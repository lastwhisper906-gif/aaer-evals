# DELL MD&A — 0001571996-20-000051


## mdna

[0001571996-20-000051:mdna:1]
[same as prior period, unchanged from 0001571996-20-000045:mdna:1]

[0001571996-20-000051:mdna:2]
[same as prior period, unchanged from 0001571996-20-000045:mdna:2]

[0001571996-20-000051:mdna:3]
[same as prior period, unchanged from 0001571996-20-000045:mdna:3]

[0001571996-20-000051:mdna:4]
[same as prior period, unchanged from 0001571996-20-000045:mdna:4]

[0001571996-20-000051:mdna:5]
[same as prior period, unchanged from 0001571996-20-000045:mdna:5]

[0001571996-20-000051:mdna:6]
[same as prior period, unchanged from 0001571996-20-000045:mdna:6]

[0001571996-20-000051:mdna:7]
Dell Technologies operates with significant scale and an unmatched breadth of complementary offerings.  Digital transformation has become essential to all businesses, and we have expanded our portfolio to include holistic solutions that enable our customers to drive their ongoing digital transformation initiatives.  Dell Technologies’ integrated solutions help customers modernize their IT infrastructure, address workforce transformation, and provide critical solutions to keep people and organizations connected in this current time of disruption caused by the coronavirus disease 2019 (“COVID-19”) pandemic.  We are providing essential solutions to our customers during this period of accelerated digital transformation to improve and strengthen business and workforce productivity.  With our extensive portfolio and our commitment to innovation, we have the ability to offer secure, integrated solutions that extend from the edge to the core to the cloud, and we are at the forefront of the software-defined and cloud native infrastructure era.  Our end-to-end portfolio is supported by a differentiated go-to-market engine, which includes a 43,000-person sales force, a global network of channel partners, and a world-class supply chain that together drive long-term growth and operating efficiencies.

[0001571996-20-000051:mdna:8]
In October 2020, Dell Technologies announced Project APEX, which will simplify how our customers can consume IT as-a-Service—across storage, servers, networking, hyper-converged infrastructure, PCs and broader solutions.  As we release these solutions over time, businesses will be able to buy and implement IT with a simple, consistent cloud experience across our extensive product portfolio.  Dell Technologies Cloud Console will give customers a single self-service interface to manage every aspect of their cloud and as-a-Service journey.  Dell Technologies Storage as-a-Service will be deployed and managed on-premises by Dell Technologies.

[0001571996-20-000051:mdna:9]
[same as prior period, unchanged from 0001571996-20-000045:mdna:8]

[0001571996-20-000051:mdna:10]
[same as prior period, unchanged from 0001571996-20-000045:mdna:9]

[0001571996-20-000051:mdna:11]
[same as prior period, unchanged from 0001571996-20-000045:mdna:10]

[0001571996-20-000051:mdna:12]
Our comprehensive portfolio of advanced storage solutions includes traditional storage solutions as well as next-generation storage solutions (such as all-flash arrays, scale-out file, object platforms, and software-defined solutions).  We have simplified our storage portfolio to ensure that we deliver the technology needed for our customers’ digital transformation.  We continue to make enhancements to our storage solutions offerings and expect that these offerings, including our new PowerStore storage array released in May 2020, will drive long-term improvements in the business.  Our server portfolio includes high-performance rack, blade, tower, and hyperscale servers, optimized for artificial intelligence and machine learning workloads.  Our networking portfolio helps our business customers transform and modernize their infrastructure, mobilize and enrich end-user experiences, and accelerate business applications and processes.  Our strengths in server, storage, and virtualization software solutions enable us to offer leading converged and hyper-converged solutions, allowing our customers to accelerate their IT transformation by acquiring scalable integrated IT solutions instead of building and assembling their own IT platforms.  ISG also offers attached software, peripherals, and services, including support and deployment, configuration, and extended warranty services.

[0001571996-20-000051:mdna:13]
[same as prior period, unchanged from 0001571996-20-000045:mdna:12]

[0001571996-20-000051:mdna:14]
[same as prior period, unchanged from 0001571996-20-000045:mdna:13]

[0001571996-20-000051:mdna:15]
[same as prior period, unchanged from 0001571996-20-000045:mdna:14]

[0001571996-20-000051:mdna:16]
[same as prior period, unchanged from 0001571996-20-000045:mdna:15]

[0001571996-20-000051:mdna:17]
[same as prior period, unchanged from 0001571996-20-000045:mdna:16]

[0001571996-20-000051:mdna:18]
On December 30, 2019, VMware, Inc. completed its acquisition of Pivotal Software, Inc. (“Pivotal”).  Before the transaction, Pivotal was a majority-owned subsidiary of Dell Technologies through EMC and VMware, Inc.  Pivotal provides a leading cloud-native platform that makes software development and IT operations a strategic advantage for

[0001571996-20-000051:mdna:19]
customers.  Pivotal’s cloud-native platform, Pivotal Cloud Foundry, accelerates and streamlines software development by reducing the complexity of building, deploying, and operating new cloud-native applications, and modernizing legacy applications.  With the acquisition, which aligns key software assets, VMware, Inc. will drive and build on a comprehensive development platform with Kubernetes.

[0001571996-20-000051:mdna:20]
[same as prior period, unchanged from 0001571996-20-000045:mdna:19]

[0001571996-20-000051:mdna:21]
[same as prior period, unchanged from 0001571996-20-000045:mdna:20]

[0001571996-20-000051:mdna:22]
Our other businesses, described below, consist of product and service offerings of Secureworks, Virtustream, and Boomi, each of which is majority-owned by Dell Technologies.  These businesses are not classified as reportable segments, either individually or collectively, as the results of the businesses are not material to our overall results and the businesses do not meet the criteria for reportable segments.

[0001571996-20-000051:mdna:23]
[same as prior period, unchanged from 0001571996-20-000045:mdna:22]

[0001571996-20-000051:mdna:24]
[same as prior period, unchanged from 0001571996-20-000045:mdna:23]

[0001571996-20-000051:mdna:25]
[same as prior period, unchanged from 0001571996-20-000045:mdna:24]

[0001571996-20-000051:mdna:26]
On February 18, 2020, we announced our entry into a definitive agreement with a consortium of investors to sell RSA Security.  On September 1, 2020, the parties closed the transaction.  At the completion of the sale, we received total cash consideration of approximately $2.082 billion, resulting in a pre-tax gain on sale of $338 million.  The Company ultimately recorded a $21 million loss net of taxes.  The transaction was intended to further simplify our product portfolio and corporate structure.  Prior to the divestiture, RSA Security’s operating results were included within Other businesses.  See Note 1 of the Notes to the Condensed Consolidated Financial Statements included in this report for more information about this transaction.

[0001571996-20-000051:mdna:27]
[same as prior period, unchanged from 0001571996-20-000045:mdna:26]

[0001571996-20-000051:mdna:28]
[same as prior period, unchanged from 0001571996-20-000045:mdna:27]

[0001571996-20-000051:mdna:29]
[same as prior period, unchanged from 0001571996-20-000045:mdna:28]

[0001571996-20-000051:mdna:30]
Dell Financial Services and its affiliates (“DFS”) support our businesses by offering and arranging various financing options and services for our customers in North America, Europe, Australia, and New Zealand.  DFS originates, collects, and services customer receivables primarily related to the purchase or use of our product, software, and service solutions.  We also arrange financing for some of our customers in various countries where DFS does not currently operate as a captive.  DFS further strengthens our customer relationships through its flexible consumption models, which enable us to offer our customers the option to pay over time and, in certain cases, based on utilization, providing them with financial flexibility to meet their changing technological requirements.  The results of these operations are allocated to our segments based on the underlying product or service financed.  In response to the COVID-19 pandemic, we are continuing to focus on supporting our customers and are providing up to $9 billion in financing support by offering low or zero percent interest rate programs as well as payment deferral options.  The financial impact to DFS and our securitization and structured financing programs is not expected to be

[0001571996-20-000051:mdna:31]
material.  For additional information about our financing arrangements, see Note 4 of the Notes to the Condensed Consolidated Financial Statements included in this report.

[0001571996-20-000051:mdna:32]
[same as prior period, unchanged from 0001571996-20-000045:mdna:31]

[0001571996-20-000051:mdna:33]
As part of our strategy, we will continue to evaluate opportunities for strategic investments through our venture capital investment arm, Dell Technologies Capital, with a focus on emerging technology areas that are relevant to all segments of our business and that will complement our existing portfolio of solutions.  Our investment areas include storage, software-defined networking, management and orchestration, security, machine learning and artificial intelligence, Big Data and analytics, cloud, Internet of Things (“IoT”), and software development operations.  In addition to these investments, we also may make disciplined acquisitions targeting businesses that advance our strategic objectives.  As of October 30, 2020 and January 31, 2020, Dell Technologies held strategic investments of $1.5 billion and $0.9 billion, respectively.

[0001571996-20-000051:mdna:34]
[same as prior period, unchanged from 0001571996-20-000045:mdna:33]

[0001571996-20-000051:mdna:35]
[same as prior period, unchanged from 0001571996-20-000045:mdna:34]

[0001571996-20-000051:mdna:36]
The health of our employees, customers, business partners, and communities remains our primary focus.  We have taken numerous actions to date in response to COVID-19, including a swift implementation of our business continuity plans.  Our crisis management team is actively engaged to respond to changes in our environment quickly and effectively, and to ensure that our preparedness plans and response activities are aligned with recommendations of the WHO, the U.S. Centers for Disease Control and Prevention, and governmental regulations.  We have implemented broad travel restrictions and moved to virtual-only events.  Most of our employees were previously equipped with remote work capabilities over the past several years, thus enabling us to quickly establish a work-from-home posture for the majority of our employees.  Further, we implemented pandemic-specific protocols for our essential employees whose jobs require them to be on-site or with customers.  With the virus surging again across many regions, we are being cautious with our return-to-site protocols and will continue remote work practices to ensure the health and safety of our employees, customers, and business partners.

[0001571996-20-000051:mdna:37]
We are working closely with our customers and business partners to support them as they expand their own remote work solutions and contingency plans, helping them access our products and services remotely.  We have benefited from our agility, our breadth, and our scale.  Notable actions we have taken include the following:

[0001571996-20-000051:mdna:38]
[same as prior period, unchanged from 0001571996-20-000045:mdna:37]

[0001571996-20-000051:mdna:39]
[same as prior period, unchanged from 0001571996-20-000045:mdna:38]

[0001571996-20-000051:mdna:40]
[same as prior period, unchanged from 0001571996-20-000045:mdna:39]

[0001571996-20-000051:mdna:41]
[same as prior period, unchanged from 0001571996-20-000045:mdna:40]

[0001571996-20-000051:mdna:42]
[same as prior period, unchanged from 0001571996-20-000045:mdna:41]

[0001571996-20-000051:mdna:43]
During the first nine months of Fiscal 2021, we took certain precautionary measures to increase our cash position and preserve financial flexibility.  We also made a series of prudent decisions to manage expenses and preserve liquidity including but not

[0001571996-20-000051:mdna:44]
limited to global hiring limitations, reduction in consulting and contractor costs, global travel restrictions, suspension of the Dell 401(k) match program for U.S. employees, and lower facilities-related costs.  We will evaluate these actions as we set our annual operating plan for Fiscal 2022, taking into account current conditions, and expect that some of the benefits of these cost reduction initiatives recognized during Fiscal 2021 will phase out over time.  All of these actions are aligned with our strategy, which remains unchanged, of focusing on gaining share, integrating and innovating across the Dell Technologies portfolio, and strengthening our capital structure.

[0001571996-20-000051:mdna:45]
We saw unique demand dynamics during the first nine months of Fiscal 2021.   In ISG, the demand environment weakened as enterprise customers directed more of their investments towards remote work and business continuity solutions.  In CSG, overall demand was stronger than expected as customers sought to enable work and learn from home solutions.  For additional information about impacts of COVID-19 on our operations, see “Results of Operations—Consolidated Results” and “—Business Unit Results.”

[0001571996-20-000051:mdna:46]
[same as prior period, unchanged from 0001571996-20-000045:mdna:44]

[0001571996-20-000051:mdna:47]
[same as prior period, unchanged from 0001571996-20-000045:mdna:45]

[0001571996-20-000051:mdna:48]
[same as prior period, unchanged from 0001571996-20-000045:mdna:46]

[0001571996-20-000051:mdna:49]
ISG — We expect that ISG will continue to be impacted by the changing nature of the IT infrastructure market and competitive environment.  The overall server demand environment was down for the first nine months of Fiscal 2021 and remains varied among international regions.  In the fourth quarter of Fiscal 2021, we expect ISG demand to be slightly lower than the prior year’s sequential growth based on the continued softness in data center spending.  We will continue to be selective in determining whether to pursue certain large hyperscale and other server transactions as we drive for balanced growth and profitability.  With our scale and strong solutions portfolio, we believe we are well-positioned to respond to ongoing competitive dynamics.  We continue to focus on customer base expansion and lifetime value of customer relationships.

[0001571996-20-000051:mdna:50]
[same as prior period, unchanged from 0001571996-20-000045:mdna:48]

[0001571996-20-000051:mdna:51]
[same as prior period, unchanged from 0001571996-20-000045:mdna:49]

[0001571996-20-000051:mdna:52]
CSG — Our CSG offerings are an important element of our strategy, generating strong cash flow and opportunities for cross-selling of complementary solutions.  During the first nine months of Fiscal 2021, CSG demand was strong in certain product

[0001571996-20-000051:mdna:53]
67

[0001571996-20-000051:mdna:54]
lines, particularly for notebooks and gaming systems, while demand for commercial desktops decreased.  These demand dynamics were driven by the imperative for remote work and remote learning solutions, as business, government, and education customers sought to maintain productivity in the midst of COVID-19.  We continue to deploy Dell PC as a Service offerings for customers who are seeking simplified solutions and lifecycle management with predictable pricing through DFS.  We expect that the CSG demand environment will to continue to be cyclical.  CSG demand in the fourth quarter of the fiscal year is typically stronger due to holiday purchasing patterns, and in Fiscal 2021 we expect CSG demand in the fourth quarter to be slightly above normal seasonality.  We remain committed to our long-term strategy for CSG and will continue to innovate across the portfolio, while benefiting from consolidation trends that are occurring in the markets in which we compete.  Competitive dynamics will continue to be a factor in our CSG business as we seek to balance profitability and growth.

[0001571996-20-000051:mdna:55]
[same as prior period, unchanged from 0001571996-20-000045:mdna:53]

[0001571996-20-000051:mdna:56]
Supply Chain — During Fiscal 2020, we recognized benefits to our ISG and CSG operating results from significant component cost declines.  During the first nine months of Fiscal 2021, component costs continued to decline in the aggregate, but at a lower rate than in Fiscal 2020.  In recent quarters ISG experienced some component cost inflation, particularly for servers.  The component cost trending is dependent on the strength or weakness of actual end-user demand and supply dynamics, which will continue to evolve and ultimately impact the translation of the cost environment to pricing and operating results.

[0001571996-20-000051:mdna:57]
Dell Technologies maintains limited-source supplier relationships for certain components, because the relationships are advantageous in the areas of performance, quality, support, delivery, capacity, and price considerations.  In recent periods, we have been impacted by component supply constraints in certain product offerings, some of which resulted from COVID-19 driven demand patterns.  Delays in the supply of limited-source components, including as a result of COVID-19, are affecting the timing of shipments of certain products in desired quantities or configurations.

[0001571996-20-000051:mdna:58]
[same as prior period, unchanged from 0001571996-20-000045:mdna:56]

[0001571996-20-000051:mdna:59]
We manage our business on a U.S. dollar basis.  However, we have a large global presence, generating approximately half of our revenue by sales to customers outside of the United States during both the first nine months of Fiscal 2021 and Fiscal 2020.  As a result, our revenue can be impacted by fluctuations in foreign currency exchange rates.  We utilize a comprehensive hedging strategy intended to mitigate the impact of foreign currency volatility over time, and we adjust pricing when possible to further minimize foreign currency impacts.

[0001571996-20-000051:mdna:60]
[same as prior period, unchanged from 0001571996-20-000045:mdna:58]

[0001571996-20-000051:mdna:61]
[same as prior period, unchanged from 0001571996-20-000045:mdna:59]

[0001571996-20-000051:mdna:62]
[same as prior period, unchanged from 0001571996-20-000045:mdna:60]

[0001571996-20-000051:mdna:63]
[same as prior period, unchanged from 0001571996-20-000045:mdna:61]

[0001571996-20-000051:mdna:64]
[same as prior period, unchanged from 0001571996-20-000045:mdna:62]

[0001571996-20-000051:mdna:65]
[same as prior period, unchanged from 0001571996-20-000045:mdna:63]

[0001571996-20-000051:mdna:66]
69

[0001571996-20-000051:mdna:67]
[same as prior period, unchanged from 0001571996-20-000045:mdna:65]

[0001571996-20-000051:mdna:68]
[same as prior period, unchanged from 0001571996-20-000045:mdna:66]

[0001571996-20-000051:mdna:69]
[same as prior period, unchanged from 0001571996-20-000045:mdna:67]

[0001571996-20-000051:mdna:70]
[same as prior period, unchanged from 0001571996-20-000045:mdna:68]

[0001571996-20-000051:mdna:71]
[same as prior period, unchanged from 0001571996-20-000045:mdna:69]

[0001571996-20-000051:mdna:72]
Revenue Reclassification — During Fiscal 2020, Dell Technologies made certain reclassifications of net revenue between the products and services categories on the Consolidated Statement of Net Income (Loss), which impacted previously reported amounts for the third quarter and first nine months of Fiscal 2020.  The reclassifications were made to provide a more meaningful representation of the nature of certain service and software-as-a-service offerings of VMware, Inc.  The reclassifications resulted in an increase to services revenue and an equal and offsetting decrease to product revenue of $210 million and $584 million for the third quarter and first nine months of Fiscal 2020, respectively.  Total net revenue as previously reported remains unchanged.  The Company did not recast cost of goods sold for the related revenue reclassifications due to immateriality.

[0001571996-20-000051:mdna:73]
[same as prior period, unchanged from 0001571996-20-000045:mdna:71]

[0001571996-20-000051:mdna:74]
[same as prior period, unchanged from 0001571996-20-000045:mdna:72]

[0001571996-20-000051:mdna:75]
[same as prior period, unchanged from 0001571996-20-000045:mdna:73]

[0001571996-20-000051:mdna:76]
•Transaction-related Expenses — Transaction-related expenses typically consist of acquisition, integration, and divestiture related costs and are expensed as incurred.  These expenses primarily represent costs for legal, banking, consulting, and advisory services.  From time to time, this category also may include transaction-related gains on divestitures of businesses or asset sales.  During the first quarter of Fiscal 2021, we recognized a gain of $120 million on the sale of certain intellectual property assets.  During the third quarter of Fiscal 2021, we recognized a pre-tax gain of $338 million on the sale of RSA Security.  We exclude these items for purposes of calculating the non-GAAP financial measures presented below to facilitate a more meaningful evaluation of our current operating performance and comparisons to our past operating performance.  See Note 1 and Note 8 of the Notes to the Condensed Consolidated Financial Statements for additional information about the divestiture of RSA Security and acquisitions by VMware, Inc., respectively.

[0001571996-20-000051:mdna:77]
[same as prior period, unchanged from 0001571996-20-000045:mdna:75]

[0001571996-20-000051:mdna:78]
•Other Corporate Expenses — Other corporate expenses consists primarily of severance, facility action, and other costs.  Severance costs are primarily related to severance and benefits for employees terminated pursuant to cost savings initiatives.  We continue to integrate owned and leased facilities and may incur additional costs as we seek opportunities for operational efficiencies.  Other corporate expenses vary from period to period and are significantly impacted by the timing and nature of these events.  Therefore, although we may incur these types of expenses in the future, we believe that eliminating these charges for purposes of calculating the non-GAAP financial measures presented below facilitates a more

[0001571996-20-000051:mdna:79]
meaningful evaluation of our current operating performance and comparisons to our past operating performance.  During the first nine months of Fiscal 2020, this category included Virtustream gross impairment charges of $619 million.

[0001571996-20-000051:mdna:80]
•Fair Value Adjustments on Equity Investments — Fair value adjustments on equity investments primarily consists of the gain (loss) on strategic investments, which includes the recurring fair value adjustments of investments in publicly-traded companies, as well as those in privately-held companies, which are adjusted for observable price changes and, to a lesser extent, any potential impairments.  During the third quarter and first nine months of Fiscal 2021, this category included an unrealized gain of $465 million related to one of our strategic investments.  See Note 3 of the Notes to the Condensed Consolidated Financial Statements for additional information on our strategic investment activity.  Given the volatility in the ongoing adjustments to the valuation of these strategic investments, we believe that excluding these gains and losses for purposes of calculating non-GAAP net income presented below facilitates a more meaningful evaluation of our current operating performance and comparisons to our past operating performance.

[0001571996-20-000051:mdna:81]
•Aggregate Adjustment for Income Taxes — The aggregate adjustment for income taxes is the estimated combined income tax effect for the adjustments described above, as well as an adjustment for discrete tax items.  Due to the variability in recognition of discrete tax items from period to period, we believe that excluding these benefits or charges for purposes of calculating non-GAAP net income facilitates a more meaningful evaluation of our current operating performance and comparisons to our past operating performance.  The tax effects are determined based on the tax jurisdictions where the above items were incurred.  See Note 11 of the Notes to the Condensed Consolidated Financial Statements for additional information about our income taxes, including discrete tax items.

[0001571996-20-000051:mdna:82]
[same as prior period, unchanged from 0001571996-20-000045:mdna:77]

[0001571996-20-000051:mdna:83]
[same as prior period, unchanged from 0001571996-20-000045:mdna:82]

[0001571996-20-000051:mdna:84]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 30, 2020 |  | % Change |  | November 1, 2019 |  | October 30, 2020 |  | % Change |  | November 1, 2019 |
|  | (in millions, except percentages) |
| Product net revenue | $ | 17,352 |  |  | — | % |  | $ | 17,275 |  |  | $ | 50,127 |  |  | (3) | % |  | $ | 51,765 |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Impact of purchase accounting | 2 |  |  |  |  | 5 |  |  | 8 |  |  |  |  | 15 |  |
| Non-GAAP product net revenue | $ | 17,354 |  |  | — | % |  | $ | 17,280 |  |  | $ | 50,135 |  |  | (3) | % |  | $ | 51,780 |  |
| Services net revenue | $ | 6,130 |  |  | 10 | % |  | $ | 5,569 |  |  | $ | 17,985 |  |  | 10 | % |  | $ | 16,357 |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Impact of purchase accounting | 37 |  |  |  |  | 79 |  |  | 121 |  |  |  |  | 235 |  |
| Non-GAAP services net revenue | $ | 6,167 |  |  | 9 | % |  | $ | 5,648 |  |  | $ | 18,106 |  |  | 9 | % |  | $ | 16,592 |  |
| Net revenue | $ | 23,482 |  |  | 3 | % |  | $ | 22,844 |  |  | $ | 68,112 |  |  | — | % |  | $ | 68,122 |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Impact of purchase accounting | 39 |  |  |  |  | 84 |  |  | 129 |  |  |  |  | 250 |  |
| Non-GAAP net revenue | $ | 23,521 |  |  | 3 | % |  | $ | 22,928 |  |  | $ | 68,241 |  |  | — | % |  | $ | 68,372 |  |
| Product gross margin | $ | 3,563 |  |  | (4) | % |  | $ | 3,717 |  |  | $ | 10,204 |  |  | (9) | % |  | $ | 11,239 |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 376 |  |  |  |  | 517 |  |  | 1,122 |  |  |  |  | 1,555 |  |
| Impact of purchase accounting | 3 |  |  |  |  | 7 |  |  | 13 |  |  |  |  | 20 |  |
| Transaction-related expenses | — |  |  |  |  | — |  |  | — |  |  |  |  | (5) |  |
| Stock-based compensation expense | 7 |  |  |  |  | 3 |  |  | 17 |  |  |  |  | 9 |  |
| Other corporate expenses | 12 |  |  |  |  | 2 |  |  | 15 |  |  |  |  | 11 |  |
| Non-GAAP product gross margin | $ | 3,961 |  |  | (7) | % |  | $ | 4,246 |  |  | $ | 11,371 |  |  | (11) | % |  | $ | 12,829 |  |
| Services gross margin | $ | 3,698 |  |  | 8 | % |  | $ | 3,409 |  |  | $ | 11,066 |  |  | 11 | % |  | $ | 10,010 |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | (1) |  |  |  |  | — |  |  | — |  |  |  |  | — |  |
| Impact of purchase accounting | 37 |  |  |  |  | 79 |  |  | 121 |  |  |  |  | 235 |  |
| Transaction-related expenses | — |  |  |  |  | — |  |  | — |  |  |  |  | — |  |
| Stock-based compensation expense | 44 |  |  |  |  | 30 |  |  | 124 |  |  |  |  | 82 |  |
| Other corporate expenses | 32 |  |  |  |  | 4 |  |  | 40 |  |  |  |  | 32 |  |
| Non-GAAP services gross margin | $ | 3,810 |  |  | 8 | % |  | $ | 3,522 |  |  | $ | 11,351 |  |  | 10 | % |  | $ | 10,359 |  |

[0001571996-20-000051:mdna:85]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 30, 2020 |  | % Change |  | November 1, 2019 |  | October 30, 2020 |  | % Change |  | November 1, 2019 |
|  | (in millions, except percentages) |
| Gross margin | $ | 7,261 |  |  | 2 | % |  | $ | 7,126 |  |  | $ | 21,270 |  |  | — | % |  | $ | 21,249 |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 375 |  |  |  |  | 517 |  |  | 1,122 |  |  |  |  | 1,555 |  |
| Impact of purchase accounting | 40 |  |  |  |  | 86 |  |  | 134 |  |  |  |  | 255 |  |
| Transaction-related expenses | — |  |  |  |  | — |  |  | — |  |  |  |  | (5) |  |
| Stock-based compensation expense | 51 |  |  |  |  | 33 |  |  | 141 |  |  |  |  | 91 |  |
| Other corporate expenses | 44 |  |  |  |  | 6 |  |  | 55 |  |  |  |  | 43 |  |
| Non-GAAP gross margin | $ | 7,771 |  |  | — | % |  | $ | 7,768 |  |  | $ | 22,722 |  |  | (2) | % |  | $ | 23,188 |  |
| Operating expenses | $ | 6,132 |  |  | (3) | % |  | $ | 6,290 |  |  | $ | 18,303 |  |  | (5) | % |  | $ | 19,344 |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | (470) |  |  |  |  | (540) |  |  | (1,425) |  |  |  |  | (1,779) |  |
| Impact of purchase accounting | (9) |  |  |  |  | (10) |  |  | (31) |  |  |  |  | (44) |  |
| Transaction-related expenses | (52) |  |  |  |  | (76) |  |  | (211) |  |  |  |  | (170) |  |
| Stock-based compensation expense | (385) |  |  |  |  | (289) |  |  | (1,078) |  |  |  |  | (795) |  |
| Other corporate expenses | (170) |  |  |  |  | (49) |  |  | (340) |  |  |  |  | (749) |  |
| Non-GAAP operating expenses | $ | 5,046 |  |  | (5) | % |  | $ | 5,326 |  |  | $ | 15,218 |  |  | (4) | % |  | $ | 15,807 |  |
| Operating income | $ | 1,129 |  |  | 35 | % |  | $ | 836 |  |  | $ | 2,967 |  |  | 56 | % |  | $ | 1,905 |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 845 |  |  |  |  | 1,057 |  |  | 2,547 |  |  |  |  | 3,334 |  |
| Impact of purchase accounting | 49 |  |  |  |  | 96 |  |  | 165 |  |  |  |  | 299 |  |
| Transaction-related expenses | 52 |  |  |  |  | 76 |  |  | 211 |  |  |  |  | 165 |  |
| Stock-based compensation expense | 436 |  |  |  |  | 322 |  |  | 1,219 |  |  |  |  | 886 |  |
| Other corporate expenses | 214 |  |  |  |  | 55 |  |  | 395 |  |  |  |  | 792 |  |
| Non-GAAP operating income | $ | 2,725 |  |  | 12 | % |  | $ | 2,442 |  |  | $ | 7,504 |  |  | 2 | % |  | $ | 7,381 |  |
| Net income | $ | 881 |  |  | 60 | % |  | $ | 552 |  |  | $ | 2,162 |  |  | (58) | % |  | $ | 5,113 |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 845 |  |  |  |  | 1,057 |  |  | 2,547 |  |  |  |  | 3,334 |  |
| Impact of purchase accounting | 49 |  |  |  |  | 96 |  |  | 165 |  |  |  |  | 299 |  |
| Transaction-related (income) expenses | (286) |  |  |  |  | 76 |  |  | (247) |  |  |  |  | 165 |  |
| Stock-based compensation expense | 436 |  |  |  |  | 322 |  |  | 1,219 |  |  |  |  | 886 |  |
| Other corporate expenses | 106 |  |  |  |  | 55 |  |  | 287 |  |  |  |  | 792 |  |
| Fair value adjustments on equity investments | (489) |  |  |  |  | (18) |  |  | (591) |  |  |  |  | (160) |  |
| Aggregate adjustment for income taxes | 169 |  |  |  |  | (695) |  |  | (1,067) |  |  |  |  | (6,024) |  |
| Non-GAAP net income | $ | 1,711 |  |  | 18 | % |  | $ | 1,445 |  |  | $ | 4,475 |  |  | 2 | % |  | $ | 4,405 |  |

[0001571996-20-000051:mdna:86]
74

[0001571996-20-000051:mdna:87]
[same as prior period, unchanged from 0001571996-20-000045:mdna:86]

[0001571996-20-000051:mdna:88]
[same as prior period, unchanged from 0001571996-20-000045:mdna:87]

[0001571996-20-000051:mdna:89]
[same as prior period, unchanged from 0001571996-20-000045:mdna:88]

[0001571996-20-000051:mdna:90]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 30, 2020 |  | % Change |  | November 1, 2019 |  | October 30, 2020 |  | % Change |  | November 1, 2019 |
|  | (in millions, except percentages) |
| Net income | $ | 881 |  |  | 60 | % |  | $ | 552 |  |  | $ | 2,162 |  |  | (58) | % |  | $ | 5,113 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Interest and other, net (a) | (273) |  |  |  |  | 677 |  |  | 929 |  |  |  |  | 2,000 |  |
| Income tax expense (benefit) (b) | 521 |  |  |  |  | (393) |  |  | (124) |  |  |  |  | (5,208) |  |
| Depreciation and amortization | 1,361 |  |  |  |  | 1,494 |  |  | 4,017 |  |  |  |  | 4,608 |  |
| EBITDA | $ | 2,490 |  |  | 7 | % |  | $ | 2,330 |  |  | $ | 6,984 |  |  | 7 | % |  | $ | 6,513 |  |
| EBITDA | $ | 2,490 |  |  | 7 | % |  | $ | 2,330 |  |  | $ | 6,984 |  |  | 7 | % |  | $ | 6,513 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation expense | 436 |  |  |  |  | 322 |  |  | 1,219 |  |  |  |  | 886 |  |
| Impact of purchase accounting (c) | 39 |  |  |  |  | 84 |  |  | 129 |  |  |  |  | 251 |  |
| Transaction-related expenses (d) | 52 |  |  |  |  | 76 |  |  | 211 |  |  |  |  | 165 |  |
| Other corporate expenses (e) | 214 |  |  |  |  | 45 |  |  | 395 |  |  |  |  | 771 |  |
| Adjusted EBITDA | $ | 3,231 |  |  | 13 | % |  | $ | 2,857 |  |  | $ | 8,938 |  |  | 4 | % |  | $ | 8,586 |  |

[0001571996-20-000051:mdna:91]
[same as prior period, unchanged from 0001571996-20-000045:mdna:90]

[0001571996-20-000051:mdna:92]
[same as prior period, unchanged from 0001571996-20-000045:mdna:91]

[0001571996-20-000051:mdna:93]
(b)See Note 11 of the Notes to the Condensed Consolidated Financial Statements included in this report for additional information on discrete tax items recorded during the third quarter and first nine months of Fiscal 2021 and Fiscal 2020.

[0001571996-20-000051:mdna:94]
[same as prior period, unchanged from 0001571996-20-000045:mdna:93]

[0001571996-20-000051:mdna:95]
[same as prior period, unchanged from 0001571996-20-000045:mdna:94]

[0001571996-20-000051:mdna:96]
[same as prior period, unchanged from 0001571996-20-000045:mdna:95]

[0001571996-20-000051:mdna:97]
[same as prior period, unchanged from 0001571996-20-000045:mdna:96]

[0001571996-20-000051:mdna:98]
[same as prior period, unchanged from 0001571996-20-000045:mdna:97]

[0001571996-20-000051:mdna:99]
[same as prior period, unchanged from 0001571996-20-000045:mdna:98]

[0001571996-20-000051:mdna:100]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 30, 2020 |  |  |  | November 1, 2019 |  | October 30, 2020 |  |  |  | November 1, 2019 |
|  | Dollars |  | % ofNet Revenue |  | %Change |  | Dollars |  | % ofNet Revenue |  | Dollars |  | % ofNet Revenue |  | %Change |  | Dollars |  | % ofNet Revenue |
|  | (in millions, except percentages) |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Products (a) | $ | 17,352 |  |  | 73.9 | % |  | — | % |  | $ | 17,275 |  |  | 75.6 | % |  | $ | 50,127 |  |  | 73.6 | % |  | (3) | % |  | $ | 51,765 |  |  | 76.0 | % |
| Services (a) | 6,130 |  |  | 26.1 | % |  | 10 | % |  | 5,569 |  |  | 24.4 | % |  | 17,985 |  |  | 26.4 | % |  | 10 | % |  | 16,357 |  |  | 24.0 | % |
| Total net revenue | $ | 23,482 |  |  | 100.0 | % |  | 3 | % |  | $ | 22,844 |  |  | 100.0 | % |  | $ | 68,112 |  |  | 100.0 | % |  | — | % |  | $ | 68,122 |  |  | 100.0 | % |
| Gross margin: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Products (b) | $ | 3,563 |  |  | 20.5 | % |  | (4) | % |  | $ | 3,717 |  |  | 21.5 | % |  | $ | 10,204 |  |  | 20.4 | % |  | (9) | % |  | $ | 11,239 |  |  | 21.7 | % |
| Services (c) | 3,698 |  |  | 60.3 | % |  | 8 | % |  | 3,409 |  |  | 61.2 | % |  | 11,066 |  |  | 61.5 | % |  | 11 | % |  | 10,010 |  |  | 61.2 | % |
| Total gross margin | $ | 7,261 |  |  | 30.9 | % |  | 2 | % |  | $ | 7,126 |  |  | 31.2 | % |  | $ | 21,270 |  |  | 31.2 | % |  | — | % |  | $ | 21,249 |  |  | 31.2 | % |
| Operating expenses | $ | 6,132 |  |  | 26.1 | % |  | (3) | % |  | $ | 6,290 |  |  | 27.5 | % |  | $ | 18,303 |  |  | 26.9 | % |  | (5) | % |  | $ | 19,344 |  |  | 28.4 | % |
| Operating income | $ | 1,129 |  |  | 4.8 | % |  | 35 | % |  | $ | 836 |  |  | 3.7 | % |  | $ | 2,967 |  |  | 4.4 | % |  | 56 | % |  | $ | 1,905 |  |  | 2.8 | % |
| Net income | $ | 881 |  |  | 3.8 | % |  | 60 | % |  | $ | 552 |  |  | 2.4 | % |  | $ | 2,162 |  |  | 3.2 | % |  | (58) | % |  | $ | 5,113 |  |  | 7.5 | % |
| Net income attributable to Dell Technologies Inc. | $ | 832 |  |  | 3.5 | % |  | 67 | % |  | $ | 499 |  |  | 2.2 | % |  | $ | 2,023 |  |  | 3.0 | % |  | (52) | % |  | $ | 4,208 |  |  | 6.2 | % |
| Non-GAAP Financial Information |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Non-GAAP net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Products (a) | $ | 17,354 |  |  | 73.8 | % |  | — | % |  | $ | 17,280 |  |  | 75.4 | % |  | $ | 50,135 |  |  | 73.5 | % |  | (3) | % |  | $ | 51,780 |  |  | 75.7 | % |
| Services (a) | 6,167 |  |  | 26.2 | % |  | 9 | % |  | 5,648 |  |  | 24.6 | % |  | 18,106 |  |  | 26.5 | % |  | 9 | % |  | 16,592 |  |  | 24.3 | % |
| Total non-GAAP net revenue | $ | 23,521 |  |  | 100.0 | % |  | 3 | % |  | $ | 22,928 |  |  | 100.0 | % |  | $ | 68,241 |  |  | 100.0 | % |  | — | % |  | $ | 68,372 |  |  | 100.0 | % |
| Non-GAAP gross margin: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Products (b) | $ | 3,961 |  |  | 22.8 | % |  | (7) | % |  | $ | 4,246 |  |  | 24.6 | % |  | $ | 11,371 |  |  | 22.7 | % |  | (11) | % |  | $ | 12,829 |  |  | 24.8 | % |
| Services (c) | 3,810 |  |  | 61.8 | % |  | 8 | % |  | 3,522 |  |  | 62.4 | % |  | 11,351 |  |  | 62.7 | % |  | 10 | % |  | 10,359 |  |  | 62.4 | % |
| Total non-GAAP gross margin | $ | 7,771 |  |  | 33.0 | % |  | — | % |  | $ | 7,768 |  |  | 33.9 | % |  | $ | 22,722 |  |  | 33.3 | % |  | (2) | % |  | $ | 23,188 |  |  | 33.9 | % |
| Non-GAAP operating expenses | $ | 5,046 |  |  | 21.5 | % |  | (5) | % |  | $ | 5,326 |  |  | 23.2 | % |  | $ | 15,218 |  |  | 22.3 | % |  | (4) | % |  | $ | 15,807 |  |  | 23.1 | % |
| Non-GAAP operating income | $ | 2,725 |  |  | 11.6 | % |  | 12 | % |  | $ | 2,442 |  |  | 10.7 | % |  | $ | 7,504 |  |  | 11.0 | % |  | 2 | % |  | $ | 7,381 |  |  | 10.8 | % |
| Non-GAAP net income | $ | 1,711 |  |  | 7.3 | % |  | 18 | % |  | $ | 1,445 |  |  | 6.3 | % |  | $ | 4,475 |  |  | 6.6 | % |  | 2 | % |  | $ | 4,405 |  |  | 6.4 | % |
| EBITDA | $ | 2,490 |  |  | 10.6 | % |  | 7 | % |  | $ | 2,330 |  |  | 10.2 | % |  | $ | 6,984 |  |  | 10.2 | % |  | 7 | % |  | $ | 6,513 |  |  | 9.5 | % |
| Adjusted EBITDA | $ | 3,231 |  |  | 13.7 | % |  | 13 | % |  | $ | 2,857 |  |  | 12.5 | % |  | $ | 8,938 |  |  | 13.1 | % |  | 4 | % |  | $ | 8,586 |  |  | 12.6 | % |

[0001571996-20-000051:mdna:101]
[same as prior period, unchanged from 0001571996-20-000045:mdna:100]

[0001571996-20-000051:mdna:102]
(a)    During Fiscal 2020, Dell Technologies made certain reclassifications of net revenue between the products and services categories on the Consolidated Statement of Net Income (Loss), which impacted previously reported amounts for the third quarter and first nine months of Fiscal 2020.  The Company did not recast cost of goods sold for the related revenue reclassifications due to immateriality.  The reclassifications resulted in an increase to services revenue and an equal and offsetting decrease to product revenue of $210 million and $584 million for the third quarter and first nine months of Fiscal 2020, respectively.  Total net revenue as previously reported remains unchanged.

[0001571996-20-000051:mdna:103]
76

[0001571996-20-000051:mdna:104]
(b)    Product gross margin percentages represent product gross margin as a percentage of product net revenue, and non-GAAP product gross margin percentages represent non-GAAP product gross margin as a percentage of non-GAAP product net revenue.

[0001571996-20-000051:mdna:105]
(c)    Services gross margin percentages represent services gross margin as a percentage of services net revenue, and non-GAAP services gross margin percentages represent non-GAAP services gross margin as a percentage of non-GAAP services net revenue.

[0001571996-20-000051:mdna:106]
[same as prior period, unchanged from 0001571996-20-000045:mdna:105]

[0001571996-20-000051:mdna:107]
[same as prior period, unchanged from 0001571996-20-000045:mdna:106]

[0001571996-20-000051:mdna:108]
During the third quarter and first nine months of Fiscal 2021, our net revenue increased 3% and remained flat, respectively, as we benefited from the strength of our broad technology solutions portfolio, which helped us navigate market volatility and competitive pressures, particularly due to the COVID-19 environment.  During the third quarter and first nine months of Fiscal 2021, our non-GAAP net revenue also increased 3% and remained flat, respectively.  Increases in CSG and VMware net revenue were offset by a decline in ISG net revenue for both the third quarter and first nine months of Fiscal 2021.  The increase in CSG net revenue was primarily driven by growth in consumer solutions and continued strong demand for commercial notebooks, partially offset by lower demand for commercial desktops.  VMware net revenue increased due to growth in sales of subscriptions and software-as-a-service offerings and software maintenance.  ISG net revenue decreased primarily due to a weaker demand environment as customers continued to direct their investments towards remote work and business continuity solutions.  Although we are in the midst of unprecedented uncertainty as a result of the ongoing COVID-19 pandemic, we believe we are well-positioned for long-term profitable growth while also maintaining the ability to adjust as needed to changing market conditions with complementary solutions across all segments of our business, an agile workforce, and the strength of our global supply chain.

[0001571996-20-000051:mdna:109]
During the third quarter and first nine months of Fiscal 2021, our operating income increased 35% and 56%, respectively, primarily driven by lower selling, general, and administrative expenses as we realized the benefit of cost reduction initiatives.  During the third quarter of Fiscal 2021, operating income benefited from increases in operating income for CSG and VMware, and a decrease in amortization of intangible assets.  These benefits were partially offset by a decrease in operating income for ISG and increases in stock-based compensation expense and severance costs.  During the first nine months of Fiscal 2021, the increase in operating income was primarily attributable to the absence of Virtustream impairment charges of $619 million recognized in the first nine months of Fiscal 2020.  Operating income for the first nine months of Fiscal 2021 also benefited from increases in operating income for VMware and other businesses and a decrease in amortization of intangible assets.  These benefits were partially offset by decreases in operating income for CSG and ISG and increases in stock-based compensation expense and severance costs.

[0001571996-20-000051:mdna:110]
Amortization of intangible assets, stock-based compensation expense, and other corporate expenses that impacted our operating income totaled $1.5 billion and $1.4 billion for the third quarter of Fiscal 2021 and Fiscal 2020, respectively, and $4.2 billion and $5.0 billion for the first nine months of Fiscal 2021 and Fiscal 2020, respectively.  Excluding these costs, and the impact of purchase accounting and transaction-related expenses, our non-GAAP operating income increased 12% and 2% during the third quarter and first nine months of Fiscal 2021, respectively.  The 12% increase in non-GAAP operating income during the third quarter of Fiscal 2021 was due to increases in operating income for CSG and VMware, which were partially offset by a decrease in operating income for ISG.  The 2% increase in non-GAAP operating income during the first nine months of Fiscal 2020 was due to increases in operating income for VMware and other businesses, which were partially offset by decreases in operating income for CSG and ISG.

[0001571996-20-000051:mdna:111]
Cash provided by operating activities was $5.5 billion and $5.8 billion for the first nine months of Fiscal 2021 and Fiscal 2020, respectively.  Operating cash flows declined slightly during the first nine months of Fiscal 2021 as the strong profitability during the period was offset by unfavorable working capital impacts of an increase in inventory, decline in growth rate of deferred revenue, and timing of purchases and payments to vendors.  COVID-19 impacts to working capital continued to

[0001571996-20-000051:mdna:112]
normalize during the third quarter of Fiscal 2021.  See “Market Conditions, Liquidity, and Capital Commitments” for further information on our cash flow metrics.

[0001571996-20-000051:mdna:113]
[same as prior period, unchanged from 0001571996-20-000045:mdna:111]

[0001571996-20-000051:mdna:114]
During the third quarter of Fiscal 2021, our net revenue and non-GAAP net revenue both increased 3%.  The increases in net revenue and non-GAAP net revenue during the third quarter of Fiscal 2021 were primarily attributable to increases in net revenue for CSG and VMware, which were partially offset by a decrease in ISG net revenue.  See “Business Unit Results” for further information.  During the first nine months of Fiscal 2021, our revenue and non-GAAP net revenue both remained flat as increases in net revenue for CSG and VMware were offset by a decrease in ISG net revenue.

[0001571996-20-000051:mdna:115]
•Product Net Revenue — Product net revenue includes revenue from the sale of hardware products and software licenses.  During the third quarter of Fiscal 2021, product net revenue and non-GAAP product net revenue both remained flat as an increase in product net revenue for CSG was offset by a decrease in product net revenue for ISG.  During the first nine months of Fiscal 2021, product net revenue and non-GAAP product net revenue both decreased 3% primarily due to a decrease in product net revenue for ISG.

[0001571996-20-000051:mdna:116]
•Services Net Revenue — Services net revenue includes revenue from our services offerings and support services related to hardware products and software licenses.  During the third quarter of Fiscal 2021, services net revenue and non-GAAP services net revenue increased 10% and 9%, respectively.  During the first nine months of Fiscal 2021, services net revenue and non-GAAP services net revenue increased 10% and 9%, respectively.  These increases were primarily attributable to increases in services net revenue for CSG third-party software and maintenance and VMware software, and in particular, increases in subscription-based licenses.  A substantial portion of services net revenue is derived from offerings that have been deferred over a period of time, and, as a result, reported services net revenue growth rates will be different than reported product net revenue growth rates.

[0001571996-20-000051:mdna:117]
From a geographical perspective, during the third quarter and first nine months of Fiscal 2021, net revenue increased in the Americas due to strong CSG performance.  These increases were offset by declines in net revenue generated by sales to customers in APJ as a result of a weaker demand environment.

[0001571996-20-000051:mdna:118]
[same as prior period, unchanged from 0001571996-20-000045:mdna:118]

[0001571996-20-000051:mdna:119]
During the third quarter and first nine months of Fiscal 2021, our gross margin increased 2% to $7.3 billion and remained flat at $21.3 billion, respectively.  The increase in our gross margin during the third quarter of Fiscal 2021 was driven by favorable impacts of gross margin increases in CSG and VMware and a decrease in amortization of intangible assets, partially offset by  gross margin decreases for ISG and other businesses.  During the first nine months of Fiscal 2021, our gross margin remained relatively flat as favorable impacts of gross margin increases for VMware and a decrease in amortization of intangible assets were offset by gross margin decreases for CSG and ISG.

[0001571996-20-000051:mdna:120]
During the third quarter and first nine months of Fiscal 2021, our gross margin percentage decreased 30 basis points to 30.9% and remained flat at 31.2% basis points, respectively.  The decrease in our gross margin percentage during the third quarter of Fiscal 2021 was primarily driven by decreases in gross margin percentage for ISG due to higher product costs and a shift in mix due to strong CSG sales, which was partially offset by  a decrease in amortization of intangible assets.  During the first nine months of Fiscal 2021, gross margin percentage remained flat as the beneficial impact of a decrease in amortization of intangible assets was offset by decreases in gross margin percentage for ISG and CSG, as well as by a decrease due to a shift in product mix due to strong CSG sales.

[0001571996-20-000051:mdna:121]
Our gross margin included the impact of amortization of intangibles and purchase accounting adjustments of $0.4 billion and $0.6 billion for the third quarter of Fiscal 2021 and Fiscal 2020, respectively, and $1.3 billion and $1.8 billion during the first nine months of Fiscal 2021 and Fiscal 2020, respectively.  Excluding these costs, transaction-related expenses, stock-based compensation expense, and other corporate expenses, non-GAAP gross margin during the third quarter and first nine months of Fiscal 2021 remained flat at $7.8 billion and decreased 2% to $22.7 billion, respectively.

[0001571996-20-000051:mdna:122]
Non-GAAP gross margin percentage decreased 90 basis points to 33.0% and 60 basis points to 33.3% during the third quarter and first nine months of Fiscal 2021, respectively.  The decrease in our non-GAAP gross margin percentage during the third quarter of Fiscal 2021 was due to decreases in gross margin percentage for ISG due to higher product costs and a shift in mix  due to strong CSG sales.  During the first nine months of Fiscal 2021 the decrease in our non-GAAP gross margin percentage

[0001571996-20-000051:mdna:123]
was attributable to decreases in gross margin percentage for ISG and CSG, as well as a decrease due to a shift in product mix due to strong CSG sales.

[0001571996-20-000051:mdna:124]
•Products — During the third quarter of Fiscal 2021, product gross margin decreased 4% to $3.6 billion, and product gross margin percentage decreased 100 basis points to 20.5%.  The decrease in product gross margin was primarily driven by higher product costs for ISG partially offset by an increase in gross margin for CSG and a decrease in amortization of intangible assets.  Product gross margin percentage decreased during the third quarter of Fiscal 2021 due to a shift in product mix due to strong CSG sales.  During the third quarter of Fiscal 2021, non-GAAP product gross margin decreased 7% to $4.0 billion, and non-GAAP product gross margin percentage decreased 180 basis points to 22.8% due to the same CSG and ISG dynamics discussed above.

[0001571996-20-000051:mdna:125]
During the first nine months of Fiscal 2021, product gross margin decreased 9% to $10.2 billion, and product gross margin percentage decreased 130 basis points to 20.4%.  The decreases in product gross margin and product gross margin percentage were primarily driven by higher product costs for ISG and a shift in product mix due to strong CSG sales.  These unfavorable impacts were partially offset by a decrease in amortization of intangibles.  During the first nine months of Fiscal 2021, non-GAAP product gross margin decreased 11% to $11.4 billion, and non-GAAP product gross margin percentage decreased 210 basis points to 22.7% due to the same CSG and ISG dynamics discussed above.

[0001571996-20-000051:mdna:126]
•Services — During the third quarter of Fiscal 2021, services gross margin increased 8% to $3.7 billion, and services gross margin percentage decreased 90 basis points to 60.3%.  Services gross margin increased due to growth in VMware software maintenance and CSG third-party software and maintenance, particularly subscription-based licenses, as well as a decrease in purchase accounting adjustments.  Excluding purchase accounting adjustments, transaction-related expenses, stock-based compensation expense, and other corporate expenses, non-GAAP services gross margin increased 8% to $3.8 billion during the third quarter of Fiscal 2021 primarily due to growth in VMware software maintenance and CSG third-party software and maintenance, and in particular, increases in subscription-based licenses.

[0001571996-20-000051:mdna:127]
During the third quarter of Fiscal 2021, services gross margin percentage decreased 90 basis points to 60.3% and non-GAAP services gross margin percentage decreased 60 basis points to 61.8%.  These decreases were driven by decreases in services gross margin percentage for CSG, partially offset by increases in services gross margin percentages for VMware and ISG.

[0001571996-20-000051:mdna:128]
During the first nine months of Fiscal 2021, services gross margin increased 11% to $11.1 billion due to growth in VMware software maintenance and CSG third-party software and maintenance, and in particular, increases in subscription-based licenses, as well as a decrease in purchase accounting adjustments.  Excluding purchase accounting adjustments, transaction-related expenses, stock-based compensation expense, and other corporate expenses, non-GAAP services gross margin increased 10% to $11.4 billion during the first nine months of Fiscal 2021 primarily due to growth in VMware software maintenance and CSG third-party software and maintenance,  particularly subscription-based licenses.

[0001571996-20-000051:mdna:129]
During the first nine months of Fiscal 2021, services gross margin percentage increased 30 basis points to 61.5% and non-GAAP services gross margin percentage increased 30 basis points to 62.7% primarily due to an increase in VMware services gross margin percentage.

[0001571996-20-000051:mdna:130]
[same as prior period, unchanged from 0001571996-20-000045:mdna:126]

[0001571996-20-000051:mdna:131]
[same as prior period, unchanged from 0001571996-20-000045:mdna:127]

[0001571996-20-000051:mdna:132]
79

[0001571996-20-000051:mdna:133]
The terms and conditions of our vendor rebate programs are largely based on product volumes and are generally negotiated either at the beginning of the annual or quarterly period, depending on the program.  The timing and amount of vendor rebates and other discounts we receive under the programs may vary from period to period, reflecting changes in the competitive environment.  We monitor our component costs and seek to address the effects of any changes to terms that might arise under our vendor rebate programs.  Our gross margins for the third quarter and first nine months of Fiscal 2021 and Fiscal 2020 were not materially affected by any changes to the terms of our vendor rebate programs, as the amounts we received under these programs were generally stable relative to our total net cost.  We are not aware of any significant changes to vendor pricing or rebate programs that may impact our results in the near term.

[0001571996-20-000051:mdna:134]
[same as prior period, unchanged from 0001571996-20-000045:mdna:130]

[0001571996-20-000051:mdna:135]
[same as prior period, unchanged from 0001571996-20-000045:mdna:131]

[0001571996-20-000051:mdna:136]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 30, 2020 |  |  |  | November 1, 2019 |  | October 30, 2020 |  |  |  | November 1, 2019 |
|  | Dollars |  | % ofNet Revenue |  | %Change |  | Dollars |  | % ofNet Revenue |  | Dollars |  | % ofNet Revenue |  | %Change |  | Dollars |  | % ofNet Revenue |
|  | (in millions, except percentages) |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling, general, and administrative | $ | 4,772 |  |  | 20.3 | % |  | (5) | % |  | $ | 5,028 |  |  | 22.0 | % |  | $ | 14,419 |  |  | 21.1 | % |  | (8) | % |  | $ | 15,677 |  |  | 23.0 | % |
| Research and development | 1,360 |  |  | 5.8 | % |  | 8 | % |  | 1,262 |  |  | 5.5 | % |  | 3,884 |  |  | 5.7 | % |  | 6 | % |  | 3,667 |  |  | 5.4 | % |
| Total operating expenses | $ | 6,132 |  |  | 26.1 | % |  | (3) | % |  | $ | 6,290 |  |  | 27.5 | % |  | $ | 18,303 |  |  | 26.8 | % |  | (5) | % |  | $ | 19,344 |  |  | 28.4 | % |
| Other Financial Information |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Non-GAAP operating expenses | $ | 5,046 |  |  | 21.4 | % |  | (5) | % |  | $ | 5,326 |  |  | 23.2 | % |  | $ | 15,218 |  |  | 22.3 | % |  | (4) | % |  | $ | 15,807 |  |  | 23.1 | % |

[0001571996-20-000051:mdna:137]
During the third quarter and first nine months of Fiscal 2021, total operating expenses decreased 3% and 5%, respectively, primarily due to a decrease in selling, general, and administrative expenses, offset partially by an increase in research and development expenses.  Our operating expenses include amortization of intangible assets, the impact of purchase accounting, transaction-related expenses, stock-based compensation expense, and other corporate expenses.  In aggregate, these items totaled $1.1 billion and $1.0 billion for the third quarter of Fiscal 2021 and Fiscal 2020, respectively, and $3.1 billion and $3.5 billion for the first nine months of Fiscal 2021 and Fiscal 2020, respectively.  Excluding these costs, total non-GAAP operating expenses decreased 5% and 4% for the third quarter and first nine months of Fiscal 2021, respectively.

[0001571996-20-000051:mdna:138]
•Selling, General, and Administrative — Selling, general, and administrative (“SG&A”) expenses decreased 5% and 8%, respectively, during the third quarter and first nine months of Fiscal 2021.  The decreases in SG&A expenses were primarily due to measures taken as a result of the COVID-19 pandemic, which included global hiring limitations, reduction in consulting and contractor costs, global travel restrictions, suspension of the Dell 401(k) match program for U.S. employees, and lower facilities-related costs, as well as to a decrease in amortization of intangible assets.  With respect to our cost reduction initiatives, we expect that some of the benefits which we recognized during the third quarter and first nine months of Fiscal 2021 will phase out over time.  These favorable impacts to SG&A expenses were partially offset by increases in stock-based compensation expense and severance costs during the third quarter and first nine months of Fiscal 2021.  Additionally, during the first nine months of Fiscal 2021, the decrease in SG&A expenses reflected the absence of Virtustream impairment charges of $619 million recognized in the first nine months of Fiscal 2020.

[0001571996-20-000051:mdna:139]
•Research and Development — Research and development (“R&D”) expenses are primarily composed of personnel-related expenses related to product development.  R&D expenses as a percentage of net revenue were approximately 5.8% and 5.5% for the third quarter of Fiscal 2021 and Fiscal 2020, respectively, and 5.7% and 5.4% for the first nine months of Fiscal 2021 and Fiscal 2020, respectively.  R&D expenses as a percentage of net revenue increased during the third quarter and first nine months of Fiscal 2021 primarily due to an increase in compensation-related expense, including stock-based compensation expense, driven by VMware.  As our industry continues to change and as the needs of our customers evolve, we intend to support R&D initiatives to innovate and introduce new and enhanced solutions into the market.

[0001571996-20-000051:mdna:140]
[same as prior period, unchanged from 0001571996-20-000045:mdna:136]

[0001571996-20-000051:mdna:141]
[same as prior period, unchanged from 0001571996-20-000045:mdna:137]

[0001571996-20-000051:mdna:142]
During the third quarter and first nine months of Fiscal 2021, our operating income increased 35% and 56%, respectively, primarily driven by lower selling, general, and administrative expenses as we realized the benefit of cost reduction initiatives.  During the third quarter of Fiscal 2021, operating income benefited from increases in operating income for CSG and VMware, and from a decrease in amortization of intangible assets.  These benefits were partially offset by a decrease in operating income for ISG and increases in stock-based compensation expense and severance costs.  During the first nine months of Fiscal 2021, the increase in operating income was primarily attributable to the absence of Virtustream impairment charges of $619 million recognized in the first nine months of Fiscal 2020.  Operating income during the first nine months of Fiscal 2021 also benefited from increases in operating income for VMware and other businesses and a decrease in amortization of intangible assets.  These benefits were partially offset by decreases in operating income for CSG and ISG and increases in stock-based compensation expense and severance costs.

[0001571996-20-000051:mdna:143]
Amortization of intangible assets, stock-based compensation expense, and other corporate expenses that impacted our operating income totaled $1.5 billion and $1.4 billion for the third quarter of Fiscal 2021 and Fiscal 2020, respectively, and $4.2 billion and $5.0 billion for the first nine months of Fiscal 2021 and Fiscal 2020, respectively.  Excluding these costs, and the impact of purchase accounting and transaction-related expenses, our non-GAAP operating income increased 12% to $2.7 billion and 2% to $7.5 billion during the third quarter and first nine months of Fiscal 2021, respectively.  Non-GAAP operating income increased 12% for the third quarter of Fiscal 2021 due to increases in operating income for CSG and VMware, which were partially offset by a decrease in operating income for ISG.  Non-GAAP operating income increased 2% during the first nine months of Fiscal 2021 due to increases in operating income for VMware and other businesses, which were partially offset by decreases in operating income for CSG and ISG.

[0001571996-20-000051:mdna:144]
[same as prior period, unchanged from 0001571996-20-000045:mdna:141]

[0001571996-20-000051:mdna:145]
[same as prior period, unchanged from 0001571996-20-000045:mdna:142]

[0001571996-20-000051:mdna:146]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 30, 2020 |  | November 1, 2019 |  | October 30, 2020 |  | November 1, 2019 |
|  | (in millions) |
| Interest and other, net: |  |  |  |  |  |  |  |
| Investment income, primarily interest | $ | 11 |  |  | $ | 41 |  |  | $ | 47 |  |  | $ | 127 |  |
| Gain on investments, net | 489 |  |  | 18 |  |  | 591 |  |  | 160 |  |
| Interest expense | (566) |  |  | (654) |  |  | (1,855) |  |  | (2,045) |  |
| Foreign exchange | (31) |  |  | (43) |  |  | (130) |  |  | (123) |  |
| Other | 370 |  |  | (39) |  |  | 418 |  |  | (119) |  |
| Total interest and other, net | $ | 273 |  |  | $ | (677) |  |  | $ | (929) |  |  | $ | (2,000) |  |

[0001571996-20-000051:mdna:147]
During the third quarter and first nine months of Fiscal 2021, the change in interest and other, net was favorable by $950 million and $1,071 million, respectively, primarily driven by a $465 million gain on the fair value adjustment of one of our strategic investments, a pre-tax gain of $338 million on the sale of RSA Security reflected in Other in the table above, and a decrease in interest expense due to debt paydown over the periods.  During the first nine months of Fiscal 2021, interest and other, net also benefited from a gain of $120 million recognized from the sale of certain intellectual property assets during the first quarter of Fiscal 2021.

[0001571996-20-000051:mdna:148]
[same as prior period, unchanged from 0001571996-20-000045:mdna:145]

[0001571996-20-000051:mdna:149]
For the third quarter of Fiscal 2021 and Fiscal 2020, our effective income tax rates were 37.2% on pre-tax income of $1.4 billion and -247.2% on pre-tax income of $159 million, respectively.  For the first nine months of Fiscal 2021 and Fiscal 2020, our effective income tax rates were -6.1% on pre-tax income of $2.0 billion and 5482.1% on pre-tax losses of $95 million, respectively.  The changes in our effective income tax rates were primarily driven by discrete tax items and changes in our jurisdictional mix of income.

[0001571996-20-000051:mdna:150]
For the third quarter and first nine months of Fiscal 2021, our effective income tax rates include a discrete tax expense of $359 million related to the divestiture of RSA Security during the period.  Our effective income tax rate for the first nine months of Fiscal 2021 also includes discrete tax benefits of $746 million related to an audit settlement and $59 million from an intra-entity asset transfer of certain of Pivotal’s intellectual property to an Irish subsidiary that was completed by VMware, Inc.  For the first nine months of Fiscal 2020, our effective income tax rate includes discrete tax benefits of $4.9 billion related to similar intra-entity asset transfers.  The tax benefit for each intra-entity asset transfer was recorded as a deferred tax asset in the period of the transaction and represents the book and tax basis difference on the transferred assets measured based on the applicable Irish statutory tax rate.  We expect to be able to realize the deferred tax assets resulting from these intra-entity asset transfers.  Our effective income tax rates for the third quarter and first nine months of Fiscal 2020 also include discrete tax benefits of $305 million related to an audit settlement.

[0001571996-20-000051:mdna:151]
Our effective income tax rate can fluctuate depending on the geographic distribution of our worldwide earnings, as our foreign earnings are generally taxed at lower rates than in the United States.  The differences between our effective income tax rate and the U.S. federal statutory rate of 21% principally result from the geographical distribution of income, differences between the book and tax treatment of certain items, and the discrete tax items discussed above.  In certain jurisdictions, our tax rate is significantly less than the applicable statutory rate as a result of tax holidays.  The majority of our foreign income that is subject to these tax holidays and lower tax rates is attributable to Singapore, China, and Malaysia.  A significant portion of these income tax benefits relates to a tax holiday that will be effective until January 31, 2029.  Our other tax holidays will expire in whole or in part during Fiscal 2022 through Fiscal 2030.  Many of these tax holidays and reduced tax rates may be extended when certain conditions are met or may be terminated early if certain conditions are not met.  As of October 30, 2020, we were not aware of any matters of non-compliance related to these tax holidays.  The effective income tax rate for future quarters of Fiscal 2021 may be impacted by the actual mix of jurisdictions in which income is generated.

[0001571996-20-000051:mdna:152]
[same as prior period, unchanged from 0001571996-20-000045:mdna:149]

[0001571996-20-000051:mdna:153]
[same as prior period, unchanged from 0001571996-20-000045:mdna:150]

[0001571996-20-000051:mdna:154]
During the third quarter and first nine months of Fiscal 2021, net income increased 60% to $0.9 billion and decreased 58% to $2.2 billion, respectively.  The increase in net income during the third quarter of Fiscal 2021 was primarily due to net gains recognized in interest and other, net, and an increase in income taxes.  The decrease in net income during the first nine months of Fiscal 2021 was primarily due to lower discrete tax benefits, which were partially offset by an increase in operating income.

[0001571996-20-000051:mdna:155]
Net income includes amortization of intangible assets, the impact of purchase accounting, transaction-related expenses, stock-based compensation expense, other corporate expenses, fair value adjustments on equity investments, and discrete tax items.  Excluding these costs and the related tax impacts, non-GAAP net income increased 18% to $1.7 billion and 2% to $4.5 billion during the third quarter and first nine months of Fiscal 2021, respectively.  The increases in non-GAAP net income during the third quarter and first nine months of Fiscal 2021 were primarily attributable to increases in non-GAAP operating income and increases in non-GAAP income taxes.

[0001571996-20-000051:mdna:156]
82

[0001571996-20-000051:mdna:157]
[same as prior period, unchanged from 0001571996-20-000045:mdna:153]

[0001571996-20-000051:mdna:158]
During the third quarter and first nine months of Fiscal 2021, net income attributable to non-controlling interests was $49 million and $139 million, respectively, and consisted of net income or loss attributable to our non-controlling interests in VMware, Inc. and Secureworks.  During the third quarter and first nine months of Fiscal 2020, net income attributable to non-controlling interests was $53 million and $905 million, respectively, and consisted of net income or loss attributable to our non-controlling interests in VMware, Inc., Secureworks, and Pivotal.  Pivotal was acquired by VMware, Inc. on December 30, 2019 and, as a result, we no longer have a separate non-controlling interest in Pivotal.  The decreases in net income attributable to non-controlling interests during the third quarter and first nine months of Fiscal 2021 were attributable to decreases in net income attributable to our non-controlling interest in VMware, Inc.  For more information about our non-controlling interests, see Note 13 of the Notes to the Condensed Consolidated Financial Statements included in this report.

[0001571996-20-000051:mdna:159]
[same as prior period, unchanged from 0001571996-20-000045:mdna:155]

[0001571996-20-000051:mdna:160]
Net income attributable to Dell Technologies Inc. represents net income and an adjustment for non-controlling interests.  During the third quarter and first nine months of Fiscal 2021, net income attributable to Dell Technologies Inc. was $0.8 billion and $2.0 billion, respectively.  During the third quarter and first nine months of Fiscal 2020, net income attributable to Dell Technologies Inc. was $0.5 billion and $4.2 billion, respectively.  The increase in net income attributable to Dell Technologies Inc. during the third quarter of Fiscal 2021 was primarily attributable to an increase in net income for the period.  During the first nine months of Fiscal 2021, the decrease in net income attributable to Dell Technologies Inc. was primarily attributable to a decrease in net income for the period.

[0001571996-20-000051:mdna:161]
[same as prior period, unchanged from 0001571996-20-000045:mdna:157]

[0001571996-20-000051:mdna:162]
[same as prior period, unchanged from 0001571996-20-000045:mdna:158]

[0001571996-20-000051:mdna:163]
[same as prior period, unchanged from 0001571996-20-000045:mdna:159]

[0001571996-20-000051:mdna:164]
[same as prior period, unchanged from 0001571996-20-000045:mdna:160]

[0001571996-20-000051:mdna:165]
[same as prior period, unchanged from 0001571996-20-000045:mdna:161]

[0001571996-20-000051:mdna:166]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 30, 2020 |  | % Change |  | November 1, 2019 |  | October 30, 2020 |  | % Change |  | November 1, 2019 |
|  | (in millions, except percentages) |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Servers and networking | $ | 4,164 |  |  | (2) | % |  | $ | 4,241 |  | $ | 12,118 |  | (6) | % |  | $ | 12,858 |
| Storage | 3,860 |  |  | (7) | % |  | 4,149 |  | 11,682 |  | (5) | % |  | 12,355 |
| Total ISG net revenue | $ | 8,024 |  |  | (4) | % |  | $ | 8,390 |  | $ | 23,800 |  | (6) | % |  | $ | 25,213 |
| Operating income: |  |  |  |  |  |  |  |  |  |  |  |
| ISG operating income | $ | 882 |  |  | (11) | % |  | $ | 996 |  | $ | 2,587 |  | (10) | % |  | $ | 2,889 |
| % of segment net revenue | 11.0 | % |  |  |  | 11.9 | % |  | 10.9 | % |  |  |  | 11.5 | % |

[0001571996-20-000051:mdna:167]
Net Revenue — During the third quarter and first nine months of Fiscal 2021, ISG net revenue decreased 4% and 6%, respectively, due to decreases in sales of servers and networking and storage.  ISG net revenue decreased primarily due to a weaker demand environment, as customers restricted technology spending and directed their investments toward remote work and business continuity solutions.

[0001571996-20-000051:mdna:168]
Revenue from the sales of servers and networking decreased 2% and 6% during the third quarter and first nine months of Fiscal 2021, respectively, primarily driven by declines in units sold of our PowerEdge servers due to the broader macro-economic environment, including the effects of COVID-19.  During the third quarter of Fiscal 2021, the decline in volume was largely offset by improvement in average selling prices for servers.  During the first nine months of Fiscal 2021, servers and networking revenue was impacted by an overall decrease in average selling prices for servers resulting from competitive pressures in certain geographies in the first half of Fiscal 2021.  Storage revenue decreased 7% and 5% during the third quarter and first nine months of Fiscal 2021, respectively, primarily due to declines in demand for our core storage solutions offerings, partially offset by increased demand for hyperconverged infrastructure solutions.  We continue to make enhancements to our storage solutions offerings and expect that these offerings, including our new PowerStore storage array released in May 2020, will drive long-term improvements in the business.

[0001571996-20-000051:mdna:169]
[same as prior period, unchanged from 0001571996-20-000045:mdna:165]

[0001571996-20-000051:mdna:170]
From a geographical perspective, net revenue attributable to ISG decreased in all regions during both the third quarter and first nine months of Fiscal 2021, driven by a weaker demand environment as a result of pervasive global COVID-19 disruptions.

[0001571996-20-000051:mdna:171]
Operating Income — During the third quarter of Fiscal 2021, ISG operating income as a percentage of net revenue decreased 90 basis points to 11.0%.  During the first nine months of Fiscal 2021, ISG operating income as a percentage of net revenue decreased 60 basis points to 10.9%.  The declines in operating income percentages during the third quarter and first nine months of Fiscal 2021 were driven by declines in gross margin percentages for servers and networking, which were attributable to commodity inflation and competitive pricing dynamics.  The declines in ISG gross margin percentage during the third quarter

[0001571996-20-000051:mdna:172]
[same as prior period, unchanged from 0001571996-20-000045:mdna:168]

[0001571996-20-000051:mdna:173]
and first nine months of Fiscal 2021 were partially offset by decreases in operating expenses as a percentage of net revenue, as we realized the benefit of cost reduction initiatives.

[0001571996-20-000051:mdna:174]
[same as prior period, unchanged from 0001571996-20-000045:mdna:170]

[0001571996-20-000051:mdna:175]
[same as prior period, unchanged from 0001571996-20-000045:mdna:171]

[0001571996-20-000051:mdna:176]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 30, 2020 |  | % Change |  | November 1, 2019 |  | October 30, 2020 |  | % Change |  | November 1, 2019 |
|  | (in millions, except percentages) |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Commercial | $ | 8,783 |  |  | 5 | % |  | $ | 8,330 |  |  | $ | 25,456 |  |  | (1) | % |  | $ | 25,714 |  |
| Consumer | 3,503 |  |  | 14 | % |  | 3,080 |  |  | 9,137 |  |  | 9 | % |  | 8,354 |  |
| Total CSG net revenue | $ | 12,286 |  |  | 8 | % |  | $ | 11,410 |  |  | $ | 34,593 |  |  | 2 | % |  | $ | 34,068 |  |
| Operating income: |  |  |  |  |  |  |  |  |  |  |  |
| CSG operating income | $ | 1,002 |  |  | 36 | % |  | $ | 739 |  |  | $ | 2,309 |  |  | (8) | % |  | $ | 2,514 |  |
| % of segment net revenue | 8.2 | % |  |  |  | 6.5 | % |  | 6.7 | % |  |  |  | 7.4 | % |

[0001571996-20-000051:mdna:177]
Net Revenue — During the third quarter and first nine months of Fiscal 2021, CSG net revenue increased 8% and 2%, respectively, primarily due to increases in commercial and consumer notebook sales, partially offset by decreases in commercial desktop sales.  Much of this demand was driven by the imperative for remote work and remote learning solutions, as business, government, and education customers sought to maintain productivity in the midst of COVID-19.

[0001571996-20-000051:mdna:178]
Commercial revenue increased 5% during the third quarter of Fiscal 2021, primarily due to increased demand for commercial notebooks, and particularly for entry-level commercial notebooks, driven by customers in education and state and local government.  The increase in demand for commercial notebooks was partially offset by lower demand for commercial desktops during the third quarter of Fiscal 2021.  Commercial revenue decreased 1% during the first nine months of Fiscal 2020 primarily due to lower demand for commercial desktops, the effects of which were largely offset by an increase in demand for entry-level commercial notebooks, driven by customers in education and state and local government.

[0001571996-20-000051:mdna:179]
Consumer revenue increased 14% and 9% during the third quarter and first nine months of Fiscal 2021, respectively, due to continued strong demand for consumer notebooks and high-end and gaming systems, coupled with an increase in average selling prices for our higher-priced consumer notebooks.

[0001571996-20-000051:mdna:180]
From a geographical perspective, net revenue attributable to CSG increased in the Americas and EMEA during both the third quarter and first nine months of Fiscal 2021.  These increases were partially offset by declines in net revenue attributable to CSG in APJ during the periods.

[0001571996-20-000051:mdna:181]
Operating Income — During the third quarter of Fiscal 2021, CSG operating income as a percentage of net revenue increased 170 basis points to 8.2% primarily due to a decrease in operating expenses as a percentage of revenue, as we realized the benefit of cost reduction initiatives, and to a lesser extent, an increase in CSG gross margin percentage driven by consumer pricing favorability.  During the first nine months of Fiscal 2021, CSG operating income as a percentage of net revenue decreased 70 basis points to 6.7%.  This decrease was primarily attributable to a decrease in CSG gross margin percentage driven by a shift in product mix to entry-level commercial notebooks and lower component cost deflation relative to pricing.  The decrease in CSG gross margin percentage was partially offset by a decrease in operating expenses as a percentage of revenue, as we realized the benefit of cost reduction initiatives.

[0001571996-20-000051:mdna:182]
[same as prior period, unchanged from 0001571996-20-000045:mdna:179]

[0001571996-20-000051:mdna:183]
[same as prior period, unchanged from 0001571996-20-000045:mdna:180]

[0001571996-20-000051:mdna:184]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 30, 2020 |  | % Change |  | November 1, 2019 |  | October 30, 2020 |  | % Change |  | November 1, 2019 |
|  | (in millions, except percentages) |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |
| VMware net revenue | $ | 2,893 |  |  | 8 | % |  | $ | 2,671 |  |  | $ | 8,556 |  |  | 10 | % |  | $ | 7,779 |  |
| Operating income: |  |  |  |  |  |  |  |  |  |  |  |
| VMware operating income | $ | 837 |  |  | 18 | % |  | $ | 709 |  |  | $ | 2,504 |  |  | 22 | % |  | $ | 2,055 |  |
| % of segment net revenue | 28.9 | % |  |  |  | 26.5 | % |  | 29.3 | % |  |  |  | 26.4 | % |

[0001571996-20-000051:mdna:185]
Net Revenue — VMware net revenue, inclusive of Pivotal, primarily consists of revenue from the sale of software licenses under perpetual licenses and subscription and software-as-a-service (“SaaS”) offerings, as well as related software maintenance services, support, training, consulting services, and hosted services.  VMware net revenue for the third quarter and first nine months of Fiscal 2021 increased 8% and 10%, respectively, primarily due to growth in sales of subscriptions and SaaS offerings, as well as an increase in sales of software maintenance services.  Growth in sales of subscriptions and SaaS offerings was primarily driven by increased demand for hybrid cloud offerings and digital workspaces.  Software maintenance revenue benefited from maintenance contracts sold in previous periods.

[0001571996-20-000051:mdna:186]
From a geographical perspective, approximately half of VMware net revenue during the third quarter and first nine months of Fiscal 2021 was generated by sales to customers in the United States.  VMware net revenue for the third quarter and first nine months of Fiscal 2021 increased in both the United States and internationally.

[0001571996-20-000051:mdna:187]
Operating Income — During the third quarter and first nine months of Fiscal 2021, VMware operating income as a percentage of net revenue increased 240 basis points to 28.9% and 290 basis points to 29.3%, respectively.  The increases were primarily driven by decreases in selling, general, and administrative expenses as a percentage of net revenue as we benefited from decreased travel-related costs resulting from travel restrictions imposed in response to the COVID-19 pandemic.  While the COVID-19 pandemic has not had a significant adverse financial impact on VMware operations to date, there continues to be significant uncertainty regarding the economic effects of the COVID-19 pandemic and the extent to which it may have a negative impact on VMware’s sales and results of operations for the remainder of Fiscal 2021 and into Fiscal 2022.

[0001571996-20-000051:mdna:188]
[same as prior period, unchanged from 0001571996-20-000045:mdna:185]

[0001571996-20-000051:mdna:189]
[same as prior period, unchanged from 0001571996-20-000045:mdna:186]

[0001571996-20-000051:mdna:190]
[same as prior period, unchanged from 0001571996-20-000045:mdna:187]

[0001571996-20-000051:mdna:191]
We sell products and services directly to customers and through a variety of sales channels, including retail distribution.  Our accounts receivable, net, was $11.4 billion and $12.5 billion as of October 30, 2020 and January 31, 2020, respectively.  We maintain an allowance for expected credit losses to cover receivables that may be deemed uncollectible.  The allowance for expected credit losses is an estimate based on an analysis of historical loss experience, current receivables aging, and management’s assessment of current conditions and reasonable and supportable expectation of future conditions, as well as specific identifiable customer accounts that are deemed at risk.  Our analysis includes assumptions regarding the impact of COVID-19 and continued market volatility, which is highly uncertain and subject to significant judgment.  Given this uncertainty, our allowance for expected credit losses in future periods may vary from our current estimates.  As of October 30, 2020 and January 31, 2020, the allowance for expected credit losses was $115 million and $94 million, respectively.  Allowance for expected credit losses of trade receivables as of October 30, 2020 includes the impact of adoption of the new current expected credit losses (“CECL”) standard, which was adopted as of February 1, 2020 using the modified retrospective method.  Based on our assessment, we believe that we are adequately reserved for expected credit losses.  We will continue to monitor the aging of our accounts receivable and take actions, where necessary, to reduce our exposure to credit losses.

[0001571996-20-000051:mdna:192]
[same as prior period, unchanged from 0001571996-20-000045:mdna:189]

[0001571996-20-000051:mdna:193]
Dell Financial Services and its affiliates (“DFS”) support Dell Technologies by offering and arranging various financing options and services for our customers globally, including through captive financing operations in North America, Europe, Australia, and New Zealand.  DFS originates, collects, and services customer receivables primarily related to the purchase of our product, software, and service solutions.  DFS further strengthens our customer relationships through its flexible consumption models, which enable us to offer our customers the option to pay over time and, in certain cases, based on utilization, to provide them with financial flexibility to meet their changing technological requirements.  New financing originations were $2.1 billion and $2.0 billion for the third quarter of Fiscal 2021 and Fiscal 2020, respectively, and $6.5 billion and $5.7 billion for the first nine months of Fiscal 2021 and Fiscal 2020, respectively.

[0001571996-20-000051:mdna:194]
[same as prior period, unchanged from 0001571996-20-000045:mdna:191]

[0001571996-20-000051:mdna:195]
As of October 30, 2020 and January 31, 2020, our financing receivables, net were $10.2 billion and $9.7 billion, respectively.  We maintain an allowance to cover expected financing receivable credit losses and evaluate credit loss expectations based on our total portfolio.  Allowance for expected credit losses of financing receivables as of October 30, 2020 includes the impact of adoption of the CECL standard referred to above.  Our analysis includes assumptions regarding the impact of COVID-19 and continued market volatility, which is highly uncertain and subject to significant judgment.  Given this uncertainty, our allowance for expected credit losses in future periods may vary from our current estimates.  For the third quarter of Fiscal 2021 and Fiscal 2020, the principal charge-off rate for our financing receivables portfolio was 0.7% and 0.9%, respectively.  For the first nine months of Fiscal 2021 and Fiscal 2020, the principal charge-off rate for our financing receivables portfolio was 0.9% and 1.0%, respectively.  The credit quality of our financing receivables has improved in recent years due to an overall improvement in the credit environment and as the mix of high-quality commercial accounts in our portfolio has continued to increase.  We continue to monitor broader economic indicators and their potential impact on future loss performance.  We have an extensive process to manage our exposure to customer credit risk, including active management of credit lines and our collection activities.  We also sell selected fixed-term financing receivables without recourse to unrelated third parties on a periodic basis, primarily to manage certain concentrations of customer credit exposure.  Based on our assessment of the customer financing receivables, we believe that we are adequately reserved.

[0001571996-20-000051:mdna:196]
We retain a residual interest in equipment leased under our lease programs.  As of October 30, 2020 and January 31, 2020, the residual interest recorded as part of financing receivables was $472 million and $582 million, respectively.  The amount of the residual interest is established at the inception of the lease based upon estimates of the value of the equipment at the end of the lease term using historical studies, industry data, and future value-at-risk demand valuation methods.  On a quarterly basis, we assess the carrying amount of our recorded residual values for impairment.  Generally, residual value risk on equipment under lease is not considered to be significant, because of the existence of a secondary market with respect to the equipment.  The lease agreement also clearly defines applicable return conditions and remedies for non-compliance, to ensure that the leased equipment will be in good operating condition upon return.  Model changes and updates, as well as market strength and product acceptance, are monitored and adjustments are made to residual values in accordance with the significance of any such changes.  Our remarketing sales staff works closely with customers and dealers to manage the sale of lease returns and the recovery of residual exposure.  No impairment losses were recorded related to residual assets during the third quarter and first nine months of Fiscal 2021 and Fiscal 2020.

[0001571996-20-000051:mdna:197]
As of October 30, 2020 and January 31, 2020, equipment under operating leases, net was $1.3 billion and $0.8 billion, respectively.  Based on triggering events, we assess the carrying amount of the equipment under operating leases recorded for impairment.  No material impairment losses were recorded related to such equipment during the third quarter and first nine months of Fiscal 2021 and Fiscal 2020.

[0001571996-20-000051:mdna:198]
[same as prior period, unchanged from 0001571996-20-000045:mdna:195]

[0001571996-20-000051:mdna:199]
[same as prior period, unchanged from 0001571996-20-000045:mdna:196]

[0001571996-20-000051:mdna:200]
[same as prior period, unchanged from 0001571996-20-000045:mdna:197]

[0001571996-20-000051:mdna:201]
As of October 30, 2020, we had no off-balance sheet arrangements that have or are reasonably likely to have a current or future material effect on our financial condition or results of operations.

[0001571996-20-000051:mdna:202]
[same as prior period, unchanged from 0001571996-20-000045:mdna:199]

[0001571996-20-000051:mdna:203]
[same as prior period, unchanged from 0001571996-20-000045:mdna:200]

[0001571996-20-000051:mdna:204]
[same as prior period, unchanged from 0001571996-20-000045:mdna:201]

[0001571996-20-000051:mdna:205]
[same as prior period, unchanged from 0001571996-20-000045:mdna:202]

[0001571996-20-000051:mdna:206]
[same as prior period, unchanged from 0001571996-20-000045:mdna:203]

[0001571996-20-000051:mdna:207]
[same as prior period, unchanged from 0001571996-20-000045:mdna:204]

[0001571996-20-000051:mdna:208]
[same as prior period, unchanged from 0001571996-20-000045:mdna:205]

[0001571996-20-000051:mdna:209]
[same as prior period, unchanged from 0001571996-20-000045:mdna:206]

[0001571996-20-000051:mdna:210]
[same as prior period, unchanged from 0001571996-20-000045:mdna:207]

[0001571996-20-000051:mdna:211]
[same as prior period, unchanged from 0001571996-20-000045:mdna:208]

[0001571996-20-000051:mdna:212]
[same as prior period, unchanged from 0001571996-20-000045:mdna:209]

[0001571996-20-000051:mdna:213]
|  | October 30, 2020 |  | January 31, 2020 |
|  | (in millions) |
| Cash and cash equivalents, and available borrowings: |  |  |  |
| Cash and cash equivalents (a) | $ | 11,304 |  |  | $ | 9,302 |  |
| Remaining available borrowings under revolving credit facilities (b) | 5,466 |  |  | 5,972 |  |
| Total cash, cash equivalents, and available borrowings | $ | 16,770 |  |  | $ | 15,274 |  |

[0001571996-20-000051:mdna:214]
[same as prior period, unchanged from 0001571996-20-000045:mdna:211]

[0001571996-20-000051:mdna:215]
(a)    Of the $11.3 billion of cash and cash equivalents as of October 30, 2020, $3.9 billion was held by VMware, Inc.

[0001571996-20-000051:mdna:216]
(b)    Of the $5.5 billion of remaining available borrowings under revolving credit facilities, $1.0 billion was attributable to the VMware Revolving Credit Facility.

[0001571996-20-000051:mdna:217]
Our revolving credit facilities as of October 30, 2020 include the Revolving Credit Facility, which we entered into on May 25, 2020.  The Revolving Credit Facility has a maximum aggregate borrowing capacity of $4.5 billion, and available borrowings under this facility are reduced by draws on the facility and outstanding letters of credit.  As of October 30, 2020, there were no

[0001571996-20-000051:mdna:218]
borrowings outstanding under the facility and remaining available borrowings totaled approximately $4.5 billion.  We may regularly use our available borrowings from our Revolving Credit Facility on a short-term basis for general corporate purposes.

[0001571996-20-000051:mdna:219]
The VMware Revolving Credit Facility has a maximum capacity of $1.0 billion.  As of October 30, 2020, $1.0 billion was available under the VMware Revolving Credit Facility.  None of the net proceeds of borrowings under the VMware Revolving Credit Facility will be made available to support the operations or satisfy any corporate purposes of Dell Technologies, other than the operations and corporate purposes of VMware, Inc. and VMware, Inc.’s subsidiaries.

[0001571996-20-000051:mdna:220]
[same as prior period, unchanged from 0001571996-20-000045:mdna:217]

[0001571996-20-000051:mdna:221]
[same as prior period, unchanged from 0001571996-20-000045:mdna:218]

[0001571996-20-000051:mdna:222]
[same as prior period, unchanged from 0001571996-20-000045:mdna:219]

[0001571996-20-000051:mdna:223]
[same as prior period, unchanged from 0001571996-20-000045:mdna:220]

[0001571996-20-000051:mdna:224]
|  | October 30, 2020 |  | Increase (decrease) |  | January 31, 2020 |
|  | (in millions) |
| Core debt |  |  |  |  |  |
| Senior Secured Credit Facilities and First Lien Notes | $ | 27,186 |  |  | $ | (2,478) |  |  | $ | 29,664 |  |
| Unsecured Notes and Debentures | 1,352 |  |  | — |  |  | 1,352 |  |
| Senior Notes | 2,700 |  |  | — |  |  | 2,700 |  |
| EMC Notes | 1,000 |  |  | (600) |  |  | 1,600 |  |
| DFS allocated debt | (870) |  |  | 625 |  |  | (1,495) |  |
| Total core debt | 31,368 |  |  | (2,453) |  |  | 33,821 |  |
| DFS related debt |  |  |  |  |  |
| DFS debt | 9,201 |  |  | 1,436 |  |  | 7,765 |  |
| DFS allocated debt | 870 |  |  | (625) |  |  | 1,495 |  |
| Total DFS related debt | 10,071 |  |  | 811 |  |  | 9,260 |  |
| Margin Loan Facility and other | 4,167 |  |  | 143 |  |  | 4,024 |  |
| Debt of public subsidiary |  |  |  |  |  |
| VMware Notes | 4,750 |  |  | 750 |  |  | 4,000 |  |
| VMware Term Loan Facility | — |  |  | (1,500) |  |  | 1,500 |  |
| Other | 55 |  |  | (5) |  |  | 60 |  |
| Total public subsidiary debt | 4,805 |  |  | (755) |  |  | 5,560 |  |
| Total debt, principal amount | 50,411 |  |  | (2,254) |  |  | 52,665 |  |
| Carrying value adjustments | (550) |  |  | 59 |  |  | (609) |  |
| Total debt, carrying value | $ | 49,861 |  |  | $ | (2,195) |  |  | $ | 52,056 |  |

[0001571996-20-000051:mdna:225]
During the first nine months of Fiscal 2021, the outstanding principal amount of our debt decreased by $2.3 billion to $50.4 billion as of October 30, 2020, primarily driven by net repayments of core debt and VMware, Inc. debt, partially offset by a net increase in DFS debt.

[0001571996-20-000051:mdna:226]
We define core debt as the total principal amount of our debt, less DFS related debt, our Margin Loan Facility and other debt, and public subsidiary debt.  Our core debt was $31.4 billion as of October 30, 2020.  During the first nine months of Fiscal 2021, the decrease in our core debt was driven by principal repayments.  Proceeds of $2.082 billion from the sale of RSA Security were used to pay down core debt.  Principal repayments included the retirement in full of $4.5 billion principal amount

[0001571996-20-000051:mdna:227]
of 4.42% First Lien Notes due June 2021, repayment of $600 million principal amount of 2.650% EMC Notes due June 2020 upon maturity, and repayment of approximately $229 million of term loan facilities.  These repayments were partially offset by the issuance of multiple series of First Lien Notes in an aggregate principal amount of $2.25 billion on April 9, 2020.  See Note 6 of the Notes to the Condensed Consolidated Financial Statements included in this report for more information about our debt.

[0001571996-20-000051:mdna:228]
There are no scheduled maturities of core debt for the remainder Fiscal 2021, although we intend to continue making core debt principal payments as part of our overall capital allocation strategy.

[0001571996-20-000051:mdna:229]
During the first nine months of Fiscal 2021, we issued an additional $1.4 billion, net, in DFS debt to support the expansion of our financing receivables portfolio, which includes the issuance of 500 million Euro of senior unsecured eurobonds on June 24, 2020.  DFS related debt primarily represents debt from our securitization and structured financing programs.  The majority of DFS debt is non-recourse to Dell Technologies and represents borrowings under securitization programs and structured financing programs, for which our risk of loss is limited to transferred lease and loan payments and associated equipment, and under which the credit holders have no recourse to Dell Technologies.

[0001571996-20-000051:mdna:230]
[same as prior period, unchanged from 0001571996-20-000045:mdna:228]

[0001571996-20-000051:mdna:231]
As of October 30, 2020, margin loan and other debt primarily consisted of the $4.0 billion Margin Loan Facility.

[0001571996-20-000051:mdna:232]
Debt of public subsidiary represents VMware, Inc. indebtedness.  The decrease in debt of public subsidiary during the first nine months of Fiscal 2021 was due to principal repayments by VMware, Inc. of $1.25 billion principal amount of its 2.30% Notes due August 2020 and $1.5 billion principal amount of the VMware Term Loan Facility.  These repayments were partially offset by the issuance of VMware Notes in an aggregate principal amount of $2.0 billion on April 7, 2020.  See Note 6 of the Notes to the Condensed Consolidated Financial Statements included in this report for more information about VMware, Inc. debt.

[0001571996-20-000051:mdna:233]
[same as prior period, unchanged from 0001571996-20-000045:mdna:231]

[0001571996-20-000051:mdna:234]
[same as prior period, unchanged from 0001571996-20-000045:mdna:232]

[0001571996-20-000051:mdna:235]
[same as prior period, unchanged from 0001571996-20-000045:mdna:233]

[0001571996-20-000051:mdna:236]
91

[0001571996-20-000051:mdna:237]
[same as prior period, unchanged from 0001571996-20-000045:mdna:234]

[0001571996-20-000051:mdna:238]
[same as prior period, unchanged from 0001571996-20-000045:mdna:235]

[0001571996-20-000051:mdna:239]
|  | Nine Months Ended |
|  | October 30, 2020 |  | November 1, 2019 |
|  | (in millions) |
| Net change in cash from: |  |  |  |
| Operating activities | $ | 5,530 |  |  | $ | 5,783 |  |
| Investing activities | 26 |  |  | (3,982) |  |
| Financing activities | (3,483) |  |  | (2,600) |  |
| Effect of exchange rate changes on cash, cash equivalents, and restricted cash | (67) |  |  | (100) |  |
| Change in cash, cash equivalents, and restricted cash | $ | 2,006 |  |  | $ | (899) |  |

[0001571996-20-000051:mdna:240]
Operating Activities — Cash provided by operating activities was $5.5 billion for the first nine months of Fiscal 2021 compared to $5.8 billion for the first nine months of Fiscal 2020.  Operating cash flows declined slightly during the first nine months of Fiscal 2021 as the strong profitability during the period was offset by unfavorable working capital impacts of an increase in inventory, decline in growth rate of deferred revenue, and timing of purchases and payments to vendors.  COVID-19 impacts to working capital continued to normalize during the third quarter of Fiscal 2021.

[0001571996-20-000051:mdna:241]
DFS offerings are initially funded through cash on hand at the time of origination, most of which is subsequently replaced with third-party financing.  For DFS offerings which qualify as sales-type leases, the initial funding of financing receivables is reflected as an impact to cash flows from operations, and is largely subsequently offset by cash proceeds from financing.  For DFS operating leases, which have increased under the current leasing standard, the initial funding is classified as a capital expenditure and reflected as cash flows used in investing activities.  DFS new financing originations were $6.5 billion and $5.7 billion during the first nine months of Fiscal 2021 and Fiscal 2020, respectively.  As of October 30, 2020, DFS had $10.2 billion of total net financing receivables and $1.3 billion of equipment under DFS operating leases, net.

[0001571996-20-000051:mdna:242]
Investing Activities — Investing activities primarily consist of cash used to fund capital expenditures for property, plant, and equipment, which includes equipment under DFS operating leases, capitalized software development costs, strategic investments, and the maturities, sales, and purchases of investments.  During the first nine months of Fiscal 2021, cash provided by investing activities was $26 million and was primarily driven by net cash proceeds from the divestiture of RSA Security during the the third quarter of Fiscal 2021, largely offset by capital expenditures and acquisitions of businesses.  In comparison, cash used in investing activities was $4.0 billion during the first nine months of Fiscal 2020 and was primarily driven by capital expenditures and acquisition of businesses, which were partially offset by net cash proceeds from the net sales of strategic investments.

[0001571996-20-000051:mdna:243]
Financing Activities — Financing activities primarily consist of the proceeds and repayments of debt, cash used to repurchase common stock, and proceeds from the issuance of common stock.  Cash used in financing activities of $3.5 billion during the first nine months of Fiscal 2021 primarily consisted of debt repayments and repurchases of common stock by our public subsidiaries, partially offset by cash proceeds from the issuances of multiple series of First Lien Notes and VMware Notes.  In comparison, cash used in financing activities of $2.6 billion during the first nine months of Fiscal 2020 primarily consisted of repayments of debt and repurchases of common stock by our public subsidiaries.

[0001571996-20-000051:mdna:244]
[same as prior period, unchanged from 0001571996-20-000045:mdna:241]

[0001571996-20-000051:mdna:245]
Capital Expenditures — During the first nine months of Fiscal 2021 and Fiscal 2020, we spent $1.4 billion and $1.6 billion, respectively, on property, plant, and equipment.  These expenditures were incurred in connection with our global expansion efforts and infrastructure investments made to support future growth, and the funding of equipment under DFS operating leases.  During the first nine months of Fiscal 2021 and Fiscal 2020, funding of gross equipment under DFS operating leases was $0.6 billion and $0.7 billion, respectively.  Product demand, product mix, and the use of contract manufacturers, as well as ongoing investments in operating and information technology infrastructure, influence the level and prioritization of our capital expenditures.  Aggregate capital expenditures for Fiscal 2021 are currently expected to be approximately $1.9 billion, of which approximately $0.8 billion is expected for equipment under DFS operating leases.

[0001571996-20-000051:mdna:246]
[same as prior period, unchanged from 0001571996-20-000045:mdna:243]

[0001571996-20-000051:mdna:247]
[same as prior period, unchanged from 0001571996-20-000045:mdna:244]

[0001571996-20-000051:mdna:248]
[same as prior period, unchanged from 0001571996-20-000045:mdna:245]
