# DELL 8-K — 0001571996-20-000048 filed 2020-11-24

## item codes, every 8-K on or before 2020-12-07

- 2020-11-24 0001571996-20-000048 — 2.02, 9.01
- 2020-08-27 0001571996-20-000041 — 2.02, 9.01
- 2020-07-02 0001571996-20-000037 — 5.07
- 2020-05-28 0001571996-20-000028 — 2.02, 9.01
- 2020-04-09 0001193125-20-102602 — 1.01, 2.03, 9.01
- 2020-04-08 0001571996-20-000021 — 5.02
- 2020-04-03 0001571996-20-000019 — 8.01, 9.01
- 2020-03-26 0001571996-20-000015 — 7.01
- 2020-02-27 0001571996-20-000009 — 2.02, 8.01, 9.01
- 2020-02-18 0001571996-20-000005 — 8.01, 9.01
- 2020-01-09 0001571996-20-000002 — 3.02
- 2020-01-06 0001193125-20-002200 — 3.02
- 2019-12-13 0001193125-19-313947 — 3.02
- 2019-12-10 0001571996-19-000052 — 5.02
- 2019-12-02 0001571996-19-000044 — 5.02, 7.01, 9.01
- 2019-11-26 0001571996-19-000042 — 2.02, 9.01
- 2019-09-23 0001193125-19-252192 — 1.01, 2.03, 9.01
- 2019-08-29 0001571996-19-000036 — 2.02, 9.01
- 2019-08-22 0001193125-19-226939 — 7.01, 8.01, 9.01
- 2019-07-11 0001571996-19-000032 — 5.02, 5.07, 9.01
- 2019-07-03 0001571996-19-000030 — 3.02
- 2019-06-27 0001571996-19-000028 — 3.02
- 2019-05-30 0001571996-19-000021 — 2.02, 9.01
- 2019-04-02 0001571996-19-000010 — 5.02
- 2019-03-21 0001193125-19-082281 — 1.01, 1.02, 2.03, 9.01
- 2019-03-19 0001571996-19-000005 — 5.02, 9.01
- 2019-03-14 0001193125-19-074935 — 1.01, 2.03, 9.01
- 2019-03-07 0001193125-19-066045 — 8.01, 9.01
- 2019-02-28 0001571996-19-000002 — 2.02, 9.01
- 2018-12-28 0001193125-18-360943 — 1.01, 1.02, 3.01, 3.03, 5.02, 5.03, 7.01, 8.01, 9.01
- 2018-12-21 0001193125-18-356324 — 1.01, 2.03, 9.01
- 2018-12-14 0001193125-18-349469 — 8.01
- 2018-12-11 0001193125-18-346958 — 5.07, 8.01, 9.01
- 2018-11-29 0001571996-18-000041 — 2.02, 9.01
- 2018-11-28 0001571996-18-000037 — 7.01, 8.01, 9.01
- 2018-11-26 0001193125-18-333967 — 8.01, 9.01
- 2018-11-15 0001193125-18-328110 — 1.01, 9.01 — amendment of 0001193125-18-327222
- 2018-11-15 0001193125-18-327222 — 1.01, 7.01, 9.01
- 2018-10-03 0001193125-18-291390 — 8.01
- 2018-09-06 0001571996-18-000029 — 2.02, 9.01
- 2018-08-06 0001571996-18-000027 — 8.01, 9.01
- 2018-07-02 0001193125-18-210339 — 1.01, 7.01, 9.01
- 2018-06-28 0001571996-18-000024 — 5.07
- 2018-06-04 0001571996-18-000019 — 2.02, 9.01
- 2018-05-17 0001571996-18-000016 — 7.01
- 2018-04-26 0001571996-18-000009 — 7.01, 9.01
- 2018-03-08 0001193125-18-074168 — 2.02, 9.01
- 2018-02-02 0001193125-18-029947 — 7.01, 9.01
- 2017-12-07 0001571996-17-000042 — 2.02, 9.01
- 2017-10-24 0001571996-17-000037 — 1.01, 2.03, 9.01
- 2017-09-15 0001571996-17-000027 — 5.02
- 2017-09-07 0001571996-17-000017 — 2.02, 9.01
- 2017-08-24 0001571996-17-000014 — 8.01
- 2017-06-29 0001571996-17-000011 — 3.03, 5.07, 8.01, 9.01
- 2017-06-08 0001193125-17-197638 — 2.02, 9.01
- 2017-03-30 0001193125-17-102794 — 8.01
- 2017-03-30 0001193125-17-102777 — 2.02, 9.01
- 2017-03-09 0001193125-17-076981 — 1.01, 2.03, 9.01
- 2017-01-17 0001193125-17-011125 — 8.01
- 2016-12-15 0001193125-16-793722 — 8.01
- 2016-12-08 0001193125-16-787976 — 2.02, 9.01
- 2016-11-10 0001193125-16-765964 — 1.02, 8.01
- 2016-11-04 0001193125-16-760249 — 8.01
- 2016-09-13 0001193125-16-708600 — 3.02
- 2016-09-09 0001193125-16-706567 — 1.01, 1.02, 2.01, 2.03, 3.02, 3.03, 5.02, 9.01
- 2016-09-07 0001193125-16-703370 — 3.03, 5.07, 7.01, 8.01, 9.01
- 2016-09-06 0001193125-16-702057 — 2.02, 9.01
- 2016-08-31 0001193125-16-697268 — 8.01, 9.01
- 2016-08-26 0001193125-16-692921 — 8.01, 9.01
- 2016-07-11 0001193125-16-645610 — 8.01
- 2016-07-05 0001193125-16-641679 — 8.01
- 2016-06-22 0001193125-16-629055 — 1.01, 2.03, 8.01, 9.01
- 2016-06-21 0001193125-16-627071 — 8.01, 9.01
- 2016-06-10 0001193125-16-618483 — 2.02, 9.01
- 2016-06-09 0001193125-16-617893 — 8.01, 9.01

## late-filing notifications on or before 2020-12-07

- none on or before 2020-12-07

## item 2.02 — earnings release, exhibit 99.1

[0001571996-20-000048:8k_2_02:1]
EX-99.1
2
exhibit991earningsq3fy.htm
EX-99.1

[0001571996-20-000048:8k_2_02:2]
Document

[0001571996-20-000048:8k_2_02:3]
Exhibit 99.1

[0001571996-20-000048:8k_2_02:4]
News Release

[0001571996-20-000048:8k_2_02:5]
Remote Work and Learn Solutions Drive Dell Technologies’

[0001571996-20-000048:8k_2_02:6]
Third Quarter Fiscal 2021 Financial Results

[0001571996-20-000048:8k_2_02:7]
ROUND ROCK, Texas — November 24, 2020

[0001571996-20-000048:8k_2_02:8]
News summary

[0001571996-20-000048:8k_2_02:9]
•Third quarter total revenue up 3% to $23.5 billion

[0001571996-20-000048:8k_2_02:10]
•Record Client Solutions Group revenue of $12.3 billion, up 8%, operating income of $1.0 billion

[0001571996-20-000048:8k_2_02:11]
•Diluted earnings per share up 64% to $1.08, non-GAAP diluted earnings per share up 16% to $2.03

[0001571996-20-000048:8k_2_02:12]
•Operating income up 35% to $1.1 billion, non-GAAP operating income up 12% to $2.7 billion

[0001571996-20-000048:8k_2_02:13]
Full story

[0001571996-20-000048:8k_2_02:14]
Dell Technologies (NYSE: DELL) announces financial results for its fiscal 2021 third quarter. Revenue was up 3% to $23.5 billion. The company generated operating income of $1.1 billion, a 35% increase over the same period in the prior year, and non-GAAP operating income of $2.7 billion, up 12%. Net income was $881 million, non-GAAP net income was $1.7 billion and adjusted EBITDA was $3.2 billion. Net cash from operating activities was $3.0 billion. Diluted earnings per share was $1.08, up 64% and non-GAAP diluted earnings per share was $2.03, up 16%.

[0001571996-20-000048:8k_2_02:15]
“Technology has never been more important, and as the world evolves, so does our business,” said Jeff Clarke, vice chairman and chief operating officer, Dell Technologies. “We met unprecedented demand for remote work and learn solutions this quarter while increasing revenue to $23.5 billion. At the same time, we accelerated our as-a-Service strategy and hybrid cloud capabilities at the edge – positioning us to win in these growing markets and making it easy for customers to manage data and workloads across all their operations.”

[0001571996-20-000048:8k_2_02:16]
In October, at Dell Technologies World Experience, the company announced the expansion of its as-a-Service capabilities with Project APEX to simplify how customers and partners access technology on-demand – across storage, servers, networking, hyperconverged infrastructure, PCs and broader solutions. Project APEX will unify the company’s as-a-Service and cloud strategies, technology offerings, and go-to-market efforts. Businesses will have a consistent as-a-Service experience wherever they run workloads including on-premises, edge locations and public clouds.

[0001571996-20-000048:8k_2_02:17]
1

[0001571996-20-000048:8k_2_02:18]
Third Quarter Fiscal 2021 Financial Results

[0001571996-20-000048:8k_2_02:19]
|  | Three Months Ended |  |  |  | Nine Months Ended |  |  |
|  | October 30, 2020 |  | November 1, 2019 |  | Change |  | October 30, 2020 |  | November 1, 2019 |  | Change |
|  | (in millions, except per share amounts and percentages; unaudited) |
| Total net revenue | $ | 23,482 |  |  | $ | 22,844 |  |  | 3% |  | $ | 68,112 |  |  | $ | 68,122 |  |  | —% |
| Operating income | $ | 1,129 |  |  | $ | 836 |  |  | 35% |  | $ | 2,967 |  |  | $ | 1,905 |  |  | 56% |
| Net income | $ | 881 |  |  | $ | 552 |  |  | 60% |  | $ | 2,162 |  |  | $ | 5,113 |  |  | (58)% |
| Earnings per share - diluted | $ | 1.08 |  |  | $ | 0.66 |  |  | 64% |  | $ | 2.64 |  |  | $ | 5.50 |  |  | (52)% |
| Non-GAAP net revenue | $ | 23,521 |  |  | $ | 22,928 |  |  | 3% |  | $ | 68,241 |  |  | $ | 68,372 |  |  | —% |
| Non-GAAP operating income | $ | 2,725 |  |  | $ | 2,442 |  |  | 12% |  | $ | 7,504 |  |  | $ | 7,381 |  |  | 2% |
| Non-GAAP net income | $ | 1,711 |  |  | $ | 1,445 |  |  | 18% |  | $ | 4,475 |  |  | $ | 4,405 |  |  | 2% |
| Adjusted EBITDA | $ | 3,231 |  |  | $ | 2,857 |  |  | 13% |  | $ | 8,938 |  |  | $ | 8,586 |  |  | 4% |
| Non-GAAP earnings per share - diluted | $ | 2.03 |  |  | $ | 1.75 |  |  | 16% |  | $ | 5.28 |  |  | $ | 5.35 |  |  | (1)% |

[0001571996-20-000048:8k_2_02:20]
Information about Dell Technologies’ use of non-GAAP financial information is provided under “Non-GAAP Financial Measures” below.  All comparisons in this press release are year-over-year unless otherwise noted.

[0001571996-20-000048:8k_2_02:21]
Dell Technologies ended the quarter with cash and investments of $13 billion and paid down $4.6 billion in debt during the quarter. The company had total deferred revenue of $28.7 billion as of quarter end, up 11% year-over-year. Recurring revenue, which includes deferred revenue amortization, utility and as-a-Service models was approximately $6 billion for the quarter, up 13% year-over-year.

[0001571996-20-000048:8k_2_02:22]
“We delivered differentiated performance through our diversified portfolio and are leaning into growth opportunities while managing operating expenses in a disciplined way,” said Tom Sweet, chief financial officer, Dell Technologies. “In the third quarter, we drove value by expanding profitability at a significant multiple of revenue and generated $3 billion in operating cash flow.”

[0001571996-20-000048:8k_2_02:23]
Operating segments summary

[0001571996-20-000048:8k_2_02:24]
Client Solutions Group revenue for the third quarter was a record $12.3 billion. Operating income was a record $1.0 billion, up 36% and 8.2% of Client Solutions Group revenue. The company saw continued demand for remote work, learning and gaming solutions. Consumer revenue was $3.5 billion, up 14%, while commercial client revenue was $8.8 billion, up 5%.

[0001571996-20-000048:8k_2_02:25]
Key highlights:

[0001571996-20-000048:8k_2_02:26]
•Consumer direct business up 47% with consumer direct online business up 62%, based on orders.

[0001571996-20-000048:8k_2_02:27]
•Strong performance with double-digit revenue growth in Latitude and Precision notebooks and triple-digit revenue growth in Commercial Chromebooks.

[0001571996-20-000048:8k_2_02:28]
•Strength in the XPS premium line and gaming systems including Alienware, with strong double-digit revenue growth for both notebooks and desktops.

[0001571996-20-000048:8k_2_02:29]
2

[0001571996-20-000048:8k_2_02:30]
Infrastructure Solutions Group revenue for the third quarter was $8.0 billion, with customers continuing to direct more spending towards remote work and business continuity solutions. Storage revenue was $3.9 billion, while servers and networking revenue was $4.2 billion. Operating income was $882 million for the third quarter, or approximately 11% of Infrastructure Solutions Group revenue.

[0001571996-20-000048:8k_2_02:31]
Key highlights:

[0001571996-20-000048:8k_2_02:32]
•Launch of new HCI, cloud, storage and data protection integration with latest VMware releases to help customers innovate across edge locations, data centers and hybrid clouds.

[0001571996-20-000048:8k_2_02:33]
•Continued strong demand for VxRail and PowerMax solutions, with double-digit orders growth in both for the third straight quarter.

[0001571996-20-000048:8k_2_02:34]
•PowerEdge server orders up single digits sequentially.

[0001571996-20-000048:8k_2_02:35]
VMware revenue was $2.9 billion for the third quarter, up 8% driven by broad-based strength across a diverse product portfolio. Operating income for the quarter was $837 million, or 28.9% of VMware revenue.

[0001571996-20-000048:8k_2_02:36]
Conference call information

[0001571996-20-000048:8k_2_02:37]
As previously announced, the Company will hold a conference call to discuss its third quarter performance today, November 24, 2020 at 4:30 p.m. CST. The conference call will be broadcast live over the internet and can be accessed at https://investors.delltechnologies.com/events-and-presentations/upcoming-events

[0001571996-20-000048:8k_2_02:38]
For those unable to listen to the live broadcast, an archived version will be available at the same location for one year.

[0001571996-20-000048:8k_2_02:39]
Additional financial and operating information may be downloaded from

[0001571996-20-000048:8k_2_02:40]
https://investors.delltechnologies.com/financial-information/quarterly-results

[0001571996-20-000048:8k_2_02:41]
About Dell Technologies

[0001571996-20-000048:8k_2_02:42]
Dell Technologies (NYSE:DELL) helps organizations and individuals build their digital future and transform how they work, live and play.  The company provides customers with the industry’s broadest and most innovative technology and services portfolio for the data era.

[0001571996-20-000048:8k_2_02:43]
Contacts

[0001571996-20-000048:8k_2_02:44]
Investors: Investor_Relations@Dell.com

[0001571996-20-000048:8k_2_02:45]
Media: Media.Relations@Dell.com

[0001571996-20-000048:8k_2_02:46]
# # #

[0001571996-20-000048:8k_2_02:47]
Copyright © 2020 Dell Inc. or its subsidiaries. All Rights Reserved. Dell Technologies, Dell, EMC and Dell EMC are trademarks of Dell Inc. or its subsidiaries. Other trademarks may be trademarks of their respective owners.

[0001571996-20-000048:8k_2_02:48]
3

[0001571996-20-000048:8k_2_02:49]
Non-GAAP Financial Measures:

[0001571996-20-000048:8k_2_02:50]
This press release presents information about Dell Technologies’ non-GAAP net revenue, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP operating income, non-GAAP net income, non-GAAP net income attributable to non-controlling interests, non-GAAP net income attributable to Dell Technologies Inc. - basic, non-GAAP net income attributable to Dell Technologies Inc. - diluted, non-GAAP earnings per share attributable to Dell Technologies Inc. - basic, non-GAAP earnings per share attributable to Dell Technologies Inc. - diluted, EBITDA, and adjusted EBITDA, which are non-GAAP financial measures provided as a supplement to the results provided in accordance with generally accepted accounting principles in the United States of America (“GAAP”). A reconciliation of each non-GAAP financial measure to the most directly comparable GAAP financial measure is provided in the attached tables for each of the fiscal periods indicated.

[0001571996-20-000048:8k_2_02:51]
Special Note on Forward-Looking Statements:

[0001571996-20-000048:8k_2_02:52]
Dell Technologies’ results or events in future periods could differ materially from those expressed or implied by these forward-looking statements because of risks, uncertainties, and other factors that include, but are not limited to, the following: competitive pressures; Dell Technologies’ reliance on third-party suppliers for products and components, including reliance on single-source or limited-source suppliers; Dell Technologies’ ability to achieve favorable pricing from its vendors; adverse global economic conditions and instability in financial markets, including as a result of the COVID-19 pandemic; Dell Technologies’ execution of its growth, business and acquisition strategies; the success of Dell Technologies’ cost efficiency measures; Dell Technologies’ ability to manage solutions and products and services transitions in an effective manner; Dell Technologies’ ability to deliver high-quality products and services; Dell Technologies’ foreign operations and ability to generate substantial non-U.S. net revenue; Dell Technologies’ product, customer, and geographic sales mix, and seasonal sales trends; the performance of Dell Technologies’ sales channel partners; access to the capital markets by Dell Technologies or its customers; weak economic conditions and additional regulation including tariffs and other effects of trade regulation; counterparty default risks; effects of customer defaults or the exercise of customer rights on the ability of Dell Technologies to produce revenue under its contracts for services and solutions at expected levels and to perform such contracts at estimated costs; the loss by Dell Technologies of government contracts; Dell Technologies’ ability to develop and protect its proprietary intellectual property or obtain licenses to intellectual property developed by others on commercially reasonable and competitive terms; infrastructure disruptions, cyberattacks, or other data security breaches; Dell Technologies’ ability to hedge effectively its exposure to fluctuations in foreign currency exchange rates and interest rates; expiration of tax holidays or favorable tax rate structures, or unfavorable outcomes in tax audits and other tax compliance matters; impairment of portfolio investments; unfavorable results of legal proceedings; Dell Technologies’ ability to develop and maintain effective internal control over financial reporting; compliance requirements of changing environmental and safety laws; the effect of armed hostilities, terrorism, natural disasters, climate change, and public health issues, including those relating to the COVID-19 pandemic; Dell Technologies’ substantial level of indebtedness; the impact of the financial performance of VMware, Inc.; and the market volatility of Dell Technologies’ pension plan assets.

[0001571996-20-000048:8k_2_02:53]
This list of risks, uncertainties, and other factors is not complete. Dell Technologies discusses some of these matters more fully, as well as certain risk factors that could affect Dell Technologies’ business, financial condition, results of operations, and prospects, in its reports filed with the SEC, including Dell Technologies’ annual report on Form 10-K for the fiscal year ended January 31, 2020, quarterly reports on Form 10-Q, and current reports on Form 8-K. These filings are available for review through the SEC’s website at www.sec.gov. Any or all forward-looking statements Dell Technologies makes may turn out to be wrong and can be affected by inaccurate assumptions Dell Technologies might make or by known or unknown risks, uncertainties and other factors, including those identified in this press release. Accordingly, you should not place undue reliance on the forward-looking statements made in this press release, which speak only as of the date such statements are made. Dell Technologies does not undertake to update any forward-looking statement after the date as of which such statement was made, whether to reflect changes in circumstances or Dell Technologies’ expectations, the occurrence of unanticipated events, or otherwise.

[0001571996-20-000048:8k_2_02:54]
4

[0001571996-20-000048:8k_2_02:55]
DELL TECHNOLOGIES INC.

[0001571996-20-000048:8k_2_02:56]
Condensed Consolidated Statements of Income (Loss) and Related Financial Highlights

[0001571996-20-000048:8k_2_02:57]
(in millions, except percentages; unaudited)

[0001571996-20-000048:8k_2_02:58]
|  | Three Months Ended |  |  |  | Nine Months Ended |  |  |
|  | October 30, 2020 |  | November 1, 2019 |  | Change |  | October 30, 2020 |  | November 1, 2019 |  | Change |
| Net revenue (a): |  |  |  |  |  |  |  |  |  |  |  |
| Products | $ | 17,352 |  |  | $ | 17,275 |  |  | —% |  | $ | 50,127 |  |  | $ | 51,765 |  |  | (3)% |
| Services | 6,130 |  |  | 5,569 |  |  | 10% |  | 17,985 |  |  | 16,357 |  |  | 10% |
| Total net revenue | 23,482 |  |  | 22,844 |  |  | 3% |  | 68,112 |  |  | 68,122 |  |  | —% |
| Cost of net revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Products | 13,789 |  |  | 13,558 |  |  | 2% |  | 39,923 |  |  | 40,526 |  |  | (1)% |
| Services | 2,432 |  |  | 2,160 |  |  | 13% |  | 6,919 |  |  | 6,347 |  |  | 9% |
| Total cost of net revenue | 16,221 |  |  | 15,718 |  |  | 3% |  | 46,842 |  |  | 46,873 |  |  | —% |
| Gross margin | 7,261 |  |  | 7,126 |  |  | 2% |  | 21,270 |  |  | 21,249 |  |  | —% |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |
| Selling, general, and administrative | 4,772 |  |  | 5,028 |  |  | (5)% |  | 14,419 |  |  | 15,677 |  |  | (8)% |
| Research and development | 1,360 |  |  | 1,262 |  |  | 8% |  | 3,884 |  |  | 3,667 |  |  | 6% |
| Total operating expenses | 6,132 |  |  | 6,290 |  |  | (3)% |  | 18,303 |  |  | 19,344 |  |  | (5)% |
| Operating income | 1,129 |  |  | 836 |  |  | 35% |  | 2,967 |  |  | 1,905 |  |  | 56% |
| Interest and other, net | 273 |  |  | (677) |  |  | 140% |  | (929) |  |  | (2,000) |  |  | 54% |
| Income (loss) before income taxes | 1,402 |  |  | 159 |  |  | 782% |  | 2,038 |  |  | (95) |  |  | NM |
| Income tax provision (benefit) | 521 |  |  | (393) |  |  | 233% |  | (124) |  |  | (5,208) |  |  | 98% |
| Net income | 881 |  |  | 552 |  |  | 60% |  | 2,162 |  |  | 5,113 |  |  | (58)% |
| Less: Net income attributable to non-controlling interests | 49 |  |  | 53 |  |  | (8)% |  | 139 |  |  | 905 |  |  | (85)% |
| Net income attributable to Dell Technologies Inc. | $ | 832 |  |  | $ | 499 |  |  | 67% |  | $ | 2,023 |  |  | $ | 4,208 |  |  | (52)% |
| Percentage of Total Net Revenue: |  |  |  |  |  |  |  |  |  |  |
| Gross margin | 31 | % |  | 31 | % |  |  |  | 31 | % |  | 31 | % |  |  |
| Selling, general, and administrative | 20 | % |  | 22 | % |  |  |  | 21 | % |  | 23 | % |  |  |
| Research and development | 6 | % |  | 6 | % |  |  |  | 6 | % |  | 5 | % |  |  |
| Operating expenses | 26 | % |  | 28 | % |  |  |  | 27 | % |  | 28 | % |  |  |
| Operating income | 5 | % |  | 4 | % |  |  |  | 4 | % |  | 3 | % |  |  |
| Income (loss) before income taxes | 6 | % |  | 1 | % |  |  |  | 3 | % |  | — | % |  |  |
| Net income | 4 | % |  | 2 | % |  |  |  | 3 | % |  | 8 | % |  |  |
| Income tax rate | 37.2 | % |  | -247.2 | % |  |  |  | -6.1 | % |  | 5482.1 | % |  |  |

[0001571996-20-000048:8k_2_02:59]
____________________

[0001571996-20-000048:8k_2_02:60]
(a)    During Fiscal 2020, the Company reclassified revenue associated with certain service and software-as-a-service offerings from product revenue to services revenue. There was no change to total revenue as a result of the reclassifications. Prior period results have been recast to conform with current period presentation.

[0001571996-20-000048:8k_2_02:61]
5

[0001571996-20-000048:8k_2_02:62]
DELL TECHNOLOGIES INC.

[0001571996-20-000048:8k_2_02:63]
Consolidated Statements of Financial Position

[0001571996-20-000048:8k_2_02:64]
(in millions; unaudited)

[0001571996-20-000048:8k_2_02:65]
|  | October 30, 2020 |  | January 31, 2020 |
| ASSETS |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 11,304 |  |  | $ | 9,302 |  |
| Accounts receivable, net | 11,377 |  |  | 12,484 |  |
| Short-term financing receivables, net | 4,872 |  |  | 4,895 |  |
| Inventories, net | 3,393 |  |  | 3,281 |  |
| Other current assets | 7,668 |  |  | 6,906 |  |
| Total current assets | 38,614 |  |  | 36,868 |  |
| Property, plant, and equipment, net | 6,344 |  |  | 6,055 |  |
| Long-term investments | 1,655 |  |  | 864 |  |
| Long-term financing receivables, net | 5,374 |  |  | 4,848 |  |
| Goodwill | 40,643 |  |  | 41,691 |  |
| Intangible assets, net | 15,257 |  |  | 18,107 |  |
| Other non-current assets | 11,061 |  |  | 10,428 |  |
| Total assets | $ | 118,948 |  |  | $ | 118,861 |  |
| LIABILITIES, REDEEMABLE SHARES, AND STOCKHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |
| Short-term debt | $ | 6,536 |  |  | $ | 7,737 |  |
| Accounts payable | 19,792 |  |  | 20,065 |  |
| Accrued and other | 8,715 |  |  | 9,773 |  |
| Short-term deferred revenue | 15,259 |  |  | 14,881 |  |
| Total current liabilities | 50,302 |  |  | 52,456 |  |
| Long-term debt | 43,325 |  |  | 44,319 |  |
| Long-term deferred revenue | 13,422 |  |  | 12,919 |  |
| Other non-current liabilities | 5,433 |  |  | 5,383 |  |
| Total liabilities | 112,482 |  |  | 115,077 |  |
| Redeemable shares | 527 |  |  | 629 |  |
| Stockholders’ equity (deficit): |  |  |  |
| Total Dell Technologies Inc. stockholders’ equity (deficit) | 883 |  |  | (1,574) |  |
| Non-controlling interests | 5,056 |  |  | 4,729 |  |
| Total stockholders’ equity | 5,939 |  |  | 3,155 |  |
| Total liabilities, redeemable shares, and stockholders’ equity | $ | 118,948 |  |  | $ | 118,861 |  |

[0001571996-20-000048:8k_2_02:66]
6

[0001571996-20-000048:8k_2_02:67]
DELL TECHNOLOGIES INC.

[0001571996-20-000048:8k_2_02:68]
Condensed Consolidated Statements of Cash Flows

[0001571996-20-000048:8k_2_02:69]
(in millions; unaudited)

[0001571996-20-000048:8k_2_02:70]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 30, 2020 |  | November 1, 2019 |  | October 30, 2020 |  | November 1, 2019 |
| Cash flows from operating activities: |  |  |  |  |  |  |  |
| Net income | $ | 881 |  |  | $ | 552 |  |  | $ | 2,162 |  |  | $ | 5,113 |  |
| Adjustments to reconcile net income to net cash provided by (used in) operating activities: | 2,113 |  |  | 1,269 |  |  | 3,368 |  |  | 670 |  |
| Change in cash from operating activities | 2,994 |  |  | 1,821 |  |  | 5,530 |  |  | 5,783 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |
| Purchases of investments | (122) |  |  | (72) |  |  | (296) |  |  | (142) |  |
| Maturities and sales of investments | 27 |  |  | 19 |  |  | 98 |  |  | 449 |  |
| Capital expenditures and capitalized software development costs | (480) |  |  | (609) |  |  | (1,584) |  |  | (1,876) |  |
| Acquisition of businesses and assets, net | (71) |  |  | (2,053) |  |  | (405) |  |  | (2,437) |  |
| Divestitures of businesses and assets, net | 2,067 |  |  | — |  |  | 2,187 |  |  | (3) |  |
| Other | 14 |  |  | 16 |  |  | 26 |  |  | 27 |  |
| Change in cash from investing activities | 1,435 |  |  | (2,699) |  |  | 26 |  |  | (3,982) |  |
| Cash flows from financing activities: |  |  |  |  |  |  |  |
| Proceeds from the issuance of common stock | 168 |  |  | 212 |  |  | 389 |  |  | 451 |  |
| Repurchases of parent common stock | — |  |  | (2) |  |  | (240) |  |  | (6) |  |
| Repurchases of subsidiary common stock (a) | (299) |  |  | (283) |  |  | (890) |  |  | (1,686) |  |
| Proceeds from debt | 2,925 |  |  | 5,455 |  |  | 14,772 |  |  | 17,656 |  |
| Repayments of debt | (7,024) |  |  | (5,037) |  |  | (17,244) |  |  | (18,948) |  |
| Other | (80) |  |  | (23) |  |  | (270) |  |  | (67) |  |
| Change in cash from financing activities | (4,310) |  |  | 322 |  |  | (3,483) |  |  | (2,600) |  |
| Effect of exchange rate changes on cash, cash equivalents, and restricted cash | (15) |  |  | (38) |  |  | (67) |  |  | (100) |  |
| Change in cash, cash equivalents, and restricted cash | 104 |  |  | (594) |  |  | 2,006 |  |  | (899) |  |
| Cash, cash equivalents, and restricted cash at beginning of the period | 12,053 |  |  | 9,935 |  |  | 10,151 |  |  | 10,240 |  |
| Cash, cash equivalents, and restricted cash at end of the period | $ | 12,157 |  |  | $ | 9,341 |  |  | $ | 12,157 |  |  | $ | 9,341 |  |

[0001571996-20-000048:8k_2_02:71]
_________________

[0001571996-20-000048:8k_2_02:72]
(a)     Subsidiary common stock repurchases are inclusive of employee tax withholding on stock-based compensation.

[0001571996-20-000048:8k_2_02:73]
7

[0001571996-20-000048:8k_2_02:74]
DELL TECHNOLOGIES INC.

[0001571996-20-000048:8k_2_02:75]
Segment Information

[0001571996-20-000048:8k_2_02:76]
(in millions, except percentages; unaudited; continued on next page)

[0001571996-20-000048:8k_2_02:77]
|  | Three Months Ended |  |  |  | Nine Months Ended |  |  |
|  | October 30, 2020 |  | November 1, 2019 |  | Change |  | October 30, 2020 |  | November 1, 2019 |  | Change |
| Infrastructure Solutions Group (ISG): |
| Net Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Servers and networking | $ | 4,164 |  |  | $ | 4,241 |  |  | (2)% |  | $ | 12,118 |  |  | $ | 12,858 |  |  | (6)% |
| Storage | 3,860 |  |  | 4,149 |  |  | (7)% |  | 11,682 |  |  | 12,355 |  |  | (5)% |
| Total ISG net revenue | $ | 8,024 |  |  | $ | 8,390 |  |  | (4)% |  | $ | 23,800 |  |  | $ | 25,213 |  |  | (6)% |
| Operating Income: |  |  |  |  |  |  |  |  |  |  |  |
| ISG operating income | $ | 882 |  |  | $ | 996 |  |  | (11)% |  | $ | 2,587 |  |  | $ | 2,889 |  |  | (10)% |
| % of ISG net revenue | 11 | % |  | 12 | % |  |  |  | 11 | % |  | 11 | % |  |  |
| % of total reportable segment operating income | 32 | % |  | 41 | % |  |  |  | 35 | % |  | 39 | % |  |  |
| Client Solutions Group (CSG): |
| Net Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Commercial | $ | 8,783 |  |  | $ | 8,330 |  |  | 5% |  | $ | 25,456 |  |  | $ | 25,714 |  |  | (1)% |
| Consumer | 3,503 |  |  | 3,080 |  |  | 14% |  | 9,137 |  |  | 8,354 |  |  | 9% |
| Total CSG net revenue | $ | 12,286 |  |  | $ | 11,410 |  |  | 8% |  | $ | 34,593 |  |  | $ | 34,068 |  |  | 2% |
| Operating Income: |  |  |  |  |  |  |  |  |  |  |  |
| CSG operating income | $ | 1,002 |  |  | $ | 739 |  |  | 36% |  | $ | 2,309 |  |  | $ | 2,514 |  |  | (8)% |
| % of CSG net revenue | 8 | % |  | 6 | % |  |  |  | 7 | % |  | 7 | % |  |  |
| % of total reportable segment operating income | 37 | % |  | 30 | % |  |  |  | 31 | % |  | 34 | % |  |  |
| VMware (a): |
| Net Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Total VMware net revenue | $ | 2,893 |  |  | $ | 2,671 |  |  | 8% |  | $ | 8,556 |  |  | $ | 7,779 |  |  | 10% |
| Operating Income: |  |  |  |  |  |  |  |  |  |  |  |
| VMware operating income | $ | 837 |  |  | $ | 709 |  |  | 18% |  | $ | 2,504 |  |  | $ | 2,055 |  |  | 22% |
| % of VMware net revenue | 29 | % |  | 27 | % |  |  |  | 29 | % |  | 26 | % |  |  |
| % of total reportable segment operating income | 31 | % |  | 29 | % |  |  |  | 34 | % |  | 27 | % |  |  |

[0001571996-20-000048:8k_2_02:78]
____________________

[0001571996-20-000048:8k_2_02:79]
(a)    During Fiscal 2020, the Company reclassified Pivotal operating results from Other businesses to the VMware reportable segment. There was no change to consolidated results as a result of the reclassification. Prior period results have been recast to conform with current period presentation.

[0001571996-20-000048:8k_2_02:80]
8

[0001571996-20-000048:8k_2_02:81]
DELL TECHNOLOGIES INC.

[0001571996-20-000048:8k_2_02:82]
Segment Information

[0001571996-20-000048:8k_2_02:83]
(in millions, except percentages; unaudited; continued)

[0001571996-20-000048:8k_2_02:84]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 30, 2020 |  | November 1, 2019 |  | October 30, 2020 |  | November 1, 2019 |
| Reconciliation to consolidated net revenue: |  |  |  |  |  |  |
| Reportable segment net revenue (a) | $ | 23,203 |  |  | $ | 22,471 |  |  | $ | 66,949 |  |  | $ | 67,060 |  |
| Other businesses (a) (b) | 314 |  |  | 456 |  |  | 1,288 |  |  | 1,311 |  |
| Unallocated transactions (c) | 4 |  |  | 1 |  |  | 4 |  |  | 1 |  |
| Impact of purchase accounting (d) | (39) |  |  | (84) |  |  | (129) |  |  | (250) |  |
| Total consolidated net revenue | $ | 23,482 |  |  | $ | 22,844 |  |  | $ | 68,112 |  |  | $ | 68,122 |  |
| Reconciliation to consolidated operating income: |  |  |  |  |
| Reportable segment operating income (a) | $ | 2,721 |  |  | $ | 2,444 |  |  | $ | 7,400 |  |  | $ | 7,458 |  |
| Other businesses (a) (b) | 3 |  |  | — |  |  | 105 |  |  | (48) |  |
| Unallocated transactions (c) | 1 |  |  | (2) |  |  | (1) |  |  | (29) |  |
| Impact of purchase accounting (d) | (49) |  |  | (96) |  |  | (165) |  |  | (299) |  |
| Amortization of intangibles | (845) |  |  | (1,057) |  |  | (2,547) |  |  | (3,334) |  |
| Transaction-related expenses (e) | (52) |  |  | (76) |  |  | (211) |  |  | (165) |  |
| Stock-based compensation expense (f) | (436) |  |  | (322) |  |  | (1,219) |  |  | (886) |  |
| Other corporate expenses (g) | (214) |  |  | (55) |  |  | (395) |  |  | (792) |  |
| Total consolidated operating income | $ | 1,129 |  |  | $ | 836 |  |  | $ | 2,967 |  |  | $ | 1,905 |  |

[0001571996-20-000048:8k_2_02:85]
_________________

[0001571996-20-000048:8k_2_02:86]
(a)During Fiscal 2020, the Company reclassified Pivotal operating results from Other businesses to the VMware reportable segment. Prior period results have been recast to conform with current period presentation.

[0001571996-20-000048:8k_2_02:87]
(b)Secureworks, Virtustream, and Boomi constitute “Other businesses” and do not meet the requirements for a reportable segment, either individually or collectively. The Company completed the sale of RSA Security on September 1, 2020; prior to divestiture, RSA Security’s operating results were also included in Other Businesses and did not meet the requirements for a reportable segment. The results of Other businesses are not material to the Company’s overall results.

[0001571996-20-000048:8k_2_02:88]
(c)Unallocated transactions includes other corporate items that are not allocated to Dell Technologies’ reportable segments.

[0001571996-20-000048:8k_2_02:89]
(d)Impact of purchase accounting includes non-cash purchase accounting adjustments that are primarily related to the EMC merger transaction.

[0001571996-20-000048:8k_2_02:90]
(e)Transaction-related expenses includes acquisition, integration, and divestiture related costs.

[0001571996-20-000048:8k_2_02:91]
(f)Stock-based compensation expense consists of equity awards granted based on the estimated fair value of those awards at grant date.

[0001571996-20-000048:8k_2_02:92]
(g)Other corporate expenses includes impairment charges, severance, facility action, and other costs.

[0001571996-20-000048:8k_2_02:93]
9

[0001571996-20-000048:8k_2_02:94]
SUPPLEMENTAL SELECTED NON-GAAP FINANCIAL MEASURES

[0001571996-20-000048:8k_2_02:95]
These tables present information about the Company’s non-GAAP net revenue, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP operating income, non-GAAP net income, non-GAAP net income attributable to non-controlling interests, non-GAAP net income attributable to Dell Technologies Inc. - basic, non-GAAP net income attributable to Dell Technologies Inc. - diluted, non-GAAP earnings per share attributable to Dell Technologies Inc. - basic, non-GAAP earnings per share attributable to Dell Technologies Inc. - diluted, EBITDA, and adjusted EBITDA, which are non-GAAP financial measures provided as a supplement to the results provided in accordance with generally accepted accounting principles in the United States of America (“GAAP”). A detailed discussion of Dell Technologies’ reasons for including these non-GAAP financial measures, the limitations associated with these measures, the items excluded from these measures, and our reason for excluding those items are presented in “Management’s Discussion and Analysis of Financial Condition and Results of Operations — Non-GAAP Financial Measures” in our periodic reports filed with the SEC. Dell Technologies encourages investors to review the non-GAAP discussion in these reports in conjunction with the presentation of non-GAAP financial measures.

[0001571996-20-000048:8k_2_02:96]
10

[0001571996-20-000048:8k_2_02:97]
DELL TECHNOLOGIES INC.

[0001571996-20-000048:8k_2_02:98]
Selected Non-GAAP Financial Measures

[0001571996-20-000048:8k_2_02:99]
(in millions, except per share amounts and percentages; unaudited)

[0001571996-20-000048:8k_2_02:100]
|  | Three Months Ended |  |  |  | Nine Months Ended |  |  |
|  | October 30, 2020 |  | November 1, 2019 |  | Change |  | October 30, 2020 |  | November 1, 2019 |  | Change |
| Non-GAAP net revenue | $ | 23,521 |  |  | $ | 22,928 |  |  | 3% |  | $ | 68,241 |  |  | $ | 68,372 |  |  | —% |
| Non-GAAP gross margin | $ | 7,771 |  |  | $ | 7,768 |  |  | —% |  | $ | 22,722 |  |  | $ | 23,188 |  |  | (2)% |
| % of non-GAAP net revenue | 33 | % |  | 34 | % |  |  |  | 33 | % |  | 34 | % |  |  |
| Non-GAAP operating expenses | $ | 5,046 |  |  | $ | 5,326 |  |  | (5)% |  | $ | 15,218 |  |  | $ | 15,807 |  |  | (4)% |
| % of non-GAAP net revenue | 21 | % |  | 23 | % |  |  |  | 22 | % |  | 23 | % |  |  |
| Non-GAAP operating income | $ | 2,725 |  |  | $ | 2,442 |  |  | 12% |  | $ | 7,504 |  |  | $ | 7,381 |  |  | 2% |
| % of non-GAAP net revenue | 12 | % |  | 11 | % |  |  |  | 11 | % |  | 11 | % |  |  |
| Non-GAAP net income | $ | 1,711 |  |  | $ | 1,445 |  |  | 18% |  | $ | 4,475 |  |  | $ | 4,405 |  |  | 2% |
| % of non-GAAP net revenue | 7 | % |  | 6 | % |  |  |  | 7 | % |  | 6 | % |  |  |
| Adjusted EBITDA | $ | 3,231 |  |  | $ | 2,857 |  |  | 13% |  | $ | 8,938 |  |  | $ | 8,586 |  |  | 4% |
| % of non-GAAP net revenue | 14 | % |  | 12 | % |  |  |  | 13 | % |  | 13 | % |  |  |
| Non-GAAP earnings per share - diluted | $ | 2.03 |  |  | $ | 1.75 |  |  | 16% |  | $ | 5.28 |  |  | $ | 5.35 |  |  | (1)% |

[0001571996-20-000048:8k_2_02:101]
11

[0001571996-20-000048:8k_2_02:102]
DELL TECHNOLOGIES INC.

[0001571996-20-000048:8k_2_02:103]
Reconciliation of Selected Non-GAAP Financial Measures

[0001571996-20-000048:8k_2_02:104]
(in millions, except percentages; unaudited; continued on next page)

[0001571996-20-000048:8k_2_02:105]
|  | Three Months Ended |  |  |  | Nine Months Ended |  |  |
|  | October 30, 2020 |  | November 1, 2019 |  | Change |  | October 30, 2020 |  | November 1, 2019 |  | Change |
| Net revenue | $ | 23,482 |  |  | $ | 22,844 |  |  | 3% |  | $ | 68,112 |  |  | $ | 68,122 |  |  | —% |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Impact of purchase accounting | 39 |  |  | 84 |  |  |  |  | 129 |  |  | 250 |  |  |  |
| Non-GAAP net revenue | $ | 23,521 |  |  | $ | 22,928 |  |  | 3% |  | $ | 68,241 |  |  | $ | 68,372 |  |  | —% |
| Gross margin | $ | 7,261 |  |  | $ | 7,126 |  |  | 2% |  | $ | 21,270 |  |  | $ | 21,249 |  |  | —% |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 375 |  |  | 517 |  |  |  |  | 1,122 |  |  | 1,555 |  |  |  |
| Impact of purchase accounting | 40 |  |  | 86 |  |  |  |  | 134 |  |  | 255 |  |  |  |
| Transaction-related expenses | — |  |  | — |  |  |  |  | — |  |  | (5) |  |  |  |
| Stock-based compensation expense | 51 |  |  | 33 |  |  |  |  | 141 |  |  | 91 |  |  |  |
| Other corporate expenses | 44 |  |  | 6 |  |  |  |  | 55 |  |  | 43 |  |  |  |
| Non-GAAP gross margin | $ | 7,771 |  |  | $ | 7,768 |  |  | —% |  | $ | 22,722 |  |  | $ | 23,188 |  |  | (2)% |
| Operating expenses | $ | 6,132 |  |  | $ | 6,290 |  |  | (3)% |  | $ | 18,303 |  |  | $ | 19,344 |  |  | (5)% |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | (470) |  |  | (540) |  |  |  |  | (1,425) |  |  | (1,779) |  |  |  |
| Impact of purchase accounting | (9) |  |  | (10) |  |  |  |  | (31) |  |  | (44) |  |  |  |
| Transaction-related expenses | (52) |  |  | (76) |  |  |  |  | (211) |  |  | (170) |  |  |  |
| Stock-based compensation expense | (385) |  |  | (289) |  |  |  |  | (1,078) |  |  | (795) |  |  |  |
| Other corporate expenses | (170) |  |  | (49) |  |  |  |  | (340) |  |  | (749) |  |  |  |
| Non-GAAP operating expenses | $ | 5,046 |  |  | $ | 5,326 |  |  | (5)% |  | $ | 15,218 |  |  | $ | 15,807 |  |  | (4)% |
| Operating income | $ | 1,129 |  |  | $ | 836 |  |  | 35% |  | $ | 2,967 |  |  | $ | 1,905 |  |  | 56% |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 845 |  |  | 1,057 |  |  |  |  | 2,547 |  |  | 3,334 |  |  |  |
| Impact of purchase accounting | 49 |  |  | 96 |  |  |  |  | 165 |  |  | 299 |  |  |  |
| Transaction-related expenses | 52 |  |  | 76 |  |  |  |  | 211 |  |  | 165 |  |  |  |
| Stock-based compensation expense | 436 |  |  | 322 |  |  |  |  | 1,219 |  |  | 886 |  |  |  |
| Other corporate expenses | 214 |  |  | 55 |  |  |  |  | 395 |  |  | 792 |  |  |  |
| Non-GAAP operating income | $ | 2,725 |  |  | $ | 2,442 |  |  | 12% |  | $ | 7,504 |  |  | $ | 7,381 |  |  | 2% |

[0001571996-20-000048:8k_2_02:106]
12

[0001571996-20-000048:8k_2_02:107]
DELL TECHNOLOGIES INC.

[0001571996-20-000048:8k_2_02:108]
Reconciliation of Selected Non-GAAP Financial Measures

[0001571996-20-000048:8k_2_02:109]
(in millions, except percentages; unaudited; continued)

[0001571996-20-000048:8k_2_02:110]
|  | Three Months Ended |  |  |  | Nine Months Ended |  |  |
|  | October 30, 2020 |  | November 1, 2019 |  | Change |  | October 30, 2020 |  | November 1, 2019 |  | Change |
| Net income | $ | 881 |  |  | $ | 552 |  |  | 60% |  | $ | 2,162 |  |  | $ | 5,113 |  |  | (58)% |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 845 |  |  | 1,057 |  |  |  |  | 2,547 |  |  | 3,334 |  |  |  |
| Impact of purchase accounting | 49 |  |  | 96 |  |  |  |  | 165 |  |  | 299 |  |  |  |
| Transaction-related expenses | (286) |  |  | 76 |  |  |  |  | (247) |  |  | 165 |  |  |  |
| Stock-based compensation expense | 436 |  |  | 322 |  |  |  |  | 1,219 |  |  | 886 |  |  |  |
| Other corporate expenses | 106 |  |  | 55 |  |  |  |  | 287 |  |  | 792 |  |  |  |
| Fair value adjustments on equity investments | (489) |  |  | (18) |  |  |  |  | (591) |  |  | (160) |  |  |  |
| Aggregate adjustment for income taxes | 169 |  |  | (695) |  |  |  |  | (1,067) |  |  | (6,024) |  |  |  |
| Non-GAAP net income | $ | 1,711 |  |  | $ | 1,445 |  |  | 18% |  | $ | 4,475 |  |  | $ | 4,405 |  |  | 2% |
| Net income | $ | 881 |  |  | $ | 552 |  |  | 60% |  | $ | 2,162 |  |  | $ | 5,113 |  |  | (58)% |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Interest and other, net | (273) |  |  | 677 |  |  |  |  | 929 |  |  | 2,000 |  |  |  |
| Income tax benefit | 521 |  |  | (393) |  |  |  |  | (124) |  |  | (5,208) |  |  |  |
| Depreciation and amortization | 1,361 |  |  | 1,494 |  |  |  |  | 4,017 |  |  | 4,608 |  |  |  |
| EBITDA | $ | 2,490 |  |  | $ | 2,330 |  |  | 7% |  | $ | 6,984 |  |  | $ | 6,513 |  |  | 7% |
| EBITDA | $ | 2,490 |  |  | $ | 2,330 |  |  | 7% |  | $ | 6,984 |  |  | $ | 6,513 |  |  | 7% |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation expense | 436 |  |  | 322 |  |  |  |  | 1,219 |  |  | 886 |  |  |  |
| Impact of purchase accounting | 39 |  |  | 84 |  |  |  |  | 129 |  |  | 251 |  |  |  |
| Transaction-related expenses | 52 |  |  | 76 |  |  |  |  | 211 |  |  | 165 |  |  |  |
| Other corporate expenses | 214 |  |  | 45 |  |  |  |  | 395 |  |  | 771 |  |  |  |
| Adjusted EBITDA | $ | 3,231 |  |  | $ | 2,857 |  |  | 13% |  | $ | 8,938 |  |  | $ | 8,586 |  |  | 4% |

[0001571996-20-000048:8k_2_02:111]
13

[0001571996-20-000048:8k_2_02:112]
DELL TECHNOLOGIES INC.

[0001571996-20-000048:8k_2_02:113]
Reconciliation of Selected Non-GAAP Financial Measures

[0001571996-20-000048:8k_2_02:114]
For the Three Months Ended October 30, 2020

[0001571996-20-000048:8k_2_02:115]
(in millions, except per share amounts; unaudited)

[0001571996-20-000048:8k_2_02:116]
|  | GAAP |  | Amortization of intangibles |  | Impact of purchase accounting |  | Transaction-related expenses |  | Stock-based compensation expense |  | Other corporate expenses |  | Fair value adjustments on equity investments |  | Aggregate adjustment for income taxes |  | Non-GAAP |
| Net income | $ | 881 |  |  | 845 |  |  | 49 |  |  | (286) |  |  | 436 |  |  | 106 |  |  | (489) |  |  | 169 |  |  | $ | 1,711 |  |
| Less: Net income attributable to non-controlling interests (a) | 49 |  |  | 63 |  |  | 3 |  |  | 5 |  |  | 61 |  |  | 9 |  |  | (34) |  |  | (13) |  |  | 143 |  |
| Net income attributable to Dell Technologies Inc. - basic | 832 |  |  | 782 |  |  | 46 |  |  | (291) |  |  | 375 |  |  | 97 |  |  | (455) |  |  | 182 |  |  | 1,568 |  |
| Incremental dilution from VMware, Inc. attributable to Dell Technologies Inc. (b) | (3) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | (4) |  |
| Net income attributable to Dell Technologies Inc. - diluted | $ | 829 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 1,564 |  |
| Earnings per share - basic | $ | 1.11 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 2.10 |  |
| Earnings per share - diluted | $ | 1.08 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 2.03 |  |
| Weighted-average shares outstanding - basic | 747 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 747 |  |
| Weighted-average shares outstanding - diluted | 771 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 771 |  |

[0001571996-20-000048:8k_2_02:117]
_________________

[0001571996-20-000048:8k_2_02:118]
(a)     Net income attributable to non-controlling interests is calculated by multiplying the minority interest percentage of VMware, Inc. and SecureWorks Corp. by their non-GAAP net income adjustments for the period presented.

[0001571996-20-000048:8k_2_02:119]
(b)     Incremental dilution from VMware, Inc. attributable to Dell Technologies Inc. represents the impact of VMware, Inc.’s dilutive securities on the diluted earnings per share of Dell Technologies Inc. and is calculated by multiplying the difference between VMware, Inc.’s basic and diluted earnings per share by the number of shares of VMware, Inc. common stock held by Dell Technologies Inc.

[0001571996-20-000048:8k_2_02:120]
14

[0001571996-20-000048:8k_2_02:121]
DELL TECHNOLOGIES INC.

[0001571996-20-000048:8k_2_02:122]
Reconciliation of Selected Non-GAAP Financial Measures

[0001571996-20-000048:8k_2_02:123]
For the Nine Months Ended October 30, 2020

[0001571996-20-000048:8k_2_02:124]
(in millions, except per share amounts; unaudited)

[0001571996-20-000048:8k_2_02:125]
|  | GAAP |  | Amortization of intangibles |  | Impact of purchase accounting |  | Transaction-related expenses |  | Stock-based compensation expense |  | Other corporate expenses |  | Fair value adjustments on equity investments |  | Aggregate adjustment for income taxes |  | Non-GAAP |
| Net income | $ | 2,162 |  |  | 2,547 |  |  | 165 |  |  | (247) |  |  | 1,219 |  |  | 287 |  |  | (591) |  |  | (1,067) |  |  | $ | 4,475 |  |
| Less: Net income attributable to non-controlling interests (a) | 139 |  |  | 187 |  |  | 10 |  |  | 20 |  |  | 172 |  |  | 9 |  |  | (35) |  |  | (77) |  |  | 425 |  |
| Net income attributable to Dell Technologies Inc. - basic | 2,023 |  |  | $ | 2,360 |  |  | $ | 155 |  |  | $ | (267) |  |  | $ | 1,047 |  |  | $ | 278 |  |  | $ | (556) |  |  | $ | (990) |  |  | 4,050 |  |
| Incremental dilution from VMware, Inc. attributable to Dell Technologies Inc. (b) | (8) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | (13) |  |
| Net income attributable to Dell Technologies Inc. - diluted | $ | 2,015 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 4,037 |  |
| Earnings per share - basic | $ | 2.73 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 5.46 |  |
| Earnings per share - diluted | $ | 2.64 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 5.28 |  |
| Weighted-average shares outstanding - basic | 742 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 742 |  |
| Weighted-average shares outstanding - diluted | 764 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 764 |  |

[0001571996-20-000048:8k_2_02:126]
_________________

[0001571996-20-000048:8k_2_02:127]
(a)     Net income attributable to non-controlling interests is calculated by multiplying the minority interest percentage of VMware, Inc. and SecureWorks Corp. by their non-GAAP net income adjustments for the period presented.

[0001571996-20-000048:8k_2_02:128]
(b)     Incremental dilution from VMware, Inc. attributable to Dell Technologies Inc. represents the impact of VMware, Inc.’s dilutive securities on the diluted earnings per share of Dell Technologies Inc. and is calculated by multiplying the difference between VMware, Inc.’s basic and diluted earnings per share by the number of shares of VMware, Inc. common stock held by Dell Technologies Inc.

[0001571996-20-000048:8k_2_02:129]
DELL TECHNOLOGIES INC.

[0001571996-20-000048:8k_2_02:130]
Reconciliation of Selected Non-GAAP Financial Measures

[0001571996-20-000048:8k_2_02:131]
For the Three Months Ended November 1, 2019

[0001571996-20-000048:8k_2_02:132]
(in millions, except per share amounts; unaudited)

[0001571996-20-000048:8k_2_02:133]
|  | GAAP |  | Amortization of intangibles |  | Impact of purchase accounting |  | Transaction-related expenses |  | Stock-based compensation expense |  | Other corporate expenses |  | Fair value adjustments on equity investments |  | Aggregate adjustment for income taxes |  | Non-GAAP |
| Net income | $ | 552 |  |  | 1,057 |  |  | 96 |  |  | 76 |  |  | 322 |  |  | 55 |  |  | (18) |  |  | (695) |  |  | $ | 1,445 |  |
| Less: Net income attributable to non-controlling interests (a) | 53 |  |  | 75 |  |  | 5 |  |  | 13 |  |  | 55 |  |  | — |  |  | (50) |  |  | (27) |  |  | 124 |  |
| Net income attributable to Dell Technologies Inc. - basic | 499 |  |  | 982 |  |  | 91 |  |  | 63 |  |  | 267 |  |  | 55 |  |  | 32 |  |  | (668) |  |  | 1,321 |  |
| Incremental dilution from VMware, Inc. attributable to Dell Technologies Inc. (b) | (6) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | (6) |  |
| Net income attributable to Dell Technologies Inc. - diluted | $ | 493 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 1,315 |  |
| Earnings per share - basic | $ | 0.69 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 1.82 |  |
| Earnings per share - diluted | $ | 0.66 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 1.75 |  |
| Weighted-average shares outstanding - basic | 725 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 725 |  |
| Weighted-average shares outstanding - diluted | 750 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 750 |  |

[0001571996-20-000048:8k_2_02:134]
_________________

[0001571996-20-000048:8k_2_02:135]
(a)     Net income attributable to non-controlling interests is calculated by multiplying the minority interest percentage of VMware, Inc., Pivotal Software, Inc., and SecureWorks Corp. by their non-GAAP net income adjustments for the period presented.

[0001571996-20-000048:8k_2_02:136]
(b)     Incremental dilution from VMware, Inc. attributable to Dell Technologies Inc. represents the impact of VMware, Inc.’s dilutive securities on the diluted earnings per share of Dell Technologies Inc. and is calculated by multiplying the difference between VMware, Inc.’s basic and diluted earnings per share by the number of shares of VMware, Inc. common stock held by Dell Technologies Inc.

[0001571996-20-000048:8k_2_02:137]
16

[0001571996-20-000048:8k_2_02:138]
DELL TECHNOLOGIES INC.

[0001571996-20-000048:8k_2_02:139]
Reconciliation of Selected Non-GAAP Financial Measures

[0001571996-20-000048:8k_2_02:140]
For the Nine Months Ended November 1, 2019

[0001571996-20-000048:8k_2_02:141]
(in millions, except per share amounts; unaudited)

[0001571996-20-000048:8k_2_02:142]
|  | GAAP |  | Amortization of intangibles |  | Impact of purchase accounting |  | Transaction-related expenses |  | Stock-based compensation expense |  | Other corporate expenses |  | Fair value adjustments on equity investments |  | Aggregate adjustment for income taxes |  | Non-GAAP |
| Net income | $ | 5,113 |  |  | 3,334 |  |  | 299 |  |  | 165 |  |  | 886 |  |  | 792 |  |  | (160) |  |  | (6,024) |  |  | $ | 4,405 |  |
| Less: Net income attributable to non-controlling interests (a) | 905 |  |  | 219 |  |  | 17 |  |  | 18 |  |  | 152 |  |  | — |  |  | 24 |  |  | (971) |  |  | 364 |  |
| Net income attributable to Dell Technologies Inc. - basic | 4,208 |  |  | 3,115 |  |  | 282 |  |  | 147 |  |  | 734 |  |  | 792 |  |  | (184) |  |  | (5,053) |  |  | 4,041 |  |
| Incremental dilution from VMware, Inc. attributable to Dell Technologies Inc. (b) | (81) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | (25) |  |
| Net income attributable to Dell Technologies Inc. - diluted | $ | 4,127 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 4,016 |  |
| Earnings per share - basic | $ | 5.84 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 5.61 |  |
| Earnings per share - diluted | $ | 5.50 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 5.35 |  |
| Weighted-average shares outstanding - basic | 720 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 720 |  |
| Weighted-average shares outstanding - diluted | 750 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 750 |  |

[0001571996-20-000048:8k_2_02:143]
_________________

[0001571996-20-000048:8k_2_02:144]
(a)     Net income attributable to non-controlling interests is calculated by multiplying the minority interest percentage of VMware, Inc., Pivotal Software, Inc., and SecureWorks Corp. by their non-GAAP net income adjustments for the period presented.

[0001571996-20-000048:8k_2_02:145]
(b)     Incremental dilution from VMware, Inc. attributable to Dell Technologies Inc. represents the impact of VMware, Inc.’s dilutive securities on the diluted earnings per share of Dell Technologies Inc. and is calculated by multiplying the difference between VMware, Inc.’s basic and diluted earnings per share by the number of shares of VMware, Inc. common stock held by Dell Technologies Inc.

[0001571996-20-000048:8k_2_02:146]
17
