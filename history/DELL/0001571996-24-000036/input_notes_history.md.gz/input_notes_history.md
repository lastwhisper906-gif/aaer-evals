# DELL note change history — 0001571996-23-000032 → 0001571996-23-000046


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2023-12-08):
[0001571996-23-000046:note_history:1]
COMMITMENTS AND CONTINGENCIES 
Purchase Obligations
  (was, 2023-09-12, similarity 0.7527):
[0001571996-23-000032:note_history:1]
COMMITMENTS AND CONTINGENCIES 
Legal Matters

- added (2023-12-08):
[0001571996-23-000046:note_history:2]
The Company has contractual obligations to purchase goods or services, which specify significant terms (including fixed or minimum quantities to be purchased), fixed, minimum, or variable price provisions; and the approximate timing of the transaction.  As of November 3, 2023, such purchase obligations were $3.8 billion for the remaining three months of Fiscal 2024; $0.8 billion for Fiscal 2025; and $0.6 billion for Fiscal 2026 and thereafter.

- added (2023-12-08):
[0001571996-23-000046:note_history:3]
Legal Matters

- added (2023-12-08):
[0001571996-23-000046:note_history:4]
On May 16, 2023, during the second quarter of Fiscal 2024, the Company paid the settlement amount following approval of the settlement by the Delaware Court of Chancery.  The payment is reflected within cash flows from operating activities within the Condensed Consolidated Statements of Cash Flows.  The Company does not expect to incur additional expenses with respect to the settlement.

- added (2023-12-08):
[0001571996-23-000046:note_history:5]
In accordance with the relevant accounting guidance, the Company provides disclosures of matters where it is at least reasonably possible that the Company could experience a material loss exceeding the amounts already accrued for these or other proceedings or matters.  In addition, the Company also discloses matters based on its consideration of other matters and qualitative factors, including the experience of other companies in the industry, and investor, customer, and employee relations considerations.  As of November 3, 2023, the Company does not believe there is a reasonable possibility that a material loss exceeding the amounts already accrued for these or other proceedings or matters has been incurred.  However, since the ultimate resolution of any such proceedings and matters is inherently unpredictable, the Company’s business, financial condition, results of operations, or cash flows could be materially affected in any particular period by unfavorable outcomes in one or more of these proceedings or matters.  Whether the outcome of any claim, suit, assessment, investigation, or legal proceeding, individually or collectively, could have a material adverse effect on the Company’s business, financial condition, results of operations, or cash flows will depend on a number of factors, including the nature, timing, and amount of any associated expenses, amounts paid in settlement, damages, or other remedies or consequences.

- changed (2023-12-08):
[0001571996-23-000046:note_history:6]
Under the Separation and Distribution Agreement entered into with VMware, Inc. upon the completion of the spin-off of VMware, Inc. by means of a special stock dividend (the “VMware Spin-off”) on November 1, 2021, Dell Technologies agreed to indemnify VMware, Inc., each of its subsidiaries and each of their respective directors, officers, and employees from and against all liabilities relating to, arising out of or resulting from, among other matters, the liabilities allocated to Dell Technologies as part of the separation of Dell Technologies and VMware, Inc. (individually and together with its subsidiaries, “VMware”) and their respective businesses (the “Separation”). VMware similarly agreed to indemnify Dell Technologies Inc., each of its subsidiaries and each of their respective directors, officers, and employees from and against all liabilities relating to, arising out of or resulting from, among other matters, the liabilities allocated to VMware as part of the Separation. Dell Technologies expects VMware to fully perform under the terms of the Separation and Distribution Agreement.
  (was, 2023-09-12, similarity 0.9964):
[0001571996-23-000032:note_history:6]
Under the Separation and Distribution Agreement entered into with VMware, Inc. upon the completion of the spin-off of VMware, Inc. by means of a special stock dividend (the “VMware Spin-off”) on November 1, 2021, Dell Technologies has agreed to indemnify VMware, Inc., each of its subsidiaries and each of their respective directors, officers, and employees from and against all liabilities relating to, arising out of or resulting from, among other matters, the liabilities allocated to Dell Technologies as part of the separation of Dell Technologies and VMware, Inc. (individually and together with its subsidiaries, “VMware”) and their respective businesses (the “Separation”). VMware similarly has agreed to indemnify Dell Technologies Inc., each of its subsidiaries and each of their respective directors, officers, and employees from and against all liabilities relating to, arising out of or resulting from, among other matters, the liabilities allocated to VMware as part of the Separation.  Dell Technologies expects VMware to fully perform under the terms of the Separation and Distribution Agreement.

- removed (2023-12-08):
[0001571996-23-000032:note_history:7]
On May 16, 2023, the Company paid the settlement amount following approval of the settlement by the Delaware Court of Chancery.  The payment is reflected within cash flows from operating activities within the Condensed Consolidated Statements of Cash Flows.  The Company does not expect to incur additional expenses with respect to the settlement.

- removed (2023-12-08):
[0001571996-23-000032:note_history:8]
In accordance with the relevant accounting guidance, the Company provides disclosures of matters where it is at least reasonably possible that the Company could experience a material loss exceeding the amounts already accrued for these or other proceedings or matters.  In addition, the Company also discloses matters based on its consideration of other matters and qualitative factors, including the experience of other companies in the industry, and investor, customer, and employee relations considerations.  As of August 4, 2023, the Company does not believe there is a reasonable possibility that a material loss exceeding the amounts already accrued for these or other proceedings or matters has been incurred.  However, since the ultimate resolution of any such proceedings and matters is inherently unpredictable, the Company’s business, financial condition, results of operations, or cash flows could be materially affected in any particular period by unfavorable outcomes in one or more of these proceedings or matters.  Whether the outcome of any claim, suit, assessment, investigation, or legal proceeding, individually or collectively, could have a material adverse effect on the Company’s business, financial condition, results of operations, or cash flows will depend on a number of factors, including the nature, timing, and amount of any associated expenses, amounts paid in settlement, damages, or other remedies or consequences.


## dell:CreditLossFinancialInstrumentLeasesDebtVariableInterestEntitiesAndCustomerReceivablesSalesTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-12-08):
[0001571996-23-000046:note_history:9]
Financing options are offered to our customers primarily through Dell Financial Services and its affiliates (“DFS”).  The Company also arranges financing for some of its customers in various countries where DFS does not currently operate as a captive enterprise.  The key activities of DFS include originating, collecting, and servicing customer financing arrangements primarily related to the purchase or use of Dell Technologies products and services.  In some cases, DFS also offers financing for the purchase of third-party technology products that complement the Dell Technologies portfolio of products and services.  New financing originations were $1.8 billion and $2.3 billion for the three months ended November 3, 2023 and October 28, 2022, respectively, and $6.0 billion and $6.7 billion for the nine months ended November 3, 2023 and October 28, 2022, respectively.
  (was, 2023-09-12, similarity 0.8648):
[0001571996-23-000032:note_history:9]
Financing options are offered to our customers primarily through Dell Financial Services and its affiliates (“DFS”).  The Company also arranges financing for some of its customers in various countries where DFS does not currently operate as a captive enterprise.  The key activities of DFS include originating, collecting, and servicing customer financing arrangements primarily related to the purchase or use of Dell Technologies products and services.  In some cases, DFS also offers financing for the purchase of third-party technology products that complement the Dell Technologies portfolio of products and services.  New financing originations were $2.4 billion and $2.3 billion for the three months ended August 4, 2023 and July 29, 2022, respectively, and $4.2 billion and $4.4 billion for the six months ended August 4, 2023 and July 29, 2022, respectively.

- added (2023-12-08):
[0001571996-23-000046:note_history:10]
Revolving loans — Revolving loans offered under a private label credit financing program,  referred to as Dell Business Credit (“DBC”), provide qualified customers with a revolving credit line for the purchase of products and services offered by Dell Technologies.  The DBC product is primarily offered to small and medium-sized commercial customers.  Revolving loans in the United States bear interest at a variable annual percentage rate that is tied to the prime rate.  Based on historical payment patterns, revolving loan transactions are typically repaid within twelve months on average.  Due to the short-term nature of the revolving loan portfolio, the carrying value of the portfolio approximates fair value.

- added (2023-12-08):
[0001571996-23-000046:note_history:11]
Prior to the sale of the U.S. consumer revolving customer receivables portfolio described in Note 1 of the Notes to the Condensed Consolidated Financial Statements, the Company also offered private label credit financing under the Dell Preferred Account (“DPA”) program.  The DPA product was primarily offered to individual consumer customers.

- changed (2023-12-08):
[0001571996-23-000046:note_history:12]
Flexible consumption models, as defined above, further enable the Company to offer its customers the option to pay over time to provide them with financial flexibility to meet their changing technological requirements.  Such models may result in identification of embedded lease arrangements that lead to the recognition of operating or sales-type leases.
  (was, 2023-09-12, similarity 0.9886):
[0001571996-23-000032:note_history:12]
Flexible consumption models, as defined above, enable the Company to offer its customers the option to pay over time to provide them with financial flexibility to meet their changing technological requirements.  Such models may result in identification of embedded lease arrangements that lead to the recognition of operating or sales-type leases.

- changed (2023-12-08):
[0001571996-23-000046:note_history:13]
|  | November 3, 2023 |  | February 3, 2023 |
|  | Revolving |  | Fixed-term |  | Total |  | Revolving |  | Fixed-term |  | Total |
|  | (in millions) |
| Financing receivables, net: |  |  |  |  |  |  |  |  |  |  |  |
| Customer receivables, gross (a) (b) | $ | 172 |  |  | $ | 10,144 |  |  | $ | 10,316 |  |  | $ | 685 |  |  | $ | 10,293 |  |  | $ | 10,978 |  |
| Allowances for losses | (9) |  |  | (144) |  |  | (153) |  |  | (88) |  |  | (113) |  |  | (201) |  |
| Customer receivables, net | 163 |  |  | 10,000 |  |  | 10,163 |  |  | 597 |  |  | 10,180 |  |  | 10,777 |  |
| Residual interest | — |  |  | 150 |  |  | 150 |  |  | — |  |  | 142 |  |  | 142 |  |
| Financing receivables, net | $ | 163 |  |  | $ | 10,150 |  |  | $ | 10,313 |  |  | $ | 597 |  |  | $ | 10,322 |  |  | $ | 10,919 |  |
| Short-term | $ | 163 |  |  | $ | 4,377 |  |  | $ | 4,540 |  |  | $ | 597 |  |  | $ | 4,684 |  |  | $ | 5,281 |  |
| Long-term | $ | — |  |  | $ | 5,773 |  |  | $ | 5,773 |  |  | $ | — |  |  | $ | 5,638 |  |  | $ | 5,638 |  |
  (was, 2023-09-12, similarity 0.9912):
[0001571996-23-000032:note_history:13]
|  | August 4, 2023 |  | February 3, 2023 |
|  | Revolving |  | Fixed-term |  | Total |  | Revolving |  | Fixed-term |  | Total |
|  | (in millions) |
| Financing receivables, net: |  |  |  |  |  |  |  |  |  |  |  |
| Customer receivables, gross (a) (b) | $ | 180 |  |  | $ | 10,439 |  |  | $ | 10,619 |  |  | $ | 685 |  |  | $ | 10,293 |  |  | $ | 10,978 |  |
| Allowances for losses | (9) |  |  | (140) |  |  | (149) |  |  | (88) |  |  | (113) |  |  | (201) |  |
| Customer receivables, net | 171 |  |  | 10,299 |  |  | 10,470 |  |  | 597 |  |  | 10,180 |  |  | 10,777 |  |
| Residual interest | — |  |  | 150 |  |  | 150 |  |  | — |  |  | 142 |  |  | 142 |  |
| Financing receivables, net | $ | 171 |  |  | $ | 10,449 |  |  | $ | 10,620 |  |  | $ | 597 |  |  | $ | 10,322 |  |  | $ | 10,919 |  |
| Short-term | $ | 171 |  |  | $ | 4,636 |  |  | $ | 4,807 |  |  | $ | 597 |  |  | $ | 4,684 |  |  | $ | 5,281 |  |
| Long-term | $ | — |  |  | $ | 5,813 |  |  | $ | 5,813 |  |  | $ | — |  |  | $ | 5,638 |  |  | $ | 5,638 |  |

- changed (2023-12-08):
[0001571996-23-000046:note_history:14]
(b)    The decrease in revolving customer financing receivables is primarily attributable to the sale of the U.S. consumer revolving customer receivables portfolio described in Note 1 of the Notes to the Condensed Consolidated Financial Statements.
  (was, 2023-09-12, similarity 0.6424):
[0001571996-23-000032:note_history:14]
(b)    The decrease in revolving customer financing receivables is attributable to the reclassification of the U.S. consumer revolving portfolio to current assets held for sale, as described above.

- added (2023-12-08):
[0001571996-23-000046:note_history:15]
|  | Three Months Ended |
|  | November 3, 2023 |  | October 28, 2022 |
|  | Revolving |  | Fixed-term |  | Total |  | Revolving |  | Fixed-term |  | Total |
|  | (in millions) |
| Allowance for financing receivable losses: |  |  |  |  |  |  |  |  |  |  |  |
| Balances at beginning of period | $ | 9 |  |  | $ | 140 |  |  | $ | 149 |  |  | $ | 91 |  |  | $ | 92 |  |  | $ | 183 |  |
| Charge-offs, net of recoveries | (4) |  |  | (3) |  |  | (7) |  |  | (12) |  |  | (1) |  |  | (13) |  |
| Provision charged to income statement | 4 |  |  | 7 |  |  | 11 |  |  | 8 |  |  | 8 |  |  | 16 |  |
| Balances at end of period | $ | 9 |  |  | $ | 144 |  |  | $ | 153 |  |  | $ | 87 |  |  | $ | 99 |  |  | $ | 186 |  |

- added (2023-12-08):
[0001571996-23-000046:note_history:16]
|  | Nine Months Ended |
|  | November 3, 2023 |  | October 28, 2022 |
|  | Revolving |  | Fixed-term |  | Total |  | Revolving |  | Fixed-term |  | Total |
|  | (in millions) |
| Allowance for financing receivable losses: |  |  |  |  |  |  |  |  |  |  |  |
| Balances at beginning of period | $ | 88 |  |  | $ | 113 |  |  | $ | 201 |  |  | $ | 102 |  |  | $ | 87 |  |  | $ | 189 |  |
| Charge-offs, net of recoveries | (37) |  |  | (5) |  |  | (42) |  |  | (37) |  |  | (5) |  |  | (42) |  |
| Provision charged to income statement | 32 |  |  | 36 |  |  | 68 |  |  | 22 |  |  | 17 |  |  | 39 |  |
| Other (a) | (74) |  |  | — |  |  | (74) |  |  | — |  |  | — |  |  | — |  |
| Balances at end of period | $ | 9 |  |  | $ | 144 |  |  | $ | 153 |  |  | $ | 87 |  |  | $ | 99 |  |  | $ | 186 |  |

- added (2023-12-08):
[0001571996-23-000046:note_history:17]
____________________

- added (2023-12-08):
[0001571996-23-000046:note_history:18]
(a)    Other represents the derecognition of the allowance for financing receivable losses related to the sale of the U.S. consumer revolving customer receivables portfolio described in Note 1 of the Notes to the Condensed Consolidated Financial Statements.

- changed (2023-12-08):
[0001571996-23-000046:note_history:19]
|  | November 3, 2023 |  | February 3, 2023 |
|  | Current |  | Past Due1 — 90 Days |  | Past Due>90 Days |  | Total |  | Current |  | Past Due1 — 90 Days |  | Past Due>90 Days |  | Total |
|  | (in millions) |
| Revolving — DPA | $ | 5 |  |  | $ | — |  |  | $ | — |  |  | $ | 5 |  |  | $ | 457 |  |  | $ | 34 |  |  | $ | 17 |  |  | $ | 508 |  |
| Revolving — DBC | 146 |  |  | 17 |  |  | 4 |  |  | 167 |  |  | 154 |  |  | 19 |  |  | 4 |  |  | 177 |  |
| Fixed-term — Consumer and Commercial | 9,140 |  |  | 868 |  |  | 136 |  |  | 10,144 |  |  | 9,309 |  |  | 927 |  |  | 57 |  |  | 10,293 |  |
| Total customer receivables, gross | $ | 9,291 |  |  | $ | 885 |  |  | $ | 140 |  |  | $ | 10,316 |  |  | $ | 9,920 |  |  | $ | 980 |  |  | $ | 78 |  |  | $ | 10,978 |  |
  (was, 2023-09-12, similarity 0.9887):
[0001571996-23-000032:note_history:19]
|  | August 4, 2023 |  | February 3, 2023 |
|  | Current |  | Past Due1 — 90 Days |  | Past Due>90 Days |  | Total |  | Current |  | Past Due1 — 90 Days |  | Past Due>90 Days |  | Total |
|  | (in millions) |
| Revolving — DPA | $ | 7 |  |  | $ | — |  |  | $ | — |  |  | $ | 7 |  |  | $ | 457 |  |  | $ | 34 |  |  | $ | 17 |  |  | $ | 508 |  |
| Revolving — DBC | 151 |  |  | 18 |  |  | 4 |  |  | 173 |  |  | 154 |  |  | 19 |  |  | 4 |  |  | 177 |  |
| Fixed-term — Consumer and Commercial | 9,412 |  |  | 969 |  |  | 58 |  |  | 10,439 |  |  | 9,309 |  |  | 927 |  |  | 57 |  |  | 10,293 |  |
| Total customer receivables, gross | $ | 9,570 |  |  | $ | 987 |  |  | $ | 62 |  |  | $ | 10,619 |  |  | $ | 9,920 |  |  | $ | 980 |  |  | $ | 78 |  |  | $ | 10,978 |  |

- changed (2023-12-08):
[0001571996-23-000046:note_history:20]
|  | November 3, 2023 |
|  | Fixed-term — Consumer and Commercial |  |  |  |  |  |  |
|  | Fiscal Year of Origination |  |  |  |  |  |  |
|  | 2024 |  | 2023 |  | 2022 |  | 2021 |  | 2020 |  | Years Prior |  | Revolving — DPA |  | Revolving — DBC |  | Total |
|  | (in millions) |
| Higher | $ | 2,494 |  |  | $ | 2,195 |  |  | $ | 1,076 |  |  | $ | 499 |  |  | $ | 127 |  |  | $ | 3 |  |  | $ | 1 |  |  | $ | 42 |  |  | $ | 6,437 |  |
| Mid | 849 |  |  | 1,047 |  |  | 378 |  |  | 159 |  |  | 40 |  |  | 2 |  |  | 2 |  |  | 49 |  |  | 2,526 |  |
| Lower | 454 |  |  | 516 |  |  | 210 |  |  | 69 |  |  | 25 |  |  | 1 |  |  | 2 |  |  | 76 |  |  | 1,353 |  |
| Total | $ | 3,797 |  |  | $ | 3,758 |  |  | $ | 1,664 |  |  | $ | 727 |  |  | $ | 192 |  |  | $ | 6 |  |  | $ | 5 |  |  | $ | 167 |  |  | $ | 10,316 |  |
  (was, 2023-09-12, similarity 0.9888):
[0001571996-23-000032:note_history:20]
|  | August 4, 2023 |
|  | Fixed-term — Consumer and Commercial |  |  |  |  |  |  |
|  | Fiscal Year of Origination |  |  |  |  |  |  |
|  | 2024 |  | 2023 |  | 2022 |  | 2021 |  | 2020 |  | Years Prior |  | Revolving — DPA |  | Revolving — DBC |  | Total |
|  | (in millions) |
| Higher | $ | 1,997 |  |  | $ | 2,453 |  |  | $ | 1,267 |  |  | $ | 617 |  |  | $ | 206 |  |  | $ | 10 |  |  | $ | 1 |  |  | $ | 45 |  |  | $ | 6,596 |  |
| Mid | 611 |  |  | 1,205 |  |  | 480 |  |  | 214 |  |  | 63 |  |  | 5 |  |  | 3 |  |  | 50 |  |  | 2,631 |  |
| Lower | 288 |  |  | 615 |  |  | 266 |  |  | 99 |  |  | 40 |  |  | 3 |  |  | 3 |  |  | 78 |  |  | 1,392 |  |
| Total | $ | 2,896 |  |  | $ | 4,273 |  |  | $ | 2,013 |  |  | $ | 930 |  |  | $ | 309 |  |  | $ | 18 |  |  | $ | 7 |  |  | $ | 173 |  |  | $ | 10,619 |  |

- changed (2023-12-08):
[0001571996-23-000046:note_history:21]
The categories shown in the tables above segregate customer receivables based on the relative degrees of credit risk.  Credit quality indicators for DBC revolving and fixed-term accounts are generally updated on a periodic basis.
  (was, 2023-09-12, similarity 0.7443):
[0001571996-23-000032:note_history:21]
The categories shown in the tables above segregate customer receivables based on the relative degrees of credit risk.  The credit quality indicators for DPA revolving accounts are measured primarily as of each quarter-end date, while all other indicators are generally updated on a periodic basis.

- added (2023-12-08):
[0001571996-23-000046:note_history:22]
For the DBC revolving receivables and fixed-term commercial receivables shown in the table above, an internal grading system is utilized that assigns a credit level score based on a number of considerations, including liquidity, operating performance, and industry outlook.  The grading criteria and classifications for the fixed-term products differ from those for the revolving products as loss experience varies between these product and customer groups.  The credit quality categories cannot be compared between the different classes as loss experience varies substantially between the classes.  Prior to the sale of the U.S. consumer revolving customer receivables revolving portfolio described in Note 1 of the Notes to the Condensed Consolidated Financial Statements, the Company made credit decisions based on proprietary scorecards, which included the customer’s credit history, payment history, credit usage, and other credit agency-related elements.  The higher quality category included prime accounts generally comparable to U.S. customer FICO scores of 720 or above.  The mid category represented mid-tier accounts that are comparable to U.S. customer FICO scores from 660 to 719.  The lower category represented accounts that are comparable to U.S. customer FICO scores below 660.

- changed (2023-12-08):
[0001571996-23-000046:note_history:23]
|  | Three Months Ended |  | Nine Months Ended |
|  | November 3, 2023 |  | October 28, 2022 |  | November 3, 2023 |  | October 28, 2022 |
|  | (in millions) |
| Net revenue — products | $ | 227 |  |  | $ | 207 |  |  | $ | 766 |  |  | $ | 646 |  |
| Cost of net revenue — products | 176 |  |  | 164 |  |  | 564 |  |  | 532 |  |
| Gross margin — products | $ | 51 |  |  | $ | 43 |  |  | $ | 202 |  |  | $ | 114 |  |
  (was, 2023-09-12, similarity 0.837):
[0001571996-23-000032:note_history:23]
|  | Three Months Ended |  | Six Months Ended |
|  | August 4, 2023 |  | July 29, 2022 |  | August 4, 2023 |  | July 29, 2022 |
|  | (in millions) |
| Net revenue — products | $ | 292 |  |  | $ | 219 |  |  | $ | 539 |  |  | $ | 439 |  |
| Cost of net revenue — products | 192 |  |  | 164 |  |  | 388 |  |  | 368 |  |
| Gross margin — products | $ | 100 |  |  | $ | 55 |  |  | $ | 151 |  |  | $ | 71 |  |

- changed (2023-12-08):
[0001571996-23-000046:note_history:24]
|  | November 3, 2023 |
|  | (in millions) |
| Fiscal 2024 (remaining three months) | $ | 809 |  |
| Fiscal 2025 | 2,221 |  |
| Fiscal 2026 | 1,712 |  |
| Fiscal 2027 | 971 |  |
| Fiscal 2028 and beyond | 388 |  |
| Total undiscounted cash flows | 6,101 |  |
| Fixed-term loans | 4,954 |  |
| Revolving loans | 172 |  |
| Less: Unearned income | (911) |  |
| Total customer receivables, gross | $ | 10,316 |  |
  (was, 2023-09-12, similarity 0.6704):
[0001571996-23-000032:note_history:24]
|  | August 4, 2023 |
|  | (in millions) |
| Fiscal 2024 (remaining six months) | $ | 623 |  |
| Fiscal 2025 | 918 |  |
| Fiscal 2026 | 544 |  |
| Fiscal 2027 | 192 |  |
| Fiscal 2028 and beyond | 71 |  |
| Total | $ | 2,348 |  |

- changed (2023-12-08):
[0001571996-23-000046:note_history:25]
|  | November 3, 2023 |  | February 3, 2023 |
|  | (in millions) |
| Equipment under operating lease, gross | $ | 3,855 |  |  | $ | 3,725 |  |
| Less: Accumulated depreciation | (1,721) |  |  | (1,517) |  |
| Equipment under operating lease, net | $ | 2,134 |  |  | $ | 2,208 |  |
  (was, 2023-09-12, similarity 0.9702):
[0001571996-23-000032:note_history:25]
|  | August 4, 2023 |  | February 3, 2023 |
|  | (in millions) |
| Equipment under operating lease, gross | $ | 3,833 |  |  | $ | 3,725 |  |
| Less: Accumulated depreciation | (1,687) |  |  | (1,517) |  |
| Equipment under operating lease, net | $ | 2,146 |  |  | $ | 2,208 |  |

- changed (2023-12-08):
[0001571996-23-000046:note_history:26]
|  | Three Months Ended |  | Nine Months Ended |
|  | November 3, 2023 |  | October 28, 2022 |  | November 3, 2023 |  | October 28, 2022 |
|  | (in millions) |
| Income related to lease payments | $ | 341 |  |  | $ | 297 |  |  | $ | 992 |  |  | $ | 782 |  |
| Depreciation expense | $ | 234 |  |  | $ | 212 |  |  | $ | 703 |  |  | $ | 571 |  |
  (was, 2023-09-12, similarity 0.8035):
[0001571996-23-000032:note_history:26]
|  | Three Months Ended |  | Six Months Ended |
|  | August 4, 2023 |  | July 29, 2022 |  | August 4, 2023 |  | July 29, 2022 |
|  | (in millions) |
| Income related to lease payments | $ | 330 |  |  | $ | 253 |  |  | $ | 651 |  |  | $ | 485 |  |
| Depreciation expense | $ | 236 |  |  | $ | 194 |  |  | $ | 469 |  |  | $ | 359 |  |

- changed (2023-12-08):
[0001571996-23-000046:note_history:27]
The following table presents the future payments to be received by the Company in operating lease contracts as of the date indicated:
  (was, 2023-09-12, similarity 0.9638):
[0001571996-23-000032:note_history:27]
The following table presents the future payments to be received by the Company as lessor in operating lease contracts as of the date indicated:

- added (2023-12-08):
[0001571996-23-000046:note_history:28]
|  | November 3, 2023 |
|  | (in millions) |
| Fiscal 2024 (remaining three months) | $ | 330 |  |
| Fiscal 2025 | 974 |  |
| Fiscal 2026 | 628 |  |
| Fiscal 2027 | 272 |  |
| Fiscal 2028 and beyond | 113 |  |
| Total | $ | 2,317 |  |

- changed (2023-12-08):
[0001571996-23-000046:note_history:29]
|  | November 3, 2023 |  | February 3, 2023 |
| DFS debt | (in millions) |
| DFS U.S. debt: |  |  |  |
| Asset-based financing and securitization facilities | $ | 2,443 |  |  | $ | 3,987 |  |
| Fixed-term securitization offerings | 3,715 |  |  | 2,679 |  |
| Other | 31 |  |  | 76 |  |
| Total DFS U.S. debt | 6,189 |  |  | 6,742 |  |
| DFS international debt: |  |  |  |
| Securitization facility | 749 |  |  | 790 |  |
| Other borrowings | 839 |  |  | 871 |  |
| Note payable | 250 |  |  | 250 |  |
| Dell Bank senior unsecured eurobonds | 1,593 |  |  | 1,637 |  |
| Total DFS international debt | 3,431 |  |  | 3,548 |  |
| Total DFS debt | $ | 9,620 |  |  | $ | 10,290 |  |
| Total short-term DFS debt | $ | 5,374 |  |  | $ | 5,400 |  |
| Total long-term DFS debt | $ | 4,246 |  |  | $ | 4,890 |  |
  (was, 2023-09-12, similarity 0.9896):
[0001571996-23-000032:note_history:29]
|  | August 4, 2023 |  | February 3, 2023 |
| DFS debt | (in millions) |
| DFS U.S. debt: |  |  |  |
| Asset-based financing and securitization facilities | $ | 3,067 |  |  | $ | 3,987 |  |
| Fixed-term securitization offerings | 3,471 |  |  | 2,679 |  |
| Other | 58 |  |  | 76 |  |
| Total DFS U.S. debt | 6,596 |  |  | 6,742 |  |
| DFS international debt: |  |  |  |
| Securitization facility | 793 |  |  | 790 |  |
| Other borrowings | 762 |  |  | 871 |  |
| Note payable | 250 |  |  | 250 |  |
| Dell Bank senior unsecured eurobonds | 1,642 |  |  | 1,637 |  |
| Total DFS international debt | 3,447 |  |  | 3,548 |  |
| Total DFS debt | $ | 10,043 |  |  | $ | 10,290 |  |
| Total short-term DFS debt | $ | 5,801 |  |  | $ | 5,400 |  |
| Total long-term DFS debt | $ | 4,242 |  |  | $ | 4,890 |  |

- changed (2023-12-08):
[0001571996-23-000046:note_history:30]
Asset-Based Financing and Securitization Facilities — The Company maintains separate asset-based financing facilities in the United States, which are revolving facilities for fixed-term leases and loans.  This debt is collateralized solely by the U.S. loan and lease payments and associated equipment in the facilities.  The debt has a variable interest rate, and the duration of the debt is based on the terms of the underlying loan and lease payment streams.  As of November 3, 2023, the total debt capacity related to the U.S. asset-based financing facilities was $5.1 billion.  The Company enters into interest swap agreements to effectively convert a portion of this debt from a floating rate to a fixed rate.  See Note 7 of the Notes to the Condensed Consolidated Financial Statements for additional information about the Company’s interest rate swaps.
  (was, 2023-09-12, similarity 0.9342):
[0001571996-23-000032:note_history:30]
Asset-Based Financing and Securitization Facilities — The Company maintains separate asset-based financing facilities and a securitization facility in the United States, which are revolving facilities for fixed-term leases and loans and for revolving loans, respectively.  This debt is collateralized solely by the U.S. loan and lease payments and associated equipment in the facilities.  The debt has a variable interest rate and the duration of the debt is based on the terms of the underlying loan and lease payment streams.  As of August 4, 2023, the total debt capacity related to the U.S. asset-based financing and securitization facilities was $5.6 billion.  The Company enters into interest swap agreements to effectively convert a portion of this debt from a floating rate to a fixed rate.  See Note 7 of the Notes to the Condensed Consolidated Financial Statements for additional information about interest rate swaps.

- added (2023-12-08):
[0001571996-23-000046:note_history:31]
The Company’s two U.S. asset-based financing facilities for fixed-term leases and loans are effective through July 7, 2025 and June 21, 2024, respectively.  The asset-based financing facilities contain standard structural features related to the performance of the funded receivables, which include defined credit losses, delinquencies, average credit scores, and minimum collection requirements.  In the event one or more of these criteria are not met and the Company is unable to restructure the facility, no further funding of receivables will be permitted and the timing of the Company’s expected cash flows from over-collateralization will be delayed.  As of November 3, 2023, these criteria were met.

- added (2023-12-08):
[0001571996-23-000046:note_history:32]
The Company previously maintained a U.S. securitization facility for revolving loans effective through June 25, 2025.  In connection with the sale of the U.S. consumer revolving customer receivables portfolio described in Note 1 of the Notes to the Condensed Consolidated Financial Statements, the Company’s U.S. securitization facility for revolving loans was paid down and terminated during the three months ended November 3, 2023.

- changed (2023-12-08):
[0001571996-23-000046:note_history:33]
Fixed-Term Securitization Offerings — The Company periodically issues asset-backed debt securities under fixed-term securitization programs to private investors.  The asset-backed debt securities are collateralized solely by the U.S. fixed-term lease and loan payments and associated equipment, which are held by Special Purpose Entities (“SPEs”), as discussed below.  The interest rate on these securities is fixed and ranges from 0.53% to 6.80% per annum as of November 3, 2023, and the duration of these securities is based on the terms of the underlying lease and loan payment streams.
  (was, 2023-09-12, similarity 0.9878):
[0001571996-23-000032:note_history:33]
Fixed-Term Securitization Offerings — The Company periodically issues asset-backed debt securities under fixed-term securitization programs to private investors.  The asset-backed debt securities are collateralized solely by the U.S. fixed-term lease and loan payments and associated equipment, which are held by Special Purpose Entities (“SPEs”), as discussed below.  The interest rate on these securities is fixed and ranges from 0.43% to 6.80% per annum as of August 4, 2023, and the duration of these securities is based on the terms of the underlying lease and loan payment streams.

- changed (2023-12-08):
[0001571996-23-000046:note_history:34]
Securitization Facility — The Company maintains a securitization facility in Europe for fixed-term leases and loans.  The debt under this facility has a variable interest rate, and the duration of the debt is based on the terms of the underlying loan and lease payment streams.  This facility is effective through December 23, 2024 and had a total debt capacity of $850 million as of November 3, 2023.
  (was, 2023-09-12, similarity 0.9715):
[0001571996-23-000032:note_history:34]
Securitization Facility — The Company maintains a securitization facility in Europe for fixed-term leases and loans.  The debt under this facility has a variable interest rate, and the duration of the debt is based on the terms of the underlying loan and lease payment streams.  This facility is effective through December 23, 2024 and had a total debt capacity of $876 million as of August 4, 2023.

- changed (2023-12-08):
[0001571996-23-000046:note_history:35]
The securitization facility contains standard structural features related to the performance of the securitized receivables, which include defined credit losses, delinquencies, average credit scores, and minimum collection requirements.  In the event one or more of these criteria are not met and the Company is unable to restructure the program, no further funding of receivables will be permitted and the timing of the Company’s expected cash flows from over-collateralization will be delayed.  As of November 3, 2023, these criteria were met.
  (was, 2023-09-12, similarity 0.987):
[0001571996-23-000032:note_history:35]
The securitization facility contains standard structural features related to the performance of the securitized receivables, which include defined credit losses, delinquencies, average credit scores, and minimum collection requirements.  In the event one or more of these criteria are not met and the Company is unable to restructure the program, no further funding of receivables will be permitted and the timing of the Company’s expected cash flows from over-collateralization will be delayed.  As of August 4, 2023, these criteria were met.

- changed (2023-12-08):
[0001571996-23-000046:note_history:36]
Other Borrowings — In connection with the Company’s international financing operations, the Company has entered into revolving structured financing debt programs related to its fixed-term lease and loan products sold in Canada, Europe, Australia, New Zealand, and the Middle East.  The debt under these programs has a variable interest rate, and the duration of the debt is based on the terms of the underlying loan and lease payment streams.  The Canadian facility, which is collateralized solely by Canadian loan and lease payments and associated equipment, had a total debt capacity of $328 million as of November 3, 2023 and is effective through January 16, 2025.  The European facility, which is collateralized solely by European loan and lease payments and associated equipment, had a total debt capacity of $531 million as of November 3, 2023 and is effective through June 14, 2025.  The Australia and New Zealand facility, which is collateralized solely by Australia and New Zealand loan and lease payments and associated equipment, had a total debt capacity of $290 million as of November 3, 2023 and is effective through April 20, 2025. The Middle East facility, which is collateralized solely by Middle East loan and lease payments and associated equipment, had a total debt capacity of $150 million as of November 3, 2023 and is effective through March 24, 2025.
  (was, 2023-09-12, similarity 0.6168):
[0001571996-23-000032:note_history:36]
Other Borrowings — In connection with the Company’s international financing operations, the Company has entered into revolving structured financing debt programs related to its fixed-term lease and loan products sold in Canada, Europe, Australia, New Zealand, and the Middle East.  The debt under these programs has a variable interest rate, and the duration of the debt is based on the terms of the underlying loan and lease payment streams.  The Canadian facility, which is collateralized solely by Canadian loan and lease payments and associated equipment, had a total debt capacity of $337 million as of August 4, 2023 and is effective through January 16, 2025.  The European facility, which is collateralized solely by European loan and lease payments and associated equipment, had a total debt capacity of $657 million as of August 4, 2023 and is effective through June 14, 2025.  The Australia and New Zealand facility, which is collateralized solely by Australia and New Zealand loan and lease payments and associated equipment, had a total debt capacity of $295 million as of August 4, 2023 and is effective through April 20, 2025. The Middle East facility, which is collateralized solely by Middle East loan and lease payments and associated equipment, had a total debt capacity of $150 million as of August 4, 2023 and is effective through March 24, 2025.

- changed (2023-12-08):
[0001571996-23-000046:note_history:37]
Note Payable — On May 25, 2022, the Company entered into an unsecured credit agreement to fund receivables in Mexico.  As of November 3, 2023, the aggregate principal amount of the note payable was $250 million.  The note bears interest at an annual rate of 4.24% and will mature on May 31, 2024.
  (was, 2023-09-12, similarity 0.9742):
[0001571996-23-000032:note_history:37]
Note Payable — On May 25, 2022, the Company entered into an unsecured credit agreement to fund receivables in Mexico.  As of August 4, 2023, the aggregate principal amount of the note payable was $250 million.  The note bears interest at an annual rate of 4.24% and will mature on May 31, 2024.

- changed (2023-12-08):
[0001571996-23-000046:note_history:38]
|  | November 3, 2023 |  | February 3, 2023 |
|  | (in millions) |
| Assets held by consolidated VIEs |  |  |  |
| Other current assets | $ | 146 |  |  | $ | 274 |  |
| Financing receivables, net of allowance |  |  |  |
| Short-term | $ | 3,059 |  |  | $ | 3,702 |  |
| Long-term | $ | 3,261 |  |  | $ | 3,295 |  |
| Property, plant, and equipment, net | $ | 1,097 |  |  | $ | 1,164 |  |
| Liabilities held by consolidated VIEs |  |  |  |
| Debt, net of unamortized debt issuance costs |  |  |  |
| Short-term | $ | 4,138 |  |  | $ | 4,761 |  |
| Long-term | $ | 2,753 |  |  | $ | 2,685 |  |
  (was, 2023-09-12, similarity 0.6986):
[0001571996-23-000032:note_history:38]
|  | August 4, 2023 |  | February 3, 2023 |
|  | (in millions) |
| Assets held by consolidated VIEs |  |  |  |
| Other current assets | $ | 282 |  |  | $ | 274 |  |
| Current assets held for sale | $ | 366 |  |  | $ | — |  |
| Financing receivables, net of allowance |  |  |  |
| Short-term | $ | 3,256 |  |  | $ | 3,702 |  |
| Long-term | $ | 3,298 |  |  | $ | 3,295 |  |
| Property, plant, and equipment, net | $ | 1,142 |  |  | $ | 1,164 |  |
| Liabilities held by consolidated VIEs |  |  |  |
| Debt, net of unamortized debt issuance costs |  |  |  |
| Short-term | $ | 4,556 |  |  | $ | 4,761 |  |
| Long-term | $ | 2,760 |  |  | $ | 2,685 |  |

- added (2023-12-08):
[0001571996-23-000046:note_history:39]
Lease and loan payments and associated equipment transferred via securitization through SPEs were $1.1 billion and $1.6 billion for the three months ended November 3, 2023 and October 28, 2022, respectively, and $3.7 billion and $4.5 billion for the nine months ended November 3, 2023 and October 28, 2022, respectively.

- changed (2023-12-08):
[0001571996-23-000046:note_history:40]
To manage certain concentrations of customer credit exposure, the Company may sell selected fixed-term customer receivables to unrelated third parties on a periodic basis, without recourse.  The amount of customer receivables sold for this purpose was $205 million and $431 million for the nine months ended November 3, 2023 and October 28, 2022, respectively.  The Company’s continuing involvement in these customer receivables is primarily limited to servicing arrangements.
  (was, 2023-09-12, similarity 0.628):
[0001571996-23-000032:note_history:40]
To manage certain concentrations of customer credit exposure, the Company may sell selected fixed-term customer receivables to unrelated third parties on a periodic basis, without recourse.  The amount of customer receivables sold for this purpose was $187 million and $425 million for the six months ended August 4, 2023 and July 29, 2022, respectively.  The Company’s continuing involvement in these customer receivables is primarily limited to servicing arrangements.

- removed (2023-12-08):
[0001571996-23-000032:note_history:41]
Revolving loans — Revolving loans offered under private label credit financing programs provide qualified customers with a revolving credit line for the purchase of products and services offered by Dell Technologies.  These private label credit financing programs are referred to as Dell Preferred Account (“DPA”) and Dell Business Credit (“DBC”).  The DPA product is primarily offered to individual consumer customers, and the DBC product is primarily offered to small and medium-sized commercial customers.  Revolving loans in the United States bear interest at a variable annual percentage rate that is tied to the prime rate.  Based on historical payment patterns, revolving loan transactions are typically repaid within twelve months on average.  Due to the short-term nature of the revolving loan portfolio, the carrying value of the portfolio approximates fair value.

- removed (2023-12-08):
[0001571996-23-000032:note_history:42]
As described in Note 1 to the Notes to the Condensed Consolidated Financial Statements, on July 12, 2023, the Company entered into a definitive agreement with Comenity Capital Bank, a subsidiary of Bread Financial Holdings, Inc., to establish a new U.S. DPA program under which transactions will be originated, owned, serviced, and collected by Bread. Under the definitive agreement, the Company will also sell its U.S. consumer revolving customer receivables portfolio. Upon the completion of the sale, such receivables will be serviced by Bread and the Company will have no continuing involvement.  The transaction is expected to close in the third quarter of Fiscal 2024, subject to customary closing conditions.

- removed (2023-12-08):
[0001571996-23-000032:note_history:43]
In accordance with applicable accounting guidance, the Company concluded that the U.S. consumer revolving customer financing receivables have met the criteria to be classified as held for sale as of August 4, 2023. Accordingly, the Company reclassified $389 million, net of allowance, to current assets held for sale on the Condensed Consolidated Statements of Financial Position as of August 4, 2023.

- removed (2023-12-08):
[0001571996-23-000032:note_history:44]
|  | Three Months Ended |
|  | August 4, 2023 |  | July 29, 2022 |
|  | Revolving |  | Fixed-term |  | Total |  | Revolving |  | Fixed-term |  | Total |
|  | (in millions) |
| Allowance for financing receivable losses: |  |  |  |  |  |  |  |  |  |  |  |
| Balances at beginning of period | $ | 84 |  |  | $ | 135 |  |  | $ | 219 |  |  | $ | 94 |  |  | $ | 87 |  |  | $ | 181 |  |
| Charge-offs, net of recoveries | (16) |  |  | (1) |  |  | (17) |  |  | (12) |  |  | (2) |  |  | (14) |  |
| Provision charged to income statement | 15 |  |  | 6 |  |  | 21 |  |  | 9 |  |  | 7 |  |  | 16 |  |
| Held for sale adjustment | (74) |  |  | — |  |  | (74) |  |  | — |  |  | — |  |  | — |  |
| Balances at end of period | $ | 9 |  |  | $ | 140 |  |  | $ | 149 |  |  | $ | 91 |  |  | $ | 92 |  |  | $ | 183 |  |

- removed (2023-12-08):
[0001571996-23-000032:note_history:45]
|  | Six Months Ended |
|  | August 4, 2023 |  | July 29, 2022 |
|  | Revolving |  | Fixed-term |  | Total |  | Revolving |  | Fixed-term |  | Total |
|  | (in millions) |
| Allowance for financing receivable losses: |  |  |  |  |  |  |  |  |  |  |  |
| Balances at beginning of period | $ | 88 |  |  | $ | 113 |  |  | $ | 201 |  |  | $ | 102 |  |  | $ | 87 |  |  | $ | 189 |  |
| Charge-offs, net of recoveries | (33) |  |  | (2) |  |  | (35) |  |  | (25) |  |  | (4) |  |  | (29) |  |
| Provision charged to income statement | 28 |  |  | 29 |  |  | 57 |  |  | 14 |  |  | 9 |  |  | 23 |  |
| Held for sale adjustment | (74) |  |  | — |  |  | (74) |  |  | — |  |  | — |  |  | — |  |
| Balances at end of period | $ | 9 |  |  | $ | 140 |  |  | $ | 149 |  |  | $ | 91 |  |  | $ | 92 |  |  | $ | 183 |  |

- removed (2023-12-08):
[0001571996-23-000032:note_history:46]
For DPA revolving receivables, the Company makes credit decisions based on proprietary scorecards, which include the customer’s credit history, payment history, credit usage, and other credit agency-related elements.  The higher quality category includes prime accounts generally comparable to U.S. customer FICO scores of 720 or above.  The mid category represents the mid-tier accounts that are comparable to U.S. customer FICO scores from 660 to 719.  The lower category is generally sub-prime and represents accounts that are comparable to U.S. customer FICO scores below 660.  For the DBC revolving receivables and fixed-term commercial receivables shown in the table above, an internal grading system is utilized that assigns a credit level score based on a number of considerations, including liquidity, operating performance, and industry outlook.  The grading criteria and classifications for the fixed-term products differ from those for the revolving products as loss experience varies between these product and customer groups.  The credit quality categories cannot be compared between the different classes as loss experience varies substantially between the classes.

- removed (2023-12-08):
[0001571996-23-000032:note_history:47]
|  | August 4, 2023 |
|  | (in millions) |
| Fiscal 2024 (remaining six months) | $ | 1,445 |  |
| Fiscal 2025 | 2,063 |  |
| Fiscal 2026 | 1,540 |  |
| Fiscal 2027 | 822 |  |
| Fiscal 2028 and beyond | 297 |  |
| Total undiscounted cash flows | 6,167 |  |
| Fixed-term loans | 5,163 |  |
| Revolving loans | 180 |  |
| Less: Unearned income | (891) |  |
| Total customer receivables, gross | $ | 10,619 |  |

- removed (2023-12-08):
[0001571996-23-000032:note_history:48]
The Company’s two U.S. asset-based financing facilities for fixed-term leases and loans are effective through July 7, 2025 and June 21, 2024, respectively.  The Company’s U.S. securitization facility for revolving loans is effective through June 25, 2025.  The Company intends to pay down the U.S. securitization facility for revolving loans prior to the close of the U.S. consumer revolving customer receivables portfolio sale described above.

- removed (2023-12-08):
[0001571996-23-000032:note_history:49]
The asset-based financing and securitization facilities contain standard structural features related to the performance of the funded receivables, which include defined credit losses, delinquencies, average credit scores, and minimum collection requirements.  In the event one or more of these criteria are not met and the Company is unable to restructure the facility, no further funding of receivables will be permitted and the timing of the Company’s expected cash flows from over-collateralization will be delayed.  As of August 4, 2023, these criteria were met.

- removed (2023-12-08):
[0001571996-23-000032:note_history:50]
Lease and loan payments and associated equipment transferred via securitization through SPEs were $1.1 billion and $1.2 billion for the three months ended August 4, 2023 and July 29, 2022, respectively, and $2.6 billion and $2.9 billion for the six months ended August 4, 2023 and July 29, 2022, respectively.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-12-08):
[0001571996-23-000046:note_history:51]
|  | November 3, 2023 |  | February 3, 2023 |
|  | (in millions) |
| Senior Notes: |  |  |  |
| 5.45% due June 2023 | $ | — |  |  | $ | 1,000 |  |
| 4.00% due July 2024 | 1,000 |  |  | 1,000 |  |
| 5.85% due July 2025 | 1,000 |  |  | 1,000 |  |
| 6.02% due June 2026 | 3,500 |  |  | 4,500 |  |
| 4.90% due October 2026 | 1,750 |  |  | 1,750 |  |
| 6.10% due July 2027 | 500 |  |  | 500 |  |
| 5.25% due February 2028 | 1,000 |  |  | 1,000 |  |
| 5.30% due October 2029 | 1,750 |  |  | 1,750 |  |
| 6.20% due July 2030 | 750 |  |  | 750 |  |
| 5.75% due February 2033 | 1,000 |  |  | 1,000 |  |
| 8.10% due July 2036 | 1,000 |  |  | 1,000 |  |
| 3.38% due December 2041 | 962 |  |  | 1,000 |  |
| 8.35% due July 2046 | 800 |  |  | 800 |  |
| 3.45% due December 2051 | 1,095 |  |  | 1,250 |  |
| Legacy Notes and Debentures: |  |  |  |
| 7.10% due April 2028 | 300 |  |  | 300 |  |
| 6.50% due April 2038 | 388 |  |  | 388 |  |
| 5.40% due September 2040 | 264 |  |  | 264 |  |
| DFS Debt (Note 4) | 9,620 |  |  | 10,290 |  |
| Other | 181 |  |  | 325 |  |
| Total debt, principal amount | $ | 26,860 |  |  | $ | 29,867 |  |
| Unamortized discount, net of unamortized premium | (117) |  |  | (133) |  |
| Debt issuance costs | (126) |  |  | (146) |  |
| Total debt, carrying value | $ | 26,617 |  |  | $ | 29,588 |  |
| Total short-term debt, carrying value | $ | 6,498 |  |  | $ | 6,573 |  |
| Total long-term debt, carrying value | $ | 20,119 |  |  | $ | 23,015 |  |
  (was, 2023-09-12, similarity 0.9937):
[0001571996-23-000032:note_history:51]
|  | August 4, 2023 |  | February 3, 2023 |
|  | (in millions) |
| Senior Notes: |  |  |  |
| 5.45% due June 2023 | $ | — |  |  | $ | 1,000 |  |
| 4.00% due July 2024 | 1,000 |  |  | 1,000 |  |
| 5.85% due July 2025 | 1,000 |  |  | 1,000 |  |
| 6.02% due June 2026 | 3,500 |  |  | 4,500 |  |
| 4.90% due October 2026 | 1,750 |  |  | 1,750 |  |
| 6.10% due July 2027 | 500 |  |  | 500 |  |
| 5.25% due February 2028 | 1,000 |  |  | 1,000 |  |
| 5.30% due October 2029 | 1,750 |  |  | 1,750 |  |
| 6.20% due July 2030 | 750 |  |  | 750 |  |
| 5.75% due February 2033 | 1,000 |  |  | 1,000 |  |
| 8.10% due July 2036 | 1,000 |  |  | 1,000 |  |
| 3.38% due December 2041 | 982 |  |  | 1,000 |  |
| 8.35% due July 2046 | 800 |  |  | 800 |  |
| 3.45% due December 2051 | 1,099 |  |  | 1,250 |  |
| Legacy Notes and Debentures: |  |  |  |
| 7.10% due April 2028 | 300 |  |  | 300 |  |
| 6.50% due April 2038 | 388 |  |  | 388 |  |
| 5.40% due September 2040 | 264 |  |  | 264 |  |
| DFS Debt (Note 4) | 10,043 |  |  | 10,290 |  |
| Other | 262 |  |  | 325 |  |
| Total debt, principal amount | $ | 27,388 |  |  | $ | 29,867 |  |
| Unamortized discount, net of unamortized premium | (119) |  |  | (133) |  |
| Debt issuance costs | (131) |  |  | (146) |  |
| Total debt, carrying value | $ | 27,138 |  |  | $ | 29,588 |  |
| Total short-term debt, carrying value | $ | 6,961 |  |  | $ | 6,573 |  |
| Total long-term debt, carrying value | $ | 20,177 |  |  | $ | 23,015 |  |

- changed (2023-12-08):
[0001571996-23-000046:note_history:52]
During the nine months ended November 3, 2023, the net decrease in the Company’s debt balance was principally attributable to:
  (was, 2023-09-12, similarity 0.9205):
[0001571996-23-000032:note_history:52]
During the six months ended August 4, 2023, the net decrease in the Company’s debt balance was principally attributable to:

- changed (2023-12-08):
[0001571996-23-000046:note_history:53]
As of November 3, 2023, the Company had no outstanding borrowings under the 2021 Revolving Credit Facility.
  (was, 2023-09-12, similarity 0.9286):
[0001571996-23-000032:note_history:53]
As of August 4, 2023, the Company had no outstanding borrowings under the 2021 Revolving Credit Facility.

- changed (2023-12-08):
[0001571996-23-000046:note_history:54]
Commercial Paper Program — During Fiscal 2023, the Company established a commercial paper program under which the Company may issue unsecured notes in a maximum aggregate face amount of $5.0 billion outstanding at any time, with maturities up to 397 days from the date of issuance.  The notes are sold on customary terms in the U.S. commercial paper market on a private placement basis.  The proceeds of the notes are used for general corporate purposes.  As of November 3, 2023, the Company had no outstanding borrowings under the commercial paper program.
  (was, 2023-09-12, similarity 0.9204):
[0001571996-23-000032:note_history:54]
Commercial Paper Program — During Fiscal 2023, the Company established a commercial paper program under which the Company may issue unsecured notes in a maximum aggregate face amount of $5.0 billion outstanding at any time, with maturities up to 397 days from the date of issuance.  The notes are sold on customary terms in the U.S. commercial paper market on a private placement basis.  The proceeds of the notes are used for general corporate purposes.  As of August 4, 2023, the Company had no outstanding borrowings under the commercial paper program.

- changed (2023-12-08):
[0001571996-23-000046:note_history:55]
Covenants — The credit agreement governing the 2021 Revolving Credit Facility and the indentures governing the Senior Notes and the Legacy Notes and Debentures impose various limitations, subject to exceptions, on creating certain liens and entering into sale and lease-back transactions.  The foregoing credit agreement and indentures contain customary events of default, including failure to make required payments, failure to comply with covenants, and the occurrence of certain events of bankruptcy and insolvency.  The 2021 Revolving Credit Facility is also subject to an interest coverage ratio covenant that is tested at the end of each fiscal quarter with respect to the Company’s preceding four fiscal quarters.  The Company was in compliance with this financial covenant as of November 3, 2023.
  (was, 2023-09-12, similarity 0.9911):
[0001571996-23-000032:note_history:55]
Covenants — The credit agreement governing the 2021 Revolving Credit Facility and the indentures governing the Senior Notes and the Legacy Notes and Debentures impose various limitations, subject to exceptions, on creating certain liens and entering into sale and lease-back transactions.  The foregoing credit agreement and indentures contain customary events of default, including failure to make required payments, failure to comply with covenants, and the occurrence of certain events of bankruptcy and insolvency.  The 2021 Revolving Credit Facility is also subject to an interest coverage ratio covenant that is tested at the end of each fiscal quarter with respect to the Company’s preceding four fiscal quarters.  The Company was in compliance with this financial covenant as of August 4, 2023.

- changed (2023-12-08):
[0001571996-23-000046:note_history:56]
The following table presents the aggregate future maturities of the Company’s debt as of November 3, 2023 for the periods indicated:
  (was, 2023-09-12, similarity 0.9449):
[0001571996-23-000032:note_history:56]
The following table presents the aggregate future maturities of the Company’s debt as of August 4, 2023 for the periods indicated:

- changed (2023-12-08):
[0001571996-23-000046:note_history:57]
|  | Maturities by Fiscal Year |
|  | 2024 (remaining three months) |  | 2025 |  | 2026 |  | 2027 |  | 2028 |  | Thereafter |  | Total |
|  | (in millions) |
| Senior Notes | $ | — |  |  | $ | 1,000 |  |  | $ | 1,000 |  |  | $ | 5,250 |  |  | $ | 500 |  |  | $ | 8,357 |  |  | $ | 16,107 |  |
| Legacy Notes and Debentures | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 952 |  |  | 952 |  |
| DFS Debt | 1,479 |  |  | 4,807 |  |  | 1,833 |  |  | 884 |  |  | 610 |  |  | 7 |  |  | 9,620 |  |
| Other | 13 |  |  | 124 |  |  | 29 |  |  | 8 |  |  | 6 |  |  | 1 |  |  | 181 |  |
| Total maturities, principal amount | 1,492 |  |  | 5,931 |  |  | 2,862 |  |  | 6,142 |  |  | 1,116 |  |  | 9,317 |  |  | 26,860 |  |
| Associated carrying value adjustments | (2) |  |  | (7) |  |  | (6) |  |  | (33) |  |  | (8) |  |  | (187) |  |  | (243) |  |
| Total maturities, carrying value amount | $ | 1,490 |  |  | $ | 5,924 |  |  | $ | 2,856 |  |  | $ | 6,109 |  |  | $ | 1,108 |  |  | $ | 9,130 |  |  | $ | 26,617 |  |
  (was, 2023-09-12, similarity 0.9936):
[0001571996-23-000032:note_history:57]
|  | Maturities by Fiscal Year |
|  | 2024 (remaining six months) |  | 2025 |  | 2026 |  | 2027 |  | 2028 |  | Thereafter |  | Total |
|  | (in millions) |
| Senior Notes | $ | — |  |  | $ | 1,000 |  |  | $ | 1,000 |  |  | $ | 5,250 |  |  | $ | 500 |  |  | $ | 8,381 |  |  | $ | 16,131 |  |
| Legacy Notes and Debentures | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 952 |  |  | 952 |  |
| DFS Debt | 2,827 |  |  | 4,341 |  |  | 1,511 |  |  | 773 |  |  | 590 |  |  | 1 |  |  | 10,043 |  |
| Other | 100 |  |  | 122 |  |  | 27 |  |  | 8 |  |  | 5 |  |  | — |  |  | 262 |  |
| Total maturities, principal amount | 2,927 |  |  | 5,463 |  |  | 2,538 |  |  | 6,031 |  |  | 1,095 |  |  | 9,334 |  |  | 27,388 |  |
| Associated carrying value adjustments | (2) |  |  | (7) |  |  | (7) |  |  | (36) |  |  | (8) |  |  | (190) |  |  | (250) |  |
| Total maturities, carrying value amount | $ | 2,925 |  |  | $ | 5,456 |  |  | $ | 2,531 |  |  | $ | 5,995 |  |  | $ | 1,087 |  |  | $ | 9,144 |  |  | $ | 27,138 |  |


## us-gaap:ScheduleOfCarryingValuesAndEstimatedFairValuesOfDebtInstrumentsTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-12-08):
[0001571996-23-000046:note_history:58]
|  | November 3, 2023 |  | February 3, 2023 |
|  | Carrying Value |  | Fair Value |  | Carrying Value |  | Fair Value |
|  | (in billions) |
| Senior Notes | $ | 16.0 |  |  | $ | 15.6 |  |  | $ | 18.1 |  |  | $ | 18.2 |  |
| Legacy Notes and Debentures | $ | 0.9 |  |  | $ | 0.9 |  |  | $ | 0.9 |  |  | $ | 1.0 |  |
| DFS Debt | $ | 9.6 |  |  | $ | 9.1 |  |  | $ | 10.3 |  |  | $ | 9.9 |  |
  (was, 2023-09-12, similarity 0.9784):
[0001571996-23-000032:note_history:58]
|  | August 4, 2023 |  | February 3, 2023 |
|  | Carrying Value |  | Fair Value |  | Carrying Value |  | Fair Value |
|  | (in billions) |
| Senior Notes | $ | 16.0 |  |  | $ | 15.8 |  |  | $ | 18.1 |  |  | $ | 18.2 |  |
| Legacy Notes and Debentures | $ | 0.9 |  |  | $ | 1.0 |  |  | $ | 0.9 |  |  | $ | 1.0 |  |
| DFS Debt | $ | 10.0 |  |  | $ | 9.6 |  |  | $ | 10.3 |  |  | $ | 9.9 |  |


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2023-12-08):
[0001571996-23-000046:note_history:59]
The following table presents DFS debt as of the dates indicated and excludes the allocated portion of the Company’s other borrowings, which represents the additional amount considered to fund the DFS business:

- changed (2023-12-08):
[0001571996-23-000046:note_history:60]
|  | November 3, 2023 |  | February 3, 2023 |
| DFS debt | (in millions) |
| DFS U.S. debt: |  |  |  |
| Asset-based financing and securitization facilities | $ | 2,443 |  |  | $ | 3,987 |  |
| Fixed-term securitization offerings | 3,715 |  |  | 2,679 |  |
| Other | 31 |  |  | 76 |  |
| Total DFS U.S. debt | 6,189 |  |  | 6,742 |  |
| DFS international debt: |  |  |  |
| Securitization facility | 749 |  |  | 790 |  |
| Other borrowings | 839 |  |  | 871 |  |
| Note payable | 250 |  |  | 250 |  |
| Dell Bank senior unsecured eurobonds | 1,593 |  |  | 1,637 |  |
| Total DFS international debt | 3,431 |  |  | 3,548 |  |
| Total DFS debt | $ | 9,620 |  |  | $ | 10,290 |  |
| Total short-term DFS debt | $ | 5,374 |  |  | $ | 5,400 |  |
| Total long-term DFS debt | $ | 4,246 |  |  | $ | 4,890 |  |
  (was, 2023-09-12, similarity 0.9896):
[0001571996-23-000032:note_history:60]
|  | August 4, 2023 |  | February 3, 2023 |
| DFS debt | (in millions) |
| DFS U.S. debt: |  |  |  |
| Asset-based financing and securitization facilities | $ | 3,067 |  |  | $ | 3,987 |  |
| Fixed-term securitization offerings | 3,471 |  |  | 2,679 |  |
| Other | 58 |  |  | 76 |  |
| Total DFS U.S. debt | 6,596 |  |  | 6,742 |  |
| DFS international debt: |  |  |  |
| Securitization facility | 793 |  |  | 790 |  |
| Other borrowings | 762 |  |  | 871 |  |
| Note payable | 250 |  |  | 250 |  |
| Dell Bank senior unsecured eurobonds | 1,642 |  |  | 1,637 |  |
| Total DFS international debt | 3,447 |  |  | 3,548 |  |
| Total DFS debt | $ | 10,043 |  |  | $ | 10,290 |  |
| Total short-term DFS debt | $ | 5,801 |  |  | $ | 5,400 |  |
| Total long-term DFS debt | $ | 4,242 |  |  | $ | 4,890 |  |

- changed (2023-12-08):
[0001571996-23-000046:note_history:61]
|  | November 3, 2023 |  | February 3, 2023 |
|  | (in millions) |
| Senior Notes: |  |  |  |
| 5.45% due June 2023 | $ | — |  |  | $ | 1,000 |  |
| 4.00% due July 2024 | 1,000 |  |  | 1,000 |  |
| 5.85% due July 2025 | 1,000 |  |  | 1,000 |  |
| 6.02% due June 2026 | 3,500 |  |  | 4,500 |  |
| 4.90% due October 2026 | 1,750 |  |  | 1,750 |  |
| 6.10% due July 2027 | 500 |  |  | 500 |  |
| 5.25% due February 2028 | 1,000 |  |  | 1,000 |  |
| 5.30% due October 2029 | 1,750 |  |  | 1,750 |  |
| 6.20% due July 2030 | 750 |  |  | 750 |  |
| 5.75% due February 2033 | 1,000 |  |  | 1,000 |  |
| 8.10% due July 2036 | 1,000 |  |  | 1,000 |  |
| 3.38% due December 2041 | 962 |  |  | 1,000 |  |
| 8.35% due July 2046 | 800 |  |  | 800 |  |
| 3.45% due December 2051 | 1,095 |  |  | 1,250 |  |
| Legacy Notes and Debentures: |  |  |  |
| 7.10% due April 2028 | 300 |  |  | 300 |  |
| 6.50% due April 2038 | 388 |  |  | 388 |  |
| 5.40% due September 2040 | 264 |  |  | 264 |  |
| DFS Debt (Note 4) | 9,620 |  |  | 10,290 |  |
| Other | 181 |  |  | 325 |  |
| Total debt, principal amount | $ | 26,860 |  |  | $ | 29,867 |  |
| Unamortized discount, net of unamortized premium | (117) |  |  | (133) |  |
| Debt issuance costs | (126) |  |  | (146) |  |
| Total debt, carrying value | $ | 26,617 |  |  | $ | 29,588 |  |
| Total short-term debt, carrying value | $ | 6,498 |  |  | $ | 6,573 |  |
| Total long-term debt, carrying value | $ | 20,119 |  |  | $ | 23,015 |  |
  (was, 2023-09-12, similarity 0.9937):
[0001571996-23-000032:note_history:61]
|  | August 4, 2023 |  | February 3, 2023 |
|  | (in millions) |
| Senior Notes: |  |  |  |
| 5.45% due June 2023 | $ | — |  |  | $ | 1,000 |  |
| 4.00% due July 2024 | 1,000 |  |  | 1,000 |  |
| 5.85% due July 2025 | 1,000 |  |  | 1,000 |  |
| 6.02% due June 2026 | 3,500 |  |  | 4,500 |  |
| 4.90% due October 2026 | 1,750 |  |  | 1,750 |  |
| 6.10% due July 2027 | 500 |  |  | 500 |  |
| 5.25% due February 2028 | 1,000 |  |  | 1,000 |  |
| 5.30% due October 2029 | 1,750 |  |  | 1,750 |  |
| 6.20% due July 2030 | 750 |  |  | 750 |  |
| 5.75% due February 2033 | 1,000 |  |  | 1,000 |  |
| 8.10% due July 2036 | 1,000 |  |  | 1,000 |  |
| 3.38% due December 2041 | 982 |  |  | 1,000 |  |
| 8.35% due July 2046 | 800 |  |  | 800 |  |
| 3.45% due December 2051 | 1,099 |  |  | 1,250 |  |
| Legacy Notes and Debentures: |  |  |  |
| 7.10% due April 2028 | 300 |  |  | 300 |  |
| 6.50% due April 2038 | 388 |  |  | 388 |  |
| 5.40% due September 2040 | 264 |  |  | 264 |  |
| DFS Debt (Note 4) | 10,043 |  |  | 10,290 |  |
| Other | 262 |  |  | 325 |  |
| Total debt, principal amount | $ | 27,388 |  |  | $ | 29,867 |  |
| Unamortized discount, net of unamortized premium | (119) |  |  | (133) |  |
| Debt issuance costs | (131) |  |  | (146) |  |
| Total debt, carrying value | $ | 27,138 |  |  | $ | 29,588 |  |
| Total short-term debt, carrying value | $ | 6,961 |  |  | $ | 6,573 |  |
| Total long-term debt, carrying value | $ | 20,177 |  |  | $ | 23,015 |  |

- removed (2023-12-08):
[0001571996-23-000032:note_history:62]
The majority of DFS debt is non-recourse to Dell Technologies and represents borrowings under securitization programs and structured financing programs, for which the Company’s risk of loss is limited to transferred loan and lease payments and associated equipment.  
The following table presents DFS debt as of the dates indicated and excludes the allocated portion of the Company’s other borrowings, which represents the additional amount considered to fund the DFS business:


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-12-08):
[0001571996-23-000046:note_history:63]
The following table presents the aggregate future maturities of the Company’s debt as of November 3, 2023 for the periods indicated:
  (was, 2023-09-12, similarity 0.9449):
[0001571996-23-000032:note_history:63]
The following table presents the aggregate future maturities of the Company’s debt as of August 4, 2023 for the periods indicated:

- changed (2023-12-08):
[0001571996-23-000046:note_history:64]
|  | Maturities by Fiscal Year |
|  | 2024 (remaining three months) |  | 2025 |  | 2026 |  | 2027 |  | 2028 |  | Thereafter |  | Total |
|  | (in millions) |
| Senior Notes | $ | — |  |  | $ | 1,000 |  |  | $ | 1,000 |  |  | $ | 5,250 |  |  | $ | 500 |  |  | $ | 8,357 |  |  | $ | 16,107 |  |
| Legacy Notes and Debentures | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 952 |  |  | 952 |  |
| DFS Debt | 1,479 |  |  | 4,807 |  |  | 1,833 |  |  | 884 |  |  | 610 |  |  | 7 |  |  | 9,620 |  |
| Other | 13 |  |  | 124 |  |  | 29 |  |  | 8 |  |  | 6 |  |  | 1 |  |  | 181 |  |
| Total maturities, principal amount | 1,492 |  |  | 5,931 |  |  | 2,862 |  |  | 6,142 |  |  | 1,116 |  |  | 9,317 |  |  | 26,860 |  |
| Associated carrying value adjustments | (2) |  |  | (7) |  |  | (6) |  |  | (33) |  |  | (8) |  |  | (187) |  |  | (243) |  |
| Total maturities, carrying value amount | $ | 1,490 |  |  | $ | 5,924 |  |  | $ | 2,856 |  |  | $ | 6,109 |  |  | $ | 1,108 |  |  | $ | 9,130 |  |  | $ | 26,617 |  |
  (was, 2023-09-12, similarity 0.9936):
[0001571996-23-000032:note_history:64]
|  | Maturities by Fiscal Year |
|  | 2024 (remaining six months) |  | 2025 |  | 2026 |  | 2027 |  | 2028 |  | Thereafter |  | Total |
|  | (in millions) |
| Senior Notes | $ | — |  |  | $ | 1,000 |  |  | $ | 1,000 |  |  | $ | 5,250 |  |  | $ | 500 |  |  | $ | 8,381 |  |  | $ | 16,131 |  |
| Legacy Notes and Debentures | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 952 |  |  | 952 |  |
| DFS Debt | 2,827 |  |  | 4,341 |  |  | 1,511 |  |  | 773 |  |  | 590 |  |  | 1 |  |  | 10,043 |  |
| Other | 100 |  |  | 122 |  |  | 27 |  |  | 8 |  |  | 5 |  |  | — |  |  | 262 |  |
| Total maturities, principal amount | 2,927 |  |  | 5,463 |  |  | 2,538 |  |  | 6,031 |  |  | 1,095 |  |  | 9,334 |  |  | 27,388 |  |
| Associated carrying value adjustments | (2) |  |  | (7) |  |  | (7) |  |  | (36) |  |  | (8) |  |  | (190) |  |  | (250) |  |
| Total maturities, carrying value amount | $ | 2,925 |  |  | $ | 5,456 |  |  | $ | 2,531 |  |  | $ | 5,995 |  |  | $ | 1,087 |  |  | $ | 9,144 |  |  | $ | 27,138 |  |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- added (2023-12-08):
[0001571996-23-000046:note_history:65]
RELATED PARTY TRANSACTIONS 
For the periods presented within this report, VMware was considered to be a related party of the Company as a result of Michael Dell’s ownership interests in both Dell Technologies and VMware as well as Mr. Dell’s service as Chairman and Chief Executive Officer of Dell Technologies and as Chairman of the Board of VMware, Inc.

- added (2023-12-08):
[0001571996-23-000046:note_history:66]
Subsequent to the close of the Company’s third quarter of Fiscal 2024, Broadcom Inc. completed its acquisition of VMware and terminated the preexisting related party relationship.  See Note 18 of the Notes to the Condensed Consolidated Financial Statements for more information about the impact of the transaction on the Company’s relationship with VMware.

- changed (2023-12-08):
[0001571996-23-000046:note_history:67]
The information provided below includes a summary of transactions with VMware for the periods presented.  Transactions with related parties other than VMware during the periods presented were immaterial, individually and in aggregate.
  (was, 2023-09-12, similarity 0.9409):
[0001571996-23-000032:note_history:67]
The information provided below includes a summary of transactions with VMware.  Transactions with related parties other than VMware during the periods presented were immaterial, individually and in aggregate.

- added (2023-12-08):
[0001571996-23-000046:note_history:68]
•Dell Technologies may procure products and services from VMware for its internal use.  For the three and nine months ended November 3, 2023 and October 28, 2022, costs incurred associated with products and services purchased from VMware for internal use were immaterial.

- changed (2023-12-08):
[0001571996-23-000046:note_history:69]
•Dell Technologies sells and leases products and sells services to VMware.  For the three and nine months ended November 3, 2023 and October 28, 2022, revenue recognized from sales of services to VMware was immaterial.
  (was, 2023-09-12, similarity 0.7255):
[0001571996-23-000032:note_history:69]
•Dell Technologies sells and leases products and sells services to VMware.  For the three and six months ended August 4, 2023 and July 29, 2022, revenue recognized from sales of services to VMware was immaterial.

- added (2023-12-08):
[0001571996-23-000046:note_history:70]
•Dell Technologies and VMware also enter into joint marketing, sales, and branding arrangements, for which both parties may incur costs.  For the three and nine months ended November 3, 2023 and October 28, 2022, consideration received from VMware for joint marketing, sales, and branding arrangements was immaterial.

- changed (2023-12-08):
[0001571996-23-000046:note_history:71]
•Dell Technologies and VMware entered into a transition services agreement in connection with the VMware Spin-off to provide various support services, including investment advisory services, certain support services from Dell Technologies personnel, and other transitional services.  Costs associated with this agreement were immaterial for the three and nine months ended October 28, 2022.  Activities under the agreement concluded during Fiscal 2023.
  (was, 2023-09-12, similarity 0.9475):
[0001571996-23-000032:note_history:71]
•Dell Technologies and VMware entered into a transition services agreement in connection with the VMware Spin-off to provide various support services, including investment advisory services, certain support services from Dell Technologies personnel, and other transitional services.  Costs associated with this agreement were immaterial for the three and six months ended July 29, 2022.  Activities under the agreement concluded during Fiscal 2023.

- changed (2023-12-08):
[0001571996-23-000046:note_history:72]
|  |  |  | Three Months Ended |  | Nine Months Ended |  |  |
|  | Classification |  | November 3, 2023 |  | October 28, 2022 |  | November 3, 2023 |  | October 28, 2022 |  |  |
|  |  |  | (in millions) |
| Sales and leases of products to VMware | Net revenue - products |  | $ | 16 |  |  | $ | 49 |  |  | $ | 94 |  |  | $ | 130 |  |  |  |
| Purchase of VMware products for resale | Cost of net revenue - products |  | $ | 379 |  |  | $ | 281 |  |  | $ | 970 |  |  | $ | 962 |  |  |  |
| Purchase of VMware services for resale | Cost of net revenue - services |  | $ | 884 |  |  | $ | 733 |  |  | $ | 2,640 |  |  | $ | 2,204 |  |  |  |
  (was, 2023-09-12, similarity 0.8577):
[0001571996-23-000032:note_history:72]
|  |  |  | Three Months Ended |  | Six Months Ended |
|  | Classification |  | August 4, 2023 |  | July 29, 2022 |  | August 4, 2023 |  | July 29, 2022 |  |  |
|  |  |  | (in millions) |
| Sales and leases of products to VMware | Net revenue - products |  | $ | 38 |  |  | $ | 35 |  |  | $ | 78 |  |  | $ | 81 |  |  |  |
| Purchase of VMware products for resale | Cost of net revenue - products |  | $ | 384 |  |  | $ | 426 |  |  | $ | 591 |  |  | $ | 681 |  |  |  |
| Purchase of VMware services for resale | Cost of net revenue - services |  | $ | 880 |  |  | $ | 762 |  |  | $ | 1,756 |  |  | $ | 1,471 |  |  |  |

- changed (2023-12-08):
[0001571996-23-000046:note_history:73]
|  | Classification |  | November 3, 2023 |  | February 3, 2023 |
|  |  |  | (in millions) |
| Deferred costs related to VMware products and services for resale | Other current assets |  | $ | 2,926 |  |  | $ | 3,000 |  |
| Deferred costs related to VMware products and services for resale | Other non-current assets |  | $ | 2,201 |  |  | $ | 2,537 |  |
  (was, 2023-09-12, similarity 0.9778):
[0001571996-23-000032:note_history:73]
|  | Classification |  | August 4, 2023 |  | February 3, 2023 |
|  |  |  | (in millions) |
| Deferred costs related to VMware products and services for resale | Other current assets |  | $ | 2,898 |  |  | $ | 3,000 |  |
| Deferred costs related to VMware products and services for resale | Other non-current assets |  | $ | 2,277 |  |  | $ | 2,537 |  |

- changed (2023-12-08):
[0001571996-23-000046:note_history:74]
|  | November 3, 2023 |  | February 3, 2023 |
|  | (in millions) |
| Due from related party, net, current (a) | $ | 386 |  |  | $ | 378 |  |
| Due from related party, net, non-current (b) | $ | 239 |  |  | $ | 440 |  |
| Due to related party, current (c) | $ | 1,246 |  |  | $ | 2,067 |  |
| Due to related party, non-current (d) | $ | 11 |  |  | $ | — |  |
  (was, 2023-09-12, similarity 0.8627):
[0001571996-23-000032:note_history:74]
|  | August 4, 2023 |  | February 3, 2023 |
|  | (in millions) |
| Due from related party, net, current (a) | $ | 404 |  |  | $ | 378 |  |
| Due from related party, net, non-current (b) | $ | 236 |  |  | $ | 440 |  |
| Due to related party, current (c) | $ | 1,252 |  |  | $ | 2,067 |  |

- changed (2023-12-08):
[0001571996-23-000046:note_history:75]
(a)      Amounts due from related party, net, current consisted of amounts due from VMware, inclusive of current net tax receivables from VMware under the Tax Agreements described below.  Amounts, excluding tax, are generally settled in cash within 60 days of each quarter-end.
  (was, 2023-09-12, similarity 0.9944):
[0001571996-23-000032:note_history:75]
(a)      Amounts due from related party, net, current consists of amounts due from VMware, inclusive of current net tax receivables from VMware under the Tax Agreements described below.  Amounts, excluding tax, are generally settled in cash within 60 days of each quarter-end.

- changed (2023-12-08):
[0001571996-23-000046:note_history:76]
(b)      Amounts due from related party, net, non-current consisted of the non-current portion of net receivables from VMware under the Tax Agreements.
  (was, 2023-09-12, similarity 0.9897):
[0001571996-23-000032:note_history:76]
(b)      Amounts due from related party, net, non-current consists of the non-current portion of net receivables from VMware under the Tax Agreements.

- changed (2023-12-08):
[0001571996-23-000046:note_history:77]
(c)      Amounts due to related party, current included amounts due to VMware, which are generally settled in cash within 60 days of each quarter-end.
  (was, 2023-09-12, similarity 0.9931):
[0001571996-23-000032:note_history:77]
(c)      Amounts due to related party, current includes amounts due to VMware, which are generally settled in cash within 60 days of each quarter-end.

- added (2023-12-08):
[0001571996-23-000046:note_history:78]
(d)     Amounts due to related party, non-current are included in other non-current liabilities.

- changed (2023-12-08):
[0001571996-23-000046:note_history:79]
Pursuant to the Tax Agreements, net receipts from VMware during the nine months ended November 3, 2023 and net payments to VMware during the nine months ended October 28, 2022 were immaterial.
  (was, 2023-09-12, similarity 0.9025):
[0001571996-23-000032:note_history:79]
Pursuant to the Tax Agreements, net receipts from VMware during the six months ended August 4, 2023 and net payments to VMware during the six months ended July 29, 2022 were immaterial.

- added (2023-12-08):
[0001571996-23-000046:note_history:80]
As a result of the activity under the Tax Agreements with VMware, amounts due from VMware were $484 million and $599 million as of November 3, 2023 and February 3, 2023, respectively, and primarily related to VMware’s estimated tax obligation resulting from the Transition Tax.  The 2017 Tax Cuts and Jobs Act included a deferral election for an eight-year installment payment method on the Transition Tax.  Dell Technologies expects VMware to pay the remainder of its Transition Tax over a period of two years.

- changed (2023-12-08):
[0001571996-23-000046:note_history:81]
Indemnification — Upon consummation of the VMware Spin-off, Dell Technologies recorded net income tax indemnification receivables from VMware related to certain income tax liabilities for which Dell Technologies is jointly and severally liable, but for which it is indemnified by VMware under the Tax Matters Agreement.  The amounts that VMware may be obligated to pay Dell Technologies could vary depending on the outcome of certain unresolved tax matters, which may not be resolved for several years.  The net receivable as of November 3, 2023 and February 3, 2023 was $95 million and $146 million, respectively.
  (was, 2023-09-12, similarity 0.9883):
[0001571996-23-000032:note_history:81]
Indemnification — Upon consummation of the VMware Spin-off, Dell Technologies recorded net income tax indemnification receivables from VMware related to certain income tax liabilities for which Dell Technologies is jointly and severally liable, but for which it is indemnified by VMware under the Tax Matters Agreement.  The amounts that VMware may be obligated to pay Dell Technologies could vary depending on the outcome of certain unresolved tax matters, which may not be resolved for several years.  The net receivable as of August 4, 2023 and February 3, 2023 was $93 million and $146 million, respectively.

- removed (2023-12-08):
[0001571996-23-000032:note_history:82]
RELATED PARTY TRANSACTIONS 
VMware is considered to be a related party of the Company as a result of Michael Dell’s ownership interests in both Dell Technologies and VMware as well as Mr. Dell’s service as Chairman and Chief Executive Officer of Dell Technologies and as Chairman of the Board of VMware, Inc.

- removed (2023-12-08):
[0001571996-23-000032:note_history:83]
Dell Technologies and VMware engage in the following ongoing related party transactions:

- removed (2023-12-08):
[0001571996-23-000032:note_history:84]
•Dell Technologies procures products and services from VMware for its internal use.  For the three and six months ended August 4, 2023 and July 29, 2022, costs incurred associated with products and services purchased from VMware for internal use were immaterial.

- removed (2023-12-08):
[0001571996-23-000032:note_history:85]
•Dell Technologies and VMware also enter into joint marketing, sales, and branding arrangements, for which both parties may incur costs.  For the three and six months ended August 4, 2023 and July 29, 2022, consideration received from VMware for joint marketing, sales, and branding arrangements was immaterial.

- removed (2023-12-08):
[0001571996-23-000032:note_history:86]
Due To/From Related Party

- removed (2023-12-08):
[0001571996-23-000032:note_history:87]
The following table presents amounts due to and from VMware as of the dates indicated:

- removed (2023-12-08):
[0001571996-23-000032:note_history:88]
As a result of the activity under the Tax Agreements with VMware, amounts due from VMware were $484 million and $599 million as of August 4, 2023 and February 3, 2023, respectively, primarily related to VMware’s estimated tax obligation resulting from the Transition Tax.  The 2017 Tax Cuts and Jobs Act included a deferral election for an eight-year installment payment method on the Transition Tax.  Dell Technologies expects VMware to pay the remainder of its Transition Tax over a period of two years.


## us-gaap:ScheduleOfRelatedPartyTransactionsTableTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2023-12-08):
[0001571996-23-000046:note_history:89]
|  |  |  | Three Months Ended |  | Nine Months Ended |  |  |
|  | Classification |  | November 3, 2023 |  | October 28, 2022 |  | November 3, 2023 |  | October 28, 2022 |  |  |
|  |  |  | (in millions) |
| Sales and leases of products to VMware | Net revenue - products |  | $ | 16 |  |  | $ | 49 |  |  | $ | 94 |  |  | $ | 130 |  |  |  |
| Purchase of VMware products for resale | Cost of net revenue - products |  | $ | 379 |  |  | $ | 281 |  |  | $ | 970 |  |  | $ | 962 |  |  |  |
| Purchase of VMware services for resale | Cost of net revenue - services |  | $ | 884 |  |  | $ | 733 |  |  | $ | 2,640 |  |  | $ | 2,204 |  |  |  |
  (was, 2023-09-12, similarity 0.8577):
[0001571996-23-000032:note_history:89]
|  |  |  | Three Months Ended |  | Six Months Ended |
|  | Classification |  | August 4, 2023 |  | July 29, 2022 |  | August 4, 2023 |  | July 29, 2022 |  |  |
|  |  |  | (in millions) |
| Sales and leases of products to VMware | Net revenue - products |  | $ | 38 |  |  | $ | 35 |  |  | $ | 78 |  |  | $ | 81 |  |  |  |
| Purchase of VMware products for resale | Cost of net revenue - products |  | $ | 384 |  |  | $ | 426 |  |  | $ | 591 |  |  | $ | 681 |  |  |  |
| Purchase of VMware services for resale | Cost of net revenue - services |  | $ | 880 |  |  | $ | 762 |  |  | $ | 1,756 |  |  | $ | 1,471 |  |  |  |

- changed (2023-12-08):
[0001571996-23-000046:note_history:90]
|  | Classification |  | November 3, 2023 |  | February 3, 2023 |
|  |  |  | (in millions) |
| Deferred costs related to VMware products and services for resale | Other current assets |  | $ | 2,926 |  |  | $ | 3,000 |  |
| Deferred costs related to VMware products and services for resale | Other non-current assets |  | $ | 2,201 |  |  | $ | 2,537 |  |
  (was, 2023-09-12, similarity 0.9778):
[0001571996-23-000032:note_history:90]
|  | Classification |  | August 4, 2023 |  | February 3, 2023 |
|  |  |  | (in millions) |
| Deferred costs related to VMware products and services for resale | Other current assets |  | $ | 2,898 |  |  | $ | 3,000 |  |
| Deferred costs related to VMware products and services for resale | Other non-current assets |  | $ | 2,277 |  |  | $ | 2,537 |  |

- changed (2023-12-08):
[0001571996-23-000046:note_history:91]
|  | November 3, 2023 |  | February 3, 2023 |
|  | (in millions) |
| Due from related party, net, current (a) | $ | 386 |  |  | $ | 378 |  |
| Due from related party, net, non-current (b) | $ | 239 |  |  | $ | 440 |  |
| Due to related party, current (c) | $ | 1,246 |  |  | $ | 2,067 |  |
| Due to related party, non-current (d) | $ | 11 |  |  | $ | — |  |
  (was, 2023-09-12, similarity 0.8627):
[0001571996-23-000032:note_history:91]
|  | August 4, 2023 |  | February 3, 2023 |
|  | (in millions) |
| Due from related party, net, current (a) | $ | 404 |  |  | $ | 378 |  |
| Due from related party, net, non-current (b) | $ | 236 |  |  | $ | 440 |  |
| Due to related party, current (c) | $ | 1,252 |  |  | $ | 2,067 |  |

- changed (2023-12-08):
[0001571996-23-000046:note_history:92]
(a)      Amounts due from related party, net, current consisted of amounts due from VMware, inclusive of current net tax receivables from VMware under the Tax Agreements described below.  Amounts, excluding tax, are generally settled in cash within 60 days of each quarter-end.
  (was, 2023-09-12, similarity 0.9944):
[0001571996-23-000032:note_history:92]
(a)      Amounts due from related party, net, current consists of amounts due from VMware, inclusive of current net tax receivables from VMware under the Tax Agreements described below.  Amounts, excluding tax, are generally settled in cash within 60 days of each quarter-end.

- changed (2023-12-08):
[0001571996-23-000046:note_history:93]
(b)      Amounts due from related party, net, non-current consisted of the non-current portion of net receivables from VMware under the Tax Agreements.
  (was, 2023-09-12, similarity 0.9897):
[0001571996-23-000032:note_history:93]
(b)      Amounts due from related party, net, non-current consists of the non-current portion of net receivables from VMware under the Tax Agreements.

- changed (2023-12-08):
[0001571996-23-000046:note_history:94]
(c)      Amounts due to related party, current included amounts due to VMware, which are generally settled in cash within 60 days of each quarter-end.
(d)     Amounts due to related party, non-current are included in other non-current liabilities.
  (was, 2023-09-12, similarity 0.7507):
[0001571996-23-000032:note_history:94]
(c)      Amounts due to related party, current includes amounts due to VMware, which are generally settled in cash within 60 days of each quarter-end.

- removed (2023-12-08):
[0001571996-23-000032:note_history:95]
The following table presents amounts due to and from VMware as of the dates indicated:


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2023-12-08):
[0001571996-23-000046:note_history:96]
|  | Three Months Ended |  | Nine Months Ended |
|  | November 3, 2023 |  | October 28, 2022 |  | November 3, 2023 |  | October 28, 2022 |
|  | (in millions) |
| Net revenue: |  |  |  |  |  |  |  |
| Infrastructure Solutions Group: |  |  |  |  |  |  |  |
| Servers and networking | $ | 4,656 |  |  | $ | 5,201 |  |  | $ | 12,767 |  |  | $ | 15,458 |  |
| Storage | 3,843 |  |  | 4,429 |  |  | 11,786 |  |  | 12,993 |  |
| Total ISG net revenue | $ | 8,499 |  |  | $ | 9,630 |  |  | $ | 24,553 |  |  | $ | 28,451 |  |
| Client Solutions Group: |  |  |  |  |  |  |  |
| Commercial | $ | 9,835 |  |  | $ | 10,747 |  |  | $ | 30,251 |  |  | $ | 34,859 |  |
| Consumer | 2,441 |  |  | 3,028 |  |  | 6,950 |  |  | 9,993 |  |
| Total CSG net revenue | $ | 12,276 |  |  | $ | 13,775 |  |  | $ | 37,201 |  |  | $ | 44,852 |  |
  (was, 2023-09-12, similarity 0.9097):
[0001571996-23-000032:note_history:96]
|  | Three Months Ended |  | Six Months Ended |
|  | August 4, 2023 |  | July 29, 2022 |  | August 4, 2023 |  | July 29, 2022 |
|  | (in millions) |
| Net revenue: |  |  |  |  |  |  |  |
| Infrastructure Solutions Group: |  |  |  |  |  |  |  |
| Servers and networking | $ | 4,274 |  |  | $ | 5,209 |  |  | $ | 8,111 |  |  | $ | 10,257 |  |
| Storage | 4,187 |  |  | 4,327 |  |  | 7,943 |  |  | 8,564 |  |
| Total ISG net revenue | $ | 8,461 |  |  | $ | 9,536 |  |  | $ | 16,054 |  |  | $ | 18,821 |  |
| Client Solutions Group: |  |  |  |  |  |  |  |
| Commercial | $ | 10,554 |  |  | $ | 12,141 |  |  | $ | 20,416 |  |  | $ | 24,112 |  |
| Consumer | 2,388 |  |  | 3,349 |  |  | 4,509 |  |  | 6,965 |  |
| Total CSG net revenue | $ | 12,942 |  |  | $ | 15,490 |  |  | $ | 24,925 |  |  | $ | 31,077 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2023-12-08):
[0001571996-23-000046:note_history:97]
|  | Three Months Ended |  | Nine Months Ended |
|  | November 3, 2023 |  | October 28, 2022 |  | November 3, 2023 |  | October 28, 2022 |
|  | (in millions) |
| Deferred revenue: |  |  |  |  |  |  |  |
| Deferred revenue at beginning of period | $ | 30,312 |  |  | $ | 28,025 |  |  | $ | 30,286 |  |  | $ | 27,573 |  |
| Revenue deferrals | 4,492 |  |  | 4,128 |  |  | 15,236 |  |  | 14,675 |  |
| Revenue recognized | (5,766) |  |  | (5,064) |  |  | (16,484) |  |  | (14,994) |  |
| Other (a) | 15 |  |  | — |  |  | 15 |  |  | (165) |  |
| Deferred revenue at end of period | $ | 29,053 |  |  | $ | 27,089 |  |  | $ | 29,053 |  |  | $ | 27,089 |  |
| Short-term deferred revenue | $ | 15,206 |  |  | $ | 14,106 |  |  | $ | 15,206 |  |  | $ | 14,106 |  |
| Long-term deferred revenue | $ | 13,847 |  |  | $ | 12,983 |  |  | $ | 13,847 |  |  | $ | 12,983 |  |
  (was, 2023-09-12, similarity 0.9011):
[0001571996-23-000032:note_history:97]
|  | Three Months Ended |  | Six Months Ended |
|  | August 4, 2023 |  | July 29, 2022 |  | August 4, 2023 |  | July 29, 2022 |
|  | (in millions) |
| Deferred revenue: |  |  |  |  |  |  |  |
| Deferred revenue at beginning of period | $ | 29,695 |  |  | $ | 27,403 |  |  | $ | 30,286 |  |  | $ | 27,573 |  |
| Revenue deferrals | 6,025 |  |  | 5,572 |  |  | 10,744 |  |  | 10,547 |  |
| Revenue recognized | (5,408) |  |  | (4,950) |  |  | (10,718) |  |  | (9,930) |  |
| Other (a) | — |  |  | — |  |  | — |  |  | (165) |  |
| Deferred revenue at end of period | $ | 30,312 |  |  | $ | 28,025 |  |  | $ | 30,312 |  |  | $ | 28,025 |  |
| Short-term deferred revenue | $ | 16,174 |  |  | $ | 14,724 |  |  | $ | 16,174 |  |  | $ | 14,724 |  |
| Long-term deferred revenue | $ | 14,138 |  |  | $ | 13,301 |  |  | $ | 14,138 |  |  | $ | 13,301 |  |

- changed (2023-12-08):
[0001571996-23-000046:note_history:98]
(a)    For the nine months ended October 28, 2022, Other represents the reclassification of deferred revenue to accrued and other liabilities.
  (was, 2023-09-12, similarity 0.9389):
[0001571996-23-000032:note_history:98]
(a)    For the six months ended July 29, 2022, Other represents the reclassification of deferred revenue to accrued and other liabilities.

- changed (2023-12-08):
[0001571996-23-000046:note_history:99]
Remaining Performance Obligations — Remaining performance obligations represent the aggregate amount of the transaction price allocated to performance obligations not delivered, or partially undelivered, as of the end of the reporting period.  Remaining performance obligations include deferred revenue plus unbilled amounts not yet recorded in deferred revenue.  The value of the transaction price allocated to remaining performance obligations as of November 3, 2023 was approximately $39 billion.  The Company expects to recognize approximately 58% of remaining performance obligations as revenue in the next twelve months, and the remainder thereafter.
  (was, 2023-09-12, similarity 0.9892):
[0001571996-23-000032:note_history:99]
Remaining Performance Obligations — Remaining performance obligations represent the aggregate amount of the transaction price allocated to performance obligations not delivered, or partially undelivered, as of the end of the reporting period.  Remaining performance obligations include deferred revenue plus unbilled amounts not yet recorded in deferred revenue.  The value of the transaction price allocated to remaining performance obligations as of August 4, 2023 was approximately $39 billion.  The Company expects to recognize approximately 58% of remaining performance obligations as revenue in the next twelve months, and the remainder thereafter.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- added (2023-12-08):
[0001571996-23-000046:note_history:100]
SUBSEQUENT EVENTS 
On November 22, 2023, subsequent to the close of the Company’s third quarter of Fiscal 2024, VMware was acquired by Broadcom Inc. (“Broadcom”).  Upon the completion of Broadcom’s acquisition of VMware, Mr. Dell relinquished his direct ownership interest in VMware and his position as Chairman of the Board of VMware, Inc.  Mr. Dell’s subsequent ownership interest in Broadcom does not represent control or significant influence to an extent that the transacting parties might be prevented from fully pursuing their own separate interests.  As a result, the Company determined that the acquisition terminated the preexisting related party relationship with VMware and that no related party relationship exists with either Broadcom or VMware as of the date of issuance of this report.
Other than the matter identified above, there were no known events occurring after November 3, 2023 and up until the date of issuance of this report that would materially affect the information presented herein.

- removed (2023-12-08):
[0001571996-23-000032:note_history:101]
SUBSEQUENT EVENTS There were no known events occurring after August 4, 2023 and up until the date of issuance of this report that would materially affect the information presented herein.
