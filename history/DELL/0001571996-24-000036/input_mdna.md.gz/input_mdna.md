# DELL MD&A — 0001571996-24-000036


## mdna

[0001571996-24-000036:mdna:1]
ITEM 7 — MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS

[0001571996-24-000036:mdna:2]
This management’s discussion and analysis should be read in conjunction with the audited Consolidated Financial Statements and accompanying Notes included in this Annual Report on Form 10-K.  This section of this Form 10-K generally discusses Fiscal 2024 and Fiscal 2023 items and presents year-to-year comparisons between Fiscal 2024 and Fiscal 2023 results.  Discussion of Fiscal 2022 items and year-to-year comparisons between Fiscal 2023 and Fiscal 2022 results that are not included in this Form 10-K are presented in “Part II — Item 7 — Management’s Discussion and Analysis of Financial Condition and Results of Operations” of the Company’s Annual Report on Form 10-K for the fiscal year ended February 3, 2023, as filed with the SEC on March 30, 2023, which is available free of charge on the SEC’s website at www.sec.gove and on our Investor Relations website at investors.delltechnologies.com.

[0001571996-24-000036:mdna:3]
Unless otherwise indicated, all results presented are prepared in a manner that complies, in all material respects, with generally accepted accounting principles in the United States of America (“GAAP”).  Unless otherwise indicated, all changes identified for the current-period results represent comparisons to results for the prior corresponding fiscal period.

[0001571996-24-000036:mdna:4]
Unless the context indicates otherwise, references in this management’s discussion and analysis to “we,” “us,” “our,” the “Company,” and “Dell Technologies” mean Dell Technologies Inc. and its consolidated subsidiaries, references to “Dell” mean Dell Inc. and Dell Inc.’s consolidated subsidiaries, and references to “EMC” mean EMC Corporation and EMC Corporation’s consolidated subsidiaries.

[0001571996-24-000036:mdna:5]
Our fiscal year is the 52- or 53-week period ending on the Friday nearest January 31.  We refer to our fiscal year ended February 2, 2024 as “Fiscal 2024” and our fiscal year ended February 3, 2023 as “Fiscal 2023.”  Fiscal 2024 included 52 weeks and Fiscal 2023 included 53 weeks.

[0001571996-24-000036:mdna:6]
INTRODUCTION

[0001571996-24-000036:mdna:7]
Company Overview

[0001571996-24-000036:mdna:8]
Dell Technologies is a global technology company that provides customers with a broad and innovative solutions portfolio to help customers modernize their information technology (“IT”) infrastructure, address workforce transformation, and provide critical solutions that keep people and organizations connected.  With our extensive portfolio and our commitment to innovation, we offer secure, integrated solutions that extend from the edge to the core to the cloud, and we are at the forefront of artificial intelligence (“AI”), software-defined, and cloud native infrastructure solutions.  Our vision is to become the most essential technology partner.  We intend to realize our vision as we execute our strategy to leverage our strengths to extend our leadership positions and capture new growth.

[0001571996-24-000036:mdna:9]
We are organized into two business units which are also our reportable segments: Infrastructure Solutions Group and Client Solutions Group.

[0001571996-24-000036:mdna:10]
•Infrastructure Solutions Group (“ISG”) — ISG includes our storage, server, and networking offerings.  Our comprehensive storage portfolio includes modern and traditional storage solutions, including all-flash arrays, scale-out file, object platforms, hyper-converged infrastructure, and software-defined storage.  Our server portfolio includes high-performance general-purpose and AI-optimized servers.  Our networking portfolio includes wide area network infrastructure, data center and edge networking switches, and cables and optics.  ISG also offers software, peripherals, and services, including consulting and support and deployment.

[0001571996-24-000036:mdna:11]
•Client Solutions Group (“CSG”) — CSG includes offerings designed for commercial and consumer customers.  Our CSG portfolio includes branded PCs including notebooks, desktops, and workstations, branded peripherals, and third-party software and peripherals.  CSG also includes services offerings, such as configuration, support and deployment, and extended warranties.

[0001571996-24-000036:mdna:12]
Our “other businesses” primarily consist of our resale of standalone offerings of VMware LLC (formerly “VMware, Inc.” and individually and together with its subsidiaries, “VMware”), referred to as “VMware Resale,” and offerings of SecureWorks Corp. (“Secureworks”).  These businesses are not classified as reportable segments, either individually or collectively.

[0001571996-24-000036:mdna:13]
For further discussion regarding our current reportable segments, see “Item 1 Business”, “Results of Operations — Business Unit Results,” and Note 19 of the Notes to the Consolidated Financial Statements included in this report.

[0001571996-24-000036:mdna:14]
We offer customers choice in how they acquire our solutions including traditional purchasing and financing offerings provided by Dell Financial Services and its affiliates (“DFS”).  We also offer flexible consumption models, including utility, subscription, and as-a-Service models.  These offerings allow our customers to pay over time and provide them with operational and financial flexibility.  For additional information about our financing arrangements, see Note 6 of the Notes to the Consolidated Financial Statements included in this report.

[0001571996-24-000036:mdna:15]
Business Trends and Challenges

[0001571996-24-000036:mdna:16]
Fiscal 2024 Significant Developments — During Fiscal 2024, certain significant developments impacted the environment in which we operate.  Such developments, and their impact on our operations, were as follows:

[0001571996-24-000036:mdna:17]
•Macroeconomic uncertainty: Throughout the year, the effects of the evolving macroeconomic environment continued to impact industry-wide demand as customers were cautious and measured in their approach to IT spending, which affected our ISG and CSG net revenue performance.

[0001571996-24-000036:mdna:18]
•Advancements in artificial intelligence: Despite overall caution from our enterprise and large corporate customers, our ISG business benefited from increased demand for AI-optimized solutions as advancements in AI influenced customer spending behavior as organizations look to implement AI in their own operations.  Demand for AI-optimized servers outpaced the supply of graphics processing units (“GPUs”) for these products, resulting in elevated backlog levels for such offerings as we exited the fiscal year.

[0001571996-24-000036:mdna:19]
•Supply chain: Notwithstanding the constraints in supply for GPUs, our supply chain operated efficiently during the year.  We experienced a decline in component and logistics costs, which we refer to as input costs.  Input costs decreased generally as a result of declines in demand leading to improving supply positions for certain limited-source components as well as reductions in both expedited shipments and overall rate costs in the freight network.

[0001571996-24-000036:mdna:20]
•Broadcom’s acquisition of VMware: On November 22, 2023, Broadcom, Inc., (“Broadcom”) completed its acquisition of VMware, leading to changes to our relationship with VMware described below.  The changes affected our other businesses net revenue, most notably in the fourth quarter of the fiscal year.

[0001571996-24-000036:mdna:21]
Throughout the year, we remained focused on our key strategic priorities, building long-term value creation for our stakeholders, and addressing our customers’ needs while continuing to make prudent decisions in response to the environment.  We balanced profitability and growth while executing disciplined pricing and navigating through competitive pricing pressures, which increased as the year progressed.  Additionally, we continued to execute cost management measures, including limiting external hiring, employee reorganizations, and other actions to align our investments with our strategic priorities and customer needs.  These actions resulted in a reduction in our overall headcount.

[0001571996-24-000036:mdna:22]
Despite continued near-term challenges, we expect the demand environment to improve in Fiscal 2025 which will enable us to achieve net revenue growth for the full fiscal year.  We expect ISG net revenue to grow, driven by our AI-optimized servers, improving demand for our traditional servers, and a recovery in demand for our storage offerings.  We expect CSG net revenue growth for the full fiscal year, driven in part by the anticipated PC refresh cycle in the latter part of Fiscal 2025.  While we anticipate both ISG and CSG net revenue growth, we expect a continued reduction of our other businesses’ net revenue as a result of the change in our commercial relationship with VMware.

[0001571996-24-000036:mdna:23]
We expect input costs to increase during Fiscal 2025, principally driven by anticipated inflation for component costs as the year progresses.  Further, we anticipate that the pricing environment will be more competitive in Fiscal 2025, which we began to observe during the second half of Fiscal 2024.  Input cost trends are dependent on the strength or weakness of actual end-user demand and supply dynamics, which will continue to fluctuate and ultimately impact our costs, pricing, and operating results.  We plan to mitigate the impact of these dynamics through continued disciplined cost management.

[0001571996-24-000036:mdna:24]
Throughout Fiscal 2025, we will continue to advance our own capabilities to change the way we work and make decisions, improve business outcomes and the customer experience, and reduce cost by leveraging new technology to streamline our own systems and optimize business processes.  We believe our unique operating advantages provide a foundation to foster growth, drive efficiencies, and continue to position us for long-term success.

[0001571996-24-000036:mdna:25]
Relationship with VMware — On November 1, 2021, we completed our spin-off of VMware by means of a special stock dividend (the “VMware Spin-off”).  In connection with and upon completion of the VMware Spin-off, we entered into the Commercial Framework Agreement (“CFA”) with VMware, which provided the framework under which we and VMware continued our commercial relationship.  Pursuant to the CFA, we have acted as a distributor of VMware’s standalone products and services, purchased such products and services for resale to customers, and integrated VMware products and services with Dell Technologies’ offerings for sale to end-users.

[0001571996-24-000036:mdna:26]
On November 22, 2023, VMware was acquired by Broadcom.  Following the acquisition, Broadcom announced changes to its go-to-market approach for VMware offerings which impacted our commercial relationship with VMware.  In response to such changes, on January 25, 2024, under a provision of the CFA permitting us to terminate the agreement upon a change in control of VMware, we delivered notice of termination of the CFA to Broadcom under which the agreement will terminate on March 25, 2024.

[0001571996-24-000036:mdna:27]
The Company continues to integrate select VMware products and services with Dell Technologies’ offerings and sell them to end-users.  The results of such offerings are reflected within CSG or ISG, depending upon the nature of the underlying offering sold.

[0001571996-24-000036:mdna:28]
VMware was a related party until the date of its acquisition by Broadcom.  The acquisition terminated the preexisting related party relationship with VMware such that no related party relationship exists with either Broadcom or VMware as of the date of issuance of this report.  For more information regarding the impact of the Broadcom acquisition of VMware and our related party transactions with VMware, see Note 20 of the Notes to the Consolidated Financial Statements included in this report.

[0001571996-24-000036:mdna:29]
ISG — We expect that ISG will continue to be impacted by the evolving nature of the IT infrastructure market and competitive environment.  With our scale and strong solutions portfolio, we believe we are well-positioned to address the ongoing competitive dynamics and trends in technology and customer needs.  Through our collaborative, customer-focused approach to innovation, we strive to deliver new and relevant solutions and software to our customers quickly and efficiently.  We continue to focus on customer base expansion and the lifetime value of customer relationships.

[0001571996-24-000036:mdna:30]
We anticipate that ISG will continue to benefit from technology advances and customer interest in AI.  Through our server and storage offerings, including our AI-optimized solutions, we are well positioned to capture growth and support our customers’ needs.

[0001571996-24-000036:mdna:31]
We expect that growth in data will continue to generate long-term demand for our storage solutions and services.  Cloud native applications are expected to continue to be a key trend in the infrastructure market.  We benefit from offering solutions that address software-defined storage, hyper-converged infrastructure, and modular solutions based on server-centric architectures.  We continue to expand our offerings in external storage arrays, which incorporate flexible, cloud-based functionality.  Our storage business is subject to seasonal trends, which may continue to impact ISG results.

[0001571996-24-000036:mdna:32]
CSG — We participate in all segments of the PC market but focus on commercial and high-end consumer computing devices, as we believe they represent the most stable and profitable markets.  We anticipate that CSG will benefit from advances in AI in the long-term as customers will require PCs with the ability to run their complex AI workloads.

[0001571996-24-000036:mdna:33]
Competitive dynamics continue to be an important factor in our CSG business and continue to impact pricing and operating results.  We remain committed to our long-term CSG strategy and will continue to make investments to innovate across the portfolio.  We expect that the CSG demand environment will continue to be subject to seasonal trends.

[0001571996-24-000036:mdna:34]
Recurring Revenue and Consumption Models — We expect that our flexible consumption models will further strengthen our customer relationships and provide a foundation for growth in recurring revenue.  We define recurring revenue as revenue recognized that is primarily related to hardware and software maintenance as well as operating leases, subscription, as-a-Service, and usage-based offerings.

[0001571996-24-000036:mdna:35]
42

[0001571996-24-000036:mdna:36]
Strategic Investments and Acquisitions — As part of our strategy, we will continue to evaluate opportunities for strategic investments through our venture capital investment arm, Dell Technologies Capital, with a focus on emerging technology areas that are relevant to our business.  The technologies or products these companies have under development are typically in the early stages and may never have commercial value, which could result in a loss of a substantial part of our investment in the companies.

[0001571996-24-000036:mdna:37]
Foreign Currency Exposure — We manage our business on a U.S. dollar basis.  However, we have a large global presence, generating approximately half of our net revenue from sales to customers outside of the United States during Fiscal 2024 and Fiscal 2023.  As a result, our operating results can be, and particularly in recent periods have been, impacted by fluctuations in foreign currency exchange rates.  We utilize a comprehensive hedging strategy intended to mitigate the impact of foreign currency volatility over time, and we adjust pricing when possible to further minimize foreign currency impacts.

[0001571996-24-000036:mdna:38]
Other Macroeconomic Risks and Uncertainties — The impacts of trade protection measures, including increases in tariffs and trade barriers, changes in government policies and international trade arrangements, geopolitical volatility (including ongoing military conflicts in Ukraine and the Middle East), and global macroeconomic conditions (including those in China), may affect our ability to conduct business in some non-U.S. markets.  We monitor and seek to mitigate these risks with adjustments to our manufacturing, supply chain, and distribution networks.

[0001571996-24-000036:mdna:39]
43

[0001571996-24-000036:mdna:40]
NON-GAAP FINANCIAL MEASURES

[0001571996-24-000036:mdna:41]
In this management’s discussion and analysis, we use supplemental measures of our performance which are derived from our consolidated financial information but which are not presented in our consolidated financial statements prepared in accordance with GAAP.  These non-GAAP financial measures include non-GAAP product net revenue; non-GAAP services net revenue; non-GAAP net revenue; non-GAAP product gross margin; non-GAAP services gross margin; non-GAAP gross margin; non-GAAP operating expenses; non-GAAP operating income; non-GAAP net income; non-GAAP earnings per share attributable to Dell Technologies, Inc. - diluted; free cash flow; and adjusted free cash flow.  These non-GAAP financial measures are not meant to be considered as indicators of performance or liquidity in isolation from or as a substitute for gross margin, operating expenses, operating income, net income, diluted earnings per share, or cash flows from operating activities prepared in accordance with GAAP, and should be read only in conjunction with financial information presented on a GAAP basis.

[0001571996-24-000036:mdna:42]
We use non-GAAP financial measures to supplement financial information presented on a GAAP basis.  Management uses these non-GAAP measures in financial planning and forecasting and when evaluating our financial results and operating trends and performance.  We believe, when used supplementally with GAAP financial measures, these non-GAAP financial measures provide our investors with useful and transparent information to help them evaluate our results by facilitating an enhanced understanding of our results of operations and enabling them to make period to period comparisons.  There are limitations to the use of the non-GAAP financial measures presented in this report.  Our non-GAAP financial measures may not be comparable to similarly titled measures of other companies.  Other companies, including companies in our industry, may calculate non-GAAP financial measures differently than we do, limiting the usefulness of those measures for comparative purposes.

[0001571996-24-000036:mdna:43]
Non-GAAP product net revenue, non-GAAP services net revenue, non-GAAP net revenue, non-GAAP product gross margin, non-GAAP services gross margin, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP operating income, non-GAAP net income, and non-GAAP earnings per share attributable to Dell Technologies, Inc. - diluted, as defined by us, exclude amortization of intangible assets, the impact of purchase accounting, transaction-related expenses, stock-based compensation expense, other corporate expenses and, for non-GAAP net income and non-GAAP diluted earnings per share attributable to Dell Technologies, fair value adjustments on equity investments and an aggregate adjustment for income taxes.  As the excluded items may have a material impact on our financial results, our management compensates for this limitation by relying primarily on our GAAP results and using non-GAAP financial measures supplementally or for projections when comparable GAAP financial measures are not available.

[0001571996-24-000036:mdna:44]
Reconciliations of each non-GAAP financial measure to its most directly comparable GAAP financial measure are presented below.  We encourage you to review the reconciliations in conjunction with the presentation of the non-GAAP financial measures for each of the periods presented.  The discussion below includes information on each of the excluded items as well as our reasons for excluding them from our non-GAAP results.  In future fiscal periods, we may exclude such items and may incur income and expenses similar to these excluded items.  Accordingly, the exclusion of these items and other similar items in our non-GAAP presentation should not be interpreted as implying that these items are non-recurring, infrequent, or unusual.

[0001571996-24-000036:mdna:45]
The following is a summary of the items excluded from the most comparable GAAP financial measures to calculate our non-GAAP financial measures.

[0001571996-24-000036:mdna:46]
•Amortization of Intangible Assets — Amortization of intangible assets primarily consists of amortization of customer relationships, developed technology, and trade names.  In connection with our acquisition by merger of EMC, referred to as the “EMC merger transaction,” and the acquisition of Dell Inc. by Dell Technologies Inc., referred to as the “going-private transaction,” all of the tangible and intangible assets and liabilities of EMC and Dell Inc. and their consolidated subsidiaries, respectively, were accounted for and recognized at fair value on the transaction dates.  Accordingly, for the periods presented, amortization of intangible assets primarily represents amortization associated with intangible assets recognized in connection with the EMC merger transaction and the going-private transaction.  We exclude amortization charges for purchased intangible assets as they are significantly impacted by the timing and magnitude of our acquisitions, may vary in amount from period to period, and do not reflect current operating performance.

[0001571996-24-000036:mdna:47]
44

[0001571996-24-000036:mdna:48]
•Impact of Purchase Accounting — The impact of purchase accounting includes purchase accounting adjustments primarily related to the EMC merger transaction recorded under the acquisition method of accounting in accordance with the accounting guidance for business combinations.  In accordance with such guidance, all of the assets and liabilities acquired were accounted for and recognized at fair value as of the transaction date, and the fair value adjustments continue to amortize over the estimated useful lives in the periods following the transaction.  The fair value adjustments that are still amortizing primarily relate to property, plant, and equipment.  We exclude the impact of purchase accounting as it is does not reflect our current operating performance and charges are significantly impacted by the timing and magnitude of our acquisitions and, as a result, may vary in amount from period to period.

[0001571996-24-000036:mdna:49]
•Transaction-Related (Income) Expenses — Transaction-related expenses typically consist of acquisition, integration, and divestiture related costs, and are expensed as incurred.  During Fiscal 2022, this category also includes costs incurred in connection with the VMware Spin-off.  These expenses primarily represent costs for legal, banking, consulting, and advisory services.  During Fiscal 2022, this category included $1.5 billion in debt extinguishment fees primarily associated with the early retirement of certain senior notes.  From time to time, this category also may include transaction-related income related to divestitures of businesses or asset sales.  During Fiscal 2022, we recognized a pre-tax gain of $4.0 billion on the sale of our Boomi business.  We exclude transaction-related expenses because they are significantly impacted by the timing and magnitude of our acquisitions and divestitures and do not reflect current operating performance.

[0001571996-24-000036:mdna:50]
•Stock-based Compensation Expense — Stock-based compensation expense consists of equity awards granted based on the estimated fair value of those awards at grant date.  To estimate the fair value of performance-based awards containing a market condition, we use the Monte Carlo valuation model.  For other share-based awards, the fair value is generally based on the closing price of the Class C Common Stock as reported on the NYSE on the date of grant.  Although stock-based compensation is an important aspect of the compensation of our employees and executives, we exclude such expense because the fair value of the stock-based awards may fluctuate based on factors unrelated to the operating performance of the business and may bear little resemblance to the actual value realized upon the vesting or future exercise of the related stock-based awards.

[0001571996-24-000036:mdna:51]
•Other Corporate Expenses — Other corporate expenses consist primarily of impairment charges, severance expenses, incentive charges related to equity investments, facility action costs, and payroll taxes associated with stock-based compensation.  During Fiscal 2024 and Fiscal 2023, we recognized $0.6 billion and $0.5 billion, respectively, of severance expense related to workforce reduction activities.  Severance costs are primarily related to severance and benefits for employees terminated pursuant to cost savings initiatives.  During Fiscal 2023, other corporate expenses includes $0.9 billion of net expense recognized within interest and other, net, in connection with an agreement to settle the Class V transaction litigation.  See Note 12 of the Notes to the Consolidated Financial Statements included in this report for information about this matter.  Although we may incur these types of expenses in the future, we exclude other corporate expenses as they can vary from period to period, are significantly impacted by the timing and nature of these events, and are not used by management in assessing operating performance of the business.

[0001571996-24-000036:mdna:52]
•Fair Value Adjustments on Equity Investments — Fair value adjustments on equity investments primarily consist of the gain (loss) on strategic investments, which includes recurring fair value adjustments of investments in publicly-traded companies, as well as those in privately-held companies, which are adjusted for observable price changes and any potential impairments.  See Note 5 of the Notes to the Consolidated Financial Statements included in this report for additional information on our strategic investment activity.  We exclude fair value adjustments on equity investments given the volatility in ongoing adjustments to the valuation of these strategic investments and because such adjustments are unrelated to the operating performance of our business.

[0001571996-24-000036:mdna:53]
•Aggregate Adjustment for Income Taxes — The aggregate adjustment for income taxes is the estimated combined income tax effect for the adjustments described above, as well as an adjustment for discrete tax items.  We exclude these benefits or charges for purposes of calculating non-GAAP net income due to the variability in recognition of discrete tax items from period to period.  The tax effects are determined based on the tax jurisdictions where the above items were incurred.  See Note 13 of the Notes to the Consolidated Financial Statements included in this report for additional information about our income taxes.  Beginning in Fiscal 2025, our non-GAAP income tax will be calculated using a fixed estimated annual tax rate which will be determined based on historical trends and projections for the current fiscal year.  We may adjust our estimated annual tax rate during the fiscal year to take into account events that would significantly impact our income tax expense, including significant changes resulting from tax legislation, material changes in the geographic mix of revenue and expenses, changes to our corporate structure, and other significant events.

[0001571996-24-000036:mdna:54]
45

[0001571996-24-000036:mdna:55]
The following table presents a reconciliation of each non-GAAP financial measure to the most directly comparable GAAP measure for the periods indicated:

[0001571996-24-000036:mdna:56]
|  |  |  | Fiscal Year Ended |
|  |  |  |  |  |  |  | February 2, 2024 |  | % Change |  | February 3, 2023 |  | % Change |  | January 28, 2022 |
|  |  |  |  |  |  |  | (in millions, except percentages) |
| Product net revenue |  |  |  |  |  |  | $ | 64,353 |  |  | (19) | % |  | $ | 79,250 |  |  | (1) | % |  | $ | 79,830 |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Impact of purchase accounting |  |  |  |  |  |  | — |  |  |  |  | — |  |  |  |  | — |  |
| Non-GAAP product net revenue |  |  |  |  |  |  | $ | 64,353 |  |  | (19) | % |  | $ | 79,250 |  |  | (1) | % |  | $ | 79,830 |  |
| Services net revenue |  |  |  |  |  |  | $ | 24,072 |  |  | 4 | % |  | $ | 23,051 |  |  | 8 | % |  | $ | 21,367 |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Impact of purchase accounting |  |  |  |  |  |  | — |  |  |  |  | — |  |  |  |  | 32 |  |
| Non-GAAP services net revenue |  |  |  |  |  |  | $ | 24,072 |  |  | 4 | % |  | $ | 23,051 |  |  | 8 | % |  | $ | 21,399 |  |
| Net revenue |  |  |  |  |  |  | $ | 88,425 |  |  | (14) | % |  | $ | 102,301 |  |  | 1 | % |  | $ | 101,197 |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Impact of purchase accounting |  |  |  |  |  |  | — |  |  |  |  | — |  |  |  |  | 32 |  |
| Non-GAAP net revenue |  |  |  |  |  |  | $ | 88,425 |  |  | (14) | % |  | $ | 102,301 |  |  | 1 | % |  | $ | 101,229 |  |
| Product gross margin |  |  |  |  |  |  | $ | 11,037 |  |  | (17) | % |  | $ | 13,221 |  |  | 5 | % |  | $ | 12,606 |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles |  |  |  |  |  |  | 331 |  |  |  |  | 414 |  |  |  |  | 598 |  |
| Impact of purchase accounting |  |  |  |  |  |  | — |  |  |  |  | 2 |  |  |  |  | 3 |  |
| Stock-based compensation expense |  |  |  |  |  |  | 51 |  |  |  |  | 52 |  |  |  |  | 48 |  |
| Other corporate expenses |  |  |  |  |  |  | 23 |  |  |  |  | 32 |  |  |  |  | 6 |  |
| Non-GAAP product gross margin |  |  |  |  |  |  | $ | 11,442 |  |  | (17) | % |  | $ | 13,721 |  |  | 3 | % |  | $ | 13,261 |  |
| Services gross margin |  |  |  |  |  |  | $ | 9,832 |  |  | 4 | % |  | $ | 9,465 |  |  | 2 | % |  | $ | 9,285 |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Impact of purchase accounting |  |  |  |  |  |  | — |  |  |  |  | — |  |  |  |  | 32 |  |
| Stock-based compensation expense |  |  |  |  |  |  | 98 |  |  |  |  | 100 |  |  |  |  | 85 |  |
| Other corporate expenses |  |  |  |  |  |  | 72 |  |  |  |  | 141 |  |  |  |  | 21 |  |
| Non-GAAP services gross margin |  |  |  |  |  |  | $ | 10,002 |  |  | 3 | % |  | $ | 9,706 |  |  | 3 | % |  | $ | 9,423 |  |
| Gross margin |  |  |  |  |  |  | $ | 20,869 |  |  | (8) | % |  | $ | 22,686 |  |  | 4 | % |  | $ | 21,891 |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles |  |  |  |  |  |  | 331 |  |  |  |  | 414 |  |  |  |  | 598 |  |
| Impact of purchase accounting |  |  |  |  |  |  | — |  |  |  |  | 2 |  |  |  |  | 35 |  |
| Stock-based compensation expense |  |  |  |  |  |  | 149 |  |  |  |  | 152 |  |  |  |  | 133 |  |
| Other corporate expenses |  |  |  |  |  |  | 95 |  |  |  |  | 173 |  |  |  |  | 27 |  |
| Non-GAAP gross margin |  |  |  |  |  |  | $ | 21,444 |  |  | (8) | % |  | $ | 23,427 |  |  | 3 | % |  | $ | 22,684 |  |

[0001571996-24-000036:mdna:57]
|  |  |  | Fiscal Year Ended |
|  |  |  |  |  |  |  | February 2, 2024 |  | % Change |  | February 3, 2023 |  | % Change |  | January 28, 2022 |
|  |  |  |  |  |  |  | (in millions, except percentages) |
| Operating expenses |  |  |  |  |  |  | $ | 15,658 |  |  | (7) | % |  | $ | 16,915 |  |  | (2) | % |  | $ | 17,232 |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles |  |  |  |  |  |  | (488) |  |  |  |  | (556) |  |  |  |  | (1,043) |  |
| Impact of purchase accounting |  |  |  |  |  |  | (14) |  |  |  |  | (42) |  |  |  |  | (32) |  |
| Transaction-related expenses |  |  |  |  |  |  | (12) |  |  |  |  | (22) |  |  |  |  | (273) |  |
| Stock-based compensation expense |  |  |  |  |  |  | (729) |  |  |  |  | (779) |  |  |  |  | (675) |  |
| Other corporate expenses |  |  |  |  |  |  | (649) |  |  |  |  | (726) |  |  |  |  | (310) |  |
| Non-GAAP operating expenses |  |  |  |  |  |  | $ | 13,766 |  |  | (7) | % |  | $ | 14,790 |  |  | (1) | % |  | $ | 14,899 |  |
| Operating income |  |  |  |  |  |  | $ | 5,211 |  |  | (10) | % |  | $ | 5,771 |  |  | 24 | % |  | $ | 4,659 |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles |  |  |  |  |  |  | 819 |  |  |  |  | 970 |  |  |  |  | 1,641 |  |
| Impact of purchase accounting |  |  |  |  |  |  | 14 |  |  |  |  | 44 |  |  |  |  | 67 |  |
| Transaction-related expenses |  |  |  |  |  |  | 12 |  |  |  |  | 22 |  |  |  |  | 273 |  |
| Stock-based compensation expense |  |  |  |  |  |  | 878 |  |  |  |  | 931 |  |  |  |  | 808 |  |
| Other corporate expenses |  |  |  |  |  |  | 744 |  |  |  |  | 899 |  |  |  |  | 337 |  |
| Non-GAAP operating income |  |  |  |  |  |  | $ | 7,678 |  |  | (11) | % |  | $ | 8,637 |  |  | 11 | % |  | $ | 7,785 |  |
| Net income |  |  |  |  |  |  | $ | 3,195 |  |  | 32 | % |  | $ | 2,422 |  |  | (51) | % |  | $ | 4,942 |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles |  |  |  |  |  |  | 819 |  |  |  |  | 970 |  |  |  |  | 1,641 |  |
| Impact of purchase accounting |  |  |  |  |  |  | 14 |  |  |  |  | 44 |  |  |  |  | 67 |  |
| Transaction-related (income) expenses |  |  |  |  |  |  | 49 |  |  |  |  | (16) |  |  |  |  | (2,143) |  |
| Stock-based compensation expense |  |  |  |  |  |  | 878 |  |  |  |  | 931 |  |  |  |  | 808 |  |
| Other corporate expenses |  |  |  |  |  |  | 744 |  |  |  |  | 1,812 |  |  |  |  | 337 |  |
| Fair value adjustments on equity investments |  |  |  |  |  |  | (47) |  |  |  |  | 206 |  |  |  |  | (572) |  |
| Aggregate adjustment for income taxes |  |  |  |  |  |  | (407) |  |  |  |  | (642) |  |  |  |  | (156) |  |
| Non-GAAP net income |  |  |  |  |  |  | $ | 5,245 |  |  | (8) | % |  | $ | 5,727 |  |  | 16 | % |  | $ | 4,924 |  |

[0001571996-24-000036:mdna:58]
47

[0001571996-24-000036:mdna:59]
|  |  |  | Fiscal Year Ended |
|  |  |  |  |  |  |  | February 2,2024 |  | % Change |  | February 3,2023 |  | % Change |  | January 28,2022 |
| Earnings per share attributable to Dell Technologies, Inc. — diluted |  |  |  |  |  |  | $ | 4.36 |  |  | 35 | % |  | $ | 3.24 |  |  | (48) | % |  | $ | 6.26 |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles |  |  |  |  |  |  | 1.11 |  |  |  |  | 1.29 |  |  |  |  | 2.07 |  |
| Impact of purchase accounting |  |  |  |  |  |  | 0.02 |  |  |  |  | 0.06 |  |  |  |  | 0.08 |  |
| Transaction-related (income) expenses |  |  |  |  |  |  | 0.07 |  |  |  |  | (0.02) |  |  |  |  | (2.71) |  |
| Stock-based compensation expense |  |  |  |  |  |  | 1.19 |  |  |  |  | 1.24 |  |  |  |  | 1.02 |  |
| Other corporate expenses |  |  |  |  |  |  | 1.01 |  |  |  |  | 2.41 |  |  |  |  | 0.43 |  |
| Fair value adjustments on equity investments |  |  |  |  |  |  | (0.06) |  |  |  |  | 0.27 |  |  |  |  | (0.72) |  |
| Aggregate adjustment for income taxes |  |  |  |  |  |  | (0.55) |  |  |  |  | (0.86) |  |  |  |  | (0.20) |  |
| Total non-GAAP adjustments attributable to non-controlling interests |  |  |  |  |  |  | (0.02) |  |  |  |  | (0.02) |  |  |  |  | (0.01) |  |
| Non-GAAP earnings per share attributable to Dell Technologies, Inc. — diluted |  |  |  |  |  |  | $ | 7.13 |  |  | (6) | % |  | $ | 7.61 |  |  | 22 | % |  | $ | 6.22 |  |

[0001571996-24-000036:mdna:60]
48

[0001571996-24-000036:mdna:61]
In addition to the above measures, we consider free cash flow and adjusted free cash flow to be liquidity measures that provide useful information to management and investors in part because we use these metrics in our long-term capital allocation framework.  Further, we believe free cash flow and adjusted free cash flow are useful measures to management and investors because they reflect cash that we can use to, among other purposes, repurchase common stock, pay dividends on our common stock, invest in our business, pay down debt, and make strategic acquisitions.

[0001571996-24-000036:mdna:62]
As is the case with the non-GAAP measures presented above, users should consider the limitations of using free cash flow and adjusted free cash flow, including the fact that those measures do not provide a complete measure of our cash flows for any period.  Free cash flow and adjusted free cash flow do not purport to be alternatives to cash flows from operating activities as a measure of liquidity.  In particular, free cash flow and adjusted free cash flow are not intended to be a measure of cash flow available for management’s discretionary use, as these measures do not consider certain cash requirements, such as debt service requirements and other contractual commitments.

[0001571996-24-000036:mdna:63]
The following table presents a reconciliation of free cash flow and adjusted free cash flow to cash from operating activities for the periods indicated:

[0001571996-24-000036:mdna:64]
|  |  |  | Fiscal Year Ended |
|  |  |  |  |  |  |  | February 2,2024 |  | % Change |  | February 3,2023 |  | % Change |  | January 28,2022 |
|  |  |  |  |  |  |  | (in millions, except percentages) |
| Cash flow from operations |  |  |  |  |  |  | $ | 8,676 |  |  | 143 | % |  | $ | 3,565 |  |  | (65) | % |  | $ | 10,307 |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Capital expenditures and capitalized software development costs, net (a) |  |  |  |  |  |  | (2,753) |  |  |  |  | (2,993) |  |  |  |  | (2,755) |  |
| Free cash flow |  |  |  |  |  |  | $ | 5,923 |  |  | 935 | % |  | $ | 572 |  |  | (92) | % |  | $ | 7,552 |  |
| Free cash flow |  |  |  |  |  |  | $ | 5,923 |  |  | 935 | % |  | $ | 572 |  |  | (92) | % |  | $ | 7,552 |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| DFS financing receivables (b) |  |  |  |  |  |  | (309) |  |  |  |  | 461 |  |  |  |  | 241 |  |
| DFS operating leases (c) |  |  |  |  |  |  | (7) |  |  |  |  | 500 |  |  |  |  | 394 |  |
| Adjusted free cash flow |  |  |  |  |  |  | $ | 5,607 |  |  | 266 | % |  | $ | 1,533 |  |  | (81) | % |  | $ | 8,187 |  |

[0001571996-24-000036:mdna:65]
____________________

[0001571996-24-000036:mdna:66]
(a)    Capital expenditures and capitalized software development costs, net include proceeds from sales of facilities, land, and other assets.

[0001571996-24-000036:mdna:67]
(b)    DFS financing receivables represent the operating cash flow impact from the change in financing receivables.

[0001571996-24-000036:mdna:68]
(c)    DFS operating leases represent the change in net carrying value of equipment for DFS operating leases.

[0001571996-24-000036:mdna:69]
We exclude the cash flow impact of DFS financing receivables and operating leases from our adjusted free cash flow, as the initial funding at the time of origination is largely subsequently replaced with cash inflows from DFS debt, the majority of which is asset-backed.

[0001571996-24-000036:mdna:70]
49

[0001571996-24-000036:mdna:71]
RESULTS OF OPERATIONS

[0001571996-24-000036:mdna:72]
Consolidated Results

[0001571996-24-000036:mdna:73]
The following table summarizes our consolidated results for the periods indicated.  Unless otherwise indicated, all changes identified for the current-period results represent comparisons to results for the prior corresponding fiscal period.

[0001571996-24-000036:mdna:74]
|  |  |  | Fiscal Year Ended |
|  |  |  |  |  |  |  | February 2, 2024 |  |  |  | February 3, 2023 |  |  |  | January 28, 2022 |
|  |  |  |  |  |  |  |  |  |  |  | Dollars |  | % ofNet Revenue |  | %Change |  | Dollars |  | % ofNet Revenue |  | %Change |  | Dollars |  | % ofNet Revenue |
|  |  |  |  |  |  |  |  |  |  |  | (in millions, except percentages and per share amounts) |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Products |  |  |  |  |  |  |  |  |  |  | $ | 64,353 |  |  | 72.8 | % |  | (19) | % |  | $ | 79,250 |  |  | 77.5 | % |  | (1) | % |  | $ | 79,830 |  |  | 78.9 | % |
| Services |  |  |  |  |  |  |  |  |  |  | 24,072 |  |  | 27.2 | % |  | 4 | % |  | 23,051 |  |  | 22.5 | % |  | 8 | % |  | 21,367 |  |  | 21.1 | % |
| Total net revenue |  |  |  |  |  |  |  |  |  |  | $ | 88,425 |  |  | 100.0 | % |  | (14) | % |  | $ | 102,301 |  |  | 100.0 | % |  | 1 | % |  | $ | 101,197 |  |  | 100.0 | % |
| Gross margin: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Products |  |  |  |  |  |  |  |  |  |  | $ | 11,037 |  |  | 17.2 | % |  | (17) | % |  | $ | 13,221 |  |  | 16.7 | % |  | 5 | % |  | $ | 12,606 |  |  | 15.8 | % |
| Services |  |  |  |  |  |  |  |  |  |  | 9,832 |  |  | 40.8 | % |  | 4 | % |  | 9,465 |  |  | 41.1 | % |  | 2 | % |  | 9,285 |  |  | 43.5 | % |
| Total gross margin |  |  |  |  |  |  |  |  |  |  | $ | 20,869 |  |  | 23.6 | % |  | (8) | % |  | $ | 22,686 |  |  | 22.2 | % |  | 4 | % |  | $ | 21,891 |  |  | 21.6 | % |
| Operating expenses |  |  |  |  |  |  |  |  |  |  | $ | 15,658 |  |  | 17.7 | % |  | (7) | % |  | $ | 16,915 |  |  | 16.6 | % |  | (2) | % |  | $ | 17,232 |  |  | 17.0 | % |
| Operating income |  |  |  |  |  |  |  |  |  |  | $ | 5,211 |  |  | 5.9 | % |  | (10) | % |  | $ | 5,771 |  |  | 5.6 | % |  | 24 | % |  | $ | 4,659 |  |  | 4.6 | % |
| Net income |  |  |  |  |  |  |  |  |  |  | $ | 3,195 |  |  | 3.6 | % |  | 32 | % |  | $ | 2,422 |  |  | 2.4 | % |  | (51) | % |  | $ | 4,942 |  |  | 4.9 | % |
| Earnings per share attributable to Dell Technologies — diluted |  |  |  |  |  |  |  |  |  |  | $ | 4.36 |  |  |  |  | 35 | % |  | $ | 3.24 |  |  |  |  | (48) | % |  | $ | 6.26 |  |  |  |
| Cash flow from operations |  |  |  |  |  |  |  |  |  |  | $ | 8,676 |  |  |  |  | 143 | % |  | $ | 3,565 |  |  |  |  | (65) | % |  | $ | 10,307 |  |  |  |
| Non-GAAP Financial Information |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  |  | Fiscal Year Ended |
|  |  |  |  |  |  |  | February 2, 2024 |  |  |  | February 3, 2023 |  |  |  | January 28, 2022 |
|  |  |  |  |  |  |  |  |  |  |  | Dollars |  | % of Non-GAAPNet Revenue |  | %Change |  | Dollars |  | % of Non-GAAPNet Revenue |  | %Change |  | Dollars |  | % of Non-GAAPNet Revenue |
|  |  |  |  |  |  |  |  |  |  |  | (in millions, except percentages and per share amounts) |
| Non-GAAP net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Products |  |  |  |  |  |  |  |  |  |  | $ | 64,353 |  |  | 72.8 | % |  | (19) | % |  | $ | 79,250 |  |  | 77.5 | % |  | (1) | % |  | $ | 79,830 |  |  | 78.9 | % |
| Services |  |  |  |  |  |  |  |  |  |  | 24,072 |  |  | 27.2 | % |  | 4 | % |  | 23,051 |  |  | 22.5 | % |  | 8 | % |  | 21,399 |  |  | 21.1 | % |
| Total non-GAAP net revenue |  |  |  |  |  |  |  |  |  |  | $ | 88,425 |  |  | 100.0 | % |  | (14) | % |  | $ | 102,301 |  |  | 100.0 | % |  | 1 | % |  | $ | 101,229 |  |  | 100.0 | % |
| Non-GAAP gross margin: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Products |  |  |  |  |  |  |  |  |  |  | $ | 11,442 |  |  | 17.8 | % |  | (17) | % |  | $ | 13,721 |  |  | 17.3 | % |  | 3 | % |  | $ | 13,261 |  |  | 16.6 | % |
| Services |  |  |  |  |  |  |  |  |  |  | 10,002 |  |  | 41.6 | % |  | 3 | % |  | 9,706 |  |  | 42.1 | % |  | 3 | % |  | 9,423 |  |  | 44.0 | % |
| Total non-GAAP gross margin |  |  |  |  |  |  |  |  |  |  | $ | 21,444 |  |  | 24.3 | % |  | (8) | % |  | $ | 23,427 |  |  | 22.9 | % |  | 3 | % |  | $ | 22,684 |  |  | 22.4 | % |
| Non-GAAP operating expenses |  |  |  |  |  |  |  |  |  |  | $ | 13,766 |  |  | 15.6 | % |  | (7) | % |  | $ | 14,790 |  |  | 14.5 | % |  | (1) | % |  | $ | 14,899 |  |  | 14.7 | % |
| Non-GAAP operating income |  |  |  |  |  |  |  |  |  |  | $ | 7,678 |  |  | 8.7 | % |  | (11) | % |  | $ | 8,637 |  |  | 8.4 | % |  | 11 | % |  | $ | 7,785 |  |  | 7.7 | % |
| Non-GAAP net income |  |  |  |  |  |  |  |  |  |  | $ | 5,245 |  |  | 5.9 | % |  | (8) | % |  | $ | 5,727 |  |  | 5.6 | % |  | 16 | % |  | $ | 4,924 |  |  | 4.9 | % |
| Non-GAAP earnings per share attributable to Dell Technologies — diluted |  |  |  |  |  |  |  |  |  |  | $ | 7.13 |  |  |  |  | (6) | % |  | $ | 7.61 |  |  |  |  | 22 | % |  | $ | 6.22 |  |  |  |
| Free cash flow |  |  |  |  |  |  |  |  |  |  | $ | 5,923 |  |  |  |  | 935 | % |  | $ | 572 |  |  |  |  | (92) | % |  | $ | 7,552 |  |  |  |
| Adjusted free cash flow |  |  |  |  |  |  |  |  |  |  | $ | 5,607 |  |  |  |  | 266 | % |  | $ | 1,533 |  |  |  |  | (81) | % |  | $ | 8,187 |  |  |  |

[0001571996-24-000036:mdna:75]
50

[0001571996-24-000036:mdna:76]
Non-GAAP product net revenue, non-GAAP services net revenue, non-GAAP net revenue, non-GAAP product gross margin, non-GAAP services gross margin, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP operating income, non-GAAP net income, non-GAAP diluted earnings per share attributable to Dell Technologies, free cash flow, and adjusted free cash flow are not measurements of financial performance prepared in accordance with GAAP.  Non-GAAP financial measures as a percentage of revenue are calculated based on non-GAAP net revenue, where applicable.  See “Non‑GAAP Financial Measures” for additional information about these non-GAAP financial measures, including our reasons for including these measures, material limitations with respect to the usefulness of the measures, and a reconciliation of each non-GAAP financial measure to the most directly comparable GAAP financial measure.

[0001571996-24-000036:mdna:77]
Overview

[0001571996-24-000036:mdna:78]
During Fiscal 2024, net revenue decreased by 14%, driven by declines in CSG net revenue and, to a lesser extent, ISG net revenue, which reflected the prolonged impact of global macroeconomic conditions on demand.  The decline in CSG net revenue was primarily attributable to a decrease in units sold within both commercial and consumer offerings, partially offset by an increase in the average selling prices of our commercial offerings.  ISG net revenue decreased as a result of a reduction in net revenue attributable to our servers and networking offerings and, to a lesser extent, our storage offerings.

[0001571996-24-000036:mdna:79]
Operating income and non-GAAP operating income decreased by 10% to $5.2 billion and 11% to $7.7 billion, respectively, during Fiscal 2024.  The decline in operating income and non-GAAP operating income was driven by a decrease in ISG operating income and, to a lesser extent, CSG operating income, which both declined primarily as a result of a decrease in net revenue that outpaced the favorable impacts of a decline in input costs and cost management measures.  The decline in ISG operating income was primarily attributable to decreases in our servers and networking offerings and, to a lesser extent, our storage offerings.  The decline in CSG operating income was driven by decreases in both commercial and consumer offerings.  The decline in operating income was partially offset by decreases in other corporate expenses and amortization of intangibles.

[0001571996-24-000036:mdna:80]
During Fiscal 2024, both operating income and non-GAAP operating income as a percentage of net revenue increased 30 basis points to 5.9% and 8.7%, respectively.  These increases were due to an increase in gross margin as a percentage of net revenue, which was principally driven by a decline in input costs.  The increase in operating income and non-GAAP operating income as a percentage of net revenue was offset by an increase in operating expense rate, principally within ISG, that was attributable to a decrease in net revenue which outpaced the impact of continued cost management measures.

[0001571996-24-000036:mdna:81]
Cash provided by operating activities was $8.7 billion during Fiscal 2024, and was primarily driven by profitability coupled with strong inventory management and cash collections performance.  During Fiscal 2023, cash provided by operating activities was $3.6 billion, which primarily reflected profitability that was partially offset by the impact of working capital dynamics.  See “Liquidity, Cash Requirements, and Market Conditions” for additional information about our cash flow metrics.

[0001571996-24-000036:mdna:82]
Despite the near-term challenges driven by uncertainty in the macroeconomic environment, we continue to see opportunities to create value and grow as we respond to long-term demand for our IT solutions driven by a technology- and data-enabled world.  We have demonstrated our ability to adjust to changing market conditions with complementary solutions and innovation across both segments of our business, an agile workforce, and the strength of our global supply chain.  As we continue to innovate and modernize our offerings, we believe that Dell Technologies is well-positioned for long-term profitable growth.

[0001571996-24-000036:mdna:83]
Net Revenue

[0001571996-24-000036:mdna:84]
During Fiscal 2024, net revenue decreased 14%, primarily driven by declines in CSG net revenue and, to a lesser extent, ISG net revenue.  See “Business Unit Results” for further information.

[0001571996-24-000036:mdna:85]
•Product Net Revenue — Product net revenue includes revenue from the sale of hardware products and software licenses.  During Fiscal 2024, product net revenue decreased 19%, due to declines in CSG product net revenue and, to a lesser extent, ISG product net revenue.  CSG product net revenue decreased primarily as a result of a decline in units sold, which impacted both our commercial and consumer offerings.  The decline in ISG product net revenue was primarily attributable to a decrease in product net revenue attributable to our servers and networking offerings driven by a decrease in units sold, and, to a lesser extent, a decline in our product net revenue attributable to storage offerings.

[0001571996-24-000036:mdna:86]
51

[0001571996-24-000036:mdna:87]
•Services Net Revenue — Services net revenue includes revenue from our services offerings and support services related to hardware products and software licenses.  During Fiscal 2024, services net revenue increased 4%, driven primarily by growth within services net revenue attributable to CSG and other businesses.  The increase in services net revenue attributable to CSG was driven primarily by third-party software support and maintenance and hardware support and maintenance.  The increase in services net revenue attributable to other businesses was driven primarily by VMware software maintenance arrangements.  See “Introduction” for additional information about the impact of Broadcom’s acquisition of VMware on our relationship with VMware.

[0001571996-24-000036:mdna:88]
A substantial portion of services net revenue is derived from offerings that have been deferred over a period of time, and, as a result, reported growth rates for services net revenue will be different than reported growth rates for product net revenue.

[0001571996-24-000036:mdna:89]
From a geographical perspective, net revenue decreased in the Americas, EMEA, and APJ during Fiscal 2024, most notably within APJ.

[0001571996-24-000036:mdna:90]
Gross Margin

[0001571996-24-000036:mdna:91]
During Fiscal 2024, gross margin and non-GAAP gross margin both decreased 8% to $20.9 billion and $21.4 billion, respectively.  The declines were driven by decreases in both ISG and CSG gross margin that were primarily attributable to a decrease in net revenue, the effect of which was partially offset by lower input costs.

[0001571996-24-000036:mdna:92]
Both gross margin and non-GAAP gross margin percentage increased 140 basis points to 23.6% and 24.3%, respectively, during Fiscal 2024.  The increases were primarily attributable to the impacts of an overall decline in input costs coupled with an increase in average selling price across many of our offerings as we continued to exercise disciplined pricing in an increasingly competitive environment.

[0001571996-24-000036:mdna:93]
•Product Gross Margin — During Fiscal 2024, product gross margin and non-GAAP product gross margin both decreased 17% to $11.0 billion and $11.4 billion, respectively.  The decreases were primarily driven by declines in both ISG and CSG product gross margin, which were largely attributable to declines in product net revenue, partially offset by lower input costs.

[0001571996-24-000036:mdna:94]
During Fiscal 2024, product gross margin percentage and non-GAAP product gross margin percentage both increased 50 basis points to 17.2% and 17.8%, respectively, primarily due to an increase in CSG product gross margin percentage.  CSG product gross margin percentage increased primarily as a result of the impacts of an overall decline in input costs coupled with an increase in average selling price across many of our product offerings.

[0001571996-24-000036:mdna:95]
•Services Gross Margin — During Fiscal 2024, services gross margin and non-GAAP services gross margin increased 4% to $9.8 billion and 3% to $10.0 billion, respectively.  The increases were primarily attributable to growth within ISG services gross margin and, to a lesser extent, CSG services gross margin, that were driven by support and maintenance associated with products sold in prior periods.

[0001571996-24-000036:mdna:96]
During Fiscal 2024, services gross margin percentage decreased 30 basis points to 40.8% and non-GAAP services gross margin percentage decreased 50 basis points to 41.6%.  The decreases were driven primarily by a shift in mix of services delivered.

[0001571996-24-000036:mdna:97]
Vendor Programs

[0001571996-24-000036:mdna:98]
Our gross margin is affected by our ability to achieve competitive pricing with our vendors and contract manufacturers, including through our negotiation of a variety of vendor rebate programs to achieve lower net costs for the various components we include in our products.  Under these programs, vendors provide us with rebates or other discounts from the list prices for the components, which are generally elements of their pricing strategy.  We account for vendor rebates and other discounts as a reduction in cost of net revenue.  We manage our costs on a total net cost basis, which includes supplier list prices reduced by vendor rebates and other discounts.

[0001571996-24-000036:mdna:99]
52

[0001571996-24-000036:mdna:100]
The terms and conditions of our vendor rebate programs are largely based on product volumes and are generally negotiated either at the beginning of the annual or quarterly period, depending on the program.  The timing and amount of vendor rebates and other discounts we receive under the programs may vary from period to period, reflecting changes in the competitive environment.  We monitor our component costs and seek to address the effects of any changes to terms that might arise under our vendor rebate programs.  Our gross margins for Fiscal 2024 were not materially affected by any changes to the terms of our vendor rebate programs, as the amounts we received under these programs were generally stable relative to our total net cost.  We are not aware of any significant changes to our vendor rebate programs that will materially impact our results in the near term.

[0001571996-24-000036:mdna:101]
Operating Expenses

[0001571996-24-000036:mdna:102]
The following table presents information regarding our operating expenses for the periods indicated:

[0001571996-24-000036:mdna:103]
|  |  |  | Fiscal Year Ended |
|  |  |  |  |  |  |  | February 2, 2024 |  |  |  | February 3, 2023 |  |  |  | January 28, 2022 |
|  |  |  |  |  |  |  |  |  |  |  | Dollars |  | % of Net Revenue |  | %Change |  | Dollars |  | % of Net Revenue |  | %Change |  | Dollars |  | % of Net Revenue |
|  |  |  |  |  |  |  |  |  |  |  | (in millions, except percentages) |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling, general, and administrative |  |  |  |  |  |  |  |  |  |  | $ | 12,857 |  |  | 14.5 | % |  | (9) | % |  | $ | 14,136 |  |  | 13.9 | % |  | (4) | % |  | $ | 14,655 |  |  | 14.5 | % |
| Research and development |  |  |  |  |  |  |  |  |  |  | 2,801 |  |  | 3.2 | % |  | 1 | % |  | 2,779 |  |  | 2.7 | % |  | 8 | % |  | 2,577 |  |  | 2.5 | % |
| Total operating expenses |  |  |  |  |  |  |  |  |  |  | $ | 15,658 |  |  | 17.7 | % |  | (7) | % |  | $ | 16,915 |  |  | 16.6 | % |  | (2) | % |  | $ | 17,232 |  |  | 17.0 | % |
|  |  |  | Fiscal Year Ended |
|  |  |  |  |  |  |  | February 2, 2024 |  |  |  | February 3, 2023 |  |  |  | January 28, 2022 |
|  |  |  |  |  |  |  |  |  |  |  | Dollars |  | % of Net Revenue |  | %Change |  | Dollars |  | % of Net Revenue |  | % Change |  | Dollars |  | % of Net Revenue |
|  |  |  |  |  |  |  |  |  |  |  | (in millions, except percentages) |
| Non-GAAP operating expenses |  |  |  |  |  |  |  |  |  |  | $ | 13,766 |  |  | 15.6 | % |  | (7) | % |  | $ | 14,790 |  |  | 14.5 | % |  | (1) | % |  | $ | 14,899 |  |  | 14.7 | % |

[0001571996-24-000036:mdna:104]
During Fiscal 2024, total operating expenses decreased 7%, due to a decline in selling, general, and administrative expenses.

[0001571996-24-000036:mdna:105]
•Selling, General, and Administrative — During Fiscal 2024, selling, general, and administrative (“SG&A”) expenses decreased 9%, driven by a decrease in employee compensation and benefits expense, principally due to a decline in overall headcount and, to a lesser extent, a decrease in advertising and outside services expense as a result of continued disciplined cost management.

[0001571996-24-000036:mdna:106]
•Research and Development — Research and development (“R&D”) expenses are primarily composed of personnel-related expenses incurred in connection with product development.  R&D expenses increased 1% during Fiscal 2024, principally due to an increase in R&D-related employee compensation and benefits expense, partially offset by a decrease in outside services as a result of continued disciplined cost management.

[0001571996-24-000036:mdna:107]
As a percentage of net revenue, R&D expenses for Fiscal 2024 and Fiscal 2023 were 3.2% and 2.7%, respectively.  The increases in R&D expenses as a percentage of net revenue were attributable to continued R&D investments as we support R&D initiatives to innovate and introduce new and enhanced solutions into the market.

[0001571996-24-000036:mdna:108]
During Fiscal 2024, non-GAAP operating expenses decreased 7%, principally due to continued disciplined cost management which resulted in a decline in employee compensation and benefits, outside services, and advertising expenses, among other items.

[0001571996-24-000036:mdna:109]
We continue to make strategic investments designed to enable growth, marketing, and R&D, while balancing our efforts to drive cost efficiencies in the business.  We also expect to continue making investments in support of our own digital transformation which aims to streamline and optimize our business processes.

[0001571996-24-000036:mdna:110]
Operating Income

[0001571996-24-000036:mdna:111]
Operating income and non-GAAP operating income decreased by 10% to $5.2 billion and 11% to $7.7 billion, respectively, during Fiscal 2024.  The decline in operating income and non-GAAP operating income was driven by a decrease in ISG operating income and, to a lesser extent, CSG operating income, which both declined primarily as a result of a decrease in net revenue that outpaced the favorable impacts of a decline in input costs and cost management measures.  The decline in ISG operating income was primarily attributable to decreases in our servers and networking offerings and, to a lesser extent, our storage offerings.  The decline in CSG operating income was driven by decreases in both commercial and consumer offerings.  The decline in operating income was partially offset by decreases in other corporate expenses and amortization of intangibles.

[0001571996-24-000036:mdna:112]
During Fiscal 2024, both operating income and non-GAAP operating income as a percentage of net revenue increased 30 basis points to 5.9% and 8.7%, respectively.  These increases were due to an increase in gross margin as a percentage of net revenue, which was principally driven by a decline in input costs.  The increase in operating income and non-GAAP operating income as a percentage of net revenue was offset by an increase in operating expense rate, principally within ISG, that was attributable to a decrease in net revenue which outpaced the impact of continued cost management measures.

[0001571996-24-000036:mdna:113]
Interest and Other, Net

[0001571996-24-000036:mdna:114]
The following table presents information regarding interest and other, net for the periods indicated:

[0001571996-24-000036:mdna:115]
|  |  |  | Fiscal Year Ended |
|  |  |  |  |  | February 2, 2024 |  | February 3, 2023 |  | January 28, 2022 |
|  |  |  |  |  | (in millions) |
| Interest and other, net: |  |  |  |  |  |  |  |  |  |
| Investment income, primarily interest |  |  |  |  | $ | 305 |  |  | $ | 100 |  |  | $ | 42 |  |
| Gain (loss) on investments, net |  |  |  |  | 47 |  |  | (206) |  |  | 569 |  |
| Interest expense |  |  |  |  | (1,501) |  |  | (1,222) |  |  | (1,542) |  |
| Foreign exchange |  |  |  |  | (199) |  |  | (265) |  |  | (221) |  |
| Gain on disposition of businesses and assets |  |  |  |  | — |  |  | — |  |  | 3,968 |  |
| Debt extinguishment gain (loss) |  |  |  |  | 68 |  |  | — |  |  | (1,572) |  |
| Legal settlement, net |  |  |  |  | — |  |  | (894) |  |  | — |  |
| Other |  |  |  |  | (44) |  |  | (59) |  |  | 20 |  |
| Total interest and other, net |  |  |  |  | $ | (1,324) |  |  | $ | (2,546) |  |  | $ | 1,264 |  |

[0001571996-24-000036:mdna:116]
The change in interest and other, net was favorable, primarily as a result of $0.9 billion of expense recognized in Fiscal 2023 in connection with an agreement to settle the Class V transaction litigation, coupled with a gain on investments and an increase in investment income during Fiscal 2024.  Favorable impacts within interest and other, net were partially offset by an increase in interest expense primarily associated with DFS securitization and structured financing programs.  See Note 12 to the Notes to the Consolidated Financial Statements for additional information about the settlement of the Class V transaction litigation.

[0001571996-24-000036:mdna:117]
Income and Other Taxes

[0001571996-24-000036:mdna:118]
The following table presents information regarding our income and other taxes for the periods indicated:

[0001571996-24-000036:mdna:119]
|  |  |  | Fiscal Year Ended |
|  |  |  |  |  | February 2, 2024 |  | February 3, 2023 |  | January 28, 2022 |
|  |  |  |  |  | (in millions, except percentages) |
| Income before income taxes |  |  |  |  | $ | 3,887 |  |  | $ | 3,225 |  |  | $ | 5,923 |  |
| Income tax expense |  |  |  |  | $ | 692 |  |  | $ | 803 |  |  | $ | 981 |  |
| Effective income tax rate |  |  |  |  | 17.8 | % |  | 24.9 | % |  | 16.6 | % |

[0001571996-24-000036:mdna:120]
For Fiscal 2024 and Fiscal 2023, our effective income tax rate was 17.8% and 24.9%, respectively.  Changes related to our effective income tax rates for Fiscal 2024 as compared to Fiscal 2023 were primarily attributable to the tax impact of foreign operations and benefits from U.S. research and development tax credits.  In addition, our effective tax rate for Fiscal 2023 included the impact of an expense recognized in connection with the agreement to settle the Class V transaction litigation described in Note 12 of the Notes to the Consolidated Financial Statements.

[0001571996-24-000036:mdna:121]
Our effective income tax rate can fluctuate depending on the geographic distribution of our worldwide earnings, as our foreign earnings are generally taxed at lower rates than in the United States.  The differences between our effective income tax rates and the U.S. federal statutory rate of 21% principally result from the geographical distribution of income, differences between the book and tax treatment of certain items, and discrete tax items.  In certain jurisdictions, our tax rate is significantly less than the applicable statutory rate as a result of tax holidays.  The majority of our foreign income subject to these tax holidays is attributable to Singapore and China.  A significant portion of these income tax benefits relates to a tax holiday that will be effective until January 31, 2029.  Most of our other tax holidays will expire in whole or in part during Fiscal 2030 and Fiscal 2031.  Many of these tax holidays and reduced tax rates may be extended when certain conditions are met or may be terminated early if certain conditions are not met or as a result of changes in tax legislation.  As of February 2, 2024, we were not aware of any matters of non-compliance or enacted tax legislative changes affecting these tax holidays.

[0001571996-24-000036:mdna:122]
Many countries have enacted or are in the process of enacting laws based on the Pillar Two proposal relating to global minimum tax issued by the Organisation for Economic Co-operation and Development (“OECD”).  While we expect our effective income tax rate and cash income tax payments could increase in future years as a result of the global minimum tax, we do not anticipate a material impact to our Fiscal 2025 consolidated results of operations.  Our assessment could be affected by legislative guidance and future enactment of additional provisions within the Pillar Two framework, particularly in countries in which we have tax holidays and incentives.  Our income tax benefit from tax holidays and incentives decreased the provision for income taxes by approximately $244 million ($0.33 per share) during Fiscal 2024.

[0001571996-24-000036:mdna:123]
For further discussion regarding tax matters, including the status of income tax audits, see Note 13 of the Notes to the Consolidated Financial Statements included in this report.

[0001571996-24-000036:mdna:124]
Net Income

[0001571996-24-000036:mdna:125]
During Fiscal 2024, net income increased 32% to $3.2 billion, driven primarily by a favorable change in interest and other, net, partially offset by a decline in operating income.

[0001571996-24-000036:mdna:126]
During Fiscal 2024, non-GAAP net income decreased 8% to $5.2 billion, driven by a decline in operating income, partially offset by a decline in income tax expense.

[0001571996-24-000036:mdna:127]
Business Unit Results

[0001571996-24-000036:mdna:128]
Our reportable segments are based on the ISG and CSG business units.  A description of our business units is provided under “Introduction.”  See Note 19 of the Notes to the Consolidated Financial Statements included in this report for a reconciliation of net revenue and operating income by reportable segment to consolidated net revenue and consolidated operating income, respectively.

[0001571996-24-000036:mdna:129]
Infrastructure Solutions Group

[0001571996-24-000036:mdna:130]
The following table presents net revenue and operating income attributable to ISG for the periods indicated:

[0001571996-24-000036:mdna:131]
|  |  |  | Fiscal Year Ended |
|  |  |  |  |  |  |  | February 2, 2024 |  | % Change |  | February 3, 2023 |  | % Change |  | January 28, 2022 |
|  |  |  |  |  |  |  | (in millions, except percentages) |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Servers and networking |  |  |  |  |  |  | $ | 17,624 |  | (14) | % |  | $ | 20,398 |  | 14 | % |  | $ | 17,901 |
| Storage |  |  |  |  |  |  | 16,261 |  | (9) | % |  | 17,958 |  | 9 | % |  | 16,465 |
| Total ISG net revenue |  |  |  |  |  |  | $ | 33,885 |  | (12) | % |  | $ | 38,356 |  | 12 | % |  | $ | 34,366 |
| Operating income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| ISG operating income |  |  |  |  |  |  | $ | 4,286 |  | (15) | % |  | $ | 5,045 |  | 35 | % |  | $ | 3,736 |
| % of segment net revenue |  |  |  |  |  |  | 12.6 | % |  |  |  | 13.2 | % |  |  |  | 10.9 | % |

[0001571996-24-000036:mdna:132]
Net Revenue — During Fiscal 2024, ISG net revenue decreased 12% driven primarily by servers and networking net revenue and, to a lesser extent, storage net revenue as global macroeconomic conditions continued to impact demand.

[0001571996-24-000036:mdna:133]
Revenue from sales of servers and networking decreased 14% during Fiscal 2024, driven by a decrease in units sold, the effect of which was partially offset by an increase in the average selling prices of our server offerings.  The average selling price of our server offerings increased as a result of the impact of attached offerings and richer configurations.

[0001571996-24-000036:mdna:134]
During Fiscal 2024, storage net revenue decreased 9%, driven by a decline in net revenue across the majority of our storage offerings.

[0001571996-24-000036:mdna:135]
From a geographical perspective, net revenue attributable to ISG decreased in the Americas, EMEA, and APJ during Fiscal 2024.

[0001571996-24-000036:mdna:136]
Operating Income — During Fiscal 2024, ISG operating income as a percentage of net revenue decreased 60 basis points to 12.6%, principally due to an increase in operating expenses as a percentage of net revenue.  Operating expenses as a percentage of net revenue increased as a result of a decline in revenue that outpaced the impact of continued cost management measures coupled with continued investment in research and development.  The impact of an increase in operating expenses as a percentage of net revenue was partially offset by an overall decline in input costs coupled with an increase in average selling price.

[0001571996-24-000036:mdna:137]
Client Solutions Group

[0001571996-24-000036:mdna:138]
The following table presents net revenue and operating income attributable to CSG for the periods indicated:

[0001571996-24-000036:mdna:139]
|  |  |  | Fiscal Year Ended |
|  |  |  |  |  |  |  | February 2, 2024 |  | % Change |  | February 3, 2023 |  | % Change |  | January 28, 2022 |
|  |  |  |  |  |  |  | (in millions, except percentages) |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Commercial |  |  |  |  |  |  | $ | 39,814 |  | (13) | % |  | $ | 45,556 |  | — | % |  | $ | 45,576 |
| Consumer |  |  |  |  |  |  | 9,102 |  | (28) | % |  | 12,657 |  | (20) | % |  | 15,888 |
| Total CSG net revenue |  |  |  |  |  |  | $ | 48,916 |  | (16) | % |  | $ | 58,213 |  | (5) | % |  | $ | 61,464 |
| Operating income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| CSG operating income |  |  |  |  |  |  | $ | 3,512 |  | (8) | % |  | $ | 3,824 |  | (12) | % |  | $ | 4,365 |
| % of segment net revenue |  |  |  |  |  |  | 7.2 | % |  |  |  | 6.6 | % |  |  |  | 7.1 | % |

[0001571996-24-000036:mdna:140]
Net Revenue — During Fiscal 2024, CSG net revenue decreased 16% driven by a decline in units sold as global macroeconomic conditions continued to impact demand.

[0001571996-24-000036:mdna:141]
Commercial net revenue decreased 13% during Fiscal 2024.  The decline was primarily due to a decrease in units sold which was partially offset by the effect of an increase in the average selling prices of our commercial offerings.  Average selling prices of our commercial offerings increased primarily as a result of richer configurations and the mix of offerings sold.

[0001571996-24-000036:mdna:142]
Consumer net revenue decreased 28% during Fiscal 2024, principally due to a decrease in units sold and, to a lesser extent, a decline in the average selling price of our consumer offerings.

[0001571996-24-000036:mdna:143]
From a geographical perspective, net revenue attributable to CSG decreased primarily in APJ and, to a lesser extent, in the Americas and EMEA during Fiscal 2024.

[0001571996-24-000036:mdna:144]
Operating Income — During Fiscal 2024, CSG operating income as a percentage of net revenue increased 60 basis points to 7.2%, primarily due to the impact of an overall decrease in input costs coupled with an increase in the average selling prices of our commercial offerings, as described above.  The impact of these factors was partially offset by an increase in operating expenses as a percentage of net revenue, which increased as a result of a decline in CSG net revenue that outpaced the impact of continued cost management measures.

[0001571996-24-000036:mdna:145]
OTHER BALANCE SHEET ITEMS

[0001571996-24-000036:mdna:146]
Accounts Receivable

[0001571996-24-000036:mdna:147]
We sell products and services directly to customers and through a variety of sales channels, including retail distribution.  Our accounts receivable, net, was $9.3 billion and $12.5 billion as of February 2, 2024 and February 3, 2023, respectively.  The reduction in accounts receivable, net was driven primarily by a decline in net revenue coupled with strong collections.  We maintain an allowance for expected credit losses to cover receivables that may be deemed uncollectible.  The allowance for expected credit losses is an estimate based on an analysis of historical loss experience, current receivables aging, and management’s assessment of current conditions and its reasonable and supportable expectation of future conditions, as well as specific identifiable customer accounts that are deemed at risk.  As of February 2, 2024 and February 3, 2023, the allowance for expected credit losses was $71 million and $78 million, respectively.  Based on our assessment, we believe that we are adequately reserved for expected credit losses.

[0001571996-24-000036:mdna:148]
Dell Financial Services and Financing Receivables

[0001571996-24-000036:mdna:149]
We offer or arrange various financing options and services for our customers globally, including through captive financing operations.  DFS originates, collects, and services customer receivables primarily related to the purchase of our product, software, and service solutions.  We further strengthen customer relationships through flexible consumption models, including utility, subscription, and as-a-Service models, which enable our customers the option to pay over time to provide them with financial and operational flexibility.  New financing originations were $8.4 billion, $9.7 billion, and $8.5 billion for Fiscal 2024, Fiscal 2023, and Fiscal 2022 respectively.

[0001571996-24-000036:mdna:150]
Our leases are generally classified as sales-type leases or operating leases.  On commencement of sales-type leases, we recognize profit up-front, and recognize amounts due from the customer under the lease contract as financing receivables.  Interest income is recognized as net product revenue over the term of the lease.  Upon origination of operating leases, we record equipment under operating leases, classified as property, plant, and equipment.  We recognize product revenue and depreciation expense, classified as cost of net revenue, over the contract term.

[0001571996-24-000036:mdna:151]
As of February 2, 2024 and February 3, 2023, our financing receivables, net were $10.5 billion and $10.9 billion, respectively.  The decline in financing receivables was driven primarily by the sale of our U.S. consumer revolving customer financing receivables portfolio.  See Note 6 of the Notes to the Consolidated Financial Statements included in this report for additional information about the sale.

[0001571996-24-000036:mdna:152]
We maintain an allowance to cover expected financing receivable credit losses and evaluate credit loss expectations based on our total portfolio.  For both Fiscal 2024 and Fiscal 2023, the principal charge-off rate for our financing receivables portfolio was 0.5% and for Fiscal 2022 was 0.6%.  The credit quality of our financing receivables has improved in recent years as the mix of high-quality commercial accounts in our portfolio has continued to increase.  We continue to monitor broader economic indicators and their potential impact on future credit loss performance.  We have an extensive process to manage our exposure to customer credit risk, including active management of credit lines and our collection activities.  We also sell selected fixed-term financing receivables without recourse to unrelated third parties on a periodic basis, primarily to manage certain concentrations of customer credit exposure.  Based on our assessment of the customer financing receivables, we believe that we are adequately reserved.

[0001571996-24-000036:mdna:153]
We retain a residual interest in equipment leased under our lease programs.  As of February 2, 2024 and February 3, 2023, the residual interest recorded as part of financing receivables was $157 million and $142 million, respectively.  The amount of the residual interest is established at the inception of the lease based upon estimates of the value of the equipment at the end of the lease term using historical studies, industry data, and future value-at-risk demand valuation methods.  On a quarterly basis, we assess the carrying amount of our recorded residual values for expected losses.  Generally, expected losses as a result of residual value risk on equipment under lease are not considered to be significant primarily because of the existence of a secondary market with respect to the equipment.  Further, the lease agreement defines applicable return conditions and remedies for non-compliance to ensure that the leased equipment will be in good operating condition upon return.  No expected losses were recorded related to residual assets during Fiscal 2024 and Fiscal 2023.

[0001571996-24-000036:mdna:154]
As of February 2, 2024 and February 3, 2023, equipment under operating leases, net was $2.2 billion.  We assess the carrying amount of the equipment under operating leases for impairment whenever events or circumstances may indicate that an impairment has occurred.  No material impairment losses were recorded related to such equipment during Fiscal 2024, Fiscal 2023, and Fiscal 2022.

[0001571996-24-000036:mdna:155]
DFS offerings are initially funded through cash on hand at the time of origination, most of which is subsequently replaced with asset-backed financing.  For DFS offerings which qualify as sales-type leases, the initial funding of financing receivables is reflected as an impact to cash flows from operations and is largely subsequently offset by cash proceeds from financing.  For DFS operating leases, the initial funding is classified as a capital expenditure and reflected as an impact to cash flows used in investing activities.

[0001571996-24-000036:mdna:156]
See Note 6 of the Notes to the Consolidated Financial Statements included in this report for additional information about our financing receivables and the associated allowances, and equipment under operating leases.

[0001571996-24-000036:mdna:157]
59

[0001571996-24-000036:mdna:158]
LIQUIDITY, CASH REQUIREMENTS, AND MARKET CONDITIONS

[0001571996-24-000036:mdna:159]
Liquidity and Capital Resources

[0001571996-24-000036:mdna:160]
We rely on operating cash flows, which are impacted by trends in the demand environment, as our primary source of liquidity for our ongoing business operations.  We monitor the efficiency of our balance sheet to ensure that we have adequate liquidity to support our business and strategic initiatives.

[0001571996-24-000036:mdna:161]
In addition to internally generated cash, we have access to other capital sources to finance our strategic initiatives and fund growth in our financing operations.  Our strategy is to deploy capital from any potential source, whether internally generated cash or debt, depending on the adequacy and availability of that source of capital and whether it can be accessed in a cost-effective manner.

[0001571996-24-000036:mdna:162]
We believe that our current cash and cash equivalents, together with cash that will be provided by future operations and borrowings expected to be available under our revolving credit facility and commercial paper program, will be sufficient over at least the next twelve months and for the foreseeable future thereafter to meet our material cash requirements, including funding of our operations, debt-related payments, capital expenditures, and other corporate needs.

[0001571996-24-000036:mdna:163]
As part of our overall capital allocation strategy, we intend to return capital to our stockholders through both share repurchase programs and dividend payments and use the remaining available cash to drive growth and maintain our investment grade credit rating.

[0001571996-24-000036:mdna:164]
The following table presents our cash and cash equivalents as well as our available borrowings as of the dates indicated:

[0001571996-24-000036:mdna:165]
|  | February 2, 2024 |  | February 3, 2023 |
|  | (in millions) |
| Cash and cash equivalents, and available borrowings: |  |  |  |
| Cash and cash equivalents | $ | 7,366 |  |  | $ | 8,607 |  |
| Remaining available borrowings under 2021 Revolving Credit Facility | 5,999 |  |  | 5,999 |  |
| Total cash and cash equivalents, and available borrowings | $ | 13,365 |  |  | $ | 14,606 |  |

[0001571996-24-000036:mdna:166]
During Fiscal 2024, cash and cash equivalents decreased by $1.2 billion primarily due to the return of capital to our stockholders, capital expenditures, and the repayment of Senior Notes, the effect of which was partially offset by cash flows from operations.

[0001571996-24-000036:mdna:167]
As of February 2, 2024, our 2021 Revolving Credit Facility had a maximum capacity of $6.0 billion.  Available borrowings under this facility are reduced by draws on the facility and outstanding letters of credit.  As of February 2, 2024, there were no borrowings outstanding under the facility and remaining available borrowings totaled approximately $6.0 billion.  The 2021 Revolving Credit Facility also acts as a backstop to provide liquidity support for our commercial paper program.

[0001571996-24-000036:mdna:168]
We maintain a commercial paper program under which we may issue unsecured notes in a maximum aggregate face amount of $5.0 billion outstanding at any time, with maturities up to 397 days from the date of issue.  As of February 2, 2024, we had no outstanding borrowings under the program.

[0001571996-24-000036:mdna:169]
We may regularly use our available borrowings from the 2021 Revolving Credit Facility and issuances under the commercial paper program on a short-term basis for general corporate purposes.  See the following discussion for additional information about our debt.

[0001571996-24-000036:mdna:170]
Debt

[0001571996-24-000036:mdna:171]
The following table presents our outstanding debt as of the dates indicated:

[0001571996-24-000036:mdna:172]
|  | February 2, 2024 |  | Change |  | February 3, 2023 |
|  | (in millions) |
| Core debt |  |  |  |  |  |
| Senior Notes | $ | 15,607 |  |  | $ | (2,693) |  |  | $ | 18,300 |  |
| Legacy Notes and Debentures | 952 |  |  | — |  |  | 952 |  |
| DFS allocated debt | (1,640) |  |  | (444) |  |  | (1,196) |  |
| Total core debt | 14,919 |  |  | (3,137) |  |  | 18,056 |  |
| DFS related debt |  |  |  |  |  |
| DFS debt | 9,492 |  |  | (798) |  |  | 10,290 |  |
| DFS allocated debt | 1,640 |  |  | 444 |  |  | 1,196 |  |
| Total DFS related debt | 11,132 |  |  | (354) |  |  | 11,486 |  |
| Other | 171 |  |  | (154) |  |  | 325 |  |
| Total debt, principal amount | 26,222 |  |  | (3,645) |  |  | 29,867 |  |
| Carrying value adjustments | (228) |  |  | 51 |  |  | (279) |  |
| Total debt, carrying value | $ | 25,994 |  |  | $ | (3,594) |  |  | $ | 29,588 |  |

[0001571996-24-000036:mdna:173]
The outstanding principal amount of our debt decreased $3.6 billion to $26.2 billion as of February 2, 2024, driven primarily by the prepayment of $2.7 billion principal amount of Senior Notes and a reduction in DFS debt which was principally attributable to the prepayment and termination of our U.S. securitization facility for consumer revolving loans.

[0001571996-24-000036:mdna:174]
Subsequent to the close of Fiscal 2024, we issued $1.0 billion aggregate principal amount of 5.40% Senior Notes due 2034.  We intend to use the net proceeds of the issuance to prepay a portion of our outstanding 6.02% Senior Notes due 2026.

[0001571996-24-000036:mdna:175]
We define core debt as the total principal amount of our debt, less DFS related debt and other debt.  Our core debt was $14.9 billion and $18.1 billion as of February 2, 2024 and February 3, 2023, respectively.  See Note 8 of the Notes to the Consolidated Financial Statements included in this report for additional information about our debt.

[0001571996-24-000036:mdna:176]
DFS related debt primarily represents debt from our securitization and structured financing programs.  Our risk of loss under these programs is limited to transferred lease and loan payments and associated equipment, as the credit holders have no recourse to Dell Technologies.

[0001571996-24-000036:mdna:177]
To fund expansion of the DFS business, we balance the use of the securitization and structured financing programs with other sources of liquidity.  We approximate the amount of our core debt used to fund the DFS business by applying a 7:1 debt-to-equity ratio to the sum of our financing receivables balance and equipment under operating leases, net.  The debt-to-equity ratio is based on the underlying credit quality of the assets.  See Note 6 of the Notes to the Consolidated Financial Statements included in this report for additional information about our DFS debt.

[0001571996-24-000036:mdna:178]
We believe we will continue to be able to make our debt principal and interest payments, including payment of short-term maturities, from existing and expected sources of cash, primarily from operating cash flows.  Cash used for debt principal and interest payments may include short-term borrowings under our commercial paper program, our revolving credit facility, or other borrowings.  Under our variable-rate debt, we could experience variations in our future interest expense from potential fluctuations in applicable reference rates, or from possible fluctuations in the level of DFS debt required to meet future demand for customer financing.

[0001571996-24-000036:mdna:179]
At our sole discretion, we may purchase, redeem, prepay, refinance, or otherwise retire any amount of our outstanding indebtedness under the terms of such indebtedness at any time and from time to time, in open market or negotiated transactions with the holders of such indebtedness or otherwise, as we consider appropriate in light of market conditions and other relevant factors.

[0001571996-24-000036:mdna:180]
Cash Flows

[0001571996-24-000036:mdna:181]
The following table presents a summary of our Consolidated Statements of Cash Flows for the periods indicated:

[0001571996-24-000036:mdna:182]
|  | Fiscal Year Ended |
|  | February 2, 2024 |  | February 3, 2023 |  | January 28, 2022 |
|  | (in millions) |
| Net change in cash from: |  |  |  |  |  |
| Operating activities | $ | 8,676 |  |  | $ | 3,565 |  |  | $ | 10,307 |  |
| Investing activities | (2,783) |  |  | (3,024) |  |  | 1,306 |  |
| Financing activities | (7,094) |  |  | (1,625) |  |  | (16,609) |  |
| Effect of exchange rate changes on cash, cash equivalents, and restricted cash | (186) |  |  | (104) |  |  | (106) |  |
| Change in cash, cash equivalents, and restricted cash | $ | (1,387) |  |  | $ | (1,188) |  |  | $ | (5,102) |  |

[0001571996-24-000036:mdna:183]
Operating Activities — Cash provided by operating activities was $8.7 billion during Fiscal 2024, and was primarily driven by profitability coupled with strong inventory management and cash collections performance.  Cash provided by operating activities also reflected the impact of the $0.9 billion net payment to settle the Class V transaction litigation and $0.4 billion in proceeds from the sale of our U.S. consumer revolving customer receivables portfolio.  During Fiscal 2023, cash provided by operating activities was $3.6 billion, which primarily reflected profitability that was partially offset by the impact of working capital dynamics.

[0001571996-24-000036:mdna:184]
Investing Activities — Investing activities primarily consist of cash used to fund capital expenditures for property, plant, and equipment inclusive of equipment under DFS operating leases and equipment used to support our as-a-Service offerings, which we refer to collectively as assets in a customer contract.  Additional activities include capitalized software development costs, acquisitions and divestitures, and the maturities, sales, and purchases of investments.  Cash used in investing activities was $2.8 billion and $3.0 billion during Fiscal 2024 and Fiscal 2023, respectively, and was primarily applied to capital expenditures.

[0001571996-24-000036:mdna:185]
Financing Activities — Financing activities primarily consist of the proceeds and repayments of debt and return of capital to our stockholders.  Cash used in financing activities was $7.1 billion during Fiscal 2024 and primarily consisted of principal repayments of our Senior Notes, repurchases of common stock, inclusive of payments to settle employee tax withholdings on stock-based compensation, and the payment of quarterly dividends.  During Fiscal 2023, cash used in financing activities was $1.6 billion and primarily consisted of repurchases of common stock, inclusive of payments to settle employee tax withholdings on stock-based compensation, and the payment of quarterly dividends.

[0001571996-24-000036:mdna:186]
DFS Cash Flow Impacts — DFS offerings are initially funded through cash on hand at the time of origination, most of which is subsequently replaced with asset-backed financing.  For DFS offerings that qualify as sales-type leases, the initial funding of financing receivables is reflected as an impact to cash flows from operations and is largely subsequently offset by cash proceeds from financing.  For operating leases, the initial funding is classified as a capital expenditure and reflected as cash flows used in investing activities.  DFS new financing originations were $8.4 billion, $9.7 billion, and $8.5 billion during Fiscal 2024, Fiscal 2023, and Fiscal 2022 respectively.  As of February 2, 2024, the Company had $10.5 billion of total net financing receivables and $2.2 billion of equipment under operating leases, net.

[0001571996-24-000036:mdna:187]
Supply Chain Finance Program — We maintain a Supply Chain Finance Program (the "SCF Program”) that enables eligible suppliers to sell receivables due from us to a third-party financial institution at the suppliers’ sole discretion.  The SCF Program does not impact our liquidity, as payments by us to participating suppliers are remitted to the financial institution on the original invoice due date.  Further, we negotiate payment terms with our suppliers regardless of their decision to participate in the SCF Program.  Payments made under the SCF Program are included in cash flows from operating activities on the Consolidated Statements of Cash Flows.  See Note 21 of the Notes to the Consolidated Financial Statements included in this report for more information regarding the SCF Program.

[0001571996-24-000036:mdna:188]
Material Capital Commitments and Cash Requirements

[0001571996-24-000036:mdna:189]
The Company’s material capital commitments include the following:

[0001571996-24-000036:mdna:190]
Capital Expenditures — We spent $2.8 billion and $3.0 billion during Fiscal 2024 and Fiscal 2023, respectively, on property, plant, and equipment and capitalized software development costs.  Of total expenditures incurred, funding of assets in a customer contract totaled $1.2 billion and $1.5 billion during Fiscal 2024 and Fiscal 2023, respectively.  Product demand, product mix, the use of contract manufacturers, and ongoing investments in operating and information technology infrastructure influence the level and prioritization of our capital expenditures.

[0001571996-24-000036:mdna:191]
Repurchases of Common Stock — Effective as of September 23, 2021, our Board of Directors approved a stock repurchase program with no fixed expiration date under which we are authorized to repurchase up to $5.0 billion of shares of our Class C Common Stock.  Effective as of October 5, 2023, the Company’s Board of Directors approved the repurchase of an additional $5.0 billion of shares of the Class C Common Stock with no fixed expiration date.  Following the additional approval, the Company had approximately $5.7 billion in cumulative authorized amount remaining under the stock repurchase program.

[0001571996-24-000036:mdna:192]
During Fiscal 2024, the Company repurchased approximately 34 million shares of Class C Common Stock for a total purchase price of approximately $2.1 billion.  During Fiscal 2023, the Company repurchased approximately 62 million shares of Class C Common Stock for a total purchase price of approximately $2.8 billion.

[0001571996-24-000036:mdna:193]
Dividend Payments — During Fiscal 2024 and Fiscal 2023, the Company paid $1.1 billion and $1.0 billion, respectively, in dividends and dividend equivalents at a rate of $0.37 per share per fiscal quarter and $0.33 per share per fiscal quarter, respectively.

[0001571996-24-000036:mdna:194]
On February 29, 2024, subsequent to the close of Fiscal 2024, we announced that the Board of Directors approved a 20% increase in the dividend rate to $0.445 per share per fiscal quarter beginning in the first quarter of Fiscal 2025.

[0001571996-24-000036:mdna:195]
Additionally, the Company’s material cash requirements include the following contractual obligations:

[0001571996-24-000036:mdna:196]
Debt — Our expected principal cash payments on borrowings are exclusive of discounts and premiums.  As of February 2, 2024, the Company had outstanding debt for an aggregate principal amount of $26.2 billion, with $7.0 billion payable within 12 months.  Included within the aggregate principal amount was $16.7 billion of outstanding long-term notes with varying maturities, with $1.1 billion payable within 12 months, and $9.5 billion of DFS debt, with $5.9 billion payable within 12 months.

[0001571996-24-000036:mdna:197]
As of February 2, 2024, future interest payments associated with outstanding debt were $7.4 billion, with $1.2 billion payable within 12 months.  Included within total future interest payments is $6.9 billion of payments related to outstanding long-term notes, with $0.9 billion payable within 12 months, and $0.5 billion of payments related to our DFS debt, with $0.3 billion payable within 12 months.

[0001571996-24-000036:mdna:198]
Purchase Obligations — Purchase obligations are defined as contractual obligations to purchase goods or services that are enforceable and legally binding on us.  These obligations specify all significant terms, including fixed or minimum quantities to be purchased; fixed, minimum, or variable price provisions; and the approximate timing of the transaction.  Purchase obligations do not include contracts that may be canceled without penalty.

[0001571996-24-000036:mdna:199]
We utilize several suppliers to manufacture sub-assemblies for our products.  Our efficient supply chain management allows us to enter into flexible and mutually beneficial purchase arrangements with our suppliers in order to minimize inventory risk.  Consistent with industry practice, we acquire raw materials or other goods and services, including product components, by issuing to suppliers authorizations to purchase based on our projected demand and manufacturing needs.  These purchase orders are typically fulfilled within 30 days and are entered into during the ordinary course of business in order to establish best pricing and continuity of supply for our production.  Purchase orders are not included in purchase obligations, as they typically represent our authorization to purchase rather than binding purchase obligations.

[0001571996-24-000036:mdna:200]
As of February 2, 2024, the Company had purchase obligations of $5.0 billion, with $4.4 billion payable within 12 months.

[0001571996-24-000036:mdna:201]
Operating Leases — We lease property and equipment, manufacturing facilities, and office space under non-cancelable leases.  Certain of these leases obligate us to pay taxes, maintenance, and repair costs.  As of February 2, 2024, the Company had operating lease obligations of $0.9 billion, with $0.3 billion payable within 12 months.  See Note 7 of the Notes to the Consolidated Financial Statements included in this report for additional information about our leasing transactions in which we are the lessee.

[0001571996-24-000036:mdna:202]
Tax Obligations — Tax obligations represent a one-time mandatory deemed repatriation tax on undistributed earnings of foreign subsidiaries.  As of February 2, 2024, the balance of tax obligations was $108 million, with $48 million payable within 12 months.  Excluded from the amounts above are $1.3 billion in additional liabilities associated with uncertain tax positions as of February 2, 2024.  We are unable to reliably estimate the expected payment dates for any liabilities for uncertain tax positions.  See Note 13 of the Notes to the Consolidated Financial Statements included in this report for more information regarding these tax matters.

[0001571996-24-000036:mdna:203]
Market Conditions

[0001571996-24-000036:mdna:204]
We regularly monitor economic conditions and associated impacts on the financial markets and our business.  We consistently evaluate the financial health of our supplier base, carefully manage customer credit, diversify counterparty risk, and monitor the concentration risk of our cash and cash equivalents balances globally.  We routinely monitor our financial exposure to borrowers and counterparties.

[0001571996-24-000036:mdna:205]
We monitor credit risk associated with our financial counterparties using various market credit risk indicators such as credit ratings issued by nationally recognized credit rating agencies and changes in market credit default swap levels.  We perform periodic evaluations of our positions with these counterparties and may limit exposure to any one counterparty in accordance with our policies.  We monitor and manage these activities depending on current and expected market developments.

[0001571996-24-000036:mdna:206]
We use derivative instruments to hedge certain foreign currency exposures.  We use forward contracts and purchased options designated as cash flow hedges to protect against the foreign currency exchange rate risks inherent in our forecasted transactions denominated in currencies other than the U.S. dollar.  In addition, we primarily use forward contracts and may use purchased options to hedge monetary assets and liabilities denominated in a foreign currency.  See Note 9 of the Notes to the Consolidated Financial Statements included in this report for additional information about our use of derivative instruments.

[0001571996-24-000036:mdna:207]
We are exposed to interest rate risk related to our variable-rate debt portfolio.  In the normal course of business we follow established policies and procedures to manage this risk, including monitoring of our asset and liability mix and the use of derivative instruments.  As a result, we do not anticipate any material losses from interest rate risk.

[0001571996-24-000036:mdna:208]
Summarized Guarantor Financial Information

[0001571996-24-000036:mdna:209]
Dell International L.L.C. and EMC Corporation (the “Issuers”), both of which are wholly-owned subsidiaries of Dell Technologies Inc., completed private offerings of multiple series of senior secured notes issued on June 1, 2016, March 20, 2019, and April 9, 2020 (the “Senior Secured Notes”).  The Senior Secured Notes became unsecured obligations following the release of the collateral securing such Senior Secured Notes during Fiscal 2022.  On December 13, 2021, the Issuers completed a private offering of senior unsecured notes (together with the Senior Secured Notes, the “Unregistered Senior Notes”).

[0001571996-24-000036:mdna:210]
In June 2021 and September 2023, the Issuers completed exchange offers in which they issued $18.4 billion and $2.1 billion, respectively, in aggregate principal amount of registered senior notes under the Securities Act of 1933 (the “Exchange Notes”) in exchange for the same principal amount and substantially identical terms of the Senior Notes.

[0001571996-24-000036:mdna:211]
On January 24, 2023, the Issuers completed a public offering of unsecured senior notes (together with the Exchange Notes, the “Senior Notes”) in the aggregate principal amount of $2.0 billion.  The unsecured senior notes were sold pursuant to a shelf registration statement.

[0001571996-24-000036:mdna:212]
Guarantees — The Senior Notes are guaranteed on a joint and several unsecured basis by Dell Technologies Inc. and its wholly-owned subsidiaries, Denali Intermediate, Inc. and Dell Inc. (collectively, the “Guarantors”).

[0001571996-24-000036:mdna:213]
Basis of Preparation of the Summarized Financial Information — The tables below are summarized financial information provided in conformity with Rule 13-01 of the SEC’s Regulation S-X.  The summarized financial information of the Issuers and Guarantors (collectively, the “Obligor Group”) is presented on a combined basis, excluding intercompany balances and transactions between entities in the Obligor Group.  The Obligor Group’s investment balances in Non-Obligor Subsidiaries have been excluded.  The Obligor Group’s amounts due from, amounts due to, and transactions with Non-Obligor Subsidiaries have been presented separately.  The Obligor Group’s transactions with VMware LLC (formerly “VMware, Inc.” and individually and together with its subsidiaries, “VMware”) and its consolidated subsidiaries (the “Related Party”) have been presented separately through November 21, 2023, the date immediately prior to Broadcom, Inc.’s acquisition of VMware, effective upon which the related party relationship terminated.

[0001571996-24-000036:mdna:214]
The following table presents summarized results of operations information for the Obligor Group for the period indicated:

[0001571996-24-000036:mdna:215]
|  | Fiscal Year Ended |
|  | February 2, 2024 |
|  | (in millions) |
| Net revenue (a) | $ | 9,198 |  |
| Gross margin (b) | 4,029 |  |
| Operating income | 983 |  |
| Interest and other, net (c) | (3,739) |  |
| Loss before income taxes | $ | (2,756) |  |
| Net loss attributable to Obligor Group | $ | (2,055) |  |

[0001571996-24-000036:mdna:216]
____________________

[0001571996-24-000036:mdna:217]
(a)    Includes net revenue from products and services sold to Non-Obligor Subsidiaries of $850 million and $121 million, respectively.

[0001571996-24-000036:mdna:218]
(b)    Includes cost of net revenue from the resale of solutions purchased from Non-Obligor Subsidiaries for the fiscal year and from the Related Party through November 21, 2023, of $948 million and $298 million, respectively.  Includes cost of net revenue from shared services provided by Non-Obligor Subsidiaries of $570 million.

[0001571996-24-000036:mdna:219]
(c)    Includes interest expense on intercompany loan payables of $2,172 million and other expenses from services provided by Non-Obligor Subsidiaries of $87 million.

[0001571996-24-000036:mdna:220]
The following table presents summarized balance sheet information for the Obligor Group as of the dates indicated:

[0001571996-24-000036:mdna:221]
|  | February 2, 2024 |  | February 3, 2023 |
|  | (in millions) |
| ASSETS |
| Current assets | $ | 2,631 |  |  | $ | 2,972 |  |
| Intercompany receivables | 281 |  |  | 595 |  |
| Due from related party, net | — |  |  | 312 |  |
| Short-term intercompany loan receivables | 92 |  |  | 227 |  |
| Total current assets | 3,004 |  |  | 4,106 |  |
| Due from related party, net | — |  |  | 440 |  |
| Goodwill and intangible assets | 14,447 |  |  | 14,818 |  |
| Other non-current assets | 3,437 |  |  | 3,009 |  |
| Total assets | $ | 20,888 |  |  | $ | 22,373 |  |
| LIABILITIES |
| Current liabilities | $ | 5,255 |  |  | $ | 6,611 |  |
| Due to related party | — |  |  | 110 |  |
| Total current liabilities | 5,255 |  |  | 6,721 |  |
| Long-term debt | 15,353 |  |  | 17,996 |  |
| Intercompany loan payables | 41,617 |  |  | 38,896 |  |
| Other non-current liabilities | 3,473 |  |  | 3,891 |  |
| Total liabilities | $ | 65,698 |  |  | $ | 67,504 |  |

[0001571996-24-000036:mdna:222]
66

[0001571996-24-000036:mdna:223]
Critical Accounting Estimates

[0001571996-24-000036:mdna:224]
We prepare our financial statements in conformity with GAAP, which requires certain estimates, assumptions, and judgments to be made that may affect our Consolidated Statements of Financial Position and Consolidated Statements of Income.  Accounting policies that have a significant impact on our Consolidated Financial Statements are described in Note 2 of the Notes to the Consolidated Financial Statements included in this report.  The accounting estimates and assumptions discussed in this section are those that we consider to be the most critical.  We consider an accounting policy to be critical if the nature of the estimate or assumption is subject to a material level of judgment and if changes in those estimates or assumptions are reasonably likely to materially impact our Consolidated Financial Statements.  We have discussed the development, selection, and disclosure of our critical accounting policies with the Audit Committee of our Board of Directors.

[0001571996-24-000036:mdna:225]
Revenue Recognition — We sell a wide portfolio of products and services offerings to our customers.  Our agreements have varying terms and conditions depending on the goods and services being sold, the rights and obligations conveyed, and the legal jurisdiction of the arrangement.  While most of our agreements have standard terms and conditions, more complex agreements may contain nonstandard terms and conditions.  There are significant judgments in interpreting agreements to determine the appropriate accounting for nonstandard terms and conditions.

[0001571996-24-000036:mdna:226]
Our contracts with customers often include multiple performance obligations for various distinct goods and services such as hardware, software licenses, support and maintenance agreements, and other service offerings and solutions.  We use significant judgment to assess whether these promises are distinct performance obligations that should be accounted for separately.  In certain hardware solutions, the hardware is highly interdependent on, and interrelated with, the embedded software.  In these offerings, the hardware and software licenses are accounted for as a single performance obligation.

[0001571996-24-000036:mdna:227]
The transaction price reflects the amount of consideration to which we expect to be entitled in exchange for transferring goods or services to the customer.  If the consideration promised in a contract includes a variable amount, we estimate the amount to which we expect to be entitled using either the expected value or most likely amount method.  Estimates are updated each reporting period as the variability is resolved or if additional information becomes available.  Generally, volume discounts, rebates, and sales returns reduce the transaction price.  When we determine the transaction price, we only include amounts that are not subject to significant future reversal.

[0001571996-24-000036:mdna:228]
When a contract includes multiple performance obligations, the transaction price is allocated to each performance obligation in proportion to the standalone selling price (“SSP”) of each performance obligation.

[0001571996-24-000036:mdna:229]
Judgment is required when determining the SSP of our performance obligations.  If the observable price is available, we utilize that price for the SSP.  If the observable price is not available, the SSP must be estimated.  We estimate SSP by considering multiple factors, including, but not limited to, pricing practices, internal costs, and profit objectives as well as overall market conditions, which include geographic or regional specific factors, competitive positioning, and competitor actions.  Our SSP estimates rely, in part, on company pricing trends.  Market conditions could impact the selling price in the current period which may not be reflective of trends, and could lead to revenue timing, classification, and segment differences when compared to similar contracts in other periods.  SSP for our performance obligations is periodically reassessed.

[0001571996-24-000036:mdna:230]
For transactions that involve a third party, the Company evaluates whether it is acting as the principal or the agent in the transaction.  This determination requires significant judgment and impacts the amount and timing of revenue recognized.  If the Company determines that it controls a good or service before it is transferred to the customer, the Company is acting as the principal and recognizes revenue at the gross amount of consideration it is entitled to from the customer.  Indicators that the Company controls a good or service before transferring to a customer include, but are not limited to, the Company being the primary obligor to the customer, establishing its own pricing, and having inventory and credit risks.

[0001571996-24-000036:mdna:231]
Goodwill and Indefinite-Lived Intangible Assets Impairment Assessments — Goodwill and indefinite-lived intangible assets are tested for impairment annually during the third fiscal quarter and whenever events or circumstances may indicate that an impairment has occurred.

[0001571996-24-000036:mdna:232]
To determine whether goodwill is impaired, we first assess certain qualitative factors.  Qualitative factors that may be assessed include, but are not limited to, macroeconomic conditions, industry and market considerations, cost factors, overall financial performance, or other relevant company-specific events.  Based on this assessment, if it is determined to be more likely than not that the fair value of a goodwill reporting unit is less than its carrying amount, we perform a quantitative analysis of the goodwill impairment test.  Alternatively, we may bypass the qualitative assessment and perform a quantitative impairment test.

[0001571996-24-000036:mdna:233]
67

[0001571996-24-000036:mdna:234]
Significant judgment is exercised in the identification of goodwill reporting units, assignment of assets and liabilities to goodwill reporting units, assignment of goodwill to reporting units, and determination of the fair value of each goodwill reporting unit.  The fair value of each of our goodwill reporting units is generally estimated using a combination of public company multiples and discounted cash flow methodologies, which is then compared to the carrying value of each goodwill reporting unit.  The discounted cash flow and public company multiples methodologies require significant judgment, including estimation of future revenues, gross margins, and operating expenses, which are dependent on internal forecasts, current and anticipated economic conditions and trends, selection of market multiples through assessment of the reporting unit’s performance relative to peer competitors, the estimation of the long-term revenue growth rate and discount rate of our business, and the determination of our weighted average cost of capital.  Changes in these estimates and assumptions could materially affect the fair value of the goodwill reporting unit, potentially resulting in a non-cash impairment charge.

[0001571996-24-000036:mdna:235]
The fair value of the indefinite-lived intangible assets is generally estimated using discounted cash flow methodologies.  The discounted cash flow methodologies require significant judgment, including estimation of future revenue, the estimation of the long-term revenue growth rate of our business, and the determination of the weighted average cost of capital and royalty rates.  Changes in these estimates and assumptions could materially affect the fair value of the indefinite-lived intangible assets, potentially resulting in a non-cash impairment charge.

[0001571996-24-000036:mdna:236]
For our annual impairment test during the third fiscal quarter of Fiscal 2024, during which the Company elected to quantitatively test the Infrastructure Solutions Group and Client Solutions Group reporting units, we determined that the fair value of each of these reporting units substantially exceeded its carrying amount.  For more information about our goodwill and intangible assets, see Note 10 of the Notes to the Consolidated Financial Statements included in this report.

[0001571996-24-000036:mdna:237]
Income Taxes — We are subject to income tax in the United States and numerous foreign jurisdictions.  Significant judgments are required in determining the consolidated provision for income taxes.  We calculate a provision for income taxes using the asset and liability method, under which deferred tax assets and liabilities are recognized by identifying the temporary differences arising from the different treatment of items for tax and accounting purposes.  We account for the tax impact of including Global Intangible Low-Taxed Income (GILTI) in U.S. taxable income as a period cost.  We provide related valuation allowances for deferred tax assets, where appropriate.  Significant judgment is required in determining any valuation allowance against deferred tax assets.  In assessing the need for a valuation allowance, we consider all available evidence for each jurisdiction, including past operating results, estimates of future taxable income, and the feasibility of ongoing tax planning strategies.  In the event we determine that all or part of the net deferred tax assets are not realizable in the future, we will make an adjustment to the valuation allowance that would be charged to earnings in the period such determination is made.

[0001571996-24-000036:mdna:238]
Significant judgment is also required in evaluating our uncertain tax positions.  Although we believe our tax return positions are sustainable, we recognize tax benefits from uncertain tax positions in the financial statements only when it is more likely than not that the positions will be sustained upon examination, including resolution of any related appeals or litigation processes, based on the technical merits and a consideration of the relevant taxing authority’s administrative practices and precedents.  To the extent that the final tax outcome of these matters is different from the amounts recorded, such differences will impact the provision for income taxes in the period in which such determination is made.  The provision for income taxes includes the impact of reserve provisions and changes to reserves that are considered appropriate, as well as the related net interest and penalties.  We believe we have provided adequate reserves for all uncertain tax positions.

[0001571996-24-000036:mdna:239]
Legal and Other Contingencies — The outcomes of legal proceedings and claims brought against us are subject to significant uncertainty.  An estimated loss from a loss contingency such as a legal proceeding or claim is accrued by a charge to income if it is probable that an asset has been impaired or a liability has been incurred and the amount of the loss can be reasonably estimated.  In determining whether a loss should be accrued, we evaluate, among other factors, the degree of probability of an unfavorable outcome and the ability to make a reasonable estimate of the amount of loss.  Significant judgment is required in determining whether a loss should be accrued, and changes in these factors could materially impact our Consolidated Financial Statements.

[0001571996-24-000036:mdna:240]
68

[0001571996-24-000036:mdna:241]
Inventories — We state our inventory at the lower of cost or net realizable value.  We record a write-down for inventories of components and products, including third-party products held for resale, which have become obsolete or are in excess of anticipated demand or net realizable value.  We perform a detailed review of inventory each fiscal quarter that considers multiple factors, including demand forecasts, product life cycle status, product development plans, current sales levels, product pricing, and component cost trends.  The industries in which we compete are subject to demand changes.  If future demand or market conditions for our products are less favorable than forecasted, or if unforeseen technological changes negatively impact the utility of component inventory, we may be required to record additional write-downs, which would adversely affect our gross margin.

[0001571996-24-000036:mdna:242]
Recently Issued Accounting Pronouncements

[0001571996-24-000036:mdna:243]
See Note 2 of the Notes to the Consolidated Financial Statements included in this report for a summary of recently issued accounting pronouncements that are applicable to our Consolidated Financial Statements.

[0001571996-24-000036:mdna:244]
69
