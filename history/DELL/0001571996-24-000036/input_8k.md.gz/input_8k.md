# DELL 8-K — 0001571996-24-000008 filed 2024-02-29

## item codes, every 8-K on or before 2024-03-25

- 2024-03-18 0001193125-24-070193 — 1.01, 2.03, 9.01
- 2024-03-07 0001571996-24-000012 — 3.02
- 2024-03-06 0001193125-24-059631 — 8.01, 9.01
- 2024-02-29 0001571996-24-000008 — 2.02, 9.01
- 2024-01-30 0001571996-24-000004 — 1.02
- 2024-01-18 0001571996-24-000002 — 3.02
- 2023-12-18 0001193125-23-297664 — 8.01, 9.01
- 2023-12-05 0001571996-23-000042 — 3.02
- 2023-12-04 0001193125-23-288428 — 8.01, 9.01
- 2023-11-30 0001571996-23-000039 — 2.02, 9.01
- 2023-10-05 0001193125-23-251131 — 7.01, 8.01, 9.01
- 2023-10-02 0001571996-23-000036 — 5.02 — amendment of 0001571996-23-000034
- 2023-09-26 0001571996-23-000034 — 5.02
- 2023-08-31 0001571996-23-000029 — 2.02, 9.01
- 2023-08-09 0001571996-23-000026 — 5.02 — amendment of 0001571996-23-000002
- 2023-07-28 0001571996-23-000024 — 5.02
- 2023-07-13 0001193125-23-186639 — 3.02
- 2023-06-30 0001193125-23-180570 — 8.01, 9.01
- 2023-06-22 0001571996-23-000021 — 5.02, 5.07, 9.01
- 2023-06-15 0001193125-23-167472 — 8.01, 9.01
- 2023-06-01 0001571996-23-000014 — 2.02, 9.01
- 2023-03-02 0001571996-23-000002 — 2.02, 5.02, 9.01
- 2023-02-06 0001193125-23-024781 — 7.01, 9.01
- 2023-01-24 0001193125-23-014260 — 1.01, 2.03, 9.01
- 2023-01-11 0001193125-23-006528 — 8.01, 9.01
- 2022-11-21 0001571996-22-000041 — 2.02, 9.01
- 2022-11-16 0001571996-22-000038 — 8.01
- 2022-08-25 0001571996-22-000028 — 2.02, 9.01
- 2022-07-18 0001193125-22-196334 — 2.03, 8.01
- 2022-06-29 0001571996-22-000025 — 3.03, 5.03, 5.07, 8.01, 9.01
- 2022-05-26 0001571996-22-000013 — 2.02, 9.01
- 2022-02-24 0001571996-22-000004 — 2.02, 8.01, 9.01
- 2021-12-20 0001193125-21-362482 — 8.01, 9.01
- 2021-12-15 0001193125-21-357927 — 1.01, 2.03, 9.01
- 2021-12-07 0001193125-21-349218 — 8.01, 9.01
- 2021-11-23 0001571996-21-000060 — 2.02, 9.01
- 2021-11-05 0001571996-21-000057 — 1.02, 2.01, 7.01, 8.01, 9.01 — amendment, the index does not say of what
- 2021-11-01 0001571996-21-000052 — 8.01, 9.01
- 2021-11-01 0001193125-21-315488 — 1.01, 1.02, 2.01, 8.01, 9.01
- 2021-10-21 0001193125-21-304052 — 8.01, 9.01
- 2021-10-19 0001571996-21-000050 — 8.01, 9.01
- 2021-10-07 0001193125-21-294210 — 8.01, 9.01
- 2021-09-30 0001571996-21-000047 — 5.02
- 2021-09-27 0001571996-21-000045 — 8.01
- 2021-09-23 0001193125-21-280190 — 7.01, 8.01, 9.01
- 2021-09-20 0001193125-21-276810 — 7.01, 9.01
- 2021-08-26 0001571996-21-000037 — 2.02, 9.01
- 2021-07-01 0001571996-21-000034 — 3.02
- 2021-06-24 0001571996-21-000031 — 5.07
- 2021-06-24 0001193125-21-197644 — 7.01, 9.01
- 2021-06-16 0001571996-21-000029 — 5.02
- 2021-05-27 0001571996-21-000019 — 2.02, 9.01
- 2021-05-03 0001571996-21-000010 — 8.01, 9.01
- 2021-04-14 0001193125-21-116271 — 1.01, 7.01, 9.01
- 2021-02-25 0001571996-21-000003 — 2.02, 9.01
- 2021-02-18 0001193125-21-047844 — 1.01, 2.03, 9.01
- 2020-11-24 0001571996-20-000048 — 2.02, 9.01
- 2020-08-27 0001571996-20-000041 — 2.02, 9.01
- 2020-07-02 0001571996-20-000037 — 5.07
- 2020-05-28 0001571996-20-000028 — 2.02, 9.01
- 2020-04-09 0001193125-20-102602 — 1.01, 2.03, 9.01
- 2020-04-08 0001571996-20-000021 — 5.02
- 2020-04-03 0001571996-20-000019 — 8.01, 9.01
- 2020-03-26 0001571996-20-000015 — 7.01
- 2020-02-27 0001571996-20-000009 — 2.02, 8.01, 9.01
- 2020-02-18 0001571996-20-000005 — 8.01, 9.01
- 2020-01-09 0001571996-20-000002 — 3.02
- 2020-01-06 0001193125-20-002200 — 3.02
- 2019-12-13 0001193125-19-313947 — 3.02
- 2019-12-10 0001571996-19-000052 — 5.02
- 2019-12-02 0001571996-19-000044 — 5.02, 7.01, 9.01
- 2019-11-26 0001571996-19-000042 — 2.02, 9.01
- 2019-09-23 0001193125-19-252192 — 1.01, 2.03, 9.01
- 2019-08-29 0001571996-19-000036 — 2.02, 9.01
- 2019-08-22 0001193125-19-226939 — 7.01, 8.01, 9.01
- 2019-07-11 0001571996-19-000032 — 5.02, 5.07, 9.01
- 2019-07-03 0001571996-19-000030 — 3.02
- 2019-06-27 0001571996-19-000028 — 3.02
- 2019-05-30 0001571996-19-000021 — 2.02, 9.01
- 2019-04-02 0001571996-19-000010 — 5.02
- 2019-03-21 0001193125-19-082281 — 1.01, 1.02, 2.03, 9.01
- 2019-03-19 0001571996-19-000005 — 5.02, 9.01
- 2019-03-14 0001193125-19-074935 — 1.01, 2.03, 9.01
- 2019-03-07 0001193125-19-066045 — 8.01, 9.01
- 2019-02-28 0001571996-19-000002 — 2.02, 9.01
- 2018-12-28 0001193125-18-360943 — 1.01, 1.02, 3.01, 3.03, 5.02, 5.03, 7.01, 8.01, 9.01
- 2018-12-21 0001193125-18-356324 — 1.01, 2.03, 9.01
- 2018-12-14 0001193125-18-349469 — 8.01
- 2018-12-11 0001193125-18-346958 — 5.07, 8.01, 9.01
- 2018-11-29 0001571996-18-000041 — 2.02, 9.01
- 2018-11-28 0001571996-18-000037 — 7.01, 8.01, 9.01
- 2018-11-26 0001193125-18-333967 — 8.01, 9.01
- 2018-11-15 0001193125-18-328110 — 1.01, 9.01 — amendment of 0001193125-18-327222
- 2018-11-15 0001193125-18-327222 — 1.01, 7.01, 9.01
- 2018-10-03 0001193125-18-291390 — 8.01
- 2018-09-06 0001571996-18-000029 — 2.02, 9.01
- 2018-08-06 0001571996-18-000027 — 8.01, 9.01
- 2018-07-02 0001193125-18-210339 — 1.01, 7.01, 9.01
- 2018-06-28 0001571996-18-000024 — 5.07
- 2018-06-04 0001571996-18-000019 — 2.02, 9.01
- 2018-05-17 0001571996-18-000016 — 7.01
- 2018-04-26 0001571996-18-000009 — 7.01, 9.01
- 2018-03-08 0001193125-18-074168 — 2.02, 9.01
- 2018-02-02 0001193125-18-029947 — 7.01, 9.01
- 2017-12-07 0001571996-17-000042 — 2.02, 9.01
- 2017-10-24 0001571996-17-000037 — 1.01, 2.03, 9.01
- 2017-09-15 0001571996-17-000027 — 5.02
- 2017-09-07 0001571996-17-000017 — 2.02, 9.01
- 2017-08-24 0001571996-17-000014 — 8.01
- 2017-06-29 0001571996-17-000011 — 3.03, 5.07, 8.01, 9.01
- 2017-06-08 0001193125-17-197638 — 2.02, 9.01
- 2017-03-30 0001193125-17-102794 — 8.01
- 2017-03-30 0001193125-17-102777 — 2.02, 9.01
- 2017-03-09 0001193125-17-076981 — 1.01, 2.03, 9.01
- 2017-01-17 0001193125-17-011125 — 8.01
- 2016-12-15 0001193125-16-793722 — 8.01
- 2016-12-08 0001193125-16-787976 — 2.02, 9.01
- 2016-11-10 0001193125-16-765964 — 1.02, 8.01
- 2016-11-04 0001193125-16-760249 — 8.01
- 2016-09-13 0001193125-16-708600 — 3.02
- 2016-09-09 0001193125-16-706567 — 1.01, 1.02, 2.01, 2.03, 3.02, 3.03, 5.02, 9.01
- 2016-09-07 0001193125-16-703370 — 3.03, 5.07, 7.01, 8.01, 9.01
- 2016-09-06 0001193125-16-702057 — 2.02, 9.01
- 2016-08-31 0001193125-16-697268 — 8.01, 9.01
- 2016-08-26 0001193125-16-692921 — 8.01, 9.01
- 2016-07-11 0001193125-16-645610 — 8.01
- 2016-07-05 0001193125-16-641679 — 8.01
- 2016-06-22 0001193125-16-629055 — 1.01, 2.03, 8.01, 9.01
- 2016-06-21 0001193125-16-627071 — 8.01, 9.01
- 2016-06-10 0001193125-16-618483 — 2.02, 9.01
- 2016-06-09 0001193125-16-617893 — 8.01, 9.01

## late-filing notifications on or before 2024-03-25

- none on or before 2024-03-25

## item 2.02 — earnings release, exhibit 99.1

[0001571996-24-000008:8k_2_02:1]
EX-99.1
2
exhibit991earnings8kq4fy24.htm
EX-99.1

[0001571996-24-000008:8k_2_02:2]
Document

[0001571996-24-000008:8k_2_02:3]
Exhibit 99.1

[0001571996-24-000008:8k_2_02:4]
Dell Technologies Delivers Fourth Quarter and Full Year Fiscal 2024 Financial Results

[0001571996-24-000008:8k_2_02:5]
News summary

[0001571996-24-000008:8k_2_02:6]
•Fourth quarter revenue of $22.3 billion and full-year revenue of $88.4 billion

[0001571996-24-000008:8k_2_02:7]
•Full-year operating income of $5.2 billion and non-GAAP operating income of $7.7 billion

[0001571996-24-000008:8k_2_02:8]
•Full-year cash flow from operations of $8.7 billion

[0001571996-24-000008:8k_2_02:9]
•Full-year diluted earnings per share of $4.36 and non-GAAP diluted earnings per share of $7.13

[0001571996-24-000008:8k_2_02:10]
•Announcing a 20% increase in annual cash dividend to $1.78 per common share

[0001571996-24-000008:8k_2_02:11]
ROUND ROCK, Texas — February 29, 2024

[0001571996-24-000008:8k_2_02:12]
Full story

[0001571996-24-000008:8k_2_02:13]
Dell Technologies (NYSE: DELL) announces financial results for its fiscal 2024 fourth quarter and full year. Fourth quarter revenue was $22.3 billion, down 11% year over year. Operating income was $1.5 billion and non-GAAP operating income was $2.1 billion, up 25% and down 1% year over year, respectively. Cash flow from operations was $1.5 billion. Diluted earnings per share was $1.59, and non-GAAP diluted earnings per share was $2.20, up 89% and 22% year over year, respectively.

[0001571996-24-000008:8k_2_02:14]
Revenue for the year was $88.4 billion, down 14% from fiscal year 2023. Operating income was $5.2 billion and non-GAAP operating income was $7.7 billion, down 10% and 11% year over year, respectively. Cash flow from operations for the full year was $8.7 billion. Full-year diluted earnings per share was $4.36, and non-GAAP diluted earnings per share was $7.13, up 35% and down 6% year over year, respectively.

[0001571996-24-000008:8k_2_02:15]
Cash and investments were $9.0 billion, and Dell reached its core leverage target of 1.5x exiting the fiscal year. Dell is increasing its annual cash dividend by 20% to $1.78 per common share, with $0.445 per common share for the first quarterly distribution payable on May 3 to shareholders of record as of April 23.

[0001571996-24-000008:8k_2_02:16]
“We generated $8.7 billion in cash flow from operations this fiscal year, returning $7 billion to shareholders since Q1 FY23,” said Yvonne McGill, chief financial officer, Dell Technologies. “We’re optimistic about FY25 and are increasing our annual dividend by 20% – a testament to our confidence in the business and ability to generate strong cash flow.”

[0001571996-24-000008:8k_2_02:17]
1

[0001571996-24-000008:8k_2_02:18]
Fourth Quarter Fiscal 2024 Financial Results

[0001571996-24-000008:8k_2_02:19]
|  | Three Months Ended |  |  |  | Fiscal Year Ended |  |  |
|  | February 2, 2024 |  | February 3, 2023 |  | Change |  | February 2, 2024 |  | February 3, 2023 |  | Change |
|  | (in millions, except per share amounts and percentages; unaudited) |
| Net revenue | $ | 22,318 |  |  | $ | 25,039 |  |  | (11)% |  | $ | 88,425 |  |  | $ | 102,301 |  |  | (14)% |
| Operating income | $ | 1,491 |  |  | $ | 1,189 |  |  | 25% |  | $ | 5,211 |  |  | $ | 5,771 |  |  | (10)% |
| Net income | $ | 1,158 |  |  | $ | 606 |  |  | 91% |  | $ | 3,195 |  |  | $ | 2,422 |  |  | 32% |
| Earnings per share - diluted | $ | 1.59 |  |  | $ | 0.84 |  |  | 89% |  | $ | 4.36 |  |  | $ | 3.24 |  |  | 35% |
| Non-GAAP operating income | $ | 2,139 |  |  | $ | 2,170 |  |  | (1)% |  | $ | 7,678 |  |  | $ | 8,637 |  |  | (11)% |
| Non-GAAP net income | $ | 1,610 |  |  | $ | 1,322 |  |  | 22% |  | $ | 5,245 |  |  | $ | 5,727 |  |  | (8)% |
| Adjusted free cash flow | $ | 1,010 |  |  | $ | 2,267 |  |  | (55)% |  | $ | 5,607 |  |  | $ | 1,533 |  |  | 266% |
| Non-GAAP earnings per share - diluted | $ | 2.20 |  |  | $ | 1.80 |  |  | 22% |  | $ | 7.13 |  |  | $ | 7.61 |  |  | (6)% |

[0001571996-24-000008:8k_2_02:20]
Information about Dell Technologies’ use of non-GAAP financial information is provided under “Non-GAAP Financial Measures” below. All comparisons in this press release are year-over-year unless otherwise noted.

[0001571996-24-000008:8k_2_02:21]
Infrastructure Solutions Group (ISG) delivered fourth quarter revenue of $9.3 billion, up 10% sequentially and down 6% year over year. Servers and networking revenue was $4.9 billion, with sequential growth driven primarily by AI-optimized servers. Storage revenue was $4.5 billion, up 16% sequentially with demand strength across the portfolio. Operating income was $1.4 billion. Full-year ISG revenue was $33.9 billion, down 12% year over year, and full-year operating income was $4.3 billion, down 15% year over year.

[0001571996-24-000008:8k_2_02:22]
Client Solutions Group (CSG) delivered fourth quarter revenue of $11.7 billion, down 5% sequentially and 12% year over year. Commercial client revenue was $9.6 billion, and Consumer revenue was $2.2 billion. Operating income was $726 million. Full-year CSG revenue was $48.9 billion, down 16% year over year, and full-year operating income was $3.5 billion, down 8% year over year.

[0001571996-24-000008:8k_2_02:23]
“Our strong AI-optimized server momentum continues, with orders increasing nearly 40% sequentially and backlog nearly doubling, exiting our fiscal year at $2.9 billion,” said Jeff Clarke, vice chairman and chief operating officer, Dell Technologies. “We’ve just started to touch the AI opportunities ahead of us, and we believe Dell is uniquely positioned with our broad portfolio to help customers build GenAI solutions that meet performance, cost and security requirements.”

[0001571996-24-000008:8k_2_02:24]
Dell continues to expand its portfolio to help customers meet their performance, cost and security requirements across clouds, on premises and at the edge:

[0001571996-24-000008:8k_2_02:25]
•Expanded the Dell Generative AI Solutions portfolio with support for the AMD Instinct™ MI300X accelerator in Dell PowerEdge XE9680 servers and the new Dell Validated Design for Generative AI with AMD ROCm™ powered AI frameworks.

[0001571996-24-000008:8k_2_02:26]
•Introduced new enterprise data storage advancements and planned validation with the NVIDIA DGX SuperPOD AI infrastructure, helping customers quickly access data for AI workloads with Dell PowerScale systems.

[0001571996-24-000008:8k_2_02:27]
•Announced Dell will have the broadest portfolio of commercial AI laptops and mobile workstations, which feature built-in AI acceleration with the addition of the neural processing unit

[0001571996-24-000008:8k_2_02:28]
2

[0001571996-24-000008:8k_2_02:29]
(NPU). New XPS systems also feature the NPU, helping to improve performance, productivity and collaboration.

[0001571996-24-000008:8k_2_02:30]
•Forged partnership with Nokia to serve as its preferred infrastructure partner for Nokia AirFrame customers, transitioning them to Dell PowerEdge servers with Dell global services and support.  Dell will also offer Nokia’s Digital Automation Cloud solution with Dell NativeEdge to provide a comprehensive, scalable solution for enterprises.

[0001571996-24-000008:8k_2_02:31]
Operating Segments Results

[0001571996-24-000008:8k_2_02:32]
|  | Three Months Ended |  |  |  | Fiscal Year Ended |  |  |
|  | February 2, 2024 |  | February 3, 2023 |  | Change |  | February 2, 2024 |  | February 3, 2023 |  | Change |
|  | (in millions, except percentages; unaudited) |
| Infrastructure Solutions Group (ISG): |  |  |  |  |  |  |  |  |  |  |  |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Servers and networking | $ | 4,857 |  | $ | 4,940 |  |  | (2)% |  | $ | 17,624 |  |  | $ | 20,398 |  |  | (14)% |
| Storage | 4,475 |  |  | 4,965 |  |  | (10)% |  | 16,261 |  |  | 17,958 |  |  | (9)% |
| Total ISG net revenue | $ | 9,332 |  |  | $ | 9,905 |  |  | (6)% |  | $ | 33,885 |  |  | $ | 38,356 |  |  | (12)% |
| Operating Income: |  |  |  |  |  |  |  |  |  |  |  |
| ISG operating income | $ | 1,428 |  |  | $ | 1,543 |  |  | (7)% |  | $ | 4,286 |  |  | $ | 5,045 |  |  | (15)% |
| % of ISG net revenue | 15.3 | % |  | 15.6 | % |  |  |  | 12.6 | % |  | 13.2 | % |  |  |
| % of total reportable segment operating income | 66 | % |  | 70 | % |  |  |  | 55 | % |  | 57 | % |  |  |
| Client Solutions Group (CSG): |  |  |  |  |  |  |  |  |  |  |  |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Commercial | $ | 9,563 |  |  | $ | 10,697 |  |  | (11)% |  | $ | 39,814 |  |  | $ | 45,556 |  |  | (13)% |
| Consumer | 2,152 |  |  | 2,664 |  |  | (19)% |  | 9,102 |  |  | 12,657 |  |  | (28)% |
| Total CSG net revenue | $ | 11,715 |  |  | $ | 13,361 |  |  | (12)% |  | $ | 48,916 |  |  | $ | 58,213 |  |  | (16)% |
| Operating Income: |  |  |  |  |  |  |  |  |  |  |  |
| CSG operating income | $ | 726 |  |  | $ | 671 |  |  | 8% |  | $ | 3,512 |  |  | $ | 3,824 |  |  | (8)% |
| % of CSG net revenue | 6.2 | % |  | 5.0 | % |  |  |  | 7.2 | % |  | 6.6 | % |  |  |
| % of total reportable segment operating income | 34 | % |  | 30 | % |  |  |  | 45 | % |  | 43 | % |  |  |

[0001571996-24-000008:8k_2_02:33]
Conference call information

[0001571996-24-000008:8k_2_02:34]
As previously announced, the company will hold a conference call to discuss its performance and financial guidance on Feb. 29 at 3:30 p.m. CST. Prior to the start of the conference call, prepared remarks and a presentation containing additional financial and operating information prior to financial guidance may be downloaded from investors.delltechnologies.com. The conference call will be broadcast live over the internet and can be accessed at https://investors.delltechnologies.com/news-events/upcoming-events

[0001571996-24-000008:8k_2_02:35]
For those unable to listen to the live broadcast, the final remarks and presentation with financial guidance will be available following the broadcast, and an archived version will be available at the same location for one year.

[0001571996-24-000008:8k_2_02:36]
3

[0001571996-24-000008:8k_2_02:37]
Environmental, Social and Governance (ESG)

[0001571996-24-000008:8k_2_02:38]
Our Environmental, Social and Governance (ESG) efforts focus on driving positive impact for people and our planet while delivering long-term value for our stakeholders. ESG resources can be accessed at https://www.dell.com/en-us/dt/corporate/social-impact/reporting/esg-governance.htm

[0001571996-24-000008:8k_2_02:39]
About Dell Technologies

[0001571996-24-000008:8k_2_02:40]
Dell Technologies (NYSE:DELL) helps organizations and individuals build their digital future and transform how they work, live and play. The company provides customers with the industry’s broadest and most innovative technology and services portfolio for the data era.

[0001571996-24-000008:8k_2_02:41]
Contacts

[0001571996-24-000008:8k_2_02:42]
Investors: Investor_Relations@Dell.com

[0001571996-24-000008:8k_2_02:43]
Media: Media.Relations@Dell.com

[0001571996-24-000008:8k_2_02:44]
# # #

[0001571996-24-000008:8k_2_02:45]
Copyright © 2024 Dell Inc. or its subsidiaries. All Rights Reserved. Dell Technologies, Dell, EMC and Dell EMC are trademarks of Dell Inc. or its subsidiaries. Other trademarks may be trademarks of their respective owners.

[0001571996-24-000008:8k_2_02:46]
Non-GAAP Financial Measures:

[0001571996-24-000008:8k_2_02:47]
This press release presents information about non-GAAP gross margin, non-GAAP operating expenses, non-GAAP operating income, non-GAAP net income, non-GAAP net income attributable to Dell Technologies Inc., non-GAAP earnings per share attributable to Dell Technologies Inc. – diluted, free cash flow, and adjusted free cash flow which are non-GAAP financial measures provided as a supplement to the results provided in accordance with generally accepted accounting principles in the United States of America (“GAAP”). A reconciliation of each non-GAAP financial measure to the most directly comparable GAAP financial measure is provided in the attached tables for each of the fiscal periods indicated.

[0001571996-24-000008:8k_2_02:48]
Special Note on Forward-Looking Statements:

[0001571996-24-000008:8k_2_02:49]
Dell Technologies’ results or events in future periods could differ materially from those expressed or implied by these forward-looking statements because of risks, uncertainties, and other factors that include, but are not limited to, the following: adverse global economic conditions and instability in financial markets; competitive pressures; Dell Technologies’ reliance on third-party suppliers for products and components, including reliance on single-source or limited-source suppliers; Dell Technologies’ ability to achieve favorable pricing from its vendors; Dell Technologies’ execution of its strategy; Dell Technologies’ ability to manage solutions and products and services transitions in an effective manner; Dell Technologies’ ability to deliver high-quality products, software, and services; cyber attacks or other data security incidents; Dell Technologies’ ability to successfully execute on strategic initiatives including acquisitions, divestitures or cost savings measures; Dell Technologies’ foreign operations and ability to generate substantial non-U.S. net revenue; Dell Technologies’ product, services, customer, and geographic sales mix, and seasonal sales trends; the performance of Dell Technologies’ sales channel partners; access to the capital markets by Dell Technologies or its customers; material impairment of the value of goodwill or intangible assets; adverse economic conditions and the effect of additional regulation on Dell Technologies’ financial services activities; counterparty default risks; the loss by Dell Technologies of any contracts for ISG services and solutions and its ability to perform such contracts at their estimated costs; loss by Dell Technologies of government contracts; Dell Technologies’ ability to develop and protect its proprietary intellectual property or obtain licenses to intellectual property developed by others on commercially reasonable and competitive terms; disruptions in Dell Technologies’ infrastructure; Dell Technologies’ ability to hedge effectively its exposure to fluctuations in foreign currency exchange rates and interest rates; expiration of tax holidays or favorable tax rate structures, or unfavorable outcomes in tax audits and other tax compliance matters; impairment of portfolio investments; unfavorable results of legal proceedings; expectations relating to environmental, social and governance (ESG) considerations; compliance requirements of changing environmental and safety laws, human rights laws, or other laws; the effect of armed hostilities, terrorism, natural disasters, or public health issues; the effect of global climate change and legal, regulatory, or market measures to address climate change; Dell Technologies’ dependence on the services of Michael Dell and key employees; Dell Technologies’ level of indebtedness; and business and financial factors and legal restrictions affecting continuation of Dell Technologies’ quarterly cash dividend policy and dividend rate.

[0001571996-24-000008:8k_2_02:50]
This list of risks, uncertainties, and other factors is not complete. Dell Technologies discusses some of these matters more fully, as well as certain risk factors that could affect Dell Technologies’ business, financial condition, results of operations, and prospects, in its reports filed with the SEC, including Dell Technologies’ annual report on Form 10-K for the fiscal year ended February 3, 2023, quarterly reports on

[0001571996-24-000008:8k_2_02:51]
4

[0001571996-24-000008:8k_2_02:52]
Form 10-Q, and current reports on Form 8-K. These filings are available for review through the SEC’s website at www.sec.gov. Any or all forward-looking statements Dell Technologies makes may turn out to be wrong and can be affected by inaccurate assumptions Dell Technologies might make or by known or unknown risks, uncertainties, and other factors, including those identified in this press release. Accordingly, you should not place undue reliance on the forward-looking statements made in this press release, which speak only as of its date. Dell Technologies does not undertake to update, and expressly disclaims any duty to update, its forward-looking statements, whether as a result of circumstances or events that arise after the date they are made, new information, or otherwise.

[0001571996-24-000008:8k_2_02:53]
5

[0001571996-24-000008:8k_2_02:54]
DELL TECHNOLOGIES INC.

[0001571996-24-000008:8k_2_02:55]
Consolidated Statements of Income and Related Financial Highlights

[0001571996-24-000008:8k_2_02:56]
(in millions, except percentages; unaudited)

[0001571996-24-000008:8k_2_02:57]
|  | Three Months Ended |  |  |  | Fiscal Year Ended |  |  |
|  | February 2, 2024 |  | February 3, 2023 |  | Change |  | February 2, 2024 |  | February 3, 2023 |  | Change |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Products | $ | 16,149 |  |  | $ | 19,038 |  |  | (15)% |  | $ | 64,353 |  |  | $ | 79,250 |  |  | (19)% |
| Services | 6,169 |  |  | 6,001 |  |  | 3% |  | 24,072 |  |  | 23,051 |  |  | 4% |
| Total net revenue | 22,318 |  |  | 25,039 |  |  | (11)% |  | 88,425 |  |  | 102,301 |  |  | (14)% |
| Cost of net revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Products | 13,393 |  |  | 15,748 |  |  | (15)% |  | 53,316 |  |  | 66,029 |  |  | (19)% |
| Services | 3,609 |  |  | 3,535 |  |  | 2% |  | 14,240 |  |  | 13,586 |  |  | 5% |
| Total cost of net revenue | 17,002 |  |  | 19,283 |  |  | (12)% |  | 67,556 |  |  | 79,615 |  |  | (15)% |
| Gross margin | 5,316 |  |  | 5,756 |  |  | (8)% |  | 20,869 |  |  | 22,686 |  |  | (8)% |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |
| Selling, general, and administrative | 3,109 |  |  | 3,772 |  |  | (18)% |  | 12,857 |  |  | 14,136 |  |  | (9)% |
| Research and development | 716 |  |  | 795 |  |  | (10)% |  | 2,801 |  |  | 2,779 |  |  | 1% |
| Total operating expenses | 3,825 |  |  | 4,567 |  |  | (16)% |  | 15,658 |  |  | 16,915 |  |  | (7)% |
| Operating income | 1,491 |  |  | 1,189 |  |  | 25% |  | 5,211 |  |  | 5,771 |  |  | (10)% |
| Interest and other, net | (203) |  |  | (266) |  |  | 24% |  | (1,324) |  |  | (2,546) |  |  | 48% |
| Income before income taxes | 1,288 |  |  | 923 |  |  | 40% |  | 3,887 |  |  | 3,225 |  |  | 21% |
| Income tax expense | 130 |  |  | 317 |  |  | (59)% |  | 692 |  |  | 803 |  |  | (14)% |
| Net income | 1,158 |  |  | 606 |  |  | 91% |  | 3,195 |  |  | 2,422 |  |  | 32% |
| Less: Net loss attributable to non-controlling interests | (2) |  |  | (8) |  |  | 75% |  | (16) |  |  | (20) |  |  | 20% |
| Net income attributable to Dell Technologies Inc. | $ | 1,160 |  |  | $ | 614 |  |  | 89% |  | $ | 3,211 |  |  | $ | 2,442 |  |  | 31% |
| Percentage of Total Net Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Gross margin | 23.8 | % |  | 23.0 | % |  |  |  | 23.6 | % |  | 22.2 | % |  |  |
| Selling, general, and administrative | 13.9 | % |  | 15.1 | % |  |  |  | 14.5 | % |  | 13.9 | % |  |  |
| Research and development | 3.2 | % |  | 3.2 | % |  |  |  | 3.2 | % |  | 2.7 | % |  |  |
| Operating expenses | 17.1 | % |  | 18.3 | % |  |  |  | 17.7 | % |  | 16.6 | % |  |  |
| Operating income | 6.7 | % |  | 4.7 | % |  |  |  | 5.9 | % |  | 5.6 | % |  |  |
| Income before income taxes | 5.8 | % |  | 3.7 | % |  |  |  | 4.4 | % |  | 3.2 | % |  |  |
| Net income | 5.2 | % |  | 2.4 | % |  |  |  | 3.6 | % |  | 2.4 | % |  |  |
| Income tax rate | 10.1 | % |  | 34.3 | % |  |  |  | 17.8 | % |  | 24.9 | % |  |  |

[0001571996-24-000008:8k_2_02:58]
Amounts are based on underlying data and may not visually foot due to rounding.

[0001571996-24-000008:8k_2_02:59]
6

[0001571996-24-000008:8k_2_02:60]
DELL TECHNOLOGIES INC.

[0001571996-24-000008:8k_2_02:61]
Consolidated Statements of Financial Position

[0001571996-24-000008:8k_2_02:62]
(in millions; unaudited)

[0001571996-24-000008:8k_2_02:63]
|  | February 2, 2024 |  | February 3, 2023 |
| ASSETS |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 7,366 |  |  | $ | 8,607 |  |
| Accounts receivable, net of allowance of $71 and $78 | 9,343 |  |  | 12,482 |  |
| Due from related party, net | — |  |  | 378 |  |
| Short-term financing receivables, net of allowance of $79 and $142 | 4,643 |  |  | 5,281 |  |
| Inventories | 3,622 |  |  | 4,776 |  |
| Other current assets | 10,957 |  |  | 10,827 |  |
| Current assets held for sale | 16 |  |  | — |  |
| Total current assets | 35,947 |  |  | 42,351 |  |
| Property, plant, and equipment, net | 6,432 |  |  | 6,209 |  |
| Long-term investments | 1,316 |  |  | 1,518 |  |
| Long-term financing receivables, net of allowance of $91 and $59 | 5,877 |  |  | 5,638 |  |
| Goodwill | 19,700 |  |  | 19,676 |  |
| Intangible assets, net | 5,701 |  |  | 6,468 |  |
| Due from related party, net | — |  |  | 440 |  |
| Other non-current assets | 7,116 |  |  | 7,311 |  |
| Total assets | $ | 82,089 |  |  | $ | 89,611 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |
| Short-term debt | $ | 6,982 |  |  | $ | 6,573 |  |
| Accounts payable | 19,389 |  |  | 18,598 |  |
| Due to related party | — |  |  | 2,067 |  |
| Accrued and other | 6,805 |  |  | 8,874 |  |
| Short-term deferred revenue | 15,318 |  |  | 15,542 |  |
| Total current liabilities | 48,494 |  |  | 51,654 |  |
| Long-term debt | 19,012 |  |  | 23,015 |  |
| Long-term deferred revenue | 13,827 |  |  | 14,744 |  |
| Other non-current liabilities | 3,065 |  |  | 3,223 |  |
| Total liabilities | 84,398 |  |  | 92,636 |  |
| Stockholders’ equity (deficit): |  |  |  |
| Total Dell Technologies Inc. stockholders’ equity (deficit) | (2,404) |  |  | (3,122) |  |
| Non-controlling interests | 95 |  |  | 97 |  |
| Total stockholders’ equity (deficit) | (2,309) |  |  | (3,025) |  |
| Total liabilities and stockholders’ equity | $ | 82,089 |  |  | $ | 89,611 |  |

[0001571996-24-000008:8k_2_02:64]
DELL TECHNOLOGIES INC.

[0001571996-24-000008:8k_2_02:65]
Consolidated Statements of Cash Flows

[0001571996-24-000008:8k_2_02:66]
(in millions; unaudited)

[0001571996-24-000008:8k_2_02:67]
|  | Three Months Ended |  | Fiscal Year Ended |
|  | February 2, 2024 |  | February 3, 2023 |  | February 2, 2024 |  | February 3, 2023 |
| Cash flows from operating activities: |  |  |  |  |  |  |  |
| Net income | $ | 1,158 |  |  | $ | 606 |  |  | $ | 3,195 |  |  | $ | 2,422 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: | 375 |  |  | 2,108 |  |  | 5,481 |  |  | 1,143 |  |
| Change in cash from operating activities | 1,533 |  |  | 2,714 |  |  | 8,676 |  |  | 3,565 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |
| Purchases of investments | (29) |  |  | (7) |  |  | (172) |  |  | (108) |  |
| Maturities and sales of investments | 76 |  |  | 17 |  |  | 226 |  |  | 116 |  |
| Capital expenditures and capitalized software development costs | (727) |  |  | (759) |  |  | (2,756) |  |  | (3,003) |  |
| Acquisition of businesses and assets, net | 1 |  |  | (70) |  |  | (126) |  |  | (70) |  |
| Other | 10 |  |  | 23 |  |  | 45 |  |  | 41 |  |
| Change in cash from investing activities | (669) |  |  | (796) |  |  | (2,783) |  |  | (3,024) |  |
| Cash flows from financing activities: |  |  |  |  |  |  |  |
| Proceeds from the issuance of common stock | 2 |  |  | — |  |  | 10 |  |  | 5 |  |
| Repurchases of common stock | (878) |  |  | (165) |  |  | (2,080) |  |  | (2,883) |  |
| Repurchases of common stock for employee tax withholdings | (18) |  |  | (18) |  |  | (372) |  |  | (398) |  |
| Payments of dividends and dividend equivalents | (261) |  |  | (236) |  |  | (1,072) |  |  | (964) |  |
| Proceeds from debt | 871 |  |  | 3,700 |  |  | 7,775 |  |  | 12,479 |  |
| Repayments of debt | (1,480) |  |  | (1,746) |  |  | (11,246) |  |  | (9,825) |  |
| Debt-related costs and other, net | (55) |  |  | (22) |  |  | (109) |  |  | (39) |  |
| Change in cash from financing activities | (1,819) |  |  | 1,513 |  |  | (7,094) |  |  | (1,625) |  |
| Effect of exchange rate changes on cash, cash equivalents, and restricted cash | 14 |  |  | 239 |  |  | (186) |  |  | (104) |  |
| Change in cash, cash equivalents, and restricted cash | (941) |  |  | 3,670 |  |  | (1,387) |  |  | (1,188) |  |
| Cash, cash equivalents, and restricted cash at beginning of the period | 8,448 |  |  | 5,224 |  |  | 8,894 |  |  | 10,082 |  |
| Cash, cash equivalents, and restricted cash at end of the period | $ | 7,507 |  |  | $ | 8,894 |  |  | $ | 7,507 |  |  | $ | 8,894 |  |

[0001571996-24-000008:8k_2_02:68]
8

[0001571996-24-000008:8k_2_02:69]
DELL TECHNOLOGIES INC.

[0001571996-24-000008:8k_2_02:70]
Segment Information

[0001571996-24-000008:8k_2_02:71]
(in millions, except percentages; unaudited; continued on next page)

[0001571996-24-000008:8k_2_02:72]
|  | Three Months Ended |  |  |  | Fiscal Year Ended |  |  |
|  | February 2, 2024 |  | February 3, 2023 |  | Change |  | February 2, 2024 |  | February 3, 2023 |  | Change |
| Infrastructure Solutions Group (ISG): |  |  |  |  |  |  |  |  |  |  |  |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Servers and networking | $ | 4,857 |  | $ | 4,940 |  |  | (2)% |  | $ | 17,624 |  |  | $ | 20,398 |  |  | (14)% |
| Storage | 4,475 |  |  | 4,965 |  |  | (10)% |  | 16,261 |  |  | 17,958 |  |  | (9)% |
| Total ISG net revenue | $ | 9,332 |  |  | $ | 9,905 |  |  | (6)% |  | $ | 33,885 |  |  | $ | 38,356 |  |  | (12)% |
| Operating Income: |  |  |  |  |  |  |  |  |  |  |  |
| ISG operating income | $ | 1,428 |  |  | $ | 1,543 |  |  | (7)% |  | $ | 4,286 |  |  | $ | 5,045 |  |  | (15)% |
| % of ISG net revenue | 15.3 | % |  | 15.6 | % |  |  |  | 12.6 | % |  | 13.2 | % |  |  |
| % of total reportable segment operating income | 66 | % |  | 70 | % |  |  |  | 55 | % |  | 57 | % |  |  |
| Client Solutions Group (CSG): |  |  |  |  |  |  |  |  |  |  |  |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Commercial | $ | 9,563 |  |  | $ | 10,697 |  |  | (11)% |  | $ | 39,814 |  |  | $ | 45,556 |  |  | (13)% |
| Consumer | 2,152 |  |  | 2,664 |  |  | (19)% |  | 9,102 |  |  | 12,657 |  |  | (28)% |
| Total CSG net revenue | $ | 11,715 |  |  | $ | 13,361 |  |  | (12)% |  | $ | 48,916 |  |  | $ | 58,213 |  |  | (16)% |
| Operating Income: |  |  |  |  |  |  |  |  |  |  |  |
| CSG operating income | $ | 726 |  |  | $ | 671 |  |  | 8% |  | $ | 3,512 |  |  | $ | 3,824 |  |  | (8)% |
| % of CSG net revenue | 6.2 | % |  | 5.0 | % |  |  |  | 7.2 | % |  | 6.6 | % |  |  |
| % of total reportable segment operating income | 34 | % |  | 30 | % |  |  |  | 45 | % |  | 43 | % |  |  |

[0001571996-24-000008:8k_2_02:73]
Amounts are based on underlying data and may not visually foot due to rounding.

[0001571996-24-000008:8k_2_02:74]
9

[0001571996-24-000008:8k_2_02:75]
DELL TECHNOLOGIES INC.

[0001571996-24-000008:8k_2_02:76]
Segment Information

[0001571996-24-000008:8k_2_02:77]
(in millions, except percentages; unaudited; continued)

[0001571996-24-000008:8k_2_02:78]
|  | Three Months Ended |  | Fiscal Year Ended |
|  | February 2, 2024 |  | February 3, 2023 |  | February 2, 2024 |  | February 3, 2023 |
| Reconciliation to consolidated net revenue: |  |  |  |  |  |  |
| Reportable segment net revenue | $ | 21,047 |  |  | $ | 23,266 |  |  | $ | 82,801 |  |  | $ | 96,569 |  |
| Other businesses (a) | 1,269 |  |  | 1,770 |  |  | 5,614 |  |  | 5,721 |  |
| Unallocated transactions (b) | 2 |  |  | 3 |  |  | 10 |  |  | 11 |  |
| Total consolidated net revenue | $ | 22,318 |  |  | $ | 25,039 |  |  | $ | 88,425 |  |  | $ | 102,301 |  |
| Reconciliation to consolidated operating income: |  |  |  |  |  |  |  |
| Reportable segment operating income | $ | 2,154 |  |  | $ | 2,214 |  |  | $ | 7,798 |  |  | $ | 8,869 |  |
| Other businesses (a) | (17) |  |  | (48) |  |  | (129) |  |  | (240) |  |
| Unallocated transactions (b) | 2 |  |  | 4 |  |  | 9 |  |  | 8 |  |
| Impact of purchase accounting (c) | (4) |  |  | (11) |  |  | (14) |  |  | (44) |  |
| Amortization of intangibles | (206) |  |  | (238) |  |  | (819) |  |  | (970) |  |
| Transaction-related expenses (d) | (3) |  |  | (6) |  |  | (12) |  |  | (22) |  |
| Stock-based compensation expense (e) | (203) |  |  | (228) |  |  | (878) |  |  | (931) |  |
| Other corporate expenses (f) | (232) |  |  | (498) |  |  | (744) |  |  | (899) |  |
| Total consolidated operating income | $ | 1,491 |  |  | $ | 1,189 |  |  | $ | 5,211 |  |  | $ | 5,771 |  |

[0001571996-24-000008:8k_2_02:79]
_________________

[0001571996-24-000008:8k_2_02:80]
(a)Other businesses consists of: 1) Dell’s resale of standalone VMware, Inc. products and services, “VMware Resale,” 2) Secureworks, and 3) Virtustream, and do not meet the requirements for a reportable segment, either individually or collectively.

[0001571996-24-000008:8k_2_02:81]
(b)Unallocated transactions includes other corporate items that are not allocated to Dell Technologies’ reportable segments.

[0001571996-24-000008:8k_2_02:82]
(c)Impact of purchase accounting includes non-cash purchase accounting adjustments that are primarily related to the EMC merger transaction.

[0001571996-24-000008:8k_2_02:83]
(d)Transaction-related expenses includes acquisition, integration, and divestiture related costs. From time to time, this category also may include transaction-related income related to divestitures of businesses or asset sales.

[0001571996-24-000008:8k_2_02:84]
(e)Stock-based compensation expense consists of equity awards granted based on the estimated fair value of those awards at grant date.

[0001571996-24-000008:8k_2_02:85]
(f)Other corporate expenses includes severance, impairment charges, incentive charges related to equity investments, payroll taxes associated with stock-based compensation, facilities action, and other costs.

[0001571996-24-000008:8k_2_02:86]
10

[0001571996-24-000008:8k_2_02:87]
SUPPLEMENTAL SELECTED NON-GAAP FINANCIAL MEASURES

[0001571996-24-000008:8k_2_02:88]
These tables present information about the Company’s non-GAAP gross margin, non-GAAP operating expenses, non-GAAP operating income, non-GAAP net income, non-GAAP net income attributable to Dell Technologies Inc., non-GAAP earnings per share attributable to Dell Technologies Inc. - diluted, free cash flow and adjusted free cash flow, which are non-GAAP financial measures provided as a supplement to the results provided in accordance with generally accepted accounting principles in the United States of America (“GAAP”). A detailed discussion of Dell Technologies’ reasons for including these non-GAAP financial measures, the limitations associated with these measures, the items excluded from these measures, and our reason for excluding those items are presented in “Management’s Discussion and Analysis of Financial Condition and Results of Operations — Non-GAAP Financial Measures” in our periodic reports filed with the SEC. Dell Technologies encourages investors to review the non-GAAP discussion in these reports in conjunction with the presentation of non-GAAP financial measures.

[0001571996-24-000008:8k_2_02:89]
11

[0001571996-24-000008:8k_2_02:90]
DELL TECHNOLOGIES INC.

[0001571996-24-000008:8k_2_02:91]
Selected Financial Measures

[0001571996-24-000008:8k_2_02:92]
(in millions, except per share amounts and percentages; unaudited)

[0001571996-24-000008:8k_2_02:93]
|  | Three Months Ended |  |  |  | Fiscal Year Ended |  |  |
|  | February 2, 2024 |  | February 3, 2023 |  | % Change |  | February 2, 2024 |  | February 3, 2023 |  | Change |
| Net revenue (a) | $ | 22,318 |  |  | $ | 25,039 |  |  | (11)% |  | $ | 88,425 |  |  | $ | 102,301 |  |  | (14)% |
| Non-GAAP gross margin | $ | 5,468 |  |  | $ | 5,971 |  |  | (8)% |  | $ | 21,444 |  |  | $ | 23,427 |  |  | (8)% |
| % of non-GAAP net revenue | 24.5 | % |  | 23.8 | % |  |  |  | 24.3 | % |  | 22.9 | % |  |  |
| Non-GAAP operating expenses | $ | 3,329 |  |  | $ | 3,801 |  |  | (12)% |  | $ | 13,766 |  |  | $ | 14,790 |  |  | (7)% |
| % of non-GAAP net revenue | 14.9 | % |  | 15.1 | % |  |  |  | 15.6 | % |  | 14.5 | % |  |  |
| Non-GAAP operating income | $ | 2,139 |  |  | $ | 2,170 |  |  | (1)% |  | $ | 7,678 |  | $ | 8,637 |  | (11)% |
| % of non-GAAP net revenue | 9.6 | % |  | 8.7 | % |  |  |  | 8.7 | % |  | 8.4 | % |  |  |
| Non-GAAP net income | $ | 1,610 |  |  | $ | 1,322 |  |  | 22% |  | $ | 5,245 |  |  | $ | 5,727 |  |  | (8)% |
| % of non-GAAP net revenue | 7.2 | % |  | 5.3 | % |  |  |  | 5.9 | % |  | 5.6 | % |  |  |
| Non-GAAP earnings per share - diluted | $ | 2.20 |  |  | $ | 1.80 |  |  | 22% |  | $ | 7.13 |  |  | $ | 7.61 |  |  | (6)% |

[0001571996-24-000008:8k_2_02:94]
____________________

[0001571996-24-000008:8k_2_02:95]
(a)    Effective in the first quarter of Fiscal 2023, non-GAAP net revenue no longer differs from net revenue, the most comparable GAAP financial measure.

[0001571996-24-000008:8k_2_02:96]
Amounts are based on underlying data and may not visually foot due to rounding.

[0001571996-24-000008:8k_2_02:97]
12

[0001571996-24-000008:8k_2_02:98]
DELL TECHNOLOGIES INC.

[0001571996-24-000008:8k_2_02:99]
Reconciliation of Selected Non-GAAP Financial Measures

[0001571996-24-000008:8k_2_02:100]
(in millions, except percentages; unaudited; continued on next page)

[0001571996-24-000008:8k_2_02:101]
|  | Three Months Ended |  |  |  | Fiscal Year Ended |  |  |
|  | February 2, 2024 |  | February 3, 2023 |  | % Change |  | February 2, 2024 |  | February 3, 2023 |  | % Change |
| Gross margin | $ | 5,316 |  |  | $ | 5,756 |  |  | (8)% |  | $ | 20,869 |  |  | $ | 22,686 |  |  | (8)% |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 84 |  |  | 99 |  |  |  |  | 331 |  |  | 414 |  |  |  |
| Impact of purchase accounting | — |  |  | — |  |  |  |  | — |  |  | 2 |  |  |  |
| Stock-based compensation expense | 37 |  |  | 40 |  |  |  |  | 149 |  |  | 152 |  |  |  |
| Other corporate expenses | 31 |  |  | 76 |  |  |  |  | 95 |  |  | 173 |  |  |  |
| Non-GAAP gross margin | $ | 5,468 |  |  | $ | 5,971 |  |  | (8)% |  | $ | 21,444 |  |  | $ | 23,427 |  |  | (8)% |
| Operating expenses | $ | 3,825 |  |  | $ | 4,567 |  |  | (16)% |  | $ | 15,658 |  |  | $ | 16,915 |  |  | (7)% |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | (122) |  |  | (139) |  |  |  |  | (488) |  |  | (556) |  |  |  |
| Impact of purchase accounting | (4) |  |  | (11) |  |  |  |  | (14) |  |  | (42) |  |  |  |
| Transaction-related expenses | (3) |  |  | (6) |  |  |  |  | (12) |  |  | (22) |  |  |  |
| Stock-based compensation expense | (166) |  |  | (188) |  |  |  |  | (729) |  |  | (779) |  |  |  |
| Other corporate expenses | (201) |  |  | (422) |  |  |  |  | (649) |  |  | (726) |  |  |  |
| Non-GAAP operating expenses | $ | 3,329 |  |  | $ | 3,801 |  |  | (12)% |  | $ | 13,766 |  |  | $ | 14,790 |  |  | (7)% |
| Operating income | $ | 1,491 |  |  | $ | 1,189 |  |  | 25% |  | $ | 5,211 |  |  | $ | 5,771 |  |  | (10)% |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 206 |  |  | 238 |  |  |  |  | 819 |  |  | 970 |  |  |  |
| Impact of purchase accounting | 4 |  |  | 11 |  |  |  |  | 14 |  |  | 44 |  |  |  |
| Transaction-related expenses | 3 |  |  | 6 |  |  |  |  | 12 |  |  | 22 |  |  |  |
| Stock-based compensation expense | 203 |  |  | 228 |  |  |  |  | 878 |  |  | 931 |  |  |  |
| Other corporate expenses | 232 |  |  | 498 |  |  |  |  | 744 |  |  | 899 |  |  |  |
| Non-GAAP operating income | $ | 2,139 |  |  | $ | 2,170 |  |  | (1)% |  | $ | 7,678 |  |  | $ | 8,637 |  |  | (11)% |
| Net income | $ | 1,158 |  |  | $ | 606 |  |  | 91 | % |  | $ | 3,195 |  |  | $ | 2,422 |  |  | 32% |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 206 |  |  | 238 |  |  |  |  | 819 |  |  | 970 |  |  |  |
| Impact of purchase accounting | 4 |  |  | 11 |  |  |  |  | 14 |  |  | 44 |  |  |  |
| Transaction-related (income) expenses | (5) |  |  | (14) |  |  |  |  | 49 |  |  | (16) |  |  |  |
| Stock-based compensation expense | 203 |  |  | 228 |  |  |  |  | 878 |  |  | 931 |  |  |  |
| Other corporate expenses | 232 |  |  | 392 |  |  |  |  | 744 |  |  | 1,812 |  |  |  |
| Fair value adjustments on equity investments | (83) |  |  | 9 |  |  |  |  | (47) |  |  | 206 |  |  |  |
| Aggregate adjustment for income taxes | (105) |  |  | (148) |  |  |  |  | (407) |  |  | (642) |  |  |  |
| Non-GAAP net income | $ | 1,610 |  |  | $ | 1,322 |  |  | 22% |  | $ | 5,245 |  |  | $ | 5,727 |  |  | (8)% |

[0001571996-24-000008:8k_2_02:102]
13

[0001571996-24-000008:8k_2_02:103]
DELL TECHNOLOGIES INC.

[0001571996-24-000008:8k_2_02:104]
Reconciliation of Selected Non-GAAP Financial Measures

[0001571996-24-000008:8k_2_02:105]
(unaudited; continued)

[0001571996-24-000008:8k_2_02:106]
|  | Three Months Ended |  |  |  | Fiscal Year Ended |  |  |  |  |  |  |
|  | February 2,2024 |  | February 3,2023 |  | % Change |  | February 2,2024 |  | February 3,2023 |  | % Change |  |  |  |  |
| Earnings per share attributable to Dell Technologies, Inc. - diluted | $ | 1.59 |  |  | $ | 0.84 |  |  | 89 | % |  | $ | 4.36 |  |  | $ | 3.24 |  |  | 35 | % |  |  |  |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 0.28 |  |  | 0.32 |  |  |  |  | 1.11 |  |  | 1.29 |  |  |  |  |  |  |  |
| Impact of purchase accounting | 0.01 |  |  | 0.01 |  |  |  |  | 0.02 |  |  | 0.06 |  |  |  |  |  |  |  |
| Transaction-related (income) expenses | (0.01) |  |  | (0.02) |  |  |  |  | 0.07 |  |  | (0.02) |  |  |  |  |  |  |  |
| Stock-based compensation expense | 0.28 |  |  | 0.31 |  |  |  |  | 1.19 |  |  | 1.24 |  |  |  |  |  |  |  |
| Other corporate expenses | 0.32 |  |  | 0.53 |  |  |  |  | 1.01 |  |  | 2.41 |  |  |  |  |  |  |  |
| Fair value adjustments on equity investments | (0.11) |  |  | 0.01 |  |  |  |  | (0.06) |  |  | 0.27 |  |  |  |  |  |  |  |
| Aggregate adjustment for income taxes | (0.15) |  |  | (0.19) |  |  |  |  | (0.55) |  |  | (0.86) |  |  |  |  |  |  |  |
| Total non-GAAP adjustments attributable to non-controlling interests | (0.01) |  |  | (0.01) |  |  |  |  | (0.02) |  |  | (0.02) |  |  |  |  |  |  |  |
| Non-GAAP earnings per share attributable to Dell Technologies, Inc. - diluted | $ | 2.20 |  |  | $ | 1.80 |  |  | 22 | % |  | $ | 7.13 |  |  | $ | 7.61 |  |  | (6) | % |  |  |  |  |

[0001571996-24-000008:8k_2_02:107]
14

[0001571996-24-000008:8k_2_02:108]
DELL TECHNOLOGIES INC.

[0001571996-24-000008:8k_2_02:109]
Reconciliation of Selected Non-GAAP Financial Measures

[0001571996-24-000008:8k_2_02:110]
(in millions, except percentages; unaudited; continued)

[0001571996-24-000008:8k_2_02:111]
|  | Three Months Ended |  |  |  | Fiscal Year Ended |  |  |  |  |  |  |
|  | February 2,2024 |  | February 3,2023 |  | % Change |  | February 2,2024 |  | February 3,2023 |  | % Change |  |  |  |  |
| Cash flow from operations | $ | 1,533 |  |  | $ | 2,714 |  |  | (44) | % |  | $ | 8,676 |  |  | $ | 3,565 |  |  | 143 | % |  |  |  |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Capital expenditures and capitalized software development costs, net (a) | (727) |  |  | (749) |  |  |  |  | (2,753) |  |  | (2,993) |  |  |  |  |  |  |  |
| Free cash flow | $ | 806 |  |  | $ | 1,965 |  |  | (59) | % |  | $ | 5,923 |  |  | $ | 572 |  |  | 935 | % |  |  |  |  |
| Free cash flow | $ | 806 |  |  | $ | 1,965 |  |  | (59) | % |  | $ | 5,923 |  |  | $ | 572 |  |  | 935 | % |  |  |  |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| DFS financing receivables (b) | 136 |  |  | 175 |  |  |  |  | (309) |  |  | 461 |  |  |  |  |  |  |  |
| DFS operating leases (c) | 68 |  |  | 127 |  |  |  |  | (7) |  |  | 500 |  |  |  |  |  |  |  |
| Adjusted free cash flow | $ | 1,010 |  |  | $ | 2,267 |  |  | (55) | % |  | $ | 5,607 |  |  | $ | 1,533 |  |  | 266 | % |  |  |  |  |

[0001571996-24-000008:8k_2_02:112]
____________________

[0001571996-24-000008:8k_2_02:113]
(a)    Capital expenditures and capitalized software development costs is net of proceeds from sales of facilities, land, and

[0001571996-24-000008:8k_2_02:114]
other assets.

[0001571996-24-000008:8k_2_02:115]
(b)    DFS financing receivables represents the operating cash flow impact from the change in financing receivables.

[0001571996-24-000008:8k_2_02:116]
(c)    DFS operating leases represents the change in net carrying value of equipment for DFS operating leases.
