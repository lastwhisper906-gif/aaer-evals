# DELL notes — 0001571996-24-000036


## dei:DocumentsIncorporatedByReferenceTextBlock

[0001571996-24-000036:notes:1]
DOCUMENTS INCORPORATED BY REFERENCE

[0001571996-24-000036:notes:2]
The information required by Part III of this report, to the extent not set forth herein, is incorporated by reference from the registrant’s proxy statement relating to its annual meeting of stockholders to be held in 2024.  The proxy statement will be filed with the Securities and Exchange Commission within 120 days after the end of the fiscal year to which this report relates.


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0001571996-24-000036:notes:3]
Basis of Presentation — These Consolidated Financial Statements have been prepared in accordance with accounting principles generally accepted in the United States of America (“GAAP”).

[0001571996-24-000036:notes:4]
The Company’s fiscal year is the 52- or 53-week period ending on the Friday nearest January 31.  The fiscal years ended February 2, 2024 and January 28, 2022 were 52-week periods.  The fiscal year ended February 3, 2023 was a 53-week period.


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock

[0001571996-24-000036:notes:5]
SUMMARY OF SIGNIFICANT ACCOUNTING POLICIES 
Principles of Consolidation — These Consolidated Financial Statements include the accounts of Dell Technologies and its wholly-owned subsidiaries, as well as the accounts of Secureworks, which, as indicated in Note 1 of the Notes to the Consolidated Financial Statements, is majority-owned by Dell Technologies, and VMware through the date of the VMware Spin-off.  All intercompany transactions have been eliminated.

[0001571996-24-000036:notes:6]
The Company also consolidates Variable Interest Entities ("VIEs") where it has been determined that the Company is the primary beneficiary of the applicable entities’ operations.  For each VIE, the primary beneficiary is the party that has both the power to direct the activities that most significantly impact the VIE's economic performance and the obligation to absorb losses or the right to receive benefits of the VIE that could potentially be significant to such VIE.  In evaluating whether the Company is the primary beneficiary of each entity, the Company evaluates its power to direct the most significant activities of the VIE by considering the purpose and design of each entity and the risks each entity was designed to create and pass through to its respective variable interest holders.  The Company also evaluates its economic interests in each of the VIEs.  See Note 6 of the Notes to the Consolidated Financial Statements for more information regarding consolidated VIEs.

[0001571996-24-000036:notes:7]
Use of Estimates — The preparation of financial statements in accordance with GAAP requires management to make estimates and assumptions that affect the amounts reported in the Consolidated Financial Statements and the accompanying Notes.   Actual results could differ materially from those estimates.

[0001571996-24-000036:notes:8]
Cash and Cash Equivalents — All highly liquid investments with original maturities of 90 days or less at date of purchase are reported at fair value and are considered to be cash equivalents.  Credit card receivables are classified as either cash and cash equivalents or receivables depending on the nature of the payment terms.

[0001571996-24-000036:notes:9]
Investments — The Company has strategic investments in equity and other securities as well as investments in fixed-income debt securities.  All equity and other securities and long-term fixed income debt securities are recorded as long-term investments in the Consolidated Statements of Financial Position.  Short-term fixed income debt securities are recorded as other current assets in the Consolidated Statements of Financial Position.

[0001571996-24-000036:notes:10]
Strategic investments in marketable equity and other securities are recorded at fair value based on quoted prices in active markets.  Strategic investments in non-marketable equity and other securities without readily determinable fair values are recorded at cost, less impairment, and are adjusted for observable price changes.  Fair value measurements and impairments for strategic investments are recognized in interest and other, net in the Consolidated Statements of Income.  In evaluating equity investments without readily determinable fair values for impairment or observable price changes, the Company uses inputs that include pre- and post-money valuations of recent financing events and the impact of those events on its fully diluted ownership percentages, as well as other available information regarding the issuer’s historical and forecasted performance.

[0001571996-24-000036:notes:11]
Fixed-income debt securities are carried at amortized cost.  The Company intends to hold the fixed-income debt securities to maturity.

[0001571996-24-000036:notes:12]
Allowance for Expected Credit Losses on Accounts Receivable — The Company recognizes an allowance for losses on accounts receivable in an amount equal to the current expected credit losses.  The estimation of the allowance is based on an analysis of historical loss experience, current receivables aging, and management’s assessment of current conditions and reasonable and supportable expectation of future conditions, as well as an assessment of specific identifiable customer accounts considered at risk or uncollectible.  The Company assesses collectibility by pooling receivables where similar characteristics exist and evaluates receivables individually when specific customer balances no longer share those risk characteristics and are considered at risk or uncollectible.  The expense associated with the allowance for expected credit losses is recognized in selling, general, and administrative expenses.

[0001571996-24-000036:notes:13]
Accounting for Operating Leases as a Lessee — In its ordinary course of business, the Company enters into leases as a lessee for office buildings, warehouses, employee vehicles, and equipment.  The Company determines if an arrangement is a lease or contains a lease at inception.  The Company’s leases are generally classified as operating leases.  Finance leases are immaterial.  Operating leases result in the recognition of right of use (“ROU”) assets and lease liabilities on the Consolidated Statements of Financial Position.  ROU assets represent the right to use an underlying asset for the lease term and lease liabilities represent the obligation to make lease payments arising from the lease, measured on a discounted basis.  At lease commencement, the lease liability is measured at the present value of the lease payments over the lease term.  The operating lease ROU asset equals the lease liability adjusted for any initial direct costs, prepaid or deferred rent, and lease incentives.  The Company uses the implicit rate when readily determinable.  As most of the leases do not provide an implicit rate, the Company uses its incremental borrowing rate based on the information available at the commencement date to determine the present value of lease payments.

[0001571996-24-000036:notes:14]
The lease term may include options to extend or to terminate the lease that the Company is reasonably certain to exercise.  The Company has elected not to record leases with an initial term of 12 months or less on the Consolidated Statements of Financial Position.  Lease expense is recognized on a straight-line basis over the lease term in most instances.  The Company does not generate material sublease income and has no material related party leases.  The Company’s lease agreements do not contain any material residual value guarantees or material restrictive covenants.

[0001571996-24-000036:notes:15]
The Company’s office building agreements contain costs such as common area maintenance and other executory costs that may be either fixed or variable in nature.  Variable lease costs are expensed as incurred.  The Company combines lease and non-lease components, including fixed common area and other maintenance costs, in calculating the ROU assets and lease liabilities for its office buildings and employee vehicles.  Under certain service agreements with third-party logistics providers, the Company directs the use of the inventory within the warehouses and, therefore, controls the assets.  The warehouses and some of the equipment used are considered embedded leases.  The Company accounts for the lease and non-lease components separately.  The lease components consist of the warehouses and some of the equipment, such as conveyor belts.  The non-lease components consist of services and other shared equipment, such as material handling and transportation.  The Company allocates the consideration to the lease and non-lease components using their relative standalone values.  See Note 7 of the Notes to the Consolidated Financial Statements for additional information.

[0001571996-24-000036:notes:16]
Accounting for Leases as a Lessor — The Company’s wholly-owned subsidiary Dell Financial Services and its affiliates (“DFS”) act as a lessor to provide equipment financing to customers through a variety of lease arrangements (“DFS leases”).  The Company’s leases are classified as sales-type leases, direct financing leases, or operating leases.  Direct financing leases are immaterial.

[0001571996-24-000036:notes:17]
The Company also offers alternative payment structures and as-a-Service offerings that are assessed to determine whether an embedded lease arrangement exists.  The Company accounts for those contracts as a lease arrangement if it is determined that the contract contains an identified asset and that control of that asset has transferred to the customer.

[0001571996-24-000036:notes:18]
When a contract includes lease and non-lease components, the Company allocates consideration under the contract to each component based on relative standalone selling price and subsequently assesses lease classification for each lease component within a contract.  DFS provides lessees with the option to extend the lease or purchase the underlying asset at the end of the lease term, which is considered when evaluating lease classification.  In general, DFS’s lease arrangements do not have variable payment terms and are typically non-cancelable.

[0001571996-24-000036:notes:19]
On commencement of sales-type leases, the Company recognizes profit up-front, and amounts due from the customer under the lease contract are recognized as financing receivables on the Consolidated Statements of Financial Position.  Interest income is recognized as net product revenue over the term of the lease based on the effective interest method.  The Company has elected not to include sales and other taxes collected from the lessee as part of lease revenue.

[0001571996-24-000036:notes:20]
All other leases that do not meet the definition of a sales-type lease or direct financing lease are classified as operating leases.  The underlying asset in an operating lease arrangement is carried at depreciated cost as “Assets in a customer contract” within Property, plant, and equipment, net on the Consolidated Statements of Financial Position.  Depreciation is calculated using the straight-line method over the term of the underlying lease contract and is recognized as cost of net revenue.  The depreciable basis is the original cost of the equipment less the estimated residual value of the equipment at the end of the lease term.  The residual value is based upon estimates of the value of the equipment at the end of the lease term using historical studies, industry data, and future value-at-risk demand valuation methods.  The Company recognizes operating lease income to product revenue generally on a straight-line basis over the lease term and expenses deferred initial direct costs on the same basis.  The Company recognizes variable lease income to product revenue generally as earned.  Impairment of assets in a customer contract is assessed on the same basis as other long-lived assets.

[0001571996-24-000036:notes:21]
Accounting for Fixed-Term Loans — For fixed-term loans, the Company may recognize profit up-front upon commencement or over time depending on the product or service offering.  Amounts due from the customer under the loan agreement are recognized as financing receivables on the Consolidated Statements of Financial Position.  The Company generally recognizes interest income to product revenue based on the effective interest method and expenses deferred initial direct costs on a straight-line basis over the loan term.

[0001571996-24-000036:notes:22]
Financing Receivables — Financing receivables are presented net of allowance for losses and consist of customer receivables and residual interest.  Gross customer receivables include amounts due from customers under revolving loans, fixed-term loans, fixed-term sales-type or direct financing leases, and accrued interest.  The Company has two portfolios, consisting of (i) fixed-term leases and loans and (ii) revolving loans, and assesses risk at the portfolio level to determine the appropriate allowance levels.  The portfolio segments are further segregated into classes based on products, customer type, and credit risk evaluation.  Fixed-term leases and loans are offered to qualified small and medium-sized businesses, large commercial accounts, governmental organizations, and educational entities.  Fixed-term loans are also offered to qualified individual consumers.  Revolving loans offered under a private label credit financing program, referred to as Dell Business Credit (“DBC”), are primarily offered to small and medium-sized business customers.

[0001571996-24-000036:notes:23]
The Company retains a residual interest in equipment leased under its fixed-term lease programs.  The amount of the residual interest is established at the inception of the lease based upon estimates of the value of the equipment at the end of the lease term using historical studies, industry data, and future value-at-risk demand valuation methods.

[0001571996-24-000036:notes:24]
Allowance for Financing Receivables Losses — The Company recognizes an allowance for financing receivables losses, including both the lease receivable and unguaranteed residual, in an amount equal to the expected losses net of recoveries.  The allowance for financing receivables losses on the lease receivable is determined based on various factors, including lifetime expected losses determined using macroeconomic forecast assumptions and management judgments applicable to and through the expected life of the portfolios as well as past due receivables, receivable type, and customer risk profile.  Both fixed and revolving financing receivables loss rates are affected by macroeconomic conditions, including the level of gross domestic product (“GDP”) growth, the level of commercial capital equipment investment, unemployment rates, and the credit quality of the borrower.

[0001571996-24-000036:notes:25]
Generally, expected credit losses as a result of residual value risk on equipment under lease are not considered to be significant primarily because of the existence of a secondary market with respect to the equipment.  The Company’s lease agreements also generally define applicable return conditions and remedies for non-compliance to ensure that the leased equipment will be in good operating condition upon return.  Model changes and updates, as well as market strength and product acceptance, are monitored and adjustments are made to residual values in accordance with the significance of any such changes.

[0001571996-24-000036:notes:26]
When an account is deemed to be uncollectible, customer account principal and interest are charged off to the allowance for losses.  While the Company does not generally place financing receivables on non-accrual status during the delinquency period, accrued interest is included in the allowance for loss calculation and, therefore, the Company is adequately reserved in the event of charge off.  Recoveries on receivables previously charged off as uncollectible are recorded to the allowance for financing receivables losses.  The expense associated with the allowance for financing receivables losses is recognized as cost of net revenue.

[0001571996-24-000036:notes:27]
Asset Securitization — The Company transfers certain U.S. and European customer loan and lease payments and associated equipment to Special Purpose Entities (“SPEs”) that meet the definition of a Variable Interest Entity (“VIE”) and are consolidated into the Consolidated Financial Statements.  These SPEs are bankruptcy-remote legal entities with separate assets and liabilities.  The purpose of the SPEs is to facilitate the funding of customer loan and lease payments and associated equipment in the capital markets.  Some of these SPEs have entered into financing arrangements with multi-seller conduits that, in turn, issue asset-backed debt securities in the capital markets.  The asset securitizations in the SPEs are accounted for as secured borrowings.

[0001571996-24-000036:notes:28]
Inventories — The Company generally records inventory on the Consolidated Statements of Financial Position when legal title and risk of loss have passed to the Company for items that are held for sale in the ordinary course of business, that are in process of production for sale, or that will be consumed in the production of goods or services that will be held for sale.  Inventories are stated at the lower of cost or net realizable value, with cost being determined on a first-in, first-out basis.  Adjustments to reduce the cost of inventory to its net realizable value are made, if required, for estimated excess, obsolescence, or impaired balances.  At the point of the loss recognition, a new, lower cost basis for that inventory is established, and subsequent changes in facts and circumstances do not result in the restoration or increase in the newly established cost basis.

[0001571996-24-000036:notes:29]
Property, Plant, and Equipment — Property, plant, and equipment are carried at depreciated cost.  Depreciation is determined using the straight-line method over the shorter of the estimated useful lives of the assets or the lease term, as applicable.  The estimated useful lives of the Company’s property, plant, and equipment are generally as follows:

[0001571996-24-000036:notes:30]
|  | Estimated Useful Life |
| Computer and other equipment | 3-5 years |
| Assets in a customer contract | Term of underlying lease contract |
| Buildings and building improvements | 10-30 years or term of underlying land lease |
| Leasehold improvements | 5 years or contract term |
| Internal use software | 5 years |

[0001571996-24-000036:notes:31]
Gains or losses related to retirements or dispositions of fixed assets are recognized in the period during which the retirement or disposition occurs.

[0001571996-24-000036:notes:32]
Capitalized Software Development Costs — Software development costs related to the development of new product offerings are capitalized subsequent to the establishment of technological feasibility, which is demonstrated by the completion of a detailed program design or working model, if no program design is completed.  The Company amortizes capitalized costs on a straight-line basis over the estimated useful lives of the products, which is generally two years.

[0001571996-24-000036:notes:33]
As of February 2, 2024 and February 3, 2023, capitalized software development costs were $646 million and $673 million, respectively, and are included in other non-current assets, net in the accompanying Consolidated Statements of Financial Position.  Amortization expense for the fiscal years ended February 2, 2024, February 3, 2023, and January 28, 2022 was $416 million, $317 million, and $263 million, respectively.

[0001571996-24-000036:notes:34]
The Company capitalizes certain internal and external costs to acquire or create internal use software which are incurred subsequent to the completion of the preliminary project stage.  Costs associated with maintenance and minor enhancements to the features and functionality of the Company’s internal use software are expensed as incurred.

[0001571996-24-000036:notes:35]
Impairment of Long-Lived Assets — The Company reviews long-lived assets for impairment when events or changes in circumstances indicate the carrying amount of an asset may not be recoverable.  The Company assesses the recoverability of the assets based on the undiscounted future cash flows expected from the use and eventual disposition of the asset.  If the carrying amount of the asset is determined not to be recoverable, a write-down to fair value is recorded.  Fair values are determined based on quoted market values, discounted cash flows, or external appraisals, as applicable.  Long-lived assets to be disposed of are reported at the lower of carrying amount or fair value less costs to sell.

[0001571996-24-000036:notes:36]
Intangible Assets Including Goodwill — Identifiable intangible assets with finite lives are amortized over their estimated useful lives.  Indefinite-lived intangible assets are not amortized.  Definite-lived intangible assets are reviewed for impairment when events and circumstances indicate the asset may be impaired.  Goodwill and indefinite-lived intangible assets are tested for impairment annually during the third fiscal quarter and whenever events or circumstances indicate that an impairment may have occurred.

[0001571996-24-000036:notes:37]
Foreign Currency Translation — The majority of the Company’s international sales are made by international subsidiaries, some of which have the U.S. Dollar as their functional currency.  The Company’s subsidiaries that do not use the U.S. Dollar as their functional currency translate assets and liabilities at current exchange rates in effect at the balance sheet date.  Revenue and expenses from these international subsidiaries are translated using either the monthly average exchange rates in effect for the period in which the activity was recognized or the specific daily exchange rate associated with the date the transactions actually occur.  Foreign currency translation adjustments are included as a component of accumulated other comprehensive income (loss) (“AOCI”) in stockholders’ equity (deficit).

[0001571996-24-000036:notes:38]
Local currency transactions of international subsidiaries that have the U.S. Dollar as their functional currency are remeasured into U.S. Dollars using the current rates of exchange for monetary assets and liabilities and historical rates of exchange for nonmonetary assets and liabilities.  Gains and losses from remeasurement of monetary assets and liabilities are included in interest and other, net on the Consolidated Statements of Income.  See Note 21 of the Notes to the Consolidated Financial Statements for amounts recognized from remeasurement during the periods presented.

[0001571996-24-000036:notes:39]
Hedging Instruments — The Company uses derivative financial instruments, primarily forward contracts, options, and swaps, to hedge certain foreign currency and interest rate exposures.  The relationships between hedging instruments and hedged items, as well as the risk management objectives and strategies for undertaking hedge transactions, are formally documented.  The Company does not use derivatives for speculative purposes.  All derivative instruments are recognized as either assets or liabilities in the Consolidated Statements of Financial Position and are measured at fair value.  The Company’s hedge portfolio includes non-designated derivatives and derivatives designated as cash flow hedges and, from time to time, fair value hedges.

[0001571996-24-000036:notes:40]
For derivative instruments designated as a cash flow hedge, the Company assesses hedge effectiveness at the onset of the hedge, then performs qualitative assessments at regular intervals throughout the life of the derivative.  The gain or loss on the hedge is recorded in AOCI, as a separate component of stockholders’ equity (deficit), and reclassified into earnings in the period during which the hedged transaction is recognized in earnings.  For derivatives that are designated as a fair value hedge, the Company evaluates the effectiveness of the qualifying fair value hedge using the shortcut method of accounting under which hedges are assumed to be perfectly effective.  The change in fair value of the hedge exactly offsets the fair value of the hedged item and there is no net impact recognized in earnings from the fair value of the derivative.  For derivatives that are not designated as hedges or do not qualify for hedge accounting treatment, the Company recognizes the change in the instrument’s fair value in earnings as a component of interest and other, net.

[0001571996-24-000036:notes:41]
Cash flows from derivative instruments are presented in the same category on the Consolidated Statements of Cash Flows as the cash flows from the underlying hedged items.  See Note 9 of the Notes to the Consolidated Financial Statements for a description of the Company’s derivative financial instrument activities.

[0001571996-24-000036:notes:42]
Revenue Recognition — The Company sells a wide portfolio of products and services to its customers.  The Company’s agreements have varying requirements depending on the goods and services being sold, the rights and obligations conveyed, and the legal jurisdiction of the arrangement.

[0001571996-24-000036:notes:43]
Revenue is recognized for these arrangements based on the following five steps:

[0001571996-24-000036:notes:44]
(1)    Identify the contract with a customer.  The Company evaluates facts and circumstances regarding sales transactions in order to identify contracts with its customers.  An agreement must meet all of the following criteria to qualify as a contract eligible for revenue recognition under the model:  (i) the contract must be approved by all parties who are committed to perform their respective obligations; (ii) each party’s rights regarding the goods and services to be transferred to the customer can be identified; (iii) the payment terms for the goods and services can be identified; (iv) the customer has the ability and intent to pay and it is probable that the Company will collect substantially all of the consideration to which it will be entitled; and (v) the contract must have commercial substance.  Judgment is used in determining the customer’s ability and intent to pay, which is based upon various factors, including the customer’s historical payment experience or customer credit and financial information.

[0001571996-24-000036:notes:45]
(2)    Identify the performance obligations in the contract.  The Company’s contracts with customers often include the promise to transfer multiple goods and services to the customer.  Distinct promises within a contract are referred to as “performance obligations” and are accounted for as separate units of account.  The Company assesses whether each promised good or service is distinct for the purpose of identifying the performance obligations in the contract.  This assessment involves subjective determinations and requires management to make judgments about the individual promised goods or services and whether such goods or services are separable from the other aspects of the contractual relationship.  Promised goods and services are considered distinct provided that: (i) the customer can benefit from the good or service either on its own or together with other resources that are readily available to the customer (that is, the good or service is capable of being distinct); and (ii) the Company’s promise to transfer the good or service to the customer is separately identifiable from other promises in the contract (that is, the promise to transfer the good or service is distinct within the context of the contract).  The Company’s performance obligations include various distinct goods and services such as hardware, software licenses, support and maintenance agreements, and other service offerings and solutions.  Promised goods and services are explicitly identified in the Company’s contracts and may be sold on a standalone basis or bundled as part of a combined solution.  In certain hardware solutions, the hardware is highly interdependent on, and interrelated with, the embedded software.  In these offerings, the hardware and software licenses are accounted for as a single performance obligation.

[0001571996-24-000036:notes:46]
(3)    Determine the transaction price.  The transaction price reflects the amount of consideration to which the Company expects to be entitled in exchange for transferring goods or services to the customer.  If the consideration promised in a contract includes a variable amount, the Company estimates the amount to which it expects to be entitled using either the expected value or most likely amount method.  Generally, volume discounts, rebates, and sales returns reduce the transaction price.  In determining the transaction price, the Company only includes amounts that are not subject to significant future reversal.

[0001571996-24-000036:notes:47]
(4)    Allocate the transaction price to performance obligations in the contract.  When a contract includes multiple performance obligations, the transaction price is allocated to each performance obligation in an amount that depicts the consideration to which the Company expects to be entitled in exchange for transferring the promised goods or services.  For contracts with multiple performance obligations, the transaction price is allocated in proportion to the standalone selling price (“SSP”) of each performance obligation.

[0001571996-24-000036:notes:48]
The best evidence of SSP is the observable price of a good or service when the Company sells that good or service separately in similar circumstances to similar customers.  If a directly observable price is available, the Company will utilize that price for the SSP.  If a directly observable price is not available, the SSP must be estimated.  The Company estimates SSP by considering multiple factors, including, but not limited to, pricing practices, internal costs, and profit objectives as well as overall market conditions, which include geographic or regional specific factors, competitive positioning, and competitor actions.

[0001571996-24-000036:notes:49]
(5)    Recognize revenue when (or as) the performance obligation is satisfied.  Revenue is recognized when obligations under the terms of the contract with the Company’s customer are satisfied.  Revenue is recognized either over time or at a point in time, depending on when the underlying products or services are transferred to the customer.  Revenue is recognized at a point in time for products upon transfer of control.  Revenue is recognized over time for support and deployment services, software support, Software-as-a-Service (“SaaS”), and Infrastructure-as-a-Service (“IaaS”).  Revenue is recognized either over time or at a point in time for professional services and training depending on the nature of the offering to the customer.

[0001571996-24-000036:notes:50]
The Company reports revenue net of any revenue-based taxes assessed by governmental authorities that are imposed on and concurrently with specific revenue-producing transactions.

[0001571996-24-000036:notes:51]
The Company has elected the following practical expedients:

[0001571996-24-000036:notes:52]
•The Company does not account for significant financing components if the period between revenue recognition and when the customer pays for the product or service will be one year or less.

[0001571996-24-000036:notes:53]
•The Company recognizes revenue equal to the amount it has a right to invoice when the amount corresponds directly with the value to the customer of the Company’s performance to date.

[0001571996-24-000036:notes:54]
•The Company does not account for shipping and handling activities as a separate performance obligation, but rather as an activity performed to transfer the promised good.

[0001571996-24-000036:notes:55]
The following summarizes the nature of revenue recognized and the manner in which the Company accounts for sales transactions.

[0001571996-24-000036:notes:56]
Products

[0001571996-24-000036:notes:57]
Product revenue consists of revenue from sales of hardware products, including notebooks and desktop PCs, servers, storage hardware, and other hardware-related devices, as well as revenue from software license sales, including non-essential software applications and third-party software licenses.

[0001571996-24-000036:notes:58]
Revenue from sales of hardware products is recognized when control has transferred to the customer, which typically occurs when the hardware has been shipped to the customer, risk of loss has transferred to the customer, the Company has a present right to payment, and customer acceptance has been satisfied.  Customer acceptance is satisfied if acceptance is obtained from the customer, if all acceptance provisions lapse, or if the Company has evidence that all acceptance provisions will be, or have been, satisfied.  Revenue from software license sales is generally recognized when control has transferred to the customer, which is typically upon shipment, electronic delivery, or when the software is available for download by the customer.  For certain software arrangements in which the customer is granted a right to additional unspecified future software licenses, the Company’s promise to the customer is considered a stand-ready obligation in which the transfer of control and revenue recognition will occur over time.

[0001571996-24-000036:notes:59]
Services

[0001571996-24-000036:notes:60]
Services revenue consists of revenue from sales of support services, including hardware support that extends beyond the Company’s standard warranties, software maintenance, and installation; professional services; training; SaaS; and IaaS.  Revenue associated with undelivered performance obligations is deferred and recognized when or as control is transferred to the customer.  Revenue from fixed-price support or maintenance contracts sold for both hardware and software is recognized on a straight-line basis over the period of performance because the Company is required to provide services at any given time.  Other services revenue is recognized when the Company performs the services and the customer receives and consumes the benefits.

[0001571996-24-000036:notes:61]
Other

[0001571996-24-000036:notes:62]
Revenue from leasing arrangements is not subject to the revenue standard for contracts with customers and remains separately accounted for under lease accounting guidance.  The Company records operating lease rental revenue as product revenue on a straight-line basis over the lease term.  The Company records revenue under sales-type leases as product revenue in an amount equal to the present value of minimum lease payments at the inception of the lease.  Sales-type leases also produce financing income, which is included in product net revenue in the Consolidated Statements of Income and is recognized at effective rates of return over the lease term.  The Company also offers qualified customers fixed-term loans and revolving credit lines for the purchase of products and services offered by the Company.  Financing income attributable to these loans is recognized in product net revenue on an accrual basis.

[0001571996-24-000036:notes:63]
Principal versus Agent — For transactions that involve a third party, the Company evaluates whether it is acting as the principal or the agent in the transaction.  This determination requires significant judgment and impacts the amount and timing of revenue recognized.  If the Company determines that it controls a good or service before it is transferred to the customer, the Company is acting as the principal and recognizes revenue at the gross amount of consideration it is entitled to from the customer.  Indicators that the Company controls a good or service before transferring it to a customer include, but are not limited to, the Company being the primary obligor to the customer, establishing its own pricing, and having inventory and credit risks.  Conversely, if the Company determines that it does not control the good or service before it is transferred to the customer, the Company is acting as an agent in the transaction.  As an agent, the Company is arranging for the good or service to be provided by another party and recognizes revenue at the net amount of consideration retained.

[0001571996-24-000036:notes:64]
Disaggregation of Revenue — The Company’s revenue is presented on a disaggregated basis on the Consolidated Statements of Income and in Note 19 of the Notes to the Consolidated Financial Statements based on an evaluation of disclosures outside of the financial statements, information regularly reviewed by the chief operating decision maker for evaluating the financial performance of operating segments, and other information that is used to evaluate the Company’s financial performance and make resource allocations.  This information includes revenue from products and services, revenue from reportable segments, and revenue by major product categories within the segments.

[0001571996-24-000036:notes:65]
Contract Assets — Contract assets are rights to consideration in exchange for goods or services that the Company has transferred to a customer when such a right is conditional on something other than the passage of time.  Such amounts are immaterial as of February 2, 2024 and February 3, 2023.

[0001571996-24-000036:notes:66]
Contract Liabilities — Contract liabilities primarily consist of deferred revenue.  Deferred revenue is recorded when the Company has invoiced or payments have been received for undelivered products or services, or in situations where revenue recognition criteria have not been met.  Deferred revenue primarily includes amounts received in advance for extended warranty services and software maintenance.  Revenue is recognized on these items when the revenue recognition criteria are met, generally resulting in ratable recognition over the contract term.  The Company also has deferred revenue related to undelivered hardware and professional services, consisting of installations and consulting engagements, which are recognized when the Company’s performance obligations under the contract are completed.  See Note 11 of the Notes to the Consolidated Financial Statements for additional information about deferred revenue.

[0001571996-24-000036:notes:67]
Deferred Costs — Deferred costs primarily consist of costs incurred to fulfill revenue-generating contracts mainly associated with VMware Resale offerings discussed in Note 19 and Note 20 of the Notes to the Consolidated Financial Statements and third-party software support and maintenance offerings.  Deferred costs are included with other current assets and other non-current assets on the Consolidated Statements of Financial Position.  The Company defers and subsequently amortizes these charges on a straight-line basis over the life of the contract or the average contract duration to obtain the appropriate expense recognition timing.

[0001571996-24-000036:notes:68]
Costs to Obtain a Contract — The Company capitalizes incremental direct costs to obtain a contract, primarily sales commissions and employer taxes related to commission payments, if the costs are deemed to be recoverable.  The Company has elected, as a practical expedient, to expense as incurred costs to obtain a contract equal to or less than one year in duration.  Capitalized costs are deferred and amortized over the period of contract performance or the estimated life of the customer relationship, if renewals are expected, and are typically amortized over an average period of one to five years.  Amortization expense is recognized on a straight-line basis and included in selling, general, and administrative expenses in the Consolidated Statements of Income.

[0001571996-24-000036:notes:69]
The Company periodically reviews these deferred costs to determine whether events or changes in circumstances have occurred that could impact the carrying value or period of benefit of the deferred sales commissions.  There were no material impairment losses for deferred costs to obtain a contract during the fiscal years ended February 2, 2024, February 3, 2023, and January 28, 2022.

[0001571996-24-000036:notes:70]
Deferred costs to obtain a contract as of February 2, 2024 and February 3, 2023 were $674 million and $726 million, respectively.  Deferred costs to obtain a contract are classified as current assets and other non-current assets on the Consolidated Statements of Financial Position, based on when the expense is expected to be recognized.  Amortization of costs to obtain a contract during the fiscal years ended February 2, 2024, February 3, 2023, and January 28, 2022 was $383 million, $390 million, and $380 million, respectively.

[0001571996-24-000036:notes:71]
Standard Warranty Liabilities — The Company records warranty liabilities for estimated costs of fulfilling its obligations under standard limited hardware and software warranties at the time of sale.  The liabilities for standard warranties are included in accrued and other and in other non-current liabilities in the Consolidated Statements of Financial Position.  The specific warranty terms and conditions vary depending upon the product sold and the country in which the Company does business, but generally include technical support, parts, and labor over a period ranging from one to three years.  Factors that affect the Company’s warranty liabilities include the number of installed units currently under warranty, historical and anticipated rates of warranty claims on those units, and cost per claim to satisfy the Company’s warranty obligation.  The anticipated rate of warranty claims is the primary estimate used in determining the warranty liability and is relatively predictable using historical experience of failure rates.  The average remaining aggregate warranty period of the covered installed base is approximately 17 months, repair parts are generally already in stock or available at pre-determined prices, and labor rates are generally arranged at preestablished amounts with service providers.  If actual results differ from the estimates, the Company revises its estimated warranty liability.  Each quarter, the Company reevaluates its estimates to assess the adequacy of its recorded warranty liabilities and adjusts the amounts as necessary.

[0001571996-24-000036:notes:72]
Consideration Received from Vendors — The Company may receive consideration from vendors in the normal course of business.  Certain of these funds received as consideration are rebates of purchase price paid and others are related to reimbursement of costs incurred by the Company to sell the vendor’s products.  The Company recognizes a reduction of cost of goods sold if the funds are determined to be a reduction of the price of the vendor’s products.  If the consideration is a reimbursement of costs incurred by the Company to sell or develop the vendor’s products, the consideration is classified as a reduction of such costs, most often operating expenses, in the Consolidated Statements of Income.  In order to be recognized as a reduction of operating expenses, the reimbursement must be for a specific, incremental, and identifiable cost incurred by the Company in selling the vendor’s products or services.

[0001571996-24-000036:notes:73]
Loss Contingencies — The Company is subject to the possibility of various losses arising in the ordinary course of business.  In determining loss contingencies, the Company considers the likelihood of loss or impairment of an asset or the incurrence of a liability, as well as the Company’s ability to reasonably estimate the amount of loss.  An estimated loss contingency is accrued when it is probable that an asset has been impaired or a liability has been incurred and the amount of loss can be reasonably estimated.  The Company regularly evaluates current information available to determine whether such accruals should be adjusted and whether new accruals are required.

[0001571996-24-000036:notes:74]
Shipping Costs — The Company’s shipping and handling costs are included in cost of net revenue in the Consolidated Statements of Income.

[0001571996-24-000036:notes:75]
Selling, General, and Administrative — Selling expenses include items such as sales salaries and commissions, marketing and advertising costs, and contractor services.  Advertising costs are expensed as incurred in selling, general, and administrative expenses in the Consolidated Statements of Income.  For the fiscal years ended February 2, 2024, February 3, 2023, and January 28, 2022, advertising expenses were $0.9 billion, $1.1 billion, and $1.3 billion, respectively.  General and administrative expenses include items for the Company’s administrative functions, such as finance, legal, human resources, and information technology support.  These functions include costs for items such as salaries and benefits and other personnel-related costs, maintenance and supplies, outside services, intangible asset amortization, and depreciation expense.

[0001571996-24-000036:notes:76]
Research and Development — Research and development (“R&D”) costs are primarily expensed as incurred.  As noted in Capitalized Software Development Costs in this Note, qualifying software development costs are capitalized and amortized over time.  R&D costs include salaries and benefits and other personnel-related costs associated with product development.  Also included in R&D expenses are infrastructure costs, which consist of equipment and material costs, facilities-related costs, and depreciation expense.

[0001571996-24-000036:notes:77]
Income Taxes — The Company calculates a provision for income taxes using the asset and liability method, under which deferred tax assets and liabilities are recognized by identifying the temporary differences arising from the different treatment of items for tax and accounting purposes.  Deferred tax assets and liabilities are recorded using enacted tax rates in effect for the year in which the differences are expected to reverse.  The Company accounts for the tax impact of including Global Intangible Low-Taxed Income (GILTI) in U.S. taxable income as a period cost.  The Company provides valuation allowances for deferred tax assets, where appropriate.  In assessing the need for a valuation allowance, the Company considers all available evidence for each jurisdiction, including past operating results, estimates of future taxable income, and the feasibility of ongoing tax planning strategies.  In the event the Company determines that all or part of the net deferred tax assets are not realizable in the future, the Company will make an adjustment to the valuation allowance that will be charged to earnings in the period in which such a determination is made.

[0001571996-24-000036:notes:78]
The accounting guidance for uncertainties in income tax prescribes a comprehensive model for the financial statement recognition, measurement, presentation, and disclosure of uncertain tax positions taken or expected to be taken in income tax returns.  The Company recognizes a tax benefit from an uncertain tax position in the financial statements only when it is more likely than not that the position will be sustained upon examination, including resolution of any related appeals or litigation processes, based on the technical merits and a consideration of the relevant taxing authority’s administrative practices and precedents.

[0001571996-24-000036:notes:79]
Stock-Based Compensation — The Company measures stock-based compensation expense for all share-based awards granted based on the estimated fair value of those awards at grant date.  To estimate the fair value of performance-based awards containing a market condition, the Company uses the Monte Carlo valuation model.  The fair value of other share-based awards is generally based on the closing price of the Class C Common Stock as reported on the New York Stock Exchange (“NYSE”) on the date of grant.

[0001571996-24-000036:notes:80]
The compensation cost of service-based stock options, restricted stock, and restricted stock units is recognized net of any estimated forfeitures on a straight-line basis over the employee requisite service period.  Compensation cost for performance-based awards is recognized on a graded accelerated basis net of estimated forfeitures over the requisite service period.  Forfeiture rates are estimated at grant date based on historical experience and adjusted in subsequent periods for differences in actual forfeitures from those estimates.

[0001571996-24-000036:notes:81]
Recently Issued Accounting Pronouncements

[0001571996-24-000036:notes:82]
Segment Reporting — In November 2023, the Financial Accounting Standards Board (“FASB”) issued guidance to improve disclosures about a public entity’s reportable segments by requiring disclosure of additional information about a reportable segment’s expenses on an annual and interim basis.  Public entities must adopt the new guidance for fiscal years beginning after December 15, 2023, with early adoption permitted.  Upon adoption, the guidance is required to be applied retrospectively to all prior periods presented in the financial statements.  Adoption of this new guidance will result in increased disclosures in the Notes to the Consolidated Financial Statements.

[0001571996-24-000036:notes:83]
Income Taxes — In December 2023, the FASB issued guidance which requires companies to provide disaggregated income tax disclosures within the income tax rate reconciliation and income taxes paid.  Public entities must adopt the new guidance for fiscal years beginning after December 15, 2024, with early adoption permitted.  Upon adoption, the guidance can be applied prospectively or retrospectively.  Adoption of this new guidance will result in increased disclosures in the Notes to the Consolidated Financial Statements.


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0001571996-24-000036:notes:84]
DISCONTINUED OPERATIONS
VMware Spin-Off — As disclosed in Note 1 of the Notes to the Consolidated Financial Statements, on November 1, 2021, the Company completed its spin-off of VMware by means of a special stock dividend of 30,678,605 shares of Class A common stock and 307,221,836 shares of Class B common stock of VMware to Dell Technologies stockholders of record as of October 29, 2021.  VMware paid a cash dividend, pro rata, to each of the holders of VMware common stock in an aggregate amount equal to $11.5 billion, of which Dell Technologies received $9.3 billion.

[0001571996-24-000036:notes:85]
Dell Technologies determined that the VMware Spin-off, and related distributions, qualified as tax-free for U.S. federal income tax purposes, which required significant judgment by management.  In making these determinations, Dell Technologies applied U.S. federal tax law to relevant facts and circumstances and obtained a favorable private letter ruling from the Internal Revenue Service, a tax opinion, and other external tax advice related to the concluded tax treatment.  If the completed transactions were to fail to qualify for tax-free treatment for U.S. federal income tax purposes, the Company could be subject to significant liabilities, which could have material adverse impacts on the Company’s business, financial condition, results of operations and cash flows in future reporting periods.

[0001571996-24-000036:notes:86]
In connection with and upon completion of the VMware Spin-off, Dell Technologies and VMware entered into various agreements that provided a framework for the relationship between the companies after the transaction, including, among others, a commercial framework agreement, a tax matters agreement, and a transition services agreement.

[0001571996-24-000036:notes:87]
The Commercial Framework Agreement (“CFA”) provided a framework under which the Company and VMware continued their commercial relationship after the transaction, particularly with respect to projects mutually agreed by the parties as having the potential to accelerate the growth of an industry, product, service, or platform that may provide one or both companies with a strategic market opportunity.

[0001571996-24-000036:notes:88]
On November 22, 2023, VMware was acquired by Broadcom, Inc. (“Broadcom”).  Following the acquisition, Broadcom announced changes to its go-to-market approach for VMware offerings, which impacted the Company’s commercial relationship with VMware.  In response to such changes, on January 25, 2024, under a provision of the CFA permitting the Company to terminate the agreement upon a change in control of VMware, the Company delivered notice of termination of the CFA to Broadcom under which the agreement will terminate on March 25, 2024.

[0001571996-24-000036:notes:89]
Cash flows between Dell Technologies and VMware for the periods presented primarily relate to the Company’s resale of VMware’s standalone products and services and sale of Dell Technologies’ offerings integrated with select VMware products and services.  See Note 20 of the Notes to the Consolidated Financial Statements for additional information regarding transactions between Dell Technologies and VMware.

[0001571996-24-000036:notes:90]
In accordance with applicable accounting guidance, the results of VMware, excluding Dell Technologies’ resale of VMware offerings, are presented as discontinued operations in the Consolidated Statements of Income and, as such, have been excluded from both continuing operations and segment results for the fiscal year ended January 28, 2022.  The Consolidated Statements of Cash Flows are presented on a consolidated basis for both continuing operations and discontinued operations for the fiscal year ended January 28, 2022.

[0001571996-24-000036:notes:91]
The tax matters agreement between the Company and VMware governs the respective rights, responsibilities, and obligations of Dell Technologies and VMware with respect to tax liabilities (including taxes, if any, incurred as a result of any failure of the VMware Spin-off to qualify for tax-free treatment for U.S. federal income tax purposes) and benefits, tax attributes, the preparation and filing of tax returns, the control of audits and other tax proceedings, cooperation, and other matters regarding tax.

[0001571996-24-000036:notes:92]
The transition services agreement between the Company and VMware governed the various administrative services which the Company provided to VMware on an interim transitional basis.  Transition services were fulfilled and concluded during the fiscal year ended February 3, 2023.

[0001571996-24-000036:notes:93]
The following table presents key components of “Income from discontinued operations, net of income taxes” for the fiscal year ended January 28, 2022:

[0001571996-24-000036:notes:94]
|  |  |  |  |  |  | Fiscal Year Ended |
|  |  |  |  |  |  | January 28, 2022 |
|  |  |  |  |  |  | (in millions) |
| Net revenue |  |  |  |  |  | $ | 5,798 |  |
| Cost of net revenue |  |  |  |  |  | (1,632) |  |
| Operating expenses |  |  |  |  |  | 6,384 |  |
| Interest and other, net |  |  |  |  |  | 232 |  |
| Income from discontinued operations before income taxes |  |  |  |  |  | 814 |  |
| Income tax expense |  |  |  |  |  | 49 |  |
| Income from discontinued operations, net of income taxes |  |  |  |  |  | $ | 765 |  |

[0001571996-24-000036:notes:95]
____________________

[0001571996-24-000036:notes:96]
The table above reflects the offsetting effects of historical intercompany transactions which are presented on a gross basis within continuing operations on the Consolidated Statements of Income.

[0001571996-24-000036:notes:97]
The following table presents significant cash flow items from discontinued operations for the fiscal year ended January 28, 2022 included within the Consolidated Statements of Cash Flows:

[0001571996-24-000036:notes:98]
|  |  |  |  | Fiscal Year Ended |
|  |  |  |  | January 28, 2022 |  |  |
|  |  |  |  | (in millions) |
| Depreciation and amortization |  |  |  | $ | 1,004 |  |  |  |
| Capital expenditures |  |  |  | $ | 263 |  |  |  |
| Stock-based compensation expense |  |  |  | $ | 814 |  |  |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001571996-24-000036:notes:99]
FAIR VALUE MEASUREMENTS
The following table presents the Company’s hierarchy for its assets and liabilities measured at fair value on a recurring basis as of the dates indicated:

[0001571996-24-000036:notes:100]
|  | February 2, 2024 |  | February 3, 2023 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | Quoted Prices in Active Markets for Identical Assets |  | Significant Other Observable Inputs |  | Significant Unobservable Inputs |  |  |  | Quoted Prices in Active Markets for Identical Assets |  | Significant Other Observable Inputs |  | Significant Unobservable Inputs |  |  |
|  | (in millions) |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | $ | 3,170 |  |  | $ | — |  |  | $ | — |  |  | $ | 3,170 |  |  | $ | 4,301 |  |  | $ | — |  |  | $ | — |  |  | $ | 4,301 |  |
| Marketable equity and other securities | 10 |  |  | — |  |  | — |  |  | 10 |  |  | 33 |  |  | — |  |  | — |  |  | 33 |  |
| Derivative instruments | — |  |  | 104 |  |  | — |  |  | 104 |  |  | — |  |  | 295 |  |  | — |  |  | 295 |  |
| Total assets | $ | 3,180 |  |  | $ | 104 |  |  | $ | — |  |  | $ | 3,284 |  |  | $ | 4,334 |  |  | $ | 295 |  |  | $ | — |  |  | $ | 4,629 |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Derivative instruments | $ | — |  |  | $ | 84 |  |  | $ | — |  |  | $ | 84 |  |  | $ | — |  |  | $ | 460 |  |  | $ | — |  |  | $ | 460 |  |
| Total liabilities | $ | — |  |  | $ | 84 |  |  | $ | — |  |  | $ | 84 |  |  | $ | — |  |  | $ | 460 |  |  | $ | — |  |  | $ | 460 |  |

[0001571996-24-000036:notes:101]
The following section describes the valuation methodologies the Company uses to measure financial instruments at fair value.

[0001571996-24-000036:notes:102]
Money Market Funds — The Company’s investment in money market funds that are classified as cash equivalents hold underlying investments with a weighted average maturity of 90 days or less and are recognized at fair value.  The valuations of these securities are based on quoted prices in active markets for identical assets, when available, or pricing models whereby all significant inputs are observable or can be derived from or corroborated by observable market data.  The Company reviews security pricing and assesses money market fund liquidity on a quarterly basis.  As of February 2, 2024, the Company’s portfolio had no material exposure to money market funds with a fluctuating net asset value.

[0001571996-24-000036:notes:103]
Marketable Equity and Other Securities — The Company’s investments in equity and other securities that are measured at fair value on a recurring basis consist of strategic investments in publicly-traded companies.  The valuation of these securities is based on quoted prices in active markets.

[0001571996-24-000036:notes:104]
Derivative Instruments — The Company’s derivative financial instruments consist primarily of foreign currency forward and purchased option contracts and interest rate swaps.  The fair value of the portfolio is determined using valuation models based on market observable inputs, including interest rate curves, forward and spot prices for currencies, and implied volatilities.  Credit risk is also factored into the fair value calculation of the Company’s derivative financial instrument portfolio.  See Note 9 of the Notes to the Consolidated Financial Statements for a description of the Company’s derivative financial instrument activities.

[0001571996-24-000036:notes:105]
Deferred Compensation Plans — The Company offers deferred compensation plans for eligible employees, which allow participants to defer a portion of their compensation.  Assets were the same as liabilities associated with the plans at approximately $214 million and $179 million as of February 2, 2024 and February 3, 2023, respectively, and are included in other assets and other liabilities on the Consolidated Statements of Financial Position.  The net impact to the Consolidated Statements of Income is not material since changes in the fair value of the assets substantially offset changes in the fair value of the liabilities.  As such, assets and liabilities associated with these plans have not been included in the recurring fair value table above.

[0001571996-24-000036:notes:106]
Assets and Liabilities Measured at Fair Value on a Nonrecurring Basis — Certain assets are measured at fair value on a nonrecurring basis and therefore are not included in the recurring fair value table above.  These assets consist primarily of non-financial assets such as goodwill and intangible assets.  See Note 10 of the Notes to the Consolidated Financial Statements for additional information about goodwill and intangible assets.

[0001571996-24-000036:notes:107]
As of both February 2, 2024 and February 3, 2023, the Company held strategic investments in non-marketable equity and other securities of $1.3 billion.  As these investments represent early-stage companies without readily determinable fair values, they are not included in the recurring fair value table above.  See Note 5 of the Notes to the Consolidated Financial Statements for additional information about the Company’s strategic investments.

[0001571996-24-000036:notes:108]
Carrying Value and Estimated Fair Value of Outstanding Debt — The following table presents the carrying value and estimated fair value of the Company’s outstanding debt as described in Note 8 of the Notes to the Consolidated Financial Statements, including the current portion, as of the dates indicated:

[0001571996-24-000036:notes:109]
|  | February 2, 2024 |  | February 3, 2023 |
|  | Carrying Value |  | Fair Value |  | Carrying Value |  | Fair Value |
|  | (in billions) |
| Senior Notes | $ | 15.5 |  |  | $ | 15.8 |  |  | $ | 18.1 |  |  | $ | 18.2 |  |
| Legacy Notes and Debentures | $ | 0.9 |  |  | $ | 1.0 |  |  | $ | 0.9 |  |  | $ | 1.0 |  |
| DFS Debt | $ | 9.5 |  |  | $ | 9.1 |  |  | $ | 10.3 |  |  | $ | 9.9 |  |

[0001571996-24-000036:notes:110]
The fair values of the outstanding debt shown in the table above were determined based on observable market prices in a less active market or based on valuation methodologies using observable inputs and were categorized as Level 2 in the fair value hierarchy.


## us-gaap:InvestmentTextBlock

[0001571996-24-000036:notes:111]
INVESTMENTS
The Company has strategic investments in equity and other securities as well as investments in fixed income debt securities.  All equity and other securities as well as long-term fixed income debt securities are recorded as long-term investments while short-term fixed income debt securities are recorded as other current assets in the Consolidated Statements of Financial Position.

[0001571996-24-000036:notes:112]
As of both February 2, 2024 and February 3, 2023, total investments were $1.6 billion.

[0001571996-24-000036:notes:113]
Equity and Other Securities

[0001571996-24-000036:notes:114]
Equity and other securities include strategic investments in marketable and non-marketable securities.  Investments in marketable securities are measured at fair value on a recurring basis.  The Company has elected to apply the measurement alternative for non-marketable securities.  Under the alternative, the Company measures investments without readily determinable fair values at cost, less impairment, adjusted by observable price changes.  The Company makes a separate election to use the alternative for each eligible investment and is required to reassess at each reporting period whether an investment qualifies for the alternative.  In evaluating these investments for impairment or observable price changes, the Company uses inputs including pre- and post-money valuations of recent financing events and the impact of those events on its fully diluted ownership percentages, as well as other available information regarding the issuer’s historical and forecasted performance.

[0001571996-24-000036:notes:115]
Carrying Value of Equity and Other Securities

[0001571996-24-000036:notes:116]
The following table presents the cost, cumulative unrealized gains, cumulative unrealized losses, and carrying value of the Company's strategic investments in marketable and non-marketable equity securities as of the dates indicated:

[0001571996-24-000036:notes:117]
|  | February 2, 2024 |  | February 3, 2023 |
|  | Cost |  | Unrealized Gain |  | Unrealized Loss |  | Carrying Value |  | Cost |  | Unrealized Gain |  | Unrealized Loss |  | Carrying Value |
|  | (in millions) |
| Marketable | $ | 12 |  |  | $ | 24 |  |  | $ | (26) |  |  | $ | 10 |  |  | $ | 56 |  |  | $ | 17 |  |  | $ | (40) |  |  | $ | 33 |  |
| Non-marketable | 732 |  |  | 1,015 |  |  | (454) |  |  | 1,293 |  |  | 714 |  |  | 651 |  |  | (100) |  |  | 1,265 |  |
| Total equity and other securities | $ | 744 |  |  | $ | 1,039 |  |  | $ | (480) |  |  | $ | 1,303 |  |  | $ | 770 |  |  | $ | 668 |  |  | $ | (140) |  |  | $ | 1,298 |  |

[0001571996-24-000036:notes:118]
Gains and Losses on Equity and Other Securities

[0001571996-24-000036:notes:119]
The following table presents unrealized gains and losses on marketable and non-marketable equity and other securities for the periods indicated:

[0001571996-24-000036:notes:120]
|  | Fiscal Year Ended |
|  | February 2, 2024 |  | February 3, 2023 |  | January 28, 2022 |
|  | (in millions) |
| Marketable securities: |  |  |  |  |  |
| Unrealized gain | $ | 6 |  |  | $ | 57 |  |  | $ | 45 |  |
| Unrealized loss | (24) |  |  | (47) |  |  | (151) |  |
| Net unrealized gain (loss) | (18) |  |  | 10 |  |  | (106) |  |
| Non-marketable securities: |  |  |  |  |  |
| Unrealized gain | 84 |  |  | 90 |  |  | 604 |  |
| Unrealized loss | (49) |  |  | (349) |  |  | (43) |  |
| Net unrealized gain (loss) (a) (b) | 35 |  |  | (259) |  |  | 561 |  |
| Net unrealized gain (loss) on equity and other securities | $ | 17 |  |  | $ | (249) |  |  | $ | 455 |  |

[0001571996-24-000036:notes:121]
(a)    For the fiscal year ended February 2, 2024 and January 28, 2022, net unrealized gains on non-marketable securities were due to upward adjustments for observable price changes offset by losses primarily attributable to downward adjustments for observable price changes or impairments.

[0001571996-24-000036:notes:122]
(b)    For the fiscal year ended February 3, 2023, net unrealized losses on non-marketable securities were primarily attributable to the recognition of impairments which were generally in line with extended public equity market declines.

[0001571996-24-000036:notes:123]
Fixed Income Debt Securities

[0001571996-24-000036:notes:124]
The Company has fixed income debt securities carried at amortized cost which are primarily held as collateral for borrowings.  The Company intends to hold the investments to maturity.  As of February 2, 2024, the Company held $288 million in fixed income debt securities which will mature within one year and $13 million in fixed income debt securities which will mature within five years.

[0001571996-24-000036:notes:125]
The following table summarizes the Company’s debt securities as of the dates indicated:

[0001571996-24-000036:notes:126]
|  | February 2, 2024 |  | February 3, 2023 |
|  | Cost |  | Unrealized Gain |  | Unrealized Loss |  | Carrying Value |  | Cost |  | Unrealized Gain |  | Unrealized Loss |  | Carrying Value |
|  | (in millions) |
| Fixed income debt securities | $ | 325 |  |  | $ | 67 |  |  | $ | (91) |  |  | $ | 301 |  |  | $ | 348 |  |  | $ | 65 |  |  | $ | (95) |  |  | $ | 318 |  |


## dell:CreditLossFinancialInstrumentLeasesDebtVariableInterestEntitiesAndCustomerReceivablesSalesTextBlock

[0001571996-24-000036:notes:127]
FINANCIAL SERVICES
The Company offers or arranges various financing options and alternative payment structures for its customers globally.  Alternative payment structures consist of various flexible consumption models, including utility, subscription, and as-a-Service models.

[0001571996-24-000036:notes:128]
Financing options are offered to the Company’s customers primarily through Dell Financial Services and its affiliates (“DFS”).  The Company also arranges financing for some of its customers in various countries where DFS does not currently operate as a captive enterprise.  The key activities of DFS include originating, collecting, and servicing customer financing arrangements primarily related to the purchase or use of Dell Technologies products and services.  In some cases, DFS also offers financing for the purchase of third-party technology products that complement the Dell Technologies portfolio of products and services.  New financing originations were $8.4 billion, $9.7 billion, and $8.5 billion for the fiscal years ended February 2, 2024, February 3, 2023, and January 28, 2022, respectively.

[0001571996-24-000036:notes:129]
The Company’s lease and loan arrangements with customers are aggregated primarily into the following categories:

[0001571996-24-000036:notes:130]
Fixed-term leases and loans — The Company enters into financing arrangements with customers who seek lease financing for equipment.  DFS leases are generally classified as sales-type leases or operating leases.  Leases with business customers have fixed terms of generally two to four years.

[0001571996-24-000036:notes:131]
The Company also offers fixed-term loans to qualified small businesses, large commercial accounts, governmental organizations, educational entities, and certain individual consumer customers.  These loans are repaid in equal payments including interest and have defined terms of generally three to five years.  The fair value of the fixed-term loan portfolio is determined using market observable inputs.  The carrying value of these loans approximates fair value.

[0001571996-24-000036:notes:132]
Revolving loans — Revolving loans offered under a private label credit financing program,  referred to as Dell Business Credit (“DBC”), provide qualified customers with a revolving credit line for the purchase of products and services offered by Dell Technologies.  The DBC product is primarily offered to small and medium-sized commercial customers.  Revolving loans in the United States bear interest at a variable annual percentage rate that is tied to the prime rate.  Based on historical payment patterns, revolving loan transactions are typically repaid within twelve months on average.  Due to the short-term nature of the revolving loan portfolio, the carrying value of the portfolio approximates fair value.

[0001571996-24-000036:notes:133]
Prior to the sale of the U.S. consumer revolving customer receivables portfolio described in Note 1 of the Notes to the Consolidated Financial Statements, the Company also offered private label credit financing under the Dell Preferred Account (“DPA”) program.  The DPA product was primarily offered to individual consumer customers.

[0001571996-24-000036:notes:134]
Flexible consumption models, as defined above, further enable the Company to offer its customers the option to pay over time to provide them with financial and operational flexibility.  Such models may result in identification of embedded lease arrangements that lead to the recognition of operating or sales-type leases.

[0001571996-24-000036:notes:135]
Financing Receivables

[0001571996-24-000036:notes:136]
The following table presents the components of the Company’s financing receivables segregated by portfolio segment as of the dates indicated:

[0001571996-24-000036:notes:137]
|  | February 2, 2024 |  | February 3, 2023 |
|  | Revolving |  | Fixed-term |  | Total |  | Revolving |  | Fixed-term |  | Total |
|  | (in millions) |
| Financing receivables, net: |  |  |  |  |  |  |  |  |  |  |  |
| Customer receivables, gross (a) (b) | $ | 173 |  |  | $ | 10,360 |  |  | $ | 10,533 |  |  | $ | 685 |  |  | $ | 10,293 |  |  | $ | 10,978 |  |
| Allowances for losses | (9) |  |  | (161) |  |  | (170) |  |  | (88) |  |  | (113) |  |  | (201) |  |
| Customer receivables, net | 164 |  |  | 10,199 |  |  | 10,363 |  |  | 597 |  |  | 10,180 |  |  | 10,777 |  |
| Residual interest | — |  |  | 157 |  |  | 157 |  |  | — |  |  | 142 |  |  | 142 |  |
| Financing receivables, net | $ | 164 |  |  | $ | 10,356 |  |  | $ | 10,520 |  |  | $ | 597 |  |  | $ | 10,322 |  |  | $ | 10,919 |  |
| Short-term | $ | 164 |  |  | $ | 4,479 |  |  | $ | 4,643 |  |  | $ | 597 |  |  | $ | 4,684 |  |  | $ | 5,281 |  |
| Long-term | $ | — |  |  | $ | 5,877 |  |  | $ | 5,877 |  |  | $ | — |  |  | $ | 5,638 |  |  | $ | 5,638 |  |

[0001571996-24-000036:notes:138]
(a)    Customer receivables, gross include amounts due from customers under revolving loans, fixed-term loans, fixed-term leases, and accrued interest.

[0001571996-24-000036:notes:139]
(b)    The decrease in revolving customer financing receivables is primarily attributable to the sale of the U.S. consumer revolving customer receivables portfolio described in Note 1 of the Notes to the Consolidated Financial Statements.

[0001571996-24-000036:notes:140]
The following table presents the changes in allowance for financing receivables losses for the periods indicated:

[0001571996-24-000036:notes:141]
|  | Revolving |  | Fixed-term |  | Total |
|  | (in millions) |
| Allowance for financing receivables losses: |  |  |  |  |  |
| Balances as of January 29, 2021 | $ | 148 |  |  | $ | 173 |  |  | $ | 321 |  |
| Charge-offs, net of recoveries | (43) |  |  | (29) |  |  | (72) |  |
| Provision charged to income statement | (3) |  |  | (57) |  |  | (60) |  |
| Balances as of January 28, 2022 | 102 |  |  | 87 |  |  | 189 |  |
| Charge-offs, net of recoveries | (52) |  |  | (8) |  |  | (60) |  |
| Provision charged to income statement | 38 |  |  | 34 |  |  | 72 |  |
| Balances as of February 3, 2023 | 88 |  |  | 113 |  |  | 201 |  |
| Charge-offs, net of recoveries | (41) |  |  | (8) |  |  | (49) |  |
| Provision charged to income statement | 36 |  |  | 56 |  |  | 92 |  |
| Other (a) | (74) |  |  | — |  |  | (74) |  |
| Balances as of February 2, 2024 | $ | 9 |  |  | $ | 161 |  |  | $ | 170 |  |

[0001571996-24-000036:notes:142]
(a)    Other represents the derecognition of the allowance for financing receivables losses related to the sale of the U.S. consumer revolving customer receivables portfolio described in Note 1 of the Notes to the Consolidated Financial Statements.

[0001571996-24-000036:notes:143]
The Company recognizes an allowance for financing receivables losses, including both the lease receivable and unguaranteed residual, in an amount equal to the expected losses net of recoveries.  The allowance for financing receivables losses on the lease receivable is determined based on various factors, including lifetime expected losses determined using macroeconomic forecast assumptions and management judgments applicable to and through the expected life of the portfolios as well as past due receivables, receivable type, and customer risk profile.  The Company continues to monitor broader economic indicators and their potential impact on future credit loss performance.

[0001571996-24-000036:notes:144]
Aging

[0001571996-24-000036:notes:145]
The following table presents the aging of the Company’s customer financing receivables, gross, including accrued interest, segregated by class, as of the dates indicated:

[0001571996-24-000036:notes:146]
|  | February 2, 2024 |  | February 3, 2023 |
|  | Current |  | Past Due1 — 90 Days |  | Past Due>90 Days |  | Total |  | Current |  | Past Due1 — 90 Days |  | Past Due>90 Days |  | Total |
|  | (in millions) |
| Revolving — DPA | $ | 3 |  |  | $ | — |  |  | $ | — |  |  | $ | 3 |  |  | $ | 457 |  |  | $ | 34 |  |  | $ | 17 |  |  | $ | 508 |  |
| Revolving — DBC | 148 |  |  | 17 |  |  | 5 |  |  | 170 |  |  | 154 |  |  | 19 |  |  | 4 |  |  | 177 |  |
| Fixed-term — Consumer and Commercial | 9,345 |  |  | 889 |  |  | 126 |  |  | 10,360 |  |  | 9,309 |  |  | 927 |  |  | 57 |  |  | 10,293 |  |
| Total customer receivables, gross | $ | 9,496 |  |  | $ | 906 |  |  | $ | 131 |  |  | $ | 10,533 |  |  | $ | 9,920 |  |  | $ | 980 |  |  | $ | 78 |  |  | $ | 10,978 |  |

[0001571996-24-000036:notes:147]
Aging is likely to fluctuate as a result of the variability in volume of large transactions entered into over the period, and the administrative processes that accompany those transactions.  Aging is also impacted by the timing of the Company’s fiscal period end date relative to calendar month-end customer payment due dates.  As a result of these factors, fluctuations in aging from period to period do not necessarily indicate a material change in the collectibility of the portfolio.

[0001571996-24-000036:notes:148]
Fixed-term consumer and commercial customer receivables are placed on non-accrual status if principal or interest is past due and considered delinquent, or if there is concern about the collectibility of a specific customer receivable.  The receivables identified as doubtful for collectibility may be classified as current for aging purposes.  Aged revolving portfolio customer receivables identified as delinquent are charged off.

[0001571996-24-000036:notes:149]
Credit Quality

[0001571996-24-000036:notes:150]
The following tables present customer receivables, gross, including accrued interest, by credit quality indicator, segregated by class, as of the dates indicated:

[0001571996-24-000036:notes:151]
|  | February 2, 2024 |
|  | Fixed-term — Consumer and Commercial |  |  |  |  |  |  |
|  | Fiscal Year of Origination |  |  |  |  |  |  |
|  | 2024 |  | 2023 |  | 2022 |  | 2021 |  | 2020 |  | Years Prior |  | Revolving — DPA |  | Revolving — DBC |  | Total |
|  | (in millions) |
| Higher | $ | 3,261 |  |  | $ | 1,979 |  |  | $ | 833 |  |  | $ | 345 |  |  | $ | 64 |  |  | $ | — |  |  | $ | 1 |  |  | $ | 46 |  |  | $ | 6,529 |  |
| Mid | 1,111 |  |  | 911 |  |  | 290 |  |  | 86 |  |  | 19 |  |  | — |  |  | 1 |  |  | 49 |  |  | 2,467 |  |
| Lower | 703 |  |  | 469 |  |  | 187 |  |  | 80 |  |  | 21 |  |  | 1 |  |  | 1 |  |  | 75 |  |  | 1,537 |  |
| Total | $ | 5,075 |  |  | $ | 3,359 |  |  | $ | 1,310 |  |  | $ | 511 |  |  | $ | 104 |  |  | $ | 1 |  |  | $ | 3 |  |  | $ | 170 |  |  | $ | 10,533 |  |

[0001571996-24-000036:notes:152]
|  | February 3, 2023 |
|  | Fixed-term — Consumer and Commercial |  |  |  |  |  |  |
|  | Fiscal Year of Origination |  |  |  |  |  |  |
|  | 2023 |  | 2022 |  | 2021 |  | 2020 |  | 2019 |  | Years Prior |  | Revolving — DPA |  | Revolving — DBC |  | Total |
|  | (in millions) |
| Higher | $ | 3,210 |  |  | $ | 1,805 |  |  | $ | 914 |  |  | $ | 343 |  |  | $ | 37 |  |  | $ | 1 |  |  | $ | 123 |  |  | $ | 44 |  |  | $ | 6,477 |  |
| Mid | 1,242 |  |  | 631 |  |  | 362 |  |  | 119 |  |  | 17 |  |  | 1 |  |  | 136 |  |  | 54 |  |  | 2,562 |  |
| Lower | 1,017 |  |  | 364 |  |  | 157 |  |  | 65 |  |  | 7 |  |  | 1 |  |  | 249 |  |  | 79 |  |  | 1,939 |  |
| Total | $ | 5,469 |  |  | $ | 2,800 |  |  | $ | 1,433 |  |  | $ | 527 |  |  | $ | 61 |  |  | $ | 3 |  |  | $ | 508 |  |  | $ | 177 |  |  | $ | 10,978 |  |

[0001571996-24-000036:notes:153]
The categories shown in the tables above segregate customer receivables based on the relative degrees of credit risk.  Credit quality indicators for DBC revolving and fixed-term accounts are generally updated on a periodic basis.

[0001571996-24-000036:notes:154]
For the DBC revolving receivables and fixed-term commercial receivables shown in the table above, an internal grading system is utilized that assigns a credit level score based on a number of considerations, including liquidity, operating performance, and industry outlook.  The grading criteria and classifications for the fixed-term products differ from those for the revolving products as loss experience varies between these product and customer groups.  The credit quality categories cannot be compared between the different classes as loss experience varies substantially between the classes.  Prior to the sale of the U.S. consumer revolving customer receivables revolving portfolio described in Note 1 of the Notes to the Consolidated Financial Statements, the Company made credit decisions for the DPA revolving receivables based on proprietary scorecards, which included the customer’s credit history, payment history, credit usage, and other credit agency-related elements.  The higher quality category included prime accounts generally comparable to U.S. customer FICO scores of 720 or above.  The mid category represented mid-tier accounts that are comparable to U.S. customer FICO scores from 660 to 719.  The lower category represented accounts that are comparable to U.S. customer FICO scores below 660.

[0001571996-24-000036:notes:155]
Leases

[0001571996-24-000036:notes:156]
The following table presents amounts included in the Consolidated Statements of Income related to sales-type lease activity for the periods indicated:

[0001571996-24-000036:notes:157]
|  |  |  | Fiscal Year Ended |
|  |  |  |  |  | February 2, 2024 |  | February 3, 2023 |  | January 28, 2022 |
|  |  |  |  |  | (in millions) |
| Interest income — products |  |  |  |  | $ | 175 |  |  | $ | 161 |  |  | $ | 246 |  |
| Net revenue — products |  |  |  |  | $ | 1,140 |  |  | $ | 851 |  |  | $ | 756 |  |
| Cost of net revenue — products |  |  |  |  | 854 |  |  | 727 |  |  | 583 |  |
| Gross margin — products |  |  |  |  | $ | 286 |  |  | $ | 124 |  |  | $ | 173 |  |

[0001571996-24-000036:notes:158]
The following table presents the future maturity of the Company’s fixed-term customer leases and associated financing payments, and reconciles the undiscounted cash flows to the customer receivables, gross recognized on the Consolidated Statements of Financial Position as of the date indicated:

[0001571996-24-000036:notes:159]
|  | February 2, 2024 |
|  | (in millions) |
| Fiscal 2025 | $ | 2,579 |  |
| Fiscal 2026 | 1,944 |  |
| Fiscal 2027 | 1,129 |  |
| Fiscal 2028 | 414 |  |
| Fiscal 2029 and beyond | 153 |  |
| Total undiscounted cash flows | 6,219 |  |
| Fixed-term loans | 5,177 |  |
| Revolving loans | 173 |  |
| Less: Unearned income | (1,036) |  |
| Total customer receivables, gross | $ | 10,533 |  |

[0001571996-24-000036:notes:160]
Operating Leases

[0001571996-24-000036:notes:161]
The Company’s operating leases primarily consist of DFS captive fixed-term leases and contractually committed embedded leases identified within flexible consumption arrangements.

[0001571996-24-000036:notes:162]
The following table presents the components of the Company’s operating lease portfolio included in property, plant, and equipment, net as of the dates indicated:

[0001571996-24-000036:notes:163]
|  | February 2, 2024 |  | February 3, 2023 |
|  | (in millions) |
| Equipment under operating lease, gross | $ | 4,002 |  |  | $ | 3,725 |  |
| Less: Accumulated depreciation | (1,800) |  |  | (1,517) |  |
| Equipment under operating lease, net | $ | 2,202 |  |  | $ | 2,208 |  |

[0001571996-24-000036:notes:164]
The following table presents operating lease income related to lease payments and depreciation expense for the Company’s operating lease portfolio for the periods indicated:

[0001571996-24-000036:notes:165]
|  |  |  | Fiscal Year Ended |
|  |  |  |  |  | February 2, 2024 |  | February 3, 2023 |  | January 28, 2022 |
|  |  |  |  |  | (in millions) |
| Income related to lease payments |  |  |  |  | $ | 1,353 |  |  | $ | 1,091 |  |  | $ | 717 |  |
| Depreciation expense |  |  |  |  | $ | 941 |  |  | $ | 803 |  |  | $ | 536 |  |

[0001571996-24-000036:notes:166]
The following table presents the future payments to be received by the Company in operating lease contracts as of the date indicated:

[0001571996-24-000036:notes:167]
|  | February 2, 2024 |
|  | (in millions) |
| Fiscal 2025 | $ | 1,133 |  |
| Fiscal 2026 | 754 |  |
| Fiscal 2027 | 374 |  |
| Fiscal 2028 | 135 |  |
| Fiscal 2029 and beyond | 52 |  |
| Total | $ | 2,448 |  |

[0001571996-24-000036:notes:168]
DFS Debt

[0001571996-24-000036:notes:169]
The Company maintains programs that facilitate the funding of leases, loans, and other alternative payment structures in the capital markets.  The majority of DFS debt is non-recourse to Dell Technologies and represents borrowings under securitization programs and structured financing programs, for which the Company’s risk of loss is limited to transferred loan and lease payments and associated equipment.

[0001571996-24-000036:notes:170]
The following table presents DFS debt as of the dates indicated and excludes the allocated portion of the Company’s other borrowings, which represents the additional amount considered to fund the DFS business:

[0001571996-24-000036:notes:171]
|  | February 2, 2024 |  | February 3, 2023 |
| DFS debt | (in millions) |
| DFS U.S. debt: |  |  |  |
| Asset-based financing and securitization facilities | $ | 2,730 |  |  | $ | 3,987 |  |
| Fixed-term securitization offerings | 3,157 |  |  | 2,679 |  |
| Other | 28 |  |  | 76 |  |
| Total DFS U.S. debt | 5,915 |  |  | 6,742 |  |
| DFS international debt: |  |  |  |
| Securitization facility | 761 |  |  | 790 |  |
| Other borrowings | 935 |  |  | 871 |  |
| Note payable | 250 |  |  | 250 |  |
| Dell Bank senior unsecured eurobonds | 1,631 |  |  | 1,637 |  |
| Total DFS international debt | 3,577 |  |  | 3,548 |  |
| Total DFS debt | $ | 9,492 |  |  | $ | 10,290 |  |
| Total short-term DFS debt | $ | 5,863 |  |  | $ | 5,400 |  |
| Total long-term DFS debt | $ | 3,629 |  |  | $ | 4,890 |  |

[0001571996-24-000036:notes:172]
DFS U.S. Debt

[0001571996-24-000036:notes:173]
Asset-Based Financing and Securitization Facilities — The Company maintains separate asset-based financing facilities in the United States, which are revolving facilities for fixed-term leases and loans.  This debt is collateralized solely by the U.S. loan and lease payments and associated equipment in the facilities.  The debt has a variable interest rate, and the duration of the debt is based on the terms of the underlying loan and lease payment streams.  As of February 2, 2024, the total debt capacity related to the U.S. asset-based financing facilities was $5.1 billion.  The Company enters into interest swap agreements to effectively convert a portion of this debt from a floating rate to a fixed rate.  See Note 9 of the Notes to the Consolidated Financial Statements for additional information about the Company’s interest rate swaps.

[0001571996-24-000036:notes:174]
The Company’s two U.S. asset-based financing facilities for fixed-term leases and loans are effective through July 7, 2025 and June 21, 2024, respectively.  The asset-based financing facilities contain standard structural features related to the performance of the funded receivables, which include defined credit losses, delinquencies, average credit scores, and minimum collection requirements.  In the event one or more of these criteria are not met and the Company is unable to restructure the facility, no further funding of receivables will be permitted and the timing of the Company’s expected cash flows from over-collateralization will be delayed.  As of February 2, 2024, these criteria were met.

[0001571996-24-000036:notes:175]
The Company previously maintained a U.S. securitization facility for revolving loans.  In connection with the sale of the U.S. consumer revolving customer receivables portfolio described in Note 1 of the Notes to the Consolidated Financial Statements, the Company’s U.S. securitization facility for revolving loans was paid down and terminated during the fiscal year ended February 2, 2024.

[0001571996-24-000036:notes:176]
Fixed-Term Securitization Offerings — The Company periodically issues asset-backed debt securities under fixed-term securitization programs to private investors.  The asset-backed debt securities are collateralized solely by the U.S. fixed-term lease and loan payments and associated equipment, which are held by Special Purpose Entities (“SPEs”), as discussed below.  The interest rate on these securities is fixed and ranges from 0.53% to 6.80% per annum as of February 2, 2024, and the duration of these securities is based on the terms of the underlying lease and loan payment streams.

[0001571996-24-000036:notes:177]
DFS International Debt

[0001571996-24-000036:notes:178]
Securitization Facility — The Company maintains a securitization facility in Europe for fixed-term leases and loans.  The debt under this facility has a variable interest rate, and the duration of the debt is based on the terms of the underlying loan and lease payment streams.  This facility is effective through December 23, 2024 and had a total debt capacity of $870 million as of February 2, 2024.

[0001571996-24-000036:notes:179]
The securitization facility contains standard structural features related to the performance of the securitized receivables, which include defined credit losses, delinquencies, average credit scores, and minimum collection requirements.  In the event one or more of these criteria are not met and the Company is unable to restructure the program, no further funding of receivables will be permitted and the timing of the Company’s expected cash flows from over-collateralization will be delayed.  As of February 2, 2024, these criteria were met.

[0001571996-24-000036:notes:180]
Other Borrowings — In connection with the Company’s international financing operations, the Company has entered into revolving structured financing debt programs related to its fixed-term lease and loan products sold in Canada, Europe, Australia, New Zealand, and the Middle East.  The debt under these programs has a variable interest rate, and the duration of the debt is based on the terms of the underlying loan and lease payment streams.  The Canadian facility, which is collateralized solely by Canadian loan and lease payments and associated equipment, had a total debt capacity of $336 million as of February 2, 2024 and is effective through January 16, 2025.  The European facility, which is collateralized solely by European loan and lease payments and associated equipment, had a total debt capacity of $544 million as of February 2, 2024 and is effective through June 14, 2025.  The Australia and New Zealand facility, which is collateralized solely by Australia and New Zealand loan and lease payments and associated equipment, had a total debt capacity of $296 million as of February 2, 2024 and is effective through April 20, 2025.  The Middle East facility, which is collateralized solely by Middle East loan and lease payments and associated equipment, had a total debt capacity of $150 million as of February 2, 2024 and is effective through March 24, 2025.

[0001571996-24-000036:notes:181]
Note Payable — On May 25, 2022, the Company entered into an unsecured credit agreement to fund receivables in Mexico.  As of February 2, 2024, the aggregate principal amount of the note payable was $250 million.  The note bears interest at an annual rate of 4.24% and will mature on May 31, 2024.

[0001571996-24-000036:notes:182]
Dell Bank Senior Unsecured Eurobonds — On June 24, 2020, Dell Bank issued 500 million Euro of 1.625% senior unsecured four year eurobonds due June 2024.  On October 27, 2021, Dell Bank issued 500 million Euro of 0.5% senior unsecured five year eurobonds due October 2026.  On October 18, 2022, Dell Bank issued 500 million Euro of 4.5% senior unsecured five year eurobonds due October 2027.  The issuances of the senior unsecured eurobonds support the expansion of the financing operations in Europe.

[0001571996-24-000036:notes:183]
Variable Interest Entities

[0001571996-24-000036:notes:184]
In connection with the asset-based financing facilities, securitization facilities, and fixed-term securitization offerings discussed above, the Company transfers certain U.S. and European lease and loan payments and associated equipment to SPEs that meet the definition of a VIE and are consolidated, along with the associated debt described above, into the Consolidated Financial Statements, as the Company is the primary beneficiary of the VIEs.  The SPEs are bankruptcy-remote legal entities with separate assets and liabilities.  The purpose of the SPEs is to facilitate the funding of customer loan and lease payments and associated equipment in the capital markets.

[0001571996-24-000036:notes:185]
Some of the SPEs have entered into financing arrangements with multi-seller conduits that, in turn, issue asset-backed debt securities in the capital markets.  DFS debt outstanding held by the consolidated VIEs is collateralized by the lease and loan payments and associated equipment.  The Company’s risk of loss related to securitized receivables is limited to the amount by which the Company’s right to receive collections for assets securitized exceeds the amount required to pay interest, principal, and fees and expenses related to the asset-backed securities.  The Company provides credit enhancement to the securitization in the form of over-collateralization.

[0001571996-24-000036:notes:186]
The following table presents the assets and liabilities held by the consolidated VIEs as of the dates indicated, which are included in the Consolidated Statements of Financial Position:

[0001571996-24-000036:notes:187]
|  | February 2, 2024 |  | February 3, 2023 |
|  | (in millions) |
| Assets held by consolidated VIEs |  |  |  |
| Other current assets | $ | 136 |  |  | $ | 274 |  |
| Financing receivables, net of allowance |  |  |  |
| Short-term | $ | 3,314 |  |  | $ | 3,702 |  |
| Long-term | $ | 2,747 |  |  | $ | 3,295 |  |
| Property, plant, and equipment, net | $ | 1,081 |  |  | $ | 1,164 |  |
| Liabilities held by consolidated VIEs |  |  |  |
| Debt, net of unamortized debt issuance costs |  |  |  |
| Short-term | $ | 4,450 |  |  | $ | 4,761 |  |
| Long-term | $ | 2,184 |  |  | $ | 2,685 |  |

[0001571996-24-000036:notes:188]
Lease and loan payments and associated equipment transferred via securitization through SPEs were $4.6 billion and $6.2 billion for the fiscal years ended February 2, 2024 and February 3, 2023, respectively.

[0001571996-24-000036:notes:189]
Customer Receivables Sales

[0001571996-24-000036:notes:190]
To manage certain concentrations of customer credit exposure, the Company may sell selected fixed-term customer receivables to unrelated third parties on a periodic basis, without recourse.  The amount of customer receivables sold for this purpose was $222 million, $680 million, and $201 million for the fiscal years ended February 2, 2024, February 3, 2023, and January 28, 2022, respectively.  The Company’s continuing involvement in these customer receivables is primarily limited to servicing arrangements.


## us-gaap:ScheduleOfDebtTableTextBlock

[0001571996-24-000036:notes:191]
The following table summarizes the Company’s outstanding debt as of the dates indicated:

[0001571996-24-000036:notes:192]
|  | February 2, 2024 |  | February 3, 2023 |
|  | (in millions) |
| Senior Notes: |  |  |  |
| 5.45% due June 2023 | $ | — |  |  | $ | 1,000 |  |
| 4.00% due July 2024 | 1,000 |  |  | 1,000 |  |
| 5.85% due July 2025 | 1,000 |  |  | 1,000 |  |
| 6.02% due June 2026 | 3,500 |  |  | 4,500 |  |
| 4.90% due October 2026 | 1,750 |  |  | 1,750 |  |
| 6.10% due July 2027 | 500 |  |  | 500 |  |
| 5.25% due February 2028 | 1,000 |  |  | 1,000 |  |
| 5.30% due October 2029 | 1,750 |  |  | 1,750 |  |
| 6.20% due July 2030 | 750 |  |  | 750 |  |
| 5.75% due February 2033 | 1,000 |  |  | 1,000 |  |
| 8.10% due July 2036 | 1,000 |  |  | 1,000 |  |
| 3.38% due December 2041 | 962 |  |  | 1,000 |  |
| 8.35% due July 2046 | 650 |  |  | 800 |  |
| 3.45% due December 2051 | 745 |  |  | 1,250 |  |
| Legacy Notes and Debentures: |  |  |  |
| 7.10% due April 2028 | 300 |  |  | 300 |  |
| 6.50% due April 2038 | 388 |  |  | 388 |  |
| 5.40% due September 2040 | 264 |  |  | 264 |  |
| DFS Debt (Note 6) | 9,492 |  |  | 10,290 |  |
| Other | 171 |  |  | 325 |  |
| Total debt, principal amount | $ | 26,222 |  |  | $ | 29,867 |  |
| Unamortized discount, net of unamortized premium | (114) |  |  | (133) |  |
| Debt issuance costs | (114) |  |  | (146) |  |
| Total debt, carrying value | $ | 25,994 |  |  | $ | 29,588 |  |
| Total short-term debt, carrying value | $ | 6,982 |  |  | $ | 6,573 |  |
| Total long-term debt, carrying value | $ | 19,012 |  |  | $ | 23,015 |  |


## us-gaap:LesseeOperatingLeasesTextBlock

[0001571996-24-000036:notes:193]
LEASES 
The Company enters into leasing transactions in which the Company is the lessee.  These lease contracts are typically classified as operating leases.  The Company’s lease contracts are generally for office buildings used to conduct its business, and the determination of whether such contracts contain leases generally does not require significant estimates or judgments.  The Company also leases certain global logistics warehouses, employee vehicles, and equipment.  As of February 2, 2024, the remaining terms of the Company’s leases range from one month to approximately ten years.  As of February 2, 2024 and February 3, 2023, there were no material finance leases in which the Company was a lessee.

[0001571996-24-000036:notes:194]
The Company also enters into leasing transactions in which the Company is the lessor, primarily through customer financing arrangements offered through DFS.  DFS originates leases that are primarily classified as either sales-type leases or operating leases.  See Note 6 of the Notes to the Consolidated Financial Statements for more information about the Company’s lessor arrangements.

[0001571996-24-000036:notes:195]
The following table presents components of lease costs included in the Consolidated Statements of Income for the periods indicated:

[0001571996-24-000036:notes:196]
|  |  |  | Fiscal Year Ended |
|  |  |  |  |  | February 2, 2024 |  | February 3, 2023 |
|  |  |  |  |  | (in millions) |
| Operating lease costs |  |  |  |  | $ | 291 |  |  | $ | 283 |  |
| Variable costs |  |  |  |  | 80 |  |  | 113 |  |
| Total lease costs |  |  |  |  | $ | 371 |  |  | $ | 396 |  |

[0001571996-24-000036:notes:197]
During the fiscal years ended February 2, 2024 and February 3, 2023, sublease income, finance lease costs, and short-term lease costs were immaterial.

[0001571996-24-000036:notes:198]
The following table presents supplemental information related to operating leases included in the Consolidated Statements of Financial Position as of the dates indicated:

[0001571996-24-000036:notes:199]
|  | Classification |  | February 2, 2024 |  | February 3, 2023 |  |  |
|  |  |  | (in millions, except for term and discount rate) |
| Operating lease right-of-use assets | Other non-current assets |  | $ | 707 |  | $ | 725 |  |  |
| Current operating lease liabilities | Accrued and other current liabilities |  | $ | 253 |  | $ | 260 |  |  |
| Non-current operating lease liabilities | Other non-current liabilities |  | 576 |  | 630 |  |  |
| Total operating lease liabilities |  |  | $ | 829 |  | $ | 890 |  |  |
| Weighted-average remaining lease term (in years) |  |  | 4.56 |  | 4.95 |  |  |
| Weighted-average discount rate |  |  | 4.79 | % |  | 3.48 | % |  |  |

[0001571996-24-000036:notes:200]
The following table presents supplemental cash flow information related to leases for the periods indicated:

[0001571996-24-000036:notes:201]
|  | Fiscal Year Ended |
|  | February 2, 2024 |  | February 3, 2023 |
|  | (in millions) |
| Cash paid for amounts included in the measurement of lease liabilities — operating cash outflows from operating leases | $ | 300 |  |  | $ | 306 |  |
| Right-of-use assets obtained in exchange for new operating lease liabilities | $ | 247 |  |  | $ | 226 |  |

[0001571996-24-000036:notes:202]
The following table presents the future maturity of the Company’s operating lease liabilities under non-cancelable leases and reconciles the undiscounted cash flows for these leases to the lease liability recognized on the Consolidated Statements of Financial Position as of the date indicated:

[0001571996-24-000036:notes:203]
|  | February 2, 2024 |
|  | (in millions) |
| Fiscal 2025 | $ | 254 |  |
| Fiscal 2026 | 207 |  |
| Fiscal 2027 | 168 |  |
| Fiscal 2028 | 120 |  |
| Fiscal 2029 | 77 |  |
| Thereafter | 87 |  |
| Total lease payments | 913 |  |
| Less: Imputed interest | 84 |  |
| Total | $ | 829 |  |
| Current operating lease liabilities | $ | 253 |  |
| Non-current operating lease liabilities | $ | 576 |  |

[0001571996-24-000036:notes:204]
As of February 2, 2024, the Company’s undiscounted operating leases that had not yet commenced were immaterial.


## us-gaap:DebtDisclosureTextBlock

[0001571996-24-000036:notes:205]
DEBT
The following table summarizes the Company’s outstanding debt as of the dates indicated:

[0001571996-24-000036:notes:206]
During the fiscal year ended February 2, 2024, the net decrease in the Company’s debt balance was principally attributable to:

[0001571996-24-000036:notes:207]
•the repayment of $1.0 billion principal amount of the 5.45% Senior Notes due June 2023;

[0001571996-24-000036:notes:208]
•the repayment of $1.0 billion principal amount of the 6.02% Senior Notes due June 2026 in a tender offer; and

[0001571996-24-000036:notes:209]
•the repayment of $350 million principal amount of the 3.45% Senior Notes due December 2051 and $150 million principal amount of the 8.35% Senior Notes due July 2046 in a tender offer.

[0001571996-24-000036:notes:210]
The Company recognized an immaterial amount of debt extinguishment costs in interest and other, net in the Consolidated Statements of Income in connection with the above repayments.

[0001571996-24-000036:notes:211]
Subsequent to the close of the fiscal year ended February 2, 2024, the Company issued $1.0 billion aggregate principal amount of 5.40% Senior Notes due 2034.  The Company intends to use the net proceeds of the issuance to prepay a portion of the outstanding 6.02% Senior Notes due 2026.

[0001571996-24-000036:notes:212]
Outstanding Debt

[0001571996-24-000036:notes:213]
Senior Notes — The Company completed offerings of multiple series of senior notes which were issued on June 1, 2016, June 22, 2016, March 20, 2019, April 9, 2020, December 13, 2021, and January 24, 2023 in aggregate principal amounts of $20.0 billion, $3.3 billion, $4.5 billion, $2.3 billion, $2.3 billion, and $2.0 billion, respectively (the “Senior Notes”).  Interest on these borrowings is payable semiannually.

[0001571996-24-000036:notes:214]
Legacy Notes and Debentures — The Company has outstanding unsecured notes and debentures (collectively, the “Legacy Notes and Debentures”) that were issued by Dell Inc. (“Dell”), a wholly-owned subsidiary of Dell Technologies Inc., prior to the acquisition of Dell by Dell Technologies Inc. in the going-private transaction that closed in October 2013.  Interest on these borrowings is payable semiannually.

[0001571996-24-000036:notes:215]
DFS Debt — See Note 6 and Note 9 of the Notes to the Consolidated Financial Statements, respectively, for discussion of DFS debt and the interest rate swap agreements that hedge a portion of that debt.

[0001571996-24-000036:notes:216]
2021 Revolving Credit Facility — The Company’s revolving credit facility, which was entered into on November 1, 2021 (the “2021 Revolving Credit Facility”), matures on November 1, 2027.  This facility provides the Company with revolving commitments in an aggregate principal amount of $6.0 billion for general corporate purposes, including liquidity support for the Company’s commercial paper program, and includes a letter of credit sub-facility of up to $0.5 billion and a swing-line loan sub-facility of up to $0.5 billion.  The 2021 Revolving Credit Facility also allows the Company to obtain incremental additional commitments on one or more occasions in minimum amounts of $10 million.

[0001571996-24-000036:notes:217]
Borrowings under the 2021 Revolving Credit Facility bear interest at a rate per annum equal to an applicable margin plus, at the borrowers’ option, either (a) the specified adjusted term Secured Overnight Financing Rate (“SOFR”) or (b) a base rate.  The margin applicable to SOFR and base rate borrowings varies based upon the Company’s existing credit ratings.  The base rate is calculated based upon the greatest of the specified prime rate, the specified federal reserve bank rate, or SOFR plus 1%.  The borrowers may voluntarily repay outstanding loans under the 2021 Revolving Credit Facility at any time without premium or penalty, other than customary breakage costs.

[0001571996-24-000036:notes:218]
As of February 2, 2024, the Company had no outstanding borrowings under the 2021 Revolving Credit Facility.

[0001571996-24-000036:notes:219]
Commercial Paper Program — During Fiscal 2023, the Company established a commercial paper program under which the Company may issue unsecured notes in a maximum aggregate face amount of $5.0 billion outstanding at any time, with maturities up to 397 days from the date of issuance.  The notes are sold on customary terms in the U.S. commercial paper market on a private placement basis.  The proceeds of the notes are used for general corporate purposes.  As of February 2, 2024, the Company had no outstanding borrowings under the commercial paper program.

[0001571996-24-000036:notes:220]
The Company may purchase, redeem, prepay, refinance, or otherwise retire any amount of outstanding indebtedness under the terms of such indebtedness at any time and from time to time, in open market or negotiated transactions with the holders of such indebtedness or otherwise, as considered appropriate in light of market conditions and other relevant factors.

[0001571996-24-000036:notes:221]
Covenants — The credit agreement governing the 2021 Revolving Credit Facility and the indentures governing the Senior Notes and the Legacy Notes and Debentures impose various limitations, subject to exceptions, on creating certain liens and entering into sale and lease-back transactions.  The foregoing credit agreement and indentures contain customary events of default, including failure to make required payments, failure to comply with covenants, and the occurrence of certain events of bankruptcy and insolvency.  The 2021 Revolving Credit Facility is also subject to an interest coverage ratio covenant that is tested at the end of each fiscal quarter with respect to the Company’s preceding four fiscal quarters.  The Company was in compliance with this financial covenant as of February 2, 2024.

[0001571996-24-000036:notes:222]
Aggregate Future Maturities

[0001571996-24-000036:notes:223]
The following table presents the aggregate future maturities of the Company’s debt as of February 2, 2024 for the periods indicated:

[0001571996-24-000036:notes:224]
|  | Maturities by Fiscal Year |
|  | 2025 |  | 2026 |  | 2027 |  | 2028 |  | 2029 |  | Thereafter |  | Total |
|  | (in millions) |
| Senior Notes | $ | 1,000 |  |  | $ | 1,000 |  |  | $ | 5,250 |  |  | $ | 500 |  |  | $ | 1,000 |  |  | $ | 6,857 |  |  | $ | 15,607 |  |
| Legacy Notes and Debentures | — |  |  | — |  |  | — |  |  | — |  |  | 300 |  |  | 652 |  |  | 952 |  |
| DFS Debt | 5,863 |  |  | 2,127 |  |  | 878 |  |  | 618 |  |  | 6 |  |  | — |  |  | 9,492 |  |
| Other | 125 |  |  | 31 |  |  | 8 |  |  | 6 |  |  | 1 |  |  | — |  |  | 171 |  |
| Total maturities, principal amount | 6,988 |  |  | 3,158 |  |  | 6,136 |  |  | 1,124 |  |  | 1,307 |  |  | 7,509 |  |  | 26,222 |  |
| Associated carrying value adjustments | (6) |  |  | (6) |  |  | (33) |  |  | (8) |  |  | (14) |  |  | (161) |  |  | (228) |  |
| Total maturities, carrying value amount | $ | 6,982 |  |  | $ | 3,152 |  |  | $ | 6,103 |  |  | $ | 1,116 |  |  | $ | 1,293 |  |  | $ | 7,348 |  |  | $ | 25,994 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001571996-24-000036:notes:225]
DERIVATIVE INSTRUMENTS AND HEDGING ACTIVITIES 
As part of its risk management strategy, the Company uses derivative instruments, primarily foreign currency forward and option contracts and interest rate swaps, to hedge certain foreign currency and interest rate exposures, respectively.

[0001571996-24-000036:notes:226]
The Company’s objective is to offset gains and losses resulting from these exposures with gains and losses on the derivative contracts used to hedge the exposures, thereby reducing volatility of earnings and protecting the fair values of assets and liabilities.  The earnings effects of the derivative instruments are presented in the same income statement line items as the earnings effects of the hedged items.  For derivatives designated as cash flow hedges, the Company assesses hedge effectiveness both at the onset of the hedge and at regular intervals throughout the life of the instruments.  For derivatives designated as fair value hedges, the Company assesses hedge effectiveness on qualifying instruments using the shortcut method whereby the hedges are considered perfectly effective at the onset of the hedge and over the life of the hedging relationship.

[0001571996-24-000036:notes:227]
Foreign Exchange Risk

[0001571996-24-000036:notes:228]
The Company uses foreign currency forward and option contracts designated as cash flow hedges to protect against the foreign currency exchange rate risks inherent in its forecasted transactions denominated in currencies other than the U.S. Dollar.  Hedge accounting is applied based upon the criteria established by accounting guidance for derivative instruments and hedging activities.  The risk of loss associated with purchased options is limited to premium amounts paid for the option contracts.  The risk of loss associated with forward contracts is equal to the exchange rate differential from the time the contract is entered into until the time it is settled.  The majority of these contracts typically expire in twelve months or less.

[0001571996-24-000036:notes:229]
During the fiscal years ended February 2, 2024, February 3, 2023, and January 28, 2022, the Company did not discontinue any cash flow hedges related to foreign exchange contracts that had a material impact on the Company’s results of operations due to the probability that the forecasted cash flows would not occur.

[0001571996-24-000036:notes:230]
The Company uses forward contracts to hedge monetary assets and liabilities denominated in a foreign currency.  These contracts generally expire in three months or less, are considered economic hedges, and are not designated for hedge accounting.  The change in the fair value of these instruments represents a natural hedge as their gains and losses offset the changes in the underlying fair value of the monetary assets and liabilities due to movements in currency exchange rates.

[0001571996-24-000036:notes:231]
In connection with DFS operations in Europe, forward contracts are used to hedge financing receivables denominated in foreign currencies other than Euro.  These contracts are not designated for hedge accounting and most expire within three years or less.

[0001571996-24-000036:notes:232]
Interest Rate Risk

[0001571996-24-000036:notes:233]
The Company uses interest rate swaps to hedge the variability in cash flows related to the interest rate payments on structured financing debt.  The interest rate swaps economically convert the variable rate on the structured financing debt to a fixed interest rate to match the underlying fixed rate being received on fixed-term customer leases and loans.  These contracts are not designated for hedge accounting and most expire within four years or less.

[0001571996-24-000036:notes:234]
Interest rate swaps are utilized to manage the interest rate risk, at a portfolio level, associated with DFS operations in Europe.  The interest rate swaps economically convert the fixed rate on financing receivables to a three-month Euribor floating rate in order to match the floating rate nature of the banks’ funding pool.  The Company also uses interest rate swaps to manage the cash flows related to interest payments on Eurobonds.  The interest rate swaps economically convert the fixed rate on the Company’s bonds to a floating rate to match the underlying lease repayments profile.  These contracts are not designated for hedge accounting and most expire within five years or less.

[0001571996-24-000036:notes:235]
The Company utilizes cross-currency amortizing swaps to hedge the currency and interest rate risk exposure associated with the European securitization program.  The cross-currency swaps combine a Euro-based interest rate swap with a British Pound or U.S. Dollar foreign exchange forward contract in which the Company pays a fixed or floating British Pound or U.S. Dollar amount and receives a fixed or floating amount in Euros linked to the one-month Euribor.  The notional value of the swaps amortizes in line with the expected cash flows and run-off of the securitized assets.  The swaps are not designated for hedge accounting and expire within five years or less.

[0001571996-24-000036:notes:236]
Periodically, the Company also uses interest rate swaps to modify the market risk exposures in connection with long-term debt.  During Fiscal 2023, the Company entered into interest rate swaps designated as fair value hedges intended to hedge a portion of its interest rate exposure by converting the fixed interest rate of a certain tranche of debt to a floating interest rate based on the benchmark SOFR Overnight Index Swap rate.  The gains and losses related to changes in the fair value of such interest rate swaps perfectly offset changes in the fair value of the hedged portion of the underlying debt that were attributable to the changes in the underlying benchmark interest rate.  During the fiscal year ended February 2, 2024, the Company repaid the hedged debt and terminated the associated interest rate swaps.

[0001571996-24-000036:notes:237]
Derivative Instruments

[0001571996-24-000036:notes:238]
The following table presents the notional amounts of outstanding derivative instruments as of the dates indicated:

[0001571996-24-000036:notes:239]
|  | February 2, 2024 |  | February 3, 2023 |
|  | (in millions) |
| Foreign exchange contracts: |  |  |  |
| Designated as cash flow hedging instruments | $ | 6,339 |  |  | $ | 7,746 |  |
| Non-designated as hedging instruments | 5,844 |  |  | 6,833 |  |
| Total | $ | 12,183 |  |  | $ | 14,579 |  |
| Interest rate contracts: |  |  |  |
| Designated as fair value hedging instruments | $ | — |  |  | $ | 1,000 |  |
| Non-designated as hedging instruments | 6,551 |  |  | 7,214 |  |
| Total | $ | 6,551 |  |  | $ | 8,214 |  |

[0001571996-24-000036:notes:240]
The following table presents the effect of derivative instruments designated as cash flow hedging instruments on the Consolidated Statements of Financial Position and the Consolidated Statements of Income for the periods indicated:

[0001571996-24-000036:notes:241]
| Derivatives in Cash Flow Hedging Relationships |  | Gain Recognized in Accumulated OCI, Net of Tax, on Derivatives |  | Location of Gain (Loss) Reclassified from Accumulated OCI into Income |  | Gain (Loss) Reclassified from Accumulated OCI into Income |
|  |  | (in millions) |  |  |  | (in millions) |
| For the fiscal year ended February 2, 2024: |
|  |  |  |  | Total net revenue |  | $ | (98) |  |
| Foreign exchange contracts |  | $ | 85 |  |  | Total cost of net revenue |  | (9) |  |
| Total |  | $ | 85 |  |  | Total |  | $ | (107) |  |
| For the fiscal year ended February 3, 2023: |
|  |  |  |  | Total net revenue |  | $ | 736 |  |
| Foreign exchange contracts |  | $ | 354 |  |  | Total cost of net revenue |  | (31) |  |
| Total |  | $ | 354 |  |  | Total |  | $ | 705 |  |
| For the fiscal year ended January 28, 2022: |
|  |  |  |  | Total net revenue |  | $ | 158 |  |
| Foreign exchange contracts |  | $ | 374 |  |  | Total cost of net revenue |  | (3) |  |
| Total |  | $ | 374 |  |  | Income from discontinued operations |  | 3 |  |
|  |  |  |  | Total |  | $ | 158 |  |

[0001571996-24-000036:notes:242]
The following table presents the effect of derivative instruments not designated as hedging instruments on the Consolidated Statements of Income for the periods indicated:

[0001571996-24-000036:notes:243]
|  | Fiscal Year Ended |  |  |
|  | February 2, 2024 |  | February 3, 2023 |  |  |  |  |  | January 28, 2022 |  | Location of Gain (Loss) Recognized |
|  | (in millions) |  |  |
| Foreign exchange contracts | $ | (35) |  |  | $ | (174) |  |  |  |  |  |  | $ | (469) |  |  | Interest and other, net |
| Interest rate contracts | — |  |  | 50 |  |  |  |  |  |  | 10 |  |  | Interest and other, net |
| Foreign exchange contracts | — |  |  | — |  |  |  |  |  |  | 26 |  |  | Income from discontinued operations |
| Total | $ | (35) |  |  | $ | (124) |  |  |  |  |  |  | $ | (433) |  |  |  |

[0001571996-24-000036:notes:244]
The Company presents its derivative instruments on a net basis in the Consolidated Statements of Financial Position due to the right of offset by its counterparties under master netting arrangements.  The following tables present the fair value of those derivative instruments presented on a gross basis as of the dates indicated:

[0001571996-24-000036:notes:245]
|  | February 2, 2024 |
|  | Other CurrentAssets |  | Other Non-Current Assets |  | Other Current Liabilities |  | Other Non-CurrentLiabilities |  | TotalFair Value |
|  | (in millions) |
| Derivatives designated as hedging instruments: |
| Foreign exchange contracts in an asset position | $ | 44 |  |  | $ | — |  |  | $ | 19 |  |  | $ | — |  |  | $ | 63 |  |
| Foreign exchange contracts in a liability position | (5) |  |  | — |  |  | (15) |  |  | — |  |  | (20) |  |
| Interest rate contracts in an asset position | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Interest rate contracts in a liability position | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Net asset (liability) | 39 |  |  | — |  |  | 4 |  |  | — |  |  | 43 |  |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts in an asset position | 90 |  |  | — |  |  | 71 |  |  | — |  |  | 161 |  |
| Foreign exchange contracts in a liability position | (68) |  |  | — |  |  | (121) |  |  | — |  |  | (189) |  |
| Interest rate contracts in an asset position | 3 |  |  | 40 |  |  | — |  |  | — |  |  | 43 |  |
| Interest rate contracts in a liability position | — |  |  | — |  |  | (10) |  |  | (28) |  |  | (38) |  |
| Net asset (liability) | 25 |  |  | 40 |  |  | (60) |  |  | (28) |  |  | (23) |  |
| Total derivatives at fair value | $ | 64 |  |  | $ | 40 |  |  | $ | (56) |  |  | $ | (28) |  |  | $ | 20 |  |
|  | February 3, 2023 |
|  | Other CurrentAssets |  | Other Non-Current Assets |  | Other Current Liabilities |  | Other Non-CurrentLiabilities |  | TotalFair Value |
|  | (in millions) |
| Derivatives designated as hedging instruments: |
| Foreign exchange contracts in an asset position | $ | 7 |  |  | $ | — |  |  | $ | 30 |  |  | $ | — |  |  | $ | 37 |  |
| Foreign exchange contracts in a liability position | (21) |  |  | — |  |  | (142) |  |  | — |  |  | (163) |  |
| Interest rate contracts in an asset position | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Interest rate contracts in a liability position | — |  |  | — |  |  | — |  |  | (6) |  |  | (6) |  |
| Net asset (liability) | (14) |  |  | — |  |  | (112) |  |  | (6) |  |  | (132) |  |
| Derivatives not designated as hedging instruments: |
| Foreign exchange contracts in an asset position | 282 |  |  | 1 |  |  | 368 |  |  | — |  |  | 651 |  |
| Foreign exchange contracts in a liability position | (121) |  |  | — |  |  | (614) |  |  | (1) |  |  | (736) |  |
| Interest rate contracts in an asset position | 14 |  |  | 133 |  |  | — |  |  | — |  |  | 147 |  |
| Interest rate contracts in a liability position | — |  |  | — |  |  | — |  |  | (95) |  |  | (95) |  |
| Net asset (liability) | 175 |  |  | 134 |  |  | (246) |  |  | (96) |  |  | (33) |  |
| Total derivatives at fair value | $ | 161 |  |  | $ | 134 |  |  | $ | (358) |  |  | $ | (102) |  |  | $ | (165) |  |

[0001571996-24-000036:notes:246]
The following tables present the gross amounts of the Company’s derivative instruments, amounts offset due to master netting agreements with the Company’s counterparties, and the net amounts recognized in the Consolidated Statements of Financial Position as of the dates indicated:

[0001571996-24-000036:notes:247]
|  | February 2, 2024 |
|  | Gross Amounts of Recognized Assets/ (Liabilities) |  | Gross Amounts Offset in the Statement of Financial Position |  | Net Amounts of Assets/(Liabilities) Presented in the Statement of Financial Position |  | Gross Amounts not Offset in the Statement of Financial Position |  | Net Amount of Assets/ (Liabilities) Recognized in the Statement of Financial Position |
|  | Financial Instruments |  | Cash Collateral Received or Pledged |  |
|  | (in millions) |
| Derivative instruments: |  |  |  |  |  |  |  |  |  |  |  |
| Financial assets | $ | 267 |  |  | $ | (163) |  |  | $ | 104 |  |  | $ | — |  |  | $ | (24) |  |  | $ | 80 |  |
| Financial liabilities | (247) |  |  | 163 |  |  | (84) |  |  | — |  |  | 9 |  |  | (75) |  |
| Total derivative instruments | $ | 20 |  |  | $ | — |  |  | $ | 20 |  |  | $ | — |  |  | $ | (15) |  |  | $ | 5 |  |
|  | February 3, 2023 |
|  | Gross Amounts of Recognized Assets/ (Liabilities) |  | Gross Amounts Offset in the Statement of Financial Position |  | Net Amounts of Assets/(Liabilities) Presented in the Statement of Financial Position |  | Gross Amounts not Offset in the Statement of Financial Position |  | Net Amount of Assets/ (Liabilities) Recognized in the Statement of Financial Position |
|  | Financial Instruments |  | Cash Collateral Received or Pledged |  |
|  | (in millions) |
| Derivative instruments: |  |  |  |  |  |  |  |  |  |  |  |
| Financial assets | $ | 835 |  |  | $ | (540) |  |  | $ | 295 |  |  | $ | — |  |  | $ | — |  |  | $ | 295 |  |
| Financial liabilities | (1,000) |  |  | 540 |  |  | (460) |  |  | — |  |  | 25 |  |  | (435) |  |
| Total derivative instruments | $ | (165) |  |  | $ | — |  |  | $ | (165) |  |  | $ | — |  |  | $ | 25 |  |  | $ | (140) |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001571996-24-000036:notes:248]
GOODWILL AND INTANGIBLE ASSETS
Goodwill

[0001571996-24-000036:notes:249]
The Infrastructure Solutions Group and Client Solutions Group reporting units are consistent with the reportable segments identified in Note 19 of the Notes to the Consolidated Financial Statements.  Other businesses consists of VMware Resale, Secureworks, and Virtustream, which each represent separate reporting units.

[0001571996-24-000036:notes:250]
The following table presents goodwill allocated to the Company’s reportable segments and changes in the carrying amount of goodwill as of the dates indicated:

[0001571996-24-000036:notes:251]
|  | Infrastructure Solutions Group |  | Client Solutions Group |  | Other Businesses |  | Total |
|  | (in millions) |
| Balances as of February 3, 2023 | $ | 15,017 |  |  | $ | 4,232 |  |  | $ | 427 |  |  | $ | 19,676 |  |
| Goodwill acquired (a) | 77 |  |  | — |  |  | — |  |  | 77 |  |
| Impact of foreign currency translation and other | (53) |  |  | — |  |  | — |  |  | (53) |  |
| Balances as of February 2, 2024 | $ | 15,041 |  |  | $ | 4,232 |  |  | $ | 427 |  |  | $ | 19,700 |  |

[0001571996-24-000036:notes:252]
(a)    Goodwill acquired represents goodwill recognized in connection with the Company’s acquisition of Moogsoft Inc. during the fiscal year ended February 2, 2024.

[0001571996-24-000036:notes:253]
Intangible Assets

[0001571996-24-000036:notes:254]
The following table presents the Company’s intangible assets as of the dates indicated:

[0001571996-24-000036:notes:255]
|  | February 2, 2024 |  | February 3, 2023 |
|  | Gross |  | AccumulatedAmortization |  | Net |  | Gross |  | AccumulatedAmortization |  | Net |
|  | (in millions) |
| Customer relationships | $ | 16,968 |  |  | $ | (14,930) |  |  | $ | 2,038 |  |  | $ | 16,956 |  |  | $ | (14,474) |  |  | $ | 2,482 |  |
| Developed technology | 9,506 |  |  | (8,980) |  |  | 526 |  |  | 9,466 |  |  | (8,660) |  |  | 806 |  |
| Trade names | 875 |  |  | (823) |  |  | 52 |  |  | 875 |  |  | (780) |  |  | 95 |  |
| Definite-lived intangible assets | 27,349 |  |  | (24,733) |  |  | 2,616 |  |  | 27,297 |  |  | (23,914) |  |  | 3,383 |  |
| Indefinite-lived trade names | 3,085 |  |  | — |  |  | 3,085 |  |  | 3,085 |  |  | — |  |  | 3,085 |  |
| Total intangible assets | $ | 30,434 |  |  | $ | (24,733) |  |  | $ | 5,701 |  |  | $ | 30,382 |  |  | $ | (23,914) |  |  | $ | 6,468 |  |

[0001571996-24-000036:notes:256]
Amortization expense related to definite-lived intangible assets was $0.8 billion, $1.0 billion, and $1.6 billion  for the fiscal years ended February 2, 2024,  February 3, 2023, and January 28, 2022, respectively. There were no material impairment charges related to intangible assets during the fiscal years ended February 2, 2024, February 3, 2023, and January 28, 2022.

[0001571996-24-000036:notes:257]
The following table presents the estimated future annual pre-tax amortization expense of definite-lived intangible assets as of the date indicated:

[0001571996-24-000036:notes:258]
|  | February 2, 2024 |
|  | (in millions) |
| Fiscal 2025 | $ | 654 |  |
| Fiscal 2026 | 495 |  |
| Fiscal 2027 | 386 |  |
| Fiscal 2028 | 230 |  |
| Fiscal 2029 | 190 |  |
| Thereafter | 661 |  |
| Total | $ | 2,616 |  |

[0001571996-24-000036:notes:259]
Goodwill and Indefinite-Lived Intangible Assets Impairment Testing

[0001571996-24-000036:notes:260]
Goodwill and indefinite-lived intangible assets are tested for impairment annually during the third fiscal quarter and whenever events or circumstances may indicate that an impairment has occurred.

[0001571996-24-000036:notes:261]
For the annual impairment review of the Infrastructure Solutions Group (“ISG”) and Client Solutions Group (“CSG”) reporting units during the third quarter of Fiscal 2024, the Company elected to bypass the assessment of qualitative factors to determine whether it was more likely than not that the fair value of a reporting unit was less than its carrying amount, including goodwill.  In electing to bypass the qualitative assessment, the Company proceeded directly to perform a quantitative goodwill impairment test to measure the fair value of each goodwill reporting unit relative to its carrying amount, and to determine the amount of goodwill impairment loss to be recognized, if any.  For the remaining reporting units, the Company performed a qualitative assessment of goodwill at the reporting unit level.  The qualitative assessment included consideration of the relevant events and circumstances affecting the reporting unit, including macroeconomic, industry and market conditions, overall financial performance, and trends in the public company market valuation, where applicable.

[0001571996-24-000036:notes:262]
Management exercised significant judgment related to the above assessments, including the identification of goodwill reporting units, assignment of assets and liabilities to goodwill reporting units, assignment of goodwill to reporting units, and determination of the fair value of each goodwill reporting unit.  For the quantitative goodwill impairment test, the fair value of each goodwill reporting unit is generally estimated using a combination of public company multiples and discounted cash flow methodologies.  The discounted cash flow and public company multiples methodologies require significant judgment, including estimation of future revenues, gross margins, and operating expenses, which are dependent on internal forecasts, current and anticipated economic conditions and trends, selection of market multiples through assessment of the reporting unit’s performance relative to peer competitors, the estimation of the long-term revenue growth rate and discount rate of the Company’s business, and the determination of the Company’s weighted average cost of capital.  Changes in these estimates and assumptions could materially affect the fair value of the goodwill reporting unit, potentially resulting in a non-cash impairment charge.

[0001571996-24-000036:notes:263]
The fair value of the indefinite-lived trade names is generally estimated using discounted cash flow methodologies.  These methodologies require significant judgment, including estimation of future revenue, the estimation of the long-term revenue growth rate of the Company’s business and the determination of the Company’s weighted average cost of capital and royalty rates.  Changes in these estimates and assumptions could materially affect the fair value of the indefinite-lived intangible assets, potentially resulting in a non-cash impairment charge.

[0001571996-24-000036:notes:264]
Based on the results of the annual impairment test performed during the fiscal year ended February 2, 2024, the fair values of each of the reporting units and indefinite-lived intangibles exceeded their carrying values.  No goodwill or indefinite-lived assets impairment test was performed during the fiscal year ended February 2, 2024 other than the Company’s annual impairment review.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001571996-24-000036:notes:265]
DEFERRED REVENUE 
Deferred revenue consists of support and deployment services, software maintenance, training, Software-as-a-Service, and undelivered hardware and professional services, consisting of installations and consulting engagements.  Deferred revenue is recorded when the Company has invoiced or payments have been received for undelivered products or services where transfer of control has not occurred.  Revenue is recognized as the Company’s performance obligations under the contract are completed.

[0001571996-24-000036:notes:266]
The following table presents the changes in the Company’s deferred revenue for the periods indicated:

[0001571996-24-000036:notes:267]
|  |  |  | Fiscal Year Ended |
|  |  |  |  |  | February 2, 2024 |  | February 3, 2023 |
|  |  |  |  |  | (in millions) |
| Deferred revenue: |  |  |  |  |  |  |  |
| Deferred revenue at beginning of period |  |  |  |  | $ | 30,286 |  |  | $ | 27,573 |  |
| Revenue deferrals |  |  |  |  | 20,866 |  |  | 23,166 |  |
| Revenue recognized |  |  |  |  | (22,022) |  |  | (20,288) |  |
| Other (a) |  |  |  |  | 15 |  |  | (165) |  |
| Deferred revenue at end of period |  |  |  |  | $ | 29,145 |  |  | $ | 30,286 |  |
| Short-term deferred revenue |  |  |  |  | $ | 15,318 |  |  | $ | 15,542 |  |
| Long-term deferred revenue |  |  |  |  | $ | 13,827 |  |  | $ | 14,744 |  |

[0001571996-24-000036:notes:268]
(a)    For the fiscal year ended February 3, 2023, Other represents the reclassification of deferred revenue to accrued and other liabilities.

[0001571996-24-000036:notes:269]
Remaining Performance Obligations — Remaining performance obligations represent the aggregate amount of the transaction price allocated to performance obligations not delivered, or partially undelivered, as of the end of the reporting period.  Remaining performance obligations include deferred revenue plus unbilled amounts not yet recorded in deferred revenue.  The value of the transaction price allocated to remaining performance obligations as of February 2, 2024 was approximately $40 billion.  The Company expects to recognize approximately 58% of remaining performance obligations as revenue in the next twelve months, and the remainder thereafter.

[0001571996-24-000036:notes:270]
The aggregate amount of the transaction price allocated to remaining performance obligations does not include amounts owed under cancelable contracts where there is no substantive termination penalty.  The Company applied the practical expedient to exclude the value of remaining performance obligations for contracts for which revenue is recognized at the amount to which the Company has the right to invoice for services performed.

[0001571996-24-000036:notes:271]
Remaining performance obligation estimates are subject to change and are affected by several factors, including terminations, changes in the scope of contracts, periodic revalidation, adjustments for revenue that have not materialized, and adjustments for currency.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001571996-24-000036:notes:272]
COMMITMENTS AND CONTINGENCIES 
Purchase Obligations

[0001571996-24-000036:notes:273]
The Company has contractual obligations to purchase goods or services, which specify significant terms (including fixed or minimum quantities to be purchased), fixed, minimum, or variable price provisions, and the approximate timing of the transaction.  As of February 2, 2024, such purchase obligations were $4.4 billion for Fiscal 2025; $0.3 billion for Fiscal 2026; and $0.3 billion for Fiscal 2027 and thereafter.

[0001571996-24-000036:notes:274]
Legal Matters

[0001571996-24-000036:notes:275]
The Company is involved in various claims, suits, assessments, investigations, and legal proceedings that arise from time to time in the ordinary course of its business, including those identified below, consisting of matters involving consumer, antitrust, tax, intellectual property, and other issues on a global basis.

[0001571996-24-000036:notes:276]
The Company accrues a liability when it believes that it is both probable that a liability has been incurred and that it can reasonably estimate the amount of the loss.  The Company reviews these accruals at least quarterly and adjusts them to reflect ongoing negotiations, settlements, rulings, advice of legal counsel, and other relevant information.  To the extent new information is obtained and the Company’s views on the probable outcomes of claims, suits, assessments, investigations, or legal proceedings change, changes in the Company’s accrued liabilities are recorded in the period in which such a determination is made.  For some matters, the incurrence of a liability is not probable or the amount cannot be reasonably estimated and therefore accruals have not been made.

[0001571996-24-000036:notes:277]
The following is a discussion of the Company’s significant legal matters and other proceedings:

[0001571996-24-000036:notes:278]
Class Actions Related to the Class V Transaction — On December 28, 2018, the Company completed a transaction (the “Class V transaction”) in which it paid $14.0 billion in cash and issued 149,387,617 shares of its Class C Common Stock to holders of its Class V Common Stock in exchange for all outstanding shares of Class V Common Stock.  As a result of the Class V transaction, the tracking stock feature of the Company’s capital structure associated with the Class V Common Stock was terminated.  Certain stockholders of the Company, subsequently brought class action complaints arising out of the Class V transaction in which they named as defendants (collectively, the “defendants”) Michael S. Dell and certain other directors serving on the Company’s board of directors at the time of the Class V transaction (collectively, the “director defendants”), certain stockholders of the Company, consisting of Mr. Dell and Silver Lake Group LLC and certain of its affiliated funds (collectively, the “stockholder defendants”), and Goldman Sachs & Co. LLC (“Goldman Sachs”), which served as financial advisor to the Company in connection with the transaction.  The plaintiffs generally alleged that the director defendants and the stockholder defendants breached their fiduciary duties under Delaware law to the former holders of the Class V Common Stock in connection with the Class V transaction by offering a transaction value that was allegedly billions of dollars below fair value.

[0001571996-24-000036:notes:279]
As previously reported, during the fourth quarter of the fiscal year ended February 3, 2023, the plaintiffs and the defendants entered into an agreement to settle the lawsuit.  Under the terms of the settlement, the plaintiffs agreed to the dismissal of all claims upon payment of a total of $1.0 billion (the “settlement amount”), which includes all costs, expenses and fees of the plaintiff class relating to the action and its resolution.  The settlement terms required that the settlement amount be paid by the Company and/or the Company’s insurers pursuant to indemnification obligations of the Company to the defendants.  The Company is subject to indemnification obligations, upon the satisfaction of specified conditions, to the director and stockholder defendants and their affiliates pursuant to provisions of the Delaware General Corporation Law, the Company’s certificate of incorporation and bylaws, and agreements with the defendants.  A special committee of the Board of Directors consisting of directors who were not defendants in the action, advised by independent counsel, informed the Board of Directors of its determination that the defendants were entitled to indemnification under the foregoing obligations.

[0001571996-24-000036:notes:280]
During the fiscal year ended February 3, 2023, the Company established a $1.0 billion liability on the Consolidated Statements of Financial Position and recognized $0.9 billion expense, net of $106 million in insurance proceeds, within interest and other, net within the Consolidated Statements of Income related to the settlement agreement.

[0001571996-24-000036:notes:281]
On May 16, 2023, during the fiscal year ended February 2, 2024, the Company paid the settlement amount following approval of the settlement by the Delaware Court of Chancery.  The payment is reflected within cash flows from operating activities within the Consolidated Statements of Cash Flows.

[0001571996-24-000036:notes:282]
R2 Semiconductor Patent Litigation — In November 2022, R2 Semiconductor, Inc. (“R2”) filed a lawsuit in the Dusseldorf Regional Court in Germany against Intel Deutschland GmbH, Dell GmbH, and certain other customers of Intel Corporation.  R2 asserted that one European patent is infringed by certain Intel processors and those of the Company’s products that incorporate those processors (the “Accused Products”).  R2 sought an injunction prohibiting the sale of the allegedly infringing products and damages for the alleged infringement.  The Dusseldorf Regional Court (the “Court”) conducted a trial on December 7, 2023, and, on February 7, 2024, issued a decision in favor of R2.  The Court’s judgment imposes an injunction prohibiting (among other acts) the sale and use of the Accused Products in Germany by Dell GmbH, and requiring Dell GmbH to issue a communication to certain customers recalling the covered products sold since March 5, 2020.  These orders will not take effect until after notice of R2’s payment of the sureties required for enforcement and will remain in place unless stayed or overturned on appeal or until the parties reach an agreement.  On February 8, 2024, the Company filed an appeal which is in process with the appellate court.  The Court has not yet assessed damages arising out of R2’s claim.  Intel Corporation has agreed to defend and indemnify the Company and its affiliates against certain losses incurred by the Company in connection with the alleged infringement.  Given the status of this lawsuit, the nature of the case, and the Company’s agreements with Intel Corporation, the Company is unable to make a reasonable estimate of the potential loss or range of losses that might arise from the lawsuit.

[0001571996-24-000036:notes:283]
Other Litigation — Dell does not currently anticipate that any of the other various legal proceedings it is involved in will have a material adverse effect on its business, financial condition, results of operations, or cash flows.

[0001571996-24-000036:notes:284]
In accordance with the relevant accounting guidance, the Company provides disclosures of matters where it is at least reasonably possible that the Company could experience a material loss exceeding the amounts already accrued for these or other proceedings or matters.  In addition, the Company also discloses matters based on its consideration of other matters and qualitative factors, including the experience of other companies in the industry, and investor, customer, and employee relations considerations.  As of February 2, 2024, the Company does not believe there is a reasonable possibility that a material loss exceeding the amounts already accrued for these or other proceedings or matters has been incurred.  However, since the ultimate resolution of any such proceedings and matters is inherently unpredictable, the Company’s business, financial condition, results of operations, or cash flows could be materially affected in any particular period by unfavorable outcomes in one or more of these proceedings or matters.  Whether the outcome of any claim, suit, assessment, investigation, or legal proceeding, individually or collectively, could have a material adverse effect on the Company’s business, financial condition, results of operations, or cash flows will depend on a number of factors, including the nature, timing, and amount of any associated expenses, amounts paid in settlement, damages, or other remedies or consequences.

[0001571996-24-000036:notes:285]
Indemnifications Obligations

[0001571996-24-000036:notes:286]
In the ordinary course of business, the Company enters into various contracts under which it may agree to indemnify other parties for losses incurred from certain events as defined in the relevant contract, such as litigation, regulatory penalties, or claims relating to past performance.  Such indemnification obligations may not be subject to maximum loss clauses.  Historically, payments related to these indemnification obligations have not been material to the Company.

[0001571996-24-000036:notes:287]
Under the Separation and Distribution Agreement entered into with VMware, Inc., (currently known as VMware LLC after its conversion into a Delaware limited liability company), upon the completion of the VMware Spin-off on November 1, 2021, Dell Technologies agreed to indemnify VMware, Inc., each of its subsidiaries and each of their respective directors, officers, employees, as well as any successors and assigns of the foregoing, from and against all liabilities relating to, arising out of or resulting from, among other matters, the liabilities allocated to Dell Technologies as part of the separation of Dell Technologies and VMware, Inc. (individually and together with its subsidiaries, “VMware”) and their respective businesses (the “Separation”).  VMware similarly agreed to indemnify Dell Technologies Inc., each of its subsidiaries and each of their respective directors, officers, and employees from and against all liabilities relating to, arising out of or resulting from, among other matters, the liabilities allocated to VMware as part of the Separation.

[0001571996-24-000036:notes:288]
For information on the cross-indemnifications related to the tax matters agreement between the Company and VMware effective upon the Separation on November 1, 2021, see Note 20 of the Notes to the Consolidated Financial Statements.

[0001571996-24-000036:notes:289]
Certain Concentrations

[0001571996-24-000036:notes:290]
The Company maintains cash and cash equivalents, derivatives, and certain other financial instruments with various financial institutions that potentially subject it to concentration of credit risk.  As part of its risk management processes, the Company performs periodic evaluations of the relative credit standing of these financial institutions.  The Company has not sustained material credit losses from instruments held at these financial institutions.  Further, the Company does not anticipate nonperformance by any of the counterparties.

[0001571996-24-000036:notes:291]
The Company markets and sells its products and services to large corporate clients, governmental agencies, and health care and education accounts, as well as to small and medium-sized businesses and individuals.  No single customer accounted for more than 10% of the Company’s consolidated net revenue during the fiscal year ended February 2, 2024, February 3, 2023, and January 28, 2022.

[0001571996-24-000036:notes:292]
The Company utilizes a limited number of contract manufacturers that assemble a portion of its products.  The Company purchases components from suppliers and sells those components to such contract manufacturers.  The Company reflects the sale of such components by recognizing non-trade receivables from the contract manufacturers and a reduction in inventory when title and risk of loss pass to the manufacturer.  Cash flows related to such transactions are recorded within cash flows from operating activities.  The Company does not reflect the sale of the components in revenue and does not recognize any profit on the component sales until the related products are sold to a customer.
The agreements with the majority of the contract manufacturers permit the Company to offset its payables against the receivables, thus mitigating the credit risk wholly or in part.  Such receivables were $3.4 billion and $3.3 billion as of February 2, 2024 and February 3, 2023, respectively, and primarily consisted of receivables from the Company’s four largest contract manufacturers.  The Company offset its corresponding payables against $2.7 billion and $2.5 billion of such receivables as of February 2, 2024 and February 3, 2023, respectively.  The portion of receivables not offset is included in other current assets in the Consolidated Statements of Financial Position.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001571996-24-000036:notes:293]
INCOME AND OTHER TAXES
The following table presents components of the income tax expense (benefit) for continuing operations recognized for the periods indicated:

[0001571996-24-000036:notes:294]
|  | Fiscal Year Ended |
|  | February 2, 2024 |  | February 3, 2023 |  | January 28, 2022 |
|  | (in millions) |
| Current: |  |  |  |  |  |
| Federal | $ | 149 |  |  | $ | 605 |  |  | $ | 166 |  |
| State/local | 33 |  |  | 176 |  |  | 76 |  |
| Foreign | 601 |  |  | 739 |  |  | 960 |  |
| Current | 783 |  |  | 1,520 |  |  | 1,202 |  |
| Deferred: |  |  |  |  |  |
| Federal | (106) |  |  | (483) |  |  | (54) |  |
| State/local | (42) |  |  | (103) |  |  | — |  |
| Foreign | 57 |  |  | (131) |  |  | (167) |  |
| Deferred | (91) |  |  | (717) |  |  | (221) |  |
| Income tax expense | $ | 692 |  |  | $ | 803 |  |  | $ | 981 |  |

[0001571996-24-000036:notes:295]
The following table presents components of income (loss) before income taxes for continuing operations for the periods indicated:

[0001571996-24-000036:notes:296]
|  | Fiscal Year Ended |
|  | February 2, 2024 |  | February 3, 2023 |  | January 28, 2022 |
|  | (in millions) |
| Domestic | $ | (52) |  |  | $ | (1,316) |  |  | $ | 1,414 |  |
| Foreign | 3,939 |  |  | 4,541 |  |  | 4,509 |  |
| Income before income taxes | $ | 3,887 |  |  | $ | 3,225 |  |  | $ | 5,923 |  |

[0001571996-24-000036:notes:297]
The following table presents a reconciliation of the Company’s effective tax rate to the statutory U.S. federal tax rate for continuing operations for the periods indicated:

[0001571996-24-000036:notes:298]
|  | Fiscal Year Ended |
|  | February 2, 2024 |  | February 3, 2023 |  | January 28, 2022 |
| U.S. federal statutory rate | 21.0 | % |  | 21.0 | % |  | 21.0 | % |
| State income taxes, net of federal tax benefit | (0.2) |  |  | 2.0 |  |  | 1.7 |  |
| Tax impact of foreign operations | 2.7 |  |  | (0.8) |  |  | (0.3) |  |
| Change in valuation allowance | 0.3 |  |  | 0.4 |  |  | 0.4 |  |
| Non-deductible transaction-related costs | — |  |  | 0.8 |  |  | 1.2 |  |
| Stock-based compensation expense | (0.9) |  |  | (2.4) |  |  | (2.4) |  |
| U.S. R&D tax credits | (4.6) |  |  | (2.6) |  |  | (1.3) |  |
| Legal entity restructuring | — |  |  | — |  |  | (4.1) |  |
| Class V transaction litigation settlement | — |  |  | 5.8 |  |  | — |  |
| Other | (0.5) |  |  | 0.7 |  |  | 0.4 |  |
| Total | 17.8 | % |  | 24.9 | % |  | 16.6 | % |

[0001571996-24-000036:notes:299]
Changes related to the Company’s effective tax rates for the fiscal years ended February 2, 2024, February 3, 2023, and January 28, 2022 were primarily driven by items discrete to those years.  Additionally, the Company’s effective tax rate for the fiscal year ended February 2, 2024 as compared to the fiscal year ended February 3, 2023 reflected the tax impact of foreign operations and benefits from U.S. research and development tax credits.  The Company’s effective tax rate for the fiscal year ended February 3, 2023 includes the impact of a $0.9 billion expense recognized in connection with the agreement to settle the Class V transaction litigation described in Note 12 of the Notes to the Consolidated Financial Statements.  The Company’s effective tax rate for the fiscal year ended January 28, 2022 includes tax expense of $1.0 billion on a pre-tax gain of $4.0 billion related to the divestiture of Boomi during the period, as well as tax benefits of $367 million on $1.6 billion of debt extinguishment fees and $244 million related to the restructuring of certain legal entities.

[0001571996-24-000036:notes:300]
The differences between the effective income tax rates and the U.S. federal statutory rate of 21% principally result from the geographical distribution of income, differences between the book and tax treatment of certain items, and discrete tax items.  In certain jurisdictions, the Company’s tax rate is significantly less than the applicable statutory rate as a result of tax holidays.  The majority of the Company’s foreign income subject to these tax holidays and lower tax rates is attributable to Singapore and China.  A significant portion of these income tax benefits relates to a tax holiday that will be effective until January 31, 2029.  Most of the Company’s other tax holidays will expire in whole or in part during fiscal years 2030 and 2031.  Many of these tax holidays and reduced tax rates may be extended when certain conditions are met or may be terminated early if certain conditions are not met or as a result of changes in tax legislation.  As of February 2, 2024, the Company was not aware of any matters of non-compliance related to these tax holidays or enacted tax legislative changes affecting these tax holidays.  For the fiscal years ended February 2, 2024, February 3, 2023, and January 28, 2022, the income tax benefits attributable to the tax status of the affected subsidiaries were estimated to be approximately $244 million ($0.33 per share), $123 million ($0.16 per share), and $466 million ($0.59 per share), respectively.  These income tax benefits are included in tax impact of foreign operations in the table above.

[0001571996-24-000036:notes:301]
As of February 2, 2024, the Company has undistributed earnings of certain foreign subsidiaries of approximately $36.4 billion that remain indefinitely reinvested, and as such has not recognized a deferred tax liability.  Determination of the amount of unrecognized deferred income tax liability related to these undistributed earnings is not practicable.  The Company believes that a significant portion of the Company’s undistributed earnings as of February 2, 2024 will not be subject to further U.S. federal taxation.

[0001571996-24-000036:notes:302]
The following table presents the components of the Company’s net deferred tax assets (liabilities) as of the dates indicated:

[0001571996-24-000036:notes:303]
|  | February 2, 2024 |  | February 3, 2023 |
|  | (in millions) |
| Deferred tax assets: |  |  |  |
| Deferred revenue and warranty provisions | $ | 1,878 |  |  | $ | 1,959 |  |
| Credit carryforwards | 554 |  |  | 938 |  |
| Loss carryforwards | 619 |  |  | 467 |  |
| Operating and compensation related accruals | 478 |  |  | 506 |  |
| Capitalized research and development | 302 |  |  | 263 |  |
| Other (a) | 320 |  |  | 417 |  |
| Deferred tax assets (b) | 4,151 |  |  | 4,550 |  |
| Valuation allowance | (1,232) |  |  | (1,535) |  |
| Deferred tax assets, net of valuation allowance | 2,919 |  |  | 3,015 |  |
| Deferred tax liabilities: |  |  |  |
| Leasing and financing | (397) |  |  | (363) |  |
| Property and equipment | (377) |  |  | (470) |  |
| Intangibles | (338) |  |  | (483) |  |
| Other | (375) |  |  | (339) |  |
| Deferred tax liabilities (b) | (1,487) |  |  | (1,655) |  |
| Net deferred tax assets | $ | 1,432 |  |  | $ | 1,360 |  |

[0001571996-24-000036:notes:304]
(a)    As of February 2, 2024, the Company elected to present provisions for product returns and doubtful accounts within Other.  Prior period balances have been recast to conform to this presentation.

[0001571996-24-000036:notes:305]
(b)    Deferred tax assets and deferred tax liabilities are included in other non-current assets and other non-current liabilities, respectively, in the Consolidated Statements of Financial Position.

[0001571996-24-000036:notes:306]
The following tables present the net operating loss carryforwards, tax credit carryforwards, and other deferred tax assets with related valuation allowances recognized as of the dates indicated:

[0001571996-24-000036:notes:307]
|  | February 2, 2024 |  |  |
|  | Deferred Tax Assets |  | Valuation Allowance |  | Net Deferred Tax Assets |  | First Year Expiring |
|  | (in millions) |  |  |
| Credit carryforwards | $ | 554 |  |  | $ | (549) |  |  | $ | 5 |  |  | Fiscal 2025 |
| Loss carryforwards | 619 |  |  | (405) |  |  | 214 |  |  | Fiscal 2025 |
| Other deferred tax assets | 2,978 |  |  | (278) |  |  | 2,700 |  |  | NA |
| Total | $ | 4,151 |  |  | $ | (1,232) |  |  | $ | 2,919 |  |  |  |
|  | February 3, 2023 |  |  |
|  | Deferred Tax Assets |  | Valuation Allowance |  | Net Deferred Tax Assets |  | First Year Expiring |
|  | (in millions) |  |  |
| Credit carryforwards | $ | 938 |  |  | $ | (935) |  |  | $ | 3 |  |  | Fiscal 2024 |
| Loss carryforwards | 467 |  |  | (317) |  |  | 150 |  |  | Fiscal 2024 |
| Other deferred tax assets | 3,145 |  |  | (283) |  |  | 2,862 |  |  | NA |
| Total | $ | 4,550 |  |  | $ | (1,535) |  |  | $ | 3,015 |  |  |  |

[0001571996-24-000036:notes:308]
The Company’s credit carryforwards as of February 2, 2024 and February 3, 2023 relate primarily to U.S. tax credits and include state and federal tax credits associated with research and development, as well as foreign tax credits associated with the U.S. Tax Cuts and Jobs Act.  The Company assessed the realizability of these U.S. tax credits and has recorded a valuation allowance against the credits it does not expect to utilize.  The decrease in credit carryforwards and corresponding valuation allowance for the fiscal year ended February 2, 2024 was primarily attributable to changes in the determination of foreign tax credits associated with the U.S. Tax Cuts and Jobs Act.  These credit carryforwards were not previously expected to be utilized and had a full valuation allowance.  Accordingly, such changes had no impact on the Company’s effective tax rate.  The Company’s loss carryforwards as of February 2, 2024 and February 3, 2023 include net operating loss carryforwards from federal, state, and foreign jurisdictions.  The valuation allowances for other deferred tax assets as of February 2, 2024 and February 3, 2023 primarily relate to foreign jurisdictions, the changes in which are included in tax impact of foreign operations in the Company’s effective tax reconciliation.  The Company has determined that it will be able to realize the remainder of its deferred tax assets.

[0001571996-24-000036:notes:309]
The following table presents the changes in the valuation allowance for deferred tax assets for the periods indicated:

[0001571996-24-000036:notes:310]
|  | Fiscal Year Ended |
|  | February 2, 2024 |  | February 3, 2023 |  | January 28, 2022 |
|  | (in millions) |
| Balance at beginning of period | $ | 1,535 |  |  | $ | 1,423 |  |  | $ | 1,297 |  |
| Charged to income tax provision | (299) |  |  | 84 |  |  | 155 |  |
| Charged to other accounts | (4) |  |  | 28 |  |  | (29) |  |
| Balance at end of period | $ | 1,232 |  |  | $ | 1,535 |  |  | $ | 1,423 |  |

[0001571996-24-000036:notes:311]
The following table presents a reconciliation of the Company’s beginning and ending balances of unrecognized tax benefits for the periods indicated:

[0001571996-24-000036:notes:312]
|  | Fiscal Year Ended |
|  | February 2, 2024 |  | February 3, 2023 |  | January 28, 2022 |
|  | (in millions) |
| Beginning Balance | $ | 1,812 |  |  | $ | 1,595 |  |  | $ | 1,620 |  |
| Increases related to tax positions of the current year | 4 |  |  | 132 |  |  | 113 |  |
| Increases related to tax position of prior years | 828 |  |  | 181 |  |  | 143 |  |
| Reductions for tax positions of prior years | (177) |  |  | (46) |  |  | (153) |  |
| Lapse of statute of limitations | (35) |  |  | (41) |  |  | (78) |  |
| Audit settlements | (65) |  |  | (9) |  |  | (50) |  |
| Ending Balance | $ | 2,367 |  |  | $ | 1,812 |  |  | $ | 1,595 |  |

[0001571996-24-000036:notes:313]
The table above does not include accrued interest and penalties of $394 million as of both February 2, 2024 and February 3, 2023, and $383 million as of January 28, 2022.  Additionally, the table does not include certain tax benefits associated with interest and state tax deductions and other indirect jurisdictional effects of uncertain tax positions, which were $1,438 million, $910 million, and $817 million as of February 2, 2024, February 3, 2023, and January 28, 2022, respectively.

[0001571996-24-000036:notes:314]
After taking these items into account, the Company’s net unrecognized tax benefits were $1.3 billion as of February 2, 2024 and February 3, 2023, and $1.2 billion as of January 28, 2022, and are included in other non-current liabilities in the Consolidated Statements of Financial Position.

[0001571996-24-000036:notes:315]
The unrecognized tax benefits in the table above include $1.2 billion, $1.1 billion, and $0.9 billion as of February 2, 2024, February 3, 2023, and January 28, 2022, respectively, that, if recognized, would have impacted income tax expense.  Interest and penalties related to income tax liabilities are included in income tax expense.  The impact of interest and penalties on the Company’s tax provision was immaterial for the fiscal years ended February 2, 2024, February 3, 2023, and January 28, 2022.

[0001571996-24-000036:notes:316]
In June 2023, the Company received Revenue Agent’s Reports for the examination by the Internal Revenue Service (“IRS”) of fiscal years 2015 through 2017 and fiscal years 2018 through 2019.  The Company agreed with the IRS assessments relating to fiscal years 2015 through 2017 and settled those positions in August 2023.  The impact to the financial statements for that settlement was not material.  For fiscal years 2018 through 2019, the IRS proposed adjustments primarily relating to certain transactions the Company completed as part of its business integration efforts, with which the Company disagrees and which it will contest through the IRS administrative appeals procedures.  In August 2023, the Company submitted a written protest to the IRS relating to certain assessments.  The Company anticipates that the appeals process for the resolution of these matters will extend beyond the next twelve months.  In September 2023, the IRS commenced a federal income tax examination of fiscal years 2020 through 2022.

[0001571996-24-000036:notes:317]
The Company is also currently under income tax audits in various U.S. state and foreign taxing jurisdictions.  The Company is undergoing negotiations, and in some cases contested proceedings, relating to tax matters with the taxing authorities in these jurisdictions.  With respect to major U.S. state and foreign taxing jurisdictions, the Company is generally not subject to tax examinations for years prior to the fiscal year ended January 29, 2010.  The Company believes that it has provided adequate reserves related to all matters contained in tax periods open to examination, including the IRS audits described above.  Although the Company believes it has made adequate provisions for the uncertainties with respect to these audits, should the Company experience unfavorable outcomes, such outcomes could have a material impact on its results of operations, financial position, and cash flows.

[0001571996-24-000036:notes:318]
Judgment is required in evaluating the Company’s uncertain tax positions and determining the Company’s provision for income taxes.  Although the timing of resolution or closure of uncertain tax positions is not certain, the Company believes it is reasonably possible that certain tax matters in various jurisdictions could be concluded within the next twelve months.  The resolution of these matters could reduce the Company’s unrecognized tax benefits by up to $0.4 billion including interest and penalties.  Such a reduction would have a material impact on the Company’s effective tax rate.

[0001571996-24-000036:notes:319]
The Company takes certain non-income tax positions in the jurisdictions in which it operates and has received certain non-income tax assessments from various jurisdictions.  The Company believes that a material loss in these matters is not probable and that it is not reasonably possible that a material loss exceeding amounts already accrued has been incurred.  The Company believes its positions in these non-income tax litigation matters are supportable and that it ultimately will prevail in the matters.  In the normal course of business, the Company’s positions and conclusions related to its non-income taxes could be challenged and assessments may be made.  To the extent new information is obtained and the Company’s views on its positions, probable outcomes of assessments, or litigation change, changes in estimates to the Company’s accrued liabilities would be recorded in the period in which such a determination is made.  In the resolution process for income tax and non-income tax audits, the Company is required in certain situations to provide collateral guarantees or indemnification to regulators and tax authorities until the matter is resolved.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001571996-24-000036:notes:320]
ACCUMULATED OTHER COMPREHENSIVE INCOME (LOSS) 
Accumulated other comprehensive income (loss) is presented in stockholders’ equity (deficit) in the Consolidated Statements of Financial Position and consists of amounts related to foreign currency translation adjustments, unrealized net gains (losses) on cash flow hedges, and actuarial net gains (losses) from pension and other postretirement plans.

[0001571996-24-000036:notes:321]
The following table presents changes in accumulated other comprehensive income (loss), net of tax, by the following components as of the dates indicated:

[0001571996-24-000036:notes:322]
|  | Foreign Currency Translation Adjustments |  |  |  | Cash Flow Hedges |  | Pension and Other Postretirement Plans |  | Accumulated Other Comprehensive Income (Loss) |
|  | (in millions) |
| Balances as of January 29, 2021 | $ | (150) |  |  |  |  | $ | (86) |  |  | $ | (78) |  |  | $ | (314) |  |
| Other comprehensive income (loss) before reclassifications | (385) |  |  |  |  | 374 |  |  | 37 |  |  | 26 |  |
| Amounts reclassified from accumulated other comprehensive income (loss) | — |  |  |  |  | (158) |  |  | 7 |  |  | (151) |  |
| Spin-off of VMware | 9 |  |  |  |  | (1) |  |  | — |  |  | 8 |  |
| Total change for the period | (376) |  |  |  |  | 215 |  |  | 44 |  |  | (117) |  |
| Balances as of January 28, 2022 | $ | (526) |  |  |  |  | $ | 129 |  |  | $ | (34) |  |  | $ | (431) |  |
| Other comprehensive income (loss) before reclassifications | (222) |  |  |  |  | 354 |  |  | 1 |  |  | 133 |  |
| Amounts reclassified from accumulated other comprehensive income (loss) | — |  |  |  |  | (705) |  |  | 1 |  |  | (704) |  |
| Total change for the period | (222) |  |  |  |  | (351) |  |  | 2 |  |  | (571) |  |
| Less: Change in comprehensive loss attributable to non-controlling interests | (1) |  |  |  |  | — |  |  | — |  |  | (1) |  |
| Balances as of February 3, 2023 | $ | (747) |  |  |  |  | $ | (222) |  |  | $ | (32) |  |  | $ | (1,001) |  |
| Other comprehensive income (loss) before reclassifications | (8) |  |  |  |  | 85 |  |  | 15 |  |  | 92 |  |
| Amounts reclassified from accumulated other comprehensive income (loss) | — |  |  |  |  | 107 |  |  | 2 |  |  | 109 |  |
| Total change for the period | (8) |  |  |  |  | 192 |  |  | 17 |  |  | 201 |  |
| Balances as of February 2, 2024 | $ | (755) |  |  |  |  | $ | (30) |  |  | $ | (15) |  |  | $ | (800) |  |

[0001571996-24-000036:notes:323]
Amounts related to the Company’s cash flow hedges are reclassified to net income during the same period in which the items being hedged are recognized in earnings.  See Note 9 of the Notes to the Consolidated Financial Statements for more information about the Company’s derivative instruments.

[0001571996-24-000036:notes:324]
The following table presents reclassifications out of accumulated other comprehensive income (loss), net of tax, to net income for the periods indicated:

[0001571996-24-000036:notes:325]
|  |  |  | Fiscal Year Ended |
|  |  |  | February 2, 2024 |  | February 3, 2023 |  | January 28, 2022 |
|  |  |  | Cash Flow Hedges |  |  |  |  |  | Pensions |  |  |  | Total |  | Cash Flow Hedges |  | Pensions |  | Total |  | Cash Flow Hedges |  | Pensions |  | Total |
|  |  |  | (in millions) |
| Total reclassifications, net of tax: |  |  |  |  |  |  |  |  |  |  |  |  |
| Net revenue |  |  | $ | (98) |  |  |  |  |  |  | $ | — |  |  |  |  | $ | (98) |  |  | $ | 736 |  |  | $ | — |  |  | $ | 736 |  |  | $ | 158 |  |  | $ | — |  |  | $ | 158 |  |
| Cost of net revenue |  |  | (9) |  |  |  |  |  |  | — |  |  |  |  | (9) |  |  | (31) |  |  | — |  |  | (31) |  |  | (3) |  |  | — |  |  | (3) |  |
| Operating expenses |  |  | — |  |  |  |  |  |  | (2) |  |  |  |  | (2) |  |  | — |  |  | (1) |  |  | (1) |  |  | — |  |  | (7) |  |  | (7) |  |
| Income from discontinued operations |  |  | — |  |  |  |  |  |  | — |  |  |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 3 |  |  | — |  |  | 3 |  |
| Total reclassifications, net of tax |  |  | $ | (107) |  |  |  |  |  |  | $ | (2) |  |  |  |  | $ | (109) |  |  | $ | 705 |  |  | $ | (1) |  |  | $ | 704 |  |  | $ | 158 |  |  | $ | (7) |  |  | $ | 151 |  |


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001571996-24-000036:notes:326]
CAPITALIZATION 
The following table presents the Company’s authorized, issued, and outstanding common stock as of the dates indicated:

[0001571996-24-000036:notes:327]
|  | Authorized |  | Issued |  | Outstanding |
|  | (in millions) |
| Common stock as of February 2, 2024 |
| Class A | 600 |  |  | 353 |  |  | 353 |  |
| Class B | 200 |  |  | 86 |  |  | 86 |  |
| Class C | 7,900 |  |  | 382 |  |  | 266 |  |
| Class D | 100 |  |  | — |  |  | — |  |
|  | 8,800 |  |  | 821 |  |  | 705 |  |
| Common stock as of February 3, 2023 |
| Class A | 600 |  |  | 379 |  |  | 379 |  |
| Class B | 200 |  |  | 95 |  |  | 95 |  |
| Class C | 7,900 |  |  | 324 |  |  | 242 |  |
| Class D | 100 |  |  | — |  |  | — |  |
|  | 8,800 |  |  | 798 |  |  | 716 |  |

[0001571996-24-000036:notes:328]
Preferred Stock

[0001571996-24-000036:notes:329]
The Company is authorized to issue one million shares of preferred stock, par value $0.01 per share.  As of February 2, 2024 and February 3, 2023, no shares of preferred stock were issued or outstanding.

[0001571996-24-000036:notes:330]
Common Stock

[0001571996-24-000036:notes:331]
Dell Technologies Common Stock — The Class A Common Stock, the Class B Common Stock, the Class C Common Stock, and the Class D Common Stock are collectively referred to as Dell Technologies Common Stock.  The par value for all series of Dell Technologies Common Stock is $0.01 per share.  The Class A Common Stock, the Class B Common Stock, the Class C Common Stock, and the Class D Common Stock share equally in dividends declared or accumulated and have equal participation rights in undistributed earnings.

[0001571996-24-000036:notes:332]
Voting Rights — Each holder of record of (a) Class A Common Stock is entitled to ten votes per share of Class A Common Stock; (b) Class B Common Stock is entitled to ten votes per share of Class B Common Stock; (c) Class C Common Stock is entitled to one vote per share of Class C Common Stock; and (d) Class D Common Stock is not entitled to any vote on any matter except to the extent required by provisions of Delaware law (in which case such holder is entitled to one vote per share of Class D Common Stock).

[0001571996-24-000036:notes:333]
Conversion Rights — Under the Company’s certificate of incorporation, at any time and from time to time, any holder of Class A Common Stock or Class B Common Stock has the right to convert all or any of the shares of Class A Common Stock or Class B Common Stock, as applicable, held by such holder into shares of Class C Common Stock on a one-to-one basis.

[0001571996-24-000036:notes:334]
During the fiscal year ended February 2, 2024, the Company issued 34 million shares of Class C Common Stock to stockholders upon the conversion of 25 million shares of Class A Common Stock and 9 million shares of Class B Common Stock in accordance with the Company’s certificate of incorporation.

[0001571996-24-000036:notes:335]
During the fiscal year ended February 3, 2023, there were no conversions of shares of Class A Common Stock or Class B Common Stock into shares of Class C Common Stock.

[0001571996-24-000036:notes:336]
During the fiscal year ended January 28, 2022, the Company issued an aggregate of 6 million shares of Class C Common Stock to stockholders upon their conversion of the same number of shares of Class A Common Stock into Class C Common Stock in accordance with the Company’s certificate of incorporation.

[0001571996-24-000036:notes:337]
Dividends

[0001571996-24-000036:notes:338]
On February 24, 2022, the Company announced that the Board of Directors adopted a dividend policy providing for payment of quarterly cash dividends on the Dell Technologies Common Stock.

[0001571996-24-000036:notes:339]
The Company paid the following dividends during the periods presented:

[0001571996-24-000036:notes:340]
|  |  | Declaration Date |  | Record Date |  | Payment Date |  | Dividend per Share |  | Amount (in millions) |
|  |  | Fiscal 2024 |
|  |  | March 2, 2023 |  | April 25, 2023 |  | May 5, 2023 |  | $ | 0.37 |  |  | $ | 270 |  |
|  |  | June 16, 2023 |  | July 25, 2023 |  | August 4, 2023 |  | $ | 0.37 |  |  | $ | 268 |  |
|  |  | September 28, 2023 |  | October 24, 2023 |  | November 3, 2023 |  | $ | 0.37 |  |  | $ | 266 |  |
|  |  | December 5, 2023 |  | January 23, 2024 |  | February 2, 2024 |  | $ | 0.37 |  |  | $ | 261 |  |
|  |  | Fiscal 2023 |
|  |  | February 24, 2022 |  | April 20, 2022 |  | April 29, 2022 |  | $ | 0.33 |  |  | $ | 248 |  |
|  |  | June 7, 2022 |  | July 20, 2022 |  | July 29, 2022 |  | $ | 0.33 |  |  | $ | 242 |  |
|  |  | September 6, 2022 |  | October 19, 2022 |  | October 28, 2022 |  | $ | 0.33 |  |  | $ | 238 |  |
|  |  | December 6, 2022 |  | January 25, 2023 |  | February 3, 2023 |  | $ | 0.33 |  |  | $ | 236 |  |

[0001571996-24-000036:notes:341]
During the fiscal year ended February 2, 2024, the Company also paid an immaterial amount of dividend equivalents on eligible vested equity awards which are not included above.

[0001571996-24-000036:notes:342]
On February 29, 2024, subsequent to the close of the fiscal year ended February 2, 2024, the Company announced that the Board of Directors approved a 20% increase in the dividend to a rate of $0.445 per share per fiscal quarter beginning in the first quarter of the fiscal year ending January 31, 2025.

[0001571996-24-000036:notes:343]
Repurchases of Common Stock

[0001571996-24-000036:notes:344]
Effective as of September 23, 2021, the Company’s Board of Directors approved a stock repurchase program under which the Company is authorized to repurchase up to $5 billion of shares of Class C Common Stock with no fixed expiration date.

[0001571996-24-000036:notes:345]
Effective as of October 5, 2023, the Company’s Board of Directors approved the repurchase of an additional $5 billion of shares of the Company’s Class C Common Stock under the stock repurchase program.  Following the approval, the Company had approximately $5.7 billion in authorized amount remaining under the program.

[0001571996-24-000036:notes:346]
During the fiscal year ended February 2, 2024, the Company repurchased approximately 34 million shares of Class C Common Stock for a total purchase price of approximately $2.1 billion.  During the fiscal year ended February 3, 2023, the Company repurchased approximately 62 million shares of Class C Common Stock for a total purchase price of approximately $2.8 billion.  During the fiscal year ended January 28, 2022, the Company repurchased 12 million shares of Class C Common Stock for a total purchase price of approximately $659 million.
The above repurchases of Class C Common Stock exclude shares withheld from stock awards to settle employee tax withholding obligations related to the vesting of such awards.


## us-gaap:EarningsPerShareTextBlock

[0001571996-24-000036:notes:347]
EARNINGS PER SHARE
Basic earnings per share is based on the weighted-average effect of all common shares issued and outstanding and is calculated by dividing net income by the weighted-average shares outstanding during the period.  Diluted earnings per share is calculated by dividing net income by the weighted-average number of common shares used in the basic earnings per share calculation plus the number of common shares that would be issued assuming exercise or conversion of all potentially dilutive instruments.  The Company excludes equity instruments from the calculation of diluted earnings per share if the effect of including such instruments is antidilutive.

[0001571996-24-000036:notes:348]
The following table presents basic and diluted earnings per share for the periods indicated:

[0001571996-24-000036:notes:349]
|  |  |  | Fiscal Year Ended |
|  |  |  |  |  | February 2, 2024 |  | February 3, 2023 |  | January 28, 2022 |
| Earnings per share attributable to Dell Technologies Inc. — basic: |  |  |
| Continuing operations |  |  |  |  | $ | 4.46 |  |  | $ | 3.33 |  |  | $ | 6.49 |  |
| Discontinued operations |  |  |  |  | $ | — |  |  | $ | — |  |  | $ | 0.81 |  |
| Earnings per share attributable to Dell Technologies Inc. — diluted: |  |  |
| Continuing operations |  |  |  |  | $ | 4.36 |  |  | $ | 3.24 |  |  | $ | 6.26 |  |
| Discontinued operations |  |  |  |  | $ | — |  |  | $ | — |  |  | $ | 0.76 |  |

[0001571996-24-000036:notes:350]
The following table presents the computation of basic and diluted earnings per share for the periods indicated:

[0001571996-24-000036:notes:351]
|  |  |  | Fiscal Year Ended |
|  |  |  |  |  | February 2, 2024 |  | February 3, 2023 |  | January 28, 2022 |
|  |  |  |  |  | (in millions) |
| Numerator: Dell Technologies Common Stock |  |  |  |  |  |  |  |  |  |
| Net income attributable to Dell Technologies Inc. — basic and diluted |  |  |  |  | $ | 3,211 |  |  | $ | 2,442 |  |  | $ | 4,948 |  |
| Numerator: Discontinued operations |  |  |  |  |  |  |  |  |  |
| Income from discontinued operations, net of income taxes — basic |  |  |  |  | $ | — |  |  | $ | — |  |  | $ | 615 |  |
| Incremental dilution from VMware, Inc. |  |  |  |  | — |  |  | — |  |  | (7) |  |
| Income from discontinued operations, net of income taxes, attributable to Dell Technologies Inc. — diluted |  |  |  |  | $ | — |  |  | $ | — |  |  | $ | 608 |  |
| Denominator: Dell Technologies Common Stock weighted-average shares outstanding |  |  |  |  |  |  |  |  |  |
| Weighted-average shares outstanding — basic |  |  |  |  | 720 |  |  | 734 |  |  | 762 |  |
| Dilutive effect of equity awards |  |  |  |  | 16 |  |  | 19 |  |  | 29 |  |
| Weighted-average shares outstanding — diluted |  |  |  |  | 736 |  |  | 753 |  |  | 791 |  |
| Weighted-average shares outstanding — antidilutive |  |  |  |  | 4 |  |  | 9 |  |  | — |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001571996-24-000036:notes:352]
STOCK-BASED COMPENSATION 
Stock-Based Compensation Expense

[0001571996-24-000036:notes:353]
The following table presents stock-based compensation expense recognized in the Consolidated Statements of Income for the periods indicated:

[0001571996-24-000036:notes:354]
|  | Fiscal Year Ended |
|  | February 2, 2024 |  | February 3, 2023 |  | January 28, 2022 |
|  | (in millions) |
| Stock-based compensation expense: |  |  |  |  |  |
| Cost of net revenue | $ | 149 |  |  | $ | 152 |  |  | $ | 133 |  |
| Operating expenses | 729 |  |  | 779 |  |  | 675 |  |
| Stock-based compensation expense from continuing operations before taxes | 878 |  |  | 931 |  |  | 808 |  |
| Stock-based compensation expense from discontinued operations before taxes (a) | — |  |  | — |  |  | 814 |  |
| Total stock-based compensation expense before taxes | 878 |  |  | 931 |  |  | 1,622 |  |
| Income tax benefit | (157) |  |  | (163) |  |  | (296) |  |
| Total stock-based compensation expense, net of income taxes | $ | 721 |  |  | $ | 768 |  |  | $ | 1,326 |  |

[0001571996-24-000036:notes:355]
(a)    Stock-based compensation expense from discontinued operations before taxes represents VMware stock-based compensation expense and is included in income from discontinued operations, net of taxes, on the Consolidated Statements of Income for periods prior to the VMware Spin-off.

[0001571996-24-000036:notes:356]
Dell Technologies Inc. Stock-Based Compensation Plan

[0001571996-24-000036:notes:357]
Dell Technologies Inc. 2023 Stock Incentive Plan  — Employees, consultants, non-employee directors, and other service providers of the Company or its affiliates are eligible to participate in the Dell Technologies Inc. 2023 Stock Incentive Plan, which became effective on June 20, 2023 upon its approval by stockholders (the “2023 Plan”).  The 2023 Plan authorizes the Company to grant stock options, restricted stock units (“RSUs”), stock appreciation rights (“SARs”), restricted stock awards, deferred stock units, and dividend equivalents.  The 2023 Plan replaced the Dell Technologies Inc. 2013 Stock Incentive Plan (as amended and restated, the “2013 Plan”).  Upon effectiveness of the 2023 Plan, no further awards were authorized for grant under the 2013 Plan.

[0001571996-24-000036:notes:358]
The 2023 Plan authorizes the issuance of an aggregate of up to approximately 103.3 million shares of the Class C Common Stock, including (a) 50.0 million shares of Class C Common Stock that were authorized for offering and issuance under the 2023 Plan, (b) approximately 7.0 million shares of Class C Common Stock that remained available for issuance under the 2013 Plan as of the effective date of the 2023 Plan, and (c) up to approximately 46.3 million shares of Class C Common Stock subject to awards outstanding under the 2013 Plan as of the effective date of the 2023 Plan that subsequently expire or terminate prior to exercise or settlement.  As of February 2, 2024, there were approximately 58 million shares of Class C Common Stock available for future grants under the 2023 Plan.

[0001571996-24-000036:notes:359]
Restricted Stock — The Company’s awards primarily consist of RSUs granted to employees.  During the fiscal years ended February 2, 2024, February 3, 2023, and January 28, 2022, the Company granted long-term incentive awards in the form of service-based RSUs and performance-based RSUs (“PSUs”) in order to align critical talent retention programs with the interests of holders of the Class C Common Stock.

[0001571996-24-000036:notes:360]
Service-based RSUs have a fair value based on the closing price of the Class C Common Stock price as reported on the NYSE on the grant date or the trade day immediately preceding the grant date, if the grant date falls on a non-trading day.  The majority of such RSUs vest ratably over a three-year period.  Each service-based RSU represents the right to acquire one share of Class C Common Stock upon vesting.

[0001571996-24-000036:notes:361]
The PSUs granted during the periods presented are reflected as target units for performance periods not yet complete.  The actual number of units that ultimately vest will range from 0% to 200% of target, based on the level of achievement of the performance goals and continued employment with the Company over a three-year performance period.  Approximately half of the PSUs granted are subject to achievement of market-based performance goals based on relative total shareholder return and were valued utilizing a Monte Carlo valuation model to simulate the probabilities of achievement.  The remaining PSUs are subject to internal financial measures and have fair values based on the closing price of the Class C Common Stock as reported on the NYSE on the accounting grant date.

[0001571996-24-000036:notes:362]
Beginning with grants made during the fiscal year ended February 3, 2023, dividend equivalents accrue on outstanding RSUs and PSUs when a dividend is paid to the Company’s common stockholders.  Accrued dividend equivalents will be paid when the underlying RSUs and PSUs vest.

[0001571996-24-000036:notes:363]
The following table presents the assumptions utilized in the Monte Carlo valuation model for the periods indicated:

[0001571996-24-000036:notes:364]
|  | Fiscal Year Ended |
|  | February 2, 2024 |  | February 3, 2023 |  | January 28, 2022 |
| Weighted-average grant date fair value (a) | $ | 43.91 |  | $ | 73.26 |  | $ | 134.01 |
| Term (in years) | 3 |  | 3 |  | 3 |
| Risk-free rate (U.S. Government Treasury Note) | 3.8 | % |  | 2.0 | % |  | 0.3 | % |
| Expected volatility | 35 | % |  | 39 | % |  | 43 | % |
| Expected dividend yield | — | % |  | — | % |  | — | % |

[0001571996-24-000036:notes:365]
(a)    Weighted-average grant date fair value for periods prior to the completion of the VMware Spin-off is calculated using pre-spin off stock prices and has not been adjusted to reflect the impact of the conversion ratio on the Class C Common Stock.

[0001571996-24-000036:notes:366]
The following table presents RSU activity settled in Class C Common Stock for the periods indicated:

[0001571996-24-000036:notes:367]
|  | Number of Units |  | Weighted-Average Grant Date Fair Value |  | Aggregate Intrinsic Value (a) |
|  | (in millions) |  | (per unit) |  |  |
| Outstanding as of January 29, 2021 | 33 |  |  | $ | 43.09 |  |  |  |
| Granted | 13 |  |  | 88.13 |  |  |  |
| VMware Spin-off adjustment (b) | 30 |  |  | NA |  |  |
| Vested | (13) |  |  | 39.33 |  |  |  |
| Forfeited | (4) |  |  | 46.27 |  |  |  |
| Outstanding as of January 28, 2022 | 59 |  |  | 31.67 |  |  |  |
| Granted | 23 |  |  | 48.11 |  |  |  |
| Vested | (27) |  |  | 29.96 |  |  |  |
| Forfeited | (5) |  |  | 39.26 |  |  |  |
| Outstanding as of February 3, 2023 | 50 |  |  | 39.44 |  |  |  |
| Granted | 23 |  |  | 39.62 |  |  |  |
| Vested | (31) |  |  | 32.02 |  |  |  |
| Forfeited | (3) |  |  | 46.99 |  |  |  |
| Outstanding as of February 2, 2024 (c) | 39 |  |  | $ | 44.68 |  |  | $ | 3,399 |  |
| Vested and expected to vest, February 2, 2024 | 37 |  |  | $ | 44.83 |  |  | $ | 3,206 |  |

[0001571996-24-000036:notes:368]
(a)    The aggregate intrinsic value represents the total pre-tax intrinsic values based on the closing price of $86.32 of the Class C Common Stock on February 2, 2024 as reported on the NYSE that would have been received by the RSU holders if the RSUs had been issued as of February 2, 2024.

[0001571996-24-000036:notes:369]
(b)    In connection with the VMware Spin-off, and as authorized by the 2013 Plan, Dell Technologies made certain adjustments to the number of RSUs using a conversion ratio of approximately 1.97 to 1 to preserve the intrinsic value of the awards prior to the VMware Spin-off.

[0001571996-24-000036:notes:370]
(c)    As of February 2, 2024, the 39 million units outstanding included 33 million RSUs and 6 million PSUs.

[0001571996-24-000036:notes:371]
The total fair value of RSU awards that vested during the fiscal years ended February 2, 2024, February 3, 2023, and January 28, 2022 was $973 million, $827 million, and $493 million, respectively, with a pre-tax intrinsic value of $1,230 million, $1,371 million, and $1,097 million, respectively.

[0001571996-24-000036:notes:372]
As of February 2, 2024, there was $848 million of unrecognized stock-based compensation expense, net of estimated forfeitures, related to these awards expected to be recognized over a weighted-average period of approximately 1.7 years.

[0001571996-24-000036:notes:373]
Dell Technologies Shares Withheld for Taxes — Beginning in the fiscal year ended February 3, 2023, shares of Class C Common Stock are generally withheld from issuance to cover employee taxes for the vesting of restricted stock units.  During the fiscal year ended January 28, 2022, shares of Class C Common Stock were withheld from issuance to cover employee taxes for both the vesting of restricted stock units and the exercise of stock options only under certain situations.  For the fiscal years ended February 2, 2024, February 3, 2023, and January 28, 2022, 9.0 million, 8.0 million, and 0.4 million shares, respectively, were withheld to cover $366 million, $388 million, and $40 million, respectively, of employees’ tax obligations.  The value of the withheld shares was classified as a reduction to common stock and capital in excess of par value.

[0001571996-24-000036:notes:374]
Stock Option Activity — In addition to RSU activity, the Company also had stock option activity which was not material during the fiscal years ended February 2, 2024, February 3, 2023, and January 28, 2022.  Stock options are granted with option exercise prices equal to the fair market value of the Company’s Class C Common Stock and expire ten years after the grant date.

[0001571996-24-000036:notes:375]
Other Plans
In addition to the 2023 Plan described above, the Company’s consolidated subsidiary, Secureworks, maintains its own equity plan and issues equity grants settling in its Class A common stock.  The stock option and restricted stock unit activity under this plan was not material to the Company during the fiscal years ended February 2, 2024, February 3, 2023, and January 28, 2022.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001571996-24-000036:notes:376]
RETIREMENT PLAN BENEFITS 
Defined Benefit Retirement Plans

[0001571996-24-000036:notes:377]
The Company sponsors retirement plans for certain employees in the United States and internationally, some of which meet the criteria of a defined benefit retirement plan.  Benefits under defined benefit retirement plans guarantee a particular payment to the employee in retirement.  The amount of retirement benefit is defined by the plan and is typically a function of the number of years of service rendered by the employee and the employee’s average salary or salary at retirement.  The annual costs of the plans are determined using the projected unit credit actuarial cost method that includes actuarial assumptions and estimates which are subject to change.

[0001571996-24-000036:notes:378]
U.S. Pension Plan — The Company sponsors a noncontributory defined benefit retirement plan in the United States (the “U.S. pension plan”) which was assumed in connection with the EMC merger transaction.  As of December 1999, the U.S. pension plan was frozen, so employees no longer accrue retirement benefits for future services.  The measurement date for the U.S. pension plan is the end of the Company’s fiscal year.  The Company did not make any material contributions to the U.S. pension plan for the fiscal years ended February 2, 2024, February 3, 2023, and January 28, 2022, and does not expect to make any significant contributions in Fiscal 2025.

[0001571996-24-000036:notes:379]
Net periodic benefit costs related to the U.S. pension plan were immaterial for the fiscal years ended February 2, 2024, February 3, 2023, and January 28, 2022.

[0001571996-24-000036:notes:380]
The following table presents attributes of the U.S. pension plan as of the dates indicated:

[0001571996-24-000036:notes:381]
|  | February 2, 2024 |  | February 3, 2023 |
|  | (in millions) |
| Plan assets at fair value (a) | $ | 440 |  |  | $ | 439 |  |
| Benefit obligations | (457) |  |  | (484) |  |
| Underfunded position (b) | $ | (17) |  |  | $ | (45) |  |

[0001571996-24-000036:notes:382]
(a)    Plan assets are managed by outside investment managers.  The Company’s investment strategy with respect to plan assets is to achieve a long-term growth of capital, consistent with an appropriate level of risk.  Assets are recognized at fair value and are primarily classified within Level 2 of the fair value hierarchy.

[0001571996-24-000036:notes:383]
(b)    The underfunded position of the U.S. pension plan is recognized in other non-current liabilities in the Consolidated Statements of Financial Position.

[0001571996-24-000036:notes:384]
As of February 2, 2024, future benefit payments for the U.S. pension plan are expected to be paid as follows: $34 million in Fiscal 2025; $38 million in Fiscal 2026; $38 million in Fiscal 2027; $38 million in Fiscal 2028; $38 million in Fiscal 2029; and $179 million thereafter.

[0001571996-24-000036:notes:385]
International Pension Plans — The Company also sponsors retirement plans outside of the United States which qualify as defined benefit plans.  The following table presents attributes of the international pension plans as of the dates indicated:

[0001571996-24-000036:notes:386]
|  | February 2, 2024 |  | February 3, 2023 |
|  | (in millions) |
| Plan assets at fair value (a) | $ | 224 |  |  | $ | 221 |  |
| Benefit obligations | (420) |  |  | (423) |  |
| Underfunded position (b) | $ | (196) |  |  | $ | (202) |  |

[0001571996-24-000036:notes:387]
(a)    Plan assets are managed by outside investment managers.  The Company’s investment strategy with respect to plan assets is to achieve a long-term growth of capital, consistent with an appropriate level of risk.  Assets are recognized at fair value and are primarily classified within Level 1 of the fair value hierarchy.

[0001571996-24-000036:notes:388]
(b)    The underfunded position is recognized in other non-current liabilities in the Consolidated Statements of Financial Position.

[0001571996-24-000036:notes:389]
Defined Contribution Retirement Plans
Dell 401(k) Plan — The Company maintains a defined contribution retirement plan (the “Dell 401(k) Plan”) that complies with Section 401(k) of the Internal Revenue Code.  Only U.S. employees and employees of certain subsidiaries, except those who are covered by a collective bargaining agreement, classified as a leased employee or a nonresident alien, or are covered under a separate plan, are eligible to participate in the Dell 401(k) Plan.  Participation in the Dell 401(k) Plan is at the election of the employee.  As of February 2, 2024, the Company matched 100% of each participant’s voluntary contributions (the “Dell 401(k) employer match”), subject to a maximum contribution of 6% of the participant’s eligible compensation, up to an annual limit of $7,500.  Participants vest immediately in all contributions to the Dell 401(k) Plan.  The Company’s matching contributions as well as participants’ voluntary contributions are invested according to each participant’s elections in the investment options provided under the Dell 401(k) Plan.  The Company’s contributions during the fiscal years ended February 2, 2024, February 3, 2023, and January 28, 2022 were $238 million, $263 million, and $249 million, respectively.


## us-gaap:ScheduleOfChangesInFairValueOfPlanAssetsTableTextBlock

[0001571996-24-000036:notes:390]
(a)    Plan assets are managed by outside investment managers.  The Company’s investment strategy with respect to plan assets is to achieve a long-term growth of capital, consistent with an appropriate level of risk.  Assets are recognized at fair value and are primarily classified within Level 2 of the fair value hierarchy.
(b)    The underfunded position of the U.S. pension plan is recognized in other non-current liabilities in the Consolidated Statements of Financial Position.The following table presents attributes of the international pension plans as of the dates indicated:

[0001571996-24-000036:notes:391]
(a)    Plan assets are managed by outside investment managers.  The Company’s investment strategy with respect to plan assets is to achieve a long-term growth of capital, consistent with an appropriate level of risk.  Assets are recognized at fair value and are primarily classified within Level 1 of the fair value hierarchy.
(b)    The underfunded position is recognized in other non-current liabilities in the Consolidated Statements of Financial Position.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001571996-24-000036:notes:392]
SEGMENT INFORMATION 
The Company has two reportable segments that are based on the following business units:  Infrastructure Solutions Group (“ISG”) and Client Solutions Group (“CSG”).

[0001571996-24-000036:notes:393]
ISG includes the Company’s storage, server, and networking offerings.  The Company’s comprehensive storage portfolio includes modern and traditional storage solutions, including all-flash arrays, scale-out file, object platforms, hyper-converged infrastructure, and software-defined storage.  The Company’s server portfolio includes high-performance general-purpose and AI-optimized servers.  The Company’s networking portfolio includes wide area network infrastructure, data center and edge networking switches, and cables and optics.  ISG also offers software, peripherals, and services, including consulting and support and deployment.

[0001571996-24-000036:notes:394]
CSG includes offerings designed for commercial and consumer customers.  The Company’s CSG portfolio includes branded PCs including notebooks, desktops, and workstations, branded peripherals, and third-party software and peripherals.  CSG also includes services offerings, such as configuration, support and deployment, and extended warranties.

[0001571996-24-000036:notes:395]
The reportable segments disclosed herein are based on information reviewed by the Company’s management to evaluate the business segment results.  The Company’s measure of segment revenue and segment operating income for management reporting purposes excludes operating results of other businesses, unallocated corporate transactions, the impact of purchase accounting, amortization of intangible assets, transaction-related expenses, stock-based compensation expense, and other corporate expenses, as applicable.  The Company does not allocate assets to the above reportable segments for internal reporting purposes.

[0001571996-24-000036:notes:396]
Following the completion of the VMware Spin-off and pursuant to the CFA, as described in Note 1 and Note 3 of the Notes to the Consolidated Financial Statements, Dell Technologies acted as a distributor of VMware’s standalone products and services and purchased such products and services for resale to end-user customers (“VMware Resale”).  The results of VMware Resale transactions are reflected in other businesses.

[0001571996-24-000036:notes:397]
On November 22, 2023, VMware was acquired by Broadcom.  Following the acquisition, Broadcom announced changes to its go-to-market approach for VMware offerings which impacted the Company’s commercial relationship with VMware.  In response to such changes, on January 25, 2024, under a provision of the CFA permitting it to terminate the agreement upon a change in control of VMware, the Company delivered notice of termination of the CFA to Broadcom under which the agreement will terminate on March 25, 2024.

[0001571996-24-000036:notes:398]
The Company continues to integrate select VMware products and services with Dell Technologies’ offerings and sell them to end-users.  The results of such offerings are reflected within CSG or ISG, depending upon the nature of the underlying offering sold.

[0001571996-24-000036:notes:399]
The following table presents a reconciliation of net revenue by the Company’s reportable segments to the Company’s consolidated net revenue as well as a reconciliation of segment operating income to the Company’s consolidated operating income for the periods indicated:

[0001571996-24-000036:notes:400]
|  |  |  | Fiscal Year Ended |
|  |  |  |  |  | February 2, 2024 |  | February 3, 2023 |  | January 28, 2022 |
|  |  |  |  |  | (in millions) |
| Consolidated net revenue: |  |  |  |  |  |  |  |  |  |
| Infrastructure Solutions Group |  |  |  |  | $ | 33,885 |  |  | $ | 38,356 |  |  | $ | 34,366 |  |
| Client Solutions Group |  |  |  |  | 48,916 |  |  | 58,213 |  |  | 61,464 |  |
| Reportable segment net revenue |  |  |  |  | 82,801 |  |  | 96,569 |  |  | 95,830 |  |
| Other businesses (a) (b) |  |  |  |  | 5,614 |  |  | 5,721 |  |  | 5,388 |  |
| Unallocated transactions (c) |  |  |  |  | 10 |  |  | 11 |  |  | 11 |  |
| Impact of purchase accounting (d) |  |  |  |  | — |  |  | — |  |  | (32) |  |
| Total consolidated net revenue |  |  |  |  | $ | 88,425 |  |  | $ | 102,301 |  |  | $ | 101,197 |  |
| Consolidated operating income: |  |  |  |  |  |  |  |  |  |
| Infrastructure Solutions Group |  |  |  |  | $ | 4,286 |  |  | $ | 5,045 |  |  | $ | 3,736 |  |
| Client Solutions Group |  |  |  |  | 3,512 |  |  | 3,824 |  |  | 4,365 |  |
| Reportable segment operating income |  |  |  |  | 7,798 |  |  | 8,869 |  |  | 8,101 |  |
| Other businesses (a) (b) |  |  |  |  | (129) |  |  | (240) |  |  | (319) |  |
| Unallocated transactions (c) |  |  |  |  | 9 |  |  | 8 |  |  | 3 |  |
| Impact of purchase accounting (d) |  |  |  |  | (14) |  |  | (44) |  |  | (67) |  |
| Amortization of intangibles |  |  |  |  | (819) |  |  | (970) |  |  | (1,641) |  |
| Transaction-related expenses (e) |  |  |  |  | (12) |  |  | (22) |  |  | (273) |  |
| Stock-based compensation expense (f) |  |  |  |  | (878) |  |  | (931) |  |  | (808) |  |
| Other corporate expenses (g) |  |  |  |  | (744) |  |  | (899) |  |  | (337) |  |
| Total consolidated operating income |  |  |  |  | $ | 5,211 |  |  | $ | 5,771 |  |  | $ | 4,659 |  |

[0001571996-24-000036:notes:401]
(a)Other businesses consists of (i) VMware Resale, (ii) Secureworks, and (iii) Virtustream, and do not meet the requirements for a reportable segment, either individually or collectively.

[0001571996-24-000036:notes:402]
(b)The Company completed the sale of Boomi on October 1, 2021.  Prior to the divestiture, Boomi’s results were included within other businesses.  See Note 1 of the Notes to the Consolidated Financial Statements for further information about the divestiture of Boomi.

[0001571996-24-000036:notes:403]
(c)Unallocated transactions includes other corporate items that are not allocated to Dell Technologies’ reportable segments.

[0001571996-24-000036:notes:404]
(d)Impact of purchase accounting includes non-cash purchase accounting adjustments that are primarily related to the EMC merger transaction.

[0001571996-24-000036:notes:405]
(e)Transaction-related expenses includes acquisition, integration, and divestiture related costs.  During Fiscal 2022 this category also includes costs incurred in connection with the VMware Spin-off described in Note 1 and Note 3 of the Notes to the Consolidated Financial Statements.

[0001571996-24-000036:notes:406]
(f)Stock-based compensation expense consists of equity awards granted based on the estimated fair value of those awards at grant date.

[0001571996-24-000036:notes:407]
(g)Other corporate expenses includes impairment charges, severance expense, incentive charges related to equity investments, facility action costs, payroll taxes associated with stock-based compensation, and other costs.

[0001571996-24-000036:notes:408]
The following table presents the disaggregation of net revenue by reportable segment and by major product categories within the segments for the periods indicated:

[0001571996-24-000036:notes:409]
|  |  |  | Fiscal Year Ended |
|  |  |  |  |  | February 2, 2024 |  | February 3, 2023 |  | January 28, 2022 |
|  |  |  |  |  | (in millions) |
| Net revenue: |  |  |  |  |  |  |  |  |  |
| Infrastructure Solutions Group: |  |  |  |  |  |  |  |  |  |
| Servers and networking |  |  |  |  | $ | 17,624 |  |  | $ | 20,398 |  |  | $ | 17,901 |  |
| Storage |  |  |  |  | 16,261 |  |  | 17,958 |  |  | 16,465 |  |
| Total ISG net revenue |  |  |  |  | $ | 33,885 |  |  | $ | 38,356 |  |  | $ | 34,366 |  |
| Client Solutions Group: |  |  |  |  |  |  |  |  |  |
| Commercial |  |  |  |  | $ | 39,814 |  |  | $ | 45,556 |  |  | $ | 45,576 |  |
| Consumer |  |  |  |  | 9,102 |  |  | 12,657 |  |  | 15,888 |  |
| Total CSG net revenue |  |  |  |  | $ | 48,916 |  |  | $ | 58,213 |  |  | $ | 61,464 |  |

[0001571996-24-000036:notes:410]
The following table presents net revenue allocated between the United States and foreign countries for the periods indicated:

[0001571996-24-000036:notes:411]
|  | Fiscal Year Ended |
|  | February 2, 2024 |  | February 3, 2023 |  | January 28, 2022 |
|  | (in millions) |
| Net revenue: |  |  |  |  |  |
| United States | $ | 43,986 |  |  | $ | 49,201 |  |  | $ | 46,752 |  |
| Foreign countries | 44,439 |  |  | 53,100 |  |  | 54,445 |  |
| Total net revenue | $ | 88,425 |  |  | $ | 102,301 |  |  | $ | 101,197 |  |

[0001571996-24-000036:notes:412]
The following table presents property, plant, and equipment, net allocated between the United States and foreign countries as of the dates indicated:

[0001571996-24-000036:notes:413]
|  | February 2, 2024 |  | February 3, 2023 |
|  | (in millions) |
| Property, plant, and equipment, net: |  |  |  |
| United States | $ | 4,330 |  |  | $ | 4,163 |  |
| Foreign countries | 2,102 |  |  | 2,046 |  |
| Total property, plant, and equipment, net | $ | 6,432 |  |  | $ | 6,209 |  |

[0001571996-24-000036:notes:414]
The allocation between domestic and foreign net revenue is based on the location of the customers.  Net revenue from any single foreign country did not constitute more than 10% of the Company’s consolidated net revenue for any of the fiscal years ended February 2, 2024, February 3, 2023, and January 28, 2022.  As of February 2, 2024 and February 3, 2023, property, plant, and equipment, net primarily related to domestic ownership.  Within foreign countries, property, plant, and equipment, net of $0.8 billion was located in Ireland.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001571996-24-000036:notes:415]
RELATED PARTY TRANSACTIONS 
Prior to the acquisition of VMware by Broadcom, VMware was considered a related party of the Company as a result of Michael Dell’s ownership interests in both Dell Technologies and VMware as well as Mr. Dell’s service as Chairman and Chief Executive Officer of Dell Technologies and as Chairman of the Board of VMware, Inc.  On November 22, 2023, upon the completion of Broadcom’s acquisition of VMware, Mr. Dell’s ownership interest in VMware and his position as Chairman of the Board of VMware terminated.  The Company has determined that Broadcom’s acquisition terminated the Company’s related party relationship with VMware effective as of November 22, 2023 and that no related party relationship exists with Broadcom or VMware as of February 2, 2024.

[0001571996-24-000036:notes:416]
The information provided below includes a summary of related party transactions with VMware for the periods presented within this report.  Such transactions were considered related party transactions only through November 21, 2023, the day immediately preceding Broadcom’s acquisition of VMware.  The Company continues to engage in select transactions with VMware following the completion of Broadcom’s acquisition and the termination of the related party relationship.  See Note 19 of the Notes to the Consolidated Financial Statements for additional information.

[0001571996-24-000036:notes:417]
Related Party Transactions with VMware

[0001571996-24-000036:notes:418]
•Dell Technologies integrated or bundled select VMware products and services with Dell Technologies’ products and sold them to end-users.  Dell Technologies also acted as a distributor, purchasing VMware’s standalone products and services for resale to end-user customers.  Where applicable, costs under these arrangements were presented net of rebates received by Dell Technologies.

[0001571996-24-000036:notes:419]
•DFS provided financing to certain VMware end-users, which resulted in the recognition of amounts due to related parties on the Consolidated Statements of Financial Position.  Associated financing fees were recorded to product net revenue on the Consolidated Statements of Income and are reflected within sales and leases of products to VMware in the table below.

[0001571996-24-000036:notes:420]
•Dell Technologies procured products and services from VMware for its internal use.  For the fiscal years ended February 2, 2024, February 3, 2023, and January 28, 2022, costs incurred associated with products and services purchased from VMware for internal use were immaterial.

[0001571996-24-000036:notes:421]
•Dell Technologies sold and leased products and sold services to VMware.  For the fiscal years ended February 2, 2024, February 3, 2023, and January 28, 2022, revenue recognized from sales of services to VMware was immaterial.

[0001571996-24-000036:notes:422]
•Dell Technologies and VMware entered into joint marketing, sales, and branding arrangements, for which both parties incurred costs.  For the fiscal years ended February 2, 2024, February 3, 2023, and January 28, 2022, consideration received from VMware for joint marketing, sales, and branding arrangements was immaterial.

[0001571996-24-000036:notes:423]
•Dell Technologies and VMware entered into a transition services agreement in connection with the VMware Spin-off to provide various support services, including investment advisory services, certain support services from Dell Technologies personnel, and other transitional services.  Costs incurred associated with this agreement were immaterial for the fiscal years ended February 3, 2023 and January 28, 2022.  Activities under the agreement concluded during Fiscal 2023.

[0001571996-24-000036:notes:424]
The following table presents information about the impact of Dell Technologies’ related party transactions with VMware on the Consolidated Statements of Income for the periods presented:

[0001571996-24-000036:notes:425]
|  |  |  |  |  | Fiscal Year Ended |
|  | Classification |  |  |  |  |  | February 2, 2024 (a) |  | February 3, 2023 |  | January 28, 2022 |
|  |  |  |  |  |  |  | (in millions) |
| Sales and leases of products to VMware | Net revenue - products |  |  |  |  |  | $ | 103 |  |  | $ | 154 |  |  | $ | 188 |  |
| Purchase of VMware products for resale | Cost of net revenue - products |  |  |  |  |  | $ | 1,010 |  |  | $ | 1,634 |  |  | $ | 1,577 |  |
| Purchase of VMware services for resale | Cost of net revenue - services |  |  |  |  |  | $ | 2,810 |  |  | $ | 3,065 |  |  | $ | 2,487 |  |

[0001571996-24-000036:notes:426]
(a)      For the fiscal year ended February 2, 2024, amounts are reported only through November 21, 2023, the day immediately preceding the acquisition of VMware by Broadcom.

[0001571996-24-000036:notes:427]
The following tables present amounts classified as related party balances on the Consolidated Statements of Financial Position as of the dates indicated:

[0001571996-24-000036:notes:428]
|  | Classification |  |  |  | February 3, 2023 |
|  |  |  |  |  | (in millions) |
| Deferred costs related to VMware products and services for resale (a) | Other current assets |  |  |  | $ | 3,000 |  |
| Deferred costs related to VMware products and services for resale (a) | Other non-current assets |  |  |  | $ | 2,537 |  |

[0001571996-24-000036:notes:429]
(a)      Deferred costs are not reported as related party balances as of February 2, 2024 as the related party relationship with VMware terminated upon Broadcom’s acquisition of VMware.

[0001571996-24-000036:notes:430]
|  | February 2, 2024 (a) |  | February 3, 2023 |
|  | (in millions) |
| Due from related party, net, current (b) | $ | — |  |  | $ | 378 |  |
| Due from related party, net, non-current (c) | $ | — |  |  | $ | 440 |  |
| Due to related party, current (d) | $ | — |  |  | $ | 2,067 |  |

[0001571996-24-000036:notes:431]
(a)    Amounts due from related party, net were reclassified into accounts receivable, net, other current assets, and other non-current assets, and amounts due to related party, net were reclassified into accounts payable as of February 2, 2024 as, subsequent to Broadcom’s acquisition of VMware, the amounts were no longer considered due from or due to a related party.

[0001571996-24-000036:notes:432]
(b)    Amounts due from related party, net, current consisted of amounts due from VMware, inclusive of current net tax receivables from VMware under the Tax Agreements described below.  Amounts, excluding tax, were generally settled in cash within 60 days.

[0001571996-24-000036:notes:433]
(c)    Amounts due from related party, net, non-current consisted of the non-current portion of net receivables from VMware under the Tax Agreements.

[0001571996-24-000036:notes:434]
(d)    Amounts due to related party, current included amounts due to VMware, which were generally settled in cash within 60 days.

[0001571996-24-000036:notes:435]
Related Party Tax Matters

[0001571996-24-000036:notes:436]
In connection with the VMware Spin-off and concurrently with the execution of the Separation and Distribution Agreement, effective as of April 14, 2021, Dell Technologies and VMware entered into a Tax Matters Agreement (the “Tax Matters Agreement”) and agreed to terminate the Tax Sharing Agreement as amended on December 30, 2019 (together with the Tax Matters Agreement, the “Tax Agreements”).  The Tax Matters Agreement governs Dell Technologies’ and VMware’s respective rights and obligations regarding income and other taxes as well as related matters, including tax liabilities, benefits, attributes, and returns for periods both preceding and proceeding the spin-off.

[0001571996-24-000036:notes:437]
The timing of the tax payments due to and from VMware is governed by the Tax Agreements.  VMware’s portion of the mandatory one-time transition tax on accumulated earnings of foreign subsidiaries (the “Transition Tax”) is governed by a letter agreement between VMware and Dell Technologies entered into on April 1, 2019.

[0001571996-24-000036:notes:438]
Pursuant to the Tax Agreements, net receipts from VMware were $286 million during the fiscal year ended February 2, 2024, a portion of which was received subsequent to the completion of Broadcom’s acquisition of VMware, and were immaterial for the fiscal years ended February 3, 2023 and January 28, 2022.  Such receipts were primarily related to VMware’s portion of the Transition Tax and federal income taxes on Dell Technologies’ consolidated income tax return.

[0001571996-24-000036:notes:439]
As of February 2, 2024 and February 3, 2023, the amount due from VMware under the Tax Matters Agreement was $311 million and $599 million, respectively, and primarily related to VMware’s estimated tax obligation resulting from the Transition Tax.  The 2017 Tax Cuts and Jobs Act included a deferral election for an eight-year installment payment method on the Transition Tax.  Dell Technologies expects VMware to pay the remainder of its Transition Tax over a period of two years.

[0001571996-24-000036:notes:440]
Upon consummation of the VMware Spin-off, Dell Technologies recorded net income tax indemnification receivables from VMware related to certain income tax liabilities for which Dell Technologies is jointly and severally liable, but for which it is indemnified by VMware under the Tax Matters Agreement.  The amounts that VMware may be obligated to pay Dell Technologies could vary depending on the outcome of certain unresolved tax matters, which may not be resolved for several years.  The net receivable as of February 2, 2024 and February 3, 2023 was $104 million and $146 million, respectively.

[0001571996-24-000036:notes:441]
Amounts due from VMware as of February 2, 2024 under the Tax Matters Agreement and the indemnification receivable are no longer considered due from a related party.

[0001571996-24-000036:notes:442]
Other Related Parties

[0001571996-24-000036:notes:443]
Transactions with other related parties during the periods presented were immaterial, individually and in aggregate.


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0001571996-24-000036:notes:444]
SUPPLEMENTAL CONSOLIDATED FINANCIAL INFORMATION
The following table presents additional information on selected assets included in the Consolidated Statements of Financial Position as of the dates indicated:

[0001571996-24-000036:notes:445]
|  | February 2, 2024 |  | February 3, 2023 |
|  | (in millions) |
| Cash, cash equivalents, and restricted cash: |  |  |  |
| Cash and cash equivalents | $ | 7,366 |  |  | $ | 8,607 |  |
| Restricted cash - other current assets (a) | 136 |  |  | 272 |  |
| Restricted cash - other non-current assets (a) | 5 |  |  | 15 |  |
| Total cash, cash equivalents, and restricted cash | $ | 7,507 |  |  | $ | 8,894 |  |
| Inventories: |  |  |  |
| Production materials | $ | 2,321 |  |  | $ | 3,225 |  |
| Work-in-process | 607 |  |  | 708 |  |
| Finished goods | 694 |  |  | 843 |  |
| Total inventories | $ | 3,622 |  |  | $ | 4,776 |  |
| Prepaid expenses: |  |  |  |
| Total prepaid expenses (b) | $ | 589 |  |  | $ | 641 |  |
| Deferred Costs: |  |  |  |
| Total deferred costs, current (b) | $ | 5,548 |  |  | $ | 5,459 |  |
| Property, plant, and equipment, net (c): |  |  |  |
| Assets in a customer contract | $ | 5,022 |  |  | $ | 4,664 |  |
| Computer and other equipment | 3,552 |  |  | 3,401 |  |
| Land and buildings | 2,877 |  |  | 3,059 |  |
| Internal use software | 2,166 |  |  | 1,968 |  |
| Total property, plant, and equipment | 13,617 |  |  | 13,092 |  |
| Accumulated depreciation and amortization (d) | (7,185) |  |  | (6,883) |  |
| Total property, plant, and equipment, net | $ | 6,432 |  |  | $ | 6,209 |  |

[0001571996-24-000036:notes:446]
(a)    Restricted cash includes cash required to be held in escrow pursuant to DFS securitization arrangements.

[0001571996-24-000036:notes:447]
(b)    Deferred costs and prepaid expenses are included in other current assets in the Consolidated Statements of Financial Position.  Amounts classified as long-term deferred costs are included in other non-current assets and are not disclosed above.

[0001571996-24-000036:notes:448]
(c)    The Company revised its presentation of property, plant, and equipment, net by major asset class as of February 2, 2024.  Prior period balances have been recast to conform to this presentation.

[0001571996-24-000036:notes:449]
(d)    During the fiscal years ended February 2, 2024, February 3, 2023, and January 28, 2022, the Company recognized $2.0 billion, $1.8 billion, and $1.6 billion, respectively, in depreciation expense.

[0001571996-24-000036:notes:450]
Warranty Liability

[0001571996-24-000036:notes:451]
The following table presents changes in the Company’s liability for standard limited warranties for the periods indicated:

[0001571996-24-000036:notes:452]
|  |  |  | Fiscal Year Ended |
|  |  |  |  |  | February 2, 2024 |  | February 3, 2023 |  | January 28, 2022 |
|  |  |  |  |  | (in millions) |
| Warranty liability: |  |  |  |  |  |  |  |  |  |
| Warranty liability at beginning of period |  |  |  |  | $ | 467 |  |  | $ | 480 |  |  | $ | 473 |  |
| Costs accrued for new warranty contracts and changes in estimates for pre-existing warranties (a) |  |  |  |  | 808 |  |  | 956 |  |  | 957 |  |
| Service obligations honored |  |  |  |  | (849) |  |  | (969) |  |  | (950) |  |
| Warranty liability at end of period |  |  |  |  | $ | 426 |  |  | $ | 467 |  |  | $ | 480 |  |

[0001571996-24-000036:notes:453]
(a)   Changes in cost estimates related to pre-existing warranties are aggregated with accruals for new standard warranty contracts.  The Company’s warranty liability process does not differentiate between estimates made for pre-existing warranties and those made for new warranty obligations.

[0001571996-24-000036:notes:454]
Severance Charges

[0001571996-24-000036:notes:455]
The Company incurs costs related to employee severance and records a liability for these costs when it is probable that employees will be entitled to termination benefits and the amounts can be reasonably estimated.  The liability related to these actions is included in accrued and other current liabilities in the Consolidated Statements of Financial Position.

[0001571996-24-000036:notes:456]
The following table presents the activity related to the Company’s severance liability for the periods indicated:

[0001571996-24-000036:notes:457]
|  |  |  | Fiscal Year Ended |
|  |  |  |  |  | February 2, 2024 |  | February 3, 2023 |  | January 28, 2022 |
|  |  |  |  |  | (in millions) |
| Severance liability: |  |  |  |  |  |  |  |  |  |
| Severance liability at beginning of period |  |  |  |  | $ | 408 |  |  | $ | 74 |  |  | $ | 109 |  |
| Severance charges |  |  |  |  | 648 |  |  | 527 |  |  | 134 |  |
| Cash paid and other |  |  |  |  | (704) |  |  | (193) |  |  | (169) |  |
| Severance liability at end of period |  |  |  |  | $ | 352 |  |  | $ | 408 |  |  | $ | 74 |  |

[0001571996-24-000036:notes:458]
The following table presents severance charges as included in the Consolidated Statements of Income for the periods indicated:

[0001571996-24-000036:notes:459]
|  |  |  | Fiscal Year Ended |
|  |  |  |  |  | February 2, 2024 |  | February 3, 2023 |  | January 28, 2022 |
|  |  |  |  |  | (in millions) |
| Severance charges: |  |  |  |  |  |  |  |  |  |
| Cost of net revenue |  |  |  |  | $ | 86 |  |  | $ | 108 |  |  | $ | 29 |  |
| Selling, general, and administrative |  |  |  |  | 522 |  |  | 363 |  |  | 98 |  |
| Research and development |  |  |  |  | 40 |  |  | 56 |  |  | 7 |  |
| Total severance charges |  |  |  |  | $ | 648 |  |  | $ | 527 |  |  | $ | 134 |  |

[0001571996-24-000036:notes:460]
Supply Chain Finance Program

[0001571996-24-000036:notes:461]
The Company maintains a Supply Chain Finance Program (the “SCF Program”), which enables eligible suppliers of the Company, at the supplier's sole discretion, to sell receivables due from the Company to a third-party financial institution.  The Company has no involvement in establishing the terms or conditions of the arrangement between its suppliers and the financial institution and no economic interest in a supplier's decision to sell a receivable.  Suppliers may elect to sell varying amounts of their outstanding receivables as part of the SCF Program.  The Company does not provide legally secured assets or other forms of guarantees under the arrangement.

[0001571996-24-000036:notes:462]
The SCF Program does not impact the Company's liquidity as payments for participating supplier invoices are remitted by the Company to the financial institution on the original invoice due date, regardless of whether an individual invoice is sold by the supplier to the financial institution.  Further, the Company negotiates payment terms with suppliers regardless of their decision to participate in the SCF Program.  Payment terms with such suppliers vary and do not exceed 130 days.

[0001571996-24-000036:notes:463]
Any amounts due to the financial institution for suppliers participating in the SCF Program are recorded within Accounts Payable on the Consolidated Statements of Financial Position and associated payments are included in cash flows from operating activities on the Consolidated Statements of Cash Flows.

[0001571996-24-000036:notes:464]
As of February 2, 2024 and February 3, 2023, the Company had $1.1 billion and $1.0 billion, respectively, included within Accounts Payable representing invoices due to suppliers confirmed as valid under the SCF Program.

[0001571996-24-000036:notes:465]
Interest and other, net

[0001571996-24-000036:notes:466]
The following table presents information regarding interest and other, net for the periods indicated:

[0001571996-24-000036:notes:467]
|  |  |  | Fiscal Year Ended |
|  |  |  |  |  | February 2, 2024 |  | February 3, 2023 |  | January 28, 2022 |
|  |  |  |  |  | (in millions) |
| Interest and other, net: |  |  |  |  |  |  |  |  |  |
| Investment income, primarily interest |  |  |  |  | $ | 305 |  |  | $ | 100 |  |  | $ | 42 |  |
| Gain (loss) on investments, net |  |  |  |  | 47 |  |  | (206) |  |  | 569 |  |
| Interest expense |  |  |  |  | (1,501) |  |  | (1,222) |  |  | (1,542) |  |
| Foreign exchange |  |  |  |  | (199) |  |  | (265) |  |  | (221) |  |
| Gain on disposition of businesses and assets |  |  |  |  | — |  |  | — |  |  | 3,968 |  |
| Debt extinguishment gain (loss) |  |  |  |  | 68 |  |  | — |  |  | (1,572) |  |
| Legal settlement, net |  |  |  |  | — |  |  | (894) |  |  | — |  |
| Other |  |  |  |  | (44) |  |  | (59) |  |  | 20 |  |
| Total interest and other, net |  |  |  |  | $ | (1,324) |  |  | $ | (2,546) |  |  | $ | 1,264 |  |


## us-gaap:GovernmentAssistanceTextBlock

[0001571996-24-000036:notes:468]
GOVERNMENT ASSISTANCE
The Company receives government assistance in the form of grants and incentives which vary in size, duration, and conditions from various domestic and international governing bodies and related entities which are primarily structured as cash grants and non-income tax incentives.  For government assistance in which no specific US GAAP applies, the Company accounts for such transactions as a gain contingency and by analogy to a grant model.  Under such model, the Company recognizes the impact of the government assistance on the Consolidated Statements of Income upon reaching reasonable assurance that the Company will comply with the conditions of the assistance and that the grant will be received.  The Company classifies the impact of government assistance on the Consolidated Statements of Income based on the underlying nature and purpose of the assistance.

[0001571996-24-000036:notes:469]
During the fiscal years ended February 2, 2024 and February 3, 2023, government assistance received primarily consisted of the following:

[0001571996-24-000036:notes:470]
The Company received assistance from foreign governmental entities designed, in part, to promote competitive pricing by providing companies with an offset to local sales taxes incurred on the sales of products to customers.  The assistance received is broadly available to companies.  To qualify for this assistance, companies are required to invest a portion of local revenue, derived from goods manufactured locally, into research and development activities.  The incentives in place are currently set to expire at various dates through 2029.  Such expirations could be impacted by future legislation.  During the fiscal years ended February 2, 2024 and February 3, 2023, the Company recognized $288 million and $297 million, respectively, within net revenue on the Consolidated Statements of Income related to such assistance.

[0001571996-24-000036:notes:471]
The Company received incentives from foreign governmental entities to provide reimbursement for various costs incurred that are directly tied to the production or delivery of offerings sold to customers.  The agreements governing such assistance require that the Company comply with certain conditions including, but not limited to, the achievement of future operational targets.  These agreements currently expire at various dates through 2029.  During the fiscal years ended February 2, 2024 and February 3, 2023, the Company recognized a benefit of $166 million and $318 million, respectively, to cost of net revenue on the Consolidated Statements of Income related to such assistance.


## us-gaap:SubsequentEventsTextBlock

[0001571996-24-000036:notes:472]
SUBSEQUENT EVENTS 
Except as otherwise disclosed, there were no known events occurring after February 2, 2024, and up until the date of issuance of this report that would materially affect the information presented herein.


## ecd:MtrlTermsOfTrdArrTextBlock

[0001571996-24-000036:notes:473]
On January 4, 2024, Richard J. Rothberg, our General Counsel, adopted a written plan for the sale of up to 114,368 shares of the Company’s Class C Common Stock that is intended to satisfy the affirmative defense conditions of Rule 10b5-1(c) under the Exchange Act.  The plan will expire on August 30, 2024, or on any earlier date on which all of the shares have been sold.
