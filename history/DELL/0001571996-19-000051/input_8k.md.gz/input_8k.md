# DELL 8-K — 0001571996-19-000042 filed 2019-11-26

## item codes, every 8-K on or before 2019-12-09

- 2019-12-02 0001571996-19-000044 — 5.02, 7.01, 9.01
- 2019-11-26 0001571996-19-000042 — 2.02, 9.01
- 2019-09-23 0001193125-19-252192 — 1.01, 2.03, 9.01
- 2019-08-29 0001571996-19-000036 — 2.02, 9.01
- 2019-08-22 0001193125-19-226939 — 7.01, 8.01, 9.01
- 2019-07-11 0001571996-19-000032 — 5.02, 5.07, 9.01
- 2019-07-03 0001571996-19-000030 — 3.02
- 2019-06-27 0001571996-19-000028 — 3.02
- 2019-05-30 0001571996-19-000021 — 2.02, 9.01
- 2019-04-02 0001571996-19-000010 — 5.02
- 2019-03-21 0001193125-19-082281 — 1.01, 1.02, 2.03, 9.01
- 2019-03-19 0001571996-19-000005 — 5.02, 9.01
- 2019-03-14 0001193125-19-074935 — 1.01, 2.03, 9.01
- 2019-03-07 0001193125-19-066045 — 8.01, 9.01
- 2019-02-28 0001571996-19-000002 — 2.02, 9.01
- 2018-12-28 0001193125-18-360943 — 1.01, 1.02, 3.01, 3.03, 5.02, 5.03, 7.01, 8.01, 9.01
- 2018-12-21 0001193125-18-356324 — 1.01, 2.03, 9.01
- 2018-12-14 0001193125-18-349469 — 8.01
- 2018-12-11 0001193125-18-346958 — 5.07, 8.01, 9.01
- 2018-11-29 0001571996-18-000041 — 2.02, 9.01
- 2018-11-28 0001571996-18-000037 — 7.01, 8.01, 9.01
- 2018-11-26 0001193125-18-333967 — 8.01, 9.01
- 2018-11-15 0001193125-18-328110 — 1.01, 9.01 — amendment of 0001193125-18-327222
- 2018-11-15 0001193125-18-327222 — 1.01, 7.01, 9.01
- 2018-10-03 0001193125-18-291390 — 8.01
- 2018-09-06 0001571996-18-000029 — 2.02, 9.01
- 2018-08-06 0001571996-18-000027 — 8.01, 9.01
- 2018-07-02 0001193125-18-210339 — 1.01, 7.01, 9.01
- 2018-06-28 0001571996-18-000024 — 5.07
- 2018-06-04 0001571996-18-000019 — 2.02, 9.01
- 2018-05-17 0001571996-18-000016 — 7.01
- 2018-04-26 0001571996-18-000009 — 7.01, 9.01
- 2018-03-08 0001193125-18-074168 — 2.02, 9.01
- 2018-02-02 0001193125-18-029947 — 7.01, 9.01
- 2017-12-07 0001571996-17-000042 — 2.02, 9.01
- 2017-10-24 0001571996-17-000037 — 1.01, 2.03, 9.01
- 2017-09-15 0001571996-17-000027 — 5.02
- 2017-09-07 0001571996-17-000017 — 2.02, 9.01
- 2017-08-24 0001571996-17-000014 — 8.01
- 2017-06-29 0001571996-17-000011 — 3.03, 5.07, 8.01, 9.01
- 2017-06-08 0001193125-17-197638 — 2.02, 9.01
- 2017-03-30 0001193125-17-102794 — 8.01
- 2017-03-30 0001193125-17-102777 — 2.02, 9.01
- 2017-03-09 0001193125-17-076981 — 1.01, 2.03, 9.01
- 2017-01-17 0001193125-17-011125 — 8.01
- 2016-12-15 0001193125-16-793722 — 8.01
- 2016-12-08 0001193125-16-787976 — 2.02, 9.01
- 2016-11-10 0001193125-16-765964 — 1.02, 8.01
- 2016-11-04 0001193125-16-760249 — 8.01
- 2016-09-13 0001193125-16-708600 — 3.02
- 2016-09-09 0001193125-16-706567 — 1.01, 1.02, 2.01, 2.03, 3.02, 3.03, 5.02, 9.01
- 2016-09-07 0001193125-16-703370 — 3.03, 5.07, 7.01, 8.01, 9.01
- 2016-09-06 0001193125-16-702057 — 2.02, 9.01
- 2016-08-31 0001193125-16-697268 — 8.01, 9.01
- 2016-08-26 0001193125-16-692921 — 8.01, 9.01
- 2016-07-11 0001193125-16-645610 — 8.01
- 2016-07-05 0001193125-16-641679 — 8.01
- 2016-06-22 0001193125-16-629055 — 1.01, 2.03, 8.01, 9.01
- 2016-06-21 0001193125-16-627071 — 8.01, 9.01
- 2016-06-10 0001193125-16-618483 — 2.02, 9.01
- 2016-06-09 0001193125-16-617893 — 8.01, 9.01

## late-filing notifications on or before 2019-12-09

- none on or before 2019-12-09

## item 2.02 — earnings release, exhibit 99.1

[0001571996-19-000042:8k_2_02:1]
EX-99.1
2
exhibit991earnings8kq3.htm
EXHIBIT 99.1

[0001571996-19-000042:8k_2_02:2]
Exhibit

[0001571996-19-000042:8k_2_02:3]
Exhibit 99.1

[0001571996-19-000042:8k_2_02:4]
News Release

[0001571996-19-000042:8k_2_02:5]
Strong Storage, VMware and PC Performance Power

[0001571996-19-000042:8k_2_02:6]
Dell Technologies’ Third Quarter Results

[0001571996-19-000042:8k_2_02:7]
ROUND ROCK, Texas — November 26, 2019

[0001571996-19-000042:8k_2_02:8]
News summary

[0001571996-19-000042:8k_2_02:9]
| • | Storage revenue up 7%; Client Solutions Group revenue up 5% |

[0001571996-19-000042:8k_2_02:10]
| • | VMware revenue up 11% |

[0001571996-19-000042:8k_2_02:11]
| • | Operating income of $836 million; non-GAAP operating income of $2.4 billion |

[0001571996-19-000042:8k_2_02:12]
| • | Cash flow from operations of $1.8 billion |

[0001571996-19-000042:8k_2_02:13]
| • | Diluted earnings per share of $0.66; non-GAAP diluted earnings per share of $1.75 |

[0001571996-19-000042:8k_2_02:14]
Full story

[0001571996-19-000042:8k_2_02:15]
Dell Technologies (NYSE: DELL) announces financial results for its fiscal 2020 third quarter.  Third quarter revenue was $22.8 billion, up 2 percent, and non-GAAP revenue was $22.9 billion, up 1 percent over the same period last year.  Operating income was $836 million1 compared to an operating loss of $356 million last year, and non-GAAP operating income was up 18 percent to $2.4 billion.  Net income was $552 million or 2.4 percent of revenue, non-GAAP net income was $1.4 billion or 6.3 percent of non-GAAP revenue, and adjusted EBITDA was $2.9 billion or 12.5 percent of non-GAAP revenue.  Cash flow from operations was $1.8 billion.  Diluted earnings per share was $0.66 and non-GAAP diluted earnings per share was $1.75.

[0001571996-19-000042:8k_2_02:16]
“Dell Technologies is innovating and integrating solutions across our entire portfolio to create the technology infrastructure of the future for our customers,” said Jeff Clarke, vice chairman, Dell Technologies.  “Our highly differentiated set of offerings enables us to continue to win in a consolidating industry, while also driving long-term value for all stakeholders.”

[0001571996-19-000042:8k_2_02:17]
1

[0001571996-19-000042:8k_2_02:18]
Third Quarter Fiscal 2020 Financial Results

[0001571996-19-000042:8k_2_02:19]
|  | Three Months Ended |  |  |  | Nine Months Ended |  |  |
|  | November 1, 2019 |  | November 2, 2018 |  | Change |  | November 1, 2019 |  | November 2, 2018 |  | Change |
|  | (in millions, except percentages; unaudited) |
| Total net revenue | $ | 22,844 |  |  | $ | 22,482 |  |  | 2% |  | $ | 68,122 |  |  | $ | 66,780 |  |  | 2% |
| Operating income (loss) | $ | 836 |  |  | $ | (356 | ) |  | 335% |  | $ | 1,905 |  |  | $ | (522 | ) |  | 465% |
| Net income (loss) | $ | 552 |  |  | $ | (895 | ) |  | 162% |  | $ | 5,113 |  |  | $ | (1,894 | ) |  | 370% |
| Non-GAAP net revenue | $ | 22,928 |  |  | $ | 22,651 |  |  | 1% |  | $ | 68,372 |  |  | $ | 67,316 |  |  | 2% |
| Non-GAAP operating income | $ | 2,442 |  |  | $ | 2,064 |  |  | 18% |  | $ | 7,381 |  |  | $ | 6,198 |  |  | 19% |
| Non-GAAP net income | $ | 1,445 |  |  | $ | 1,197 |  |  | 21% |  | $ | 4,405 |  |  | $ | 3,635 |  |  | 21% |
| Adjusted EBITDA | $ | 2,857 |  |  | $ | 2,426 |  |  | 18% |  | $ | 8,586 |  |  | $ | 7,268 |  |  | 18% |

[0001571996-19-000042:8k_2_02:20]
Information about Dell Technologies’ use of non-GAAP financial information is provided under “Non-GAAP Financial Measures” below. All comparisons in this press release are year-over-year unless otherwise noted.

[0001571996-19-000042:8k_2_02:21]
Dell Technologies ended the quarter with a cash and investments balance of $9.4 billion.  The company repaid approximately $1.1 billion of gross debt in the quarter and approximately $3.5 billion year-to-date.  The company has paid down more than $18 billion in gross debt over the three years since closing the EMC transaction and remains on track to repay approximately $5 billion of gross debt in fiscal 2020.

[0001571996-19-000042:8k_2_02:22]
“This quarter’s results were driven by the strength of our diverse model, with our storage, commercial client and VMware businesses performing very well,” said Tom Sweet, chief financial officer, Dell Technologies.  “We remain focused on long-term profitable growth, growing faster than competitors and the industry, growing operating income and EPS faster than revenue and generating strong cash flow over time.”

[0001571996-19-000042:8k_2_02:23]
Operating segments summary

[0001571996-19-000042:8k_2_02:24]
Client Solutions Group revenue for the third quarter was $11.4 billion, up 5 percent versus the third quarter of last year.  Commercial revenue grew 9 percent to $8.3 billion, and Consumer revenue was down 6 percent to $3.1 billion.  Operating income was $739 million or 6.5 percent of Client Solutions Group revenue.

[0001571996-19-000042:8k_2_02:25]
Key highlights:

[0001571996-19-000042:8k_2_02:26]
| • | Double-digit unit and revenue growth in commercial desktops and workstations |

[0001571996-19-000042:8k_2_02:27]
| • | Outperformed the PC industry, gaining year-over-year worldwide share in total and commercial client units2 |

[0001571996-19-000042:8k_2_02:28]
| • | Expanded PC as a service to include small businesses, offering growing companies full PC lifecycle management for a single, predictable price per month |

[0001571996-19-000042:8k_2_02:29]
2

[0001571996-19-000042:8k_2_02:30]
Infrastructure Solutions Group revenue for the third quarter was $8.4 billion, a 6 percent decrease year-over-year.  Storage revenue was $4.1 billion, up 7 percent year-over-year, while servers and networking decreased 16 percent to $4.2 billion.  Operating income was $1.0 billion for the third quarter or 11.9 percent of Infrastructure Solutions Group revenue.

[0001571996-19-000042:8k_2_02:31]
Key highlights:

[0001571996-19-000042:8k_2_02:32]
| • | Strong adoption of the Dell Technologies Cloud with recent customer wins in the logistics, transportation, financial, communications and retail sectors |

[0001571996-19-000042:8k_2_02:33]
| • | Continued strong demand for our leading HCI solutions, with VxRail orders up 82 percent year-over-year |

[0001571996-19-000042:8k_2_02:34]
| • | Announced availability of Dell EMC PowerOne autonomous infrastructure to make deploying, managing and consuming IT easier for organizations |

[0001571996-19-000042:8k_2_02:35]
VMware revenue was $2.5 billion for the third quarter, up 11 percent driven by broad-based strength across a diverse product portfolio.  Operating income for the third quarter was $717 million, or 28.9 percent of VMware revenue.

[0001571996-19-000042:8k_2_02:36]
Earlier this month at the Dell Technologies Summit, the company ushered in a new decade of responsibility and innovation with the announcement of moonshot goals that will propel the company’s social impact worldwide.  The ambitious goals are the linchpin of the company’s 2030 Progress Made Real plan, and are grounded in the belief that technology and data combined with human spirit are, and will always be, positive forces in the world.

[0001571996-19-000042:8k_2_02:37]
Conference call information

[0001571996-19-000042:8k_2_02:38]
As previously announced, the company will hold a conference call to discuss its third quarter performance and financial guidance today, November 26, 2019 at 4:30 p.m. CDT.  The conference call will be broadcast live over the internet and can be accessed at https://investors.delltechnologies.com/events-and-presentations/upcoming-events

[0001571996-19-000042:8k_2_02:39]
For those unable to listen to the live broadcast, an archived version will be available at the same location for one year.

[0001571996-19-000042:8k_2_02:40]
A slide presentation containing additional financial and operating information may be downloaded from Dell Technologies’ website at https://investors.delltechnologies.com/financial-information/quarterly-results

[0001571996-19-000042:8k_2_02:41]
About Dell Technologies

[0001571996-19-000042:8k_2_02:42]
Dell Technologies (NYSE:DELL) is a unique family of businesses that helps organizations and individuals build their digital future and transform how they work and live.  The company provides customers with the industry’s broadest and most innovative technology and services portfolio spanning from edge to core to cloud.  The Dell Technologies family includes Dell, Dell EMC, Pivotal, RSA, Secureworks, Virtustream and VMware.

[0001571996-19-000042:8k_2_02:43]
CONTACTS:

[0001571996-19-000042:8k_2_02:44]
Investor Relations: Investor_Relations@Dell.com

[0001571996-19-000042:8k_2_02:45]
Media Relations: Media.Relations@Dell.com

[0001571996-19-000042:8k_2_02:46]
# # #

[0001571996-19-000042:8k_2_02:47]
3

[0001571996-19-000042:8k_2_02:48]
Copyright © 2019 Dell Inc. or its subsidiaries.  All Rights Reserved. Dell Technologies, Dell, EMC and Dell EMC are trademarks of Dell Inc. or its subsidiaries.  Other trademarks may be trademarks of their respective owners.

[0001571996-19-000042:8k_2_02:49]
| 1 | Due to the EMC transaction, significant non-cash bridging items will remain between GAAP and non-GAAP results for the next few years. |

[0001571996-19-000042:8k_2_02:50]
| 2 | IDC WW Quarterly Personal Computing Device (PDC) Tracker CY19Q3. |

[0001571996-19-000042:8k_2_02:51]
Non-GAAP Financial Measures:

[0001571996-19-000042:8k_2_02:52]
This press release presents information about Dell Technologies’ non-GAAP net revenue, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP operating income, non-GAAP net income, non-GAAP net income attributable to non-controlling interests, non-GAAP net income attributable to Dell Technologies Inc. - basic, non-GAAP net income attributable to Dell Technologies Inc. - diluted, non-GAAP earnings per share attributable to Dell Technologies Inc. - basic, non-GAAP earnings per share attributable to Dell Technologies Inc. - diluted, EBITDA, and adjusted EBITDA, which are non-GAAP financial measures provided as a supplement to the results provided in accordance with generally accepted accounting principles in the United States of America (“GAAP”). A reconciliation of each non-GAAP financial measure to the most directly comparable historical GAAP financial measure is provided in the attached tables for each of the fiscal periods indicated.

[0001571996-19-000042:8k_2_02:53]
Special Note on Forward-Looking Statements:

[0001571996-19-000042:8k_2_02:54]
Dell Technologies’ results or events in future periods could differ materially from those expressed or implied by these forward-looking statements because of risks, uncertainties, and other factors that include, but are not limited to, the following: competitive pressures; Dell Technologies’ reliance on third-party suppliers for products and components, including reliance on single-source or limited-source suppliers; Dell Technologies’ ability to achieve favorable pricing from its vendors; adverse global economic conditions and instability in financial markets; Dell Technologies’ execution of its growth, business and acquisition strategies; the success of Dell Technologies’ cost efficiency measures; Dell Technologies’ ability to manage solutions and products and services transitions in an effective manner; Dell Technologies’ ability to deliver high-quality products and services; Dell Technologies’ foreign operations and ability to generate substantial non-U.S. net revenue; Dell Technologies’ product, customer, and geographic sales mix, and seasonal sales trends; the performance of Dell Technologies’ sales channel partners; access to the capital markets by Dell Technologies or its customers; weak economic conditions and additional regulation including tariffs and other effects of trade regulation; counterparty default risks; the loss by Dell Technologies of any services contracts with its customers, including government contracts, and its ability to perform such contracts at its estimated costs; Dell Technologies’ ability to develop and protect its proprietary intellectual property or obtain licenses to intellectual property developed by others on commercially reasonable and competitive terms; infrastructure disruptions, cyberattacks, or other data security breaches; Dell Technologies’ ability to hedge effectively its exposure to fluctuations in foreign currency exchange rates and interest rates; expiration of tax holidays or favorable tax rate structures, or unfavorable outcomes in tax audits and other tax compliance matters; impairment of portfolio investments; unfavorable results of legal proceedings; increased costs and additional regulations and requirements as a result of Dell Technologies’ operation as a public company; Dell Technologies’ ability to develop and maintain effective internal control over financial reporting; compliance requirements of changing environmental and safety laws; the effect of armed hostilities, terrorism, natural disasters, and public health issues; Dell Technologies’ substantial level of indebtedness; the impact of the financial performance of VMware; and the market volatility of Dell Technologies’ pension plan assets.

[0001571996-19-000042:8k_2_02:55]
This list of risks, uncertainties, and other factors is not complete. Dell Technologies discusses some of these matters more fully, as well as certain risk factors that could affect Dell Technologies’ business, financial condition, results of operations, and prospects, in its reports filed with the SEC, including Dell Technologies’ annual report on Form 10-K for the fiscal year ended February 1, 2019, quarterly reports on Form 10-Q, and current reports on Form 8-K. These filings are available for review through the SEC’s website at www.sec.gov. Any or all forward-looking statements Dell Technologies makes may turn out to be wrong and can be affected by inaccurate assumptions Dell Technologies might make or by known or unknown risks, uncertainties and other factors, including those identified in this press release. Accordingly, you should not place undue reliance on the forward-looking statements made in this press release, which speak only as of its date. Dell Technologies does not undertake to update, and expressly disclaims any duty to update, its forward-looking statements, whether as a result of circumstances or events that arise after the date they are made, new information, or otherwise.

[0001571996-19-000042:8k_2_02:56]
4

[0001571996-19-000042:8k_2_02:57]
DELL TECHNOLOGIES INC.

[0001571996-19-000042:8k_2_02:58]
Condensed Consolidated Statements of Income (Loss) and Related Financial Highlights

[0001571996-19-000042:8k_2_02:59]
(in millions, except percentages; unaudited)

[0001571996-19-000042:8k_2_02:60]
|  | Three Months Ended |  |  |  | Nine Months Ended |  |  |
|  | November 1, 2019 |  | November 2, 2018 |  | Change |  | November 1, 2019 |  | November 2, 2018 |  | Change |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Products | $ | 17,485 |  |  | $ | 17,625 |  |  | (1)% |  | $ | 52,349 |  |  | $ | 52,445 |  |  | —% |
| Services | 5,359 |  |  | 4,857 |  |  | 10% |  | 15,773 |  |  | 14,335 |  |  | 10% |
| Total net revenue | 22,844 |  |  | 22,482 |  |  | 2% |  | 68,122 |  |  | 66,780 |  |  | 2% |
| Cost of net revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Products | 13,558 |  |  | 14,565 |  |  | (7)% |  | 40,526 |  |  | 43,114 |  |  | (6)% |
| Services | 2,160 |  |  | 1,974 |  |  | 9% |  | 6,347 |  |  | 5,722 |  |  | 11% |
| Total cost of net revenue | 15,718 |  |  | 16,539 |  |  | (5)% |  | 46,873 |  |  | 48,836 |  |  | (4)% |
| Gross margin | 7,126 |  |  | 5,943 |  |  | 20% |  | 21,249 |  |  | 17,944 |  |  | 18% |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |
| Selling, general, and administrative | 5,028 |  |  | 5,159 |  |  | (3)% |  | 15,677 |  |  | 15,064 |  |  | 4% |
| Research and development | 1,262 |  |  | 1,140 |  |  | 11% |  | 3,667 |  |  | 3,402 |  |  | 8% |
| Total operating expenses | 6,290 |  |  | 6,299 |  |  | —% |  | 19,344 |  |  | 18,466 |  |  | 5% |
| Operating income (loss) | 836 |  |  | (356 | ) |  | 335% |  | 1,905 |  |  | (522 | ) |  | 465% |
| Interest and other, net | (677 | ) |  | (639 | ) |  | (6)% |  | (2,000 | ) |  | (1,564 | ) |  | (28)% |
| Income (loss) before income taxes | 159 |  |  | (995 | ) |  | 116% |  | (95 | ) |  | (2,086 | ) |  | 95% |
| Income tax benefit | (393 | ) |  | (100 | ) |  | (293)% |  | (5,208 | ) |  | (192 | ) |  | NM |
| Net income (loss) | 552 |  |  | (895 | ) |  | 162% |  | 5,113 |  |  | (1,894 | ) |  | 370% |
| Less: Net income (loss) attributable to non-controlling interests | 53 |  |  | (19 | ) |  | 379% |  | 905 |  |  | 117 |  |  | 674% |
| Net income (loss) attributable to Dell Technologies Inc. | $ | 499 |  |  | $ | (876 | ) |  | 157% |  | $ | 4,208 |  |  | $ | (2,011 | ) |  | 309% |
| Percentage of Total Net Revenue: |  |  |  |  |  |  |  |  |  |  |
| Gross margin | 31 | % |  | 26 | % |  |  |  | 31 | % |  | 27 | % |  |  |
| Selling, general, and administrative | 22 | % |  | 23 | % |  |  |  | 23 | % |  | 23 | % |  |  |
| Research and development | 6 | % |  | 5 | % |  |  |  | 5 | % |  | 5 | % |  |  |
| Operating expenses | 28 | % |  | 28 | % |  |  |  | 28 | % |  | 28 | % |  |  |
| Operating income (loss) | 4 | % |  | (2 | )% |  |  |  | 3 | % |  | (1 | )% |  |  |
| Income (loss) before income taxes | 1 | % |  | (4 | )% |  |  |  | — | % |  | (3 | )% |  |  |
| Net income (loss) | 2 | % |  | (4 | )% |  |  |  | 8 | % |  | (3 | )% |  |  |
| Income tax rate | (247.2 | )% |  | 10.1 | % |  |  |  | 5482.1 | % |  | 9.2 | % |  |  |

[0001571996-19-000042:8k_2_02:61]
5

[0001571996-19-000042:8k_2_02:62]
DELL TECHNOLOGIES INC.

[0001571996-19-000042:8k_2_02:63]
Consolidated Statements of Financial Position

[0001571996-19-000042:8k_2_02:64]
(in millions; unaudited)

[0001571996-19-000042:8k_2_02:65]
|  | November 1, 2019 |  | February 1, 2019 |
| ASSETS |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 8,555 |  |  | $ | 9,676 |  |
| Accounts receivable, net | 11,447 |  |  | 12,371 |  |
| Short-term financing receivables, net | 4,589 |  |  | 4,398 |  |
| Inventories, net | 3,257 |  |  | 3,649 |  |
| Other current assets | 6,924 |  |  | 6,044 |  |
| Total current assets | 34,772 |  |  | 36,138 |  |
| Property, plant, and equipment, net | 5,787 |  |  | 5,259 |  |
| Long-term investments | 838 |  |  | 1,005 |  |
| Long-term financing receivables, net | 4,465 |  |  | 4,224 |  |
| Goodwill | 41,688 |  |  | 40,089 |  |
| Intangible assets, net | 19,174 |  |  | 22,270 |  |
| Other non-current assets | 10,090 |  |  | 2,835 |  |
| Total assets | $ | 116,814 |  |  | $ | 111,820 |  |
| LIABILITIES, REDEEMABLE SHARES, AND STOCKHOLDERS’ EQUITY (DEFICIT) |
| Current liabilities: |  |  |  |
| Short-term debt | $ | 7,664 |  |  | $ | 4,320 |  |
| Accounts payable | 19,443 |  |  | 19,213 |  |
| Accrued and other | 8,161 |  |  | 8,495 |  |
| Short-term deferred revenue | 13,787 |  |  | 12,944 |  |
| Total current liabilities | 49,055 |  |  | 44,972 |  |
| Long-term debt | 44,727 |  |  | 49,201 |  |
| Long-term deferred revenue | 12,116 |  |  | 11,066 |  |
| Other non-current liabilities | 6,105 |  |  | 6,327 |  |
| Total liabilities | 112,003 |  |  | 111,566 |  |
| Redeemable shares | 934 |  |  | 1,196 |  |
| Stockholders’ equity (deficit): |  |  |  |
| Total Dell Technologies Inc. stockholders’ equity (deficit) | (1,804 | ) |  | (5,765 | ) |
| Non-controlling interests | 5,681 |  |  | 4,823 |  |
| Total stockholders’ equity (deficit) | 3,877 |  |  | (942 | ) |
| Total liabilities, redeemable shares, and stockholders’ equity (deficit) | $ | 116,814 |  |  | $ | 111,820 |  |

[0001571996-19-000042:8k_2_02:66]
6

[0001571996-19-000042:8k_2_02:67]
DELL TECHNOLOGIES INC.

[0001571996-19-000042:8k_2_02:68]
Condensed Consolidated Statements of Cash Flows

[0001571996-19-000042:8k_2_02:69]
(in millions; unaudited)

[0001571996-19-000042:8k_2_02:70]
|  | Three Months Ended |  | Nine Months Ended |
|  | November 1, 2019 |  | November 2, 2018 |  | November 1, 2019 |  | November 2, 2018 |
| Cash flows from operating activities: |  |  |  |  |  |  |  |
| Net income (loss) | $ | 552 |  |  | $ | (895 | ) |  | $ | 5,113 |  |  | $ | (1,894 | ) |
| Adjustments to reconcile net income (loss) to net cash provided by operating activities | 1,269 |  |  | 1,728 |  |  | 670 |  |  | 6,519 |  |
| Change in cash from operating activities | 1,821 |  |  | 833 |  |  | 5,783 |  |  | 4,625 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |
| Investments: |  |  |  |  |  |  |  |
| Purchases | (72 | ) |  | (24 | ) |  | (142 | ) |  | (912 | ) |
| Maturities and sales | 19 |  |  | 863 |  |  | 449 |  |  | 2,185 |  |
| Capital expenditures | (529 | ) |  | (300 | ) |  | (1,612 | ) |  | (861 | ) |
| Capitalized software development costs | (80 | ) |  | (86 | ) |  | (264 | ) |  | (246 | ) |
| Acquisition of businesses, net | (2,045 | ) |  | (493 | ) |  | (2,429 | ) |  | (493 | ) |
| Divestitures of businesses, net | — |  |  | — |  |  | — |  |  | 142 |  |
| Asset acquisitions, net | (8 | ) |  | (21 | ) |  | (8 | ) |  | (59 | ) |
| Asset dispositions, net | — |  |  | (6 | ) |  | (3 | ) |  | (12 | ) |
| Other | 16 |  |  | 8 |  |  | 27 |  |  | 35 |  |
| Change in cash from investing activities | (2,699 | ) |  | (59 | ) |  | (3,982 | ) |  | (221 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |
| Share repurchases for tax withholdings of equity awards | (44 | ) |  | (52 | ) |  | (407 | ) |  | (251 | ) |
| Proceeds from the issuance of common stock of subsidiaries | 143 |  |  | 114 |  |  | 294 |  |  | 767 |  |
| Repurchases of common stock of subsidiaries | (241 | ) |  | (1 | ) |  | (1,285 | ) |  | (1 | ) |
| Proceeds from debt | 5,455 |  |  | 1,806 |  |  | 17,656 |  |  | 6,443 |  |
| Repayments of debt | (5,037 | ) |  | (2,721 | ) |  | (18,948 | ) |  | (9,669 | ) |
| Other | 46 |  |  | (3 | ) |  | 90 |  |  | (133 | ) |
| Change in cash from financing activities | 322 |  |  | (857 | ) |  | (2,600 | ) |  | (2,844 | ) |
| Effect of exchange rate changes on cash, cash equivalents, and restricted cash | (38 | ) |  | (46 | ) |  | (100 | ) |  | (262 | ) |
| Change in cash, cash equivalents, and restricted cash | (594 | ) |  | (129 | ) |  | (899 | ) |  | 1,298 |  |
| Cash, cash equivalents, and restricted cash at beginning of the period | 9,935 |  |  | 15,805 |  |  | 10,240 |  |  | 14,378 |  |
| Cash, cash equivalents, and restricted cash at end of the period | $ | 9,341 |  |  | $ | 15,676 |  |  | $ | 9,341 |  |  | $ | 15,676 |  |

[0001571996-19-000042:8k_2_02:71]
7

[0001571996-19-000042:8k_2_02:72]
DELL TECHNOLOGIES INC.

[0001571996-19-000042:8k_2_02:73]
Segment Information

[0001571996-19-000042:8k_2_02:74]
(in millions, except percentages; unaudited; continued on next page)

[0001571996-19-000042:8k_2_02:75]
|  | Three Months Ended |  |  |  | Nine Months Ended |  |  |
|  | November 1, 2019 |  | November 2, 2018 |  | Change |  | November 1, 2019 |  | November 2, 2018 |  | Change |
| Infrastructure Solutions Group (ISG): |
| Net Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Servers and networking | $ | 4,241 |  |  | $ | 5,054 |  |  | (16)% |  | $ | 12,858 |  |  | $ | 14,700 |  |  | (13)% |
| Storage | 4,149 |  |  | 3,883 |  |  | 7% |  | 12,355 |  |  | 12,131 |  |  | 2% |
| Total ISG net revenue | $ | 8,390 |  |  | $ | 8,937 |  |  | (6)% |  | $ | 25,213 |  |  | $ | 26,831 |  |  | (6)% |
| Operating Income: |  |  |  |  |  |  |  |  |  |  |  |
| ISG operating income | $ | 996 |  |  | $ | 935 |  |  | 7% |  | $ | 2,889 |  |  | $ | 2,886 |  |  | —% |
| % of ISG net revenue | 12 | % |  | 10 | % |  |  |  | 11 | % |  | 11 | % |  |  |
| % of total reportable segment operating income | 41 | % |  | 43 | % |  |  |  | 39 | % |  | 45 | % |  |  |
| Client Solutions Group (CSG): |
| Net Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Commercial | $ | 8,330 |  |  | $ | 7,613 |  |  | 9% |  | $ | 25,714 |  |  | $ | 23,085 |  |  | 11% |
| Consumer | 3,080 |  |  | 3,292 |  |  | (6)% |  | 8,354 |  |  | 9,219 |  |  | (9)% |
| Total CSG net revenue | $ | 11,410 |  |  | $ | 10,905 |  |  | 5% |  | $ | 34,068 |  |  | $ | 32,304 |  |  | 5% |
| Operating Income: |  |  |  |  |  |  |  |  |  |  |  |
| CSG operating income | $ | 739 |  |  | $ | 447 |  |  | 65% |  | $ | 2,514 |  |  | $ | 1,405 |  |  | 79% |
| % of CSG net revenue | 6 | % |  | 4 | % |  |  |  | 7 | % |  | 4 | % |  |  |
| % of total reportable segment operating income | 30 | % |  | 21 | % |  |  |  | 34 | % |  | 22 | % |  |  |
| VMware: |
| Net Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Total VMware net revenue | $ | 2,483 |  |  | $ | 2,229 |  |  | 11% |  | $ | 7,231 |  |  | $ | 6,451 |  |  | 12% |
| Operating Income: |  |  |  |  |  |  |  |  |  |  |  |
| VMware operating income | $ | 717 |  |  | $ | 768 |  |  | (7)% |  | $ | 2,093 |  |  | $ | 2,117 |  |  | (1)% |
| % of VMware net revenue | 29 | % |  | 34 | % |  |  |  | 29 | % |  | 33 | % |  |  |
| % of total reportable segment operating income | 29 | % |  | 36 | % |  |  |  | 28 | % |  | 33 | % |  |  |

[0001571996-19-000042:8k_2_02:76]
8

[0001571996-19-000042:8k_2_02:77]
DELL TECHNOLOGIES INC.

[0001571996-19-000042:8k_2_02:78]
Segment Information

[0001571996-19-000042:8k_2_02:79]
(in millions, except percentages; unaudited; continued)

[0001571996-19-000042:8k_2_02:80]
|  | Three Months Ended |  | Nine Months Ended |
|  | November 1, 2019 |  | November 2, 2018 |  | November 1, 2019 |  | November 2, 2018 |
| Reconciliation to consolidated net revenue: |  |  |  |  |  |  |
| Reportable segment net revenue | $ | 22,283 |  |  | $ | 22,071 |  |  | $ | 66,512 |  |  | $ | 65,586 |  |
| Other businesses (a) | 644 |  |  | 583 |  |  | 1,859 |  |  | 1,736 |  |
| Unallocated transactions (b) | 1 |  |  | (3 | ) |  | 1 |  |  | (6 | ) |
| Impact of purchase accounting (c) | (84 | ) |  | (169 | ) |  | (250 | ) |  | (536 | ) |
| Total consolidated net revenue | $ | 22,844 |  |  | $ | 22,482 |  |  | $ | 68,122 |  |  | $ | 66,780 |  |
| Reconciliation to consolidated operating income (loss): |  |  |  |  |
| Reportable segment operating income | $ | 2,452 |  |  | $ | 2,150 |  |  | $ | 7,496 |  |  | $ | 6,408 |  |
| Other businesses (a) | (8 | ) |  | (40 | ) |  | (86 | ) |  | (139 | ) |
| Unallocated transactions (b) | (2 | ) |  | (46 | ) |  | (29 | ) |  | (71 | ) |
| Impact of purchase accounting (c) | (96 | ) |  | (193 | ) |  | (299 | ) |  | (630 | ) |
| Amortization of intangibles | (1,057 | ) |  | (1,546 | ) |  | (3,334 | ) |  | (4,594 | ) |
| Transaction-related expenses (d) | (76 | ) |  | (167 | ) |  | (165 | ) |  | (437 | ) |
| Stock-based compensation expense (e) | (322 | ) |  | (256 | ) |  | (886 | ) |  | (671 | ) |
| Other corporate expenses (f) | (55 | ) |  | (258 | ) |  | (792 | ) |  | (388 | ) |
| Total consolidated operating income (loss) | $ | 836 |  |  | $ | (356 | ) |  | $ | 1,905 |  |  | $ | (522 | ) |

[0001571996-19-000042:8k_2_02:81]
_________________

[0001571996-19-000042:8k_2_02:82]
| (a) | Pivotal, Secureworks, RSA Security, Virtustream, and Boomi constitute “Other businesses” and do not meet the requirements for a reportable segment, either individually or collectively. The results of Other businesses are not material to the Company’s overall results. |

[0001571996-19-000042:8k_2_02:83]
| (b) | Unallocated transactions includes other corporate items that are not allocated to Dell Technologies’ reportable segments. |

[0001571996-19-000042:8k_2_02:84]
| (c) | Impact of purchase accounting includes non-cash purchase accounting adjustments that are primarily related to the EMC merger transaction that closed in September 2016. |

[0001571996-19-000042:8k_2_02:85]
| (d) | Transaction-related expenses includes acquisition, integration, and divestiture related costs, as well as the costs incurred in the Class V transaction that closed in December 2018. |

[0001571996-19-000042:8k_2_02:86]
| (e) | Stock-based compensation expense consists of equity awards granted based on the estimated fair value of those awards at grant date. |

[0001571996-19-000042:8k_2_02:87]
| (f) | Other corporate expenses includes impairment charges and severance, facility action, and other costs. |

[0001571996-19-000042:8k_2_02:88]
9

[0001571996-19-000042:8k_2_02:89]
SUPPLEMENTAL SELECTED NON-GAAP FINANCIAL MEASURES

[0001571996-19-000042:8k_2_02:90]
These tables present information about the Company’s non-GAAP net revenue, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP operating income, non-GAAP net income, non-GAAP net income attributable to non-controlling interests, non-GAAP net income attributable to Dell Technologies Inc. - basic, non-GAAP net income attributable to Dell Technologies Inc. - diluted, non-GAAP earnings per share attributable to Dell Technologies Inc. - basic, non-GAAP earnings per share attributable to Dell Technologies Inc. - diluted, EBITDA, and adjusted EBITDA, which are non-GAAP financial measures provided as a supplement to the results provided in accordance with generally accepted accounting principles in the United States of America (“GAAP”). A detailed discussion of Dell Technologies’ reasons for including these non-GAAP financial measures, the limitations associated with these measures, the items excluded from these measures, and our reason for excluding those items are presented in “Management’s Discussion and Analysis of Financial Condition and Results of Operations - Non-GAAP Financial Measures” in our periodic reports filed with the SEC. Dell Technologies encourages investors to review the non-GAAP discussion in these reports in conjunction with the presentation of non-GAAP financial measures.

[0001571996-19-000042:8k_2_02:91]
10

[0001571996-19-000042:8k_2_02:92]
DELL TECHNOLOGIES INC.

[0001571996-19-000042:8k_2_02:93]
Selected Non-GAAP Financial Measures

[0001571996-19-000042:8k_2_02:94]
(in millions, except percentages; unaudited)

[0001571996-19-000042:8k_2_02:95]
|  | Three Months Ended |  |  |  | Nine Months Ended |  |  |
|  | November 1, 2019 |  | November 2, 2018 |  | Change |  | November 1, 2019 |  | November 2, 2018 |  | Change |
| Non-GAAP net revenue | $ | 22,928 |  |  | $ | 22,651 |  |  | 1% |  | $ | 68,372 |  |  | $ | 67,316 |  |  | 2% |
| Non-GAAP gross margin | $ | 7,768 |  |  | $ | 7,000 |  |  | 11% |  | $ | 23,188 |  |  | $ | 20,985 |  |  | 10% |
| % of non-GAAP net revenue | 34 | % |  | 31 | % |  |  |  | 34 | % |  | 31 | % |  |  |
| Non-GAAP operating expenses | $ | 5,326 |  |  | $ | 4,936 |  |  | 8% |  | $ | 15,807 |  |  | $ | 14,787 |  |  | 7% |
| % of non-GAAP net revenue | 23 | % |  | 22 | % |  |  |  | 23 | % |  | 22 | % |  |  |
| Non-GAAP operating income | $ | 2,442 |  |  | $ | 2,064 |  |  | 18% |  | $ | 7,381 |  |  | $ | 6,198 |  |  | 19% |
| % of non-GAAP net revenue | 11 | % |  | 9 | % |  |  |  | 11 | % |  | 9 | % |  |  |
| Non-GAAP net income (a) | $ | 1,445 |  |  | $ | 1,197 |  |  | 21% |  | $ | 4,405 |  |  | $ | 3,635 |  |  | 21% |
| % of non-GAAP net revenue | 6 | % |  | 5 | % |  |  |  | 6 | % |  | 5 | % |  |  |
| Adjusted EBITDA | $ | 2,857 |  |  | $ | 2,426 |  |  | 18% |  | $ | 8,586 |  |  | $ | 7,268 |  |  | 18% |
| % of non-GAAP net revenue | 12 | % |  | 11 | % |  |  |  | 13 | % |  | 11 | % |  |  |

[0001571996-19-000042:8k_2_02:96]
_________________

[0001571996-19-000042:8k_2_02:97]
| (a) | Non-GAAP net income has been recast to exclude fair value adjustments on equity investments, the corresponding tax effects of those adjustments, and discrete tax items. |

[0001571996-19-000042:8k_2_02:98]
11

[0001571996-19-000042:8k_2_02:99]
DELL TECHNOLOGIES INC.

[0001571996-19-000042:8k_2_02:100]
Reconciliation of Selected Non-GAAP Financial Measures

[0001571996-19-000042:8k_2_02:101]
(in millions, except percentages; unaudited; continued on next page)

[0001571996-19-000042:8k_2_02:102]
|  | Three Months Ended |  |  |  | Nine Months Ended |  |  |
|  | November 1, 2019 |  | November 2, 2018 |  | Change |  | November 1, 2019 |  | November 2, 2018 |  | Change |
| Net revenue | $ | 22,844 |  |  | $ | 22,482 |  |  | 2% |  | $ | 68,122 |  |  | $ | 66,780 |  |  | 2% |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Impact of purchase accounting | 84 |  |  | 169 |  |  |  |  | 250 |  |  | 536 |  |  |  |
| Non-GAAP net revenue | $ | 22,928 |  |  | $ | 22,651 |  |  | 1% |  | $ | 68,372 |  |  | $ | 67,316 |  |  | 2% |
| Gross margin | $ | 7,126 |  |  | $ | 5,943 |  |  | 20% |  | $ | 21,249 |  |  | $ | 17,944 |  |  | 18% |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 517 |  |  | 726 |  |  |  |  | 1,555 |  |  | 2,154 |  |  |  |
| Impact of purchase accounting | 86 |  |  | 171 |  |  |  |  | 255 |  |  | 549 |  |  |  |
| Transaction-related expenses | — |  |  | 102 |  |  |  |  | (5 | ) |  | 239 |  |  |  |
| Stock-based compensation expense | 33 |  |  | 20 |  |  |  |  | 91 |  |  | 54 |  |  |  |
| Other corporate expenses | 6 |  |  | 38 |  |  |  |  | 43 |  |  | 45 |  |  |  |
| Non-GAAP gross margin | $ | 7,768 |  |  | $ | 7,000 |  |  | 11% |  | $ | 23,188 |  |  | $ | 20,985 |  |  | 10% |
| Operating expenses | $ | 6,290 |  |  | $ | 6,299 |  |  | —% |  | $ | 19,344 |  |  | $ | 18,466 |  |  | 5% |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | (540 | ) |  | (820 | ) |  |  |  | (1,779 | ) |  | (2,440 | ) |  |  |
| Impact of purchase accounting | (10 | ) |  | (22 | ) |  |  |  | (44 | ) |  | (81 | ) |  |  |
| Transaction-related expenses | (76 | ) |  | (65 | ) |  |  |  | (170 | ) |  | (198 | ) |  |  |
| Stock-based compensation expense | (289 | ) |  | (236 | ) |  |  |  | (795 | ) |  | (617 | ) |  |  |
| Other corporate expenses | (49 | ) |  | (220 | ) |  |  |  | (749 | ) |  | (343 | ) |  |  |
| Non-GAAP operating expenses | $ | 5,326 |  |  | $ | 4,936 |  |  | 8% |  | $ | 15,807 |  |  | $ | 14,787 |  |  | 7% |
| Operating income (loss) | $ | 836 |  |  | $ | (356 | ) |  | 335% |  | $ | 1,905 |  |  | $ | (522 | ) |  | 465% |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 1,057 |  |  | 1,546 |  |  |  |  | 3,334 |  |  | 4,594 |  |  |  |
| Impact of purchase accounting | 96 |  |  | 193 |  |  |  |  | 299 |  |  | 630 |  |  |  |
| Transaction-related expenses | 76 |  |  | 167 |  |  |  |  | 165 |  |  | 437 |  |  |  |
| Stock-based compensation expense | 322 |  |  | 256 |  |  |  |  | 886 |  |  | 671 |  |  |  |
| Other corporate expenses | 55 |  |  | 258 |  |  |  |  | 792 |  |  | 388 |  |  |  |
| Non-GAAP operating income | $ | 2,442 |  |  | $ | 2,064 |  |  | 18% |  | $ | 7,381 |  |  | $ | 6,198 |  |  | 19% |

[0001571996-19-000042:8k_2_02:103]
12

[0001571996-19-000042:8k_2_02:104]
DELL TECHNOLOGIES INC.

[0001571996-19-000042:8k_2_02:105]
Reconciliation of Selected Non-GAAP Financial Measures

[0001571996-19-000042:8k_2_02:106]
(in millions, except percentages; unaudited; continued)

[0001571996-19-000042:8k_2_02:107]
|  | Three Months Ended |  |  |  | Nine Months Ended |  |  |
|  | November 1, 2019 |  | November 2, 2018 |  | Change |  | November 1, 2019 |  | November 2, 2018 |  | Change |
| Net income (loss) | $ | 552 |  |  | $ | (895 | ) |  | 162% |  | $ | 5,113 |  |  | $ | (1,894 | ) |  | 370% |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 1,057 |  |  | 1,546 |  |  |  |  | 3,334 |  |  | 4,594 |  |  |  |
| Impact of purchase accounting | 96 |  |  | 193 |  |  |  |  | 299 |  |  | 630 |  |  |  |
| Transaction-related expenses | 76 |  |  | 167 |  |  |  |  | 165 |  |  | 437 |  |  |  |
| Stock-based compensation expense | 322 |  |  | 256 |  |  |  |  | 886 |  |  | 671 |  |  |  |
| Other corporate expenses | 55 |  |  | 258 |  |  |  |  | 792 |  |  | 388 |  |  |  |
| Fair value adjustments on equity investments | (18 | ) |  | 17 |  |  |  |  | (160 | ) |  | (229 | ) |  |  |
| Aggregate adjustment for income taxes | (695 | ) |  | (345 | ) |  |  |  | (6,024 | ) |  | (962 | ) |  |  |
| Non-GAAP net income (a) | $ | 1,445 |  |  | $ | 1,197 |  |  | 21% |  | $ | 4,405 |  |  | $ | 3,635 |  |  | 21% |
| Net income (loss) | $ | 552 |  |  | $ | (895 | ) |  | 162% |  | $ | 5,113 |  |  | $ | (1,894 | ) |  | 370% |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Interest and other, net | 677 |  |  | 639 |  |  |  |  | 2,000 |  |  | 1,564 |  |  |  |
| Income tax benefit | (393 | ) |  | (100 | ) |  |  |  | (5,208 | ) |  | (192 | ) |  |  |
| Depreciation and amortization | 1,494 |  |  | 1,961 |  |  |  |  | 4,608 |  |  | 5,806 |  |  |  |
| EBITDA | $ | 2,330 |  |  | $ | 1,605 |  |  | 45% |  | $ | 6,513 |  |  | $ | 5,284 |  |  | 23% |
| EBITDA | $ | 2,330 |  |  | $ | 1,605 |  |  | 45% |  | $ | 6,513 |  |  | $ | 5,284 |  |  | 23% |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation expense | 322 |  |  | 256 |  |  |  |  | 886 |  |  | 671 |  |  |  |
| Impact of purchase accounting | 84 |  |  | 169 |  |  |  |  | 251 |  |  | 536 |  |  |  |
| Transaction-related expenses | 76 |  |  | 158 |  |  |  |  | 165 |  |  | 409 |  |  |  |
| Other corporate expenses | 45 |  |  | 238 |  |  |  |  | 771 |  |  | 368 |  |  |  |
| Adjusted EBITDA | $ | 2,857 |  |  | $ | 2,426 |  |  | 18% |  | $ | 8,586 |  |  | $ | 7,268 |  |  | 18% |

[0001571996-19-000042:8k_2_02:108]
_________________

[0001571996-19-000042:8k_2_02:109]
| (a) | Non-GAAP net income has been recast to exclude fair value adjustments on equity investments, the corresponding tax effects of those adjustments, and discrete tax items. |

[0001571996-19-000042:8k_2_02:110]
13

[0001571996-19-000042:8k_2_02:111]
DELL TECHNOLOGIES INC.

[0001571996-19-000042:8k_2_02:112]
Reconciliation of Selected Non-GAAP Financial Measures

[0001571996-19-000042:8k_2_02:113]
For the Three Months Ended November 1, 2019

[0001571996-19-000042:8k_2_02:114]
(in millions, except per share amounts; unaudited)

[0001571996-19-000042:8k_2_02:115]
|  | GAAP |  | Amortization of intangibles |  | Impact of purchase accounting |  | Transaction-related expenses |  | Stock-based compensation expense |  | Other corporate expenses |  | Fair value adjustments on equity investments |  | Aggregate adjustment for income taxes |  | Non-GAAP |
| Net income | $ | 552 |  |  | 1,057 |  |  | 96 |  |  | 76 |  |  | 322 |  |  | 55 |  |  | (18 | ) |  | (695 | ) |  | $ | 1,445 |  |
| Less: Net income attributable to non-controlling interests (a) | 53 |  |  | 75 |  |  | 5 |  |  | 13 |  |  | 55 |  |  | — |  |  | (50 | ) |  | (27 | ) |  | 124 |  |
| Net income attributable to Dell Technologies Inc. - basic | 499 |  |  | 982 |  |  | 91 |  |  | 63 |  |  | 267 |  |  | 55 |  |  | 32 |  |  | (668 | ) |  | 1,321 |  |
| Incremental dilution from VMware, Inc. attributable to Dell Technologies Inc. (b) | (6 | ) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | (6 | ) |
| Net income attributable to Dell Technologies Inc. - diluted | $ | 493 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 1,315 |  |
| Earnings per share - basic | $ | 0.69 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 1.82 |  |
| Earnings per share - diluted | $ | 0.66 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 1.75 |  |
| Weighted-average shares outstanding - basic | 725 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 725 |  |
| Weighted-average shares outstanding - diluted | 750 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 750 |  |

[0001571996-19-000042:8k_2_02:116]
_________________

[0001571996-19-000042:8k_2_02:117]
| (a) | Net income attributable to non-controlling interests is calculated by multiplying the minority interest percentage of VMware, Inc., Pivotal Software, Inc., and SecureWorks Corp. by their non-GAAP net income adjustments for the period presented. |

[0001571996-19-000042:8k_2_02:118]
| (b) | Incremental dilution from VMware, Inc. attributable to Dell Technologies Inc. represents the impact of VMware, Inc.’s dilutive securities on the diluted earnings per share of Dell Technologies Inc. and is calculated by multiplying the difference between VMware, Inc.’s basic and diluted earnings per share by the number of shares of VMware, Inc. common stock held by Dell Technologies Inc. |

[0001571996-19-000042:8k_2_02:119]
DELL TECHNOLOGIES INC.

[0001571996-19-000042:8k_2_02:120]
Reconciliation of Selected Non-GAAP Financial Measures

[0001571996-19-000042:8k_2_02:121]
For the Nine Months Ended November 1, 2019

[0001571996-19-000042:8k_2_02:122]
(in millions, except per share amounts; unaudited)

[0001571996-19-000042:8k_2_02:123]
|  | GAAP |  | Amortization of intangibles |  | Impact of purchase accounting |  | Transaction-related expenses |  | Stock-based compensation expense |  | Other corporate expenses |  | Fair value adjustments on equity investments |  | Aggregate adjustment for income taxes |  | Non-GAAP |
| Net income | $ | 5,113 |  |  | 3,334 |  |  | 299 |  |  | 165 |  |  | 886 |  |  | 792 |  |  | (160 | ) |  | (6,024 | ) |  | $ | 4,405 |  |
| Less: Net income attributable to non-controlling interests (a) | 905 |  |  | 219 |  |  | 17 |  |  | 18 |  |  | 152 |  |  | — |  |  | 24 |  |  | (971 | ) |  | 364 |  |
| Net income attributable to Dell Technologies Inc. - basic | 4,208 |  |  | 3,115 |  |  | 282 |  |  | 147 |  |  | 734 |  |  | 792 |  |  | (184 | ) |  | (5,053 | ) |  | 4,041 |  |
| Incremental dilution from VMware, Inc. attributable to Dell Technologies Inc. (b) | (81 | ) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | (25 | ) |
| Net income attributable to Dell Technologies Inc. - diluted | $ | 4,127 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 4,016 |  |
| Earnings per share - basic | $ | 5.84 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 5.61 |  |
| Earnings per share - diluted | $ | 5.50 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 5.35 |  |
| Weighted-average shares outstanding - basic | 720 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 720 |  |
| Weighted-average shares outstanding - diluted | 750 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 750 |  |

[0001571996-19-000042:8k_2_02:124]
_________________

[0001571996-19-000042:8k_2_02:125]
| (a) | Net income attributable to non-controlling interests is calculated by multiplying the minority interest percentage of VMware, Inc., Pivotal Software, Inc., and SecureWorks Corp. by their non-GAAP net income adjustments for the period presented. |

[0001571996-19-000042:8k_2_02:126]
| (b) | Incremental dilution from VMware, Inc. attributable to Dell Technologies Inc. represents the impact of VMware, Inc.’s dilutive securities on the diluted earnings per share of Dell Technologies Inc. and is calculated by multiplying the difference between VMware, Inc.’s basic and diluted earnings per share by the number of shares of VMware, Inc. common stock held by Dell Technologies Inc. |

[0001571996-19-000042:8k_2_02:127]
15
