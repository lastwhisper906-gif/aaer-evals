# DELL note change history — 0001571996-19-000039 → 0001571996-19-000051


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- added (2019-12-09):
[0001571996-19-000051:note_history:1]
NOTE 10 — COMMITMENTS AND CONTINGENCIES

- added (2019-12-09):
[0001571996-19-000051:note_history:2]
Securities Litigation — On May 21, 2014, a securities class action seeking compensatory damages was filed in the United States District Court for the Southern District of New York, captioned City of Pontiac General Employees’ Retirement System v. Dell Inc., et. al. (Case No. 1:14-cv-03644).  The action names as defendants Dell Inc. (“Dell”) and certain current and former executive officers, and alleges that Dell made false and misleading statements about Dell’s financial results and future prospects between February 21, 2012 and May 22, 2012, which resulted in artificially inflated stock prices.  The case was transferred to the United States District Court for the Western District of Texas under the same caption (Case No. 1:15-cv-00374), where the defendants filed a motion to dismiss.  On September 16, 2016, the Court denied the motion to dismiss.  On March 29, 2018, the Court granted the plaintiffs’ motion for class certification, and certified a class consisting of all purchasers of Dell common stock between February 22, 2012 and May 22, 2012.  Fact and expert discovery is now closed.  The parties have agreed to an immaterial settlement amount, and the Court has preliminarily approved the settlement.  Notice of the settlement was mailed to shareholders in October 2019.  Shareholders have until December 20, 2019 to opt out or object to the settlement.  A hearing for the final approval of the settlement is set for January 10, 2020.

- changed (2019-12-09):
[0001571996-19-000051:note_history:3]
Class Actions Related to the Class V Transaction — Four purported stockholders brought putative class action complaints arising out of the Class V transaction described in Note 14 of the Notes to the Condensed Consolidated Financial Statements.  The actions were captioned Hallandale Beach Police and Fire Retirement Plan v. Michael Dell et al. (Civil Action No. 2018-0816-JTL), Howard Karp v. Michael Dell et al. (Civil Action No. 2019-0032-JTL), Miramar Police Officers’ Retirement Plan v. Michael Dell et al. (Civil Action No. 2019-0049-JTL), and Steamfitters Local 449 Pension Plan v. Michael Dell et al. (Civil Action No. 2019-0115-JTL).  The four actions were consolidated into In Re Dell Class V Litigation (Consol. C.A. No. 2018-0816-JTL), which names as defendants the Company’s board of directors and certain stockholders of the Company, including Michael S. Dell.  The plaintiffs generally allege that the defendants breached their fiduciary duties to the former holders of Class V Common Stock in connection with the Class V transaction by allegedly causing the Company to enter into a transaction that favored the interests of the controlling stockholders at the expense of such former stockholders.  The plaintiffs filed an amended complaint on August 9, 2019 making substantially similar allegations to those described above.  The defendants filed a motion to dismiss the action on September 30, 2019.  The plaintiffs replied to the motion to dismiss on November 15, 2019, and the defendant’s reply is due December 13, 2019.  A ruling on the pending motion is expected in early 2020.
  (was, 2019-09-10, similarity 0.9021):
[0001571996-19-000039:note_history:3]
Class Actions Related to the Class V Transaction — Four purported stockholders brought putative class action complaints arising out of the Class V transaction described in Note 14 of the Notes to the Condensed Consolidated Financial Statements.  The actions were captioned Hallandale Beach Police and Fire Retirement Plan v. Michael Dell et al. (Civil Action No. 2018-0816-JTL), Howard Karp v. Michael Dell et al. (Civil Action No. 2019-0032-JTL), Miramar Police Officers’ Retirement Plan v. Michael Dell et al. (Civil Action No. 2019-0049-JTL), and Steamfitters Local 449 Pension Plan v. Michael Dell et al. (Civil Action No. 2019-0115-JTL).  The four actions were consolidated into In Re Dell Class V Litigation (Consol. C.A. No. 2018-0816-JTL), which names as defendants the Company’s board of directors and certain stockholders of the Company, including Michael S. Dell.  The plaintiffs generally allege that the defendants breached their fiduciary duties to the former holders of Class V Common Stock in connection with the Class V transaction by allegedly causing the Company to enter into a transaction that favored the interests of the controlling stockholders at the expense of such former stockholders.  The plaintiffs filed an amended complaint on August 9, 2019 making substantially similar allegations as described above.  The defendants intend to file a motion to dismiss the action, which will be due on September 30, 2019.

- changed (2019-12-09):
[0001571996-19-000051:note_history:4]
Copyright Levies — The Company is involved in various proceedings and negotiations regarding Dell’s obligation to collect and remit copyright levies in certain countries.  The Company continues to collect levies in countries where it has determined that local laws require payment.  The Company, along with other companies and/or industry associations, also continues to oppose levy schemes that do not comply with controlling law.  The Company does not currently anticipate that any of these matters will have a material adverse effect on its business, financial condition, results of operations, or cash flows.
  (was, 2019-09-10, similarity 0.9692):
[0001571996-19-000039:note_history:4]
Copyright Levies — The Company is involved in various proceedings and negotiations regarding Dell’s obligation to collect and remit copyright levies in certain European Union (“EU”) countries.  The Company continues to collect levies in EU countries where it has determined that local laws require payment.  The Company, along with other companies and/or industry associations, also continues to oppose levy schemes that do not comply with EU law.  The Company does not currently anticipate that any of these matters will have a material adverse effect on its business, financial condition, results of operations, or cash flows.

- added (2019-12-09):
[0001571996-19-000051:note_history:5]
As of November 1, 2019, the Company does not believe there is a reasonable possibility that a material loss exceeding the amounts already accrued for these or other proceedings or matters has been incurred.  However, since the ultimate resolution of any such proceedings and matters is inherently unpredictable, the Company’s business, financial condition, results of operations, or cash flows could be materially affected in any particular period by unfavorable outcomes in one or more of these proceedings or matters.  Whether the outcome of any claim, suit, assessment, investigation, or legal proceeding, individually or collectively, could have a material adverse effect on the Company’s business, financial condition, results of operations, or cash flows will depend on a number of variables, including the nature, timing, and amount of any associated expenses, amounts paid in settlement, damages, or other remedies or consequences.

- removed (2019-12-09):
[0001571996-19-000039:note_history:6]
Securities Litigation — On May 21, 2014, a securities class action seeking compensatory damages was filed in the United States District Court for the Southern District of New York, captioned City of Pontiac General Employees’ Retirement System v. Dell Inc., et. al. (Case No. 1:14-cv-03644).  The action names as defendants Dell Inc. (“Dell”)

- removed (2019-12-09):
[0001571996-19-000039:note_history:7]
and certain current and former executive officers, and alleges that Dell made false and misleading statements about Dell’s financial results and future prospects between February 21, 2012 and May 22, 2012, which resulted in artificially inflated stock prices.  The case was transferred to the United States District Court for the Western District of Texas under the same caption (Case No. 1:15-cv-00374), where the defendants filed a motion to dismiss.  On September 16, 2016, the Court denied the motion to dismiss.  On March 29, 2018, the Court granted the plaintiffs’ motion for class certification, and certified a class consisting of all purchasers of Dell common stock between February 22, 2012 and May 22, 2012.  Fact and expert discovery is now closed.  Dell filed a motion for summary judgment on February 18, 2019, which is pending before the Court.  The parties have been engaged in settlement discussions and have agreed to an immaterial settlement amount pending the Court’s preliminary approval in the next few months.

- removed (2019-12-09):
[0001571996-19-000039:note_history:8]
As of August 2, 2019, the Company does not believe there is a reasonable possibility that a material loss exceeding the amounts already accrued for these or other proceedings or matters has been incurred.  However, since the ultimate resolution of any such proceedings and matters is inherently unpredictable, the Company’s business, financial condition, results of operations, or cash flows could be materially affected in any particular period by unfavorable outcomes in one or more of these proceedings or matters.  Whether the outcome of any claim, suit, assessment, investigation, or legal proceeding, individually or collectively, could have a material adverse effect on the Company’s business, financial condition, results of operations, or cash flows will depend on a number of variables, including the nature, timing, and amount of any associated expenses, amounts paid in settlement, damages, or other remedies or consequences.


## us-gaap:CommitmentsAndContingenciesPolicyTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- added (2019-12-09):
[0001571996-19-000051:note_history:9]
Legal Matters


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2019-12-09):
[0001571996-19-000051:note_history:10]
At lease inception, the lease liability is measured at the present value of the lease payments over the lease term.  The operating lease ROU asset equals the lease liability adjusted for any initial direct costs, prepaid or deferred rent, and lease incentives.  The Company uses the implicit rate when readily determinable.  As most of the leases do not provide an implicit rate, the Company uses its incremental borrowing rate based on the information available at the commencement date to determine the present value of lease payments.  Incremental borrowing rates used to determine the present value of lease payments were derived by reference to the Company’s secured-debt yields corresponding to the lease commencement date.

- changed (2019-12-09):
[0001571996-19-000051:note_history:11]
Financing Receivables — Financing receivables are presented net of allowance for losses and consist of customer receivables and residual interest.  Customer receivables, gross includes amounts due from customers under revolving loans, fixed-term loans, fixed-term sales-type or direct financing leases, and accrued interest.  The Company has two portfolios, consisting of: (1) fixed-term leases and loans and (2) revolving loans, and assesses risk at the portfolio level to determine the appropriate allowance levels.  The portfolio segments are further segregated into classes based on products, customer type, and credit risk evaluation: (1) Revolving - Dell Preferred Account (“DPA”); (2) Revolving - Dell Business Credit (“DBC”); and (3) Fixed-term - Consumer and Commercial.  Fixed-term leases and loans are offered to qualified small and medium-sized businesses, large commercial accounts, governmental organizations, and educational entities.  Additionally, fixed-term loans are also offered to certain individual consumer customers.  Revolving loans are offered under private label credit financing programs.  The DPA revolving loan programs are primarily offered to individual consumer customers and the DBC revolving loan programs are primarily offered to small and medium-sized commercial customers.
  (was, 2019-09-10, similarity 0.9853):
[0001571996-19-000039:note_history:11]
Financing Receivables — Financing receivables are presented net of allowance for losses and consist of customer receivables and residual interest.  Customer receivables, gross includes amounts due from customers under revolving loans, fixed-term loans, fixed-term sales-type or direct financing leases, and accrued interest.  The Company has two portfolios, consisting of: (1) fixed-term leases and loans and (2) revolving loans, and assesses risk at the portfolio level to determine the appropriate allowance levels.  The portfolio segments are further segregated into classes based on products, customer type, and credit risk evaluation: (1) Revolving - Dell Preferred Account (“DPA”); (2) Revolving - Dell Business Credit (“DBC”); and (3) Fixed-term - Consumer and Commercial.  Fixed-term leases and loans are offered to qualified small and medium-sized businesses, large commercial accounts, governmental organizations, and educational entities.  Additionally, fixed-term loans are also offered to certain individual consumer customers.  Revolving loans are offered under private label credit financing programs.  The DPA revolving loan programs are offered to individual consumer customers and the DBC revolving loan programs are offered to small and medium-sized business customers.

- changed (2019-12-09):
[0001571996-19-000051:note_history:12]
The Company retains a residual interest in equipment leased under its fixed-term lease programs.  The amount of the residual interest is established at the inception of the lease based upon estimates of the value of the equipment at the end of the lease term using historical studies, industry data, and future value-at-risk demand valuation methods.  On a quarterly basis, the Company assesses the carrying amount of its recorded residual values for impairment.  Anticipated declines in specific future residual values that are considered to be other-than-temporary are recorded currently in earnings.  Generally, residual value risk on equipment under lease is not considered to be significant because of the existence of a secondary market with respect to the equipment.  The lease agreement also clearly defines applicable return conditions and remedies for non-compliance, to ensure that the leased equipment will be in good operating condition upon return.  Model changes and updates, as well as market strength and product acceptance, are monitored and adjustments are made to residual values in accordance with the significance of any such changes.  The remarketing sales staff works closely with customers and dealers to manage the sale of lease returns and the recovery of residual exposure.  As of November 1, 2019, the Company has not recorded significant residual value impairment.
  (was, 2019-09-10, similarity 0.9536):
[0001571996-19-000039:note_history:12]
The Company retains a residual interest in equipment leased under its fixed-term lease programs.  The amount of the residual interest is established at the inception of the lease based upon estimates of the value of the equipment at the end of the lease term using historical studies, industry data, and future value-at-risk demand valuation methods.  On a quarterly basis, the Company assesses the carrying amount of its recorded residual values for impairment.  Anticipated declines in specific future residual values that are considered to be other-than-temporary are recorded currently in earnings.  Generally, residual value risk on equipment under lease is not considered to be significant because of the existence of a secondary market with respect to the equipment.  The lease agreement also clearly defines applicable return conditions and remedies for non-compliance, to ensure that the leased equipment will be in good operating condition upon return.  Model changes and updates, as well as market strength and product acceptance, are monitored and adjustments are made to residual values in accordance with the significance of any such changes.  Remarketing sales staff works closely with customers and dealers to manage the sale of lease returns and the recovery of residual exposure.  As of August 2, 2019, the Company has not recorded significant residual value impairment.

- changed (2019-12-09):
[0001571996-19-000051:note_history:13]
Asset Securitization — The Company transfers certain U.S. and European customer loan and lease payments and associated equipment to Special Purpose Entities (“SPEs”) that meet the definition of a Variable Interest Entity (“VIE”) and are consolidated into the Consolidated Financial Statements.  These SPEs are bankruptcy-remote legal entities with separate assets and liabilities.  The purpose of the SPEs is to facilitate the funding of customer loan and lease payments and associated equipment in the capital markets.  These SPEs have entered into financing arrangements with multi-seller conduits that, in turn, issue asset-backed debt securities in the capital markets.  The asset securitizations in the SPEs are accounted for as secured borrowings.  See Note 4 of the Notes to the Condensed Consolidated Financial Statements for additional information on the impact of the consolidation.
  (was, 2019-09-10, similarity 0.9853):
[0001571996-19-000039:note_history:13]
Asset Securitization — The Company transfers certain U.S. and European customer loan and lease payments and associated equipment to Special Purpose Entities (“SPEs”) that meet the definition of a Variable Interest Entity (“VIE”) and are consolidated into the Consolidated Financial Statements.  These SPEs are bankruptcy-remote legal entities with separate assets and liabilities.  The purpose of the SPEs is to facilitate the funding of customer lease and loan payments and associated equipment in the capital markets.  These SPEs have entered into financing arrangements with multi-seller conduits that, in turn, issue asset-backed debt securities in the capital markets.  The asset securitizations in the SPEs are accounted for as secured borrowings.  See Note 4 of the Notes to the Condensed Consolidated Financial Statements for additional information on the impact of the consolidation.

- removed (2019-12-09):
[0001571996-19-000039:note_history:14]
At lease inception, the lease liability is measured at the present value of the lease payments over the lease term.  The operating lease ROU asset equals the lease liability adjusted for any initial direct costs, prepaid or deferred rent, and lease incentives.

- removed (2019-12-09):
[0001571996-19-000039:note_history:15]
The Company uses the implicit rate when readily determinable.  As most of the leases do not provide an implicit rate, the Company uses its incremental borrowing rate based on the information available at the commencement date to determine the present value of lease payments.  Incremental borrowing rates used to determine the present value of lease payments were derived by reference to the Company’s secured-debt yields corresponding to the lease commencement date.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2019-12-09):
[0001571996-19-000051:note_history:16]
|  | November 1, 2019 |  | February 1, 2019 |
|  | (in millions) |
| Secured Debt |  |  |  |
| Senior Secured Credit Facilities: |  |  |  |
| 4.24% Term Loan B Facility due September 2023 | $ | — |  |  | $ | 4,938 |  |
| 3.79% Term Loan B-1 Facility due September 2025 | 4,750 |  |  | — |  |
| 4.16% Term Loan A-2 Facility due September 2021 | — |  |  | 4,116 |  |
| 3.54% Term Loan A-4 Facility due December 2023 | 679 |  |  | 1,650 |  |
| 4.25% Term Loan A-5 Facility due December 2019 | — |  |  | 2,016 |  |
| 3.60% Term Loan A-6 Facility due March 2024 | 3,543 |  |  | — |  |
| First Lien Notes: |  |  |  |
| 3.48% due June 2019 | — |  |  | 3,750 |  |
| 4.42% due June 2021 | 4,500 |  |  | 4,500 |  |
| 5.45% due June 2023 | 3,750 |  |  | 3,750 |  |
| 4.00% due July 2024 | 1,000 |  |  | — |  |
| 6.02% due June 2026 | 4,500 |  |  | 4,500 |  |
| 4.90% due October 2026 | 1,750 |  |  | — |  |
| 5.30% due October 2029 | 1,750 |  |  | — |  |
| 8.10% due July 2036 | 1,500 |  |  | 1,500 |  |
| 8.35% due July 2046 | 2,000 |  |  | 2,000 |  |
| Unsecured Debt |  |  |  |
| Unsecured Notes and Debentures: |  |  |  |
| 5.875% due June 2019 | — |  |  | 600 |  |
| 4.625% due April 2021 | 400 |  |  | 400 |  |
| 7.10% due April 2028 | 300 |  |  | 300 |  |
| 6.50% due April 2038 | 388 |  |  | 388 |  |
| 5.40% due September 2040 | 264 |  |  | 264 |  |
| Senior Notes: |  |  |  |
| 5.875% due June 2021 | 1,075 |  |  | 1,625 |  |
| 7.125% due June 2024 | 1,625 |  |  | 1,625 |  |
| EMC Notes: |  |  |  |
| 2.650% due June 2020 | 2,000 |  |  | 2,000 |  |
| 3.375% due June 2023 | 1,000 |  |  | 1,000 |  |
| Public Subsidiary Debt |  |  |  |
| VMware Notes: |  |  |  |
| 2.30% due August 2020 | 1,250 |  |  | 1,250 |  |
| 2.95% due August 2022 | 1,500 |  |  | 1,500 |  |
| 3.90% due August 2027 | 1,250 |  |  | 1,250 |  |
| VMware Term Loan Facility | 600 |  |  | — |  |
| DFS Debt (Note 4) | 7,568 |  |  | 5,929 |  |
| Other |  |  |  |
| 4.18% Margin Loan Facility due April 2022 | 4,000 |  |  | 3,350 |  |
| Other | 84 |  |  | 38 |  |
| Total debt, principal amount | $ | 53,026 |  |  | $ | 54,239 |  |

- changed (2019-12-09):
[0001571996-19-000051:note_history:17]
|  | November 1, 2019 |  | February 1, 2019 |
|  | (in millions) |
| Total debt, principal amount | $ | 53,026 |  |  | $ | 54,239 |  |
| Unamortized discount, net of unamortized premium | (246 | ) |  | (271 | ) |
| Debt issuance costs | (389 | ) |  | (447 | ) |
| Total debt, carrying value | $ | 52,391 |  |  | $ | 53,521 |  |
| Total short-term debt, carrying value | $ | 7,664 |  |  | $ | 4,320 |  |
| Total long-term debt, carrying value | $ | 44,727 |  |  | $ | 49,201 |  |
  (was, 2019-09-10, similarity 0.9828):
[0001571996-19-000039:note_history:17]
|  | August 2, 2019 |  | February 1, 2019 |
|  | (in millions) |
| Total debt, principal amount | $ | 52,592 |  |  | $ | 54,239 |  |
| Unamortized discount, net of unamortized premium | (252 | ) |  | (271 | ) |
| Debt issuance costs | (418 | ) |  | (447 | ) |
| Total debt, carrying value | $ | 51,922 |  |  | $ | 53,521 |  |
| Total short-term debt, carrying value | $ | 5,949 |  |  | $ | 4,320 |  |
| Total long-term debt, carrying value | $ | 45,973 |  |  | $ | 49,201 |  |

- added (2019-12-09):
[0001571996-19-000051:note_history:18]
During the nine months ended November 1, 2019, the Company repaid $550 million principal amount of its 5.875% senior unsecured notes due June 2021, $600 million principal amount of its 5.875% senior unsecured notes due June 2019 upon maturity, $950 million principal amount of its Term Loan A-4 Facility, and approximately $136 million of principal amortization under its term loan facilities.  The Company also repaid $162.5 million principal amount as part of the Term Loan B Facility refinancing and the remaining principal amount of approximately $1,277 million of its Term Loan A-2 Facility in connection with the First Lien Notes issued on March 20, 2019, as described below under “Refinancing Transactions.”  Additionally, during the nine months ended November 1, 2019, the Company issued an additional $1.6 billion, net, in DFS debt to support the expansion of its financing receivables portfolio.

- changed (2019-12-09):
[0001571996-19-000051:note_history:19]
On March 13, 2019, the Company entered into an amendment to the credit agreement for the Senior Secured Credit Facilities to obtain a new senior secured Term Loan A-6 Facility in order to refinance the $5 billion aggregate principal amount of debt incurred in connection with the Class V transaction described in Note 14 of the Notes to the Condensed Consolidated Financial Statements.  The Term Loan A-6 Facility aggregate principal amount of $3,634 million matures on March 13, 2024, of which $2,839 million aggregate principal amount represents the amounts outstanding under the Term Loan A-2 Facility that rolled-over into the new facility.  Immediately after the rollover, an aggregate principal amount of $1,277 million remained outstanding under the Term Loan A-2 Facility.
  (was, 2019-09-10, similarity 0.8751):
[0001571996-19-000039:note_history:19]
On March 13, 2019, the Company entered into an amendment to the credit agreement for the Senior Secured Credit Facilities to obtain a new senior secured Term Loan A-6 Facility in order to refinance the $5 billion aggregate principal amount of debt incurred in connection with the Class V transaction described in Note 14 of the Notes to the Condensed Consolidated Financial Statements.  The Term Loan A-6 Facility aggregate principal amount of $3,634 million matures on March 13, 2024, of which $2,839 million aggregate principal amount represents the amounts outstanding under the Term Loan A-2 Facility that rolled-over into the new facility.  Immediately after the rollover, an aggregate principal amount of $1,277 million remained outstanding under the Term Loan A-2 Facility.  The Term Loan A-6 Facility amortizes quarterly and bears interest at the London Interbank Offered Rate (“LIBOR”) plus an applicable margin ranging from 1.25% to 2.00% or a base rate plus an applicable margin of 0.25% to 1.00%.

- changed (2019-12-09):
[0001571996-19-000051:note_history:20]
On March 20, 2019, Dell International L.L.C. and EMC Corporation, both of which are wholly-owned subsidiaries of Dell Technologies Inc., completed a private offering of multiple series of First Lien Notes in an aggregate principal amount of $4.5 billion.  The principal amount, interest rate, and maturity of each series of such First Lien Notes were $1,000 million of 4.00% First Lien Notes due July 15, 2024, $1,750 million of 4.90% First Lien Notes due October 1, 2026, and $1,750 million of 5.30% First Lien Notes due October 1, 2029.
  (was, 2019-09-10, similarity 0.9969):
[0001571996-19-000039:note_history:20]
On March 20, 2019, Dell International L.L.C. and EMC Corporation, both which are wholly-owned subsidiaries of Dell Technologies Inc., completed a private offering of multiple series of First Lien Notes in an aggregate principal amount of $4.5 billion.  The principal amount, interest rate, and maturity of each series of such First Lien Notes were $1,000 million of 4.00% First Lien Notes due July 15, 2024, $1,750 million of 4.90% First Lien Notes due October 1, 2026, and $1,750 million of 5.30% First Lien Notes due October 1, 2029.

- added (2019-12-09):
[0001571996-19-000051:note_history:21]
A majority of the proceeds from the First Lien Notes issued on March 20, 2019 was used to repay all of the outstanding $3,750 million principal amount of the 3.48% First Lien Notes due June 2019.  In addition, proceeds of approximately $800 million of borrowings under the new Term Loan A-6 Facility, the proceeds of the $650 million increase in the Margin Loan Facility, and a portion of the proceeds from the 2019 First Lien Notes were used to repay all $2,016 million of the Company’s outstanding amounts under the Term Loan A-5 Facility due December 2019.  During the three months ended May 3, 2019, the remaining proceeds available from the 2019 First Lien Notes were used to repay $550 million of outstanding amounts under the Term Loan A-2 Facility and to pay related premiums, accrued interest, fees, and expenses.  The Term Loan A-2 Facility was subsequently paid off as of August 2, 2019.

- added (2019-12-09):
[0001571996-19-000051:note_history:22]
On September 19, 2019, the Company entered into a sixth refinancing amendment to the Senior Secured Credit Agreement (the “Sixth Refinancing Amendment”) to refinance the Term Loan B Facility due September 2023 with a new term loan B facility consisting of an aggregate principal amount of $4,750 million refinancing term B-1 loans maturing on September 19, 2025 (“Term Loan B-1 Facility due September 2025” or “Term Loan B-1 Facility”).  The Company used the proceeds from the Term Loan B-1 Facility, together with other funds available, to repay $4,913 million of outstanding amounts under the Term Loan B Facility due September 2023 and to pay related accrued interest, fees and expenses.

- changed (2019-12-09):
[0001571996-19-000051:note_history:23]
The refinancing and amendments were evaluated in accordance with FASB ASC 470, “Debt-Modifications and Extinguishments.”  The amendment to the Margin Loan Agreement and the term debt refinancing were accounted for as modifications for all existing lenders and as new issuances for new lenders.  The First Lien Notes issued on March 20, 2019 were accounted for as new issuances for all lenders, and repayment of the Company’s outstanding amounts under the Term Loan A-5 Facility was accounted for as an extinguishment.  During the three months ended May 3, 2019, the Company capitalized $74.5 million in new fees paid to creditors as a result of the modifications and new issuances.  In addition, the Company recognized expenses of $32.3 million in unamortized costs and $7.1 million in new third-party costs during the three months ended May 3, 2019.  The Term Loan B Facility refinancing was accounted for as a modification for all existing lenders and as a new issuance for new lenders.  During the three months ended November 1, 2019, the Company capitalized $5.9 million in new fees paid to creditors as a result of the modifications and new issuances.  In addition, the Company recognized expenses of $1.5 million in unamortized costs and $5.1 million in new third-party costs during the three months ended November 1, 2019.
  (was, 2019-09-10, similarity 0.781):
[0001571996-19-000039:note_history:23]
The refinancing and amendments were evaluated in accordance with FASB ASC 470, “Debt-Modifications and Extinguishments.”  The amendment to the Margin Loan Agreement and the term debt refinancing were accounted for as modifications for all existing lenders and as new issuances for new lenders.  The First Lien Notes issued on March 20, 2019 were accounted for as new issuances for all lenders, and repayment of the Company’s outstanding amounts under the Term Loan A-5 Facility was accounted for as an extinguishment.  During the three months ended May 3, 2019, the Company capitalized $74.5 million in new fees paid to creditors as a result of the modifications and new issuances.  In addition, the Company recognized expenses of $32.3 million in unamortized costs and $7.1 million in new third-party costs during the three months ended May 3, 2019.

- changed (2019-12-09):
[0001571996-19-000051:note_history:24]
As of November 1, 2019, available borrowings under the Revolving Credit Facility totaled $4.5 billion.  The Senior Secured Credit Facilities provide that the borrowers have the right at any time, subject to customary conditions, to request incremental term loans or incremental revolving commitments.
  (was, 2019-09-10, similarity 0.9759):
[0001571996-19-000039:note_history:24]
As of August 2, 2019, available borrowings under the Revolving Credit Facility totaled $4.5 billion.  The Senior Secured Credit Facilities provide that the borrowers have the right at any time, subject to customary conditions, to request incremental term loans or incremental revolving commitments.

- added (2019-12-09):
[0001571996-19-000051:note_history:25]
Borrowings under the Senior Secured Credit Facilities bear interest at a rate per annum equal to an applicable margin, plus, at the borrowers’ option, either (a) a base rate, or (b) the London Interbank Offered Rate (“LIBOR”).  The Term Loan B-1 Facility bears interest at LIBOR plus an applicable margin of 2.00% or a base rate plus an applicable margin of 1.00%.  The Term Loan A-4 Facility and the Term Loan A-6 Facility bear interest at LIBOR plus an applicable margin ranging from 1.25% to 2.00% or a base rate plus an applicable margin ranging from 0.25% to 1.00%.  Interest is payable, in the case of loans bearing interest based on LIBOR, at the end of each interest period (but at least every three months), in arrears and, in the case of loans bearing interest based on the base rate, quarterly in arrears.

- added (2019-12-09):
[0001571996-19-000051:note_history:26]
The Term Loan B-1 Facility amortizes in equal quarterly installments in aggregate annual amounts equal to 1% of the original principal amount.  The Term Loan A-4 Facility amortizes in equal quarterly installments in aggregate annual amounts equal to 5% of the original principal amount in each of the first four years after the facility closing date of December 20, 2018, and 80% of the original principal amount in the fifth year after December 20, 2018.  The Term Loan A-6 Facility amortizes in equal quarterly installments in aggregate annual amounts equal to 5% of the original principal amount in each of the first four years after the facility closing date of March 13, 2019, and 80% of the original principal amount in the fifth year after March 13, 2019.  The Revolving Credit Facility has no amortization.

- added (2019-12-09):
[0001571996-19-000051:note_history:27]
First Lien Notes — The senior secured notes (collectively, the “First Lien Notes”) were issued on June 1, 2016 and March 20, 2019 in an aggregate principal amount of $20.0 billion and $4.5 billion, respectively.  As discussed above, during the three months ended May 3, 2019, the Company used a portion of the $4.5 billion proceeds from the First Lien Notes issued on March 20, 2019 to repay all of the outstanding $3,750 million principal amount of its 3.48% First Lien Notes due June 2019.  Interest on these borrowings is payable semiannually.  The First Lien Notes are secured on a pari passu basis with the Senior Secured Credit Facilities, on a first-priority basis by substantially all of the tangible and intangible assets of the issuers and guarantors that secure obligations under the Senior Secured Credit Facilities, including pledges of all capital stock of the issuers, Dell, and certain wholly-owned material subsidiaries of the issuers and the guarantors, subject to certain exceptions.

- changed (2019-12-09):
[0001571996-19-000051:note_history:28]
China Revolving Credit Facility — During the three months ended May 3, 2019, the Company renewed its credit agreement (the “China Revolving Credit Facility”) with a bank lender for a secured revolving loan facility in an aggregate principal amount not to exceed $500 million at an interest rate of LIBOR plus 0.6% per annum.  The facility will expire on February 26, 2020.  As of November 1, 2019, there were no outstanding borrowings under the China Revolving Credit Facility.
  (was, 2019-09-10, similarity 0.9075):
[0001571996-19-000039:note_history:28]
China Revolving Credit Facility — During the three months ended May 3, 2019, the Company renewed its credit agreement (the “China Revolving Credit Facility”) with a bank lender for a secured revolving loan facility in an aggregate principal amount not to exceed $500 million at an interest rate of LIBOR plus 0.6% per annum.  The facility will expire on February 26, 2020.  As of August 2, 2019, there were no outstanding borrowings under the China Revolving Credit Facility.

- changed (2019-12-09):
[0001571996-19-000051:note_history:29]
VMware Revolving Credit Facility — On September 12, 2017, VMware, Inc. entered into an unsecured credit agreement, establishing a revolving credit facility (the “VMware Revolving Credit Facility”) with a syndicate of lenders that provides the company with a borrowing capacity of up to $1.0 billion for VMware, Inc. general corporate purposes.  Commitments under the VMware Revolving Credit Facility are available for a period of five years, which may be extended, subject to the satisfaction of certain conditions, by up to two one year periods.  The credit agreement contains certain representations, warranties, and covenants.  Commitment fees, interest rates, and other terms of borrowing under the VMware Revolving Credit Facility may vary based on VMware, Inc.’s external credit ratings.  None of the net proceeds of such borrowings will be made available to support the operations or satisfy any corporate purposes of Dell Technologies, other than the operations and corporate purposes of VMware, Inc. and VMware, Inc.’s subsidiaries.  As of November 1, 2019, there were no outstanding borrowings under the VMware Revolving Credit Facility.
  (was, 2019-09-10, similarity 0.9859):
[0001571996-19-000039:note_history:29]
VMware Revolving Credit Facility — On September 12, 2017, VMware, Inc. entered into an unsecured credit agreement, establishing a revolving credit facility (the “VMware Revolving Credit Facility”) with a syndicate of lenders that provides the company with a borrowing capacity of up to $1.0 billion which may be used for VMware, Inc. general corporate purposes.  Commitments under the VMware Revolving Credit Facility are available for a period of five years, which may be extended, subject to the satisfaction of certain conditions, by up to two one year periods.  The credit agreement contains certain representations, warranties, and covenants.  Commitment fees, interest rates, and other terms of borrowing under the VMware Revolving Credit Facility may vary based on VMware, Inc.’s external credit ratings.  None of the net proceeds of such borrowings will be made available to support the operations or satisfy any corporate purposes of Dell Technologies, other than the operations and corporate purposes of VMware, Inc. and VMware, Inc.’s subsidiaries.  As of August 2, 2019, there were no outstanding borrowings under the VMware Revolving Credit Facility.

- added (2019-12-09):
[0001571996-19-000051:note_history:30]
VMware Term Loan Facility — On September 26, 2019, VMware, Inc. entered into a senior unsecured term loan facility (the “VMware Term Loan Facility”) with a syndicate of lenders that provides VMware, Inc. with a borrowing capacity of up to $2.0 billion for VMware, Inc. general corporate purposes.  VMware, Inc. may borrow against the VMware Term Loan Facility two times up to its borrowing capacity of $2.0 billion until February 7, 2020.  The VMware Term Loan Facility matures on the 364th day following the initial funding under the facility.  The VMware Term Loan Facility bears interest at LIBOR plus 0.75% to 1.25%, or an alternative base rate plus 0.00% to 0.25%, depending on VMware Inc.’s external credit ratings.  VMware, Inc. drew down $2.0 billion and repaid $1.4 billion during the three months ended November 1, 2019.  As of November 1, 2019, the outstanding balance was $600 million, and $1.4 billion remained available to be drawn down for future borrowing purposes.  The VMware Term Loan Facility contains certain representations, warranties, and covenants.  None of the net proceeds of such borrowings will be made available to support the operations or satisfy any corporate purposes of Dell Technologies, other than the operations and corporate purposes of VMware, Inc. and VMware, Inc.’s subsidiaries.

- changed (2019-12-09):
[0001571996-19-000051:note_history:31]
Margin Loan Facility — On April 12, 2017, the Company entered into the Margin Loan Facility in an aggregate principal amount of $2.0 billion.  In connection with the Class V transaction, on December 20, 2018, the Company amended the Margin Loan Facility to increase the aggregate principal amount to $3.35 billion.  In connection with obtaining the Term Loan A-6 Facility, the Company increased the aggregate principal amount of the Margin Loan Facility to $4.0 billion.  VMW Holdco LLC, a wholly-owned subsidiary of EMC, is the borrower under the Margin Loan Facility, which is secured by 60 million shares of Class B common stock of VMware, Inc. and 20 million shares of Class A common stock of VMware, Inc.  Loans under the Margin Loan Facility bear interest at a rate per annum payable, at the borrower’s option, either at (a) a base rate plus 1.25% per annum or (b) a LIBOR-based rate plus 2.25% per annum.  Interest under the Margin Loan Facility is payable quarterly.
  (was, 2019-09-10, similarity 0.9936):
[0001571996-19-000039:note_history:31]
Margin Loan Facility — On April 12, 2017, the Company entered into the Margin Loan Facility in an aggregate principal amount of $2.0 billion.  In connection with the Class V transaction, on December 20, 2018, the Company amended the Margin Loan Facility to increase the aggregate principal amount to $3.35 billion.  In connection with obtaining the Term Loan A-6 Facility, the Company increased the aggregate principal amount of the facility to $4.0 billion.  VMW Holdco LLC, a wholly-owned subsidiary of EMC, is the borrower under the Margin Loan Facility, which is secured by 60 million shares of Class B common stock of VMware, Inc. and 20 million shares of Class A common stock of VMware, Inc.  Loans under the Margin Loan Facility bear interest at a rate per annum payable, at the borrower’s option, either at (a) a base rate plus 1.25% per annum or (b) a LIBOR-based rate plus 2.25% per annum.  Interest under the Margin Loan Facility is payable quarterly.

- added (2019-12-09):
[0001571996-19-000051:note_history:32]
Pivotal Revolving Credit Facility — On September 7, 2017, Pivotal entered into a credit agreement (the “Pivotal Revolving Credit Facility”) that provided for a senior secured revolving loan facility in an aggregate principal amount not to exceed $100 million.   The credit facility contained customary representations, warranties, and covenants, including financial covenants.  During the three months ended November 1, 2019, the Pivotal Revolving Credit Facility was terminated.

- changed (2019-12-09):
[0001571996-19-000051:note_history:33]
The following table presents the aggregate future maturities of the Company’s debt as of November 1, 2019 for the periods indicated:
  (was, 2019-09-10, similarity 0.9449):
[0001571996-19-000039:note_history:33]
The following table presents the aggregate future maturities of the Company’s debt as of August 2, 2019 for the periods indicated:

- changed (2019-12-09):
[0001571996-19-000051:note_history:34]
|  | Maturities by Fiscal Year |
|  | 2020 (remaining three months) |  | 2021 |  | 2022 |  | 2023 |  | 2024 |  | Thereafter |  | Total |
|  | (in millions) |
| Senior Secured Credit Facilities and First Lien Notes | $ | 91 |  |  | $ | 184 |  |  | $ | 4,717 |  |  | $ | 286 |  |  | $ | 6,702 |  |  | $ | 17,742 |  |  | $ | 29,722 |  |
| Unsecured Notes and Debentures | — |  |  | — |  |  | 400 |  |  | — |  |  | — |  |  | 952 |  |  | 1,352 |  |
| Senior Notes and EMC Notes | — |  |  | 2,000 |  |  | 1,075 |  |  | — |  |  | 1,000 |  |  | 1,625 |  |  | 5,700 |  |
| VMware Notes | — |  |  | 1,850 |  |  | — |  |  | 1,500 |  |  | — |  |  | 1,250 |  |  | 4,600 |  |
| DFS Debt | 1,249 |  |  | 3,611 |  |  | 1,418 |  |  | 1,198 |  |  | 84 |  |  | 8 |  |  | 7,568 |  |
| Margin Loan Facility | — |  |  | — |  |  | — |  |  | 4,000 |  |  | — |  |  | — |  |  | 4,000 |  |
| Other | 11 |  |  | 21 |  |  | 7 |  |  | 8 |  |  | 7 |  |  | 30 |  |  | 84 |  |
| Total maturities, principal amount | 1,351 |  |  | 7,666 |  |  | 7,617 |  |  | 6,992 |  |  | 7,793 |  |  | 21,607 |  |  | 53,026 |  |
| Associated carrying value adjustments | — |  |  | (8 | ) |  | (57 | ) |  | (26 | ) |  | (53 | ) |  | (491 | ) |  | (635 | ) |
| Total maturities, carrying value amount | $ | 1,351 |  |  | $ | 7,658 |  |  | $ | 7,560 |  |  | $ | 6,966 |  |  | $ | 7,740 |  |  | $ | 21,116 |  |  | $ | 52,391 |  |
  (was, 2019-09-10, similarity 0.9953):
[0001571996-19-000039:note_history:34]
|  | Maturities by Fiscal Year |
|  | 2020 (remaining six months) |  | 2021 |  | 2022 |  | 2023 |  | 2024 |  | Thereafter |  | Total |
|  | (in millions) |
| Senior Secured Credit Facilities and First Lien Notes | $ | 116 |  |  | $ | 174 |  |  | $ | 4,732 |  |  | $ | 290 |  |  | $ | 11,722 |  |  | $ | 13,226 |  |  | $ | 30,260 |  |
| Unsecured Notes and Debentures | — |  |  | — |  |  | 400 |  |  | — |  |  | — |  |  | 952 |  |  | 1,352 |  |
| Senior Notes and EMC Notes | — |  |  | 2,000 |  |  | 1,625 |  |  | — |  |  | 1,000 |  |  | 1,625 |  |  | 6,250 |  |
| VMware Notes | — |  |  | 1,250 |  |  | — |  |  | 1,500 |  |  | — |  |  | 1,250 |  |  | 4,000 |  |
| DFS Debt | 2,140 |  |  | 3,051 |  |  | 980 |  |  | 438 |  |  | 36 |  |  | — |  |  | 6,645 |  |
| Margin Loan Facility | — |  |  | — |  |  | — |  |  | 4,000 |  |  | — |  |  | — |  |  | 4,000 |  |
| Other | 13 |  |  | 18 |  |  | 7 |  |  | 8 |  |  | 7 |  |  | 32 |  |  | 85 |  |
| Total maturities, principal amount | 2,269 |  |  | 6,493 |  |  | 7,744 |  |  | 6,236 |  |  | 12,765 |  |  | 17,085 |  |  | 52,592 |  |
| Associated carrying value adjustments | — |  |  | (5 | ) |  | (78 | ) |  | (28 | ) |  | (142 | ) |  | (417 | ) |  | (670 | ) |
| Total maturities, carrying value amount | $ | 2,269 |  |  | $ | 6,488 |  |  | $ | 7,666 |  |  | $ | 6,208 |  |  | $ | 12,623 |  |  | $ | 16,668 |  |  | $ | 51,922 |  |

- changed (2019-12-09):
[0001571996-19-000051:note_history:35]
As of November 1, 2019, the Company had certain consolidated subsidiaries that were designated as unrestricted subsidiaries for all purposes of the applicable credit agreements and the indentures governing the First Lien Notes and the Senior Notes.  Substantially all of the net assets of the Company’s consolidated subsidiaries were restricted, with the exception of the Company’s unrestricted subsidiaries, primarily VMware, Inc., Pivotal, Secureworks, and their respective subsidiaries, as of November 1, 2019.
  (was, 2019-09-10, similarity 0.972):
[0001571996-19-000039:note_history:35]
As of August 2, 2019, the Company had certain consolidated subsidiaries that were designated as unrestricted subsidiaries for all purposes of the applicable credit agreements and the indentures governing the First Lien Notes and the Senior Notes.  Substantially all of the net assets of the Company’s consolidated subsidiaries were restricted, with the exception of the Company’s unrestricted subsidiaries, primarily VMware, Inc., Pivotal, Secureworks, and their respective subsidiaries, as of August 2, 2019.

- changed (2019-12-09):
[0001571996-19-000051:note_history:36]
The Term Loan A-4 Facility, the Term Loan A-6 Facility, and the Revolving Credit Facility are subject to a first lien leverage ratio covenant that is tested at the end of each fiscal quarter of Dell with respect to Dell’s preceding four fiscal quarters.  The Company was in compliance with all financial covenants as of November 1, 2019.
  (was, 2019-09-10, similarity 0.9788):
[0001571996-19-000039:note_history:36]
The Term Loan A-4 Facility, the Term Loan A-6 Facility, and the Revolving Credit Facility are subject to a first lien leverage ratio covenant that is tested at the end of each fiscal quarter of Dell with respect to Dell’s preceding four fiscal quarters.  The Company was in compliance with all financial covenants as of August 2, 2019.

- removed (2019-12-09):
[0001571996-19-000039:note_history:37]
|  | August 2, 2019 |  | February 1, 2019 |
|  | (in millions) |
| Secured Debt |  |  |  |
| Senior Secured Credit Facilities: |  |  |  |
| 4.24% Term Loan B Facility due September 2023 | $ | 4,913 |  |  | $ | 4,938 |  |
| 4.16% Term Loan A-2 Facility due September 2021 | — |  |  | 4,116 |  |
| 3.99% Term Loan A-4 Facility due December 2023 | 1,009 |  |  | 1,650 |  |
| 4.25% Term Loan A-5 Facility due December 2019 | — |  |  | 2,016 |  |
| 4.07% Term Loan A-6 Facility due March 2024 | 3,588 |  |  | — |  |
| First Lien Notes: |  |  |  |
| 3.48% due June 2019 | — |  |  | 3,750 |  |
| 4.42% due June 2021 | 4,500 |  |  | 4,500 |  |
| 5.45% due June 2023 | 3,750 |  |  | 3,750 |  |
| 4.00% due July 2024 | 1,000 |  |  | — |  |
| 6.02% due June 2026 | 4,500 |  |  | 4,500 |  |
| 4.90% due October 2026 | 1,750 |  |  | — |  |
| 5.30% due October 2029 | 1,750 |  |  | — |  |
| 8.10% due July 2036 | 1,500 |  |  | 1,500 |  |
| 8.35% due July 2046 | 2,000 |  |  | 2,000 |  |
| Unsecured Debt |  |  |  |
| Unsecured Notes and Debentures: |  |  |  |
| 5.875% due June 2019 | — |  |  | 600 |  |
| 4.625% due April 2021 | 400 |  |  | 400 |  |
| 7.10% due April 2028 | 300 |  |  | 300 |  |
| 6.50% due April 2038 | 388 |  |  | 388 |  |
| 5.40% due September 2040 | 264 |  |  | 264 |  |
| Senior Notes: |  |  |  |
| 5.875% due June 2021 | 1,625 |  |  | 1,625 |  |
| 7.125% due June 2024 | 1,625 |  |  | 1,625 |  |
| EMC Notes: |  |  |  |
| 2.650% due June 2020 | 2,000 |  |  | 2,000 |  |
| 3.375% due June 2023 | 1,000 |  |  | 1,000 |  |
| VMware Notes: |  |  |  |
| 2.30% due August 2020 | 1,250 |  |  | 1,250 |  |
| 2.95% due August 2022 | 1,500 |  |  | 1,500 |  |
| 3.90% due August 2027 | 1,250 |  |  | 1,250 |  |
| DFS Debt (Note 4) | 6,645 |  |  | 5,929 |  |
| Other |  |  |  |
| 4.51% Margin Loan Facility due April 2022 | 4,000 |  |  | 3,350 |  |
| Other | 85 |  |  | 38 |  |
| Total debt, principal amount | $ | 52,592 |  |  | $ | 54,239 |  |

- removed (2019-12-09):
[0001571996-19-000039:note_history:38]
During the six months ended August 2, 2019, the Company repaid the remaining principal amount of approximately $1,277 million of its Term Loan A-2 Facility described below under “Refinancing Transactions,” $620 million principal amount of its Term Loan A-4 Facility, $600 million principal amount of  its 5.875% senior notes due June 2019 upon maturity, and approximately $91 million of principal amortization under its term loan facilities.  Additionally, during the six months ended August 2, 2019, the Company issued an additional $0.7 billion, net, in DFS debt to support the expansion of its financing receivables portfolio.

- removed (2019-12-09):
[0001571996-19-000039:note_history:39]
A majority of the proceeds from the First Lien Notes issued on March 20, 2019 was used to repay all of the outstanding $3,750 million First Lien Notes due June 2019.  In addition, proceeds of approximately $800 million of borrowings under the new Term Loan A-6 Facility, the proceeds of the $650 million increase in the Margin Loan Facility, and a portion of the proceeds from the 2019 First Lien Notes were used to repay all of the Company’s outstanding amounts under the Term Loan A-5 Facility due December 2019.  During the three months ended May 3, 2019, the remaining proceeds available from the 2019 First Lien Notes were used to repay $550 million of outstanding amounts under the Term Loan A-2 Facility and to pay related premiums, accrued interest, fees, and expenses.  The Term Loan A-2 Facility was subsequently paid off as of August 2, 2019.

- removed (2019-12-09):
[0001571996-19-000039:note_history:40]
Borrowings under the Senior Secured Credit Facilities bear interest at a rate per annum equal to an applicable margin, plus, at the borrowers’ option, either (a) a base rate, which, under the Term Loan B Facility, is subject to an interest rate floor of 1.75% per annum, and under all other borrowings is subject to an interest rate floor of 0% per annum, or (b) LIBOR, which, under the Term Loan B Facility, is subject to an interest rate floor of 0.75% per annum, and under all other borrowings is subject to an interest rate floor of 0% per annum.  Interest is payable, in the case of loans bearing interest based on LIBOR, at the end of each interest period (but at least every three months), in arrears and, in the case of loans bearing interest based on the base rate, quarterly in arrears.

- removed (2019-12-09):
[0001571996-19-000039:note_history:41]
The Term Loan B Facility amortizes in equal quarterly installments in aggregate annual amounts equal to 1% of the original principal amount.  The Term Loan A-4 Facility amortizes in equal quarterly installments in aggregate annual amounts equal to 5% of the original principal amount in each of the first four years after the facility closing date of December 20, 2018, and 80% of the original principal amount in the fifth year after December 20, 2018.  The Term Loan A-6 Facility amortizes in equal quarterly installments in aggregate annual amounts equal to 5% of the original principal amount in each of the first four years after the facility closing date of March 13, 2019, and 80% of the original principal amount in the fifth year after March 13, 2019.  The Revolving Credit Facility has no amortization.

- removed (2019-12-09):
[0001571996-19-000039:note_history:42]
First Lien Notes — The senior secured notes (collectively, the “First Lien Notes”) were issued on June 1, 2016 and March 20, 2019 in an aggregate principal amount of $20.0 billion and $4.5 billion, respectively.  As stated above, the Company used a portion of the $4.5 billion proceeds to repay all of the outstanding $3,750 million First Lien Notes due June 2019.  Interest on these borrowings is payable semiannually.  The First Lien Notes are secured on a pari passu basis with the Senior Secured Credit Facilities, on a first-priority basis by substantially all of the tangible and intangible assets of the issuers and guarantors that secure obligations under the Senior Secured Credit Facilities, including pledges of all capital stock of the issuers, Dell, and certain wholly-owned material subsidiaries of the issuers and the guarantors, subject to certain exceptions.

- removed (2019-12-09):
[0001571996-19-000039:note_history:43]
.

- removed (2019-12-09):
[0001571996-19-000039:note_history:44]
Pivotal Revolving Credit Facility — On September 7, 2017, Pivotal entered into a credit agreement (the “Pivotal Revolving Credit Facility”) that provides for a senior secured revolving loan facility in an aggregate principal amount not to exceed $100 million.  The credit facility contains customary representations, warranties, and covenants, including financial covenants.  The credit agreement will expire on September 8, 2020, unless it is terminated earlier.  None of the net proceeds of borrowings under the facility will be made available to support the operations or satisfy any corporate purposes of Dell Technologies, other than the operations and corporate purposes of Pivotal and Pivotal’s subsidiaries.  As of August 2, 2019, there were no outstanding borrowings under the Pivotal Revolving Credit Facility.


## us-gaap:ScheduleOfCarryingValuesAndEstimatedFairValuesOfDebtInstrumentsTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-12-09):
[0001571996-19-000051:note_history:45]
|  | November 1, 2019 |  | February 1, 2019 |
|  | Carrying Value |  | Fair Value |  | Carrying Value |  | Fair Value |
|  | (in billions) |
| Senior Secured Credit Facilities | $ | 8.9 |  |  | $ | 9.0 |  |  | $ | 12.5 |  |  | $ | 12.6 |  |
| First Lien Notes | $ | 20.5 |  |  | $ | 23.3 |  |  | $ | 19.8 |  |  | $ | 21.0 |  |
| Unsecured Notes and Debentures | $ | 1.2 |  |  | $ | 1.4 |  |  | $ | 1.8 |  |  | $ | 1.9 |  |
| Senior Notes | $ | 2.6 |  |  | $ | 2.8 |  |  | $ | 3.1 |  |  | $ | 3.4 |  |
| EMC Notes | $ | 3.0 |  |  | $ | 3.0 |  |  | $ | 3.0 |  |  | $ | 2.9 |  |
| VMware Notes and VMware Term Loan Facility | $ | 4.6 |  |  | $ | 4.7 |  |  | $ | 4.0 |  |  | $ | 3.9 |  |
| Margin Loan Facility | $ | 4.0 |  |  | $ | 4.0 |  |  | $ | 3.3 |  |  | $ | 3.4 |  |
  (was, 2019-09-10, similarity 0.8772):
[0001571996-19-000039:note_history:45]
|  | August 2, 2019 |  | February 1, 2019 |
|  | Carrying Value |  | Fair Value |  | Carrying Value |  | Fair Value |
|  | (in billions) |
| Senior Secured Credit Facilities | $ | 9.4 |  |  | $ | 9.5 |  |  | $ | 12.5 |  |  | $ | 12.6 |  |
| First Lien Notes | $ | 20.5 |  |  | $ | 22.8 |  |  | $ | 19.8 |  |  | $ | 21.0 |  |
| Unsecured Notes and Debentures | $ | 1.2 |  |  | $ | 1.4 |  |  | $ | 1.8 |  |  | $ | 1.9 |  |
| Senior Notes | $ | 3.2 |  |  | $ | 3.4 |  |  | $ | 3.1 |  |  | $ | 3.4 |  |
| EMC Notes | $ | 3.0 |  |  | $ | 3.0 |  |  | $ | 3.0 |  |  | $ | 2.9 |  |
| VMware Notes | $ | 4.0 |  |  | $ | 4.0 |  |  | $ | 4.0 |  |  | $ | 3.9 |  |
| Margin Loan Facility | $ | 4.0 |  |  | $ | 4.0 |  |  | $ | 3.3 |  |  | $ | 3.4 |  |


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2019-12-09):
[0001571996-19-000051:note_history:46]
|  | November 1, 2019 |  | February 1, 2019 |
|  | (in millions) |
| DFS U.S. debt: |  |  |  |
| Securitization facilities | $ | 2,019 |  |  | $ | 1,914 |  |
| Fixed-term securitization offerings | 3,003 |  |  | 2,303 |  |
| Other | 183 |  |  | 223 |  |
| Total DFS U.S. debt | 5,205 |  |  | 4,440 |  |
| DFS international debt: |  |  |  |
| Securitization facility | 716 |  |  | 584 |  |
| Other borrowings | 893 |  |  | 708 |  |
| Note payable | 198 |  |  | 197 |  |
| Dell Bank Senior Unsecured Eurobonds | 556 |  |  | — |  |
| Total DFS international debt | 2,363 |  |  | 1,489 |  |
| Total DFS debt | $ | 7,568 |  |  | $ | 5,929 |  |
| Total short-term DFS debt | $ | 3,576 |  |  | $ | 3,113 |  |
| Total long-term DFS debt | $ | 3,992 |  |  | $ | 2,816 |  |

- added (2019-12-09):
[0001571996-19-000051:note_history:47]
|  | November 1, 2019 |  | February 1, 2019 |
|  | (in millions) |
| Secured Debt |  |  |  |
| Senior Secured Credit Facilities: |  |  |  |
| 4.24% Term Loan B Facility due September 2023 | $ | — |  |  | $ | 4,938 |  |
| 3.79% Term Loan B-1 Facility due September 2025 | 4,750 |  |  | — |  |
| 4.16% Term Loan A-2 Facility due September 2021 | — |  |  | 4,116 |  |
| 3.54% Term Loan A-4 Facility due December 2023 | 679 |  |  | 1,650 |  |
| 4.25% Term Loan A-5 Facility due December 2019 | — |  |  | 2,016 |  |
| 3.60% Term Loan A-6 Facility due March 2024 | 3,543 |  |  | — |  |
| First Lien Notes: |  |  |  |
| 3.48% due June 2019 | — |  |  | 3,750 |  |
| 4.42% due June 2021 | 4,500 |  |  | 4,500 |  |
| 5.45% due June 2023 | 3,750 |  |  | 3,750 |  |
| 4.00% due July 2024 | 1,000 |  |  | — |  |
| 6.02% due June 2026 | 4,500 |  |  | 4,500 |  |
| 4.90% due October 2026 | 1,750 |  |  | — |  |
| 5.30% due October 2029 | 1,750 |  |  | — |  |
| 8.10% due July 2036 | 1,500 |  |  | 1,500 |  |
| 8.35% due July 2046 | 2,000 |  |  | 2,000 |  |
| Unsecured Debt |  |  |  |
| Unsecured Notes and Debentures: |  |  |  |
| 5.875% due June 2019 | — |  |  | 600 |  |
| 4.625% due April 2021 | 400 |  |  | 400 |  |
| 7.10% due April 2028 | 300 |  |  | 300 |  |
| 6.50% due April 2038 | 388 |  |  | 388 |  |
| 5.40% due September 2040 | 264 |  |  | 264 |  |
| Senior Notes: |  |  |  |
| 5.875% due June 2021 | 1,075 |  |  | 1,625 |  |
| 7.125% due June 2024 | 1,625 |  |  | 1,625 |  |
| EMC Notes: |  |  |  |
| 2.650% due June 2020 | 2,000 |  |  | 2,000 |  |
| 3.375% due June 2023 | 1,000 |  |  | 1,000 |  |
| Public Subsidiary Debt |  |  |  |
| VMware Notes: |  |  |  |
| 2.30% due August 2020 | 1,250 |  |  | 1,250 |  |
| 2.95% due August 2022 | 1,500 |  |  | 1,500 |  |
| 3.90% due August 2027 | 1,250 |  |  | 1,250 |  |
| VMware Term Loan Facility | 600 |  |  | — |  |
| DFS Debt (Note 4) | 7,568 |  |  | 5,929 |  |
| Other |  |  |  |
| 4.18% Margin Loan Facility due April 2022 | 4,000 |  |  | 3,350 |  |
| Other | 84 |  |  | 38 |  |
| Total debt, principal amount | $ | 53,026 |  |  | $ | 54,239 |  |

- changed (2019-12-09):
[0001571996-19-000051:note_history:48]
|  | November 1, 2019 |  | February 1, 2019 |
|  | (in millions) |
| Total debt, principal amount | $ | 53,026 |  |  | $ | 54,239 |  |
| Unamortized discount, net of unamortized premium | (246 | ) |  | (271 | ) |
| Debt issuance costs | (389 | ) |  | (447 | ) |
| Total debt, carrying value | $ | 52,391 |  |  | $ | 53,521 |  |
| Total short-term debt, carrying value | $ | 7,664 |  |  | $ | 4,320 |  |
| Total long-term debt, carrying value | $ | 44,727 |  |  | $ | 49,201 |  |
  (was, 2019-09-10, similarity 0.9828):
[0001571996-19-000039:note_history:48]
|  | August 2, 2019 |  | February 1, 2019 |
|  | (in millions) |
| Total debt, principal amount | $ | 52,592 |  |  | $ | 54,239 |  |
| Unamortized discount, net of unamortized premium | (252 | ) |  | (271 | ) |
| Debt issuance costs | (418 | ) |  | (447 | ) |
| Total debt, carrying value | $ | 51,922 |  |  | $ | 53,521 |  |
| Total short-term debt, carrying value | $ | 5,949 |  |  | $ | 4,320 |  |
| Total long-term debt, carrying value | $ | 45,973 |  |  | $ | 49,201 |  |

- removed (2019-12-09):
[0001571996-19-000039:note_history:49]
|  | August 2, 2019 |  | February 1, 2019 |
|  | (in millions) |
| DFS U.S. debt: |  |  |  |
| Securitization facilities | $ | 2,287 |  |  | $ | 1,914 |  |
| Fixed-term securitization offerings | 2,438 |  |  | 2,303 |  |
| Other | 201 |  |  | 223 |  |
| Total DFS U.S. debt | 4,926 |  |  | 4,440 |  |
| DFS international debt: |  |  |  |
| Securitization facility | 690 |  |  | 584 |  |
| Other borrowings | 831 |  |  | 708 |  |
| Note payable | 198 |  |  | 197 |  |
| Total DFS international debt | 1,719 |  |  | 1,489 |  |
| Total DFS debt | $ | 6,645 |  |  | $ | 5,929 |  |
| Total short-term DFS debt | $ | 3,703 |  |  | $ | 3,113 |  |
| Total long-term DFS debt | $ | 2,942 |  |  | $ | 2,816 |  |

- removed (2019-12-09):
[0001571996-19-000039:note_history:50]
|  | August 2, 2019 |  | February 1, 2019 |
|  | (in millions) |
| Secured Debt |  |  |  |
| Senior Secured Credit Facilities: |  |  |  |
| 4.24% Term Loan B Facility due September 2023 | $ | 4,913 |  |  | $ | 4,938 |  |
| 4.16% Term Loan A-2 Facility due September 2021 | — |  |  | 4,116 |  |
| 3.99% Term Loan A-4 Facility due December 2023 | 1,009 |  |  | 1,650 |  |
| 4.25% Term Loan A-5 Facility due December 2019 | — |  |  | 2,016 |  |
| 4.07% Term Loan A-6 Facility due March 2024 | 3,588 |  |  | — |  |
| First Lien Notes: |  |  |  |
| 3.48% due June 2019 | — |  |  | 3,750 |  |
| 4.42% due June 2021 | 4,500 |  |  | 4,500 |  |
| 5.45% due June 2023 | 3,750 |  |  | 3,750 |  |
| 4.00% due July 2024 | 1,000 |  |  | — |  |
| 6.02% due June 2026 | 4,500 |  |  | 4,500 |  |
| 4.90% due October 2026 | 1,750 |  |  | — |  |
| 5.30% due October 2029 | 1,750 |  |  | — |  |
| 8.10% due July 2036 | 1,500 |  |  | 1,500 |  |
| 8.35% due July 2046 | 2,000 |  |  | 2,000 |  |
| Unsecured Debt |  |  |  |
| Unsecured Notes and Debentures: |  |  |  |
| 5.875% due June 2019 | — |  |  | 600 |  |
| 4.625% due April 2021 | 400 |  |  | 400 |  |
| 7.10% due April 2028 | 300 |  |  | 300 |  |
| 6.50% due April 2038 | 388 |  |  | 388 |  |
| 5.40% due September 2040 | 264 |  |  | 264 |  |
| Senior Notes: |  |  |  |
| 5.875% due June 2021 | 1,625 |  |  | 1,625 |  |
| 7.125% due June 2024 | 1,625 |  |  | 1,625 |  |
| EMC Notes: |  |  |  |
| 2.650% due June 2020 | 2,000 |  |  | 2,000 |  |
| 3.375% due June 2023 | 1,000 |  |  | 1,000 |  |
| VMware Notes: |  |  |  |
| 2.30% due August 2020 | 1,250 |  |  | 1,250 |  |
| 2.95% due August 2022 | 1,500 |  |  | 1,500 |  |
| 3.90% due August 2027 | 1,250 |  |  | 1,250 |  |
| DFS Debt (Note 4) | 6,645 |  |  | 5,929 |  |
| Other |  |  |  |
| 4.51% Margin Loan Facility due April 2022 | 4,000 |  |  | 3,350 |  |
| Other | 85 |  |  | 38 |  |
| Total debt, principal amount | $ | 52,592 |  |  | $ | 54,239 |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-12-09):
[0001571996-19-000051:note_history:51]
The following table presents the aggregate future maturities of the Company’s debt as of November 1, 2019 for the periods indicated:
  (was, 2019-09-10, similarity 0.9449):
[0001571996-19-000039:note_history:51]
The following table presents the aggregate future maturities of the Company’s debt as of August 2, 2019 for the periods indicated:

- changed (2019-12-09):
[0001571996-19-000051:note_history:52]
|  | Maturities by Fiscal Year |
|  | 2020 (remaining three months) |  | 2021 |  | 2022 |  | 2023 |  | 2024 |  | Thereafter |  | Total |
|  | (in millions) |
| Senior Secured Credit Facilities and First Lien Notes | $ | 91 |  |  | $ | 184 |  |  | $ | 4,717 |  |  | $ | 286 |  |  | $ | 6,702 |  |  | $ | 17,742 |  |  | $ | 29,722 |  |
| Unsecured Notes and Debentures | — |  |  | — |  |  | 400 |  |  | — |  |  | — |  |  | 952 |  |  | 1,352 |  |
| Senior Notes and EMC Notes | — |  |  | 2,000 |  |  | 1,075 |  |  | — |  |  | 1,000 |  |  | 1,625 |  |  | 5,700 |  |
| VMware Notes | — |  |  | 1,850 |  |  | — |  |  | 1,500 |  |  | — |  |  | 1,250 |  |  | 4,600 |  |
| DFS Debt | 1,249 |  |  | 3,611 |  |  | 1,418 |  |  | 1,198 |  |  | 84 |  |  | 8 |  |  | 7,568 |  |
| Margin Loan Facility | — |  |  | — |  |  | — |  |  | 4,000 |  |  | — |  |  | — |  |  | 4,000 |  |
| Other | 11 |  |  | 21 |  |  | 7 |  |  | 8 |  |  | 7 |  |  | 30 |  |  | 84 |  |
| Total maturities, principal amount | 1,351 |  |  | 7,666 |  |  | 7,617 |  |  | 6,992 |  |  | 7,793 |  |  | 21,607 |  |  | 53,026 |  |
| Associated carrying value adjustments | — |  |  | (8 | ) |  | (57 | ) |  | (26 | ) |  | (53 | ) |  | (491 | ) |  | (635 | ) |
| Total maturities, carrying value amount | $ | 1,351 |  |  | $ | 7,658 |  |  | $ | 7,560 |  |  | $ | 6,966 |  |  | $ | 7,740 |  |  | $ | 21,116 |  |  | $ | 52,391 |  |
  (was, 2019-09-10, similarity 0.9953):
[0001571996-19-000039:note_history:52]
|  | Maturities by Fiscal Year |
|  | 2020 (remaining six months) |  | 2021 |  | 2022 |  | 2023 |  | 2024 |  | Thereafter |  | Total |
|  | (in millions) |
| Senior Secured Credit Facilities and First Lien Notes | $ | 116 |  |  | $ | 174 |  |  | $ | 4,732 |  |  | $ | 290 |  |  | $ | 11,722 |  |  | $ | 13,226 |  |  | $ | 30,260 |  |
| Unsecured Notes and Debentures | — |  |  | — |  |  | 400 |  |  | — |  |  | — |  |  | 952 |  |  | 1,352 |  |
| Senior Notes and EMC Notes | — |  |  | 2,000 |  |  | 1,625 |  |  | — |  |  | 1,000 |  |  | 1,625 |  |  | 6,250 |  |
| VMware Notes | — |  |  | 1,250 |  |  | — |  |  | 1,500 |  |  | — |  |  | 1,250 |  |  | 4,000 |  |
| DFS Debt | 2,140 |  |  | 3,051 |  |  | 980 |  |  | 438 |  |  | 36 |  |  | — |  |  | 6,645 |  |
| Margin Loan Facility | — |  |  | — |  |  | — |  |  | 4,000 |  |  | — |  |  | — |  |  | 4,000 |  |
| Other | 13 |  |  | 18 |  |  | 7 |  |  | 8 |  |  | 7 |  |  | 32 |  |  | 85 |  |
| Total maturities, principal amount | 2,269 |  |  | 6,493 |  |  | 7,744 |  |  | 6,236 |  |  | 12,765 |  |  | 17,085 |  |  | 52,592 |  |
| Associated carrying value adjustments | — |  |  | (5 | ) |  | (78 | ) |  | (28 | ) |  | (142 | ) |  | (417 | ) |  | (670 | ) |
| Total maturities, carrying value amount | $ | 2,269 |  |  | $ | 6,488 |  |  | $ | 7,666 |  |  | $ | 6,208 |  |  | $ | 12,623 |  |  | $ | 16,668 |  |  | $ | 51,922 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2019-12-09):
[0001571996-19-000051:note_history:53]
|  | Three Months Ended |  | Nine Months Ended |
|  | November 1, 2019 |  | November 2, 2018 |  | November 1, 2019 |  | November 2, 2018 |
|  | (in millions) |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |
| Infrastructure Solutions Group: |  |  |  |  |  |  |  |
| Servers and networking | $ | 4,241 |  |  | $ | 5,054 |  |  | $ | 12,858 |  |  | $ | 14,700 |  |
| Storage | 4,149 |  |  | 3,883 |  |  | 12,355 |  |  | 12,131 |  |
| Total ISG net revenue | 8,390 |  |  | 8,937 |  |  | 25,213 |  |  | 26,831 |  |
| Client Solutions Group: |  |  |  |  |  |  |  |
| Commercial | 8,330 |  |  | 7,613 |  |  | 25,714 |  |  | 23,085 |  |
| Consumer | 3,080 |  |  | 3,292 |  |  | 8,354 |  |  | 9,219 |  |
| Total CSG net revenue | 11,410 |  |  | 10,905 |  |  | 34,068 |  |  | 32,304 |  |
| VMware: |  |  |  |  |  |  |  |
| Total VMware net revenue | 2,483 |  |  | 2,229 |  |  | 7,231 |  |  | 6,451 |  |
| Total segment net revenue | $ | 22,283 |  |  | $ | 22,071 |  |  | $ | 66,512 |  |  | $ | 65,586 |  |
  (was, 2019-09-10, similarity 0.9206):
[0001571996-19-000039:note_history:53]
|  | Three Months Ended |  | Six Months Ended |
|  | August 2, 2019 |  | August 3, 2018 |  | August 2, 2019 |  | August 3, 2018 |
|  | (in millions) |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |
| Infrastructure Solutions Group: |  |  |  |  |  |  |  |
| Servers and networking | $ | 4,437 |  |  | $ | 5,061 |  |  | $ | 8,617 |  |  | $ | 9,646 |  |
| Storage | 4,184 |  |  | 4,166 |  |  | 8,206 |  |  | 8,248 |  |
| Total ISG net revenue | 8,621 |  |  | 9,227 |  |  | 16,823 |  |  | 17,894 |  |
| Client Solutions Group: |  |  |  |  |  |  |  |
| Commercial | 9,077 |  |  | 8,109 |  |  | 17,384 |  |  | 15,472 |  |
| Consumer | 2,671 |  |  | 3,019 |  |  | 5,274 |  |  | 5,927 |  |
| Total CSG net revenue | 11,748 |  |  | 11,128 |  |  | 22,658 |  |  | 21,399 |  |
| VMware: |  |  |  |  |  |  |  |
| Total VMware net revenue | 2,466 |  |  | 2,194 |  |  | 4,748 |  |  | 4,222 |  |
| Total segment net revenue | $ | 22,835 |  |  | $ | 22,549 |  |  | $ | 44,229 |  |  | $ | 43,515 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2019-12-09):
[0001571996-19-000051:note_history:54]
Deferred Revenue — Deferred revenue is recorded for support and deployment services, software maintenance, professional services, training, and software-as-a-service when the Company has a right to invoice or payments have been received for undelivered products or services where transfer of control has not occurred.  Revenue is recognized on these items when the revenue recognition criteria are met, generally resulting in ratable recognition over the contract term.  The Company also has deferred revenue related to undelivered hardware and professional services, consisting of installations and consulting engagements, which are recognized as the Company’s performance obligations under the contract are completed.
  (was, 2019-09-10, similarity 0.9838):
[0001571996-19-000039:note_history:54]
Deferred Revenue — Deferred revenue is recorded for support and deployment services, software maintenance, professional services, training, and SaaS when the Company has a right to invoice or payments have been received for undelivered products or services where transfer of control has not occurred.  Revenue is recognized on these items when the revenue recognition criteria are met, generally resulting in ratable recognition over the contract term.  The Company also has deferred revenue related to undelivered hardware and professional services, consisting of installations and consulting engagements, which are recognized as the Company’s performance obligations under the contract are completed.

- changed (2019-12-09):
[0001571996-19-000051:note_history:55]
|  | Three Months Ended |  | Nine Months Ended |
|  | November 1, 2019 |  | November 2, 2018 |  | November 1, 2019 |  | November 2, 2018 |
|  | (in millions) |
| Deferred revenue: |  |  |  |  |  |  |  |
| Deferred revenue at beginning of period | $ | 25,348 |  |  | $ | 21,700 |  |  | $ | 24,010 |  |  | $ | 20,816 |  |
| Revenue deferrals for new contracts and changes in estimates for pre-existing contracts (a) (b) | 5,326 |  |  | 4,852 |  |  | 16,201 |  |  | 14,165 |  |
| Revenue recognized (b) | (4,922 | ) |  | (4,409 | ) |  | (14,459 | ) |  | (12,838 | ) |
| Other (c) | 151 |  |  | — |  |  | 151 |  |  | — |  |
| Deferred revenue at end of period | $ | 25,903 |  |  | $ | 22,143 |  |  | $ | 25,903 |  |  | $ | 22,143 |  |
| Short-term deferred revenue | $ | 13,787 |  |  | $ | 12,079 |  |  | $ | 13,787 |  |  | $ | 12,079 |  |
| Long-term deferred revenue | $ | 12,116 |  |  | $ | 10,064 |  |  | $ | 12,116 |  |  | $ | 10,064 |  |
  (was, 2019-09-10, similarity 0.6829):
[0001571996-19-000039:note_history:55]
|  | Three Months Ended |  | Six Months Ended |
|  | August 2, 2019 |  | August 3, 2018 |  | August 2, 2019 |  | August 3, 2018 |
|  | (in millions) |
| Deferred revenue: |  |  |  |  |  |  |  |
| Deferred revenue at beginning of period | $ | 24,178 |  |  | $ | 20,959 |  |  | $ | 24,010 |  |  | $ | 20,816 |  |
| Revenue deferrals for new contracts and changes in estimates for pre-existing contracts (a) (b) | 5,975 |  |  | 4,988 |  |  | 10,875 |  |  | 9,313 |  |
| Revenue recognized (b) | (4,805 | ) |  | (4,247 | ) |  | (9,537 | ) |  | (8,429 | ) |
| Deferred revenue at end of period | $ | 25,348 |  |  | $ | 21,700 |  |  | $ | 25,348 |  |  | $ | 21,700 |  |
| Short-term deferred revenue | $ | 13,568 |  |  | $ | 11,965 |  |  | $ | 13,568 |  |  | $ | 11,965 |  |
| Long-term deferred revenue | $ | 11,780 |  |  | $ | 9,735 |  |  | $ | 11,780 |  |  | $ | 9,735 |  |

- added (2019-12-09):
[0001571996-19-000051:note_history:56]
| (b) | The Company conformed the presentation of certain deferred revenue rollforward activity for the three and nine months ended November 2, 2018 to align current year presentation. The beginning and ending deferred revenue liability balances remain unchanged. |

- added (2019-12-09):
[0001571996-19-000051:note_history:57]
(c)   Acquired deferred revenue from Carbon Black, Inc. by VMware, Inc. during the three months ended November 1, 2019. See Note 8 of the Notes to the Condensed Consolidated Financial Statements for additional information related to this acquisition.

- changed (2019-12-09):
[0001571996-19-000051:note_history:58]
Remaining Performance Obligations — Remaining performance obligations represent the aggregate amount of the transaction price allocated to performance obligations not delivered, or partially undelivered, as of the end of the reporting period.  Remaining performance obligations include deferred revenue plus unbilled amounts not yet recorded in deferred revenue.  The aggregate amount of the transaction price allocated to remaining performance obligations does not include amounts owed under cancelable contracts where there is no substantive termination penalty.
  (was, 2019-09-10, similarity 0.7242):
[0001571996-19-000039:note_history:58]
Remaining performance obligations include deferred revenue plus unbilled amounts not yet recorded in deferred revenue.  The aggregate amount of the transaction price allocated to remaining performance obligations does not include amounts owed under cancelable contracts where there is no substantive termination penalty.

- added (2019-12-09):
[0001571996-19-000051:note_history:59]
The value of the transaction price allocated to remaining performance obligations as of November 1, 2019 was approximately $34 billion.  The Company expects to recognize approximately 62% of remaining performance obligations as revenue in the next twelve months, and the remainder thereafter.

- removed (2019-12-09):
[0001571996-19-000039:note_history:60]
| (b) | The Company conformed the presentation of certain deferred revenue rollforward activity for the three and six months ended August 3, 2018 to align current year presentation. The beginning and ending deferred revenue liability balances remain unchanged. |

- removed (2019-12-09):
[0001571996-19-000039:note_history:61]
Remaining Performance Obligations — Remaining performance obligations represent the aggregate amount of the transaction price allocated to performance obligations not delivered, or partially undelivered, as of the end of the reporting period.

- removed (2019-12-09):
[0001571996-19-000039:note_history:62]
The value of the transaction price allocated to remaining performance obligations as of August 2, 2019 was approximately $33 billion.  The Company expects to recognize approximately 61% of remaining performance obligations as revenue in the next twelve months, and the remainder thereafter.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_current_note, score: 0.0

- removed (2019-12-09):
[0001571996-19-000039:note_history:63]
NOTE 20 — SUBSEQUENT EVENTS

- removed (2019-12-09):
[0001571996-19-000039:note_history:64]
VMware, Inc. Acquisition Agreements

- removed (2019-12-09):
[0001571996-19-000039:note_history:65]
Carbon Black  — VMware, Inc. entered into a definitive agreement to acquire Carbon Black, Inc. through a cash tender offer of $26.00 per share, resulting in an expected net cash payment of $1.9 billion by VMware, Inc.  Carbon Black, Inc. develops cloud-native endpoint security software.  The acquisition has been approved by the boards of directors of both VMware, Inc. and Carbon Black, Inc. and is expected to close during the second half of Fiscal 2020, subject to completion of the tender offer, regulatory approvals and other customary closing conditions.

- removed (2019-12-09):
[0001571996-19-000039:note_history:66]
Pivotal — VMware, Inc. entered into a definitive merger agreement (the “Merger Agreement”) to acquire Pivotal at a blended price per share of $11.71 per share, consisting of $15.00 per share in cash to the holders of Pivotal’s Class A common stock, and the exchange of VMware, Inc.’s Class B common stock for Pivotal’s Class B common stock held by Dell Technologies, at an exchange ratio of 0.0550 VMware, Inc. shares for each Pivotal share.  In aggregate, this transaction will result in an expected net cash payment of $0.8 billion by VMware, Inc. and the issuance of approximately 7.2 million shares of VMware, Inc.’s Class B common stock to Dell Technologies.  The VMware, Inc. Class B common stock issued to Dell Technologies would increase its ownership stake in VMware, Inc. by approximately 0.3 percentage points to 81.1% based on the shares outstanding as of the announcement of the Merger Agreement.  The acquisition has been approved by the boards of directors of both VMware, Inc. and Pivotal and is expected to close during the second half of Fiscal 2020, subject to approval of the Merger Agreement by Pivotal stockholders, regulatory approvals and other customary closing conditions.  The purchase of Pivotal will be accounted for as a transaction by entities under common control. Assets and liabilities transferred will be recorded at their historical carrying amounts on the date of the transfer, with no goodwill being recognized.

- removed (2019-12-09):
[0001571996-19-000039:note_history:67]
Support Agreement — In connection with VMware, Inc.’s entry into the Merger Agreement to acquire Pivotal as described above, Dell Technologies entered into a Consent and Support Agreement (the “Support Agreement”) with EMC Equity Assets LLC (“EMC Equity,” and together with Dell Technologies, the “Dell Stockholders”), VMware, Inc. and, solely with respect to certain sections therein, EMC and VMW Holdco LLC (“VMW Holdco”).  Each of EMC Equity, EMC, and VMW Holdco is a wholly owned subsidiary of Dell Technologies.  Pursuant to the Support Agreement, the Dell Stockholders have agreed, among other matters and subject to the terms and conditions therein, in their capacity as holders of shares of Pivotal, to vote in favor of adopting the Merger Agreement, the merger and each of the actions contemplated by the Merger Agreement.  The Dell Stockholders also have agreed to certain restrictions on transfer of their shares of the Class B common stock of Pivotal, as further set forth in the Support Agreement.  Additionally, pursuant to the Support Agreement, EMC and VMW Holdco, together as the holders of all of the outstanding shares of Class B common stock of VMware, Inc., irrevocably have consented to VMware, Inc. entering into the Merger Agreement and the consummation of the transactions contemplated thereby.  The Support Agreement provides that, subject to VMware, Inc.’s ability to consummate the Pivotal acquisition and prior to the transaction closing, VMware, Inc. and Dell Technologies will execute an amendment to the tax sharing agreement between the two companies.

- removed (2019-12-09):
[0001571996-19-000039:note_history:68]
Commitment For Senior Unsecured Term Loan Facility of VMware, Inc.

- removed (2019-12-09):
[0001571996-19-000039:note_history:69]
VMware, Inc. received a commitment from a financial institution for a senior unsecured 364-day term loan facility that would provide VMware, Inc. with a borrowing capacity of up to $2.0 billion (the “Commitment”), which, if funded, may be used for general corporate purposes.  The initial funding of the Commitment is subject to various customary conditions, including execution and delivery of the definitive loan agreement and related documentation.

- removed (2019-12-09):
[0001571996-19-000039:note_history:70]
Refinancing Transaction

- removed (2019-12-09):
[0001571996-19-000039:note_history:71]
On September 5, 2019, the Company initiated a refinancing of its existing $4.9 billion Term Loan B Facility due September 2023, which it intends to replace with a modified $4.0 billion Term Loan B Facility due 2025.  The transaction is expected to close on or about September 18, 2019.
