# DELL notes — 0001571996-19-000051


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0001571996-19-000051:notes:1]
Basis of Presentation — The accompanying unaudited Condensed Consolidated Financial Statements should be read in conjunction with the audited Consolidated Financial Statements and accompanying Notes filed with the U.S. Securities and Exchange Commission (“SEC”) in the Company’s Annual Report on Form 10-K for the fiscal year ended February 1, 2019.  These Condensed Consolidated Financial Statements have been prepared in accordance with accounting principles generally accepted in the United States of America (“GAAP”).  In the opinion of management, the accompanying Condensed Consolidated Financial Statements reflect all adjustments of a normal recurring nature considered necessary to fairly state the financial position of Dell Technologies Inc. as of November 1, 2019 and February 1, 2019, the results of its operations and corresponding comprehensive income (loss) for the three and nine months ended November 1, 2019 and November 2, 2018, and its cash flows for the nine months ended November 1, 2019 and November 2, 2018.


## us-gaap:ConsolidationPolicyTextBlock

[0001571996-19-000051:notes:2]
[same as prior period, unchanged from 0001571996-19-000039:notes:2]


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001571996-19-000051:notes:3]
Recently Issued Accounting Pronouncements

[0001571996-19-000051:notes:4]
Measurement of Credit Losses on Financial Instruments — In June 2016, the Financial Accounting Standards Board (“FASB”) issued amended guidance which replaces the current incurred loss impairment methodology for measurement of credit losses on financial instruments with a methodology that reflects expected credit losses and requires consideration of a broader range of reasonable and supportable information to inform credit loss estimates.  Public entities must adopt the new guidance for fiscal years beginning after December 15, 2019, and interim periods within those fiscal years, with early adoption permitted for fiscal periods beginning after December 15, 2018.  The Company is currently evaluating the impact that the standard will have on the Consolidated Financial Statements.

[0001571996-19-000051:notes:5]
Intangibles - Goodwill and Other - Internal-Use Software — In August 2018, the FASB issued guidance on a customer’s accounting for implementation costs incurred in a cloud-computing arrangement when hosted by a vendor.  In a hosting arrangement that is a service contract, certain implementation costs should be capitalized and amortized over the term of the arrangement.  Public entities must adopt the new guidance for fiscal years beginning after December 15, 2019, and interim periods within those fiscal years, with early adoption permitted for fiscal periods beginning after December 15, 2018.  The Company does not expect the adoption of this guidance to have a material impact on the Consolidated Financial Statements.

[0001571996-19-000051:notes:6]
Recently Adopted Accounting Pronouncements

[0001571996-19-000051:notes:7]
Leases — In February 2016, the FASB issued amended guidance on the accounting for leasing transactions.  The primary objective of this update is to increase transparency and comparability among organizations by requiring lessees to recognize a lease liability for the obligation to make lease payments and a right-of-use (“ROU”) asset for the right to use the underlying asset for the lease term.  The guidance also results in some changes to lessor accounting and requires additional disclosures about all leasing arrangements.

[0001571996-19-000051:notes:8]
The Company adopted the standard (the “new lease standard”) as of February 2, 2019 using the modified retrospective approach, with the cumulative-effect adjustment to the opening balance of stockholders’ equity (deficit) as of the adoption date.  The Company elected to apply the practical expedient using the transition option whereby prior comparative periods were not retrospectively adjusted in the Consolidated Financial Statements.  Accordingly, prior comparative periods have not been adjusted in the Condensed Consolidated Financial Statements.  The Company also elected the package of practical expedients which does not require reassessment of initial direct costs, classification of a lease, and definition of a lease.

[0001571996-19-000051:notes:9]
The adoption of the new lease standard resulted in the recognition of $1.6 billion in operating lease liabilities and related ROU assets on the Consolidated Statements of Financial Position.  The Company recorded an immaterial adjustment to stockholders’ equity (deficit) as of February 2, 2019 to reflect the cumulative effect of adoption of the new lease standard.  As of February 2, 2019, there were no material finance leases for which the Company was a lessee.

[0001571996-19-000051:notes:10]
In the area of lessor accounting, as of February 2, 2019, the Company began to originate operating leases due to the elimination of third-party residual value guarantee insurance from the sales-type lease classification test.  Leases that commenced prior to the adoption of the new lease standard were not reassessed or restated pursuant to the practical expedients elected.  Accordingly, there was no cumulative adjustment to stockholders’ equity (deficit) related to lessor accounting.

[0001571996-19-000051:notes:11]
See Note 4 and Note 5 of the Notes to the Condensed Consolidated Financial Statements for additional information about the Company’s leases from a lessor and lessee perspective, respectively.


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock

[0001571996-19-000051:notes:12]
[same as prior period, unchanged from 0001571996-19-000039:notes:12]

[0001571996-19-000051:notes:13]
[same as prior period, unchanged from 0001571996-19-000039:notes:13]

[0001571996-19-000051:notes:14]
[same as prior period, unchanged from 0001571996-19-000039:notes:14]

[0001571996-19-000051:notes:15]
At lease inception, the lease liability is measured at the present value of the lease payments over the lease term.  The operating lease ROU asset equals the lease liability adjusted for any initial direct costs, prepaid or deferred rent, and lease incentives.  The Company uses the implicit rate when readily determinable.  As most of the leases do not provide an implicit rate, the Company uses its incremental borrowing rate based on the information available at the commencement date to determine the present value of lease payments.  Incremental borrowing rates used to determine the present value of lease payments were derived by reference to the Company’s secured-debt yields corresponding to the lease commencement date.

[0001571996-19-000051:notes:16]
[same as prior period, unchanged from 0001571996-19-000039:notes:17]

[0001571996-19-000051:notes:17]
The Company has elected not to record leases with an initial term of 12 months or less on the Consolidated Statements of Financial Position.  Lease expense on such leases is recognized on a straight-line basis over the lease term.  The Company does not generate material sublease income and has no material related party leases.  The Company’s lease agreements do not contain any material residual value guarantees or material restrictive covenants.

[0001571996-19-000051:notes:18]
[same as prior period, unchanged from 0001571996-19-000039:notes:19]

[0001571996-19-000051:notes:19]
[same as prior period, unchanged from 0001571996-19-000039:notes:20]

[0001571996-19-000051:notes:20]
[same as prior period, unchanged from 0001571996-19-000039:notes:21]

[0001571996-19-000051:notes:21]
[same as prior period, unchanged from 0001571996-19-000039:notes:22]

[0001571996-19-000051:notes:22]
[same as prior period, unchanged from 0001571996-19-000039:notes:23]

[0001571996-19-000051:notes:23]
[same as prior period, unchanged from 0001571996-19-000039:notes:24]

[0001571996-19-000051:notes:24]
Financing Receivables — Financing receivables are presented net of allowance for losses and consist of customer receivables and residual interest.  Customer receivables, gross includes amounts due from customers under revolving loans, fixed-term loans, fixed-term sales-type or direct financing leases, and accrued interest.  The Company has two portfolios, consisting of: (1) fixed-term leases and loans and (2) revolving loans, and assesses risk at the portfolio level to determine the appropriate allowance levels.  The portfolio segments are further segregated into classes based on products, customer type, and credit risk evaluation: (1) Revolving - Dell Preferred Account (“DPA”); (2) Revolving - Dell Business Credit (“DBC”); and (3) Fixed-term - Consumer and Commercial.  Fixed-term leases and loans are offered to qualified small and medium-sized businesses, large commercial accounts, governmental organizations, and educational entities.  Additionally, fixed-term loans are also offered to certain individual consumer customers.  Revolving loans are offered under private label credit financing programs.  The DPA revolving loan programs are primarily offered to individual consumer customers and the DBC revolving loan programs are primarily offered to small and medium-sized commercial customers.

[0001571996-19-000051:notes:25]
The Company retains a residual interest in equipment leased under its fixed-term lease programs.  The amount of the residual interest is established at the inception of the lease based upon estimates of the value of the equipment at the end of the lease term using historical studies, industry data, and future value-at-risk demand valuation methods.  On a quarterly basis, the Company assesses the carrying amount of its recorded residual values for impairment.  Anticipated declines in specific future residual values that are considered to be other-than-temporary are recorded currently in earnings.  Generally, residual value risk on equipment under lease is not considered to be significant because of the existence of a secondary market with respect to the equipment.  The lease agreement also clearly defines applicable return conditions and remedies for non-compliance, to ensure that the leased equipment will be in good operating condition upon return.  Model changes and updates, as well as market strength and product acceptance, are monitored and adjustments are made to residual values in accordance with the significance of any such changes.  The remarketing sales staff works closely with customers and dealers to manage the sale of lease returns and the recovery of residual exposure.  As of November 1, 2019, the Company has not recorded significant residual value impairment.

[0001571996-19-000051:notes:26]
Asset Securitization — The Company transfers certain U.S. and European customer loan and lease payments and associated equipment to Special Purpose Entities (“SPEs”) that meet the definition of a Variable Interest Entity (“VIE”) and are consolidated into the Consolidated Financial Statements.  These SPEs are bankruptcy-remote legal entities with separate assets and liabilities.  The purpose of the SPEs is to facilitate the funding of customer loan and lease payments and associated equipment in the capital markets.  These SPEs have entered into financing arrangements with multi-seller conduits that, in turn, issue asset-backed debt securities in the capital markets.  The asset securitizations in the SPEs are accounted for as secured borrowings.  See Note 4 of the Notes to the Condensed Consolidated Financial Statements for additional information on the impact of the consolidation.


## us-gaap:FairValueDisclosuresTextBlock

[0001571996-19-000051:notes:27]
[same as prior period, unchanged from 0001571996-19-000039:notes:28]

[0001571996-19-000051:notes:28]
[same as prior period, unchanged from 0001571996-19-000039:notes:29]

[0001571996-19-000051:notes:29]
|  | November 1, 2019 |  | February 1, 2019 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | QuotedPricesin ActiveMarkets forIdenticalAssets |  | SignificantOtherObservableInputs |  | SignificantUnobservableInputs |  |  |  | QuotedPricesin ActiveMarkets forIdenticalAssets |  | SignificantOtherObservableInputs |  | SignificantUnobservableInputs |  |  |
|  | (in millions) |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | $ | 4,488 |  |  | $ | — |  |  | $ | — |  |  | $ | 4,488 |  |  | $ | 5,221 |  |  | $ | — |  |  | $ | — |  |  | $ | 5,221 |  |
| Equity and other securities | 11 |  |  | — |  |  | — |  |  | 11 |  |  | 314 |  |  | 20 |  |  | — |  |  | 334 |  |
| Derivative instruments | — |  |  | 119 |  |  | — |  |  | 119 |  |  | — |  |  | 97 |  |  | — |  |  | 97 |  |
| Total assets | $ | 4,499 |  |  | $ | 119 |  |  | $ | — |  |  | $ | 4,618 |  |  | $ | 5,535 |  |  | $ | 117 |  |  | $ | — |  |  | $ | 5,652 |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Derivative instruments | $ | — |  |  | $ | 67 |  |  | $ | — |  |  | $ | 67 |  |  | $ | — |  |  | $ | 60 |  |  | $ | — |  |  | $ | 60 |  |
| Total liabilities | $ | — |  |  | $ | 67 |  |  | $ | — |  |  | $ | 67 |  |  | $ | — |  |  | $ | 60 |  |  | $ | — |  |  | $ | 60 |  |

[0001571996-19-000051:notes:30]
[same as prior period, unchanged from 0001571996-19-000039:notes:31]

[0001571996-19-000051:notes:31]
Money Market Funds — The Company’s investment in money market funds that are classified as cash equivalents hold underlying investments with a weighted average maturity of 90 days or less and are recognized at fair value.  The valuations of these securities are based on quoted prices in active markets for identical assets, when available, or pricing models whereby all significant inputs are observable or can be derived from or corroborated by observable market data.  The Company reviews security pricing and assesses liquidity on a quarterly basis.  As of November 1, 2019, the Company’s U.S. portfolio had no material exposure to money market funds with a fluctuating net asset value.

[0001571996-19-000051:notes:32]
[same as prior period, unchanged from 0001571996-19-000039:notes:33]

[0001571996-19-000051:notes:33]
[same as prior period, unchanged from 0001571996-19-000039:notes:34]

[0001571996-19-000051:notes:34]
Deferred Compensation Plans —The Company offers deferred compensation plans for eligible employees, which allow participants to defer payment for a portion of their compensation.  Assets were the same as liabilities associated with the plans at approximately $239 million and $192 million as of November 1, 2019 and February 1, 2019, respectively, and are included in other assets and other liabilities on the Condensed Consolidated Statements of Financial Position.  The net impact to the Condensed Consolidated Statements of Income (Loss) is not material since changes in the fair value of the assets substantially offset changes in the fair value of the liabilities.  As such, assets and liabilities associated with these plans have not been included in the recurring fair value table above.  These fair values were determined based on observable market prices in a less active market or based on valuation methodologies using observable inputs and were categorized as Level 2 in the fair value hierarchy.

[0001571996-19-000051:notes:35]
[same as prior period, unchanged from 0001571996-19-000039:notes:36]

[0001571996-19-000051:notes:36]
As of November 1, 2019 and February 1, 2019, the Company held private strategic investments of $827 million and $671 million, respectively.  As these investments represent early-stage companies without readily determinable fair values, they are not included in the recurring fair value table above.

[0001571996-19-000051:notes:37]
[same as prior period, unchanged from 0001571996-19-000039:notes:38]

[0001571996-19-000051:notes:38]
[same as prior period, unchanged from 0001571996-19-000039:notes:39]

[0001571996-19-000051:notes:39]
|  | November 1, 2019 |  | February 1, 2019 |
|  | Carrying Value |  | Fair Value |  | Carrying Value |  | Fair Value |
|  | (in billions) |
| Senior Secured Credit Facilities | $ | 8.9 |  |  | $ | 9.0 |  |  | $ | 12.5 |  |  | $ | 12.6 |  |
| First Lien Notes | $ | 20.5 |  |  | $ | 23.3 |  |  | $ | 19.8 |  |  | $ | 21.0 |  |
| Unsecured Notes and Debentures | $ | 1.2 |  |  | $ | 1.4 |  |  | $ | 1.8 |  |  | $ | 1.9 |  |
| Senior Notes | $ | 2.6 |  |  | $ | 2.8 |  |  | $ | 3.1 |  |  | $ | 3.4 |  |
| EMC Notes | $ | 3.0 |  |  | $ | 3.0 |  |  | $ | 3.0 |  |  | $ | 2.9 |  |
| VMware Notes and VMware Term Loan Facility | $ | 4.6 |  |  | $ | 4.7 |  |  | $ | 4.0 |  |  | $ | 3.9 |  |
| Margin Loan Facility | $ | 4.0 |  |  | $ | 4.0 |  |  | $ | 3.3 |  |  | $ | 3.4 |  |

[0001571996-19-000051:notes:40]
[same as prior period, unchanged from 0001571996-19-000039:notes:41]

[0001571996-19-000051:notes:41]
[same as prior period, unchanged from 0001571996-19-000039:notes:42]

[0001571996-19-000051:notes:42]
[same as prior period, unchanged from 0001571996-19-000039:notes:43]

[0001571996-19-000051:notes:43]
|  | November 1, 2019 |  | February 1, 2019 |
|  | Cost |  | Unrealized Gain |  | Unrealized (Loss) |  | Carrying Value |  | Cost |  | Unrealized Gain |  | Unrealized (Loss) |  | Carrying Value |
|  | (in millions) |
| Equity and other securities | $ | 776 |  |  | $ | 94 |  |  | $ | (32 | ) |  | $ | 838 |  |  | $ | 638 |  |  | $ | 539 |  |  | $ | (172 | ) |  | $ | 1,005 |  |

[0001571996-19-000051:notes:44]
For the nine months ended November 1, 2019, the equity and other securities without readily determinable fair values of $827 million increased by $88 million, due to upward adjustments for observable price changes, offset by $12 million of downward adjustments that were primarily attributable to impairments.  The remainder of equity and other securities consists of publicly-traded investments that are measured at fair value on a recurring basis.


## us-gaap:LoansNotesTradeAndOtherReceivablesDisclosureTextBlock

[0001571996-19-000051:notes:45]
NOTE 4 — FINANCIAL SERVICES

[0001571996-19-000051:notes:46]
The Company offers or arranges various financing options, services, and alternative payment structures for its customers in North America, Europe, Australia, and New Zealand through DFS.  The Company also arranges financing for some of its customers in various countries where DFS does not currently operate as a captive enterprise.  The key activities of DFS include originating, collecting, and servicing customer financing arrangements primarily related to the purchase or use of Dell Technologies products and services.  In some cases, DFS also offers financing on the purchase of third-party technology products that complement the Dell Technologies portfolio of products and services.  New financing originations were $2.0 billion and $1.6 billion for the three months ended November 1, 2019 and November 2, 2018, respectively, and were $5.7 billion and $5.2 billion for the nine months ended November 1, 2019 and November 2, 2018, respectively.

[0001571996-19-000051:notes:47]
The Company’s loan and lease arrangements with customers are aggregated into the following categories:

[0001571996-19-000051:notes:48]
Revolving loans — Revolving loans offered under private label credit financing programs provide qualified customers with a revolving credit line for the purchase of products and services offered by Dell Technologies.  These private label credit financing programs are referred to as Dell Preferred Account (“DPA”) and Dell Business Credit (“DBC”).  The DPA product is primarily offered to individual consumer customers, and the DBC product is primarily offered to small and medium-sized commercial customers.  Revolving loans in the United States bear interest at a variable annual percentage rate that is tied to the prime rate.  Based on historical payment patterns, revolving loan transactions are typically repaid within twelve months on average.  Due to the short-term nature of the revolving loan portfolio, the carrying value of the portfolio approximates fair value.

[0001571996-19-000051:notes:49]
Fixed-term leases and loans — The Company enters into financing arrangements with customers who seek lease financing for equipment they might otherwise purchase.  Under the new lease standard discussed in Note 1 and Note 2 of the Notes to the Condensed Consolidated Financial Statements, new DFS leases are classified as sales-type leases, direct financing leases, or operating leases.  When the terms of the DFS lease transfer control of the underlying asset to the lessee, the contract is typically classified as a sales-type lease.  Direct financing leases under the new lease standard are immaterial.  All other new DFS leases are classified as operating leases.  Leases that commenced prior to the adoption of the new lease standard were not reassessed or restated pursuant to the practical expedients elected and will continue to be accounted for under previous lease accounting guidance.  Leases with business customers have fixed terms of generally two to four years.

[0001571996-19-000051:notes:50]
[same as prior period, unchanged from 0001571996-19-000039:notes:50]

[0001571996-19-000051:notes:51]
[same as prior period, unchanged from 0001571996-19-000039:notes:51]

[0001571996-19-000051:notes:52]
[same as prior period, unchanged from 0001571996-19-000039:notes:52]

[0001571996-19-000051:notes:53]
|  | November 1, 2019 |  | February 1, 2019 |
|  | Revolving |  | Fixed-term |  | Total |  | Revolving |  | Fixed-term |  | Total |
|  | (in millions) |
| Financing receivables, net: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer receivables, gross (a) | $ | 774 |  |  | $ | 7,813 |  |  | $ | 8,587 |  |  | $ | 835 |  |  | $ | 7,249 |  |  | $ | 8,084 |  |
| Allowances for losses | (66 | ) |  | (78 | ) |  | (144 | ) |  | (75 | ) |  | (61 | ) |  | (136 | ) |
| Customer receivables, net | 708 |  |  | 7,735 |  |  | 8,443 |  |  | 760 |  |  | 7,188 |  |  | 7,948 |  |
| Residual interest | — |  |  | 611 |  |  | 611 |  |  | — |  |  | 674 |  |  | 674 |  |
| Financing receivables, net | $ | 708 |  |  | $ | 8,346 |  |  | $ | 9,054 |  |  | $ | 760 |  |  | $ | 7,862 |  |  | $ | 8,622 |  |
| Short-term | $ | 708 |  |  | $ | 3,881 |  |  | $ | 4,589 |  |  | $ | 760 |  |  | $ | 3,638 |  |  | $ | 4,398 |  |
| Long-term | $ | — |  |  | $ | 4,465 |  |  | $ | 4,465 |  |  | $ | — |  |  | $ | 4,224 |  |  | $ | 4,224 |  |

[0001571996-19-000051:notes:54]
[same as prior period, unchanged from 0001571996-19-000039:notes:54]

[0001571996-19-000051:notes:55]
[same as prior period, unchanged from 0001571996-19-000039:notes:55]

[0001571996-19-000051:notes:56]
[same as prior period, unchanged from 0001571996-19-000039:notes:56]

[0001571996-19-000051:notes:57]
|  | Three Months Ended |
|  | November 1, 2019 |  | November 2, 2018 |
|  | Revolving |  | Fixed-term |  | Total |  | Revolving |  | Fixed-term |  | Total |
|  | (in millions) |
| Allowance for financing receivable losses: |  |  |  |  |  |  |  |  |  |  |  |
| Balances at beginning of period | $ | 67 |  |  | $ | 71 |  |  | $ | 138 |  |  | $ | 75 |  |  | $ | 51 |  |  | $ | 126 |  |
| Charge-offs, net of recoveries | (18 | ) |  | (6 | ) |  | (24 | ) |  | (19 | ) |  | (4 | ) |  | (23 | ) |
| Provision charged to income statement | 17 |  |  | 13 |  |  | 30 |  |  | 17 |  |  | 6 |  |  | 23 |  |
| Balances at end of period | $ | 66 |  |  | $ | 78 |  |  | $ | 144 |  |  | $ | 73 |  |  | $ | 53 |  |  | $ | 126 |  |
|  | Nine Months Ended |
|  | November 1, 2019 |  | November 2, 2018 |
|  | Revolving |  | Fixed-term |  | Total |  | Revolving |  | Fixed-term |  | Total |
|  | (in millions) |
| Allowance for financing receivable losses: |  |  |  |  |  |  |  |  |  |  |  |
| Balances at beginning of period | $ | 75 |  |  | $ | 61 |  |  | $ | 136 |  |  | $ | 81 |  |  | $ | 64 |  |  | $ | 145 |  |
| Charge-offs, net of recoveries | (53 | ) |  | (18 | ) |  | (71 | ) |  | (58 | ) |  | (21 | ) |  | (79 | ) |
| Provision charged to income statement | 44 |  |  | 35 |  |  | 79 |  |  | 50 |  |  | 10 |  |  | 60 |  |
| Balances at end of period | $ | 66 |  |  | $ | 78 |  |  | $ | 144 |  |  | $ | 73 |  |  | $ | 53 |  |  | $ | 126 |  |

[0001571996-19-000051:notes:58]
[same as prior period, unchanged from 0001571996-19-000039:notes:58]

[0001571996-19-000051:notes:59]
[same as prior period, unchanged from 0001571996-19-000039:notes:59]

[0001571996-19-000051:notes:60]
|  | November 1, 2019 |  | February 1, 2019 |
|  | Current |  | Past Due1 — 90 Days |  | Past Due>90 Days |  | Total |  | Current |  | Past Due1 — 90 Days |  | Past Due>90 Days |  | Total |
|  | (in millions) |
| Revolving — DPA | $ | 524 |  |  | $ | 49 |  |  | $ | 19 |  |  | $ | 592 |  |  | $ | 583 |  |  | $ | 53 |  |  | $ | 21 |  |  | $ | 657 |  |
| Revolving — DBC | 161 |  |  | 17 |  |  | 4 |  |  | 182 |  |  | 155 |  |  | 19 |  |  | 4 |  |  | 178 |  |
| Fixed-term — Consumer and Commercial | 6,813 |  |  | 914 |  |  | 86 |  |  | 7,813 |  |  | 6,282 |  |  | 878 |  |  | 89 |  |  | 7,249 |  |
| Total customer receivables, gross | $ | 7,498 |  |  | $ | 980 |  |  | $ | 109 |  |  | $ | 8,587 |  |  | $ | 7,020 |  |  | $ | 950 |  |  | $ | 114 |  |  | $ | 8,084 |  |

[0001571996-19-000051:notes:61]
[same as prior period, unchanged from 0001571996-19-000039:notes:61]

[0001571996-19-000051:notes:62]
[same as prior period, unchanged from 0001571996-19-000039:notes:62]

[0001571996-19-000051:notes:63]
[same as prior period, unchanged from 0001571996-19-000039:notes:63]

[0001571996-19-000051:notes:64]
|  | November 1, 2019 |  | February 1, 2019 |
|  | Higher |  | Mid |  | Lower |  | Total |  | Higher |  | Mid |  | Lower |  | Total |
|  | (in millions) |
| Revolving — DPA | $ | 124 |  |  | $ | 173 |  |  | $ | 295 |  |  | $ | 592 |  |  | $ | 128 |  |  | $ | 192 |  |  | $ | 337 |  |  | $ | 657 |  |
| Revolving — DBC | $ | 47 |  |  | $ | 56 |  |  | $ | 79 |  |  | $ | 182 |  |  | $ | 47 |  |  | $ | 54 |  |  | $ | 77 |  |  | $ | 178 |  |
| Fixed-term — Consumer and Commercial | $ | 4,494 |  |  | $ | 1,995 |  |  | $ | 1,324 |  |  | $ | 7,813 |  |  | $ | 3,980 |  |  | $ | 1,984 |  |  | $ | 1,285 |  |  | $ | 7,249 |  |

[0001571996-19-000051:notes:65]
[same as prior period, unchanged from 0001571996-19-000039:notes:65]

[0001571996-19-000051:notes:66]
[same as prior period, unchanged from 0001571996-19-000039:notes:66]

[0001571996-19-000051:notes:67]
Interest income on sales-type lease receivables was $66 million and $196 million for the three and nine months ended November 1, 2019, respectively.

[0001571996-19-000051:notes:68]
[same as prior period, unchanged from 0001571996-19-000039:notes:68]

[0001571996-19-000051:notes:69]
|  | Three Months Ended |  | Nine Months Ended |
|  | November 1, 2019 |  | November 1, 2019 |
|  | (in millions) |
| Net revenue — products | $ | 251 |  |  | $ | 604 |  |
| Cost of net revenue — products | 215 |  |  | 475 |  |
| Gross margin — products | $ | 36 |  |  | $ | 129 |  |

[0001571996-19-000051:notes:70]
[same as prior period, unchanged from 0001571996-19-000039:notes:70]

[0001571996-19-000051:notes:71]
|  | November 1, 2019 |
| Fiscal Years | (in millions) |
| Fiscal 2020 (remaining three months) | $ | 850 |  |
| Fiscal 2021 | 2,272 |  |
| Fiscal 2022 | 1,487 |  |
| Fiscal 2023 | 693 |  |
| Fiscal 2024 and beyond | 273 |  |
| Total undiscounted cash flows | 5,575 |  |
| Fixed-term loans | 2,755 |  |
| Revolving loans | 774 |  |
| Less: unearned income | (517 | ) |
| Total customer receivables, gross | $ | 8,587 |  |

[0001571996-19-000051:notes:72]
[same as prior period, unchanged from 0001571996-19-000039:notes:72]

[0001571996-19-000051:notes:73]
[same as prior period, unchanged from 0001571996-19-000039:notes:73]

[0001571996-19-000051:notes:74]
[same as prior period, unchanged from 0001571996-19-000039:notes:74]

[0001571996-19-000051:notes:75]
|  | November 1, 2019 |
|  | (in millions) |
| Equipment under operating lease, gross | $ | 699 |  |
| Less: accumulated depreciation | (73 | ) |
| Equipment under operating lease, net | $ | 626 |  |

[0001571996-19-000051:notes:76]
[same as prior period, unchanged from 0001571996-19-000039:notes:76]

[0001571996-19-000051:notes:77]
Operating lease income relating to lease payments was $63 million and $94 million for the three and nine months ended November 1, 2019, respectively.  Depreciation expense was $40 million and $64 million for the three and nine months ended November 1, 2019, respectively.

[0001571996-19-000051:notes:78]
[same as prior period, unchanged from 0001571996-19-000039:notes:78]

[0001571996-19-000051:notes:79]
|  | November 1, 2019 |
| Fiscal Years | (in millions) |
| Fiscal 2020 (remaining three months) | $ | 73 |  |
| Fiscal 2021 | 250 |  |
| Fiscal 2022 | 229 |  |
| Fiscal 2023 | 123 |  |
| Fiscal 2024 and beyond | 10 |  |
| Total | $ | 685 |  |

[0001571996-19-000051:notes:80]
[same as prior period, unchanged from 0001571996-19-000039:notes:80]

[0001571996-19-000051:notes:81]
The Company maintains programs that facilitate the funding of leases, loans, and other alternative payment structures in the capital markets.  For DFS debt under securitization programs, the Company’s risk of loss is limited to transferred loan and lease payments and associated equipment, and the credit holders under these programs have no recourse to the Company.  The following table presents DFS debt as of the dates indicated.  The table excludes the allocated portion of the Company’s other borrowings, which represents the additional amount considered to fund the DFS business.

[0001571996-19-000051:notes:82]
|  | November 1, 2019 |  | February 1, 2019 |
|  | (in millions) |
| DFS U.S. debt: |  |  |  |
| Securitization facilities | $ | 2,019 |  |  | $ | 1,914 |  |
| Fixed-term securitization offerings | 3,003 |  |  | 2,303 |  |
| Other | 183 |  |  | 223 |  |
| Total DFS U.S. debt | 5,205 |  |  | 4,440 |  |
| DFS international debt: |  |  |  |
| Securitization facility | 716 |  |  | 584 |  |
| Other borrowings | 893 |  |  | 708 |  |
| Note payable | 198 |  |  | 197 |  |
| Dell Bank Senior Unsecured Eurobonds | 556 |  |  | — |  |
| Total DFS international debt | 2,363 |  |  | 1,489 |  |
| Total DFS debt | $ | 7,568 |  |  | $ | 5,929 |  |
| Total short-term DFS debt | $ | 3,576 |  |  | $ | 3,113 |  |
| Total long-term DFS debt | $ | 3,992 |  |  | $ | 2,816 |  |

[0001571996-19-000051:notes:83]
[same as prior period, unchanged from 0001571996-19-000039:notes:83]

[0001571996-19-000051:notes:84]
Securitization Facilities — The Company maintains separate securitization facilities in the United States for fixed-term leases and loans and for revolving loans.  This debt is collateralized solely by the U.S. loan and lease payments and associated equipment in the facilities.  The debt has a variable interest rate and the duration of the debt is based on the terms of the underlying loan and lease payment streams.  As of November 1, 2019, the total debt capacity related to the U.S. securitization facilities was $4.0 billion.  The Company enters into interest swap agreements to effectively convert a portion of its securitization debt from a floating rate to a fixed rate.  See Note 7 of the Notes to the Condensed Consolidated Financial Statements for additional information about interest rate swaps.

[0001571996-19-000051:notes:85]
The Company’s U.S. securitization facility for revolving loans is effective through June 25, 2022.  The Company’s two U.S. securitization facilities for fixed-term leases and loans are effective through August 22, 2021 and July 26, 2022, respectively.

[0001571996-19-000051:notes:86]
The securitization facilities contain standard structural features related to the performance of the securitized receivables, which include defined credit losses, delinquencies, average credit scores, and minimum collection requirements.  In the event one or more of these criteria are not met and the Company is unable to restructure the facility, no further funding of receivables will be permitted and the timing of the Company’s expected cash flows from over-collateralization will be delayed.  As of November 1, 2019, these criteria were met.

[0001571996-19-000051:notes:87]
Fixed-Term Securitization Offerings — The Company periodically issues asset-backed debt securities under fixed-term securitization programs to private investors.  The asset-backed debt securities are collateralized solely by the U.S. fixed-term leases and loans in the offerings, which are held by Special Purpose Entities (“SPEs”), as discussed below.  The interest rate on these securities is fixed and ranges from 1.91% to 3.85% per annum, and the duration of these securities is based on the terms of the underlying loan and lease payment streams.

[0001571996-19-000051:notes:88]
[same as prior period, unchanged from 0001571996-19-000039:notes:88]

[0001571996-19-000051:notes:89]
Securitization Facility — The Company maintains a securitization facility in Europe for fixed-term leases and loans.  This facility is effective through December 21, 2020 and has a total debt capacity of $892 million as of November 1, 2019.

[0001571996-19-000051:notes:90]
The securitization facility contains standard structural features related to the performance of the securitized receivables which include defined credit losses, delinquencies, average credit scores, and minimum collection requirements.  In the event one or more of these criteria are not met and the Company is unable to restructure the program, no further funding of receivables will be permitted and the timing of the Company’s expected cash flows from over-collateralization will be delayed.  As of November 1, 2019, these criteria were met.

[0001571996-19-000051:notes:91]
Other Borrowings — In connection with the Company’s international financing operations, the Company has entered into revolving structured financing debt programs related to its fixed-term lease and loan products sold in Canada, Europe, Australia, and New Zealand.  The Canadian facility, which is collateralized solely by Canadian loan and lease payments and associated equipment, had a total debt capacity of $285 million as of November 1, 2019, and is effective through January 16, 2023.  The European facility, which is collateralized solely by European loan and lease payments and associated equipment, had a total debt capacity of $669 million as of November 1, 2019, and is effective through December 14, 2020.  The Australia and New Zealand facility, which is collateralized solely by Australia and New Zealand loan and lease payments and associated equipment, had a total debt capacity of $193 million as of November 1, 2019, and is effective through January 29, 2020.

[0001571996-19-000051:notes:92]
Note Payable — On November 27, 2017, the Company entered into an unsecured credit agreement to fund receivables in Mexico.  As of November 1, 2019, the aggregate principal amount of the note payable is $198 million.  The note bears interest at either the applicable London Interbank Offered Rate (“LIBOR”) plus 2.25%, for the borrowings denominated in U.S. dollars, or the Mexican Interbank Equilibrium Interest Rate (“TIIE”) plus 2.00%, for the borrowings denominated in Mexican pesos.  The note will mature on December 1, 2020.  Although the note is unsecured, the Company manages the note in the same manner as its structured financing programs, so that the collections from loan and lease payments and associated equipment in Mexico are used to pay down principal and interest of the note.

[0001571996-19-000051:notes:93]
Dell Bank Senior Unsecured Eurobonds  — On October 17, 2019, Dell Bank International D.A.C. issued 500 million Euro of 0.625% senior unsecured three year eurobonds due October 2022.  The issuance of the senior unsecured eurobonds supports the expansion of the financing operations in Europe.

[0001571996-19-000051:notes:94]
[same as prior period, unchanged from 0001571996-19-000039:notes:93]

[0001571996-19-000051:notes:95]
In connection with the securitization facilities and offerings discussed above, the Company transfers certain U.S. and European loan and lease payments and associated equipment to SPEs that meet the definition of a Variable Interest Entity (“VIE”) and are consolidated, along with the associated debt detailed above, into the Consolidated Financial Statements, as the Company is the primary beneficiary of those VIEs.  The SPEs are bankruptcy-remote legal entities with separate assets and liabilities.  The purpose of the SPEs is to facilitate the funding of customer loan and lease payments and associated equipment in the capital markets.

[0001571996-19-000051:notes:96]
[same as prior period, unchanged from 0001571996-19-000039:notes:95]

[0001571996-19-000051:notes:97]
|  | November 1, 2019 |  | February 1, 2019 |
|  | (in millions) |
| Assets held by consolidated VIEs, net: |  |  |  |  |  |
| Short-term, net | $ | 3,212 |  |  | $ | 2,940 |  |
| Long-term, net | 3,149 |  |  | 2,508 |  |
| Assets held by consolidated VIEs, net | $ | 6,361 |  |  | $ | 5,448 |  |

[0001571996-19-000051:notes:98]
Loan and lease payments and associated equipment transferred via securitization through SPEs were $1.3 billion and $1.2 billion for the three months ended November 1, 2019 and November 2, 2018, respectively, and $4.1 billion and $3.7 billion for the nine months ended November 1, 2019 and November 2, 2018, respectively.

[0001571996-19-000051:notes:99]
Some of the SPEs have entered into financing arrangements with multi-seller conduits that, in turn, issue asset-backed debt securities in the capital markets.  The DFS debt outstanding, which is collateralized by the loan and lease payments and associated equipment held by the consolidated VIEs, was $5.7 billion and $4.8 billion as of November 1, 2019 and February 1, 2019, respectively.  The Company’s risk of loss related to securitized receivables is limited to the amount by which the Company’s right to receive collections for assets securitized exceeds the amount required to pay interest, principal, and fees and expenses related to the asset-backed securities.  The Company provides credit enhancement to the securitizations in the form of over-collateralization.

[0001571996-19-000051:notes:100]
[same as prior period, unchanged from 0001571996-19-000039:notes:99]

[0001571996-19-000051:notes:101]
To manage certain concentrations of customer credit exposure, the Company may sell selected fixed-term customer receivables to unrelated third parties on a periodic basis.  The amount of customer receivables sold was $406 million and $590 million for the nine months ended November 1, 2019 and November 2, 2018, respectively.


## us-gaap:ScheduleOfDebtTableTextBlock

[0001571996-19-000051:notes:102]
The following table presents DFS debt as of the dates indicated.  The table excludes the allocated portion of the Company’s other borrowings, which represents the additional amount considered to fund the DFS business.

[0001571996-19-000051:notes:103]
The following table presents the Company’s outstanding debt as of the dates indicated:

[0001571996-19-000051:notes:104]
|  | November 1, 2019 |  | February 1, 2019 |
|  | (in millions) |
| Secured Debt |  |  |  |
| Senior Secured Credit Facilities: |  |  |  |
| 4.24% Term Loan B Facility due September 2023 | $ | — |  |  | $ | 4,938 |  |
| 3.79% Term Loan B-1 Facility due September 2025 | 4,750 |  |  | — |  |
| 4.16% Term Loan A-2 Facility due September 2021 | — |  |  | 4,116 |  |
| 3.54% Term Loan A-4 Facility due December 2023 | 679 |  |  | 1,650 |  |
| 4.25% Term Loan A-5 Facility due December 2019 | — |  |  | 2,016 |  |
| 3.60% Term Loan A-6 Facility due March 2024 | 3,543 |  |  | — |  |
| First Lien Notes: |  |  |  |
| 3.48% due June 2019 | — |  |  | 3,750 |  |
| 4.42% due June 2021 | 4,500 |  |  | 4,500 |  |
| 5.45% due June 2023 | 3,750 |  |  | 3,750 |  |
| 4.00% due July 2024 | 1,000 |  |  | — |  |
| 6.02% due June 2026 | 4,500 |  |  | 4,500 |  |
| 4.90% due October 2026 | 1,750 |  |  | — |  |
| 5.30% due October 2029 | 1,750 |  |  | — |  |
| 8.10% due July 2036 | 1,500 |  |  | 1,500 |  |
| 8.35% due July 2046 | 2,000 |  |  | 2,000 |  |
| Unsecured Debt |  |  |  |
| Unsecured Notes and Debentures: |  |  |  |
| 5.875% due June 2019 | — |  |  | 600 |  |
| 4.625% due April 2021 | 400 |  |  | 400 |  |
| 7.10% due April 2028 | 300 |  |  | 300 |  |
| 6.50% due April 2038 | 388 |  |  | 388 |  |
| 5.40% due September 2040 | 264 |  |  | 264 |  |
| Senior Notes: |  |  |  |
| 5.875% due June 2021 | 1,075 |  |  | 1,625 |  |
| 7.125% due June 2024 | 1,625 |  |  | 1,625 |  |
| EMC Notes: |  |  |  |
| 2.650% due June 2020 | 2,000 |  |  | 2,000 |  |
| 3.375% due June 2023 | 1,000 |  |  | 1,000 |  |
| Public Subsidiary Debt |  |  |  |
| VMware Notes: |  |  |  |
| 2.30% due August 2020 | 1,250 |  |  | 1,250 |  |
| 2.95% due August 2022 | 1,500 |  |  | 1,500 |  |
| 3.90% due August 2027 | 1,250 |  |  | 1,250 |  |
| VMware Term Loan Facility | 600 |  |  | — |  |
| DFS Debt (Note 4) | 7,568 |  |  | 5,929 |  |
| Other |  |  |  |
| 4.18% Margin Loan Facility due April 2022 | 4,000 |  |  | 3,350 |  |
| Other | 84 |  |  | 38 |  |
| Total debt, principal amount | $ | 53,026 |  |  | $ | 54,239 |  |

[0001571996-19-000051:notes:105]
|  | November 1, 2019 |  | February 1, 2019 |
|  | (in millions) |
| Total debt, principal amount | $ | 53,026 |  |  | $ | 54,239 |  |
| Unamortized discount, net of unamortized premium | (246 | ) |  | (271 | ) |
| Debt issuance costs | (389 | ) |  | (447 | ) |
| Total debt, carrying value | $ | 52,391 |  |  | $ | 53,521 |  |
| Total short-term debt, carrying value | $ | 7,664 |  |  | $ | 4,320 |  |
| Total long-term debt, carrying value | $ | 44,727 |  |  | $ | 49,201 |  |


## us-gaap:LesseeOperatingLeasesTextBlock

[0001571996-19-000051:notes:106]
[same as prior period, unchanged from 0001571996-19-000039:notes:105]

[0001571996-19-000051:notes:107]
The Company enters into leasing transactions in which the Company is the lessee.  These lease contracts are typically classified as operating leases.  The Company’s lease contracts are generally for office buildings used to conduct its business, and the determination of whether such contracts contain leases generally does not require significant estimates or judgments.  The Company also leases certain global logistics warehouses, employee vehicles, and equipment.  As of November 1, 2019, the remaining terms of the Company’s leases range from one year to 27 years.

[0001571996-19-000051:notes:108]
The Company also enters into leasing transactions in which the Company is the lessor, primarily through customer financing arrangements offered through DFS.  DFS originates leases that are primarily classified as either sales-type leases or operating leases.  See Note 4 of the Notes to the Condensed Consolidated Financial Statements for more information on the DFS lease portfolio and related lease disclosures.

[0001571996-19-000051:notes:109]
In adopting the new lease standard discussed in Note 1 and Note 2 of the Notes to the Condensed Consolidated Financial Statements, the Company elected to apply a transition method that does not require the retrospective application to periods prior to adoption.  Financial information associated with the Company’s leases in which the Company is the lessee is contained in this Note.  As of November 1, 2019, there were no material finance leases for which the Company was a lessee.

[0001571996-19-000051:notes:110]
[same as prior period, unchanged from 0001571996-19-000039:notes:109]

[0001571996-19-000051:notes:111]
|  | Three Months Ended |  | Nine Months Ended |
|  | November 1, 2019 |  | November 1, 2019 |
|  | (in millions) |
| Operating lease costs | $ | 134 |  |  | $ | 377 |  |
| Variable costs | 41 |  |  | 120 |  |
| Total lease costs | $ | 175 |  |  | $ | 497 |  |

[0001571996-19-000051:notes:112]
During the nine months ended November 1, 2019, sublease income, finance lease costs, and short-term lease costs were immaterial.

[0001571996-19-000051:notes:113]
[same as prior period, unchanged from 0001571996-19-000039:notes:112]

[0001571996-19-000051:notes:114]
|  | Classification |  | November 1, 2019 |
|  |  |  | (in millions, except for term and discount rate) |
| Operating lease ROU assets | Other non-current assets |  | $ | 1,752 |  |
| Current operating lease liabilities | Accrued and other current liabilities |  | $ | 428 |  |
| Non-current operating lease liabilities | Other non-current liabilities |  | 1,336 |  |
| Total operating lease liabilities |  |  | $ | 1,764 |  |
| Weighted-average remaining lease term (in years) |  |  | 8.73 |  |
| Weighted-average discount rate |  |  | 3.94 | % |

[0001571996-19-000051:notes:115]
[same as prior period, unchanged from 0001571996-19-000039:notes:114]

[0001571996-19-000051:notes:116]
|  | Nine Months Ended |
|  | November 1, 2019 |
|  | (in millions) |
| Cash paid for amounts included in the measurement of lease liabilities — operating cash outflows from operating leases | $ | 367 |  |
| ROU assets obtained in exchange for new operating lease liabilities | $ | 495 |  |

[0001571996-19-000051:notes:117]
[same as prior period, unchanged from 0001571996-19-000039:notes:116]

[0001571996-19-000051:notes:118]
|  | November 1, 2019 |
| Fiscal Years | (in millions) |
| Fiscal 2020 (remaining three months) | $ | 104 |  |
| Fiscal 2021 | 455 |  |
| Fiscal 2022 | 360 |  |
| Fiscal 2023 | 277 |  |
| Fiscal 2024 | 181 |  |
| Thereafter | 772 |  |
| Total lease payments | $ | 2,149 |  |
| Less: Imputed interest | (385 | ) |
| Total | $ | 1,764 |  |
| Current operating lease liabilities | $ | 428 |  |
| Non-current operating lease liabilities | $ | 1,336 |  |

[0001571996-19-000051:notes:119]
[same as prior period, unchanged from 0001571996-19-000039:notes:118]

[0001571996-19-000051:notes:120]
As of November 1, 2019, the Company has additional operating leases that have not yet commenced of $665 million.  These operating leases will commence during Fiscal 2020 and Fiscal 2021 with lease terms of one year to 16 years.

[0001571996-19-000051:notes:121]
[same as prior period, unchanged from 0001571996-19-000039:notes:120]

[0001571996-19-000051:notes:122]
[same as prior period, unchanged from 0001571996-19-000039:notes:121]

[0001571996-19-000051:notes:123]
[same as prior period, unchanged from 0001571996-19-000039:notes:122]


## us-gaap:DebtDisclosureTextBlock

[0001571996-19-000051:notes:124]
NOTE 6 — DEBT

[0001571996-19-000051:notes:125]
During the nine months ended November 1, 2019, the Company repaid $550 million principal amount of its 5.875% senior unsecured notes due June 2021, $600 million principal amount of its 5.875% senior unsecured notes due June 2019 upon maturity, $950 million principal amount of its Term Loan A-4 Facility, and approximately $136 million of principal amortization under its term loan facilities.  The Company also repaid $162.5 million principal amount as part of the Term Loan B Facility refinancing and the remaining principal amount of approximately $1,277 million of its Term Loan A-2 Facility in connection with the First Lien Notes issued on March 20, 2019, as described below under “Refinancing Transactions.”  Additionally, during the nine months ended November 1, 2019, the Company issued an additional $1.6 billion, net, in DFS debt to support the expansion of its financing receivables portfolio.

[0001571996-19-000051:notes:126]
Refinancing Transactions

[0001571996-19-000051:notes:127]
On March 7, 2019, the Company amended the Margin Loan Agreement to increase the aggregate principal amount of borrowings under the Margin Loan Facility by $650 million.

[0001571996-19-000051:notes:128]
On March 13, 2019, the Company entered into an amendment to the credit agreement for the Senior Secured Credit Facilities to obtain a new senior secured Term Loan A-6 Facility in order to refinance the $5 billion aggregate principal amount of debt incurred in connection with the Class V transaction described in Note 14 of the Notes to the Condensed Consolidated Financial Statements.  The Term Loan A-6 Facility aggregate principal amount of $3,634 million matures on March 13, 2024, of which $2,839 million aggregate principal amount represents the amounts outstanding under the Term Loan A-2 Facility that rolled-over into the new facility.  Immediately after the rollover, an aggregate principal amount of $1,277 million remained outstanding under the Term Loan A-2 Facility.

[0001571996-19-000051:notes:129]
On March 20, 2019, Dell International L.L.C. and EMC Corporation, both of which are wholly-owned subsidiaries of Dell Technologies Inc., completed a private offering of multiple series of First Lien Notes in an aggregate principal amount of $4.5 billion.  The principal amount, interest rate, and maturity of each series of such First Lien Notes were $1,000 million of 4.00% First Lien Notes due July 15, 2024, $1,750 million of 4.90% First Lien Notes due October 1, 2026, and $1,750 million of 5.30% First Lien Notes due October 1, 2029.

[0001571996-19-000051:notes:130]
A majority of the proceeds from the First Lien Notes issued on March 20, 2019 was used to repay all of the outstanding $3,750 million principal amount of the 3.48% First Lien Notes due June 2019.  In addition, proceeds of approximately $800 million of borrowings under the new Term Loan A-6 Facility, the proceeds of the $650 million increase in the Margin Loan Facility, and a portion of the proceeds from the 2019 First Lien Notes were used to repay all $2,016 million of the Company’s outstanding amounts under the Term Loan A-5 Facility due December 2019.  During the three months ended May 3, 2019, the remaining proceeds available from the 2019 First Lien Notes were used to repay $550 million of outstanding amounts under the Term Loan A-2 Facility and to pay related premiums, accrued interest, fees, and expenses.  The Term Loan A-2 Facility was subsequently paid off as of August 2, 2019.

[0001571996-19-000051:notes:131]
On September 19, 2019, the Company entered into a sixth refinancing amendment to the Senior Secured Credit Agreement (the “Sixth Refinancing Amendment”) to refinance the Term Loan B Facility due September 2023 with a new term loan B facility consisting of an aggregate principal amount of $4,750 million refinancing term B-1 loans maturing on September 19, 2025 (“Term Loan B-1 Facility due September 2025” or “Term Loan B-1 Facility”).  The Company used the proceeds from the Term Loan B-1 Facility, together with other funds available, to repay $4,913 million of outstanding amounts under the Term Loan B Facility due September 2023 and to pay related accrued interest, fees and expenses.

[0001571996-19-000051:notes:132]
The refinancing and amendments were evaluated in accordance with FASB ASC 470, “Debt-Modifications and Extinguishments.”  The amendment to the Margin Loan Agreement and the term debt refinancing were accounted for as modifications for all existing lenders and as new issuances for new lenders.  The First Lien Notes issued on March 20, 2019 were accounted for as new issuances for all lenders, and repayment of the Company’s outstanding amounts under the Term Loan A-5 Facility was accounted for as an extinguishment.  During the three months ended May 3, 2019, the Company capitalized $74.5 million in new fees paid to creditors as a result of the modifications and new issuances.  In addition, the Company recognized expenses of $32.3 million in unamortized costs and $7.1 million in new third-party costs during the three months ended May 3, 2019.  The Term Loan B Facility refinancing was accounted for as a modification for all existing lenders and as a new issuance for new lenders.  During the three months ended November 1, 2019, the Company capitalized $5.9 million in new fees paid to creditors as a result of the modifications and new issuances.  In addition, the Company recognized expenses of $1.5 million in unamortized costs and $5.1 million in new third-party costs during the three months ended November 1, 2019.

[0001571996-19-000051:notes:133]
Secured Debt

[0001571996-19-000051:notes:134]
Senior Secured Credit Facilities — The Company has entered into a credit agreement that provides for senior secured credit facilities (the “Senior Secured Credit Facilities”) comprising (a) term loan facilities and (b) a senior secured Revolving Credit Facility, which includes capacity for up to $0.5 billion of letters of credit and for borrowings of up to $0.4 billion under swing-line loans.

[0001571996-19-000051:notes:135]
As of November 1, 2019, available borrowings under the Revolving Credit Facility totaled $4.5 billion.  The Senior Secured Credit Facilities provide that the borrowers have the right at any time, subject to customary conditions, to request incremental term loans or incremental revolving commitments.

[0001571996-19-000051:notes:136]
Borrowings under the Senior Secured Credit Facilities bear interest at a rate per annum equal to an applicable margin, plus, at the borrowers’ option, either (a) a base rate, or (b) the London Interbank Offered Rate (“LIBOR”).  The Term Loan B-1 Facility bears interest at LIBOR plus an applicable margin of 2.00% or a base rate plus an applicable margin of 1.00%.  The Term Loan A-4 Facility and the Term Loan A-6 Facility bear interest at LIBOR plus an applicable margin ranging from 1.25% to 2.00% or a base rate plus an applicable margin ranging from 0.25% to 1.00%.  Interest is payable, in the case of loans bearing interest based on LIBOR, at the end of each interest period (but at least every three months), in arrears and, in the case of loans bearing interest based on the base rate, quarterly in arrears.

[0001571996-19-000051:notes:137]
The Term Loan B-1 Facility amortizes in equal quarterly installments in aggregate annual amounts equal to 1% of the original principal amount.  The Term Loan A-4 Facility amortizes in equal quarterly installments in aggregate annual amounts equal to 5% of the original principal amount in each of the first four years after the facility closing date of December 20, 2018, and 80% of the original principal amount in the fifth year after December 20, 2018.  The Term Loan A-6 Facility amortizes in equal quarterly installments in aggregate annual amounts equal to 5% of the original principal amount in each of the first four years after the facility closing date of March 13, 2019, and 80% of the original principal amount in the fifth year after March 13, 2019.  The Revolving Credit Facility has no amortization.

[0001571996-19-000051:notes:138]
The borrowers may voluntarily repay outstanding loans under the term loan facilities and the Revolving Credit Facility at any time without premium or penalty, other than customary “breakage” costs.

[0001571996-19-000051:notes:139]
All obligations of the borrowers under the Senior Secured Credit Facilities and certain swap agreements, cash management arrangements, and certain letters of credit provided by any lender or agent party to the Senior Secured Credit Facilities or any of its affiliates and certain other persons are secured by (a) a first-priority security interest in certain tangible and intangible assets of the borrowers and the guarantors and (b) a first-priority pledge of 100% of the capital stock of the borrowers, Dell Inc., a wholly‑owned subsidiary of the Company (“Dell”), and each wholly-owned material restricted subsidiary of the borrowers and the guarantors, in each case subject to certain thresholds, exceptions, and permitted liens.

[0001571996-19-000051:notes:140]
First Lien Notes — The senior secured notes (collectively, the “First Lien Notes”) were issued on June 1, 2016 and March 20, 2019 in an aggregate principal amount of $20.0 billion and $4.5 billion, respectively.  As discussed above, during the three months ended May 3, 2019, the Company used a portion of the $4.5 billion proceeds from the First Lien Notes issued on March 20, 2019 to repay all of the outstanding $3,750 million principal amount of its 3.48% First Lien Notes due June 2019.  Interest on these borrowings is payable semiannually.  The First Lien Notes are secured on a pari passu basis with the Senior Secured Credit Facilities, on a first-priority basis by substantially all of the tangible and intangible assets of the issuers and guarantors that secure obligations under the Senior Secured Credit Facilities, including pledges of all capital stock of the issuers, Dell, and certain wholly-owned material subsidiaries of the issuers and the guarantors, subject to certain exceptions.

[0001571996-19-000051:notes:141]
The Company has agreed to use commercially reasonable efforts to register with the SEC notes having terms substantially identical to the terms of the First Lien Notes as part of an offer to exchange such registered notes for the First Lien Notes.  The Company will be obligated to pay additional interest on the First Lien Notes if it fails to consummate such an exchange offer within five years after the closing date of the EMC merger transaction, in the case of the First Lien Notes issued on June 1, 2016, and within five years after their issue date, in the case of the First Lien Notes issued on March 20, 2019.

[0001571996-19-000051:notes:142]
China Revolving Credit Facility — During the three months ended May 3, 2019, the Company renewed its credit agreement (the “China Revolving Credit Facility”) with a bank lender for a secured revolving loan facility in an aggregate principal amount not to exceed $500 million at an interest rate of LIBOR plus 0.6% per annum.  The facility will expire on February 26, 2020.  As of November 1, 2019, there were no outstanding borrowings under the China Revolving Credit Facility.

[0001571996-19-000051:notes:143]
Unsecured Debt

[0001571996-19-000051:notes:144]
Unsecured Notes and Debentures — The Company has outstanding unsecured notes and debentures (collectively, the “Unsecured Notes and Debentures”) that were issued by Dell prior to the acquisition of Dell by Dell Technologies Inc. in the going-private transaction that closed in October 2013.  Interest on these borrowings is payable semiannually.

[0001571996-19-000051:notes:145]
Senior Notes — The senior unsecured notes (collectively, the “Senior Notes”) were issued on June 22, 2016 in an aggregate principal amount of $3.25 billion.  Interest on these borrowings is payable semiannually.

[0001571996-19-000051:notes:146]
EMC Notes — On September 7, 2016, EMC had outstanding $2.5 billion aggregate principal amount of its 1.875% Notes due June 2018, which the Company fully repaid during the three months ended August 3, 2018, $2.0 billion aggregate principal amount of its 2.650% Notes due June 2020, and $1.0 billion aggregate principal amount of its 3.375% Notes due June 2023 (collectively, the “EMC Notes”).  Interest on these borrowings is payable semiannually.

[0001571996-19-000051:notes:147]
VMware Notes — On August 21, 2017, VMware, Inc. completed a public offering of unsecured senior notes in the aggregate amount of $4.0 billion, consisting of outstanding principal due on the following dates: $1.25 billion due August 21, 2020, $1.5 billion due August 21, 2022, and $1.25 billion due August 21, 2027 (collectively, the “VMware Notes”).  The VMware Notes bear interest, payable semiannually, at annual rates of 2.30%, 2.95%, and 3.90%, respectively.  None of the net proceeds of such borrowings will be made available to support the operations or satisfy any corporate purposes of Dell Technologies, other than the operations and corporate purposes of VMware, Inc. and VMware, Inc.’s subsidiaries.

[0001571996-19-000051:notes:148]
VMware Revolving Credit Facility — On September 12, 2017, VMware, Inc. entered into an unsecured credit agreement, establishing a revolving credit facility (the “VMware Revolving Credit Facility”) with a syndicate of lenders that provides the company with a borrowing capacity of up to $1.0 billion for VMware, Inc. general corporate purposes.  Commitments under the VMware Revolving Credit Facility are available for a period of five years, which may be extended, subject to the satisfaction of certain conditions, by up to two one year periods.  The credit agreement contains certain representations, warranties, and covenants.  Commitment fees, interest rates, and other terms of borrowing under the VMware Revolving Credit Facility may vary based on VMware, Inc.’s external credit ratings.  None of the net proceeds of such borrowings will be made available to support the operations or satisfy any corporate purposes of Dell Technologies, other than the operations and corporate purposes of VMware, Inc. and VMware, Inc.’s subsidiaries.  As of November 1, 2019, there were no outstanding borrowings under the VMware Revolving Credit Facility.

[0001571996-19-000051:notes:149]
VMware Term Loan Facility — On September 26, 2019, VMware, Inc. entered into a senior unsecured term loan facility (the “VMware Term Loan Facility”) with a syndicate of lenders that provides VMware, Inc. with a borrowing capacity of up to $2.0 billion for VMware, Inc. general corporate purposes.  VMware, Inc. may borrow against the VMware Term Loan Facility two times up to its borrowing capacity of $2.0 billion until February 7, 2020.  The VMware Term Loan Facility matures on the 364th day following the initial funding under the facility.  The VMware Term Loan Facility bears interest at LIBOR plus 0.75% to 1.25%, or an alternative base rate plus 0.00% to 0.25%, depending on VMware Inc.’s external credit ratings.  VMware, Inc. drew down $2.0 billion and repaid $1.4 billion during the three months ended November 1, 2019.  As of November 1, 2019, the outstanding balance was $600 million, and $1.4 billion remained available to be drawn down for future borrowing purposes.  The VMware Term Loan Facility contains certain representations, warranties, and covenants.  None of the net proceeds of such borrowings will be made available to support the operations or satisfy any corporate purposes of Dell Technologies, other than the operations and corporate purposes of VMware, Inc. and VMware, Inc.’s subsidiaries.

[0001571996-19-000051:notes:150]
See Note 4 and Note 7 of the Notes to the Condensed Consolidated Financial Statements, respectively, for discussion of DFS debt and the interest rate swap agreements that hedge a portion of that debt.

[0001571996-19-000051:notes:151]
Other

[0001571996-19-000051:notes:152]
Margin Loan Facility — On April 12, 2017, the Company entered into the Margin Loan Facility in an aggregate principal amount of $2.0 billion.  In connection with the Class V transaction, on December 20, 2018, the Company amended the Margin Loan Facility to increase the aggregate principal amount to $3.35 billion.  In connection with obtaining the Term Loan A-6 Facility, the Company increased the aggregate principal amount of the Margin Loan Facility to $4.0 billion.  VMW Holdco LLC, a wholly-owned subsidiary of EMC, is the borrower under the Margin Loan Facility, which is secured by 60 million shares of Class B common stock of VMware, Inc. and 20 million shares of Class A common stock of VMware, Inc.  Loans under the Margin Loan Facility bear interest at a rate per annum payable, at the borrower’s option, either at (a) a base rate plus 1.25% per annum or (b) a LIBOR-based rate plus 2.25% per annum.  Interest under the Margin Loan Facility is payable quarterly.

[0001571996-19-000051:notes:153]
The Margin Loan Facility will mature in April 2022.  The borrower may voluntarily repay outstanding loans under the Margin Loan Facility at any time without premium or penalty, other than customary “breakage” costs, subject to certain minimum threshold amounts for prepayment.

[0001571996-19-000051:notes:154]
Pivotal Revolving Credit Facility — On September 7, 2017, Pivotal entered into a credit agreement (the “Pivotal Revolving Credit Facility”) that provided for a senior secured revolving loan facility in an aggregate principal amount not to exceed $100 million.   The credit facility contained customary representations, warranties, and covenants, including financial covenants.  During the three months ended November 1, 2019, the Pivotal Revolving Credit Facility was terminated.

[0001571996-19-000051:notes:155]
Aggregate Future Maturities

[0001571996-19-000051:notes:156]
The following table presents the aggregate future maturities of the Company’s debt as of November 1, 2019 for the periods indicated:

[0001571996-19-000051:notes:157]
|  | Maturities by Fiscal Year |
|  | 2020 (remaining three months) |  | 2021 |  | 2022 |  | 2023 |  | 2024 |  | Thereafter |  | Total |
|  | (in millions) |
| Senior Secured Credit Facilities and First Lien Notes | $ | 91 |  |  | $ | 184 |  |  | $ | 4,717 |  |  | $ | 286 |  |  | $ | 6,702 |  |  | $ | 17,742 |  |  | $ | 29,722 |  |
| Unsecured Notes and Debentures | — |  |  | — |  |  | 400 |  |  | — |  |  | — |  |  | 952 |  |  | 1,352 |  |
| Senior Notes and EMC Notes | — |  |  | 2,000 |  |  | 1,075 |  |  | — |  |  | 1,000 |  |  | 1,625 |  |  | 5,700 |  |
| VMware Notes | — |  |  | 1,850 |  |  | — |  |  | 1,500 |  |  | — |  |  | 1,250 |  |  | 4,600 |  |
| DFS Debt | 1,249 |  |  | 3,611 |  |  | 1,418 |  |  | 1,198 |  |  | 84 |  |  | 8 |  |  | 7,568 |  |
| Margin Loan Facility | — |  |  | — |  |  | — |  |  | 4,000 |  |  | — |  |  | — |  |  | 4,000 |  |
| Other | 11 |  |  | 21 |  |  | 7 |  |  | 8 |  |  | 7 |  |  | 30 |  |  | 84 |  |
| Total maturities, principal amount | 1,351 |  |  | 7,666 |  |  | 7,617 |  |  | 6,992 |  |  | 7,793 |  |  | 21,607 |  |  | 53,026 |  |
| Associated carrying value adjustments | — |  |  | (8 | ) |  | (57 | ) |  | (26 | ) |  | (53 | ) |  | (491 | ) |  | (635 | ) |
| Total maturities, carrying value amount | $ | 1,351 |  |  | $ | 7,658 |  |  | $ | 7,560 |  |  | $ | 6,966 |  |  | $ | 7,740 |  |  | $ | 21,116 |  |  | $ | 52,391 |  |

[0001571996-19-000051:notes:158]
Covenants and Unrestricted Net Assets — The credit agreement for the Senior Secured Credit Facilities contains customary negative covenants that generally limit the ability of Denali Intermediate Inc., a wholly-owned subsidiary of Dell Technologies (“Dell Intermediate”), Dell, and Dell’s and Denali Intermediate’s other restricted subsidiaries to incur debt, create liens, make fundamental changes, enter into asset sales, make certain investments, pay dividends or distribute or redeem certain equity interests, prepay or redeem certain debt, and enter into certain transactions with affiliates.  The indenture governing the Senior Notes contains customary negative covenants that generally limit the ability of Denali Intermediate, Dell, and Dell’s and Denali Intermediate’s other restricted subsidiaries to incur additional debt or issue certain preferred shares, pay dividends on or make other distributions in respect of capital stock or make other restricted payments, make certain investments, sell or transfer certain assets, create liens on certain assets to secure debt, consolidate, merge, sell, or otherwise dispose of all or substantially all assets, enter into certain transactions with affiliates, and designate subsidiaries as unrestricted subsidiaries.  The negative covenants under such credit agreements and indenture are subject to certain exceptions, qualifications, and “baskets.”  The indentures governing the First Lien Notes, the Unsecured Notes and Debentures, and the EMC Notes variously impose limitations, subject to specified exceptions, on creating certain liens, entering into sale and lease-back transactions, and entering into certain asset sales.  The foregoing credit agreements and indentures contain customary events of default, including failure to make required payments, failure to comply with covenants, and the occurrence of certain events of bankruptcy and insolvency.

[0001571996-19-000051:notes:159]
As of November 1, 2019, the Company had certain consolidated subsidiaries that were designated as unrestricted subsidiaries for all purposes of the applicable credit agreements and the indentures governing the First Lien Notes and the Senior Notes.  Substantially all of the net assets of the Company’s consolidated subsidiaries were restricted, with the exception of the Company’s unrestricted subsidiaries, primarily VMware, Inc., Pivotal, Secureworks, and their respective subsidiaries, as of November 1, 2019.

[0001571996-19-000051:notes:160]
The Term Loan A-4 Facility, the Term Loan A-6 Facility, and the Revolving Credit Facility are subject to a first lien leverage ratio covenant that is tested at the end of each fiscal quarter of Dell with respect to Dell’s preceding four fiscal quarters.  The Company was in compliance with all financial covenants as of November 1, 2019.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001571996-19-000051:notes:161]
[same as prior period, unchanged from 0001571996-19-000039:notes:159]

[0001571996-19-000051:notes:162]
[same as prior period, unchanged from 0001571996-19-000039:notes:160]

[0001571996-19-000051:notes:163]
[same as prior period, unchanged from 0001571996-19-000039:notes:161]

[0001571996-19-000051:notes:164]
[same as prior period, unchanged from 0001571996-19-000039:notes:162]

[0001571996-19-000051:notes:165]
[same as prior period, unchanged from 0001571996-19-000039:notes:163]

[0001571996-19-000051:notes:166]
During the nine months ended November 1, 2019 and November 2, 2018, the Company did not discontinue any cash flow hedges related to foreign exchange contracts that had a material impact on the Company’s results of operations due to the probability that the forecasted cash flows would not occur.

[0001571996-19-000051:notes:167]
[same as prior period, unchanged from 0001571996-19-000039:notes:165]

[0001571996-19-000051:notes:168]
[same as prior period, unchanged from 0001571996-19-000039:notes:166]

[0001571996-19-000051:notes:169]
[same as prior period, unchanged from 0001571996-19-000039:notes:167]

[0001571996-19-000051:notes:170]
[same as prior period, unchanged from 0001571996-19-000039:notes:168]

[0001571996-19-000051:notes:171]
[same as prior period, unchanged from 0001571996-19-000039:notes:169]

[0001571996-19-000051:notes:172]
[same as prior period, unchanged from 0001571996-19-000039:notes:170]

[0001571996-19-000051:notes:173]
[same as prior period, unchanged from 0001571996-19-000039:notes:171]

[0001571996-19-000051:notes:174]
[same as prior period, unchanged from 0001571996-19-000039:notes:172]

[0001571996-19-000051:notes:175]
|  | November 1, 2019 |  | February 1, 2019 |
|  | (in millions) |
| Foreign exchange contracts: |  |  |  |  |  |
| Designated as cash flow hedging instruments | $ | 8,550 |  |  | $ | 7,573 |  |
| Non-designated as hedging instruments | 6,734 |  |  | 6,129 |  |
| Total | $ | 15,284 |  |  | $ | 13,702 |  |
| Interest rate contracts: |  |  |  |
| Non-designated as hedging instruments | $ | 3,715 |  |  | $ | 2,674 |  |

[0001571996-19-000051:notes:176]
[same as prior period, unchanged from 0001571996-19-000039:notes:174]

[0001571996-19-000051:notes:177]
| Derivatives in Cash Flow Hedging Relationships |  | Gain (Loss) Recognized in Accumulated OCI, Net of Tax, on Derivatives |  | Location of Gain (Loss) Reclassified from Accumulated OCI into Income |  | Gain (Loss) Reclassified from Accumulated OCI into Income |
|  |  | (in millions) |  |  |  | (in millions) |
| For the three months ended November 1, 2019 |
|  |  |  |  |  | Total net revenue |  | $ | 71 |  |
| Foreign exchange contracts |  | $ | (47 | ) |  | Total cost of net revenue |  | — |  |
| Interest rate contracts |  | — |  |  | Interest and other, net |  | — |  |
| Total |  | $ | (47 | ) |  |  |  | $ | 71 |  |
| For the three months ended November 2, 2018 |
|  |  |  |  |  | Total net revenue |  | $ | 76 |  |
| Foreign exchange contracts |  | $ | 73 |  |  | Total cost of net revenue |  | — |  |
| Interest rate contracts |  | — |  |  | Interest and other, net |  | — |  |
| Total |  | $ | 73 |  |  |  |  | $ | 76 |  |
| For the nine months ended November 1, 2019 |
|  |  |  |  |  | Total net revenue |  | $ | 197 |  |
| Foreign exchange contracts |  | $ | 210 |  |  | Total cost of net revenue |  | — |  |
| Interest rate contracts |  | — |  |  | Interest and other, net |  | — |  |
| Total |  | $ | 210 |  |  |  |  | $ | 197 |  |
| For the nine months ended November 2, 2018 |
|  |  |  |  |  | Total net revenue |  | $ | 122 |  |
| Foreign exchange contracts |  | $ | 314 |  |  | Total cost of net revenue |  | — |  |
| Interest rate contracts |  | — |  |  | Interest and other, net |  | — |  |
| Total |  | $ | 314 |  |  |  |  | $ | 122 |  |

[0001571996-19-000051:notes:178]
[same as prior period, unchanged from 0001571996-19-000039:notes:176]

[0001571996-19-000051:notes:179]
|  |  | Three Months Ended |  | Nine Months Ended |  |  |
|  |  | November 1, 2019 |  | November 2, 2018 |  | November 1, 2019 |  | November 2, 2018 |  | Location of Gain (Loss) Recognized |
|  |  | (in millions) |  |  |
| Gain (Loss) Recognized: |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | $ | 13 |  |  | $ | 18 |  |  | $ | (46 | ) |  | $ | 50 |  |  | Interest and other, net |
| Interest rate contracts |  | 1 |  |  | 1 |  |  | (21 | ) |  | 2 |  |  | Interest and other, net |
| Total |  | $ | 14 |  |  | $ | 19 |  |  | $ | (67 | ) |  | $ | 52 |  |  |  |

[0001571996-19-000051:notes:180]
[same as prior period, unchanged from 0001571996-19-000039:notes:178]

[0001571996-19-000051:notes:181]
[same as prior period, unchanged from 0001571996-19-000039:notes:179]

[0001571996-19-000051:notes:182]
|  | November 1, 2019 |
|  | Other CurrentAssets |  | Other Non-Current Assets |  | Other CurrentLiabilities |  | Other Non-CurrentLiabilities |  | TotalFair Value |
|  | (in millions) |  |  |
| Derivatives designated as hedging instruments: |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts in an asset position | $ | 90 |  |  | $ | — |  |  | $ | 11 |  |  | $ | — |  |  | $ | 101 |  |
| Foreign exchange contracts in a liability position | (24 | ) |  | — |  |  | (22 | ) |  | — |  |  | (46 | ) |
| Net asset (liability) | 66 |  |  | — |  |  | (11 | ) |  | — |  |  | 55 |  |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts in an asset position | 176 |  |  | — |  |  | 41 |  |  | — |  |  | 217 |  |
| Foreign exchange contracts in a liability position | (124 | ) |  | — |  |  | (70 | ) |  | (3 | ) |  | (197 | ) |
| Interest rate contracts in an asset position | — |  |  | 1 |  |  | — |  |  | — |  |  | 1 |  |
| Interest rate contracts in a liability position | — |  |  | — |  |  | — |  |  | (24 | ) |  | (24 | ) |
| Net asset (liability) | 52 |  |  | 1 |  |  | (29 | ) |  | (27 | ) |  | (3 | ) |
| Total derivatives at fair value | $ | 118 |  |  | $ | 1 |  |  | $ | (40 | ) |  | $ | (27 | ) |  | $ | 52 |  |
|  | February 1, 2019 |
|  | Other CurrentAssets |  | Other Non-Current Assets |  | Other CurrentLiabilities |  | Other Non-CurrentLiabilities |  | TotalFair Value |
|  | (in millions) |  |  |
| Derivatives designated as hedging instruments: |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts in an asset position | $ | 45 |  |  | $ | — |  |  | $ | 29 |  |  | $ | — |  |  | $ | 74 |  |
| Foreign exchange contracts in a liability position | (19 | ) |  | — |  |  | (20 | ) |  | — |  |  | (39 | ) |
| Net asset (liability) | 26 |  |  | — |  |  | 9 |  |  | — |  |  | 35 |  |
| Derivatives not designated as hedging instruments: |
| Foreign exchange contracts in an asset position | 178 |  |  | — |  |  | 57 |  |  | — |  |  | 235 |  |
| Foreign exchange contracts in a liability position | (110 | ) |  | — |  |  | (115 | ) |  | (2 | ) |  | (227 | ) |
| Interest rate contracts in an asset position | — |  |  | 3 |  |  | — |  |  | — |  |  | 3 |  |
| Interest rate contracts in a liability position | — |  |  | — |  |  | — |  |  | (9 | ) |  | (9 | ) |
| Net asset (liability) | 68 |  |  | 3 |  |  | (58 | ) |  | (11 | ) |  | 2 |  |
| Total derivatives at fair value | $ | 94 |  |  | $ | 3 |  |  | $ | (49 | ) |  | $ | (11 | ) |  | $ | 37 |  |

[0001571996-19-000051:notes:183]
[same as prior period, unchanged from 0001571996-19-000039:notes:181]

[0001571996-19-000051:notes:184]
|  | November 1, 2019 |
|  | Gross Amounts of Recognized Assets/ (Liabilities) |  | Gross Amounts Offset in the Statement of Financial Position |  | Net Amounts of Assets/ (Liabilities) Presented in the Statement of Financial Position |  | Gross Amounts not Offset in the Statement of Financial Position |  | Net Amount |
|  | Financial Instruments |  | Cash Collateral Received or Pledged |  |
|  | (in millions) |
| Derivative instruments: |  |  |  |  |  |  |  |  |  |  |  |
| Financial assets | $ | 319 |  |  | $ | (200 | ) |  | $ | 119 |  |  | $ | — |  |  | $ | — |  |  | $ | 119 |  |
| Financial liabilities | (267 | ) |  | 200 |  |  | (67 | ) |  | — |  |  | 11 |  |  | (56 | ) |
| Total derivative instruments | $ | 52 |  |  | $ | — |  |  | $ | 52 |  |  | $ | — |  |  | $ | 11 |  |  | $ | 63 |  |
|  | February 1, 2019 |
|  | Gross Amounts of Recognized Assets/ (Liabilities) |  | Gross Amounts Offset in the Statement of Financial Position |  | Net Amounts of Assets/ (Liabilities) Presented in the Statement of Financial Position |  | Gross Amounts not Offset in the Statement of Financial Position |  | Net Amount |
|  | Financial Instruments |  | Cash Collateral Received or Pledged |  |
|  | (in millions) |
| Derivative instruments: |  |  |  |  |  |  |  |  |  |  |  |
| Financial assets | $ | 312 |  |  | $ | (215 | ) |  | $ | 97 |  |  | $ | — |  |  | $ | — |  |  | $ | 97 |  |
| Financial liabilities | (275 | ) |  | 215 |  |  | (60 | ) |  | — |  |  | 4 |  |  | (56 | ) |
| Total derivative instruments | $ | 37 |  |  | $ | — |  |  | $ | 37 |  |  | $ | — |  |  | $ | 4 |  |  | $ | 41 |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001571996-19-000051:notes:185]
[same as prior period, unchanged from 0001571996-19-000039:notes:183]

[0001571996-19-000051:notes:186]
[same as prior period, unchanged from 0001571996-19-000039:notes:184]

[0001571996-19-000051:notes:187]
[same as prior period, unchanged from 0001571996-19-000039:notes:185]

[0001571996-19-000051:notes:188]
|  | Infrastructure Solutions Group |  | Client Solutions Group |  | VMware |  | Other Businesses (a) |  | Total |
|  | (in millions) |
| Balance as of February 1, 2019 | $ | 15,199 |  |  | $ | 4,237 |  |  | $ | 16,419 |  |  | $ | 4,234 |  |  | $ | 40,089 |  |
| Goodwill acquired (b) | — |  |  | — |  |  | 1,909 |  |  | — |  |  | 1,909 |  |
| Impact of foreign currency translation | (92 | ) |  | — |  |  | — |  |  | (11 | ) |  | (103 | ) |
| Goodwill impaired (c) | — |  |  | — |  |  | — |  |  | (207 | ) |  | (207 | ) |
| Balance as of November 1, 2019 | $ | 15,107 |  |  | $ | 4,237 |  |  | $ | 18,328 |  |  | $ | 4,016 |  |  | $ | 41,688 |  |

[0001571996-19-000051:notes:189]
[same as prior period, unchanged from 0001571996-19-000039:notes:187]

[0001571996-19-000051:notes:190]
[same as prior period, unchanged from 0001571996-19-000039:notes:188]

[0001571996-19-000051:notes:191]
[same as prior period, unchanged from 0001571996-19-000039:notes:189]

[0001571996-19-000051:notes:192]
VMware, Inc. Acquisition of Carbon Black, Inc.

[0001571996-19-000051:notes:193]
On October 8, 2019, VMware, Inc. completed the acquisition of Carbon Black, Inc. (“Carbon Black”), a developer of cloud-native endpoint protection, in a cash tender offer for all of the outstanding shares of Carbon Black’s common stock, at a price of $26.00 per share.  VMware, Inc. acquired Carbon Black to create a comprehensive intrinsic security portfolio to protect workloads, clients, and infrastructure from cloud to edge.  VMware, Inc. believes that the acquisition will result in synergies with the Carbon Black platform and VMware NSX and VMware Workspace ONE offerings, among others, and enable VMware, Inc. to offer a highly-differentiated intrinsic security platform addressing multiple concerns of the security industry.  The total preliminary purchase price was $2.0 billion, net of cash acquired of $111 million.

[0001571996-19-000051:notes:194]
Merger consideration totaling $18 million is held with a third-party paying agent and is payable to a certain employee of Carbon Black subject to specified future employment conditions and is being recognized as an expense over the requisite service period of approximately two years on a straight-line basis.

[0001571996-19-000051:notes:195]
VMware, Inc. assumed all of Carbon Black’s unvested stock options and restricted stock outstanding at the completion of the acquisition with an estimated fair value of $181 million.  Of the total consideration, $10 million was allocated to the purchase price and $171 million was allocated to future services and will be expensed over the remaining requisite service periods of approximately three years on a straight-line basis.  The estimated fair value of the stock options assumed by VMware, Inc. was determined using the Black-Scholes option pricing model.  The share conversion ratio of 0.2 was applied to convert Carbon Black’s outstanding stock awards into shares of VMware, Inc.'s common stock.

[0001571996-19-000051:notes:196]
The following table summarizes the preliminary allocation of the consideration to the fair value of the assets acquired and liabilities assumed on the date of acquisition.

[0001571996-19-000051:notes:197]
|  | Preliminary Allocation |
|  | (in millions) |
| Cash | $ | 111 |  |
| Accounts receivable | 58 |  |
| Intangible assets | 492 |  |
| Goodwill | 1,588 |  |
| Other acquired assets | 52 |  |
| Total assets acquired | 2,301 |  |
| Unearned revenue | 151 |  |
| Other assumed liabilities | 45 |  |
| Total liabilities assumed | 196 |  |
| Fair value of assets acquired and liabilities assumed | $ | 2,105 |  |

[0001571996-19-000051:notes:198]
The following table summarizes the components of the intangible assets acquired and their estimated useful lives by VMware, Inc. in conjunction with the acquisition.

[0001571996-19-000051:notes:199]
|  | Weighted-Average Useful Lives |  | Fair Value Amount |
|  | (in years) |  | (in millions) |
| Purchased technology | 4.2 |  | $ | 232 |  |
| Customer relationships and customer lists | 7.0 |  | 215 |  |
| Trademarks and tradenames | 5.0 |  | 25 |  |
| Other | 2.0 |  | 20 |  |
| Total definite-lived intangible assets |  |  | $ | 492 |  |

[0001571996-19-000051:notes:200]
The excess of the purchase consideration over the fair value of net tangible and identifiable intangible assets acquired was recorded as goodwill.  The estimated fair value assigned to the tangible assets, identifiable intangible assets, and assumed liabilities were based on VMware, Inc. management's estimates and assumptions.  The initial allocation of the purchase price was based on preliminary valuations and assumptions and is subject to change within the measurement period.  Additionally, current and non-current income taxes payable and deferred taxes may be subject to change as additional information is received and tax returns are finalized.  VMware, Inc. expects to finalize the allocation of the purchase price within the measurement period.  VMware, Inc. expects that goodwill and identifiable intangible assets will not be deductible for tax purposes.

[0001571996-19-000051:notes:201]
The pro forma financial information assuming the acquisition had occurred as of the beginning of the fiscal year prior to the fiscal year of acquisition, as well as the revenue and earnings generated during the current fiscal year, were not material for disclosure purposes.

[0001571996-19-000051:notes:202]
Other VMware, Inc. Acquisitions

[0001571996-19-000051:notes:203]
During the three months ended November 1, 2019, VMware, Inc. completed four other acquisitions. VMware, Inc. expects that these acquisitions will enhance its product features and capabilities for its software defined data center solutions and software-as-a-service offerings.  The aggregate purchase price, net of cash acquired for these four acquisitions, was $68 million, which primarily included $21 million of identifiable intangible assets and $48 million of goodwill, of which the majority is not expected to be deductible for tax purposes.  The identifiable intangible assets had estimated useful lives of one to five years and primarily consisted of completed technology.

[0001571996-19-000051:notes:204]
During the three months ended August 2, 2019, VMware, Inc. completed the acquisition of Avi Networks, Inc., a provider of multi-cloud application delivery services.  The total purchase price was $326 million, net of cash acquired of $9 million.  The purchase price primarily included $94 million of identifiable intangible assets and $228 million of goodwill that is not expected to be deductible for tax purposes.

[0001571996-19-000051:notes:205]
[same as prior period, unchanged from 0001571996-19-000039:notes:191]

[0001571996-19-000051:notes:206]
These and other VMware, Inc. acquisitions were not material individually to the Condensed Consolidated Financial Statements.  For each of the acquisitions, the initial allocation of the purchase price was based on preliminary valuations and assumptions and is subject to change within the measurement period.  VMware, Inc. expects to finalize the allocation of the purchase price for each of the acquisitions within the measurement period.

[0001571996-19-000051:notes:207]
Goodwill Impairment Tests — Goodwill and indefinite-lived intangible assets are tested for impairment annually during the third fiscal quarter and whenever events or circumstances may indicate that an impairment has occurred.  The Company elected to bypass the assessment of qualitative factors to determine whether it was more likely than not that the fair value of a reporting unit was less than its carrying amount, including goodwill.  In electing to bypass the qualitative assessment, the Company proceeded directly to performing a quantitative goodwill impairment test to measure the fair value of each goodwill reporting unit relative to its carrying amount, and to determine the amount of goodwill impairment loss to be recognized, if any.

[0001571996-19-000051:notes:208]
Based on the results of the annual impairment test performed during the three months ended November 1, 2019, the fair values of each of the reporting units exceeded their carrying values.  However, it was determined that the excess of fair value over carrying amount was less than 20% for the RSA Security reporting unit, which had an excess of fair value over carrying amount of 13% as of November 1, 2019.  Management will continue to monitor the RSA Security goodwill reporting unit and consider potential impacts to the impairment assessment.

[0001571996-19-000051:notes:209]
Based on the results of the annual impairment test performed for the fiscal year ended February 1, 2019, which was also a quantitative test for all goodwill reporting units, the fair values of each of the reporting units, except for the Virtustream reporting unit, exceeded their carrying values.  Virtustream’s results, which are reported within the Company’s Other Businesses, do not meet the requirements for a reportable segment and are not material to the Company’s overall results.  See Note 18 of the Notes to the Condensed Consolidated Financial Statements for additional segment information.

[0001571996-19-000051:notes:210]
[same as prior period, unchanged from 0001571996-19-000039:notes:195]

[0001571996-19-000051:notes:211]
During fiscal year ended February 1, 2019, Virtustream forecasts were revised downward due to a resetting of the longer-term business model that is focused on a streamlined product portfolio.  Based on the results of the annual impairment test performed for the fiscal year ended February 1, 2019, it was determined that the carrying value of the Virtustream reporting unit exceeded its fair value, and, as such, a goodwill impairment charge of approximately $190 million was recognized during the three months ended November 2, 2018 to write the goodwill down to a fair value of approximately $200 million.

[0001571996-19-000051:notes:212]
[same as prior period, unchanged from 0001571996-19-000039:notes:197]

[0001571996-19-000051:notes:213]
The impairment is reflected in the Condensed Consolidated Statements of Financial Position as of November 1, 2019 as a reduction in Goodwill of $207 million, a reduction in Intangible assets, net of $266 million, a reduction in Property, plant, and equipment, net of $146 million, and a reduction in Other non-current liabilities of $95 million related to deferred income taxes.  There are no remaining balances of Virtustream goodwill, intangible assets, or property, plant, and equipment as of November 1, 2019 following the impairment charges recognized during the three months ended August 2, 2019 and November 2, 2018.

[0001571996-19-000051:notes:214]
In conjunction with the annual impairment test performed for the fiscal year ended February 1, 2019, it was determined that the excess of fair value over carrying amount was less than 20% for the RSA Security reporting unit, which had an excess of fair value over carrying amount of 11% as of November 2, 2018.

[0001571996-19-000051:notes:215]
Following the closing of the Class V transaction described in Note 14 of the Notes to the Condensed Consolidated Financial Statements, the Company performed an interim impairment analysis during the three months ended February 1, 2019 given the availability of market data for the fair value of the Class C Common Stock.  Other than the impairment indicators disclosed during the Company’s annual goodwill impairment test during the three months ended November 2, 2018, there were no impairment indicators resulting from the interim impairment analysis.

[0001571996-19-000051:notes:216]
[same as prior period, unchanged from 0001571996-19-000039:notes:201]

[0001571996-19-000051:notes:217]
[same as prior period, unchanged from 0001571996-19-000039:notes:202]

[0001571996-19-000051:notes:218]
[same as prior period, unchanged from 0001571996-19-000039:notes:203]

[0001571996-19-000051:notes:219]
|  | November 1, 2019 |  | February 1, 2019 |
|  | Gross |  | AccumulatedAmortization |  | Net |  | Gross |  | AccumulatedAmortization |  | Net |
|  | (in millions) |
| Customer relationships | $ | 22,947 |  |  | $ | (13,319 | ) |  | $ | 9,628 |  |  | $ | 22,750 |  |  | $ | (11,703 | ) |  | $ | 11,047 |  |
| Developed technology | 15,702 |  |  | (10,454 | ) |  | 5,248 |  |  | 15,701 |  |  | (9,036 | ) |  | 6,665 |  |
| Trade names | 1,307 |  |  | (764 | ) |  | 543 |  |  | 1,291 |  |  | (606 | ) |  | 685 |  |
| Leasehold assets (liabilities) | — |  |  | — |  |  | — |  |  | 128 |  |  | (10 | ) |  | 118 |  |
| Definite-lived intangible assets | 39,956 |  |  | (24,537 | ) |  | 15,419 |  |  | 39,870 |  |  | (21,355 | ) |  | 18,515 |  |
| Indefinite-lived trade names | 3,755 |  |  | — |  |  | 3,755 |  |  | 3,755 |  |  | — |  |  | 3,755 |  |
| Total intangible assets | $ | 43,711 |  |  | $ | (24,537 | ) |  | $ | 19,174 |  |  | $ | 43,625 |  |  | $ | (21,355 | ) |  | $ | 22,270 |  |

[0001571996-19-000051:notes:220]
Amortization expense related to definite-lived intangible assets was approximately $1.1 billion and $1.5 billion for the three months ended November 1, 2019 and November 2, 2018, respectively, and $3.3 billion and $4.6 billion for the nine months ended November 1, 2019 and November 2, 2018, respectively.  There were no material impairment charges related to intangible assets during the three months ended November 1, 2019 and November 2, 2018.  Due to the adoption of the new lease standard discussed in Note 1 and Note 2 of the Notes to the Condensed Consolidated Financial Statements, the Company derecognized all intangible leasehold assets and adjusted the carrying amount of the ROU assets by a corresponding amount as of February 2, 2019.

[0001571996-19-000051:notes:221]
[same as prior period, unchanged from 0001571996-19-000039:notes:206]

[0001571996-19-000051:notes:222]
|  | November 1, 2019 |
| Fiscal Years | (in millions) |
| 2020 (remaining three months) | $ | 1,074 |  |
| 2021 | 3,431 |  |
| 2022 | 2,722 |  |
| 2023 | 1,838 |  |
| 2024 | 1,465 |  |
| Thereafter | 4,889 |  |
| Total | $ | 15,419 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001571996-19-000051:notes:223]
[same as prior period, unchanged from 0001571996-19-000039:notes:208]

[0001571996-19-000051:notes:224]
Deferred Revenue — Deferred revenue is recorded for support and deployment services, software maintenance, professional services, training, and software-as-a-service when the Company has a right to invoice or payments have been received for undelivered products or services where transfer of control has not occurred.  Revenue is recognized on these items when the revenue recognition criteria are met, generally resulting in ratable recognition over the contract term.  The Company also has deferred revenue related to undelivered hardware and professional services, consisting of installations and consulting engagements, which are recognized as the Company’s performance obligations under the contract are completed.

[0001571996-19-000051:notes:225]
[same as prior period, unchanged from 0001571996-19-000039:notes:210]

[0001571996-19-000051:notes:226]
|  | Three Months Ended |  | Nine Months Ended |
|  | November 1, 2019 |  | November 2, 2018 |  | November 1, 2019 |  | November 2, 2018 |
|  | (in millions) |
| Deferred revenue: |  |  |  |  |  |  |  |
| Deferred revenue at beginning of period | $ | 25,348 |  |  | $ | 21,700 |  |  | $ | 24,010 |  |  | $ | 20,816 |  |
| Revenue deferrals for new contracts and changes in estimates for pre-existing contracts (a) (b) | 5,326 |  |  | 4,852 |  |  | 16,201 |  |  | 14,165 |  |
| Revenue recognized (b) | (4,922 | ) |  | (4,409 | ) |  | (14,459 | ) |  | (12,838 | ) |
| Other (c) | 151 |  |  | — |  |  | 151 |  |  | — |  |
| Deferred revenue at end of period | $ | 25,903 |  |  | $ | 22,143 |  |  | $ | 25,903 |  |  | $ | 22,143 |  |
| Short-term deferred revenue | $ | 13,787 |  |  | $ | 12,079 |  |  | $ | 13,787 |  |  | $ | 12,079 |  |
| Long-term deferred revenue | $ | 12,116 |  |  | $ | 10,064 |  |  | $ | 12,116 |  |  | $ | 10,064 |  |

[0001571996-19-000051:notes:227]
[same as prior period, unchanged from 0001571996-19-000039:notes:212]

[0001571996-19-000051:notes:228]
| (b) | The Company conformed the presentation of certain deferred revenue rollforward activity for the three and nine months ended November 2, 2018 to align current year presentation. The beginning and ending deferred revenue liability balances remain unchanged. |

[0001571996-19-000051:notes:229]
(c)   Acquired deferred revenue from Carbon Black, Inc. by VMware, Inc. during the three months ended November 1, 2019. See Note 8 of the Notes to the Condensed Consolidated Financial Statements for additional information related to this acquisition.

[0001571996-19-000051:notes:230]
Remaining Performance Obligations — Remaining performance obligations represent the aggregate amount of the transaction price allocated to performance obligations not delivered, or partially undelivered, as of the end of the reporting period.  Remaining performance obligations include deferred revenue plus unbilled amounts not yet recorded in deferred revenue.  The aggregate amount of the transaction price allocated to remaining performance obligations does not include amounts owed under cancelable contracts where there is no substantive termination penalty.

[0001571996-19-000051:notes:231]
[same as prior period, unchanged from 0001571996-19-000039:notes:216]

[0001571996-19-000051:notes:232]
[same as prior period, unchanged from 0001571996-19-000039:notes:217]

[0001571996-19-000051:notes:233]
The value of the transaction price allocated to remaining performance obligations as of November 1, 2019 was approximately $34 billion.  The Company expects to recognize approximately 62% of remaining performance obligations as revenue in the next twelve months, and the remainder thereafter.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001571996-19-000051:notes:234]
NOTE 10 — COMMITMENTS AND CONTINGENCIES

[0001571996-19-000051:notes:235]
Legal Matters

[0001571996-19-000051:notes:236]
The Company is involved in various claims, suits, assessments, investigations, and legal proceedings that arise from time to time in the ordinary course of its business, including those identified below, consisting of matters involving consumer, antitrust, tax, intellectual property, and other issues on a global basis.

[0001571996-19-000051:notes:237]
The Company accrues a liability when it believes that it is both probable that a liability has been incurred and that it can reasonably estimate the amount of the loss.  The Company reviews these accruals at least quarterly and adjusts them to reflect ongoing negotiations, settlements, rulings, advice of legal counsel, and other relevant information.  To the extent new information is obtained and the Company’s views on the probable outcomes of claims, suits, assessments, investigations, or legal proceedings change, changes in the Company’s accrued liabilities would be recorded in the period in which such a determination is made.  For some matters, the amount of liability is not probable or the amount cannot be reasonably estimated and therefore accruals have not been made.

[0001571996-19-000051:notes:238]
The following is a discussion of the Company’s significant legal matters and other proceedings:

[0001571996-19-000051:notes:239]
Securities Litigation — On May 21, 2014, a securities class action seeking compensatory damages was filed in the United States District Court for the Southern District of New York, captioned City of Pontiac General Employees’ Retirement System v. Dell Inc., et. al. (Case No. 1:14-cv-03644).  The action names as defendants Dell Inc. (“Dell”) and certain current and former executive officers, and alleges that Dell made false and misleading statements about Dell’s financial results and future prospects between February 21, 2012 and May 22, 2012, which resulted in artificially inflated stock prices.  The case was transferred to the United States District Court for the Western District of Texas under the same caption (Case No. 1:15-cv-00374), where the defendants filed a motion to dismiss.  On September 16, 2016, the Court denied the motion to dismiss.  On March 29, 2018, the Court granted the plaintiffs’ motion for class certification, and certified a class consisting of all purchasers of Dell common stock between February 22, 2012 and May 22, 2012.  Fact and expert discovery is now closed.  The parties have agreed to an immaterial settlement amount, and the Court has preliminarily approved the settlement.  Notice of the settlement was mailed to shareholders in October 2019.  Shareholders have until December 20, 2019 to opt out or object to the settlement.  A hearing for the final approval of the settlement is set for January 10, 2020.

[0001571996-19-000051:notes:240]
Class Actions Related to the Class V Transaction — Four purported stockholders brought putative class action complaints arising out of the Class V transaction described in Note 14 of the Notes to the Condensed Consolidated Financial Statements.  The actions were captioned Hallandale Beach Police and Fire Retirement Plan v. Michael Dell et al. (Civil Action No. 2018-0816-JTL), Howard Karp v. Michael Dell et al. (Civil Action No. 2019-0032-JTL), Miramar Police Officers’ Retirement Plan v. Michael Dell et al. (Civil Action No. 2019-0049-JTL), and Steamfitters Local 449 Pension Plan v. Michael Dell et al. (Civil Action No. 2019-0115-JTL).  The four actions were consolidated into In Re Dell Class V Litigation (Consol. C.A. No. 2018-0816-JTL), which names as defendants the Company’s board of directors and certain stockholders of the Company, including Michael S. Dell.  The plaintiffs generally allege that the defendants breached their fiduciary duties to the former holders of Class V Common Stock in connection with the Class V transaction by allegedly causing the Company to enter into a transaction that favored the interests of the controlling stockholders at the expense of such former stockholders.  The plaintiffs filed an amended complaint on August 9, 2019 making substantially similar allegations to those described above.  The defendants filed a motion to dismiss the action on September 30, 2019.  The plaintiffs replied to the motion to dismiss on November 15, 2019, and the defendant’s reply is due December 13, 2019.  A ruling on the pending motion is expected in early 2020.

[0001571996-19-000051:notes:241]
Copyright Levies — The Company is involved in various proceedings and negotiations regarding Dell’s obligation to collect and remit copyright levies in certain countries.  The Company continues to collect levies in countries where it has determined that local laws require payment.  The Company, along with other companies and/or industry associations, also continues to oppose levy schemes that do not comply with controlling law.  The Company does not currently anticipate that any of these matters will have a material adverse effect on its business, financial condition, results of operations, or cash flows.

[0001571996-19-000051:notes:242]
Other Litigation — The various legal proceedings in which Dell is involved include commercial and intellectual property litigation.  Dell does not currently anticipate that any of these matters will have a material adverse effect on its business, financial condition, results of operations, or cash flows.

[0001571996-19-000051:notes:243]
As of November 1, 2019, the Company does not believe there is a reasonable possibility that a material loss exceeding the amounts already accrued for these or other proceedings or matters has been incurred.  However, since the ultimate resolution of any such proceedings and matters is inherently unpredictable, the Company’s business, financial condition, results of operations, or cash flows could be materially affected in any particular period by unfavorable outcomes in one or more of these proceedings or matters.  Whether the outcome of any claim, suit, assessment, investigation, or legal proceeding, individually or collectively, could have a material adverse effect on the Company’s business, financial condition, results of operations, or cash flows will depend on a number of variables, including the nature, timing, and amount of any associated expenses, amounts paid in settlement, damages, or other remedies or consequences.

[0001571996-19-000051:notes:244]
Indemnifications

[0001571996-19-000051:notes:245]
In the ordinary course of business, the Company enters into contractual arrangements under which it may agree to indemnify the third party to such arrangements from any losses incurred relating to the services it performs on behalf of the Company or for losses arising from certain events as defined in the particular contract, such as litigation or claims relating to past performance.  Such indemnification obligations may not be subject to maximum loss clauses.  Historically, payments related to these indemnifications have not been material to the Company.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001571996-19-000051:notes:246]
INCOME AND OTHER TAXES

[0001571996-19-000051:notes:247]
For the three months ended November 1, 2019, the Company’s effective income tax rate benefit was 247.2% on pre-tax income of $159 million.  For the three months ended November 2, 2018, the Company’s effective income tax rate was 10.1% on pre-tax losses of $1.0 billion.  For the nine months ended November 1, 2019 and November 2, 2018, the Company’s effective income tax rates were 5482.1% and 9.2%, respectively, on pre-tax losses of $95 million and $2.1 billion, respectively.  The changes in the Company’s effective tax rates are primarily driven by discrete tax items and a change in the Company’s jurisdictional mix of income.  For the three and nine months ended November 1, 2019, the Company’s effective tax rate includes $305 million of discrete tax benefits related to an audit settlement.  The Company’s effective tax rate for the nine months ended November 1, 2019 also includes $4.9 billion of discrete tax benefits related to intra-entity asset transfers described below, $273 million of discrete tax expense related to certain foreign tax credits associated with U.S. Tax Reform discussed below, and $95 million of discrete tax benefits relating to Virtustream impairment charges discussed in Note 8 of the Notes to the Condensed Consolidated Financial Statements.  During the nine months ended November 1, 2019, the Company completed two intra-entity asset transfers of certain of its intellectual property to Irish subsidiaries, resulting in discrete tax benefits of $4.9 billion.  The tax benefit for each intra-entity asset transfer was recorded as a deferred tax asset in the period of transaction and represents the book and tax basis difference on the transferred assets measured based on the applicable Irish statutory tax rate.  The tax deductions for amortization of the assets will be recognized in the future, and any amortization not deducted for tax purposes will be carried forward indefinitely under Irish tax laws.  The Company expects to be able to realize the deferred tax assets resulting from these intra-entity asset transfers.  For the nine months ended November 2, 2018, the Company’s effective tax rate included $154 million of discrete tax benefits resulting from the impact of its adoption of the new revenue recognition standard during the three months ended May 4, 2018.

[0001571996-19-000051:notes:248]
The Tax Cuts and Jobs Act of 2017 (“U.S. Tax Reform”) was signed into law on December 22, 2017.  Among other things, U.S. Tax Reform lowers the U.S. corporate income tax rate to 21% from 35%, establishes a modified territorial system requiring a mandatory deemed repatriation tax on undistributed earnings of foreign subsidiaries, requires a minimum tax on certain future earnings generated by foreign subsidiaries while providing for future tax-free repatriation of earnings through a 100% dividends-received deduction, and places limitations on the deductibility of net interest expense.  In December 2019, the U.S. Department of the Treasury released final and newly proposed regulations related to foreign tax credits and the base erosion anti-abuse tax.  The Company is currently evaluating the impact of these regulations and will recognize any resulting adjustments as necessary.  The Company anticipates that the U.S. Department of the Treasury and the Internal Revenue Service (“IRS”) will continue to issue regulatory guidance clarifying certain provisions of U.S. Tax Reform.  When additional guidance is issued, the Company will recognize the related tax impact in the fiscal quarter of such issuance.

[0001571996-19-000051:notes:249]
The differences between the estimated effective income tax rates and the U.S. federal statutory rate of 21% principally result from the Company’s geographical distribution of income and differences between the book and tax treatment of certain items.  In certain jurisdictions, the Company’s tax rate is significantly less than the applicable statutory rate as a result of tax holidays.  The majority of the Company’s foreign income that is subject to these tax holidays and lower tax rates is attributable to Singapore, China, and Malaysia.  A significant portion of these income tax benefits relates to a tax holiday that will be effective until January 31, 2029.  The Company’s other tax holidays will expire in whole or in part during fiscal years 2022 through 2030.  Many of these tax holidays and reduced tax rates may be extended when certain conditions are met or may be terminated early if certain conditions are not met.  As of November 1, 2019, the Company was not aware of any matters of non-compliance related to these tax holidays.

[0001571996-19-000051:notes:250]
During the three months ended November 1, 2019, the Company made a cash payment of $438 million in settlement of the IRS audit for fiscal years 2007 through 2009.  In May 2017, the IRS commenced a federal income tax audit for fiscal years 2010 through 2014, for which the Company received a Revenue Agent’s Report (“RAR”) in December 2019.  The Company is currently evaluating the contents of the RAR.  The Company believes it has valid positions supporting its tax returns and that it is adequately reserved.

[0001571996-19-000051:notes:251]
The Company is also currently under income tax audits in various state and foreign jurisdictions.  The Company is undergoing negotiations, and in some cases contested proceedings, relating to tax matters with the taxing authorities in these jurisdictions.  The Company believes that it has provided adequate reserves related to all matters contained in tax periods open to examination.  Although the Company believes it has made adequate provisions for the uncertainties surrounding these audits, should the Company experience unfavorable outcomes, such outcomes could have a material impact on its results of operations, financial position, and cash flows.  With respect to major U.S. state and foreign taxing jurisdictions, the Company is generally not subject to tax examinations for years prior to the fiscal year ended January 29, 2010.

[0001571996-19-000051:notes:252]
Judgment is required in evaluating the Company’s uncertain tax positions and determining the Company’s provision for income taxes.  The unrecognized tax benefits were $2.7 billion and $3.4 billion as of November 1, 2019 and February 1, 2019, respectively, and are included in accrued and other and other non-current liabilities in the Condensed Consolidated Statements of Financial Position.  The Company does not anticipate a significant change to the total amount of unrecognized tax benefits within the next twelve months.

[0001571996-19-000051:notes:253]
The Company takes certain non-income tax positions in the jurisdictions in which it operates and has received certain non-income tax assessments from various jurisdictions.  The Company believes that a material loss in these matters is not probable and that it is not reasonably possible that a material loss exceeding amounts already accrued has been incurred.  The Company believes its positions in these non-income tax litigation matters are supportable and that it ultimately will prevail in the matters.  In the normal course of business, the Company’s positions and conclusions related to its non-income taxes could be challenged and assessments may be made.  To the extent new information is obtained and the Company’s views on its positions, probable outcomes of assessments, or litigation change, changes in estimates to the Company’s accrued liabilities would be recorded in the period in which such a determination is made.  In the resolution process for income tax and non-income tax audits, the Company is required in certain situations to provide collateral guarantees or indemnification to regulators and tax authorities until the matter is resolved.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001571996-19-000051:notes:254]
[same as prior period, unchanged from 0001571996-19-000039:notes:239]

[0001571996-19-000051:notes:255]
[same as prior period, unchanged from 0001571996-19-000039:notes:240]

[0001571996-19-000051:notes:256]
[same as prior period, unchanged from 0001571996-19-000039:notes:241]

[0001571996-19-000051:notes:257]
|  | Foreign Currency Translation Adjustments |  | Investments |  | Cash Flow Hedges |  | Pension and Other Postretirement Plans |  | Accumulated Other Comprehensive Income (Loss) |
|  | (in millions) |
| Balances as of February 1, 2019 | $ | (452 | ) |  | $ | — |  |  | $ | (29 | ) |  | $ | 14 |  |  | $ | (467 | ) |
| Other comprehensive income (loss) before reclassifications | (186 | ) |  | — |  |  | 210 |  |  | 8 |  |  | 32 |  |
| Amounts reclassified from accumulated other comprehensive income (loss) | — |  |  | — |  |  | (197 | ) |  | — |  |  | (197 | ) |
| Total change for the period | (186 | ) |  | — |  |  | 13 |  |  | 8 |  |  | (165 | ) |
| Less: Change in comprehensive income (loss) attributable to non-controlling interests | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Balances as of November 1, 2019 | $ | (638 | ) |  | $ | — |  |  | $ | (16 | ) |  | $ | 22 |  |  | $ | (632 | ) |

[0001571996-19-000051:notes:258]
[same as prior period, unchanged from 0001571996-19-000039:notes:243]

[0001571996-19-000051:notes:259]
[same as prior period, unchanged from 0001571996-19-000039:notes:244]

[0001571996-19-000051:notes:260]
|  | Three Months Ended |
|  | November 1, 2019 |  | November 2, 2018 |
|  | Investments |  | Cash Flow Hedges |  | Total |  | Investments |  | Cash Flow Hedges |  | Total |
|  | (in millions) |
| Total reclassifications, net of tax: |  |  |  |  |  |  |  |  |  |  |  |
| Net revenue | $ | — |  |  | $ | 71 |  |  | $ | 71 |  |  | $ | — |  |  | $ | 76 |  |  | $ | 76 |  |
| Cost of net revenue | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Interest and other, net | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Total reclassifications, net of tax | $ | — |  |  | $ | 71 |  |  | $ | 71 |  |  | $ | — |  |  | $ | 76 |  |  | $ | 76 |  |
|  | Nine Months Ended |
|  | November 1, 2019 |  | November 2, 2018 |
|  | Investments |  | Cash Flow Hedges |  | Total |  | Investments |  | Cash Flow Hedges |  | Total |
|  | (in millions) |
| Total reclassifications, net of tax: |  |  |  |  |  |  |  |  |  |  |  |
| Net revenue | $ | — |  |  | $ | 197 |  |  | $ | 197 |  |  | $ | — |  |  | $ | 122 |  |  | $ | 122 |  |
| Cost of net revenue | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Interest and other, net | — |  |  | — |  |  | — |  |  | 1 |  |  | — |  |  | 1 |  |
| Total reclassifications, net of tax | $ | — |  |  | $ | 197 |  |  | $ | 197 |  |  | $ | 1 |  |  | $ | 122 |  |  | $ | 123 |  |


## us-gaap:MinorityInterestDisclosureTextBlock

[0001571996-19-000051:notes:261]
[same as prior period, unchanged from 0001571996-19-000039:notes:246]

[0001571996-19-000051:notes:262]
VMware, Inc. — The non-controlling interests’ share of equity in VMware, Inc. is reflected as a component of the non-controlling interests in the Condensed Consolidated Statements of Financial Position and was $4.5 billion and $3.8 billion as of November 1, 2019 and February 1, 2019, respectively.  As of November 1, 2019 and February 1, 2019, the Company held approximately 80.7% and 80.5%, respectively, of the outstanding equity interest in VMware, Inc.

[0001571996-19-000051:notes:263]
Pivotal — The non-controlling interests’ share of equity in Pivotal is reflected as a component of the non-controlling interests in the Condensed Consolidated Statements of Financial Position and was $1.1 billion and $1.0 billion as of November 1, 2019 and February 1, 2019, respectively.  As of November 1, 2019 and February 1, 2019, the Company held approximately 59.4% and 62.8%, respectively, of the outstanding equity interest in Pivotal.  On August 22, 2019, Pivotal entered into a definitive merger agreement pursuant to which it will be acquired by VMware, Inc..

[0001571996-19-000051:notes:264]
Secureworks — The non-controlling interests’ share of equity in Secureworks is reflected as a component of the non-controlling interests in the Condensed Consolidated Statements of Financial Position and was $87 million as of November 1, 2019 and February 1, 2019.  As of November 1, 2019 and February 1, 2019, the Company held approximately 86.9% and 87.4%, respectively, of the outstanding equity interest in Secureworks, excluding restricted stock awards (“RSAs”).  As of November 1, 2019 and February 1, 2019, the Company held approximately 86.2% and 86.4%, respectively, of the outstanding equity interest in Secureworks, including RSAs.

[0001571996-19-000051:notes:265]
[same as prior period, unchanged from 0001571996-19-000039:notes:250]

[0001571996-19-000051:notes:266]
|  | Nine Months Ended |
|  | November 1, 2019 |
|  | (in millions) |
| Net income attributable to Dell Technologies Inc. | $ | 4,208 |  |
| Transfers (to)/from the non-controlling interests: |  |
| Increase in Dell Technologies Inc. additional paid-in-capital for equity issuances and other equity activity | 616 |  |
| Decrease in Dell Technologies Inc. additional paid-in-capital and accumulated deficit for equity issuances and other equity activity | (1,278 | ) |
| Net transfers to non-controlling interests | (662 | ) |
| Change from net income attributable to Dell Technologies Inc. and transfers to the non-controlling interests | $ | 3,546 |  |


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001571996-19-000051:notes:267]
[same as prior period, unchanged from 0001571996-19-000039:notes:252]

[0001571996-19-000051:notes:268]
[same as prior period, unchanged from 0001571996-19-000039:notes:253]

[0001571996-19-000051:notes:269]
|  | Authorized |  | Issued |  | Outstanding |
|  | (in millions) |
| Common stock as of November 1, 2019 |
| Class A | 600 |  |  | 374 |  |  | 374 |  |
| Class B | 200 |  |  | 119 |  |  | 119 |  |
| Class C | 7,900 |  |  | 238 |  |  | 236 |  |
| Class D | 100 |  |  | — |  |  | — |  |
| Class V | 343 |  |  | — |  |  | — |  |
|  | 9,143 |  |  | 731 |  |  | 729 |  |
| Common stock as of February 1, 2019 |
| Class A | 600 |  |  | 410 |  |  | 410 |  |
| Class B | 200 |  |  | 137 |  |  | 137 |  |
| Class C | 7,900 |  |  | 174 |  |  | 172 |  |
| Class D | 100 |  |  | — |  |  | — |  |
| Class V | 343 |  |  | — |  |  | — |  |
|  | 9,143 |  |  | 721 |  |  | 719 |  |

[0001571996-19-000051:notes:270]
[same as prior period, unchanged from 0001571996-19-000039:notes:255]

[0001571996-19-000051:notes:271]
[same as prior period, unchanged from 0001571996-19-000039:notes:256]

[0001571996-19-000051:notes:272]
The Company is authorized to issue one million shares of preferred stock, par value $0.01 per share.  As of November 1, 2019 and February 1, 2019, no shares of preferred stock were issued or outstanding.

[0001571996-19-000051:notes:273]
[same as prior period, unchanged from 0001571996-19-000039:notes:258]

[0001571996-19-000051:notes:274]
[same as prior period, unchanged from 0001571996-19-000039:notes:259]

[0001571996-19-000051:notes:275]
Dell Technologies Common Stock — For fiscal periods beginning with the first quarter of Fiscal 2020, the Class A Common Stock, the Class B Common Stock, the Class C Common Stock, and the Class D Common Stock, formerly collectively referred to as the DHI Group Common Stock, are collectively referred to as Dell Technologies Common Stock.  The redesignation of such classes of common stock from DHI Group Common Stock to Dell Technologies Common Stock is intended to align the Company’s reporting with how such classes are referred to by securities analysts, investors, and other users of the financial statements since the completion on December 28, 2018 of the Class V transaction described below.  As a result of the cancellation of all outstanding Class V Common Stock upon the closing of that transaction, there is no requirement after the fourth quarter of Fiscal 2019 to allocate net income (loss) between two separate groups of common stock denoted the DHI Group Common Stock and the Class V Common Stock or to report earnings (loss) per share for each such group.  Accordingly, net income (loss), earnings (loss) per share and other relevant information are reported for Dell Technologies Common Stock for all fiscal periods beginning with the first quarter of Fiscal 2020 and, because of lack of comparability with the new reporting, are reported separately for the DHI Group and the Class V Common Stock, as applicable, for prior fiscal periods.  The par value for all classes of Dell Technologies Common Stock is $0.01 per share.  The Class A Common Stock, the Class B Common Stock, the Class C Common Stock, and the Class D Common Stock share equally in dividends declared or accumulated and have equal participation rights in undistributed earnings.

[0001571996-19-000051:notes:276]
[same as prior period, unchanged from 0001571996-19-000039:notes:261]

[0001571996-19-000051:notes:277]
[same as prior period, unchanged from 0001571996-19-000039:notes:262]

[0001571996-19-000051:notes:278]
Class V Common Stock and Class V Group — The Class V Common Stock was a class of common stock intended to track the performance of a portion of Dell Technologies’ economic interest in the Class V Group.  The Class V Group consisted solely of VMware, Inc. common stock held by the Company.  As of November 1, 2019, no shares of Class V Common Stock were outstanding.

[0001571996-19-000051:notes:279]
[same as prior period, unchanged from 0001571996-19-000039:notes:264]

[0001571996-19-000051:notes:280]
Conversion Rights — Under the Company’s certificate of incorporation, at any time and from time to time, any holder of Class A Common Stock or Class B Common Stock has the right to convert all or any of the shares of Class A Common Stock or Class B Common Stock, as applicable, held by such holder into shares of Class C Common Stock on a one-to-one basis.  During the nine months ended November 1, 2019, the Company issued 35,749,396 shares of Class C Common Stock to  stockholders upon their conversion of the same number of shares of Class A Common Stock into Class C Common Stock in accordance with the Company’s certificate of incorporation.  During the nine months ended November 1, 2019, the Company issued 17,650,820 shares of Class C Common Stock to stockholders upon their conversion of the same number of shares of Class B Common Stock into Class C Common Stock in accordance with the Company’s certificate of incorporation.

[0001571996-19-000051:notes:281]
[same as prior period, unchanged from 0001571996-19-000039:notes:266]

[0001571996-19-000051:notes:282]
[same as prior period, unchanged from 0001571996-19-000039:notes:267]

[0001571996-19-000051:notes:283]
[same as prior period, unchanged from 0001571996-19-000039:notes:268]

[0001571996-19-000051:notes:284]
[same as prior period, unchanged from 0001571996-19-000039:notes:269]

[0001571996-19-000051:notes:285]
[same as prior period, unchanged from 0001571996-19-000039:notes:270]

[0001571996-19-000051:notes:286]
[same as prior period, unchanged from 0001571996-19-000039:notes:271]

[0001571996-19-000051:notes:287]
On May 29, 2019, VMware, Inc.’s board of directors authorized the repurchase of an additional $1.5 billion of VMware, Inc.’s Class A common stock.  Since the date of the EMC merger transaction, VMware, Inc.’s board of directors has authorized total repurchases of $3.7 billion, of which $1.1 billion remained available as of November 1, 2019.  During the nine months ended November 1, 2019, VMware, Inc. repurchased 7.3 million shares of its Class A common stock in the open market for approximately $1.3 billion, of which approximately $0.2 billion impacted Dell Technologies’ accumulated deficit balance as of November 1, 2019 as a result of the periodic depletion of VMware, Inc.’s additional paid-in capital balance.  During the nine months ended November 2, 2018, VMware, Inc. did not repurchase any shares of its Class A common stock.

[0001571996-19-000051:notes:288]
[same as prior period, unchanged from 0001571996-19-000039:notes:273]


## us-gaap:EarningsPerShareTextBlock

[0001571996-19-000051:notes:289]
[same as prior period, unchanged from 0001571996-19-000039:notes:274]

[0001571996-19-000051:notes:290]
[same as prior period, unchanged from 0001571996-19-000039:notes:275]

[0001571996-19-000051:notes:291]
[same as prior period, unchanged from 0001571996-19-000039:notes:276]

[0001571996-19-000051:notes:292]
[same as prior period, unchanged from 0001571996-19-000039:notes:277]

[0001571996-19-000051:notes:293]
[same as prior period, unchanged from 0001571996-19-000039:notes:278]

[0001571996-19-000051:notes:294]
For fiscal periods beginning with the first quarter of Fiscal 2020, the Class A Common Stock, the Class B Common Stock, the Class C Common Stock, and the Class D Common Stock, formerly collectively referred to as the DHI Group Common Stock, are collectively referred to as Dell Technologies Common Stock.  The redesignation of such classes of common stock from DHI Group Common Stock to Dell Technologies Common Stock is intended to align the Company’s reporting with how such classes are referred to by securities analysts, investors, and other users of the financial statements since the completion of the Class V transaction.  As a result of the cancellation of all outstanding Class V Common Stock upon the closing of that transaction, there is no requirement after the fourth quarter of Fiscal 2019 to allocate net income (loss) between two separate groups of common stock denoted DHI Group Common Stock and the Class V Common Stock or to report earnings (loss) per share measures for each such group.  Accordingly, net income (loss), earnings (loss) per share and other relevant information are reported for Dell Technologies Common Stock for all fiscal periods beginning with the first quarter of Fiscal 2020 and, because of the lack of comparability with the new reporting, are reported separately for the DHI Group and the Class V Common Stock, as applicable, for prior fiscal periods.

[0001571996-19-000051:notes:295]
[same as prior period, unchanged from 0001571996-19-000039:notes:280]

[0001571996-19-000051:notes:296]
[same as prior period, unchanged from 0001571996-19-000039:notes:281]

[0001571996-19-000051:notes:297]
|  | Three Months Ended |  | Nine Months Ended |
|  | November 1, 2019 |  | November 2, 2018 |  | November 1, 2019 |  | November 2, 2018 |
| Earnings (loss) per share attributable to Dell Technologies Inc. - basic: |  |  |  |  |
| Dell Technologies Common Stock | $ | 0.69 |  |  |  |  | $ | 5.84 |  |  |  |
| Class V Common Stock |  |  | $ | 0.83 |  |  |  |  | $ | 4.80 |  |
| DHI Group |  |  | $ | (1.84 | ) |  |  |  | $ | (5.23 | ) |
| Earnings (loss) per share attributable to Dell Technologies Inc. - diluted: |  |  |  |  |
| Dell Technologies Common Stock | $ | 0.66 |  |  |  |  | $ | 5.50 |  |  |  |
| Class V Common Stock |  |  | $ | 0.81 |  |  |  |  | $ | 4.72 |  |
| DHI Group |  |  | $ | (1.84 | ) |  |  |  | $ | (5.25 | ) |

[0001571996-19-000051:notes:298]
[same as prior period, unchanged from 0001571996-19-000039:notes:283]

[0001571996-19-000051:notes:299]
|  | Three Months Ended |  | Nine Months Ended |
|  | November 1, 2019 |  | November 1, 2019 |
|  | (in millions) |
| Numerator: Dell Technologies Common Stock |  |  |  |
| Net income attributable to Dell Technologies - basic | $ | 499 |  |  | $ | 4,208 |  |
| Incremental dilution from VMware, Inc. attributable to Dell Technologies (a) | (6 | ) |  | (81 | ) |
| Net income attributable to Dell Technologies - diluted | $ | 493 |  |  | $ | 4,127 |  |
| Denominator: Dell Technologies Common Stock weighted-average shares outstanding |  |
| Weighted-average shares outstanding - basic | 725 |  |  | 720 |  |
| Dilutive effect of options, restricted stock units, restricted stock, and other | 25 |  |  | 30 |  |
| Weighted-average shares outstanding - diluted | 750 |  |  | 750 |  |
| Weighted-average shares outstanding - antidilutive | — |  |  | — |  |

[0001571996-19-000051:notes:300]
| (a) | The incremental dilution from VMware, Inc. represents the impact of VMware, Inc.’s dilutive securities on diluted earnings (loss) per share of Dell Technologies Common Stock, and is calculated by multiplying the difference between VMware, Inc.’s basic and diluted earnings (loss) per share by the number of shares of VMware, Inc. common stock held by the Company. There is no incremental dilution from Pivotal and Secureworks due to the net loss position of these entities for the periods presented. |

[0001571996-19-000051:notes:301]
[same as prior period, unchanged from 0001571996-19-000039:notes:286]

[0001571996-19-000051:notes:302]
|  | Three Months Ended |  | Nine Months Ended |
|  | November 2, 2018 |  | November 2, 2018 |
|  | (in millions) |
| Numerator: Class V Common Stock |  |  |  |
| Net income attributable to Class V Common Stock - basic | $ | 165 |  |  | $ | 955 |  |
| Incremental dilution from VMware, Inc. attributable to Class V Common Stock (a) | (3 | ) |  | (15 | ) |
| Net income attributable to Class V Common Stock - diluted | $ | 162 |  |  | $ | 940 |  |
| Numerator: DHI Group |  |  |  |
| Net loss attributable to DHI Group - basic | $ | (1,041 | ) |  | $ | (2,966 | ) |
| Incremental dilution from VMware, Inc. attributable to DHI Group (a) | (1 | ) |  | (9 | ) |
| Net loss attributable to DHI Group - diluted | $ | (1,042 | ) |  | $ | (2,975 | ) |
| Denominator: Class V Common Stock weighted-average shares outstanding |  |  |  |
| Weighted-average shares outstanding - basic | 199 |  |  | 199 |  |
| Dilutive effect of options, restricted stock units, restricted stock, and other (b) | — |  |  | — |  |
| Weighted-average shares outstanding - diluted | 199 |  |  | 199 |  |
| Weighted-average shares outstanding - antidilutive (b) | — |  |  | — |  |
| Denominator: DHI Group weighted-average shares outstanding |  |  |  |
| Weighted-average shares outstanding - basic | 567 |  |  | 567 |  |
| Dilutive effect of options, restricted stock units, restricted stock, and other | — |  |  | — |  |
| Weighted-average shares outstanding - diluted | 567 |  |  | 567 |  |
| Weighted-average shares outstanding - antidilutive (c) | 46 |  |  | 47 |  |

[0001571996-19-000051:notes:303]
[same as prior period, unchanged from 0001571996-19-000039:notes:288]

[0001571996-19-000051:notes:304]
[same as prior period, unchanged from 0001571996-19-000039:notes:289]

[0001571996-19-000051:notes:305]
[same as prior period, unchanged from 0001571996-19-000039:notes:290]

[0001571996-19-000051:notes:306]
[same as prior period, unchanged from 0001571996-19-000039:notes:291]

[0001571996-19-000051:notes:307]
|  | Three Months Ended |  | Nine Months Ended |
|  | November 2, 2018 |  | November 2, 2018 |
|  | (in millions) |
| Net income attributable to Class V Common Stock (a) | $ | 165 |  |  | $ | 955 |  |
| Net loss attributable to DHI Group | (1,041 | ) |  | (2,966 | ) |
| Net loss attributable to Dell Technologies Inc. | $ | (876 | ) |  | $ | (2,011 | ) |

[0001571996-19-000051:notes:308]
[same as prior period, unchanged from 0001571996-19-000039:notes:293]

[0001571996-19-000051:notes:309]
See Exhibit 99.1 filed with the Company’s Quarterly Report on Form 10-Q for the quarterly period ended November 2, 2018 for a reconciliation of VMware net income to net income attributable to Class V Common Stock.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001571996-19-000051:notes:310]
[same as prior period, unchanged from 0001571996-19-000039:notes:295]

[0001571996-19-000051:notes:311]
Dell Technologies Inc. 2013 Stock Incentive Plan (As Amended and Restated as of July, 9, 2019) — During the nine months ended November 1, 2019, the Company’s stockholders approved an amendment to the Dell Technologies Inc. 2013 Stock Incentive Plan (the “Plan”) to authorize an additional 35 million shares of Class C Common Stock for issuance pursuant to the Plan.  Upon effectiveness of the amendment, a total of 110.5 million shares of Class C Common Stock are authorized for issuance.  As of November 1, 2019, there were 55 million shares of Class C Common Stock available for future grants under the Plan.

[0001571996-19-000051:notes:312]
Restricted Stock Units — During the nine months ended November 1, 2019, the Company granted long-term incentive awards in the form of 10.5 million service-based restricted stock units (“RSUs”) and 1.9 million performance-based RSUs in order to align critical talent retention programs with the interests of holders of the Class C Common Stock.

[0001571996-19-000051:notes:313]
[same as prior period, unchanged from 0001571996-19-000039:notes:298]

[0001571996-19-000051:notes:314]
The performance-based RSUs are reflected at target units while the actual number of units that ultimately vest will range from 0% to 200% of target, based on the level of achievement of the performance goals and continued employment with the Company over a performance period ending March 14, 2022.  Approximately 0.9 million of the performance-based RSUs are subject to achievement of market-based performance goals based on relative total shareholder return.  For the non-market performance-based RSUs, the fair values will be based on the closing price of the Class C Common Stock as reported on the NYSE on the accounting grant date.  For the nine months ended November 1, 2019, approximately one-third of the non-market performance awards have been valued and are considered outstanding for accounting purposes.  Market-based performance awards utilized a Monte Carlo valuation model to simulate the probabilities of achievement of relative total shareholder return in order to determine the awards’ fair value.

[0001571996-19-000051:notes:315]
[same as prior period, unchanged from 0001571996-19-000039:notes:300]

[0001571996-19-000051:notes:316]
|  | Nine Months Ended |
|  | November 1, 2019 |
| Weighted-average grant date fair value | $ | 87.17 |  |
| Expected term (in years) | 3.0 |  |
| Risk-free rate (U.S. Government Treasury Note) | 2.4 | % |
| Expected volatility | 45 | % |
| Expected dividend yield | — | % |

[0001571996-19-000051:notes:317]
As of November 1, 2019, 15 million RSUs were outstanding, of which 5 million RSUs were subject to performance conditions.  The awards outstanding have a weighted-average grant date fair value of $50.79 per share and an aggregate intrinsic value of $804 million based on the closing price of the Class C Common Stock as reported on the NYSE on November 1, 2019.  As of November 1, 2019, there was $475 million of unrecognized stock-based compensation expense, net of estimated forfeitures, related to these awards expected to be recognized over a weighted-average period of approximately 2.3 years.

[0001571996-19-000051:notes:318]
Stock Options - Of the 42 million stock options outstanding as of February 1, 2019, 10 million were exercised under the Plan during the nine months ended November 1, 2019 with a weighted-average exercise price of $16.09.  Cash proceeds were $157 million and the pre-tax intrinsic value of the options exercised was $355 million during the nine months ended November 1, 2019.


## dell:TemporaryEquityTextBlock

[0001571996-19-000051:notes:319]
NOTE 17 — REDEEMABLE SHARES

[0001571996-19-000051:notes:320]
Awards under the Company’s stock incentive plans include certain rights that allow the holder to exercise a put feature for the underlying Class A or Class C Common Stock after a six month holding period following the issuance of such common stock.  The put feature requires the Company to purchase the stock at its fair market value.  Accordingly, these awards and such common stock are subject to reclassification from equity to temporary equity, and the Company determines the award amounts to be classified as temporary equity as follows:

[0001571996-19-000051:notes:321]
| • | For stock options to purchase Class C Common Stock subject to service requirements, the intrinsic value of the option is multiplied by the portion of the option for which services have been rendered. Upon exercise of the option, the amount in temporary equity represents the fair value of the Class C Common Stock. |

[0001571996-19-000051:notes:322]
| • | For stock appreciation rights, RSUs, or RSAs, any of which stock award types are subject to service requirements, the fair value of the share is multiplied by the portion of the share for which services have been rendered. |

[0001571996-19-000051:notes:323]
| • | For share-based arrangements that are subject to the occurrence of a contingent event, those amounts are reclassified to temporary equity based on a probability assessment performed by the Company on a periodic basis. Contingent events include the achievement of performance-based metrics. |

[0001571996-19-000051:notes:324]
In connection with the Class V transaction described in Note 14 of the Notes to the Condensed Consolidated Financial Statements, the put feature provisions were amended to provide that the put feature applicable to transfers of Dell Technologies securities will terminate upon the earlier of two years after the expiration on June 27, 2019 of the post-transaction lock-up or consummation of any underwritten public offering of shares of Class C Common Stock.

[0001571996-19-000051:notes:325]
The following table presents the amount of redeemable shares classified as temporary equity and summarizes the award type as of the dates indicated:

[0001571996-19-000051:notes:326]
|  | November 1, 2019 |  | February 1, 2019 |
|  | (in millions) |
| Redeemable shares classified as temporary equity | $ | 934 |  |  | $ | 1,196 |  |
| Issued and outstanding unrestricted common shares | 2 |  |  | 3 |  |
| Restricted stock units | 1 |  |  | 1 |  |
| Restricted stock awards | — |  |  | — |  |
| Outstanding stock options | 21 |  |  | 31 |  |

[0001571996-19-000051:notes:327]
The decrease in the value of redeemable shares during the nine months ended November 1, 2019 was primarily attributable to a decrease in Class C Common Stock fair value, reassessment of vesting probability for performance-based awards and a reduction in the number of shares eligible for put rights as market sales of shares occur.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001571996-19-000051:notes:328]
[same as prior period, unchanged from 0001571996-19-000039:notes:313]

[0001571996-19-000051:notes:329]
[same as prior period, unchanged from 0001571996-19-000039:notes:314]

[0001571996-19-000051:notes:330]
[same as prior period, unchanged from 0001571996-19-000039:notes:315]

[0001571996-19-000051:notes:331]
[same as prior period, unchanged from 0001571996-19-000039:notes:316]

[0001571996-19-000051:notes:332]
[same as prior period, unchanged from 0001571996-19-000039:notes:317]

[0001571996-19-000051:notes:333]
On August 22, 2019, Pivotal entered into a definitive merger agreement pursuant to which it will be acquired by VMware, Inc.  The merger is expected to be completed during the fourth quarter of Fiscal 2020 and will be accounted for as a transaction by entities under common control.  This transaction will require retrospective combination of the VMware, Inc. and Pivotal entities for all periods presented, as if the combination had been in effect since the inception of common control.  Upon the completion of the merger, the Company will report Pivotal results within the VMware reportable segment, rather than in Other businesses.  This change in the segment reporting structure will be reflected as a recast of prior period segment results.

[0001571996-19-000051:notes:334]
[same as prior period, unchanged from 0001571996-19-000039:notes:318]

[0001571996-19-000051:notes:335]
[same as prior period, unchanged from 0001571996-19-000039:notes:319]

[0001571996-19-000051:notes:336]
|  | Three Months Ended |  | Nine Months Ended |
|  | November 1, 2019 |  | November 2, 2018 |  | November 1, 2019 |  | November 2, 2018 |
|  | (in millions) |
| Consolidated net revenue: |  |  |  |  |  |  |  |  |  |  |
| Infrastructure Solutions Group | $ | 8,390 |  |  | $ | 8,937 |  |  | $ | 25,213 |  |  | $ | 26,831 |  |
| Client Solutions Group | 11,410 |  |  | 10,905 |  |  | 34,068 |  |  | 32,304 |  |
| VMware | 2,483 |  |  | 2,229 |  |  | 7,231 |  |  | 6,451 |  |
| Reportable segment net revenue | 22,283 |  |  | 22,071 |  |  | 66,512 |  |  | 65,586 |  |
| Other businesses (a) | 644 |  |  | 583 |  |  | 1,859 |  |  | 1,736 |  |
| Unallocated transactions (b) | 1 |  |  | (3 | ) |  | 1 |  |  | (6 | ) |
| Impact of purchase accounting (c) | (84 | ) |  | (169 | ) |  | (250 | ) |  | (536 | ) |
| Total consolidated net revenue | $ | 22,844 |  |  | $ | 22,482 |  |  | $ | 68,122 |  |  | $ | 66,780 |  |
| Consolidated operating income (loss): |  |  |  |  |  |  |  |
| Infrastructure Solutions Group | $ | 996 |  |  | $ | 935 |  |  | $ | 2,889 |  |  | $ | 2,886 |  |
| Client Solutions Group | 739 |  |  | 447 |  |  | 2,514 |  |  | 1,405 |  |
| VMware | 717 |  |  | 768 |  |  | 2,093 |  |  | 2,117 |  |
| Reportable segment operating income | 2,452 |  |  | 2,150 |  |  | 7,496 |  |  | 6,408 |  |
| Other businesses (a) | (8 | ) |  | (40 | ) |  | (86 | ) |  | (139 | ) |
| Unallocated transactions (b) | (2 | ) |  | (46 | ) |  | (29 | ) |  | (71 | ) |
| Impact of purchase accounting (c) | (96 | ) |  | (193 | ) |  | (299 | ) |  | (630 | ) |
| Amortization of intangibles | (1,057 | ) |  | (1,546 | ) |  | (3,334 | ) |  | (4,594 | ) |
| Transaction-related expenses (d) | (76 | ) |  | (167 | ) |  | (165 | ) |  | (437 | ) |
| Stock-based compensation expense (e) | (322 | ) |  | (256 | ) |  | (886 | ) |  | (671 | ) |
| Other corporate expenses (f) | (55 | ) |  | (258 | ) |  | (792 | ) |  | (388 | ) |
| Total consolidated operating income (loss) | $ | 836 |  |  | $ | (356 | ) |  | $ | 1,905 |  |  | $ | (522 | ) |

[0001571996-19-000051:notes:337]
[same as prior period, unchanged from 0001571996-19-000039:notes:321]

[0001571996-19-000051:notes:338]
[same as prior period, unchanged from 0001571996-19-000039:notes:322]

[0001571996-19-000051:notes:339]
[same as prior period, unchanged from 0001571996-19-000039:notes:323]

[0001571996-19-000051:notes:340]
[same as prior period, unchanged from 0001571996-19-000039:notes:324]

[0001571996-19-000051:notes:341]
[same as prior period, unchanged from 0001571996-19-000039:notes:325]

[0001571996-19-000051:notes:342]
[same as prior period, unchanged from 0001571996-19-000039:notes:326]

[0001571996-19-000051:notes:343]
[same as prior period, unchanged from 0001571996-19-000039:notes:327]

[0001571996-19-000051:notes:344]
|  | Three Months Ended |  | Nine Months Ended |
|  | November 1, 2019 |  | November 2, 2018 |  | November 1, 2019 |  | November 2, 2018 |
|  | (in millions) |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |
| Infrastructure Solutions Group: |  |  |  |  |  |  |  |
| Servers and networking | $ | 4,241 |  |  | $ | 5,054 |  |  | $ | 12,858 |  |  | $ | 14,700 |  |
| Storage | 4,149 |  |  | 3,883 |  |  | 12,355 |  |  | 12,131 |  |
| Total ISG net revenue | 8,390 |  |  | 8,937 |  |  | 25,213 |  |  | 26,831 |  |
| Client Solutions Group: |  |  |  |  |  |  |  |
| Commercial | 8,330 |  |  | 7,613 |  |  | 25,714 |  |  | 23,085 |  |
| Consumer | 3,080 |  |  | 3,292 |  |  | 8,354 |  |  | 9,219 |  |
| Total CSG net revenue | 11,410 |  |  | 10,905 |  |  | 34,068 |  |  | 32,304 |  |
| VMware: |  |  |  |  |  |  |  |
| Total VMware net revenue | 2,483 |  |  | 2,229 |  |  | 7,231 |  |  | 6,451 |  |
| Total segment net revenue | $ | 22,283 |  |  | $ | 22,071 |  |  | $ | 66,512 |  |  | $ | 65,586 |  |


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0001571996-19-000051:notes:345]
[same as prior period, unchanged from 0001571996-19-000039:notes:329]

[0001571996-19-000051:notes:346]
[same as prior period, unchanged from 0001571996-19-000039:notes:330]

[0001571996-19-000051:notes:347]
|  | November 1, 2019 |  | February 1, 2019 |
|  | (in millions) |
| Cash, cash equivalents, and restricted cash: |  |  |  |
| Cash and cash equivalents | $ | 8,555 |  |  | $ | 9,676 |  |
| Restricted cash - other current assets (a) | 654 |  |  | 522 |  |
| Restricted cash - other non-current assets (a) | 132 |  |  | 42 |  |
| Total cash, cash equivalents, and restricted cash | $ | 9,341 |  |  | $ | 10,240 |  |
| Inventories, net: |  |  |  |
| Production materials | $ | 1,491 |  |  | $ | 1,794 |  |
| Work-in-process | 615 |  |  | 702 |  |
| Finished goods | 1,151 |  |  | 1,153 |  |
| Total inventories, net | $ | 3,257 |  |  | $ | 3,649 |  |
| Other non-current liabilities: |  |  |  |
| Warranty liability | $ | 169 |  |  | $ | 169 |  |
| Deferred and other tax liabilities | 3,972 |  |  | 5,527 |  |
| Non-current operating lease liabilities | 1,336 |  |  | — |  |
| Other | 628 |  |  | 631 |  |
| Total other non-current liabilities | $ | 6,105 |  |  | $ | 6,327 |  |

[0001571996-19-000051:notes:348]
[same as prior period, unchanged from 0001571996-19-000039:notes:332]

[0001571996-19-000051:notes:349]
[same as prior period, unchanged from 0001571996-19-000039:notes:333]

[0001571996-19-000051:notes:350]
[same as prior period, unchanged from 0001571996-19-000039:notes:334]

[0001571996-19-000051:notes:351]
|  | Three Months Ended |  | Nine Months Ended |
|  | November 1, 2019 |  | November 2, 2018 |  | November 1, 2019 |  | November 2, 2018 |
|  | (in millions) |
| Warranty liability: |  |  |  |  |  |  |  |
| Warranty liability at beginning of period | $ | 525 |  |  | $ | 542 |  |  | $ | 524 |  |  | $ | 539 |  |
| Costs accrued for new warranty contracts and changes in estimates for pre-existing warranties (a) (b) | 211 |  |  | 226 |  |  | 651 |  |  | 656 |  |
| Service obligations honored | (216 | ) |  | (245 | ) |  | (655 | ) |  | (672 | ) |
| Warranty liability at end of period | $ | 520 |  |  | $ | 523 |  |  | $ | 520 |  |  | $ | 523 |  |
| Current portion | $ | 351 |  |  | $ | 354 |  |  | $ | 351 |  |  | $ | 354 |  |
| Non-current portion | $ | 169 |  |  | $ | 169 |  |  | $ | 169 |  |  | $ | 169 |  |

[0001571996-19-000051:notes:352]
[same as prior period, unchanged from 0001571996-19-000039:notes:336]

[0001571996-19-000051:notes:353]
[same as prior period, unchanged from 0001571996-19-000039:notes:337]

[0001571996-19-000051:notes:354]
[same as prior period, unchanged from 0001571996-19-000039:notes:338]
