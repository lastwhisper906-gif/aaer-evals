# DELL MD&A — 0001571996-19-000051


## mdna

[0001571996-19-000051:mdna:1]
[same as prior period, unchanged from 0001571996-19-000039:mdna:1]

[0001571996-19-000051:mdna:2]
[same as prior period, unchanged from 0001571996-19-000039:mdna:2]

[0001571996-19-000051:mdna:3]
[same as prior period, unchanged from 0001571996-19-000039:mdna:3]

[0001571996-19-000051:mdna:4]
[same as prior period, unchanged from 0001571996-19-000039:mdna:4]

[0001571996-19-000051:mdna:5]
[same as prior period, unchanged from 0001571996-19-000039:mdna:5]

[0001571996-19-000051:mdna:6]
[same as prior period, unchanged from 0001571996-19-000039:mdna:6]

[0001571996-19-000051:mdna:7]
[same as prior period, unchanged from 0001571996-19-000039:mdna:7]

[0001571996-19-000051:mdna:8]
[same as prior period, unchanged from 0001571996-19-000039:mdna:8]

[0001571996-19-000051:mdna:9]
[same as prior period, unchanged from 0001571996-19-000039:mdna:9]

[0001571996-19-000051:mdna:10]
[same as prior period, unchanged from 0001571996-19-000039:mdna:10]

[0001571996-19-000051:mdna:11]
[same as prior period, unchanged from 0001571996-19-000039:mdna:11]

[0001571996-19-000051:mdna:12]
[same as prior period, unchanged from 0001571996-19-000039:mdna:12]

[0001571996-19-000051:mdna:13]
[same as prior period, unchanged from 0001571996-19-000039:mdna:13]

[0001571996-19-000051:mdna:14]
[same as prior period, unchanged from 0001571996-19-000039:mdna:14]

[0001571996-19-000051:mdna:15]
[same as prior period, unchanged from 0001571996-19-000039:mdna:15]

[0001571996-19-000051:mdna:16]
[same as prior period, unchanged from 0001571996-19-000039:mdna:16]

[0001571996-19-000051:mdna:17]
During the third quarter of Fiscal 2020, VMware, Inc. completed its acquisition of Carbon Black, Inc. (“Carbon Black”), a developer of cloud-native endpoint protection, in a cash tender offer at a price of $26.00 per share.  See Note 8 of the Notes to the Condensed Consolidated Financial Statements included in this report for more information regarding the acquisition of Carbon Black.

[0001571996-19-000051:mdna:18]
[same as prior period, unchanged from 0001571996-19-000039:mdna:17]

[0001571996-19-000051:mdna:19]
[same as prior period, unchanged from 0001571996-19-000039:mdna:18]

[0001571996-19-000051:mdna:20]
| • | Pivotal (NYSE: PVTL) provides a leading cloud-native platform that makes software development and IT operations a strategic advantage for customers. Pivotal’s cloud-native platform, Pivotal Cloud Foundry, accelerates and streamlines software development by reducing the complexity of building, deploying, and operating new cloud-native applications and modernizing legacy applications. On April 24, 2018, Pivotal completed a registered underwritten initial public offering of its Class A common stock. |

[0001571996-19-000051:mdna:21]
On August 22, 2019, Pivotal entered into a definitive merger agreement pursuant to which it will be acquired by VMware, Inc.  If the merger is completed, subject to the terms of the merger agreement, holders of shares of the Pivotal Class A common stock will receive $15 in cash per share and Dell Technologies will receive 0.0550 of a share of VMware Class B common stock for each share of the Pivotal Class B common owned by it.  The outstanding shares of Pivotal Class B common stock that are held by VMware, Inc. will be canceled as part of the merger.  Following completion of the merger, the shares of Pivotal Class A common stock will cease to be listed on the New York Stock Exchange and registration of the Pivotal Class A common stock under the Exchange Act will be terminated.  The merger is expected to be completed during the fourth quarter of Fiscal 2020.

[0001571996-19-000051:mdna:22]
The purchase of Pivotal will be accounted for as a transaction by entities under common control.  Assets and liabilities of Pivotal will remain at their historical carrying amounts on the date of the transaction, with no new goodwill being recognized.  This transaction will require retrospective combination of the VMware, Inc. and Pivotal entities for all periods presented, as if the combination had been in effect since the inception of common control.  Upon the completion of the merger, the Company will report Pivotal results within the VMware reportable segment, rather than in Other businesses.  This change in the segment reporting structure will be reflected as a recast of prior period segment results.

[0001571996-19-000051:mdna:23]
| • | Secureworks (NASDAQ: SCWX) is a leading global provider of intelligence-driven information security solutions singularly focused on protecting its clients from cyber attacks. The solutions offered by Secureworks enable organizations of varying size and complexity to fortify their cyber defenses to prevent security breaches, detect malicious activity in near real time, prioritize and respond rapidly to security incidents, and predict emerging threats. |

[0001571996-19-000051:mdna:24]
[same as prior period, unchanged from 0001571996-19-000039:mdna:21]

[0001571996-19-000051:mdna:25]
[same as prior period, unchanged from 0001571996-19-000039:mdna:22]

[0001571996-19-000051:mdna:26]
| • | Boomi specializes in cloud-based integration, connecting information between existing on-premise and cloud-based applications to ensure that business processes are optimized, data is accurate and workflow is reliable. |

[0001571996-19-000051:mdna:27]
[same as prior period, unchanged from 0001571996-19-000039:mdna:24]

[0001571996-19-000051:mdna:28]
[same as prior period, unchanged from 0001571996-19-000039:mdna:25]

[0001571996-19-000051:mdna:29]
70

[0001571996-19-000051:mdna:30]
[same as prior period, unchanged from 0001571996-19-000039:mdna:26]

[0001571996-19-000051:mdna:31]
[same as prior period, unchanged from 0001571996-19-000039:mdna:27]

[0001571996-19-000051:mdna:32]
[same as prior period, unchanged from 0001571996-19-000039:mdna:28]

[0001571996-19-000051:mdna:33]
[same as prior period, unchanged from 0001571996-19-000039:mdna:29]

[0001571996-19-000051:mdna:34]
As part of our strategy, we will continue to evaluate opportunities for strategic investments through our venture capital investment arm, Dell Technologies Capital, with a focus on emerging technology areas that are relevant to the Dell Technologies unique family of businesses and that will complement our existing portfolio of solutions.  Our investment areas include storage, software-defined networking, management and orchestration, security, machine learning and artificial intelligence, Big Data and analytics, cloud, Internet of Things (“IoT”), and software development operations.  In addition to these investments, we also may make disciplined acquisitions targeting businesses that advance our strategic objectives.  As of November 1, 2019 and February 1, 2019, Dell Technologies held strategic investments of $0.8 billion and $1.0 billion, respectively.

[0001571996-19-000051:mdna:35]
[same as prior period, unchanged from 0001571996-19-000039:mdna:31]

[0001571996-19-000051:mdna:36]
[same as prior period, unchanged from 0001571996-19-000039:mdna:32]

[0001571996-19-000051:mdna:37]
[same as prior period, unchanged from 0001571996-19-000039:mdna:33]

[0001571996-19-000051:mdna:38]
We expect that ISG will continue to be impacted by the changing nature of the IT infrastructure market and competitive environment.  The overall server demand environment remains varied among international regions with areas of softness in China and Western Europe.  We will continue to be selective in determining whether to pursue certain large server transactions as we drive for balanced growth and profitability.  With our scale and strong product portfolio, we believe we are well positioned to respond to ongoing competitive dynamics.  Cloud-native applications are expected to continue as a primary growth driver in the infrastructure market as IT organizations increasingly become multi-cloud environments.  We believe the complementary cloud solutions across our business strongly position us to meet these demands for our customers, who are increasingly looking to leverage different forms of cloud-based computing.  We also continue to be impacted by the emerging trends of enterprises deploying software-defined storage, hyper-converged infrastructure, and modular solutions based on server-centric architectures.  These trends are changing the way customers are consuming our traditional storage offerings, and we are focused on enabling new capabilities in our storage portfolio.  Offsetting such trends, however, is the unprecedented data growth throughout all industries, which is generating continued demand for our storage products and services.  We have leading solutions through our ISG and VMware data center offerings.  In addition, through our research and development efforts, we expect to develop new solutions in this rapidly changing industry that we believe will enable us to continue to provide superior solutions to our customers.

[0001571996-19-000051:mdna:39]
In ISG, we are also seeing continued interest in flexible consumption models by our customers as they seek to build greater flexibility into their cost structures.  These solutions are generally multi-year contracts that typically result in recognition of revenue over the term of the arrangement.  We expect these flexible consumption models will further strengthen our customer relationships and will provide more predictable revenue streams over time. We are able to leverage our traditional strength in the PC market to offer solutions and services that provide higher-value, recurring revenue streams.  Given current market trends, we expect that the demand environment will continue to be cyclical.  For instance, CSG demand was robust in the first nine months of Fiscal 2020 as we realized benefits from the Microsoft Windows 10 operating system refresh cycle.  Although we expect continued strong demand into early next year, we expect overall CSG demand will soften in Fiscal 2021 as the Windows 10 refresh cycle winds down.

[0001571996-19-000051:mdna:40]
Competitive dynamics will continue to be a factor in our CSG business as we seek to balance profitability and growth.  We are committed to a long-term growth strategy that we believe will benefit from the consolidation trends that are occurring in the markets in which we compete.  Our CSG offerings are an important element of our strategy, generating strong cash flow and opportunities for cross-selling of complementary solutions.

[0001571996-19-000051:mdna:41]
During the third quarter and first nine months of Fiscal 2020, we recognized benefits to our operating results from significant component cost declines.  We expect component costs to remain deflationary in the aggregate through early next fiscal year, but to a lesser degree relative to the previous three quarters.  We are now beginning to see cost inflation across certain components and we expect the overall environment to be inflationary, which may result in Fiscal 2021 operating results more consistent with historical levels.  The component cost trends and forecasts are dependent on the strength or weakness of actual end user demand and supply dynamics, which will continue to evolve and ultimately impact the translation of the cost environment to pricing and operating results.

[0001571996-19-000051:mdna:42]
Dell Technologies maintains limited-source supplier relationships for processors, because the relationships are advantageous in the areas of performance, quality, support, delivery, capacity, and price considerations.  We are seeing the impact of processor supply constraints on our CSG product offerings.  Delays in the supply of this limited-source component could affect the timing of shipments of certain CSG products in desired quantities or configurations in the fourth quarter and into Fiscal 2021.

[0001571996-19-000051:mdna:43]
The impacts of trade protection measures, including increases in tariffs and trade barriers due to the current geopolitical climate and changes and instability in government policies and international trade arrangements, will continue to affect our ability to conduct business in non-U.S. markets.  Among such impacts, we expect slower demand in China to continue to affect our results into Fiscal 2021.  We continue to mitigate these risks with adjustments to our manufacturing, supply chain and distribution networks.

[0001571996-19-000051:mdna:44]
We manage our business on a U.S. dollar basis.  However, we have a large global presence, generating approximately half of our revenue by sales to customers outside of the United States during both the first nine months of Fiscal 2020 and Fiscal 2019.  As a result, our revenue can be impacted by fluctuations in foreign currency exchange rates.  We utilize a comprehensive hedging strategy intended to mitigate the impact of foreign currency volatility over time, and we adjust pricing when possible to further minimize foreign currency impacts.  During the past twelve months, there has been a sustained weakening of foreign currencies relative to the U.S. dollar, and we will continue to respond to foreign currency fluctuations with appropriate strategies through the end of Fiscal 2020.

[0001571996-19-000051:mdna:45]
[same as prior period, unchanged from 0001571996-19-000039:mdna:38]

[0001571996-19-000051:mdna:46]
[same as prior period, unchanged from 0001571996-19-000039:mdna:39]

[0001571996-19-000051:mdna:47]
[same as prior period, unchanged from 0001571996-19-000039:mdna:40]

[0001571996-19-000051:mdna:48]
[same as prior period, unchanged from 0001571996-19-000039:mdna:41]

[0001571996-19-000051:mdna:49]
[same as prior period, unchanged from 0001571996-19-000039:mdna:42]

[0001571996-19-000051:mdna:50]
[same as prior period, unchanged from 0001571996-19-000039:mdna:54]

[0001571996-19-000051:mdna:51]
[same as prior period, unchanged from 0001571996-19-000039:mdna:43]

[0001571996-19-000051:mdna:52]
[same as prior period, unchanged from 0001571996-19-000039:mdna:44]

[0001571996-19-000051:mdna:53]
[same as prior period, unchanged from 0001571996-19-000039:mdna:45]

[0001571996-19-000051:mdna:54]
[same as prior period, unchanged from 0001571996-19-000039:mdna:46]

[0001571996-19-000051:mdna:55]
[same as prior period, unchanged from 0001571996-19-000039:mdna:47]

[0001571996-19-000051:mdna:56]
Dell Technologies’ non-GAAP net income now excludes, among other items, fair value adjustments on equity investments as well as discrete tax items.  These items were not excluded in the prior presentation of our non-GAAP net income for the three and nine months ended November 2, 2018.  Upon our return to the public markets in December 2018 as a result of the Class V transaction, we reevaluated the presentation of non-GAAP net income and made these changes to facilitate the evaluation of our current operating performance and the comparability of our current operating performance to our past operating performance.  Non-GAAP net income for the three and nine months ended November 2, 2018 has been recast to reflect the current presentation.

[0001571996-19-000051:mdna:57]
[same as prior period, unchanged from 0001571996-19-000039:mdna:49]

[0001571996-19-000051:mdna:58]
[same as prior period, unchanged from 0001571996-19-000039:mdna:50]

[0001571996-19-000051:mdna:59]
[same as prior period, unchanged from 0001571996-19-000039:mdna:51]

[0001571996-19-000051:mdna:60]
| • | Transaction-related Expenses — Transaction-related expenses consist of acquisition, integration, and divestiture related costs, and are expensed as incurred. These expenses primarily represent costs for legal, banking, consulting, and advisory services, as well as certain compensatory retention awards directly related to the EMC merger transaction. During the first nine months of Fiscal 2019, this category also included $216 million of expenses related to integration of our inventory policies and management process, including customer evaluation units and manufacturing and engineering inventory. |

[0001571996-19-000051:mdna:61]
[same as prior period, unchanged from 0001571996-19-000039:mdna:53]

[0001571996-19-000051:mdna:62]
75

[0001571996-19-000051:mdna:63]
| • | Other Corporate Expenses — Other corporate expenses consists primarily of impairment charges and severance, facility action, and other costs. Virtustream gross impairment charges of $619 million and $190 million were incurred during the first nine months of Fiscal 2020 and Fiscal 2019, respectively. See Note 8 of the Notes to the Condensed Consolidated Financial Statements for additional information on Virtustream impairment charges. Severance costs are primarily related to severance and benefits for employees terminated pursuant to cost savings initiatives. We continue to integrate owned and leased facilities and may incur additional costs as we seek opportunities for operational efficiencies. Other corporate expenses vary from period to period and are significantly impacted by the timing and nature of these events. Therefore, although we may incur these types of expenses in the future, we believe that eliminating these charges for purposes of calculating the non-GAAP financial measures presented below facilitates a more meaningful evaluation of our current operating performance and comparisons to our past operating performance. |

[0001571996-19-000051:mdna:64]
| • | Fair Value Adjustments on Equity Investments — Fair value adjustments on equity investments primarily consists of the gain (loss) on strategic investments, which includes the recurring fair value adjustments of investments in publicly-traded companies, as well as those in privately-held companies, which are adjusted for observable price changes and, to a lesser extent, any potential impairments. Given the volatility in the ongoing adjustments to the valuation of these strategic investments, we believe that excluding these gains and losses for purposes of calculating non-GAAP net income presented below facilitates a more meaningful evaluation of our current operating performance and comparisons to our past operating performance. |

[0001571996-19-000051:mdna:65]
| • | Aggregate Adjustment for Income Taxes — The aggregate adjustment for income taxes is the estimated combined income tax effect for the adjustments described above, as well as an adjustment for discrete tax items. Due to the variability in recognition of discrete tax items from period to period, we believe that excluding these benefits or charges for purposes of calculating non-GAAP net income facilitates a more meaningful evaluation of our current operating performance and comparisons to our past operating performance. The tax effects are determined based on the tax jurisdictions where the above items were incurred. This category includes discrete tax benefits of $4.9 billion recorded in the first nine months of Fiscal 2020 for intra-entity asset transfers, and $305 million recorded in the third quarter of Fiscal 2020 related to an audit settlement. See Note 11 of the Notes to the Condensed Consolidated Financial Statements for additional information on our income taxes. |

[0001571996-19-000051:mdna:66]
[same as prior period, unchanged from 0001571996-19-000039:mdna:64]

[0001571996-19-000051:mdna:67]
[same as prior period, unchanged from 0001571996-19-000039:mdna:59]

[0001571996-19-000051:mdna:68]
|  | Three Months Ended |  | Nine Months Ended |
|  | November 1, 2019 |  | % Change |  | November 2, 2018 |  | November 1, 2019 |  | % Change |  | November 2, 2018 |
|  | (in millions, except percentages) |
| Product net revenue | $ | 17,485 |  |  | (1 | )% |  | $ | 17,625 |  |  | $ | 52,349 |  |  | — | % |  | $ | 52,445 |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Impact of purchase accounting | 5 |  |  |  |  | 15 |  |  | 15 |  |  |  |  | 50 |  |
| Non-GAAP product net revenue | $ | 17,490 |  |  | (1 | )% |  | $ | 17,640 |  |  | $ | 52,364 |  |  | — | % |  | $ | 52,495 |  |
| Services net revenue | $ | 5,359 |  |  | 10 | % |  | $ | 4,857 |  |  | $ | 15,773 |  |  | 10 | % |  | $ | 14,335 |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Impact of purchase accounting | 79 |  |  |  |  | 154 |  |  | 235 |  |  |  |  | 486 |  |
| Non-GAAP services net revenue | $ | 5,438 |  |  | 9 | % |  | $ | 5,011 |  |  | $ | 16,008 |  |  | 8 | % |  | $ | 14,821 |  |
| Net revenue | $ | 22,844 |  |  | 2 | % |  | $ | 22,482 |  |  | $ | 68,122 |  |  | 2 | % |  | $ | 66,780 |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Impact of purchase accounting | 84 |  |  |  |  | 169 |  |  | 250 |  |  |  |  | 536 |  |
| Non-GAAP net revenue | $ | 22,928 |  |  | 1 | % |  | $ | 22,651 |  |  | $ | 68,372 |  |  | 2 | % |  | $ | 67,316 |  |
| Product gross margin | $ | 3,927 |  |  | 28 | % |  | $ | 3,060 |  |  | $ | 11,823 |  |  | 27 | % |  | $ | 9,331 |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 517 |  |  |  |  | 726 |  |  | 1,555 |  |  |  |  | 2,154 |  |
| Impact of purchase accounting | 7 |  |  |  |  | 17 |  |  | 20 |  |  |  |  | 63 |  |
| Transaction-related expenses | — |  |  |  |  | 99 |  |  | (5 | ) |  |  |  | 236 |  |
| Stock-based compensation expense | 3 |  |  |  |  | 2 |  |  | 9 |  |  |  |  | 5 |  |
| Other corporate expenses | 2 |  |  |  |  | — |  |  | 11 |  |  |  |  | 3 |  |
| Non-GAAP product gross margin | $ | 4,456 |  |  | 14 | % |  | $ | 3,904 |  |  | $ | 13,413 |  |  | 14 | % |  | $ | 11,792 |  |
| Services gross margin | $ | 3,199 |  |  | 11 | % |  | $ | 2,883 |  |  | $ | 9,426 |  |  | 9 | % |  | $ | 8,613 |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Impact of purchase accounting | 79 |  |  |  |  | 154 |  |  | 235 |  |  |  |  | 486 |  |
| Transaction-related expenses | — |  |  |  |  | 3 |  |  | — |  |  |  |  | 3 |  |
| Stock-based compensation expense | 30 |  |  |  |  | 18 |  |  | 82 |  |  |  |  | 49 |  |
| Other corporate expenses | 4 |  |  |  |  | 38 |  |  | 32 |  |  |  |  | 42 |  |
| Non-GAAP services gross margin | $ | 3,312 |  |  | 7 | % |  | $ | 3,096 |  |  | $ | 9,775 |  |  | 6 | % |  | $ | 9,193 |  |

[0001571996-19-000051:mdna:69]
|  | Three Months Ended |  | Nine Months Ended |
|  | November 1, 2019 |  | % Change |  | November 2, 2018 |  | November 1, 2019 |  | % Change |  | November 2, 2018 |
|  | (in millions, except percentages) |
| Gross margin | $ | 7,126 |  |  | 20 | % |  | $ | 5,943 |  |  | $ | 21,249 |  |  | 18 | % |  | $ | 17,944 |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 517 |  |  |  |  | 726 |  |  | 1,555 |  |  |  |  | 2,154 |  |
| Impact of purchase accounting | 86 |  |  |  |  | 171 |  |  | 255 |  |  |  |  | 549 |  |
| Transaction-related expenses | — |  |  |  |  | 102 |  |  | (5 | ) |  |  |  | 239 |  |
| Stock-based compensation expense | 33 |  |  |  |  | 20 |  |  | 91 |  |  |  |  | 54 |  |
| Other corporate expenses | 6 |  |  |  |  | 38 |  |  | 43 |  |  |  |  | 45 |  |
| Non-GAAP gross margin | $ | 7,768 |  |  | 11 | % |  | $ | 7,000 |  |  | $ | 23,188 |  |  | 10 | % |  | $ | 20,985 |  |
| Operating expenses | $ | 6,290 |  |  | — | % |  | $ | 6,299 |  |  | $ | 19,344 |  |  | 5 | % |  | $ | 18,466 |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | (540 | ) |  |  |  | (820 | ) |  | (1,779 | ) |  |  |  | (2,440 | ) |
| Impact of purchase accounting | (10 | ) |  |  |  | (22 | ) |  | (44 | ) |  |  |  | (81 | ) |
| Transaction-related expenses | (76 | ) |  |  |  | (65 | ) |  | (170 | ) |  |  |  | (198 | ) |
| Stock-based compensation expense | (289 | ) |  |  |  | (236 | ) |  | (795 | ) |  |  |  | (617 | ) |
| Other corporate expenses | (49 | ) |  |  |  | (220 | ) |  | (749 | ) |  |  |  | (343 | ) |
| Non-GAAP operating expenses | $ | 5,326 |  |  | 8 | % |  | $ | 4,936 |  |  | $ | 15,807 |  |  | 7 | % |  | $ | 14,787 |  |
| Operating income (loss) | $ | 836 |  |  | 335 | % |  | $ | (356 | ) |  | $ | 1,905 |  |  | 465 | % |  | $ | (522 | ) |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 1,057 |  |  |  |  | 1,546 |  |  | 3,334 |  |  |  |  | 4,594 |  |
| Impact of purchase accounting | 96 |  |  |  |  | 193 |  |  | 299 |  |  |  |  | 630 |  |
| Transaction-related expenses | 76 |  |  |  |  | 167 |  |  | 165 |  |  |  |  | 437 |  |
| Stock-based compensation expense | 322 |  |  |  |  | 256 |  |  | 886 |  |  |  |  | 671 |  |
| Other corporate expenses | 55 |  |  |  |  | 258 |  |  | 792 |  |  |  |  | 388 |  |
| Non-GAAP operating income | $ | 2,442 |  |  | 18 | % |  | $ | 2,064 |  |  | $ | 7,381 |  |  | 19 | % |  | $ | 6,198 |  |
| Net income (loss) | $ | 552 |  |  | 162 | % |  | $ | (895 | ) |  | $ | 5,113 |  |  | 370 | % |  | $ | (1,894 | ) |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 1,057 |  |  |  |  | 1,546 |  |  | 3,334 |  |  |  |  | 4,594 |  |
| Impact of purchase accounting | 96 |  |  |  |  | 193 |  |  | 299 |  |  |  |  | 630 |  |
| Transaction-related expenses | 76 |  |  |  |  | 167 |  |  | 165 |  |  |  |  | 437 |  |
| Stock-based compensation expense | 322 |  |  |  |  | 256 |  |  | 886 |  |  |  |  | 671 |  |
| Other corporate expenses | 55 |  |  |  |  | 258 |  |  | 792 |  |  |  |  | 388 |  |
| Fair value adjustments on equity investments | (18 | ) |  |  |  | 17 |  |  | (160 | ) |  |  |  | (229 | ) |
| Aggregate adjustment for income taxes | (695 | ) |  |  |  | (345 | ) |  | (6,024 | ) |  |  |  | (962 | ) |
| Non-GAAP net income (a) | $ | 1,445 |  |  | 21 | % |  | $ | 1,197 |  |  | $ | 4,405 |  |  | 21 | % |  | $ | 3,635 |  |

[0001571996-19-000051:mdna:70]
[same as prior period, unchanged from 0001571996-19-000039:mdna:62]

[0001571996-19-000051:mdna:71]
[same as prior period, unchanged from 0001571996-19-000039:mdna:63]

[0001571996-19-000051:mdna:72]
[same as prior period, unchanged from 0001571996-19-000039:mdna:84]

[0001571996-19-000051:mdna:73]
In addition to the above measures, we also use EBITDA and adjusted EBITDA to provide additional information for evaluation of our operating performance.  Adjusted EBITDA excludes purchase accounting adjustments related to the EMC merger transaction and the going-private transaction, acquisition, integration, and divestiture related costs, impairment charges,  severance, facility action, and other costs, and stock-based compensation expense.  We believe that, due to the non-operational nature of the purchase accounting entries, it is appropriate to exclude these adjustments.

[0001571996-19-000051:mdna:74]
[same as prior period, unchanged from 0001571996-19-000039:mdna:66]

[0001571996-19-000051:mdna:75]
[same as prior period, unchanged from 0001571996-19-000039:mdna:67]

[0001571996-19-000051:mdna:76]
|  | Three Months Ended |  | Nine Months Ended |
|  | November 1, 2019 |  | % Change |  | November 2, 2018 |  | November 1, 2019 |  | % Change |  | November 2, 2018 |
|  | (in millions, except percentages) |
| Net income (loss) | $ | 552 |  |  | 162 | % |  | $ | (895 | ) |  | $ | 5,113 |  |  | 370 | % |  | $ | (1,894 | ) |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Interest and other, net (a) | 677 |  |  |  |  | 639 |  |  | 2,000 |  |  |  |  | 1,564 |  |
| Income tax benefit (b) | (393 | ) |  |  |  | (100 | ) |  | (5,208 | ) |  |  |  | (192 | ) |
| Depreciation and amortization | 1,494 |  |  |  |  | 1,961 |  |  | 4,608 |  |  |  |  | 5,806 |  |
| EBITDA | $ | 2,330 |  |  | 45 | % |  | $ | 1,605 |  |  | $ | 6,513 |  |  | 23 | % |  | $ | 5,284 |  |
| EBITDA | $ | 2,330 |  |  | 45 | % |  | $ | 1,605 |  |  | $ | 6,513 |  |  | 23 | % |  | $ | 5,284 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation expense | 322 |  |  |  |  | 256 |  |  | 886 |  |  |  |  | 671 |  |
| Impact of purchase accounting (c) | 84 |  |  |  |  | 169 |  |  | 251 |  |  |  |  | 536 |  |
| Transaction-related expenses (d) | 76 |  |  |  |  | 158 |  |  | 165 |  |  |  |  | 409 |  |
| Other corporate expenses (e) | 45 |  |  |  |  | 238 |  |  | 771 |  |  |  |  | 368 |  |
| Adjusted EBITDA | $ | 2,857 |  |  | 18 | % |  | $ | 2,426 |  |  | $ | 8,586 |  |  | 18 | % |  | $ | 7,268 |  |

[0001571996-19-000051:mdna:77]
[same as prior period, unchanged from 0001571996-19-000039:mdna:69]

[0001571996-19-000051:mdna:78]
[same as prior period, unchanged from 0001571996-19-000039:mdna:70]

[0001571996-19-000051:mdna:79]
| (b) | See Note 11 of the Notes to the Condensed Consolidated Financial Statements for additional information on discrete tax items recorded during the first nine months of Fiscal 2020. |

[0001571996-19-000051:mdna:80]
[same as prior period, unchanged from 0001571996-19-000039:mdna:72]

[0001571996-19-000051:mdna:81]
[same as prior period, unchanged from 0001571996-19-000039:mdna:73]

[0001571996-19-000051:mdna:82]
[same as prior period, unchanged from 0001571996-19-000039:mdna:74]

[0001571996-19-000051:mdna:83]
79

[0001571996-19-000051:mdna:84]
[same as prior period, unchanged from 0001571996-19-000039:mdna:75]

[0001571996-19-000051:mdna:85]
[same as prior period, unchanged from 0001571996-19-000039:mdna:76]

[0001571996-19-000051:mdna:86]
[same as prior period, unchanged from 0001571996-19-000039:mdna:77]

[0001571996-19-000051:mdna:87]
|  | Three Months Ended |  | Nine Months Ended |
|  | November 1, 2019 |  |  |  | November 2, 2018 |  | November 1, 2019 |  |  |  | November 2, 2018 |
|  | Dollars |  | % ofNet Revenue |  | %Change |  | Dollars |  | % ofNet Revenue |  | Dollars |  | % ofNet Revenue |  | %Change |  | Dollars |  | % ofNet Revenue |
|  | (in millions, except percentages) |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 17,485 |  |  | 76.5 | % |  | (1 | )% |  | $ | 17,625 |  |  | 78.4 | % |  | $ | 52,349 |  |  | 76.8 | % |  | — | % |  | $ | 52,445 |  |  | 78.5 | % |
| Services | 5,359 |  |  | 23.5 | % |  | 10 | % |  | 4,857 |  |  | 21.6 | % |  | 15,773 |  |  | 23.2 | % |  | 10 | % |  | 14,335 |  |  | 21.5 | % |
| Total net revenue | $ | 22,844 |  |  | 100.0 | % |  | 2 | % |  | $ | 22,482 |  |  | 100.0 | % |  | $ | 68,122 |  |  | 100.0 | % |  | 2 | % |  | $ | 66,780 |  |  | 100.0 | % |
| Gross margin: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product (a) | $ | 3,927 |  |  | 22.5 | % |  | 28 | % |  | $ | 3,060 |  |  | 17.4 | % |  | $ | 11,823 |  |  | 22.6 | % |  | 27 | % |  | $ | 9,331 |  |  | 17.8 | % |
| Services (b) | 3,199 |  |  | 59.7 | % |  | 11 | % |  | 2,883 |  |  | 59.4 | % |  | 9,426 |  |  | 59.8 | % |  | 9 | % |  | 8,613 |  |  | 60.1 | % |
| Total gross margin | $ | 7,126 |  |  | 31.2 | % |  | 20 | % |  | $ | 5,943 |  |  | 26.4 | % |  | $ | 21,249 |  |  | 31.2 | % |  | 18 | % |  | $ | 17,944 |  |  | 26.9 | % |
| Operating expenses | $ | 6,290 |  |  | 27.5 | % |  | — | % |  | $ | 6,299 |  |  | 28.0 | % |  | $ | 19,344 |  |  | 28.4 | % |  | 5 | % |  | $ | 18,466 |  |  | 27.7 | % |
| Operating income (loss) | $ | 836 |  |  | 3.7 | % |  | 335 | % |  | $ | (356 | ) |  | (1.6 | )% |  | $ | 1,905 |  |  | 2.8 | % |  | 465 | % |  | $ | (522 | ) |  | (0.8 | )% |
| Net income (loss) | $ | 552 |  |  | 2.4 | % |  | 162 | % |  | $ | (895 | ) |  | (4.0 | )% |  | $ | 5,113 |  |  | 7.5 | % |  | 370 | % |  | $ | (1,894 | ) |  | (2.8 | )% |
| Net income (loss) attributable to Dell Technologies Inc. | $ | 499 |  |  | 2.2 | % |  | 157 | % |  | $ | (876 | ) |  | (3.9 | )% |  | $ | 4,208 |  |  | 6.2 | % |  | 309 | % |  | $ | (2,011 | ) |  | (3.0 | )% |
| Non-GAAP Financial Information |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Non-GAAP net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 17,490 |  |  | 76.3 | % |  | (1 | )% |  | $ | 17,640 |  |  | 77.9 | % |  | $ | 52,364 |  |  | 76.6 | % |  | — | % |  | $ | 52,495 |  |  | 78.0 | % |
| Services | 5,438 |  |  | 23.7 | % |  | 9 | % |  | 5,011 |  |  | 22.1 | % |  | 16,008 |  |  | 23.4 | % |  | 8 | % |  | 14,821 |  |  | 22.0 | % |
| Total non-GAAP net revenue | $ | 22,928 |  |  | 100.0 | % |  | 1 | % |  | $ | 22,651 |  |  | 100.0 | % |  | $ | 68,372 |  |  | 100.0 | % |  | 2 | % |  | $ | 67,316 |  |  | 100.0 | % |
| Non-GAAP gross margin: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product (a) | $ | 4,456 |  |  | 25.5 | % |  | 14 | % |  | $ | 3,904 |  |  | 22.1 | % |  | $ | 13,413 |  |  | 25.6 | % |  | 14 | % |  | $ | 11,792 |  |  | 22.5 | % |
| Services (b) | 3,312 |  |  | 60.9 | % |  | 7 | % |  | 3,096 |  |  | 61.8 | % |  | 9,775 |  |  | 61.1 | % |  | 6 | % |  | 9,193 |  |  | 62.0 | % |
| Total non-GAAP gross margin | $ | 7,768 |  |  | 33.9 | % |  | 11 | % |  | $ | 7,000 |  |  | 30.9 | % |  | $ | 23,188 |  |  | 33.9 | % |  | 10 | % |  | $ | 20,985 |  |  | 31.2 | % |
| Non-GAAP operating expenses | $ | 5,326 |  |  | 23.2 | % |  | 8 | % |  | $ | 4,936 |  |  | 21.8 | % |  | $ | 15,807 |  |  | 23.1 | % |  | 7 | % |  | $ | 14,787 |  |  | 22.0 | % |
| Non-GAAP operating income | $ | 2,442 |  |  | 10.7 | % |  | 18 | % |  | $ | 2,064 |  |  | 9.1 | % |  | $ | 7,381 |  |  | 10.8 | % |  | 19 | % |  | $ | 6,198 |  |  | 9.2 | % |
| Non-GAAP net income (c) | $ | 1,445 |  |  | 6.3 | % |  | 21 | % |  | $ | 1,197 |  |  | 5.3 | % |  | $ | 4,405 |  |  | 6.4 | % |  | 21 | % |  | $ | 3,635 |  |  | 5.4 | % |
| EBITDA | $ | 2,330 |  |  | 10.2 | % |  | 45 | % |  | $ | 1,605 |  |  | 7.1 | % |  | $ | 6,513 |  |  | 9.5 | % |  | 23 | % |  | $ | 5,284 |  |  | 7.8 | % |
| Adjusted EBITDA | $ | 2,857 |  |  | 12.5 | % |  | 18 | % |  | $ | 2,426 |  |  | 10.7 | % |  | $ | 8,586 |  |  | 12.6 | % |  | 18 | % |  | $ | 7,268 |  |  | 10.8 | % |

[0001571996-19-000051:mdna:88]
[same as prior period, unchanged from 0001571996-19-000039:mdna:79]

[0001571996-19-000051:mdna:89]
[same as prior period, unchanged from 0001571996-19-000039:mdna:80]

[0001571996-19-000051:mdna:90]
[same as prior period, unchanged from 0001571996-19-000039:mdna:81]

[0001571996-19-000051:mdna:91]
[same as prior period, unchanged from 0001571996-19-000039:mdna:82]

[0001571996-19-000051:mdna:92]
[same as prior period, unchanged from 0001571996-19-000039:mdna:104]

[0001571996-19-000051:mdna:93]
[same as prior period, unchanged from 0001571996-19-000039:mdna:85]

[0001571996-19-000051:mdna:94]
[same as prior period, unchanged from 0001571996-19-000039:mdna:86]

[0001571996-19-000051:mdna:95]
During both the third quarter and first nine months of Fiscal 2020, our net revenue increased 2%.  During the third quarter and first nine months of Fiscal 2020, our non-GAAP net revenue increased 1% and 2%, respectively.  The increases in net revenue and non-GAAP net revenue were attributable to increases in net revenue in CSG and VMware, which were partially offset by declines in ISG net revenue.  The increase in CSG revenue primarily resulted from the Microsoft Windows 10 operating system refresh cycle combined with strong execution by the business.  VMware net revenue increased due to growth in software license revenue and strong renewals of VMware enterprise agreements, maintenance contracts sold in previous periods, and additional maintenance contracts sold in conjunction with new software license sales.  ISG net revenue decreased primarily because of weakness in servers and networking.  During the first nine months of Fiscal 2020, we benefited from the strength of our broad IT solutions portfolio, which helped us navigate market volatility and competitive pressures.  We believe we are well-positioned for long-term profitable growth while also maintaining the ability to adjust as needed to changing market conditions with complementary solutions across our businesses.

[0001571996-19-000051:mdna:96]
During the third quarter of Fiscal 2020, our operating income was $836 million compared to an operating loss of $356 million during the third quarter of Fiscal 2019.  During the first nine months of Fiscal 2020, our operating income was $1.9 billion compared to an operating loss of $522 million during the first nine months of Fiscal 2019.  The increases in our operating income for the third quarter and first nine months of Fiscal 2020 were primarily attributable to an increase in operating income for CSG due to lower component costs and a decrease in amortization of intangible assets.  During the first nine months, these benefits were partially offset by an increase in other corporate expenses, which primarily included Virtustream impairment charges.

[0001571996-19-000051:mdna:97]
Amortization of intangible assets and other corporate expenses that impacted our operating income totaled $1.1 billion and $1.8 billion for the third quarter of Fiscal 2020 and Fiscal 2019, respectively, and $4.1 billion and 5.0 billion for the first nine months of Fiscal 2020 and Fiscal 2019, respectively.  Excluding these costs, the impact of purchase accounting, stock-based compensation expense, and transaction-related expenses, our non-GAAP operating income was $2.4 billion and $2.1 billion during the third quarter of Fiscal 2020 and Fiscal 2019, respectively.  During the first nine months of Fiscal 2020 and Fiscal 2019, our non-GAAP operating income was $7.4 billion and $6.2 billion, respectively.  The increases in our non-GAAP operating income for the third quarter and first nine months of Fiscal 2020 were primarily due to an increase in operating income for CSG.

[0001571996-19-000051:mdna:98]
Cash provided by operating activities was $5.8 billion and $4.6 billion during the first nine months of Fiscal 2020 and Fiscal 2019, respectively.  The increase in operating cash flows during the first nine months of Fiscal 2020 was primarily driven by improved profitability and continued working capital discipline.  See “Market Conditions, Liquidity, and Capital Commitments” for further information on our cash flow metrics.

[0001571996-19-000051:mdna:99]
[same as prior period, unchanged from 0001571996-19-000039:mdna:91]

[0001571996-19-000051:mdna:100]
During both the third quarter and first nine months of Fiscal 2020, our net revenue increased 2%.  During the third quarter and first nine months of Fiscal 2020, our non-GAAP net revenue increased 1% and 2%, respectively.  The increases in net revenue and non-GAAP net revenue were primarily attributable to increases in net revenue in CSG and VMware, which were partially offset by declines in ISG net revenue.  See “Business Unit Results” for further information.

[0001571996-19-000051:mdna:101]
| • | Product Net Revenue — Product net revenue includes revenue from the sale of hardware products and software licenses. During the third quarter of Fiscal 2020, product net revenue and non-GAAP product net revenue decreased 1%. During the first nine months of Fiscal 2020, product net revenue and non-GAAP product net revenue were unchanged. For the periods presented, these changes were driven by decreases in product net revenue for ISG servers and networking, which were offset by increases in product net revenue for CSG and VMware. |

[0001571996-19-000051:mdna:102]
| • | Services Net Revenue — Services net revenue includes revenue from our services offerings and support services related to hardware products and software licenses. During the third quarter of Fiscal 2020, services net revenue and non-GAAP services net revenue increased 10% and 9%, respectively. During the first nine months of Fiscal 2020, services net revenue and non-GAAP services net revenue increased 10% and 8%, respectively. These increases were primarily due to an increase in services revenue for hardware support and deployment and software maintenance due to growth in CSG and VMware. A substantial portion of services net revenue is derived from offerings that have been deferred over a period of time, and, as a result, reported services net revenue growth rates will be different than reported product net revenue growth rates. |

[0001571996-19-000051:mdna:103]
From a geographical perspective, net revenue generated by sales to customers in the Americas increased during the third quarter of Fiscal 2020 due to strong performance in CSG and VMware.  Net revenue from sales to customers in APJ decreased slightly during the third quarter of Fiscal 2020, primarily as the result of a weaker demand environment for ISG servers and networking, particularly in China.  In EMEA, net revenue from sales to customers remained flat during the third quarter of Fiscal 2020.

[0001571996-19-000051:mdna:104]
Net revenue generated by sales to customers in the Americas and EMEA increased during the first nine months of Fiscal 2020 due to strong performance in CSG and VMware.  Net revenue from sales to customers in APJ remained flat during the first nine months of Fiscal 2020.

[0001571996-19-000051:mdna:105]
[same as prior period, unchanged from 0001571996-19-000039:mdna:98]

[0001571996-19-000051:mdna:106]
During the third quarter and first nine months of Fiscal 2020, our gross margin increased 20% to $7.1 billion and 18% to $21.2 billion, respectively.  During the third quarter and first nine months of Fiscal 2020, our gross margin percentage increased 480 basis points to 31.2% and 430 basis points to 31.2%, respectively.  The increases in our gross margin percentage during the third quarter and first nine months of Fiscal 2020 were primarily attributable to a deflationary component cost environment and a decrease in amortization of intangibles and purchase accounting adjustments.

[0001571996-19-000051:mdna:107]
Our gross margin for the third quarter and first nine months of Fiscal 2020 included the impact of amortization of intangibles and purchase accounting adjustments of $0.6 billion and $1.8 billion, respectively.  Excluding these costs, transaction-related expenses, stock-based compensation expense, and other corporate expenses, non-GAAP gross margin for the third quarter and first nine months of Fiscal 2020 increased 11% to $7.8 billion and 10% to $23.2 billion, respectively, and non-GAAP gross margin percentage increased 300 basis points to 33.9% and 270 basis points to 33.9%, respectively.  The increases in our non-GAAP gross margin were attributable to increases in gross margin across all three business units.  The increases in our non-GAAP gross margin percentage were primarily due to higher gross margin percentages for both ISG and CSG which benefited from the deflationary component cost environment.

[0001571996-19-000051:mdna:108]
| • | Products — During the third quarter of Fiscal 2020, product gross margin increased 28% to $3.9 billion, and product gross margin percentage increased 510 basis points to 22.5%. During the third quarter of Fiscal 2020, non-GAAP product gross margin increased 14% to $4.5 billion, and non-GAAP product gross margin percentage increased 340 basis points to 25.5%. The increases in product gross margin and non-GAAP product gross margin were driven by primarily by the strength in sales of CSG commercial products and VMware software licenses and the deflationary component cost environment for ISG and CSG. Product gross margin also benefited from a decrease in amortization of intangibles and transaction-related costs. Product gross margin percentage and non-GAAP product gross margin percentage increased primarily due to the higher product gross margin percentages for both ISG and CSG, which benefited from the deflationary component cost environment. |

[0001571996-19-000051:mdna:109]
During the first nine months of Fiscal 2020, product gross margin increased 27% to $11.8 billion, and product gross margin percentage increased 480 basis points to 22.6%.  During the first nine months of Fiscal 2020, non-GAAP product gross margin increased 14% to $13.4 billion, and non-GAAP product gross margin percentage increased 310 basis points to 25.6%.  The increases in product gross margin and non-GAAP product gross margin were driven primarily by increases in product revenue due to strength in sales of CSG commercial products and VMware software licenses and the deflationary component cost environment for ISG and CSG.  Product gross margin also benefited from a decrease in amortization of intangibles and transaction-related costs.  Product gross margin percentage and non-GAAP product gross margin percentage increased primarily as a result of higher product gross margin percentages for both ISG and CSG, which benefited from the deflationary component cost environment.

[0001571996-19-000051:mdna:110]
[same as prior period, unchanged from 0001571996-19-000039:mdna:120]

[0001571996-19-000051:mdna:111]
| • | Services — During the third quarter of Fiscal 2020, services gross margin increased 11% to $3.2 billion, and services gross margin percentage increased 30 basis points to 59.7%. Services gross margin increased due to growth in VMware software maintenance. Services gross margin also benefited from a decrease in purchase accounting adjustments, which totaled $79 million and $154 million during the third quarter of Fiscal 2020 and Fiscal 2019, respectively. Excluding these adjustments, transaction-related expenses, stock-based compensation expense, and other corporate expenses, non-GAAP services gross margin increased 7% to $3.3 billion, and non-GAAP services gross margin percentage decreased 90 basis points to 60.9%. The decrease in services gross margin percentage was primarily attributable to a change in mix of software and hardware maintenance for CSG and ISG, although the deflation in the third quarter of Fiscal 2020 was at a lower rate than during the first six months of Fiscal 2020 . |

[0001571996-19-000051:mdna:112]
During the first nine months of Fiscal 2020, services gross margin increased 9% to $9.4 billion, and services gross margin percentage decreased 30 basis points to 59.8%.  Services gross margin increased due to growth in services gross margin in VMware software maintenance.  The decrease in services gross margin percentage was attributable to lower CSG services gross margin.  Services gross margin benefited from a decrease in purchase accounting adjustments, which totaled $0.2 billion and $0.5 billion during the first nine months of Fiscal 2020 and Fiscal 2019, respectively.  Excluding these adjustments, transaction-related expenses, stock-based compensation expense, and other corporate expenses, non-GAAP services gross margin increased 6% to $9.8 billion, and non-GAAP services gross margin percentage decreased 90 basis points to 61.1%.  The decrease in services gross margin percentage was primarily attributable to a change in mix of software and hardware maintenance for CSG and ISG.

[0001571996-19-000051:mdna:113]
[same as prior period, unchanged from 0001571996-19-000039:mdna:106]

[0001571996-19-000051:mdna:114]
[same as prior period, unchanged from 0001571996-19-000039:mdna:107]

[0001571996-19-000051:mdna:115]
The terms and conditions of our vendor rebate programs are largely based on product volumes and are generally negotiated either at the beginning of the annual or quarterly period, depending on the program.  The timing and amount of vendor rebates and other discounts we receive under the programs may vary from period to period, reflecting changes in the competitive environment.  We monitor our component costs and seek to address the effects of any changes to terms that might arise under our vendor rebate programs.  Our gross margins for the third quarter and first nine months of Fiscal 2020 and Fiscal 2019 were not materially affected by any changes to the terms of our vendor rebate programs, as the amounts we received under these programs were generally stable relative to our total net cost.  We are not aware of any significant changes to vendor pricing or rebate programs that may impact our results in the near term.

[0001571996-19-000051:mdna:116]
[same as prior period, unchanged from 0001571996-19-000039:mdna:109]

[0001571996-19-000051:mdna:117]
83

[0001571996-19-000051:mdna:118]
[same as prior period, unchanged from 0001571996-19-000039:mdna:110]

[0001571996-19-000051:mdna:119]
[same as prior period, unchanged from 0001571996-19-000039:mdna:111]

[0001571996-19-000051:mdna:120]
|  | Three Months Ended |  | Nine Months Ended |
|  | November 1, 2019 |  |  |  | November 2, 2018 |  | November 1, 2019 |  |  |  | November 2, 2018 |
|  | Dollars |  | % ofNet Revenue |  | %Change |  | Dollars |  | % ofNet Revenue |  | Dollars |  | % ofNet Revenue |  | %Change |  | Dollars |  | % ofNet Revenue |
|  | (in millions, except percentages) |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling, general, and administrative | $ | 5,028 |  |  | 22.0 | % |  | (3 | )% |  | $ | 5,159 |  |  | 22.9 | % |  | $ | 15,677 |  |  | 23.0 | % |  | 4 | % |  | $ | 15,064 |  |  | 22.6 | % |
| Research and development | 1,262 |  |  | 5.5 | % |  | 11 | % |  | 1,140 |  |  | 5.1 | % |  | 3,667 |  |  | 5.4 | % |  | 8 | % |  | 3,402 |  |  | 5.1 | % |
| Total operating expenses | $ | 6,290 |  |  | 27.5 | % |  | — | % |  | $ | 6,299 |  |  | 28.0 | % |  | $ | 19,344 |  |  | 28.4 | % |  | 5 | % |  | $ | 18,466 |  |  | 27.7 | % |
| Other Financial Information |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Non-GAAP operating expenses | $ | 5,326 |  |  | 23.2 | % |  | 8 | % |  | $ | 4,936 |  |  | 21.8 | % |  | $ | 15,807 |  |  | 23.1 | % |  | 7 | % |  | $ | 14,787 |  |  | 22.0 | % |

[0001571996-19-000051:mdna:121]
During the third quarter and first nine months of Fiscal 2020, total operating expenses remained flat and increased 5%, respectively.  During the third quarter of Fiscal 2020, operating expenses remained flat primarily due to offsetting impacts of an increase in selling, general, and administrative expenses, and a decrease in amortization of intangibles.  During the first nine months of Fiscal 2020, operating expenses increased primarily due to an increase in selling, general, and administrative expenses, partially offset by a decrease in amortization of intangibles.

[0001571996-19-000051:mdna:122]
Our operating expenses include the impact of purchase accounting, amortization of intangible assets, transaction-related expenses, stock-based compensation expense, and other corporate expenses.  In aggregate, these items totaled $1.0 billion and $1.4 billion for the third quarter of Fiscal 2020 and Fiscal 2019, respectively, and $3.5 billion and $3.7 billion for the first nine months of Fiscal 2020 and Fiscal 2019, respectively.  Excluding these costs, total non-GAAP operating expenses increased 8% and 7% for the third quarter and first nine months of Fiscal 2020, respectively.

[0001571996-19-000051:mdna:123]
| • | Selling, General, and Administrative — Selling, general, and administrative (“SG&A”) expenses decreased 3% during the third quarter of Fiscal 2020 due to a decrease in amortization of intangibles, partially offset by an increase in SG&A expenses that was driven by investments in our go-to-market capabilities, including sales headcount, and higher performance-based compensation and commission costs. During the first nine months of Fiscal 2020, SG&A expenses increased 4% due to increased compensation-related expenses associated with revenue growth and sales headcount, as well as Virtustream impairment charges. These increases were partially offset by a decrease in amortization of intangibles. |

[0001571996-19-000051:mdna:124]
| • | Research and Development — Research and development (“R&D”) expenses are primarily composed of personnel-related expenses related to product development. R&D expenses as a percentage of net revenue were approximately 5.5% and 5.1% for the third quarter of Fiscal 2020 and Fiscal 2019, respectively, and 5.4% and 5.1% for the first nine months of Fiscal 2020 and Fiscal 2019, respectively. As our industry continues to change and as the needs of our customers evolve, we intend to support R&D initiatives to innovate and introduce new and enhanced solutions into the market. |

[0001571996-19-000051:mdna:125]
[same as prior period, unchanged from 0001571996-19-000039:mdna:116]

[0001571996-19-000051:mdna:126]
[same as prior period, unchanged from 0001571996-19-000039:mdna:137]

[0001571996-19-000051:mdna:127]
[same as prior period, unchanged from 0001571996-19-000039:mdna:117]

[0001571996-19-000051:mdna:128]
During the third quarter of Fiscal 2020, our operating income was $836 million compared to an operating loss of $356 million during the third quarter of Fiscal 2019.  During the first nine months of Fiscal 2020, our operating income was $1.9 billion compared to an operating loss of $522 million during the first nine months of Fiscal 2019.  The operating income we recognized for the third quarter and first nine months of Fiscal 2020 was primarily attributable to an increase in operating income for CSG and a decrease in amortization of intangible assets.  During the first nine months of Fiscal 2020, these benefits were partially offset by an increase in other corporate expenses, which primarily include Virtustream impairment charges.

[0001571996-19-000051:mdna:129]
Amortization of intangible assets and other corporate expenses that impacted our operating income totaled $1.1 billion and $1.8 billion for the third quarter of Fiscal 2020 and Fiscal 2019, respectively, and $4.1 billion and $5.0 billion for the first nine months of Fiscal 2020 and Fiscal 2019, respectively.  Excluding these costs, the impact of purchase accounting, stock-based compensation expense, and transaction-related expenses, our non-GAAP operating income was $2.4 billion and $2.1 billion during the third quarter of Fiscal 2020 and Fiscal 2019, respectively.  During the first nine months of Fiscal 2020 and Fiscal 2019, our non-GAAP operating income was $7.4 billion and $6.2 billion, respectively.  The increases in our non-GAAP operating income for the third quarter and first nine months of Fiscal 2020 were primarily due to an increase in operating income for CSG.

[0001571996-19-000051:mdna:130]
[same as prior period, unchanged from 0001571996-19-000039:mdna:121]

[0001571996-19-000051:mdna:131]
[same as prior period, unchanged from 0001571996-19-000039:mdna:122]

[0001571996-19-000051:mdna:132]
|  | Three Months Ended |  | Nine Months Ended |
|  | November 1, 2019 |  | November 2, 2018 |  | November 1, 2019 |  | November 2, 2018 |
|  | (in millions) |
| Interest and other, net: |  |  |  |  |  |  |  |  |  |  |  |
| Investment income, primarily interest | $ | 41 |  |  | $ | 84 |  |  | $ | 127 |  |  | $ | 247 |  |
| Gain (loss) on investments, net | 18 |  |  | (17 | ) |  | 160 |  |  | 229 |  |
| Interest expense | (654 | ) |  | (612 | ) |  | (2,045 | ) |  | (1,830 | ) |
| Foreign exchange | (43 | ) |  | (63 | ) |  | (123 | ) |  | (174 | ) |
| Other | (39 | ) |  | (31 | ) |  | (119 | ) |  | (36 | ) |
| Total interest and other, net | $ | (677 | ) |  | $ | (639 | ) |  | $ | (2,000 | ) |  | $ | (1,564 | ) |

[0001571996-19-000051:mdna:133]
During the third quarter and first nine months of Fiscal 2020, the change in interest and other, net was unfavorable by $38 million and $436 million, respectively, primarily due to higher interest expense and a decrease in net gain on investments.  To fund a portion of the cash consideration paid in the Class V transaction, we incurred additional debt and liquidated a significant amount of our investments.  As a result, we expect higher interest expense and lower investment income to continue in Fiscal 2020.  See Note 3 and Note 6 of the Notes to the Condensed Consolidated Financial Statements included in this report for further information regarding our investments and debt, respectively.

[0001571996-19-000051:mdna:134]
[same as prior period, unchanged from 0001571996-19-000039:mdna:125]

[0001571996-19-000051:mdna:135]
For the third quarter of Fiscal 2020, our effective income tax rate benefit was 247.2% on pre-tax income of $159 million.  For the third quarter of Fiscal 2019, our effective income tax rate was 10.1% on pre-tax losses of $1.0 billion.  For the first nine months of Fiscal 2020 and Fiscal 2019, our effective income tax rates were 5482.1% and 9.2%, respectively, on pre-tax losses of $95 million and $2.1 billion, respectively.  The changes in our effective tax rates were primarily driven by discrete tax items and a change in our jurisdictional mix of income.

[0001571996-19-000051:mdna:136]
Our effective tax rate for the first nine months of Fiscal 2020 also includes $4.9 billion of discrete tax benefits related to intra-entity asset transfers, $273 million of discrete tax expense related to certain foreign tax credits associated with U.S. Tax Reform discussed below and $95 million of discrete tax benefits relating to Virtustream impairment charges discussed in Note 8 of the Notes to the Condensed Consolidated Financial Statements included in this report.  In the first nine months of Fiscal 2020, we completed two intra-entity asset transfers of certain of our intellectual property to Irish subsidiaries, resulting in discrete tax benefits of $4.9 billion.  The tax benefit for each intra-entity asset transfer was recorded as a deferred tax asset in the period of transaction and represents the book and tax basis difference on the transferred assets measured based on the applicable Irish statutory tax rate.  The tax deductions for amortization of the assets will be recognized in the future and any amortization not deducted for tax purposes will be carried forward indefinitely under Irish Tax laws.  We expect to be able to realize the deferred tax assets resulting from these intra-entity asset transfers.  For the third quarter and first nine months of Fiscal 2020, our effective tax rate includes $305 million of discrete tax benefits related to an audit settlement.  For the first nine months of Fiscal 2019, our effective tax rate includes $154 million of discrete tax benefits resulting from the impact of our adoption of the new revenue recognition standard in the first quarter of Fiscal 2019.

[0001571996-19-000051:mdna:137]
The Tax Cuts and Jobs Act of 2017 (“U.S. Tax Reform”) was signed into law on December 22, 2017.  Among other things, U.S. Tax Reform lowers the U.S. corporate income tax rate to 21% from 35%, establishes a modified territorial system requiring a mandatory deemed repatriation tax on undistributed earnings of foreign subsidiaries, requires a minimum tax on certain future earnings generated by foreign subsidiaries while providing for future tax-free repatriation of earnings through a 100% dividends-received deduction, and places limitations on the deductibility of net interest expense.  In December 2019, the U.S. Department of the Treasury released final and newly proposed regulations related to foreign tax credits and the base erosion anti-abuse tax.  We are currently evaluating the impact of these regulations and will recognize any resulting adjustments as necessary.  We anticipate that the U.S. Department of the Treasury and the Internal Revenue Service will continue to issue regulatory guidance clarifying certain provisions of U.S. Tax Reform.  When additional guidance is issued, we will recognize the related tax impact in the fiscal quarter of such issuance.

[0001571996-19-000051:mdna:138]
Our effective income tax rate can fluctuate depending on the geographic distribution of our worldwide earnings, as our foreign earnings are generally taxed at lower rates than in the United States.  The differences between our effective income tax rate and the U.S. federal statutory rate of 21% principally result from the geographical distribution of income and differences between the book and tax treatment of certain items.  In certain jurisdictions, our tax rate is significantly less than the applicable statutory rate as a result of tax holidays.  The majority of our foreign income that is subject to these tax holidays and lower tax rates is attributable to Singapore, China, and Malaysia.  A significant portion of these income tax benefits relates to a tax holiday that will be effective until January 31, 2029.  Our other tax holidays will expire in whole or in part during Fiscal 2022 through Fiscal 2030.  Many of these tax holidays and reduced tax rates may be extended when certain conditions are met or may be terminated early if certain conditions are not met.  As of November 1, 2019, we were not aware of any matters of non-compliance related to these tax holidays.

[0001571996-19-000051:mdna:139]
[same as prior period, unchanged from 0001571996-19-000039:mdna:129]

[0001571996-19-000051:mdna:140]
[same as prior period, unchanged from 0001571996-19-000039:mdna:130]

[0001571996-19-000051:mdna:141]
During the third quarter and first nine months of Fiscal 2020, net income was $0.6 billion and $5.1 billion, respectively, compared to net loss of $0.9 billion and $1.9 billion during the third quarter and first nine months of Fiscal 2019, respectively.  The net income we recognized during the third quarter of Fiscal 2020 was primarily attributable to an increase in operating income.  The net income we recognized during the first nine months of Fiscal 2020 was primarily attributable to an increase in tax benefit and, to a lesser extent, an increase in operating income, which was partially offset by an increase in interest and other, net expense.

[0001571996-19-000051:mdna:142]
Net income for the third quarter and first nine months of Fiscal 2020 and Fiscal 2019 included amortization of intangible assets, the impact of purchase accounting, transaction-related expenses, stock-based compensation expense, other corporate expenses, fair value adjustments on equity investments, and discrete tax items.  Excluding these costs and the related tax impacts, non-GAAP net income was $1.4 billion and $4.4 billion during the third quarter and first nine months of Fiscal 2020, respectively, and was $1.2 billion and $3.6 billion during the third quarter and first nine months of Fiscal 2019, respectively.  The increase in non-GAAP net income during the third quarter and first nine months of Fiscal 2020 was primarily attributable to an increase in operating income, which was partially offset by an increase in interest and other, net expense.

[0001571996-19-000051:mdna:143]
[same as prior period, unchanged from 0001571996-19-000039:mdna:154]

[0001571996-19-000051:mdna:144]
[same as prior period, unchanged from 0001571996-19-000039:mdna:133]

[0001571996-19-000051:mdna:145]
Net income or loss attributable to non-controlling interests consisted of net income or loss attributable to our non-controlling interests in VMware, Inc., Pivotal, and Secureworks.  During the third quarter and first nine months of Fiscal 2020, net income attributable to non-controlling interests was $53 million and $905 million, respectively.  During the third quarter and first nine months of Fiscal 2019, net income or loss attributable to non-controlling interests was $19 million net loss and $117 million net income, respectively.  The increase in net income attributable to non-controlling interests during the third quarter and first nine months of Fiscal 2020 was attributable to an increase in net income attributable to our non-controlling interest in VMware, Inc.  For more information about our non-controlling interests, see Note 13 of the Notes to the Condensed Consolidated Financial Statements included in this report.

[0001571996-19-000051:mdna:146]
[same as prior period, unchanged from 0001571996-19-000039:mdna:135]

[0001571996-19-000051:mdna:147]
Net income (loss) attributable to Dell Technologies Inc. represents net income or loss and an adjustment for non-controlling interests.  During the third quarter and first nine months of Fiscal 2020, net income attributable to Dell Technologies Inc. was $0.5 billion and $4.2 billion, respectively.  During the third quarter and first nine months of Fiscal 2019, net loss attributable to Dell Technologies Inc. was $0.9 billion and $2.0 billion, respectively.  The net income attributable to Dell Technologies Inc. we recognized during the third quarter and first nine months of Fiscal 2020 was primarily attributable to an increase in net income for the periods.

[0001571996-19-000051:mdna:148]
87

[0001571996-19-000051:mdna:149]
[same as prior period, unchanged from 0001571996-19-000039:mdna:138]

[0001571996-19-000051:mdna:150]
[same as prior period, unchanged from 0001571996-19-000039:mdna:139]

[0001571996-19-000051:mdna:151]
[same as prior period, unchanged from 0001571996-19-000039:mdna:140]

[0001571996-19-000051:mdna:152]
[same as prior period, unchanged from 0001571996-19-000039:mdna:141]

[0001571996-19-000051:mdna:153]
|  | Three Months Ended |  | Nine Months Ended |
|  | November 1, 2019 |  | % Change |  | November 2, 2018 |  | November 1, 2019 |  | % Change |  | November 2, 2018 |
|  | (in millions, except percentages) |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Servers and networking | $ | 4,241 |  |  | (16)% |  | $ | 5,054 |  |  | $ | 12,858 |  |  | (13)% |  | $ | 14,700 |  |
| Storage | 4,149 |  |  | 7% |  | 3,883 |  |  | 12,355 |  |  | 2% |  | 12,131 |  |
| Total ISG net revenue | $ | 8,390 |  |  | (6)% |  | $ | 8,937 |  |  | $ | 25,213 |  |  | (6)% |  | $ | 26,831 |  |
| Operating income: |  |  |  |  |  |  |  |  |  |  |  |
| ISG operating income | $ | 996 |  |  | 7% |  | $ | 935 |  |  | $ | 2,889 |  |  | —% |  | $ | 2,886 |  |
| % of segment net revenue | 11.9 | % |  |  |  | 10.5 | % |  | 11.5 | % |  |  |  | 10.8 | % |

[0001571996-19-000051:mdna:154]
Net Revenue — During both the third quarter and first nine months of Fiscal 2020, ISG net revenue decreased 6%, primarily due to a decrease in sales of servers and networking.  Revenue from the sales of servers and networking decreased 16% and 13% during the third quarter and first nine months of Fiscal 2020, respectively, primarily driven by a decline in units sold of our PowerEdge servers due to a weaker demand environment.  Certain competitive dynamics also contributed to lower server sales volumes, as we focused on profitability over net revenue growth.   During the third quarter of Fiscal 2020, further contributing to the decrease in ISG net revenue, average selling prices for servers decreased primarily due to competitive pressures in certain geographies.  During the first nine months of Fiscal 2020, the impact of the lower volume of PowerEdge sales was partially mitigated by an increase in average selling prices from the sale of servers with more robust compute capacity and higher memory and storage content, which was driven by customer demand for servers that enable big data analytics.  Storage revenue increased 7% and 2% during the third quarter and first nine months of Fiscal 2020, respectively.  We experienced relatively stable demand in storage.  We continue to make go-to-market investments and enhancements to our storage solutions offerings and expect that these investments will drive long-term improvements in the business.

[0001571996-19-000051:mdna:155]
Component costs were deflationary in the aggregate for ISG during the first nine months of Fiscal 2020, and we continue to monitor our pricing in response to the changing cost environment.  We expect the aggregate ISG component cost environment to continue to be deflationary through early next fiscal year, but to a lesser degree relative to the previous three quarters.  For Fiscal 2021, we expect an inflationary component cost environment, which may put pressure on ISG operating results, particularly in servers and networking.

[0001571996-19-000051:mdna:156]
[same as prior period, unchanged from 0001571996-19-000039:mdna:144]

[0001571996-19-000051:mdna:157]
From a geographical perspective, net revenue attributable to ISG decreased in the Americas, EMEA, and APJ during the third quarter of Fiscal 2020.  Net revenue attributable to ISG increased in EMEA, and decreased in the Americas and APJ during the first nine months of Fiscal 2020.  The decreases in ISG revenue in APJ were more significant than changes in net revenue in the other regions, and were driven by a weaker demand environment, particularly in China, which we expect to continue into Fiscal 2021.

[0001571996-19-000051:mdna:158]
Operating Income — During the third quarter and first nine months of Fiscal 2020, ISG operating income as a percentage of net revenue increased 140 basis points to 11.9% and 70 basis points to 11.5%, respectively, due to an increase in ISG gross margin percentage resulting from the deflationary cost environment discussed above.  The increase in ISG operating margins were offset by an increase in ISG operating expenses as a percentage of ISG net revenue.  ISG operating expenses increased due to investments we made in our go-to-market capabilities to ensure the optimal coverage model to serve the needs of our customers.

[0001571996-19-000051:mdna:159]
[same as prior period, unchanged from 0001571996-19-000039:mdna:148]

[0001571996-19-000051:mdna:160]
[same as prior period, unchanged from 0001571996-19-000039:mdna:149]

[0001571996-19-000051:mdna:161]
|  | Three Months Ended |  | Nine Months Ended |
|  | November 1, 2019 |  | % Change |  | November 2, 2018 |  | November 1, 2019 |  | % Change |  | November 2, 2018 |
|  | (in millions, except percentages) |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Commercial | $ | 8,330 |  |  | 9% |  | $ | 7,613 |  |  | $ | 25,714 |  |  | 11% |  | $ | 23,085 |  |
| Consumer | 3,080 |  |  | (6)% |  | 3,292 |  |  | 8,354 |  |  | (9)% |  | 9,219 |  |
| Total CSG net revenue | $ | 11,410 |  |  | 5% |  | $ | 10,905 |  |  | $ | 34,068 |  |  | 5% |  | $ | 32,304 |  |
| Operating income: |  |  |  |  |  |  |  |  |  |  |  |
| CSG operating income | $ | 739 |  |  | 65% |  | $ | 447 |  |  | $ | 2,514 |  |  | 79% |  | $ | 1,405 |  |
| % of segment net revenue | 6.5 | % |  |  |  | 4.1 | % |  | 7.4 | % |  |  |  | 4.3 | % |

[0001571996-19-000051:mdna:162]
Net Revenue — During both the third quarter and first nine months of Fiscal 2020, CSG net revenue increased 5% primarily driven by the Microsoft Windows 10 operating system refresh cycle, combined with strong execution by the business.  Although we expect continued strong CSG demand into early Fiscal 2021, we expect overall CSG demand will decelerate in Fiscal 2021 as the Windows 10 refresh cycle winds down.

[0001571996-19-000051:mdna:163]
During the third quarter and first nine months of Fiscal 2020, commercial revenue increased 9% and 11%, respectively, due to continued strong demand for our commercial products across all product categories, driven by the Microsoft Windows 10 operating system refresh cycle.  Consumer revenue decreased 6% and 9% during the third quarter and first nine months of Fiscal 2020, respectively, due to lower demand as we continue to focus on commercial and higher-end consumer products.  During the first nine months of Fiscal 2020, the decline in consumer demand was partially offset by an increase in average selling prices for our higher-priced consumer notebooks.

[0001571996-19-000051:mdna:164]
The aggregate CSG component cost environment was deflationary in the third quarter and first nine months of Fiscal 2020, and we expect deflationary conditions to continue through the end of Fiscal 2020, but to a lesser degree relative to the previous three quarters.  For Fiscal 2021, we expect an inflationary component cost environment, which will put pressure on CSG operating results.

[0001571996-19-000051:mdna:165]
From a geographical perspective, net revenue attributable to CSG increased in the Americas, EMEA, and APJ during the third quarter and first nine months of Fiscal 2020.

[0001571996-19-000051:mdna:166]
Operating Income — During the third quarter and first nine months of Fiscal 2020, CSG operating income as a percentage of net revenue increased 240 basis points to 6.5% and 310 basis points to 7.4%, respectively.  The increases were primarily due to lower component costs that positively impacted CSG gross margin and a shift in product mix to higher-margin product offerings.

[0001571996-19-000051:mdna:167]
[same as prior period, unchanged from 0001571996-19-000039:mdna:155]

[0001571996-19-000051:mdna:168]
[same as prior period, unchanged from 0001571996-19-000039:mdna:156]

[0001571996-19-000051:mdna:169]
|  | Three Months Ended |  | Nine Months Ended |
|  | November 1, 2019 |  | % Change |  | November 2, 2018 |  | November 1, 2019 |  | % Change |  | November 2, 2018 |
|  | (in millions, except percentages) |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |
| VMware net revenue | $ | 2,483 |  |  | 11% |  | $ | 2,229 |  |  | $ | 7,231 |  |  | 12% |  | $ | 6,451 |  |
| Operating income: |  |  |  |  |  |  |  |  |  |  |  |
| VMware operating income | $ | 717 |  |  | (7)% |  | $ | 768 |  |  | $ | 2,093 |  |  | (1)% |  | $ | 2,117 |  |
| % of segment net revenue | 28.9 | % |  |  |  | 34.5 | % |  | 28.9 | % |  |  |  | 32.8 | % |

[0001571996-19-000051:mdna:170]
Net Revenue — VMware net revenue primarily consists of revenue from the sale of software licenses under perpetual licenses, related software maintenance and support, training, consulting services, and hosted services.  VMware net revenue for the third quarter and first nine months of Fiscal 2020 increased 11% and 12%, respectively, primarily due to growth in software license revenue and sales of software maintenance services.  Software license revenue reflected broad-based growth across the product portfolio.  Software maintenance revenue benefited from strong renewals of VMware enterprise agreements, revenue recognized from maintenance contracts sold in prior periods, and additional maintenance contracts sold in conjunction with new software license sales.

[0001571996-19-000051:mdna:171]
From a geographical perspective, approximately half of VMware net revenue during the third quarter and first nine months of Fiscal 2020 was generated by sales to customers in the United States.  VMware net revenue for the third quarter and first nine months of Fiscal 2020 was positively affected by growth across U.S. and international markets.

[0001571996-19-000051:mdna:172]
Operating Income — During the third quarter and first nine months of Fiscal 2020, VMware operating income as a percentage of net revenue decreased 560 basis points to 28.9% and 390 basis points to 28.9%, respectively.  The decrease was driven by an increase in operating expenses as a percentage of net revenue as the result of an increase in compensation-related expense associated with sales and sales support, primarily due to increased headcount, as well as to an increase in R&D expenses.

[0001571996-19-000051:mdna:173]
90

[0001571996-19-000051:mdna:174]
[same as prior period, unchanged from 0001571996-19-000039:mdna:161]

[0001571996-19-000051:mdna:175]
[same as prior period, unchanged from 0001571996-19-000039:mdna:162]

[0001571996-19-000051:mdna:176]
We sell products and services directly to customers and through a variety of sales channels, including retail distribution.  Our accounts receivable, net, was $11.4 billion and $12.4 billion as of November 1, 2019 and February 1, 2019, respectively.  We maintain an allowance for doubtful accounts to cover receivables that may be deemed uncollectible.  The allowance for losses is based on a provision for accounts that are collectively evaluated based on historical bad debt experience as well as specific identifiable customer accounts that are deemed at risk.  As of November 1, 2019 and February 1, 2019, the allowance for doubtful accounts was $98 million and $85 million, respectively.  Based on our assessment, we believe that we are adequately reserved for expected credit losses.  We monitor the aging of our accounts receivable and continue to take actions to reduce our exposure to credit losses.

[0001571996-19-000051:mdna:177]
[same as prior period, unchanged from 0001571996-19-000039:mdna:164]

[0001571996-19-000051:mdna:178]
Dell Financial Services and its affiliates (“DFS”) support Dell Technologies by offering and arranging various financing options and services for our customers globally, including through captive financing operations in North America, Europe, Australia, and New Zealand.  DFS originates, collects, and services customer receivables primarily related to the purchase of our product, software, and service solutions.  DFS further strengthens our customer relationships through its flexible consumption models, which enable us to offer our customers the option to pay over time and, in certain cases, based on utilization, to provide them with financial flexibility to meet their changing technological requirements.  New financing originations were $2.0 billion and $1.6 billion for the third quarter of Fiscal 2020 and Fiscal 2019, respectively, and $5.7 billion and $5.2 billion for the first nine months of Fiscal 2020 and Fiscal 2019, respectively.

[0001571996-19-000051:mdna:179]
[same as prior period, unchanged from 0001571996-19-000039:mdna:166]

[0001571996-19-000051:mdna:180]
As of November 1, 2019 and February 1, 2019, our financing receivables, net were $9.1 billion and $8.6 billion, respectively.  We maintain an allowance to cover expected financing receivable credit losses and evaluate credit loss expectations based on our total portfolio.  For the third quarter of Fiscal 2020 and Fiscal 2019, the principal charge-off rate for our total portfolio was 0.9% and 1.0%, respectively.  For the first nine months of Fiscal 2020 and Fiscal 2019, the principal charge-off rate for our total portfolio was 1.0% and 1.2%, respectively.  The credit quality of our financing receivables has improved in recent years due to an overall improvement in the credit environment and as the mix of high-quality commercial accounts in our portfolio has continued to increase.  We continue to monitor broader economic indicators and their potential impact on future loss performance.  We have an extensive process to manage our exposure to customer credit risk, including active management of credit lines and our collection activities.  We also sell selected fixed-term financing receivables without recourse to unrelated third parties on a periodic basis, primarily to manage certain concentrations of customer credit exposure.  Based on our assessment of the customer financing receivables, we believe that we are adequately reserved.

[0001571996-19-000051:mdna:181]
91

[0001571996-19-000051:mdna:182]
We retain a residual interest in equipment leased under our lease programs.  As of November 1, 2019 and February 1, 2019, the residual interest recorded as part of financing receivables was $611 million and $674 million, respectively.  The amount of the residual interest is established at the inception of the lease based upon estimates of the value of the equipment at the end of the lease term using historical studies, industry data, and future value-at-risk demand valuation methods.  On a quarterly basis, we assess the carrying amount of our recorded residual values for impairment.  Generally, residual value risk on equipment under lease is not considered to be significant, because of the existence of a secondary market with respect to the equipment.  The lease agreement also clearly defines applicable return conditions and remedies for non-compliance, to ensure that the leased equipment will be in good operating condition upon return.  Model changes and updates, as well as market strength and product acceptance, are monitored and adjustments are made to residual values in accordance with the significance of any such changes.  Our remarketing sales staff works closely with customers and dealers to manage the sale of lease returns and the recovery of residual exposure.  No impairment losses were recorded related to residual assets during the third quarter and first nine months of Fiscal 2020.

[0001571996-19-000051:mdna:183]
As of November 1, 2019, equipment under operating leases, net was $626 million and was immaterial as of February 1, 2019.  The increase in equipment under operating leases, net is due to our adoption of the new lease standard and the elimination of the third-party residual value guarantee insurance in the lease classification test for sales-type leases.  Based on triggering events, we assess the carrying amount of the equipment under operating leases recorded for impairment.  No impairment losses were recorded related to such equipment during the third quarter and first nine months of Fiscal 2020.

[0001571996-19-000051:mdna:184]
DFS offerings are initially funded through cash on hand at the time of origination, most of which is subsequently replaced with third-party financing.  As a result, while the initial funding of financing receivables is reflected as an impact to cash flows from operations and investing, this funding is largely subsequently offset by cash flows from financing.  Additionally, as a result of our adoption of the new leasing standard on lessor accounting, the increase to future originations of operating leases results in a shift from financing receivables to capital expenditures, which benefits our cash flows provided by operating activities by the increase in capital expenditures being reported as cash flows used in investing activities.

[0001571996-19-000051:mdna:185]
[same as prior period, unchanged from 0001571996-19-000039:mdna:171]

[0001571996-19-000051:mdna:186]
[same as prior period, unchanged from 0001571996-19-000039:mdna:172]

[0001571996-19-000051:mdna:187]
As of November 1, 2019, we had no off-balance sheet arrangements that have or are reasonably likely to have a current or future material effect on our financial condition or results of operations.

[0001571996-19-000051:mdna:188]
[same as prior period, unchanged from 0001571996-19-000039:mdna:175]

[0001571996-19-000051:mdna:189]
[same as prior period, unchanged from 0001571996-19-000039:mdna:176]

[0001571996-19-000051:mdna:190]
[same as prior period, unchanged from 0001571996-19-000039:mdna:177]

[0001571996-19-000051:mdna:191]
[same as prior period, unchanged from 0001571996-19-000039:mdna:178]

[0001571996-19-000051:mdna:192]
[same as prior period, unchanged from 0001571996-19-000039:mdna:179]

[0001571996-19-000051:mdna:193]
We are exposed to interest rate risk related to our variable-rate debt portfolio.  In the normal course of business, we follow established policies and procedures to manage this risk, including monitoring of our asset and liability mix.  As a result, we do not anticipate any material losses from interest rate risk.

[0001571996-19-000051:mdna:194]
[same as prior period, unchanged from 0001571996-19-000039:mdna:181]

[0001571996-19-000051:mdna:195]
[same as prior period, unchanged from 0001571996-19-000039:mdna:182]

[0001571996-19-000051:mdna:196]
To support our ongoing business operations, we rely on operating cash flows as our primary source of liquidity.  We monitor the efficiency of our balance sheet to ensure that we have adequate liquidity to support our strategic initiatives.  In addition to internally generated cash, we have access to other capital sources to finance our strategic initiatives and fund growth in our financing operations.  As of November 1, 2019, we had $8.6 billion of total cash and cash equivalents.  Our strategy is to deploy capital from any potential source, whether internally generated cash or debt, depending on the adequacy and availability of that source of capital and whether it can be accessed in a cost-effective manner.

[0001571996-19-000051:mdna:197]
[same as prior period, unchanged from 0001571996-19-000039:mdna:184]

[0001571996-19-000051:mdna:198]
During the fourth quarter of Fiscal 2019, as discussed above in “Introduction — Class V Transaction,” we completed a transaction in which all issued and outstanding shares of our Class V Common Stock were exchanged for cash or shares of Class C Common Stock at the stockholder’s election.  We paid a total of $14 billion of cash to holders of Class V Common Stock.  To fund a majority of the cash payment to stockholders, VMware, Inc. declared a conditional $11 billion one-time special cash dividend (the “Special Dividend”), which was paid pro-rata to VMware, Inc. stockholders as of the dividend record date of December 27, 2018 and in connection with the completion of the Class V transaction.  Our cash, cash equivalents, and investments declined significantly, commensurate with the cash required to fund this transaction.

[0001571996-19-000051:mdna:199]
VMware, Inc. has advised us that, following its payment of the Special Dividend, VMware, Inc. will remain committed to a balanced capital allocation policy through investment in its product and solutions offerings, acquisitions, and returning capital to its stockholders through share repurchases.  As of November 1, 2019, $1.1 billion remained available for share repurchases.  During the first nine months of Fiscal 2020, VMware, Inc. repurchased 7.3 million shares of its Class A common stock in the open market for approximately $1.3 billion.  During the first nine months of Fiscal 2019, VMware, Inc. did not repurchase any shares of its Class A common stock.

[0001571996-19-000051:mdna:200]
[same as prior period, unchanged from 0001571996-19-000039:mdna:187]

[0001571996-19-000051:mdna:201]
[same as prior period, unchanged from 0001571996-19-000039:mdna:188]

[0001571996-19-000051:mdna:202]
|  | November 1, 2019 |  | February 1, 2019 |
|  | (in millions) |
| Cash and cash equivalents, and available borrowings: |  |  |  |
| Cash and cash equivalents (a) | $ | 8,555 |  |  | $ | 9,676 |  |
| Remaining available borrowings under revolving credit facilities | 7,386 |  |  | 5,586 |  |
| Total cash, cash equivalents, and available borrowings | $ | 15,941 |  |  | $ | 15,262 |  |

[0001571996-19-000051:mdna:203]
[same as prior period, unchanged from 0001571996-19-000039:mdna:190]

[0001571996-19-000051:mdna:204]
| (a) | Of the $8.6 billion of cash and cash equivalents as of November 1, 2019, $2.0 billion was held by VMware, Inc. |

[0001571996-19-000051:mdna:205]
Our revolving credit facilities include the Revolving Credit Facility and the China Revolving Credit Facility, which we renewed during the first quarter of Fiscal 2020.  The Revolving Credit Facility and the China Revolving Credit Facility have maximum aggregate borrowings of $4.5 billion and $0.5 billion, respectively.  Available borrowings under these facilities are reduced by draws on the facility and, under the Revolving Credit Facility, outstanding letters of credit.  As of November 1, 2019, there were no borrowings outstanding under the facilities and remaining available borrowings totaled approximately $5.0 billion.  We may regularly use our available borrowings from both our Revolving Credit Facility and our China Revolving Credit Facility on a short-term basis for general corporate purposes.

[0001571996-19-000051:mdna:206]
The VMware Revolving Credit Facility has maximum aggregate borrowings of $1.0 billion.  As of November 1, 2019, $1.0 billion was available under the VMware Revolving Credit Facility.  The VMware Term Loan Facility has a borrowing capacity of up to $2.0 billion.  VMware, Inc. may borrow against the VMware Term Loan Facility two times up to its borrowing capacity of $2.0 billion until February 7, 2020.  As of November 1, 2019, the outstanding balance was $600 million, and $1.4 billion remained available to be drawn down for future borrowing purposes.  None of the net proceeds of such borrowings will be made available to support the operations or satisfy any corporate purposes of Dell Technologies, other than the operations and corporate purposes of VMware, Inc. and VMware, Inc.’s subsidiaries.

[0001571996-19-000051:mdna:207]
The Pivotal Revolving Credit Facility had maximum aggregate borrowings of $100 million and was terminated during the third quarter of Fiscal 2020.

[0001571996-19-000051:mdna:208]
[same as prior period, unchanged from 0001571996-19-000039:mdna:194]

[0001571996-19-000051:mdna:209]
[same as prior period, unchanged from 0001571996-19-000039:mdna:195]

[0001571996-19-000051:mdna:210]
[same as prior period, unchanged from 0001571996-19-000039:mdna:196]

[0001571996-19-000051:mdna:211]
[same as prior period, unchanged from 0001571996-19-000039:mdna:197]

[0001571996-19-000051:mdna:212]
|  | November 1, 2019 |  | Increase (decrease) |  | February 1, 2019 |
|  | (in millions) |
| Core debt |  |  |  |  |  |
| Senior Secured Credit Facilities and First Lien Notes | $ | 29,722 |  |  | $ | (2,998 | ) |  | $ | 32,720 |  |
| Unsecured Notes and Debentures | 1,352 |  |  | (600 | ) |  | 1,952 |  |
| Senior Notes | 2,700 |  |  | (550 | ) |  | 3,250 |  |
| EMC Notes | 3,000 |  |  | — |  |  | 3,000 |  |
| DFS allocated debt | (902 | ) |  | 713 |  |  | (1,615 | ) |
| Total core debt | 35,872 |  |  | (3,435 | ) |  | 39,307 |  |
| DFS related debt |  |  |  |  |  |
| DFS debt | 7,568 |  |  | 1,639 |  |  | 5,929 |  |
| DFS allocated debt | 902 |  |  | (713 | ) |  | 1,615 |  |
| Total DFS related debt | 8,470 |  |  | 926 |  |  | 7,544 |  |
| Margin Loan Facility and other | 4,024 |  |  | 636 |  |  | 3,388 |  |
| Public subsidiary debt |  |  |  |  |  |
| VMware Notes | 4,000 |  |  | — |  |  | 4,000 |  |
| VMware Term Loan Facility | 600 |  |  | 600 |  |  | — |  |
| Other | 60 |  |  | 60 |  |  | — |  |
| Total public subsidiary debt | 4,660 |  |  | 660 |  |  | 4,000 |  |
| Total debt, principal amount | 53,026 |  |  | (1,213 | ) |  | 54,239 |  |
| Carrying value adjustments | (635 | ) |  | 83 |  |  | (718 | ) |
| Total debt, carrying value | $ | 52,391 |  |  | $ | (1,130 | ) |  | $ | 53,521 |  |

[0001571996-19-000051:mdna:213]
During the first nine months of Fiscal 2020, the outstanding principal amount of our debt decreased by $1.2 billion to $53.0 billion as of November 1, 2019.

[0001571996-19-000051:mdna:214]
During the first nine months of Fiscal 2020, core debt decreased by $3.4 billion to $35.9 billion as of November 1, 2019.  We define core debt as the total principal amount of our debt, less DFS related debt, our Margin Loan Facility and other debt, and public subsidiary debt.  The decrease in core debt was primarily due to our deleveraging efforts.  See Note 6 of the Notes to the Condensed Consolidated Financial Statements included in this report for more information about our debt.

[0001571996-19-000051:mdna:215]
During the first nine months of Fiscal 2020, we issued an additional $1.6 billion, net, in DFS debt to support the expansion of its financing receivables portfolio.  DFS related debt primarily represents debt from our securitization and structured financing programs.  For DFS debt under securitization programs, our risk of loss is limited to transferred lease and loan payments and associated equipment, and the credit holders under these programs have no recourse to Dell Technologies.  To fund expansion of the DFS business, we balance the use of the securitization and structured financing programs with other sources of liquidity.  We approximate the amount of our debt used to fund the DFS business by applying a 7:1 debt to equity ratio to the sum of our financing receivables balance and equipment under our DFS operating leases, net.  The debt to equity ratio used is based on the underlying credit quality of the assets.  See Note 4 of the Notes to the Condensed Consolidated Financial Statements included in this report for more information about our DFS debt.

[0001571996-19-000051:mdna:216]
As of November 1, 2019, margin loan and other debt primarily consisted of the $4.0 billion Margin Loan Facility.  We amended the Margin Loan Facility during the first quarter of Fiscal 2020, and increased the principal amount by $650 million to $4.0 billion.

[0001571996-19-000051:mdna:217]
Public subsidiary debt represents VMware, Inc. indebtedness.  See Note 6 of the Notes to the Condensed Consolidated Financial Statements included in this report for more information about VMware, Inc. debt.

[0001571996-19-000051:mdna:218]
VMware, Inc. and its respective subsidiaries are unrestricted subsidiaries for purposes of the core debt of Dell Technologies.  Neither Dell Technologies nor any of its subsidiaries, other than VMware, Inc., is obligated to make payment on the VMware Notes or the VMware Term Loan Facility.  None of the net proceeds of the VMware Notes or the VMware Term Loan Facility will be made available to support the operations or satisfy any corporate purposes of Dell Technologies, other than the operations and corporate purposes of VMware, Inc. and its subsidiaries.

[0001571996-19-000051:mdna:219]
Our requirements for cash to pay principal and interest on our core debt increased significantly due to the borrowings we incurred to finance the EMC merger transaction and, to a lesser extent, the Class V transaction.  We have made good progress in paying down core debt since the EMC merger transaction.  We believe we will continue to be able to make our debt principal and interest payments, including the short-term maturities, from existing and expected sources of cash, primarily from operating cash flows.  Cash used for debt principal and interest payments may also include short-term borrowings under our revolving credit facilities.  We will continue to focus on paying down core debt.  Under our variable-rate debt, we could have variations in our future interest expense from potential fluctuations in LIBOR, or from possible fluctuations in the level of DFS debt required to meet future demand for customer financing.  We or our affiliates or their related persons, at our or their sole discretion, may purchase, redeem, prepay, refinance, or otherwise retire any amount of our outstanding indebtedness under the terms of such indebtedness at any time and from time to time, in open market or negotiated transactions with the holders of such indebtedness or otherwise, as appropriate market conditions exist.

[0001571996-19-000051:mdna:220]
[same as prior period, unchanged from 0001571996-19-000039:mdna:206]

[0001571996-19-000051:mdna:221]
[same as prior period, unchanged from 0001571996-19-000039:mdna:207]

[0001571996-19-000051:mdna:222]
|  | Nine Months Ended |
|  | November 1, 2019 |  | November 2, 2018 |
|  | (in millions) |
| Net change in cash from: |  |  |  |
| Operating activities | $ | 5,783 |  |  | $ | 4,625 |  |
| Investing activities | (3,982 | ) |  | (221 | ) |
| Financing activities | (2,600 | ) |  | (2,844 | ) |
| Effect of exchange rate changes on cash, cash equivalents, and restricted cash | (100 | ) |  | (262 | ) |
| Change in cash, cash equivalents, and restricted cash | $ | (899 | ) |  | $ | 1,298 |  |

[0001571996-19-000051:mdna:223]
Operating Activities — Cash provided by operating activities was $5.8 billion for the first nine months of Fiscal 2020 compared to $4.6 billion for the first nine months of Fiscal 2019.  The increase in operating cash flows during the first nine months of Fiscal 2020 was attributable to improved profitability and continued working capital discipline.  Cash provided by operating activities includes a $0.4 billion payment for a tax settlement during the third quarter of Fiscal 2020.

[0001571996-19-000051:mdna:224]
DFS offerings are initially funded through cash on hand at the time of origination, most of which is subsequently replaced with third-party financing.  As a result, while the initial funding of financing receivables is reflected as an impact to cash flows from operations and investing, this funding impact is largely subsequently offset by cash flows from financing.  Additionally, as a result of our adoption of the new leasing standard on lessor accounting in the first quarter of Fiscal 2020, the increase to future originations of operating leases results in a shift from financing receivables to capital expenditures, which benefits our cash flows provided by operating activities by the increase in capital expenditures being reported as cash flows used in investing activities.  DFS new financing originations were $5.7 billion and $5.2 billion during the first nine months of Fiscal 2020 and Fiscal 2019, respectively.  As of November 1, 2019, DFS had $9.1 billion of total net financing receivables and $0.6 billion of equipment under DFS operating leases, net.

[0001571996-19-000051:mdna:225]
Investing Activities — Investing activities primarily consist of cash used to fund capital expenditures for property, plant, and equipment, which includes equipment under DFS operating leases, capitalized software development costs, strategic investments, and the maturities, sales, and purchases of investments.  During the first nine months of Fiscal 2020, cash used in investing activities was $4.0 billion and was primarily driven by capital expenditures and acquisition of businesses, which were partially offset by net cash proceeds from the net sales of investments.  In comparison, cash used by investing activities was $0.2 billion during the first nine months of Fiscal 2019 and was primarily driven by capital expenditures and acquisition of businesses, partially offset by net sales of investments.

[0001571996-19-000051:mdna:226]
96

[0001571996-19-000051:mdna:227]
Financing Activities — Financing activities primarily consist of the proceeds and repayments of debt, cash used to repurchase common stock, and proceeds from the issuance of common stock of subsidiaries.  Cash used in financing activities of $2.6 billion during the first nine months of Fiscal 2020 primarily consisted of repayments of debt and repurchases of common stock by our public subsidiaries.  In comparison, cash used by financing activities of $2.8 billion during the first nine months of Fiscal 2019 was primarily driven by repayments of debt, including an EMC senior note issued in the principal amount of $2.5 billion we repaid during the second quarter of Fiscal 2019 and the Term Loan A-3 Facility in the amount of $1.2 billion we repaid during the third quarter of Fiscal 2019.

[0001571996-19-000051:mdna:228]
[same as prior period, unchanged from 0001571996-19-000039:mdna:213]

[0001571996-19-000051:mdna:229]
Capital Expenditures — During the first nine months of Fiscal 2020, we spent $1.6 billion on property, plant, and equipment, which included gross equipment under DFS operating leases of $0.7 billion.  During the first nine months of Fiscal 2019, we spent $0.9 billion on property, plant, and equipment.  These expenditures were incurred in connection with our global expansion efforts and infrastructure investments made to support future growth, and, in Fiscal 2020, the funding of equipment under DFS operating leases.  Product demand, product mix, and the use of contract manufacturers, as well as ongoing investments in operating and information technology infrastructure, influence the level and prioritization of our capital expenditures.  Aggregate capital expenditures for Fiscal 2020, which will involve infrastructure investments, strategic initiatives, and funding our DFS leasing operations, are currently expected to total between $2.2 billion and $2.4 billion, of which approximately $1.0 billion relates to the property, plant, and equipment to be recognized under the new lease accounting standard.

[0001571996-19-000051:mdna:230]
[same as prior period, unchanged from 0001571996-19-000039:mdna:215]

[0001571996-19-000051:mdna:231]
[same as prior period, unchanged from 0001571996-19-000039:mdna:216]

[0001571996-19-000051:mdna:232]
97
