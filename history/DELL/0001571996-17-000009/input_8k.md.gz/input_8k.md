# DELL 8-K — 0001193125-17-197638 filed 2017-06-08

## item codes, every 8-K on or before 2017-06-09

- 2017-06-08 0001193125-17-197638 — 2.02, 9.01
- 2017-03-30 0001193125-17-102794 — 8.01
- 2017-03-30 0001193125-17-102777 — 2.02, 9.01
- 2017-03-09 0001193125-17-076981 — 1.01, 2.03, 9.01
- 2017-01-17 0001193125-17-011125 — 8.01
- 2016-12-15 0001193125-16-793722 — 8.01
- 2016-12-08 0001193125-16-787976 — 2.02, 9.01
- 2016-11-10 0001193125-16-765964 — 1.02, 8.01
- 2016-11-04 0001193125-16-760249 — 8.01
- 2016-09-13 0001193125-16-708600 — 3.02
- 2016-09-09 0001193125-16-706567 — 1.01, 1.02, 2.01, 2.03, 3.02, 3.03, 5.02, 9.01
- 2016-09-07 0001193125-16-703370 — 3.03, 5.07, 7.01, 8.01, 9.01
- 2016-09-06 0001193125-16-702057 — 2.02, 9.01
- 2016-08-31 0001193125-16-697268 — 8.01, 9.01
- 2016-08-26 0001193125-16-692921 — 8.01, 9.01
- 2016-07-11 0001193125-16-645610 — 8.01
- 2016-07-05 0001193125-16-641679 — 8.01
- 2016-06-22 0001193125-16-629055 — 1.01, 2.03, 8.01, 9.01
- 2016-06-21 0001193125-16-627071 — 8.01, 9.01
- 2016-06-10 0001193125-16-618483 — 2.02, 9.01
- 2016-06-09 0001193125-16-617893 — 8.01, 9.01

## late-filing notifications on or before 2017-06-09

- none on or before 2017-06-09

## item 2.02 — earnings release, exhibit 99.1

[0001193125-17-197638:8k_2_02:1]
EX-99.1
2
d268242dex991.htm
EX-99.1

[0001193125-17-197638:8k_2_02:2]
EX-99.1

[0001193125-17-197638:8k_2_02:3]
Exhibit 99.1

[0001193125-17-197638:8k_2_02:4]
|  |  | News Release |  |  |

[0001193125-17-197638:8k_2_02:5]
Dell Technologies Reports Fiscal Year 2018

[0001193125-17-197638:8k_2_02:6]
First Quarter Financial Results

[0001193125-17-197638:8k_2_02:7]
ROUND
ROCK, Texas – June 8, 2017

[0001193125-17-197638:8k_2_02:8]
News summary

[0001193125-17-197638:8k_2_02:9]
|  | • |  | First quarter revenue was $17.8 billion, non-GAAP revenue was $18.2 billion |

[0001193125-17-197638:8k_2_02:10]
|  | • |  | Operating loss of $1.5 billion, non-GAAP operating income of $1.2 billion |

[0001193125-17-197638:8k_2_02:11]
|  | • |  | Successfully integrated sales organization to execute one go-to-market motion for customers |

[0001193125-17-197638:8k_2_02:12]
Full story

[0001193125-17-197638:8k_2_02:13]
Dell Technologies (NYSE: DVMT) announces its fiscal 2018 first quarter results, which reflect the growth and impact of the EMC transaction. 1

[0001193125-17-197638:8k_2_02:14]
For the first quarter, consolidated revenue was $17.8 billion and non-GAAP revenue was $18.2 billion.
During the quarter, the company generated an operating loss of $1.5 billion, with a non-GAAP operating income of $1.2 billion.

[0001193125-17-197638:8k_2_02:15]
“We’re pleased
with overall results in the first quarter of our new go-to-market structure and the demand velocity we saw in a challenging component cost environment,” said Tom Sweet, chief financial officer, Dell Technologies Inc. “I’m encouraged
by these achievements and excited about the opportunities ahead as we continue to provide a broad portfolio of solutions for our customers’ digital transformations.”

[0001193125-17-197638:8k_2_02:16]
The company ended the quarter with a cash and investments balance of $14.9 billion. Since closing the EMC transaction, Dell Technologies has paid down
approximately $7.1 billion in gross debt, resulting in a $200 million reduction in annualized interest expense on a run-rate basis. The company also has repurchased $1.1 billion of Class V Common Stock under both the previously announced Class V
Group and DHI Group repurchase programs.

[0001193125-17-197638:8k_2_02:17]
Fiscal first quarter 2018 results

[0001193125-17-197638:8k_2_02:18]
|  |  | Three Months Ended |  |
|  |  | May 5, 2017 |  |  | April 29, 2016 |  |  | Change |  |
|  |  | (in millions, except percentages; unaudited) |  |
| Net revenue |  | $ | 17,816 |  |  | $ | 12,241 |  |  |  | 46 | % |
| Operating loss |  | $ | (1,500 | ) |  | $ | (139 | ) |  |  | (979 | )% |
| Net loss from continuing operations |  | $ | (1,383 | ) |  | $ | (424 | ) |  |  | (226 | )% |
| Non-GAAP net revenue |  | $ | 18,171 |  |  | $ | 12,319 |  |  |  | 48 | % |
| Non-GAAP operating income |  | $ | 1,197 |  |  | $ | 539 |  |  |  | 122 | % |
| Non-GAAP net income from continuing operations |  | $ | 581 |  |  | $ | 264 |  |  |  | 120 | % |
| Adjusted EBITDA |  | $ | 1,567 |  |  | $ | 643 |  |  |  | 144 | % |

[0001193125-17-197638:8k_2_02:19]
Information about Dell Technologies’ use of non-GAAP financial information is provided under “Non-GAAP Financial
Measures” below. All comparisons in this press release are year-over-year unless otherwise noted.

[0001193125-17-197638:8k_2_02:20]
Operating segments summary

[0001193125-17-197638:8k_2_02:21]
Client Solutions Group continued to outgrow the market worldwide in unit shipments for both commercial and consumer product categories
on a calendar year basis. Revenue for the first quarter was $9.1 billion, up 6 percent year over year. Operating income was $374 million for the quarter, or 4.1 percent of revenue.

[0001193125-17-197638:8k_2_02:22]
Key highlights:

[0001193125-17-197638:8k_2_02:23]
|  | • |  | Increased PC shipments by 6.2 percent year-over-year, with 17 consecutive quarters of year-over-year PC unit share growth 2 |

[0001193125-17-197638:8k_2_02:24]
|  | • |  | Maintained No. 1 share position worldwide for displays, gaining unit share year-over-year for the 17th consecutive quarter 3 |

[0001193125-17-197638:8k_2_02:25]
|  | • |  | Only vendor to gain share year-over-year in both Fixed and Mobile workstation categories 4 |

[0001193125-17-197638:8k_2_02:26]
Infrastructure Solutions Group generated $6.9 billion of revenue in the first quarter, which includes $3.2 billion in servers and
networking and $3.7 billion in storage, with an operating income of $323 million.

[0001193125-17-197638:8k_2_02:27]
Key highlights:

[0001193125-17-197638:8k_2_02:28]
|  | • |  | Remained the worldwide market share leader in x86 servers, with PowerEdge units and revenue growth up by double digits in the fiscal quarter 5 |

[0001193125-17-197638:8k_2_02:29]
|  | • |  | Demand for hyperconverged portfolio grew at a triple-digit rate, while demand for all-flash solutions grew at a very high double-digit rate |

[0001193125-17-197638:8k_2_02:30]
|  | • |  | Increased demand for Virtustream Public Cloud for mission-critical applications by approximately 100 percent |

[0001193125-17-197638:8k_2_02:31]
VMware segment revenue for the first quarter was $1.7 billion, with operating income of $486 million, or 28 percent of revenue.

[0001193125-17-197638:8k_2_02:32]
Early in the first quarter, the company successfully integrated the combined sales organization and is now
operating with one common go-to-market sales motion for customers. Immediately following the quarter close, Dell Technologies hosted its second annual Dell EMC World conference last month in Las Vegas for 13,000 customers and partners. During the
event the company launched approximately 40 innovative products and solutions, including the new 14th generation of Dell EMC PowerEdge servers, four flexible consumption models, seven all-flash and hybrid storage systems and the world’s first
artificial intelligence platform for women entrepreneurs. In addition, the company announced Dell Technologies Capital, its venture practice for the entire Dell Technologies family of businesses aimed at investments in early-stage startups.

[0001193125-17-197638:8k_2_02:33]
Conference call information

[0001193125-17-197638:8k_2_02:34]
As previously announced, the
company will hold a conference call to discuss its first quarter performance today at 7 a.m. CDT. The conference call will be broadcast live over the internet and can be accessed at investors.delltechnologies.com. For those unable to listen to the
live broadcast, an archived version will be available at the same location for 30 days.

[0001193125-17-197638:8k_2_02:35]
A slide presentation containing additional financial and
operating information may be downloaded from Dell Technologies’ website at investors.delltechnologies.com.

[0001193125-17-197638:8k_2_02:36]
About Dell Technologies

[0001193125-17-197638:8k_2_02:37]
Dell Technologies is a unique family of businesses that provides the essential infrastructure for organizations to build their digital future, transform
IT and protect their most important asset, information. The company services customers of all sizes across 180 countries – ranging from 98 percent of the Fortune 500 to individual consumers – with the industry’s most
comprehensive and innovative portfolio from the edge to the core to the cloud.

[0001193125-17-197638:8k_2_02:38]
MEDIA CONTACTS:

[0001193125-17-197638:8k_2_02:39]
Dave Farmer

[0001193125-17-197638:8k_2_02:40]
(508) 293-7206

[0001193125-17-197638:8k_2_02:41]
dave.farmer@dell.com

[0001193125-17-197638:8k_2_02:42]
Lauren Lee

[0001193125-17-197638:8k_2_02:43]
(512) 728-4374

[0001193125-17-197638:8k_2_02:44]
lauren.lee@dell.com

[0001193125-17-197638:8k_2_02:45]
INVESTOR RELATIONS CONTACTS:

[0001193125-17-197638:8k_2_02:46]
Kristy Harris Bias

[0001193125-17-197638:8k_2_02:47]
(512) 728-1658

[0001193125-17-197638:8k_2_02:48]
kristy.harris.bias@dell.com

[0001193125-17-197638:8k_2_02:49]
Karen Litzler-Hollier

[0001193125-17-197638:8k_2_02:50]
(512) 728-0388

[0001193125-17-197638:8k_2_02:51]
karen.litzler-hollie@dell.com

[0001193125-17-197638:8k_2_02:52]
# # #

[0001193125-17-197638:8k_2_02:53]
Copyright © 2017 Dell Inc. or its subsidiaries. All
Rights Reserved. Dell, Dell EMC, Dell Inc. and the Dell logo are trademarks of Dell Technologies in the United States and/or other jurisdictions. All other marks and names mentioned herein may be trademarks of their respective companies.

[0001193125-17-197638:8k_2_02:54]
| 1 | Due to the EMC transaction and to a lesser extent the Dell going-private transaction, significant non-cash bridging items will remain between GAAP and non-GAAP results for the next few years. Prior-year historical Dell Technologies financials do not include EMC historical results, thereby impacting most year-over-year comparisons. |

[0001193125-17-197638:8k_2_02:55]
| 2 | IDC Worldwide Quarterly Personal Computing Device (PCD) Tracker CY17Q1 |

[0001193125-17-197638:8k_2_02:56]
| 3 | IDC Worldwide Quarterly PC Monitor Tracker CY16Q4 |

[0001193125-17-197638:8k_2_02:57]
| 4 | IDC Worldwide Quarterly Workstation Tracker CY17Q1 |

[0001193125-17-197638:8k_2_02:58]
| 5 | IDC Worldwide Quarterly Server Tracker, June 2017 |

[0001193125-17-197638:8k_2_02:59]
Non-GAAP Financial Measures

[0001193125-17-197638:8k_2_02:60]
The press release presents information about the Company’s non-GAAP net revenue, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP operating
income, non-GAAP net income from continuing operations, EBITDA and adjusted EBITDA, which are non-GAAP financial measures provided as a supplement to the results provided in accordance with generally accepted accounting principles in the United
States of America (“GAAP”). A reconciliation of each of the foregoing historical non-GAAP financial measures to the most directly comparable historical GAAP financial measures is provided in the attached tables for each of the fiscal
periods indicated.

[0001193125-17-197638:8k_2_02:61]
Special Note on Forward-Looking Statements:

[0001193125-17-197638:8k_2_02:62]
Dell Technologies’ results or events in future periods could differ materially from those expressed or implied by these forward-looking statements
because of risks, uncertainties, and other factors that include, but are not limited to, the following: competitive pressures; Dell Technologies’ reliance on third-party suppliers for products and components, including reliance on single-source
or limited-source suppliers; Dell Technologies’ ability to achieve favorable pricing from its vendors; adverse global economic conditions and instability in financial markets; Dell Technologies’ execution of its growth, business and
acquisition strategies; the success of Dell Technologies’ cost efficiency measures; Dell Technologies’ ability to manage solutions and products and services transitions in an effective manner; Dell Technologies’ ability to deliver
high-quality products and services; Dell Technologies’ foreign operations and ability to generate substantial non-U.S.net revenue; Dell Technologies’ product, customer, and geographic sales mix, and seasonal sales trends; the performance
of Dell Technologies’ sales channel partners; access to the capital markets by Dell Technologies or its customers; weak economic conditions and additional regulation; counterparty default risks; the loss by Dell Technologies of any services
contracts with its customers, including government contracts, and its ability to perform such contracts at its estimated costs; Dell Technologies’ ability to develop and protect its proprietary intellectual property or obtain licenses to
intellectual property developed by others on commercially reasonable and competitive terms; infrastructure disruptions, cyberattacks, or other data security breaches; Dell Technologies’ ability to hedge effectively its exposure to fluctuations
in foreign currency exchange rates and interest rates; expiration of tax holidays or favorable tax rate structures, or unfavorable outcomes in tax audits and other tax compliance matters; impairment of portfolio investments; unfavorable results of
legal proceedings; increased costs and additional regulations and requirements as a result of Dell Technologies becoming a newly public company; Dell Technologies’ ability to develop and maintain effective internal control over financial
reporting; compliance requirements of changing environmental and safety laws; the effect of armed hostilities, terrorism, natural disasters, and public health issues; the costs, time, and effort required to be dedicated to the integration of the
Dell and EMC businesses; the ability to realize the anticipated synergies from the merger with EMC; the ability to integrate EMC’s technology, solutions, products, and services with those of Dell in an effective manner; the impact of the
financial performance of VMware; and the market volatility of Dell Technologies’ pension plan assets.

[0001193125-17-197638:8k_2_02:63]
This list of risks, uncertainties, and
other factors is not complete. Dell Technologies discusses some of these matters more fully, as well as certain risk factors that could affect the Dell Technologies’ business, financial condition, results of operations, and prospects, in its
periodic reports filed with the Securities and Exchange Commission, including Dell Technologies’ Annual Report on Form 10-K for the fiscal year ended February 3, 2017, and current reports on Form 8-K. These filings are available for review
through the Securities and Exchange Commission’s website at www.sec.gov. Any or all forward-looking statements Dell Technologies makes may turn out to be wrong and can be affected by inaccurate assumptions Dell Technologies might make or by
known or unknown risks, uncertainties and other factors, including those identified in this press release. Accordingly, you should not place undue reliance on the forward-looking statements made in this press release, which speak only as of its
date. Dell Technologies does not undertake to update, and expressly disclaims any duty to update, its forward-looking statements, whether as a result of circumstances or events that arise after the date they are made, new information, or otherwise.

[0001193125-17-197638:8k_2_02:64]
DELL TECHNOLOGIES INC.

[0001193125-17-197638:8k_2_02:65]
Condensed Consolidated Statements of Income (Loss) and Related Financial Highlights

[0001193125-17-197638:8k_2_02:66]
(in millions, except per share amounts and percentages; unaudited)

[0001193125-17-197638:8k_2_02:67]
|  |  | Three Months Ended |  |  |  |  |
|  |  | May 5, 2017 |  |  | April 29, 2016 |  |  | Change |  |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |
| Products |  | $ | 12,968 |  |  | $ | 10,183 |  |  |  | 27 | % |
| Services |  |  | 4,848 |  |  |  | 2,058 |  |  |  | 136 | % |
| Total net revenue |  |  | 17,816 |  |  |  | 12,241 |  |  |  | 46 | % |
| Cost of net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |
| Products |  |  | 11,459 |  |  |  | 8,799 |  |  |  | 30 | % |
| Services |  |  | 2,055 |  |  |  | 1,249 |  |  |  | 65 | % |
| Total cost of net revenue |  |  | 13,514 |  |  |  | 10,048 |  |  |  | 34 | % |
| Gross margin |  |  | 4,302 |  |  |  | 2,193 |  |  |  | 96 | % |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling, general, and administrative |  |  | 4,669 |  |  |  | 2,068 |  |  |  | 126 | % |
| Research and development |  |  | 1,133 |  |  |  | 264 |  |  |  | 329 | % |
| Total operating expenses |  |  | 5,802 |  |  |  | 2,332 |  |  |  | 149 | % |
| Operating loss |  |  | (1,500 | ) |  |  | (139 | ) |  |  | (979 | )% |
| Interest and other, net |  |  | (573 | ) |  |  | (219 | ) |  |  | (162 | )% |
| Loss from continuing operations before income taxes |  |  | (2,073 | ) |  |  | (358 | ) |  |  | (479 | )% |
| Income tax provision (benefit) |  |  | (690 | ) |  |  | 66 |  |  |  | NM |  |
| Net loss from continuing operations |  |  | (1,383 | ) |  |  | (424 | ) |  |  | (226 | )% |
| Income from discontinued operations, net of income taxes |  |  | — |  |  |  | 479 |  |  |  | (100 | )% |
| Net income (loss) |  |  | (1,383 | ) |  |  | 55 |  |  |  | NM |  |
| Less: Net loss attributable to non-controlling interests |  |  | (49 | ) |  |  | — |  |  |  | NA |  |
| Net income (loss) attributable to Dell Technologies Inc. |  | $ | (1,334 | ) |  | $ | 55 |  |  |  | NM |  |
| Earnings (loss) per share attributable to Dell Technologies Inc. - basic: |  |  |  |  |  |  |  |  |  |  |  |  |
| Continuing operations - Class V Common Stock - basic |  | $ | 0.57 |  |  | $ | — |  |  |  |  |  |
| Continuing operations - DHI Group - basic |  | $ | (2.57 | ) |  | $ | (1.05 | ) |  |  |  |  |
| Discontinued operations - DHI Group - basic |  | $ | — |  |  | $ | 1.18 |  |  |  |  |  |
| Earnings (loss) per share attributable to Dell Technologies Inc. - diluted: |  |  |  |  |  |  |  |  |  |  |  |  |
| Continuing operations - Class V Common Stock - diluted |  | $ | 0.56 |  |  | $ | — |  |  |  |  |  |
| Continuing operations - DHI Group - diluted |  | $ | (2.57 | ) |  | $ | (1.05 | ) |  |  |  |  |
| Discontinued operations - DHI Group - diluted |  | $ | — |  |  | $ | 1.18 |  |  |  |  |  |
| Weighted-average shares outstanding: |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic - Class V Common Stock |  |  | 207 |  |  |  | — |  |  |  |  |  |
| Diluted - Class V Common Stock |  |  | 207 |  |  |  | — |  |  |  |  |  |
| Basic - DHI Group |  |  | 566 |  |  |  | 405 |  |  |  |  |  |
| Diluted - DHI Group |  |  | 566 |  |  |  | 405 |  |  |  |  |  |
| Percentage of Total Net Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |
| Gross margin |  |  | 24 | % |  |  | 18 | % |  |  |  |  |
| Selling, general, and administrative |  |  | 26 | % |  |  | 17 | % |  |  |  |  |
| Research and development |  |  | 6 | % |  |  | 2 | % |  |  |  |  |
| Operating expenses |  |  | 33 | % |  |  | 19 | % |  |  |  |  |
| Operating loss |  |  | (8 | )% |  |  | (1 | )% |  |  |  |  |
| Loss from continuing operations before income taxes |  |  | (12 | )% |  |  | (3 | )% |  |  |  |  |
| Net loss from continuing operations |  |  | (8 | )% |  |  | (3 | )% |  |  |  |  |
| Income tax rate |  |  | 33 | % |  |  | (18 | )% |  |  |  |  |

[0001193125-17-197638:8k_2_02:68]
DELL TECHNOLOGIES INC.

[0001193125-17-197638:8k_2_02:69]
Condensed Consolidated Statements of Financial Position

[0001193125-17-197638:8k_2_02:70]
(in millions; unaudited)

[0001193125-17-197638:8k_2_02:71]
|  |  | May 5, 2017 |  |  | February 3, 2017 |  |
| ASSETS |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 9,554 |  |  | $ | 9,474 |  |
| Short-term investments |  |  | 1,620 |  |  |  | 1,975 |  |
| Accounts receivable, net |  |  | 8,834 |  |  |  | 9,420 |  |
| Short-term financing receivables, net |  |  | 3,255 |  |  |  | 3,222 |  |
| Inventories, net |  |  | 2,466 |  |  |  | 2,538 |  |
| Other current assets |  |  | 4,655 |  |  |  | 4,144 |  |
| Total current assets |  |  | 30,384 |  |  |  | 30,773 |  |
| Property, plant, and equipment, net |  |  | 5,438 |  |  |  | 5,653 |  |
| Long-term investments |  |  | 3,772 |  |  |  | 3,802 |  |
| Long-term financing receivables, net |  |  | 2,741 |  |  |  | 2,651 |  |
| Goodwill |  |  | 38,930 |  |  |  | 38,910 |  |
| Intangible assets, net |  |  | 33,283 |  |  |  | 35,053 |  |
| Other non-current assets |  |  | 1,492 |  |  |  | 1,364 |  |
| Total assets |  | $ | 116,040 |  |  | $ | 118,206 |  |
| LIABILITIES, REDEEMABLE SHARES, AND STOCKHOLDERS’ EQUITY |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Short-term debt |  | $ | 4,842 |  |  | $ | 6,329 |  |
| Accounts payable |  |  | 15,064 |  |  |  | 14,422 |  |
| Accrued and other |  |  | 6,376 |  |  |  | 7,119 |  |
| Short-term deferred revenue |  |  | 10,354 |  |  |  | 10,265 |  |
| Total current liabilities |  |  | 36,636 |  |  |  | 38,135 |  |
| Long-term debt |  |  | 44,948 |  |  |  | 43,061 |  |
| Long-term deferred revenue |  |  | 8,330 |  |  |  | 8,431 |  |
| Other non-current liabilities |  |  | 8,435 |  |  |  | 9,339 |  |
| Total liabilities |  |  | 98,349 |  |  |  | 98,966 |  |
| Redeemable shares |  |  | 301 |  |  |  | 231 |  |
| Stockholders’ equity: |  |  |  |  |  |  |  |  |
| Total Dell Technologies Inc. stockholders’ equity |  |  | 11,532 |  |  |  | 13,243 |  |
| Non-controlling interests |  |  | 5,858 |  |  |  | 5,766 |  |
| Total stockholders’ equity |  |  | 17,390 |  |  |  | 19,009 |  |
| Total liabilities, redeemable shares, and stockholders’ equity |  | $ | 116,040 |  |  | $ | 118,206 |  |

[0001193125-17-197638:8k_2_02:72]
DELL TECHNOLOGIES INC.

[0001193125-17-197638:8k_2_02:73]
Condensed Consolidated Statements of Cash Flows

[0001193125-17-197638:8k_2_02:74]
(in millions; unaudited)

[0001193125-17-197638:8k_2_02:75]
|  |  | Three Months Ended |  |
|  |  | May 5, 2017 |  |  | April 29, 2016 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net income (loss) |  | $ | (1,383 | ) |  | $ | 55 |  |
| Adjustments to reconcile net loss to net cash provided by operating activities |  |  | 1,623 |  |  |  | (118 | ) |
| Change in cash from operating activities |  |  | 240 |  |  |  | (63 | ) |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Investments: |  |  |  |  |  |  |  |  |
| Purchases |  |  | (559 | ) |  |  | — |  |
| Maturities and sales |  |  | 973 |  |  |  | 12 |  |
| Capital expenditures |  |  | (245 | ) |  |  | (92 | ) |
| Proceeds from sale of facilities, land, and other assets |  |  | — |  |  |  | 4 |  |
| Capitalized software development costs |  |  | (89 | ) |  |  | — |  |
| Collections on purchased financing receivables |  |  | 3 |  |  |  | 16 |  |
| Acquisition of businesses, net |  |  | (12 | ) |  |  | — |  |
| Divestitures of businesses, net |  |  | (20 | ) |  |  | — |  |
| Change in cash from investing activities |  |  | 51 |  |  |  | (60 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Proceeds from the issuance of common stock of subsidiaries |  |  | 8 |  |  |  | 102 |  |
| Repurchases of DHI Group Common Stock |  |  | (2 | ) |  |  | — |  |
| Repurchases of Class V Common Stock |  |  | (368 | ) |  |  | — |  |
| Issuance of common stock under employee plans |  |  | 1 |  |  |  | — |  |
| Payments for debt issuance costs |  |  | (5 | ) |  |  | (2 | ) |
| Proceeds from debt |  |  | 3,441 |  |  |  | 552 |  |
| Repayments of debt |  |  | (3,154 | ) |  |  | (1,041 | ) |
| Repurchases for tax withholdings on vesting of equity awards |  |  | (126 | ) |  |  | (1 | ) |
| Other |  |  | — |  |  |  | 3 |  |
| Change in cash from financing activities |  |  | (205 | ) |  |  | (387 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  |  | (6 | ) |  |  | 73 |  |
| Change in cash and cash equivalents |  |  | 80 |  |  |  | (437 | ) |
| Cash and cash equivalents at beginning of the period, including amounts held for sale |  |  | 9,474 |  |  |  | 6,576 |  |
| Cash and cash equivalents at end of the period |  | $ | 9,554 |  |  | $ | 6,139 |  |
| Less: Cash included in current assets held for sale |  |  | — |  |  |  | 268 |  |
| Cash and cash equivalents from continuing operations |  | $ | 9,554 |  |  | $ | 5,871 |  |

[0001193125-17-197638:8k_2_02:76]
DELL TECHNOLOGIES INC.

[0001193125-17-197638:8k_2_02:77]
Segment Information

[0001193125-17-197638:8k_2_02:78]
(in
millions, except percentages; unaudited)

[0001193125-17-197638:8k_2_02:79]
|  |  | Three Months Ended |  |  |  |  |
|  |  | May 5, 2017 |  |  | April 29, 2016 |  |  | Change |  |
| Client Solutions Group (CSG): |  |  |  |  |  |  |  |  |  |  |  |  |
| Net Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |
| Commercial |  | $ | 6,350 |  |  | $ | 6,145 |  |  |  | 3 | % |
| Consumer |  |  | 2,706 |  |  |  | 2,426 |  |  |  | 12 | % |
| Total CSG net revenue |  | $ | 9,056 |  |  | $ | 8,571 |  |  |  | 6 | % |
| Operating Income: |  |  |  |  |  |  |  |  |  |  |  |  |
| CSG operating income |  | $ | 374 |  |  | $ | 385 |  |  |  | (3 | )% |
| % of CSG net revenue |  |  | 4 | % |  |  | 4 | % |  |  |  |  |
| % of total segment operating income |  |  | 32 | % |  |  | 67 | % |  |  |  |  |
| Infrastructure Solutions Group (ISG): |  |  |  |  |  |  |  |  |  |  |  |  |
| Net Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |
| Servers and networking |  | $ | 3,231 |  |  | $ | 3,075 |  |  |  | 5 | % |
| Storage |  |  | 3,685 |  |  |  | 538 |  |  |  | 585 | % |
| Total ISG net revenue |  | $ | 6,916 |  |  | $ | 3,613 |  |  |  | 91 | % |
| Operating Income: |  |  |  |  |  |  |  |  |  |  |  |  |
| ISG operating income |  | $ | 323 |  |  | $ | 192 |  |  |  | 68 | % |
| % of ISG net revenue |  |  | 5 | % |  |  | 5 | % |  |  |  |  |
| % of total segment operating income |  |  | 27 | % |  |  | 33 | % |  |  |  |  |
| VMware: |  |  |  |  |  |  |  |  |  |  |  |  |
| Net Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |
| Total VMware net revenue |  | $ | 1,736 |  |  | $ | — |  |  |  | NA |  |
| Operating Income: |  |  |  |  |  |  |  |  |  |  |  |  |
| VMware operating income |  | $ | 486 |  |  | $ | — |  |  |  | NA |  |
| % of VMware net revenue |  |  | 28 | % |  |  | NA |  |  |  |  |  |
| % of total segment operating income |  |  | 41 | % |  |  | NA |  |  |  |  |  |
| Reconciliation to consolidated net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |
| Reportable segment net revenue |  | $ | 17,708 |  |  | $ | 12,184 |  |  |  |  |  |
| Other businesses (a) |  |  | 462 |  |  |  | 110 |  |  |  |  |  |
| Unallocated transactions (b) |  |  | 1 |  |  |  | 25 |  |  |  |  |  |
| Impact of purchase accounting (c) |  |  | (355 | ) |  |  | (78 | ) |  |  |  |  |
| Total net revenue |  | $ | 17,816 |  |  | $ | 12,241 |  |  |  |  |  |
| Reconciliation to consolidated operating income (loss): |  |  |  |  |  |  |  |  |  |  |  |  |
| Reportable segment operating income |  | $ | 1,183 |  |  | $ | 577 |  |  |  |  |  |
| Other businesses (a) |  |  | 3 |  |  |  | (16 | ) |  |  |  |  |
| Unallocated transactions (b) |  |  | 11 |  |  |  | (22 | ) |  |  |  |  |
| Impact of purchase accounting (c) |  |  | (423 | ) |  |  | (106 | ) |  |  |  |  |
| Amortization of intangibles |  |  | (1,776 | ) |  |  | (491 | ) |  |  |  |  |
| Transaction-related expenses (d) |  |  | (191 | ) |  |  | (57 | ) |  |  |  |  |
| Other corporate expenses (e) |  |  | (307 | ) |  |  | (24 | ) |  |  |  |  |
| Total operating loss |  | $ | (1,500 | ) |  | $ | (139 | ) |  |  |  |  |

[0001193125-17-197638:8k_2_02:80]
| (a) | Other businesses consist of RSA Information Security, SecureWorks, Pivotal, and Boomi offerings, and do not constitute a reportable segment, either individually or collectively, as the results of the businesses are not material to the Company’s overall results and the businesses do not meet the criteria for reportable segments. |

[0001193125-17-197638:8k_2_02:81]
| (b) | Unallocated transactions includes long-term incentives, certain short-term incentive compensation expenses, and other corporate items that are not allocated to Dell Technologies’ reportable segments. |

[0001193125-17-197638:8k_2_02:82]
| (c) | Impact of purchase accounting includes non-cash purchase accounting adjustments that are primarily related to the EMC merger transaction. |

[0001193125-17-197638:8k_2_02:83]
| (d) | Transaction-related expenses includes acquisition, integration, and divestiture related costs. |

[0001193125-17-197638:8k_2_02:84]
| (e) | Other corporate expenses includes severance and facility action costs as well as stock-based compensation expense. |

[0001193125-17-197638:8k_2_02:85]
SUPPLEMENTAL SELECTED NON-GAAP FINANCIAL MEASURES

[0001193125-17-197638:8k_2_02:86]
These tables present information about the Company’s non-GAAP net revenue, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP operating income,
non-GAAP net income from continuing operations, EBITDA, and adjusted EBITDA, which are non-GAAP financial measures provided as a supplement to the results provided in accordance with generally accepted accounting principles in the United States of
America (“GAAP”). A detailed discussion of Dell Technologies’ reasons for including these non-GAAP financial measures, the limitations associated with these measures, the items excluded from
these measures, and our reason for excluding those items are presented in “Management’s Discussion and Analysis of Financial Condition and Results of Operations - Non-GAAP Financial Measures” in our periodic reports filed with the
SEC. Dell Technologies encourages investors to review the non-GAAP discussion in conjunction with the presentation of non-GAAP financial measures.

[0001193125-17-197638:8k_2_02:87]
DELL TECHNOLOGIES INC.

[0001193125-17-197638:8k_2_02:88]
Selected Non-GAAP Financial Measures

[0001193125-17-197638:8k_2_02:89]
(in millions, except percentages; unaudited)

[0001193125-17-197638:8k_2_02:90]
|  |  | Three Months Ended |  |  |  |  |
|  |  | May 5, 2017 |  |  | April 29, 2016 |  |  | Change |  |
| Non-GAAP net revenue |  | $ | 18,171 |  |  | $ | 12,319 |  |  |  | 48 | % |
| Non-GAAP gross margin |  | $ | 5,646 |  |  | $ | 2,385 |  |  |  | 137 | % |
| % of non-GAAP net revenue |  |  | 31 | % |  |  | 19 | % |  |  |  |  |
| Non-GAAP operating expenses |  | $ | 4,449 |  |  | $ | 1,846 |  |  |  | 141 | % |
| % of non-GAAP net revenue |  |  | 24 | % |  |  | 15 | % |  |  |  |  |
| Non-GAAP operating income |  | $ | 1,197 |  |  | $ | 539 |  |  |  | 122 | % |
| % of non-GAAP net revenue |  |  | 7 | % |  |  | 4 | % |  |  |  |  |
| Non-GAAP net income from continuing operations |  | $ | 581 |  |  | $ | 264 |  |  |  | 120 | % |
| % of non-GAAP net revenue |  |  | 3 | % |  |  | 2 | % |  |  |  |  |
| Adjusted EBITDA |  | $ | 1,567 |  |  | $ | 643 |  |  |  | 144 | % |
| % of non-GAAP net revenue |  |  | 9 | % |  |  | 5 | % |  |  |  |  |

[0001193125-17-197638:8k_2_02:91]
DELL TECHNOLOGIES INC.

[0001193125-17-197638:8k_2_02:92]
Reconciliation of Selected Non-GAAP Financial Measures

[0001193125-17-197638:8k_2_02:93]
(in millions, except percentages; unaudited)

[0001193125-17-197638:8k_2_02:94]
|  |  | Three Months Ended |  |  |  |  |
|  |  | May 5, 2017 |  |  | April 29, 2016 |  |  | Change |  |
| Net revenue |  | $ | 17,816 |  |  | $ | 12,241 |  |  |  | 46 | % |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Impact of purchase accounting |  |  | 355 |  |  |  | 78 |  |  |  |  |  |
| Non-GAAP net revenue |  | $ | 18,171 |  |  | $ | 12,319 |  |  |  | 48 | % |
| Gross margin |  | $ | 4,302 |  |  | $ | 2,193 |  |  |  | 96 | % |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Impact of purchase accounting |  |  | 365 |  |  |  | 89 |  |  |  |  |  |
| Amortization of intangibles |  |  | 950 |  |  |  | 101 |  |  |  |  |  |
| Transaction-related expenses |  |  | 7 |  |  |  | (1 | ) |  |  |  |  |
| Other corporate expenses |  |  | 22 |  |  |  | 3 |  |  |  |  |  |
| Non-GAAP gross margin |  | $ | 5,646 |  |  | $ | 2,385 |  |  |  | 137 | % |
| Operating expenses |  | $ | 5,802 |  |  | $ | 2,332 |  |  |  | 149 | % |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Impact of purchase accounting |  |  | (58 | ) |  |  | (17 | ) |  |  |  |  |
| Amortization of intangibles |  |  | (826 | ) |  |  | (390 | ) |  |  |  |  |
| Transaction-related expenses |  |  | (184 | ) |  |  | (58 | ) |  |  |  |  |
| Other corporate expenses |  |  | (285 | ) |  |  | (21 | ) |  |  |  |  |
| Non-GAAP operating expenses |  | $ | 4,449 |  |  | $ | 1,846 |  |  |  | 141 | % |
| Operating loss |  | $ | (1,500 | ) |  | $ | (139 | ) |  |  | (979 | )% |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Impact of purchase accounting |  |  | 423 |  |  |  | 106 |  |  |  |  |  |
| Amortization of intangibles |  |  | 1,776 |  |  |  | 491 |  |  |  |  |  |
| Transaction-related expenses |  |  | 191 |  |  |  | 57 |  |  |  |  |  |
| Other corporate expenses |  |  | 307 |  |  |  | 24 |  |  |  |  |  |
| Non-GAAP operating income |  | $ | 1,197 |  |  | $ | 539 |  |  |  | 122 | % |
| Net loss from continuing operations |  | $ | (1,383 | ) |  | $ | (424 | ) |  |  | (226 | )% |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Impact of purchase accounting |  |  | 423 |  |  |  | 106 |  |  |  |  |  |
| Amortization of intangibles |  |  | 1,776 |  |  |  | 491 |  |  |  |  |  |
| Transaction-related expenses |  |  | 191 |  |  |  | 57 |  |  |  |  |  |
| Other corporate expenses |  |  | 307 |  |  |  | 24 |  |  |  |  |  |
| Aggregate adjustment for income taxes |  |  | (733 | ) |  |  | 10 |  |  |  |  |  |
| Non-GAAP net income from continuing operations |  | $ | 581 |  |  | $ | 264 |  |  |  | 120 | % |
| Net loss from continuing operations |  | $ | (1,383 | ) |  | $ | (424 | ) |  |  | (226 | )% |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest and other, net |  |  | 573 |  |  |  | 219 |  |  |  |  |  |
| Income tax provision (benefit) |  |  | (690 | ) |  |  | 66 |  |  |  |  |  |
| Depreciation and amortization |  |  | 2,212 |  |  |  | 618 |  |  |  |  |  |
| EBITDA |  | $ | 712 |  |  | $ | 479 |  |  |  | 49 | % |
| EBITDA |  | $ | 712 |  |  | $ | 479 |  |  |  | 49 | % |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation expense |  |  | 201 |  |  |  | 14 |  |  |  |  |  |
| Impact of purchase accounting |  |  | 357 |  |  |  | 83 |  |  |  |  |  |
| Transaction-related expenses |  |  | 191 |  |  |  | 57 |  |  |  |  |  |
| Other corporate expenses |  |  | 106 |  |  |  | 10 |  |  |  |  |  |
| Adjusted EBITDA |  | $ | 1,567 |  |  | $ | 643 |  |  |  | 144 | % |
