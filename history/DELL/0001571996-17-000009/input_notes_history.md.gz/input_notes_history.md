# DELL note change history — 0001571996-16-000021 → 0001571996-17-000009


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- added (2017-06-09):
[0001571996-17-000009:note_history:1]
Legal Matters

- changed (2017-06-09):
[0001571996-17-000009:note_history:2]
The Company is involved in various claims, suits, assessments, investigations, and legal proceedings that arise from time to time in the ordinary course of its business, including those identified below, consisting of matters involving consumer, antitrust, tax, intellectual property, and other issues on a global basis.  The Company accrues a liability when it believes that it is both probable that a liability has been incurred and that it can reasonably estimate the amount of the loss.  The Company reviews these accruals at least quarterly and adjusts them to reflect ongoing negotiations, settlements, rulings, advice of legal counsel, and other relevant information.  To the extent new information is obtained and the Company's views on the probable outcomes of claims, suits, assessments, investigations, or legal proceedings change, changes in the Company's accrued liabilities would be recorded in the period in which such a determination is made.  For some matters, the amount of liability is not probable or the amount cannot be reasonably estimated and therefore accruals have not been made.  The following is a discussion of the Company's significant legal matters and other proceedings:
  (was, 2016-12-09, similarity 0.9925):
[0001571996-16-000021:note_history:2]
Legal Matters — The Company is involved in various claims, suits, assessments, investigations, and legal proceedings that arise from time to time in the ordinary course of its business, including those identified below, consisting of matters involving consumer, antitrust, tax, intellectual property, and other issues on a global basis.  The Company accrues a liability when it believes that it is both probable that a liability has been incurred and that it can reasonably estimate the amount of the loss.  The Company reviews these accruals at least quarterly and adjusts them to reflect ongoing negotiations, settlements, rulings, advice of legal counsel, and other relevant information.  To the extent new information is obtained and the Company's views on the probable outcomes of claims, suits, assessments, investigations, or legal proceedings change, changes in the Company's accrued liabilities would be recorded in the period in which such determination is made.  For some matters, the amount of liability is not probable or the amount cannot be reasonably estimated and therefore accruals have not been made.  The following is a discussion of the Company's significant legal matters and other proceedings:

- changed (2017-06-09):
[0001571996-17-000009:note_history:3]
EMC Merger Litigation — The Company, Dell, and Universal Acquisition Co. ("Universal") were named as defendants in fifteen putative class-action lawsuits brought by purported EMC shareholders and VMware, Inc. stockholders challenging the proposed merger between the Company, Dell, and Universal on the one hand, and EMC on the other (the "EMC merger").  Those suits are captioned as follows:
  (was, 2016-12-09, similarity 0.9166):
[0001571996-16-000021:note_history:3]
EMC Merger Litigation — The Company, Dell, and Universal Acquisition Co. (“Universal”) have been named as defendants in fifteen putative class-action lawsuits brought by purported EMC shareholders and VMware stockholders challenging the proposed merger between the Company, Dell, and Universal on the one hand, and EMC on the other (the “EMC merger”).  Those suits are captioned as follows:

- changed (2017-06-09):
[0001571996-17-000009:note_history:4]
| Case | Court | Filing Date |
| 1. | IBEW Local No. 129 Benefit Fund v. Tucci,Civ. No. 1584-3130-BLS1 | Mass. Superior Court, Suffolk County | 10/15/2015 |
| 2. | Barrett v. Tucci,Civ. No. 15-6023-A | Mass. Superior Court, Middlesex County | 10/16/2015 |
| 3. | Graulich v. Tucci,Civ. No. 1584-3169-BLS1 | Mass. Superior Court, Suffolk County | 10/19/2015 |
| 4. | Vassallo v. EMC Corp.,Civ. No. 1584-3173-BLS1 | Mass. Superior Court, Suffolk County | 10/19/2015 |
| 5. | City of Miami Police Relief & Pension Fund v. Tucci,Civ. No. 1584-3174-BLS1 | Mass. Superior Court, Suffolk County | 10/19/2015 |
| 6. | Lasker v. EMC Corp.,Civ. No. 1584-3214-BLS1 | Mass. Superior Court, Suffolk County | 10/23/2015 |
| 7. | Walsh v. EMC Corp.,Civ. No. 15-13654 | U.S. District Court,District of Massachusetts | 10/27/2015 |
| 8. | Local Union No. 373 U.A. Pension Plan v. EMC Corp.,Civ. No. 1584-3253-BLS1 | Mass. Superior Court, Suffolk County | 10/28/2015 |
| 9. | City of Lakeland Emps.' Pension & Ret. Fund v. Tucci,Civ. No. 1584-3269-BLS1 | Mass. Superior Court, Suffolk County | 10/28/2015 |
| 10. | Ma v. Tucci,Civ. No. 1584-3281-BLS1 | Mass. Superior Court, Suffolk County | 10/29/2015 |
| 11. | Stull v. EMC Corp.,Civ. No. 15-13692 | U.S. District Court,District of Massachusetts | 10/30/2015 |
| 12. | Jacobs v. EMC Corp.,Civ. No. 15-6318-H | Mass. Superior Court, Middlesex County | 11/12/2015 |
| 13. | Ford v. VMware, Inc.,C.A. No. 11714-VCL | Delaware Chancery Court | 11/17/2015 |
| 14. | Pancake v. EMC Corp.,Civ. No. 16-10040 | U.S. District Court,District of Massachusetts | 1/11/2016 |
| 15. | Booth Family Trust v. EMC Corp.,Civ. No. 16-10114 | U.S. District Court,District of Massachusetts | 1/26/2016 |
  (was, 2016-12-09, similarity 0.9993):
[0001571996-16-000021:note_history:4]
| Case | Court | Filing Date |
| 1. | IBEW Local No. 129 Benefit Fund v. Tucci,Civ. No. 1584-3130-BLS1 | Mass. Superior Court, Suffolk County | 10/15/2015 |
| 2. | Barrett v. Tucci,Civ. No. 15-6023-A | Mass. Superior Court, Middlesex County | 10/16/2015 |
| 3. | Graulich v. Tucci,Civ. No. 1584-3169-BLS1 | Mass. Superior Court, Suffolk County | 10/19/2015 |
| 4. | Vassallo v. EMC Corp.,Civ. No. 1584-3173-BLS1 | Mass. Superior Court, Suffolk County | 10/19/2015 |
| 5. | City of Miami Police Relief & Pension Fund v. Tucci,Civ. No. 1584-3174-BLS1 | Mass. Superior Court, Suffolk County | 10/19/2015 |
| 6. | Lasker v. EMC Corp.,Civ. No. 1584-3214-BLS1 | Mass. Superior Court, Suffolk County | 10/23/2015 |
| 7. | Walsh v. EMC Corp.,Civ. No. 15-13654 | U.S. District Court,District of Massachusetts | 10/27/2015 |
| 8. | Local Union No. 373 U.A. Pension Plan v. EMC Corp.,Civ. No. 1584-3253-BLS1 | Mass. Superior Court, Suffolk County | 10/28/2015 |
| 9. | City of Lakeland Emps.’ Pension & Ret. Fund v. Tucci,Civ. No. 1584-3269-BLS1 | Mass. Superior Court, Suffolk County | 10/28/2015 |
| 10. | Ma v. Tucci,Civ. No. 1584-3281-BLS1 | Mass. Superior Court, Suffolk County | 10/29/2015 |
| 11. | Stull v. EMC Corp.,Civ. No. 15-13692 | U.S. District Court,District of Massachusetts | 10/30/2015 |
| 12. | Jacobs v. EMC Corp.,Civ. No. 15-6318-H | Mass. Superior Court, Middlesex County | 11/12/2015 |
| 13. | Ford v. VMware, Inc.,C.A. No. 11714-VCL | Delaware Chancery Court | 11/17/2015 |
| 14. | Pancake v. EMC Corp.,Civ. No. 16-10040 | U.S. District Court,District of Massachusetts | 1/11/2016 |
| 15. | Booth Family Trust v. EMC Corp.,Civ. No. 16-10114 | U.S. District Court,District of Massachusetts | 1/26/2016 |

- changed (2017-06-09):
[0001571996-17-000009:note_history:5]
The fifteen lawsuits sought, among other things, injunctive relief enjoining the EMC merger, rescission of the EMC merger if consummated, an award of fees and costs, and/or an award of damages.
  (was, 2016-12-09, similarity 0.9792):
[0001571996-16-000021:note_history:5]
The fifteen lawsuits seek, among other things, injunctive relief enjoining the EMC merger, rescission of the EMC merger if consummated, an award of fees and costs, and/or an award of damages.

- changed (2017-06-09):
[0001571996-17-000009:note_history:6]
The complaints in the IBEW, Barrett, Graulich, Vassallo, City of Miami, Lasker, Local Union No. 373, City of Lakeland, and Ma actions generally allege that the EMC directors breached their fiduciary duties to EMC shareholders in connection with the EMC merger by, among other things, failing to maximize shareholder value and agreeing to provisions in the EMC merger agreement that discouraged competing bids.  After consolidating the nine complaints, by decision dated December 7, 2015, the Business Litigation Session of the Suffolk County Superior Court in Massachusetts dismissed all nine complaints for failure to make a demand on the EMC board of directors.  Three of the nine plaintiffs in the consolidated actions appealed the judgment dismissing their complaints.  The Massachusetts Supreme Judicial Court granted an application for direct appellate review, and heard oral argument on the appeal on November 7, 2016.  On March 6, 2017, the Supreme Judicial Court issued a decision affirming the dismissal.  This decision terminated the consolidated actions.
  (was, 2016-12-09, similarity 0.705):
[0001571996-16-000021:note_history:6]
The complaints in the IBEW, Barrett, Graulich, Vassallo, City of Miami, Lasker, Local Union No. 373, City of Lakeland, and Ma actions generally allege that the EMC directors breached their fiduciary duties to EMC shareholders in connection with the EMC merger by, among other things, failing to maximize shareholder value and agreeing to provisions in the EMC merger agreement that discourage competing bids. The complaints generally further allege that there were various conflicts of interest in the proposed transaction. The IBEW, Graulich, City of Miami, and Ma plaintiffs brought suit against the Company, Dell, and Universal for injunctive relief.  The Barrett, Vassallo, Lasker, Lakeland, and Local Union No. 373 plaintiffs brought suit against the Company, Dell, and Universal as alleged aiders and abettors.   After consolidating the nine complaints, by decision dated December 7, 2015, the Business Litigation Session of the Suffolk County Superior Court in Massachusetts, dismissed all nine complaints for failure to make a demand on the EMC board of directors.  Three of the nine plaintiffs in the consolidated actions appealed the judgment dismissing their complaints.  The Massachusetts Supreme Judicial Court granted an application for direct appellate review, and heard oral argument on the appeal on November 7, 2016.  The outcome of the appeal is uncertain.

- changed (2017-06-09):
[0001571996-17-000009:note_history:7]
The complaints in the Walsh, Stull, Pancake, and Booth actions allege that the EMC directors breached their fiduciary duties to EMC shareholders in connection with the EMC merger by, among other things, failing to maximize shareholder value and agreeing to provisions in the EMC merger agreement that discouraged competing bids.  The complaints generally further allege that the preliminary registration statement on Form S-4 filed by the Company on December 14, 2015 in connection with the transaction contained material misstatements and omissions, in violation of Section 14(a) of the Securities Exchange Act of 1934 (the "Exchange Act") and SEC Rule 14a-9 promulgated thereunder and/or that the Company, Dell, and Universal acted as controlling persons of EMC under Section 20(a) of the Exchange Act.  On June 6, 2016, the Securities and Exchange Commission declared effective the Company's registration statement on Form S-4 relating to the EMC merger (the "SEC Form S-4"), including the amendments thereto.  On June 17, 2016, the parties to the Walsh, Stull, Pancake, and Booth actions submitted to the Court a Stipulation and Proposed Order Dismissing Action and Retaining Jurisdiction to Determine Plaintiffs' Counsel's Application for an Award of Attorneys' Fees and Reimbursement of Expenses.  In the stipulation, the plaintiffs represented to the Court that they believe sufficient information had been disclosed to warrant dismissal of the actions as moot in light of the disclosures in the SEC Form S-4, including the amendments thereto.  On October 25, 2016, following an agreement between the parties with respect to attorneys' fees and expenses, the Court entered an order terminating the four actions for all purposes.
  (was, 2016-12-09, similarity 0.7607):
[0001571996-16-000021:note_history:7]
The complaints in the Walsh, Stull, Pancake, and Booth actions allege that the EMC directors breached their fiduciary duties to EMC shareholders in connection with the EMC merger by, among other things, failing to maximize shareholder value and agreeing to provisions in the EMC merger agreement that discourage competing bids. The complaints generally further allege that there were various conflicts of interest in the proposed transaction and that the preliminary SEC Form S-4 filed by the Company on December 14, 2015 in connection with the transaction contained material misstatements and omissions, in violation of Section 14(a) of the Securities Exchange Act of 1934 (the "Exchange Act”) and SEC Rule 14a-9 promulgated thereunder (“Rule 14a-9”).  Under the amended complaints, the plaintiffs in the Walsh, Stull, and Pancake actions have brought suit against the Company, Dell, and Universal under Section 20(a) of the Exchange Act as alleged controlling persons of EMC.  The plaintiffs in the Booth action have brought suit against the Company, Dell, and Universal under Section 14(a) of the Exchange Act and Rule 14a-9.  On April 26, 2016, the Court consolidated the actions and entered an order appointing Plaintiff Stull as lead plaintiff and his choice of counsel as lead and liaison counsel.  On June 6, 2016, the Securities and Exchange Commission declared effective the Company’s registration statement on Form S-4 relating to the EMC merger (the “SEC Form S-4”), including the amendments thereto.  On June 17, 2016, the parties to the Walsh, Stull, Pancake, and Booth actions submitted to the Court a Stipulation and Proposed Order Dismissing Action and Retaining Jurisdiction to Determine Plaintiffs’ Counsel’s Application for an Award of Attorneys’ Fees and Reimbursement of Expenses.  In the stipulation, the plaintiffs represented to the Court that they believe sufficient information had been disclosed to warrant dismissal of the actions as moot in light of the disclosures in the SEC Form S-4, including the amendments thereto.  The Court has entered the proposed order and the cases are now dismissed.

- added (2017-06-09):
[0001571996-17-000009:note_history:8]
The amended complaints in the Jacobs and Ford actions allege that EMC, as the majority stockholder of VMware, Inc., and the individual defendants, who were directors of EMC, VMware, Inc., or both, breached their fiduciary duties to minority stockholders of VMware, Inc. in connection with the proposed EMC merger by allegedly entering into or approving a merger that favors the interests of EMC and Dell at the expense of the minority stockholders.  The plaintiffs in the Jacobs action also brought suit against the Company, Dell, and Universal as alleged aiders and abettors.  Effective December 2, 2016, the parties entered into an agreement to resolve the Jacobs action, pursuant to which the plaintiff voluntarily dismissed the action with prejudice.  Under the operative amended complaint in the Ford action, the plaintiffs also brought suit against the Company and Dell for alleged breach of fiduciary duties to VMware, Inc. and its stockholders, and against the Company, Dell, and Universal for aiding and abetting the alleged breach of fiduciary duties by EMC's and VMware, Inc.'s directors.  Certain defendants filed motions to dismiss the amended complaint on June 21, 2016.  A hearing on those motions was held on February 3, 2017.  On May 2, 2017, the Court dismissed the amended complaint for failure to state a claim upon which relief could be granted and no appeal was taken.  All fifteen EMC merger-related lawsuits are now fully and finally resolved.

- added (2017-06-09):
[0001571996-17-000009:note_history:9]
Appraisal Proceedings — Holders of shares of Dell common stock who did not vote on September 12, 2013 in favor of the proposal to adopt the amended going-private transaction agreement and who properly demanded appraisal of their shares and who otherwise comply with the requirements of Section 262 of the Delaware General Corporate Law ("DGCL") are entitled to seek appraisal for, and obtain payment in cash for the judicially determined "fair value" (as defined pursuant to Section 262 of the DGCL) of, their shares in lieu of receiving the going-private transaction consideration.  Dell initially recorded a liability of $13.75 for each share with respect to which appraisal has been demanded and as to which the demand has not been withdrawn, together with interest at the statutory rate discussed below.  As of May 5, 2017 and February 3, 2017, this liability was approximately $129 million.  The Court of Chancery ruled that the fair value of the appraisal shares as of October 29, 2013, the date on which the going-private transaction became effective, was $17.62 per share.  This ruling would entitle the holders of the remaining 5,505,730 shares subject to the appraisal proceedings to $17.62 per share, plus interest at a statutory rate, compounded quarterly.  On November 21, 2016, the Court of Chancery entered final judgment in the appraisal action.  On November 22, 2016, Dell filed a notice of appeal to the Delaware Supreme Court.  That appeal is pending.  The Company believes it was adequately reserved for the appraisal proceedings as of May 5, 2017.

- changed (2017-06-09):
[0001571996-17-000009:note_history:10]
Securities Litigation — On May 22, 2014, a securities class action seeking compensatory damages was filed in the United States District Court for the Southern District of New York, captioned the City of Pontiac Employee Retirement System vs. Dell Inc. et. al. (Case No. 1:14-cv-03644).  The action names as defendants Dell Inc. and certain current and former executive officers, and alleges that Dell made false and misleading statements about Dell's business operations and products between February 22, 2012 and May 22, 2012, which resulted in artificially inflated stock prices.  The case was transferred to the United States District Court for the Western District of Texas, where the defendants filed a motion to dismiss.  On September 16, 2016, the Court denied the motion to dismiss and the case is proceeding with discovery.  The defendants believe the claims asserted are without merit and the risk of material loss is remote.
  (was, 2016-12-09, similarity 0.9989):
[0001571996-16-000021:note_history:10]
Securities Litigation — On May 22, 2014, a securities class action seeking compensatory damages was filed in the United States District Court for the Southern District of New York, captioned the City of Pontiac Employee Retirement System vs. Dell Inc. et. al. (Case No. 1:14-cv-03644).  The action names as defendants Dell Inc. and certain current and former executive officers, and alleges that Dell made false and misleading statements about Dell’s business operations and products between February 22, 2012 and May 22, 2012, which resulted in artificially inflated stock prices.  The case was transferred to the United States District Court for the Western District of Texas, where the defendants filed a motion to dismiss.  On September 16, 2016, the Court denied the motion to dismiss and the case is proceeding with discovery.  The defendants believe the claims asserted are without merit and the risk of material loss is remote.

- changed (2017-06-09):
[0001571996-17-000009:note_history:11]
As of May 5, 2017, the Company does not believe there is a reasonable possibility that a material loss exceeding the amounts already accrued for these or other proceedings or matters has been incurred.  However, since the ultimate resolution of any such proceedings and matters is inherently unpredictable, the Company's business, financial condition, results of operations, or cash flows could be materially affected in any particular period by unfavorable outcomes in one or more of these proceedings or matters.  Whether the outcome of any claim, suit, assessment, investigation, or legal proceeding, individually or collectively, could have a material adverse effect on the Company's business, financial condition, results of operations, or cash flows will depend on a number of variables, including the nature, timing, and amount of any associated expenses, amounts paid in settlement, damages, or other remedies or consequences.
  (was, 2016-12-09, similarity 0.9946):
[0001571996-16-000021:note_history:11]
As of October 28, 2016, the Company does not believe there is a reasonable possibility that a material loss exceeding the amounts already accrued for these or other proceedings or matters has been incurred.  However, since the ultimate resolution of any such proceedings and matters is inherently unpredictable, the Company's business, financial condition, results of operations, or cash flows could be materially affected in any particular period by unfavorable outcomes in one or more of these proceedings or matters.  Whether the outcome of any claim, suit, assessment, investigation, or legal proceeding, individually or collectively, could have a material adverse effect on the Company's business, financial condition, results of operations, or cash flows will depend on a number of variables, including the nature, timing, and amount of any associated expenses, amounts paid in settlement, damages, or other remedies or consequences.

- added (2017-06-09):
[0001571996-17-000009:note_history:12]
Indemnifications

- changed (2017-06-09):
[0001571996-17-000009:note_history:13]
In the ordinary course of business, the Company enters into contractual arrangements under which it may agree to indemnify the third party to such arrangements from any losses incurred relating to the services it performs on behalf of the Company or for losses arising from certain events as defined in the particular contract, such as litigation or claims relating to past performance.  Such indemnification obligations may not be subject to maximum loss clauses.  Historically, payments related to these indemnifications have not been material to the Company.
  (was, 2016-12-09, similarity 0.9833):
[0001571996-16-000021:note_history:13]
Indemnifications — In the ordinary course of business, the Company enters into contractual arrangements under which it may agree to indemnify the third party to such arrangements from any losses incurred relating to the services it performs on behalf of the Company or for losses arising from certain events as defined in the particular contract, such as litigation or claims relating to past performance.  Such indemnification obligations may not be subject to maximum loss clauses.  Historically, payments related to these indemnifications have not been material to the Company.

- added (2017-06-09):
[0001571996-17-000009:note_history:14]
In connection with the divestitures discussed in Note 3 of the Notes to the Condensed Consolidated Financial Statements, the Company has indemnified the purchasers of businesses for the occurrence of specified events.  The Company does not currently believe that contingent obligations to provide indemnification in connection with these divestitures will have a material adverse effect on the Company.

- added (2017-06-09):
[0001571996-17-000009:note_history:15]
Purchase Obligations

- added (2017-06-09):
[0001571996-17-000009:note_history:16]
The Company has contractual obligations to purchase goods or services, which specify significant terms, including fixed or minimum quantities to be purchased; fixed, minimum, or variable price provisions; and the approximate timing of the transaction.  As of May 5, 2017, the Company had $2,674 million, $260 million, and $432 million in purchase obligations for Fiscal 2018, Fiscal 2019, and Fiscal 2020 and thereafter, respectively.

- removed (2017-06-09):
[0001571996-16-000021:note_history:17]
Lease Commitments — The Company leases property and equipment, manufacturing facilities, and office space under non-cancelable leases. Certain of these leases obligate the Company to pay taxes, maintenance, and repair costs. At October 28, 2016, future minimum lease payments under these non-cancelable leases were as follows: $63 million in Fiscal 2017; $473 million in Fiscal 2018; $373 million in Fiscal 2019; $285 million in Fiscal 2020; $221 million in Fiscal 2021; and $963 million thereafter.

- removed (2017-06-09):
[0001571996-16-000021:note_history:18]
For the three and nine months ended October 28, 2016, rent expense under all leases totaled $110 million and $179 million, respectively. For the three and nine months ended October 30, 2015, rent expense under all leases totaled $33 million and $99 million, respectively.

- removed (2017-06-09):
[0001571996-16-000021:note_history:19]
Purchase Obligations — The Company has contractual obligations to purchase goods or services, which specify significant

- removed (2017-06-09):
[0001571996-16-000021:note_history:20]
terms, including fixed or minimum quantities to be purchased; fixed, minimum, or variable price provisions; and the

- removed (2017-06-09):
[0001571996-16-000021:note_history:21]
approximate timing of the transaction. As of October 28, 2016, the Company had $2,510 million, $137 million, and $112 million in purchase obligations for Fiscal 2017, Fiscal 2018, and Fiscal 2019 and thereafter, respectively.

- removed (2017-06-09):
[0001571996-16-000021:note_history:22]
The amended complaints in the Jacobs and Ford actions allege that EMC, as the majority stockholder of VMware, Inc. ("VMware"), and the individual defendants, who are directors of EMC, VMware, or both, breached their fiduciary duties to minority stockholders of VMware in connection with the proposed EMC merger by allegedly entering into or approving a merger that favors the interests of EMC and Dell at the expense of the minority stockholders. Under the amended complaint, the plaintiffs in the Jacobs action also brought suit against the Company, Dell, and Universal as alleged aiders and abettors.  Effective December 2, 2016, the parties entered into an agreement to resolve the Jacobs action, pursuant to which the plaintiff has voluntarily dismissed the action with prejudice.  Under the amended complaint, the plaintiffs in the Ford action have also brought suit against the Company and Dell for alleged breach of fiduciary duties to VMware and its stockholders, and against the Company, Dell, and Universal for aiding and abetting the alleged breach of fiduciary duties by EMC and VMware’s directors.  On November 17, 2015, the plaintiffs in the Ford action moved for a preliminary injunction and for expedited discovery.  Certain defendants filed motions to dismiss the amended complaint in the Ford action on February 26, 2016 and February 29, 2016.  On June 7, 2016, the plaintiffs in the Ford action filed a second amended complaint.  Certain defendants filed motions to dismiss the second amended complaint on June 21, 2016.  A hearing on the motions is scheduled for February 3, 2017.No trial date has been set in the Ford action, and the outcome is uncertain.

- removed (2017-06-09):
[0001571996-16-000021:note_history:23]
An adverse judgment for monetary damages on any of the EMC merger litigations could have an adverse effect on the Company’s operations.

- removed (2017-06-09):
[0001571996-16-000021:note_history:24]
Appraisal Proceedings — Holders of shares of Dell common stock who did not vote on September 12, 2013 in favor of the proposal to adopt the amended going-private transaction agreement and who properly demanded appraisal of their shares and who otherwise comply with the requirements of Section 262 of the Delaware General Corporate Law ("DGCL") are entitled to seek appraisal for, and obtain payment in cash for the judicially determined "fair value" (as defined pursuant to Section 262 of the DGCL) of, their shares in lieu of receiving the going-private transaction consideration.  Dell initially recorded a liability of $13.75 for each share with respect to which appraisal has been demanded and as to which the demand has not been withdrawn, together with interest at the statutory rate discussed below.  As of October 28, 2016, this liability was approximately $129 million, compared to approximately $593 million as of January 29, 2016, as the Company settled a substantial portion of the liability during the nine months ended October 28, 2016.  Also during the nine months ended October 28, 2016, as discussed further below, the Court of Chancery ruled that that the fair value of the appraisal shares as of October 29, 2013, the date on which the going-private transaction became effective, was $17.62 per share.  On November 21, 2016, the Chancery Court entered final judgment in the appraisal action.  On November 22, 2016, Dell filed a notice of appeal to the Delaware Supreme Court.  That appeal is pending.  The Company believes it was adequately reserved for the appraisal proceedings as of October 28, 2016.

- removed (2017-06-09):
[0001571996-16-000021:note_history:25]
Between October 29, 2013 and February 25, 2014, former Dell stockholders filed petitions in thirteen separate matters commencing appraisal proceedings in the Delaware Court of Chancery in which they seek a determination of the fair value of a total of approximately 38 million shares of Dell common stock plus interest, costs, and attorneys' fees.  These matters have been consolidated as In Re Appraisal of Dell (C.A. No. 9322-VCL).  The trial took place during the week of October 5, 2015.

- removed (2017-06-09):
[0001571996-16-000021:note_history:26]
The appraisal proceedings were conducted in accordance with the rules of the Delaware Court of Chancery.  In these proceedings, the Court of Chancery determined the fair value of the shares as to which appraisal has been properly demanded, exclusive of any element of value arising from the accomplishment or expectation of the going-private transaction.  Interest on such fair value from the effective time of the going-private transaction through the date of payment of the judgment will be compounded quarterly and will accrue at a per annum rate of 5% over the Federal Reserve discount rate (including any surcharge) as established from time to time.  Any payment in respect of the shares subject to appraisal rights will be required to be paid in cash.

- removed (2017-06-09):
[0001571996-16-000021:note_history:27]
The petitioners sought $28.61 per share, plus interest.  Dell, by contrast, believes that the fair value of Dell on the day the going-private transaction was completed was $12.68 per share.  The number of shares subject to appraisal demands, including shares held by those parties who have sought appraisal but not filed petitions, originally was 38,766,982.  By orders dated June 27 and September 10, 2014, and May 13, May 14, July 13 and July 28, 2015, the Court of Chancery dismissed claims of holders of approximately 2,530,322 shares for failure to comply with the statutory requirements for seeking appraisal.  On July 30, 2015, Dell moved for summary judgment seeking to dismiss claims of holders of an additional 30,730,930 shares (as well as a number of shares previously disqualified on other grounds) because those shares were voted in favor of the going-private transaction, and thus failed to comply with the statutory requirements for seeking appraisal.  On May 11, 2016, the Court of Chancery granted Dell's motion and dismissed the appraisal claims of the holders of the 30,730,930 shares, determining that they were entitled to the merger consideration without interest.  On May 18, 2016, the petitioners filed a motion for an equitable award of interest, which was denied by the Court on May 31, 2016.

- removed (2017-06-09):
[0001571996-16-000021:note_history:28]
The Court of Chancery ruled on May 31, 2016, that the fair value of shares as of October 29, 2013, the date on which the going-private transaction became effective, was $17.62 per share.  This ruling would entitle the holders of the remaining 5,505,730 shares to $17.62 per share, plus interest at a statutory rate, compounded quarterly.  On June 6, 2016, the petitioners filed a motion to amend the Court’s memorandum opinion, which was denied by the Court on June 16, 2016.  On November 21, 2016, the Chancery Court entered final judgment in the appraisal action.  On November 22, 2016, Dell filed a notice of appeal to the Delaware Supreme Court.  That appeal is pending.

- removed (2017-06-09):
[0001571996-16-000021:note_history:29]
On June 29, 2016, the Company, Dell, and certain funds affiliated with T. Rowe entered into a settlement agreement to resolve a dispute regarding the fair value and interest due on approximately 31,653,905 shares held by the funds, representing the 30,730,930 shares subject to claims that were dismissed on May 11, 2016 plus an additional 922,975 shares that had been previously disqualified on other grounds.  The terms of the T. Rowe settlement, among other matters, provide that, in exchange for a release and dismissal of all asserted claims, the Company pay $13.75 per share for a total sum of approximately $463 million, including interest.  On June 29, 2016, the Court entered an order approving the settlement, which was subsequently consummated.  The remaining 5,505,730 shares not subject to the settlement agreement remain subject to the appraisal proceedings.  On November 21, 2016, the Chancery Court entered final judgment in the appraisal action.  On November 22, 2016, Dell filed a notice of appeal to the Delaware Supreme Court.  That appeal is pending.


## us-gaap:CommitmentsAndContingenciesPolicyTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- added (2017-06-09):
[0001571996-17-000009:note_history:30]
The Company accrues a liability when it believes that it is both probable that a liability has been incurred and that it can reasonably estimate the amount of the loss.  The Company reviews these accruals at least quarterly and adjusts them to reflect ongoing negotiations, settlements, rulings, advice of legal counsel, and other relevant information.  To the extent new information is obtained and the Company's views on the probable outcomes of claims, suits, assessments, investigations, or legal proceedings change, changes in the Company's accrued liabilities would be recorded in the period in which such a determination is made.  For some matters, the amount of liability is not probable or the amount cannot be reasonably estimated and therefore accruals have not been made.

- removed (2017-06-09):
[0001571996-16-000021:note_history:31]
The Company accrues a liability when it believes that it is both probable that a liability has been incurred and that it can reasonably estimate the amount of the loss.


## dvmt:BasisOfPresentationMergersAcquisitionsAndDispositionsDisclosuresAndNewAccountingPronouncementsTextBlock (critical_accounting_estimates) — matched_by: no_current_note, score: 0.0

- removed (2017-06-09):
[0001571996-16-000021:note_history:32]
EMC MERGER TRANSACTION, OTHER TRANSACTIONS AND BASIS OF PRESENTATION

- removed (2017-06-09):
[0001571996-16-000021:note_history:33]
EMC Merger Transaction — On September 7, 2016, EMC Corporation, a Massachusetts corporation (“EMC”), became a wholly-owned subsidiary of Dell Technologies Inc. ("the Company") as a result of the merger of Universal Acquisition Co., a Delaware corporation and wholly-owned subsidiary of the Company (“Merger Sub”), with and into EMC, with EMC surviving as a wholly-owned subsidiary of the Company (the “EMC merger transaction”). The EMC merger transaction was effected pursuant to the Agreement and Plan of Merger, dated as of October 12, 2015, by and among the Company, Dell Inc., a Delaware corporation (“Dell”), Merger Sub, and EMC, as amended by the First Amendment to Agreement and Plan of Merger, dated as of May 16, 2016, by and among the Company, Dell, Merger Sub, and EMC.  See Note 3 of the Notes to the Unaudited Condensed Consolidated Financial Statements for additional information on the EMC merger transaction.

- removed (2017-06-09):
[0001571996-16-000021:note_history:34]
Divestitures — On March 27, 2016, Dell entered into a definitive agreement with NTT Data International L.L.C. to divest substantially all of Dell Services for cash consideration of approximately $3.0 billion.  On June 19, 2016, Dell entered into a definitive agreement with Francisco Partners and Elliot Management Corporation to divest substantially all of Dell Software Group ("DSG") for cash consideration of approximately $2.4 billion.  On September 12, 2016, EMC entered into a definitive agreement with OpenText Corporation to divest the Dell EMC Enterprise Content Division ("ECD") for cash consideration of approximately $1.6 billion.  In accordance with applicable accounting guidance, the results of Dell Services, DSG, and ECD are presented as discontinued operations in the Condensed Consolidated Statements of Income (Loss) and, as such, have been excluded from both continuing operations and segment results for all periods presented.  Further, the Company has reclassified the related assets and liabilities as held for sale in the accompanying Condensed Consolidated Statements of Financial Position.  See Note 4 of the Notes to the Unaudited Condensed Consolidated Financial Statements for additional information.

- removed (2017-06-09):
[0001571996-16-000021:note_history:35]
SecureWorks Initial Public Offering — On April 27, 2016, SecureWorks Corp. (“SecureWorks”) completed a registered underwritten initial public offering ("IPO") of its Class A common stock.  As of October 28, 2016, the Company held approximately 87.5% of the outstanding equity interest in SecureWorks.  The results of the SecureWorks operations are included in other businesses.  See Note 15 and Note 20 of the Notes to the Unaudited Condensed Consolidated Financial Statements for more information.

- removed (2017-06-09):
[0001571996-16-000021:note_history:36]
Going-Private Transaction — On October 29, 2013, Dell was acquired by Denali Holding Inc. (which changed its name to Dell Technologies Inc. on August 25, 2016) in a merger transaction pursuant to an agreement and plan of merger, dated as of February 5, 2013, as amended. Dell Technologies is a Delaware corporation owned by Michael S. Dell and a separate property trust for the benefit of Mr. Dell’s wife (the "MD Stockholders"), investment funds affiliated with Silver Lake Partners (the "SLP Stockholders"), investment funds affiliated with MSD Partners, L.P. (the "MSDC Stockholders"), members of Dell’s management, and other investors. Mr. Dell serves as Chairman and Chief Executive Officer of Dell Technologies and Dell.

- removed (2017-06-09):
[0001571996-16-000021:note_history:37]
Basis of Presentation — The accompanying Condensed Consolidated Financial Statements have been prepared in accordance with accounting principles generally accepted in the United States of America ("GAAP").  In the opinion of management, the accompanying Condensed Consolidated Financial Statements reflect all adjustments of a normal recurring nature considered necessary to fairly state the financial position of Dell Technologies Inc. (individually and together with its consolidated subsidiaries, "the Company" or "Dell Technologies") as of October 28, 2016 and January 29, 2016, the results of its operations and corresponding comprehensive income (loss) for the three and nine months ended October 28, 2016 and October 30, 2015, and its cash flows for the nine months ended October 28, 2016 and October 30, 2015.  The accompanying Unaudited Condensed Consolidated Financial Statements should be read in conjunction with the Audited Consolidated Financial Statements and accompanying Notes for the fiscal year ended January 29, 2016 ("Fiscal 2016") included in the proxy statement/prospectus dated June 6, 2016 forming part of the Company’s registration statement on Form S-4 (Registration No. 333 208524).

- removed (2017-06-09):
[0001571996-16-000021:note_history:38]
As a result of the EMC merger transaction completed on September 7, 2016, the Company's results for the fiscal periods reflected in the accompanying Unaudited Condensed Consolidated Financial Statements are not directly comparable.  The results of the businesses acquired in the EMC merger transaction (the "acquired businesses") are included in the consolidated results of Dell Technologies for the three and nine months ended October 28, 2016, and represent the results of the acquired businesses from September 7, 2016, the date of the EMC merger transaction, through October 28, 2016, the end of the third fiscal quarter of Dell Technologies. The results of the acquired businesses will be reported on the basis of Dell Technologies' fiscal year end to align with the fiscal periods for which Dell Technologies reports its results.

- removed (2017-06-09):
[0001571996-16-000021:note_history:39]
The standalone results of VMware, Inc. ("VMware") will continue to be publicly reported on a calendar year end basis through the end of December 31, 2016, after which VMware will effect a change in its year end, and will be publicly reported on the basis of Dell Technologies' fiscal year end beginning February 4, 2017, to align with the fiscal periods for which Dell Technologies reports its results.

- removed (2017-06-09):
[0001571996-16-000021:note_history:40]
The Dell Technologies balance sheet reflects the full consolidation of EMC's assets and liabilities as a result of the close of the EMC merger transaction on September 7, 2016.  The Company’s purchase accounting remains preliminary as contemplated by GAAP and, as a result, there may be upon further review future changes to the value and allocation of the acquired assets, liabilities assumed, associated amortization expense, and goodwill.  These changes may be material.

- removed (2017-06-09):
[0001571996-16-000021:note_history:41]
The preparation of financial statements in accordance with GAAP requires management to make estimates and assumptions that

- removed (2017-06-09):
[0001571996-16-000021:note_history:42]
affect the amounts reported in the Company's Condensed Consolidated Financial Statements and the accompanying Notes.  Actual results could differ materially from those estimates.  The results of operations, comprehensive income (loss), and cash flows for the three and nine months ended October 28, 2016 and October 30, 2015 are not necessarily indicative of the results to be expected for the full fiscal year or for any other fiscal period.

- removed (2017-06-09):
[0001571996-16-000021:note_history:43]
The Company's fiscal year is the 52- or 53-week period ending on the Friday nearest January 31.  The fiscal year ending February 3, 2017 ("Fiscal 2017") will be a 53-week period.


## us-gaap:BusinessDescriptionAndBasisOfPresentationTextBlock (critical_accounting_estimates) — matched_by: no_prior_note, score: 0.0

- added (2017-06-09):
[0001571996-17-000009:note_history:44]
BASIS OF PRESENTATION

- added (2017-06-09):
[0001571996-17-000009:note_history:45]
EMC Merger Transaction — On September 7, 2016, EMC Corporation, a Massachusetts corporation ("EMC"), became a wholly-owned subsidiary of Dell Technologies Inc. (the "Company") as a result of the merger of Universal Acquisition Co., a Delaware corporation and wholly-owned subsidiary of the Company ("Merger Sub"), with and into EMC, with EMC surviving as a wholly-owned subsidiary of the Company (the "EMC merger transaction").  See Note 2 of the Notes to the Condensed Consolidated Financial Statements for additional information on the EMC merger transaction.

- added (2017-06-09):
[0001571996-17-000009:note_history:46]
Divestitures — On November 2, 2016, the Company completed substantially all of the divestiture of Dell Services.  On October 31, 2016, the Company completed the divestiture of Dell Software Group ("DSG").  On January 23, 2017, the Company completed the divestiture of the Dell EMC Enterprise Content Division ("ECD").  In accordance with applicable accounting guidance, the results of Dell Services, DSG, and ECD are presented as discontinued operations in the Condensed Consolidated Statements of Income (Loss) and, as such, have been excluded from both continuing operations and segment results for the relevant periods.  See Note 3 of the Notes to the Condensed Consolidated Financial Statements for additional information.

- added (2017-06-09):
[0001571996-17-000009:note_history:47]
SecureWorks Initial Public Offering — On April 27, 2016, SecureWorks Corp. ("SecureWorks") completed a registered underwritten initial public offering ("IPO") of its Class A common stock.  The results of the SecureWorks operations are included in other businesses.  See Note 15 of the Notes to the Condensed Consolidated Financial Statements for more information.

- added (2017-06-09):
[0001571996-17-000009:note_history:48]
Basis of Presentation — The accompanying Unaudited Condensed Consolidated Financial Statements should be read in conjunction with the audited Consolidated Financial Statements and accompanying Notes filed with the U.S. Securities and Exchange Commission ("SEC") in the Company's Annual Report on Form 10-K for the fiscal year ended February 3, 2017 ("Fiscal 2017").  These Condensed Consolidated Financial Statements have been prepared in accordance with accounting principles generally accepted in the United States of America ("GAAP").  In the opinion of management, the accompanying Condensed Consolidated Financial Statements reflect all adjustments of a normal recurring nature considered necessary to fairly state the financial position of Dell Technologies Inc. (individually and together with its consolidated subsidiaries, the "Company" or "Dell Technologies") as of May 5, 2017 and February 3, 2017, the results of its operations and corresponding comprehensive income (loss), as well as its cash flows, for the three months ended May 5, 2017 and April 29, 2016.

- added (2017-06-09):
[0001571996-17-000009:note_history:49]
The preparation of financial statements in accordance with GAAP requires management to make estimates and assumptions that

- added (2017-06-09):
[0001571996-17-000009:note_history:50]
affect the amounts reported in the Condensed Consolidated Financial Statements and the accompanying Notes.  Actual results could differ materially from those estimates.  The results of operations, comprehensive income (loss), and cash flows for the three months ended May 5, 2017 and April 29, 2016 are not necessarily indicative of the results to be expected for the full fiscal year or for any other fiscal period.

- added (2017-06-09):
[0001571996-17-000009:note_history:51]
The Company's fiscal year is the 52- or 53-week period ending on the Friday nearest January 31.  The fiscal year ended February 3, 2017 ("Fiscal 2017") was a 53-week period while the fiscal year ending February 2, 2018 ("Fiscal 2018") will be a 52-week period.

- added (2017-06-09):
[0001571996-17-000009:note_history:52]
As a result of the EMC merger transaction completed on September 7, 2016, the Company's results for the fiscal periods reflected in these Condensed Consolidated Financial Statements are not directly comparable.  The results of the businesses acquired in the EMC merger transaction are included in the consolidated results of Dell Technologies for the three months ended May 5, 2017.  The Dell Technologies balance sheet reflects the full consolidation of EMC's assets and liabilities as a result of the closing of the EMC merger transaction on September 7, 2016.

- added (2017-06-09):
[0001571996-17-000009:note_history:53]
Unless the context indicates otherwise, references in these Notes to the Condensed Consolidated Financial Statements to "VMware" mean the VMware reportable segment, which reflects the operations of VMware, Inc. (NYSE: VMW) within Dell Technologies.  See Exhibit 99.1 filed with the Company's quarterly report on Form 10-Q for the quarterly period ended May 5, 2017 for information on the differences between VMware reportable segment results and VMware, Inc. results.

- added (2017-06-09):
[0001571996-17-000009:note_history:54]
Recently Issued Accounting Pronouncements

- added (2017-06-09):
[0001571996-17-000009:note_history:55]
Revenue from Contracts with Customers — In May 2014, the Financial Accounting Standards Board (the "FASB") issued amended guidance on the recognition of revenue from contracts with customers.  The objective of the new standard is to establish a single comprehensive model for entities to use in accounting for revenue arising from contracts with customers and will supersede substantially all of the existing revenue recognition guidance, including industry-specific guidance.  The new standard requires entities to recognize revenue when it transfers promised goods or services to customers in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services.  The new standard also provides guidance on the accounting for costs to fulfill or obtain a customer contract.  Further, the new standard requires additional disclosures to help enable users of the financial statements to better understand the nature, amount, timing, risks, and judgments related to revenue recognition and related cash flows from contracts with customers.

- added (2017-06-09):
[0001571996-17-000009:note_history:56]
In August 2015, the FASB approved a one-year deferral of the effective date of this standard.  Public entities are required to adopt the new standard for fiscal years, and interim periods within those years, beginning after December 15, 2017.  The new revenue standard may be applied retrospectively to each prior period presented (full retrospective method) or retrospectively with the cumulative effect of initially applying the standard recognized at the date of initial application in retained earnings (modified retrospective method).  The Company currently expects to adopt this standard retrospectively to each prior period presented for the fiscal year beginning February 3, 2018.

- added (2017-06-09):
[0001571996-17-000009:note_history:57]
While the Company is currently evaluating the financial and system impacts that the new standard will have on the Condensed Consolidated Financial Statements, the Company expects that unearned license revenue related to the sale of software licenses and related deliverables will decline upon adoption.  Currently, the Company defers revenue for certain software arrangements due to the absence of vendor specific objective evidence ("VSOE") of fair value for all or a portion of the deliverables.  Under the new standard, the Company will no longer be required to establish VSOE of fair value in order to account for elements in an arrangement as separate units of accounting, and will be able to record revenue upon satisfaction of each performance obligation.  Additionally, the Company expects the new standard to have an impact in the way the transaction price is allocated for certain non-standard warranties.  The new standard is expected to result in more of the aggregate transaction price related to the non-standard warranty being recorded as revenue upon delivery of the underlying product, because the Company will no longer defer revenue based on the separately stated price of the non-standard warranty provided under the contract.  The Company continues to make progress in assessing the impacts of the standard on the Condensed Consolidated Financial Statements and will continue to evaluate the impact of any changes to the standard or interpretations should they become available.

- added (2017-06-09):
[0001571996-17-000009:note_history:58]
Recognition and Measurement of Financial Assets and Financial Liabilities — In January 2016, the FASB issued amended guidance on Recognition and Measurement of Financial Assets and Financial Liabilities.  The standard addresses certain aspects of recognition, measurement, presentation, and disclosure of financial instruments.  Public entities must adopt the new guidance for fiscal years, and interim periods within those years, beginning after December 15, 2017.  The Company does not expect that the standard will have a material impact on the Condensed Consolidated Financial Statements.

- added (2017-06-09):
[0001571996-17-000009:note_history:59]
Leases — In February 2016, the FASB issued amended guidance on the accounting for leasing transactions.  The primary objective of this update is to increase transparency and comparability among organizations by recognizing lease assets and lease liabilities on the balance sheet and disclosing key information about leasing arrangements.  Public entities must adopt the new guidance for reporting periods beginning after December 15, 2018, with early adoption permitted.  Companies are required to use a modified retrospective approach for leases that exist or are entered into after the beginning of the earliest comparative period in the financial statements.  The Company is currently evaluating the impact that the standard will have on the Condensed Consolidated Financial Statements.

- added (2017-06-09):
[0001571996-17-000009:note_history:60]
Improvements to Employee Share-Based Payment Accounting — In March 2016, the FASB issued amended guidance on the accounting for employee share-based payments, including the accounting for income taxes and forfeitures, classification of awards as either equity or liabilities, and classification of cash flows.  The Company adopted this guidance during the three months ended May 5, 2017.  In accordance with the new guidance, excess tax benefits or deficiencies for stock-based compensation are now reflected as a component of the provision for income taxes on the Condensed Consolidated Statements of Income (Loss), whereas they were previously recorded as additional paid-in capital.  The Company has elected to continue to estimate expected forfeitures.  Additionally, the Company now presents excess tax benefits as an operating activity rather than a financing activity on the Condensed Consolidated Statements of Cash Flows, while the cash flows related to employee taxes paid for withheld shares are presented as a financing activity with prior periods adjusted accordingly.  The adoption of the amended guidance did not have a material impact on the Condensed Consolidated Financial Statements.  The prospective impact of the new standard will depend on the Company's stock price at the vesting or exercise dates of the awards and the number of awards that vest or are exercised in each period, but we do not expect the impact to be material in future periods.

- added (2017-06-09):
[0001571996-17-000009:note_history:61]
Measurement of Credit Losses on Financial Instruments — In June 2016, the FASB issued amended guidance which replaces the current incurred loss impairment methodology with a methodology that reflects expected credit losses and requires consideration of a broader range of reasonable and supportable information to inform credit loss estimates.  Public entities must adopt the new guidance for fiscal years beginning after December 15, 2019, including interim periods within those fiscal years.  All entities may adopt the amendments in the new standard as of fiscal years beginning after December 15, 2018, including interim periods within those fiscal years.  Earlier adoption is not permitted.  The Company is currently evaluating the impact that the standard will have on the Condensed Consolidated Financial Statements.

- added (2017-06-09):
[0001571996-17-000009:note_history:62]
Classification of Certain Cash Receipts and Cash Payments — In August 2016, the FASB issued amended guidance on the presentation and classification of eight specific cash flow issues with the objective of reducing existing diversity in practice.  Public entities must adopt the new guidance for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2017, with early adoption permitted.  Companies should reflect any adjustments on a retrospective basis, if practicable; otherwise, adoption is required to be applied as of the earliest date practicable.  The Company is currently evaluating the timing of adoption as well as the impact that the standard will have on the Condensed Consolidated Financial Statements.

- added (2017-06-09):
[0001571996-17-000009:note_history:63]
Intra-Entity Transfers of Assets Other Than Inventory — In October 2016, the FASB issued amended guidance on the accounting for income taxes.  The new guidance requires companies to recognize the income tax effects of intra-entity asset transfers, other than transfers of inventory, when the transfer occurs instead of when the asset is sold to a third party.  The new guidance should be applied on a modified-retrospective basis with the cumulative-effect adjustment to retained earnings as of the beginning of the period of adoption.  The Company early adopted this guidance during the three months ended May 5, 2017.  At adoption, approximately $84 million was reclassified from other non-current liabilities to retained earnings, resulting in a net credit to retained earnings.

- added (2017-06-09):
[0001571996-17-000009:note_history:64]
Simplifying the Test for Goodwill Impairment — In January 2017, the FASB issued amended guidance to simplify the subsequent measurement of goodwill by removing Step 2 of the goodwill impairment test.  Instead, under the amendments in the new guidance, an entity should perform its annual, or interim, goodwill impairment test by comparing the fair value of a reporting unit with its carrying amount.  An entity should recognize an impairment charge for the amount by which the carrying amount exceeds the reporting unit's fair value.  Public entities must adopt the new guidance in fiscal years beginning after December 15, 2019, with early adoption permitted.  The Company is currently evaluating the impact of the new guidance and timing of adoption, but does not expect that the standard will have an impact on its Condensed Consolidated Financial Statements.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: no_current_note, score: 0.0

- removed (2017-06-09):
[0001571996-16-000021:note_history:65]
— INTERIM UPDATE TO SUMMARY OF SIGNIFICANT ACCOUNTING POLICIES

- removed (2017-06-09):
[0001571996-16-000021:note_history:66]
The following interim update to the Company's significant accounting policies reflects the changes as a result of the EMC merger transaction.

- removed (2017-06-09):
[0001571996-16-000021:note_history:67]
Principles of Consolidation — These consolidated financial statements include the accounts of Dell Technologies and its wholly-owned subsidiaries, as well as the accounts of SecureWorks, VMware, and Pivotal Software Inc. ("Pivotal"), companies which are majority-owned by Dell Technologies.  All intercompany transactions have been eliminated.

- removed (2017-06-09):
[0001571996-16-000021:note_history:68]
On April 27, 2016, SecureWorks completed a registered underwritten IPO of its Class A common stock.  As of October 28, 2016, Dell Technologies held approximately 87.5% of the outstanding equity interest in SecureWorks.  Since the date of the IPO, the financial results of SecureWorks remain consolidated with those of Dell Technologies as Dell Technologies is the controlling stockholder of SecureWorks.  The portion of the results of operations of SecureWorks allocable to its other owners is shown as net income attributable to the non-controlling interests in the Condensed Consolidated Statements of Income (Loss), as an adjustment to net income attributable to Dell Technologies stockholders.  Additionally, the cumulative portion of the results of operations of SecureWorks allocable to its other owners, along with the interest in the net assets of SecureWorks attributable to those other owners, is shown as a component of non-controlling interests in the Condensed Consolidated Statements of Financial Position.

- removed (2017-06-09):
[0001571996-16-000021:note_history:69]
As of October 28, 2016, Dell Technologies held approximately 83.3% of the outstanding equity interest in VMware. VMware’s financial results have been consolidated with those of Dell Technologies as Dell Technologies is VMware’s controlling stockholder.  The results of VMware presented in the accompanying Condensed Consolidated Financial Statements represent the results of the acquired businesses from September 7, 2016, the date of the EMC merger transaction, through October 28, 2016, the end of the third fiscal quarter of Dell Technologies.  The portion of the results of operations of VMware allocable to its other owners is shown as net income attributable to the non-controlling interests in the Condensed Consolidated Statements of Income (Loss) as an adjustment to net income attributable to Dell Technologies stockholders.  Additionally, the cumulative portion of the results of operations of VMware allocable to its other owners, along with the interest in the net assets of VMware attributable to those other owners, is shown as a component of non-controlling interests in the Condensed Consolidated Statements of Financial Position as of October 28, 2016.

- removed (2017-06-09):
[0001571996-16-000021:note_history:70]
As of October 28, 2016, Dell Technologies held approximately 77.4% of the outstanding equity interest in Pivotal.  Pivotal’s financial results have been consolidated with those of Dell Technologies as Dell Technologies is Pivotal’s controlling stockholder.  The results of Pivotal presented in the accompanying Condensed Consolidated Financial Statements represent the results of the acquired businesses from September 7, 2016, the date of the EMC merger transaction, through October 28, 2016, the end of the third fiscal quarter of Dell Technologies.  A portion of the non-controlling interest in Pivotal is held by third parties in the form of a preferred equity instrument.  Accordingly, there is no net income attributable to this non-controlling interest in the Condensed Consolidated Statements of Income (Loss). The portion of the results of operations of Pivotal allocable to its other owners, whose interests are held in the form of common stock, and the interest in the net assets of Pivotal attributable to those other owners are shown as net income attributable to the non-controlling interest in the Condensed Consolidated Statements of Income (Loss) as an adjustment to net income attributable to Dell Technologies stockholders, and as component of non-controlling interests in the Condensed Consolidated Statements of Financial Position as of October 28, 2016, respectively.

- removed (2017-06-09):
[0001571996-16-000021:note_history:71]
Investments — All debt security investments with remaining maturities in excess of one year and substantially all equity and other securities are recorded as long-term investments in the Condensed Consolidated Statements of Financial Position. In comparison, debt security instruments with a remaining maturity shorter than one year are classified as short-term investments in the Condensed Consolidated Statements of Financial Position.

- removed (2017-06-09):
[0001571996-16-000021:note_history:72]
Unrealized gains and temporary loss positions on investments classified as available-for-sale are included within accumulated other comprehensive income (loss), net of any related tax effect.  Upon realization, those amounts are reclassified from accumulated other comprehensive income (loss) to interest and other, net.  Realized gains and losses and other-than-temporary impairments are reflected in the consolidated income statement in interest and other, net.  Investments accounted for under the cost method are measured at fair value initially.  Subsequently, when there is an indicator of impairment, the impairment is recognized.

- removed (2017-06-09):
[0001571996-16-000021:note_history:73]
Revenue Recognition — Net revenue primarily includes sales of hardware, services, software licenses, and peripherals.  The Company recognizes revenue for these products and services when it is realized or realizable and earned.  Revenue is recognized when persuasive evidence of an arrangement exists; delivery has occurred or services have been rendered; the Company's fee to its customer is fixed or determinable; and collection of the resulting receivable is reasonably assured.  This policy is applicable to all sales, including sales to resellers and end-users.

- removed (2017-06-09):
[0001571996-16-000021:note_history:74]
Revenue from third-party software sales and extended warranties for third-party products, for which the Company does not meet the criteria for gross revenue recognition, is recognized on a net basis.  All other revenue is recognized on a gross basis.

- removed (2017-06-09):
[0001571996-16-000021:note_history:75]
Services revenue and cost of services revenue captions in the Consolidated Statements of Income (Loss) include the Company's services, third-party software revenue, and support services related to the Company-owned software offerings.

- removed (2017-06-09):
[0001571996-16-000021:note_history:76]
The following summarizes the major terms of contractual relationships with customers and the manner in which the Company accounts for sales transactions.

- removed (2017-06-09):
[0001571996-16-000021:note_history:77]
Products

- removed (2017-06-09):
[0001571996-16-000021:note_history:78]
Product revenue consists of computer hardware, enterprise hardware, and software licenses sales that are delivered, sold as a subscription or sold on a consumption basis. Computer hardware and enterprise hardware include notebooks and desktop PCs, servers, storage hardware, and other hardware-related devices.  Software license sales include optional, stand-alone software applications. Software applications provide customers with resource management, backup and archiving, information security, information management and intelligence, data analytics and server virtualization capabilities.  Revenue from the sale of hardware products and systems is recognized when title and risk of loss pass to the customer.  Delivery is considered complete when products have been shipped to the Company's customer, title and risk of loss have transferred to the customer, and customer acceptance has been satisfied.  Customer acceptance is satisfied if acceptance is obtained from the customer, if all acceptance provisions lapse, or if the Company has evidence that all acceptance provisions have been satisfied.  Depending on the nature of the arrangement, software license sales is generally recognized upon shipment or electronic delivery.  For certain arrangements, revenue is recognized based on usage or ratably over the term of the arrangement.  License revenue from royalty arrangements is recognized upon either receipt of royalty reports or payments from third parties.

- removed (2017-06-09):
[0001571996-16-000021:note_history:79]
The Company records reductions to revenue for estimated customer sales returns, rebates, and certain other customer incentive programs.  These reductions to revenue are made based upon reasonable and reliable estimates that are determined by historical experience, contractual terms, and current conditions.  The primary factors affecting the Company's accrual for estimated customer returns include estimated return rates as well as the number of units shipped that have a right of return that has not expired as of the balance sheet date.  If returns cannot be reliably estimated, revenue is not recognized until a reliable estimate can be made or the return right lapses.

- removed (2017-06-09):
[0001571996-16-000021:note_history:80]
The Company sells its products directly to customers as well as through other distribution channels, such as retailers, distributors, and resellers.  The Company recognizes revenue on these sales when the reseller has economic substance apart from the Company; any credit risk has been identified and quantified; title and risk of loss have passed to the sales channel; the fee paid to the Company is not contingent upon resale or payment by the end user; and the Company has no further obligations related to bringing about resale or delivery.

- removed (2017-06-09):
[0001571996-16-000021:note_history:81]
Sales through the Company's distribution channels are primarily made under agreements allowing for limited rights of return, price protection, rebates, and marketing development funds.  The Company has generally limited return rights through contractual caps or has an established selling history for these arrangements.  Therefore, there is sufficient data to establish reasonable and reliable estimates of returns for the majority of these sales.  To the extent price protection or return rights are not limited and a reliable estimate cannot be made, all of the revenue and related costs are deferred until the product has been sold to the end-user or the rights expire.  The Company records estimated reductions to revenue or an expense for distribution channel programs at the later of the offer or the time revenue is recognized.

- removed (2017-06-09):
[0001571996-16-000021:note_history:82]
The Company defers the cost of shipped products awaiting revenue recognition until revenue is recognized.

- removed (2017-06-09):
[0001571996-16-000021:note_history:83]
Services

- removed (2017-06-09):
[0001571996-16-000021:note_history:84]
Services revenue consists of hardware and software maintenance, installation services, professional services, training revenue, third-party software revenue, and software sold as a service.  The Company recognizes revenue from fixed-price support or maintenance contracts sold for both hardware and software ratably over the contract period and recognizes the costs associated with these contracts as incurred.  For sales of extended warranties with a separate contract price, the Company defers revenue equal to the separately stated price.  Revenue associated with undelivered elements is deferred and recorded when delivery occurs or services are provided. Revenue from extended warranty and service contracts, for which the Company is obligated to perform, is recorded as deferred revenue and subsequently recognized over the term of the contract on a straight-line basis or when the service is completed and the costs associated with these contracts are recognized as incurred.

- removed (2017-06-09):
[0001571996-16-000021:note_history:85]
Multiple Deliverables

- removed (2017-06-09):
[0001571996-16-000021:note_history:86]
When an arrangement has more than one element, such as hardware, software, and services contained in a single arrangement, the Company first allocates revenue based upon the relative selling price into two categories: (1) non-software components, such as hardware and any hardware-related items, such as required system software that functions with the hardware to deliver the essential functionality of the hardware and related post-contract customer support, software as a service subscriptions and other services; and (2) software components, such as optional software applications and related items, such as post-contract customer support and other services. The Company then allocates revenue within the non-software category to each element based upon its relative selling price using a hierarchy of vendor-specific objective evidence (“VSOE”), third-party evidence of selling price (“TPE”), or estimated selling prices (“ESP”), if VSOE or TPE does not exist. The Company allocates revenue within the software category to the undelivered elements based upon their fair value using VSOE, with the residual revenue allocated to the delivered elements. If the Company cannot objectively determine the VSOE of the fair value of any undelivered software element, it defers revenue for all software components until all elements are delivered and services have been performed, until fair value can objectively be determined for any remaining undelivered elements, or until software maintenance is the only undelivered element, in which case revenue is recognized over the maintenance term for all software elements.

- removed (2017-06-09):
[0001571996-16-000021:note_history:87]
The Company allocates the amount of revenue recognized for delivered elements to the amount that is not subject to forfeiture or refund or contingent on the future delivery of products or services.

- removed (2017-06-09):
[0001571996-16-000021:note_history:88]
Customers under software maintenance agreements are entitled to receive updates and upgrades on a when-and-if-available basis, and various types of technical support based on the level of support purchased. In the event specific features, functionality, entitlements, or the release version of an upgrade or new product have been announced but not delivered, and customers will receive that upgrade or new product as part of a current software maintenance contract, a specified upgrade is deemed created and product revenues are deferred on purchases made after the announcement date until delivery of the upgrade or new product. The amount and elements to be deferred are dependent on whether the Company has established VSOE of fair value for the upgrade or new product.

- removed (2017-06-09):
[0001571996-16-000021:note_history:89]
Other

- removed (2017-06-09):
[0001571996-16-000021:note_history:90]
The Company records revenue from the sale of equipment under sales-type leases as product revenue in an amount equal to the present value of minimum lease payments at the inception of the lease.  Sales-type leases also produce financing income, which is included in net revenue in the Condensed Consolidated Statements of Income (Loss) and is recognized at consistent rates of return over the lease term.  Revenue from operating leases is recognized over the lease period. The Company also offers qualified customers revolving credit lines for the purchase of products and services offered by the Company.  Financing income attributable to these revolving loans is recognized in net revenue on an accrual basis.

- removed (2017-06-09):
[0001571996-16-000021:note_history:91]
The Company accrues for the estimated costs of systems’ warranty at the time of sale.  Systems’ warranty costs are estimated based upon historical experience and specific identification of systems’ requirements.

- removed (2017-06-09):
[0001571996-16-000021:note_history:92]
The Company reports revenue net of any revenue-based taxes assessed by governmental authorities that are imposed on and concurrent with specific revenue-producing transactions.

- removed (2017-06-09):
[0001571996-16-000021:note_history:93]
Deferred Revenue — Deferred revenue represents amounts received in advance for extended warranty services, deferred hardware, software maintenance, prepaid professional services, and unearned license fees, which are recognized ratably over the contract term as either product or services revenue depending on the nature of the item.  The Company also has deferred revenue related to internally-developed software offerings, and deferred profit on third-party software offerings, which are generally recognized ratably over the contract term as either product or services revenue depending on the nature of the item.

- removed (2017-06-09):
[0001571996-16-000021:note_history:94]
Research and Development — Research and development (“R&D”) costs are expensed as incurred. R&D costs include salaries and benefits and other personnel-related costs associated with product development.  Also included in R&D expenses are infrastructure costs, which consist of equipment and material costs, facilities-related costs, depreciation expense, and intangible asset amortization.

- removed (2017-06-09):
[0001571996-16-000021:note_history:95]
Capitalized Software Development Costs — In accordance with the applicable accounting standards, software development costs related to the development of new product offerings are capitalized subsequent to the establishment of technological feasibility, which is demonstrated by the completion of a detailed program design or working model, if no program design is completed. GAAP requires that annual amortization expense of the capitalized software development costs be the greater of the amounts computed using the ratio of gross revenue to a product's total current and anticipated revenues, or the straight-line method over the product's remaining estimated economic life. Capitalized costs are amortized over periods ranging from eighteen months to two years which represents the product's estimated economic life.

- removed (2017-06-09):
[0001571996-16-000021:note_history:96]
Amounts capitalized for the period from September 7, 2016 through October 28, 2016 were $85 million, and are included in other non-current assets, net in the accompanying Condensed Consolidated Statements of Financial Position.  Amortization expense for the period from September 7, 2016 through October 28, 2016 was $0.4 million.  Prior to the EMC merger transaction, there were no significant capitalized software development costs specific to the legacy businesses of Dell Technologies Inc.

- removed (2017-06-09):
[0001571996-16-000021:note_history:97]
Recently Issued Accounting Pronouncements

- removed (2017-06-09):
[0001571996-16-000021:note_history:98]
Revenue from Contracts with Customers — In May 2014, the Financial Accounting Standards Board ("FASB") issued amended guidance on the recognition of revenue from contracts with customers.  The objective of the new standard is to establish a single comprehensive model for entities to use in accounting for revenue arising from contracts with customers and will supersede most of the existing revenue recognition guidance, including industry-specific guidance.  The new standard requires entities to recognize revenue when it transfers promised goods or services to customers in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services. In August 2015, the FASB approved a one-year deferral of the effective date of this standard.  Public entities are required to adopt the new standard for fiscal years, and interim periods within those years, beginning after December 15, 2017.  The new revenue standard may be applied retrospectively to each prior period presented or retrospectively with the cumulative effect recognized as of the date of adoption.  The Company is currently evaluating the method of adoption and the impact that the new standard will have on the Consolidated Financial Statements.

- removed (2017-06-09):
[0001571996-16-000021:note_history:99]
Presentation of Debt Issuance Costs — In April 2015, the FASB issued amended guidance which changes the classification of debt issuance costs in the Consolidated Statements of Financial Position.  The new guidance requires debt issuance costs to be presented as a direct deduction from the carrying amount of the related debt liability consistent with the presentation of debt discounts, rather than as an asset.  The guidance related to recognition and measurement of debt issuance costs remains unchanged.  The Company implemented the new presentation in the nine months ended October 28, 2016 on a retrospective basis, and except for the reclassification of debt issuance costs of $128 million as of January 29, 2016 in the accompanying Condensed Consolidated Statements of Financial Position, there was no other impact on the Consolidated Financial Statements.

- removed (2017-06-09):
[0001571996-16-000021:note_history:100]
Recognition and Measurement of Financial Assets and Financial Liabilities — In January 2016, the FASB issued amended guidance on Recognition and Measurement of Financial Assets and Financial Liabilities.  The standard addresses certain aspects of recognition, measurement, presentation, and disclosure of financial instruments.  Public entities must adopt the new guidance for fiscal years, and interim periods within those years, beginning after December 15, 2017.  The Company is currently evaluating the impact that the standard will have on the Consolidated Financial Statements.

- removed (2017-06-09):
[0001571996-16-000021:note_history:101]
Leases — In February 2016, the FASB issued amended guidance on the accounting for leasing transactions.  The primary objective of this update is to increase transparency and comparability among organizations by recognizing lease assets and lease liabilities on the balance sheet and disclosing key information about leasing arrangements.  Public entities must adopt the new guidance for reporting periods beginning after December 15, 2018, with early adoption permitted.  Companies are required to use a modified retrospective approach for leases that exist or are entered into after the beginning of the earliest comparative period in the financial statements.  The Company is currently evaluating the impact that the standard will have on the Consolidated Financial Statements.

- removed (2017-06-09):
[0001571996-16-000021:note_history:102]
Improvements to Employee Share-Based Payment Accounting — In March 2016, the FASB issued amended guidance on the accounting for employee share-based payments.  The topics that were amended in the update involve several aspects of the accounting for share-based payment transactions, including the income tax consequences, classification of awards as either equity or liabilities, and classification on the statement of cash flows.  Public entities must adopt the new guidance for fiscal years, and interim periods within those years, beginning after December 2016.  The Company is currently evaluating the impact that the standard will have on the Consolidated Financial Statements.

- removed (2017-06-09):
[0001571996-16-000021:note_history:103]
Measurement of Credit Losses on Financial Instruments — In June 2016, the FASB issued amended guidance which replaces the current incurred loss impairment methodology with a methodology that reflects expected credit losses and requires consideration of a broader range of reasonable and supportable information to inform credit loss estimates.  Public entities must adopt the new guidance for fiscal years beginning after December 15, 2019, including interim periods within those fiscal years. All entities may adopt the amendments in the new standard as of fiscal years beginning after December 15, 2018, including interim periods within those fiscal years.  However, earlier adoption is not permitted.  The Company is currently evaluating the impact that the standard will have on the Consolidated Financial Statements.

- removed (2017-06-09):
[0001571996-16-000021:note_history:104]
Classification of Certain Cash Receipts and Cash Payments — In August 2016, the FASB issued amended guidance on the presentation and classification of eight specific cash flow issues with the objective of reducing existing diversity in practice.  Public entities must adopt the new guidance for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2017, with early adoption permitted.  Companies should reflect any adjustments on a retrospective basis, if practicable, otherwise adoption is required to be applied as of the earliest date practicable.  The Company is currently evaluating the timing of adoption as well as the impact that the standard will have on the Consolidated Financial Statements.

- removed (2017-06-09):
[0001571996-16-000021:note_history:105]
Intra-Entity Transfers of Assets Other Than Inventory — In October 2016, the FASB issued amended guidance on the accounting for income taxes.  The new guidance requires companies to recognize the income tax effects of intra-entity asset transfers, other than transfers of inventory, when the transfer occurs instead of when the asset is sold to a third party, as current GAAP requires.  Public entities must adopt the new guidance for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2017, with early adoption permitted at the beginning of an annual period.  The new guidance is required to be applied retrospectively with the cumulative effect recognized as of the beginning of the period of adoption. The Company is currently evaluating the timing of adoption as well as the impact that the standard will have on the Consolidated Financial Statements.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2017-06-09):
[0001571996-17-000009:note_history:106]
|  | May 5, 2017 |  | February 3, 2017 |
|  | (in millions) |
| Secured Debt |  |  |  |
| Structured financing debt | $ | 3,869 |  |  | $ | 3,464 |  |
| Senior Secured Credit Facilities: |  |  |  |
| 3.50% Term Loan B Facility due September 2023 | 5,473 |  |  | 4,987 |  |
| 3.00% Term Loan A-1 Facility due December 2018 | 599 |  |  | 600 |  |
| 3.25% Term Loan A-2 Facility due September 2021 | 3,827 |  |  | 3,876 |  |
| 3.00% Term Loan A-3 Facility due December 2018 | 1,800 |  |  | 1,800 |  |
| 3.00% Revolving Credit Facility due September 2021 | 375 |  |  | 375 |  |
| First Lien Notes: |  |  |  |
| 3.48% due June 2019 | 3,750 |  |  | 3,750 |  |
| 4.42% due June 2021 | 4,500 |  |  | 4,500 |  |
| 5.45% due June 2023 | 3,750 |  |  | 3,750 |  |
| 6.02% due June 2026 | 4,500 |  |  | 4,500 |  |
| 8.10% due June 2036 | 1,500 |  |  | 1,500 |  |
| 8.35% due June 2046 | 2,000 |  |  | 2,000 |  |
| Unsecured Debt |  |  |  |
| Unsecured Notes and Debentures: |  |  |  |
| 5.65% due April 2018 | 500 |  |  | 500 |  |
| 5.875% due June 2019 | 600 |  |  | 600 |  |
| 4.625% due April 2021 | 400 |  |  | 400 |  |
| 7.10% due April 2028 | 300 |  |  | 300 |  |
| 6.50% due April 2038 | 388 |  |  | 388 |  |
| 5.40% due September 2040 | 265 |  |  | 265 |  |
| Senior Notes: |  |  |  |
| 5.875% due June 2021 | 1,625 |  |  | 1,625 |  |
| 7.125% due June 2024 | 1,625 |  |  | 1,625 |  |
| EMC Notes: |  |  |  |
| 1.875% due June 2018 | 2,500 |  |  | 2,500 |  |
| 2.650% due June 2020 | 2,000 |  |  | 2,000 |  |
| 3.375% due June 2023 | 1,000 |  |  | 1,000 |  |
| Other |  |  |  |
| 3.42% Margin Loan Facility due April 2022 | 2,000 |  |  | — |  |
| 2.53% Margin Bridge Facility due September 2017 | — |  |  | 2,500 |  |
| 2.75% VMware Note Bridge Facility due September 2017 | 1,500 |  |  | 1,500 |  |
| Other | 82 |  |  | 51 |  |
| Total debt, principal amount | $ | 50,728 |  |  | $ | 50,356 |  |
| Unamortized discount, net of unamortized premium | (293 | ) |  | (284 | ) |
| Debt issuance costs | (645 | ) |  | (682 | ) |
| Total debt, carrying value | $ | 49,790 |  |  | $ | 49,390 |  |
| Total short-term debt, carrying value | $ | 4,842 |  |  | $ | 6,329 |  |
| Total long-term debt, carrying value | $ | 44,948 |  |  | $ | 43,061 |  |

- added (2017-06-09):
[0001571996-17-000009:note_history:107]
During the three months ended May 5, 2017, the Company refinanced the Term Loan B Facility to reduce the interest rate margin by 0.75% and to increase the outstanding principal amount by $500 million.  The Company applied the proceeds from the Term Loan B Facility refinancing to repay $500 million principal amount of the Margin Bridge Facility, without premium or penalty, and accrued and unpaid interest thereon.  Additionally, during the three months ended May 5, 2017, the Company issued the Margin Loan Facility in the principal amount of $2.0 billion, and used the proceeds of the new facility to extinguish the Margin Bridge Facility, without premium or penalty.

- changed (2017-06-09):
[0001571996-17-000009:note_history:108]
Senior Secured Credit Facilities — At the closing of the EMC merger transaction on September 7, 2016, the Company entered into a credit agreement that provides for senior secured credit facilities (the "Senior Secured Credit Facilities") in the aggregate principal amount of $17.6 billion comprising (a) term loan facilities and (b) a senior secured Revolving Credit Facility, which includes capacity for up to $0.5 billion of letters of credit and for borrowings of up to $0.4 billion under swing-line loans.  As of May 5, 2017, available borrowings under the Revolving Credit Facility totaled $2.7 billion.  The Senior Secured Credit Facilities provide that the borrowers have the right at any time, subject to customary conditions, to request incremental term loans or incremental revolving commitments.
  (was, 2016-12-09, similarity 0.667):
[0001571996-16-000021:note_history:108]
Senior Secured Credit Facilities — At the closing of the EMC merger transaction on September 7, 2016, the Company entered into a credit agreement (the "Senior Secured Credit Agreement") that provides for senior secured credit facilities (the “Senior Secured Credit Facilities”) in the aggregate principal amount of $17.575 billion comprising (a) term loan facilities and (b) a senior secured Revolving Credit Facility, which includes capacity for up to $0.5 billion of letters of credit and for borrowings of up to $0.4 billion under swing-line loans. Dell International L.L.C. ("Dell International") and EMC are the borrowers under the Senior Secured Credit Facilities.  As of October 28, 2016, available borrowings under the Revolving Credit Facility totaled $1.6 billion.  The Senior Secured Credit Facilities provide that the borrowers have the right at any time, subject to customary conditions, to request incremental term loans or incremental revolving commitments in an aggregate principal amount of up to (a) the greater of (i) $10.0 billion and (ii) 100% of Consolidated EBITDA (as defined in the Senior Secured Credit Agreement) plus (b) an amount equal to voluntary prepayments of the term loan facilities and the revolving credit facility, subject to certain requirements, plus (c) an additional unlimited amount subject to a pro forma net first lien leverage ratio of 3.25:1.0.

- changed (2017-06-09):
[0001571996-17-000009:note_history:109]
Borrowings under the Senior Secured Credit Facilities bear interest at a rate per annum equal to an applicable margin, plus, at the borrowers' option, either (a) a base rate, which, under the Term Loan B Facility, is subject to an interest rate floor of 1.75% per annum, and under all other borrowings is subject to an interest rate floor of 0% per annum, or (b) a London interbank offered rate ("LIBOR"), which, under the Term Loan B Facility, is subject to an interest rate floor of 0.75% per annum, and under all other borrowings is subject to an interest rate floor of 0% per annum.  Interest is payable, in the case of loans bearing interest based on LIBOR, at the end of each interest period (but at least every three months), in arrears and, in the case of loans bearing interest based on the base rate, quarterly in arrears.
  (was, 2016-12-09, similarity 0.6817):
[0001571996-16-000021:note_history:109]
Borrowings under the Senior Secured Credit Facilities bear interest at a rate per annum equal to an applicable margin, plus, at the borrowers’ option, either (a) a base rate, which, under the Term Loan B Facility, is subject to an interest rate floor of 1.75% per annum, and under all other borrowings is subject to an interest rate floor of 0% per annum, or (b) a London interbank offered rate ("LIBOR"), which, under the Term Loan B Facility, is subject to an interest rate floor of 0.75% per annum, and under all other borrowings is subject to an interest rate floor of 0% per annum. The applicable margin under the Term Loan B Facility is subject to reduction based on a first lien leverage ratio test. The applicable margins under the Term Loan A-1 Facility, the Term Loan A-2 Facility, the Term Loan A-3 Facility and the Revolving Credit Facility vary based upon a corporate ratings-based pricing schedule.

- added (2017-06-09):
[0001571996-17-000009:note_history:110]
The Term Loan A-1 Facility, the Term Loan A-3 Facility, and the Revolving Credit Facility have no amortization.  The Term Loan A-2 Facility amortizes in equal quarterly installments in aggregate annual amounts equal to 5% of the original principal amount in each of the first two years after the closing date of the EMC merger transaction, 10% of the original principal amount in each of the third and fourth years after the closing date of the EMC merger transaction, and 70% of the original principal amount in the fifth year after the closing date of the EMC merger transaction.  The Term Loan B Facility amortizes in equal quarterly installments in aggregate annual amounts equal to 1% of the original principal amount.  The Term Loan A-1 and Term Loan A-3 Facilities require the borrowers to prepay outstanding borrowings under these facilities with 100% of the net cash proceeds of certain non-ordinary course asset sales or dispositions.  The borrowers may voluntarily repay outstanding loans under the term loan facilities and the Revolving Credit Facility at any time without premium or penalty, other than customary "breakage" costs.

- added (2017-06-09):
[0001571996-17-000009:note_history:111]
All obligations of the borrowers under the Senior Secured Credit Facilities and certain swap agreements, cash management arrangements, and certain letters of credit provided by any lender or agent party to the Senior Secured Credit Facilities or any of its affiliates and certain other persons are secured by (a) a first-priority security interest in certain tangible and intangible assets of the borrowers and the guarantors and (b) a first-priority pledge of 100% of the capital stock of the borrowers, Dell Inc., an indirect wholly-owned subsidiary of Dell Technologies ("Dell"), and each wholly-owned material restricted subsidiary of the borrowers and the guarantors, in each case subject to certain thresholds, exceptions, and permitted liens.

- added (2017-06-09):
[0001571996-17-000009:note_history:112]
During the three months ended May 5, 2017, the Company refinanced the Term Loan B Facility to reduce the interest rate margin by 0.75% and to increase the outstanding principal amount by $500 million.

- changed (2017-06-09):
[0001571996-17-000009:note_history:113]
First Lien Notes — The senior secured notes (collectively, the "First Lien Notes") were issued on June 1, 2016 in an aggregate principal amount of $20.0 billion.  Interest on these borrowings is payable semiannually.  The First Lien Notes are secured, on a pari passu basis with the Senior Secured Credit Facilities, on a first-priority basis by substantially all of the tangible and intangible assets of the issuers and guarantors that secure obligations under the Senior Secured Credit Facilities, including pledges of all capital stock of the issuers, of Dell, and of certain wholly-owned material subsidiaries of the issuers and the guarantors, subject to certain exceptions.
  (was, 2016-12-09, similarity 0.7115):
[0001571996-16-000021:note_history:113]
First Lien Notes — The senior secured notes (collectively, the “First Lien Notes”) were issued on June 1, 2016 in an aggregate principal amount of $20.0 billion.  As of the closing of the EMC merger transaction, Dell International and EMC are the co-issuers of the First Lien Notes.  The First Lien Notes are guaranteed, subject to certain exceptions, on a joint and several basis by Dell Technologies, Denali Intermediate, Dell, and Denali Intermediate’s direct and indirect wholly-owned material domestic subsidiaries that guarantee the Senior Secured Credit Facilities.  The First Lien Notes are secured, on a pari passu basis with the Senior Secured Credit Facilities, on a first-priority basis by substantially all of the tangible and intangible assets of the issuers and guarantors that secure obligations under the Senior Secured Credit Facilities, including pledges of all capital stock of the issuers, of Dell, and of certain wholly-owned material subsidiaries of the issuers and the guarantors, subject to certain exceptions.

- added (2017-06-09):
[0001571996-17-000009:note_history:114]
The Company has agreed to use commercially reasonable efforts to register with the SEC notes having terms substantially identical to the terms of the First Lien Notes as part of an offer to exchange such registered notes for the First Lien Notes.  The Company will be obligated to pay additional interest on the First Lien Notes if it fails to consummate such an exchange offer within five years after the closing date of the EMC merger transaction.

- added (2017-06-09):
[0001571996-17-000009:note_history:115]
Senior Notes — The senior unsecured notes (collectively, the "Senior Notes") were issued on June 22, 2016 in an aggregate principal amount of $3.25 billion.  Interest on these borrowings is payable semiannually.

- added (2017-06-09):
[0001571996-17-000009:note_history:116]
EMC Notes — On September 7, 2016, EMC had outstanding $2.5 billion aggregate principal amount of its 1.875% Notes due June 2018, $2.0 billion aggregate principal amount of its 2.650% Notes due June 2020 and $1.0 billion aggregate principal amount of its 3.375% Notes due June 2023 (collectively, the "EMC Notes").  Interest on these borrowings is payable semiannually.  The EMC Notes remain outstanding following the closing of the EMC merger transaction.

- added (2017-06-09):
[0001571996-17-000009:note_history:117]
Margin Loan Facility — During the three months ended May 5, 2017, the Company issued the Margin Loan Facility in an aggregate principal amount of $2.0 billion.  VMW Holdco LLC, a wholly owned subsidiary of EMC, is the borrower under the Margin Loan Facility, which is secured by 60 million shares of Class B common stock of VMware, Inc. and 20 million shares of Class A common stock of VMware, Inc.  Loans under the Margin Loan Facility bear interest at a rate per annum payable, at the borrower's option, either at (a) a base rate plus 1.25% per annum or (b) a LIBOR-based rate plus 2.25% per annum.  Interest under the Margin Loan Facility is payable quarterly.

- added (2017-06-09):
[0001571996-17-000009:note_history:118]
The Margin Loan Facility will mature in April 2022.  The borrower may voluntarily repay outstanding loans under the Margin Loan Facility at any time without premium or penalty, other than customary "breakage" costs, subject to certain minimum threshold amounts for prepayment.

- changed (2017-06-09):
[0001571996-17-000009:note_history:119]
Margin Bridge Facility — On September 7, 2016, Merger Sub and EMC entered into a credit agreement providing for a senior secured margin bridge facility in an aggregate principal amount of $2.5 billion (the "Margin Bridge Facility").
  (was, 2016-12-09, similarity 0.67):
[0001571996-16-000021:note_history:119]
Margin Bridge Facility — On September 7, 2016, Merger Sub and EMC entered into a credit agreement providing for a senior secured margin bridge facility in an aggregate principal amount of $2.5 billion (the “Margin Bridge Facility”).  EMC is the borrower under the Margin Bridge Facility, which is secured solely by 77,033,442 shares of Class B common stock of VMware and any proceeds thereof.

- added (2017-06-09):
[0001571996-17-000009:note_history:120]
During the three months ended May 5, 2017, the Company separately applied the proceeds from the Term Loan B Facility refinancing and the issuance of the Margin Loan Facility to extinguish the Margin Bridge Facility, without premium or penalty.

- changed (2017-06-09):
[0001571996-17-000009:note_history:121]
VMware Note Bridge Facility — On September 7, 2016, Merger Sub and EMC entered into a credit agreement providing for a senior secured note bridge facility in an aggregate principal amount of $1.5 billion (the "VMware Note Bridge Facility").  The VMware Note Bridge Facility is secured solely by certain intercompany notes in an aggregate principal amount of $1.5 billion issued by VMware, Inc. that are payable to EMC, and the proceeds thereof.
  (was, 2016-12-09, similarity 0.8447):
[0001571996-16-000021:note_history:121]
VMware Note Bridge Facility — On September 7, 2016, Merger Sub and EMC entered into a credit agreement providing for a senior secured note bridge facility in an aggregate principal amount of $1.5 billion (the “VMware Note Bridge Facility”).  EMC is the borrower under the VMware Note Bridge Facility, which is secured solely by certain intercompany notes in an aggregate principal amount of $1.5 billion issued by VMware that are payable to EMC, and the proceeds thereof.

- added (2017-06-09):
[0001571996-17-000009:note_history:122]
The VMware Note Bridge Facility has no amortization.  The borrower is required to prepay outstanding borrowings under the VMware Note Bridge Facility with 100% of the net cash proceeds of any asset sale or other disposition of the pledged VMware, Inc. promissory notes.  The borrower may voluntarily repay outstanding loans under the VMware Note Bridge Facility at any time without premium or penalty, other than customary "breakage" costs, subject to certain minimum threshold amounts for prepayment.

- changed (2017-06-09):
[0001571996-17-000009:note_history:123]
Structured Financing Debt — As of May 5, 2017 and February 3, 2017, the Company had $3.9 billion and $3.5 billion, respectively, in outstanding structured financing debt, which was primarily related to the fixed-term lease and loan securitization programs and the revolving loan securitization programs.  See Note 6 and Note 8 of the Notes to the Condensed Consolidated Financial Statements for further discussion of the structured financing debt and the interest rate swap agreements that hedge a portion of that debt.
  (was, 2016-12-09, similarity 0.956):
[0001571996-16-000021:note_history:123]
Structured Financing Debt — As of October 28, 2016 and January 29, 2016, the Company had $3.4 billion and $3.4 billion, respectively, in outstanding structured financing debt, which was primarily related to the fixed-term lease and loan securitization programs and the revolving loan securitization programs.  See Note 7 and Note 9 of the Notes to the Unaudited Condensed Consolidated Financial Statements for further discussion of the structured financing debt and the interest rate swap agreements that hedge a portion of that debt.

- added (2017-06-09):
[0001571996-17-000009:note_history:124]
Unsecured Notes and Debentures — The Company has unsecured notes and debentures (collectively, the "Unsecured Notes and Dentures") that were issued prior to the acquisition of Dell by Dell Technologies Inc.  Interest on these borrowings is payable semiannually.

- changed (2017-06-09):
[0001571996-17-000009:note_history:125]
Aggregate Future Maturities — As of May 5, 2017, aggregate future maturities of the Company's debt were as follows:
  (was, 2016-12-09, similarity 0.9554):
[0001571996-16-000021:note_history:125]
Aggregate Future Maturities — As of October 28, 2016, aggregate future maturities of the Company's debt were as follows:

- added (2017-06-09):
[0001571996-17-000009:note_history:126]
|  | Maturities by Fiscal Year |
|  | 2018 (remaining nine months) |  | 2019 |  | 2020 |  | 2021 |  | 2022 |  | Thereafter |  | Total |
|  | (in millions) |
| Structured Financing Debt | $ | 2,039 |  |  | $ | 1,291 |  |  | $ | 406 |  |  | $ | 107 |  |  | $ | 26 |  |  | $ | — |  |  | $ | 3,869 |  |
| Senior Secured Credit Facilities and First Lien Notes | 188 |  |  | 2,699 |  |  | 4,197 |  |  | 336 |  |  | 7,677 |  |  | 16,977 |  |  | 32,074 |  |
| Unsecured Notes and Debentures | — |  |  | 500 |  |  | 600 |  |  | — |  |  | 400 |  |  | 953 |  |  | 2,453 |  |
| Senior Notes and EMC Notes | — |  |  | 2,500 |  |  | — |  |  | 2,000 |  |  | 1,625 |  |  | 2,625 |  |  | 8,750 |  |
| Margin Loan Facility | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 2,000 |  |  | 2,000 |  |
| Bridge Facility | 1,500 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 1,500 |  |
| Other | 9 |  |  | 18 |  |  | 3 |  |  | 27 |  |  | — |  |  | 25 |  |  | 82 |  |
| Total maturities, principal amount | 3,736 |  |  | 7,008 |  |  | 5,206 |  |  | 2,470 |  |  | 9,728 |  |  | 22,580 |  |  | 50,728 |  |
| Associated carrying value adjustments | (9 | ) |  | (42 | ) |  | (51 | ) |  | (1 | ) |  | (230 | ) |  | (605 | ) |  | (938 | ) |
| Total maturities, carrying value amount | $ | 3,727 |  |  | $ | 6,966 |  |  | $ | 5,155 |  |  | $ | 2,469 |  |  | $ | 9,498 |  |  | $ | 21,975 |  |  | $ | 49,790 |  |

- added (2017-06-09):
[0001571996-17-000009:note_history:127]
Covenants and Unrestricted Net Assets — The credit agreement for the Senior Secured Credit Facilities contain customary negative covenants that generally limit the ability of Denali Intermediate Inc., a wholly-owned subsidiary of Dell Technologies ("Dell Intermediate"), Dell, and Dell's and Denali Intermediate's other restricted subsidiaries to incur debt, create liens, make fundamental changes, enter into asset sales, make certain investments, pay dividends or distribute or redeem certain equity interests, prepay or redeem certain debt, and enter into certain transactions with affiliates.  The indenture governing the Senior Notes contains customary negative covenants that generally limit the ability of Denali Intermediate, Dell, and Dell's and Denali Intermediate's other restricted subsidiaries to incur additional debt or issue certain preferred shares, pay dividends on or make other distributions in respect of capital stock or make other restricted payments, make certain investments, sell or transfer certain assets, create liens on certain assets to secure debt, consolidate, merge, sell, or otherwise dispose of all or substantially all assets, enter into certain transactions with affiliates, and designate subsidiaries as unrestricted subsidiaries.  The negative covenants under such credit agreements and indenture are subject to certain exceptions, qualifications, and "baskets."  The indentures governing the First Lien Notes, the Unsecured Notes and Debentures, and the EMC Notes variously impose limitations, subject to specified exceptions, on creating certain liens, entering into sale and lease-back transactions, and entering into certain asset sales.  As of May 5, 2017, the Company had certain consolidated subsidiaries that were designated as unrestricted subsidiaries for all purposes of the applicable credit agreements and the indentures governing the First Lien Notes and the Senior Notes.  The foregoing credit agreements and indentures contain customary events of default, including failure to make required payments, failure to comply with covenants, and the occurrence of certain events of bankruptcy and insolvency.

- changed (2017-06-09):
[0001571996-17-000009:note_history:128]
The Term Loan A-1 Facility, the Term Loan A-2 Facility, the Term Loan A-3 Facility, and the Revolving Credit Facility are subject to a first lien net leverage ratio covenant that is tested at the end of each fiscal quarter of Dell with respect to Dell's preceding four fiscal quarters.  The Company was in compliance with all financial covenants as of May 5, 2017.
  (was, 2016-12-09, similarity 0.8772):
[0001571996-16-000021:note_history:128]
The Term Loan A-1 Facility, the Term Loan A-2 Facility, the Term Loan A-3 Facility, and the Revolving Credit Facility are subject to a first lien net leverage ratio covenant that will be tested at the end of each fiscal quarter of Dell with respect to Dell’s preceding four fiscal quarters.  The Company was in compliance with this financial covenant as of October 28, 2016.

- removed (2017-06-09):
[0001571996-16-000021:note_history:129]
|  | October 28, 2016 |  | January 29, 2016 |
|  | (in millions) |
| Secured Debt |  |  |  |
| Structured financing debt | $ | 3,426 |  |  | $ | 3,411 |  |
| 3.75% Floating rate due October 2018 ("Term Loan C Facility") | — |  |  | 1,003 |  |
| 4.00% Floating rate due April 2020 ("Term Loan B Facility") | — |  |  | 4,329 |  |
| 4.00% Floating rate due April 2020 ("Term Loan Euro Facility") | — |  |  | 891 |  |
| 5.625% due October 2020 ("Senior First Lien Notes") | — |  |  | 1,400 |  |
| EMC merger transaction financing issued on September 7, 2016 ("Senior Secured Credit Facilities"): |  |  |  |
| 4.00% Term Loan B Facility due September 2023 | 5,000 |  |  | — |  |
| 2.53% Term Loan A-1 Facility due December 2018 | 3,700 |  |  | — |  |
| 2.78% Term Loan A-2 Facility due September 2021 | 3,925 |  |  | — |  |
| 2.53% Term Loan A-3 Facility due December 2018 | 1,800 |  |  | — |  |
| 2.53% Revolving Credit Facility due September 2021 | 1,475 |  |  | — |  |
| EMC merger transaction financing issued on June 1, 2016 ("First Lien Notes"): |  |  |  |
| 3.48% due June 2019 | 3,750 |  |  | — |  |
| 4.42% due June 2021 | 4,500 |  |  | — |  |
| 5.45% due June 2023 | 3,750 |  |  | — |  |
| 6.02% due June 2026 | 4,500 |  |  | — |  |
| 8.10% due June 2036 | 1,500 |  |  | — |  |
| 8.35% due June 2046 | 2,000 |  |  | — |  |
| Unsecured Notes and Debentures |  |  |  |
| Notes and debentures issued prior to going-private transaction: |  |  |  |
| 3.10% due April 2016 | — |  |  | 400 |  |
| 5.65% due April 2018 | 500 |  |  | 500 |  |
| 5.875% due June 2019 | 600 |  |  | 600 |  |
| 4.625% due April 2021 | 400 |  |  | 400 |  |
| 7.10% due April 2028 | 300 |  |  | 300 |  |
| 6.50% due April 2038 | 388 |  |  | 388 |  |
| 5.40% due September 2040 | 265 |  |  | 265 |  |
| EMC merger transaction financing issued on June 22, 2016 ("Senior Notes"): |  |  |  |
| 5.875% due June 2021 | 1,625 |  |  | — |  |
| 7.125% due June 2024 | 1,625 |  |  | — |  |
| Existing EMC notes assumed as part of the EMC merger transaction ("EMC Notes"): |  |  |  |
| 1.875% due June 2018 | 2,500 |  |  | — |  |
| 2.650% due June 2020 | 2,000 |  |  | — |  |
| 3.375% due June 2023 | 1,000 |  |  | — |  |
| Bridge Facilities |  |  |  |
| 4.875% Asset Sale Bridge Facility due September 2017 | 2,200 |  |  | — |  |
| 2.28% Margin Bridge Facility due September 2017 | 2,500 |  |  | — |  |
| 2.28% VMware Note Bridge Facility due September 2017 | 1,500 |  |  | — |  |
| Other | 58 |  |  | 93 |  |
| Total debt, principal amount | 56,787 |  |  | 13,980 |  |

- removed (2017-06-09):
[0001571996-16-000021:note_history:130]
|  | October 28, 2016 |  | January 29, 2016 |
|  | (in millions) |
| Total debt, principal amount | 56,787 |  |  | 13,980 |  |
| Unamortized discount, net of unamortized premium | (310 | ) |  | (221 | ) |
| Debt issuance costs | (805 | ) |  | (128 | ) |
| Total debt, carrying value | $ | 55,672 |  |  | $ | 13,631 |  |
| Total short-term debt | $ | 8,388 |  |  | $ | 2,981 |  |
| Total long-term debt | $ | 47,284 |  |  | $ | 10,650 |  |

- removed (2017-06-09):
[0001571996-16-000021:note_history:131]
Upon the closing of the EMC merger transaction, the Company repaid and terminated the ABL Credit Facility and the Term Loan Facilities obtained in connection with the going-private transaction, and redeemed the Senior First Lien Notes issued in connection with the going-private transaction.  During the nine months ended October 28, 2016, the Company repaid $0.5 billion of the Revolving Credit Facility obtained in connection with the EMC merger transaction and $0.4 billion of maturing Unsecured Notes and Debentures.

- removed (2017-06-09):
[0001571996-16-000021:note_history:132]
To finance the EMC merger transaction, the Company issued $45.9 billion in new debt, which included proceeds from the sale of the First Lien Notes and Senior Unsecured Notes in June 2016, as well as borrowings under the Senior Secured Credit Facilities (including the Revolving Credit Facility), the Asset Sale Bridge Facility, the Margin Bridge Facility, and the VMware Note Bridge Facility at the closing of the transaction.  The Company incurred approximately $245 million of other expenses related to these debt extinguishments and new borrowings.  Under the terms of the agreements relating to the issuance of the First Lien Notes and Senior Unsecured Notes, the proceeds of the offerings were deposited into escrow and included in restricted cash in the Condensed Consolidated Statements of Financial Position until the closing of the EMC merger transaction, at which time such proceeds were released to finance the transaction.  Upon the closing of the EMC merger transaction, the Company received pre-funded interest in the amount of $58 million that the Company had previously paid into escrow and which will be paid to the holders of the First Lien Notes and Senior Unsecured Notes on the scheduled interest payment dates, as well as investment income earned of approximately $14 million on that pre-funded interest.

- removed (2017-06-09):
[0001571996-16-000021:note_history:133]
The Term Loan A-1 Facility will mature on December 31, 2018 and has no amortization.  The Term Loan A-2 Facility will mature on September 7, 2021 and amortizes in equal quarterly installments in aggregate annual amounts equal to 5% of the original principal amount in each of the first two years after the date of the closing of the EMC merger transaction, 10% of the original principal amount in each of the third and fourth years after the date of the closing of the EMC merger transaction, and 70% of the original principal amount in the fifth year after the date of the closing of the EMC merger transaction.  The Term Loan A-3 Facility will mature on December 31, 2018 and has no amortization.  The Term Loan B Facility will mature on September 7, 2023 and amortizes in equal quarterly installments in aggregate annual amounts equal to 1% of the original principal amount.  The Revolving Credit Facility will mature on September 7, 2021 and has no amortization.  The Term Loan A-1 and A-3 Facilities require the borrowers to prepay outstanding borrowings under these facilities with 100% of the net cash proceeds of certain non-ordinary course asset sales or dispositions after fully prepaying the Asset Sale Bridge Facility.  The borrowers may voluntarily repay outstanding loans under the Term Loan and Revolving Credit Facilities at any time without premium or penalty, other than customary “breakage” costs.

- removed (2017-06-09):
[0001571996-16-000021:note_history:134]
All obligations of the borrowers under the Senior Secured Credit Facilities and certain swap agreements, cash management arrangements, and certain letters of credit provided by any lender or agent party to the Senior Secured Credit Facilities or any of their affiliates and certain other persons are guaranteed by Denali Intermediate Inc. (“Denali Intermediate”), Dell, certain subsidiaries of Denali Intermediate, and each existing and subsequently acquired or organized direct or indirect material wholly-owned domestic restricted subsidiary of Dell, with customary exceptions.  All such obligations under the Senior Secured Credit Facilities (and the guarantees thereof) and certain swap agreements, cash management arrangements, and certain letters of credit provided by any lender or agent party to the Senior Secured Credit Facilities or any of its affiliates and certain other persons are secured by (a) a first-priority security interest in certain tangible and intangible assets of the borrowers and the guarantors and (b) a first-priority pledge of 100% of the capital stock of the borrowers, Dell and each wholly-owned material restricted subsidiary of the borrowers and the guarantors, in each case subject to certain thresholds, exceptions and permitted liens.

- removed (2017-06-09):
[0001571996-16-000021:note_history:135]
Senior Notes — The senior unsecured notes (collectively, the "Senior Notes") were issued on June 22, 2016 in an aggregate principal amount of $3.25 billion.  As of the closing of the EMC merger transaction, Dell International and EMC are the co-issuers of the Senior Notes.  The Senior Notes are guaranteed, subject to certain exceptions, on a joint and several basis, by Dell Technologies, Denali Intermediate, Dell, and Denali Intermediate’s direct and indirect wholly-owned material domestic subsidiaries that guarantee the Senior Secured Credit Facilities.

- removed (2017-06-09):
[0001571996-16-000021:note_history:136]
Repayment and Termination of Credit Facilities — At the closing of the EMC merger transaction on September 7, 2016, the Company repaid approximately $6.1 billion of borrowings (including accrued and unpaid interest thereon) under the Company’s ABL Credit Facility and Term Loan Facilities obtained in connection with the going-private transaction and terminated such credit facilities and related credit agreements and documents.

- removed (2017-06-09):
[0001571996-16-000021:note_history:137]
The ABL Credit Facility provided for an asset-based senior secured revolving credit facility in an initial aggregate principal amount of approximately $2.0 billion, subject to a borrowing base consisting of certain receivables and inventory.  The Term Loan Facilities originally provided for senior secured term loan facilities consisting of a $4.7 billion Term Loan B Facility, a $1.5 billion Term Loan C Facility and a €0.7 billion Term Loan Euro Facility.

- removed (2017-06-09):
[0001571996-16-000021:note_history:138]
Redemption of Senior First Lien Notes — In connection with the EMC merger transaction, the Company issued and delivered notices of conditional redemption to holders of the outstanding 5.625% Senior First Lien Notes due 2020 issued by them in October 2013 in connection with Dell’s going private transaction (the “Senior First Lien Notes”) to redeem (a) $0.15 billion in aggregate principal amount of the Senior First Lien Notes at a redemption price of 103% of the principal amount thereof and (b) $1.25 billion in aggregate principal amount of the Senior First Lien Notes at a redemption price equal to 100% of the principal amount thereof plus a “make-whole” premium calculated in accordance with the indenture governing the Senior First Lien Notes, in each case, plus accrued and unpaid interest thereon to but excluding the redemption date. Such redemption notices were conditioned upon, among other matters, the closing of the EMC merger transaction. On September 7, 2016, substantially concurrently with the consummation of the EMC merger transaction, the Company deposited with the trustee of the Senior First Lien Notes the applicable redemption payments to fund such redemptions and thereby redeemed all of the outstanding Senior First Lien Notes.  The Senior First Lien Notes were issued in an aggregate original principal amount of $1.5 billion.

- removed (2017-06-09):
[0001571996-16-000021:note_history:139]
EMC Notes — As of September 7, 2016, EMC had outstanding approximately $2.5 billion aggregate principal amount of its 1.875% Notes due June 2018, approximately $2.0 billion aggregate principal amount of its 2.650% Notes due June 2020 and approximately $1.0 billion aggregate principal amount of its 3.375% Notes due June 2023 (collectively, the “EMC Notes”), all of which were issued pursuant to an Indenture dated as of June 6, 2013. The EMC Notes remain outstanding following the closing of the EMC merger transaction. The EMC Notes are senior unsecured obligations of EMC and are not guaranteed by any subsidiaries of EMC or by the Company or any other subsidiaries of the Company.

- removed (2017-06-09):
[0001571996-16-000021:note_history:140]
Unsecured Notes and Debentures — The Company has Unsecured Notes and Debentures that were issued prior to the going-private transaction. Interest on these borrowings is payable semiannually. See "Senior Notes" above for a discussion of the Senior Unsecured Notes issued in connection with the EMC merger transaction.

- removed (2017-06-09):
[0001571996-16-000021:note_history:141]
Asset Sale Bridge Facility — On September 7, 2016, certain subsidiaries of the Company entered into a credit agreement providing for a senior unsecured asset sale bridge facility in an aggregate principal amount of $2.2 billion (the “Asset Sale Bridge Facility”). Dell International and EMC are the borrowers under the Asset Sale Bridge Facility, which is guaranteed by Denali Intermediate, certain subsidiaries of Denali Intermediate, Dell, and each existing and subsequently acquired or organized direct or indirect material wholly-owned domestic restricted subsidiary of Dell that guarantees the Senior Secured Credit Facilities.

- removed (2017-06-09):
[0001571996-16-000021:note_history:142]
Borrowings under the Asset Sale Bridge Facility bear interest (a) at a fixed rate of 4.875% per annum until the date that is the three-month anniversary of the closing date of the facility, (b) at a LIBOR-based rate plus a marginal rate of 7.50% per annum from the date that is the three-month anniversary of the closing date of the facility until the date that is the six-month anniversary of the closing date of the facility, and (c) thereafter, at a LIBOR-based rate, subject to increases of 50 basis points on the applicable margin rate every three months thereafter. Interest is payable, at the end of each interest period (but at least every three months), in arrears.

- removed (2017-06-09):
[0001571996-16-000021:note_history:143]
The Asset Sale Bridge Facility will mature on September 6, 2017 and has no amortization. The Asset Sale Bridge Facility requires the borrowers to prepay outstanding borrowings under the facility with 100% of the net cash proceeds of certain non-ordinary course asset sales or dispositions. The borrowers may voluntarily repay outstanding loans under the Asset Sale Bridge Facility at any time without premium or penalty, other than customary "breakage" costs.

- removed (2017-06-09):
[0001571996-16-000021:note_history:144]
See Note 22 of the Notes to the Unaudited Condensed Consolidated Financial Statements for information regarding the repayment and termination of the Asset Sale Bridge Facility that occurred subsequent to October 28, 2016.

- removed (2017-06-09):
[0001571996-16-000021:note_history:145]
Interest under the Margin Bridge Facility is payable, at the borrower's option, either at (a) a base rate plus 0.75% per annum or (b) a LIBOR-based rate plus 1.75% per annum. Interest is payable, in the case of loans bearing interest based on LIBOR, at the end of each interest period (but at least every three months), in arrears and, in the case of loans bearing interest based on the base rate, quarterly in arrears.

- removed (2017-06-09):
[0001571996-16-000021:note_history:146]
The Margin Bridge Facility will mature on September 6, 2017 and has no amortization. The Margin Bridge Facility requires the borrower to prepay outstanding borrowings under the Margin Bridge Facility with 100% of the net cash proceeds of any asset sale or other disposition of the pledged VMware shares.  The borrower may voluntarily repay outstanding loans under the Margin Bridge Facility at any time without premium or penalty, other than customary “breakage” costs, subject to certain minimum threshold amounts for prepayment.

- removed (2017-06-09):
[0001571996-16-000021:note_history:147]
The VMware Note Bridge Facility will mature on September 6, 2017 and has no amortization.  The VMware Note Bridge Facility requires the borrower to prepay outstanding borrowings under the VMware Note Bridge Facility with 100% of the net cash proceeds of any asset sale or other disposition of the pledged VMware promissory notes. The borrower may voluntarily repay outstanding loans under the VMware Note Bridge Facility at any time without premium or penalty, other than customary “breakage” costs, subject to certain minimum threshold amounts for prepayment.

- removed (2017-06-09):
[0001571996-16-000021:note_history:148]
|  | Maturities by Fiscal Year |
|  | 2017 (remaining three months) |  | 2018 |  | 2019 |  | 2020 |  | 2021 |  | Thereafter |  | Total |
|  | (in millions) |
| Structured Financing Debt | $ | 581 |  |  | $ | 1,754 |  |  | $ | 911 |  |  | $ | 150 |  |  | $ | 27 |  |  | $ | 3 |  |  | $ | 3,426 |  |
| Senior Secured Credit Facilities and First Lien Notes | 62 |  |  | 246 |  |  | 5,795 |  |  | 4,193 |  |  | 332 |  |  | 25,272 |  |  | 35,900 |  |
| Unsecured Notes and Debentures | — |  |  | — |  |  | 500 |  |  | 600 |  |  | — |  |  | 1,353 |  |  | 2,453 |  |
| Senior Notes and EMC Notes | — |  |  | — |  |  | 2,500 |  |  | — |  |  | 2,000 |  |  | 4,250 |  |  | 8,750 |  |
| Bridge Facilities | — |  |  | 6,200 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 6,200 |  |
| Other | 17 |  |  | 13 |  |  | 2 |  |  | — |  |  | — |  |  | 26 |  |  | 58 |  |
| Total maturities, principal amount | 660 |  |  | 8,213 |  |  | 9,708 |  |  | 4,943 |  |  | 2,359 |  |  | 30,904 |  |  | 56,787 |  |
| Associated carrying value adjustments | (1 | ) |  | (76 | ) |  | (113 | ) |  | (63 | ) |  | — |  |  | (862 | ) |  | (1,115 | ) |
| Total maturities, carrying value amount | $ | 659 |  |  | $ | 8,137 |  |  | $ | 9,595 |  |  | $ | 4,880 |  |  | $ | 2,359 |  |  | $ | 30,042 |  |  | $ | 55,672 |  |

- removed (2017-06-09):
[0001571996-16-000021:note_history:149]
Covenants and Unrestricted Net Assets — The credit agreements for the Senior Secured Credit Facilities and the Asset Sale Bridge Facility contain customary negative covenants that generally limit the ability of Denali Intermediate, Dell, and Dell’s and Denali Intermediate’s other restricted subsidiaries to incur debt, create liens, make fundamental changes, enter into asset sales, make certain investments, pay dividends or distribute or redeem certain equity interests, prepay or redeem certain debt, and enter into certain transactions with affiliates.  The indenture governing the Senior Notes contains customary negative covenants that generally limit the ability of Denali Intermediate, Dell, and Dell’s and Denali’s other restricted subsidiaries to incur additional debt or issue certain preferred shares, pay dividends on or make other distributions in respect of capital stock or make other restricted payments, make certain investments, sell or transfer certain assets, create liens on certain assets to secure debt, consolidate, merge, sell, or otherwise dispose of all or substantially all assets, enter into certain transactions with affiliates, and designate subsidiaries as unrestricted subsidiaries.  The negative covenants under such credit agreements and indenture are subject to certain exceptions, qualifications and “baskets.”  The indentures governing the First Lien Notes, the Unsecured Notes and Debentures, and the EMC Notes variously impose limitations, subject to specified exceptions, on creating certain liens, entering into sale and lease-back transactions, and entering into certain asset sales.  As of October 28, 2016, the Company had certain consolidated subsidiaries that were designated as unrestricted subsidiaries for all purposes of the applicable credit agreements and the indentures governing the First Lien Notes and the Senior Notes.  As of October 28, 2016, unrestricted net assets of the consolidated subsidiaries were approximately $32.8 billion.  The foregoing credit agreements and indentures contain customary events of default, including failure to make required payments, failure to comply with covenants, and the occurrence of certain events of bankruptcy and insolvency.


## us-gaap:ScheduleOfCarryingValuesAndEstimatedFairValuesOfDebtInstrumentsTableTextBlock (debt) — matched_by: no_prior_note, score: 0.0

- added (2017-06-09):
[0001571996-17-000009:note_history:150]
The following table summarizes the carrying value and estimated fair value of the Company's outstanding debt as described in Note 7 of the Notes to the Condensed Consolidated Financial Statements, including the current portion, as of the dates indicated:

- added (2017-06-09):
[0001571996-17-000009:note_history:151]
|  | May 5, 2017 |  | February 3, 2017 |
|  | Carrying Value |  | Fair Value |  | Carrying Value |  | Fair Value |
|  | (in billions) |
| Senior Secured Credit Facilities | $ | 11.8 |  |  | $ | 12.1 |  |  | $ | 11.4 |  |  | $ | 11.7 |  |
| First Lien Notes | $ | 19.7 |  |  | $ | 22.1 |  |  | $ | 19.7 |  |  | $ | 21.8 |  |
| Unsecured Notes and Debentures | $ | 2.3 |  |  | $ | 2.5 |  |  | $ | 2.3 |  |  | $ | 2.5 |  |
| Senior Notes | $ | 3.1 |  |  | $ | 3.5 |  |  | $ | 3.1 |  |  | $ | 3.5 |  |
| EMC Notes | $ | 5.5 |  |  | $ | 5.4 |  |  | $ | 5.5 |  |  | $ | 5.4 |  |
| Margin Loan Facility | $ | 2.0 |  |  | $ | 2.0 |  |  | $ | — |  |  | $ | — |  |
| Bridge Facilities | $ | 1.5 |  |  | $ | 1.5 |  |  | $ | 4.0 |  |  | $ | 4.0 |  |


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2017-06-09):
[0001571996-17-000009:note_history:152]
|  | May 5, 2017 |  | February 3, 2017 |
|  | (in millions) |
| Secured Debt |  |  |  |
| Structured financing debt | $ | 3,869 |  |  | $ | 3,464 |  |
| Senior Secured Credit Facilities: |  |  |  |
| 3.50% Term Loan B Facility due September 2023 | 5,473 |  |  | 4,987 |  |
| 3.00% Term Loan A-1 Facility due December 2018 | 599 |  |  | 600 |  |
| 3.25% Term Loan A-2 Facility due September 2021 | 3,827 |  |  | 3,876 |  |
| 3.00% Term Loan A-3 Facility due December 2018 | 1,800 |  |  | 1,800 |  |
| 3.00% Revolving Credit Facility due September 2021 | 375 |  |  | 375 |  |
| First Lien Notes: |  |  |  |
| 3.48% due June 2019 | 3,750 |  |  | 3,750 |  |
| 4.42% due June 2021 | 4,500 |  |  | 4,500 |  |
| 5.45% due June 2023 | 3,750 |  |  | 3,750 |  |
| 6.02% due June 2026 | 4,500 |  |  | 4,500 |  |
| 8.10% due June 2036 | 1,500 |  |  | 1,500 |  |
| 8.35% due June 2046 | 2,000 |  |  | 2,000 |  |
| Unsecured Debt |  |  |  |
| Unsecured Notes and Debentures: |  |  |  |
| 5.65% due April 2018 | 500 |  |  | 500 |  |
| 5.875% due June 2019 | 600 |  |  | 600 |  |
| 4.625% due April 2021 | 400 |  |  | 400 |  |
| 7.10% due April 2028 | 300 |  |  | 300 |  |
| 6.50% due April 2038 | 388 |  |  | 388 |  |
| 5.40% due September 2040 | 265 |  |  | 265 |  |
| Senior Notes: |  |  |  |
| 5.875% due June 2021 | 1,625 |  |  | 1,625 |  |
| 7.125% due June 2024 | 1,625 |  |  | 1,625 |  |
| EMC Notes: |  |  |  |
| 1.875% due June 2018 | 2,500 |  |  | 2,500 |  |
| 2.650% due June 2020 | 2,000 |  |  | 2,000 |  |
| 3.375% due June 2023 | 1,000 |  |  | 1,000 |  |
| Other |  |  |  |
| 3.42% Margin Loan Facility due April 2022 | 2,000 |  |  | — |  |
| 2.53% Margin Bridge Facility due September 2017 | — |  |  | 2,500 |  |
| 2.75% VMware Note Bridge Facility due September 2017 | 1,500 |  |  | 1,500 |  |
| Other | 82 |  |  | 51 |  |
| Total debt, principal amount | $ | 50,728 |  |  | $ | 50,356 |  |
| Unamortized discount, net of unamortized premium | (293 | ) |  | (284 | ) |
| Debt issuance costs | (645 | ) |  | (682 | ) |
| Total debt, carrying value | $ | 49,790 |  |  | $ | 49,390 |  |
| Total short-term debt, carrying value | $ | 4,842 |  |  | $ | 6,329 |  |
| Total long-term debt, carrying value | $ | 44,948 |  |  | $ | 43,061 |  |

- removed (2017-06-09):
[0001571996-16-000021:note_history:153]
|  | October 28, 2016 |  | January 29, 2016 |
|  | (in millions) |
| Secured Debt |  |  |  |
| Structured financing debt | $ | 3,426 |  |  | $ | 3,411 |  |
| 3.75% Floating rate due October 2018 ("Term Loan C Facility") | — |  |  | 1,003 |  |
| 4.00% Floating rate due April 2020 ("Term Loan B Facility") | — |  |  | 4,329 |  |
| 4.00% Floating rate due April 2020 ("Term Loan Euro Facility") | — |  |  | 891 |  |
| 5.625% due October 2020 ("Senior First Lien Notes") | — |  |  | 1,400 |  |
| EMC merger transaction financing issued on September 7, 2016 ("Senior Secured Credit Facilities"): |  |  |  |
| 4.00% Term Loan B Facility due September 2023 | 5,000 |  |  | — |  |
| 2.53% Term Loan A-1 Facility due December 2018 | 3,700 |  |  | — |  |
| 2.78% Term Loan A-2 Facility due September 2021 | 3,925 |  |  | — |  |
| 2.53% Term Loan A-3 Facility due December 2018 | 1,800 |  |  | — |  |
| 2.53% Revolving Credit Facility due September 2021 | 1,475 |  |  | — |  |
| EMC merger transaction financing issued on June 1, 2016 ("First Lien Notes"): |  |  |  |
| 3.48% due June 2019 | 3,750 |  |  | — |  |
| 4.42% due June 2021 | 4,500 |  |  | — |  |
| 5.45% due June 2023 | 3,750 |  |  | — |  |
| 6.02% due June 2026 | 4,500 |  |  | — |  |
| 8.10% due June 2036 | 1,500 |  |  | — |  |
| 8.35% due June 2046 | 2,000 |  |  | — |  |
| Unsecured Notes and Debentures |  |  |  |
| Notes and debentures issued prior to going-private transaction: |  |  |  |
| 3.10% due April 2016 | — |  |  | 400 |  |
| 5.65% due April 2018 | 500 |  |  | 500 |  |
| 5.875% due June 2019 | 600 |  |  | 600 |  |
| 4.625% due April 2021 | 400 |  |  | 400 |  |
| 7.10% due April 2028 | 300 |  |  | 300 |  |
| 6.50% due April 2038 | 388 |  |  | 388 |  |
| 5.40% due September 2040 | 265 |  |  | 265 |  |
| EMC merger transaction financing issued on June 22, 2016 ("Senior Notes"): |  |  |  |
| 5.875% due June 2021 | 1,625 |  |  | — |  |
| 7.125% due June 2024 | 1,625 |  |  | — |  |
| Existing EMC notes assumed as part of the EMC merger transaction ("EMC Notes"): |  |  |  |
| 1.875% due June 2018 | 2,500 |  |  | — |  |
| 2.650% due June 2020 | 2,000 |  |  | — |  |
| 3.375% due June 2023 | 1,000 |  |  | — |  |
| Bridge Facilities |  |  |  |
| 4.875% Asset Sale Bridge Facility due September 2017 | 2,200 |  |  | — |  |
| 2.28% Margin Bridge Facility due September 2017 | 2,500 |  |  | — |  |
| 2.28% VMware Note Bridge Facility due September 2017 | 1,500 |  |  | — |  |
| Other | 58 |  |  | 93 |  |
| Total debt, principal amount | 56,787 |  |  | 13,980 |  |

- removed (2017-06-09):
[0001571996-16-000021:note_history:154]
|  | October 28, 2016 |  | January 29, 2016 |
|  | (in millions) |
| Total debt, principal amount | 56,787 |  |  | 13,980 |  |
| Unamortized discount, net of unamortized premium | (310 | ) |  | (221 | ) |
| Debt issuance costs | (805 | ) |  | (128 | ) |
| Total debt, carrying value | $ | 55,672 |  |  | $ | 13,631 |  |
| Total short-term debt | $ | 8,388 |  |  | $ | 2,981 |  |
| Total long-term debt | $ | 47,284 |  |  | $ | 10,650 |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2017-06-09):
[0001571996-17-000009:note_history:155]
As of May 5, 2017, aggregate future maturities of the Company's debt were as follows:
  (was, 2016-12-09, similarity 0.939):
[0001571996-16-000021:note_history:155]
As of October 28, 2016, aggregate future maturities of the Company's debt were as follows:

- added (2017-06-09):
[0001571996-17-000009:note_history:156]
|  | Maturities by Fiscal Year |
|  | 2018 (remaining nine months) |  | 2019 |  | 2020 |  | 2021 |  | 2022 |  | Thereafter |  | Total |
|  | (in millions) |
| Structured Financing Debt | $ | 2,039 |  |  | $ | 1,291 |  |  | $ | 406 |  |  | $ | 107 |  |  | $ | 26 |  |  | $ | — |  |  | $ | 3,869 |  |
| Senior Secured Credit Facilities and First Lien Notes | 188 |  |  | 2,699 |  |  | 4,197 |  |  | 336 |  |  | 7,677 |  |  | 16,977 |  |  | 32,074 |  |
| Unsecured Notes and Debentures | — |  |  | 500 |  |  | 600 |  |  | — |  |  | 400 |  |  | 953 |  |  | 2,453 |  |
| Senior Notes and EMC Notes | — |  |  | 2,500 |  |  | — |  |  | 2,000 |  |  | 1,625 |  |  | 2,625 |  |  | 8,750 |  |
| Margin Loan Facility | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 2,000 |  |  | 2,000 |  |
| Bridge Facility | 1,500 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 1,500 |  |
| Other | 9 |  |  | 18 |  |  | 3 |  |  | 27 |  |  | — |  |  | 25 |  |  | 82 |  |
| Total maturities, principal amount | 3,736 |  |  | 7,008 |  |  | 5,206 |  |  | 2,470 |  |  | 9,728 |  |  | 22,580 |  |  | 50,728 |  |
| Associated carrying value adjustments | (9 | ) |  | (42 | ) |  | (51 | ) |  | (1 | ) |  | (230 | ) |  | (605 | ) |  | (938 | ) |
| Total maturities, carrying value amount | $ | 3,727 |  |  | $ | 6,966 |  |  | $ | 5,155 |  |  | $ | 2,469 |  |  | $ | 9,498 |  |  | $ | 21,975 |  |  | $ | 49,790 |  |

- removed (2017-06-09):
[0001571996-16-000021:note_history:157]
|  | Maturities by Fiscal Year |
|  | 2017 (remaining three months) |  | 2018 |  | 2019 |  | 2020 |  | 2021 |  | Thereafter |  | Total |
|  | (in millions) |
| Structured Financing Debt | $ | 581 |  |  | $ | 1,754 |  |  | $ | 911 |  |  | $ | 150 |  |  | $ | 27 |  |  | $ | 3 |  |  | $ | 3,426 |  |
| Senior Secured Credit Facilities and First Lien Notes | 62 |  |  | 246 |  |  | 5,795 |  |  | 4,193 |  |  | 332 |  |  | 25,272 |  |  | 35,900 |  |
| Unsecured Notes and Debentures | — |  |  | — |  |  | 500 |  |  | 600 |  |  | — |  |  | 1,353 |  |  | 2,453 |  |
| Senior Notes and EMC Notes | — |  |  | — |  |  | 2,500 |  |  | — |  |  | 2,000 |  |  | 4,250 |  |  | 8,750 |  |
| Bridge Facilities | — |  |  | 6,200 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 6,200 |  |
| Other | 17 |  |  | 13 |  |  | 2 |  |  | — |  |  | — |  |  | 26 |  |  | 58 |  |
| Total maturities, principal amount | 660 |  |  | 8,213 |  |  | 9,708 |  |  | 4,943 |  |  | 2,359 |  |  | 30,904 |  |  | 56,787 |  |
| Associated carrying value adjustments | (1 | ) |  | (76 | ) |  | (113 | ) |  | (63 | ) |  | — |  |  | (862 | ) |  | (1,115 | ) |
| Total maturities, carrying value amount | $ | 659 |  |  | $ | 8,137 |  |  | $ | 9,595 |  |  | $ | 4,880 |  |  | $ | 2,359 |  |  | $ | 30,042 |  |  | $ | 55,672 |  |


## us-gaap:RevenueRecognitionPolicyTextBlock (revenue_recognition_policy) — matched_by: no_current_note, score: 0.0

- removed (2017-06-09):
[0001571996-16-000021:note_history:158]
Revenue Recognition — Net revenue primarily includes sales of hardware, services, software licenses, and peripherals.  The Company recognizes revenue for these products and services when it is realized or realizable and earned.  Revenue is recognized when persuasive evidence of an arrangement exists; delivery has occurred or services have been rendered; the Company's fee to its customer is fixed or determinable; and collection of the resulting receivable is reasonably assured.  This policy is applicable to all sales, including sales to resellers and end-users.

- removed (2017-06-09):
[0001571996-16-000021:note_history:159]
Revenue from third-party software sales and extended warranties for third-party products, for which the Company does not meet the criteria for gross revenue recognition, is recognized on a net basis.  All other revenue is recognized on a gross basis.

- removed (2017-06-09):
[0001571996-16-000021:note_history:160]
Services revenue and cost of services revenue captions in the Consolidated Statements of Income (Loss) include the Company's services, third-party software revenue, and support services related to the Company-owned software offerings.

- removed (2017-06-09):
[0001571996-16-000021:note_history:161]
The following summarizes the major terms of contractual relationships with customers and the manner in which the Company accounts for sales transactions.

- removed (2017-06-09):
[0001571996-16-000021:note_history:162]
Products

- removed (2017-06-09):
[0001571996-16-000021:note_history:163]
Product revenue consists of computer hardware, enterprise hardware, and software licenses sales that are delivered, sold as a subscription or sold on a consumption basis. Computer hardware and enterprise hardware include notebooks and desktop PCs, servers, storage hardware, and other hardware-related devices.  Software license sales include optional, stand-alone software applications. Software applications provide customers with resource management, backup and archiving, information security, information management and intelligence, data analytics and server virtualization capabilities.  Revenue from the sale of hardware products and systems is recognized when title and risk of loss pass to the customer.  Delivery is considered complete when products have been shipped to the Company's customer, title and risk of loss have transferred to the customer, and customer acceptance has been satisfied.  Customer acceptance is satisfied if acceptance is obtained from the customer, if all acceptance provisions lapse, or if the Company has evidence that all acceptance provisions have been satisfied.  Depending on the nature of the arrangement, software license sales is generally recognized upon shipment or electronic delivery.  For certain arrangements, revenue is recognized based on usage or ratably over the term of the arrangement.  License revenue from royalty arrangements is recognized upon either receipt of royalty reports or payments from third parties.

- removed (2017-06-09):
[0001571996-16-000021:note_history:164]
The Company records reductions to revenue for estimated customer sales returns, rebates, and certain other customer incentive programs.  These reductions to revenue are made based upon reasonable and reliable estimates that are determined by historical experience, contractual terms, and current conditions.  The primary factors affecting the Company's accrual for estimated customer returns include estimated return rates as well as the number of units shipped that have a right of return that has not expired as of the balance sheet date.  If returns cannot be reliably estimated, revenue is not recognized until a reliable estimate can be made or the return right lapses.

- removed (2017-06-09):
[0001571996-16-000021:note_history:165]
The Company sells its products directly to customers as well as through other distribution channels, such as retailers, distributors, and resellers.  The Company recognizes revenue on these sales when the reseller has economic substance apart from the Company; any credit risk has been identified and quantified; title and risk of loss have passed to the sales channel; the fee paid to the Company is not contingent upon resale or payment by the end user; and the Company has no further obligations related to bringing about resale or delivery.

- removed (2017-06-09):
[0001571996-16-000021:note_history:166]
Sales through the Company's distribution channels are primarily made under agreements allowing for limited rights of return, price protection, rebates, and marketing development funds.  The Company has generally limited return rights through contractual caps or has an established selling history for these arrangements.  Therefore, there is sufficient data to establish reasonable and reliable estimates of returns for the majority of these sales.  To the extent price protection or return rights are not limited and a reliable estimate cannot be made, all of the revenue and related costs are deferred until the product has been sold to the end-user or the rights expire.  The Company records estimated reductions to revenue or an expense for distribution channel programs at the later of the offer or the time revenue is recognized.

- removed (2017-06-09):
[0001571996-16-000021:note_history:167]
The Company defers the cost of shipped products awaiting revenue recognition until revenue is recognized.

- removed (2017-06-09):
[0001571996-16-000021:note_history:168]
Services

- removed (2017-06-09):
[0001571996-16-000021:note_history:169]
Services revenue consists of hardware and software maintenance, installation services, professional services, training revenue, third-party software revenue, and software sold as a service.  The Company recognizes revenue from fixed-price support or maintenance contracts sold for both hardware and software ratably over the contract period and recognizes the costs associated with these contracts as incurred.  For sales of extended warranties with a separate contract price, the Company defers revenue equal to the separately stated price.  Revenue associated with undelivered elements is deferred and recorded when delivery occurs or services are provided. Revenue from extended warranty and service contracts, for which the Company is obligated to perform, is recorded as deferred revenue and subsequently recognized over the term of the contract on a straight-line basis or when the service is completed and the costs associated with these contracts are recognized as incurred.

- removed (2017-06-09):
[0001571996-16-000021:note_history:170]
Multiple Deliverables

- removed (2017-06-09):
[0001571996-16-000021:note_history:171]
When an arrangement has more than one element, such as hardware, software, and services contained in a single arrangement, the Company first allocates revenue based upon the relative selling price into two categories: (1) non-software components, such as hardware and any hardware-related items, such as required system software that functions with the hardware to deliver the essential functionality of the hardware and related post-contract customer support, software as a service subscriptions and other services; and (2) software components, such as optional software applications and related items, such as post-contract customer support and other services. The Company then allocates revenue within the non-software category to each element based upon its relative selling price using a hierarchy of vendor-specific objective evidence (“VSOE”), third-party evidence of selling price (“TPE”), or estimated selling prices (“ESP”), if VSOE or TPE does not exist. The Company allocates revenue within the software category to the undelivered elements based upon their fair value using VSOE, with the residual revenue allocated to the delivered elements. If the Company cannot objectively determine the VSOE of the fair value of any undelivered software element, it defers revenue for all software components until all elements are delivered and services have been performed, until fair value can objectively be determined for any remaining undelivered elements, or until software maintenance is the only undelivered element, in which case revenue is recognized over the maintenance term for all software elements.

- removed (2017-06-09):
[0001571996-16-000021:note_history:172]
The Company allocates the amount of revenue recognized for delivered elements to the amount that is not subject to forfeiture or refund or contingent on the future delivery of products or services.

- removed (2017-06-09):
[0001571996-16-000021:note_history:173]
Customers under software maintenance agreements are entitled to receive updates and upgrades on a when-and-if-available basis, and various types of technical support based on the level of support purchased. In the event specific features, functionality, entitlements, or the release version of an upgrade or new product have been announced but not delivered, and customers will receive that upgrade or new product as part of a current software maintenance contract, a specified upgrade is deemed created and product revenues are deferred on purchases made after the announcement date until delivery of the upgrade or new product. The amount and elements to be deferred are dependent on whether the Company has established VSOE of fair value for the upgrade or new product.

- removed (2017-06-09):
[0001571996-16-000021:note_history:174]
Other

- removed (2017-06-09):
[0001571996-16-000021:note_history:175]
The Company records revenue from the sale of equipment under sales-type leases as product revenue in an amount equal to the present value of minimum lease payments at the inception of the lease.  Sales-type leases also produce financing income, which is included in net revenue in the Condensed Consolidated Statements of Income (Loss) and is recognized at consistent rates of return over the lease term.  Revenue from operating leases is recognized over the lease period. The Company also offers qualified customers revolving credit lines for the purchase of products and services offered by the Company.  Financing income attributable to these revolving loans is recognized in net revenue on an accrual basis.

- removed (2017-06-09):
[0001571996-16-000021:note_history:176]
The Company accrues for the estimated costs of systems’ warranty at the time of sale.  Systems’ warranty costs are estimated based upon historical experience and specific identification of systems’ requirements.

- removed (2017-06-09):
[0001571996-16-000021:note_history:177]
The Company reports revenue net of any revenue-based taxes assessed by governmental authorities that are imposed on and concurrent with specific revenue-producing transactions.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- added (2017-06-09):
[0001571996-17-000009:note_history:178]
Federal Income Taxes — In May 2017, the IRS commenced a federal income tax audit for fiscal years 2010 through 2014, which could take several years to complete.  Dell believes that adequate reserves have been provided related to all matters contained in tax periods open to examination.  For further discussion regarding tax matters, including the status of income tax audits, see Note 13 of the Notes to the Condensed Consolidated Financial Statements.

- changed (2017-06-09):
[0001571996-17-000009:note_history:179]
Other than the matters identified above, there were no known events occurring after the balance sheet date and up until the date of the issuance of this report that would materially affect the information presented herein.
  (was, 2016-12-09, similarity 0.9474):
[0001571996-16-000021:note_history:179]
Other than the items noted above, there were no known events occurring after the balance sheet date and up until the date of the issuance of this report that would materially affect the information presented herein.

- removed (2017-06-09):
[0001571996-16-000021:note_history:180]
Dell Software Group Divestiture — On October 31, 2016, the parties closed the DSG divestiture transaction.  Dell received total cash consideration for the sale of approximately $2.4 billion.  The Company expects to realize an estimated pre-tax gain on sale of $1.2 billion.

- removed (2017-06-09):
[0001571996-16-000021:note_history:181]
Dell Services Divestiture — On November 2, 2016, the parties closed the Dell Services divestiture transaction.  Dell received total cash consideration for the sale of approximately $3.0 billion. The Company expects to realize an estimated pre-tax gain on sale of $1.5 billion.

- removed (2017-06-09):
[0001571996-16-000021:note_history:182]
Repayment and Termination of Asset Sale Bridge Facility — On November 8, 2016, the Company applied cash proceeds from the sale of substantially all of the Company’s Dell Services business unit and the sale of substantially all of the Company’s Dell Software Group business unit to repay the outstanding $2.2 billion principal amount of the Asset Sale Bridge Facility without premium or penalty and accrued and unpaid interest thereon, and terminated the Asset Sale Bridge Facility and the Asset Sale Bridge Credit Agreement and related documents.

- removed (2017-06-09):
[0001571996-16-000021:note_history:183]
Repayment of Term Loan A-1 Facility — On November 8, 2016, the Company applied cash proceeds from the sale of substantially all of the Company’s Dell Services business unit and the sale of substantially all of the Company’s Dell Software Group business unit and other cash to repay approximately $2.1 billion principal amount of the Term Loan A-1 Facility without premium or penalty and accrued and unpaid interest thereon.

- removed (2017-06-09):
[0001571996-16-000021:note_history:184]
IRS Audit Settlement — On November 9, 2016, the Company effectively settled the IRS audit for fiscal years 2004 through 2006.  The settlement amount payable to the IRS in early 2017 is approximately $545 million and the Company expects to record an income tax benefit of approximately $300 million in the fourth quarter of Fiscal 2017.  However, the Company is currently evaluating the impact of the settlement on its uncertain tax positions; therefore, the actual amount of any tax impact to be recorded in future quarters is still uncertain.

- removed (2017-06-09):
[0001571996-16-000021:note_history:185]
Repayment of Revolving Credit Facility — On November 17, 2016, the Company repaid approximately $1 billion principal amount of the Revolving Credit Facility and accrued and unpaid interest thereon.
