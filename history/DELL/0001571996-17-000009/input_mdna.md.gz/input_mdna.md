# DELL MD&A — 0001571996-17-000009


## mdna

[0001571996-17-000009:mdna:1]
ITEM 2 — MANAGEMENT'S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS

[0001571996-17-000009:mdna:2]
Unless otherwise indicated, all results presented are prepared in a manner that complies, in all material respects, with accounting principles generally accepted in the United States of America ("GAAP").  Additionally, unless otherwise indicated, all changes identified for the current-period results represent comparisons to results for the prior corresponding fiscal period.

[0001571996-17-000009:mdna:3]
Unless the context indicates otherwise, references in this report to "we," "us," "our," the "Company," and "Dell Technologies" mean Dell Technologies Inc. and its consolidated subsidiaries, and references to "EMC" mean EMC Corporation and EMC Corporation's consolidated subsidiaries.

[0001571996-17-000009:mdna:4]
Our fiscal year is the 52- or 53-week period ending on the Friday nearest January 31.  We refer to our fiscal years ended February 2, 2018 and February 3, 2017 as "Fiscal 2018" and "Fiscal 2017" respectively.  Fiscal 2017 included 53 weeks, with the extra week included in the fourth quarter of Fiscal 2017.  Fiscal 2018 will include 52 weeks.

[0001571996-17-000009:mdna:5]
On September 7, 2016, we completed our acquisition by merger of EMC.  The consolidated results of EMC are included in Dell Technologies' consolidated results for the Fiscal 2018 period presented.  During Fiscal 2017, we closed the Dell Services, DSG, and ECD divestiture transactions.  Accordingly, the results of operations of Dell Services, DSG, and ECD, as well as the related gains or losses on sale, have been excluded from the results of continuing operations in the periods presented in this management's discussion and analysis, except as otherwise indicated.

[0001571996-17-000009:mdna:6]
[same as prior period, unchanged from 0001571996-16-000021:mdna:8]

[0001571996-17-000009:mdna:7]
Dell Technologies is a strategically aligned family of businesses that brings together the entire infrastructure from hardware to software to services — from the edge to the data center to the cloud.  Dell Technologies is a leader in the traditional technology of today and a leader in the cloud-native infrastructure of tomorrow.  We are a leading provider of scalable IT solutions enabling customers to be more efficient, mobile, informed, and secure.  Through our recent combination with EMC, Dell Technologies now primarily encompasses our Client Solutions Group, Infrastructure Solutions Group, VMware, Inc., RSA Information Security, SecureWorks Corp., Pivotal Software, Inc. and Boomi, Inc.  We are focused on providing technology solutions and services that accelerate digital transformation.  We believe technology exists to drive human progress on a global scale — to create new markets, reshape industries, and improve lives.  We are positioned to help customers of any size build the essential infrastructure to modernize IT and enable digital business, and are differentiated by our practical innovation and efficient, simple, and affordable solutions.

[0001571996-17-000009:mdna:8]
Dell Technologies is committed to our customers.  We believe our products, solutions, and services will help power digital transformation.  As we innovate to make our customers' existing IT increasingly productive, we help them reinvest their savings into the next generation of technologies that they need to succeed in the digital economy.  Our next-generation solutions which enable digital transformation include software-defined data centers, all flash arrays, hybrid cloud, converged and hyper-converged infrastructure, mobile, and security solutions.  In addition, our extended warranty and delivery offerings, and software and peripherals, which are closely tied to the sale of our hardware products, are important value differentiators that we are able to offer our customers.

[0001571996-17-000009:mdna:9]
We are actively working on the integration of EMC acquired businesses, and our combined go-to-market initiatives.  During this period of transition and integration, we remain focused on supporting our customers with outstanding solutions, products, and services.  We will continue our focus on building superior customer relationships through our direct model and our network of channel partners, which includes value-added resellers, system integrators, distributors, and retailers.  We also will continue investing in strategic solutions and enhancing our go-to-market sales and marketing capabilities as we seek to create a leading global technology company poised for long-term sustainable growth and innovation.

[0001571996-17-000009:mdna:10]
57

[0001571996-17-000009:mdna:11]
[same as prior period, unchanged from 0001571996-16-000021:mdna:13]

[0001571996-17-000009:mdna:12]
| • | To extend our market leading position through our Client Solutions Group and Infrastructure Solutions Group offerings, both on- and off-premises |

[0001571996-17-000009:mdna:13]
[same as prior period, unchanged from 0001571996-16-000021:mdna:15]

[0001571996-17-000009:mdna:14]
| • | To innovate with winning technology that spans and unites on- and off-premises applications and infrastructure and that enables workforce transformation required by our customers |

[0001571996-17-000009:mdna:15]
As part of this strategy, we will continue to evaluate opportunities for strategic investments and disciplined acquisitions with a focus on emerging technology areas that are relevant to the Dell Technologies' unique family of businesses and that will complement our existing portfolio of solutions.  Our investment areas include storage, software-defined networking, management and orchestration, security, machine learning and artificial intelligence, Big Data and analytics, cloud, Internet of Things, and software development operations.

[0001571996-17-000009:mdna:16]
We operate a diversified business model with the majority of our net revenue and operating income derived from commercial clients that consist of large enterprises, small and medium-sized businesses, and public sector customers.

[0001571996-17-000009:mdna:17]
[same as prior period, unchanged from 0001571996-16-000021:mdna:19]

[0001571996-17-000009:mdna:18]
We design, develop, manufacture, market, sell, and support a wide range of products and services.  We are organized into the following business units, which are our reportable segments: Client Solutions Group; Infrastructure Solutions Group; and VMware.  Due to our divestitures of Dell Services, Dell Software Group, and Dell EMC Enterprise Content Division, the results of these businesses, as well as the related gains or losses on sale, have been excluded from this management's discussion and analysis for all periods presented, except as otherwise indicated.

[0001571996-17-000009:mdna:19]
| • | Client Solutions Group (CSG) — Offerings by CSG include branded hardware, such as desktop PCs and notebooks, and branded peripherals, such as monitors, printers, and projectors. CSG also offers attached software, peripherals and services, including support and deployment, configuration, and extended warranty services. |

[0001571996-17-000009:mdna:20]
Approximately half of CSG revenue is generated by sales to customers in the Americas, with the remaining portion derived from sales to customers in the Europe, Middle East and Africa region ("EMEA") and the Asia‑Pacific and Japan region ("APJ").

[0001571996-17-000009:mdna:21]
| • | Infrastructure Solutions Group (ISG) — EMC's Information Storage segment and our existing Enterprise Solutions Group were merged to create the Infrastructure Solutions Group, or ISG. The comprehensive portfolio of advanced storage solutions includes traditional storage solutions as well as next-generation storage solutions (including all flash arrays, scale-out file and object platforms). The server portfolio includes high-performance rack, blade, tower, and hyperscale servers. The networking portfolio will help our business customers transform and modernize their infrastructure, mobilize and enrich end-user experiences, and accelerate business applications and processes. Similar to CSG, ISG also offers attached software, peripherals, and services, including support and deployment, configuration, and extended warranty services. |

[0001571996-17-000009:mdna:22]
Approximately half of ISG revenue is generated by sales to customers in the Americas, with the remaining portion derived from sales to customers in EMEA and APJ.

[0001571996-17-000009:mdna:23]
| • | VMware — The VMware reportable segment ("VMware") reflects the operations of VMware, Inc. (NYSE: VMW) within Dell Technologies. See Exhibit 99.1 filed with this report for further details on the differences between VMware reportable segment results and VMware, Inc. results. |

[0001571996-17-000009:mdna:24]
VMware is a leader in virtualization and cloud infrastructure solutions, which enable organizations to manage IT resources across complex multi-cloud, multi-device environments.  VMware offers a broad portfolio of virtualization technologies across three main product groups: software-defined data center; hybrid cloud computing; and end-user computing.

[0001571996-17-000009:mdna:25]
[same as prior period, unchanged from 0001571996-16-000021:mdna:28]

[0001571996-17-000009:mdna:26]
Our other businesses, described below, consist of product and service offerings of RSA Information Security, SecureWorks, Pivotal, and Boomi.  These businesses are not classified as reportable segments, either individually or collectively, as the results of the businesses are not material to our overall results and the businesses do not meet the criteria for reportable segments.

[0001571996-17-000009:mdna:27]
[same as prior period, unchanged from 0001571996-16-000021:mdna:30]

[0001571996-17-000009:mdna:28]
| • | SecureWorks (NASDAQ: SCWX) is a leading global provider of intelligence-driven information security solutions singularly focused on protecting its clients from cyber attacks. |

[0001571996-17-000009:mdna:29]
| • | Pivotal is a leading provider of application and data infrastructure software, agile development services, and data science consulting. Pivotal's cloud-native platform enables leading companies to transform their operations with an approach that is focused on building software, rather than buying it. |

[0001571996-17-000009:mdna:30]
[same as prior period, unchanged from 0001571996-16-000021:mdna:33]

[0001571996-17-000009:mdna:31]
See Note 19 of the Notes to the Condensed Consolidated Financial Statements included in this report for more information about our other businesses.

[0001571996-17-000009:mdna:32]
For further discussion regarding our current reportable segments, see "Results of Operations — Business Unit Results."

[0001571996-17-000009:mdna:33]
Dell Financial Services

[0001571996-17-000009:mdna:34]
We also offer or arrange various financing options and services for our commercial and consumer customers in the United States, Canada, Europe, and Mexico through Dell Financial Services ("DFS") and its affiliates.  DFS services include originating, collecting, and servicing customer receivables primarily related to the purchase of Dell Technologies products.  The results of these operations are allocated to our segments based on the underlying product or service financed.  For additional information about our financing arrangements, see Note 6 of the Notes to the Condensed Consolidated Financial Statements included in this report.

[0001571996-17-000009:mdna:35]
[same as prior period, unchanged from 0001571996-16-000021:mdna:37]

[0001571996-17-000009:mdna:36]
We are seeing an unprecedented rate of change in the IT industry.  Organizations of all kinds are embracing digital technology to achieve their business objectives.  Our vision is to be the essential infrastructure company and leader in end-user computing, data center infrastructure solutions, virtualization, and cloud software that our customers continue to trust and rely on for their IT solutions and transformations.  We accelerate results for our customers by enabling them to be more efficient, mobile, informed, and secure.  We continue to invest in research and development, sales, and other key areas of our business to deliver superior products and solutions capabilities and to drive execution of long-term profitable growth.  We believe that our results will benefit from an integrated go-to-market strategy, including enhanced coordination among the family of Dell Technologies companies, and from our differentiated products and solutions capabilities.  We intend to continue to execute on our business model and seek to balance liquidity, profitability, and growth to position our company for long-term success.

[0001571996-17-000009:mdna:37]
We are able to leverage our traditional strength in the PC market to offer solutions and services that provide higher value recurring revenue streams.  Given the macroeconomic environment and computing trends, we expect that the demand environment will continue to be uneven and cyclical and that market competition in our Client Solutions Group business will intensify.  However, we are committed to a long-term growth strategy that we believe will benefit from the consolidation trends that are occurring in our markets.  Our Client Solutions Group offerings remain an important element of our strategy, generating strong cash flow and opportunities for cross-selling of complementary solutions.

[0001571996-17-000009:mdna:38]
We expect that our Infrastructure Solutions Group will continue to be adversely affected by declines in the traditional storage and server markets.  Cloud-native applications are expected to continue as a primary growth driver in the infrastructure market as IT organizations increasingly become multi-cloud environments.  We believe the complementary cloud solutions across our business, created through our combination with EMC, strongly position us to meet these demands for our customers who are increasingly looking to leverage cloud-based computing.  Further, we will be able to provide new and more robust storage and data center solutions to meet the evolving needs of our customers.  We also continue to be impacted by the emerging trends of enterprises deploying software-defined storage, hyper-converged, and modular solutions based on server-centric architectures.

[0001571996-17-000009:mdna:39]
We are also seeing increased interest in "as a service" flexible consumption models by our customers as they seek to build greater flexibility into their cost structures.  We have responded to this interest by introducing various financing and consumption model offerings.

[0001571996-17-000009:mdna:40]
We have leading solutions in these categories through our ISG and VMware data center offerings.  In addition, through our research and development efforts, we expect to develop new solutions in this rapidly changing industry that we believe will enable us to continue to provide superior solutions to our customers.

[0001571996-17-000009:mdna:41]
We manage our business on a U.S. dollar basis.  However, we have a large global presence, generating approximately half of our revenue by sales to customers outside of the United States during the first three months of Fiscal 2018 and the first three months of Fiscal 2017.  Our revenues, therefore, can be impacted by fluctuations in foreign currency exchange rates.  We utilize a comprehensive hedging strategy intended to mitigate the impact of foreign currency volatility over time, and we adjust pricing when possible to further minimize foreign currency impacts.  The percentage of our revenues generated in regions outside of the United States did not change substantially as a result of the EMC merger transaction.

[0001571996-17-000009:mdna:42]
[same as prior period, unchanged from 0001571996-16-000021:mdna:42]

[0001571996-17-000009:mdna:43]
As described in Note 2 of the Notes to the Condensed Consolidated Financial Statements included in this report, on September 7, 2016, a merger subsidiary of Dell Technologies merged with and into EMC Corporation, with EMC Corporation surviving the merger as a wholly-owned subsidiary of Dell Technologies.

[0001571996-17-000009:mdna:44]
Pursuant to the terms of the merger agreement, upon the completion of the EMC merger transaction, each issued and outstanding share of common stock, par value $0.01 per share, of EMC (approximately 2.0 billion as of September 7, 2016) was converted into the right to receive (1) $24.05 in cash, without interest, and (2) 0.11146 validly issued, fully paid and non-assessable shares of common stock of the Company designated as Class V Common Stock, par value $0.01 per share, plus cash in lieu of any fractional shares.  Shares of the Class V Common Stock were approved for listing on the New York Stock Exchange (the "NYSE") under the ticker symbol "DVMT" and began trading on September 7, 2016.

[0001571996-17-000009:mdna:45]
In connection with the EMC merger transaction, all principal, accrued but unpaid interest, fees, and other amounts (other than certain contingent obligations) outstanding at the effective time of the EMC merger transaction under EMC's unsecured revolving credit facility, Dell's asset-based revolving credit facility, and Dell's term facilities were substantially repaid concurrently with the closing.  Further, all commitments to lend and guarantees and security interests, as applicable, in connection therewith were terminated or released.  The aggregate amounts of principal, interest, and premium necessary to redeem in full the outstanding $1.4 billion in aggregate principal amount of 5.625% Senior First Lien Notes due 2020 co-issued by Dell International and Denali Finance Corp. were deposited with the trustee for such notes, and such notes were thereby satisfied and discharged, concurrently with the effective time of the EMC merger transaction.  All of Dell's other outstanding senior notes and all of EMC's outstanding senior notes remained outstanding after the effective time of the EMC merger transaction in accordance with their respective terms.

[0001571996-17-000009:mdna:46]
Dell Technologies financed the EMC merger transaction, repayment of the foregoing indebtedness of EMC and Dell outstanding as of the closing of the EMC merger transaction, and the payment of related fees and expenses, with debt financing arrangements in an aggregate principal amount of approximately $45.9 billion, equity financing arrangements of approximately $4.4 billion, and cash on hand of approximately $7.8 billion.

[0001571996-17-000009:mdna:47]
See Note 2 and Note 7 to the Condensed Consolidated Financial Statements included in this report for additional information regarding the EMC merger transaction and the related financing transactions.

[0001571996-17-000009:mdna:48]
[same as prior period, unchanged from 0001571996-16-000021:mdna:61]

[0001571996-17-000009:mdna:49]
[same as prior period, unchanged from 0001571996-16-000021:mdna:62]

[0001571996-17-000009:mdna:50]
[same as prior period, unchanged from 0001571996-16-000021:mdna:63]

[0001571996-17-000009:mdna:51]
[same as prior period, unchanged from 0001571996-16-000021:mdna:64]

[0001571996-17-000009:mdna:52]
Non-GAAP product net revenue, non-GAAP services net revenue, non-GAAP net revenue, non-GAAP product gross margin, non-GAAP services gross margin, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP operating income, and non-GAAP net income from continuing operations, as defined by us, exclude the impact of purchase accounting, amortization of intangible assets, transaction-related expenses, other corporate expenses and, for non-GAAP net income, an aggregate adjustment for income taxes.  As the excluded items have a material impact on our financial results, our management compensates for this limitation by relying primarily on our GAAP results and using non-GAAP financial measures supplementally or for projections when comparable GAAP financial measures are not available.  The non-GAAP financial measures are not meant to be considered as indicators of performance in isolation from or as a substitute for net revenue, gross margin, operating expenses, operating income, or net income prepared in accordance with GAAP, and should be read only in conjunction with financial information presented on a GAAP basis.

[0001571996-17-000009:mdna:53]
[same as prior period, unchanged from 0001571996-16-000021:mdna:66]

[0001571996-17-000009:mdna:54]
[same as prior period, unchanged from 0001571996-16-000021:mdna:67]

[0001571996-17-000009:mdna:55]
| • | Impact of Purchase Accounting — The impact of purchase accounting includes purchase accounting adjustments, related to the EMC merger transaction and the acquisition of Dell Inc. by Dell Technologies Inc. on October 29, 2013, referred to as the going-private transaction, recorded under the acquisition method of accounting in accordance with the accounting guidance for business combinations. This guidance prescribes that the purchase price be allocated to assets acquired and liabilities assumed based on the estimated fair value of such assets and liabilities on the date of the transaction. Accordingly, all of the assets and liabilities acquired in the EMC merger transaction and the going-private transaction were accounted for and recognized at fair value as of the respective transaction dates, and the fair value adjustments are being amortized over the estimated useful lives in the periods following the transactions. The fair value adjustments primarily relate to deferred revenue, inventory, and property, plant, and equipment. The purchase accounting adjustments and related amortization of those adjustments are reflected in our GAAP results; however, we evaluate the operating results of the underlying businesses on a non-GAAP basis, after removing such adjustments. We believe that excluding the impact of purchase accounting provides results that are useful in understanding our current operating performance and provides more meaningful comparisons to our past operating performance. |

[0001571996-17-000009:mdna:56]
[same as prior period, unchanged from 0001571996-16-000021:mdna:70]

[0001571996-17-000009:mdna:57]
| • | Transaction-related Expenses — Transaction-related expenses consist of acquisition, integration, and divestiture related costs, and are expensed as incurred. These expenses primarily represent costs for legal, banking, consulting, and advisory services, as well as certain compensatory retention awards directly related to the EMC merger transaction and related integration. |

[0001571996-17-000009:mdna:58]
| • | Other Corporate Expenses — Other corporate expenses consists of severance, facility action costs, and stock-based compensation expense associated with equity awards. Severance costs are primarily related to severance and benefits for employees terminated pursuant to cost savings initiatives. Facility action costs included in the first three months of Fiscal 2018 were $79 million, and we expect to incur these costs over the next nine months as we continue to integrate owned and leased facilities and as we seek opportunities for operational efficiencies and cost savings. Other corporate expenses vary from period to period and are significantly impacted by the timing and nature of these events. Therefore, although we may incur these types of expenses in the future, we believe that eliminating these charges for purposes of calculating the non-GAAP financial measures presented below facilitates a more meaningful evaluation of our current operating performance and comparisons to our past operating performance. |

[0001571996-17-000009:mdna:59]
| • | Aggregate Adjustment for Income Taxes — The aggregate adjustment for income taxes is the estimated combined income tax effect for the adjustments described above. During the first quarter of Fiscal 2017, this category also includes tax charges of approximately $135 million on previously untaxed earnings of a foreign subsidiary that will no longer be permanently reinvested as a result of the Dell Services divestiture. The tax effects are determined based on the tax jurisdictions where the above items were incurred. |

[0001571996-17-000009:mdna:60]
62

[0001571996-17-000009:mdna:61]
The table below presents a reconciliation of each non-GAAP financial measure to the most directly comparable GAAP measure for each of the periods presented:

[0001571996-17-000009:mdna:62]
|  | Three Months Ended |
|  | May 5, 2017 |  | % Change |  | April 29, 2016 |
|  | (in millions, except percentages) |
| Product net revenue | $ | 12,968 |  |  | 27 | % |  | $ | 10,183 |  |
| Non-GAAP adjustments: |  |  |  |  |  |
| Impact of purchase accounting | 55 |  |  |  |  | (1 | ) |
| Non-GAAP product net revenue | $ | 13,023 |  |  | 28 | % |  | $ | 10,182 |  |
| Services net revenue | $ | 4,848 |  |  | 136 | % |  | $ | 2,058 |  |
| Non-GAAP adjustments: |  |  |  |  |  |
| Impact of purchase accounting | 300 |  |  |  |  | 79 |  |
| Non-GAAP services net revenue | $ | 5,148 |  |  | 141 | % |  | $ | 2,137 |  |
| Net revenue | $ | 17,816 |  |  | 46 | % |  | $ | 12,241 |  |
| Non-GAAP adjustments: |  |  |  |  |  |
| Impact of purchase accounting | 355 |  |  |  |  | 78 |  |
| Non-GAAP net revenue | $ | 18,171 |  |  | 48 | % |  | $ | 12,319 |  |
| Product gross margin | $ | 1,509 |  |  | 9 | % |  | $ | 1,384 |  |
| Non-GAAP adjustments: |  |  |  |  |  |
| Impact of purchase accounting | 65 |  |  |  |  | 12 |  |
| Amortization of intangibles | 950 |  |  |  |  | 101 |  |
| Transaction-related expenses | 2 |  |  |  |  | — |  |
| Other corporate expenses | 3 |  |  |  |  | 1 |  |
| Non-GAAP product gross margin | $ | 2,529 |  |  | 69 | % |  | $ | 1,498 |  |
| Services gross margin | $ | 2,793 |  |  | 245 | % |  | $ | 809 |  |
| Non-GAAP adjustments: |  |  |  |  |  |
| Impact of purchase accounting | 300 |  |  |  |  | 77 |  |
| Amortization of intangibles | — |  |  |  |  | — |  |
| Transaction-related expenses | 5 |  |  |  |  | (1 | ) |
| Other corporate expenses | 19 |  |  |  |  | 2 |  |
| Non-GAAP services gross margin | $ | 3,117 |  |  | 251 | % |  | $ | 887 |  |
| Gross margin | $ | 4,302 |  |  | 96 | % |  | $ | 2,193 |  |
| Non-GAAP adjustments: |  |  |  |  |  |
| Impact of purchase accounting | 365 |  |  |  |  | 89 |  |
| Amortization of intangibles | 950 |  |  |  |  | 101 |  |
| Transaction-related expenses | 7 |  |  |  |  | (1 | ) |
| Other corporate expenses | 22 |  |  |  |  | 3 |  |
| Non-GAAP gross margin | $ | 5,646 |  |  | 137 | % |  | $ | 2,385 |  |

[0001571996-17-000009:mdna:63]
63

[0001571996-17-000009:mdna:64]
|  | Three Months Ended |
|  | May 5, 2017 |  | % Change |  | April 29, 2016 |
|  | (in millions, except percentages) |
| Operating expenses | $ | 5,802 |  |  | 149 | % |  | $ | 2,332 |  |
| Non-GAAP adjustments: |  |  |  |  |  |
| Impact of purchase accounting | (58 | ) |  |  |  | (17 | ) |
| Amortization of intangibles | (826 | ) |  |  |  | (390 | ) |
| Transaction-related expenses | (184 | ) |  |  |  | (58 | ) |
| Other corporate expenses | (285 | ) |  |  |  | (21 | ) |
| Non-GAAP operating expenses | $ | 4,449 |  |  | 141 | % |  | $ | 1,846 |  |
| Operating loss | $ | (1,500 | ) |  | (979 | )% |  | $ | (139 | ) |
| Non-GAAP adjustments: |  |  |  |  |  |
| Impact of purchase accounting | 423 |  |  |  |  | 106 |  |
| Amortization of intangibles | 1,776 |  |  |  |  | 491 |  |
| Transaction-related expenses | 191 |  |  |  |  | 57 |  |
| Other corporate expenses | 307 |  |  |  |  | 24 |  |
| Non-GAAP operating income | $ | 1,197 |  |  | 122 | % |  | $ | 539 |  |
| Net loss from continuing operations | $ | (1,383 | ) |  | (226 | )% |  | $ | (424 | ) |
| Non-GAAP adjustments: |  |  |  |  |  |
| Impact of purchase accounting | 423 |  |  |  |  | 106 |  |
| Amortization of intangibles | 1,776 |  |  |  |  | 491 |  |
| Transaction-related expenses | 191 |  |  |  |  | 57 |  |
| Other corporate expenses | 307 |  |  |  |  | 24 |  |
| Aggregate adjustment for income taxes | (733 | ) |  |  |  | 10 |  |
| Non-GAAP net income from continuing operations | $ | 581 |  |  | 120 | % |  | $ | 264 |  |

[0001571996-17-000009:mdna:65]
In addition to the above measures, we also use EBITDA and adjusted EBITDA to provide additional information for evaluation of our operating performance.  Adjusted EBITDA excludes purchase accounting adjustments related to the EMC merger transaction and the going-private transaction, acquisition, integration, and divestiture-related costs, severance and facility actions, and stock-based compensation expense.  We believe that, due to the non-operational nature of the purchase accounting entries, it is appropriate to exclude these adjustments.

[0001571996-17-000009:mdna:66]
As is the case with the non-GAAP measures presented above, users should consider the limitations of using EBITDA and adjusted EBITDA, including the fact that those measures do not provide a complete measure of our operating performance.  EBITDA and adjusted EBITDA do not purport to be alternatives to net income (loss) as measures of operating performance or to cash flows from operating activities as a measure of liquidity.  In particular, EBITDA and adjusted EBITDA are not intended to be a measure of free cash flow available for management's discretionary use, as these measures do not consider certain cash requirements, such as working capital needs, capital expenditures, contractual commitments, interest payments, tax payments, and other debt service requirements.

[0001571996-17-000009:mdna:67]
[same as prior period, unchanged from 0001571996-16-000021:mdna:81]

[0001571996-17-000009:mdna:68]
|  | Three Months Ended |
|  | May 5, 2017 |  | % Change |  | April 29, 2016 |
|  | (in millions, except percentages) |
| Net loss from continuing operations | $ | (1,383 | ) |  | (226 | )% |  | $ | (424 | ) |
| Adjustments: |  |  |  |  |  |
| Interest and other, net (a) | 573 |  |  |  |  | 219 |  |
| Income tax provision (benefit) | (690 | ) |  |  |  | 66 |  |
| Depreciation and amortization | 2,212 |  |  |  |  | 618 |  |
| EBITDA | $ | 712 |  |  | 49 | % |  | $ | 479 |  |
| EBITDA | $ | 712 |  |  | 49 | % |  | $ | 479 |  |
| Adjustments: |  |  |  |  |  |
| Stock-based compensation expense | 201 |  |  |  |  | 14 |  |
| Impact of purchase accounting (b) | 357 |  |  |  |  | 83 |  |
| Transaction-related expenses (c) | 191 |  |  |  |  | 57 |  |
| Other corporate expenses (d) | 106 |  |  |  |  | 10 |  |
| Adjusted EBITDA | $ | 1,567 |  |  | 144 | % |  | $ | 643 |  |

[0001571996-17-000009:mdna:69]
[same as prior period, unchanged from 0001571996-16-000021:mdna:83]

[0001571996-17-000009:mdna:70]
[same as prior period, unchanged from 0001571996-16-000021:mdna:84]

[0001571996-17-000009:mdna:71]
[same as prior period, unchanged from 0001571996-16-000021:mdna:85]

[0001571996-17-000009:mdna:72]
| (c) | Transaction-related expenses consist of acquisition, integration, and divestiture related costs. |

[0001571996-17-000009:mdna:73]
[same as prior period, unchanged from 0001571996-16-000021:mdna:87]

[0001571996-17-000009:mdna:74]
65

[0001571996-17-000009:mdna:75]
[same as prior period, unchanged from 0001571996-16-000021:mdna:89]

[0001571996-17-000009:mdna:76]
[same as prior period, unchanged from 0001571996-16-000021:mdna:90]

[0001571996-17-000009:mdna:77]
The following table summarizes our consolidated results from continuing operations for each of the periods presented.  Unless otherwise indicated, all changes identified for the current-period results represent comparisons to results for the prior corresponding fiscal period.

[0001571996-17-000009:mdna:78]
|  |  | Three Months Ended |
|  |  | May 5, 2017 |  |  |  | April 29, 2016 |
|  |  | Dollars |  | % ofNet Revenue |  | %Change |  | Dollars |  | % ofNet Revenue |
|  |  | (in millions, except percentages) |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 12,968 |  |  | 72.8 | % |  | 27% |  | $ | 10,183 |  |  | 83.2 | % |
| Services |  | 4,848 |  |  | 27.2 | % |  | 136% |  | 2,058 |  |  | 16.8 | % |
| Total net revenue |  | $ | 17,816 |  |  | 100.0 | % |  | 46% |  | $ | 12,241 |  |  | 100.0 | % |
| Gross margin: |  |  |  |  |  |  |  |  |  |  |
| Product (a) |  | $ | 1,509 |  |  | 11.6 | % |  | 9% |  | $ | 1,384 |  |  | 13.6 | % |
| Services (b) |  | 2,793 |  |  | 57.6 | % |  | 245% |  | 809 |  |  | 39.3 | % |
| Total gross margin |  | $ | 4,302 |  |  | 24.1 | % |  | 96% |  | $ | 2,193 |  |  | 17.9 | % |
| Operating expenses |  | $ | 5,802 |  |  | 32.6 | % |  | 149% |  | $ | 2,332 |  |  | 19.1 | % |
| Operating loss |  | $ | (1,500 | ) |  | (8.4 | )% |  | (979)% |  | $ | (139 | ) |  | (1.1 | )% |
| Net loss from continuing operations |  | $ | (1,383 | ) |  | (7.8 | )% |  | (226)% |  | $ | (424 | ) |  | (3.5 | )% |
| Net loss attributable to Dell Technologies Inc. |  | $ | (1,334 | ) |  | (7.5 | )% |  | NM |  | $ | 55 |  |  | 0.4 | % |
| Other Financial Information |  |  |  |  |  |  |  |  |  |  |
| Non-GAAP net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 13,023 |  |  | 71.7 | % |  | 28% |  | $ | 10,182 |  |  | 82.7 | % |
| Services |  | 5,148 |  |  | 28.3 | % |  | 141% |  | 2,137 |  |  | 17.3 | % |
| Total non-GAAP net revenue |  | $ | 18,171 |  |  | 100.0 | % |  | 48% |  | $ | 12,319 |  |  | 100.0 | % |
| Non-GAAP gross margin: |  |  |  |  |  |  |  |  |  |  |  |
| Product (a) |  | $ | 2,529 |  |  | 19.4 | % |  | 69% |  | $ | 1,498 |  |  | 14.7 | % |
| Services (b) |  | 3,117 |  |  | 60.5 | % |  | 251% |  | 887 |  |  | 41.5 | % |
| Total non-GAAP gross margin |  | $ | 5,646 |  |  | 31.1 | % |  | 137% |  | $ | 2,385 |  |  | 19.4 | % |
| Non-GAAP operating expenses |  | $ | 4,449 |  |  | 24.5 | % |  | 141% |  | $ | 1,846 |  |  | 15.0 | % |
| Non-GAAP operating income |  | $ | 1,197 |  |  | 6.6 | % |  | 122% |  | $ | 539 |  |  | 4.4 | % |
| Non-GAAP net income from continuing operations |  | $ | 581 |  |  | 3.2 | % |  | 120% |  | $ | 264 |  |  | 2.1 | % |
| EBITDA |  | $ | 712 |  |  | 3.9 | % |  | 49% |  | $ | 479 |  |  | 3.9 | % |
| Adjusted EBITDA |  | $ | 1,567 |  |  | 8.6 | % |  | 144% |  | $ | 643 |  |  | 5.2 | % |

[0001571996-17-000009:mdna:79]
[same as prior period, unchanged from 0001571996-16-000021:mdna:157]

[0001571996-17-000009:mdna:80]
| (a) | Product gross margin percentages represent product gross margin as a percentage of product net revenue, and non-GAAP product gross margin as a percentage of non-GAAP product net revenue. |

[0001571996-17-000009:mdna:81]
| (b) | Services gross margin percentages represent services gross margin as a percentage of services net revenue, and non-GAAP services gross margin as a percentage of non-GAAP services net revenue. |

[0001571996-17-000009:mdna:82]
| NM | Not meaningful. |

[0001571996-17-000009:mdna:83]
66

[0001571996-17-000009:mdna:84]
Non-GAAP product net revenue, non-GAAP services net revenue, non-GAAP net revenue, non-GAAP product gross margin, non-GAAP services gross margin, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP operating income, non-GAAP net income from continuing operations, EBITDA, and adjusted EBITDA are not measurements of financial performance prepared in accordance with GAAP.  Non-GAAP financial measures as a percentage of revenue are calculated based on non-GAAP net revenue.  See "Non-GAAP Financial Measures" for information about these non-GAAP financial measures, including our reasons for including these measures, material limitations with respect to the usefulness of the measures, and a reconciliation of each non-GAAP financial measure to the most directly comparable GAAP financial measure.

[0001571996-17-000009:mdna:85]
As a result of the EMC merger transaction completed on September 7, 2016 and its impact on the first quarter of Fiscal 2018, our results for the fiscal periods discussed below are not directly comparable.

[0001571996-17-000009:mdna:86]
[same as prior period, unchanged from 0001571996-16-000021:mdna:95]

[0001571996-17-000009:mdna:87]
During the first quarter of Fiscal 2018, our net revenue and non-GAAP net revenue increased 46% and 48%, respectively.  The increase in net revenue and non-GAAP net revenue was primarily attributable to revenue from the EMC acquired businesses and, to a lesser extent, an increase in revenue from CSG.  The EMC merger transaction had an impact on the mix of revenue contributed by our business units.  CSG net revenue represented approximately 50% of our net revenue during the first quarter of Fiscal 2018.  In comparison, CSG net revenue represented a higher proportion of our revenue prior to the EMC merger transaction, accounting for approximately 70% of our net revenue during the first quarter of Fiscal 2017.

[0001571996-17-000009:mdna:88]
During the first quarters of Fiscal 2018 and Fiscal 2017, our operating loss was $1.5 billion and $0.1 billion, respectively.  The increase in our operating loss for the first quarter of Fiscal 2018 was primarily attributable to an increase in amortization of intangible assets and purchase accounting adjustments related to the EMC merger transaction, as well as an increase in compensation and benefits expense as a result of growth in our headcount.  The impact of the increase in operating expenses was partially offset by the favorable impact of gross margin from the EMC acquired businesses.

[0001571996-17-000009:mdna:89]
Our operating loss was impacted by purchase accounting adjustments associated with the EMC merger transaction and the going-private transaction, amortization of intangible assets, transaction-related expenses, and other corporate expenses.  In aggregate, these items totaled $2.7 billion and $0.7 billion for the first quarters of Fiscal 2018 and Fiscal 2017, respectively.  Excluding these adjustments, non-GAAP operating income increased 122% to $1.2 billion during the first quarter of Fiscal 2018.  The increase in non-GAAP operating income in the first quarter of Fiscal 2018 was primarily attributable to the favorable impact of non-GAAP operating income from the EMC acquired businesses, particularly VMware.

[0001571996-17-000009:mdna:90]
Cash provided by operating activities was $0.2 billion during the first quarter of Fiscal 2018.  Positive operating cash flows were driven by profitability, particularly in VMware.  See "Market Conditions, Liquidity, and Capital Commitments" for further information on our cash flow metrics.

[0001571996-17-000009:mdna:91]
[same as prior period, unchanged from 0001571996-16-000021:mdna:100]

[0001571996-17-000009:mdna:92]
During the first quarter of Fiscal 2018, our net revenue increased 46% primarily due to revenue from the EMC acquired businesses, offset partially by an increase in purchase accounting adjustments as a result of the EMC merger transaction.  Our non-GAAP net revenue increased 48% during the first quarter of Fiscal 2018, primarily due to the impact from the EMC acquired businesses.  An increase of 6% in CSG net revenue also contributed to higher net revenue and non-GAAP net revenue during the first quarter of Fiscal 2018, but to a lesser extent.  See "Business Unit Results — Client Solutions Group" for further information.

[0001571996-17-000009:mdna:93]
| • | Product Net Revenue — Product net revenue includes revenue from the sale of hardware products and Dell Technologies-owned software licenses. During the first quarter of Fiscal 2018, product net revenue increased 27% and non-GAAP product net revenue increased 28% primarily due to the impact from the EMC acquired businesses. |

[0001571996-17-000009:mdna:94]
| • | Services Net Revenue — Services net revenue includes revenue from our services offerings, third-party software license sales, and support services related to Dell Technologies-owned software and hardware. During the first quarter of Fiscal 2018, services net revenue increased 136% and non-GAAP services net revenue increased 141% primarily due to the impact from the EMC acquired businesses. |

[0001571996-17-000009:mdna:95]
See "Business Unit Results" for further information regarding revenue from our products, services, and software offerings.

[0001571996-17-000009:mdna:96]
From a geographical perspective, net revenue generated by sales to customers in all regions increased during the first quarter of Fiscal 2018 primarily as a result of the impact from the EMC acquired businesses.  Our mix of revenues generated in the Americas, EMEA, and APJ did not change substantially as a result of the EMC merger transaction.

[0001571996-17-000009:mdna:97]
[same as prior period, unchanged from 0001571996-16-000021:mdna:106]

[0001571996-17-000009:mdna:98]
During the first quarter of Fiscal 2018, our gross margin increased 96% to $4.3 billion, and our gross margin percentage increased 620 basis points to 24.1%.  The increase in our gross margin and gross margin percentage was primarily attributable to incremental gross margin from the EMC acquired businesses, which had higher gross margin percentages.  This increase was partially offset by the higher impact of purchase accounting and amortization of intangibles as a result of the EMC merger transaction.

[0001571996-17-000009:mdna:99]
Our gross margin for Fiscal 2018 included the effect of $1.3 billion of purchase accounting adjustments and amortization of intangibles related to the EMC merger transaction and the going-private transaction.  In comparison, the impact of purchase accounting and amortization of intangibles totaled $0.2 billion in the first quarter of Fiscal 2017, and in this period related only to the going-private transaction.  Excluding these costs, transaction-related expenses and other corporate expenses,  non-GAAP gross margin increased 137% to $5.6 billion and our non-GAAP gross margin percentage increased 1,170 basis points to 31.1%.  The increase in our non-GAAP gross margin and non-GAAP gross margin percentage was primarily due to the impact from the EMC acquired businesses, which had higher gross margin percentages.

[0001571996-17-000009:mdna:100]
| • | Products — During the first quarter of Fiscal 2018, product gross margin increased 9% to $1.5 billion, and product gross margin percentage decreased 200 basis points to 11.6%. The increase in product gross margin was driven primarily by additional product gross margin from the EMC acquired businesses, which was largely offset by an increase in amortization of intangibles related to the EMC merger transaction. The decrease in product gross margin percentage was primarily driven by an increase in amortization of intangibles and, to a lesser extent, a decrease in CSG product gross margin. |

[0001571996-17-000009:mdna:101]
During the first quarter of Fiscal 2018, non-GAAP product gross margin increased 69% to $2.5 billion, and non-GAAP product gross margin percentage increased 470 basis points to 19.4%.  The increase in non-GAAP product gross margin and non-GAAP product gross margin percentage were primarily attributable to the incremental product gross margin from the EMC acquired businesses, which had higher gross margin percentages.

[0001571996-17-000009:mdna:102]
| • | Services — During the first quarter of Fiscal 2018, our services gross margin increased 245% to $2.8 billion, and our services gross margin percentage increased 1,830 basis points to 57.6%. The increase in services gross margin was primarily attributable to gross margin from the EMC acquired businesses. Purchase accounting adjustments totaled $0.3 billion during the first quarter of Fiscal 2018, compared to $0.1 billion during the first quarter of Fiscal 2017. Excluding these costs, transaction-related expenses and other corporate expenses, non-GAAP gross margin dollars for services increased 251% to $3.1 billion and services gross margin percentage increased 1,900 basis points to 60.5%. |

[0001571996-17-000009:mdna:103]
[same as prior period, unchanged from 0001571996-16-000021:mdna:117]

[0001571996-17-000009:mdna:104]
Our gross margin is affected by our ability to achieve competitive pricing with our vendors and contract manufacturers, including through our negotiation of a variety of vendor rebate programs to achieve lower net costs for the various components we include in our products.  Under these programs, vendors provide us with rebates or other discounts from the list prices for the components, which are generally elements of their pricing strategy.  We account for vendor rebates and other discounts as a reduction in cost of net revenue.  We manage our costs on a total net cost basis, which includes supplier list prices reduced by vendor rebates and other discounts.

[0001571996-17-000009:mdna:105]
The terms and conditions of our vendor rebate programs are largely based on product volumes and are generally negotiated either at the beginning of the annual or quarterly period, depending on the program.  The timing and amount of vendor rebates and other discounts we receive under the programs may vary from period to period, reflecting changes in the competitive environment.  We monitor our component costs and seek to address the effects of any changes to terms that might arise under our vendor rebate programs.  Our gross margins for the first quarters of Fiscal 2018 and Fiscal 2017 were not materially affected by any changes to the terms of our vendor rebate programs, as the amounts we received under these programs were generally stable relative to our total net cost.  We are not aware of any significant changes to vendor pricing or rebate programs that may impact our results in the near term.

[0001571996-17-000009:mdna:106]
In addition, we have pursued legal action against certain vendors and are currently involved in negotiations with other vendors regarding their past pricing practices.  We have negotiated settlements with some of these vendors and may have additional settlements in future periods.  These settlements are allocated to our segments based on the relative amount of affected vendor products sold by each segment.  No such settlements were recorded in the first quarter of Fiscal 2018 that would have a material impact on product gross margins in the current quarter or affect comparability with product gross margin in the first quarter of Fiscal 2017.

[0001571996-17-000009:mdna:107]
[same as prior period, unchanged from 0001571996-16-000021:mdna:122]

[0001571996-17-000009:mdna:108]
[same as prior period, unchanged from 0001571996-16-000021:mdna:123]

[0001571996-17-000009:mdna:109]
|  |  | Three Months Ended |
|  |  | May 5, 2017 |  |  |  | April 29, 2016 |
|  |  | Dollars |  | % ofNet Revenue |  | %Change |  | Dollars |  | % ofNet Revenue |
|  |  | (in millions, except percentages) |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |
| Selling, general, and administrative |  | $ | 4,669 |  |  | 26.2 | % |  | 126% |  | $ | 2,068 |  |  | 16.9 | % |
| Research and development |  | 1,133 |  |  | 6.4 | % |  | 329% |  | 264 |  |  | 2.2 | % |
| Total operating expenses |  | $ | 5,802 |  |  | 32.6 | % |  | 149% |  | $ | 2,332 |  |  | 19.1 | % |
| Other Financial Information |  |  |  |  |  |  |  |  |  |  |
| Non-GAAP operating expenses |  | $ | 4,449 |  |  | 24.5 | % |  | 141% |  | $ | 1,846 |  |  | 15.0 | % |

[0001571996-17-000009:mdna:110]
During the first quarter of Fiscal 2018, our total operating expenses increased 149%.  The increase in total operating expenses was primarily due to incremental operating costs of the EMC acquired businesses.  Our operating expenses include the impact of purchase accounting associated with the EMC merger transaction and the going-private transaction, amortization of intangible assets, transaction-related expenses, and other corporate expenses.  In aggregate, these items totaled $1.4 billion and $0.5 billion for Fiscal 2018 and Fiscal 2017, respectively.  Excluding these costs, total non-GAAP operating expenses increased 141% primarily due to the impact from the EMC acquired businesses.

[0001571996-17-000009:mdna:111]
| • | Selling, General, and Administrative — Selling, general, and administrative ("SG&A") expenses increased 126% during the first quarter of Fiscal 2018. The increases in SG&A expenses were primarily driven by incremental operating costs of the EMC acquired businesses. |

[0001571996-17-000009:mdna:112]
| • | Research and Development — Research and development ("R&D") expenses are primarily composed of personnel-related expenses related to product development. R&D expenses were approximately 6.4% and 2.2% of net revenue for the first quarters of Fiscal 2018 and Fiscal 2017, respectively. The increases in R&D expenses were attributable to the expansion of our R&D capability through the EMC merger transaction. As our industry continues to change and as the needs of our customers evolve, we intend to support R&D initiatives to innovate and introduce new and enhanced solutions into the market. |

[0001571996-17-000009:mdna:113]
We will continue to balance our efforts to drive cost efficiencies in the business with strategic investments in areas that will enable growth, such as our sales force, marketing, and R&D.

[0001571996-17-000009:mdna:114]
[same as prior period, unchanged from 0001571996-16-000021:mdna:130]

[0001571996-17-000009:mdna:115]
Our operating loss was $1.5 billion and $0.1 billion during the first quarters of Fiscal 2018 and Fiscal 2017, respectively.  The increase in operating loss was primarily attributable to higher operating expenses, partially offset by increases in gross margin.  Our operating loss includes the impact of purchase accounting associated with the EMC merger transaction and the going-private transaction, amortization of intangible assets, transaction-related expenses, and other corporate expenses.  In aggregate, these items totaled $2.7 billion and $0.7 billion for the first quarters of Fiscal 2018 and Fiscal 2017, respectively.  Excluding these costs, non-GAAP operating income increased 122% to $1.2 billion during Fiscal 2018.  The increase in non-GAAP

[0001571996-17-000009:mdna:116]
69

[0001571996-17-000009:mdna:117]
operating income was primarily attributable to an increase in gross margin, which was partially offset by higher operating expenses from the EMC acquired businesses.

[0001571996-17-000009:mdna:118]
[same as prior period, unchanged from 0001571996-16-000021:mdna:133]

[0001571996-17-000009:mdna:119]
[same as prior period, unchanged from 0001571996-16-000021:mdna:134]

[0001571996-17-000009:mdna:120]
|  | Three Months Ended |
|  | May 5, 2017 |  | April 29, 2016 |
|  | (in millions) |
| Interest and other, net: |  |  |  |  |  |
| Investment income, primarily interest | $ | 38 |  |  | $ | 9 |  |
| Gain (loss) on investments, net | (1 | ) |  | — |  |
| Interest expense | (597 | ) |  | (163 | ) |
| Foreign exchange | (27 | ) |  | (42 | ) |
| Other | 14 |  |  | (23 | ) |
| Total interest and other, net | $ | (573 | ) |  | $ | (219 | ) |

[0001571996-17-000009:mdna:121]
During the first quarter of Fiscal 2018, changes in interest and other, net were unfavorable by $0.4 billion, primarily due to an increase in interest expense from higher average debt balances from debt issued in connection with the EMC merger transaction.  See Note 7 of the Notes to the Condensed Consolidated Financial Statements included in this report for further information regarding our debt.

[0001571996-17-000009:mdna:122]
[same as prior period, unchanged from 0001571996-16-000021:mdna:137]

[0001571996-17-000009:mdna:123]
Our effective income tax rates for continuing operations were 33.3% and (18.4)% on pre-tax losses from continuing operations of $2.1 billion and $0.4 billion for the first quarters of Fiscal 2018 and Fiscal 2017, respectively.  The change in our effective income tax rate for the first quarter of Fiscal 2018 was primarily attributable to prior year tax charges recognized in the first quarter of Fiscal 2017 relating to the divestiture of Dell Services, as well as tax benefits from charges associated with the EMC merger transaction incurred in the first quarter of Fiscal 2018, including purchase accounting adjustments, interest charges, and stock-based compensation expense.  See Note 2 of the Notes to the Condensed Consolidated Financial Statements included in this report for more information on the EMC merger transaction.  The income tax rate for future quarters of Fiscal 2018 will be impacted by the actual mix of jurisdictions in which income is generated.

[0001571996-17-000009:mdna:124]
Our effective tax rate can fluctuate depending on the geographic distribution of our world-wide earnings, as our foreign earnings are generally taxed at lower rates than in the United States.  In certain jurisdictions, our tax rate is significantly less than the applicable statutory rate as a result of tax holidays.  The majority of our foreign income that is subject to these tax holidays and lower tax rates is attributable to Singapore, China, and Malaysia.  A significant portion of these income tax benefits relate to a tax holiday that expires in January 2019.  Our other tax holidays will expire in whole or in part during Fiscal 2019 through Fiscal 2023.  Many of these tax holidays and reduced tax rates may be extended when certain conditions are met or may be terminated early if certain conditions are not met.  The differences between our effective tax rate and the U.S. federal statutory rate of 35% principally resulted from the geographical distribution of taxable income discussed above and permanent differences between the book and tax treatment of certain items.  We continue to assess our business model and its impact in various taxing jurisdictions.

[0001571996-17-000009:mdna:125]
For further discussion regarding tax matters, including the status of income tax audits, see Note 13 and Note 21 of the Notes to the Condensed Consolidated Financial Statements included in this report.

[0001571996-17-000009:mdna:126]
[same as prior period, unchanged from 0001571996-16-000021:mdna:144]

[0001571996-17-000009:mdna:127]
During the first quarter of Fiscal 2018, net loss from continuing operations increased 226% to a net loss of $1.4 billion.  The increase in net loss from continuing operations for the first quarter of Fiscal 2018 was primarily attributable to an increase in operating loss and to an increase in interest and other, net expense.  The effect of these factors was partially offset by an increase in tax benefit during the period.  See Note 13 of the Notes to the Condensed Consolidated Financial Statements included in this report for more information regarding our effective tax rate.

[0001571996-17-000009:mdna:128]
Net loss from continuing operations for the first quarter of Fiscal 2018 included amortization of intangible assets, the impact of purchase accounting, transaction-related expenses, and other corporate expenses.  Excluding these costs, non-GAAP net income from continuing operations increased 120% to $0.6 billion during the first quarter of Fiscal 2018.  The increase in non-GAAP net income from continuing operations during the first quarter of Fiscal 2018 was primarily attributable to an increase in operating income, the effect of which was partially offset by an increase in interest and other, net expense.

[0001571996-17-000009:mdna:129]
[same as prior period, unchanged from 0001571996-16-000021:mdna:147]

[0001571996-17-000009:mdna:130]
During the first quarter of Fiscal 2018, net loss attributable to the non-controlling interests was $49 million.  Net loss attributable to the non-controlling interests was primarily attributable to the net loss attributable to the non-controlling interest in VMware, Inc. of $45 million.  During the first quarter of Fiscal 2017, Dell Technologies had an immaterial amount of non-controlling interest related to SecureWorks, which completed a registered underwritten initial public offering of its Class A common stock on April 27, 2016.  For more information about our non-controlling interests, see Note 15 of the Notes to the Condensed Consolidated Financial Statements included in this report.

[0001571996-17-000009:mdna:131]
Net Income/Loss Attributable to Dell Technologies Inc.

[0001571996-17-000009:mdna:132]
Net loss attributable to Dell Technologies Inc. represents net income/loss from continuing operations, and an adjustment for non-controlling interests, and, in Fiscal 2017, an adjustment for discontinued operations.  During the first quarter of Fiscal 2018, net loss attributable to Dell Technologies Inc. was $1.3 billion, compared to a $0.1 billion net gain attributable to Dell Technologies Inc. during the first quarter of Fiscal 2017.  This increase in net loss attributable to Dell Technologies Inc. was primarily attributable to an increase in net loss from continuing operations and the absence of an adjustment for income from discontinued operations.  For more information regarding our discontinued operations, see Note 3 of the Notes to the Condensed Consolidated Financial Statements included in this report.

[0001571996-17-000009:mdna:133]
71

[0001571996-17-000009:mdna:134]
[same as prior period, unchanged from 0001571996-16-000021:mdna:152]

[0001571996-17-000009:mdna:135]
Our reportable segments are based on the following business units:  Client Solutions Group ("CSG"); Infrastructure Solutions Group ("ISG"); and VMware.  A description of our three business units is provided under "Introduction."  See Note 19 of the Notes to the Condensed Consolidated Financial Statements included in this report for a reconciliation of net revenue and operating income by reportable segment to consolidated net revenue and consolidated operating income, respectively.

[0001571996-17-000009:mdna:136]
[same as prior period, unchanged from 0001571996-16-000021:mdna:154]

[0001571996-17-000009:mdna:137]
[same as prior period, unchanged from 0001571996-16-000021:mdna:155]

[0001571996-17-000009:mdna:138]
|  | Three Months Ended |
|  | May 5, 2017 |  | % Change |  | April 29, 2016 |
|  | (in millions, except percentages) |
| Net Revenue: |  |  |  |  |  |
| Commercial | $ | 6,350 |  |  | 3% |  | $ | 6,145 |  |
| Consumer | 2,706 |  |  | 12% |  | 2,426 |  |
| Total CSG net revenue | $ | 9,056 |  |  | 6% |  | $ | 8,571 |  |
| Operating Income: |  |  |  |  |  |
| CSG operating income | $ | 374 |  |  | (3)% |  | $ | 385 |  |
| % of segment net revenue | 4.1 | % |  |  |  | 4.5 | % |

[0001571996-17-000009:mdna:139]
Net Revenue — During the first quarter of Fiscal 2018, CSG net revenue increased 6% driven by an increase in both commercial and consumer net revenue.  The increase in CSG net revenue was primarily driven by an increase in units sold as we benefited from a general improvement in customer demand, which favored premium notebooks and workstations over desktops.  Despite an increase in sales of our premium offerings, overall average selling prices were relatively flat over the period as we strategically managed our pricing position.

[0001571996-17-000009:mdna:140]
From a geographical perspective, net revenue attributable to CSG increased in APJ and the Americas during the first quarter of Fiscal 2018, while net revenue in EMEA was relatively unchanged.

[0001571996-17-000009:mdna:141]
Operating Income — During the first quarter of Fiscal 2018, CSG operating income as a percentage of net revenue decreased 40 basis points to 4.1%.  This decrease was driven by an overall decline in our gross margin percentage due to increases in certain component costs that we were not able to fully offset through pricing.  This decline in gross margin was partially offset by a reduction in operating expenses as we managed our cost position.  We expect that component cost increases will continue to be challenging over the next few quarters.

[0001571996-17-000009:mdna:142]
[same as prior period, unchanged from 0001571996-16-000021:mdna:164]

[0001571996-17-000009:mdna:143]
[same as prior period, unchanged from 0001571996-16-000021:mdna:165]

[0001571996-17-000009:mdna:144]
|  | Three Months Ended |
|  | May 5, 2017 |  | % Change |  | April 29, 2016 |
|  | (in millions, except percentages) |
| Net Revenue: |  |  |  |  |  |
| Servers and networking | $ | 3,231 |  |  | 5% |  | $ | 3,075 |  |
| Storage | 3,685 |  |  | 585% |  | 538 |  |
| Total ISG net revenue | $ | 6,916 |  |  | 91% |  | $ | 3,613 |  |
| Operating Income: |  |  |  |  |  |
| ISG operating income | $ | 323 |  |  | 68% |  | $ | 192 |  |
| % of segment net revenue | 4.7 | % |  |  |  | 5.3 | % |

[0001571996-17-000009:mdna:145]
Net Revenue — During the first quarter of Fiscal 2018, ISG net revenue increased approximately $3.3 billion, or 91%, primarily due to incremental net revenue associated with the EMC acquired storage business, which caused storage revenue to increase approximately $3.1 billion, or 585%.  Revenue from servers and networking also increased 5% over the period, primarily resulting from an increase in sale of PowerEdge units, while average selling prices of PowerEdge remained relatively flat.

[0001571996-17-000009:mdna:146]
From a geographical perspective, during the first quarter of Fiscal 2018, ISG net revenue increased in all regions due to the incremental revenue from the EMC acquired storage business.  The EMC acquired storage business operates on a world-wide basis with a geographic mix similar to that of the legacy Dell ISG business.

[0001571996-17-000009:mdna:147]
Operating Income — During the first quarter of Fiscal 2018, ISG operating income as a percentage of net revenue decreased 60 basis points to 4.7%.  While the EMC acquired storage business contributed higher gross margin overall, we experienced gross margin pressure due to changing product mix within ISG as well as component cost inflation, which we expect to continue in the near term.  ISG operating income also was affected by increased operating expenses reflecting larger investments in research and development as well as expenses incurred in connection with the discontinuation of certain products.

[0001571996-17-000009:mdna:148]
73

[0001571996-17-000009:mdna:149]
[same as prior period, unchanged from 0001571996-16-000021:mdna:172]

[0001571996-17-000009:mdna:150]
[same as prior period, unchanged from 0001571996-16-000021:mdna:173]

[0001571996-17-000009:mdna:151]
|  | Three Months Ended |
|  | May 5, 2017 |  | % Change |  | April 29, 2016 |
|  | (in millions, except percentages) |
| Net Revenue: |  |  |  |  |  |
| VMware net revenue | $ | 1,736 |  |  | NA |  | $ | — |  |
| Operating Income: |  |  |  |  |  |
| VMware operating income | $ | 486 |  |  | NA |  | $ | — |  |
| % of segment net revenue | 28.0 | % |  |  |  | NA |

[0001571996-17-000009:mdna:152]
Net Revenue — VMware net revenue during the first quarter of Fiscal 2018 primarily consists of revenue from the sale of software licenses under perpetual licenses, related software maintenance and support, training, consulting services, and hosted services.

[0001571996-17-000009:mdna:153]
From a geographical perspective, approximately half of VMware net revenue during the first quarter of Fiscal 2018 was generated from sales to customers in the United States.

[0001571996-17-000009:mdna:154]
Operating Income — During the first quarter of Fiscal 2018, VMware operating income as a percentage of net revenue was 28.0%.

[0001571996-17-000009:mdna:155]
OTHER BALANCE SHEET ITEMS

[0001571996-17-000009:mdna:156]
[same as prior period, unchanged from 0001571996-16-000021:mdna:179]

[0001571996-17-000009:mdna:157]
We sell products and services directly to customers and through a variety of sales channels, including retail distribution.  Our accounts receivable, net, was $8.8 billion and $9.4 billion as of May 5, 2017 and February 3, 2017, respectively.  The decrease in accounts receivable, net was primarily driven by a sequential decline in net revenue in line with normal seasonality.  We maintain an allowance for doubtful accounts to cover receivables that may be deemed uncollectible.  The allowance for losses is based on a provision for accounts that are collectively evaluated based on historical bad debt experience as well as specific identifiable customer accounts that are deemed at risk.  As of May 5, 2017 and February 3, 2017, the allowance for doubtful accounts was $64 million and $57 million, respectively.  Based on our assessment, we believe that we are adequately reserved for expected credit losses.  We monitor the aging of our accounts receivable and continue to take actions to reduce our exposure to credit losses.

[0001571996-17-000009:mdna:158]
[same as prior period, unchanged from 0001571996-16-000021:mdna:181]

[0001571996-17-000009:mdna:159]
Dell Financial Services, referred to as DFS, offers a wide range of financial services, including originating, collecting, and servicing customer receivables primarily related to the purchase of Dell products.  Following the closing of the EMC merger transaction, DFS began offering similar financial services related to the purchase of Dell EMC and VMware products.  In some cases, we originate financing activities for our commercial customers related to the purchase of third-party technology products that complement our portfolio of products and services.  New financing originations, which represent the amounts of financing provided by DFS to customers for equipment and related software and services, including third-party originations, were $1.1 billion and $0.8 billion for the first quarter of Fiscal 2018 and the first quarter of Fiscal 2017, respectively.  As of May 5, 2017 and February 3, 2017, our financing receivables, net were $6.0 billion and $5.9 billion, respectively.

[0001571996-17-000009:mdna:160]
We have securitization programs to fund revolving loans and fixed-term leases and loans through consolidated special purpose entities, referred to as SPEs, which we account for as secured borrowings.  We transfer certain U.S. and European customer financing receivables to these SPEs, whose purpose is to facilitate the funding of customer receivables through financing arrangements with multi-seller conduits that issue asset-backed debt securities in the capital markets and to private investors.  During the first quarters of Fiscal 2018 and Fiscal 2017, we transferred $0.9 billion and $0.6 billion to these SPEs, respectively.  The structured financing debt related to all of our securitization programs included as secured borrowing was $3.5 billion and $3.1 billion as of May 5, 2017 and February 3, 2017, respectively.  In addition, the carrying amount of the corresponding financing receivables was $4.0 billion and $3.6 billion as of May 5, 2017 and February 3, 2017, respectively.  As a result of the EMC merger transaction, we plan to expand our existing securitization programs to allow for additional funding of customer receivables in the capital markets.

[0001571996-17-000009:mdna:161]
We maintain an allowance to cover expected financing receivable credit losses and evaluate credit loss expectations based on our total portfolio.  For the first quarter of Fiscal 2018 and the first quarter of Fiscal 2017, the principal charge-off rate for our total portfolio was 1.8% and 2.2%, respectively.  The credit quality of our financing receivables has improved in recent years due to an overall improvement in the credit environment and as the mix of high-quality commercial accounts in our portfolio has increased.  We expect that trend to continue with increased commercial customer volume resulting from the EMC merger transaction.  The allowance for losses is determined based on various factors, including historical and anticipated experience, past due receivables, receivable type, and customer risk profile.  At May 5, 2017 and February 3, 2017, the allowance for financing receivable losses was $136 million and $143 million, respectively.  In general, the loss rates on our financing receivables have improved over the periods presented.  We expect relatively stable loss rates in future periods, with movements in these rates being primarily driven by seasonality and a continued shift in portfolio composition to lower risk commercial assets.  We continue to monitor broader economic indicators and their potential impact on future loss performance.  We have an extensive process to manage our exposure to customer credit risk, including active management of credit lines and our collection activities.  We also sell selected fixed-term financing receivables to unrelated third parties on a periodic basis, primarily to manage certain concentrations of customer credit exposure.  Based on our assessment of the customer financing receivables, we believe that we are adequately reserved.

[0001571996-17-000009:mdna:162]
See Note 6 of the Notes to the Condensed Consolidated Financial Statements included in this report for additional information about our financing receivables and the associated allowance.

[0001571996-17-000009:mdna:163]
[same as prior period, unchanged from 0001571996-16-000021:mdna:187]

[0001571996-17-000009:mdna:164]
Deferred revenue is recorded when billings have been generated or payments have been received for undelivered products or services, or in situations where revenue recognition criteria have not been met.  Deferred revenue represents amounts received in advance for extended warranty services, software maintenance, unearned license fees, and deferred profit on third-party software offerings.  Deferred revenue is recognized on these items when the revenue recognition criteria are met, generally resulting in ratable recognition over the contract term.  We also have deferred revenue related to undelivered hardware and professional services, consisting of installations and consulting engagements, which are recognized as our obligations under the contract are completed.

[0001571996-17-000009:mdna:165]
Our total deferred revenue was $18.7 billion as of both May 5, 2017 and February 3, 2017.  A majority of our deferred revenue as of May 5, 2017 is expected to be recognized over the next two years.

[0001571996-17-000009:mdna:166]
[same as prior period, unchanged from 0001571996-16-000021:mdna:190]

[0001571996-17-000009:mdna:167]
As of May 5, 2017, we had no off-balance sheet arrangements that have or are reasonably likely to have a current or future material effect on our financial condition or results of operations.

[0001571996-17-000009:mdna:168]
76

[0001571996-17-000009:mdna:169]
[same as prior period, unchanged from 0001571996-16-000021:mdna:193]

[0001571996-17-000009:mdna:170]
[same as prior period, unchanged from 0001571996-16-000021:mdna:194]

[0001571996-17-000009:mdna:171]
[same as prior period, unchanged from 0001571996-16-000021:mdna:195]

[0001571996-17-000009:mdna:172]
[same as prior period, unchanged from 0001571996-16-000021:mdna:196]

[0001571996-17-000009:mdna:173]
We use derivative instruments to hedge certain foreign currency exposures.  We use forward contracts and purchased options designated as cash flow hedges to protect against the foreign currency exchange rate risks inherent in our forecasted transactions denominated in currencies other than the U.S. dollar.  In addition, we primarily use forward contracts and may use purchased options to hedge monetary assets and liabilities denominated in a foreign currency.  See Note 8 of the Notes to the Condensed Consolidated Financial Statements included in this report for more information about our use of derivative instruments.

[0001571996-17-000009:mdna:174]
We are exposed to interest rate risk related to our variable-rate debt and investment portfolio.  In the normal course of business, we follow established policies and procedures to manage this risk, including monitoring of our asset and liability mix.  As a result, we do not anticipate any material losses from interest rate risk.

[0001571996-17-000009:mdna:175]
The impact on our Condensed Consolidated Financial Statements included in this report of any credit adjustments related to our use of counterparties has been immaterial.

[0001571996-17-000009:mdna:176]
[same as prior period, unchanged from 0001571996-16-000021:mdna:199]

[0001571996-17-000009:mdna:177]
To support our ongoing business operations, we rely on operating cash flows as our primary source of liquidity.  We monitor the efficiency of our balance sheet to ensure that we have adequate liquidity to support our strategic initiatives.  In addition to internally generated cash, we have access to other capital sources to finance our strategic initiatives and fund growth in our financing operations.  As of May 5, 2017, we had $9.6 billion of total cash and cash equivalents, the majority of which was held outside of the United States.  Our strategy is to deploy capital from any potential source, whether internally generated cash or debt, depending on the adequacy and availability of that source of capital and whether it can be accessed in a cost-effective manner.

[0001571996-17-000009:mdna:178]
[same as prior period, unchanged from 0001571996-16-000021:mdna:201]

[0001571996-17-000009:mdna:179]
The following table summarizes our cash and cash equivalents as well as our available borrowings as of May 5, 2017 and February 3, 2017:

[0001571996-17-000009:mdna:180]
|  | May 5, 2017 |  | February 3, 2017 |
|  | (in millions) |
| Cash and cash equivalents, and available borrowings: |  |  |  |
| Cash and cash equivalents (a) | $ | 9,554 |  |  | $ | 9,474 |  |
| Remaining available borrowings under the Revolving Credit Facility | 2,678 |  |  | 2,678 |  |
| Total cash, cash equivalents, and available borrowings | $ | 12,232 |  |  | $ | 12,152 |  |

[0001571996-17-000009:mdna:181]
[same as prior period, unchanged from 0001571996-16-000021:mdna:228]

[0001571996-17-000009:mdna:182]
(a)  Of the $9.6 billion of cash and cash equivalents as of May 5, 2017, $3.9 billion was held by VMware, Inc.

[0001571996-17-000009:mdna:183]
[same as prior period, unchanged from 0001571996-16-000021:mdna:10]

[0001571996-17-000009:mdna:184]
The Revolving Credit Facility has maximum aggregate borrowings of approximately $3.2 billion.  Available borrowings under the Revolving Credit Facility are reduced by draws on the facility as well as by outstanding letters of credit.  As of May 5, 2017, remaining available borrowings under this facility totaled approximately $2.7 billion.  These available borrowings may be used periodically for general corporate purposes.

[0001571996-17-000009:mdna:185]
We believe that our current cash and cash equivalents, along with cash that will be provided by future operations and borrowings expected to be available under the Revolving Credit Facility, will be sufficient over at least the next twelve months to fund our operations, capital expenditures, share repurchases, and debt service requirements.

[0001571996-17-000009:mdna:186]
[same as prior period, unchanged from 0001571996-16-000021:mdna:207]

[0001571996-17-000009:mdna:187]
The following table summarizes our outstanding debt as of May 5, 2017 and February 3, 2017:

[0001571996-17-000009:mdna:188]
|  | May 5, 2017 |  | February 3, 2017 |
|  | (in millions) |
| Outstanding Debt: |  |  |  |
| Structured financing debt | $ | 3,869 |  |  | $ | 3,464 |  |
| Senior Secured Credit Facilities and First Lien Notes | 32,074 |  |  | 31,638 |  |
| Unsecured Notes and Debentures | 2,453 |  |  | 2,453 |  |
| Senior Notes | 3,250 |  |  | 3,250 |  |
| EMC Notes | 5,500 |  |  | 5,500 |  |
| Margin Loan Facility | 2,000 |  |  | — |  |
| Bridge Facilities | 1,500 |  |  | 4,000 |  |
| Other | 82 |  |  | 51 |  |
| Total debt, principal amount | 50,728 |  |  | 50,356 |  |
| Carrying value adjustments | (938 | ) |  | (966 | ) |
| Total debt, carrying value | $ | 49,790 |  |  | $ | 49,390 |  |

[0001571996-17-000009:mdna:189]
To finance the EMC merger transaction, we issued an aggregate principal amount of $45.9 billion in new debt, which included proceeds from the sale of the First Lien Notes and Senior Notes, as well as borrowings under the Senior Secured Credit Facilities (including the Revolving Credit Facility), the Asset Sale Bridge Facility, the Margin Bridge Facility, and the VMware Bridge Facility at the closing of the transaction.  Additionally, on September 7, 2016, EMC had outstanding senior notes (the "EMC Notes") consisting of $2.5 billion aggregate principal amount of its 1.875% Notes due June 2018, $2.0 billion aggregate principal amount of its 2.650% Notes due June 2020 and $1.0 billion aggregate principal amount of its 3.375% Notes due June 2023.  The EMC Notes remain outstanding following the closing of the EMC merger transaction.

[0001571996-17-000009:mdna:190]
During the first quarter of Fiscal 2018, we refinanced the Term Loan B Facility to reduce the interest rate margin by 0.75% and to increase the outstanding principal amount by $0.5 billion.  We applied the proceeds from the Term Loan B Facility refinancing to repay $0.5 billion principal amount of the Margin Bridge Facility.  Additionally, during the first quarter of Fiscal 2018, we issued the Margin Loan Facility in the principal amount of $2.0 billion, and used the proceeds of the new facility to extinguish the Margin Bridge Facility.  Further, we issued an additional $0.4 billion, net, in structured financing debt to support the expansion of our financing receivables portfolio, and repaid approximately $0.1 billion principal amount of our Term Loan facilities.

[0001571996-17-000009:mdna:191]
Our requirements for cash to pay principal and interest have increased significantly due to the borrowings that were required to finance the EMC merger transaction.  We or our affiliates, at our or their sole discretion, may purchase, redeem, prepay, refinance, or otherwise retire our outstanding indebtedness under the terms of such indebtedness at any time and from time to time, in open market or negotiated transactions with the holders of such indebtedness, or otherwise.

[0001571996-17-000009:mdna:192]
We balance the use of our securitization programs with working capital and other sources of liquidity to fund growth in our global financial services business.  Of the $50.7 billion in outstanding principal debt as of May 5, 2017, $5.2 billion, which includes $3.9 billion in structured financing debt, is used to fund this business.

[0001571996-17-000009:mdna:193]
78

[0001571996-17-000009:mdna:194]
See Note 7 of the Notes to the Condensed Consolidated Financial Statements included in this report for more information about our debt.

[0001571996-17-000009:mdna:195]
[same as prior period, unchanged from 0001571996-16-000021:mdna:215]

[0001571996-17-000009:mdna:196]
The following table contains a summary of our Condensed Consolidated Statements of Cash Flows for the respective periods:

[0001571996-17-000009:mdna:197]
|  | Three Months Ended |
|  | May 5, 2017 |  | April 29, 2016 |
|  | (in millions) |
| Net change in cash from: |  |  |  |
| Operating activities | $ | 240 |  |  | $ | (63 | ) |
| Investing activities | 51 |  |  | (60 | ) |
| Financing activities | (205 | ) |  | (387 | ) |
| Effect of exchange rate changes on cash and cash equivalents | (6 | ) |  | 73 |  |
| Change in cash and cash equivalents | $ | 80 |  |  | $ | (437 | ) |

[0001571996-17-000009:mdna:198]
Operating Activities — Cash provided by operating activities was $240 million during the first quarter of Fiscal 2018 and cash used by operating activity was $63 million for first quarter of Fiscal 2017.  Operating cash flows during the first quarter of Fiscal 2018 were driven by profitability, primarily in VMware.  The favorable impact of this profitability was partially offset by increased compensation and benefit expenses as a result of higher seasonal incentive bonus payments.

[0001571996-17-000009:mdna:199]
Investing Activities — Investing activities primarily consist of the maturities, sales, and purchases of investments, capital expenditures for property, plant, and equipment, and capitalized software development costs.  Cash provided by investing activities was $51 million during the first quarter of Fiscal 2018 and cash used by investing activities was $60 million during the first quarter of Fiscal 2017.  The change in cash from investing activities during the first quarter of Fiscal 2018 was primarily driven by maturities and sales of investments.

[0001571996-17-000009:mdna:200]
Financing Activities — Financing activities primarily consist of the proceeds and repayments of debt and cash used to repurchase common stock.  Cash used by financing activities was $205 million during the first quarter of Fiscal 2018 and primarily reflected our repurchase of shares of Class V Common Stock under the programs described below and other shares of common stock we repurchased for tax withholdings on vesting of equity awards.  This use of cash was partially offset by net proceeds of approximately $400 million of cash from the issuance of structured financing debt.  In comparison, cash used in financing activities was $387 million during the first quarter of Fiscal 2017 and primarily consisted of the repayment of debt, partially offset by the issuance of common stock of SecureWorks upon the closing of the SecureWorks initial public offering.  See Note 7  and Note 17 of the Notes to the Condensed Consolidated Financial Statements included in this report for more information about our debt and share repurchase programs, respectively.

[0001571996-17-000009:mdna:201]
[same as prior period, unchanged from 0001571996-16-000021:mdna:36]

[0001571996-17-000009:mdna:202]
[same as prior period, unchanged from 0001571996-16-000021:mdna:224]

[0001571996-17-000009:mdna:203]
Our key performance metrics are net revenue, operating income, adjusted EBITDA, cash flows from operations, and cash conversion cycle.  Net revenue, operating income, adjusted EBITDA, and cash flows from operations are discussed elsewhere in this report.  Our cash conversion cycle is presented below.

[0001571996-17-000009:mdna:204]
Cash Conversion Cycle

[0001571996-17-000009:mdna:205]
[same as prior period, unchanged from 0001571996-16-000021:mdna:226]

[0001571996-17-000009:mdna:206]
|  | Three Months Ended |
|  | May 5, 2017 |  | April 29, 2016 |
| Days of sales outstanding (a) | 48 |  |  | 41 |  |
| Days of supply in inventory (b) | 18 |  |  | 15 |  |
| Days in accounts payable (c) | (108 | ) |  | (113 | ) |
| Cash conversion cycle (d) | (42 | ) |  | (57 | ) |

[0001571996-17-000009:mdna:207]
__________________

[0001571996-17-000009:mdna:208]
| (a) | Days of sales outstanding, referred to as DSO, calculates the average collection period of our receivables. DSO is based on the ending net trade receivables and the most recent quarterly non-GAAP net revenue for each period. DSO also includes the effect of product costs related to customer shipments not yet recognized as revenue that are classified in other current assets, as we believe this provides a more relevant metric that aligns with actual sales activity in the quarter, regardless of revenue recognition under GAAP. DSO is calculated by adding accounts receivable, net of allowance for doubtful accounts, and customer shipments in transit and dividing that sum by average non-GAAP net revenue per day for the current quarter (90 days for the three months ended May 5, 2017 and April 29, 2016). As of May 5, 2017, DSO and days of customer shipments not yet recognized were 44 and 4 days, respectively. As of April 29, 2016, DSO and days of customer shipments not yet recognized were 36 and 5 days, respectively. |

[0001571996-17-000009:mdna:209]
| (b) | Days of supply in inventory, referred to as DSI, measures the average number of days from procurement to sale of our products. DSI is based on ending inventory and non-GAAP cost of goods sold for each period. DSI is calculated by dividing ending inventory by average non-GAAP cost of goods sold per day for the current quarter (90 days for the three months ended May 5, 2017 and April 29, 2016). |

[0001571996-17-000009:mdna:210]
| (c) | Days in accounts payable, referred to as DPO, calculates the average number of days our payables remain outstanding before payment. DPO is based on ending accounts payable and non-GAAP cost of goods sold for each period. DPO is calculated by dividing accounts payable by average non-GAAP cost of goods sold per day for the current quarter (90 days for the three months ended May 5, 2017 and April 29, 2016). |

[0001571996-17-000009:mdna:211]
[same as prior period, unchanged from 0001571996-16-000021:mdna:232]

[0001571996-17-000009:mdna:212]
80

[0001571996-17-000009:mdna:213]
The table below provides reconciliations of each non-GAAP financial measure to its most directly comparable GAAP financial measure used in calculating the DSO, DSI and DPO metrics:

[0001571996-17-000009:mdna:214]
|  | Three Months Ended |
|  | May 5, 2017 |  | April 29, 2016 |
|  | (in millions) |
| Cost of goods sold | $ | 13,514 |  |  | $ | 10,048 |  |
| Non-GAAP adjustments: |  |  |  |
| Impact of purchase accounting | (10 | ) |  | (11 | ) |
| Amortization of intangibles | (950 | ) |  | (101 | ) |
| Transaction-related expenses | (7 | ) |  | 1 |  |
| Other corporate expenses | (22 | ) |  | (3 | ) |
| Non-GAAP cost of goods sold | $ | 12,525 |  |  | $ | 9,934 |  |

[0001571996-17-000009:mdna:215]
For the three months ended May 5, 2017, changes in our cash conversion cycle were unfavorable by 15 days when compared to the three months ended April 29, 2016.  This was primarily driven by the acquisition of EMC, which had a negative impact across all three components.  We experienced a five day decrease in DPO, primarily driven by supplier payments terms of the EMC acquired businesses.  A seven day increase in DSO was primarily driven by differences in collections management from the EMC acquired businesses.  A three day increase in DSI was primarily the result of the longer inventory cycle associated with the EMC acquired product lines.  We are continuing the integration of the EMC acquired businesses and, as a result, our supplier arrangements, collection activities, and operating cycles will continue to evolve.  We believe our business model allows us to maintain an efficient cash conversion cycle, which compares favorably with that of others in our industry.

[0001571996-17-000009:mdna:216]
[same as prior period, unchanged from 0001571996-16-000021:mdna:238]

[0001571996-17-000009:mdna:217]
Capital Expenditures — During the first quarters of Fiscal 2018 and Fiscal 2017, we spent $245 million and $92 million, respectively, on property, plant, and equipment.  These expenditures were primarily incurred in connection with our global expansion efforts and infrastructure investments made to support future growth.  Product demand, product mix, and the use of contract manufacturers, as well as ongoing investments in operating and information technology infrastructure, influence the level and prioritization of our capital expenditures.  Aggregate capital expenditures for Fiscal 2018, which will be primarily related to infrastructure investments and strategic initiatives, are currently expected to total approximately $1.3 billion.

[0001571996-17-000009:mdna:218]
Repurchases of Common Stock

[0001571996-17-000009:mdna:219]
Class V Common Stock Repurchases — On December 13, 2016, the board of directors approved a stock repurchase program under which we are authorized to use assets of the Class V Group to repurchase up to $500 million of shares of Class V Common Stock over a period of six months.  During the first quarter of Fiscal 2018, we repurchased 1.3 million shares of Class V Common Stock for $82 million, and on February 13, 2017, the stock repurchase program was completed.

[0001571996-17-000009:mdna:220]
On March 27, 2017, the board of directors approved an amendment of the stock repurchase program which authorizes us to use assets of the Class V Group to repurchase up to an additional $300 million of shares of Class V Common Stock over a period of an additional six months.  During the first quarter of Fiscal 2018, we repurchased 4.2 million shares of Class V Common Stock for $277 million under the extended stock repurchase program.  As of May 5, 2017, our remaining authorized amount for share repurchases was $23 million.

[0001571996-17-000009:mdna:221]
VMware, Inc. Class A Common Stock Repurchases — On December 15, 2016, we entered into a stock purchase agreement with VMware, Inc., pursuant to which VMware, Inc. agreed to repurchase for cash $500 million of shares of VMware, Inc. Class A common stock from a subsidiary of Dell Technologies.  During the first quarter of Fiscal 2018, VMware, Inc. repurchased 1.4 million shares, and on February 15, 2017, the sale transaction under the stock purchase agreement was completed.

[0001571996-17-000009:mdna:222]
During January 2017, VMware, Inc.'s board of directors authorized the repurchase of up to an additional $1.2 billion of shares of VMware, Inc. Class A common stock through the end of Fiscal 2018.  On March 29, 2017, we entered into a stock purchase agreement with VMware, Inc., pursuant to which VMware, Inc. repurchased for cash $300 million of shares of VMware, Inc.

[0001571996-17-000009:mdna:223]
Class A common stock from a subsidiary of Dell Technologies.  The proceeds from the sale were applied to the repurchase of shares of our Class V Common Stock under the stock repurchase program described above.

[0001571996-17-000009:mdna:224]
During the first quarter of Fiscal 2018, VMware, Inc. received an initial delivery of approximately 2.7 million shares of Class A common stock with a value of $240 million for $300 million in cash.  On May 10, 2017, the sale transaction under the stock purchase agreement was completed and VMware, Inc. received an additional 0.7 million shares.  This repurchase was pursuant to the January 2017 authorization.  As of May 5, 2017, the cumulative authorized amount remaining for share repurchases by VMware, Inc. under the January 2017 authorization was $900 million.

[0001571996-17-000009:mdna:225]
For more information regarding share repurchase programs, see Note 17 of the Notes to the Condensed Consolidated Financial Statements included in this report, and "Part II — Item 2 — Unregistered Sales of Equity Securities and Use of Proceeds."

[0001571996-17-000009:mdna:226]
[same as prior period, unchanged from 0001571996-16-000021:mdna:251]

[0001571996-17-000009:mdna:227]
We utilize several suppliers to manufacture sub-assemblies for our products.  Our efficient supply chain management allows us to enter into flexible and mutually beneficial purchase arrangements with our suppliers in order to minimize inventory risk.  Consistent with industry practice, we acquire raw materials or other goods and services, including product components, by issuing to suppliers authorizations to purchase based on our projected demand and manufacturing needs.  These purchase orders are typically fulfilled within 30 days and are entered into during the ordinary course of business in order to establish best pricing and continuity of supply for our production.  Purchase orders are not included in the table above as they typically represent our authorization to purchase rather than binding purchase obligations.

[0001571996-17-000009:mdna:228]
As of May 5, 2017, we had $2.7 billion, $0.3 billion, and $0.4 billion in purchase obligations for Fiscal 2018, Fiscal 2019, and Fiscal 2020 and thereafter, respectively.

[0001571996-17-000009:mdna:229]
[same as prior period, unchanged from 0001571996-16-000021:mdna:60]
