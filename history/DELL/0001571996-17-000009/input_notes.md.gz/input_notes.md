# DELL notes — 0001571996-17-000009


## dvmt:ReconciliationofConsolidatedNetIncomeLossTableTextBlock

[0001571996-17-000009:notes:1]
[same as prior period, unchanged from 0001571996-16-000021:notes:58]

[0001571996-17-000009:notes:2]
|  | Three Months Ended |
|  | May 5, 2017 |  | April 29, 2016 |
|  | (in millions) |
| Net income from continuing operations attributable to Class V Common Stock | $ | 118 |  |  | $ | — |  |
| Net loss from continuing operations attributable to DHI Group | (1,452 | ) |  | (424 | ) |
| Net loss from continuing operations attributable to Dell Technologies Inc. | (1,334 | ) |  | (424 | ) |
| Income from discontinued operations, net of income taxes (Note 3) | — |  |  | 479 |  |
| Net income (loss) attributable to Dell Technologies Inc. | $ | (1,334 | ) |  | $ | 55 |  |


## invest:InvestmentTableTextBlock

[0001571996-17-000009:notes:3]
The following table summarizes, by major security type, the carrying value and amortized cost of the Company's investments.  All debt security investments with remaining effective maturities in excess of one year and substantially all equity and other securities are recorded as long-term investments in the Condensed Consolidated Statements of Financial Position.

[0001571996-17-000009:notes:4]
|  | May 5, 2017 |  | February 3, 2017 |
|  | Cost |  | Unrealized Gain |  | Unrealized (Loss) |  | Carrying Value |  | Cost |  | Unrealized Gain |  | Unrealized (Loss) |  | Carrying Value |
|  | (in millions) |
| Investments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. government and agencies | $ | 275 |  |  | $ | — |  |  | $ | — |  |  | $ | 275 |  |  | $ | 231 |  |  | $ | — |  |  | $ | — |  |  | $ | 231 |  |
| U.S. corporate debt securities | 542 |  |  | — |  |  | (1 | ) |  | 541 |  |  | 651 |  |  | — |  |  | (1 | ) |  | 650 |  |
| Foreign debt securities | 599 |  |  | — |  |  | (1 | ) |  | 598 |  |  | 743 |  |  | — |  |  | (1 | ) |  | 742 |  |
| Municipal obligations | 206 |  |  | — |  |  | — |  |  | 206 |  |  | 348 |  |  | — |  |  | — |  |  | 348 |  |
| Asset-backed securities | — |  |  | — |  |  | — |  |  | — |  |  | 4 |  |  | — |  |  | — |  |  | 4 |  |
| Total short-term investments | 1,622 |  |  | — |  |  | (2 | ) |  | 1,620 |  |  | 1,977 |  |  | — |  |  | (2 | ) |  | 1,975 |  |
| U.S. government and agencies | 614 |  |  | — |  |  | (5 | ) |  | 609 |  |  | 689 |  |  | — |  |  | (6 | ) |  | 683 |  |
| U.S. corporate debt securities | 1,188 |  |  | 1 |  |  | (10 | ) |  | 1,179 |  |  | 1,164 |  |  | — |  |  | (14 | ) |  | 1,150 |  |
| Foreign debt securities | 1,299 |  |  | 1 |  |  | (10 | ) |  | 1,290 |  |  | 1,356 |  |  | — |  |  | (15 | ) |  | 1,341 |  |
| Municipal obligations | — |  |  | — |  |  | — |  |  | — |  |  | 4 |  |  | — |  |  | — |  |  | 4 |  |
| Equity and other securities (a) | 640 |  |  | 54 |  |  | — |  |  | 694 |  |  | 604 |  |  | 22 |  |  | (2 | ) |  | 624 |  |
| Total long-term investments | 3,741 |  |  | 56 |  |  | (25 | ) |  | 3,772 |  |  | 3,817 |  |  | 22 |  |  | (37 | ) |  | 3,802 |  |
| Total investments | $ | 5,363 |  |  | $ | 56 |  |  | $ | (27 | ) |  | $ | 5,392 |  |  | $ | 5,794 |  |  | $ | 22 |  |  | $ | (39 | ) |  | $ | 5,777 |  |

[0001571996-17-000009:notes:5]
____________________

[0001571996-17-000009:notes:6]
| (a) | The majority of equity and other securities are strategic investments accounted for under the cost method, while the remainder are investments that are measured at fair value on a recurring basis. See Note 4 of the Notes to the Condensed Consolidated Financial Statements for additional information on investments measured at fair value on a recurring basis. |


## invest:InvestmentTextBlock

[0001571996-17-000009:notes:7]
INVESTMENTS

[0001571996-17-000009:notes:8]
The Company's investments in debt securities are classified as available-for-sale securities, which are carried at fair value.  As of May 5, 2017, all investments in an unrealized loss position have been in a continuous unrealized loss position for less than 12 months.

[0001571996-17-000009:notes:9]
The contractual maturities of debt securities held at May 5, 2017 are as follows:

[0001571996-17-000009:notes:10]
|  | Amortized Cost |  | Carrying Value |
|  | (in millions) |
| Due within one year | $ | 1,622 |  |  | $ | 1,620 |  |
| Due after 1 year through 5 years | 3,024 |  |  | 3,002 |  |
| Due after 5 years through 10 years | 77 |  |  | 76 |  |
| Total | $ | 4,723 |  |  | $ | 4,698 |  |


## us-gaap:AllowanceForCreditLossesOnFinancingReceivablesTableTextBlock

[0001571996-17-000009:notes:11]
The following table summarizes the changes in the allowance for financing receivable losses for the respective periods:

[0001571996-17-000009:notes:12]
|  | Three Months Ended |
|  | May 5, 2017 |  | April 29, 2016 |
|  | Revolving |  | Fixed-term |  | Total |  | Revolving |  | Fixed-term |  | Total |
|  | (in millions) |
| Allowance for financing receivable losses: |
| Balances at beginning of period | $ | 91 |  |  | $ | 52 |  |  | $ | 143 |  |  | $ | 118 |  |  | $ | 58 |  |  | $ | 176 |  |
| Charge-offs, net of recoveries | (22 | ) |  | (3 | ) |  | (25 | ) |  | (25 | ) |  | (3 | ) |  | (28 | ) |
| Provision charged to income statement | 16 |  |  | 2 |  |  | 18 |  |  | 14 |  |  | 3 |  |  | 17 |  |
| Balances at end of period | $ | 85 |  |  | $ | 51 |  |  | $ | 136 |  |  | $ | 107 |  |  | $ | 58 |  |  | $ | 165 |  |


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0001571996-17-000009:notes:13]
The accompanying Unaudited Condensed Consolidated Financial Statements should be read in conjunction with the audited Consolidated Financial Statements and accompanying Notes filed with the U.S. Securities and Exchange Commission ("SEC") in the Company's Annual Report on Form 10-K for the fiscal year ended February 3, 2017 ("Fiscal 2017").  These Condensed Consolidated Financial Statements have been prepared in accordance with accounting principles generally accepted in the United States of America ("GAAP").  In the opinion of management, the accompanying Condensed Consolidated Financial Statements reflect all adjustments of a normal recurring nature considered necessary to fairly state the financial position of Dell Technologies Inc. (individually and together with its consolidated subsidiaries, the "Company" or "Dell Technologies") as of May 5, 2017 and February 3, 2017, the results of its operations and corresponding comprehensive income (loss), as well as its cash flows, for the three months ended May 5, 2017 and April 29, 2016.

[0001571996-17-000009:notes:14]
The preparation of financial statements in accordance with GAAP requires management to make estimates and assumptions that

[0001571996-17-000009:notes:15]
affect the amounts reported in the Condensed Consolidated Financial Statements and the accompanying Notes.  Actual results could differ materially from those estimates.  The results of operations, comprehensive income (loss), and cash flows for the three months ended May 5, 2017 and April 29, 2016 are not necessarily indicative of the results to be expected for the full fiscal year or for any other fiscal period.


## us-gaap:BusinessAcquisitionProFormaInformationTextBlock

[0001571996-17-000009:notes:16]
The following table provides unaudited pro forma results of operations for the periods presented as if the transaction date had occurred on January 31, 2015, the first day of Fiscal 2016:

[0001571996-17-000009:notes:17]
|  | Three Months Ended |
|  | April 29, 2016 |
|  | (in millions) |
| Total net revenue | $ | 17,205 |  |
| Net loss attributable to Dell Technologies Inc. | $ | (1,383 | ) |
| Earnings (loss) per share attributable to Dell Technologies Inc. - basic (a): |  |
| Continuing operations - Class V Common Stock | $ | 0.39 |  |
| Continuing operations - DHI Group | $ | (2.59 | ) |
| Earnings (loss) per share attributable to Dell Technologies Inc. - diluted (a): |  |
| Continuing operations - Class V Common Stock | $ | 0.39 |  |
| Continuing operations - DHI Group | $ | (2.59 | ) |

[0001571996-17-000009:notes:18]
| (a) | For purposes of calculating pro forma earnings (loss) per share, the Company used the two-class method. Earnings are allocated between the Class V Common Stock and the DHI Group on a basis consistent with historical earnings (loss) per share. |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001571996-17-000009:notes:19]
BUSINESS COMBINATIONS

[0001571996-17-000009:notes:20]
[same as prior period, unchanged from 0001571996-16-000021:notes:64]

[0001571996-17-000009:notes:21]
Transaction Overview — On September 7, 2016, EMC became a wholly-owned subsidiary of the Company as a result of the merger of Merger Sub with and into EMC, with EMC surviving as a wholly-owned subsidiary of the Company.  Pursuant to the terms of the merger agreement, upon the completion of the EMC merger transaction, each issued and outstanding share of common stock, par value $0.01 per share, of EMC (approximately 2.0 billion as of September 7, 2016) was converted into the right to receive (1) $24.05 in cash, without interest, and (2) 0.11146 validly issued, fully paid and non-assessable shares of common stock of the Company designated as Class V Common Stock, par value $0.01 per share (the "Class V Common Stock"), plus cash in lieu of any fractional shares.  Shares of the Class V Common Stock were approved for listing on the New York Stock Exchange (the "NYSE") under the ticker symbol "DVMT" and began trading on September 7, 2016.

[0001571996-17-000009:notes:22]
In connection with the EMC merger transaction, the Company authorized 343 million shares of Class V Common Stock.  On September 7, 2016, Dell Technologies issued 223 million shares of Class V Common Stock to EMC shareholders at a purchase price of $45.07 per share for an aggregate purchase price of approximately $10.0 billion.  The total fair value of consideration transferred to effect the EMC merger transaction was approximately $64.0 billion, which primarily consisted of cash and such shares of Class V Common Stock, as well as the fair value of non-controlling interests in VMware, Inc. and Pivotal Software, Inc. ("Pivotal"), majority-owned consolidated subsidiaries of EMC.  See Note 17 for more information on the Class V Common Stock.

[0001571996-17-000009:notes:23]
Assets Acquired and Liabilities Assumed — The EMC merger transaction has been accounted for as a business combination under the acquisition method of accounting.  The cumulative impact of any subsequent changes resulting from the facts and circumstances that existed as of the transaction date will be adjusted in the reporting period in which the adjustment amount is determined.  The Company's purchase accounting is substantially complete.  The following table summarizes, as of May 5, 2017, the preliminary purchase price allocation to the assets acquired and the liabilities assumed in the EMC merger transaction (in millions):

[0001571996-17-000009:notes:24]
| Current assets: |  |
| Cash and cash equivalents | $ | 10,080 |  |
| Short-term investments | 1,765 |  |
| Accounts receivable | 2,810 |  |
| Short-term financing receivables | 64 |  |
| Inventories, net | 1,993 |  |
| Other current assets | 903 |  |
| Total current assets | 17,615 |  |
| Property, plant, and equipment | 4,490 |  |
| Long-term investments | 4,317 |  |
| Long-term financing receivables, net | 65 |  |
| Goodwill | 31,539 |  |
| Purchased intangibles | 31,218 |  |
| Other non-current assets | 445 |  |
| Total assets | $ | 89,689 |  |
| Current liabilities: |  |
| Short-term debt | $ | 905 |  |
| Accounts payable | 728 |  |
| Accrued and other | 3,259 |  |
| Short-term deferred revenue | 4,954 |  |
| Total current liabilities | 9,846 |  |
| Long-term debt | 5,474 |  |
| Long-term deferred revenue | 3,469 |  |
| Deferred tax liabilities | 6,625 |  |
| Other non-current liabilities | 324 |  |
| Total liabilities | 25,738 |  |
| Total net assets | $ | 63,951 |  |

[0001571996-17-000009:notes:25]
The table above includes amounts allocated to ECD, which was divested in the fiscal year ended February 3, 2017.  See Note 3 of the Notes to the Condensed Consolidated Financial Statements for more information on discontinued operations.

[0001571996-17-000009:notes:26]
Pro Forma Financial Information — The following table provides unaudited pro forma results of operations for the periods presented as if the transaction date had occurred on January 31, 2015, the first day of Fiscal 2016:

[0001571996-17-000009:notes:27]
The pro forma information for the three months ended April 29, 2016 combines the Company's historical results for the three months ended April 29, 2016 and EMC's historical results for the three months ended March 31, 2016.  The historical results have been adjusted in the pro forma information to give effect to items that are (a) directly attributable to the EMC merger transaction, (b) factually supportable, and (c) expected to have a continuing impact on the combined company's results.  The pro forma information is presented for informational purposes only.  The unaudited pro forma results include the elimination of non-recurring transaction and integration costs of $63 million in the three months ended April 29, 2016.  The pro forma information does not purport to represent what the combined company's results of operations or financial condition would have been had the EMC merger transaction actually occurred on the date indicated, and does not purport to project the combined company's results of operations for any future period or as of any future date.


## us-gaap:BusinessDescriptionAndBasisOfPresentationTextBlock

[0001571996-17-000009:notes:28]
BASIS OF PRESENTATION

[0001571996-17-000009:notes:29]
EMC Merger Transaction — On September 7, 2016, EMC Corporation, a Massachusetts corporation ("EMC"), became a wholly-owned subsidiary of Dell Technologies Inc. (the "Company") as a result of the merger of Universal Acquisition Co., a Delaware corporation and wholly-owned subsidiary of the Company ("Merger Sub"), with and into EMC, with EMC surviving as a wholly-owned subsidiary of the Company (the "EMC merger transaction").  See Note 2 of the Notes to the Condensed Consolidated Financial Statements for additional information on the EMC merger transaction.

[0001571996-17-000009:notes:30]
Divestitures — On November 2, 2016, the Company completed substantially all of the divestiture of Dell Services.  On October 31, 2016, the Company completed the divestiture of Dell Software Group ("DSG").  On January 23, 2017, the Company completed the divestiture of the Dell EMC Enterprise Content Division ("ECD").  In accordance with applicable accounting guidance, the results of Dell Services, DSG, and ECD are presented as discontinued operations in the Condensed Consolidated Statements of Income (Loss) and, as such, have been excluded from both continuing operations and segment results for the relevant periods.  See Note 3 of the Notes to the Condensed Consolidated Financial Statements for additional information.

[0001571996-17-000009:notes:31]
SecureWorks Initial Public Offering — On April 27, 2016, SecureWorks Corp. ("SecureWorks") completed a registered underwritten initial public offering ("IPO") of its Class A common stock.  The results of the SecureWorks operations are included in other businesses.  See Note 15 of the Notes to the Condensed Consolidated Financial Statements for more information.

[0001571996-17-000009:notes:32]
Basis of Presentation — The accompanying Unaudited Condensed Consolidated Financial Statements should be read in conjunction with the audited Consolidated Financial Statements and accompanying Notes filed with the U.S. Securities and Exchange Commission ("SEC") in the Company's Annual Report on Form 10-K for the fiscal year ended February 3, 2017 ("Fiscal 2017").  These Condensed Consolidated Financial Statements have been prepared in accordance with accounting principles generally accepted in the United States of America ("GAAP").  In the opinion of management, the accompanying Condensed Consolidated Financial Statements reflect all adjustments of a normal recurring nature considered necessary to fairly state the financial position of Dell Technologies Inc. (individually and together with its consolidated subsidiaries, the "Company" or "Dell Technologies") as of May 5, 2017 and February 3, 2017, the results of its operations and corresponding comprehensive income (loss), as well as its cash flows, for the three months ended May 5, 2017 and April 29, 2016.

[0001571996-17-000009:notes:33]
The Company's fiscal year is the 52- or 53-week period ending on the Friday nearest January 31.  The fiscal year ended February 3, 2017 ("Fiscal 2017") was a 53-week period while the fiscal year ending February 2, 2018 ("Fiscal 2018") will be a 52-week period.

[0001571996-17-000009:notes:34]
As a result of the EMC merger transaction completed on September 7, 2016, the Company's results for the fiscal periods reflected in these Condensed Consolidated Financial Statements are not directly comparable.  The results of the businesses acquired in the EMC merger transaction are included in the consolidated results of Dell Technologies for the three months ended May 5, 2017.  The Dell Technologies balance sheet reflects the full consolidation of EMC's assets and liabilities as a result of the closing of the EMC merger transaction on September 7, 2016.

[0001571996-17-000009:notes:35]
Unless the context indicates otherwise, references in these Notes to the Condensed Consolidated Financial Statements to "VMware" mean the VMware reportable segment, which reflects the operations of VMware, Inc. (NYSE: VMW) within Dell Technologies.  See Exhibit 99.1 filed with the Company's quarterly report on Form 10-Q for the quarterly period ended May 5, 2017 for information on the differences between VMware reportable segment results and VMware, Inc. results.

[0001571996-17-000009:notes:36]
Recently Issued Accounting Pronouncements

[0001571996-17-000009:notes:37]
Revenue from Contracts with Customers — In May 2014, the Financial Accounting Standards Board (the "FASB") issued amended guidance on the recognition of revenue from contracts with customers.  The objective of the new standard is to establish a single comprehensive model for entities to use in accounting for revenue arising from contracts with customers and will supersede substantially all of the existing revenue recognition guidance, including industry-specific guidance.  The new standard requires entities to recognize revenue when it transfers promised goods or services to customers in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services.  The new standard also provides guidance on the accounting for costs to fulfill or obtain a customer contract.  Further, the new standard requires additional disclosures to help enable users of the financial statements to better understand the nature, amount, timing, risks, and judgments related to revenue recognition and related cash flows from contracts with customers.

[0001571996-17-000009:notes:38]
In August 2015, the FASB approved a one-year deferral of the effective date of this standard.  Public entities are required to adopt the new standard for fiscal years, and interim periods within those years, beginning after December 15, 2017.  The new revenue standard may be applied retrospectively to each prior period presented (full retrospective method) or retrospectively with the cumulative effect of initially applying the standard recognized at the date of initial application in retained earnings (modified retrospective method).  The Company currently expects to adopt this standard retrospectively to each prior period presented for the fiscal year beginning February 3, 2018.

[0001571996-17-000009:notes:39]
While the Company is currently evaluating the financial and system impacts that the new standard will have on the Condensed Consolidated Financial Statements, the Company expects that unearned license revenue related to the sale of software licenses and related deliverables will decline upon adoption.  Currently, the Company defers revenue for certain software arrangements due to the absence of vendor specific objective evidence ("VSOE") of fair value for all or a portion of the deliverables.  Under the new standard, the Company will no longer be required to establish VSOE of fair value in order to account for elements in an arrangement as separate units of accounting, and will be able to record revenue upon satisfaction of each performance obligation.  Additionally, the Company expects the new standard to have an impact in the way the transaction price is allocated for certain non-standard warranties.  The new standard is expected to result in more of the aggregate transaction price related to the non-standard warranty being recorded as revenue upon delivery of the underlying product, because the Company will no longer defer revenue based on the separately stated price of the non-standard warranty provided under the contract.  The Company continues to make progress in assessing the impacts of the standard on the Condensed Consolidated Financial Statements and will continue to evaluate the impact of any changes to the standard or interpretations should they become available.

[0001571996-17-000009:notes:40]
Recognition and Measurement of Financial Assets and Financial Liabilities — In January 2016, the FASB issued amended guidance on Recognition and Measurement of Financial Assets and Financial Liabilities.  The standard addresses certain aspects of recognition, measurement, presentation, and disclosure of financial instruments.  Public entities must adopt the new guidance for fiscal years, and interim periods within those years, beginning after December 15, 2017.  The Company does not expect that the standard will have a material impact on the Condensed Consolidated Financial Statements.

[0001571996-17-000009:notes:41]
Leases — In February 2016, the FASB issued amended guidance on the accounting for leasing transactions.  The primary objective of this update is to increase transparency and comparability among organizations by recognizing lease assets and lease liabilities on the balance sheet and disclosing key information about leasing arrangements.  Public entities must adopt the new guidance for reporting periods beginning after December 15, 2018, with early adoption permitted.  Companies are required to use a modified retrospective approach for leases that exist or are entered into after the beginning of the earliest comparative period in the financial statements.  The Company is currently evaluating the impact that the standard will have on the Condensed Consolidated Financial Statements.

[0001571996-17-000009:notes:42]
Improvements to Employee Share-Based Payment Accounting — In March 2016, the FASB issued amended guidance on the accounting for employee share-based payments, including the accounting for income taxes and forfeitures, classification of awards as either equity or liabilities, and classification of cash flows.  The Company adopted this guidance during the three months ended May 5, 2017.  In accordance with the new guidance, excess tax benefits or deficiencies for stock-based compensation are now reflected as a component of the provision for income taxes on the Condensed Consolidated Statements of Income (Loss), whereas they were previously recorded as additional paid-in capital.  The Company has elected to continue to estimate expected forfeitures.  Additionally, the Company now presents excess tax benefits as an operating activity rather than a financing activity on the Condensed Consolidated Statements of Cash Flows, while the cash flows related to employee taxes paid for withheld shares are presented as a financing activity with prior periods adjusted accordingly.  The adoption of the amended guidance did not have a material impact on the Condensed Consolidated Financial Statements.  The prospective impact of the new standard will depend on the Company's stock price at the vesting or exercise dates of the awards and the number of awards that vest or are exercised in each period, but we do not expect the impact to be material in future periods.

[0001571996-17-000009:notes:43]
Measurement of Credit Losses on Financial Instruments — In June 2016, the FASB issued amended guidance which replaces the current incurred loss impairment methodology with a methodology that reflects expected credit losses and requires consideration of a broader range of reasonable and supportable information to inform credit loss estimates.  Public entities must adopt the new guidance for fiscal years beginning after December 15, 2019, including interim periods within those fiscal years.  All entities may adopt the amendments in the new standard as of fiscal years beginning after December 15, 2018, including interim periods within those fiscal years.  Earlier adoption is not permitted.  The Company is currently evaluating the impact that the standard will have on the Condensed Consolidated Financial Statements.

[0001571996-17-000009:notes:44]
Classification of Certain Cash Receipts and Cash Payments — In August 2016, the FASB issued amended guidance on the presentation and classification of eight specific cash flow issues with the objective of reducing existing diversity in practice.  Public entities must adopt the new guidance for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2017, with early adoption permitted.  Companies should reflect any adjustments on a retrospective basis, if practicable; otherwise, adoption is required to be applied as of the earliest date practicable.  The Company is currently evaluating the timing of adoption as well as the impact that the standard will have on the Condensed Consolidated Financial Statements.

[0001571996-17-000009:notes:45]
Intra-Entity Transfers of Assets Other Than Inventory — In October 2016, the FASB issued amended guidance on the accounting for income taxes.  The new guidance requires companies to recognize the income tax effects of intra-entity asset transfers, other than transfers of inventory, when the transfer occurs instead of when the asset is sold to a third party.  The new guidance should be applied on a modified-retrospective basis with the cumulative-effect adjustment to retained earnings as of the beginning of the period of adoption.  The Company early adopted this guidance during the three months ended May 5, 2017.  At adoption, approximately $84 million was reclassified from other non-current liabilities to retained earnings, resulting in a net credit to retained earnings.

[0001571996-17-000009:notes:46]
Simplifying the Test for Goodwill Impairment — In January 2017, the FASB issued amended guidance to simplify the subsequent measurement of goodwill by removing Step 2 of the goodwill impairment test.  Instead, under the amendments in the new guidance, an entity should perform its annual, or interim, goodwill impairment test by comparing the fair value of a reporting unit with its carrying amount.  An entity should recognize an impairment charge for the amount by which the carrying amount exceeds the reporting unit's fair value.  Public entities must adopt the new guidance in fiscal years beginning after December 15, 2019, with early adoption permitted.  The Company is currently evaluating the impact of the new guidance and timing of adoption, but does not expect that the standard will have an impact on its Condensed Consolidated Financial Statements.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001571996-17-000009:notes:47]
COMMITMENTS AND CONTINGENCIES

[0001571996-17-000009:notes:48]
Legal Matters

[0001571996-17-000009:notes:49]
The Company is involved in various claims, suits, assessments, investigations, and legal proceedings that arise from time to time in the ordinary course of its business, including those identified below, consisting of matters involving consumer, antitrust, tax, intellectual property, and other issues on a global basis.  The Company accrues a liability when it believes that it is both probable that a liability has been incurred and that it can reasonably estimate the amount of the loss.  The Company reviews these accruals at least quarterly and adjusts them to reflect ongoing negotiations, settlements, rulings, advice of legal counsel, and other relevant information.  To the extent new information is obtained and the Company's views on the probable outcomes of claims, suits, assessments, investigations, or legal proceedings change, changes in the Company's accrued liabilities would be recorded in the period in which such a determination is made.  For some matters, the amount of liability is not probable or the amount cannot be reasonably estimated and therefore accruals have not been made.  The following is a discussion of the Company's significant legal matters and other proceedings:

[0001571996-17-000009:notes:50]
EMC Merger Litigation — The Company, Dell, and Universal Acquisition Co. ("Universal") were named as defendants in fifteen putative class-action lawsuits brought by purported EMC shareholders and VMware, Inc. stockholders challenging the proposed merger between the Company, Dell, and Universal on the one hand, and EMC on the other (the "EMC merger").  Those suits are captioned as follows:

[0001571996-17-000009:notes:51]
| Case | Court | Filing Date |
| 1. | IBEW Local No. 129 Benefit Fund v. Tucci,Civ. No. 1584-3130-BLS1 | Mass. Superior Court, Suffolk County | 10/15/2015 |
| 2. | Barrett v. Tucci,Civ. No. 15-6023-A | Mass. Superior Court, Middlesex County | 10/16/2015 |
| 3. | Graulich v. Tucci,Civ. No. 1584-3169-BLS1 | Mass. Superior Court, Suffolk County | 10/19/2015 |
| 4. | Vassallo v. EMC Corp.,Civ. No. 1584-3173-BLS1 | Mass. Superior Court, Suffolk County | 10/19/2015 |
| 5. | City of Miami Police Relief & Pension Fund v. Tucci,Civ. No. 1584-3174-BLS1 | Mass. Superior Court, Suffolk County | 10/19/2015 |
| 6. | Lasker v. EMC Corp.,Civ. No. 1584-3214-BLS1 | Mass. Superior Court, Suffolk County | 10/23/2015 |
| 7. | Walsh v. EMC Corp.,Civ. No. 15-13654 | U.S. District Court,District of Massachusetts | 10/27/2015 |
| 8. | Local Union No. 373 U.A. Pension Plan v. EMC Corp.,Civ. No. 1584-3253-BLS1 | Mass. Superior Court, Suffolk County | 10/28/2015 |
| 9. | City of Lakeland Emps.' Pension & Ret. Fund v. Tucci,Civ. No. 1584-3269-BLS1 | Mass. Superior Court, Suffolk County | 10/28/2015 |
| 10. | Ma v. Tucci,Civ. No. 1584-3281-BLS1 | Mass. Superior Court, Suffolk County | 10/29/2015 |
| 11. | Stull v. EMC Corp.,Civ. No. 15-13692 | U.S. District Court,District of Massachusetts | 10/30/2015 |
| 12. | Jacobs v. EMC Corp.,Civ. No. 15-6318-H | Mass. Superior Court, Middlesex County | 11/12/2015 |
| 13. | Ford v. VMware, Inc.,C.A. No. 11714-VCL | Delaware Chancery Court | 11/17/2015 |
| 14. | Pancake v. EMC Corp.,Civ. No. 16-10040 | U.S. District Court,District of Massachusetts | 1/11/2016 |
| 15. | Booth Family Trust v. EMC Corp.,Civ. No. 16-10114 | U.S. District Court,District of Massachusetts | 1/26/2016 |

[0001571996-17-000009:notes:52]
The fifteen lawsuits sought, among other things, injunctive relief enjoining the EMC merger, rescission of the EMC merger if consummated, an award of fees and costs, and/or an award of damages.

[0001571996-17-000009:notes:53]
The complaints in the IBEW, Barrett, Graulich, Vassallo, City of Miami, Lasker, Local Union No. 373, City of Lakeland, and Ma actions generally allege that the EMC directors breached their fiduciary duties to EMC shareholders in connection with the EMC merger by, among other things, failing to maximize shareholder value and agreeing to provisions in the EMC merger agreement that discouraged competing bids.  After consolidating the nine complaints, by decision dated December 7, 2015, the Business Litigation Session of the Suffolk County Superior Court in Massachusetts dismissed all nine complaints for failure to make a demand on the EMC board of directors.  Three of the nine plaintiffs in the consolidated actions appealed the judgment dismissing their complaints.  The Massachusetts Supreme Judicial Court granted an application for direct appellate review, and heard oral argument on the appeal on November 7, 2016.  On March 6, 2017, the Supreme Judicial Court issued a decision affirming the dismissal.  This decision terminated the consolidated actions.

[0001571996-17-000009:notes:54]
The complaints in the Walsh, Stull, Pancake, and Booth actions allege that the EMC directors breached their fiduciary duties to EMC shareholders in connection with the EMC merger by, among other things, failing to maximize shareholder value and agreeing to provisions in the EMC merger agreement that discouraged competing bids.  The complaints generally further allege that the preliminary registration statement on Form S-4 filed by the Company on December 14, 2015 in connection with the transaction contained material misstatements and omissions, in violation of Section 14(a) of the Securities Exchange Act of 1934 (the "Exchange Act") and SEC Rule 14a-9 promulgated thereunder and/or that the Company, Dell, and Universal acted as controlling persons of EMC under Section 20(a) of the Exchange Act.  On June 6, 2016, the Securities and Exchange Commission declared effective the Company's registration statement on Form S-4 relating to the EMC merger (the "SEC Form S-4"), including the amendments thereto.  On June 17, 2016, the parties to the Walsh, Stull, Pancake, and Booth actions submitted to the Court a Stipulation and Proposed Order Dismissing Action and Retaining Jurisdiction to Determine Plaintiffs' Counsel's Application for an Award of Attorneys' Fees and Reimbursement of Expenses.  In the stipulation, the plaintiffs represented to the Court that they believe sufficient information had been disclosed to warrant dismissal of the actions as moot in light of the disclosures in the SEC Form S-4, including the amendments thereto.  On October 25, 2016, following an agreement between the parties with respect to attorneys' fees and expenses, the Court entered an order terminating the four actions for all purposes.

[0001571996-17-000009:notes:55]
The amended complaints in the Jacobs and Ford actions allege that EMC, as the majority stockholder of VMware, Inc., and the individual defendants, who were directors of EMC, VMware, Inc., or both, breached their fiduciary duties to minority stockholders of VMware, Inc. in connection with the proposed EMC merger by allegedly entering into or approving a merger that favors the interests of EMC and Dell at the expense of the minority stockholders.  The plaintiffs in the Jacobs action also brought suit against the Company, Dell, and Universal as alleged aiders and abettors.  Effective December 2, 2016, the parties entered into an agreement to resolve the Jacobs action, pursuant to which the plaintiff voluntarily dismissed the action with prejudice.  Under the operative amended complaint in the Ford action, the plaintiffs also brought suit against the Company and Dell for alleged breach of fiduciary duties to VMware, Inc. and its stockholders, and against the Company, Dell, and Universal for aiding and abetting the alleged breach of fiduciary duties by EMC's and VMware, Inc.'s directors.  Certain defendants filed motions to dismiss the amended complaint on June 21, 2016.  A hearing on those motions was held on February 3, 2017.  On May 2, 2017, the Court dismissed the amended complaint for failure to state a claim upon which relief could be granted and no appeal was taken.  All fifteen EMC merger-related lawsuits are now fully and finally resolved.

[0001571996-17-000009:notes:56]
Appraisal Proceedings — Holders of shares of Dell common stock who did not vote on September 12, 2013 in favor of the proposal to adopt the amended going-private transaction agreement and who properly demanded appraisal of their shares and who otherwise comply with the requirements of Section 262 of the Delaware General Corporate Law ("DGCL") are entitled to seek appraisal for, and obtain payment in cash for the judicially determined "fair value" (as defined pursuant to Section 262 of the DGCL) of, their shares in lieu of receiving the going-private transaction consideration.  Dell initially recorded a liability of $13.75 for each share with respect to which appraisal has been demanded and as to which the demand has not been withdrawn, together with interest at the statutory rate discussed below.  As of May 5, 2017 and February 3, 2017, this liability was approximately $129 million.  The Court of Chancery ruled that the fair value of the appraisal shares as of October 29, 2013, the date on which the going-private transaction became effective, was $17.62 per share.  This ruling would entitle the holders of the remaining 5,505,730 shares subject to the appraisal proceedings to $17.62 per share, plus interest at a statutory rate, compounded quarterly.  On November 21, 2016, the Court of Chancery entered final judgment in the appraisal action.  On November 22, 2016, Dell filed a notice of appeal to the Delaware Supreme Court.  That appeal is pending.  The Company believes it was adequately reserved for the appraisal proceedings as of May 5, 2017.

[0001571996-17-000009:notes:57]
Securities Litigation — On May 22, 2014, a securities class action seeking compensatory damages was filed in the United States District Court for the Southern District of New York, captioned the City of Pontiac Employee Retirement System vs. Dell Inc. et. al. (Case No. 1:14-cv-03644).  The action names as defendants Dell Inc. and certain current and former executive officers, and alleges that Dell made false and misleading statements about Dell's business operations and products between February 22, 2012 and May 22, 2012, which resulted in artificially inflated stock prices.  The case was transferred to the United States District Court for the Western District of Texas, where the defendants filed a motion to dismiss.  On September 16, 2016, the Court denied the motion to dismiss and the case is proceeding with discovery.  The defendants believe the claims asserted are without merit and the risk of material loss is remote.

[0001571996-17-000009:notes:58]
Copyright Levies — The Company's obligation to collect and remit copyright levies in certain European Union ("EU") countries may be affected by the resolution of legal proceedings pending in Germany against various companies, including Dell's German subsidiary, and elsewhere in the EU against other companies in Dell's industry.  The plaintiffs in those proceedings, some of which are described below, generally seek to impose or modify the levies with respect to sales of such equipment as multifunction devices, phones, personal computers, and printers, alleging that such products enable the copying of copyrighted materials.  Some of the proceedings also challenge whether the levy schemes in those countries comply with EU law.  Certain EU member countries that do not yet impose levies on digital devices are expected to implement legislation to enable them to extend existing levy schemes, while some other EU member countries are expected to limit the scope of levy schemes and their applicability in the digital hardware environment.  Dell, other companies, and various industry associations have opposed the extension of levies to the digital environment and have advocated alternative models of compensation to rights holders.  The Company continues to collect levies in certain EU countries where it has determined that based on local laws it is probable that it has a payment obligation.  The amount of levies is generally based on the number of products sold and the per-product amounts of the levies, which vary.  The Company accrues a liability when it believes that it is both probable that a loss has been incurred and when it can reasonably estimate the amount of the loss.

[0001571996-17-000009:notes:59]
On December 29, 2005, Zentralstelle für private Überspielungsrechte ("ZPÜ"), a joint association of various German collecting societies, instituted arbitration proceedings against Dell's German subsidiary before the Board of Arbitration at the German Patent and Trademark Office in Munich, and subsequently filed a lawsuit in the German Regional Court in Munich on February 21, 2008, seeking levies to be paid on each personal computer sold by Dell in Germany through the end of calendar year 2007.  On December 23, 2009, ZPÜ and the German industry association, BCH, reached a settlement regarding audio-video copyright levy litigation (with levies ranging from €3.15 to €13.65 per unit).  Dell joined this settlement on February 23, 2010, and has paid the amounts due under the settlement.  On March 25, 2014, ZPÜ and Dell reached a settlement for levies to be paid on each personal computer sold for the period of January 2, 2011 through December 31, 2016.  The amount of the settlement is not material to the Company.  The amount of any levies payable after calendar year 2016, as well as the Company's ability to recover such amounts through increased prices, remains uncertain.

[0001571996-17-000009:notes:60]
German courts are also considering a lawsuit originally filed in July 2004 by VG Wort, a German collecting society representing certain copyright holders, against Hewlett-Packard Company in the Stuttgart Civil Court seeking levies on printers, and a lawsuit originally filed in September 2003 by the same plaintiff against Fujitsu Siemens Computer GmbH in Munich Civil Court in Munich, Germany seeking levies on personal computers.  In each case, the civil and appellate courts held that the subject classes of equipment were subject to levies.  In July 2011, the German Federal Supreme Court, to which the lower court holdings have been appealed, referred each case to the Court of Justice of the European Union, submitting a number of legal questions on the interpretation of the European Copyright Directive which the German Federal Supreme Court deems necessary for its decision.  In August 2014, the German Supreme Court delivered an opinion ruling that printers and personal computers are subject to levies, and referred the case back to the Court of Appeals.  Dell joined the industry settlement in the Fujitsu Siemens case, and Dell believes it has no remaining material obligations in either case.

[0001571996-17-000009:notes:61]
Proceedings seeking to impose or modify copyright levies for sales of digital devices also have been instituted in courts in other EU member states.  Even in countries where Dell is not a party to such proceedings, decisions in those cases could impact Dell's business and the amount of copyright levies Dell may be required to collect.

[0001571996-17-000009:notes:62]
The ultimate resolution of these proceedings and the associated financial impact to the Company, if any, including the number of units potentially affected, the amount of levies imposed, and the ability of the Company to recover such amounts, remain uncertain at this time.  Should the courts determine there is liability for previous units shipped beyond the amount of levies the Company has collected or accrued, the Company would be liable for such incremental amounts.  Recovery of any such amounts from others by the Company would be possible only on future collections related to future shipments.

[0001571996-17-000009:notes:63]
Other Litigation — The various legal proceedings in which Dell is involved include commercial litigation and a variety of patent suits.  In some of these cases, Dell is the sole defendant.  More often, particularly in the patent suits, Dell is one of a number of defendants in the electronics and technology industries.  Dell is actively defending a number of patent infringement suits, and several pending claims are in various stages of evaluation.  While the number of patent cases varies over time, Dell does not currently anticipate that any of these matters will have a material adverse effect on its business, financial condition, results of operations, or cash flows.

[0001571996-17-000009:notes:64]
As of May 5, 2017, the Company does not believe there is a reasonable possibility that a material loss exceeding the amounts already accrued for these or other proceedings or matters has been incurred.  However, since the ultimate resolution of any such proceedings and matters is inherently unpredictable, the Company's business, financial condition, results of operations, or cash flows could be materially affected in any particular period by unfavorable outcomes in one or more of these proceedings or matters.  Whether the outcome of any claim, suit, assessment, investigation, or legal proceeding, individually or collectively, could have a material adverse effect on the Company's business, financial condition, results of operations, or cash flows will depend on a number of variables, including the nature, timing, and amount of any associated expenses, amounts paid in settlement, damages, or other remedies or consequences.

[0001571996-17-000009:notes:65]
Indemnifications

[0001571996-17-000009:notes:66]
In the ordinary course of business, the Company enters into contractual arrangements under which it may agree to indemnify the third party to such arrangements from any losses incurred relating to the services it performs on behalf of the Company or for losses arising from certain events as defined in the particular contract, such as litigation or claims relating to past performance.  Such indemnification obligations may not be subject to maximum loss clauses.  Historically, payments related to these indemnifications have not been material to the Company.

[0001571996-17-000009:notes:67]
In connection with the divestitures discussed in Note 3 of the Notes to the Condensed Consolidated Financial Statements, the Company has indemnified the purchasers of businesses for the occurrence of specified events.  The Company does not currently believe that contingent obligations to provide indemnification in connection with these divestitures will have a material adverse effect on the Company.

[0001571996-17-000009:notes:68]
Purchase Obligations

[0001571996-17-000009:notes:69]
The Company has contractual obligations to purchase goods or services, which specify significant terms, including fixed or minimum quantities to be purchased; fixed, minimum, or variable price provisions; and the approximate timing of the transaction.  As of May 5, 2017, the Company had $2,674 million, $260 million, and $432 million in purchase obligations for Fiscal 2018, Fiscal 2019, and Fiscal 2020 and thereafter, respectively.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001571996-17-000009:notes:70]
[same as prior period, unchanged from 0001571996-16-000021:notes:127]

[0001571996-17-000009:notes:71]
Accumulated other comprehensive loss is presented in stockholders' equity in the Condensed Consolidated Statements of Financial Position and consists of amounts related to foreign currency translation adjustments, unrealized net gains (losses) on investments, unrealized net gains (losses) on cash flow hedges, and actuarial net gains (losses) from pension and other postretirement plans.

[0001571996-17-000009:notes:72]
[same as prior period, unchanged from 0001571996-16-000021:notes:129]

[0001571996-17-000009:notes:73]
|  | Foreign Currency Translation Adjustments |  | Investments |  | Cash Flow Hedges |  | Pension and Other Postretirement Plans |  | Accumulated Other Comprehensive Loss |
|  | (in millions) |
| Balances as of February 3, 2017 | $ | (612 | ) |  | $ | (13 | ) |  | $ | 11 |  |  | $ | 19 |  |  | $ | (595 | ) |
| Other comprehensive income (loss) before reclassifications | 53 |  |  | 28 |  |  | (16 | ) |  | — |  |  | 65 |  |
| Amounts reclassified from accumulated other comprehensive loss | — |  |  | 1 |  |  | (21 | ) |  | — |  |  | (20 | ) |
| Total change for the period | 53 |  |  | 29 |  |  | (37 | ) |  | — |  |  | 45 |  |
| Less: Change in comprehensive income attributable to non-controlling interests | — |  |  | 2 |  |  | 1 |  |  | — |  |  | 3 |  |
| Balances as of May 5, 2017 | $ | (559 | ) |  | $ | 14 |  |  | $ | (27 | ) |  | $ | 19 |  |  | $ | (553 | ) |

[0001571996-17-000009:notes:74]
Amounts related to investments are reclassified to net income when gains and losses are realized.  See Note 4 and Note 5 of the Notes to the Condensed Consolidated Financial Statements for more information on the Company's investments.  Amounts related to the Company's cash flow hedges are reclassified to net income during the same period in which the items being hedged are recognized in earnings.  In addition, any hedge ineffectiveness related to cash flow hedges is recognized currently in net income.  See Note 8 of the Notes to the Condensed Consolidated Financial Statements for more information on the Company's derivative instruments.

[0001571996-17-000009:notes:75]
The following table presents reclassifications out of accumulated other comprehensive loss, net of tax, to net income (loss) for the periods presented:

[0001571996-17-000009:notes:76]
|  | Three Months Ended |
|  | May 5, 2017 |  | April 29, 2016 |
|  | Investments |  | Cash Flow Hedges |  | Total |  | Investments |  | Cash Flow Hedges |  | Total |
|  | (in millions) |
| Total reclassifications, net of tax: |  |  |  |  |  |  |  |  |  |  |  |
| Net revenue | $ | — |  |  | $ | 17 |  |  | $ | 17 |  |  | $ | — |  |  | $ | (45 | ) |  | $ | (45 | ) |
| Cost of net revenue | — |  |  | 4 |  |  | 4 |  |  | — |  |  | (8 | ) |  | (8 | ) |
| Interest and other, net | (1 | ) |  | — |  |  | (1 | ) |  | — |  |  | (1 | ) |  | (1 | ) |
| Total reclassifications, net of tax | $ | (1 | ) |  | $ | 21 |  |  | $ | 20 |  |  | $ | — |  |  | $ | (54 | ) |  | $ | (54 | ) |


## us-gaap:ConsolidationLessThanWhollyOwnedSubsidiaryParentOwnershipInterestEffectsOfChangesNetTextBlock

[0001571996-17-000009:notes:77]
The effect of changes in the Company's ownership interest in VMware, Inc., SecureWorks, and Pivotal on the Company's equity was as follows:

[0001571996-17-000009:notes:78]
|  | Three Months Ended |
|  | May 5, 2017 |  | April 29, 2016 |
|  | (in millions) |
| Net income (loss) attributable to Dell Technologies Inc. | $ | (1,334 | ) |  | $ | 55 |  |
| Transfers (to) from the non-controlling interests: |  |  |  |
| Increase in Dell Technologies Inc. additional paid-in-capital for equity issuances and other equity activity | 160 |  |  | — |  |
| Decrease in Dell Technologies Inc. additional paid-in-capital for equity issuances | (248 | ) |  | — |  |
| Net transfers to non-controlling interests | (88 | ) |  | — |  |
| Change from net income (loss) attributable to Dell Technologies Inc. and transfers to/from the non-controlling interests | $ | (1,422 | ) |  | $ | 55 |  |


## us-gaap:DebtDisclosureTextBlock

[0001571996-17-000009:notes:79]
DEBT

[0001571996-17-000009:notes:80]
The following table summarizes the Company's outstanding debt as of the dates indicated:

[0001571996-17-000009:notes:81]
|  | May 5, 2017 |  | February 3, 2017 |
|  | (in millions) |
| Secured Debt |  |  |  |
| Structured financing debt | $ | 3,869 |  |  | $ | 3,464 |  |
| Senior Secured Credit Facilities: |  |  |  |
| 3.50% Term Loan B Facility due September 2023 | 5,473 |  |  | 4,987 |  |
| 3.00% Term Loan A-1 Facility due December 2018 | 599 |  |  | 600 |  |
| 3.25% Term Loan A-2 Facility due September 2021 | 3,827 |  |  | 3,876 |  |
| 3.00% Term Loan A-3 Facility due December 2018 | 1,800 |  |  | 1,800 |  |
| 3.00% Revolving Credit Facility due September 2021 | 375 |  |  | 375 |  |
| First Lien Notes: |  |  |  |
| 3.48% due June 2019 | 3,750 |  |  | 3,750 |  |
| 4.42% due June 2021 | 4,500 |  |  | 4,500 |  |
| 5.45% due June 2023 | 3,750 |  |  | 3,750 |  |
| 6.02% due June 2026 | 4,500 |  |  | 4,500 |  |
| 8.10% due June 2036 | 1,500 |  |  | 1,500 |  |
| 8.35% due June 2046 | 2,000 |  |  | 2,000 |  |
| Unsecured Debt |  |  |  |
| Unsecured Notes and Debentures: |  |  |  |
| 5.65% due April 2018 | 500 |  |  | 500 |  |
| 5.875% due June 2019 | 600 |  |  | 600 |  |
| 4.625% due April 2021 | 400 |  |  | 400 |  |
| 7.10% due April 2028 | 300 |  |  | 300 |  |
| 6.50% due April 2038 | 388 |  |  | 388 |  |
| 5.40% due September 2040 | 265 |  |  | 265 |  |
| Senior Notes: |  |  |  |
| 5.875% due June 2021 | 1,625 |  |  | 1,625 |  |
| 7.125% due June 2024 | 1,625 |  |  | 1,625 |  |
| EMC Notes: |  |  |  |
| 1.875% due June 2018 | 2,500 |  |  | 2,500 |  |
| 2.650% due June 2020 | 2,000 |  |  | 2,000 |  |
| 3.375% due June 2023 | 1,000 |  |  | 1,000 |  |
| Other |  |  |  |
| 3.42% Margin Loan Facility due April 2022 | 2,000 |  |  | — |  |
| 2.53% Margin Bridge Facility due September 2017 | — |  |  | 2,500 |  |
| 2.75% VMware Note Bridge Facility due September 2017 | 1,500 |  |  | 1,500 |  |
| Other | 82 |  |  | 51 |  |
| Total debt, principal amount | $ | 50,728 |  |  | $ | 50,356 |  |
| Unamortized discount, net of unamortized premium | (293 | ) |  | (284 | ) |
| Debt issuance costs | (645 | ) |  | (682 | ) |
| Total debt, carrying value | $ | 49,790 |  |  | $ | 49,390 |  |
| Total short-term debt, carrying value | $ | 4,842 |  |  | $ | 6,329 |  |
| Total long-term debt, carrying value | $ | 44,948 |  |  | $ | 43,061 |  |

[0001571996-17-000009:notes:82]
During the three months ended May 5, 2017, the Company refinanced the Term Loan B Facility to reduce the interest rate margin by 0.75% and to increase the outstanding principal amount by $500 million.  The Company applied the proceeds from the Term Loan B Facility refinancing to repay $500 million principal amount of the Margin Bridge Facility, without premium or penalty, and accrued and unpaid interest thereon.  Additionally, during the three months ended May 5, 2017, the Company issued the Margin Loan Facility in the principal amount of $2.0 billion, and used the proceeds of the new facility to extinguish the Margin Bridge Facility, without premium or penalty.

[0001571996-17-000009:notes:83]
Senior Secured Credit Facilities — At the closing of the EMC merger transaction on September 7, 2016, the Company entered into a credit agreement that provides for senior secured credit facilities (the "Senior Secured Credit Facilities") in the aggregate principal amount of $17.6 billion comprising (a) term loan facilities and (b) a senior secured Revolving Credit Facility, which includes capacity for up to $0.5 billion of letters of credit and for borrowings of up to $0.4 billion under swing-line loans.  As of May 5, 2017, available borrowings under the Revolving Credit Facility totaled $2.7 billion.  The Senior Secured Credit Facilities provide that the borrowers have the right at any time, subject to customary conditions, to request incremental term loans or incremental revolving commitments.

[0001571996-17-000009:notes:84]
Borrowings under the Senior Secured Credit Facilities bear interest at a rate per annum equal to an applicable margin, plus, at the borrowers' option, either (a) a base rate, which, under the Term Loan B Facility, is subject to an interest rate floor of 1.75% per annum, and under all other borrowings is subject to an interest rate floor of 0% per annum, or (b) a London interbank offered rate ("LIBOR"), which, under the Term Loan B Facility, is subject to an interest rate floor of 0.75% per annum, and under all other borrowings is subject to an interest rate floor of 0% per annum.  Interest is payable, in the case of loans bearing interest based on LIBOR, at the end of each interest period (but at least every three months), in arrears and, in the case of loans bearing interest based on the base rate, quarterly in arrears.

[0001571996-17-000009:notes:85]
The Term Loan A-1 Facility, the Term Loan A-3 Facility, and the Revolving Credit Facility have no amortization.  The Term Loan A-2 Facility amortizes in equal quarterly installments in aggregate annual amounts equal to 5% of the original principal amount in each of the first two years after the closing date of the EMC merger transaction, 10% of the original principal amount in each of the third and fourth years after the closing date of the EMC merger transaction, and 70% of the original principal amount in the fifth year after the closing date of the EMC merger transaction.  The Term Loan B Facility amortizes in equal quarterly installments in aggregate annual amounts equal to 1% of the original principal amount.  The Term Loan A-1 and Term Loan A-3 Facilities require the borrowers to prepay outstanding borrowings under these facilities with 100% of the net cash proceeds of certain non-ordinary course asset sales or dispositions.  The borrowers may voluntarily repay outstanding loans under the term loan facilities and the Revolving Credit Facility at any time without premium or penalty, other than customary "breakage" costs.

[0001571996-17-000009:notes:86]
All obligations of the borrowers under the Senior Secured Credit Facilities and certain swap agreements, cash management arrangements, and certain letters of credit provided by any lender or agent party to the Senior Secured Credit Facilities or any of its affiliates and certain other persons are secured by (a) a first-priority security interest in certain tangible and intangible assets of the borrowers and the guarantors and (b) a first-priority pledge of 100% of the capital stock of the borrowers, Dell Inc., an indirect wholly-owned subsidiary of Dell Technologies ("Dell"), and each wholly-owned material restricted subsidiary of the borrowers and the guarantors, in each case subject to certain thresholds, exceptions, and permitted liens.

[0001571996-17-000009:notes:87]
During the three months ended May 5, 2017, the Company refinanced the Term Loan B Facility to reduce the interest rate margin by 0.75% and to increase the outstanding principal amount by $500 million.

[0001571996-17-000009:notes:88]
First Lien Notes — The senior secured notes (collectively, the "First Lien Notes") were issued on June 1, 2016 in an aggregate principal amount of $20.0 billion.  Interest on these borrowings is payable semiannually.  The First Lien Notes are secured, on a pari passu basis with the Senior Secured Credit Facilities, on a first-priority basis by substantially all of the tangible and intangible assets of the issuers and guarantors that secure obligations under the Senior Secured Credit Facilities, including pledges of all capital stock of the issuers, of Dell, and of certain wholly-owned material subsidiaries of the issuers and the guarantors, subject to certain exceptions.

[0001571996-17-000009:notes:89]
The Company has agreed to use commercially reasonable efforts to register with the SEC notes having terms substantially identical to the terms of the First Lien Notes as part of an offer to exchange such registered notes for the First Lien Notes.  The Company will be obligated to pay additional interest on the First Lien Notes if it fails to consummate such an exchange offer within five years after the closing date of the EMC merger transaction.

[0001571996-17-000009:notes:90]
Senior Notes — The senior unsecured notes (collectively, the "Senior Notes") were issued on June 22, 2016 in an aggregate principal amount of $3.25 billion.  Interest on these borrowings is payable semiannually.

[0001571996-17-000009:notes:91]
EMC Notes — On September 7, 2016, EMC had outstanding $2.5 billion aggregate principal amount of its 1.875% Notes due June 2018, $2.0 billion aggregate principal amount of its 2.650% Notes due June 2020 and $1.0 billion aggregate principal amount of its 3.375% Notes due June 2023 (collectively, the "EMC Notes").  Interest on these borrowings is payable semiannually.  The EMC Notes remain outstanding following the closing of the EMC merger transaction.

[0001571996-17-000009:notes:92]
Margin Loan Facility — During the three months ended May 5, 2017, the Company issued the Margin Loan Facility in an aggregate principal amount of $2.0 billion.  VMW Holdco LLC, a wholly owned subsidiary of EMC, is the borrower under the Margin Loan Facility, which is secured by 60 million shares of Class B common stock of VMware, Inc. and 20 million shares of Class A common stock of VMware, Inc.  Loans under the Margin Loan Facility bear interest at a rate per annum payable, at the borrower's option, either at (a) a base rate plus 1.25% per annum or (b) a LIBOR-based rate plus 2.25% per annum.  Interest under the Margin Loan Facility is payable quarterly.

[0001571996-17-000009:notes:93]
The Margin Loan Facility will mature in April 2022.  The borrower may voluntarily repay outstanding loans under the Margin Loan Facility at any time without premium or penalty, other than customary "breakage" costs, subject to certain minimum threshold amounts for prepayment.

[0001571996-17-000009:notes:94]
Margin Bridge Facility — On September 7, 2016, Merger Sub and EMC entered into a credit agreement providing for a senior secured margin bridge facility in an aggregate principal amount of $2.5 billion (the "Margin Bridge Facility").

[0001571996-17-000009:notes:95]
During the three months ended May 5, 2017, the Company separately applied the proceeds from the Term Loan B Facility refinancing and the issuance of the Margin Loan Facility to extinguish the Margin Bridge Facility, without premium or penalty.

[0001571996-17-000009:notes:96]
VMware Note Bridge Facility — On September 7, 2016, Merger Sub and EMC entered into a credit agreement providing for a senior secured note bridge facility in an aggregate principal amount of $1.5 billion (the "VMware Note Bridge Facility").  The VMware Note Bridge Facility is secured solely by certain intercompany notes in an aggregate principal amount of $1.5 billion issued by VMware, Inc. that are payable to EMC, and the proceeds thereof.

[0001571996-17-000009:notes:97]
Interest under the VMware Note Bridge Facility is payable, at the borrower's option, either at (a) a base rate plus 0.75% per annum or (b) a LIBOR-based rate plus 1.75% per annum.  Interest is payable, in the case of loans bearing interest based on LIBOR, at the end of each interest period (but at least every three months), in arrears and, in the case of loans bearing interest based on the base rate, quarterly in arrears.

[0001571996-17-000009:notes:98]
The VMware Note Bridge Facility has no amortization.  The borrower is required to prepay outstanding borrowings under the VMware Note Bridge Facility with 100% of the net cash proceeds of any asset sale or other disposition of the pledged VMware, Inc. promissory notes.  The borrower may voluntarily repay outstanding loans under the VMware Note Bridge Facility at any time without premium or penalty, other than customary "breakage" costs, subject to certain minimum threshold amounts for prepayment.

[0001571996-17-000009:notes:99]
Structured Financing Debt — As of May 5, 2017 and February 3, 2017, the Company had $3.9 billion and $3.5 billion, respectively, in outstanding structured financing debt, which was primarily related to the fixed-term lease and loan securitization programs and the revolving loan securitization programs.  See Note 6 and Note 8 of the Notes to the Condensed Consolidated Financial Statements for further discussion of the structured financing debt and the interest rate swap agreements that hedge a portion of that debt.

[0001571996-17-000009:notes:100]
Unsecured Notes and Debentures — The Company has unsecured notes and debentures (collectively, the "Unsecured Notes and Dentures") that were issued prior to the acquisition of Dell by Dell Technologies Inc.  Interest on these borrowings is payable semiannually.

[0001571996-17-000009:notes:101]
Aggregate Future Maturities — As of May 5, 2017, aggregate future maturities of the Company's debt were as follows:

[0001571996-17-000009:notes:102]
|  | Maturities by Fiscal Year |
|  | 2018 (remaining nine months) |  | 2019 |  | 2020 |  | 2021 |  | 2022 |  | Thereafter |  | Total |
|  | (in millions) |
| Structured Financing Debt | $ | 2,039 |  |  | $ | 1,291 |  |  | $ | 406 |  |  | $ | 107 |  |  | $ | 26 |  |  | $ | — |  |  | $ | 3,869 |  |
| Senior Secured Credit Facilities and First Lien Notes | 188 |  |  | 2,699 |  |  | 4,197 |  |  | 336 |  |  | 7,677 |  |  | 16,977 |  |  | 32,074 |  |
| Unsecured Notes and Debentures | — |  |  | 500 |  |  | 600 |  |  | — |  |  | 400 |  |  | 953 |  |  | 2,453 |  |
| Senior Notes and EMC Notes | — |  |  | 2,500 |  |  | — |  |  | 2,000 |  |  | 1,625 |  |  | 2,625 |  |  | 8,750 |  |
| Margin Loan Facility | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 2,000 |  |  | 2,000 |  |
| Bridge Facility | 1,500 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 1,500 |  |
| Other | 9 |  |  | 18 |  |  | 3 |  |  | 27 |  |  | — |  |  | 25 |  |  | 82 |  |
| Total maturities, principal amount | 3,736 |  |  | 7,008 |  |  | 5,206 |  |  | 2,470 |  |  | 9,728 |  |  | 22,580 |  |  | 50,728 |  |
| Associated carrying value adjustments | (9 | ) |  | (42 | ) |  | (51 | ) |  | (1 | ) |  | (230 | ) |  | (605 | ) |  | (938 | ) |
| Total maturities, carrying value amount | $ | 3,727 |  |  | $ | 6,966 |  |  | $ | 5,155 |  |  | $ | 2,469 |  |  | $ | 9,498 |  |  | $ | 21,975 |  |  | $ | 49,790 |  |

[0001571996-17-000009:notes:103]
Covenants and Unrestricted Net Assets — The credit agreement for the Senior Secured Credit Facilities contain customary negative covenants that generally limit the ability of Denali Intermediate Inc., a wholly-owned subsidiary of Dell Technologies ("Dell Intermediate"), Dell, and Dell's and Denali Intermediate's other restricted subsidiaries to incur debt, create liens, make fundamental changes, enter into asset sales, make certain investments, pay dividends or distribute or redeem certain equity interests, prepay or redeem certain debt, and enter into certain transactions with affiliates.  The indenture governing the Senior Notes contains customary negative covenants that generally limit the ability of Denali Intermediate, Dell, and Dell's and Denali Intermediate's other restricted subsidiaries to incur additional debt or issue certain preferred shares, pay dividends on or make other distributions in respect of capital stock or make other restricted payments, make certain investments, sell or transfer certain assets, create liens on certain assets to secure debt, consolidate, merge, sell, or otherwise dispose of all or substantially all assets, enter into certain transactions with affiliates, and designate subsidiaries as unrestricted subsidiaries.  The negative covenants under such credit agreements and indenture are subject to certain exceptions, qualifications, and "baskets."  The indentures governing the First Lien Notes, the Unsecured Notes and Debentures, and the EMC Notes variously impose limitations, subject to specified exceptions, on creating certain liens, entering into sale and lease-back transactions, and entering into certain asset sales.  As of May 5, 2017, the Company had certain consolidated subsidiaries that were designated as unrestricted subsidiaries for all purposes of the applicable credit agreements and the indentures governing the First Lien Notes and the Senior Notes.  The foregoing credit agreements and indentures contain customary events of default, including failure to make required payments, failure to comply with covenants, and the occurrence of certain events of bankruptcy and insolvency.

[0001571996-17-000009:notes:104]
The Term Loan A-1 Facility, the Term Loan A-2 Facility, the Term Loan A-3 Facility, and the Revolving Credit Facility are subject to a first lien net leverage ratio covenant that is tested at the end of each fiscal quarter of Dell with respect to Dell's preceding four fiscal quarters.  The Company was in compliance with all financial covenants as of May 5, 2017.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001571996-17-000009:notes:105]
[same as prior period, unchanged from 0001571996-16-000021:notes:169]

[0001571996-17-000009:notes:106]
[same as prior period, unchanged from 0001571996-16-000021:notes:170]

[0001571996-17-000009:notes:107]
As part of its risk management strategy, the Company uses derivative instruments, primarily foreign currency forward and option contracts and interest rate swaps, to hedge certain foreign currency and interest rate exposures, respectively.

[0001571996-17-000009:notes:108]
The Company's objective is to offset gains and losses resulting from these exposures with gains and losses on the derivative contracts used to hedge the exposures, thereby reducing volatility of earnings and protecting the fair values of assets and liabilities.  For derivatives designated as cash flow hedges, the Company assesses hedge effectiveness both at the onset of the hedge and at regular intervals throughout the life of the derivative and recognizes any ineffective portion of the hedge in earnings as a component of interest and other, net.  Hedge ineffectiveness recognized in earnings was not material during the three months ended May 5, 2017 and April 29, 2016.

[0001571996-17-000009:notes:109]
[same as prior period, unchanged from 0001571996-16-000021:notes:174]

[0001571996-17-000009:notes:110]
[same as prior period, unchanged from 0001571996-16-000021:notes:175]

[0001571996-17-000009:notes:111]
During the three months ended May 5, 2017 and April 29, 2016, the Company did not discontinue any cash flow hedges related to foreign exchange contracts that had a material impact on the Company's results of operations due to the probability that the forecasted cash flows would not occur.

[0001571996-17-000009:notes:112]
[same as prior period, unchanged from 0001571996-16-000021:notes:177]

[0001571996-17-000009:notes:113]
[same as prior period, unchanged from 0001571996-16-000021:notes:178]

[0001571996-17-000009:notes:114]
[same as prior period, unchanged from 0001571996-16-000021:notes:179]

[0001571996-17-000009:notes:115]
[same as prior period, unchanged from 0001571996-16-000021:notes:180]

[0001571996-17-000009:notes:116]
[same as prior period, unchanged from 0001571996-16-000021:notes:181]

[0001571996-17-000009:notes:117]
The Company utilizes cross currency amortizing swaps to hedge the currency and interest rate risk exposure associated with the securitization program that was established in Europe in January 2017.  The cross currency swaps combine a Euro-based interest rate swap with a British Pound or U.S. Dollar foreign exchange forward contract in which the Company pays a fixed British Pound or U.S. Dollar amount and receives a floating amount in Euro linked to the one-month Euribor.  The notional value of the swaps amortizes in line with the expected cash flows and run-off of the securitized assets.  The swaps mature within five years or less and are not designated for hedge accounting.

[0001571996-17-000009:notes:118]
[same as prior period, unchanged from 0001571996-16-000021:notes:182]

[0001571996-17-000009:notes:119]
[same as prior period, unchanged from 0001571996-16-000021:notes:183]

[0001571996-17-000009:notes:120]
|  | May 5, 2017 |  | February 3, 2017 (a) |
|  | (in millions) |
| Foreign exchange contracts: |  |  |  |  |  |
| Designated as cash flow hedging instruments | $ | 4,113 |  |  | $ | 3,781 |  |
| Non-designated as hedging instruments | 5,767 |  |  | 5,146 |  |
| Total | $ | 9,880 |  |  | $ | 8,927 |  |
| Interest rate contracts: |  |  |  |
| Non-designated as hedging instruments | $ | 1,033 |  |  | $ | 1,251 |  |

[0001571996-17-000009:notes:121]
| (a) | The notional amount calculation methodology has been enhanced to reflect the sum of the absolute value of derivative instruments netted by currency. Prior period amounts have been updated to conform with the current period presentation. |

[0001571996-17-000009:notes:122]
Effect of Derivative Instruments on the Condensed Consolidated Statements of Financial Position and the Condensed Consolidated Statements of Income (Loss)

[0001571996-17-000009:notes:123]
| Derivatives inCash FlowHedging Relationships |  | Gain (Loss)Recognizedin AccumulatedOCI, Netof Tax, onDerivatives(Effective Portion) |  | Location of Gain (Loss)Reclassifiedfrom AccumulatedOCI into Income(Effective Portion) |  | Gain (Loss)Reclassifiedfrom AccumulatedOCI into Income(Effective Portion) |  | Location of Gain (Loss) Recognized in Income on Derivative (Ineffective Portion) |  | Gain (Loss) Recognized in Income on Derivative (Ineffective Portion) |
| (in millions) |
| For the three months ended May 5, 2017 |  |  |  |  |  |  |
|  |  |  |  |  | Total net revenue |  | $ | 17 |  |  |  |  |  |
| Foreign exchange contracts |  | $ | (16 | ) |  | Total cost of net revenue |  | 4 |  |  |  |  |  |
| Interest rate contracts |  | — |  |  | Interest and other, net |  | — |  |  | Interest and other, net |  | $ | — |  |
| Total |  | $ | (16 | ) |  |  |  | $ | 21 |  |  |  |  | $ | — |  |
| For the three months ended April 29, 2016 |  |  |  |  |  |  |
|  |  |  |  |  | Total net revenue |  | $ | (45 | ) |  |  |  |  |
| Foreign exchange contracts |  | $ | (165 | ) |  | Total cost of net revenue |  | (8 | ) |  |  |  |  |
| Interest rate contracts |  | — |  |  | Interest and other, net |  | — |  |  | Interest and other, net |  | $ | (1 | ) |
| Total |  | $ | (165 | ) |  |  |  | $ | (53 | ) |  |  |  | $ | (1 | ) |

[0001571996-17-000009:notes:124]
Fair Value of Derivative Instruments in the Condensed Consolidated Statements of Financial Position

[0001571996-17-000009:notes:125]
[same as prior period, unchanged from 0001571996-16-000021:notes:188]

[0001571996-17-000009:notes:126]
|  | May 5, 2017 |
|  | Other CurrentAssets |  | Other Non-Current Assets |  | Other CurrentLiabilities |  | Other Non-CurrentLiabilities |  | TotalFair Value |
|  |  |  | (in millions) |  |  |
| Derivatives designated as hedging instruments: |
| Foreign exchange contracts in an asset position | $ | 37 |  |  | $ | — |  |  | $ | 21 |  |  | $ | — |  |  | $ | 58 |  |
| Foreign exchange contracts in a liability position | (17 | ) |  | — |  |  | (22 | ) |  | — |  |  | (39 | ) |
| Net asset (liability) | 20 |  |  | — |  |  | (1 | ) |  | — |  |  | 19 |  |
| Derivatives not designated as hedging instruments: |
| Foreign exchange contracts in an asset position | 161 |  |  | 1 |  |  | 52 |  |  | — |  |  | 214 |  |
| Foreign exchange contracts in a liability position | (77 | ) |  | — |  |  | (154 | ) |  | — |  |  | (231 | ) |
| Interest rate contracts in an asset position | — |  |  | 3 |  |  | — |  |  | — |  |  | 3 |  |
| Interest rate contracts in a liability position | — |  |  | — |  |  | — |  |  | (6 | ) |  | (6 | ) |
| Net asset (liability) | 84 |  |  | 4 |  |  | (102 | ) |  | (6 | ) |  | (20 | ) |
| Total derivatives at fair value | $ | 104 |  |  | $ | 4 |  |  | $ | (103 | ) |  | $ | (6 | ) |  | $ | (1 | ) |
|  | February 3, 2017 |
|  | Other CurrentAssets |  | Other Non-Current Assets |  | Other CurrentLiabilities |  | Other Non-CurrentLiabilities |  | TotalFair Value |
|  |  |  | (in millions) |  |  |
| Derivatives designated as hedging instruments: |
| Foreign exchange contracts in an asset position | $ | 41 |  |  | $ | — |  |  | $ | 17 |  |  | $ | — |  |  | $ | 58 |  |
| Foreign exchange contracts in a liability position | (19 | ) |  | — |  |  | (6 | ) |  | — |  |  | (25 | ) |
| Net asset (liability) | 22 |  |  | — |  |  | 11 |  |  | — |  |  | 33 |  |
| Derivatives not designated as hedging instruments: |
| Foreign exchange contracts in an asset position | 309 |  |  | 2 |  |  | 31 |  |  | — |  |  | 342 |  |
| Foreign exchange contracts in a liability position | (131 | ) |  | — |  |  | (103 | ) |  | — |  |  | (234 | ) |
| Interest rate contracts in an asset position | — |  |  | 3 |  |  | — |  |  | — |  |  | 3 |  |
| Interest rate contracts in a liability position | — |  |  | — |  |  | — |  |  | (3 | ) |  | (3 | ) |
| Net asset (liability) | 178 |  |  | 5 |  |  | (72 | ) |  | (3 | ) |  | 108 |  |
| Total derivatives at fair value | $ | 200 |  |  | $ | 5 |  |  | $ | (61 | ) |  | $ | (3 | ) |  | $ | 141 |  |

[0001571996-17-000009:notes:127]
The following table presents the gross amounts of the Company's derivative instruments, amounts offset due to master netting agreements with the Company's counterparties, and the net amounts recognized in the Condensed Consolidated Statements of Financial Position.

[0001571996-17-000009:notes:128]
|  | May 5, 2017 |
|  | Gross Amounts of Recognized Assets/ (Liabilities) |  | Gross Amounts Offset in the Statement of Financial Position |  | Net Amounts of Assets/ (Liabilities) Presented in the Statement of Financial Position |  | Gross Amounts not Offset in the Statement of Financial Position |  | Net Amount |
|  | Financial Instruments |  | Cash Collateral Received or Pledged |  |
|  | (in millions) |
| Derivative instruments: |  |  |  |  |  |  |  |  |  |  |  |
| Financial assets | $ | 275 |  |  | $ | (167 | ) |  | $ | 108 |  |  | $ | — |  |  | $ | — |  |  | $ | 108 |  |
| Financial liabilities | (276 | ) |  | 167 |  |  | (109 | ) |  | — |  |  | — |  |  | (109 | ) |
| Total derivative instruments | $ | (1 | ) |  | $ | — |  |  | $ | (1 | ) |  | $ | — |  |  | $ | — |  |  | $ | (1 | ) |
|  | February 3, 2017 |
|  | Gross Amounts of Recognized Assets/ (Liabilities) |  | Gross Amounts Offset in the Statement of Financial Position |  | Net Amounts of Assets/ (Liabilities) Presented in the Statement of Financial Position |  | Gross Amounts not Offset in the Statement of Financial Position |  | Net Amount |
|  | Financial Instruments |  | Cash Collateral Received or Pledged |  |
|  | (in millions) |
| Derivative instruments: |  |  |  |  |  |  |  |  |  |  |  |
| Financial assets | $ | 403 |  |  | $ | (198 | ) |  | $ | 205 |  |  | $ | — |  |  | $ | — |  |  | $ | 205 |  |
| Financial liabilities | (262 | ) |  | 198 |  |  | (64 | ) |  | — |  |  | — |  |  | (64 | ) |
| Total derivative instruments | $ | 141 |  |  | $ | — |  |  | $ | 141 |  |  | $ | — |  |  | $ | — |  |  | $ | 141 |  |


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0001571996-17-000009:notes:129]
[same as prior period, unchanged from 0001571996-16-000021:notes:238]

[0001571996-17-000009:notes:130]
Dell entered into a definitive agreement with NTT Data International L.L.C. to divest substantially all of Dell Services, and on November 2, 2016, the parties closed substantially all of the transaction.  Dell entered into a definitive agreement with Francisco Partners and Elliot Management Corporation to divest substantially all of DSG, and on October 31, 2016, the parties closed the transaction.  EMC, a subsidiary of the Company, entered into a definitive agreement with OpenText Corporation to divest the Dell EMC Enterprise Content Division, and on January 23, 2017, the parties closed the transaction.

[0001571996-17-000009:notes:131]
Upon closing of the respective transactions, the Company entered into transition services agreements with NTT Data International L.L.C., Francisco Partners and Elliot Management, and OpenText Corporation pursuant to which the Company provides various administrative services on an interim transitional basis.  Transition services may be provided for up to one year, with an option to renew after that period.  The Company also entered into various commercial agreements with NTT Data International, Francisco Partners and Elliot Management, and OpenText Corporation that include reseller agreements for certain offerings.

[0001571996-17-000009:notes:132]
In accordance with applicable accounting guidance, the Company reclassified the financial results of Dell Services, DSG, and ECD as discontinued operations in the Condensed Consolidated Statements of Income (Loss) for the relevant periods.  The following table presents key financial results of Dell Services and DSG included in "Income from discontinued operations, net of income taxes (Note 3)" for the three months ended April 29, 2016:

[0001571996-17-000009:notes:133]
|  | Three Months Ended April 29, 2016 |
|  | Dell Services |  | DSG |  | Total |
|  | (in millions) |
| Net revenue | $ | 646 |  |  | $ | 321 |  |  | $ | 967 |  |
| Cost of net revenue | 519 |  |  | 90 |  |  | 609 |  |
| Operating expenses | 111 |  |  | 249 |  |  | 360 |  |
| Interest and other, net | — |  |  | 14 |  |  | 14 |  |
| Income (loss) from discontinued operations before income taxes | 16 |  |  | (4 | ) |  | 12 |  |
| Income tax benefit (a) | (463 | ) |  | (4 | ) |  | (467 | ) |
| Income from discontinued operations, net of income taxes | $ | 479 |  |  | $ | — |  |  | $ | 479 |  |

[0001571996-17-000009:notes:134]
| (a) | The tax benefit for Dell Services recorded during the three months ended April 29, 2016 was primarily due to temporary differences arising from outside basis differences in the stock entities to be disposed, offset by a valuation allowance. |

[0001571996-17-000009:notes:135]
Cash flows from the Company's discontinued operations are included in the accompanying Condensed Consolidated Statements of Cash Flows.  The significant cash flow items from Dell Services and DSG for the three months ended April 29, 2016 were as follows:

[0001571996-17-000009:notes:136]
|  | Three Months Ended April 29, 2016 |
|  | Dell Services |  | DSG |  | Total |
|  | (in millions) |
| Depreciation and amortization (a) | $ | 32 |  |  | $ | 42 |  |  | $ | 74 |  |
| Capital expenditures | $ | 19 |  |  | $ | 6 |  |  | $ | 25 |  |

[0001571996-17-000009:notes:137]
| (a) | Depreciation and amortization ceased upon determination that Dell Services and DSG had met the criteria for discontinued operations reporting as of March 27, 2016 and June 19, 2016, respectively. |


## us-gaap:EarningsPerShareTextBlock

[0001571996-17-000009:notes:138]
[same as prior period, unchanged from 0001571996-16-000021:notes:269]

[0001571996-17-000009:notes:139]
[same as prior period, unchanged from 0001571996-16-000021:notes:270]

[0001571996-17-000009:notes:140]
The Company has two groups of common stock, denoted as the DHI Group Common Stock and the Class V Common Stock.  The DHI Group Common Stock consists of four classes of common stock, referred to as Class A Common Stock, Class B Common Stock, Class C Common Stock, and Class D Common Stock.  The DHI Group generally refers to the direct and indirect interest of Dell Technologies in all of Dell Technologies' business, assets, properties, liabilities, and preferred stock other than those attributable to the Class V Group, as well as its retained interest in the Class V Group equal to approximately 38% of the Company's economic interest in the Class V Group as of May 5, 2017.  The Class V Common Stock is intended to track the economic performance of approximately 62% of the Company's economic interest in the Class V Group as of such date.  As of May 5, 2017, the Class V Group consisted solely of approximately 334 million shares of VMware, Inc. common stock held by the Company.  See Note 17 of the Notes to the Condensed Consolidated Financial Statements and Exhibit 99.1 to the Company's quarterly report on Form 10-Q for the quarterly period ended May 5, 2017 for more information regarding the allocation of earnings from Dell Technologies' interest in VMware, Inc. between the DHI Group and the Class V Common Stock.

[0001571996-17-000009:notes:141]
[same as prior period, unchanged from 0001571996-16-000021:notes:272]

[0001571996-17-000009:notes:142]
[same as prior period, unchanged from 0001571996-16-000021:notes:273]

[0001571996-17-000009:notes:143]
|  | Three Months Ended |
|  | May 5, 2017 |  | April 29, 2016 |
| Earnings (loss) per share attributable to Dell Technologies Inc. - basic: |
| Continuing operations - Class V Common Stock - basic | $ | 0.57 |  |  | $ | — |  |
| Continuing operations - DHI Group - basic | $ | (2.57 | ) |  | $ | (1.05 | ) |
| Discontinued operations - DHI Group - basic | $ | — |  |  | $ | 1.18 |  |
| Earnings (loss) per share attributable to Dell Technologies Inc. - diluted: |
| Continuing operations - Class V Common Stock - diluted | $ | 0.56 |  |  | $ | — |  |
| Continuing operations - DHI Group - diluted | $ | (2.57 | ) |  | $ | (1.05 | ) |
| Discontinued operations - DHI Group - diluted | $ | — |  |  | $ | 1.18 |  |

[0001571996-17-000009:notes:144]
[same as prior period, unchanged from 0001571996-16-000021:notes:275]

[0001571996-17-000009:notes:145]
|  | Three Months Ended |
|  | May 5, 2017 |  | April 29, 2016 |
|  | (in millions) |
| Numerator: Continuing operations - Class V Common Stock |  |  |  |
| Net income from continuing operations attributable to Class V Common Stock - basic | $ | 118 |  |  | $ | — |  |
| Incremental dilution from VMware, Inc. attributable to Class V Common Stock (a) | (2 | ) |  | — |  |
| Net income from continuing operations attributable to Class V Common Stock - diluted | $ | 116 |  |  | $ | — |  |
| Numerator: Continuing operations - DHI Group |  |  |  |
| Net loss from continuing operations attributable to DHI Group - basic | $ | (1,452 | ) |  | $ | (424 | ) |
| Incremental dilution from VMware, Inc. attributable to DHI Group (a) | (1 | ) |  | — |  |
| Net loss from continuing operations attributable to DHI Group - diluted | $ | (1,453 | ) |  | $ | (424 | ) |
| Numerator: Discontinued operations - DHI Group |  |  |  |
| Income from discontinued operations, net of income taxes - basic and diluted | $ | — |  |  | $ | 479 |  |
| Denominator: Class V Common Stock weighted-average shares outstanding |  |  |  |  |  |
| Weighted-average shares outstanding - basic | 207 |  |  | — |  |
| Dilutive effect of options, restricted stock units, restricted stock, and other (b) | — |  |  | — |  |
| Weighted-average shares outstanding - diluted | 207 |  |  | — |  |
| Weighted-average shares outstanding - antidilutive (b) | — |  |  | — |  |
| Denominator: DHI Group weighted-average shares outstanding |  |  |  |
| Weighted-average shares outstanding - basic | 566 |  |  | 405 |  |
| Dilutive effect of options, restricted stock units, restricted stock, and other | — |  |  | — |  |
| Weighted-average shares outstanding - diluted | 566 |  |  | 405 |  |
| Weighted-average shares outstanding - antidilutive (c) | 37 |  |  | 54 |  |

[0001571996-17-000009:notes:146]
| (a) | The incremental dilution from VMware, Inc. represents the impact of VMware, Inc.'s dilutive securities on the diluted earnings (loss) per share of the DHI Group and the Class V Common Stock, respectively, and is calculated by multiplying the difference between VMware, Inc.'s basic and diluted earnings (loss) per share by the number of shares of VMware, Inc. Class A common stock owned by the Company. |

[0001571996-17-000009:notes:147]
| (b) | The dilutive effect of Class V Common Stock-based incentive awards was not material to the calculation of the weighted-average Class V Common Stock shares outstanding. The antidilutive effect of these awards was also not material. |

[0001571996-17-000009:notes:148]
[same as prior period, unchanged from 0001571996-16-000021:notes:279]


## us-gaap:FairValueDisclosuresTextBlock

[0001571996-17-000009:notes:149]
[same as prior period, unchanged from 0001571996-16-000021:notes:283]

[0001571996-17-000009:notes:150]
The following table presents the Company's hierarchy for its assets and liabilities measured at fair value on a recurring basis as of May 5, 2017 and February 3, 2017:

[0001571996-17-000009:notes:151]
|  | May 5, 2017 (a) |  | February 3, 2017 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | QuotedPricesin ActiveMarkets forIdenticalAssets |  | SignificantOtherObservableInputs |  | SignificantUnobservableInputs |  |  |  | QuotedPricesin ActiveMarkets forIdenticalAssets |  | SignificantOtherObservableInputs |  | SignificantUnobservableInputs |  |  |
|  | (in millions) |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | $ | 5,477 |  |  | $ | — |  |  | $ | — |  |  | $ | 5,477 |  |  | $ | 4,866 |  |  | $ | — |  |  | $ | — |  |  | $ | 4,866 |  |
| Municipal obligations | — |  |  | 15 |  |  | — |  |  | 15 |  |  | — |  |  | 3 |  |  | — |  |  | 3 |  |
| Debt securities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. government and agencies | 454 |  |  | 430 |  |  | — |  |  | 884 |  |  | 444 |  |  | 470 |  |  | — |  |  | 914 |  |
| U.S. corporate | — |  |  | 1,720 |  |  | — |  |  | 1,720 |  |  | — |  |  | 1,800 |  |  | — |  |  | 1,800 |  |
| Foreign | — |  |  | 1,888 |  |  | — |  |  | 1,888 |  |  | — |  |  | 2,083 |  |  | — |  |  | 2,083 |  |
| Municipal obligations | — |  |  | 206 |  |  | — |  |  | 206 |  |  | — |  |  | 352 |  |  | — |  |  | 352 |  |
| Asset-backed securities | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 4 |  |  | — |  |  | 4 |  |
| Equity and other securities | 204 |  |  | 1 |  |  | — |  |  | 205 |  |  | 169 |  |  | — |  |  | — |  |  | 169 |  |
| Derivative instruments | — |  |  | 108 |  |  | — |  |  | 108 |  |  | — |  |  | 205 |  |  | — |  |  | 205 |  |
| Total assets | $ | 6,135 |  |  | $ | 4,368 |  |  | $ | — |  |  | $ | 10,503 |  |  | $ | 5,479 |  |  | $ | 4,917 |  |  | $ | — |  |  | $ | 10,396 |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Derivative instruments | $ | — |  |  | $ | 109 |  |  | $ | — |  |  | $ | 109 |  |  | $ | — |  |  | $ | 64 |  |  | $ | — |  |  | $ | 64 |  |
| Total liabilities | $ | — |  |  | $ | 109 |  |  | $ | — |  |  | $ | 109 |  |  | $ | — |  |  | $ | 64 |  |  | $ | — |  |  | $ | 64 |  |

[0001571996-17-000009:notes:152]
(a)   The Company did not transfer any securities between levels during the three months ended May 5, 2017.

[0001571996-17-000009:notes:153]
[same as prior period, unchanged from 0001571996-16-000021:notes:284]

[0001571996-17-000009:notes:154]
Money Market Funds — The Company's investment in money market funds that are classified as cash equivalents hold underlying investments with a weighted average maturity of 90 days or less and are recognized at fair value.  The valuations of these securities are based on quoted prices in active markets for identical assets, when available, or pricing models whereby all significant inputs are observable or can be derived from or corroborated by observable market data.  The Company reviews security pricing and assesses liquidity on a quarterly basis.  As of May 5, 2017, the Company's U.S. portfolio had no material exposure to money market funds with a fluctuating net asset value.

[0001571996-17-000009:notes:155]
[same as prior period, unchanged from 0001571996-16-000021:notes:286]

[0001571996-17-000009:notes:156]
Debt Securities — The majority of the Company's debt securities consist of various fixed income securities such as U.S. government and agencies, U.S. corporate, and foreign.  Valuation is based on pricing models whereby all significant inputs, including benchmark yields, reported trades, broker-dealer quotes, issue spreads, benchmark securities, bids, offers, and other market related data, are observable or can be derived from or corroborated by observable market data for substantially the full term of the asset.  Inputs are documented in accordance with the fair value measurements hierarchy.  The Company reviews security pricing and assesses liquidity on a quarterly basis.  See Note 5 of the Notes to the Condensed Consolidated Financial Statements for additional information about investments.

[0001571996-17-000009:notes:157]
Equity and Other Securities — The majority of the Company's investments in equity and other securities that are measured at fair value on a recurring basis consist of strategic investments in publicly traded companies.  The valuation of these securities is based on quoted prices in active markets.

[0001571996-17-000009:notes:158]
Derivative Instruments — The Company's derivative financial instruments consist primarily of foreign currency forward and purchased option contracts and interest rate swaps.  The fair value of the portfolio is determined using valuation models based on market observable inputs, including interest rate curves, forward and spot prices for currencies, and implied volatilities.  Credit risk is also factored into the fair value calculation of the Company's derivative instrument portfolio.  See Note 8 of the Notes to the Condensed Consolidated Financial Statements for a description of the Company's derivative financial instrument activities.

[0001571996-17-000009:notes:159]
Assets and Liabilities Measured at Fair Value on a Nonrecurring Basis — Certain assets are measured at fair value on a nonrecurring basis and therefore are not included in the recurring fair value table above.  These assets consist primarily of non-financial assets such as goodwill and intangible assets.  See Note 9 of the Notes to the Condensed Consolidated Financial Statements for additional information about goodwill and intangible assets.

[0001571996-17-000009:notes:160]
As of May 5, 2017 and February 3, 2017, the Company held strategic investments of $489 million and $455 million, respectively.  These investments are accounted for under the cost method and are not included in the recurring fair value table above.  Investments accounted for under the cost method are recorded at cost initially, which approximates fair value.  Subsequently, if there is an indicator of impairment, the impairment is recognized.  In evaluating these investments for impairment, the Company uses inputs including pre- and post-money valuations of recent financing events and the impact of those on its fully diluted ownership percentages, as well as other available information regarding the issuer's historical and forecasted performance.  As these investments are early-stage companies which are not publicly traded, it is not practicable for the Company to reliably estimate the fair value of these investments.

[0001571996-17-000009:notes:161]
Carrying Value and Estimated Fair Value of Outstanding Debt — The following table summarizes the carrying value and estimated fair value of the Company's outstanding debt as described in Note 7 of the Notes to the Condensed Consolidated Financial Statements, including the current portion, as of the dates indicated:

[0001571996-17-000009:notes:162]
|  | May 5, 2017 |  | February 3, 2017 |
|  | Carrying Value |  | Fair Value |  | Carrying Value |  | Fair Value |
|  | (in billions) |
| Senior Secured Credit Facilities | $ | 11.8 |  |  | $ | 12.1 |  |  | $ | 11.4 |  |  | $ | 11.7 |  |
| First Lien Notes | $ | 19.7 |  |  | $ | 22.1 |  |  | $ | 19.7 |  |  | $ | 21.8 |  |
| Unsecured Notes and Debentures | $ | 2.3 |  |  | $ | 2.5 |  |  | $ | 2.3 |  |  | $ | 2.5 |  |
| Senior Notes | $ | 3.1 |  |  | $ | 3.5 |  |  | $ | 3.1 |  |  | $ | 3.5 |  |
| EMC Notes | $ | 5.5 |  |  | $ | 5.4 |  |  | $ | 5.5 |  |  | $ | 5.4 |  |
| Margin Loan Facility | $ | 2.0 |  |  | $ | 2.0 |  |  | $ | — |  |  | $ | — |  |
| Bridge Facilities | $ | 1.5 |  |  | $ | 1.5 |  |  | $ | 4.0 |  |  | $ | 4.0 |  |

[0001571996-17-000009:notes:163]
The fair values of the outstanding Senior Secured Credit Facilities, First Lien Notes, Unsecured Notes and Debentures, Senior Notes, EMC Notes, Margin Loan Facility, and Bridge Facilities were determined based on observable market prices in a less active market or based on valuation methodologies using observable inputs and were categorized as Level 2 in the fair value hierarchy.  The fair values of the other short-term debt and the structured financing debt approximate their carrying values due to their short-term maturities.


## us-gaap:FinancingReceivableCreditQualityIndicatorsTableTextBlock

[0001571996-17-000009:notes:164]
The following table summarizes customer receivables, gross, including accrued interest, by credit quality indicator segregated by class, as of May 5, 2017 and February 3, 2017.  The categories shown in the table below segregate customer receivables based on the relative degrees of credit risk.  The credit quality indicators for DPA revolving accounts are measured primarily as of each quarter-end date, while all other indicators are generally updated on a periodic basis.

[0001571996-17-000009:notes:165]
For DPA revolving receivables shown in the table below, the Company makes credit decisions based on proprietary scorecards, which include the customer's credit history, payment history, credit usage, and other credit agency-related elements.  The higher quality category includes prime accounts generally of a higher credit quality that are comparable to U.S. customer FICO scores of 720 or above.  The mid-category represents the mid-tier accounts that are comparable to U.S. customer FICO scores from 660 to 719.  The lower category is generally sub-prime and represents lower credit quality accounts that are comparable to U.S. customer FICO scores below 660.  For the DBC revolving receivables and fixed-term commercial receivables shown in the table below, an internal grading system is utilized that assigns a credit level score based on a number of considerations, including liquidity, operating performance, and industry outlook.  The grading criteria and classifications for the fixed-term products differ from those for the revolving products as loss experience varies between these product and customer groups.  The credit quality categories cannot be compared between the different classes as loss experience varies substantially between the classes.

[0001571996-17-000009:notes:166]
|  | May 5, 2017 |  | February 3, 2017 |
|  | Higher |  | Mid |  | Lower |  | Total |  | Higher |  | Mid |  | Lower |  | Total |
|  | (in millions) |
| Revolving — DPA | $ | 134 |  |  | $ | 216 |  |  | $ | 400 |  |  | $ | 750 |  |  | $ | 136 |  |  | $ | 244 |  |  | $ | 428 |  |  | $ | 808 |  |
| Revolving — DBC | $ | 56 |  |  | $ | 58 |  |  | $ | 76 |  |  | $ | 190 |  |  | $ | 61 |  |  | $ | 60 |  |  | $ | 80 |  |  | $ | 201 |  |
| Fixed-term — Consumer and Commercial (a) | $ | 2,333 |  |  | $ | 1,474 |  |  | $ | 896 |  |  | $ | 4,703 |  |  | $ | 2,232 |  |  | $ | 1,428 |  |  | $ | 870 |  |  | $ | 4,530 |  |

[0001571996-17-000009:notes:167]
| (a) | During the three months ended May 5, 2017, the Company modified its credit scoring methodology for fixed-term financing receivables in response to changes in its go-to-market strategy. This methodology has been modified to a single, consistent, and comparable model across all fixed-term product customers. In connection with this change, the Company has re-categorized existing fixed-term customers and has recast prior period credit quality categories to align with the current period presentation. |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001571996-17-000009:notes:168]
[same as prior period, unchanged from 0001571996-16-000021:notes:302]

[0001571996-17-000009:notes:169]
[same as prior period, unchanged from 0001571996-16-000021:notes:303]

[0001571996-17-000009:notes:170]
The following table presents goodwill allocated to the Company's business segments as of May 5, 2017 and February 3, 2017, and changes in the carrying amount of goodwill for the respective periods:

[0001571996-17-000009:notes:171]
|  | Client Solutions Group |  | Infrastructure Solutions Group |  | VMware |  | Other Businesses (a) |  | Total |
|  | (in millions) |
| Balances as of February 3, 2017 | $ | 4,237 |  |  | $ | 15,607 |  |  | $ | 15,070 |  |  | $ | 3,996 |  |  | $ | 38,910 |  |
| Goodwill recognized during the period | — |  |  | — |  |  | — |  |  | 9 |  |  | 9 |  |
| Goodwill divested | — |  |  | (13 | ) |  | — |  |  | — |  |  | (13 | ) |
| Impact of foreign currency translation | — |  |  | 23 |  |  | — |  |  | 1 |  |  | 24 |  |
| Other adjustments | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Balances as of May 5, 2017 | $ | 4,237 |  |  | $ | 15,617 |  |  | $ | 15,070 |  |  | $ | 4,006 |  |  | $ | 38,930 |  |

[0001571996-17-000009:notes:172]
| (a) | Other Businesses consists of offerings by RSA Information Security, SecureWorks, Pivotal, and Boomi, Inc. ("Boomi"). |

[0001571996-17-000009:notes:173]
Goodwill and indefinite-lived intangible assets are tested for impairment annually during the third fiscal quarter and whenever events or circumstances may indicate that an impairment has occurred.  Based on the results of the annual impairment test, which was a qualitative test, no impairment of goodwill or indefinite-lived intangible assets existed for any reporting unit as of October 28, 2016.  No events or circumstances transpired subsequent to the annual impairment test that would indicate a potential impairment of goodwill as of May 5, 2017.  Further, the Company did not have any accumulated goodwill impairment charges as of May 5, 2017.

[0001571996-17-000009:notes:174]
[same as prior period, unchanged from 0001571996-16-000021:notes:311]

[0001571996-17-000009:notes:175]
[same as prior period, unchanged from 0001571996-16-000021:notes:312]

[0001571996-17-000009:notes:176]
The Company's intangible assets as of May 5, 2017 and February 3, 2017 were as follows:

[0001571996-17-000009:notes:177]
|  | May 5, 2017 |  | February 3, 2017 |
|  | Gross |  | AccumulatedAmortization |  | Net |  | Gross |  | AccumulatedAmortization |  | Net |
|  | (in millions) |
| Customer relationships | $ | 22,711 |  |  | $ | (6,324 | ) |  | $ | 16,387 |  |  | $ | 22,708 |  |  | $ | (5,552 | ) |  | $ | 17,156 |  |
| Developed technology | 15,381 |  |  | (3,455 | ) |  | 11,926 |  |  | 14,569 |  |  | (2,510 | ) |  | 12,059 |  |
| Trade names | 1,267 |  |  | (258 | ) |  | 1,009 |  |  | 1,268 |  |  | (201 | ) |  | 1,067 |  |
| Leasehold assets (liabilities) | 128 |  |  | (2 | ) |  | 126 |  |  | 128 |  |  | (1 | ) |  | 127 |  |
| Definite-lived intangible assets | 39,487 |  |  | (10,039 | ) |  | 29,448 |  |  | 38,673 |  |  | (8,264 | ) |  | 30,409 |  |
| In-process research and development | 80 |  |  | — |  |  | 80 |  |  | 890 |  |  | — |  |  | 890 |  |
| Indefinite-lived trade names | 3,755 |  |  | — |  |  | 3,755 |  |  | 3,754 |  |  | — |  |  | 3,754 |  |
| Total intangible assets | $ | 43,322 |  |  | $ | (10,039 | ) |  | $ | 33,283 |  |  | $ | 43,317 |  |  | $ | (8,264 | ) |  | $ | 35,053 |  |

[0001571996-17-000009:notes:178]
Amortization expense related to definite-lived intangible assets was approximately $1,776 million and $491 million during the three months ended May 5, 2017 and April 29, 2016, respectively.  There were no material impairment charges related to intangible assets during the three months ended May 5, 2017 and April 29, 2016.

[0001571996-17-000009:notes:179]
Estimated future annual pre-tax amortization expense of definite-lived intangible assets as of February 3, 2017 over the next five fiscal years and thereafter is as follows:

[0001571996-17-000009:notes:180]
| Fiscal Years | (in millions) |
| 2018 (remaining nine months) | $ | 5,178 |  |
| 2019 | 6,026 |  |
| 2020 | 4,238 |  |
| 2021 | 3,316 |  |
| 2022 | 2,609 |  |
| Thereafter | 8,081 |  |
| Total | $ | 29,448 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001571996-17-000009:notes:181]
[same as prior period, unchanged from 0001571996-16-000021:notes:319]

[0001571996-17-000009:notes:182]
For the three months ended May 5, 2017 and April 29, 2016, the Company's effective income tax rates for continuing operations were 33.3% and (18.4)% on pre-tax losses from continuing operations of $2,073 million and $358 million, respectively.  The change in the Company's effective income tax rate was primarily attributable to prior year tax charges recognized during the three months ended April 29, 2016 relating to the divestiture of Dell Services, as well as tax benefits from charges associated with the EMC merger transaction incurred during the three months ended May 5, 2017, including purchase accounting adjustments, interest charges, and stock-based compensation expense.  For more information regarding the EMC merger transaction, see Note 2 of the Notes to the Condensed Consolidated Financial Statements.  The income tax rate for future quarters of Fiscal 2018 will be impacted by the actual mix of jurisdictions in which income is generated.

[0001571996-17-000009:notes:183]
The differences between the estimated effective income tax rates and the U.S. federal statutory rate of 35% principally result from the Company's geographical distribution of income and differences between the book and tax treatment of certain items.  A portion of the Company's operations is subject to a reduced tax rate or is free of tax under various tax holidays.  A significant portion of these income tax benefits relate to a tax holiday that expires in January 2019.  The Company's other tax holidays will expire in whole or in part during fiscal years 2019 through 2023.  Many of these tax holidays and reduced tax rates may be extended when certain conditions are met or may be terminated early if certain conditions are not met.

[0001571996-17-000009:notes:184]
The Company's U.S. federal income tax returns for fiscal years 2007 through 2009 are currently under consideration by the Office of Appeals of the Internal Revenue Service (the "IRS").  The IRS issued a Revenue Agent's Report ("RAR") related to those years during the fiscal year ended February 3, 2017.  The IRS has proposed adjustments primarily relating to transfer pricing matters with which the Company disagrees and will contest through the IRS administrative appeals procedures.  Prior to the EMC merger transaction, EMC received a RAR for its tax years 2009 and 2010, and during the three months ended May 5, 2017, EMC received an RAR for its tax year 2011.  The Company also disagrees with certain proposed adjustments in these RARs and is currently contesting the proposed adjustments through the IRS administrative appeals process.

[0001571996-17-000009:notes:185]
The Company is also currently under income tax audits in various state and foreign jurisdictions.  The Company is undergoing negotiations, and in some cases contested proceedings, relating to tax matters with the taxing authorities in these jurisdictions.  The Company believes that it has provided adequate reserves related to all matters contained in tax periods open to examination.  Although the Company believes it has made adequate provisions for the uncertainties surrounding these audits, should the Company experience unfavorable outcomes, such outcomes could have a material impact on its results of operations, financial position, and cash flows.  With respect to major U.S. state and foreign taxing jurisdictions, the Company is generally not subject to tax examinations for years prior to fiscal year 2007.

[0001571996-17-000009:notes:186]
Judgment is required in evaluating the Company's uncertain tax positions and determining the Company's provision for income taxes.  The Company's net unrecognized tax benefits were $3.1 billion as of both May 5, 2017 and February 3, 2017 and are included in other non-current liabilities in the Condensed Consolidated Statements of Financial Position.  The Company does not anticipate a significant change to the total amount of unrecognized tax benefits within the next twelve months.

[0001571996-17-000009:notes:187]
The Company takes certain non-income tax positions in the jurisdictions in which it operates and has received certain non-income tax assessments from various jurisdictions.  The Company believes that a material loss in these matters is not probable and that it is not reasonably possible that a material loss exceeding amounts already accrued has been incurred.  The Company believes its positions in these non-income tax litigation matters are supportable and that it ultimately will prevail in the matters.  In the normal course of business, the Company's positions and conclusions related to its non-income taxes could be challenged and assessments may be made.  To the extent new information is obtained and the Company's views on its positions, probable outcomes of assessments, or litigation change, changes in estimates to the Company's accrued liabilities would be recorded in the period in which such a determination is made.  In the resolution process for income tax and non-income tax audits, the Company may be required to provide collateral guarantees or indemnification to regulators and tax authorities until the matter is resolved.


## us-gaap:LoansNotesTradeAndOtherReceivablesDisclosureTextBlock

[0001571996-17-000009:notes:188]
FINANCIAL SERVICES

[0001571996-17-000009:notes:189]
The Company offers or arranges various financing options and services for its business and consumer customers in the United States, Canada, Europe, and Mexico through Dell Financial Services and its affiliates (collectively, "DFS").  The key activities of DFS include the origination, collection, and servicing of customer receivables primarily related to the purchase of Dell Technologies' products and services.  New financing originations, which represent the amounts of financing provided by DFS to customers for equipment and related software and services, including third-party originations, were $1.1 billion and $0.8 billion, respectively, for three months ended May 5, 2017 and April 29, 2016.

[0001571996-17-000009:notes:190]
The Company's financing receivables are aggregated into the following categories:

[0001571996-17-000009:notes:191]
| • | Revolving loans — Revolving loans offered under private label credit financing programs provide qualified customers with a revolving credit line for the purchase of products and services offered by Dell. These private label credit financing programs are referred to as Dell Preferred Account ("DPA") and Dell Business Credit ("DBC"). The DPA product is primarily offered to individual consumer customers, and the DBC product is primarily offered to small and medium-sized commercial customers. Revolving loans in the United States bear interest at a variable annual percentage rate that is tied to the prime rate. Based on historical payment patterns, revolving loan transactions are typically repaid within twelve months on average. |

[0001571996-17-000009:notes:192]
| • | Fixed-term sales-type leases and loans — The Company enters into sales-type lease arrangements with customers who seek lease financing. Leases with business customers have fixed terms of generally two to four years. Future maturities of minimum lease payments as of May 5, 2017 were as follows: Fiscal 2018 - $1,434 million; Fiscal 2019 - $1,276 million; Fiscal 2020 - $703 million; Fiscal 2021 - $214 million; Fiscal 2022 and beyond - $54 million. The Company also offers fixed-term loans to qualified small businesses, large commercial accounts, governmental organizations, educational entities, and certain individual consumer customers. These loans are repaid in equal payments including interest and have defined terms of generally three to five years. |

[0001571996-17-000009:notes:193]
The following table summarizes the components of the Company's financing receivables segregated by portfolio segment as of May 5, 2017 and February 3, 2017:

[0001571996-17-000009:notes:194]
|  | May 5, 2017 |  | February 3, 2017 |
|  | Revolving |  | Fixed-term |  | Total |  | Revolving |  | Fixed-term |  | Total |
|  | (in millions) |
| Financing receivables, net: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer receivables, gross | $ | 940 |  |  | $ | 4,703 |  |  | $ | 5,643 |  |  | $ | 1,009 |  |  | $ | 4,530 |  |  | $ | 5,539 |  |
| Allowances for losses | (85 | ) |  | (51 | ) |  | (136 | ) |  | (91 | ) |  | (52 | ) |  | (143 | ) |
| Customer receivables, net | 855 |  |  | 4,652 |  |  | 5,507 |  |  | 918 |  |  | 4,478 |  |  | 5,396 |  |
| Residual interest | — |  |  | 489 |  |  | 489 |  |  | — |  |  | 477 |  |  | 477 |  |
| Financing receivables, net | $ | 855 |  |  | $ | 5,141 |  |  | $ | 5,996 |  |  | $ | 918 |  |  | $ | 4,955 |  |  | $ | 5,873 |  |
| Short-term | $ | 855 |  |  | $ | 2,400 |  |  | $ | 3,255 |  |  | $ | 918 |  |  | $ | 2,304 |  |  | $ | 3,222 |  |
| Long-term | $ | — |  |  | $ | 2,741 |  |  | $ | 2,741 |  |  | $ | — |  |  | $ | 2,651 |  |  | $ | 2,651 |  |

[0001571996-17-000009:notes:195]
The following table summarizes the aging of the Company's customer financing receivables, gross, including accrued interest, as of May 5, 2017 and February 3, 2017, segregated by class:

[0001571996-17-000009:notes:196]
|  | May 5, 2017 |  | February 3, 2017 |
|  | Current |  | Past Due 1 — 90 Days |  | Past Due > 90 Days |  | Total |  | Current |  | Past Due 1 — 90 Days |  | Past Due > 90 Days |  | Total |
|  | (in millions) |
| Revolving — DPA | $ | 669 |  |  | $ | 58 |  |  | $ | 23 |  |  | $ | 750 |  |  | $ | 715 |  |  | $ | 66 |  |  | $ | 27 |  |  | $ | 808 |  |
| Revolving — DBC | 162 |  |  | 23 |  |  | 5 |  |  | 190 |  |  | 175 |  |  | 22 |  |  | 4 |  |  | 201 |  |
| Fixed-term — Consumer and Commercial | 4,116 |  |  | 510 |  |  | 77 |  |  | 4,703 |  |  | 3,994 |  |  | 506 |  |  | 30 |  |  | 4,530 |  |
| Total customer receivables, gross | $ | 4,947 |  |  | $ | 591 |  |  | $ | 105 |  |  | $ | 5,643 |  |  | $ | 4,884 |  |  | $ | 594 |  |  | $ | 61 |  |  | $ | 5,539 |  |

[0001571996-17-000009:notes:197]
Credit Quality

[0001571996-17-000009:notes:198]
Structured Financing Debt

[0001571996-17-000009:notes:199]
The Company maintains programs which facilitate the funding of financing receivables in the capital markets in the United States, Canada, and Europe.  The Company's total structured financing debt, which is collateralized by financing receivables, was $3.9 billion and $3.5 billion as of May 5, 2017 and February 3, 2017, respectively, under the following programs.

[0001571996-17-000009:notes:200]
| • | Securitization Programs — The Company maintains securitization programs in the United States and Europe. The securitization programs in the United States include the fixed-term lease and loan securitization program and the revolving loan securitization program. The outstanding balance of debt under these U.S. programs was $1.1 billion and $1.5 billion as of May 5, 2017 and February 3, 2017, respectively. This debt is collateralized solely by the U.S. financing receivables in the programs. The debt has a variable interest rate and the duration of this debt is based on the terms of the underlying financing receivables. As of May 5, 2017, the total debt capacity related to the U.S. securitization programs was $2.1 billion. The Company enters into interest swap agreements to effectively convert the portion of its structured financing debt from a floating rate to a fixed rate. See Note 8 of the Notes to the Condensed Consolidated Financial Statements for additional information about interest rate swaps. |

[0001571996-17-000009:notes:201]
The Company's U.S. securitization programs became effective on October 29, 2013.  The revolving program, which was extended during the third quarter of Fiscal 2017, is effective for four and one-half years beginning October 29, 2013.  The fixed-term program, which was extended during the first quarter of Fiscal 2016, is effective for four and one-half years beginning October 29, 2013.

[0001571996-17-000009:notes:202]
The Company established a securitization program in Europe for fixed-term leases and loans.  This program became effective on January 13, 2017, and is effective for two years.  The outstanding balance of debt under this program was $302 million as of May 5, 2017, and the total debt capacity related to the securitization program was $659 million.

[0001571996-17-000009:notes:203]
The securitization programs contain standard structural features related to the performance of the securitized receivables which include defined credit losses, delinquencies, average credit scores, and minimum collection requirements.  In the event one or more of these criteria are not met and the Company is unable to restructure the program, no further funding of receivables will be permitted and the timing of the Company's expected cash flows from over-collateralization will be delayed.  As of May 5, 2017, these criteria were met.

[0001571996-17-000009:notes:204]
| • | Fixed-Term Securitization Programs — The Company periodically issues asset-backed debt securities under fixed-term securitization programs to private investors. As of May 5, 2017 and February 3, 2017, the associated debt balance of these securities was $2.1 billion and $1.4 billion, respectively. The asset-backed debt securities are collateralized solely by the U.S. fixed-term financing receivables in the offerings, which are held by SPEs, as discussed below. The interest rate on these securities is fixed and ranges from 0.42% to 3.61%, and the duration of these securities is based on the terms of the underlying financing receivables. |

[0001571996-17-000009:notes:205]
| • | Other Structured Financing Programs — In connection with the Company's international financing operations, the Company has entered into revolving structured financing debt programs related to its fixed-term lease and loan products sold in Canada and Europe. The aggregate outstanding balances of the Canadian and European revolving structured loans as of May 5, 2017 and February 3, 2017 were $387 million and $382 million, respectively. As of May 5, 2017, the Canadian program, which was extended during the fiscal year ended May 5, 2017, had a total debt capacity of $160 million. This program is effective for two years, beginning on April 15, 2016, and is collateralized solely by the Canadian financing receivables. The European program, which was extended during the first quarter of Fiscal 2016, is now effective for four years, beginning on December 23, 2013. The program is collateralized solely by the European financing receivables and had a total debt capacity of $330 million as of May 5, 2017. |

[0001571996-17-000009:notes:206]
Variable Interest Entities

[0001571996-17-000009:notes:207]
In connection with the securitization programs discussed above, the Company transfers certain U.S. and European customer financing receivables to Special Purpose Entities ("SPEs") that meet the definition of a Variable Interest Entity ("VIE") and are consolidated, along with the associated debt, into the Condensed Consolidated Financial Statements, as the Company is the primary beneficiary of those VIEs.  These SPEs are bankruptcy-remote legal entities with separate assets and liabilities.  The purpose of these SPEs is to facilitate the funding of customer receivables in the capital markets.

[0001571996-17-000009:notes:208]
The following table shows financing receivables held by the consolidated VIEs as of the respective dates:

[0001571996-17-000009:notes:209]
|  | May 5, 2017 |  | February 3, 2017 |
|  | (in millions) |
| Financing receivables held by consolidated VIEs, net: |  |  |  |  |  |
| Short-term, net | $ | 2,348 |  |  | $ | 2,227 |  |
| Long-term, net | 1,636 |  |  | 1,381 |  |
| Financing receivables held by consolidated VIEs, net | $ | 3,984 |  |  | $ | 3,608 |  |

[0001571996-17-000009:notes:210]
Financing receivables transferred via securitization through SPEs were $0.9 billion and $0.6 billion for the three months ended May 5, 2017 and April 29, 2016, respectively.

[0001571996-17-000009:notes:211]
Some of the SPEs have entered into financing arrangements with multi-seller conduits that, in turn, issue asset-backed debt securities in the capital markets.  The structured financing debt outstanding, which is collateralized by the financing receivables held by the consolidated VIEs, was $3.5 billion and $3.1 billion as of May 5, 2017 and February 3, 2017, respectively.  The Company's risk of loss related to securitized receivables is limited to the amount by which the Company's right to receive collections for assets securitized exceeds the amount required to pay interest, principal, and fees and expenses related to the asset-backed securities.  The Company provides credit enhancement to the securitization in the form of over-collateralization.

[0001571996-17-000009:notes:212]
Financing Receivable Sales

[0001571996-17-000009:notes:213]
To manage certain concentrations of customer credit exposure, the Company may sell selected fixed-term financing receivables to unrelated third parties on a periodic basis.  The amount of financing receivables sold was $55 million and $80 million for the three months ended May 5, 2017 and April 29, 2016, respectively.


## us-gaap:MinorityInterestDisclosureTextBlock

[0001571996-17-000009:notes:214]
[same as prior period, unchanged from 0001571996-16-000021:notes:329]

[0001571996-17-000009:notes:215]
VMware, Inc. — The non-controlling interests' share of equity in VMware, Inc. is reflected as a component of the non-controlling interests in the accompanying Condensed Consolidated Statements of Financial Position and was $5.3 billion and $5.2 billion as of May 5, 2017 and February 3, 2017, respectively.  As of May 5, 2017 and February 3, 2017, the Company held approximately 81.8% and 82.5%, respectively, of the outstanding equity interest in VMware, Inc.

[0001571996-17-000009:notes:216]
SecureWorks — On April 27, 2016, SecureWorks completed a registered underwritten IPO of its Class A common stock.  The non-controlling interests' share of equity in SecureWorks is reflected as a component of the non-controlling interests in the accompanying Condensed Consolidated Statements of Financial Position and was $88 million  and $86 million as of May 5, 2017 and February 3, 2017, respectively.  As of May 5, 2017 and February 3, 2017, Dell Technologies held approximately 87.1% and 87.5%, respectively, of the outstanding equity interest in SecureWorks.

[0001571996-17-000009:notes:217]
Pivotal — A portion of the non-controlling interests in Pivotal is held by third parties in the form of preferred equity instruments.  Due to the terms of such instruments, Pivotal's results of operations and equity activity are not attributable to such interests in Pivotal in the Condensed Consolidated Statements of Income (Loss) and Condensed Consolidated Statements of Financial Position.  The preferred equity instruments are convertible into common shares at the non-controlling owner's election at any time.  The remaining portion of the non-controlling interests in Pivotal is held by third parties in the form of common stock.  Pivotal's results of operations and equity activity are attributable to such interests in Pivotal in the Condensed Consolidated Statements of Income (Loss) and Condensed Consolidated Statements of Financial Position.  The non-controlling interests' share of equity in Pivotal, including both preferred equity instruments and common stock, is reflected as a component of the non-controlling interests in the accompanying Condensed Consolidated Statements of Financial Position and was $473 million and $472 million as of May 5, 2017 and February 3, 2017, respectively.  As of May 5, 2017 and February 3, 2017, the Company held approximately 77.6% and 77.8%, respectively, of the outstanding equity interest in Pivotal.


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001571996-17-000009:notes:218]
WARRANTY LIABILITY

[0001571996-17-000009:notes:219]
The Company records a liability for its standard limited warranties at the time of sale for the estimated costs that may be incurred.  The liability for standard warranties is included in accrued and other current liabilities and other non-current liabilities in the Condensed Consolidated Statements of Financial Position.

[0001571996-17-000009:notes:220]
Changes in the Company's liability for standard limited warranties are presented in the following table for the periods indicated.

[0001571996-17-000009:notes:221]
|  | Three Months Ended |
|  | May 5, 2017 |  | April 29, 2016 |
|  | (in millions) |
| Warranty liability: |  |  |  |
| Warranty liability at beginning of period | $ | 604 |  |  | $ | 574 |  |
| Costs accrued for new warranty contracts and changes in estimates for pre-existing warranties (a) (b) | 240 |  |  | 200 |  |
| Service obligations honored | (237 | ) |  | (213 | ) |
| Warranty liability at end of period | $ | 607 |  |  | $ | 561 |  |
| Current portion | $ | 420 |  |  | $ | 383 |  |
| Non-current portion | $ | 187 |  |  | $ | 178 |  |

[0001571996-17-000009:notes:222]
| (a) | Changes in cost estimates related to pre-existing warranties are aggregated with accruals for new standard warranty contracts. The Company's warranty liability process does not differentiate between estimates made for pre-existing warranties and new warranty obligations. |

[0001571996-17-000009:notes:223]
| (b) | Includes the impact of foreign currency exchange rate fluctuations. |


## us-gaap:ReconciliationOfRevenueFromSegmentsToConsolidatedTextBlock

[0001571996-17-000009:notes:224]
The following table presents a reconciliation of net revenue by the Company's reportable segments to the Company's consolidated net revenue as well as a reconciliation of consolidated segment operating income to the Company's consolidated operating loss:

[0001571996-17-000009:notes:225]
|  | Three Months Ended |
|  | May 5, 2017 |  | April 29, 2016 |
|  | (in millions) |
| Consolidated net revenue: |  |  |  |  |
| Client Solutions Group | $ | 9,056 |  |  | $ | 8,571 |  |
| Infrastructure Solutions Group | 6,916 |  |  | 3,613 |  |
| VMware | 1,736 |  |  | — |  |
| Reportable segment net revenue | 17,708 |  |  | 12,184 |  |
| Other businesses (a) | 462 |  |  | 110 |  |
| Unallocated transactions (b) | 1 |  |  | 25 |  |
| Impact of purchase accounting (c) | (355 | ) |  | (78 | ) |
| Total net revenue | $ | 17,816 |  |  | $ | 12,241 |  |
| Consolidated operating income (loss): |  |  |  |
| Client Solutions Group | $ | 374 |  |  | $ | 385 |  |
| Infrastructure Solutions Group | 323 |  |  | 192 |  |
| VMware | 486 |  |  | — |  |
| Reportable segment operating income | 1,183 |  |  | 577 |  |
| Other businesses (a) | 3 |  |  | (16 | ) |
| Unallocated transactions (b) | 11 |  |  | (22 | ) |
| Impact of purchase accounting (c) | (423 | ) |  | (106 | ) |
| Amortization of intangibles | (1,776 | ) |  | (491 | ) |
| Transaction-related expenses (d) | (191 | ) |  | (57 | ) |
| Other corporate expenses (e) | (307 | ) |  | (24 | ) |
| Total operating loss | $ | (1,500 | ) |  | $ | (139 | ) |

[0001571996-17-000009:notes:226]
_________________

[0001571996-17-000009:notes:227]
| (a) | Other businesses consist of RSA Information Security, SecureWorks, Pivotal, and Boomi offerings, and do not constitute a reportable segment, either individually or collectively, as the results of the businesses are not material to the Company's overall results and the businesses do not meet the criteria for reportable segments. |

[0001571996-17-000009:notes:228]
[same as prior period, unchanged from 0001571996-16-000021:notes:349]

[0001571996-17-000009:notes:229]
| (c) | Impact of purchase accounting includes non-cash purchase accounting adjustments that are primarily related to the EMC merger transaction. |

[0001571996-17-000009:notes:230]
| (d) | Transaction-related expenses includes acquisition, integration, and divestiture related costs. |

[0001571996-17-000009:notes:231]
[same as prior period, unchanged from 0001571996-16-000021:notes:352]


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001571996-17-000009:notes:232]
SEVERANCE CHARGES

[0001571996-17-000009:notes:233]
In connection with the transformation of the Company's business model, the Company incurs costs related to employee severance.  The Company records a liability for these costs when it is probable that employees will be entitled to termination benefits and the amounts can be reasonably estimated.  The liability related to these actions is included in accrued and other current liabilities in the Condensed Consolidated Statements of Financial Position and was $257 million and $416 million as of May 5, 2017 and February 3, 2017, respectively.

[0001571996-17-000009:notes:234]
The following table sets forth the activity related to the Company's severance liability for the respective periods:

[0001571996-17-000009:notes:235]
|  | Three Months Ended |
|  | May 5, 2017 |  | April 29, 2016 |
|  | (in millions) |
| Balance at beginning of period | $ | 416 |  |  | $ | 26 |  |
| Severance charges to provision | 30 |  |  | 17 |  |
| Cash paid and other | (189 | ) |  | (14 | ) |
| Balance at end of period | $ | 257 |  |  | $ | 29 |  |

[0001571996-17-000009:notes:236]
Severance costs are included in cost of net revenue, selling, general, and administrative expenses, and research and development expense in the Condensed Consolidated Statements of Income (Loss) as follows:

[0001571996-17-000009:notes:237]
|  | Three Months Ended |
|  | May 5, 2017 |  | April 29, 2016 |
|  | (in millions) |
| Severance charges: |  |  |  |
| Cost of net revenue | $ | 5 |  |  | $ | 4 |  |
| Selling, general, and administrative | 7 |  |  | 7 |  |
| Research and development | 18 |  |  | 6 |  |
| Total | $ | 30 |  |  | $ | 17 |  |


## us-gaap:ScheduleOfAmountsRecognizedInBalanceSheetTableTextBlock

[0001571996-17-000009:notes:238]
The following table provides additional information on selected accounts included in the Condensed Consolidated Statements of Financial Position as of May 5, 2017 and February 3, 2017:

[0001571996-17-000009:notes:239]
|  | May 5, 2017 |  | February 3, 2017 |
|  | (in millions) |
| Inventories, net: |  |  |  |
| Production materials | $ | 872 |  |  | $ | 925 |  |
| Work-in-process | 506 |  |  | 503 |  |
| Finished goods | 1,088 |  |  | 1,110 |  |
| Total inventories, net | 2,466 |  |  | 2,538 |  |
| Other non-current liabilities: |  |  |  |
| Warranty liability | 187 |  |  | 199 |  |
| Deferred and other tax liabilities | 7,726 |  |  | 8,607 |  |
| Other | 522 |  |  | 533 |  |
| Total other non-current liabilities | $ | 8,435 |  |  | $ | 9,339 |  |


## us-gaap:ScheduleOfDisposalGroupsIncludingDiscontinuedOperationsIncomeStatementBalanceSheetAndAdditionalDisclosuresTextBlock

[0001571996-17-000009:notes:240]
The following table presents key financial results of Dell Services and DSG included in "Income from discontinued operations, net of income taxes (Note 3)" for the three months ended April 29, 2016:

[0001571996-17-000009:notes:241]
The significant cash flow items from Dell Services and DSG for the three months ended April 29, 2016 were as follows:


## us-gaap:ScheduleOfRevenuesFromExternalCustomersAndLongLivedAssetsByGeographicalAreasTableTextBlock

[0001571996-17-000009:notes:242]
The following table presents net revenue by business unit categories:

[0001571996-17-000009:notes:243]
|  | Three Months Ended |
|  | May 5, 2017 |  | April 29, 2016 |
|  | (in millions) |
| Net revenue: |  |  |  |  |  |
| Client Solutions Group: |  |  |  |
| Commercial | $ | 6,350 |  |  | $ | 6,145 |  |
| Consumer | 2,706 |  |  | 2,426 |  |
| Total CSG net revenue | 9,056 |  |  | 8,571 |  |
| Infrastructure Solutions Group: |  |  |  |
| Servers and networking | 3,231 |  |  | 3,075 |  |
| Storage | 3,685 |  |  | 538 |  |
| Total ISG net revenue | 6,916 |  |  | 3,613 |  |
| VMware |  |  |  |
| Total VMware net revenue | 1,736 |  |  | — |  |
| Total segment net revenue | $ | 17,708 |  |  | $ | 12,184 |  |


## us-gaap:ScheduleOfStockByClassTextBlock

[0001571996-17-000009:notes:244]
The following table summarizes the Company's authorized, issued, and outstanding common stock as of the dates indicated:

[0001571996-17-000009:notes:245]
|  | Authorized |  | Issued |  | Outstanding |
|  | (in millions of shares) |
| Common stock as of February 3, 2017 |
| Class A | 600 |  |  | 410 |  |  | 410 |  |
| Class B | 200 |  |  | 137 |  |  | 137 |  |
| Class C | 900 |  |  | 22 |  |  | 22 |  |
| Class D | 100 |  |  | — |  |  | — |  |
| Class V | 343 |  |  | 223 |  |  | 209 |  |
|  | 2,143 |  |  | 792 |  |  | 778 |  |
| Common stock as of May 5, 2017 |
| Class A | 600 |  |  | 410 |  |  | 410 |  |
| Class B | 200 |  |  | 137 |  |  | 137 |  |
| Class C | 900 |  |  | 22 |  |  | 22 |  |
| Class D | 100 |  |  | — |  |  | — |  |
| Class V | 343 |  |  | 223 |  |  | 203 |  |
|  | 2,143 |  |  | 792 |  |  | 772 |  |

[0001571996-17-000009:notes:246]
The following table presents the repurchase activity with respect to the Class V Common Stock for the three months ended May 5, 2017, and the attribution of the Class V Group between the Class V Common Stock and the DHI Group's retained interest as of the dates indicated:

[0001571996-17-000009:notes:247]
|  | Class V Common Stock |  | DHI Group Retained Interest |
|  | Shares of Class V Common Stock |  | Interest in Class V Group |  | Retained Interest Shares |  | Interest in Class V Group |
|  | (in millions of shares) |
| As of February 3, 2017 | 209 |  |  | 62 | % |  | 127 |  |  | 38 | % |
| Repurchases of Class V Common Stock | (6 | ) |  |  |  | — |  |  |  |
| As of May 5, 2017 | 203 |  |  | 62 | % |  | 127 |  |  | 38 | % |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001571996-17-000009:notes:248]
[same as prior period, unchanged from 0001571996-16-000021:notes:382]

[0001571996-17-000009:notes:249]
The Company has three reportable segments that are based on the following business units: Client Solutions Group ("CSG"); Infrastructure Solutions Group ("ISG"); and VMware.

[0001571996-17-000009:notes:250]
CSG includes sales to commercial and consumer customers of desktops, thin client products, and notebooks, as well as services and third-party software and peripherals closely tied to the sale of CSG hardware.  ISG includes servers, networking, and storage, as well as services and third-party software and peripherals that are closely tied to the sale of ISG hardware.  VMware includes a broad portfolio of virtualization technologies across three main product groups: software-defined data center; hybrid cloud computing; and end-user computing.

[0001571996-17-000009:notes:251]
[same as prior period, unchanged from 0001571996-16-000021:notes:385]


## us-gaap:ShareholdersEquityAndShareBasedPaymentsTextBlock

[0001571996-17-000009:notes:252]
[same as prior period, unchanged from 0001571996-16-000021:notes:386]

[0001571996-17-000009:notes:253]
Awards under the Company's stock incentive plans include certain rights that allow the holder to exercise a put feature for the underlying Class A or Class C Common Stock after a six-month holding period following the issuance of such common stock that requires the Company to purchase the stock at its fair market value.  Accordingly, these awards and common stock are subject to reclassification from equity to temporary equity, and the Company determines the award amounts to be classified as temporary equity as follows:

[0001571996-17-000009:notes:254]
| • | For stock options to purchase Class C Common Stock subject to service requirements, the intrinsic value of the option is multiplied by the portion of the option for which services have been rendered. Upon exercise of the option, the amount in temporary equity represents the fair value of the Class C Common Stock. |

[0001571996-17-000009:notes:255]
| • | For stock appreciation rights, restricted stock units ("RSUs"), or shares of restricted common stock ("RSAs"), any of which stock award types are subject to service requirements, the fair value of the share is multiplied by the portion of the shares for which services have been rendered. |

[0001571996-17-000009:notes:256]
| • | For share-based arrangements that are subject to the occurrence of a contingent event, those amounts are not reclassified to temporary equity until the contingency has been satisfied. |

[0001571996-17-000009:notes:257]
The amount of redeemable shares classified as temporary equity as of May 5, 2017 and February 3, 2017 was $301 million and $231 million, respectively.  As of May 5, 2017, the redeemable shares consisted of 1.3 million issued and outstanding unrestricted common shares, 0.6 million RSUs, 0.2 million RSAs, and 15.6 million outstanding stock options.  As of February 3, 2017, the redeemable shares consisted of 1.1 million issued and outstanding unrestricted common shares, 0.4 million RSUs, 0.1 million RSAs, and 13.7 million outstanding stock options.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001571996-17-000009:notes:258]
CAPITALIZATION

[0001571996-17-000009:notes:259]
Preferred Stock — The Company is authorized to issue one million shares of preferred stock, par value $.01 per share.  As of May 5, 2017, no shares of preferred stock were issued or outstanding.

[0001571996-17-000009:notes:260]
Class V Common Stock and Class V Group — In connection with the EMC merger transaction, the Company authorized 343 million shares of Class V Common Stock.  The Class V Common Stock is a type of common stock commonly referred to as a tracking stock, which is a class of common stock that is intended to track the economic performance of a defined set of assets and liabilities.  As of May 5, 2017, the 203 million shares of outstanding Class V Common Stock were intended to track the economic performance of approximately 62% of Dell Technologies' economic interest in the Class V Group.  The Class V Group as of such date consisted solely of approximately 334 million shares of VMware, Inc. common stock held by the Company.  The remaining 38% economic interest in the Class V Group as of May 5, 2017 was represented by the approximately 127 million retained interest shares held by the DHI Group.  The DHI Group generally refers, in addition to such retained interest, to the direct and indirect interest of Dell Technologies in all of Dell Technologies' business, assets, properties, liabilities, and preferred stock other than those attributable to the Class V Group.

[0001571996-17-000009:notes:261]
Repurchases of Common Stock; Treasury Stock

[0001571996-17-000009:notes:262]
Class V Common Stock Repurchases — On December 13, 2016, the board of directors approved a stock repurchase program (the "Class V Group Repurchase Program") under which the Company is authorized to use assets of the Class V Group to repurchase up to $500 million of shares of Class V Common Stock over a period of six months.  During the three months ended May 5, 2017, the Company repurchased 1.3 million shares of Class V Common Stock for $82 million.  On February 13, 2017, the Class V Group Repurchase Program was completed.

[0001571996-17-000009:notes:263]
On March 27, 2017, the board of directors approved an amendment of the Class V Group Repurchase Program (the "Extended Class V Group Repurchase Program") which authorizes the Company to use assets of the Class V Group to repurchase up to an additional $300 million of shares of Class V Common Stock over a period of an additional six months.  During the three months ended May 5, 2017, the Company repurchased 4.2 million shares of Class V Common Stock for $277 million under this program.  As of May 5, 2017, the Company's remaining authorized amount for share repurchases was $23 million.  On May 9, 2017, subsequent to the close of the Company's fiscal quarter, the Extended Class V Group Repurchase Program was completed.

[0001571996-17-000009:notes:264]
All shares of Class V Common Stock repurchased by the Company pursuant to the repurchase programs are held as treasury stock at cost.  The repurchase of shares pursuant to the Class V Common Stock repurchase programs was funded from proceeds received by the Class V Group from the sale by a subsidiary of the Company of shares of Class A common stock of VMware, Inc. owned by such subsidiary, as described below under "VMware, Inc. Class A Common Stock Repurchases."  Share repurchases made by VMware, Inc. of its Class A common stock from a subsidiary of the Company do not affect the determination of the respective interests of the Class V Common Stock and the DHI Group in the Class V Group.  See Exhibit 99.1 to the Company's quarterly report on Form 10-Q for the quarterly period ended May 5, 2017 for more information regarding Unaudited Attributed Financial Information for the Class V Group.

[0001571996-17-000009:notes:265]
VMware, Inc. Class A Common Stock Repurchases — On December 15, 2016, the Company entered into a stock purchase agreement with VMware, Inc. (the "December 2016 Stock Purchase Agreement"), pursuant to which VMware, Inc. agreed to repurchase for cash $500 million of shares of VMware, Inc. Class A common stock from a subsidiary of the Company.  During the three months ended May 5, 2017, VMware, Inc. repurchased 1.4 million shares.  On February 15, 2017, the sale transaction under the December 2016 Stock Purchase Agreement was completed.  VMware, Inc. repurchased a total of 6.2 million shares under this agreement.  The Company applied the proceeds from the sale to the repurchase of shares of its Class V Common Stock under the Class V Group Repurchase Program described above.  All shares repurchased under VMware, Inc.'s stock repurchase programs are retired.

[0001571996-17-000009:notes:266]
In January 2017, VMware, Inc.'s board of directors authorized the repurchase of up to an additional $1.2 billion of shares of VMware, Inc. Class A common stock (the "January 2017 Authorization") through the end of Fiscal 2018.  On March 29, 2017, the Company entered into a new stock purchase agreement with VMware, Inc. (the "March 2017 Stock Purchase Agreement"), pursuant to which VMware, Inc. repurchased for cash $300 million of shares of VMware, Inc. Class A common stock from a subsidiary of the Company.  The proceeds from the sale were applied by the Company to the repurchase of shares of the Class V Common Stock under the Extended Class V Group Repurchase Program described above.

[0001571996-17-000009:notes:267]
During the three months ended May 5, 2017, VMware, Inc. received an initial delivery of approximately 2.7 million shares of Class A common stock with a value of $240 million for $300 million in cash.  On May 10, 2017, subsequent to the close of the Company's fiscal quarter, the sale transaction under the March 2017 Stock Purchase Agreement was completed, and VMware, Inc. received an additional 0.7 million shares.  The total of 3.4 million shares repurchased by VMware, Inc. under the March 2017 Stock Purchase Agreement was based on the volume-weighted average per share price of the Class A common stock as reported on the New York Stock Exchange during a specified reference period, less a discount of 3.5% from that volume-weighted average per share price.  This repurchase was pursuant to the January 2017 Authorization.  As of May 5, 2017, the cumulative authorized amount remaining for share repurchases by VMware, Inc. under the January 2017 Authorization was $900 million.


## us-gaap:SubsequentEventsTextBlock

[0001571996-17-000009:notes:268]
SUBSEQUENT EVENTS

[0001571996-17-000009:notes:269]
Federal Income Taxes — In May 2017, the IRS commenced a federal income tax audit for fiscal years 2010 through 2014, which could take several years to complete.  Dell believes that adequate reserves have been provided related to all matters contained in tax periods open to examination.  For further discussion regarding tax matters, including the status of income tax audits, see Note 13 of the Notes to the Condensed Consolidated Financial Statements.

[0001571996-17-000009:notes:270]
Other than the matters identified above, there were no known events occurring after the balance sheet date and up until the date of the issuance of this report that would materially affect the information presented herein.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001571996-17-000009:notes:271]
[same as prior period, unchanged from 0001571996-16-000021:notes:420]
