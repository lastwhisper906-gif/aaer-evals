# DELL MD&A — 0001571996-22-000031


## mdna

[0001571996-22-000031:mdna:1]
[same as prior period, unchanged from 0001571996-22-000021:mdna:1]

[0001571996-22-000031:mdna:2]
[same as prior period, unchanged from 0001571996-22-000021:mdna:2]

[0001571996-22-000031:mdna:3]
[same as prior period, unchanged from 0001571996-22-000021:mdna:3]

[0001571996-22-000031:mdna:4]
On November 1, 2021, the Company completed its spin-off of VMware, Inc. (“VMware”).  In accordance with applicable accounting guidance, the results of VMware, excluding Dell's resale of VMware offerings, are presented as discontinued operations in the Condensed Consolidated Statements of Income and, as such, have been excluded from both continuing operations and segment results for the three and six months ended July 30, 2021.  The Condensed Consolidated Statements of Cash Flows are presented on a consolidated basis for both continuing operations and discontinued operations.

[0001571996-22-000031:mdna:5]
Our fiscal year is the 52- or 53-week period ending on the Friday nearest January 31.  We refer to our fiscal year ending February 3, 2023 as “Fiscal 2023” and our fiscal year ended January 28, 2022 as “Fiscal 2022.”  Fiscal 2023 will include 53 weeks and Fiscal 2022 included 52 weeks.

[0001571996-22-000031:mdna:6]
[same as prior period, unchanged from 0001571996-22-000021:mdna:6]

[0001571996-22-000031:mdna:7]
[same as prior period, unchanged from 0001571996-22-000021:mdna:7]

[0001571996-22-000031:mdna:8]
[same as prior period, unchanged from 0001571996-22-000021:mdna:8]

[0001571996-22-000031:mdna:9]
[same as prior period, unchanged from 0001571996-22-000021:mdna:9]

[0001571996-22-000031:mdna:10]
Dell Technologies’ end-to-end portfolio is supported by a world-class organization that operates globally in approximately 180 countries across key functional areas, including technology and product development, marketing, sales, financial services, and services.  Our go-to-market engine includes a 32,000-person sales force and a global network of over 200,000 channel partners.  Dell Financial Services and its affiliates (“DFS”) offer customers payment flexibility and enable synergies across the business.  We employ approximately 35,000 full-time service and support professionals and maintain more than 2,400 vendor-managed service centers.  We manage a world-class supply chain that drives long-term growth and operating efficiencies, with approximately $75 billion in annual procurement expenditures and over 750 parts distribution centers.  Together, these durable competitive advantages provide a critical foundation for our success.

[0001571996-22-000031:mdna:11]
[same as prior period, unchanged from 0001571996-22-000021:mdna:11]

[0001571996-22-000031:mdna:12]
[same as prior period, unchanged from 0001571996-22-000021:mdna:12]

[0001571996-22-000031:mdna:13]
[same as prior period, unchanged from 0001571996-22-000021:mdna:13]

[0001571996-22-000031:mdna:14]
[same as prior period, unchanged from 0001571996-22-000021:mdna:14]

[0001571996-22-000031:mdna:15]
[same as prior period, unchanged from 0001571996-22-000021:mdna:15]

[0001571996-22-000031:mdna:16]
[same as prior period, unchanged from 0001571996-22-000021:mdna:16]

[0001571996-22-000031:mdna:17]
[same as prior period, unchanged from 0001571996-22-000021:mdna:17]

[0001571996-22-000031:mdna:18]
[same as prior period, unchanged from 0001571996-22-000021:mdna:18]

[0001571996-22-000031:mdna:19]
•Infrastructure Solutions Group (“ISG”) — ISG enables our customers’ digital transformation through our trusted multi-cloud, machine learning, artificial intelligence, and data analytics solutions which are built upon modern data center infrastructure.  ISG helps customers in the area of hybrid cloud deployment with the goal of simplifying, streamlining, and automating cloud operations.  ISG solutions are built for multi-cloud environments and are optimized to run cloud native workloads in both public and private clouds, as well as traditional on-premise workloads.

[0001571996-22-000031:mdna:20]
Our comprehensive portfolio of advanced storage solutions includes traditional storage solutions as well as next-generation storage solutions (such as all-flash arrays, scale-out file, object platforms, and software-defined solutions).   Our PowerStore offering, a differentiated midrange storage solution that enables seamless updates using microservices and container-based software architecture, allows us to compete more effectively within midrange storage.  We continue to make enhancements to our storage solutions offerings and expect that these offerings will drive long-term improvements in the business.

[0001571996-22-000031:mdna:21]
[same as prior period, unchanged from 0001571996-22-000021:mdna:21]

[0001571996-22-000031:mdna:22]
[same as prior period, unchanged from 0001571996-22-000021:mdna:22]

[0001571996-22-000031:mdna:23]
[same as prior period, unchanged from 0001571996-22-000021:mdna:23]

[0001571996-22-000031:mdna:24]
[same as prior period, unchanged from 0001571996-22-000021:mdna:67]

[0001571996-22-000031:mdna:25]
•Client Solutions Group (“CSG”) — CSG includes branded hardware (such as desktops, workstations, and notebooks) and branded peripherals (such as displays, docking stations, and other electronics), as well as third-party software and peripherals.  CSG also includes services offerings, including support and deployment, configuration, and extended warranty services.  Our computing devices are designed with our commercial and consumer customers’ needs in mind, and we seek to optimize performance, reliability, manageability, design, and security.  For our customers that are seeking to simplify client lifecycle management, Dell PC as-a-Service offering combines hardware, software, lifecycle services, and financing into one all-encompassing solution that provides predictable pricing per seat per month.

[0001571996-22-000031:mdna:26]
[same as prior period, unchanged from 0001571996-22-000021:mdna:26]

[0001571996-22-000031:mdna:27]
Our other businesses, described below, consist of our resale of standalone VMware offerings, referred to as VMware Resale, as well as product and service offerings of SecureWorks Corp. (“Secureworks”) and Virtustream.  These businesses are not classified as reportable segments, either individually or collectively.

[0001571996-22-000031:mdna:28]
•VMware Resale consists of our sale of standalone VMware offerings.  Under the Commercial Framework Agreement discussed below entered into as part of our spin-off of VMware, Dell Technologies continues to act as a key channel partner in this relationship, reselling VMware offerings to our customers.  This partnership is intended to facilitate mutually beneficial growth for both Dell and VMware.

[0001571996-22-000031:mdna:29]
[same as prior period, unchanged from 0001571996-22-000021:mdna:29]

[0001571996-22-000031:mdna:30]
[same as prior period, unchanged from 0001571996-22-000021:mdna:30]

[0001571996-22-000031:mdna:31]
[same as prior period, unchanged from 0001571996-22-000021:mdna:31]

[0001571996-22-000031:mdna:32]
We believe the collaboration, innovation, and coordination of the operations and strategies across the segments of our business, as well as our differentiated go-to-market model, will continue to drive revenue synergies.  Through our research and development activities, we are able to engineer leading innovative solutions that incorporate the distinct set of hardware, software, and services across all segments of our business.

[0001571996-22-000031:mdna:33]
[same as prior period, unchanged from 0001571996-22-000021:mdna:33]

[0001571996-22-000031:mdna:34]
[same as prior period, unchanged from 0001571996-22-000021:mdna:34]

[0001571996-22-000031:mdna:35]
DFS supports our businesses by offering and arranging various financing options and services for our customers globally.  DFS originates, collects, and services customer receivables primarily related to the purchase or use of our product, software, and services solutions.  We also arrange financing for some of our customers in various countries where DFS does not currently operate as a captive entity.  DFS further strengthens our customer relationships through its flexible consumption models which provide our customers with financial flexibility to meet their changing technological requirements.  Our flexible consumption models enable us to offer our customers the option to pay over time and, in certain cases, based on utilization.  The results of these operations are allocated to our segments based on the underlying product or service financed and may be impacted by, among other items, changes in the interest rate environment and the translation of those changes in to pricing.  For additional information about our financing arrangements, see Note 5 of the Notes to the Condensed Consolidated Financial Statements included in this report.

[0001571996-22-000031:mdna:36]
60

[0001571996-22-000031:mdna:37]
[same as prior period, unchanged from 0001571996-22-000021:mdna:36]

[0001571996-22-000031:mdna:38]
Spin-Off of VMware, Inc. —  On November 1, 2021, we completed our spin-off of VMware by means of a special stock dividend (the “VMware Spin-off”).  The VMware Spin-off was effectuated pursuant to a Separation and Distribution Agreement, dated as of April 14, 2021, between Dell Technologies and VMware.  As part of the transaction, VMware paid a special cash dividend, pro rata, to each holder of VMware common stock in an aggregate amount equal to $11.5 billion, of which Dell Technologies received $9.3 billion.

[0001571996-22-000031:mdna:39]
[same as prior period, unchanged from 0001571996-22-000021:mdna:38]

[0001571996-22-000031:mdna:40]
The results of VMware, excluding Dell's resale of VMware offerings, are presented as discontinued operations in the Condensed Consolidated Statements of Income and, as such, have been excluded from both continuing operations and segment results for the three and six months ended July 30, 2021.  The Condensed Consolidated Statements of Cash Flows are presented on a consolidated basis for both continuing operations and discontinued operations.  See Note 2 of the Notes to the Condensed Consolidated Financial Statements included in this report for additional information about the VMware Spin-off.

[0001571996-22-000031:mdna:41]
[same as prior period, unchanged from 0001571996-22-000021:mdna:40]

[0001571996-22-000031:mdna:42]
[same as prior period, unchanged from 0001571996-22-000021:mdna:41]

[0001571996-22-000031:mdna:43]
The Company is considered to be a related party of VMware as a result of Michael Dell’s ownership interest in both Dell Technologies and VMware and Mr. Dell’s continued service as Chairman and Chief Executive Officer of Dell Technologies and as Chairman of the Board of VMware, Inc.  Following the completion of the VMware Spin-off, the majority of transactions that occur between Dell Technologies and VMware consist of Dell Technologies’ purchase of VMware products and services for resale, either on a standalone basis or as a part of integrated offerings.  For more information regarding related party transactions with VMware, see Note 16 of the Notes to the Condensed Consolidated Financial Statements included in this report.

[0001571996-22-000031:mdna:44]
[same as prior period, unchanged from 0001571996-22-000021:mdna:43]

[0001571996-22-000031:mdna:45]
As part of our strategy, we will continue to evaluate opportunities for strategic investments through our venture capital investment arm, Dell Technologies Capital, with a focus on emerging technology areas that are relevant to all segments of our business and that will complement our existing portfolio of solutions.  Our investment areas include storage, software-defined networking, management and orchestration, security, machine learning and artificial intelligence, Big Data and analytics, cloud, edge computing, and software development operations.  The technologies or products these companies have under development are typically in the early stages and may never have commercial value, which could result in a loss of a substantial part of our initial investment in the companies.

[0001571996-22-000031:mdna:46]
During the second quarter of Fiscal 2023, we recognized a net loss of $255 million on our strategic investments generally in line with overall public equity market declines.  As of July 29, 2022 and January 28, 2022, we held strategic investments in non-marketable securities of $1.3 billion and $1.4 billion, respectively.  See Note 4 of the Notes to the Condensed Consolidated Financial Statements included in this report for additional information.

[0001571996-22-000031:mdna:47]
[same as prior period, unchanged from 0001571996-22-000021:mdna:45]

[0001571996-22-000031:mdna:48]
[same as prior period, unchanged from 0001571996-22-000021:mdna:47]

[0001571996-22-000031:mdna:49]
Macroeconomic conditions continue to evolve globally and, during the second quarter of Fiscal 2023, while net revenue grew, we experienced a notable change in the demand for both our ISG and CSG offerings.  Demand for our CSG offerings decreased in line with industry-wide declines while demand for our ISG offerings moderated as a result of customer uncertainty in response to the macroeconomic environment.  Although we expect ISG net revenue growth to continue through the remainder of Fiscal 2023, we anticipate that the rate of growth will moderate.  Within CSG, we expect that demand for our offerings will continue to decline, which we anticipate will result in a decrease in CSG net revenue through the remainder of Fiscal 2023.  We will continue to actively monitor global events and make prudent decisions to navigate this environment.  We believe our durable competitive advantages continue to position us for long-term success.

[0001571996-22-000031:mdna:50]
Supply Chain — Dell Technologies maintains limited-source supplier relationships for certain components because the relationships are advantageous in the areas of performance, quality, support, delivery, capacity, and price considerations. During the second quarter and first six months of Fiscal 2023, we continued to be impacted by industry-wide constraints in the supply of limited-source components in certain product offerings, principally within ISG, as a result of the global impacts of COVID-19.  Demand for certain product components within ISG continues to outpace supply, resulting in an increase in orders pending fulfillment and extended lead times for our customers.  While we expect to continue to manage these supply constraints for the remainder of Fiscal 2023, we anticipate that they may moderate dependent on the overall demand environment.

[0001571996-22-000031:mdna:51]
Supply chain dynamics also continue to impact logistics and component costs, which we refer to as input costs.  Logistics costs remained elevated for the second quarter and first six months of Fiscal 2023 as a result of both expedited shipments of components and overall rate costs in the freight network, as capacity remains constrained.  While we expect overall logistics costs to remain elevated for the remainder of Fiscal 2023, we anticipate these costs will begin to decline in the third quarter of Fiscal 2023.  Component costs were deflationary during the second quarter and first six months of Fiscal 2023, and we expect such costs will remain moderately deflationary into the third quarter of Fiscal 2023.  Component cost trends are dependent on the strength or weakness of actual end-user demand and supply dynamics, which will continue to evolve and ultimately impact the translation of the cost environment to pricing and operating results.

[0001571996-22-000031:mdna:52]
In response to these pressures, we continue to take steps to actively address our customers’ demands while balancing profitability and growth.

[0001571996-22-000031:mdna:53]
Foreign Currency Exposure — We manage our business on a U.S. dollar basis.  However, we have a large global presence, generating approximately half of our net revenue from sales to customers outside of the United States during the second quarter and first six months of Fiscal 2023 and Fiscal 2022.  As a result, our operating results can be, and particularly in recent periods have been, impacted by fluctuations in foreign currency exchange rates.  We utilize a comprehensive hedging strategy intended to mitigate the impact of foreign currency volatility over time, and we adjust pricing when possible to further minimize foreign currency impacts.

[0001571996-22-000031:mdna:54]
Ukraine War — We are monitoring and responding to effects of the ongoing war in Ukraine.  When Russia invaded Ukraine, we made the decision to not sell, service, or support products in Russia, Belarus, and restricted regions of Ukraine.  Operations in Russia and Ukraine accounted for less than 1% of net revenue in Fiscal 2022.  During the second quarter of Fiscal 2023, we recognized $189 million in costs associated with exiting our business in Russia, primarily related to asset impairments and other exit related costs.  We have resumed product sales to non-sanctioned areas in Ukraine.  We are focused on providing products and support to Ukrainian customers, as they rebuild infrastructure and restore businesses and the financial sector.

[0001571996-22-000031:mdna:55]
The war and the related economic sanctions are impacting markets worldwide.  Our business may be adversely affected by potential effects, including supply chain disruptions, product shipping delays, macroeconomic impacts resulting from the exclusion of Russian financial institutions from the global banking system, volatility in foreign exchange rates and interest rates, inflationary pressures, and heightened cybersecurity and data theft threats.  The full impact of the war on our business operations and financial performance will depend on future developments.  We will continue to monitor and assess the related restrictions and other effects and pursue prudent decisions for our team members, customers, and business.

[0001571996-22-000031:mdna:56]
COVID-19 Pandemic and Response — We continue to monitor the COVID-19 pandemic and variants of the coronavirus, as well as the impact the pandemic has on our employees, customers, business partners, and communities.  As discussed above, we continue to manage through the impacts of the COVID-19 pandemic on our supply chain.  The ongoing impact of the COVID-19 pandemic on our business operations and financial performance remains uncertain and will depend on future developments.  We will continue to actively monitor global events and pursue prudent decisions to navigate in this uncertain and ever-changing environment.  For additional information about impacts of COVID-19 on our operations, see “Results of Operations—Consolidated Results” and “—Business Unit Results.”

[0001571996-22-000031:mdna:57]
Inflation Reduction Act — Subsequent to the close of the second quarter of Fiscal 2023, the Inflation Reduction Act of 2022 was enacted into law.  The statute includes a 15% corporate alternative minimum tax on adjusted financial statement income which is effective for the fiscal year ended February 2, 2024.  The new law also imposes a 1% excise tax on share repurchases, effective for repurchases made after December 31, 2022.  We are currently assessing the potential impact of this law.

[0001571996-22-000031:mdna:58]
Other Macroeconomic Risks and Uncertainties — The impacts of trade protection measures, including increases in tariffs and trade barriers, changes in government policies and international trade arrangements, and geopolitical issues may affect our ability to conduct business in some non-U.S. markets.  We monitor and seek to mitigate these risks with adjustments to our manufacturing, supply chain, and distribution networks.

[0001571996-22-000031:mdna:59]
ISG — We expect that ISG will continue to be impacted by the changing nature of the IT infrastructure market and competitive environment.  With our scale and strong solutions portfolio, we believe we are well-positioned to respond to ongoing competitive dynamics.  Within servers and networking, we will continue to be selective in determining whether to pursue certain large hyperscale and other server transactions.  We continue to focus on customer base expansion and lifetime value of customer relationships.

[0001571996-22-000031:mdna:60]
[same as prior period, unchanged from 0001571996-22-000021:mdna:57]

[0001571996-22-000031:mdna:61]
[same as prior period, unchanged from 0001571996-22-000021:mdna:58]

[0001571996-22-000031:mdna:62]
CSG — Our CSG offerings are an important element of our strategy, generating strong cash flow and opportunities for cross-selling of complementary solutions.  Competitive dynamics continue to be a factor in our CSG business and impact pricing and operating results.  We remain committed to our long-term strategy for CSG and will continue to make investments to innovate across the portfolio while benefiting from consolidation trends that are occurring in the markets in which we compete. We expect that the CSG demand environment will continue to be subject to seasonal trends.

[0001571996-22-000031:mdna:63]
Recurring Revenue and Consumption Models — Our customers are seeking new and innovative models that address how they consume our solutions.  We offer options including as-a-Service, utility, leases, loans, and immediate pay models designed to match customers’ consumption and financing preferences.  We believe these options are particularly beneficial during times of economic uncertainty as they provide our customers with financial flexibility to further enable them to procure our solutions.

[0001571996-22-000031:mdna:64]
We continue to evolve and build momentum across our family of as-a-Service offerings as we pursue our strategy of modernizing our core business solutions, with APEX at the forefront.  We expect that our flexible consumption models and as-a-Service offerings will further strengthen our customer relationships and provide a foundation for growth in recurring revenue.

[0001571996-22-000031:mdna:65]
[same as prior period, unchanged from 0001571996-22-000021:mdna:62]

[0001571996-22-000031:mdna:66]
[same as prior period, unchanged from 0001571996-22-000021:mdna:65]

[0001571996-22-000031:mdna:67]
[same as prior period, unchanged from 0001571996-22-000021:mdna:66]

[0001571996-22-000031:mdna:68]
64

[0001571996-22-000031:mdna:69]
[same as prior period, unchanged from 0001571996-22-000021:mdna:68]

[0001571996-22-000031:mdna:70]
In this management’s discussion and analysis, we use supplemental measures of our performance which are derived from our consolidated financial information but which are not presented in our consolidated financial statements prepared in accordance with GAAP.  These non-GAAP financial measures include non-GAAP product net revenue; non-GAAP services net revenue; non-GAAP net revenue; non-GAAP product gross margin; non-GAAP services gross margin; non-GAAP gross margin; non-GAAP operating expenses; non-GAAP operating income; non-GAAP net income; earnings before interest and other, net, taxes, depreciation, and amortization (“EBITDA”); and adjusted EBITDA.  The non-GAAP financial measures are not meant to be considered as indicators of performance in isolation from or as a substitute for net revenue, gross margin, operating expenses, operating income, or net income from continuing operations prepared in accordance with GAAP, and should be read only in conjunction with financial information presented on a GAAP basis.

[0001571996-22-000031:mdna:71]
Effective in the first quarter of Fiscal 2023, non-GAAP product net revenue, non-GAAP services net revenue, and non-GAAP net revenue no longer differ from the most comparable GAAP financial measures.  Such non-GAAP financial measures are provided below for all periods presented to show purchase accounting adjustments that impacted such financial measures in prior periods.

[0001571996-22-000031:mdna:72]
[same as prior period, unchanged from 0001571996-22-000021:mdna:71]

[0001571996-22-000031:mdna:73]
[same as prior period, unchanged from 0001571996-22-000021:mdna:72]

[0001571996-22-000031:mdna:74]
[same as prior period, unchanged from 0001571996-22-000021:mdna:73]

[0001571996-22-000031:mdna:75]
[same as prior period, unchanged from 0001571996-22-000021:mdna:74]

[0001571996-22-000031:mdna:76]
[same as prior period, unchanged from 0001571996-22-000021:mdna:75]

[0001571996-22-000031:mdna:77]
•Impact of Purchase Accounting — The impact of purchase accounting includes purchase accounting adjustments related to the EMC merger transaction and, to a lesser extent, the going-private transaction, recorded under the acquisition method of accounting in accordance with the accounting guidance for business combinations.  Accordingly, all of the assets and liabilities acquired in such transactions were accounted for and recognized at fair value as of the respective transaction dates, and the fair value adjustments are being amortized over the estimated useful lives in the periods following the transactions.  The fair value adjustments that are still amortizing primarily relate to property, plant, and equipment.  We believe that excluding the impact of purchase accounting for purposes of calculating the non-GAAP financial measures presented below facilitates an enhanced understanding of our current operating performance and provides more meaningful period to period comparisons.

[0001571996-22-000031:mdna:78]
•Transaction-related (income) Expenses — Transaction-related expenses typically consist of acquisition, integration, and divestiture related costs, as well as the costs incurred in the VMware Spin-off, and are expensed as incurred.  These expenses primarily represent costs for legal, banking, consulting, and advisory services.  From time to time, this category also may include transaction-related income related to divestitures of businesses or asset sales.  We exclude these items for purposes of calculating the non-GAAP financial measures presented below to facilitate an enhanced understanding of our current operating performance and provide more meaningful period to period comparisons.

[0001571996-22-000031:mdna:79]
[same as prior period, unchanged from 0001571996-22-000021:mdna:78]

[0001571996-22-000031:mdna:80]
•Other Corporate Expenses — Other corporate expenses consist of impairment charges, incentive charges related to equity investments, severance, facility action, payroll taxes associated with stock-based compensation, and other costs.  During the second quarter of Fiscal 2023, we recognized $189 million in costs associated with exiting our business in Russia, primarily related to asset impairments and other exit related costs.  Severance costs are primarily related to severance and benefits for employees terminated pursuant to cost savings initiatives.  We continue to optimize our facilities footprint and may incur additional costs as we seek opportunities for operational efficiencies.  Other corporate expenses vary from period to period and are significantly impacted by the timing and nature of these events.  Therefore, although we may incur these types of expenses in the future, we believe that eliminating these charges for purposes of calculating the non-GAAP financial measures presented below facilitates an enhanced understanding of our current operating performance and provides more meaningful period to period comparisons.

[0001571996-22-000031:mdna:81]
•Fair Value Adjustments on Equity Investments — Fair value adjustments on equity investments primarily consist of the gain (loss) on strategic investments, which includes the recurring fair value adjustments of investments in publicly-traded companies, as well as those in privately-held companies, which are adjusted for observable price changes and any potential impairments.  See Note 3 of the Notes to the Condensed Consolidated Financial Statements included in this report for additional information on our strategic investment activity.  Given the volatility in the ongoing adjustments to the valuation of these strategic investments, we believe that excluding these gains and losses for purposes of calculating non-GAAP net income presented below facilitates an enhanced understanding of our current operating performance and provides more meaningful period to period comparisons.

[0001571996-22-000031:mdna:82]
[same as prior period, unchanged from 0001571996-22-000021:mdna:81]

[0001571996-22-000031:mdna:83]
66

[0001571996-22-000031:mdna:84]
[same as prior period, unchanged from 0001571996-22-000021:mdna:82]

[0001571996-22-000031:mdna:85]
|  | Three Months Ended |  | Six Months Ended |
|  | July 29,2022 |  | % Change |  | July 30,2021 |  | July 29,2022 |  | % Change |  | July 30,2021 |  |  |  |  |
|  | (in millions, except percentages) |
| Product net revenue | $ | 20,810 |  |  | 10 | % |  | $ | 18,895 |  |  | $ | 41,274 |  |  | 13 | % |  | $ | 36,382 |  |  |  |  |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Impact of purchase accounting | — |  |  |  |  | 1 |  |  | — |  |  |  |  | — |  |  |  |  |  |
| Non-GAAP product net revenue | $ | 20,810 |  |  | 10 | % |  | $ | 18,896 |  |  | $ | 41,274 |  |  | 13 | % |  | $ | 36,382 |  |  |  |  |  |
| Services net revenue | $ | 5,615 |  |  | 6 | % |  | $ | 5,296 |  |  | $ | 11,267 |  |  | 8 | % |  | $ | 10,399 |  |  |  |  |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Impact of purchase accounting | — |  |  |  |  | 7 |  |  | — |  |  |  |  | 16 |  |  |  |  |  |
| Non-GAAP services net revenue | $ | 5,615 |  |  | 6 | % |  | $ | 5,303 |  |  | $ | 11,267 |  |  | 8 | % |  | $ | 10,415 |  |  |  |  |  |
| Net revenue | $ | 26,425 |  |  | 9 | % |  | $ | 24,191 |  |  | $ | 52,541 |  |  | 12 | % |  | $ | 46,781 |  |  |  |  |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Impact of purchase accounting | — |  |  |  |  | 8 |  |  | — |  |  |  |  | 16 |  |  |  |  |  |
| Non-GAAP net revenue | $ | 26,425 |  |  | 9 | % |  | $ | 24,199 |  |  | $ | 52,541 |  |  | 12 | % |  | $ | 46,797 |  |  |  |  |  |
| Product gross margin | $ | 3,139 |  |  | (2) | % |  | $ | 3,203 |  |  | $ | 6,594 |  |  | 5 | % |  | $ | 6,256 |  |  |  |  |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 105 |  |  |  |  | 149 |  |  | 209 |  |  |  |  | 300 |  |  |  |  |  |
| Impact of purchase accounting | — |  |  |  |  | 2 |  |  | 2 |  |  |  |  | 2 |  |  |  |  |  |
| Stock-based compensation expense | 13 |  |  |  |  | 11 |  |  | 26 |  |  |  |  | 20 |  |  |  |  |  |
| Other corporate expenses | 13 |  |  |  |  | 1 |  |  | 16 |  |  |  |  | 4 |  |  |  |  |  |
| Non-GAAP product gross margin | $ | 3,270 |  |  | (3) | % |  | $ | 3,366 |  |  | $ | 6,847 |  |  | 4 | % |  | $ | 6,582 |  |  |  |  |  |
| Services gross margin | $ | 2,300 |  |  | 1 | % |  | $ | 2,272 |  |  | $ | 4,629 |  |  | 3 | % |  | $ | 4,483 |  |  |  |  |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | — |  |  |  |  | 1 |  |  | — |  |  |  |  | — |  |  |  |  |  |
| Impact of purchase accounting | — |  |  |  |  | 7 |  |  | — |  |  |  |  | 16 |  |  |  |  |  |
| Stock-based compensation expense | 24 |  |  |  |  | 21 |  |  | 49 |  |  |  |  | 40 |  |  |  |  |  |
| Other corporate expenses | 56 |  |  |  |  | 6 |  |  | 66 |  |  |  |  | 16 |  |  |  |  |  |
| Non-GAAP services gross margin | $ | 2,380 |  |  | 3 | % |  | $ | 2,307 |  |  | $ | 4,744 |  |  | 4 | % |  | $ | 4,555 |  |  |  |  |  |

[0001571996-22-000031:mdna:86]
67

[0001571996-22-000031:mdna:87]
|  | Three Months Ended |  | Six Months Ended |
|  | July 29,2022 |  | % Change |  | July 30,2021 |  | July 29,2022 |  | % Change |  | July 30,2021 |  |  |  |  |
|  | (in millions, except percentages) |
| Gross margin | $ | 5,439 |  |  | (1) | % |  | $ | 5,475 |  |  | $ | 11,223 |  |  | 5 | % |  | $ | 10,739 |  |  |  |  |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 105 |  |  |  |  | 150 |  |  | 209 |  |  |  |  | 300 |  |  |  |  |  |
| Impact of purchase accounting | — |  |  |  |  | 9 |  |  | 2 |  |  |  |  | 18 |  |  |  |  |  |
| Stock-based compensation expense | 37 |  |  |  |  | 32 |  |  | 75 |  |  |  |  | 60 |  |  |  |  |  |
| Other corporate expenses | 69 |  |  |  |  | 7 |  |  | 82 |  |  |  |  | 20 |  |  |  |  |  |
| Non-GAAP gross margin | $ | 5,650 |  |  | — | % |  | $ | 5,673 |  |  | $ | 11,591 |  |  | 4 | % |  | $ | 11,137 |  |  |  |  |  |
| Operating expenses | $ | 4,169 |  |  | (6) | % |  | $ | 4,458 |  |  | $ | 8,403 |  |  | (4) | % |  | $ | 8,735 |  |  |  |  |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | (139) |  |  |  |  | (292) |  |  | (278) |  |  |  |  | (587) |  |  |  |  |  |
| Impact of purchase accounting | (3) |  |  |  |  | (6) |  |  | (10) |  |  |  |  | (17) |  |  |  |  |  |
| Transaction-related expenses | (3) |  |  |  |  | (37) |  |  | (8) |  |  |  |  | (66) |  |  |  |  |  |
| Stock-based compensation expense | (199) |  |  |  |  | (174) |  |  | (393) |  |  |  |  | (318) |  |  |  |  |  |
| Other corporate expenses | (127) |  |  |  |  | (144) |  |  | (210) |  |  |  |  | (248) |  |  |  |  |  |
| Non-GAAP operating expenses | $ | 3,698 |  |  | (3) | % |  | $ | 3,805 |  |  | $ | 7,504 |  |  | — | % |  | $ | 7,499 |  |  |  |  |  |
| Operating income | $ | 1,270 |  |  | 25 | % |  | $ | 1,017 |  |  | $ | 2,820 |  |  | 41 | % |  | $ | 2,004 |  |  |  |  |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 244 |  |  |  |  | 442 |  |  | 487 |  |  |  |  | 887 |  |  |  |  |  |
| Impact of purchase accounting | 3 |  |  |  |  | 15 |  |  | 12 |  |  |  |  | 35 |  |  |  |  |  |
| Transaction-related expenses | 3 |  |  |  |  | 37 |  |  | 8 |  |  |  |  | 66 |  |  |  |  |  |
| Stock-based compensation expense | 236 |  |  |  |  | 206 |  |  | 468 |  |  |  |  | 378 |  |  |  |  |  |
| Other corporate expenses | 196 |  |  |  |  | 151 |  |  | 292 |  |  |  |  | 268 |  |  |  |  |  |
| Non-GAAP operating income | $ | 1,952 |  |  | 4 | % |  | $ | 1,868 |  |  | $ | 4,087 |  |  | 12 | % |  | $ | 3,638 |  |  |  |  |  |
| Net income from continuing operations | $ | 506 |  |  | (20) | % |  | $ | 629 |  |  | $ | 1,575 |  |  | 22 | % |  | $ | 1,288 |  |  |  |  |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 244 |  |  |  |  | 442 |  |  | 487 |  |  |  |  | 887 |  |  |  |  |  |
| Impact of purchase accounting | 3 |  |  |  |  | 15 |  |  | 12 |  |  |  |  | 35 |  |  |  |  |  |
| Transaction-related (income) expenses | (4) |  |  |  |  | 25 |  |  | (6) |  |  |  |  | 54 |  |  |  |  |  |
| Stock-based compensation expense | 236 |  |  |  |  | 206 |  |  | 468 |  |  |  |  | 378 |  |  |  |  |  |
| Other corporate expenses | 212 |  |  |  |  | 151 |  |  | 308 |  |  |  |  | 268 |  |  |  |  |  |
| Fair value adjustments on equity investments | 255 |  |  |  |  | (168) |  |  | 241 |  |  |  |  | (362) |  |  |  |  |  |
| Aggregate adjustment for income taxes | (186) |  |  |  |  | (134) |  |  | (385) |  |  |  |  | (327) |  |  |  |  |  |
| Non-GAAP net income | $ | 1,266 |  |  | 9 | % |  | $ | 1,166 |  |  | $ | 2,700 |  |  | 22 | % |  | $ | 2,221 |  |  |  |  |  |

[0001571996-22-000031:mdna:88]
68

[0001571996-22-000031:mdna:89]
[same as prior period, unchanged from 0001571996-22-000021:mdna:87]

[0001571996-22-000031:mdna:90]
[same as prior period, unchanged from 0001571996-22-000021:mdna:88]

[0001571996-22-000031:mdna:91]
[same as prior period, unchanged from 0001571996-22-000021:mdna:89]

[0001571996-22-000031:mdna:92]
|  | Three Months Ended |  | Six Months Ended |
|  | July 29,2022 |  | % Change |  | July 30,2021 |  | July 29,2022 |  | % Change |  | July 30,2021 |  |  |  |  |
|  | (in millions, except percentages) |
| Net income from continuing operations | $ | 506 |  |  | (20) | % |  | $ | 629 |  |  | $ | 1,575 |  |  | 22 | % |  | $ | 1,288 |  |  |  |  |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest and other, net (a) | 635 |  |  |  |  | 292 |  |  | 972 |  |  |  |  | 580 |  |  |  |  |  |
| Income tax expense (benefit) | 129 |  |  |  |  | 96 |  |  | 273 |  |  |  |  | 136 |  |  |  |  |  |
| Depreciation and amortization | 744 |  |  |  |  | 904 |  |  | 1,470 |  |  |  |  | 1,809 |  |  |  |  |  |
| EBITDA | $ | 2,014 |  |  | 5 | % |  | $ | 1,921 |  |  | $ | 4,290 |  |  | 13 | % |  | $ | 3,813 |  |  |  |  |  |
| EBITDA | $ | 2,014 |  |  | 5 | % |  | $ | 1,921 |  |  | $ | 4,290 |  |  | 13 | % |  | $ | 3,813 |  |  |  |  |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation expense | 236 |  |  |  |  | 206 |  |  | 468 |  |  |  |  | 378 |  |  |  |  |  |
| Impact of purchase accounting (b) | — |  |  |  |  | 8 |  |  | — |  |  |  |  | 20 |  |  |  |  |  |
| Transaction-related expenses (c) | 3 |  |  |  |  | 37 |  |  | 8 |  |  |  |  | 66 |  |  |  |  |  |
| Other corporate expenses (d) | 196 |  |  |  |  | 151 |  |  | 292 |  |  |  |  | 268 |  |  |  |  |  |
| Adjusted EBITDA | $ | 2,449 |  |  | 5 | % |  | $ | 2,323 |  |  | $ | 5,058 |  |  | 11 | % |  | $ | 4,545 |  |  |  |  |  |

[0001571996-22-000031:mdna:93]
[same as prior period, unchanged from 0001571996-22-000021:mdna:91]

[0001571996-22-000031:mdna:94]
[same as prior period, unchanged from 0001571996-22-000021:mdna:92]

[0001571996-22-000031:mdna:95]
(b)This amount includes the non-cash purchase accounting adjustments related to the EMC merger transaction and the going-private transaction.

[0001571996-22-000031:mdna:96]
(c)Transaction-related expenses consist of acquisition, integration, and divestiture related costs, as well as the costs incurred in the VMware Spin-off.

[0001571996-22-000031:mdna:97]
(d)Other corporate expenses includes impairment charges, incentive charges related to equity investments, severance, facility action, payroll taxes associated with stock-based compensation, and other costs.  During the second quarter and first six months of Fiscal 2023, other corporate expenses includes $189 million of costs incurred in connection with exiting our business in Russia.

[0001571996-22-000031:mdna:98]
69

[0001571996-22-000031:mdna:99]
[same as prior period, unchanged from 0001571996-22-000021:mdna:97]

[0001571996-22-000031:mdna:100]
[same as prior period, unchanged from 0001571996-22-000021:mdna:98]

[0001571996-22-000031:mdna:101]
[same as prior period, unchanged from 0001571996-22-000021:mdna:99]

[0001571996-22-000031:mdna:102]
|  | Three Months Ended |  | Six Months Ended |
|  | July 29, 2022 |  |  |  | July 30, 2021 |  | July 29, 2022 |  |  |  | July 30, 2021 |  |  |  |  |
|  | Dollars |  | % of Net Revenue |  | %Change |  | Dollars |  | % of Net Revenue |  | Dollars |  | % ofNet Revenue |  | %Change |  | Dollars |  | % ofNet Revenue |  |  |  |  |  |  |
|  | (in millions, except percentages) |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Products | $ | 20,810 |  |  | 78.8 | % |  | 10 | % |  | $ | 18,895 |  |  | 78.1 | % |  | $ | 41,274 |  |  | 78.6 | % |  | 13 | % |  | $ | 36,382 |  |  | 77.8 | % |  |  |  |  |  |  |
| Services | 5,615 |  |  | 21.2 | % |  | 6 | % |  | 5,296 |  |  | 21.9 | % |  | 11,267 |  |  | 21.4 | % |  | 8 | % |  | 10,399 |  |  | 22.2 | % |  |  |  |  |  |  |
| Total net revenue | $ | 26,425 |  |  | 100.0 | % |  | 9 | % |  | $ | 24,191 |  |  | 100.0 | % |  | $ | 52,541 |  |  | 100.0 | % |  | 12 | % |  | $ | 46,781 |  |  | 100.0 | % |  |  |  |  |  |  |
| Gross margin: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Products (a) | $ | 3,139 |  |  | 15.1 | % |  | (2) | % |  | $ | 3,203 |  |  | 17.0 | % |  | $ | 6,594 |  |  | 16.0 | % |  | 5 | % |  | $ | 6,256 |  |  | 17.2 | % |  |  |  |  |  |  |
| Services (b) | 2,300 |  |  | 41.0 | % |  | 1 | % |  | 2,272 |  |  | 42.9 | % |  | 4,629 |  |  | 41.1 | % |  | 3 | % |  | 4,483 |  |  | 43.1 | % |  |  |  |  |  |  |
| Total gross margin | $ | 5,439 |  |  | 20.6 | % |  | (1) | % |  | $ | 5,475 |  |  | 22.6 | % |  | $ | 11,223 |  |  | 21.4 | % |  | 5 | % |  | $ | 10,739 |  |  | 23.0 | % |  |  |  |  |  |  |
| Operating expenses | $ | 4,169 |  |  | 15.8 | % |  | (6) | % |  | $ | 4,458 |  |  | 18.4 | % |  | $ | 8,403 |  |  | 16.0 | % |  | (4) | % |  | $ | 8,735 |  |  | 18.7 | % |  |  |  |  |  |  |
| Operating income | $ | 1,270 |  |  | 4.8 | % |  | 25 | % |  | $ | 1,017 |  |  | 4.2 | % |  | $ | 2,820 |  |  | 5.4 | % |  | 41 | % |  | $ | 2,004 |  |  | 4.3 | % |  |  |  |  |  |  |
| Net income from continuing operations | $ | 506 |  |  | 1.9 | % |  | (20) | % |  | $ | 629 |  |  | 2.6 | % |  | $ | 1,575 |  |  | 3.0 | % |  | 22 | % |  | $ | 1,288 |  |  | 2.8 | % |  |  |  |  |  |  |
| Non-GAAP Financial Information |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  | Three Months Ended |  | Six Months Ended |
|  | July 29, 2022 |  |  |  | July 30, 2021 |  | July 29, 2022 |  |  |  | July 30, 2021 |  |  |  |  |
|  | Dollars |  | % of Non-GAAP Net Revenue |  | %Change |  | Dollars |  | % of Non-GAAP Net Revenue |  | Dollars |  | % of Non-GAAP Net Revenue |  | %Change |  | Dollars |  | % of Non-GAAP Net Revenue |  |  |  |  |  |  |
|  | (in millions, except percentages) |
| Non-GAAP net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Products | $ | 20,810 |  |  | 78.8 | % |  | 10 | % |  | $ | 18,896 |  |  | 78.1 | % |  | $ | 41,274 |  |  | 78.6 | % |  | 13 | % |  | $ | 36,382 |  |  | 77.7 | % |  |  |  |  |  |  |
| Services | 5,615 |  |  | 21.2 | % |  | 6 | % |  | 5,303 |  |  | 21.9 | % |  | 11,267 |  |  | 21.4 | % |  | 8 | % |  | 10,415 |  |  | 22.3 | % |  |  |  |  |  |  |
| Total non-GAAP net revenue | $ | 26,425 |  |  | 100.0 | % |  | 9 | % |  | $ | 24,199 |  |  | 100.0 | % |  | $ | 52,541 |  |  | 100.0 | % |  | 12 | % |  | $ | 46,797 |  |  | 100.0 | % |  |  |  |  |  |  |
| Non-GAAP gross margin: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Products (a) | $ | 3,270 |  |  | 15.7 | % |  | (3) | % |  | $ | 3,366 |  |  | 17.8 | % |  | $ | 6,847 |  |  | 16.6 | % |  | 4 | % |  | $ | 6,582 |  |  | 18.1 | % |  |  |  |  |  |  |
| Services (b) | 2,380 |  |  | 42.4 | % |  | 3 | % |  | 2,307 |  |  | 43.5 | % |  | 4,744 |  |  | 42.1 | % |  | 4 | % |  | 4,555 |  |  | 43.7 | % |  |  |  |  |  |  |
| Total non-GAAP gross margin | $ | 5,650 |  |  | 21.4 | % |  | — | % |  | $ | 5,673 |  |  | 23.4 | % |  | $ | 11,591 |  |  | 22.1 | % |  | 4 | % |  | $ | 11,137 |  |  | 23.8 | % |  |  |  |  |  |  |
| Non-GAAP operating expenses | $ | 3,698 |  |  | 14.0 | % |  | (3) | % |  | $ | 3,805 |  |  | 15.7 | % |  | $ | 7,504 |  |  | 14.3 | % |  | — | % |  | $ | 7,499 |  |  | 16.0 | % |  |  |  |  |  |  |
| Non-GAAP operating income | $ | 1,952 |  |  | 7.4 | % |  | 4 | % |  | $ | 1,868 |  |  | 7.7 | % |  | $ | 4,087 |  |  | 7.8 | % |  | 12 | % |  | $ | 3,638 |  |  | 7.8 | % |  |  |  |  |  |  |
| Non-GAAP net income | $ | 1,266 |  |  | 4.8 | % |  | 9 | % |  | $ | 1,166 |  |  | 4.8 | % |  | $ | 2,700 |  |  | 5.1 | % |  | 22 | % |  | $ | 2,221 |  |  | 4.7 | % |  |  |  |  |  |  |
| EBITDA | $ | 2,014 |  |  | 7.6 | % |  | 5 | % |  | $ | 1,921 |  |  | 7.9 | % |  | $ | 4,290 |  |  | 8.2 | % |  | 13 | % |  | $ | 3,813 |  |  | 8.1 | % |  |  |  |  |  |  |
| Adjusted EBITDA | $ | 2,449 |  |  | 9.3 | % |  | 5 | % |  | $ | 2,323 |  |  | 9.6 | % |  | $ | 5,058 |  |  | 9.6 | % |  | 11 | % |  | $ | 4,545 |  |  | 9.7 | % |  |  |  |  |  |  |

[0001571996-22-000031:mdna:103]
[same as prior period, unchanged from 0001571996-22-000021:mdna:101]

[0001571996-22-000031:mdna:104]
(a)    Product gross margin and non-GAAP product gross margin percentages are calculated as a percentage of product net revenue and non-GAAP product net revenue, respectively.

[0001571996-22-000031:mdna:105]
(b)    Services gross margin and non-GAAP services gross margin percentages are calculated as a percentage of services net revenue and non-GAAP services net revenue, respectively.

[0001571996-22-000031:mdna:106]
[same as prior period, unchanged from 0001571996-22-000021:mdna:105]

[0001571996-22-000031:mdna:107]
[same as prior period, unchanged from 0001571996-22-000021:mdna:106]

[0001571996-22-000031:mdna:108]
During the second quarter and first six months of Fiscal 2023, our net revenue increased 9% and 12%, respectively, due to growth in net revenue for both CSG and ISG.  CSG net revenue benefited from growth in net revenue attributable to our commercial offerings.  ISG net revenue growth continued throughout the second quarter and first six months of Fiscal 2023 driven by strength in our offerings across both servers and networking and storage.

[0001571996-22-000031:mdna:109]
During the second quarter and first six months of Fiscal 2023, our operating income increased 25% to $1.3 billion and 41% to $2.8 billion, respectively.  These increases were primarily due to the favorable impact of a decrease in amortization of intangible assets and growth in operating income for ISG.  Growth in ISG operating income for the second quarter of Fiscal 2023 was driven by our server and networking and storage offerings while, for the first six months of Fiscal 2023, ISG operating income growth was primarily due to strength in our storage offerings.  During the second quarter and first six months of Fiscal 2023 our non-GAAP operating income increased 4% to $2.0 billion and increased 12% to $4.1 billion driven by the same ISG dynamics discussed above.

[0001571996-22-000031:mdna:110]
Operating income as a percentage of net revenue increased 60 basis points to 4.8% and 110 basis points to 5.4% during the second quarter and first six months of Fiscal 2023, respectively.  These increases were primarily driven by a decrease in operating expenses as a percentage of net revenue due to continued disciplined cost management and by the favorable impact of a decrease in amortization of intangible assets.  The effect of these factors was partially offset by declines in gross margin as a percentage of net revenue primarily due to the impacts of an overall increase in cost of net revenue and foreign currency exchange rate fluctuations, which were not entirely offset by pricing adjustments as we balanced profitability with competitive positioning.  Non-GAAP operating income as a percentage of net revenue decreased 30 basis points to 7.4% and was flat at 7.8% during the second quarter and first six months of Fiscal 2023, respectively, driven by declines in gross margin as a percentage of net revenue offset by decreases in operating expenses as a percentage of net revenue.

[0001571996-22-000031:mdna:111]
Cash provided by operating activities was $0.5 billion and $4.0 billion during the first six months of Fiscal 2023 and Fiscal 2022, respectively.  During the first six months of Fiscal 2022, $2.1 billion of the $4.0 billion total represented cash provided by operating activities attributable to VMware.  Cash provided by operating activities during the first six months of Fiscal 2023 reflected continued profitability, partially offset by working capital dynamics.  See “Liquidity, Cash Requirements, and Market Conditions” for further information on our cash flow metrics.

[0001571996-22-000031:mdna:112]
We continue to see opportunities to create value and grow in response to demand for our IT solutions driven by a technology-enabled world.  We have demonstrated our ability to adjust to changing market conditions with complementary solutions across both segments of our business, an agile workforce, and the strength of our global supply chain.  As we continue to innovate and modernize our core offerings, we believe that Dell Technologies is well-positioned for long-term profitable growth.

[0001571996-22-000031:mdna:113]
[same as prior period, unchanged from 0001571996-22-000021:mdna:112]

[0001571996-22-000031:mdna:114]
During the second quarter and first six months of Fiscal 2023, our net revenue increased 9% and increased 12%, respectively, due to growth in net revenue for both CSG and ISG.  See “Business Unit Results” for further information.

[0001571996-22-000031:mdna:115]
•Product Net Revenue — Product net revenue includes revenue from the sale of hardware products and software licenses.  During the second quarter and first six months of Fiscal 2023, our product net revenue increased 10% and 13%, respectively, driven by growth within both CSG and ISG.  CSG product net revenue increased primarily due to growth within our commercial offerings partially offset by a decrease within our consumer offerings.  ISG product net revenue growth was primarily attributable to growth in net revenue from sales of servers and networking and, to a lesser extent, an increase in net revenue from sales of storage.

[0001571996-22-000031:mdna:116]
•Services Net Revenue — Services net revenue includes revenue from our services offerings and support services related to hardware products and software licenses.  During the second quarter and first six months of Fiscal 2023, services net revenue increased 6% and 8%, respectively, driven principally by strength in hardware support and maintenance and third-party software support and maintenance within CSG.  A substantial portion of services net revenue is derived from offerings that have been deferred over a period of time, and, as a result, reported services net revenue growth rates will be different than reported product net revenue growth rates.

[0001571996-22-000031:mdna:117]
From a geographical perspective, net revenue generated by sales to customers in all regions increased during the second quarter and first six months of Fiscal 2023, driven by both CSG and ISG.

[0001571996-22-000031:mdna:118]
[same as prior period, unchanged from 0001571996-22-000021:mdna:118]

[0001571996-22-000031:mdna:119]
During the second quarter of Fiscal 2023, our gross margin decreased 1% to $5.4 billion and our non-GAAP gross margin remained flat at $5.7 billion, driven by declines in CSG and other businesses gross margin that were mostly offset by growth in ISG gross margin.

[0001571996-22-000031:mdna:120]
During the first six months of Fiscal 2023, our gross margin increased 5% to $11.2 billion and our non-GAAP gross margin increased 4% to $11.6 billion.  These increases were driven primarily by an increase in ISG gross margin due to continued strength in net revenue growth attributable to both storage and servers and networking.

[0001571996-22-000031:mdna:121]
During the second quarter of Fiscal 2023, both our gross margin and non-GAAP gross margin percentages decreased 200 basis points to 20.6% and 21.4%, respectively, while during the first six months of Fiscal 2023, gross margin and non-GAAP gross margin percentages decreased 160 basis points to 21.4% and 170 basis points to 22.1%, respectively.  These decreases were primarily due to the impacts of an overall increase in cost of net revenue and foreign currency exchange rate fluctuations, which were not entirely offset by pricing adjustments as we balanced profitability with competitive positioning.  Increased cost of net revenue was principally driven by a net increase in input costs, as compared to the second quarter and first six months of Fiscal 2022, which broadly impacted our product offerings.

[0001571996-22-000031:mdna:122]
•Product Gross Margin — During the second quarter of Fiscal 2023, product gross margin and non-GAAP product gross margin decreased 2% to $3.1 billion and 3% to $3.3 billion, respectively.  These decreases were primarily due to a decline in CSG product gross margin, principally related to our consumer offerings, which was partially offset by an increase in ISG product gross margin.  ISG product gross margin increased primarily due continued strength in product net revenue growth for our server and networking offerings.

[0001571996-22-000031:mdna:123]
During the first six months of Fiscal 2023, product gross margin and non-GAAP product gross margin increased 5% to $6.6 billion and 4% to $6.8 billion, respectively.  These increases were attributable to growth in ISG product gross margin, which was driven primarily by strength in product net revenue growth for our server and networking offerings coupled with product net revenue growth in our storage offerings.  Growth in ISG product gross margin was partially offset by a decrease in CSG product gross margin driven primarily by our consumer offerings.

[0001571996-22-000031:mdna:124]
During the second quarter of Fiscal 2023, product gross margin percentage and non-GAAP product gross margin percentage decreased 190 basis points to 15.1% and 210 basis points to 15.7%, respectively, while during the first six months of Fiscal 2023 product gross margin percentage and non-GAAP product gross margin percentage decreased 120 basis points to 16.0% and 150 basis points to 16.6%, respectively.  The decrease during the second quarter of Fiscal 2023 was primarily due to a decline in product gross margin percentage for both CSG and ISG.  For the first six months of Fiscal 2023, product gross margin percentage decreased primarily due to a decline in CSG product gross margin percentage and, to a lesser extent, a decline in ISG product gross margin percentage.

[0001571996-22-000031:mdna:125]
•Services Gross Margin — During the second quarter and first six months of Fiscal 2023, services gross margin increased 1% to $2.3 billion and 3% to $4.6 billion, respectively.  During the second quarter and first six months of Fiscal 2023, non-GAAP services gross margin increased 3% to $2.4 billion and 4% to $4.7 billion, respectively.  These increases were driven primarily by increased CSG services gross margin as a result of growth within hardware support and maintenance associated with products sold in prior periods.

[0001571996-22-000031:mdna:126]
During the second quarter and first six months of Fiscal 2023, services gross margin percentage decreased 190 basis points to 41.0% and 200 basis points to 41.1%, respectively.  These decreases were driven in part by declines in services gross margin percentage for ISG and, to a lesser extent, a shift in mix towards CSG.  The impacts of the divestiture of Boomi during the third quarter of Fiscal 2022 coupled with asset impairment costs associated with exiting our Russia business also contributed to the declines.  During the second quarter and first six months of Fiscal 2023, non-GAAP services gross margin percentage decreased 110 basis points to 42.4% and 160 basis points to 42.1%, respectively, driven by the same ISG, CSG, and Boomi divestiture impacts discussed above.

[0001571996-22-000031:mdna:127]
[same as prior period, unchanged from 0001571996-22-000021:mdna:125]

[0001571996-22-000031:mdna:128]
[same as prior period, unchanged from 0001571996-22-000021:mdna:126]

[0001571996-22-000031:mdna:129]
The terms and conditions of our vendor rebate programs are largely based on product volumes and are generally negotiated either at the beginning of the annual or quarterly period, depending on the program.  The timing and amount of vendor rebates and other discounts we receive under the programs may vary from period to period, reflecting changes in the competitive environment.  We monitor our component costs and seek to address the effects of any changes to terms that might arise under our vendor rebate programs.  Our gross margins for the second quarter and first six months of Fiscal 2023 and for the second quarter and first six months of Fiscal 2022 were not materially affected by any changes to the terms of our vendor rebate programs, as the amounts we received under these programs were generally stable relative to our total net cost.  We are not aware of any significant changes to vendor pricing or rebate programs that may impact our results in the near term.

[0001571996-22-000031:mdna:130]
73

[0001571996-22-000031:mdna:131]
[same as prior period, unchanged from 0001571996-22-000021:mdna:128]

[0001571996-22-000031:mdna:132]
[same as prior period, unchanged from 0001571996-22-000021:mdna:129]

[0001571996-22-000031:mdna:133]
|  | Three Months Ended |  | Six Months Ended |
|  | July 29, 2022 |  |  |  | July 30, 2021 |  | July 29, 2022 |  |  |  | July 30, 2021 |  |  |  |  |
|  | Dollars |  | % of Net Revenue |  | %Change |  | Dollars |  | % of Net Revenue |  | Dollars |  | % of Net Revenue |  | %Change |  | Dollars |  | % of Net Revenue |  |  |  |  |  |  |
|  | (in millions, except percentages) |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling, general, and administrative | $ | 3,543 |  |  | 13.4 | % |  | (6) | % |  | $ | 3,761 |  |  | 15.5 | % |  | $ | 7,096 |  |  | 13.5 | % |  | (4) | % |  | $ | 7,419 |  |  | 15.9 | % |  |  |  |  |  |  |
| Research and development | 626 |  |  | 2.4 | % |  | (10) | % |  | 697 |  |  | 2.9 | % |  | 1,307 |  |  | 2.5 | % |  | (1) | % |  | 1,316 |  |  | 2.8 | % |  |  |  |  |  |  |
| Total operating expenses | $ | 4,169 |  |  | 15.8 | % |  | (6) | % |  | $ | 4,458 |  |  | 18.4 | % |  | $ | 8,403 |  |  | 16.0 | % |  | (4) | % |  | $ | 8,735 |  |  | 18.7 | % |  |  |  |  |  |  |
|  | Three Months Ended |  | Six Months Ended |
|  | July 29, 2022 |  |  |  | July 30, 2021 |  | July 29, 2022 |  |  |  | July 30, 2021 |  |  |  |  |
|  | Dollars |  | % of Net Revenue |  | %Change |  | Dollars |  | % of Net Revenue |  | Dollars |  | % of Net Revenue |  | %Change |  | Dollars |  | % of Net Revenue |  |  |  |  |  |  |
|  | (in millions, except percentages) |
| Non-GAAP operating expenses | $ | 3,698 |  |  | 14.0 | % |  | (3) | % |  | $ | 3,805 |  |  | 15.7 | % |  | $ | 7,504 |  |  | 14.3 | % |  | — | % |  | $ | 7,499 |  |  | 16.0 | % |  |  |  |  |  |  |

[0001571996-22-000031:mdna:134]
During the second quarter and first six months of Fiscal 2023, total operating expenses decreased 6% and 4%, respectively, primarily driven by a decrease in selling, general, and administrative expenses in both periods.

[0001571996-22-000031:mdna:135]
•Selling, General, and Administrative — Selling, general, and administrative (“SG&A”) expenses decreased 6% and 4% during the second quarter and first six months of Fiscal 2023, respectively.  The decreases in SG&A expenses were primarily attributable to a decrease in amortization of intangible assets and a decrease in employee compensation and benefits expense primarily resulting from a reduction in performance-based compensation and disciplined cost management.

[0001571996-22-000031:mdna:136]
•Research and Development — Research and development (“R&D”) expenses are primarily composed of personnel-related expenses related to product development.  R&D expenses decreased 10% and 1% during the second quarter and first six months of Fiscal 2023, respectively.  The decrease in R&D expenses during the second quarter of Fiscal 2023 was driven by the same employee compensation and benefits dynamics discussed within SG&A above.  As a percentage of net revenue, R&D expenses for the second quarter of Fiscal 2023 and Fiscal 2022 were 2.4% and 2.9%, respectively, and, for the first six months of Fiscal 2023 and Fiscal 2022, were 2.5% and 2.8%, respectively.  These decreases were driven by revenue growth which outpaced our R&D investments coupled with disciplined cost management.  We intend to continue supporting R&D initiatives to innovate and introduce new and enhanced solutions into the market.

[0001571996-22-000031:mdna:137]
During the second quarter and first six months of Fiscal 2023, non-GAAP operating expenses decreased 3% and were flat, respectively.  The decrease in non-GAAP operating expenses during the second quarter of Fiscal 2023 was principally due to a decline in employee compensation and benefits expense primarily resulting from a reduction in performance-based compensation and disciplined cost management.  For the first six months of Fiscal 2023, a decrease in employee compensation and benefits expense was offset by increases in other selling, general, and administrative expenses.

[0001571996-22-000031:mdna:138]
[same as prior period, unchanged from 0001571996-22-000021:mdna:134]

[0001571996-22-000031:mdna:139]
[same as prior period, unchanged from 0001571996-22-000021:mdna:135]

[0001571996-22-000031:mdna:140]
During the second quarter and first six months of Fiscal 2023, our operating income increased 25% to $1.3 billion and 41% to $2.8 billion, respectively.  These increases were primarily due to the favorable impact of a decrease in amortization of intangible assets and growth in operating income for ISG.  Growth in ISG operating income for the second quarter of Fiscal 2023 was driven by our server and networking and storage offerings while, for the first six months of Fiscal 2023, ISG operating income growth was primarily due to strength in our storage offerings.  During the second quarter and first six months of Fiscal 2023, our non-GAAP operating income increased 4% to $2.0 billion and 12% to $4.1 billion driven by the same ISG dynamics discussed above.

[0001571996-22-000031:mdna:141]
Operating income as a percentage of net revenue increased 60 basis points to 4.8% and 110 basis points to 5.4% during the second quarter and first six months of Fiscal 2023, respectively.  These increases were primarily driven by a decrease in operating expenses as a percentage of net revenue due to continued disciplined cost management and the favorable impact of a decrease in amortization of intangible assets.  The effect of these factors was partially offset by declines in gross margin as a percentage of net revenue primarily due to the impacts of an overall increase in cost of net revenue and foreign currency exchange rate fluctuations, which were not entirely offset by pricing adjustments as we balanced profitability with competitive positioning.  Non-GAAP operating income as a percentage of net revenue decreased 30 basis points to 7.4% and was flat at 7.8% during the second quarter and first six months of Fiscal 2023, respectively, driven by declines in gross margin as a percentage of net revenue offset by decreases in operating expenses as a percentage of net revenue.

[0001571996-22-000031:mdna:142]
[same as prior period, unchanged from 0001571996-22-000021:mdna:138]

[0001571996-22-000031:mdna:143]
[same as prior period, unchanged from 0001571996-22-000021:mdna:139]

[0001571996-22-000031:mdna:144]
|  | Three Months Ended |  | Six Months Ended |
|  | July 29, 2022 |  | July 30, 2021 |  | July 29, 2022 |  | July 30, 2021 |  |  |
|  | (in millions) |
| Interest and other, net: |  |  |  |  |  |  |  |  |  |
| Investment income, primarily interest | $ | 16 |  |  | $ | 10 |  |  | $ | 31 |  |  | $ | 20 |  |  |  |
| Gain (loss) on investments, net | (255) |  |  | 166 |  |  | (241) |  |  | 359 |  |  |  |
| Interest expense | (298) |  |  | (416) |  |  | (563) |  |  | (849) |  |  |  |
| Foreign exchange | (66) |  |  | (67) |  |  | (155) |  |  | (119) |  |  |  |
| Other | (32) |  |  | 15 |  |  | (44) |  |  | 9 |  |  |  |
| Total interest and other, net | $ | (635) |  |  | $ | (292) |  |  | $ | (972) |  |  | $ | (580) |  |  |  |

[0001571996-22-000031:mdna:145]
During the second quarter and first six months of Fiscal 2023, the change in interest and other, net was unfavorable by $343 million and $392 million, respectively.  The unfavorable change in both periods was primarily attributable to the net loss on investments as a result of fair value adjustments on our non-marketable strategic investment portfolio discussed above, which were partially offset by a decrease in interest expense on lower average outstanding debt balances.

[0001571996-22-000031:mdna:146]
[same as prior period, unchanged from 0001571996-22-000021:mdna:142]

[0001571996-22-000031:mdna:147]
[same as prior period, unchanged from 0001571996-22-000021:mdna:143]

[0001571996-22-000031:mdna:148]
|  | Three Months Ended |  | Six Months Ended |
|  | July 29, 2022 |  | July 30, 2021 |  | July 29, 2022 |  | July 30, 2021 |
|  | (in millions, except percentages) |
| Income before income taxes | $ | 635 |  |  | $ | 725 |  |  | $ | 1,848 |  |  | $ | 1,424 |  |
| Income tax expense | $ | 129 |  |  | $ | 96 |  |  | $ | 273 |  |  | $ | 136 |  |
| Effective income tax rate | 20.3 | % |  | 13.2 | % |  | 14.8 | % |  | 9.6 | % |

[0001571996-22-000031:mdna:149]
75

[0001571996-22-000031:mdna:150]
For the second quarter of Fiscal 2023 and Fiscal 2022, our effective income tax rate was 20.3% and 13.2%, respectively.  For the first six months of Fiscal 2023 and Fiscal 2022, our effective income tax rate was 14.8% and 9.6%, respectively.  For the second quarter and first six months of Fiscal 2023, the changes in the Company’s effective tax rates were primarily attributable to changes in discrete tax items.  Other increases in our effective income tax rates were driven by a change in our jurisdictional mix of income and higher U.S. tax on foreign operations, the effects of which were partially offset by higher benefits from foreign tax credits.

[0001571996-22-000031:mdna:151]
Higher U.S. tax on foreign operations was due to the capitalization of research and development costs.  Under the Tax Cuts and Jobs Act, which was enacted on December 22, 2017, research and development expenses incurred for tax years beginning after December 31, 2021 must be capitalized and amortized ratably over five or 15 years for tax purposes, depending on where the research activities were conducted.  Our effective income tax rate for future quarters of Fiscal 2023 may be impacted by actions taken by the U.S. government to defer or repeal this provision, as well as by the actual mix of jurisdictions in which income is generated and the impact of any discrete tax items.  In addition, if the provision is not deferred or repealed, we expect it will result in a significant increase in our cash tax liabilities for Fiscal 2023, as well as a significant reduction to our deferred tax liabilities.

[0001571996-22-000031:mdna:152]
Our effective income tax rate can fluctuate depending on the geographic distribution of our worldwide earnings, as our foreign earnings are generally taxed at lower rates than in the United States.  The differences between our effective income tax rate and the U.S. federal statutory rate of 21% principally result from the geographical distribution of income, differences between the book and tax treatment of certain items, and discrete tax items.  In certain jurisdictions, our tax rate is significantly less than the applicable statutory rate as a result of tax holidays.  The majority of our foreign income that is subject to these tax holidays is attributable to Singapore and China.  A significant portion of these income tax benefits relates to a tax holiday that will be effective until January 31, 2029.  Our other tax holidays will expire in whole or in part during Fiscal 2030 through Fiscal 2031.  Many of these tax holidays and reduced tax rates may be extended when certain conditions are met or may be terminated early if certain conditions are not met.  As of July 29, 2022, we were not aware of any matters of noncompliance related to these tax holidays.

[0001571996-22-000031:mdna:153]
[same as prior period, unchanged from 0001571996-22-000021:mdna:148]

[0001571996-22-000031:mdna:154]
See “Introduction – Business Trends and Challenges – Inflation Reduction Act” for a discussion of recent tax legislation.

[0001571996-22-000031:mdna:155]
[same as prior period, unchanged from 0001571996-22-000021:mdna:149]

[0001571996-22-000031:mdna:156]
Net income from continuing operations was $0.5 billion and $0.6 billion during the second quarter of Fiscal 2023 and Fiscal 2022, respectively.  The decrease was driven principally by an unfavorable change in interest and other, net, partially offset by an increase in operating income.

[0001571996-22-000031:mdna:157]
During the first six months of Fiscal 2023 and Fiscal 2022, net income from continuing operations was $1.6 billion and $1.3 billion, respectively.  The increase was primarily due to an increase in operating income, partially offset by an unfavorable change in interest and other, net and an increase in tax expense.

[0001571996-22-000031:mdna:158]
Non-GAAP net income was $1.3 billion and $2.7 billion for the second quarter and first six months of Fiscal 2023, respectively, compared to $1.2 billion and $2.2 billion for the second quarter and first six months of Fiscal 2022, respectively.  The increases were primarily attributable to an increase in non-GAAP operating income and a favorable change in interest and other, net, partially offset by an increase in tax expense during the current periods.

[0001571996-22-000031:mdna:159]
[same as prior period, unchanged from 0001571996-22-000021:mdna:152]

[0001571996-22-000031:mdna:160]
[same as prior period, unchanged from 0001571996-22-000021:mdna:153]

[0001571996-22-000031:mdna:161]
[same as prior period, unchanged from 0001571996-22-000021:mdna:154]

[0001571996-22-000031:mdna:162]
[same as prior period, unchanged from 0001571996-22-000021:mdna:155]

[0001571996-22-000031:mdna:163]
|  | Three Months Ended |  | Six Months Ended |
|  | July 29, 2022 |  | % Change |  | July 30, 2021 |  | July 29, 2022 |  | % Change |  | July 30, 2021 |  |  |  |  |
|  | (in millions, except percentages) |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Servers and networking | $ | 5,209 |  |  | 16 | % |  | $ | 4,480 |  | $ | 10,257 |  | 19 | % |  | $ | 8,620 |  |  |  |  |
| Storage | 4,327 |  |  | 6 | % |  | 4,070 |  | 8,564 |  | 8 | % |  | 7,963 |  |  |  |  |
| Total ISG net revenue | $ | 9,536 |  |  | 12 | % |  | $ | 8,550 |  | $ | 18,821 |  | 13 | % |  | $ | 16,583 |  |  |  |  |
| Operating income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| ISG operating income | $ | 1,046 |  |  | 9 | % |  | $ | 962 |  | $ | 2,128 |  | 22 | % |  | $ | 1,740 |  |  |  |  |
| % of segment net revenue | 11.0 | % |  |  |  | 11.3 | % |  | 11.3 | % |  |  |  | 10.5 | % |  |  |  |  |

[0001571996-22-000031:mdna:164]
Net Revenue — During the second quarter and first six months of Fiscal 2023, ISG net revenue increased 12% and 13%, respectively, driven by strength across both servers and networking and storage offerings.

[0001571996-22-000031:mdna:165]
Revenue from sales of servers and networking increased 16% and 19% during the second quarter and first six months of Fiscal 2023, respectively.  The increases were primarily driven by an increase in average selling price of our server offerings, the effect of which was partially offset by a decrease in units sold.  The average selling price for our server offerings increased as a result of a shift in mix within servers, richer configurations, and continued actions to manage pricing in response to increased input costs.

[0001571996-22-000031:mdna:166]
During the second quarter and first six months of Fiscal 2023, storage revenue increased 6% and 8%, respectively, due to continued strength across the majority of our storage offerings.

[0001571996-22-000031:mdna:167]
[same as prior period, unchanged from 0001571996-22-000021:mdna:160]

[0001571996-22-000031:mdna:168]
From a geographical perspective, net revenue attributable to ISG increased in all regions during the second quarter and first six months of Fiscal 2023.

[0001571996-22-000031:mdna:169]
Operating Income — During the second quarter of Fiscal 2023, ISG operating income as a percentage of net revenue decreased 30 basis points to 11.0%.  The decrease was principally attributable to the impacts of an increase in cost of net revenue and foreign currency exchange rate fluctuations which were not entirely offset by pricing adjustments.  The effect of these impacts was partially mitigated by the favorable impact of a decrease in operating expense as a percentage of revenue.

[0001571996-22-000031:mdna:170]
During the first six months of Fiscal 2023, ISG operating income as a percentage of net revenue increased 80 basis points to 11.3%, primarily due to a decrease in operating expenses as a percentage of revenue that resulted from strong revenue growth and disciplined cost management.  The favorable impact of the decrease in operating expenses as a percentage of revenue was partially offset by the impacts of an increase in cost of net revenue and foreign currency exchange rate fluctuations which were not entirely offset by pricing adjustments, coupled with a shift in revenue mix towards servers and networking.

[0001571996-22-000031:mdna:171]
78

[0001571996-22-000031:mdna:172]
[same as prior period, unchanged from 0001571996-22-000021:mdna:163]

[0001571996-22-000031:mdna:173]
[same as prior period, unchanged from 0001571996-22-000021:mdna:164]

[0001571996-22-000031:mdna:174]
|  | Three Months Ended |  | Six Months Ended |
|  | July 29, 2022 |  | % Change |  | July 30, 2021 |  | July 29, 2022 |  | % Change |  | July 30, 2021 |  |  |  |  |
|  | (in millions, except percentages) |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Commercial | $ | 12,141 |  |  | 15 | % |  | $ | 10,577 |  | $ | 24,112 |  | 18 | % |  | $ | 20,385 |  |  |  |  |
| Consumer | 3,349 |  |  | (9) | % |  | 3,691 |  | 6,965 |  | (3) | % |  | 7,194 |  |  |  |  |
| Total CSG net revenue | $ | 15,490 |  |  | 9 | % |  | $ | 14,268 |  | $ | 31,077 |  | 13 | % |  | $ | 27,579 |  |  |  |  |
| Operating income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| CSG operating income | $ | 978 |  |  | (1) | % |  | $ | 986 |  | $ | 2,093 |  | 1 | % |  | $ | 2,066 |  |  |  |  |
| % of segment net revenue | 6.3 | % |  |  |  | 6.9 | % |  | 6.7 | % |  |  |  | 7.5 | % |  |  |  |  |

[0001571996-22-000031:mdna:175]
Net Revenue — During the second quarter and first six months of Fiscal 2023, CSG net revenue increased 9% and 13%, respectively, primarily driven by an increase in revenue attributable to our commercial offerings, partially offset by a decline in consumer net revenue.

[0001571996-22-000031:mdna:176]
Commercial net revenue increased 15% and 18% during the second quarter and first six months of Fiscal 2023, respectively, principally as a result of an increase in the average selling price of our commercial offerings.

[0001571996-22-000031:mdna:177]
Consumer net revenue decreased 9% and 3% during the second quarter and first six months of Fiscal 2023, respectively, primarily due to a decrease in units sold, partially offset by the effect of an increase in the average selling price of our consumer offerings.

[0001571996-22-000031:mdna:178]
Our average selling prices increased as a result of a shift in mix towards commercial offerings, richer configurations, and continued actions to manage pricing in response to the macroeconomic environment.

[0001571996-22-000031:mdna:179]
From a geographical perspective, net revenue attributable to CSG increased across all regions during the first six months of Fiscal 2023.  During the second quarter of Fiscal 2023, net revenue attributable to CSG increased in the Americas and APJ and was flat in EMEA.

[0001571996-22-000031:mdna:180]
Operating Income — During the second quarter and first six months of Fiscal 2023, CSG operating income as a percentage of net revenue decreased 60 basis points to 6.3% and 80 basis points to 6.7%, respectively, primarily due to the impacts of an increase in cost of net revenue and foreign currency exchange rate fluctuations which were not entirely offset by pricing adjustments, as we balanced profitability with competitive positioning.  The effect of these impacts was partially offset by a decrease in operating expenses as a percentage of revenue as a result of disciplined cost management.

[0001571996-22-000031:mdna:181]
[same as prior period, unchanged from 0001571996-22-000021:mdna:170]

[0001571996-22-000031:mdna:182]
[same as prior period, unchanged from 0001571996-22-000021:mdna:171]

[0001571996-22-000031:mdna:183]
We sell products and services directly to customers and through a variety of sales channels, including retail distribution.  Our accounts receivable, net, was $13.4 billion and $12.9 billion as of July 29, 2022 and January 28, 2022, respectively.  We maintain an allowance for expected credit losses to cover receivables that may be deemed uncollectible.  As of July 29, 2022 and January 28, 2022, the allowance for expected credit losses was $75 million and $90 million, respectively.  Based on our assessment, we believe that we are adequately reserved for expected credit losses.  We will continue to monitor the aging of our accounts receivable and take actions, where necessary, to reduce our exposure to credit losses.

[0001571996-22-000031:mdna:184]
[same as prior period, unchanged from 0001571996-22-000021:mdna:173]

[0001571996-22-000031:mdna:185]
The Company offers or arranges various financing options and services for our customers globally, including through captive financing operations.  DFS originates, collects, and services customer receivables primarily related to the purchase of our product, software, and service solutions.  The Company further strengthens our customer relationships through its flexible consumption models, which enable us to offer our customers the option to pay over time and, in certain cases, based on utilization, to provide them with financial flexibility to meet their changing technological requirements.  New financing originations were $2.3 billion and $1.9 billion for the second quarter of Fiscal 2023 and Fiscal 2022, respectively, and $4.4 billion and $3.8 billion for the first six months of Fiscal 2023 and Fiscal 2022, respectively.

[0001571996-22-000031:mdna:186]
The Company’s leases are generally classified as sales-type leases or operating leases.  Amounts due from lessees under sales-type leases or direct financing leases are recorded as part of financing receivables, with interest income recognized over the contract term.  Upon commencement of sales-type leases, we typically qualify for up-front revenue recognition.  Upon origination of operating leases, we record equipment under operating leases, classified as property, plant, and equipment.  Over the contract term of an operating lease, we recognize rental revenue and depreciation expense, classified as cost of net revenue.

[0001571996-22-000031:mdna:187]
As of July 29, 2022 and January 28, 2022, our financing receivables, net were $10.3 billion and $10.6 billion, respectively.  We maintain an allowance to cover expected financing receivable credit losses and evaluate credit loss expectations based on our total portfolio.  For the second quarter and first six months of both Fiscal 2023 and Fiscal 2022, the principal charge-off rate for our financing receivables portfolio was 0.5%.  The credit quality of our financing receivables has improved in recent years as the mix of high-quality commercial accounts in our portfolio has continued to increase.  We continue to monitor broader economic indicators and their potential impact on future credit loss performance.  We have an extensive process to manage our exposure to customer credit risk, including active management of credit lines and our collection activities.  We also sell selected fixed-term financing receivables without recourse to unrelated third parties on a periodic basis, primarily to manage certain concentrations of customer credit exposure.  Based on our assessment of the customer financing receivables, we believe that we are adequately reserved.

[0001571996-22-000031:mdna:188]
We retain a residual interest in equipment leased under our lease programs.  As of July 29, 2022 and January 28, 2022, the residual interest recorded as part of financing receivables was $150 million and $217 million, respectively.  The decline in residual interest was principally attributable to a corresponding increase in originations of operating leases.  The amount of the residual interest is established at the inception of the lease based upon estimates of the value of the equipment at the end of the lease term using historical studies, industry data, and future value-at-risk demand valuation methods.  On a quarterly basis, we assess the carrying amount of our recorded residual values for impairment.  Generally, expected losses as a result of residual value risk on equipment under lease are not considered to be significant primarily because of the existence of a secondary market with respect to the equipment.  Further, the lease agreement defines applicable return conditions and remedies for non-compliance to ensure that the leased equipment will be in good operating condition upon return.  No expected losses were recorded related to residual assets during the second quarter and first six months of Fiscal 2023 and Fiscal 2022.

[0001571996-22-000031:mdna:189]
As of July 29, 2022 and January 28, 2022, equipment under operating leases, net was $2.0 billion and $1.7 billion, respectively.  We assess the carrying amount of the equipment under operating leases for impairment whenever events or circumstances may indicate that an impairment has occurred.  No material impairment losses were recorded related to such equipment during the second quarter and first six months of Fiscal 2023 and Fiscal 2022.

[0001571996-22-000031:mdna:190]
[same as prior period, unchanged from 0001571996-22-000021:mdna:179]

[0001571996-22-000031:mdna:191]
[same as prior period, unchanged from 0001571996-22-000021:mdna:180]

[0001571996-22-000031:mdna:192]
[same as prior period, unchanged from 0001571996-22-000021:mdna:181]

[0001571996-22-000031:mdna:193]
81

[0001571996-22-000031:mdna:194]
LIQUIDITY, CASH REQUIREMENTS, AND MARKET CONDITIONS

[0001571996-22-000031:mdna:195]
[same as prior period, unchanged from 0001571996-22-000021:mdna:184]

[0001571996-22-000031:mdna:196]
[same as prior period, unchanged from 0001571996-22-000021:mdna:185]

[0001571996-22-000031:mdna:197]
We believe that our current cash and cash equivalents, together with cash that will be provided by future operations and borrowings expected to be available under our revolving credit facility and commercial paper program, will be sufficient over at least the next twelve months and for the foreseeable future thereafter to meet our material cash requirements, including funding of our operations, debt-related payments, capital expenditures, and other corporate needs.

[0001571996-22-000031:mdna:198]
[same as prior period, unchanged from 0001571996-22-000021:mdna:187]

[0001571996-22-000031:mdna:199]
[same as prior period, unchanged from 0001571996-22-000021:mdna:188]

[0001571996-22-000031:mdna:200]
|  | July 29, 2022 |  | January 28, 2022 |
|  | (in millions) |
| Cash and cash equivalents, and available borrowings: |  |  |  |
| Cash and cash equivalents | $ | 5,507 |  |  | $ | 9,477 |  |
| Remaining available borrowings under revolving credit facilities | 4,999 |  |  | 4,969 |  |
| Total cash, cash equivalents, and available borrowings | $ | 10,506 |  |  | $ | 14,446 |  |

[0001571996-22-000031:mdna:201]
During the first six months of Fiscal 2023, cash and cash equivalents decreased by $4.0 billion, primarily driven by return of capital to stockholders, through share repurchases and dividend payments, and capital expenditures.

[0001571996-22-000031:mdna:202]
Our revolving credit facilities as of July 29, 2022 consist of the 2021 Revolving Credit Facility, which has a maximum capacity of $5.0 billion.  Available borrowings under this facility are reduced by draws on the facility and outstanding letters of credit.  As of July 29, 2022, there were no borrowings outstanding under the facility and remaining available borrowings totaled approximately $5.0 billion.  The 2021 Revolving Credit Facility also acts as a backstop to provide liquidity support for our commercial paper program discussed below.

[0001571996-22-000031:mdna:203]
During the second quarter of Fiscal 2023, we established a commercial paper program under which we may issue unsecured notes in a maximum aggregate face amount of $5.0 billion outstanding at any time, with maturities up to 397 days from the date of issue.  As of July 29, 2022, we had no outstanding borrowings under the program.

[0001571996-22-000031:mdna:204]
We may regularly use our available borrowings from the 2021 Revolving Credit Facility and issuances under the commercial paper program on a short-term basis for general corporate purposes.  See Note 7 of the Notes to the Condensed Consolidated Financial Statements included in this report for additional information.

[0001571996-22-000031:mdna:205]
82

[0001571996-22-000031:mdna:206]
[same as prior period, unchanged from 0001571996-22-000021:mdna:192]

[0001571996-22-000031:mdna:207]
[same as prior period, unchanged from 0001571996-22-000021:mdna:193]

[0001571996-22-000031:mdna:208]
|  | July 29, 2022 |  | Change |  | January 28, 2022 |
|  | (in millions) |
| Core debt |  |  |  |  |  |
| Senior Notes | $ | 16,300 |  |  | $ | — |  |  | $ | 16,300 |  |
| Legacy Notes and Debentures | 952 |  |  | — |  |  | 952 |  |
| DFS allocated debt | (1,132) |  |  | 1 |  |  | (1,133) |  |
| Total core debt | 16,120 |  |  | 1 |  |  | 16,119 |  |
| DFS related debt |  |  |  |  |  |
| DFS debt | 9,640 |  |  | (6) |  |  | 9,646 |  |
| DFS allocated debt | 1,132 |  |  | (1) |  |  | 1,133 |  |
| Total DFS related debt | 10,772 |  |  | (7) |  |  | 10,779 |  |
| Other | 311 |  |  | (26) |  |  | 337 |  |
| Total debt, principal amount | 27,203 |  |  | (32) |  |  | 27,235 |  |
| Carrying value adjustments | (269) |  |  | 12 |  |  | (281) |  |
| Total debt, carrying value | $ | 26,934 |  |  | $ | (20) |  |  | $ | 26,954 |  |

[0001571996-22-000031:mdna:209]
As of July 29, 2022, the outstanding principal amount of our debt of $27.2 billion remained effectively unchanged from January 28, 2022.

[0001571996-22-000031:mdna:210]
We define core debt as the total principal amount of our debt, less DFS related debt and other debt.  Our core debt was $16.1 billion as of July 29, 2022 and January 28, 2022.  See Note 7 of the Notes to the Condensed Consolidated Financial Statements included in this report for more information about our debt.

[0001571996-22-000031:mdna:211]
[same as prior period, unchanged from 0001571996-22-000021:mdna:197]

[0001571996-22-000031:mdna:212]
To fund expansion of the DFS business, we balance the use of the securitization and structured financing programs with other sources of liquidity.  We approximate the amount of our debt used to fund the DFS business by applying a 7:1 debt-to-equity ratio to the sum of our financing receivables balance and equipment under our DFS operating leases, net.  The debt-to-equity ratio is based on the underlying credit quality of the assets.  See Note 5 of the Notes to the Condensed Consolidated Financial Statements included in this report for more information about our DFS debt.

[0001571996-22-000031:mdna:213]
[same as prior period, unchanged from 0001571996-22-000021:mdna:199]

[0001571996-22-000031:mdna:214]
We believe we will continue to be able to make our debt principal and interest payments, including the short-term maturities, from existing and expected sources of cash, primarily from operating cash flows.  Cash used for debt principal and interest payments may include short-term borrowings under our commercial paper program or our revolving credit facility.  Under our variable-rate debt, we could experience variations in our future interest expense from potential fluctuations in applicable reference rates, or from possible fluctuations in the level of DFS debt required to meet future demand for customer financing.  There are no scheduled maturities related to our outstanding core debt during Fiscal 2023.  However, at our sole discretion, we may purchase, redeem, prepay, refinance, or otherwise retire any amount of our outstanding indebtedness under the terms of such indebtedness at any time and from time to time, in open market or negotiated transactions with the holders of such indebtedness or otherwise, as we consider appropriate in light of market conditions and other relevant factors.

[0001571996-22-000031:mdna:215]
[same as prior period, unchanged from 0001571996-22-000021:mdna:202]

[0001571996-22-000031:mdna:216]
[same as prior period, unchanged from 0001571996-22-000021:mdna:203]

[0001571996-22-000031:mdna:217]
|  | Six Months Ended |
|  | July 29, 2022 |  | July 30, 2021 |  |  |
|  | (in millions) |
| Net change in cash from: |  |  |  |  |  |
| Operating activities | $ | 455 |  |  | $ | 3,963 |  |  |  |
| Investing activities | (1,498) |  |  | (1,188) |  |  |  |
| Financing activities | (2,752) |  |  | (5,311) |  |  |  |
| Effect of exchange rate changes on cash, cash equivalents, and restricted cash | (194) |  |  | (21) |  |  |  |
| Change in cash, cash equivalents, and restricted cash | $ | (3,989) |  |  | $ | (2,557) |  |  |  |

[0001571996-22-000031:mdna:218]
Cash flows for the six months ended July 30, 2021 are inclusive of cash flows attributable to VMware.  Effective November 1, 2021, as a result of the VMware Spin-off, cash flows ceased to include VMware.  See “Introduction” and Note 1 and Note 2 of the Notes to the Condensed Consolidated Financial Statements included in this report for additional information regarding the VMware Spin-off.

[0001571996-22-000031:mdna:219]
Operating Activities — Cash provided by operating activities was $0.5 billion during the first six months of Fiscal 2023 and reflects continued profitability partially offset by the impact of working capital dynamics.  During the first six months of Fiscal 2022, cash provided by operating activities was $4.0 billion, of which $2.1 billion represents cash provided by operating activities attributable to VMware, and was driven by both strong profitability coupled with favorable working capital dynamics.

[0001571996-22-000031:mdna:220]
Investing Activities — Investing activities primarily consist of cash used to fund capital expenditures for property, plant, and equipment, which includes equipment under DFS operating leases.  Additional activities include capitalized software development costs, strategic investments, and the maturities, sales, and purchases of investments.  During the first six months of Fiscal 2023 and Fiscal 2022, cash used in investing activities was $1.5 billion and $1.2 billion, respectively, and was primarily applied to capital expenditures.

[0001571996-22-000031:mdna:221]
Financing Activities — Financing activities primarily consist of the proceeds and repayments of debt and cash used to repurchase common stock.  Cash used in financing activities was $2.8 billion during the first six months of Fiscal 2023 and primarily consisted of repurchases of common stock, payments to settle employee tax withholding on stock-based compensation, and the payment of quarterly dividends.  Cash used in financing activities of $5.3 billion during the first six months of Fiscal 2022 primarily consisted of debt repayments and repurchases of common stock by our public subsidiaries.

[0001571996-22-000031:mdna:222]
DFS Cash Flow Impacts — DFS offerings are initially funded through cash on hand at the time of origination, most of which is subsequently replaced with asset-backed financing.  For DFS offerings that qualify as sales-type leases, the initial funding of financing receivables is reflected as an impact to cash flows from operations and is largely subsequently offset by cash proceeds from financing.  For DFS operating leases, the initial funding is classified as a capital expenditure and reflected as cash flows used in investing activities.  DFS new financing originations were $4.4 billion and $3.8 billion during the first six months of Fiscal 2023 and Fiscal 2022, respectively.  As of July 29, 2022, DFS had $10.3 billion of total net financing receivables and $2.0 billion of equipment under DFS operating leases, net.

[0001571996-22-000031:mdna:223]
Cash Requirements and Expenditures

[0001571996-22-000031:mdna:224]
Capital Expenditures — We spent $1.5 billion and $1.3 billion during the first six months of Fiscal 2023 and Fiscal 2022, respectively, on property, plant, and equipment and capitalized software development costs, of which the funding of equipment under DFS operating leases totaled $0.5 billion and $0.4 billion, respectively.  Product demand, product mix, the use of contract manufacturers, and ongoing investments in operating and information technology infrastructure influence the level and prioritization of our capital expenditures.  Aggregate capital expenditures for Fiscal 2023 are currently expected to total between $3.1 billion and $3.3 billion, of which approximately $1.1 billion of expenditures are expected to be applied to equipment under DFS operating leases and approximately $0.4 billion to capitalized software development costs.

[0001571996-22-000031:mdna:225]
Repurchases of Common Stock — Effective as of September 23, 2021, our Board of Directors approved a stock repurchase program with no established expiration date under which we are authorized to repurchase up to $5 billion of shares of our Class C Common Stock.  During the first six months of Fiscal 2023, we repurchased approximately 42 million shares of Class C Common Stock under this program for a total purchase price of approximately $2.1 billion.

[0001571996-22-000031:mdna:226]
Dividend Payments — On February 24, 2022, the Company announced that its Board of Directors has adopted a dividend policy under which the Company intends to pay quarterly cash dividends on its common stock at an initial rate of $0.33 per share per fiscal quarter.  During the six months ended July 29, 2022, the Company paid the following dividends:

[0001571996-22-000031:mdna:227]
| Declaration Date |  | Record Date |  | Payment Date |  | Dividend per Share |  | Amount (in millions) |
| February 24, 2022 |  | April 20, 2022 |  | April 29, 2022 |  | $ | 0.33 |  |  | $ | 248 |  |
| June 7, 2022 |  | July 20, 2022 |  | July 29, 2022 |  | $ | 0.33 |  |  | $ | 242 |  |

[0001571996-22-000031:mdna:228]
[same as prior period, unchanged from 0001571996-22-000021:mdna:215]

[0001571996-22-000031:mdna:229]
We utilize several suppliers to manufacture sub-assemblies for our products.  Our efficient supply chain management allows us to enter into flexible and mutually beneficial purchase arrangements with our suppliers in order to minimize inventory risk.  Consistent with industry practice, we acquire raw materials or other goods and services, including product components, by issuing to supplier’s authorizations to purchase based on our projected demand and manufacturing needs.  These purchase orders are typically fulfilled within 30 days and are entered into during the ordinary course of business in order to establish best pricing and continuity of supply for our production.  Purchase orders are not included in purchase obligations, as they typically represent our authorization to purchase rather than binding purchase obligations.

[0001571996-22-000031:mdna:230]
As of July 29, 2022, such purchase obligations were $4.0 billion, $0.5 billion, and $0.8 billion for the remaining six months of Fiscal 2023, Fiscal 2024, and Fiscal 2025 and thereafter, respectively.

[0001571996-22-000031:mdna:231]
[same as prior period, unchanged from 0001571996-22-000021:mdna:218]

[0001571996-22-000031:mdna:232]
[same as prior period, unchanged from 0001571996-22-000021:mdna:219]

[0001571996-22-000031:mdna:233]
[same as prior period, unchanged from 0001571996-22-000021:mdna:220]

[0001571996-22-000031:mdna:234]
[same as prior period, unchanged from 0001571996-22-000021:mdna:221]

[0001571996-22-000031:mdna:235]
[same as prior period, unchanged from 0001571996-22-000021:mdna:222]

[0001571996-22-000031:mdna:236]
[same as prior period, unchanged from 0001571996-22-000021:mdna:223]

[0001571996-22-000031:mdna:237]
As discussed in Note 7 of the Notes to the Condensed Consolidated Financial Statements included in this report, Dell International L.L.C. and EMC Corporation (the “Issuers”), both of which are wholly-owned subsidiaries of Dell Technologies Inc., completed private offerings of multiple series of senior secured notes issued on June 1, 2016, March 20, 2019, and April 9, 2020 (the “Senior Notes”).  In June 2021, the Issuers completed an exchange offer and issued $18.4 billion aggregate principal amount of registered senior notes under the Securities Act of 1933 in exchange for the same principal amount and substantially identical terms of the Senior Notes.  The aggregate principal amount of unregistered Senior Notes remaining outstanding following the settlement of the exchange offer was approximately $0.1 billion.  During Fiscal 2022, the tangible and intangible assets of the Issuers and guarantors that secured obligations under the Senior Notes were released as collateral.  As a result, the Senior Notes became fully unsecured.  In addition, all guarantees of the Senior Notes by subsidiaries of Dell Inc. were released.

[0001571996-22-000031:mdna:238]
Guarantees — The Senior Notes are guaranteed on a joint and several unsecured basis by Dell Technologies Inc. and its wholly-owned subsidiaries, Denali Intermediate, Inc. and Dell Inc. (collectively, the “Guarantors”).

[0001571996-22-000031:mdna:239]
Basis of Preparation of the Summarized Financial Information — The tables below are summarized financial information provided in conformity with Rule 13-01 of the SEC’s Regulation S-X.  The summarized financial information of the Issuers and Guarantors (collectively, the “Obligor Group”) is presented on a combined basis, excluding intercompany balances and transactions between entities in the Obligor Group.  The Obligor Group’s amounts due from, amounts due to, and transactions with Non-Obligor Subsidiaries and VMware, Inc. and its consolidated subsidiaries (the “Related Party”) have been presented separately.  The Obligor Group’s investment balances in Non-Obligor Subsidiaries have been excluded.

[0001571996-22-000031:mdna:240]
[same as prior period, unchanged from 0001571996-22-000021:mdna:227]

[0001571996-22-000031:mdna:241]
|  | Six Months Ended |
|  | July 29, 2022 |
|  | (in millions) |
| Net revenue (a) | $ | 4,966 |  |
| Gross margin (b) | 2,185 |  |
| Operating income | 597 |  |
| Interest and other, net (c) | (1,214) |  |
| Loss before income taxes | (617) |  |
| Net loss attributable to Obligor Group | $ | (439) |  |

[0001571996-22-000031:mdna:242]
[same as prior period, unchanged from 0001571996-22-000021:mdna:229]

[0001571996-22-000031:mdna:243]
(a)  Includes net revenue from services provided and product sales to Non-Obligor Subsidiaries of $440 million and $79 million, respectively.

[0001571996-22-000031:mdna:244]
(b)  Includes cost of net revenue from resale of solutions purchased from Non-Obligor Subsidiaries and the Related Party of $487 million and $264 million, respectively.  Includes costs of net revenue from shared services provided by Non-Obligor Subsidiaries of $315 million.

[0001571996-22-000031:mdna:245]
(c)   Includes interest expense on inter-company loan payables of $631 million.

[0001571996-22-000031:mdna:246]
[same as prior period, unchanged from 0001571996-22-000021:mdna:233]

[0001571996-22-000031:mdna:247]
|  | July 29, 2022 |  | January 28, 2022 |
|  | (in millions) |
| ASSETS |
| Current assets | $ | 3,178 |  |  | $ | 3,106 |  |
| Intercompany receivables | 123 |  |  | 988 |  |
| Due from related party, net | 117 |  |  | 59 |  |
| Short-term intercompany loan receivables | 232 |  |  | — |  |
| Total current assets | 3,650 |  |  | 4,153 |  |
| Due from related party, net | 609 |  |  | 710 |  |
| Goodwill and intangible assets | 15,119 |  |  | 15,399 |  |
| Other non-current assets | 2,812 |  |  | 2,810 |  |
| Total assets | $ | 22,190 |  |  | $ | 23,072 |  |
| LIABILITIES |
| Current liabilities | $ | 5,629 |  |  | $ | 4,625 |  |
| Due to related party | 95 |  |  | 192 |  |
| Total current liabilities | 5,724 |  |  | 4,817 |  |
| Long-term debt | 16,016 |  |  | 17,001 |  |
| Intercompany loan payables | 37,582 |  |  | 37,509 |  |
| Other non-current liabilities | 3,445 |  |  | 3,473 |  |
| Total liabilities | $ | 62,767 |  |  | $ | 62,800 |  |

[0001571996-22-000031:mdna:248]
87
