# DELL note change history — 0001571996-22-000021 → 0001571996-22-000031


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2022-09-01):
[0001571996-22-000031:note_history:1]
The Company has contractual obligations to purchase goods or services, which specify significant terms (including fixed or minimum quantities to be purchased), fixed, minimum, or variable price provisions; and the approximate timing of the transaction.  As of July 29, 2022, such purchase obligations were $4.0 billion, $0.5 billion, and $0.8 billion for the remaining six months of Fiscal 2023, Fiscal 2024, and Fiscal 2025 and thereafter, respectively.
  (was, 2022-06-06, similarity 0.9814):
[0001571996-22-000021:note_history:1]
The Company has contractual obligations to purchase goods or services, which specify significant terms (including fixed or minimum quantities to be purchased), fixed, minimum, or variable price provisions; and the approximate timing of the transaction.  As of April 29, 2022, such purchase obligations were $3.1 billion, $0.4 billion, and $0.8 billion for the remaining nine months of Fiscal 2023, Fiscal 2024, and Fiscal 2025 and thereafter, respectively.

- changed (2022-09-01):
[0001571996-22-000031:note_history:2]
The Company accrues a liability when it believes that it is both probable that a liability has been incurred and that it can reasonably estimate the amount of the loss.  The Company reviews these accruals at least quarterly and adjusts them to reflect ongoing negotiations, settlements, rulings, advice of legal counsel, and other relevant information.  To the extent new information is obtained and the Company’s views on the probable outcomes of claims, suits, assessments, investigations, or legal proceedings change, changes in the Company’s accrued liabilities are recorded in the period in which such a determination is made.  For some matters, the incurrence of a liability is not probable or the amount cannot be reasonably estimated and therefore accruals have not been made.
  (was, 2022-06-06, similarity 0.9846):
[0001571996-22-000021:note_history:2]
The Company accrues a liability when it believes that it is both probable that a liability has been incurred and that it can reasonably estimate the amount of the loss.  The Company reviews these accruals at least quarterly and adjusts them to reflect ongoing negotiations, settlements, rulings, advice of legal counsel, and other relevant information.  To the extent new information is obtained and the Company’s views on the probable outcomes of claims, suits, assessments, investigations, or legal proceedings change, changes in the Company’s accrued liabilities are recorded in the period in which such a determination is made.  For some matters, the amount of liability is not probable or the amount cannot be reasonably estimated and therefore accruals have not been made.

- changed (2022-09-01):
[0001571996-22-000031:note_history:3]
Class Actions Related to VMware, Inc.’s Acquisition of Pivotal Software, Inc. — Two purported stockholders brought putative class action complaints arising out of VMware, Inc.’s acquisition of Pivotal Software, Inc. (“Pivotal”) on December 30, 2019.  The two actions were consolidated in the Delaware Chancery Court into In re: Pivotal Software, Inc. Stockholders Litigation (Civil Action No. 2020-0440-KSJM).  The complaint names as defendants the Company, VMware, Inc., Michael S. Dell, and certain officers of Pivotal.  The plaintiffs generally allege that the defendants breached their fiduciary duties to the former holders of Pivotal Class A Common Stock in connection with VMware, Inc.’s acquisition of Pivotal by allegedly causing Pivotal to enter into a transaction that favored the interests of Pivotal’s controlling stockholders at the expense of such former stockholders.  The parties have reached an agreement to settle the litigation and are seeking the court’s approval of the settlement.
  (was, 2022-06-06, similarity 0.8659):
[0001571996-22-000021:note_history:3]
Class Actions Related to VMware, Inc.’s Acquisition of Pivotal — Two purported stockholders brought putative class action complaints arising out of VMware, Inc.’s acquisition of Pivotal Software, Inc. on December 30, 2019.  The two actions were consolidated in the Delaware Chancery Court into In re: Pivotal Software, Inc. Stockholders Litigation (Civil Action No. 2020-0440-KSJM).  The complaint names as defendants the Company, VMware, Inc., Michael S. Dell, and certain officers of Pivotal.  The plaintiffs generally allege that the defendants breached their fiduciary duties to the former holders of Pivotal Class A Common Stock in connection with VMware, Inc.’s acquisition of Pivotal by allegedly causing Pivotal to enter into a transaction that favored the interests of Pivotal’s controlling stockholders at the expense of such former stockholders.  The parties have reached an agreement to settle the litigation and are seeking the court’s approval of the settlement.

- changed (2022-09-01):
[0001571996-22-000031:note_history:4]
In accordance with the relevant accounting guidance, the Company provides disclosures of matters where it is at least reasonably possible that the Company could experience a material loss exceeding the amounts already accrued for these or other proceedings or matters.  In addition, the Company also discloses matters based on its consideration of other matters and qualitative factors, including the experience of other companies in the industry, and investor, customer, and employee relations considerations.  As of July 29, 2022, the Company does not believe there is a reasonable possibility that a material loss exceeding the amounts already accrued for these or other proceedings or matters has been incurred.  However, since the ultimate resolution of any such proceedings and matters is inherently unpredictable, the Company’s business, financial condition, results of operations, or cash flows could be materially affected in any particular period by unfavorable outcomes in one or more of these proceedings or matters.  Whether the outcome of any claim, suit, assessment, investigation, or legal proceeding, individually or collectively, could have a material adverse effect on the Company’s business, financial condition, results of operations, or cash flows will depend on a number of factors, including the nature, timing, and amount of any associated expenses, amounts paid in settlement, damages, or other remedies or consequences.
  (was, 2022-06-06, similarity 0.9969):
[0001571996-22-000021:note_history:4]
In accordance with the relevant accounting guidance, the Company provides disclosures of matters where it is at least reasonably possible that the Company could experience a material loss exceeding the amounts already accrued for these or other proceedings or matters.  In addition, the Company also discloses matters based on its consideration of other matters and qualitative factors, including the experience of other companies in the industry, and investor, customer, and employee relations considerations.  As of April 29, 2022, the Company does not believe there is a reasonable possibility that a material loss exceeding the amounts already accrued for these or other proceedings or matters has been incurred.  However, since the ultimate resolution of any such proceedings and matters is inherently unpredictable, the Company’s business, financial condition, results of operations, or cash flows could be materially affected in any particular period by unfavorable outcomes in one or more of these proceedings or matters.  Whether the outcome of any claim, suit, assessment, investigation, or legal proceeding, individually or collectively, could have a material adverse effect on the Company’s business, financial condition, results of operations, or cash flows will depend on a number of factors, including the nature, timing, and amount of any associated expenses, amounts paid in settlement, damages, or other remedies or consequences.

- changed (2022-09-01):
[0001571996-22-000031:note_history:5]
Under the Separation and Distribution Agreement described in Note 2 of the Notes to the Condensed Consolidated Financial Statements, Dell Technologies has agreed to indemnify VMware, Inc., each of its subsidiaries and each of their respective directors, officers, and employees from and against all liabilities relating to, arising out of or resulting from, among other matters, the liabilities allocated to Dell Technologies as part of the separation of  Dell Technologies and VMware and their respective businesses as a result of the VMware Spin-off (the “Separation”).  VMware similarly has agreed to indemnify Dell Technologies Inc., each of its subsidiaries and each of their respective directors, officers, and employees from and against all liabilities relating to, arising out of or resulting from, among other matters, the liabilities allocated to VMware as part of the Separation.  Dell Technologies expects VMware to fully perform under the terms of the Separation and Distribution Agreement.
For information on the cross-indemnifications related to the tax matters agreement between the Company and VMware described in Note 2 of the Notes to the Condensed Consolidated Financial Statements effective upon the Separation on November 1, 2021, see Note 2 and Note 16 of the Notes to the Condensed Consolidated Financial Statements.
  (was, 2022-06-06, similarity 0.9996):
[0001571996-22-000021:note_history:5]
Under the Separation and Distribution Agreement described in Note 2 of the Notes to the Condensed Consolidated Financial Statements, Dell Technologies has agreed to indemnify VMware, Inc., each of its subsidiaries and each of their respective directors, officers, and employees from and against all liabilities relating to, arising out of or resulting from, among other matters, the liabilities allocated to Dell Technologies as part of the separation of  Dell Technologies and VMware and their respective businesses as a result of the VMware Spin-off (the “Separation”).  VMware similarly has agreed to indemnify Dell Technologies, Inc., each of its subsidiaries and each of their respective directors, officers, and employees from and against all liabilities relating to, arising out of or resulting from, among other matters, the liabilities allocated to VMware as part of the Separation.  Dell Technologies expects VMware to fully perform under the terms of the Separation and Distribution Agreement.
For information on the cross-indemnifications related to the tax matters agreement between the Company and VMware described in Note 2 of the Notes to the Condensed Consolidated Financial Statements effective upon the Separation on November 1, 2021, see Note 2 and Note 16 of the Notes to the Condensed Consolidated Financial Statements.


## dell:CreditLossFinancialInstrumentLeasesDebtVariableInterestEntitiesAndCustomerReceivablesSalesTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-09-01):
[0001571996-22-000031:note_history:6]
FINANCIAL SERVICES
The Company offers or arranges various financing options and services and alternative payment structures for its customers globally primarily through Dell Financial Services and its affiliates (“DFS”).  The Company also arranges financing for some of its customers in various countries where DFS does not currently operate as a captive enterprise.  The key activities of DFS include originating, collecting, and servicing customer financing arrangements primarily related to the purchase or use of Dell Technologies products and services.  In some cases, DFS also offers financing for the purchase of third-party technology products that complement the Dell Technologies portfolio of products and services.  New financing originations were $2.3 billion and $1.9 billion for the three months ended July 29, 2022 and July 30, 2021, respectively, and $4.4 billion and $3.8 billion for the six months ended July 29, 2022 and July 30, 2021, respectively.
  (was, 2022-06-06, similarity 0.9387):
[0001571996-22-000021:note_history:6]
FINANCIAL SERVICES
The Company offers or arranges various financing options and services and alternative payment structures for its customers globally primarily through Dell Financial Services and its affiliates (“DFS”).  The Company also arranges financing for some of its customers in various countries where DFS does not currently operate as a captive enterprise.  The key activities of DFS include originating, collecting, and servicing customer financing arrangements primarily related to the purchase or use of Dell Technologies products and services.  In some cases, DFS also offers financing for the purchase of third-party technology products that complement the Dell Technologies portfolio of products and services.  New financing originations were $2.1 billion and $1.9 billion for the three months ended April 29, 2022 and April 30, 2021, respectively.

- changed (2022-09-01):
[0001571996-22-000031:note_history:7]
|  | July 29, 2022 |  | January 28, 2022 |
|  | Revolving |  | Fixed-term |  | Total |  | Revolving |  | Fixed-term |  | Total |
|  | (in millions) |
| Financing receivables, net: |  |  |  |  |  |  |  |  |  |  |  |
| Customer receivables, gross (a) | $ | 705 |  |  | $ | 9,638 |  |  | $ | 10,343 |  |  | $ | 750 |  |  | $ | 9,833 |  |  | $ | 10,583 |  |
| Allowances for losses | (91) |  |  | (92) |  |  | (183) |  |  | (102) |  |  | (87) |  |  | (189) |  |
| Customer receivables, net | 614 |  |  | 9,546 |  |  | 10,160 |  |  | 648 |  |  | 9,746 |  |  | 10,394 |  |
| Residual interest | — |  |  | 150 |  |  | 150 |  |  | — |  |  | 217 |  |  | 217 |  |
| Financing receivables, net | $ | 614 |  |  | $ | 9,696 |  |  | $ | 10,310 |  |  | $ | 648 |  |  | $ | 9,963 |  |  | $ | 10,611 |  |
| Short-term | $ | 614 |  |  | $ | 4,246 |  |  | $ | 4,860 |  |  | $ | 648 |  |  | $ | 4,441 |  |  | $ | 5,089 |  |
| Long-term | $ | — |  |  | $ | 5,450 |  |  | $ | 5,450 |  |  | $ | — |  |  | $ | 5,522 |  |  | $ | 5,522 |  |
  (was, 2022-06-06, similarity 0.9943):
[0001571996-22-000021:note_history:7]
|  | April 29, 2022 |  | January 28, 2022 |
|  | Revolving |  | Fixed-term |  | Total |  | Revolving |  | Fixed-term |  | Total |
|  | (in millions) |
| Financing receivables, net: |  |  |  |  |  |  |  |  |  |  |  |
| Customer receivables, gross (a) | $ | 716 |  |  | $ | 9,483 |  |  | $ | 10,199 |  |  | $ | 750 |  |  | $ | 9,833 |  |  | $ | 10,583 |  |
| Allowances for losses | (94) |  |  | (87) |  |  | (181) |  |  | (102) |  |  | (87) |  |  | (189) |  |
| Customer receivables, net | 622 |  |  | 9,396 |  |  | 10,018 |  |  | 648 |  |  | 9,746 |  |  | 10,394 |  |
| Residual interest | — |  |  | 176 |  |  | 176 |  |  | — |  |  | 217 |  |  | 217 |  |
| Financing receivables, net | $ | 622 |  |  | $ | 9,572 |  |  | $ | 10,194 |  |  | $ | 648 |  |  | $ | 9,963 |  |  | $ | 10,611 |  |
| Short-term | $ | 622 |  |  | $ | 4,174 |  |  | $ | 4,796 |  |  | $ | 648 |  |  | $ | 4,441 |  |  | $ | 5,089 |  |
| Long-term | $ | — |  |  | $ | 5,398 |  |  | $ | 5,398 |  |  | $ | — |  |  | $ | 5,522 |  |  | $ | 5,522 |  |

- changed (2022-09-01):
[0001571996-22-000031:note_history:8]
|  | Three Months Ended |
|  | July 29, 2022 |  | July 30, 2021 |
|  | Revolving |  | Fixed-term |  | Total |  | Revolving |  | Fixed-term |  | Total |
|  | (in millions) |
| Allowance for financing receivable losses: |  |  |  |  |  |  |  |  |  |  |  |
| Balances at beginning of period | $ | 94 |  |  | $ | 87 |  |  | $ | 181 |  |  | $ | 139 |  |  | $ | 177 |  |  | $ | 316 |  |
| Charge-offs, net of recoveries | (12) |  |  | (2) |  |  | (14) |  |  | (10) |  |  | (3) |  |  | (13) |  |
| Provision charged to income statement | 9 |  |  | 7 |  |  | 16 |  |  | (3) |  |  | (13) |  |  | (16) |  |
| Balances at end of period | $ | 91 |  |  | $ | 92 |  |  | $ | 183 |  |  | $ | 126 |  |  | $ | 161 |  |  | $ | 287 |  |
  (was, 2022-06-06, similarity 0.9379):
[0001571996-22-000021:note_history:8]
|  | Three Months Ended |
|  | April 29, 2022 |  | April 30, 2021 |
|  | Revolving |  | Fixed-term |  | Total |  | Revolving |  | Fixed-term |  | Total |
|  | (in millions) |
| Allowance for financing receivable losses: |  |  |  |  |  |  |  |  |  |  |  |
| Balances at beginning of period | $ | 102 |  |  | $ | 87 |  |  | $ | 189 |  |  | $ | 148 |  |  | $ | 173 |  |  | $ | 321 |  |
| Charge-offs, net of recoveries | (13) |  |  | (2) |  |  | (15) |  |  | (13) |  |  | (2) |  |  | (15) |  |
| Provision charged to income statement | 5 |  |  | 2 |  |  | 7 |  |  | 4 |  |  | 6 |  |  | 10 |  |
| Balances at end of period | $ | 94 |  |  | $ | 87 |  |  | $ | 181 |  |  | $ | 139 |  |  | $ | 177 |  |  | $ | 316 |  |

- added (2022-09-01):
[0001571996-22-000031:note_history:9]
|  | Six Months Ended |
|  | July 29, 2022 |  | July 30, 2021 |
|  | Revolving |  | Fixed-term |  | Total |  | Revolving |  | Fixed-term |  | Total |
|  | (in millions) |
| Allowance for financing receivable losses: |  |  |  |  |  |  |  |  |  |  |  |
| Balances at beginning of period | $ | 102 |  |  | $ | 87 |  |  | $ | 189 |  |  | $ | 148 |  |  | $ | 173 |  |  | $ | 321 |  |
| Charge-offs, net of recoveries | (25) |  |  | (4) |  |  | (29) |  |  | (23) |  |  | (5) |  |  | (28) |  |
| Provision charged to income statement | 14 |  |  | 9 |  |  | 23 |  |  | 1 |  |  | (7) |  |  | (6) |  |
| Balances at end of period | $ | 91 |  |  | $ | 92 |  |  | $ | 183 |  |  | $ | 126 |  |  | $ | 161 |  |  | $ | 287 |  |

- changed (2022-09-01):
[0001571996-22-000031:note_history:10]
|  | July 29, 2022 |  | January 28, 2022 |
|  | Current |  | Past Due1 — 90 Days |  | Past Due>90 Days |  | Total |  | Current |  | Past Due1 — 90 Days |  | Past Due>90 Days |  | Total |
|  | (in millions) |
| Revolving — DPA | $ | 472 |  |  | $ | 37 |  |  | $ | 13 |  |  | $ | 522 |  |  | $ | 520 |  |  | $ | 40 |  |  | $ | 11 |  |  | $ | 571 |  |
| Revolving — DBC | 164 |  |  | 16 |  |  | 3 |  |  | 183 |  |  | 158 |  |  | 18 |  |  | 3 |  |  | 179 |  |
| Fixed-term — Consumer and Commercial | 9,343 |  |  | 271 |  |  | 24 |  |  | 9,638 |  |  | 9,444 |  |  | 345 |  |  | 44 |  |  | 9,833 |  |
| Total customer receivables, gross | $ | 9,979 |  |  | $ | 324 |  |  | $ | 40 |  |  | $ | 10,343 |  |  | $ | 10,122 |  |  | $ | 403 |  |  | $ | 58 |  |  | $ | 10,583 |  |
  (was, 2022-06-06, similarity 0.9927):
[0001571996-22-000021:note_history:10]
|  | April 29, 2022 |  | January 28, 2022 |
|  | Current |  | Past Due1 — 90 Days |  | Past Due>90 Days |  | Total |  | Current |  | Past Due1 — 90 Days |  | Past Due>90 Days |  | Total |
|  | (in millions) |
| Revolving — DPA | $ | 488 |  |  | $ | 35 |  |  | $ | 12 |  |  | $ | 535 |  |  | $ | 520 |  |  | $ | 40 |  |  | $ | 11 |  |  | $ | 571 |  |
| Revolving — DBC | 164 |  |  | 14 |  |  | 3 |  |  | 181 |  |  | 158 |  |  | 18 |  |  | 3 |  |  | 179 |  |
| Fixed-term — Consumer and Commercial | 8,962 |  |  | 485 |  |  | 36 |  |  | 9,483 |  |  | 9,444 |  |  | 345 |  |  | 44 |  |  | 9,833 |  |
| Total customer receivables, gross | $ | 9,614 |  |  | $ | 534 |  |  | $ | 51 |  |  | $ | 10,199 |  |  | $ | 10,122 |  |  | $ | 403 |  |  | $ | 58 |  |  | $ | 10,583 |  |

- changed (2022-09-01):
[0001571996-22-000031:note_history:11]
Aging is likely to fluctuate as a result of the variability in volume of large transactions entered into over the period, and the administrative processes that accompany those transactions.  Aging is also impacted by the timing of the Dell Technologies fiscal period end date relative to calendar month-end customer payment due dates.  As a result of these factors, fluctuations in aging from period to period do not necessarily indicate a material change in the collectibility of the portfolio.
  (was, 2022-06-06, similarity 0.6747):
[0001571996-22-000021:note_history:11]
Aging is likely to fluctuate as a result of the variability in volume of large transactions entered into over the period, and the administrative processes that accompany those transactions.  Aging is also impacted by the timing of the Dell Technologies

- changed (2022-09-01):
[0001571996-22-000031:note_history:12]
|  | July 29, 2022 |
|  | Fixed-term — Consumer and Commercial |  |  |  |  |  |  |
|  | Fiscal Year of Origination |  |  |  |  |  |  |
|  | 2023 |  | 2022 |  | 2021 |  | 2020 |  | 2019 |  | Years Prior |  | Revolving — DPA |  | Revolving — DBC |  | Total |
|  | (in millions) |
| Higher | $ | 1,785 |  |  | $ | 2,347 |  |  | $ | 1,291 |  |  | $ | 578 |  |  | $ | 109 |  |  | $ | 7 |  |  | $ | 126 |  |  | $ | 46 |  |  | $ | 6,289 |  |
| Mid | 690 |  |  | 773 |  |  | 540 |  |  | 194 |  |  | 47 |  |  | 4 |  |  | 149 |  |  | 57 |  |  | 2,454 |  |
| Lower | 392 |  |  | 458 |  |  | 297 |  |  | 104 |  |  | 19 |  |  | 3 |  |  | 247 |  |  | 80 |  |  | 1,600 |  |
| Total | $ | 2,867 |  |  | $ | 3,578 |  |  | $ | 2,128 |  |  | $ | 876 |  |  | $ | 175 |  |  | $ | 14 |  |  | $ | 522 |  |  | $ | 183 |  |  | $ | 10,343 |  |
  (was, 2022-06-06, similarity 0.9928):
[0001571996-22-000021:note_history:12]
|  | April 29, 2022 |
|  | Fixed-term — Consumer and Commercial |  |  |  |  |  |  |
|  | Fiscal Year of Origination |  |  |  |  |  |  |
|  | 2023 |  | 2022 |  | 2021 |  | 2020 |  | 2019 |  | Years Prior |  | Revolving — DPA |  | Revolving — DBC |  | Total |
|  | (in millions) |
| Higher | $ | 1,223 |  |  | $ | 2,587 |  |  | $ | 1,450 |  |  | $ | 695 |  |  | $ | 145 |  |  | $ | 15 |  |  | $ | 132 |  |  | $ | 46 |  |  | $ | 6,293 |  |
| Mid | 345 |  |  | 866 |  |  | 621 |  |  | 235 |  |  | 64 |  |  | 8 |  |  | 155 |  |  | 57 |  |  | 2,351 |  |
| Lower | 179 |  |  | 505 |  |  | 369 |  |  | 142 |  |  | 29 |  |  | 5 |  |  | 248 |  |  | 78 |  |  | 1,555 |  |
| Total | $ | 1,747 |  |  | $ | 3,958 |  |  | $ | 2,440 |  |  | $ | 1,072 |  |  | $ | 238 |  |  | $ | 28 |  |  | $ | 535 |  |  | $ | 181 |  |  | $ | 10,199 |  |

- changed (2022-09-01):
[0001571996-22-000031:note_history:13]
|  | Three Months Ended |  | Six Months Ended |
|  | July 29, 2022 |  | July 30, 2021 |  | July 29, 2022 |  | July 30, 2021 |
|  | (in millions) |
| Net revenue — products | $ | 219 |  |  | $ | 194 |  |  | $ | 439 |  |  | $ | 424 |  |
| Cost of net revenue — products | 164 |  |  | 142 |  |  | 368 |  |  | 305 |  |
| Gross margin — products | $ | 55 |  |  | $ | 52 |  |  | $ | 71 |  |  | $ | 119 |  |
  (was, 2022-06-06, similarity 0.6763):
[0001571996-22-000021:note_history:13]
|  | Three Months Ended |
|  | April 29, 2022 |  | April 30, 2021 |
|  | (in millions) |
| Net revenue — products | $ | 220 |  |  | $ | 230 |  |
| Cost of net revenue — products | 204 |  |  | 163 |  |
| Gross margin — products | $ | 16 |  |  | $ | 67 |  |

- changed (2022-09-01):
[0001571996-22-000031:note_history:14]
|  | July 29, 2022 |
|  | (in millions) |
| Fiscal 2023 (remaining six months) | $ | 1,329 |  |
| Fiscal 2024 | 1,950 |  |
| Fiscal 2025 | 1,277 |  |
| Fiscal 2026 | 659 |  |
| Fiscal 2027 and beyond | 217 |  |
| Total undiscounted cash flows | 5,432 |  |
| Fixed-term loans | 4,795 |  |
| Revolving loans | 705 |  |
| Less: Unearned income | (589) |  |
| Total customer receivables, gross | $ | 10,343 |  |
  (was, 2022-06-06, similarity 0.6855):
[0001571996-22-000021:note_history:14]
|  | April 29, 2022 |
|  | (in millions) |
| Fiscal 2023 (remaining nine months) | $ | 663 |  |
| Fiscal 2024 | 650 |  |
| Fiscal 2025 | 397 |  |
| Fiscal 2026 | 122 |  |
| Fiscal 2027 and beyond | 32 |  |
| Total | $ | 1,864 |  |

- changed (2022-09-01):
[0001571996-22-000031:note_history:15]
|  | July 29, 2022 |  | January 28, 2022 |
|  | (in millions) |
| Equipment under operating lease, gross | $ | 3,202 |  |  | $ | 2,643 |  |
| Less: Accumulated depreciation | (1,202) |  |  | (935) |  |
| Equipment under operating lease, net | $ | 2,000 |  |  | $ | 1,708 |  |
  (was, 2022-06-06, similarity 0.9806):
[0001571996-22-000021:note_history:15]
|  | April 29, 2022 |  | January 28, 2022 |
|  | (in millions) |
| Equipment under operating lease, gross | $ | 2,942 |  |  | $ | 2,643 |  |
| Less: Accumulated depreciation | (1,076) |  |  | (935) |  |
| Equipment under operating lease, net | $ | 1,866 |  |  | $ | 1,708 |  |

- changed (2022-09-01):
[0001571996-22-000031:note_history:16]
|  | Three Months Ended |  | Six Months Ended |
|  | July 29, 2022 |  | July 30, 2021 |  | July 29, 2022 |  | July 30, 2021 |
|  | (in millions) |
| Income related to lease payments | $ | 253 |  |  | $ | 167 |  |  | $ | 485 |  |  | $ | 323 |  |
| Depreciation expense | $ | 194 |  |  | $ | 127 |  |  | $ | 359 |  |  | $ | 243 |  |
  (was, 2022-06-06, similarity 0.7021):
[0001571996-22-000021:note_history:16]
|  | Three Months Ended |
|  | April 29, 2022 |  | April 30, 2021 |
|  | (in millions) |
| Income related to lease payments | $232 |  | $156 |
| Depreciation expense | $165 |  | $116 |

- added (2022-09-01):
[0001571996-22-000031:note_history:17]
|  | July 29, 2022 |
|  | (in millions) |
| Fiscal 2023 (remaining six months) | $ | 469 |  |
| Fiscal 2024 | 760 |  |
| Fiscal 2025 | 512 |  |
| Fiscal 2026 | 198 |  |
| Fiscal 2027 and beyond | 64 |  |
| Total | $ | 2,003 |  |

- changed (2022-09-01):
[0001571996-22-000031:note_history:18]
|  | July 29, 2022 |  | January 28, 2022 |
| DFS debt | (in millions) |
| DFS U.S. debt: |  |  |  |
| Asset-based financing and securitization facilities | $ | 2,271 |  |  | $ | 3,054 |  |
| Fixed-term securitization offerings | 3,968 |  |  | 3,011 |  |
| Other | 117 |  |  | 135 |  |
| Total DFS U.S. debt | 6,356 |  |  | 6,200 |  |
| DFS international debt: |  |  |  |
| Securitization facility | 694 |  |  | 739 |  |
| Other borrowings | 810 |  |  | 785 |  |
| Note payable | 250 |  |  | 250 |  |
| Dell Bank senior unsecured eurobonds | 1,530 |  |  | 1,672 |  |
| Total DFS international debt | 3,284 |  |  | 3,446 |  |
| Total DFS debt | $ | 9,640 |  |  | $ | 9,646 |  |
| Total short-term DFS debt | $ | 5,565 |  |  | $ | 5,803 |  |
| Total long-term DFS debt | $ | 4,075 |  |  | $ | 3,843 |  |
  (was, 2022-06-06, similarity 0.9932):
[0001571996-22-000021:note_history:18]
|  | April 29, 2022 |  | January 28, 2022 |
| DFS debt | (in millions) |
| DFS U.S. debt: |  |  |  |
| Asset-based financing and securitization facilities | $ | 2,720 |  |  | $ | 3,054 |  |
| Fixed-term securitization offerings | 3,607 |  |  | 3,011 |  |
| Other | 125 |  |  | 135 |  |
| Total DFS U.S. debt | 6,452 |  |  | 6,200 |  |
| DFS international debt: |  |  |  |
| Securitization facility | 730 |  |  | 739 |  |
| Other borrowings | 818 |  |  | 785 |  |
| Note payable | 250 |  |  | 250 |  |
| Dell Bank senior unsecured eurobonds | 1,575 |  |  | 1,672 |  |
| Total DFS international debt | 3,373 |  |  | 3,446 |  |
| Total DFS debt | $ | 9,825 |  |  | $ | 9,646 |  |
| Total short-term DFS debt | $ | 5,907 |  |  | $ | 5,803 |  |
| Total long-term DFS debt | $ | 3,918 |  |  | $ | 3,843 |  |

- changed (2022-09-01):
[0001571996-22-000031:note_history:19]
Asset-Based Financing and Securitization Facilities — The Company maintains separate asset-based financing facilities and a securitization facility in the United States, which are revolving facilities for fixed-term leases and loans and for revolving loans, respectively.  This debt is collateralized solely by the U.S. loan and lease payments and associated equipment in the facilities.  The debt has a variable interest rate and the duration of the debt is based on the terms of the underlying loan and lease payment streams.  As of July 29, 2022, the total debt capacity related to the U.S. asset-based financing and securitization facilities was $5.0 billion.  The Company enters into interest swap agreements to effectively convert a portion of this debt from a floating rate to a fixed rate.  See Note 8 of the Notes to the Condensed Consolidated Financial Statements for additional information about interest rate swaps.
  (was, 2022-06-06, similarity 0.9951):
[0001571996-22-000021:note_history:19]
Asset-Based Financing and Securitization Facilities — The Company maintains separate asset-based financing facilities and a securitization facility in the United States, which are revolving facilities for fixed-term leases and loans and for revolving loans, respectively.  This debt is collateralized solely by the U.S. loan and lease payments and associated equipment in the facilities.  The debt has a variable interest rate and the duration of the debt is based on the terms of the underlying loan and lease payment streams.  As of April 29, 2022, the total debt capacity related to the U.S. asset-based financing and securitization facilities was $4.5 billion.  The Company enters into interest swap agreements to effectively convert a portion of this debt from a floating rate to a fixed rate.  See Note 8 of the Notes to the Condensed Consolidated Financial Statements for additional information about interest rate swaps.

- changed (2022-09-01):
[0001571996-22-000031:note_history:20]
The Company’s U.S. securitization facility for revolving loans is effective through June 25, 2025.  The Company’s two U.S. asset-based financing facilities for fixed-term leases and loans are effective through July 10, 2023 and June 21, 2024, respectively.
  (was, 2022-06-06, similarity 0.9916):
[0001571996-22-000021:note_history:20]
The Company’s U.S. securitization facility for revolving loans is effective through June 25, 2025.  The Company’s two U.S. asset-based financing facilities for fixed-term leases and loans are effective through July 10, 2023 and July 26, 2022, respectively.

- changed (2022-09-01):
[0001571996-22-000031:note_history:21]
The asset-based financing and securitization facilities contain standard structural features related to the performance of the funded receivables, which include defined credit losses, delinquencies, average credit scores, and minimum collection requirements.  In the event one or more of these criteria are not met and the Company is unable to restructure the facility, no further funding of receivables will be permitted and the timing of the Company’s expected cash flows from over-collateralization will be delayed.  As of July 29, 2022, these criteria were met.
  (was, 2022-06-06, similarity 0.9919):
[0001571996-22-000021:note_history:21]
The asset-based financing and securitization facilities contain standard structural features related to the performance of the funded receivables, which include defined credit losses, delinquencies, average credit scores, and minimum collection requirements.  In the event one or more of these criteria are not met and the Company is unable to restructure the facility, no further funding of receivables will be permitted and the timing of the Company’s expected cash flows from over-collateralization will be delayed.  As of April 29, 2022, these criteria were met.

- changed (2022-09-01):
[0001571996-22-000031:note_history:22]
Securitization Facility — The Company maintains a securitization facility in Europe for fixed-term leases and loans.  This facility is effective through December 21, 2022 and had a total debt capacity of $816 million as of July 29, 2022.
  (was, 2022-06-06, similarity 0.962):
[0001571996-22-000021:note_history:22]
Securitization Facility — The Company maintains a securitization facility in Europe for fixed-term leases and loans.  This facility is effective through December 21, 2022 and had a total debt capacity of $840 million as of April 29, 2022.

- changed (2022-09-01):
[0001571996-22-000031:note_history:23]
The securitization facility contains standard structural features related to the performance of the securitized receivables, which include defined credit losses, delinquencies, average credit scores, and minimum collection requirements.  In the event one or more of these criteria are not met and the Company is unable to restructure the program, no further funding of receivables will be permitted and the timing of the Company’s expected cash flows from over-collateralization will be delayed.  As of July 29, 2022, these criteria were met.
  (was, 2022-06-06, similarity 0.9916):
[0001571996-22-000021:note_history:23]
The securitization facility contains standard structural features related to the performance of the securitized receivables, which include defined credit losses, delinquencies, average credit scores, and minimum collection requirements.  In the event one or more of these criteria are not met and the Company is unable to restructure the program, no further funding of receivables will be permitted and the timing of the Company’s expected cash flows from over-collateralization will be delayed.  As of April 29, 2022, these criteria were met.

- changed (2022-09-01):
[0001571996-22-000031:note_history:24]
Other Borrowings — In connection with the Company’s international financing operations, the Company has entered into revolving structured financing debt programs related to its fixed-term lease and loan products sold in Canada, Europe, Australia, and New Zealand.  The Canadian facility, which is collateralized solely by Canadian loan and lease payments and associated equipment, had a total debt capacity of $351 million as of July 29, 2022 and is effective through January 16, 2025.  The European facility, which is collateralized solely by European loan and lease payments and associated equipment, had a total debt capacity of $612 million as of July 29, 2022 and is effective through December 14, 2023.  The Australia and New Zealand facility, which is collateralized solely by Australia and New Zealand loan and lease payments and associated equipment, had a total debt capacity of $315 million as of July 29, 2022 and is effective through April 20, 2023.
  (was, 2022-06-06, similarity 0.6826):
[0001571996-22-000021:note_history:24]
Other Borrowings — In connection with the Company’s international financing operations, the Company has entered into revolving structured financing debt programs related to its fixed-term lease and loan products sold in Canada, Europe, Australia, and New Zealand.  The Canadian facility, which is collateralized solely by Canadian loan and lease payments and associated equipment, had a total debt capacity of $351 million as of April 29, 2022 and is effective through January 16, 2025.  The European facility, which is collateralized solely by European loan and lease payments and associated equipment, had a total debt capacity of $630 million as of April 29, 2022 and is effective through December 14, 2023.  The Australia and New Zealand facility, which is collateralized solely by Australia and New Zealand loan and lease payments and associated equipment, had a total debt capacity of $319 million as of April 29, 2022 and is effective through April 20, 2023.

- added (2022-09-01):
[0001571996-22-000031:note_history:25]
Note Payable — On May 25, 2022, the Company entered into an unsecured credit agreement to fund receivables in Mexico.  As of July 29, 2022, the aggregate principal amount of the note payable was $250 million.  The note bears interest at an annual rate of 4.24% and will mature on May 31, 2024.

- changed (2022-09-01):
[0001571996-22-000031:note_history:26]
Dell Bank Senior Unsecured Eurobonds — On October 17, 2019, Dell Bank International D.A.C. (“Dell Bank”) issued 500 million Euro of 0.625% senior unsecured three year eurobonds due October 2022.  On June 24, 2020, Dell Bank issued 500 million Euro of 1.625% senior unsecured four year eurobonds due June 2024.  On October 27, 2021, Dell Bank issued 500 million Euro of 0.5% senior unsecured five year eurobonds due October 2026.  The issuances of the senior unsecured eurobonds support the expansion of the financing operations in Europe.
  (was, 2022-06-06, similarity 0.999):
[0001571996-22-000021:note_history:26]
Dell Bank Senior Unsecured Eurobonds  — On October 17, 2019, Dell Bank International D.A.C. (“Dell Bank”) issued 500 million Euro of 0.625% senior unsecured three year eurobonds due October 2022.  On June 24, 2020, Dell Bank issued 500 million Euro of 1.625% senior unsecured four year eurobonds due June 2024.  On October 27, 2021, Dell Bank issued 500 million Euro of 0.5% senior unsecured five year eurobonds due October 2026.  The issuance of the senior unsecured eurobonds support the expansion of the financing operations in Europe.

- changed (2022-09-01):
[0001571996-22-000031:note_history:27]
In connection with the asset-based financing facilities, securitization facilities, and fixed-term securitization offerings discussed above, the Company transfers certain U.S. and European lease and loan payments and associated equipment to SPEs that meet the definition of a VIE and are consolidated, along with the associated debt detailed above, into the Condensed Consolidated Financial Statements, as the Company is the primary beneficiary of the VIEs.  The SPEs are bankruptcy-remote legal entities with separate assets and liabilities.  The purpose of the SPEs is to facilitate the funding of customer loan and lease payments and associated equipment in the capital markets.
  (was, 2022-06-06, similarity 0.9762):
[0001571996-22-000021:note_history:27]
In connection with the asset-based financing facilities, securitization facilities, and fixed-term securitization offerings discussed above, the Company transfers certain U.S. and European lease and loan payments and associated equipment to SPEs that meet the definition of a Variable Interest Entity (“VIE”) and are consolidated, along with the associated debt detailed above, into the Condensed Consolidated Financial Statements, as the Company is the primary beneficiary of the VIEs.  The SPEs are bankruptcy-remote legal entities with separate assets and liabilities.  The purpose of the SPEs is to facilitate the funding of customer loan and lease payments and associated equipment in the capital markets.

- changed (2022-09-01):
[0001571996-22-000031:note_history:28]
|  | July 29, 2022 |  | January 28, 2022 |
|  | (in millions) |
| Assets held by consolidated VIEs |  |  |  |
| Other current assets | $ | 574 |  |  | $ | 535 |  |
| Financing receivables, net of allowance |  |  |  |
| Short-term | $ | 3,313 |  |  | $ | 3,368 |  |
| Long-term | $ | 3,181 |  |  | $ | 3,141 |  |
| Property, plant, and equipment, net | $ | 1,069 |  |  | $ | 945 |  |
| Liabilities held by consolidated VIEs |  |  |  |
| Debt, net of unamortized debt issuance costs |  |  |  |
| Short-term | $ | 4,469 |  |  | $ | 4,560 |  |
| Long-term | $ | 2,450 |  |  | $ | 2,235 |  |
  (was, 2022-06-06, similarity 0.991):
[0001571996-22-000021:note_history:28]
|  | April 29, 2022 |  | January 28, 2022 |
|  | (in millions) |
| Assets held by consolidated VIEs |  |  |  |
| Other current assets | $ | 547 |  |  | $ | 535 |  |
| Financing receivables, net of allowance |  |  |  |
| Short-term | $ | 3,376 |  |  | $ | 3,368 |  |
| Long-term | $ | 3,270 |  |  | $ | 3,141 |  |
| Property, plant, and equipment, net | $ | 1,030 |  |  | $ | 945 |  |
| Liabilities held by consolidated VIEs |  |  |  |
| Debt, net of unamortized debt issuance costs |  |  |  |
| Short-term | $ | 4,545 |  |  | $ | 4,560 |  |
| Long-term | $ | 2,500 |  |  | $ | 2,235 |  |

- changed (2022-09-01):
[0001571996-22-000031:note_history:29]
Lease and loan payments and associated equipment transferred via securitization through SPEs were $1.2 billion and $1.3 billion for the three months ended July 29, 2022 and July 30, 2021, respectively, and $2.9 billion and $2.7 billion for the six months ended July 29, 2022 and July 30, 2021, respectively.
  (was, 2022-06-06, similarity 0.7828):
[0001571996-22-000021:note_history:29]
Lease and loan payments and associated equipment transferred via securitization through SPEs were $1.7 billion and $1.4 billion for the three months ended April 29, 2022 and April 30, 2021, respectively.

- changed (2022-09-01):
[0001571996-22-000031:note_history:30]
To manage certain concentrations of customer credit exposure, the Company may sell selected fixed-term customer receivables to unrelated third parties on a periodic basis, without recourse.  The amount of customer receivables sold for this purpose was $425 million and $101 million for the six months ended July 29, 2022 and July 30, 2021, respectively.  The Company’s continuing involvement in these customer receivables is primarily limited to servicing arrangements.
  (was, 2022-06-06, similarity 0.9207):
[0001571996-22-000021:note_history:30]
To manage certain concentrations of customer credit exposure, the Company may sell selected fixed-term customer receivables to unrelated third parties on a periodic basis, without recourse.  The amount of customer receivables sold for this purpose was $148 million and $101 million for the three months ended April 29, 2022 and April 30, 2021, respectively.  The Company’s continuing involvement in these customer receivables is primarily limited to servicing arrangements.

- removed (2022-09-01):
[0001571996-22-000021:note_history:31]
fiscal period end date relative to calendar month-end customer payment due dates.  As a result of these factors, fluctuations in aging from period to period do not necessarily indicate a material change in the collectibility of the portfolio.

- removed (2022-09-01):
[0001571996-22-000021:note_history:32]
|  | April 29, 2022 |
|  | (in millions) |
| Fiscal 2023 (remaining nine months) | $ | 1,876 |  |
| Fiscal 2024 | 1,721 |  |
| Fiscal 2025 | 1,050 |  |
| Fiscal 2026 | 474 |  |
| Fiscal 2027 and beyond | 144 |  |
| Total undiscounted cash flows | 5,265 |  |
| Fixed-term loans | 4,814 |  |
| Revolving loans | 716 |  |
| Less: Unearned income | (596) |  |
| Total customer receivables, gross | $ | 10,199 |  |

- removed (2022-09-01):
[0001571996-22-000021:note_history:33]
Note Payable —On August 7, 2020, the Company entered into two unsecured credit agreements to fund receivables in Mexico.  As of April 29, 2022, the aggregate principal amount of the notes payable was $250 million.  The notes bear interest at an annual rate of 3.37% and will mature on June 1, 2022.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-09-01):
[0001571996-22-000031:note_history:34]
|  | July 29, 2022 |  | January 28, 2022 |
|  | (in millions) |
| Senior Notes: |  |  |  |
| 5.45% due June 2023 | $ | 1,000 |  |  | $ | 1,000 |  |
| 4.00% due July 2024 | 1,000 |  |  | 1,000 |  |
| 5.85% due July 2025 | 1,000 |  |  | 1,000 |  |
| 6.02% due June 2026 | 4,500 |  |  | 4,500 |  |
| 4.90% due October 2026 | 1,750 |  |  | 1,750 |  |
| 6.10% due July 2027 | 500 |  |  | 500 |  |
| 5.30% due October 2029 | 1,750 |  |  | 1,750 |  |
| 6.20% due July 2030 | 750 |  |  | 750 |  |
| 8.10% due July 2036 | 1,000 |  |  | 1,000 |  |
| 3.38% due December 2041 | 1,000 |  |  | 1,000 |  |
| 8.35% due July 2046 | 800 |  |  | 800 |  |
| 3.45% due December 2051 | 1,250 |  |  | 1,250 |  |
| Legacy Notes and Debentures: |  |  |  |
| 7.10% due April 2028 | 300 |  |  | 300 |  |
| 6.50% due April 2038 | 388 |  |  | 388 |  |
| 5.40% due September 2040 | 264 |  |  | 264 |  |
| DFS Debt (Note 5) | 9,640 |  |  | 9,646 |  |
| Other | 311 |  |  | 337 |  |
| Total debt, principal amount | $ | 27,203 |  |  | $ | 27,235 |  |
| Unamortized discount, net of unamortized premium | (128) |  |  | (134) |  |
| Debt issuance costs | (141) |  |  | (147) |  |
| Total debt, carrying value | $ | 26,934 |  |  | $ | 26,954 |  |
| Total short-term debt, carrying value | $ | 6,647 |  |  | $ | 5,823 |  |
| Total long-term debt, carrying value | $ | 20,287 |  |  | $ | 21,131 |  |
  (was, 2022-06-06, similarity 0.9157):
[0001571996-22-000021:note_history:34]
|  | April 29, 2022 |  | January 28, 2022 |
|  | (in millions) |
| Senior Notes: |  |  |  |
| 5.45% due June 2023 | 1,000 |  |  | 1,000 |  |
| 4.00% due July 2024 | 1,000 |  |  | 1,000 |  |
| 5.85% due July 2025 | 1,000 |  |  | 1,000 |  |
| 6.02% due June 2026 | 4,500 |  |  | 4,500 |  |
| 4.90% due October 2026 | 1,750 |  |  | 1,750 |  |
| 6.10% due July 2027 | 500 |  |  | 500 |  |
| 5.30% due October 2029 | 1,750 |  |  | 1,750 |  |
| 6.20% due July 2030 | 750 |  |  | 750 |  |
| 8.10% due July 2036 | 1,000 |  |  | 1,000 |  |
| 3.38% due December 2041 | 1,000 |  |  | 1,000 |  |
| 8.35% due July 2046 | 800 |  |  | 800 |  |
| 3.45% due December 2051 | 1,250 |  |  | 1,250 |  |
| Legacy Notes and Debentures: |  |  |  |
| 7.10% due April 2028 | 300 |  |  | 300 |  |
| 6.50% due April 2038 | 388 |  |  | 388 |  |
| 5.40% due September 2040 | 264 |  |  | 264 |  |
| DFS Debt (Note 5) | 9,825 |  |  | 9,646 |  |
| Other | 320 |  |  | 337 |  |
| Total debt, principal amount | $ | 27,397 |  |  | $ | 27,235 |  |
| Unamortized discount, net of unamortized premium | (131) |  |  | (134) |  |
| Debt issuance costs | (144) |  |  | (147) |  |
| Total debt, carrying value | $ | 27,122 |  |  | $ | 26,954 |  |
| Total short-term debt, carrying value | $ | 5,925 |  |  | $ | 5,823 |  |
| Total long-term debt, carrying value | $ | 21,197 |  |  | $ | 21,131 |  |

- added (2022-09-01):
[0001571996-22-000031:note_history:35]
Commercial Paper Program

- added (2022-09-01):
[0001571996-22-000031:note_history:36]
On July 18, 2022, the Company established a commercial paper program under which the Company may issue unsecured notes in a maximum aggregate face amount of $5.0 billion outstanding at any time, with maturities up to 397 days from the date of issue.  The notes will be sold on customary terms in the U.S. commercial paper market on a private placement basis.  The proceeds of the notes will be used for general corporate purposes.  As of July 29, 2022, the Company had no outstanding borrowings under the commercial paper program.  Subsequent to July 29, 2022, the Company issued and subsequently repaid notes under this program.

- changed (2022-09-01):
[0001571996-22-000031:note_history:37]
Senior Notes — The Company completed private offerings of multiple series of senior notes which were issued on June 1, 2016, June 22, 2016, March 20, 2019, April 9, 2020, and December 13, 2021 in aggregate principal amounts of $20.0 billion, $3.3 billion, $4.5 billion, $2.3 billion, and $2.3 billion respectively (together with the registered senior notes subsequently issued in exchange, the “Senior Notes”).  Interest on these borrowings is payable semiannually.
  (was, 2022-06-06, similarity 0.9035):
[0001571996-22-000021:note_history:37]
Senior Notes — The Company completed private offerings of multiple series of senior notes which were issued on June 1, 2016, June 22, 2016, March 20, 2019, April 9, 2020, and December 13, 2021 in aggregate principal amounts of $20.0 billion, $3.3 billion, $4.5 billion, $2.3 billion, and $2.3 billion respectively (the “Senior Notes”).  Interest on these borrowings is payable semiannually.

- changed (2022-09-01):
[0001571996-22-000031:note_history:38]
In June 2021, Dell International L.L.C. and EMC Corporation, wholly-owned subsidiaries of Dell Technologies Inc. and issuers of the Senior Notes (the “Issuers”), completed offers to exchange any and all outstanding Senior Notes issued on June 1, 2016, March 20, 2019, and April 9, 2020 for senior notes registered under the Securities Act of 1933 having terms substantially identical to the terms of the outstanding Senior Notes.  The Issuers issued $18.4 billion aggregate principal amount of registered Senior Notes in exchange for the same aggregate principal amount of unregistered Senior Notes.  The aggregate principal amount of unregistered Senior Notes remaining outstanding following the settlement of the exchange offers was approximately $0.1 billion.
  (was, 2022-06-06, similarity 0.9876):
[0001571996-22-000021:note_history:38]
In June 2021, Dell International L.L.C. and EMC Corporation, wholly-owned subsidiaries of Dell Technologies and issuers of the Senior Notes (the “Issuers”), completed offers to exchange any and all outstanding Senior Notes issued on June 1, 2016, March 20, 2019, and April 9, 2020 for senior notes registered under the Securities Act of 1933 having terms substantially identical to the terms of the outstanding Senior Notes.  The Issuers issued $18.4 billion aggregate principal amount of registered senior notes in exchange for the same aggregate principal amount of Senior Notes.  The aggregate principal amount of unregistered Senior Notes remaining outstanding following the settlement of the exchange offers was approximately $0.1 billion.

- changed (2022-09-01):
[0001571996-22-000031:note_history:39]
Legacy Notes and Debentures — The Company has outstanding unsecured notes and debentures (collectively, the “Legacy Notes and Debentures”) that were issued by Dell Inc. (“Dell”), a wholly-owned subsidiary of Dell Technologies Inc., prior to the acquisition of Dell by Dell Technologies Inc. in the going-private transaction that closed in October 2013.  Interest on these borrowings is payable semiannually.
  (was, 2022-06-06, similarity 0.8259):
[0001571996-22-000021:note_history:39]
Legacy Notes and Debentures — The Company has outstanding unsecured notes and debentures (collectively, the “Legacy Notes and Debentures”) that were issued by Dell prior to the acquisition of Dell Inc. by Dell Technologies Inc. in the going-private transaction that closed in October 2013.  Interest on these borrowings is payable semiannually.

- changed (2022-09-01):
[0001571996-22-000031:note_history:40]
2021 Revolving Credit Facility — The Company’s revolving credit facility, which was entered into on November 1, 2021 (the “2021 Revolving Credit Facility”), matures on November 1, 2026.  This facility provides the Company with revolving commitments in an aggregate principal amount of $5.0 billion for general corporate purposes, including liquidity support for the Company’s commercial paper program, and includes a letter of credit sub-facility of up to $0.5 billion and a swing-line loan sub-facility of up to $0.5 billion.  The 2021 Revolving Credit Facility also allows the Company to obtain incremental additional commitments on one or more occasions in minimum amounts of $10 million.
  (was, 2022-06-06, similarity 0.9008):
[0001571996-22-000021:note_history:40]
2021 Revolving Credit Facility  — The 2021 Revolving Credit Facility, which was entered into on November 1, 2021, matures on November 1, 2026, This facility provides the Company with revolving commitments in an aggregate principal amount of $5.0 billion for general corporate purposes and includes a letter of credit sub-facility of up to $0.5 billion and a swing-line loan sub-facility of up to $0.5 billion.  The 2021 Revolving Credit Facility also allows the Company to obtain incremental additional commitments on one or more occasions in minimum amounts of $10 million.

- added (2022-09-01):
[0001571996-22-000031:note_history:41]
Borrowings under the 2021 Revolving Credit Facility bear interest at a rate per annum equal to an applicable margin plus, at the borrowers’ option, either (a) the specified London Interbank Offered Rate (“LIBOR”) or (b) a base rate.  The margin applicable to LIBOR and base rate borrowings varies based upon the Company’s existing date ratings.  The base rate is calculated based upon the greatest of the specified prime rate, the specified federal reserve bank rate, or LIBOR plus 1%.

- changed (2022-09-01):
[0001571996-22-000031:note_history:42]
As of July 29, 2022, available borrowings under the 2021 Revolving Credit Facility totaled $5.0 billion.
  (was, 2022-06-06, similarity 0.9626):
[0001571996-22-000021:note_history:42]
As of April 29, 2022, available borrowings under the 2021 Revolving Credit Facility totaled $5.0 billion.

- changed (2022-09-01):
[0001571996-22-000031:note_history:43]
Covenants — The credit agreement governing the 2021 Revolving Credit Facility and the indentures governing the Senior Notes and the Legacy Notes and Debentures impose various limitations, subject to exceptions, on creating certain liens and entering into sale and lease-back transactions.  The foregoing credit agreement and indentures contain customary events of default, including failure to make required payments, failure to comply with covenants, and the occurrence of certain events of bankruptcy and insolvency.  The 2021 Revolving Credit Facility is also subject to an interest coverage ratio covenant that is tested at the end of each fiscal quarter with respect to the Company’s preceding four fiscal quarters.  The Company was in compliance with this financial covenant as of July 29, 2022.
  (was, 2022-06-06, similarity 0.9752):
[0001571996-22-000021:note_history:43]
Covenants — The credit agreement governing the 2021 Revolving Credit Facility and the indentures governing the Senior Notes and the Legacy Notes and Debentures variously impose limitations, subject to exceptions, on creating certain liens and entering into sale and lease-back transactions.  The foregoing credit agreement and indentures contain customary events of default, including failure to make required payments, failure to comply with covenants, and the occurrence of certain events of bankruptcy and insolvency.  The 2021 Revolving Credit Facility is also subject to an interest coverage ratio covenant that is tested at the end of each fiscal quarter with respect to the Company’s preceding four fiscal quarters.  The Company was in compliance with this financial covenant as of April 29, 2022.

- changed (2022-09-01):
[0001571996-22-000031:note_history:44]
The following table presents the aggregate future maturities of the Company’s debt as of July 29, 2022 for the periods indicated:
  (was, 2022-06-06, similarity 0.968):
[0001571996-22-000021:note_history:44]
The following tables presents the aggregate future maturities of the Company’s debt as of April 29, 2022 for the periods indicated:

- changed (2022-09-01):
[0001571996-22-000031:note_history:45]
|  | Maturities by Fiscal Year |
|  | 2023 (remaining six months) |  | 2024 |  | 2025 |  | 2026 |  | 2027 |  | Thereafter |  | Total |
|  | (in millions) |
| Senior Notes | $ | — |  |  | $ | 1,000 |  |  | $ | 1,000 |  |  | $ | 1,000 |  |  | $ | 6,250 |  |  | $ | 7,050 |  |  | $ | 16,300 |  |
| Legacy Notes and Debentures | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 952 |  |  | 952 |  |
| DFS Debt | 3,538 |  |  | 3,027 |  |  | 2,245 |  |  | 263 |  |  | 565 |  |  | 2 |  |  | 9,640 |  |
| Other | 21 |  |  | 161 |  |  | 107 |  |  | 20 |  |  | 1 |  |  | 1 |  |  | 311 |  |
| Total maturities, principal amount | 3,559 |  |  | 4,188 |  |  | 3,352 |  |  | 1,283 |  |  | 6,816 |  |  | 8,005 |  |  | 27,203 |  |
| Associated carrying value adjustments | (3) |  |  | (7) |  |  | (10) |  |  | (8) |  |  | (54) |  |  | (187) |  |  | (269) |  |
| Total maturities, carrying value amount | $ | 3,556 |  |  | $ | 4,181 |  |  | $ | 3,342 |  |  | $ | 1,275 |  |  | $ | 6,762 |  |  | $ | 7,818 |  |  | $ | 26,934 |  |
  (was, 2022-06-06, similarity 0.9955):
[0001571996-22-000021:note_history:45]
|  | Maturities by Fiscal Year |
|  | 2023 (remaining nine months) |  | 2024 |  | 2025 |  | 2026 |  | 2027 |  | Thereafter |  | Total |
|  | (in millions) |
| Senior Notes | $ | — |  |  | $ | 1,000 |  |  | $ | 1,000 |  |  | $ | 1,000 |  |  | $ | 6,250 |  |  | $ | 7,050 |  |  | $ | 16,300 |  |
| Legacy Notes and Debentures | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 952 |  |  | 952 |  |
| DFS Debt | 5,201 |  |  | 2,612 |  |  | 1,294 |  |  | 165 |  |  | 550 |  |  | 3 |  |  | 9,825 |  |
| Other | 23 |  |  | 165 |  |  | 109 |  |  | 20 |  |  | 1 |  |  | 2 |  |  | 320 |  |
| Total maturities, principal amount | 5,224 |  |  | 3,777 |  |  | 2,403 |  |  | 1,185 |  |  | 6,801 |  |  | 8,007 |  |  | 27,397 |  |
| Associated carrying value adjustments | (5) |  |  | (6) |  |  | (9) |  |  | (8) |  |  | (56) |  |  | (191) |  |  | (275) |  |
| Total maturities, carrying value amount | $ | 5,219 |  |  | $ | 3,771 |  |  | $ | 2,394 |  |  | $ | 1,177 |  |  | $ | 6,745 |  |  | $ | 7,816 |  |  | $ | 27,122 |  |

- removed (2022-09-01):
[0001571996-22-000021:note_history:46]
The Company may conduct borrowings under the 2021 Revolving Credit Facility through London Interbank Offered Rate (“LIBOR”) borrowings or Base Rate Loan borrowings.  LIBOR borrowings bear interest at a rate per annum equal to the LIBOR, plus an applicable rate that varies based upon the Company’s existing debt ratings (the “applicable rate”).  Base Rate Loan borrowings bear interest at a rate per annum equal to the base rate plus the applicable rate.  The base rate is calculated based upon the greatest of the specified prime rate, the specified federal reserve bank rate, or LIBOR plus 1%.


## us-gaap:ScheduleOfCarryingValuesAndEstimatedFairValuesOfDebtInstrumentsTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-09-01):
[0001571996-22-000031:note_history:47]
|  | July 29, 2022 |  | January 28, 2022 |
|  | Carrying Value |  | Fair Value |  | Carrying Value |  | Fair Value |
|  | (in billions) |
| Senior Notes | $ | 16.2 |  |  | $ | 16.7 |  |  | $ | 16.1 |  |  | $ | 18.5 |  |
| Legacy Notes and Debentures | $ | 0.8 |  |  | $ | 1.0 |  |  | $ | 0.8 |  |  | $ | 1.1 |  |
  (was, 2022-06-06, similarity 0.9484):
[0001571996-22-000021:note_history:47]
|  | April 29, 2022 |  | January 28, 2022 |
|  | Carrying Value |  | Fair Value |  | Carrying Value |  | Fair Value |
|  | (in billions) |
| Senior Notes | $ | 16.1 |  |  | $ | 16.7 |  |  | $ | 16.1 |  |  | $ | 18.5 |  |
| Legacy Notes and Debentures | $ | 0.8 |  |  | $ | 1.0 |  |  | $ | 0.8 |  |  | $ | 1.1 |  |


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-09-01):
[0001571996-22-000031:note_history:48]
|  | July 29, 2022 |  | January 28, 2022 |
| DFS debt | (in millions) |
| DFS U.S. debt: |  |  |  |
| Asset-based financing and securitization facilities | $ | 2,271 |  |  | $ | 3,054 |  |
| Fixed-term securitization offerings | 3,968 |  |  | 3,011 |  |
| Other | 117 |  |  | 135 |  |
| Total DFS U.S. debt | 6,356 |  |  | 6,200 |  |
| DFS international debt: |  |  |  |
| Securitization facility | 694 |  |  | 739 |  |
| Other borrowings | 810 |  |  | 785 |  |
| Note payable | 250 |  |  | 250 |  |
| Dell Bank senior unsecured eurobonds | 1,530 |  |  | 1,672 |  |
| Total DFS international debt | 3,284 |  |  | 3,446 |  |
| Total DFS debt | $ | 9,640 |  |  | $ | 9,646 |  |
| Total short-term DFS debt | $ | 5,565 |  |  | $ | 5,803 |  |
| Total long-term DFS debt | $ | 4,075 |  |  | $ | 3,843 |  |
  (was, 2022-06-06, similarity 0.9932):
[0001571996-22-000021:note_history:48]
|  | April 29, 2022 |  | January 28, 2022 |
| DFS debt | (in millions) |
| DFS U.S. debt: |  |  |  |
| Asset-based financing and securitization facilities | $ | 2,720 |  |  | $ | 3,054 |  |
| Fixed-term securitization offerings | 3,607 |  |  | 3,011 |  |
| Other | 125 |  |  | 135 |  |
| Total DFS U.S. debt | 6,452 |  |  | 6,200 |  |
| DFS international debt: |  |  |  |
| Securitization facility | 730 |  |  | 739 |  |
| Other borrowings | 818 |  |  | 785 |  |
| Note payable | 250 |  |  | 250 |  |
| Dell Bank senior unsecured eurobonds | 1,575 |  |  | 1,672 |  |
| Total DFS international debt | 3,373 |  |  | 3,446 |  |
| Total DFS debt | $ | 9,825 |  |  | $ | 9,646 |  |
| Total short-term DFS debt | $ | 5,907 |  |  | $ | 5,803 |  |
| Total long-term DFS debt | $ | 3,918 |  |  | $ | 3,843 |  |

- changed (2022-09-01):
[0001571996-22-000031:note_history:49]
|  | July 29, 2022 |  | January 28, 2022 |
|  | (in millions) |
| Senior Notes: |  |  |  |
| 5.45% due June 2023 | $ | 1,000 |  |  | $ | 1,000 |  |
| 4.00% due July 2024 | 1,000 |  |  | 1,000 |  |
| 5.85% due July 2025 | 1,000 |  |  | 1,000 |  |
| 6.02% due June 2026 | 4,500 |  |  | 4,500 |  |
| 4.90% due October 2026 | 1,750 |  |  | 1,750 |  |
| 6.10% due July 2027 | 500 |  |  | 500 |  |
| 5.30% due October 2029 | 1,750 |  |  | 1,750 |  |
| 6.20% due July 2030 | 750 |  |  | 750 |  |
| 8.10% due July 2036 | 1,000 |  |  | 1,000 |  |
| 3.38% due December 2041 | 1,000 |  |  | 1,000 |  |
| 8.35% due July 2046 | 800 |  |  | 800 |  |
| 3.45% due December 2051 | 1,250 |  |  | 1,250 |  |
| Legacy Notes and Debentures: |  |  |  |
| 7.10% due April 2028 | 300 |  |  | 300 |  |
| 6.50% due April 2038 | 388 |  |  | 388 |  |
| 5.40% due September 2040 | 264 |  |  | 264 |  |
| DFS Debt (Note 5) | 9,640 |  |  | 9,646 |  |
| Other | 311 |  |  | 337 |  |
| Total debt, principal amount | $ | 27,203 |  |  | $ | 27,235 |  |
| Unamortized discount, net of unamortized premium | (128) |  |  | (134) |  |
| Debt issuance costs | (141) |  |  | (147) |  |
| Total debt, carrying value | $ | 26,934 |  |  | $ | 26,954 |  |
| Total short-term debt, carrying value | $ | 6,647 |  |  | $ | 5,823 |  |
| Total long-term debt, carrying value | $ | 20,287 |  |  | $ | 21,131 |  |
  (was, 2022-06-06, similarity 0.9157):
[0001571996-22-000021:note_history:49]
|  | April 29, 2022 |  | January 28, 2022 |
|  | (in millions) |
| Senior Notes: |  |  |  |
| 5.45% due June 2023 | 1,000 |  |  | 1,000 |  |
| 4.00% due July 2024 | 1,000 |  |  | 1,000 |  |
| 5.85% due July 2025 | 1,000 |  |  | 1,000 |  |
| 6.02% due June 2026 | 4,500 |  |  | 4,500 |  |
| 4.90% due October 2026 | 1,750 |  |  | 1,750 |  |
| 6.10% due July 2027 | 500 |  |  | 500 |  |
| 5.30% due October 2029 | 1,750 |  |  | 1,750 |  |
| 6.20% due July 2030 | 750 |  |  | 750 |  |
| 8.10% due July 2036 | 1,000 |  |  | 1,000 |  |
| 3.38% due December 2041 | 1,000 |  |  | 1,000 |  |
| 8.35% due July 2046 | 800 |  |  | 800 |  |
| 3.45% due December 2051 | 1,250 |  |  | 1,250 |  |
| Legacy Notes and Debentures: |  |  |  |
| 7.10% due April 2028 | 300 |  |  | 300 |  |
| 6.50% due April 2038 | 388 |  |  | 388 |  |
| 5.40% due September 2040 | 264 |  |  | 264 |  |
| DFS Debt (Note 5) | 9,825 |  |  | 9,646 |  |
| Other | 320 |  |  | 337 |  |
| Total debt, principal amount | $ | 27,397 |  |  | $ | 27,235 |  |
| Unamortized discount, net of unamortized premium | (131) |  |  | (134) |  |
| Debt issuance costs | (144) |  |  | (147) |  |
| Total debt, carrying value | $ | 27,122 |  |  | $ | 26,954 |  |
| Total short-term debt, carrying value | $ | 5,925 |  |  | $ | 5,823 |  |
| Total long-term debt, carrying value | $ | 21,197 |  |  | $ | 21,131 |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-09-01):
[0001571996-22-000031:note_history:50]
The following table presents the aggregate future maturities of the Company’s debt as of July 29, 2022 for the periods indicated:
  (was, 2022-06-06, similarity 0.968):
[0001571996-22-000021:note_history:50]
The following tables presents the aggregate future maturities of the Company’s debt as of April 29, 2022 for the periods indicated:

- changed (2022-09-01):
[0001571996-22-000031:note_history:51]
|  | Maturities by Fiscal Year |
|  | 2023 (remaining six months) |  | 2024 |  | 2025 |  | 2026 |  | 2027 |  | Thereafter |  | Total |
|  | (in millions) |
| Senior Notes | $ | — |  |  | $ | 1,000 |  |  | $ | 1,000 |  |  | $ | 1,000 |  |  | $ | 6,250 |  |  | $ | 7,050 |  |  | $ | 16,300 |  |
| Legacy Notes and Debentures | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 952 |  |  | 952 |  |
| DFS Debt | 3,538 |  |  | 3,027 |  |  | 2,245 |  |  | 263 |  |  | 565 |  |  | 2 |  |  | 9,640 |  |
| Other | 21 |  |  | 161 |  |  | 107 |  |  | 20 |  |  | 1 |  |  | 1 |  |  | 311 |  |
| Total maturities, principal amount | 3,559 |  |  | 4,188 |  |  | 3,352 |  |  | 1,283 |  |  | 6,816 |  |  | 8,005 |  |  | 27,203 |  |
| Associated carrying value adjustments | (3) |  |  | (7) |  |  | (10) |  |  | (8) |  |  | (54) |  |  | (187) |  |  | (269) |  |
| Total maturities, carrying value amount | $ | 3,556 |  |  | $ | 4,181 |  |  | $ | 3,342 |  |  | $ | 1,275 |  |  | $ | 6,762 |  |  | $ | 7,818 |  |  | $ | 26,934 |  |
  (was, 2022-06-06, similarity 0.9955):
[0001571996-22-000021:note_history:51]
|  | Maturities by Fiscal Year |
|  | 2023 (remaining nine months) |  | 2024 |  | 2025 |  | 2026 |  | 2027 |  | Thereafter |  | Total |
|  | (in millions) |
| Senior Notes | $ | — |  |  | $ | 1,000 |  |  | $ | 1,000 |  |  | $ | 1,000 |  |  | $ | 6,250 |  |  | $ | 7,050 |  |  | $ | 16,300 |  |
| Legacy Notes and Debentures | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 952 |  |  | 952 |  |
| DFS Debt | 5,201 |  |  | 2,612 |  |  | 1,294 |  |  | 165 |  |  | 550 |  |  | 3 |  |  | 9,825 |  |
| Other | 23 |  |  | 165 |  |  | 109 |  |  | 20 |  |  | 1 |  |  | 2 |  |  | 320 |  |
| Total maturities, principal amount | 5,224 |  |  | 3,777 |  |  | 2,403 |  |  | 1,185 |  |  | 6,801 |  |  | 8,007 |  |  | 27,397 |  |
| Associated carrying value adjustments | (5) |  |  | (6) |  |  | (9) |  |  | (8) |  |  | (56) |  |  | (191) |  |  | (275) |  |
| Total maturities, carrying value amount | $ | 5,219 |  |  | $ | 3,771 |  |  | $ | 2,394 |  |  | $ | 1,177 |  |  | $ | 6,745 |  |  | $ | 7,816 |  |  | $ | 27,122 |  |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2022-09-01):
[0001571996-22-000031:note_history:52]
RELATED PARTY TRANSACTIONS 
VMware is considered to be a related party of the Company as a result of Michael Dell’s ownership interest in both Dell Technologies and VMware as well as Mr. Dell’s continued service as Chairman and Chief Executive Officer of Dell Technologies and as Chairman of the Board of VMware, Inc.  See Note 1 and Note 2 of the Notes to the Condensed Consolidated Financial Statements for more information about the VMware Spin-off.
  (was, 2022-06-06, similarity 0.9087):
[0001571996-22-000021:note_history:52]
RELATED PARTY TRANSACTIONS 
Effective upon the completion of the VMware Spin-off, VMware is considered to be a related party of the Company.  The related party relationship is a result of Michael Dell’s ownership interest in both Dell Technologies and VMware as well as Mr. Dell’s continued service as Chairman and Chief Executive Officer of Dell Technologies and as Chairman of the Board of VMware, Inc.  See Note 1 and Note 2 of the Notes to the Condensed Consolidated Financial Statements for more information about the VMware Spin-off.

- changed (2022-09-01):
[0001571996-22-000031:note_history:53]
•Dell Technologies procures products and services from VMware for its internal use.  For the three and six months ended July 29, 2022 and July 30, 2021, costs incurred associated with products and services purchased from VMware for internal use were immaterial.
  (was, 2022-06-06, similarity 0.6335):
[0001571996-22-000021:note_history:53]
•Dell Technologies sells and leases products and sells services to VMware.  For the three months ended April 29, 2022 and April 30, 2021, revenue recognized from sales of services to VMware was immaterial.

- added (2022-09-01):
[0001571996-22-000031:note_history:54]
•Dell Technologies sells and leases products and sells services to VMware.  For the three and six months ended July 29, 2022 and July 30, 2021, revenue recognized from sales of services to VMware was immaterial.

- changed (2022-09-01):
[0001571996-22-000031:note_history:55]
•Dell Technologies and VMware also enter into joint marketing, sales, and branding arrangements, for which both parties may incur costs.  For the three and six months ended July 29, 2022 and July 30, 2021, consideration received from VMware for joint marketing, sales, and branding arrangements was immaterial.
  (was, 2022-06-06, similarity 0.7356):
[0001571996-22-000021:note_history:55]
•Dell Technologies and VMware also enter into joint marketing, sales, and branding arrangements, for which both parties may incur costs.  For the three months ended April 29, 2022 and April 30, 2021, consideration received from VMware for joint marketing, sales, and branding arrangements was immaterial.

- changed (2022-09-01):
[0001571996-22-000031:note_history:56]
•Dell Technologies and VMware enter into agreements to collaborate on technology projects in which one party pays the corresponding party for services or the reimbursement of costs.  For the three and six months ended July 29, 2022 and July 30, 2021, collaborative technology projects were immaterial.
  (was, 2022-06-06, similarity 0.7622):
[0001571996-22-000021:note_history:56]
•Dell Technologies and VMware enter into agreements to collaborate on technology projects in which one party pays the corresponding party for services or the reimbursement of costs.  For the three months ended April 29, 2022 and April 30, 2021, collaborative technology projects were immaterial.

- changed (2022-09-01):
[0001571996-22-000031:note_history:57]
•Dell Technologies provides support services and support from Dell Technologies personnel to VMware in certain geographic regions where VMware does not have an established legal entity.  These employees are managed by VMware but Dell Technologies incurs the costs for these such services.  The costs incurred by Dell Technologies on VMware’s behalf to these employees are charged to VMware.  For the three and six months ended July 29, 2022 and July 30, 2021, costs associated with such seconded employees were immaterial.
  (was, 2022-06-06, similarity 0.8396):
[0001571996-22-000021:note_history:57]
•Dell Technologies provides support services and support from Dell Technologies personnel to VMware in certain geographic regions where VMware does not have an established legal entity.  These employees are managed by VMware but Dell Technologies incurs the costs for these such services.  The costs incurred by Dell Technologies on VMware’s behalf to these employees are charged to VMware.  For the three months ended April 29, 2022 and April 30, 2021, costs associated with such seconded employees were immaterial.

- changed (2022-09-01):
[0001571996-22-000031:note_history:58]
•Dell Technologies and VMware entered into a transition services agreement in connection with the VMware Spin-off to provide various support services including investment advisory services, certain support services from Dell Technologies personnel, and other transitional services.  Costs associated with this agreement were immaterial for the three and six months ended July 29, 2022.
  (was, 2022-06-06, similarity 0.9426):
[0001571996-22-000021:note_history:58]
•Dell Technologies and VMware entered into a transition services agreement in connection with the VMware Spin-off to provide various support services including investment advisory services, certain support services from Dell Technologies personnel, and other transitional services.  Costs associated with this agreement were immaterial for the three months ended April 29, 2022.

- added (2022-09-01):
[0001571996-22-000031:note_history:59]
|  |  |  | Three Months Ended |  | Six Months Ended |
|  | Classification |  | July 29, 2022 |  | July 30, 2021 |  | July 29, 2022 |  | July 30, 2021 |
|  |  |  | (in millions) |
| Sales and leases of products to VMware | Net revenue - products |  | $ | 35 |  |  | $ | 31 |  |  | $ | 81 |  |  | $ | 78 |  |
| Purchase of VMware products for resale | Cost of net revenue - products |  | $ | 426 |  |  | $ | 387 |  |  | $ | 681 |  |  | $ | 706 |  |
| Purchase of VMware services for resale | Cost of net revenue - services |  | $ | 762 |  |  | $ | 616 |  |  | $ | 1,471 |  |  | $ | 1,194 |  |

- changed (2022-09-01):
[0001571996-22-000031:note_history:60]
|  | Classification |  | July 29, 2022 |  | January 28, 2022 |
|  |  |  | (in millions) |
| Deferred costs related to VMware products and services for resale | Other current assets |  | $ | 2,652 |  |  | $ | 2,571 |  |
| Deferred costs related to VMware products and services for resale | Other non-current assets |  | $ | 2,166 |  |  | $ | 2,311 |  |
  (was, 2022-06-06, similarity 0.9333):
[0001571996-22-000021:note_history:60]
|  | Classification | April 29, 2022 |  | January 28, 2022 |
|  |  | (in millions) |
| Deferred costs related to VMware products and services for resale | Other current assets | $ | 2,493 |  |  | $ | 2,571 |  |
| Deferred costs related to VMware products and services for resale | Other non-current assets | $ | 2,060 |  |  | $ | 2,311 |  |

- added (2022-09-01):
[0001571996-22-000031:note_history:61]
Net receipts from VMware pursuant to the Tax Agreements were immaterial during the three and six months ended July 29, 2022 and July 30, 2021, and primarily relate to VMware’s portion of the Transition Tax, federal income taxes on Dell Technologies’ consolidated tax return, and state tax payments for combined states.

- added (2022-09-01):
[0001571996-22-000031:note_history:62]
As a result of the activity under the Tax Agreements with VMware, amounts due from VMware were $570 million and $621 million as of July 29, 2022 and January 28, 2022, respectively, primarily related to VMware’s estimated tax obligation resulting from the Transition Tax.  The 2017 Tax Cuts and Jobs Act included a deferral election for an eight-year installment payment method on the Transition Tax.  Dell Technologies expects VMware to pay the remainder of its Transition Tax over a period of three years.

- changed (2022-09-01):
[0001571996-22-000031:note_history:63]
Indemnification — Upon consummation of the VMware Spin-off, Dell Technologies recorded net income tax indemnification receivables from VMware related to certain income tax liabilities for which Dell Technologies is jointly and severally liable, but for which it is indemnified by VMware under the Tax Matters Agreement.  The amounts that VMware may be obligated to pay Dell Technologies could vary depending on the outcome of certain unresolved tax matters, which may not be resolved for several years.  The net receivable as of July 29, 2022 and January 28, 2022 was $154 million and$144 million, respectively.
  (was, 2022-06-06, similarity 0.9538):
[0001571996-22-000021:note_history:63]
Indemnification — Upon consummation of the VMware Spin-off, Dell Technologies recorded net income tax indemnification receivables from VMware related to certain income tax liabilities for which Dell Technologies is jointly and severally liable, but for which it is indemnified by VMware under the Tax Matters Agreement.  The amounts that VMware may be obligated to pay Dell Technologies could vary depending on the outcome of certain unresolved tax matters, which may not be resolved for several years.  The net receivable as of April 29, 2022 was $147 million.

- changed (2022-09-01):
[0001571996-22-000031:note_history:64]
|  | July 29, 2022 |  | January 28, 2022 |
|  | (in millions) |
| Due from related party, net, current (a) | $ | 195 |  |  | $ | 131 |  |
| Due from related party, net, non-current (b) | $ | 609 |  |  | $ | 710 |  |
| Due to related party, current (c) | $ | 1,269 |  |  | $ | 1,414 |  |
  (was, 2022-06-06, similarity 0.9457):
[0001571996-22-000021:note_history:64]
|  | April 29, 2022 |  | January 28, 2022 |
|  | (in millions) |
| Due from related party, net, current (a) | $ | 131 |  |  | $ | 131 |  |
| Due from related party, net, non-current (b) | $ | 713 |  |  | $ | 710 |  |
| Due to related party, current (c) | $ | 622 |  |  | $ | 1,414 |  |

- changed (2022-09-01):
[0001571996-22-000031:note_history:65]
(b)  Amounts due from related party, non-current consists of non-current portion of net receivables from VMware under the Tax Agreements.
  (was, 2022-06-06, similarity 0.9891):
[0001571996-22-000021:note_history:65]
(b)  Amounts in due from related party, non-current consists of non-current portion of net receivables from VMware under the Tax Agreements.

- changed (2022-09-01):
[0001571996-22-000031:note_history:66]
(c)  Amounts due to related party, current includes amounts due to VMware which are generally settled in cash within 60 days of each quarter-end.
  (was, 2022-06-06, similarity 0.9896):
[0001571996-22-000021:note_history:66]
(c)  Amounts in due to related party, current includes amounts due to VMware which are generally settled in cash within 60 days of each quarter-end.

- removed (2022-09-01):
[0001571996-22-000021:note_history:67]
•Dell Technologies procures products and services from VMware for its internal use.  For the three months ended April 29, 2022 and April 30, 2021, cost incurred associated with products and services purchased from VMware for internal use was immaterial.

- removed (2022-09-01):
[0001571996-22-000021:note_history:68]
|  |  |  | Three Months Ended |  |  |  |  |  |
|  | Classification |  | April 29, 2022 |  | April 30, 2021 |  |  |  |  |  |
|  |  |  | (in millions) |  |  |  |
| Sales and leases of products to VMware | Net revenue - products |  | 46 |  |  | 47 |  |  |  |  |  |  |
| Purchase of VMware products for resale | Cost of net revenue - products |  | 255 |  |  | 319 |  |  |  |  |  |  |
| Purchase of VMware services for resale | Cost of net revenue - services |  | 709 |  |  | 578 |  |  |  |  |  |  |

- removed (2022-09-01):
[0001571996-22-000021:note_history:69]
Net payments made to VMware pursuant to the Tax Agreements were immaterial during the three months ended April 29, 2022 and April 30, 2021, and relate to VMware’s portion of federal income taxes on Dell Technologies’ consolidated tax return as well as state tax payments for combined states.

- removed (2022-09-01):
[0001571996-22-000021:note_history:70]
As a result of the activity under the Tax Agreements with VMware, amounts due from VMware were $630 million and $621 million as of April 29, 2022 and January 28, 2022, respectively, primarily related to VMware’s estimated tax obligation resulting from the Transition Tax.  The 2017 Tax Cuts and Jobs Act included a deferral election for an eight-year installment payment method on the Transition Tax.  Dell Technologies expects VMware to pay the remainder of its Transition Tax over a period of four years.


## us-gaap:ScheduleOfRelatedPartyTransactionsTableTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- added (2022-09-01):
[0001571996-22-000031:note_history:71]
|  |  |  | Three Months Ended |  | Six Months Ended |
|  | Classification |  | July 29, 2022 |  | July 30, 2021 |  | July 29, 2022 |  | July 30, 2021 |
|  |  |  | (in millions) |
| Sales and leases of products to VMware | Net revenue - products |  | $ | 35 |  |  | $ | 31 |  |  | $ | 81 |  |  | $ | 78 |  |
| Purchase of VMware products for resale | Cost of net revenue - products |  | $ | 426 |  |  | $ | 387 |  |  | $ | 681 |  |  | $ | 706 |  |
| Purchase of VMware services for resale | Cost of net revenue - services |  | $ | 762 |  |  | $ | 616 |  |  | $ | 1,471 |  |  | $ | 1,194 |  |

- changed (2022-09-01):
[0001571996-22-000031:note_history:72]
|  | Classification |  | July 29, 2022 |  | January 28, 2022 |
|  |  |  | (in millions) |
| Deferred costs related to VMware products and services for resale | Other current assets |  | $ | 2,652 |  |  | $ | 2,571 |  |
| Deferred costs related to VMware products and services for resale | Other non-current assets |  | $ | 2,166 |  |  | $ | 2,311 |  |
  (was, 2022-06-06, similarity 0.9333):
[0001571996-22-000021:note_history:72]
|  | Classification | April 29, 2022 |  | January 28, 2022 |
|  |  | (in millions) |
| Deferred costs related to VMware products and services for resale | Other current assets | $ | 2,493 |  |  | $ | 2,571 |  |
| Deferred costs related to VMware products and services for resale | Other non-current assets | $ | 2,060 |  |  | $ | 2,311 |  |

- changed (2022-09-01):
[0001571996-22-000031:note_history:73]
|  | July 29, 2022 |  | January 28, 2022 |
|  | (in millions) |
| Due from related party, net, current (a) | $ | 195 |  |  | $ | 131 |  |
| Due from related party, net, non-current (b) | $ | 609 |  |  | $ | 710 |  |
| Due to related party, current (c) | $ | 1,269 |  |  | $ | 1,414 |  |
  (was, 2022-06-06, similarity 0.9457):
[0001571996-22-000021:note_history:73]
|  | April 29, 2022 |  | January 28, 2022 |
|  | (in millions) |
| Due from related party, net, current (a) | $ | 131 |  |  | $ | 131 |  |
| Due from related party, net, non-current (b) | $ | 713 |  |  | $ | 710 |  |
| Due to related party, current (c) | $ | 622 |  |  | $ | 1,414 |  |

- changed (2022-09-01):
[0001571996-22-000031:note_history:74]
(b)  Amounts due from related party, non-current consists of non-current portion of net receivables from VMware under the Tax Agreements.
  (was, 2022-06-06, similarity 0.9891):
[0001571996-22-000021:note_history:74]
(b)  Amounts in due from related party, non-current consists of non-current portion of net receivables from VMware under the Tax Agreements.

- changed (2022-09-01):
[0001571996-22-000031:note_history:75]
(c)  Amounts due to related party, current includes amounts due to VMware which are generally settled in cash within 60 days of each quarter-end.
  (was, 2022-06-06, similarity 0.9896):
[0001571996-22-000021:note_history:75]
(c)  Amounts in due to related party, current includes amounts due to VMware which are generally settled in cash within 60 days of each quarter-end.

- removed (2022-09-01):
[0001571996-22-000021:note_history:76]
|  |  |  | Three Months Ended |  |  |  |  |  |
|  | Classification |  | April 29, 2022 |  | April 30, 2021 |  |  |  |  |  |
|  |  |  | (in millions) |  |  |  |
| Sales and leases of products to VMware | Net revenue - products |  | 46 |  |  | 47 |  |  |  |  |  |  |
| Purchase of VMware products for resale | Cost of net revenue - products |  | 255 |  |  | 319 |  |  |  |  |  |  |
| Purchase of VMware services for resale | Cost of net revenue - services |  | 709 |  |  | 578 |  |  |  |  |  |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2022-09-01):
[0001571996-22-000031:note_history:77]
|  | Three Months Ended |  | Six Months Ended |
|  | July 29, 2022 |  | July 30, 2021 |  | July 29, 2022 |  | July 30, 2021 |  |  |
|  | (in millions) |
| Net revenue: |  |  |  |  |  |  |  |  |  |
| Infrastructure Solutions Group: |  |  |  |  |  |  |  |  |  |
| Servers and networking | $ | 5,209 |  |  | $ | 4,480 |  |  | $ | 10,257 |  |  | $ | 8,620 |  |  |  |
| Storage | 4,327 |  |  | 4,070 |  |  | 8,564 |  |  | 7,963 |  |  |  |
| Total ISG net revenue | $ | 9,536 |  |  | $ | 8,550 |  |  | $ | 18,821 |  |  | $ | 16,583 |  |  |  |
| Client Solutions Group: |  |  |  |  |  |  |  |  |  |
| Commercial | $ | 12,141 |  |  | $ | 10,577 |  |  | $ | 24,112 |  |  | $ | 20,385 |  |  |  |
| Consumer | 3,349 |  |  | 3,691 |  |  | 6,965 |  |  | 7,194 |  |  |  |
| Total CSG net revenue | $ | 15,490 |  |  | $ | 14,268 |  |  | $ | 31,077 |  |  | $ | 27,579 |  |  |  |
  (was, 2022-06-06, similarity 0.7713):
[0001571996-22-000021:note_history:77]
|  |  |  | Three Months Ended |
|  |  |  |  |  | April 29, 2022 |  | April 30, 2021 |  |  |
|  |  |  |  |  | (in millions) |
| Net revenue: |  |  |  |  |  |  |  |  |  |
| Infrastructure Solutions Group: |  |  |  |  |  |  |  |  |  |
| Servers and networking |  |  |  |  | $ | 5,048 |  |  | $ | 4,140 |  |  |  |
| Storage |  |  |  |  | 4,237 |  |  | 3,893 |  |  |  |
| Total ISG net revenue |  |  |  |  | $ | 9,285 |  |  | $ | 8,033 |  |  |  |
| Client Solutions Group: |  |  |  |  |  |  |  |  |  |
| Commercial |  |  |  |  | $ | 11,971 |  |  | $ | 9,808 |  |  |  |
| Consumer |  |  |  |  | 3,616 |  |  | 3,503 |  |  |  |
| Total CSG net revenue |  |  |  |  | $ | 15,587 |  |  | $ | 13,311 |  |  |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2022-09-01):
[0001571996-22-000031:note_history:78]
|  | Three Months Ended |  | Six Months Ended |
|  | July 29, 2022 |  | July 30, 2021 |  | July 29, 2022 |  | July 30, 2021 |
|  | (in millions) |
| Deferred revenue: |  |  |  |  |  |  |  |
| Deferred revenue at beginning of period | $ | 27,403 |  |  | $ | 26,282 |  |  | $ | 27,573 |  |  | $ | 25,592 |  |
| Revenue deferrals | 5,572 |  |  | 5,281 |  |  | 10,547 |  |  | 10,560 |  |
| Revenue recognized | (4,950) |  |  | (4,740) |  |  | (9,930) |  |  | (9,329) |  |
| Other (a) | — |  |  | (155) |  |  | (165) |  |  | (155) |  |
| Deferred revenue at end of period | $ | 28,025 |  |  | $ | 26,668 |  |  | $ | 28,025 |  |  | $ | 26,668 |  |
| Short-term deferred revenue | $ | 14,724 |  |  | $ | 13,765 |  |  | $ | 14,724 |  |  | $ | 13,765 |  |
| Long-term deferred revenue | $ | 13,301 |  |  | $ | 12,903 |  |  | $ | 13,301 |  |  | $ | 12,903 |  |
  (was, 2022-06-06, similarity 0.7603):
[0001571996-22-000021:note_history:78]
|  | Three Months Ended |
|  | April 29, 2022 |  | April 30, 2021 |
|  | (in millions) |
| Deferred revenue: |  |  |  |
| Deferred revenue at beginning of period | $ | 27,573 |  |  | $ | 25,592 |  |
| Revenue deferrals | 4,975 |  |  | 5,279 |  |
| Revenue recognized | (4,980) |  |  | (4,589) |  |
| Other (a) | (165) |  |  | — |  |
| Deferred revenue at end of period | $ | 27,403 |  |  | $ | 26,282 |  |
| Short-term deferred revenue | $ | 14,329 |  |  | $ | 13,641 |  |
| Long-term deferred revenue | $ | 13,074 |  |  | $ | 12,641 |  |

- added (2022-09-01):
[0001571996-22-000031:note_history:79]
(a)    For the six months ended July 29, 2022, Other represents the reclassification of deferred revenue to accrued and other liabilities.  For the three and six months ended July 30, 2021, Other consists of divested deferred revenue from the sale of Boomi.

- changed (2022-09-01):
[0001571996-22-000031:note_history:80]
Remaining Performance Obligations — Remaining performance obligations represent the aggregate amount of the transaction price allocated to performance obligations not delivered, or partially undelivered, as of the end of the reporting period.  Remaining performance obligations include deferred revenue plus unbilled amounts not yet recorded in deferred revenue.  The value of the transaction price allocated to remaining performance obligations as of July 29, 2022 was approximately $41 billion.  The Company expects to recognize approximately 61% of remaining performance obligations as revenue in the next twelve months, and the remainder thereafter.
  (was, 2022-06-06, similarity 0.993):
[0001571996-22-000021:note_history:80]
Remaining Performance Obligations — Remaining performance obligations represent the aggregate amount of the transaction price allocated to performance obligations not delivered, or partially undelivered, as of the end of the reporting period.  Remaining performance obligations include deferred revenue plus unbilled amounts not yet recorded in deferred revenue.  The value of the transaction price allocated to remaining performance obligations as of April 29, 2022 was approximately $42 billion.  The Company expects to recognize approximately 62% of remaining performance obligations as revenue in the next twelve months, and the remainder thereafter.

- removed (2022-09-01):
[0001571996-22-000021:note_history:81]
(a)    Other represents the reclassification of deferred revenue to accrued and other liabilities.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- changed (2022-09-01):
[0001571996-22-000031:note_history:82]
SUBSEQUENT EVENTS There were no known events occurring after July 29, 2022 and up until the date of issuance of this report that would materially affect the information presented herein.
  (was, 2022-06-06, similarity 0.97):
[0001571996-22-000021:note_history:82]
SUBSEQUENT EVENTS There were no known events occurring after April 29, 2022 and up until the date of the issuance of this report that would materially affect the information presented herein.
