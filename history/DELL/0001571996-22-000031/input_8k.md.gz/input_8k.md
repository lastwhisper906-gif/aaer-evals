# DELL 8-K — 0001571996-22-000028 filed 2022-08-25

## item codes, every 8-K on or before 2022-09-01

- 2022-08-25 0001571996-22-000028 — 2.02, 9.01
- 2022-07-18 0001193125-22-196334 — 2.03, 8.01
- 2022-06-29 0001571996-22-000025 — 3.03, 5.03, 5.07, 8.01, 9.01
- 2022-05-26 0001571996-22-000013 — 2.02, 9.01
- 2022-02-24 0001571996-22-000004 — 2.02, 8.01, 9.01
- 2021-12-20 0001193125-21-362482 — 8.01, 9.01
- 2021-12-15 0001193125-21-357927 — 1.01, 2.03, 9.01
- 2021-12-07 0001193125-21-349218 — 8.01, 9.01
- 2021-11-23 0001571996-21-000060 — 2.02, 9.01
- 2021-11-05 0001571996-21-000057 — 1.02, 2.01, 7.01, 8.01, 9.01 — amendment, the index does not say of what
- 2021-11-01 0001571996-21-000052 — 8.01, 9.01
- 2021-11-01 0001193125-21-315488 — 1.01, 1.02, 2.01, 8.01, 9.01
- 2021-10-21 0001193125-21-304052 — 8.01, 9.01
- 2021-10-19 0001571996-21-000050 — 8.01, 9.01
- 2021-10-07 0001193125-21-294210 — 8.01, 9.01
- 2021-09-30 0001571996-21-000047 — 5.02
- 2021-09-27 0001571996-21-000045 — 8.01
- 2021-09-23 0001193125-21-280190 — 7.01, 8.01, 9.01
- 2021-09-20 0001193125-21-276810 — 7.01, 9.01
- 2021-08-26 0001571996-21-000037 — 2.02, 9.01
- 2021-07-01 0001571996-21-000034 — 3.02
- 2021-06-24 0001571996-21-000031 — 5.07
- 2021-06-24 0001193125-21-197644 — 7.01, 9.01
- 2021-06-16 0001571996-21-000029 — 5.02
- 2021-05-27 0001571996-21-000019 — 2.02, 9.01
- 2021-05-03 0001571996-21-000010 — 8.01, 9.01
- 2021-04-14 0001193125-21-116271 — 1.01, 7.01, 9.01
- 2021-02-25 0001571996-21-000003 — 2.02, 9.01
- 2021-02-18 0001193125-21-047844 — 1.01, 2.03, 9.01
- 2020-11-24 0001571996-20-000048 — 2.02, 9.01
- 2020-08-27 0001571996-20-000041 — 2.02, 9.01
- 2020-07-02 0001571996-20-000037 — 5.07
- 2020-05-28 0001571996-20-000028 — 2.02, 9.01
- 2020-04-09 0001193125-20-102602 — 1.01, 2.03, 9.01
- 2020-04-08 0001571996-20-000021 — 5.02
- 2020-04-03 0001571996-20-000019 — 8.01, 9.01
- 2020-03-26 0001571996-20-000015 — 7.01
- 2020-02-27 0001571996-20-000009 — 2.02, 8.01, 9.01
- 2020-02-18 0001571996-20-000005 — 8.01, 9.01
- 2020-01-09 0001571996-20-000002 — 3.02
- 2020-01-06 0001193125-20-002200 — 3.02
- 2019-12-13 0001193125-19-313947 — 3.02
- 2019-12-10 0001571996-19-000052 — 5.02
- 2019-12-02 0001571996-19-000044 — 5.02, 7.01, 9.01
- 2019-11-26 0001571996-19-000042 — 2.02, 9.01
- 2019-09-23 0001193125-19-252192 — 1.01, 2.03, 9.01
- 2019-08-29 0001571996-19-000036 — 2.02, 9.01
- 2019-08-22 0001193125-19-226939 — 7.01, 8.01, 9.01
- 2019-07-11 0001571996-19-000032 — 5.02, 5.07, 9.01
- 2019-07-03 0001571996-19-000030 — 3.02
- 2019-06-27 0001571996-19-000028 — 3.02
- 2019-05-30 0001571996-19-000021 — 2.02, 9.01
- 2019-04-02 0001571996-19-000010 — 5.02
- 2019-03-21 0001193125-19-082281 — 1.01, 1.02, 2.03, 9.01
- 2019-03-19 0001571996-19-000005 — 5.02, 9.01
- 2019-03-14 0001193125-19-074935 — 1.01, 2.03, 9.01
- 2019-03-07 0001193125-19-066045 — 8.01, 9.01
- 2019-02-28 0001571996-19-000002 — 2.02, 9.01
- 2018-12-28 0001193125-18-360943 — 1.01, 1.02, 3.01, 3.03, 5.02, 5.03, 7.01, 8.01, 9.01
- 2018-12-21 0001193125-18-356324 — 1.01, 2.03, 9.01
- 2018-12-14 0001193125-18-349469 — 8.01
- 2018-12-11 0001193125-18-346958 — 5.07, 8.01, 9.01
- 2018-11-29 0001571996-18-000041 — 2.02, 9.01
- 2018-11-28 0001571996-18-000037 — 7.01, 8.01, 9.01
- 2018-11-26 0001193125-18-333967 — 8.01, 9.01
- 2018-11-15 0001193125-18-328110 — 1.01, 9.01 — amendment of 0001193125-18-327222
- 2018-11-15 0001193125-18-327222 — 1.01, 7.01, 9.01
- 2018-10-03 0001193125-18-291390 — 8.01
- 2018-09-06 0001571996-18-000029 — 2.02, 9.01
- 2018-08-06 0001571996-18-000027 — 8.01, 9.01
- 2018-07-02 0001193125-18-210339 — 1.01, 7.01, 9.01
- 2018-06-28 0001571996-18-000024 — 5.07
- 2018-06-04 0001571996-18-000019 — 2.02, 9.01
- 2018-05-17 0001571996-18-000016 — 7.01
- 2018-04-26 0001571996-18-000009 — 7.01, 9.01
- 2018-03-08 0001193125-18-074168 — 2.02, 9.01
- 2018-02-02 0001193125-18-029947 — 7.01, 9.01
- 2017-12-07 0001571996-17-000042 — 2.02, 9.01
- 2017-10-24 0001571996-17-000037 — 1.01, 2.03, 9.01
- 2017-09-15 0001571996-17-000027 — 5.02
- 2017-09-07 0001571996-17-000017 — 2.02, 9.01
- 2017-08-24 0001571996-17-000014 — 8.01
- 2017-06-29 0001571996-17-000011 — 3.03, 5.07, 8.01, 9.01
- 2017-06-08 0001193125-17-197638 — 2.02, 9.01
- 2017-03-30 0001193125-17-102794 — 8.01
- 2017-03-30 0001193125-17-102777 — 2.02, 9.01
- 2017-03-09 0001193125-17-076981 — 1.01, 2.03, 9.01
- 2017-01-17 0001193125-17-011125 — 8.01
- 2016-12-15 0001193125-16-793722 — 8.01
- 2016-12-08 0001193125-16-787976 — 2.02, 9.01
- 2016-11-10 0001193125-16-765964 — 1.02, 8.01
- 2016-11-04 0001193125-16-760249 — 8.01
- 2016-09-13 0001193125-16-708600 — 3.02
- 2016-09-09 0001193125-16-706567 — 1.01, 1.02, 2.01, 2.03, 3.02, 3.03, 5.02, 9.01
- 2016-09-07 0001193125-16-703370 — 3.03, 5.07, 7.01, 8.01, 9.01
- 2016-09-06 0001193125-16-702057 — 2.02, 9.01
- 2016-08-31 0001193125-16-697268 — 8.01, 9.01
- 2016-08-26 0001193125-16-692921 — 8.01, 9.01
- 2016-07-11 0001193125-16-645610 — 8.01
- 2016-07-05 0001193125-16-641679 — 8.01
- 2016-06-22 0001193125-16-629055 — 1.01, 2.03, 8.01, 9.01
- 2016-06-21 0001193125-16-627071 — 8.01, 9.01
- 2016-06-10 0001193125-16-618483 — 2.02, 9.01
- 2016-06-09 0001193125-16-617893 — 8.01, 9.01

## late-filing notifications on or before 2022-09-01

- none on or before 2022-09-01

## item 2.02 — earnings release, exhibit 99.1

[0001571996-22-000028:8k_2_02:1]
EX-99.1
2
exhibit991earnings8kq2fy23.htm
EX-99.1

[0001571996-22-000028:8k_2_02:2]
Document

[0001571996-22-000028:8k_2_02:3]
Exhibit 99.1

[0001571996-22-000028:8k_2_02:4]
Dell Technologies Announces Second Quarter Fiscal 2023 Financial Results

[0001571996-22-000028:8k_2_02:5]
News summary

[0001571996-22-000028:8k_2_02:6]
•Record second quarter revenue of $26.4 billion, up 9%, driven by continued growth across client and infrastructure business units

[0001571996-22-000028:8k_2_02:7]
•Operating income up 25% at $1.3 billion, and non-GAAP operating income up 4% at $2.0 billion

[0001571996-22-000028:8k_2_02:8]
•Diluted earnings per share of $0.68 and non-GAAP diluted earnings per share of $1.68

[0001571996-22-000028:8k_2_02:9]
ROUND ROCK, Texas — August 25, 2022

[0001571996-22-000028:8k_2_02:10]
Full story

[0001571996-22-000028:8k_2_02:11]
Dell Technologies (NYSE: DELL) announces financial results for its fiscal 2023 second quarter. Revenue was a second quarter record of $26.4 billion, up 9%, driven by growth across Client Solutions Group (CSG) and Infrastructure Solutions Group (ISG). Operating income was $1.3 billion, up 25%, representing 4.8% of revenue, and non-GAAP operating income was $2.0 billion, up 4%, representing 7.4% of revenue. Net income from continuing operations was $506 million and non-GAAP net income was $1.3 billion. Diluted earnings per share was $0.68, and non-GAAP diluted earnings per share was $1.68.

[0001571996-22-000028:8k_2_02:12]
1

[0001571996-22-000028:8k_2_02:13]
Second Quarter Fiscal 2023 Financial Results

[0001571996-22-000028:8k_2_02:14]
|  | Three Months Ended |  |  |  | Six Months Ended |  |  |
|  | July 29, 2022 |  | July 30, 2021 |  | Change |  | July 29, 2022 |  | July 30, 2021 |  | Change |
|  | (in millions, except per share amounts and percentages; unaudited) |
| Total net revenue | $ | 26,425 |  |  | $ | 24,191 |  |  | 9% |  | $ | 52,541 |  |  | $ | 46,781 |  |  | 12% |
| Operating income | $ | 1,270 |  |  | $ | 1,017 |  |  | 25% |  | $ | 2,820 |  |  | $ | 2,004 |  |  | 41% |
| Net income from continuing operations | $ | 506 |  |  | $ | 629 |  |  | (20)% |  | $ | 1,575 |  |  | $ | 1,288 |  |  | 22% |
| Earnings per share - diluted | $ | 0.68 |  |  | $ | 0.80 |  |  | (15)% |  | $ | 2.06 |  |  | $ | 1.65 |  |  | 25% |
| Non-GAAP net revenue | $ | 26,425 |  |  | $ | 24,199 |  |  | 9% |  | $ | 52,541 |  |  | $ | 46,797 |  |  | 12% |
| Non-GAAP operating income | $ | 1,952 |  |  | $ | 1,868 |  |  | 4% |  | $ | 4,087 |  |  | $ | 3,638 |  |  | 12% |
| Non-GAAP net income | $ | 1,266 |  |  | $ | 1,166 |  |  | 9% |  | $ | 2,700 |  |  | $ | 2,221 |  |  | 22% |
| Non-GAAP earnings per share - diluted | $ | 1.68 |  |  | $ | 1.48 |  |  | 14% |  | $ | 3.52 |  |  | $ | 2.83 |  |  | 24% |

[0001571996-22-000028:8k_2_02:15]
Information about Dell Technologies’ use of non-GAAP financial information is provided under “Non-GAAP Financial Measures” below.  All comparisons in this press release are year-over-year unless otherwise noted.

[0001571996-22-000028:8k_2_02:16]
Operating segments summary

[0001571996-22-000028:8k_2_02:17]
Client Solutions Group delivered second quarter record revenue of $15.5 billion, up 9% year-over-year. Commercial revenue was $12.1 billion, a 15% increase year-over-year, and Consumer revenue was $3.3 billion, down 9% year-over-year. Focus on the commercial market continues to drive differentiated share results, with share gains in 34 of the last 38 quarters.1 Operating income was $1.0 billion, or approximately 6.3% of Client Solutions Group revenue.

[0001571996-22-000028:8k_2_02:18]
Key areas of innovation:

[0001571996-22-000028:8k_2_02:19]
•Precision 7865 Tower delivers on 25 years of commercial workstation innovation, supporting demanding, multi-application workloads.

[0001571996-22-000028:8k_2_02:20]
•Alienware m15 R5 launches as the most powerful 17-inch AMD Advantage™ gaming laptop.

[0001571996-22-000028:8k_2_02:21]
•New commercial devices for hybrid work are available, including the Latitude 9330, the world’s first laptop with a collaboration touchpad that lets users mute, turn video on/off, screen share and chat.

[0001571996-22-000028:8k_2_02:22]
•This year’s rollout of premium laptops continues with the launch of the XPS 13 and reveal of the versatile XPS 2-in-1.

[0001571996-22-000028:8k_2_02:23]
Infrastructure Solutions Group delivered record second quarter revenue of $9.5 billion, up 12% and its sixth consecutive quarter of year-over-year growth. Storage revenue was $4.3 billion, up 6%, with growth across the portfolio and demand strength in high-end storage and our marquee mid-range product PowerStore, which has now grown every quarter since its launch. Servers and networking revenue was $5.2 billion, up 16% year-over-year. Operating income was $1.0 billion or approximately 11.0% of Infrastructure Solutions Group revenue.

[0001571996-22-000028:8k_2_02:24]
1 Based on units, as of Q2 CY2022 IDC data. Data between Q1 CY2013 and Q2 CY2022.

[0001571996-22-000028:8k_2_02:25]
2

[0001571996-22-000028:8k_2_02:26]
Key areas of innovation:

[0001571996-22-000028:8k_2_02:27]
•The largest release in PowerStore history and new PowerMaxOS10 software are now available, delivering more than 500 new Dell storage software advancements that help customers drive faster insights, achieve better multicloud data control and increase cyber resiliency.

[0001571996-22-000028:8k_2_02:28]
•PowerProtect Cyber Recovery vault purchases grew 30% year-over-year, as customers seek multiple layers of protection from ransomware and other sophisticated threats.

[0001571996-22-000028:8k_2_02:29]
•Dell Validated Design for Analytics – Data Lakehouse, consisting of Dell’s end-to-end ISG portfolio, provides secure access to reliable, quality data, so users can run analytics, AI, ML and other data-driven workloads.

[0001571996-22-000028:8k_2_02:30]
•T-Mobile and Dell Technologies join forces to pair a private 5G network with Dell edge-computing technologies, so data can be processed, stored and acted upon at locations like large business campuses, factories or universities.

[0001571996-22-000028:8k_2_02:31]
Dell Technologies ended the quarter with remaining performance obligations of $41 billion, up 2% year-over-year, deferred revenue of $28.0 billion, and cash and investments of $7.1 billion. Recurring revenue for the second quarter was approximately $5.2 billion, up 8% year-over-year. APEX annual recurring revenue is now over $1 billion, with second quarter orders growth of 78% year-over-year.

[0001571996-22-000028:8k_2_02:32]
Executive Quotes:

[0001571996-22-000028:8k_2_02:33]
•“We continued to execute well in an increasingly challenging environment with record second quarter revenue of $26.4 billion, up 9%,” said Jeff Clarke, vice chairman and co-chief operating officer, Dell Technologies. “We also advanced our long-term strategy – growing the core while innovating for our customers and enabling their opportunities in the data era.”

[0001571996-22-000028:8k_2_02:34]
•“We delivered strong CSG and ISG growth and profitability – with revenue up 12% and 9% respectively – although we observed more cautious customer behavior as the quarter progressed,” said Chuck Whitten, co-chief operating officer, Dell Technologies. “Customers continue to prioritize advanced technology solutions to compete and succeed in the years ahead, and we are confident in our long-term opportunities.”

[0001571996-22-000028:8k_2_02:35]
•“Another quarter of record revenue, together with our operating income of $1.3 billion and non-GAAP operating income of $2.0 billion, affirms our industry strength and competitive position,” said Tom Sweet, chief financial officer, Dell Technologies. “We remain focused on what we can control, staying flexible and opportunistic, and delivering revenue and EPS growth with strong free cash flow to our shareholders over time.”

[0001571996-22-000028:8k_2_02:36]
Conference call information

[0001571996-22-000028:8k_2_02:37]
As previously announced, the Company will hold a conference call to discuss its performance and financial guidance on Aug. 25, 2022, at 4:30 p.m. CDT. Prior to the start of the conference call, prepared remarks and a presentation containing additional financial and operating information prior to guidance may be downloaded from investors.delltechnologies.com. The conference call will be broadcast live over the internet can be accessed at

[0001571996-22-000028:8k_2_02:38]
https://investors.delltechnologies.com/events-and-presentations/upcoming-events

[0001571996-22-000028:8k_2_02:39]
For those unable to listen to the live broadcast, the final remarks and presentation with guidance will be available following the broadcast, and an archived version will be available at the same location for one year.

[0001571996-22-000028:8k_2_02:40]
3

[0001571996-22-000028:8k_2_02:41]
Customer Highlights Blog

[0001571996-22-000028:8k_2_02:42]
Read our quarterly blog from Bill Scannell, Dell Technologies president of Global Sales & Customer Operations, to learn more about how we are helping customers with their digital transformations:

[0001571996-22-000028:8k_2_02:43]
https://www.dell.com/en-us/blog/technology-investments-are-key-to-customers-competitive-advantage/

[0001571996-22-000028:8k_2_02:44]
Environmental, Social and Governance (ESG)

[0001571996-22-000028:8k_2_02:45]
Our Environmental, Social and Governance (ESG) efforts focus on driving positive impact for people and our planet while delivering long-term value for our stakeholders. The FY22 ESG report was published June 30, 2022, and the Company held a conference call to discuss on July 21. ESG resources can be accessed at

[0001571996-22-000028:8k_2_02:46]
https://www.dell.com/en-us/dt/corporate/social-impact/reporting/esg-governance.htm

[0001571996-22-000028:8k_2_02:47]
About Dell Technologies

[0001571996-22-000028:8k_2_02:48]
Dell Technologies (NYSE:DELL) helps organizations and individuals build their digital future and transform how they work, live and play. The company provides customers with the industry’s broadest and most innovative technology and services portfolio for the data era.

[0001571996-22-000028:8k_2_02:49]
Contacts

[0001571996-22-000028:8k_2_02:50]
Investors: Investor_Relations@Dell.com

[0001571996-22-000028:8k_2_02:51]
Media: Media.Relations@Dell.com

[0001571996-22-000028:8k_2_02:52]
# # #

[0001571996-22-000028:8k_2_02:53]
Copyright © 2022 Dell Inc. or its subsidiaries. All Rights Reserved. Dell Technologies, Dell, EMC and Dell EMC are trademarks of Dell Inc. or its subsidiaries. Other trademarks may be trademarks of their respective owners.

[0001571996-22-000028:8k_2_02:54]
Non-GAAP Financial Measures:

[0001571996-22-000028:8k_2_02:55]
This press release presents information about Dell Technologies’ non-GAAP net revenue, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP operating income, non-GAAP net income, non-GAAP net income attributable to non-controlling interests, non-GAAP net income attributable to Dell Technologies Inc. - basic, non-GAAP net income attributable to Dell Technologies Inc. - diluted, non-GAAP earnings per share attributable to Dell Technologies Inc. - basic, and non-GAAP earnings per share attributable to Dell Technologies Inc. - diluted, which are non-GAAP financial measures provided as a supplement to the results provided in accordance with generally accepted accounting principles in the United States of America (“GAAP”). A reconciliation of each non-GAAP financial measure to the most directly comparable GAAP financial measure is provided in the attached tables for each of the fiscal periods indicated.

[0001571996-22-000028:8k_2_02:56]
Special Note on Forward-Looking Statements:

[0001571996-22-000028:8k_2_02:57]
Dell Technologies’ results or events in future periods could differ materially from those expressed or implied by these forward-looking statements because of risks, uncertainties, and other factors that include, but are not limited to, the following: risks and uncertainties relating to our spin-off of VMware, Inc., including the potential effects on our business of the transaction; the effects of the COVID-19 pandemic; competitive pressures; Dell Technologies’ reliance on third-party suppliers for products and components, including reliance on single-source or limited-source suppliers; Dell Technologies’ ability to achieve favorable pricing from its vendors; adverse global economic conditions and instability in financial markets; Dell Technologies’ execution of its growth, business and acquisition strategies; the success of Dell Technologies’ cost efficiency measures; Dell Technologies’ ability to manage solutions and products and services transitions in an effective manner; Dell Technologies’ ability to deliver high-quality products, software, and services; cyber attacks or other data security incidents; Dell Technologies’ foreign operations and ability to generate substantial non-U.S. net revenue; Dell Technologies’ product, services, customer, and geographic sales mix, and seasonal sales trends; the performance of Dell Technologies’ sales channel partners; access to the capital markets by Dell Technologies or its customers; material impairment of the value of goodwill or intangible assets; weak economic conditions and the effect of additional regulation on Dell Technologies’ financial services activities; counterparty default risks; the loss by Dell Technologies of any contracts for ISG services and solutions and its ability to perform such contracts at their estimated costs; loss by Dell Technologies of government contracts; Dell Technologies’ ability to develop and protect its proprietary intellectual property or obtain

[0001571996-22-000028:8k_2_02:58]
licenses to intellectual property developed by others on commercially reasonable and competitive terms; disruptions in Dell Technologies’ infrastructure; Dell Technologies’ ability to hedge effectively its exposure to fluctuations in foreign currency exchange rates and interest rates; expiration of tax holidays or favorable tax rate structures, or unfavorable outcomes in tax audits and other tax compliance matters; impairment of portfolio investments; unfavorable results of legal proceedings; compliance requirements of changing environmental and safety laws or other laws; the effect of armed hostilities, terrorism, natural disasters, and public health issues; the effect of global climate change and legal, regulatory, or market measures to address climate change; Dell Technologies’ dependence on the services of Michael Dell and key employees; Dell Technologies’ level of indebtedness; the effect of the transition from LIBOR as a reference rate to calculate interest rates under our variable-rate indebtedness; and business and financial factors and legal restrictions affecting continuation of Dell Technologies’ quarterly cash dividend policy and dividend rate.

[0001571996-22-000028:8k_2_02:59]
This list of risks, uncertainties, and other factors is not complete. Dell Technologies discusses some of these matters more fully, as well as certain risk factors that could affect Dell Technologies’ business, financial condition, results of operations, and prospects, in its reports filed with the SEC, including Dell Technologies’ annual report on Form 10-K for the fiscal year ended January 28, 2022, quarterly reports on Form 10-Q, and current reports on Form 8-K. These filings are available for review through the SEC’s website at www.sec.gov. Any or all forward-looking statements Dell Technologies makes may turn out to be wrong and can be affected by inaccurate assumptions Dell Technologies might make or by known or unknown risks, uncertainties and other factors, including those identified in this press release. Accordingly, you should not place undue reliance on the forward-looking statements made in this press release, which speak only as of its date. Dell Technologies does not undertake to update, and expressly disclaims any duty to update, its forward-looking statements, whether as a result of circumstances or events that arise after the date they are made, new information, or otherwise.

[0001571996-22-000028:8k_2_02:60]
5

[0001571996-22-000028:8k_2_02:61]
DELL TECHNOLOGIES INC. FINANCIAL INFORMATION

[0001571996-22-000028:8k_2_02:62]
Basis of Presentation

[0001571996-22-000028:8k_2_02:63]
Spin-Off of VMware, Inc. — On November 1, 2021, Dell Technologies Inc. completed its spin-off of VMware, Inc. (“VMware”) by means of a special stock dividend (the “VMware Spin-off”). In accordance with applicable accounting guidance, the results of VMware, excluding Dell's resale of VMware offerings, are presented as discontinued operations in the Condensed Consolidated Statements of Income and, as such, have been excluded from both continuing operations and segment results for the three and six months ended July 30, 2021.  The Condensed Consolidated Statements of Cash Flows are presented on a consolidated basis for both continuing operations and discontinued operations.

[0001571996-22-000028:8k_2_02:64]
6

[0001571996-22-000028:8k_2_02:65]
DELL TECHNOLOGIES INC.

[0001571996-22-000028:8k_2_02:66]
Consolidated Statements of Income and Related Financial Highlights

[0001571996-22-000028:8k_2_02:67]
(in millions, except percentages; unaudited)

[0001571996-22-000028:8k_2_02:68]
|  | Three Months Ended |  |  |  | Six Months Ended |  |  |
|  | July 29, 2022 |  | July 30, 2021 |  | Change |  | July 29, 2022 |  | July 30, 2021 |  | Change |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Products | $ | 20,810 |  | $ | 18,895 |  | 10% |  | $ | 41,274 |  |  | $ | 36,382 |  |  | 13% |
| Services | 5,615 |  | 5,296 |  | 6% |  | 11,267 |  |  | 10,399 |  |  | 8% |
| Total net revenue | 26,425 |  | 24,191 |  | 9% |  | 52,541 |  |  | 46,781 |  |  | 12% |
| Cost of net revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Products | 17,671 |  | 15,692 |  | 13% |  | 34,680 |  |  | 30,126 |  |  | 15% |
| Services | 3,315 |  | 3,024 |  | 10% |  | 6,638 |  |  | 5,916 |  |  | 12% |
| Total cost of net revenue | 20,986 |  | 18,716 |  | 12% |  | 41,318 |  |  | 36,042 |  |  | 15% |
| Gross margin | 5,439 |  | 5,475 |  | (1)% |  | 11,223 |  |  | 10,739 |  |  | 5% |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |
| Selling, general, and administrative | 3,543 |  | 3,761 |  | (6)% |  | 7,096 |  |  | 7,419 |  |  | (4)% |
| Research and development | 626 |  | 697 |  | (10)% |  | 1,307 |  |  | 1,316 |  |  | (1)% |
| Total operating expenses | 4,169 |  | 4,458 |  | (6)% |  | 8,403 |  |  | 8,735 |  |  | (4)% |
| Operating income | 1,270 |  | 1,017 |  | 25% |  | 2,820 |  |  | 2,004 |  |  | 41% |
| Interest and other, net | (635) |  | (292) |  | (117)% |  | (972) |  |  | (580) |  |  | (68)% |
| Income before income taxes | 635 |  | 725 |  | (12)% |  | 1,848 |  |  | 1,424 |  |  | 30% |
| Income tax expense | 129 |  | 96 |  | 34% |  | 273 |  |  | 136 |  |  | 101% |
| Net income from continuing operations | 506 |  | 629 |  | (20)% |  | 1,575 |  |  | 1,288 |  |  | 22% |
| Income from discontinued operations, net of income taxes | — |  | 251 |  | (100)% |  | — |  |  | 530 |  |  | (100)% |
| Net income | 506 |  | 880 |  | (43)% |  | 1,575 |  |  | 1,818 |  |  | (13)% |
| Less: Net loss attributable to non-controlling interests | (5) |  | (2) |  | (150)% |  | (8) |  |  | (3) |  |  | (167)% |
| Less: Net income attributable to non-controlling interests of discontinued operations | — |  | 51 |  | (100)% |  | — |  |  | 103 |  |  | (100)% |
| Net income attributable to Dell Technologies Inc. | $ | 511 |  | $ | 831 |  | (39)% |  | $ | 1,583 |  |  | $ | 1,718 |  |  | (8)% |
| Percentage of Total Net Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Gross margin | 20.6 | % |  | 22.6 | % |  |  |  | 21.4 | % |  | 23.0 | % |  |  |
| Selling, general, and administrative | 13.4 | % |  | 15.5 | % |  |  |  | 13.5 | % |  | 15.9 | % |  |  |
| Research and development | 2.4 | % |  | 2.9 | % |  |  |  | 2.5 | % |  | 2.8 | % |  |  |
| Operating expenses | 15.8 | % |  | 18.4 | % |  |  |  | 16.0 | % |  | 18.7 | % |  |  |
| Operating income | 4.8 | % |  | 4.2 | % |  |  |  | 5.4 | % |  | 4.3 | % |  |  |
| Income before income taxes | 2.4 | % |  | 3.0 | % |  |  |  | 3.5 | % |  | 3.0 | % |  |  |
| Net income from continuing operations | 1.9 | % |  | 2.6 | % |  |  |  | 3.0 | % |  | 2.8 | % |  |  |
| Income tax rate | 20.3 | % |  | 13.2 | % |  |  |  | 14.8 | % |  | 9.6 | % |  |  |

[0001571996-22-000028:8k_2_02:69]
Amounts are based on underlying data and may not visually foot due to rounding.

[0001571996-22-000028:8k_2_02:70]
7

[0001571996-22-000028:8k_2_02:71]
DELL TECHNOLOGIES INC.

[0001571996-22-000028:8k_2_02:72]
Consolidated Statements of Financial Position

[0001571996-22-000028:8k_2_02:73]
(in millions; unaudited)

[0001571996-22-000028:8k_2_02:74]
|  | July 29, 2022 |  | January 28, 2022 |
| ASSETS |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 5,507 |  |  | $ | 9,477 |  |
| Accounts receivable, net | 13,431 |  |  | 12,912 |  |
| Due from related party, net | 195 |  |  | 131 |  |
| Short-term financing receivables, net | 4,860 |  |  | 5,089 |  |
| Inventories | 5,883 |  |  | 5,898 |  |
| Other current assets | 12,386 |  |  | 11,526 |  |
| Total current assets | 42,262 |  |  | 45,033 |  |
| Property, plant, and equipment, net | 5,772 |  |  | 5,415 |  |
| Long-term investments | 1,520 |  |  | 1,839 |  |
| Long-term financing receivables, net | 5,450 |  |  | 5,522 |  |
| Goodwill | 19,505 |  |  | 19,770 |  |
| Intangible assets, net | 6,972 |  |  | 7,461 |  |
| Due from related party, net | 609 |  |  | 710 |  |
| Other non-current assets | 6,685 |  |  | 6,985 |  |
| Total assets | $ | 88,775 |  |  | $ | 92,735 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |
| Short-term debt | $ | 6,647 |  |  | $ | 5,823 |  |
| Accounts payable | 25,339 |  |  | 27,143 |  |
| Due to related party | 1,269 |  |  | 1,414 |  |
| Accrued and other | 6,810 |  |  | 7,578 |  |
| Short-term deferred revenue | 14,724 |  |  | 14,261 |  |
| Total current liabilities | 54,789 |  |  | 56,219 |  |
| Long-term debt | 20,287 |  |  | 21,131 |  |
| Long-term deferred revenue | 13,301 |  |  | 13,312 |  |
| Other non-current liabilities | 3,153 |  |  | 3,653 |  |
| Total liabilities | 91,530 |  |  | 94,315 |  |
| Stockholders’ equity (deficit): |  |  |  |
| Total Dell Technologies Inc. stockholders’ equity (deficit) | (2,860) |  |  | (1,685) |  |
| Non-controlling interests | 105 |  |  | 105 |  |
| Total stockholders’ equity (deficit) | (2,755) |  |  | (1,580) |  |
| Total liabilities and stockholders’ equity | $ | 88,775 |  |  | $ | 92,735 |  |

[0001571996-22-000028:8k_2_02:75]
8

[0001571996-22-000028:8k_2_02:76]
DELL TECHNOLOGIES INC.

[0001571996-22-000028:8k_2_02:77]
Consolidated Statements of Cash Flows

[0001571996-22-000028:8k_2_02:78]
(in millions; unaudited)

[0001571996-22-000028:8k_2_02:79]
|  | Three Months Ended |  | Six Months Ended |
|  | July 29, 2022 |  | July 30, 2021 |  | July 29, 2022 |  | July 30, 2021 |
| Cash flows from operating activities: |  |  |  |  |  |  |  |
| Net income | $ | 506 |  |  | $ | 880 |  |  | $ | 1,575 |  |  | $ | 1,818 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: | 218 |  |  | 845 |  |  | (1,120) |  |  | 2,145 |  |
| Change in cash from operating activities | 724 |  |  | 1,725 |  |  | 455 |  |  | 3,963 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |
| Purchases of investments | (28) |  |  | (124) |  |  | (80) |  |  | (270) |  |
| Maturities and sales of investments | 50 |  |  | 79 |  |  | 68 |  |  | 335 |  |
| Capital expenditures and capitalized software development costs | (807) |  |  | (632) |  |  | (1,497) |  |  | (1,257) |  |
| Acquisition of businesses and assets, net | — |  |  | (6) |  |  | — |  |  | (16) |  |
| Other | 7 |  |  | 14 |  |  | 11 |  |  | 20 |  |
| Change in cash from investing activities | (778) |  |  | (669) |  |  | (1,498) |  |  | (1,188) |  |
| Cash flows from financing activities: |  |  |  |  |  |  |  |
| Proceeds from the issuance of common stock | 1 |  |  | 26 |  |  | 5 |  |  | 186 |  |
| Repurchases of parent common stock (a) | (689) |  |  | (8) |  |  | (2,468) |  |  | (17) |  |
| Repurchases of subsidiary common stock (a) | (1) |  |  | (544) |  |  | (8) |  |  | (978) |  |
| Payments of dividends to stockholders | (242) |  |  | — |  |  | (490) |  |  | — |  |
| Proceeds from debt | 3,431 |  |  | 1,209 |  |  | 6,465 |  |  | 3,935 |  |
| Repayments of debt | (3,539) |  |  | (4,353) |  |  | (6,242) |  |  | (8,423) |  |
| Debt-related costs and other, net | (7) |  |  | (3) |  |  | (14) |  |  | (14) |  |
| Change in cash from financing activities | (1,046) |  |  | (3,673) |  |  | (2,752) |  |  | (5,311) |  |
| Effect of exchange rate changes on cash, cash equivalents, and restricted cash | (83) |  |  | (16) |  |  | (194) |  |  | (21) |  |
| Change in cash, cash equivalents, and restricted cash | (1,183) |  |  | (2,633) |  |  | (3,989) |  |  | (2,557) |  |
| Cash, cash equivalents, and restricted cash at beginning of the period, including cash attributable to discontinued operations | 7,276 |  |  | 15,260 |  |  | 10,082 |  |  | 15,184 |  |
| Cash, cash equivalents, and restricted cash at end of the period, including cash attributable to discontinued operations | 6,093 |  |  | 12,627 |  |  | 6,093 |  |  | 12,627 |  |
| Less: Cash, cash equivalents, and restricted cash attributable to discontinued operations | — |  |  | 5,922 |  |  | — |  |  | 5,922 |  |
| Cash, cash equivalents, and restricted cash from continuing operations | $ | 6,093 |  |  | $ | 6,705 |  |  | $ | 6,093 |  |  | $ | 6,705 |  |

[0001571996-22-000028:8k_2_02:80]
_________________

[0001571996-22-000028:8k_2_02:81]
(a)Common stock repurchases are inclusive of employee tax withholding on stock-based compensation.

[0001571996-22-000028:8k_2_02:82]
9

[0001571996-22-000028:8k_2_02:83]
DELL TECHNOLOGIES INC.

[0001571996-22-000028:8k_2_02:84]
Segment Information

[0001571996-22-000028:8k_2_02:85]
(in millions, except percentages; unaudited; continued on next page)

[0001571996-22-000028:8k_2_02:86]
|  | Three Months Ended |  |  |  | Six Months Ended |  |  |
|  | July 29, 2022 |  | July 30, 2021 |  | Change |  | July 29, 2022 |  | July 30, 2021 |  | Change |
| Infrastructure Solutions Group (ISG): |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Servers and networking | $ | 5,209 |  | $ | 4,480 |  | 16% |  | $ | 10,257 |  | $ | 8,620 |  | 19% |
| Storage | 4,327 |  | 4,070 |  | 6% |  | 8,564 |  | 7,963 |  | 8% |
| Total ISG net revenue | $ | 9,536 |  | $ | 8,550 |  | 12% |  | $ | 18,821 |  | $ | 16,583 |  | 13% |
| Operating Income: |  |  |  |  |  |  |  |  |  |  |  |
| ISG operating income | $ | 1,046 |  | $ | 962 |  | 9% |  | $ | 2,128 |  | $ | 1,740 |  | 22% |
| % of ISG net revenue | 11.0 | % |  | 11.3 | % |  |  |  | 11.3 | % |  | 10.5 | % |  |  |
| % of total reportable segment operating income | 52 | % |  | 49 | % |  |  |  | 50 | % |  | 46 | % |  |  |
| Client Solutions Group (CSG): |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Commercial | $ | 12,141 |  | $ | 10,577 |  | 15% |  | $ | 24,112 |  | $ | 20,385 |  | 18% |
| Consumer | 3,349 |  | 3,691 |  | (9)% |  | 6,965 |  | 7,194 |  | (3)% |
| Total CSG net revenue | $ | 15,490 |  | $ | 14,268 |  | 9% |  | $ | 31,077 |  | $ | 27,579 |  | 13% |
| Operating Income: |  |  |  |  |  |  |  |  |  |  |  |
| CSG operating income | $ | 978 |  | $ | 986 |  | (1)% |  | $ | 2,093 |  | $ | 2,066 |  | 1% |
| % of CSG net revenue | 6.3 | % |  | 6.9 | % |  |  |  | 6.7 | % |  | 7.5 | % |  |  |
| % of total reportable segment operating income | 48 | % |  | 51 | % |  |  |  | 50 | % |  | 54 | % |  |  |

[0001571996-22-000028:8k_2_02:87]
Amounts are based on underlying data and may not visually foot due to rounding.

[0001571996-22-000028:8k_2_02:88]
10

[0001571996-22-000028:8k_2_02:89]
DELL TECHNOLOGIES INC.

[0001571996-22-000028:8k_2_02:90]
Segment Information

[0001571996-22-000028:8k_2_02:91]
(in millions, except percentages; unaudited; continued)

[0001571996-22-000028:8k_2_02:92]
|  | Three Months Ended |  | Six Months Ended |
|  | July 29, 2022 |  | July 30, 2021 |  | July 29, 2022 |  | July 30, 2021 |
| Reconciliation to consolidated net revenue: |  |  |  |  |  |  |
| Reportable segment net revenue | $ | 25,026 |  |  | $ | 22,818 |  |  | $ | 49,898 |  |  | $ | 44,162 |  |
| Other businesses (a) | 1,399 |  |  | 1,378 |  |  | 2,638 |  |  | 2,630 |  |
| Unallocated transactions (b) | — |  |  | 3 |  |  | 5 |  |  | 5 |  |
| Impact of purchase accounting (c) | — |  |  | (8) |  |  | — |  |  | (16) |  |
| Total consolidated net revenue | $ | 26,425 |  |  | $ | 24,191 |  |  | $ | 52,541 |  |  | $ | 46,781 |  |
| Reconciliation to consolidated operating income: |  |  |  |  |  |  |  |
| Reportable segment operating income | $ | 2,024 |  |  | $ | 1,948 |  |  | $ | 4,221 |  |  | $ | 3,806 |  |
| Other businesses (a) | (71) |  |  | (77) |  |  | (135) |  |  | (167) |  |
| Unallocated transactions (b) | (1) |  |  | (3) |  |  | 1 |  |  | (1) |  |
| Impact of purchase accounting (c) | (3) |  |  | (15) |  |  | (12) |  |  | (35) |  |
| Amortization of intangibles | (244) |  |  | (442) |  |  | (487) |  |  | (887) |  |
| Transaction-related expenses (d) | (3) |  |  | (37) |  |  | (8) |  |  | (66) |  |
| Stock-based compensation expense (e) | (236) |  |  | (206) |  |  | (468) |  |  | (378) |  |
| Other corporate expenses (f) | (196) |  |  | (151) |  |  | (292) |  |  | (268) |  |
| Total consolidated operating income | $ | 1,270 |  |  | $ | 1,017 |  |  | $ | 2,820 |  |  | $ | 2,004 |  |

[0001571996-22-000028:8k_2_02:93]
_________________

[0001571996-22-000028:8k_2_02:94]
(a)Other businesses consists of: 1) Dell’s resale of standalone VMware, Inc. products and services, “VMware Resale,” 2) Secureworks, and 3) Virtustream, and do not meet the requirements for a reportable segment, either individually or collectively.

[0001571996-22-000028:8k_2_02:95]
(b)Unallocated transactions includes other corporate items that are not allocated to Dell Technologies’ reportable segments.

[0001571996-22-000028:8k_2_02:96]
(c)Impact of purchase accounting includes non-cash purchase accounting adjustments that are primarily related to the EMC merger transaction.

[0001571996-22-000028:8k_2_02:97]
(d)Transaction-related expenses includes acquisition, integration, and divestiture related costs.

[0001571996-22-000028:8k_2_02:98]
(e)Stock-based compensation expense consists of equity awards granted based on the estimated fair value of those awards at grant date.

[0001571996-22-000028:8k_2_02:99]
(f)Other corporate expenses includes impairment charges, incentive charges related to equity investments, severance, payroll taxes associated with stock-based compensation, facilities action, and other costs.  During the three and six months ended Fiscal 2023, other corporate expenses includes impairment and other costs incurred in connection with exiting our business in Russia.

[0001571996-22-000028:8k_2_02:100]
11

[0001571996-22-000028:8k_2_02:101]
SUPPLEMENTAL SELECTED NON-GAAP FINANCIAL MEASURES

[0001571996-22-000028:8k_2_02:102]
These tables present information about the Company’s non-GAAP net revenue, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP operating income, non-GAAP net income, non-GAAP net income attributable to Dell Technologies Inc. - basic and diluted, non-GAAP earnings per share attributable to Dell Technologies Inc. - basic, and non-GAAP earnings per share attributable to Dell Technologies Inc. - diluted which are non-GAAP financial measures provided as a supplement to the results provided in accordance with generally accepted accounting principles in the United States of America (“GAAP”). A detailed discussion of Dell Technologies’ reasons for including these non-GAAP financial measures, the limitations associated with these measures, the items excluded from these measures, and our reason for excluding those items are presented in “Management’s Discussion and Analysis of Financial Condition and Results of Operations — Non-GAAP Financial Measures” in our periodic reports filed with the SEC. Dell Technologies encourages investors to review the non-GAAP discussion in these reports in conjunction with the presentation of non-GAAP financial measures.

[0001571996-22-000028:8k_2_02:103]
12

[0001571996-22-000028:8k_2_02:104]
DELL TECHNOLOGIES INC.

[0001571996-22-000028:8k_2_02:105]
Selected Non-GAAP Financial Measures

[0001571996-22-000028:8k_2_02:106]
(in millions, except per share amounts and percentages; unaudited)

[0001571996-22-000028:8k_2_02:107]
|  | Three Months Ended |  |  |  | Six Months Ended |  |  |
|  | July 29, 2022 |  | July 30, 2021 |  | Change |  | July 29, 2022 |  | July 30, 2021 |  | Change |
| Non-GAAP net revenue | $ | 26,425 |  | $ | 24,199 |  | 9% |  | $ | 52,541 |  | $ | 46,797 |  | 12% |
| Non-GAAP gross margin | $ | 5,650 |  | $ | 5,673 |  | —% |  | $ | 11,591 |  | $ | 11,137 |  | 4% |
| % of non-GAAP net revenue | 21.4 | % |  | 23.4 | % |  |  |  | 22.1 | % |  | 23.8 | % |  |  |
| Non-GAAP operating expenses | $ | 3,698 |  | $ | 3,805 |  | (3)% |  | $ | 7,504 |  | $ | 7,499 |  | —% |
| % of non-GAAP net revenue | 14.0 | % |  | 15.7 | % |  |  |  | 14.3 | % |  | 16.0 | % |  |  |
| Non-GAAP operating income | $ | 1,952 |  | $ | 1,868 |  | 4% |  | $ | 4,087 |  | $ | 3,638 |  | 12% |
| % of non-GAAP net revenue | 7.4 | % |  | 7.7 | % |  |  |  | 7.8 | % |  | 7.8 | % |  |  |
| Non-GAAP net income | $ | 1,266 |  | $ | 1,166 |  | 9% |  | $ | 2,700 |  | $ | 2,221 |  | 22% |
| % of non-GAAP net revenue | 4.8 | % |  | 4.8 | % |  |  |  | 5.1 | % |  | 4.7 | % |  |  |
| Non-GAAP earnings per share - diluted | $ | 1.68 |  | $ | 1.48 |  | 14% |  | $ | 3.52 |  | $ | 2.83 |  | 24% |

[0001571996-22-000028:8k_2_02:108]
Amounts are based on underlying data and may not visually foot due to rounding.

[0001571996-22-000028:8k_2_02:109]
DELL TECHNOLOGIES INC.

[0001571996-22-000028:8k_2_02:110]
Reconciliation of Selected Non-GAAP Financial Measures

[0001571996-22-000028:8k_2_02:111]
(in millions, except percentages; unaudited; continued on next page)

[0001571996-22-000028:8k_2_02:112]
|  | Three Months Ended |  |  |  | Six Months Ended |  |  |
|  | July 29, 2022 |  | July 30, 2021 |  | Change |  | July 29, 2022 |  | July 30, 2021 |  | Change |
| Net revenue | $ | 26,425 |  |  | $ | 24,191 |  |  | 9% |  | $ | 52,541 |  |  | $ | 46,781 |  |  | 12% |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Impact of purchase accounting | — |  |  | 8 |  |  |  |  | — |  |  | 16 |  |  |  |
| Non-GAAP net revenue | $ | 26,425 |  |  | $ | 24,199 |  |  | 9% |  | $ | 52,541 |  |  | $ | 46,797 |  |  | 12% |
| Gross margin | $ | 5,439 |  |  | $ | 5,475 |  |  | (1)% |  | $ | 11,223 |  |  | $ | 10,739 |  |  | 5% |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 105 |  |  | 150 |  |  |  |  | 209 |  |  | 300 |  |  |  |
| Impact of purchase accounting | — |  |  | 9 |  |  |  |  | 2 |  |  | 18 |  |  |  |
| Stock-based compensation expense | 37 |  |  | 32 |  |  |  |  | 75 |  |  | 60 |  |  |  |
| Other corporate expenses | 69 |  |  | 7 |  |  |  |  | 82 |  |  | 20 |  |  |  |
| Non-GAAP gross margin | $ | 5,650 |  |  | $ | 5,673 |  |  | —% |  | $ | 11,591 |  |  | $ | 11,137 |  |  | 4% |
| Operating expenses | $ | 4,169 |  |  | $ | 4,458 |  |  | (6)% |  | $ | 8,403 |  |  | $ | 8,735 |  |  | (4)% |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | (139) |  |  | (292) |  |  |  |  | (278) |  |  | (587) |  |  |  |
| Impact of purchase accounting | (3) |  |  | (6) |  |  |  |  | (10) |  |  | (17) |  |  |  |
| Transaction-related expenses | (3) |  |  | (37) |  |  |  |  | (8) |  |  | (66) |  |  |  |
| Stock-based compensation expense | (199) |  |  | (174) |  |  |  |  | (393) |  |  | (318) |  |  |  |
| Other corporate expenses | (127) |  |  | (144) |  |  |  |  | (210) |  |  | (248) |  |  |  |
| Non-GAAP operating expenses | $ | 3,698 |  |  | $ | 3,805 |  |  | (3)% |  | $ | 7,504 |  |  | $ | 7,499 |  |  | —% |
| Operating income | $ | 1,270 |  |  | $ | 1,017 |  |  | 25% |  | $ | 2,820 |  |  | $ | 2,004 |  |  | 41% |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 244 |  |  | 442 |  |  |  |  | 487 |  |  | 887 |  |  |  |
| Impact of purchase accounting | 3 |  |  | 15 |  |  |  |  | 12 |  |  | 35 |  |  |  |
| Transaction-related expenses | 3 |  |  | 37 |  |  |  |  | 8 |  |  | 66 |  |  |  |
| Stock-based compensation expense | 236 |  |  | 206 |  |  |  |  | 468 |  |  | 378 |  |  |  |
| Other corporate expenses | 196 |  |  | 151 |  |  |  |  | 292 |  |  | 268 |  |  |  |
| Non-GAAP operating income | $ | 1,952 |  |  | $ | 1,868 |  |  | 4% |  | $ | 4,087 |  |  | $ | 3,638 |  |  | 12% |

[0001571996-22-000028:8k_2_02:113]
14

[0001571996-22-000028:8k_2_02:114]
DELL TECHNOLOGIES INC.

[0001571996-22-000028:8k_2_02:115]
Reconciliation of Selected Non-GAAP Financial Measures

[0001571996-22-000028:8k_2_02:116]
(in millions, except percentages; unaudited; continued)

[0001571996-22-000028:8k_2_02:117]
|  | Three Months Ended |  |  |  | Six Months Ended |  |  |
|  | July 29, 2022 |  | July 30, 2021 |  | Change |  | July 29, 2022 |  | July 30, 2021 |  | Change |
| Net income from continuing operations | $ | 506 |  |  | $ | 629 |  |  | (20)% |  | $ | 1,575 |  |  | $ | 1,288 |  |  | 22% |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 244 |  |  | 442 |  |  |  |  | 487 |  |  | 887 |  |  |  |
| Impact of purchase accounting | 3 |  |  | 15 |  |  |  |  | 12 |  |  | 35 |  |  |  |
| Transaction-related (income) expenses | (4) |  |  | 25 |  |  |  |  | (6) |  |  | 54 |  |  |  |
| Stock-based compensation expense | 236 |  |  | 206 |  |  |  |  | 468 |  |  | 378 |  |  |  |
| Other corporate expenses | 212 |  |  | 151 |  |  |  |  | 308 |  |  | 268 |  |  |  |
| Fair value adjustments on equity investments | 255 |  |  | (168) |  |  |  |  | 241 |  |  | (362) |  |  |  |
| Aggregate adjustment for income taxes | (186) |  |  | (134) |  |  |  |  | (385) |  |  | (327) |  |  |  |
| Non-GAAP net income | $ | 1,266 |  |  | $ | 1,166 |  |  | 9% |  | $ | 2,700 |  |  | $ | 2,221 |  |  | 22% |
| Net income from continuing operations attributable to Dell Technologies Inc. | $ | 511 |  |  | $ | 631 |  |  | (19)% |  | $ | 1,583 |  |  | $ | 1,291 |  |  | 23% |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 244 |  |  | 442 |  |  |  |  | 487 |  |  | 887 |  |  |  |
| Impact of purchase accounting | 3 |  |  | 15 |  |  |  |  | 12 |  |  | 35 |  |  |  |
| Transaction-related (income) expenses | (4) |  |  | 25 |  |  |  |  | (6) |  |  | 54 |  |  |  |
| Stock-based compensation expense | 236 |  |  | 206 |  |  |  |  | 468 |  |  | 378 |  |  |  |
| Other corporate expenses | 212 |  |  | 151 |  |  |  |  | 308 |  |  | 268 |  |  |  |
| Fair value adjustments on equity investments | 255 |  |  | (168) |  |  |  |  | 241 |  |  | (362) |  |  |  |
| Aggregate adjustment for income taxes | (186) |  |  | (134) |  |  |  |  | (385) |  |  | (327) |  |  |  |
| Total non-GAAP adjustments attributable to non-controlling interests | (3) |  |  | (2) |  |  |  |  | (5) |  |  | (3) |  |  |  |
| Non-GAAP net income attributable to Dell Technologies Inc. | $ | 1,268 |  |  | $ | 1,166 |  |  | 9% |  | $ | 2,703 |  |  | $ | 2,221 |  |  | 22% |

[0001571996-22-000028:8k_2_02:118]
15

[0001571996-22-000028:8k_2_02:119]
DELL TECHNOLOGIES INC.

[0001571996-22-000028:8k_2_02:120]
Reconciliation of Selected Non-GAAP Financial Measures

[0001571996-22-000028:8k_2_02:121]
(in millions, except percentages and per share amounts; unaudited; continued)

[0001571996-22-000028:8k_2_02:122]
|  | Three Months Ended |  |  |  | Six Months Ended |  |  |
|  | July 29, 2022 |  | July 30, 2021 |  | Change |  | July 29, 2022 |  | July 30, 2021 |  | Change |
| Earnings per share from continuing operations attributable to Dell Technologies Inc. |  |  |  |  |
| Net income from continuing operations attributable to Dell Technologies Inc. — basic | $ | 511 |  |  | $ | 631 |  |  |  |  | $ | 1,583 |  |  | $ | 1,291 |  |  |  |
| Weighted-average shares outstanding — basic | 739 |  |  | 763 |  |  |  |  | 746 |  |  | 760 |  |  |  |
| Earnings per share attributable to Dell Technologies Inc. — basic | $ | 0.69 |  |  | $ | 0.83 |  |  | (17)% |  | $ | 2.12 |  |  | $ | 1.70 |  |  | 25% |
| Net income from continuing operations attributable to Dell Technologies Inc. — diluted | $ | 511 |  |  | $ | 631 |  |  |  |  | $ | 1,583 |  |  | $ | 1,291 |  |  |  |
| Weighted-average shares outstanding — diluted | 755 |  |  | 786 |  |  |  |  | 768 |  |  | 784 |  |  |  |
| Earnings per share attributable to Dell Technologies Inc. — diluted: | $ | 0.68 |  |  | $ | 0.80 |  |  | (15)% |  | $ | 2.06 |  |  | $ | 1.65 |  |  | 25% |
| Earnings per share from discontinued operations attributable to Dell Technologies Inc. |  |  |  |  |
| Net income from discontinued operations attributable to Dell Technologies Inc. — basic | $ | — |  |  | $ | 200 |  |  |  |  | $ | — |  |  | $ | 427 |  |  |  |
| Weighted-average shares outstanding — basic | — |  |  | 763 |  |  |  |  | — |  |  | 760 |  |  |  |
| Earnings per share attributable to Dell Technologies Inc. — basic | $ | — |  |  | $ | 0.26 |  |  | NM |  | $ | — |  |  | $ | 0.56 |  |  | NM |
| Incremental dilution from VMware, Inc. attributable to Dell Technologies | — |  |  | (3) |  |  |  |  | — |  |  | (5) |  |  |  |
| Net income from discontinued operations attributable to Dell Technologies Inc. — diluted | $ | — |  |  | $ | 197 |  |  |  |  | $ | — |  |  | $ | 422 |  |  |  |
| Weighted-average shares outstanding — diluted | — |  |  | 786 |  |  |  |  | — |  |  | 784 |  |  |  |
| Earnings per share attributable to Dell Technologies Inc. — diluted | $ | — |  |  | $ | 0.25 |  |  | NM |  | $ | — |  |  | $ | 0.53 |  |  | NM |
| Non-GAAP earnings per share attributable to Dell Technologies Inc. |  |  |
| Non-GAAP net income attributable to Dell Technologies Inc. — basic | $ | 1,268 |  |  | $ | 1,166 |  |  |  |  | $ | 2,703 |  |  | $ | 2,221 |  |  |  |
| Weighted-average shares outstanding — basic | 739 |  |  | 763 |  |  |  |  | 746 |  |  | 760 |  |  |  |
| Earnings per share attributable to Dell Technologies Inc. — basic | $ | 1.72 |  |  | $ | 1.53 |  |  | 12% |  | $ | 3.62 |  |  | $ | 2.92 |  |  | 24% |
| Non-GAAP net income attributable to Dell Technologies Inc. — diluted | $ | 1,268 |  |  | $ | 1,166 |  |  |  |  | $ | 2,703 |  |  | $ | 2,221 |  |  |  |
| Weighted-average shares outstanding — diluted | 755 |  |  | 786 |  |  |  |  | 768 |  |  | 784 |  |  |  |
| Earnings per share attributable to Dell Technologies Inc. — diluted | $ | 1.68 |  |  | $ | 1.48 |  |  | 14% |  | $ | 3.52 |  |  | $ | 2.83 |  |  | 24% |

[0001571996-22-000028:8k_2_02:123]
Amounts may not visually recalculate due to rounding.

[0001571996-22-000028:8k_2_02:124]
16
