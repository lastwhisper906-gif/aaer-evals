# DELL notes — 0001571996-22-000031


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0001571996-22-000031:notes:1]
Basis of Presentation — The accompanying unaudited Condensed Consolidated Financial Statements should be read in conjunction with the audited Consolidated Financial Statements and accompanying Notes filed with the U.S. Securities and Exchange Commission (“SEC”) in the Company’s Annual Report on Form 10-K for the fiscal year ended January 28, 2022.  These Condensed Consolidated Financial Statements have been prepared in accordance with accounting principles generally accepted in the United States of America (“GAAP”).  In the opinion of management, the accompanying Condensed Consolidated Financial Statements reflect all adjustments of a normal recurring nature considered necessary to fairly state the financial position of the Company as of July 29, 2022 and January 28, 2022, the results of its operations, corresponding comprehensive income, and its statement of stockholders’ equity for the three and six months ended July 29, 2022 and July 30, 2021, and its cash flows for the six months ended July 29, 2022 and July 30, 2021.


## us-gaap:ConsolidationPolicyTextBlock

[0001571996-22-000031:notes:2]
[same as prior period, unchanged from 0001571996-22-000021:notes:2]


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001571996-22-000031:notes:3]
Recently Issued Accounting Pronouncements

[0001571996-22-000031:notes:4]
Accounting for Contract Assets and Contract Liabilities from Contracts with Customers — In October 2021, the Financial Accounting Standards Board (“FASB”) issued guidance which requires companies to apply Topic 606, Revenue from Contracts with Customers, to recognize and measure contract assets and contract liabilities from contracts with customers acquired in a business combination.  Public entities must adopt the new guidance for fiscal years beginning after December 15, 2022 and interim periods within those fiscal years, with early adoption permitted.  Adoption of the guidance is not expected to have a material impact on the Company’s financial results.
Reference Rate Reform — In March 2020, the FASB issued guidance which provides temporary optional expedients and exceptions to GAAP guidance on contract modifications and certain hedging relationships to ease the financial reporting burdens related to the expected market transition from the London Interbank Offered Rate to alternative reference rates.  The Company may elect to apply the amendments prospectively through December 31, 2024.  Adoption of the new guidance is not expected to have a material impact on the Company’s financial results.


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0001571996-22-000031:notes:5]
DISCONTINUED OPERATIONS
VMware Spin-Off — As disclosed in Note 1 of the Notes to the Condensed Consolidated Financial Statements, on November 1, 2021, the Company completed its spin-off of VMware by means of a special stock dividend of 30,678,605 shares of Class A common stock and 307,221,836 shares of Class B common stock of VMware to Dell Technologies stockholders of record as of October 29, 2021.

[0001571996-22-000031:notes:6]
[same as prior period, unchanged from 0001571996-22-000021:notes:6]

[0001571996-22-000031:notes:7]
[same as prior period, unchanged from 0001571996-22-000021:notes:7]

[0001571996-22-000031:notes:8]
Dell Technologies determined that the VMware Spin-off, and related distributions, qualified as tax-free for U.S. federal income tax purposes, which required significant judgment by management.  In making these determinations, Dell Technologies applied U.S. federal tax law to relevant facts and circumstances and obtained a favorable private letter ruling from the Internal Revenue Service, a tax opinion, and other external tax advice related to the concluded tax treatment.  If the completed transactions were to fail to qualify for tax-free treatment for U.S. federal income tax purposes, the Company could be subject to significant liabilities, which could have material adverse impacts on the Company’s business, financial condition, results of operations and cash flows in future reporting periods.

[0001571996-22-000031:notes:9]
[same as prior period, unchanged from 0001571996-22-000021:notes:9]

[0001571996-22-000031:notes:10]
[same as prior period, unchanged from 0001571996-22-000021:notes:10]

[0001571996-22-000031:notes:11]
Pursuant to the CFA, Dell Technologies continues to act as a distributor of VMware’s standalone products and services and purchases such products and services for resale to end-user customers.  Dell Technologies also continues to integrate VMware’s products and services with Dell Technologies’ offerings and sell them to end users.  Cash flows between Dell Technologies and VMware primarily relate to such transactions.  The Company has determined that it is generally acting as principal in these arrangements.  The results of such operations are classified as continuing operations within the Company’s Condensed Consolidated Statements of Income.  See Note 16 of the Notes to the Condensed Consolidated Financial Statements for additional information regarding transactions between Dell Technologies and VMware.

[0001571996-22-000031:notes:12]
In accordance with applicable accounting guidance, the results of VMware, excluding Dell Technologies’ resale of VMware offerings, are presented as discontinued operations in the Condensed Consolidated Statements of Income and, as such, have been excluded from both continuing operations and segment results for the three and six months ended July 30, 2021.  The Condensed Consolidated Statements of Cash Flows are presented on a consolidated basis for both continuing operations and discontinued operations.

[0001571996-22-000031:notes:13]
[same as prior period, unchanged from 0001571996-22-000021:notes:13]

[0001571996-22-000031:notes:14]
[same as prior period, unchanged from 0001571996-22-000021:notes:14]

[0001571996-22-000031:notes:15]
The following table presents key components of “Income from discontinued operations, net of income taxes” for the three and six months ended July 30, 2021:

[0001571996-22-000031:notes:16]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | July 30, 2021 |  | July 30, 2021 |
|  |  | (in millions) |
| Net revenue |  | $ | 1,931 |  |  | $ | 3,828 |  |
| Cost of net revenue |  | (579) |  |  | (1,076) |  |
| Operating expenses |  | 2,155 |  |  | 4,161 |  |
| Interest and other, net |  | 67 |  |  | 167 |  |
| Income from discontinued operations before income taxes |  | 288 |  |  | 576 |  |
| Income tax expense |  | 37 |  |  | 46 |  |
| Income from discontinued operations, net of income taxes |  | $ | 251 |  |  | $ | 530 |  |

[0001571996-22-000031:notes:17]
[same as prior period, unchanged from 0001571996-22-000021:notes:17]

[0001571996-22-000031:notes:18]
The table above reflects the offsetting effects of historical intercompany transactions which are presented on a gross basis within continuing operations on the Condensed Consolidated Statements of Income.

[0001571996-22-000031:notes:19]
The following table presents significant cash flow items from discontinued operations for the six months ended July 30, 2021 included within the Condensed Consolidated Statements of Cash Flows:

[0001571996-22-000031:notes:20]
|  |  |  |  | Six Months Ended |
|  |  |  |  | July 30, 2021 |
|  |  |  |  | (in millions) |
| Depreciation and amortization |  |  |  | $ | 670 |  |
| Capital expenditures |  |  |  | $ | 160 |  |
| Stock-based compensation expense |  |  |  | $ | 556 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001571996-22-000031:notes:21]
[same as prior period, unchanged from 0001571996-22-000021:notes:21]

[0001571996-22-000031:notes:22]
|  | July 29, 2022 |  | January 28, 2022 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | Quoted Prices in Active Markets for Identical Assets |  | Significant Other Observable Inputs |  | Significant Unobservable Inputs |  |  |  | Quoted Prices in Active Markets for Identical Assets |  | Significant Other Observable Inputs |  | Significant Unobservable Inputs |  |  |
|  | (in millions) |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | $ | 1,089 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,089 |  |  | $ | 3,737 |  |  | $ | — |  |  | $ | — |  |  | $ | 3,737 |  |
| Marketable equity and other securities | 25 |  |  | — |  |  | — |  |  | 25 |  |  | 86 |  |  | — |  |  | — |  |  | 86 |  |
| Derivative instruments | — |  |  | 634 |  |  | — |  |  | 634 |  |  | — |  |  | 253 |  |  | — |  |  | 253 |  |
| Total assets | $ | 1,114 |  |  | $ | 634 |  |  | $ | — |  |  | $ | 1,748 |  |  | $ | 3,823 |  |  | $ | 253 |  |  | $ | — |  |  | $ | 4,076 |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Derivative instruments | $ | — |  |  | $ | 108 |  |  | $ | — |  |  | $ | 108 |  |  | $ | — |  |  | $ | 138 |  |  | $ | — |  |  | $ | 138 |  |
| Total liabilities | $ | — |  |  | $ | 108 |  |  | $ | — |  |  | $ | 108 |  |  | $ | — |  |  | $ | 138 |  |  | $ | — |  |  | $ | 138 |  |

[0001571996-22-000031:notes:23]
[same as prior period, unchanged from 0001571996-22-000021:notes:23]

[0001571996-22-000031:notes:24]
[same as prior period, unchanged from 0001571996-22-000021:notes:24]

[0001571996-22-000031:notes:25]
[same as prior period, unchanged from 0001571996-22-000021:notes:25]

[0001571996-22-000031:notes:26]
[same as prior period, unchanged from 0001571996-22-000021:notes:26]

[0001571996-22-000031:notes:27]
Deferred Compensation Plans —The Company offers deferred compensation plans for eligible employees, which allow participants to defer a portion of their compensation.  Assets were the same as liabilities associated with the plans at approximately $169 million and $192 million as of July 29, 2022 and January 28, 2022, respectively, and are included in other assets and other liabilities on the Condensed Consolidated Statements of Financial Position.  The net impact to the Condensed Consolidated Statements of Income is not material since changes in the fair value of the assets substantially offset changes in the fair value of the liabilities.  As such, assets and liabilities associated with these plans have not been included in the recurring fair value table above.

[0001571996-22-000031:notes:28]
[same as prior period, unchanged from 0001571996-22-000021:notes:28]

[0001571996-22-000031:notes:29]
As of July 29, 2022 and January 28, 2022, the Company held strategic investments in non-marketable equity and other securities of $1.3 billion and $1.4 billion, respectively.  As these investments represent early-stage companies without readily determinable fair values, they are not included in the recurring fair value table above.  See Note 4 of the Notes to the Condensed Consolidated Financial Statements for additional information about our strategic investments.

[0001571996-22-000031:notes:30]
[same as prior period, unchanged from 0001571996-22-000021:notes:30]

[0001571996-22-000031:notes:31]
|  | July 29, 2022 |  | January 28, 2022 |
|  | Carrying Value |  | Fair Value |  | Carrying Value |  | Fair Value |
|  | (in billions) |
| Senior Notes | $ | 16.2 |  |  | $ | 16.7 |  |  | $ | 16.1 |  |  | $ | 18.5 |  |
| Legacy Notes and Debentures | $ | 0.8 |  |  | $ | 1.0 |  |  | $ | 0.8 |  |  | $ | 1.1 |  |

[0001571996-22-000031:notes:32]
[same as prior period, unchanged from 0001571996-22-000021:notes:32]


## us-gaap:InvestmentTextBlock

[0001571996-22-000031:notes:33]
INVESTMENTS
The Company has strategic investments in equity and other securities as well as investments in fixed income debt securities.   All equity and other securities as well as long-term fixed income debt securities are recorded as long-term investments in the Condensed Consolidated Statements of Financial Position.  Short-term fixed income debt securities are recorded as other current assets in the Condensed Consolidated Statements of Financial Position.

[0001571996-22-000031:notes:34]
As of July 29, 2022 and January 28, 2022, total investments were $1.6 billion and $1.8 billion, respectively.

[0001571996-22-000031:notes:35]
[same as prior period, unchanged from 0001571996-22-000021:notes:34]

[0001571996-22-000031:notes:36]
[same as prior period, unchanged from 0001571996-22-000021:notes:35]

[0001571996-22-000031:notes:37]
[same as prior period, unchanged from 0001571996-22-000021:notes:36]

[0001571996-22-000031:notes:38]
[same as prior period, unchanged from 0001571996-22-000021:notes:37]

[0001571996-22-000031:notes:39]
|  | July 29, 2022 |  | January 28, 2022 |
|  | Cost |  | Unrealized Gain |  | Unrealized Loss |  | Carrying Value |  | Cost |  | Unrealized Gain |  | Unrealized Loss |  | Carrying Value |
|  | (in millions) |
| Marketable | $ | 29 |  |  | $ | 22 |  |  | $ | (26) |  |  | $ | 25 |  |  | $ | 126 |  |  | $ | 79 |  |  | $ | (119) |  |  | $ | 86 |  |
| Non-marketable | 691 |  |  | 961 |  |  | (385) |  |  | 1,267 |  |  | 593 |  |  | 900 |  |  | (52) |  |  | 1,441 |  |
| Total equity and other securities | $ | 720 |  |  | $ | 983 |  |  | $ | (411) |  |  | $ | 1,292 |  |  | $ | 719 |  |  | $ | 979 |  |  | $ | (171) |  |  | $ | 1,527 |  |

[0001571996-22-000031:notes:40]
[same as prior period, unchanged from 0001571996-22-000021:notes:39]

[0001571996-22-000031:notes:41]
[same as prior period, unchanged from 0001571996-22-000021:notes:40]

[0001571996-22-000031:notes:42]
|  | Three Months Ended |  | Six Months Ended |
|  | July 29, 2022 |  | July 30, 2021 |  | July 29, 2022 |  | July 30, 2021 |
|  | (in millions) |
| Marketable securities |  |  |  |  |  |  |  |
| Unrealized gain | $ | 7 |  |  | $ | 110 |  |  | $ | 7 |  |  | $ | 126 |  |
| Unrealized loss | (1) |  |  | — |  |  | (19) |  |  | (8) |  |
| Net unrealized gain (loss) | 6 |  |  | 110 |  |  | (12) |  |  | 118 |  |
| Non-marketable securities |  |  |  |  |  |  |  |
| Unrealized gain | 51 |  |  | 62 |  |  | 72 |  |  | 244 |  |
| Unrealized loss | (320) |  |  | (21) |  |  | (320) |  |  | (98) |  |
| Net unrealized gain (loss) (a) (b) | (269) |  |  | 41 |  |  | (248) |  |  | 146 |  |
| Net unrealized gain (loss) on equity and other securities | $ | (263) |  |  | $ | 151 |  |  | $ | (260) |  |  | $ | 264 |  |

[0001571996-22-000031:notes:43]
(a)    For the three and six months ended July 29, 2022, net unrealized losses on non-marketable securities was primarily attributable to the recognition of $310 million of impairments on equity and other securities, which was generally in line with extended public equity market declines.  In evaluating these investments for impairment, the Company used inputs including pre- and post-money valuations of recent financing events and the impact of those events on its fully diluted ownership percentages, as well as other available information regarding the issuer’s historical and forecasted performance.

[0001571996-22-000031:notes:44]
(b)  For the three and six months ended July 30, 2021, net unrealized gains on non-marketable securities were due to upward adjustments for observable price changes offset by losses primarily attributable to downward adjustments for observable price changes.

[0001571996-22-000031:notes:45]
[same as prior period, unchanged from 0001571996-22-000021:notes:43]

[0001571996-22-000031:notes:46]
[same as prior period, unchanged from 0001571996-22-000021:notes:44]

[0001571996-22-000031:notes:47]
[same as prior period, unchanged from 0001571996-22-000021:notes:45]

[0001571996-22-000031:notes:48]
|  | July 29, 2022 |  | January 28, 2022 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Loss |  | Carrying Value |  | Amortized Cost |  | Unrealized Gains |  | Unrealized Loss |  | Carrying Value |
|  | (in millions) |
| Fixed income debt securities | $ | 338 |  |  | $ | 34 |  |  | $ | (83) |  |  | $ | 289 |  |  | $ | 333 |  |  | $ | 26 |  |  | $ | (47) |  |  | $ | 312 |  |


## dell:CreditLossFinancialInstrumentLeasesDebtVariableInterestEntitiesAndCustomerReceivablesSalesTextBlock

[0001571996-22-000031:notes:49]
FINANCIAL SERVICES
The Company offers or arranges various financing options and services and alternative payment structures for its customers globally primarily through Dell Financial Services and its affiliates (“DFS”).  The Company also arranges financing for some of its customers in various countries where DFS does not currently operate as a captive enterprise.  The key activities of DFS include originating, collecting, and servicing customer financing arrangements primarily related to the purchase or use of Dell Technologies products and services.  In some cases, DFS also offers financing for the purchase of third-party technology products that complement the Dell Technologies portfolio of products and services.  New financing originations were $2.3 billion and $1.9 billion for the three months ended July 29, 2022 and July 30, 2021, respectively, and $4.4 billion and $3.8 billion for the six months ended July 29, 2022 and July 30, 2021, respectively.

[0001571996-22-000031:notes:50]
The Company’s lease and loan arrangements with customers are aggregated primarily into the following categories:

[0001571996-22-000031:notes:51]
Revolving loans — Revolving loans offered under private label credit financing programs provide qualified customers with a revolving credit line for the purchase of products and services offered by Dell Technologies.  These private label credit financing programs are referred to as Dell Preferred Account (“DPA”) and Dell Business Credit (“DBC”).  The DPA product is primarily offered to individual consumer customers, and the DBC product is primarily offered to small and medium-sized commercial customers.  Revolving loans in the United States bear interest at a variable annual percentage rate that is tied to the prime rate.  Based on historical payment patterns, revolving loan transactions are typically repaid within twelve months on average.  Due to the short-term nature of the revolving loan portfolio, the carrying value of the portfolio approximates fair value.

[0001571996-22-000031:notes:52]
Fixed-term leases and loans — The Company enters into financing arrangements with customers who seek lease financing for equipment.  DFS leases are generally classified as sales-type leases or operating leases.  Leases with business customers have fixed terms of generally two to four years.

[0001571996-22-000031:notes:53]
The Company also offers fixed-term loans to qualified small businesses, large commercial accounts, governmental organizations, educational entities, and certain individual consumer customers.  These loans are repaid in equal payments including interest and have defined terms of generally three to five years.  The fair value of the fixed-term loan portfolio is determined using market observable inputs.  The carrying value of these loans approximates fair value.

[0001571996-22-000031:notes:54]
The Company further strengthens customer relationships through flexible consumption models, which enable the Company to offer its customers the option to pay over time and, in certain cases, based on utilization, to provide them with financial flexibility to meet their changing technological requirements.

[0001571996-22-000031:notes:55]
Financing Receivables

[0001571996-22-000031:notes:56]
The following table presents the components of the Company’s financing receivables segregated by portfolio segment as of the dates indicated:

[0001571996-22-000031:notes:57]
|  | July 29, 2022 |  | January 28, 2022 |
|  | Revolving |  | Fixed-term |  | Total |  | Revolving |  | Fixed-term |  | Total |
|  | (in millions) |
| Financing receivables, net: |  |  |  |  |  |  |  |  |  |  |  |
| Customer receivables, gross (a) | $ | 705 |  |  | $ | 9,638 |  |  | $ | 10,343 |  |  | $ | 750 |  |  | $ | 9,833 |  |  | $ | 10,583 |  |
| Allowances for losses | (91) |  |  | (92) |  |  | (183) |  |  | (102) |  |  | (87) |  |  | (189) |  |
| Customer receivables, net | 614 |  |  | 9,546 |  |  | 10,160 |  |  | 648 |  |  | 9,746 |  |  | 10,394 |  |
| Residual interest | — |  |  | 150 |  |  | 150 |  |  | — |  |  | 217 |  |  | 217 |  |
| Financing receivables, net | $ | 614 |  |  | $ | 9,696 |  |  | $ | 10,310 |  |  | $ | 648 |  |  | $ | 9,963 |  |  | $ | 10,611 |  |
| Short-term | $ | 614 |  |  | $ | 4,246 |  |  | $ | 4,860 |  |  | $ | 648 |  |  | $ | 4,441 |  |  | $ | 5,089 |  |
| Long-term | $ | — |  |  | $ | 5,450 |  |  | $ | 5,450 |  |  | $ | — |  |  | $ | 5,522 |  |  | $ | 5,522 |  |

[0001571996-22-000031:notes:58]
(a)    Customer receivables, gross include amounts due from customers under revolving loans, fixed-term loans, fixed-term sales-type or direct financing leases, and accrued interest.

[0001571996-22-000031:notes:59]
The following table presents the changes in allowance for financing receivable losses for the periods indicated:

[0001571996-22-000031:notes:60]
|  | Three Months Ended |
|  | July 29, 2022 |  | July 30, 2021 |
|  | Revolving |  | Fixed-term |  | Total |  | Revolving |  | Fixed-term |  | Total |
|  | (in millions) |
| Allowance for financing receivable losses: |  |  |  |  |  |  |  |  |  |  |  |
| Balances at beginning of period | $ | 94 |  |  | $ | 87 |  |  | $ | 181 |  |  | $ | 139 |  |  | $ | 177 |  |  | $ | 316 |  |
| Charge-offs, net of recoveries | (12) |  |  | (2) |  |  | (14) |  |  | (10) |  |  | (3) |  |  | (13) |  |
| Provision charged to income statement | 9 |  |  | 7 |  |  | 16 |  |  | (3) |  |  | (13) |  |  | (16) |  |
| Balances at end of period | $ | 91 |  |  | $ | 92 |  |  | $ | 183 |  |  | $ | 126 |  |  | $ | 161 |  |  | $ | 287 |  |

[0001571996-22-000031:notes:61]
|  | Six Months Ended |
|  | July 29, 2022 |  | July 30, 2021 |
|  | Revolving |  | Fixed-term |  | Total |  | Revolving |  | Fixed-term |  | Total |
|  | (in millions) |
| Allowance for financing receivable losses: |  |  |  |  |  |  |  |  |  |  |  |
| Balances at beginning of period | $ | 102 |  |  | $ | 87 |  |  | $ | 189 |  |  | $ | 148 |  |  | $ | 173 |  |  | $ | 321 |  |
| Charge-offs, net of recoveries | (25) |  |  | (4) |  |  | (29) |  |  | (23) |  |  | (5) |  |  | (28) |  |
| Provision charged to income statement | 14 |  |  | 9 |  |  | 23 |  |  | 1 |  |  | (7) |  |  | (6) |  |
| Balances at end of period | $ | 91 |  |  | $ | 92 |  |  | $ | 183 |  |  | $ | 126 |  |  | $ | 161 |  |  | $ | 287 |  |

[0001571996-22-000031:notes:62]
Aging

[0001571996-22-000031:notes:63]
The following table presents the aging of the Company’s customer financing receivables, gross, including accrued interest, segregated by class, as of the dates indicated:

[0001571996-22-000031:notes:64]
|  | July 29, 2022 |  | January 28, 2022 |
|  | Current |  | Past Due1 — 90 Days |  | Past Due>90 Days |  | Total |  | Current |  | Past Due1 — 90 Days |  | Past Due>90 Days |  | Total |
|  | (in millions) |
| Revolving — DPA | $ | 472 |  |  | $ | 37 |  |  | $ | 13 |  |  | $ | 522 |  |  | $ | 520 |  |  | $ | 40 |  |  | $ | 11 |  |  | $ | 571 |  |
| Revolving — DBC | 164 |  |  | 16 |  |  | 3 |  |  | 183 |  |  | 158 |  |  | 18 |  |  | 3 |  |  | 179 |  |
| Fixed-term — Consumer and Commercial | 9,343 |  |  | 271 |  |  | 24 |  |  | 9,638 |  |  | 9,444 |  |  | 345 |  |  | 44 |  |  | 9,833 |  |
| Total customer receivables, gross | $ | 9,979 |  |  | $ | 324 |  |  | $ | 40 |  |  | $ | 10,343 |  |  | $ | 10,122 |  |  | $ | 403 |  |  | $ | 58 |  |  | $ | 10,583 |  |

[0001571996-22-000031:notes:65]
Aging is likely to fluctuate as a result of the variability in volume of large transactions entered into over the period, and the administrative processes that accompany those transactions.  Aging is also impacted by the timing of the Dell Technologies fiscal period end date relative to calendar month-end customer payment due dates.  As a result of these factors, fluctuations in aging from period to period do not necessarily indicate a material change in the collectibility of the portfolio.

[0001571996-22-000031:notes:66]
Fixed-term consumer and commercial customer receivables are placed on non-accrual status if principal or interest is past due and considered delinquent, or if there is concern about collectibility of a specific customer receivable.  The receivables identified as doubtful for collectibility may be classified as current for aging purposes.  Aged revolving portfolio customer receivables identified as delinquent are charged off.

[0001571996-22-000031:notes:67]
Credit Quality

[0001571996-22-000031:notes:68]
The following tables present customer receivables, gross, including accrued interest, by credit quality indicator segregated by class, as of the dates indicated:

[0001571996-22-000031:notes:69]
|  | July 29, 2022 |
|  | Fixed-term — Consumer and Commercial |  |  |  |  |  |  |
|  | Fiscal Year of Origination |  |  |  |  |  |  |
|  | 2023 |  | 2022 |  | 2021 |  | 2020 |  | 2019 |  | Years Prior |  | Revolving — DPA |  | Revolving — DBC |  | Total |
|  | (in millions) |
| Higher | $ | 1,785 |  |  | $ | 2,347 |  |  | $ | 1,291 |  |  | $ | 578 |  |  | $ | 109 |  |  | $ | 7 |  |  | $ | 126 |  |  | $ | 46 |  |  | $ | 6,289 |  |
| Mid | 690 |  |  | 773 |  |  | 540 |  |  | 194 |  |  | 47 |  |  | 4 |  |  | 149 |  |  | 57 |  |  | 2,454 |  |
| Lower | 392 |  |  | 458 |  |  | 297 |  |  | 104 |  |  | 19 |  |  | 3 |  |  | 247 |  |  | 80 |  |  | 1,600 |  |
| Total | $ | 2,867 |  |  | $ | 3,578 |  |  | $ | 2,128 |  |  | $ | 876 |  |  | $ | 175 |  |  | $ | 14 |  |  | $ | 522 |  |  | $ | 183 |  |  | $ | 10,343 |  |

[0001571996-22-000031:notes:70]
|  | January 28, 2022 |
|  | Fixed-term — Consumer and Commercial |  |  |  |  |  |  |
|  | Fiscal Year of Origination |  |  |  |  |  |  |
|  | 2022 |  | 2021 |  | 2020 |  | 2019 |  | 2018 |  | Years Prior |  | Revolving — DPA |  | Revolving — DBC |  | Total |
|  | (in millions) |
| Higher | $ | 3,279 |  |  | $ | 1,824 |  |  | $ | 914 |  |  | $ | 221 |  |  | $ | 25 |  |  | $ | 3 |  |  | $ | 150 |  |  | $ | 46 |  |  | $ | 6,462 |  |
| Mid | 1,071 |  |  | 751 |  |  | 329 |  |  | 94 |  |  | 17 |  |  | — |  |  | 166 |  |  | 57 |  |  | 2,485 |  |
| Lower | 599 |  |  | 450 |  |  | 208 |  |  | 42 |  |  | 6 |  |  | — |  |  | 255 |  |  | 76 |  |  | 1,636 |  |
| Total | $ | 4,949 |  |  | $ | 3,025 |  |  | $ | 1,451 |  |  | $ | 357 |  |  | $ | 48 |  |  | $ | 3 |  |  | $ | 571 |  |  | $ | 179 |  |  | $ | 10,583 |  |

[0001571996-22-000031:notes:71]
The categories shown in the tables above segregate customer receivables based on the relative degrees of credit risk.  The credit quality indicators for DPA revolving accounts are measured primarily as of each quarter-end date, while all other indicators are generally updated on a periodic basis.

[0001571996-22-000031:notes:72]
For DPA revolving receivables shown in the table above, the Company makes credit decisions based on proprietary scorecards, which include the customer’s credit history, payment history, credit usage, and other credit agency-related elements.  The higher quality category includes prime accounts generally of a higher credit quality that are comparable to U.S. customer FICO scores of 720 or above.  The mid-category represents the mid-tier accounts that are comparable to U.S. customer FICO scores from 660 to 719.  The lower category is generally sub-prime and represents lower credit quality accounts that are comparable to U.S. customer FICO scores below 660.  For the DBC revolving receivables and fixed-term commercial receivables shown in the table above, an internal grading system is utilized that assigns a credit level score based on a number of considerations, including liquidity, operating performance, and industry outlook.  The grading criteria and classifications for the fixed-term products differ from those for the revolving products as loss experience varies between these product and customer groups.  The credit quality categories cannot be compared between the different classes as loss experience varies substantially between the classes.

[0001571996-22-000031:notes:73]
Leases

[0001571996-22-000031:notes:74]
The following table presents the net revenue, cost of net revenue, and gross margin recognized at the commencement date of sales-type leases for the periods indicated:

[0001571996-22-000031:notes:75]
|  | Three Months Ended |  | Six Months Ended |
|  | July 29, 2022 |  | July 30, 2021 |  | July 29, 2022 |  | July 30, 2021 |
|  | (in millions) |
| Net revenue — products | $ | 219 |  |  | $ | 194 |  |  | $ | 439 |  |  | $ | 424 |  |
| Cost of net revenue — products | 164 |  |  | 142 |  |  | 368 |  |  | 305 |  |
| Gross margin — products | $ | 55 |  |  | $ | 52 |  |  | $ | 71 |  |  | $ | 119 |  |

[0001571996-22-000031:notes:76]
The following table presents the future maturity of the Company’s fixed-term customer leases and associated financing payments, and reconciles the undiscounted cash flows to the customer receivables, gross recognized on the Condensed Consolidated Statements of Financial Position as of the date indicated:

[0001571996-22-000031:notes:77]
|  | July 29, 2022 |
|  | (in millions) |
| Fiscal 2023 (remaining six months) | $ | 1,329 |  |
| Fiscal 2024 | 1,950 |  |
| Fiscal 2025 | 1,277 |  |
| Fiscal 2026 | 659 |  |
| Fiscal 2027 and beyond | 217 |  |
| Total undiscounted cash flows | 5,432 |  |
| Fixed-term loans | 4,795 |  |
| Revolving loans | 705 |  |
| Less: Unearned income | (589) |  |
| Total customer receivables, gross | $ | 10,343 |  |

[0001571996-22-000031:notes:78]
Operating Leases

[0001571996-22-000031:notes:79]
The following table presents the components of the Company’s operating lease portfolio included in property, plant, and equipment, net as of the dates indicated:

[0001571996-22-000031:notes:80]
|  | July 29, 2022 |  | January 28, 2022 |
|  | (in millions) |
| Equipment under operating lease, gross | $ | 3,202 |  |  | $ | 2,643 |  |
| Less: Accumulated depreciation | (1,202) |  |  | (935) |  |
| Equipment under operating lease, net | $ | 2,000 |  |  | $ | 1,708 |  |

[0001571996-22-000031:notes:81]
The following table presents operating lease income related to lease payments and depreciation expense for the Company’s operating lease portfolio for the periods indicated:

[0001571996-22-000031:notes:82]
|  | Three Months Ended |  | Six Months Ended |
|  | July 29, 2022 |  | July 30, 2021 |  | July 29, 2022 |  | July 30, 2021 |
|  | (in millions) |
| Income related to lease payments | $ | 253 |  |  | $ | 167 |  |  | $ | 485 |  |  | $ | 323 |  |
| Depreciation expense | $ | 194 |  |  | $ | 127 |  |  | $ | 359 |  |  | $ | 243 |  |

[0001571996-22-000031:notes:83]
The following table presents the future payments to be received by the Company as lessor in operating lease contracts as of the date indicated:

[0001571996-22-000031:notes:84]
|  | July 29, 2022 |
|  | (in millions) |
| Fiscal 2023 (remaining six months) | $ | 469 |  |
| Fiscal 2024 | 760 |  |
| Fiscal 2025 | 512 |  |
| Fiscal 2026 | 198 |  |
| Fiscal 2027 and beyond | 64 |  |
| Total | $ | 2,003 |  |

[0001571996-22-000031:notes:85]
DFS Debt

[0001571996-22-000031:notes:86]
The Company maintains programs that facilitate the funding of leases, loans, and other alternative payment structures in the capital markets.  The majority of DFS debt is non-recourse to Dell Technologies and represents borrowings under securitization programs and structured financing programs, for which the Company’s risk of loss is limited to transferred loan and lease payments and associated equipment.

[0001571996-22-000031:notes:87]
The following table presents DFS debt as of the dates indicated and excludes the allocated portion of the Company’s other borrowings, which represents the additional amount considered to fund the DFS business:

[0001571996-22-000031:notes:88]
|  | July 29, 2022 |  | January 28, 2022 |
| DFS debt | (in millions) |
| DFS U.S. debt: |  |  |  |
| Asset-based financing and securitization facilities | $ | 2,271 |  |  | $ | 3,054 |  |
| Fixed-term securitization offerings | 3,968 |  |  | 3,011 |  |
| Other | 117 |  |  | 135 |  |
| Total DFS U.S. debt | 6,356 |  |  | 6,200 |  |
| DFS international debt: |  |  |  |
| Securitization facility | 694 |  |  | 739 |  |
| Other borrowings | 810 |  |  | 785 |  |
| Note payable | 250 |  |  | 250 |  |
| Dell Bank senior unsecured eurobonds | 1,530 |  |  | 1,672 |  |
| Total DFS international debt | 3,284 |  |  | 3,446 |  |
| Total DFS debt | $ | 9,640 |  |  | $ | 9,646 |  |
| Total short-term DFS debt | $ | 5,565 |  |  | $ | 5,803 |  |
| Total long-term DFS debt | $ | 4,075 |  |  | $ | 3,843 |  |

[0001571996-22-000031:notes:89]
DFS U.S. Debt

[0001571996-22-000031:notes:90]
Asset-Based Financing and Securitization Facilities — The Company maintains separate asset-based financing facilities and a securitization facility in the United States, which are revolving facilities for fixed-term leases and loans and for revolving loans, respectively.  This debt is collateralized solely by the U.S. loan and lease payments and associated equipment in the facilities.  The debt has a variable interest rate and the duration of the debt is based on the terms of the underlying loan and lease payment streams.  As of July 29, 2022, the total debt capacity related to the U.S. asset-based financing and securitization facilities was $5.0 billion.  The Company enters into interest swap agreements to effectively convert a portion of this debt from a floating rate to a fixed rate.  See Note 8 of the Notes to the Condensed Consolidated Financial Statements for additional information about interest rate swaps.

[0001571996-22-000031:notes:91]
The Company’s U.S. securitization facility for revolving loans is effective through June 25, 2025.  The Company’s two U.S. asset-based financing facilities for fixed-term leases and loans are effective through July 10, 2023 and June 21, 2024, respectively.

[0001571996-22-000031:notes:92]
The asset-based financing and securitization facilities contain standard structural features related to the performance of the funded receivables, which include defined credit losses, delinquencies, average credit scores, and minimum collection requirements.  In the event one or more of these criteria are not met and the Company is unable to restructure the facility, no further funding of receivables will be permitted and the timing of the Company’s expected cash flows from over-collateralization will be delayed.  As of July 29, 2022, these criteria were met.

[0001571996-22-000031:notes:93]
Fixed-Term Securitization Offerings — The Company periodically issues asset-backed debt securities under fixed-term securitization programs to private investors.  The asset-backed debt securities are collateralized solely by the U.S. fixed-term leases and loans in the offerings, which are held by Special Purpose Entities (“SPEs”), as discussed below.  The interest rate on these securities is fixed and ranges from 0.33% to 5.92% per annum, and the duration of these securities is based on the terms of the underlying lease and loan payment streams.

[0001571996-22-000031:notes:94]
DFS International Debt

[0001571996-22-000031:notes:95]
Securitization Facility — The Company maintains a securitization facility in Europe for fixed-term leases and loans.  This facility is effective through December 21, 2022 and had a total debt capacity of $816 million as of July 29, 2022.

[0001571996-22-000031:notes:96]
The securitization facility contains standard structural features related to the performance of the securitized receivables, which include defined credit losses, delinquencies, average credit scores, and minimum collection requirements.  In the event one or more of these criteria are not met and the Company is unable to restructure the program, no further funding of receivables will be permitted and the timing of the Company’s expected cash flows from over-collateralization will be delayed.  As of July 29, 2022, these criteria were met.

[0001571996-22-000031:notes:97]
Other Borrowings — In connection with the Company’s international financing operations, the Company has entered into revolving structured financing debt programs related to its fixed-term lease and loan products sold in Canada, Europe, Australia, and New Zealand.  The Canadian facility, which is collateralized solely by Canadian loan and lease payments and associated equipment, had a total debt capacity of $351 million as of July 29, 2022 and is effective through January 16, 2025.  The European facility, which is collateralized solely by European loan and lease payments and associated equipment, had a total debt capacity of $612 million as of July 29, 2022 and is effective through December 14, 2023.  The Australia and New Zealand facility, which is collateralized solely by Australia and New Zealand loan and lease payments and associated equipment, had a total debt capacity of $315 million as of July 29, 2022 and is effective through April 20, 2023.

[0001571996-22-000031:notes:98]
Note Payable — On May 25, 2022, the Company entered into an unsecured credit agreement to fund receivables in Mexico.  As of July 29, 2022, the aggregate principal amount of the note payable was $250 million.  The note bears interest at an annual rate of 4.24% and will mature on May 31, 2024.

[0001571996-22-000031:notes:99]
Dell Bank Senior Unsecured Eurobonds — On October 17, 2019, Dell Bank International D.A.C. (“Dell Bank”) issued 500 million Euro of 0.625% senior unsecured three year eurobonds due October 2022.  On June 24, 2020, Dell Bank issued 500 million Euro of 1.625% senior unsecured four year eurobonds due June 2024.  On October 27, 2021, Dell Bank issued 500 million Euro of 0.5% senior unsecured five year eurobonds due October 2026.  The issuances of the senior unsecured eurobonds support the expansion of the financing operations in Europe.

[0001571996-22-000031:notes:100]
Variable Interest Entities

[0001571996-22-000031:notes:101]
In connection with the asset-based financing facilities, securitization facilities, and fixed-term securitization offerings discussed above, the Company transfers certain U.S. and European lease and loan payments and associated equipment to SPEs that meet the definition of a VIE and are consolidated, along with the associated debt detailed above, into the Condensed Consolidated Financial Statements, as the Company is the primary beneficiary of the VIEs.  The SPEs are bankruptcy-remote legal entities with separate assets and liabilities.  The purpose of the SPEs is to facilitate the funding of customer loan and lease payments and associated equipment in the capital markets.

[0001571996-22-000031:notes:102]
Some of the SPEs have entered into financing arrangements with multi-seller conduits that, in turn, issue asset-backed debt securities in the capital markets.  DFS debt outstanding held by the consolidated VIEs is collateralized by the lease and loan payments and associated equipment.  The Company’s risk of loss related to securitized receivables is limited to the amount by which the Company’s right to receive collections for assets securitized exceeds the amount required to pay interest, principal, and fees and expenses related to the asset-backed securities.  The Company provides credit enhancement to the securitization in the form of over-collateralization.

[0001571996-22-000031:notes:103]
The following table presents the assets and liabilities held by the consolidated VIEs as of the dates indicated, which are included in the Condensed Consolidated Statements of Financial Position:

[0001571996-22-000031:notes:104]
|  | July 29, 2022 |  | January 28, 2022 |
|  | (in millions) |
| Assets held by consolidated VIEs |  |  |  |
| Other current assets | $ | 574 |  |  | $ | 535 |  |
| Financing receivables, net of allowance |  |  |  |
| Short-term | $ | 3,313 |  |  | $ | 3,368 |  |
| Long-term | $ | 3,181 |  |  | $ | 3,141 |  |
| Property, plant, and equipment, net | $ | 1,069 |  |  | $ | 945 |  |
| Liabilities held by consolidated VIEs |  |  |  |
| Debt, net of unamortized debt issuance costs |  |  |  |
| Short-term | $ | 4,469 |  |  | $ | 4,560 |  |
| Long-term | $ | 2,450 |  |  | $ | 2,235 |  |

[0001571996-22-000031:notes:105]
Lease and loan payments and associated equipment transferred via securitization through SPEs were $1.2 billion and $1.3 billion for the three months ended July 29, 2022 and July 30, 2021, respectively, and $2.9 billion and $2.7 billion for the six months ended July 29, 2022 and July 30, 2021, respectively.

[0001571996-22-000031:notes:106]
Customer Receivable Sales

[0001571996-22-000031:notes:107]
To manage certain concentrations of customer credit exposure, the Company may sell selected fixed-term customer receivables to unrelated third parties on a periodic basis, without recourse.  The amount of customer receivables sold for this purpose was $425 million and $101 million for the six months ended July 29, 2022 and July 30, 2021, respectively.  The Company’s continuing involvement in these customer receivables is primarily limited to servicing arrangements.


## us-gaap:ScheduleOfDebtTableTextBlock

[0001571996-22-000031:notes:108]
The majority of DFS debt is non-recourse to Dell Technologies and represents borrowings under securitization programs and structured financing programs, for which the Company’s risk of loss is limited to transferred loan and lease payments and associated equipment.  
The following table presents DFS debt as of the dates indicated and excludes the allocated portion of the Company’s other borrowings, which represents the additional amount considered to fund the DFS business:

[0001571996-22-000031:notes:109]
The following table summarizes the Company’s outstanding debt as of the dates indicated:

[0001571996-22-000031:notes:110]
|  | July 29, 2022 |  | January 28, 2022 |
|  | (in millions) |
| Senior Notes: |  |  |  |
| 5.45% due June 2023 | $ | 1,000 |  |  | $ | 1,000 |  |
| 4.00% due July 2024 | 1,000 |  |  | 1,000 |  |
| 5.85% due July 2025 | 1,000 |  |  | 1,000 |  |
| 6.02% due June 2026 | 4,500 |  |  | 4,500 |  |
| 4.90% due October 2026 | 1,750 |  |  | 1,750 |  |
| 6.10% due July 2027 | 500 |  |  | 500 |  |
| 5.30% due October 2029 | 1,750 |  |  | 1,750 |  |
| 6.20% due July 2030 | 750 |  |  | 750 |  |
| 8.10% due July 2036 | 1,000 |  |  | 1,000 |  |
| 3.38% due December 2041 | 1,000 |  |  | 1,000 |  |
| 8.35% due July 2046 | 800 |  |  | 800 |  |
| 3.45% due December 2051 | 1,250 |  |  | 1,250 |  |
| Legacy Notes and Debentures: |  |  |  |
| 7.10% due April 2028 | 300 |  |  | 300 |  |
| 6.50% due April 2038 | 388 |  |  | 388 |  |
| 5.40% due September 2040 | 264 |  |  | 264 |  |
| DFS Debt (Note 5) | 9,640 |  |  | 9,646 |  |
| Other | 311 |  |  | 337 |  |
| Total debt, principal amount | $ | 27,203 |  |  | $ | 27,235 |  |
| Unamortized discount, net of unamortized premium | (128) |  |  | (134) |  |
| Debt issuance costs | (141) |  |  | (147) |  |
| Total debt, carrying value | $ | 26,934 |  |  | $ | 26,954 |  |
| Total short-term debt, carrying value | $ | 6,647 |  |  | $ | 5,823 |  |
| Total long-term debt, carrying value | $ | 20,287 |  |  | $ | 21,131 |  |


## us-gaap:LesseeOperatingLeasesTextBlock

[0001571996-22-000031:notes:111]
LEASES 
The Company enters into leasing transactions in which the Company is the lessee.  These lease contracts are typically classified as operating leases.  The Company’s lease contracts are generally for office buildings used to conduct its business, and the determination of whether such contracts contain leases generally does not require significant estimates or judgments.  The Company also leases certain global logistics warehouses, employee vehicles, and equipment.  As of July 29, 2022, the remaining terms of the Company’s leases range from less than one month to approximately ten years.  As of July 29, 2022 and January 28, 2022, there were no material finance leases for which the Company was a lessee.

[0001571996-22-000031:notes:112]
The Company also enters into leasing transactions in which the Company is the lessor, primarily through customer financing arrangements offered through DFS.  DFS originates leases that are primarily classified as either sales-type leases or operating leases.  See Note 5 of the Notes to the Condensed Consolidated Financial Statements for more information on the Company’s lessor arrangements.

[0001571996-22-000031:notes:113]
[same as prior period, unchanged from 0001571996-22-000021:notes:112]

[0001571996-22-000031:notes:114]
|  | Three Months Ended |  | Six Months Ended |
|  | July 29, 2022 |  | July 30, 2021 |  | July 29, 2022 |  | July 30, 2021 |
|  | (in millions) |
| Operating lease costs | $ | 68 |  |  | $ | 86 |  |  | $ | 140 |  |  | $ | 180 |  |
| Variable costs | 23 |  |  | 21 |  |  | 48 |  |  | 47 |  |
| Total lease costs | $ | 91 |  |  | $ | 107 |  |  | $ | 188 |  |  | $ | 227 |  |

[0001571996-22-000031:notes:115]
During the six months ended July 29, 2022 and July 30, 2021, sublease income, finance lease costs, and short-term lease costs were immaterial.

[0001571996-22-000031:notes:116]
[same as prior period, unchanged from 0001571996-22-000021:notes:115]

[0001571996-22-000031:notes:117]
|  | Classification |  | July 29, 2022 |  | January 28, 2022 |  |  |
|  |  |  | (in millions, except for term and discount rate) |
| Operating lease right-of-use assets | Other non-current assets |  | $ | 784 |  | $ | 871 |  |  |
| Current operating lease liabilities | Accrued and other current liabilities |  | $ | 263 |  | $ | 287 |  |  |
| Non-current operating lease liabilities | Other non-current liabilities |  | 640 |  | 720 |  |  |
| Total operating lease liabilities |  |  | $ | 903 |  | $ | 1,007 |  |  |
| Weighted-average remaining lease term (in years) |  |  | 5.28 |  | 5.51 |  |  |
| Weighted-average discount rate |  |  | 3.15 | % |  | 3.01 | % |  |  |

[0001571996-22-000031:notes:118]
[same as prior period, unchanged from 0001571996-22-000021:notes:117]

[0001571996-22-000031:notes:119]
|  | Six Months Ended |
|  | July 29, 2022 |  | July 30, 2021 |
|  | (in millions) |
| Cash paid for amounts included in the measurement of lease liabilities — operating cash outflows from operating leases (a) | $ | 156 |  |  | $ | 257 |  |
| Right-of-use assets obtained in exchange for new operating lease liabilities | $ | 103 |  |  | $ | 115 |  |

[0001571996-22-000031:notes:120]
(a) Cash paid for amounts included in the measurement of lease liabilities - operating cash outflows from operating leases from discontinued operations was $92 million for the six months ended July 30, 2021.

[0001571996-22-000031:notes:121]
[same as prior period, unchanged from 0001571996-22-000021:notes:120]

[0001571996-22-000031:notes:122]
|  | July 29, 2022 |  |  |
|  | (in millions) |
| Fiscal 2023 (remaining six months) | $ | 133 |  |  |  |
| Fiscal 2024 | 233 |  |  |  |
| Fiscal 2025 | 169 |  |  |  |
| Fiscal 2026 | 132 |  |  |  |
| Fiscal 2027 | 104 |  |  |  |
| Thereafter | 209 |  |  |  |
| Total lease payments | 980 |  |  |  |
| Less: Imputed interest | (77) |  |  |  |
| Total | $ | 903 |  |  |  |
| Current operating lease liabilities | $ | 263 |  |  |  |
| Non-current operating lease liabilities | $ | 640 |  |  |  |

[0001571996-22-000031:notes:123]
As of July 29, 2022, the Company’s undiscounted operating leases that had not yet commenced were immaterial.


## us-gaap:DebtDisclosureTextBlock

[0001571996-22-000031:notes:124]
DEBT
The following table summarizes the Company’s outstanding debt as of the dates indicated:

[0001571996-22-000031:notes:125]
Commercial Paper Program

[0001571996-22-000031:notes:126]
On July 18, 2022, the Company established a commercial paper program under which the Company may issue unsecured notes in a maximum aggregate face amount of $5.0 billion outstanding at any time, with maturities up to 397 days from the date of issue.  The notes will be sold on customary terms in the U.S. commercial paper market on a private placement basis.  The proceeds of the notes will be used for general corporate purposes.  As of July 29, 2022, the Company had no outstanding borrowings under the commercial paper program.  Subsequent to July 29, 2022, the Company issued and subsequently repaid notes under this program.

[0001571996-22-000031:notes:127]
Outstanding Debt

[0001571996-22-000031:notes:128]
Senior Notes — The Company completed private offerings of multiple series of senior notes which were issued on June 1, 2016, June 22, 2016, March 20, 2019, April 9, 2020, and December 13, 2021 in aggregate principal amounts of $20.0 billion, $3.3 billion, $4.5 billion, $2.3 billion, and $2.3 billion respectively (together with the registered senior notes subsequently issued in exchange, the “Senior Notes”).  Interest on these borrowings is payable semiannually.

[0001571996-22-000031:notes:129]
In June 2021, Dell International L.L.C. and EMC Corporation, wholly-owned subsidiaries of Dell Technologies Inc. and issuers of the Senior Notes (the “Issuers”), completed offers to exchange any and all outstanding Senior Notes issued on June 1, 2016, March 20, 2019, and April 9, 2020 for senior notes registered under the Securities Act of 1933 having terms substantially identical to the terms of the outstanding Senior Notes.  The Issuers issued $18.4 billion aggregate principal amount of registered Senior Notes in exchange for the same aggregate principal amount of unregistered Senior Notes.  The aggregate principal amount of unregistered Senior Notes remaining outstanding following the settlement of the exchange offers was approximately $0.1 billion.

[0001571996-22-000031:notes:130]
Legacy Notes and Debentures — The Company has outstanding unsecured notes and debentures (collectively, the “Legacy Notes and Debentures”) that were issued by Dell Inc. (“Dell”), a wholly-owned subsidiary of Dell Technologies Inc., prior to the acquisition of Dell by Dell Technologies Inc. in the going-private transaction that closed in October 2013.  Interest on these borrowings is payable semiannually.

[0001571996-22-000031:notes:131]
DFS Debt — See Note 5 and Note 8 of the Notes to the Condensed Consolidated Financial Statements, respectively, for discussion of DFS debt and the interest rate swap agreements that hedge a portion of that debt.

[0001571996-22-000031:notes:132]
2021 Revolving Credit Facility — The Company’s revolving credit facility, which was entered into on November 1, 2021 (the “2021 Revolving Credit Facility”), matures on November 1, 2026.  This facility provides the Company with revolving commitments in an aggregate principal amount of $5.0 billion for general corporate purposes, including liquidity support for the Company’s commercial paper program, and includes a letter of credit sub-facility of up to $0.5 billion and a swing-line loan sub-facility of up to $0.5 billion.  The 2021 Revolving Credit Facility also allows the Company to obtain incremental additional commitments on one or more occasions in minimum amounts of $10 million.

[0001571996-22-000031:notes:133]
Borrowings under the 2021 Revolving Credit Facility bear interest at a rate per annum equal to an applicable margin plus, at the borrowers’ option, either (a) the specified London Interbank Offered Rate (“LIBOR”) or (b) a base rate.  The margin applicable to LIBOR and base rate borrowings varies based upon the Company’s existing date ratings.  The base rate is calculated based upon the greatest of the specified prime rate, the specified federal reserve bank rate, or LIBOR plus 1%.

[0001571996-22-000031:notes:134]
The borrowers may voluntarily repay outstanding loans under the 2021 Revolving Credit Facility at any time without premium or penalty, other than customary breakage costs.

[0001571996-22-000031:notes:135]
As of July 29, 2022, available borrowings under the 2021 Revolving Credit Facility totaled $5.0 billion.

[0001571996-22-000031:notes:136]
Covenants — The credit agreement governing the 2021 Revolving Credit Facility and the indentures governing the Senior Notes and the Legacy Notes and Debentures impose various limitations, subject to exceptions, on creating certain liens and entering into sale and lease-back transactions.  The foregoing credit agreement and indentures contain customary events of default, including failure to make required payments, failure to comply with covenants, and the occurrence of certain events of bankruptcy and insolvency.  The 2021 Revolving Credit Facility is also subject to an interest coverage ratio covenant that is tested at the end of each fiscal quarter with respect to the Company’s preceding four fiscal quarters.  The Company was in compliance with this financial covenant as of July 29, 2022.

[0001571996-22-000031:notes:137]
Aggregate Future Maturities

[0001571996-22-000031:notes:138]
The following table presents the aggregate future maturities of the Company’s debt as of July 29, 2022 for the periods indicated:

[0001571996-22-000031:notes:139]
|  | Maturities by Fiscal Year |
|  | 2023 (remaining six months) |  | 2024 |  | 2025 |  | 2026 |  | 2027 |  | Thereafter |  | Total |
|  | (in millions) |
| Senior Notes | $ | — |  |  | $ | 1,000 |  |  | $ | 1,000 |  |  | $ | 1,000 |  |  | $ | 6,250 |  |  | $ | 7,050 |  |  | $ | 16,300 |  |
| Legacy Notes and Debentures | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 952 |  |  | 952 |  |
| DFS Debt | 3,538 |  |  | 3,027 |  |  | 2,245 |  |  | 263 |  |  | 565 |  |  | 2 |  |  | 9,640 |  |
| Other | 21 |  |  | 161 |  |  | 107 |  |  | 20 |  |  | 1 |  |  | 1 |  |  | 311 |  |
| Total maturities, principal amount | 3,559 |  |  | 4,188 |  |  | 3,352 |  |  | 1,283 |  |  | 6,816 |  |  | 8,005 |  |  | 27,203 |  |
| Associated carrying value adjustments | (3) |  |  | (7) |  |  | (10) |  |  | (8) |  |  | (54) |  |  | (187) |  |  | (269) |  |
| Total maturities, carrying value amount | $ | 3,556 |  |  | $ | 4,181 |  |  | $ | 3,342 |  |  | $ | 1,275 |  |  | $ | 6,762 |  |  | $ | 7,818 |  |  | $ | 26,934 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001571996-22-000031:notes:140]
[same as prior period, unchanged from 0001571996-22-000021:notes:137]

[0001571996-22-000031:notes:141]
[same as prior period, unchanged from 0001571996-22-000021:notes:138]

[0001571996-22-000031:notes:142]
[same as prior period, unchanged from 0001571996-22-000021:notes:139]

[0001571996-22-000031:notes:143]
[same as prior period, unchanged from 0001571996-22-000021:notes:140]

[0001571996-22-000031:notes:144]
During three and six months ended July 29, 2022 and July 30, 2021, the Company did not discontinue any cash flow hedges related to foreign exchange contracts that had a material impact on the Company’s results of operations due to the probability that the forecasted cash flows would not occur.

[0001571996-22-000031:notes:145]
[same as prior period, unchanged from 0001571996-22-000021:notes:142]

[0001571996-22-000031:notes:146]
[same as prior period, unchanged from 0001571996-22-000021:notes:143]

[0001571996-22-000031:notes:147]
[same as prior period, unchanged from 0001571996-22-000021:notes:144]

[0001571996-22-000031:notes:148]
[same as prior period, unchanged from 0001571996-22-000021:notes:145]

[0001571996-22-000031:notes:149]
[same as prior period, unchanged from 0001571996-22-000021:notes:146]

[0001571996-22-000031:notes:150]
The Company utilizes cross-currency amortizing swaps to hedge the currency and interest rate risk exposure associated with the European securitization program.  The cross-currency swaps combine a Euro-based interest rate swap with a British Pound or U.S. Dollar foreign exchange forward contract in which the Company pays a fixed or floating British Pound or U.S. Dollar amount and receives a fixed or floating amount in Euros linked to the one-month Euribor.  The notional value of the swaps amortizes in line with the expected cash flows and run-off of the securitized assets.  The swaps are not designated for hedge accounting and expire within five years or less.

[0001571996-22-000031:notes:151]
[same as prior period, unchanged from 0001571996-22-000021:notes:148]

[0001571996-22-000031:notes:152]
[same as prior period, unchanged from 0001571996-22-000021:notes:149]

[0001571996-22-000031:notes:153]
|  | July 29, 2022 |  | January 28, 2022 |
|  | (in millions) |
| Foreign exchange contracts: |  |  |  |
| Designated as cash flow hedging instruments | $ | 8,653 |  |  | $ | 7,879 |  |
| Non-designated as hedging instruments | 6,470 |  |  | 8,713 |  |
| Total | $ | 15,123 |  |  | $ | 16,592 |  |
| Interest rate contracts: |  |  |  |
| Non-designated as hedging instruments | $ | 5,637 |  |  | $ | 6,715 |  |

[0001571996-22-000031:notes:154]
The following tables present the effect of derivative instruments designated as hedging instruments on the Condensed Consolidated Statements of Financial Position and the Condensed Consolidated Statements of Income for the periods indicated:

[0001571996-22-000031:notes:155]
| Derivatives in Cash Flow Hedging Relationships |  | Gain (Loss) Recognized in Accumulated OCI, Net of Tax, on Derivatives |  | Location of Gain (Loss) Reclassified from Accumulated OCI into Income |  | Gain (Loss) Reclassified from Accumulated OCI into Income |
|  |  | (in millions) |  |  |  | (in millions) |
| For the three months ended July 29, 2022 |
|  |  |  |  | Total net revenue |  | $ | 307 |  |
| Foreign exchange contracts |  | $ | 166 |  |  | Total cost of net revenue |  | (1) |  |
| Interest rate contracts |  | — |  |  | Interest and other, net |  | — |  |
| Total |  | $ | 166 |  |  |  |  | $ | 306 |  |
| For the three months ended July 30, 2021 |
|  |  |  |  | Total net revenue |  | $ | (7) |  |
| Foreign exchange contracts |  | $ | 65 |  |  | Total cost of net revenue |  | (7) |  |
| Interest rate contracts |  | — |  |  | Interest and other, net |  | — |  |
| Total |  | $ | 65 |  |  | Income from discontinued operations |  | $ | 1 |  |
|  |  |  |  | Total |  | $ | (13) |  |

[0001571996-22-000031:notes:156]
| Derivatives in Cash Flow Hedging Relationships |  | Gain (Loss) Recognized in Accumulated OCI, Net of Tax, on Derivatives |  | Location of Gain (Loss) Reclassified from Accumulated OCI into Income |  | Gain (Loss) Reclassified from Accumulated OCI into Income |
|  |  | (in millions) |  |  |  | (in millions) |
| For the six months ended July 29, 2022 |
|  |  |  |  | Total net revenue |  | 430 |  |
| Foreign exchange contracts |  | 538 |  |  | Total cost of net revenue |  | (28) |  |
| Interest rate contracts |  | — |  |  | Interest and other, net |  | — |  |
| Total |  | $ | 538 |  |  | Total |  | $ | 402 |  |
| For the six months ended July 30, 2021 |
|  |  |  |  | Total net revenue |  | $ | (37) |  |
| Foreign exchange contracts |  | $ | 64 |  |  | Total cost of net revenue |  | (5) |  |
| Interest rate contracts |  | — |  |  | Interest and other, net |  | — |  |
| Total |  | $ | 64 |  |  | Income from discontinued operations |  | $ | 2 |  |
|  |  |  |  | Total |  | $ | (40) |  |

[0001571996-22-000031:notes:157]
[same as prior period, unchanged from 0001571996-22-000021:notes:153]

[0001571996-22-000031:notes:158]
|  | Three Months Ended |  | Six Months Ended |  |  |
|  | July 29, 2022 |  | July 30, 2021 |  | July 29, 2022 |  | July 30, 2021 |  | Location of Gain (Loss) Recognized |
|  | (in millions) |  |  |
| Foreign exchange contracts | $ | (74) |  |  | $ | (143) |  |  | $ | (305) |  |  | $ | (172) |  |  | Interest and other, net |
| Interest rate contracts | 1 |  |  | (4) |  |  | 18 |  |  | (3) |  |  | Interest and other, net |
| Foreign exchange contracts | — |  |  | 10 |  |  | — |  |  | 15 |  |  | Income from discontinued operations |
| Total | $ | (73) |  |  | $ | (137) |  |  | $ | (287) |  |  | $ | (160) |  |  |  |

[0001571996-22-000031:notes:159]
The Company presents its foreign exchange derivative instruments on a net basis in the Condensed Consolidated Statements of Financial Position due to the right of offset by its counterparties under master netting arrangements.  The following tables present the fair value of those derivative instruments presented on a gross basis as of the dates indicated:

[0001571996-22-000031:notes:160]
|  | July 29, 2022 |
|  | Other CurrentAssets |  | Other Non-Current Assets |  | Other CurrentLiabilities |  | Other Non-CurrentLiabilities |  | TotalFair Value |
|  | (in millions) |
| Derivatives designated as hedging instruments: |
| Foreign exchange contracts in an asset position | $ | 255 |  |  | $ | — |  |  | $ | 20 |  |  | $ | — |  |  | $ | 275 |  |
| Foreign exchange contracts in a liability position | (14) |  |  | — |  |  | (5) |  |  | — |  |  | (19) |  |
| Net asset | 241 |  |  | — |  |  | 15 |  |  | — |  |  | 256 |  |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts in an asset position | 673 |  |  | 1 |  |  | 68 |  |  | — |  |  | 742 |  |
| Foreign exchange contracts in a liability position | (368) |  |  | — |  |  | (124) |  |  | (4) |  |  | (496) |  |
| Interest rate contracts in an asset position | 5 |  |  | 82 |  |  | — |  |  | — |  |  | 87 |  |
| Interest rate contracts in a liability position | — |  |  | — |  |  | (1) |  |  | (62) |  |  | (63) |  |
| Net asset (liability) | 310 |  |  | 83 |  |  | (57) |  |  | (66) |  |  | 270 |  |
| Total derivatives at fair value | $ | 551 |  |  | $ | 83 |  |  | $ | (42) |  |  | $ | (66) |  |  | $ | 526 |  |
|  | January 28, 2022 |
|  | Other CurrentAssets |  | Other Non-Current Assets |  | Other CurrentLiabilities |  | Other Non-CurrentLiabilities |  | TotalFair Value |
|  | (in millions) |
| Derivatives designated as hedging instruments: |
| Foreign exchange contracts in an asset position | $ | 135 |  |  | $ | — |  |  | $ | 50 |  |  | $ | — |  |  | $ | 185 |  |
| Foreign exchange contracts in a liability position | (5) |  |  | — |  |  | (8) |  |  | — |  |  | (13) |  |
| Net asset | 130 |  |  | — |  |  | 42 |  |  | — |  |  | 172 |  |
| Derivatives not designated as hedging instruments: |
| Foreign exchange contracts in an asset position | 280 |  |  | 2 |  |  | 106 |  |  | — |  |  | 388 |  |
| Foreign exchange contracts in a liability position | (189) |  |  | — |  |  | (244) |  |  | (5) |  |  | (438) |  |
| Interest rate contracts in an asset position | — |  |  | 30 |  |  | — |  |  | — |  |  | 30 |  |
| Interest rate contracts in a liability position | — |  |  | — |  |  | — |  |  | (37) |  |  | (37) |  |
| Net asset (liability) | 91 |  |  | 32 |  |  | (138) |  |  | (42) |  |  | (57) |  |
| Total derivatives at fair value | $ | 221 |  |  | $ | 32 |  |  | $ | (96) |  |  | $ | (42) |  |  | $ | 115 |  |

[0001571996-22-000031:notes:161]
[same as prior period, unchanged from 0001571996-22-000021:notes:157]

[0001571996-22-000031:notes:162]
|  | July 29, 2022 |
|  | Gross Amounts of Recognized Assets/ (Liabilities) |  | Gross Amounts Offset in the Statement of Financial Position |  | Net Amounts of Assets/ (Liabilities) Presented in the Statement of Financial Position |  | Gross Amounts not Offset in the Statement of Financial Position |  | Net Amount of Assets/ (Liabilities) Recognized in the Statement of Financial Position |
|  | Financial Instruments |  | Cash Collateral Received or Pledged |  |
|  | (in millions) |
| Derivative instruments: |  |  |  |  |  |  |  |  |  |  |  |
| Financial assets | $ | 1,104 |  |  | $ | (470) |  |  | $ | 634 |  |  | $ | — |  |  | $ | — |  |  | $ | 634 |  |
| Financial liabilities | (578) |  |  | 470 |  |  | (108) |  |  | — |  |  | 48 |  |  | (60) |  |
| Total derivative instruments | $ | 526 |  |  | $ | — |  |  | $ | 526 |  |  | $ | — |  |  | $ | 48 |  |  | $ | 574 |  |
|  | January 28, 2022 |
|  | Gross Amounts of Recognized Assets/ (Liabilities) |  | Gross Amounts Offset in the Statement of Financial Position |  | Net Amounts of Assets/ (Liabilities) Presented in the Statement of Financial Position |  | Gross Amounts not Offset in the Statement of Financial Position |  | Net Amount of Assets/ (Liabilities) Recognized in the Statement of Financial Position |
|  | Financial Instruments |  | Cash Collateral Received or Pledged |  |
|  | (in millions) |
| Derivative instruments: |  |  |  |  |  |  |  |  |  |  |  |
| Financial assets | $ | 603 |  |  | $ | (350) |  |  | $ | 253 |  |  | $ | — |  |  | $ | — |  |  | $ | 253 |  |
| Financial liabilities | (488) |  |  | 350 |  |  | (138) |  |  | — |  |  | 24 |  |  | (114) |  |
| Total derivative instruments | $ | 115 |  |  | $ | — |  |  | $ | 115 |  |  | $ | — |  |  | $ | 24 |  |  | $ | 139 |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001571996-22-000031:notes:163]
[same as prior period, unchanged from 0001571996-22-000021:notes:159]

[0001571996-22-000031:notes:164]
[same as prior period, unchanged from 0001571996-22-000021:notes:160]

[0001571996-22-000031:notes:165]
[same as prior period, unchanged from 0001571996-22-000021:notes:161]

[0001571996-22-000031:notes:166]
|  | Infrastructure Solutions Group |  | Client Solutions Group |  | Other Businesses |  | Total |
|  | (in millions) |
| Balances as of January 28, 2022 | $ | 15,106 |  |  | $ | 4,237 |  |  | $ | 427 |  |  | $ | 19,770 |  |
| Impact of foreign currency translation and other | (260) |  |  | (5) |  |  | — |  |  | (265) |  |
| Balances as of July 29, 2022 | $ | 14,846 |  |  | $ | 4,232 |  |  | $ | 427 |  |  | $ | 19,505 |  |

[0001571996-22-000031:notes:167]
[same as prior period, unchanged from 0001571996-22-000021:notes:163]

[0001571996-22-000031:notes:168]
[same as prior period, unchanged from 0001571996-22-000021:notes:164]

[0001571996-22-000031:notes:169]
|  | July 29, 2022 |  | January 28, 2022 |
|  | Gross |  | AccumulatedAmortization |  | Net |  | Gross |  | AccumulatedAmortization |  | Net |
|  | (in millions) |
| Customer relationships | $ | 16,956 |  |  | $ | (14,205) |  |  | $ | 2,751 |  |  | $ | 16,956 |  |  | $ | (13,938) |  |  | $ | 3,018 |  |
| Developed technology | 9,633 |  |  | (8,609) |  |  | 1,024 |  |  | 9,635 |  |  | (8,405) |  |  | 1,230 |  |
| Trade names | 885 |  |  | (773) |  |  | 112 |  |  | 885 |  |  | (757) |  |  | 128 |  |
| Definite-lived intangible assets | 27,474 |  |  | (23,587) |  |  | 3,887 |  |  | 27,476 |  |  | (23,100) |  |  | 4,376 |  |
| Indefinite-lived trade names | 3,085 |  |  | — |  |  | 3,085 |  |  | 3,085 |  |  | — |  |  | 3,085 |  |
| Total intangible assets | $ | 30,559 |  |  | $ | (23,587) |  |  | $ | 6,972 |  |  | $ | 30,561 |  |  | $ | (23,100) |  |  | $ | 7,461 |  |

[0001571996-22-000031:notes:170]
Amortization expense related to definite-lived intangible assets was $244 million and $442 million for the three months ended July 29, 2022 and July 30, 2021, respectively, and $487 million and $887 million for the six months ended July 29, 2022 and July 30, 2021, respectively.  There were no material impairment charges related to intangible assets during the three or six months ended July 29, 2022 and July 30, 2021.

[0001571996-22-000031:notes:171]
[same as prior period, unchanged from 0001571996-22-000021:notes:167]

[0001571996-22-000031:notes:172]
|  | July 29, 2022 |
|  | (in millions) |
| Fiscal 2023 (remaining six months) | $ | 488 |  |
| Fiscal 2024 | 776 |  |
| Fiscal 2025 | 607 |  |
| Fiscal 2026 | 474 |  |
| Fiscal 2027 | 361 |  |
| Thereafter | 1,181 |  |
| Total | $ | 3,887 |  |

[0001571996-22-000031:notes:173]
[same as prior period, unchanged from 0001571996-22-000021:notes:169]

[0001571996-22-000031:notes:174]
[same as prior period, unchanged from 0001571996-22-000021:notes:170]

[0001571996-22-000031:notes:175]
[same as prior period, unchanged from 0001571996-22-000021:notes:171]

[0001571996-22-000031:notes:176]
[same as prior period, unchanged from 0001571996-22-000021:notes:172]

[0001571996-22-000031:notes:177]
The fair value of the indefinite-lived trade names is generally estimated using discounted cash flow methodologies.  These methodologies require significant judgment, including estimation of future revenue, the estimation of the long-term revenue growth rate of the Company’s business and the determination of the Company’s weighted average cost of capital and royalty rates.  Changes in these estimates and assumptions could materially affect the fair value of the indefinite-lived intangible assets, potentially resulting in a non-cash impairment charge.

[0001571996-22-000031:notes:178]
Based on the results of the annual impairment test performed during the fiscal year ended January 28, 2022, the fair values of each of the reporting units exceeded their carrying values.  The Company did not recognize any material impairments during the six months ended July 29, 2022.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001571996-22-000031:notes:179]
[same as prior period, unchanged from 0001571996-22-000021:notes:175]

[0001571996-22-000031:notes:180]
[same as prior period, unchanged from 0001571996-22-000021:notes:176]

[0001571996-22-000031:notes:181]
|  | Three Months Ended |  | Six Months Ended |
|  | July 29, 2022 |  | July 30, 2021 |  | July 29, 2022 |  | July 30, 2021 |
|  | (in millions) |
| Deferred revenue: |  |  |  |  |  |  |  |
| Deferred revenue at beginning of period | $ | 27,403 |  |  | $ | 26,282 |  |  | $ | 27,573 |  |  | $ | 25,592 |  |
| Revenue deferrals | 5,572 |  |  | 5,281 |  |  | 10,547 |  |  | 10,560 |  |
| Revenue recognized | (4,950) |  |  | (4,740) |  |  | (9,930) |  |  | (9,329) |  |
| Other (a) | — |  |  | (155) |  |  | (165) |  |  | (155) |  |
| Deferred revenue at end of period | $ | 28,025 |  |  | $ | 26,668 |  |  | $ | 28,025 |  |  | $ | 26,668 |  |
| Short-term deferred revenue | $ | 14,724 |  |  | $ | 13,765 |  |  | $ | 14,724 |  |  | $ | 13,765 |  |
| Long-term deferred revenue | $ | 13,301 |  |  | $ | 12,903 |  |  | $ | 13,301 |  |  | $ | 12,903 |  |

[0001571996-22-000031:notes:182]
(a)    For the six months ended July 29, 2022, Other represents the reclassification of deferred revenue to accrued and other liabilities.  For the three and six months ended July 30, 2021, Other consists of divested deferred revenue from the sale of Boomi.

[0001571996-22-000031:notes:183]
Remaining Performance Obligations — Remaining performance obligations represent the aggregate amount of the transaction price allocated to performance obligations not delivered, or partially undelivered, as of the end of the reporting period.  Remaining performance obligations include deferred revenue plus unbilled amounts not yet recorded in deferred revenue.  The value of the transaction price allocated to remaining performance obligations as of July 29, 2022 was approximately $41 billion.  The Company expects to recognize approximately 61% of remaining performance obligations as revenue in the next twelve months, and the remainder thereafter.

[0001571996-22-000031:notes:184]
[same as prior period, unchanged from 0001571996-22-000021:notes:180]

[0001571996-22-000031:notes:185]
[same as prior period, unchanged from 0001571996-22-000021:notes:181]


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001571996-22-000031:notes:186]
COMMITMENTS AND CONTINGENCIES 
Purchase Obligations

[0001571996-22-000031:notes:187]
The Company has contractual obligations to purchase goods or services, which specify significant terms (including fixed or minimum quantities to be purchased), fixed, minimum, or variable price provisions; and the approximate timing of the transaction.  As of July 29, 2022, such purchase obligations were $4.0 billion, $0.5 billion, and $0.8 billion for the remaining six months of Fiscal 2023, Fiscal 2024, and Fiscal 2025 and thereafter, respectively.

[0001571996-22-000031:notes:188]
Legal Matters

[0001571996-22-000031:notes:189]
The Company is involved in various claims, suits, assessments, investigations, and legal proceedings that arise from time to time in the ordinary course of its business, including those identified below, consisting of matters involving consumer, antitrust, tax, intellectual property, and other issues on a global basis.  Pursuant to the Separation and Distribution Agreement referred to below, Dell Technologies shares responsibility with VMware for certain matters, as indicated below, and VMware has agreed to indemnify Dell Technologies in whole or in part with respect to certain matters.

[0001571996-22-000031:notes:190]
The Company accrues a liability when it believes that it is both probable that a liability has been incurred and that it can reasonably estimate the amount of the loss.  The Company reviews these accruals at least quarterly and adjusts them to reflect ongoing negotiations, settlements, rulings, advice of legal counsel, and other relevant information.  To the extent new information is obtained and the Company’s views on the probable outcomes of claims, suits, assessments, investigations, or legal proceedings change, changes in the Company’s accrued liabilities are recorded in the period in which such a determination is made.  For some matters, the incurrence of a liability is not probable or the amount cannot be reasonably estimated and therefore accruals have not been made.

[0001571996-22-000031:notes:191]
The following is a discussion of the Company’s significant legal matters and other proceedings:

[0001571996-22-000031:notes:192]
Class Actions Related to the Class V Transaction — On December 28, 2018, the Company completed a transaction (the “Class V transaction”) in which it paid $14.0 billion in cash and issued 149,387,617 shares of its Class C Common Stock to holders of its Class V Common Stock in exchange for all outstanding shares of Class V Common Stock.  As a result of the Class V transaction, the tracking stock feature of the Company’s capital structure associated with the Class V Common Stock was terminated.  In November 2018, four purported stockholders brought putative class action complaints arising out of the Class V transaction.  The actions were captioned Hallandale Beach Police and Fire Retirement Plan v. Michael Dell et al. (Civil Action No. 2018-0816-JTL), Howard Karp v. Michael Dell et al. (Civil Action No. 2019-0032-JTL), Miramar Police Officers’ Retirement Plan v. Michael Dell et al. (Civil Action No. 2019-0049-JTL), and Steamfitters Local 449 Pension Plan v. Michael Dell et al. (Civil Action No. 2019-0115-JTL).  The four actions were consolidated in the Delaware Chancery Court into In Re Dell Class V Litigation (Consol. C.A. No. 2018-0816-JTL).  The suit currently names as defendants Michael S. Dell and certain of the other directors serving on the Board of Directors at the time of the Class V transaction, certain stockholders of the Company, consisting of Michael S. Dell and Silver Lake Group LLC and certain of its affiliated funds, and Goldman Sachs & Co. LLC (“Goldman Sachs”), which served as financial advisor to the Company in connection with the Class V transaction.  In an amended complaint filed in August 2019, the plaintiffs generally allege that the director and stockholder defendants breached their fiduciary duties under Delaware law to the former holders of Class V Common Stock in connection with the Class V transaction by offering a transaction value that was allegedly billions of dollars below the fair value.  The plaintiffs contend that the offer understated the value of shares surrendered by the former stockholders, which the plaintiffs allege should have reflected higher alternative valuations, including a valuation related to the value of the shares of VMware, Inc. common stock, and that the difference in values was wrongfully appropriated by the stockholder defendants.  On August 20, 2021, the plaintiffs added Goldman Sachs as a defendant and allege that it aided and abetted the alleged primary violations.  In the complaint, the plaintiffs seek, among other remedies, a judicial declaration that the director and stockholder defendants breached their fiduciary duties.  The plaintiffs also seek in the complaint disgorgement of all profits, benefits, and other compensation obtained by the defendants as a result of such alleged conduct and an award of unspecified damages, fees, and costs.  The defendants filed a motion to dismiss the action in September 2019.  The court denied the motion in June 2020 and the case is currently in the discovery phase.  Trial is scheduled to begin on December 5, 2022.  The Company is not a defendant in this action but is subject to director indemnification provisions under its certificate of incorporation and bylaws, and is a party to agreements with

[0001571996-22-000031:notes:193]
the defendants that contain indemnification obligations of the Company, conditioned on the satisfaction of the requirements set forth in such agreements, relating to service as a director, ownership of the Company’s securities, and provision of services, as applicable.

[0001571996-22-000031:notes:194]
Class Actions Related to VMware, Inc.’s Acquisition of Pivotal Software, Inc. — Two purported stockholders brought putative class action complaints arising out of VMware, Inc.’s acquisition of Pivotal Software, Inc. (“Pivotal”) on December 30, 2019.  The two actions were consolidated in the Delaware Chancery Court into In re: Pivotal Software, Inc. Stockholders Litigation (Civil Action No. 2020-0440-KSJM).  The complaint names as defendants the Company, VMware, Inc., Michael S. Dell, and certain officers of Pivotal.  The plaintiffs generally allege that the defendants breached their fiduciary duties to the former holders of Pivotal Class A Common Stock in connection with VMware, Inc.’s acquisition of Pivotal by allegedly causing Pivotal to enter into a transaction that favored the interests of Pivotal’s controlling stockholders at the expense of such former stockholders.  The parties have reached an agreement to settle the litigation and are seeking the court’s approval of the settlement.

[0001571996-22-000031:notes:195]
Other Litigation — Dell does not currently anticipate that any of the other various legal proceedings it is involved in will have a material adverse effect on its business, financial condition, results of operations, or cash flows.

[0001571996-22-000031:notes:196]
In accordance with the relevant accounting guidance, the Company provides disclosures of matters where it is at least reasonably possible that the Company could experience a material loss exceeding the amounts already accrued for these or other proceedings or matters.  In addition, the Company also discloses matters based on its consideration of other matters and qualitative factors, including the experience of other companies in the industry, and investor, customer, and employee relations considerations.  As of July 29, 2022, the Company does not believe there is a reasonable possibility that a material loss exceeding the amounts already accrued for these or other proceedings or matters has been incurred.  However, since the ultimate resolution of any such proceedings and matters is inherently unpredictable, the Company’s business, financial condition, results of operations, or cash flows could be materially affected in any particular period by unfavorable outcomes in one or more of these proceedings or matters.  Whether the outcome of any claim, suit, assessment, investigation, or legal proceeding, individually or collectively, could have a material adverse effect on the Company’s business, financial condition, results of operations, or cash flows will depend on a number of factors, including the nature, timing, and amount of any associated expenses, amounts paid in settlement, damages, or other remedies or consequences.

[0001571996-22-000031:notes:197]
Indemnifications Obligations

[0001571996-22-000031:notes:198]
In the ordinary course of business, the Company enters into various contracts under which it may agree to indemnify other parties for losses incurred from certain events as defined in the relevant contract, such as litigation, regulatory penalties, or claims relating to past performance.  Such indemnification obligations may not be subject to maximum loss clauses.  Historically, payments related to these indemnification obligations have not been material to the Company.

[0001571996-22-000031:notes:199]
Under the Separation and Distribution Agreement described in Note 2 of the Notes to the Condensed Consolidated Financial Statements, Dell Technologies has agreed to indemnify VMware, Inc., each of its subsidiaries and each of their respective directors, officers, and employees from and against all liabilities relating to, arising out of or resulting from, among other matters, the liabilities allocated to Dell Technologies as part of the separation of  Dell Technologies and VMware and their respective businesses as a result of the VMware Spin-off (the “Separation”).  VMware similarly has agreed to indemnify Dell Technologies Inc., each of its subsidiaries and each of their respective directors, officers, and employees from and against all liabilities relating to, arising out of or resulting from, among other matters, the liabilities allocated to VMware as part of the Separation.  Dell Technologies expects VMware to fully perform under the terms of the Separation and Distribution Agreement.
For information on the cross-indemnifications related to the tax matters agreement between the Company and VMware described in Note 2 of the Notes to the Condensed Consolidated Financial Statements effective upon the Separation on November 1, 2021, see Note 2 and Note 16 of the Notes to the Condensed Consolidated Financial Statements.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001571996-22-000031:notes:200]
INCOME AND OTHER TAXES
For the three months ended July 29, 2022, the Company’s effective income tax rate was 20.3% on pre-tax income of $0.6 billion compared to 13.2% on pre-tax income of $0.7 billion for the three months ended July 30, 2021.  For the six months ended July 29, 2022, the Company’s effective income tax rate was 14.8% on pre-tax income of $1.8 billion compared to 9.6% on pre-tax income of $1.4 billion for the six months ended July 30, 2021.  For both the three and six months ended July 29, 2022, the changes in the Company’s effective tax rates were primarily attributable to changes in discrete tax items.  Other increases to the Company’s effective income tax rates were primarily driven by a change in the jurisdictional mix of income and higher U.S. tax on foreign operations, the effects of which were partially offset by higher benefits from foreign tax credits.

[0001571996-22-000031:notes:201]
Higher U.S. tax on foreign operations is attributable to the capitalization of research and development costs.  Under the Tax Cuts and Jobs Act, which was enacted on December 22, 2017, research and development costs incurred for tax years beginning after December 31, 2021 must be capitalized and amortized ratably over five or 15 years for tax purposes, depending on where the research activities are conducted.  The effective income tax rate for future quarters of Fiscal 2023 may be impacted by actions taken by the U.S. government to defer or repeal this provision, as well as by the actual mix of jurisdictions in which income is generated and the impact of any discrete tax items.

[0001571996-22-000031:notes:202]
The differences between the estimated effective income tax rates and the U.S. federal statutory rate of 21% principally result from the Company’s geographical distribution of income, differences between the book and tax treatment of certain items, and discrete tax items.  In certain jurisdictions, the Company’s tax rate is significantly less than the applicable statutory rate as a result of tax holidays.  The majority of the Company’s foreign income that is subject to these tax holidays and lower tax rates is attributable to Singapore and China.  A significant portion of these income tax benefits relate to a tax holiday that will be effective until January 31, 2029.  The Company’s other tax holidays will expire in whole or in part during fiscal years 2030 through 2031.  Many of these tax holidays and reduced tax rates may be extended when certain conditions are met or may be terminated early if certain conditions are not met.  As of July 29, 2022, the Company was not aware of any matters of non-compliance related to these tax holidays.

[0001571996-22-000031:notes:203]
[same as prior period, unchanged from 0001571996-22-000021:notes:199]

[0001571996-22-000031:notes:204]
Judgment is required in evaluating the Company’s uncertain tax positions and determining the Company’s provision for income taxes.  The unrecognized tax benefits were $1.2 billion as of both July 29, 2022 and January 28, 2022, and are included in other non-current liabilities in the Condensed Consolidated Statements of Financial Position.  The Company does not anticipate a significant change to the total amount of unrecognized tax benefits within the next twelve months.

[0001571996-22-000031:notes:205]
The Company takes certain non-income tax positions in the jurisdictions in which it operates and has received certain non-income tax assessments from various jurisdictions.  The Company believes that a material loss in these matters is not probable and that it is not reasonably possible that a material loss exceeding amounts already accrued has been incurred.  The Company believes its positions in these non-income tax litigation matters are supportable and that it ultimately will prevail in the matters.  In the normal course of business, the Company’s positions and conclusions related to its non-income taxes could be challenged and assessments may be made.  To the extent new information is obtained and the Company’s views on its positions, probable outcomes of assessments, or litigation change, changes in estimates to the Company’s accrued liabilities would be recorded in the period in which such a determination is made.  In the resolution process for income tax and non-income tax audits, the Company is required in certain situations to provide collateral guarantees or indemnification to regulators and tax authorities until the matter is resolved.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001571996-22-000031:notes:206]
[same as prior period, unchanged from 0001571996-22-000021:notes:202]

[0001571996-22-000031:notes:207]
[same as prior period, unchanged from 0001571996-22-000021:notes:203]

[0001571996-22-000031:notes:208]
|  | Foreign Currency Translation Adjustments |  |  |  | Cash Flow Hedges |  | Pension and Other Postretirement Plans |  | Accumulated Other Comprehensive Income (Loss) |
|  | (in millions) |
| Balances as of January 28, 2022 | $ | (526) |  |  |  |  | $ | 129 |  |  | $ | (34) |  |  | $ | (431) |  |
| Other comprehensive income (loss) before reclassifications | (424) |  |  |  |  | 538 |  |  | 13 |  |  | 127 |  |
| Amounts reclassified from accumulated other comprehensive income (loss) | — |  |  |  |  | (402) |  |  | — |  |  | (402) |  |
| Total change for the period | (424) |  |  |  |  | 136 |  |  | 13 |  |  | (275) |  |
| Less: Change in comprehensive loss attributable to non-controlling interests | (1) |  |  |  |  | — |  |  | — |  |  | (1) |  |
| Balances as of July 29, 2022 | $ | (949) |  |  |  |  | $ | 265 |  |  | $ | (21) |  |  | $ | (705) |  |

[0001571996-22-000031:notes:209]
[same as prior period, unchanged from 0001571996-22-000021:notes:205]

[0001571996-22-000031:notes:210]
[same as prior period, unchanged from 0001571996-22-000021:notes:206]

[0001571996-22-000031:notes:211]
|  |  |  | Three Months Ended |
|  |  |  | July 29, 2022 |  |  |  | July 30, 2021 |
|  |  |  | Cash Flow Hedges |  | Pensions |  | Total |  |  |  | Cash Flow Hedges |  | Pensions |  | Total |
|  |  |  | (in millions) |
| Total reclassifications, net of tax: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net revenue |  |  | $ | 307 |  |  | $ | — |  |  | $ | 307 |  |  |  |  | $ | (7) |  |  | $ | — |  |  | $ | (7) |  |
| Cost of net revenue |  |  | (1) |  |  | — |  |  | (1) |  |  |  |  | (7) |  |  | — |  |  | (7) |  |
| Operating expenses |  |  | — |  |  | — |  |  | — |  |  |  |  | — |  |  | (2) |  |  | (2) |  |
| Income from discontinued operations |  |  | — |  |  | — |  |  | — |  |  |  |  | 1 |  |  | — |  |  | 1 |  |
| Total reclassifications, net of tax |  |  | $ | 306 |  |  | $ | — |  |  | $ | 306 |  |  |  |  | $ | (13) |  |  | $ | (2) |  |  | $ | (15) |  |

[0001571996-22-000031:notes:212]
|  |  |  | Six Months Ended |
|  |  |  | July 29, 2022 |  |  |  | July 30, 2021 |
|  |  |  | Cash Flow Hedges |  | Pensions |  | Total |  |  |  | Cash Flow Hedges |  | Pensions |  | Total |
|  |  |  | (in millions) |
| Total reclassifications, net of tax: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net revenue |  |  | $ | 430 |  |  | $ | — |  |  | $ | 430 |  |  |  |  | $ | (37) |  |  | $ | — |  |  | $ | (37) |  |
| Cost of net revenue |  |  | (28) |  |  | — |  |  | (28) |  |  |  |  | (5) |  |  | — |  |  | (5) |  |
| Operating expenses |  |  | — |  |  | — |  |  | — |  |  |  |  | — |  |  | (2) |  |  | (2) |  |
| Income from discontinued operations |  |  | — |  |  | — |  |  | — |  |  |  |  | 2 |  |  | — |  |  | 2 |  |
| Total reclassifications, net of tax |  |  | $ | 402 |  |  | $ | — |  |  | $ | 402 |  |  |  |  | $ | (40) |  |  | $ | (2) |  |  | $ | (42) |  |


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001571996-22-000031:notes:213]
[same as prior period, unchanged from 0001571996-22-000021:notes:208]

[0001571996-22-000031:notes:214]
|  | Authorized |  | Issued |  | Outstanding |
|  | (in millions) |
| Common stock as of July 29, 2022 |
| Class A | 600 |  |  | 379 |  |  | 379 |  |
| Class B | 200 |  |  | 95 |  |  | 95 |  |
| Class C | 7,900 |  |  | 322 |  |  | 260 |  |
| Class D | 100 |  |  | — |  |  | — |  |
|  | 8,800 |  |  | 796 |  |  | 734 |  |
| Common stock as of January 28, 2022 |
| Class A | 600 |  |  | 379 |  |  | 379 |  |
| Class B | 200 |  |  | 95 |  |  | 95 |  |
| Class C | 7,900 |  |  | 303 |  |  | 283 |  |
| Class D | 100 |  |  | — |  |  | — |  |
| Class V | 343 |  |  | — |  |  | — |  |
|  | 9,143 |  |  | 777 |  |  | 757 |  |

[0001571996-22-000031:notes:215]
On June 29, 2022, the authorized capital stock provisions of the Company’s certificate of incorporation were amended to eliminate the Class V Common Stock as the fifth authorized series of Dell Technologies common stock.  In connection with the elimination of authorized Class V Common Stock, the Company’s certificate of incorporation also was amended to decrease by 343 million shares the total number of shares of common stock which Dell Technologies is authorized to issue.

[0001571996-22-000031:notes:216]
[same as prior period, unchanged from 0001571996-22-000021:notes:211]

[0001571996-22-000031:notes:217]
The Company is authorized to issue one million shares of preferred stock, par value $0.01 per share.  As of July 29, 2022 and January 28, 2022, no shares of preferred stock were issued or outstanding.

[0001571996-22-000031:notes:218]
[same as prior period, unchanged from 0001571996-22-000021:notes:213]

[0001571996-22-000031:notes:219]
Dell Technologies Common Stock — The Class A Common Stock, the Class B Common Stock, the Class C Common Stock, and the Class D Common Stock are collectively referred to as Dell Technologies Common Stock.  The par value for all series of Dell Technologies Common Stock is $0.01 per share.  The Class A Common Stock, the Class B Common Stock, the Class C Common Stock, and the Class D Common Stock share equally in dividends declared or accumulated and have equal participation rights in undistributed earnings.

[0001571996-22-000031:notes:220]
[same as prior period, unchanged from 0001571996-22-000021:notes:215]

[0001571996-22-000031:notes:221]
[same as prior period, unchanged from 0001571996-22-000021:notes:216]

[0001571996-22-000031:notes:222]
During the six months ended July 29, 2022, there were no conversions of shares of Class A or Class B Common Stock into shares of Class C Common Stock.

[0001571996-22-000031:notes:223]
[same as prior period, unchanged from 0001571996-22-000021:notes:218]

[0001571996-22-000031:notes:224]
[same as prior period, unchanged from 0001571996-22-000021:notes:219]

[0001571996-22-000031:notes:225]
The Company paid the following dividends during the six months ended July 29, 2022:

[0001571996-22-000031:notes:226]
| Declaration Date |  | Record Date |  | Payment Date |  | Dividend per Share |  | Amount (in millions) |
| February 24, 2022 |  | April 20, 2022 |  | April 29, 2022 |  | $ | 0.33 |  |  | $ | 248 |  |
| June 7, 2022 |  | July 20, 2022 |  | July 29, 2022 |  | $ | 0.33 |  |  | $ | 242 |  |

[0001571996-22-000031:notes:227]
[same as prior period, unchanged from 0001571996-22-000021:notes:221]

[0001571996-22-000031:notes:228]
Effective as of September 23, 2021, the Company’s Board of Directors terminated the Company’s previous stock repurchase program and approved a new stock repurchase program under which the Company is authorized to repurchase up to $5 billion of shares of the Company’s Class C Common Stock with no established expiration date.  During the six months ended July 29, 2022, the Company repurchased approximately 42 million shares of Class C Common Stock for a total purchase price of approximately $2.1 billion.

[0001571996-22-000031:notes:229]
The above repurchases of Class C Common Stock exclude shares withheld from stock awards to settle employee tax withholding obligations related to the vesting of such awards.  
The Company did not repurchase any shares of Class C Common Stock during the six months ended July 30, 2021 under the previous stock repurchase program.


## us-gaap:EarningsPerShareTextBlock

[0001571996-22-000031:notes:230]
[same as prior period, unchanged from 0001571996-22-000021:notes:224]

[0001571996-22-000031:notes:231]
[same as prior period, unchanged from 0001571996-22-000021:notes:225]

[0001571996-22-000031:notes:232]
|  | Three Months Ended |  | Six Months Ended |  |  |
|  | July 29, 2022 |  | July 30, 2021 |  | July 29, 2022 |  | July 30, 2021 |  |  |
| Earnings per share attributable to Dell Technologies Inc. - basic |
| Continuing operations | $ | 0.69 |  |  | $ | 0.83 |  |  | $ | 2.12 |  |  | $ | 1.70 |  |  |  |
| Discontinued operations | $ | — |  |  | $ | 0.26 |  |  | $ | — |  |  | $ | 0.56 |  |  |  |
| Earnings per share attributable to Dell Technologies Inc. — diluted |
| Continuing operations | $ | 0.68 |  |  | $ | 0.80 |  |  | $ | 2.06 |  |  | $ | 1.65 |  |  |  |
| Discontinued operations | $ | — |  |  | $ | 0.25 |  |  | $ | — |  |  | $ | 0.53 |  |  |  |

[0001571996-22-000031:notes:233]
[same as prior period, unchanged from 0001571996-22-000021:notes:227]

[0001571996-22-000031:notes:234]
|  | Three Months Ended |  | Six Months Ended |
|  | July 29, 2022 |  | July 30, 2021 |  | July 29, 2022 |  | July 30, 2021 |
|  | (in millions) |
| Numerator: Continuing operations |  |  |  |  |  |  |  |
| Net income attributable to Dell Technologies Inc. from continuing operations - basic and diluted | $ | 511 |  |  | $ | 631 |  |  | $ | 1,583 |  |  | $ | 1,291 |  |
| Numerator: Discontinued operations |  |  |  |  |  |  |  |
| Income from discontinued operations, net of income taxes - basic | $ | — |  |  | $ | 200 |  |  | $ | — |  |  | $ | 427 |  |
| Incremental dilution from VMware, Inc. (a) | — |  |  | (3) |  |  | — |  |  | (5) |  |
| Income from discontinued operations, net of income taxes, attributable to Dell Technologies Inc. - diluted | $ | — |  |  | $ | 197 |  |  | $ | — |  |  | $ | 422 |  |
| Denominator: Dell Technologies Common Stock weighted-average shares outstanding |  |  |  |  |  |  |  |
| Weighted-average shares outstanding — basic | 739 |  |  | 763 |  |  | 746 |  |  | 760 |  |
| Dilutive effect of options, restricted stock units, restricted stock, and other | 16 |  |  | 23 |  |  | 22 |  |  | 24 |  |
| Weighted-average shares outstanding — diluted | 755 |  |  | 786 |  |  | 768 |  |  | 784 |  |
| Weighted-average shares outstanding — antidilutive | 15 |  |  | — |  |  | 8 |  |  | — |  |

[0001571996-22-000031:notes:235]
(a)    The incremental dilution from VMware, Inc. represents the impact of VMware, Inc.’s dilutive securities on diluted earnings per share of Dell Technologies Common Stock, and is calculated by multiplying the difference between VMware, Inc.’s basic and diluted earnings (loss) per share by the number of shares of VMware, Inc. common stock held by the Company before the VMware Spin-off.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001571996-22-000031:notes:236]
RELATED PARTY TRANSACTIONS 
VMware is considered to be a related party of the Company as a result of Michael Dell’s ownership interest in both Dell Technologies and VMware as well as Mr. Dell’s continued service as Chairman and Chief Executive Officer of Dell Technologies and as Chairman of the Board of VMware, Inc.  See Note 1 and Note 2 of the Notes to the Condensed Consolidated Financial Statements for more information about the VMware Spin-off.

[0001571996-22-000031:notes:237]
The information provided below includes a summary of transactions with VMware, Inc. and with its consolidated subsidiaries (collectively, “VMware”).  Transactions with related parties other than VMware during the periods presented were immaterial, individually and in aggregate.

[0001571996-22-000031:notes:238]
Transactions with VMware

[0001571996-22-000031:notes:239]
Dell Technologies and VMware engage in the following ongoing related party transactions:

[0001571996-22-000031:notes:240]
•Pursuant to original equipment manufacturer and reseller arrangements, Dell Technologies integrates or bundles VMware’s products and services with Dell Technologies’ products and sells them to end-users.  Dell Technologies also acts as a distributor, purchasing VMware’s standalone products and services for resale to end-user customers.  Where applicable, costs under these arrangements are presented net of rebates received by Dell Technologies.

[0001571996-22-000031:notes:241]
•Dell Technologies procures products and services from VMware for its internal use.  For the three and six months ended July 29, 2022 and July 30, 2021, costs incurred associated with products and services purchased from VMware for internal use were immaterial.

[0001571996-22-000031:notes:242]
•Dell Technologies sells and leases products and sells services to VMware.  For the three and six months ended July 29, 2022 and July 30, 2021, revenue recognized from sales of services to VMware was immaterial.

[0001571996-22-000031:notes:243]
•Dell Technologies and VMware also enter into joint marketing, sales, and branding arrangements, for which both parties may incur costs.  For the three and six months ended July 29, 2022 and July 30, 2021, consideration received from VMware for joint marketing, sales, and branding arrangements was immaterial.

[0001571996-22-000031:notes:244]
•DFS provides financing to certain VMware end users.  Upon acceptance of the financing arrangement by both VMware’s end users and DFS, DFS recognizes amounts due to related parties on the Condensed Consolidated Statements of Financial Position.  Associated financing fees are recorded to product net revenue on the Condensed Consolidated Statements of Income.

[0001571996-22-000031:notes:245]
•Dell Technologies and VMware enter into agreements to collaborate on technology projects in which one party pays the corresponding party for services or the reimbursement of costs.  For the three and six months ended July 29, 2022 and July 30, 2021, collaborative technology projects were immaterial.

[0001571996-22-000031:notes:246]
•Dell Technologies provides support services and support from Dell Technologies personnel to VMware in certain geographic regions where VMware does not have an established legal entity.  These employees are managed by VMware but Dell Technologies incurs the costs for these such services.  The costs incurred by Dell Technologies on VMware’s behalf to these employees are charged to VMware.  For the three and six months ended July 29, 2022 and July 30, 2021, costs associated with such seconded employees were immaterial.

[0001571996-22-000031:notes:247]
•Dell Technologies and VMware entered into a transition services agreement in connection with the VMware Spin-off to provide various support services including investment advisory services, certain support services from Dell Technologies personnel, and other transitional services.  Costs associated with this agreement were immaterial for the three and six months ended July 29, 2022.

[0001571996-22-000031:notes:248]
The following table presents information about the impact of Dell Technologies’ related party transactions with VMware on the Condensed Consolidated Statements of Income for the periods indicated:

[0001571996-22-000031:notes:249]
|  |  |  | Three Months Ended |  | Six Months Ended |
|  | Classification |  | July 29, 2022 |  | July 30, 2021 |  | July 29, 2022 |  | July 30, 2021 |
|  |  |  | (in millions) |
| Sales and leases of products to VMware | Net revenue - products |  | $ | 35 |  |  | $ | 31 |  |  | $ | 81 |  |  | $ | 78 |  |
| Purchase of VMware products for resale | Cost of net revenue - products |  | $ | 426 |  |  | $ | 387 |  |  | $ | 681 |  |  | $ | 706 |  |
| Purchase of VMware services for resale | Cost of net revenue - services |  | $ | 762 |  |  | $ | 616 |  |  | $ | 1,471 |  |  | $ | 1,194 |  |

[0001571996-22-000031:notes:250]
The following table presents information about the impact of Dell Technologies’ related party transactions with VMware on the Condensed Consolidated Statements of Financial Position for the periods indicated:

[0001571996-22-000031:notes:251]
|  | Classification |  | July 29, 2022 |  | January 28, 2022 |
|  |  |  | (in millions) |
| Deferred costs related to VMware products and services for resale | Other current assets |  | $ | 2,652 |  |  | $ | 2,571 |  |
| Deferred costs related to VMware products and services for resale | Other non-current assets |  | $ | 2,166 |  |  | $ | 2,311 |  |

[0001571996-22-000031:notes:252]
Related Party Tax Matters

[0001571996-22-000031:notes:253]
Tax Agreements — In connection with the VMware Spin-off and concurrently with the execution of the Separation and Distribution Agreement, effective as of April 14, 2021, Dell Technologies and VMware entered into a Tax Matters Agreement (the “Tax Matters Agreement”) and agreed to terminate the tax sharing agreement as amended on December 30, 2019 (together with the Tax Matters Agreement, the “Tax Agreements”).  The Tax Matters Agreement governs Dell Technologies’ and VMware’s respective rights and obligations, both for pre-spin-off periods and post-spin-off periods, regarding income and other taxes, and related matters, including tax liabilities and benefits, attributes, and returns.

[0001571996-22-000031:notes:254]
The timing of the tax payments due to and from related parties is governed by the Tax Agreements.  VMware’s portion of the mandatory one-time transition tax on accumulated earnings of foreign subsidiaries (the “Transition Tax”) is governed by a letter agreement between VMware and Dell Technologies entered into on April 1, 2019.

[0001571996-22-000031:notes:255]
Net receipts from VMware pursuant to the Tax Agreements were immaterial during the three and six months ended July 29, 2022 and July 30, 2021, and primarily relate to VMware’s portion of the Transition Tax, federal income taxes on Dell Technologies’ consolidated tax return, and state tax payments for combined states.

[0001571996-22-000031:notes:256]
As a result of the activity under the Tax Agreements with VMware, amounts due from VMware were $570 million and $621 million as of July 29, 2022 and January 28, 2022, respectively, primarily related to VMware’s estimated tax obligation resulting from the Transition Tax.  The 2017 Tax Cuts and Jobs Act included a deferral election for an eight-year installment payment method on the Transition Tax.  Dell Technologies expects VMware to pay the remainder of its Transition Tax over a period of three years.

[0001571996-22-000031:notes:257]
Indemnification — Upon consummation of the VMware Spin-off, Dell Technologies recorded net income tax indemnification receivables from VMware related to certain income tax liabilities for which Dell Technologies is jointly and severally liable, but for which it is indemnified by VMware under the Tax Matters Agreement.  The amounts that VMware may be obligated to pay Dell Technologies could vary depending on the outcome of certain unresolved tax matters, which may not be resolved for several years.  The net receivable as of July 29, 2022 and January 28, 2022 was $154 million and$144 million, respectively.

[0001571996-22-000031:notes:258]
Due To/From Related Party

[0001571996-22-000031:notes:259]
The following table presents amounts due to and from VMware as of the dates indicated:

[0001571996-22-000031:notes:260]
|  | July 29, 2022 |  | January 28, 2022 |
|  | (in millions) |
| Due from related party, net, current (a) | $ | 195 |  |  | $ | 131 |  |
| Due from related party, net, non-current (b) | $ | 609 |  |  | $ | 710 |  |
| Due to related party, current (c) | $ | 1,269 |  |  | $ | 1,414 |  |

[0001571996-22-000031:notes:261]
(a)    Amounts due from related party, current consists of amounts due from VMware, inclusive of current net tax receivables from VMware under the Tax Agreements.  Amounts, excluding tax, are generally settled in cash within 60 days of each quarter-end.

[0001571996-22-000031:notes:262]
(b)  Amounts due from related party, non-current consists of non-current portion of net receivables from VMware under the Tax Agreements.

[0001571996-22-000031:notes:263]
(c)  Amounts due to related party, current includes amounts due to VMware which are generally settled in cash within 60 days of each quarter-end.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001571996-22-000031:notes:264]
[same as prior period, unchanged from 0001571996-22-000021:notes:258]

[0001571996-22-000031:notes:265]
[same as prior period, unchanged from 0001571996-22-000021:notes:259]

[0001571996-22-000031:notes:266]
CSG includes sales to commercial and consumer customers of branded hardware (such as desktops, workstations, and notebooks) and branded peripherals (such as displays, docking stations, and other electronics), as well as services and third-party software and peripherals.  CSG also offers attached software, peripherals, and services, including support and deployment, configuration, and extended warranty services.

[0001571996-22-000031:notes:267]
[same as prior period, unchanged from 0001571996-22-000021:notes:261]

[0001571996-22-000031:notes:268]
[same as prior period, unchanged from 0001571996-22-000021:notes:262]

[0001571996-22-000031:notes:269]
[same as prior period, unchanged from 0001571996-22-000021:notes:263]

[0001571996-22-000031:notes:270]
[same as prior period, unchanged from 0001571996-22-000021:notes:264]

[0001571996-22-000031:notes:271]
[same as prior period, unchanged from 0001571996-22-000021:notes:265]

[0001571996-22-000031:notes:272]
|  | Three Months Ended |  | Six Months Ended |
|  | July 29, 2022 |  | July 30, 2021 |  | July 29, 2022 |  | July 30, 2021 |  |  |
|  | (in millions) |
| Consolidated net revenue: |  |  |  |  |  |  |  |  |  |
| Infrastructure Solutions Group | $ | 9,536 |  |  | $ | 8,550 |  |  | $ | 18,821 |  |  | $ | 16,583 |  |  |  |
| Client Solutions Group | 15,490 |  |  | 14,268 |  |  | 31,077 |  |  | 27,579 |  |  |  |
| Reportable segment net revenue | 25,026 |  |  | 22,818 |  |  | 49,898 |  |  | 44,162 |  |  |  |
| Other businesses (a) | 1,399 |  |  | 1,378 |  |  | 2,638 |  |  | 2,630 |  |  |  |
| Unallocated transactions (b) | — |  |  | 3 |  |  | 5 |  |  | 5 |  |  |  |
| Impact of purchase accounting (c) | — |  |  | (8) |  |  | — |  |  | (16) |  |  |  |
| Total consolidated net revenue | $ | 26,425 |  |  | $ | 24,191 |  |  | $ | 52,541 |  |  | $ | 46,781 |  |  |  |
| Consolidated operating income: |  |  |  |  |  |  |  |  |  |
| Infrastructure Solutions Group | $ | 1,046 |  |  | $ | 962 |  |  | $ | 2,128 |  |  | $ | 1,740 |  |  |  |
| Client Solutions Group | 978 |  |  | 986 |  |  | 2,093 |  |  | 2,066 |  |  |  |
| Reportable segment operating income | 2,024 |  |  | 1,948 |  |  | 4,221 |  |  | 3,806 |  |  |  |
| Other businesses (a) | (71) |  |  | (77) |  |  | (135) |  |  | (167) |  |  |  |
| Unallocated transactions (b) | (1) |  |  | (3) |  |  | 1 |  |  | (1) |  |  |  |
| Impact of purchase accounting (c) | (3) |  |  | (15) |  |  | (12) |  |  | (35) |  |  |  |
| Amortization of intangibles | (244) |  |  | (442) |  |  | (487) |  |  | (887) |  |  |  |
| Transaction-related expenses (d) | (3) |  |  | (37) |  |  | (8) |  |  | (66) |  |  |  |
| Stock-based compensation expense (e) | (236) |  |  | (206) |  |  | (468) |  |  | (378) |  |  |  |
| Other corporate expenses (f) | (196) |  |  | (151) |  |  | (292) |  |  | (268) |  |  |  |
| Total consolidated operating income | $ | 1,270 |  |  | $ | 1,017 |  |  | $ | 2,820 |  |  | $ | 2,004 |  |  |  |

[0001571996-22-000031:notes:273]
[same as prior period, unchanged from 0001571996-22-000021:notes:267]

[0001571996-22-000031:notes:274]
[same as prior period, unchanged from 0001571996-22-000021:notes:268]

[0001571996-22-000031:notes:275]
[same as prior period, unchanged from 0001571996-22-000021:notes:269]

[0001571996-22-000031:notes:276]
[same as prior period, unchanged from 0001571996-22-000021:notes:270]

[0001571996-22-000031:notes:277]
[same as prior period, unchanged from 0001571996-22-000021:notes:271]

[0001571996-22-000031:notes:278]
(f)Other corporate expenses includes impairment charges, incentive charges related to equity investments, severance, facility action, payroll taxes associated with stock-based compensation, and other costs.  During the three and six months ended Fiscal 2023, other corporate expenses includes impairment and other costs incurred in connection with exiting the Company’s business in Russia.

[0001571996-22-000031:notes:279]
[same as prior period, unchanged from 0001571996-22-000021:notes:273]

[0001571996-22-000031:notes:280]
|  | Three Months Ended |  | Six Months Ended |
|  | July 29, 2022 |  | July 30, 2021 |  | July 29, 2022 |  | July 30, 2021 |  |  |
|  | (in millions) |
| Net revenue: |  |  |  |  |  |  |  |  |  |
| Infrastructure Solutions Group: |  |  |  |  |  |  |  |  |  |
| Servers and networking | $ | 5,209 |  |  | $ | 4,480 |  |  | $ | 10,257 |  |  | $ | 8,620 |  |  |  |
| Storage | 4,327 |  |  | 4,070 |  |  | 8,564 |  |  | 7,963 |  |  |  |
| Total ISG net revenue | $ | 9,536 |  |  | $ | 8,550 |  |  | $ | 18,821 |  |  | $ | 16,583 |  |  |  |
| Client Solutions Group: |  |  |  |  |  |  |  |  |  |
| Commercial | $ | 12,141 |  |  | $ | 10,577 |  |  | $ | 24,112 |  |  | $ | 20,385 |  |  |  |
| Consumer | 3,349 |  |  | 3,691 |  |  | 6,965 |  |  | 7,194 |  |  |  |
| Total CSG net revenue | $ | 15,490 |  |  | $ | 14,268 |  |  | $ | 31,077 |  |  | $ | 27,579 |  |  |  |


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0001571996-22-000031:notes:281]
SUPPLEMENTAL CONSOLIDATED FINANCIAL INFORMATION
The following table presents additional information on selected assets included in the Condensed Consolidated Statements of Financial Position as of the dates indicated:

[0001571996-22-000031:notes:282]
|  | July 29, 2022 |  | January 28, 2022 |
|  | (in millions) |
| Cash, cash equivalents, and restricted cash: |  |  |  |
| Cash and cash equivalents | $ | 5,507 |  |  | $ | 9,477 |  |
| Restricted cash - other current assets (a) | 571 |  |  | 534 |  |
| Restricted cash - other non-current assets (a) | 15 |  |  | 71 |  |
| Total cash, cash equivalents, and restricted cash | $ | 6,093 |  |  | $ | 10,082 |  |
| Inventories, net: |  |  |  |
| Production materials | $ | 3,604 |  |  | $ | 3,653 |  |
| Work-in-process | 892 |  |  | 855 |  |
| Finished goods | 1,387 |  |  | 1,390 |  |
| Total inventories, net | $ | 5,883 |  |  | $ | 5,898 |  |
| Deferred Costs: |  |  |  |
| Total deferred costs, current (b) | $ | 5,516 |  |  | $ | 4,996 |  |
| Property, plant, and equipment, net: |  |  |  |
| Computer equipment | $ | 7,240 |  |  | $ | 6,497 |  |
| Land and buildings | 3,008 |  |  | 3,095 |  |
| Machinery and other equipment | 2,991 |  |  | 2,714 |  |
| Total property, plant, and equipment | 13,239 |  |  | 12,306 |  |
| Accumulated depreciation and amortization | (7,467) |  |  | (6,891) |  |
| Total property, plant, and equipment, net | $ | 5,772 |  |  | $ | 5,415 |  |

[0001571996-22-000031:notes:283]
[same as prior period, unchanged from 0001571996-22-000021:notes:277]

[0001571996-22-000031:notes:284]
[same as prior period, unchanged from 0001571996-22-000021:notes:278]

[0001571996-22-000031:notes:285]
[same as prior period, unchanged from 0001571996-22-000021:notes:279]

[0001571996-22-000031:notes:286]
[same as prior period, unchanged from 0001571996-22-000021:notes:280]

[0001571996-22-000031:notes:287]
|  | Three Months Ended |  | Six Months Ended |
|  | July 29, 2022 |  | July 30, 2021 |  | July 29, 2022 |  | July 30, 2021 |
|  | (in millions) |
| Warranty liability: |  |  |  |  |  |  |  |
| Warranty liability at beginning of period | $ | 468 |  |  | $ | 458 |  |  | $ | 480 |  |  | $ | 473 |  |
| Costs accrued for new warranty contracts and changes in estimates for pre-existing warranties (a) | 244 |  |  | 241 |  |  | 467 |  |  | 443 |  |
| Service obligations honored | (249) |  |  | (228) |  |  | (484) |  |  | (445) |  |
| Warranty liability at end of period | $ | 463 |  |  | $ | 471 |  |  | $ | 463 |  |  | $ | 471 |  |

[0001571996-22-000031:notes:288]
[same as prior period, unchanged from 0001571996-22-000021:notes:282]

[0001571996-22-000031:notes:289]
[same as prior period, unchanged from 0001571996-22-000021:notes:283]

[0001571996-22-000031:notes:290]
[same as prior period, unchanged from 0001571996-22-000021:notes:284]

[0001571996-22-000031:notes:291]
|  | Three Months Ended |  | Six Months Ended |
|  | July 29, 2022 |  | July 30, 2021 |  | July 29, 2022 |  | July 30, 2021 |
|  | (in millions) |
| Interest and other, net: |  |  |  |  |  |  |  |
| Investment income, primarily interest | $ | 16 |  |  | $ | 10 |  |  | $ | 31 |  |  | $ | 20 |  |
| Gain (loss) on investments, net | (255) |  |  | 166 |  |  | (241) |  |  | 359 |  |
| Interest expense | (298) |  |  | (416) |  |  | (563) |  |  | (849) |  |
| Foreign exchange | (66) |  |  | (67) |  |  | (155) |  |  | (119) |  |
| Other | (32) |  |  | 15 |  |  | (44) |  |  | 9 |  |
| Total interest and other, net | $ | (635) |  |  | $ | (292) |  |  | $ | (972) |  |  | $ | (580) |  |


## us-gaap:SubsequentEventsTextBlock

[0001571996-22-000031:notes:292]
SUBSEQUENT EVENTS There were no known events occurring after July 29, 2022 and up until the date of issuance of this report that would materially affect the information presented herein.
