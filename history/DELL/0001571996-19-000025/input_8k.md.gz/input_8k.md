# DELL 8-K — 0001571996-19-000021 filed 2019-05-30

## item codes, every 8-K on or before 2019-06-10

- 2019-05-30 0001571996-19-000021 — 2.02, 9.01
- 2019-04-02 0001571996-19-000010 — 5.02
- 2019-03-21 0001193125-19-082281 — 1.01, 1.02, 2.03, 9.01
- 2019-03-19 0001571996-19-000005 — 5.02, 9.01
- 2019-03-14 0001193125-19-074935 — 1.01, 2.03, 9.01
- 2019-03-07 0001193125-19-066045 — 8.01, 9.01
- 2019-02-28 0001571996-19-000002 — 2.02, 9.01
- 2018-12-28 0001193125-18-360943 — 1.01, 1.02, 3.01, 3.03, 5.02, 5.03, 7.01, 8.01, 9.01
- 2018-12-21 0001193125-18-356324 — 1.01, 2.03, 9.01
- 2018-12-14 0001193125-18-349469 — 8.01
- 2018-12-11 0001193125-18-346958 — 5.07, 8.01, 9.01
- 2018-11-29 0001571996-18-000041 — 2.02, 9.01
- 2018-11-28 0001571996-18-000037 — 7.01, 8.01, 9.01
- 2018-11-26 0001193125-18-333967 — 8.01, 9.01
- 2018-11-15 0001193125-18-328110 — 1.01, 9.01 — amendment of 0001193125-18-327222
- 2018-11-15 0001193125-18-327222 — 1.01, 7.01, 9.01
- 2018-10-03 0001193125-18-291390 — 8.01
- 2018-09-06 0001571996-18-000029 — 2.02, 9.01
- 2018-08-06 0001571996-18-000027 — 8.01, 9.01
- 2018-07-02 0001193125-18-210339 — 1.01, 7.01, 9.01
- 2018-06-28 0001571996-18-000024 — 5.07
- 2018-06-04 0001571996-18-000019 — 2.02, 9.01
- 2018-05-17 0001571996-18-000016 — 7.01
- 2018-04-26 0001571996-18-000009 — 7.01, 9.01
- 2018-03-08 0001193125-18-074168 — 2.02, 9.01
- 2018-02-02 0001193125-18-029947 — 7.01, 9.01
- 2017-12-07 0001571996-17-000042 — 2.02, 9.01
- 2017-10-24 0001571996-17-000037 — 1.01, 2.03, 9.01
- 2017-09-15 0001571996-17-000027 — 5.02
- 2017-09-07 0001571996-17-000017 — 2.02, 9.01
- 2017-08-24 0001571996-17-000014 — 8.01
- 2017-06-29 0001571996-17-000011 — 3.03, 5.07, 8.01, 9.01
- 2017-06-08 0001193125-17-197638 — 2.02, 9.01
- 2017-03-30 0001193125-17-102794 — 8.01
- 2017-03-30 0001193125-17-102777 — 2.02, 9.01
- 2017-03-09 0001193125-17-076981 — 1.01, 2.03, 9.01
- 2017-01-17 0001193125-17-011125 — 8.01
- 2016-12-15 0001193125-16-793722 — 8.01
- 2016-12-08 0001193125-16-787976 — 2.02, 9.01
- 2016-11-10 0001193125-16-765964 — 1.02, 8.01
- 2016-11-04 0001193125-16-760249 — 8.01
- 2016-09-13 0001193125-16-708600 — 3.02
- 2016-09-09 0001193125-16-706567 — 1.01, 1.02, 2.01, 2.03, 3.02, 3.03, 5.02, 9.01
- 2016-09-07 0001193125-16-703370 — 3.03, 5.07, 7.01, 8.01, 9.01
- 2016-09-06 0001193125-16-702057 — 2.02, 9.01
- 2016-08-31 0001193125-16-697268 — 8.01, 9.01
- 2016-08-26 0001193125-16-692921 — 8.01, 9.01
- 2016-07-11 0001193125-16-645610 — 8.01
- 2016-07-05 0001193125-16-641679 — 8.01
- 2016-06-22 0001193125-16-629055 — 1.01, 2.03, 8.01, 9.01
- 2016-06-21 0001193125-16-627071 — 8.01, 9.01
- 2016-06-10 0001193125-16-618483 — 2.02, 9.01
- 2016-06-09 0001193125-16-617893 — 8.01, 9.01

## late-filing notifications on or before 2019-06-10

- none on or before 2019-06-10

## item 2.02 — earnings release, exhibit 99.1

[0001571996-19-000021:8k_2_02:1]
EX-99.1
2
exhibit991earnings8k.htm
EXHIBIT 99.1

[0001571996-19-000021:8k_2_02:2]
Exhibit

[0001571996-19-000021:8k_2_02:3]
Exhibit 99.1

[0001571996-19-000021:8k_2_02:4]
News Release

[0001571996-19-000021:8k_2_02:5]
Dell Technologies Reports First Quarter Fiscal 2020

[0001571996-19-000021:8k_2_02:6]
Financial Results

[0001571996-19-000021:8k_2_02:7]
ROUND ROCK, Texas — May 30, 2019

[0001571996-19-000021:8k_2_02:8]
News summary

[0001571996-19-000021:8k_2_02:9]
| • | First quarter revenue of $21.9 billion, up 3 percent; non-GAAP first quarter revenue of $22.0 billion, up 2 percent |

[0001571996-19-000021:8k_2_02:10]
| • | Operating income of $550 million; non-GAAP operating income of $2.2 billion |

[0001571996-19-000021:8k_2_02:11]
| • | Diluted earnings per share of $0.38; non-GAAP diluted earnings per share of $1.45 |

[0001571996-19-000021:8k_2_02:12]
Full story

[0001571996-19-000021:8k_2_02:13]
Dell Technologies (NYSE: DELL) today announced financial results for its fiscal 2020 first quarter ended May 3, 2019.  First quarter revenue was $21.9 billion, up 3 percent, and non-GAAP revenue was $22.0 billion, up 2 percent over the same period in the prior year.  The company generated operating income of $550 million1, compared to an operating loss of $153 million last year, and non-GAAP operating income of $2.2 billion, compared to $2.0 billion last year.  Net income was $329 million or 1.5 percent of revenue, non-GAAP net income was $1.2 billion or 5.5 percent of non-GAAP revenue, and adjusted EBITDA was $2.6 billion or 11.7 percent of non-GAAP revenue.  Cash flow from operations was approximately $682 million for the quarter with diluted earnings per share of $0.38 and non-GAAP diluted earnings per share of $1.45.

[0001571996-19-000021:8k_2_02:14]
“We’re in the middle of a technology led investment cycle that’s fueled by the explosion of data,” said Jeff Clarke, vice chairman, Dell Technologies.  “No one is better positioned to deliver the solutions customers need to grow in the data era.  One example is our new Dell Technologies Cloud platform jointly engineered with VMware to expedite customers’ moves to hybrid cloud environments.”

[0001571996-19-000021:8k_2_02:15]
Unveiled at Dell Technologies World earlier in the quarter, the Dell Technologies Cloud combines the power of VMware and Dell Technologies to make hybrid cloud environments simpler to deploy and manage with consistent infrastructure, operations, and services. Dell Technologies Cloud seamlessly extends from the public cloud into the data center with the option of hyperconverged or converged infrastructure, including VMware Cloud Foundation on VxRail, as well as being able to be consumed as a fully managed Data Center-as-a-Service, VMware Cloud on Dell EMC.

[0001571996-19-000021:8k_2_02:16]
1

[0001571996-19-000021:8k_2_02:17]
Also at Dell Technologies World 2019, the company extended its leadership in edge computing with the announcement of Unified Workspace, which integrates solutions across Dell devices and services, VMware Workspace ONE, and Secureworks to simplify the entire device lifecycle for IT.

[0001571996-19-000021:8k_2_02:18]
First Quarter Fiscal 2020 Financial Results

[0001571996-19-000021:8k_2_02:19]
|  | Three Months Ended |  |  |
|  | May 3, 2019 |  | May 4, 2018 |  | Change |
|  | (in millions, except percentages; unaudited) |
| Total net revenue | $ | 21,908 |  |  | $ | 21,356 |  |  | 3% |
| Operating income (loss) | $ | 550 |  |  | $ | (153 | ) |  | 459% |
| Net income (loss) | $ | 329 |  |  | $ | (538 | ) |  | 161% |
| Non-GAAP net revenue | $ | 21,990 |  |  | $ | 21,543 |  |  | 2% |
| Non-GAAP operating income | $ | 2,196 |  |  | $ | 2,026 |  |  | 8% |
| Non-GAAP net income | $ | 1,209 |  |  | $ | 1,179 |  |  | 3% |
| Adjusted EBITDA | $ | 2,573 |  |  | $ | 2,383 |  |  | 8% |

[0001571996-19-000021:8k_2_02:20]
Information about Dell Technologies’ use of non-GAAP financial information is provided under “Non-GAAP Financial Measures” below. All comparisons in this press release are year-over-year unless otherwise noted.

[0001571996-19-000021:8k_2_02:21]
Dell Technologies ended the quarter with a cash and investments balance of $9.8 billion.  The company paid down approximately $400 million in gross debt in the first quarter and approximately $15 billion in gross debt over the two and a half years since the closing of the EMC transaction, excluding Dell Financial Services-related debt, public subsidiary debt, and debt incurred to finance the Class V transaction.  The company is on track to repay approximately $4.8 billion of gross debt in fiscal year 2020.

[0001571996-19-000021:8k_2_02:22]
“I am pleased that we grew revenue and profitability while taking share in a dynamic environment,” said Tom Sweet, chief financial officer, Dell Technologies.  “We remain focused on long-term relative growth and innovating across our family of businesses to help our customers transform for their digital future.”

[0001571996-19-000021:8k_2_02:23]
Operating segments summary

[0001571996-19-000021:8k_2_02:24]
Infrastructure Solutions Group revenue for the first quarter was $8.2 billion, a 5 percent decrease year-over-year.  This was driven by a 1 percent decrease in storage revenue to $4.0 billion and a 9 percent decrease in server and networking revenue to $4.2 billion.  Operating income was $843 million for the first quarter, or 10.3 percent of Infrastructure Solutions Group revenue.

[0001571996-19-000021:8k_2_02:25]
Key highlights:

[0001571996-19-000021:8k_2_02:26]
| • | Newer software-defined data center solutions and hyper converged infrastructure are growing rapidly, including VxRail, which grew triple digits again during the first quarter |

[0001571996-19-000021:8k_2_02:27]
| • | Launched midrange storage portfolio with new Unity XT solution announced at Dell Technologies World 2019, as well as new Cloud Storage Services extending support for hybrid cloud environments |

[0001571996-19-000021:8k_2_02:28]
| • | Strengthened data protection portfolio with announcement of PowerProtect X400 and PowerProtect Software platform offerings at Dell Technologies World 2019 |

[0001571996-19-000021:8k_2_02:29]
2

[0001571996-19-000021:8k_2_02:30]
Client Solutions Group revenue for the first quarter was $10.9 billion, up 6 percent versus the first quarter of last year.  Commercial revenue grew 13 percent to $8.3 billion, and Consumer revenue was down 10 percent to $2.6 billion.  Operating income was $793 million for the first quarter, or 7.3 percent of Client Solutions Group revenue.

[0001571996-19-000021:8k_2_02:31]
Key highlights:

[0001571996-19-000021:8k_2_02:32]
| • | Gained year-over-year worldwide PC share2 for 25th consecutive quarter |

[0001571996-19-000021:8k_2_02:33]
| • | Double-digit revenue growth in commercial notebooks, desktops, and workstations |

[0001571996-19-000021:8k_2_02:34]
| • | Launched new Dell Latitude mobile PC portfolio with breakthroughs in security, productivity, and connectivity |

[0001571996-19-000021:8k_2_02:35]
VMware revenue was $2.3 billion for the first quarter, up 13 percent driven by broad-based strength across a diverse product portfolio. Operating income for the first quarter was $614 million, or 26.9 percent of VMware revenue.

[0001571996-19-000021:8k_2_02:36]
Conference call information

[0001571996-19-000021:8k_2_02:37]
As previously announced, the company will hold a conference call to discuss its first quarter performance today, May 30, 2019 at 4:30 p.m. CST.  The conference call will be broadcast live over the internet and can be accessed at https://investors.delltechnologies.com/events-and-presentations/upcoming-events  For those unable to listen to the live broadcast, an archived version will be available at the same location for one year.

[0001571996-19-000021:8k_2_02:38]
A slide presentation containing additional financial and operating information may be downloaded from Dell Technologies’ website at https://investors.delltechnologies.com/financial-information/quarterly-results

[0001571996-19-000021:8k_2_02:39]
About Dell Technologies

[0001571996-19-000021:8k_2_02:40]
Dell Technologies (NYSE:DELL) is a unique family of businesses that helps organizations and individuals build their digital future and transform how they work and live.  The company provides customers with the industry’s broadest and most innovative technology and services portfolio spanning from edge to core to cloud.  The Dell Technologies family includes Dell, Dell EMC, Pivotal, RSA, Secureworks, Virtustream and VMware.

[0001571996-19-000021:8k_2_02:41]
CONTACTS:

[0001571996-19-000021:8k_2_02:42]
Investor Relations: Investor_Relations@Dell.com

[0001571996-19-000021:8k_2_02:43]
Media Relations: Media.Relations@Dell.com

[0001571996-19-000021:8k_2_02:44]
# # #

[0001571996-19-000021:8k_2_02:45]
Copyright © 2019 Dell Inc. or its subsidiaries.  All Rights Reserved. Dell Technologies, Dell, EMC and Dell EMC are trademarks of Dell Inc. or its subsidiaries.  Other trademarks may be trademarks of their respective owners.

[0001571996-19-000021:8k_2_02:46]
| 1 | Due to the EMC transaction, significant non-cash bridging items will remain between GAAP and non-GAAP results for the next few years. |

[0001571996-19-000021:8k_2_02:47]
| 2 | IDC WW Quarterly Personal Computing Device (PCD) Tracker CY19Q1 |

[0001571996-19-000021:8k_2_02:48]
3

[0001571996-19-000021:8k_2_02:49]
Non-GAAP Financial Measures:

[0001571996-19-000021:8k_2_02:50]
This press release presents information about Dell Technologies’ non-GAAP net revenue, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP operating income, non-GAAP net income, non-GAAP net income attributable to non-controlling interest, non-GAAP net income attributable to Dell Technologies Inc. - basic, non-GAAP net income attributable to Dell Technologies Inc. - diluted, non-GAAP earnings per share attributable to Dell Technologies Inc. - basic, non-GAAP earnings per share attributable to Dell Technologies Inc. - diluted, EBITDA, and adjusted EBITDA, which are non-GAAP financial measures provided as a supplement to the results provided in accordance with generally accepted accounting principles in the United States of America (“GAAP”). A reconciliation of each non-GAAP financial measure to the most directly comparable historical GAAP financial measure is provided in the attached tables for each of the fiscal periods indicated.

[0001571996-19-000021:8k_2_02:51]
Special Note on Forward-Looking Statements:

[0001571996-19-000021:8k_2_02:52]
Dell Technologies’ results or events in future periods could differ materially from those expressed or implied by these forward-looking statements because of risks, uncertainties, and other factors that include, but are not limited to, the following: competitive pressures; Dell Technologies’ reliance on third-party suppliers for products and components, including reliance on single-source or limited-source suppliers; Dell Technologies’ ability to achieve favorable pricing from its vendors; adverse global economic conditions and instability in financial markets; Dell Technologies’ execution of its growth, business and acquisition strategies; the success of Dell Technologies’ cost efficiency measures; Dell Technologies’ ability to manage solutions and products and services transitions in an effective manner; Dell Technologies’ ability to deliver high-quality products and services; Dell Technologies’ foreign operations and ability to generate substantial non-U.S. net revenue; Dell Technologies’ product, customer, and geographic sales mix, and seasonal sales trends; the performance of Dell Technologies’ sales channel partners; access to the capital markets by Dell Technologies or its customers; weak economic conditions and additional regulation; counterparty default risks; the loss by Dell Technologies of any services contracts with its customers, including government contracts, and its ability to perform such contracts at its estimated costs; Dell Technologies’ ability to develop and protect its proprietary intellectual property or obtain licenses to intellectual property developed by others on commercially reasonable and competitive terms; infrastructure disruptions, cyberattacks, or other data security breaches; Dell Technologies’ ability to hedge effectively its exposure to fluctuations in foreign currency exchange rates and interest rates; expiration of tax holidays or favorable tax rate structures, or unfavorable outcomes in tax audits and other tax compliance matters; impairment of portfolio investments; unfavorable results of legal proceedings; increased costs and additional regulations and requirements as a result of Dell Technologies’ operation as a public company; Dell Technologies’ ability to develop and maintain effective internal control over financial reporting; compliance requirements of changing environmental and safety laws; the effect of armed hostilities, terrorism, natural disasters, and public health issues; Dell Technologies’ substantial level of indebtedness; the impact of the financial performance of VMware; and the market volatility of Dell Technologies’ pension plan assets.

[0001571996-19-000021:8k_2_02:53]
This list of risks, uncertainties, and other factors is not complete. Dell Technologies discusses some of these matters more fully, as well as certain risk factors that could affect Dell Technologies’ business, financial condition, results of operations, and prospects, in its reports filed with the SEC, including Dell Technologies’ annual report on Form 10-K for the fiscal year ended February 1, 2019, quarterly reports on Form 10-Q, and current reports on Form 8-K. These filings are available for review through the SEC’s website at www.sec.gov. Any or all forward-looking statements Dell Technologies makes may turn out to be wrong and can be affected by inaccurate assumptions Dell Technologies might make or by known or unknown risks, uncertainties and other factors, including those identified in this press release. Accordingly, you should not place undue reliance on the forward-looking statements made in this press release, which speak only as of its date. Dell Technologies does not undertake to update, and expressly disclaims any duty to update, its forward-looking statements, whether as a result of circumstances or events that arise after the date they are made, new information, or otherwise.

[0001571996-19-000021:8k_2_02:54]
4

[0001571996-19-000021:8k_2_02:55]
DELL TECHNOLOGIES INC.

[0001571996-19-000021:8k_2_02:56]
Condensed Consolidated Statements of Income (Loss) and Related Financial Highlights

[0001571996-19-000021:8k_2_02:57]
(in millions, except percentages; unaudited)

[0001571996-19-000021:8k_2_02:58]
|  | Three Months Ended |  |  |
|  | May 3, 2019 |  | May 4, 2018 |  | Change |
| Net revenue: |  |  |  |  |  |
| Products | $ | 16,754 |  |  | $ | 16,671 |  |  | —% |
| Services | 5,154 |  |  | 4,685 |  |  | 10% |
| Total net revenue | 21,908 |  |  | 21,356 |  |  | 3% |
| Cost of net revenue: |  |  |  |  |  |
| Products | 13,079 |  |  | 13,606 |  |  | (4)% |
| Services | 2,032 |  |  | 1,872 |  |  | 9% |
| Total cost of net revenue | 15,111 |  |  | 15,478 |  |  | (2)% |
| Gross margin | 6,797 |  |  | 5,878 |  |  | 16% |
| Operating expenses: |  |  |  |  |  |
| Selling, general, and administrative | 5,071 |  |  | 4,944 |  |  | 3% |
| Research and development | 1,176 |  |  | 1,087 |  |  | 8% |
| Total operating expenses | 6,247 |  |  | 6,031 |  |  | 4% |
| Operating income (loss) | 550 |  |  | (153 | ) |  | 459% |
| Interest and other, net | (693 | ) |  | (470 | ) |  | (47)% |
| Loss before income taxes | (143 | ) |  | (623 | ) |  | 77% |
| Income tax benefit | (472 | ) |  | (85 | ) |  | (455)% |
| Net income (loss) | 329 |  |  | (538 | ) |  | 161% |
| Less: Net income attributable to non-controlling interests | 36 |  |  | 98 |  |  | 63% |
| Net income (loss) attributable to Dell Technologies Inc. | $ | 293 |  |  | $ | (636 | ) |  | 146% |
| Percentage of Total Net Revenue: |  |  |  |  |  |
| Gross margin | 31 | % |  | 28 | % |  |  |
| Selling, general, and administrative | 23 | % |  | 23 | % |  |  |
| Research and development | 5 | % |  | 5 | % |  |  |
| Operating expenses | 29 | % |  | 28 | % |  |  |
| Operating income (loss) | 3 | % |  | (1 | )% |  |  |
| Loss before income taxes | (1 | )% |  | (3 | )% |  |  |
| Net income (loss) | 2 | % |  | (3 | )% |  |  |
| Income tax rate | 330.1 | % |  | 13.6 | % |  |  |

[0001571996-19-000021:8k_2_02:59]
5

[0001571996-19-000021:8k_2_02:60]
DELL TECHNOLOGIES INC.

[0001571996-19-000021:8k_2_02:61]
Consolidated Statements of Financial Position

[0001571996-19-000021:8k_2_02:62]
(in millions; unaudited)

[0001571996-19-000021:8k_2_02:63]
|  | May 3, 2019 |  | February 1, 2019 |
| ASSETS |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 9,040 |  |  | $ | 9,676 |  |
| Short-term investments | — |  |  | — |  |
| Accounts receivable, net | 10,517 |  |  | 12,371 |  |
| Short-term financing receivables, net | 4,277 |  |  | 4,398 |  |
| Inventories, net | 3,360 |  |  | 3,649 |  |
| Other current assets | 6,461 |  |  | 6,044 |  |
| Total current assets | 33,655 |  |  | 36,138 |  |
| Property, plant, and equipment, net | 5,505 |  |  | 5,259 |  |
| Long-term investments | 782 |  |  | 1,005 |  |
| Long-term financing receivables, net | 4,131 |  |  | 4,224 |  |
| Goodwill | 40,015 |  |  | 40,089 |  |
| Intangible assets, net | 20,948 |  |  | 22,270 |  |
| Other non-current assets | 4,856 |  |  | 2,835 |  |
| Total assets | $ | 109,892 |  |  | $ | 111,820 |  |
| LIABILITIES, REDEEMABLE SHARES, AND STOCKHOLDERS’ EQUITY (DEFICIT) |
| Current liabilities: |  |  |  |
| Short-term debt | $ | 4,884 |  |  | $ | 4,320 |  |
| Accounts payable | 18,097 |  |  | 19,213 |  |
| Accrued and other | 7,455 |  |  | 8,495 |  |
| Short-term deferred revenue | 13,043 |  |  | 12,944 |  |
| Total current liabilities | 43,479 |  |  | 44,972 |  |
| Long-term debt | 48,640 |  |  | 49,201 |  |
| Long-term deferred revenue | 11,135 |  |  | 11,066 |  |
| Other non-current liabilities | 6,525 |  |  | 6,327 |  |
| Total liabilities | 109,779 |  |  | 111,566 |  |
| Redeemable shares | 1,774 |  |  | 1,196 |  |
| Stockholders’ equity (deficit): |  |  |  |
| Total Dell Technologies Inc. stockholders’ equity (deficit) | (6,464 | ) |  | (5,765 | ) |
| Non-controlling interests | 4,803 |  |  | 4,823 |  |
| Total stockholders’ equity (deficit) | (1,661 | ) |  | (942 | ) |
| Total liabilities, redeemable shares, and stockholders’ equity (deficit) | $ | 109,892 |  |  | $ | 111,820 |  |

[0001571996-19-000021:8k_2_02:64]
6

[0001571996-19-000021:8k_2_02:65]
DELL TECHNOLOGIES INC.

[0001571996-19-000021:8k_2_02:66]
Condensed Consolidated Statements of Cash Flows

[0001571996-19-000021:8k_2_02:67]
(in millions; unaudited)

[0001571996-19-000021:8k_2_02:68]
|  | Three Months Ended |
|  | May 3, 2019 |  | May 4, 2018 |
| Cash flows from operating activities: |  |  |  |
| Net income (loss) | $ | 329 |  |  | $ | (538 | ) |
| Adjustments to reconcile net loss to net cash provided by operating activities | 353 |  |  | 1,697 |  |
| Change in cash from operating activities | 682 |  |  | 1,159 |  |
| Cash flows from investing activities: |  |  |  |
| Investments: |  |  |  |
| Purchases | (38 | ) |  | (439 | ) |
| Maturities and sales | 337 |  |  | 531 |  |
| Capital expenditures | (610 | ) |  | (273 | ) |
| Proceeds from sale of facilities, land, and other assets | — |  |  | 10 |  |
| Capitalized software development costs | (106 | ) |  | (89 | ) |
| Collections on purchased financing receivables | 7 |  |  | 10 |  |
| Acquisition of businesses, net | (45 | ) |  | — |  |
| Divestitures of businesses, net | — |  |  | 142 |  |
| Asset acquisitions, net | — |  |  | (38 | ) |
| Asset dispositions, net | (3 | ) |  | (3 | ) |
| Change in cash from investing activities | (458 | ) |  | (149 | ) |
| Cash flows from financing activities: |  |  |  |
| Share repurchases for tax withholdings of equity awards | (215 | ) |  | (100 | ) |
| Proceeds from the issuance of common stock of subsidiaries | 133 |  |  | 642 |  |
| Repurchases of common stock of subsidiaries | (592 | ) |  | — |  |
| Proceeds from debt | 9,563 |  |  | 1,863 |  |
| Repayments of debt | (9,569 | ) |  | (1,822 | ) |
| Other | (39 | ) |  | (40 | ) |
| Change in cash from financing activities | (719 | ) |  | 543 |  |
| Effect of exchange rate changes on cash, cash equivalents, and restricted cash | (36 | ) |  | (86 | ) |
| Change in cash, cash equivalents, and restricted cash | (531 | ) |  | 1,467 |  |
| Cash, cash equivalents, and restricted cash at beginning of the period | 10,240 |  |  | 14,378 |  |
| Cash, cash equivalents, and restricted cash at end of the period | $ | 9,709 |  |  | $ | 15,845 |  |

[0001571996-19-000021:8k_2_02:69]
7

[0001571996-19-000021:8k_2_02:70]
DELL TECHNOLOGIES INC.

[0001571996-19-000021:8k_2_02:71]
Segment Information

[0001571996-19-000021:8k_2_02:72]
(in millions, except percentages; unaudited; continued on next page)

[0001571996-19-000021:8k_2_02:73]
|  | Three Months Ended |  |  |
|  | May 3, 2019 |  | May 4, 2018 |  | Change |
| Infrastructure Solutions Group (ISG): |  |  |  |  |  |
| Net Revenue: |  |  |  |  |  |
| Servers and networking | $ | 4,180 |  |  | $ | 4,585 |  |  | (9)% |
| Storage | 4,022 |  |  | 4,082 |  |  | (1)% |
| Total ISG net revenue | $ | 8,202 |  |  | $ | 8,667 |  |  | (5)% |
| Operating Income: |  |  |  |  |  |
| ISG operating income | $ | 843 |  |  | $ | 939 |  |  | (10)% |
| % of ISG net revenue | 10 | % |  | 11 | % |  |  |
| % of total reportable segment operating income | 37 | % |  | 45 | % |  |  |
| Client Solutions Group (CSG): |  |  |  |  |  |
| Net Revenue: |  |  |  |  |  |
| Commercial | $ | 8,307 |  |  | $ | 7,363 |  |  | 13% |
| Consumer | 2,603 |  |  | 2,908 |  |  | (10)% |
| Total CSG net revenue | $ | 10,910 |  |  | $ | 10,271 |  |  | 6% |
| Operating Income: |  |  |  |  |  |
| CSG operating income | $ | 793 |  |  | $ | 533 |  |  | 49% |
| % of CSG net revenue | 7 | % |  | 5 | % |  |  |
| % of total reportable segment operating income | 35 | % |  | 26 | % |  |  |
| VMware: |  |  |  |  |  |
| Net Revenue: |  |  |  |  |  |
| Total VMware net revenue | $ | 2,282 |  |  | $ | 2,028 |  |  | 13% |
| Operating Income: |  |  |  |  |  |
| VMware operating income | $ | 614 |  |  | $ | 613 |  |  | —% |
| % of VMware net revenue | 27 | % |  | 30 | % |  |  |
| % of total reportable segment operating income | 27 | % |  | 29 | % |  |  |

[0001571996-19-000021:8k_2_02:74]
8

[0001571996-19-000021:8k_2_02:75]
DELL TECHNOLOGIES INC.

[0001571996-19-000021:8k_2_02:76]
Segment Information

[0001571996-19-000021:8k_2_02:77]
(in millions, except percentages; unaudited; continued)

[0001571996-19-000021:8k_2_02:78]
|  | Three Months Ended |
|  | May 3, 2019 |  | May 4, 2018 |
| Reconciliation to consolidated net revenue: |  |  |
| Reportable segment net revenue | $ | 21,394 |  |  | $ | 20,966 |  |
| Other businesses (a) | 596 |  |  | 579 |  |
| Unallocated transactions (b) | — |  |  | (2 | ) |
| Impact of purchase accounting (c) | (82 | ) |  | (187 | ) |
| Total consolidated net revenue | $ | 21,908 |  |  | $ | 21,356 |  |
| Reconciliation to consolidated operating income (loss): |
| Reportable segment operating income | $ | 2,250 |  |  | $ | 2,085 |  |
| Other businesses (a) | (53 | ) |  | (50 | ) |
| Unallocated transactions (b) | (1 | ) |  | (9 | ) |
| Impact of purchase accounting (c) | (101 | ) |  | (222 | ) |
| Amortization of intangibles | (1,217 | ) |  | (1,522 | ) |
| Transaction-related expenses (d) | (42 | ) |  | (166 | ) |
| Stock-based compensation expense (e) | (263 | ) |  | (199 | ) |
| Other corporate expenses (f) | (23 | ) |  | (70 | ) |
| Total consolidated operating income (loss) | $ | 550 |  |  | $ | (153 | ) |

[0001571996-19-000021:8k_2_02:79]
_________________

[0001571996-19-000021:8k_2_02:80]
| (a) | Pivotal, SecureWorks, RSA Security, Virtustream, and Boomi constitute “Other businesses” and do not meet the requirements for a reportable segment, either individually or collectively. The results of Other businesses are not material to the Company’s overall results. |

[0001571996-19-000021:8k_2_02:81]
| (b) | Unallocated transactions includes long-term incentives, certain short-term incentive compensation expenses, and other corporate items that are not allocated to Dell Technologies’ reportable segments. |

[0001571996-19-000021:8k_2_02:82]
| (c) | Impact of purchase accounting includes non-cash purchase accounting adjustments that are primarily related to the EMC merger transaction. |

[0001571996-19-000021:8k_2_02:83]
| (d) | Transaction-related expenses includes acquisition, integration, and divestiture related costs, as well as the costs incurred in the Class V transaction. |

[0001571996-19-000021:8k_2_02:84]
| (e) | Stock-based compensation expense consists of equity awards granted based on the estimated fair value of those awards at grant date. |

[0001571996-19-000021:8k_2_02:85]
| (f) | Other corporate expenses includes severance and facility action costs. |

[0001571996-19-000021:8k_2_02:86]
9

[0001571996-19-000021:8k_2_02:87]
SUPPLEMENTAL SELECTED NON-GAAP FINANCIAL MEASURES

[0001571996-19-000021:8k_2_02:88]
These tables present information about the Company’s non-GAAP net revenue, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP operating income, non-GAAP net income, non-GAAP net income attributable to non-controlling interest, non-GAAP net income attributable to Dell Technologies Inc. - basic, non-GAAP net income attributable to Dell Technologies Inc. - diluted, non-GAAP earnings per share attributable to Dell Technologies Inc. - basic, non-GAAP earnings per share attributable to Dell Technologies Inc. - diluted, EBITDA, and adjusted EBITDA, which are non-GAAP financial measures provided as a supplement to the results provided in accordance with generally accepted accounting principles in the United States of America (“GAAP”). A detailed discussion of Dell Technologies’ reasons for including these non-GAAP financial measures, the limitations associated with these measures, the items excluded from these measures, and our reason for excluding those items are presented in “Management’s Discussion and Analysis of Financial Condition and Results of Operations - Non-GAAP Financial Measures” in our periodic reports filed with the SEC. Dell Technologies encourages investors to review the non-GAAP discussion in conjunction with the presentation of non-GAAP financial measures.

[0001571996-19-000021:8k_2_02:89]
10

[0001571996-19-000021:8k_2_02:90]
DELL TECHNOLOGIES INC.

[0001571996-19-000021:8k_2_02:91]
Selected Non-GAAP Financial Measures

[0001571996-19-000021:8k_2_02:92]
(in millions, except percentages; unaudited)

[0001571996-19-000021:8k_2_02:93]
|  | Three Months Ended |  |  |
|  | May 3, 2019 |  | May 4, 2018 |  | Change |
| Non-GAAP net revenue | $ | 21,990 |  |  | $ | 21,543 |  |  | 2% |
| Non-GAAP gross margin | $ | 7,434 |  |  | $ | 6,919 |  |  | 7% |
| % of non-GAAP net revenue | 34 | % |  | 32 | % |  |  |
| Non-GAAP operating expenses | $ | 5,238 |  |  | $ | 4,893 |  |  | 7% |
| % of non-GAAP net revenue | 24 | % |  | 23 | % |  |  |
| Non-GAAP operating income | $ | 2,196 |  |  | $ | 2,026 |  |  | 8% |
| % of non-GAAP net revenue | 10 | % |  | 9 | % |  |  |
| Non-GAAP net income (a) | $ | 1,209 |  |  | $ | 1,179 |  |  | 3% |
| % of non-GAAP net revenue | 5 | % |  | 5 | % |  |  |
| Adjusted EBITDA | $ | 2,573 |  |  | $ | 2,383 |  |  | 8% |
| % of non-GAAP net revenue | 12 | % |  | 11 | % |  |  |

[0001571996-19-000021:8k_2_02:94]
_________________

[0001571996-19-000021:8k_2_02:95]
| (a) | Non-GAAP net income has been recast to exclude fair value adjustments on equity investments, the corresponding tax effects of those adjustments, and discrete tax items. |

[0001571996-19-000021:8k_2_02:96]
11

[0001571996-19-000021:8k_2_02:97]
DELL TECHNOLOGIES INC.

[0001571996-19-000021:8k_2_02:98]
Reconciliation of Selected Non-GAAP Financial Measures

[0001571996-19-000021:8k_2_02:99]
(in millions, except percentages; unaudited; continued on next page)

[0001571996-19-000021:8k_2_02:100]
|  | Three Months Ended |  |  |
|  | May 3, 2019 |  | May 4, 2018 |  | Change |
| Net revenue | $ | 21,908 |  |  | $ | 21,356 |  |  | 3% |
| Non-GAAP adjustments: |  |  |  |  |  |
| Impact of purchase accounting | 82 |  |  | 187 |  |  |  |
| Non-GAAP net revenue | $ | 21,990 |  |  | $ | 21,543 |  |  | 2% |
| Gross margin | $ | 6,797 |  |  | $ | 5,878 |  |  | 16% |
| Non-GAAP adjustments: |  |  |  |  |  |
| Amortization of intangibles | 519 |  |  | 710 |  |  |  |
| Impact of purchase accounting | 84 |  |  | 193 |  |  |  |
| Transaction-related expenses | (5 | ) |  | 116 |  |  |  |
| Stock-based compensation expense | 26 |  |  | 16 |  |  |  |
| Other corporate expenses | 13 |  |  | 6 |  |  |  |
| Non-GAAP gross margin | $ | 7,434 |  |  | $ | 6,919 |  |  | 7% |
| Operating expenses | $ | 6,247 |  |  | $ | 6,031 |  |  | 4% |
| Non-GAAP adjustments: |  |  |  |  |  |
| Amortization of intangibles | (698 | ) |  | (812 | ) |  |  |
| Impact of purchase accounting | (17 | ) |  | (29 | ) |  |  |
| Transaction-related expenses | (47 | ) |  | (50 | ) |  |  |
| Stock-based compensation expense | (237 | ) |  | (183 | ) |  |  |
| Other corporate expenses | (10 | ) |  | (64 | ) |  |  |
| Non-GAAP operating expenses | $ | 5,238 |  |  | $ | 4,893 |  |  | 7% |
| Operating income (loss) | $ | 550 |  |  | $ | (153 | ) |  | 459% |
| Non-GAAP adjustments: |  |  |  |  |  |
| Amortization of intangibles | 1,217 |  |  | 1,522 |  |  |  |
| Impact of purchase accounting | 101 |  |  | 222 |  |  |  |
| Transaction-related expenses | 42 |  |  | 166 |  |  |  |
| Stock-based compensation expense | 263 |  |  | 199 |  |  |  |
| Other corporate expenses | 23 |  |  | 70 |  |  |  |
| Non-GAAP operating income | $ | 2,196 |  |  | $ | 2,026 |  |  | 8% |

[0001571996-19-000021:8k_2_02:101]
12

[0001571996-19-000021:8k_2_02:102]
DELL TECHNOLOGIES INC.

[0001571996-19-000021:8k_2_02:103]
Reconciliation of Selected Non-GAAP Financial Measures

[0001571996-19-000021:8k_2_02:104]
(in millions, except percentages; unaudited; continued)

[0001571996-19-000021:8k_2_02:105]
|  | Three Months Ended |  |  |
|  | May 3, 2019 |  | May 4, 2018 |  | Change |
| Net income (loss) | $ | 329 |  |  | $ | (538 | ) |  | 161% |
| Non-GAAP adjustments: |  |  |  |  |  |
| Amortization of intangibles | 1,217 |  |  | 1,522 |  |  |  |
| Impact of purchase accounting | 101 |  |  | 222 |  |  |  |
| Transaction-related expenses | 42 |  |  | 166 |  |  |  |
| Stock-based compensation expense | 263 |  |  | 199 |  |  |  |
| Other corporate expenses | 23 |  |  | 70 |  |  |  |
| Fair value adjustments on equity investments | (62 | ) |  | (107 | ) |  |  |
| Aggregate adjustment for income taxes | (704 | ) |  | (355 | ) |  |  |
| Non-GAAP net income (a) | $ | 1,209 |  |  | $ | 1,179 |  |  | 3% |
| Net income (loss) | $ | 329 |  |  | $ | (538 | ) |  | 161% |
| Adjustments: |  |  |  |  |  |
| Interest and other, net | 693 |  |  | 470 |  |  |  |
| Income tax provision (benefit) | (472 | ) |  | (85 | ) |  |  |
| Depreciation and amortization | 1,616 |  |  | 1,914 |  |  |  |
| EBITDA | $ | 2,166 |  |  | $ | 1,761 |  |  | 23% |
| EBITDA | $ | 2,166 |  |  | $ | 1,761 |  |  | 23% |
| Adjustments: |  |  |  |  |  |
| Stock-based compensation expense | 263 |  |  | 199 |  |  |  |
| Impact of purchase accounting | 83 |  |  | 222 |  |  |  |
| Transaction-related expenses | 42 |  |  | 166 |  |  |  |
| Other corporate expenses | 19 |  |  | 35 |  |  |  |
| Adjusted EBITDA | $ | 2,573 |  |  | $ | 2,383 |  |  | 8% |

[0001571996-19-000021:8k_2_02:106]
_________________

[0001571996-19-000021:8k_2_02:107]
| (a) | Non-GAAP net income has been recast to exclude fair value adjustments on equity investments, the corresponding tax effects of those adjustments, and discrete tax items. |

[0001571996-19-000021:8k_2_02:108]
13

[0001571996-19-000021:8k_2_02:109]
DELL TECHNOLOGIES INC.

[0001571996-19-000021:8k_2_02:110]
Reconciliation of Selected Non-GAAP Financial Measures

[0001571996-19-000021:8k_2_02:111]
For the Three Months Ended May 3, 2019

[0001571996-19-000021:8k_2_02:112]
(in millions, except per share amounts; unaudited)

[0001571996-19-000021:8k_2_02:113]
|  | GAAP |  | Amortization of intangibles |  | Impact of purchase accounting |  | Transaction-related expenses |  | Stock-based compensation expense |  | Other corporate expenses |  | Fair value adjustments on equity investments |  | Aggregate adjustment for income taxes |  | Non-GAAP |
| Net income | $ | 329 |  |  | 1,217 |  |  | 101 |  |  | 42 |  |  | 263 |  |  | 23 |  |  | (62 | ) |  | (704 | ) |  | $ | 1,209 |  |
| Less: Net income attributable to non-controlling interests (a) | 36 |  |  | 72 |  |  | 6 |  |  | 3 |  |  | 46 |  |  | — |  |  | (25 | ) |  | (29 | ) |  | 109 |  |
| Net income attributable to Dell Technologies Inc. - basic | 293 |  |  | 1,145 |  |  | 95 |  |  | 39 |  |  | 217 |  |  | 23 |  |  | (37 | ) |  | (675 | ) |  | 1,100 |  |
| Incremental dilution from VMware, Inc. attributable to Dell Technologies Inc. (b) | (8 | ) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | (8 | ) |
| Net income attributable to Dell Technologies Inc. - diluted | $ | 285 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 1,092 |  |
| Earnings per share - basic | $ | 0.41 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 1.53 |  |
| Earnings per share - diluted | $ | 0.38 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 1.45 |  |
| Weighted-average shares outstanding - basic | 717 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 717 |  |
| Weighted-average shares outstanding - diluted | 751 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 751 |  |

[0001571996-19-000021:8k_2_02:114]
_________________

[0001571996-19-000021:8k_2_02:115]
| (a) | Net income attributable to non-controlling interests is calculated by multiplying the minority interest percentage of VMware Inc., Pivotal Software Inc., and SecureWorks Corp. by their non-GAAP net income adjustments for the period presented. |

[0001571996-19-000021:8k_2_02:116]
| (b) | Incremental dilution from VMware, Inc. attributable to Dell Technologies Inc. represents the impact of VMware Inc.’s dilutive securities on the diluted earnings per share of Dell Technologies Inc. and is calculated by multiplying the difference between VMware’s basic and diluted earnings per share by the number of shares of VMware Inc. common stock held by Dell Technologies Inc. |

[0001571996-19-000021:8k_2_02:117]
14
