# DELL note change history — 0001571996-18-000044 → 0001571996-19-000025


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- added (2019-06-10):
[0001571996-19-000025:note_history:1]
Securities Litigation — On May 21, 2014, a securities class action seeking compensatory damages was filed in the United States District Court for the Southern District of New York, captioned City of Pontiac General Employees’ Retirement System v. Dell Inc., et. al. (Case No. 1:14-cv-03644).  The action names as defendants Dell Inc. and certain current and former executive officers, and alleges that Dell made false and misleading statements about Dell’s financial results and future prospects between February 21, 2012 and May 22, 2012, which resulted in artificially inflated stock prices.  The case was transferred to the United States District Court for the Western District of Texas under the same caption (Case No. 1:15-cv-00374), where the defendants filed a motion to dismiss.  On September 16, 2016, the Court denied the motion to dismiss.  On March 29, 2018, the Court granted the plaintiffs’ motion for class certification, and certified a class consisting of all purchasers of Dell common stock between February 22, 2012 and May 22, 2012.  Fact and expert discovery is now closed.  Dell filed a motion for summary judgment on February 18, 2019, which is now fully-briefed and pending before the Court.  If the matter is not dismissed, a trial is currently set for October 2019.

- added (2019-06-10):
[0001571996-19-000025:note_history:2]
Class Actions Related to the Class V Transaction — Four purported stockholders brought putative class action complaints arising out of the Class V transaction described in Note 14 of the Notes to the Consolidated Financial Statements.  The actions were captioned Hallandale Beach Police and Fire Retirement Plan v. Michael Dell et al. (Civil Action No. 2018-0816-JTL), Howard Karp v. Michael Dell et al. (Civil Action No. 2019-0032-JTL), Miramar Police Officers’ Retirement Plan v. Michael Dell et al. (Civil Action No. 2019-0049-JTL), and Steamfitters Local 449 Pension Plan v. Michael Dell et al. (Civil Action No. 2019-0115-JTL).  The four actions were consolidated into In Re Dell Class V Litigation (Consol. C.A. No. 2018-0816-JTL), which names as defendants the Company’s board of directors and certain stockholders of the Company, including Michael S. Dell and entities through which Mr. Dell allegedly holds a portion of his and/or his family’s stock.  The plaintiffs generally allege that the defendants breached their fiduciary duties to the former holders of Class V Common Stock in connection with the Class V transaction by allegedly causing the Company to enter into a transaction that favored the interests of the controlling stockholders at the expense of such former stockholders.  The Defendants intend to file a motion to dismiss the action.

- added (2019-06-10):
[0001571996-19-000025:note_history:3]
Copyright Levies — The Company is involved in various proceedings and negotiations regarding Dell’s obligation to collect and remit copyright levies in certain European Union (“EU”) countries.  The Company continues to collect levies in EU countries where it has determined that local laws require payment.  The Company, along with other companies and/or industry associations, also continues to oppose levy schemes that do not comply with EU law.  The Company does not currently anticipate that any of these matters will have a material adverse effect on its business, financial condition, results of operations, or cash flows.

- added (2019-06-10):
[0001571996-19-000025:note_history:4]
Other Litigation — The various legal proceedings in which Dell is involved include commercial and intellectual property litigation.  Dell does not currently anticipate that any of these matters will have a material adverse effect on its business, financial condition, results of operations, or cash flows.

- changed (2019-06-10):
[0001571996-19-000025:note_history:5]
As of May 3, 2019, the Company does not believe there is a reasonable possibility that a material loss exceeding the amounts already accrued for these or other proceedings or matters has been incurred.  However, since the ultimate resolution of any such proceedings and matters is inherently unpredictable, the Company’s business, financial condition, results of operations, or cash flows could be materially affected in any particular period by unfavorable outcomes in one or more of these proceedings or matters.  Whether the outcome of any claim, suit, assessment, investigation, or legal proceeding, individually or collectively, could have a material adverse effect on the Company’s business, financial condition, results of operations, or cash flows will depend on a number of variables, including the nature, timing, and amount of any associated expenses, amounts paid in settlement, damages, or other remedies or consequences.
  (was, 2018-12-10, similarity 0.9941):
[0001571996-18-000044:note_history:5]
As of November 2, 2018, the Company does not believe there is a reasonable possibility that a material loss exceeding the amounts already accrued for these or other proceedings or matters has been incurred.  However, since the ultimate resolution of any such proceedings and matters is inherently unpredictable, the Company’s business, financial condition, results of operations, or cash flows could be materially affected in any particular period by unfavorable outcomes in one or more of these proceedings or matters.  Whether the outcome of any claim, suit, assessment, investigation, or legal proceeding, individually or collectively, could have a material adverse effect on the Company’s business, financial condition, results of operations, or cash flows will depend on a number of variables, including the nature, timing, and amount of any associated expenses, amounts paid in settlement, damages, or other remedies or consequences.

- removed (2019-06-10):
[0001571996-18-000044:note_history:6]
Appraisal Proceedings — On October 29, 2013, Dell Technologies acquired Dell in a transaction referred to as the going-private transaction.  Holders of shares of Dell common stock who did not vote on September 12, 2013 in favor of the proposal to adopt the amended going-private transaction agreement and who properly demanded appraisal of their shares and who otherwise comply with the requirements of Section 262 of the Delaware General Corporate Law (“DGCL”) are entitled to seek appraisal for, and obtain payment in cash for the judicially determined “fair value” (as defined pursuant to Section 262 of the DGCL) of, their shares in lieu of receiving the going-private transaction consideration. The liability for the appraisal proceedings was approximately $129 million as of February 2, 2018.  On May 8, 2018, the Company entered into an agreement to settle a portion of the liability related to the appraisal proceedings in the amount of approximately $70 million, and on May 18, 2018, this portion of the liability was fully paid.  The Company settled with the remaining plaintiffs as of July 16, 2018 in the amount of approximately $30 million.  The remaining liability accrual was released to Interest and other, net during the three months ended August 3, 2018.  As of August 3, 2018, there was no remaining liability for appraisal proceedings.

- removed (2019-06-10):
[0001571996-18-000044:note_history:7]
Securities Litigation — On May 22, 2014, a securities class action seeking compensatory damages was filed in the United States District Court for the Southern District of New York, captioned the City of Pontiac Employee Retirement System vs. Dell Inc. et. al. (Case No. 1:14-cv-03644).  The action names as defendants Dell Inc. and certain current and former executive officers, and alleges that Dell made false and misleading statements about Dell’s business operations and products between February 22, 2012 and May 22, 2012, which resulted in artificially inflated stock prices.  The case was transferred to the United States District Court for the Western District of Texas, where the defendants filed a motion to dismiss.  On September 16, 2016, the Court denied the motion to dismiss and the case is proceeding with discovery.  The defendants believe the claims asserted are without merit and the risk of material loss is remote.

- removed (2019-06-10):
[0001571996-18-000044:note_history:8]
Copyright Levies — The Company’s obligation to collect and remit copyright levies in certain European Union (“EU”) countries may be affected by the resolution of legal proceedings pending in Germany and other EU member states against various companies, including Dell subsidiaries.  The plaintiffs in those proceedings generally seek to impose or modify the levies with respect to sales of such equipment as multifunction devices, phones, personal computers, storage devices, and printers, alleging that such products enable the copying of copyrighted materials.  Some of the proceedings also challenge whether the levy schemes in those countries comply with EU law.  Certain EU member countries that do not yet impose levies on digital devices are expected to implement legislation to enable them to extend existing levy schemes, while some other EU member countries are expected to limit the scope of levy schemes and their applicability in the digital hardware environment.  Dell, other companies, and various industry associations have opposed the extension of levies to the digital environment and have advocated alternative models of compensation to rights holders.

- removed (2019-06-10):
[0001571996-18-000044:note_history:9]
The Company continues to collect levies in certain EU countries where it has determined that based on local laws it is probable that it has a payment obligation.  The amount of levies is generally based on the number of products sold and the per-product amounts of the levies, which vary.  The Company accrues a liability when it believes that it is both probable that a loss has been incurred and when it can reasonably estimate the amount of the loss.

- removed (2019-06-10):
[0001571996-18-000044:note_history:10]
Other Litigation — The various legal proceedings in which Dell is involved include commercial litigation and a variety of patent suits.  In some of these cases, Dell is the sole defendant.  More often, particularly in the patent suits, Dell is one of a number of defendants in the electronics and technology industries.  Dell is actively defending a number of patent infringement suits, and several pending claims are in various stages of evaluation.  While the number of patent cases varies over time, Dell does not currently anticipate that any of these matters will have a material adverse effect on its business, financial condition, results of operations, or cash flows.

- removed (2019-06-10):
[0001571996-18-000044:note_history:11]
Class V Transaction Litigation — On October 31, 2018, High River Limited Partnership, Icahn Partners Master Fund LP, and Icahn Partners LP filed an action against Dell in Delaware Chancery Court, pursuant to Section 220 of the DGCL, seeking (1) to inspect certain of the Company’s books and records purportedly related to the Class V transaction described in Note 16 of the Notes to the Condensed Consolidated Financial Statements or the potential initial public offering of the Company’s Class C Common Stock, and (2) the public dissemination of unspecified materials already produced for inspection (High River LP v. Dell Tech. Holdings Inc., No. 2018-0790 (Del. Ch. filed Oct. 31, 2018)).  By motion dated October 31, 2018, the plaintiffs sought expedited treatment of their claims.  On November 1, 2018, Dell filed its opposition to the motion for expedited treatment.  On November 5, 2018, the Chancery Court scheduled a trial on the matter for November 19, 2018.  Prior to the scheduled trial, on November 15, 2018, the plaintiffs voluntarily dismissed this action against the Company.

- removed (2019-06-10):
[0001571996-18-000044:note_history:12]
On November 8, 2018, Hallandale Beach Police and Fire Retirement Plan filed a putative stockholder class action lawsuit against our directors and Michael S. Dell, a separate property trust for the benefit of Mr. Dell’s wife, investment funds affiliated with Silver Lake Partners, and investment funds affiliated with MSD Partners, L.P. in Delaware Chancery Court, alleging, among other things, that the directors of the Company breached their fiduciary duties to holders of the Class V Common Stock in connection with the Class V transaction, because, among other things, the Class V transaction is allegedly financially unfair and coercive to holders of the Class V Common Stock and there were various conflicts of interest (Hallandale Beach Police and Fire Retirement Plan v. Michael Dell, et al., No. 2018-0816-JTL (Del. Ch. filed November 8, 2018)). The lawsuit seeks, among other things, a judicial declaration that that defendants breached their fiduciary duties and an award of damages, fees and costs.


## us-gaap:CommitmentsAndContingenciesPolicyTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- added (2019-06-10):
[0001571996-19-000025:note_history:13]
The Company is involved in various claims, suits, assessments, investigations, and legal proceedings that arise from time to time in the ordinary course of its business, including those identified below, consisting of matters involving consumer, antitrust, tax, intellectual property, and other issues on a global basis.


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: title_similarity, score: 1.0

- added (2019-06-10):
[0001571996-19-000025:note_history:14]
As discussed in Note 1 of the Notes to the Condensed Consolidated Financial Statements, the Company adopted the new lease standard as of February 2, 2019, using the modified retrospective method.  A lease is defined as a contract that conveys the right to control the use of an identified asset for a period of time in exchange for consideration.  The Company enters into contracts that are, or contain, leases as both a lessee and a lessor.  The following accounting policies have been updated as part of the adoption of the new lease standard.

- added (2019-06-10):
[0001571996-19-000025:note_history:15]
Accounting for Operating Leases as a Lessee — In its ordinary course of business, the Company enters into leases as a lessee for office buildings, warehouses, employee vehicles, and equipment.  The Company determines if an arrangement is a lease or contains a lease at inception.  Operating leases result in the recognition of ROU assets and lease liabilities on the Consolidated Statements of Financial Position.  ROU assets represent the right to use an underlying asset for the lease term and lease liabilities represent the obligation to make lease payments arising from the lease, measured on a discounted basis.

- added (2019-06-10):
[0001571996-19-000025:note_history:16]
At lease inception, the lease liability is measured at the present value of the lease payments over the lease term.  The operating lease ROU asset equals the lease liability adjusted for any initial direct costs, prepaid or deferred rent, and lease incentives.

- added (2019-06-10):
[0001571996-19-000025:note_history:17]
The Company uses the implicit rate when readily determinable.  As most of the leases do not provide an implicit rate, the Company uses its incremental borrowing rate based on the information available at the commencement date to determine the present value of lease payments.  Incremental borrowing rates used to determine the present value of lease payments were derived in reference to the Company’s secured-debt yields corresponding to the lease commencement date.

- added (2019-06-10):
[0001571996-19-000025:note_history:18]
The lease term may include options to extend or to terminate the lease that the Company is reasonably certain to exercise.  Lease expense is recognized on a straight-line basis over the lease term in most instances.

- added (2019-06-10):
[0001571996-19-000025:note_history:19]
The Company has elected not to record leases with an initial term of 12 months or less on the Consolidated Statements of Financial Position.  Lease expense on such leases is recognized on a straight-line basis over the lease term.  The Company does not generate material sublease income and has no material related party leases.  The Company’s lease agreements do not contain any material residual value guarantees or material restrictive covenants.

- added (2019-06-10):
[0001571996-19-000025:note_history:20]
The Company’s office building agreements contain costs such as common area maintenance and other executory costs that are variable in nature.  Variable lease costs are expensed as incurred.  The Company combines lease and non-lease components, such as common area and other maintenance costs, in calculating the ROU assets and lease liabilities for its office buildings and employee vehicles.  Under certain service agreements with third-party logistic providers, the Company directs the use of the inventory within the warehouses and, therefore, controls the assets.  The warehouses and some of the equipment used are considered embedded leases.  The Company accounts for the lease and non-lease components separately.  The lease components consist of the warehouses and some of the equipment, such as conveyor belts.  The non-lease components consist of services and other shared equipment, such as material handling and transportation.  The Company allocates the consideration to the lease and non-lease components using their relative standalone values.  See Note 5 of the Notes to the Condensed Consolidated Financial Statements for additional information.

- added (2019-06-10):
[0001571996-19-000025:note_history:21]
Accounting for Leases as a Lessor — The Company’s wholly-owned subsidiary, Dell Financial Services and its affiliates (“DFS”), acts as a lessor to provide equipment financing to customers through a variety of lease arrangements (“DFS leases”).  Subsequent to the adoption of the new lease standard, new DFS leases are classified as sales-type leases, direct financing leases, or operating leases.  Direct financing leases under the new lease standard are immaterial.  Leases that commenced prior to the adoption of the new lease standard were not reassessed or restated pursuant to the practical expedients elected and will continue to be accounted for under previous lease accounting guidance.

- added (2019-06-10):
[0001571996-19-000025:note_history:22]
When a contract includes lease and non-lease components, DFS allocates consideration under the contract to each component based on relative standalone selling price.  Whenever the terms of the lease transfer control to the lessee, the contract is typically classified as a sales-type lease.  Through these arrangements, the lessee has the right to substantially all of the economic benefits from use of the identified asset and has the right to direct the use of such asset during the period of use.  In many arrangements, the lessee also retains ownership at the end of the lease term.  On commencement of sales-type leases, the Company recognizes profit up-front, and amounts due from the customer under the lease contract are recognized as financing receivables on the Consolidated Statement of Financial Position.  Interest income is recognized over the term of the lease based on the effective interest method as Net revenue.  For sales and other taxes collected from the lessee, the Company has elected not to include such taxes as part of lease revenue.

- added (2019-06-10):
[0001571996-19-000025:note_history:23]
All other leases which do not meet the definition of a sales-type lease or direct financing lease are classified as operating leases.  The underlying asset in an operating lease arrangement is carried at depreciated cost as “Equipment under operating leases” within Property, plant, and equipment, net on the Consolidated Statement of Financial Position.  Depreciation is calculated using the straight-line method over the term of the underlying lease contract and is recognized as Cost of net revenue.  The depreciable basis is the original cost of the equipment less the estimated residual value of the equipment at the end of the lease term.  The Company recognizes operating lease revenue on a straight-line basis over the lease term and expenses deferred initial direct costs on the same basis.  Impairment of equipment under operating leases is assessed on the same basis as other long-lived assets.

- added (2019-06-10):
[0001571996-19-000025:note_history:24]
DFS provides lessees with the option to extend the lease or purchase the underlying asset at the end of the lease term, which is considered when evaluating lease classification.  In general, DFS’s lease arrangements do not have variable payment terms and are non-cancelable.

- added (2019-06-10):
[0001571996-19-000025:note_history:25]
See Note 4 of the Notes to the Condensed Consolidated Financial Statements for more information regarding DFS leasing arrangements.

- added (2019-06-10):
[0001571996-19-000025:note_history:26]
Financing Receivables — Financing receivables are presented net of allowance for losses and consist of customer receivables and residual interest.  Customer receivables, gross includes amounts due from customers under revolving loans, fixed-term loans, fixed-term sales-type or direct financing leases, and accrued interest.  The Company has two portfolios: (1) fixed-term leases and loans and (2) revolving loans, and assesses risk at the portfolio level to determine the appropriate allowance levels.  The portfolio segments are further segregated into classes based on products, customer type, and credit risk evaluation: (1) Revolving - Dell Preferred Account (“DPA”); (2) Revolving - Dell Business Credit (“DBC”); and (3) Fixed-term - Consumer and Commercial.  Fixed-term leases and loans are offered to qualified small and medium-sized businesses, large commercial accounts, governmental organizations, and educational entities.  Additionally, fixed-term loans are also offered to certain individual consumer customers.  Revolving loans are offered under private label credit financing programs.  The DPA revolving loan programs are offered to individual consumer customers and the DBC revolving loan programs are offered to small and medium-sized business customers.

- added (2019-06-10):
[0001571996-19-000025:note_history:27]
The Company retains a residual interest in equipment leased under its fixed-term lease programs.  The amount of the residual interest is established at the inception of the lease based upon estimates of the value of the equipment at the end of the lease term using historical studies, industry data, and future value-at-risk demand valuation methods.  On a quarterly basis, the Company assesses the carrying amount of its recorded residual values for impairment.  Anticipated declines in specific future residual values that are considered to be other-than-temporary are recorded currently in earnings.  Generally, residual value risk on equipment under lease is not considered to be significant because of the existence of a secondary market with respect to the equipment.  The lease agreement also clearly defines applicable return conditions and remedies for non-compliance, to ensure that the leased equipment will be in good operating condition upon return.  Model changes and updates, as well as market strength and product acceptance, are monitored and adjustments are made to residual values in accordance with the significance of any such changes.  Remarketing sales staff works closely with customers and dealers to manage the sale of lease returns and the recovery of residual exposure.  As of May 3, 2019, the Company has not recorded significant residual value impairment.

- added (2019-06-10):
[0001571996-19-000025:note_history:28]
Asset Securitization — The Company transfers certain U.S. and European customer loan and lease payments and associated equipment to Special Purpose Entities (“SPEs”) that meet the definition of a Variable Interest Entity (“VIE”) and are consolidated into the Consolidated Financial Statements.  These SPEs are bankruptcy-remote legal entities with separate assets and liabilities.  The purpose of the SPEs is to facilitate the funding of customer lease and loan payments and associated equipment in the capital markets.  These SPEs have entered into financing arrangements with multi-seller conduits that, in turn, issue asset-backed debt securities in the capital markets.  The asset securitizations in the SPEs are accounted for as secured borrowings.  See Note 4 of the Notes to the Condensed Consolidated Financial Statements for additional information on the impact of the consolidation.

- removed (2019-06-10):
[0001571996-18-000044:note_history:29]
As mentioned previously in Note 1 of the Notes to the Condensed Consolidated Financial Statements, the Company adopted amended guidance on the recognition of revenue from contracts with customers during the three months ended May 4, 2018, using the full retrospective method.  The following accounting policies have been updated as part of the adoption of the new standard.

- removed (2019-06-10):
[0001571996-18-000044:note_history:30]
Revenue Recognition — The Company enters into a variety of agreements to provide a wide portfolio of products and services offerings to its customers.  These agreements have varying requirements depending on the goods and services being sold, the rights and obligations conveyed, and the legal jurisdiction of the arrangement.

- removed (2019-06-10):
[0001571996-18-000044:note_history:31]
Revenue is recognized either over time or at a point in time, depending on when the underlying goods or services are transferred to the customer, in an amount that reflects the consideration to which the Company expects to be entitled in exchange for delivering those goods or services.  The following five steps are applied to recognize revenue:

- removed (2019-06-10):
[0001571996-18-000044:note_history:32]
| (1) | Identify the contract with a customer. The term “contract” refers to the enforceable rights and obligations provided in an agreement between the Company and one or more other parties in exchange for payment. The Company evaluates facts and circumstances regarding sales transactions in order to identify contracts with its customers. An agreement must meet all of the following criteria to qualify as a contract eligible for revenue recognition under the model: (i) the contract must be approved by all parties; (ii) each party’s rights regarding the goods and services to be transferred to the customer can be identified; (iii) the payment terms for the goods and services can be identified; (iv) the customer has the ability and intent to pay and it is probable that the Company will collect substantially all of the consideration to which it will be entitled; and (v) the contract must have commercial substance. Judgment is used in determining the customer’s ability and intent to pay, which is based upon various factors including the customer’s historical payment experience or customer credit and financial information. |

- removed (2019-06-10):
[0001571996-18-000044:note_history:33]
| (2) | Identify the performance obligations in the contract. Distinct promises within a contract are referred to as “performance obligations” and are accounted for as separate units of account. The Company assesses whether each promised good or service is distinct for the purpose of identifying the performance obligations in the contract. This assessment involves subjective determinations and requires management to make judgments about the individual promised goods or services and whether such goods or services are separable from the other aspects of the contractual relationship. Promised goods and services are considered distinct provided that: (i) the customer can benefit from the good or service either on its own or together with other resources that are readily available to the customer (that is, the good or service is capable of being distinct); and (ii) the Company’s promise to transfer the good or service to the customer is separately identifiable from other promises in the contract (that is, the promise to transfer the good or service is distinct within the context of the contract). The Company’s performance obligations consist of a variety of products and services offerings which include: hardware, such as servers, storage, networking, personal computers, workstations, and peripherals; third-party software; proprietary software licenses; support and deployment services, which include hardware support that extends beyond the Company’s standard warranties, software maintenance, and installation; professional services; training; software as a service (“SaaS”); and infrastructure as a service (“IaaS”). |

- removed (2019-06-10):
[0001571996-18-000044:note_history:34]
| (3) | Determine the transaction price. Transaction price reflects the amount of consideration to which the Company expects to be entitled in exchange for transferring goods or services to the customer. If the consideration promised in a contract includes a variable amount, the Company estimates the amount to which it expects to be entitled using either the expected value or most likely amount method. The Company’s contracts may include terms that could cause variability in the transaction price, including, for example, rebates, sales returns, and volume discounts. In determining the transaction price, any variable consideration would be considered, to the extent applicable, if it is probable that a significant future reversal of cumulative revenue under the contract will not occur when the uncertainty associated with the variable consideration is resolved. |

- removed (2019-06-10):
[0001571996-18-000044:note_history:35]
| (4) | Allocate the transaction price to performance obligations in the contract. Many of the Company’s contracts include promises to transfer multiple products and services to a customer, and the transaction price must be allocated to each performance obligation in an amount that depicts the consideration to which the Company expects to be entitled in exchange for transferring the promised goods or services. For these contracts with multiple performance obligations, the transaction price is allocated in proportion to the standalone selling price (“SSP”) of each performance obligation. |

- removed (2019-06-10):
[0001571996-18-000044:note_history:36]
If the contract contains a single performance obligation, the entire transaction price is allocated to that performance obligation.

- removed (2019-06-10):
[0001571996-18-000044:note_history:37]
The best evidence of SSP is the observable price of a good or service when the Company sells that good or service separately in similar circumstances to similar customers.  If a directly observable price is available, it must be utilized for the SSP.  If a directly observable price is not available, the SSP must be estimated.  The Company estimates SSP by considering multiple factors including, but not limited to, pricing practices, internal costs, and profit objectives as well as overall market conditions which include geographic or regional specific factors, competitive positioning, and competitor actions.  SSP can include fixed and variable components.  Variable components are estimated based on the most likely outcome or expected value of the variable components.

- removed (2019-06-10):
[0001571996-18-000044:note_history:38]
| (5) | Recognize revenue when (or as) the performance obligation is satisfied. Revenue is recognized when obligations under the terms of the contract with the Company’s customer are satisfied. Revenue is recognized either over time or at a point in time, depending on when the underlying products or services are transferred to the customer. Revenue is recognized at a point in time for products upon transfer of control. Revenue is recognized over time for support and deployment services, professional services, training, software support, SaaS, and IaaS. |

- removed (2019-06-10):
[0001571996-18-000044:note_history:39]
The Company reports revenue net of any revenue-based taxes assessed by governmental authorities that are imposed on and concurrently with specific revenue-producing transactions.

- removed (2019-06-10):
[0001571996-18-000044:note_history:40]
The Company has elected the following practical expedients with the adoption of the new revenue standard:

- removed (2019-06-10):
[0001571996-18-000044:note_history:41]
| • | The Company does not account for significant financing components if the period between revenue recognition and when the customer pays for the product or service will be one year or less. |

- removed (2019-06-10):
[0001571996-18-000044:note_history:42]
| • | The Company recognizes revenue equal to the amount it has a right to invoice when the amount corresponds directly with the value to the customer of the Company’s performance to date. |

- removed (2019-06-10):
[0001571996-18-000044:note_history:43]
| • | The Company does not account for shipping and handling activities as a separate performance obligation, but rather as an activity performed to transfer the promised good. |

- removed (2019-06-10):
[0001571996-18-000044:note_history:44]
The following summarizes the nature of revenue recognized and the manner in which the Company accounts for sales transactions.

- removed (2019-06-10):
[0001571996-18-000044:note_history:45]
Products

- removed (2019-06-10):
[0001571996-18-000044:note_history:46]
Product revenue consists of hardware and software license sales that are delivered, sold as a subscription or sold on a consumption basis.  Hardware includes notebooks and desktop PCs, servers, storage hardware, and other hardware-related devices.  Software license sales include non-essential, stand-alone software applications.  Software applications provide customers with resource management, backup and archiving, information security, information management and intelligence, data analytics, and server virtualization capabilities.

- removed (2019-06-10):
[0001571996-18-000044:note_history:47]
Revenue from the sale of hardware products is recognized when control has transferred to the customer, which typically occurs when the hardware has been shipped to the customer, risk of loss has transferred to the customer, the Company has a present right to payment, and customer acceptance has been satisfied.  Customer acceptance is satisfied if acceptance is obtained from the customer, if all acceptance provisions lapse, or if the Company has evidence that all acceptance provisions will be, or have been, satisfied.  Revenue from software license sales is generally recognized when control has transferred to the customer, which is typically upon shipment, electronic delivery, or when the software is available for download by the customer.  For certain arrangements, including software subscriptions and certain software license agreements which provide customers control to certain product performance obligations over time, revenue is recognized based on usage or ratably over the term of the arrangement based on the pattern of delivery of the product to the customer.

- removed (2019-06-10):
[0001571996-18-000044:note_history:48]
Invoices for products are generally issued as control transfers, which is typically upon shipment or electronic delivery.  There was no significant revenue in any period presented related to performance obligations satisfied or partially satisfied in prior periods.

- removed (2019-06-10):
[0001571996-18-000044:note_history:49]
Services

- removed (2019-06-10):
[0001571996-18-000044:note_history:50]
Services revenue consists of revenue from sales of support services, including hardware support that extends beyond the Company’s standard warranties, software maintenance, and installation; professional services; training; SaaS; and IaaS.  Revenue associated with undelivered performance obligations is deferred and recorded as control is transferred to the customer over time.  Revenue from fixed-price support or maintenance contracts sold for both hardware and software is recognized on a straight-line basis over the period of performance because the Company is required to provide services at any given time.  Other services revenue is recognized when the Company performs the services and the customers receive and consume the benefits.

- removed (2019-06-10):
[0001571996-18-000044:note_history:51]
Invoices for services may be issued at the start of a service term, which is typically the case for support and deployment services, or as services are rendered, which is typically the case for professional services, training, SaaS, and IaaS.

- removed (2019-06-10):
[0001571996-18-000044:note_history:52]
Other

- removed (2019-06-10):
[0001571996-18-000044:note_history:53]
Revenue from leasing arrangements is not subject to the revenue standard for contracts with customers, and remains separately accounted for under existing lease accounting guidance.  The Company records revenue from the sale of equipment under sales-type leases as product revenue in an amount equal to the present value of minimum lease payments at the inception of the lease.  Sales-type leases also produce financing income, which is included in products net revenue in the Consolidated Statements of Income (Loss) and is recognized at consistent rates of return over the lease term.  The Company also offers qualified customers fixed-term loans and revolving credit lines for the purchase of products and services offered by the Company.  Financing income attributable to these loans is recognized in products net revenue on an accrual basis.

- removed (2019-06-10):
[0001571996-18-000044:note_history:54]
Disaggregation of Revenue — The Company’s revenue is presented on a disaggregated basis on the Condensed Consolidated Statements of Income (Loss) and in Note 18 of the Notes to the Condensed Consolidated Financial Statements based on an evaluation of disclosures outside of the financial statements, information regularly reviewed by the chief operating decision maker for evaluating the financial performance of operating segments, and other information that is used to evaluate the Company’s financial performance or make resource allocations.  This information includes revenue from products and services, revenue from reportable segments, and revenue by major product categories within the segments.

- removed (2019-06-10):
[0001571996-18-000044:note_history:55]
Contract Assets — Contract assets are rights to consideration in exchange for goods or services that the Company has transferred to a customer when such a right is conditional on something other than the passage of time.  Such amounts have been insignificant to date.

- removed (2019-06-10):
[0001571996-18-000044:note_history:56]
Contract Liabilities — Contract liabilities primarily consist of deferred revenue.  Deferred revenue is recorded when the Company has a right to invoice or payments have been received for undelivered products or services, or in situations where revenue recognition criteria have not been met.  Deferred revenue also represents amounts received in advance for extended warranty services and software maintenance.  Revenue is recognized on these items when the revenue recognition criteria are met, generally resulting in ratable recognition over the contract term.  The Company also has deferred revenue related to undelivered hardware and professional services, consisting of installations and consulting engagements, which are recognized as the Company’s performance obligations under the contract are completed.  See Note 9 of the Notes to the Condensed Consolidated Financial Statements for additional information about deferred revenue.

- removed (2019-06-10):
[0001571996-18-000044:note_history:57]
Costs to Obtain a Contract — The incremental direct costs of obtaining a contract primarily consist of sales commissions and employer taxes related to commission payments.  The Company has elected, as a practical expedient, to expense as incurred costs to obtain a contract equal to or less than one year in duration.  For contracts greater than one year in duration, the associated costs to obtain a contract are deferred and amortized over the period of contract performance or a longer period, generally the estimated life of the customer relationship, if renewals are expected and the renewal commission is not commensurate with the initial commission.  Deferred costs to obtain a contract are typically amortized over a period of three to seven years, depending on the contract term and expectation of the period of benefit for the costs, which may exceed the contract term.  Amortization expense is recognized on a straight-line basis and included in selling, general, and administrative expenses in the Condensed Consolidated Statements of Income (Loss).

- removed (2019-06-10):
[0001571996-18-000044:note_history:58]
The Company periodically reviews these deferred costs to determine whether events or changes in circumstances have occurred that could impact the carrying value or period of benefit of the deferred sales commissions.  There were no material impairment losses for deferred sales commissions during the nine months ended November 2, 2018 and November 3, 2017.

- removed (2019-06-10):
[0001571996-18-000044:note_history:59]
Deferred costs to obtain a contract as of November 2, 2018 and February 2, 2018 were $1.1 billion and $0.8 billion, respectively.  Deferred costs to obtain a contract are classified as current assets and other non-current assets on the Condensed Consolidated Statements of Financial Position, based on when the expense is expected to be recognized.  Amortization of costs to obtain a contract during the three months ended November 2, 2018 and November 3, 2017 was $145 million and $89 million, respectively.  Amortization of costs to obtain a contract during the nine months ended November 2, 2018 and November 3, 2017 was $364 million and $204 million, respectively.


## us-gaap:BusinessDescriptionAndBasisOfPresentationTextBlock (critical_accounting_estimates) — matched_by: no_current_note, score: 0.0

- removed (2019-06-10):
[0001571996-18-000044:note_history:60]
NOTE 1 — BASIS OF PRESENTATION

- removed (2019-06-10):
[0001571996-18-000044:note_history:61]
References in these Notes to the Condensed Consolidated Financial Statements to the “Company” or “Dell Technologies” mean Dell Technologies Inc. individually and together with its consolidated subsidiaries.

- removed (2019-06-10):
[0001571996-18-000044:note_history:62]
Basis of Presentation — The accompanying unaudited Condensed Consolidated Financial Statements should be read in conjunction with the audited Consolidated Financial Statements and accompanying Notes included in the Company’s Annual Report on Form 10-K for the fiscal year ended February 2, 2018, and the recast audited Consolidated Financial Statements and accompanying Notes for the fiscal years ended February 2, 2018 and February 3, 2017 (the “Recast Financial Statements”)

- removed (2019-06-10):
[0001571996-18-000044:note_history:63]
and other financial information included in the Company’s Current Report on Form 8-K filed with the Securities and Exchange Commission (the “SEC”) on August 6, 2018.  The Recast Financial Statements were recast from and supersede the audited Consolidated Financial Statements for the fiscal years ended February 2, 2018 and February 3, 2017 included in the Company’s Annual Report on Form 10-K for the fiscal year ended February 2, 2018.  Such audited Consolidated Financial Statements were recast to present certain previously reported financial statements and other related financial information on a basis consistent with the new accounting standards adopted during the three months ended May 4, 2018.  Further, segment information was recast to conform with certain segment reporting changes the Company made during the three months ended May 4, 2018.  See below for additional information regarding recently adopted accounting pronouncements.

- removed (2019-06-10):
[0001571996-18-000044:note_history:64]
These Condensed Consolidated Financial Statements have been prepared in accordance with accounting principles generally accepted in the United States of America (“GAAP”).  In the opinion of management, the accompanying Condensed  Consolidated Financial Statements reflect all adjustments of a normal recurring nature considered necessary to fairly state the financial position of Dell Technologies Inc. as of November 2, 2018, the results of its operations and corresponding comprehensive income (loss) for the three and nine months ended November 2, 2018 and November 3, 2017, and its cash flows for the nine months ended November 2, 2018 and November 3, 2017.  The February 2, 2018 condensed consolidated balance sheet included herein was derived from the Recast Financial Statements.

- removed (2019-06-10):
[0001571996-18-000044:note_history:65]
The preparation of financial statements in accordance with GAAP requires management to make estimates and assumptions that affect the amounts reported in the Condensed Consolidated Financial Statements and the accompanying Notes.  Actual results could differ materially from those estimates.  The results of operations and comprehensive income (loss) for the three and nine months ended November 2, 2018 and November 3, 2017 and the cash flows for the nine months ended November 2, 2018 and November 3, 2017 are not necessarily indicative of the results to be expected for the full fiscal year or for any other fiscal period.

- removed (2019-06-10):
[0001571996-18-000044:note_history:66]
The Company’s fiscal year is the 52- or 53-week period ending on the Friday nearest January 31.  The fiscal year ended February 2, 2018 was a 52-week period, and the fiscal year ending February 1, 2019 will be a 52-week period.

- removed (2019-06-10):
[0001571996-18-000044:note_history:67]
Principles of Consolidation — These Condensed Consolidated Financial Statements include the accounts of Dell Technologies and its wholly-owned subsidiaries, as well as the accounts of VMware, Inc., Pivotal Software, Inc. (“Pivotal”), and SecureWorks Corp. (“SecureWorks”), each of which is majority-owned by Dell Technologies.  All intercompany transactions have been eliminated.

- removed (2019-06-10):
[0001571996-18-000044:note_history:68]
Unless the context indicates otherwise, references in these Notes to the Condensed Consolidated Financial Statements to “VMware” mean the VMware reportable segment, which reflects the operations of VMware, Inc. (NYSE: VMW) within Dell Technologies.  See Exhibit 99.1 filed with the quarterly report on Form 10-Q for the quarterly period ended November 2, 2018 for information on the differences between VMware reportable segment results and VMware, Inc. results.

- removed (2019-06-10):
[0001571996-18-000044:note_history:69]
EMC Merger Transaction — On September 7, 2016, the Company completed its acquisition by merger of EMC Corporation (“EMC”), referred to as the EMC merger transaction.  The consolidated results of EMC are included in Dell Technologies’ consolidated results presented in these financial statements.

- removed (2019-06-10):
[0001571996-18-000044:note_history:70]
Pivotal Initial Public Offering — On April 24, 2018, Pivotal completed a registered underwritten initial public offering (“IPO”) of its Class A common stock (NYSE: PVTL).  The results of Pivotal’s operations are included in other businesses.  For more information regarding the Company’s ownership of Pivotal, see Note 14 of the Notes to the Condensed Consolidated Financial Statements.

- removed (2019-06-10):
[0001571996-18-000044:note_history:71]
Recently Issued Accounting Pronouncements

- removed (2019-06-10):
[0001571996-18-000044:note_history:72]
Leases — In February 2016, the Financial Accounting Standards Board (“FASB”) issued amended guidance on the accounting for leasing transactions.  The primary objective of this update is to increase transparency and comparability among organizations by requiring lessees to recognize a lease liability for the obligation to make lease payments and a right-of-use asset for the right to use the underlying asset for the lease term.  The guidance also makes some changes to lessor accounting and requires additional disclosures about all leasing arrangements.  Companies are required to use a modified retrospective approach, with the option of applying the requirements of the standard either (1) retrospectively to each prior comparative reporting period presented, or (2) retrospectively at the beginning of the period of adoption.  The Company will adopt this standard for the fiscal year beginning February 2, 2019, and will apply it at the beginning of the period of adoption through a cumulative-effect adjustment to retained earnings.  In the area of lessee accounting, the Company anticipates that the most significant change will be recognition of right-of-use assets and lease liabilities on the Consolidated Statements of Financial Position.  In the area of lessor accounting, the Company anticipates that the most significant change will be an increase to future originations of operating leases due to elimination of the third-party residual value guarantee insurance in the sales-type lease test.

- removed (2019-06-10):
[0001571996-18-000044:note_history:73]
Measurement of Credit Losses on Financial Instruments — In June 2016, the FASB issued amended guidance which replaces the current incurred loss impairment methodology for measurement of credit losses on financial instruments with a methodology that reflects expected credit losses and requires consideration of a broader range of reasonable and supportable information to inform credit loss estimates.  Public entities must adopt the new guidance for fiscal years beginning after December 15, 2019, and interim periods within those fiscal years, with early adoption permitted for fiscal periods beginning after December 15, 2018.  The Company is currently evaluating the impact that the standard will have on the Consolidated Financial Statements.

- removed (2019-06-10):
[0001571996-18-000044:note_history:74]
Recently Adopted Accounting Pronouncements

- removed (2019-06-10):
[0001571996-18-000044:note_history:75]
Revenue from Contracts with Customers — In May 2014, the FASB issued amended guidance on the recognition of revenue from contracts with customers.  The objective of the new standard is to establish a single comprehensive model for entities to use in accounting for revenue arising from contracts with customers and will supersede substantially all of the existing revenue recognition guidance, including industry-specific guidance.  The new standard requires entities to recognize revenue when it transfers promised goods or services to customers in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services.  Further, the new standard requires additional disclosures to help enable users of the financial statements to better understand the nature, amount, timing, risks, and judgments related to revenue recognition and related cash flows from contracts with customers.  Concurrently, the FASB issued guidance on the accounting for costs to fulfill or obtain a customer contract.  The Company adopted these standards during the three months ended May 4, 2018 using the full retrospective method, which requires the Company to recast each prior period presented consistent with the new guidance.  The Company recorded a credit of approximately $1 billion to retained earnings as of January 29, 2016 to reflect the cumulative effect of the adoption.  See tables provided below which present the impact of the new accounting standards to the Company’s previously reported financial results.  See also Note 2 of the Notes to the Condensed Consolidated Financial Statements for a summary of significant policies related to the new accounting standards.

- removed (2019-06-10):
[0001571996-18-000044:note_history:76]
Recognition and Measurement of Financial Assets and Financial Liabilities — In January 2016, the FASB issued amended guidance that generally requires changes in the fair value of equity investments, other than those accounted for under the equity method, to be recognized through net income, rather than other comprehensive income.  For equity investments without readily determinable fair values, the Company is no longer permitted to use the cost method of accounting.  The Company has elected to apply the measurement alternative for those investments.  Under the alternative, the Company measures investments without readily determinable fair values at cost, less impairment, adjusted by observable price changes on a prospective basis.  The Company must make a separate election to use the alternative for each eligible investment, and is required to reassess at each reporting period whether an investment qualifies for the alternative.  The Company adopted this standard during the three months ended May 4, 2018.  Adoption of the standard was applied through a cumulative one-time adjustment to accumulated deficit of $56 million for the accumulated unrealized gain previously recorded in other comprehensive income.  The impact of the standard on the Condensed Consolidated Statements of Income (Loss) during the three and nine months ended November 2, 2018 was a loss of $14 million and a gain of $209 million, respectively, recognized in interest and other, net, and the impact in future periods will depend on the relative changes in market price of the equity investments.

- removed (2019-06-10):
[0001571996-18-000044:note_history:77]
Classification of Certain Cash Receipts and Cash Payments — In August 2016, the FASB issued amended guidance on the presentation and classification of eight specific cash flow issues with the objective of reducing existing diversity in practice.  Companies should reflect any adjustments on a retrospective basis, if practicable; otherwise, adoption is required to be applied as of the earliest date practicable.  The Company adopted this standard during the three months ended May 4, 2018.  Prior period amounts on the Condensed Consolidated Statements of Cash Flows have been recast to conform with current period presentation as shown in the reconciliation provided below.

- removed (2019-06-10):
[0001571996-18-000044:note_history:78]
Intra-Entity Transfers of Assets Other Than Inventory — In October 2016, the FASB issued amended guidance on the accounting for income taxes.  The new guidance requires companies to recognize the income tax effects of intra-entity asset transfers, other than transfers of inventory, when the transfer occurs instead of when the asset is sold to a third party.  The new guidance was applied on a modified-retrospective basis with the cumulative-effect adjustment to accumulated deficit as of the beginning of the period of adoption.  The Company early adopted this guidance during the three months ended May 5, 2017.  At adoption, approximately $84 million was reclassified from other non-current liabilities to accumulated deficit, resulting in a net credit to accumulated deficit.

- removed (2019-06-10):
[0001571996-18-000044:note_history:79]
Statement of Cash Flows, Restricted Cash — In November 2016, the FASB issued amended guidance requiring entities to include restricted cash and restricted cash equivalents in cash balances on the cash flow statement, and also to provide a supplemental reconciliation of cash, cash equivalents and restricted cash.  Public entities must adopt the new guidance for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2017, with early adoption permitted.  The Company adopted this standard during the three months ended May 4, 2018.  See Note 19 of the Notes to the Condensed Consolidated Financial Statements for supplemental cash flow information.  Prior period amounts on the Condensed Consolidated Statements of Cash Flows have been recast to conform with current period presentation as shown in the reconciliation provided below.

- removed (2019-06-10):
[0001571996-18-000044:note_history:80]
Clarifying the Definition of a Business — In January 2017, the FASB issued amended guidance to clarify the definition of a business with the objective of adding guidance to assist entities with evaluating whether transactions should be accounted for as acquisitions (or disposals) of assets or businesses.  Public entities must adopt the new guidance for fiscal years beginning after December 15, 2017, and interim periods within those fiscal years.  The new guidance did not have a material impact on the Company’s conclusions regarding transactions that were assessed in the current period.

- removed (2019-06-10):
[0001571996-18-000044:note_history:81]
Simplifying the Test for Goodwill Impairment — In January 2017, the FASB issued amended guidance to simplify the subsequent measurement of goodwill by removing Step 2 of the goodwill impairment test.  Instead, under the amendments in the new guidance, an entity should perform its annual, or interim, goodwill impairment test by comparing the fair value of a reporting unit with its carrying amount.  An entity should recognize an impairment charge for the amount by which the carrying amount exceeds the reporting unit’s fair value.  Public entities must adopt the new guidance in fiscal years beginning after December 15, 2019, with early adoption permitted.  In conjunction with its annual goodwill and indefinite-lived intangible assets impairment testing which occurs during the third fiscal quarter of each year, the Company elected to early adopt this guidance during the three months ended November 2, 2018.  No interim goodwill impairment tests were required during both the three months ended May 4, 2018 and August 3, 2018.  See Note 8 of the Notes to the Condensed Consolidated Financial Statements for additional information about goodwill impairment testing.

- removed (2019-06-10):
[0001571996-18-000044:note_history:82]
Derivatives and Hedging — In August 2017, the FASB issued amended guidance that will make more financial and non-financial hedging strategies eligible for hedge accounting.  The amended guidance changes how companies assess effectiveness, and also amends the presentation and disclosure requirements.  The guidance is intended to simplify the application of hedge accounting and increase transparency as to the scope and results of hedging programs.  Immediate early adoption is permitted in any interim or annual period.  The Company elected to early adopt this standard during the three months ended May 4, 2018.  The impact of the adoption of the standard was immaterial to the Condensed Consolidated Financial Statements.

- removed (2019-06-10):
[0001571996-18-000044:note_history:83]
Income Statement - Reporting Comprehensive Income — In February 2018, the FASB issued guidance that will permit entities to reclassify the tax effects stranded in accumulated other comprehensive income to accumulated deficit as a result of U.S. Tax Reform, discussed in Note 12 of the Notes to the Condensed Consolidated Financial Statements.  The guidance gives entities the option to reclassify these amounts, but requires new disclosures regardless of whether they elect to do so.  The guidance is effective for fiscal years beginning after December 15, 2018, and interim periods within those fiscal years.  Early adoption is permitted.  The Company elected to early adopt this standard during the three months ended May 4, 2018, and recorded the impact of the adoption as a cumulative adjustment to accumulated deficit.  The impact of the adoption was immaterial to the Condensed Consolidated Financial Statements.

- removed (2019-06-10):
[0001571996-18-000044:note_history:84]
Impacts to Previously Reported Periods

- removed (2019-06-10):
[0001571996-18-000044:note_history:85]
The following tables present the impact of the new accounting standards to the Company’s previously reported financial results.

- removed (2019-06-10):
[0001571996-18-000044:note_history:86]
Selected Captions from the Condensed Consolidated Statement of Financial Position

- removed (2019-06-10):
[0001571996-18-000044:note_history:87]
|  | February 2, 2018 |
|  | As Reported (a) |  | Revenue from Contracts with Customers |  | As Recast |
|  | (in millions) |
| Assets |  |  |  |  |  |
| Accounts receivable, net | $ | 11,177 |  |  | $ | 544 |  |  | $ | 11,721 |  |
| Other current assets | $ | 5,054 |  |  | $ | 827 |  |  | $ | 5,881 |  |
| Other non-current assets | $ | 1,862 |  |  | $ | 541 |  |  | $ | 2,403 |  |
| Liabilities and Stockholders' Equity |  |  |  |  |  |
| Accrued and other | $ | 7,661 |  |  | $ | 365 |  |  | $ | 8,026 |  |
| Short-term deferred revenue | $ | 12,024 |  |  | $ | (418 | ) |  | $ | 11,606 |  |
| Long-term deferred revenue | $ | 10,223 |  |  | $ | (1,013 | ) |  | $ | 9,210 |  |
| Other non-current liabilities | $ | 6,797 |  |  | $ | 480 |  |  | $ | 7,277 |  |
| Accumulated deficit | $ | (9,253 | ) |  | $ | 2,393 |  |  | $ | (6,860 | ) |
| Non-controlling interests | $ | 5,661 |  |  | $ | 105 |  |  | $ | 5,766 |  |

- removed (2019-06-10):
[0001571996-18-000044:note_history:88]
____________________

- removed (2019-06-10):
[0001571996-18-000044:note_history:89]
| (a) | Amounts as reported in the Company’s Annual Report on Form 10-K for the fiscal year ended February 2, 2018. |

- removed (2019-06-10):
[0001571996-18-000044:note_history:90]
The above impacts are summarized as follows:

- removed (2019-06-10):
[0001571996-18-000044:note_history:91]
Accounts receivable, net.  The adoption of the new revenue standard resulted in an increase to accounts receivable, net primarily due to the following two factors:

- removed (2019-06-10):
[0001571996-18-000044:note_history:92]
| • | First, the return rights provision, which represents an estimate of expected customer returns, which was previously presented as a reduction of accounts receivable, net, is now being presented outside of accounts receivable, net in two separate balance sheet line items. A liability is recorded in accrued and other for the estimated value of the sales amounts to be returned to the customer, and an asset is recorded in other current assets representing the recoverable cost of the inventory estimated to be returned. |

- removed (2019-06-10):
[0001571996-18-000044:note_history:93]
| • | Second, the standard provides new guidance regarding transfer of control of goods to the customer. Under these new guidelines, the Company has determined that for certain hardware contracts in the United States, transfer of control and recognition of revenue can occur earlier. This resulted in an increase in accounts receivable, net and a decrease in the in-transit deferral recorded in other current assets. |

- removed (2019-06-10):
[0001571996-18-000044:note_history:94]
Other assets.  The adoption of the new revenue standard resulted in an increase in other assets due to capitalization of the costs to obtain a contract, as well as the accounts receivable, net of impacts discussed above.

- removed (2019-06-10):
[0001571996-18-000044:note_history:95]
Deferred revenue.  The adoption of the new revenue standard resulted in a decline in deferred revenue due to earlier recognition of revenue for software licenses, and less of the aggregate transaction price being allocated to extended warranty.  Deferred revenue was also reduced by the impact of variable consideration (i.e., price concessions, rebates, and refunds).  The reduction in deferred revenue was partially offset by an increase resulting from the change in presentation of deferred costs on third-party software offerings, which are reported in other assets, and are either sold on a standalone basis or as an attached component of the Company’s hardware offering.  The Company previously reported the associated deferred revenue net of these deferred costs in deferred revenue.

- removed (2019-06-10):
[0001571996-18-000044:note_history:96]
Condensed Consolidated Statements of Income (Loss)

- removed (2019-06-10):
[0001571996-18-000044:note_history:97]
|  | Three Months Ended |  | Nine Months Ended |
|  | November 3, 2017 |  | November 3, 2017 |
|  | As Reported (a) |  | Revenue from Contracts with Customers |  | As Recast |  | As Reported (a) |  | Revenue from Contracts with Customers |  | As Recast |
|  | (in millions, except per share amounts) |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Products | $ | 14,680 |  |  | $ | 440 |  |  | $ | 15,120 |  |  | $ | 42,003 |  |  | $ | 1,853 |  |  | $ | 43,856 |  |
| Services | 4,930 |  |  | (494 | ) |  | 4,436 |  |  | 14,722 |  |  | (1,501 | ) |  | 13,221 |  |
| Total net revenue | 19,610 |  |  | (54 | ) |  | 19,556 |  |  | 56,725 |  |  | 352 |  |  | 57,077 |  |
| Cost of net revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Products | 12,369 |  |  | 204 |  |  | 12,573 |  |  | 36,206 |  |  | 965 |  |  | 37,171 |  |
| Services | 2,078 |  |  | (315 | ) |  | 1,763 |  |  | 6,245 |  |  | (984 | ) |  | 5,261 |  |
| Total cost of net revenue | 14,447 |  |  | (111 | ) |  | 14,336 |  |  | 42,451 |  |  | (19 | ) |  | 42,432 |  |
| Gross margin | 5,163 |  |  | 57 |  |  | 5,220 |  |  | 14,274 |  |  | 371 |  |  | 14,645 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |
| Selling, general, and administrative | 4,625 |  |  | (66 | ) |  | 4,559 |  |  | 13,989 |  |  | (294 | ) |  | 13,695 |  |
| Research and development | 1,071 |  |  | — |  |  | 1,071 |  |  | 3,297 |  |  | — |  |  | 3,297 |  |
| Total operating expenses | 5,696 |  |  | (66 | ) |  | 5,630 |  |  | 17,286 |  |  | (294 | ) |  | 16,992 |  |
| Operating loss | (533 | ) |  | 123 |  |  | (410 | ) |  | (3,012 | ) |  | 665 |  |  | (2,347 | ) |
| Interest and other, net | (682 | ) |  | — |  |  | (682 | ) |  | (1,800 | ) |  | 1 |  |  | (1,799 | ) |
| Income (loss) before income taxes | (1,215 | ) |  | 123 |  |  | (1,092 | ) |  | (4,812 | ) |  | 666 |  |  | (4,146 | ) |
| Income tax provision (benefit) | (274 | ) |  | 33 |  |  | (241 | ) |  | (1,510 | ) |  | 157 |  |  | (1,353 | ) |
| Net income (loss) | (941 | ) |  | 90 |  |  | (851 | ) |  | (3,302 | ) |  | 509 |  |  | (2,793 | ) |
| Less: Net loss attributable to non-controlling interests | (4 | ) |  | (1 | ) |  | (5 | ) |  | (85 | ) |  | 41 |  |  | (44 | ) |
| Net income (loss) attributable to Dell Technologies Inc. | $ | (937 | ) |  | $ | 91 |  |  | $ | (846 | ) |  | $ | (3,217 | ) |  | $ | 468 |  |  | $ | (2,749 | ) |
| Earnings (loss) per share attributable to Dell Technologies Inc. - basic: |  |  |  |  |  |  |
| Class V Common Stock - basic | $ | 1.10 |  |  | $ | (0.12 | ) |  | $ | 0.98 |  |  | $ | 2.50 |  |  | $ | 0.08 |  |  | $ | 2.58 |  |
| DHI Group - basic | $ | (2.05 | ) |  | $ | 0.21 |  |  | $ | (1.84 | ) |  | $ | (6.57 | ) |  | $ | 0.79 |  |  | $ | (5.78 | ) |
| Earnings (loss) per share attributable to Dell Technologies Inc. - diluted: |  |  |  |  |  |  |
| Class V Common Stock - diluted | $ | 1.09 |  |  | $ | (0.13 | ) |  | $ | 0.96 |  |  | $ | 2.46 |  |  | $ | 0.08 |  |  | $ | 2.54 |  |
| DHI Group - diluted | $ | (2.05 | ) |  | $ | 0.21 |  |  | $ | (1.84 | ) |  | $ | (6.58 | ) |  | $ | 0.79 |  |  | $ | (5.79 | ) |

- removed (2019-06-10):
[0001571996-18-000044:note_history:98]
____________________

- removed (2019-06-10):
[0001571996-18-000044:note_history:99]
| (a) | Amounts as reported in the Company’s Quarterly Report on Form 10-Q for the quarterly period ended November 3, 2017. |

- removed (2019-06-10):
[0001571996-18-000044:note_history:100]
The above impacts are summarized as follows:

- removed (2019-06-10):
[0001571996-18-000044:note_history:101]
Net revenue.  The adoption of the new revenue standard resulted in an increase to net revenue due to earlier revenue recognition than permitted under the previous standard.

- removed (2019-06-10):
[0001571996-18-000044:note_history:102]
Products revenue vs. services revenue.  The adoption of the new revenue standard resulted in a change to the classification of products revenue vs. services revenue, due to the following factors:

- removed (2019-06-10):
[0001571996-18-000044:note_history:103]
| • | Under the new revenue standard, amounts within a contract are now allocated to the product and services performance obligations based on their respective standalone selling prices, which generally increases product revenue and decreases services revenue relative to previously reported results. |

- removed (2019-06-10):
[0001571996-18-000044:note_history:104]
| • | Further, third-party software licenses were previously recognized in services revenue as the Company could not separate the value of the software license from the associated maintenance agreement. Under the new revenue standard, the license value requires separation and will be recognized in product revenue and the value of the software maintenance will continue to be recognized in services revenue. |

- removed (2019-06-10):
[0001571996-18-000044:note_history:105]
Operating expenses.   The adoption of the new revenue standard resulted in a decrease to operating expenses due to the deferral of the incremental direct costs of obtaining a contract.

- removed (2019-06-10):
[0001571996-18-000044:note_history:106]
Selected Captions from the Condensed Consolidated Statement of Cash Flows

- removed (2019-06-10):
[0001571996-18-000044:note_history:107]
|  | Nine Months Ended |
|  | November 3, 2017 |
|  | As Reported (a) |  | Classification of Certain Cash Receipts and Cash Payments |  | Statement of Cash Flows, Restricted Cash |  | As Recast |
|  | (in millions) |
| Change in cash from operating activities | $ | 3,679 |  |  | $ | 48 |  |  | $ | 17 |  |  | $ | 3,744 |  |
| Change in cash from investing activities | $ | (1,990 | ) |  | $ | — |  |  | $ | — |  |  | $ | (1,990 | ) |
| Change in cash from financing activities | $ | 496 |  |  | $ | (48 | ) |  | $ | 77 |  |  | $ | 525 |  |
| Change in cash, cash equivalents, and restricted cash | $ | 2,232 |  |  | $ | — |  |  | $ | 94 |  |  | $ | 2,326 |  |
| Cash, cash equivalents, and restricted cash at beginning of the period | 9,474 |  |  | — |  |  | 358 |  |  | 9,832 |  |
| Cash, cash equivalents, and restricted cash at end of the period | $ | 11,706 |  |  | $ | — |  |  | $ | 452 |  |  | $ | 12,158 |  |

- removed (2019-06-10):
[0001571996-18-000044:note_history:108]
____________________

- removed (2019-06-10):
[0001571996-18-000044:note_history:109]
(a) 
Amounts as reported in the Company’s Quarterly Report on Form 10-Q for the quarterly period ended November 3, 2017.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-06-10):
[0001571996-19-000025:note_history:110]
The following table presents the Company’s outstanding debt as of the dates indicated:
  (was, 2018-12-10, similarity 0.931):
[0001571996-18-000044:note_history:110]
The following table summarizes the Company’s outstanding debt as of the dates indicated:

- changed (2019-06-10):
[0001571996-19-000025:note_history:111]
|  | May 3, 2019 |  | February 1, 2019 |
|  | (in millions) |
| Secured Debt |  |  |  |
| Senior Secured Credit Facilities: |  |  |  |
| 4.49% Term Loan B Facility due September 2023 | $ | 4,925 |  |  | $ | 4,938 |  |
| 4.24% Term Loan A-2 Facility due September 2021 | 727 |  |  | 4,116 |  |
| 4.24% Term Loan A-4 Facility due December 2023 | 1,629 |  |  | 1,650 |  |
| 4.25% Term Loan A-5 Facility due December 2019 | — |  |  | 2,016 |  |
| 4.23% Term Loan A-6 Facility due March 2024 | 3,634 |  |  | — |  |
| First Lien Notes: |  |  |  |
| 3.48% due June 2019 | — |  |  | 3,750 |  |
| 4.42% due June 2021 | 4,500 |  |  | 4,500 |  |
| 5.45% due June 2023 | 3,750 |  |  | 3,750 |  |
| 4.00% due July 2024 | 1,000 |  |  | — |  |
| 6.02% due June 2026 | 4,500 |  |  | 4,500 |  |
| 4.90% due October 2026 | 1,750 |  |  | — |  |
| 5.30% due October 2029 | 1,750 |  |  | — |  |
| 8.10% due July 2036 | 1,500 |  |  | 1,500 |  |
| 8.35% due July 2046 | 2,000 |  |  | 2,000 |  |
| Unsecured Debt |  |  |  |
| Unsecured Notes and Debentures: |  |  |  |
| 5.875% due June 2019 | 600 |  |  | 600 |  |
| 4.625% due April 2021 | 400 |  |  | 400 |  |
| 7.10% due April 2028 | 300 |  |  | 300 |  |
| 6.50% due April 2038 | 388 |  |  | 388 |  |
| 5.40% due September 2040 | 264 |  |  | 264 |  |
| Senior Notes: |  |  |  |
| 5.875% due June 2021 | 1,625 |  |  | 1,625 |  |
| 7.125% due June 2024 | 1,625 |  |  | 1,625 |  |
| EMC Notes: |  |  |  |
| 2.650% due June 2020 | 2,000 |  |  | 2,000 |  |
| 3.375% due June 2023 | 1,000 |  |  | 1,000 |  |
| VMware Notes: |  |  |  |
| 2.30% due August 2020 | 1,250 |  |  | 1,250 |  |
| 2.95% due August 2022 | 1,500 |  |  | 1,500 |  |
| 3.90% due August 2027 | 1,250 |  |  | 1,250 |  |
| DFS Debt (Note 4) | 6,343 |  |  | 5,929 |  |
| Other |  |  |  |
| 4.83% Margin Loan Facility due April 2022 | 4,000 |  |  | 3,350 |  |
| Other | 27 |  |  | 38 |  |
| Total debt, principal amount | $ | 54,237 |  |  | $ | 54,239 |  |
  (was, 2018-12-10, similarity 0.6046):
[0001571996-18-000044:note_history:111]
|  | November 2, 2018 |  | February 2, 2018 |
|  | (in millions) |
| Secured Debt |  |  |  |
| Senior Secured Credit Facilities: |  |  |  |
| 4.31% Term Loan B Facility due September 2023 | $ | 4,950 |  |  | $ | 4,988 |  |
| 4.06% Term Loan A-2 Facility due September 2021 | 4,228 |  |  | 4,394 |  |
| 3.81% Term Loan A-3 Facility due December 2018 | — |  |  | 1,213 |  |
| First Lien Notes: |  |  |  |
| 3.48% due June 2019 | 3,750 |  |  | 3,750 |  |
| 4.42% due June 2021 | 4,500 |  |  | 4,500 |  |
| 5.45% due June 2023 | 3,750 |  |  | 3,750 |  |
| 6.02% due June 2026 | 4,500 |  |  | 4,500 |  |
| 8.10% due July 2036 | 1,500 |  |  | 1,500 |  |
| 8.35% due July 2046 | 2,000 |  |  | 2,000 |  |
| Unsecured Debt |  |  |  |
| Unsecured Notes and Debentures: |  |  |  |
| 5.65% due April 2018 | — |  |  | 500 |  |
| 5.875% due June 2019 | 600 |  |  | 600 |  |
| 4.625% due April 2021 | 400 |  |  | 400 |  |
| 7.10% due April 2028 | 300 |  |  | 300 |  |
| 6.50% due April 2038 | 388 |  |  | 388 |  |
| 5.40% due September 2040 | 264 |  |  | 264 |  |
| Senior Notes: |  |  |  |
| 5.875% due June 2021 | 1,625 |  |  | 1,625 |  |
| 7.125% due June 2024 | 1,625 |  |  | 1,625 |  |
| EMC Notes: |  |  |  |
| 1.875% due June 2018 | — |  |  | 2,500 |  |
| 2.650% due June 2020 | 2,000 |  |  | 2,000 |  |
| 3.375% due June 2023 | 1,000 |  |  | 1,000 |  |
| VMware Notes: |  |  |  |
| 2.30% due August 2020 | 1,250 |  |  | 1,250 |  |
| 2.95% due August 2022 | 1,500 |  |  | 1,500 |  |
| 3.90% due August 2027 | 1,250 |  |  | 1,250 |  |
| DFS Debt (Note 5) | 5,937 |  |  | 4,796 |  |
| Other |  |  |  |
| 4.78% Margin Loan Facility due April 2022 | 2,000 |  |  | 2,000 |  |
| Other | 47 |  |  | 101 |  |
| Total debt, principal amount | $ | 49,364 |  |  | $ | 52,694 |  |

- changed (2019-06-10):
[0001571996-19-000025:note_history:112]
|  | May 3, 2019 |  | February 1, 2019 |
|  | (in millions) |
| Total debt, principal amount | $ | 54,237 |  |  | $ | 54,239 |  |
| Unamortized discount, net of unamortized premium | (268 | ) |  | (271 | ) |
| Debt issuance costs | (445 | ) |  | (447 | ) |
| Total debt, carrying value | $ | 53,524 |  |  | $ | 53,521 |  |
| Total short-term debt, carrying value | $ | 4,884 |  |  | $ | 4,320 |  |
| Total long-term debt, carrying value | $ | 48,640 |  |  | $ | 49,201 |  |
  (was, 2018-12-10, similarity 0.9864):
[0001571996-18-000044:note_history:112]
|  | November 2, 2018 |  | February 2, 2018 |
|  | (in millions) |
| Total debt, principal amount | $ | 49,364 |  |  | $ | 52,694 |  |
| Unamortized discount, net of unamortized premium | (238 | ) |  | (266 | ) |
| Debt issuance costs | (469 | ) |  | (557 | ) |
| Total debt, carrying value | $ | 48,657 |  |  | $ | 51,871 |  |
| Total short-term debt, carrying value | $ | 8,150 |  |  | $ | 7,873 |  |
| Total long-term debt, carrying value | $ | 40,507 |  |  | $ | 43,998 |  |

- added (2019-06-10):
[0001571996-19-000025:note_history:113]
On March 7, 2019, the Company amended the Margin Loan Agreement to increase the aggregate principal amount of borrowings under the Margin Loan Facility by $650 million.

- added (2019-06-10):
[0001571996-19-000025:note_history:114]
On March 13, 2019, the Company entered into an amendment to the credit agreement for the Senior Secured Credit Facilities to obtain a new senior secured Term Loan A-6 Facility in order to refinance the $5 billion aggregate principal amount of debt incurred in connection with the Class V transaction described in Note 14 of the Notes to the Condensed Consolidated Financial Statements.  The Term Loan A-6 Facility aggregate principal amount of $3,634 million matures on March 13, 2024, of which $2,839 million aggregate principal amount represents the amounts outstanding under the Term Loan A-2 Facility that rolled-over into the new facility.  Immediately after the rollover, an aggregate principal amount of $1,277 million remained outstanding under the Term Loan A-2 Facility.  The Term Loan A-6 Facility amortizes quarterly and bears interest at the London Interbank Offered Rate (“LIBOR”) plus an applicable margin ranging from 1.25% to 2.00% or a base rate plus an applicable margin of 0.25% to 1.00%.

- added (2019-06-10):
[0001571996-19-000025:note_history:115]
On March 20, 2019, Dell International L.L.C. and EMC Corporation, both which are wholly-owned subsidiaries of Dell Technologies Inc., completed a private offering of multiple series of First Lien Notes in an aggregate principal amount of $4.5 billion.  The principal amount, interest rate, and maturity of each series of such First Lien Notes were as follows:

- added (2019-06-10):
[0001571996-19-000025:note_history:116]
| • | $1,000 million 4.00% First Lien Notes due July 15, 2024 |

- added (2019-06-10):
[0001571996-19-000025:note_history:117]
| • | $1,750 million 4.90% First Lien Notes due October 1, 2026 |

- added (2019-06-10):
[0001571996-19-000025:note_history:118]
| • | $1,750 million 5.30% First Lien Notes due October 1, 2029 |

- added (2019-06-10):
[0001571996-19-000025:note_history:119]
A majority of the proceeds from the First Lien Notes issued on March 20, 2019 was used to repay all of the outstanding $3,750 million First Lien Notes due June 2019.  In addition, proceeds of approximately $800 million of borrowings under the new Term Loan A-6 Facility, the proceeds of the $650 million increase in the Margin Loan Facility, and a portion of the proceeds from the 2019 First Lien Notes were used to repay all of the Company’s outstanding amounts under the Term Loan A-5 Facility due December 2019.  The remaining proceeds available from the 2019 First Lien Notes were used to repay outstanding amounts under the Term Loan A-2 Facility and to pay related premiums, accrued interest, fees, and expenses.

- added (2019-06-10):
[0001571996-19-000025:note_history:120]
The refinancing and amendments were evaluated in accordance with FASB ASC 470, “Debt-Modifications and Extinguishments.”  The amendment to the Margin Loan Agreement and the term debt refinancing were accounted for as modifications for all existing lenders and as new issuances for new lenders.  The First Lien Notes issued on March 20, 2019, were accounted for as new issuances for all lenders, and repayment of the Company’s outstanding amounts under the Term Loan A-5 Facility was accounted for as an extinguishment.  During the three months ended May 3, 2019, the Company capitalized $74.5 million in new fees paid to creditors as a result of the modifications and new issuances.  In addition, the Company recognized expenses of $32.3 million in unamortized costs and $7.1 million in new third-party costs during the three months ended May 3, 2019.

- added (2019-06-10):
[0001571996-19-000025:note_history:121]
During the three months ended May 3, 2019, the Company also repaid $400 million of its Term Loan A-2 Facility and approximately $33 million of principal amortization under its term loan facilities.

- added (2019-06-10):
[0001571996-19-000025:note_history:122]
The Company issued an additional $0.4 billion, net, in DFS debt to support the expansion of its financing receivables portfolio during the three months ended May 3, 2019.

- changed (2019-06-10):
[0001571996-19-000025:note_history:123]
Senior Secured Credit Facilities — The Company has entered into a credit agreement that provides for senior secured credit facilities (the “Senior Secured Credit Facilities”) comprising (a) term loan facilities and (b) a senior secured Revolving Credit Facility, which includes capacity for up to $0.5 billion of letters of credit and for borrowings of up to $0.4 billion under swing-line loans.
  (was, 2018-12-10, similarity 0.6963):
[0001571996-18-000044:note_history:123]
Senior Secured Credit Facilities — The Company has entered into a credit agreement that provides for senior secured credit facilities (the “Senior Secured Credit Facilities”) in the aggregate principal amount of $17.6 billion comprising (a) term loan facilities and (b) a senior secured Revolving Credit Facility, which includes capacity for up to $0.5 billion of letters of credit and for borrowings of up to $0.4 billion under swing-line loans.  As of November 2, 2018, available borrowings under the Revolving Credit Facility totaled $3.3 billion.  The Senior Secured Credit Facilities provide that the borrowers have the right at any time, subject to customary conditions, to request incremental term loans or incremental revolving commitments.

- added (2019-06-10):
[0001571996-19-000025:note_history:124]
As of May 3, 2019, available borrowings under the Revolving Credit Facility totaled $4.5 billion.  The Senior Secured Credit Facilities provide that the borrowers have the right at any time, subject to customary conditions, to request incremental term loans or incremental revolving commitments.

- changed (2019-06-10):
[0001571996-19-000025:note_history:125]
Borrowings under the Senior Secured Credit Facilities bear interest at a rate per annum equal to an applicable margin, plus, at the borrowers’ option, either (a) a base rate, which, under the Term Loan B Facility, is subject to an interest rate floor of 1.75% per annum, and under all other borrowings is subject to an interest rate floor of 0% per annum, or (b) LIBOR, which, under the Term Loan B Facility, is subject to an interest rate floor of 0.75% per annum, and under all other borrowings is subject to an interest rate floor of 0% per annum.  Interest is payable, in the case of loans bearing interest based on LIBOR, at the end of each interest period (but at least every three months), in arrears and, in the case of loans bearing interest based on the base rate, quarterly in arrears.
  (was, 2018-12-10, similarity 0.9715):
[0001571996-18-000044:note_history:125]
Borrowings under the Senior Secured Credit Facilities bear interest at a rate per annum equal to an applicable margin, plus, at the borrowers’ option, either (a) a base rate, which, under the Term Loan B Facility, is subject to an interest rate floor of 1.75% per annum, and under all other borrowings is subject to an interest rate floor of 0% per annum, or (b) a London interbank offered rate (“LIBOR”), which, under the Term Loan B Facility, is subject to an interest rate floor of 0.75% per annum, and under all other borrowings is subject to an interest rate floor of 0% per annum.  Interest is payable, in the case of loans bearing interest based on LIBOR, at the end of each interest period (but at least every three months), in arrears and, in the case of loans bearing interest based on the base rate, quarterly in arrears.

- added (2019-06-10):
[0001571996-19-000025:note_history:126]
The Term Loan B Facility amortizes in equal quarterly installments in aggregate annual amounts equal to 1% of the original principal amount.  The Term Loan A-2 Facility amortizes in equal quarterly installments in aggregate annual amounts equal to 5% of the original principal amount in the first year after the closing date of the refinancing transaction on October 20, 2017, 10% of the original principal amount in each of the second and third years after October 20, 2017, and 75% of the original principal amount in the fourth year after October 20, 2017.  The Term Loan A-4 Facility amortizes in equal quarterly installments in aggregate annual amounts equal to 5% of the original principal amount in each of the first four years after the facility closing date of December 20, 2018, and 80% of the original principal amount in the fifth year after December 20, 2018.  The Revolving Credit Facility has no amortization.

- added (2019-06-10):
[0001571996-19-000025:note_history:127]
The borrowers may voluntarily repay outstanding loans under the term loan facilities and the Revolving Credit Facility at any time without premium or penalty, other than customary “breakage” costs.

- changed (2019-06-10):
[0001571996-19-000025:note_history:128]
First Lien Notes — The senior secured notes (collectively, the “First Lien Notes”) were issued on June 1, 2016 and March 20, 2019 in an aggregate principal amount of $20.0 billion and $4.5 billion, respectively.  As stated above, the Company used a portion of the $4.5 billion proceeds to repay all of the outstanding $3,750 million First Lien Notes due June 2019.  Interest on these borrowings is payable semiannually.  The First Lien Notes are secured, on a pari passu basis with the Senior Secured Credit Facilities, on a first-priority basis by substantially all of the tangible and intangible assets of the issuers and guarantors that secure obligations under the Senior Secured Credit Facilities, including pledges of all capital stock of the issuers, Dell, and certain wholly-owned material subsidiaries of the issuers and the guarantors, subject to certain exceptions.
  (was, 2018-12-10, similarity 0.809):
[0001571996-18-000044:note_history:128]
First Lien Notes — The senior secured notes (collectively, the “First Lien Notes”) were issued on June 1, 2016 in an aggregate principal amount of $20.0 billion.  Interest on these borrowings is payable semiannually.  The First Lien Notes are secured, on a pari passu basis with the Senior Secured Credit Facilities, on a first-priority basis by substantially all of the tangible and intangible assets of the issuers and guarantors that secure obligations under the Senior Secured Credit Facilities, including pledges of all capital stock of the issuers, Dell, and certain wholly-owned material subsidiaries of the issuers and the guarantors, subject to certain exceptions.

- changed (2019-06-10):
[0001571996-19-000025:note_history:129]
China Revolving Credit Facility — During the three months ended May 3, 2019, the Company renewed its credit agreement (the “China Revolving Credit Facility”) with a bank lender for a secured revolving loan facility in an aggregate principal amount not to exceed $500 million at an interest rate of LIBOR plus 0.6% per annum.  The facility will expire on February 26, 2020.  As of May 3, 2019, there were no outstanding borrowings under the China Revolving Credit Facility.
  (was, 2018-12-10, similarity 0.6659):
[0001571996-18-000044:note_history:129]
China Revolving Credit Facility — On October 31, 2017, the Company entered into a credit agreement (the “China Revolving Credit Facility”) with a bank lender for a secured revolving loan facility in an aggregate principal amount not to exceed $500 million at an interest rate of LIBOR plus 0.6% per annum.   The facility expired on October 31, 2018, with no outstanding borrowings due.

- changed (2019-06-10):
[0001571996-19-000025:note_history:130]
Unsecured Notes and Debentures — The Company has outstanding unsecured notes and debentures (collectively, the “Unsecured Notes and Debentures”) that were issued by Dell prior to the acquisition of Dell by Dell Technologies Inc. in the going-private transaction that closed in October 2013.  Interest on these borrowings is payable semiannually.
  (was, 2018-12-10, similarity 0.9881):
[0001571996-18-000044:note_history:130]
Unsecured Notes and Debentures — The Company has outstanding unsecured notes and debentures (collectively, the “Unsecured Notes and Debentures”) that were issued prior to the acquisition of Dell by Dell Technologies Inc. in the going-private transaction that closed in October 2013.  Interest on these borrowings is payable semiannually.

- changed (2019-06-10):
[0001571996-19-000025:note_history:131]
VMware Revolving Credit Facility — On September 12, 2017, VMware, Inc. entered into an unsecured credit agreement, establishing a revolving credit facility (the “VMware Revolving Credit Facility”) with a syndicate of lenders that provides the company with a borrowing capacity of up to $1.0 billion which may be used for VMware, Inc. general corporate purposes.  Commitments under the VMware Revolving Credit Facility are available for a period of five years, which may be extended, subject to the satisfaction of certain conditions, by up to two one year periods.  The credit agreement contains certain representations, warranties, and covenants.  Commitment fees, interest rates, and other terms of borrowing under the VMware Revolving Credit Facility may vary based on VMware, Inc.’s external credit ratings.  None of the net proceeds of such borrowings will be made available to support the operations or satisfy any corporate purposes of Dell Technologies, other than the operations and corporate purposes of VMware, Inc. and VMware, Inc.’s subsidiaries.  As of May 3, 2019, there were no outstanding borrowings under the VMware Revolving Credit Facility.
  (was, 2018-12-10, similarity 0.9948):
[0001571996-18-000044:note_history:131]
VMware Revolving Credit Facility —  On September 12, 2017, VMware, Inc. entered into an unsecured credit agreement, establishing a revolving credit facility (the “VMware Revolving Credit Facility”), with a syndicate of lenders that provides the company with a borrowing capacity of up to $1.0 billion which may be used for VMware, Inc. general corporate purposes.  Commitments under the VMware Revolving Credit Facility are available for a period of five years, which may be extended, subject to the satisfaction of certain conditions, by up to two one year periods.  The credit agreement contains certain representations, warranties, and covenants.  Commitment fees, interest rates, and other terms of borrowing under the VMware Revolving Credit Facility may vary based on VMware, Inc.’s external credit ratings.  None of the net proceeds of such borrowings will be made available to support the operations or satisfy any corporate purposes of Dell Technologies, other than the operations and corporate purposes of VMware, Inc. and VMware, Inc.’s subsidiaries.  As of November 2, 2018, there were no outstanding borrowings under the VMware Revolving Credit Facility.

- changed (2019-06-10):
[0001571996-19-000025:note_history:132]
Margin Loan Facility — On April 12, 2017, the Company entered into the Margin Loan Facility in an aggregate principal amount of $2.0 billion.  In connection with the Class V transaction, on December 20, 2018, the Company amended the Margin Loan Facility to increase the aggregate principal amount to $3.35 billion.  In connection with obtaining the Term Loan A-6 Facility, the Company increased the aggregate principal amount of the facility to $4.0 billion.  VMW Holdco LLC, a wholly-owned subsidiary of EMC, is the borrower under the Margin Loan Facility, which is secured by 60 million shares of Class B common stock of VMware, Inc. and 20 million shares of Class A common stock of VMware, Inc.  Loans under the Margin Loan Facility bear interest at a rate per annum payable, at the borrower’s option, either at (a) a base rate plus 1.25% per annum or (b) a LIBOR-based rate plus 2.25% per annum.  Interest under the Margin Loan Facility is payable quarterly.
  (was, 2018-12-10, similarity 0.8046):
[0001571996-18-000044:note_history:132]
Margin Loan Facility — On April 12, 2017, the Company entered into the Margin Loan Facility in an aggregate principal amount of $2.0 billion.  VMW Holdco LLC, a wholly-owned subsidiary of EMC, is the borrower under the Margin Loan Facility, which is secured by 60 million shares of Class B common stock of VMware, Inc. and 20 million shares of Class A common stock of VMware, Inc.  Loans under the Margin Loan Facility bear interest at a rate per annum payable, at the borrower’s option, either at (a) a base rate plus 1.25% per annum or (b) a LIBOR-based rate plus 2.25% per annum.  Interest under the Margin Loan Facility is payable quarterly.

- changed (2019-06-10):
[0001571996-19-000025:note_history:133]
Pivotal Revolving Credit Facility — On September 7, 2017, Pivotal entered into a credit agreement (the “Pivotal Revolving Credit Facility”) that provides for a senior secured revolving loan facility in an aggregate principal amount not to exceed $100 million.  The credit facility contains customary representations, warranties, and covenants, including financial covenants.  The credit agreement will expire on September 8, 2020, unless it is terminated earlier.  None of the net proceeds of borrowings under the facility will be made available to support the operations or satisfy any corporate purposes of Dell Technologies, other than the operations and corporate purposes of Pivotal and Pivotal’s subsidiaries.  As of May 3, 2019, there were no outstanding borrowings under the Pivotal Revolving Credit Facility.
  (was, 2018-12-10, similarity 0.9931):
[0001571996-18-000044:note_history:133]
Pivotal Revolving Credit Facility — On September 7, 2017, Pivotal entered into a credit agreement (the “Pivotal Revolving Credit Facility”) that provides for a senior secured revolving loan facility in an aggregate principal amount not to exceed $100 million.  The credit facility contains customary representations, warranties, and covenants, including financial covenants.  The credit agreement will expire on September 8, 2020, unless it is terminated earlier.  None of the net proceeds of borrowings under the facility will be made available to support the operations or satisfy any corporate purposes of Dell Technologies, other than the operations and corporate purposes of Pivotal and Pivotal’s subsidiaries.  As of November 2, 2018, there were no outstanding borrowings under the Pivotal Revolving Credit Facility.

- changed (2019-06-10):
[0001571996-19-000025:note_history:134]
The following table presents the aggregate future maturities of the Company’s debt as of May 3, 2019 for the periods indicated:
  (was, 2018-12-10, similarity 0.6058):
[0001571996-18-000044:note_history:134]
As of November 2, 2018, aggregate future maturities of the Company’s debt were as follows:

- changed (2019-06-10):
[0001571996-19-000025:note_history:135]
|  | Maturities by Fiscal Year |
|  | 2020 (remaining nine months) |  | 2021 |  | 2022 |  | 2023 |  | 2024 |  | Thereafter |  | Total |
|  | (in millions) |
| Senior Secured Credit Facilities and First Lien Notes | $ | 248 |  |  | $ | 236 |  |  | $ | 5,542 |  |  | $ | 393 |  |  | $ | 12,033 |  |  | $ | 13,213 |  |  | $ | 31,665 |  |
| Unsecured Notes and Debentures | 600 |  |  | — |  |  | 400 |  |  | — |  |  | — |  |  | 952 |  |  | 1,952 |  |
| Senior Notes and EMC Notes | — |  |  | 2,000 |  |  | 1,625 |  |  | — |  |  | 1,000 |  |  | 1,625 |  |  | 6,250 |  |
| VMware Notes | — |  |  | 1,250 |  |  | — |  |  | 1,500 |  |  | — |  |  | 1,250 |  |  | 4,000 |  |
| DFS Debt | 3,124 |  |  | 2,402 |  |  | 594 |  |  | 187 |  |  | 36 |  |  | — |  |  | 6,343 |  |
| Margin Loan Facility | — |  |  | — |  |  | — |  |  | 4,000 |  |  | — |  |  | — |  |  | 4,000 |  |
| Other | 16 |  |  | 11 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 27 |  |
| Total maturities, principal amount | 3,988 |  |  | 5,899 |  |  | 8,161 |  |  | 6,080 |  |  | 13,069 |  |  | 17,040 |  |  | 54,237 |  |
| Associated carrying value adjustments | — |  |  | (6 | ) |  | (93 | ) |  | (30 | ) |  | (153 | ) |  | (431 | ) |  | (713 | ) |
| Total maturities, carrying value amount | $ | 3,988 |  |  | $ | 5,893 |  |  | $ | 8,068 |  |  | $ | 6,050 |  |  | $ | 12,916 |  |  | $ | 16,609 |  |  | $ | 53,524 |  |
  (was, 2018-12-10, similarity 0.8916):
[0001571996-18-000044:note_history:135]
|  | Maturities by Fiscal Year |
|  | 2019 (remaining three months) |  | 2020 |  | 2021 |  | 2022 |  | 2023 |  | Thereafter |  | Total |
|  | (in millions) |
| Senior Secured Credit Facilities and First Lien Notes | $ | 124 |  |  | $ | 4,245 |  |  | $ | 371 |  |  | $ | 7,888 |  |  | $ | 62 |  |  | $ | 16,488 |  |  | $ | 29,178 |  |
| Unsecured Notes and Debentures | — |  |  | 600 |  |  | — |  |  | 400 |  |  | — |  |  | 952 |  |  | 1,952 |  |
| Senior Notes and EMC Notes | — |  |  | — |  |  | 2,000 |  |  | 1,625 |  |  | — |  |  | 2,625 |  |  | 6,250 |  |
| VMware Notes | — |  |  | — |  |  | 1,250 |  |  | — |  |  | 1,500 |  |  | 1,250 |  |  | 4,000 |  |
| DFS Debt | 1,011 |  |  | 2,812 |  |  | 1,712 |  |  | 318 |  |  | 75 |  |  | 9 |  |  | 5,937 |  |
| Margin Loan Facility |  |  |  |  |  |  |  |  |  |  |  |  | 2,000 |  |  | — |  |  | 2,000 |  |
| Other | 7 |  |  | 24 |  |  | 16 |  |  | — |  |  | — |  |  | — |  |  | 47 |  |
| Total maturities, principal amount | 1,142 |  |  | 7,681 |  |  | 5,349 |  |  | 10,231 |  |  | 3,637 |  |  | 21,324 |  |  | 49,364 |  |
| Associated carrying value adjustments | — |  |  | (14 | ) |  | (7 | ) |  | (151 | ) |  | (26 | ) |  | (509 | ) |  | (707 | ) |
| Total maturities, carrying value amount | $ | 1,142 |  |  | $ | 7,667 |  |  | $ | 5,342 |  |  | $ | 10,080 |  |  | $ | 3,611 |  |  | $ | 20,815 |  |  | $ | 48,657 |  |

- added (2019-06-10):
[0001571996-19-000025:note_history:136]
As of May 3, 2019, the Company had certain consolidated subsidiaries that were designated as unrestricted subsidiaries for all purposes of the applicable credit agreements and the indentures governing the First Lien Notes and the Senior Notes.  Substantially all of the net assets of the Company’s consolidated subsidiaries were restricted, with the exception of the Company’s unrestricted subsidiaries, primarily VMware Inc., Secureworks, Pivotal, and their respective subsidiaries, as of May 3, 2019.

- changed (2019-06-10):
[0001571996-19-000025:note_history:137]
The Term Loan A-2 Facility, the Term Loan A-4 Facility, the Term Loan A-6 Facility, and the Revolving Credit Facility are subject to a first lien leverage ratio covenant that is tested at the end of each fiscal quarter of Dell with respect to Dell’s preceding four fiscal quarters.  The Company was in compliance with all financial covenants as of May 3, 2019.
  (was, 2018-12-10, similarity 0.8994):
[0001571996-18-000044:note_history:137]
The Term Loan A-2 Facility and the Revolving Credit Facility are subject to a first lien leverage ratio covenant that is tested at the end of each fiscal quarter of Dell with respect to Dell’s preceding four fiscal quarters.  The Company was in compliance with all financial covenants as of November 2, 2018.

- removed (2019-06-10):
[0001571996-18-000044:note_history:138]
During the nine months ended November 2, 2018, the Company repaid $3 billion principal amount of its unsecured notes and $1.4 billion principal amount of its term loan facilities, which included approximately $0.2 billion of amortization.   Additionally, during the nine months ended November 2, 2018, the Company issued an additional $1.2 billion, net, in DFS debt to support the expansion of its financing receivables portfolio.

- removed (2019-06-10):
[0001571996-18-000044:note_history:139]
The Term Loan A-2 Facility amortizes in equal quarterly installments in aggregate annual amounts equal to 5% of the original principal amount in the first year after the closing date of the refinancing transaction on October 20, 2017, 10% of the original principal amount in each of the second and third years after October 20, 2017, and 70% of the original principal amount in the fourth year after October 20, 2017.  The Term Loan B Facility amortizes in equal quarterly installments in aggregate annual amounts equal to 1% of the original principal amount.  The Revolving Credit Facility has no amortization.  The borrowers may voluntarily repay outstanding loans under the term loan facilities and the Revolving Credit Facility at any time without premium or penalty, other than customary “breakage” costs.  The Term Loan A-3 Facility was fully repaid during the three months ended November 2, 2018.

- removed (2019-06-10):
[0001571996-18-000044:note_history:140]
On November 14, 2018, the Company entered into a commitment letter with bank lenders providing for bridge financing in an aggregate principal amount of up to $5.0 billion under the Senior Secured Credit Facilities. See Note 20 of the Notes to the Condensed Consolidated Financial Statements included in this report for further information regarding the bridge financing.

- removed (2019-06-10):
[0001571996-18-000044:note_history:141]
As of November 2, 2018, the Company had certain consolidated subsidiaries that were designated as unrestricted subsidiaries for all purposes of the applicable credit agreements and the indentures governing the First Lien Notes and the Senior Notes.


## us-gaap:ScheduleOfCarryingValuesAndEstimatedFairValuesOfDebtInstrumentsTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-06-10):
[0001571996-19-000025:note_history:142]
Carrying Value and Estimated Fair Value of Outstanding Debt — The following table presents the carrying value and estimated fair value of the Company’s outstanding debt as described in Note 6 of the Notes to the Condensed Consolidated Financial Statements, including the current portion, as of the dates indicated:
  (was, 2018-12-10, similarity 0.9746):
[0001571996-18-000044:note_history:142]
Carrying Value and Estimated Fair Value of Outstanding Debt — The following table summarizes the carrying value and estimated fair value of the Company’s outstanding debt as described in Note 6 of the Notes to the Condensed Consolidated Financial Statements, including the current portion, as of the dates indicated:

- changed (2019-06-10):
[0001571996-19-000025:note_history:143]
|  | May 3, 2019 |  | February 1, 2019 |
|  | Carrying Value |  | Fair Value |  | Carrying Value |  | Fair Value |
|  | (in billions) |
| Senior Secured Credit Facilities | $ | 10.8 |  |  | $ | 10.9 |  |  | $ | 12.5 |  |  | $ | 12.6 |  |
| First Lien Notes | $ | 20.5 |  |  | $ | 22.3 |  |  | $ | 19.8 |  |  | $ | 21.0 |  |
| Unsecured Notes and Debentures | $ | 1.8 |  |  | $ | 2.0 |  |  | $ | 1.8 |  |  | $ | 1.9 |  |
| Senior Notes | $ | 3.1 |  |  | $ | 3.4 |  |  | $ | 3.1 |  |  | $ | 3.4 |  |
| EMC Notes | $ | 3.0 |  |  | $ | 3.0 |  |  | $ | 3.0 |  |  | $ | 2.9 |  |
| VMware Notes | $ | 4.0 |  |  | $ | 3.9 |  |  | $ | 4.0 |  |  | $ | 3.9 |  |
| Margin Loan Facility | $ | 4.0 |  |  | $ | 4.0 |  |  | $ | 3.3 |  |  | $ | 3.4 |  |
  (was, 2018-12-10, similarity 0.9926):
[0001571996-18-000044:note_history:143]
|  | November 2, 2018 |  | February 2, 2018 |
|  | Carrying Value |  | Fair Value |  | Carrying Value |  | Fair Value |
|  | (in billions) |
| Senior Secured Credit Facilities | $ | 9.0 |  |  | $ | 9.2 |  |  | $ | 10.4 |  |  | $ | 10.6 |  |
| First Lien Notes | $ | 19.8 |  |  | $ | 20.9 |  |  | $ | 19.7 |  |  | $ | 21.9 |  |
| Unsecured Notes and Debentures | $ | 1.8 |  |  | $ | 1.9 |  |  | $ | 2.3 |  |  | $ | 2.5 |  |
| Senior Notes | $ | 3.1 |  |  | $ | 3.4 |  |  | $ | 3.1 |  |  | $ | 3.4 |  |
| EMC Notes | $ | 3.0 |  |  | $ | 2.9 |  |  | $ | 5.5 |  |  | $ | 5.4 |  |
| VMware Notes | $ | 4.0 |  |  | $ | 3.8 |  |  | $ | 4.0 |  |  | $ | 3.9 |  |
| Margin Loan Facility | $ | 2.0 |  |  | $ | 2.0 |  |  | $ | 2.0 |  |  | $ | 2.0 |  |


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-06-10):
[0001571996-19-000025:note_history:144]
The following table presents DFS debt as of the dates indicated.  The table excludes the allocated portion of the Company’s other borrowings, which represents the additional amount considered to fund the DFS business.
  (was, 2018-12-10, similarity 0.844):
[0001571996-18-000044:note_history:144]
The following table summarizes DFS debt as of the periods indicated.  The table excludes the allocated portion of the Company’s other borrowings, which represents the additional amount considered to fund the DFS business.

- added (2019-06-10):
[0001571996-19-000025:note_history:145]
|  | May 3, 2019 |  | February 1, 2019 |
|  | (in millions) |
| DFS U.S. debt: |  |  |  |
| Securitization facilities | $ | 1,692 |  |  | $ | 1,914 |  |
| Fixed-term securitization offerings | 2,836 |  |  | 2,303 |  |
| Other | 201 |  |  | 223 |  |
| Total DFS U.S. debt | 4,729 |  |  | 4,440 |  |
| DFS international debt: |  |  |  |
| Securitization facility | 646 |  |  | 584 |  |
| Other borrowings | 766 |  |  | 708 |  |
| Note payable | 202 |  |  | 197 |  |
| Total DFS international debt | 1,614 |  |  | 1,489 |  |
| Total DFS debt | $ | 6,343 |  |  | $ | 5,929 |  |
| Total short-term DFS debt | $ | 3,952 |  |  | $ | 3,113 |  |
| Total long-term DFS debt | $ | 2,391 |  |  | $ | 2,816 |  |

- changed (2019-06-10):
[0001571996-19-000025:note_history:146]
The following table presents the Company’s outstanding debt as of the dates indicated:
  (was, 2018-12-10, similarity 0.931):
[0001571996-18-000044:note_history:146]
The following table summarizes the Company’s outstanding debt as of the dates indicated:

- changed (2019-06-10):
[0001571996-19-000025:note_history:147]
|  | May 3, 2019 |  | February 1, 2019 |
|  | (in millions) |
| Secured Debt |  |  |  |
| Senior Secured Credit Facilities: |  |  |  |
| 4.49% Term Loan B Facility due September 2023 | $ | 4,925 |  |  | $ | 4,938 |  |
| 4.24% Term Loan A-2 Facility due September 2021 | 727 |  |  | 4,116 |  |
| 4.24% Term Loan A-4 Facility due December 2023 | 1,629 |  |  | 1,650 |  |
| 4.25% Term Loan A-5 Facility due December 2019 | — |  |  | 2,016 |  |
| 4.23% Term Loan A-6 Facility due March 2024 | 3,634 |  |  | — |  |
| First Lien Notes: |  |  |  |
| 3.48% due June 2019 | — |  |  | 3,750 |  |
| 4.42% due June 2021 | 4,500 |  |  | 4,500 |  |
| 5.45% due June 2023 | 3,750 |  |  | 3,750 |  |
| 4.00% due July 2024 | 1,000 |  |  | — |  |
| 6.02% due June 2026 | 4,500 |  |  | 4,500 |  |
| 4.90% due October 2026 | 1,750 |  |  | — |  |
| 5.30% due October 2029 | 1,750 |  |  | — |  |
| 8.10% due July 2036 | 1,500 |  |  | 1,500 |  |
| 8.35% due July 2046 | 2,000 |  |  | 2,000 |  |
| Unsecured Debt |  |  |  |
| Unsecured Notes and Debentures: |  |  |  |
| 5.875% due June 2019 | 600 |  |  | 600 |  |
| 4.625% due April 2021 | 400 |  |  | 400 |  |
| 7.10% due April 2028 | 300 |  |  | 300 |  |
| 6.50% due April 2038 | 388 |  |  | 388 |  |
| 5.40% due September 2040 | 264 |  |  | 264 |  |
| Senior Notes: |  |  |  |
| 5.875% due June 2021 | 1,625 |  |  | 1,625 |  |
| 7.125% due June 2024 | 1,625 |  |  | 1,625 |  |
| EMC Notes: |  |  |  |
| 2.650% due June 2020 | 2,000 |  |  | 2,000 |  |
| 3.375% due June 2023 | 1,000 |  |  | 1,000 |  |
| VMware Notes: |  |  |  |
| 2.30% due August 2020 | 1,250 |  |  | 1,250 |  |
| 2.95% due August 2022 | 1,500 |  |  | 1,500 |  |
| 3.90% due August 2027 | 1,250 |  |  | 1,250 |  |
| DFS Debt (Note 4) | 6,343 |  |  | 5,929 |  |
| Other |  |  |  |
| 4.83% Margin Loan Facility due April 2022 | 4,000 |  |  | 3,350 |  |
| Other | 27 |  |  | 38 |  |
| Total debt, principal amount | $ | 54,237 |  |  | $ | 54,239 |  |
  (was, 2018-12-10, similarity 0.6046):
[0001571996-18-000044:note_history:147]
|  | November 2, 2018 |  | February 2, 2018 |
|  | (in millions) |
| Secured Debt |  |  |  |
| Senior Secured Credit Facilities: |  |  |  |
| 4.31% Term Loan B Facility due September 2023 | $ | 4,950 |  |  | $ | 4,988 |  |
| 4.06% Term Loan A-2 Facility due September 2021 | 4,228 |  |  | 4,394 |  |
| 3.81% Term Loan A-3 Facility due December 2018 | — |  |  | 1,213 |  |
| First Lien Notes: |  |  |  |
| 3.48% due June 2019 | 3,750 |  |  | 3,750 |  |
| 4.42% due June 2021 | 4,500 |  |  | 4,500 |  |
| 5.45% due June 2023 | 3,750 |  |  | 3,750 |  |
| 6.02% due June 2026 | 4,500 |  |  | 4,500 |  |
| 8.10% due July 2036 | 1,500 |  |  | 1,500 |  |
| 8.35% due July 2046 | 2,000 |  |  | 2,000 |  |
| Unsecured Debt |  |  |  |
| Unsecured Notes and Debentures: |  |  |  |
| 5.65% due April 2018 | — |  |  | 500 |  |
| 5.875% due June 2019 | 600 |  |  | 600 |  |
| 4.625% due April 2021 | 400 |  |  | 400 |  |
| 7.10% due April 2028 | 300 |  |  | 300 |  |
| 6.50% due April 2038 | 388 |  |  | 388 |  |
| 5.40% due September 2040 | 264 |  |  | 264 |  |
| Senior Notes: |  |  |  |
| 5.875% due June 2021 | 1,625 |  |  | 1,625 |  |
| 7.125% due June 2024 | 1,625 |  |  | 1,625 |  |
| EMC Notes: |  |  |  |
| 1.875% due June 2018 | — |  |  | 2,500 |  |
| 2.650% due June 2020 | 2,000 |  |  | 2,000 |  |
| 3.375% due June 2023 | 1,000 |  |  | 1,000 |  |
| VMware Notes: |  |  |  |
| 2.30% due August 2020 | 1,250 |  |  | 1,250 |  |
| 2.95% due August 2022 | 1,500 |  |  | 1,500 |  |
| 3.90% due August 2027 | 1,250 |  |  | 1,250 |  |
| DFS Debt (Note 5) | 5,937 |  |  | 4,796 |  |
| Other |  |  |  |
| 4.78% Margin Loan Facility due April 2022 | 2,000 |  |  | 2,000 |  |
| Other | 47 |  |  | 101 |  |
| Total debt, principal amount | $ | 49,364 |  |  | $ | 52,694 |  |

- changed (2019-06-10):
[0001571996-19-000025:note_history:148]
|  | May 3, 2019 |  | February 1, 2019 |
|  | (in millions) |
| Total debt, principal amount | $ | 54,237 |  |  | $ | 54,239 |  |
| Unamortized discount, net of unamortized premium | (268 | ) |  | (271 | ) |
| Debt issuance costs | (445 | ) |  | (447 | ) |
| Total debt, carrying value | $ | 53,524 |  |  | $ | 53,521 |  |
| Total short-term debt, carrying value | $ | 4,884 |  |  | $ | 4,320 |  |
| Total long-term debt, carrying value | $ | 48,640 |  |  | $ | 49,201 |  |
  (was, 2018-12-10, similarity 0.9864):
[0001571996-18-000044:note_history:148]
|  | November 2, 2018 |  | February 2, 2018 |
|  | (in millions) |
| Total debt, principal amount | $ | 49,364 |  |  | $ | 52,694 |  |
| Unamortized discount, net of unamortized premium | (238 | ) |  | (266 | ) |
| Debt issuance costs | (469 | ) |  | (557 | ) |
| Total debt, carrying value | $ | 48,657 |  |  | $ | 51,871 |  |
| Total short-term debt, carrying value | $ | 8,150 |  |  | $ | 7,873 |  |
| Total long-term debt, carrying value | $ | 40,507 |  |  | $ | 43,998 |  |

- removed (2019-06-10):
[0001571996-18-000044:note_history:149]
|  | November 2, 2018 |  | February 2, 2018 |
|  | (in millions) |
| DFS U.S. debt |  |  |  |
| Securitization facilities | $ | 1,649 |  |  | $ | 1,498 |  |
| Fixed-term securitization offerings | 2,683 |  |  | 2,034 |  |
| Other | 186 |  |  | 32 |  |
| Total DFS U.S. debt | 4,518 |  |  | 3,564 |  |
| DFS international debt |  |  |  |
| Securitization facility | 524 |  |  | 404 |  |
| Other structured facilities | 702 |  |  | 628 |  |
| Note payable | 193 |  |  | 200 |  |
| Total DFS international debt | 1,419 |  |  | 1,232 |  |
| Total DFS debt | $ | 5,937 |  |  | $ | 4,796 |  |
| Total short-term DFS debt | $ | 3,288 |  |  | $ | 3,327 |  |
| Total long-term DFS debt | $ | 2,649 |  |  | $ | 1,469 |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-06-10):
[0001571996-19-000025:note_history:150]
The following table presents the aggregate future maturities of the Company’s debt as of May 3, 2019 for the periods indicated:
  (was, 2018-12-10, similarity 0.6058):
[0001571996-18-000044:note_history:150]
As of November 2, 2018, aggregate future maturities of the Company’s debt were as follows:

- changed (2019-06-10):
[0001571996-19-000025:note_history:151]
|  | Maturities by Fiscal Year |
|  | 2020 (remaining nine months) |  | 2021 |  | 2022 |  | 2023 |  | 2024 |  | Thereafter |  | Total |
|  | (in millions) |
| Senior Secured Credit Facilities and First Lien Notes | $ | 248 |  |  | $ | 236 |  |  | $ | 5,542 |  |  | $ | 393 |  |  | $ | 12,033 |  |  | $ | 13,213 |  |  | $ | 31,665 |  |
| Unsecured Notes and Debentures | 600 |  |  | — |  |  | 400 |  |  | — |  |  | — |  |  | 952 |  |  | 1,952 |  |
| Senior Notes and EMC Notes | — |  |  | 2,000 |  |  | 1,625 |  |  | — |  |  | 1,000 |  |  | 1,625 |  |  | 6,250 |  |
| VMware Notes | — |  |  | 1,250 |  |  | — |  |  | 1,500 |  |  | — |  |  | 1,250 |  |  | 4,000 |  |
| DFS Debt | 3,124 |  |  | 2,402 |  |  | 594 |  |  | 187 |  |  | 36 |  |  | — |  |  | 6,343 |  |
| Margin Loan Facility | — |  |  | — |  |  | — |  |  | 4,000 |  |  | — |  |  | — |  |  | 4,000 |  |
| Other | 16 |  |  | 11 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 27 |  |
| Total maturities, principal amount | 3,988 |  |  | 5,899 |  |  | 8,161 |  |  | 6,080 |  |  | 13,069 |  |  | 17,040 |  |  | 54,237 |  |
| Associated carrying value adjustments | — |  |  | (6 | ) |  | (93 | ) |  | (30 | ) |  | (153 | ) |  | (431 | ) |  | (713 | ) |
| Total maturities, carrying value amount | $ | 3,988 |  |  | $ | 5,893 |  |  | $ | 8,068 |  |  | $ | 6,050 |  |  | $ | 12,916 |  |  | $ | 16,609 |  |  | $ | 53,524 |  |
  (was, 2018-12-10, similarity 0.8916):
[0001571996-18-000044:note_history:151]
|  | Maturities by Fiscal Year |
|  | 2019 (remaining three months) |  | 2020 |  | 2021 |  | 2022 |  | 2023 |  | Thereafter |  | Total |
|  | (in millions) |
| Senior Secured Credit Facilities and First Lien Notes | $ | 124 |  |  | $ | 4,245 |  |  | $ | 371 |  |  | $ | 7,888 |  |  | $ | 62 |  |  | $ | 16,488 |  |  | $ | 29,178 |  |
| Unsecured Notes and Debentures | — |  |  | 600 |  |  | — |  |  | 400 |  |  | — |  |  | 952 |  |  | 1,952 |  |
| Senior Notes and EMC Notes | — |  |  | — |  |  | 2,000 |  |  | 1,625 |  |  | — |  |  | 2,625 |  |  | 6,250 |  |
| VMware Notes | — |  |  | — |  |  | 1,250 |  |  | — |  |  | 1,500 |  |  | 1,250 |  |  | 4,000 |  |
| DFS Debt | 1,011 |  |  | 2,812 |  |  | 1,712 |  |  | 318 |  |  | 75 |  |  | 9 |  |  | 5,937 |  |
| Margin Loan Facility |  |  |  |  |  |  |  |  |  |  |  |  | 2,000 |  |  | — |  |  | 2,000 |  |
| Other | 7 |  |  | 24 |  |  | 16 |  |  | — |  |  | — |  |  | — |  |  | 47 |  |
| Total maturities, principal amount | 1,142 |  |  | 7,681 |  |  | 5,349 |  |  | 10,231 |  |  | 3,637 |  |  | 21,324 |  |  | 49,364 |  |
| Associated carrying value adjustments | — |  |  | (14 | ) |  | (7 | ) |  | (151 | ) |  | (26 | ) |  | (509 | ) |  | (707 | ) |
| Total maturities, carrying value amount | $ | 1,142 |  |  | $ | 7,667 |  |  | $ | 5,342 |  |  | $ | 10,080 |  |  | $ | 3,611 |  |  | $ | 20,815 |  |  | $ | 48,657 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2019-06-10):
[0001571996-19-000025:note_history:152]
The following table presents the disaggregation of net revenue by reportable segment, and by major product categories within the segments for the periods indicated:
  (was, 2018-12-10, similarity 0.9139):
[0001571996-18-000044:note_history:152]
The following table presents the disaggregation of net revenue by reportable segment, and by major product categories within the segments:

- changed (2019-06-10):
[0001571996-19-000025:note_history:153]
|  | Three Months Ended |
|  | May 3, 2019 |  | May 4, 2018 |
|  | (in millions) |
| Net revenue: |  |  |  |  |  |
| Infrastructure Solutions Group: |  |  |  |
| Servers and networking | $ | 4,180 |  |  | $ | 4,585 |  |
| Storage | 4,022 |  |  | 4,082 |  |
| Total ISG net revenue | 8,202 |  |  | 8,667 |  |
| Client Solutions Group: |  |  |  |
| Commercial | 8,307 |  |  | 7,363 |  |
| Consumer | 2,603 |  |  | 2,908 |  |
| Total CSG net revenue | 10,910 |  |  | 10,271 |  |
| VMware: |  |  |  |
| Total VMware net revenue | 2,282 |  |  | 2,028 |  |
| Reportable segment net revenue | $ | 21,394 |  |  | $ | 20,966 |  |
  (was, 2018-12-10, similarity 0.7643):
[0001571996-18-000044:note_history:153]
|  | Three Months Ended |  | Nine Months Ended |
|  | November 2, 2018 |  | November 3, 2017 |  | November 2, 2018 |  | November 3, 2017 |
|  | (in millions) |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |
| Infrastructure Solutions Group: |  |  |  |  |  |  |  |
| Servers and networking | $ | 5,054 |  |  | $ | 3,875 |  |  | $ | 14,700 |  |  | $ | 10,908 |  |
| Storage | 3,883 |  |  | 3,660 |  |  | 12,131 |  |  | 11,055 |  |
| Total ISG net revenue | 8,937 |  |  | 7,535 |  |  | 26,831 |  |  | 21,963 |  |
| Client Solutions Group: |  |  |  |  |  |  |  |
| Commercial | 7,613 |  |  | 6,778 |  |  | 23,085 |  |  | 20,327 |  |
| Consumer | 3,292 |  |  | 3,051 |  |  | 9,219 |  |  | 8,416 |  |
| Total CSG net revenue | 10,905 |  |  | 9,829 |  |  | 32,304 |  |  | 28,743 |  |
| VMware: |  |  |  |  |  |  |  |
| Total VMware net revenue | 2,229 |  |  | 1,933 |  |  | 6,451 |  |  | 5,735 |  |
| Total segment net revenue | $ | 22,071 |  |  | $ | 19,297 |  |  | $ | 65,586 |  |  | $ | 56,441 |  |


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock (revenue_recognition_policy) — matched_by: no_current_note, score: 0.0

- removed (2019-06-10):
[0001571996-18-000044:note_history:154]
Revenue Recognition — The Company enters into a variety of agreements to provide a wide portfolio of products and services offerings to its customers.  These agreements have varying requirements depending on the goods and services being sold, the rights and obligations conveyed, and the legal jurisdiction of the arrangement.

- removed (2019-06-10):
[0001571996-18-000044:note_history:155]
Revenue is recognized either over time or at a point in time, depending on when the underlying goods or services are transferred to the customer, in an amount that reflects the consideration to which the Company expects to be entitled in exchange for delivering those goods or services.  The following five steps are applied to recognize revenue:

- removed (2019-06-10):
[0001571996-18-000044:note_history:156]
| (1) | Identify the contract with a customer. The term “contract” refers to the enforceable rights and obligations provided in an agreement between the Company and one or more other parties in exchange for payment. The Company evaluates facts and circumstances regarding sales transactions in order to identify contracts with its customers. An agreement must meet all of the following criteria to qualify as a contract eligible for revenue recognition under the model: (i) the contract must be approved by all parties; (ii) each party’s rights regarding the goods and services to be transferred to the customer can be identified; (iii) the payment terms for the goods and services can be identified; (iv) the customer has the ability and intent to pay and it is probable that the Company will collect substantially all of the consideration to which it will be entitled; and (v) the contract must have commercial substance. Judgment is used in determining the customer’s ability and intent to pay, which is based upon various factors including the customer’s historical payment experience or customer credit and financial information. |

- removed (2019-06-10):
[0001571996-18-000044:note_history:157]
| (2) | Identify the performance obligations in the contract. Distinct promises within a contract are referred to as “performance obligations” and are accounted for as separate units of account. The Company assesses whether each promised good or service is distinct for the purpose of identifying the performance obligations in the contract. This assessment involves subjective determinations and requires management to make judgments about the individual promised goods or services and whether such goods or services are separable from the other aspects of the contractual relationship. Promised goods and services are considered distinct provided that: (i) the customer can benefit from the good or service either on its own or together with other resources that are readily available to the customer (that is, the good or service is capable of being distinct); and (ii) the Company’s promise to transfer the good or service to the customer is separately identifiable from other promises in the contract (that is, the promise to transfer the good or service is distinct within the context of the contract). The Company’s performance obligations consist of a variety of products and services offerings which include: hardware, such as servers, storage, networking, personal computers, workstations, and peripherals; third-party software; proprietary software licenses; support and deployment services, which include hardware support that extends beyond the Company’s standard warranties, software maintenance, and installation; professional services; training; software as a service (“SaaS”); and infrastructure as a service (“IaaS”). |

- removed (2019-06-10):
[0001571996-18-000044:note_history:158]
| (3) | Determine the transaction price. Transaction price reflects the amount of consideration to which the Company expects to be entitled in exchange for transferring goods or services to the customer. If the consideration promised in a contract includes a variable amount, the Company estimates the amount to which it expects to be entitled using either the expected value or most likely amount method. The Company’s contracts may include terms that could cause variability in the transaction price, including, for example, rebates, sales returns, and volume discounts. In determining the transaction price, any variable consideration would be considered, to the extent applicable, if it is probable that a significant future reversal of cumulative revenue under the contract will not occur when the uncertainty associated with the variable consideration is resolved. |

- removed (2019-06-10):
[0001571996-18-000044:note_history:159]
| (4) | Allocate the transaction price to performance obligations in the contract. Many of the Company’s contracts include promises to transfer multiple products and services to a customer, and the transaction price must be allocated to each performance obligation in an amount that depicts the consideration to which the Company expects to be entitled in exchange for transferring the promised goods or services. For these contracts with multiple performance obligations, the transaction price is allocated in proportion to the standalone selling price (“SSP”) of each performance obligation. |

- removed (2019-06-10):
[0001571996-18-000044:note_history:160]
If the contract contains a single performance obligation, the entire transaction price is allocated to that performance obligation.

- removed (2019-06-10):
[0001571996-18-000044:note_history:161]
The best evidence of SSP is the observable price of a good or service when the Company sells that good or service separately in similar circumstances to similar customers.  If a directly observable price is available, it must be utilized for the SSP.  If a directly observable price is not available, the SSP must be estimated.  The Company estimates SSP by considering multiple factors including, but not limited to, pricing practices, internal costs, and profit objectives as well as overall market conditions which include geographic or regional specific factors, competitive positioning, and competitor actions.  SSP can include fixed and variable components.  Variable components are estimated based on the most likely outcome or expected value of the variable components.

- removed (2019-06-10):
[0001571996-18-000044:note_history:162]
| (5) | Recognize revenue when (or as) the performance obligation is satisfied. Revenue is recognized when obligations under the terms of the contract with the Company’s customer are satisfied. Revenue is recognized either over time or at a point in time, depending on when the underlying products or services are transferred to the customer. Revenue is recognized at a point in time for products upon transfer of control. Revenue is recognized over time for support and deployment services, professional services, training, software support, SaaS, and IaaS. |

- removed (2019-06-10):
[0001571996-18-000044:note_history:163]
The Company reports revenue net of any revenue-based taxes assessed by governmental authorities that are imposed on and concurrently with specific revenue-producing transactions.

- removed (2019-06-10):
[0001571996-18-000044:note_history:164]
The Company has elected the following practical expedients with the adoption of the new revenue standard:

- removed (2019-06-10):
[0001571996-18-000044:note_history:165]
| • | The Company does not account for significant financing components if the period between revenue recognition and when the customer pays for the product or service will be one year or less. |

- removed (2019-06-10):
[0001571996-18-000044:note_history:166]
| • | The Company recognizes revenue equal to the amount it has a right to invoice when the amount corresponds directly with the value to the customer of the Company’s performance to date. |

- removed (2019-06-10):
[0001571996-18-000044:note_history:167]
| • | The Company does not account for shipping and handling activities as a separate performance obligation, but rather as an activity performed to transfer the promised good. |

- removed (2019-06-10):
[0001571996-18-000044:note_history:168]
The following summarizes the nature of revenue recognized and the manner in which the Company accounts for sales transactions.

- removed (2019-06-10):
[0001571996-18-000044:note_history:169]
Products

- removed (2019-06-10):
[0001571996-18-000044:note_history:170]
Product revenue consists of hardware and software license sales that are delivered, sold as a subscription or sold on a consumption basis.  Hardware includes notebooks and desktop PCs, servers, storage hardware, and other hardware-related devices.  Software license sales include non-essential, stand-alone software applications.  Software applications provide customers with resource management, backup and archiving, information security, information management and intelligence, data analytics, and server virtualization capabilities.

- removed (2019-06-10):
[0001571996-18-000044:note_history:171]
Revenue from the sale of hardware products is recognized when control has transferred to the customer, which typically occurs when the hardware has been shipped to the customer, risk of loss has transferred to the customer, the Company has a present right to payment, and customer acceptance has been satisfied.  Customer acceptance is satisfied if acceptance is obtained from the customer, if all acceptance provisions lapse, or if the Company has evidence that all acceptance provisions will be, or have been, satisfied.  Revenue from software license sales is generally recognized when control has transferred to the customer, which is typically upon shipment, electronic delivery, or when the software is available for download by the customer.  For certain arrangements, including software subscriptions and certain software license agreements which provide customers control to certain product performance obligations over time, revenue is recognized based on usage or ratably over the term of the arrangement based on the pattern of delivery of the product to the customer.

- removed (2019-06-10):
[0001571996-18-000044:note_history:172]
Invoices for products are generally issued as control transfers, which is typically upon shipment or electronic delivery.  There was no significant revenue in any period presented related to performance obligations satisfied or partially satisfied in prior periods.

- removed (2019-06-10):
[0001571996-18-000044:note_history:173]
Services

- removed (2019-06-10):
[0001571996-18-000044:note_history:174]
Services revenue consists of revenue from sales of support services, including hardware support that extends beyond the Company’s standard warranties, software maintenance, and installation; professional services; training; SaaS; and IaaS.  Revenue associated with undelivered performance obligations is deferred and recorded as control is transferred to the customer over time.  Revenue from fixed-price support or maintenance contracts sold for both hardware and software is recognized on a straight-line basis over the period of performance because the Company is required to provide services at any given time.  Other services revenue is recognized when the Company performs the services and the customers receive and consume the benefits.

- removed (2019-06-10):
[0001571996-18-000044:note_history:175]
Invoices for services may be issued at the start of a service term, which is typically the case for support and deployment services, or as services are rendered, which is typically the case for professional services, training, SaaS, and IaaS.

- removed (2019-06-10):
[0001571996-18-000044:note_history:176]
Other

- removed (2019-06-10):
[0001571996-18-000044:note_history:177]
Revenue from leasing arrangements is not subject to the revenue standard for contracts with customers, and remains separately accounted for under existing lease accounting guidance.  The Company records revenue from the sale of equipment under sales-type leases as product revenue in an amount equal to the present value of minimum lease payments at the inception of the lease.  Sales-type leases also produce financing income, which is included in products net revenue in the Consolidated Statements of Income (Loss) and is recognized at consistent rates of return over the lease term.  The Company also offers qualified customers fixed-term loans and revolving credit lines for the purchase of products and services offered by the Company.  Financing income attributable to these loans is recognized in products net revenue on an accrual basis.

- removed (2019-06-10):
[0001571996-18-000044:note_history:178]
Disaggregation of Revenue — The Company’s revenue is presented on a disaggregated basis on the Condensed Consolidated Statements of Income (Loss) and in Note 18 of the Notes to the Condensed Consolidated Financial Statements based on an evaluation of disclosures outside of the financial statements, information regularly reviewed by the chief operating decision maker for evaluating the financial performance of operating segments, and other information that is used to evaluate the Company’s financial performance or make resource allocations.  This information includes revenue from products and services, revenue from reportable segments, and revenue by major product categories within the segments.

- removed (2019-06-10):
[0001571996-18-000044:note_history:179]
Contract Assets — Contract assets are rights to consideration in exchange for goods or services that the Company has transferred to a customer when such a right is conditional on something other than the passage of time.  Such amounts have been insignificant to date.

- removed (2019-06-10):
[0001571996-18-000044:note_history:180]
Contract Liabilities — Contract liabilities primarily consist of deferred revenue.  Deferred revenue is recorded when the Company has a right to invoice or payments have been received for undelivered products or services, or in situations where revenue recognition criteria have not been met.  Deferred revenue also represents amounts received in advance for extended warranty services and software maintenance.  Revenue is recognized on these items when the revenue recognition criteria are met, generally resulting in ratable recognition over the contract term.  The Company also has deferred revenue related to undelivered hardware and professional services, consisting of installations and consulting engagements, which are recognized as the Company’s performance obligations under the contract are completed.  See Note 9 of the Notes to the Condensed Consolidated Financial Statements for additional information about deferred revenue.

- removed (2019-06-10):
[0001571996-18-000044:note_history:181]
Costs to Obtain a Contract — The incremental direct costs of obtaining a contract primarily consist of sales commissions and employer taxes related to commission payments.  The Company has elected, as a practical expedient, to expense as incurred costs to obtain a contract equal to or less than one year in duration.  For contracts greater than one year in duration, the associated costs to obtain a contract are deferred and amortized over the period of contract performance or a longer period, generally the estimated life of the customer relationship, if renewals are expected and the renewal commission is not commensurate with the initial commission.  Deferred costs to obtain a contract are typically amortized over a period of three to seven years, depending on the contract term and expectation of the period of benefit for the costs, which may exceed the contract term.  Amortization expense is recognized on a straight-line basis and included in selling, general, and administrative expenses in the Condensed Consolidated Statements of Income (Loss).  
The Company periodically reviews these deferred costs to determine whether events or changes in circumstances have occurred that could impact the carrying value or period of benefit of the deferred sales commissions.  There were no material impairment losses for deferred sales commissions during the nine months ended November 2, 2018 and November 3, 2017.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_current_note, score: 0.0

- removed (2019-06-10):
[0001571996-18-000044:note_history:182]
NOTE 20 — SUBSEQUENT EVENTS

- removed (2019-06-10):
[0001571996-18-000044:note_history:183]
During November 2018, VMware, Inc. announced that it had signed a definitive agreement to acquire Heptio Inc. (“Heptio”).  Total consideration for the acquisition, subject to purchase price adjustments, will consist of approximately $550 million in cash and assumed unvested equity awards of the acquiree.  Heptio provides products and services that help enterprises deploy and operationalize Kubernetes.  The transaction is expected to close during the three months ending February 1, 2019 and is subject to regulatory approvals and customary closing conditions.

- removed (2019-06-10):
[0001571996-18-000044:note_history:184]
On November 14, 2018, the Company and Merger Sub entered into Amendment No.1 to the Agreement and Plan of Merger (the “Amendment”), which amended the Merger Agreement described in Note 16 of the Notes to the Condensed Consolidated Financial Statements (as amended by the Amendment, the “Amended Merger Agreement”).  The Amendment, among other things, (i) increases the Aggregate Cash Consideration Cap from $9 billion to $14 billion, (ii) increases the per share Cash Consideration from $109.00, without interest, to $120.00, without interest, and (iii) increases the ratio at which each share of Class V Common Stock may be exchanged from 1.3665 shares of Class C Common Stock to at least 1.5043 shares of Class C Common Stock.  Under the Amended Merger Agreement, each share of Class V Common Stock will be converted into the right to receive, at the election of the holder of such share, either (1) such number of shares of Class C Common Stock as determined by the application of the exchange ratio, which will be between 1.5043 and 1.8130, or (2) $120.00 in cash, without interest, subject to the Aggregate Cash Consideration Cap of $14 billion. This represents a 10% increase in the consideration for the Class V transaction, as well as a 56% increase in the Aggregate Cash Consideration Cap.

- removed (2019-06-10):
[0001571996-18-000044:note_history:185]
In addition, the Amendment provides for certain corporate governance changes that would be implemented following the closing of the Merger.  Among such changes, the Company has agreed that, no later than June 30, 2019, (i) the Company’s Board of Directors will appoint a fourth director who meets the independence requirements of the New York Stock Exchange (an “independent director”) to the Board of Directors after consultation with holders of Class C Common Stock and (ii) the Company will establish a Nominating and Corporate Governance Committee of the Board of Directors. The Nominating and Corporate Governance Committee is expected to be initially comprised of Michael Dell and Egon Durban, who currently serve as directors, and one independent director. The Amendment also includes changes to the Company’s amended and restated certificate of incorporation to provide for the ability of holders of Class C Common Stock, voting separately as a series, to elect one director beginning with the second annual meeting of stockholders of the Company following the closing of the Merger and annually thereafter.

- removed (2019-06-10):
[0001571996-18-000044:note_history:186]
In connection with the Amendment, Dell entered into a commitment letter, dated November 14, 2018, with bank lenders providing for a senior secured incremental first lien term A loan facility (the “bridge financing”) under the Company’s existing senior secured credit agreement to fund the $5 billion increase in the Aggregate Cash Consideration Cap.  The bridge financing will bear interest at a rate per annum equal to an applicable margin, plus, at the borrowers’ option, either (i) the adjusted LIBOR plus 1.75%, subject to an interest rate floor of 0% per annum, or (ii) a base rate subject to an interest rate floor of 0.75% per annum, subject to an interest rate floor of 0% per annum.

- removed (2019-06-10):
[0001571996-18-000044:note_history:187]
The bridge financing will have no amortization and will initially mature on the earlier of (a) February 8, 2019 and (b) the date on which the Merger Agreement is terminated by the Company or any of its affiliates in accordance with its terms (the “Initial Maturity Date”), except that, on the date on which the Class V transaction is consummated, the Initial Maturity Date will be extended automatically to the date that is 364 days after the closing date of the Merger (the “First Extended Maturity Date”), so long as the Merger has been consummated prior to the Initial Maturity Date.

- removed (2019-06-10):
[0001571996-18-000044:note_history:188]
The First Extended Maturity Date may be extended to the date that is 364 days after the First Extended Maturity Date (the “Second Extended Maturity Date” and together with the Initial Maturity Date and the First Extended Maturity Date, as applicable, the “Maturity Date”) so long as (i) the borrower shall have provided written notice of the extension at least 10 business days prior to the First Extended Maturity Date, (ii) concurrently with the effectiveness of such extension, the borrower shall have paid an extension fee in an amount equal to 0.50% of the aggregate principal amount of the bridge financing so extended, and (iii) the conditions set forth in senior secured credit agreement shall have been satisfied.

- removed (2019-06-10):
[0001571996-18-000044:note_history:189]
The Merger and the Class V transaction will be accounted for as a hybrid liability and equity transaction involving the repurchase of outstanding common stock, with the consideration consisting of a variable combination of cash and shares.  Upon settlement, the accounting for the Class V transaction will reflect that the outstanding Class V Common Stock will be canceled and converted into the right to receive shares of Class C Common Stock or $120.00 per share in cash or combination of cash and shares, depending on each holder’s election and subject to proration of the cash elections.  The variable nature of the cash obligation to repurchase the shares of Class V Common Stock may require the Company to settle a portion of the shares in exchange for cash and therefore will be accounted for as a financial instrument with a potential mark-to-market adjustment for the change in fair value from the date of the stockholder meeting at which the Company’s stockholders will vote on approval of the Class V transaction to the election deadline by which holders of Class V Common Stock must elect the form of consideration for which they will exchange their shares.  After the election deadline and following the determination of the final proration of cash elections and the exchange ratio, the Class V transaction will be accounted for as an equity transaction.

- removed (2019-06-10):
[0001571996-18-000044:note_history:190]
Other than the matters identified above, there were no known events occurring after the balance sheet date and up until the date of the issuance of this report that would materially affect the information presented herein.
