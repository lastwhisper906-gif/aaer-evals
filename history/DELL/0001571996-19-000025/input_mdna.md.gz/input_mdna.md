# DELL MD&A — 0001571996-19-000025


## mdna

[0001571996-19-000025:mdna:1]
[same as prior period, unchanged from 0001571996-18-000044:mdna:1]

[0001571996-19-000025:mdna:2]
[same as prior period, unchanged from 0001571996-18-000044:mdna:3]

[0001571996-19-000025:mdna:3]
[same as prior period, unchanged from 0001571996-18-000044:mdna:4]

[0001571996-19-000025:mdna:4]
Our fiscal year is the 52- or 53-week period ending on the Friday nearest January 31.  We refer to our fiscal year ending January 31, 2020 and our fiscal year ended February 1, 2019 as “Fiscal 2020” and “Fiscal 2019,” respectively.  Fiscal 2020 and Fiscal 2019 include 52 weeks.

[0001571996-19-000025:mdna:5]
[same as prior period, unchanged from 0001571996-18-000044:mdna:6]

[0001571996-19-000025:mdna:6]
Dell Technologies is a leading global end-to-end technology provider, with a comprehensive portfolio of IT hardware, software, and service solutions spanning both traditional infrastructure and emerging, multi-cloud technologies that enable our customers to build their digital future and transform how they work and live.  We collaborate across key functional areas such as technology and product development, marketing, go-to-market and global services, and are supported by Dell Financial Services.  We believe this operational philosophy enables our platform to seamlessly deliver differentiated and holistic IT solutions to our customers, which has driven significant revenue growth and share gains.

[0001571996-19-000025:mdna:7]
Dell Technologies operates with significant scale and a differentiated breadth of complementary offerings.  Digital transformation has become essential to all businesses, and we have expanded our portfolio to include holistic solutions that enable our customers to drive their ongoing digital transformation initiatives.  Dell Technologies’ integrated solutions help customers modernize their IT infrastructure, address workforce transformation, and provide critical security solutions to protect against the ever increasing and evolving security threats.  With our extensive portfolio and our commitment to innovation, we have the ability to offer secure, integrated solutions that extend from the edge to the core to the cloud, and we are at the forefront of the software-defined and cloud native infrastructure era.  Our end-to-end portfolio is supported by a differentiated go-to-market engine, which includes a 40,000-person sales force, a global network of channel partners, and a world-class supply chain that together drive revenue growth and operating efficiencies.

[0001571996-19-000025:mdna:8]
[same as prior period, unchanged from 0001571996-18-000044:mdna:9]

[0001571996-19-000025:mdna:9]
[same as prior period, unchanged from 0001571996-18-000044:mdna:10]

[0001571996-19-000025:mdna:10]
| • | Infrastructure Solutions Group (“ISG”) — ISG enables the digital transformation of our customers through our trusted multi-cloud and big data solutions, which are built upon a modern data center infrastructure. Our comprehensive portfolio of advanced storage solutions includes traditional storage solutions as well as next-generation storage solutions (such as all-flash arrays, scale-out file, object platforms, and software-defined solutions), while our server portfolio includes high-performance rack, blade, tower, and hyperscale servers. Our networking portfolio helps our business customers transform and modernize their infrastructure, mobilize and enrich end-user experiences, and accelerate business applications and processes. Our strengths in server, storage, and virtualization software solutions enable us to offer leading converged and hyper-converged solutions, helping customers build modern two-tier IT architecture for simplified management and operations. This allows our customers to accelerate their IT transformation by acquiring scalable integrated IT solutions instead of building and assembling their own IT platforms. ISG also offers attached software, peripherals, and services, including support and deployment, configuration, and extended warranty services. |

[0001571996-19-000025:mdna:11]
We are continuing our journey to simplify our storage portfolio, with the goal of ensuring that we deliver the technology needed for our customers’ digital transformation.  As our storage portfolio evolves, we will continue to support our current portfolio of storage solutions.

[0001571996-19-000025:mdna:12]
[same as prior period, unchanged from 0001571996-18-000044:mdna:13]

[0001571996-19-000025:mdna:13]
| • | Client Solutions Group (“CSG”) — CSG includes branded hardware (such as desktops, workstations, and notebooks) and branded peripherals (such as displays and projectors), as well as third-party software and peripherals. Our computing devices are designed with our commercial and consumer customers’ needs in mind, and we seek to optimize performance, reliability, manageability, design, and security. In addition to our traditional hardware business, we have a portfolio of thin client offerings that we believe will allow us to benefit from the growth trends in cloud computing. For our customers that are seeking to simplify client lifecycle management, Dell PC as a Service offering combines hardware, software, lifecycle services, and financing into one all-encompassing solution that provides predictable pricing per seat per month through Dell Financial Services. CSG also offers attached software, peripherals, and services, including support and deployment, configuration, and extended warranty services. |

[0001571996-19-000025:mdna:14]
[same as prior period, unchanged from 0001571996-18-000044:mdna:15]

[0001571996-19-000025:mdna:15]
| • | VMware — The VMware reportable segment (“VMware”) reflects the operations of VMware, Inc. (NYSE: VMW) within Dell Technologies. |

[0001571996-19-000025:mdna:16]
VMware works with customers in the areas of hybrid cloud, multi-cloud, modern applications, networking and security, and digital workspaces, helping customers manage their IT resources across private clouds and complex multi-cloud, multi-device environments.  VMware’s portfolio supports and addresses the key IT priorities of customers: accelerating their cloud journey, empowering digital workspaces, and transforming networking and security.  VMware solutions provide a flexible digital foundation to enable the digital transformation of VMware’s customers as they ready their applications, infrastructure, and devices for their future business needs.

[0001571996-19-000025:mdna:17]
[same as prior period, unchanged from 0001571996-18-000044:mdna:18]

[0001571996-19-000025:mdna:18]
Our other businesses, described below, consist of product and service offerings of Pivotal, Secureworks, RSA Security, Virtustream, and Boomi, each of which is majority-owned by Dell Technologies.  These businesses are not classified as reportable segments, either individually or collectively, as the results of the businesses are not material to our overall results and the businesses do not meet the criteria for reportable segments.  See Note 18 of the Notes to the Condensed Consolidated Financial Statements included in this report for more information about our other businesses.

[0001571996-19-000025:mdna:19]
| • | Pivotal (NYSE: PVTL) provides a leading cloud-native platform that makes software development and IT operations a strategic advantage for customers. Pivotal’s cloud-native platform, Pivotal Cloud Foundry, accelerates and streamlines software development by reducing the complexity of building, deploying, and operating new cloud-native applications and modernizing legacy applications. On April 24, 2018, Pivotal completed a registered underwritten initial public offering of its Class A common stock. |

[0001571996-19-000025:mdna:20]
| • | Secureworks (NASDAQ: SCWX) is a leading global provider of intelligence-driven information security solutions singularly focused on protecting its clients from cyber attacks. The solutions offered by Secureworks enable organizations of varying size and complexity to fortify their cyber defenses to prevent security breaches, detect malicious activity in near real time, prioritize and respond rapidly to security incidents and predict emerging threats. |

[0001571996-19-000025:mdna:21]
[same as prior period, unchanged from 0001571996-18-000044:mdna:22]

[0001571996-19-000025:mdna:22]
| • | Virtustream offers cloud software and infrastructure-as-a-service solutions that enable customers to migrate, run, and manage mission-critical applications in cloud-based IT environments. |

[0001571996-19-000025:mdna:23]
[same as prior period, unchanged from 0001571996-18-000044:mdna:24]

[0001571996-19-000025:mdna:24]
We recently unveiled the Dell Technologies Cloud, a new set of cloud infrastructure solutions to make hybrid cloud environments simpler to deploy and manage.  The Dell Technologies Cloud portfolio consists of the new Dell Technologies Cloud Platforms and the new Data Center-as-a-Service offering, VMware Cloud on Dell EMC.  These enable a flexible range of IT and management options with tight integration and a single vendor experience for purchasing, deployment, services, and financing, giving customers more control as the operational hub of their hybrid clouds.  We believe the increasing collaboration, innovation, and coordination of the operations and strategies of our businesses, as well as our differentiated go-to-market model, will continue to drive revenue synergies.  Through our coordinated research and development activities, we are able to jointly engineer leading innovative solutions that incorporate the distinct set of hardware, software, and services across our businesses.

[0001571996-19-000025:mdna:25]
Our products and services offerings are continually evolving in response to industry dynamics.  As a result, reclassifications of certain products and services solutions in major product categories may be required.  For further discussion regarding our current reportable segments, see “Results of Operations — Business Unit Results.”

[0001571996-19-000025:mdna:26]
[same as prior period, unchanged from 0001571996-18-000044:mdna:27]

[0001571996-19-000025:mdna:27]
Dell Financial Services and its affiliates (“DFS”) support our businesses by offering and arranging various financing options and services for our customers in North America, Europe, Australia, and New Zealand.  DFS originates, collects, and services customer receivables primarily related to the purchase or use of our product, software, and service solutions.  We also arrange financing for some of our customers in various countries where DFS does not currently operate as a captive enterprise.  DFS further strengthens our customer relationships through its flexible consumption models, which enable us to offer our customers the option to pay over time and, in certain cases, based on utilization, to provide them with financial flexibility to meet their changing technological requirements.  The results of these operations are allocated to our segments based on the underlying product or service financed.  For additional information about our financing arrangements, see Note 4 of the Notes to the Condensed Consolidated Financial Statements included in this report.

[0001571996-19-000025:mdna:28]
62

[0001571996-19-000025:mdna:29]
[same as prior period, unchanged from 0001571996-18-000044:mdna:29]

[0001571996-19-000025:mdna:30]
As part of our strategy, we will continue to evaluate opportunities for strategic investments through our venture capital investment arm, Dell Technologies Capital, with a focus on emerging technology areas that are relevant to the Dell Technologies unique family of businesses and that will complement our existing portfolio of solutions.  Our investment areas include storage, software-defined networking, management and orchestration, security, machine learning and artificial intelligence, Big Data and analytics, cloud, Internet of Things (“IoT”), and software development operations.  In addition to these investments, we also may make disciplined acquisitions targeting businesses that advance our strategic objectives.  As of May 3, 2019 and February 1, 2019, Dell Technologies held strategic investments of $0.8 billion and $1.0 billion, respectively.

[0001571996-19-000025:mdna:31]
[same as prior period, unchanged from 0001571996-18-000044:mdna:31]

[0001571996-19-000025:mdna:32]
We are seeing an accelerated rate of change in the IT industry.  Organizations are embracing digital technology to achieve their business objectives.  Our vision is to be an essential infrastructure company and leader in end-user computing, data center infrastructure solutions, data management, virtualization, IoT, and cloud software that our customers continue to trust and rely on for their IT solutions and their broader business transformation objectives as they embrace the hybrid multi-cloud environment of today.

[0001571996-19-000025:mdna:33]
We continue to invest in research and development, sales, and other key areas of our business to deliver superior products and solutions capabilities and to drive execution of long-term sustainable growth.  We believe that our results will benefit from an integrated go-to-market strategy, including enhanced coordination among the family of Dell Technologies companies, and from our differentiated products and solutions capabilities.  We intend to continue to execute on our business model and seek to balance liquidity, profitability, and growth to position our company for long-term success.

[0001571996-19-000025:mdna:34]
We expect that ISG will continue to be impacted by the changing nature of the IT infrastructure market and competitive environment.  In our server business, we may continue to be selective in determining whether to pursue certain large transactions as we drive for balanced growth and profitability.  With our scale and strong product portfolio, we believe we are well positioned to respond to ongoing competitive dynamics.  Cloud-native applications are expected to continue as a primary growth driver in the infrastructure market as IT organizations increasingly become multi-cloud environments.  We believe the complementary cloud solutions across our business strongly position us to meet these demands for our customers, who are increasingly looking to leverage different forms of cloud-based computing.  We also continue to be impacted by the emerging trends of enterprises deploying software-defined storage, hyper-converged infrastructure, and modular solutions based on server-centric architectures.  These trends are changing the way customers are consuming our traditional storage offerings, and we are focused on enabling new capabilities in our storage portfolio.  Offsetting such trends, however, is the unprecedented data growth throughout all industries, which is generating continued demand for our storage products and services.  We have leading solutions through our ISG and VMware data center offerings.  In addition, through our research and development efforts, we expect to develop new solutions in this rapidly changing industry that we believe will enable us to continue to provide superior solutions to our customers.

[0001571996-19-000025:mdna:35]
In ISG, we are also seeing continued interest in flexible consumption models by our customers as they seek to build greater flexibility into their cost structures.  These solutions are generally multi-year contracts that typically result in recognition of revenue over the term of the arrangement.  We expect these flexible consumption models will further strengthen our customer relationships and will provide more predictable revenue streams over time.

[0001571996-19-000025:mdna:36]
[same as prior period, unchanged from 0001571996-18-000044:mdna:35]

[0001571996-19-000025:mdna:37]
We manage our business on a U.S. dollar basis.  However, we have a large global presence, generating approximately half of our revenue by sales to customers outside of the United States during the first three months of Fiscal 2020 and the first three months of Fiscal 2019.  Our revenue, therefore, can be impacted by fluctuations in foreign currency exchange rates.  We utilize a comprehensive hedging strategy intended to mitigate the impact of foreign currency volatility over time, and we adjust pricing when possible to further minimize foreign currency impacts.

[0001571996-19-000025:mdna:38]
[same as prior period, unchanged from 0001571996-18-000044:mdna:37]

[0001571996-19-000025:mdna:39]
[same as prior period, unchanged from 0001571996-18-000044:mdna:38]

[0001571996-19-000025:mdna:40]
[same as prior period, unchanged from 0001571996-18-000044:mdna:39]

[0001571996-19-000025:mdna:41]
On December 28, 2018, we completed a transaction (“Class V transaction”) in which we paid $14.0 billion in cash and issued 149,387,617 shares of our Class C Common Stock to holders of our Class V Common Stock in exchange for all outstanding shares of Class V Common Stock.  The non-cash consideration portion of the Class V transaction totaled $6.9 billion.  As a result of the Class V transaction, the tracking stock feature of Dell Technologies’ capital structure was terminated.  The Class C Common Stock is traded on the New York Stock Exchange.

[0001571996-19-000025:mdna:42]
The aggregate cash consideration and the fees and expenses incurred in connection with the Class V transaction were funded with proceeds of $3.67 billion from new term loans under our senior secured credit facilities, proceeds of a margin loan financing in an aggregate principal amount of $1.35 billion, proceeds of Dell Technologies’ pro-rata portion, in the amount of $8.87 billion, of a special $11 billion cash dividend paid by VMware, Inc. in connection with the Class V transaction, and cash on hand at Dell Technologies and its subsidiaries.  See Note 6 of the Notes to the Condensed Consolidated Financial Statements included in this report for information about the debt incurred by us to finance the Class V transaction.

[0001571996-19-000025:mdna:43]
64

[0001571996-19-000025:mdna:44]
[same as prior period, unchanged from 0001571996-18-000044:mdna:53]

[0001571996-19-000025:mdna:45]
[same as prior period, unchanged from 0001571996-18-000044:mdna:54]

[0001571996-19-000025:mdna:46]
We use non-GAAP financial measures to supplement financial information presented on a GAAP basis.  We believe that excluding certain items from our GAAP results allows management to better understand our consolidated financial performance from period to period and better project our future consolidated financial performance as forecasts are developed at a level of detail different from that used to prepare GAAP-based financial measures.  Moreover, we believe these non-GAAP financial measures provide our stakeholders with useful information to help them evaluate our operating results by facilitating an enhanced understanding of our operating performance and enabling them to make more meaningful period to period comparisons.  There are limitations to the use of the non-GAAP financial measures presented in this report.  Our non-GAAP financial measures may not be comparable to similarly titled measures of other companies.  Other companies, including companies in our industry, may calculate non-GAAP financial measures differently than we do, limiting the usefulness of those measures for comparative purposes.

[0001571996-19-000025:mdna:47]
Non-GAAP product net revenue, non-GAAP services net revenue, non-GAAP net revenue, non-GAAP product gross margin, non-GAAP services gross margin, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP operating income, and non-GAAP net income, as defined by us, exclude amortization of intangible assets, the impact of purchase accounting, transaction-related expenses, stock-based compensation expense, other corporate expenses and, for non-GAAP net income, fair value adjustments on equity adjustments and an aggregate adjustment for income taxes.  As the excluded items have a material impact on our financial results, our management compensates for this limitation by relying primarily on our GAAP results and using non-GAAP financial measures supplementally or for projections when comparable GAAP financial measures are not available.  The non-GAAP financial measures are not meant to be considered as indicators of performance in isolation from or as a substitute for net revenue, gross margin, operating expenses, operating income, or net income prepared in accordance with GAAP, and should be read only in conjunction with financial information presented on a GAAP basis.

[0001571996-19-000025:mdna:48]
Reconciliations of each non-GAAP financial measure to its most directly comparable GAAP financial measure are presented below.  We encourage you to review the reconciliations in conjunction with the presentation of the non-GAAP financial measures for each of the periods presented.  The discussion below includes information on each of the excluded items as well as our reasons for excluding them from our non-GAAP results.  In future fiscal periods, we may exclude such items and may incur income and expenses similar to these excluded items.  Accordingly, the exclusion of these items and other similar items in our non-GAAP presentation should not be interpreted as implying that these items are non-recurring, infrequent, or unusual.

[0001571996-19-000025:mdna:49]
Dell Technologies’ non-GAAP net income now excludes, among other items, fair value adjustments on equity investments as well as discrete tax items.  These items were not excluded in the prior presentation of our non-GAAP net income for the three months ended May 4, 2018.  Upon our return to the public markets in December 2018 as a result of the Class V transaction, we reevaluated the presentation of non-GAAP net income and made these changes to facilitate the evaluation of our current operating performance and the comparability of our current operating performance to our past operating performance.  Non-GAAP net income for the three months ended May 4, 2018 has been recast to reflect the current presentation.  The following is a summary of the items excluded from the most comparable GAAP financial measures to calculate our non-GAAP financial measures:

[0001571996-19-000025:mdna:50]
[same as prior period, unchanged from 0001571996-18-000044:mdna:60]

[0001571996-19-000025:mdna:51]
| • | Impact of Purchase Accounting — The impact of purchase accounting includes purchase accounting adjustments related to the EMC merger transaction and, to a lesser extent, the going-private transaction, recorded under the acquisition method of accounting in accordance with the accounting guidance for business combinations. This guidance prescribes that the purchase price be allocated to assets acquired and liabilities assumed based on the estimated fair value of such assets and liabilities on the date of the transaction. Accordingly, all of the assets and liabilities acquired in the EMC merger transaction and the going-private transaction were accounted for and recognized at fair value as of the respective transaction dates, and the fair value adjustments are being amortized over the estimated useful lives in the periods following the transactions. The fair value adjustments primarily relate to deferred revenue, inventory, and property, plant, and equipment. The purchase accounting adjustments and related amortization of those adjustments are reflected in our GAAP results; however, we evaluate the operating results of the underlying businesses on a non-GAAP basis, after removing such adjustments. We believe that excluding the impact of purchase accounting provides results that are useful in understanding our current operating performance and provides more meaningful comparisons to our past operating performance. |

[0001571996-19-000025:mdna:52]
| • | Transaction-related Expenses — Transaction-related expenses consist of acquisition, integration, and divestiture related costs, and are expensed as incurred. These expenses primarily represent costs for legal, banking, consulting, and advisory services, as well as certain compensatory retention awards directly related to the EMC merger transaction. During the first quarter of Fiscal 2019, this category also included $116 million of expenses related to integration of our inventory policies and management process related to customer evaluation units. |

[0001571996-19-000025:mdna:53]
| • | Stock-based Compensation Expense — Stock-based compensation expense consists of equity awards granted based on the estimated fair value of those awards at grant date. For service-based stock options, we typically estimate the fair value using the Black-Scholes valuation model and for performance-based awards containing a market condition, we estimate the fair value using the Monte Carlo valuation model. Our non-GAAP adjustment for stock-based compensation expense was previously included within the other corporate expenses non-GAAP adjustment. Due to the growth in our stock-based compensation expense, we have revised our presentation to present stock-based compensation expense separately in our reconciliations presented below. Stock-based compensation expense varies from period to period and is significantly impacted by our share price and the various assumptions used for valuation purposes. Therefore, although we will incur this type of expense in the future, we believe that eliminating these charges for purposes of calculating the non-GAAP financial measures presented below facilitates a more meaningful evaluation of our current operating performance and comparisons to our past operating performance. |

[0001571996-19-000025:mdna:54]
| • | Other Corporate Expenses — Other corporate expenses consists primarily of severance, facility action, and other costs. Severance costs are primarily related to severance and benefits for employees terminated pursuant to cost savings initiatives. We continue to integrate owned and leased facilities and may incur additional costs as we seek opportunities for operational efficiencies. Other corporate expenses vary from period to period and are significantly impacted by the timing and nature of these events. Therefore, although we may incur these types of expenses in the future, we believe that eliminating these charges for purposes of calculating the non-GAAP financial measures presented below facilitates a more meaningful evaluation of our current operating performance and comparisons to our past operating performance. |

[0001571996-19-000025:mdna:55]
| • | Fair Value Adjustments on Equity Investments — Fair value adjustments on equity investments primarily consists of the gain (loss) on strategic investments, which includes the recurring fair value adjustments of investments in publicly-traded companies, as well as those in privately-held companies, which are adjusted for observable price changes, and to a lesser extent any potential impairments. Given the volatility in the ongoing adjustments to the valuation of these strategic investments, we believe that excluding these gains and losses for purposes of calculating non-GAAP net income presented below facilitates a more meaningful evaluation of our current operating performance and comparisons to our past operating performance. |

[0001571996-19-000025:mdna:56]
| • | Aggregate Adjustment for Income Taxes — The aggregate adjustment for income taxes is the estimated combined income tax effect for the adjustments described above, as well as an adjustment for discrete tax items. Due to the variability in recognition of discrete tax items from period to period, we believe that excluding these benefits or charges for purposes of calculating non-GAAP net income facilitates a more meaningful evaluation of our current operating performance and comparisons to our past operating performance. The tax effects are determined based on the tax jurisdictions where the above items were incurred. |

[0001571996-19-000025:mdna:57]
66

[0001571996-19-000025:mdna:58]
[same as prior period, unchanged from 0001571996-18-000044:mdna:66]

[0001571996-19-000025:mdna:59]
|  | Three Months Ended |
|  | May 3, 2019 |  | % Change |  | May 4, 2018 |
|  | (in millions, except percentages) |
| Product net revenue | $ | 16,754 |  |  | — | % |  | $ | 16,671 |  |
| Non-GAAP adjustments: |  |  |  |  |  |
| Impact of purchase accounting | 4 |  |  |  |  | 17 |  |
| Non-GAAP product net revenue | $ | 16,758 |  |  | — | % |  | $ | 16,688 |  |
| Services net revenue | $ | 5,154 |  |  | 10 | % |  | $ | 4,685 |  |
| Non-GAAP adjustments: |  |  |  |  |  |
| Impact of purchase accounting | 78 |  |  |  |  | 170 |  |
| Non-GAAP services net revenue | $ | 5,232 |  |  | 8 | % |  | $ | 4,855 |  |
| Net revenue | $ | 21,908 |  |  | 3 | % |  | $ | 21,356 |  |
| Non-GAAP adjustments: |  |  |  |  |  |
| Impact of purchase accounting | 82 |  |  |  |  | 187 |  |
| Non-GAAP net revenue | $ | 21,990 |  |  | 2 | % |  | $ | 21,543 |  |
| Product gross margin | $ | 3,675 |  |  | 20 | % |  | $ | 3,065 |  |
| Non-GAAP adjustments: |  |  |  |  |  |
| Amortization of intangibles | 519 |  |  |  |  | 710 |  |
| Impact of purchase accounting | 6 |  |  |  |  | 23 |  |
| Transaction-related expenses | (2 | ) |  |  |  | 116 |  |
| Stock-based compensation expense | 2 |  |  |  |  | 2 |  |
| Other corporate expenses | 4 |  |  |  |  | 2 |  |
| Non-GAAP product gross margin | $ | 4,204 |  |  | 7 | % |  | $ | 3,918 |  |
| Services gross margin | $ | 3,122 |  |  | 11 | % |  | $ | 2,813 |  |
| Non-GAAP adjustments: |  |  |  |  |  |
| Impact of purchase accounting | 78 |  |  |  |  | 170 |  |
| Transaction-related expenses | (3 | ) |  |  |  | — |  |
| Stock-based compensation expense | 24 |  |  |  |  | 14 |  |
| Other corporate expenses | 9 |  |  |  |  | 4 |  |
| Non-GAAP services gross margin | $ | 3,230 |  |  | 8 | % |  | $ | 3,001 |  |

[0001571996-19-000025:mdna:60]
67

[0001571996-19-000025:mdna:61]
|  | Three Months Ended |
|  | May 3, 2019 |  | % Change |  | May 4, 2018 |
|  | (in millions, except percentages) |
| Gross margin | $ | 6,797 |  |  | 16 | % |  | $ | 5,878 |  |
| Non-GAAP adjustments: |  |  |  |  |  |
| Amortization of intangibles | 519 |  |  |  |  | 710 |  |
| Impact of purchase accounting | 84 |  |  |  |  | 193 |  |
| Transaction-related expenses | (5 | ) |  |  |  | 116 |  |
| Stock-based compensation expense | 26 |  |  |  |  | 16 |  |
| Other corporate expenses | 13 |  |  |  |  | 6 |  |
| Non-GAAP gross margin | $ | 7,434 |  |  | 7 | % |  | $ | 6,919 |  |
| Operating expenses | $ | 6,247 |  |  | 4 | % |  | $ | 6,031 |  |
| Non-GAAP adjustments: |  |  |  |  |  |
| Amortization of intangibles | (698 | ) |  |  |  | (812 | ) |
| Impact of purchase accounting | (17 | ) |  |  |  | (29 | ) |
| Transaction-related expenses | (47 | ) |  |  |  | (50 | ) |
| Stock-based compensation expense | (237 | ) |  |  |  | (183 | ) |
| Other corporate expenses | (10 | ) |  |  |  | (64 | ) |
| Non-GAAP operating expenses | $ | 5,238 |  |  | 7 | % |  | $ | 4,893 |  |
| Operating income (loss) | $ | 550 |  |  | 459 | % |  | $ | (153 | ) |
| Non-GAAP adjustments: |  |  |  |  |  |
| Amortization of intangibles | 1,217 |  |  |  |  | 1,522 |  |
| Impact of purchase accounting | 101 |  |  |  |  | 222 |  |
| Transaction-related expenses | 42 |  |  |  |  | 166 |  |
| Stock-based compensation expense | 263 |  |  |  |  | 199 |  |
| Other corporate expenses | 23 |  |  |  |  | 70 |  |
| Non-GAAP operating income | $ | 2,196 |  |  | 8 | % |  | $ | 2,026 |  |
| Net income (loss) | $ | 329 |  |  | 161 | % |  | $ | (538 | ) |
| Non-GAAP adjustments: |  |  |  |  |  |
| Amortization of intangibles | 1,217 |  |  |  |  | 1,522 |  |
| Impact of purchase accounting | 101 |  |  |  |  | 222 |  |
| Transaction-related expenses | 42 |  |  |  |  | 166 |  |
| Stock-based compensation expense | 263 |  |  |  |  | 199 |  |
| Other corporate expenses | 23 |  |  |  |  | 70 |  |
| Fair value adjustments on equity investments | (62 | ) |  |  |  | (107 | ) |
| Aggregate adjustment for income taxes | (704 | ) |  |  |  | (355 | ) |
| Non-GAAP net income (a) | $ | 1,209 |  |  | 3 | % |  | $ | 1,179 |  |

[0001571996-19-000025:mdna:62]
_________________

[0001571996-19-000025:mdna:63]
| (a) | Non-GAAP net income has been recast to exclude fair value adjustments on equity investments, the corresponding tax effects of those adjustments, and discrete tax items. |

[0001571996-19-000025:mdna:64]
In addition to the above measures, we also use EBITDA and adjusted EBITDA to provide additional information for evaluation of our operating performance.  Adjusted EBITDA excludes purchase accounting adjustments related to the EMC merger transaction and the going-private transaction, acquisition, integration, and divestiture related costs, severance, facility action, and other costs, and stock-based compensation expense.  We believe that, due to the non-operational nature of the purchase accounting entries, it is appropriate to exclude these adjustments.

[0001571996-19-000025:mdna:65]
[same as prior period, unchanged from 0001571996-18-000044:mdna:71]

[0001571996-19-000025:mdna:66]
The table below presents a reconciliation of EBITDA and adjusted EBITDA to net loss for the periods presented:

[0001571996-19-000025:mdna:67]
|  | Three Months Ended |
|  | May 3, 2019 |  | % Change |  | May 4, 2018 |
|  | (in millions, except percentages) |
| Net income (loss) | $ | 329 |  |  | 161 | % |  | $ | (538 | ) |
| Adjustments: |  |  |  |  |  |
| Interest and other, net (a) | 693 |  |  |  |  | 470 |  |
| Income tax benefit | (472 | ) |  |  |  | (85 | ) |
| Depreciation and amortization | 1,616 |  |  |  |  | 1,914 |  |
| EBITDA | $ | 2,166 |  |  | 23 | % |  | $ | 1,761 |  |
| EBITDA | $ | 2,166 |  |  | 23 | % |  | $ | 1,761 |  |
| Adjustments: |  |  |  |  |  |
| Stock-based compensation expense | 263 |  |  |  |  | 199 |  |
| Impact of purchase accounting (b) | 83 |  |  |  |  | 222 |  |
| Transaction-related expenses (c) | 42 |  |  |  |  | 166 |  |
| Other corporate expenses (d) | 19 |  |  |  |  | 35 |  |
| Adjusted EBITDA | $ | 2,573 |  |  | 8 | % |  | $ | 2,383 |  |

[0001571996-19-000025:mdna:68]
[same as prior period, unchanged from 0001571996-18-000044:mdna:84]

[0001571996-19-000025:mdna:69]
[same as prior period, unchanged from 0001571996-18-000044:mdna:75]

[0001571996-19-000025:mdna:70]
[same as prior period, unchanged from 0001571996-18-000044:mdna:76]

[0001571996-19-000025:mdna:71]
[same as prior period, unchanged from 0001571996-18-000044:mdna:77]

[0001571996-19-000025:mdna:72]
| (d) | Consists of severance, facility action, and other costs. |

[0001571996-19-000025:mdna:73]
69

[0001571996-19-000025:mdna:74]
[same as prior period, unchanged from 0001571996-18-000044:mdna:80]

[0001571996-19-000025:mdna:75]
[same as prior period, unchanged from 0001571996-18-000044:mdna:81]

[0001571996-19-000025:mdna:76]
The following table summarizes our consolidated results for each of the periods presented.  Unless otherwise indicated, all changes identified for the current period results represent comparisons to results for the prior corresponding fiscal period.

[0001571996-19-000025:mdna:77]
|  | Three Months Ended |
|  | May 3, 2019 |  |  |  | May 4, 2018 |
|  | Dollars |  | % ofNet Revenue |  | %Change |  | Dollars |  | % ofNet Revenue |
|  | (in millions, except percentages) |
| Net revenue: |  |  |  |  |  |  |  |  |  |
| Product | $ | 16,754 |  |  | 76.5 | % |  | — | % |  | $ | 16,671 |  |  | 78.1 | % |
| Services | 5,154 |  |  | 23.5 | % |  | 10 | % |  | 4,685 |  |  | 21.9 | % |
| Total net revenue | $ | 21,908 |  |  | 100.0 | % |  | 3 | % |  | $ | 21,356 |  |  | 100.0 | % |
| Gross margin: |  |  |  |  |  |  |  |  |  |
| Product (a) | $ | 3,675 |  |  | 21.9 | % |  | 20 | % |  | $ | 3,065 |  |  | 18.4 | % |
| Services (b) | 3,122 |  |  | 60.6 | % |  | 11 | % |  | 2,813 |  |  | 60.0 | % |
| Total gross margin | $ | 6,797 |  |  | 31.0 | % |  | 16 | % |  | $ | 5,878 |  |  | 27.5 | % |
| Operating expenses | $ | 6,247 |  |  | 28.5 | % |  | 4 | % |  | $ | 6,031 |  |  | 28.2 | % |
| Operating income (loss) | $ | 550 |  |  | 2.5 | % |  | 459 | % |  | $ | (153 | ) |  | (0.7 | )% |
| Net income (loss) | $ | 329 |  |  | 1.5 | % |  | 161 | % |  | $ | (538 | ) |  | (2.5 | )% |
| Net income (loss) attributable to Dell Technologies Inc. | $ | 293 |  |  | 1.3 | % |  | 146 | % |  | $ | (636 | ) |  | (3.0 | )% |
| Non-GAAP Financial Information |  |  |  |  |  |  |  |  |
| Non-GAAP net revenue: |  |  |  |  |  |  |  |  |  |
| Product | $ | 16,758 |  |  | 76.2 | % |  | — | % |  | $ | 16,688 |  |  | 77.5 | % |
| Services | 5,232 |  |  | 23.8 | % |  | 8 | % |  | 4,855 |  |  | 22.5 | % |
| Total non-GAAP net revenue | $ | 21,990 |  |  | 100.0 | % |  | 2 | % |  | $ | 21,543 |  |  | 100.0 | % |
| Non-GAAP gross margin: |  |  |  |  |  |  |  |  |  |
| Product (a) | $ | 4,204 |  |  | 25.1 | % |  | 7 | % |  | $ | 3,918 |  |  | 23.5 | % |
| Services (b) | 3,230 |  |  | 61.7 | % |  | 8 | % |  | 3,001 |  |  | 61.8 | % |
| Total non-GAAP gross margin | $ | 7,434 |  |  | 33.8 | % |  | 7 | % |  | $ | 6,919 |  |  | 32.1 | % |
| Non-GAAP operating expenses | $ | 5,238 |  |  | 23.8 | % |  | 7 | % |  | $ | 4,893 |  |  | 22.7 | % |
| Non-GAAP operating income | $ | 2,196 |  |  | 10.0 | % |  | 8 | % |  | $ | 2,026 |  |  | 9.4 | % |
| Non-GAAP net income (c) | $ | 1,209 |  |  | 5.5 | % |  | 3 | % |  | $ | 1,179 |  |  | 5.5 | % |
| EBITDA | $ | 2,166 |  |  | 9.8 | % |  | 23 | % |  | $ | 1,761 |  |  | 8.2 | % |
| Adjusted EBITDA | $ | 2,573 |  |  | 11.7 | % |  | 8 | % |  | $ | 2,383 |  |  | 11.1 | % |

[0001571996-19-000025:mdna:78]
____________________

[0001571996-19-000025:mdna:79]
[same as prior period, unchanged from 0001571996-18-000044:mdna:85]

[0001571996-19-000025:mdna:80]
[same as prior period, unchanged from 0001571996-18-000044:mdna:86]

[0001571996-19-000025:mdna:81]
| (c) | Non-GAAP net income has been recast to exclude fair value adjustments on equity investments, the corresponding tax effects of those adjustments, and discrete tax items. |

[0001571996-19-000025:mdna:82]
[same as prior period, unchanged from 0001571996-18-000044:mdna:52]

[0001571996-19-000025:mdna:83]
Non-GAAP product net revenue, non-GAAP services net revenue, non-GAAP net revenue, non-GAAP product gross margin, non-GAAP services gross margin, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP operating income, non-GAAP net income, EBITDA, and adjusted EBITDA are not measurements of financial performance prepared in accordance with GAAP.  Non-GAAP financial measures as a percentage of net revenue are calculated based on non-GAAP net revenue.  See “Non‑GAAP Financial Measures” for additional information about these non-GAAP financial measures, including our reasons for including these measures, material limitations with respect to the usefulness of the measures, and a reconciliation of each non-GAAP financial measure to the most directly comparable GAAP financial measure.

[0001571996-19-000025:mdna:84]
[same as prior period, unchanged from 0001571996-18-000044:mdna:88]

[0001571996-19-000025:mdna:85]
During the first quarter of Fiscal 2020, our net revenue and non-GAAP net revenue increased 3% and 2%, respectively.  The increases in net revenue and non-GAAP net revenue were attributable to increases in net revenue in CSG and VMware.  We believe we are well-positioned for long-term profitable growth while also maintaining the ability to adjust as needed to changing market conditions with the complementary solutions across our businesses.

[0001571996-19-000025:mdna:86]
During the first quarter of Fiscal 2020 and Fiscal 2019, our operating income was $550 million and our operating loss was $153 million, respectively.  The increase in our operating income for the first quarter of Fiscal 2020 was primarily attributable to a decrease in amortization of intangible assets and purchase accounting adjustments related to the EMC merger transaction and an increase in operating income for CSG.

[0001571996-19-000025:mdna:87]
Amortization of intangible assets and purchase accounting adjustments that impacted operating income totaled $1.3 billion and $1.7 billion for the first quarter of Fiscal 2020 and Fiscal 2019, respectively.  Excluding these costs, stock-based compensation expense, transaction-related expenses, and other corporate expenses, non-GAAP operating income increased 8% to $2.2 billion during the first quarter of Fiscal 2020.  The increase in non-GAAP operating income for the first quarter of Fiscal 2020 was primarily due to an increase in operating income for CSG.

[0001571996-19-000025:mdna:88]
Cash provided by operating activities was $0.7 billion during the first quarter of Fiscal 2020 compared to $1.2 billion for the first quarter of Fiscal 2019.  The decrease in operating cash flows during the first quarter of Fiscal 2020 was primarily driven by higher seasonal personnel payments, partially offset by improved profitability.  See “Market Conditions, Liquidity, and Capital Commitments” for further information on our cash flow metrics.

[0001571996-19-000025:mdna:89]
[same as prior period, unchanged from 0001571996-18-000044:mdna:93]

[0001571996-19-000025:mdna:90]
During the first quarter of Fiscal 2020, our net revenue and non-GAAP net revenue increased 3% and 2%, respectively.  The increases in net revenue and non-GAAP net revenue were attributable to increases in net revenue in CSG and VMware.  See “Business Unit Results” for further information.

[0001571996-19-000025:mdna:91]
| • | Product Net Revenue — Product net revenue includes revenue from the sale of hardware products and software licenses. During the first quarter of Fiscal 2020, both product net revenue and non-GAAP product net revenue remained consistent with the first quarter of Fiscal 2019. |

[0001571996-19-000025:mdna:92]
| • | Services Net Revenue — Services net revenue includes revenue from our services offerings and support services related to hardware products and software licenses. During the first quarter of Fiscal 2020, services net revenue and non-GAAP services net revenue increased 10% and 8%, respectively. These increases were primarily due to an increase in services revenue for hardware support and deployment and software maintenance due to growth in the business. A portion of services net revenue is derived from offerings that have been deferred over a period of time, and, as a result, reported services net revenue growth rates will be different than product net revenue growth rates. |

[0001571996-19-000025:mdna:93]
From a geographical perspective, net revenue generated by sales to customers in the Americas and EMEA increased during the first quarter of Fiscal 2020 due to strong performance globally in CSG and VMware.  Net revenue from sales to customers in APJ remained essentially unchanged during the first quarter of Fiscal 2020.

[0001571996-19-000025:mdna:94]
[same as prior period, unchanged from 0001571996-18-000044:mdna:98]

[0001571996-19-000025:mdna:95]
During the first quarter of Fiscal 2020, our gross margin increased 16% to $6.8 billion, and our gross margin percentage increased 350 basis points to 31.0%.  The increase in our gross margin percentage during the first quarter of Fiscal 2020 was primarily attributable to a decrease in amortization of intangibles and purchase accounting adjustments, a deflationary component cost environment, and increases in gross margin percentage for both ISG and CSG.

[0001571996-19-000025:mdna:96]
Our gross margin for the first quarter of Fiscal 2020 and Fiscal 2019 included the impact of amortization of intangibles and purchase accounting adjustments of $0.6 billion and $0.9 billion, respectively.  Excluding these costs, transaction-related expenses, stock-based compensation expense, and other corporate expenses, non-GAAP gross margin for the first quarter of Fiscal 2020 increased 7% to $7.4 billion, and non-GAAP gross margin percentage increased 170 basis points to 33.8%.  The increase in our non-GAAP gross margin was attributable to increases in gross margin across all three business units.  The increase in our non-GAAP gross margin percentage was primarily due to higher gross margin percentage for both ISG and CSG, as well as the positive impact of VMware’s relative mix of gross margin on our consolidated results.

[0001571996-19-000025:mdna:97]
| • | Products — During the first quarter of Fiscal 2020, product gross margin increased 20% to $3.7 billion, and product gross margin percentage increased 350 basis points to 21.9%. The increases in both product gross margin and product gross margin percentage were primarily attributable to a decrease in amortization of intangibles and transaction-related expenses. During the first quarter of Fiscal 2020, non-GAAP product gross margin increased 7% to $4.2 billion, and non-GAAP product gross margin percentage increased 160 basis points to 25.1%. The increases in product gross margin and non-GAAP product gross margin were driven primarily by increases in product revenue due to strength in sales of CSG commercial products and VMware software licenses. Product gross margin percentage and non-GAAP product gross margin percentage increased primarily as a result of higher product gross margin percentages for ISG and CSG, as well as the positive impact of VMware’s relative mix of gross margin percentage on our consolidated results. |

[0001571996-19-000025:mdna:98]
| • | Services — During the first quarter of Fiscal 2020, services gross margin increased 11% to $3.1 billion, and services gross margin percentage increased 60 basis points to 60.6%. Services gross margin increased due to growth in services gross margin across all three business units, particularly in hardware support and deployment and software maintenance. During the first quarter of Fiscal 2020 and Fiscal 2019, services gross margin also benefited from a decrease in purchase accounting adjustments, which totaled $78 million and $170 million, respectively. Excluding these costs, transaction-related expenses, stock-based compensation expense, and other corporate expenses, non-GAAP services gross margin increased 8% to $3.2 billion, and non-GAAP services gross margin percentage decreased 10 basis points to 61.7%. |

[0001571996-19-000025:mdna:99]
[same as prior period, unchanged from 0001571996-18-000044:mdna:108]

[0001571996-19-000025:mdna:100]
[same as prior period, unchanged from 0001571996-18-000044:mdna:109]

[0001571996-19-000025:mdna:101]
The terms and conditions of our vendor rebate programs are largely based on product volumes and are generally negotiated either at the beginning of the annual or quarterly period, depending on the program.  The timing and amount of vendor rebates and other discounts we receive under the programs may vary from period to period, reflecting changes in the competitive environment.  We monitor our component costs and seek to address the effects of any changes to terms that might arise under our vendor rebate programs.  Our gross margins for the first quarter of Fiscal 2020 and Fiscal 2019 were not materially affected by any changes to the terms of our vendor rebate programs, as the amounts we received under these programs were generally stable relative to our total net cost.  We are not aware of any significant changes to vendor pricing or rebate programs that may impact our results in the near term.

[0001571996-19-000025:mdna:102]
In addition, we have pursued legal action against certain vendors and are currently involved in negotiations with other vendors regarding their past pricing practices.  We have negotiated settlements with some of these vendors and may have additional settlements in future periods.  These settlements are allocated to our segments based on the relative amount of affected vendor products sold by each segment.

[0001571996-19-000025:mdna:103]
[same as prior period, unchanged from 0001571996-18-000044:mdna:113]

[0001571996-19-000025:mdna:104]
[same as prior period, unchanged from 0001571996-18-000044:mdna:114]

[0001571996-19-000025:mdna:105]
|  | Three Months Ended |
|  | May 3, 2019 |  |  |  | May 4, 2018 |
|  | Dollars |  | % ofNet Revenue |  | %Change |  | Dollars |  | % ofNet Revenue |
|  | (in millions, except percentages) |
| Operating expenses: |  |  |  |  |  |  |  |  |  |
| Selling, general, and administrative | $ | 5,071 |  |  | 23.1 | % |  | 3 | % |  | $ | 4,944 |  |  | 23.1 | % |
| Research and development | 1,176 |  |  | 5.4 | % |  | 8 | % |  | 1,087 |  |  | 5.1 | % |
| Total operating expenses | $ | 6,247 |  |  | 28.5 | % |  | 4 | % |  | $ | 6,031 |  |  | 28.2 | % |
| Other Financial Information |  |  |  |  |  |  |  |  |
| Non-GAAP operating expenses | $ | 5,238 |  |  | 23.8 | % |  | 7 | % |  | $ | 4,893 |  |  | 22.7 | % |

[0001571996-19-000025:mdna:106]
During the first quarter of Fiscal 2020, total operating expenses increased 4%.  Our operating expenses include the impact of purchase accounting, amortization of intangible assets, transaction-related expenses, stock-based compensation expense, and other corporate expenses.  In aggregate, these items totaled $1.0 billion and $1.1 billion for the first quarter of Fiscal 2020 and Fiscal 2019, respectively.  Excluding these costs, total non-GAAP operating expenses for the first quarter of Fiscal 2020 increased 7%.  The increases in operating expenses and non-GAAP operating expenses were primarily due to an increase in selling, general, and administrative expenses associated with our revenue growth and sales headcount.

[0001571996-19-000025:mdna:107]
| • | Selling, General, and Administrative — Selling, general, and administrative (“SG&A”) expenses increased 3% during the first quarter of Fiscal 2020. The increases in SG&A expenses were primarily driven by investments in our go-to-market capabilities, including sales headcount, and higher performance-based compensation and commission costs. |

[0001571996-19-000025:mdna:108]
| • | Research and Development — Research and development (“R&D”) expenses are primarily composed of personnel-related expenses related to product development. R&D expenses as a percentage of net revenue for the first quarter of Fiscal 2020 and Fiscal 2019 were approximately 5.4% and 5.1%, respectively. As our industry continues to change and as the needs of our customers evolve, we intend to support R&D initiatives to innovate and introduce new and enhanced solutions into the market. |

[0001571996-19-000025:mdna:109]
[same as prior period, unchanged from 0001571996-18-000044:mdna:119]

[0001571996-19-000025:mdna:110]
[same as prior period, unchanged from 0001571996-18-000044:mdna:120]

[0001571996-19-000025:mdna:111]
During the first quarter of Fiscal 2020, our operating income increased 459% to $550 million.  The increase in our operating income for the first quarter of Fiscal 2020 was primarily attributable to a decrease in amortization of intangible assets and purchase accounting adjustments and an increase in operating income for CSG.

[0001571996-19-000025:mdna:112]
Amortization of intangible assets and purchase accounting adjustments that impacted operating income totaled $1.3 billion and $1.7 billion for the first quarter of Fiscal 2020 and Fiscal 2019, respectively.  Excluding these costs, transaction-related expenses, stock-based compensation expense, and other corporate expenses, non-GAAP operating income increased 8% to $2.2 billion during the first quarter of Fiscal 2020.  The increase in non-GAAP operating income for the first quarter of Fiscal 2020 was primarily due to an increase in operating income for CSG.

[0001571996-19-000025:mdna:113]
[same as prior period, unchanged from 0001571996-18-000044:mdna:123]

[0001571996-19-000025:mdna:114]
[same as prior period, unchanged from 0001571996-18-000044:mdna:124]

[0001571996-19-000025:mdna:115]
|  | Three Months Ended |
|  | May 3, 2019 |  | May 4, 2018 |
|  | (in millions) |
| Interest and other, net: |  |  |  |  |  |
| Investment income, primarily interest | $ | 44 |  |  | $ | 78 |  |
| Gain (loss) on investments, net | 62 |  |  | 107 |  |
| Interest expense | (699 | ) |  | (596 | ) |
| Foreign exchange | (45 | ) |  | (77 | ) |
| Other | (55 | ) |  | 18 |  |
| Total interest and other, net | $ | (693 | ) |  | $ | (470 | ) |

[0001571996-19-000025:mdna:116]
During the first quarter of Fiscal 2020, the change in interest and other, net was unfavorable by $223 million, primarily due to higher interest expense.  To fund a portion of the cash consideration paid in the Class V transaction, we incurred additional debt and liquidated a significant amount of our investments.  As a result, we expect higher interest expense and lower investment income to continue in Fiscal 2020.  See Note 3 and Note 6 of the Notes to the Condensed Consolidated Financial Statements included in this report for further information regarding our investments and debt, respectively.

[0001571996-19-000025:mdna:117]
[same as prior period, unchanged from 0001571996-18-000044:mdna:127]

[0001571996-19-000025:mdna:118]
Our income tax rates were 330.1% and 13.6% on pre-tax losses of $143 million and $623 million for the first quarter of Fiscal 2020 and Fiscal 2019, respectively.  The change in our effective tax rate is primarily driven by discrete tax benefits and a change in our jurisdictional mix of income.  During the first quarter of Fiscal 2020, our effective tax rate includes a discrete tax benefit for $405 million resulting from an intra-entity asset transfer that was completed during the quarter.  The tax benefit represents the future amortization we will be able to realize over a period of no more than 15 years and is recorded as a deferred tax asset in the period of the transaction.  Our effective tax rate for the first quarter of Fiscal 2019 includes $154 million of discrete tax benefits resulting from the impact of our adoption during the quarter of the new revenue recognition standard.  On May 31, 2019, our VMware business unit transferred certain of its intellectual property to its Irish subsidiary.  In the second quarter of Fiscal 2020, we will record a discrete tax benefit of approximately $4.5 billion for this transaction that represents the future amortization we will be able to realize for this intellectual property.  For further discussion regarding tax matters, see Note 11 of the Notes to the Condensed Consolidated Financial Statements included in this report.

[0001571996-19-000025:mdna:119]
The Tax Cuts and Jobs Act of 2017 (“U.S. Tax Reform”) was signed into law on December 22, 2017.  Among other things, U.S. Tax Reform lowers the U.S. corporate income tax rate to 21% from 35%, establishes a modified territorial system requiring a mandatory deemed repatriation tax on undistributed earnings of foreign subsidiaries (the “Transition Tax”), requires a minimum tax on certain future earnings generated by foreign subsidiaries while providing for future tax-free repatriation of earnings through a 100% dividends-received deduction, and places limitations on the deductibility of net interest expense.  We anticipate that the U.S. Department of the Treasury and the Internal Revenue Service (“IRS”) will continue to issue regulatory guidance clarifying certain provisions of U.S. Tax Reform.  When additional guidance is issued, we will recognize the related tax impact in the fiscal quarter of such issuance.

[0001571996-19-000025:mdna:120]
Our effective income tax rate can fluctuate depending on the geographic distribution of our worldwide earnings, as our foreign earnings are generally taxed at lower rates than in the United States.  The differences between our effective income tax rate and the U.S. federal statutory rate of 21% principally result from the geographical distribution of income and differences between the book and tax treatment of certain items.  In certain jurisdictions, our tax rate is significantly less than the applicable statutory rate as a result of tax holidays.  The majority of our foreign income that is subject to these tax holidays and lower tax rates is attributable to Singapore, China, and Malaysia.  A significant portion of these income tax benefits relates to a tax holiday that will be effective until January 31, 2029.  Our other tax holidays will expire in whole or in part during Fiscal 2022 through Fiscal 2030.  Many of these tax holidays and reduced tax rates may be extended when certain conditions are met or may be terminated early if certain conditions are not met.

[0001571996-19-000025:mdna:121]
For further discussion regarding tax matters, including the status of income tax audits, see Note 11 of the Notes to the Condensed Consolidated Financial Statements included in this report.

[0001571996-19-000025:mdna:122]
[same as prior period, unchanged from 0001571996-18-000044:mdna:133]

[0001571996-19-000025:mdna:123]
During the first quarter of Fiscal 2020, net income increased 161% to $329 million.  The increase in net income during the first quarter of Fiscal 2020 was primarily attributable to an increase in operating income and, to a lesser extent, an increase in tax benefit, which was partially offset by an increase in interest and other, net expense.

[0001571996-19-000025:mdna:124]
Net income for the first quarter of Fiscal 2020 included amortization of intangible assets, the impact of purchase accounting, transaction-related expenses, stock-based compensation expense, other corporate expenses, fair value adjustments on equity investments, and discrete tax items.  Excluding these costs and the related tax impacts, non-GAAP net income increased 3% to $1.2 billion during the first quarter of Fiscal 2020.  The increase in non-GAAP net income during the first quarter of Fiscal 2020 was primarily attributable to an increase in operating income, which was partially offset by an increase in interest and other, net expense.

[0001571996-19-000025:mdna:125]
[same as prior period, unchanged from 0001571996-18-000044:mdna:136]

[0001571996-19-000025:mdna:126]
During the first quarter of Fiscal 2020, net income attributable to non-controlling interests was $36 million, compared to net income attributable to non-controlling interests of $98 million during the first quarter of Fiscal 2019.  Net income or loss attributable to non-controlling interests consisted of net income or loss attributable to our non-controlling interests in VMware, Inc., Pivotal, and Secureworks.  For more information about our non-controlling interests, see Note 13 of the Notes to the Condensed Consolidated Financial Statements included in this report.

[0001571996-19-000025:mdna:127]
Net Income (Loss) Attributable to Dell Technologies Inc.

[0001571996-19-000025:mdna:128]
Net income (loss) attributable to Dell Technologies Inc. represents net income (loss) and an adjustment for non-controlling interests.  During the first quarter of Fiscal 2020 and Fiscal 2019, net income attributable to Dell Technologies Inc. was $293 million and net loss attributable to Dell Technologies Inc. was $636 million, respectively.  The increase in net income attributable to Dell Technologies Inc. during the first quarter of Fiscal 2020 was primarily attributable to an increase in net income for the period.

[0001571996-19-000025:mdna:129]
[same as prior period, unchanged from 0001571996-18-000044:mdna:140]

[0001571996-19-000025:mdna:130]
[same as prior period, unchanged from 0001571996-18-000044:mdna:141]

[0001571996-19-000025:mdna:131]
Infrastructure Solutions Group

[0001571996-19-000025:mdna:132]
[same as prior period, unchanged from 0001571996-18-000044:mdna:144]

[0001571996-19-000025:mdna:133]
|  | Three Months Ended |
|  | May 3, 2019 |  | % Change |  | May 4, 2018 |
|  | (in millions, except percentages) |
| Net revenue: |  |  |  |  |  |
| Servers and networking | $ | 4,180 |  |  | (9)% |  | $ | 4,585 |  |
| Storage | 4,022 |  |  | (1)% |  | 4,082 |  |
| Total ISG net revenue | $ | 8,202 |  |  | (5)% |  | $ | 8,667 |  |
| Operating income: |  |  |  |  |  |
| ISG operating income | $ | 843 |  |  | (10)% |  | $ | 939 |  |
| % of segment net revenue | 10.3 | % |  |  |  | 10.8 | % |

[0001571996-19-000025:mdna:134]
Net Revenue — During the first quarter of Fiscal 2020, ISG net revenue decreased 5% primarily due to a decrease in sales of servers and networking.  Revenue from servers and networking decreased 9% the first quarter of Fiscal 2020, driven by a decline in units sold of our PowerEdge servers due to a weaker demand environment.  Certain competitive dynamics also contributed to lower server volumes during the quarter, as we focused on profitability above net revenue growth.  The impact of the lower volume of PowerEdge sales was partially mitigated by an increase in average selling prices due to the sale of servers with more robust compute capacity and higher memory and storage content, which was driven by customer demand for servers that enable big data analytics.  Storage revenue remained relatively flat during the first quarter of Fiscal 2020 compared to the strong performance in the first quarter of Fiscal 2019.  We continue to make go-to-market investments and enhancements to our storage solutions offerings and expect that these investments will drive long-term improvements in the business.  Component costs were deflationary in the aggregate for ISG during the first quarter of Fiscal 2020, and we continue to monitor our pricing in response to changes in the component cost environment.  We expect the aggregate ISG component cost environment to continue to be deflationary in the near term.

[0001571996-19-000025:mdna:135]
[same as prior period, unchanged from 0001571996-18-000044:mdna:147]

[0001571996-19-000025:mdna:136]
From a geographical perspective, net revenue attributable to ISG increased in EMEA, decreased slightly in the Americas, and decreased in APJ during the first quarter of Fiscal 2020.

[0001571996-19-000025:mdna:137]
Operating Income — During the first quarter of Fiscal 2020, ISG operating income as a percentage of net revenue decreased 50 basis points to 10.3% primarily due to an increase in operating expenses as a percentage of net revenue, partially offset by an increase in ISG gross margin percentage.  Our continued investments in go-to-market capabilities and solutions offerings outpaced revenue growth, and, as a result, operating expenses increased as a percentage of net revenue.  ISG gross margin percentage improved due to higher average selling prices and the deflationary cost environment as referred to above.

[0001571996-19-000025:mdna:138]
Client Solutions Group

[0001571996-19-000025:mdna:139]
[same as prior period, unchanged from 0001571996-18-000044:mdna:152]

[0001571996-19-000025:mdna:140]
|  | Three Months Ended |
|  | May 3, 2019 |  | % Change |  | May 4, 2018 |
|  | (in millions, except percentages) |
| Net revenue: |  |  |  |  |  |
| Commercial | $ | 8,307 |  |  | 13% |  | $ | 7,363 |  |
| Consumer | 2,603 |  |  | (10)% |  | 2,908 |  |
| Total CSG net revenue | $ | 10,910 |  |  | 6% |  | $ | 10,271 |  |
| Operating income: |  |  |  |  |  |
| CSG operating income | $ | 793 |  |  | 49% |  | $ | 533 |  |
| % of segment net revenue | 7.3 | % |  |  |  | 5.2 | % |

[0001571996-19-000025:mdna:141]
Net Revenue — During the first quarter of Fiscal 2020, CSG net revenue increased 6% due to continued strong demand for our commercial products across all product categories.  Consumer revenue decreased 10% due to lower demand for notebooks, which was partially offset by higher average selling prices as we experienced a shift in product mix to higher-priced consumer notebooks.  The aggregate CSG component cost environment was deflationary in the first quarter of Fiscal 2020, and we expect deflationary conditions to continue in the near term.

[0001571996-19-000025:mdna:142]
From a geographical perspective, net revenue attributable to CSG increased across all regions during the first quarter of Fiscal 2020.

[0001571996-19-000025:mdna:143]
Operating Income — During the first quarter of Fiscal 2020, CSG operating income as a percentage of net revenue increased 210 basis points to 7.3%.  The increase was primarily due to lower component costs that positively impacted CSG gross margin and a shift in product mix to higher margin product offerings.

[0001571996-19-000025:mdna:144]
VMware

[0001571996-19-000025:mdna:145]
The following table presents net revenue and operating income attributable to VMware for the respective periods:

[0001571996-19-000025:mdna:146]
|  | Three Months Ended |
|  | May 3, 2019 |  | % Change |  | May 4, 2018 |
|  | (in millions, except percentages) |
| Net revenue: |  |  |  |  |  |
| VMware net revenue | $ | 2,282 |  |  | 13% |  | $ | 2,028 |  |
| Operating income: |  |  |  |  |  |
| VMware operating income | $ | 614 |  |  | —% |  | $ | 613 |  |
| % of segment net revenue | 26.9 | % |  |  |  | 30.2 | % |

[0001571996-19-000025:mdna:147]
Net Revenue — VMware net revenue primarily consists of revenue from the sale of software licenses under perpetual licenses, related software maintenance and support, training, consulting services, and hosted services.  VMware net revenue during the first quarter of Fiscal 2020 increased 13% primarily due to growth in software license revenue and sales of software maintenance services.  Software license revenue reflected broad-based growth across the product portfolio.  Software maintenance revenue benefited from strong renewals, revenue recognized from maintenance contracts sold in prior periods, and new maintenance contracts sold during the period.

[0001571996-19-000025:mdna:148]
From a geographical perspective, approximately half of VMware net revenue during the first quarter of Fiscal 2020 was generated by sales to customers in the United States.  VMware net revenue for the first quarter of Fiscal 2020 was positively affected by growth across U.S. and international markets.

[0001571996-19-000025:mdna:149]
Operating Income — During the first quarter of Fiscal 2020, VMware operating income as a percentage of net revenue decreased 330 basis points to 26.9%.  The decrease was driven by an increase in operating expenses as a percentage of net revenue due to an increase in compensation-related expense associated with sales and sales support, primarily due to increased headcount, as well as to an increase in R&D expenses.

[0001571996-19-000025:mdna:150]
[same as prior period, unchanged from 0001571996-18-000044:mdna:105]

[0001571996-19-000025:mdna:151]
[same as prior period, unchanged from 0001571996-18-000044:mdna:167]

[0001571996-19-000025:mdna:152]
[same as prior period, unchanged from 0001571996-18-000044:mdna:168]

[0001571996-19-000025:mdna:153]
We sell products and services directly to customers and through a variety of sales channels, including retail distribution.  Our accounts receivable, net, was $10.5 billion and $12.4 billion as of May 3, 2019 and February 1, 2019, respectively.  We maintain an allowance for doubtful accounts to cover receivables that may be deemed uncollectible.  The allowance for losses is based on a provision for accounts that are collectively evaluated based on historical bad debt experience as well as specific identifiable customer accounts that are deemed at risk.  As of May 3, 2019 and February 1, 2019, the allowance for doubtful accounts was $79 million and $85 million, respectively.  Based on our assessment, we believe that we are adequately reserved for expected credit losses.  We monitor the aging of our accounts receivable and continue to take actions to reduce our exposure to credit losses.

[0001571996-19-000025:mdna:154]
Dell Financial Services

[0001571996-19-000025:mdna:155]
Dell Financial Services and its affiliates (“DFS”) support Dell Technologies by offering and arranging various financing options and services for our customers globally, including through captive financing operations in North America, Europe, Australia, and New Zealand.  DFS originates, collects, and services customer receivables primarily related to the purchase of our product, software, and service solutions.  DFS further strengthens our customer relationships through its flexible consumption models, which enable us to offer our customers the option to pay over time and, in certain cases, based on utilization, to provide them with financial flexibility to meet their changing technological requirements.  New financing originations were $1.7 billion for both the three months ended May 3, 2019 and May 4, 2018.

[0001571996-19-000025:mdna:156]
As of February 2, 2019, we adopted the new lease standard discussed in Note 1 and Note 2 of the Notes to the Condensed Consolidated Financial Statements included in this report.  The adoption of the new lease standard did not result in a change to leases that commenced prior to adoption.  For new leases that commenced subsequent to the adoption of the new lease standard, DFS accounts for the leases as sales-type leases, direct financing leases, or operating leases depending on lease classification guidance.  Amounts due from lessees under sales-type leases or direct financing leases are recorded as part of financing receivables, with interest income recognized over the contract term.  On commencement of sales-type leases, we typically qualify for up front revenue recognition.  On originations of operating leases, we record equipment under operating leases, classified as property, plant, and equipment, and recognize rental revenue and depreciation expense, classified as cost of net revenue, over the contract term.  Direct financing leases under the new lease standard are immaterial.

[0001571996-19-000025:mdna:157]
As of May 3, 2019 and February 1, 2019, our financing receivables, net were $8.4 billion and $8.6 billion, respectively.  We maintain an allowance to cover expected financing receivable credit losses and evaluate credit loss expectations based on our total portfolio.  For the first quarter of Fiscal 2020 and Fiscal 2019, the principal charge-off rate for our total portfolio was 1.0% and 1.2%, respectively.  The credit quality of our financing receivables has improved in recent years due to an overall improvement in the credit environment and as the mix of high-quality commercial accounts in our portfolio has continued to increase.  We continue to monitor broader economic indicators and their potential impact on future loss performance.  We have an extensive process to manage our exposure to customer credit risk, including active management of credit lines and our collection activities.  We also sell selected fixed-term financing receivables to unrelated third parties on a periodic basis, primarily to manage certain concentrations of customer credit exposure.  Based on our assessment of the customer financing receivables, we believe that we are adequately reserved.

[0001571996-19-000025:mdna:158]
We retain a residual interest in equipment leased under our lease programs.  As of May 3, 2019 and February 1, 2019, the residual interest recorded as part of financing receivables was $661 million and $674 million, respectively.  The amount of the residual interest is established at the inception of the lease based upon estimates of the value of the equipment at the end of the lease term using historical studies, industry data, and future value-at-risk demand valuation methods.  On a quarterly basis, we assess the carrying amount of our recorded residual values for impairment.  Generally, residual value risk on equipment under lease is not considered to be significant, because of the existence of a secondary market with respect to the equipment.  The lease agreement also clearly defines applicable return conditions and remedies for non-compliance, to ensure that the leased equipment will be in good operating condition upon return.  Model changes and updates, as well as market strength and product acceptance, are monitored and adjustments are made to residual values in accordance with the significance of any such changes.  Our remarketing sales staff works closely with customers and dealers to manage the sale of lease returns and the recovery of residual exposure.  No impairment losses were recorded related to residual assets during the three months ended May 3, 2019.

[0001571996-19-000025:mdna:159]
As of May 3, 2019 and February 1, 2019, equipment under operating leases, net was $274 million and $3 million, respectively.  The increase in equipment under operating leases, net is due to our adoption of the new lease standard and the elimination of the third-party residual value guarantee insurance in the lease classification test for sales-type leases.  Based on triggering events, we assess the carrying amount of the equipment under operating leases recorded for impairment.  No impairment losses were recorded related to such equipment during the three months ended May 3, 2019.

[0001571996-19-000025:mdna:160]
DFS offerings are initially funded through cash on hand at the time of origination, most of which is subsequently replaced with third-party financing.  As a result, while the initial funding of financing receivables is reflected as an impact to cash flows from operations, this funding is largely subsequently offset by cash flows from financing.  Additionally, as a result of our adoption of the new leasing standard on lessor accounting, the increase to future originations of operating leases results in a shift from financing receivables to capital expenditures, which benefits our cash flows provided by operating activities by the increase in capital expenditures being reported as cash flows used in investing activities.

[0001571996-19-000025:mdna:161]
See Note 4 of the Notes to the Condensed Consolidated Financial Statements included in this report for additional information about our financing receivables and the equipment under operating leases.

[0001571996-19-000025:mdna:162]
[same as prior period, unchanged from 0001571996-18-000044:mdna:175]

[0001571996-19-000025:mdna:163]
As of May 3, 2019, we had no off-balance sheet arrangements that have or are reasonably likely to have a current or future material effect on our financial condition or results of operations.

[0001571996-19-000025:mdna:164]
80

[0001571996-19-000025:mdna:165]
[same as prior period, unchanged from 0001571996-18-000044:mdna:178]

[0001571996-19-000025:mdna:166]
[same as prior period, unchanged from 0001571996-18-000044:mdna:179]

[0001571996-19-000025:mdna:167]
[same as prior period, unchanged from 0001571996-18-000044:mdna:180]

[0001571996-19-000025:mdna:168]
We monitor credit risk associated with our financial counterparties using various market credit risk indicators such as credit ratings issued by nationally recognized credit rating agencies and changes in market credit default swap levels.  We perform periodic evaluations of our positions with these counterparties and may limit exposure to any one counterparty in accordance with our policies.  We monitor and manage these activities depending on current and expected market developments.

[0001571996-19-000025:mdna:169]
[same as prior period, unchanged from 0001571996-18-000044:mdna:182]

[0001571996-19-000025:mdna:170]
[same as prior period, unchanged from 0001571996-18-000044:mdna:183]

[0001571996-19-000025:mdna:171]
[same as prior period, unchanged from 0001571996-18-000044:mdna:184]

[0001571996-19-000025:mdna:172]
[same as prior period, unchanged from 0001571996-18-000044:mdna:185]

[0001571996-19-000025:mdna:173]
To support our ongoing business operations, we rely on operating cash flows as our primary source of liquidity.  We monitor the efficiency of our balance sheet to ensure that we have adequate liquidity to support our strategic initiatives.  In addition to internally generated cash, we have access to other capital sources to finance our strategic initiatives and fund growth in our financing operations.  As of May 3, 2019, we had $9.0 billion of total cash and cash equivalents.  Our strategy is to deploy capital from any potential source, whether internally generated cash or debt, depending on the adequacy and availability of that source of capital and whether it can be accessed in a cost-effective manner.

[0001571996-19-000025:mdna:174]
A significant portion of our income is earned in non-U.S. jurisdictions.  Prior to the enactment of U.S. Tax Reform as discussed above in “Results of Operations — Income and Other Taxes,” earnings available to be repatriated to the United States would be subject to U.S. federal income tax, less applicable foreign tax credits.  U.S. Tax Reform fundamentally changes the U.S. approach to taxation of foreign earnings to a modified territorial tax system, which generally allows companies to make distributions of non-U.S. earnings to the United States without incurring additional U.S. federal tax.  However, local and U.S. state taxes may still apply.  We have provided for future tax liabilities on income earned in non-U.S. jurisdictions, except for foreign earnings that are considered indefinitely reinvested outside of the United States.

[0001571996-19-000025:mdna:175]
During the fourth quarter of Fiscal 2019, as discussed above in “Introduction — Class V Transaction,” we completed a transaction in which all issued and outstanding shares of our Class V Common Stock were exchanged for cash or shares of Class C Common Stock at the stockholder’s election.  We paid a total of $14 billion of cash to holders of Class V Common Stock.

[0001571996-19-000025:mdna:176]
To fund a majority of the cash payment to stockholders, VMware, Inc. declared a conditional $11 billion one-time special cash dividend (the “Special Dividend”), which was paid pro-rata to VMware, Inc. stockholders as of the dividend record date of December 27, 2018 and in connection with the completion of the Class V transaction.  Our cash, cash equivalents, and investments declined significantly, commensurate with the cash required to fund this transaction.  VMware, Inc. has advised us that, following its payment of the Special Dividend, VMware, Inc. will remain committed to a balanced capital allocation policy through investment in its product and solutions offerings, acquisitions, and returning capital to its stockholders through share repurchases.  During the three months ended May 3, 2019,  VMware, Inc. repurchased 3.3 million shares of its Class A common stock in the open market for approximately $591 million.  During the three months ended May 4, 2018, VMware, Inc. did not repurchase any shares of its Class A common stock.

[0001571996-19-000025:mdna:177]
We funded a majority of the cash consideration paid in the Class V transaction from the $8.87 billion of the proceeds of the Special Dividend.  The remaining amount of the cash consideration was primarily funded with $3.67 billion of proceeds from new senior secured term loans under our senior secured credit facilities and proceeds of a margin loan financing in an aggregate principal amount of $1.35 billion.  See Note 6 of the Notes to the Condensed Consolidated Financial Statements included in this report for information about the debt we incurred to finance the Class V transaction.

[0001571996-19-000025:mdna:178]
The following table summarizes our cash and cash equivalents as well as our available borrowings as of May 3, 2019 and February 1, 2019:

[0001571996-19-000025:mdna:179]
|  | May 3, 2019 |  | February 1, 2019 |
|  | (in millions) |
| Cash and cash equivalents, and available borrowings: |  |  |  |
| Cash and cash equivalents (a) | $ | 9,040 |  |  | $ | 9,676 |  |
| Remaining available borrowings under revolving credit facilities | 6,086 |  |  | 5,586 |  |
| Total cash, cash equivalents, and available borrowings | $ | 15,126 |  |  | $ | 15,262 |  |

[0001571996-19-000025:mdna:180]
____________________

[0001571996-19-000025:mdna:181]
| (a) | Of the $9.0 billion of cash and cash equivalents as of May 3, 2019, $3.3 billion was held by VMware, Inc. |

[0001571996-19-000025:mdna:182]
Our revolving credit facilities include the Revolving Credit Facility and the China Revolving Credit Facility, which we renewed during the first quarter of Fiscal 2020.  The Revolving Credit Facility and the China Revolving Credit Facility have maximum aggregate borrowings of $4.5 billion and $0.5 billion, respectively.  Available borrowings under these facilities are reduced by draws on the facility and, under the Revolving Credit Facility, outstanding letters of credit.  As of May 3, 2019, there were no borrowings outstanding under the facilities and remaining available borrowings totaled approximately $5.0 billion.  We may regularly use our available borrowings from both our Revolving Credit Facility and our China Revolving Credit Facility on a short-term basis for general corporate purposes.

[0001571996-19-000025:mdna:183]
The VMware Revolving Credit Facility and the Pivotal Revolving Credit Facility have maximum aggregate borrowings of $1.0 billion and $100 million, respectively.  None of the net proceeds of such borrowings will be made available to support the operations or satisfy any corporate purposes of Dell Technologies, other than the operations and corporate purposes of VMware, Inc., Pivotal, and their respective subsidiaries under the applicable facility.  As of May 3, 2019, $1.0 billion was available under the VMware Revolving Credit Facility and $100 million was available under the Pivotal Revolving Credit Facility.

[0001571996-19-000025:mdna:184]
[same as prior period, unchanged from 0001571996-18-000044:mdna:197]

[0001571996-19-000025:mdna:185]
We believe that our current cash and cash equivalents, together with cash that will be provided by future operations and expected borrowings under our revolving credit facilities, will be sufficient over at least the next twelve months to fund our operations, debt service requirements and maturities, capital expenditures, share repurchases, and other corporate needs.

[0001571996-19-000025:mdna:186]
82

[0001571996-19-000025:mdna:187]
[same as prior period, unchanged from 0001571996-18-000044:mdna:200]

[0001571996-19-000025:mdna:188]
The following table summarizes our outstanding debt as of May 3, 2019 and February 1, 2019:

[0001571996-19-000025:mdna:189]
|  | May 3, 2019 |  | February 1, 2019 |
|  | (in millions) |
| Restricted Subsidiary Debt |  |  |  |
| Core debt: |  |  |  |
| Senior Secured Credit Facilities and First Lien Notes | $ | 31,665 |  |  | $ | 32,720 |  |
| Unsecured Notes and Debentures | 1,952 |  |  | 1,952 |  |
| Senior Notes | 3,250 |  |  | 3,250 |  |
| EMC Notes | 3,000 |  |  | 3,000 |  |
| DFS allocated debt | (1,263 | ) |  | (1,615 | ) |
| Total core debt | 38,604 |  |  | 39,307 |  |
| DFS related debt: |  |  |  |
| DFS debt | 6,343 |  |  | 5,929 |  |
| DFS allocated debt | 1,263 |  |  | 1,615 |  |
| Total DFS related debt | 7,606 |  |  | 7,544 |  |
| Margin Loan and Other | 4,027 |  |  | 3,388 |  |
| Unrestricted Subsidiary Debt |  |  |  |
| VMware Notes | 4,000 |  |  | 4,000 |  |
| Other | — |  |  | — |  |
| Total unrestricted subsidiary debt | 4,000 |  |  | 4,000 |  |
| Total debt, principal amount | 54,237 |  |  | 54,239 |  |
| Carrying value adjustments | (713 | ) |  | (718 | ) |
| Total debt, carrying value | $ | 53,524 |  |  | $ | 53,521 |  |

[0001571996-19-000025:mdna:190]
The outstanding principal amount of our debt was $54.2 billion as of May 3, 2019, which included core debt of $38.6 billion.  We define core debt as the total principal amount of our debt, less DFS related debt, our margin loan and other debt, and unrestricted subsidiary debt.

[0001571996-19-000025:mdna:191]
DFS related debt primarily represents debt from our securitization and structured financing programs.  To fund expansion of the DFS business, we balance the use of the securitization and structured financing programs with other sources of liquidity.  We approximate the amount of our debt used to fund the DFS business by applying a 7:1 debt to equity ratio to the sum of our financing receivables balance and the future maturities of our DFS operating lease assets, based on the underlying credit quality of the assets.  See Note 4 of the Notes to the Condensed Consolidated Financial Statements included in this report for more information about our DFS debt.

[0001571996-19-000025:mdna:192]
As of May 3, 2019, margin loan and other debt primarily consisted of the $4.0 billion Margin Loan Facility.

[0001571996-19-000025:mdna:193]
[same as prior period, unchanged from 0001571996-18-000044:mdna:206]

[0001571996-19-000025:mdna:194]
83

[0001571996-19-000025:mdna:195]
Our requirements for cash to pay principal and interest on our debt increased significantly due to the borrowings we incurred to finance the EMC merger transaction, and to a lesser extent, the Class V transaction.  We have made good progress in paying down core debt since the EMC merger transaction.  We believe we will continue to be able to make our debt principal and interest payments, including the short-term maturities, from existing and expected sources of cash.  Cash used for debt principal and interest payments may include short-term borrowings under our revolving credit facilities.  We will continue to focus on paying down core debt.  We expect that continued demand for customer financing as well as an increase in LIBOR will impact future interest expense on our variable-rate debt.  We or our affiliates or their related persons, at our or their sole discretion, may purchase, redeem, prepay, refinance, or otherwise retire any amount of our outstanding indebtedness under the terms of such indebtedness at any time and from time to time, in open market or negotiated transactions with the holders of such indebtedness or otherwise, as appropriate market conditions exist.

[0001571996-19-000025:mdna:196]
During the first quarter of Fiscal 2020, we incurred new long-term debt to complete two refinancing transactions.  We issued multiple series of First Lien Notes (the “new First Lien Notes”) totaling approximately $4.5 billion and increased the aggregate principal amount of borrowings under our Margin Loan Facility by $650 million.  In addition, we amended the credit agreement for our senior secured credit facilities to obtain a new senior secured Term Loan A-6 Facility consisting of $3,634 million, of which $2,839 million aggregate principal amount consisted of amounts outstanding that rolled over from our Term Loan A-2 Facility.  Immediately after the rollover, $1,277 million aggregate principal amount of Term Loan A-2 Facility remained outstanding.

[0001571996-19-000025:mdna:197]
The proceeds from the new First Lien Notes were used to repay all of our outstanding $3,750 million First Lien Notes due June 2019.  In addition, proceeds of approximately $800 million of borrowings under our Term Loan A-6 Facility, the proceeds of the $650 million increase in the Margin Loan Facility, and a portion of the proceeds from the new First Lien Notes were used to repay all of our outstanding amounts under the Term Loan A-5 Facility due December 2019.  The remaining proceeds available from our new First Lien Notes were used to repay outstanding amounts under our Term Loan A-2 Facility and to pay related premiums, accrued interest, fees, and expenses.  This refinancing enabled us to smooth out our upcoming maturity profile while maintaining an efficient cost of capital and minimizing our borrowings under our revolving credit facilities.

[0001571996-19-000025:mdna:198]
In addition, we repaid $400 million of our Term Loan A-2 Facility and approximately $33 million of principal amortization under our term loan facilities during the first quarter of Fiscal 2020.

[0001571996-19-000025:mdna:199]
[same as prior period, unchanged from 0001571996-18-000044:mdna:209]

[0001571996-19-000025:mdna:200]
[same as prior period, unchanged from 0001571996-18-000044:mdna:211]

[0001571996-19-000025:mdna:201]
[same as prior period, unchanged from 0001571996-18-000044:mdna:212]

[0001571996-19-000025:mdna:202]
|  | Three Months Ended |
|  | May 3, 2019 |  | May 4, 2018 |
|  | (in millions) |
| Net change in cash from: |  |  |  |
| Operating activities | $ | 682 |  |  | $ | 1,159 |  |
| Investing activities | (458 | ) |  | (149 | ) |
| Financing activities | (719 | ) |  | 543 |  |
| Effect of exchange rate changes on cash and cash equivalents | (36 | ) |  | (86 | ) |
| Change in cash and cash equivalents | $ | (531 | ) |  | $ | 1,467 |  |

[0001571996-19-000025:mdna:203]
Operating Activities — Cash provided by operating activities was $682 million for the first quarter of Fiscal 2020 compared to $1,159 million for the first quarter of Fiscal 2019.  The decrease in operating cash flows during the first quarter of Fiscal 2020 was attributable to increased compensation and benefit payments as a result of higher seasonal personnel payments, partially offset by improved profitability.

[0001571996-19-000025:mdna:204]
[same as prior period, unchanged from 0001571996-18-000044:mdna:158]

[0001571996-19-000025:mdna:205]
DFS offerings are initially funded through cash on hand at the time of origination, most of which is subsequently replaced with third-party financing.  As a result, while the initial funding of financing receivables is reflected as an impact to cash flows from operations, this funding impact is largely subsequently offset by cash flows from financing.  Additionally, as a result of our adoption of the new leasing standard on lessor accounting in the first quarter of Fiscal 2020, the increase to future originations of operating leases results in a shift from financing receivables to capital expenditures, which benefits our cash flows provided by operating activities by the increase in capital expenditures being reported as cash flows used in investing activities.  DFS new financing originations were $1.7 billion during both the first quarter of Fiscal 2020 and Fiscal 2019.  As of May 3, 2019, DFS had $8.4 billion of total net financing receivables and $274 million of equipment under DFS operating leases, net.

[0001571996-19-000025:mdna:206]
Investing Activities — Investing activities primarily consist of cash used to fund capital expenditures for property, plant, and equipment, which includes equipment under DFS operating leases, capitalized software development costs, strategic investments, and the maturities, sales, and purchases of investments.  During the first quarter of Fiscal 2020, cash used in investing activities was $458 million and was primarily driven by capital expenditures, which were partially offset by net cash proceeds from the net sales of strategic investments.  In comparison, cash used by investing activities was $149 million during the first quarter of Fiscal 2019 and was primarily driven by capital expenditures, partially offset by net cash proceeds from the divestitures of businesses and by the net sales of investments.

[0001571996-19-000025:mdna:207]
Financing Activities — Financing activities primarily consist of the proceeds and repayments of debt, cash used to repurchase common stock, and proceeds from the issuance of common stock of subsidiaries.  Cash used by financing activities of $719 million during the first quarter of Fiscal 2020 primarily consisted of repurchases of common stock by our public subsidiaries.  In comparison, cash provided by financing activities of $543 million during the first quarter of Fiscal 2019 was primarily driven by proceeds from the issuance of Pivotal common stock in connection with Pivotal’s IPO.

[0001571996-19-000025:mdna:208]
[same as prior period, unchanged from 0001571996-18-000044:mdna:219]

[0001571996-19-000025:mdna:209]
Capital Expenditures — During the first quarter of Fiscal 2020, we spent $610 million on property, plant, and equipment, which included equipment under DFS operating leases of $274 million.  During the first quarter of Fiscal 2019, we spent $273 million on property, plant, and equipment.  These expenditures were incurred in connection with our global expansion efforts and infrastructure investments made to support future growth, and, in Fiscal 2020, the funding of equipment under DFS operating leases.  Product demand, product mix, and the use of contract manufacturers, as well as ongoing investments in operating and information technology infrastructure, influence the level and prioritization of our capital expenditures.  Aggregate capital expenditures for Fiscal 2020, which will involve infrastructure investments, strategic initiatives, and funding our DFS leasing operations, are currently expected to total between $2.7 billion and $2.9 billion, of which $1.5 billion relates to the property, plant, and equipment recognized under the new leasing standard adopted in the first quarter of Fiscal 2020.

[0001571996-19-000025:mdna:210]
[same as prior period, unchanged from 0001571996-18-000044:mdna:221]

[0001571996-19-000025:mdna:211]
[same as prior period, unchanged from 0001571996-18-000044:mdna:222]
