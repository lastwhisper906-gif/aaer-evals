# DELL notes — 0001571996-19-000025


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0001571996-19-000025:notes:1]
Basis of Presentation — The accompanying unaudited Condensed Consolidated Financial Statements should be read in conjunction with the audited Consolidated Financial Statements and accompanying Notes filed with the U.S. Securities and Exchange Commission (“SEC”) in the Company's Annual Report on Form 10-K for the fiscal year ended February 1, 2019.  These Condensed Consolidated Financial Statements have been prepared in accordance with accounting principles generally accepted in the United States of America (“GAAP”).  In the opinion of management, the accompanying Condensed Consolidated Financial Statements reflect all adjustments of a normal recurring nature considered necessary to fairly state the financial position of Dell Technologies Inc. as of May 3, 2019 and February 1, 2019, the results of its operations and corresponding comprehensive income (loss) for the three months ended May 3, 2019 and May 4, 2018, and its cash flows for the three months ended May 3, 2019 and May 4, 2018.


## us-gaap:ConsolidationPolicyTextBlock

[0001571996-19-000025:notes:2]
Principles of Consolidation — These Condensed Consolidated Financial Statements include the accounts of Dell Technologies and its wholly-owned subsidiaries, as well as the accounts of VMware, Inc., Pivotal Software, Inc. (“Pivotal”), and SecureWorks Corp. (“Secureworks”), each of which is majority-owned by Dell Technologies.  All intercompany transactions have been eliminated.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001571996-19-000025:notes:3]
Recently Issued Accounting Pronouncements

[0001571996-19-000025:notes:4]
Measurement of Credit Losses on Financial Instruments — In June 2016, the Financial Accounting Standards Board (“FASB”) issued amended guidance which replaces the current incurred loss impairment methodology for measurement of credit losses on financial instruments with a methodology that reflects expected credit losses and requires consideration of a broader range of reasonable and supportable information to inform credit loss estimates.  Public entities must adopt the new guidance for fiscal years beginning after December 15, 2019, and interim periods within those fiscal years, with early adoption permitted for fiscal periods beginning after December 15, 2018.  The Company is currently evaluating the impact that the standard will have on the Condensed Consolidated Financial Statements.

[0001571996-19-000025:notes:5]
Intangibles - Goodwill and Other - Internal-Use Software — In August 2018, the FASB issued guidance on a customer’s accounting for implementation costs incurred in a cloud-computing arrangement when hosted by a vendor.  In a hosting arrangement that is a service contract, certain implementation costs should be capitalized and amortized over the term of the arrangement.  Public entities must adopt the new guidance for fiscal years beginning after December 15, 2019, and interim periods within those fiscal years, with early adoption permitted for fiscal periods beginning after December 15, 2018.  The Company does not expect the adoption of this guidance to have a material impact on the Condensed Consolidated Financial Statements.

[0001571996-19-000025:notes:6]
Recently Adopted Accounting Pronouncements

[0001571996-19-000025:notes:7]
Leases — In February 2016, the FASB issued amended guidance on the accounting for leasing transactions.  The primary objective of this update is to increase transparency and comparability among organizations by requiring lessees to recognize a lease liability for the obligation to make lease payments and a right-of-use (“ROU”) asset for the right to use the underlying asset for the lease term.  The guidance also results in some changes to lessor accounting and requires additional disclosures about all leasing arrangements.

[0001571996-19-000025:notes:8]
The Company adopted the standard (the “new lease standard”) as of February 2, 2019 using a modified retrospective approach, with the cumulative-effect adjustment to the opening balance of stockholders’ equity (deficit) as of the adoption date.  The Company elected to apply the practical expedient using the transition option whereby prior comparative periods were not retrospectively adjusted in the Consolidated Financial Statements.  Accordingly, prior comparative periods have not been adjusted in the Condensed Consolidated Financial Statements.  The Company also elected the package of practical expedients which does not require reassessment of initial direct costs, classification of a lease, and definition of a lease.

[0001571996-19-000025:notes:9]
The adoption of the new lease standard resulted in the recognition of $1.6 billion in operating lease liabilities and related ROU assets on the Consolidated Statements of Financial Position.  The Company recorded an immaterial adjustment to stockholders’ equity (deficit) as of February 2, 2019 to reflect the cumulative effect of adoption of the new lease standard.  As of February 2, 2019, there were no material finance leases for which the Company was a lessee.

[0001571996-19-000025:notes:10]
In the area of lessor accounting, as of February 2, 2019, the Company began to originate operating leases due to the elimination of third-party residual value guarantee insurance from the sales-type lease classification test.  Leases that commenced prior to the adoption of the new lease standard were not reassessed or restated pursuant to the practical expedients elected.  Accordingly, there was no cumulative adjustment to stockholders’ equity (deficit) related to lessor accounting.

[0001571996-19-000025:notes:11]
See Note 4 and Note 5 of the Notes to the Condensed Consolidated Financial Statements for additional information about the Company’s leases from a lessor and lessee perspective, respectively.


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock

[0001571996-19-000025:notes:12]
NOTE 2 — INTERIM UPDATE TO SUMMARY OF SIGNIFICANT ACCOUNTING POLICIES

[0001571996-19-000025:notes:13]
As discussed in Note 1 of the Notes to the Condensed Consolidated Financial Statements, the Company adopted the new lease standard as of February 2, 2019, using the modified retrospective method.  A lease is defined as a contract that conveys the right to control the use of an identified asset for a period of time in exchange for consideration.  The Company enters into contracts that are, or contain, leases as both a lessee and a lessor.  The following accounting policies have been updated as part of the adoption of the new lease standard.

[0001571996-19-000025:notes:14]
Accounting for Operating Leases as a Lessee — In its ordinary course of business, the Company enters into leases as a lessee for office buildings, warehouses, employee vehicles, and equipment.  The Company determines if an arrangement is a lease or contains a lease at inception.  Operating leases result in the recognition of ROU assets and lease liabilities on the Consolidated Statements of Financial Position.  ROU assets represent the right to use an underlying asset for the lease term and lease liabilities represent the obligation to make lease payments arising from the lease, measured on a discounted basis.

[0001571996-19-000025:notes:15]
At lease inception, the lease liability is measured at the present value of the lease payments over the lease term.  The operating lease ROU asset equals the lease liability adjusted for any initial direct costs, prepaid or deferred rent, and lease incentives.

[0001571996-19-000025:notes:16]
The Company uses the implicit rate when readily determinable.  As most of the leases do not provide an implicit rate, the Company uses its incremental borrowing rate based on the information available at the commencement date to determine the present value of lease payments.  Incremental borrowing rates used to determine the present value of lease payments were derived in reference to the Company’s secured-debt yields corresponding to the lease commencement date.

[0001571996-19-000025:notes:17]
The lease term may include options to extend or to terminate the lease that the Company is reasonably certain to exercise.  Lease expense is recognized on a straight-line basis over the lease term in most instances.

[0001571996-19-000025:notes:18]
The Company has elected not to record leases with an initial term of 12 months or less on the Consolidated Statements of Financial Position.  Lease expense on such leases is recognized on a straight-line basis over the lease term.  The Company does not generate material sublease income and has no material related party leases.  The Company’s lease agreements do not contain any material residual value guarantees or material restrictive covenants.

[0001571996-19-000025:notes:19]
The Company’s office building agreements contain costs such as common area maintenance and other executory costs that are variable in nature.  Variable lease costs are expensed as incurred.  The Company combines lease and non-lease components, such as common area and other maintenance costs, in calculating the ROU assets and lease liabilities for its office buildings and employee vehicles.  Under certain service agreements with third-party logistic providers, the Company directs the use of the inventory within the warehouses and, therefore, controls the assets.  The warehouses and some of the equipment used are considered embedded leases.  The Company accounts for the lease and non-lease components separately.  The lease components consist of the warehouses and some of the equipment, such as conveyor belts.  The non-lease components consist of services and other shared equipment, such as material handling and transportation.  The Company allocates the consideration to the lease and non-lease components using their relative standalone values.  See Note 5 of the Notes to the Condensed Consolidated Financial Statements for additional information.

[0001571996-19-000025:notes:20]
Accounting for Leases as a Lessor — The Company’s wholly-owned subsidiary, Dell Financial Services and its affiliates (“DFS”), acts as a lessor to provide equipment financing to customers through a variety of lease arrangements (“DFS leases”).  Subsequent to the adoption of the new lease standard, new DFS leases are classified as sales-type leases, direct financing leases, or operating leases.  Direct financing leases under the new lease standard are immaterial.  Leases that commenced prior to the adoption of the new lease standard were not reassessed or restated pursuant to the practical expedients elected and will continue to be accounted for under previous lease accounting guidance.

[0001571996-19-000025:notes:21]
When a contract includes lease and non-lease components, DFS allocates consideration under the contract to each component based on relative standalone selling price.  Whenever the terms of the lease transfer control to the lessee, the contract is typically classified as a sales-type lease.  Through these arrangements, the lessee has the right to substantially all of the economic benefits from use of the identified asset and has the right to direct the use of such asset during the period of use.  In many arrangements, the lessee also retains ownership at the end of the lease term.  On commencement of sales-type leases, the Company recognizes profit up-front, and amounts due from the customer under the lease contract are recognized as financing receivables on the Consolidated Statement of Financial Position.  Interest income is recognized over the term of the lease based on the effective interest method as Net revenue.  For sales and other taxes collected from the lessee, the Company has elected not to include such taxes as part of lease revenue.

[0001571996-19-000025:notes:22]
All other leases which do not meet the definition of a sales-type lease or direct financing lease are classified as operating leases.  The underlying asset in an operating lease arrangement is carried at depreciated cost as “Equipment under operating leases” within Property, plant, and equipment, net on the Consolidated Statement of Financial Position.  Depreciation is calculated using the straight-line method over the term of the underlying lease contract and is recognized as Cost of net revenue.  The depreciable basis is the original cost of the equipment less the estimated residual value of the equipment at the end of the lease term.  The Company recognizes operating lease revenue on a straight-line basis over the lease term and expenses deferred initial direct costs on the same basis.  Impairment of equipment under operating leases is assessed on the same basis as other long-lived assets.

[0001571996-19-000025:notes:23]
DFS provides lessees with the option to extend the lease or purchase the underlying asset at the end of the lease term, which is considered when evaluating lease classification.  In general, DFS’s lease arrangements do not have variable payment terms and are non-cancelable.

[0001571996-19-000025:notes:24]
See Note 4 of the Notes to the Condensed Consolidated Financial Statements for more information regarding DFS leasing arrangements.

[0001571996-19-000025:notes:25]
Financing Receivables — Financing receivables are presented net of allowance for losses and consist of customer receivables and residual interest.  Customer receivables, gross includes amounts due from customers under revolving loans, fixed-term loans, fixed-term sales-type or direct financing leases, and accrued interest.  The Company has two portfolios: (1) fixed-term leases and loans and (2) revolving loans, and assesses risk at the portfolio level to determine the appropriate allowance levels.  The portfolio segments are further segregated into classes based on products, customer type, and credit risk evaluation: (1) Revolving - Dell Preferred Account (“DPA”); (2) Revolving - Dell Business Credit (“DBC”); and (3) Fixed-term - Consumer and Commercial.  Fixed-term leases and loans are offered to qualified small and medium-sized businesses, large commercial accounts, governmental organizations, and educational entities.  Additionally, fixed-term loans are also offered to certain individual consumer customers.  Revolving loans are offered under private label credit financing programs.  The DPA revolving loan programs are offered to individual consumer customers and the DBC revolving loan programs are offered to small and medium-sized business customers.

[0001571996-19-000025:notes:26]
The Company retains a residual interest in equipment leased under its fixed-term lease programs.  The amount of the residual interest is established at the inception of the lease based upon estimates of the value of the equipment at the end of the lease term using historical studies, industry data, and future value-at-risk demand valuation methods.  On a quarterly basis, the Company assesses the carrying amount of its recorded residual values for impairment.  Anticipated declines in specific future residual values that are considered to be other-than-temporary are recorded currently in earnings.  Generally, residual value risk on equipment under lease is not considered to be significant because of the existence of a secondary market with respect to the equipment.  The lease agreement also clearly defines applicable return conditions and remedies for non-compliance, to ensure that the leased equipment will be in good operating condition upon return.  Model changes and updates, as well as market strength and product acceptance, are monitored and adjustments are made to residual values in accordance with the significance of any such changes.  Remarketing sales staff works closely with customers and dealers to manage the sale of lease returns and the recovery of residual exposure.  As of May 3, 2019, the Company has not recorded significant residual value impairment.

[0001571996-19-000025:notes:27]
Asset Securitization — The Company transfers certain U.S. and European customer loan and lease payments and associated equipment to Special Purpose Entities (“SPEs”) that meet the definition of a Variable Interest Entity (“VIE”) and are consolidated into the Consolidated Financial Statements.  These SPEs are bankruptcy-remote legal entities with separate assets and liabilities.  The purpose of the SPEs is to facilitate the funding of customer lease and loan payments and associated equipment in the capital markets.  These SPEs have entered into financing arrangements with multi-seller conduits that, in turn, issue asset-backed debt securities in the capital markets.  The asset securitizations in the SPEs are accounted for as secured borrowings.  See Note 4 of the Notes to the Condensed Consolidated Financial Statements for additional information on the impact of the consolidation.


## us-gaap:FairValueDisclosuresTextBlock

[0001571996-19-000025:notes:28]
NOTE 3 — FAIR VALUE MEASUREMENTS AND INVESTMENTS

[0001571996-19-000025:notes:29]
The following table presents the Company’s hierarchy for its assets and liabilities measured at fair value on a recurring basis as of the dates indicated:

[0001571996-19-000025:notes:30]
|  | May 3, 2019 |  | February 1, 2019 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | QuotedPricesin ActiveMarkets forIdenticalAssets |  | SignificantOtherObservableInputs |  | SignificantUnobservableInputs |  |  |  | QuotedPricesin ActiveMarkets forIdenticalAssets |  | SignificantOtherObservableInputs |  | SignificantUnobservableInputs |  |  |
|  | (in millions) |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | $ | 5,167 |  |  | $ | — |  |  | $ | — |  |  | $ | 5,167 |  |  | $ | 5,221 |  |  | $ | — |  |  | $ | — |  |  | $ | 5,221 |  |
| Debt securities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Equity and other securities | 15 |  |  | 32 |  |  | — |  |  | 47 |  |  | 314 |  |  | 20 |  |  | — |  |  | 334 |  |
| Derivative instruments | — |  |  | 168 |  |  | — |  |  | 168 |  |  | — |  |  | 97 |  |  | — |  |  | 97 |  |
| Total assets | $ | 5,182 |  |  | $ | 200 |  |  | $ | — |  |  | $ | 5,382 |  |  | $ | 5,535 |  |  | $ | 117 |  |  | $ | — |  |  | $ | 5,652 |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Derivative instruments | $ | — |  |  | $ | 28 |  |  | $ | — |  |  | $ | 28 |  |  | $ | — |  |  | $ | 60 |  |  | $ | — |  |  | $ | 60 |  |
| Total liabilities | $ | — |  |  | $ | 28 |  |  | $ | — |  |  | $ | 28 |  |  | $ | — |  |  | $ | 60 |  |  | $ | — |  |  | $ | 60 |  |

[0001571996-19-000025:notes:31]
[same as prior period, unchanged from 0001571996-18-000044:notes:86]

[0001571996-19-000025:notes:32]
Money Market Funds — The Company’s investment in money market funds that are classified as cash equivalents hold underlying investments with a weighted average maturity of 90 days or less and are recognized at fair value.  The valuations of these securities are based on quoted prices in active markets for identical assets, when available, or pricing models whereby all significant inputs are observable or can be derived from or corroborated by observable market data.  The Company reviews security pricing and assesses liquidity on a quarterly basis.  As of May 3, 2019, the Company’s U.S. portfolio had no material exposure to money market funds with a fluctuating net asset value.

[0001571996-19-000025:notes:33]
Equity and Other Securities — The Company’s investments in equity and other securities that are measured at fair value on a recurring basis consist primarily of strategic investments in publicly-traded companies.  The valuation of these securities is based on quoted prices in active markets.

[0001571996-19-000025:notes:34]
[same as prior period, unchanged from 0001571996-18-000044:notes:90]

[0001571996-19-000025:notes:35]
[same as prior period, unchanged from 0001571996-18-000044:notes:91]

[0001571996-19-000025:notes:36]
As of May 3, 2019 and February 1, 2019, the Company held private strategic investments of $735 million and $671 million, respectively.  As these investments represent early-stage companies without readily determinable fair values, they are not included in the recurring fair value table above.

[0001571996-19-000025:notes:37]
[same as prior period, unchanged from 0001571996-18-000044:notes:93]

[0001571996-19-000025:notes:38]
Carrying Value and Estimated Fair Value of Outstanding Debt — The following table presents the carrying value and estimated fair value of the Company’s outstanding debt as described in Note 6 of the Notes to the Condensed Consolidated Financial Statements, including the current portion, as of the dates indicated:

[0001571996-19-000025:notes:39]
|  | May 3, 2019 |  | February 1, 2019 |
|  | Carrying Value |  | Fair Value |  | Carrying Value |  | Fair Value |
|  | (in billions) |
| Senior Secured Credit Facilities | $ | 10.8 |  |  | $ | 10.9 |  |  | $ | 12.5 |  |  | $ | 12.6 |  |
| First Lien Notes | $ | 20.5 |  |  | $ | 22.3 |  |  | $ | 19.8 |  |  | $ | 21.0 |  |
| Unsecured Notes and Debentures | $ | 1.8 |  |  | $ | 2.0 |  |  | $ | 1.8 |  |  | $ | 1.9 |  |
| Senior Notes | $ | 3.1 |  |  | $ | 3.4 |  |  | $ | 3.1 |  |  | $ | 3.4 |  |
| EMC Notes | $ | 3.0 |  |  | $ | 3.0 |  |  | $ | 3.0 |  |  | $ | 2.9 |  |
| VMware Notes | $ | 4.0 |  |  | $ | 3.9 |  |  | $ | 4.0 |  |  | $ | 3.9 |  |
| Margin Loan Facility | $ | 4.0 |  |  | $ | 4.0 |  |  | $ | 3.3 |  |  | $ | 3.4 |  |

[0001571996-19-000025:notes:40]
The fair values of the outstanding debt shown in the table above, as well as the DFS debt described in Note 4 of the Notes to the Condensed Consolidated Financial Statements, were determined based on observable market prices in a less active market or based on valuation methodologies using observable inputs and were categorized as Level 2 in the fair value hierarchy.  The carrying value of DFS debt approximates fair value.

[0001571996-19-000025:notes:41]
Investments

[0001571996-19-000025:notes:42]
The following table presents the carrying value and amortized cost of the Company’s strategic investments in publicly-traded and privately-held companies as of the dates indicated:

[0001571996-19-000025:notes:43]
|  | May 3, 2019 |  | February 1, 2019 |
|  | Cost |  | Unrealized Gain |  | Unrealized (Loss) |  | Carrying Value |  | Cost |  | Unrealized Gain |  | Unrealized (Loss) |  | Carrying Value |
|  | (in millions) |
| Equity and other securities | $ | 756 |  |  | $ | 44 |  |  | $ | (18 | ) |  | $ | 782 |  |  | $ | 638 |  |  | $ | 539 |  |  | $ | (172 | ) |  | $ | 1,005 |  |

[0001571996-19-000025:notes:44]
For the three months ended May 3, 2019, the equity and other securities without readily determinable fair values increased by $44 million due to upward adjustments for observable price changes, offset by $8 million of downward adjustments that were primarily attributable to impairments.  The remainder of equity and other securities consists of publicly-traded investments that are measured at fair value on a recurring basis.


## us-gaap:LoansNotesTradeAndOtherReceivablesDisclosureTextBlock

[0001571996-19-000025:notes:45]
NOTE 4 — FINANCIAL SERVICES

[0001571996-19-000025:notes:46]
The Company offers or arranges various financing options and services, and alternative payment structures for its customers in North America, Europe, Australia, and New Zealand through DFS and its affiliates.  The Company also arranges financing for some of its customers in various countries where DFS does not currently operate as a captive enterprise.  The key activities of DFS include originating, collecting, and servicing of customer financing arrangements primarily related to the purchase or usage of Dell Technologies products and services.  In some cases, DFS also offers financing on the purchase of third-party technology products that complement the Dell Technologies portfolio of products and services.  New financing originations were $1.7 billion for both the three months ended May 3, 2019 and May 4, 2018.

[0001571996-19-000025:notes:47]
The Company’s lease and loan arrangements with customers are aggregated into the following categories:

[0001571996-19-000025:notes:48]
| • | Revolving loans — Revolving loans offered under private label credit financing programs provide qualified customers with a revolving credit line for the purchase of products and services offered by Dell Technologies. These private label credit financing programs are referred to as Dell Preferred Account (“DPA”) and Dell Business Credit (“DBC”). The DPA product is primarily offered to individual consumer customers, and the DBC product is primarily offered to small and medium-sized commercial customers. Revolving loans in the United States bear interest at a variable annual percentage rate that is tied to the prime rate. Based on historical payment patterns, revolving loan transactions are typically repaid within twelve months on average. Due to the short-term nature of the revolving loan portfolio, the carrying value of the portfolio approximates fair value. |

[0001571996-19-000025:notes:49]
| • | Fixed-term leases and loans — The Company enters into financing arrangements with customers who seek lease financing for equipment they might otherwise purchase. Under the new lease standard discussed in Note 1 and Note 2 of the Notes to the Condensed Consolidated Financial Statements, new DFS leases are classified as sales-type leases, direct financing leases, or operating leases. When the terms of the DFS lease transfer control of the underlying asset to the lessee, the contract is typically classified as a sales-type lease. Direct financing leases under the new lease standard are immaterial. All other new DFS leases are classified as operating leases. Leases that commenced prior to the adoption of the new lease standard were not reassessed or restated pursuant to the practical expedients elected and will continue to be accounted for under previous lease accounting guidance. Leases with business customers have fixed terms of generally two to four years. |

[0001571996-19-000025:notes:50]
The Company also offers fixed-term loans to qualified small businesses, large commercial accounts, governmental organizations, educational entities, and certain individual consumer customers.  These loans are repaid in equal payments including interest and have defined terms of generally three to five years.  The fair value of the fixed-term loan portfolio is determined using market observable inputs.  The carrying value of these loans approximates fair value.

[0001571996-19-000025:notes:51]
[same as prior period, unchanged from 0001571996-18-000044:notes:106]

[0001571996-19-000025:notes:52]
The following table presents the components of the Company’s financing receivables segregated by portfolio segment as of the dates indicated:

[0001571996-19-000025:notes:53]
|  | May 3, 2019 |  | February 1, 2019 |
|  | Revolving |  | Fixed-term |  | Total |  | Revolving |  | Fixed-term |  | Total |
|  | (in millions) |
| Financing receivables, net: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer receivables, gross (a) | $ | 790 |  |  | $ | 7,100 |  |  | $ | 7,890 |  |  | $ | 835 |  |  | $ | 7,249 |  |  | $ | 8,084 |  |
| Allowances for losses | (70 | ) |  | (73 | ) |  | (143 | ) |  | (75 | ) |  | (61 | ) |  | (136 | ) |
| Customer receivables, net | 720 |  |  | 7,027 |  |  | 7,747 |  |  | 760 |  |  | 7,188 |  |  | 7,948 |  |
| Residual interest | — |  |  | 661 |  |  | 661 |  |  | — |  |  | 674 |  |  | 674 |  |
| Financing receivables, net | $ | 720 |  |  | $ | 7,688 |  |  | $ | 8,408 |  |  | $ | 760 |  |  | $ | 7,862 |  |  | $ | 8,622 |  |
| Short-term | $ | 720 |  |  | $ | 3,557 |  |  | $ | 4,277 |  |  | $ | 760 |  |  | $ | 3,638 |  |  | $ | 4,398 |  |
| Long-term | $ | — |  |  | $ | 4,131 |  |  | $ | 4,131 |  |  | $ | — |  |  | $ | 4,224 |  |  | $ | 4,224 |  |

[0001571996-19-000025:notes:54]
____________________

[0001571996-19-000025:notes:55]
| (a) | Customer receivables, gross includes amounts due from customers under revolving loans, fixed-term loans, fixed-term sales-type or direct financing leases, and accrued interest. |

[0001571996-19-000025:notes:56]
The following table presents the changes in allowance for financing receivable losses for the periods indicated:

[0001571996-19-000025:notes:57]
|  | Three Months Ended |
|  | May 3, 2019 |  | May 4, 2018 |
|  | Revolving |  | Fixed-term |  | Total |  | Revolving |  | Fixed-term |  | Total |
|  | (in millions) |
| Allowance for financing receivable losses: |  |  |  |  |  |  |  |  |  |  |  |
| Balances at beginning of period | $ | 75 |  |  | $ | 61 |  |  | $ | 136 |  |  | $ | 81 |  |  | $ | 64 |  |  | $ | 145 |  |
| Charge-offs, net of recoveries | (20 | ) |  | (3 | ) |  | (23 | ) |  | (20 | ) |  | (5 | ) |  | (25 | ) |
| Provision charged to income statement | 15 |  |  | 15 |  |  | 30 |  |  | 16 |  |  | 3 |  |  | 19 |  |
| Balances at end of period | $ | 70 |  |  | $ | 73 |  |  | $ | 143 |  |  | $ | 77 |  |  | $ | 62 |  |  | $ | 139 |  |

[0001571996-19-000025:notes:58]
Aging

[0001571996-19-000025:notes:59]
The following table presents the aging of the Company’s customer financing receivables, gross, including accrued interest, segregated by class, as of the dates indicated:

[0001571996-19-000025:notes:60]
|  | May 3, 2019 |  | February 1, 2019 |
|  | Current |  | Past Due1 — 90 Days |  | Past Due>90 Days |  | Total |  | Current |  | Past Due1 — 90 Days |  | Past Due>90 Days |  | Total |
|  | (in millions) |
| Revolving — DPA | $ | 553 |  |  | $ | 43 |  |  | $ | 19 |  |  | $ | 615 |  |  | $ | 583 |  |  | $ | 53 |  |  | $ | 21 |  |  | $ | 657 |  |
| Revolving — DBC | 153 |  |  | 19 |  |  | 3 |  |  | 175 |  |  | 155 |  |  | 19 |  |  | 4 |  |  | 178 |  |
| Fixed-term — Consumer and Commercial | 6,160 |  |  | 832 |  |  | 108 |  |  | 7,100 |  |  | 6,282 |  |  | 878 |  |  | 89 |  |  | 7,249 |  |
| Total customer receivables, gross | $ | 6,866 |  |  | $ | 894 |  |  | $ | 130 |  |  | $ | 7,890 |  |  | $ | 7,020 |  |  | $ | 950 |  |  | $ | 114 |  |  | $ | 8,084 |  |

[0001571996-19-000025:notes:61]
Aging is likely to fluctuate year to year as a result of the variability in volume of large transactions entered into over the period, and the administrative processes that accompany those larger transactions.  As such, fluctuations in aging do not necessarily indicate a material change in the credit quality of the portfolio.

[0001571996-19-000025:notes:62]
[same as prior period, unchanged from 0001571996-18-000044:notes:119]

[0001571996-19-000025:notes:63]
The following table presents customer receivables, gross, including accrued interest, by credit quality indicator segregated by class, as of the dates indicated.  The categories shown in the table below segregate customer receivables based on the relative degrees of credit risk.  The credit quality indicators for DPA revolving accounts are measured primarily as of each quarter-end date, while all other indicators are generally updated on a periodic basis.

[0001571996-19-000025:notes:64]
|  | May 3, 2019 |  | February 1, 2019 |
|  | Higher |  | Mid |  | Lower |  | Total |  | Higher |  | Mid |  | Lower |  | Total |
|  | (in millions) |
| Revolving — DPA | $ | 121 |  |  | $ | 180 |  |  | $ | 314 |  |  | $ | 615 |  |  | $ | 128 |  |  | $ | 192 |  |  | $ | 337 |  |  | $ | 657 |  |
| Revolving — DBC | $ | 45 |  |  | $ | 53 |  |  | $ | 77 |  |  | $ | 175 |  |  | $ | 47 |  |  | $ | 54 |  |  | $ | 77 |  |  | $ | 178 |  |
| Fixed-term — Consumer and Commercial | $ | 3,916 |  |  | $ | 1,928 |  |  | $ | 1,256 |  |  | $ | 7,100 |  |  | $ | 3,980 |  |  | $ | 1,984 |  |  | $ | 1,285 |  |  | $ | 7,249 |  |

[0001571996-19-000025:notes:65]
For DPA revolving receivables shown in the table above, the Company makes credit decisions based on proprietary scorecards, which include the customer’s credit history, payment history, credit usage, and other credit agency-related elements.  The higher quality category includes prime accounts generally of a higher credit quality that are comparable to U.S. customer FICO scores of 720 or above.  The mid-category represents the mid-tier accounts that are comparable to U.S. customer FICO scores from 660 to 719.  The lower category is generally sub-prime and represents lower credit quality accounts that are comparable to U.S. customer FICO scores below 660.  For the DBC revolving receivables and fixed-term commercial receivables shown in the table above, an internal grading system is utilized that assigns a credit level score based on a number of considerations, including liquidity, operating performance, and industry outlook.  The grading criteria and classifications for the fixed-term products differ from those for the revolving products as loss experience varies between these product and customer groups.  The credit quality categories cannot be compared between the different classes as loss experience varies substantially between the classes.

[0001571996-19-000025:notes:66]
Leases

[0001571996-19-000025:notes:67]
Interest income on sales-type lease receivables was $64 million for the three months ended May 3, 2019.

[0001571996-19-000025:notes:68]
The following table presents the net revenue, cost of net revenue, and gross margin recognized at the commencement date of  sales-type leases for the period indicated:

[0001571996-19-000025:notes:69]
|  | Three Months Ended |
|  | May 3, 2019 |
|  | (in millions) |
| Net revenue — products | $ | 130 |  |
| Cost of net revenue — products | 81 |  |
| Gross margin — products | $ | 49 |  |

[0001571996-19-000025:notes:70]
The following table presents the future maturity of the Company’s fixed-term customer leases and associated financing payments, and reconciles the undiscounted cash flows to the customer receivables, gross recognized on the Condensed Consolidated Statements of Financial Position as of May 3, 2019:

[0001571996-19-000025:notes:71]
| Fiscal Years | (in millions) |
| Fiscal 2020 (remaining nine months) | $ | 2,038 |  |
| Fiscal 2021 | 1,890 |  |
| Fiscal 2022 | 1,086 |  |
| Fiscal 2023 | 390 |  |
| Fiscal 2024 and beyond | 129 |  |
| Total undiscounted cash flows | 5,533 |  |
| Fixed-term loans | 2,045 |  |
| Revolving loans | 790 |  |
| Less: unearned income | (478 | ) |
| Total customer receivables, gross | $ | 7,890 |  |

[0001571996-19-000025:notes:72]
Disclosure related to periods prior to adoption of the new lease standard — Future maturities of minimum lease and associated financing payments as of February 1, 2019 were as follows: $2.6 billion in Fiscal 2020; $1.7 billion in Fiscal 2021; $0.9 billion in Fiscal 2022; $0.3 billion in Fiscal 2023; and $0.1 billion in Fiscal 2024 and beyond.  Future maturities and associated financing payments referenced herein represent the aggregate payments under the customer lease contract.

[0001571996-19-000025:notes:73]
Operating Leases

[0001571996-19-000025:notes:74]
The following table presents the components of the Company’s operating lease portfolio included in Property, plant, and equipment, net as of the date indicated:

[0001571996-19-000025:notes:75]
|  | May 3, 2019 |
|  | (in millions) |
| Equipment under operating lease, gross | $ | 282 |  |
| Less: accumulated depreciation | 8 |  |
| Equipment under operating lease, net | $ | 274 |  |

[0001571996-19-000025:notes:76]
As of February 1, 2019, the Company’s equipment under operating lease, net was $3 million.

[0001571996-19-000025:notes:77]
Operating lease income relating to lease payments was $4 million for the three months ended May 3, 2019.  Depreciation expense was $3 million for the three months ended May 3, 2019.

[0001571996-19-000025:notes:78]
The following table presents the future payments to be received by the Company as lessor in operating lease contracts as of May 3, 2019:

[0001571996-19-000025:notes:79]
| Fiscal Years | (in millions) |
| Fiscal 2020 (remaining nine months) | $ | 90 |  |
| Fiscal 2021 | 92 |  |
| Fiscal 2022 | 79 |  |
| Fiscal 2023 | 22 |  |
| Fiscal 2024 and beyond | 1 |  |
| Total | $ | 284 |  |

[0001571996-19-000025:notes:80]
[same as prior period, unchanged from 0001571996-18-000044:notes:123]

[0001571996-19-000025:notes:81]
The Company maintains programs that facilitate the funding of leases, loans, and other alternative payment structures in the capital markets.  The following table presents DFS debt as of the dates indicated.  The table excludes the allocated portion of the Company’s other borrowings, which represents the additional amount considered to fund the DFS business.

[0001571996-19-000025:notes:82]
|  | May 3, 2019 |  | February 1, 2019 |
|  | (in millions) |
| DFS U.S. debt: |  |  |  |
| Securitization facilities | $ | 1,692 |  |  | $ | 1,914 |  |
| Fixed-term securitization offerings | 2,836 |  |  | 2,303 |  |
| Other | 201 |  |  | 223 |  |
| Total DFS U.S. debt | 4,729 |  |  | 4,440 |  |
| DFS international debt: |  |  |  |
| Securitization facility | 646 |  |  | 584 |  |
| Other borrowings | 766 |  |  | 708 |  |
| Note payable | 202 |  |  | 197 |  |
| Total DFS international debt | 1,614 |  |  | 1,489 |  |
| Total DFS debt | $ | 6,343 |  |  | $ | 5,929 |  |
| Total short-term DFS debt | $ | 3,952 |  |  | $ | 3,113 |  |
| Total long-term DFS debt | $ | 2,391 |  |  | $ | 2,816 |  |

[0001571996-19-000025:notes:83]
[same as prior period, unchanged from 0001571996-18-000044:notes:126]

[0001571996-19-000025:notes:84]
Securitization Facilities — The Company maintains separate securitization facilities in the United States for fixed-term leases and loans and for revolving loans.  This debt is collateralized solely by the U.S. loan and lease payments and associated equipment in the facilities.  The debt has a variable interest rate and the duration of the debt is based on the terms of the underlying loan and lease payment streams.  As of May 3, 2019, the total debt capacity related to the U.S. securitization facilities was $3.5 billion.  The Company enters into interest swap agreements to effectively convert a portion of its securitization debt from a floating rate to a fixed rate.  See Note 7 of the Notes to the Condensed Consolidated Financial Statements for additional information about interest rate swaps.

[0001571996-19-000025:notes:85]
The Company’s U.S. securitization facility for revolving loans is effective through June 1, 2020.  The Company’s two U.S. securitization facilities for fixed-term leases and loans are effective through February 10, 2020 and February 22, 2020, respectively.

[0001571996-19-000025:notes:86]
The securitization facilities contain standard structural features related to the performance of the securitized receivables, which include defined credit losses, delinquencies, average credit scores, and minimum collection requirements.  In the event one or more of these criteria are not met and the Company is unable to restructure the facility, no further funding of receivables will be permitted and the timing of the Company’s expected cash flows from over-collateralization will be delayed.  As of May 3, 2019, these criteria were met.

[0001571996-19-000025:notes:87]
Fixed-Term Securitization Offerings — The Company periodically issues asset-backed debt securities under fixed-term securitization programs to private investors.  The asset-backed debt securities are collateralized solely by the U.S. fixed-term leases and loans in the offerings, which are held by Special Purpose Entities (“SPEs”), as discussed below.  The interest rate on these securities is fixed and ranges from 1.97% to 3.97% per annum, and the duration of these securities is based on the terms of the underlying lease and loan payment streams.

[0001571996-19-000025:notes:88]
[same as prior period, unchanged from 0001571996-18-000044:notes:131]

[0001571996-19-000025:notes:89]
Securitization Facility — The Company maintains a securitization facility in Europe for fixed-term leases and loans.  This facility is effective through December 21, 2020 and has a total debt capacity of $894 million as of May 3, 2019.

[0001571996-19-000025:notes:90]
The securitization facility contains standard structural features related to the performance of the securitized receivables which include defined credit losses, delinquencies, average credit scores, and minimum collection requirements.  In the event one or more of these criteria are not met and the Company is unable to restructure the program, no further funding of receivables will be permitted and the timing of the Company’s expected cash flows from over-collateralization will be delayed.  As of May 3, 2019, these criteria were met.

[0001571996-19-000025:notes:91]
Other Borrowings — In connection with the Company’s international financing operations, the Company has entered into revolving structured financing debt programs related to its fixed-term lease and loan products sold in Canada, Europe, Australia, and New Zealand.  The Canadian facility, which is collateralized solely by Canadian loan and lease payments and associated equipment, had a total debt capacity of $223 million as of May 3, 2019, and is effective through January 16, 2023.  The European facility, which is collateralized solely by European loan and lease payments and associated equipment, had a total debt capacity of $670 million as of May 3, 2019, and is effective through December 14, 2020.  The Australia and New Zealand facility, which is collateralized solely by Australia and New Zealand loan and lease payments and associated equipment, had a total debt capacity of $196 million as of May 3, 2019, and is effective through January 29, 2020.

[0001571996-19-000025:notes:92]
Note Payable — On November 27, 2017, the Company entered into an unsecured credit agreement to fund receivables in Mexico.  As of May 3, 2019, the aggregate principal amount of the note payable is $198 million.  The note bears interest at either the applicable London Interbank Offered Rate (“LIBOR”) plus 2.25%, for the borrowings denominated in U.S. dollars, or the Mexican Interbank Equilibrium Interest Rate (“TIIE”) plus 2.00%, for the borrowings denominated in Mexican pesos.  The note will mature on December 1, 2020.  Although the note is unsecured, the Company intends to manage the note in the same manner as its structured financing programs, so that the collections from loan and lease payments and associated equipment in Mexico will be used to pay down principal and interest of the note.

[0001571996-19-000025:notes:93]
[same as prior period, unchanged from 0001571996-18-000044:notes:136]

[0001571996-19-000025:notes:94]
In connection with the securitization facilities and offerings discussed above, the Company transfers certain U.S. and European loan and lease payments and associated equipment to SPEs that meet the definition of a Variable Interest Entity (“VIE”) and are consolidated, along with the associated debt detailed above, into the Consolidated Financial Statements, as the Company is the primary beneficiary of those VIEs.  The SPEs are bankruptcy-remote legal entities with separate assets and liabilities.  The purpose of the SPEs is to facilitate the funding of loan and lease payments and associated equipment in the capital markets.

[0001571996-19-000025:notes:95]
The following table presents financing receivables and equipment under operating leases, net held by the consolidated VIEs as of the dates indicated:

[0001571996-19-000025:notes:96]
|  | May 3, 2019 |  | February 1, 2019 |
|  | (in millions) |
| Assets held by consolidated VIEs, net: |  |  |  |  |  |
| Short-term, net | $ | 2,998 |  |  | $ | 2,940 |  |
| Long-term, net | 2,768 |  |  | 2,508 |  |
| Assets held by consolidated VIEs, net | $ | 5,766 |  |  | $ | 5,448 |  |

[0001571996-19-000025:notes:97]
Loan and lease payments and associated equipment transferred via securitization through SPEs were $1.5 billion and $1.3 billion for the three months ended May 3, 2019 and May 4, 2018, respectively.

[0001571996-19-000025:notes:98]
Some of the SPEs have entered into financing arrangements with multi-seller conduits that, in turn, issue asset-backed debt securities in the capital markets.  The DFS debt outstanding, which is collateralized by the loan and lease payments and associated equipment held by the consolidated VIEs, was $5.2 billion and $4.8 billion as of May 3, 2019 and February 1, 2019, respectively.  The Company’s risk of loss related to securitized receivables is limited to the amount by which the Company’s right to receive collections for assets securitized exceeds the amount required to pay interest, principal, and fees and expenses related to the asset-backed securities.  The Company provides credit enhancement to the securitization in the form of over-collateralization.

[0001571996-19-000025:notes:99]
Customer Receivable Sales

[0001571996-19-000025:notes:100]
To manage certain concentrations of customer credit exposure, the Company may sell selected fixed-term customer receivables to unrelated third parties on a periodic basis.  The amount of customer receivables sold was $101 million for both the three months ended May 3, 2019 and May 4, 2018.


## us-gaap:ScheduleOfDebtTableTextBlock

[0001571996-19-000025:notes:101]
The following table presents DFS debt as of the dates indicated.  The table excludes the allocated portion of the Company’s other borrowings, which represents the additional amount considered to fund the DFS business.

[0001571996-19-000025:notes:102]
The following table presents the Company’s outstanding debt as of the dates indicated:

[0001571996-19-000025:notes:103]
|  | May 3, 2019 |  | February 1, 2019 |
|  | (in millions) |
| Secured Debt |  |  |  |
| Senior Secured Credit Facilities: |  |  |  |
| 4.49% Term Loan B Facility due September 2023 | $ | 4,925 |  |  | $ | 4,938 |  |
| 4.24% Term Loan A-2 Facility due September 2021 | 727 |  |  | 4,116 |  |
| 4.24% Term Loan A-4 Facility due December 2023 | 1,629 |  |  | 1,650 |  |
| 4.25% Term Loan A-5 Facility due December 2019 | — |  |  | 2,016 |  |
| 4.23% Term Loan A-6 Facility due March 2024 | 3,634 |  |  | — |  |
| First Lien Notes: |  |  |  |
| 3.48% due June 2019 | — |  |  | 3,750 |  |
| 4.42% due June 2021 | 4,500 |  |  | 4,500 |  |
| 5.45% due June 2023 | 3,750 |  |  | 3,750 |  |
| 4.00% due July 2024 | 1,000 |  |  | — |  |
| 6.02% due June 2026 | 4,500 |  |  | 4,500 |  |
| 4.90% due October 2026 | 1,750 |  |  | — |  |
| 5.30% due October 2029 | 1,750 |  |  | — |  |
| 8.10% due July 2036 | 1,500 |  |  | 1,500 |  |
| 8.35% due July 2046 | 2,000 |  |  | 2,000 |  |
| Unsecured Debt |  |  |  |
| Unsecured Notes and Debentures: |  |  |  |
| 5.875% due June 2019 | 600 |  |  | 600 |  |
| 4.625% due April 2021 | 400 |  |  | 400 |  |
| 7.10% due April 2028 | 300 |  |  | 300 |  |
| 6.50% due April 2038 | 388 |  |  | 388 |  |
| 5.40% due September 2040 | 264 |  |  | 264 |  |
| Senior Notes: |  |  |  |
| 5.875% due June 2021 | 1,625 |  |  | 1,625 |  |
| 7.125% due June 2024 | 1,625 |  |  | 1,625 |  |
| EMC Notes: |  |  |  |
| 2.650% due June 2020 | 2,000 |  |  | 2,000 |  |
| 3.375% due June 2023 | 1,000 |  |  | 1,000 |  |
| VMware Notes: |  |  |  |
| 2.30% due August 2020 | 1,250 |  |  | 1,250 |  |
| 2.95% due August 2022 | 1,500 |  |  | 1,500 |  |
| 3.90% due August 2027 | 1,250 |  |  | 1,250 |  |
| DFS Debt (Note 4) | 6,343 |  |  | 5,929 |  |
| Other |  |  |  |
| 4.83% Margin Loan Facility due April 2022 | 4,000 |  |  | 3,350 |  |
| Other | 27 |  |  | 38 |  |
| Total debt, principal amount | $ | 54,237 |  |  | $ | 54,239 |  |

[0001571996-19-000025:notes:104]
|  | May 3, 2019 |  | February 1, 2019 |
|  | (in millions) |
| Total debt, principal amount | $ | 54,237 |  |  | $ | 54,239 |  |
| Unamortized discount, net of unamortized premium | (268 | ) |  | (271 | ) |
| Debt issuance costs | (445 | ) |  | (447 | ) |
| Total debt, carrying value | $ | 53,524 |  |  | $ | 53,521 |  |
| Total short-term debt, carrying value | $ | 4,884 |  |  | $ | 4,320 |  |
| Total long-term debt, carrying value | $ | 48,640 |  |  | $ | 49,201 |  |


## us-gaap:LesseeOperatingLeasesTextBlock

[0001571996-19-000025:notes:105]
NOTE 5 — LEASES

[0001571996-19-000025:notes:106]
The Company enters into leasing transactions in which the Company is lessee.  These lease contracts are typically classified as operating leases.  The Company’s lease contracts are generally for office buildings used to conduct our business, and the determination of whether such contracts contain leases generally does not require significant estimates or judgments.  The Company also leases certain global logistic warehouses, employee vehicles, and equipment.  As of May 3, 2019, the remaining terms of the Company’s leases range from one year to 27 years.

[0001571996-19-000025:notes:107]
The Company also enters into leasing transactions in which the Company is lessor, primarily through customer financing arrangements offered through DFS.  DFS originates leases that are primarily classified as either sales-type leases or operating leases.  See Note 4 of the Notes to the Condensed Consolidated Financial Statements for more information on the DFS lease portfolio and related lease disclosures.

[0001571996-19-000025:notes:108]
In adopting the new lease standard discussed in Note 1 and Note 2 of the Notes to the Condensed Consolidated Financial Statements, the Company elected to apply a transition method that does not require the retrospective application to periods prior to adoption.  Financial information associated with the Company’s leases in which the Company is lessee contained in this footnote are presented as of and for the three months ended May 3, 2019.

[0001571996-19-000025:notes:109]
The following table presents components of lease costs included in the Condensed Consolidated Statements of Income for the period presented:

[0001571996-19-000025:notes:110]
|  | Three Months Ended |
|  | May 3, 2019 |
|  | (in millions) |
| Operating lease costs | $ | 117 |  |
| Variable costs | 38 |  |
| Total lease costs | $ | 155 |  |

[0001571996-19-000025:notes:111]
During the three months ended May 3, 2019, sublease income, finance lease costs, and short-term lease costs were immaterial.

[0001571996-19-000025:notes:112]
The following table presents supplemental information related to operating leases included in the Condensed Consolidated Statements of Financial Position as of the date presented:

[0001571996-19-000025:notes:113]
|  | Classification |  | May 3, 2019 |
|  |  |  | (in millions, except for term and discount rate) |
| Operating lease ROU assets | Other non-current assets |  | $ | 1,527 |  |
| Current operating lease liabilities | Accrued and other current liabilities |  | $ | 416 |  |
| Non-current operating lease liabilities | Other non-current liabilities |  | 1,138 |  |
| Total operating lease liabilities |  |  | $ | 1,554 |  |
| Weighted-average remaining lease term (in years) |  |  | 9.2 |  |
| Weighted-average discount rate |  |  | 4.1 | % |

[0001571996-19-000025:notes:114]
The following table presents supplemental cash flow information related to leases for the period presented:

[0001571996-19-000025:notes:115]
|  | Three Months Ended |
|  | May 3, 2019 |
|  | (in millions) |
| Cash paid for amounts included in the measurement of lease liabilities - operating cash outflows from operating leases | $ | 122 |  |
| ROU assets obtained in exchange for new operating lease liabilities | $ | 42 |  |

[0001571996-19-000025:notes:116]
The following table presents the future maturity of the Company’s operating lease liabilities under non-cancelable leases and reconciles the undiscounted cash flows for these leases to the lease liability recognized on the Condensed Consolidated Statements of Financial Position as of May 3, 2019:

[0001571996-19-000025:notes:117]
| Fiscal Years | (in millions) |
| Fiscal 2020 (remaining nine months) | $ | 305 |  |
| Fiscal 2021 | 365 |  |
| Fiscal 2022 | 271 |  |
| Fiscal 2023 | 195 |  |
| Fiscal 2024 | 125 |  |
| Thereafter | 656 |  |
| Total lease payments | $ | 1,917 |  |
| Less: Imputed interest | (363 | ) |
| Total | $ | 1,554 |  |
| Current operating lease liabilities | $ | 416 |  |
| Non-current operating lease liabilities | $ | 1,138 |  |

[0001571996-19-000025:notes:118]
The amount of future lease commitments after Fiscal 2024 is primarily for the ground lease on VMware, Inc.’s Palo Alto, California headquarter facilities, which expires in Fiscal 2047.

[0001571996-19-000025:notes:119]
As of May 3, 2019, the Company has additional operating leases that have not yet commenced of $237 million.  These operating leases will commence during Fiscal 2020 and Fiscal 2021 with lease terms of one year to 10 years.

[0001571996-19-000025:notes:120]
Disclosure related to periods prior to adoption of the new lease standard

[0001571996-19-000025:notes:121]
As of February 1, 2019, the Company had the following future minimum lease payments under non-cancelable leases prior to the adoption of the new lease standard:

[0001571996-19-000025:notes:122]
| Fiscal Years | (in millions) |
| Fiscal 2020 | $ | 371 |  |
| Fiscal 2021 | 314 |  |
| Fiscal 2022 | 240 |  |
| Fiscal 2023 | 175 |  |
| Fiscal 2024 | 113 |  |
| Thereafter | 643 |  |
| Total | $ | 1,856 |  |


## us-gaap:DebtDisclosureTextBlock

[0001571996-19-000025:notes:123]
NOTE 6 — DEBT

[0001571996-19-000025:notes:124]
On March 7, 2019, the Company amended the Margin Loan Agreement to increase the aggregate principal amount of borrowings under the Margin Loan Facility by $650 million.

[0001571996-19-000025:notes:125]
On March 13, 2019, the Company entered into an amendment to the credit agreement for the Senior Secured Credit Facilities to obtain a new senior secured Term Loan A-6 Facility in order to refinance the $5 billion aggregate principal amount of debt incurred in connection with the Class V transaction described in Note 14 of the Notes to the Condensed Consolidated Financial Statements.  The Term Loan A-6 Facility aggregate principal amount of $3,634 million matures on March 13, 2024, of which $2,839 million aggregate principal amount represents the amounts outstanding under the Term Loan A-2 Facility that rolled-over into the new facility.  Immediately after the rollover, an aggregate principal amount of $1,277 million remained outstanding under the Term Loan A-2 Facility.  The Term Loan A-6 Facility amortizes quarterly and bears interest at the London Interbank Offered Rate (“LIBOR”) plus an applicable margin ranging from 1.25% to 2.00% or a base rate plus an applicable margin of 0.25% to 1.00%.

[0001571996-19-000025:notes:126]
On March 20, 2019, Dell International L.L.C. and EMC Corporation, both which are wholly-owned subsidiaries of Dell Technologies Inc., completed a private offering of multiple series of First Lien Notes in an aggregate principal amount of $4.5 billion.  The principal amount, interest rate, and maturity of each series of such First Lien Notes were as follows:

[0001571996-19-000025:notes:127]
| • | $1,000 million 4.00% First Lien Notes due July 15, 2024 |

[0001571996-19-000025:notes:128]
| • | $1,750 million 4.90% First Lien Notes due October 1, 2026 |

[0001571996-19-000025:notes:129]
| • | $1,750 million 5.30% First Lien Notes due October 1, 2029 |

[0001571996-19-000025:notes:130]
A majority of the proceeds from the First Lien Notes issued on March 20, 2019 was used to repay all of the outstanding $3,750 million First Lien Notes due June 2019.  In addition, proceeds of approximately $800 million of borrowings under the new Term Loan A-6 Facility, the proceeds of the $650 million increase in the Margin Loan Facility, and a portion of the proceeds from the 2019 First Lien Notes were used to repay all of the Company’s outstanding amounts under the Term Loan A-5 Facility due December 2019.  The remaining proceeds available from the 2019 First Lien Notes were used to repay outstanding amounts under the Term Loan A-2 Facility and to pay related premiums, accrued interest, fees, and expenses.

[0001571996-19-000025:notes:131]
The refinancing and amendments were evaluated in accordance with FASB ASC 470, “Debt-Modifications and Extinguishments.”  The amendment to the Margin Loan Agreement and the term debt refinancing were accounted for as modifications for all existing lenders and as new issuances for new lenders.  The First Lien Notes issued on March 20, 2019, were accounted for as new issuances for all lenders, and repayment of the Company’s outstanding amounts under the Term Loan A-5 Facility was accounted for as an extinguishment.  During the three months ended May 3, 2019, the Company capitalized $74.5 million in new fees paid to creditors as a result of the modifications and new issuances.  In addition, the Company recognized expenses of $32.3 million in unamortized costs and $7.1 million in new third-party costs during the three months ended May 3, 2019.

[0001571996-19-000025:notes:132]
During the three months ended May 3, 2019, the Company also repaid $400 million of its Term Loan A-2 Facility and approximately $33 million of principal amortization under its term loan facilities.

[0001571996-19-000025:notes:133]
The Company issued an additional $0.4 billion, net, in DFS debt to support the expansion of its financing receivables portfolio during the three months ended May 3, 2019.

[0001571996-19-000025:notes:134]
Secured Debt

[0001571996-19-000025:notes:135]
Senior Secured Credit Facilities — The Company has entered into a credit agreement that provides for senior secured credit facilities (the “Senior Secured Credit Facilities”) comprising (a) term loan facilities and (b) a senior secured Revolving Credit Facility, which includes capacity for up to $0.5 billion of letters of credit and for borrowings of up to $0.4 billion under swing-line loans.

[0001571996-19-000025:notes:136]
As of May 3, 2019, available borrowings under the Revolving Credit Facility totaled $4.5 billion.  The Senior Secured Credit Facilities provide that the borrowers have the right at any time, subject to customary conditions, to request incremental term loans or incremental revolving commitments.

[0001571996-19-000025:notes:137]
Borrowings under the Senior Secured Credit Facilities bear interest at a rate per annum equal to an applicable margin, plus, at the borrowers’ option, either (a) a base rate, which, under the Term Loan B Facility, is subject to an interest rate floor of 1.75% per annum, and under all other borrowings is subject to an interest rate floor of 0% per annum, or (b) LIBOR, which, under the Term Loan B Facility, is subject to an interest rate floor of 0.75% per annum, and under all other borrowings is subject to an interest rate floor of 0% per annum.  Interest is payable, in the case of loans bearing interest based on LIBOR, at the end of each interest period (but at least every three months), in arrears and, in the case of loans bearing interest based on the base rate, quarterly in arrears.

[0001571996-19-000025:notes:138]
The Term Loan B Facility amortizes in equal quarterly installments in aggregate annual amounts equal to 1% of the original principal amount.  The Term Loan A-2 Facility amortizes in equal quarterly installments in aggregate annual amounts equal to 5% of the original principal amount in the first year after the closing date of the refinancing transaction on October 20, 2017, 10% of the original principal amount in each of the second and third years after October 20, 2017, and 75% of the original principal amount in the fourth year after October 20, 2017.  The Term Loan A-4 Facility amortizes in equal quarterly installments in aggregate annual amounts equal to 5% of the original principal amount in each of the first four years after the facility closing date of December 20, 2018, and 80% of the original principal amount in the fifth year after December 20, 2018.  The Revolving Credit Facility has no amortization.

[0001571996-19-000025:notes:139]
The borrowers may voluntarily repay outstanding loans under the term loan facilities and the Revolving Credit Facility at any time without premium or penalty, other than customary “breakage” costs.

[0001571996-19-000025:notes:140]
All obligations of the borrowers under the Senior Secured Credit Facilities and certain swap agreements, cash management arrangements, and certain letters of credit provided by any lender or agent party to the Senior Secured Credit Facilities or any of its affiliates and certain other persons are secured by (a) a first-priority security interest in certain tangible and intangible assets of the borrowers and the guarantors and (b) a first-priority pledge of 100% of the capital stock of the borrowers, Dell Inc., a wholly‑owned subsidiary of the Company (“Dell”), and each wholly-owned material restricted subsidiary of the borrowers and the guarantors, in each case subject to certain thresholds, exceptions, and permitted liens.

[0001571996-19-000025:notes:141]
First Lien Notes — The senior secured notes (collectively, the “First Lien Notes”) were issued on June 1, 2016 and March 20, 2019 in an aggregate principal amount of $20.0 billion and $4.5 billion, respectively.  As stated above, the Company used a portion of the $4.5 billion proceeds to repay all of the outstanding $3,750 million First Lien Notes due June 2019.  Interest on these borrowings is payable semiannually.  The First Lien Notes are secured, on a pari passu basis with the Senior Secured Credit Facilities, on a first-priority basis by substantially all of the tangible and intangible assets of the issuers and guarantors that secure obligations under the Senior Secured Credit Facilities, including pledges of all capital stock of the issuers, Dell, and certain wholly-owned material subsidiaries of the issuers and the guarantors, subject to certain exceptions.

[0001571996-19-000025:notes:142]
The Company has agreed to use commercially reasonable efforts to register with the SEC notes having terms substantially identical to the terms of the First Lien Notes as part of an offer to exchange such registered notes for the First Lien Notes.  The Company will be obligated to pay additional interest on the First Lien Notes if it fails to consummate such an exchange offer within five years after the closing date of the EMC merger transaction.

[0001571996-19-000025:notes:143]
China Revolving Credit Facility — During the three months ended May 3, 2019, the Company renewed its credit agreement (the “China Revolving Credit Facility”) with a bank lender for a secured revolving loan facility in an aggregate principal amount not to exceed $500 million at an interest rate of LIBOR plus 0.6% per annum.  The facility will expire on February 26, 2020.  As of May 3, 2019, there were no outstanding borrowings under the China Revolving Credit Facility.

[0001571996-19-000025:notes:144]
Unsecured Debt

[0001571996-19-000025:notes:145]
Unsecured Notes and Debentures — The Company has outstanding unsecured notes and debentures (collectively, the “Unsecured Notes and Debentures”) that were issued by Dell prior to the acquisition of Dell by Dell Technologies Inc. in the going-private transaction that closed in October 2013.  Interest on these borrowings is payable semiannually.

[0001571996-19-000025:notes:146]
Senior Notes — The senior unsecured notes (collectively, the “Senior Notes”) were issued on June 22, 2016 in an aggregate principal amount of $3.25 billion.  Interest on these borrowings is payable semiannually.

[0001571996-19-000025:notes:147]
EMC Notes — On September 7, 2016, EMC had outstanding $2.5 billion aggregate principal amount of its 1.875% Notes due June 2018, which the Company fully repaid during the three months ended August 3, 2018, $2.0 billion aggregate principal amount of its 2.650% Notes due June 2020, and $1.0 billion aggregate principal amount of its 3.375% Notes due June 2023 (collectively, the “EMC Notes”).  Interest on these borrowings is payable semiannually.

[0001571996-19-000025:notes:148]
VMware Notes — On August 21, 2017, VMware, Inc. completed a public offering of unsecured senior notes in the aggregate amount of $4.0 billion, consisting of outstanding principal due on the following dates: $1.25 billion due August 21, 2020, $1.5 billion due August 21, 2022, and $1.25 billion due August 21, 2027 (collectively, the “VMware Notes”).  The VMware Notes bear interest, payable semiannually, at annual rates of 2.30%, 2.95%, and 3.90%, respectively.  None of the net proceeds of such borrowings will be made available to support the operations or satisfy any corporate purposes of Dell Technologies, other than the operations and corporate purposes of VMware, Inc. and VMware, Inc.’s subsidiaries.

[0001571996-19-000025:notes:149]
VMware Revolving Credit Facility — On September 12, 2017, VMware, Inc. entered into an unsecured credit agreement, establishing a revolving credit facility (the “VMware Revolving Credit Facility”) with a syndicate of lenders that provides the company with a borrowing capacity of up to $1.0 billion which may be used for VMware, Inc. general corporate purposes.  Commitments under the VMware Revolving Credit Facility are available for a period of five years, which may be extended, subject to the satisfaction of certain conditions, by up to two one year periods.  The credit agreement contains certain representations, warranties, and covenants.  Commitment fees, interest rates, and other terms of borrowing under the VMware Revolving Credit Facility may vary based on VMware, Inc.’s external credit ratings.  None of the net proceeds of such borrowings will be made available to support the operations or satisfy any corporate purposes of Dell Technologies, other than the operations and corporate purposes of VMware, Inc. and VMware, Inc.’s subsidiaries.  As of May 3, 2019, there were no outstanding borrowings under the VMware Revolving Credit Facility.

[0001571996-19-000025:notes:150]
See Note 4 and Note 7 of the Notes to the Condensed Consolidated Financial Statements, respectively, for discussion of DFS debt and the interest rate swap agreements that hedge a portion of that debt.

[0001571996-19-000025:notes:151]
Other

[0001571996-19-000025:notes:152]
Margin Loan Facility — On April 12, 2017, the Company entered into the Margin Loan Facility in an aggregate principal amount of $2.0 billion.  In connection with the Class V transaction, on December 20, 2018, the Company amended the Margin Loan Facility to increase the aggregate principal amount to $3.35 billion.  In connection with obtaining the Term Loan A-6 Facility, the Company increased the aggregate principal amount of the facility to $4.0 billion.  VMW Holdco LLC, a wholly-owned subsidiary of EMC, is the borrower under the Margin Loan Facility, which is secured by 60 million shares of Class B common stock of VMware, Inc. and 20 million shares of Class A common stock of VMware, Inc.  Loans under the Margin Loan Facility bear interest at a rate per annum payable, at the borrower’s option, either at (a) a base rate plus 1.25% per annum or (b) a LIBOR-based rate plus 2.25% per annum.  Interest under the Margin Loan Facility is payable quarterly.

[0001571996-19-000025:notes:153]
The Margin Loan Facility will mature in April 2022.  The borrower may voluntarily repay outstanding loans under the Margin Loan Facility at any time without premium or penalty, other than customary “breakage” costs, subject to certain minimum threshold amounts for prepayment.

[0001571996-19-000025:notes:154]
Pivotal Revolving Credit Facility — On September 7, 2017, Pivotal entered into a credit agreement (the “Pivotal Revolving Credit Facility”) that provides for a senior secured revolving loan facility in an aggregate principal amount not to exceed $100 million.  The credit facility contains customary representations, warranties, and covenants, including financial covenants.  The credit agreement will expire on September 8, 2020, unless it is terminated earlier.  None of the net proceeds of borrowings under the facility will be made available to support the operations or satisfy any corporate purposes of Dell Technologies, other than the operations and corporate purposes of Pivotal and Pivotal’s subsidiaries.  As of May 3, 2019, there were no outstanding borrowings under the Pivotal Revolving Credit Facility.

[0001571996-19-000025:notes:155]
Aggregate Future Maturities

[0001571996-19-000025:notes:156]
The following table presents the aggregate future maturities of the Company’s debt as of May 3, 2019 for the periods indicated:

[0001571996-19-000025:notes:157]
|  | Maturities by Fiscal Year |
|  | 2020 (remaining nine months) |  | 2021 |  | 2022 |  | 2023 |  | 2024 |  | Thereafter |  | Total |
|  | (in millions) |
| Senior Secured Credit Facilities and First Lien Notes | $ | 248 |  |  | $ | 236 |  |  | $ | 5,542 |  |  | $ | 393 |  |  | $ | 12,033 |  |  | $ | 13,213 |  |  | $ | 31,665 |  |
| Unsecured Notes and Debentures | 600 |  |  | — |  |  | 400 |  |  | — |  |  | — |  |  | 952 |  |  | 1,952 |  |
| Senior Notes and EMC Notes | — |  |  | 2,000 |  |  | 1,625 |  |  | — |  |  | 1,000 |  |  | 1,625 |  |  | 6,250 |  |
| VMware Notes | — |  |  | 1,250 |  |  | — |  |  | 1,500 |  |  | — |  |  | 1,250 |  |  | 4,000 |  |
| DFS Debt | 3,124 |  |  | 2,402 |  |  | 594 |  |  | 187 |  |  | 36 |  |  | — |  |  | 6,343 |  |
| Margin Loan Facility | — |  |  | — |  |  | — |  |  | 4,000 |  |  | — |  |  | — |  |  | 4,000 |  |
| Other | 16 |  |  | 11 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 27 |  |
| Total maturities, principal amount | 3,988 |  |  | 5,899 |  |  | 8,161 |  |  | 6,080 |  |  | 13,069 |  |  | 17,040 |  |  | 54,237 |  |
| Associated carrying value adjustments | — |  |  | (6 | ) |  | (93 | ) |  | (30 | ) |  | (153 | ) |  | (431 | ) |  | (713 | ) |
| Total maturities, carrying value amount | $ | 3,988 |  |  | $ | 5,893 |  |  | $ | 8,068 |  |  | $ | 6,050 |  |  | $ | 12,916 |  |  | $ | 16,609 |  |  | $ | 53,524 |  |

[0001571996-19-000025:notes:158]
Covenants and Unrestricted Net Assets — The credit agreement for the Senior Secured Credit Facilities contains customary negative covenants that generally limit the ability of Denali Intermediate Inc., a wholly-owned subsidiary of Dell Technologies (“Dell Intermediate”), Dell, and Dell’s and Denali Intermediate’s other restricted subsidiaries to incur debt, create liens, make fundamental changes, enter into asset sales, make certain investments, pay dividends or distribute or redeem certain equity interests, prepay or redeem certain debt, and enter into certain transactions with affiliates.  The indenture governing the Senior Notes contains customary negative covenants that generally limit the ability of Denali Intermediate, Dell, and Dell’s and Denali Intermediate’s other restricted subsidiaries to incur additional debt or issue certain preferred shares, pay dividends on or make other distributions in respect of capital stock or make other restricted payments, make certain investments, sell or transfer certain assets, create liens on certain assets to secure debt, consolidate, merge, sell, or otherwise dispose of all or substantially all assets, enter into certain transactions with affiliates, and designate subsidiaries as unrestricted subsidiaries.

[0001571996-19-000025:notes:159]
The negative covenants under such credit agreements and indenture are subject to certain exceptions, qualifications, and “baskets.”  The indentures governing the First Lien Notes, the Unsecured Notes and Debentures, and the EMC Notes variously impose limitations, subject to specified exceptions, on creating certain liens, entering into sale and lease-back transactions, and entering into certain asset sales.  The foregoing credit agreements and indentures contain customary events of default, including failure to make required payments, failure to comply with covenants, and the occurrence of certain events of bankruptcy and insolvency.

[0001571996-19-000025:notes:160]
As of May 3, 2019, the Company had certain consolidated subsidiaries that were designated as unrestricted subsidiaries for all purposes of the applicable credit agreements and the indentures governing the First Lien Notes and the Senior Notes.  Substantially all of the net assets of the Company’s consolidated subsidiaries were restricted, with the exception of the Company’s unrestricted subsidiaries, primarily VMware Inc., Secureworks, Pivotal, and their respective subsidiaries, as of May 3, 2019.

[0001571996-19-000025:notes:161]
The Term Loan A-2 Facility, the Term Loan A-4 Facility, the Term Loan A-6 Facility, and the Revolving Credit Facility are subject to a first lien leverage ratio covenant that is tested at the end of each fiscal quarter of Dell with respect to Dell’s preceding four fiscal quarters.  The Company was in compliance with all financial covenants as of May 3, 2019.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001571996-19-000025:notes:162]
[same as prior period, unchanged from 0001571996-18-000044:notes:176]

[0001571996-19-000025:notes:163]
[same as prior period, unchanged from 0001571996-18-000044:notes:178]

[0001571996-19-000025:notes:164]
[same as prior period, unchanged from 0001571996-18-000044:notes:179]

[0001571996-19-000025:notes:165]
[same as prior period, unchanged from 0001571996-18-000044:notes:180]

[0001571996-19-000025:notes:166]
[same as prior period, unchanged from 0001571996-18-000044:notes:181]

[0001571996-19-000025:notes:167]
During the three months ended May 3, 2019 and May 4, 2018, the Company did not discontinue any cash flow hedges related to foreign exchange contracts that had a material impact on the Company’s results of operations due to the probability that the forecasted cash flows would not occur.

[0001571996-19-000025:notes:168]
[same as prior period, unchanged from 0001571996-18-000044:notes:183]

[0001571996-19-000025:notes:169]
In connection with expanded offerings of DFS in Europe, forward contracts are used to hedge financing receivables denominated in foreign currencies.  These contracts are not designated for hedge accounting and most expire within three years or less.

[0001571996-19-000025:notes:170]
[same as prior period, unchanged from 0001571996-18-000044:notes:185]

[0001571996-19-000025:notes:171]
[same as prior period, unchanged from 0001571996-18-000044:notes:186]

[0001571996-19-000025:notes:172]
[same as prior period, unchanged from 0001571996-18-000044:notes:187]

[0001571996-19-000025:notes:173]
The Company utilizes cross currency amortizing swaps to hedge the currency and interest rate risk exposure associated with the securitization program that was established in Europe in January 2017.  The cross currency swaps combine a Euro-based interest rate swap with a British Pound or U.S. Dollar foreign exchange forward contract in which the Company pays a fixed British Pound or U.S. Dollar amount and receives a floating amount in Euros linked to the one-month Euribor.  The notional value of the swaps amortizes in line with the expected cash flows and run-off of the securitized assets.  The swaps are not designated for hedge accounting and expire within five years or less.

[0001571996-19-000025:notes:174]
[same as prior period, unchanged from 0001571996-18-000044:notes:177]

[0001571996-19-000025:notes:175]
[same as prior period, unchanged from 0001571996-18-000044:notes:189]

[0001571996-19-000025:notes:176]
|  | May 3, 2019 |  | February 1, 2019 |
|  | (in millions) |
| Foreign exchange contracts: |  |  |  |  |  |
| Designated as cash flow hedging instruments | $ | 7,915 |  |  | $ | 7,573 |  |
| Non-designated as hedging instruments | 5,894 |  |  | 6,129 |  |
| Total | $ | 13,809 |  |  | $ | 13,702 |  |
| Interest rate contracts: |  |  |  |
| Non-designated as hedging instruments | $ | 2,582 |  |  | $ | 2,674 |  |

[0001571996-19-000025:notes:177]
[same as prior period, unchanged from 0001571996-18-000044:notes:192]

[0001571996-19-000025:notes:178]
| Derivatives in Cash Flow Hedging Relationships |  | Gain (Loss) Recognized in Accumulated OCI, Net of Tax, on Derivatives |  | Location of Gain (Loss) Reclassified from Accumulated OCI into Income |  | Gain (Loss) Reclassified from Accumulated OCI into Income |
|  |  | (in millions) |  |  |  | (in millions) |
| For the three months ended May 3, 2019 |
|  |  |  |  |  | Total net revenue |  | $ | 58 |  |
| Foreign exchange contracts |  | $ | 152 |  |  | Total cost of net revenue |  | — |  |
| Interest rate contracts |  | — |  |  | Interest and other, net |  | — |  |
| Total |  | $ | 152 |  |  |  |  | $ | 58 |  |
| For the three months ended May 4, 2018 |
|  |  |  |  |  | Total net revenue |  | $ | (31 | ) |
| Foreign exchange contracts |  | $ | 121 |  |  | Total cost of net revenue |  | — |  |
| Interest rate contracts |  | — |  |  | Interest and other, net |  | — |  |
| Total |  | $ | 121 |  |  |  |  | $ | (31 | ) |

[0001571996-19-000025:notes:179]
Effect of Derivative Instruments Not Designated as Hedging Instruments on the Condensed Consolidated Statements of Income (Loss)

[0001571996-19-000025:notes:180]
|  | Three Months Ended |  |  |
|  | May 3, 2019 |  | May 4, 2018 |  | Location of Gain (Loss) Recognized |
|  | (in millions) |  |
| Foreign exchange contracts | $ | (66 | ) |  | $ | (43 | ) |  | Interest and other, net |
| Interest rate contracts | (7 | ) |  | 2 |  |  | Interest and other, net |
| Total | $ | (73 | ) |  | $ | (41 | ) |  |  |

[0001571996-19-000025:notes:181]
[same as prior period, unchanged from 0001571996-18-000044:notes:196]

[0001571996-19-000025:notes:182]
The Company presents its foreign exchange derivative instruments on a net basis in the Condensed Consolidated Statements of Financial Position due to the right of offset by its counterparties under master netting arrangements.  The following tables present the fair value of those derivative instruments presented on a gross basis as of the dates indicated:

[0001571996-19-000025:notes:183]
|  | May 3, 2019 |
|  | Other CurrentAssets |  | Other Non-Current Assets |  | Other CurrentLiabilities |  | Other Non-CurrentLiabilities |  | TotalFair Value |
|  |  |  | (in millions) |  |  |
| Derivatives designated as hedging instruments: |
| Foreign exchange contracts in an asset position | $ | 167 |  |  | $ | — |  |  | $ | 2 |  |  | $ | — |  |  | $ | 169 |  |
| Foreign exchange contracts in a liability position | (3 | ) |  | — |  |  | (1 | ) |  | — |  |  | (4 | ) |
| Net asset (liability) | 164 |  |  | — |  |  | 1 |  |  | — |  |  | 165 |  |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts in an asset position | 192 |  |  | — |  |  | 14 |  |  | — |  |  | 206 |  |
| Foreign exchange contracts in a liability position | (190 | ) |  | — |  |  | (26 | ) |  | (3 | ) |  | (219 | ) |
| Interest rate contracts in an asset position | — |  |  | 2 |  |  | — |  |  | — |  |  | 2 |  |
| Interest rate contracts in a liability position | — |  |  | — |  |  | — |  |  | (14 | ) |  | (14 | ) |
| Net asset (liability) | 2 |  |  | 2 |  |  | (12 | ) |  | (17 | ) |  | (25 | ) |
| Total derivatives at fair value | $ | 166 |  |  | $ | 2 |  |  | $ | (11 | ) |  | $ | (17 | ) |  | $ | 140 |  |
|  | February 1, 2019 |
|  | Other CurrentAssets |  | Other Non-Current Assets |  | Other CurrentLiabilities |  | Other Non-CurrentLiabilities |  | TotalFair Value |
|  |  |  | (in millions) |  |  |
| Derivatives designated as hedging instruments: |
| Foreign exchange contracts in an asset position | $ | 45 |  |  | $ | — |  |  | $ | 29 |  |  | $ | — |  |  | $ | 74 |  |
| Foreign exchange contracts in a liability position | (19 | ) |  | — |  |  | (20 | ) |  | — |  |  | (39 | ) |
| Net asset (liability) | 26 |  |  | — |  |  | 9 |  |  | — |  |  | 35 |  |
| Derivatives not designated as hedging instruments: |
| Foreign exchange contracts in an asset position | 178 |  |  | — |  |  | 57 |  |  | — |  |  | 235 |  |
| Foreign exchange contracts in a liability position | (110 | ) |  | — |  |  | (115 | ) |  | (2 | ) |  | (227 | ) |
| Interest rate contracts in an asset position | — |  |  | 3 |  |  | — |  |  | — |  |  | 3 |  |
| Interest rate contracts in a liability position | — |  |  | — |  |  | — |  |  | (9 | ) |  | (9 | ) |
| Net asset (liability) | 68 |  |  | 3 |  |  | (58 | ) |  | (11 | ) |  | 2 |  |
| Total derivatives at fair value | $ | 94 |  |  | $ | 3 |  |  | $ | (49 | ) |  | $ | (11 | ) |  | $ | 37 |  |

[0001571996-19-000025:notes:184]
The following tables present the gross amounts of the Company’s derivative instruments, amounts offset due to master netting agreements with the Company’s counterparties, and the net amounts recognized in the Condensed Consolidated Statements of Financial Position as of the dates indicated:

[0001571996-19-000025:notes:185]
|  | May 3, 2019 |
|  | Gross Amounts of Recognized Assets/ (Liabilities) |  | Gross Amounts Offset in the Statement of Financial Position |  | Net Amounts of Assets/ (Liabilities) Presented in the Statement of Financial Position |  | Gross Amounts not Offset in the Statement of Financial Position |  | Net Amount |
|  | Financial Instruments |  | Cash Collateral Received or Pledged |  |
|  | (in millions) |
| Derivative instruments: |  |  |  |  |  |  |  |  |  |  |  |
| Financial assets | $ | 377 |  |  | $ | (209 | ) |  | $ | 168 |  |  | $ | — |  |  | $ | — |  |  | $ | 168 |  |
| Financial liabilities | (237 | ) |  | 209 |  |  | (28 | ) |  | — |  |  | 6 |  |  | (22 | ) |
| Total derivative instruments | $ | 140 |  |  | $ | — |  |  | $ | 140 |  |  | $ | — |  |  | $ | 6 |  |  | $ | 146 |  |
|  | February 1, 2019 |
|  | Gross Amounts of Recognized Assets/ (Liabilities) |  | Gross Amounts Offset in the Statement of Financial Position |  | Net Amounts of Assets/ (Liabilities) Presented in the Statement of Financial Position |  | Gross Amounts not Offset in the Statement of Financial Position |  | Net Amount |
|  | Financial Instruments |  | Cash Collateral Received or Pledged |  |
|  | (in millions) |
| Derivative instruments: |  |  |  |  |  |  |  |  |  |  |  |
| Financial assets | $ | 312 |  |  | $ | (215 | ) |  | $ | 97 |  |  | $ | — |  |  | $ | — |  |  | $ | 97 |  |
| Financial liabilities | (275 | ) |  | 215 |  |  | (60 | ) |  | — |  |  | 4 |  |  | (56 | ) |
| Total derivative instruments | $ | 37 |  |  | $ | — |  |  | $ | 37 |  |  | $ | — |  |  | $ | 4 |  |  | $ | 41 |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001571996-19-000025:notes:186]
[same as prior period, unchanged from 0001571996-18-000044:notes:201]

[0001571996-19-000025:notes:187]
[same as prior period, unchanged from 0001571996-18-000044:notes:202]

[0001571996-19-000025:notes:188]
The following table presents goodwill allocated to the Company’s business segments and changes in the carrying amount of goodwill as of the dates indicated:

[0001571996-19-000025:notes:189]
|  | Infrastructure Solutions Group |  | Client Solutions Group |  | VMware |  | Other Businesses (a) |  | Total |
|  | (in millions) |
| Balance as of February 1, 2019 | $ | 15,199 |  |  | $ | 4,237 |  |  | $ | 16,419 |  |  | $ | 4,234 |  |  | $ | 40,089 |  |
| Goodwill acquired (b) | — |  |  | — |  |  | 33 |  |  | — |  |  | 33 |  |
| Impact of foreign currency translation | (89 | ) |  | — |  |  | — |  |  | (18 | ) |  | (107 | ) |
| Balance as of May 3, 2019 | $ | 15,110 |  |  | $ | 4,237 |  |  | $ | 16,452 |  |  | $ | 4,216 |  |  | $ | 40,015 |  |

[0001571996-19-000025:notes:190]
(a)  Other Businesses consists of offerings by Pivotal, Secureworks, RSA Security LLC (“RSA Security”), Virtustream Group Holdings, Inc. (“Virtustream”), and Boomi, Inc. (“Boomi”).

[0001571996-19-000025:notes:191]
(b)  VMware, Inc. completed the acquisition of AetherPal Inc. for a total purchase price of $45 million.

[0001571996-19-000025:notes:192]
Goodwill and indefinite-lived intangible assets are tested for impairment annually during the third fiscal quarter and whenever events or circumstances may indicate that an impairment has occurred.  Based on the results of the annual impairment test performed for the fiscal year ended February 1, 2019, which was a quantitative test for all goodwill reporting units, the fair values of each of the reporting units, except for the Virtustream reporting unit, exceeded their carrying values.  Virtustream’s results, which are reported within the Company’s Other Businesses, do not meet the requirements for a reportable segment and are not material to the Company’s overall results.  See Note 18 of the Notes to the Condensed Consolidated Financial Statements for additional segment information.

[0001571996-19-000025:notes:193]
Virtustream delivers an application management cloud platform for enterprise mission-critical workloads in the Infrastructure-as-a-Service market, and had approximately $0.4 billion in goodwill that was derived from the EMC merger transaction during the fiscal year ended February 3, 2017.  Virtustream forecasts were revised downward due to a resetting of the longer-term business model that is focused on a streamlined product portfolio.

[0001571996-19-000025:notes:194]
Based on the results of the annual impairment test performed for the fiscal year ended February 1, 2019, it was determined that the carrying value of the Virtustream reporting unit exceeded its fair value, and, as such, a goodwill impairment charge of approximately $190 million was recognized during the three months ended November 2, 2018.  This expense was classified in selling, general, and administrative in the Consolidated Statements of Income (Loss).  The impairment was reflected as a reduction in goodwill of approximately $190 million in the Consolidated Statements of Financial Position as of February 1, 2019.  The remaining Virtustream goodwill was approximately $200 million, inclusive of the impact of foreign currency translation, as of both May 3, 2019 and February 1, 2019.  Management continues to monitor the Virtustream goodwill reporting unit and consider potential impacts to the impairment assessment.

[0001571996-19-000025:notes:195]
As a result of the annual impairment test, it was determined that the excess of fair value over carrying amount was less than 20% for the RSA Security reporting unit, which had an excess of fair value over carrying amount of 11% as of November 2, 2018.  Management continues to monitor the RSA Security goodwill reporting unit and consider potential impacts to the impairment assessment.

[0001571996-19-000025:notes:196]
Additionally, as a result of the Class V transaction described in Note 14 of the Notes to the Condensed Consolidated Financial Statements, the Company performed an interim impairment analysis during the three months ended February 1, 2019 given the availability of market data for the fair value of the Class C Common Stock. Other than those disclosed during the Company’s annual goodwill impairment test during the three months ended November 2, 2018, there were no impairment indicators resulting from the interim impairment analysis. No events or circumstances transpired subsequent to this interim impairment analysis test that would indicate a potential impairment of goodwill as of May 3, 2019.

[0001571996-19-000025:notes:197]
Management exercised significant judgment related to the above assessments, including the identification of goodwill reporting units, assignment of assets and liabilities to goodwill reporting units, assignment of goodwill to reporting units, and determination of the fair value of each goodwill reporting unit.  The fair value of each goodwill reporting unit is generally estimated using a combination of public company multiples and discounted cash flow methodologies, unless the reporting unit relates to a publicly traded entity (VMware, Inc., Pivotal, or Secureworks), in which case the fair value is determined based primarily on the public company market valuation.  The discounted cash flow and public company multiples methodologies require significant judgment, including estimation of future cash flows, which is dependent on internal forecasts, current and anticipated economic conditions and trends, selection of market multiples through assessment of the reporting unit’s performance relative to peer competitors, the estimation of the long-term growth rate of the Company’s business, and the determination of the Company’s weighted average cost of capital.  Changes in these estimates and assumptions could materially affect the fair value of the goodwill reporting unit, potentially resulting in a non-cash impairment charge.

[0001571996-19-000025:notes:198]
[same as prior period, unchanged from 0001571996-18-000044:notes:218]

[0001571996-19-000025:notes:199]
The following table presents the Company’s intangible assets as of the dates indicated:

[0001571996-19-000025:notes:200]
|  | May 3, 2019 |  | February 1, 2019 |
|  | Gross |  | AccumulatedAmortization |  | Net |  | Gross |  | AccumulatedAmortization |  | Net |
|  | (in millions) |
| Customer relationships | $ | 22,755 |  |  | $ | (12,350 | ) |  | $ | 10,405 |  |  | $ | 22,750 |  |  | $ | (11,703 | ) |  | $ | 11,047 |  |
| Developed technology | 15,707 |  |  | (9,549 | ) |  | 6,158 |  |  | 15,701 |  |  | (9,036 | ) |  | 6,665 |  |
| Trade names | 1,291 |  |  | (661 | ) |  | 630 |  |  | 1,291 |  |  | (606 | ) |  | 685 |  |
| Leasehold assets (liabilities) | — |  |  | — |  |  | — |  |  | 128 |  |  | (10 | ) |  | 118 |  |
| Definite-lived intangible assets | 39,753 |  |  | (22,560 | ) |  | 17,193 |  |  | 39,870 |  |  | (21,355 | ) |  | 18,515 |  |
| Indefinite-lived trade names | 3,755 |  |  | — |  |  | 3,755 |  |  | 3,755 |  |  | — |  |  | 3,755 |  |
| Total intangible assets | $ | 43,508 |  |  | $ | (22,560 | ) |  | $ | 20,948 |  |  | $ | 43,625 |  |  | $ | (21,355 | ) |  | $ | 22,270 |  |

[0001571996-19-000025:notes:201]
Amortization expense related to definite-lived intangible assets was approximately $1.2 billion and $1.5 billion for the three months ended May 3, 2019 and May 4, 2018, respectively.  There were no material impairment charges related to intangible assets during the three months ended May 3, 2019 and May 4, 2018.  Due to the adoption of the new lease standard discussed in Note 1 and Note 2 of the Notes to the Condensed Consolidated Financial Statements, the Company derecognized all intangible leasehold assets and adjusted the carrying amount of the ROU assets by a corresponding amount as of February 2, 2019.

[0001571996-19-000025:notes:202]
Based on the results of the annual impairment test performed for the fiscal year ended February 1, 2019, the Virtustream definite-lived intangible assets were tested for impairment using a quantitative analysis, and due to the Virtustream business changes discussed above, no impairment was identified.

[0001571996-19-000025:notes:203]
The following table presents the estimated future annual pre-tax amortization expense of definite-lived intangible assets:

[0001571996-19-000025:notes:204]
| Fiscal Years | (in millions) |
| 2020 (remaining nine months) | $ | 3,172 |  |
| 2021 | 3,360 |  |
| 2022 | 2,649 |  |
| 2023 | 1,762 |  |
| 2024 | 1,399 |  |
| Thereafter | 4,851 |  |
| Total | $ | 17,193 |  |


## us-gaap:DeferredRevenueDisclosureTextBlock

[0001571996-19-000025:notes:205]
[same as prior period, unchanged from 0001571996-18-000044:notes:225]

[0001571996-19-000025:notes:206]
[same as prior period, unchanged from 0001571996-18-000044:notes:226]

[0001571996-19-000025:notes:207]
The following table presents the changes in the Company’s deferred revenue for the periods indicated:

[0001571996-19-000025:notes:208]
|  | Three Months Ended |
|  | May 3, 2019 |  | May 4, 2018 |
|  | (in millions) |
| Deferred revenue: |  |  |  |
| Deferred revenue at beginning of period | $ | 24,010 |  |  | $ | 20,816 |  |
| Revenue deferrals for new contracts and changes in estimates for pre-existing contracts (a) (b) | 4,900 |  |  | 4,325 |  |
| Revenue recognized | (4,732 | ) |  | (4,182 | ) |
| Deferred revenue at end of period | $ | 24,178 |  |  | $ | 20,959 |  |
| Short-term deferred revenue | $ | 13,043 |  |  | $ | 11,495 |  |
| Long-term deferred revenue | $ | 11,135 |  |  | $ | 9,464 |  |

[0001571996-19-000025:notes:209]
[same as prior period, unchanged from 0001571996-18-000044:notes:229]

[0001571996-19-000025:notes:210]
| (b) | The Company conformed the presentation of certain deferred revenue rollforward activity for the three months ended May 4, 2018 to align current year presentation. The beginning and ending deferred revenue liability balances remain unchanged. |

[0001571996-19-000025:notes:211]
[same as prior period, unchanged from 0001571996-18-000044:notes:230]

[0001571996-19-000025:notes:212]
[same as prior period, unchanged from 0001571996-18-000044:notes:231]

[0001571996-19-000025:notes:213]
[same as prior period, unchanged from 0001571996-18-000044:notes:232]

[0001571996-19-000025:notes:214]
[same as prior period, unchanged from 0001571996-18-000044:notes:233]

[0001571996-19-000025:notes:215]
The value of the transaction price allocated to remaining performance obligations as of May 3, 2019 was approximately $31 billion.  The Company expects to recognize approximately 62% of remaining performance obligations as revenue in the next twelve months, and the remainder thereafter.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001571996-19-000025:notes:216]
NOTE 10 — COMMITMENTS AND CONTINGENCIES

[0001571996-19-000025:notes:217]
Legal Matters

[0001571996-19-000025:notes:218]
The Company is involved in various claims, suits, assessments, investigations, and legal proceedings that arise from time to time in the ordinary course of its business, including those identified below, consisting of matters involving consumer, antitrust, tax, intellectual property, and other issues on a global basis.

[0001571996-19-000025:notes:219]
The Company accrues a liability when it believes that it is both probable that a liability has been incurred and that it can reasonably estimate the amount of the loss.  The Company reviews these accruals at least quarterly and adjusts them to reflect ongoing negotiations, settlements, rulings, advice of legal counsel, and other relevant information.  To the extent new information is obtained and the Company’s views on the probable outcomes of claims, suits, assessments, investigations, or legal proceedings change, changes in the Company’s accrued liabilities would be recorded in the period in which such a determination is made.  For some matters, the amount of liability is not probable or the amount cannot be reasonably estimated and therefore accruals have not been made.

[0001571996-19-000025:notes:220]
The following is a discussion of the Company’s significant legal matters and other proceedings:

[0001571996-19-000025:notes:221]
Securities Litigation — On May 21, 2014, a securities class action seeking compensatory damages was filed in the United States District Court for the Southern District of New York, captioned City of Pontiac General Employees’ Retirement System v. Dell Inc., et. al. (Case No. 1:14-cv-03644).  The action names as defendants Dell Inc. and certain current and former executive officers, and alleges that Dell made false and misleading statements about Dell’s financial results and future prospects between February 21, 2012 and May 22, 2012, which resulted in artificially inflated stock prices.  The case was transferred to the United States District Court for the Western District of Texas under the same caption (Case No. 1:15-cv-00374), where the defendants filed a motion to dismiss.  On September 16, 2016, the Court denied the motion to dismiss.  On March 29, 2018, the Court granted the plaintiffs’ motion for class certification, and certified a class consisting of all purchasers of Dell common stock between February 22, 2012 and May 22, 2012.  Fact and expert discovery is now closed.  Dell filed a motion for summary judgment on February 18, 2019, which is now fully-briefed and pending before the Court.  If the matter is not dismissed, a trial is currently set for October 2019.

[0001571996-19-000025:notes:222]
Class Actions Related to the Class V Transaction — Four purported stockholders brought putative class action complaints arising out of the Class V transaction described in Note 14 of the Notes to the Consolidated Financial Statements.  The actions were captioned Hallandale Beach Police and Fire Retirement Plan v. Michael Dell et al. (Civil Action No. 2018-0816-JTL), Howard Karp v. Michael Dell et al. (Civil Action No. 2019-0032-JTL), Miramar Police Officers’ Retirement Plan v. Michael Dell et al. (Civil Action No. 2019-0049-JTL), and Steamfitters Local 449 Pension Plan v. Michael Dell et al. (Civil Action No. 2019-0115-JTL).  The four actions were consolidated into In Re Dell Class V Litigation (Consol. C.A. No. 2018-0816-JTL), which names as defendants the Company’s board of directors and certain stockholders of the Company, including Michael S. Dell and entities through which Mr. Dell allegedly holds a portion of his and/or his family’s stock.  The plaintiffs generally allege that the defendants breached their fiduciary duties to the former holders of Class V Common Stock in connection with the Class V transaction by allegedly causing the Company to enter into a transaction that favored the interests of the controlling stockholders at the expense of such former stockholders.  The Defendants intend to file a motion to dismiss the action.

[0001571996-19-000025:notes:223]
Copyright Levies — The Company is involved in various proceedings and negotiations regarding Dell’s obligation to collect and remit copyright levies in certain European Union (“EU”) countries.  The Company continues to collect levies in EU countries where it has determined that local laws require payment.  The Company, along with other companies and/or industry associations, also continues to oppose levy schemes that do not comply with EU law.  The Company does not currently anticipate that any of these matters will have a material adverse effect on its business, financial condition, results of operations, or cash flows.

[0001571996-19-000025:notes:224]
Other Litigation — The various legal proceedings in which Dell is involved include commercial and intellectual property litigation.  Dell does not currently anticipate that any of these matters will have a material adverse effect on its business, financial condition, results of operations, or cash flows.

[0001571996-19-000025:notes:225]
As of May 3, 2019, the Company does not believe there is a reasonable possibility that a material loss exceeding the amounts already accrued for these or other proceedings or matters has been incurred.  However, since the ultimate resolution of any such proceedings and matters is inherently unpredictable, the Company’s business, financial condition, results of operations, or cash flows could be materially affected in any particular period by unfavorable outcomes in one or more of these proceedings or matters.  Whether the outcome of any claim, suit, assessment, investigation, or legal proceeding, individually or collectively, could have a material adverse effect on the Company’s business, financial condition, results of operations, or cash flows will depend on a number of variables, including the nature, timing, and amount of any associated expenses, amounts paid in settlement, damages, or other remedies or consequences.

[0001571996-19-000025:notes:226]
Indemnifications

[0001571996-19-000025:notes:227]
In the ordinary course of business, the Company enters into contractual arrangements under which it may agree to indemnify the third party to such arrangements from any losses incurred relating to the services it performs on behalf of the Company or for losses arising from certain events as defined in the particular contract, such as litigation or claims relating to past performance.  Such indemnification obligations may not be subject to maximum loss clauses.  Historically, payments related to these indemnifications have not been material to the Company.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001571996-19-000025:notes:228]
NOTE 11 — INCOME AND OTHER TAXES

[0001571996-19-000025:notes:229]
For the three months ended May 3, 2019 and May 4, 2018, the Company’s effective income tax rates were 330.1% and 13.6%, respectively, on pre-tax losses of $143 million and $623 million, respectively.  The change in the Company’s effective tax rate is primarily driven by discrete tax benefits and a change in the Company’s jurisdictional mix of income.  The Company’s effective tax rate for the three months ended May 4, 2018 includes $154 million of discrete tax benefits resulting from the impact of its adoption during the quarter of the new revenue recognition standard.  For the three months ended May 3, 2019, the Company’s effective tax rate includes a discrete tax benefit for $405 million resulting from an intra-entity asset transfer that was completed during the quarter.  The tax benefit represents the future amortization the Company will be able to realize over a period of no more than 15 years and is recorded as a deferred tax asset in the period of the transaction.  On May 31, 2019, the Company’s VMware business unit completed a similar transaction and transferred certain of its intellectual property to its Irish subsidiary.  In the second quarter of Fiscal 2020, the Company will record a discrete tax benefit of approximately $4.5 billion for this transaction that represents the future amortization the Company will be able to realize for this intellectual property.  The Company is evaluating the impact that this transaction will have on the Company’s estimated annual effective tax rate.

[0001571996-19-000025:notes:230]
The Tax Cuts and Jobs Act of 2017 (“U.S. Tax Reform”) was signed into law on December 22, 2017.  Among other things, U.S. Tax Reform lowers the U.S. corporate income tax rate to 21% from 35%, establishes a modified territorial system requiring a mandatory deemed repatriation tax on undistributed earnings of foreign subsidiaries, requires a minimum tax on certain future earnings generated by foreign subsidiaries while providing for future tax-free repatriation of earnings through a 100% dividends-received deduction, and places limitations on the deductibility of net interest expense.  The Company anticipates that the U.S. Department of the Treasury and the Internal Revenue Service (“IRS”) will continue to issue regulatory guidance clarifying certain provisions of U.S. Tax Reform.  When additional guidance is issued, the Company will recognize the related tax impact in the fiscal quarter of such issuance.

[0001571996-19-000025:notes:231]
The differences between the estimated effective income tax rates and the U.S. federal statutory rate of 21% principally result from the Company’s geographical distribution of income and differences between the book and tax treatment of certain items.  In certain jurisdictions, the Company’s tax rate is significantly less than the applicable statutory rate as a result of tax holidays.  The majority of the Company’s foreign income that is subject to these tax holidays and lower tax rates is attributable to Singapore, China, and Malaysia.  A significant portion of these income tax benefits relates to a tax holiday that will be effective until January 31, 2029.  The Company’s other tax holidays will expire in whole or in part during fiscal years 2022 through 2030.  Many of these tax holidays and reduced tax rates may be extended when certain conditions are met or may be terminated early if certain conditions are not met.

[0001571996-19-000025:notes:232]
The Company’s U.S. federal income tax returns for fiscal years 2007 through 2009 are currently under consideration by the Office of Appeals of the IRS.  The IRS issued a Revenue Agent’s Report (“RAR”) related to those years during the fiscal year ended February 3, 2017.  The IRS has proposed adjustments primarily relating to transfer pricing matters with which the Company disagrees and has been contesting through the IRS administrative appeals process.  Although this process has been progressing and the timing of any resolution remains uncertain, the Company anticipates reaching a settlement with the IRS before the end of the current fiscal year.  In May 2017, the IRS commenced a federal income tax audit for fiscal years 2010 through 2014, for which the Company expects to receive a RAR in early 2020.

[0001571996-19-000025:notes:233]
[same as prior period, unchanged from 0001571996-18-000044:notes:263]

[0001571996-19-000025:notes:234]
Judgment is required in evaluating the Company’s uncertain tax positions and determining the Company’s provision for income taxes.  The unrecognized tax benefits were $3.4 billion as of both May 3, 2019 and February 1, 2019 and are included in accrued and other and other non-current liabilities in the Condensed Consolidated Statements of Financial Position.  Although timing of resolution or closure of audits is not certain, the Company believes it is reasonably possible that certain tax matters in various jurisdictions, including those matters discussed above, could be concluded within the next 12 months.  The resolution of these audits could reduce the Company’s unrecognized tax benefits by an estimated amount of between $500 million to $800 million.  Such a reduction will have a material effect on the Company’s effective tax rate.

[0001571996-19-000025:notes:235]
The Company takes certain non-income tax positions in the jurisdictions in which it operates and has received certain non-income tax assessments from various jurisdictions.  The Company believes that a material loss in these matters is not probable and that it is not reasonably possible that a material loss exceeding amounts already accrued has been incurred.  The Company believes its positions in these non-income tax litigation matters are supportable and that it ultimately will prevail in the matters.  In the normal course of business, the Company’s positions and conclusions related to its non-income taxes could be challenged and assessments may be made.  To the extent new information is obtained and the Company’s views on its positions, probable outcomes of assessments, or litigation change, changes in estimates to the Company’s accrued liabilities would be recorded in the period in which such a determination is made.  In the resolution process for income tax and non-income tax audits, the Company is required in certain situations to provide collateral guarantees or indemnification to regulators and tax authorities until the matter is resolved.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001571996-19-000025:notes:236]
NOTE 12 — ACCUMULATED OTHER COMPREHENSIVE INCOME (LOSS)

[0001571996-19-000025:notes:237]
Accumulated other comprehensive income (loss) is presented in stockholders’ equity (deficit) in the Condensed Consolidated Statements of Financial Position and consists of amounts related to foreign currency translation adjustments, unrealized net gains (losses) on investments, unrealized net gains (losses) on cash flow hedges, and actuarial net gains (losses) from pension and other postretirement plans.

[0001571996-19-000025:notes:238]
The following table presents changes in accumulated other comprehensive income (loss), net of tax, by the following components as of the dates indicated:

[0001571996-19-000025:notes:239]
|  | Foreign Currency Translation Adjustments |  | Investments |  | Cash Flow Hedges |  | Pension and Other Postretirement Plans |  | Accumulated Other Comprehensive Income (Loss) |
|  | (in millions) |
| Balances as of February 1, 2019 | $ | (452 | ) |  | $ | — |  |  | $ | (29 | ) |  | $ | 14 |  |  | $ | (467 | ) |
| Other comprehensive income (loss) before reclassifications | (158 | ) |  | — |  |  | 152 |  |  | 7 |  |  | 1 |  |
| Amounts reclassified from accumulated other comprehensive income (loss) | — |  |  | — |  |  | (58 | ) |  | — |  |  | (58 | ) |
| Total change for the period | (158 | ) |  | — |  |  | 94 |  |  | 7 |  |  | (57 | ) |
| Less: Change in comprehensive income attributable to non-controlling interests | — |  |  | — |  |  | 1 |  |  | — |  |  | 1 |  |
| Balances as of May 3, 2019 | $ | (610 | ) |  | $ | — |  |  | $ | 64 |  |  | $ | 21 |  |  | $ | (525 | ) |

[0001571996-19-000025:notes:240]
Amounts related to investments are reclassified to net income (loss) when gains and losses are realized.  See Note 3 of the Notes to the Condensed Consolidated Financial Statements for more information on the Company’s investments.  Amounts related to the Company’s cash flow hedges are reclassified to net income during the same period in which the items being hedged are recognized in earnings.  See Note 7 of the Notes to the Condensed Consolidated Financial Statements for more information on the Company’s derivative instruments.

[0001571996-19-000025:notes:241]
The following table presents reclassifications out of accumulated other comprehensive income (loss), net of tax, to net income (loss) for the periods indicated:

[0001571996-19-000025:notes:242]
|  | Three Months Ended |
|  | May 3, 2019 |  | May 4, 2018 |
|  | Investments |  | Cash Flow Hedges |  | Total |  | Investments |  | Cash Flow Hedges |  | Total |
|  | (in millions) |
| Total reclassifications, net of tax: |  |  |  |  |  |  |  |  |  |  |  |
| Net revenue | $ | — |  |  | $ | 58 |  |  | $ | 58 |  |  | $ | — |  |  | $ | (31 | ) |  | $ | (31 | ) |
| Cost of net revenue | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Interest and other, net | — |  |  | — |  |  | — |  |  | 1 |  |  | — |  |  | 1 |  |
| Total reclassifications, net of tax | $ | — |  |  | $ | 58 |  |  | $ | 58 |  |  | $ | 1 |  |  | $ | (31 | ) |  | $ | (30 | ) |


## us-gaap:MinorityInterestDisclosureTextBlock

[0001571996-19-000025:notes:243]
NOTE 13 — NON-CONTROLLING INTERESTS

[0001571996-19-000025:notes:244]
VMware, Inc. — The non-controlling interests’ share of equity in VMware, Inc. is reflected as a component of the non-controlling interests in the accompanying Condensed Consolidated Statements of Financial Position and was $3.7 billion and $3.8 billion as of May 3, 2019 and February 1, 2019, respectively.  As of May 3, 2019 and February 1, 2019, the Company held approximately 80.6% and 80.5%, respectively, of the outstanding equity interest in VMware, Inc.

[0001571996-19-000025:notes:245]
Pivotal — On April 24, 2018, Pivotal completed a registered underwritten IPO of its Class A common stock.  In conjunction with the IPO, all of Pivotal’s preferred equity shares were converted into shares of its common stock on a one-to-one basis, such that upon completion of its IPO, Pivotal’s outstanding capital stock consisted solely of common stock.  The non-controlling interests’ share of equity in Pivotal is reflected as a component of the non-controlling interest in the accompanying Condensed Consolidated Statements of Financial Position and was $1.0 billion as of May 3, 2019 and February 1, 2019.  As of May 3, 2019 and February 1, 2019, the Company held approximately 61.4% and 62.8%, respectively, of the outstanding equity interest in Pivotal.

[0001571996-19-000025:notes:246]
Secureworks — The non-controlling interests’ share of equity in Secureworks is reflected as a component of the non-controlling interests in the accompanying Condensed Consolidated Statements of Financial Position and was $91 million and $87 million as of May 3, 2019 and February 1, 2019, respectively.  As of May 3, 2019 and February 1, 2019, the Company held approximately 86.6% and 87.4%, respectively, of the outstanding equity interest in Secureworks, excluding restricted stock awards (“RSAs”).  As of May 3, 2019 and February 1, 2019, the Company held approximately 85.9% and 86.4%, respectively, of the outstanding equity interest in Secureworks, including RSAs.

[0001571996-19-000025:notes:247]
The following table presents the effect of changes in the Company’s ownership interest in VMware, Inc., Pivotal, and Secureworks on the Company’s equity for the period indicated:

[0001571996-19-000025:notes:248]
|  | Three Months Ended |
|  | May 3, 2019 |
|  | (in millions) |
| Net income attributable to Dell Technologies Inc. | $ | 293 |  |
| Transfers (to)/from the non-controlling interests: |  |
| Increase in Dell Technologies Inc. additional paid-in-capital for equity issuances and other equity activity | 204 |  |
| Decrease in Dell Technologies Inc. additional paid-in-capital for equity issuances and other equity activity | (600 | ) |
| Net transfers from non-controlling interests | (396 | ) |
| Change from net income attributable to Dell Technologies Inc. and transfers to the non-controlling interests | $ | (103 | ) |


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001571996-19-000025:notes:249]
NOTE 14 — CAPITALIZATION

[0001571996-19-000025:notes:250]
The following table presents the Company’s authorized, issued, and outstanding common stock as of the dates indicated:

[0001571996-19-000025:notes:251]
|  | Authorized |  | Issued |  | Outstanding |
|  | (in millions) |
| Common stock as of May 3, 2019 |
| Class A | 600 |  |  | 409 |  |  | 409 |  |
| Class B | 200 |  |  | 137 |  |  | 137 |  |
| Class C | 7,900 |  |  | 175 |  |  | 173 |  |
| Class D | 100 |  |  | — |  |  | — |  |
| Class V | 343 |  |  | — |  |  | — |  |
|  | 9,143 |  |  | 721 |  |  | 719 |  |
| Common stock as of February 1, 2019 |
| Class A | 600 |  |  | 410 |  |  | 410 |  |
| Class B | 200 |  |  | 137 |  |  | 137 |  |
| Class C | 7,900 |  |  | 174 |  |  | 172 |  |
| Class D | 100 |  |  | — |  |  | — |  |
| Class V | 343 |  |  | — |  |  | — |  |
|  | 9,143 |  |  | 721 |  |  | 719 |  |

[0001571996-19-000025:notes:252]
Under the Company’s certificate of incorporation as amended and restated upon the completion of the Class V transaction described below, the Company is prohibited from issuing any of the authorized shares of Class V Common Stock.

[0001571996-19-000025:notes:253]
[same as prior period, unchanged from 0001571996-18-000044:notes:295]

[0001571996-19-000025:notes:254]
The Company is authorized to issue one million shares of preferred stock, par value $0.01 per share.  As of May 3, 2019 and February 1, 2019, no shares of preferred stock were issued or outstanding.

[0001571996-19-000025:notes:255]
[same as prior period, unchanged from 0001571996-18-000044:notes:297]

[0001571996-19-000025:notes:256]
Common Stock for Fiscal 2020 and Thereafter

[0001571996-19-000025:notes:257]
Dell Technologies Common Stock — For fiscal periods beginning with the first quarter of Fiscal 2020, the Class A Common Stock, the Class B Common Stock, the Class C Common Stock, and the Class D Common Stock, formerly collectively referred to as the DHI Group Common Stock, are collectively referred to as Dell Technologies Common Stock.  The redesignation of such classes of common stock from DHI Group Common Stock to Dell Technologies Common Stock is intended to align the Company’s reporting with how such classes are referred to by securities analysts, investors, and other users of the financial statements since the completion on December 28, 2018 of the Class V transaction described below.  As a result of the cancellation of all outstanding Class V Common Stock upon the closing of that transaction, there is no requirement after the fourth quarter of Fiscal 2019 to allocate net income (loss) between two separate groups of common stock denoted the DHI Group Common Stock and the Class V Common Stock or to report earnings (loss) per share for each such group.  Accordingly, net income (loss), earnings (loss) per share and other relevant information will be reported for Dell Technologies Common Stock for all fiscal periods beginning with the first quarter of Fiscal 2020 and, because of lack of comparability with the new reporting, will be reported separately for the DHI Group and the Class V Common Stock, as applicable, for prior fiscal periods.  The par value for all classes of Dell Technologies Common Stock is $0.01 per share.  The Class A Common Stock, the Class B Common Stock, the Class C Common Stock, and the Class D Common Stock share equally in dividends declared or accumulated and have equal participation rights in undistributed earnings.

[0001571996-19-000025:notes:258]
Common Stock prior to Fiscal 2020

[0001571996-19-000025:notes:259]
DHI Group Common Stock and DHI Group — For the fiscal periods prior to the first quarter of Fiscal 2020, the Class A Common Stock, the Class B Common Stock, the Class C Common Stock, and the Class D Common Stock were collectively referred to as the DHI Group Common Stock.  All classes of DHI Group Common Stock have a par value of $0.01 per share and the Class A Common Stock, the Class B Common Stock, the Class C Common Stock, and the Class D Common Stock share equally in dividends declared or accumulated and have equal participation rights in undistributed earnings.  Prior to the completion on December 28, 2018 of the Class V transaction, the DHI Group referred to the direct and indirect interest of Dell Technologies in all of Dell Technologies’ business, assets, properties, liabilities, and preferred stock other than those attributable to the Class V Group, as well as the DHI Group’s retained interest in the Class V Group.  Subsequent to the completion of the Class V transaction, the DHI Group refers to all classes of issued and outstanding DHI Group Common Stock.

[0001571996-19-000025:notes:260]
Class V Common Stock and Class V Group — The Class V Common Stock was a class of common stock intended to track the performance of a portion of Dell Technologies’ economic interest in the Class V Group.  The Class V Group consisted solely of VMware, Inc. common stock held by the Company.  As of May 3, 2019, no shares of Class V Common Stock were outstanding.

[0001571996-19-000025:notes:261]
Voting Rights — Each holder of record of: (a) Class A Common Stock is entitled to ten votes per share of Class A Common Stock; (b) Class B Common Stock is entitled to ten votes per share of Class B Common Stock; (c) Class C Common Stock is entitled to one vote per share of Class C Common Stock; and (d) Class D Common Stock is not entitled to any vote on any matter except to the extent required by provisions of Delaware law (in which case such holder is entitled to one vote per share of Class D Common Stock).

[0001571996-19-000025:notes:262]
Conversion Rights — Under the Company’s certificate of incorporation, at any time and from time to time, any holder of Class A Common Stock or Class B Common Stock has the right to convert all or any of the shares of Class A Common Stock or Class B Common Stock, as applicable, held by such holder into shares of Class C Common Stock on a one-to-one basis.  During the three months ended May 3, 2019, the Company issued 998,419 shares of Class C Common Stock to nine stockholders upon the stockholders’ conversion of the same number of shares of Class A Common Stock into Class C Common Stock in accordance with the terms of the Company’s certificate of incorporation.

[0001571996-19-000025:notes:263]
[same as prior period, unchanged from 0001571996-18-000044:notes:312]

[0001571996-19-000025:notes:264]
On December 28, 2018, the Company completed a transaction (the “Class V transaction”) in which it paid $14.0 billion in cash and issued 149,387,617 shares of its Class C Common Stock to holders of the Class V Common Stock in exchange for all outstanding shares of Class V Common Stock.  The non-cash consideration portion of the Class V transaction totaled $6.9 billion.  As a result of the Class V transaction, the tracking stock feature of the Company’s capital structure associated with the Class V Common Stock was terminated.  The Class C Common Stock is traded on the New York Stock Exchange.

[0001571996-19-000025:notes:265]
The aggregate cash consideration and the fees and expenses incurred in connection with the Class V transaction were funded with proceeds of $3.67 billion from new term loans under the Company’s senior secured credit facilities, proceeds of a margin loan financing in an aggregate principal amount of $1.35 billion, proceeds of the Company’s pro-rata portion, in the amount of $8.87 billion, of a special $11 billion cash dividend paid by VMware, Inc. in connection with the Class V transaction, and cash on hand at Dell Technologies and its subsidiaries.  See Note 6 of the Notes to the Condensed Consolidated Financial Statements for information about the debt incurred by the Company to finance the Class V transaction.

[0001571996-19-000025:notes:266]
The merger pursuant to which the Class V transaction was effected and the Class V transaction have been accounted for as a hybrid liability and equity transaction involving the repurchase of outstanding common stock, with the consideration consisting of a variable combination of cash and shares.  Upon settlement, the accounting for the Class V transaction reflected that the outstanding Class V Common Stock was canceled and exchanged for shares of Class C Common Stock or $120.00 per share in cash or combination of cash and shares, depending on each holder’s election and subject to proration of the cash elections.  The variable nature of the cash obligation to repurchase the shares of Class V Common Stock required the Company to settle a portion of the shares in exchange for cash and therefore was accounted for as a financial instrument with an immaterial mark-to-market adjustment for the change in fair value from the date of the stockholder meeting at which the Company’s stockholders voted to approve the Class V transaction to the election deadline by which holders of Class V Common Stock elected the form of consideration for which they exchanged their shares.

[0001571996-19-000025:notes:267]
Repurchases of Common Stock

[0001571996-19-000025:notes:268]
[same as prior period, unchanged from 0001571996-18-000044:notes:308]

[0001571996-19-000025:notes:269]
Since the date of the EMC merger transaction, VMware, Inc.’s board of directors has authorized the repurchase of a total of $2.2 billion of VMware, Inc.’s Class A common stock, of which $243 million remained available as of May 3, 2019.  VMware, Inc. repurchased 3.3 million shares of its Class A common stock in the open market for approximately $591 million during the three months ended May 3, 2019.  During the three months ended May 4, 2018, VMware Inc. did not repurchase any shares of its Class A common stock.

[0001571996-19-000025:notes:270]
[same as prior period, unchanged from 0001571996-18-000044:notes:311]


## us-gaap:EarningsPerShareTextBlock

[0001571996-19-000025:notes:271]
[same as prior period, unchanged from 0001571996-18-000044:notes:279]

[0001571996-19-000025:notes:272]
[same as prior period, unchanged from 0001571996-18-000044:notes:280]

[0001571996-19-000025:notes:273]
Until the completion on December 28, 2018 of the Class V transaction described in Note 14 of the Notes to the Condensed Consolidated Financial Statements, the Company had two groups of common stock, denoted as the DHI Group Common Stock and the Class V Common Stock.

[0001571996-19-000025:notes:274]
The Class V Common Stock was a class of common stock intended to track the economic performance of 61% of the Company’s interest in the Class V Group, which consisted solely of VMware, Inc. common stock held by the Company.  Upon the completion of the Class V transaction, all outstanding shares of Class V Common Stock ceased to be outstanding, and the tracking stock structure was terminated.  The Class C Common Stock issued to former holders of the Class V Common Stock in the Class V transaction represents an interest in the Company’s entire business and, unlike the Class V Common Stock, is not intended to track the performance of any distinct assets or business.

[0001571996-19-000025:notes:275]
Prior to Fiscal 2020, the DHI Group Common Stock consists of the Class A Common Stock, the Class B Common Stock, the Class C Common Stock, and the Class D Common Stock.  The DHI Group referred to the direct and indirect interest of Dell Technologies in all of Dell Technologies’ business, assets, properties, liabilities, and preferred stock other than those attributable to the Class V Group, as well as the DHI Group’s retained interest in the Class V Group.

[0001571996-19-000025:notes:276]
For fiscal periods beginning with the first quarter of Fiscal 2020, the Class A Common Stock, the Class B Common Stock, the Class C Common Stock, and the Class D Common Stock, formerly collectively referred to as the DHI Group Common Stock, are collectively referred to as Dell Technologies Common Stock.  The redesignation of such classes of common stock from DHI Group Common Stock to Dell Technologies Common Stock is intended to align the Company’s reporting with how such classes are referred to by securities analysts, investors, and other users of the financial statements since the completion of the Class V transaction.  As a result of the cancellation of all outstanding Class V Common Stock upon the closing of that transaction, there is no requirement after the fourth quarter of Fiscal 2019 to allocate net income (loss) between two separate groups of common stock denoted DHI Group Common Stock and the Class V Common Stock or to report earnings (loss) per share measures for each such group.  Accordingly, net income (loss), earnings (loss) per share and other relevant information will be reported for Dell Technologies Common Stock for all fiscal periods beginning with the first quarter of Fiscal 2020 and, because of the lack of comparability with the new reporting, will be reported separately for the DHI Group and the Class V Common Stock, as applicable, for prior fiscal periods.

[0001571996-19-000025:notes:277]
For purposes of calculating earnings (loss) per share, the Company uses the two-class method.  As all classes of Dell Technologies Common Stock and DHI Group Common Stock share the same rights in dividends, basic and diluted earnings (loss) per share are the same for each class of both Dell Technologies Common Stock and DHI Group Common Stock.

[0001571996-19-000025:notes:278]
The following table presents the basic and diluted earnings (loss) per share for the periods indicated:

[0001571996-19-000025:notes:279]
|  | Three Months Ended |
|  | May 3, 2019 |  | May 4, 2018 |
| Earnings (loss) per share attributable to Dell Technologies Inc. - basic: |
| Dell Technologies Common Stock | $ | 0.41 |  |  |  |
| Class V Common Stock |  |  | $ | 2.36 |  |
| DHI Group |  |  | $ | (1.95 | ) |
| Earnings (loss) per share attributable to Dell Technologies Inc. - diluted: |
| Dell Technologies Common Stock | $ | 0.38 |  |  |  |
| Class V Common Stock |  |  | $ | 2.33 |  |
| DHI Group |  |  | $ | (1.95 | ) |

[0001571996-19-000025:notes:280]
The following table presents the computation of basic and diluted earnings (loss) per share for the period indicated:

[0001571996-19-000025:notes:281]
|  | Three Months Ended |
|  | May 3, 2019 |
|  | (in millions) |
| Numerator: Dell Technologies Common Stock |  |
| Net income attributable to Dell Technologies - basic | $ | 293 |  |
| Incremental dilution from VMware, Inc. attributable to Dell Technologies (a) | (8 | ) |
| Net income attributable to Dell Technologies - diluted | $ | 285 |  |
| Denominator: Dell Technologies Common Stock weighted-average shares outstanding |  |
| Weighted-average shares outstanding - basic | 717 |  |
| Dilutive effect of options, restricted stock units, restricted stock, and other | 34 |  |
| Weighted-average shares outstanding - diluted | 751 |  |
| Weighted-average shares outstanding - antidilutive | 6 |  |

[0001571996-19-000025:notes:282]
| (a) | The incremental dilution from VMware, Inc. represents the impact of VMware, Inc.’s dilutive securities on diluted earnings (loss) per share of Dell Technologies Common Stock, and is calculated by multiplying the difference between VMware, Inc.’s basic and diluted earnings (loss) per share by the number of shares of VMware, Inc. common stock held by the Company. |

[0001571996-19-000025:notes:283]
The following table presents the computation of basic and diluted earnings (loss) per share prior to Fiscal 2020:

[0001571996-19-000025:notes:284]
|  | Three Months Ended |
|  | May 4, 2018 |
|  | (in millions) |
| Numerator: Class V Common Stock |  |
| Net income attributable to Class V Common Stock - basic | $ | 470 |  |
| Incremental dilution from VMware, Inc. attributable to Class V Common Stock (a) | (7 | ) |
| Net income attributable to Class V Common Stock - diluted | $ | 463 |  |
| Numerator: DHI Group |  |
| Net loss attributable to DHI Group - basic | $ | (1,106 | ) |
| Incremental dilution from VMware, Inc. attributable to DHI Group (a) | (4 | ) |
| Net loss attributable to DHI Group - diluted | $ | (1,110 | ) |
| Denominator: Class V Common Stock weighted-average shares outstanding |  |  |
| Weighted-average shares outstanding - basic | 199 |  |
| Dilutive effect of options, restricted stock units, restricted stock, and other (b) | — |  |
| Weighted-average shares outstanding - diluted | 199 |  |
| Weighted-average shares outstanding - antidilutive (b) | — |  |
| Denominator: DHI Group weighted-average shares outstanding |  |
| Weighted-average shares outstanding - basic | 568 |  |
| Dilutive effect of options, restricted stock units, restricted stock, and other | — |  |
| Weighted-average shares outstanding - diluted | 568 |  |
| Weighted-average shares outstanding - antidilutive (c) | 34 |  |

[0001571996-19-000025:notes:285]
[same as prior period, unchanged from 0001571996-18-000044:notes:287]

[0001571996-19-000025:notes:286]
[same as prior period, unchanged from 0001571996-18-000044:notes:288]

[0001571996-19-000025:notes:287]
| (c) | Stock-based incentive awards have been excluded from the calculation of the DHI Group’s diluted loss per share because their effect would have been antidilutive, as the Company had a net loss as to the DHI Group for the periods presented. |

[0001571996-19-000025:notes:288]
The following table presents a reconciliation to the consolidated net loss attributable to Dell Technologies Inc. prior to Fiscal 2020:

[0001571996-19-000025:notes:289]
|  | Three Months Ended |
|  | May 4, 2018 |
|  | (in millions) |
| Net income attributable to Class V Common Stock (a) | $ | 470 |  |
| Net loss attributable to DHI Group | (1,106 | ) |
| Net loss attributable to Dell Technologies Inc. | $ | (636 | ) |

[0001571996-19-000025:notes:290]
(a)

[0001571996-19-000025:notes:291]
See Exhibit 99.1 filed with the Company’s Quarterly Report on Form 10-Q for the quarterly period ended May 4, 2018 for a reconciliation of VMware net income to net income attributable to Class V Common Stock.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001571996-19-000025:notes:292]
NOTE 16 — STOCK-BASED COMPENSATION

[0001571996-19-000025:notes:293]
Restricted Stock — During the three months ended May 3, 2019, the Company granted long-term incentive awards in the form of 9.7 million service-based restricted stock units (“RSUs”) and 1.9 million performance-based RSUs in order to align critical talent retention programs with the interests of holders of the Class C Common Stock.

[0001571996-19-000025:notes:294]
The service-based RSUs have a fair value based on the closing price of the Class C Common Stock price as reported on the New York Stock Exchange (“NYSE”) on the grant date. Most of such RSUs vest ratably over a three-year period.  Each service-based RSU represents the right to acquire one share of Class C Common Stock upon vesting.

[0001571996-19-000025:notes:295]
The performance-based RSUs are reflected at target units while the actual number of units that ultimately vest will range from 0% to 200% of target, based on the level of achievement of the performance goals and continued employment with the Company over a performance period ending March 14, 2022.  Approximately 0.9 million of the performance-based RSUs are subject to achievement of market-based performance goals based on relative total shareholder return.  For the non-market performance-based RSUs, the fair values will be based on the closing price of the Class C Common Stock as reported on the NYSE on the accounting grant date.  For the three months ended May 3, 2019, approximately one-third of the non-market performance awards have been valued and are considered outstanding for accounting purposes.  Market-based performance awards utilized a Monte Carlo valuation model to simulate the probabilities of achievement of relative total shareholder return in order to determine the awards’ fair value.

[0001571996-19-000025:notes:296]
The following table presents the assumptions utilized in the valuation model for the period indicated:

[0001571996-19-000025:notes:297]
|  | Three Months Ended |
|  | May 3, 2019 |
| Weighted-average grant date fair value | $ | 87.17 |  |
| Expected term (in years) | 3.0 |  |
| Risk-free rate (U.S. Government Treasury Note) | 2.4 | % |
| Expected volatility | 45 | % |
| Expected dividend yield | — | % |

[0001571996-19-000025:notes:298]
As of May 3, 2019, there were 19 million shares of Class C Common Stock available for future grants under the Dell Technologies Inc. 2013 Stock Incentive Plan.

[0001571996-19-000025:notes:299]
As of May 3, 2019, 16 million RSUs were outstanding, of which 5 million RSUs were subject to performance conditions.  The awards outstanding have a weighted-average grant date fair value of $49.58 per share and an aggregate intrinsic value of $1,069 million based on the closing price of the Class C Common Stock as reported on the NYSE on May 3, 2019.  As of May 3, 2019, there was $550 million of unrecognized stock-based compensation expense, net of estimated forfeitures, related to these awards expected to be recognized over a weighted-average period of approximately 2.8 years.


## us-gaap:ShareholdersEquityAndShareBasedPaymentsTextBlock

[0001571996-19-000025:notes:300]
[same as prior period, unchanged from 0001571996-18-000044:notes:322]

[0001571996-19-000025:notes:301]
[same as prior period, unchanged from 0001571996-18-000044:notes:323]

[0001571996-19-000025:notes:302]
[same as prior period, unchanged from 0001571996-18-000044:notes:324]

[0001571996-19-000025:notes:303]
| • | For stock appreciation rights, RSUs, or RSAs, any of which stock award types are subject to service requirements, the fair value of the share is multiplied by the portion of the share for which services have been rendered. |

[0001571996-19-000025:notes:304]
| • | For share-based arrangements that are subject to the occurrence of a contingent event, those amounts are not reclassified to temporary equity until the contingency has been satisfied. Contingent events include the achievement of performance-based metrics. |

[0001571996-19-000025:notes:305]
In connection with the Class V transaction described in Note 14 of the Notes to the Consolidated Financial Statements, the put feature provisions were amended to provide that the put feature will terminate two years after the expiration on June 27, 2019 of the post‑transaction lock‑up applicable to transfers of Dell Technologies securities, or earlier upon consummation of any underwritten public offering of shares of Class C Common Stock.

[0001571996-19-000025:notes:306]
The following table presents the amount of redeemable shares classified as temporary equity and summarizes the award type as of the dates presented:

[0001571996-19-000025:notes:307]
|  | May 3, 2019 |  | February 1, 2019 |
|  | (in millions) |
| Redeemable shares classified as temporary equity | $ | 1,774 |  |  | $ | 1,196 |  |
| Issued and outstanding unrestricted common shares | 3 |  |  | 3 |  |
| Restricted stock units | 3 |  |  | 1 |  |
| Restricted stock awards | 1 |  |  | — |  |
| Outstanding stock options | 31 |  |  | 31 |  |

[0001571996-19-000025:notes:308]
The increase in the value of redeemable shares during the three months ended May 3, 2019 was primarily attributable to an increase in Class C Common Stock fair value, as well as the reassessment of vesting of performance-based awards.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001571996-19-000025:notes:309]
[same as prior period, unchanged from 0001571996-18-000044:notes:330]

[0001571996-19-000025:notes:310]
[same as prior period, unchanged from 0001571996-18-000044:notes:331]

[0001571996-19-000025:notes:311]
ISG enables the digital transformation of the Company’s customers through its trusted multi-cloud and big data solutions, which are built upon a modern data center infrastructure.  The ISG comprehensive portfolio of advanced storage solutions includes traditional storage solutions as well as next-generation storage solutions (such as all-flash arrays, scale-out file, object platforms, and software-defined solutions), while the Company’s server portfolio includes high-performance rack, blade, tower, and hyperscale servers.  The ISG networking portfolio helps business customers transform and modernize their infrastructure, mobilize and enrich end-user experiences, and accelerate business applications and processes.  ISG also offers attached software, peripherals, and services, including support and deployment, configuration, and extended warranty services.

[0001571996-19-000025:notes:312]
CSG includes sales to commercial and consumer customers of branded hardware (such as desktops, workstations, and notebooks) and branded peripherals (such as displays and projectors), as well as services and third-party software and peripherals.  CSG also offers attached software, peripherals, and services, including support and deployment, configuration, and extended warranty services.

[0001571996-19-000025:notes:313]
VMware works with customers in the areas of hybrid cloud, multi-cloud, modern applications, networking and security, and digital workspaces, helping customers manage their IT resources across private clouds and complex multi-cloud, multi-device environments. VMware solutions provide a flexible digital foundation to enable the digital transformation of VMware’s customers as they ready their applications, infrastructure, and devices for their future business needs.

[0001571996-19-000025:notes:314]
The reportable segments disclosed herein are based on information reviewed by the Company’s management to evaluate the business segment results.  The Company’s measure of segment operating income for management reporting purposes excludes the impact of Other businesses, purchase accounting, amortization of intangible assets, unallocated corporate transactions, severance and facility action costs, stock-based compensation expense, and transaction-related expenses.  The Company does not allocate assets to the above reportable segments for internal reporting purposes.

[0001571996-19-000025:notes:315]
The following table presents a reconciliation of net revenue by the Company’s reportable segments to the Company’s consolidated net revenue as well as a reconciliation of consolidated segment operating income to the Company’s consolidated operating income (loss) for the periods indicated:

[0001571996-19-000025:notes:316]
|  | Three Months Ended |
|  | May 3, 2019 |  | May 4, 2018 |
|  | (in millions) |
| Consolidated net revenue: |  |  |  |  |
| Infrastructure Solutions Group | $ | 8,202 |  |  | $ | 8,667 |  |
| Client Solutions Group | 10,910 |  |  | 10,271 |  |
| VMware | 2,282 |  |  | 2,028 |  |
| Reportable segment net revenue | 21,394 |  |  | 20,966 |  |
| Other businesses (a) | 596 |  |  | 579 |  |
| Unallocated transactions (b) | — |  |  | (2 | ) |
| Impact of purchase accounting (c) | (82 | ) |  | (187 | ) |
| Total consolidated net revenue | $ | 21,908 |  |  | $ | 21,356 |  |
| Consolidated operating income (loss): |  |  |  |
| Infrastructure Solutions Group | $ | 843 |  |  | $ | 939 |  |
| Client Solutions Group | 793 |  |  | 533 |  |
| VMware | 614 |  |  | 613 |  |
| Reportable segment operating income | 2,250 |  |  | 2,085 |  |
| Other businesses (a) | (53 | ) |  | (50 | ) |
| Unallocated transactions (b) | (1 | ) |  | (9 | ) |
| Impact of purchase accounting (c) | (101 | ) |  | (222 | ) |
| Amortization of intangibles | (1,217 | ) |  | (1,522 | ) |
| Transaction-related expenses (d) | (42 | ) |  | (166 | ) |
| Stock-based compensation expense (e) | (263 | ) |  | (199 | ) |
| Other corporate expenses (f) | (23 | ) |  | (70 | ) |
| Total consolidated operating income (loss) | $ | 550 |  |  | $ | (153 | ) |

[0001571996-19-000025:notes:317]
| (a) | Pivotal, Secureworks, RSA Security, Virtustream, and Boomi constitute “Other businesses” and do not meet the requirements for a reportable segment, either individually or collectively. The results of Other businesses are not material to the Company’s overall results. |

[0001571996-19-000025:notes:318]
[same as prior period, unchanged from 0001571996-18-000044:notes:339]

[0001571996-19-000025:notes:319]
[same as prior period, unchanged from 0001571996-18-000044:notes:340]

[0001571996-19-000025:notes:320]
| (d) | Transaction-related expenses includes acquisition, integration, and divestiture related costs, as well as the costs incurred in the Class V transaction. |

[0001571996-19-000025:notes:321]
| (e) | Stock-based compensation expense consists of equity awards granted based on the estimated fair value of those awards at grant date. |

[0001571996-19-000025:notes:322]
| (f) | Other corporate expenses includes severance and facility action costs. |

[0001571996-19-000025:notes:323]
The following table presents the disaggregation of net revenue by reportable segment, and by major product categories within the segments for the periods indicated:

[0001571996-19-000025:notes:324]
|  | Three Months Ended |
|  | May 3, 2019 |  | May 4, 2018 |
|  | (in millions) |
| Net revenue: |  |  |  |  |  |
| Infrastructure Solutions Group: |  |  |  |
| Servers and networking | $ | 4,180 |  |  | $ | 4,585 |  |
| Storage | 4,022 |  |  | 4,082 |  |
| Total ISG net revenue | 8,202 |  |  | 8,667 |  |
| Client Solutions Group: |  |  |  |
| Commercial | 8,307 |  |  | 7,363 |  |
| Consumer | 2,603 |  |  | 2,908 |  |
| Total CSG net revenue | 10,910 |  |  | 10,271 |  |
| VMware: |  |  |  |
| Total VMware net revenue | 2,282 |  |  | 2,028 |  |
| Reportable segment net revenue | $ | 21,394 |  |  | $ | 20,966 |  |


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0001571996-19-000025:notes:325]
[same as prior period, unchanged from 0001571996-18-000044:notes:345]

[0001571996-19-000025:notes:326]
The following table presents additional information on selected accounts included in the Condensed Consolidated Statements of Financial Position as of the dates indicated:

[0001571996-19-000025:notes:327]
|  | May 3, 2019 |  | February 1, 2019 |
|  | (in millions) |
| Cash, cash equivalents, and restricted cash: |  |  |  |
| Cash and cash equivalents | $ | 9,040 |  |  | $ | 9,676 |  |
| Restricted cash - other current assets (a) | 629 |  |  | 522 |  |
| Restricted cash - other non-current assets (a) | 40 |  |  | 42 |  |
| Total cash, cash equivalents, and restricted cash | $ | 9,709 |  |  | $ | 10,240 |  |
| Inventories, net: |  |  |  |
| Production materials | $ | 1,561 |  |  | $ | 1,794 |  |
| Work-in-process | 722 |  |  | 702 |  |
| Finished goods | 1,077 |  |  | 1,153 |  |
| Total inventories, net | $ | 3,360 |  |  | $ | 3,649 |  |
| Other non-current liabilities: |  |  |  |
| Warranty liability | $ | 162 |  |  | $ | 169 |  |
| Deferred and other tax liabilities | 4,688 |  |  | 5,527 |  |
| Non-current operating lease liabilities | 1,138 |  |  | — |  |
| Other | 537 |  |  | 631 |  |
| Total other non-current liabilities | $ | 6,525 |  |  | $ | 6,327 |  |

[0001571996-19-000025:notes:328]
| (a) | Restricted cash includes cash required to be held in escrow pursuant to DFS securitization arrangements and VMware, Inc. restricted cash. |

[0001571996-19-000025:notes:329]
Warranty Liability

[0001571996-19-000025:notes:330]
The following table presents changes in the Company’s liability for standard limited warranties for the periods indicated:

[0001571996-19-000025:notes:331]
|  | Three Months Ended |
|  | May 3, 2019 |  | May 4, 2018 |
|  | (in millions) |
| Warranty liability: |  |  |  |
| Warranty liability at beginning of period | $ | 524 |  |  | $ | 539 |  |
| Costs accrued for new warranty contracts and changes in estimates for pre-existing warranties (a) (b) | 203 |  |  | 194 |  |
| Service obligations honored | (227 | ) |  | (206 | ) |
| Warranty liability at end of period | $ | 500 |  |  | $ | 527 |  |
| Current portion | $ | 338 |  |  | $ | 358 |  |
| Non-current portion | $ | 162 |  |  | $ | 169 |  |

[0001571996-19-000025:notes:332]
| (a) | Changes in cost estimates related to pre-existing warranties are aggregated with accruals for new standard warranty contracts. The Company’s warranty liability process does not differentiate between estimates made for pre-existing warranties and new warranty obligations. |

[0001571996-19-000025:notes:333]
(b)

[0001571996-19-000025:notes:334]
Includes the impact of foreign currency exchange rate fluctuations.
