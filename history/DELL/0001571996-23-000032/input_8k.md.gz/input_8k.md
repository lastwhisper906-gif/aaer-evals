# DELL 8-K — 0001571996-23-000029 filed 2023-08-31

## item codes, every 8-K on or before 2023-09-12

- 2023-08-31 0001571996-23-000029 — 2.02, 9.01
- 2023-08-09 0001571996-23-000026 — 5.02 — amendment of 0001571996-23-000002
- 2023-07-28 0001571996-23-000024 — 5.02
- 2023-07-13 0001193125-23-186639 — 3.02
- 2023-06-30 0001193125-23-180570 — 8.01, 9.01
- 2023-06-22 0001571996-23-000021 — 5.02, 5.07, 9.01
- 2023-06-15 0001193125-23-167472 — 8.01, 9.01
- 2023-06-01 0001571996-23-000014 — 2.02, 9.01
- 2023-03-02 0001571996-23-000002 — 2.02, 5.02, 9.01
- 2023-02-06 0001193125-23-024781 — 7.01, 9.01
- 2023-01-24 0001193125-23-014260 — 1.01, 2.03, 9.01
- 2023-01-11 0001193125-23-006528 — 8.01, 9.01
- 2022-11-21 0001571996-22-000041 — 2.02, 9.01
- 2022-11-16 0001571996-22-000038 — 8.01
- 2022-08-25 0001571996-22-000028 — 2.02, 9.01
- 2022-07-18 0001193125-22-196334 — 2.03, 8.01
- 2022-06-29 0001571996-22-000025 — 3.03, 5.03, 5.07, 8.01, 9.01
- 2022-05-26 0001571996-22-000013 — 2.02, 9.01
- 2022-02-24 0001571996-22-000004 — 2.02, 8.01, 9.01
- 2021-12-20 0001193125-21-362482 — 8.01, 9.01
- 2021-12-15 0001193125-21-357927 — 1.01, 2.03, 9.01
- 2021-12-07 0001193125-21-349218 — 8.01, 9.01
- 2021-11-23 0001571996-21-000060 — 2.02, 9.01
- 2021-11-05 0001571996-21-000057 — 1.02, 2.01, 7.01, 8.01, 9.01 — amendment, the index does not say of what
- 2021-11-01 0001571996-21-000052 — 8.01, 9.01
- 2021-11-01 0001193125-21-315488 — 1.01, 1.02, 2.01, 8.01, 9.01
- 2021-10-21 0001193125-21-304052 — 8.01, 9.01
- 2021-10-19 0001571996-21-000050 — 8.01, 9.01
- 2021-10-07 0001193125-21-294210 — 8.01, 9.01
- 2021-09-30 0001571996-21-000047 — 5.02
- 2021-09-27 0001571996-21-000045 — 8.01
- 2021-09-23 0001193125-21-280190 — 7.01, 8.01, 9.01
- 2021-09-20 0001193125-21-276810 — 7.01, 9.01
- 2021-08-26 0001571996-21-000037 — 2.02, 9.01
- 2021-07-01 0001571996-21-000034 — 3.02
- 2021-06-24 0001571996-21-000031 — 5.07
- 2021-06-24 0001193125-21-197644 — 7.01, 9.01
- 2021-06-16 0001571996-21-000029 — 5.02
- 2021-05-27 0001571996-21-000019 — 2.02, 9.01
- 2021-05-03 0001571996-21-000010 — 8.01, 9.01
- 2021-04-14 0001193125-21-116271 — 1.01, 7.01, 9.01
- 2021-02-25 0001571996-21-000003 — 2.02, 9.01
- 2021-02-18 0001193125-21-047844 — 1.01, 2.03, 9.01
- 2020-11-24 0001571996-20-000048 — 2.02, 9.01
- 2020-08-27 0001571996-20-000041 — 2.02, 9.01
- 2020-07-02 0001571996-20-000037 — 5.07
- 2020-05-28 0001571996-20-000028 — 2.02, 9.01
- 2020-04-09 0001193125-20-102602 — 1.01, 2.03, 9.01
- 2020-04-08 0001571996-20-000021 — 5.02
- 2020-04-03 0001571996-20-000019 — 8.01, 9.01
- 2020-03-26 0001571996-20-000015 — 7.01
- 2020-02-27 0001571996-20-000009 — 2.02, 8.01, 9.01
- 2020-02-18 0001571996-20-000005 — 8.01, 9.01
- 2020-01-09 0001571996-20-000002 — 3.02
- 2020-01-06 0001193125-20-002200 — 3.02
- 2019-12-13 0001193125-19-313947 — 3.02
- 2019-12-10 0001571996-19-000052 — 5.02
- 2019-12-02 0001571996-19-000044 — 5.02, 7.01, 9.01
- 2019-11-26 0001571996-19-000042 — 2.02, 9.01
- 2019-09-23 0001193125-19-252192 — 1.01, 2.03, 9.01
- 2019-08-29 0001571996-19-000036 — 2.02, 9.01
- 2019-08-22 0001193125-19-226939 — 7.01, 8.01, 9.01
- 2019-07-11 0001571996-19-000032 — 5.02, 5.07, 9.01
- 2019-07-03 0001571996-19-000030 — 3.02
- 2019-06-27 0001571996-19-000028 — 3.02
- 2019-05-30 0001571996-19-000021 — 2.02, 9.01
- 2019-04-02 0001571996-19-000010 — 5.02
- 2019-03-21 0001193125-19-082281 — 1.01, 1.02, 2.03, 9.01
- 2019-03-19 0001571996-19-000005 — 5.02, 9.01
- 2019-03-14 0001193125-19-074935 — 1.01, 2.03, 9.01
- 2019-03-07 0001193125-19-066045 — 8.01, 9.01
- 2019-02-28 0001571996-19-000002 — 2.02, 9.01
- 2018-12-28 0001193125-18-360943 — 1.01, 1.02, 3.01, 3.03, 5.02, 5.03, 7.01, 8.01, 9.01
- 2018-12-21 0001193125-18-356324 — 1.01, 2.03, 9.01
- 2018-12-14 0001193125-18-349469 — 8.01
- 2018-12-11 0001193125-18-346958 — 5.07, 8.01, 9.01
- 2018-11-29 0001571996-18-000041 — 2.02, 9.01
- 2018-11-28 0001571996-18-000037 — 7.01, 8.01, 9.01
- 2018-11-26 0001193125-18-333967 — 8.01, 9.01
- 2018-11-15 0001193125-18-328110 — 1.01, 9.01 — amendment of 0001193125-18-327222
- 2018-11-15 0001193125-18-327222 — 1.01, 7.01, 9.01
- 2018-10-03 0001193125-18-291390 — 8.01
- 2018-09-06 0001571996-18-000029 — 2.02, 9.01
- 2018-08-06 0001571996-18-000027 — 8.01, 9.01
- 2018-07-02 0001193125-18-210339 — 1.01, 7.01, 9.01
- 2018-06-28 0001571996-18-000024 — 5.07
- 2018-06-04 0001571996-18-000019 — 2.02, 9.01
- 2018-05-17 0001571996-18-000016 — 7.01
- 2018-04-26 0001571996-18-000009 — 7.01, 9.01
- 2018-03-08 0001193125-18-074168 — 2.02, 9.01
- 2018-02-02 0001193125-18-029947 — 7.01, 9.01
- 2017-12-07 0001571996-17-000042 — 2.02, 9.01
- 2017-10-24 0001571996-17-000037 — 1.01, 2.03, 9.01
- 2017-09-15 0001571996-17-000027 — 5.02
- 2017-09-07 0001571996-17-000017 — 2.02, 9.01
- 2017-08-24 0001571996-17-000014 — 8.01
- 2017-06-29 0001571996-17-000011 — 3.03, 5.07, 8.01, 9.01
- 2017-06-08 0001193125-17-197638 — 2.02, 9.01
- 2017-03-30 0001193125-17-102794 — 8.01
- 2017-03-30 0001193125-17-102777 — 2.02, 9.01
- 2017-03-09 0001193125-17-076981 — 1.01, 2.03, 9.01
- 2017-01-17 0001193125-17-011125 — 8.01
- 2016-12-15 0001193125-16-793722 — 8.01
- 2016-12-08 0001193125-16-787976 — 2.02, 9.01
- 2016-11-10 0001193125-16-765964 — 1.02, 8.01
- 2016-11-04 0001193125-16-760249 — 8.01
- 2016-09-13 0001193125-16-708600 — 3.02
- 2016-09-09 0001193125-16-706567 — 1.01, 1.02, 2.01, 2.03, 3.02, 3.03, 5.02, 9.01
- 2016-09-07 0001193125-16-703370 — 3.03, 5.07, 7.01, 8.01, 9.01
- 2016-09-06 0001193125-16-702057 — 2.02, 9.01
- 2016-08-31 0001193125-16-697268 — 8.01, 9.01
- 2016-08-26 0001193125-16-692921 — 8.01, 9.01
- 2016-07-11 0001193125-16-645610 — 8.01
- 2016-07-05 0001193125-16-641679 — 8.01
- 2016-06-22 0001193125-16-629055 — 1.01, 2.03, 8.01, 9.01
- 2016-06-21 0001193125-16-627071 — 8.01, 9.01
- 2016-06-10 0001193125-16-618483 — 2.02, 9.01
- 2016-06-09 0001193125-16-617893 — 8.01, 9.01

## late-filing notifications on or before 2023-09-12

- none on or before 2023-09-12

## item 2.02 — earnings release, exhibit 99.1

[0001571996-23-000029:8k_2_02:1]
EX-99.1
2
exhibit991earnings8kq2fy24.htm
EX-99.1

[0001571996-23-000029:8k_2_02:2]
Document

[0001571996-23-000029:8k_2_02:3]
Exhibit 99.1

[0001571996-23-000029:8k_2_02:4]
Dell Technologies Delivers Second Quarter Fiscal 2024 Financial Results

[0001571996-23-000029:8k_2_02:5]
News summary

[0001571996-23-000029:8k_2_02:6]
•Second quarter revenue of $22.9 billion

[0001571996-23-000029:8k_2_02:7]
•Operating income of $1.2 billion and non-GAAP operating income of $2 billion

[0001571996-23-000029:8k_2_02:8]
•Diluted earnings per share of $0.63, and non-GAAP diluted earnings per share of $1.74

[0001571996-23-000029:8k_2_02:9]
•Second quarter cash flow from operations of $3.2 billion

[0001571996-23-000029:8k_2_02:10]
ROUND ROCK, Texas — August 31, 2023

[0001571996-23-000029:8k_2_02:11]
Full story

[0001571996-23-000029:8k_2_02:12]
Dell Technologies (NYSE: DELL) announces financial results for its fiscal 2024 second quarter. Revenue was $22.9 billion, down 13% year-over-year and up 10% sequentially. The company generated operating income of $1.2 billion and non-GAAP operating income of $2 billion, down 8% and up 1% year-over-year, respectively. Diluted earnings per share was $0.63, and non-GAAP diluted earnings per share was $1.74, down 7% and up 4% year-over-year, respectively. Cash flow from operations for the second quarter was $3.2 billion, driven by working capital improvements, sequential growth and profitability. The company has generated $8.1 billion of cash flow from operations throughout the last 12 months.

[0001571996-23-000029:8k_2_02:13]
Dell ended the quarter with remaining performance obligations of $39 billion, recurring revenue of $5.6 billion, up 8% year-over-year, and deferred revenue of $30.3 billion, up 8% year-over-year, primarily due to increases in service and software maintenance agreements. Cash and investments were $9.9 billion, and the company returned $525 million to shareholders in the second quarter through share repurchases and dividends.

[0001571996-23-000029:8k_2_02:14]
“Our Q2 performance underscores the power of our model to generate cash in a sequential growth environment,” said Yvonne McGill, chief financial officer, Dell Technologies. “Revenue grew 10% sequentially to $22.9 billion, with strong cash flow from operations of $3.2 billion in Q2 and $8.1 billion over the last 12 months. We continue to deliver value to shareholders and have flexibility to increase our return of capital going forward.”

[0001571996-23-000029:8k_2_02:15]
1

[0001571996-23-000029:8k_2_02:16]
Second Quarter Fiscal 2024 Financial Results

[0001571996-23-000029:8k_2_02:17]
|  | Three Months Ended |  |  |  | Six Months Ended |  |  |
|  | August 4, 2023 |  | July 29, 2022 |  | Change |  | August 4, 2023 |  | July 29, 2022 |  | Change |
|  | (in millions, except per share amounts and percentages; unaudited) |
| Total net revenue | $ | 22,934 |  |  | $ | 26,425 |  |  | (13)% |  | $ | 43,856 |  |  | $ | 52,541 |  |  | (17)% |
| Operating income | $ | 1,165 |  |  | $ | 1,270 |  |  | (8)% |  | $ | 2,234 |  |  | $ | 2,820 |  |  | (21)% |
| Net income | $ | 455 |  |  | $ | 506 |  |  | (10)% |  | $ | 1,033 |  |  | $ | 1,575 |  |  | (34)% |
| Earnings per share - diluted | $ | 0.63 |  |  | $ | 0.68 |  |  | (7)% |  | $ | 1.42 |  |  | $ | 2.06 |  |  | (31)% |
| Non-GAAP net revenue | $ | 22,934 |  |  | $ | 26,425 |  |  | (13)% |  | $ | 43,856 |  |  | $ | 52,541 |  |  | (17)% |
| Non-GAAP operating income | $ | 1,977 |  |  | $ | 1,952 |  |  | 1% |  | $ | 3,575 |  |  | $ | 4,087 |  |  | (13)% |
| Non-GAAP net income | $ | 1,283 |  |  | $ | 1,266 |  |  | 1% |  | $ | 2,246 |  |  | $ | 2,700 |  |  | (17)% |
| Adjusted EBITDA | $ | 2,595 |  |  | $ | 2,449 |  |  | 6% |  | $ | 4,799 |  |  | $ | 5,058 |  |  | (5)% |
| Non-GAAP earnings per share - diluted | $ | 1.74 |  |  | $ | 1.68 |  |  | 4% |  | $ | 3.05 |  |  | $ | 3.52 |  |  | (13)% |

[0001571996-23-000029:8k_2_02:18]
Information about Dell Technologies’ use of non-GAAP financial information is provided under “Non-GAAP Financial Measures” below. All comparisons in this press release are year-over-year unless otherwise noted.

[0001571996-23-000029:8k_2_02:19]
Infrastructure Solutions Group delivered second quarter revenue of $8.5 billion, down 11% year-over-year and up 11% sequentially. Storage revenue was $4.2 billion, with continued demand growth in PowerStore, the company’s leading midrange storage array, and PowerFlex, the company’s software-defined storage. PowerFlex has now grown eight consecutive quarters with second quarter demand more than doubling year-over-year. Servers and networking revenue was $4.3 billion, with continued demand growth in AI-optimized servers. Operating income was $1 billion, approximately 12.4% of Infrastructure Solutions Group revenue.

[0001571996-23-000029:8k_2_02:20]
Client Solutions Group delivered second quarter revenue of $12.9 billion, down 16% year-over-year and up 8% sequentially. Commercial client revenue was $10.6 billion, with demand growth in workstations, which help organizations run complex AI workloads locally. Consumer revenue was $2.4 billion. Operating income was $969 million, or approximately 7.5% of Client Solutions Group revenue.

[0001571996-23-000029:8k_2_02:21]
“With a better demand environment and strong execution, we delivered extraordinary Q2 results,” said Jeff Clarke, vice chairman and chief operating officer, Dell Technologies. “We continue to focus on the most profitable segments of the market where we have a leading position. Demand for our proprietary software-defined storage solution has now grown eight consecutive quarters. Our client solutions group business was up 8% sequentially with strong attach rates. And AI is already showing it’s a long-term tailwind, with continued demand growth across our portfolio.”

[0001571996-23-000029:8k_2_02:22]
Dell expanded on its May announcement of Project Helix and introduced Dell Generative AI Solutions, which spans IT infrastructure, PCs and professional services to simplify the adoption of full-stack generative AI with large language models on premises.

[0001571996-23-000029:8k_2_02:23]
•The Dell Validated Design for Generative AI with NVIDIA is an inferencing blueprint, jointly engineered with NVIDIA, that helps customers generate higher quality, faster time-to-value predictions and decisions with their own data.

[0001571996-23-000029:8k_2_02:24]
•Dell PowerEdge XE9680 servers are optimized for generative AI applications and are the fastest ramping new solution in Dell history.

[0001571996-23-000029:8k_2_02:25]
2

[0001571996-23-000029:8k_2_02:26]
•Dell Precision workstations run AI software frameworks 80% faster than the previous generation and have up to four NVIDIA RTX 6000 Ada Generation GPUs.

[0001571996-23-000029:8k_2_02:27]
•Dell Professional Services help customers accelerate generative AI adoption and improve operational efficiency.

[0001571996-23-000029:8k_2_02:28]
Operating Segments Results

[0001571996-23-000029:8k_2_02:29]
|  | Three Months Ended |  |  |  | Six Months Ended |  |  |
|  | August 4, 2023 |  | July 29, 2022 |  | Change |  | August 4, 2023 |  | July 29, 2022 |  | Change |
|  | (in millions, except percentages; unaudited) |
| Infrastructure Solutions Group (ISG): |  |  |  |  |  |  |  |  |  |  |  |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Servers and networking | $ | 4,274 |  | $ | 5,209 |  |  | (18)% |  | $ | 8,111 |  |  | $ | 10,257 |  |  | (21)% |
| Storage | 4,187 |  |  | 4,327 |  |  | (3)% |  | 7,943 |  |  | 8,564 |  |  | (7)% |
| Total ISG net revenue | $ | 8,461 |  |  | $ | 9,536 |  |  | (11)% |  | $ | 16,054 |  |  | $ | 18,821 |  |  | (15)% |
| Operating Income: |  |  |  |  |  |  |  |  |  |  |  |
| ISG operating income | $ | 1,049 |  |  | $ | 1,046 |  |  | —% |  | $ | 1,789 |  |  | $ | 2,128 |  |  | (16)% |
| % of ISG net revenue | 12.4 | % |  | 11.0 | % |  |  |  | 11.1 | % |  | 11.3 | % |  |  |
| % of total reportable segment operating income | 52 | % |  | 52 | % |  |  |  | 49 | % |  | 50 | % |  |  |
| Client Solutions Group (CSG): |  |  |  |  |  |  |  |  |  |  |  |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Commercial | $ | 10,554 |  |  | $ | 12,141 |  |  | (13)% |  | $ | 20,416 |  |  | $ | 24,112 |  |  | (15)% |
| Consumer | 2,388 |  |  | 3,349 |  |  | (29)% |  | 4,509 |  |  | 6,965 |  |  | (35)% |
| Total CSG net revenue | $ | 12,942 |  |  | $ | 15,490 |  |  | (16)% |  | $ | 24,925 |  |  | $ | 31,077 |  |  | (20)% |
| Operating Income: |  |  |  |  |  |  |  |  |  |  |  |
| CSG operating income | $ | 969 |  |  | $ | 978 |  |  | (1)% |  | $ | 1,861 |  |  | $ | 2,093 |  |  | (11)% |
| % of CSG net revenue | 7.5 | % |  | 6.3 | % |  |  |  | 7.5 | % |  | 6.7 | % |  |  |
| % of total reportable segment operating income | 48 | % |  | 48 | % |  |  |  | 51 | % |  | 50 | % |  |  |

[0001571996-23-000029:8k_2_02:30]
Conference call information

[0001571996-23-000029:8k_2_02:31]
As previously announced, the company will hold a conference call to discuss its performance and financial guidance on Aug. 31 at 3:30 p.m. CDT. Prior to the start of the conference call, prepared remarks and a presentation containing additional financial and operating information prior to financial guidance may be downloaded from investors.delltechnologies.com. The conference call will be broadcast live over the internet and can be accessed at https://investors.delltechnologies.com/news-events/upcoming-events

[0001571996-23-000029:8k_2_02:32]
For those unable to listen to the live broadcast, the final remarks and presentation with financial guidance will be available following the broadcast, and an archived version will be available at the same location for one year.

[0001571996-23-000029:8k_2_02:33]
Environmental, Social and Governance (ESG)

[0001571996-23-000029:8k_2_02:34]
Our Environmental, Social and Governance (ESG) efforts focus on driving positive impact for people and our planet while delivering long-term value for our stakeholders. ESG resources can be accessed at https://www.dell.com/en-us/dt/corporate/social-impact/reporting/esg-governance.htm

[0001571996-23-000029:8k_2_02:35]
3

[0001571996-23-000029:8k_2_02:36]
About Dell Technologies

[0001571996-23-000029:8k_2_02:37]
Dell Technologies (NYSE:DELL) helps organizations and individuals build their digital future and transform how they work, live and play. The company provides customers with the industry’s broadest and most innovative technology and services portfolio for the data era.

[0001571996-23-000029:8k_2_02:38]
Contacts

[0001571996-23-000029:8k_2_02:39]
Investors: Investor_Relations@Dell.com

[0001571996-23-000029:8k_2_02:40]
Media: Media.Relations@Dell.com

[0001571996-23-000029:8k_2_02:41]
# # #

[0001571996-23-000029:8k_2_02:42]
Copyright © 2023 Dell Inc. or its subsidiaries. All Rights Reserved. Dell Technologies, Dell, EMC and Dell EMC are trademarks of Dell Inc. or its subsidiaries. Other trademarks may be trademarks of their respective owners.

[0001571996-23-000029:8k_2_02:43]
Non-GAAP Financial Measures:

[0001571996-23-000029:8k_2_02:44]
This press release presents information about non-GAAP gross margin, non-GAAP operating expenses, non-GAAP operating income, non-GAAP net income, non-GAAP net income attributable to Dell Technologies Inc., non-GAAP earnings per share attributable to Dell Technologies Inc. – basic, and non-GAAP earnings per share attributable to Dell Technologies Inc. – diluted, which are non-GAAP financial measures provided as a supplement to the results provided in accordance with generally accepted accounting principles in the United States of America (“GAAP”). A reconciliation of each non-GAAP financial measure to the most directly comparable GAAP financial measure is provided in the attached tables for each of the fiscal periods indicated.

[0001571996-23-000029:8k_2_02:45]
Special Note on Forward-Looking Statements:

[0001571996-23-000029:8k_2_02:46]
Dell Technologies’ results or events in future periods could differ materially from those expressed or implied by these forward-looking statements because of risks, uncertainties, and other factors that include, but are not limited to, the following: adverse global economic conditions and instability in financial markets; competitive pressures; Dell Technologies’ reliance on third-party suppliers for products and components, including reliance on single-source or limited-source suppliers; Dell Technologies’ ability to achieve favorable pricing from its vendors; Dell Technologies’ ability to achieve  the intended benefits of its continuing strategic relationship with VMware, Inc.; Dell Technologies’ execution of its strategy; Dell Technologies’ ability to manage solutions and products and services transitions in an effective manner; Dell Technologies’ ability to deliver high-quality products, software, and services; cyber attacks or other data security incidents; Dell Technologies’ ability to successfully execute on strategic initiatives including acquisitions, divestitures or cost savings measures; Dell Technologies’ foreign operations and ability to generate substantial non-U.S. net revenue; Dell Technologies’ product, services, customer, and geographic sales mix, and seasonal sales trends; the performance of Dell Technologies’ sales channel partners; access to the capital markets by Dell Technologies or its customers; material impairment of the value of goodwill or intangible assets; weak economic conditions and the effect of additional regulation on Dell Technologies’ financial services activities; counterparty default risks; the loss by Dell Technologies of any contracts for ISG services and solutions and its ability to perform such contracts at their estimated costs; loss by Dell Technologies of government contracts; Dell Technologies’ ability to develop and protect its proprietary intellectual property or obtain licenses to intellectual property developed by others on commercially reasonable and competitive terms; disruptions in Dell Technologies’ infrastructure; Dell Technologies’ ability to hedge effectively its exposure to fluctuations in foreign currency exchange rates and interest rates; expiration of tax holidays or favorable tax rate structures, or unfavorable outcomes in tax audits and other tax compliance matters; impairment of portfolio investments; unfavorable results of legal proceedings; expectations relating to environmental, social and governance (ESG) considerations; compliance requirements of changing environmental and safety laws, human rights laws, or other laws; the effect of armed hostilities, terrorism, natural disasters, or public health issues; the effect of global climate change and legal, regulatory, or market measures to address climate change; Dell Technologies’ dependence on the services of Michael Dell and key employees; Dell Technologies’ level of indebtedness; and business and financial factors and legal restrictions affecting continuation of Dell Technologies’ quarterly cash dividend policy and dividend rate.

[0001571996-23-000029:8k_2_02:47]
This list of risks, uncertainties, and other factors is not complete. Dell Technologies discusses some of these matters more fully, as well as certain risk factors that could affect Dell Technologies’ business, financial condition, results of operations, and prospects, in its reports filed with the SEC, including Dell Technologies’ annual report on Form 10-K for the fiscal year ended February 3, 2023, quarterly reports on Form 10-Q, and current reports on Form 8-K. These filings are available for review through the SEC’s website at www.sec.gov. Any or all forward-looking statements Dell Technologies makes may turn out to be wrong and can be affected by inaccurate assumptions Dell Technologies might make or by known or unknown risks, uncertainties, and other factors, including those identified in this press release. Accordingly, you should not place undue reliance on the forward-looking statements made in this press release, which speak only as of its

[0001571996-23-000029:8k_2_02:48]
4

[0001571996-23-000029:8k_2_02:49]
date. Dell Technologies does not undertake to update, and expressly disclaims any duty to update, its forward-looking statements, whether as a result of circumstances or events that arise after the date they are made, new information, or otherwise.

[0001571996-23-000029:8k_2_02:50]
5

[0001571996-23-000029:8k_2_02:51]
DELL TECHNOLOGIES INC.

[0001571996-23-000029:8k_2_02:52]
Consolidated Statements of Income and Related Financial Highlights

[0001571996-23-000029:8k_2_02:53]
(in millions, except percentages; unaudited)

[0001571996-23-000029:8k_2_02:54]
|  | Three Months Ended |  |  |  | Six Months Ended |  |  |
|  | August 4, 2023 |  | July 29, 2022 |  | Change |  | August 4, 2023 |  | July 29, 2022 |  | Change |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Products | $ | 16,935 |  |  | $ | 20,810 |  |  | (19)% |  | $ | 31,971 |  |  | $ | 41,274 |  |  | (23)% |
| Services | 5,999 |  |  | 5,615 |  |  | 7% |  | 11,885 |  |  | 11,267 |  |  | 5% |
| Total net revenue | 22,934 |  |  | 26,425 |  |  | (13)% |  | 43,856 |  |  | 52,541 |  |  | (17)% |
| Cost of net revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Products | 14,002 |  |  | 17,671 |  |  | (21)% |  | 26,377 |  |  | 34,680 |  |  | (24)% |
| Services | 3,545 |  |  | 3,315 |  |  | 7% |  | 7,074 |  |  | 6,638 |  |  | 7% |
| Total cost of net revenue | 17,547 |  |  | 20,986 |  |  | (16)% |  | 33,451 |  |  | 41,318 |  |  | (19)% |
| Gross margin | 5,387 |  |  | 5,439 |  |  | (1)% |  | 10,405 |  |  | 11,223 |  |  | (7)% |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |
| Selling, general, and administrative | 3,517 |  |  | 3,543 |  |  | (1)% |  | 6,778 |  |  | 7,096 |  |  | (4)% |
| Research and development | 705 |  |  | 626 |  |  | 13% |  | 1,393 |  |  | 1,307 |  |  | 7% |
| Total operating expenses | 4,222 |  |  | 4,169 |  |  | 1% |  | 8,171 |  |  | 8,403 |  |  | (3)% |
| Operating income | 1,165 |  |  | 1,270 |  |  | (8)% |  | 2,234 |  |  | 2,820 |  |  | (21)% |
| Interest and other, net | (451) |  |  | (635) |  |  | 29% |  | (815) |  |  | (972) |  |  | 16% |
| Income before income taxes | 714 |  |  | 635 |  |  | 12% |  | 1,419 |  |  | 1,848 |  |  | (23)% |
| Income tax expense | 259 |  |  | 129 |  |  | 101% |  | 386 |  |  | 273 |  |  | 41% |
| Net income | 455 |  |  | 506 |  |  | (10)% |  | 1,033 |  |  | 1,575 |  |  | (34)% |
| Less: Net loss attributable to non-controlling interests | (7) |  |  | (5) |  |  | (40)% |  | (12) |  |  | (8) |  |  | (50)% |
| Net income attributable to Dell Technologies Inc. | $ | 462 |  |  | $ | 511 |  |  | (10)% |  | $ | 1,045 |  |  | $ | 1,583 |  |  | (34)% |
| Percentage of Total Net Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Gross margin | 23.5 | % |  | 20.6 | % |  |  |  | 23.7 | % |  | 21.4 | % |  |  |
| Selling, general, and administrative | 15.3 | % |  | 13.4 | % |  |  |  | 15.4 | % |  | 13.5 | % |  |  |
| Research and development | 3.1 | % |  | 2.4 | % |  |  |  | 3.2 | % |  | 2.5 | % |  |  |
| Operating expenses | 18.4 | % |  | 15.8 | % |  |  |  | 18.6 | % |  | 16.0 | % |  |  |
| Operating income | 5.1 | % |  | 4.8 | % |  |  |  | 5.1 | % |  | 5.4 | % |  |  |
| Income before income taxes | 3.1 | % |  | 2.4 | % |  |  |  | 3.2 | % |  | 3.5 | % |  |  |
| Net income | 2.0 | % |  | 1.9 | % |  |  |  | 2.4 | % |  | 3.0 | % |  |  |
| Income tax rate | 36.3 | % |  | 20.3 | % |  |  |  | 27.2 | % |  | 14.8 | % |  |  |

[0001571996-23-000029:8k_2_02:55]
Amounts are based on underlying data and may not visually foot due to rounding.

[0001571996-23-000029:8k_2_02:56]
6

[0001571996-23-000029:8k_2_02:57]
DELL TECHNOLOGIES INC.

[0001571996-23-000029:8k_2_02:58]
Consolidated Statements of Financial Position

[0001571996-23-000029:8k_2_02:59]
(in millions; unaudited)

[0001571996-23-000029:8k_2_02:60]
|  | August 4, 2023 |  | February 3, 2023 |
| ASSETS |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 8,364 |  |  | $ | 8,607 |  |
| Accounts receivable, net of allowance of $80 and $78 | 10,351 |  |  | 12,482 |  |
| Due from related party, net | 404 |  |  | 378 |  |
| Short-term financing receivables, net of allowance of $72 and $142 | 4,807 |  |  | 5,281 |  |
| Inventories | 3,584 |  |  | 4,776 |  |
| Other current assets | 11,047 |  |  | 10,827 |  |
| Current assets held for sale | 442 |  |  | — |  |
| Total current assets | 38,999 |  |  | 42,351 |  |
| Property, plant, and equipment, net | 6,252 |  |  | 6,209 |  |
| Long-term investments | 1,331 |  |  | 1,518 |  |
| Long-term financing receivables, net of allowance of $77 and $59 | 5,813 |  |  | 5,638 |  |
| Goodwill | 19,640 |  |  | 19,676 |  |
| Intangible assets, net | 6,060 |  |  | 6,468 |  |
| Due from related party, net | 236 |  |  | 440 |  |
| Other non-current assets | 7,327 |  |  | 7,311 |  |
| Total assets | $ | 85,658 |  |  | $ | 89,611 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |
| Short-term debt | $ | 6,961 |  |  | $ | 6,573 |  |
| Accounts payable | 19,969 |  |  | 18,598 |  |
| Due to related party | 1,252 |  |  | 2,067 |  |
| Accrued and other | 6,586 |  |  | 8,874 |  |
| Short-term deferred revenue | 16,174 |  |  | 15,542 |  |
| Total current liabilities | 50,942 |  |  | 51,654 |  |
| Long-term debt | 20,177 |  |  | 23,015 |  |
| Long-term deferred revenue | 14,138 |  |  | 14,744 |  |
| Other non-current liabilities | 3,078 |  |  | 3,223 |  |
| Total liabilities | 88,335 |  |  | 92,636 |  |
| Stockholders’ equity (deficit): |  |  |  |
| Total Dell Technologies Inc. stockholders’ equity (deficit) | (2,772) |  |  | (3,122) |  |
| Non-controlling interests | 95 |  |  | 97 |  |
| Total stockholders’ equity (deficit) | (2,677) |  |  | (3,025) |  |
| Total liabilities and stockholders’ equity | $ | 85,658 |  |  | $ | 89,611 |  |

[0001571996-23-000029:8k_2_02:61]
7

[0001571996-23-000029:8k_2_02:62]
DELL TECHNOLOGIES INC.

[0001571996-23-000029:8k_2_02:63]
Consolidated Statements of Cash Flows

[0001571996-23-000029:8k_2_02:64]
(in millions; unaudited)

[0001571996-23-000029:8k_2_02:65]
|  | Three Months Ended |  | Six Months Ended |
|  | August 4, 2023 |  | July 29, 2022 |  | August 4, 2023 |  | July 29, 2022 |
| Cash flows from operating activities: |  |  |  |  |  |  |  |
| Net income | $ | 455 |  |  | $ | 506 |  |  | $ | 1,033 |  |  | $ | 1,575 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: | 2,759 |  |  | 218 |  |  | 3,958 |  |  | (1,120) |  |
| Change in cash from operating activities | 3,214 |  |  | 724 |  |  | 4,991 |  |  | 455 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |
| Purchases of investments | (98) |  |  | (28) |  |  | (113) |  |  | (80) |  |
| Maturities and sales of investments | 108 |  |  | 50 |  |  | 127 |  |  | 68 |  |
| Capital expenditures and capitalized software development costs | (624) |  |  | (807) |  |  | (1,325) |  |  | (1,497) |  |
| Other | 9 |  |  | 7 |  |  | 22 |  |  | 11 |  |
| Change in cash from investing activities | (605) |  |  | (778) |  |  | (1,289) |  |  | (1,498) |  |
| Cash flows from financing activities: |  |  |  |  |  |  |  |
| Proceeds from the issuance of common stock | 2 |  |  | 1 |  |  | 4 |  |  | 5 |  |
| Repurchases of common stock | (260) |  |  | (682) |  |  | (500) |  |  | (2,118) |  |
| Repurchases of common stock for employee tax withholdings | (6) |  |  | (8) |  |  | (312) |  |  | (358) |  |
| Payments of dividends and dividend equivalents | (269) |  |  | (242) |  |  | (545) |  |  | (490) |  |
| Proceeds from debt | 2,134 |  |  | 3,431 |  |  | 4,655 |  |  | 6,465 |  |
| Repayments of debt | (3,384) |  |  | (3,539) |  |  | (7,082) |  |  | (6,242) |  |
| Debt-related costs and other, net | (44) |  |  | (7) |  |  | (49) |  |  | (14) |  |
| Change in cash from financing activities | (1,827) |  |  | (1,046) |  |  | (3,829) |  |  | (2,752) |  |
| Effect of exchange rate changes on cash, cash equivalents, and restricted cash | (59) |  |  | (83) |  |  | (117) |  |  | (194) |  |
| Change in cash, cash equivalents, and restricted cash | 723 |  |  | (1,183) |  |  | (244) |  |  | (3,989) |  |
| Cash, cash equivalents, and restricted cash at beginning of the period | 7,927 |  |  | 7,276 |  |  | 8,894 |  |  | 10,082 |  |
| Cash, cash equivalents, and restricted cash at end of the period | $ | 8,650 |  |  | $ | 6,093 |  |  | $ | 8,650 |  |  | $ | 6,093 |  |

[0001571996-23-000029:8k_2_02:66]
8

[0001571996-23-000029:8k_2_02:67]
DELL TECHNOLOGIES INC.

[0001571996-23-000029:8k_2_02:68]
Segment Information

[0001571996-23-000029:8k_2_02:69]
(in millions, except percentages; unaudited; continued on next page)

[0001571996-23-000029:8k_2_02:70]
|  | Three Months Ended |  |  |  | Six Months Ended |  |  |
|  | August 4, 2023 |  | July 29, 2022 |  | Change |  | August 4, 2023 |  | July 29, 2022 |  | Change |
| Infrastructure Solutions Group (ISG): |  |  |  |  |  |  |  |  |  |  |  |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Servers and networking | $ | 4,274 |  | $ | 5,209 |  |  | (18)% |  | $ | 8,111 |  |  | $ | 10,257 |  |  | (21)% |
| Storage | 4,187 |  |  | 4,327 |  |  | (3)% |  | 7,943 |  |  | 8,564 |  |  | (7)% |
| Total ISG net revenue | $ | 8,461 |  |  | $ | 9,536 |  |  | (11)% |  | $ | 16,054 |  |  | $ | 18,821 |  |  | (15)% |
| Operating Income: |  |  |  |  |  |  |  |  |  |  |  |
| ISG operating income | $ | 1,049 |  |  | $ | 1,046 |  |  | —% |  | $ | 1,789 |  |  | $ | 2,128 |  |  | (16)% |
| % of ISG net revenue | 12.4 | % |  | 11.0 | % |  |  |  | 11.1 | % |  | 11.3 | % |  |  |
| % of total reportable segment operating income | 52 | % |  | 52 | % |  |  |  | 49 | % |  | 50 | % |  |  |
| Client Solutions Group (CSG): |  |  |  |  |  |  |  |  |  |  |  |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Commercial | $ | 10,554 |  |  | $ | 12,141 |  |  | (13)% |  | $ | 20,416 |  |  | $ | 24,112 |  |  | (15)% |
| Consumer | 2,388 |  |  | 3,349 |  |  | (29)% |  | 4,509 |  |  | 6,965 |  |  | (35)% |
| Total CSG net revenue | $ | 12,942 |  |  | $ | 15,490 |  |  | (16)% |  | $ | 24,925 |  |  | $ | 31,077 |  |  | (20)% |
| Operating Income: |  |  |  |  |  |  |  |  |  |  |  |
| CSG operating income | $ | 969 |  |  | $ | 978 |  |  | (1)% |  | $ | 1,861 |  |  | $ | 2,093 |  |  | (11)% |
| % of CSG net revenue | 7.5 | % |  | 6.3 | % |  |  |  | 7.5 | % |  | 6.7 | % |  |  |
| % of total reportable segment operating income | 48 | % |  | 48 | % |  |  |  | 51 | % |  | 50 | % |  |  |

[0001571996-23-000029:8k_2_02:71]
Amounts are based on underlying data and may not visually foot due to rounding.

[0001571996-23-000029:8k_2_02:72]
9

[0001571996-23-000029:8k_2_02:73]
DELL TECHNOLOGIES INC.

[0001571996-23-000029:8k_2_02:74]
Segment Information

[0001571996-23-000029:8k_2_02:75]
(in millions, except percentages; unaudited; continued)

[0001571996-23-000029:8k_2_02:76]
|  | Three Months Ended |  | Six Months Ended |
|  | August 4, 2023 |  | July 29, 2022 |  | August 4, 2023 |  | July 29, 2022 |
| Reconciliation to consolidated net revenue: |  |  |  |  |  |  |
| Reportable segment net revenue | $ | 21,403 |  |  | $ | 25,026 |  |  | $ | 40,979 |  |  | $ | 49,898 |  |
| Other businesses (a) | 1,528 |  |  | 1,399 |  |  | 2,871 |  |  | 2,638 |  |
| Unallocated transactions (b) | 3 |  |  | — |  |  | 6 |  |  | 5 |  |
| Total consolidated net revenue | $ | 22,934 |  |  | $ | 26,425 |  |  | $ | 43,856 |  |  | $ | 52,541 |  |
| Reconciliation to consolidated operating income: |  |  |  |  |  |  |  |
| Reportable segment operating income | $ | 2,018 |  |  | $ | 2,024 |  |  | $ | 3,650 |  |  | $ | 4,221 |  |
| Other businesses (a) | (44) |  |  | (71) |  |  | (80) |  |  | (135) |  |
| Unallocated transactions (b) | 3 |  |  | (1) |  |  | 5 |  |  | 1 |  |
| Impact of purchase accounting (c) | (4) |  |  | (3) |  |  | (8) |  |  | (12) |  |
| Amortization of intangibles | (209) |  |  | (244) |  |  | (408) |  |  | (487) |  |
| Transaction-related (income) expenses (d) | (3) |  |  | (3) |  |  | (6) |  |  | (8) |  |
| Stock-based compensation expense (e) | (223) |  |  | (236) |  |  | (448) |  |  | (468) |  |
| Other corporate expenses (f) | (373) |  |  | (196) |  |  | (471) |  |  | (292) |  |
| Total consolidated operating income | $ | 1,165 |  |  | $ | 1,270 |  |  | $ | 2,234 |  |  | $ | 2,820 |  |

[0001571996-23-000029:8k_2_02:77]
_________________

[0001571996-23-000029:8k_2_02:78]
(a)Other businesses consists of: 1) Dell’s resale of standalone VMware, Inc. products and services, “VMware Resale,” 2) Secureworks, and 3) Virtustream, and do not meet the requirements for a reportable segment, either individually or collectively.

[0001571996-23-000029:8k_2_02:79]
(b)Unallocated transactions includes other corporate items that are not allocated to Dell Technologies’ reportable segments.

[0001571996-23-000029:8k_2_02:80]
(c)Impact of purchase accounting includes non-cash purchase accounting adjustments that are primarily related to the EMC merger transaction.

[0001571996-23-000029:8k_2_02:81]
(d)Transaction-related (income) expenses includes acquisition, integration, and divestiture related costs. From time to time, this category also may include transaction-related income related to divestitures of businesses or asset sales.

[0001571996-23-000029:8k_2_02:82]
(e)Stock-based compensation expense consists of equity awards granted based on the estimated fair value of those awards at grant date.

[0001571996-23-000029:8k_2_02:83]
(f)Other corporate expenses includes severance, impairment charges, incentive charges related to equity investments, payroll taxes associated with stock-based compensation, facilities action, and other costs.  During the three and six months ended August 4, 2023, other corporate expenses included $364 million of severance expense.  During the three and six months ended July 29, 2022, other corporate expenses includes impairment and other costs incurred in connection with exiting our business in Russia.

[0001571996-23-000029:8k_2_02:84]
SUPPLEMENTAL SELECTED NON-GAAP FINANCIAL MEASURES

[0001571996-23-000029:8k_2_02:85]
These tables present information about the Company’s non-GAAP gross margin, non-GAAP operating expenses, non-GAAP operating income, non-GAAP net income, non-GAAP net income attributable to Dell Technologies Inc., non-GAAP earnings per share attributable to Dell Technologies Inc. - basic, and non-GAAP earnings per share attributable to Dell Technologies Inc. - diluted, which are non-GAAP financial measures provided as a supplement to the results provided in accordance with generally accepted accounting principles in the United States of America (“GAAP”). A detailed discussion of Dell Technologies’ reasons for including these non-GAAP financial measures, the limitations associated with these measures, the items excluded from these measures, and our reason for excluding those items are presented in “Management’s Discussion and Analysis of Financial Condition and Results of Operations — Non-GAAP Financial Measures” in our periodic reports filed with the SEC. Dell Technologies encourages investors to review the non-GAAP discussion in these reports in conjunction with the presentation of non-GAAP financial measures.

[0001571996-23-000029:8k_2_02:86]
11

[0001571996-23-000029:8k_2_02:87]
DELL TECHNOLOGIES INC.

[0001571996-23-000029:8k_2_02:88]
Selected Financial Measures

[0001571996-23-000029:8k_2_02:89]
(in millions, except per share amounts and percentages; unaudited)

[0001571996-23-000029:8k_2_02:90]
|  | Three Months Ended |  |  |  | Six Months Ended |  |  |
|  | August 4, 2023 |  | July 29, 2022 |  | Change |  | August 4, 2023 |  | July 29, 2022 |  | Change |
| Net revenue (a) | $ | 22,934 |  |  | $ | 26,425 |  |  | (13)% |  | $ | 43,856 |  |  | $ | 52,541 |  |  | (17)% |
| Non-GAAP gross margin | $ | 5,536 |  |  | $ | 5,650 |  |  | (2)% |  | $ | 10,700 |  |  | $ | 11,591 |  |  | (8)% |
| % of non-GAAP net revenue | 24.1 | % |  | 21.4 | % |  |  |  | 24.4 | % |  | 22.1 | % |  |  |
| Non-GAAP operating expenses | $ | 3,559 |  |  | $ | 3,698 |  |  | (4)% |  | $ | 7,125 |  |  | $ | 7,504 |  |  | (5)% |
| % of non-GAAP net revenue | 15.5 | % |  | 14.0 | % |  |  |  | 16.2 | % |  | 14.3 | % |  |  |
| Non-GAAP operating income | $ | 1,977 |  |  | $ | 1,952 |  |  | 1% |  | $ | 3,575 |  | $ | 4,087 |  | (13)% |
| % of non-GAAP net revenue | 8.6 | % |  | 7.4 | % |  |  |  | 8.2 | % |  | 7.8 | % |  |  |
| Non-GAAP net income | $ | 1,283 |  |  | $ | 1,266 |  |  | 1% |  | $ | 2,246 |  |  | $ | 2,700 |  |  | (17)% |
| % of non-GAAP net revenue | 5.6 | % |  | 4.8 | % |  |  |  | 5.1 | % |  | 5.1 | % |  |  |
| Non-GAAP earnings per share - diluted | $ | 1.74 |  |  | $ | 1.68 |  |  | 4% |  | $ | 3.05 |  |  | $ | 3.52 |  |  | (13)% |

[0001571996-23-000029:8k_2_02:91]
____________________

[0001571996-23-000029:8k_2_02:92]
(a)    Effective in the first quarter of Fiscal 2023, non-GAAP net revenue no longer differs from net revenue, the most comparable GAAP financial measure.

[0001571996-23-000029:8k_2_02:93]
Amounts are based on underlying data and may not visually foot due to rounding.

[0001571996-23-000029:8k_2_02:94]
12

[0001571996-23-000029:8k_2_02:95]
DELL TECHNOLOGIES INC.

[0001571996-23-000029:8k_2_02:96]
Reconciliation of Selected Non-GAAP Financial Measures

[0001571996-23-000029:8k_2_02:97]
(in millions, except percentages; unaudited; continued on next page)

[0001571996-23-000029:8k_2_02:98]
|  | Three Months Ended |  |  |  | Six Months Ended |  |  |
|  | August 4, 2023 |  | July 29, 2022 |  | Change |  | August 4, 2023 |  | July 29, 2022 |  | Change |
| Gross margin | $ | 5,387 |  |  | $ | 5,439 |  |  | (1)% |  | $ | 10,405 |  |  | $ | 11,223 |  |  | (7)% |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 84 |  |  | 105 |  |  |  |  | 163 |  |  | 209 |  |  |  |
| Impact of purchase accounting | — |  |  | — |  |  |  |  | — |  |  | 2 |  |  |  |
| Stock-based compensation expense | 37 |  |  | 37 |  |  |  |  | 75 |  |  | 75 |  |  |  |
| Other corporate expenses | 28 |  |  | 69 |  |  |  |  | 57 |  |  | 82 |  |  |  |
| Non-GAAP gross margin | $ | 5,536 |  |  | $ | 5,650 |  |  | (2)% |  | $ | 10,700 |  |  | $ | 11,591 |  |  | (8)% |
| Operating expenses | $ | 4,222 |  |  | $ | 4,169 |  |  | 1% |  | $ | 8,171 |  |  | $ | 8,403 |  |  | (3)% |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | (125) |  |  | (139) |  |  |  |  | (245) |  |  | (278) |  |  |  |
| Impact of purchase accounting | (4) |  |  | (3) |  |  |  |  | (8) |  |  | (10) |  |  |  |
| Transaction-related (income) expenses | (3) |  |  | (3) |  |  |  |  | (6) |  |  | (8) |  |  |  |
| Stock-based compensation expense | (186) |  |  | (199) |  |  |  |  | (373) |  |  | (393) |  |  |  |
| Other corporate expenses | (345) |  |  | (127) |  |  |  |  | (414) |  |  | (210) |  |  |  |
| Non-GAAP operating expenses | $ | 3,559 |  |  | $ | 3,698 |  |  | (4)% |  | $ | 7,125 |  |  | $ | 7,504 |  |  | (5)% |
| Operating income | $ | 1,165 |  |  | $ | 1,270 |  |  | (8)% |  | $ | 2,234 |  |  | $ | 2,820 |  |  | (21)% |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 209 |  |  | 244 |  |  |  |  | 408 |  |  | 487 |  |  |  |
| Impact of purchase accounting | 4 |  |  | 3 |  |  |  |  | 8 |  |  | 12 |  |  |  |
| Transaction-related expenses | 3 |  |  | 3 |  |  |  |  | 6 |  |  | 8 |  |  |  |
| Stock-based compensation expense | 223 |  |  | 236 |  |  |  |  | 448 |  |  | 468 |  |  |  |
| Other corporate expenses | 373 |  |  | 196 |  |  |  |  | 471 |  |  | 292 |  |  |  |
| Non-GAAP operating income | $ | 1,977 |  |  | $ | 1,952 |  |  | 1% |  | $ | 3,575 |  |  | $ | 4,087 |  |  | (13)% |
| Net income | $ | 455 |  |  | $ | 506 |  |  | (10) | % |  | $ | 1,033 |  |  | $ | 1,575 |  |  | (34)% |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 209 |  |  | 244 |  |  |  |  | 408 |  |  | 487 |  |  |  |
| Impact of purchase accounting | 4 |  |  | 3 |  |  |  |  | 8 |  |  | 12 |  |  |  |
| Transaction-related (income) expenses | 60 |  |  | (4) |  |  |  |  | 59 |  |  | (6) |  |  |  |
| Stock-based compensation expense | 223 |  |  | 236 |  |  |  |  | 448 |  |  | 468 |  |  |  |
| Other corporate expenses | 372 |  |  | 212 |  |  |  |  | 471 |  |  | 308 |  |  |  |
| Fair value adjustments on equity investments | 29 |  |  | 255 |  |  |  |  | 44 |  |  | 241 |  |  |  |
| Aggregate adjustment for income taxes | (69) |  |  | (186) |  |  |  |  | (225) |  |  | (385) |  |  |  |
| Non-GAAP net income | $ | 1,283 |  |  | $ | 1,266 |  |  | 1% |  | $ | 2,246 |  |  | $ | 2,700 |  |  | (17)% |

[0001571996-23-000029:8k_2_02:99]
13

[0001571996-23-000029:8k_2_02:100]
DELL TECHNOLOGIES INC.

[0001571996-23-000029:8k_2_02:101]
Reconciliation of Selected Non-GAAP Financial Measures

[0001571996-23-000029:8k_2_02:102]
(in millions, except percentages and per share amounts; unaudited; continued)

[0001571996-23-000029:8k_2_02:103]
|  | For the Three Months Ended August 4, 2023 |
|  | GAAP |  | Amortization of intangibles |  | Impact of purchase accounting |  | Transaction-related (income) expenses |  | Stock-based compensation expense |  | Other corporate expenses |  | Fair value adjustments on equity investments |  | Aggregate adjustment for income taxes |  | Aggregate adjustment for non-controlling interests |  | Non-GAAP |
| Net income attributable to Dell Technologies Inc. | $ | 462 |  |  | 209 |  |  | 4 |  |  | 60 |  |  | 223 |  |  | 372 |  |  | 29 |  |  | (69) |  |  | (5) |  |  | $ | 1,285 |  |
| Earnings per share - basic | $ | 0.64 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 1.77 |  |
| Earnings per share - diluted | $ | 0.63 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 1.74 |  |
| Weighted-average shares outstanding - basic | 726 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 726 |  |
| Weighted-average shares outstanding - diluted | 738 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 738 |  |

[0001571996-23-000029:8k_2_02:104]
|  | For the Three Months Ended July 29, 2022 |
|  | GAAP |  | Amortization of intangibles |  | Impact of purchase accounting |  | Transaction-related (income) expenses |  | Stock-based compensation expense |  | Other corporate expenses |  | Fair value adjustments on equity investments |  | Aggregate adjustment for income taxes |  | Aggregate adjustment for non-controlling interests |  | Non-GAAP |
| Net income attributable to Dell Technologies Inc. | $ | 511 |  |  | 244 |  |  | 3 |  |  | (4) |  |  | 236 |  |  | 212 |  |  | 255 |  |  | (186) |  |  | (3) |  |  | $ | 1,268 |  |
| Earnings per share - basic | $ | 0.69 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 1.72 |  |
| Earnings per share - diluted | $ | 0.68 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 1.68 |  |
| Weighted-average shares outstanding - basic | 739 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 739 |  |
| Weighted-average shares outstanding - diluted | 755 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 755 |  |

[0001571996-23-000029:8k_2_02:105]
DELL TECHNOLOGIES INC.

[0001571996-23-000029:8k_2_02:106]
Reconciliation of Selected Non-GAAP Financial Measures

[0001571996-23-000029:8k_2_02:107]
(in millions, except percentages and per share amounts; unaudited; continued)

[0001571996-23-000029:8k_2_02:108]
|  | For the Six Months Ended August 4, 2023 |
|  | GAAP |  | Amortization of intangibles |  | Impact of purchase accounting |  | Transaction-related (income) expenses |  | Stock-based compensation expense |  | Other corporate expenses |  | Fair value adjustments on equity investments |  | Aggregate adjustment for income taxes |  | Aggregate adjustment for non-controlling interests |  | Non-GAAP |
| Net income attributable to Dell Technologies Inc. | $ | 1,045 |  |  | 408 |  |  | 8 |  |  | 59 |  |  | 448 |  |  | 471 |  |  | 44 |  |  | (225) |  |  | (7) |  |  | $ | 2,251 |  |
| Earnings per share - basic | $ | 1.44 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 3.10 |  |
| Earnings per share - diluted | $ | 1.42 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 3.05 |  |
| Weighted-average shares outstanding - basic | 725 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 725 |  |
| Weighted-average shares outstanding - diluted | 737 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 737 |  |

[0001571996-23-000029:8k_2_02:109]
|  | For the Six Months Ended July 29, 2022 |
|  | GAAP |  | Amortization of intangibles |  | Impact of purchase accounting |  | Transaction-related (income) expenses |  | Stock-based compensation expense |  | Other corporate expenses |  | Fair value adjustments on equity investments |  | Aggregate adjustment for income taxes |  | Aggregate adjustment for non-controlling interests |  | Non-GAAP |
| Net income attributable to Dell Technologies Inc. | $ | 1,583 |  |  | 487 |  |  | 12 |  |  | (6) |  |  | 468 |  |  | 308 |  |  | 241 |  |  | (385) |  |  | (5) |  |  | $ | 2,703 |  |
| Earnings per share - basic | $ | 2.12 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 3.62 |  |
| Earnings per share - diluted | $ | 2.06 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 3.52 |  |
| Weighted-average shares outstanding - basic | 746 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 746 |  |
| Weighted-average shares outstanding - diluted | 768 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 768 |  |

[0001571996-23-000029:8k_2_02:110]
15
