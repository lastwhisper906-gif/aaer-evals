# DELL MD&A — 0001571996-23-000032


## mdna

[0001571996-23-000032:mdna:1]
[same as prior period, unchanged from 0001571996-23-000019:mdna:1]

[0001571996-23-000032:mdna:2]
[same as prior period, unchanged from 0001571996-23-000019:mdna:2]

[0001571996-23-000032:mdna:3]
[same as prior period, unchanged from 0001571996-23-000019:mdna:3]

[0001571996-23-000032:mdna:4]
[same as prior period, unchanged from 0001571996-23-000019:mdna:4]

[0001571996-23-000032:mdna:5]
[same as prior period, unchanged from 0001571996-23-000019:mdna:5]

[0001571996-23-000032:mdna:6]
[same as prior period, unchanged from 0001571996-23-000019:mdna:6]

[0001571996-23-000032:mdna:7]
Dell Technologies helps organizations build their digital futures and individuals transform how they work, live, and play.  We provide customers with one of the industry’s broadest and most innovative solutions portfolio for the data era, including traditional infrastructure and extending to multicloud environments.  Our differentiated and holistic IT solutions enable us to capture growth as customer spending priorities evolve.

[0001571996-23-000032:mdna:8]
[same as prior period, unchanged from 0001571996-23-000019:mdna:8]

[0001571996-23-000032:mdna:9]
Dell Technologies operates globally in approximately 180 countries, supported by a world-class organization across key functional areas, including technology and product development, marketing, sales, financial services, and services.  We have a number of durable competitive advantages that provide a critical foundation for our success.  Our go-to-market model includes a 29,000-person direct sales force and a global network of approximately 240,000 channel partners.  We employ approximately 34,000 service and support professionals and maintain approximately 2,200 vendor-managed service centers.  We also manage a world-class supply chain at significant scale with approximately $77 billion in annual procurement expenditures and over 725 parts distribution centers.

[0001571996-23-000032:mdna:10]
[same as prior period, unchanged from 0001571996-23-000019:mdna:10]

[0001571996-23-000032:mdna:11]
57

[0001571996-23-000032:mdna:12]
[same as prior period, unchanged from 0001571996-23-000019:mdna:11]

[0001571996-23-000032:mdna:13]
Our vision is to become the most essential technology company for the data era.  We help customers address their evolving IT needs and their broader digital transformation objectives as they embrace today’s multicloud world.  We intend to execute our vision by growing our core offerings, including opportunities such as artificial intelligence (“AI”), edge, telecom, data management, and as-a-Service consumption models.

[0001571996-23-000032:mdna:14]
We believe we are uniquely positioned in the data and multicloud era and that our results will continue to benefit from our durable competitive advantages.  We intend to continue to execute our business model and position our Company for long-term success while balancing liquidity, profitability, and growth and keeping our purpose at the forefront of our decision-making: to create technologies that drive human progress.

[0001571996-23-000032:mdna:15]
[same as prior period, unchanged from 0001571996-23-000019:mdna:16]

[0001571996-23-000032:mdna:16]
[same as prior period, unchanged from 0001571996-23-000019:mdna:17]

[0001571996-23-000032:mdna:17]
[same as prior period, unchanged from 0001571996-23-000019:mdna:18]

[0001571996-23-000032:mdna:18]
•Infrastructure Solutions Group (“ISG”) — ISG enables our customers’ digital transformations with solutions that address the fundamental shift to multicloud environments, machine learning, AI, and data analytics.  ISG helps customers simplify, streamline, and automate cloud operations.  ISG solutions are built for multicloud environments and are optimized to run cloud native workloads in both public and private clouds, as well as traditional on-premise workloads.

[0001571996-23-000032:mdna:19]
[same as prior period, unchanged from 0001571996-23-000019:mdna:20]

[0001571996-23-000032:mdna:20]
Our server portfolio includes high-performance rack, blade, and tower servers.  Our servers are designed with the capability to run high value workloads across customers’ IT on premises, multicloud, and edge environments, including the training, fine-tuning, and operationalization of AI models.  Our networking portfolio helps our business customers transform and modernize their infrastructure, mobilize and enrich end-user experiences, and accelerate business applications and processes.

[0001571996-23-000032:mdna:21]
[same as prior period, unchanged from 0001571996-23-000019:mdna:22]

[0001571996-23-000032:mdna:22]
[same as prior period, unchanged from 0001571996-23-000019:mdna:23]

[0001571996-23-000032:mdna:23]
[same as prior period, unchanged from 0001571996-23-000019:mdna:24]

[0001571996-23-000032:mdna:24]
[same as prior period, unchanged from 0001571996-23-000019:mdna:25]

[0001571996-23-000032:mdna:25]
[same as prior period, unchanged from 0001571996-23-000019:mdna:26]

[0001571996-23-000032:mdna:26]
[same as prior period, unchanged from 0001571996-23-000019:mdna:27]

[0001571996-23-000032:mdna:27]
[same as prior period, unchanged from 0001571996-23-000019:mdna:28]

[0001571996-23-000032:mdna:28]
[same as prior period, unchanged from 0001571996-23-000019:mdna:29]

[0001571996-23-000032:mdna:29]
[same as prior period, unchanged from 0001571996-23-000019:mdna:30]

[0001571996-23-000032:mdna:30]
[same as prior period, unchanged from 0001571996-23-000019:mdna:31]

[0001571996-23-000032:mdna:31]
[same as prior period, unchanged from 0001571996-23-000019:mdna:32]

[0001571996-23-000032:mdna:32]
[same as prior period, unchanged from 0001571996-23-000019:mdna:33]

[0001571996-23-000032:mdna:33]
[same as prior period, unchanged from 0001571996-23-000019:mdna:66]

[0001571996-23-000032:mdna:34]
[same as prior period, unchanged from 0001571996-23-000019:mdna:36]

[0001571996-23-000032:mdna:35]
[same as prior period, unchanged from 0001571996-23-000019:mdna:37]

[0001571996-23-000032:mdna:36]
VMware is considered to be a related party of the Company as a result of Michael Dell’s ownership interests in both Dell Technologies and VMware and Mr. Dell’s service as Chairman and Chief Executive Officer of Dell Technologies and as Chairman of the Board of VMware, Inc.  For more information regarding related party transactions with VMware, see Note 15 of the Notes to the Condensed Consolidated Financial Statements included in this report.

[0001571996-23-000032:mdna:37]
[same as prior period, unchanged from 0001571996-23-000019:mdna:39]

[0001571996-23-000032:mdna:38]
[same as prior period, unchanged from 0001571996-23-000019:mdna:40]

[0001571996-23-000032:mdna:39]
As of August 4, 2023 and February 3, 2023, we held strategic investments in non-marketable securities of $1.2 billion and $1.3 billion, respectively.  See Note 3 of the Notes to the Condensed Consolidated Financial Statements included in this report for additional information.

[0001571996-23-000032:mdna:40]
[same as prior period, unchanged from 0001571996-23-000019:mdna:42]

[0001571996-23-000032:mdna:41]
[same as prior period, unchanged from 0001571996-23-000019:mdna:34]

[0001571996-23-000032:mdna:42]
Product backlog represents the value of unfulfilled manufacturing orders and is included as a component of remaining performance obligations to the extent we determine that the manufacturing orders are non-cancelable.  Our business model generally gives us the ability to optimize product backlog at any point in time, such as by expediting shipping or prioritizing customer orders for products that have shorter lead times.  During Fiscal 2023, we lowered our backlog across both CSG and ISG from previously elevated levels as constraints in limited-source components began to diminish as a result of improving supply positions and overall declines in the demand environment.

[0001571996-23-000032:mdna:43]
60

[0001571996-23-000032:mdna:44]
[same as prior period, unchanged from 0001571996-23-000019:mdna:43]

[0001571996-23-000032:mdna:45]
During the first half of Fiscal 2024, the effects of the evolving macroeconomic environment continued to impact our net revenue performance when compared to the first half of Fiscal 2023.  Within CSG, our first half Fiscal 2024 net revenue performance was impacted by industry-wide declines in demand that began in the second quarter of Fiscal 2023.  Within ISG, our first half Fiscal 2024 net revenue performance was impacted as certain customers remained cautious and were measured in their IT spending.

[0001571996-23-000032:mdna:46]
During the second quarter of Fiscal 2024, while net revenue declined, we experienced sequential growth in the demand for our offerings as certain customers responded to early signs of macroeconomic stabilization.  Despite some indicators of a stabilizing environment, we currently anticipate a decline in net revenue for the second half of Fiscal 2024 relative to the net revenue we achieved in the second half of Fiscal 2023, driven primarily by net revenue attributable to ISG.  We anticipate the decline in net revenue will, in part, be attributable to the continued impact of macroeconomic conditions on demand and increasing competitive pricing pressure.  We expect that the decline in net revenue will be partially offset by disciplined cost management measures as we continue to make prudent decisions to navigate this environment.

[0001571996-23-000032:mdna:47]
Despite continued near-term challenges, we believe our durable competitive advantages continue to position us for long-term success.

[0001571996-23-000032:mdna:48]
[same as prior period, unchanged from 0001571996-23-000019:mdna:47]

[0001571996-23-000032:mdna:49]
During the second quarter of Fiscal 2024, our supply chain continued to operate efficiently at standard lead times for our customers and we experienced declines in both component and logistics costs, which we refer to as input costs.  We expect component cost deflation to moderate during the second half of Fiscal 2024.  Component cost trends are dependent on the strength or weakness of actual end-user demand and supply dynamics, which will continue to evolve and ultimately impact the translation of the cost environment to pricing and operating results.  Logistics costs, which we believe have now normalized, continued to decrease from previously elevated levels as a result of declines in both expedited shipments and overall rate costs in the freight network.

[0001571996-23-000032:mdna:50]
Foreign Currency Exposure — We manage our business on a U.S. dollar basis.  However, we have a large global presence, generating approximately half of our net revenue from sales to customers outside of the United States during the second quarter of Fiscal 2024 and Fiscal 2023.  As a result, our operating results can be, and particularly in recent periods have been, impacted by fluctuations in foreign currency exchange rates.  We utilize a comprehensive hedging strategy intended to mitigate the impact of foreign currency volatility over time, and we adjust pricing when possible to further minimize foreign currency impacts.

[0001571996-23-000032:mdna:51]
[same as prior period, unchanged from 0001571996-23-000019:mdna:51]

[0001571996-23-000032:mdna:52]
Through our collaborative, customer-focused approach to innovation, we strive to deliver new and relevant solutions and software to our customers quickly and efficiently.  We continue to focus on customer base expansion and lifetime value of customer relationships.  Our customer base includes service providers, such as cloud service providers, Software-as-a-Service companies, consumer webtech providers, and telecommunications companies.  These service providers turn to Dell Technologies for our advanced solutions that enable efficient infrastructure and service delivery at cloud scale.

[0001571996-23-000032:mdna:53]
While we anticipate challenges in the demand environment as customers re-prioritize and exercise caution in response to macroeconomic conditions, we expect that data growth will continue to generate long-term demand for our storage solutions and services.  Cloud native applications are expected to continue to be a key trend in the infrastructure market.  We benefit from offering solutions that address the emerging trends of enterprises deploying software-defined storage, hyper-converged infrastructure, and modular solutions based on server-centric architectures.  These trends are changing the way customers are consuming our storage offerings.  We continue to expand our offerings in external storage arrays, which incorporate flexible, cloud-based functionality.  Our storage business is subject to seasonal trends, which we expect to continue.

[0001571996-23-000032:mdna:54]
We anticipate that ISG will benefit from the continued expansion of, and advances in, AI.  Through our server and storage offerings, as well as our Dell-validated AI solutions, we are well positioned to capture growth and support our customers needs.  As demonstrated by our PowerEdge XE servers, we continue to optimize and enhance our offerings to run high value and transformational workloads, such as AI.

[0001571996-23-000032:mdna:55]
CSG — Our CSG offerings are an important element of our strategy, generating strong cash flow and opportunities for cross-selling of complementary solutions.  Within CSG, while we participate in all segments of the PC market, we are focused on commercial and high-end consumer computing devices, as we believe they are the most stable and profitable markets.  Competitive dynamics continue to be a factor in our CSG business and continue to impact pricing and operating results.

[0001571996-23-000032:mdna:56]
[same as prior period, unchanged from 0001571996-23-000019:mdna:56]

[0001571996-23-000032:mdna:57]
Recurring Revenue and Consumption Models — Our customers are seeking new and innovative models that address how they consume our solutions.  In part, customers are looking for predictable cost models and to reduce complexity, align solutions offerings to their business needs, and provide consistent operations throughout their IT enterprise.

[0001571996-23-000032:mdna:58]
We offer options including leases, loans, immediate pay, as-a-Service, subscription, and utility models designed to match customers' consumption and financing preferences.  We believe these options are particularly advantageous for our customers during times of economic uncertainty as they provide customers with financial flexibility to further enable them to procure our solutions.

[0001571996-23-000032:mdna:59]
These offerings typically result in multiyear agreements which generate recurring revenue streams over the term of the arrangement.  We expect that these offerings will further strengthen our customer relationships and provide a foundation for growth in recurring revenue.  We define recurring revenue as revenue recognized that is primarily related to hardware and software maintenance as well as operating leases, subscription, as-a-Service, and usage-based offerings.

[0001571996-23-000032:mdna:60]
[same as prior period, unchanged from 0001571996-23-000019:mdna:60]

[0001571996-23-000032:mdna:61]
[same as prior period, unchanged from 0001571996-23-000019:mdna:63]

[0001571996-23-000032:mdna:62]
[same as prior period, unchanged from 0001571996-23-000019:mdna:64]

[0001571996-23-000032:mdna:63]
[same as prior period, unchanged from 0001571996-23-000019:mdna:65]

[0001571996-23-000032:mdna:64]
[same as prior period, unchanged from 0001571996-23-000019:mdna:67]

[0001571996-23-000032:mdna:65]
[same as prior period, unchanged from 0001571996-23-000019:mdna:68]

[0001571996-23-000032:mdna:66]
[same as prior period, unchanged from 0001571996-23-000019:mdna:69]

[0001571996-23-000032:mdna:67]
[same as prior period, unchanged from 0001571996-23-000019:mdna:70]

[0001571996-23-000032:mdna:68]
[same as prior period, unchanged from 0001571996-23-000019:mdna:71]

[0001571996-23-000032:mdna:69]
[same as prior period, unchanged from 0001571996-23-000019:mdna:72]

[0001571996-23-000032:mdna:70]
[same as prior period, unchanged from 0001571996-23-000019:mdna:73]

[0001571996-23-000032:mdna:71]
•Impact of Purchase Accounting — The impact of purchase accounting includes purchase accounting adjustments primarily related to the EMC merger transaction recorded under the acquisition method of accounting in accordance with the accounting guidance for business combinations.  In accordance with such guidance, all of the assets and liabilities acquired were accounted for and recognized at fair value as of the respective transaction dates, and the fair value adjustments continue to amortize over the estimated useful lives in the periods following the transactions.  The fair value adjustments that are still amortizing primarily relate to property, plant, and equipment.  We believe that excluding the impact of purchase accounting for purposes of calculating the non-GAAP financial measures presented below facilitates an enhanced understanding of our current operating performance and provides more meaningful period to period comparisons.

[0001571996-23-000032:mdna:72]
[same as prior period, unchanged from 0001571996-23-000019:mdna:75]

[0001571996-23-000032:mdna:73]
[same as prior period, unchanged from 0001571996-23-000019:mdna:76]

[0001571996-23-000032:mdna:74]
•Other Corporate Expenses — Other corporate expenses consist of impairment charges, incentive charges related to equity investments, severance, facility action, payroll taxes associated with stock-based compensation, and other costs.  Severance costs are primarily related to severance and benefits for employees terminated pursuant to cost savings initiatives.  During the second quarter of Fiscal 2024, we recognized $364 million of severance expense related to workforce reduction activities.  During the second quarter of Fiscal 2023, we recognized $189 million in costs associated with exiting our business in Russia, primarily related to asset impairments and other exit related costs.  Other corporate expenses vary from period to period and are significantly impacted by the timing and nature of these events.  Therefore, although we may incur these types of expenses in the future, we believe that eliminating these charges for purposes of calculating the non-GAAP financial measures presented below facilitates an enhanced understanding of our current operating performance and provides more meaningful period to period comparisons.

[0001571996-23-000032:mdna:75]
[same as prior period, unchanged from 0001571996-23-000019:mdna:78]

[0001571996-23-000032:mdna:76]
[same as prior period, unchanged from 0001571996-23-000019:mdna:79]

[0001571996-23-000032:mdna:77]
[same as prior period, unchanged from 0001571996-23-000019:mdna:80]

[0001571996-23-000032:mdna:78]
|  | Three Months Ended |  | Six Months Ended |
|  | August 4,2023 |  | % Change |  | July 29,2022 |  | August 4,2023 |  | % Change |  | July 29,2022 |  |  |  |  |
|  | (in millions, except percentages) |
| Product gross margin | $ | 2,933 |  |  | (7) | % |  | $ | 3,139 |  |  | $ | 5,594 |  |  | (15) | % |  | $ | 6,594 |  |  |  |  |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 84 |  |  |  |  | 105 |  |  | 163 |  |  |  |  | 209 |  |  |  |  |  |
| Impact of purchase accounting | — |  |  |  |  | — |  |  | — |  |  |  |  | 2 |  |  |  |  |  |
| Stock-based compensation expense | 13 |  |  |  |  | 13 |  |  | 26 |  |  |  |  | 26 |  |  |  |  |  |
| Other corporate expenses | 7 |  |  |  |  | 13 |  |  | 15 |  |  |  |  | 16 |  |  |  |  |  |
| Non-GAAP product gross margin | $ | 3,037 |  |  | (7) | % |  | $ | 3,270 |  |  | $ | 5,798 |  |  | (15) | % |  | $ | 6,847 |  |  |  |  |  |
| Services gross margin | $ | 2,454 |  |  | 7 | % |  | $ | 2,300 |  |  | $ | 4,811 |  |  | 4 | % |  | $ | 4,629 |  |  |  |  |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation expense | 24 |  |  |  |  | 24 |  |  | 49 |  |  |  |  | 49 |  |  |  |  |  |
| Other corporate expenses | 21 |  |  |  |  | 56 |  |  | 42 |  |  |  |  | 66 |  |  |  |  |  |
| Non-GAAP services gross margin | $ | 2,499 |  |  | 5 | % |  | $ | 2,380 |  |  | $ | 4,902 |  |  | 3 | % |  | $ | 4,744 |  |  |  |  |  |
| Gross margin | $ | 5,387 |  |  | (1) | % |  | $ | 5,439 |  |  | $ | 10,405 |  |  | (7) | % |  | $ | 11,223 |  |  |  |  |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 84 |  |  |  |  | 105 |  |  | 163 |  |  |  |  | 209 |  |  |  |  |  |
| Impact of purchase accounting | — |  |  |  |  | — |  |  | — |  |  |  |  | 2 |  |  |  |  |  |
| Stock-based compensation expense | 37 |  |  |  |  | 37 |  |  | 75 |  |  |  |  | 75 |  |  |  |  |  |
| Other corporate expenses | 28 |  |  |  |  | 69 |  |  | 57 |  |  |  |  | 82 |  |  |  |  |  |
| Non-GAAP gross margin | $ | 5,536 |  |  | (2) | % |  | $ | 5,650 |  |  | $ | 10,700 |  |  | (8) | % |  | $ | 11,591 |  |  |  |  |  |
| Operating expenses | $ | 4,222 |  |  | 1 | % |  | $ | 4,169 |  |  | $ | 8,171 |  |  | (3) | % |  | $ | 8,403 |  |  |  |  |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | (125) |  |  |  |  | (139) |  |  | (245) |  |  |  |  | (278) |  |  |  |  |  |
| Impact of purchase accounting | (4) |  |  |  |  | (3) |  |  | (8) |  |  |  |  | (10) |  |  |  |  |  |
| Transaction-related expenses | (3) |  |  |  |  | (3) |  |  | (6) |  |  |  |  | (8) |  |  |  |  |  |
| Stock-based compensation expense | (186) |  |  |  |  | (199) |  |  | (373) |  |  |  |  | (393) |  |  |  |  |  |
| Other corporate expenses | (345) |  |  |  |  | (127) |  |  | (414) |  |  |  |  | (210) |  |  |  |  |  |
| Non-GAAP operating expenses | $ | 3,559 |  |  | (4) | % |  | $ | 3,698 |  |  | $ | 7,125 |  |  | (5) | % |  | $ | 7,504 |  |  |  |  |  |

[0001571996-23-000032:mdna:79]
65

[0001571996-23-000032:mdna:80]
|  | Three Months Ended |  | Six Months Ended |
|  | August 4,2023 |  | % Change |  | July 29,2022 |  | August 4,2023 |  | % Change |  | July 29,2022 |  |  |  |  |
|  | (in millions, except percentages) |
| Operating income | $ | 1,165 |  |  | (8) | % |  | $ | 1,270 |  |  | $ | 2,234 |  |  | (21) | % |  | $ | 2,820 |  |  |  |  |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 209 |  |  |  |  | 244 |  |  | 408 |  |  |  |  | 487 |  |  |  |  |  |
| Impact of purchase accounting | 4 |  |  |  |  | 3 |  |  | 8 |  |  |  |  | 12 |  |  |  |  |  |
| Transaction-related expenses | 3 |  |  |  |  | 3 |  |  | 6 |  |  |  |  | 8 |  |  |  |  |  |
| Stock-based compensation expense | 223 |  |  |  |  | 236 |  |  | 448 |  |  |  |  | 468 |  |  |  |  |  |
| Other corporate expenses | 373 |  |  |  |  | 196 |  |  | 471 |  |  |  |  | 292 |  |  |  |  |  |
| Non-GAAP operating income | $ | 1,977 |  |  | 1 | % |  | $ | 1,952 |  |  | $ | 3,575 |  |  | (13) | % |  | $ | 4,087 |  |  |  |  |  |
| Net income | $ | 455 |  |  | (10) | % |  | $ | 506 |  |  | $ | 1,033 |  |  | (34) | % |  | $ | 1,575 |  |  |  |  |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 209 |  |  |  |  | 244 |  |  | 408 |  |  |  |  | 487 |  |  |  |  |  |
| Impact of purchase accounting | 4 |  |  |  |  | 3 |  |  | 8 |  |  |  |  | 12 |  |  |  |  |  |
| Transaction-related (income) expenses | 60 |  |  |  |  | (4) |  |  | 59 |  |  |  |  | (6) |  |  |  |  |  |
| Stock-based compensation expense | 223 |  |  |  |  | 236 |  |  | 448 |  |  |  |  | 468 |  |  |  |  |  |
| Other corporate expenses | 372 |  |  |  |  | 212 |  |  | 471 |  |  |  |  | 308 |  |  |  |  |  |
| Fair value adjustments on equity investments | 29 |  |  |  |  | 255 |  |  | 44 |  |  |  |  | 241 |  |  |  |  |  |
| Aggregate adjustment for income taxes | (69) |  |  |  |  | (186) |  |  | (225) |  |  |  |  | (385) |  |  |  |  |  |
| Non-GAAP net income | $ | 1,283 |  |  | 1 | % |  | $ | 1,266 |  |  | $ | 2,246 |  |  | (17) | % |  | $ | 2,700 |  |  |  |  |  |

[0001571996-23-000032:mdna:81]
66

[0001571996-23-000032:mdna:82]
[same as prior period, unchanged from 0001571996-23-000019:mdna:85]

[0001571996-23-000032:mdna:83]
As is the case with the non-GAAP measures presented above, users should consider the limitations of using EBITDA and adjusted EBITDA, including the fact that those measures do not provide a complete measure of our operating performance.  EBITDA and adjusted EBITDA do not purport to be alternatives to net income as a measure of operating performance or to cash flows from operating activities as a measure of liquidity.  In particular, EBITDA and adjusted EBITDA are not intended to be a measure of cash flow available for management’s discretionary use, as these measures do not consider certain cash requirements, such as working capital needs, capital expenditures, contractual commitments, interest payments, tax payments, and other debt service requirements.

[0001571996-23-000032:mdna:84]
[same as prior period, unchanged from 0001571996-23-000019:mdna:87]

[0001571996-23-000032:mdna:85]
|  | Three Months Ended |  | Six Months Ended |
|  | August 4,2023 |  | % Change |  | July 29,2022 |  | August 4,2023 |  | % Change |  | July 29,2022 |  |  |  |  |
|  | (in millions, except percentages) |
| Net income | $ | 455 |  |  | (10) | % |  | $ | 506 |  |  | $ | 1,033 |  |  | (34) | % |  | $ | 1,575 |  |  |  |  |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest and other, net (a) | 451 |  |  |  |  | 635 |  |  | 815 |  |  |  |  | 972 |  |  |  |  |  |
| Income tax expense (benefit) | 259 |  |  |  |  | 129 |  |  | 386 |  |  |  |  | 273 |  |  |  |  |  |
| Depreciation and amortization | 831 |  |  |  |  | 744 |  |  | 1,640 |  |  |  |  | 1,470 |  |  |  |  |  |
| EBITDA | $ | 1,996 |  |  | (1) | % |  | $ | 2,014 |  |  | $ | 3,874 |  |  | (10) | % |  | $ | 4,290 |  |  |  |  |  |
| EBITDA | $ | 1,996 |  |  | (1) | % |  | $ | 2,014 |  |  | $ | 3,874 |  |  | (10) | % |  | $ | 4,290 |  |  |  |  |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation expense | 223 |  |  |  |  | 236 |  |  | 448 |  |  |  |  | 468 |  |  |  |  |  |
| Transaction-related expenses | 3 |  |  |  |  | 3 |  |  | 6 |  |  |  |  | 8 |  |  |  |  |  |
| Other corporate expenses | 373 |  |  |  |  | 196 |  |  | 471 |  |  |  |  | 292 |  |  |  |  |  |
| Adjusted EBITDA | $ | 2,595 |  |  | 6 | % |  | $ | 2,449 |  |  | $ | 4,799 |  |  | (5) | % |  | $ | 5,058 |  |  |  |  |  |

[0001571996-23-000032:mdna:86]
[same as prior period, unchanged from 0001571996-23-000019:mdna:89]

[0001571996-23-000032:mdna:87]
[same as prior period, unchanged from 0001571996-23-000019:mdna:90]

[0001571996-23-000032:mdna:88]
[same as prior period, unchanged from 0001571996-23-000019:mdna:91]

[0001571996-23-000032:mdna:89]
[same as prior period, unchanged from 0001571996-23-000019:mdna:92]

[0001571996-23-000032:mdna:90]
The following table summarizes our consolidated results for the periods indicated.  Unless otherwise indicated, all changes identified for the current-period results represent comparisons to results for the prior corresponding fiscal period.

[0001571996-23-000032:mdna:91]
|  | Three Months Ended |  | Six Months Ended |
|  | August 4, 2023 |  |  |  | July 29, 2022 |  | August 4, 2023 |  |  |  | July 29, 2022 |  |  |  |  |
|  | Dollars |  | % of Net Revenue |  | %Change |  | Dollars |  | % of Net Revenue |  | Dollars |  | % ofNet Revenue |  | %Change |  | Dollars |  | % ofNet Revenue |  |  |  |  |  |  |
|  | (in millions, except percentages) |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Products | $ | 16,935 |  |  | 73.8 | % |  | (19) | % |  | $ | 20,810 |  |  | 78.8 | % |  | $ | 31,971 |  |  | 72.9 | % |  | (23) | % |  | $ | 41,274 |  |  | 78.6 | % |  |  |  |  |  |  |
| Services | 5,999 |  |  | 26.2 | % |  | 7 | % |  | 5,615 |  |  | 21.2 | % |  | 11,885 |  |  | 27.1 | % |  | 5 | % |  | 11,267 |  |  | 21.4 | % |  |  |  |  |  |  |
| Total net revenue | $ | 22,934 |  |  | 100.0 | % |  | (13) | % |  | $ | 26,425 |  |  | 100.0 | % |  | $ | 43,856 |  |  | 100.0 | % |  | (17) | % |  | $ | 52,541 |  |  | 100.0 | % |  |  |  |  |  |  |
| Gross margin: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Products (a) | $ | 2,933 |  |  | 17.3 | % |  | (7) | % |  | $ | 3,139 |  |  | 15.1 | % |  | $ | 5,594 |  |  | 17.5 | % |  | (15) | % |  | $ | 6,594 |  |  | 16.0 | % |  |  |  |  |  |  |
| Services (b) | 2,454 |  |  | 40.9 | % |  | 7 | % |  | 2,300 |  |  | 41.0 | % |  | 4,811 |  |  | 40.5 | % |  | 4 | % |  | 4,629 |  |  | 41.1 | % |  |  |  |  |  |  |
| Total gross margin | $ | 5,387 |  |  | 23.5 | % |  | (1) | % |  | $ | 5,439 |  |  | 20.6 | % |  | $ | 10,405 |  |  | 23.7 | % |  | (7) | % |  | $ | 11,223 |  |  | 21.4 | % |  |  |  |  |  |  |
| Operating expenses | $ | 4,222 |  |  | 18.4 | % |  | 1 | % |  | $ | 4,169 |  |  | 15.8 | % |  | $ | 8,171 |  |  | 18.6 | % |  | (3) | % |  | $ | 8,403 |  |  | 16.0 | % |  |  |  |  |  |  |
| Operating income | $ | 1,165 |  |  | 5.1 | % |  | (8) | % |  | $ | 1,270 |  |  | 4.8 | % |  | $ | 2,234 |  |  | 5.1 | % |  | (21) | % |  | $ | 2,820 |  |  | 5.4 | % |  |  |  |  |  |  |
| Net income | $ | 455 |  |  | 2.0 | % |  | (10) | % |  | $ | 506 |  |  | 1.9 | % |  | $ | 1,033 |  |  | 2.4 | % |  | (34) | % |  | $ | 1,575 |  |  | 3.0 | % |  |  |  |  |  |  |
| Non-GAAP Financial Information |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  | Three Months Ended |  | Six Months Ended |
|  | August 4, 2023 |  |  |  | July 29, 2022 |  | August 4, 2023 |  |  |  | July 29, 2022 |  |  |  |  |
|  | Dollars |  | % of Net Revenue |  | %Change |  | Dollars |  | % of Net Revenue |  | Dollars |  | % ofNet Revenue |  | %Change |  | Dollars |  | % ofNet Revenue |  |  |  |  |  |  |
|  | (in millions, except percentages) |
| Non-GAAP gross margin: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Products (a) | $ | 3,037 |  |  | 17.9 | % |  | (7) | % |  | $ | 3,270 |  |  | 15.7 | % |  | $ | 5,798 |  |  | 18.1 | % |  | (15) | % |  | $ | 6,847 |  |  | 16.6 | % |  |  |  |  |  |  |
| Services (b) | 2,499 |  |  | 41.7 | % |  | 5 | % |  | 2,380 |  |  | 42.4 | % |  | 4,902 |  |  | 41.2 | % |  | 3 | % |  | 4,744 |  |  | 42.1 | % |  |  |  |  |  |  |
| Total non-GAAP gross margin | $ | 5,536 |  |  | 24.1 | % |  | (2) | % |  | $ | 5,650 |  |  | 21.4 | % |  | $ | 10,700 |  |  | 24.4 | % |  | (8) | % |  | $ | 11,591 |  |  | 22.1 | % |  |  |  |  |  |  |
| Non-GAAP operating expenses | $ | 3,559 |  |  | 15.5 | % |  | (4) | % |  | $ | 3,698 |  |  | 14.0 | % |  | $ | 7,125 |  |  | 16.2 | % |  | (5) | % |  | $ | 7,504 |  |  | 14.3 | % |  |  |  |  |  |  |
| Non-GAAP operating income | $ | 1,977 |  |  | 8.6 | % |  | 1 | % |  | $ | 1,952 |  |  | 7.4 | % |  | $ | 3,575 |  |  | 8.2 | % |  | (13) | % |  | $ | 4,087 |  |  | 7.8 | % |  |  |  |  |  |  |
| Non-GAAP net income | $ | 1,283 |  |  | 5.6 | % |  | 1 | % |  | $ | 1,266 |  |  | 4.8 | % |  | $ | 2,246 |  |  | 5.1 | % |  | (17) | % |  | $ | 2,700 |  |  | 5.1 | % |  |  |  |  |  |  |
| EBITDA | $ | 1,996 |  |  | 8.7 | % |  | (1) | % |  | $ | 2,014 |  |  | 7.6 | % |  | $ | 3,874 |  |  | 8.8 | % |  | (10) | % |  | $ | 4,290 |  |  | 8.2 | % |  |  |  |  |  |  |
| Adjusted EBITDA | $ | 2,595 |  |  | 11.3 | % |  | 6 | % |  | $ | 2,449 |  |  | 9.3 | % |  | $ | 4,799 |  |  | 10.9 | % |  | (5) | % |  | $ | 5,058 |  |  | 9.6 | % |  |  |  |  |  |  |

[0001571996-23-000032:mdna:92]
[same as prior period, unchanged from 0001571996-23-000019:mdna:95]

[0001571996-23-000032:mdna:93]
[same as prior period, unchanged from 0001571996-23-000019:mdna:96]

[0001571996-23-000032:mdna:94]
[same as prior period, unchanged from 0001571996-23-000019:mdna:97]

[0001571996-23-000032:mdna:95]
[same as prior period, unchanged from 0001571996-23-000019:mdna:98]

[0001571996-23-000032:mdna:96]
[same as prior period, unchanged from 0001571996-23-000019:mdna:99]

[0001571996-23-000032:mdna:97]
During the second quarter and first six months of Fiscal 2024, net revenue decreased by 13% and 17%, respectively, driven by declines in both CSG and ISG net revenue, which reflected the impact of challenging global macroeconomic conditions.  The decline in CSG net revenue was primarily attributable to a decrease in units sold, partially offset by an increase in average selling prices.  ISG net revenue decreased primarily as a result of a reduction in net revenue attributable to servers and networking and, to a lesser extent, a decline in storage net revenue.

[0001571996-23-000032:mdna:98]
During the second quarter of Fiscal 2024, operating income and non-GAAP operating income decreased by 8% to $1.2 billion and increased 1% to $2.0 billion, respectively.  The decline in operating income was driven by a decrease in net revenue coupled with an increase in other corporate expenses.  Non-GAAP operating income remained effectively flat as the impact of a decrease in net revenue was largely offset by a decline in input costs and by the impact of cost management measures.

[0001571996-23-000032:mdna:99]
During the first six months of Fiscal 2024, operating income and non-GAAP operating income decreased by 21% to $2.2 billion and 13% to $3.6 billion, respectively.  The declines were primarily attributable to a reduction in both ISG and CSG operating income as a result of a decrease in net revenue which was partially offset by the impact of disciplined cost management measures.  The decline in ISG operating income was primarily attributable to decreases in storage and, to a lesser extent, servers and networking.  The decline in CSG operating income was driven by decreases in both commercial and consumer.  The decrease in operating income was also impacted by an increase in other corporate expenses.

[0001571996-23-000032:mdna:100]
During the second quarter and first six months of Fiscal 2024, operating income as a percentage of net revenue increased 30 basis points to 5.1% and decreased 30 basis points to 5.1%, respectively.  Non-GAAP operating income as a percentage of net revenue increased 120 basis points to 8.6% and 40 basis points to 8.2% during the second quarter and first six months of Fiscal 2024, respectively.  Operating income and non-GAAP operating income as a percentage of net revenue during both the second quarter and first six months of Fiscal 2024 benefited from growth in gross margin as a percentage of net revenue, which increased primarily due to the impacts of an overall decrease in input costs coupled with an increase in average selling prices.  The impact of increases in gross margin as a percentage of net revenue was offset by increases in operating expense as a percentage of net revenue that were driven by a decline in net revenue which outpaced the impact of continued cost management measures.  Operating income as a percentage of net revenue during both periods was further impacted by an increase in other corporate expenses.

[0001571996-23-000032:mdna:101]
Cash provided by operating activities was $5.0 billion and $0.5 billion during the first six months of Fiscal 2024 and Fiscal 2023, respectively.  Cash provided by operating activities during the first six months of Fiscal 2024 was primarily driven by profitability and working capital management as we reduced inventory, demonstrated strong cash collections performance, and benefited from the timing of purchases and payments to vendors.  Cash provided by operating activities during the first six months of Fiscal 2023 reflected profitability, partially offset by the impact of working capital dynamics.  See “Liquidity, Cash Requirements, and Market Conditions” for additional information about our cash flow metrics.

[0001571996-23-000032:mdna:102]
Despite the near-term challenges driven by uncertainty in the macroeconomic environment, we continue to see opportunities to create value and grow as we respond to long-term demand for our IT solutions driven by a technology and data-enabled world.  We have demonstrated our ability to adjust to changing market conditions with complementary solutions and innovation across both segments of our business, an agile workforce, and the strength of our global supply chain.  As we continue to innovate and modernize our core offerings, we believe that Dell Technologies is well-positioned for long-term profitable growth.

[0001571996-23-000032:mdna:103]
[same as prior period, unchanged from 0001571996-23-000019:mdna:132]

[0001571996-23-000032:mdna:104]
[same as prior period, unchanged from 0001571996-23-000019:mdna:105]

[0001571996-23-000032:mdna:105]
During the second quarter and first six months of Fiscal 2024, net revenue decreased 13% and 17%, respectively, primarily driven by declines in both CSG and ISG net revenue.  See “Business Unit Results” for further information.

[0001571996-23-000032:mdna:106]
•Product Net Revenue — Product net revenue includes revenue from the sale of hardware products and software licenses.  During the second quarter and first six months of Fiscal 2024, product net revenue decreased 19% and 23%, respectively, due to declines in both CSG and ISG product net revenue.  CSG product net revenue decreased primarily as a result of a decline in units sold, which impacted both our commercial and consumer offerings, partially offset by an increase in average selling prices.  The decline in ISG product net revenue was primarily attributable to a decrease in product net revenue for servers and networking, driven by a decrease in units sold, and, to a lesser extent, a decline in our product net revenue for storage offerings.

[0001571996-23-000032:mdna:107]
•Services Net Revenue — Services net revenue includes revenue from our services offerings and support services related to hardware products and software licenses.  During the second quarter and first six months of Fiscal 2024, services net revenue increased 7% and 5%, respectively, driven primarily by growth within other businesses, which was principally attributable to VMware Resale, as well as third-party software support and maintenance within CSG and strength in hardware support and maintenance in both CSG and ISG.  A substantial portion of services net revenue is derived from offerings that have been deferred over a period of time, and, as a result, reported growth rates for services net revenue will be different than reported growth rates for product net revenue.

[0001571996-23-000032:mdna:108]
From a geographical perspective, net revenue decreased in the Americas, EMEA, and APJ regions during both the second quarter and first six months of Fiscal 2024.

[0001571996-23-000032:mdna:109]
[same as prior period, unchanged from 0001571996-23-000019:mdna:110]

[0001571996-23-000032:mdna:110]
During the second quarter of Fiscal 2024, gross margin and non-GAAP gross margin decreased 1% to $5.4 billion and 2% to $5.5 billion, respectively.  During the first six months of Fiscal 2024, gross margin and non-GAAP gross margin decreased 7% to $10.4 billion and 8% to $10.7 billion, respectively.  The declines were by driven by decreases in CSG and, to a lesser extent, ISG gross margin that were primarily attributable to decreases in net revenue, the effect of which was partially offset by lower input costs.

[0001571996-23-000032:mdna:111]
During the second quarter of Fiscal 2024, gross margin and non-GAAP gross margin percentage increased 290 basis points to 23.5% and 270 basis points to 24.1%, respectively.  During the first six months of Fiscal 2024, both gross margin and non-GAAP gross margin percentage increased 230 basis points to 23.7% and 24.4%, respectively.  The increases were primarily attributable to the impacts of an overall decline in input costs coupled with an increase in average selling price across many of our offerings as we maintained strong pricing discipline.

[0001571996-23-000032:mdna:112]
•Product Gross Margin — During the second quarter of Fiscal 2024, product gross margin and non-GAAP product gross margin both decreased 7% to $2.9 billion and $3.0 billion, respectively.  During the first six months of Fiscal 2024, product gross margin and non-GAAP product gross margin both decreased 15% to $5.6 billion and $5.8 billion, respectively.  The decreases were primarily driven by declines in both CSG and ISG product gross margin, which were largely attributable to declines in product net revenue.

[0001571996-23-000032:mdna:113]
During the second quarter of Fiscal 2024, both product gross margin percentage and non-GAAP product gross margin percentage increased 220 basis points to 17.3% and 17.9%, respectively, while during the first six months of Fiscal 2024, both product gross margin percentage and non-GAAP product gross margin percentage increased 150 basis points to 17.5% and 18.1%, respectively.  The increases were driven primarily by the impacts of an overall decline in input costs coupled with an increase in average selling price across many of our offerings as we maintained strong pricing discipline.

[0001571996-23-000032:mdna:114]
•Services Gross Margin — During the second quarter of Fiscal 2024, services gross margin and non-GAAP services gross margin increased 7% to $2.5 billion and 5% to $2.5 billion, respectively.  During the first six months of Fiscal 2024, services gross margin and non-GAAP services gross margin increased 4% to $4.8 billion and 3% to $4.9 billion, respectively.  The increases were primarily attributable to growth within ISG services gross margin driven by support and maintenance associated with products sold in prior periods.

[0001571996-23-000032:mdna:115]
During the second quarter and first six months of Fiscal 2024, services gross margin percentage decreased 10 basis points to 40.9% and 60 basis points to 40.5%, respectively.  The decreases were driven by a decline in services gross margin percentage for CSG, due to a shift in mix of CSG services delivered, partially offset by an increase in ISG services gross margin percentage coupled with the impact of asset impairment costs associated with exiting our Russia business in Fiscal 2023.

[0001571996-23-000032:mdna:116]
During the second quarter and first six months of Fiscal 2024, non-GAAP services gross margin percentage decreased 70 basis points to 41.7% and 90 basis points to 41.2%, respectively.  The decreases were driven by a decline in services gross margin percentage for CSG, due to a shift in mix of CSG services delivered, partially offset by an increase in ISG services gross margin percentage.

[0001571996-23-000032:mdna:117]
[same as prior period, unchanged from 0001571996-23-000019:mdna:117]

[0001571996-23-000032:mdna:118]
[same as prior period, unchanged from 0001571996-23-000019:mdna:118]

[0001571996-23-000032:mdna:119]
The terms and conditions of our vendor rebate programs are largely based on product volumes and are generally negotiated either at the beginning of the annual or quarterly period, depending on the program.  The timing and amount of vendor rebates and other discounts we receive under the programs may vary from period to period, reflecting changes in the competitive environment.  We monitor our component costs and seek to address the effects of any changes to terms that might arise under our vendor rebate programs.  Our gross margins for the second quarter and first six months of Fiscal 2024 were not materially affected by any changes to the terms of our vendor rebate programs, as the amounts we received under these programs were generally stable relative to our total net cost.  We are not aware of any significant changes to our vendor rebate programs that will materially impact our results in the near term.

[0001571996-23-000032:mdna:120]
[same as prior period, unchanged from 0001571996-23-000019:mdna:121]

[0001571996-23-000032:mdna:121]
[same as prior period, unchanged from 0001571996-23-000019:mdna:122]

[0001571996-23-000032:mdna:122]
|  | Three Months Ended |  | Six Months Ended |
|  | August 4, 2023 |  |  |  | July 29, 2022 |  | August 4, 2023 |  |  |  | July 29, 2022 |  |  |  |  |
|  | Dollars |  | % of Net Revenue |  | %Change |  | Dollars |  | % of Net Revenue |  | Dollars |  | % of Net Revenue |  | %Change |  | Dollars |  | % of Net Revenue |  |  |  |  |  |  |
|  | (in millions, except percentages) |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling, general, and administrative | $ | 3,517 |  |  | 15.3 | % |  | (1) | % |  | $ | 3,543 |  |  | 13.4 | % |  | $ | 6,778 |  |  | 15.4 | % |  | (4) | % |  | $ | 7,096 |  |  | 13.5 | % |  |  |  |  |  |  |
| Research and development | 705 |  |  | 3.1 | % |  | 13 | % |  | 626 |  |  | 2.4 | % |  | 1,393 |  |  | 3.2 | % |  | 7 | % |  | 1,307 |  |  | 2.5 | % |  |  |  |  |  |  |
| Total operating expenses | $ | 4,222 |  |  | 18.4 | % |  | 1 | % |  | $ | 4,169 |  |  | 15.8 | % |  | $ | 8,171 |  |  | 18.6 | % |  | (3) | % |  | $ | 8,403 |  |  | 16.0 | % |  |  |  |  |  |  |
|  | Three Months Ended |  | Six Months Ended |
|  | August 4, 2023 |  |  |  | July 29, 2022 |  | August 4, 2023 |  |  |  | July 29, 2022 |  |  |  |  |
|  | Dollars |  | % of Net Revenue |  | %Change |  | Dollars |  | % of Net Revenue |  | Dollars |  | % of Net Revenue |  | %Change |  | Dollars |  | % of Net Revenue |  |  |  |  |  |  |
|  | (in millions, except percentages) |
| Non-GAAP operating expenses | $ | 3,559 |  |  | 15.5 | % |  | (4) | % |  | $ | 3,698 |  |  | 14.0 | % |  | $ | 7,125 |  |  | 16.2 | % |  | (5) | % |  | $ | 7,504 |  |  | 14.3 | % |  |  |  |  |  |  |

[0001571996-23-000032:mdna:123]
During the second quarter of Fiscal 2024, total operating expenses increased 1%, driven by growth in research and development expenses.  During the first six months of Fiscal 2024, total operating expenses decreased 3% due to a decline in selling, general, and administrative expenses.

[0001571996-23-000032:mdna:124]
•Selling, General, and Administrative — Selling, general, and administrative (“SG&A”) expenses decreased 1% and 4%, respectively, during the second quarter and first six months of Fiscal 2024.  These decreases were attributable to continued disciplined cost management which resulted in a reduction in outside services and advertising expenses, among other items, partially offset by an increase in employee compensation and benefits expense.  Employee compensation and benefits expense increased primarily as a result of costs incurred in connection with workforce reductions.

[0001571996-23-000032:mdna:125]
•Research and Development — Research and development (“R&D”) expenses are primarily composed of personnel-related expenses incurred in connection with product development.  R&D expenses increased 13% and 7%, respectively, during the second quarter and first six months of Fiscal 2024 driven by an increase in employee compensation and benefits expense.

[0001571996-23-000032:mdna:126]
As a percentage of net revenue, R&D expenses for the second quarter of Fiscal 2024 and Fiscal 2023 were 3.1% and 2.4%, respectively, and for the first six months of Fiscal 2024 and Fiscal 2023 were 3.2% and 2.5%, respectively.  The increases in R&D expenses as a percentage of net revenue were attributable to continued R&D investments as we support R&D initiatives to innovate and introduce new and enhanced solutions into the market.

[0001571996-23-000032:mdna:127]
During the second quarter and first six months of Fiscal 2024, non-GAAP operating expenses decreased 4% and 5%, respectively, principally due to continued disciplined cost management which resulted in a decline in outside services and advertising expenses, among other items.

[0001571996-23-000032:mdna:128]
[same as prior period, unchanged from 0001571996-23-000019:mdna:128]

[0001571996-23-000032:mdna:129]
[same as prior period, unchanged from 0001571996-23-000019:mdna:129]

[0001571996-23-000032:mdna:130]
During the second quarter of Fiscal 2024, operating income and non-GAAP operating income decreased by 8% to $1.2 billion and increased 1% to $2.0 billion, respectively.  The decline in operating income was driven by a decrease in net revenue coupled with an increase in other corporate expenses.  Non-GAAP operating income remained effectively flat as the impact of a decrease in net revenue was largely offset by a decline in input costs and by the impact of cost management measures.

[0001571996-23-000032:mdna:131]
During the first six months of Fiscal 2024, operating income and non-GAAP operating income decreased by 21% to $2.2 billion and 13% to $3.6 billion, respectively.  The declines were primarily attributable to a reduction in both ISG and CSG operating income as a result of a decrease in net revenue which was partially offset by the impact of disciplined cost management measures.  The decline in ISG operating income was primarily attributable to decreases in storage and, to a lesser extent, servers and networking.  The decline in CSG operating income was driven by decreases in both commercial and consumer.  The decrease in operating income was also impacted by an increase in other corporate expenses.

[0001571996-23-000032:mdna:132]
During the second quarter and first six months of Fiscal 2024, operating income as a percentage of net revenue increased 30 basis points to 5.1% and decreased 30 basis points to 5.1%, respectively.  Non-GAAP operating income as a percentage of net revenue increased 120 basis points to 8.6% and 40 basis points to 8.2% during the second quarter and first six months of Fiscal 2024, respectively.  Operating income and non-GAAP operating income as a percentage of net revenue during both the second quarter and first six months of Fiscal 2024 benefited from growth in gross margin as a percentage of net revenue, which increased primarily due to the impacts of an overall decrease in input costs coupled with an increase in average selling prices.  The impact of increases in gross margin as a percentage of net revenue was offset by increases in operating expense as a percentage of net revenue that were driven by a decline in net revenue which outpaced the impact of continued cost management measures.  Operating income as a percentage of net revenue during both periods was further impacted by an increase in other corporate expenses.

[0001571996-23-000032:mdna:133]
[same as prior period, unchanged from 0001571996-23-000019:mdna:133]

[0001571996-23-000032:mdna:134]
[same as prior period, unchanged from 0001571996-23-000019:mdna:134]

[0001571996-23-000032:mdna:135]
|  | Three Months Ended |  | Six Months Ended |
|  | August 4, 2023 |  | July 29, 2022 |  | August 4, 2023 |  | July 29, 2022 |  |  |
|  | (in millions) |
| Interest and other, net: |  |  |  |  |  |  |  |  |  |
| Investment income, primarily interest | $ | 66 |  |  | $ | 16 |  |  | $ | 125 |  |  | $ | 31 |  |  |  |
| Loss on investments, net | (29) |  |  | (255) |  |  | (44) |  |  | (241) |  |  |  |
| Interest expense | (352) |  |  | (298) |  |  | (757) |  |  | (563) |  |  |  |
| Foreign exchange | (65) |  |  | (66) |  |  | (97) |  |  | (155) |  |  |  |
| Other | (71) |  |  | (32) |  |  | (42) |  |  | (44) |  |  |  |
| Total interest and other, net | $ | (451) |  |  | $ | (635) |  |  | $ | (815) |  |  | $ | (972) |  |  |  |

[0001571996-23-000032:mdna:136]
During the second quarter and first six months of Fiscal 2024, the change in interest and other, net was favorable, driven by a decrease in net loss on investments and an increase in investment income, partially offset by an increase in interest expense.  The decrease in net loss on investments resulted from fair value adjustments on our non-marketable strategic investment portfolio that occurred in the second quarter of Fiscal 2023.

[0001571996-23-000032:mdna:137]
[same as prior period, unchanged from 0001571996-23-000019:mdna:137]

[0001571996-23-000032:mdna:138]
[same as prior period, unchanged from 0001571996-23-000019:mdna:138]

[0001571996-23-000032:mdna:139]
|  | Three Months Ended |  | Six Months Ended |
|  | August 4, 2023 |  | July 29, 2022 |  | August 4, 2023 |  | July 29, 2022 |  |  |
|  | (in millions, except percentages) |
| Income before income taxes | $ | 714 |  |  | $ | 635 |  |  | $ | 1,419 |  |  | $ | 1,848 |  |  |  |
| Income tax expense | $ | 259 |  |  | $ | 129 |  |  | $ | 386 |  |  | $ | 273 |  |  |  |
| Effective income tax rate | 36.3 | % |  | 20.3 | % |  | 27.2 | % |  | 14.8 | % |  |  |

[0001571996-23-000032:mdna:140]
For the second quarter of Fiscal 2024 and Fiscal 2023, our effective income tax rate was 36.3% and 20.3%, respectively.  For the first six months of Fiscal 2024 and Fiscal 2023, our effective income tax rate was 27.2% and 14.8%, respectively.  The changes in our effective income tax rate were attributable to a change in our jurisdictional mix of income, higher U.S. tax on foreign operations, and the impact of discrete tax items.

[0001571996-23-000032:mdna:141]
Our effective income tax rate can fluctuate depending on the geographic distribution of our worldwide earnings, as our foreign earnings are generally taxed at lower rates than in the United States.  The differences between our effective income tax rates and the U.S. federal statutory rate of 21% principally result from the geographical distribution of income, differences between the book and tax treatment of certain items, and discrete tax items.  In certain jurisdictions, our tax rate is significantly less than the applicable statutory rate as a result of tax holidays.  The majority of our foreign income subject to these tax holidays is attributable to Singapore and China.  A significant portion of these income tax benefits relates to a tax holiday that will be effective until January 31, 2029.  Most of our other tax holidays will expire in whole or in part during Fiscal 2030 through Fiscal 2031.  Many of these tax holidays and reduced tax rates may be extended when certain conditions are met or may be terminated early if certain conditions are not met or as a result of changes in tax legislation.  As of August 4, 2023, we were not aware of any matters of noncompliance or enacted tax legislative changes affecting these tax holidays.

[0001571996-23-000032:mdna:142]
[same as prior period, unchanged from 0001571996-23-000019:mdna:142]

[0001571996-23-000032:mdna:143]
[same as prior period, unchanged from 0001571996-23-000019:mdna:143]

[0001571996-23-000032:mdna:144]
During both the second quarter of Fiscal 2024 and Fiscal 2023, net income was $0.5 billion.  Non-GAAP net income was $1.3 billion for both the second quarter of Fiscal 2024 and Fiscal 2023.  Net income performance reflected a decline in operating income and an increase in tax expense that were offset by a favorable change in interest and other, net.  Consistent with non-GAAP operating income, non-GAAP net income reflected a decrease in net revenue that was largely offset by a decline in input costs and the impact of cost management measures.

[0001571996-23-000032:mdna:145]
During the first six months of Fiscal 2024 and Fiscal 2023, net income was $1.0 billion and $1.6 billion, respectively.  Non-GAAP net income was $2.2 billion and $2.7 billion for the first six months of Fiscal 2024 and Fiscal 2023, respectively.  The decreases in both net income and non-GAAP net income were principally attributable to a decline in operating income.

[0001571996-23-000032:mdna:146]
[same as prior period, unchanged from 0001571996-23-000019:mdna:146]

[0001571996-23-000032:mdna:147]
Our reportable segments are based on the ISG and CSG business units.  A description of our business units is provided under “Introduction.”  See Note 16 of the Notes to the Condensed Consolidated Financial Statements included in this report for a reconciliation of net revenue and operating income by reportable segment to consolidated net revenue and consolidated operating income, respectively.

[0001571996-23-000032:mdna:148]
[same as prior period, unchanged from 0001571996-23-000019:mdna:148]

[0001571996-23-000032:mdna:149]
[same as prior period, unchanged from 0001571996-23-000019:mdna:149]

[0001571996-23-000032:mdna:150]
|  | Three Months Ended |  | Six Months Ended |
|  | August 4, 2023 |  | % Change |  | July 29, 2022 |  | August 4, 2023 |  | % Change |  | July 29, 2022 |  |  |  |  |
|  | (in millions, except percentages) |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Servers and networking | $ | 4,274 |  |  | (18) | % |  | $ | 5,209 |  | $ | 8,111 |  | (21) | % |  | $ | 10,257 |  |  |  |  |
| Storage | 4,187 |  |  | (3) | % |  | 4,327 |  | 7,943 |  | (7) | % |  | 8,564 |  |  |  |  |
| Total ISG net revenue | $ | 8,461 |  |  | (11) | % |  | $ | 9,536 |  | $ | 16,054 |  | (15) | % |  | $ | 18,821 |  |  |  |  |
| Operating income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| ISG operating income | $ | 1,049 |  |  | — | % |  | $ | 1,046 |  | $ | 1,789 |  | (16) | % |  | $ | 2,128 |  |  |  |  |
| % of segment net revenue | 12.4 | % |  |  |  | 11.0 | % |  | 11.1 | % |  |  |  | 11.3 | % |  |  |  |  |

[0001571996-23-000032:mdna:151]
Net Revenue — During the second quarter and first six months of Fiscal 2024, ISG net revenue decreased 11% and 15%, respectively, driven by a decline in servers and networking net revenue and, to a lesser extent, a decline in storage net revenue.

[0001571996-23-000032:mdna:152]
Revenue from sales of servers and networking decreased 18% and 21% during the second quarter and first six months of Fiscal 2024, respectively, driven by a decrease in units sold, the effect of which was partially offset by an increase in average selling price of our server offerings.  The average selling price for our server offerings increased as a result of richer configurations and the impact of attached offerings.

[0001571996-23-000032:mdna:153]
During the second quarter and first six months of Fiscal 2024, storage revenue decreased 3% and 7%, respectively, due to a decline in net revenue across the majority of our storage offerings.

[0001571996-23-000032:mdna:154]
From a geographical perspective, net revenue attributable to ISG decreased in the Americas, EMEA, and APJ during the second quarter and first six months of Fiscal 2024.

[0001571996-23-000032:mdna:155]
Operating Income — During the second quarter of Fiscal 2024, ISG operating income as a percentage of net revenue increased 140 basis points to 12.4%, principally due to the impact of an overall decline in input costs coupled with an increase in average selling price.  The increase in operating income as a percentage of net revenue was partially offset by an increase in operating expenses as a percentage of net revenue due to a decline in revenue that outpaced the impact of cost management measures.

[0001571996-23-000032:mdna:156]
During the first six months of Fiscal 2024, ISG operating income as a percentage of net revenue decreased 20 basis points to 11.1%, principally due to an increase in operating expenses as a percentage of net revenue that resulted from a decline in net revenue which outpaced the impact of cost management measures.  The impact of an increase in operating expenses as a percentage of net revenue was partially offset by the impacts of an overall decrease in input costs coupled with an increase in average selling price.

[0001571996-23-000032:mdna:157]
[same as prior period, unchanged from 0001571996-23-000019:mdna:176]

[0001571996-23-000032:mdna:158]
[same as prior period, unchanged from 0001571996-23-000019:mdna:157]

[0001571996-23-000032:mdna:159]
[same as prior period, unchanged from 0001571996-23-000019:mdna:158]

[0001571996-23-000032:mdna:160]
|  | Three Months Ended |  | Six Months Ended |
|  | August 4, 2023 |  | % Change |  | July 29, 2022 |  | August 4, 2023 |  | % Change |  | July 29, 2022 |  |  |  |  |
|  | (in millions, except percentages) |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Commercial | $ | 10,554 |  |  | (13) | % |  | $ | 12,141 |  | $ | 20,416 |  | (15) | % |  | $ | 24,112 |  |  |  |  |
| Consumer | 2,388 |  |  | (29) | % |  | 3,349 |  | 4,509 |  | (35) | % |  | 6,965 |  |  |  |  |
| Total CSG net revenue | $ | 12,942 |  |  | (16) | % |  | $ | 15,490 |  | $ | 24,925 |  | (20) | % |  | $ | 31,077 |  |  |  |  |
| Operating income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| CSG operating income | $ | 969 |  |  | (1) | % |  | $ | 978 |  | $ | 1,861 |  | (11) | % |  | $ | 2,093 |  |  |  |  |
| % of segment net revenue | 7.5 | % |  |  |  | 6.3 | % |  | 7.5 | % |  |  |  | 6.7 | % |  |  |  |  |

[0001571996-23-000032:mdna:161]
Net Revenue — During the second quarter and first six months of Fiscal 2024, CSG net revenue decreased 16% and 20%, respectively, driven by a decline in units sold as uncertain macroeconomic conditions continued to impact industry-wide demand.

[0001571996-23-000032:mdna:162]
Commercial net revenue decreased 13% and 15%, respectively, during the second quarter and first six months of Fiscal 2024.  The decreases were primarily due to a decrease in units sold which was partially offset by the effect of an increase in the average selling price of our commercial offerings.

[0001571996-23-000032:mdna:163]
Consumer net revenue decreased 29% and 35%, respectively, during the second quarter and first six months of Fiscal 2024, principally due to a decrease in units sold.  During the first six months of Fiscal 2024, the decline was partially offset by the effect of an increase in the average selling price of our consumer offerings.

[0001571996-23-000032:mdna:164]
Average selling prices for our CSG offerings increased during the second quarter and first six months of Fiscal 2024 primarily as a result of a shift in mix towards our commercial offerings coupled with richer configurations and the impact of attached offerings.

[0001571996-23-000032:mdna:165]
From a geographical perspective, net revenue attributable to CSG decreased primarily in APJ and, to a lesser extent, in the Americas and EMEA during both the second quarter and first six months of Fiscal 2024.

[0001571996-23-000032:mdna:166]
Operating Income — During the second quarter and first six months of Fiscal 2024, CSG operating income as a percentage of net revenue increased 120 and 80 basis points, respectively, to 7.5%, primarily due to the impact of an overall decrease in input costs coupled with an increase in average selling prices.  The impact was partially offset by an increase in operating expenses as a percentage of net revenue, which increased as a result of a decline in CSG net revenue that outpaced the impact of cost management measures.

[0001571996-23-000032:mdna:167]
[same as prior period, unchanged from 0001571996-23-000019:mdna:165]

[0001571996-23-000032:mdna:168]
[same as prior period, unchanged from 0001571996-23-000019:mdna:166]

[0001571996-23-000032:mdna:169]
We sell products and services directly to customers and through a variety of sales channels, including retail distribution.  Our accounts receivable, net, was $10.4 billion and $12.5 billion as of August 4, 2023 and February 3, 2023, respectively.  The reduction in accounts receivable, net primarily reflects strong collections coupled with a decline in net revenue.  We maintain an allowance for expected credit losses to cover receivables that may be deemed uncollectible.  The allowance for expected credit losses is an estimate based on an analysis of historical loss experience, current receivables aging, and management’s assessment of current conditions and its reasonable and supportable expectation of future conditions, as well as specific identifiable customer accounts that are deemed at risk.  As of August 4, 2023 and February 3, 2023, the allowance for expected credit losses was $80 million and $78 million, respectively.  Based on our assessment, we believe that we are adequately reserved for expected credit losses.  We are monitoring the impact of current economic conditions and the aging of our accounts receivable on our expected losses and have not experienced deterioration in delinquency or loss rates.  We will continue to take actions, where necessary, to reduce our exposure to credit losses.

[0001571996-23-000032:mdna:170]
[same as prior period, unchanged from 0001571996-23-000019:mdna:168]

[0001571996-23-000032:mdna:171]
We offer or arrange various financing options and services for our customers globally, including through captive financing operations.  DFS originates, collects, and services customer receivables primarily related to the purchase of our product, software, and service solutions.  We further strengthen customer relationships through flexible consumption models, including utility, subscription, and as-a-Service models, which enable us to offer our customers the option to pay over time to provide them with financial flexibility to meet their changing technological requirements.  We have historically seen an increasing interest in our various financing options during times of macroeconomic uncertainty.  New financing originations were $2.4 billion and $2.3 billion for the second quarter of Fiscal 2024 and Fiscal 2023, respectively, and $4.2 billion and $4.4 billion for the first six months of Fiscal 2024 and Fiscal 2023, respectively.

[0001571996-23-000032:mdna:172]
Our leases are generally classified as sales-type leases or operating leases.  On commencement of sales-type leases, we recognize profit up-front, and recognize amounts due from the customer under the lease contract as financing receivables.  Interest income is recognized as net product revenue over the term of the lease.  Upon origination of operating leases, we record equipment under operating leases, classified as property, plant, and equipment.  We recognize product revenue and depreciation expense, classified as cost of net revenue, over the contract term.

[0001571996-23-000032:mdna:173]
As of August 4, 2023 and February 3, 2023, our financing receivables, net were $10.6 billion and $10.9 billion, respectively.  The decline in financing receivables was driven by the reclassification of the U.S. consumer revolving customer financing receivables portfolio to current assets held for sale on the Condensed Consolidated Statements of Financial Position.  See Note 4 of the Notes to the Condensed Consolidated Financial Statements included in this report for additional information about the reclassification.  We maintain an allowance to cover expected financing receivable credit losses and evaluate credit loss expectations based on our total portfolio.  For the second quarter and first six months of Fiscal 2024 and Fiscal 2023, the principal charge-off rate for our financing receivables portfolio was 0.6% and 0.5%, respectively.  The credit quality of our financing receivables has improved in recent years as the mix of high-quality commercial accounts in our portfolio has continued to increase.  We continue to monitor broader economic indicators and their potential impact on future credit loss performance.  We have an extensive process to manage our exposure to customer credit risk, including active management of credit lines and our collection activities.  We also sell selected fixed-term financing receivables without recourse to unrelated third parties on a periodic basis, primarily to manage certain concentrations of customer credit exposure.  Based on our assessment of the customer financing receivables, we believe that we are adequately reserved.

[0001571996-23-000032:mdna:174]
We retain a residual interest in equipment leased under our lease programs.  As of August 4, 2023 and February 3, 2023, the residual interest recorded as part of financing receivables was $150 million and $142 million, respectively.  The amount of the residual interest is established at the inception of the lease based upon estimates of the value of the equipment at the end of the lease term using historical studies, industry data, and future value-at-risk demand valuation methods.  On a quarterly basis, we assess the carrying amount of our recorded residual values for expected losses.  Generally, expected losses as a result of residual value risk on equipment under lease are not considered to be significant primarily because of the existence of a secondary market with respect to the equipment.  Further, the lease agreement defines applicable return conditions and remedies for non-compliance to ensure that the leased equipment will be in good operating condition upon return.  No expected losses were recorded related to residual assets during the second quarter and first six months of Fiscal 2024 and Fiscal 2023.

[0001571996-23-000032:mdna:175]
As of August 4, 2023 and February 3, 2023, equipment under operating leases, net was $2.1 billion and $2.2 billion, respectively.  We assess the carrying amount of the equipment under operating leases for impairment whenever events or circumstances may indicate that an impairment has occurred.  No material impairment losses were recorded related to such equipment during the second quarter and first six months of Fiscal 2024 and Fiscal 2023.

[0001571996-23-000032:mdna:176]
DFS offerings are initially funded through cash on hand at the time of origination, most of which is subsequently replaced with asset-backed financing.  For DFS offerings which qualify as sales-type leases, the initial funding of financing receivables is reflected as an impact to cash flows from operations and is largely subsequently offset by cash proceeds from financing.  For DFS operating leases, the initial funding is classified as a capital expenditure and reflected as an impact to cash flows used in investing activities.

[0001571996-23-000032:mdna:177]
[same as prior period, unchanged from 0001571996-23-000019:mdna:175]

[0001571996-23-000032:mdna:178]
78

[0001571996-23-000032:mdna:179]
[same as prior period, unchanged from 0001571996-23-000019:mdna:177]

[0001571996-23-000032:mdna:180]
[same as prior period, unchanged from 0001571996-23-000019:mdna:178]

[0001571996-23-000032:mdna:181]
[same as prior period, unchanged from 0001571996-23-000019:mdna:179]

[0001571996-23-000032:mdna:182]
[same as prior period, unchanged from 0001571996-23-000019:mdna:180]

[0001571996-23-000032:mdna:183]
We believe that our current cash and cash equivalents, together with cash that will be provided by future operations and borrowings expected to be available under our revolving credit facility and commercial paper program, will be sufficient over at least the next twelve months and for the foreseeable future thereafter to meet our material cash requirements, including funding of our operations, debt-related payments, capital expenditures, and other corporate needs.

[0001571996-23-000032:mdna:184]
As part of our overall capital allocation strategy, we intend to return capital to our stockholders through both share repurchase programs and dividend payments, drive growth, and maintain our investment grade credit rating.

[0001571996-23-000032:mdna:185]
[same as prior period, unchanged from 0001571996-23-000019:mdna:183]

[0001571996-23-000032:mdna:186]
|  | August 4, 2023 |  | February 3, 2023 |
|  | (in millions) |
| Cash and cash equivalents, and available borrowings: |  |  |  |
| Cash and cash equivalents | $ | 8,364 |  |  | $ | 8,607 |  |
| Remaining available borrowings under 2021 Revolving Credit Facility | 5,999 |  |  | 5,999 |  |
| Total cash and cash equivalents, and available borrowings | $ | 14,363 |  |  | $ | 14,606 |  |

[0001571996-23-000032:mdna:187]
During the first six months of Fiscal 2024, cash and cash equivalents decreased by $0.2 billion primarily as a result of the repayment of Senior Notes, capital expenditures, and the return of capital to our stockholders, partially offset by cash flows from operations.

[0001571996-23-000032:mdna:188]
As of August 4, 2023, our 2021 Revolving Credit Facility had a maximum capacity of $6.0 billion.  Available borrowings under this facility are reduced by draws on the facility and outstanding letters of credit.  As of August 4, 2023, there were no borrowings outstanding under the facility and remaining available borrowings totaled approximately $6.0 billion.  The 2021 Revolving Credit Facility also acts as a backstop to provide liquidity support for our commercial paper program.

[0001571996-23-000032:mdna:189]
During Fiscal 2023, we established a commercial paper program under which we may issue unsecured notes in a maximum aggregate face amount of $5.0 billion outstanding at any time, with maturities up to 397 days from the date of issue.  As of August 4, 2023, we had no outstanding borrowings under the program.

[0001571996-23-000032:mdna:190]
We may regularly use our available borrowings from the 2021 Revolving Credit Facility and issuances under the commercial paper program on a short-term basis for general corporate purposes.  See Note 6 of the Notes to the Condensed Consolidated Financial Statements included in this report for additional information about our debt.

[0001571996-23-000032:mdna:191]
[same as prior period, unchanged from 0001571996-23-000019:mdna:189]

[0001571996-23-000032:mdna:192]
[same as prior period, unchanged from 0001571996-23-000019:mdna:190]

[0001571996-23-000032:mdna:193]
|  | August 4, 2023 |  | Change |  | February 3, 2023 |
|  | (in millions) |
| Core debt |  |  |  |  |  |
| Senior Notes | $ | 16,131 |  |  | $ | (2,169) |  |  | $ | 18,300 |  |
| Legacy Notes and Debentures | 952 |  |  | — |  |  | 952 |  |
| DFS allocated debt | (1,467) |  |  | (271) |  |  | (1,196) |  |
| Total core debt | 15,616 |  |  | (2,440) |  |  | 18,056 |  |
| DFS related debt |  |  |  |  |  |
| DFS debt | 10,043 |  |  | (247) |  |  | 10,290 |  |
| DFS allocated debt | 1,467 |  |  | 271 |  |  | 1,196 |  |
| Total DFS related debt | 11,510 |  |  | 24 |  |  | 11,486 |  |
| Other | 262 |  |  | (63) |  |  | 325 |  |
| Total debt, principal amount | 27,388 |  |  | (2,479) |  |  | 29,867 |  |
| Carrying value adjustments | (250) |  |  | 29 |  |  | (279) |  |
| Total debt, carrying value | $ | 27,138 |  |  | $ | (2,450) |  |  | $ | 29,588 |  |

[0001571996-23-000032:mdna:194]
The outstanding principal amount of our debt decreased $2.5 billion to $27.4 billion as of August 4, 2023, driven primarily by the prepayment of $2.0 billion principal amount of Senior Notes.

[0001571996-23-000032:mdna:195]
We define core debt as the total principal amount of our debt, less DFS related debt and other debt.  Our core debt was $15.6 billion and $18.1 billion as of August 4, 2023 and February 3, 2023, respectively.  See Note 6 of the Notes to the Condensed Consolidated Financial Statements included in this report for additional information about our debt.

[0001571996-23-000032:mdna:196]
[same as prior period, unchanged from 0001571996-23-000019:mdna:194]

[0001571996-23-000032:mdna:197]
To fund expansion of the DFS business, we balance the use of the securitization and structured financing programs with other sources of liquidity.  We approximate the amount of our core debt used to fund the DFS business by applying a 7:1 debt-to-equity ratio to the sum of our financing receivables balance and equipment under our DFS operating leases, net.  The debt-to-equity ratio is based on the underlying credit quality of the assets.  During the second quarter of Fiscal 2024, we entered into a definitive agreement to sell our U.S. consumer revolving customer financing receivables portfolio.  In accordance with applicable accounting guidance, we reclassified $389 million of financing receivables, net of allowance, to current assets held for sale on the Condensed Consolidated Statement of Financial Position as of August 4, 2023.  This amount is included in the calculation of DFS allocated debt.  See Note 4 of the Notes to the Condensed Consolidated Financial Statements included in this report for additional information about our DFS debt.

[0001571996-23-000032:mdna:198]
We believe we will continue to be able to make our debt principal and interest payments, including short-term maturities, from existing and expected sources of cash, primarily from operating cash flows.  Cash used for debt principal and interest payments may include short-term borrowings under our commercial paper program, our revolving credit facility, or other borrowings.  Under our variable-rate debt, we could experience variations in our future interest expense from potential fluctuations in applicable reference rates, or from possible fluctuations in the level of DFS debt required to meet future demand for customer financing.

[0001571996-23-000032:mdna:199]
[same as prior period, unchanged from 0001571996-23-000019:mdna:197]

[0001571996-23-000032:mdna:200]
[same as prior period, unchanged from 0001571996-23-000019:mdna:198]

[0001571996-23-000032:mdna:201]
[same as prior period, unchanged from 0001571996-23-000019:mdna:199]

[0001571996-23-000032:mdna:202]
|  | Six Months Ended |
|  | August 4, 2023 |  | July 29, 2022 |  |  |
|  | (in millions) |
| Net change in cash from: |  |  |  |  |  |
| Operating activities | $ | 4,991 |  |  | $ | 455 |  |  |  |
| Investing activities | (1,289) |  |  | (1,498) |  |  |  |
| Financing activities | (3,829) |  |  | (2,752) |  |  |  |
| Effect of exchange rate changes on cash, cash equivalents, and restricted cash | (117) |  |  | (194) |  |  |  |
| Change in cash, cash equivalents, and restricted cash | $ | (244) |  |  | $ | (3,989) |  |  |  |

[0001571996-23-000032:mdna:203]
Operating Activities — Cash provided by operating activities was $5.0 billion during the first six months of Fiscal 2024, and was primarily driven by profitability and working capital management as we reduced inventory, demonstrated strong cash collections performance, and benefited from the timing of purchases and payments to vendors.  Cash provided by operating activities also reflected the impact of the $0.9 billion net payment to settle the Class V transaction litigation.  During the first six months of Fiscal 2023, cash provided by operating activities was $0.5 billion, which primarily reflected profitability that was partially offset by the impact of working capital dynamics.

[0001571996-23-000032:mdna:204]
Investing Activities — Investing activities primarily consist of cash used to fund capital expenditures for property, plant, and equipment inclusive of equipment under DFS operating leases and equipment used to support our as-a-Service offerings, which we refer to collectively as revenue-generating assets.  Additional activities include capitalized software development costs, acquisitions and divestitures, and the maturities, sales, and purchases of investments.  Cash used in investing activities was $1.3 billion and $1.5 billion during the first six months of Fiscal 2024 and Fiscal 2023, respectively, and was primarily applied to capital expenditures.

[0001571996-23-000032:mdna:205]
Financing Activities — Financing activities primarily consist of the proceeds and repayments of debt and return of capital to our stockholders.  Cash used in financing activities was $3.8 billion during the first six months of Fiscal 2024 and primarily consisted of principal repayments of our Senior Notes, repurchases of common stock, inclusive of payments to settle employee tax withholdings on stock-based compensation, and the payment of quarterly dividends.  During the first six months of Fiscal 2023, cash used in financing activities was $2.8 billion and primarily consisted of repurchases of common stock, inclusive of payments to settle employee tax withholdings on stock-based compensation, and the payment of quarterly dividends.

[0001571996-23-000032:mdna:206]
DFS Cash Flow Impacts — DFS offerings are initially funded through cash on hand at the time of origination, most of which is subsequently replaced with asset-backed financing.  For DFS offerings that qualify as sales-type leases, the initial funding of financing receivables is reflected as an impact to cash flows from operations and is largely subsequently offset by cash proceeds from financing.  For operating leases, the initial funding is classified as a capital expenditure and reflected as cash flows used in investing activities.  DFS new financing originations were $4.2 billion and $4.4 billion during the first six months of Fiscal 2024 and Fiscal 2023, respectively.  As of August 4, 2023, the Company had $10.6 billion of total net financing receivables and $2.1 billion of equipment under operating leases, net.

[0001571996-23-000032:mdna:207]
[same as prior period, unchanged from 0001571996-23-000019:mdna:205]

[0001571996-23-000032:mdna:208]
Capital Commitments and Other Cash Requirements

[0001571996-23-000032:mdna:209]
Capital Expenditures — We spent $1.3 billion and $1.5 billion, respectively, during the first six months of Fiscal 2024 and Fiscal 2023 on property, plant, and equipment and capitalized software development costs.  Of total expenditures incurred, funding of revenue-generating assets totaled $0.5 billion and $0.7 billion during the first six months of Fiscal 2024 and Fiscal 2023, respectively.  Product demand, product mix, the use of contract manufacturers, and ongoing investments in operating and information technology infrastructure influence the level and prioritization of our capital expenditures.  Aggregate capital expenditures for Fiscal 2024 are currently expected to total between $3.2 billion and $3.4 billion, of which approximately $1.7 billion are expected to relate to revenue-generating assets.

[0001571996-23-000032:mdna:210]
Repurchases of Common Stock — Effective as of September 23, 2021, our Board of Directors approved a stock repurchase program with no fixed expiration date under which we are authorized to repurchase up to $5 billion of shares of our Class C Common Stock.  During the first six months of Fiscal 2024, the Company repurchased approximately 11 million shares of Class C Common Stock for a total purchase price of approximately $0.5 billion.  During the first six months of Fiscal 2023, the Company repurchased approximately 42 million shares of Class C Common Stock for a total purchase price of approximately $2.1 billion.

[0001571996-23-000032:mdna:211]
Dividend Payments — On February 24, 2022, we announced that our Board of Directors adopted a dividend policy providing for our payment of quarterly cash dividends on our common stock at a rate of $0.33 per share per fiscal quarter beginning in the first quarter of Fiscal 2023.  On March 2, 2023, the Company announced that the Board of Directors approved a 12% increase in the quarterly dividend rate from $0.33 per share per fiscal quarter to a rate of $0.37 per share per fiscal quarter beginning in the first quarter of Fiscal 2024.  During the first six months of Fiscal 2024 and Fiscal 2023, the Company paid $545 million and $490 million, respectively, in dividends and dividend equivalents.

[0001571996-23-000032:mdna:212]
[same as prior period, unchanged from 0001571996-23-000019:mdna:210]

[0001571996-23-000032:mdna:213]
[same as prior period, unchanged from 0001571996-23-000019:mdna:211]

[0001571996-23-000032:mdna:214]
[same as prior period, unchanged from 0001571996-23-000019:mdna:212]

[0001571996-23-000032:mdna:215]
[same as prior period, unchanged from 0001571996-23-000019:mdna:213]

[0001571996-23-000032:mdna:216]
[same as prior period, unchanged from 0001571996-23-000019:mdna:214]

[0001571996-23-000032:mdna:217]
82

[0001571996-23-000032:mdna:218]
[same as prior period, unchanged from 0001571996-23-000019:mdna:215]

[0001571996-23-000032:mdna:219]
[same as prior period, unchanged from 0001571996-23-000019:mdna:216]

[0001571996-23-000032:mdna:220]
83

[0001571996-23-000032:mdna:221]
[same as prior period, unchanged from 0001571996-23-000019:mdna:218]

[0001571996-23-000032:mdna:222]
[same as prior period, unchanged from 0001571996-23-000019:mdna:219]

[0001571996-23-000032:mdna:223]
[same as prior period, unchanged from 0001571996-23-000019:mdna:220]

[0001571996-23-000032:mdna:224]
[same as prior period, unchanged from 0001571996-23-000019:mdna:221]

[0001571996-23-000032:mdna:225]
Basis of Preparation of the Summarized Financial Information — The tables below are summarized financial information provided in conformity with Rule 13-01 of the SEC’s Regulation S-X.  The summarized financial information of the Issuers and Guarantors (collectively, the “Obligor Group”) is presented on a combined basis, excluding intercompany balances and transactions between entities in the Obligor Group.  The Obligor Group’s amounts due from, amounts due to, and transactions with Non-Obligor Subsidiaries and VMware, Inc. and its consolidated subsidiaries (the “Related Party”) have been presented separately.  The Obligor Group’s investment balances in Non-Obligor Subsidiaries have been excluded.

[0001571996-23-000032:mdna:226]
[same as prior period, unchanged from 0001571996-23-000019:mdna:223]

[0001571996-23-000032:mdna:227]
|  | Six Months Ended |
|  | August 4, 2023 |
|  | (in millions) |
| Net revenue (a) | $ | 4,522 |  |
| Gross margin (b) | 1,873 |  |
| Operating income | 288 |  |
| Interest and other, net (c) | (1,981) |  |
| Loss before income taxes | $ | (1,693) |  |
| Net loss attributable to Obligor Group | $ | (1,287) |  |

[0001571996-23-000032:mdna:228]
[same as prior period, unchanged from 0001571996-23-000019:mdna:225]

[0001571996-23-000032:mdna:229]
(a)      Includes net revenue from services provided and product sales to Non-Obligor Subsidiaries of $420 million and $49 million, respectively.

[0001571996-23-000032:mdna:230]
(b)      Includes cost of net revenue from the resale of solutions purchased from Non-Obligor Subsidiaries and the Related Party of $465 million and $196 million, respectively.  Includes cost of net revenue from shared services provided by Non-Obligor Subsidiaries of $291 million.

[0001571996-23-000032:mdna:231]
(c)    Includes interest expense on intercompany loan payables of $1,304 million and other expenses from services provided by Non-Obligor Subsidiaries of $42 million.

[0001571996-23-000032:mdna:232]
84

[0001571996-23-000032:mdna:233]
[same as prior period, unchanged from 0001571996-23-000019:mdna:229]

[0001571996-23-000032:mdna:234]
|  | August 4, 2023 |  | February 3, 2023 |
|  | (in millions) |
| ASSETS |
| Current assets | $ | 2,060 |  |  | $ | 2,972 |  |
| Intercompany receivables | — |  |  | 595 |  |
| Due from related party, net | 344 |  |  | 312 |  |
| Short-term intercompany loan receivables | — |  |  | 227 |  |
| Total current assets | 2,404 |  |  | 4,106 |  |
| Due from related party, net | 236 |  |  | 440 |  |
| Goodwill and intangible assets | 14,588 |  |  | 14,818 |  |
| Other non-current assets | 3,175 |  |  | 3,009 |  |
| Total assets | $ | 20,403 |  |  | $ | 22,373 |  |
| LIABILITIES |
| Current liabilities | $ | 5,117 |  |  | $ | 6,611 |  |
| Intercompany payable | 1,016 |  |  | — |  |
| Due to related party | 56 |  |  | 110 |  |
| Total current liabilities | 6,189 |  |  | 6,721 |  |
| Long-term debt | 15,856 |  |  | 17,996 |  |
| Intercompany loan payables | 38,827 |  |  | 38,896 |  |
| Other non-current liabilities | 3,603 |  |  | 3,891 |  |
| Total liabilities | $ | 64,475 |  |  | $ | 67,504 |  |

[0001571996-23-000032:mdna:235]
85
