# DELL note change history — 0001571996-23-000019 → 0001571996-23-000032


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2023-09-12):
[0001571996-23-000032:note_history:1]
As previously reported, during the fourth quarter of Fiscal 2023, the plaintiffs and the defendants entered into an agreement to settle the lawsuit.  Under the terms of the settlement, the plaintiffs agreed to the dismissal of all claims upon payment of a total of $1.0 billion (the “settlement amount”), which includes all costs, expenses and fees of the plaintiff class relating to the action and its resolution.  The settlement terms required that the settlement amount be paid by the Company and/or the Company’s insurers pursuant to indemnification obligations of the Company to the defendants.  The Company is subject to indemnification obligations, upon the satisfaction of specified conditions, to the director and stockholder defendants and their affiliates pursuant to provisions of the Delaware General Corporation Law, the Company’s certificate of incorporation and bylaws, and agreements with the defendants.  A special committee of the Board of Directors consisting of directors who were not defendants in the action, advised by independent counsel, informed the Board of Directors of its determination that the defendants are entitled to indemnification under the foregoing obligations.
  (was, 2023-06-12, similarity 0.989):
[0001571996-23-000019:note_history:1]
As previously reported, during the fourth quarter of Fiscal 2023, the plaintiffs and the defendants entered into an agreement to settle the lawsuit. Under the terms of the settlement, the plaintiffs agreed to the dismissal of all claims upon payment of a total of $1.0 billion (the “settlement amount”), which includes all costs, expenses and fees of the plaintiff class relating to the action and its resolution. The settlement terms required that the settlement amount be paid by the Company and/or the Company’s insurers pursuant to indemnification obligations of the Company to the defendants. The Company is subject to indemnification obligations, upon the satisfaction of specified conditions, to the director and stockholder defendants and their affiliates pursuant to provisions of the Delaware General Corporation Law, the Company’s certificate of incorporation and bylaws, and agreements with the defendants. A special committee of the Board consisting of directors who were not defendants in the action, advised by independent counsel, informed the Board of its determination that the defendants are entitled to indemnification under the foregoing obligations.

- changed (2023-09-12):
[0001571996-23-000032:note_history:2]
During Fiscal 2023, the Company established a $1.0 billion liability on the Consolidated Statements of Financial Position and recognized $0.9 billion expense, net of $106 million in insurance proceeds, within interest and other, net within the Consolidated Statements of Income related to the settlement agreement.  The Company accounted for the expected insurance proceeds as a loss recovery and recognized a benefit within interest and other, net within the Condensed Consolidated Statements of Income and corresponding receivable on the Condensed Consolidated Statements of Financial Position.
  (was, 2023-06-12, similarity 0.8131):
[0001571996-23-000019:note_history:2]
During Fiscal 2023, the Company established a $1.0 billion liability on the Consolidated Statements of Financial Position and recognized $0.9 billion expense, net of $106 million in insurance proceeds, within interest and other, net within the Consolidated Statements of Income related to the settlement agreement.  The Company accounted for the expected insurance proceeds as a loss recovery and recognized a benefit within interest and other, net within the Condensed Consolidated Statements of Income and corresponding receivable on the Condensed Consolidated Statements of Financial Position.  On May 16, 2023, subsequent to the close of the three months ended May 5, 2023, the Company paid the settlement amount following approval of the settlement by the Delaware Court of Chancery.  The Company does not expect to incur additional expenses with respect to the settlement.

- added (2023-09-12):
[0001571996-23-000032:note_history:3]
On May 16, 2023, the Company paid the settlement amount following approval of the settlement by the Delaware Court of Chancery.  The payment is reflected within cash flows from operating activities within the Condensed Consolidated Statements of Cash Flows.  The Company does not expect to incur additional expenses with respect to the settlement.

- added (2023-09-12):
[0001571996-23-000032:note_history:4]
In accordance with the relevant accounting guidance, the Company provides disclosures of matters where it is at least reasonably possible that the Company could experience a material loss exceeding the amounts already accrued for these or other proceedings or matters.  In addition, the Company also discloses matters based on its consideration of other matters and qualitative factors, including the experience of other companies in the industry, and investor, customer, and employee relations considerations.  As of August 4, 2023, the Company does not believe there is a reasonable possibility that a material loss exceeding the amounts already accrued for these or other proceedings or matters has been incurred.  However, since the ultimate resolution of any such proceedings and matters is inherently unpredictable, the Company’s business, financial condition, results of operations, or cash flows could be materially affected in any particular period by unfavorable outcomes in one or more of these proceedings or matters.  Whether the outcome of any claim, suit, assessment, investigation, or legal proceeding, individually or collectively, could have a material adverse effect on the Company’s business, financial condition, results of operations, or cash flows will depend on a number of factors, including the nature, timing, and amount of any associated expenses, amounts paid in settlement, damages, or other remedies or consequences.

- changed (2023-09-12):
[0001571996-23-000032:note_history:5]
Under the Separation and Distribution Agreement entered into with VMware, Inc. upon the completion of the spin-off of VMware, Inc. by means of a special stock dividend (the “VMware Spin-off”) on November 1, 2021, Dell Technologies has agreed to indemnify VMware, Inc., each of its subsidiaries and each of their respective directors, officers, and employees from and against all liabilities relating to, arising out of or resulting from, among other matters, the liabilities allocated to Dell Technologies as part of the separation of Dell Technologies and VMware, Inc. (individually and together with its subsidiaries, “VMware”) and their respective businesses (the “Separation”). VMware similarly has agreed to indemnify Dell Technologies Inc., each of its subsidiaries and each of their respective directors, officers, and employees from and against all liabilities relating to, arising out of or resulting from, among other matters, the liabilities allocated to VMware as part of the Separation.  Dell Technologies expects VMware to fully perform under the terms of the Separation and Distribution Agreement.
  (was, 2023-06-12, similarity 0.9923):
[0001571996-23-000019:note_history:5]
Under the Separation and Distribution Agreement entered into with VMware, Inc. upon the completion of the spin-off of VMware, Inc. by means of a special stock dividend (the “VMware Spin-off”), Dell Technologies has agreed to indemnify VMware, Inc., each of its subsidiaries and each of their respective directors, officers, and employees from and against all liabilities relating to, arising out of or resulting from, among other matters, the liabilities allocated to Dell Technologies as part of the separation of Dell Technologies and VMware, Inc. (individually and together with its subsidiaries, “VMware”) and their respective businesses (the “Separation”). VMware similarly has agreed to indemnify Dell Technologies Inc., each of its subsidiaries and each of their respective directors, officers, and employees from and against all liabilities relating to, arising out of or resulting from, among other matters, the liabilities allocated to VMware as part of the Separation.  Dell Technologies expects VMware to fully perform under the terms of the Separation and Distribution Agreement.

- removed (2023-09-12):
[0001571996-23-000019:note_history:6]
In accordance with the relevant accounting guidance, the Company provides disclosures of matters where it is at least reasonably possible that the Company could experience a material loss exceeding the amounts already accrued for these or other proceedings or matters.  In addition, the Company also discloses matters based on its consideration of other matters and qualitative factors, including the experience of other companies in the industry, and investor, customer, and employee relations considerations.  As of May 5, 2023, the Company does not believe there is a reasonable possibility that a material loss exceeding the amounts already accrued for these or other proceedings or matters has been incurred.  However, since the ultimate resolution of any such proceedings and matters is inherently unpredictable, the Company’s business, financial condition, results of operations, or cash flows could be materially affected in any particular period by unfavorable outcomes in one or more of these proceedings or matters.  Whether the outcome of any claim, suit, assessment, investigation, or legal proceeding, individually or collectively, could have a material adverse effect on the Company’s business, financial condition, results of operations, or cash flows will depend on a number of factors, including the nature, timing, and amount of any associated expenses, amounts paid in settlement, damages, or other remedies or consequences.


## dell:CreditLossFinancialInstrumentLeasesDebtVariableInterestEntitiesAndCustomerReceivablesSalesTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-09-12):
[0001571996-23-000032:note_history:7]
Financing options are offered to our customers primarily through Dell Financial Services and its affiliates (“DFS”).  The Company also arranges financing for some of its customers in various countries where DFS does not currently operate as a captive enterprise.  The key activities of DFS include originating, collecting, and servicing customer financing arrangements primarily related to the purchase or use of Dell Technologies products and services.  In some cases, DFS also offers financing for the purchase of third-party technology products that complement the Dell Technologies portfolio of products and services.  New financing originations were $2.4 billion and $2.3 billion for the three months ended August 4, 2023 and July 29, 2022, respectively, and $4.2 billion and $4.4 billion for the six months ended August 4, 2023 and July 29, 2022, respectively.
  (was, 2023-06-12, similarity 0.9294):
[0001571996-23-000019:note_history:7]
Financing options are offered to our customers primarily through Dell Financial Services and its affiliates (“DFS”).  The Company also arranges financing for some of its customers in various countries where DFS does not currently operate as a captive enterprise.  The key activities of DFS include originating, collecting, and servicing customer financing arrangements primarily related to the purchase or use of Dell Technologies products and services.  In some cases, DFS also offers financing for the purchase of third-party technology products that complement the Dell Technologies portfolio of products and services.  New financing originations were $1.8 billion and $2.1 billion for the three months ended May 5, 2023 and April 29, 2022, respectively.

- added (2023-09-12):
[0001571996-23-000032:note_history:8]
As described in Note 1 to the Notes to the Condensed Consolidated Financial Statements, on July 12, 2023, the Company entered into a definitive agreement with Comenity Capital Bank, a subsidiary of Bread Financial Holdings, Inc., to establish a new U.S. DPA program under which transactions will be originated, owned, serviced, and collected by Bread. Under the definitive agreement, the Company will also sell its U.S. consumer revolving customer receivables portfolio. Upon the completion of the sale, such receivables will be serviced by Bread and the Company will have no continuing involvement.  The transaction is expected to close in the third quarter of Fiscal 2024, subject to customary closing conditions.

- added (2023-09-12):
[0001571996-23-000032:note_history:9]
In accordance with applicable accounting guidance, the Company concluded that the U.S. consumer revolving customer financing receivables have met the criteria to be classified as held for sale as of August 4, 2023. Accordingly, the Company reclassified $389 million, net of allowance, to current assets held for sale on the Condensed Consolidated Statements of Financial Position as of August 4, 2023.

- changed (2023-09-12):
[0001571996-23-000032:note_history:10]
|  | August 4, 2023 |  | February 3, 2023 |
|  | Revolving |  | Fixed-term |  | Total |  | Revolving |  | Fixed-term |  | Total |
|  | (in millions) |
| Financing receivables, net: |  |  |  |  |  |  |  |  |  |  |  |
| Customer receivables, gross (a) (b) | $ | 180 |  |  | $ | 10,439 |  |  | $ | 10,619 |  |  | $ | 685 |  |  | $ | 10,293 |  |  | $ | 10,978 |  |
| Allowances for losses | (9) |  |  | (140) |  |  | (149) |  |  | (88) |  |  | (113) |  |  | (201) |  |
| Customer receivables, net | 171 |  |  | 10,299 |  |  | 10,470 |  |  | 597 |  |  | 10,180 |  |  | 10,777 |  |
| Residual interest | — |  |  | 150 |  |  | 150 |  |  | — |  |  | 142 |  |  | 142 |  |
| Financing receivables, net | $ | 171 |  |  | $ | 10,449 |  |  | $ | 10,620 |  |  | $ | 597 |  |  | $ | 10,322 |  |  | $ | 10,919 |  |
| Short-term | $ | 171 |  |  | $ | 4,636 |  |  | $ | 4,807 |  |  | $ | 597 |  |  | $ | 4,684 |  |  | $ | 5,281 |  |
| Long-term | $ | — |  |  | $ | 5,813 |  |  | $ | 5,813 |  |  | $ | — |  |  | $ | 5,638 |  |  | $ | 5,638 |  |
  (was, 2023-06-12, similarity 0.9918):
[0001571996-23-000019:note_history:10]
|  | May 5, 2023 |  | February 3, 2023 |
|  | Revolving |  | Fixed-term |  | Total |  | Revolving |  | Fixed-term |  | Total |
|  | (in millions) |
| Financing receivables, net: |  |  |  |  |  |  |  |  |  |  |  |
| Customer receivables, gross (a) | $ | 658 |  |  | $ | 9,951 |  |  | $ | 10,609 |  |  | $ | 685 |  |  | $ | 10,293 |  |  | $ | 10,978 |  |
| Allowances for losses | (84) |  |  | (135) |  |  | (219) |  |  | (88) |  |  | (113) |  |  | (201) |  |
| Customer receivables, net | 574 |  |  | 9,816 |  |  | 10,390 |  |  | 597 |  |  | 10,180 |  |  | 10,777 |  |
| Residual interest | — |  |  | 147 |  |  | 147 |  |  | — |  |  | 142 |  |  | 142 |  |
| Financing receivables, net | $ | 574 |  |  | $ | 9,963 |  |  | $ | 10,537 |  |  | $ | 597 |  |  | $ | 10,322 |  |  | $ | 10,919 |  |
| Short-term | $ | 574 |  |  | $ | 4,439 |  |  | $ | 5,013 |  |  | $ | 597 |  |  | $ | 4,684 |  |  | $ | 5,281 |  |
| Long-term | $ | — |  |  | $ | 5,524 |  |  | $ | 5,524 |  |  | $ | — |  |  | $ | 5,638 |  |  | $ | 5,638 |  |

- added (2023-09-12):
[0001571996-23-000032:note_history:11]
(b)    The decrease in revolving customer financing receivables is attributable to the reclassification of the U.S. consumer revolving portfolio to current assets held for sale, as described above.

- added (2023-09-12):
[0001571996-23-000032:note_history:12]
|  | Three Months Ended |
|  | August 4, 2023 |  | July 29, 2022 |
|  | Revolving |  | Fixed-term |  | Total |  | Revolving |  | Fixed-term |  | Total |
|  | (in millions) |
| Allowance for financing receivable losses: |  |  |  |  |  |  |  |  |  |  |  |
| Balances at beginning of period | $ | 84 |  |  | $ | 135 |  |  | $ | 219 |  |  | $ | 94 |  |  | $ | 87 |  |  | $ | 181 |  |
| Charge-offs, net of recoveries | (16) |  |  | (1) |  |  | (17) |  |  | (12) |  |  | (2) |  |  | (14) |  |
| Provision charged to income statement | 15 |  |  | 6 |  |  | 21 |  |  | 9 |  |  | 7 |  |  | 16 |  |
| Held for sale adjustment | (74) |  |  | — |  |  | (74) |  |  | — |  |  | — |  |  | — |  |
| Balances at end of period | $ | 9 |  |  | $ | 140 |  |  | $ | 149 |  |  | $ | 91 |  |  | $ | 92 |  |  | $ | 183 |  |

- added (2023-09-12):
[0001571996-23-000032:note_history:13]
|  | Six Months Ended |
|  | August 4, 2023 |  | July 29, 2022 |
|  | Revolving |  | Fixed-term |  | Total |  | Revolving |  | Fixed-term |  | Total |
|  | (in millions) |
| Allowance for financing receivable losses: |  |  |  |  |  |  |  |  |  |  |  |
| Balances at beginning of period | $ | 88 |  |  | $ | 113 |  |  | $ | 201 |  |  | $ | 102 |  |  | $ | 87 |  |  | $ | 189 |  |
| Charge-offs, net of recoveries | (33) |  |  | (2) |  |  | (35) |  |  | (25) |  |  | (4) |  |  | (29) |  |
| Provision charged to income statement | 28 |  |  | 29 |  |  | 57 |  |  | 14 |  |  | 9 |  |  | 23 |  |
| Held for sale adjustment | (74) |  |  | — |  |  | (74) |  |  | — |  |  | — |  |  | — |  |
| Balances at end of period | $ | 9 |  |  | $ | 140 |  |  | $ | 149 |  |  | $ | 91 |  |  | $ | 92 |  |  | $ | 183 |  |

- changed (2023-09-12):
[0001571996-23-000032:note_history:14]
|  | August 4, 2023 |  | February 3, 2023 |
|  | Current |  | Past Due1 — 90 Days |  | Past Due>90 Days |  | Total |  | Current |  | Past Due1 — 90 Days |  | Past Due>90 Days |  | Total |
|  | (in millions) |
| Revolving — DPA | $ | 7 |  |  | $ | — |  |  | $ | — |  |  | $ | 7 |  |  | $ | 457 |  |  | $ | 34 |  |  | $ | 17 |  |  | $ | 508 |  |
| Revolving — DBC | 151 |  |  | 18 |  |  | 4 |  |  | 173 |  |  | 154 |  |  | 19 |  |  | 4 |  |  | 177 |  |
| Fixed-term — Consumer and Commercial | 9,412 |  |  | 969 |  |  | 58 |  |  | 10,439 |  |  | 9,309 |  |  | 927 |  |  | 57 |  |  | 10,293 |  |
| Total customer receivables, gross | $ | 9,570 |  |  | $ | 987 |  |  | $ | 62 |  |  | $ | 10,619 |  |  | $ | 9,920 |  |  | $ | 980 |  |  | $ | 78 |  |  | $ | 10,978 |  |
  (was, 2023-06-12, similarity 0.6314):
[0001571996-23-000019:note_history:14]
|  | May 5, 2023 |  | February 3, 2023 |
|  | Current |  | Past Due1 — 90 Days |  | Past Due>90 Days |  | Total |  | Current |  | Past Due1 — 90 Days |  | Past Due>90 Days |  | Total |
|  | (in millions) |
| Revolving — DPA | $ | 433 |  |  | $ | 33 |  |  | $ | 16 |  |  | $ | 482 |  |  | $ | 457 |  |  | $ | 34 |  |  | $ | 17 |  |  | $ | 508 |  |
| Revolving — DBC | 153 |  |  | 19 |  |  | 4 |  |  | 176 |  |  | 154 |  |  | 19 |  |  | 4 |  |  | 177 |  |
| Fixed-term — Consumer and Commercial | 9,128 |  |  | 743 |  |  | 80 |  |  | 9,951 |  |  | 9,309 |  |  | 927 |  |  | 57 |  |  | 10,293 |  |
| Total customer receivables, gross | $ | 9,714 |  |  | $ | 795 |  |  | $ | 100 |  |  | $ | 10,609 |  |  | $ | 9,920 |  |  | $ | 980 |  |  | $ | 78 |  |  | $ | 10,978 |  |

- changed (2023-09-12):
[0001571996-23-000032:note_history:15]
|  | August 4, 2023 |
|  | Fixed-term — Consumer and Commercial |  |  |  |  |  |  |
|  | Fiscal Year of Origination |  |  |  |  |  |  |
|  | 2024 |  | 2023 |  | 2022 |  | 2021 |  | 2020 |  | Years Prior |  | Revolving — DPA |  | Revolving — DBC |  | Total |
|  | (in millions) |
| Higher | $ | 1,997 |  |  | $ | 2,453 |  |  | $ | 1,267 |  |  | $ | 617 |  |  | $ | 206 |  |  | $ | 10 |  |  | $ | 1 |  |  | $ | 45 |  |  | $ | 6,596 |  |
| Mid | 611 |  |  | 1,205 |  |  | 480 |  |  | 214 |  |  | 63 |  |  | 5 |  |  | 3 |  |  | 50 |  |  | 2,631 |  |
| Lower | 288 |  |  | 615 |  |  | 266 |  |  | 99 |  |  | 40 |  |  | 3 |  |  | 3 |  |  | 78 |  |  | 1,392 |  |
| Total | $ | 2,896 |  |  | $ | 4,273 |  |  | $ | 2,013 |  |  | $ | 930 |  |  | $ | 309 |  |  | $ | 18 |  |  | $ | 7 |  |  | $ | 173 |  |  | $ | 10,619 |  |
  (was, 2023-06-12, similarity 0.9928):
[0001571996-23-000019:note_history:15]
|  | May 5, 2023 |
|  | Fixed-term — Consumer and Commercial |  |  |  |  |  |  |
|  | Fiscal Year of Origination |  |  |  |  |  |  |
|  | 2024 |  | 2023 |  | 2022 |  | 2021 |  | 2020 |  | Years Prior |  | Revolving — DPA |  | Revolving — DBC |  | Total |
|  | (in millions) |
| Higher | $ | 931 |  |  | $ | 2,640 |  |  | $ | 1,484 |  |  | $ | 716 |  |  | $ | 259 |  |  | $ | 18 |  |  | $ | 113 |  |  | $ | 43 |  |  | $ | 6,204 |  |
| Mid | 410 |  |  | 1,274 |  |  | 536 |  |  | 270 |  |  | 84 |  |  | 9 |  |  | 130 |  |  | 53 |  |  | 2,766 |  |
| Lower | 198 |  |  | 660 |  |  | 296 |  |  | 117 |  |  | 42 |  |  | 7 |  |  | 239 |  |  | 80 |  |  | 1,639 |  |
| Total | $ | 1,539 |  |  | $ | 4,574 |  |  | $ | 2,316 |  |  | $ | 1,103 |  |  | $ | 385 |  |  | $ | 34 |  |  | $ | 482 |  |  | $ | 176 |  |  | $ | 10,609 |  |

- changed (2023-09-12):
[0001571996-23-000032:note_history:16]
For DPA revolving receivables, the Company makes credit decisions based on proprietary scorecards, which include the customer’s credit history, payment history, credit usage, and other credit agency-related elements.  The higher quality category includes prime accounts generally comparable to U.S. customer FICO scores of 720 or above.  The mid category represents the mid-tier accounts that are comparable to U.S. customer FICO scores from 660 to 719.  The lower category is generally sub-prime and represents accounts that are comparable to U.S. customer FICO scores below 660.  For the DBC revolving receivables and fixed-term commercial receivables shown in the table above, an internal grading system is utilized that assigns a credit level score based on a number of considerations, including liquidity, operating performance, and industry outlook.  The grading criteria and classifications for the fixed-term products differ from those for the revolving products as loss experience varies between these product and customer groups.  The credit quality categories cannot be compared between the different classes as loss experience varies substantially between the classes.
  (was, 2023-06-12, similarity 0.9894):
[0001571996-23-000019:note_history:16]
For DPA revolving receivables shown in the table above, the Company makes credit decisions based on proprietary scorecards, which include the customer’s credit history, payment history, credit usage, and other credit agency-related elements.  The higher quality category includes prime accounts generally comparable to U.S. customer FICO scores of 720 or above.  The mid category represents the mid-tier accounts that are comparable to U.S. customer FICO scores from 660 to 719.  The lower category is generally sub-prime and represents accounts that are comparable to U.S. customer FICO scores below 660.  For the DBC revolving receivables and fixed-term commercial receivables shown in the table above, an internal grading system is utilized that assigns a credit level score based on a number of considerations, including liquidity, operating performance, and industry outlook.  The grading criteria and classifications for the fixed-term products differ from those for the revolving products as loss experience varies between these product and customer groups.  The credit quality categories cannot be compared between the different classes as loss experience varies substantially between the classes.

- changed (2023-09-12):
[0001571996-23-000032:note_history:17]
The following table presents net revenue, cost of net revenue, and gross margin recognized at the commencement date of sales-type leases for the periods indicated:
  (was, 2023-06-12, similarity 0.9879):
[0001571996-23-000019:note_history:17]
The following table presents the net revenue, cost of net revenue, and gross margin recognized at the commencement date of sales-type leases for the periods indicated:

- changed (2023-09-12):
[0001571996-23-000032:note_history:18]
|  | Three Months Ended |  | Six Months Ended |
|  | August 4, 2023 |  | July 29, 2022 |  | August 4, 2023 |  | July 29, 2022 |
|  | (in millions) |
| Net revenue — products | $ | 292 |  |  | $ | 219 |  |  | $ | 539 |  |  | $ | 439 |  |
| Cost of net revenue — products | 192 |  |  | 164 |  |  | 388 |  |  | 368 |  |
| Gross margin — products | $ | 100 |  |  | $ | 55 |  |  | $ | 151 |  |  | $ | 71 |  |
  (was, 2023-06-12, similarity 0.6411):
[0001571996-23-000019:note_history:18]
|  |  |  | Three Months Ended |
|  |  |  |  |  | May 5, 2023 |  | April 29, 2022 |
|  |  |  |  |  | (in millions) |
| Net revenue — products |  |  |  |  | $ | 247 |  |  | $ | 220 |  |
| Cost of net revenue — products |  |  |  |  | 196 |  |  | 204 |  |
| Gross margin — products |  |  |  |  | $ | 51 |  |  | $ | 16 |  |

- changed (2023-09-12):
[0001571996-23-000032:note_history:19]
|  | August 4, 2023 |
|  | (in millions) |
| Fiscal 2024 (remaining six months) | $ | 1,445 |  |
| Fiscal 2025 | 2,063 |  |
| Fiscal 2026 | 1,540 |  |
| Fiscal 2027 | 822 |  |
| Fiscal 2028 and beyond | 297 |  |
| Total undiscounted cash flows | 6,167 |  |
| Fixed-term loans | 5,163 |  |
| Revolving loans | 180 |  |
| Less: Unearned income | (891) |  |
| Total customer receivables, gross | $ | 10,619 |  |
  (was, 2023-06-12, similarity 0.6855):
[0001571996-23-000019:note_history:19]
|  | May 5, 2023 |
|  | (in millions) |
| Fiscal 2024 (remaining nine months) | $ | 862 |  |
| Fiscal 2025 | 824 |  |
| Fiscal 2026 | 460 |  |
| Fiscal 2027 | 141 |  |
| Fiscal 2028 and beyond | 46 |  |
| Total | $ | 2,333 |  |

- changed (2023-09-12):
[0001571996-23-000032:note_history:20]
|  | August 4, 2023 |  | February 3, 2023 |
|  | (in millions) |
| Equipment under operating lease, gross | $ | 3,833 |  |  | $ | 3,725 |  |
| Less: Accumulated depreciation | (1,687) |  |  | (1,517) |  |
| Equipment under operating lease, net | $ | 2,146 |  |  | $ | 2,208 |  |
  (was, 2023-06-12, similarity 0.9806):
[0001571996-23-000019:note_history:20]
|  | May 5, 2023 |  | February 3, 2023 |
|  | (in millions) |
| Equipment under operating lease, gross | $ | 3,817 |  |  | $ | 3,725 |  |
| Less: Accumulated depreciation | (1,634) |  |  | (1,517) |  |
| Equipment under operating lease, net | $ | 2,183 |  |  | $ | 2,208 |  |

- added (2023-09-12):
[0001571996-23-000032:note_history:21]
|  | Three Months Ended |  | Six Months Ended |
|  | August 4, 2023 |  | July 29, 2022 |  | August 4, 2023 |  | July 29, 2022 |
|  | (in millions) |
| Income related to lease payments | $ | 330 |  |  | $ | 253 |  |  | $ | 651 |  |  | $ | 485 |  |
| Depreciation expense | $ | 236 |  |  | $ | 194 |  |  | $ | 469 |  |  | $ | 359 |  |

- added (2023-09-12):
[0001571996-23-000032:note_history:22]
|  | August 4, 2023 |
|  | (in millions) |
| Fiscal 2024 (remaining six months) | $ | 623 |  |
| Fiscal 2025 | 918 |  |
| Fiscal 2026 | 544 |  |
| Fiscal 2027 | 192 |  |
| Fiscal 2028 and beyond | 71 |  |
| Total | $ | 2,348 |  |

- changed (2023-09-12):
[0001571996-23-000032:note_history:23]
|  | August 4, 2023 |  | February 3, 2023 |
| DFS debt | (in millions) |
| DFS U.S. debt: |  |  |  |
| Asset-based financing and securitization facilities | $ | 3,067 |  |  | $ | 3,987 |  |
| Fixed-term securitization offerings | 3,471 |  |  | 2,679 |  |
| Other | 58 |  |  | 76 |  |
| Total DFS U.S. debt | 6,596 |  |  | 6,742 |  |
| DFS international debt: |  |  |  |
| Securitization facility | 793 |  |  | 790 |  |
| Other borrowings | 762 |  |  | 871 |  |
| Note payable | 250 |  |  | 250 |  |
| Dell Bank senior unsecured eurobonds | 1,642 |  |  | 1,637 |  |
| Total DFS international debt | 3,447 |  |  | 3,548 |  |
| Total DFS debt | $ | 10,043 |  |  | $ | 10,290 |  |
| Total short-term DFS debt | $ | 5,801 |  |  | $ | 5,400 |  |
| Total long-term DFS debt | $ | 4,242 |  |  | $ | 4,890 |  |
  (was, 2023-06-12, similarity 0.9933):
[0001571996-23-000019:note_history:23]
|  | May 5, 2023 |  | February 3, 2023 |
| DFS debt | (in millions) |
| DFS U.S. debt: |  |  |  |
| Asset-based financing and securitization facilities | $ | 3,326 |  |  | $ | 3,987 |  |
| Fixed-term securitization offerings | 3,192 |  |  | 2,679 |  |
| Other | 67 |  |  | 76 |  |
| Total DFS U.S. debt | 6,585 |  |  | 6,742 |  |
| DFS international debt: |  |  |  |
| Securitization facility | 818 |  |  | 790 |  |
| Other borrowings | 852 |  |  | 871 |  |
| Note payable | 250 |  |  | 250 |  |
| Dell Bank senior unsecured eurobonds | 1,652 |  |  | 1,637 |  |
| Total DFS international debt | 3,572 |  |  | 3,548 |  |
| Total DFS debt | $ | 10,157 |  |  | $ | 10,290 |  |
| Total short-term DFS debt | $ | 5,232 |  |  | $ | 5,400 |  |
| Total long-term DFS debt | $ | 4,925 |  |  | $ | 4,890 |  |

- changed (2023-09-12):
[0001571996-23-000032:note_history:24]
Asset-Based Financing and Securitization Facilities — The Company maintains separate asset-based financing facilities and a securitization facility in the United States, which are revolving facilities for fixed-term leases and loans and for revolving loans, respectively.  This debt is collateralized solely by the U.S. loan and lease payments and associated equipment in the facilities.  The debt has a variable interest rate and the duration of the debt is based on the terms of the underlying loan and lease payment streams.  As of August 4, 2023, the total debt capacity related to the U.S. asset-based financing and securitization facilities was $5.6 billion.  The Company enters into interest swap agreements to effectively convert a portion of this debt from a floating rate to a fixed rate.  See Note 7 of the Notes to the Condensed Consolidated Financial Statements for additional information about interest rate swaps.
  (was, 2023-06-12, similarity 0.9951):
[0001571996-23-000019:note_history:24]
Asset-Based Financing and Securitization Facilities — The Company maintains separate asset-based financing facilities and a securitization facility in the United States, which are revolving facilities for fixed-term leases and loans and for revolving loans, respectively.  This debt is collateralized solely by the U.S. loan and lease payments and associated equipment in the facilities.  The debt has a variable interest rate and the duration of the debt is based on the terms of the underlying loan and lease payment streams.  As of May 5, 2023, the total debt capacity related to the U.S. asset-based financing and securitization facilities was $5.6 billion.  The Company enters into interest swap agreements to effectively convert a portion of this debt from a floating rate to a fixed rate.  See Note 7 of the Notes to the Condensed Consolidated Financial Statements for additional information about interest rate swaps.

- added (2023-09-12):
[0001571996-23-000032:note_history:25]
The Company’s two U.S. asset-based financing facilities for fixed-term leases and loans are effective through July 7, 2025 and June 21, 2024, respectively.  The Company’s U.S. securitization facility for revolving loans is effective through June 25, 2025.  The Company intends to pay down the U.S. securitization facility for revolving loans prior to the close of the U.S. consumer revolving customer receivables portfolio sale described above.

- changed (2023-09-12):
[0001571996-23-000032:note_history:26]
The asset-based financing and securitization facilities contain standard structural features related to the performance of the funded receivables, which include defined credit losses, delinquencies, average credit scores, and minimum collection requirements.  In the event one or more of these criteria are not met and the Company is unable to restructure the facility, no further funding of receivables will be permitted and the timing of the Company’s expected cash flows from over-collateralization will be delayed.  As of August 4, 2023, these criteria were met.
  (was, 2023-06-12, similarity 0.9919):
[0001571996-23-000019:note_history:26]
The asset-based financing and securitization facilities contain standard structural features related to the performance of the funded receivables, which include defined credit losses, delinquencies, average credit scores, and minimum collection requirements.  In the event one or more of these criteria are not met and the Company is unable to restructure the facility, no further funding of receivables will be permitted and the timing of the Company’s expected cash flows from over-collateralization will be delayed.  As of May 5, 2023, these criteria were met.

- changed (2023-09-12):
[0001571996-23-000032:note_history:27]
Fixed-Term Securitization Offerings — The Company periodically issues asset-backed debt securities under fixed-term securitization programs to private investors.  The asset-backed debt securities are collateralized solely by the U.S. fixed-term lease and loan payments and associated equipment, which are held by Special Purpose Entities (“SPEs”), as discussed below.  The interest rate on these securities is fixed and ranges from 0.43% to 6.80% per annum as of August 4, 2023, and the duration of these securities is based on the terms of the underlying lease and loan payment streams.
  (was, 2023-06-12, similarity 0.8498):
[0001571996-23-000019:note_history:27]
Fixed-Term Securitization Offerings — The Company periodically issues asset-backed debt securities under fixed-term securitization programs to private investors.  The asset-backed debt securities are collateralized solely by the U.S. fixed-term lease and loan payments and associated equipment, which are held by Special Purpose Entities (“SPEs”), as discussed below.  The interest rate on these securities is fixed and ranges from 0.33% to 6.80% per annum, and the duration of these securities is based on the terms of the underlying lease and loan payment streams.

- changed (2023-09-12):
[0001571996-23-000032:note_history:28]
Securitization Facility — The Company maintains a securitization facility in Europe for fixed-term leases and loans.  The debt under this facility has a variable interest rate, and the duration of the debt is based on the terms of the underlying loan and lease payment streams.  This facility is effective through December 23, 2024 and had a total debt capacity of $876 million as of August 4, 2023.
  (was, 2023-06-12, similarity 0.9778):
[0001571996-23-000019:note_history:28]
Securitization Facility — The Company maintains a securitization facility in Europe for fixed-term leases and loans. The debt under this facility has a variable interest rate, and the duration of the debt is based on the terms of the underlying loan and lease payment streams.  This facility is effective through December 23, 2024 and had a total debt capacity of $881 million as of May 5, 2023.

- changed (2023-09-12):
[0001571996-23-000032:note_history:29]
The securitization facility contains standard structural features related to the performance of the securitized receivables, which include defined credit losses, delinquencies, average credit scores, and minimum collection requirements.  In the event one or more of these criteria are not met and the Company is unable to restructure the program, no further funding of receivables will be permitted and the timing of the Company’s expected cash flows from over-collateralization will be delayed.  As of August 4, 2023, these criteria were met.
  (was, 2023-06-12, similarity 0.9916):
[0001571996-23-000019:note_history:29]
The securitization facility contains standard structural features related to the performance of the securitized receivables, which include defined credit losses, delinquencies, average credit scores, and minimum collection requirements.  In the event one or more of these criteria are not met and the Company is unable to restructure the program, no further funding of receivables will be permitted and the timing of the Company’s expected cash flows from over-collateralization will be delayed.  As of May 5, 2023, these criteria were met.

- added (2023-09-12):
[0001571996-23-000032:note_history:30]
Other Borrowings — In connection with the Company’s international financing operations, the Company has entered into revolving structured financing debt programs related to its fixed-term lease and loan products sold in Canada, Europe, Australia, New Zealand, and the Middle East.  The debt under these programs has a variable interest rate, and the duration of the debt is based on the terms of the underlying loan and lease payment streams.  The Canadian facility, which is collateralized solely by Canadian loan and lease payments and associated equipment, had a total debt capacity of $337 million as of August 4, 2023 and is effective through January 16, 2025.  The European facility, which is collateralized solely by European loan and lease payments and associated equipment, had a total debt capacity of $657 million as of August 4, 2023 and is effective through June 14, 2025.  The Australia and New Zealand facility, which is collateralized solely by Australia and New Zealand loan and lease payments and associated equipment, had a total debt capacity of $295 million as of August 4, 2023 and is effective through April 20, 2025. The Middle East facility, which is collateralized solely by Middle East loan and lease payments and associated equipment, had a total debt capacity of $150 million as of August 4, 2023 and is effective through March 24, 2025.

- changed (2023-09-12):
[0001571996-23-000032:note_history:31]
Note Payable — On May 25, 2022, the Company entered into an unsecured credit agreement to fund receivables in Mexico.  As of August 4, 2023, the aggregate principal amount of the note payable was $250 million.  The note bears interest at an annual rate of 4.24% and will mature on May 31, 2024.
  (was, 2023-06-12, similarity 0.9832):
[0001571996-23-000019:note_history:31]
Note Payable — On May 25, 2022, the Company entered into an unsecured credit agreement to fund receivables in Mexico.  As of May 5, 2023, the aggregate principal amount of the note payable was $250 million.  The note bears interest at an annual rate of 4.24% and will mature on May 31, 2024.

- changed (2023-09-12):
[0001571996-23-000032:note_history:32]
|  | August 4, 2023 |  | February 3, 2023 |
|  | (in millions) |
| Assets held by consolidated VIEs |  |  |  |
| Other current assets | $ | 282 |  |  | $ | 274 |  |
| Current assets held for sale | $ | 366 |  |  | $ | — |  |
| Financing receivables, net of allowance |  |  |  |
| Short-term | $ | 3,256 |  |  | $ | 3,702 |  |
| Long-term | $ | 3,298 |  |  | $ | 3,295 |  |
| Property, plant, and equipment, net | $ | 1,142 |  |  | $ | 1,164 |  |
| Liabilities held by consolidated VIEs |  |  |  |
| Debt, net of unamortized debt issuance costs |  |  |  |
| Short-term | $ | 4,556 |  |  | $ | 4,761 |  |
| Long-term | $ | 2,760 |  |  | $ | 2,685 |  |
  (was, 2023-06-12, similarity 0.7):
[0001571996-23-000019:note_history:32]
|  | May 5, 2023 |  | February 3, 2023 |
|  | (in millions) |
| Assets held by consolidated VIEs |  |  |  |
| Other current assets | $ | 291 |  |  | $ | 274 |  |
| Financing receivables, net of allowance |  |  |  |
| Short-term | $ | 3,620 |  |  | $ | 3,702 |  |
| Long-term | $ | 3,361 |  |  | $ | 3,295 |  |
| Property, plant, and equipment, net | $ | 1,423 |  |  | $ | 1,164 |  |
| Liabilities held by consolidated VIEs |  |  |  |
| Debt, net of unamortized debt issuance costs |  |  |  |
| Short-term | $ | 4,277 |  |  | $ | 4,761 |  |
| Long-term | $ | 1,980 |  |  | $ | 2,685 |  |

- changed (2023-09-12):
[0001571996-23-000032:note_history:33]
Lease and loan payments and associated equipment transferred via securitization through SPEs were $1.1 billion and $1.2 billion for the three months ended August 4, 2023 and July 29, 2022, respectively, and $2.6 billion and $2.9 billion for the six months ended August 4, 2023 and July 29, 2022, respectively.
  (was, 2023-06-12, similarity 0.7794):
[0001571996-23-000019:note_history:33]
Lease and loan payments and associated equipment transferred via securitization through SPEs were $1.5 billion and $1.7 billion for the three months ended May 5, 2023 and April 29, 2022, respectively.

- changed (2023-09-12):
[0001571996-23-000032:note_history:34]
To manage certain concentrations of customer credit exposure, the Company may sell selected fixed-term customer receivables to unrelated third parties on a periodic basis, without recourse.  The amount of customer receivables sold for this purpose was $187 million and $425 million for the six months ended August 4, 2023 and July 29, 2022, respectively.  The Company’s continuing involvement in these customer receivables is primarily limited to servicing arrangements.
  (was, 2023-06-12, similarity 0.6322):
[0001571996-23-000019:note_history:34]
To manage certain concentrations of customer credit exposure, the Company may sell selected fixed-term customer receivables to unrelated third parties on a periodic basis, without recourse.  The amount of customer receivables sold for this purpose was $169 million and $148 million for the three months ended May 5, 2023 and April 29, 2022, respectively.  The Company’s continuing involvement in these customer receivables is primarily limited to servicing arrangements.

- removed (2023-09-12):
[0001571996-23-000019:note_history:35]
|  | Three Months Ended |
|  | May 5, 2023 |  | April 29, 2022 |
|  | Revolving |  | Fixed-term |  | Total |  | Revolving |  | Fixed-term |  | Total |
|  | (in millions) |
| Allowance for financing receivable losses: |  |  |  |  |  |  |  |  |  |  |  |
| Balances at beginning of period | $ | 88 |  |  | $ | 113 |  |  | $ | 201 |  |  | $ | 102 |  |  | $ | 87 |  |  | $ | 189 |  |
| Charge-offs, net of recoveries | (17) |  |  | (1) |  |  | (18) |  |  | (13) |  |  | (2) |  |  | (15) |  |
| Provision charged to income statement | 13 |  |  | 23 |  |  | 36 |  |  | 5 |  |  | 2 |  |  | 7 |  |
| Balances at end of period | $ | 84 |  |  | $ | 135 |  |  | $ | 219 |  |  | $ | 94 |  |  | $ | 87 |  |  | $ | 181 |  |

- removed (2023-09-12):
[0001571996-23-000019:note_history:36]
|  | May 5, 2023 |
|  | (in millions) |
| Fiscal 2024 (remaining nine months) | $ | 1,997 |  |
| Fiscal 2025 | 1,894 |  |
| Fiscal 2026 | 1,361 |  |
| Fiscal 2027 | 659 |  |
| Fiscal 2028 and beyond | 178 |  |
| Total undiscounted cash flows | 6,089 |  |
| Fixed-term loans | 4,640 |  |
| Revolving loans | 658 |  |
| Less: Unearned income | (778) |  |
| Total customer receivables, gross | $ | 10,609 |  |

- removed (2023-09-12):
[0001571996-23-000019:note_history:37]
|  |  |  | Three Months Ended |
|  |  |  |  |  | May 5, 2023 |  | April 29, 2022 |
|  |  |  |  |  | (in millions) |
| Income related to lease payments |  |  |  |  | $ | 321 |  |  | $ | 232 |  |
| Depreciation expense |  |  |  |  | $ | 233 |  |  | $ | 165 |  |

- removed (2023-09-12):
[0001571996-23-000019:note_history:38]
The Company’s U.S. securitization facility for revolving loans is effective through June 25, 2025.  The Company’s two U.S. asset-based financing facilities for fixed-term leases and loans are effective through July 10, 2023 and June 21, 2024, respectively.  The Company intends to extend the facility currently effective through July 10, 2023 during the second quarter of Fiscal 2024.

- removed (2023-09-12):
[0001571996-23-000019:note_history:39]
Other Borrowings — In connection with the Company’s international financing operations, the Company has entered into revolving structured financing debt programs related to its fixed-term lease and loan products sold in Canada, Europe, Australia, and New Zealand.  The debt under these programs has a variable interest rate, and the duration of the debt is based on the terms of the underlying loan and lease payment streams.  The Canadian facility, which is collateralized solely by Canadian loan and lease payments and associated equipment, had a total debt capacity of $332 million as of May 5, 2023 and is effective through January 16, 2025.  The European facility, which is collateralized solely by European loan and lease payments and associated equipment, had a total debt capacity of $661 million as of May 5, 2023 and is effective through June 14, 2025.  The Australia and New Zealand facility, which is collateralized solely by Australia and New Zealand loan and lease payments and associated equipment, had a total debt capacity of $301 million as of May 5, 2023 and is effective through April 20, 2025. The Middle East facility, which is collateralized solely by Middle East loan and lease payments and associated equipment, had a total debt capacity of $150 million as of May 5, 2023 and is effective through March 24, 2025.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-09-12):
[0001571996-23-000032:note_history:40]
|  | August 4, 2023 |  | February 3, 2023 |
|  | (in millions) |
| Senior Notes: |  |  |  |
| 5.45% due June 2023 | $ | — |  |  | $ | 1,000 |  |
| 4.00% due July 2024 | 1,000 |  |  | 1,000 |  |
| 5.85% due July 2025 | 1,000 |  |  | 1,000 |  |
| 6.02% due June 2026 | 3,500 |  |  | 4,500 |  |
| 4.90% due October 2026 | 1,750 |  |  | 1,750 |  |
| 6.10% due July 2027 | 500 |  |  | 500 |  |
| 5.25% due February 2028 | 1,000 |  |  | 1,000 |  |
| 5.30% due October 2029 | 1,750 |  |  | 1,750 |  |
| 6.20% due July 2030 | 750 |  |  | 750 |  |
| 5.75% due February 2033 | 1,000 |  |  | 1,000 |  |
| 8.10% due July 2036 | 1,000 |  |  | 1,000 |  |
| 3.38% due December 2041 | 982 |  |  | 1,000 |  |
| 8.35% due July 2046 | 800 |  |  | 800 |  |
| 3.45% due December 2051 | 1,099 |  |  | 1,250 |  |
| Legacy Notes and Debentures: |  |  |  |
| 7.10% due April 2028 | 300 |  |  | 300 |  |
| 6.50% due April 2038 | 388 |  |  | 388 |  |
| 5.40% due September 2040 | 264 |  |  | 264 |  |
| DFS Debt (Note 4) | 10,043 |  |  | 10,290 |  |
| Other | 262 |  |  | 325 |  |
| Total debt, principal amount | $ | 27,388 |  |  | $ | 29,867 |  |
| Unamortized discount, net of unamortized premium | (119) |  |  | (133) |  |
| Debt issuance costs | (131) |  |  | (146) |  |
| Total debt, carrying value | $ | 27,138 |  |  | $ | 29,588 |  |
| Total short-term debt, carrying value | $ | 6,961 |  |  | $ | 6,573 |  |
| Total long-term debt, carrying value | $ | 20,177 |  |  | $ | 23,015 |  |
  (was, 2023-06-12, similarity 0.9959):
[0001571996-23-000019:note_history:40]
|  | May 5, 2023 |  | February 3, 2023 |
|  | (in millions) |
| Senior Notes: |  |  |  |
| 5.45% due June 2023 | $ | — |  |  | $ | 1,000 |  |
| 4.00% due July 2024 | 1,000 |  |  | 1,000 |  |
| 5.85% due July 2025 | 1,000 |  |  | 1,000 |  |
| 6.02% due June 2026 | 4,500 |  |  | 4,500 |  |
| 4.90% due October 2026 | 1,750 |  |  | 1,750 |  |
| 6.10% due July 2027 | 500 |  |  | 500 |  |
| 5.25% due February 2028 | 1,000 |  |  | 1,000 |  |
| 5.30% due October 2029 | 1,750 |  |  | 1,750 |  |
| 6.20% due July 2030 | 750 |  |  | 750 |  |
| 5.75% due February 2033 | 1,000 |  |  | 1,000 |  |
| 8.10% due July 2036 | 1,000 |  |  | 1,000 |  |
| 3.38% due December 2041 | 1,000 |  |  | 1,000 |  |
| 8.35% due July 2046 | 800 |  |  | 800 |  |
| 3.45% due December 2051 | 1,200 |  |  | 1,250 |  |
| Legacy Notes and Debentures: |  |  |  |
| 7.10% due April 2028 | 300 |  |  | 300 |  |
| 6.50% due April 2038 | 388 |  |  | 388 |  |
| 5.40% due September 2040 | 264 |  |  | 264 |  |
| DFS Debt (Note 4) | 10,157 |  |  | 10,290 |  |
| Other | 336 |  |  | 325 |  |
| Total debt, principal amount | $ | 28,695 |  |  | $ | 29,867 |  |
| Unamortized discount, net of unamortized premium | (121) |  |  | (133) |  |
| Debt issuance costs | (142) |  |  | (146) |  |
| Total debt, carrying value | $ | 28,432 |  |  | $ | 29,588 |  |
| Total short-term debt, carrying value | $ | 5,470 |  |  | $ | 6,573 |  |
| Total long-term debt, carrying value | $ | 22,962 |  |  | $ | 23,015 |  |

- changed (2023-09-12):
[0001571996-23-000032:note_history:41]
During the six months ended August 4, 2023, the net decrease in the Company’s debt balance was principally attributable to:
  (was, 2023-06-12, similarity 0.6379):
[0001571996-23-000019:note_history:41]
During the three months ended May 5, 2023, the net decrease in the Company’s debt balance primarily reflected the repayment of $1 billion principal amount of the 5.45% Senior Notes due June 2023.

- added (2023-09-12):
[0001571996-23-000032:note_history:42]
•the repayment of $1 billion principal amount of the 5.45% Senior Notes due June 2023; and

- added (2023-09-12):
[0001571996-23-000032:note_history:43]
•the repayment of $1 billion principal amount of the 6.02% Senior Notes due June 2026 in a tender offer, in connection with which the Company recognized an immaterial amount of debt extinguishment costs in interest and other, net in the Condensed Consolidated Statement of Income.

- changed (2023-09-12):
[0001571996-23-000032:note_history:44]
As of August 4, 2023, the Company had no outstanding borrowings under the 2021 Revolving Credit Facility.
  (was, 2023-06-12, similarity 0.9579):
[0001571996-23-000019:note_history:44]
As of May 5, 2023, the Company had no oustanding borrowings under the 2021 Revolving Credit Facility.

- changed (2023-09-12):
[0001571996-23-000032:note_history:45]
Commercial Paper Program — During Fiscal 2023, the Company established a commercial paper program under which the Company may issue unsecured notes in a maximum aggregate face amount of $5.0 billion outstanding at any time, with maturities up to 397 days from the date of issuance.  The notes are sold on customary terms in the U.S. commercial paper market on a private placement basis.  The proceeds of the notes are used for general corporate purposes.  As of August 4, 2023, the Company had no outstanding borrowings under the commercial paper program.
  (was, 2023-06-12, similarity 0.8328):
[0001571996-23-000019:note_history:45]
Commercial Paper Program — During Fiscal 2023, the Company established a commercial paper program under which the Company may issue unsecured notes in a maximum aggregate face amount of $5.0 billion outstanding at any time, with maturities up to 397 days from the date of issuance.  The notes are sold on customary terms in the U.S. commercial paper market on a private placement basis.  The proceeds of the notes are used for general corporate purposes.  As of May 5, 2023, the Company had no outstanding borrowings under the commercial paper program.  Commercial paper issuances and repayments with maturities of 90 days or less are presented on a net basis within cash flows from financing activities on the Condensed Consolidated Statements of Cash Flows.

- changed (2023-09-12):
[0001571996-23-000032:note_history:46]
Covenants — The credit agreement governing the 2021 Revolving Credit Facility and the indentures governing the Senior Notes and the Legacy Notes and Debentures impose various limitations, subject to exceptions, on creating certain liens and entering into sale and lease-back transactions.  The foregoing credit agreement and indentures contain customary events of default, including failure to make required payments, failure to comply with covenants, and the occurrence of certain events of bankruptcy and insolvency.  The 2021 Revolving Credit Facility is also subject to an interest coverage ratio covenant that is tested at the end of each fiscal quarter with respect to the Company’s preceding four fiscal quarters.  The Company was in compliance with this financial covenant as of August 4, 2023.
  (was, 2023-06-12, similarity 0.9943):
[0001571996-23-000019:note_history:46]
Covenants — The credit agreement governing the 2021 Revolving Credit Facility and the indentures governing the Senior Notes and the Legacy Notes and Debentures impose various limitations, subject to exceptions, on creating certain liens and entering into sale and lease-back transactions.  The foregoing credit agreement and indentures contain customary events of default, including failure to make required payments, failure to comply with covenants, and the occurrence of certain events of bankruptcy and insolvency.  The 2021 Revolving Credit Facility is also subject to an interest coverage ratio covenant that is tested at the end of each fiscal quarter with respect to the Company’s preceding four fiscal quarters.  The Company was in compliance with this financial covenant as of May 5, 2023.

- changed (2023-09-12):
[0001571996-23-000032:note_history:47]
The following table presents the aggregate future maturities of the Company’s debt as of August 4, 2023 for the periods indicated:
  (was, 2023-06-12, similarity 0.9719):
[0001571996-23-000019:note_history:47]
The following table presents the aggregate future maturities of the Company’s debt as of May 5, 2023 for the periods indicated:

- changed (2023-09-12):
[0001571996-23-000032:note_history:48]
|  | Maturities by Fiscal Year |
|  | 2024 (remaining six months) |  | 2025 |  | 2026 |  | 2027 |  | 2028 |  | Thereafter |  | Total |
|  | (in millions) |
| Senior Notes | $ | — |  |  | $ | 1,000 |  |  | $ | 1,000 |  |  | $ | 5,250 |  |  | $ | 500 |  |  | $ | 8,381 |  |  | $ | 16,131 |  |
| Legacy Notes and Debentures | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 952 |  |  | 952 |  |
| DFS Debt | 2,827 |  |  | 4,341 |  |  | 1,511 |  |  | 773 |  |  | 590 |  |  | 1 |  |  | 10,043 |  |
| Other | 100 |  |  | 122 |  |  | 27 |  |  | 8 |  |  | 5 |  |  | — |  |  | 262 |  |
| Total maturities, principal amount | 2,927 |  |  | 5,463 |  |  | 2,538 |  |  | 6,031 |  |  | 1,095 |  |  | 9,334 |  |  | 27,388 |  |
| Associated carrying value adjustments | (2) |  |  | (7) |  |  | (7) |  |  | (36) |  |  | (8) |  |  | (190) |  |  | (250) |  |
| Total maturities, carrying value amount | $ | 2,925 |  |  | $ | 5,456 |  |  | $ | 2,531 |  |  | $ | 5,995 |  |  | $ | 1,087 |  |  | $ | 9,144 |  |  | $ | 27,138 |  |
  (was, 2023-06-12, similarity 0.9942):
[0001571996-23-000019:note_history:48]
|  | Maturities by Fiscal Year |
|  | 2024 (remaining nine months) |  | 2025 |  | 2026 |  | 2027 |  | 2028 |  | Thereafter |  | Total |
|  | (in millions) |
| Senior Notes | $ | — |  |  | $ | 1,000 |  |  | $ | 1,000 |  |  | $ | 6,250 |  |  | $ | 500 |  |  | $ | 8,500 |  |  | $ | 17,250 |  |
| Legacy Notes and Debentures | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 952 |  |  | 952 |  |
| DFS Debt | 4,442 |  |  | 3,829 |  |  | 643 |  |  | 681 |  |  | 562 |  |  | — |  |  | 10,157 |  |
| Other | 177 |  |  | 122 |  |  | 26 |  |  | 7 |  |  | 4 |  |  | — |  |  | 336 |  |
| Total maturities, principal amount | 4,619 |  |  | 4,951 |  |  | 1,669 |  |  | 6,938 |  |  | 1,066 |  |  | 9,452 |  |  | 28,695 |  |
| Associated carrying value adjustments | (3) |  |  | (8) |  |  | (8) |  |  | (43) |  |  | (8) |  |  | (193) |  |  | (263) |  |
| Total maturities, carrying value amount | $ | 4,616 |  |  | $ | 4,943 |  |  | $ | 1,661 |  |  | $ | 6,895 |  |  | $ | 1,058 |  |  | $ | 9,259 |  |  | $ | 28,432 |  |


## us-gaap:ScheduleOfCarryingValuesAndEstimatedFairValuesOfDebtInstrumentsTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-09-12):
[0001571996-23-000032:note_history:49]
|  | August 4, 2023 |  | February 3, 2023 |
|  | Carrying Value |  | Fair Value |  | Carrying Value |  | Fair Value |
|  | (in billions) |
| Senior Notes | $ | 16.0 |  |  | $ | 15.8 |  |  | $ | 18.1 |  |  | $ | 18.2 |  |
| Legacy Notes and Debentures | $ | 0.9 |  |  | $ | 1.0 |  |  | $ | 0.9 |  |  | $ | 1.0 |  |
| DFS Debt | $ | 10.0 |  |  | $ | 9.6 |  |  | $ | 10.3 |  |  | $ | 9.9 |  |
  (was, 2023-06-12, similarity 0.986):
[0001571996-23-000019:note_history:49]
|  | May 5, 2023 |  | February 3, 2023 |
|  | Carrying Value |  | Fair Value |  | Carrying Value |  | Fair Value |
|  | (in billions) |
| Senior Notes | $ | 17.1 |  |  | $ | 17.1 |  |  | $ | 18.1 |  |  | $ | 18.2 |  |
| Legacy Notes and Debentures | $ | 0.9 |  |  | $ | 1.0 |  |  | $ | 0.9 |  |  | $ | 1.0 |  |
| DFS Debt | $ | 10.2 |  |  | $ | 9.8 |  |  | $ | 10.3 |  |  | $ | 9.9 |  |


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-09-12):
[0001571996-23-000032:note_history:50]
|  | August 4, 2023 |  | February 3, 2023 |
| DFS debt | (in millions) |
| DFS U.S. debt: |  |  |  |
| Asset-based financing and securitization facilities | $ | 3,067 |  |  | $ | 3,987 |  |
| Fixed-term securitization offerings | 3,471 |  |  | 2,679 |  |
| Other | 58 |  |  | 76 |  |
| Total DFS U.S. debt | 6,596 |  |  | 6,742 |  |
| DFS international debt: |  |  |  |
| Securitization facility | 793 |  |  | 790 |  |
| Other borrowings | 762 |  |  | 871 |  |
| Note payable | 250 |  |  | 250 |  |
| Dell Bank senior unsecured eurobonds | 1,642 |  |  | 1,637 |  |
| Total DFS international debt | 3,447 |  |  | 3,548 |  |
| Total DFS debt | $ | 10,043 |  |  | $ | 10,290 |  |
| Total short-term DFS debt | $ | 5,801 |  |  | $ | 5,400 |  |
| Total long-term DFS debt | $ | 4,242 |  |  | $ | 4,890 |  |
  (was, 2023-06-12, similarity 0.9933):
[0001571996-23-000019:note_history:50]
|  | May 5, 2023 |  | February 3, 2023 |
| DFS debt | (in millions) |
| DFS U.S. debt: |  |  |  |
| Asset-based financing and securitization facilities | $ | 3,326 |  |  | $ | 3,987 |  |
| Fixed-term securitization offerings | 3,192 |  |  | 2,679 |  |
| Other | 67 |  |  | 76 |  |
| Total DFS U.S. debt | 6,585 |  |  | 6,742 |  |
| DFS international debt: |  |  |  |
| Securitization facility | 818 |  |  | 790 |  |
| Other borrowings | 852 |  |  | 871 |  |
| Note payable | 250 |  |  | 250 |  |
| Dell Bank senior unsecured eurobonds | 1,652 |  |  | 1,637 |  |
| Total DFS international debt | 3,572 |  |  | 3,548 |  |
| Total DFS debt | $ | 10,157 |  |  | $ | 10,290 |  |
| Total short-term DFS debt | $ | 5,232 |  |  | $ | 5,400 |  |
| Total long-term DFS debt | $ | 4,925 |  |  | $ | 4,890 |  |

- changed (2023-09-12):
[0001571996-23-000032:note_history:51]
|  | August 4, 2023 |  | February 3, 2023 |
|  | (in millions) |
| Senior Notes: |  |  |  |
| 5.45% due June 2023 | $ | — |  |  | $ | 1,000 |  |
| 4.00% due July 2024 | 1,000 |  |  | 1,000 |  |
| 5.85% due July 2025 | 1,000 |  |  | 1,000 |  |
| 6.02% due June 2026 | 3,500 |  |  | 4,500 |  |
| 4.90% due October 2026 | 1,750 |  |  | 1,750 |  |
| 6.10% due July 2027 | 500 |  |  | 500 |  |
| 5.25% due February 2028 | 1,000 |  |  | 1,000 |  |
| 5.30% due October 2029 | 1,750 |  |  | 1,750 |  |
| 6.20% due July 2030 | 750 |  |  | 750 |  |
| 5.75% due February 2033 | 1,000 |  |  | 1,000 |  |
| 8.10% due July 2036 | 1,000 |  |  | 1,000 |  |
| 3.38% due December 2041 | 982 |  |  | 1,000 |  |
| 8.35% due July 2046 | 800 |  |  | 800 |  |
| 3.45% due December 2051 | 1,099 |  |  | 1,250 |  |
| Legacy Notes and Debentures: |  |  |  |
| 7.10% due April 2028 | 300 |  |  | 300 |  |
| 6.50% due April 2038 | 388 |  |  | 388 |  |
| 5.40% due September 2040 | 264 |  |  | 264 |  |
| DFS Debt (Note 4) | 10,043 |  |  | 10,290 |  |
| Other | 262 |  |  | 325 |  |
| Total debt, principal amount | $ | 27,388 |  |  | $ | 29,867 |  |
| Unamortized discount, net of unamortized premium | (119) |  |  | (133) |  |
| Debt issuance costs | (131) |  |  | (146) |  |
| Total debt, carrying value | $ | 27,138 |  |  | $ | 29,588 |  |
| Total short-term debt, carrying value | $ | 6,961 |  |  | $ | 6,573 |  |
| Total long-term debt, carrying value | $ | 20,177 |  |  | $ | 23,015 |  |
  (was, 2023-06-12, similarity 0.9959):
[0001571996-23-000019:note_history:51]
|  | May 5, 2023 |  | February 3, 2023 |
|  | (in millions) |
| Senior Notes: |  |  |  |
| 5.45% due June 2023 | $ | — |  |  | $ | 1,000 |  |
| 4.00% due July 2024 | 1,000 |  |  | 1,000 |  |
| 5.85% due July 2025 | 1,000 |  |  | 1,000 |  |
| 6.02% due June 2026 | 4,500 |  |  | 4,500 |  |
| 4.90% due October 2026 | 1,750 |  |  | 1,750 |  |
| 6.10% due July 2027 | 500 |  |  | 500 |  |
| 5.25% due February 2028 | 1,000 |  |  | 1,000 |  |
| 5.30% due October 2029 | 1,750 |  |  | 1,750 |  |
| 6.20% due July 2030 | 750 |  |  | 750 |  |
| 5.75% due February 2033 | 1,000 |  |  | 1,000 |  |
| 8.10% due July 2036 | 1,000 |  |  | 1,000 |  |
| 3.38% due December 2041 | 1,000 |  |  | 1,000 |  |
| 8.35% due July 2046 | 800 |  |  | 800 |  |
| 3.45% due December 2051 | 1,200 |  |  | 1,250 |  |
| Legacy Notes and Debentures: |  |  |  |
| 7.10% due April 2028 | 300 |  |  | 300 |  |
| 6.50% due April 2038 | 388 |  |  | 388 |  |
| 5.40% due September 2040 | 264 |  |  | 264 |  |
| DFS Debt (Note 4) | 10,157 |  |  | 10,290 |  |
| Other | 336 |  |  | 325 |  |
| Total debt, principal amount | $ | 28,695 |  |  | $ | 29,867 |  |
| Unamortized discount, net of unamortized premium | (121) |  |  | (133) |  |
| Debt issuance costs | (142) |  |  | (146) |  |
| Total debt, carrying value | $ | 28,432 |  |  | $ | 29,588 |  |
| Total short-term debt, carrying value | $ | 5,470 |  |  | $ | 6,573 |  |
| Total long-term debt, carrying value | $ | 22,962 |  |  | $ | 23,015 |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-09-12):
[0001571996-23-000032:note_history:52]
The following table presents the aggregate future maturities of the Company’s debt as of August 4, 2023 for the periods indicated:
  (was, 2023-06-12, similarity 0.9719):
[0001571996-23-000019:note_history:52]
The following table presents the aggregate future maturities of the Company’s debt as of May 5, 2023 for the periods indicated:

- changed (2023-09-12):
[0001571996-23-000032:note_history:53]
|  | Maturities by Fiscal Year |
|  | 2024 (remaining six months) |  | 2025 |  | 2026 |  | 2027 |  | 2028 |  | Thereafter |  | Total |
|  | (in millions) |
| Senior Notes | $ | — |  |  | $ | 1,000 |  |  | $ | 1,000 |  |  | $ | 5,250 |  |  | $ | 500 |  |  | $ | 8,381 |  |  | $ | 16,131 |  |
| Legacy Notes and Debentures | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 952 |  |  | 952 |  |
| DFS Debt | 2,827 |  |  | 4,341 |  |  | 1,511 |  |  | 773 |  |  | 590 |  |  | 1 |  |  | 10,043 |  |
| Other | 100 |  |  | 122 |  |  | 27 |  |  | 8 |  |  | 5 |  |  | — |  |  | 262 |  |
| Total maturities, principal amount | 2,927 |  |  | 5,463 |  |  | 2,538 |  |  | 6,031 |  |  | 1,095 |  |  | 9,334 |  |  | 27,388 |  |
| Associated carrying value adjustments | (2) |  |  | (7) |  |  | (7) |  |  | (36) |  |  | (8) |  |  | (190) |  |  | (250) |  |
| Total maturities, carrying value amount | $ | 2,925 |  |  | $ | 5,456 |  |  | $ | 2,531 |  |  | $ | 5,995 |  |  | $ | 1,087 |  |  | $ | 9,144 |  |  | $ | 27,138 |  |
  (was, 2023-06-12, similarity 0.9942):
[0001571996-23-000019:note_history:53]
|  | Maturities by Fiscal Year |
|  | 2024 (remaining nine months) |  | 2025 |  | 2026 |  | 2027 |  | 2028 |  | Thereafter |  | Total |
|  | (in millions) |
| Senior Notes | $ | — |  |  | $ | 1,000 |  |  | $ | 1,000 |  |  | $ | 6,250 |  |  | $ | 500 |  |  | $ | 8,500 |  |  | $ | 17,250 |  |
| Legacy Notes and Debentures | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 952 |  |  | 952 |  |
| DFS Debt | 4,442 |  |  | 3,829 |  |  | 643 |  |  | 681 |  |  | 562 |  |  | — |  |  | 10,157 |  |
| Other | 177 |  |  | 122 |  |  | 26 |  |  | 7 |  |  | 4 |  |  | — |  |  | 336 |  |
| Total maturities, principal amount | 4,619 |  |  | 4,951 |  |  | 1,669 |  |  | 6,938 |  |  | 1,066 |  |  | 9,452 |  |  | 28,695 |  |
| Associated carrying value adjustments | (3) |  |  | (8) |  |  | (8) |  |  | (43) |  |  | (8) |  |  | (193) |  |  | (263) |  |
| Total maturities, carrying value amount | $ | 4,616 |  |  | $ | 4,943 |  |  | $ | 1,661 |  |  | $ | 6,895 |  |  | $ | 1,058 |  |  | $ | 9,259 |  |  | $ | 28,432 |  |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2023-09-12):
[0001571996-23-000032:note_history:54]
•Dell Technologies procures products and services from VMware for its internal use.  For the three and six months ended August 4, 2023 and July 29, 2022, costs incurred associated with products and services purchased from VMware for internal use were immaterial.
  (was, 2023-06-12, similarity 0.8618):
[0001571996-23-000019:note_history:54]
•Dell Technologies procures products and services from VMware for its internal use.  For the three months ended May 5, 2023 and April 29, 2022, costs incurred associated with products and services purchased from VMware for internal use were immaterial.

- changed (2023-09-12):
[0001571996-23-000032:note_history:55]
•Dell Technologies sells and leases products and sells services to VMware.  For the three and six months ended August 4, 2023 and July 29, 2022, revenue recognized from sales of services to VMware was immaterial.
  (was, 2023-06-12, similarity 0.9439):
[0001571996-23-000019:note_history:55]
•Dell Technologies sells and leases products and sells services to VMware.  For the three months ended May 5, 2023 and April 29, 2022, revenue recognized from sales of services to VMware was immaterial.

- changed (2023-09-12):
[0001571996-23-000032:note_history:56]
•Dell Technologies and VMware also enter into joint marketing, sales, and branding arrangements, for which both parties may incur costs.  For the three and six months ended August 4, 2023 and July 29, 2022, consideration received from VMware for joint marketing, sales, and branding arrangements was immaterial.
  (was, 2023-06-12, similarity 0.7356):
[0001571996-23-000019:note_history:56]
•Dell Technologies and VMware also enter into joint marketing, sales, and branding arrangements, for which both parties may incur costs.  For the three months ended May 5, 2023 and April 29, 2022, consideration received from VMware for joint marketing, sales, and branding arrangements was immaterial.

- changed (2023-09-12):
[0001571996-23-000032:note_history:57]
•Dell Technologies and VMware entered into a transition services agreement in connection with the VMware Spin-off to provide various support services, including investment advisory services, certain support services from Dell Technologies personnel, and other transitional services.  Costs associated with this agreement were immaterial for the three and six months ended July 29, 2022.  Activities under the agreement concluded during Fiscal 2023.
  (was, 2023-06-12, similarity 0.9503):
[0001571996-23-000019:note_history:57]
•Dell Technologies and VMware entered into a transition services agreement in connection with the VMware Spin-off to provide various support services, including investment advisory services, certain support services from Dell Technologies personnel, and other transitional services.  Costs associated with this agreement were immaterial for the three months ended April 29, 2022.  Activities under the agreement concluded during Fiscal 2023.

- added (2023-09-12):
[0001571996-23-000032:note_history:58]
|  |  |  | Three Months Ended |  | Six Months Ended |
|  | Classification |  | August 4, 2023 |  | July 29, 2022 |  | August 4, 2023 |  | July 29, 2022 |  |  |
|  |  |  | (in millions) |
| Sales and leases of products to VMware | Net revenue - products |  | $ | 38 |  |  | $ | 35 |  |  | $ | 78 |  |  | $ | 81 |  |  |  |
| Purchase of VMware products for resale | Cost of net revenue - products |  | $ | 384 |  |  | $ | 426 |  |  | $ | 591 |  |  | $ | 681 |  |  |  |
| Purchase of VMware services for resale | Cost of net revenue - services |  | $ | 880 |  |  | $ | 762 |  |  | $ | 1,756 |  |  | $ | 1,471 |  |  |  |

- changed (2023-09-12):
[0001571996-23-000032:note_history:59]
|  | Classification |  | August 4, 2023 |  | February 3, 2023 |
|  |  |  | (in millions) |
| Deferred costs related to VMware products and services for resale | Other current assets |  | $ | 2,898 |  |  | $ | 3,000 |  |
| Deferred costs related to VMware products and services for resale | Other non-current assets |  | $ | 2,277 |  |  | $ | 2,537 |  |
  (was, 2023-06-12, similarity 0.9856):
[0001571996-23-000019:note_history:59]
|  | Classification |  | May 5, 2023 |  | February 3, 2023 |
|  |  |  | (in millions) |
| Deferred costs related to VMware products and services for resale | Other current assets |  | $ | 2,863 |  |  | $ | 3,000 |  |
| Deferred costs related to VMware products and services for resale | Other non-current assets |  | $ | 2,234 |  |  | $ | 2,537 |  |

- added (2023-09-12):
[0001571996-23-000032:note_history:60]
|  | August 4, 2023 |  | February 3, 2023 |
|  | (in millions) |
| Due from related party, net, current (a) | $ | 404 |  |  | $ | 378 |  |
| Due from related party, net, non-current (b) | $ | 236 |  |  | $ | 440 |  |
| Due to related party, current (c) | $ | 1,252 |  |  | $ | 2,067 |  |

- changed (2023-09-12):
[0001571996-23-000032:note_history:61]
Pursuant to the Tax Agreements, net receipts from VMware during the six months ended August 4, 2023 and net payments to VMware during the six months ended July 29, 2022 were immaterial.
  (was, 2023-06-12, similarity 0.9153):
[0001571996-23-000019:note_history:61]
Pursuant to the Tax Agreements, net receipts from VMware during the three months ended May 5, 2023 and net payments to VMware during the three months ended April 29, 2022 were immaterial.

- added (2023-09-12):
[0001571996-23-000032:note_history:62]
As a result of the activity under the Tax Agreements with VMware, amounts due from VMware were $484 million and $599 million as of August 4, 2023 and February 3, 2023, respectively, primarily related to VMware’s estimated tax obligation resulting from the Transition Tax.  The 2017 Tax Cuts and Jobs Act included a deferral election for an eight-year installment payment method on the Transition Tax.  Dell Technologies expects VMware to pay the remainder of its Transition Tax over a period of two years.

- changed (2023-09-12):
[0001571996-23-000032:note_history:63]
Indemnification — Upon consummation of the VMware Spin-off, Dell Technologies recorded net income tax indemnification receivables from VMware related to certain income tax liabilities for which Dell Technologies is jointly and severally liable, but for which it is indemnified by VMware under the Tax Matters Agreement.  The amounts that VMware may be obligated to pay Dell Technologies could vary depending on the outcome of certain unresolved tax matters, which may not be resolved for several years.  The net receivable as of August 4, 2023 and February 3, 2023 was $93 million and $146 million, respectively.
  (was, 2023-06-12, similarity 0.9925):
[0001571996-23-000019:note_history:63]
Indemnification — Upon consummation of the VMware Spin-off, Dell Technologies recorded net income tax indemnification receivables from VMware related to certain income tax liabilities for which Dell Technologies is jointly and severally liable, but for which it is indemnified by VMware under the Tax Matters Agreement.  The amounts that VMware may be obligated to pay Dell Technologies could vary depending on the outcome of certain unresolved tax matters, which may not be resolved for several years.  The net receivable as of May 5, 2023 and February 3, 2023 was $150 million and $146 million, respectively.

- removed (2023-09-12):
[0001571996-23-000019:note_history:64]
|  |  |  |  |  | Three Months Ended |
|  | Classification |  |  |  |  |  | May 5, 2023 |  | April 29, 2022 |  |  |
|  |  |  |  |  |  |  | (in millions) |
| Sales and leases of products to VMware | Net revenue - products |  |  |  |  |  | $ | 40 |  |  | $ | 46 |  |  |  |
| Purchase of VMware products for resale | Cost of net revenue - products |  |  |  |  |  | $ | 207 |  |  | $ | 255 |  |  |  |
| Purchase of VMware services for resale | Cost of net revenue - services |  |  |  |  |  | $ | 876 |  |  | $ | 709 |  |  |  |

- removed (2023-09-12):
[0001571996-23-000019:note_history:65]
|  | May 5, 2023 |  | February 3, 2023 |
|  | (in millions) |
| Due from related party, net, current (a) | $ | 384 |  |  | $ | 378 |  |
| Due from related party, net, non-current (b) | $ | 442 |  |  | $ | 440 |  |
| Due to related party, current (c) | $ | 594 |  |  | $ | 2,067 |  |

- removed (2023-09-12):
[0001571996-23-000019:note_history:66]
As a result of the activity under the Tax Agreements with VMware, amounts due from VMware were $596 million and $599 million as of May 5, 2023 and February 3, 2023, respectively, primarily related to VMware’s estimated tax obligation resulting from the Transition Tax.  The 2017 Tax Cuts and Jobs Act included a deferral election for an eight-year installment payment method on the Transition Tax.  Dell Technologies expects VMware to pay the remainder of its Transition Tax over a period of three years.


## us-gaap:ScheduleOfRelatedPartyTransactionsTableTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- added (2023-09-12):
[0001571996-23-000032:note_history:67]
|  |  |  | Three Months Ended |  | Six Months Ended |
|  | Classification |  | August 4, 2023 |  | July 29, 2022 |  | August 4, 2023 |  | July 29, 2022 |  |  |
|  |  |  | (in millions) |
| Sales and leases of products to VMware | Net revenue - products |  | $ | 38 |  |  | $ | 35 |  |  | $ | 78 |  |  | $ | 81 |  |  |  |
| Purchase of VMware products for resale | Cost of net revenue - products |  | $ | 384 |  |  | $ | 426 |  |  | $ | 591 |  |  | $ | 681 |  |  |  |
| Purchase of VMware services for resale | Cost of net revenue - services |  | $ | 880 |  |  | $ | 762 |  |  | $ | 1,756 |  |  | $ | 1,471 |  |  |  |

- changed (2023-09-12):
[0001571996-23-000032:note_history:68]
|  | Classification |  | August 4, 2023 |  | February 3, 2023 |
|  |  |  | (in millions) |
| Deferred costs related to VMware products and services for resale | Other current assets |  | $ | 2,898 |  |  | $ | 3,000 |  |
| Deferred costs related to VMware products and services for resale | Other non-current assets |  | $ | 2,277 |  |  | $ | 2,537 |  |
  (was, 2023-06-12, similarity 0.9856):
[0001571996-23-000019:note_history:68]
|  | Classification |  | May 5, 2023 |  | February 3, 2023 |
|  |  |  | (in millions) |
| Deferred costs related to VMware products and services for resale | Other current assets |  | $ | 2,863 |  |  | $ | 3,000 |  |
| Deferred costs related to VMware products and services for resale | Other non-current assets |  | $ | 2,234 |  |  | $ | 2,537 |  |

- added (2023-09-12):
[0001571996-23-000032:note_history:69]
|  | August 4, 2023 |  | February 3, 2023 |
|  | (in millions) |
| Due from related party, net, current (a) | $ | 404 |  |  | $ | 378 |  |
| Due from related party, net, non-current (b) | $ | 236 |  |  | $ | 440 |  |
| Due to related party, current (c) | $ | 1,252 |  |  | $ | 2,067 |  |

- removed (2023-09-12):
[0001571996-23-000019:note_history:70]
|  |  |  |  |  | Three Months Ended |
|  | Classification |  |  |  |  |  | May 5, 2023 |  | April 29, 2022 |  |  |
|  |  |  |  |  |  |  | (in millions) |
| Sales and leases of products to VMware | Net revenue - products |  |  |  |  |  | $ | 40 |  |  | $ | 46 |  |  |  |
| Purchase of VMware products for resale | Cost of net revenue - products |  |  |  |  |  | $ | 207 |  |  | $ | 255 |  |  |  |
| Purchase of VMware services for resale | Cost of net revenue - services |  |  |  |  |  | $ | 876 |  |  | $ | 709 |  |  |  |

- removed (2023-09-12):
[0001571996-23-000019:note_history:71]
|  | May 5, 2023 |  | February 3, 2023 |
|  | (in millions) |
| Due from related party, net, current (a) | $ | 384 |  |  | $ | 378 |  |
| Due from related party, net, non-current (b) | $ | 442 |  |  | $ | 440 |  |
| Due to related party, current (c) | $ | 594 |  |  | $ | 2,067 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2023-09-12):
[0001571996-23-000032:note_history:72]
|  | Three Months Ended |  | Six Months Ended |
|  | August 4, 2023 |  | July 29, 2022 |  | August 4, 2023 |  | July 29, 2022 |
|  | (in millions) |
| Net revenue: |  |  |  |  |  |  |  |
| Infrastructure Solutions Group: |  |  |  |  |  |  |  |
| Servers and networking | $ | 4,274 |  |  | $ | 5,209 |  |  | $ | 8,111 |  |  | $ | 10,257 |  |
| Storage | 4,187 |  |  | 4,327 |  |  | 7,943 |  |  | 8,564 |  |
| Total ISG net revenue | $ | 8,461 |  |  | $ | 9,536 |  |  | $ | 16,054 |  |  | $ | 18,821 |  |
| Client Solutions Group: |  |  |  |  |  |  |  |
| Commercial | $ | 10,554 |  |  | $ | 12,141 |  |  | $ | 20,416 |  |  | $ | 24,112 |  |
| Consumer | 2,388 |  |  | 3,349 |  |  | 4,509 |  |  | 6,965 |  |
| Total CSG net revenue | $ | 12,942 |  |  | $ | 15,490 |  |  | $ | 24,925 |  |  | $ | 31,077 |  |
  (was, 2023-06-12, similarity 0.6305):
[0001571996-23-000019:note_history:72]
|  |  |  | Three Months Ended |
|  |  |  |  |  | May 5, 2023 |  | April 29, 2022 |
|  |  |  |  |  | (in millions) |
| Net revenue: |  |  |  |  |  |  |  |
| Infrastructure Solutions Group: |  |  |  |  |  |  |  |
| Servers and networking |  |  |  |  | $ | 3,837 |  |  | $ | 5,048 |  |
| Storage |  |  |  |  | 3,756 |  |  | 4,237 |  |
| Total ISG net revenue |  |  |  |  | $ | 7,593 |  |  | $ | 9,285 |  |
| Client Solutions Group: |  |  |  |  |  |  |  |
| Commercial |  |  |  |  | $ | 9,862 |  |  | $ | 11,971 |  |
| Consumer |  |  |  |  | 2,121 |  |  | 3,616 |  |
| Total CSG net revenue |  |  |  |  | $ | 11,983 |  |  | $ | 15,587 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2023-09-12):
[0001571996-23-000032:note_history:73]
DEFERRED REVENUE 
Deferred revenue consists of support and deployment services, software maintenance, training, Software-as-a-Service, and undelivered hardware and professional services, consisting of installations and consulting engagements.  Deferred revenue is recorded when the Company has invoiced or payments have been received for undelivered products or services where transfer of control has not occurred.  Revenue is recognized as the Company’s performance obligations under the contract are completed.
  (was, 2023-06-12, similarity 0.9817):
[0001571996-23-000019:note_history:73]
DEFERRED REVENUE 
Deferred Revenue — Deferred revenue consists of support and deployment services, software maintenance, training, Software-as-a-Service, and undelivered hardware and professional services, consisting of installations and consulting engagements.  Deferred revenue is recorded when the Company has invoiced or payments have been received for undelivered products or services where transfer of control has not occurred.  Revenue is recognized as the Company’s performance obligations under the contract are completed.

- changed (2023-09-12):
[0001571996-23-000032:note_history:74]
|  | Three Months Ended |  | Six Months Ended |
|  | August 4, 2023 |  | July 29, 2022 |  | August 4, 2023 |  | July 29, 2022 |
|  | (in millions) |
| Deferred revenue: |  |  |  |  |  |  |  |
| Deferred revenue at beginning of period | $ | 29,695 |  |  | $ | 27,403 |  |  | $ | 30,286 |  |  | $ | 27,573 |  |
| Revenue deferrals | 6,025 |  |  | 5,572 |  |  | 10,744 |  |  | 10,547 |  |
| Revenue recognized | (5,408) |  |  | (4,950) |  |  | (10,718) |  |  | (9,930) |  |
| Other (a) | — |  |  | — |  |  | — |  |  | (165) |  |
| Deferred revenue at end of period | $ | 30,312 |  |  | $ | 28,025 |  |  | $ | 30,312 |  |  | $ | 28,025 |  |
| Short-term deferred revenue | $ | 16,174 |  |  | $ | 14,724 |  |  | $ | 16,174 |  |  | $ | 14,724 |  |
| Long-term deferred revenue | $ | 14,138 |  |  | $ | 13,301 |  |  | $ | 14,138 |  |  | $ | 13,301 |  |
  (was, 2023-06-12, similarity 0.7566):
[0001571996-23-000019:note_history:74]
|  |  |  | Three Months Ended |
|  |  |  |  |  | May 5, 2023 |  | April 29, 2022 |
|  |  |  |  |  | (in millions) |
| Deferred revenue: |  |  |  |  |  |  |  |
| Deferred revenue at beginning of period |  |  |  |  | $ | 30,286 |  |  | $ | 27,573 |  |
| Revenue deferrals |  |  |  |  | 4,719 |  |  | 4,975 |  |
| Revenue recognized |  |  |  |  | (5,310) |  |  | (4,980) |  |
| Other (a) |  |  |  |  | — |  |  | (165) |  |
| Deferred revenue at end of period |  |  |  |  | $ | 29,695 |  |  | $ | 27,403 |  |
| Short-term deferred revenue |  |  |  |  | $ | 15,527 |  |  | $ | 14,329 |  |
| Long-term deferred revenue |  |  |  |  | $ | 14,168 |  |  | $ | 13,074 |  |

- changed (2023-09-12):
[0001571996-23-000032:note_history:75]
(a)    For the six months ended July 29, 2022, Other represents the reclassification of deferred revenue to accrued and other liabilities.
  (was, 2023-06-12, similarity 0.8482):
[0001571996-23-000019:note_history:75]
(a)    Other represents the reclassification of deferred revenue to accrued and other liabilities.

- changed (2023-09-12):
[0001571996-23-000032:note_history:76]
Remaining Performance Obligations — Remaining performance obligations represent the aggregate amount of the transaction price allocated to performance obligations not delivered, or partially undelivered, as of the end of the reporting period.  Remaining performance obligations include deferred revenue plus unbilled amounts not yet recorded in deferred revenue.  The value of the transaction price allocated to remaining performance obligations as of August 4, 2023 was approximately $39 billion.  The Company expects to recognize approximately 58% of remaining performance obligations as revenue in the next twelve months, and the remainder thereafter.
  (was, 2023-06-12, similarity 0.993):
[0001571996-23-000019:note_history:76]
Remaining Performance Obligations — Remaining performance obligations represent the aggregate amount of the transaction price allocated to performance obligations not delivered, or partially undelivered, as of the end of the reporting period.  Remaining performance obligations include deferred revenue plus unbilled amounts not yet recorded in deferred revenue.  The value of the transaction price allocated to remaining performance obligations as of May 5, 2023 was approximately $39 billion.  The Company expects to recognize approximately 57% of remaining performance obligations as revenue in the next twelve months, and the remainder thereafter.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- changed (2023-09-12):
[0001571996-23-000032:note_history:77]
SUBSEQUENT EVENTS There were no known events occurring after August 4, 2023 and up until the date of issuance of this report that would materially affect the information presented herein.
  (was, 2023-06-12, similarity 0.9807):
[0001571996-23-000019:note_history:77]
SUBSEQUENT EVENTS There were no known events occurring after May 5, 2023 and up until the date of issuance of this report that would materially affect the information presented herein.
