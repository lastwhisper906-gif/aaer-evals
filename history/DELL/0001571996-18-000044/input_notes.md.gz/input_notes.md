# DELL notes — 0001571996-18-000044


## us-gaap:BusinessDescriptionAndBasisOfPresentationTextBlock

[0001571996-18-000044:notes:1]
NOTE 1 — BASIS OF PRESENTATION

[0001571996-18-000044:notes:2]
References in these Notes to the Condensed Consolidated Financial Statements to the “Company” or “Dell Technologies” mean Dell Technologies Inc. individually and together with its consolidated subsidiaries.

[0001571996-18-000044:notes:3]
Basis of Presentation — The accompanying unaudited Condensed Consolidated Financial Statements should be read in conjunction with the audited Consolidated Financial Statements and accompanying Notes included in the Company’s Annual Report on Form 10-K for the fiscal year ended February 2, 2018, and the recast audited Consolidated Financial Statements and accompanying Notes for the fiscal years ended February 2, 2018 and February 3, 2017 (the “Recast Financial Statements”)

[0001571996-18-000044:notes:4]
and other financial information included in the Company’s Current Report on Form 8-K filed with the Securities and Exchange Commission (the “SEC”) on August 6, 2018.  The Recast Financial Statements were recast from and supersede the audited Consolidated Financial Statements for the fiscal years ended February 2, 2018 and February 3, 2017 included in the Company’s Annual Report on Form 10-K for the fiscal year ended February 2, 2018.  Such audited Consolidated Financial Statements were recast to present certain previously reported financial statements and other related financial information on a basis consistent with the new accounting standards adopted during the three months ended May 4, 2018.  Further, segment information was recast to conform with certain segment reporting changes the Company made during the three months ended May 4, 2018.  See below for additional information regarding recently adopted accounting pronouncements.

[0001571996-18-000044:notes:5]
These Condensed Consolidated Financial Statements have been prepared in accordance with accounting principles generally accepted in the United States of America (“GAAP”).  In the opinion of management, the accompanying Condensed  Consolidated Financial Statements reflect all adjustments of a normal recurring nature considered necessary to fairly state the financial position of Dell Technologies Inc. as of November 2, 2018, the results of its operations and corresponding comprehensive income (loss) for the three and nine months ended November 2, 2018 and November 3, 2017, and its cash flows for the nine months ended November 2, 2018 and November 3, 2017.  The February 2, 2018 condensed consolidated balance sheet included herein was derived from the Recast Financial Statements.

[0001571996-18-000044:notes:6]
The preparation of financial statements in accordance with GAAP requires management to make estimates and assumptions that affect the amounts reported in the Condensed Consolidated Financial Statements and the accompanying Notes.  Actual results could differ materially from those estimates.  The results of operations and comprehensive income (loss) for the three and nine months ended November 2, 2018 and November 3, 2017 and the cash flows for the nine months ended November 2, 2018 and November 3, 2017 are not necessarily indicative of the results to be expected for the full fiscal year or for any other fiscal period.

[0001571996-18-000044:notes:7]
The Company’s fiscal year is the 52- or 53-week period ending on the Friday nearest January 31.  The fiscal year ended February 2, 2018 was a 52-week period, and the fiscal year ending February 1, 2019 will be a 52-week period.

[0001571996-18-000044:notes:8]
Principles of Consolidation — These Condensed Consolidated Financial Statements include the accounts of Dell Technologies and its wholly-owned subsidiaries, as well as the accounts of VMware, Inc., Pivotal Software, Inc. (“Pivotal”), and SecureWorks Corp. (“SecureWorks”), each of which is majority-owned by Dell Technologies.  All intercompany transactions have been eliminated.

[0001571996-18-000044:notes:9]
Unless the context indicates otherwise, references in these Notes to the Condensed Consolidated Financial Statements to “VMware” mean the VMware reportable segment, which reflects the operations of VMware, Inc. (NYSE: VMW) within Dell Technologies.  See Exhibit 99.1 filed with the quarterly report on Form 10-Q for the quarterly period ended November 2, 2018 for information on the differences between VMware reportable segment results and VMware, Inc. results.

[0001571996-18-000044:notes:10]
EMC Merger Transaction — On September 7, 2016, the Company completed its acquisition by merger of EMC Corporation (“EMC”), referred to as the EMC merger transaction.  The consolidated results of EMC are included in Dell Technologies’ consolidated results presented in these financial statements.

[0001571996-18-000044:notes:11]
Pivotal Initial Public Offering — On April 24, 2018, Pivotal completed a registered underwritten initial public offering (“IPO”) of its Class A common stock (NYSE: PVTL).  The results of Pivotal’s operations are included in other businesses.  For more information regarding the Company’s ownership of Pivotal, see Note 14 of the Notes to the Condensed Consolidated Financial Statements.

[0001571996-18-000044:notes:12]
Recently Issued Accounting Pronouncements

[0001571996-18-000044:notes:13]
Leases — In February 2016, the Financial Accounting Standards Board (“FASB”) issued amended guidance on the accounting for leasing transactions.  The primary objective of this update is to increase transparency and comparability among organizations by requiring lessees to recognize a lease liability for the obligation to make lease payments and a right-of-use asset for the right to use the underlying asset for the lease term.  The guidance also makes some changes to lessor accounting and requires additional disclosures about all leasing arrangements.  Companies are required to use a modified retrospective approach, with the option of applying the requirements of the standard either (1) retrospectively to each prior comparative reporting period presented, or (2) retrospectively at the beginning of the period of adoption.  The Company will adopt this standard for the fiscal year beginning February 2, 2019, and will apply it at the beginning of the period of adoption through a cumulative-effect adjustment to retained earnings.  In the area of lessee accounting, the Company anticipates that the most significant change will be recognition of right-of-use assets and lease liabilities on the Consolidated Statements of Financial Position.  In the area of lessor accounting, the Company anticipates that the most significant change will be an increase to future originations of operating leases due to elimination of the third-party residual value guarantee insurance in the sales-type lease test.

[0001571996-18-000044:notes:14]
[same as prior period, unchanged from 0001571996-18-000034:notes:35]

[0001571996-18-000044:notes:15]
Recently Adopted Accounting Pronouncements

[0001571996-18-000044:notes:16]
Revenue from Contracts with Customers — In May 2014, the FASB issued amended guidance on the recognition of revenue from contracts with customers.  The objective of the new standard is to establish a single comprehensive model for entities to use in accounting for revenue arising from contracts with customers and will supersede substantially all of the existing revenue recognition guidance, including industry-specific guidance.  The new standard requires entities to recognize revenue when it transfers promised goods or services to customers in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services.  Further, the new standard requires additional disclosures to help enable users of the financial statements to better understand the nature, amount, timing, risks, and judgments related to revenue recognition and related cash flows from contracts with customers.  Concurrently, the FASB issued guidance on the accounting for costs to fulfill or obtain a customer contract.  The Company adopted these standards during the three months ended May 4, 2018 using the full retrospective method, which requires the Company to recast each prior period presented consistent with the new guidance.  The Company recorded a credit of approximately $1 billion to retained earnings as of January 29, 2016 to reflect the cumulative effect of the adoption.  See tables provided below which present the impact of the new accounting standards to the Company’s previously reported financial results.  See also Note 2 of the Notes to the Condensed Consolidated Financial Statements for a summary of significant policies related to the new accounting standards.

[0001571996-18-000044:notes:17]
Recognition and Measurement of Financial Assets and Financial Liabilities — In January 2016, the FASB issued amended guidance that generally requires changes in the fair value of equity investments, other than those accounted for under the equity method, to be recognized through net income, rather than other comprehensive income.  For equity investments without readily determinable fair values, the Company is no longer permitted to use the cost method of accounting.  The Company has elected to apply the measurement alternative for those investments.  Under the alternative, the Company measures investments without readily determinable fair values at cost, less impairment, adjusted by observable price changes on a prospective basis.  The Company must make a separate election to use the alternative for each eligible investment, and is required to reassess at each reporting period whether an investment qualifies for the alternative.  The Company adopted this standard during the three months ended May 4, 2018.  Adoption of the standard was applied through a cumulative one-time adjustment to accumulated deficit of $56 million for the accumulated unrealized gain previously recorded in other comprehensive income.  The impact of the standard on the Condensed Consolidated Statements of Income (Loss) during the three and nine months ended November 2, 2018 was a loss of $14 million and a gain of $209 million, respectively, recognized in interest and other, net, and the impact in future periods will depend on the relative changes in market price of the equity investments.

[0001571996-18-000044:notes:18]
[same as prior period, unchanged from 0001571996-18-000034:notes:40]

[0001571996-18-000044:notes:19]
[same as prior period, unchanged from 0001571996-18-000034:notes:41]

[0001571996-18-000044:notes:20]
[same as prior period, unchanged from 0001571996-18-000034:notes:42]

[0001571996-18-000044:notes:21]
Clarifying the Definition of a Business — In January 2017, the FASB issued amended guidance to clarify the definition of a business with the objective of adding guidance to assist entities with evaluating whether transactions should be accounted for as acquisitions (or disposals) of assets or businesses.  Public entities must adopt the new guidance for fiscal years beginning after December 15, 2017, and interim periods within those fiscal years.  The new guidance did not have a material impact on the Company’s conclusions regarding transactions that were assessed in the current period.

[0001571996-18-000044:notes:22]
Simplifying the Test for Goodwill Impairment — In January 2017, the FASB issued amended guidance to simplify the subsequent measurement of goodwill by removing Step 2 of the goodwill impairment test.  Instead, under the amendments in the new guidance, an entity should perform its annual, or interim, goodwill impairment test by comparing the fair value of a reporting unit with its carrying amount.  An entity should recognize an impairment charge for the amount by which the carrying amount exceeds the reporting unit’s fair value.  Public entities must adopt the new guidance in fiscal years beginning after December 15, 2019, with early adoption permitted.  In conjunction with its annual goodwill and indefinite-lived intangible assets impairment testing which occurs during the third fiscal quarter of each year, the Company elected to early adopt this guidance during the three months ended November 2, 2018.  No interim goodwill impairment tests were required during both the three months ended May 4, 2018 and August 3, 2018.  See Note 8 of the Notes to the Condensed Consolidated Financial Statements for additional information about goodwill impairment testing.

[0001571996-18-000044:notes:23]
[same as prior period, unchanged from 0001571996-18-000034:notes:44]

[0001571996-18-000044:notes:24]
[same as prior period, unchanged from 0001571996-18-000034:notes:45]

[0001571996-18-000044:notes:25]
[same as prior period, unchanged from 0001571996-18-000034:notes:46]

[0001571996-18-000044:notes:26]
The following tables present the impact of the new accounting standards to the Company’s previously reported financial results.

[0001571996-18-000044:notes:27]
[same as prior period, unchanged from 0001571996-18-000034:notes:48]

[0001571996-18-000044:notes:28]
[same as prior period, unchanged from 0001571996-18-000034:notes:49]

[0001571996-18-000044:notes:29]
____________________

[0001571996-18-000044:notes:30]
| (a) | Amounts as reported in the Company’s Annual Report on Form 10-K for the fiscal year ended February 2, 2018. |

[0001571996-18-000044:notes:31]
[same as prior period, unchanged from 0001571996-18-000034:notes:51]

[0001571996-18-000044:notes:32]
[same as prior period, unchanged from 0001571996-18-000034:notes:52]

[0001571996-18-000044:notes:33]
[same as prior period, unchanged from 0001571996-18-000034:notes:53]

[0001571996-18-000044:notes:34]
[same as prior period, unchanged from 0001571996-18-000034:notes:54]

[0001571996-18-000044:notes:35]
[same as prior period, unchanged from 0001571996-18-000034:notes:55]

[0001571996-18-000044:notes:36]
Deferred revenue.  The adoption of the new revenue standard resulted in a decline in deferred revenue due to earlier recognition of revenue for software licenses, and less of the aggregate transaction price being allocated to extended warranty.  Deferred revenue was also reduced by the impact of variable consideration (i.e., price concessions, rebates, and refunds).  The reduction in deferred revenue was partially offset by an increase resulting from the change in presentation of deferred costs on third-party software offerings, which are reported in other assets, and are either sold on a standalone basis or as an attached component of the Company’s hardware offering.  The Company previously reported the associated deferred revenue net of these deferred costs in deferred revenue.

[0001571996-18-000044:notes:37]
Condensed Consolidated Statements of Income (Loss)

[0001571996-18-000044:notes:38]
|  | Three Months Ended |  | Nine Months Ended |
|  | November 3, 2017 |  | November 3, 2017 |
|  | As Reported (a) |  | Revenue from Contracts with Customers |  | As Recast |  | As Reported (a) |  | Revenue from Contracts with Customers |  | As Recast |
|  | (in millions, except per share amounts) |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Products | $ | 14,680 |  |  | $ | 440 |  |  | $ | 15,120 |  |  | $ | 42,003 |  |  | $ | 1,853 |  |  | $ | 43,856 |  |
| Services | 4,930 |  |  | (494 | ) |  | 4,436 |  |  | 14,722 |  |  | (1,501 | ) |  | 13,221 |  |
| Total net revenue | 19,610 |  |  | (54 | ) |  | 19,556 |  |  | 56,725 |  |  | 352 |  |  | 57,077 |  |
| Cost of net revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Products | 12,369 |  |  | 204 |  |  | 12,573 |  |  | 36,206 |  |  | 965 |  |  | 37,171 |  |
| Services | 2,078 |  |  | (315 | ) |  | 1,763 |  |  | 6,245 |  |  | (984 | ) |  | 5,261 |  |
| Total cost of net revenue | 14,447 |  |  | (111 | ) |  | 14,336 |  |  | 42,451 |  |  | (19 | ) |  | 42,432 |  |
| Gross margin | 5,163 |  |  | 57 |  |  | 5,220 |  |  | 14,274 |  |  | 371 |  |  | 14,645 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |
| Selling, general, and administrative | 4,625 |  |  | (66 | ) |  | 4,559 |  |  | 13,989 |  |  | (294 | ) |  | 13,695 |  |
| Research and development | 1,071 |  |  | — |  |  | 1,071 |  |  | 3,297 |  |  | — |  |  | 3,297 |  |
| Total operating expenses | 5,696 |  |  | (66 | ) |  | 5,630 |  |  | 17,286 |  |  | (294 | ) |  | 16,992 |  |
| Operating loss | (533 | ) |  | 123 |  |  | (410 | ) |  | (3,012 | ) |  | 665 |  |  | (2,347 | ) |
| Interest and other, net | (682 | ) |  | — |  |  | (682 | ) |  | (1,800 | ) |  | 1 |  |  | (1,799 | ) |
| Income (loss) before income taxes | (1,215 | ) |  | 123 |  |  | (1,092 | ) |  | (4,812 | ) |  | 666 |  |  | (4,146 | ) |
| Income tax provision (benefit) | (274 | ) |  | 33 |  |  | (241 | ) |  | (1,510 | ) |  | 157 |  |  | (1,353 | ) |
| Net income (loss) | (941 | ) |  | 90 |  |  | (851 | ) |  | (3,302 | ) |  | 509 |  |  | (2,793 | ) |
| Less: Net loss attributable to non-controlling interests | (4 | ) |  | (1 | ) |  | (5 | ) |  | (85 | ) |  | 41 |  |  | (44 | ) |
| Net income (loss) attributable to Dell Technologies Inc. | $ | (937 | ) |  | $ | 91 |  |  | $ | (846 | ) |  | $ | (3,217 | ) |  | $ | 468 |  |  | $ | (2,749 | ) |
| Earnings (loss) per share attributable to Dell Technologies Inc. - basic: |  |  |  |  |  |  |
| Class V Common Stock - basic | $ | 1.10 |  |  | $ | (0.12 | ) |  | $ | 0.98 |  |  | $ | 2.50 |  |  | $ | 0.08 |  |  | $ | 2.58 |  |
| DHI Group - basic | $ | (2.05 | ) |  | $ | 0.21 |  |  | $ | (1.84 | ) |  | $ | (6.57 | ) |  | $ | 0.79 |  |  | $ | (5.78 | ) |
| Earnings (loss) per share attributable to Dell Technologies Inc. - diluted: |  |  |  |  |  |  |
| Class V Common Stock - diluted | $ | 1.09 |  |  | $ | (0.13 | ) |  | $ | 0.96 |  |  | $ | 2.46 |  |  | $ | 0.08 |  |  | $ | 2.54 |  |
| DHI Group - diluted | $ | (2.05 | ) |  | $ | 0.21 |  |  | $ | (1.84 | ) |  | $ | (6.58 | ) |  | $ | 0.79 |  |  | $ | (5.79 | ) |

[0001571996-18-000044:notes:39]
| (a) | Amounts as reported in the Company’s Quarterly Report on Form 10-Q for the quarterly period ended November 3, 2017. |

[0001571996-18-000044:notes:40]
[same as prior period, unchanged from 0001571996-18-000034:notes:60]

[0001571996-18-000044:notes:41]
[same as prior period, unchanged from 0001571996-18-000034:notes:61]

[0001571996-18-000044:notes:42]
[same as prior period, unchanged from 0001571996-18-000034:notes:62]

[0001571996-18-000044:notes:43]
[same as prior period, unchanged from 0001571996-18-000034:notes:63]

[0001571996-18-000044:notes:44]
[same as prior period, unchanged from 0001571996-18-000034:notes:64]

[0001571996-18-000044:notes:45]
[same as prior period, unchanged from 0001571996-18-000034:notes:65]

[0001571996-18-000044:notes:46]
|  | Nine Months Ended |
|  | November 3, 2017 |
|  | As Reported (a) |  | Classification of Certain Cash Receipts and Cash Payments |  | Statement of Cash Flows, Restricted Cash |  | As Recast |
|  | (in millions) |
| Change in cash from operating activities | $ | 3,679 |  |  | $ | 48 |  |  | $ | 17 |  |  | $ | 3,744 |  |
| Change in cash from investing activities | $ | (1,990 | ) |  | $ | — |  |  | $ | — |  |  | $ | (1,990 | ) |
| Change in cash from financing activities | $ | 496 |  |  | $ | (48 | ) |  | $ | 77 |  |  | $ | 525 |  |
| Change in cash, cash equivalents, and restricted cash | $ | 2,232 |  |  | $ | — |  |  | $ | 94 |  |  | $ | 2,326 |  |
| Cash, cash equivalents, and restricted cash at beginning of the period | 9,474 |  |  | — |  |  | 358 |  |  | 9,832 |  |
| Cash, cash equivalents, and restricted cash at end of the period | $ | 11,706 |  |  | $ | — |  |  | $ | 452 |  |  | $ | 12,158 |  |

[0001571996-18-000044:notes:47]
(a) 
Amounts as reported in the Company’s Quarterly Report on Form 10-Q for the quarterly period ended November 3, 2017.


## us-gaap:ScheduleOfNewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0001571996-18-000044:notes:48]
(a) 
Amounts as reported in the Company’s Quarterly Report on Form 10-Q for the quarterly period ended November 3, 2017.The following tables present the impact of the new accounting standards to the Company’s previously reported financial results.

[0001571996-18-000044:notes:49]
(a) 
Amounts as reported in the Company’s Annual Report on Form 10-K for the fiscal year ended February 2, 2018.Selected Captions from the Condensed Consolidated Statement of Cash Flows


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001571996-18-000044:notes:50]
NOTE 2 — INTERIM UPDATE TO SUMMARY OF SIGNIFICANT ACCOUNTING POLICIES

[0001571996-18-000044:notes:51]
[same as prior period, unchanged from 0001571996-18-000034:notes:303]

[0001571996-18-000044:notes:52]
Revenue Recognition — The Company enters into a variety of agreements to provide a wide portfolio of products and services offerings to its customers.  These agreements have varying requirements depending on the goods and services being sold, the rights and obligations conveyed, and the legal jurisdiction of the arrangement.

[0001571996-18-000044:notes:53]
Revenue is recognized either over time or at a point in time, depending on when the underlying goods or services are transferred to the customer, in an amount that reflects the consideration to which the Company expects to be entitled in exchange for delivering those goods or services.  The following five steps are applied to recognize revenue:

[0001571996-18-000044:notes:54]
| (1) | Identify the contract with a customer. The term “contract” refers to the enforceable rights and obligations provided in an agreement between the Company and one or more other parties in exchange for payment. The Company evaluates facts and circumstances regarding sales transactions in order to identify contracts with its customers. An agreement must meet all of the following criteria to qualify as a contract eligible for revenue recognition under the model: (i) the contract must be approved by all parties; (ii) each party’s rights regarding the goods and services to be transferred to the customer can be identified; (iii) the payment terms for the goods and services can be identified; (iv) the customer has the ability and intent to pay and it is probable that the Company will collect substantially all of the consideration to which it will be entitled; and (v) the contract must have commercial substance. Judgment is used in determining the customer’s ability and intent to pay, which is based upon various factors including the customer’s historical payment experience or customer credit and financial information. |

[0001571996-18-000044:notes:55]
| (2) | Identify the performance obligations in the contract. Distinct promises within a contract are referred to as “performance obligations” and are accounted for as separate units of account. The Company assesses whether each promised good or service is distinct for the purpose of identifying the performance obligations in the contract. This assessment involves subjective determinations and requires management to make judgments about the individual promised goods or services and whether such goods or services are separable from the other aspects of the contractual relationship. Promised goods and services are considered distinct provided that: (i) the customer can benefit from the good or service either on its own or together with other resources that are readily available to the customer (that is, the good or service is capable of being distinct); and (ii) the Company’s promise to transfer the good or service to the customer is separately identifiable from other promises in the contract (that is, the promise to transfer the good or service is distinct within the context of the contract). The Company’s performance obligations consist of a variety of products and services offerings which include: hardware, such as servers, storage, networking, personal computers, workstations, and peripherals; third-party software; proprietary software licenses; support and deployment services, which include hardware support that extends beyond the Company’s standard warranties, software maintenance, and installation; professional services; training; software as a service (“SaaS”); and infrastructure as a service (“IaaS”). |

[0001571996-18-000044:notes:56]
| (3) | Determine the transaction price. Transaction price reflects the amount of consideration to which the Company expects to be entitled in exchange for transferring goods or services to the customer. If the consideration promised in a contract includes a variable amount, the Company estimates the amount to which it expects to be entitled using either the expected value or most likely amount method. The Company’s contracts may include terms that could cause variability in the transaction price, including, for example, rebates, sales returns, and volume discounts. In determining the transaction price, any variable consideration would be considered, to the extent applicable, if it is probable that a significant future reversal of cumulative revenue under the contract will not occur when the uncertainty associated with the variable consideration is resolved. |

[0001571996-18-000044:notes:57]
| (4) | Allocate the transaction price to performance obligations in the contract. Many of the Company’s contracts include promises to transfer multiple products and services to a customer, and the transaction price must be allocated to each performance obligation in an amount that depicts the consideration to which the Company expects to be entitled in exchange for transferring the promised goods or services. For these contracts with multiple performance obligations, the transaction price is allocated in proportion to the standalone selling price (“SSP”) of each performance obligation. |

[0001571996-18-000044:notes:58]
If the contract contains a single performance obligation, the entire transaction price is allocated to that performance obligation.

[0001571996-18-000044:notes:59]
The best evidence of SSP is the observable price of a good or service when the Company sells that good or service separately in similar circumstances to similar customers.  If a directly observable price is available, it must be utilized for the SSP.  If a directly observable price is not available, the SSP must be estimated.  The Company estimates SSP by considering multiple factors including, but not limited to, pricing practices, internal costs, and profit objectives as well as overall market conditions which include geographic or regional specific factors, competitive positioning, and competitor actions.  SSP can include fixed and variable components.  Variable components are estimated based on the most likely outcome or expected value of the variable components.

[0001571996-18-000044:notes:60]
| (5) | Recognize revenue when (or as) the performance obligation is satisfied. Revenue is recognized when obligations under the terms of the contract with the Company’s customer are satisfied. Revenue is recognized either over time or at a point in time, depending on when the underlying products or services are transferred to the customer. Revenue is recognized at a point in time for products upon transfer of control. Revenue is recognized over time for support and deployment services, professional services, training, software support, SaaS, and IaaS. |

[0001571996-18-000044:notes:61]
The Company reports revenue net of any revenue-based taxes assessed by governmental authorities that are imposed on and concurrently with specific revenue-producing transactions.

[0001571996-18-000044:notes:62]
The Company has elected the following practical expedients with the adoption of the new revenue standard:

[0001571996-18-000044:notes:63]
| • | The Company does not account for significant financing components if the period between revenue recognition and when the customer pays for the product or service will be one year or less. |

[0001571996-18-000044:notes:64]
| • | The Company recognizes revenue equal to the amount it has a right to invoice when the amount corresponds directly with the value to the customer of the Company’s performance to date. |

[0001571996-18-000044:notes:65]
| • | The Company does not account for shipping and handling activities as a separate performance obligation, but rather as an activity performed to transfer the promised good. |

[0001571996-18-000044:notes:66]
The following summarizes the nature of revenue recognized and the manner in which the Company accounts for sales transactions.

[0001571996-18-000044:notes:67]
Products

[0001571996-18-000044:notes:68]
Product revenue consists of hardware and software license sales that are delivered, sold as a subscription or sold on a consumption basis.  Hardware includes notebooks and desktop PCs, servers, storage hardware, and other hardware-related devices.  Software license sales include non-essential, stand-alone software applications.  Software applications provide customers with resource management, backup and archiving, information security, information management and intelligence, data analytics, and server virtualization capabilities.

[0001571996-18-000044:notes:69]
Revenue from the sale of hardware products is recognized when control has transferred to the customer, which typically occurs when the hardware has been shipped to the customer, risk of loss has transferred to the customer, the Company has a present right to payment, and customer acceptance has been satisfied.  Customer acceptance is satisfied if acceptance is obtained from the customer, if all acceptance provisions lapse, or if the Company has evidence that all acceptance provisions will be, or have been, satisfied.  Revenue from software license sales is generally recognized when control has transferred to the customer, which is typically upon shipment, electronic delivery, or when the software is available for download by the customer.  For certain arrangements, including software subscriptions and certain software license agreements which provide customers control to certain product performance obligations over time, revenue is recognized based on usage or ratably over the term of the arrangement based on the pattern of delivery of the product to the customer.

[0001571996-18-000044:notes:70]
Invoices for products are generally issued as control transfers, which is typically upon shipment or electronic delivery.  There was no significant revenue in any period presented related to performance obligations satisfied or partially satisfied in prior periods.

[0001571996-18-000044:notes:71]
Services

[0001571996-18-000044:notes:72]
Services revenue consists of revenue from sales of support services, including hardware support that extends beyond the Company’s standard warranties, software maintenance, and installation; professional services; training; SaaS; and IaaS.  Revenue associated with undelivered performance obligations is deferred and recorded as control is transferred to the customer over time.  Revenue from fixed-price support or maintenance contracts sold for both hardware and software is recognized on a straight-line basis over the period of performance because the Company is required to provide services at any given time.  Other services revenue is recognized when the Company performs the services and the customers receive and consume the benefits.

[0001571996-18-000044:notes:73]
Invoices for services may be issued at the start of a service term, which is typically the case for support and deployment services, or as services are rendered, which is typically the case for professional services, training, SaaS, and IaaS.

[0001571996-18-000044:notes:74]
Other

[0001571996-18-000044:notes:75]
Revenue from leasing arrangements is not subject to the revenue standard for contracts with customers, and remains separately accounted for under existing lease accounting guidance.  The Company records revenue from the sale of equipment under sales-type leases as product revenue in an amount equal to the present value of minimum lease payments at the inception of the lease.  Sales-type leases also produce financing income, which is included in products net revenue in the Consolidated Statements of Income (Loss) and is recognized at consistent rates of return over the lease term.  The Company also offers qualified customers fixed-term loans and revolving credit lines for the purchase of products and services offered by the Company.  Financing income attributable to these loans is recognized in products net revenue on an accrual basis.

[0001571996-18-000044:notes:76]
Disaggregation of Revenue — The Company’s revenue is presented on a disaggregated basis on the Condensed Consolidated Statements of Income (Loss) and in Note 18 of the Notes to the Condensed Consolidated Financial Statements based on an evaluation of disclosures outside of the financial statements, information regularly reviewed by the chief operating decision maker for evaluating the financial performance of operating segments, and other information that is used to evaluate the Company’s financial performance or make resource allocations.  This information includes revenue from products and services, revenue from reportable segments, and revenue by major product categories within the segments.

[0001571996-18-000044:notes:77]
Contract Assets — Contract assets are rights to consideration in exchange for goods or services that the Company has transferred to a customer when such a right is conditional on something other than the passage of time.  Such amounts have been insignificant to date.

[0001571996-18-000044:notes:78]
Contract Liabilities — Contract liabilities primarily consist of deferred revenue.  Deferred revenue is recorded when the Company has a right to invoice or payments have been received for undelivered products or services, or in situations where revenue recognition criteria have not been met.  Deferred revenue also represents amounts received in advance for extended warranty services and software maintenance.  Revenue is recognized on these items when the revenue recognition criteria are met, generally resulting in ratable recognition over the contract term.  The Company also has deferred revenue related to undelivered hardware and professional services, consisting of installations and consulting engagements, which are recognized as the Company’s performance obligations under the contract are completed.  See Note 9 of the Notes to the Condensed Consolidated Financial Statements for additional information about deferred revenue.

[0001571996-18-000044:notes:79]
Costs to Obtain a Contract — The incremental direct costs of obtaining a contract primarily consist of sales commissions and employer taxes related to commission payments.  The Company has elected, as a practical expedient, to expense as incurred costs to obtain a contract equal to or less than one year in duration.  For contracts greater than one year in duration, the associated costs to obtain a contract are deferred and amortized over the period of contract performance or a longer period, generally the estimated life of the customer relationship, if renewals are expected and the renewal commission is not commensurate with the initial commission.  Deferred costs to obtain a contract are typically amortized over a period of three to seven years, depending on the contract term and expectation of the period of benefit for the costs, which may exceed the contract term.  Amortization expense is recognized on a straight-line basis and included in selling, general, and administrative expenses in the Condensed Consolidated Statements of Income (Loss).

[0001571996-18-000044:notes:80]
The Company periodically reviews these deferred costs to determine whether events or changes in circumstances have occurred that could impact the carrying value or period of benefit of the deferred sales commissions.  There were no material impairment losses for deferred sales commissions during the nine months ended November 2, 2018 and November 3, 2017.

[0001571996-18-000044:notes:81]
Deferred costs to obtain a contract as of November 2, 2018 and February 2, 2018 were $1.1 billion and $0.8 billion, respectively.  Deferred costs to obtain a contract are classified as current assets and other non-current assets on the Condensed Consolidated Statements of Financial Position, based on when the expense is expected to be recognized.  Amortization of costs to obtain a contract during the three months ended November 2, 2018 and November 3, 2017 was $145 million and $89 million, respectively.  Amortization of costs to obtain a contract during the nine months ended November 2, 2018 and November 3, 2017 was $364 million and $204 million, respectively.


## us-gaap:FairValueDisclosuresTextBlock

[0001571996-18-000044:notes:82]
NOTE 3 — FAIR VALUE MEASUREMENTS

[0001571996-18-000044:notes:83]
The following table presents the Company’s hierarchy for its assets and liabilities measured at fair value on a recurring basis as of November 2, 2018 and February 2, 2018:

[0001571996-18-000044:notes:84]
|  | November 2, 2018 (a) |  | February 2, 2018 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | QuotedPricesin ActiveMarkets forIdenticalAssets |  | SignificantOtherObservableInputs |  | SignificantUnobservableInputs |  |  |  | QuotedPricesin ActiveMarkets forIdenticalAssets |  | SignificantOtherObservableInputs |  | SignificantUnobservableInputs |  |  |
|  | (in millions) |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | $ | 12,166 |  |  | $ | — |  |  | $ | — |  |  | $ | 12,166 |  |  | $ | 8,641 |  |  | $ | — |  |  | $ | — |  |  | $ | 8,641 |  |
| U.S. corporate debt securities | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 23 |  |  | — |  |  | 23 |  |
| Foreign corporate debt securities | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 65 |  |  | — |  |  | 65 |  |
| Debt securities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. government and agencies | 434 |  |  | 270 |  |  | — |  |  | 704 |  |  | 682 |  |  | 392 |  |  | — |  |  | 1,074 |  |
| U.S. corporate | — |  |  | 1,649 |  |  | — |  |  | 1,649 |  |  | — |  |  | 2,003 |  |  | — |  |  | 2,003 |  |
| Foreign | — |  |  | 1,942 |  |  | — |  |  | 1,942 |  |  | — |  |  | 2,547 |  |  | — |  |  | 2,547 |  |
| Equity and other securities | 373 |  |  | 16 |  |  | — |  |  | 389 |  |  | 236 |  |  | 5 |  |  | — |  |  | 241 |  |
| Derivative instruments | — |  |  | 253 |  |  | — |  |  | 253 |  |  | — |  |  | 83 |  |  | — |  |  | 83 |  |
| Total assets | $ | 12,973 |  |  | $ | 4,130 |  |  | $ | — |  |  | $ | 17,103 |  |  | $ | 9,559 |  |  | $ | 5,118 |  |  | $ | — |  |  | $ | 14,677 |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Derivative instruments | $ | — |  |  | $ | 18 |  |  | $ | — |  |  | $ | 18 |  |  | $ | — |  |  | $ | 184 |  |  | $ | — |  |  | $ | 184 |  |
| Total liabilities | $ | — |  |  | $ | 18 |  |  | $ | — |  |  | $ | 18 |  |  | $ | — |  |  | $ | 184 |  |  | $ | — |  |  | $ | 184 |  |

[0001571996-18-000044:notes:85]
(a)   The Company did not transfer any securities between levels during the nine months ended November 2, 2018.

[0001571996-18-000044:notes:86]
[same as prior period, unchanged from 0001571996-18-000034:notes:163]

[0001571996-18-000044:notes:87]
Money Market Funds — The Company’s investment in money market funds that are classified as cash equivalents hold underlying investments with a weighted average maturity of 90 days or less and are recognized at fair value.  The valuations of these securities are based on quoted prices in active markets for identical assets, when available, or pricing models whereby all significant inputs are observable or can be derived from or corroborated by observable market data.  The Company reviews security pricing and assesses liquidity on a quarterly basis.  As of November 2, 2018, the Company’s U.S. portfolio had no material exposure to money market funds with a fluctuating net asset value.

[0001571996-18-000044:notes:88]
Equity and Other Securities — The majority of the Company’s investments in equity and other securities that are measured at fair value on a recurring basis consist of strategic investments in publicly-traded companies.  The valuation of these securities is based on quoted prices in active markets.

[0001571996-18-000044:notes:89]
Debt Securities — The majority of the Company’s debt securities consists of various fixed income securities such as U.S. government and agencies, U.S. corporate, and foreign.  Valuation is based on pricing models whereby all significant inputs, including benchmark yields, reported trades, broker-dealer quotes, issue spreads, benchmark securities, bids, offers, and other market related data, are observable or can be derived from or corroborated by observable market data for substantially the full term of the asset.  Inputs are documented in accordance with the fair value measurements hierarchy.  The Company reviews security pricing and assesses liquidity on a quarterly basis.  See Note 4 of the Notes to the Condensed Consolidated Financial Statements for additional information about investments.

[0001571996-18-000044:notes:90]
Derivative Instruments — The Company’s derivative financial instruments consist primarily of foreign currency forward and purchased option contracts and interest rate swaps.  The fair value of the portfolio is determined using valuation models based on market observable inputs, including interest rate curves, forward and spot prices for currencies, and implied volatilities.  Credit risk is also factored into the fair value calculation of the Company’s derivative instrument portfolio.  See Note 7 of the Notes to the Condensed Consolidated Financial Statements for a description of the Company’s derivative financial instrument activities.

[0001571996-18-000044:notes:91]
[same as prior period, unchanged from 0001571996-18-000034:notes:168]

[0001571996-18-000044:notes:92]
As of November 2, 2018 and February 2, 2018, the Company held strategic investments of $610 million and $485 million, respectively.  As these investments represent early-stage companies without readily determinable fair values, they are not included in the recurring fair value table above.

[0001571996-18-000044:notes:93]
The Company has elected to apply the measurement alternative for these investments.  Under the alternative, the Company measures investments without readily determinable fair values at cost, less impairment, adjusted by observable price changes.  The Company must make a separate election to use the alternative for each eligible investment and is required to reassess at each reporting period whether an investment qualifies for the alternative.  In evaluating these investments for impairment or observable price changes, the Company uses inputs including pre- and post-money valuations of recent financing events and the impact of those on its fully diluted ownership percentages, as well as other available information regarding the issuer’s historical and forecasted performance.

[0001571996-18-000044:notes:94]
Carrying Value and Estimated Fair Value of Outstanding Debt — The following table summarizes the carrying value and estimated fair value of the Company’s outstanding debt as described in Note 6 of the Notes to the Condensed Consolidated Financial Statements, including the current portion, as of the dates indicated:

[0001571996-18-000044:notes:95]
|  | November 2, 2018 |  | February 2, 2018 |
|  | Carrying Value |  | Fair Value |  | Carrying Value |  | Fair Value |
|  | (in billions) |
| Senior Secured Credit Facilities | $ | 9.0 |  |  | $ | 9.2 |  |  | $ | 10.4 |  |  | $ | 10.6 |  |
| First Lien Notes | $ | 19.8 |  |  | $ | 20.9 |  |  | $ | 19.7 |  |  | $ | 21.9 |  |
| Unsecured Notes and Debentures | $ | 1.8 |  |  | $ | 1.9 |  |  | $ | 2.3 |  |  | $ | 2.5 |  |
| Senior Notes | $ | 3.1 |  |  | $ | 3.4 |  |  | $ | 3.1 |  |  | $ | 3.4 |  |
| EMC Notes | $ | 3.0 |  |  | $ | 2.9 |  |  | $ | 5.5 |  |  | $ | 5.4 |  |
| VMware Notes | $ | 4.0 |  |  | $ | 3.8 |  |  | $ | 4.0 |  |  | $ | 3.9 |  |
| Margin Loan Facility | $ | 2.0 |  |  | $ | 2.0 |  |  | $ | 2.0 |  |  | $ | 2.0 |  |

[0001571996-18-000044:notes:96]
The fair values of the outstanding debt shown in the table above, as well as the DFS debt described in Note 5 of the Notes to the Condensed Consolidated Financial Statements, were determined based on observable market prices in a less active market or based on valuation methodologies using observable inputs and were categorized as Level 2 in the fair value hierarchy.  The carrying value of DFS debt approximates fair value.


## invest:InvestmentTextBlock

[0001571996-18-000044:notes:97]
NOTE 4 — INVESTMENTS

[0001571996-18-000044:notes:98]
The following table summarizes, by major security type, the carrying value and amortized cost of the Company’s investments.  All debt security investments with remaining effective maturities in excess of one year and substantially all equity and other securities are recorded as long-term investments in the Condensed Consolidated Statements of Financial Position.

[0001571996-18-000044:notes:99]
|  | November 2, 2018 |  | February 2, 2018 |
|  | Cost |  | Unrealized Gain |  | Unrealized (Loss) |  | Carrying Value |  | Cost |  | Unrealized Gain |  | Unrealized (Loss) |  | Carrying Value |
|  | (in millions) |
| Investments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. government and agencies | $ | 395 |  |  | $ | — |  |  | $ | (3 | ) |  | $ | 392 |  |  | $ | 485 |  |  | $ | — |  |  | $ | (2 | ) |  | $ | 483 |  |
| U.S. corporate debt securities | 778 |  |  | — |  |  | (4 | ) |  | 774 |  |  | 660 |  |  | — |  |  | (2 | ) |  | 658 |  |
| Foreign debt securities | 1,162 |  |  | — |  |  | (6 | ) |  | 1,156 |  |  | 1,048 |  |  | — |  |  | (2 | ) |  | 1,046 |  |
| Total short-term investments | 2,335 |  |  | — |  |  | (13 | ) |  | 2,322 |  |  | 2,193 |  |  | — |  |  | (6 | ) |  | 2,187 |  |
| U.S. government and agencies | 320 |  |  | — |  |  | (8 | ) |  | 312 |  |  | 600 |  |  | — |  |  | (9 | ) |  | 591 |  |
| U.S. corporate debt securities | 897 |  |  | — |  |  | (22 | ) |  | 875 |  |  | 1,361 |  |  | — |  |  | (16 | ) |  | 1,345 |  |
| Foreign debt securities | 805 |  |  | — |  |  | (19 | ) |  | 786 |  |  | 1,518 |  |  | — |  |  | (17 | ) |  | 1,501 |  |
| Equity and other securities (a) | 731 |  |  | 389 |  |  | (121 | ) |  | 999 |  |  | 640 |  |  | 86 |  |  | — |  |  | 726 |  |
| Total long-term investments | 2,753 |  |  | 389 |  |  | (170 | ) |  | 2,972 |  |  | 4,119 |  |  | 86 |  |  | (42 | ) |  | 4,163 |  |
| Total investments | $ | 5,088 |  |  | $ | 389 |  |  | $ | (183 | ) |  | $ | 5,294 |  |  | $ | 6,312 |  |  | $ | 86 |  |  | $ | (48 | ) |  | $ | 6,350 |  |

[0001571996-18-000044:notes:100]
| (a) | $610 million and $485 million of equity and other securities as of November 2, 2018 and February 2, 2018, respectively, are private strategic investments without readily determinable fair values, which are recorded at cost, less impairment, and adjusted for observable price changes. For the the nine months ended November 2, 2018, the equity and other securities without readily determinable fair values increased by $116 million due to upward adjustments for observable price changes offset by $30 million of downward adjustments that were primarily attributable to impairments. The remainder of equity and other securities consists of publicly-traded investments that are measured at fair value on a recurring basis. See Note 3 of the Notes to the Condensed Consolidated Financial Statements for additional information on investments measured at fair value. |

[0001571996-18-000044:notes:101]
The Company’s investments in debt securities are classified as available-for-sale securities, which are carried at fair value.  As of November 2, 2018, the aggregate fair value of investments held in a continuous unrealized loss position for greater than 12 months was $2.5 billion, and the unrealized loss on these investments was $41 million.  As of February 2, 2018, the aggregate fair value of investments held in a continuous unrealized loss position for greater than 12 months was $1.9 billion, and the unrealized loss on these investments was $25 million.

[0001571996-18-000044:notes:102]
The maturities of debt securities held as of November 2, 2018 are as follows:

[0001571996-18-000044:notes:103]
|  | Carrying Value |  | Amortized Cost |
|  | (in millions) |
| Due within one year | $ | 2,322 |  |  | $ | 2,335 |  |
| Due after 1 year through 5 years | 1,932 |  |  | 1,980 |  |
| Due after 5 years through 10 years | 41 |  |  | 42 |  |
| Total | $ | 4,295 |  |  | $ | 4,357 |  |


## us-gaap:LoansNotesTradeAndOtherReceivablesDisclosureTextBlock

[0001571996-18-000044:notes:104]
NOTE 5 — FINANCIAL SERVICES

[0001571996-18-000044:notes:105]
The Company offers or arranges various financing options and services for its customers in North America, Europe, Australia, and New Zealand through Dell Financial Services and its affiliates (“DFS”).  The key activities of DFS include originating, collecting, and servicing customer receivables primarily related to the purchase of Dell Technologies products and services.  In some cases, DFS also offers financing on the purchase of third-party technology products that complement the Dell Technologies portfolio of products and services.  New financing originations were $1.6 billion for both the three months ended November 2, 2018 and November 3, 2017, respectively, and were $5.2 billion and $4.3 billion for the nine months ended November 2, 2018 and November 3, 2017, respectively.

[0001571996-18-000044:notes:106]
[same as prior period, unchanged from 0001571996-18-000034:notes:204]

[0001571996-18-000044:notes:107]
The Company’s financing receivables are aggregated into the following categories:

[0001571996-18-000044:notes:108]
| • | Revolving loans — Revolving loans offered under private label credit financing programs provide qualified customers with a revolving credit line for the purchase of products and services offered by Dell Technologies. These private label credit financing programs are referred to as Dell Preferred Account (“DPA”) and Dell Business Credit (“DBC”). The DPA product is primarily offered to individual consumer customers, and the DBC product is primarily offered to small and medium-sized commercial customers. Revolving loans in the United States bear interest at a variable annual percentage rate that is tied to the prime rate. Based on historical payment patterns, revolving loan transactions are typically repaid within twelve months on average. |

[0001571996-18-000044:notes:109]
| • | Fixed-term sales-type leases and loans — The Company enters into sales-type lease arrangements with customers who seek lease financing. Leases with business customers have fixed terms of generally two to four years. Future maturities of minimum lease and associated financing payments as of November 2, 2018 were as follows: Fiscal 2019 - $781 million; Fiscal 2020 - $2,112 million; Fiscal 2021 - $1,393 million; Fiscal 2022 - $610 million; Fiscal 2023 and beyond - $216 million. Future maturities and associated financing payments referenced herein represent the aggregate payments under the customer lease contract. The Company also offers fixed-term loans to qualified small businesses, large commercial accounts, governmental organizations, educational entities, and certain individual consumer customers. These loans are repaid in equal payments including interest and have defined terms of generally three to five years. |

[0001571996-18-000044:notes:110]
The following table summarizes the components of the Company’s financing receivables segregated by portfolio segment as of November 2, 2018 and February 2, 2018:

[0001571996-18-000044:notes:111]
|  | November 2, 2018 |  | February 2, 2018 |
|  | Revolving |  | Fixed-term |  | Total |  | Revolving |  | Fixed-term |  | Total |
|  | (in millions) |
| Financing receivables, net: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer receivables, gross (a) | $ | 804 |  |  | $ | 6,740 |  |  | $ | 7,544 |  |  | $ | 900 |  |  | $ | 6,282 |  |  | $ | 7,182 |  |
| Allowances for losses | (73 | ) |  | (53 | ) |  | (126 | ) |  | (81 | ) |  | (64 | ) |  | (145 | ) |
| Customer receivables, net | 731 |  |  | 6,687 |  |  | 7,418 |  |  | 819 |  |  | 6,218 |  |  | 7,037 |  |
| Residual interest | — |  |  | 662 |  |  | 662 |  |  | — |  |  | 606 |  |  | 606 |  |
| Financing receivables, net | $ | 731 |  |  | $ | 7,349 |  |  | $ | 8,080 |  |  | $ | 819 |  |  | $ | 6,824 |  |  | $ | 7,643 |  |
| Short-term | $ | 731 |  |  | $ | 3,403 |  |  | $ | 4,134 |  |  | $ | 819 |  |  | $ | 3,100 |  |  | $ | 3,919 |  |
| Long-term | $ | — |  |  | $ | 3,946 |  |  | $ | 3,946 |  |  | $ | — |  |  | $ | 3,724 |  |  | $ | 3,724 |  |

[0001571996-18-000044:notes:112]
[same as prior period, unchanged from 0001571996-18-000034:notes:210]

[0001571996-18-000044:notes:113]
The following tables present the allowance for financing receivable losses for the three months ended November 2, 2018 and November 3, 2017, and the nine months ended November 2, 2018 and November 3, 2017, and changes in allowance for financing receivable losses for the respective periods:

[0001571996-18-000044:notes:114]
|  | Three Months Ended |
|  | November 2, 2018 |  | November 3, 2017 |
|  | Revolving |  | Fixed-term |  | Total |  | Revolving |  | Fixed-term |  | Total |
|  | (in millions) |
| Allowance for financing receivable losses: |
| Balances at beginning of period | $ | 75 |  |  | $ | 51 |  |  | $ | 126 |  |  | $ | 81 |  |  | $ | 54 |  |  | $ | 135 |  |
| Charge-offs, net of recoveries | (19 | ) |  | (4 | ) |  | (23 | ) |  | (21 | ) |  | (5 | ) |  | (26 | ) |
| Provision charged to income statement | 17 |  |  | 6 |  |  | 23 |  |  | 19 |  |  | 3 |  |  | 22 |  |
| Balances at end of period | $ | 73 |  |  | $ | 53 |  |  | $ | 126 |  |  | $ | 79 |  |  | $ | 52 |  |  | $ | 131 |  |

[0001571996-18-000044:notes:115]
|  | Nine Months Ended |
|  | November 2, 2018 |  | November 3, 2017 |
|  | Revolving |  | Fixed-term |  | Total |  | Revolving |  | Fixed-term |  | Total |
|  | (in millions) |
| Allowance for financing receivable losses: |  |  |  |  |  |  |  |  |  |  |  |
| Balances at beginning of period | $ | 81 |  |  | $ | 64 |  |  | $ | 145 |  |  | $ | 91 |  |  | $ | 52 |  |  | $ | 143 |  |
| Charge-offs, net of recoveries | (58 | ) |  | (21 | ) |  | (79 | ) |  | (63 | ) |  | (13 | ) |  | (76 | ) |
| Provision charged to income statement | 50 |  |  | 10 |  |  | 60 |  |  | 51 |  |  | 13 |  |  | 64 |  |
| Balances at end of period | $ | 73 |  |  | $ | 53 |  |  | $ | 126 |  |  | $ | 79 |  |  | $ | 52 |  |  | $ | 131 |  |

[0001571996-18-000044:notes:116]
The following table summarizes the aging of the Company’s customer financing receivables, gross, including accrued interest, as of November 2, 2018 and February 2, 2018, segregated by class:

[0001571996-18-000044:notes:117]
|  | November 2, 2018 |  | February 2, 2018 |
|  | Current |  | Past Due1 — 90 Days |  | Past Due>90 Days |  | Total |  | Current |  | Past Due1 — 90 Days |  | Past Due>90 Days |  | Total |
|  | (in millions) |
| Revolving — DPA | $ | 560 |  |  | $ | 53 |  |  | $ | 22 |  |  | $ | 635 |  |  | $ | 633 |  |  | $ | 59 |  |  | $ | 23 |  |  | $ | 715 |  |
| Revolving — DBC | 147 |  |  | 18 |  |  | 4 |  |  | 169 |  |  | 162 |  |  | 19 |  |  | 4 |  |  | 185 |  |
| Fixed-term — Consumer and Commercial | 5,910 |  |  | 719 |  |  | 111 |  |  | 6,740 |  |  | 5,414 |  |  | 775 |  |  | 93 |  |  | 6,282 |  |
| Total customer receivables, gross | $ | 6,617 |  |  | $ | 790 |  |  | $ | 137 |  |  | $ | 7,544 |  |  | $ | 6,209 |  |  | $ | 853 |  |  | $ | 120 |  |  | $ | 7,182 |  |

[0001571996-18-000044:notes:118]
[same as prior period, unchanged from 0001571996-18-000034:notes:213]

[0001571996-18-000044:notes:119]
[same as prior period, unchanged from 0001571996-18-000034:notes:214]

[0001571996-18-000044:notes:120]
The following table summarizes customer receivables, gross, including accrued interest, by credit quality indicator segregated by class, as of November 2, 2018 and February 2, 2018.  The categories shown in the table below segregate customer receivables based on the relative degrees of credit risk.  The credit quality indicators for DPA revolving accounts are measured primarily as of each quarter-end date, while all other indicators are generally updated on a periodic basis.

[0001571996-18-000044:notes:121]
For DPA revolving receivables shown in the table below, the Company makes credit decisions based on proprietary scorecards, which include the customer’s credit history, payment history, credit usage, and other credit agency-related elements.  The higher quality category includes prime accounts generally of a higher credit quality that are comparable to U.S. customer FICO scores of 720 or above.  The mid-category represents the mid-tier accounts that are comparable to U.S. customer FICO scores from 660 to 719.  The lower category is generally sub-prime and represents lower credit quality accounts that are comparable to U.S. customer FICO scores below 660.  For the DBC revolving receivables and fixed-term commercial receivables shown in the table below, an internal grading system is utilized that assigns a credit level score based on a number of considerations, including liquidity, operating performance, and industry outlook.  The grading criteria and classifications for the fixed-term products differ from those for the revolving products as loss experience varies between these product and customer groups.  The credit quality categories cannot be compared between the different classes as loss experience varies substantially between the classes.

[0001571996-18-000044:notes:122]
|  | November 2, 2018 |  | February 2, 2018 |
|  | Higher |  | Mid |  | Lower |  | Total |  | Higher |  | Mid |  | Lower |  | Total |
|  | (in millions) |
| Revolving — DPA | $ | 122 |  |  | $ | 187 |  |  | $ | 326 |  |  | $ | 635 |  |  | $ | 131 |  |  | $ | 223 |  |  | $ | 361 |  |  | $ | 715 |  |
| Revolving — DBC | $ | 44 |  |  | $ | 50 |  |  | $ | 75 |  |  | $ | 169 |  |  | $ | 48 |  |  | $ | 58 |  |  | $ | 79 |  |  | $ | 185 |  |
| Fixed-term — Consumer and Commercial | $ | 3,640 |  |  | $ | 1,894 |  |  | $ | 1,206 |  |  | $ | 6,740 |  |  | $ | 3,334 |  |  | $ | 1,828 |  |  | $ | 1,120 |  |  | $ | 6,282 |  |

[0001571996-18-000044:notes:123]
DFS Debt

[0001571996-18-000044:notes:124]
The Company maintains programs that facilitate the funding of financing receivables in the capital markets. The following table summarizes DFS debt as of the periods indicated.  The table excludes the allocated portion of the Company’s other borrowings, which represents the additional amount considered to fund the DFS business.

[0001571996-18-000044:notes:125]
|  | November 2, 2018 |  | February 2, 2018 |
|  | (in millions) |
| DFS U.S. debt |  |  |  |
| Securitization facilities | $ | 1,649 |  |  | $ | 1,498 |  |
| Fixed-term securitization offerings | 2,683 |  |  | 2,034 |  |
| Other | 186 |  |  | 32 |  |
| Total DFS U.S. debt | 4,518 |  |  | 3,564 |  |
| DFS international debt |  |  |  |
| Securitization facility | 524 |  |  | 404 |  |
| Other structured facilities | 702 |  |  | 628 |  |
| Note payable | 193 |  |  | 200 |  |
| Total DFS international debt | 1,419 |  |  | 1,232 |  |
| Total DFS debt | $ | 5,937 |  |  | $ | 4,796 |  |
| Total short-term DFS debt | $ | 3,288 |  |  | $ | 3,327 |  |
| Total long-term DFS debt | $ | 2,649 |  |  | $ | 1,469 |  |

[0001571996-18-000044:notes:126]
[same as prior period, unchanged from 0001571996-18-000034:notes:217]

[0001571996-18-000044:notes:127]
Securitization Facilities — The Company maintains separate securitization facilities in the United States for fixed-term leases and loans and revolving loans.  This debt is collateralized solely by the U.S. financing receivables in the facilities.  The debt has a variable interest rate and the duration of this debt is based on the terms of the underlying financing receivables.  As of November 2, 2018, the total debt capacity related to the U.S. securitization facilities was $3.5 billion.  The Company enters into interest swap agreements to effectively convert a portion of its securitization debt from a floating rate to a fixed rate.  See Note 7 of the Notes to the Condensed Consolidated Financial Statements for additional information about interest rate swaps.

[0001571996-18-000044:notes:128]
The Company’s U.S. securitization facility for revolving loans is effective through June 1, 2020.  The Company’s two U.S. securitization facilities for fixed-term leases and loans are effective through February 10, 2020 and February 22, 2020.

[0001571996-18-000044:notes:129]
The securitization facilities contain standard structural features related to the performance of the securitized receivables, which include defined credit losses, delinquencies, average credit scores, and minimum collection requirements.  In the event one or more of these criteria are not met and the Company is unable to restructure the facility, no further funding of receivables will be permitted and the timing of the Company’s expected cash flows from over-collateralization will be delayed.  As of November 2, 2018, these criteria were met.

[0001571996-18-000044:notes:130]
Fixed-Term Securitization Offerings — The Company periodically issues asset-backed debt securities under fixed-term securitization programs to private investors.  The asset-backed debt securities are collateralized solely by the U.S. fixed-term financing receivables in the offerings, which are held by Special Purpose Entities (“SPEs”), as discussed below.  The interest rate on these securities is fixed and ranges from 0.85% to 3.97% per annum, and the duration of these securities is based on the terms of the underlying financing receivables.

[0001571996-18-000044:notes:131]
[same as prior period, unchanged from 0001571996-18-000034:notes:222]

[0001571996-18-000044:notes:132]
Securitization Facility — The Company maintains a securitization facility in Europe for fixed-term leases and loans.  As of November 2, 2018, this facility was effective through January 13, 2019, and the total debt capacity of the facility was $684 million.  On November 30, 2018, the Company renewed this facility, which is now effective through December 21, 2020 and has an expanded total debt capacity of $913 million.

[0001571996-18-000044:notes:133]
The securitization facility contains standard structural features related to the performance of the securitized receivables which include defined credit losses, delinquencies, average credit scores, and minimum collection requirements.  In the event one or more of these criteria are not met and the Company is unable to restructure the program, no further funding of receivables will be permitted and the timing of the Company’s expected cash flows from over-collateralization will be delayed.  As of November 2, 2018, these criteria were met.

[0001571996-18-000044:notes:134]
Other Structured Facilities — In connection with the Company’s international financing operations, the Company has entered into revolving structured financing debt programs related to its fixed-term lease and loan products sold in Canada, Europe, Australia, and New Zealand.  The Canadian facility, which is collateralized solely by Canadian financing receivables, had a total debt capacity of $191 million as of November 2, 2018, and is effective through January 16, 2023.  The European facility, which is collateralized solely by European financing receivables, had a total debt capacity of $456 million as of November 2, 2018, and is effective through December 14, 2020.  On November 30, 2018, the European facility’s total debt capacity was increased to $684 million.  The Australia and New Zealand facility, which is collateralized solely by the Australia and New Zealand financing receivables, had a total debt capacity of $130 million as of November 2, 2018, and is effective through January 29, 2020.

[0001571996-18-000044:notes:135]
Note Payable — On November 27, 2017, the Company entered into an unsecured credit agreement to fund receivables in Mexico.  As of November 2, 2018, the aggregate principal amount of the note payable is $193 million.  The note bears interest at either the applicable London interbank offered rate (“LIBOR”) plus 2.25%, for the borrowings denominated in U.S. dollars, or the Mexican Interbank Equilibrium Interest Rate (“TIIE”) plus 2.00%, for the borrowings denominated in Mexican pesos.  The note will mature on December 1, 2020.  Although the note is unsecured, the Company intends to manage the note in the same manner as its structured financing programs, so that the collections from financing receivables in Mexico will be used to pay down principal and interest of the note.

[0001571996-18-000044:notes:136]
[same as prior period, unchanged from 0001571996-18-000034:notes:227]

[0001571996-18-000044:notes:137]
In connection with the securitization facilities and offerings discussed above, the Company transfers certain U.S. and European customer financing receivables to SPEs that meet the definition of a Variable Interest Entity (“VIE”) and are consolidated, along with the associated debt, into the Consolidated Financial Statements, as the Company is the primary beneficiary of those VIEs.  The SPEs are bankruptcy-remote legal entities with separate assets and liabilities.  The purpose of the SPEs is to facilitate the funding of customer receivables in the capital markets.

[0001571996-18-000044:notes:138]
[same as prior period, unchanged from 0001571996-18-000034:notes:229]

[0001571996-18-000044:notes:139]
|  | November 2, 2018 |  | February 2, 2018 |
|  | (in millions) |
| Financing receivables held by consolidated VIEs, net: |  |  |  |  |  |
| Short-term, net | $ | 2,908 |  |  | $ | 2,572 |  |
| Long-term, net | 2,570 |  |  | 1,981 |  |
| Financing receivables held by consolidated VIEs, net | $ | 5,478 |  |  | $ | 4,553 |  |

[0001571996-18-000044:notes:140]
Financing receivables transferred via securitization through SPEs were $1.2 billion and $1.0 billion for the three months ended November 2, 2018 and November 3, 2017, respectively, and $3.7 billion and $2.9 billion for the nine months ended November 2, 2018 and November 3, 2017, respectively.

[0001571996-18-000044:notes:141]
Some of the SPEs have entered into financing arrangements with multi-seller conduits that, in turn, issue asset-backed debt securities in the capital markets.  The DFS debt outstanding, which is collateralized by the financing receivables held by the consolidated VIEs, was $4.9 billion and $3.9 billion as of November 2, 2018 and February 2, 2018, respectively.  The Company’s risk of loss related to securitized receivables is limited to the amount by which the Company’s right to receive collections for assets securitized exceeds the amount required to pay interest, principal, and fees and expenses related to the asset-backed securities.  The Company provides credit enhancement to the securitization in the form of over-collateralization.

[0001571996-18-000044:notes:142]
[same as prior period, unchanged from 0001571996-18-000034:notes:233]

[0001571996-18-000044:notes:143]
To manage certain concentrations of customer credit exposure, the Company may sell selected fixed-term financing receivables to unrelated third parties on a periodic basis.  The amount of financing receivables sold was $590 million and $541 million for the nine months ended November 2, 2018 and November 3, 2017, respectively.


## us-gaap:ScheduleOfDebtTableTextBlock

[0001571996-18-000044:notes:144]
The following table summarizes DFS debt as of the periods indicated.  The table excludes the allocated portion of the Company’s other borrowings, which represents the additional amount considered to fund the DFS business.

[0001571996-18-000044:notes:145]
The following table summarizes the Company’s outstanding debt as of the dates indicated:

[0001571996-18-000044:notes:146]
|  | November 2, 2018 |  | February 2, 2018 |
|  | (in millions) |
| Secured Debt |  |  |  |
| Senior Secured Credit Facilities: |  |  |  |
| 4.31% Term Loan B Facility due September 2023 | $ | 4,950 |  |  | $ | 4,988 |  |
| 4.06% Term Loan A-2 Facility due September 2021 | 4,228 |  |  | 4,394 |  |
| 3.81% Term Loan A-3 Facility due December 2018 | — |  |  | 1,213 |  |
| First Lien Notes: |  |  |  |
| 3.48% due June 2019 | 3,750 |  |  | 3,750 |  |
| 4.42% due June 2021 | 4,500 |  |  | 4,500 |  |
| 5.45% due June 2023 | 3,750 |  |  | 3,750 |  |
| 6.02% due June 2026 | 4,500 |  |  | 4,500 |  |
| 8.10% due July 2036 | 1,500 |  |  | 1,500 |  |
| 8.35% due July 2046 | 2,000 |  |  | 2,000 |  |
| Unsecured Debt |  |  |  |
| Unsecured Notes and Debentures: |  |  |  |
| 5.65% due April 2018 | — |  |  | 500 |  |
| 5.875% due June 2019 | 600 |  |  | 600 |  |
| 4.625% due April 2021 | 400 |  |  | 400 |  |
| 7.10% due April 2028 | 300 |  |  | 300 |  |
| 6.50% due April 2038 | 388 |  |  | 388 |  |
| 5.40% due September 2040 | 264 |  |  | 264 |  |
| Senior Notes: |  |  |  |
| 5.875% due June 2021 | 1,625 |  |  | 1,625 |  |
| 7.125% due June 2024 | 1,625 |  |  | 1,625 |  |
| EMC Notes: |  |  |  |
| 1.875% due June 2018 | — |  |  | 2,500 |  |
| 2.650% due June 2020 | 2,000 |  |  | 2,000 |  |
| 3.375% due June 2023 | 1,000 |  |  | 1,000 |  |
| VMware Notes: |  |  |  |
| 2.30% due August 2020 | 1,250 |  |  | 1,250 |  |
| 2.95% due August 2022 | 1,500 |  |  | 1,500 |  |
| 3.90% due August 2027 | 1,250 |  |  | 1,250 |  |
| DFS Debt (Note 5) | 5,937 |  |  | 4,796 |  |
| Other |  |  |  |
| 4.78% Margin Loan Facility due April 2022 | 2,000 |  |  | 2,000 |  |
| Other | 47 |  |  | 101 |  |
| Total debt, principal amount | $ | 49,364 |  |  | $ | 52,694 |  |

[0001571996-18-000044:notes:147]
|  | November 2, 2018 |  | February 2, 2018 |
|  | (in millions) |
| Total debt, principal amount | $ | 49,364 |  |  | $ | 52,694 |  |
| Unamortized discount, net of unamortized premium | (238 | ) |  | (266 | ) |
| Debt issuance costs | (469 | ) |  | (557 | ) |
| Total debt, carrying value | $ | 48,657 |  |  | $ | 51,871 |  |
| Total short-term debt, carrying value | $ | 8,150 |  |  | $ | 7,873 |  |
| Total long-term debt, carrying value | $ | 40,507 |  |  | $ | 43,998 |  |


## us-gaap:DebtDisclosureTextBlock

[0001571996-18-000044:notes:148]
NOTE 6 — DEBT

[0001571996-18-000044:notes:149]
During the nine months ended November 2, 2018, the Company repaid $3 billion principal amount of its unsecured notes and $1.4 billion principal amount of its term loan facilities, which included approximately $0.2 billion of amortization.   Additionally, during the nine months ended November 2, 2018, the Company issued an additional $1.2 billion, net, in DFS debt to support the expansion of its financing receivables portfolio.

[0001571996-18-000044:notes:150]
Secured Debt

[0001571996-18-000044:notes:151]
Senior Secured Credit Facilities — The Company has entered into a credit agreement that provides for senior secured credit facilities (the “Senior Secured Credit Facilities”) in the aggregate principal amount of $17.6 billion comprising (a) term loan facilities and (b) a senior secured Revolving Credit Facility, which includes capacity for up to $0.5 billion of letters of credit and for borrowings of up to $0.4 billion under swing-line loans.  As of November 2, 2018, available borrowings under the Revolving Credit Facility totaled $3.3 billion.  The Senior Secured Credit Facilities provide that the borrowers have the right at any time, subject to customary conditions, to request incremental term loans or incremental revolving commitments.

[0001571996-18-000044:notes:152]
Borrowings under the Senior Secured Credit Facilities bear interest at a rate per annum equal to an applicable margin, plus, at the borrowers’ option, either (a) a base rate, which, under the Term Loan B Facility, is subject to an interest rate floor of 1.75% per annum, and under all other borrowings is subject to an interest rate floor of 0% per annum, or (b) a London interbank offered rate (“LIBOR”), which, under the Term Loan B Facility, is subject to an interest rate floor of 0.75% per annum, and under all other borrowings is subject to an interest rate floor of 0% per annum.  Interest is payable, in the case of loans bearing interest based on LIBOR, at the end of each interest period (but at least every three months), in arrears and, in the case of loans bearing interest based on the base rate, quarterly in arrears.

[0001571996-18-000044:notes:153]
The Term Loan A-2 Facility amortizes in equal quarterly installments in aggregate annual amounts equal to 5% of the original principal amount in the first year after the closing date of the refinancing transaction on October 20, 2017, 10% of the original principal amount in each of the second and third years after October 20, 2017, and 70% of the original principal amount in the fourth year after October 20, 2017.  The Term Loan B Facility amortizes in equal quarterly installments in aggregate annual amounts equal to 1% of the original principal amount.  The Revolving Credit Facility has no amortization.  The borrowers may voluntarily repay outstanding loans under the term loan facilities and the Revolving Credit Facility at any time without premium or penalty, other than customary “breakage” costs.  The Term Loan A-3 Facility was fully repaid during the three months ended November 2, 2018.

[0001571996-18-000044:notes:154]
All obligations of the borrowers under the Senior Secured Credit Facilities and certain swap agreements, cash management arrangements, and certain letters of credit provided by any lender or agent party to the Senior Secured Credit Facilities or any of its affiliates and certain other persons are secured by (a) a first-priority security interest in certain tangible and intangible assets of the borrowers and the guarantors and (b) a first-priority pledge of 100% of the capital stock of the borrowers, Dell Inc., a wholly‑owned subsidiary of the Company (“Dell”), and each wholly-owned material restricted subsidiary of the borrowers and the guarantors, in each case subject to certain thresholds, exceptions, and permitted liens.

[0001571996-18-000044:notes:155]
On November 14, 2018, the Company entered into a commitment letter with bank lenders providing for bridge financing in an aggregate principal amount of up to $5.0 billion under the Senior Secured Credit Facilities. See Note 20 of the Notes to the Condensed Consolidated Financial Statements included in this report for further information regarding the bridge financing.

[0001571996-18-000044:notes:156]
First Lien Notes — The senior secured notes (collectively, the “First Lien Notes”) were issued on June 1, 2016 in an aggregate principal amount of $20.0 billion.  Interest on these borrowings is payable semiannually.  The First Lien Notes are secured, on a pari passu basis with the Senior Secured Credit Facilities, on a first-priority basis by substantially all of the tangible and intangible assets of the issuers and guarantors that secure obligations under the Senior Secured Credit Facilities, including pledges of all capital stock of the issuers, Dell, and certain wholly-owned material subsidiaries of the issuers and the guarantors, subject to certain exceptions.

[0001571996-18-000044:notes:157]
The Company has agreed to use commercially reasonable efforts to register with the SEC notes having terms substantially identical to the terms of the First Lien Notes as part of an offer to exchange such registered notes for the First Lien Notes.  The Company will be obligated to pay additional interest on the First Lien Notes if it fails to consummate such an exchange offer within five years after the closing date of the EMC merger transaction.

[0001571996-18-000044:notes:158]
China Revolving Credit Facility — On October 31, 2017, the Company entered into a credit agreement (the “China Revolving Credit Facility”) with a bank lender for a secured revolving loan facility in an aggregate principal amount not to exceed $500 million at an interest rate of LIBOR plus 0.6% per annum.   The facility expired on October 31, 2018, with no outstanding borrowings due.

[0001571996-18-000044:notes:159]
Unsecured Debt

[0001571996-18-000044:notes:160]
Unsecured Notes and Debentures — The Company has outstanding unsecured notes and debentures (collectively, the “Unsecured Notes and Debentures”) that were issued prior to the acquisition of Dell by Dell Technologies Inc. in the going-private transaction that closed in October 2013.  Interest on these borrowings is payable semiannually.

[0001571996-18-000044:notes:161]
Senior Notes — The senior unsecured notes (collectively, the “Senior Notes”) were issued on June 22, 2016 in an aggregate principal amount of $3.25 billion.  Interest on these borrowings is payable semiannually.

[0001571996-18-000044:notes:162]
EMC Notes — On September 7, 2016, EMC had outstanding $2.5 billion aggregate principal amount of its 1.875% Notes due June 2018, which the Company fully repaid during the three months ended August 3, 2018, $2.0 billion aggregate principal amount of its 2.650% Notes due June 2020, and $1.0 billion aggregate principal amount of its 3.375% Notes due June 2023 (collectively, the “EMC Notes”).  Interest on these borrowings is payable semiannually.

[0001571996-18-000044:notes:163]
VMware Notes — On August 21, 2017, VMware, Inc. completed a public offering of unsecured senior notes in the aggregate amount of $4.0 billion, consisting of outstanding principal due on the following dates: $1.25 billion due August 21, 2020, $1.50 billion due August 21, 2022, and $1.25 billion due August 21, 2027 (collectively, the “VMware Notes”).  The VMware Notes bear interest, payable semiannually, at annual rates of 2.30%, 2.95%, and 3.90%, respectively.  None of the net proceeds of such borrowings will be made available to support the operations or satisfy any corporate purposes of Dell Technologies, other than the operations and corporate purposes of VMware, Inc. and VMware, Inc.’s subsidiaries.

[0001571996-18-000044:notes:164]
VMware Revolving Credit Facility —  On September 12, 2017, VMware, Inc. entered into an unsecured credit agreement, establishing a revolving credit facility (the “VMware Revolving Credit Facility”), with a syndicate of lenders that provides the company with a borrowing capacity of up to $1.0 billion which may be used for VMware, Inc. general corporate purposes.  Commitments under the VMware Revolving Credit Facility are available for a period of five years, which may be extended, subject to the satisfaction of certain conditions, by up to two one year periods.  The credit agreement contains certain representations, warranties, and covenants.  Commitment fees, interest rates, and other terms of borrowing under the VMware Revolving Credit Facility may vary based on VMware, Inc.’s external credit ratings.  None of the net proceeds of such borrowings will be made available to support the operations or satisfy any corporate purposes of Dell Technologies, other than the operations and corporate purposes of VMware, Inc. and VMware, Inc.’s subsidiaries.  As of November 2, 2018, there were no outstanding borrowings under the VMware Revolving Credit Facility.

[0001571996-18-000044:notes:165]
See Note 5 and Note 7 of the Notes to the Condensed Consolidated Financial Statements, respectively, for discussion of DFS debt and the interest rate swap agreements that hedge a portion of that debt.

[0001571996-18-000044:notes:166]
Margin Loan Facility — On April 12, 2017, the Company entered into the Margin Loan Facility in an aggregate principal amount of $2.0 billion.  VMW Holdco LLC, a wholly-owned subsidiary of EMC, is the borrower under the Margin Loan Facility, which is secured by 60 million shares of Class B common stock of VMware, Inc. and 20 million shares of Class A common stock of VMware, Inc.  Loans under the Margin Loan Facility bear interest at a rate per annum payable, at the borrower’s option, either at (a) a base rate plus 1.25% per annum or (b) a LIBOR-based rate plus 2.25% per annum.  Interest under the Margin Loan Facility is payable quarterly.

[0001571996-18-000044:notes:167]
The Margin Loan Facility will mature in April 2022.  The borrower may voluntarily repay outstanding loans under the Margin Loan Facility at any time without premium or penalty, other than customary “breakage” costs, subject to certain minimum threshold amounts for prepayment.

[0001571996-18-000044:notes:168]
Pivotal Revolving Credit Facility — On September 7, 2017, Pivotal entered into a credit agreement (the “Pivotal Revolving Credit Facility”) that provides for a senior secured revolving loan facility in an aggregate principal amount not to exceed $100 million.  The credit facility contains customary representations, warranties, and covenants, including financial covenants.  The credit agreement will expire on September 8, 2020, unless it is terminated earlier.  None of the net proceeds of borrowings under the facility will be made available to support the operations or satisfy any corporate purposes of Dell Technologies, other than the operations and corporate purposes of Pivotal and Pivotal’s subsidiaries.  As of November 2, 2018, there were no outstanding borrowings under the Pivotal Revolving Credit Facility.

[0001571996-18-000044:notes:169]
Aggregate Future Maturities

[0001571996-18-000044:notes:170]
As of November 2, 2018, aggregate future maturities of the Company’s debt were as follows:

[0001571996-18-000044:notes:171]
|  | Maturities by Fiscal Year |
|  | 2019 (remaining three months) |  | 2020 |  | 2021 |  | 2022 |  | 2023 |  | Thereafter |  | Total |
|  | (in millions) |
| Senior Secured Credit Facilities and First Lien Notes | $ | 124 |  |  | $ | 4,245 |  |  | $ | 371 |  |  | $ | 7,888 |  |  | $ | 62 |  |  | $ | 16,488 |  |  | $ | 29,178 |  |
| Unsecured Notes and Debentures | — |  |  | 600 |  |  | — |  |  | 400 |  |  | — |  |  | 952 |  |  | 1,952 |  |
| Senior Notes and EMC Notes | — |  |  | — |  |  | 2,000 |  |  | 1,625 |  |  | — |  |  | 2,625 |  |  | 6,250 |  |
| VMware Notes | — |  |  | — |  |  | 1,250 |  |  | — |  |  | 1,500 |  |  | 1,250 |  |  | 4,000 |  |
| DFS Debt | 1,011 |  |  | 2,812 |  |  | 1,712 |  |  | 318 |  |  | 75 |  |  | 9 |  |  | 5,937 |  |
| Margin Loan Facility |  |  |  |  |  |  |  |  |  |  |  |  | 2,000 |  |  | — |  |  | 2,000 |  |
| Other | 7 |  |  | 24 |  |  | 16 |  |  | — |  |  | — |  |  | — |  |  | 47 |  |
| Total maturities, principal amount | 1,142 |  |  | 7,681 |  |  | 5,349 |  |  | 10,231 |  |  | 3,637 |  |  | 21,324 |  |  | 49,364 |  |
| Associated carrying value adjustments | — |  |  | (14 | ) |  | (7 | ) |  | (151 | ) |  | (26 | ) |  | (509 | ) |  | (707 | ) |
| Total maturities, carrying value amount | $ | 1,142 |  |  | $ | 7,667 |  |  | $ | 5,342 |  |  | $ | 10,080 |  |  | $ | 3,611 |  |  | $ | 20,815 |  |  | $ | 48,657 |  |

[0001571996-18-000044:notes:172]
Covenants and Unrestricted Net Assets — The credit agreement for the Senior Secured Credit Facilities contains customary negative covenants that generally limit the ability of Denali Intermediate Inc., a wholly-owned subsidiary of Dell Technologies (“Dell Intermediate”), Dell, and Dell’s and Denali Intermediate’s other restricted subsidiaries to incur debt, create liens, make fundamental changes, enter into asset sales, make certain investments, pay dividends or distribute or redeem certain equity interests, prepay or redeem certain debt, and enter into certain transactions with affiliates.  The indenture governing the Senior Notes contains customary negative covenants that generally limit the ability of Denali Intermediate, Dell, and Dell’s and Denali Intermediate’s other restricted subsidiaries to incur additional debt or issue certain preferred shares, pay dividends on or make other distributions in respect of capital stock or make other restricted payments, make certain investments, sell or transfer certain assets, create liens on certain assets to secure debt, consolidate, merge, sell, or otherwise dispose of all or substantially all assets, enter into certain transactions with affiliates, and designate subsidiaries as unrestricted subsidiaries.

[0001571996-18-000044:notes:173]
The negative covenants under such credit agreements and indenture are subject to certain exceptions, qualifications, and “baskets.”  The indentures governing the First Lien Notes, the Unsecured Notes and Debentures, and the EMC Notes variously impose limitations, subject to specified exceptions, on creating certain liens, entering into sale and lease-back transactions, and entering into certain asset sales.  The foregoing credit agreements and indentures contain customary events of default, including failure to make required payments, failure to comply with covenants, and the occurrence of certain events of bankruptcy and insolvency.

[0001571996-18-000044:notes:174]
As of November 2, 2018, the Company had certain consolidated subsidiaries that were designated as unrestricted subsidiaries for all purposes of the applicable credit agreements and the indentures governing the First Lien Notes and the Senior Notes.

[0001571996-18-000044:notes:175]
The Term Loan A-2 Facility and the Revolving Credit Facility are subject to a first lien leverage ratio covenant that is tested at the end of each fiscal quarter of Dell with respect to Dell’s preceding four fiscal quarters.  The Company was in compliance with all financial covenants as of November 2, 2018.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001571996-18-000044:notes:176]
NOTE 7 — DERIVATIVE INSTRUMENTS AND HEDGING ACTIVITIES

[0001571996-18-000044:notes:177]
[same as prior period, unchanged from 0001571996-18-000034:notes:122]

[0001571996-18-000044:notes:178]
[same as prior period, unchanged from 0001571996-18-000034:notes:123]

[0001571996-18-000044:notes:179]
The Company’s objective is to offset gains and losses resulting from these exposures with gains and losses on the derivative contracts used to hedge the exposures, thereby reducing volatility of earnings and protecting the fair values of assets and liabilities.  The earnings effects of the derivative instruments are presented in the same income statement line items as the earnings effects of the hedged items.  For derivatives designated as cash flow hedges, the Company assesses hedge effectiveness both at the onset of the hedge and at regular intervals throughout the life of the derivative.  The Company does not have any derivatives designated as fair value hedges.

[0001571996-18-000044:notes:180]
[same as prior period, unchanged from 0001571996-18-000034:notes:125]

[0001571996-18-000044:notes:181]
[same as prior period, unchanged from 0001571996-18-000034:notes:126]

[0001571996-18-000044:notes:182]
During the nine months ended November 2, 2018 and November 3, 2017, the Company did not discontinue any cash flow hedges related to foreign exchange contracts that had a material impact on the Company’s results of operations due to the probability that the forecasted cash flows would not occur.

[0001571996-18-000044:notes:183]
[same as prior period, unchanged from 0001571996-18-000034:notes:128]

[0001571996-18-000044:notes:184]
[same as prior period, unchanged from 0001571996-18-000034:notes:129]

[0001571996-18-000044:notes:185]
[same as prior period, unchanged from 0001571996-18-000034:notes:130]

[0001571996-18-000044:notes:186]
[same as prior period, unchanged from 0001571996-18-000034:notes:131]

[0001571996-18-000044:notes:187]
Interest rate swaps are utilized to manage the interest rate risk, at a portfolio level, associated with DFS operations in Europe.  The interest rate swaps economically convert the fixed rate on financing receivables to a three-month Euribor floating rate basis in order to match the floating rate nature of the banks’ funding pool.  These contracts are not designated for hedge accounting and most expire within five years or less.

[0001571996-18-000044:notes:188]
[same as prior period, unchanged from 0001571996-18-000034:notes:133]

[0001571996-18-000044:notes:189]
[same as prior period, unchanged from 0001571996-18-000034:notes:134]

[0001571996-18-000044:notes:190]
The notional amounts of the Company’s outstanding derivative instruments were as follows as of the dates indicated:

[0001571996-18-000044:notes:191]
|  | November 2, 2018 |  | February 2, 2018 |
|  | (in millions) |
| Foreign exchange contracts: |  |  |  |  |  |
| Designated as cash flow hedging instruments | $ | 6,984 |  |  | $ | 4,392 |  |
| Non-designated as hedging instruments | 5,480 |  |  | 6,223 |  |
| Total | $ | 12,464 |  |  | $ | 10,615 |  |
| Interest rate contracts: |  |  |  |
| Non-designated as hedging instruments | $ | 2,326 |  |  | $ | 1,897 |  |

[0001571996-18-000044:notes:192]
[same as prior period, unchanged from 0001571996-18-000034:notes:137]

[0001571996-18-000044:notes:193]
| Derivatives in Cash FlowHedging Relationships |  | Gain (Loss)Recognizedin AccumulatedOCI, Netof Tax, onDerivatives |  | Location of Gain (Loss)Reclassified from Accumulated OCI into Income |  | Gain (Loss)Reclassifiedfrom AccumulatedOCI into Income |
|  |  | (in millions) |  |  |  | (in millions) |
| For the three months ended November 2, 2018 |
|  |  |  |  |  | Total net revenue |  | $ | 76 |  |
| Foreign exchange contracts |  | $ | 73 |  |  | Total cost of net revenue |  | — |  |
| Interest rate contracts |  | — |  |  | Interest and other, net |  | — |  |
| Total |  | $ | 73 |  |  |  |  | $ | 76 |  |
| For the three months ended November 3, 2017 |
|  |  |  |  |  | Total net revenue |  | $ | (18 | ) |
| Foreign exchange contracts |  | $ | 76 |  |  | Total cost of net revenue |  | (13 | ) |
| Interest rate contracts |  | — |  |  | Interest and other, net |  | — |  |
| Total |  | $ | 76 |  |  |  |  | $ | (31 | ) |
| For the nine months ended November 2, 2018 |
|  |  |  |  |  | Total net revenue |  | $ | 122 |  |
| Foreign exchange contracts |  | $ | 314 |  |  | Total cost of net revenue |  | — |  |
| Interest rate contracts |  | — |  |  | Interest and other, net |  | — |  |
| Total |  | $ | 314 |  |  |  |  | $ | 122 |  |
| For the nine months ended November 3, 2017 |
|  |  |  |  |  | Total net revenue |  | $ | (50 | ) |
| Foreign exchange contracts |  | $ | (81 | ) |  | Total cost of net revenue |  | (30 | ) |
| Interest rate contracts |  | — |  |  | Interest and other, net |  | — |  |
| Total |  | $ | (81 | ) |  |  |  | $ | (80 | ) |

[0001571996-18-000044:notes:194]
[same as prior period, unchanged from 0001571996-18-000034:notes:139]

[0001571996-18-000044:notes:195]
|  |  | Three Months Ended |  | Nine Months Ended |  |  |
|  |  | November 2, 2018 |  | November 3, 2017 |  | November 2, 2018 |  | November 3, 2017 |  | Location of Gain (Loss) Recognized |
|  |  | (in millions) |  |  |
| Gain (Loss) Recognized: |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | $ | 18 |  |  | $ | (75 | ) |  | $ | 50 |  |  | $ | (71 | ) |  | Interest and other, net |
| Interest rate contracts |  | 1 |  |  | 1 |  |  | 2 |  |  | — |  |  | Interest and other, net |
| Total |  | $ | 19 |  |  | $ | (74 | ) |  | $ | 52 |  |  | $ | (71 | ) |  |  |

[0001571996-18-000044:notes:196]
[same as prior period, unchanged from 0001571996-18-000034:notes:141]

[0001571996-18-000044:notes:197]
[same as prior period, unchanged from 0001571996-18-000034:notes:142]

[0001571996-18-000044:notes:198]
|  | November 2, 2018 |
|  | Other CurrentAssets |  | Other Non-Current Assets |  | Other CurrentLiabilities |  | Other Non-CurrentLiabilities |  | TotalFair Value |
|  |  |  | (in millions) |  |  |
| Derivatives designated as hedging instruments: |
| Foreign exchange contracts in an asset position | $ | 138 |  |  | $ | — |  |  | $ | 3 |  |  | $ | — |  |  | $ | 141 |  |
| Foreign exchange contracts in a liability position | (7 | ) |  | — |  |  | (9 | ) |  | — |  |  | (16 | ) |
| Net asset (liability) | 131 |  |  | — |  |  | (6 | ) |  | — |  |  | 125 |  |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts in an asset position | 306 |  |  | — |  |  | 5 |  |  | — |  |  | 311 |  |
| Foreign exchange contracts in a liability position | (193 | ) |  | — |  |  | (12 | ) |  | (2 | ) |  | (207 | ) |
| Interest rate contracts in an asset position | — |  |  | 9 |  |  | — |  |  | — |  |  | 9 |  |
| Interest rate contracts in a liability position | — |  |  | — |  |  | — |  |  | (3 | ) |  | (3 | ) |
| Net asset (liability) | 113 |  |  | 9 |  |  | (7 | ) |  | (5 | ) |  | 110 |  |
| Total derivatives at fair value | $ | 244 |  |  | $ | 9 |  |  | $ | (13 | ) |  | $ | (5 | ) |  | $ | 235 |  |
|  | February 2, 2018 |
|  | Other CurrentAssets |  | Other Non-Current Assets |  | Other CurrentLiabilities |  | Other Non-CurrentLiabilities |  | TotalFair Value |
|  |  |  | (in millions) |  |  |
| Derivatives designated as hedging instruments: |
| Foreign exchange contracts in an asset position | $ | 9 |  |  | $ | — |  |  | $ | 11 |  |  | $ | — |  |  | $ | 20 |  |
| Foreign exchange contracts in a liability position | (7 | ) |  | — |  |  | (52 | ) |  | — |  |  | (59 | ) |
| Net asset (liability) | 2 |  |  | — |  |  | (41 | ) |  | — |  |  | (39 | ) |
| Derivatives not designated as hedging instruments: |
| Foreign exchange contracts in an asset position | 194 |  |  | 3 |  |  | 141 |  |  | — |  |  | 338 |  |
| Foreign exchange contracts in a liability position | (127 | ) |  | — |  |  | (283 | ) |  | — |  |  | (410 | ) |
| Interest rate contracts in an asset position | — |  |  | 11 |  |  | — |  |  | — |  |  | 11 |  |
| Interest rate contracts in a liability position | — |  |  | — |  |  | — |  |  | (1 | ) |  | (1 | ) |
| Net asset (liability) | 67 |  |  | 14 |  |  | (142 | ) |  | (1 | ) |  | (62 | ) |
| Total derivatives at fair value | $ | 69 |  |  | $ | 14 |  |  | $ | (183 | ) |  | $ | (1 | ) |  | $ | (101 | ) |

[0001571996-18-000044:notes:199]
The following tables present the gross amounts of the Company’s derivative instruments, amounts offset due to master netting agreements with the Company’s counterparties, and the net amounts recognized in the Condensed Consolidated Statements of Financial Position.

[0001571996-18-000044:notes:200]
|  | November 2, 2018 |
|  | Gross Amounts of Recognized Assets/ (Liabilities) |  | Gross Amounts Offset in the Statement of Financial Position |  | Net Amounts of Assets/ (Liabilities) Presented in the Statement of Financial Position |  | Gross Amounts not Offset in the Statement of Financial Position |  | Net Amount |
|  | Financial Instruments |  | Cash Collateral Received or Pledged |  |
|  | (in millions) |
| Derivative instruments: |  |  |  |  |  |  |  |  |  |  |  |
| Financial assets | $ | 461 |  |  | $ | (208 | ) |  | $ | 253 |  |  | $ | — |  |  | $ | — |  |  | $ | 253 |  |
| Financial liabilities | (226 | ) |  | 208 |  |  | (18 | ) |  | — |  |  | 3 |  |  | (15 | ) |
| Total derivative instruments | $ | 235 |  |  | $ | — |  |  | $ | 235 |  |  | $ | — |  |  | $ | 3 |  |  | $ | 238 |  |
|  | February 2, 2018 |
|  | Gross Amounts of Recognized Assets/ (Liabilities) |  | Gross Amounts Offset in the Statement of Financial Position |  | Net Amounts of Assets/ (Liabilities) Presented in the Statement of Financial Position |  | Gross Amounts not Offset in the Statement of Financial Position |  | Net Amount |
|  | Financial Instruments |  | Cash Collateral Received or Pledged |  |
|  | (in millions) |
| Derivative instruments: |  |  |  |  |  |  |  |  |  |  |  |
| Financial assets | $ | 369 |  |  | $ | (286 | ) |  | $ | 83 |  |  | $ | — |  |  | $ | — |  |  | $ | 83 |  |
| Financial liabilities | (470 | ) |  | 286 |  |  | (184 | ) |  | — |  |  | — |  |  | (184 | ) |
| Total derivative instruments | $ | (101 | ) |  | $ | — |  |  | $ | (101 | ) |  | $ | — |  |  | $ | — |  |  | $ | (101 | ) |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001571996-18-000044:notes:201]
NOTE 8 — GOODWILL AND INTANGIBLE ASSETS

[0001571996-18-000044:notes:202]
[same as prior period, unchanged from 0001571996-18-000034:notes:178]

[0001571996-18-000044:notes:203]
The following table presents goodwill allocated to the Company’s business segments as of November 2, 2018 and February 2, 2018, and changes in the carrying amount of goodwill for the respective periods:

[0001571996-18-000044:notes:204]
|  | Infrastructure Solutions Group (a) |  | Client Solutions Group |  | VMware |  | Other Businesses (b) |  | Total |
|  | (in millions) |
| Balance as of February 2, 2018 | $ | 15,953 |  |  | $ | 4,237 |  |  | $ | 15,635 |  |  | $ | 4,095 |  |  | $ | 39,920 |  |
| Goodwill acquired (c) | — |  |  | — |  |  | 394 |  |  | — |  |  | 394 |  |
| Impact of foreign currency translation | (330 | ) |  | — |  |  | — |  |  | (72 | ) |  | (402 | ) |
| Goodwill divested | (69 | ) |  | — |  |  | — |  |  | — |  |  | (69 | ) |
| Other adjustments (d) | (396 | ) |  | — |  |  | (2 | ) |  | 396 |  |  | (2 | ) |
| Goodwill impaired (e) | — |  |  | — |  |  | — |  |  | (190 | ) |  | (190 | ) |
| Balance as of November 2, 2018 | $ | 15,158 |  |  | $ | 4,237 |  |  | $ | 16,027 |  |  | $ | 4,229 |  |  | $ | 39,651 |  |

[0001571996-18-000044:notes:205]
[same as prior period, unchanged from 0001571996-18-000034:notes:181]

[0001571996-18-000044:notes:206]
| (b) | Other Businesses consists of offerings by Pivotal, SecureWorks, RSA Security LLC (“RSA Security”), Virtustream Group Holdings, Inc. (“Virtustream”), and Boomi, Inc. (“Boomi”). |

[0001571996-18-000044:notes:207]
| (c) | During the three months ended November 2, 2018, VMware, Inc. completed the acquisition of CloudHealth Technologies, Inc. (“CloudHealth Technologies”). |

[0001571996-18-000044:notes:208]
| (d) | During the three months ended May 4, 2018, the Company made certain segment reporting changes, which included the movement of the results of Virtustream from the Infrastructure Solutions Group segment to Other businesses. The amount of goodwill attributable to Virtustream was reclassified to Other businesses to align with these reporting changes. |

[0001571996-18-000044:notes:209]
| (e) | The Company recognized a goodwill impairment charge related to Virtustream, as discussed below. |

[0001571996-18-000044:notes:210]
VMware, Inc. Acquisition  — CloudHealth Technologies delivers a cloud operations platform that enables customers to analyze and manage cloud cost, usage, security, and performance centrally for native public clouds.  The total purchase price was $495 million, net of cash acquired of $26 million and primarily included $101 million of identifiable intangible assets and $394 million of goodwill that is not expected to be deductible for tax purposes.  The preliminary allocation of the purchase price was based on a preliminary valuation and assumptions, and is subject to change within the measurement period. VMware, Inc. expects to finalize the allocation of the purchase price as soon as practicable and not later than one year from the acquisition date.

[0001571996-18-000044:notes:211]
Annual Goodwill Impairment Test  — In connection with its annual impairment cycle, the Company elected to early adopt the amended guidance issued by the FASB that simplified the goodwill impairment test, as discussed in Note 1 of the Notes to the Condensed Consolidated Financial Statements.

[0001571996-18-000044:notes:212]
Goodwill and indefinite-lived intangible assets are tested for impairment annually during the third fiscal quarter and whenever events or circumstances may indicate that an impairment has occurred.  The Company elected to bypass the assessment of qualitative factors to determine whether it was more likely than not that the fair value of a reporting unit was less than its carrying amount, including goodwill.  In electing to bypass the qualitative assessment, the Company proceeded directly to performing a quantitative goodwill impairment test to measure the fair value of each goodwill reporting unit relative to its carrying amount, and to determine the amount of goodwill impairment loss to be recognized, if any.

[0001571996-18-000044:notes:213]
Management exercised significant judgment related to the above assessment, including the identification of goodwill reporting units, assignment of assets and liabilities to goodwill reporting units, assignment of goodwill to reporting units, and determination of the fair value of each goodwill reporting unit.  The fair value of each goodwill reporting unit is generally estimated using a combination of public company multiples and discounted cash flow methodologies, unless the reporting unit relates to a publicly traded entity (VMware, Inc., Pivotal, or SecureWorks), in which case the fair value is determined based primarily on the public company market valuation.  The discounted cash flow and public company multiples methodologies require significant judgment, including estimation of future cash flows, which is dependent on internal forecasts, current and anticipated economic conditions and trends, selection of market multiples through assessment of the reporting unit’s performance relative to peer competitors, the estimation of the long-term growth rate of the Company’s business, and the determination of the Company’s weighted average cost of capital.  Changes in these estimates and assumptions could materially affect the fair value of the goodwill reporting unit, potentially resulting in a non-cash impairment charge.

[0001571996-18-000044:notes:214]
Based on the results of the annual impairment test, which was a quantitative test for all goodwill reporting units, the fair values of each of the reporting units, except for the Virtustream reporting unit, exceeded their carrying values.  Virtustream’s results, which are reported within the Company’s “Other Businesses,” do not meet the requirements for a reportable segment and are not material to the Company’s overall results.  See Note 18 of the Notes to the Condensed Consolidated Financial Statements for additional segment information.

[0001571996-18-000044:notes:215]
Virtustream delivers an application management cloud platform for enterprise mission-critical workloads in the Infrastructure-as-a-Service (“IaaS”) market, and has approximately $0.4 billion in goodwill that was derived from the EMC acquisition in fiscal year 2017.  Virtustream forecasts were revised downward due to a resetting of the longer term business model that is focused on a streamlined product portfolio.

[0001571996-18-000044:notes:216]
It was determined that the carrying value of the Virtustream reporting unit exceeded its fair value, as such a goodwill impairment charge of approximately $190 million was recognized during the three months ended November 2, 2018.  This expense was classified in selling, general, and administrative in the Condensed Consolidated Statements of Income (Loss).  The impairment is reflected as a reduction in goodwill of approximately $190 million in the Condensed Consolidated Statements of Financial Position as of November 2, 2018.  The Company did not have any accumulated goodwill impairment charges from prior period goodwill impairment tests.  The remaining Virtustream goodwill was approximately $205 million, inclusive of the impact of foreign currency translation, as of November 2, 2018.  Management will continue to monitor the Virtustream goodwill reporting unit and consider potential impacts to the impairment assessment.

[0001571996-18-000044:notes:217]
Further, as a result of the annual impairment test, it was determined that the excess of fair value over carrying amount was less than 20% for the RSA Security reporting unit, which had an excess of fair value over carrying amount of 11% as of November 2, 2018.  Management will continue to monitor the RSA Security goodwill reporting unit and consider potential impacts to the impairment assessment.

[0001571996-18-000044:notes:218]
[same as prior period, unchanged from 0001571996-18-000034:notes:186]

[0001571996-18-000044:notes:219]
The Company’s intangible assets as of November 2, 2018 and February 2, 2018 were as follows:

[0001571996-18-000044:notes:220]
|  | November 2, 2018 |  | February 2, 2018 |
|  | Gross |  | AccumulatedAmortization |  | Net |  | Gross |  | AccumulatedAmortization |  | Net |
|  | (in millions) |
| Customer relationships | $ | 22,749 |  |  | $ | (10,934 | ) |  | $ | 11,815 |  |  | $ | 22,764 |  |  | $ | (8,637 | ) |  | $ | 14,127 |  |
| Developed technology | 15,678 |  |  | (8,315 | ) |  | 7,363 |  |  | 15,586 |  |  | (6,196 | ) |  | 9,390 |  |
| Trade names | 1,288 |  |  | (553 | ) |  | 735 |  |  | 1,277 |  |  | (407 | ) |  | 870 |  |
| Leasehold assets (liabilities) | 128 |  |  | (9 | ) |  | 119 |  |  | 128 |  |  | (6 | ) |  | 122 |  |
| Definite-lived intangible assets | 39,843 |  |  | (19,811 | ) |  | 20,032 |  |  | 39,755 |  |  | (15,246 | ) |  | 24,509 |  |
| Indefinite-lived trade names | 3,755 |  |  | — |  |  | 3,755 |  |  | 3,756 |  |  | — |  |  | 3,756 |  |
| Total intangible assets | $ | 43,598 |  |  | $ | (19,811 | ) |  | $ | 23,787 |  |  | $ | 43,511 |  |  | $ | (15,246 | ) |  | $ | 28,265 |  |

[0001571996-18-000044:notes:221]
Amortization expense related to definite-lived intangible assets was approximately $1.5 billion and $1.7 billion for the three months ended November 2, 2018 and November 3, 2017, respectively, and $4.6 billion and $5.3 billion for the nine months ended November 2, 2018 and November 3, 2017, respectively.  The amortization expense for the fiscal year ended February 2, 2018 was primarily related to the intangible assets acquired in the EMC merger transaction.  There were no material impairment charges related to intangible assets during the three months ended November 2, 2018 and November 3, 2017.

[0001571996-18-000044:notes:222]
Due to Virtustream business changes, the Virtustream definite-lived intangible assets were tested for impairment using a quantitative analysis, and no impairment was identified.

[0001571996-18-000044:notes:223]
Estimated future annual pre-tax amortization expense of definite-lived intangible assets as of November 2, 2018 over the next five fiscal years and thereafter is as follows:

[0001571996-18-000044:notes:224]
| Fiscal Years | (in millions) |
| 2019 (remaining three months) | $ | 1,543 |  |
| 2020 | 4,386 |  |
| 2021 | 3,358 |  |
| 2022 | 2,648 |  |
| 2023 | 1,763 |  |
| Thereafter | 6,334 |  |
| Total | $ | 20,032 |  |


## us-gaap:DeferredRevenueDisclosureTextBlock

[0001571996-18-000044:notes:225]
NOTE 9 — DEFERRED REVENUE

[0001571996-18-000044:notes:226]
Deferred Revenue — Deferred revenue is recorded for support and deployment services, software maintenance, professional services, training, and SaaS when the Company has a right to invoice or payments have been received for undelivered products or services where transfer of control has not occurred.  Revenue is recognized on these items when the revenue recognition criteria are met, generally resulting in ratable recognition over the contract term.  The Company also has deferred revenue related to undelivered hardware and professional services, consisting of installations and consulting engagements, which are recognized as the Company’s performance obligations under the contract are completed.

[0001571996-18-000044:notes:227]
Changes in the Company’s deferred revenue are presented in the following table for the period indicated:

[0001571996-18-000044:notes:228]
|  | Three Months Ended |  | Nine Months Ended |
|  | November 2, 2018 |  | November 2, 2018 |
|  | (in millions) |
| Deferred revenue: |  |  |  |
| Deferred revenue at beginning of period | $ | 21,700 |  |  | $ | 20,816 |  |
| Revenue deferrals for new contracts and changes in estimates for pre-existing contracts (a) | 5,166 |  |  | 16,626 |  |
| Revenue recognized | (4,723 | ) |  | (15,299 | ) |
| Deferred revenue at end of period | $ | 22,143 |  |  | $ | 22,143 |  |
| Short-term deferred revenue | $ | 12,079 |  |  | $ | 12,079 |  |
| Long-term deferred revenue | $ | 10,064 |  |  | $ | 10,064 |  |

[0001571996-18-000044:notes:229]
| (a) | Includes the impact of foreign currency exchange rate fluctuations. |

[0001571996-18-000044:notes:230]
Remaining Performance Obligations — Remaining performance obligations represent the aggregate amount of the transaction price allocated to performance obligations not delivered, or partially undelivered, as of the end of the reporting period.

[0001571996-18-000044:notes:231]
Remaining performance obligations include deferred revenue plus unbilled amounts not yet recorded in deferred revenue.  The aggregate amount of the transaction price allocated to remaining performance obligations does not include amounts owed under cancelable contracts where there is no substantive termination penalty.

[0001571996-18-000044:notes:232]
The Company applied the practical expedient to exclude the value of remaining performance obligations for contracts for which revenue is recognized at the amount to which the Company has the right to invoice for services performed.  The Company also applied the practical expedient to not disclose the amount of transaction price allocated to remaining performance obligations for the periods prior to adoption of the new revenue standard.

[0001571996-18-000044:notes:233]
Remaining performance obligation estimates are subject to change and are affected by several factors, including terminations, changes in the scope of contracts, periodic revalidation, adjustments for revenue that have not materialized, and adjustments for currency.

[0001571996-18-000044:notes:234]
The value of the transaction price allocated to remaining performance obligations as of November 2, 2018 was approximately $30 billion.  The Company expects to recognize approximately 63% of remaining performance obligations as revenue in the next 12 months, and the remainder thereafter.


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001571996-18-000044:notes:235]
NOTE 10 — WARRANTY LIABILITY

[0001571996-18-000044:notes:236]
[same as prior period, unchanged from 0001571996-18-000034:notes:240]

[0001571996-18-000044:notes:237]
Changes in the Company’s liability for standard limited warranties are presented in the following table for the periods indicated.

[0001571996-18-000044:notes:238]
|  | Three Months Ended |  | Nine Months Ended |
|  | November 2, 2018 |  | November 3, 2017 |  | November 2, 2018 |  | November 3, 2017 |
|  | (in millions) |
| Warranty liability: |  |  |  |  |  |  |  |
| Warranty liability at beginning of period | $ | 542 |  |  | $ | 588 |  |  | $ | 539 |  |  | $ | 604 |  |
| Costs accrued for new warranty contracts and changes in estimates for pre-existing warranties (a) (b) | 226 |  |  | 209 |  |  | 656 |  |  | 672 |  |
| Service obligations honored | (245 | ) |  | (239 | ) |  | (672 | ) |  | (718 | ) |
| Warranty liability at end of period | $ | 523 |  |  | $ | 558 |  |  | $ | 523 |  |  | $ | 558 |  |
| Current portion | $ | 354 |  |  | $ | 371 |  |  | $ | 354 |  |  | $ | 371 |  |
| Non-current portion | $ | 169 |  |  | $ | 187 |  |  | $ | 169 |  |  | $ | 187 |  |

[0001571996-18-000044:notes:239]
| (a) | Changes in cost estimates related to pre-existing warranties are aggregated with accruals for new standard warranty contracts. The Company’s warranty liability process does not differentiate between estimates made for pre-existing warranties and new warranty obligations. |

[0001571996-18-000044:notes:240]
(b)
Includes the impact of foreign currency exchange rate fluctuations.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001571996-18-000044:notes:241]
NOTE 11 — COMMITMENTS AND CONTINGENCIES

[0001571996-18-000044:notes:242]
Legal Matters

[0001571996-18-000044:notes:243]
The Company is involved in various claims, suits, assessments, investigations, and legal proceedings that arise from time to time in the ordinary course of its business, including those identified below, consisting of matters involving consumer, antitrust, tax, intellectual property, and other issues on a global basis.

[0001571996-18-000044:notes:244]
The Company accrues a liability when it believes that it is both probable that a liability has been incurred and that it can reasonably estimate the amount of the loss.  The Company reviews these accruals at least quarterly and adjusts them to reflect ongoing negotiations, settlements, rulings, advice of legal counsel, and other relevant information.  To the extent new information is obtained and the Company’s views on the probable outcomes of claims, suits, assessments, investigations, or legal proceedings change, changes in the Company’s accrued liabilities would be recorded in the period in which such a determination is made.  For some matters, the amount of liability is not probable or the amount cannot be reasonably estimated and therefore accruals have not been made.

[0001571996-18-000044:notes:245]
The following is a discussion of the Company’s significant legal matters and other proceedings:

[0001571996-18-000044:notes:246]
Appraisal Proceedings — On October 29, 2013, Dell Technologies acquired Dell in a transaction referred to as the going-private transaction.  Holders of shares of Dell common stock who did not vote on September 12, 2013 in favor of the proposal to adopt the amended going-private transaction agreement and who properly demanded appraisal of their shares and who otherwise comply with the requirements of Section 262 of the Delaware General Corporate Law (“DGCL”) are entitled to seek appraisal for, and obtain payment in cash for the judicially determined “fair value” (as defined pursuant to Section 262 of the DGCL) of, their shares in lieu of receiving the going-private transaction consideration. The liability for the appraisal proceedings was approximately $129 million as of February 2, 2018.  On May 8, 2018, the Company entered into an agreement to settle a portion of the liability related to the appraisal proceedings in the amount of approximately $70 million, and on May 18, 2018, this portion of the liability was fully paid.  The Company settled with the remaining plaintiffs as of July 16, 2018 in the amount of approximately $30 million.  The remaining liability accrual was released to Interest and other, net during the three months ended August 3, 2018.  As of August 3, 2018, there was no remaining liability for appraisal proceedings.

[0001571996-18-000044:notes:247]
Securities Litigation — On May 22, 2014, a securities class action seeking compensatory damages was filed in the United States District Court for the Southern District of New York, captioned the City of Pontiac Employee Retirement System vs. Dell Inc. et. al. (Case No. 1:14-cv-03644).  The action names as defendants Dell Inc. and certain current and former executive officers, and alleges that Dell made false and misleading statements about Dell’s business operations and products between February 22, 2012 and May 22, 2012, which resulted in artificially inflated stock prices.  The case was transferred to the United States District Court for the Western District of Texas, where the defendants filed a motion to dismiss.  On September 16, 2016, the Court denied the motion to dismiss and the case is proceeding with discovery.  The defendants believe the claims asserted are without merit and the risk of material loss is remote.

[0001571996-18-000044:notes:248]
Copyright Levies — The Company’s obligation to collect and remit copyright levies in certain European Union (“EU”) countries may be affected by the resolution of legal proceedings pending in Germany and other EU member states against various companies, including Dell subsidiaries.  The plaintiffs in those proceedings generally seek to impose or modify the levies with respect to sales of such equipment as multifunction devices, phones, personal computers, storage devices, and printers, alleging that such products enable the copying of copyrighted materials.  Some of the proceedings also challenge whether the levy schemes in those countries comply with EU law.  Certain EU member countries that do not yet impose levies on digital devices are expected to implement legislation to enable them to extend existing levy schemes, while some other EU member countries are expected to limit the scope of levy schemes and their applicability in the digital hardware environment.  Dell, other companies, and various industry associations have opposed the extension of levies to the digital environment and have advocated alternative models of compensation to rights holders.

[0001571996-18-000044:notes:249]
The Company continues to collect levies in certain EU countries where it has determined that based on local laws it is probable that it has a payment obligation.  The amount of levies is generally based on the number of products sold and the per-product amounts of the levies, which vary.  The Company accrues a liability when it believes that it is both probable that a loss has been incurred and when it can reasonably estimate the amount of the loss.

[0001571996-18-000044:notes:250]
Other Litigation — The various legal proceedings in which Dell is involved include commercial litigation and a variety of patent suits.  In some of these cases, Dell is the sole defendant.  More often, particularly in the patent suits, Dell is one of a number of defendants in the electronics and technology industries.  Dell is actively defending a number of patent infringement suits, and several pending claims are in various stages of evaluation.  While the number of patent cases varies over time, Dell does not currently anticipate that any of these matters will have a material adverse effect on its business, financial condition, results of operations, or cash flows.

[0001571996-18-000044:notes:251]
Class V Transaction Litigation — On October 31, 2018, High River Limited Partnership, Icahn Partners Master Fund LP, and Icahn Partners LP filed an action against Dell in Delaware Chancery Court, pursuant to Section 220 of the DGCL, seeking (1) to inspect certain of the Company’s books and records purportedly related to the Class V transaction described in Note 16 of the Notes to the Condensed Consolidated Financial Statements or the potential initial public offering of the Company’s Class C Common Stock, and (2) the public dissemination of unspecified materials already produced for inspection (High River LP v. Dell Tech. Holdings Inc., No. 2018-0790 (Del. Ch. filed Oct. 31, 2018)).  By motion dated October 31, 2018, the plaintiffs sought expedited treatment of their claims.  On November 1, 2018, Dell filed its opposition to the motion for expedited treatment.  On November 5, 2018, the Chancery Court scheduled a trial on the matter for November 19, 2018.  Prior to the scheduled trial, on November 15, 2018, the plaintiffs voluntarily dismissed this action against the Company.

[0001571996-18-000044:notes:252]
On November 8, 2018, Hallandale Beach Police and Fire Retirement Plan filed a putative stockholder class action lawsuit against our directors and Michael S. Dell, a separate property trust for the benefit of Mr. Dell’s wife, investment funds affiliated with Silver Lake Partners, and investment funds affiliated with MSD Partners, L.P. in Delaware Chancery Court, alleging, among other things, that the directors of the Company breached their fiduciary duties to holders of the Class V Common Stock in connection with the Class V transaction, because, among other things, the Class V transaction is allegedly financially unfair and coercive to holders of the Class V Common Stock and there were various conflicts of interest (Hallandale Beach Police and Fire Retirement Plan v. Michael Dell, et al., No. 2018-0816-JTL (Del. Ch. filed November 8, 2018)). The lawsuit seeks, among other things, a judicial declaration that that defendants breached their fiduciary duties and an award of damages, fees and costs.

[0001571996-18-000044:notes:253]
As of November 2, 2018, the Company does not believe there is a reasonable possibility that a material loss exceeding the amounts already accrued for these or other proceedings or matters has been incurred.  However, since the ultimate resolution of any such proceedings and matters is inherently unpredictable, the Company’s business, financial condition, results of operations, or cash flows could be materially affected in any particular period by unfavorable outcomes in one or more of these proceedings or matters.  Whether the outcome of any claim, suit, assessment, investigation, or legal proceeding, individually or collectively, could have a material adverse effect on the Company’s business, financial condition, results of operations, or cash flows will depend on a number of variables, including the nature, timing, and amount of any associated expenses, amounts paid in settlement, damages, or other remedies or consequences.

[0001571996-18-000044:notes:254]
Indemnifications

[0001571996-18-000044:notes:255]
In the ordinary course of business, the Company enters into contractual arrangements under which it may agree to indemnify the third party to such arrangements from any losses incurred relating to the services it performs on behalf of the Company or for losses arising from certain events as defined in the particular contract, such as litigation or claims relating to past performance.  Such indemnification obligations may not be subject to maximum loss clauses.  Historically, payments related to these indemnifications have not been material to the Company.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001571996-18-000044:notes:256]
NOTE 12 — INCOME AND OTHER TAXES

[0001571996-18-000044:notes:257]
For the three months ended November 2, 2018 and November 3, 2017, the Company’s effective income tax rates were 10.1% and 22.1%, respectively, on pre-tax losses of $1.0 billion and $1.1 billion, respectively.  For the nine months ended November 2, 2018 and November 3, 2017, the Company’s effective income tax rates were 9.2% and 32.6%, respectively, on pre-tax losses of $2.1 billion and $4.1 billion, respectively.  The changes in the Company’s effective income tax rates for the three and nine months ended November 2, 2018 compared to the prior periods were primarily attributable to impacts of the Tax Cuts and Jobs Act of 2017 (“U.S. Tax Reform” or the “Act”).  The change in the Company’s effective income tax rate for the nine months ended November 2, 2018 was also impacted by discrete tax benefits resulting from the impact of adopting the new revenue standard.

[0001571996-18-000044:notes:258]
U.S. Tax Reform was signed into law on December 22, 2017.  Among other things, U.S. Tax Reform lowers the U.S. corporate income tax rate to 21% from 35%, establishes a modified territorial system requiring a mandatory deemed repatriation tax on undistributed earnings of foreign subsidiaries (the “Transition Tax”), requires a minimum tax on certain future earnings generated by foreign subsidiaries while providing for future tax-free repatriation of earnings through a 100% dividends-received deduction, and places limitations on the deductibility of net interest expense.

[0001571996-18-000044:notes:259]
GAAP requires the effect of a change in tax laws to be recognized in the period that includes the enactment date.  Due to the complexities involved in accounting for the enactment of U.S. Tax Reform, the SEC staff issued Staff Accounting Bulletin No. 118 (“SAB 118”), which allows companies to record provisional amounts in earnings for the first year following the Act’s enactment, with those provisional amounts required to be finalized by the end of that year.  In accordance with GAAP and SAB 118, for the fiscal year ended February 2, 2018, the Company recognized a provisional tax benefit of $0.5 billion, which was primarily driven by a $1.5 billion tax benefit related to the remeasurement of deferred tax assets and liabilities, offset by $1.0 billion of current and future income tax expenses related to the Transition Tax.  The Company’s provisional estimates for the Transition Tax are based on its initial analysis using available information and estimates.  The Company continues to collect and process the data necessary to complete its determination of the accounting implications of U.S. Tax Reform, as well as to evaluate the impact of recently proposed guidance issued by the U.S. Treasury Department on the provisional calculation.  Any final guidance to be issued by the U.S. Treasury Department also could further affect the provisional calculation.   As a result, no adjustments have been made to the provisional amount recorded for the fiscal year ended February 2, 2018.  In accordance with SAB 118, any adjustments to the Company’s provision estimates will be complete by the fourth quarter of the fiscal year ending February 1, 2019.  Revisions to the Company’s provisional estimates may be material to the Company.

[0001571996-18-000044:notes:260]
The differences between the estimated effective income tax rates and the U.S. federal statutory rate of 21% principally result from the Company’s geographical distribution of income and differences between the book and tax treatment of certain items.  In certain jurisdictions, the Company’s tax rate is significantly less than the applicable statutory rate as a result of tax holidays.  The majority of the Company’s foreign income that is subject to these tax holidays and lower tax rates is attributable to Singapore, China, and Malaysia.  A significant portion of these income tax benefits is related to a tax holiday that will expire at the end of the fiscal year ending February 1, 2019.  The Company is currently seeking new terms for the affected subsidiary beyond the fiscal year ending February 1, 2019, and it is uncertain whether any terms will be agreed upon.  The Company’s other tax holidays will expire in whole or in part during fiscal years 2019 through 2023.  Many of these tax holidays and reduced tax rates may be extended when certain conditions are met or may be terminated early if certain conditions are not met.

[0001571996-18-000044:notes:261]
The Company’s U.S. federal income tax returns for fiscal years 2007 through 2009 are currently under consideration by the Office of Appeals of the Internal Revenue Service (the “IRS”).  The IRS issued a Revenue Agent’s Report (“RAR”) related to those years during the fiscal year ended February 3, 2017.  The IRS has proposed adjustments primarily relating to transfer pricing matters with which the Company disagrees and is contesting through the IRS administrative appeals process.  In May 2017, the IRS commenced a federal income tax audit for fiscal years 2010 through 2014, which could take several years to complete.

[0001571996-18-000044:notes:262]
[same as prior period, unchanged from 0001571996-18-000034:notes:198]

[0001571996-18-000044:notes:263]
[same as prior period, unchanged from 0001571996-18-000034:notes:199]

[0001571996-18-000044:notes:264]
Judgment is required in evaluating the Company’s uncertain tax positions and determining the Company’s provision for income taxes.  The unrecognized tax benefits were $3.2 billion as of both November 2, 2018 and February 2, 2018 and are included in other non-current liabilities in the Condensed Consolidated Statements of Financial Position.  The Company does not anticipate a significant change to the total amount of unrecognized tax benefits within the next twelve months.

[0001571996-18-000044:notes:265]
The Company takes certain non-income tax positions in the jurisdictions in which it operates and has received certain non-income tax assessments from various jurisdictions.  The Company believes that a material loss in these matters is not probable and that it is not reasonably possible that a material loss exceeding amounts already accrued has been incurred.  The Company believes its positions in these non-income tax litigation matters are supportable and that it ultimately will prevail in the matters.  In the normal course of business, the Company’s positions and conclusions related to its non-income taxes could be challenged and assessments may be made.  To the extent new information is obtained and the Company’s views on its positions, probable outcomes of assessments, or litigation change, changes in estimates to the Company’s accrued liabilities would be recorded in the period in which such a determination is made.  In the resolution process for income tax and non-income tax audits, in certain situations the Company is required to provide collateral guarantees or indemnification to regulators and tax authorities until the matter is resolved.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001571996-18-000044:notes:266]
NOTE 13 — ACCUMULATED OTHER COMPREHENSIVE INCOME (LOSS)

[0001571996-18-000044:notes:267]
Accumulated other comprehensive income (loss) is presented in stockholders’ equity in the Condensed Consolidated Statements of Financial Position and consists of amounts related to foreign currency translation adjustments, unrealized net gains (losses) on investments, unrealized net gains (losses) on cash flow hedges, and actuarial net gains (losses) from pension and other postretirement plans.

[0001571996-18-000044:notes:268]
[same as prior period, unchanged from 0001571996-18-000034:notes:80]

[0001571996-18-000044:notes:269]
|  | Foreign Currency Translation Adjustments |  | Investments |  | Cash Flow Hedges |  | Pension and Other Postretirement Plans |  | Accumulated Other Comprehensive Income (Loss) |
|  | (in millions) |
| Balances as of February 2, 2018 | $ | 179 |  |  | $ | 22 |  |  | $ | (103 | ) |  | $ | 32 |  |  | $ | 130 |  |
| Adjustment for adoption of accounting standards (Note 1) | — |  |  | (61 | ) |  | — |  |  | 3 |  |  | (58 | ) |
| Other comprehensive income (loss) before reclassifications | (721 | ) |  | (2 | ) |  | 314 |  |  | — |  |  | (409 | ) |
| Amounts reclassified from accumulated other comprehensive income (loss) | — |  |  | (1 | ) |  | (122 | ) |  | — |  |  | (123 | ) |
| Total change for the period | (721 | ) |  | (64 | ) |  | 192 |  |  | 3 |  |  | (590 | ) |
| Less: Change in comprehensive loss attributable to non-controlling interests | — |  |  | (2 | ) |  | (2 | ) |  | — |  |  | (4 | ) |
| Balances as of November 2, 2018 | $ | (542 | ) |  | $ | (40 | ) |  | $ | 91 |  |  | $ | 35 |  |  | $ | (456 | ) |

[0001571996-18-000044:notes:270]
Amounts related to investments are reclassified to net income when gains and losses are realized.  See Note 3 and Note 4 of the Notes to the Condensed Consolidated Financial Statements for more information on the Company’s investments.  Amounts related to the Company’s cash flow hedges are reclassified to net income during the same period in which the items being hedged are recognized in earnings.  See Note 7 of the Notes to the Condensed Consolidated Financial Statements for more information on the Company’s derivative instruments.

[0001571996-18-000044:notes:271]
[same as prior period, unchanged from 0001571996-18-000034:notes:83]

[0001571996-18-000044:notes:272]
|  | Three Months Ended |
|  | November 2, 2018 |  | November 3, 2017 |
|  | Investments |  | Cash Flow Hedges |  | Total |  | Investments |  | Cash Flow Hedges |  | Total |
|  | (in millions) |
| Total reclassifications, net of tax: |  |  |  |  |  |  |  |  |  |  |  |
| Net revenue | $ | — |  |  | $ | 76 |  |  | $ | 76 |  |  | $ | — |  |  | $ | (18 | ) |  | $ | (18 | ) |
| Cost of net revenue | — |  |  | — |  |  | — |  |  | — |  |  | (13 | ) |  | (13 | ) |
| Interest and other, net | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Total reclassifications, net of tax | $ | — |  |  | $ | 76 |  |  | $ | 76 |  |  | $ | — |  |  | $ | (31 | ) |  | $ | (31 | ) |
|  | Nine Months Ended |
|  | November 2, 2018 |  | November 3, 2017 |
|  | Investments |  | Cash Flow Hedges |  | Total |  | Investments |  | Cash Flow Hedges |  | Total |
|  | (in millions) |
| Total reclassifications, net of tax: |  |  |  |  |  |  |  |  |  |  |  |
| Net revenue | $ | — |  |  | $ | 122 |  |  | $ | 122 |  |  | $ | — |  |  | $ | (50 | ) |  | $ | (50 | ) |
| Cost of net revenue | — |  |  | — |  |  | — |  |  | — |  |  | (30 | ) |  | (30 | ) |
| Interest and other, net | 1 |  |  | — |  |  | 1 |  |  | (3 | ) |  | — |  |  | (3 | ) |
| Total reclassifications, net of tax | $ | 1 |  |  | $ | 122 |  |  | $ | 123 |  |  | $ | (3 | ) |  | $ | (80 | ) |  | $ | (83 | ) |


## us-gaap:MinorityInterestDisclosureTextBlock

[0001571996-18-000044:notes:273]
NOTE 14 — NON-CONTROLLING INTERESTS

[0001571996-18-000044:notes:274]
VMware, Inc. — The non-controlling interests’ share of equity in VMware, Inc. is reflected as a component of the non-controlling interests in the accompanying Condensed Consolidated Statements of Financial Position and was $5.8 billion and $5.2 billion as of November 2, 2018 and February 2, 2018, respectively.  As of November 2, 2018 and February 2, 2018, the Company held approximately 80.7% and 81.9%, respectively, of the outstanding equity interest in VMware, Inc.

[0001571996-18-000044:notes:275]
Pivotal — On April 24, 2018, Pivotal completed a registered underwritten IPO of its Class A common stock.  In conjunction with the IPO, all of Pivotal’s preferred equity shares were converted into shares of its common stock on a one-to-one basis, such that upon completion of its IPO, Pivotal’s outstanding capital stock consisted solely of common stock.  The non-controlling interests’ share of equity in Pivotal is reflected as a component of the non-controlling interest in the accompanying Condensed Consolidated Statements of Financial Position and was $959 million and $489 million as of November 2, 2018 and February 2, 2018, respectively.  The increase in non-controlling interest for Pivotal is primarily due to the IPO completed during the three months ended May 4, 2018.  As of November 2, 2018 and February 2, 2018, the Company held approximately 63.7% and 77.1%, respectively, of the outstanding equity interest in Pivotal.

[0001571996-18-000044:notes:276]
SecureWorks — The non-controlling interests’ share of equity in SecureWorks is reflected as a component of the non-controlling interests in the accompanying Condensed Consolidated Statements of Financial Position and was $96 million and $90 million as of November 2, 2018 and February 2, 2018, respectively.  As of November 2, 2018 and February 2, 2018, the Company held approximately 86.6% and 87.1%, respectively, of the outstanding equity interest in SecureWorks, excluding restricted stock awards (“RSAs”).  As of November 2, 2018 and February 2, 2018, the Company held approximately 85.6% and 86.3%, respectively, of the outstanding equity interest in SecureWorks, including RSAs.

[0001571996-18-000044:notes:277]
The effect of changes in the Company’s ownership interest in VMware, Inc., Pivotal, and SecureWorks on the Company’s equity was as follows:

[0001571996-18-000044:notes:278]
|  | Nine Months Ended |
|  | November 2, 2018 |
|  | (in millions) |
| Net loss attributable to Dell Technologies Inc. | $ | (2,011 | ) |
| Transfers (to) from the non-controlling interests: |  |
| Increase in Dell Technologies Inc. additional paid-in-capital for equity issuances and other equity activity | 783 |  |
| Decrease in Dell Technologies Inc. additional paid-in-capital for equity issuances and other equity activity | (667 | ) |
| Net transfers from non-controlling interests | 116 |  |
| Change from net loss attributable to Dell Technologies Inc. and transfers to/from the non-controlling interests | $ | (1,895 | ) |


## us-gaap:EarningsPerShareTextBlock

[0001571996-18-000044:notes:279]
NOTE 15 — EARNINGS (LOSS) PER SHARE

[0001571996-18-000044:notes:280]
[same as prior period, unchanged from 0001571996-18-000034:notes:149]

[0001571996-18-000044:notes:281]
The Company has two groups of common stock, denoted as the DHI Group Common Stock and the Class V Common Stock.  The DHI Group Common Stock consists of four classes of common stock, referred to as Class A Common Stock, Class B Common Stock, Class C Common Stock, and Class D Common Stock.  The DHI Group generally refers to the direct and indirect interest of Dell Technologies in all of Dell Technologies’ business, assets, properties, liabilities, and preferred stock other than those attributable to the Class V Group, as well as the DHI Group’s retained interest in the Class V Group equal to approximately 39% of the Company’s economic interest in the Class V Group as of November 2, 2018.  The Class V Common Stock is intended to track the economic performance of approximately 61% of the Company’s economic interest in the Class V Group as of such date.  The Class V Group consists solely of VMware, Inc. common stock held by the Company.  As of November 2, 2018, the Class V Group consisted of approximately 331 million shares of VMware, Inc. common stock.  See Note 16 of the Notes to the Condensed Consolidated Financial Statements and Exhibit 99.1 filed with the Company’s Quarterly Report on Form 10-Q for the quarterly period ended November 2, 2018 for more information regarding the allocation of earnings from Dell Technologies’ interest in VMware, Inc. between the DHI Group and the Class V Common Stock.

[0001571996-18-000044:notes:282]
[same as prior period, unchanged from 0001571996-18-000034:notes:151]

[0001571996-18-000044:notes:283]
[same as prior period, unchanged from 0001571996-18-000034:notes:152]

[0001571996-18-000044:notes:284]
|  | Three Months Ended |  | Nine Months Ended |
|  | November 2, 2018 |  | November 3, 2017 |  | November 2, 2018 |  | November 3, 2017 |
| Earnings (loss) per share attributable to Dell Technologies Inc. - basic: |  |  |  |  |
| Class V Common Stock - basic | $ | 0.83 |  |  | $ | 0.98 |  |  | $ | 4.80 |  |  | $ | 2.58 |  |
| DHI Group - basic | $ | (1.84 | ) |  | $ | (1.84 | ) |  | $ | (5.23 | ) |  | $ | (5.78 | ) |
| Earnings (loss) per share attributable to Dell Technologies Inc. - diluted: |  |  |  |  |
| Class V Common Stock - diluted | $ | 0.81 |  |  | $ | 0.96 |  |  | $ | 4.72 |  |  | $ | 2.54 |  |
| DHI Group - diluted | $ | (1.84 | ) |  | $ | (1.84 | ) |  | $ | (5.25 | ) |  | $ | (5.79 | ) |

[0001571996-18-000044:notes:285]
[same as prior period, unchanged from 0001571996-18-000034:notes:154]

[0001571996-18-000044:notes:286]
|  | Three Months Ended |  | Nine Months Ended |
|  | November 2, 2018 |  | November 3, 2017 |  | November 2, 2018 |  | November 3, 2017 |
|  | (in millions) |
| Numerator: Class V Common Stock |  |  |  |  |  |  |  |
| Net income attributable to Class V Common Stock - basic | $ | 165 |  |  | $ | 198 |  |  | $ | 955 |  |  | $ | 527 |  |
| Incremental dilution from VMware, Inc. attributable to Class V Common Stock (a) | (3 | ) |  | (4 | ) |  | (15 | ) |  | (8 | ) |
| Net income attributable to Class V Common Stock - diluted | $ | 162 |  |  | $ | 194 |  |  | $ | 940 |  |  | $ | 519 |  |
| Numerator: DHI Group |  |  |  |  |  |  |  |
| Net loss attributable to DHI Group - basic | $ | (1,041 | ) |  | $ | (1,044 | ) |  | $ | (2,966 | ) |  | $ | (3,276 | ) |
| Incremental dilution from VMware, Inc. attributable to DHI Group (a) | (1 | ) |  | (2 | ) |  | (9 | ) |  | (5 | ) |
| Net loss attributable to DHI Group - diluted | $ | (1,042 | ) |  | $ | (1,046 | ) |  | $ | (2,975 | ) |  | $ | (3,281 | ) |
| Denominator: Class V Common Stock weighted-average shares outstanding |  |  |  |  |  |  |  |  |  |  |  |
| Weighted-average shares outstanding - basic | 199 |  |  | 202 |  |  | 199 |  |  | 204 |  |
| Dilutive effect of options, restricted stock units, restricted stock, and other (b) | — |  |  | — |  |  | — |  |  | — |  |
| Weighted-average shares outstanding - diluted | 199 |  |  | 202 |  |  | 199 |  |  | 204 |  |
| Weighted-average shares outstanding - antidilutive (b) | — |  |  | — |  |  | — |  |  | — |  |
| Denominator: DHI Group weighted-average shares outstanding |  |  |  |  |  |  |  |
| Weighted-average shares outstanding - basic | 567 |  |  | 567 |  |  | 567 |  |  | 567 |  |
| Dilutive effect of options, restricted stock units, restricted stock, and other | — |  |  | — |  |  | — |  |  | — |  |
| Weighted-average shares outstanding - diluted | 567 |  |  | 567 |  |  | 567 |  |  | 567 |  |
| Weighted-average shares outstanding - antidilutive (c) | 46 |  |  | 34 |  |  | 47 |  |  | 36 |  |

[0001571996-18-000044:notes:287]
| (a) | The incremental dilution from VMware, Inc. represents the impact of VMware, Inc.’s dilutive securities on the diluted earnings (loss) per share of the DHI Group and the Class V Common Stock, respectively, and is calculated by multiplying the difference between VMware, Inc.’s basic and diluted earnings (loss) per share by the number of shares of VMware, Inc. common stock held by the Company. |

[0001571996-18-000044:notes:288]
[same as prior period, unchanged from 0001571996-18-000034:notes:157]

[0001571996-18-000044:notes:289]
| (c) | Stock-based incentive awards have been excluded from the calculation of the DHI Group’s diluted earnings (loss) per share because their effect would have been antidilutive, as the Company had a net loss from continuing operations attributable to the DHI Group for the periods presented. |

[0001571996-18-000044:notes:290]
The following table presents a reconciliation to the consolidated net income (loss) attributable to Dell Technologies Inc.:

[0001571996-18-000044:notes:291]
|  | Three Months Ended |  | Nine Months Ended |
|  | November 2, 2018 |  | November 3, 2017 |  | November 2, 2018 |  | November 3, 2017 |
|  | (in millions) |
| Net income attributable to Class V Common Stock | $ | 165 |  |  | $ | 198 |  |  | $ | 955 |  |  | $ | 527 |  |
| Net loss attributable to DHI Group | (1,041 | ) |  | (1,044 | ) |  | (2,966 | ) |  | (3,276 | ) |
| Net loss attributable to Dell Technologies Inc. | $ | (876 | ) |  | $ | (846 | ) |  | $ | (2,011 | ) |  | $ | (2,749 | ) |


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001571996-18-000044:notes:292]
NOTE 16 — CAPITALIZATION

[0001571996-18-000044:notes:293]
The following table summarizes the Company’s authorized, issued, and outstanding common stock as of the dates indicated:

[0001571996-18-000044:notes:294]
|  | Authorized |  | Issued |  | Outstanding |
|  | (in millions of shares) |
| Common stock as of February 2, 2018 |
| Class A | 600 |  |  | 410 |  |  | 410 |  |
| Class B | 200 |  |  | 137 |  |  | 137 |  |
| Class C | 7,900 |  |  | 24 |  |  | 23 |  |
| Class D | 100 |  |  | — |  |  | — |  |
| Class V | 343 |  |  | 223 |  |  | 199 |  |
|  | 9,143 |  |  | 794 |  |  | 769 |  |
| Common stock as of November 2, 2018 |
| Class A | 600 |  |  | 410 |  |  | 410 |  |
| Class B | 200 |  |  | 137 |  |  | 137 |  |
| Class C | 7,900 |  |  | 24 |  |  | 22 |  |
| Class D | 100 |  |  | — |  |  | — |  |
| Class V | 343 |  |  | 223 |  |  | 199 |  |
|  | 9,143 |  |  | 794 |  |  | 768 |  |

[0001571996-18-000044:notes:295]
[same as prior period, unchanged from 0001571996-18-000034:notes:306]

[0001571996-18-000044:notes:296]
The Company is authorized to issue one million shares of preferred stock, par value $.01 per share.  As of November 2, 2018, no shares of preferred stock were issued or outstanding.

[0001571996-18-000044:notes:297]
[same as prior period, unchanged from 0001571996-18-000034:notes:308]

[0001571996-18-000044:notes:298]
DHI Group Common Stock and DHI Group— The Class A Common Stock, the Class B Common Stock, the Class C Common Stock, and the Class D Common Stock are collectively referred to as the DHI Group Common Stock.  The par value for all classes of DHI Group Common Stock is $.01 per share.  The Class A Common Stock, the Class B Common Stock, the Class C Common Stock, and the Class D Common Stock share equally in dividends declared or accumulated and have equal participation rights in undistributed earnings.  The DHI Group generally refers to the direct and indirect interest of Dell Technologies in all of Dell Technologies’ business, assets, properties, liabilities, and preferred stock other than those attributable to the Class V Group, as well as the DHI Group’s retained interest in the Class V Group.

[0001571996-18-000044:notes:299]
Class V Common Stock and Class V Group — In connection with the EMC merger transaction, the Company authorized 343 million shares of Class V Common Stock.  The Class V Common Stock is a type of common stock commonly referred to as a tracking stock, which is a class of common stock that is intended to track the economic performance of a defined set of assets and liabilities.  As of November 2, 2018, the 199 million shares of outstanding Class V Common Stock were intended to track the economic performance of approximately 61% of Dell Technologies’ economic interest in the Class V Group.  The Class V Group as of such date consisted solely of approximately 331 million shares of VMware, Inc. common stock held by the Company.  The remaining 39% economic interest in the Class V Group as of November 2, 2018 was represented by the approximately 127 million retained interest shares held by the DHI Group.

[0001571996-18-000044:notes:300]
[same as prior period, unchanged from 0001571996-18-000034:notes:311]

[0001571996-18-000044:notes:301]
[same as prior period, unchanged from 0001571996-18-000034:notes:312]

[0001571996-18-000044:notes:302]
Since the date of the EMC merger transaction, the Company has authorized several programs to repurchase shares of its Class V Common Stock.  Of the $2.1 billion total authorized for repurchases under the programs, $676 million remained available as of November 2, 2018, all of which is attributable to the DHI Group Repurchase Program, which the board of directors suspended on December 13, 2016 until such time as it authorizes the reinstatement of that program.

[0001571996-18-000044:notes:303]
During the three months ended November 2, 2018, the Company did not repurchase any Class V Common Stock.  During the three months ended November 3, 2017, the Company repurchased 3.8 million shares of Class V Common Stock for an aggregate purchase price of $300 million.  The repurchase of these shares was funded by proceeds received by the Class V Group from the sale by a subsidiary of the Company of shares of Class A common stock of VMware, Inc. owned by such subsidiary.  Share repurchases made by VMware, Inc. of its Class A common stock from a subsidiary of the Company do not affect the determination of the respective interests of the Class V Common Stock and the DHI Group in the Class V Group.  See Exhibit 99.1 filed with the Quarterly Report on Form 10-Q for the three months ended November 2, 2018 for more information regarding Unaudited Attributed Financial Information for the Class V Group.

[0001571996-18-000044:notes:304]
[same as prior period, unchanged from 0001571996-18-000034:notes:315]

[0001571996-18-000044:notes:305]
[same as prior period, unchanged from 0001571996-18-000034:notes:316]

[0001571996-18-000044:notes:306]
During the three months ended November 2, 2018, the Company did not repurchase any shares of DHI Group Common Stock.   During the three months ended November 3, 2017, the Company repurchased an immaterial number of shares of DHI Group Common Stock for approximately $4 million.

[0001571996-18-000044:notes:307]
[same as prior period, unchanged from 0001571996-18-000034:notes:318]

[0001571996-18-000044:notes:308]
[same as prior period, unchanged from 0001571996-18-000034:notes:319]

[0001571996-18-000044:notes:309]
Since the date of the EMC merger transaction, VMware, Inc.’s board of directors has authorized the repurchase of a total of $2.2 billion of VMware, Inc.’s Class A common stock, of which $876 million remained available as of November 2, 2018.

[0001571996-18-000044:notes:310]
During the three months ended November 2, 2018, VMware, Inc. did not repurchase any of its Class A common stock. During the three months and nine months ended November 3, 2017, VMware, Inc. repurchased 5.1 million shares of its Class A common stock in the open market for $555 million.

[0001571996-18-000044:notes:311]
All shares repurchased under VMware, Inc.’s stock repurchase programs are retired.

[0001571996-18-000044:notes:312]
[same as prior period, unchanged from 0001571996-18-000034:notes:323]

[0001571996-18-000044:notes:313]
On July 2, 2018, the Company announced that it had completed its evaluation of potential strategic business opportunities.  As a result of such evaluation, the Company has determined to pursue a transaction, referred to as the “Class V transaction,” pursuant to an Agreement and Plan of Merger (the “Merger Agreement”), dated as of July 1, 2018, between the Company and Teton Merger Sub Inc. (“Merger Sub”), a Delaware corporation and wholly-owned subsidiary of the Company.  The Merger Agreement provides, among other things and subject to the terms and conditions set forth therein, that Merger Sub will be merged with and into the Company (the “Merger”), with the Company continuing as the surviving corporation.

[0001571996-18-000044:notes:314]
The Merger Agreement provides that, subject to the terms and conditions thereof, at the effective time of the Merger (the “Effective Time”), each share of Class V Common Stock that is issued and outstanding immediately prior to the Effective Time will be canceled and converted into the right to receive, at the holder’s election, (i) 1.3665 shares (the “Share Consideration”) of Class C Common Stock or (ii) $109.00 in cash, without interest (the “Cash Consideration”), subject to an aggregate amount of Cash Consideration that may be received by holders of Class V Common Stock in the Merger not exceeding $9 billion (the “Aggregate Cash Consideration Cap”).

[0001571996-18-000044:notes:315]
If the total amount of Cash Consideration elected by holders of Class V Common Stock would exceed the Aggregate Cash Consideration Cap, a portion of the shares with respect to which a holder elects to receive the Cash Consideration equal to a fraction, the numerator of which is the Aggregate Cash Consideration Cap and the denominator of which is the aggregate amount of Cash Consideration elected by holders, will be converted into the right to receive the Cash Consideration and the remaining portion of such shares held by such holders will be converted into the right to receive the Share Consideration.  Any share of Class V Common Stock for which a valid election to receive Cash Consideration is not in effect at the Effective Time will be converted into Share Consideration.  Upon consummation of the Merger, all shares of the Class V Common Stock would be delisted from the New York Stock Exchange and the Class C Common Stock would be listed on the New York Stock Exchange.

[0001571996-18-000044:notes:316]
In addition, pursuant to the Merger Agreement, as of the Effective Time and unless otherwise agreed by the Company and a holder of a Class V Common Stock-based equity award granted by the Company (a “Class V Award”), each Class V Award will be converted into a new equity award on the same terms and conditions (including applicable vesting requirements and deferral provisions) with respect to the number of shares of Class C Common Stock that is equal to the number of shares of Class V Common Stock that were subject to the Class V Award multiplied by 1.3665 (rounded down to the nearest whole share).  The exercise price for any Class V Award options so converted will equal the exercise price of such Class V Award options immediately prior to the Effective Time divided by 1.3665 (rounded up to the nearest whole penny).

[0001571996-18-000044:notes:317]
In connection with the Merger Agreement, the board of directors of VMware, Inc. declared a conditional $11 billion one‑time special cash dividend pro rata to holders of VMware, Inc. common stock.  Immediately prior to the completion of the Class V transaction, subject to the satisfaction of other conditions of the Class V transaction, as well as certain other conditions, VMware, Inc. will pay the special cash dividend to its stockholders.  Approximately $8.87 billion of the VMware, Inc. cash dividend will be received by the Company and used to fund all or substantially all of the Cash Consideration paid to holders of the Class V Common Stock in the Class V transaction.  The Company will fund any remaining cash consideration, which is not expected to be material, from cash on hand.

[0001571996-18-000044:notes:318]
[same as prior period, unchanged from 0001571996-18-000034:notes:328]

[0001571996-18-000044:notes:319]
[same as prior period, unchanged from 0001571996-18-000034:notes:329]

[0001571996-18-000044:notes:320]
On October 3, 2018, the Company announced that as a potential contingency plan in the event the Class V transaction is not consummated, it had met with certain investment banks to explore a potential initial public offering of its Class C Common Stock.  There is no assurance that the Company’s board of directors will determine to proceed with an initial public offering of its Class C Common Stock in the event that the Class V transaction is not consummated.

[0001571996-18-000044:notes:321]
On November 14, 2018, the Company and Merger Sub entered into an amendment to the Merger Agreement which, among other things, increases the Aggregate Cash Consideration Cap, the Share Consideration, and the Cash Consideration, and provides for certain corporate governance changes to be implemented following the closing of the Merger. See Note 20 of the Notes to the Condensed Consolidated Financial Statements for further information regarding the amended Class V transaction.


## us-gaap:ShareholdersEquityAndShareBasedPaymentsTextBlock

[0001571996-18-000044:notes:322]
NOTE 17 — REDEEMABLE SHARES

[0001571996-18-000044:notes:323]
Awards under the Company’s stock incentive plans include certain rights that allow the holder to exercise a put feature for the underlying Class A or Class C Common Stock after a six month holding period following the issuance of such common stock.  The put feature requires the Company to purchase the stock at its fair market value.  Accordingly, these awards and such common stock are subject to reclassification from equity to temporary equity, and the Company determines the award amounts to be classified as temporary equity as follows:

[0001571996-18-000044:notes:324]
[same as prior period, unchanged from 0001571996-18-000034:notes:298]

[0001571996-18-000044:notes:325]
| • | For stock appreciation rights, restricted stock units (“RSUs”), or RSAs, any of which stock award types are subject to service requirements, the fair value of the share is multiplied by the portion of the share for which services have been rendered. |

[0001571996-18-000044:notes:326]
| • | For share-based arrangements that are subject to the occurrence of a contingent event, those amounts are not reclassified to temporary equity until the contingency has been satisfied. Contingent events include the achievement of performance-based metrics. |

[0001571996-18-000044:notes:327]
The following table sets forth the amount of redeemable shares classified as temporary equity and summarizes the award type as of the dates indicated:

[0001571996-18-000044:notes:328]
|  | November 2, 2018 |  | February 2, 2018 |
|  | (in millions) |
| Redeemable shares classified as temporary equity | $ | 2,095 |  |  | $ | 384 |  |
| Issued and outstanding unrestricted common shares | 2.3 |  |  | 2.9 |  |
| Restricted stock units | 3.6 |  |  | 0.4 |  |
| Restricted stock awards | 1.4 |  |  | 0.1 |  |
| Outstanding stock options | 30.8 |  |  | 15.3 |  |

[0001571996-18-000044:notes:329]
The increase in the value of redeemable shares during the nine months ended November 2, 2018 was primarily attributable to an increase in DHI Group Common Stock fair value, as well as the reassessment of vesting of performance-based awards.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001571996-18-000044:notes:330]
NOTE 18 — SEGMENT INFORMATION

[0001571996-18-000044:notes:331]
The Company has three reportable segments that are based on the following business units:  Infrastructure Solutions Group (“ISG”); Client Solutions Group (“CSG”); and VMware.

[0001571996-18-000044:notes:332]
ISG previously included Virtustream product and service offerings.  Virtustream’s cloud software and infrastructure-as-a-service solutions enable customers to migrate, run, and manage mission-critical applications in cloud-based IT environments.  During the three months ended May 4, 2018, the Company made certain segment reporting changes, which included the movement of Virtustream’s results from ISG to Other businesses.  None of these changes impacted the Company’s previously reported consolidated financial results, but the Company’s prior period segment results have been recast to reflect this change.

[0001571996-18-000044:notes:333]
[same as prior period, unchanged from 0001571996-18-000034:notes:293]

[0001571996-18-000044:notes:334]
The reportable segments disclosed herein are based on information reviewed by the Company’s management to evaluate the business segment results.  The Company’s measure of segment operating income for management reporting purposes excludes the impact of other businesses, purchase accounting, amortization of intangible assets, unallocated corporate transactions, severance and facility action costs, and transaction-related expenses.  The Company does not allocate assets to the above reportable segments for internal reporting purposes.

[0001571996-18-000044:notes:335]
The following table presents a reconciliation of net revenue by the Company’s reportable segments to the Company’s consolidated net revenue as well as a reconciliation of consolidated segment operating income to the Company’s consolidated operating loss:

[0001571996-18-000044:notes:336]
|  | Three Months Ended |  | Nine Months Ended |
|  | November 2, 2018 |  | November 3, 2017 |  | November 2, 2018 |  | November 3, 2017 |
|  | (in millions) |
| Consolidated net revenue: |  |  |  |  |  |  |  |  |  |  |
| Infrastructure Solutions Group | $ | 8,937 |  |  | $ | 7,535 |  |  | $ | 26,831 |  |  | $ | 21,963 |  |
| Client Solutions Group | 10,905 |  |  | 9,829 |  |  | 32,304 |  |  | 28,743 |  |
| VMware | 2,229 |  |  | 1,933 |  |  | 6,451 |  |  | 5,735 |  |
| Reportable segment net revenue | 22,071 |  |  | 19,297 |  |  | 65,586 |  |  | 56,441 |  |
| Other businesses (a) | 583 |  |  | 557 |  |  | 1,736 |  |  | 1,629 |  |
| Unallocated transactions (b) | (3 | ) |  | (3 | ) |  | (6 | ) |  | (8 | ) |
| Impact of purchase accounting (c) | (169 | ) |  | (295 | ) |  | (536 | ) |  | (985 | ) |
| Total net revenue | $ | 22,482 |  |  | $ | 19,556 |  |  | $ | 66,780 |  |  | $ | 57,077 |  |
| Consolidated operating income (loss): |  |  |  |  |  |  |  |
| Infrastructure Solutions Group | $ | 935 |  |  | $ | 870 |  |  | $ | 2,886 |  |  | $ | 2,023 |  |
| Client Solutions Group | 447 |  |  | 630 |  |  | 1,405 |  |  | 1,483 |  |
| VMware | 768 |  |  | 634 |  |  | 2,117 |  |  | 1,973 |  |
| Reportable segment operating income | 2,150 |  |  | 2,134 |  |  | 6,408 |  |  | 5,479 |  |
| Other businesses (a) | (40 | ) |  | (19 | ) |  | (139 | ) |  | (71 | ) |
| Unallocated transactions (b) | (46 | ) |  | (6 | ) |  | (71 | ) |  | (8 | ) |
| Impact of purchase accounting (c) | (193 | ) |  | (366 | ) |  | (630 | ) |  | (1,195 | ) |
| Amortization of intangibles | (1,546 | ) |  | (1,734 | ) |  | (4,594 | ) |  | (5,250 | ) |
| Transaction-related expenses (d) | (167 | ) |  | (86 | ) |  | (437 | ) |  | (415 | ) |
| Other corporate expenses (e) | (514 | ) |  | (333 | ) |  | (1,059 | ) |  | (887 | ) |
| Total operating loss | $ | (356 | ) |  | $ | (410 | ) |  | $ | (522 | ) |  | $ | (2,347 | ) |

[0001571996-18-000044:notes:337]
_________________

[0001571996-18-000044:notes:338]
| (a) | Pivotal, SecureWorks, RSA Security, Virtustream, and Boomi constitute “Other businesses” and do not meet the requirements for a reportable segment, either individually or collectively. The results of Other businesses are not material to the Company’s overall results. |

[0001571996-18-000044:notes:339]
| (b) | Unallocated transactions includes long-term incentives, certain short-term incentive compensation expenses, and other corporate items that are not allocated to Dell Technologies’ reportable segments. |

[0001571996-18-000044:notes:340]
| (c) | Impact of purchase accounting includes non-cash purchase accounting adjustments that are primarily related to the EMC merger transaction. |

[0001571996-18-000044:notes:341]
| (d) | Transaction-related expenses includes acquisition, integration, and divestiture related costs. |

[0001571996-18-000044:notes:342]
| (e) | Other corporate expenses includes goodwill impairment charges, severance, facility action costs, and stock-based compensation expense. |

[0001571996-18-000044:notes:343]
The following table presents the disaggregation of net revenue by reportable segment, and by major product categories within the segments:

[0001571996-18-000044:notes:344]
|  | Three Months Ended |  | Nine Months Ended |
|  | November 2, 2018 |  | November 3, 2017 |  | November 2, 2018 |  | November 3, 2017 |
|  | (in millions) |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |
| Infrastructure Solutions Group: |  |  |  |  |  |  |  |
| Servers and networking | $ | 5,054 |  |  | $ | 3,875 |  |  | $ | 14,700 |  |  | $ | 10,908 |  |
| Storage | 3,883 |  |  | 3,660 |  |  | 12,131 |  |  | 11,055 |  |
| Total ISG net revenue | 8,937 |  |  | 7,535 |  |  | 26,831 |  |  | 21,963 |  |
| Client Solutions Group: |  |  |  |  |  |  |  |
| Commercial | 7,613 |  |  | 6,778 |  |  | 23,085 |  |  | 20,327 |  |
| Consumer | 3,292 |  |  | 3,051 |  |  | 9,219 |  |  | 8,416 |  |
| Total CSG net revenue | 10,905 |  |  | 9,829 |  |  | 32,304 |  |  | 28,743 |  |
| VMware: |  |  |  |  |  |  |  |
| Total VMware net revenue | 2,229 |  |  | 1,933 |  |  | 6,451 |  |  | 5,735 |  |
| Total segment net revenue | $ | 22,071 |  |  | $ | 19,297 |  |  | $ | 65,586 |  |  | $ | 56,441 |  |


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0001571996-18-000044:notes:345]
NOTE 19 — SUPPLEMENTAL CONSOLIDATED FINANCIAL INFORMATION

[0001571996-18-000044:notes:346]
The following table provides additional information on selected accounts included in the Condensed Consolidated Statements of Financial Position as of November 2, 2018 and February 2, 2018:

[0001571996-18-000044:notes:347]
|  | November 2, 2018 |  | February 2, 2018 |
|  | (in millions) |
| Inventories, net: |  |  |  |
| Production materials | $ | 1,727 |  |  | $ | 967 |  |
| Work-in-process | 764 |  |  | 514 |  |
| Finished goods | 1,302 |  |  | 1,197 |  |
| Total inventories, net | $ | 3,793 |  |  | $ | 2,678 |  |
| Other non-current liabilities: |  |  |  |
| Warranty liability | $ | 169 |  |  | $ | 172 |  |
| Deferred and other tax liabilities | 5,808 |  |  | 6,590 |  |
| Other | 590 |  |  | 515 |  |
| Total other non-current liabilities | $ | 6,567 |  |  | $ | 7,277 |  |

[0001571996-18-000044:notes:348]
[same as prior period, unchanged from 0001571996-18-000034:notes:14]

[0001571996-18-000044:notes:349]
The following table presents cash, cash equivalents, and restricted cash as reported on the Condensed Consolidated Statements of Financial Position as of November 2, 2018 and February 2, 2018:

[0001571996-18-000044:notes:350]
|  | November 2, 2018 |  | February 2, 2018 |
|  | (in millions) |
| Cash and cash equivalents | $ | 15,152 |  |  | $ | 13,942 |  |
| Restricted cash - current assets | 499 |  |  | 423 |  |
| Restricted cash - other non-current assets | 25 |  |  | 13 |  |
| Total cash, cash equivalents, and restricted cash | $ | 15,676 |  |  | $ | 14,378 |  |

[0001571996-18-000044:notes:351]
[same as prior period, unchanged from 0001571996-18-000034:notes:17]


## us-gaap:SubsequentEventsTextBlock

[0001571996-18-000044:notes:352]
NOTE 20 — SUBSEQUENT EVENTS

[0001571996-18-000044:notes:353]
During November 2018, VMware, Inc. announced that it had signed a definitive agreement to acquire Heptio Inc. (“Heptio”).  Total consideration for the acquisition, subject to purchase price adjustments, will consist of approximately $550 million in cash and assumed unvested equity awards of the acquiree.  Heptio provides products and services that help enterprises deploy and operationalize Kubernetes.  The transaction is expected to close during the three months ending February 1, 2019 and is subject to regulatory approvals and customary closing conditions.

[0001571996-18-000044:notes:354]
On November 14, 2018, the Company and Merger Sub entered into Amendment No.1 to the Agreement and Plan of Merger (the “Amendment”), which amended the Merger Agreement described in Note 16 of the Notes to the Condensed Consolidated Financial Statements (as amended by the Amendment, the “Amended Merger Agreement”).  The Amendment, among other things, (i) increases the Aggregate Cash Consideration Cap from $9 billion to $14 billion, (ii) increases the per share Cash Consideration from $109.00, without interest, to $120.00, without interest, and (iii) increases the ratio at which each share of Class V Common Stock may be exchanged from 1.3665 shares of Class C Common Stock to at least 1.5043 shares of Class C Common Stock.  Under the Amended Merger Agreement, each share of Class V Common Stock will be converted into the right to receive, at the election of the holder of such share, either (1) such number of shares of Class C Common Stock as determined by the application of the exchange ratio, which will be between 1.5043 and 1.8130, or (2) $120.00 in cash, without interest, subject to the Aggregate Cash Consideration Cap of $14 billion. This represents a 10% increase in the consideration for the Class V transaction, as well as a 56% increase in the Aggregate Cash Consideration Cap.

[0001571996-18-000044:notes:355]
In addition, the Amendment provides for certain corporate governance changes that would be implemented following the closing of the Merger.  Among such changes, the Company has agreed that, no later than June 30, 2019, (i) the Company’s Board of Directors will appoint a fourth director who meets the independence requirements of the New York Stock Exchange (an “independent director”) to the Board of Directors after consultation with holders of Class C Common Stock and (ii) the Company will establish a Nominating and Corporate Governance Committee of the Board of Directors. The Nominating and Corporate Governance Committee is expected to be initially comprised of Michael Dell and Egon Durban, who currently serve as directors, and one independent director. The Amendment also includes changes to the Company’s amended and restated certificate of incorporation to provide for the ability of holders of Class C Common Stock, voting separately as a series, to elect one director beginning with the second annual meeting of stockholders of the Company following the closing of the Merger and annually thereafter.

[0001571996-18-000044:notes:356]
In connection with the Amendment, Dell entered into a commitment letter, dated November 14, 2018, with bank lenders providing for a senior secured incremental first lien term A loan facility (the “bridge financing”) under the Company’s existing senior secured credit agreement to fund the $5 billion increase in the Aggregate Cash Consideration Cap.  The bridge financing will bear interest at a rate per annum equal to an applicable margin, plus, at the borrowers’ option, either (i) the adjusted LIBOR plus 1.75%, subject to an interest rate floor of 0% per annum, or (ii) a base rate subject to an interest rate floor of 0.75% per annum, subject to an interest rate floor of 0% per annum.

[0001571996-18-000044:notes:357]
The bridge financing will have no amortization and will initially mature on the earlier of (a) February 8, 2019 and (b) the date on which the Merger Agreement is terminated by the Company or any of its affiliates in accordance with its terms (the “Initial Maturity Date”), except that, on the date on which the Class V transaction is consummated, the Initial Maturity Date will be extended automatically to the date that is 364 days after the closing date of the Merger (the “First Extended Maturity Date”), so long as the Merger has been consummated prior to the Initial Maturity Date.

[0001571996-18-000044:notes:358]
The First Extended Maturity Date may be extended to the date that is 364 days after the First Extended Maturity Date (the “Second Extended Maturity Date” and together with the Initial Maturity Date and the First Extended Maturity Date, as applicable, the “Maturity Date”) so long as (i) the borrower shall have provided written notice of the extension at least 10 business days prior to the First Extended Maturity Date, (ii) concurrently with the effectiveness of such extension, the borrower shall have paid an extension fee in an amount equal to 0.50% of the aggregate principal amount of the bridge financing so extended, and (iii) the conditions set forth in senior secured credit agreement shall have been satisfied.

[0001571996-18-000044:notes:359]
The Merger and the Class V transaction will be accounted for as a hybrid liability and equity transaction involving the repurchase of outstanding common stock, with the consideration consisting of a variable combination of cash and shares.  Upon settlement, the accounting for the Class V transaction will reflect that the outstanding Class V Common Stock will be canceled and converted into the right to receive shares of Class C Common Stock or $120.00 per share in cash or combination of cash and shares, depending on each holder’s election and subject to proration of the cash elections.  The variable nature of the cash obligation to repurchase the shares of Class V Common Stock may require the Company to settle a portion of the shares in exchange for cash and therefore will be accounted for as a financial instrument with a potential mark-to-market adjustment for the change in fair value from the date of the stockholder meeting at which the Company’s stockholders will vote on approval of the Class V transaction to the election deadline by which holders of Class V Common Stock must elect the form of consideration for which they will exchange their shares.  After the election deadline and following the determination of the final proration of cash elections and the exchange ratio, the Class V transaction will be accounted for as an equity transaction.

[0001571996-18-000044:notes:360]
Other than the matters identified above, there were no known events occurring after the balance sheet date and up until the date of the issuance of this report that would materially affect the information presented herein.
