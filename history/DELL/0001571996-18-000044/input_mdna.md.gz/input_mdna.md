# DELL MD&A — 0001571996-18-000044


## mdna

[0001571996-18-000044:mdna:1]
ITEM 2 — MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS

[0001571996-18-000044:mdna:2]
This management’s discussion and analysis should be read in conjunction with the audited Consolidated Financial Statements and accompanying Notes included in the Company’s Annual Report on Form 10-K for the fiscal year ended February 2, 2018 and the recast audited Consolidated Financial Statements and accompanying Notes for the fiscal years ended February 2, 2018 and February 3, 2017 and other financial information included in the Current Report on Form 8-K filed with the SEC on August 6, 2018.  Multiple accounting standards were adopted during the three months ended May 4, 2018, which resulted in adjustment or reclassification of amounts previously reported.  See Note 1 of the Notes to the Condensed Consolidated Financial Statements included in this report for further information regarding our recently adopted accounting standards.

[0001571996-18-000044:mdna:3]
Unless otherwise indicated, all results presented are prepared in a manner that complies, in all material respects, with accounting principles generally accepted in the United States of America (“GAAP”).  Additionally, unless otherwise indicated, all changes identified for the current-period results represent comparisons to results for the prior corresponding fiscal period.

[0001571996-18-000044:mdna:4]
Unless the context indicates otherwise, references in this report to “we,” “us,” “our,” the “Company,” and “Dell Technologies” mean Dell Technologies Inc. and its consolidated subsidiaries, references to “Dell” mean Dell Inc. and Dell Inc.’s consolidated subsidiaries, and references to “EMC” mean EMC Corporation and EMC Corporation’s consolidated subsidiaries.

[0001571996-18-000044:mdna:5]
Our fiscal year is the 52- or 53-week period ending on the Friday nearest January 31.  We refer to our fiscal years ending February 1, 2019 and our fiscal year ended February 2, 2018 as “Fiscal 2019” and “Fiscal 2018,” respectively.  Fiscal 2019 and Fiscal 2018 include 52 weeks.

[0001571996-18-000044:mdna:6]
[same as prior period, unchanged from 0001571996-18-000034:mdna:6]

[0001571996-18-000044:mdna:7]
Dell Technologies is a leading global end-to-end technology provider, with a comprehensive portfolio of IT hardware, software and service solutions spanning both traditional infrastructure and emerging, multi-cloud technologies that enable our customers to meet the business needs of tomorrow.  We operate eight complementary businesses: our Infrastructure Solutions Group and our Client Solutions Group, as well as VMware, Inc., Pivotal Software, Inc. (“Pivotal”), SecureWorks Corp. (“SecureWorks”), RSA Security LLC (“RSA Security”), Virtustream Group Holdings, Inc. (“Virtustream”), and Boomi, Inc. (“Boomi”).  Together our strategically aligned family of businesses operates in close coordination across key functional areas such as product development, go-to-market and global services, and are supported by Dell Financial Services.  We believe this operational philosophy enables our platform to seamlessly deliver differentiated and holistic IT solutions to our customers, which has driven significant revenue growth and share gains.

[0001571996-18-000044:mdna:8]
As a result of our significant transformation since the going-private transaction in 2013, Dell Technologies today operates with significant scale and an unmatched breadth of complementary offerings.  Digital transformation has become essential to all businesses, and we have expanded our portfolio to include holistic solutions that enable our customers to drive their ongoing digital transformation initiatives.  Dell Technologies’ integrated solutions help customers modernize their IT infrastructure, address workforce transformation and provide critical security solutions to protect against the ever increasing and evolving security threats.  With our extensive portfolio and our commitment to innovation, we have the ability to offer secure, integrated solutions that extend from the intelligent edge to the multi-cloud data center ecosystem, and we are at the forefront of the software-defined and cloud native infrastructure era.  Our end-to-end portfolio is supported by a differentiated go-to-market engine, which includes a 40,000-person sales force and 150,000 channel partners across 180 countries, and a world-class supply chain that together drive revenue growth and operating efficiencies.

[0001571996-18-000044:mdna:9]
[same as prior period, unchanged from 0001571996-18-000034:mdna:9]

[0001571996-18-000044:mdna:10]
We design, develop, manufacture, market, sell, and support a wide range of products and services.  We are organized into the following business units, which are our reportable segments: Infrastructure Solutions Group; Client Solutions Group; and VMware.

[0001571996-18-000044:mdna:11]
| • | Infrastructure Solutions Group (“ISG”) — Our Infrastructure Solutions Group, provides comprehensive data solutions and services, including storage, server, networking and services. Our comprehensive portfolio of advanced storage solutions includes traditional storage solutions as well as next-generation storage solutions (such as all-flash arrays, scale-out file, object platforms, and software-defined solutions), while our server portfolio includes high-performance rack, blade, tower, and hyperscale servers. Our networking portfolio helps our business customers transform and modernize their infrastructure, mobilize and enrich end-user experiences, and accelerate business applications and processes. ISG also offers attached software, peripherals, and services, including support and deployment, configuration, and extended warranty services. |

[0001571996-18-000044:mdna:12]
We are currently working to simplify our storage portfolio, with the goal of ensuring that we deliver the technology needed for our customers’ digital transformation.  We anticipate that these changes will take two to three years to execute.  As our storage portfolio evolves, we will continue to support our current portfolio of storage solutions.

[0001571996-18-000044:mdna:13]
Approximately half of ISG revenue is generated by sales to customers in the Americas, with the remaining portion derived from sales to customers in the Europe, Middle East, and Africa region (“EMEA”) and the Asia-Pacific and Japan region (“APJ”).

[0001571996-18-000044:mdna:14]
| • | Client Solutions Group (“CSG”) — CSG includes branded hardware (such as desktops, workstations, and notebooks) and branded peripherals (such as displays and projectors), as well as third-party software and peripherals. CSG also offers attached services, including support and deployment, configuration, and extended warranty services. |

[0001571996-18-000044:mdna:15]
[same as prior period, unchanged from 0001571996-18-000034:mdna:15]

[0001571996-18-000044:mdna:16]
| • | VMware — The VMware reportable segment (“VMware”) reflects the operations of VMware, Inc. (NYSE: VMW) within Dell Technologies. See Exhibit 99.1 filed with this report for further details on the differences between VMware reportable segment results and VMware, Inc. results. |

[0001571996-18-000044:mdna:17]
VMware provides compute, management, cloud, networking, and security storage, mobility, and other end-user computing infrastructure software to businesses that provides a flexible digital foundation for the applications that empower businesses to serve their customers globally.  VMware has continued to broaden its product and solution offerings beyond software-defined compute software to enable customers to modernize data centers, integrate public clouds, transform networking and security, and empower digital workspaces.

[0001571996-18-000044:mdna:18]
[same as prior period, unchanged from 0001571996-18-000034:mdna:18]

[0001571996-18-000044:mdna:19]
[same as prior period, unchanged from 0001571996-18-000034:mdna:19]

[0001571996-18-000044:mdna:20]
| • | Pivotal (NYSE: PVTL) provides a leading cloud-native platform that makes software development and IT operations a strategic advantage for customers. Pivotal’s cloud-native platform, Pivotal Cloud Foundry, accelerates and streamlines software development by reducing the complexity of building, deploying and operating new cloud-native applications and modernizing legacy applications. On April 24, 2018, Pivotal completed a registered underwritten initial public offering of its Class A common stock. |

[0001571996-18-000044:mdna:21]
[same as prior period, unchanged from 0001571996-18-000034:mdna:21]

[0001571996-18-000044:mdna:22]
[same as prior period, unchanged from 0001571996-18-000034:mdna:22]

[0001571996-18-000044:mdna:23]
| • | Virtustream offers cloud software and infrastructure-as-a-service solutions that enable customers to migrate, run, and manage mission-critical applications in cloud-based IT environments. Beginning in the first quarter of Fiscal 2019, Virtustream results are reported within other businesses, rather than within ISG. This change in reporting structure did not impact our previously reported consolidated financial results, but our prior period segment results have been recast to reflect the change. |

[0001571996-18-000044:mdna:24]
[same as prior period, unchanged from 0001571996-18-000034:mdna:24]

[0001571996-18-000044:mdna:25]
[same as prior period, unchanged from 0001571996-18-000034:mdna:25]

[0001571996-18-000044:mdna:26]
For further discussion regarding our current reportable segments, see “Results of Operations — Business Unit Results.”

[0001571996-18-000044:mdna:27]
[same as prior period, unchanged from 0001571996-18-000034:mdna:27]

[0001571996-18-000044:mdna:28]
Dell Financial Services and its affiliates (“DFS”) supports our businesses by offering and arranging various financing options and services for our customers in North America, Europe, Australia, and New Zealand.  DFS originates, collects, and services customer receivables primarily related to the purchase of our product, software, and service solutions.  DFS further strengthens our customer relationships through its flexible consumption models, which enable us to offer our customers the option to pay over time and, in certain cases, based on utilization, providing them with financial flexibility to meet their changing technological requirements.  The results of these operations are allocated to our segments based on the underlying product or service financed.  For additional information about our financing arrangements, see Note 5 of the Notes to the Condensed Consolidated Financial Statements included in this report.

[0001571996-18-000044:mdna:29]
[same as prior period, unchanged from 0001571996-18-000034:mdna:29]

[0001571996-18-000044:mdna:30]
As part of our strategy, we will continue to evaluate opportunities for strategic investments through our venture capital investment arm, Dell Technologies Capital, with a focus on emerging technology areas that are relevant to the Dell Technologies unique family of businesses and that will complement our existing portfolio of solutions.  Our investment areas include storage, software-defined networking, management and orchestration, security, machine learning and artificial intelligence, Big Data and analytics, cloud, Internet of Things (“IoT”), and software development operations.  In addition to these investments, we also may make disciplined acquisitions targeting businesses that advance our strategic objectives.  As of November 2, 2018 and February 2, 2018, Dell Technologies held strategic investments of $1.0 billion and $0.7 billion, respectively.

[0001571996-18-000044:mdna:31]
[same as prior period, unchanged from 0001571996-18-000034:mdna:31]

[0001571996-18-000044:mdna:32]
We are seeing an unprecedented rate of change in the IT industry.  Organizations of all kinds are embracing digital technology to achieve their business objectives.  Our vision is to be an essential infrastructure company and leader in end-user computing, data center infrastructure solutions, virtualization, IoT, and cloud software that our customers continue to trust and rely on for their IT solutions and transformations as they embrace the multi-cloud environment of today.  To further advance this vision, we recently unveiled a new IoT strategy, division, and an array of solutions to support IoT adoption for our customers.  We accelerate results for our customers by enabling them to be more efficient, mobile, informed, and secure.  We continue to invest in research and development, sales, and other key areas of our business to deliver superior products and solutions capabilities and to drive execution of long-term sustainable growth.  We believe that our results will benefit from an integrated go-to-market strategy, including enhanced coordination among the family of Dell Technologies companies, and from our differentiated products and solutions capabilities.  We intend to continue to execute on our business model and seek to balance liquidity, profitability, and growth to position our company for long-term success.

[0001571996-18-000044:mdna:33]
[same as prior period, unchanged from 0001571996-18-000034:mdna:33]

[0001571996-18-000044:mdna:34]
[same as prior period, unchanged from 0001571996-18-000034:mdna:34]

[0001571996-18-000044:mdna:35]
We are able to leverage our traditional strength in the PC market to offer solutions and services that provide higher-value, recurring revenue streams.  Given current market trends, we expect that the demand environment will continue to be cyclical and that competitive dynamics will continue to pressure our CSG business.  However, we are committed to a long-term growth strategy that we believe will benefit from the consolidation trends that are occurring in our markets.  Our CSG offerings are an important element of our strategy, generating strong cash flow and opportunities for cross-selling of complementary solutions.

[0001571996-18-000044:mdna:36]
We manage our business on a U.S. dollar basis.  However, we have a large global presence, generating approximately half of our revenue by sales to customers outside of the United States during the first nine months of Fiscal 2019 and the first nine months of Fiscal 2018.  Our revenues, therefore, can be impacted by fluctuations in foreign currency exchange rates.  We utilize a comprehensive hedging strategy intended to mitigate the impact of foreign currency volatility over time, and we adjust pricing when possible to further minimize foreign currency impacts.

[0001571996-18-000044:mdna:37]
[same as prior period, unchanged from 0001571996-18-000034:mdna:37]

[0001571996-18-000044:mdna:38]
[same as prior period, unchanged from 0001571996-18-000034:mdna:38]

[0001571996-18-000044:mdna:39]
[same as prior period, unchanged from 0001571996-18-000034:mdna:39]

[0001571996-18-000044:mdna:40]
On July 2, 2018, we announced that we had completed our evaluation of potential strategic business opportunities.  As a result of such evaluation, we determined to pursue a transaction, referred to as the “Class V transaction,” pursuant to an Agreement and Plan of Merger (the “Merger Agreement”), dated as of July 1, 2018, between Dell Technologies and Teton Merger Sub Inc. (“Merger Sub”), a Delaware corporation and wholly-owned subsidiary of Dell Technologies.  The Merger Agreement provides, among other things and subject to the terms and conditions set forth therein, that Merger Sub will be merged with and into Dell Technologies (the “Merger”), with Dell Technologies continuing as the surviving corporation.

[0001571996-18-000044:mdna:41]
Original Merger Agreement.  Before the amendment described below, the Merger Agreement provided that, subject to the terms and conditions thereof, at the effective time of the Merger (the “Effective Time”), each share of Class V Common Stock that is issued and outstanding immediately prior to the Effective Time will be canceled and converted into the right to receive, at the holder’s election, (i) 1.3665 shares (the “Share Consideration”) of Class C Common Stock or (ii) $109.00 in cash, without interest (the “Cash Consideration”), subject to an aggregate amount of Cash Consideration that may be received by holders of Class V Common Stock in the Merger not exceeding $9 billion (the “Aggregate Cash Consideration Cap”).  If the total amount of Cash Consideration elected by holders of Class V Common Stock would exceed the Aggregate Cash Consideration Cap, a portion of the shares with respect to which a holder elects to receive the Cash Consideration equal to a fraction, the numerator of which is the Aggregate Cash Consideration Cap and the denominator of which is the aggregate amount of Cash Consideration elected by holders, will be converted into the right to receive the Cash Consideration and the remaining portion of such shares held by such holders will be converted into the right to receive the Share Consideration.  Any share of Class V Common Stock for which a valid election to receive Cash Consideration is not in effect at the Effective Time will be converted into Share Consideration.  Upon consummation of the Merger, all shares of the Class V Common Stock would be delisted from the New York Stock Exchange and the Class C Common Stock would be listed on the New York Stock Exchange.

[0001571996-18-000044:mdna:42]
In addition, before it was amended, the Merger Agreement provided that, as of the Effective Time and unless otherwise agreed by Dell Technologies and a holder of a Class V Common Stock-based equity award granted by us (a “Class V Award”), each Class V Award will be converted into a new equity award on the same terms and conditions (including applicable vesting requirements and deferral provisions) with respect to the number of shares of Class C Common Stock that is equal to the number of shares of Class V Common Stock that were subject to the Class V Award multiplied by 1.3665 (rounded down to the nearest whole share).  The exercise price for any Class V Award options so converted will equal the exercise price of such Class V Award options immediately prior to the Effective Time divided by 1.3665 (rounded up to the nearest whole penny).

[0001571996-18-000044:mdna:43]
In connection with the Merger Agreement, the board of directors of VMware, Inc. declared a conditional $11 billion one‑time special cash dividend pro rata to holders of VMware, Inc. common stock.  Immediately prior to the completion of the Class V transaction, subject to the satisfaction of other conditions of the Class V transaction, as well as certain other conditions, VMware, Inc. will pay the special cash dividend to its stockholders.  Approximately $8.87 billion of the VMware, Inc. cash dividend will be received by Dell Technologies and used to fund all or substantially all of the Cash Consideration paid to holders of the Class V Common Stock in the Class V transaction.  We will fund any remaining cash consideration, which is not expected to be material, from cash on hand.

[0001571996-18-000044:mdna:44]
Our obligation to complete the Merger and the Class V transaction is subject to stockholder approval and certain other closing conditions as further described in a Current Report on Form 8-K filed by us with the SEC on July 2, 2018.

[0001571996-18-000044:mdna:45]
On October 3, 2018, we announced that as a potential contingency plan in the event the Class V transaction is not consummated, we had met with certain investment banks to explore a potential initial public offering of our Class C Common Stock. There is no assurance that our board of directors will determine to proceed with an initial public offering of our Class C Common Stock in the event that the Class V transaction is not consummated.

[0001571996-18-000044:mdna:46]
Amended Merger Agreement.  On November 14, 2018, Dell Technologies and Merger Sub entered into Amendment No.1 to the Agreement and Plan of Merger, (the “Amendment”), which amended the Merger Agreement (as amended by the Amendment, the “Amended Merger Agreement”).  The Amendment, among other things, (i) increases the Aggregate Cash Consideration Cap from $9 billion to $14 billion, (ii) increases the per share Cash Consideration from $109.00, without interest, to $120.00, without interest, and (iii) increases the ratio at which each share of Class V Common Stock may be exchanged from 1.3665 shares of Class C Common Stock to at least 1.5043 shares of Class C Common Stock, subject to increase as described in our Current Report on Form 8-K filed with the SEC on November 15, 2018.  Under the terms and conditions of the Amended Merger Agreement, each share of Class V Common Stock will be converted into the right to receive, at the election of the holder of such share, either (1) such number of shares of Class C Common Stock as determined by the application of the exchange ratio, which will be between 1.5043 and 1.8130, or (2) $120.00 in cash, without interest, subject to the Aggregate Cash Consideration Cap of $14 billion. This represents a 10% increase in the consideration for the Class V transaction, as well as a 56% increase in the Aggregate Cash Consideration Cap.

[0001571996-18-000044:mdna:47]
In addition, the Amendment provides for certain corporate governance changes that would be implemented following the closing of the Merger.  Among such changes, the Company has agreed that, no later than June 30, 2019, (i) the Board of Directors will appoint a fourth director who meets the independence requirements of the New York Stock Exchange (an “independent director”) to the Board of Directors after consultation with holders of Class C Common Stock and (ii) the Company will establish a Nominating and Corporate Governance Committee of the Board of Directors. The Nominating and Corporate Governance Committee is expected to be initially comprised of Michael Dell and Egon Durban, who currently serve as directors, and one independent director. The Amendment also includes changes to our amended and restated certificate of incorporation to provide for the ability of holders of Class C Common Stock, voting separately as a series, to elect one director beginning with the second annual meeting of stockholders of Dell Technologies following the closing of the Merger and annually thereafter.

[0001571996-18-000044:mdna:48]
Bridge Financing.  In connection with the Amendment, Dell Inc., a wholly-owned subsidiary of Dell Technologies, entered into a commitment letter, dated November 14, 2018, for a senior secured incremental first lien term A loan facility (the “bridge financing”) under its existing senior secured credit agreement to fund the $5 billion increase in the Aggregate Cash Consideration Cap.  The bridge financing will bear interest at a rate per annum equal to an applicable margin, plus, at the borrowers’ option, either (a) the Adjusted LIBOR plus 1.75%, subject to an interest rate floor of 0% per annum or (b) a base rate subject to an interest rate floor of 0.75% per annum, subject to an interest rate floor of 0% per annum.

[0001571996-18-000044:mdna:49]
The bridge financing will have no amortization and will initially mature on the earlier of (a) February 8, 2019 and (b) the date on which the Merger Agreement is terminated by Dell Technologies or any of its affiliates in accordance with its terms (the “Initial Maturity Date”), except provided that, on the date on which the Class V Transaction is consummated, the Initial Maturity Date will be extended automatically to the date that is 364 days after the Closing Date (the “First Extended Maturity Date”), so long as the Merger has been consummated prior to the Initial Maturity Date.

[0001571996-18-000044:mdna:50]
The First Extended Maturity Date may be extended to the date that is 364 days after the First Extended Maturity Date (the “Second Extended Maturity Date” and together with the Initial Maturity Date and the First Extended Maturity Date, as applicable, the “Maturity Date”) so long as (i) the borrower shall have provided written notice of the extension at least 10 business days prior to the First Extended Maturity Date, (ii) concurrently with the effectiveness of such extension, the borrower shall have paid an extension fee in an amount equal to 0.50% of the aggregate principal amount of the bridge financing so extended and (iii) the conditions set forth in senior secured credit agreement shall have been satisfied.

[0001571996-18-000044:mdna:51]
Accounting.  The Merger and the Class V transaction will be accounted for as a hybrid liability and equity transaction involving the repurchase of outstanding common stock, with the consideration consisting of a variable combination of cash and shares.  Upon settlement, the accounting for the Class V transaction will reflect that the outstanding Class V Common Stock will be canceled and converted into the right to receive shares of Class C Common Stock or $120.00 per share in cash or combination of cash and shares, depending on each holder’s election and subject to proration of the cash elections.  The variable nature of the cash obligation to repurchase the shares of Class V Common Stock may require us to settle a portion of the shares in exchange for cash and therefore will be accounted for as a financial instrument with a potential mark-to-market adjustment for the change in fair value from the date of the stockholder meeting at which the Company’s stockholders will vote on approval of the Class V transaction to the election deadline by which holders of Class V Common Stock must elect the form of consideration for which they will exchange their shares.  After the election deadline and following the determination of the final proration of cash elections and the exchange ratio, the Class V transaction will be accounted for as an equity transaction.

[0001571996-18-000044:mdna:52]
[same as prior period, unchanged from 0001571996-18-000034:mdna:59]

[0001571996-18-000044:mdna:53]
[same as prior period, unchanged from 0001571996-18-000034:mdna:47]

[0001571996-18-000044:mdna:54]
In this management’s discussion and analysis, we use supplemental measures of our performance which are derived from our consolidated financial information but which are not presented in our consolidated financial statements prepared in accordance with GAAP.  These non-GAAP financial measures include non-GAAP product net revenue; non-GAAP services net revenue; non-GAAP net revenue; non-GAAP product gross margin; non-GAAP services gross margin; non-GAAP gross margin; non-GAAP operating expenses; non-GAAP operating income; non-GAAP net income; earnings before interest and other, net, taxes, depreciation, and amortization (“EBITDA”); and adjusted EBITDA.

[0001571996-18-000044:mdna:55]
[same as prior period, unchanged from 0001571996-18-000034:mdna:49]

[0001571996-18-000044:mdna:56]
[same as prior period, unchanged from 0001571996-18-000034:mdna:50]

[0001571996-18-000044:mdna:57]
Non-GAAP product net revenue, non-GAAP services net revenue, non-GAAP net revenue, non-GAAP product gross margin, non-GAAP services gross margin, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP operating income, and non-GAAP net income, as defined by us, exclude amortization of intangible assets, the impact of purchase accounting, transaction-related expenses, other corporate expenses and, for non-GAAP net income from continuing operations, an aggregate adjustment for income taxes.  As the excluded items have a material impact on our financial results, our management compensates for this limitation by relying primarily on our GAAP results and using non-GAAP financial measures supplementally or for projections when comparable GAAP financial measures are not available.  The non-GAAP financial measures are not meant to be considered as indicators of performance in isolation from or as a substitute for net revenue, gross margin, operating expenses, operating income, or net income prepared in accordance with GAAP, and should be read only in conjunction with financial information presented on a GAAP basis.

[0001571996-18-000044:mdna:58]
[same as prior period, unchanged from 0001571996-18-000034:mdna:52]

[0001571996-18-000044:mdna:59]
[same as prior period, unchanged from 0001571996-18-000034:mdna:53]

[0001571996-18-000044:mdna:60]
[same as prior period, unchanged from 0001571996-18-000034:mdna:54]

[0001571996-18-000044:mdna:61]
[same as prior period, unchanged from 0001571996-18-000034:mdna:55]

[0001571996-18-000044:mdna:62]
| • | Transaction-related Expenses — Transaction-related expenses consist of acquisition, integration, and divestiture related costs, and are expensed as incurred. These expenses primarily represent costs for legal, banking, consulting, and advisory services, as well as certain compensatory retention awards directly related to the EMC merger transaction. During the first nine months of Fiscal 2019, this category also included charges related to integration of our inventory policies and management process. We incurred expenses of approximately $116 million for customer evaluation units and approximately $100 million for manufacturing and engineering inventory during the first and third quarter of Fiscal 2019, respectively. |

[0001571996-18-000044:mdna:63]
| • | Other Corporate Expenses — Other corporate expenses consists of goodwill impairment charges, severance, facility action costs, and stock-based compensation expense associated with equity awards. In the third quarter of Fiscal 2019, we incurred a goodwill impairment charge of $190 million. See Note 8 of the Notes to the Condensed Consolidated Financial Statements for additional information about goodwill impairment testing. Severance costs are primarily related to severance and benefits for employees terminated pursuant to cost savings initiatives. Facility action costs were $7 million and $21 million, respectively, during the third quarter and first nine months of Fiscal 2019, compared to $67 million and $175 million, respectively, during the third quarter and first nine months of Fiscal 2018. We continue to integrate owned and leased facilities and may incur additional costs as we seek opportunities for operational efficiencies. Other corporate expenses vary from period to period and are significantly impacted by the timing and nature of these events. Therefore, although we may incur these types of expenses in the future, we believe that eliminating these charges for purposes of calculating the non-GAAP financial measures presented below facilitates a more meaningful evaluation of our current operating performance and comparisons to our past operating performance. |

[0001571996-18-000044:mdna:64]
| • | Aggregate Adjustment for Income Taxes — The aggregate adjustment for income taxes is the estimated combined income tax effect for the adjustments described above. During the first nine months of Fiscal 2019, this category also includes approximately $154 million of tax benefits resulting from the impact of adopting the new revenue standard in the first quarter of Fiscal 2019. The tax effects are determined based on the tax jurisdictions where the above items were incurred. |

[0001571996-18-000044:mdna:65]
72

[0001571996-18-000044:mdna:66]
[same as prior period, unchanged from 0001571996-18-000034:mdna:60]

[0001571996-18-000044:mdna:67]
|  | Three Months Ended |  | Nine Months Ended |
|  | November 2, 2018 |  | % Change |  | November 3, 2017 |  | November 2, 2018 |  | % Change |  | November 3, 2017 |
|  | (in millions, except percentages) |
| Product net revenue | $ | 17,625 |  |  | 17 | % |  | $ | 15,120 |  |  | $ | 52,445 |  |  | 20 | % |  | $ | 43,856 |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Impact of purchase accounting | 15 |  |  |  |  | 33 |  |  | 50 |  |  |  |  | 138 |  |
| Non-GAAP product net revenue | $ | 17,640 |  |  | 16 | % |  | $ | 15,153 |  |  | $ | 52,495 |  |  | 19 | % |  | $ | 43,994 |  |
| Services net revenue | $ | 4,857 |  |  | 9 | % |  | $ | 4,436 |  |  | $ | 14,335 |  |  | 8 | % |  | $ | 13,221 |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Impact of purchase accounting | 154 |  |  |  |  | 262 |  |  | 486 |  |  |  |  | 847 |  |
| Non-GAAP services net revenue | $ | 5,011 |  |  | 7 | % |  | $ | 4,698 |  |  | $ | 14,821 |  |  | 5 | % |  | $ | 14,068 |  |
| Net revenue | $ | 22,482 |  |  | 15 | % |  | $ | 19,556 |  |  | $ | 66,780 |  |  | 17 | % |  | $ | 57,077 |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Impact of purchase accounting | 169 |  |  |  |  | 295 |  |  | 536 |  |  |  |  | 985 |  |
| Non-GAAP net revenue | $ | 22,651 |  |  | 14 | % |  | $ | 19,851 |  |  | $ | 67,316 |  |  | 16 | % |  | $ | 58,062 |  |
| Product gross margin | $ | 3,060 |  |  | 20 | % |  | $ | 2,547 |  |  | $ | 9,331 |  |  | 40 | % |  | $ | 6,685 |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 726 |  |  |  |  | 914 |  |  | 2,154 |  |  |  |  | 2,784 |  |
| Impact of purchase accounting | 17 |  |  |  |  | 45 |  |  | 63 |  |  |  |  | 173 |  |
| Transaction-related expenses | 99 |  |  |  |  | 1 |  |  | 236 |  |  |  |  | 9 |  |
| Other corporate expenses | 2 |  |  |  |  | 2 |  |  | 8 |  |  |  |  | 8 |  |
| Non-GAAP product gross margin | $ | 3,904 |  |  | 11 | % |  | $ | 3,509 |  |  | $ | 11,792 |  |  | 22 | % |  | $ | 9,659 |  |
| Services gross margin | $ | 2,883 |  |  | 8 | % |  | $ | 2,673 |  |  | $ | 8,613 |  |  | 8 | % |  | $ | 7,960 |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Impact of purchase accounting | 154 |  |  |  |  | 262 |  |  | 486 |  |  |  |  | 847 |  |
| Transaction-related expenses | 3 |  |  |  |  | 4 |  |  | 3 |  |  |  |  | 13 |  |
| Other corporate expenses | 56 |  |  |  |  | 26 |  |  | 91 |  |  |  |  | 55 |  |
| Non-GAAP services gross margin | $ | 3,096 |  |  | 4 | % |  | $ | 2,965 |  |  | $ | 9,193 |  |  | 4 | % |  | $ | 8,875 |  |
| Gross margin | $ | 5,943 |  |  | 14 | % |  | $ | 5,220 |  |  | $ | 17,944 |  |  | 23 | % |  | $ | 14,645 |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 726 |  |  |  |  | 914 |  |  | 2,154 |  |  |  |  | 2,784 |  |
| Impact of purchase accounting | 171 |  |  |  |  | 307 |  |  | 549 |  |  |  |  | 1,020 |  |
| Transaction-related expenses | 102 |  |  |  |  | 5 |  |  | 239 |  |  |  |  | 22 |  |
| Other corporate expenses | 58 |  |  |  |  | 28 |  |  | 99 |  |  |  |  | 63 |  |
| Non-GAAP gross margin | $ | 7,000 |  |  | 8 | % |  | $ | 6,474 |  |  | $ | 20,985 |  |  | 13 | % |  | $ | 18,534 |  |

[0001571996-18-000044:mdna:68]
[same as prior period, unchanged from 0001571996-18-000034:mdna:73]

[0001571996-18-000044:mdna:69]
|  | Three Months Ended |  | Nine Months Ended |
|  | November 2, 2018 |  | % Change |  | November 3, 2017 |  | November 2, 2018 |  | % Change |  | November 3, 2017 |
|  | (in millions, except percentages) |
| Operating expenses | $ | 6,299 |  |  | 12 | % |  | $ | 5,630 |  |  | $ | 18,466 |  |  | 9 | % |  | $ | 16,992 |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | (820 | ) |  |  |  | (820 | ) |  | (2,440 | ) |  |  |  | (2,466 | ) |
| Impact of purchase accounting | (22 | ) |  |  |  | (59 | ) |  | (81 | ) |  |  |  | (175 | ) |
| Transaction-related expenses | (65 | ) |  |  |  | (81 | ) |  | (198 | ) |  |  |  | (393 | ) |
| Other corporate expenses | (456 | ) |  |  |  | (305 | ) |  | (960 | ) |  |  |  | (824 | ) |
| Non-GAAP operating expenses | $ | 4,936 |  |  | 13 | % |  | $ | 4,365 |  |  | $ | 14,787 |  |  | 13 | % |  | $ | 13,134 |  |
| Operating loss | $ | (356 | ) |  | 13 | % |  | $ | (410 | ) |  | $ | (522 | ) |  | 78 | % |  | $ | (2,347 | ) |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 1,546 |  |  |  |  | 1,734 |  |  | 4,594 |  |  |  |  | 5,250 |  |
| Impact of purchase accounting | 193 |  |  |  |  | 366 |  |  | 630 |  |  |  |  | 1,195 |  |
| Transaction-related expenses | 167 |  |  |  |  | 86 |  |  | 437 |  |  |  |  | 415 |  |
| Other corporate expenses | 514 |  |  |  |  | 333 |  |  | 1,059 |  |  |  |  | 887 |  |
| Non-GAAP operating income | $ | 2,064 |  |  | (2 | )% |  | $ | 2,109 |  |  | $ | 6,198 |  |  | 15 | % |  | $ | 5,400 |  |
| Net loss | $ | (895 | ) |  | (5 | )% |  | $ | (851 | ) |  | $ | (1,894 | ) |  | 32 | % |  | $ | (2,793 | ) |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 1,546 |  |  |  |  | 1,734 |  |  | 4,594 |  |  |  |  | 5,250 |  |
| Impact of purchase accounting | 193 |  |  |  |  | 366 |  |  | 630 |  |  |  |  | 1,195 |  |
| Transaction-related expenses | 167 |  |  |  |  | 86 |  |  | 437 |  |  |  |  | 415 |  |
| Other corporate expenses | 514 |  |  |  |  | 333 |  |  | 1,059 |  |  |  |  | 887 |  |
| Aggregate adjustment for income taxes | (325 | ) |  |  |  | (469 | ) |  | (1,103 | ) |  |  |  | (1,882 | ) |
| Non-GAAP net income | $ | 1,200 |  |  | — | % |  | $ | 1,199 |  |  | $ | 3,723 |  |  | 21 | % |  | $ | 3,072 |  |

[0001571996-18-000044:mdna:70]
In addition to the above measures, we also use EBITDA and adjusted EBITDA to provide additional information for evaluation of our operating performance.  Adjusted EBITDA excludes purchase accounting adjustments related to the EMC merger transaction and the going-private transaction, acquisition, integration, and divestiture related costs, goodwill impairment charges, severance and facility action costs, and stock-based compensation expense.  We believe that, due to the non-operational nature of the purchase accounting entries, it is appropriate to exclude these adjustments.

[0001571996-18-000044:mdna:71]
As is the case with the non-GAAP measures presented above, users should consider the limitations of using EBITDA and adjusted EBITDA, including the fact that those measures do not provide a complete measure of our operating performance.  EBITDA and adjusted EBITDA do not purport to be alternatives to net income (loss) as measures of operating performance or to cash flows from operating activities as a measure of liquidity.  In particular, EBITDA and adjusted EBITDA are not intended to be a measure of free cash flow available for management’s discretionary use, as these measures do not consider certain cash requirements, such as working capital needs, capital expenditures, contractual commitments, interest payments, tax payments, and other debt service requirements.

[0001571996-18-000044:mdna:72]
[same as prior period, unchanged from 0001571996-18-000034:mdna:66]

[0001571996-18-000044:mdna:73]
|  | Three Months Ended |  | Nine Months Ended |
|  | November 2, 2018 |  | % Change |  | November 3, 2017 |  | November 2, 2018 |  | % Change |  | November 3, 2017 |
|  | (in millions, except percentages) |
| Net loss | $ | (895 | ) |  | (5 | )% |  | $ | (851 | ) |  | $ | (1,894 | ) |  | 32 | % |  | $ | (2,793 | ) |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Interest and other, net (a) | 639 |  |  |  |  | 682 |  |  | 1,564 |  |  |  |  | 1,799 |  |
| Income tax benefit | (100 | ) |  |  |  | (241 | ) |  | (192 | ) |  |  |  | (1,353 | ) |
| Depreciation and amortization | 1,961 |  |  |  |  | 2,137 |  |  | 5,806 |  |  |  |  | 6,491 |  |
| EBITDA | $ | 1,605 |  |  | (7 | )% |  | $ | 1,727 |  |  | $ | 5,284 |  |  | 28 | % |  | $ | 4,144 |  |
| EBITDA | $ | 1,605 |  |  | (7 | )% |  | $ | 1,727 |  |  | $ | 5,284 |  |  | 28 | % |  | $ | 4,144 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation expense | 256 |  |  |  |  | 221 |  |  | 671 |  |  |  |  | 630 |  |
| Impact of purchase accounting (b) | 169 |  |  |  |  | 298 |  |  | 536 |  |  |  |  | 990 |  |
| Transaction-related expenses (c) | 158 |  |  |  |  | 86 |  |  | 409 |  |  |  |  | 415 |  |
| Other corporate expenses (d) | 238 |  |  |  |  | 109 |  |  | 368 |  |  |  |  | 237 |  |
| Adjusted EBITDA | $ | 2,426 |  |  | (1 | )% |  | $ | 2,441 |  |  | $ | 7,268 |  |  | 13 | % |  | $ | 6,416 |  |

[0001571996-18-000044:mdna:74]
[same as prior period, unchanged from 0001571996-18-000034:mdna:68]

[0001571996-18-000044:mdna:75]
| (a) | See “Results of Operations — Interest and Other, Net” for more information on the components of interest and other, net. |

[0001571996-18-000044:mdna:76]
[same as prior period, unchanged from 0001571996-18-000034:mdna:70]

[0001571996-18-000044:mdna:77]
[same as prior period, unchanged from 0001571996-18-000034:mdna:71]

[0001571996-18-000044:mdna:78]
| (d) | Consists of goodwill impairment charges, severance and facility action costs. |

[0001571996-18-000044:mdna:79]
75

[0001571996-18-000044:mdna:80]
[same as prior period, unchanged from 0001571996-18-000034:mdna:74]

[0001571996-18-000044:mdna:81]
[same as prior period, unchanged from 0001571996-18-000034:mdna:75]

[0001571996-18-000044:mdna:82]
The following table summarizes our consolidated results from continuing operations for each of the periods presented.  Unless otherwise indicated, all changes identified for the current-period results represent comparisons to results for the prior corresponding fiscal period.  Multiple accounting standards were adopted during the first quarter of Fiscal 2019, which resulted in adjustment or reclassification of amounts previously reported.  See Note 1 of the Notes to the Condensed Consolidated Financial Statements included in this report for further information regarding our recently adopted accounting standards.

[0001571996-18-000044:mdna:83]
|  | Three Months Ended |  | Nine Months Ended |
|  | November 2, 2018 |  |  |  | November 3, 2017 |  | November 2, 2018 |  |  |  | November 3, 2017 |
|  | Dollars |  | % ofNet Revenue |  | %Change |  | Dollars |  | % ofNet Revenue |  | Dollars |  | % ofNet Revenue |  | %Change |  | Dollars |  | % ofNet Revenue |
|  | (in millions, except percentages) |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 17,625 |  |  | 78.4 | % |  | 17 | % |  | $ | 15,120 |  |  | 77.3 | % |  | $ | 52,445 |  |  | 78.5 | % |  | 20 | % |  | $ | 43,856 |  |  | 76.8 | % |
| Services | 4,857 |  |  | 21.6 | % |  | 9 | % |  | 4,436 |  |  | 22.7 | % |  | 14,335 |  |  | 21.5 | % |  | 8 | % |  | 13,221 |  |  | 23.2 | % |
| Total net revenue | $ | 22,482 |  |  | 100.0 | % |  | 15 | % |  | $ | 19,556 |  |  | 100.0 | % |  | $ | 66,780 |  |  | 100.0 | % |  | 17 | % |  | $ | 57,077 |  |  | 100.0 | % |
| Gross margin: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product (a) | $ | 3,060 |  |  | 17.4 | % |  | 20 | % |  | $ | 2,547 |  |  | 16.8 | % |  | $ | 9,331 |  |  | 17.8 | % |  | 40 | % |  | $ | 6,685 |  |  | 15.2 | % |
| Services (b) | 2,883 |  |  | 59.4 | % |  | 8 | % |  | 2,673 |  |  | 60.3 | % |  | 8,613 |  |  | 60.1 | % |  | 8 | % |  | 7,960 |  |  | 60.2 | % |
| Total gross margin | $ | 5,943 |  |  | 26.4 | % |  | 14 | % |  | $ | 5,220 |  |  | 26.7 | % |  | $ | 17,944 |  |  | 26.9 | % |  | 23 | % |  | $ | 14,645 |  |  | 25.7 | % |
| Operating expenses | $ | 6,299 |  |  | 28.0 | % |  | 12 | % |  | $ | 5,630 |  |  | 28.8 | % |  | $ | 18,466 |  |  | 27.7 | % |  | 9 | % |  | $ | 16,992 |  |  | 29.8 | % |
| Operating loss | $ | (356 | ) |  | (1.6 | )% |  | 13 | % |  | $ | (410 | ) |  | (2.1 | )% |  | $ | (522 | ) |  | (0.8 | )% |  | 78 | % |  | $ | (2,347 | ) |  | (4.1 | )% |
| Net loss | $ | (895 | ) |  | (4.0 | )% |  | (5 | )% |  | $ | (851 | ) |  | (4.4 | )% |  | $ | (1,894 | ) |  | (2.8 | )% |  | 32 | % |  | $ | (2,793 | ) |  | (4.9 | )% |
| Net loss attributable to Dell Technologies Inc. | $ | (876 | ) |  | (3.9 | )% |  | (4 | )% |  | $ | (846 | ) |  | (4.3 | )% |  | $ | (2,011 | ) |  | (3.0 | )% |  | 27 | % |  | $ | (2,749 | ) |  | (4.8 | )% |
| Non-GAAP Financial Information |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Non-GAAP net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 17,640 |  |  | 77.9 | % |  | 16 | % |  | $ | 15,153 |  |  | 76.3 | % |  | $ | 52,495 |  |  | 78.0 | % |  | 19 | % |  | $ | 43,994 |  |  | 75.8 | % |
| Services | 5,011 |  |  | 22.1 | % |  | 7 | % |  | 4,698 |  |  | 23.7 | % |  | 14,821 |  |  | 22.0 | % |  | 5 | % |  | 14,068 |  |  | 24.2 | % |
| Total non-GAAP net revenue | $ | 22,651 |  |  | 100.0 | % |  | 14 | % |  | $ | 19,851 |  |  | 100.0 | % |  | $ | 67,316 |  |  | 100.0 | % |  | 16 | % |  | $ | 58,062 |  |  | 100.0 | % |
| Non-GAAP gross margin: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product (a) | $ | 3,904 |  |  | 22.1 | % |  | 11 | % |  | $ | 3,509 |  |  | 23.2 | % |  | $ | 11,792 |  |  | 22.5 | % |  | 22 | % |  | $ | 9,659 |  |  | 22.0 | % |
| Services (b) | 3,096 |  |  | 61.8 | % |  | 4 | % |  | 2,965 |  |  | 63.1 | % |  | 9,193 |  |  | 62.0 | % |  | 4 | % |  | 8,875 |  |  | 63.1 | % |
| Total non-GAAP gross margin | $ | 7,000 |  |  | 30.9 | % |  | 8 | % |  | $ | 6,474 |  |  | 32.6 | % |  | $ | 20,985 |  |  | 31.2 | % |  | 13 | % |  | $ | 18,534 |  |  | 31.9 | % |
| Non-GAAP operating expenses | $ | 4,936 |  |  | 21.8 | % |  | 13 | % |  | $ | 4,365 |  |  | 22.0 | % |  | $ | 14,787 |  |  | 22.0 | % |  | 13 | % |  | $ | 13,134 |  |  | 22.6 | % |
| Non-GAAP operating income | $ | 2,064 |  |  | 9.1 | % |  | (2 | )% |  | $ | 2,109 |  |  | 10.6 | % |  | $ | 6,198 |  |  | 9.2 | % |  | 15 | % |  | $ | 5,400 |  |  | 9.3 | % |
| Non-GAAP net income | $ | 1,200 |  |  | 5.3 | % |  | — | % |  | $ | 1,199 |  |  | 6.0 | % |  | $ | 3,723 |  |  | 5.5 | % |  | 21 | % |  | $ | 3,072 |  |  | 5.3 | % |
| EBITDA | $ | 1,605 |  |  | 7.1 | % |  | (7 | )% |  | $ | 1,727 |  |  | 8.7 | % |  | $ | 5,284 |  |  | 7.8 | % |  | 28 | % |  | $ | 4,144 |  |  | 7.1 | % |
| Adjusted EBITDA | $ | 2,426 |  |  | 10.7 | % |  | (1 | )% |  | $ | 2,441 |  |  | 12.3 | % |  | $ | 7,268 |  |  | 10.8 | % |  | 13 | % |  | $ | 6,416 |  |  | 11.1 | % |

[0001571996-18-000044:mdna:84]
[same as prior period, unchanged from 0001571996-18-000034:mdna:78]

[0001571996-18-000044:mdna:85]
[same as prior period, unchanged from 0001571996-18-000034:mdna:79]

[0001571996-18-000044:mdna:86]
[same as prior period, unchanged from 0001571996-18-000034:mdna:80]

[0001571996-18-000044:mdna:87]
Non-GAAP product net revenue, non-GAAP services net revenue, non-GAAP net revenue, non-GAAP product gross margin, non-GAAP services gross margin, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP operating income, non-GAAP net income from continuing operations, EBITDA, and adjusted EBITDA are not measurements of financial performance prepared in accordance with GAAP.  Non-GAAP financial measures as a percentage of revenue are calculated based on non-GAAP net revenue.  See “Non‑GAAP Financial Measures” for additional information about these non-GAAP financial measures, including our reasons for including these measures, material limitations with respect to the usefulness of the measures, and a reconciliation of each non-GAAP financial measure to the most directly comparable GAAP financial measure.

[0001571996-18-000044:mdna:88]
[same as prior period, unchanged from 0001571996-18-000034:mdna:82]

[0001571996-18-000044:mdna:89]
The strong global macro-economic environment has generated robust demand for our products.  Dell Technologies is well-positioned to meet this demand with complementary solutions across our strategically aligned family of businesses.  During the third quarter and first nine months of Fiscal 2019, our net revenue increased 15% and 17%, respectively.  During the third quarter and first nine months of Fiscal 2019, our non-GAAP net revenue increased 14% and 16%, respectively.  The increases in net revenue and non-GAAP net revenue were attributable to increases in net revenue across all three business units.  The momentum in server, client, and VMware that started building last year has continued in Fiscal 2019 and we are seeing progress in the growth of our storage business revenue.

[0001571996-18-000044:mdna:90]
During the third quarter of Fiscal 2019 and Fiscal 2018, our operating loss was $356 million and $410 million, respectively. During the first nine months of Fiscal 2019 and Fiscal 2018, our operating loss was $0.5 billion and $2.3 billion, respectively.   The decrease in our operating loss for the third quarter and first nine months of Fiscal 2019 was primarily attributable to a decrease in amortization of intangible assets and purchase accounting adjustments related to the EMC merger transaction and an increase in operating income for ISG and VMware.

[0001571996-18-000044:mdna:91]
Amortization of intangible assets and purchase accounting adjustments that impacted operating income totaled $1.7 billion and $2.1 billion for the third quarter of Fiscal 2019 and Fiscal 2018, respectively, and $5.2 billion and $6.4 billion for the first nine months of Fiscal 2019 and Fiscal 2018, respectively.  Excluding these costs, transaction-related expenses, and other corporate expenses, non-GAAP operating income decreased 2% to $2.1 billion and increased 15% to $6.2 billion during the third quarter and first nine months of Fiscal 2019, respectively.  The increase in non-GAAP operating income for the first nine months of Fiscal 2019 was primarily due to an increase in operating income for ISG and VMware.

[0001571996-18-000044:mdna:92]
Cash provided by operating activities was $4.6 billion and $3.7 billion during the first nine months of Fiscal 2019 and Fiscal 2018, respectively.  The increase in operating cash flows during the first nine months of Fiscal 2019 was driven by business momentum, improved profitability, and management of working capital.  See “Market Conditions, Liquidity, and Capital Commitments” for further information on our cash flow metrics.

[0001571996-18-000044:mdna:93]
[same as prior period, unchanged from 0001571996-18-000034:mdna:87]

[0001571996-18-000044:mdna:94]
During the third quarter and first nine months of Fiscal 2019, our net revenue increased 15% and 17%, respectively.  During the third quarter and first nine months of Fiscal 2019, our non-GAAP net revenue increased 14% and 16%, respectively.  The increases in net revenue and non-GAAP net revenue were attributable to increases in net revenue across all three business units.  See “Business Unit Results” for further information.

[0001571996-18-000044:mdna:95]
| • | Product Net Revenue — Product net revenue includes revenue from the sale of hardware products and software licenses. During the third quarter of Fiscal 2019, product net revenue and non-GAAP product net revenue increased 17% and 16%, respectively. During the first nine months of Fiscal 2019, product net revenue and non-GAAP product net revenue increased 20% and 19%, respectively. These increases were attributable to an increase in product revenue across all three business units, driven by strength in sales across all product categories. |

[0001571996-18-000044:mdna:96]
| • | Services Net Revenue — Services net revenue includes revenue from our services offerings and support services related to hardware products and software licenses. During the third quarter of Fiscal 2019, services net revenue and non-GAAP services net revenue increased 9% and 7%, respectively. During the first nine months of Fiscal 2019, services net revenue and non-GAAP services net revenue increased 8% and 5%, respectively. These increases were primarily due to an increase in services revenue for hardware support and deployment and software maintenance due to growth in the business. |

[0001571996-18-000044:mdna:97]
From a geographical perspective, net revenue generated by sales to customers in all regions increased in the third quarter and first nine months of Fiscal 2019 due to strong performance globally in all three business units.

[0001571996-18-000044:mdna:98]
[same as prior period, unchanged from 0001571996-18-000034:mdna:93]

[0001571996-18-000044:mdna:99]
During the third quarter and first nine months of Fiscal 2019, our gross margin increased 14% to $5.9 billion and 23% to $17.9 billion, respectively.  Our gross margin percentage decreased 30 basis points to 26.4% and increased 120 basis points to 26.9%, respectively, during the third quarter and first nine months of Fiscal 2019.  The decrease in our gross margin percentage during the third quarter of Fiscal 2019 was primarily attributable to gross margin rate pressure in CSG due to geographical mix and product mix dynamics in ISG due to growth in sales of servers, which were offset partially by a decrease in amortization of intangibles and purchase accounting adjustments. The increase in our gross margin percentage during the first nine months of Fiscal 2019 was primarily attributable to a decrease in amortization of intangibles and purchase accounting adjustments, offset partially by gross margin rate pressure in CSG and product mix dynamics in ISG due to growth in sales of servers.

[0001571996-18-000044:mdna:100]
Our gross margin for the third quarter and first nine months of Fiscal 2019 included the impact of amortization of intangibles and purchase accounting adjustments of $0.9 billion and $2.7 billion, respectively.  In comparison, the impact of amortization of intangibles and purchase accounting adjustments in the third quarter and first nine months of Fiscal 2018 totaled $1.2 billion and $3.8 billion, respectively.  Excluding these costs, transaction-related expenses, and other corporate expenses, non-GAAP gross margin for the third quarter and first nine months of Fiscal 2019 increased 8% to $7.0 billion and 13% to $21.0 billion, respectively, and non-GAAP gross margin percentage decreased 170 basis points to 30.9% and 70 basis points to 31.2%, respectively.  The increases in our non-GAAP gross margin were attributable to increases in gross margin across all three business units.  The decreases in our non-GAAP gross margin percentage were primarily due to gross margin rate pressure in CSG and product mix dynamics in ISG due to growth in sales of servers.

[0001571996-18-000044:mdna:101]
| • | Products — During the third quarter of Fiscal 2019, product gross margin increased 20% to $3.1 billion, and product gross margin percentage increased 60 basis points to 17.4%. The increase in product gross margin was driven primarily by increases in product revenue in ISG and VMware due to strength in sales of ISG servers and storage, and VMware software licenses. Product gross margin also benefited from a decrease in the impact of amortization of intangibles and purchase accounting adjustments. Product gross margin percentage increased primarily as a result of a decrease in the impact of amortization of intangibles and purchase accounting adjustments. |

[0001571996-18-000044:mdna:102]
During the third quarter of Fiscal 2019, non-GAAP product gross margin increased 11% to $3.9 billion, and non-GAAP product gross margin percentage decreased 110 basis points to 22.1%.  The increase in non-GAAP product gross margin was driven primarily by increases in product revenue in ISG and VMware due to strength in sales of ISG servers and storage and VMware software licenses, partially offset by gross margin rate pressure in CSG commercial and consumer products due to geographical mix and product mix dynamics in ISG due to growth in sales of servers.  Non-GAAP product gross margin percentage decreased due to lower product gross margin percentage for CSG and ISG, which was partially offset by an increase in product gross margin percentages for VMware.

[0001571996-18-000044:mdna:103]
During the first nine months of Fiscal 2019 product gross margin increased 40% to $9.3 billion, and product gross margin percentage increased 260 basis points to 17.8%.  During the first nine months of Fiscal 2019, non-GAAP product gross margin increased 22% to $11.8 billion, and non-GAAP product gross margin percentage increased 50 basis points to 22.5%.  The increases in product gross margin and non-GAAP product gross margin were driven primarily by increases in product revenue in all three business units due to strength in sales of ISG servers and storage, CSG commercial products, and VMware software licenses.  Product gross margin percentage and non-GAAP product gross margin percentage increased primarily as a result of higher product gross margin percentages for ISG and VMware.

[0001571996-18-000044:mdna:104]
In the second quarter of Fiscal 2018, we entered into a settlement agreement with a vendor to resolve a dispute regarding past pricing practices.  Our gross margin for the second quarter and first nine months of Fiscal 2018 included a benefit of $68 million related to receipt of payment under the settlement.  Vendor settlements are allocated to our segments based on the relative amount of affected vendor products sold by each segment.  The $68 million settlement benefit was entirely allocated to CSG.

[0001571996-18-000044:mdna:105]
78

[0001571996-18-000044:mdna:106]
| • | Services — During the third quarter of Fiscal 2019, services gross margin increased 8% to $2.9 billion, and services gross margin percentage decreased 90 basis points to 59.4%. Services gross margin increased due to growth in services gross margin across all business units, particularly in hardware support and deployment and software maintenance. Services gross margin also benefited from a decrease in purchase accounting adjustments, which totaled $154 million and $262 million, respectively, during the third quarter of Fiscal 2019 and Fiscal 2018. Excluding these costs, transaction-related expenses, and other corporate expenses, non-GAAP services gross margin increased 4% to $3.1 billion, and non-GAAP services gross margin percentage decreased 130 basis points to 61.8%. Services gross margin percentage decreased primarily due to lower services gross margin percentages in all three business units. |

[0001571996-18-000044:mdna:107]
During the first nine months of Fiscal 2019, services gross margin increased 8% to $8.6 billion, and services gross margin percentage decreased 10 basis points to 60.1%.  Services gross margin increased due to growth in services gross margin across all business units, particularly in hardware support and deployment and software maintenance.  Services gross margin also benefited from a decrease in purchase accounting adjustments, which totaled $0.5 billion and $0.8 billion, respectively, during the first nine months of Fiscal 2019 and Fiscal 2018.  Excluding these costs, transaction-related expenses, and other corporate expenses, non-GAAP services gross margin increased 4% to $9.2 billion, and non-GAAP services gross margin percentage decreased 110 basis points to 62.0%.  Services gross margin percentage decreased primarily due to lower services gross margin percentages in all three business units.

[0001571996-18-000044:mdna:108]
[same as prior period, unchanged from 0001571996-18-000034:mdna:102]

[0001571996-18-000044:mdna:109]
[same as prior period, unchanged from 0001571996-18-000034:mdna:103]

[0001571996-18-000044:mdna:110]
The terms and conditions of our vendor rebate programs are largely based on product volumes and are generally negotiated either at the beginning of the annual or quarterly period, depending on the program.  The timing and amount of vendor rebates and other discounts we receive under the programs may vary from period to period, reflecting changes in the competitive environment.  We monitor our component costs and seek to address the effects of any changes to terms that might arise under our vendor rebate programs.  Our gross margins for the third quarter and first nine months of Fiscal 2019 and Fiscal 2018 were not materially affected by any changes to the terms of our vendor rebate programs, as the amounts we received under these programs were generally stable relative to our total net cost.  We are not aware of any significant changes to vendor pricing or rebate programs that may impact our results in the near term.

[0001571996-18-000044:mdna:111]
In addition, we have pursued legal action against certain vendors and are currently involved in negotiations with other vendors regarding their past pricing practices.  We have negotiated settlements with some of these vendors and may have additional settlements in future periods.  These settlements are allocated to our segments based on the relative amount of affected vendor products sold by each segment.  As discussed above, a pricing settlement was recorded in the second quarter of Fiscal 2018 that benefited product gross margins by $68 million in the first nine months of Fiscal 2018.  No such settlements were recorded in the third quarter and first nine months of Fiscal 2019 that would have a material impact on product gross margins in the current quarter or affect comparability with product gross margin in the third quarter and first nine months of Fiscal 2018.

[0001571996-18-000044:mdna:112]
79

[0001571996-18-000044:mdna:113]
[same as prior period, unchanged from 0001571996-18-000034:mdna:106]

[0001571996-18-000044:mdna:114]
[same as prior period, unchanged from 0001571996-18-000034:mdna:107]

[0001571996-18-000044:mdna:115]
|  | Three Months Ended |  | Nine Months Ended |
|  | November 2, 2018 |  |  |  | November 3, 2017 |  | November 2, 2018 |  |  |  | November 3, 2017 |
|  | Dollars |  | % ofNet Revenue |  | %Change |  | Dollars |  | % ofNet Revenue |  | Dollars |  | % ofNet Revenue |  | %Change |  | Dollars |  | % ofNet Revenue |
|  | (in millions, except percentages) |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling, general, and administrative | $ | 5,159 |  |  | 22.9 | % |  | 13 | % |  | $ | 4,559 |  |  | 23.3 | % |  | $ | 15,064 |  |  | 22.6 | % |  | 10 | % |  | $ | 13,695 |  |  | 24.0 | % |
| Research and development | 1,140 |  |  | 5.1 | % |  | 6 | % |  | 1,071 |  |  | 5.5 | % |  | 3,402 |  |  | 5.1 | % |  | 3 | % |  | 3,297 |  |  | 5.8 | % |
| Total operating expenses | $ | 6,299 |  |  | 28.0 | % |  | 12 | % |  | $ | 5,630 |  |  | 28.8 | % |  | $ | 18,466 |  |  | 27.7 | % |  | 9 | % |  | $ | 16,992 |  |  | 29.8 | % |
| Other Financial Information |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Non-GAAP operating expenses | $ | 4,936 |  |  | 21.8 | % |  | 13 | % |  | $ | 4,365 |  |  | 22.0 | % |  | $ | 14,787 |  |  | 22.0 | % |  | 13 | % |  | $ | 13,134 |  |  | 22.6 | % |

[0001571996-18-000044:mdna:116]
During the third quarter and first nine months of Fiscal 2019, total operating expenses increased 12% and 9%, respectively.  Our operating expenses include the impact of purchase accounting, amortization of intangible assets, transaction-related expenses, and other corporate expenses.  Other corporate expenses included a goodwill impairment charge of approximately $190 million recorded during the third quarter of Fiscal 2019.  In aggregate, these items totaled $1.4 billion and $1.3 billion for the third quarter of Fiscal 2019 and Fiscal 2018, respectively, and $3.7 billion and $3.9 billion for the first nine months of Fiscal 2019 and Fiscal 2018, respectively.  Excluding these costs, total non-GAAP operating expenses for both the third quarter and first nine months of Fiscal 2019 increased 13%.  The increases in operating expenses and non-GAAP operating expenses were primarily due to an increase in selling, general, and administrative expenses associated with our revenue growth and sales headcount.

[0001571996-18-000044:mdna:117]
| • | Selling, General, and Administrative — Selling, general, and administrative (“SG&A”) expenses increased 13% and 10%, respectively, during the third quarter and first nine months of Fiscal 2019. The increases in SG&A expenses were primarily driven by investments in our go-to-market capabilities and higher performance-based compensation and commission costs, as well as a goodwill impairment charge of approximately $190 million recorded during the third quarter of Fiscal 2019. |

[0001571996-18-000044:mdna:118]
| • | Research and Development — Research and development (“R&D”) expenses are primarily composed of personnel-related expenses related to product development. R&D expenses as a percentage of net revenue for the third quarter of Fiscal 2019 and Fiscal 2018 were approximately 5.1% and 5.5%, respectively. R&D expenses as a percentage of net revenue for the first nine months of Fiscal 2019 and Fiscal 2018 were approximately 5.1% and 5.8%, respectively. The decreases in R&D expenses as a percentage of net revenue were attributable to revenue growth that outpaced the scale of R&D investments. As our industry continues to change and as the needs of our customers evolve, we intend to support R&D initiatives to innovate and introduce new and enhanced solutions into the market. |

[0001571996-18-000044:mdna:119]
We continue to make investments designed to enable growth, particularly in our sales force, marketing, and R&D, while balancing our efforts to drive cost efficiencies in the business.  We also expect to continue to make investments in support of our own digital transformation to modernize and streamline our IT operations.

[0001571996-18-000044:mdna:120]
[same as prior period, unchanged from 0001571996-18-000034:mdna:113]

[0001571996-18-000044:mdna:121]
During the third quarter of Fiscal 2019, our operating loss decreased 13% to $356 million.  The decrease in our operating loss for the third quarter of Fiscal 2019 was primarily attributable to a decrease in amortization of intangible assets and purchase accounting adjustments and an increase in operating income for ISG and VMware.  During the first nine months of Fiscal 2019, our operating loss decreased 78% to $0.5 billion.  The decrease in our operating loss for the first nine months of Fiscal 2019 was primarily attributable to a decrease in amortization of intangible assets and purchase accounting adjustments and an increase in operating income for ISG and VMware.

[0001571996-18-000044:mdna:122]
Amortization of intangible assets and purchase accounting adjustments that impacted operating income totaled $1.7 billion and $2.1 billion for the third quarter of Fiscal 2019 and Fiscal 2018, respectively, and $5.2 billion and $6.4 billion for the first nine months of Fiscal 2019 and Fiscal 2018, respectively.  Excluding these costs, transaction-related expenses, and other corporate expenses, non-GAAP operating income decreased 2% to $2.1 billion, and increased 15% to $6.2 billion during the third quarter and first nine months of Fiscal 2019, respectively.  Non-GAAP operating income during the third quarter of Fiscal 2019 decreased primarily due to a decrease in operating income for CSG, which was partially offset by an increase in operating income for ISG and VMware.  The increase in non-GAAP operating income for the first nine months of Fiscal 2019 was primarily due to an increase in operating income for ISG and VMware.

[0001571996-18-000044:mdna:123]
[same as prior period, unchanged from 0001571996-18-000034:mdna:117]

[0001571996-18-000044:mdna:124]
[same as prior period, unchanged from 0001571996-18-000034:mdna:118]

[0001571996-18-000044:mdna:125]
|  | Three Months Ended |  | Nine Months Ended |
|  | November 2, 2018 |  | November 3, 2017 |  | November 2, 2018 |  | November 3, 2017 |
|  | (in millions) |
| Interest and other, net: |  |  |  |  |  |  |  |  |  |  |  |
| Investment income, primarily interest | $ | 84 |  |  | $ | 57 |  |  | $ | 247 |  |  | $ | 142 |  |
| Gain (loss) on investments, net | (17 | ) |  | (3 | ) |  | 229 |  |  | 22 |  |
| Interest expense | (612 | ) |  | (607 | ) |  | (1,830 | ) |  | (1,802 | ) |
| Foreign exchange | (63 | ) |  | (35 | ) |  | (174 | ) |  | (77 | ) |
| Other | (31 | ) |  | (94 | ) |  | (36 | ) |  | (84 | ) |
| Total interest and other, net | $ | (639 | ) |  | $ | (682 | ) |  | $ | (1,564 | ) |  | $ | (1,799 | ) |

[0001571996-18-000044:mdna:126]
Effective in the first quarter of Fiscal 2019, we adopted the new accounting guidance for “Recognition and Measurement of Financial Assets and Financial Liabilities.”  As a result, we record in interest and other, net, changes in the fair value of our publicly-traded strategic investments and changes in the value of our strategic investments without readily determinable fair values when adjusted to fair value upon observable price changes or impairment.  During the first nine months of Fiscal 2019, the change in interest and other, net was favorable by $235 million, primarily due to gains on strategic investments.  See Note 1 and Note 4 of the Notes to the Condensed Consolidated Financial Statements included in this report for further information regarding our recently adopted accounting standards and our investments, respectively.

[0001571996-18-000044:mdna:127]
[same as prior period, unchanged from 0001571996-18-000034:mdna:121]

[0001571996-18-000044:mdna:128]
For the third quarter and first nine months of Fiscal 2019, our effective income tax rates were 10.1% and 9.2%, respectively, on pre-tax losses of $1.0 billion and $2.1 billion, respectively.  For the third quarter and first nine months of Fiscal 2018, our effective income tax rates were 22.1% and 32.6%, respectively, on pre-tax losses of $1.1 billion and $4.1 billion, respectively.  The changes in our effective income tax rates for the third quarter and first nine months of Fiscal 2019 were primarily attributable to impacts of the Tax Cuts and Jobs Act of 2017 (“U.S. Tax Reform”).  The change in our effective income tax rate for the first nine months of Fiscal 2019, was also impacted by discrete tax benefits resulting from the impact of adopting the new revenue standard.

[0001571996-18-000044:mdna:129]
U.S. Tax Reform was signed into law on December 22, 2017.  U.S. Tax Reform lowers the U.S. corporate income tax rate to 21% from 35%, establishes a modified territorial system requiring a mandatory deemed repatriation tax on undistributed earnings of foreign subsidiaries (the “Transition Tax”), requires a minimum tax on certain future earnings generated by foreign subsidiaries while providing for future tax-free repatriation of earnings through a 100% dividends-received deduction, and places limitations on the deductibility of net interest expense.

[0001571996-18-000044:mdna:130]
GAAP requires the effect of a change in tax laws to be recognized in the period that includes the enactment date.  Accordingly, for Fiscal 2018 we recognized a provisional tax benefit of $0.5 billion related to U.S. Tax Reform, primarily driven by a $1.5 billion tax benefit related to the remeasurement of deferred tax assets and liabilities, offset by $1.0 billion of current and future income tax expenses related to the Transition Tax.  We continue to collect and process the data necessary to complete our determination of the accounting implications of U.S. Tax Reform, as well as to evaluate the impact of recently proposed guidance issued by the U.S. Treasury Department on the provision calculation.  Any final guidance to be issued by the U.S. Treasury Department also could further affect the provisional calculation.  As a result, no adjustments have been made to the provisional amount recorded for Fiscal 2018.  In accordance with SEC Staff Accounting Bulletin 118, any adjustments to our provisional estimates will be complete by the fourth quarter of Fiscal 2019.  Revisions to our provisional estimates may be material.

[0001571996-18-000044:mdna:131]
[same as prior period, unchanged from 0001571996-18-000034:mdna:126]

[0001571996-18-000044:mdna:132]
[same as prior period, unchanged from 0001571996-18-000034:mdna:127]

[0001571996-18-000044:mdna:133]
[same as prior period, unchanged from 0001571996-18-000034:mdna:128]

[0001571996-18-000044:mdna:134]
During the third quarter and first nine months of Fiscal 2019, net loss increased 5% to $0.9 billion and decreased 32% to $1.9 billion, respectively.  The increase in net loss during the third quarter of Fiscal 2019 was primarily attributable to a decrease in tax benefit, which was partially offset by a decrease in operating loss and, to a lesser extent, a decrease in interest and other, net expense.  The decrease in net loss during the first nine months of Fiscal 2019 was primarily attributable to a decrease in operating loss and, to a lesser extent, a decrease in interest and other, net expense, which was partially offset by a decrease in tax benefit.

[0001571996-18-000044:mdna:135]
Net loss for the third quarter and first nine months of Fiscal 2019 included amortization of intangible assets, the impact of purchase accounting, transaction-related expenses, and other corporate expenses.  Excluding these costs and the related tax impacts, non-GAAP net income remained flat at $1.2 billion and increased 21% to $3.7 billion during the third quarter and first nine months of Fiscal 2019, respectively.  The increase in non-GAAP net income during the first nine months of Fiscal 2019 was primarily attributable to an increase in operating income and a decrease in interest and other, net expense, which was partially offset by an increase in income tax expense.

[0001571996-18-000044:mdna:136]
[same as prior period, unchanged from 0001571996-18-000034:mdna:131]

[0001571996-18-000044:mdna:137]
During the third quarter and first nine months of Fiscal 2019, net loss attributable to non-controlling interests was $19 million and net income attributable to non-controlling interests was $117 million, respectively, compared to a net loss attributable to non-controlling interests of $5 million and $44 million, respectively, during the third quarter and first nine months of Fiscal 2018.  Net income or loss attributable to non-controlling interests consisted of net income or loss attributable to our non-controlling interests in VMware, Inc., Pivotal, and SecureWorks.  For more information about our non-controlling interests, see Note 14 of the Notes to the Condensed Consolidated Financial Statements included in this report.

[0001571996-18-000044:mdna:138]
[same as prior period, unchanged from 0001571996-18-000034:mdna:133]

[0001571996-18-000044:mdna:139]
Net loss attributable to Dell Technologies Inc. represents net loss and an adjustment for non-controlling interests.  Net loss attributable to Dell Technologies Inc. was $0.9 billion and $0.8 billion, respectively, during the third quarter of Fiscal 2019 and Fiscal 2018, and $2.0 billion and $2.7 billion, respectively, during the first nine months of Fiscal 2019 and Fiscal 2018.  The decrease in net loss attributable to Dell Technologies Inc. during the first nine months of Fiscal 2019 was primarily attributable to a decrease in net loss for the period.

[0001571996-18-000044:mdna:140]
[same as prior period, unchanged from 0001571996-18-000034:mdna:135]

[0001571996-18-000044:mdna:141]
Our reportable segments are based on the following business units: ISG, CSG, and VMware.  A description of our three business units is provided under “Introduction.”  See Note 18 of the Notes to the Condensed Consolidated Financial Statements included in this report for a reconciliation of net revenue and operating income by reportable segment to consolidated net revenue and consolidated operating loss, respectively.

[0001571996-18-000044:mdna:142]
[same as prior period, unchanged from 0001571996-18-000034:mdna:137]

[0001571996-18-000044:mdna:143]
[same as prior period, unchanged from 0001571996-18-000034:mdna:138]

[0001571996-18-000044:mdna:144]
[same as prior period, unchanged from 0001571996-18-000034:mdna:139]

[0001571996-18-000044:mdna:145]
|  | Three Months Ended |  | Nine Months Ended |
|  | November 2, 2018 |  | % Change |  | November 3, 2017 |  | November 2, 2018 |  | % Change |  | November 3, 2017 |
|  | (in millions, except percentages) |
| Net Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Servers and networking | $ | 5,054 |  |  | 30% |  | $ | 3,875 |  |  | $ | 14,700 |  |  | 35% |  | $ | 10,908 |  |
| Storage | 3,883 |  |  | 6% |  | 3,660 |  |  | 12,131 |  |  | 10% |  | 11,055 |  |
| Total ISG net revenue | $ | 8,937 |  |  | 19% |  | $ | 7,535 |  |  | $ | 26,831 |  |  | 22% |  | $ | 21,963 |  |
| Operating Income: |  |  |  |  |  |  |  |  |  |  |  |
| ISG operating income | $ | 935 |  |  | 7% |  | $ | 870 |  |  | $ | 2,886 |  |  | 43% |  | $ | 2,023 |  |
| % of segment net revenue | 10.5 | % |  |  |  | 11.5 | % |  | 10.8 | % |  |  |  | 9.2 | % |

[0001571996-18-000044:mdna:146]
Net Revenue — During the third quarter and first nine months of Fiscal 2019, ISG net revenue increased 19% and 22%, respectively, primarily due to an increase in sales of servers and networking as well as an increase in sales of storage.  Revenue from servers and networking increased 30% and 35%, respectively, during the third quarter and first nine months of Fiscal 2019, driven by an increase in both average selling price and units sold of our PowerEdge servers.  Average selling prices increased due to the sale of servers with higher memory and storage content, which is driven by customer demand for servers that enable big data analytics and software-defined solutions, as well as increased component costs.  Storage revenue increased 6% and 10%, respectively, during the third quarter and first nine months of Fiscal 2019 due to strong growth in our high-end storage products and unstructured storage array solutions.  We have been making go-to-market investments and enhancements to our storage solutions offerings, and expect that these investments will drive long-term improvements in the business.  Although component costs were inflationary during the first nine months of Fiscal 2019, they were slightly deflationary in the aggregate for ISG during the third quarter of Fiscal 2019, and we continue to monitor our pricing in response to the current component cost environment.  We expect the aggregate ISG component cost environment to continue to be slightly deflationary for the remainder of Fiscal 2019.

[0001571996-18-000044:mdna:147]
[same as prior period, unchanged from 0001571996-18-000034:mdna:142]

[0001571996-18-000044:mdna:148]
From a geographical perspective, net revenue attributable to ISG increased across all regions during the third quarter and first nine months of Fiscal 2019.

[0001571996-18-000044:mdna:149]
Operating Income — During the third quarter of Fiscal 2019, ISG operating income as a percentage of net revenue decreased 100 basis points to 10.5%.  During the third quarter of Fiscal 2019, we experienced gross margin pressure due to a shift in product mix to servers, which typically have a lower gross margin than storage products. We expect this trend to continue in the short-term as the demand for servers continues to outpace the growth in storage.  The decrease in ISG gross margin was partially offset by a decrease in operating expenses as a percentage of revenue.  Despite the investments we have been making in our go-to-market capabilities and solutions offerings, operating expenses decreased as a percentage of revenue as a result of revenue growth that outpaced the scale of these investments.

[0001571996-18-000044:mdna:150]
During the first nine months of Fiscal 2019, ISG operating income as a percentage of net revenue increased 160 basis points to 10.8% primarily due to a decrease in operating expenses as a percentage of revenue.  The benefit from the decrease in operating expense percentage was partially offset by a decrease in ISG gross margin percentage due to a shift in product mix to servers.

[0001571996-18-000044:mdna:151]
[same as prior period, unchanged from 0001571996-18-000034:mdna:146]

[0001571996-18-000044:mdna:152]
[same as prior period, unchanged from 0001571996-18-000034:mdna:147]

[0001571996-18-000044:mdna:153]
|  | Three Months Ended |  | Nine Months Ended |
|  | November 2, 2018 |  | % Change |  | November 3, 2017 |  | November 2, 2018 |  | % Change |  | November 3, 2017 |
|  | (in millions, except percentages) |
| Net Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Commercial | $ | 7,613 |  |  | 12% |  | $ | 6,778 |  |  | $ | 23,085 |  |  | 14% |  | $ | 20,327 |  |
| Consumer | 3,292 |  |  | 8% |  | 3,051 |  |  | 9,219 |  |  | 10% |  | 8,416 |  |
| Total CSG net revenue | $ | 10,905 |  |  | 11% |  | $ | 9,829 |  |  | $ | 32,304 |  |  | 12% |  | $ | 28,743 |  |
| Operating Income: |  |  |  |  |  |  |  |  |  |  |  |
| CSG operating income | $ | 447 |  |  | (29)% |  | $ | 630 |  |  | $ | 1,405 |  |  | (5)% |  | $ | 1,483 |  |
| % of segment net revenue | 4.1 | % |  |  |  | 6.4 | % |  | 4.3 | % |  |  |  | 5.2 | % |

[0001571996-18-000044:mdna:154]
Net Revenue — During the third quarter and first nine months of Fiscal 2019, CSG net revenue increased 11% and 12%, respectively, driven by continued strong demand and increased sales volume across both commercial and consumer categories in notebooks, workstations, and desktops.  During the first nine months of Fiscal 2019, overall average selling prices were higher, driven by an increase in both the commercial and consumer product categories, as we managed our pricing in response to supply chain dynamics, geographical mix, and an inflationary component cost environment during the first six months of Fiscal 2019.  During the third quarter of Fiscal 2019, the aggregate CSG component cost environment was deflationary and we expect deflationary conditions to continue for the remainder of Fiscal 2019.

[0001571996-18-000044:mdna:155]
From a geographical perspective, net revenue attributable to CSG increased across all regions during the third quarter and first nine months of Fiscal 2019.

[0001571996-18-000044:mdna:156]
Operating Income — During the third quarter of Fiscal 2019, CSG operating income as a percentage of net revenue decreased 230 basis points to 4.1% as a result of a decline in gross margin percentage and an increase in operating expenses as a percentage of revenue.  The decline in our gross margin percentage was primarily attributable to supply chain dynamics, and a strengthening U.S. dollar that impacted our ability to adjust pricing in response to geographical mix.  Operating expenses increased due to higher performance-based compensation and commission costs.

[0001571996-18-000044:mdna:157]
During the first nine months of Fiscal 2019, CSG operating income as a percentage of net revenue decreased 90 basis points to 4.3%.  The decrease was primarily due to higher component costs that negatively impacted CSG gross margin and to increases in CSG operating expense as a percentage of revenue resulting from higher performance-driven commission costs and marketing expense related to our net revenue growth.  In addition, the decline in CSG operating income as a percentage of revenue during the first nine months of Fiscal 2019 was partially attributable to a $68 million vendor settlement recorded in the second quarter of Fiscal 2018, which resulted in an incremental 30 basis points to our operating income percentage in the prior period that did not recur.  Removing the effect of this vendor settlement, CSG operating income as a percentage of revenue decreased 60 basis points during the third quarter of Fiscal 2019.

[0001571996-18-000044:mdna:158]
84

[0001571996-18-000044:mdna:159]
[same as prior period, unchanged from 0001571996-18-000034:mdna:153]

[0001571996-18-000044:mdna:160]
[same as prior period, unchanged from 0001571996-18-000034:mdna:154]

[0001571996-18-000044:mdna:161]
|  | Three Months Ended |  | Nine Months Ended |
|  | November 2, 2018 |  | % Change |  | November 3, 2017 |  | November 2, 2018 |  | % Change |  | November 3, 2017 |
|  | (in millions, except percentages) |
| Net Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| VMware net revenue | $ | 2,229 |  |  | 15% |  | $ | 1,933 |  |  | $ | 6,451 |  |  | 12% |  | $ | 5,735 |  |
| Operating Income: |  |  |  |  |  |  |  |  |  |  |  |
| VMware operating income | $ | 768 |  |  | 21% |  | $ | 634 |  |  | $ | 2,117 |  |  | 7% |  | $ | 1,973 |  |
| % of segment net revenue | 34.5 | % |  |  |  | 32.8 | % |  | 32.8 | % |  |  |  | 34.4 | % |

[0001571996-18-000044:mdna:162]
Net Revenue — VMware net revenue primarily consisted of revenue from the sale of software licenses under perpetual licenses, related software maintenance and support, training, consulting services, and hosted services.  VMware net revenue during the third quarter and first nine months of Fiscal 2019 increased 15% and 12%, respectively, primarily due to growth in software license revenue and sales of software maintenance services.  Software license revenue benefited from broad-based growth across the product portfolio.  Software maintenance revenue benefited from strong renewals, revenue recognized from maintenance contracts sold in prior periods, and new maintenance contracts sold during the period.

[0001571996-18-000044:mdna:163]
From a geographical perspective, approximately half of VMware net revenue during the third quarter and first nine months of Fiscal 2019 was generated by sales to customers in the United States.  VMware net revenue for the third quarter and first nine months of Fiscal 2019 benefited from growth across US and international geographies.

[0001571996-18-000044:mdna:164]
Operating Income — During the third quarter of Fiscal 2019, VMware operating income as a percentage of net revenue increased 170 basis points to 34.5%, driven primarily by an increase in gross margin percentage and a decrease in operating expense percentage of revenue, as revenue growth outpaced the increases in sales compensation-related expenses and R&D investments.

[0001571996-18-000044:mdna:165]
During the first nine months of Fiscal 2019, VMware operating income as a percentage of net revenue decreased 160 basis points to 32.8%.  The decrease was driven by an increase in operating expenses as a percentage of revenue due to an increase in compensation-related expense associated with sales and sales support, which reflected increased performance-driven commission costs and headcount, as well as to an increase in R&D expenses.

[0001571996-18-000044:mdna:166]
[same as prior period, unchanged from 0001571996-18-000034:mdna:159]

[0001571996-18-000044:mdna:167]
[same as prior period, unchanged from 0001571996-18-000034:mdna:160]

[0001571996-18-000044:mdna:168]
[same as prior period, unchanged from 0001571996-18-000034:mdna:161]

[0001571996-18-000044:mdna:169]
We sell products and services directly to customers and through a variety of sales channels, including retail distribution.  Our accounts receivable, net, was $11.1 billion and $11.7 billion as of November 2, 2018 and February 2, 2018, respectively.  We maintain an allowance for doubtful accounts to cover receivables that may be deemed uncollectible.  The allowance for losses is based on a provision for accounts that are collectively evaluated based on historical bad debt experience as well as specific identifiable customer accounts that are deemed at risk.  As of November 2, 2018 and February 2, 2018, the allowance for doubtful accounts was $92 million and $103 million, respectively.  Based on our assessment, we believe that we are adequately reserved for expected credit losses.  We monitor the aging of our accounts receivable and continue to take actions to reduce our exposure to credit losses.

[0001571996-18-000044:mdna:170]
[same as prior period, unchanged from 0001571996-18-000034:mdna:163]

[0001571996-18-000044:mdna:171]
Dell Financial Services and its affiliates (“DFS”) offers a wide range of financial services, including originating, collecting, and servicing customer receivables primarily related to the purchase of Dell Technologies’ products and services.  In some cases, we also offer financing on the purchase of third-party technology products that complement our portfolio of products and services.  New financing originations were $1.6 billion for both the third quarter of Fiscal 2019 and Fiscal 2018, respectively, and $5.2 billion and $4.3 billion for the first nine months of Fiscal 2019 and Fiscal 2018, respectively.  As of November 2, 2018 and February 2, 2018, our financing receivables, net were $8.1 billion and $7.6 billion, respectively.

[0001571996-18-000044:mdna:172]
We have securitization facilities to fund revolving loans and fixed-term leases and loans through consolidated special purpose entities, referred to as SPEs, which we account for as secured borrowings.  We transfer certain U.S. and European customer financing receivables to these SPEs, whose purpose is to facilitate the funding of customer receivables through financing arrangements with multi-seller conduits that issue asset-backed debt securities in the capital markets and to private investors.  During the third quarter of Fiscal 2019 and Fiscal 2018, we transferred $1.2 billion and $1.0 billion, respectively, to these SPEs, and during the first nine months of Fiscal 2019 and Fiscal 2018, we transferred $3.7 billion and $2.9 billion, respectively, to the SPEs.  The DFS debt related to all of our securitization facilities included as secured borrowings was $4.9 billion and $3.9 billion as of November 2, 2018 and February 2, 2018, respectively.  In addition, the carrying amount of the corresponding financing receivables was $5.5 billion and $4.6 billion as of November 2, 2018 and February 2, 2018, respectively.

[0001571996-18-000044:mdna:173]
We maintain an allowance to cover expected financing receivable credit losses and evaluate credit loss expectations based on our total portfolio.  For the third quarter of Fiscal 2019 and Fiscal 2018, the principal charge-off rate for our total portfolio was 1.0% and 1.5%, respectively.  For the first nine months of Fiscal 2019 and Fiscal 2018, the principal charge-off rate for our total portfolio was 1.2% and 1.6%, respectively.  The credit quality of our financing receivables has improved in recent years due to an overall improvement in the credit environment and as the mix of high-quality commercial accounts in our portfolio has continued to increase.  The allowance for losses is determined based on various factors, including historical and anticipated experience, past due receivables, receivable type, and customer risk profile.  As of November 2, 2018 and February 2, 2018, the allowance for financing receivable losses was $126 million and $145 million, respectively.  In general, the loss rates on our financing receivables have improved over the periods presented.  We expect relatively stable loss rates in future periods, with movements in these rates being primarily driven by seasonality and a continued shift in portfolio composition to lower risk commercial assets.  We continue to monitor broader economic indicators and their potential impact on future loss performance.  We have an extensive process to manage our exposure to customer credit risk, including active management of credit lines and our collection activities.  We also sell selected fixed-term financing receivables to unrelated third parties on a periodic basis, primarily to manage certain concentrations of customer credit exposure.  Based on our assessment of the customer financing receivables, we believe that we are adequately reserved.

[0001571996-18-000044:mdna:174]
[same as prior period, unchanged from 0001571996-18-000034:mdna:167]

[0001571996-18-000044:mdna:175]
[same as prior period, unchanged from 0001571996-18-000034:mdna:168]

[0001571996-18-000044:mdna:176]
As of November 2, 2018, we had no off-balance sheet arrangements that have or are reasonably likely to have a current or future material effect on our financial condition or results of operations.

[0001571996-18-000044:mdna:177]
86

[0001571996-18-000044:mdna:178]
[same as prior period, unchanged from 0001571996-18-000034:mdna:170]

[0001571996-18-000044:mdna:179]
[same as prior period, unchanged from 0001571996-18-000034:mdna:171]

[0001571996-18-000044:mdna:180]
[same as prior period, unchanged from 0001571996-18-000034:mdna:172]

[0001571996-18-000044:mdna:181]
[same as prior period, unchanged from 0001571996-18-000034:mdna:173]

[0001571996-18-000044:mdna:182]
[same as prior period, unchanged from 0001571996-18-000034:mdna:174]

[0001571996-18-000044:mdna:183]
[same as prior period, unchanged from 0001571996-18-000034:mdna:175]

[0001571996-18-000044:mdna:184]
[same as prior period, unchanged from 0001571996-18-000034:mdna:176]

[0001571996-18-000044:mdna:185]
[same as prior period, unchanged from 0001571996-18-000034:mdna:177]

[0001571996-18-000044:mdna:186]
To support our ongoing business operations, we rely on operating cash flows as our primary source of liquidity.  We monitor the efficiency of our balance sheet to ensure that we have adequate liquidity to support our strategic initiatives.  In addition to internally generated cash, we have access to other capital sources to finance our strategic initiatives and fund growth in our financing operations.  As of November 2, 2018, we had $15.2 billion of total cash and cash equivalents, just over half of which was held outside of the United States, and $5.3 billion of total investments.  Our strategy is to deploy capital from any potential source, whether internally generated cash or debt, depending on the adequacy and availability of that source of capital and whether it can be accessed in a cost-effective manner.

[0001571996-18-000044:mdna:187]
A significant portion of our income is earned in non-U.S. jurisdictions.  Prior to the enactment of U.S. Tax Reform as discussed above in “Results of Operations — Income and Other Taxes”, earnings available to be repatriated to the United States would be subject to U.S. federal income tax, less applicable foreign tax credits.  U.S. Tax Reform fundamentally changes the U.S. approach to taxation of foreign earnings to a modified territorial tax system, which generally allows companies to make distributions of non-U.S. earnings to the United States without incurring additional U.S. federal tax.  However, local and U.S. state taxes may still apply.  We have provided for future tax liabilities on income earned in non-U.S. jurisdictions, except for foreign earnings that are considered indefinitely reinvested outside of the United States.

[0001571996-18-000044:mdna:188]
During the fourth quarter of Fiscal 2019, as discussed above in “Introduction — Class V Transaction,” we expect to complete a transaction in which the issued and outstanding shares of Class V Common Stock will be exchanged for shares of Class C Common Stock or cash at the stockholder’s election.  No more than $14 billion of cash, in the aggregate, will be paid to holders of Class V Common Stock in connection with the Class V transaction.

[0001571996-18-000044:mdna:189]
To fund a majority of the cash payment to stockholders, VMware, Inc. declared a conditional $11 billion one-time special cash dividend (the “Special Dividend”), payable pro-rata to VMware, Inc. stockholders as of the dividend record date and in connection with the closing of the proposed Class V transaction.  The payment of the dividend is subject to the satisfaction of the conditions to the Class V transaction and other specified conditions.  We will fund a majority of the cash consideration to be paid in the Class V transaction from our portion of the proceeds of the Special Dividend.  Our cash, cash equivalents, and investments will decline significantly, commensurate with the cash required to fund this transaction.  VMware, Inc. has advised us that, following its payment of the Special Dividend, VMware, Inc. expects to return to its historical capital allocation policy.

[0001571996-18-000044:mdna:190]
On November 14, 2018, we entered into a commitment letter with bank lenders providing for bridge financing to fund the $5 billion increase in the cash consideration for the Class V transaction.  The bridge financing will mature within one year of the closing date.  We are currently evaluating our options to replace the bridge financing with permanent financing and expect to complete this evaluation in the fourth quarter of Fiscal 2019.  See Note 20 of the Notes to the Condensed Consolidated Financial Statements included in this report for additional information about the bridge financing.

[0001571996-18-000044:mdna:191]
The following table summarizes our cash and cash equivalents as well as our available borrowings as of November 2, 2018 and February 2, 2018:

[0001571996-18-000044:mdna:192]
|  | November 2, 2018 |  | February 2, 2018 |
|  | (in millions) |
| Cash and cash equivalents, and available borrowings: |  |  |  |
| Cash and cash equivalents (a) | $ | 15,152 |  |  | $ | 13,942 |  |
| Remaining available borrowings under revolving credit facilities | 4,414 |  |  | 4,875 |  |
| Total cash, cash equivalents, and available borrowings | $ | 19,566 |  |  | $ | 18,817 |  |

[0001571996-18-000044:mdna:193]
[same as prior period, unchanged from 0001571996-18-000034:mdna:186]

[0001571996-18-000044:mdna:194]
(a)  Of the $15.2 billion of cash and cash equivalents as of November 2, 2018, $9.2 billion was held by VMware, Inc.  Of the $13.9 billion of cash and cash equivalents as of February 2, 2018, $6.0 billion was held by VMware, Inc.  Amounts exclude restricted cash.

[0001571996-18-000044:mdna:195]
Available borrowings under the Revolving Credit Facility are reduced by draws on the facility and outstanding letters of credit.  As of November 2, 2018, there were no borrowings outstanding under the facility and remaining available borrowings totaled approximately $3.3 billion.  These available borrowings may be used periodically for general corporate purposes.

[0001571996-18-000044:mdna:196]
The VMware Revolving Credit Facility and the Pivotal Revolving Credit Facility have maximum aggregate borrowings of $1.0 billion and $100 million, respectively.  None of the net proceeds of such borrowings will be made available to support the operations or satisfy any corporate purposes of Dell Technologies, other than the operations and corporate purposes of VMware, Inc., Pivotal, and their respective subsidiaries.  As of November 2, 2018, $1.0 billion was available under the VMware Revolving Credit Facility and $100 million was available under the Pivotal Revolving Credit Facility.

[0001571996-18-000044:mdna:197]
[same as prior period, unchanged from 0001571996-18-000034:mdna:190]

[0001571996-18-000044:mdna:198]
Our China Revolving Credit Facility expired on October 31, 2018 with no outstanding borrowings due.  We are currently in the process of renewing the facility.

[0001571996-18-000044:mdna:199]
Even with the significant decline in cash and cash equivalents that will result from the Class V transaction, we believe that our current cash and cash equivalents, together with cash that will be provided by future operations and expected borrowings under our revolving credit facilities, will be sufficient over at least the next twelve months to fund our operations, debt service requirements and maturities, capital expenditures, share repurchases, and other corporate needs.

[0001571996-18-000044:mdna:200]
[same as prior period, unchanged from 0001571996-18-000034:mdna:192]

[0001571996-18-000044:mdna:201]
The following table summarizes our outstanding debt as of November 2, 2018 and February 2, 2018:

[0001571996-18-000044:mdna:202]
|  | November 2, 2018 |  | February 2, 2018 |
|  | (in millions) |
| Restricted Subsidiary Debt |  |  |  |
| Core debt: |  |  |  |
| Senior Secured Credit Facilities and First Lien Notes | $ | 29,178 |  |  | $ | 30,595 |  |
| Unsecured Notes and Debentures | 1,952 |  |  | 2,452 |  |
| Senior Notes | 3,250 |  |  | 3,250 |  |
| EMC Notes | 3,000 |  |  | 5,500 |  |
| DFS allocated debt | (1,133 | ) |  | (1,892 | ) |
| Total core debt | 36,247 |  |  | 39,905 |  |
| DFS related debt: |  |  |  |
| DFS debt | 5,937 |  |  | 4,796 |  |
| DFS allocated debt | 1,133 |  |  | 1,892 |  |
| Total DFS related debt | 7,070 |  |  | 6,688 |  |
| Other | 2,047 |  |  | 2,054 |  |
| Unrestricted Subsidiary Debt |  |  |  |
| VMware Notes | 4,000 |  |  | 4,000 |  |
| Other | — |  |  | 47 |  |
| Total unrestricted subsidiary debt | 4,000 |  |  | 4,047 |  |
| Total debt, principal amount | 49,364 |  |  | 52,694 |  |
| Carrying value adjustments | (707 | ) |  | (823 | ) |
| Total debt, carrying value | $ | 48,657 |  |  | $ | 51,871 |  |

[0001571996-18-000044:mdna:203]
The outstanding principal amount of our debt was $49.4 billion as of November 2, 2018, which included core debt of $36.2 billion.  We define core debt as the total principal amount of our debt, less DFS related debt, other debt, and unrestricted subsidiary debt.

[0001571996-18-000044:mdna:204]
[same as prior period, unchanged from 0001571996-18-000034:mdna:196]

[0001571996-18-000044:mdna:205]
As of November 2, 2018 and February 2, 2018, other debt primarily consisted of the $2.0 billion Margin Loan Facility.

[0001571996-18-000044:mdna:206]
[same as prior period, unchanged from 0001571996-18-000034:mdna:198]

[0001571996-18-000044:mdna:207]
Our requirements for cash to pay principal and interest on our debt increased significantly due to the borrowings we incurred to finance the EMC merger transaction.  We have made good progress in paying down core debt since the EMC merger transaction.  We believe we will continue to be able to make our debt principal and interest payments, including the short-term maturities, from existing and expected sources of cash.  Cash used for debt principal and interest payments may include short-term borrowings under revolving credit facilities.  We will continue to focus on paying down core debt.  Despite the debt repayments, interest expense was $1.8 billion during both the nine months ended November 2, 2018 and November 3, 2017 due to an increase in LIBOR, and also due to an increase in the debt used to fund the DFS business, as we see continued demand for customer financing.  We expect that continued demand for customer financing as well as an increase in LIBOR will impact future interest expense on our variable-rate debt.  We or our affiliates, at our or their sole discretion, may purchase, redeem, prepay, refinance, or otherwise retire any amount of our outstanding indebtedness under the terms of such indebtedness at any time and from time to time, in open market or negotiated transactions with the holders of such indebtedness, as appropriate market conditions exist.

[0001571996-18-000044:mdna:208]
During the third quarter of Fiscal 2019, we repaid approximately $1.2 billion principal amount of our 1.875% Term Loan A-3 Facility due December 2018 and $68 million principal amount of our other term loan facilities.  Further, we issued an additional $375 million, net, in DFS debt to support the expansion of our financing receivables portfolio.

[0001571996-18-000044:mdna:209]
[same as prior period, unchanged from 0001571996-18-000034:mdna:202]

[0001571996-18-000044:mdna:210]
As discussed above, we are expecting to incur additional debt for up to $5 billion in bridge financing related to the consummation of the Class V transaction.  In replacing this debt with permanent financing, we will seek to minimize our cost of capital while maintaining a manageable maturity profile.  See Note 20 of the Notes to the Condensed Consolidated Financial Statements included in this report for additional information about the bridge financing.

[0001571996-18-000044:mdna:211]
[same as prior period, unchanged from 0001571996-18-000034:mdna:203]

[0001571996-18-000044:mdna:212]
The following table contains a summary of our Condensed Consolidated Statements of Cash Flows for the respective periods:

[0001571996-18-000044:mdna:213]
|  | Nine Months Ended |
|  | November 2, 2018 |  | November 3, 2017 |
|  | (in millions) |
| Net change in cash from: |  |  |  |
| Operating activities | $ | 4,625 |  |  | $ | 3,744 |  |
| Investing activities | (221 | ) |  | (1,990 | ) |
| Financing activities | (2,844 | ) |  | 525 |  |
| Effect of exchange rate changes on cash and cash equivalents | (262 | ) |  | 47 |  |
| Change in cash and cash equivalents | $ | 1,298 |  |  | $ | 2,326 |  |

[0001571996-18-000044:mdna:214]
Operating Activities — Cash provided by operating activities was $4.6 billion for the first nine months of Fiscal 2019 compared to $3.7 billion for the first nine months of Fiscal 2018.  The increase in operating cash flows during the first nine months of Fiscal 2019 was driven by business momentum, improved profitability, and management of working capital.  During the third quarter of Fiscal 2019, we experienced supply chain dynamics that increased inventory and negatively impacted working capital.  It is possible that these supply chain dynamics could persist over the coming quarters and continue to pressure working capital.

[0001571996-18-000044:mdna:215]
DFS offerings are initially funded through cash on hand at the time of origination, most of which is subsequently replaced with third-party financing.  As a result, while the initial funding is reflected as an impact to cash flows from operations, it is largely subsequently offset by cash flows from financing.  DFS new financing originations were $5.2 billion and $4.3 billion for the first nine months of Fiscal 2019 and the first nine months of Fiscal 2018, respectively.  As of November 2, 2018, DFS had $8.1 billion of total net financing receivables.

[0001571996-18-000044:mdna:216]
Investing Activities — Investing activities primarily consist of cash used to fund strategic investments, the maturities, sales, and purchases of investments, capital expenditures for property, plant, and equipment, and capitalized software development costs.

[0001571996-18-000044:mdna:217]
During the first nine months of Fiscal 2019, cash used by investing activities was $0.2 billion and was primarily driven by capital expenditures and strategic investments, partially offset by the net sales of investments.  In comparison, cash used by investing activities was $2.0 billion during the first nine months of Fiscal 2018 and was primarily driven by capital expenditures, capitalized software development costs, and net purchases of investments.

[0001571996-18-000044:mdna:218]
Financing Activities — Financing activities primarily consist of the proceeds and repayments of debt, cash used to repurchase common stock, and proceeds from the issuance of common stock of subsidiaries.  Cash used by financing activities of $2.8 billion during the first nine months of Fiscal 2019 was primarily driven by repayments of debt, including the EMC Note in the amount of $2.5 billion we repaid during the second quarter of Fiscal 2019 and the Term Loan A-3 Facility in the amount of $1.2 billion we repaid during the third quarter of Fiscal 2019.  In comparison, cash provided by financing activities of $0.5 billion during the first nine months of Fiscal 2018 was primarily driven by net proceeds from debt, primarily due to the issuance of the VMware Notes, partially offset by cash used for share repurchases.

[0001571996-18-000044:mdna:219]
[same as prior period, unchanged from 0001571996-18-000034:mdna:209]

[0001571996-18-000044:mdna:220]
Capital Expenditures — During both the first nine months of Fiscal 2019 and Fiscal 2018, we spent $0.9 billion on property, plant, and equipment.  These expenditures were primarily incurred in connection with our global expansion efforts and infrastructure investments made to support future growth.  Product demand, product mix, and the use of contract manufacturers, as well as ongoing investments in operating and information technology infrastructure, influence the level and prioritization of our capital expenditures.  Aggregate capital expenditures for Fiscal 2019, which will be primarily related to infrastructure investments and strategic initiatives, are currently expected to total between $1.1 billion and $1.3 billion.

[0001571996-18-000044:mdna:221]
Purchase Obligations — Purchase obligations are defined as contractual obligations to purchase goods or services that are enforceable and legally binding on us.  These obligations specify all significant terms, including fixed or minimum quantities to be purchased; fixed, minimum, or variable price provisions; and the approximate timing of the transaction.  Purchase obligations do not include contracts that may be canceled without penalty.

[0001571996-18-000044:mdna:222]
[same as prior period, unchanged from 0001571996-18-000034:mdna:213]

[0001571996-18-000044:mdna:223]
[same as prior period, unchanged from 0001571996-18-000034:mdna:214]

[0001571996-18-000044:mdna:224]
[same as prior period, unchanged from 0001571996-18-000034:mdna:215]

[0001571996-18-000044:mdna:225]
Since the date of the EMC merger transaction, our board of directors has authorized several programs to repurchase shares of our Class V Common Stock.  Of the $2.1 billion total authorized, $676 million remained as of November 2, 2018, all of which is attributable to the DHI Group Repurchase Program, which the board of directors suspended on December 13, 2016 until such time as it authorizes the reinstatement of that program.

[0001571996-18-000044:mdna:226]
During the first nine months of Fiscal 2019, we did not repurchase any shares of Class V Common Stock.  During the first nine months of Fiscal 2018, we repurchased 9.7 million shares of Class V Common Stock for an aggregate purchase price of $682 million.  The repurchase of these shares was funded by proceeds received by the Class V Group from the sale by our subsidiary of shares of Class A common stock of VMware, Inc. owned by such subsidiary, as discussed below.

[0001571996-18-000044:mdna:227]
[same as prior period, unchanged from 0001571996-18-000034:mdna:218]

[0001571996-18-000044:mdna:228]
During the first nine months of Fiscal 2019, we repurchased an immaterial number of shares of DHI Group Common Stock for $48 million.  No shares were repurchased during the third quarter of Fiscal 2019.  During the third quarter and first nine months of Fiscal 2018, we repurchased an immaterial number of shares of DHI Group Common Stock for approximately $4 million and $6 million, respectively.

[0001571996-18-000044:mdna:229]
91

[0001571996-18-000044:mdna:230]
[same as prior period, unchanged from 0001571996-18-000034:mdna:220]

[0001571996-18-000044:mdna:231]
Since the date of the EMC merger transaction, VMware Inc.’s board of directors has authorized the repurchase of a total of $2.2 billion of VMware Inc.’s Class A common stock, of which $876 million remained available as of November 2, 2018.

[0001571996-18-000044:mdna:232]
During the first nine months of Fiscal 2019, VMware, Inc. did not repurchase any shares of its Class A common stock.  During the first nine months of Fiscal 2018, pursuant to stock repurchase agreements between Dell Technologies Inc. and VMware, Inc., VMware, Inc. repurchased 7.5 million shares of its Class A common stock from us for an aggregate purchase price of $725 million.  VMware, Inc. received 4.1 million shares of its Class A common stock during the first quarter of Fiscal 2018, 0.7 million shares during the second quarter of Fiscal 2018 and the remaining 2.7 million shares of its Class A common stock during the third quarter of Fiscal 2018.  The proceeds from the sales were used by us to repurchase shares of our Class V Common Stock, as described above.

[0001571996-18-000044:mdna:233]
92
