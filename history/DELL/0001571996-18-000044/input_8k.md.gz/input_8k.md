# DELL 8-K — 0001571996-18-000041 filed 2018-11-29

## item codes, every 8-K on or before 2018-12-10

- 2018-11-29 0001571996-18-000041 — 2.02, 9.01
- 2018-11-28 0001571996-18-000037 — 7.01, 8.01, 9.01
- 2018-11-26 0001193125-18-333967 — 8.01, 9.01
- 2018-11-15 0001193125-18-328110 — 1.01, 9.01 — amendment of 0001193125-18-327222
- 2018-11-15 0001193125-18-327222 — 1.01, 7.01, 9.01
- 2018-10-03 0001193125-18-291390 — 8.01
- 2018-09-06 0001571996-18-000029 — 2.02, 9.01
- 2018-08-06 0001571996-18-000027 — 8.01, 9.01
- 2018-07-02 0001193125-18-210339 — 1.01, 7.01, 9.01
- 2018-06-28 0001571996-18-000024 — 5.07
- 2018-06-04 0001571996-18-000019 — 2.02, 9.01
- 2018-05-17 0001571996-18-000016 — 7.01
- 2018-04-26 0001571996-18-000009 — 7.01, 9.01
- 2018-03-08 0001193125-18-074168 — 2.02, 9.01
- 2018-02-02 0001193125-18-029947 — 7.01, 9.01
- 2017-12-07 0001571996-17-000042 — 2.02, 9.01
- 2017-10-24 0001571996-17-000037 — 1.01, 2.03, 9.01
- 2017-09-15 0001571996-17-000027 — 5.02
- 2017-09-07 0001571996-17-000017 — 2.02, 9.01
- 2017-08-24 0001571996-17-000014 — 8.01
- 2017-06-29 0001571996-17-000011 — 3.03, 5.07, 8.01, 9.01
- 2017-06-08 0001193125-17-197638 — 2.02, 9.01
- 2017-03-30 0001193125-17-102794 — 8.01
- 2017-03-30 0001193125-17-102777 — 2.02, 9.01
- 2017-03-09 0001193125-17-076981 — 1.01, 2.03, 9.01
- 2017-01-17 0001193125-17-011125 — 8.01
- 2016-12-15 0001193125-16-793722 — 8.01
- 2016-12-08 0001193125-16-787976 — 2.02, 9.01
- 2016-11-10 0001193125-16-765964 — 1.02, 8.01
- 2016-11-04 0001193125-16-760249 — 8.01
- 2016-09-13 0001193125-16-708600 — 3.02
- 2016-09-09 0001193125-16-706567 — 1.01, 1.02, 2.01, 2.03, 3.02, 3.03, 5.02, 9.01
- 2016-09-07 0001193125-16-703370 — 3.03, 5.07, 7.01, 8.01, 9.01
- 2016-09-06 0001193125-16-702057 — 2.02, 9.01
- 2016-08-31 0001193125-16-697268 — 8.01, 9.01
- 2016-08-26 0001193125-16-692921 — 8.01, 9.01
- 2016-07-11 0001193125-16-645610 — 8.01
- 2016-07-05 0001193125-16-641679 — 8.01
- 2016-06-22 0001193125-16-629055 — 1.01, 2.03, 8.01, 9.01
- 2016-06-21 0001193125-16-627071 — 8.01, 9.01
- 2016-06-10 0001193125-16-618483 — 2.02, 9.01
- 2016-06-09 0001193125-16-617893 — 8.01, 9.01

## late-filing notifications on or before 2018-12-10

- none on or before 2018-12-10

## item 2.02 — earnings release, exhibit 99.1

[0001571996-18-000041:8k_2_02:1]
EX-99.1
2
exhibit991earnings8k.htm
EXHIBIT 99.1

[0001571996-18-000041:8k_2_02:2]
Exhibit

[0001571996-18-000041:8k_2_02:3]
Exhibit 99.1

[0001571996-18-000041:8k_2_02:4]
News Release

[0001571996-18-000041:8k_2_02:5]
Dell Technologies Reports Fiscal Year 2019 Third Quarter

[0001571996-18-000041:8k_2_02:6]
Financial Results

[0001571996-18-000041:8k_2_02:7]
ROUND ROCK, Texas - Nov. 29, 2018

[0001571996-18-000041:8k_2_02:8]
News summary

[0001571996-18-000041:8k_2_02:9]
| • | GAAP revenue up 15 percent to $22.5 billion |

[0001571996-18-000041:8k_2_02:10]
| • | Third consecutive quarter of double-digit growth across all reportable segments |

[0001571996-18-000041:8k_2_02:11]
| • | Continued cross-sell synergies across the family of businesses |

[0001571996-18-000041:8k_2_02:12]
Full story

[0001571996-18-000041:8k_2_02:13]
Dell Technologies (NYSE: DVMT) announces its fiscal 2019 third quarter results. For the third quarter, revenue was $22.5 billion, up 15 percent, and non-GAAP revenue was $22.7 billion, up 14 percent from the prior period. During the quarter, the company generated a GAAP operating loss of $356 million1, with a non-GAAP operating income of $2.1 billion, down 2 percent. Cash flow from operations was approximately $833 million.

[0001571996-18-000041:8k_2_02:14]
“The digital transformation of our world is underway, and we are in the early stages of a massive, technology-led investment cycle," said Michael Dell, chairman and CEO, Dell Technologies. "Dell Technologies was created to meet this opportunity head on for our customers and our investors. You can see the proof in our strong growth, in our powerful innovation and in the depth of our customer relationships.”

[0001571996-18-000041:8k_2_02:15]
The company ended the third quarter with a cash and investments balance of $20.4 billion. During the quarter, Dell Technologies paid down approximately $1.3 billion of core debt2. Within the past two years, the company has paid down approximately $14.4 billion in gross debt, excluding Dell Financial Services related and subsidiary debt.

[0001571996-18-000041:8k_2_02:16]
“Dell Technologies has assembled a broad set of capabilities and unique position that drive an attractive financial model,” said Tom Sweet, chief financial officer, Dell Technologies. “Our third quarter of double-digit growth in all three of our reportable segments shows that our customers increasingly see us as a key partner with a deep portfolio to meet their needs, from the edge to the core to the cloud.”

[0001571996-18-000041:8k_2_02:17]
Fiscal year 2019 third quarter results

[0001571996-18-000041:8k_2_02:18]
|  | Three Months Ended |  |  |  | Nine Months Ended |  |  |
|  | November 2, 2018 |  | November 3, 2017 |  | Change |  | November 2, 2018 |  | November 3, 2017 |  | Change |
|  | (in millions, except percentages; unaudited) |
| Total net revenue | $ | 22,482 |  |  | $ | 19,556 |  |  | 15% |  | $ | 66,780 |  |  | $ | 57,077 |  |  | 17% |
| Operating loss | $ | (356 | ) |  | $ | (410 | ) |  | 13% |  | $ | (522 | ) |  | $ | (2,347 | ) |  | 78% |
| Net loss | $ | (895 | ) |  | $ | (851 | ) |  | (5)% |  | $ | (1,894 | ) |  | $ | (2,793 | ) |  | 32% |
| Non-GAAP net revenue | $ | 22,651 |  |  | $ | 19,851 |  |  | 14% |  | $ | 67,316 |  |  | $ | 58,062 |  |  | 16% |
| Non-GAAP operating income | $ | 2,064 |  |  | $ | 2,109 |  |  | (2)% |  | $ | 6,198 |  |  | $ | 5,400 |  |  | 15% |
| Non-GAAP net income | $ | 1,200 |  |  | $ | 1,199 |  |  | —% |  | $ | 3,723 |  |  | $ | 3,072 |  |  | 21% |
| Adjusted EBITDA | $ | 2,426 |  |  | $ | 2,441 |  |  | (1)% |  | $ | 7,268 |  |  | $ | 6,416 |  |  | 13% |

[0001571996-18-000041:8k_2_02:19]
Information about Dell Technologies’ use of non-GAAP financial information is provided under “Non-GAAP Financial Measures” below. All comparisons in this press release are year over year unless otherwise noted.

[0001571996-18-000041:8k_2_02:20]
“Data is becoming the most valuable and differentiating asset for many organizations as it opens up new revenue streams and unearths opportunities for improvement in almost every part of an organization,” said Jeff Clarke, vice chairman, Products & Operations, Dell Technologies. “This presents a tremendous opportunity for Dell Technologies given all of this data needs to be stored, protected, managed and analyzed, and we believe this is evidenced through the strong momentum we’ve seen in our business.”

[0001571996-18-000041:8k_2_02:21]
Operating segments summary

[0001571996-18-000041:8k_2_02:22]
Infrastructure Solutions Group revenue for the third quarter was $8.9 billion, a 19 percent increase. This was driven by revenue of $3.9 billion in storage, a 6 percent increase, and $5.1 billion in servers and networking, a 30 percent increase. Operating income for the third quarter was $935 million, a 7 percent increase driven primarily by server and storage mix dynamics.

[0001571996-18-000041:8k_2_02:23]
Key third quarter highlights:

[0001571996-18-000041:8k_2_02:24]
| • | Servers and Networking delivered its sixth consecutive quarter of double-digit revenue growth |

[0001571996-18-000041:8k_2_02:25]
| • | Triple-digit growth for VxRail on a demand basis, and now well above a $1 billion run rate |

[0001571996-18-000041:8k_2_02:26]
| • | Demand was strong for file-based arrays where Dell Technologies is highly differentiated with unmatched scalability, performance and flexibility |

[0001571996-18-000041:8k_2_02:27]
Client Solutions Group revenue for the third quarter was $10.9 billion, up 11 percent, with growth across both Commercial and Consumer. Commercial revenue grew 12 percent to $7.6 billion, and Consumer revenue was up 8 percent to $3.3 billion. Operating income for the third quarter was $447 million, or 4.1 percent of revenue. CSG operating income was down 29 percent against a strong prior period, and foreign exchange and supply chain headwinds.

[0001571996-18-000041:8k_2_02:28]
Key third quarter highlights:

[0001571996-18-000041:8k_2_02:29]
| • | Outperformed the PC industry for total worldwide units, delivering above-market growth in desktops and notebooks and in total commercial units3 |

[0001571996-18-000041:8k_2_02:30]
| • | No. 1 share position worldwide for displays, gaining unit share year-over-year for the 22nd consecutive quarter4 |

[0001571996-18-000041:8k_2_02:31]
| • | Maintained position as No. 1 provider of workstations worldwide5, with growth in every region and double-digit growth in both fixed and mobile form factors |

[0001571996-18-000041:8k_2_02:32]
VMware revenue for the third quarter was $2.2 billion, up 15 percent, with operating income of $768 million and 34.5 percent of revenue. The company continues to see revenue synergies through the collaboration across the Dell Technologies family of businesses. Earlier this month at VMworld Europe, Dell Technologies announced the VxBlock System 1000 as part of the Dell EMC Cloud Marketplace with new automation software and integration with VMware vRealize Suite, revolutionizing Converged Infrastructure operations by enabling administrators to expand resources in minutes versus hours. For the industry-leading hyper-converged infrastructure solution VxRail, the company announced an integrated cloud platform with support for VMware Cloud Foundation and fully automated network configuration with Dell EMC Networking SmartFabric Services.

[0001571996-18-000041:8k_2_02:33]
Third quarter revenue from other businesses, including Pivotal, Secureworks, RSA Security, Virtustream and Boomi, was $583 million, up 5 percent.

[0001571996-18-000041:8k_2_02:34]
Conference call information

[0001571996-18-000041:8k_2_02:35]
As previously announced, the company will hold a conference call to discuss its third quarter results today at 5:00 p.m. CST. The conference call will be broadcast live over the internet and can be accessed at investors.delltechnologies.com. For those unable to listen to the live broadcast, an archived version will be available at the same location for one year.

[0001571996-18-000041:8k_2_02:36]
A slide presentation containing additional financial and operating information may be downloaded from Dell Technologies’ website at investors.delltechnologies.com.

[0001571996-18-000041:8k_2_02:37]
About Dell Technologies

[0001571996-18-000041:8k_2_02:38]
Dell Technologies is a unique family of businesses that provides the essential infrastructure for organizations to build their digital future, transform IT and protect their most important asset, information. The company services customers of all sizes across 180 countries - ranging from 99 percent of the Fortune 500 to individual consumers - with the industry’s most comprehensive and innovative portfolio from the edge to the core to the cloud.

[0001571996-18-000041:8k_2_02:39]
CONTACTS:

[0001571996-18-000041:8k_2_02:40]
Investor Relations: Investor_Relations@Dell.com

[0001571996-18-000041:8k_2_02:41]
Media Relations: Media.Relations@Dell.com

[0001571996-18-000041:8k_2_02:42]
# # #

[0001571996-18-000041:8k_2_02:43]
Copyright © 2018 Dell Inc. or its subsidiaries. All Rights Reserved. Dell Technologies, Dell, EMC and Dell EMC are trademarks of Dell Inc. or its subsidiaries. Other trademarks may be trademarks of their respective owners.

[0001571996-18-000041:8k_2_02:44]
| 1 | Due to the EMC transaction, significant non-cash bridging items will remain between GAAP and non-GAAP results for the next few years. |

[0001571996-18-000041:8k_2_02:45]
| 2 | Core debt represents the total principal amount of the company’s debt, less unrestricted subsidiary debt, DFS related debt, and other debt. See slide presentation on the FY19Q3 Earnings Event page for full reconciliation of the core debt amount. |

[0001571996-18-000041:8k_2_02:46]
| 3 | IDC WW Quarterly Personal Computing Device (PCD) Tracker CY18Q3 |

[0001571996-18-000041:8k_2_02:47]
| 4 | DisplaySearch Desktop Monitor Market Tracker CY18Q3 |

[0001571996-18-000041:8k_2_02:48]
| 5 | IDC WW Workstation Tracker CY18Q3 |

[0001571996-18-000041:8k_2_02:49]
Non-GAAP Financial Measures:

[0001571996-18-000041:8k_2_02:50]
This press release presents information about Dell Technologies’ non-GAAP net revenue, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP operating income, non-GAAP net income, EBITDA and adjusted EBITDA, which are non-GAAP financial measures provided as a supplement to the results provided in accordance with generally accepted accounting principles in the United States of America ("GAAP"). A reconciliation of each historical non-GAAP financial measure to the most directly comparable historical GAAP financial measure is provided in the attached tables for each of the fiscal periods indicated.

[0001571996-18-000041:8k_2_02:51]
Special Note on Forward-Looking Statements:

[0001571996-18-000041:8k_2_02:52]
Dell Technologies’ results or events in future periods could differ materially from those expressed or implied by these forward-looking statements because of risks, uncertainties, and other factors that include risks relating to the proposed exchange of shares of Dell Technologies Class V common stock for shares of Class C common stock or, at the holder’s election, cash,  including but not limited to: (i) the failure to consummate or delay in consummating the proposed transaction, including the failure to obtain the requisite stockholder approvals or the failure of VMware, Inc. (“VMware”) to pay the special dividend or any inability of Dell Technologies to pay the cash consideration to Class V holders; (ii) the risk as to the trading price of Class C common stock to be issued by Dell Technologies in the proposed transaction relative to the trading price of shares of Class V common stock and VMware common stock; and (iii) the risks discussed in the “Risk Factors” section of the registration statement on Form S-4 (File No. 333-226618) that has been filed with the Securities and Exchange Commission (the “SEC”) and declared effective, and the risks discussed in the “Update to Risk Factors” section of the supplement to the definitive proxy statement/prospectus that has been filed with the SEC.  Other risks, uncertainties and factors include competitive pressures; Dell Technologies’ reliance on third-party suppliers for products and components including reliance on single-source or limited-source suppliers; Dell Technologies’ ability to achieve favorable pricing from its vendors; adverse global economic conditions and instability in financial markets; Dell Technologies’ execution of its growth, business and acquisition strategies; the success of Dell Technologies’ cost efficiency measures; Dell Technologies’ ability to manage solutions and products and services transitions in an effective manner; Dell Technologies’ ability to deliver high-quality products and services; Dell Technologies’ foreign operations and ability to generate substantial non-U.S. net revenue; Dell Technologies’ product, customer, and geographic sales mix, and seasonal sales trends; the performance of Dell Technologies’ sales channel partners; access to the capital markets by Dell Technologies or its customers; weak economic conditions and additional regulation; counterparty default risks; the loss by Dell Technologies of any services contracts with its customers, including government contracts, and its ability to perform such contracts at its estimated costs; Dell Technologies’ ability to develop and protect its proprietary intellectual property or obtain licenses to intellectual property developed by others on commercially reasonable and competitive terms; infrastructure disruptions, cyberattacks, or other data security breaches; Dell Technologies’ ability to hedge effectively its exposure to fluctuations in foreign currency exchange rates and interest rates; expiration of tax holidays or favorable tax rate structures, or unfavorable outcomes in tax audits and other tax compliance matters; impairment of portfolio investments; unfavorable results of legal proceedings; increased costs and additional regulations and requirements as a result of Dell Technologies operation as a public company; Dell Technologies’ ability to develop and maintain effective internal control over financial reporting; compliance requirements of changing environmental and safety laws; the effect of armed hostilities, terrorism, natural disasters, and public health issues; Dell Technologies’ substantial level of indebtedness; the impact of the financial performance of VMware; and the market volatility of Dell Technologies’ pension plan assets.

[0001571996-18-000041:8k_2_02:53]
This list of risks, uncertainties, and other factors is not complete. Dell Technologies discusses some of these matters more fully, as well as certain risk factors that could affect Dell Technologies’ business, financial condition, results of operations, and prospects, in its reports filed with the SEC, including Dell Technologies’ Annual Report on Form 10-K for the fiscal year ended February 2, 2018, quarterly reports on Form 10-Q, and current reports on Form 8-K. These filings are available for review through the SEC’s website at www.sec.gov. Any or all forward-looking statements Dell Technologies makes may turn out to be wrong and can be affected by inaccurate assumptions Dell Technologies might make or by known or unknown risks, uncertainties and other factors, including those identified in this press release. Accordingly, you should not place undue reliance on the forward-looking statements made in this press release, which speak only as of its date. Dell Technologies does not undertake to update, and expressly disclaims any duty to update, its forward-looking statements, whether as a result of circumstances or events that arise after the date they are made, new information, or otherwise.

[0001571996-18-000041:8k_2_02:54]
No Offer or Solicitation:

[0001571996-18-000041:8k_2_02:55]
This communication does not constitute an offer to sell or a solicitation of an offer to sell or a solicitation of an offer to buy any securities or a solicitation of any vote or approval, nor shall there be any sale of securities in any jurisdiction in which such offer, solicitation or sale would be unlawful prior to registration or qualification under the securities laws of any such jurisdiction. No offering of securities shall be made except by means of a prospectus meeting the requirements of Section 10 of the Securities Act of 1933 and otherwise in accordance with applicable law.

[0001571996-18-000041:8k_2_02:56]
Additional Information and Where to Find It:

[0001571996-18-000041:8k_2_02:57]
This communication is being made in respect of the proposed merger of a wholly-owned subsidiary of Dell Technologies Inc. (the “Company”) with and into the Company, with the Company as the surviving entity, pursuant to which each share of Class V common stock of the Company will, at the election of the holder, convert into the right to receive shares of Class C common stock of the Company or cash, without interest, and each existing share of Class A common stock, Class B common stock and Class C common stock of the Company will be unaffected by the merger and remain outstanding. The proposed transaction requires the approval of a majority of the aggregate voting power of the outstanding shares of Class A common stock, Class B common stock and Class V common stock other than those held by affiliates of the Company, in each case, voting as a separate class, and all outstanding shares of common stock of the Company, voting together as a single class, and will be submitted to stockholders for their consideration. The Company has filed a registration statement on Form S-4 (File No. 333-226618). The registration statement was declared effective by the SEC on October 19, 2018, and a definitive proxy statement/prospectus was mailed on or about October 23, 2018 to each holder of Class A common stock, Class B common stock, Class C common stock and Class V common stock entitled to vote at the special meeting in connection with the proposed transaction. The Company also filed a supplement to the definitive proxy statement/prospectus on November 26, 2018, which was mailed on or about November 26, 2018 to each holder of Class A common stock, Class B common stock, Class C common stock and Class V common stock entitled to vote at the special meeting in connection with the proposed transaction. INVESTORS ARE URGED TO READ THE PROXY STATEMENT/PROSPECTUS, THE SUPPLEMENT AND ANY OTHER DOCUMENTS RELATING TO THE TRANSACTION FILED WITH THE SEC CAREFULLY AND IN THEIR ENTIRETY IF AND WHEN THEY BECOME AVAILABLE BECAUSE THEY WILL CONTAIN IMPORTANT INFORMATION ABOUT THE PROPOSED TRANSACTION. You may get these documents, when available, for free by visiting EDGAR on the SEC website at www.sec.gov or by visiting the Company’s website at http://investors.delltechnologies.com.

[0001571996-18-000041:8k_2_02:58]
Participants in the Solicitation:

[0001571996-18-000041:8k_2_02:59]
The Company and its consolidated subsidiaries and their directors, executive officers and other members of their management and employees, and Silver Lake Technology Management, L.L.C. and its managing partners and employees, may be deemed to be participants in the solicitation of proxies from the stockholders of the Company in favor of the proposed merger and the other transactions contemplated by the amended merger agreement, including the exchange of shares of Class V common stock of the Company for shares of Class C common stock of the Company or cash. Information concerning persons who may be considered participants in such solicitation under the rules of the SEC, including a description of their direct or indirect interests, by security holdings or otherwise, is set forth in the aforementioned proxy statement/prospectus and the supplement that have been filed with the SEC.

[0001571996-18-000041:8k_2_02:60]
DELL TECHNOLOGIES INC.

[0001571996-18-000041:8k_2_02:61]
Condensed Consolidated Statements of Income (Loss) and Related Financial Highlights

[0001571996-18-000041:8k_2_02:62]
(in millions, except per share amounts and percentages; unaudited)

[0001571996-18-000041:8k_2_02:63]
|  | Three Months Ended |  |  |  | Nine Months Ended |  |  |
|  | November 2, 2018 |  | November 3, 2017 |  | Change |  | November 2, 2018 |  | November 3, 2017 |  | Change |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Products | $ | 17,625 |  |  | $ | 15,120 |  |  | 17% |  | $ | 52,445 |  |  | $ | 43,856 |  |  | 20% |
| Services | 4,857 |  |  | 4,436 |  |  | 9% |  | 14,335 |  |  | 13,221 |  |  | 8% |
| Total net revenue | 22,482 |  |  | 19,556 |  |  | 15% |  | 66,780 |  |  | 57,077 |  |  | 17% |
| Cost of net revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Products | 14,565 |  |  | 12,573 |  |  | 16% |  | 43,114 |  |  | 37,171 |  |  | 16% |
| Services | 1,974 |  |  | 1,763 |  |  | 12% |  | 5,722 |  |  | 5,261 |  |  | 9% |
| Total cost of net revenue | 16,539 |  |  | 14,336 |  |  | 15% |  | 48,836 |  |  | 42,432 |  |  | 15% |
| Gross margin | 5,943 |  |  | 5,220 |  |  | 14% |  | 17,944 |  |  | 14,645 |  |  | 23% |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |
| Selling, general, and administrative | 5,159 |  |  | 4,559 |  |  | 13% |  | 15,064 |  |  | 13,695 |  |  | 10% |
| Research and development | 1,140 |  |  | 1,071 |  |  | 6% |  | 3,402 |  |  | 3,297 |  |  | 3% |
| Total operating expenses | 6,299 |  |  | 5,630 |  |  | 12% |  | 18,466 |  |  | 16,992 |  |  | 9% |
| Operating loss | (356 | ) |  | (410 | ) |  | 13% |  | (522 | ) |  | (2,347 | ) |  | 78% |
| Interest and other, net | (639 | ) |  | (682 | ) |  | 6% |  | (1,564 | ) |  | (1,799 | ) |  | 13% |
| Loss before income taxes | (995 | ) |  | (1,092 | ) |  | 9% |  | (2,086 | ) |  | (4,146 | ) |  | 50% |
| Income tax benefit | (100 | ) |  | (241 | ) |  | 59% |  | (192 | ) |  | (1,353 | ) |  | 86% |
| Net loss | (895 | ) |  | (851 | ) |  | (5)% |  | (1,894 | ) |  | (2,793 | ) |  | 32% |
| Less: Net income (loss) attributable to non-controlling interests | (19 | ) |  | (5 | ) |  | 280% |  | 117 |  |  | (44 | ) |  | (366)% |
| Net loss attributable to Dell Technologies Inc. | $ | (876 | ) |  | $ | (846 | ) |  | (4)% |  | $ | (2,011 | ) |  | $ | (2,749 | ) |  | 27% |
| Earnings (loss) per share attributable to Dell Technologies Inc. - basic: |  |  |  |  |  |  |  |  |  |  |  |
| Class V Common Stock - basic | $ | 0.83 |  |  | $ | — |  |  |  |  | $ | 4.80 |  |  | $ | — |  |  |  |
| DHI Group - basic | $ | (1.84 | ) |  | $ | — |  |  |  |  | $ | (5.23 | ) |  | $ | — |  |  |  |
| Earnings (loss) per share attributable to Dell Technologies Inc. - diluted: |  |  |  |  |  |  |  |  |  |  |  |
| Class V Common Stock - diluted | $ | 0.81 |  |  | $ | — |  |  |  |  | $ | 4.72 |  |  | $ | — |  |  |  |
| DHI Group - diluted | $ | (1.84 | ) |  | $ | — |  |  |  |  | $ | (5.25 | ) |  | $ | — |  |  |  |
| Weighted-average shares outstanding: |  |  |  |  |  |  |  |  |  |  |  |
| Basic - Class V Common Stock | 199 |  |  | 202 |  |  |  |  | 199 |  |  | 204 |  |  |  |
| Diluted - Class V Common Stock | 199 |  |  | 202 |  |  |  |  | 199 |  |  | 204 |  |  |  |
| Basic - DHI Group | 567 |  |  | 567 |  |  |  |  | 567 |  |  | 567 |  |  |  |
| Diluted - DHI Group | 567 |  |  | 567 |  |  |  |  | 567 |  |  | 567 |  |  |  |
| Percentage of Total Net Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Gross margin | 26 | % |  | 27 | % |  |  |  | 27 | % |  | 26 | % |  |  |
| Selling, general, and administrative | 23 | % |  | 23 | % |  |  |  | 23 | % |  | 24 | % |  |  |
| Research and development | 5 | % |  | 5 | % |  |  |  | 5 | % |  | 6 | % |  |  |
| Operating expenses | 28 | % |  | 29 | % |  |  |  | 28 | % |  | 30 | % |  |  |
| Operating loss | (2 | )% |  | (2 | )% |  |  |  | (1 | )% |  | (4 | )% |  |  |
| Loss before income taxes | (4 | )% |  | (6 | )% |  |  |  | (3 | )% |  | (7 | )% |  |  |
| Net loss | (4 | )% |  | (4 | )% |  |  |  | (3 | )% |  | (5 | )% |  |  |
| Income tax rate | 10.1 | % |  | 22.1 | % |  |  |  | 9.2 | % |  | 32.6 | % |  |  |

[0001571996-18-000041:8k_2_02:64]
DELL TECHNOLOGIES INC.

[0001571996-18-000041:8k_2_02:65]
Condensed Consolidated Statements of Financial Position

[0001571996-18-000041:8k_2_02:66]
(in millions; unaudited)

[0001571996-18-000041:8k_2_02:67]
|  | November 2, 2018 |  | February 2, 2018 |
| ASSETS |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 15,152 |  |  | $ | 13,942 |  |
| Short-term investments | 2,322 |  |  | 2,187 |  |
| Accounts receivable, net | 11,113 |  |  | 11,721 |  |
| Short-term financing receivables, net | 4,134 |  |  | 3,919 |  |
| Inventories, net | 3,793 |  |  | 2,678 |  |
| Other current assets | 6,445 |  |  | 5,881 |  |
| Total current assets | 42,959 |  |  | 40,328 |  |
| Property, plant, and equipment, net | 5,228 |  |  | 5,390 |  |
| Long-term investments | 2,972 |  |  | 4,163 |  |
| Long-term financing receivables, net | 3,946 |  |  | 3,724 |  |
| Goodwill | 39,651 |  |  | 39,920 |  |
| Intangible assets, net | 23,787 |  |  | 28,265 |  |
| Other non-current assets | 2,698 |  |  | 2,403 |  |
| Total assets | $ | 121,241 |  |  | $ | 124,193 |  |
| LIABILITIES, REDEEMABLE SHARES, AND STOCKHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |
| Short-term debt | $ | 8,150 |  |  | $ | 7,873 |  |
| Accounts payable | 19,748 |  |  | 18,334 |  |
| Accrued and other | 7,606 |  |  | 8,026 |  |
| Short-term deferred revenue | 12,079 |  |  | 11,606 |  |
| Total current liabilities | 47,583 |  |  | 45,839 |  |
| Long-term debt | 40,507 |  |  | 43,998 |  |
| Long-term deferred revenue | 10,064 |  |  | 9,210 |  |
| Other non-current liabilities | 6,567 |  |  | 7,277 |  |
| Total liabilities | 104,721 |  |  | 106,324 |  |
| Redeemable shares | 2,095 |  |  | 384 |  |
| Stockholders' equity: |  |  |  |
| Total Dell Technologies Inc. stockholders’ equity | 7,592 |  |  | 11,719 |  |
| Non-controlling interests | 6,833 |  |  | 5,766 |  |
| Total stockholders' equity | 14,425 |  |  | 17,485 |  |
| Total liabilities, redeemable shares, and stockholders' equity | $ | 121,241 |  |  | $ | 124,193 |  |

[0001571996-18-000041:8k_2_02:68]
DELL TECHNOLOGIES INC.

[0001571996-18-000041:8k_2_02:69]
Condensed Consolidated Statements of Cash Flows

[0001571996-18-000041:8k_2_02:70]
(in millions; unaudited)

[0001571996-18-000041:8k_2_02:71]
|  | Three Months Ended |  | Nine Months Ended |
|  | November 2, 2018 |  | November 3, 2017 |  | November 2, 2018 |  | November 3, 2017 |
| Cash flows from operating activities: |  |  |  |  |  |  |  |
| Net loss | $ | (895 | ) |  | $ | (851 | ) |  | $ | (1,894 | ) |  | $ | (2,793 | ) |
| Adjustments to reconcile net loss to net cash provided by operating activities | 1,728 |  |  | 2,490 |  |  | 6,519 |  |  | 6,537 |  |
| Change in cash from operating activities | 833 |  |  | 1,639 |  |  | 4,625 |  |  | 3,744 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |
| Investments: |  |  |  |  |  |  |  |
| Purchases | (24 | ) |  | (1,194 | ) |  | (912 | ) |  | (3,454 | ) |
| Maturities and sales | 863 |  |  | 935 |  |  | 2,185 |  |  | 2,993 |  |
| Capital expenditures | (300 | ) |  | (341 | ) |  | (861 | ) |  | (902 | ) |
| Proceeds from sale of facilities, land, and other assets | — |  |  | — |  |  | 10 |  |  | — |  |
| Capitalized software development costs | (86 | ) |  | (94 | ) |  | (246 | ) |  | (281 | ) |
| Collections on purchased financing receivables | 8 |  |  | 15 |  |  | 25 |  |  | 25 |  |
| Acquisition of businesses, net | (493 | ) |  | — |  |  | (493 | ) |  | (223 | ) |
| Divestitures of businesses, net | — |  |  | — |  |  | 142 |  |  | — |  |
| Asset acquisitions, net | (21 | ) |  | (9 | ) |  | (59 | ) |  | (95 | ) |
| Asset dispositions, net | (6 | ) |  | (12 | ) |  | (12 | ) |  | (53 | ) |
| Change in cash from investing activities | (59 | ) |  | (700 | ) |  | (221 | ) |  | (1,990 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |
| Payment of dissenting shares obligation | — |  |  | — |  |  | (76 | ) |  | — |  |
| Share repurchases for tax withholdings of equity awards | (52 | ) |  | (105 | ) |  | (251 | ) |  | (299 | ) |
| Proceeds from the issuance of common stock of subsidiaries | 114 |  |  | 30 |  |  | 767 |  |  | 110 |  |
| Repurchases of DHI Group Common Stock | — |  |  | (4 | ) |  | (47 | ) |  | (6 | ) |
| Repurchases of Class V Common Stock | — |  |  | (300 | ) |  | — |  |  | (722 | ) |
| Repurchases of common stock of subsidiaries | (1 | ) |  | (555 | ) |  | (1 | ) |  | (555 | ) |
| Payments for debt issuance costs | (3 | ) |  | (39 | ) |  | (11 | ) |  | (44 | ) |
| Proceeds from debt | 1,806 |  |  | 8,412 |  |  | 6,443 |  |  | 13,168 |  |
| Repayments of debt | (2,721 | ) |  | (5,837 | ) |  | (9,669 | ) |  | (11,128 | ) |
| Other | — |  |  | — |  |  | 1 |  |  | 1 |  |
| Change in cash from financing activities | (857 | ) |  | 1,602 |  |  | (2,844 | ) |  | 525 |  |
| Effect of exchange rate changes on cash, cash equivalents, and restricted cash | (46 | ) |  | (1 | ) |  | (262 | ) |  | 47 |  |
| Change in cash, cash equivalents, and restricted cash | (129 | ) |  | 2,540 |  |  | 1,298 |  |  | 2,326 |  |
| Cash, cash equivalents, and restricted cash at beginning of the period | 15,805 |  |  | 9,618 |  |  | 14,378 |  |  | 9,832 |  |
| Cash, cash equivalents, and restricted cash at end of the period | $ | 15,676 |  |  | $ | 12,158 |  |  | $ | 15,676 |  |  | $ | 12,158 |  |

[0001571996-18-000041:8k_2_02:72]
DELL TECHNOLOGIES INC.

[0001571996-18-000041:8k_2_02:73]
Segment Information

[0001571996-18-000041:8k_2_02:74]
(in millions, except percentages; unaudited; continued on next page)

[0001571996-18-000041:8k_2_02:75]
|  | Three Months Ended |  |  |  | Nine Months Ended |  |  |
|  | November 2, 2018 |  | November 3, 2017 |  | Change |  | November 2, 2018 |  | November 3, 2017 |  | Change |
| Infrastructure Solutions Group (ISG): |  |  |  |  |  |  |  |  |  |  |  |
| Net Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Servers and networking | $ | 5,054 |  |  | $ | 3,875 |  |  | 30% |  | $ | 14,700 |  |  | $ | 10,908 |  |  | 35% |
| Storage | 3,883 |  |  | 3,660 |  |  | 6% |  | 12,131 |  |  | 11,055 |  |  | 10% |
| Total ISG net revenue | $ | 8,937 |  |  | $ | 7,535 |  |  | 19% |  | $ | 26,831 |  |  | $ | 21,963 |  |  | 22% |
| Operating Income: |  |  |  |  |  |  |  |  |  |  |  |
| ISG operating income | $ | 935 |  |  | $ | 870 |  |  | 7% |  | $ | 2,886 |  |  | $ | 2,023 |  |  | 43% |
| % of ISG net revenue | 10 | % |  | 12 | % |  |  |  | 11 | % |  | 9 | % |  |  |
| % of total segment operating income | 43 | % |  | 41 | % |  |  |  | 45 | % |  | 37 | % |  |  |
| Client Solutions Group (CSG): |  |  |  |  |  |  |  |  |  |  |  |
| Net Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Commercial | $ | 7,613 |  |  | $ | 6,778 |  |  | 12% |  | $ | 23,085 |  |  | $ | 20,327 |  |  | 14% |
| Consumer | 3,292 |  |  | 3,051 |  |  | 8% |  | 9,219 |  |  | 8,416 |  |  | 10% |
| Total CSG net revenue | $ | 10,905 |  |  | $ | 9,829 |  |  | 11% |  | $ | 32,304 |  |  | $ | 28,743 |  |  | 12% |
| Operating Income: |  |  |  |  |  |  |  |  |  |  |  |
| CSG operating income | $ | 447 |  |  | $ | 630 |  |  | (29)% |  | $ | 1,405 |  |  | $ | 1,483 |  |  | (5)% |
| % of CSG net revenue | 4 | % |  | 6 | % |  |  |  | 4 | % |  | 5 | % |  |  |
| % of total segment operating income | 21 | % |  | 29 | % |  |  |  | 22 | % |  | 27 | % |  |  |
| VMware: |  |  |  |  |  |  |  |  |  |  |  |
| Net Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Total VMware net revenue | $ | 2,229 |  |  | $ | 1,933 |  |  | 15% |  | $ | 4,222 |  |  | $ | 3,802 |  |  | 11% |
| Operating Income: |  |  |  |  |  |  |  |  |  |  |  |
| VMware operating income | $ | 768 |  |  | $ | 634 |  |  | 21% |  | $ | 2,117 |  |  | $ | 1,973 |  |  | 7% |
| % of VMware net revenue | 34 | % |  | 33 | % |  |  |  | 33 | % |  | 34 | % |  |  |
| % of total segment operating income | 36 | % |  | 30 | % |  |  |  | 33 | % |  | 36 | % |  |  |

[0001571996-18-000041:8k_2_02:76]
DELL TECHNOLOGIES INC.

[0001571996-18-000041:8k_2_02:77]
Segment Information

[0001571996-18-000041:8k_2_02:78]
(in millions, except percentages; unaudited; continued)

[0001571996-18-000041:8k_2_02:79]
|  | Three Months Ended |  | Nine Months Ended |
|  | November 2, 2018 |  | November 3, 2017 |  | November 2, 2018 |  | November 3, 2017 |
| Reconciliation to consolidated net revenue: |  |  |  |  |  |  |
| Reportable segment net revenue | $ | 22,071 |  |  | $ | 19,297 |  |  | $ | 65,586 |  |  | $ | 56,441 |  |
| Other businesses (a) | 583 |  |  | 557 |  |  | 1,736 |  |  | 1,629 |  |
| Unallocated transactions (b) | (3 | ) |  | (3 | ) |  | (6 | ) |  | (8 | ) |
| Impact of purchase accounting (c) | (169 | ) |  | (295 | ) |  | (536 | ) |  | (985 | ) |
| Total net revenue | $ | 22,482 |  |  | $ | 19,556 |  |  | $ | 66,780 |  |  | $ | 57,077 |  |
| Reconciliation to consolidated operating income (loss): |  |  |  |  |
| Reportable segment operating income | $ | 2,150 |  |  | $ | 2,134 |  |  | $ | 6,408 |  |  | $ | 5,479 |  |
| Other businesses (a) | (40 | ) |  | (19 | ) |  | (139 | ) |  | (71 | ) |
| Unallocated transactions (b) | (46 | ) |  | (6 | ) |  | (71 | ) |  | (8 | ) |
| Impact of purchase accounting (c) | (193 | ) |  | (366 | ) |  | (630 | ) |  | (1,195 | ) |
| Amortization of intangibles | (1,546 | ) |  | (1,734 | ) |  | (4,594 | ) |  | (5,250 | ) |
| Transaction-related expenses (d) | (167 | ) |  | (86 | ) |  | (437 | ) |  | (415 | ) |
| Other corporate expenses (e) | (514 | ) |  | (333 | ) |  | (1,059 | ) |  | (887 | ) |
| Total operating loss | $ | (356 | ) |  | $ | (410 | ) |  | $ | (522 | ) |  | $ | (2,347 | ) |

[0001571996-18-000041:8k_2_02:80]
_________________

[0001571996-18-000041:8k_2_02:81]
| (a) | Pivotal, SecureWorks, RSA Security, Virtustream, and Boomi constitute "Other businesses" and do not meet the requirements for a reportable segment, either individually or collectively. The results of Other businesses are not material to the Company's overall results. |

[0001571996-18-000041:8k_2_02:82]
| (b) | Unallocated transactions includes long-term incentives, certain short-term incentive compensation expenses, and other corporate items that are not allocated to Dell Technologies' reportable segments. |

[0001571996-18-000041:8k_2_02:83]
| (c) | Impact of purchase accounting includes non-cash purchase accounting adjustments that are primarily related to the EMC merger transaction. |

[0001571996-18-000041:8k_2_02:84]
| (d) | Transaction-related expenses includes acquisition, integration, and divestiture related costs. |

[0001571996-18-000041:8k_2_02:85]
| (e) | Other corporate expenses includes severance and facility action costs as well as stock-based compensation expense. |

[0001571996-18-000041:8k_2_02:86]
SUPPLEMENTAL SELECTED NON-GAAP FINANCIAL MEASURES

[0001571996-18-000041:8k_2_02:87]
These tables present information about the Company’s non-GAAP net revenue, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP operating income, non-GAAP net income, EBITDA, and adjusted EBITDA, which are non-GAAP financial measures provided as a supplement to the results provided in accordance with generally accepted accounting principles in the United States of America (“GAAP”).  A detailed discussion of Dell Technologies’ reasons for including these non-GAAP financial measures, the limitations associated with these measures, the items excluded from these measures, and our reason for excluding those items are presented in “Management’s Discussion and Analysis of Financial Condition and Results of Operations - Non-GAAP Financial Measures” in our periodic reports filed with the SEC.  Dell Technologies encourages investors to review the non-GAAP discussion in conjunction with the presentation of non-GAAP financial measures.

[0001571996-18-000041:8k_2_02:88]
DELL TECHNOLOGIES INC.

[0001571996-18-000041:8k_2_02:89]
Selected Non-GAAP Financial Measures

[0001571996-18-000041:8k_2_02:90]
(in millions, except percentages; unaudited)

[0001571996-18-000041:8k_2_02:91]
|  | Three Months Ended |  |  |  | Nine Months Ended |  |  |
|  | November 2, 2018 |  | November 3, 2017 |  | Change |  | November 2, 2018 |  | November 3, 2017 |  | Change |
| Non-GAAP net revenue | $ | 22,651 |  |  | $ | 19,851 |  |  | 14% |  | $ | 67,316 |  |  | $ | 58,062 |  |  | 16% |
| Non-GAAP gross margin | $ | 7,000 |  |  | $ | 6,474 |  |  | 8% |  | $ | 20,985 |  |  | $ | 18,534 |  |  | 13% |
| % of non-GAAP net revenue | 31 | % |  | 33 | % |  |  |  | 31 | % |  | 32 | % |  |  |
| Non-GAAP operating expenses | $ | 4,936 |  |  | $ | 4,365 |  |  | 13% |  | $ | 14,787 |  |  | $ | 13,134 |  |  | 13% |
| % of non-GAAP net revenue | 22 | % |  | 22 | % |  |  |  | 22 | % |  | 23 | % |  |  |
| Non-GAAP operating income | $ | 2,064 |  |  | $ | 2,109 |  |  | (2)% |  | $ | 6,198 |  |  | $ | 5,400 |  |  | 15% |
| % of non-GAAP net revenue | 9 | % |  | 11 | % |  |  |  | 9 | % |  | 9 | % |  |  |
| Non-GAAP net income | $ | 1,200 |  |  | $ | 1,199 |  |  | —% |  | $ | 3,723 |  |  | $ | 3,072 |  |  | 21% |
| % of non-GAAP net revenue | 5 | % |  | 6 | % |  |  |  | 6 | % |  | 5 | % |  |  |
| Adjusted EBITDA | $ | 2,426 |  |  | $ | 2,441 |  |  | (1)% |  | $ | 7,268 |  |  | $ | 6,416 |  |  | 13% |
| % of non-GAAP net revenue | 11 | % |  | 12 | % |  |  |  | 11 | % |  | 11 | % |  |  |

[0001571996-18-000041:8k_2_02:92]
DELL TECHNOLOGIES INC.

[0001571996-18-000041:8k_2_02:93]
Reconciliation of Selected Non-GAAP Financial Measures

[0001571996-18-000041:8k_2_02:94]
(in millions, except percentages; unaudited; continued on next page)

[0001571996-18-000041:8k_2_02:95]
|  | Three Months Ended |  |  |  | Nine Months Ended |  |  |
|  | November 2, 2018 |  | November 3, 2017 |  | Change |  | November 2, 2018 |  | November 3, 2017 |  | Change |
| Net revenue | $ | 22,482 |  |  | $ | 19,556 |  |  | 15% |  | $ | 66,780 |  |  | $ | 57,077 |  |  | 17% |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Impact of purchase accounting | 169 |  |  | 295 |  |  |  |  | 536 |  |  | 985 |  |  |  |
| Non-GAAP net revenue | $ | 22,651 |  |  | $ | 19,851 |  |  | 14% |  | $ | 67,316 |  |  | $ | 58,062 |  |  | 16% |
| Gross margin | $ | 5,943 |  |  | $ | 5,220 |  |  | 14% |  | $ | 17,944 |  |  | $ | 14,645 |  |  | 23% |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 726 |  |  | 914 |  |  |  |  | 2,154 |  |  | 2,784 |  |  |  |
| Impact of purchase accounting | 171 |  |  | 307 |  |  |  |  | 549 |  |  | 1,020 |  |  |  |
| Transaction-related expenses | 102 |  |  | 5 |  |  |  |  | 239 |  |  | 22 |  |  |  |
| Other corporate expenses | 58 |  |  | 28 |  |  |  |  | 99 |  |  | 63 |  |  |  |
| Non-GAAP gross margin | $ | 7,000 |  |  | $ | 6,474 |  |  | 8% |  | $ | 20,985 |  |  | $ | 18,534 |  |  | 13% |
| Operating expenses | $ | 6,299 |  |  | $ | 5,630 |  |  | 12% |  | $ | 18,466 |  |  | $ | 16,992 |  |  | 9% |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | (820 | ) |  | (820 | ) |  |  |  | (2,440 | ) |  | (2,466 | ) |  |  |
| Impact of purchase accounting | (22 | ) |  | (59 | ) |  |  |  | (81 | ) |  | (175 | ) |  |  |
| Transaction-related expenses | (65 | ) |  | (81 | ) |  |  |  | (198 | ) |  | (393 | ) |  |  |
| Other corporate expenses | (456 | ) |  | (305 | ) |  |  |  | (960 | ) |  | (824 | ) |  |  |
| Non-GAAP operating expenses | $ | 4,936 |  |  | $ | 4,365 |  |  | 13% |  | $ | 14,787 |  |  | $ | 13,134 |  |  | 13% |
| Operating loss | $ | (356 | ) |  | $ | (410 | ) |  | 13% |  | $ | (522 | ) |  | $ | (2,347 | ) |  | 78% |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 1,546 |  |  | 1,734 |  |  |  |  | 4,594 |  |  | 5,250 |  |  |  |
| Impact of purchase accounting | 193 |  |  | 366 |  |  |  |  | 630 |  |  | 1,195 |  |  |  |
| Transaction-related expenses | 167 |  |  | 86 |  |  |  |  | 437 |  |  | 415 |  |  |  |
| Other corporate expenses | 514 |  |  | 333 |  |  |  |  | 1,059 |  |  | 887 |  |  |  |
| Non-GAAP operating income | $ | 2,064 |  |  | $ | 2,109 |  |  | (2)% |  | $ | 6,198 |  |  | $ | 5,400 |  |  | 15% |
| Net loss | $ | (895 | ) |  | $ | (851 | ) |  | (5)% |  | $ | (1,894 | ) |  | $ | (2,793 | ) |  | 32% |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 1,546 |  |  | 1,734 |  |  |  |  | 4,594 |  |  | 5,250 |  |  |  |
| Impact of purchase accounting | 193 |  |  | 366 |  |  |  |  | 630 |  |  | 1,195 |  |  |  |
| Transaction-related expenses | 167 |  |  | 86 |  |  |  |  | 437 |  |  | 415 |  |  |  |
| Other corporate expenses | 514 |  |  | 333 |  |  |  |  | 1,059 |  |  | 887 |  |  |  |
| Aggregate adjustment for income taxes | (325 | ) |  | (469 | ) |  |  |  | (1,103 | ) |  | (1,882 | ) |  |  |
| Non-GAAP net income | $ | 1,200 |  |  | $ | 1,199 |  |  | —% |  | $ | 3,723 |  |  | $ | 3,072 |  |  | 21% |

[0001571996-18-000041:8k_2_02:96]
DELL TECHNOLOGIES INC.

[0001571996-18-000041:8k_2_02:97]
Reconciliation of Selected Non-GAAP Financial Measures

[0001571996-18-000041:8k_2_02:98]
(in millions, except percentages; unaudited; continued)

[0001571996-18-000041:8k_2_02:99]
|  | Three Months Ended |  |  |  | Nine Months Ended |  |  |
|  | November 2, 2018 |  | November 3, 2017 |  | Change |  | November 2, 2018 |  | November 3, 2017 |  | Change |
| Net loss | $ | (895 | ) |  | $ | (851 | ) |  | (5)% |  | $ | (1,894 | ) |  | $ | (2,793 | ) |  | 32% |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Interest and other, net | 639 |  |  | 682 |  |  |  |  | 1,564 |  |  | 1,799 |  |  |  |
| Income tax benefit | (100 | ) |  | (241 | ) |  |  |  | (192 | ) |  | (1,353 | ) |  |  |
| Depreciation and amortization | 1,961 |  |  | 2,137 |  |  |  |  | 5,806 |  |  | 6,491 |  |  |  |
| EBITDA | $ | 1,605 |  |  | $ | 1,727 |  |  | (7)% |  | $ | 5,284 |  |  | $ | 4,144 |  |  | 28% |
| EBITDA | $ | 1,605 |  |  | $ | 1,727 |  |  | (7)% |  | $ | 5,284 |  |  | $ | 4,144 |  |  | 28% |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation expense | 256 |  |  | 221 |  |  |  |  | 671 |  |  | 630 |  |  |  |
| Impact of purchase accounting | 169 |  |  | 298 |  |  |  |  | 536 |  |  | 990 |  |  |  |
| Transaction-related expenses | 158 |  |  | 86 |  |  |  |  | 409 |  |  | 415 |  |  |  |
| Other corporate expenses | 238 |  |  | 109 |  |  |  |  | 368 |  |  | 237 |  |  |  |
| Adjusted EBITDA | $ | 2,426 |  |  | $ | 2,441 |  |  | (1)% |  | $ | 7,268 |  |  | $ | 6,416 |  |  | 13% |
