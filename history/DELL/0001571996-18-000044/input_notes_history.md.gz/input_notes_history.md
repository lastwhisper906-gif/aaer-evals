# DELL note change history — 0001571996-18-000034 → 0001571996-18-000044


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2018-12-10):
[0001571996-18-000044:note_history:1]
NOTE 11 — COMMITMENTS AND CONTINGENCIES
  (was, 2018-09-11, similarity 0.8657):
[0001571996-18-000034:note_history:1]
COMMITMENTS AND CONTINGENCIES

- added (2018-12-10):
[0001571996-18-000044:note_history:2]
The Company is involved in various claims, suits, assessments, investigations, and legal proceedings that arise from time to time in the ordinary course of its business, including those identified below, consisting of matters involving consumer, antitrust, tax, intellectual property, and other issues on a global basis.

- changed (2018-12-10):
[0001571996-18-000044:note_history:3]
The Company accrues a liability when it believes that it is both probable that a liability has been incurred and that it can reasonably estimate the amount of the loss.  The Company reviews these accruals at least quarterly and adjusts them to reflect ongoing negotiations, settlements, rulings, advice of legal counsel, and other relevant information.  To the extent new information is obtained and the Company’s views on the probable outcomes of claims, suits, assessments, investigations, or legal proceedings change, changes in the Company’s accrued liabilities would be recorded in the period in which such a determination is made.  For some matters, the amount of liability is not probable or the amount cannot be reasonably estimated and therefore accruals have not been made.
  (was, 2018-09-11, similarity 0.6272):
[0001571996-18-000034:note_history:3]
The Company is involved in various claims, suits, assessments, investigations, and legal proceedings that arise from time to time in the ordinary course of its business, including those identified below, consisting of matters involving consumer, antitrust, tax, intellectual property, and other issues on a global basis.  The Company accrues a liability when it believes that it is both probable that a liability has been incurred and that it can reasonably estimate the amount of the loss.  The Company reviews these accruals at least quarterly and adjusts them to reflect ongoing negotiations, settlements, rulings, advice of legal counsel, and other relevant information.  To the extent new information is obtained and the Company's views on the probable outcomes of claims, suits, assessments, investigations, or legal proceedings change, changes in the Company's accrued liabilities would be recorded in the period in which such a determination is made.  For some matters, the amount of liability is not probable or the amount cannot be reasonably estimated and therefore accruals have not been made.  The following is a discussion of the Company's significant legal matters and other proceedings:

- added (2018-12-10):
[0001571996-18-000044:note_history:4]
The following is a discussion of the Company’s significant legal matters and other proceedings:

- changed (2018-12-10):
[0001571996-18-000044:note_history:5]
Appraisal Proceedings — On October 29, 2013, Dell Technologies acquired Dell in a transaction referred to as the going-private transaction.  Holders of shares of Dell common stock who did not vote on September 12, 2013 in favor of the proposal to adopt the amended going-private transaction agreement and who properly demanded appraisal of their shares and who otherwise comply with the requirements of Section 262 of the Delaware General Corporate Law (“DGCL”) are entitled to seek appraisal for, and obtain payment in cash for the judicially determined “fair value” (as defined pursuant to Section 262 of the DGCL) of, their shares in lieu of receiving the going-private transaction consideration. The liability for the appraisal proceedings was approximately $129 million as of February 2, 2018.  On May 8, 2018, the Company entered into an agreement to settle a portion of the liability related to the appraisal proceedings in the amount of approximately $70 million, and on May 18, 2018, this portion of the liability was fully paid.  The Company settled with the remaining plaintiffs as of July 16, 2018 in the amount of approximately $30 million.  The remaining liability accrual was released to Interest and other, net during the three months ended August 3, 2018.  As of August 3, 2018, there was no remaining liability for appraisal proceedings.
  (was, 2018-09-11, similarity 0.6722):
[0001571996-18-000034:note_history:5]
Appraisal Proceedings — On October 29, 2013, Dell Technologies acquired Dell in a transaction referred to as the going-private transaction.  Holders of shares of Dell common stock who did not vote on September 12, 2013 in favor of the proposal to adopt the amended going-private transaction agreement and who properly demanded appraisal of their shares and who otherwise comply with the requirements of Section 262 of the Delaware General Corporate Law ("DGCL") are entitled to seek appraisal for, and obtain payment in cash for the judicially determined "fair value" (as defined pursuant to Section 262 of the DGCL) of, their shares in lieu of receiving the going-private transaction consideration.  Dell initially recorded a liability of $13.75 for each share with respect to which appraisal has been demanded and as to which the demand has not been withdrawn, together with interest at the statutory rate discussed below.  The Court of Chancery ruled that the fair value of the appraisal shares as of October 29, 2013, the date on which the going-private transaction became effective, was $17.62 per share.  This ruling would entitle the holders of the remaining 5,505,630 shares subject to the appraisal proceedings to $17.62 per share, plus interest at a statutory rate, compounded quarterly.  On November 21, 2016, the Court of Chancery entered final judgment in the appraisal action.  On November 22, 2016, Dell filed a notice of appeal to the Delaware Supreme Court, which issued a decision on December 14, 2017.  In its decision, the Delaware Supreme Court reversed, in part, and affirmed, in part, the decision of the Delaware Court of Chancery.  On January 2, 2018, the Delaware Supreme Court issued its formal mandate remanding the matter to the Court of Chancery for further proceedings consistent with its opinion.  In accordance with direction by the Court of Chancery, the parties submitted proposals to the Court of Chancery outlining the remaining issues to be adjudicated.  The liability for the appraisal proceedings was approximately $129 million as of February 2, 2018.  On May 8, 2018, the Company entered into an agreement to settle a portion of the liability related to the appraisal proceedings in the amount of approximately $70 million, and on May 18, 2018, this portion of the liability was fully paid.  The Company settled with the remaining plaintiffs as of July 16, 2018 in the amount of approximately $30 million.  The remaining liability accrual was released to Interest and other, net during the three months ended August 3, 2018.  As of August 3, 2018, there was no remaining liability for appraisal proceedings.

- changed (2018-12-10):
[0001571996-18-000044:note_history:6]
Securities Litigation — On May 22, 2014, a securities class action seeking compensatory damages was filed in the United States District Court for the Southern District of New York, captioned the City of Pontiac Employee Retirement System vs. Dell Inc. et. al. (Case No. 1:14-cv-03644).  The action names as defendants Dell Inc. and certain current and former executive officers, and alleges that Dell made false and misleading statements about Dell’s business operations and products between February 22, 2012 and May 22, 2012, which resulted in artificially inflated stock prices.  The case was transferred to the United States District Court for the Western District of Texas, where the defendants filed a motion to dismiss.  On September 16, 2016, the Court denied the motion to dismiss and the case is proceeding with discovery.  The defendants believe the claims asserted are without merit and the risk of material loss is remote.
  (was, 2018-09-11, similarity 0.9989):
[0001571996-18-000034:note_history:6]
Securities Litigation — On May 22, 2014, a securities class action seeking compensatory damages was filed in the United States District Court for the Southern District of New York, captioned the City of Pontiac Employee Retirement System vs. Dell Inc. et. al. (Case No. 1:14-cv-03644).  The action names as defendants Dell Inc. and certain current and former executive officers, and alleges that Dell made false and misleading statements about Dell's business operations and products between February 22, 2012 and May 22, 2012, which resulted in artificially inflated stock prices.  The case was transferred to the United States District Court for the Western District of Texas, where the defendants filed a motion to dismiss.  On September 16, 2016, the Court denied the motion to dismiss and the case is proceeding with discovery.  The defendants believe the claims asserted are without merit and the risk of material loss is remote.

- changed (2018-12-10):
[0001571996-18-000044:note_history:7]
Copyright Levies — The Company’s obligation to collect and remit copyright levies in certain European Union (“EU”) countries may be affected by the resolution of legal proceedings pending in Germany and other EU member states against various companies, including Dell subsidiaries.  The plaintiffs in those proceedings generally seek to impose or modify the levies with respect to sales of such equipment as multifunction devices, phones, personal computers, storage devices, and printers, alleging that such products enable the copying of copyrighted materials.  Some of the proceedings also challenge whether the levy schemes in those countries comply with EU law.  Certain EU member countries that do not yet impose levies on digital devices are expected to implement legislation to enable them to extend existing levy schemes, while some other EU member countries are expected to limit the scope of levy schemes and their applicability in the digital hardware environment.  Dell, other companies, and various industry associations have opposed the extension of levies to the digital environment and have advocated alternative models of compensation to rights holders.
  (was, 2018-09-11, similarity 0.8342):
[0001571996-18-000034:note_history:7]
Copyright Levies — The Company's obligation to collect and remit copyright levies in certain European Union ("EU") countries may be affected by the resolution of legal proceedings pending in Germany and other EU member states against various companies, including Dell subsidiaries.  The plaintiffs in those proceedings generally seek to impose or modify the levies with respect to sales of such equipment as multifunction devices, phones, personal computers, storage devices, and printers, alleging that such products enable the copying of copyrighted materials.  Some of the proceedings also challenge whether the levy schemes in those countries comply with EU law.  Certain EU member countries that do not yet impose levies on digital devices are expected to implement legislation to enable them to extend existing levy schemes, while some other EU member countries are expected to limit the scope of levy schemes and their applicability in the digital hardware environment.  Dell, other companies, and various industry associations have opposed the extension of levies to the digital environment and have advocated alternative models of compensation to rights holders.  The Company continues to collect levies in certain EU countries where it has determined that based on local laws it is probable that it has a payment obligation.  The amount of levies is generally based on the number of products sold and the per-product amounts of the levies, which vary.  The Company accrues a liability when it believes that it is both probable that a loss has been incurred and when it can reasonably estimate the amount of the loss.

- added (2018-12-10):
[0001571996-18-000044:note_history:8]
The Company continues to collect levies in certain EU countries where it has determined that based on local laws it is probable that it has a payment obligation.  The amount of levies is generally based on the number of products sold and the per-product amounts of the levies, which vary.  The Company accrues a liability when it believes that it is both probable that a loss has been incurred and when it can reasonably estimate the amount of the loss.

- added (2018-12-10):
[0001571996-18-000044:note_history:9]
Class V Transaction Litigation — On October 31, 2018, High River Limited Partnership, Icahn Partners Master Fund LP, and Icahn Partners LP filed an action against Dell in Delaware Chancery Court, pursuant to Section 220 of the DGCL, seeking (1) to inspect certain of the Company’s books and records purportedly related to the Class V transaction described in Note 16 of the Notes to the Condensed Consolidated Financial Statements or the potential initial public offering of the Company’s Class C Common Stock, and (2) the public dissemination of unspecified materials already produced for inspection (High River LP v. Dell Tech. Holdings Inc., No. 2018-0790 (Del. Ch. filed Oct. 31, 2018)).  By motion dated October 31, 2018, the plaintiffs sought expedited treatment of their claims.  On November 1, 2018, Dell filed its opposition to the motion for expedited treatment.  On November 5, 2018, the Chancery Court scheduled a trial on the matter for November 19, 2018.  Prior to the scheduled trial, on November 15, 2018, the plaintiffs voluntarily dismissed this action against the Company.

- added (2018-12-10):
[0001571996-18-000044:note_history:10]
On November 8, 2018, Hallandale Beach Police and Fire Retirement Plan filed a putative stockholder class action lawsuit against our directors and Michael S. Dell, a separate property trust for the benefit of Mr. Dell’s wife, investment funds affiliated with Silver Lake Partners, and investment funds affiliated with MSD Partners, L.P. in Delaware Chancery Court, alleging, among other things, that the directors of the Company breached their fiduciary duties to holders of the Class V Common Stock in connection with the Class V transaction, because, among other things, the Class V transaction is allegedly financially unfair and coercive to holders of the Class V Common Stock and there were various conflicts of interest (Hallandale Beach Police and Fire Retirement Plan v. Michael Dell, et al., No. 2018-0816-JTL (Del. Ch. filed November 8, 2018)). The lawsuit seeks, among other things, a judicial declaration that that defendants breached their fiduciary duties and an award of damages, fees and costs.

- added (2018-12-10):
[0001571996-18-000044:note_history:11]
As of November 2, 2018, the Company does not believe there is a reasonable possibility that a material loss exceeding the amounts already accrued for these or other proceedings or matters has been incurred.  However, since the ultimate resolution of any such proceedings and matters is inherently unpredictable, the Company’s business, financial condition, results of operations, or cash flows could be materially affected in any particular period by unfavorable outcomes in one or more of these proceedings or matters.  Whether the outcome of any claim, suit, assessment, investigation, or legal proceeding, individually or collectively, could have a material adverse effect on the Company’s business, financial condition, results of operations, or cash flows will depend on a number of variables, including the nature, timing, and amount of any associated expenses, amounts paid in settlement, damages, or other remedies or consequences.

- removed (2018-12-10):
[0001571996-18-000034:note_history:12]
CamSoft Litigation — CamSoft Data Systems, Inc. ("CamSoft") filed in 2009 a lawsuit, captioned CamSoft Data Systems, Inc. v. Southern Electronics Supply, Inc., et al., in the 19th Judicial District Court, Parish of East Baton Rouge, Louisiana, alleging that Dell conspired with others to misappropriate CamSoft’s trade secrets relating to municipal wireless video surveillance systems and engaged in unfair trade practices.  CamSoft asserted Louisiana state law claims for misappropriation of trade secrets, unfair trade practices, antitrust and other torts.  CamSoft seeks compensatory and punitive damages in excess of $2 billion.  The Company believes the claims are without merit and has motions to dismiss pending before the court.  The case is scheduled for trial in October 2018.

- removed (2018-12-10):
[0001571996-18-000034:note_history:13]
As of August 3, 2018, the Company does not believe there is a reasonable possibility that a material loss exceeding the amounts already accrued for these or other proceedings or matters has been incurred.  However, since the ultimate resolution of any such proceedings and matters is inherently unpredictable, the Company's business, financial condition, results of operations, or cash flows could be materially affected in any particular period by unfavorable outcomes in one or more of these proceedings or matters.  Whether the outcome of any claim, suit, assessment, investigation, or legal proceeding, individually or collectively, could have a material adverse effect on the Company's business, financial condition, results of operations, or cash flows will depend on a number of variables, including the nature, timing, and amount of any associated expenses, amounts paid in settlement, damages, or other remedies or consequences.


## us-gaap:CommitmentsAndContingenciesPolicyTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2018-12-10):
[0001571996-18-000044:note_history:14]
The Company accrues a liability when it believes that it is both probable that a liability has been incurred and that it can reasonably estimate the amount of the loss.  The Company reviews these accruals at least quarterly and adjusts them to reflect ongoing negotiations, settlements, rulings, advice of legal counsel, and other relevant information.  To the extent new information is obtained and the Company’s views on the probable outcomes of claims, suits, assessments, investigations, or legal proceedings change, changes in the Company’s accrued liabilities would be recorded in the period in which such a determination is made.  For some matters, the amount of liability is not probable or the amount cannot be reasonably estimated and therefore accruals have not been made.
  (was, 2018-09-11, similarity 0.9974):
[0001571996-18-000034:note_history:14]
The Company accrues a liability when it believes that it is both probable that a liability has been incurred and that it can reasonably estimate the amount of the loss.  The Company reviews these accruals at least quarterly and adjusts them to reflect ongoing negotiations, settlements, rulings, advice of legal counsel, and other relevant information.  To the extent new information is obtained and the Company's views on the probable outcomes of claims, suits, assessments, investigations, or legal proceedings change, changes in the Company's accrued liabilities would be recorded in the period in which such a determination is made.  For some matters, the amount of liability is not probable or the amount cannot be reasonably estimated and therefore accruals have not been made.


## us-gaap:BusinessDescriptionAndBasisOfPresentationTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2018-12-10):
[0001571996-18-000044:note_history:15]
NOTE 1 — BASIS OF PRESENTATION
  (was, 2018-09-11, similarity 0.8235):
[0001571996-18-000034:note_history:15]
BASIS OF PRESENTATION

- changed (2018-12-10):
[0001571996-18-000044:note_history:16]
References in these Notes to the Condensed Consolidated Financial Statements to the “Company” or “Dell Technologies” mean Dell Technologies Inc. individually and together with its consolidated subsidiaries.
  (was, 2018-09-11, similarity 0.9612):
[0001571996-18-000034:note_history:16]
References in these Notes to the Condensed Consolidated Financial Statements to the "Company" or "Dell Technologies" mean Dell Technologies Inc. individually and together with its consolidated subsidiaries.

- changed (2018-12-10):
[0001571996-18-000044:note_history:17]
Basis of Presentation — The accompanying unaudited Condensed Consolidated Financial Statements should be read in conjunction with the audited Consolidated Financial Statements and accompanying Notes included in the Company’s Annual Report on Form 10-K for the fiscal year ended February 2, 2018, and the recast audited Consolidated Financial Statements and accompanying Notes for the fiscal years ended February 2, 2018 and February 3, 2017 (the “Recast Financial Statements”)
  (was, 2018-09-11, similarity 0.9351):
[0001571996-18-000034:note_history:17]
Basis of Presentation — The accompanying unaudited Condensed Consolidated Financial Statements should be read in conjunction with the audited Consolidated Financial Statements and accompanying Notes included in the Company's Annual Report on Form 10-K for the fiscal year ended February 2, 2018, and the recast audited Consolidated Financial Statements and accompanying Notes for the fiscal years ended February 2, 2018  and February 3, 2017 (the "Recast Financial Statements")

- changed (2018-12-10):
[0001571996-18-000044:note_history:18]
and other financial information included in the Company’s Current Report on Form 8-K filed with the Securities and Exchange Commission (the “SEC”) on August 6, 2018.  The Recast Financial Statements were recast from and supersede the audited Consolidated Financial Statements for the fiscal years ended February 2, 2018 and February 3, 2017 included in the Company’s Annual Report on Form 10-K for the fiscal year ended February 2, 2018.  Such audited Consolidated Financial Statements were recast to present certain previously reported financial statements and other related financial information on a basis consistent with the new accounting standards adopted during the three months ended May 4, 2018.  Further, segment information was recast to conform with certain segment reporting changes the Company made during the three months ended May 4, 2018.  See below for additional information regarding recently adopted accounting pronouncements.
  (was, 2018-09-11, similarity 0.9923):
[0001571996-18-000034:note_history:18]
and other financial information included in the Company's Current Report on Form 8-K filed with the Securities and Exchange Commission (the "SEC") on August 6, 2018.  The Recast Financial Statements were recast from and supersede the audited Consolidated Financial Statements for the fiscal years ended February 2, 2018  and February 3, 2017 included in the Company's Annual Report on Form 10-K for the fiscal year ended February 2, 2018.  Such audited Consolidated Financial Statements were recast to present certain previously reported financial statements and other related financial information on a basis consistent with the new accounting standards adopted during the three months ended May 4, 2018.  Further, segment information was recast to conform with certain segment reporting changes the Company made during the three months ended May 4, 2018.  See below for additional information regarding recently adopted accounting pronouncements.

- added (2018-12-10):
[0001571996-18-000044:note_history:19]
These Condensed Consolidated Financial Statements have been prepared in accordance with accounting principles generally accepted in the United States of America (“GAAP”).  In the opinion of management, the accompanying Condensed  Consolidated Financial Statements reflect all adjustments of a normal recurring nature considered necessary to fairly state the financial position of Dell Technologies Inc. as of November 2, 2018, the results of its operations and corresponding comprehensive income (loss) for the three and nine months ended November 2, 2018 and November 3, 2017, and its cash flows for the nine months ended November 2, 2018 and November 3, 2017.  The February 2, 2018 condensed consolidated balance sheet included herein was derived from the Recast Financial Statements.

- changed (2018-12-10):
[0001571996-18-000044:note_history:20]
The preparation of financial statements in accordance with GAAP requires management to make estimates and assumptions that affect the amounts reported in the Condensed Consolidated Financial Statements and the accompanying Notes.  Actual results could differ materially from those estimates.  The results of operations and comprehensive income (loss) for the three and nine months ended November 2, 2018 and November 3, 2017 and the cash flows for the nine months ended November 2, 2018 and November 3, 2017 are not necessarily indicative of the results to be expected for the full fiscal year or for any other fiscal period.
  (was, 2018-09-11, similarity 0.6545):
[0001571996-18-000034:note_history:20]
The preparation of financial statements in accordance with GAAP requires management to make estimates and assumptions that affect the amounts reported in the Condensed Consolidated Financial Statements and the accompanying Notes.  Actual results could differ materially from those estimates.  The results of operations and comprehensive income (loss) for the three and six months ended August 3, 2018 and August 4, 2017 and the cash flows for the six months ended August 3, 2018 and August 4, 2017 are not necessarily indicative of the results to be expected for the full fiscal year or for any other fiscal period.

- changed (2018-12-10):
[0001571996-18-000044:note_history:21]
The Company’s fiscal year is the 52- or 53-week period ending on the Friday nearest January 31.  The fiscal year ended February 2, 2018 was a 52-week period, and the fiscal year ending February 1, 2019 will be a 52-week period.
  (was, 2018-09-11, similarity 0.9378):
[0001571996-18-000034:note_history:21]
The Company's fiscal year is the 52- or 53-week period ending on the Friday nearest January 31.  The fiscal year ended February 2, 2018 ("Fiscal 2018") was a 52-week period, and the fiscal year ending February 1, 2019 ("Fiscal 2019") will be a 52-week period.

- changed (2018-12-10):
[0001571996-18-000044:note_history:22]
Principles of Consolidation — These Condensed Consolidated Financial Statements include the accounts of Dell Technologies and its wholly-owned subsidiaries, as well as the accounts of VMware, Inc., Pivotal Software, Inc. (“Pivotal”), and SecureWorks Corp. (“SecureWorks”), each of which is majority-owned by Dell Technologies.  All intercompany transactions have been eliminated.
  (was, 2018-09-11, similarity 0.8915):
[0001571996-18-000034:note_history:22]
Principles of Consolidation — These Condensed Consolidated Financial Statements include the accounts of Dell Technologies and its wholly-owned subsidiaries, as well as the accounts of SecureWorks Corp. ("SecureWorks"), VMware, Inc., and Pivotal Software, Inc. ("Pivotal"), each of which is majority-owned by Dell Technologies.  All intercompany transactions have been eliminated.

- changed (2018-12-10):
[0001571996-18-000044:note_history:23]
Unless the context indicates otherwise, references in these Notes to the Condensed Consolidated Financial Statements to “VMware” mean the VMware reportable segment, which reflects the operations of VMware, Inc. (NYSE: VMW) within Dell Technologies.  See Exhibit 99.1 filed with the quarterly report on Form 10-Q for the quarterly period ended November 2, 2018 for information on the differences between VMware reportable segment results and VMware, Inc. results.
  (was, 2018-09-11, similarity 0.8341):
[0001571996-18-000034:note_history:23]
Unless the context indicates otherwise, references in these Notes to the Condensed Consolidated Financial Statements to "VMware" mean the VMware reportable segment, which reflects the operations of VMware, Inc. (NYSE: VMW) within Dell Technologies.  See Exhibit 99.1 filed with the quarterly report on Form 10-Q for the quarterly period ended August 3, 2018 for information on the differences between VMware reportable segment results and VMware, Inc. results.

- changed (2018-12-10):
[0001571996-18-000044:note_history:24]
EMC Merger Transaction — On September 7, 2016, the Company completed its acquisition by merger of EMC Corporation (“EMC”), referred to as the EMC merger transaction.  The consolidated results of EMC are included in Dell Technologies’ consolidated results presented in these financial statements.
  (was, 2018-09-11, similarity 0.9792):
[0001571996-18-000034:note_history:24]
EMC Merger Transaction — On September 7, 2016, the Company completed its acquisition by merger of EMC Corporation ("EMC"), referred to as the EMC merger transaction.  The consolidated results of EMC are included in Dell Technologies' consolidated results presented in these financial statements.

- added (2018-12-10):
[0001571996-18-000044:note_history:25]
Pivotal Initial Public Offering — On April 24, 2018, Pivotal completed a registered underwritten initial public offering (“IPO”) of its Class A common stock (NYSE: PVTL).  The results of Pivotal’s operations are included in other businesses.  For more information regarding the Company’s ownership of Pivotal, see Note 14 of the Notes to the Condensed Consolidated Financial Statements.

- changed (2018-12-10):
[0001571996-18-000044:note_history:26]
Leases — In February 2016, the Financial Accounting Standards Board (“FASB”) issued amended guidance on the accounting for leasing transactions.  The primary objective of this update is to increase transparency and comparability among organizations by requiring lessees to recognize a lease liability for the obligation to make lease payments and a right-of-use asset for the right to use the underlying asset for the lease term.  The guidance also makes some changes to lessor accounting and requires additional disclosures about all leasing arrangements.  Companies are required to use a modified retrospective approach, with the option of applying the requirements of the standard either (1) retrospectively to each prior comparative reporting period presented, or (2) retrospectively at the beginning of the period of adoption.  The Company will adopt this standard for the fiscal year beginning February 2, 2019, and will apply it at the beginning of the period of adoption through a cumulative-effect adjustment to retained earnings.  In the area of lessee accounting, the Company anticipates that the most significant change will be recognition of right-of-use assets and lease liabilities on the Consolidated Statements of Financial Position.  In the area of lessor accounting, the Company anticipates that the most significant change will be an increase to future originations of operating leases due to elimination of the third-party residual value guarantee insurance in the sales-type lease test.
  (was, 2018-09-11, similarity 0.996):
[0001571996-18-000034:note_history:26]
Leases — In February 2016, the Financial Accounting Standards Board ("FASB") issued amended guidance on the accounting for leasing transactions.  The primary objective of this update is to increase transparency and comparability among organizations by requiring lessees to recognize a lease liability for the obligation to make lease payments and a right-of-use asset for the right to use the underlying asset for the lease term.  The guidance also makes some changes to lessor accounting and requires additional disclosures about all leasing arrangements.  Companies are required to use a modified retrospective approach, with the option of applying the requirements of the standard either (1) retrospectively to each prior comparative reporting period presented, or (2) retrospectively at the beginning of the period of adoption.  The Company will adopt this standard for the fiscal year beginning February 2, 2019, and will apply it at the beginning of the period of adoption through a cumulative-effect adjustment to retained earnings.  In the area of lessee accounting, the Company anticipates that the most significant change will be recognition of right-of-use assets and lease liabilities on the Consolidated Statements of Financial Position.  In the area of lessor accounting, the Company anticipates that the most significant change will be an increase to future originations of operating leases due to elimination of the third-party residual value guarantee insurance in the sales-type lease test.

- changed (2018-12-10):
[0001571996-18-000044:note_history:27]
Revenue from Contracts with Customers — In May 2014, the FASB issued amended guidance on the recognition of revenue from contracts with customers.  The objective of the new standard is to establish a single comprehensive model for entities to use in accounting for revenue arising from contracts with customers and will supersede substantially all of the existing revenue recognition guidance, including industry-specific guidance.  The new standard requires entities to recognize revenue when it transfers promised goods or services to customers in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services.  Further, the new standard requires additional disclosures to help enable users of the financial statements to better understand the nature, amount, timing, risks, and judgments related to revenue recognition and related cash flows from contracts with customers.  Concurrently, the FASB issued guidance on the accounting for costs to fulfill or obtain a customer contract.  The Company adopted these standards during the three months ended May 4, 2018 using the full retrospective method, which requires the Company to recast each prior period presented consistent with the new guidance.  The Company recorded a credit of approximately $1 billion to retained earnings as of January 29, 2016 to reflect the cumulative effect of the adoption.  See tables provided below which present the impact of the new accounting standards to the Company’s previously reported financial results.  See also Note 2 of the Notes to the Condensed Consolidated Financial Statements for a summary of significant policies related to the new accounting standards.
  (was, 2018-09-11, similarity 0.9994):
[0001571996-18-000034:note_history:27]
Revenue from Contracts with Customers — In May 2014, the FASB issued amended guidance on the recognition of revenue from contracts with customers.  The objective of the new standard is to establish a single comprehensive model for entities to use in accounting for revenue arising from contracts with customers and will supersede substantially all of the existing revenue recognition guidance, including industry-specific guidance.  The new standard requires entities to recognize revenue when it transfers promised goods or services to customers in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services.  Further, the new standard requires additional disclosures to help enable users of the financial statements to better understand the nature, amount, timing, risks, and judgments related to revenue recognition and related cash flows from contracts with customers.  Concurrently, the FASB issued guidance on the accounting for costs to fulfill or obtain a customer contract.  The Company adopted these standards during the three months ended May 4, 2018 using the full retrospective method, which requires the Company to recast each prior period presented consistent with the new guidance.  The Company recorded a credit of approximately $1 billion to retained earnings as of January 29, 2016 to reflect the cumulative effect of the adoption.  See tables provided below which present the impact of the new accounting standards to the Company's previously reported financial results.  See also Note 2 of the Notes to the Condensed Consolidated Financial Statements for a summary of significant policies related to the new accounting standards.

- changed (2018-12-10):
[0001571996-18-000044:note_history:28]
Recognition and Measurement of Financial Assets and Financial Liabilities — In January 2016, the FASB issued amended guidance that generally requires changes in the fair value of equity investments, other than those accounted for under the equity method, to be recognized through net income, rather than other comprehensive income.  For equity investments without readily determinable fair values, the Company is no longer permitted to use the cost method of accounting.  The Company has elected to apply the measurement alternative for those investments.  Under the alternative, the Company measures investments without readily determinable fair values at cost, less impairment, adjusted by observable price changes on a prospective basis.  The Company must make a separate election to use the alternative for each eligible investment, and is required to reassess at each reporting period whether an investment qualifies for the alternative.  The Company adopted this standard during the three months ended May 4, 2018.  Adoption of the standard was applied through a cumulative one-time adjustment to accumulated deficit of $56 million for the accumulated unrealized gain previously recorded in other comprehensive income.  The impact of the standard on the Condensed Consolidated Statements of Income (Loss) during the three and nine months ended November 2, 2018 was a loss of $14 million and a gain of $209 million, respectively, recognized in interest and other, net, and the impact in future periods will depend on the relative changes in market price of the equity investments.
  (was, 2018-09-11, similarity 0.9721):
[0001571996-18-000034:note_history:28]
Recognition and Measurement of Financial Assets and Financial Liabilities — In January 2016, the FASB issued amended guidance that generally requires changes in the fair value of equity investments, other than those accounted for under the equity method, to be recognized through net income, rather than other comprehensive income.  For equity investments without readily determinable fair values, the Company is no longer permitted to use the cost method of accounting.  The Company has elected to apply the measurement alternative for those investments.  Under the alternative, the Company measures investments without readily determinable fair values at cost, less impairment, adjusted by observable price changes on a prospective basis.  The Company must make a separate election to use the alternative for each eligible investment, and is required to reassess at each reporting period whether an investment qualifies for the alternative.  The Company adopted this standard during the three months ended May 4, 2018.  Adoption of the standard was applied through a cumulative one-time adjustment to accumulated deficit of $56 million for the accumulated unrealized gain previously recorded in other comprehensive income.  The impact of the standard on the Condensed Consolidated Statements of Income (Loss) during the three and six months ended August 3, 2018 was a gain of approximately $123 million and $223 million, respectively, recognized in interest and other, net, and the impact in future periods will depend on the relative changes in market price of the equity investments.

- changed (2018-12-10):
[0001571996-18-000044:note_history:29]
Clarifying the Definition of a Business — In January 2017, the FASB issued amended guidance to clarify the definition of a business with the objective of adding guidance to assist entities with evaluating whether transactions should be accounted for as acquisitions (or disposals) of assets or businesses.  Public entities must adopt the new guidance for fiscal years beginning after December 15, 2017, and interim periods within those fiscal years.  The new guidance did not have a material impact on the Company’s conclusions regarding transactions that were assessed in the current period.
  (was, 2018-09-11, similarity 0.9983):
[0001571996-18-000034:note_history:29]
Clarifying the Definition of a Business — In January 2017, the FASB issued amended guidance to clarify the definition of a business with the objective of adding guidance to assist entities with evaluating whether transactions should be accounted for as acquisitions (or disposals) of assets or businesses.  Public entities must adopt the new guidance for fiscal years beginning after December 15, 2017, and interim periods within those fiscal years.  The new guidance did not have a material impact on the Company's conclusions regarding transactions that were assessed in the current period.

- changed (2018-12-10):
[0001571996-18-000044:note_history:30]
Simplifying the Test for Goodwill Impairment — In January 2017, the FASB issued amended guidance to simplify the subsequent measurement of goodwill by removing Step 2 of the goodwill impairment test.  Instead, under the amendments in the new guidance, an entity should perform its annual, or interim, goodwill impairment test by comparing the fair value of a reporting unit with its carrying amount.  An entity should recognize an impairment charge for the amount by which the carrying amount exceeds the reporting unit’s fair value.  Public entities must adopt the new guidance in fiscal years beginning after December 15, 2019, with early adoption permitted.  In conjunction with its annual goodwill and indefinite-lived intangible assets impairment testing which occurs during the third fiscal quarter of each year, the Company elected to early adopt this guidance during the three months ended November 2, 2018.  No interim goodwill impairment tests were required during both the three months ended May 4, 2018 and August 3, 2018.  See Note 8 of the Notes to the Condensed Consolidated Financial Statements for additional information about goodwill impairment testing.
  (was, 2018-09-11, similarity 0.6667):
[0001571996-18-000034:note_history:30]
Simplifying the Test for Goodwill Impairment — In January 2017, the FASB issued amended guidance to simplify the subsequent measurement of goodwill by removing Step 2 of the goodwill impairment test.  Instead, under the amendments in the new guidance, an entity should perform its annual, or interim, goodwill impairment test by comparing the fair value of a reporting unit with its carrying amount.  An entity should recognize an impairment charge for the amount by which the carrying amount exceeds the reporting unit's fair value.  Public entities must adopt the new guidance in fiscal years beginning after December 15, 2019, with early adoption permitted.  The Company is currently evaluating the impact of the new guidance but does not expect that the standard will have an impact on its Consolidated Financial Statements.

- changed (2018-12-10):
[0001571996-18-000044:note_history:31]
The following tables present the impact of the new accounting standards to the Company’s previously reported financial results.
  (was, 2018-09-11, similarity 0.9921):
[0001571996-18-000034:note_history:31]
The following tables present the impact of the new accounting standards to the Company's previously reported financial results.

- changed (2018-12-10):
[0001571996-18-000044:note_history:32]
| (a) | Amounts as reported in the Company’s Annual Report on Form 10-K for the fiscal year ended February 2, 2018. |
  (was, 2018-09-11, similarity 0.991):
[0001571996-18-000034:note_history:32]
| (a) | Amounts as reported in the Company's Annual Report on Form 10-K for the fiscal year ended February 2, 2018. |

- changed (2018-12-10):
[0001571996-18-000044:note_history:33]
Deferred revenue.  The adoption of the new revenue standard resulted in a decline in deferred revenue due to earlier recognition of revenue for software licenses, and less of the aggregate transaction price being allocated to extended warranty.  Deferred revenue was also reduced by the impact of variable consideration (i.e., price concessions, rebates, and refunds).  The reduction in deferred revenue was partially offset by an increase resulting from the change in presentation of deferred costs on third-party software offerings, which are reported in other assets, and are either sold on a standalone basis or as an attached component of the Company’s hardware offering.  The Company previously reported the associated deferred revenue net of these deferred costs in deferred revenue.
  (was, 2018-09-11, similarity 0.9987):
[0001571996-18-000034:note_history:33]
Deferred revenue.  The adoption of the new revenue standard resulted in a decline in deferred revenue due to earlier recognition of revenue for software licenses, and less of the aggregate transaction price being allocated to extended warranty.  Deferred revenue was also reduced by the impact of variable consideration (i.e., price concessions, rebates, and refunds).  The reduction in deferred revenue was partially offset by an increase resulting from the change in presentation of deferred costs on third-party software offerings, which are reported in other assets, and are either sold on a standalone basis or as an attached component of the Company's hardware offering.  The Company previously reported the associated deferred revenue net of these deferred costs in deferred revenue.

- changed (2018-12-10):
[0001571996-18-000044:note_history:34]
Condensed Consolidated Statements of Income (Loss)
  (was, 2018-09-11, similarity 0.9899):
[0001571996-18-000034:note_history:34]
Condensed Consolidated Statement of Income (Loss)

- changed (2018-12-10):
[0001571996-18-000044:note_history:35]
|  | Three Months Ended |  | Nine Months Ended |
|  | November 3, 2017 |  | November 3, 2017 |
|  | As Reported (a) |  | Revenue from Contracts with Customers |  | As Recast |  | As Reported (a) |  | Revenue from Contracts with Customers |  | As Recast |
|  | (in millions, except per share amounts) |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Products | $ | 14,680 |  |  | $ | 440 |  |  | $ | 15,120 |  |  | $ | 42,003 |  |  | $ | 1,853 |  |  | $ | 43,856 |  |
| Services | 4,930 |  |  | (494 | ) |  | 4,436 |  |  | 14,722 |  |  | (1,501 | ) |  | 13,221 |  |
| Total net revenue | 19,610 |  |  | (54 | ) |  | 19,556 |  |  | 56,725 |  |  | 352 |  |  | 57,077 |  |
| Cost of net revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Products | 12,369 |  |  | 204 |  |  | 12,573 |  |  | 36,206 |  |  | 965 |  |  | 37,171 |  |
| Services | 2,078 |  |  | (315 | ) |  | 1,763 |  |  | 6,245 |  |  | (984 | ) |  | 5,261 |  |
| Total cost of net revenue | 14,447 |  |  | (111 | ) |  | 14,336 |  |  | 42,451 |  |  | (19 | ) |  | 42,432 |  |
| Gross margin | 5,163 |  |  | 57 |  |  | 5,220 |  |  | 14,274 |  |  | 371 |  |  | 14,645 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |
| Selling, general, and administrative | 4,625 |  |  | (66 | ) |  | 4,559 |  |  | 13,989 |  |  | (294 | ) |  | 13,695 |  |
| Research and development | 1,071 |  |  | — |  |  | 1,071 |  |  | 3,297 |  |  | — |  |  | 3,297 |  |
| Total operating expenses | 5,696 |  |  | (66 | ) |  | 5,630 |  |  | 17,286 |  |  | (294 | ) |  | 16,992 |  |
| Operating loss | (533 | ) |  | 123 |  |  | (410 | ) |  | (3,012 | ) |  | 665 |  |  | (2,347 | ) |
| Interest and other, net | (682 | ) |  | — |  |  | (682 | ) |  | (1,800 | ) |  | 1 |  |  | (1,799 | ) |
| Income (loss) before income taxes | (1,215 | ) |  | 123 |  |  | (1,092 | ) |  | (4,812 | ) |  | 666 |  |  | (4,146 | ) |
| Income tax provision (benefit) | (274 | ) |  | 33 |  |  | (241 | ) |  | (1,510 | ) |  | 157 |  |  | (1,353 | ) |
| Net income (loss) | (941 | ) |  | 90 |  |  | (851 | ) |  | (3,302 | ) |  | 509 |  |  | (2,793 | ) |
| Less: Net loss attributable to non-controlling interests | (4 | ) |  | (1 | ) |  | (5 | ) |  | (85 | ) |  | 41 |  |  | (44 | ) |
| Net income (loss) attributable to Dell Technologies Inc. | $ | (937 | ) |  | $ | 91 |  |  | $ | (846 | ) |  | $ | (3,217 | ) |  | $ | 468 |  |  | $ | (2,749 | ) |
| Earnings (loss) per share attributable to Dell Technologies Inc. - basic: |  |  |  |  |  |  |
| Class V Common Stock - basic | $ | 1.10 |  |  | $ | (0.12 | ) |  | $ | 0.98 |  |  | $ | 2.50 |  |  | $ | 0.08 |  |  | $ | 2.58 |  |
| DHI Group - basic | $ | (2.05 | ) |  | $ | 0.21 |  |  | $ | (1.84 | ) |  | $ | (6.57 | ) |  | $ | 0.79 |  |  | $ | (5.78 | ) |
| Earnings (loss) per share attributable to Dell Technologies Inc. - diluted: |  |  |  |  |  |  |
| Class V Common Stock - diluted | $ | 1.09 |  |  | $ | (0.13 | ) |  | $ | 0.96 |  |  | $ | 2.46 |  |  | $ | 0.08 |  |  | $ | 2.54 |  |
| DHI Group - diluted | $ | (2.05 | ) |  | $ | 0.21 |  |  | $ | (1.84 | ) |  | $ | (6.58 | ) |  | $ | 0.79 |  |  | $ | (5.79 | ) |
  (was, 2018-09-11, similarity 0.9661):
[0001571996-18-000034:note_history:35]
|  | Three Months Ended |  | Six Months Ended |
|  | August 4, 2017 |  | August 4, 2017 |
|  | As Reported (a) |  | Revenue from Contracts with Customers |  | As Recast |  | As Reported (a) |  | Revenue from Contracts with Customers |  | As Recast |
|  | (in millions, except per share amounts) |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Products | $ | 14,355 |  |  | $ | 747 |  |  | $ | 15,102 |  |  | $ | 27,323 |  |  | $ | 1,413 |  |  | $ | 28,736 |  |
| Services | 4,944 |  |  | (525 | ) |  | 4,419 |  |  | 9,792 |  |  | (1,007 | ) |  | 8,785 |  |
| Total net revenue | 19,299 |  |  | 222 |  |  | 19,521 |  |  | 37,115 |  |  | 406 |  |  | 37,521 |  |
| Cost of net revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Products | 12,378 |  |  | 397 |  |  | 12,775 |  |  | 23,837 |  |  | 761 |  |  | 24,598 |  |
| Services | 2,112 |  |  | (334 | ) |  | 1,778 |  |  | 4,167 |  |  | (669 | ) |  | 3,498 |  |
| Total cost of net revenue | 14,490 |  |  | 63 |  |  | 14,553 |  |  | 28,004 |  |  | 92 |  |  | 28,096 |  |
| Gross margin | 4,809 |  |  | 159 |  |  | 4,968 |  |  | 9,111 |  |  | 314 |  |  | 9,425 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |
| Selling, general, and administrative | 4,695 |  |  | (155 | ) |  | 4,540 |  |  | 9,364 |  |  | (228 | ) |  | 9,136 |  |
| Research and development | 1,093 |  |  | — |  |  | 1,093 |  |  | 2,226 |  |  | — |  |  | 2,226 |  |
| Total operating expenses | 5,788 |  |  | (155 | ) |  | 5,633 |  |  | 11,590 |  |  | (228 | ) |  | 11,362 |  |
| Operating loss | (979 | ) |  | 314 |  |  | (665 | ) |  | (2,479 | ) |  | 542 |  |  | (1,937 | ) |
| Interest and other, net | (545 | ) |  | — |  |  | (545 | ) |  | (1,118 | ) |  | 1 |  |  | (1,117 | ) |
| Income (loss) before income taxes | (1,524 | ) |  | 314 |  |  | (1,210 | ) |  | (3,597 | ) |  | 543 |  |  | (3,054 | ) |
| Income tax provision (benefit) | (546 | ) |  | 75 |  |  | (471 | ) |  | (1,236 | ) |  | 124 |  |  | (1,112 | ) |
| Net income (loss) | (978 | ) |  | 239 |  |  | (739 | ) |  | (2,361 | ) |  | 419 |  |  | (1,942 | ) |
| Less: Net income (loss) attributable to non-controlling interests | (32 | ) |  | 25 |  |  | (7 | ) |  | (81 | ) |  | 42 |  |  | (39 | ) |
| Net income (loss) attributable to Dell Technologies Inc. | $ | (946 | ) |  | $ | 214 |  |  | $ | (732 | ) |  | $ | (2,280 | ) |  | $ | 377 |  |  | $ | (1,903 | ) |
| Earnings (loss) per share attributable to Dell Technologies Inc. - basic: |  |  |  |  |  |  |
| Class V Common Stock - basic | $ | 0.83 |  |  | $ | 0.17 |  |  | $ | 1.00 |  |  | $ | 1.40 |  |  | $ | 0.20 |  |  | $ | 1.60 |  |
| DHI Group - basic | $ | (1.97 | ) |  | $ | 0.32 |  |  | $ | (1.65 | ) |  | $ | (4.53 | ) |  | $ | 0.59 |  |  | $ | (3.94 | ) |
| Earnings (loss) per share attributable to Dell Technologies Inc. - diluted: |  |  |  |  |  |  |
| Class V Common Stock - diluted | $ | 0.82 |  |  | $ | 0.18 |  |  | $ | 1.00 |  |  | $ | 1.38 |  |  | $ | 0.21 |  |  | $ | 1.59 |  |
| DHI Group - diluted | $ | (1.97 | ) |  | $ | 0.31 |  |  | $ | (1.66 | ) |  | $ | (4.54 | ) |  | $ | 0.59 |  |  | $ | (3.95 | ) |

- changed (2018-12-10):
[0001571996-18-000044:note_history:36]
| (a) | Amounts as reported in the Company’s Quarterly Report on Form 10-Q for the quarterly period ended November 3, 2017. |
  (was, 2018-09-11, similarity 0.9322):
[0001571996-18-000034:note_history:36]
| (a) | Amounts as reported in the Company's Quarterly Report on Form 10-Q for the quarterly period ended August 4, 2017. |

- changed (2018-12-10):
[0001571996-18-000044:note_history:37]
|  | Nine Months Ended |
|  | November 3, 2017 |
|  | As Reported (a) |  | Classification of Certain Cash Receipts and Cash Payments |  | Statement of Cash Flows, Restricted Cash |  | As Recast |
|  | (in millions) |
| Change in cash from operating activities | $ | 3,679 |  |  | $ | 48 |  |  | $ | 17 |  |  | $ | 3,744 |  |
| Change in cash from investing activities | $ | (1,990 | ) |  | $ | — |  |  | $ | — |  |  | $ | (1,990 | ) |
| Change in cash from financing activities | $ | 496 |  |  | $ | (48 | ) |  | $ | 77 |  |  | $ | 525 |  |
| Change in cash, cash equivalents, and restricted cash | $ | 2,232 |  |  | $ | — |  |  | $ | 94 |  |  | $ | 2,326 |  |
| Cash, cash equivalents, and restricted cash at beginning of the period | 9,474 |  |  | — |  |  | 358 |  |  | 9,832 |  |
| Cash, cash equivalents, and restricted cash at end of the period | $ | 11,706 |  |  | $ | — |  |  | $ | 452 |  |  | $ | 12,158 |  |
  (was, 2018-09-11, similarity 0.9393):
[0001571996-18-000034:note_history:37]
|  | Six Months Ended |
|  | August 4, 2017 |
|  | As Reported (a) |  | Classification of Certain Cash Receipts and Cash Payments |  | Statement of Cash Flows, Restricted Cash |  | As Recast |
|  | (in millions) |
| Change in cash from operating activities | $ | 2,056 |  |  | $ | 32 |  |  | $ | 17 |  |  | $ | 2,105 |  |
| Change in cash from investing activities | $ | (1,290 | ) |  | $ | — |  |  | $ | — |  |  | $ | (1,290 | ) |
| Change in cash from financing activities | $ | (1,075 | ) |  | $ | (32 | ) |  | $ | 30 |  |  | $ | (1,077 | ) |
| Change in cash, cash equivalents, and restricted cash | $ | (261 | ) |  | $ | — |  |  | $ | 47 |  |  | $ | (214 | ) |
| Cash, cash equivalents, and restricted cash at beginning of the period | 9,474 |  |  | — |  |  | 358 |  |  | 9,832 |  |
| Cash, cash equivalents, and restricted cash at end of the period | $ | 9,213 |  |  | $ | — |  |  | $ | 405 |  |  | $ | 9,618 |  |

- changed (2018-12-10):
[0001571996-18-000044:note_history:38]
(a) 
Amounts as reported in the Company’s Quarterly Report on Form 10-Q for the quarterly period ended November 3, 2017.
  (was, 2018-09-11, similarity 0.9043):
[0001571996-18-000034:note_history:38]
| (a) | Amounts as reported in the Company's Quarterly Report on Form 10-Q for the quarterly period ended August 4, 2017. |

- removed (2018-12-10):
[0001571996-18-000034:note_history:39]
These Condensed Consolidated Financial Statements have been prepared in accordance with accounting principles generally accepted in the United States of America ("GAAP").  In the opinion of management, the accompanying Condensed  Consolidated Financial Statements reflect all adjustments of a normal recurring nature considered necessary to fairly state the financial position of Dell Technologies Inc. as of August 3, 2018, the results of its operations and corresponding comprehensive income (loss) for the three and six months ended August 3, 2018 and August 4, 2017, and its cash flows for the six months ended August 3, 2018 and August 4, 2017.  The February 2, 2018 condensed consolidated balance sheet included herein was derived from the Recast Financial Statements.

- removed (2018-12-10):
[0001571996-18-000034:note_history:40]
Pivotal Initial Public Offering — On April 24, 2018, Pivotal completed a registered underwritten initial public offering ("IPO") of its Class A common stock.  The results of Pivotal's operations are included in other businesses.  For more information regarding the Company's ownership of Pivotal, see Note 14 of the Notes to the Condensed Consolidated Financial Statements.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2018-12-10):
[0001571996-18-000044:note_history:41]
NOTE 2 — INTERIM UPDATE TO SUMMARY OF SIGNIFICANT ACCOUNTING POLICIES
  (was, 2018-09-11, similarity 0.9302):
[0001571996-18-000034:note_history:41]
INTERIM UPDATE TO SUMMARY OF SIGNIFICANT ACCOUNTING POLICIES

- changed (2018-12-10):
[0001571996-18-000044:note_history:42]
| (1) | Identify the contract with a customer. The term “contract” refers to the enforceable rights and obligations provided in an agreement between the Company and one or more other parties in exchange for payment. The Company evaluates facts and circumstances regarding sales transactions in order to identify contracts with its customers. An agreement must meet all of the following criteria to qualify as a contract eligible for revenue recognition under the model: (i) the contract must be approved by all parties; (ii) each party’s rights regarding the goods and services to be transferred to the customer can be identified; (iii) the payment terms for the goods and services can be identified; (iv) the customer has the ability and intent to pay and it is probable that the Company will collect substantially all of the consideration to which it will be entitled; and (v) the contract must have commercial substance. Judgment is used in determining the customer’s ability and intent to pay, which is based upon various factors including the customer’s historical payment experience or customer credit and financial information. |
  (was, 2018-09-11, similarity 0.9886):
[0001571996-18-000034:note_history:42]
| (1) | Identify the contract with a customer. The term "contract" refers to the enforceable rights and obligations provided in an agreement between the Company and one or more other parties in exchange for payment. The Company evaluates facts and circumstances regarding sales transactions in order to identify contracts with its customers. An agreement must meet all of the following criteria to qualify as a contract eligible for revenue recognition under the model: (i) the contract must be approved by all parties; (ii) each party's rights regarding the goods and services to be transferred to the customer can be identified; (iii) the payment terms for the goods and services can be identified; (iv) the customer has the ability and intent to pay and it is probable that the Company will collect substantially all of the consideration to which it will be entitled; and (v) the contract must have commercial substance. Judgment is used in determining the customer's ability and intent to pay, which is based upon various factors including the customer's historical payment experience or customer credit and financial information. |

- changed (2018-12-10):
[0001571996-18-000044:note_history:43]
| (2) | Identify the performance obligations in the contract. Distinct promises within a contract are referred to as “performance obligations” and are accounted for as separate units of account. The Company assesses whether each promised good or service is distinct for the purpose of identifying the performance obligations in the contract. This assessment involves subjective determinations and requires management to make judgments about the individual promised goods or services and whether such goods or services are separable from the other aspects of the contractual relationship. Promised goods and services are considered distinct provided that: (i) the customer can benefit from the good or service either on its own or together with other resources that are readily available to the customer (that is, the good or service is capable of being distinct); and (ii) the Company’s promise to transfer the good or service to the customer is separately identifiable from other promises in the contract (that is, the promise to transfer the good or service is distinct within the context of the contract). The Company’s performance obligations consist of a variety of products and services offerings which include: hardware, such as servers, storage, networking, personal computers, workstations, and peripherals; third-party software; proprietary software licenses; support and deployment services, which include hardware support that extends beyond the Company’s standard warranties, software maintenance, and installation; professional services; training; software as a service (“SaaS”); and infrastructure as a service (“IaaS”). |
  (was, 2018-09-11, similarity 0.9896):
[0001571996-18-000034:note_history:43]
| (2) | Identify the performance obligations in the contract. Distinct promises within a contract are referred to as "performance obligations" and are accounted for as separate units of account. The Company assesses whether each promised good or service is distinct for the purpose of identifying the performance obligations in the contract. This assessment involves subjective determinations and requires management to make judgments about the individual promised goods or services and whether such goods or services are separable from the other aspects of the contractual relationship. Promised goods and services are considered distinct provided that: (i) the customer can benefit from the good or service either on its own or together with other resources that are readily available to the customer (that is, the good or service is capable of being distinct); and (ii) the Company's promise to transfer the good or service to the customer is separately identifiable from other promises in the contract (that is, the promise to transfer the good or service is distinct within the context of the contract). The Company's performance obligations consist of a variety of products and services offerings which include: hardware, such as servers, storage, networking, personal computers, workstations, and peripherals; third-party software; proprietary software licenses; support and deployment services, which include hardware support that extends beyond the Company's standard warranties, software maintenance, and installation; professional services; training; software as a service ("SaaS"); and infrastructure as a service ("IaaS"). |

- changed (2018-12-10):
[0001571996-18-000044:note_history:44]
| (4) | Allocate the transaction price to performance obligations in the contract. Many of the Company’s contracts include promises to transfer multiple products and services to a customer, and the transaction price must be allocated to each performance obligation in an amount that depicts the consideration to which the Company expects to be entitled in exchange for transferring the promised goods or services. For these contracts with multiple performance obligations, the transaction price is allocated in proportion to the standalone selling price (“SSP”) of each performance obligation. |
  (was, 2018-09-11, similarity 0.8926):
[0001571996-18-000034:note_history:44]
| (4) | Allocate the transaction price to performance obligations in the contract. Many of the Company’s contracts include promises to transfer multiple products and services to a customer, and the transaction price must be allocated to each performance obligation in an amount that depicts the consideration to which the Company expects to be entitled in exchange for transferring the promised goods or services. For these contracts with multiple performance obligations, the transaction price is allocated in proportion to the standalone selling price ("SSP") of each performance obligation. If the contract contains a single performance obligation, the entire transaction price is allocated to that performance obligation. |

- added (2018-12-10):
[0001571996-18-000044:note_history:45]
If the contract contains a single performance obligation, the entire transaction price is allocated to that performance obligation.

- changed (2018-12-10):
[0001571996-18-000044:note_history:46]
| (5) | Recognize revenue when (or as) the performance obligation is satisfied. Revenue is recognized when obligations under the terms of the contract with the Company’s customer are satisfied. Revenue is recognized either over time or at a point in time, depending on when the underlying products or services are transferred to the customer. Revenue is recognized at a point in time for products upon transfer of control. Revenue is recognized over time for support and deployment services, professional services, training, software support, SaaS, and IaaS. |
  (was, 2018-09-11, similarity 0.9982):
[0001571996-18-000034:note_history:46]
| (5) | Recognize revenue when (or as) the performance obligation is satisfied. Revenue is recognized when obligations under the terms of the contract with the Company's customer are satisfied. Revenue is recognized either over time or at a point in time, depending on when the underlying products or services are transferred to the customer. Revenue is recognized at a point in time for products upon transfer of control. Revenue is recognized over time for support and deployment services, professional services, training, software support, SaaS, and IaaS. |

- changed (2018-12-10):
[0001571996-18-000044:note_history:47]
| • | The Company recognizes revenue equal to the amount it has a right to invoice when the amount corresponds directly with the value to the customer of the Company’s performance to date. |
  (was, 2018-09-11, similarity 0.9947):
[0001571996-18-000034:note_history:47]
| • | The Company recognizes revenue equal to the amount it has a right to invoice when the amount corresponds directly with the value to the customer of the Company's performance to date. |

- changed (2018-12-10):
[0001571996-18-000044:note_history:48]
Services revenue consists of revenue from sales of support services, including hardware support that extends beyond the Company’s standard warranties, software maintenance, and installation; professional services; training; SaaS; and IaaS.  Revenue associated with undelivered performance obligations is deferred and recorded as control is transferred to the customer over time.  Revenue from fixed-price support or maintenance contracts sold for both hardware and software is recognized on a straight-line basis over the period of performance because the Company is required to provide services at any given time.  Other services revenue is recognized when the Company performs the services and the customers receive and consume the benefits.
  (was, 2018-09-11, similarity 0.9986):
[0001571996-18-000034:note_history:48]
Services revenue consists of revenue from sales of support services, including hardware support that extends beyond the Company's standard warranties, software maintenance, and installation; professional services; training; SaaS; and IaaS.  Revenue associated with undelivered performance obligations is deferred and recorded as control is transferred to the customer over time.  Revenue from fixed-price support or maintenance contracts sold for both hardware and software is recognized on a straight-line basis over the period of performance because the Company is required to provide services at any given time.  Other services revenue is recognized when the Company performs the services and the customers receive and consume the benefits.

- changed (2018-12-10):
[0001571996-18-000044:note_history:49]
Disaggregation of Revenue — The Company’s revenue is presented on a disaggregated basis on the Condensed Consolidated Statements of Income (Loss) and in Note 18 of the Notes to the Condensed Consolidated Financial Statements based on an evaluation of disclosures outside of the financial statements, information regularly reviewed by the chief operating decision maker for evaluating the financial performance of operating segments, and other information that is used to evaluate the Company’s financial performance or make resource allocations.  This information includes revenue from products and services, revenue from reportable segments, and revenue by major product categories within the segments.
  (was, 2018-09-11, similarity 0.9971):
[0001571996-18-000034:note_history:49]
Disaggregation of Revenue — The Company's revenue is presented on a disaggregated basis on the Condensed Consolidated Statements of Income (Loss) and in Note 18 of the Notes to the Condensed Consolidated Financial Statements based on an evaluation of disclosures outside of the financial statements, information regularly reviewed by the chief operating decision maker for evaluating the financial performance of operating segments, and other information that is used to evaluate the Company's financial performance or make resource allocations.  This information includes revenue from products and services, revenue from reportable segments, and revenue by major product categories within the segments.

- changed (2018-12-10):
[0001571996-18-000044:note_history:50]
Contract Liabilities — Contract liabilities primarily consist of deferred revenue.  Deferred revenue is recorded when the Company has a right to invoice or payments have been received for undelivered products or services, or in situations where revenue recognition criteria have not been met.  Deferred revenue also represents amounts received in advance for extended warranty services and software maintenance.  Revenue is recognized on these items when the revenue recognition criteria are met, generally resulting in ratable recognition over the contract term.  The Company also has deferred revenue related to undelivered hardware and professional services, consisting of installations and consulting engagements, which are recognized as the Company’s performance obligations under the contract are completed.  See Note 9 of the Notes to the Condensed Consolidated Financial Statements for additional information about deferred revenue.
  (was, 2018-09-11, similarity 0.9989):
[0001571996-18-000034:note_history:50]
Contract Liabilities — Contract liabilities primarily consist of deferred revenue.  Deferred revenue is recorded when the Company has a right to invoice or payments have been received for undelivered products or services, or in situations where revenue recognition criteria have not been met.  Deferred revenue also represents amounts received in advance for extended warranty services and software maintenance.  Revenue is recognized on these items when the revenue recognition criteria are met, generally resulting in ratable recognition over the contract term.  The Company also has deferred revenue related to undelivered hardware and professional services, consisting of installations and consulting engagements, which are recognized as the Company's performance obligations under the contract are completed.  See Note 9 of the Notes to the Condensed Consolidated Financial Statements for additional information about deferred revenue.

- changed (2018-12-10):
[0001571996-18-000044:note_history:51]
Costs to Obtain a Contract — The incremental direct costs of obtaining a contract primarily consist of sales commissions and employer taxes related to commission payments.  The Company has elected, as a practical expedient, to expense as incurred costs to obtain a contract equal to or less than one year in duration.  For contracts greater than one year in duration, the associated costs to obtain a contract are deferred and amortized over the period of contract performance or a longer period, generally the estimated life of the customer relationship, if renewals are expected and the renewal commission is not commensurate with the initial commission.  Deferred costs to obtain a contract are typically amortized over a period of three to seven years, depending on the contract term and expectation of the period of benefit for the costs, which may exceed the contract term.  Amortization expense is recognized on a straight-line basis and included in selling, general, and administrative expenses in the Condensed Consolidated Statements of Income (Loss).
  (was, 2018-09-11, similarity 0.8604):
[0001571996-18-000034:note_history:51]
Costs to Obtain a Contract — The incremental direct costs of obtaining a contract primarily consist of sales commissions and employer taxes related to commission payments.  The Company has elected, as a practical expedient, to expense as incurred costs to obtain a contract equal to or less than one year in duration.  For contracts greater than one year in duration, the associated costs to obtain a contract are deferred and amortized over the period of contract performance or a longer period, generally the estimated life of the customer relationship, if renewals are expected and the renewal commission is not commensurate with the initial commission.  Deferred costs to obtain a contract are typically amortized over a period of three to seven years, depending on the contract term and expectation of the period of benefit for the costs, which may exceed the contract term.  Amortization expense is recognized on a straight-line basis and included in selling, general, and administrative expenses in the Condensed Consolidated Statements of Income (Loss).  The Company periodically reviews these deferred costs to determine whether events or changes in circumstances have occurred that could impact the carrying value or period of benefit of the deferred sales commissions.  There were no material impairment losses for deferred sales commissions during the six months ended August 3, 2018 and August 4, 2017.

- added (2018-12-10):
[0001571996-18-000044:note_history:52]
The Company periodically reviews these deferred costs to determine whether events or changes in circumstances have occurred that could impact the carrying value or period of benefit of the deferred sales commissions.  There were no material impairment losses for deferred sales commissions during the nine months ended November 2, 2018 and November 3, 2017.

- changed (2018-12-10):
[0001571996-18-000044:note_history:53]
Deferred costs to obtain a contract as of November 2, 2018 and February 2, 2018 were $1.1 billion and $0.8 billion, respectively.  Deferred costs to obtain a contract are classified as current assets and other non-current assets on the Condensed Consolidated Statements of Financial Position, based on when the expense is expected to be recognized.  Amortization of costs to obtain a contract during the three months ended November 2, 2018 and November 3, 2017 was $145 million and $89 million, respectively.  Amortization of costs to obtain a contract during the nine months ended November 2, 2018 and November 3, 2017 was $364 million and $204 million, respectively.
  (was, 2018-09-11, similarity 0.8871):
[0001571996-18-000034:note_history:53]
Deferred costs to obtain a contract as of August 3, 2018 and February 2, 2018 were $1.0 billion and $0.8 billion, respectively.  Deferred costs to obtain a contract are classified as current assets and other non-current assets on the Condensed Consolidated Statements of Financial Position, based on when the expense is expected to be recognized.  Amortization of costs to obtain a contract during the three months ended August 3, 2018 and August 4, 2017 was $113 million and $62 million, respectively.  Amortization of costs to obtain a contract during the six months ended August 3, 2018 and August 4, 2017 was $219 million and $115 million, respectively.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2018-12-10):
[0001571996-18-000044:note_history:54]
NOTE 6 — DEBT

- changed (2018-12-10):
[0001571996-18-000044:note_history:55]
The following table summarizes the Company’s outstanding debt as of the dates indicated:
  (was, 2018-09-11, similarity 0.9886):
[0001571996-18-000034:note_history:55]
The following table summarizes the Company's outstanding debt as of the dates indicated:

- changed (2018-12-10):
[0001571996-18-000044:note_history:56]
|  | November 2, 2018 |  | February 2, 2018 |
|  | (in millions) |
| Secured Debt |  |  |  |
| Senior Secured Credit Facilities: |  |  |  |
| 4.31% Term Loan B Facility due September 2023 | $ | 4,950 |  |  | $ | 4,988 |  |
| 4.06% Term Loan A-2 Facility due September 2021 | 4,228 |  |  | 4,394 |  |
| 3.81% Term Loan A-3 Facility due December 2018 | — |  |  | 1,213 |  |
| First Lien Notes: |  |  |  |
| 3.48% due June 2019 | 3,750 |  |  | 3,750 |  |
| 4.42% due June 2021 | 4,500 |  |  | 4,500 |  |
| 5.45% due June 2023 | 3,750 |  |  | 3,750 |  |
| 6.02% due June 2026 | 4,500 |  |  | 4,500 |  |
| 8.10% due July 2036 | 1,500 |  |  | 1,500 |  |
| 8.35% due July 2046 | 2,000 |  |  | 2,000 |  |
| Unsecured Debt |  |  |  |
| Unsecured Notes and Debentures: |  |  |  |
| 5.65% due April 2018 | — |  |  | 500 |  |
| 5.875% due June 2019 | 600 |  |  | 600 |  |
| 4.625% due April 2021 | 400 |  |  | 400 |  |
| 7.10% due April 2028 | 300 |  |  | 300 |  |
| 6.50% due April 2038 | 388 |  |  | 388 |  |
| 5.40% due September 2040 | 264 |  |  | 264 |  |
| Senior Notes: |  |  |  |
| 5.875% due June 2021 | 1,625 |  |  | 1,625 |  |
| 7.125% due June 2024 | 1,625 |  |  | 1,625 |  |
| EMC Notes: |  |  |  |
| 1.875% due June 2018 | — |  |  | 2,500 |  |
| 2.650% due June 2020 | 2,000 |  |  | 2,000 |  |
| 3.375% due June 2023 | 1,000 |  |  | 1,000 |  |
| VMware Notes: |  |  |  |
| 2.30% due August 2020 | 1,250 |  |  | 1,250 |  |
| 2.95% due August 2022 | 1,500 |  |  | 1,500 |  |
| 3.90% due August 2027 | 1,250 |  |  | 1,250 |  |
| DFS Debt (Note 5) | 5,937 |  |  | 4,796 |  |
| Other |  |  |  |
| 4.78% Margin Loan Facility due April 2022 | 2,000 |  |  | 2,000 |  |
| Other | 47 |  |  | 101 |  |
| Total debt, principal amount | $ | 49,364 |  |  | $ | 52,694 |  |
  (was, 2018-09-11, similarity 0.8466):
[0001571996-18-000034:note_history:56]
|  | August 3, 2018 |  | February 2, 2018 |
|  | (in millions) |
| Secured Debt |  |  |  |
| Senior Secured Credit Facilities: |  |  |  |
| 4.08% Term Loan B Facility due September 2023 | $ | 4,963 |  |  | $ | 4,988 |  |
| 3.83% Term Loan A-2 Facility due September 2021 | 4,283 |  |  | 4,394 |  |
| 3.58% Term Loan A-3 Facility due December 2018 | 1,213 |  |  | 1,213 |  |
| First Lien Notes: |  |  |  |
| 3.48% due June 2019 | 3,750 |  |  | 3,750 |  |
| 4.42% due June 2021 | 4,500 |  |  | 4,500 |  |
| 5.45% due June 2023 | 3,750 |  |  | 3,750 |  |
| 6.02% due June 2026 | 4,500 |  |  | 4,500 |  |
| 8.10% due July 2036 | 1,500 |  |  | 1,500 |  |
| 8.35% due July 2046 | 2,000 |  |  | 2,000 |  |
| Unsecured Debt |  |  |  |
| Unsecured Notes and Debentures: |  |  |  |
| 5.65% due April 2018 | — |  |  | 500 |  |
| 5.875% due June 2019 | 600 |  |  | 600 |  |
| 4.625% due April 2021 | 400 |  |  | 400 |  |
| 7.10% due April 2028 | 300 |  |  | 300 |  |
| 6.50% due April 2038 | 388 |  |  | 388 |  |
| 5.40% due September 2040 | 264 |  |  | 264 |  |
| Senior Notes: |  |  |  |
| 5.875% due June 2021 | 1,625 |  |  | 1,625 |  |
| 7.125% due June 2024 | 1,625 |  |  | 1,625 |  |
| EMC Notes: |  |  |  |
| 1.875% due June 2018 | — |  |  | 2,500 |  |
| 2.650% due June 2020 | 2,000 |  |  | 2,000 |  |
| 3.375% due June 2023 | 1,000 |  |  | 1,000 |  |
| VMware Notes: |  |  |  |
| 2.30% due August 2020 | 1,250 |  |  | 1,250 |  |
| 2.95% due August 2022 | 1,500 |  |  | 1,500 |  |
| 3.90% due August 2027 | 1,250 |  |  | 1,250 |  |
| DFS Debt (Note 5) | 5,586 |  |  | 4,796 |  |
| Other |  |  |  |
| 4.59% Margin Loan Facility due April 2022 | 2,000 |  |  | 2,000 |  |
| Other | 56 |  |  | 101 |  |
| Total debt, principal amount | $ | 50,303 |  |  | $ | 52,694 |  |

- changed (2018-12-10):
[0001571996-18-000044:note_history:57]
|  | November 2, 2018 |  | February 2, 2018 |
|  | (in millions) |
| Total debt, principal amount | $ | 49,364 |  |  | $ | 52,694 |  |
| Unamortized discount, net of unamortized premium | (238 | ) |  | (266 | ) |
| Debt issuance costs | (469 | ) |  | (557 | ) |
| Total debt, carrying value | $ | 48,657 |  |  | $ | 51,871 |  |
| Total short-term debt, carrying value | $ | 8,150 |  |  | $ | 7,873 |  |
| Total long-term debt, carrying value | $ | 40,507 |  |  | $ | 43,998 |  |
  (was, 2018-09-11, similarity 0.9828):
[0001571996-18-000034:note_history:57]
|  | August 3, 2018 |  | February 2, 2018 |
|  | (in millions) |
| Total debt, principal amount | $ | 50,303 |  |  | $ | 52,694 |  |
| Unamortized discount, net of unamortized premium | (246 | ) |  | (266 | ) |
| Debt issuance costs | (499 | ) |  | (557 | ) |
| Total debt, carrying value | $ | 49,558 |  |  | $ | 51,871 |  |
| Total short-term debt, carrying value | $ | 9,144 |  |  | $ | 7,873 |  |
| Total long-term debt, carrying value | $ | 40,414 |  |  | $ | 43,998 |  |

- added (2018-12-10):
[0001571996-18-000044:note_history:58]
During the nine months ended November 2, 2018, the Company repaid $3 billion principal amount of its unsecured notes and $1.4 billion principal amount of its term loan facilities, which included approximately $0.2 billion of amortization.   Additionally, during the nine months ended November 2, 2018, the Company issued an additional $1.2 billion, net, in DFS debt to support the expansion of its financing receivables portfolio.

- changed (2018-12-10):
[0001571996-18-000044:note_history:59]
Senior Secured Credit Facilities — The Company has entered into a credit agreement that provides for senior secured credit facilities (the “Senior Secured Credit Facilities”) in the aggregate principal amount of $17.6 billion comprising (a) term loan facilities and (b) a senior secured Revolving Credit Facility, which includes capacity for up to $0.5 billion of letters of credit and for borrowings of up to $0.4 billion under swing-line loans.  As of November 2, 2018, available borrowings under the Revolving Credit Facility totaled $3.3 billion.  The Senior Secured Credit Facilities provide that the borrowers have the right at any time, subject to customary conditions, to request incremental term loans or incremental revolving commitments.
  (was, 2018-09-11, similarity 0.9439):
[0001571996-18-000034:note_history:59]
Senior Secured Credit Facilities — The Company has entered into a credit agreement that provides for senior secured credit facilities (the "Senior Secured Credit Facilities") in the aggregate principal amount of $17.6 billion comprising (a) term loan facilities and (b) a senior secured Revolving Credit Facility, which includes capacity for up to $0.5 billion of letters of credit and for borrowings of up to $0.4 billion under swing-line loans.  As of August 3, 2018, available borrowings under the Revolving Credit Facility totaled $3.3 billion.  The Senior Secured Credit Facilities provide that the borrowers have the right at any time, subject to customary conditions, to request incremental term loans or incremental revolving commitments.

- changed (2018-12-10):
[0001571996-18-000044:note_history:60]
Borrowings under the Senior Secured Credit Facilities bear interest at a rate per annum equal to an applicable margin, plus, at the borrowers’ option, either (a) a base rate, which, under the Term Loan B Facility, is subject to an interest rate floor of 1.75% per annum, and under all other borrowings is subject to an interest rate floor of 0% per annum, or (b) a London interbank offered rate (“LIBOR”), which, under the Term Loan B Facility, is subject to an interest rate floor of 0.75% per annum, and under all other borrowings is subject to an interest rate floor of 0% per annum.  Interest is payable, in the case of loans bearing interest based on LIBOR, at the end of each interest period (but at least every three months), in arrears and, in the case of loans bearing interest based on the base rate, quarterly in arrears.
  (was, 2018-09-11, similarity 0.9903):
[0001571996-18-000034:note_history:60]
Borrowings under the Senior Secured Credit Facilities bear interest at a rate per annum equal to an applicable margin, plus, at the borrowers' option, either (a) a base rate, which, under the Term Loan B Facility, is subject to an interest rate floor of 1.75% per annum, and under all other borrowings is subject to an interest rate floor of 0% per annum, or (b) a London interbank offered rate ("LIBOR"), which, under the Term Loan B Facility, is subject to an interest rate floor of 0.75% per annum, and under all other borrowings is subject to an interest rate floor of 0% per annum.  Interest is payable, in the case of loans bearing interest based on LIBOR, at the end of each interest period (but at least every three months), in arrears and, in the case of loans bearing interest based on the base rate, quarterly in arrears.

- changed (2018-12-10):
[0001571996-18-000044:note_history:61]
The Term Loan A-2 Facility amortizes in equal quarterly installments in aggregate annual amounts equal to 5% of the original principal amount in the first year after the closing date of the refinancing transaction on October 20, 2017, 10% of the original principal amount in each of the second and third years after October 20, 2017, and 70% of the original principal amount in the fourth year after October 20, 2017.  The Term Loan B Facility amortizes in equal quarterly installments in aggregate annual amounts equal to 1% of the original principal amount.  The Revolving Credit Facility has no amortization.  The borrowers may voluntarily repay outstanding loans under the term loan facilities and the Revolving Credit Facility at any time without premium or penalty, other than customary “breakage” costs.  The Term Loan A-3 Facility was fully repaid during the three months ended November 2, 2018.
  (was, 2018-09-11, similarity 0.8288):
[0001571996-18-000034:note_history:61]
The Term Loan A-2 Facility amortizes in equal quarterly installments in aggregate annual amounts equal to 5% of the original principal amount in the first year after the closing date of the refinancing transaction on October 20, 2017, 10% of the original principal amount in each of the second and third years after October 20, 2017, and 70% of the original principal amount in the fourth year after October 20, 2017.  The Term Loan B Facility amortizes in equal quarterly installments in aggregate annual amounts equal to 1% of the original principal amount.  The Term Loan A-3 Facility and the Revolving Credit Facility have no amortization.  The Term Loan A-3 Facility requires the borrowers to prepay outstanding borrowings under these facilities with 100% of the net cash proceeds of certain non-ordinary course asset sales or dispositions.  The borrowers may voluntarily repay outstanding loans under the term loan facilities and the Revolving Credit Facility at any time without premium or penalty, other than customary "breakage" costs.

- changed (2018-12-10):
[0001571996-18-000044:note_history:62]
All obligations of the borrowers under the Senior Secured Credit Facilities and certain swap agreements, cash management arrangements, and certain letters of credit provided by any lender or agent party to the Senior Secured Credit Facilities or any of its affiliates and certain other persons are secured by (a) a first-priority security interest in certain tangible and intangible assets of the borrowers and the guarantors and (b) a first-priority pledge of 100% of the capital stock of the borrowers, Dell Inc., a wholly‑owned subsidiary of the Company (“Dell”), and each wholly-owned material restricted subsidiary of the borrowers and the guarantors, in each case subject to certain thresholds, exceptions, and permitted liens.
  (was, 2018-09-11, similarity 0.9918):
[0001571996-18-000034:note_history:62]
All obligations of the borrowers under the Senior Secured Credit Facilities and certain swap agreements, cash management arrangements, and certain letters of credit provided by any lender or agent party to the Senior Secured Credit Facilities or any of its affiliates and certain other persons are secured by (a) a first-priority security interest in certain tangible and intangible assets of the borrowers and the guarantors and (b) a first-priority pledge of 100% of the capital stock of the borrowers, Dell Inc., a wholly‑owned subsidiary of the Company ("Dell"), and each wholly-owned material restricted subsidiary of the borrowers and the guarantors, in each case subject to certain thresholds, exceptions, and permitted liens.

- added (2018-12-10):
[0001571996-18-000044:note_history:63]
On November 14, 2018, the Company entered into a commitment letter with bank lenders providing for bridge financing in an aggregate principal amount of up to $5.0 billion under the Senior Secured Credit Facilities. See Note 20 of the Notes to the Condensed Consolidated Financial Statements included in this report for further information regarding the bridge financing.

- changed (2018-12-10):
[0001571996-18-000044:note_history:64]
First Lien Notes — The senior secured notes (collectively, the “First Lien Notes”) were issued on June 1, 2016 in an aggregate principal amount of $20.0 billion.  Interest on these borrowings is payable semiannually.  The First Lien Notes are secured, on a pari passu basis with the Senior Secured Credit Facilities, on a first-priority basis by substantially all of the tangible and intangible assets of the issuers and guarantors that secure obligations under the Senior Secured Credit Facilities, including pledges of all capital stock of the issuers, Dell, and certain wholly-owned material subsidiaries of the issuers and the guarantors, subject to certain exceptions.
  (was, 2018-09-11, similarity 0.9729):
[0001571996-18-000034:note_history:64]
First Lien Notes — The senior secured notes (collectively, the "First Lien Notes") were issued on June 1, 2016 in an aggregate principal amount of $20.0 billion.  Interest on these borrowings is payable semiannually.  The First Lien Notes are secured, on a pari passu basis with the Senior Secured Credit Facilities, on a first-priority basis by substantially all of the tangible and intangible assets of the issuers and guarantors that secure obligations under the Senior Secured Credit Facilities, including pledges of all capital stock of the issuers, Dell, and certain wholly-owned material subsidiaries of the issuers and the guarantors, subject to certain exceptions.

- added (2018-12-10):
[0001571996-18-000044:note_history:65]
China Revolving Credit Facility — On October 31, 2017, the Company entered into a credit agreement (the “China Revolving Credit Facility”) with a bank lender for a secured revolving loan facility in an aggregate principal amount not to exceed $500 million at an interest rate of LIBOR plus 0.6% per annum.   The facility expired on October 31, 2018, with no outstanding borrowings due.

- changed (2018-12-10):
[0001571996-18-000044:note_history:66]
Unsecured Notes and Debentures — The Company has outstanding unsecured notes and debentures (collectively, the “Unsecured Notes and Debentures”) that were issued prior to the acquisition of Dell by Dell Technologies Inc. in the going-private transaction that closed in October 2013.  Interest on these borrowings is payable semiannually.
  (was, 2018-09-11, similarity 0.9036):
[0001571996-18-000034:note_history:66]
Unsecured Notes and Debentures — The Company has outstanding unsecured notes and debentures (collectively, the "Unsecured Notes and Debentures") that were issued prior to the acquisition of Dell by Dell Technologies Inc. in the going-private transaction that closed in October 2013.  Interest on these borrowings is payable semiannually.

- changed (2018-12-10):
[0001571996-18-000044:note_history:67]
Senior Notes — The senior unsecured notes (collectively, the “Senior Notes”) were issued on June 22, 2016 in an aggregate principal amount of $3.25 billion.  Interest on these borrowings is payable semiannually.
  (was, 2018-09-11, similarity 0.9307):
[0001571996-18-000034:note_history:67]
Senior Notes — The senior unsecured notes (collectively, the "Senior Notes") were issued on June 22, 2016 in an aggregate principal amount of $3.25 billion.  Interest on these borrowings is payable semiannually.

- changed (2018-12-10):
[0001571996-18-000044:note_history:68]
EMC Notes — On September 7, 2016, EMC had outstanding $2.5 billion aggregate principal amount of its 1.875% Notes due June 2018, which the Company fully repaid during the three months ended August 3, 2018, $2.0 billion aggregate principal amount of its 2.650% Notes due June 2020, and $1.0 billion aggregate principal amount of its 3.375% Notes due June 2023 (collectively, the “EMC Notes”).  Interest on these borrowings is payable semiannually.
  (was, 2018-09-11, similarity 0.8797):
[0001571996-18-000034:note_history:68]
EMC Notes — On September 7, 2016, EMC had outstanding $2.5 billion aggregate principal amount of its 1.875% Notes due June 2018, which the Company fully repaid during the three months ended August 3, 2018, $2.0 billion aggregate principal amount of its 2.650% Notes due June 2020, and $1.0 billion aggregate principal amount of its 3.375% Notes due June 2023 (collectively, the "EMC Notes").  Interest on these borrowings is payable semiannually.  The EMC Notes remain outstanding following the closing of the EMC merger transaction.

- changed (2018-12-10):
[0001571996-18-000044:note_history:69]
VMware Notes — On August 21, 2017, VMware, Inc. completed a public offering of unsecured senior notes in the aggregate amount of $4.0 billion, consisting of outstanding principal due on the following dates: $1.25 billion due August 21, 2020, $1.50 billion due August 21, 2022, and $1.25 billion due August 21, 2027 (collectively, the “VMware Notes”).  The VMware Notes bear interest, payable semiannually, at annual rates of 2.30%, 2.95%, and 3.90%, respectively.  None of the net proceeds of such borrowings will be made available to support the operations or satisfy any corporate purposes of Dell Technologies, other than the operations and corporate purposes of VMware, Inc. and VMware, Inc.’s subsidiaries.
  (was, 2018-09-11, similarity 0.979):
[0001571996-18-000034:note_history:69]
VMware Notes — On August 21, 2017, VMware, Inc. completed a public offering of unsecured senior notes in the aggregate amount of $4.0 billion, consisting of outstanding principal due on the following dates: $1.25 billion due August 21, 2020, $1.50 billion due August 21, 2022, and $1.25 billion due August 21, 2027 (collectively, the "VMware Notes").  The VMware Notes bear interest, payable semiannually, at annual rates of 2.30%, 2.95%, and 3.90%, respectively.  None of the net proceeds of such borrowings will be made available to support the operations or satisfy any corporate purposes of Dell Technologies, other than the operations and corporate purposes of VMware, Inc. and VMware, Inc.’s subsidiaries.

- changed (2018-12-10):
[0001571996-18-000044:note_history:70]
VMware Revolving Credit Facility —  On September 12, 2017, VMware, Inc. entered into an unsecured credit agreement, establishing a revolving credit facility (the “VMware Revolving Credit Facility”), with a syndicate of lenders that provides the company with a borrowing capacity of up to $1.0 billion which may be used for VMware, Inc. general corporate purposes.  Commitments under the VMware Revolving Credit Facility are available for a period of five years, which may be extended, subject to the satisfaction of certain conditions, by up to two one year periods.  The credit agreement contains certain representations, warranties, and covenants.  Commitment fees, interest rates, and other terms of borrowing under the VMware Revolving Credit Facility may vary based on VMware, Inc.’s external credit ratings.  None of the net proceeds of such borrowings will be made available to support the operations or satisfy any corporate purposes of Dell Technologies, other than the operations and corporate purposes of VMware, Inc. and VMware, Inc.’s subsidiaries.  As of November 2, 2018, there were no outstanding borrowings under the VMware Revolving Credit Facility.
  (was, 2018-09-11, similarity 0.9643):
[0001571996-18-000034:note_history:70]
VMware Revolving Credit Facility —  On September 12, 2017, VMware, Inc. entered into an unsecured credit agreement, establishing a revolving credit facility (the "VMware Revolving Credit Facility"), with a syndicate of lenders that provides the company with a borrowing capacity of up to $1.0 billion which may be used for VMware, Inc. general corporate purposes.  Commitments under the VMware Revolving Credit Facility are available for a period of five years, which may be extended, subject to the satisfaction of certain conditions, by up to two one year periods.  The credit agreement contains certain representations, warranties, and covenants.  Commitment fees, interest rates, and other terms of borrowing under the VMware Revolving Credit Facility may vary based on VMware, Inc.’s external credit ratings.  None of the net proceeds of such borrowings will be made available to support the operations or satisfy any corporate purposes of Dell Technologies, other than the operations and corporate purposes of VMware, Inc. and VMware, Inc.’s subsidiaries.  As of August 3, 2018, there were no outstanding borrowings under the VMware Revolving Credit Facility.

- changed (2018-12-10):
[0001571996-18-000044:note_history:71]
Margin Loan Facility — On April 12, 2017, the Company entered into the Margin Loan Facility in an aggregate principal amount of $2.0 billion.  VMW Holdco LLC, a wholly-owned subsidiary of EMC, is the borrower under the Margin Loan Facility, which is secured by 60 million shares of Class B common stock of VMware, Inc. and 20 million shares of Class A common stock of VMware, Inc.  Loans under the Margin Loan Facility bear interest at a rate per annum payable, at the borrower’s option, either at (a) a base rate plus 1.25% per annum or (b) a LIBOR-based rate plus 2.25% per annum.  Interest under the Margin Loan Facility is payable quarterly.
  (was, 2018-09-11, similarity 0.9984):
[0001571996-18-000034:note_history:71]
Margin Loan Facility — On April 12, 2017, the Company entered into the Margin Loan Facility in an aggregate principal amount of $2.0 billion.  VMW Holdco LLC, a wholly-owned subsidiary of EMC, is the borrower under the Margin Loan Facility, which is secured by 60 million shares of Class B common stock of VMware, Inc. and 20 million shares of Class A common stock of VMware, Inc.  Loans under the Margin Loan Facility bear interest at a rate per annum payable, at the borrower's option, either at (a) a base rate plus 1.25% per annum or (b) a LIBOR-based rate plus 2.25% per annum.  Interest under the Margin Loan Facility is payable quarterly.

- changed (2018-12-10):
[0001571996-18-000044:note_history:72]
The Margin Loan Facility will mature in April 2022.  The borrower may voluntarily repay outstanding loans under the Margin Loan Facility at any time without premium or penalty, other than customary “breakage” costs, subject to certain minimum threshold amounts for prepayment.
  (was, 2018-09-11, similarity 0.9926):
[0001571996-18-000034:note_history:72]
The Margin Loan Facility will mature in April 2022.  The borrower may voluntarily repay outstanding loans under the Margin Loan Facility at any time without premium or penalty, other than customary "breakage" costs, subject to certain minimum threshold amounts for prepayment.

- changed (2018-12-10):
[0001571996-18-000044:note_history:73]
Pivotal Revolving Credit Facility — On September 7, 2017, Pivotal entered into a credit agreement (the “Pivotal Revolving Credit Facility”) that provides for a senior secured revolving loan facility in an aggregate principal amount not to exceed $100 million.  The credit facility contains customary representations, warranties, and covenants, including financial covenants.  The credit agreement will expire on September 8, 2020, unless it is terminated earlier.  None of the net proceeds of borrowings under the facility will be made available to support the operations or satisfy any corporate purposes of Dell Technologies, other than the operations and corporate purposes of Pivotal and Pivotal’s subsidiaries.  As of November 2, 2018, there were no outstanding borrowings under the Pivotal Revolving Credit Facility.
  (was, 2018-09-11, similarity 0.9025):
[0001571996-18-000034:note_history:73]
Pivotal Revolving Credit Facility — On September 7, 2017, Pivotal entered into a credit agreement (the "Pivotal Revolving Credit Facility") that provides for a senior secured revolving loan facility in an aggregate principal amount not to exceed $100 million.  The credit facility contains customary representations, warranties, and covenants, including financial covenants.  The credit agreement will expire on September 8, 2020, unless it is terminated earlier.  None of the net proceeds of borrowings under the facility will be made available to support the operations or satisfy any corporate purposes of Dell Technologies, other than the operations and corporate purposes of Pivotal and Pivotal's subsidiaries.  As of August 3, 2018, there were no outstanding borrowings under the Pivotal Revolving Credit Facility.

- changed (2018-12-10):
[0001571996-18-000044:note_history:74]
As of November 2, 2018, aggregate future maturities of the Company’s debt were as follows:
  (was, 2018-09-11, similarity 0.9048):
[0001571996-18-000034:note_history:74]
As of August 3, 2018, aggregate future maturities of the Company's debt were as follows:

- changed (2018-12-10):
[0001571996-18-000044:note_history:75]
|  | Maturities by Fiscal Year |
|  | 2019 (remaining three months) |  | 2020 |  | 2021 |  | 2022 |  | 2023 |  | Thereafter |  | Total |
|  | (in millions) |
| Senior Secured Credit Facilities and First Lien Notes | $ | 124 |  |  | $ | 4,245 |  |  | $ | 371 |  |  | $ | 7,888 |  |  | $ | 62 |  |  | $ | 16,488 |  |  | $ | 29,178 |  |
| Unsecured Notes and Debentures | — |  |  | 600 |  |  | — |  |  | 400 |  |  | — |  |  | 952 |  |  | 1,952 |  |
| Senior Notes and EMC Notes | — |  |  | — |  |  | 2,000 |  |  | 1,625 |  |  | — |  |  | 2,625 |  |  | 6,250 |  |
| VMware Notes | — |  |  | — |  |  | 1,250 |  |  | — |  |  | 1,500 |  |  | 1,250 |  |  | 4,000 |  |
| DFS Debt | 1,011 |  |  | 2,812 |  |  | 1,712 |  |  | 318 |  |  | 75 |  |  | 9 |  |  | 5,937 |  |
| Margin Loan Facility |  |  |  |  |  |  |  |  |  |  |  |  | 2,000 |  |  | — |  |  | 2,000 |  |
| Other | 7 |  |  | 24 |  |  | 16 |  |  | — |  |  | — |  |  | — |  |  | 47 |  |
| Total maturities, principal amount | 1,142 |  |  | 7,681 |  |  | 5,349 |  |  | 10,231 |  |  | 3,637 |  |  | 21,324 |  |  | 49,364 |  |
| Associated carrying value adjustments | — |  |  | (14 | ) |  | (7 | ) |  | (151 | ) |  | (26 | ) |  | (509 | ) |  | (707 | ) |
| Total maturities, carrying value amount | $ | 1,142 |  |  | $ | 7,667 |  |  | $ | 5,342 |  |  | $ | 10,080 |  |  | $ | 3,611 |  |  | $ | 20,815 |  |  | $ | 48,657 |  |
  (was, 2018-09-11, similarity 0.9664):
[0001571996-18-000034:note_history:75]
|  | Maturities by Fiscal Year |
|  | 2019 (remaining six months) |  | 2020 |  | 2021 |  | 2022 |  | 2023 |  | Thereafter |  | Total |
|  | (in millions) |
| Senior Secured Credit Facilities and First Lien Notes | $ | 1,405 |  |  | $ | 4,245 |  |  | $ | 371 |  |  | $ | 7,888 |  |  | $ | 63 |  |  | $ | 16,488 |  |  | $ | 30,460 |  |
| Unsecured Notes and Debentures | — |  |  | 600 |  |  | — |  |  | 400 |  |  | — |  |  | 952 |  |  | 1,952 |  |
| Senior Notes and EMC Notes | — |  |  | — |  |  | 2,000 |  |  | 1,625 |  |  | — |  |  | 2,625 |  |  | 6,250 |  |
| VMware Notes | — |  |  | — |  |  | 1,250 |  |  | — |  |  | 1,500 |  |  | 1,250 |  |  | 4,000 |  |
| DFS Debt | 1,931 |  |  | 1,998 |  |  | 1,459 |  |  | 165 |  |  | 31 |  |  | 1 |  |  | 5,585 |  |
| Margin Loan Facility | — |  |  | — |  |  | — |  |  | — |  |  | 2,000 |  |  | — |  |  | 2,000 |  |
| Other | 16 |  |  | 24 |  |  | 14 |  |  | — |  |  | — |  |  | 2 |  |  | 56 |  |
| Total maturities, principal amount | 3,352 |  |  | 6,867 |  |  | 5,094 |  |  | 10,078 |  |  | 3,594 |  |  | 21,318 |  |  | 50,303 |  |
| Associated carrying value adjustments | (4 | ) |  | (21 | ) |  | (7 | ) |  | (164 | ) |  | (27 | ) |  | (522 | ) |  | (745 | ) |
| Total maturities, carrying value amount | $ | 3,348 |  |  | $ | 6,846 |  |  | $ | 5,087 |  |  | $ | 9,914 |  |  | $ | 3,567 |  |  | $ | 20,796 |  |  | $ | 49,558 |  |

- changed (2018-12-10):
[0001571996-18-000044:note_history:76]
Covenants and Unrestricted Net Assets — The credit agreement for the Senior Secured Credit Facilities contains customary negative covenants that generally limit the ability of Denali Intermediate Inc., a wholly-owned subsidiary of Dell Technologies (“Dell Intermediate”), Dell, and Dell’s and Denali Intermediate’s other restricted subsidiaries to incur debt, create liens, make fundamental changes, enter into asset sales, make certain investments, pay dividends or distribute or redeem certain equity interests, prepay or redeem certain debt, and enter into certain transactions with affiliates.  The indenture governing the Senior Notes contains customary negative covenants that generally limit the ability of Denali Intermediate, Dell, and Dell’s and Denali Intermediate’s other restricted subsidiaries to incur additional debt or issue certain preferred shares, pay dividends on or make other distributions in respect of capital stock or make other restricted payments, make certain investments, sell or transfer certain assets, create liens on certain assets to secure debt, consolidate, merge, sell, or otherwise dispose of all or substantially all assets, enter into certain transactions with affiliates, and designate subsidiaries as unrestricted subsidiaries.
  (was, 2018-09-11, similarity 0.7527):
[0001571996-18-000034:note_history:76]
Covenants and Unrestricted Net Assets — The credit agreement for the Senior Secured Credit Facilities contains customary negative covenants that generally limit the ability of Denali Intermediate Inc., a wholly-owned subsidiary of Dell Technologies ("Dell Intermediate"), Dell, and Dell's and Denali Intermediate's other restricted subsidiaries to incur debt, create liens, make fundamental changes, enter into asset sales, make certain investments, pay dividends or distribute or redeem certain equity interests, prepay or redeem certain debt, and enter into certain transactions with affiliates.  The indenture governing the Senior Notes contains customary negative covenants that generally limit the ability of Denali Intermediate, Dell, and Dell's and Denali Intermediate's other restricted subsidiaries to incur additional debt or issue certain preferred shares, pay dividends on or make other distributions in respect of capital stock or make other restricted payments, make certain investments, sell or transfer certain assets, create liens on certain assets to secure debt, consolidate, merge, sell, or otherwise dispose of all or substantially all assets, enter into certain transactions with affiliates, and designate subsidiaries as unrestricted subsidiaries.  The negative covenants under such credit agreements and indenture are subject to certain exceptions, qualifications, and "baskets."  The indentures governing the First Lien Notes, the Unsecured Notes and Debentures, and the EMC Notes variously impose limitations, subject to specified exceptions, on creating certain liens, entering into sale and lease-back transactions, and entering into certain asset sales.  The foregoing credit agreements and indentures contain customary events of default, including failure to make required payments, failure to comply with covenants, and the occurrence of certain events of bankruptcy and insolvency.

- added (2018-12-10):
[0001571996-18-000044:note_history:77]
The negative covenants under such credit agreements and indenture are subject to certain exceptions, qualifications, and “baskets.”  The indentures governing the First Lien Notes, the Unsecured Notes and Debentures, and the EMC Notes variously impose limitations, subject to specified exceptions, on creating certain liens, entering into sale and lease-back transactions, and entering into certain asset sales.  The foregoing credit agreements and indentures contain customary events of default, including failure to make required payments, failure to comply with covenants, and the occurrence of certain events of bankruptcy and insolvency.

- added (2018-12-10):
[0001571996-18-000044:note_history:78]
As of November 2, 2018, the Company had certain consolidated subsidiaries that were designated as unrestricted subsidiaries for all purposes of the applicable credit agreements and the indentures governing the First Lien Notes and the Senior Notes.

- changed (2018-12-10):
[0001571996-18-000044:note_history:79]
The Term Loan A-2 Facility and the Revolving Credit Facility are subject to a first lien leverage ratio covenant that is tested at the end of each fiscal quarter of Dell with respect to Dell’s preceding four fiscal quarters.  The Company was in compliance with all financial covenants as of November 2, 2018.
  (was, 2018-09-11, similarity 0.9228):
[0001571996-18-000034:note_history:79]
The Term Loan A-2 Facility, the Term Loan A-3 Facility, and the Revolving Credit Facility are subject to a first lien net leverage ratio covenant that is tested at the end of each fiscal quarter of Dell with respect to Dell's preceding four fiscal quarters.  The Company was in compliance with all financial covenants as of August 3, 2018.

- removed (2018-12-10):
[0001571996-18-000034:note_history:80]
DEBT

- removed (2018-12-10):
[0001571996-18-000034:note_history:81]
During the six months ended August 3, 2018, the Company repaid $3 billion principal amount of its unsecured notes and $136 million principal amount of its term loan facilities.  Additionally, during the six months ended August 3, 2018, the Company issued an additional $868 million, net, in DFS debt to support the expansion of its financing receivables portfolio.

- removed (2018-12-10):
[0001571996-18-000034:note_history:82]
China Revolving Credit Facility — On October 31, 2017, the Company entered into a credit agreement (the "China Revolving Credit Facility") with a bank lender for a secured revolving loan facility in an aggregate principal amount not to exceed $500 million.  Borrowings under the China Revolving Credit Facility bear interest at LIBOR plus 0.6% per annum.  The Company may voluntarily repay outstanding loans under the China Revolving Credit Facility at any time without premium or penalty, other than customary "breakage" costs.  The facility will expire on October 31, 2018.  As of August 3, 2018, there were no outstanding borrowings under the China Revolving Credit Facility.

- removed (2018-12-10):
[0001571996-18-000034:note_history:83]
As of August 3, 2018, the Company had certain consolidated subsidiaries that were designated as unrestricted subsidiaries for all purposes of the applicable credit agreements and the indentures governing the First Lien Notes and the Senior Notes.


## us-gaap:ScheduleOfCarryingValuesAndEstimatedFairValuesOfDebtInstrumentsTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2018-12-10):
[0001571996-18-000044:note_history:84]
Carrying Value and Estimated Fair Value of Outstanding Debt — The following table summarizes the carrying value and estimated fair value of the Company’s outstanding debt as described in Note 6 of the Notes to the Condensed Consolidated Financial Statements, including the current portion, as of the dates indicated:

- changed (2018-12-10):
[0001571996-18-000044:note_history:85]
|  | November 2, 2018 |  | February 2, 2018 |
|  | Carrying Value |  | Fair Value |  | Carrying Value |  | Fair Value |
|  | (in billions) |
| Senior Secured Credit Facilities | $ | 9.0 |  |  | $ | 9.2 |  |  | $ | 10.4 |  |  | $ | 10.6 |  |
| First Lien Notes | $ | 19.8 |  |  | $ | 20.9 |  |  | $ | 19.7 |  |  | $ | 21.9 |  |
| Unsecured Notes and Debentures | $ | 1.8 |  |  | $ | 1.9 |  |  | $ | 2.3 |  |  | $ | 2.5 |  |
| Senior Notes | $ | 3.1 |  |  | $ | 3.4 |  |  | $ | 3.1 |  |  | $ | 3.4 |  |
| EMC Notes | $ | 3.0 |  |  | $ | 2.9 |  |  | $ | 5.5 |  |  | $ | 5.4 |  |
| VMware Notes | $ | 4.0 |  |  | $ | 3.8 |  |  | $ | 4.0 |  |  | $ | 3.9 |  |
| Margin Loan Facility | $ | 2.0 |  |  | $ | 2.0 |  |  | $ | 2.0 |  |  | $ | 2.0 |  |
  (was, 2018-09-11, similarity 0.9886):
[0001571996-18-000034:note_history:85]
|  | August 3, 2018 |  | February 2, 2018 |
|  | Carrying Value |  | Fair Value |  | Carrying Value |  | Fair Value |
|  | (in billions) |
| Senior Secured Credit Facilities | $ | 10.3 |  |  | $ | 10.5 |  |  | $ | 10.4 |  |  | $ | 10.6 |  |
| First Lien Notes | $ | 19.7 |  |  | $ | 21.3 |  |  | $ | 19.7 |  |  | $ | 21.9 |  |
| Unsecured Notes and Debentures | $ | 1.8 |  |  | $ | 2.0 |  |  | $ | 2.3 |  |  | $ | 2.5 |  |
| Senior Notes | $ | 3.1 |  |  | $ | 3.4 |  |  | $ | 3.1 |  |  | $ | 3.4 |  |
| EMC Notes | $ | 3.0 |  |  | $ | 2.9 |  |  | $ | 5.5 |  |  | $ | 5.4 |  |
| VMware Notes | $ | 4.0 |  |  | $ | 3.9 |  |  | $ | 4.0 |  |  | $ | 3.9 |  |
| Margin Loan Facility | $ | 2.0 |  |  | $ | 2.0 |  |  | $ | 2.0 |  |  | $ | 2.0 |  |

- removed (2018-12-10):
[0001571996-18-000034:note_history:86]
The following table summarizes the carrying value and estimated fair value of the Company's outstanding debt as described in Note 6 of the Notes to the Condensed Consolidated Financial Statements, including the current portion, as of the dates indicated:


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2018-12-10):
[0001571996-18-000044:note_history:87]
The following table summarizes DFS debt as of the periods indicated.  The table excludes the allocated portion of the Company’s other borrowings, which represents the additional amount considered to fund the DFS business.
  (was, 2018-09-11, similarity 0.9955):
[0001571996-18-000034:note_history:87]
The following table summarizes DFS debt as of the periods indicated.  The table excludes the allocated portion of the Company's other borrowings, which represents the additional amount considered to fund the DFS business.

- changed (2018-12-10):
[0001571996-18-000044:note_history:88]
|  | November 2, 2018 |  | February 2, 2018 |
|  | (in millions) |
| DFS U.S. debt |  |  |  |
| Securitization facilities | $ | 1,649 |  |  | $ | 1,498 |  |
| Fixed-term securitization offerings | 2,683 |  |  | 2,034 |  |
| Other | 186 |  |  | 32 |  |
| Total DFS U.S. debt | 4,518 |  |  | 3,564 |  |
| DFS international debt |  |  |  |
| Securitization facility | 524 |  |  | 404 |  |
| Other structured facilities | 702 |  |  | 628 |  |
| Note payable | 193 |  |  | 200 |  |
| Total DFS international debt | 1,419 |  |  | 1,232 |  |
| Total DFS debt | $ | 5,937 |  |  | $ | 4,796 |  |
| Total short-term DFS debt | $ | 3,288 |  |  | $ | 3,327 |  |
| Total long-term DFS debt | $ | 2,649 |  |  | $ | 1,469 |  |
  (was, 2018-09-11, similarity 0.9881):
[0001571996-18-000034:note_history:88]
|  | August 3, 2018 |  | February 2, 2018 |
|  | (in millions) |
| DFS U.S. debt |  |  |  |
| Securitization facilities | $ | 1,782 |  |  | $ | 1,498 |  |
| Fixed-term securitization offerings | 2,305 |  |  | 2,034 |  |
| Other | 132 |  |  | 32 |  |
| Total DFS U.S. debt | 4,219 |  |  | 3,564 |  |
| DFS international debt |  |  |  |
| Securitization facility | 497 |  |  | 404 |  |
| Other structured facilities | 670 |  |  | 628 |  |
| Note payable | 200 |  |  | 200 |  |
| Total DFS international debt | 1,367 |  |  | 1,232 |  |
| Total DFS debt | $ | 5,586 |  |  | $ | 4,796 |  |
| Total short-term DFS debt | $ | 3,130 |  |  | $ | 3,327 |  |
| Total long-term DFS debt | $ | 2,456 |  |  | $ | 1,469 |  |

- changed (2018-12-10):
[0001571996-18-000044:note_history:89]
The following table summarizes the Company’s outstanding debt as of the dates indicated:
  (was, 2018-09-11, similarity 0.9886):
[0001571996-18-000034:note_history:89]
The following table summarizes the Company's outstanding debt as of the dates indicated:

- changed (2018-12-10):
[0001571996-18-000044:note_history:90]
|  | November 2, 2018 |  | February 2, 2018 |
|  | (in millions) |
| Secured Debt |  |  |  |
| Senior Secured Credit Facilities: |  |  |  |
| 4.31% Term Loan B Facility due September 2023 | $ | 4,950 |  |  | $ | 4,988 |  |
| 4.06% Term Loan A-2 Facility due September 2021 | 4,228 |  |  | 4,394 |  |
| 3.81% Term Loan A-3 Facility due December 2018 | — |  |  | 1,213 |  |
| First Lien Notes: |  |  |  |
| 3.48% due June 2019 | 3,750 |  |  | 3,750 |  |
| 4.42% due June 2021 | 4,500 |  |  | 4,500 |  |
| 5.45% due June 2023 | 3,750 |  |  | 3,750 |  |
| 6.02% due June 2026 | 4,500 |  |  | 4,500 |  |
| 8.10% due July 2036 | 1,500 |  |  | 1,500 |  |
| 8.35% due July 2046 | 2,000 |  |  | 2,000 |  |
| Unsecured Debt |  |  |  |
| Unsecured Notes and Debentures: |  |  |  |
| 5.65% due April 2018 | — |  |  | 500 |  |
| 5.875% due June 2019 | 600 |  |  | 600 |  |
| 4.625% due April 2021 | 400 |  |  | 400 |  |
| 7.10% due April 2028 | 300 |  |  | 300 |  |
| 6.50% due April 2038 | 388 |  |  | 388 |  |
| 5.40% due September 2040 | 264 |  |  | 264 |  |
| Senior Notes: |  |  |  |
| 5.875% due June 2021 | 1,625 |  |  | 1,625 |  |
| 7.125% due June 2024 | 1,625 |  |  | 1,625 |  |
| EMC Notes: |  |  |  |
| 1.875% due June 2018 | — |  |  | 2,500 |  |
| 2.650% due June 2020 | 2,000 |  |  | 2,000 |  |
| 3.375% due June 2023 | 1,000 |  |  | 1,000 |  |
| VMware Notes: |  |  |  |
| 2.30% due August 2020 | 1,250 |  |  | 1,250 |  |
| 2.95% due August 2022 | 1,500 |  |  | 1,500 |  |
| 3.90% due August 2027 | 1,250 |  |  | 1,250 |  |
| DFS Debt (Note 5) | 5,937 |  |  | 4,796 |  |
| Other |  |  |  |
| 4.78% Margin Loan Facility due April 2022 | 2,000 |  |  | 2,000 |  |
| Other | 47 |  |  | 101 |  |
| Total debt, principal amount | $ | 49,364 |  |  | $ | 52,694 |  |
  (was, 2018-09-11, similarity 0.8466):
[0001571996-18-000034:note_history:90]
|  | August 3, 2018 |  | February 2, 2018 |
|  | (in millions) |
| Secured Debt |  |  |  |
| Senior Secured Credit Facilities: |  |  |  |
| 4.08% Term Loan B Facility due September 2023 | $ | 4,963 |  |  | $ | 4,988 |  |
| 3.83% Term Loan A-2 Facility due September 2021 | 4,283 |  |  | 4,394 |  |
| 3.58% Term Loan A-3 Facility due December 2018 | 1,213 |  |  | 1,213 |  |
| First Lien Notes: |  |  |  |
| 3.48% due June 2019 | 3,750 |  |  | 3,750 |  |
| 4.42% due June 2021 | 4,500 |  |  | 4,500 |  |
| 5.45% due June 2023 | 3,750 |  |  | 3,750 |  |
| 6.02% due June 2026 | 4,500 |  |  | 4,500 |  |
| 8.10% due July 2036 | 1,500 |  |  | 1,500 |  |
| 8.35% due July 2046 | 2,000 |  |  | 2,000 |  |
| Unsecured Debt |  |  |  |
| Unsecured Notes and Debentures: |  |  |  |
| 5.65% due April 2018 | — |  |  | 500 |  |
| 5.875% due June 2019 | 600 |  |  | 600 |  |
| 4.625% due April 2021 | 400 |  |  | 400 |  |
| 7.10% due April 2028 | 300 |  |  | 300 |  |
| 6.50% due April 2038 | 388 |  |  | 388 |  |
| 5.40% due September 2040 | 264 |  |  | 264 |  |
| Senior Notes: |  |  |  |
| 5.875% due June 2021 | 1,625 |  |  | 1,625 |  |
| 7.125% due June 2024 | 1,625 |  |  | 1,625 |  |
| EMC Notes: |  |  |  |
| 1.875% due June 2018 | — |  |  | 2,500 |  |
| 2.650% due June 2020 | 2,000 |  |  | 2,000 |  |
| 3.375% due June 2023 | 1,000 |  |  | 1,000 |  |
| VMware Notes: |  |  |  |
| 2.30% due August 2020 | 1,250 |  |  | 1,250 |  |
| 2.95% due August 2022 | 1,500 |  |  | 1,500 |  |
| 3.90% due August 2027 | 1,250 |  |  | 1,250 |  |
| DFS Debt (Note 5) | 5,586 |  |  | 4,796 |  |
| Other |  |  |  |
| 4.59% Margin Loan Facility due April 2022 | 2,000 |  |  | 2,000 |  |
| Other | 56 |  |  | 101 |  |
| Total debt, principal amount | $ | 50,303 |  |  | $ | 52,694 |  |

- changed (2018-12-10):
[0001571996-18-000044:note_history:91]
|  | November 2, 2018 |  | February 2, 2018 |
|  | (in millions) |
| Total debt, principal amount | $ | 49,364 |  |  | $ | 52,694 |  |
| Unamortized discount, net of unamortized premium | (238 | ) |  | (266 | ) |
| Debt issuance costs | (469 | ) |  | (557 | ) |
| Total debt, carrying value | $ | 48,657 |  |  | $ | 51,871 |  |
| Total short-term debt, carrying value | $ | 8,150 |  |  | $ | 7,873 |  |
| Total long-term debt, carrying value | $ | 40,507 |  |  | $ | 43,998 |  |
  (was, 2018-09-11, similarity 0.9828):
[0001571996-18-000034:note_history:91]
|  | August 3, 2018 |  | February 2, 2018 |
|  | (in millions) |
| Total debt, principal amount | $ | 50,303 |  |  | $ | 52,694 |  |
| Unamortized discount, net of unamortized premium | (246 | ) |  | (266 | ) |
| Debt issuance costs | (499 | ) |  | (557 | ) |
| Total debt, carrying value | $ | 49,558 |  |  | $ | 51,871 |  |
| Total short-term debt, carrying value | $ | 9,144 |  |  | $ | 7,873 |  |
| Total long-term debt, carrying value | $ | 40,414 |  |  | $ | 43,998 |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2018-12-10):
[0001571996-18-000044:note_history:92]
As of November 2, 2018, aggregate future maturities of the Company’s debt were as follows:
  (was, 2018-09-11, similarity 0.9048):
[0001571996-18-000034:note_history:92]
As of August 3, 2018, aggregate future maturities of the Company's debt were as follows:

- changed (2018-12-10):
[0001571996-18-000044:note_history:93]
|  | Maturities by Fiscal Year |
|  | 2019 (remaining three months) |  | 2020 |  | 2021 |  | 2022 |  | 2023 |  | Thereafter |  | Total |
|  | (in millions) |
| Senior Secured Credit Facilities and First Lien Notes | $ | 124 |  |  | $ | 4,245 |  |  | $ | 371 |  |  | $ | 7,888 |  |  | $ | 62 |  |  | $ | 16,488 |  |  | $ | 29,178 |  |
| Unsecured Notes and Debentures | — |  |  | 600 |  |  | — |  |  | 400 |  |  | — |  |  | 952 |  |  | 1,952 |  |
| Senior Notes and EMC Notes | — |  |  | — |  |  | 2,000 |  |  | 1,625 |  |  | — |  |  | 2,625 |  |  | 6,250 |  |
| VMware Notes | — |  |  | — |  |  | 1,250 |  |  | — |  |  | 1,500 |  |  | 1,250 |  |  | 4,000 |  |
| DFS Debt | 1,011 |  |  | 2,812 |  |  | 1,712 |  |  | 318 |  |  | 75 |  |  | 9 |  |  | 5,937 |  |
| Margin Loan Facility |  |  |  |  |  |  |  |  |  |  |  |  | 2,000 |  |  | — |  |  | 2,000 |  |
| Other | 7 |  |  | 24 |  |  | 16 |  |  | — |  |  | — |  |  | — |  |  | 47 |  |
| Total maturities, principal amount | 1,142 |  |  | 7,681 |  |  | 5,349 |  |  | 10,231 |  |  | 3,637 |  |  | 21,324 |  |  | 49,364 |  |
| Associated carrying value adjustments | — |  |  | (14 | ) |  | (7 | ) |  | (151 | ) |  | (26 | ) |  | (509 | ) |  | (707 | ) |
| Total maturities, carrying value amount | $ | 1,142 |  |  | $ | 7,667 |  |  | $ | 5,342 |  |  | $ | 10,080 |  |  | $ | 3,611 |  |  | $ | 20,815 |  |  | $ | 48,657 |  |
  (was, 2018-09-11, similarity 0.9664):
[0001571996-18-000034:note_history:93]
|  | Maturities by Fiscal Year |
|  | 2019 (remaining six months) |  | 2020 |  | 2021 |  | 2022 |  | 2023 |  | Thereafter |  | Total |
|  | (in millions) |
| Senior Secured Credit Facilities and First Lien Notes | $ | 1,405 |  |  | $ | 4,245 |  |  | $ | 371 |  |  | $ | 7,888 |  |  | $ | 63 |  |  | $ | 16,488 |  |  | $ | 30,460 |  |
| Unsecured Notes and Debentures | — |  |  | 600 |  |  | — |  |  | 400 |  |  | — |  |  | 952 |  |  | 1,952 |  |
| Senior Notes and EMC Notes | — |  |  | — |  |  | 2,000 |  |  | 1,625 |  |  | — |  |  | 2,625 |  |  | 6,250 |  |
| VMware Notes | — |  |  | — |  |  | 1,250 |  |  | — |  |  | 1,500 |  |  | 1,250 |  |  | 4,000 |  |
| DFS Debt | 1,931 |  |  | 1,998 |  |  | 1,459 |  |  | 165 |  |  | 31 |  |  | 1 |  |  | 5,585 |  |
| Margin Loan Facility | — |  |  | — |  |  | — |  |  | — |  |  | 2,000 |  |  | — |  |  | 2,000 |  |
| Other | 16 |  |  | 24 |  |  | 14 |  |  | — |  |  | — |  |  | 2 |  |  | 56 |  |
| Total maturities, principal amount | 3,352 |  |  | 6,867 |  |  | 5,094 |  |  | 10,078 |  |  | 3,594 |  |  | 21,318 |  |  | 50,303 |  |
| Associated carrying value adjustments | (4 | ) |  | (21 | ) |  | (7 | ) |  | (164 | ) |  | (27 | ) |  | (522 | ) |  | (745 | ) |
| Total maturities, carrying value amount | $ | 3,348 |  |  | $ | 6,846 |  |  | $ | 5,087 |  |  | $ | 9,914 |  |  | $ | 3,567 |  |  | $ | 20,796 |  |  | $ | 49,558 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2018-12-10):
[0001571996-18-000044:note_history:94]
|  | Three Months Ended |  | Nine Months Ended |
|  | November 2, 2018 |  | November 3, 2017 |  | November 2, 2018 |  | November 3, 2017 |
|  | (in millions) |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |
| Infrastructure Solutions Group: |  |  |  |  |  |  |  |
| Servers and networking | $ | 5,054 |  |  | $ | 3,875 |  |  | $ | 14,700 |  |  | $ | 10,908 |  |
| Storage | 3,883 |  |  | 3,660 |  |  | 12,131 |  |  | 11,055 |  |
| Total ISG net revenue | 8,937 |  |  | 7,535 |  |  | 26,831 |  |  | 21,963 |  |
| Client Solutions Group: |  |  |  |  |  |  |  |
| Commercial | 7,613 |  |  | 6,778 |  |  | 23,085 |  |  | 20,327 |  |
| Consumer | 3,292 |  |  | 3,051 |  |  | 9,219 |  |  | 8,416 |  |
| Total CSG net revenue | 10,905 |  |  | 9,829 |  |  | 32,304 |  |  | 28,743 |  |
| VMware: |  |  |  |  |  |  |  |
| Total VMware net revenue | 2,229 |  |  | 1,933 |  |  | 6,451 |  |  | 5,735 |  |
| Total segment net revenue | $ | 22,071 |  |  | $ | 19,297 |  |  | $ | 65,586 |  |  | $ | 56,441 |  |
  (was, 2018-09-11, similarity 0.9206):
[0001571996-18-000034:note_history:94]
|  | Three Months Ended |  | Six Months Ended |
|  | August 3, 2018 |  | August 4, 2017 |  | August 3, 2018 |  | August 4, 2017 |
|  | (in millions) |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |
| Infrastructure Solutions Group: |  |  |  |  |  |  |  |
| Servers and networking | $ | 5,061 |  |  | $ | 3,777 |  |  | $ | 9,646 |  |  | $ | 7,033 |  |
| Storage | 4,166 |  |  | 3,690 |  |  | 8,248 |  |  | 7,395 |  |
| Total ISG net revenue | 9,227 |  |  | 7,467 |  |  | 17,894 |  |  | 14,428 |  |
| Client Solutions Group: |  |  |  |  |  |  |  |
| Commercial | 8,109 |  |  | 7,207 |  |  | 15,472 |  |  | 13,549 |  |
| Consumer | 3,019 |  |  | 2,659 |  |  | 5,927 |  |  | 5,365 |  |
| Total CSG net revenue | 11,128 |  |  | 9,866 |  |  | 21,399 |  |  | 18,914 |  |
| VMware: |  |  |  |  |  |  |  |
| Total VMware net revenue | 2,194 |  |  | 1,984 |  |  | 4,222 |  |  | 3,802 |  |
| Total segment net revenue | $ | 22,549 |  |  | $ | 19,317 |  |  | $ | 43,515 |  |  | $ | 37,144 |  |


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2018-12-10):
[0001571996-18-000044:note_history:95]
| (1) | Identify the contract with a customer. The term “contract” refers to the enforceable rights and obligations provided in an agreement between the Company and one or more other parties in exchange for payment. The Company evaluates facts and circumstances regarding sales transactions in order to identify contracts with its customers. An agreement must meet all of the following criteria to qualify as a contract eligible for revenue recognition under the model: (i) the contract must be approved by all parties; (ii) each party’s rights regarding the goods and services to be transferred to the customer can be identified; (iii) the payment terms for the goods and services can be identified; (iv) the customer has the ability and intent to pay and it is probable that the Company will collect substantially all of the consideration to which it will be entitled; and (v) the contract must have commercial substance. Judgment is used in determining the customer’s ability and intent to pay, which is based upon various factors including the customer’s historical payment experience or customer credit and financial information. |
  (was, 2018-09-11, similarity 0.9886):
[0001571996-18-000034:note_history:95]
| (1) | Identify the contract with a customer. The term "contract" refers to the enforceable rights and obligations provided in an agreement between the Company and one or more other parties in exchange for payment. The Company evaluates facts and circumstances regarding sales transactions in order to identify contracts with its customers. An agreement must meet all of the following criteria to qualify as a contract eligible for revenue recognition under the model: (i) the contract must be approved by all parties; (ii) each party's rights regarding the goods and services to be transferred to the customer can be identified; (iii) the payment terms for the goods and services can be identified; (iv) the customer has the ability and intent to pay and it is probable that the Company will collect substantially all of the consideration to which it will be entitled; and (v) the contract must have commercial substance. Judgment is used in determining the customer's ability and intent to pay, which is based upon various factors including the customer's historical payment experience or customer credit and financial information. |

- changed (2018-12-10):
[0001571996-18-000044:note_history:96]
| (2) | Identify the performance obligations in the contract. Distinct promises within a contract are referred to as “performance obligations” and are accounted for as separate units of account. The Company assesses whether each promised good or service is distinct for the purpose of identifying the performance obligations in the contract. This assessment involves subjective determinations and requires management to make judgments about the individual promised goods or services and whether such goods or services are separable from the other aspects of the contractual relationship. Promised goods and services are considered distinct provided that: (i) the customer can benefit from the good or service either on its own or together with other resources that are readily available to the customer (that is, the good or service is capable of being distinct); and (ii) the Company’s promise to transfer the good or service to the customer is separately identifiable from other promises in the contract (that is, the promise to transfer the good or service is distinct within the context of the contract). The Company’s performance obligations consist of a variety of products and services offerings which include: hardware, such as servers, storage, networking, personal computers, workstations, and peripherals; third-party software; proprietary software licenses; support and deployment services, which include hardware support that extends beyond the Company’s standard warranties, software maintenance, and installation; professional services; training; software as a service (“SaaS”); and infrastructure as a service (“IaaS”). |
  (was, 2018-09-11, similarity 0.9896):
[0001571996-18-000034:note_history:96]
| (2) | Identify the performance obligations in the contract. Distinct promises within a contract are referred to as "performance obligations" and are accounted for as separate units of account. The Company assesses whether each promised good or service is distinct for the purpose of identifying the performance obligations in the contract. This assessment involves subjective determinations and requires management to make judgments about the individual promised goods or services and whether such goods or services are separable from the other aspects of the contractual relationship. Promised goods and services are considered distinct provided that: (i) the customer can benefit from the good or service either on its own or together with other resources that are readily available to the customer (that is, the good or service is capable of being distinct); and (ii) the Company's promise to transfer the good or service to the customer is separately identifiable from other promises in the contract (that is, the promise to transfer the good or service is distinct within the context of the contract). The Company's performance obligations consist of a variety of products and services offerings which include: hardware, such as servers, storage, networking, personal computers, workstations, and peripherals; third-party software; proprietary software licenses; support and deployment services, which include hardware support that extends beyond the Company's standard warranties, software maintenance, and installation; professional services; training; software as a service ("SaaS"); and infrastructure as a service ("IaaS"). |

- changed (2018-12-10):
[0001571996-18-000044:note_history:97]
| (4) | Allocate the transaction price to performance obligations in the contract. Many of the Company’s contracts include promises to transfer multiple products and services to a customer, and the transaction price must be allocated to each performance obligation in an amount that depicts the consideration to which the Company expects to be entitled in exchange for transferring the promised goods or services. For these contracts with multiple performance obligations, the transaction price is allocated in proportion to the standalone selling price (“SSP”) of each performance obligation. |
  (was, 2018-09-11, similarity 0.8926):
[0001571996-18-000034:note_history:97]
| (4) | Allocate the transaction price to performance obligations in the contract. Many of the Company’s contracts include promises to transfer multiple products and services to a customer, and the transaction price must be allocated to each performance obligation in an amount that depicts the consideration to which the Company expects to be entitled in exchange for transferring the promised goods or services. For these contracts with multiple performance obligations, the transaction price is allocated in proportion to the standalone selling price ("SSP") of each performance obligation. If the contract contains a single performance obligation, the entire transaction price is allocated to that performance obligation. |

- added (2018-12-10):
[0001571996-18-000044:note_history:98]
If the contract contains a single performance obligation, the entire transaction price is allocated to that performance obligation.

- changed (2018-12-10):
[0001571996-18-000044:note_history:99]
| (5) | Recognize revenue when (or as) the performance obligation is satisfied. Revenue is recognized when obligations under the terms of the contract with the Company’s customer are satisfied. Revenue is recognized either over time or at a point in time, depending on when the underlying products or services are transferred to the customer. Revenue is recognized at a point in time for products upon transfer of control. Revenue is recognized over time for support and deployment services, professional services, training, software support, SaaS, and IaaS. |
  (was, 2018-09-11, similarity 0.9982):
[0001571996-18-000034:note_history:99]
| (5) | Recognize revenue when (or as) the performance obligation is satisfied. Revenue is recognized when obligations under the terms of the contract with the Company's customer are satisfied. Revenue is recognized either over time or at a point in time, depending on when the underlying products or services are transferred to the customer. Revenue is recognized at a point in time for products upon transfer of control. Revenue is recognized over time for support and deployment services, professional services, training, software support, SaaS, and IaaS. |

- changed (2018-12-10):
[0001571996-18-000044:note_history:100]
| • | The Company recognizes revenue equal to the amount it has a right to invoice when the amount corresponds directly with the value to the customer of the Company’s performance to date. |
  (was, 2018-09-11, similarity 0.9947):
[0001571996-18-000034:note_history:100]
| • | The Company recognizes revenue equal to the amount it has a right to invoice when the amount corresponds directly with the value to the customer of the Company's performance to date. |

- changed (2018-12-10):
[0001571996-18-000044:note_history:101]
Services revenue consists of revenue from sales of support services, including hardware support that extends beyond the Company’s standard warranties, software maintenance, and installation; professional services; training; SaaS; and IaaS.  Revenue associated with undelivered performance obligations is deferred and recorded as control is transferred to the customer over time.  Revenue from fixed-price support or maintenance contracts sold for both hardware and software is recognized on a straight-line basis over the period of performance because the Company is required to provide services at any given time.  Other services revenue is recognized when the Company performs the services and the customers receive and consume the benefits.
  (was, 2018-09-11, similarity 0.9986):
[0001571996-18-000034:note_history:101]
Services revenue consists of revenue from sales of support services, including hardware support that extends beyond the Company's standard warranties, software maintenance, and installation; professional services; training; SaaS; and IaaS.  Revenue associated with undelivered performance obligations is deferred and recorded as control is transferred to the customer over time.  Revenue from fixed-price support or maintenance contracts sold for both hardware and software is recognized on a straight-line basis over the period of performance because the Company is required to provide services at any given time.  Other services revenue is recognized when the Company performs the services and the customers receive and consume the benefits.

- changed (2018-12-10):
[0001571996-18-000044:note_history:102]
Disaggregation of Revenue — The Company’s revenue is presented on a disaggregated basis on the Condensed Consolidated Statements of Income (Loss) and in Note 18 of the Notes to the Condensed Consolidated Financial Statements based on an evaluation of disclosures outside of the financial statements, information regularly reviewed by the chief operating decision maker for evaluating the financial performance of operating segments, and other information that is used to evaluate the Company’s financial performance or make resource allocations.  This information includes revenue from products and services, revenue from reportable segments, and revenue by major product categories within the segments.
  (was, 2018-09-11, similarity 0.9971):
[0001571996-18-000034:note_history:102]
Disaggregation of Revenue — The Company's revenue is presented on a disaggregated basis on the Condensed Consolidated Statements of Income (Loss) and in Note 18 of the Notes to the Condensed Consolidated Financial Statements based on an evaluation of disclosures outside of the financial statements, information regularly reviewed by the chief operating decision maker for evaluating the financial performance of operating segments, and other information that is used to evaluate the Company's financial performance or make resource allocations.  This information includes revenue from products and services, revenue from reportable segments, and revenue by major product categories within the segments.

- changed (2018-12-10):
[0001571996-18-000044:note_history:103]
Contract Liabilities — Contract liabilities primarily consist of deferred revenue.  Deferred revenue is recorded when the Company has a right to invoice or payments have been received for undelivered products or services, or in situations where revenue recognition criteria have not been met.  Deferred revenue also represents amounts received in advance for extended warranty services and software maintenance.  Revenue is recognized on these items when the revenue recognition criteria are met, generally resulting in ratable recognition over the contract term.  The Company also has deferred revenue related to undelivered hardware and professional services, consisting of installations and consulting engagements, which are recognized as the Company’s performance obligations under the contract are completed.  See Note 9 of the Notes to the Condensed Consolidated Financial Statements for additional information about deferred revenue.
  (was, 2018-09-11, similarity 0.9989):
[0001571996-18-000034:note_history:103]
Contract Liabilities — Contract liabilities primarily consist of deferred revenue.  Deferred revenue is recorded when the Company has a right to invoice or payments have been received for undelivered products or services, or in situations where revenue recognition criteria have not been met.  Deferred revenue also represents amounts received in advance for extended warranty services and software maintenance.  Revenue is recognized on these items when the revenue recognition criteria are met, generally resulting in ratable recognition over the contract term.  The Company also has deferred revenue related to undelivered hardware and professional services, consisting of installations and consulting engagements, which are recognized as the Company's performance obligations under the contract are completed.  See Note 9 of the Notes to the Condensed Consolidated Financial Statements for additional information about deferred revenue.

- changed (2018-12-10):
[0001571996-18-000044:note_history:104]
Costs to Obtain a Contract — The incremental direct costs of obtaining a contract primarily consist of sales commissions and employer taxes related to commission payments.  The Company has elected, as a practical expedient, to expense as incurred costs to obtain a contract equal to or less than one year in duration.  For contracts greater than one year in duration, the associated costs to obtain a contract are deferred and amortized over the period of contract performance or a longer period, generally the estimated life of the customer relationship, if renewals are expected and the renewal commission is not commensurate with the initial commission.  Deferred costs to obtain a contract are typically amortized over a period of three to seven years, depending on the contract term and expectation of the period of benefit for the costs, which may exceed the contract term.  Amortization expense is recognized on a straight-line basis and included in selling, general, and administrative expenses in the Condensed Consolidated Statements of Income (Loss).  
The Company periodically reviews these deferred costs to determine whether events or changes in circumstances have occurred that could impact the carrying value or period of benefit of the deferred sales commissions.  There were no material impairment losses for deferred sales commissions during the nine months ended November 2, 2018 and November 3, 2017.
  (was, 2018-09-11, similarity 0.9775):
[0001571996-18-000034:note_history:104]
Costs to Obtain a Contract — The incremental direct costs of obtaining a contract primarily consist of sales commissions and employer taxes related to commission payments.  The Company has elected, as a practical expedient, to expense as incurred costs to obtain a contract equal to or less than one year in duration.  For contracts greater than one year in duration, the associated costs to obtain a contract are deferred and amortized over the period of contract performance or a longer period, generally the estimated life of the customer relationship, if renewals are expected and the renewal commission is not commensurate with the initial commission.  Deferred costs to obtain a contract are typically amortized over a period of three to seven years, depending on the contract term and expectation of the period of benefit for the costs, which may exceed the contract term.  Amortization expense is recognized on a straight-line basis and included in selling, general, and administrative expenses in the Condensed Consolidated Statements of Income (Loss).  The Company periodically reviews these deferred costs to determine whether events or changes in circumstances have occurred that could impact the carrying value or period of benefit of the deferred sales commissions.  There were no material impairment losses for deferred sales commissions during the six months ended August 3, 2018 and August 4, 2017.

- removed (2018-12-10):
[0001571996-18-000034:note_history:105]
Deferred costs to obtain a contract as of August 3, 2018 and February 2, 2018 were $1.0 billion and $0.8 billion, respectively.  Deferred costs to obtain a contract are classified as current assets and other non-current assets on the Condensed Consolidated Statements of Financial Position, based on when the expense is expected to be recognized.


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: no_current_note, score: 0.0

- removed (2018-12-10):
[0001571996-18-000034:note_history:106]
DEFERRED REVENUE

- removed (2018-12-10):
[0001571996-18-000034:note_history:107]
Deferred Revenue — Deferred revenue is recorded for support and deployment services, software maintenance, professional services, training, and SaaS when the Company has a right to invoice or payments have been received for undelivered products or services where transfer of control has not occurred.  Revenue is recognized on these items when the revenue recognition criteria are met, generally resulting in ratable recognition over the contract term.  The Company also has deferred revenue related to undelivered hardware and professional services, consisting of installations and consulting engagements, which are recognized as the Company's performance obligations under the contract are completed.

- removed (2018-12-10):
[0001571996-18-000034:note_history:108]
Changes in the Company's deferred revenue are presented in the following table for the period indicated:

- removed (2018-12-10):
[0001571996-18-000034:note_history:109]
|  | Three Months Ended |  | Six Months Ended |
|  | August 3, 2018 |  | August 3, 2018 |
|  | (in millions) |
| Deferred revenue: |  |  |  |
| Deferred revenue at beginning of period | $ | 20,959 |  |  | $ | 20,816 |  |
| Revenue deferrals for new contracts and changes in estimates for pre-existing contracts (a) | 6,123 |  |  | 11,460 |  |
| Revenue recognized | (5,382 | ) |  | (10,576 | ) |
| Deferred revenue at end of period | $ | 21,700 |  |  | $ | 21,700 |  |
| Short-term deferred revenue | $ | 11,965 |  |  | $ | 11,965 |  |
| Long-term deferred revenue | $ | 9,735 |  |  | $ | 9,735 |  |

- removed (2018-12-10):
[0001571996-18-000034:note_history:110]
____________________

- removed (2018-12-10):
[0001571996-18-000034:note_history:111]
| (a) | Includes the impact of foreign currency exchange rate fluctuations. |

- removed (2018-12-10):
[0001571996-18-000034:note_history:112]
Remaining Performance Obligations — Remaining performance obligations represent the aggregate amount of the transaction price allocated to performance obligations not delivered, or partially undelivered, as of the end of the reporting period.

- removed (2018-12-10):
[0001571996-18-000034:note_history:113]
Remaining performance obligations include deferred revenue plus unbilled amounts not yet recorded in deferred revenue.  The aggregate amount of the transaction price allocated to remaining performance obligations does not include amounts owed under cancelable contracts where there is no substantive termination penalty.

- removed (2018-12-10):
[0001571996-18-000034:note_history:114]
The Company applied the practical expedient to exclude the value of remaining performance obligations for contracts for which revenue is recognized at the amount to which the Company has the right to invoice for services performed.  The Company also applied the practical expedient to not disclose the amount of transaction price allocated to remaining performance obligations for the periods prior to adoption of the new revenue standard.

- removed (2018-12-10):
[0001571996-18-000034:note_history:115]
Remaining performance obligation estimates are subject to change and are affected by several factors, including terminations, changes in the scope of contracts, periodic revalidation, adjustments for revenue that has not materialized, and adjustments for currency.

- removed (2018-12-10):
[0001571996-18-000034:note_history:116]
The value of the transaction price allocated to remaining performance obligations as of August 3, 2018 was approximately $29 billion.  The Company expects to recognize approximately 62% of remaining performance obligations as revenue in the next 12 months, and the remainder thereafter.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- changed (2018-12-10):
[0001571996-18-000044:note_history:117]
NOTE 20 — SUBSEQUENT EVENTS
  (was, 2018-09-11, similarity 0.7907):
[0001571996-18-000034:note_history:117]
SUBSEQUENT EVENTS

- added (2018-12-10):
[0001571996-18-000044:note_history:118]
During November 2018, VMware, Inc. announced that it had signed a definitive agreement to acquire Heptio Inc. (“Heptio”).  Total consideration for the acquisition, subject to purchase price adjustments, will consist of approximately $550 million in cash and assumed unvested equity awards of the acquiree.  Heptio provides products and services that help enterprises deploy and operationalize Kubernetes.  The transaction is expected to close during the three months ending February 1, 2019 and is subject to regulatory approvals and customary closing conditions.

- added (2018-12-10):
[0001571996-18-000044:note_history:119]
On November 14, 2018, the Company and Merger Sub entered into Amendment No.1 to the Agreement and Plan of Merger (the “Amendment”), which amended the Merger Agreement described in Note 16 of the Notes to the Condensed Consolidated Financial Statements (as amended by the Amendment, the “Amended Merger Agreement”).  The Amendment, among other things, (i) increases the Aggregate Cash Consideration Cap from $9 billion to $14 billion, (ii) increases the per share Cash Consideration from $109.00, without interest, to $120.00, without interest, and (iii) increases the ratio at which each share of Class V Common Stock may be exchanged from 1.3665 shares of Class C Common Stock to at least 1.5043 shares of Class C Common Stock.  Under the Amended Merger Agreement, each share of Class V Common Stock will be converted into the right to receive, at the election of the holder of such share, either (1) such number of shares of Class C Common Stock as determined by the application of the exchange ratio, which will be between 1.5043 and 1.8130, or (2) $120.00 in cash, without interest, subject to the Aggregate Cash Consideration Cap of $14 billion. This represents a 10% increase in the consideration for the Class V transaction, as well as a 56% increase in the Aggregate Cash Consideration Cap.

- added (2018-12-10):
[0001571996-18-000044:note_history:120]
In addition, the Amendment provides for certain corporate governance changes that would be implemented following the closing of the Merger.  Among such changes, the Company has agreed that, no later than June 30, 2019, (i) the Company’s Board of Directors will appoint a fourth director who meets the independence requirements of the New York Stock Exchange (an “independent director”) to the Board of Directors after consultation with holders of Class C Common Stock and (ii) the Company will establish a Nominating and Corporate Governance Committee of the Board of Directors. The Nominating and Corporate Governance Committee is expected to be initially comprised of Michael Dell and Egon Durban, who currently serve as directors, and one independent director. The Amendment also includes changes to the Company’s amended and restated certificate of incorporation to provide for the ability of holders of Class C Common Stock, voting separately as a series, to elect one director beginning with the second annual meeting of stockholders of the Company following the closing of the Merger and annually thereafter.

- added (2018-12-10):
[0001571996-18-000044:note_history:121]
In connection with the Amendment, Dell entered into a commitment letter, dated November 14, 2018, with bank lenders providing for a senior secured incremental first lien term A loan facility (the “bridge financing”) under the Company’s existing senior secured credit agreement to fund the $5 billion increase in the Aggregate Cash Consideration Cap.  The bridge financing will bear interest at a rate per annum equal to an applicable margin, plus, at the borrowers’ option, either (i) the adjusted LIBOR plus 1.75%, subject to an interest rate floor of 0% per annum, or (ii) a base rate subject to an interest rate floor of 0.75% per annum, subject to an interest rate floor of 0% per annum.

- added (2018-12-10):
[0001571996-18-000044:note_history:122]
The bridge financing will have no amortization and will initially mature on the earlier of (a) February 8, 2019 and (b) the date on which the Merger Agreement is terminated by the Company or any of its affiliates in accordance with its terms (the “Initial Maturity Date”), except that, on the date on which the Class V transaction is consummated, the Initial Maturity Date will be extended automatically to the date that is 364 days after the closing date of the Merger (the “First Extended Maturity Date”), so long as the Merger has been consummated prior to the Initial Maturity Date.

- added (2018-12-10):
[0001571996-18-000044:note_history:123]
The First Extended Maturity Date may be extended to the date that is 364 days after the First Extended Maturity Date (the “Second Extended Maturity Date” and together with the Initial Maturity Date and the First Extended Maturity Date, as applicable, the “Maturity Date”) so long as (i) the borrower shall have provided written notice of the extension at least 10 business days prior to the First Extended Maturity Date, (ii) concurrently with the effectiveness of such extension, the borrower shall have paid an extension fee in an amount equal to 0.50% of the aggregate principal amount of the bridge financing so extended, and (iii) the conditions set forth in senior secured credit agreement shall have been satisfied.

- added (2018-12-10):
[0001571996-18-000044:note_history:124]
The Merger and the Class V transaction will be accounted for as a hybrid liability and equity transaction involving the repurchase of outstanding common stock, with the consideration consisting of a variable combination of cash and shares.  Upon settlement, the accounting for the Class V transaction will reflect that the outstanding Class V Common Stock will be canceled and converted into the right to receive shares of Class C Common Stock or $120.00 per share in cash or combination of cash and shares, depending on each holder’s election and subject to proration of the cash elections.  The variable nature of the cash obligation to repurchase the shares of Class V Common Stock may require the Company to settle a portion of the shares in exchange for cash and therefore will be accounted for as a financial instrument with a potential mark-to-market adjustment for the change in fair value from the date of the stockholder meeting at which the Company’s stockholders will vote on approval of the Class V transaction to the election deadline by which holders of Class V Common Stock must elect the form of consideration for which they will exchange their shares.  After the election deadline and following the determination of the final proration of cash elections and the exchange ratio, the Class V transaction will be accounted for as an equity transaction.

- removed (2018-12-10):
[0001571996-18-000034:note_history:125]
During August 2018, VMware, Inc. announced that it signed a definitive agreement to acquire CloudHealth Technologies, Inc. ("CloudHealth Technologies").  Total consideration for the acquisition, subject to purchase price adjustments, will consist of approximately $500 million in cash and assumed unvested equity awards of the acquiree.  CloudHealth Technologies delivers a cloud operations platform that enables customers to help analyze and manage cloud cost, usage, security, and performance centrally for native public clouds.  The transaction is expected to close during the three months ended November 2, 2018 and is subject to regulatory approvals and customary closing conditions.

- removed (2018-12-10):
[0001571996-18-000034:note_history:126]
On September 4, 2018, the Company repaid $600 million of the Term Loan A-3 Facility that matures in December 2018.
