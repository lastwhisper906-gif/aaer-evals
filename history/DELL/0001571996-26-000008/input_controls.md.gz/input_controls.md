# DELL 10-K controls and the auditor's report


## auditors_report

[0001571996-26-000008:auditors_report:1]
Report of Independent Registered Public Accounting Firm

[0001571996-26-000008:auditors_report:2]
To the Board of Directors and Stockholders of Dell Technologies Inc.

[0001571996-26-000008:auditors_report:3]
Opinions on the Financial Statements and Internal Control over Financial Reporting

[0001571996-26-000008:auditors_report:4]
We have audited the accompanying consolidated statements of financial position of Dell Technologies Inc. and its subsidiaries (the “Company”) as of January 30, 2026 and January 31, 2025, and the related consolidated statements of income, of comprehensive income, of stockholders’ equity (deficit) and of cash flows for each of the three years in the period ended January 30, 2026, including the related notes (collectively referred to as the “consolidated financial statements”). We also have audited the Company's internal control over financial reporting as of January 30, 2026, based on criteria established in Internal Control - Integrated Framework (2013) issued by the Committee of Sponsoring Organizations of the Treadway Commission (COSO).

[0001571996-26-000008:auditors_report:5]
In our opinion, the consolidated financial statements referred to above present fairly, in all material respects, the financial position of the Company as of January 30, 2026 and January 31, 2025, and the results of its operations and its cash flows for each of the three years in the period ended January 30, 2026 in conformity with accounting principles generally accepted in the United States of America. Also in our opinion, the Company maintained, in all material respects, effective internal control over financial reporting as of January 30, 2026, based on criteria established in Internal Control - Integrated Framework (2013) issued by the COSO.

[0001571996-26-000008:auditors_report:6]
Basis for Opinions

[0001571996-26-000008:auditors_report:7]
The Company's management is responsible for these consolidated financial statements, for maintaining effective internal control over financial reporting, and for its assessment of the effectiveness of internal control over financial reporting, included in Management’s Annual Report on Internal Control Over Financial Reporting appearing under Item 9A. Our responsibility is to express opinions on the Company’s consolidated financial statements and on the Company's internal control over financial reporting based on our audits. We are a public accounting firm registered with the Public Company Accounting Oversight Board (United States) (PCAOB) and are required to be independent with respect to the Company in accordance with the U.S. federal securities laws and the applicable rules and regulations of the Securities and Exchange Commission and the PCAOB.

[0001571996-26-000008:auditors_report:8]
We conducted our audits in accordance with the standards of the PCAOB. Those standards require that we plan and perform the audits to obtain reasonable assurance about whether the consolidated financial statements are free of material misstatement, whether due to error or fraud, and whether effective internal control over financial reporting was maintained in all material respects.

[0001571996-26-000008:auditors_report:9]
Our audits of the consolidated financial statements included performing procedures to assess the risks of material misstatement of the consolidated financial statements, whether due to error or fraud, and performing procedures that respond to those risks. Such procedures included examining, on a test basis, evidence regarding the amounts and disclosures in the consolidated financial statements. Our audits also included evaluating the accounting principles used and significant estimates made by management, as well as evaluating the overall presentation of the consolidated financial statements. Our audit of internal control over financial reporting included obtaining an understanding of internal control over financial reporting, assessing the risk that a material weakness exists, and testing and evaluating the design and operating effectiveness of internal control based on the assessed risk. Our audits also included performing such other procedures as we considered necessary in the circumstances. We believe that our audits provide a reasonable basis for our opinions.

[0001571996-26-000008:auditors_report:10]
Definition and Limitations of Internal Control over Financial Reporting

[0001571996-26-000008:auditors_report:11]
A company’s internal control over financial reporting is a process designed to provide reasonable assurance regarding the reliability of financial reporting and the preparation of financial statements for external purposes in accordance with generally accepted accounting principles. A company’s internal control over financial reporting includes those policies and procedures that (i) pertain to the maintenance of records that, in reasonable detail, accurately and fairly reflect the transactions and dispositions of the assets of the company; (ii) provide reasonable assurance that transactions are recorded as necessary to permit preparation of financial statements in accordance with generally accepted accounting principles, and that receipts and expenditures of the company are being made only in accordance with authorizations of management and directors of the company; and (iii) provide reasonable assurance regarding prevention or timely detection of unauthorized acquisition, use, or disposition of the company’s assets that could have a material effect on the financial statements.

[0001571996-26-000008:auditors_report:12]
67

[0001571996-26-000008:auditors_report:13]
Because of its inherent limitations, internal control over financial reporting may not prevent or detect misstatements. Also, projections of any evaluation of effectiveness to future periods are subject to the risk that controls may become inadequate because of changes in conditions, or that the degree of compliance with the policies or procedures may deteriorate.

[0001571996-26-000008:auditors_report:14]
Critical Audit Matters

[0001571996-26-000008:auditors_report:15]
The critical audit matter communicated below is a matter arising from the current period audit of the consolidated financial statements that was communicated or required to be communicated to the audit committee and that (i) relates to accounts or disclosures that are material to the consolidated financial statements and (ii) involved our especially challenging, subjective, or complex judgments. The communication of critical audit matters does not alter in any way our opinion on the consolidated financial statements, taken as a whole, and we are not, by communicating the critical audit matter below, providing a separate opinion on the critical audit matter or on the accounts or disclosures to which it relates.

[0001571996-26-000008:auditors_report:16]
Revenue Recognition for Certain Products and Services

[0001571996-26-000008:auditors_report:17]
As described in Note 2 to the consolidated financial statements, the Company sells a wide portfolio of products and services to its customers. The Company’s contracts with customers often include the promise to transfer multiple goods and services to the customer. Distinct promises within a contract are referred to as “performance obligations” and are accounted for as separate units of account. The Company’s performance obligations include various distinct goods and services such as hardware, software licenses, support and maintenance agreements, and other service offerings and solutions. The Company recognizes revenue when obligations under the terms of the contract with the Company’s customer are satisfied, either over time or at a point in time, depending on when the underlying products or services are transferred to the customer. For the year ended January 30, 2026, the Company’s total net revenue was $113.5 billion, of which the majority relates to certain product and services revenue.

[0001571996-26-000008:auditors_report:18]
The principal consideration for our determination that performing procedures relating to revenue recognition for certain products and services is a critical audit matter is a high degree of auditor effort in performing procedures related to the Company’s revenue recognition.

[0001571996-26-000008:auditors_report:19]
Addressing the matter involved performing procedures and evaluating audit evidence in connection with forming our overall opinion on the consolidated financial statements. These procedures included testing the effectiveness of controls relating to the revenue recognition process. These procedures also included, among others, (i) testing the completeness and accuracy of management’s identification of performance obligations by examining revenue contracts on a test basis; (ii) testing a sample of revenue transactions by obtaining and inspecting source documents, such as executed contracts, purchase orders, invoices, and proof of delivery; and (iii) confirming a sample of outstanding customer invoice balances as of January 30, 2026 and, for confirmations not returned, obtaining and inspecting source documents, such as executed contracts, purchase orders, invoices, proof of delivery, and subsequent cash receipts.

[0001571996-26-000008:auditors_report:20]
/s/ PricewaterhouseCoopers LLP

[0001571996-26-000008:auditors_report:21]
Austin, Texas

[0001571996-26-000008:auditors_report:22]
March 16, 2026

[0001571996-26-000008:auditors_report:23]
We have served as the Company’s auditor since 1986.

[0001571996-26-000008:auditors_report:24]
68

[0001571996-26-000008:auditors_report:25]
DELL TECHNOLOGIES INC.

[0001571996-26-000008:auditors_report:26]
CONSOLIDATED STATEMENTS OF FINANCIAL POSITION

[0001571996-26-000008:auditors_report:27]
(in millions)

[0001571996-26-000008:auditors_report:28]
|  | January 30, 2026 |  | January 31, 2025 |
| ASSETS |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 11,528 |  |  | $ | 3,633 |  |
| Accounts receivable, net of allowance of $77 and $63 | 17,585 |  |  | 10,298 |  |
| Short-term financing receivables, net of allowance of $121 and $78 | 8,458 |  |  | 5,304 |  |
| Inventories | 10,437 |  |  | 6,716 |  |
| Other current assets | 9,594 |  |  | 9,610 |  |
| Current assets held for sale | — |  |  | 668 |  |
| Total current assets | 57,602 |  |  | 36,229 |  |
| Property, plant, and equipment, net | 6,676 |  |  | 6,336 |  |
| Long-term investments | 1,730 |  |  | 1,496 |  |
| Long-term financing receivables, net of allowance of $92 and $75 | 5,822 |  |  | 5,927 |  |
| Goodwill | 19,547 |  |  | 19,120 |  |
| Intangible assets, net | 4,533 |  |  | 4,988 |  |
| Other non-current assets | 5,376 |  |  | 5,650 |  |
| Total assets | $ | 101,286 |  |  | $ | 79,746 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |
| Short-term debt | $ | 7,990 |  |  | $ | 5,204 |  |
| Accounts payable | 33,630 |  |  | 20,832 |  |
| Accrued and other | 8,315 |  |  | 6,597 |  |
| Short-term deferred revenue | 13,334 |  |  | 13,673 |  |
| Current liabilities held for sale | — |  |  | 221 |  |
| Total current liabilities | 63,269 |  |  | 46,527 |  |
| Long-term debt | 23,513 |  |  | 19,363 |  |
| Long-term deferred revenue | 13,596 |  |  | 12,292 |  |
| Other non-current liabilities | 3,378 |  |  | 2,951 |  |
| Total liabilities | $ | 103,756 |  |  | $ | 81,133 |  |
| Commitments and contingencies (Note 11) |  |  |  |
| Stockholders’ equity (deficit): |  |  |  |
| Common stock and capital in excess of $0.01 par value | $ | 9,457 |  |  | $ | 9,119 |  |
| Treasury stock at cost | (14,533) |  |  | (8,502) |  |
| Retained earnings (accumulated deficit) | 3,325 |  |  | (1,160) |  |
| Accumulated other comprehensive loss | (719) |  |  | (939) |  |
| Total Dell Technologies Inc. stockholders’ equity (deficit) | (2,470) |  |  | (1,482) |  |
| Non-controlling interests | — |  |  | 95 |  |
| Total stockholders’ equity (deficit) | (2,470) |  |  | (1,387) |  |
| Total liabilities and stockholders’ equity | $ | 101,286 |  |  | $ | 79,746 |  |

[0001571996-26-000008:auditors_report:29]
The accompanying notes are an integral part of these Consolidated Financial Statements.

[0001571996-26-000008:auditors_report:30]
69

[0001571996-26-000008:auditors_report:31]
DELL TECHNOLOGIES INC.


## item_9a

[0001571996-26-000008:item_9a:1]
ITEM 9A — CONTROLS AND PROCEDURES

[0001571996-26-000008:item_9a:2]
This report includes the certifications of our Chief Executive Officer and Chief Financial Officer required by Rule 13a-14 under the Securities Exchange Act of 1934 (the “Exchange Act”). See Exhibits 31.1 and 31.2 filed with this report. This Item 9A includes information concerning the controls and control evaluations referred to in those certifications.

[0001571996-26-000008:item_9a:3]
Evaluation of Disclosure Controls and Procedures

[0001571996-26-000008:item_9a:4]
Disclosure controls and procedures (as defined in Rules 13a-15(e) and 15d-15(e) under the Exchange Act) are designed to provide reasonable assurance that information required to be disclosed in reports filed or submitted under the Exchange Act is recorded, processed, summarized, and reported within the time periods specified in SEC rules and forms and that such information is accumulated and communicated to management, including the Chief Executive Officer and the Chief Financial Officer, as appropriate, to allow timely decisions regarding required disclosures.

[0001571996-26-000008:item_9a:5]
In connection with the preparation of this report, our management, under the supervision and with the participation of our Chief Executive Officer and Chief Financial Officer, conducted an evaluation of the effectiveness of the design and operation of our disclosure controls and procedures as of January 30, 2026. Based on that evaluation, our Chief Executive Officer and Chief Financial Officer have concluded that as of January 30, 2026, the Company’s disclosure controls and procedures were effective to accomplish their objectives at the reasonable assurance level.

[0001571996-26-000008:item_9a:6]
Management’s Annual Report on Internal Control Over Financial Reporting

[0001571996-26-000008:item_9a:7]
Management, under the supervision of the Chief Executive Officer and the Chief Financial Officer, is responsible for establishing and maintaining adequate internal control over financial reporting. Internal control over financial reporting (as defined in Rules 13a-15(f) and 15d-15(f) under the Exchange Act) is a process designed to provide reasonable assurance regarding the reliability of financial reporting and the preparation of financial statements for external purposes in accordance with generally accepted accounting principles. Internal control over financial reporting includes those policies and procedures which (a) pertain to the maintenance of records that, in reasonable detail, accurately and fairly reflect the transactions and dispositions of assets, (b) provide reasonable assurance that transactions are recorded as necessary to permit preparation of financial statements in accordance with generally accepted accounting principles and that receipts and expenditures of the issuer are being made only in accordance with appropriate authorization of management and the directors of the issuer, and (c) provide reasonable assurance regarding prevention or timely detection of unauthorized acquisition, use, or disposition of assets that could have a material effect on the financial statements.

[0001571996-26-000008:item_9a:8]
In connection with the preparation of this report, our management, under the supervision and with the participation of our Chief Executive Officer and Chief Financial Officer, conducted an evaluation of the effectiveness of our internal control over financial reporting as of January 30, 2026, based on the criteria established in Internal Control — Integrated Framework (2013) issued by the Committee of Sponsoring Organizations of the Treadway Commission (COSO). As a result of that evaluation, management has concluded that our internal control over financial reporting was effective as of January 30, 2026.

[0001571996-26-000008:item_9a:9]
The effectiveness of our internal control over financial reporting as of January 30, 2026 has been audited by PricewaterhouseCoopers LLP, our independent registered public accounting firm, as stated in their report, which is included in “Item 8 — Financial Statements and Supplementary Data.”

[0001571996-26-000008:item_9a:10]
Changes in Internal Control Over Financial Reporting

[0001571996-26-000008:item_9a:11]
We are in the process of an ongoing business modernization initiative to advance our capabilities, leverage new technology, and optimize business processes to change the way we work and make decisions, improve business outcomes, and reduce costs. As part of this initiative, we are modernizing accounting and finance systems. We have modified and will continue to modify the design and implementation of certain internal control processes to accommodate changes to our business processes and finance procedures, as our business modernization initiative continues.

[0001571996-26-000008:item_9a:12]
139

[0001571996-26-000008:item_9a:13]
There were no other changes in our internal control over financial reporting during the fiscal quarter ended January 30, 2026 that have materially affected, or are reasonably likely to materially affect, our internal control over financial reporting.

[0001571996-26-000008:item_9a:14]
Limitations on the Effectiveness of Controls

[0001571996-26-000008:item_9a:15]
Our system of controls is designed to provide reasonable, not absolute, assurance regarding the reliability and integrity of accounting and financial reporting. Management does not expect that our disclosure controls and procedures or our internal control over financial reporting will prevent or detect all errors and all fraud. A control system, no matter how well designed and operated, can provide only reasonable, not absolute, assurance that the objectives of the control system will be met. These inherent limitations include the following:

[0001571996-26-000008:item_9a:16]
•Judgments in decision-making can be faulty, and control and process breakdowns can occur because of simple errors or mistakes.

[0001571996-26-000008:item_9a:17]
•Controls can be circumvented by individuals, acting alone or in collusion with each other, or by management override.

[0001571996-26-000008:item_9a:18]
•The design of any system of controls is based in part on certain assumptions about the likelihood of future events, and there can be no assurance that any design will succeed in achieving its stated goals under all potential future conditions.

[0001571996-26-000008:item_9a:19]
•Over time, controls may become inadequate because of changes in conditions or deterioration in the degree of compliance with associated policies or procedures.

[0001571996-26-000008:item_9a:20]
•The design of a control system must reflect the fact that resources are constrained, and the benefits of controls must be considered relative to their costs.

[0001571996-26-000008:item_9a:21]
140
