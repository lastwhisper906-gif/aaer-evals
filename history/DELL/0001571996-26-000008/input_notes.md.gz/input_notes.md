# DELL notes — 0001571996-26-000008


## dei:DocumentsIncorporatedByReferenceTextBlock

[0001571996-26-000008:notes:1]
DOCUMENTS INCORPORATED BY REFERENCE

[0001571996-26-000008:notes:2]
The information required by Part III of this report, to the extent not set forth herein, is incorporated by reference from the registrant’s proxy statement relating to its annual meeting of stockholders to be held in 2026. The proxy statement will be filed with the Securities and Exchange Commission within 120 days after the end of the fiscal year to which this report relates.


## cyd:CybersecurityRiskManagementProcessesForAssessingIdentifyingAndManagingThreatsTextBlock

[0001571996-26-000008:notes:3]
We face numerous cybersecurity threats that range from cyber-attacks common to most industries to attacks from more advanced and persistent threat actors that target large information technology companies with products and services operating in strategic sectors. We could be adversely affected by cybersecurity incidents affecting our systems or the systems of our suppliers, customers, and other third-party service providers. To address these threats, we expend considerable resources on cybersecurity risk management, strategy, and governance.

[0001571996-26-000008:notes:4]
We assess, identify, and manage material cybersecurity risks in a number of ways. Our global security and resiliency organization, under the leadership of our Chief Security Officer (“CSO”), has established an internal governance structure to identify, assess, rate, and manage cybersecurity risks across the Company in an integrated manner. The security and resiliency organization advises each business unit and functional area on addressing cybersecurity risks and monitors initiatives to mitigate and manage such risks over time. Each business unit or functional area is responsible for managing risks and ensuring that security and resiliency policies and standards are implemented within the respective business unit or function. Compliance with our internal security and resiliency policies and standards is assessed by our internal audit team, which has a dedicated cybersecurity audit function.

[0001571996-26-000008:notes:5]
Our security and resiliency organization includes a dedicated cybersecurity function led by our Chief Information Security Officer (“CISO”). As part of our cybersecurity function, the cybersecurity and intelligence response team (“CSIRT”) administers a program to monitor, detect, investigate, respond to, and escalate management of internal and external cybersecurity threats and incidents. The CSIRT provides threat intelligence information to our CSO, broader security and resiliency organization, and relevant business units and functional areas.

[0001571996-26-000008:notes:6]
We also engage third parties in connection with our cybersecurity risk management processes, including cybersecurity consultants and auditors, to conduct evaluations of our security controls and provide certifications for industry-standard security frameworks, such as ISO27001 and SOC, Type 2.

[0001571996-26-000008:notes:7]
In addition to monitoring risks from threats to our own assets, we administer a third-party risk management program that helps identify and manage risks from cybersecurity threats arising from attacks against our suppliers and other service provider organizations. This program seeks to combine a methodology for risk ratings with targeted cybersecurity assessments, security-focused contractual requirements, and monitoring activities based on the risk profile of covered suppliers and service providers.

[0001571996-26-000008:notes:8]
Our CSO reports to our General Counsel and has principal executive responsibility and oversight for the Company’s strategy, planning, and operations on the management of both physical security and cybersecurity risk. Our CSO has extensive cybersecurity and program management experience and previously served in relevant leadership positions at another large multinational corporation and the U.S. Department of Defense. He is supported by our CISO, who has extensive cybersecurity experience in both the private and public sectors, and a team of cybersecurity professionals with relevant and expansive educational and industry experience.

[0001571996-26-000008:notes:9]
Cybersecurity risk management has been integrated into the Company’s overall enterprise risk management program (“ERM”) through the Company’s enterprise risk governing bodies, which are the Global Risk and Compliance Council (“GRCC”) and the Enterprise Risk Steering Committee (“ERSC”). Our CSO reports on cybersecurity risk to the GRCC and ERSC and also serves as a member of the ERSC. The CSO regularly meets with members of our executive leadership team to discuss cybersecurity risks, as well as related mitigation and remediation activities. In addition, information on cybersecurity risks is further integrated into our overall ERM through our central internal audit function, which incorporates such information in regular audits of our cybersecurity and data protection controls and processes.


## cyd:CybersecurityRiskBoardOfDirectorsOversightTextBlock

[0001571996-26-000008:notes:10]
Our Board of Directors oversees significant cybersecurity risks to the Company directly and through its Audit Committee. The Board of Directors meets with our CSO or his delegate bi-annually to review significant cybersecurity risks as well as cybersecurity priorities and focus areas for the upcoming fiscal year. The Audit Committee meets with our CSO or his delegate quarterly to review significant cybersecurity incidents and risks, programmatic security modifications and enhancements, and progress made towards key cybersecurity initiatives and matters. The CSO may provide more frequent updates to the Board of Directors and Audit Committee if necessitated by a security incident or other developments. The Audit Committee reports regularly to our Board of Directors regarding the committee’s oversight of cybersecurity risk matters.


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0001571996-26-000008:notes:11]
Basis of Presentation — These Consolidated Financial Statements have been prepared in accordance with accounting principles generally accepted in the United States of America (“GAAP”).

[0001571996-26-000008:notes:12]
The Company’s fiscal year is the 52- or 53-week period ending on the Friday nearest January 31. The fiscal years ended January 30, 2026, January 31, 2025, and February 2, 2024 may be referred to as “Fiscal 2026,” “Fiscal 2025,” and “Fiscal 2024,” respectively. All fiscal years presented included 52 weeks.


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock

[0001571996-26-000008:notes:13]
SUMMARY OF SIGNIFICANT ACCOUNTING POLICIES 
Principles of Consolidation — These Consolidated Financial Statements include the accounts of Dell Technologies and its wholly-owned subsidiaries, as well as the accounts of Secureworks, which, as indicated in Note 1 of the Notes to the Consolidated Financial Statements, was majority-owned by Dell Technologies until its sale on February 3, 2025. All intercompany transactions have been eliminated.

[0001571996-26-000008:notes:14]
The Company also consolidates Variable Interest Entities ("VIEs") where it has been determined that the Company is the primary beneficiary of the applicable entities’ operations. For each VIE, the primary beneficiary is the party that has both the power to direct the activities that most significantly impact the VIE's economic performance and the obligation to absorb losses or the right to receive benefits of the VIE that could potentially be significant to such VIE. In evaluating whether the Company is the primary beneficiary of each entity, the Company evaluates its power to direct the most significant activities of the VIE by considering the purpose and design of each entity and the risks each entity was designed to create and pass through to its respective variable interest holders. The Company also evaluates its economic interests in each of the VIEs. See Note 5 of the Notes to the Consolidated Financial Statements for more information regarding consolidated VIEs.

[0001571996-26-000008:notes:15]
Use of Estimates — The preparation of financial statements in accordance with GAAP requires management to make estimates and assumptions that affect the amounts reported in the Consolidated Financial Statements and the accompanying Notes. Actual results could differ materially from those estimates.

[0001571996-26-000008:notes:16]
Cash and Cash Equivalents — All highly liquid investments with original maturities of 90 days or less at date of purchase are reported at fair value and are considered to be cash equivalents. Credit card receivables are classified as either cash and cash equivalents or receivables depending on the nature of the payment terms.

[0001571996-26-000008:notes:17]
Investments — The Company has strategic investments in equity and other securities as well as investments in fixed-income debt securities. All equity and other securities and long-term fixed income debt securities are recorded as long-term investments in the Consolidated Statements of Financial Position. Short-term fixed income debt securities are recorded as other current assets in the Consolidated Statements of Financial Position.

[0001571996-26-000008:notes:18]
Strategic investments in marketable equity and other securities are recorded at fair value based on quoted prices in active markets. Strategic investments in non-marketable equity and other securities without readily determinable fair values are recorded at cost, less impairment, and are adjusted for observable price changes. In evaluating equity investments without readily determinable fair values for impairment or observable price changes, the Company uses inputs that include pre- and post-money valuations of recent financing events and the impact of those events on its fully diluted ownership percentages, as well as other available information regarding the issuer’s historical and forecasted performance. Fair value measurements and impairments for strategic investments are recognized in interest and other, net in the Consolidated Statements of Income.

[0001571996-26-000008:notes:19]
Fixed-income debt securities are carried at amortized cost and approximate fair value. The Company intends to hold its fixed-income debt securities to maturity.

[0001571996-26-000008:notes:20]
Allowance for Expected Credit Losses on Accounts Receivable — The Company recognizes an allowance for losses on accounts receivable in an amount equal to the current expected credit losses. The estimation of the allowance is based on an analysis of historical loss experience, current receivables aging, and management’s assessment of current conditions and reasonable and supportable expectation of future conditions, as well as an assessment of specific identifiable customer accounts considered at risk or uncollectible. The Company assesses collectibility by pooling receivables where similar characteristics exist and evaluates receivables individually when specific customer balances no longer share those risk characteristics and are considered at risk or uncollectible. The expense associated with the allowance for expected credit losses is recognized in selling, general, and administrative expenses in the Consolidated Statements of Income.

[0001571996-26-000008:notes:21]
Accounting for Operating Leases as a Lessee — In its ordinary course of business, the Company enters into leases as a lessee for property and equipment, warehouses, and office space. The Company determines if an arrangement is a lease or contains a lease at inception. The Company’s leases are generally classified as operating leases. The Company does not have any material finance leases. Operating leases result in the recognition of right of use (“ROU”) assets and lease liabilities on the Consolidated Statements of Financial Position. ROU assets represent the right to use an underlying asset for the lease term, and lease liabilities represent the obligation to make lease payments arising from the lease, measured on a discounted basis. At lease commencement, the lease liability is measured at the present value of the lease payments over the lease term. The operating lease ROU asset equals the lease liability adjusted for any initial direct costs, prepaid or deferred rent, and lease incentives. The Company uses the implicit rate when readily determinable. As most of the leases do not provide an implicit rate, the Company uses its incremental borrowing rate based on the information available at the commencement date to determine the present value of lease payments.

[0001571996-26-000008:notes:22]
The lease term may include options to extend or to terminate the lease that the Company is reasonably certain to exercise. The Company has elected not to record leases with an initial term of 12 months or less on the Consolidated Statements of Financial Position. Lease expense is recognized on a straight-line basis over the lease term in most instances. The Company does not generate material sublease income and has no material related party leases. The Company’s lease agreements do not contain any material residual value guarantees or material restrictive covenants.

[0001571996-26-000008:notes:23]
The Company’s office space agreements contain costs such as common area maintenance and other executory costs that may be either fixed or variable in nature. Variable lease costs are expensed as incurred. The Company combines lease and non-lease components, including fixed common area and other maintenance costs, in calculating the ROU assets and lease liabilities for its office space. Under certain service agreements with third-party logistics providers, the Company directs the use of the inventory within the warehouses and, therefore, controls the assets. The warehouses and some of the equipment used are considered embedded leases. The Company accounts for the lease and non-lease components separately for its warehouses and equipment. The lease components consist of the warehouses and some of the equipment, such as conveyor belts. The non-lease components consist of services and other shared equipment, such as material handling and transportation. The Company allocates the consideration to the lease and non-lease components using their relative standalone values. See Note 6 of the Notes to the Consolidated Financial Statements for additional information.

[0001571996-26-000008:notes:24]
Accounting for Leases as a Lessor — The Company’s wholly-owned subsidiary Dell Financial Services and its affiliates (“DFS”) act as a lessor to provide equipment financing to customers through a variety of lease arrangements. The Company’s leases are classified as sales-type leases, direct financing leases, or operating leases. Direct financing leases are immaterial.

[0001571996-26-000008:notes:25]
The Company also offers alternative payment structures and as-a-Service offerings that are assessed to determine whether an embedded lease arrangement exists. The Company accounts for those contracts as a lease arrangement if it is determined that the contract contains an identified asset and that control of that asset has transferred to the customer.

[0001571996-26-000008:notes:26]
When a contract includes lease and non-lease components, the Company allocates consideration under the contract to each component based on relative standalone selling price and subsequently assesses lease classification for each lease component within a contract. DFS provides lessees with the option to extend the lease or purchase the underlying asset at the end of the lease term, which is considered when evaluating lease classification. In general, DFS lease arrangements do not have variable payment terms and are typically non-cancelable.

[0001571996-26-000008:notes:27]
On commencement of sales-type leases, the Company recognizes profit up-front, and amounts due from the customer under the lease contract are recognized as financing receivables on the Consolidated Statements of Financial Position. Interest income is recognized as net product revenue over the term of the lease based on the effective interest method. The Company has elected not to include sales and other taxes collected from the lessee as part of lease revenue.

[0001571996-26-000008:notes:28]
All other leases that do not meet the definition of a sales-type lease or direct financing lease are classified as operating leases. The underlying asset in an operating lease arrangement is carried at depreciated cost as “Assets in a customer contract” within property, plant, and equipment, net on the Consolidated Statements of Financial Position. Depreciation is calculated using the straight-line method over the term of the underlying lease contract and is recognized as cost of net revenue. The depreciable basis is the original cost of the equipment less the estimated residual value of the equipment at the end of the lease term. The residual value is based upon estimates of the value of the equipment at the end of the lease term using historical studies, industry data, and future value-at-risk demand valuation methods. The Company recognizes operating lease income to product revenue generally on a straight-line basis over the lease term and expenses deferred initial direct costs on the same basis. The Company recognizes variable lease income to product revenue generally as earned. Impairment of assets in a customer contract is assessed on the same basis as other long-lived assets.

[0001571996-26-000008:notes:29]
Financing Receivables — Financing receivables are presented net of allowance for losses and consist of customer receivables and residual interest. Gross customer receivables primarily include amounts due from customers under fixed-term leases, fixed-term loans, and accrued interest. The Company utilizes various credit quality indicators to assess risk and determine the appropriate allowance levels. Fixed-term leases and loans are further segregated into classes based on products, customer type, and credit risk evaluation. Fixed-term leases and loans are offered to qualified small and medium-sized businesses, large commercial accounts, governmental organizations, and educational entities. Fixed-term loans are also offered to qualified individual consumers. The Company historically offered revolving loans until these offerings were discontinued during the fiscal year ended January 31, 2025. As of January 30, 2026, the majority of customer arrangements under revolving loan offerings were transitioned to fixed-term offerings and the revolving loan portfolio is no longer a component of the Company’s financing receivables.

[0001571996-26-000008:notes:30]
The Company retains a residual interest in equipment leased under its fixed-term lease programs. The amount of the residual interest is established at the inception of the lease based upon estimates of the value of the equipment at the end of the lease term using historical studies, industry data, and future value-at-risk demand valuation methods.

[0001571996-26-000008:notes:31]
Allowance for Financing Receivable Losses — The Company recognizes an allowance for financing receivable losses, including both the lease receivable and unguaranteed residual, in an amount equal to the expected losses net of recoveries. The allowance for financing receivable losses on the lease receivable is determined based on various factors, including lifetime expected losses determined using macroeconomic forecast assumptions and management judgments applicable to and through the expected life of the portfolios as well as past due receivables, receivable type, and customer risk profile.

[0001571996-26-000008:notes:32]
Generally, expected credit losses as a result of residual value risk on equipment under lease are not considered to be significant primarily because of the existence of a secondary market with respect to the equipment. The Company’s lease agreements also generally define applicable return conditions and remedies for non-compliance to ensure that the leased equipment will be in good operating condition upon return. Model changes and updates, as well as market strength and product acceptance, are monitored and adjustments are made to residual values in accordance with the significance of any such changes.

[0001571996-26-000008:notes:33]
When an account is deemed to be uncollectible, customer account principal and interest are charged off to the allowance for losses. While the Company does not generally place financing receivables on non-accrual status during the delinquency period, accrued interest is included in the allowance for loss calculation and, therefore, the Company is adequately reserved in the event of charge off. Recoveries on receivables previously charged off as uncollectible are recorded to the allowance for financing receivable losses. The expense associated with the allowance for financing receivable losses is recognized as cost of net revenue.

[0001571996-26-000008:notes:34]
Asset Securitization — The Company transfers certain U.S. and European customer lease and loan payments and associated equipment to Special Purpose Entities (“SPEs”) that meet the definition of a Variable Interest Entity (“VIE”) and are consolidated into the Consolidated Financial Statements. These SPEs are bankruptcy-remote legal entities with separate assets and liabilities. The purpose of the SPEs is to facilitate the funding of customer lease and loan payments and associated equipment in the capital markets. Some of these SPEs have entered into financing arrangements with multi-seller conduits that, in turn, issue asset-backed debt securities in the capital markets. The asset securitizations in the SPEs are accounted for as secured borrowings.

[0001571996-26-000008:notes:35]
Inventories — The Company generally records inventory on the Consolidated Statements of Financial Position when legal title and risk of loss have passed to the Company for items that are held for sale in the ordinary course of business, that are in process of production for sale, or that will be consumed in the production of goods or services that will be held for sale. Inventories are stated at the lower of cost or net realizable value, with cost being determined on a first-in, first-out basis. Adjustments to reduce the cost of inventory to its net realizable value are made, if required, for estimated excess, obsolescence, or impaired balances. At the point of the loss recognition, a new, lower cost basis for that inventory is established, and subsequent changes in facts and circumstances do not result in the restoration or increase in the newly established cost basis.

[0001571996-26-000008:notes:36]
Property, Plant, and Equipment — Property, plant, and equipment are carried at depreciated cost. Depreciation is determined using the straight-line method over the shorter of the estimated useful lives of the assets or the lease term, as applicable. The estimated useful lives of the Company’s property, plant, and equipment are generally as follows:

[0001571996-26-000008:notes:37]
|  | Estimated Useful Life |
| Computer and other equipment | 3-5 years |
| Assets in a customer contract | Term of underlying lease contract |
| Buildings and building improvements | 10-30 years or term of underlying land lease |
| Leasehold improvements | 5 years or contract term |
| Internal use software | 5 years |

[0001571996-26-000008:notes:38]
Gains or losses related to retirements or dispositions of fixed assets are recognized in the period during which the retirement or disposition occurs.

[0001571996-26-000008:notes:39]
The Company capitalizes certain internal and external costs to acquire or create internal use software which are incurred subsequent to the completion of the preliminary project stage. Costs associated with maintenance and minor enhancements to the features and functionality of the Company’s internal use software are expensed as incurred.

[0001571996-26-000008:notes:40]
Capitalized Software Development Costs — Software development costs related to the development of new product offerings are capitalized subsequent to the establishment of technological feasibility, which is demonstrated by the completion of a detailed program design or working model, if no program design is completed. The Company amortizes capitalized software development costs on a straight-line basis over the estimated useful lives of the products, which is generally two years.

[0001571996-26-000008:notes:41]
As of January 30, 2026 and January 31, 2025, capitalized software development costs were $526 million and $623 million, respectively, and are included in other non-current assets in the accompanying Consolidated Statements of Financial Position. Amortization expense for the fiscal years ended January 30, 2026, January 31, 2025, and February 2, 2024 was $290 million, $325 million, and $416 million, respectively.

[0001571996-26-000008:notes:42]
Impairment of Long-Lived Assets — The Company reviews long-lived assets for impairment when events or changes in circumstances indicate that the carrying amount of an asset may not be recoverable. The Company assesses the recoverability of the asset based on the undiscounted future cash flows expected from the use and eventual disposition of the asset. If the carrying amount of the asset is determined not to be recoverable, a write-down to fair value is recorded. Fair values are determined based on quoted market values, discounted cash flows, or external appraisals, as applicable. Long-lived assets to be disposed of are reported at the lower of carrying amount or fair value less costs to sell.

[0001571996-26-000008:notes:43]
Goodwill and Intangible Assets — Identifiable intangible assets with finite lives are amortized over their estimated useful lives. Indefinite-lived intangible assets are not amortized.

[0001571996-26-000008:notes:44]
Definite-lived intangible assets are reviewed for impairment when events and circumstances indicate the asset may be impaired. Goodwill and indefinite-lived intangible assets are tested for impairment annually during the third fiscal quarter and whenever events or circumstances indicate that an impairment may have occurred. The Company can elect to perform a qualitative assessment or directly perform the quantitative impairment test. If a qualitative assessment is performed and it is determined to be more likely than not that the fair value of a goodwill reporting unit or an indefinite-lived intangible asset is less than its carrying amount, the Company will then perform a quantitative test.

[0001571996-26-000008:notes:45]
If a quantitative test is performed, the fair value of each goodwill reporting unit or the indefinite-lived intangible assets is compared to the carrying value to assess for potential impairment. The fair value of each goodwill reporting unit is generally estimated using a combination of public company multiples and discounted cash flow methodologies, which utilize internal forecasts, current and anticipated economic conditions and trends, selection of market multiples through assessment of the reporting unit’s performance relative to peer competitors, the estimation of the long-term revenue growth rate and discount rate of the Company’s business, and the determination of the Company’s weighted average cost of capital. The fair value of the indefinite-lived intangible assets is generally estimated using discounted cash flow methodologies, which utilize future revenue forecasts, the estimation of the long-term revenue growth rate of the Company’s business, and the determination of the weighted average cost of capital and royalty rates.

[0001571996-26-000008:notes:46]
Foreign Currency Translation — The majority of the Company’s international sales are made by international subsidiaries, some of which have the U.S. Dollar as their functional currency. The Company’s subsidiaries that do not use the U.S. Dollar as their functional currency translate assets and liabilities at current exchange rates in effect at the balance sheet date. Revenue and expenses from these international subsidiaries are translated using the monthly average exchange rates in effect for the period in which the activity was recognized. Foreign currency translation adjustments are included as a component of accumulated other comprehensive income (loss) (“AOCI”) in stockholders’ equity (deficit).

[0001571996-26-000008:notes:47]
Local currency transactions of international subsidiaries that have the U.S. Dollar as their functional currency are remeasured into U.S. Dollars using the current exchange rates for monetary assets and liabilities and historical exchange rates for nonmonetary assets and liabilities. Gains and losses from remeasurement of monetary assets and liabilities are included in interest and other, net on the Consolidated Statements of Income. See Note 20 of the Notes to the Consolidated Financial Statements for amounts recognized from remeasurement during the periods presented.

[0001571996-26-000008:notes:48]
Hedging Instruments — The Company uses derivative financial instruments, primarily forward contracts, options, and swaps, to hedge certain foreign currency and interest rate exposures. The relationships between hedging instruments and hedged items, as well as the risk management objectives and strategies for undertaking hedge transactions, are formally documented. The Company does not use derivatives for speculative purposes. All derivative instruments are recognized as either assets or liabilities in the Consolidated Statements of Financial Position and are measured at fair value. The Company’s hedge portfolio includes non-designated derivatives and derivatives designated as cash flow hedges and, from time to time, fair value hedges.

[0001571996-26-000008:notes:49]
For derivative instruments designated as a cash flow hedge, the Company assesses hedge effectiveness at the onset of the hedge, then performs qualitative assessments at regular intervals throughout the life of the derivative. The gain or loss on the hedge is recorded in AOCI, as a separate component of stockholders’ equity (deficit), and reclassified into earnings in the period during which the hedged transaction is recognized in earnings. For derivatives that are designated as a fair value hedge, the Company evaluates the effectiveness of the qualifying fair value hedge using the shortcut method of accounting under which hedges are assumed to be perfectly effective. The change in fair value of the hedge exactly offsets the fair value of the hedged item and there is no net impact recognized in earnings from the fair value of the derivative. For derivatives that are not designated as hedges or do not qualify for hedge accounting treatment, the Company recognizes the change in the instrument’s fair value in earnings as a component of interest and other, net.

[0001571996-26-000008:notes:50]
Cash flows from derivative instruments are presented in the same category on the Consolidated Statements of Cash Flows as the cash flows from the underlying hedged items. See Note 8 of the Notes to the Consolidated Financial Statements for a description of the Company’s derivative financial instrument activities.

[0001571996-26-000008:notes:51]
Revenue Recognition — The Company sells a wide portfolio of products and services to its customers. The Company’s agreements have varying requirements depending on the goods and services being sold, the rights and obligations conveyed, and the legal jurisdiction of the arrangement. While most of the Company’s agreements have standard terms and conditions, more complex agreements may contain nonstandard terms and conditions that require significant judgments in interpreting agreements to determine the appropriate accounting.

[0001571996-26-000008:notes:52]
Revenue is recognized for these arrangements based on the following five steps:

[0001571996-26-000008:notes:53]
(1)    Identify the contract with a customer. The Company evaluates facts and circumstances regarding sales transactions in order to identify contracts with its customers. An agreement must meet all of the following criteria to qualify as a contract eligible for revenue recognition under the model: (i) the contract must be approved by all parties who are committed to perform their respective obligations; (ii) each party’s rights regarding the goods and services to be transferred to the customer can be identified; (iii) the payment terms for the goods and services can be identified; (iv) the customer has the ability and intent to pay and it is probable that the Company will collect substantially all of the consideration to which it will be entitled; and (v) the contract must have commercial substance. Judgment is used in determining the customer’s ability and intent to pay, which is based upon various factors, including the customer’s historical payment experience or customer credit and financial information.

[0001571996-26-000008:notes:54]
(2)    Identify the performance obligations in the contract. The Company’s contracts with customers often include the promise to transfer multiple goods and services to the customer. Distinct promises within a contract are referred to as “performance obligations” and are accounted for as separate units of account. The Company assesses whether each promised good or service is distinct for the purpose of identifying the performance obligations in the contract. This assessment involves subjective determinations and requires management to make judgments about the individual promised goods or services and whether such goods or services are separable from the other aspects of the contractual relationship. Promised goods and services are considered distinct provided that: (i) the customer can benefit from the good or service either on its own or together with other resources that are readily available to the customer (that is, the good or service is capable of being distinct); and (ii) the Company’s promise to transfer the good or service to the customer is separately identifiable from other promises in the contract (that is, the promise to transfer the good or service is distinct within the context of the contract). The Company’s performance obligations include various distinct goods and services such as hardware, software licenses, support and maintenance agreements, and other service offerings and solutions. Promised goods and services are explicitly identified in the Company’s contracts and may be sold on a standalone basis or bundled as part of a combined solution. In certain hardware solutions, the hardware is highly interdependent on, and interrelated with, the embedded software. In these offerings, the hardware and software licenses are accounted for as a single performance obligation.

[0001571996-26-000008:notes:55]
(3)    Determine the transaction price. The transaction price reflects the amount of consideration to which the Company expects to be entitled in exchange for transferring goods or services to the customer. If the consideration promised in a contract includes a variable amount, the Company estimates the amount to which it expects to be entitled using either the expected value or most likely amount method. Generally, volume discounts, rebates, and sales returns reduce the transaction price. In determining the transaction price, the Company only includes amounts that are not subject to significant future reversal.

[0001571996-26-000008:notes:56]
(4)    Allocate the transaction price to performance obligations in the contract. When a contract includes multiple performance obligations, the transaction price is allocated to each performance obligation in an amount that depicts the consideration to which the Company expects to be entitled in exchange for transferring the promised goods or services. For contracts with multiple performance obligations, the transaction price is allocated in proportion to the standalone selling price (“SSP”) of each performance obligation.

[0001571996-26-000008:notes:57]
The best evidence of SSP is the observable price of a good or service when the Company sells that good or service separately in similar circumstances to similar customers. If a directly observable price is available, the Company will utilize that price for the SSP. If a directly observable price is not available, then SSP must be estimated by considering multiple factors, including, but not limited to, pricing practices, internal costs, and profit objectives as well as overall market and industry conditions, which include geographic or regional specific factors, competitive positioning, and competitor actions.

[0001571996-26-000008:notes:58]
(5)    Recognize revenue when (or as) the performance obligation is satisfied. Revenue is recognized when obligations under the terms of the contract with the Company’s customer are satisfied. Revenue is recognized either over time or at a point in time, depending on when the underlying products or services are transferred to the customer. Revenue is recognized at a point in time for products upon transfer of control. Revenue is recognized over time for support and deployment services, software support, Software-as-a-Service (“SaaS”), and Infrastructure-as-a-Service (“IaaS”). Revenue is recognized either over time or at a point in time for professional services and training depending on the nature of the offering to the customer.

[0001571996-26-000008:notes:59]
The Company reports revenue net of any revenue-based taxes assessed by governmental authorities that are imposed on and concurrently with specific revenue-producing transactions.

[0001571996-26-000008:notes:60]
The Company has elected the following practical expedients:

[0001571996-26-000008:notes:61]
•The Company does not account for significant financing components if the period between revenue recognition and when the customer pays for the product or service will be one year or less.

[0001571996-26-000008:notes:62]
•The Company recognizes revenue equal to the amount it has a right to invoice when the amount corresponds directly with the value to the customer of the Company’s performance to date.

[0001571996-26-000008:notes:63]
•The Company does not account for shipping and handling activities as a separate performance obligation, but rather as an activity performed to transfer the promised good.

[0001571996-26-000008:notes:64]
The following summarizes the nature of revenue recognized and the manner in which the Company accounts for sales transactions.

[0001571996-26-000008:notes:65]
Products

[0001571996-26-000008:notes:66]
Product revenue consists of revenue from sales of hardware products, including notebooks and desktop PCs, servers, storage hardware, and other hardware-related devices, as well as revenue from software license sales, including non-essential software applications and third-party software licenses.

[0001571996-26-000008:notes:67]
Revenue from sales of hardware products is recognized when control has transferred to the customer, which typically occurs when the hardware has been shipped to the customer, risk of loss has transferred to the customer, the Company has a present right to payment, and customer acceptance has been satisfied. Customer acceptance is satisfied if acceptance is obtained from the customer, if all acceptance provisions lapse, or if the Company has evidence that all acceptance provisions will be, or have been, satisfied. Revenue from software license sales is generally recognized when control has transferred to the customer, which is typically upon shipment, electronic delivery, or when the software is available for download by the customer.

[0001571996-26-000008:notes:68]
Services

[0001571996-26-000008:notes:69]
Services revenue consists of revenue from sales of services offerings and support services, including hardware support and software support that extends beyond the Company’s standard warranties, software maintenance, and installation; professional services; training; SaaS; and IaaS. Revenue associated with undelivered performance obligations is deferred and recognized when or as control is transferred to the customer. Revenue from fixed-price support or maintenance contracts sold for both hardware and software is recognized on a straight-line basis over the period of performance because the Company is required to provide services at any given time. Other services revenue is recognized when the Company performs the services and the customer receives and consumes the benefits.

[0001571996-26-000008:notes:70]
Other

[0001571996-26-000008:notes:71]
Revenue from leasing arrangements is not subject to the revenue standard for contracts with customers and remains separately accounted for under lease accounting guidance. The Company records operating lease rental revenue as product revenue on a straight-line basis over the lease term. The Company records revenue under sales-type leases as product revenue in an amount equal to the present value of minimum lease payments at the inception of the lease. Sales-type leases also produce financing income, which is included in product net revenue in the Consolidated Statements of Income and is recognized at effective rates of return over the lease term. The Company also offers qualified customers fixed-term loans as well as previously offered revolving lines of credit through DFS for the purchase of products and services offered by the Company. Financing income attributable to these loans is recognized in product net revenue on an accrual basis.

[0001571996-26-000008:notes:72]
Principal versus Agent — For transactions that involve a third party, the Company evaluates whether it is acting as the principal or the agent in the transaction. This determination requires significant judgment and impacts the amount and timing of revenue recognized. If the Company determines that it controls a good or service before it is transferred to the customer, the Company is acting as the principal and recognizes revenue at the gross amount of consideration it is entitled to from the customer. Indicators that the Company controls a good or service before transferring it to a customer include, but are not limited to, the Company being the primary obligor to the customer, establishing its own pricing, and having inventory and credit risks. Conversely, if the Company determines that it does not control the good or service before it is transferred to the customer, the Company is acting as an agent in the transaction. As an agent, the Company is arranging for the good or service to be provided by another party and recognizes revenue at the net amount of consideration retained.

[0001571996-26-000008:notes:73]
Disaggregation of Revenue — The Company’s revenue is presented on a disaggregated basis on the Consolidated Statements of Income and in Note 18 of the Notes to the Consolidated Financial Statements based on an evaluation of disclosures outside of the financial statements, information regularly provided to and reviewed by the Company’s Chief Operating Decision Maker (“CODM”) for evaluating the financial performance of operating segments, and other information that is used to evaluate the Company’s financial performance and make resource allocations. This information includes revenue from products and services, revenue from reportable segments, and revenue by major product categories within the segments. Given the scale and growth of the AI-optimized servers business, effective in the three months ended January 30, 2026, the Company’s servers and networking offerings were disaggregated within revenue by major product category into AI-optimized servers offerings and traditional servers and networking offerings.

[0001571996-26-000008:notes:74]
Contract Assets — Contract assets are rights to consideration in exchange for goods or services that the Company has transferred to a customer when such a right is conditional on criteria other than the passage of time. Such amounts are immaterial as of January 30, 2026 and January 31, 2025.

[0001571996-26-000008:notes:75]
Contract Liabilities — Contract liabilities primarily consist of deferred revenue. Deferred revenue is recorded when the Company has invoiced or payments have been received for undelivered products or services, or in situations where revenue recognition criteria have not been met. Revenue is recognized on these items when the revenue recognition criteria are met, generally resulting in ratable recognition over the contract term. Deferred revenue primarily consists of support and deployment services, software maintenance, training, Software-as-a-Service, and undelivered hardware and professional services, consisting of installations and consulting engagements. Revenue is recognized as the Company’s performance obligations under the contract are completed. See Note 10 of the Notes to the Consolidated Financial Statements for additional information about deferred revenue.

[0001571996-26-000008:notes:76]
Deferred Costs — Deferred costs primarily consist of costs incurred to fulfill or obtain a contract and are included within other current assets and other non-current assets on the Consolidated Statements of Financial Position, based on when the expense is expected to be recognized.

[0001571996-26-000008:notes:77]
Costs incurred to fulfill revenue-generating contracts are mainly associated with third-party software support and maintenance offerings and VMware Resale offerings discussed in Note 18 and Note 19 of the Notes to the Consolidated Financial Statements. The Company defers and subsequently amortizes these charges on a straight-line basis over the life of the contract or the average contract duration. Amortization expense is included in cost of net revenue in the Consolidated Statements of Income. Deferred costs to fulfill revenue-generating contracts as of January 30, 2026 and January 31, 2025 were $2.7 billion and $4.8 billion, respectively. Amortization of deferred costs to fulfill revenue-generating contracts during the fiscal years ended January 30, 2026, January 31, 2025, and February 2, 2024 was $6.3 billion, $7.6 billion, and $8.0 billion, respectively.

[0001571996-26-000008:notes:78]
The Company capitalizes incremental direct costs to obtain a contract, primarily sales commissions and employer taxes related to commission payments, if the costs are deemed to be recoverable. The Company has elected, as a practical expedient, to expense as incurred costs to obtain a contract equal to or less than one year in duration. Capitalized costs are deferred and amortized over the period of contract performance or the estimated life of the customer relationship, if renewals are expected, and are typically amortized over an average period of one to five years. Amortization expense is recognized on a straight-line basis and included in selling, general, and administrative expenses in the Consolidated Statements of Income. Deferred costs to obtain a contract as of January 30, 2026 and January 31, 2025 were $483 million and $540 million, respectively. Amortization of costs to obtain a contract during the fiscal years ended January 30, 2026, January 31, 2025, and February 2, 2024 was $305 million, $346 million, and $383 million, respectively.

[0001571996-26-000008:notes:79]
The Company periodically reviews these deferred costs to determine whether events or changes in circumstances have occurred that could impact the carrying value or period of benefit of the costs to fulfill or costs to obtain a contract. There were no material impairment losses for deferred costs during the fiscal years ended January 30, 2026, January 31, 2025, and February 2, 2024.

[0001571996-26-000008:notes:80]
Standard Warranty Liabilities — The Company records warranty liabilities for estimated costs of fulfilling its obligations under standard limited hardware and software warranties at the time of sale. The liabilities for standard warranties are included in accrued and other and in other non-current liabilities in the Consolidated Statements of Financial Position. The specific warranty terms and conditions vary depending upon the product sold and the country in which the Company does business, but generally include technical support, parts, and labor over a period ranging from one to three years. Factors that affect the Company’s warranty liabilities include the number of installed units currently under warranty, historical and anticipated rates of warranty claims on those units, and cost per claim to satisfy the Company’s warranty obligation. The anticipated rate of warranty claims is the primary estimate used in determining the warranty liability and is relatively predictable using historical experience of failure rates. The average remaining aggregate warranty period of the covered installed base is approximately 15 months, repair parts are generally already in stock or available at pre-determined prices, and labor rates are generally arranged at preestablished amounts with service providers. If actual results differ from the estimates, the Company revises its estimated warranty liability. Each quarter, the Company reevaluates its estimates to assess the adequacy of its recorded warranty liabilities and adjusts the amounts as necessary. See Note 20 of the Notes to the Consolidated Financial Statements for additional information about standard warranty liabilities.

[0001571996-26-000008:notes:81]
Consideration Received from Vendors — The Company may receive consideration from vendors in the normal course of business. Certain of these funds received as consideration are rebates of purchase price paid and others are related to reimbursement of costs incurred by the Company to sell the vendor’s products. The Company recognizes a reduction to cost of net revenue if the funds are determined to be a reduction of the price of the vendor’s products. If the consideration is a reimbursement of costs incurred by the Company to sell or develop the vendor’s products, the consideration is classified as a reduction of such costs, most often operating expenses, in the Consolidated Statements of Income. To be recognized as a reduction of operating expenses, the reimbursement must be for a specific, incremental, and identifiable cost incurred by the Company in selling the vendor’s products or services.

[0001571996-26-000008:notes:82]
Loss Contingencies — The Company is subject to the possibility of various losses arising in the ordinary course of business. In determining loss contingencies, the Company considers the likelihood of loss or impairment of an asset or the incurrence of a liability, as well as the Company’s ability to reasonably estimate the amount of loss. An estimated loss contingency is accrued when it is probable that an asset has been impaired or a liability has been incurred and the amount of loss can be reasonably estimated. The Company regularly evaluates current information available to determine whether such accruals should be adjusted and whether new accruals are required.

[0001571996-26-000008:notes:83]
Shipping Costs — The Company’s shipping and handling costs are included in cost of net revenue in the Consolidated Statements of Income.

[0001571996-26-000008:notes:84]
Selling, General, and Administrative — Selling expenses include items such as sales salaries and commissions, marketing and advertising costs, and contractor services. Advertising costs are generally expensed as incurred in selling, general, and administrative expenses in the Consolidated Statements of Income. For the fiscal years ended January 30, 2026, January 31, 2025, and February 2, 2024, advertising expenses were $0.7 billion, $0.8 billion, and $0.9 billion, respectively. General and administrative expenses include items for the Company’s administrative functions, such as finance, legal, human resources, and information technology support. These functions include costs for items such as salaries and benefits and other personnel-related costs, maintenance and supplies, outside services, intangible asset amortization, and depreciation expense.

[0001571996-26-000008:notes:85]
Research and Development — Research and development (“R&D”) costs are primarily expensed as incurred. As noted in Capitalized Software Development Costs in this Note, qualifying software development costs are capitalized and amortized over time. R&D costs include salaries and benefits and other personnel-related costs associated with product development. Also included in R&D expenses are infrastructure costs, which consist of equipment and material costs, facilities-related costs, and depreciation expense.

[0001571996-26-000008:notes:86]
Income Taxes — The Company calculates a provision for income taxes using the asset and liability method, under which deferred tax assets and liabilities are recognized by identifying the temporary differences arising from the different treatment of items for tax and accounting purposes. Deferred tax assets and liabilities are recorded using enacted tax rates in effect for the year in which the differences are expected to reverse. The Company accounts for the tax impact of including Global Intangible Low-Taxed Income (“GILTI”) in U.S. taxable income as a period cost. The Company provides valuation allowances for deferred tax assets, where appropriate. In assessing the need for a valuation allowance, the Company considers all available evidence for each jurisdiction, including past operating results, estimates of future taxable income, and the feasibility of ongoing tax planning strategies. In the event the Company determines that all or part of the net deferred tax assets are not realizable in the future, the Company will make an adjustment to the valuation allowance that will be charged to earnings in the period in which such a determination is made.

[0001571996-26-000008:notes:87]
The accounting guidance for uncertainties in income tax prescribes a comprehensive model for the financial statement recognition, measurement, presentation, and disclosure of uncertain tax positions taken or expected to be taken in income tax returns. Judgment is required in evaluating the Company’s uncertain tax positions and determining the Company’s provision for income taxes. The Company recognizes a tax benefit from an uncertain tax position in the financial statements only when it is more likely than not that the position will be sustained upon examination, including resolution of any related appeals or litigation processes, based on the technical merits and a consideration of the relevant taxing authority’s administrative practices and precedents.

[0001571996-26-000008:notes:88]
Stock-Based Compensation — Stock-based compensation expense consists of equity awards granted based on the estimated fair value of those awards at grant date. Stock-based compensation expense for equity awards is recorded over the requisite service period in cost of net revenues, selling, general and administrative expense and research and development expense in the Consolidated Statements of Income based on the function of the employee. Compensation expense is recognized on a straight-line basis for equity awards with a service condition and a graded vesting basis for equity awards that contain either a performance or market condition.

[0001571996-26-000008:notes:89]
The Company estimates a forfeiture rate for unvested share‑based awards and applies this rate to the recognition of stock‑based compensation expense. Forfeiture rates are estimated at grant date based on historical experience and adjusted in subsequent periods for differences in actual forfeitures from those estimates.

[0001571996-26-000008:notes:90]
Equity awards with service conditions — The fair value of restricted stock units (“RSUs”) that contain only a service-based vesting condition is measured using the closing price of the Company’s Class C Common Stock as reported on the New York Stock Exchange (“NYSE”) on the grant date or most recent preceding trading day if grant date falls on a non-trading day. The resulting stock-based compensation expense is recognized over the requisite service period, which is generally three years.

[0001571996-26-000008:notes:91]
Equity awards with service and performance conditions — The fair value of RSUs that contain both service and performance conditions is measured using the closing price of the Company’s Class C Common Stock as reported on the NYSE on the grant date or most recent preceding trading day if the grant date falls on a non-trading day. The resulting stock-based compensation expense is recognized over the requisite service period as long as attainment of the award remains probable. The Company periodically reassesses the probability of attainment and adjusts the related compensation expense accordingly. The requisite service period for performance-based RSUs is generally three years.

[0001571996-26-000008:notes:92]
Equity awards with service and market-based performance conditions — The fair value of performance-based RSUs that contain both service and market-based performance conditions is measured on grant date using a Monte Carlo simulation model. Attainment of the market condition is reflected in the estimate of fair value on the grant date and is recognized regardless of the ultimate level of actual attainment, so long as the requisite service is provided. The requisite service period for market-based performance RSUs is generally three years.

[0001571996-26-000008:notes:93]
Equity awards with service, performance, and market-based conditions — The fair value of equity awards that contain service, performance and market-based conditions is measured on the grant date using a Monte Carlo simulation model. Achievement of the market condition is reflected in the estimate of fair value on the grant date. Compensation expense for awards is recognized over the requisite service period as long as service and performance conditions are considered probable of attainment. If the service or performance conditions become improbable of attainment, compensation expense previously recognized will be reversed. Because the grant date fair value considers the market attainment probability, compensation expense recognized will not be adjusted if the market condition becomes improbable of attainment. The requisite service period for the outstanding stock option grant that contains these vesting conditions is approximately five years.

[0001571996-26-000008:notes:94]
Recently Issued Accounting Pronouncements

[0001571996-26-000008:notes:95]
Internal-Use Software — In September 2025, the Financial Accounting Standards Board (“FASB”) issued guidance to modernize internal-use software capitalization by removing references to software development project stages, increasing the operability of the recognition guidance permitting consideration of different methods of software development, including the agile method. Public entities must adopt the new guidance for fiscal years beginning after December 15, 2027, with early adoption permitted. Upon adoption, the guidance may be applied prospectively, retrospectively, or through a modified approach. The Company is currently evaluating the impact and timing of adoption of this guidance.

[0001571996-26-000008:notes:96]
Expense Disaggregation Disclosures — In November 2024, the FASB issued guidance to improve disclosures about a public entity’s expenses by requiring disclosure of additional information about the types of expenses commonly presented in the financial statements on an annual and interim basis. Public entities must adopt the new guidance for fiscal years beginning after December 15, 2026, with early adoption permitted. Upon adoption, the guidance will be applied prospectively. Adoption of this new guidance will result in increased disclosures in the Notes to the Consolidated Financial Statements.

[0001571996-26-000008:notes:97]
Recently Adopted Accounting Pronouncements

[0001571996-26-000008:notes:98]
Income Taxes — In December 2023, the FASB issued guidance which requires companies to provide disaggregated income tax disclosures within the income tax rate reconciliation and income taxes paid. Public entities were required to adopt the new guidance for fiscal years beginning after December 15, 2024. The Company adopted this standard as of January 30, 2026 on a prospective basis. Adoption of this new guidance resulted in increased disclosures on income taxes in Note 12 and Note 20 of the Notes to the Consolidated Financial Statements.


## us-gaap:CreditLossFinancialInstrumentPolicyTextBlock

[0001571996-26-000008:notes:99]
Generally, expected credit losses as a result of residual value risk on equipment under lease are not considered to be significant primarily because of the existence of a secondary market with respect to the equipment. The Company’s lease agreements also generally define applicable return conditions and remedies for non-compliance to ensure that the leased equipment will be in good operating condition upon return. Model changes and updates, as well as market strength and product acceptance, are monitored and adjustments are made to residual values in accordance with the significance of any such changes.
When an account is deemed to be uncollectible, customer account principal and interest are charged off to the allowance for losses. While the Company does not generally place financing receivables on non-accrual status during the delinquency period, accrued interest is included in the allowance for loss calculation and, therefore, the Company is adequately reserved in the event of charge off. Recoveries on receivables previously charged off as uncollectible are recorded to the allowance for financing receivable losses. The expense associated with the allowance for financing receivable losses is recognized as cost of net revenue.


## us-gaap:FairValueDisclosuresTextBlock

[0001571996-26-000008:notes:100]
FAIR VALUE MEASUREMENTS
The following table presents the Company’s hierarchy for its assets and liabilities measured at fair value on a recurring basis as of the dates indicated:

[0001571996-26-000008:notes:101]
|  | January 30, 2026 |  | January 31, 2025 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | Quoted Prices in Active Markets for Identical Assets |  | Significant Other Observable Inputs |  | Significant Unobservable Inputs |  |  |  | Quoted Prices in Active Markets for Identical Assets |  | Significant Other Observable Inputs |  | Significant Unobservable Inputs |  |  |
|  | (in millions) |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | $ | 8,052 |  |  | $ | — |  |  | $ | — |  |  | $ | 8,052 |  |  | $ | 571 |  |  | $ | — |  |  | $ | — |  |  | $ | 571 |  |
| Marketable equity and other securities | 77 |  |  | — |  |  | — |  |  | 77 |  |  | 8 |  |  | — |  |  | — |  |  | 8 |  |
| Derivative instruments | — |  |  | 160 |  |  | — |  |  | 160 |  |  | — |  |  | 302 |  |  | — |  |  | 302 |  |
| Total assets | $ | 8,129 |  |  | $ | 160 |  |  | $ | — |  |  | $ | 8,289 |  |  | $ | 579 |  |  | $ | 302 |  |  | $ | — |  |  | $ | 881 |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Derivative instruments | $ | — |  |  | $ | 126 |  |  | $ | — |  |  | $ | 126 |  |  | $ | — |  |  | $ | 75 |  |  | $ | — |  |  | $ | 75 |  |
| Total liabilities | $ | — |  |  | $ | 126 |  |  | $ | — |  |  | $ | 126 |  |  | $ | — |  |  | $ | 75 |  |  | $ | — |  |  | $ | 75 |  |

[0001571996-26-000008:notes:102]
The following section describes the valuation methodologies the Company uses to measure financial instruments at fair value.

[0001571996-26-000008:notes:103]
Money Market Funds — The Company’s investment in money market funds that are classified as cash equivalents hold underlying investments with a weighted average maturity of 90 days or less and are recognized at fair value. The valuations of these securities are based on quoted prices for identical assets in active markets, when available, or pricing models whereby all significant inputs are observable, or can be derived from, or corroborated by, observable market data. The Company reviews security pricing and assesses money market fund liquidity on a quarterly basis. As of January 30, 2026, the Company’s portfolio had no exposure to money market funds with a fluctuating net asset value.

[0001571996-26-000008:notes:104]
Marketable Equity and Other Securities — The Company’s investments in equity and other securities that are measured at fair value on a recurring basis consist of strategic investments in publicly-traded companies. The valuation of these securities is based on quoted prices in active markets.

[0001571996-26-000008:notes:105]
Derivative Instruments — The Company’s derivative financial instruments consist primarily of foreign currency forward and purchased option contracts and interest rate swaps. The fair value of the portfolio is determined using valuation models based on market observable inputs, including interest rate curves, forward and spot prices for currencies, and implied volatilities. Credit risk is also factored into the fair value calculation of the Company’s derivative financial instrument portfolio. See Note 8 of the Notes to the Consolidated Financial Statements for a description of the Company’s derivative financial instrument activities.

[0001571996-26-000008:notes:106]
Deferred Compensation Plans — The Company offers deferred compensation plans for eligible employees which allow participants to defer a portion of their compensation. Assets and liabilities associated with the plans are measured at fair value using Level 1 inputs. Assets were the same as liabilities associated with the plans at approximately $274 million and $244 million as of January 30, 2026 and January 31, 2025, respectively, and are included in other assets and other liabilities on the Consolidated Statements of Financial Position. The net impact on the Consolidated Statements of Income is not material since changes in the fair value of the assets substantially offset changes in the fair value of the liabilities. As such, assets and liabilities associated with these plans have not been included in the recurring fair value table above.

[0001571996-26-000008:notes:107]
Assets and Liabilities Measured at Fair Value on a Nonrecurring Basis — Certain assets are measured at fair value on a nonrecurring basis and therefore are not included in the recurring fair value table above. These assets consist primarily of financial assets such as the Company’s strategic investments in non-marketable equity and other securities and non-financial assets such as goodwill and intangible assets.

[0001571996-26-000008:notes:108]
Strategic investments in non-marketable equity and other securities and certain non-financial assets such as goodwill and intangible assets are measured at fair value only if they are deemed to be impaired or when there is an adjustment from observable price changes in the current period. If measured at fair value in the Consolidated Statements of Financial Position, these securities would generally be classified as Level 3 in the fair value hierarchy. See Note 4 and Note 9 of the Notes to the Consolidated Financial Statements for additional information about the Company’s investments and goodwill and intangible assets, respectively.

[0001571996-26-000008:notes:109]
Carrying Value and Estimated Fair Value of Outstanding Debt — The following table presents the carrying value and estimated fair value of the Company’s outstanding debt as described in Note 7 of the Notes to the Consolidated Financial Statements, including the current portion, as of the dates indicated:

[0001571996-26-000008:notes:110]
|  | January 30, 2026 |  | January 31, 2025 |
|  | Carrying Value |  | Fair Value |  | Carrying Value |  | Fair Value |
|  | (in billions) |
| Senior Notes | $ | 21.4 |  |  | $ | 21.8 |  |  | $ | 15.0 |  |  | $ | 15.0 |  |
| Legacy Notes | $ | 0.9 |  |  | $ | 1.0 |  |  | $ | 0.9 |  |  | $ | 1.0 |  |
| DFS Debt | $ | 9.1 |  |  | $ | 8.9 |  |  | $ | 8.7 |  |  | $ | 8.5 |  |

[0001571996-26-000008:notes:111]
The fair values of the outstanding debt shown in the table above were determined based on observable market prices in a less active market or based on valuation methodologies using observable inputs and were categorized as Level 2 in the fair value hierarchy.


## us-gaap:InvestmentTextBlock

[0001571996-26-000008:notes:112]
INVESTMENTS
The Company has strategic investments in equity and other securities as well as immaterial investments in fixed income debt securities that are primarily recorded as long-term investments in the Consolidated Statements of Financial Position. As of January 30, 2026 and January 31, 2025, total investments were $1.7 billion and $1.5 billion, respectively.

[0001571996-26-000008:notes:113]
Equity and other securities include strategic investments in marketable and non-marketable securities. Investments in marketable securities are measured at fair value on a recurring basis. Investments in non-marketable equity and other securities primarily represent early-stage companies without readily determinable fair values. The Company has elected to apply the measurement alternative for non-marketable securities which allows investments without readily determinable fair values to be measured at cost, less impairment, adjusted for observable price changes. The Company makes a separate election to apply the measurement alternative for each eligible investment and is required to reassess at each reporting period whether an investment qualifies for the alternative. In evaluating these investments for impairment or observable price changes, the Company uses inputs including pre- and post-money valuations of recent financing events and the impact of those events on its fully diluted ownership percentages, as well as other available information regarding the issuer’s historical and forecasted performance.

[0001571996-26-000008:notes:114]
Carrying Value of Equity and Other Securities

[0001571996-26-000008:notes:115]
The following table presents the cost, cumulative unrealized gain, cumulative unrealized loss, and carrying value of the Company's strategic investments in marketable and non-marketable equity and other securities as of the dates indicated:

[0001571996-26-000008:notes:116]
|  | January 30, 2026 |  | January 31, 2025 |
|  | Cost |  | Unrealized Gain |  | Unrealized Loss |  | Carrying Value |  | Cost |  | Unrealized Gain |  | Unrealized Loss |  | Carrying Value |
|  | (in millions) |
| Marketable | $ | 119 |  |  | $ | 3 |  |  | $ | (45) |  |  | $ | 77 |  |  | $ | 11 |  |  | $ | 24 |  |  | $ | (27) |  |  | $ | 8 |  |
| Non-marketable | 832 |  |  | 1,071 |  |  | (263) |  |  | 1,640 |  |  | 739 |  |  | 1,009 |  |  | (261) |  |  | 1,487 |  |
| Total equity and other securities | $ | 951 |  |  | $ | 1,074 |  |  | $ | (308) |  |  | $ | 1,717 |  |  | $ | 750 |  |  | $ | 1,033 |  |  | $ | (288) |  |  | $ | 1,495 |  |

[0001571996-26-000008:notes:117]
Gains and Losses on Equity and Other Securities

[0001571996-26-000008:notes:118]
The following table presents unrealized gains and losses on marketable and non-marketable equity and other securities for the periods indicated:

[0001571996-26-000008:notes:119]
|  |  |  | Fiscal Year Ended |
|  |  |  |  |  | January 30, 2026 |  | January 31, 2025 |  | February 2, 2024 |
|  |  |  |  |  | (in millions) |
| Marketable securities: |  |  |  |  |  |  |  |  |  |
| Unrealized gain |  |  |  |  | $ | 53 |  |  | $ | 5 |  |  | $ | 6 |  |
| Unrealized loss |  |  |  |  | (46) |  |  | (6) |  |  | (24) |  |
| Net unrealized gain (loss) |  |  |  |  | 7 |  |  | (1) |  |  | (18) |  |
| Non-marketable securities: |  |  |  |  |  |  |  |  |  |
| Unrealized gain |  |  |  |  | 161 |  |  | 154 |  |  | 84 |  |
| Unrealized loss |  |  |  |  | (42) |  |  | (32) |  |  | (49) |  |
| Net unrealized gain (a) (b) |  |  |  |  | 119 |  |  | 122 |  |  | 35 |  |
| Net unrealized gain on equity and other securities |  |  |  |  | $ | 126 |  |  | $ | 121 |  |  | $ | 17 |  |

[0001571996-26-000008:notes:120]
____________________

[0001571996-26-000008:notes:121]
(a)For the fiscal years ended January 30, 2026 and January 31, 2025, net unrealized gains on non-marketable securities were primarily attributable to adjustments for observable price changes.

[0001571996-26-000008:notes:122]
(b)For the fiscal year ended February 2, 2024, net unrealized gains on non-marketable securities were due to upward adjustments for observable price changes offset by losses attributable to impairments.


## dell:CreditLossFinancialInstrumentLeasesDebtVariableInterestEntitiesAndCustomerReceivablesSalesTextBlock

[0001571996-26-000008:notes:123]
FINANCIAL SERVICES 
The Company offers or arranges a portfolio of payment and consumption solutions and services for its customers globally, including utility, subscription, as-a-Service, leases, and loans, designed to match customers' consumption and financing preferences and to provide operational and financial flexibility.

[0001571996-26-000008:notes:124]
To support financing solutions and services as part of the Dell Technologies portfolio, Dell Financial Services and its affiliates (“DFS”) originate, collect, and service customer financing arrangements primarily related to the purchase and use of Dell Technologies products and services. In some cases, the Company also offers financing for the purchase of third-party technology products that complement the portfolio of the Company’s products and services. New financing originations were $11.9 billion for the fiscal year ended January 30, 2026 and $8.4 billion for both the fiscal years ended January 31, 2025 and February 2, 2024.

[0001571996-26-000008:notes:125]
The Company’s financing arrangements with customers are aggregated primarily as fixed-term leases and loans as described below.

[0001571996-26-000008:notes:126]
Leases — The Company enters into fixed-term financing arrangements with customers who seek lease financing for equipment. Leases are generally classified as sales-type leases or operating leases. Additionally, utility, subscription, and as-a-Service flexible consumption models may result in identification of embedded lease arrangements that require the recognition of sales-type leases or operating leases. Leases with business customers generally have fixed terms of two to five years.

[0001571996-26-000008:notes:127]
Loans — The Company also offers fixed-term loans to qualified small businesses, large commercial accounts, governmental organizations, educational entities, and certain individual consumer customers. These loans are repaid in periodic payments including interest and have defined terms typically ranging from one to five years. The fair value of the fixed-term loan portfolio is determined using market observable inputs. The carrying value of these loans approximates fair value.

[0001571996-26-000008:notes:128]
The Company historically offered revolving loans primarily to small and medium-sized commercial customers. During the fiscal year ended January 31, 2025, the Company discontinued remaining offerings under the revolving loan portfolio. The Company continued to support existing customer arrangements as well as to transition these customers to fixed-term offerings throughout the fiscal year ended January 30, 2026. As of January 30, 2026, the revolving loan portfolio is no longer a component of the Company’s financing receivables.

[0001571996-26-000008:notes:129]
Financing Receivables

[0001571996-26-000008:notes:130]
The following table presents the components of the Company’s financing receivables as of the dates indicated:

[0001571996-26-000008:notes:131]
|  |  |  |  |  | January 30, 2026 |  |  |  |  |  | January 31, 2025 |
|  |  |  |  |  | (in millions) |
| Financing receivables, net: |  |  |  |  |  |  |  |  |  |  |  |
| Customer receivables, gross (a) |  |  |  |  | $ | 14,295 |  |  |  |  |  |  | $ | 11,216 |  |
| Allowance for losses |  |  |  |  | (213) |  |  |  |  |  |  | (153) |  |
| Customer receivables, net |  |  |  |  | 14,082 |  |  |  |  |  |  | 11,063 |  |
| Residual interest |  |  |  |  | 198 |  |  |  |  |  |  | 168 |  |
| Financing receivables, net |  |  |  |  | $ | 14,280 |  |  |  |  |  |  | $ | 11,231 |  |
| Short-term |  |  |  |  | $ | 8,458 |  |  |  |  |  |  | $ | 5,304 |  |
| Long-term |  |  |  |  | $ | 5,822 |  |  |  |  |  |  | $ | 5,927 |  |

[0001571996-26-000008:notes:132]
(a)Customer receivables, gross include amounts due from customers under fixed-term leases, fixed-term loans, and accrued interest.

[0001571996-26-000008:notes:133]
The following table presents the changes in allowance for financing receivable losses for the periods indicated:

[0001571996-26-000008:notes:134]
|  |  |  |  |  |  |  | Fiscal Year Ended |
|  |  |  |  |  |  |  |  |  | January 30, 2026 |  |  |  |  |  | January 31, 2025 |  |  |  |  |  | February 2, 2024 |
|  |  |  |  |  |  |  |  |  | (in millions) |
| Allowance for financing receivable losses: |
| Balances at beginning of period |  |  |  |  |  |  |  |  | $ | 153 |  |  |  |  |  |  | $ | 170 |  |  |  |  |  |  | $ | 201 |  |
| Charge-offs, net of recoveries |  |  |  |  |  |  |  |  | (31) |  |  |  |  |  |  | (71) |  |  |  |  |  |  | (49) |  |
| Provision charged to income statement |  |  |  |  |  |  |  |  | 91 |  |  |  |  |  |  | 54 |  |  |  |  |  |  | 92 |  |
| Other (a) |  |  |  |  |  |  |  |  | — |  |  |  |  |  |  | — |  |  |  |  |  |  | (74) |  |
| Balances at end of period |  |  |  |  |  |  |  |  | $ | 213 |  |  |  |  |  |  | $ | 153 |  |  |  |  |  |  | $ | 170 |  |

[0001571996-26-000008:notes:135]
(a)Other represents the derecognition of the allowance for financing receivable losses related to the sale of the U.S. consumer revolving customer receivables portfolio described in Note 1 of the Notes to the Consolidated Financial Statements.

[0001571996-26-000008:notes:136]
The Company recognizes an allowance for financing receivable losses, including both the lease receivable and unguaranteed residual, in an amount equal to the expected losses, net of recoveries. The allowance for financing receivable losses on the lease receivable is determined based on various factors, including lifetime expected losses determined using macroeconomic forecast assumptions and management judgments applicable to and through the expected life of the portfolios as well as past due receivables, receivable type, and customer risk profile. The Company continues to monitor broader economic indicators and their potential impact on future credit loss performance.

[0001571996-26-000008:notes:137]
Aging

[0001571996-26-000008:notes:138]
The following table presents the aging of the Company’s customer financing receivables, gross, including accrued interest, as of the dates indicated:

[0001571996-26-000008:notes:139]
|  | January 30, 2026 |  | January 31, 2025 |
|  | (in millions) |
| Current 0 — 30 Days | $ | 13,985 |  |  | $ | 10,796 |  |
| Past Due 31 — 90 Days | 195 |  |  | 201 |  |
| Past Due > 90 Days | 115 |  |  | 219 |  |
| Total | $ | 14,295 |  |  | $ | 11,216 |  |

[0001571996-26-000008:notes:140]
Aging is likely to fluctuate as a result of the variability in volume of large transactions entered into over the period, and the administrative processes that accompany those transactions. Aging is also impacted by the timing of the Company’s fiscal period end date relative to calendar month-end customer payment due dates. As a result of these factors, fluctuations in aging from period to period do not necessarily indicate a material change in the collectibility of the portfolio.

[0001571996-26-000008:notes:141]
Customer receivables are placed on non-accrual status if principal or interest is past due and considered delinquent, or if there is concern about the collectibility of a specific customer receivable. The receivables identified as doubtful for collectibility may be classified as current for aging purposes.

[0001571996-26-000008:notes:142]
Credit Quality

[0001571996-26-000008:notes:143]
The following tables present customer receivables, gross, including accrued interest, by credit quality indicator, as of the dates indicated:

[0001571996-26-000008:notes:144]
|  | January 30, 2026 |
|  | Fiscal Year of Origination |  |  |
|  | 2026 |  | 2025 |  | 2024 |  | 2023 |  | 2022 |  | Years Prior |  | Total |
|  | (in millions) |
| Higher | $ | 2,671 |  |  | $ | 1,683 |  |  | $ | 1,430 |  |  | $ | 564 |  |  | $ | 84 |  |  | $ | 14 |  |  | $ | 6,446 |  |
| Mid | 4,077 |  |  | 1,354 |  |  | 419 |  |  | 163 |  |  | 22 |  |  | 1 |  |  | 6,036 |  |
| Lower | 1,153 |  |  | 321 |  |  | 209 |  |  | 109 |  |  | 11 |  |  | 10 |  |  | 1,813 |  |
| Total | $ | 7,901 |  |  | $ | 3,358 |  |  | $ | 2,058 |  |  | $ | 836 |  |  | $ | 117 |  |  | $ | 25 |  |  | $ | 14,295 |  |

[0001571996-26-000008:notes:145]
|  | January 31, 2025 |
|  | Fiscal Year of Origination |  |  |
|  | 2025 |  | 2024 |  | 2023 |  | 2022 |  | 2021 |  | Years Prior |  | Total |
|  | (in millions) |
| Higher | $ | 2,295 |  |  | $ | 2,160 |  |  | $ | 1,217 |  |  | $ | 357 |  |  | $ | 102 |  |  | $ | 4 |  |  | $ | 6,135 |  |
| Mid | 2,455 |  |  | 695 |  |  | 464 |  |  | 107 |  |  | 17 |  |  | 4 |  |  | 3,742 |  |
| Lower | 552 |  |  | 407 |  |  | 283 |  |  | 68 |  |  | 28 |  |  | 1 |  |  | 1,339 |  |
| Total | $ | 5,302 |  |  | $ | 3,262 |  |  | $ | 1,964 |  |  | $ | 532 |  |  | $ | 147 |  |  | $ | 9 |  |  | $ | 11,216 |  |

[0001571996-26-000008:notes:146]
The categories shown in the tables above segregate customer receivables, gross, based on the relative degrees of credit risk. Credit quality indicators are updated on a periodic basis. An internal grading system is utilized that assigns a credit level score based on a number of considerations, including liquidity, operating performance, and industry outlook.

[0001571996-26-000008:notes:147]
Leases

[0001571996-26-000008:notes:148]
The following table presents amounts included in the Consolidated Statements of Income related to sales-type lease activity for the periods indicated:

[0001571996-26-000008:notes:149]
|  |  |  | Fiscal Year Ended |
|  |  |  |  |  | January 30, 2026 |  | January 31, 2025 |  | February 2, 2024 |
|  |  |  |  |  | (in millions) |
| Interest income — products |  |  |  |  | $ | 357 |  |  | $ | 305 |  |  | $ | 175 |  |
| Net revenue — products |  |  |  |  | $ | 886 |  |  | $ | 1,992 |  |  | $ | 1,140 |  |
| Cost of net revenue — products |  |  |  |  | 798 |  |  | 1,703 |  |  | 854 |  |
| Gross margin — products |  |  |  |  | $ | 88 |  |  | $ | 289 |  |  | $ | 286 |  |

[0001571996-26-000008:notes:150]
The following table presents the future maturity of the Company’s customer leases and associated financing payments, and reconciles the undiscounted cash flows to the customer receivables, gross recognized on the Consolidated Statements of Financial Position as of the date indicated:

[0001571996-26-000008:notes:151]
|  | January 30, 2026 |
|  | (in millions) |
| Fiscal 2027 | $ | 3,217 |  |
| Fiscal 2028 | 1,892 |  |
| Fiscal 2029 | 1,170 |  |
| Fiscal 2030 | 504 |  |
| Fiscal 2031 and thereafter | 205 |  |
| Total undiscounted cash flows | 6,988 |  |
| Loans | 8,567 |  |
| Less: Unearned income | (1,260) |  |
| Total customer receivables, gross | $ | 14,295 |  |

[0001571996-26-000008:notes:152]
Operating Leases

[0001571996-26-000008:notes:153]
The Company’s operating leases primarily consist of fixed-term leases and contractually committed embedded leases identified within flexible consumption arrangements.

[0001571996-26-000008:notes:154]
The following table presents the components of the Company’s operating lease portfolio included in property, plant, and equipment, net as of the dates indicated:

[0001571996-26-000008:notes:155]
|  | January 30, 2026 |  | January 31, 2025 |
|  | (in millions) |
| Equipment under operating lease, gross | $ | 4,651 |  |  | $ | 4,180 |  |
| Less: Accumulated depreciation | (2,192) |  |  | (1,995) |  |
| Equipment under operating lease, net | $ | 2,459 |  |  | $ | 2,185 |  |

[0001571996-26-000008:notes:156]
The following table presents operating lease income related to lease payments and depreciation expense for the Company’s operating lease portfolio for the periods indicated:

[0001571996-26-000008:notes:157]
|  |  |  | Fiscal Year Ended |
|  |  |  |  |  | January 30, 2026 |  | January 31, 2025 |  | February 2, 2024 |
|  |  |  |  |  | (in millions) |
| Income related to lease payments |  |  |  |  | $ | 1,550 |  |  | $ | 1,473 |  |  | $ | 1,353 |  |
| Depreciation expense |  |  |  |  | $ | 1,001 |  |  | $ | 956 |  |  | $ | 941 |  |

[0001571996-26-000008:notes:158]
The following table presents the future payments to be received by the Company in operating lease contracts as of the date indicated:

[0001571996-26-000008:notes:159]
|  | January 30, 2026 |
|  | (in millions) |
| Fiscal 2027 | $ | 1,349 |  |
| Fiscal 2028 | 893 |  |
| Fiscal 2029 | 497 |  |
| Fiscal 2030 | 161 |  |
| Fiscal 2031 and thereafter | 82 |  |
| Total | $ | 2,982 |  |

[0001571996-26-000008:notes:160]
DFS Debt

[0001571996-26-000008:notes:161]
The Company maintains programs that facilitate the funding of leases, loans, and other alternative payment structures in the capital markets. The majority of DFS debt is non-recourse to Dell Technologies and represents borrowings under securitization programs and structured financing programs for which the Company’s risk of loss is limited to transferred lease and loan payments and associated equipment.

[0001571996-26-000008:notes:162]
The following table presents DFS debt as of the dates indicated and excludes the allocated portion of the Company’s other borrowings, which represents the additional amount considered to fund the DFS business:

[0001571996-26-000008:notes:163]
|  | January 30, 2026 |  | January 31, 2025 |
| DFS debt | (in millions) |
| DFS U.S. debt: |  |  |  |
| Asset-based financing facility | $ | 3,146 |  |  | $ | 3,018 |  |
| Fixed-term securitization offerings | 2,648 |  |  | 2,756 |  |
| Total DFS U.S. debt, principal amount | 5,794 |  |  | 5,774 |  |
| DFS international debt: |  |  |  |
| Securitization facility | 698 |  |  | 624 |  |
| Other borrowings | 851 |  |  | 754 |  |
| Dell Bank senior unsecured eurobonds | 1,796 |  |  | 1,559 |  |
| Total DFS international debt, principal amount | 3,345 |  |  | 2,937 |  |
| Total DFS debt, principal amount | $ | 9,139 |  |  | $ | 8,711 |  |
| Total short-term DFS debt | $ | 5,719 |  |  | $ | 5,175 |  |
| Total long-term DFS debt | $ | 3,420 |  |  | $ | 3,536 |  |

[0001571996-26-000008:notes:164]
DFS U.S. Debt

[0001571996-26-000008:notes:165]
Asset-Based Financing Facility — The Company maintains an asset-based financing facility in the United States, which is a revolving facility for fixed-term leases and loans. This debt is collateralized solely by the U.S. lease and loan payments and associated equipment in the facility. The asset-based financing facility consists of two tranches, with effective dates through July 7, 2026 and July 7, 2027, respectively. As of January 30, 2026, the total debt capacity related to the asset-based financing facility was $4.6 billion. The debt has a variable interest rate, and the duration of the debt is based on the terms of the underlying lease and loan payment streams. The Company enters into interest rate swap agreements to economically convert a portion of this debt from a floating rate to a fixed rate. See Note 8 of the Notes to the Consolidated Financial Statements for additional information about the Company’s interest rate swaps.

[0001571996-26-000008:notes:166]
The asset-based financing facility contains standard structural features related to the performance of the funded receivables, which include defined credit losses, delinquencies, average credit scores, and minimum collection requirements. In the event one or more of these criteria are not met and the Company is unable to restructure the facility, no further funding of receivables will be permitted and the timing of the Company’s expected cash flows from over-collateralization will be delayed. As of January 30, 2026, these criteria were met.

[0001571996-26-000008:notes:167]
Fixed-Term Securitization Offerings — The Company periodically issues asset-backed debt securities under fixed-term securitization programs to private investors. The asset-backed debt securities are collateralized solely by the U.S. fixed-term lease and loan payments and associated equipment, which are held by Special Purpose Entities (“SPEs”), as discussed below. The interest rate on these securities is fixed and ranges from 4.10% to 6.75% per annum as of January 30, 2026, and the duration of these securities is based on the terms of the underlying lease and loan payment streams.

[0001571996-26-000008:notes:168]
DFS International Debt

[0001571996-26-000008:notes:169]
Securitization Facility — The Company maintains a securitization facility in Europe for fixed-term leases and loans. The debt under this facility has a variable interest rate, and the duration of the debt is based on the terms of the underlying lease and loan payment streams. This facility is effective through December 22, 2026 and had a total debt capacity of $958 million as of January 30, 2026.

[0001571996-26-000008:notes:170]
The securitization facility contains standard structural features related to the performance of the securitized receivables, which include defined credit losses, delinquencies, average credit scores, and minimum collection requirements. In the event one or more of these criteria are not met and the Company is unable to restructure the program, no further funding of receivables will be permitted and the timing of the Company’s expected cash flows from over-collateralization will be delayed. As of January 30, 2026, these criteria were met.

[0001571996-26-000008:notes:171]
Other Borrowings — In connection with the Company’s international financing operations, the Company has entered into revolving structured financing debt programs related to its fixed-term lease and loan products sold in Canada, Europe, Australia and New Zealand, the Middle East, and Singapore. The debt under these programs has a variable interest rate.

[0001571996-26-000008:notes:172]
The duration of the debt in Canada, Europe, Australia and New Zealand, and the Middle East is based on the terms of the underlying lease and loan payment streams. These facilities are collateralized solely by the lease and loan payments and associated equipment in their respective region or country. The Canadian facility had a total debt capacity of $259 million as of January 30, 2026 and is effective through January 15, 2028. The European facility had a total debt capacity of $479 million as of January 30, 2026 and is effective through December 14, 2026. The Australia and New Zealand facility had a total debt capacity of $300 million as of January 30, 2026 and is effective through April 17, 2027. The Middle East facility had a total debt capacity of $150 million as of January 30, 2026 and is effective through March 14, 2027.

[0001571996-26-000008:notes:173]
The Company also has two unsecured Singapore facilities, which had a total debt capacity of $261 million as of January 30, 2026 and are effective through July 3, 2026 and July 3, 2027, respectively.

[0001571996-26-000008:notes:174]
Dell Bank Senior Unsecured Eurobonds — On October 27, 2021, Dell Bank issued 500 million Euro of 0.5% senior unsecured five-year eurobonds due October 2026. On October 18, 2022, Dell Bank issued 500 million Euro of 4.5% senior unsecured five-year eurobonds due October 2027. On June 13, 2024, Dell Bank issued 500 million Euro of 3.6% senior unsecured five-year eurobonds due June 2029. The issuances of the senior unsecured eurobonds support the expansion of the financing operations in Europe.

[0001571996-26-000008:notes:175]
Variable Interest Entities

[0001571996-26-000008:notes:176]
In connection with the asset-based financing facility, fixed-term securitization offerings, and securitization facility discussed above, the Company transfers certain U.S. and European lease and loan payments and associated equipment to SPEs that meet the definition of a VIE and are consolidated, along with the associated debt described above, into the Consolidated Financial Statements, as the Company is the primary beneficiary of the VIEs. The SPEs are bankruptcy-remote legal entities with separate assets and liabilities. The purpose of the SPEs is to facilitate the funding of customer lease and loan payments and associated equipment in the capital markets.

[0001571996-26-000008:notes:177]
Some of the SPEs have entered into financing arrangements with multi-seller conduits that, in turn, issue asset-backed debt securities in the capital markets. DFS debt outstanding held by the consolidated VIEs is collateralized by the lease and loan payments and associated equipment. The Company’s risk of loss related to securitized receivables is limited to the amount by which the Company’s right to receive collections for assets securitized exceeds the amount required to pay interest, principal, and fees and expenses related to the asset-backed securities. The Company provides credit enhancement to the securitization offerings in the form of over-collateralization.

[0001571996-26-000008:notes:178]
The following table presents the assets and liabilities held by the consolidated VIEs as of the dates indicated, which are included in the Consolidated Statements of Financial Position:

[0001571996-26-000008:notes:179]
|  | January 30, 2026 |  | January 31, 2025 |
|  | (in millions) |
| Assets held by consolidated VIEs |  |  |  |
| Other current assets | $ | 176 |  |  | $ | 123 |  |
| Financing receivables, net of allowance |  |  |  |
| Short-term | $ | 3,280 |  |  | $ | 3,262 |  |
| Long-term | $ | 2,704 |  |  | $ | 2,725 |  |
| Property, plant, and equipment, net | $ | 984 |  |  | $ | 984 |  |
| Liabilities held by consolidated VIEs |  |  |  |
| Debt, net of unamortized debt issuance costs |  |  |  |
| Short-term | $ | 4,548 |  |  | $ | 4,598 |  |
| Long-term | $ | 1,933 |  |  | $ | 1,788 |  |

[0001571996-26-000008:notes:180]
Lease and loan payments and associated equipment transferred via securitization through SPEs were $4.2 billion and $3.6 billion for the fiscal years ended January 30, 2026, and January 31, 2025, respectively.

[0001571996-26-000008:notes:181]
Customer Receivables Sales

[0001571996-26-000008:notes:182]
To manage certain concentrations of customer credit exposure, the Company may sell selected fixed-term customer receivables to unrelated third parties on a periodic basis, without recourse. The amounts of customer receivables sold for this purpose were immaterial for the fiscal years ended January 30, 2026, January 31, 2025, and February 2, 2024. The Company’s continuing involvement in these customer receivables is primarily limited to servicing arrangements.


## us-gaap:ScheduleOfDebtTableTextBlock

[0001571996-26-000008:notes:183]
The following table summarizes the Company’s outstanding debt as of the dates indicated:

[0001571996-26-000008:notes:184]
|  | January 30, 2026 |  | January 31, 2025 |
|  | (in millions) |
| Senior Notes | $ | 21,573 |  |  | $ | 15,073 |  |
| Legacy Notes | 952 |  |  | 952 |  |
| DFS Debt (Note 5) | 9,139 |  |  | 8,711 |  |
| Other | 99 |  |  | 52 |  |
| Total debt, principal amount | 31,763 |  |  | 24,788 |  |
| Unamortized discount, net of unamortized premium | (112) |  |  | (110) |  |
| Debt issuance costs | (148) |  |  | (111) |  |
| Total debt, carrying value | $ | 31,503 |  |  | $ | 24,567 |  |
| Total short-term debt, carrying value | $ | 7,990 |  |  | $ | 5,204 |  |
| Total long-term debt, carrying value | $ | 23,513 |  |  | $ | 19,363 |  |


## us-gaap:LesseeOperatingLeasesTextBlock

[0001571996-26-000008:notes:185]
LEASES 
The Company enters into leasing transactions in which the Company is the lessee. These lease contracts are typically classified as operating leases. The Company’s lease contracts are generally for office space used to conduct its business, and the determination of whether such contracts contain leases generally does not require significant estimates or judgments. The Company also leases certain property, equipment, and warehouses. As of January 30, 2026, the remaining terms of the Company’s leases generally range from one month to approximately ten years. As of January 30, 2026 and January 31, 2025, there were no material finance leases in which the Company was a lessee.

[0001571996-26-000008:notes:186]
The Company also enters into leasing transactions in which the Company is the lessor, primarily through customer financing arrangements offered under DFS. DFS originates leases that are primarily classified as either sales-type leases or operating leases. See Note 5 of the Notes to the Consolidated Financial Statements for more information about the Company’s lessor arrangements.

[0001571996-26-000008:notes:187]
The following table presents components of lease costs included in the Consolidated Statements of Income for the periods indicated:

[0001571996-26-000008:notes:188]
|  |  |  | Fiscal Year Ended |
|  |  |  |  |  | January 30, 2026 |  | January 31, 2025 |  | February 2, 2024 |
|  |  |  |  |  | (in millions) |
| Operating lease costs |  |  |  |  | $ | 239 |  |  | $ | 293 |  |  | $ | 291 |  |
| Variable costs |  |  |  |  | 77 |  |  | 62 |  |  | 80 |  |
| Total lease costs |  |  |  |  | $ | 316 |  |  | $ | 355 |  |  | $ | 371 |  |

[0001571996-26-000008:notes:189]
During the fiscal years ended January 30, 2026, January 31, 2025, and February 2, 2024, sublease income, finance lease costs, and short-term lease costs were immaterial.

[0001571996-26-000008:notes:190]
The following table presents supplemental information related to operating leases included in the Consolidated Statements of Financial Position as of the dates indicated:

[0001571996-26-000008:notes:191]
|  | Classification |  | January 30, 2026 |  | January 31, 2025 |  |  |
|  |  |  | (in millions, except for term and discount rate) |
| Operating lease right-of-use assets | Other non-current assets |  | $ | 640 |  | $ | 660 |  |  |
| Current operating lease liabilities | Accrued and other current liabilities |  | $ | 246 |  | $ | 236 |  |  |
| Non-current operating lease liabilities | Other non-current liabilities |  | 481 |  | 522 |  |  |
| Total operating lease liabilities |  |  | $ | 727 |  | $ | 758 |  |  |
| Weighted-average remaining lease term (in years) |  |  | 4.11 |  | 4.36 |  |  |
| Weighted-average discount rate |  |  | 4.74 | % |  | 5.14 | % |  |  |

[0001571996-26-000008:notes:192]
The following table presents supplemental cash flow information related to leases for the periods indicated:

[0001571996-26-000008:notes:193]
|  | Fiscal Year Ended |
|  | January 30, 2026 |  | January 31, 2025 |  | February 2, 2024 |
|  | (in millions) |
| Cash paid for amounts included in the measurement of lease liabilities — operating cash outflows from operating leases | $ | 260 |  |  | $ | 271 |  |  | $ | 300 |  |
| Right-of-use assets obtained in exchange for new operating lease liabilities | $ | 146 |  |  | $ | 184 |  |  | $ | 247 |  |

[0001571996-26-000008:notes:194]
The following table presents the future maturity of the Company’s operating lease liabilities under non-cancelable leases and reconciles the undiscounted cash flows for these leases to the lease liability recognized on the Consolidated Statements of Financial Position as of the date indicated:

[0001571996-26-000008:notes:195]
|  | January 30, 2026 |
|  | (in millions) |
| Fiscal 2027 | $ | 249 |  |
| Fiscal 2028 | 199 |  |
| Fiscal 2029 | 141 |  |
| Fiscal 2030 | 98 |  |
| Fiscal 2031 | 54 |  |
| Thereafter | 58 |  |
| Total lease payments | 799 |  |
| Less: Imputed interest | 72 |  |
| Total | $ | 727 |  |
| Current operating lease liabilities | $ | 246 |  |
| Non-current operating lease liabilities | $ | 481 |  |

[0001571996-26-000008:notes:196]
As of January 30, 2026, the Company’s undiscounted operating leases that had not yet commenced were immaterial.


## us-gaap:DebtDisclosureTextBlock

[0001571996-26-000008:notes:197]
DEBT
The following table summarizes the Company’s outstanding debt as of the dates indicated:

[0001571996-26-000008:notes:198]
The Company completed the following transactions during the fiscal year ended January 30, 2026:

[0001571996-26-000008:notes:199]
•the issuance on April 1, 2025 of $1.0 billion principal amount of 4.75% Senior Notes due April 2028, $1.0 billion principal amount of 5.00% Senior Notes due April 2030, $1.0 billion principal amount of 5.30% Senior Notes due April 2032, and $1.0 billion principal amount of 5.50% Senior Notes due April 2035, the proceeds of which were utilized for general corporate purposes; and

[0001571996-26-000008:notes:200]
•the issuance on October 6, 2025 of $0.75 billion principal amount of 4.15% Senior Notes due February 2029, $1.25 billion principal amount of 4.50% Senior Notes due February 2031, $1.25 billion principal amount of 4.75% Senior Notes due October 2032, and $1.25 billion principal amount of 5.10% Senior Notes due February 2036, the proceeds of which were utilized for general corporate purposes and to prepay a portion of the outstanding 6.02% Senior Notes due June 2026.

[0001571996-26-000008:notes:201]
Subsequent to the close of the fiscal year ended January 30, 2026, the Company repaid the remaining outstanding $0.5 billion principal amount of 6.02% Senior Notes due June 2026.

[0001571996-26-000008:notes:202]
Outstanding Debt

[0001571996-26-000008:notes:203]
Senior Notes — The Company completed offerings of multiple series of senior notes which were issued on June 1, 2016, June 22, 2016, March 20, 2019, April 9, 2020, December 13, 2021, January 24, 2023, March 18, 2024, October 8, 2024, April 1, 2025, and October 6, 2025 in aggregate principal amounts of $20.0 billion, $3.3 billion, $4.5 billion, $2.3 billion, $2.3 billion, $2.0 billion, $1.0 billion, $1.5 billion, $4.0 billion, and $4.5 billion, respectively (collectively, the “Senior Notes”). The Senior Notes have maturity dates ranging from 2026 through 2051. Interest rates on these borrowings are fixed, ranging from 3.38% to 8.35% per annum, and interest is payable semiannually.

[0001571996-26-000008:notes:204]
Legacy Notes — The Company has outstanding unsecured notes and debentures (collectively, the “Legacy Notes”) that were issued by Dell Inc. (“Dell”), a wholly-owned subsidiary of Dell Technologies Inc., prior to the acquisition of Dell by Dell Technologies Inc. in the going-private transaction that closed in October 2013. The Legacy Notes’ maturities range from 2028 through 2040. Interest rates on these borrowings are fixed, ranging from 5.40% to 7.10% per annum, and interest is payable semiannually.

[0001571996-26-000008:notes:205]
DFS Debt — See Note 5 and Note 8 of the Notes to the Consolidated Financial Statements, respectively, for discussion of DFS debt and the interest rate swap agreements that hedge a portion of that debt.

[0001571996-26-000008:notes:206]
Revolving Credit Facility — The Company’s revolving credit facility provides the Company with revolving commitments in an aggregate principal amount of $6.0 billion for general corporate purposes and includes a letter of credit sub-facility of up to $0.5 billion and a swing-line loan sub-facility of up to $0.5 billion. The revolving credit facility allows the Company to obtain incremental additional commitments on one or more occasions in minimum amounts of $10 million. The facility also acts as a backstop to provide liquidity support for the Company’s commercial paper program.

[0001571996-26-000008:notes:207]
Borrowings under the revolving credit facility bear interest at a rate per annum equal to an applicable margin plus, at the borrowers’ option, either (a) the specified adjusted term Secured Overnight Financing Rate (“SOFR”) or (b) a base rate. The margin applicable to SOFR and base rate borrowings varies based upon the Company’s existing credit ratings. The base rate is calculated based upon the greatest of the specified prime rate, the specified federal reserve bank rate, or SOFR plus 1%. The borrowers may voluntarily repay outstanding loans at any time without premium or penalty, other than customary breakage costs. The facility matures on November 1, 2027.

[0001571996-26-000008:notes:208]
As of January 30, 2026, the Company had no outstanding borrowings under the revolving credit facility.

[0001571996-26-000008:notes:209]
Commercial Paper Program — The Company maintains a commercial paper program under which the Company may issue unsecured notes in a maximum aggregate face amount of $5.0 billion outstanding at any time, with maturities of up to 397 days from the date of issuance. The notes are sold on customary terms in the U.S. commercial paper market on a private placement basis. The proceeds of the notes are used for general corporate purposes. As of January 30, 2026, the Company had no outstanding issuances under the commercial paper program.

[0001571996-26-000008:notes:210]
The Company may purchase, redeem, prepay, refinance, or otherwise retire any amount of outstanding indebtedness under the terms of such indebtedness at any time and from time to time, in open market or negotiated transactions with the holders of such indebtedness or otherwise, as considered appropriate in light of market conditions and other relevant factors.

[0001571996-26-000008:notes:211]
Covenants — The credit agreement governing the revolving credit facility and the indentures governing the Senior Notes and the Legacy Notes impose various limitations, subject to exceptions, on creating certain liens and entering into sale and lease-back transactions. The foregoing credit agreement and indentures contain customary events of default, and the revolving credit facility is subject to an interest coverage ratio covenant that is tested at the end of each fiscal quarter with respect to the Company’s preceding four fiscal quarters. The Company was in compliance with this financial covenant as of January 30, 2026.

[0001571996-26-000008:notes:212]
Aggregate Future Maturities

[0001571996-26-000008:notes:213]
The following table presents the aggregate future maturities of the Company’s debt as of January 30, 2026, excluding associated carrying value adjustments, for the periods indicated:

[0001571996-26-000008:notes:214]
|  | January 30, 2026 |
|  | (in millions) |
| Fiscal 2027 | $ | 7,997 |  |
| Fiscal 2028 | 2,975 |  |
| Fiscal 2029 | 2,615 |  |
| Fiscal 2030 | 3,878 |  |
| Fiscal 2031 | 1,763 |  |
| Thereafter | 12,535 |  |
| Total maturities, principal amount | $ | 31,763 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001571996-26-000008:notes:215]
DERIVATIVE INSTRUMENTS AND HEDGING ACTIVITIES 
As part of its risk management strategy, the Company uses derivative instruments, primarily foreign currency forward and option contracts and interest rate swaps, to hedge certain foreign currency and interest rate exposures, respectively.

[0001571996-26-000008:notes:216]
The Company’s objective is to offset gains and losses resulting from these exposures with gains and losses on the derivative contracts used to hedge the exposures, thereby reducing volatility of earnings and protecting the fair values of assets and liabilities. The earnings effects of the derivative instruments are presented in the same line items on the Consolidated Statements of Income as the earnings effects of the hedged items. For derivatives designated as cash flow hedges, the Company assesses hedge effectiveness both at the onset of the hedge and at regular intervals throughout the life of the instruments.

[0001571996-26-000008:notes:217]
Foreign Exchange Risk

[0001571996-26-000008:notes:218]
The Company uses foreign currency forward and option contracts designated as cash flow hedges to protect against the foreign currency exchange rate risks inherent in its forecasted transactions denominated in currencies other than the U.S. Dollar. Hedge accounting is applied based upon the criteria established by accounting guidance for derivative instruments and hedging activities. The risk of loss associated with purchased options is limited to premium amounts paid for the option contracts. The risk of loss associated with forward contracts is equal to the exchange rate differential from the time the contract is entered into until the time it is settled. The majority of these contracts typically expire in twelve months or less.

[0001571996-26-000008:notes:219]
During the fiscal years ended January 30, 2026, January 31, 2025, and February 2, 2024 the Company did not discontinue any cash flow hedges related to foreign exchange contracts that had a material impact on the Company’s results of operations due to the probability that the forecasted cash flows would not occur.

[0001571996-26-000008:notes:220]
The Company uses forward contracts to hedge monetary assets and liabilities denominated in a foreign currency. These contracts generally expire in three months or less, are considered economic hedges, and are not designated for hedge accounting. The change in the fair value of these instruments represents a natural hedge as their gains and losses offset the changes in the underlying fair value of the monetary assets and liabilities due to movements in currency exchange rates.

[0001571996-26-000008:notes:221]
In connection with DFS operations in Europe, forward contracts are used to hedge financing receivables denominated in foreign currencies other than Euro. These contracts are not designated for hedge accounting and most expire within three years or less.

[0001571996-26-000008:notes:222]
Interest Rate Risk

[0001571996-26-000008:notes:223]
The Company uses interest rate swaps to hedge the variability in cash flows related to the interest rate payments on structured financing debt. The interest rate swaps economically convert the variable rate on the structured financing debt to a fixed interest rate to match the underlying fixed rate being received on fixed-term customer leases and loans. These contracts are not designated for hedge accounting and most expire within four years or less.

[0001571996-26-000008:notes:224]
Interest rate swaps are utilized to manage the interest rate risk, at a portfolio level, associated with DFS operations in Europe. The interest rate swaps economically convert the fixed rate on financing receivables to a one-month or three-month Euribor floating rate in order to match the floating rate nature of the banks’ funding pool. The Company also uses interest rate swaps to manage the cash flows related to interest payments on Dell Bank senior unsecured eurobonds. The interest rate swaps economically convert the fixed rate on the eurobonds to a floating rate to match the underlying lease repayments profile. These contracts are not designated for hedge accounting and most expire within five years or less. See Note 5 of the Notes to the Consolidated Financial Statements for more information about the senior unsecured eurobonds.

[0001571996-26-000008:notes:225]
The Company utilizes cross-currency amortizing swaps to hedge the currency and interest rate risk exposure associated with the European securitization program. The cross-currency swaps combine a Euro-based interest rate swap with a British Pound or U.S. Dollar foreign exchange forward contract in which the Company pays a fixed or floating British Pound or U.S. Dollar amount and receives a fixed or floating amount in Euros linked to the one-month Euribor rate. The notional value of the swaps amortizes in line with the expected cash flows and runoff of the securitized assets. The swaps are not designated for hedge accounting and expire within five years or less.

[0001571996-26-000008:notes:226]
Derivative Instruments

[0001571996-26-000008:notes:227]
The following table presents the notional amounts of outstanding derivative instruments as of the dates indicated:

[0001571996-26-000008:notes:228]
|  | January 30, 2026 |  | January 31, 2025 |
|  | (in millions) |
| Foreign exchange contracts: |  |  |  |
| Designated as cash flow hedging instruments | $ | 7,491 |  |  | $ | 5,965 |  |
| Non-designated as hedging instruments | 5,887 |  |  | 5,683 |  |
| Total | $ | 13,378 |  |  | $ | 11,648 |  |
| Interest rate contracts: |  |  |  |
| Non-designated as hedging instruments | $ | 7,048 |  |  | $ | 6,353 |  |

[0001571996-26-000008:notes:229]
The following table presents the effect of derivative instruments designated as cash flow hedging instruments on the Consolidated Statements of Financial Position and the Consolidated Statements of Income for the periods indicated:

[0001571996-26-000008:notes:230]
| Derivatives in Cash Flow Hedging Relationships |  | Gain (Loss) Recognized in Accumulated OCI, Net of Tax, on Derivatives |  | Location of Gain (Loss) Reclassified from Accumulated OCI into Income |  | Gain (Loss) Reclassified from Accumulated OCI into Income |
|  |  | (in millions) |  |  |  | (in millions) |
| For the fiscal year ended January 30, 2026: |
|  |  |  |  | Total net revenue |  | $ | (187) |  |
| Foreign exchange contracts |  | $ | (432) |  |  | Total cost of net revenue |  | (11) |  |
| Total |  | $ | (432) |  |  | Total |  | $ | (198) |  |
| For the fiscal year ended January 31, 2025: |
|  |  |  |  | Total net revenue |  | $ | 100 |  |
| Foreign exchange contracts |  | $ | 246 |  |  | Total cost of net revenue |  | 11 |  |
| Total |  | $ | 246 |  |  | Total |  | $ | 111 |  |
| For the fiscal year ended February 2, 2024: |
|  |  |  |  | Total net revenue |  | $ | (98) |  |
| Foreign exchange contracts |  | $ | 85 |  |  | Total cost of net revenue |  | (9) |  |
| Total |  | $ | 85 |  |  | Total |  | $ | (107) |  |

[0001571996-26-000008:notes:231]
The following table presents the effect of derivative instruments not designated as hedging instruments on the Consolidated Statements of Income for the periods indicated:

[0001571996-26-000008:notes:232]
|  |  |  | Fiscal Year Ended |  |  |
|  |  |  |  |  | January 30, 2026 |  | January 31, 2025 |  | February 2, 2024 |  | Location of Gain (Loss) Recognized |
|  |  |  |  |  | (in millions) |  |  |
| Foreign exchange contracts |  |  |  |  | $ | 438 |  |  | $ | (214) |  |  | $ | (35) |  |  | Interest and other, net |
| Interest rate contracts |  |  |  |  | (39) |  |  | 27 |  |  | — |  |  | Interest and other, net |
| Total |  |  |  |  | $ | 399 |  |  | $ | (187) |  |  | $ | (35) |  |  |  |

[0001571996-26-000008:notes:233]
The Company presents its derivative instruments on a net basis in the Consolidated Statements of Financial Position due to the right of offset by its counterparties under master netting arrangements. The following tables present the fair value of those derivative instruments presented on a gross basis as of the dates indicated:

[0001571996-26-000008:notes:234]
|  | January 30, 2026 |
|  | Other Current Assets |  | Other Non-Current Assets |  | Other Current Liabilities |  | Other Non-Current Liabilities |  | Total Fair Value |
|  | (in millions) |
| Derivatives designated as hedging instruments: |
| Foreign exchange contracts in an asset position | $ | 26 |  |  | $ | — |  |  | $ | 13 |  |  | $ | — |  |  | $ | 39 |  |
| Foreign exchange contracts in a liability position | (54) |  |  | — |  |  | (59) |  |  | — |  |  | (113) |  |
| Net asset (liability) | (28) |  |  | — |  |  | (46) |  |  | — |  |  | (74) |  |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts in an asset position | 291 |  |  | 1 |  |  | 119 |  |  | — |  |  | 411 |  |
| Foreign exchange contracts in a liability position | (146) |  |  | — |  |  | (169) |  |  | — |  |  | (315) |  |
| Interest rate contracts in an asset position | 5 |  |  | 37 |  |  | — |  |  | — |  |  | 42 |  |
| Interest rate contracts in a liability position | — |  |  | — |  |  | — |  |  | (30) |  |  | (30) |  |
| Net asset (liability) | 150 |  |  | 38 |  |  | (50) |  |  | (30) |  |  | 108 |  |
| Total derivatives at fair value | $ | 122 |  |  | $ | 38 |  |  | $ | (96) |  |  | $ | (30) |  |  | $ | 34 |  |
|  | January 31, 2025 |
|  | Other Current Assets |  | Other Non-Current Assets |  | Other Current Liabilities |  | Other Non-Current Liabilities |  | Total Fair Value |
|  | (in millions) |
| Derivatives designated as hedging instruments: |
| Foreign exchange contracts in an asset position | $ | 136 |  |  | $ | — |  |  | $ | 9 |  |  | $ | — |  |  | $ | 145 |  |
| Foreign exchange contracts in a liability position | (7) |  |  | — |  |  | (3) |  |  | — |  |  | (10) |  |
| Net asset (liability) | 129 |  |  | — |  |  | 6 |  |  | — |  |  | 135 |  |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts in an asset position | 430 |  |  | — |  |  | 53 |  |  | — |  |  | 483 |  |
| Foreign exchange contracts in a liability position | (297) |  |  | — |  |  | (90) |  |  | — |  |  | (387) |  |
| Interest rate contracts in an asset position | — |  |  | 40 |  |  | — |  |  | — |  |  | 40 |  |
| Interest rate contracts in a liability position | — |  |  | — |  |  | (1) |  |  | (43) |  |  | (44) |  |
| Net asset (liability) | 133 |  |  | 40 |  |  | (38) |  |  | (43) |  |  | 92 |  |
| Total derivatives at fair value | $ | 262 |  |  | $ | 40 |  |  | $ | (32) |  |  | $ | (43) |  |  | $ | 227 |  |

[0001571996-26-000008:notes:235]
The following tables present the gross amounts of the Company’s derivative instruments, amounts offset due to master netting agreements with the Company’s counterparties, and the net amounts recognized in the Consolidated Statements of Financial Position as of the dates indicated:

[0001571996-26-000008:notes:236]
|  | January 30, 2026 |
|  | Gross Amounts of Recognized Assets/(Liabilities) |  | Gross Amounts Offset in the Statement of Financial Position |  | Net Amounts of Assets/(Liabilities) Presented in the Statement of Financial Position |  | Gross Amounts not Offset in the Statement of Financial Position |  | Net Amount of Assets/ (Liabilities) Recognized in the Statement of Financial Position |
|  | Financial Instruments |  | Cash Collateral Received or Pledged |  |
|  | (in millions) |
| Derivative instruments: |  |  |  |  |  |  |  |  |  |  |  |
| Financial assets | $ | 492 |  |  | $ | (332) |  |  | $ | 160 |  |  | $ | — |  |  | $ | (46) |  |  | $ | 114 |  |
| Financial liabilities | (458) |  |  | 332 |  |  | (126) |  |  | — |  |  | 1 |  |  | (125) |  |
| Total derivative instruments | $ | 34 |  |  | $ | — |  |  | $ | 34 |  |  | $ | — |  |  | $ | (45) |  |  | $ | (11) |  |
|  | January 31, 2025 |
|  | Gross Amounts of Recognized Assets/(Liabilities) |  | Gross Amounts Offset in the Statement of Financial Position |  | Net Amounts of Assets/(Liabilities) Presented in the Statement of Financial Position |  | Gross Amounts not Offset in the Statement of Financial Position |  | Net Amount of Assets/ (Liabilities) Recognized in the Statement of Financial Position |
|  | Financial Instruments |  | Cash Collateral Received or Pledged |  |
|  | (in millions) |
| Derivative instruments: |  |  |  |  |  |  |  |  |  |  |  |
| Financial assets | $ | 668 |  |  | $ | (366) |  |  | $ | 302 |  |  | $ | — |  |  | $ | (36) |  |  | $ | 266 |  |
| Financial liabilities | (441) |  |  | 366 |  |  | (75) |  |  | — |  |  | 8 |  |  | (67) |  |
| Total derivative instruments | $ | 227 |  |  | $ | — |  |  | $ | 227 |  |  | $ | — |  |  | $ | (28) |  |  | $ | 199 |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001571996-26-000008:notes:237]
GOODWILL AND INTANGIBLE ASSETS
Goodwill

[0001571996-26-000008:notes:238]
The Infrastructure Solutions Group (“ISG”) and Client Solutions Group (“CSG”) reporting units are consistent with the reportable segments identified in Note 18 of the Notes to the Consolidated Financial Statements. Corporate and other consists of results of VMware Resale, Virtustream, and Secureworks prior to the sale of Secureworks as discussed in Note 1 of the Notes to the Consolidated Financial Statements, each of which represents a separate reporting unit not classified as a reportable segment, either individually or collectively.

[0001571996-26-000008:notes:239]
The following table presents goodwill allocated to the Company’s reportable segments and changes in the carrying amount of goodwill as of the dates indicated:

[0001571996-26-000008:notes:240]
|  | Infrastructure Solutions Group |  | Client Solutions Group |  | Corporate and other |  | Total |
|  | (in millions) |
| Balances as of February 2, 2024 | $ | 15,041 |  |  | $ | 4,232 |  |  | $ | 427 |  |  | $ | 19,700 |  |
| Impact of foreign currency translation and other | (153) |  |  | — |  |  | — |  |  | (153) |  |
| Reclassification to assets held for sale (a) | — |  |  | — |  |  | (427) |  |  | (427) |  |
| Balances as of January 31, 2025 | $ | 14,888 |  |  | $ | 4,232 |  |  | $ | — |  |  | $ | 19,120 |  |
| Impact of foreign currency translation | 366 |  |  | — |  |  | — |  |  | 366 |  |
| Goodwill acquired | 61 |  |  | — |  |  | — |  |  | 61 |  |
| Balances as of January 30, 2026 | $ | 15,315 |  |  | $ | 4,232 |  |  | $ | — |  |  | $ | 19,547 |  |

[0001571996-26-000008:notes:241]
(a)During the fiscal year ended January 31, 2025, Secureworks goodwill was reclassified to current assets held for sale on the Consolidated Statements of Financial Position. The sale of Secureworks was completed during the three months ended May 2, 2025. See Note 1 of the Notes to the Consolidated Financial Statements for additional information about the sale of Secureworks.

[0001571996-26-000008:notes:242]
Intangible Assets

[0001571996-26-000008:notes:243]
The following table presents the Company’s intangible assets as of the dates indicated:

[0001571996-26-000008:notes:244]
|  | January 30, 2026 |  | January 31, 2025 |
|  | Gross |  | Accumulated Amortization |  | Net |  | Gross |  | Accumulated Amortization |  | Net |
|  | (in millions) |
| Customer relationships | $ | 16,644 |  |  | $ | (15,321) |  |  | $ | 1,323 |  |  | $ | 16,642 |  |  | $ | (15,013) |  |  | $ | 1,629 |  |
| Developed technology | 9,525 |  |  | (9,376) |  |  | 149 |  |  | 9,500 |  |  | (9,211) |  |  | 289 |  |
| Trade names | 875 |  |  | (869) |  |  | 6 |  |  | 875 |  |  | (860) |  |  | 15 |  |
| Definite-lived intangible assets | 27,044 |  |  | (25,566) |  |  | 1,478 |  |  | 27,017 |  |  | (25,084) |  |  | 1,933 |  |
| Indefinite-lived trade names | 3,055 |  |  | — |  |  | 3,055 |  |  | 3,055 |  |  | — |  |  | 3,055 |  |
| Total intangible assets | $ | 30,099 |  |  | $ | (25,566) |  |  | $ | 4,533 |  |  | $ | 30,072 |  |  | $ | (25,084) |  |  | $ | 4,988 |  |

[0001571996-26-000008:notes:245]
Amortization expense related to definite-lived intangible assets was $0.5 billion, $0.7 billion and $0.8 billion for the fiscal years ended January 30, 2026, January 31, 2025 and February 2, 2024, respectively. There were no material impairment charges related to intangible assets during the fiscal years ended January 30, 2026, January 31, 2025 and February 2, 2024.

[0001571996-26-000008:notes:246]
The following table presents the estimated future annual pre-tax amortization expense of definite-lived intangible assets as of the date indicated:

[0001571996-26-000008:notes:247]
|  | January 30, 2026 |
|  | (in millions) |
| Fiscal 2027 | $ | 377 |  |
| Fiscal 2028 | 235 |  |
| Fiscal 2029 | 195 |  |
| Fiscal 2030 | 158 |  |
| Fiscal 2031 | 134 |  |
| Thereafter | 379 |  |
| Total | $ | 1,478 |  |

[0001571996-26-000008:notes:248]
Goodwill and Indefinite-Lived Intangible Assets Impairment Testing

[0001571996-26-000008:notes:249]
Goodwill and indefinite-lived intangible assets are tested for impairment annually during the third fiscal quarter and whenever events or circumstances may indicate that an impairment has occurred.

[0001571996-26-000008:notes:250]
During the three months ended October 31, 2025, the Company performed the annual assessment for goodwill in each of its reporting units and indefinite-lived intangible assets. The Company is permitted to conduct a qualitative assessment to determine whether it is necessary to perform a quantitative goodwill impairment test. The Company’s qualitative assessment included consideration of the relevant events and circumstances affecting the reporting unit, including macroeconomic, industry and market conditions, recent market transactions, overall financial performance, trends in the public company market valuation, changes in projected future cash flows, and the results of the most recent quantitative assessment, where applicable. Based on this assessment, the Company concluded that it was more likely than not that the estimated fair value of the reporting units and indefinite-lived intangible assets were higher than their respective carrying values. No goodwill or indefinite-lived assets impairment test was performed during the fiscal year ended January 30, 2026 other than the Company’s annual impairment review.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001571996-26-000008:notes:251]
DEFERRED REVENUE 
Deferred revenue consists of support and deployment services, software maintenance, training, Software-as-a-Service, and undelivered hardware and professional services, consisting of installations and consulting engagements. Deferred revenue is recorded when the Company has invoiced or payments have been received for undelivered products or services, or in situations where revenue recognition criteria have not been met. Revenue is recognized as the Company’s performance obligations under the contract are completed.

[0001571996-26-000008:notes:252]
The following table presents the changes in the Company’s deferred revenue for the periods indicated:

[0001571996-26-000008:notes:253]
|  |  |  | Fiscal Year Ended |
|  |  |  |  |  | January 30, 2026 |  | January 31, 2025 |
|  |  |  |  |  | (in millions) |
| Deferred revenue: |  |  |  |  |  |  |  |
| Deferred revenue at beginning of period |  |  |  |  | $ | 25,965 |  |  | $ | 29,145 |  |
| Revenue deferrals |  |  |  |  | 21,014 |  |  | 18,135 |  |
| Revenue recognized |  |  |  |  | (20,050) |  |  | (21,179) |  |
| Other (a) |  |  |  |  | 1 |  |  | (136) |  |
| Deferred revenue at end of period |  |  |  |  | $ | 26,930 |  |  | $ | 25,965 |  |
| Short-term deferred revenue |  |  |  |  | $ | 13,334 |  |  | $ | 13,673 |  |
| Long-term deferred revenue |  |  |  |  | $ | 13,596 |  |  | $ | 12,292 |  |

[0001571996-26-000008:notes:254]
(a) Other represents adjustments to deferred revenue for acquisition and divestiture activities. For the fiscal year ended January 31, 2025, Other represents the reclassification of Secureworks deferred revenue to liabilities held for sale. See Note 1 of the Notes to the Consolidated Financial Statements for more information about the sale of Secureworks.

[0001571996-26-000008:notes:255]
Remaining Performance Obligations — Remaining performance obligations represent the aggregate amount of the transaction price allocated to performance obligations not delivered, or partially undelivered, as of the end of the reporting period. Remaining performance obligations include deferred revenue plus unbilled amounts not yet recorded in deferred revenue. The value of the transaction price allocated to remaining performance obligations as of January 30, 2026 was approximately $82 billion. The Company expects to recognize approximately 78% of remaining performance obligations as revenue in the next twelve months, approximately 11% in the following twelve months, and the remainder thereafter.

[0001571996-26-000008:notes:256]
The aggregate amount of the transaction price allocated to remaining performance obligations does not include amounts owed under cancelable contracts where there is no substantive termination penalty. The Company applied the practical expedient to exclude the value of remaining performance obligations for contracts for which revenue is recognized at the amount to which the Company has the right to invoice for services performed.

[0001571996-26-000008:notes:257]
Remaining performance obligation estimates are subject to change and are affected by multiple factors, including terminations, changes in the scope of contracts, periodic revalidation, adjustments for revenue that have not materialized, and adjustments for currency.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001571996-26-000008:notes:258]
COMMITMENTS AND CONTINGENCIES 
Purchase Obligations

[0001571996-26-000008:notes:259]
The Company has contractual obligations to purchase goods or services, which specify significant terms (including fixed or minimum quantities to be purchased), fixed, minimum, or variable price provisions, and the approximate timing of the transaction. Purchase obligations are primarily related to commitments with suppliers and software maintenance and support services. Other purchase obligations include the non-cancelable portion or the minimum cancellation fee under the contract. As of January 30, 2026, such purchase obligations were $16.8 billion for Fiscal 2027, $0.6 billion for Fiscal 2028, $0.7 billion for Fiscal 2029, $0.3 billion for Fiscal 2030, and $0.4 billion for Fiscal 2031 and thereafter.

[0001571996-26-000008:notes:260]
Legal Matters

[0001571996-26-000008:notes:261]
The Company is involved in various claims, suits, assessments, investigations, and legal proceedings that arise from time to time in the ordinary course of its business, including those identified below, consisting of matters involving consumer, antitrust, tax, intellectual property, and other issues on a global basis.

[0001571996-26-000008:notes:262]
The Company accrues a liability when it believes that it is both probable that a liability has been incurred and that it can reasonably estimate the amount of the loss. The Company reviews these accruals at least quarterly and adjusts them to reflect ongoing negotiations, settlements, rulings, advice of legal counsel, and other relevant information. To the extent new information is obtained and the Company’s views on the probable outcomes of claims, suits, assessments, investigations, or legal proceedings change, changes in the Company’s accrued liabilities are recorded in the period in which such a determination is made. For some matters, the incurrence of a liability is not probable or the amount cannot be reasonably estimated and therefore accruals have not been made.

[0001571996-26-000008:notes:263]
Class Action Relating to Dell 401(k) Plan — On January 28, 2026, a complaint was filed in the U.S. District Court for the Western District of Texas in a putative class action captioned Lowbruck et al. v. Dell Technologies Inc., et al., against the Company, the Company’s Board of Directors, and the Dell Benefits Administration Committee alleging a breach of fiduciary duties under the Employment Retirement Income Security Act of 1974 (“ERISA”). In the complaint, the plaintiffs seek a judicial declaration that the defendants breached their fiduciary duties by failing to remove imprudent investments from the Dell 401(k) (“Plan”) in a reasonable time, engaging in transactions allegedly prohibited under ERISA, and failing to monitor the fiduciaries responsible for the Plan’s administration. The plaintiffs also seek, among other remedies, an award of damages, fees, and costs in an unspecified amount. The Company intends to vigorously defend this action.

[0001571996-26-000008:notes:264]
In accordance with the relevant accounting guidance, the Company provides disclosures of matters where it is at least reasonably possible that the Company could experience a material loss exceeding the amounts already accrued for across all proceedings or matters. In addition, the Company also discloses matters based on its consideration of other matters and qualitative factors, including the experience of other companies in the industry, and investor, customer, and employee relations considerations. As of January 30, 2026, the Company does not believe there is a reasonable possibility that a material loss exceeding the amounts already accrued for across all proceedings or matters has been incurred. However, since the ultimate resolution of any such proceedings and matters is inherently unpredictable, the Company’s business, financial condition, results of operations, or cash flows could be materially affected in any particular period by unfavorable outcomes in one or more of these proceedings or matters. Whether the outcome of any claim, suit, assessment, investigation, or legal proceeding, individually or collectively, could have a material adverse effect on the Company’s business, financial condition, results of operations, or cash flows will depend on a number of factors, including the nature, timing, and amount of any associated expenses, amounts paid in settlement, damages, or other remedies or consequences.

[0001571996-26-000008:notes:265]
Indemnifications Obligations

[0001571996-26-000008:notes:266]
In the ordinary course of business, the Company enters into various contracts under which it may agree to indemnify other parties for losses incurred from certain events as defined in the relevant contract, such as litigation, regulatory penalties, or claims relating to past performance. Such indemnification obligations may not be subject to maximum loss clauses. Historically, payments related to these indemnification obligations have not been material to the Company.

[0001571996-26-000008:notes:267]
Under the Separation and Distribution Agreement entered into with VMware, Inc. upon completion of its spin-off of VMware, Inc. on November 1, 2021, Dell Technologies agreed to indemnify VMware, Inc., each of its subsidiaries and each of their respective directors, officers, employees, as well as any successors and assigns of the foregoing, from and against all liabilities relating to, arising out of or resulting from, among other matters, the liabilities allocated to Dell Technologies as part of the separation of Dell Technologies and VMware, Inc. (currently operating under the name VMware LLC, and individually and together with its subsidiaries, “VMware”) and their respective businesses (the “Separation”). VMware similarly agreed to indemnify Dell Technologies Inc., each of its subsidiaries and each of their respective directors, officers, and employees from and against all liabilities relating to, arising out of or resulting from, among other matters, the liabilities allocated to VMware as part of the Separation. The amounts that VMware and Dell Technologies may be obligated to pay each other could vary depending on the outcome of certain unresolved tax matters, which may not be resolved for several years. Net income tax indemnification receivables from VMware were immaterial as of January 30, 2026 and January 31, 2025.

[0001571996-26-000008:notes:268]
Certain Concentrations

[0001571996-26-000008:notes:269]
The Company maintains cash and cash equivalents, derivatives, and certain other financial instruments with various financial institutions that potentially subject it to concentration of credit risk. As part of its risk management processes, the Company performs periodic evaluations of the relative credit standing of these financial institutions. The Company has not sustained material credit losses from instruments held at these financial institutions. Further, the Company does not expect nonperformance by any of the counterparties.

[0001571996-26-000008:notes:270]
The Company markets and sells its products and services to large corporate clients, governmental agencies, and health care and education accounts, as well as to small and medium-sized businesses and individuals. One customer accounted for 12% of the Company’s consolidated net revenue for the fiscal year ended January 30, 2026, with substantially all of such net revenue attributable to the sale of ISG offerings. No single customer accounted for 10% or more of the Company’s consolidated net revenue for the fiscal years ended January 31, 2025 and February 2, 2024.

[0001571996-26-000008:notes:271]
The Company utilizes a limited number of contract manufacturers that assemble a portion of its products. The Company purchases components from suppliers and sells those components to such contract manufacturers. The Company reflects the sale of such components by recognizing non-trade receivables from the contract manufacturers and a reduction in inventory when title and risk of loss pass to the manufacturer. Cash flows related to such transactions are recorded within cash flows from operating activities. The Company does not reflect the sale of the components in revenue and does not recognize any profit on the component sales until the Company sells the related products to the customer. The agreements with the majority of the contract manufacturers permit the Company to offset its payables against the receivables, thus mitigating the credit risk wholly or in part. Such receivables were $13.2 billion and $5.4 billion as of January 30, 2026 and January 31, 2025, respectively, and primarily consisted of receivables from the Company’s three largest contract manufacturers. The Company offset its corresponding payables against $13.0 billion and $4.7 billion of such receivables as of January 30, 2026 and January 31, 2025, respectively. The portion of receivables not offset is included in other current assets in the Consolidated Statements of Financial Position.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001571996-26-000008:notes:272]
INCOME AND OTHER TAXES
The following table presents components of income (loss) before income taxes for the periods indicated:

[0001571996-26-000008:notes:273]
|  | Fiscal Year Ended |
|  | January 30, 2026 |  | January 31, 2025 |  | February 2, 2024 |
|  | (in millions) |
| Domestic | $ | 986 |  |  | $ | (73) |  |  | $ | (52) |  |
| Foreign | 6,277 |  |  | 5,121 |  |  | 4,139 |  |
| Income before income taxes | $ | 7,263 |  |  | $ | 5,048 |  |  | $ | 4,087 |  |

[0001571996-26-000008:notes:274]
The following table presents components of the income tax expense (benefit) recognized for the periods indicated:

[0001571996-26-000008:notes:275]
|  | Fiscal Year Ended |
|  | January 30, 2026 |  | January 31, 2025 |  | February 2, 2024 |
|  | (in millions) |
| Current: |  |  |  |  |  |
| Federal | $ | 299 |  |  | $ | (84) |  |  | $ | 161 |  |
| State/local | 164 |  |  | (21) |  |  | 33 |  |
| Foreign | 924 |  |  | 785 |  |  | 612 |  |
| Current | 1,387 |  |  | 680 |  |  | 806 |  |
| Deferred: |  |  |  |  |  |
| Federal | (51) |  |  | (220) |  |  | (106) |  |
| State/local | 10 |  |  | (12) |  |  | (42) |  |
| Foreign | (19) |  |  | 24 |  |  | 57 |  |
| Deferred | (60) |  |  | (208) |  |  | (91) |  |
| Income tax expense | $ | 1,327 |  |  | $ | 472 |  |  | $ | 715 |  |

[0001571996-26-000008:notes:276]
The following table presents a reconciliation of the Company’s effective tax rate to the statutory U.S. federal tax rate for the period ended January 30, 2026, in accordance with the guidance in ASU 2023-09:

[0001571996-26-000008:notes:277]
|  | Fiscal Year Ended |
|  | January 30, 2026 |  |  |  |  |
|  | Amount |  | Percent |  |  |  |  |  |  |  |  |
|  | (in millions, except percentages) |  |  |  |  |  |  |  |  |
| U.S. federal statutory tax rate | $ | 1,525 |  |  | 21.0 | % |  |  |  |  |  |  |  |  |
| State and local income taxes, net of federal income tax effect | 166 |  |  | 2.3 |  |  |  |  |  |  |  |  |  |
| Foreign tax effects: |  |  |  |  |  |  |  |  |  |  |  |
| Singapore: |  |  |  |  |  |  |  |  |  |  |  |
| Impact of reduced tax rate | (447) |  |  | (6.1) |  |  |  |  |  |  |  |  |  |
| Other | (179) |  |  | (2.5) |  |  |  |  |  |  |  |  |  |
| Other foreign jurisdictions | 175 |  |  | 2.4 |  |  |  |  |  |  |  |  |  |
| Effect of cross-border tax laws | 127 |  |  | 1.8 |  |  |  |  |  |  |  |  |  |
| Nontaxable or nondeductible items | (87) |  |  | (1.2) |  |  |  |  |  |  |  |  |  |
| Tax credits | (110) |  |  | (1.5) |  |  |  |  |  |  |  |  |  |
| Changes in unrecognized tax benefits | 148 |  |  | 2.0 |  |  |  |  |  |  |  |  |  |
| Other adjustments | 9 |  |  | 0.1 |  |  |  |  |  |  |  |  |  |
| Total | $ | 1,327 |  |  | 18.3 | % |  |  |  |  |  |  |  |  |

[0001571996-26-000008:notes:278]
The following table presents a reconciliation of the Company’s effective tax rate to the statutory U.S. federal tax rate for the periods indicated, in accordance with the guidance prior to the adoption of ASU 2023-09:

[0001571996-26-000008:notes:279]
|  | Fiscal Year Ended |
|  | January 31, 2025 |  | February 2, 2024 |
| U.S. federal statutory rate | 21.0 | % |  | 21.0 | % |
| State income taxes, net of federal tax benefit | 1.4 |  |  | (0.2) |  |
| Tax impact of foreign operations | 0.6 |  |  | 2.1 |  |
| Change in valuation allowance | 1.1 |  |  | 0.3 |  |
| Non-deductible transaction-related costs | 0.1 |  |  | — |  |
| Stock-based compensation expense | (4.0) |  |  | (0.9) |  |
| U.S. R&D tax credits | (1.7) |  |  | (4.3) |  |
| Lapse of U.S. statutes of limitations | (8.5) |  |  | — |  |
| Other | (0.6) |  |  | (0.5) |  |
| Total | 9.4 | % |  | 17.5 | % |

[0001571996-26-000008:notes:280]
Changes related to the Company’s effective tax rates for the fiscal years ended January 30, 2026, January 31, 2025, and February 2, 2024 were primarily attributable to discrete tax items and a change in the Company’s jurisdictional mix of income related to the tax impact of foreign operations and benefits from U.S. research and development tax credits. The Company’s effective tax rate for the fiscal year ended January 31, 2025 included discrete tax benefits of $0.4 billion related to the expiration of certain U.S. statutes of limitations and $0.2 billion related to stock-based compensation.

[0001571996-26-000008:notes:281]
On July 4, 2025, the One Big Beautiful Bill Act (“OBBBA”) was enacted into law in the United States. The new law contains a broad range of tax reform provisions, which include the extension and modification of certain provisions of the Tax Cuts and Jobs Act. Effective for the fiscal year ended January 30, 2026, changes include, but are not limited to, immediate expensing of domestic research and development expenditures, the restoration of 100% bonus depreciation, and an EBITDA-based interest expense limitation. These provisions did not have a material impact on the Company’s Consolidated Financial Statements for the fiscal year ended January 30, 2026.

[0001571996-26-000008:notes:282]
The impact of reduced tax rate for Singapore shown in the rate reconciliation table for the fiscal year ended January 30, 2026, and the tax impact of foreign operations for the fiscal years ended January 31, 2025, and February 2, 2024 shown in the rate reconciliation table for those fiscal years, reflect tax benefits from a tax holiday in one of the Company’s subsidiaries in Singapore. The tax holiday is in effect until January 31, 2029 and may be extended when certain conditions are met or may be terminated early if certain conditions are not met or as a result of changes in legislation. As of January 30, 2026, the Company was not aware of any matters of non-compliance related to this tax holiday or enacted tax legislative changes affecting this tax holiday. For the fiscal year ended January 30, 2026, the overall income tax benefit attributable to this tax holiday was estimated to be approximately $0.4 billion ($0.58 per share). For the fiscal years ended January 31, 2025 and February 2, 2024, the overall income tax benefits attributable to the tax status of the affected subsidiary were immaterial to the Company’s provision for income taxes and earnings per share.

[0001571996-26-000008:notes:283]
As of January 30, 2026, the Company has not recognized a deferred tax liability for the undistributed earnings of certain foreign subsidiaries that remain indefinitely reinvested. A significant portion of these undistributed earnings would not be subject to further U.S. federal taxation. Determination of the amount of unrecognized deferred tax liability related to these undistributed earnings is not practicable.

[0001571996-26-000008:notes:284]
The following table presents the components of the Company’s net deferred tax assets (liabilities) as of the dates indicated:

[0001571996-26-000008:notes:285]
|  | January 30, 2026 |  | January 31, 2025 |
|  | (in millions) |
| Deferred tax assets: |  |  |  |
| Deferred revenue and warranty provisions | $ | 2,104 |  |  | $ | 1,769 |  |
| Credit carryforwards | 778 |  |  | 670 |  |
| Loss carryforwards | 847 |  |  | 697 |  |
| Operating and compensation related accruals | 470 |  |  | 482 |  |
| Capitalized research and development | 111 |  |  | 291 |  |
| Other | 334 |  |  | 256 |  |
| Deferred tax assets (a) | 4,644 |  |  | 4,165 |  |
| Valuation allowance | (1,709) |  |  | (1,368) |  |
| Deferred tax assets, net of valuation allowance | 2,935 |  |  | 2,797 |  |
| Deferred tax liabilities: |  |  |  |
| Leasing and financing | (305) |  |  | (285) |  |
| Property and equipment | (278) |  |  | (273) |  |
| Intangibles | (218) |  |  | (240) |  |
| Other | (396) |  |  | (393) |  |
| Deferred tax liabilities (a) | (1,197) |  |  | (1,191) |  |
| Net deferred tax assets | $ | 1,738 |  |  | $ | 1,606 |  |

[0001571996-26-000008:notes:286]
(a)Deferred tax assets and deferred tax liabilities are included in other non-current assets and other non-current liabilities in the Consolidated Statements of Financial Position.

[0001571996-26-000008:notes:287]
The following tables present the net operating loss carryforwards, tax credit carryforwards, and other deferred tax assets with related valuation allowances recognized as of the dates indicated:

[0001571996-26-000008:notes:288]
|  | January 30, 2026 |  |  |
|  | Deferred Tax Assets |  | Valuation Allowance |  | Net Deferred Tax Assets |  | First Year Expiring |
|  | (in millions) |  |  |
| Credit carryforwards | $ | 778 |  |  | $ | (764) |  |  | $ | 14 |  |  | Fiscal 2027 |
| Loss carryforwards | 847 |  |  | (660) |  |  | 187 |  |  | Fiscal 2027 |
| Other deferred tax assets | 3,019 |  |  | (285) |  |  | 2,734 |  |  | NA |
| Total | $ | 4,644 |  |  | $ | (1,709) |  |  | $ | 2,935 |  |  |  |
|  | January 31, 2025 |  |  |
|  | Deferred Tax Assets |  | Valuation Allowance |  | Net Deferred Tax Assets |  | First Year Expiring |
|  | (in millions) |  |  |
| Credit carryforwards | $ | 670 |  |  | $ | (664) |  |  | $ | 6 |  |  | Fiscal 2026 |
| Loss carryforwards | 697 |  |  | (484) |  |  | 213 |  |  | Fiscal 2026 |
| Other deferred tax assets | 2,798 |  |  | (220) |  |  | 2,578 |  |  | NA |
| Total | $ | 4,165 |  |  | $ | (1,368) |  |  | $ | 2,797 |  |  |  |

[0001571996-26-000008:notes:289]
The Company’s credit carryforwards as of January 30, 2026 and January 31, 2025 relate to U.S. tax credits that include state tax credits associated with research and development and U.S. foreign tax credits associated with the U.S. Tax Cuts and Jobs Act, as well as foreign tax credits from non-U.S. jurisdictions. The Company assessed the realizability of these tax credits and has recorded a valuation allowance against the credits it does not expect to utilize. The Company’s loss carryforwards as of January 30, 2026 and January 31, 2025 include net operating loss carryforwards from federal, state, and foreign jurisdictions. The valuation allowances for other deferred tax assets as of January 30, 2026 and January 31, 2025 primarily relate to foreign jurisdictions, the changes in which are included in the tax impact of foreign operations in the Company’s effective tax reconciliation. The Company has determined that it will be able to realize the remainder of its deferred tax assets.

[0001571996-26-000008:notes:290]
The following table presents the changes in the valuation allowance for deferred tax assets for the periods indicated:

[0001571996-26-000008:notes:291]
|  | Fiscal Year Ended |
|  | January 30, 2026 |  | January 31, 2025 |  | February 2, 2024 |
|  | (in millions) |
| Balance at beginning of period | $ | 1,368 |  |  | $ | 1,232 |  |  | $ | 1,535 |  |
| Charged to income tax provision | 274 |  |  | 277 |  |  | (299) |  |
| Charged to other accounts | 67 |  |  | (141) |  |  | (4) |  |
| Balance at end of period | $ | 1,709 |  |  | $ | 1,368 |  |  | $ | 1,232 |  |

[0001571996-26-000008:notes:292]
The following table presents a reconciliation of the Company’s beginning and ending balances of unrecognized tax benefits for the periods indicated:

[0001571996-26-000008:notes:293]
|  | Fiscal Year Ended |
|  | January 30, 2026 |  | January 31, 2025 |  | February 2, 2024 |
|  | (in millions) |
| Balance at beginning of period | $ | 1,976 |  |  | $ | 2,367 |  |  | $ | 1,812 |  |
| Increases related to tax positions of the current year | 133 |  |  | 121 |  |  | 4 |  |
| Increases related to tax position of prior years | 86 |  |  | 37 |  |  | 828 |  |
| Reductions for tax positions of prior years | (54) |  |  | (129) |  |  | (177) |  |
| Lapse of statutes of limitations | (29) |  |  | (388) |  |  | (35) |  |
| Audit settlements | (15) |  |  | (32) |  |  | (65) |  |
| Balance at end of period | $ | 2,097 |  |  | $ | 1,976 |  |  | $ | 2,367 |  |

[0001571996-26-000008:notes:294]
The table above does not include accrued interest and penalties of $0.3 billion as of January 30, 2026, $0.2 billion as of January 31, 2025, and $0.4 billion as of February 2, 2024. The table also does not include certain tax benefits associated with interest and state tax deductions and other indirect jurisdictional effects of uncertain tax positions, which were $1.3 billion as of both January 30, 2026 and January 31, 2025, and $1.4 billion as of February 2, 2024.

[0001571996-26-000008:notes:295]
After taking these items into account, the Company’s net unrecognized tax benefits were $1.1 billion as of January 30, 2026, $0.9 billion as of January 31, 2025, and $1.3 billion as of February 2, 2024, and are included in other non-current liabilities in the Consolidated Statements of Financial Position.

[0001571996-26-000008:notes:296]
The unrecognized tax benefits in the table above include $1.0 billion, $0.9 billion, and $1.2 billion as of January 30, 2026, January 31, 2025, and February 2, 2024, respectively, that, if recognized, would have impacted income tax expense. Interest and penalties related to income tax liabilities are included in income tax expense. The impact of interest and penalties on the Company’s tax provision was immaterial for the fiscal years ended January 30, 2026, January 31, 2025, and February 2, 2024.

[0001571996-26-000008:notes:297]
In June 2023, the Company received a Revenue Agent’s Report for the federal income tax examination by the Internal Revenue Service (“IRS”) of fiscal years 2018 through 2019. The IRS proposed significant adjustments primarily relating to certain transactions the Company completed as part of its business integration efforts. In August 2023, the Company submitted a written protest to the IRS relating to certain assessments. The Company received a rebuttal from the IRS to its written protest in April 2024. The Company disagrees with the IRS’s proposed adjustments and will contest them through the IRS administrative appeals procedures. The Company expects to continue discussions with the IRS Independent Office of Appeals throughout the next fiscal year and anticipates that the appeals process for the resolution of these matters will extend beyond the next twelve months. The IRS is also currently conducting a federal income tax examination of the Company for fiscal years 2020 through 2022.

[0001571996-26-000008:notes:298]
The Company is also currently under income tax audits in various U.S. state and foreign taxing jurisdictions. The Company is undergoing negotiations, and in some cases contested proceedings, relating to tax matters with the taxing authorities in these jurisdictions. With respect to major U.S. state and foreign taxing jurisdictions, the Company is generally not subject to tax examinations for years prior to the fiscal year ended February 2, 2018. Judgment is required in evaluating the Company’s uncertain tax positions and determining the Company’s provision for income taxes. The Company believes that it has provided adequate reserves related to all matters contained in tax periods open to examination, including the IRS audits described above. Although the Company believes it has made adequate provisions for the uncertainties with respect to these audits, should the Company experience unfavorable outcomes, such outcomes could have a material impact on its results of operations, financial position, and cash flows.

[0001571996-26-000008:notes:299]
The Company takes certain non-income tax positions in the jurisdictions in which it operates and has received certain non-income tax assessments from various jurisdictions. The Company believes that a material loss in these matters is not probable and that it is not reasonably possible that a material loss exceeding amounts already accrued has been incurred. The Company believes its positions in these non-income tax litigation matters are supportable and that it ultimately will prevail in the matters. In the normal course of business, the Company’s positions and conclusions related to its non-income taxes could be challenged and assessments may be made. To the extent new information is obtained and the Company’s views on its positions, probable outcomes of assessments, or litigation change, changes in estimates to the Company’s accrued liabilities would be recorded in the period in which such a determination is made. In the resolution process for income tax and non-income tax audits, the Company is required in certain situations to provide collateral guarantees or indemnification to regulators and tax authorities until the matter is resolved.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001571996-26-000008:notes:300]
ACCUMULATED OTHER COMPREHENSIVE INCOME (LOSS) 
Accumulated other comprehensive income (loss) is presented in stockholders’ equity (deficit) in the Consolidated Statements of Financial Position and consists of amounts related to foreign currency translation adjustments, unrealized net gains (losses) on cash flow hedges, and actuarial net gains (losses) from pension and other postretirement plans.

[0001571996-26-000008:notes:301]
The following table presents changes in accumulated other comprehensive income (loss), net of tax, by the following components as of the dates indicated:

[0001571996-26-000008:notes:302]
|  | Foreign Currency Translation Adjustments |  |  |  | Cash Flow Hedges |  | Pension and Other Postretirement Plans |  | Accumulated Other Comprehensive Income (Loss) |
|  | (in millions) |
| Balances as of February 3, 2023 | $ | (747) |  |  |  |  | $ | (222) |  |  | $ | (32) |  |  | $ | (1,001) |  |
| Other comprehensive income (loss) before reclassifications | (8) |  |  |  |  | 85 |  |  | 15 |  |  | 92 |  |
| Amounts reclassified from accumulated other comprehensive income (loss) | — |  |  |  |  | 107 |  |  | 2 |  |  | 109 |  |
| Total change for the period | (8) |  |  |  |  | 192 |  |  | 17 |  |  | 201 |  |
| Balances as of February 2, 2024 | $ | (755) |  |  |  |  | $ | (30) |  |  | $ | (15) |  |  | $ | (800) |  |
| Other comprehensive income (loss) before reclassifications | (268) |  |  |  |  | 246 |  |  | — |  |  | (22) |  |
| Amounts reclassified from accumulated other comprehensive income (loss) | — |  |  |  |  | (111) |  |  | (6) |  |  | (117) |  |
| Total change for the period | (268) |  |  |  |  | 135 |  |  | (6) |  |  | (139) |  |
| Balances as of January 31, 2025 | $ | (1,023) |  |  |  |  | $ | 105 |  |  | $ | (21) |  |  | $ | (939) |  |
| Other comprehensive income (loss) before reclassifications | 450 |  |  |  |  | (432) |  |  | (2) |  |  | 16 |  |
| Amounts reclassified from accumulated other comprehensive income (loss) | — |  |  |  |  | 198 |  |  | (2) |  |  | 196 |  |
| Sale of Secureworks (a) | 8 |  |  |  |  | — |  |  | — |  |  | 8 |  |
| Total change for the period | 458 |  |  |  |  | (234) |  |  | (4) |  |  | 220 |  |
| Balances as of January 30, 2026 | $ | (565) |  |  |  |  | $ | (129) |  |  | $ | (25) |  |  | $ | (719) |  |

[0001571996-26-000008:notes:303]
(a)See Note 1 of the Notes to the Consolidated Financial Statements for more information about the sale of Secureworks.

[0001571996-26-000008:notes:304]
Amounts related to the Company’s cash flow hedges are reclassified to net income during the same period in which the items being hedged are recognized in earnings. See Note 8 of the Notes to the Consolidated Financial Statements for more information about the Company’s derivative instruments.

[0001571996-26-000008:notes:305]
The following tables present reclassifications out of accumulated other comprehensive income (loss), net of tax, to net income for the periods indicated:

[0001571996-26-000008:notes:306]
|  |  |  | Fiscal Year Ended |
|  |  |  | January 30, 2026 |  | January 31, 2025 |  | February 2, 2024 |
|  |  |  | Cash Flow Hedges |  |  |  |  |  | Pensions |  |  |  | Total |  | Cash Flow Hedges |  | Pensions |  | Total |  | Cash Flow Hedges |  | Pensions |  | Total |
|  |  |  | (in millions) |
| Total reclassifications, net of tax: |  |  |  |  |  |  |
| Net revenue |  |  | $ | (187) |  |  |  |  |  |  | $ | — |  |  |  |  | $ | (187) |  |  | $ | 100 |  |  | $ | — |  |  | $ | 100 |  |  | $ | (98) |  |  | $ | — |  |  | $ | (98) |  |
| Cost of net revenue |  |  | (11) |  |  |  |  |  |  | — |  |  |  |  | (11) |  |  | 11 |  |  | — |  |  | 11 |  |  | (9) |  |  | — |  |  | (9) |  |
| Operating expenses |  |  | — |  |  |  |  |  |  | (1) |  |  |  |  | (1) |  |  | — |  |  | 6 |  |  | 6 |  |  | — |  |  | (2) |  |  | (2) |  |
| Interest and other, net |  |  | — |  |  |  |  |  |  | 3 |  |  |  |  | 3 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Total reclassifications, net of tax |  |  | $ | (198) |  |  |  |  |  |  | $ | 2 |  |  |  |  | $ | (196) |  |  | $ | 111 |  |  | $ | 6 |  |  | $ | 117 |  |  | $ | (107) |  |  | $ | (2) |  |  | $ | (109) |  |


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001571996-26-000008:notes:307]
CAPITALIZATION 
The following table presents the Company’s authorized, issued, and outstanding common stock as of the dates indicated:

[0001571996-26-000008:notes:308]
|  | Authorized |  | Issued |  | Outstanding |
|  | (in millions) |
| Common stock as of January 30, 2026 |
| Class A | 600 |  |  | 277 |  |  | 277 |  |
| Class B | 200 |  |  | 52 |  |  | 52 |  |
| Class C | 7,900 |  |  | 515 |  |  | 323 |  |
| Class D | 100 |  |  | — |  |  | — |  |
|  | 8,800 |  |  | 844 |  |  | 652 |  |
| Common stock as of January 31, 2025 |
| Class A | 600 |  |  | 277 |  |  | 277 |  |
| Class B | 200 |  |  | 62 |  |  | 62 |  |
| Class C | 7,900 |  |  | 495 |  |  | 357 |  |
| Class D | 100 |  |  | — |  |  | — |  |
|  | 8,800 |  |  | 834 |  |  | 696 |  |

[0001571996-26-000008:notes:309]
Preferred Stock

[0001571996-26-000008:notes:310]
The Company is authorized to issue one million shares of preferred stock, par value $0.01 per share. As of January 30, 2026 and January 31, 2025, no shares of preferred stock were issued or outstanding.

[0001571996-26-000008:notes:311]
Common Stock

[0001571996-26-000008:notes:312]
Dell Technologies Common Stock — The Class A Common Stock, the Class B Common Stock, the Class C Common Stock, and the Class D Common Stock are collectively referred to as Dell Technologies Common Stock. The par value for all series of Dell Technologies Common Stock is $0.01 per share. The Class A Common Stock, the Class B Common Stock, the Class C Common Stock, and the Class D Common Stock share equally in dividends declared or accumulated and have equal participation rights in undistributed earnings.

[0001571996-26-000008:notes:313]
Voting Rights — Each holder of record of (a) Class A Common Stock is entitled to ten votes per share of Class A Common Stock; (b) Class B Common Stock is entitled to ten votes per share of Class B Common Stock; (c) Class C Common Stock is entitled to one vote per share of Class C Common Stock; and (d) Class D Common Stock is not entitled to any vote on any matter except to the extent required by provisions of Delaware law (in which case such holder is entitled to one vote per share of Class D Common Stock).

[0001571996-26-000008:notes:314]
Conversion Rights — Under the Company’s certificate of incorporation, at any time and from time to time, any holder of Class A Common Stock or Class B Common Stock has the right to convert all or any of the shares of Class A Common Stock or Class B Common Stock, as applicable, held by such holder into shares of Class C Common Stock on a one-to-one basis.

[0001571996-26-000008:notes:315]
During the fiscal year ended January 30, 2026, the Company issued approximately 10 million shares of Class C Common Stock to stockholders upon the conversion of an immaterial number of shares of Class A Common Stock shares and 10 million shares of Class B Common Stock in accordance with the Company’s certificate of incorporation.

[0001571996-26-000008:notes:316]
During the fiscal year ended January 31, 2025, the Company issued 100 million shares of Class C Common Stock to stockholders upon the conversion of 76 million shares of Class A Common Stock and 24 million shares of Class B Common Stock in accordance with the Company’s certificate of incorporation.

[0001571996-26-000008:notes:317]
During the fiscal year ended February 2, 2024, the Company issued 34 million shares of Class C Common Stock to stockholders upon the conversion of 25 million shares of Class A Common Stock and 9 million shares of Class B Common Stock in accordance with the Company’s certificate of incorporation.

[0001571996-26-000008:notes:318]
Dividends

[0001571996-26-000008:notes:319]
The Company paid the following dividends during the periods presented:

[0001571996-26-000008:notes:320]
|  |  | Declaration Date |  | Record Date |  | Payment Date |  | Dividend per Share |  | Amount (in millions) |
|  |  | Fiscal 2026 |
|  |  | February 27, 2025 |  | April 22, 2025 |  | May 2, 2025 |  | $ | 0.525 |  |  | $ | 360 |  |
|  |  | June 17, 2025 |  | July 22, 2025 |  | August 1, 2025 |  | $ | 0.525 |  |  | $ | 355 |  |
|  |  | September 4, 2025 |  | October 21, 2025 |  | October 31, 2025 |  | $ | 0.525 |  |  | $ | 351 |  |
|  |  | December 4, 2025 |  | January 20, 2026 |  | January 30, 2026 |  | $ | 0.525 |  |  | $ | 344 |  |
|  |  | Fiscal 2025 |
|  |  | February 29, 2024 |  | April 23, 2024 |  | May 3, 2024 |  | $ | 0.445 |  |  | $ | 316 |  |
|  |  | June 11, 2024 |  | July 23, 2024 |  | August 2, 2024 |  | $ | 0.445 |  |  | $ | 314 |  |
|  |  | September 18, 2024 |  | October 22, 2024 |  | November 1, 2024 |  | $ | 0.445 |  |  | $ | 312 |  |
|  |  | December 3, 2024 |  | January 22, 2025 |  | January 31, 2025 |  | $ | 0.445 |  |  | $ | 310 |  |

[0001571996-26-000008:notes:321]
During the fiscal years ended January 30, 2026 and January 31, 2025, the Company also paid an immaterial amount of dividend equivalents on eligible vested equity awards which are not included above.

[0001571996-26-000008:notes:322]
On February 26, 2026, subsequent to the close of the Company’s fiscal year ended January 30, 2026, the Company announced that the Board of Directors approved a 20% increase in the quarterly dividend rate to $0.630 per share per fiscal quarter beginning in the first quarter of the fiscal year ending January 29, 2027.

[0001571996-26-000008:notes:323]
Repurchases of Common Stock

[0001571996-26-000008:notes:324]
On September 23, 2021, the Company’s Board of Directors approved the Company’s current stock repurchase program with no fixed expiration date under which the Company may repurchase a specified dollar value of Class C Common Stock, exclusive of any fees, commissions, or other expenses related to such repurchases. As of January 30, 2026, the Company’s Board of Directors authorized the repurchase of up to $20 billion of Class C Common Stock and on February 26, 2026, subsequent to the close of the fiscal year ended January 30, 2026, authorized an additional $10 billion of Class C Common Stock for repurchase. Following the February 26, 2026 approval, the Company had approximately $15.2 billion of authorized shares remaining for repurchase under the program.

[0001571996-26-000008:notes:325]
During the fiscal year ended January 30, 2026, the Company repurchased approximately 54 million shares of Class C Common Stock for a total purchase price of approximately $6.0 billion. During the fiscal year ended January 31, 2025, the Company repurchased approximately 22 million shares of Class C Common Stock for a total purchase price of approximately $2.6 billion. During the fiscal year ended February 2, 2024, the Company repurchased approximately 34 million shares of Class C Common Stock for a total purchase price of approximately $2.1 billion.
The above repurchases of Class C Common Stock exclude U.S. federal excise taxes and shares withheld from equity awards to settle employee tax withholding obligations related to the vesting of such awards.


## us-gaap:EarningsPerShareTextBlock

[0001571996-26-000008:notes:326]
EARNINGS PER SHARE
Basic earnings per share is based on the weighted-average effect of all common shares issued and outstanding and is calculated by dividing net income by the weighted-average shares outstanding during the period. Diluted earnings per share is calculated by dividing net income by the weighted-average number of common shares used in the basic earnings per share calculation plus the number of common shares that would be issued assuming exercise or conversion of all potentially dilutive instruments. The Company excludes equity instruments from the calculation of diluted earnings per share if the effect of including such instruments is antidilutive.

[0001571996-26-000008:notes:327]
The following table presents basic and diluted earnings per share for the periods indicated:

[0001571996-26-000008:notes:328]
|  |  |  | Fiscal Year Ended |
|  |  |  |  |  | January 30, 2026 |  | January 31, 2025 |  | February 2, 2024 |
| Earnings per share attributable to Dell Technologies Inc. |  |  |
| Dell Technologies Common Stock — Basic |  |  |  |  | $ | 8.79 |  |  | $ | 6.51 |  |  | $ | 4.71 |  |
| Dell Technologies Common Stock — Diluted |  |  |  |  | $ | 8.68 |  |  | $ | 6.38 |  |  | $ | 4.60 |  |

[0001571996-26-000008:notes:329]
The following table presents the computation of basic and diluted earnings per share for the periods indicated:

[0001571996-26-000008:notes:330]
|  |  |  | Fiscal Year Ended |
|  |  |  |  |  | January 30, 2026 |  | January 31, 2025 |  | February 2, 2024 |
|  |  |  |  |  | (in millions) |
| Numerator: Dell Technologies Common Stock |  |  |  |  |  |  |  |  |  |
| Net income attributable to Dell Technologies Inc. — basic and diluted |  |  |  |  | $ | 5,936 |  |  | $ | 4,592 |  |  | $ | 3,388 |  |
| Denominator: Dell Technologies Common Stock weighted-average shares outstanding |  |  |  |  |  |  |  |  |  |
| Weighted-average shares outstanding — basic |  |  |  |  | 675 |  |  | 705 |  |  | 720 |  |
| Dilutive effect of equity awards |  |  |  |  | 9 |  |  | 15 |  |  | 16 |  |
| Weighted-average shares outstanding — diluted |  |  |  |  | 684 |  |  | 720 |  |  | 736 |  |
| Weighted-average shares outstanding — antidilutive |  |  |  |  | 1 |  |  | — |  |  | 4 |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001571996-26-000008:notes:331]
STOCK-BASED COMPENSATION 
The following table presents stock-based compensation expense recognized in the Consolidated Statements of Income for the periods indicated:

[0001571996-26-000008:notes:332]
|  | Fiscal Year Ended |
|  | January 30, 2026 |  | January 31, 2025 |  | February 2, 2024 |
|  | (in millions) |
| Stock-based compensation expense: |  |  |  |  |  |
| Cost of net revenue | $ | 157 |  |  | $ | 152 |  |  | $ | 149 |  |
| Operating expenses | 566 |  |  | 633 |  |  | 729 |  |
| Total stock-based compensation expense before taxes | 723 |  |  | 785 |  |  | 878 |  |
| Income tax benefit | (135) |  |  | (143) |  |  | (157) |  |
| Total stock-based compensation expense, net of income taxes | $ | 588 |  |  | $ | 642 |  |  | $ | 721 |  |

[0001571996-26-000008:notes:333]
Dell Technologies Inc. Stock-Based Compensation Plan

[0001571996-26-000008:notes:334]
Dell Technologies Inc. 2023 Stock Incentive Plan — Employees, consultants, non-employee directors, and other service providers of the Company or its affiliates are eligible to participate in the Dell Technologies Inc. 2023 Stock Incentive Plan, which became effective on June 20, 2023 upon its approval by stockholders (the “2023 Plan”). The 2023 Plan authorizes the Company to grant stock options, RSUs, stock appreciation rights (“SARs”), restricted stock awards, deferred stock units, and dividend equivalents. The 2023 Plan replaced the Dell Technologies Inc. 2013 Stock Incentive Plan (as amended and restated, the “2013 Plan”). Upon effectiveness of the 2023 Plan, no further awards were authorized for grant under the 2013 Plan.

[0001571996-26-000008:notes:335]
The 2023 Plan authorizes the issuance of an aggregate of up to approximately 103.3 million shares of the Class C Common Stock, including (a) 50.0 million shares of Class C Common Stock that were authorized for offering and issuance under the 2023 Plan, (b) approximately 7.0 million shares of Class C Common Stock that remained available for issuance under the 2013 Plan as of the effective date of the 2023 Plan, and (c) up to approximately 46.3 million shares of Class C Common Stock subject to awards outstanding under the 2013 Plan as of the effective date of the 2023 Plan that subsequently expire or terminate prior to exercise or settlement. As of January 30, 2026, there were approximately 45 million shares of Class C Common Stock available for future grants under the 2023 Plan.

[0001571996-26-000008:notes:336]
Restricted Stock — The Company’s awards primarily consist of RSUs granted to employees. During the fiscal years ended January 30, 2026, January 31, 2025, and February 2, 2024, the Company granted long-term incentive awards in the form of service-based RSUs and performance-based RSUs (“PSUs”) in order to align critical talent retention programs with the interests of holders of the Class C Common Stock. Each service-based RSU represents the right to acquire one share of Class C Common Stock upon vesting.

[0001571996-26-000008:notes:337]
The PSUs granted during the periods presented are reflected as target units for performance periods not yet complete. The actual number of units that ultimately vest will range from 0% to 200% of the target number, based on the level of achievement of the performance goals and continued employment with the Company over a three-year performance period. Vesting of approximately half of the PSUs granted is subject to achievement of market-based performance goals based on relative total shareholder return and vesting of the remaining PSUs is subject to achievement of internal financial performance measures.

[0001571996-26-000008:notes:338]
The following table presents the assumptions utilized in the Monte Carlo valuation model for the periods indicated:

[0001571996-26-000008:notes:339]
|  | Fiscal Year Ended |
|  | January 30, 2026 |  | January 31, 2025 |  | February 2, 2024 |
| Weighted-average grant date fair value | $ | 116.03 |  | $ | 172.99 |  | $ | 43.91 |
| Term (in years) | 3 |  | 3 |  | 3 |
| Risk-free rate (U.S. Government Treasury Note) | 3.9 | % |  | 4.4 | % |  | 3.8 | % |
| Expected volatility | 47 | % |  | 39 | % |  | 35 | % |
| Expected dividend yield | — | % |  | — | % |  | — | % |

[0001571996-26-000008:notes:340]
The following table presents RSU activity settled in Class C Common Stock for the periods indicated:

[0001571996-26-000008:notes:341]
|  | Number of Units |  | Weighted-Average Grant Date Fair Value |  | Aggregate Intrinsic Value (a) |
|  | (in millions) |  | (per unit) |  |  |
| Outstanding as of February 3, 2023 | 50 |  |  | $ | 39.44 |  |  |  |
| Granted | 23 |  |  | 39.62 |  |  |  |
| Vested | (31) |  |  | 32.02 |  |  |  |
| Forfeited | (3) |  |  | 46.99 |  |  |  |
| Outstanding as of February 2, 2024 | 39 |  |  | 44.68 |  |  |  |
| Granted | 9 |  |  | 102.35 |  |  |  |
| Vested | (18) |  |  | 43.33 |  |  |  |
| Forfeited | (4) |  |  | 56.93 |  |  |  |
| Outstanding as of January 31, 2025 | 26 |  |  | 60.51 |  |  |  |
| Granted | 8 |  |  | 86.52 |  |  |  |
| Vested | (14) |  |  | 52.90 |  |  |  |
| Forfeited | (1) |  |  | 76.09 |  |  |  |
| Outstanding as of January 30, 2026 (b) | 19 |  |  | $ | 76.42 |  |  | $ | 2,164 |  |
| Vested and expected to vest, January 30, 2026 | 18 |  |  | $ | 75.50 |  |  | $ | 2,083 |  |

[0001571996-26-000008:notes:342]
(a)The aggregate intrinsic value represents the total pre-tax intrinsic values based on the closing price of $114.44 of the Class C Common Stock on January 30, 2026 as reported on the NYSE that would have been received by the RSU holders if the RSUs had been issued as of January 30, 2026.

[0001571996-26-000008:notes:343]
(b)As of January 30, 2026, the 19 million units outstanding included 14 million RSUs and 5 million PSUs.

[0001571996-26-000008:notes:344]
The total fair value of RSU awards that vested during the fiscal years ended January 30, 2026, January 31, 2025, and February 2, 2024 was $0.7 billion, $0.8 billion, and $1.0 billion, respectively, with a pre-tax intrinsic value of $1.4 billion, $2.0 billion, and $1.2 billion, respectively.

[0001571996-26-000008:notes:345]
As of January 30, 2026, there was $0.7 billion of unrecognized stock-based compensation expense, net of estimated forfeitures, related to these awards expected to be recognized over a weighted-average period of approximately 1.7 years.

[0001571996-26-000008:notes:346]
Dell Technologies Shares Withheld for Taxes — Shares of Class C Common Stock are generally withheld from issuance to cover employee taxes for the vesting of restricted stock units. For the fiscal years ended January 30, 2026, January 31, 2025, and February 2, 2024, 4 million, 5 million, and 9 million shares, respectively, were withheld to cover $0.4 billion, $0.6 billion, and $0.4 billion, respectively, of employees’ tax obligations. The value of the withheld shares was classified as a reduction to common stock and capital in excess of par value.
Stock Option Activity — Stock options are granted with option exercise prices equal to the fair market value of the Company’s Class C Common Stock and expire ten years after the grant date. On September 30, 2025, the Compensation Committee of the Board of Directors approved a stock option grant to the Chief Operating Officer to purchase 2.5 million shares of the Company’s Class C Common Stock (the “COO option award”) under the 2023 Plan. The COO option award has a ten-year term, an exercise price of $141.77 per share, and a grant date fair value of approximately $132 million, of which the Company recognized an immaterial amount of compensation expense for the fiscal year ended January 30, 2026. Vesting in the stock option award is contingent upon achievement of a Company market capitalization goal, a Company adjusted free cash flow performance goal as of January 31, 2031, and continued service through March 15, 2031. Stock option activity was not material during the fiscal years ended January 31, 2025 and February 2, 2024.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001571996-26-000008:notes:347]
RETIREMENT PLAN BENEFITS 
Defined Benefit Retirement Plans

[0001571996-26-000008:notes:348]
The Company sponsors retirement plans for certain employees, some of which meet the criteria of a defined benefit retirement plan. Benefits under defined benefit retirement plans guarantee a particular payment to the employee in retirement. The amount of retirement benefit is defined by the plan and is typically a function of the number of years of service rendered by the employee and the employee’s average salary or salary at retirement. The annual costs of the plans are determined using the projected unit credit actuarial cost method that includes actuarial assumptions and estimates which are subject to change.

[0001571996-26-000008:notes:349]
U.S. Pension Plan — The Company sponsored a noncontributory defined benefit retirement plan in the United States (the “U.S. pension plan”), which was assumed in connection with the EMC Corporation merger transaction that was completed in September 2016. As of December 1999, the U.S. pension plan was frozen and employees no longer accrued retirement benefits for future services.

[0001571996-26-000008:notes:350]
On August 20, 2024, the Company’s Board of Directors approved an amendment to terminate the U.S. pension plan with an effective date of September 30, 2024. On September 24, 2025, the Company settled its remaining obligations under the U.S. pension plan by making distributions in the form of lump-sum payments to participants or by purchasing third-party annuities on behalf of the participant, at the participants’ election. At the time of settlement, the Company recognized a net gain of $15 million which was recorded within interest and other, net.

[0001571996-26-000008:notes:351]
The measurement date for the U.S. pension plan is the end of the Company’s fiscal year. The Company did not make any material contributions to the U.S. pension plan for the fiscal years ended January 30, 2026, January 31, 2025, and February 2, 2024. Net periodic benefit costs related to the U.S. pension plan were immaterial for the fiscal years ended January 30, 2026, January 31, 2025, and February 2, 2024.

[0001571996-26-000008:notes:352]
The underfunded position of the plan as of January 31, 2025, was $14 million and was recognized in other non-current liabilities in the Consolidated Statements of Financial Position. As of January 31, 2025, plan assets at fair value were $423 million and benefit obligations were $437 million. Plan assets were managed by outside investment managers. Assets were recognized at fair value and were primarily classified within Level 2 of the fair value hierarchy.

[0001571996-26-000008:notes:353]
International Pension Plans — The Company sponsors retirement plans outside of the United States that qualify as defined benefit plans. The following table presents attributes of the international pension plans as of the dates indicated:

[0001571996-26-000008:notes:354]
|  | January 30, 2026 |  | January 31, 2025 |
|  | (in millions) |
| Plan assets at fair value (a) | $ | 250 |  |  | $ | 228 |  |
| Benefit obligations | (498) |  |  | (438) |  |
| Underfunded position (b) | $ | (248) |  |  | $ | (210) |  |

[0001571996-26-000008:notes:355]
(a)Plan assets are managed by outside investment managers. The Company’s investment strategy with respect to plan assets is to achieve a long-term growth of capital, consistent with an appropriate level of risk. Assets are recognized at fair value and are primarily classified within Level 2 of the fair value hierarchy for both the fiscal years ended January 30, 2026 and January 31, 2025.

[0001571996-26-000008:notes:356]
(b)The underfunded position is recognized in other non-current liabilities in the Consolidated Statements of Financial Position.

[0001571996-26-000008:notes:357]
Defined Contribution Retirement Plans
Dell 401(k) Plan — The Company maintains a defined contribution retirement plan (the “Dell 401(k) Plan”) that complies with Section 401(k) of the Internal Revenue Code. Only U.S. employees and employees of certain subsidiaries, except those who are covered by a collective bargaining agreement, classified as a leased employee or a nonresident alien, or are covered under a separate plan, are eligible to participate in the Dell 401(k) Plan. Participation in the Dell 401(k) Plan is at the election of the employee. As of January 30, 2026, the Company matched 100% of each participant’s voluntary contributions (the “Dell 401(k) employer match”), subject to a maximum contribution of 6% of the participant’s eligible compensation, up to an annual limit of $7,500. Participants vest immediately in all contributions to the Dell 401(k) Plan. The Company’s matching contributions as well as participants’ voluntary contributions are invested according to each participant’s elections in the investment options provided under the Dell 401(k) Plan. The Company’s contributions during the fiscal years ended January 30, 2026, January 31, 2025, and February 2, 2024 were $198 million, $218 million, and $238 million, respectively.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001571996-26-000008:notes:358]
SEGMENT INFORMATION 
The Company reports its financial results through two reportable segments which are based on the following business units: Infrastructure Solutions Group (“ISG”) and Client Solutions Group (“CSG”). The Company organizes its reportable segments based on the manner in which management evaluates the performance of the Company.

[0001571996-26-000008:notes:359]
The Company’s Chief Executive Officer is the CODM. The CODM is regularly provided and reviews segment revenue and segment operating income to assess the performance of each segment and allocate resources to the segments in the annual planning process. The Company’s measure of segment revenue and segment operating income for management reporting purposes excludes Corporate and other, amortization of intangible assets, stock-based compensation expense, and other corporate expenses, as applicable, which are not used in evaluating the results of, or in allocating resources to, the segments. The Company does not allocate assets to the reportable segments for internal reporting purposes. The accounting policies of the segments are the same as those described in Note 2 of the Notes to the Consolidated Financial Statements.

[0001571996-26-000008:notes:360]
Given the scale and growth of the AI-optimized servers business, effective in the three months ended January 30, 2026, the Company’s servers and networking offerings were disaggregated within revenue by major product category into AI-optimized servers offerings and traditional servers and networking offerings. As a result, ISG includes the Company’s AI-optimized servers offerings, traditional servers and networking offerings, and storage offerings as major product categories. The Company’s AI-optimized servers are designed to run high-value workloads, including AI model training, fine-tuning, and inferencing. The Company’s traditional servers are high-performance general-purpose servers designed to deliver scalable performance, reliability, and efficient management across a wide range of enterprise workloads. The Company’s networking portfolio includes wide area network infrastructure, data center and edge networking switches, and cables and optics. The Company’s comprehensive storage portfolio includes modern and traditional storage solutions that span primary, unstructured and data protection offerings and are delivered through multiple architectures, including all-flash, purpose-built, software-defined, and hyper-converged infrastructure platforms. ISG also offers software, peripherals, and services, including consulting and support and deployment.

[0001571996-26-000008:notes:361]
CSG includes the Company’s commercial offerings and consumer offerings as major product categories. The Company’s CSG portfolio includes branded PCs, including notebooks, desktops, and workstations and branded peripherals that include displays, docking stations, keyboards, mice, and webcam and audio devices, as well as third-party software and peripherals. CSG also includes services offerings, such as configuration, support and deployment, and extended warranties.

[0001571996-26-000008:notes:362]
In March 2024, the Company terminated the Commercial Framework Agreement with VMware, whereby Dell Technologies acted as a distributor VMware’s stand-alone products and services and purchased such products and services for resale to end-user customers (“VMware Resale”). Dell Technologies no longer acts as a distributor of those products and services, although it continues to support customers that have purchased resale offerings sold in prior periods. The results of VMware Resale transactions are reflected in Corporate and other. The Company continues to integrate and embed certain VMware products and services with the Company’s VxRail solution to end-user customers. The results for this integrated offering are reflected within ISG.

[0001571996-26-000008:notes:363]
The following table presents a reconciliation of net revenue by the Company’s reportable segments to the Company’s consolidated net revenue as well as a reconciliation of segment operating income to the Company’s consolidated operating income for the periods indicated:

[0001571996-26-000008:notes:364]
|  |  |  | Fiscal Year Ended |
|  |  |  |  |  | January 30, 2026 |  | January 31, 2025 |  | February 2, 2024 |
|  |  |  |  |  | (in millions) |
| Consolidated net revenue: |  |  |  |  |  |  |  |  |  |
| Infrastructure Solutions Group |  |  |  |  | $ | 60,826 |  |  | $ | 43,593 |  |  | $ | 33,885 |  |
| Client Solutions Group |  |  |  |  | 50,984 |  |  | 48,393 |  |  | 48,916 |  |
| Reportable segment net revenue |  |  |  |  | 111,810 |  |  | 91,986 |  |  | 82,801 |  |
| Corporate and other (a) |  |  |  |  | 1,728 |  |  | 3,581 |  |  | 5,624 |  |
| Total consolidated net revenue |  |  |  |  | $ | 113,538 |  |  | $ | 95,567 |  |  | $ | 88,425 |  |
| Consolidated operating income: |  |  |  |  |  |  |  |  |  |
| Infrastructure Solutions Group |  |  |  |  | $ | 7,111 |  |  | $ | 5,579 |  |  | $ | 4,286 |  |
| Client Solutions Group |  |  |  |  | 2,833 |  |  | 2,972 |  |  | 3,712 |  |
| Reportable segment operating income (b) |  |  |  |  | 9,944 |  |  | 8,551 |  |  | 7,998 |  |
| Corporate and other (a) |  |  |  |  | 47 |  |  | (22) |  |  | (120) |  |
| Amortization of intangibles (c) |  |  |  |  | (497) |  |  | (667) |  |  | (833) |  |
| Stock-based compensation expense (d) |  |  |  |  | (723) |  |  | (785) |  |  | (878) |  |
| Other corporate expenses (e) |  |  |  |  | (622) |  |  | (840) |  |  | (756) |  |
| Total consolidated operating income (f) |  |  |  |  | $ | 8,149 |  |  | $ | 6,237 |  |  | $ | 5,411 |  |

[0001571996-26-000008:notes:365]
(a)Corporate and other consists of results of divested businesses or non-reportable segments whose offerings are no longer actively sold, including (i) VMware Resale, (ii) Secureworks, and (iii) Virtustream, and do not meet the requirements for a reportable segment, either individually or collectively. Additionally, Corporate and other includes other items that are managed at the corporate level and are not allocated to reportable segments.

[0001571996-26-000008:notes:366]
(b)Depreciation expense directly attributable to each reportable segment is included in the operating results of each segment. However, the CODM does not evaluate depreciation expense by operating segment, and therefore such expense is not separately presented.

[0001571996-26-000008:notes:367]
(c)Amortization of intangibles includes non-cash purchase accounting adjustments that are primarily related to the acquisition by merger of EMC Corporation in 2016.

[0001571996-26-000008:notes:368]
(d)Stock-based compensation expense consists of equity awards granted based on the estimated fair value of those awards at grant date.

[0001571996-26-000008:notes:369]
(e)Other corporate expenses includes severance expenses, payroll taxes associated with stock-based compensation, incentive charges related to equity investments, facility action costs, transaction-related expenses, and impairment charges.

[0001571996-26-000008:notes:370]
(f)Income and expenses within interest and other, net, is not allocated to the reportable segments. Therefore, the Company does not report below reportable segment operating income.

[0001571996-26-000008:notes:371]
The following table presents the significant expense categories by reportable segment for the periods indicated:

[0001571996-26-000008:notes:372]
|  |  |  | Fiscal Year Ended |
|  |  |  |  |  | January 30, 2026 |  | January 31, 2025 |  | February 2, 2024 |
|  |  |  |  |  | (in millions) |
| Infrastructure Solutions Group: |  |  |  |  |  |  |  |  |  |
| Cost of net revenue |  |  |  |  | $ | 45,022 |  |  | $ | 29,352 |  |  | $ | 20,943 |  |
| Selling, general, and administrative |  |  |  |  | $ | 6,457 |  |  | $ | 6,593 |  |  | $ | 6,752 |  |
| Research and development |  |  |  |  | $ | 2,236 |  |  | $ | 2,069 |  |  | $ | 1,904 |  |
| Client Solutions Group: |  |  |  |  |  |  |  |  |  |
| Cost of net revenue |  |  |  |  | $ | 43,691 |  |  | $ | 41,195 |  |  | $ | 40,658 |  |
| Selling, general, and administrative |  |  |  |  | $ | 3,898 |  |  | $ | 3,750 |  |  | $ | 4,080 |  |
| Research and development |  |  |  |  | $ | 562 |  |  | $ | 476 |  |  | $ | 466 |  |

[0001571996-26-000008:notes:373]
The following table presents the disaggregation of net revenue by reportable segment and by major product categories within the segments for the periods indicated:

[0001571996-26-000008:notes:374]
|  |  |  | Fiscal Year Ended |
|  |  |  |  |  | January 30, 2026 |  | January 31, 2025 |  | February 2, 2024 |
|  |  |  |  |  | (in millions) |
| Net revenue: |  |  |  |  |  |  |  |  |  |
| Infrastructure Solutions Group: |  |  |  |  |  |  |  |  |  |
| AI-optimized servers |  |  |  |  | $ | 24,683 |  |  | $ | 9,286 |  |  | $ | 1,873 |  |
| Traditional servers and networking |  |  |  |  | 19,512 |  |  | 17,850 |  |  | 15,751 |  |
| Storage |  |  |  |  | 16,631 |  |  | 16,457 |  |  | 16,261 |  |
| Total ISG net revenue |  |  |  |  | $ | 60,826 |  |  | $ | 43,593 |  |  | $ | 33,885 |  |
| Client Solutions Group: |  |  |  |  |  |  |  |  |  |
| Commercial |  |  |  |  | $ | 44,062 |  |  | $ | 40,844 |  |  | $ | 39,814 |  |
| Consumer |  |  |  |  | 6,922 |  |  | 7,549 |  |  | 9,102 |  |
| Total CSG net revenue |  |  |  |  | $ | 50,984 |  |  | $ | 48,393 |  |  | $ | 48,916 |  |

[0001571996-26-000008:notes:375]
The following table presents net revenue allocated between the United States and foreign countries for the periods indicated:

[0001571996-26-000008:notes:376]
|  | Fiscal Year Ended |
|  | January 30, 2026 |  | January 31, 2025 |  | February 2, 2024 |
|  | (in millions) |
| Net revenue: |  |  |  |  |  |
| United States | $ | 63,140 |  |  | $ | 51,014 |  |  | $ | 43,986 |  |
| Foreign countries | 50,398 |  |  | 44,553 |  |  | 44,439 |  |
| Total net revenue | $ | 113,538 |  |  | $ | 95,567 |  |  | $ | 88,425 |  |

[0001571996-26-000008:notes:377]
The allocation between domestic and foreign net revenue is based on the location of the customers. Net revenue from any single foreign country did not constitute 10% or more of the Company’s consolidated net revenue for any of the fiscal years ended January 30, 2026, January 31, 2025, and February 2, 2024.

[0001571996-26-000008:notes:378]
The following table presents property, plant, and equipment, net allocated between the United States and foreign countries as of the dates indicated:

[0001571996-26-000008:notes:379]
|  | January 30, 2026 |  | January 31, 2025 |
|  | (in millions) |
| Property, plant, and equipment, net: |  |  |  |
| United States | $ | 4,446 |  |  | $ | 4,396 |  |
| Foreign countries | 2,230 |  |  | 1,940 |  |
| Total property, plant, and equipment, net | $ | 6,676 |  |  | $ | 6,336 |  |

[0001571996-26-000008:notes:380]
As of January 30, 2026 and January 31, 2025, property, plant, and equipment, net primarily related to domestic ownership. Within foreign countries, property, plant, and equipment, net located in Ireland was $0.8 billion and $0.7 billion for the fiscal years ended January 30, 2026 and January 31, 2025, respectively.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001571996-26-000008:notes:381]
RELATED PARTY TRANSACTIONS 
Prior to the acquisition on November 22, 2023 of VMware LLC (previously VMware, Inc. and individually and together with its consolidated subsidiaries, “VMware”) by Broadcom Inc. (“Broadcom”), VMware was considered a related party of the Company. Upon Broadcom’s acquisition of VMware, Michael Dell’s ownership interest in VMware and his position as Chairman of the Board of VMware terminated, and the Company determined no related party relationship exists with Broadcom or VMware effective as of November 22, 2023. The Company continues to engage in select transactions with VMware following the completion of Broadcom’s acquisition and the termination of the related party relationship. See Note 18 of the Notes to the Consolidated Financial Statements for additional information.

[0001571996-26-000008:notes:382]
Related Party Transactions with VMware

[0001571996-26-000008:notes:383]
The information provided below includes a summary of related party transactions with VMware for the fiscal year ended February 2, 2024. Such transactions were considered related party transactions only through November 21, 2023, the day immediately preceding Broadcom’s acquisition of VMware.

[0001571996-26-000008:notes:384]
•Dell Technologies integrated or bundled select VMware products and services with Dell Technologies’ products and sold them to end-users. Dell Technologies also acted as a distributor, purchasing VMware’s standalone products and services for resale to end-user customers. Where applicable, costs under these arrangements were presented net of rebates received by Dell Technologies.

[0001571996-26-000008:notes:385]
•DFS provided financing to certain VMware end-users, which resulted in the recognition of amounts due to related parties on the Consolidated Statements of Financial Position. Associated financing fees were recorded to product net revenue on the Consolidated Statements of Income and were reflected within sales and leases of products to VMware in the table below.

[0001571996-26-000008:notes:386]
•Dell Technologies procured products and services from VMware for its internal use. For the fiscal year ended February 2, 2024, costs incurred associated with products and services purchased from VMware for internal use were immaterial.

[0001571996-26-000008:notes:387]
•Dell Technologies sold and leased products and sold services to VMware. For the fiscal year ended February 2, 2024, revenue recognized from sales of services to VMware was immaterial.

[0001571996-26-000008:notes:388]
•Dell Technologies and VMware entered into joint marketing, sales, and branding arrangements, for which both parties incurred costs. For the fiscal year ended February 2, 2024, consideration received from VMware for joint marketing, sales, and branding arrangements was immaterial.

[0001571996-26-000008:notes:389]
The following table presents information about the impact of Dell Technologies’ related party transactions with VMware on the Consolidated Statements of Income for the period presented:

[0001571996-26-000008:notes:390]
|  |  |  |  |  |  |  |  |  | Fiscal Year Ended |
|  | Classification |  |  |  |  |  |  |  |  |  | February 2, 2024 (a) |
|  |  |  |  |  |  |  |  |  |  |  | (in millions) |
| Sales and leases of products to VMware | Net revenue — products |  |  |  |  |  |  |  |  |  | $ | 103 |  |
| Purchase of VMware products for resale | Cost of net revenue — products |  |  |  |  |  |  |  |  |  | $ | 1,010 |  |
| Purchase of VMware services for resale | Cost of net revenue — services |  |  |  |  |  |  |  |  |  | $ | 2,810 |  |

[0001571996-26-000008:notes:391]
(a)For the fiscal year ended February 2, 2024, amounts are reported only through November 21, 2023, the day immediately preceding the acquisition of VMware by Broadcom.

[0001571996-26-000008:notes:392]
In connection with the completion of the VMware Spin-off described in Note 11 of the Notes to the Consolidated Financial Statements, Dell Technologies and VMware entered into a Tax Matters Agreement effective as of April 14, 2021 (the “Tax Matters Agreement”), which governs the respective rights and obligations of Dell Technologies and VMware regarding income and other taxes as well as related matters, including tax liabilities and benefits, attributes, and returns for periods both preceding and following the VMware Spin-off.

[0001571996-26-000008:notes:393]
Pursuant to the Tax Matters Agreement, net receipts from VMware during the fiscal year ended February 2, 2024 were $286 million, a portion of which was received subsequent to the completion of Broadcom’s acquisition of VMware. Such receipts were primarily related to VMware’s portion of the mandatory one-time transition tax on accumulated earnings of foreign subsidiaries and federal income taxes on Dell Technologies’ consolidated income tax return.

[0001571996-26-000008:notes:394]
Other Related Parties

[0001571996-26-000008:notes:395]
Transactions with other related parties during the periods presented were immaterial, individually and in aggregate.


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0001571996-26-000008:notes:396]
SUPPLEMENTAL CONSOLIDATED FINANCIAL INFORMATION
The following table presents additional information on selected assets included in the Consolidated Statements of Financial Position as of the dates indicated:

[0001571996-26-000008:notes:397]
|  | January 30, 2026 |  | January 31, 2025 |
|  | (in millions) |
| Cash, cash equivalents, and restricted cash: |  |  |  |
| Cash and cash equivalents | $ | 11,528 |  |  | $ | 3,633 |  |
| Cash and cash equivalents — held for sale (a) | — |  |  | 62 |  |
| Restricted cash (b) | 178 |  |  | 124 |  |
| Total cash, cash equivalents, and restricted cash | $ | 11,706 |  |  | $ | 3,819 |  |
| Inventories: |  |  |  |
| Production materials | $ | 6,696 |  |  | $ | 4,432 |  |
| Work-in-process | 2,772 |  |  | 1,128 |  |
| Finished goods | 969 |  |  | 1,156 |  |
| Total inventories | $ | 10,437 |  |  | $ | 6,716 |  |
| Prepaid expenses: |  |  |  |
| Total prepaid expenses (c) | $ | 552 |  |  | $ | 564 |  |
| Deferred costs: |  |  |  |
| Total deferred costs, current (c) | $ | 2,533 |  |  | $ | 4,129 |  |
| Property, plant, and equipment, net: |  |  |  |
| Assets in a customer contract | $ | 5,777 |  |  | $ | 5,204 |  |
| Computer and other equipment | 3,849 |  |  | 3,651 |  |
| Land and buildings | 3,134 |  |  | 2,838 |  |
| Internal use software | 2,083 |  |  | 2,403 |  |
| Total property, plant, and equipment | 14,843 |  |  | 14,096 |  |
| Accumulated depreciation and amortization (d) | (8,167) |  |  | (7,760) |  |
| Total property, plant, and equipment, net | $ | 6,676 |  |  | $ | 6,336 |  |

[0001571996-26-000008:notes:398]
(a)Held for sale represents the reclassification of Secureworks cash and cash equivalents to assets held for sale as of January 31, 2025. See Note 1 of the Notes to the Consolidated Financial Statements for more information about the sale of Secureworks.

[0001571996-26-000008:notes:399]
(b)Restricted cash is primarily classified as other current assets in the Consolidated Statements of Financial Position and consists predominantly of cash required to be held in escrow pursuant to DFS securitization arrangements.

[0001571996-26-000008:notes:400]
(c)Prepaid expenses and deferred costs are included in other current assets in the Consolidated Statements of Financial Position. Amounts classified as long-term prepaid expenses and long-term deferred costs are included in other non-current assets and are not disclosed above.

[0001571996-26-000008:notes:401]
(d)During the fiscal years ended January 30, 2026, January 31, 2025, and February 2, 2024, the Company recognized $2.2 billion, $2.1 billion, and $2.0 billion, respectively, in depreciation and amortization expense.

[0001571996-26-000008:notes:402]
Warranty Liability

[0001571996-26-000008:notes:403]
The following table presents changes in the Company’s liability for standard limited warranties for the periods indicated:

[0001571996-26-000008:notes:404]
|  |  |  | Fiscal Year Ended |
|  |  |  |  |  | January 30, 2026 |  | January 31, 2025 |  | February 2, 2024 |
|  |  |  |  |  | (in millions) |
| Warranty liability: |  |  |  |  |  |  |  |  |  |
| Warranty liability at beginning of period |  |  |  |  | $ | 424 |  |  | $ | 426 |  |  | $ | 467 |  |
| Costs accrued for new warranty contracts and changes in estimates for pre-existing warranties (a) |  |  |  |  | 978 |  |  | 882 |  |  | 808 |  |
| Service obligations honored |  |  |  |  | (952) |  |  | (884) |  |  | (849) |  |
| Warranty liability at end of period (b) |  |  |  |  | $ | 450 |  |  | $ | 424 |  |  | $ | 426 |  |

[0001571996-26-000008:notes:405]
(a)Changes in cost estimates related to pre-existing warranties are aggregated with accruals for new standard warranty contracts. The Company’s warranty liability process does not differentiate between estimates made for pre-existing warranties and those made for new warranty obligations.

[0001571996-26-000008:notes:406]
(b)The liabilities for standard warranties are included in accrued and other and in non-current liabilities in the Consolidated Statements of Financial Position.

[0001571996-26-000008:notes:407]
Severance Charges

[0001571996-26-000008:notes:408]
The Company incurs costs related to employee severance and records a liability for these costs when it is probable that employees will be entitled to termination benefits and the amounts can be reasonably estimated. The liability related to these actions is primarily included in accrued and other within current liabilities in the Consolidated Statements of Financial Position.

[0001571996-26-000008:notes:409]
The following table presents the activity related to the Company’s severance liability for the periods indicated:

[0001571996-26-000008:notes:410]
|  |  |  | Fiscal Year Ended |
|  |  |  |  |  | January 30, 2026 |  | January 31, 2025 |  | February 2, 2024 |
|  |  |  |  |  | (in millions) |
| Severance liability: |  |  |  |  |  |  |  |  |  |
| Severance liability at beginning of period |  |  |  |  | $ | 238 |  |  | $ | 352 |  |  | $ | 408 |  |
| Severance charges |  |  |  |  | 569 |  |  | 693 |  |  | 648 |  |
| Cash paid and other |  |  |  |  | (671) |  |  | (807) |  |  | (704) |  |
| Severance liability at end of period |  |  |  |  | $ | 136 |  |  | $ | 238 |  |  | $ | 352 |  |

[0001571996-26-000008:notes:411]
The following table presents severance charges as included in the Consolidated Statements of Income for the periods indicated:

[0001571996-26-000008:notes:412]
|  |  |  | Fiscal Year Ended |
|  |  |  |  |  | January 30, 2026 |  | January 31, 2025 |  | February 2, 2024 |
|  |  |  |  |  | (in millions) |
| Severance charges: |  |  |  |  |  |  |  |  |  |
| Cost of net revenue |  |  |  |  | $ | 142 |  |  | $ | 155 |  |  | $ | 86 |  |
| Selling, general, and administrative |  |  |  |  | 297 |  |  | 419 |  |  | 522 |  |
| Research and development |  |  |  |  | 130 |  |  | 119 |  |  | 40 |  |
| Total severance charges |  |  |  |  | $ | 569 |  |  | $ | 693 |  |  | $ | 648 |  |

[0001571996-26-000008:notes:413]
Supply Chain Finance Program

[0001571996-26-000008:notes:414]
The Company maintains a Supply Chain Finance Program (the “SCF Program”), which enables eligible suppliers, at the supplier's sole discretion, to sell receivables due from the Company to a third-party financial institution. The Company has no involvement in establishing the terms or conditions of the arrangement between its suppliers and the financial institution, no economic interest in a supplier's decision to sell a receivable, and does not provide legally secured assets or other forms of guarantees under the arrangement.

[0001571996-26-000008:notes:415]
The SCF Program does not impact the Company's liquidity as payments for participating supplier invoices are remitted by the Company to the financial institution on the original invoice due date, regardless of whether an individual invoice is sold by the supplier to the financial institution. Further, the Company negotiates payment terms with suppliers regardless of their decision to participate in the SCF Program. Payment terms with such suppliers vary and do not exceed 100 days. The Company’s outstanding obligations represent invoices due to suppliers confirmed as valid under the SCF Program and are included within accounts payable on the Consolidated Statements of Financial Position, while associated payments are included in cash flows from operating activities on the Consolidated Statements of Cash Flows.

[0001571996-26-000008:notes:416]
The following table presents the changes in the Company’s outstanding obligations for the periods indicated:

[0001571996-26-000008:notes:417]
|  | Fiscal Year Ended |
|  | January 30, 2026 |  | January 31, 2025 |
|  | (in millions) |
| Confirmed obligations outstanding at the beginning of period | $ | 1,368 |  |  | $ | 1,121 |  |
| Invoices confirmed | 6,052 |  |  | 5,191 |  |
| Confirmed invoices paid | (5,437) |  |  | (4,944) |  |
| Confirmed obligations outstanding at the end of period | $ | 1,983 |  |  | $ | 1,368 |  |

[0001571996-26-000008:notes:418]
Interest and Other, Net

[0001571996-26-000008:notes:419]
The following table presents information regarding interest and other, net as included in the Consolidated Statements of Income for the periods indicated:

[0001571996-26-000008:notes:420]
|  |  |  | Fiscal Year Ended |
|  |  |  |  |  | January 30, 2026 |  | January 31, 2025 |  | February 2, 2024 |
|  |  |  |  |  | (in millions) |
| Interest and other, net: |  |  |  |  |  |  |  |  |  |
| Investment income, primarily interest |  |  |  |  | $ | 256 |  |  | $ | 160 |  |  | $ | 305 |  |
| Gain on investments, net |  |  |  |  | 254 |  |  | 177 |  |  | 47 |  |
| Interest expense |  |  |  |  | (1,560) |  |  | (1,394) |  |  | (1,501) |  |
| Foreign exchange |  |  |  |  | (95) |  |  | (112) |  |  | (199) |  |
| Gain on disposition of businesses and assets |  |  |  |  | 236 |  |  | — |  |  | — |  |
| Other |  |  |  |  | 23 |  |  | (20) |  |  | 24 |  |
| Total interest and other, net |  |  |  |  | $ | (886) |  |  | $ | (1,189) |  |  | $ | (1,324) |  |

[0001571996-26-000008:notes:421]
Income Taxes Paid

[0001571996-26-000008:notes:422]
The following table presents information regarding income taxes paid as included in the Consolidated Statements of Cash Flows:

[0001571996-26-000008:notes:423]
|  | Fiscal Year Ended |
|  | January 30, 2026 |  |  |  |  |
|  | (in millions) |
| U.S. federal | $ | 366 |  |  |  |  |  |
| U.S. state and local | 176 |  |  |  |  |  |
| Foreign: |  |  |  |  |  |
| Singapore | 192 |  |  |  |  |  |
| Other foreign jurisdictions | 527 |  |  |  |  |  |
| Income taxes paid, net of refunds | $ | 1,261 |  |  |  |  |  |


## us-gaap:GovernmentAssistanceTextBlock

[0001571996-26-000008:notes:424]
GOVERNMENT ASSISTANCE
The Company receives government assistance in the form of grants and incentives which vary in size, duration, and conditions from various domestic and international governing bodies and related entities which are primarily structured as cash grants and non-income tax incentives. For government assistance in which no specific GAAP applies, the Company accounts for such transactions as a gain contingency and by analogy to a grant model. Under such model, the Company recognizes the impact of the government assistance on the Consolidated Statements of Income upon reaching reasonable assurance that the Company will comply with the conditions of the assistance and that the grant will be received. The Company classifies the impact of government assistance on the Consolidated Statements of Income based on the underlying nature and purpose of the assistance.

[0001571996-26-000008:notes:425]
During the fiscal years ended January 30, 2026, January 31, 2025, and February 2, 2024, government assistance received primarily consisted of the following:

[0001571996-26-000008:notes:426]
The Company received assistance from foreign governmental entities designed, in part, to promote competitive pricing by providing companies with an offset to local sales taxes incurred on the sales of products to customers. The assistance received is broadly available to companies. To qualify for this assistance, companies are required to invest a portion of local revenue, derived from goods manufactured locally, into research and development activities. The incentives in place are currently set to expire at various dates through 2029. Such expirations could be impacted by future legislation. During the fiscal years ended January 30, 2026, January 31, 2025, and February 2, 2024, the Company recognized $339 million, $279 million, and $288 million, respectively, within net revenue on the Consolidated Statements of Income related to such assistance.

[0001571996-26-000008:notes:427]
The Company received incentives from foreign governmental entities to provide reimbursement for various costs incurred that are directly tied to the production or delivery of offerings sold to customers. The agreements governing such assistance require that the Company comply with certain conditions including, but not limited to, the achievement of future operational targets. These agreements currently expire at various dates through 2029. During the fiscal years ended January 30, 2026, January 31, 2025, and February 2, 2024, the Company recognized a benefit of $18 million, $45 million, and $166 million, respectively, to cost of net revenue on the Consolidated Statements of Income related to such assistance.


## us-gaap:SubsequentEventsTextBlock

[0001571996-26-000008:notes:428]
SUBSEQUENT EVENTS 
There were no known events occurring after January 30, 2026 and up until the date of issuance of this report that would materially affect the information presented herein.


## ecd:MtrlTermsOfTrdArrTextBlock

[0001571996-26-000008:notes:429]
On December 18, 2025, Richard Troy Sharp, the Company’s Chief Accounting Officer, adopted a written plan for the sale of up to 2,071 shares of the Company’s Class C Common Stock that is intended to satisfy the affirmative defense conditions of Rule 10b5-1(c) under the Exchange Act. The plan will expire on December 18, 2026, or on any earlier date on which all of the shares have been sold.

[0001571996-26-000008:notes:430]
On January 15, 2026, Jeffrey W. Clarke, the Company’s Vice Chairman and Chief Operating Officer, adopted a written plan for the sale of up to 116,000 shares of the Company’s Class C Common Stock that is intended to satisfy the affirmative defense conditions of Rule 10b5-1(c) under the Exchange Act. The plan will expire on June 30, 2026, or on any earlier date on which all of the shares have been sold.
