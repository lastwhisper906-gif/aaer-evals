# DELL 8-K — 0001571996-26-000003 filed 2026-02-26

## item codes, every 8-K on or before 2026-03-16

- 2026-02-26 0001571996-26-000003 — 2.02, 9.01
- 2025-11-25 0001571996-25-000120 — 5.02 — amendment of 0001571996-25-000104
- 2025-11-25 0001571996-25-000118 — 2.02, 9.01
- 2025-10-17 0001571996-25-000114 — 5.02 — amendment of 0001571996-25-000093
- 2025-10-07 0001193125-25-232662 — 7.01, 9.01
- 2025-10-06 0001193125-25-231904 — 1.01, 2.03, 9.01
- 2025-10-02 0001571996-25-000112 — 5.02 — amendment of 0001571996-25-000104
- 2025-10-02 0001571996-25-000111 — 5.02, 9.01
- 2025-09-26 0001571996-25-000107 — 3.02
- 2025-09-23 0001193125-25-213629 — 8.01, 9.01
- 2025-09-08 0001571996-25-000104 — 5.02
- 2025-08-28 0001571996-25-000096 — 2.02, 9.01
- 2025-08-12 0001571996-25-000093 — 5.02
- 2025-07-16 0001571996-25-000081 — 3.02
- 2025-07-01 0001571996-25-000078 — 5.07
- 2025-05-29 0001571996-25-000046 — 2.02, 9.01
- 2025-04-01 0001193125-25-070461 — 1.01, 2.03, 9.01
- 2025-03-27 0001193125-25-065594 — 8.01, 9.01
- 2025-02-27 0001571996-25-000014 — 2.02, 8.01, 9.01
- 2025-01-14 0001571996-25-000004 — 3.02
- 2024-12-03 0001571996-24-000136 — 3.02
- 2024-11-26 0001571996-24-000130 — 2.02, 9.01
- 2024-10-08 0001193125-24-234446 — 1.01, 2.03, 9.01
- 2024-10-02 0001193125-24-231195 — 8.01, 9.01
- 2024-09-19 0001571996-24-000105 — 3.02
- 2024-08-29 0001571996-24-000081 — 2.02, 9.01
- 2024-07-12 0001193125-24-178608 — 3.02
- 2024-07-02 0001571996-24-000074 — 5.07
- 2024-06-10 0001571996-24-000059 — 3.02
- 2024-05-30 0001571996-24-000050 — 2.02, 9.01
- 2024-03-26 0001571996-24-000038 — 3.02
- 2024-03-18 0001193125-24-070193 — 1.01, 2.03, 9.01
- 2024-03-07 0001571996-24-000012 — 3.02
- 2024-03-06 0001193125-24-059631 — 8.01, 9.01
- 2024-02-29 0001571996-24-000008 — 2.02, 9.01
- 2024-01-30 0001571996-24-000004 — 1.02
- 2024-01-18 0001571996-24-000002 — 3.02
- 2023-12-18 0001193125-23-297664 — 8.01, 9.01
- 2023-12-05 0001571996-23-000042 — 3.02
- 2023-12-04 0001193125-23-288428 — 8.01, 9.01
- 2023-11-30 0001571996-23-000039 — 2.02, 9.01
- 2023-10-05 0001193125-23-251131 — 7.01, 8.01, 9.01
- 2023-10-02 0001571996-23-000036 — 5.02 — amendment of 0001571996-23-000034
- 2023-09-26 0001571996-23-000034 — 5.02
- 2023-08-31 0001571996-23-000029 — 2.02, 9.01
- 2023-08-09 0001571996-23-000026 — 5.02 — amendment of 0001571996-23-000002
- 2023-07-28 0001571996-23-000024 — 5.02
- 2023-07-13 0001193125-23-186639 — 3.02
- 2023-06-30 0001193125-23-180570 — 8.01, 9.01
- 2023-06-22 0001571996-23-000021 — 5.02, 5.07, 9.01
- 2023-06-15 0001193125-23-167472 — 8.01, 9.01
- 2023-06-01 0001571996-23-000014 — 2.02, 9.01
- 2023-03-02 0001571996-23-000002 — 2.02, 5.02, 9.01
- 2023-02-06 0001193125-23-024781 — 7.01, 9.01
- 2023-01-24 0001193125-23-014260 — 1.01, 2.03, 9.01
- 2023-01-11 0001193125-23-006528 — 8.01, 9.01
- 2022-11-21 0001571996-22-000041 — 2.02, 9.01
- 2022-11-16 0001571996-22-000038 — 8.01
- 2022-08-25 0001571996-22-000028 — 2.02, 9.01
- 2022-07-18 0001193125-22-196334 — 2.03, 8.01
- 2022-06-29 0001571996-22-000025 — 3.03, 5.03, 5.07, 8.01, 9.01
- 2022-05-26 0001571996-22-000013 — 2.02, 9.01
- 2022-02-24 0001571996-22-000004 — 2.02, 8.01, 9.01
- 2021-12-20 0001193125-21-362482 — 8.01, 9.01
- 2021-12-15 0001193125-21-357927 — 1.01, 2.03, 9.01
- 2021-12-07 0001193125-21-349218 — 8.01, 9.01
- 2021-11-23 0001571996-21-000060 — 2.02, 9.01
- 2021-11-05 0001571996-21-000057 — 1.02, 2.01, 7.01, 8.01, 9.01 — amendment, the index does not say of what
- 2021-11-01 0001571996-21-000052 — 8.01, 9.01
- 2021-11-01 0001193125-21-315488 — 1.01, 1.02, 2.01, 8.01, 9.01
- 2021-10-21 0001193125-21-304052 — 8.01, 9.01
- 2021-10-19 0001571996-21-000050 — 8.01, 9.01
- 2021-10-07 0001193125-21-294210 — 8.01, 9.01
- 2021-09-30 0001571996-21-000047 — 5.02
- 2021-09-27 0001571996-21-000045 — 8.01
- 2021-09-23 0001193125-21-280190 — 7.01, 8.01, 9.01
- 2021-09-20 0001193125-21-276810 — 7.01, 9.01
- 2021-08-26 0001571996-21-000037 — 2.02, 9.01
- 2021-07-01 0001571996-21-000034 — 3.02
- 2021-06-24 0001571996-21-000031 — 5.07
- 2021-06-24 0001193125-21-197644 — 7.01, 9.01
- 2021-06-16 0001571996-21-000029 — 5.02
- 2021-05-27 0001571996-21-000019 — 2.02, 9.01
- 2021-05-03 0001571996-21-000010 — 8.01, 9.01
- 2021-04-14 0001193125-21-116271 — 1.01, 7.01, 9.01
- 2021-02-25 0001571996-21-000003 — 2.02, 9.01
- 2021-02-18 0001193125-21-047844 — 1.01, 2.03, 9.01
- 2020-11-24 0001571996-20-000048 — 2.02, 9.01
- 2020-08-27 0001571996-20-000041 — 2.02, 9.01
- 2020-07-02 0001571996-20-000037 — 5.07
- 2020-05-28 0001571996-20-000028 — 2.02, 9.01
- 2020-04-09 0001193125-20-102602 — 1.01, 2.03, 9.01
- 2020-04-08 0001571996-20-000021 — 5.02
- 2020-04-03 0001571996-20-000019 — 8.01, 9.01
- 2020-03-26 0001571996-20-000015 — 7.01
- 2020-02-27 0001571996-20-000009 — 2.02, 8.01, 9.01
- 2020-02-18 0001571996-20-000005 — 8.01, 9.01
- 2020-01-09 0001571996-20-000002 — 3.02
- 2020-01-06 0001193125-20-002200 — 3.02
- 2019-12-13 0001193125-19-313947 — 3.02
- 2019-12-10 0001571996-19-000052 — 5.02
- 2019-12-02 0001571996-19-000044 — 5.02, 7.01, 9.01
- 2019-11-26 0001571996-19-000042 — 2.02, 9.01
- 2019-09-23 0001193125-19-252192 — 1.01, 2.03, 9.01
- 2019-08-29 0001571996-19-000036 — 2.02, 9.01
- 2019-08-22 0001193125-19-226939 — 7.01, 8.01, 9.01
- 2019-07-11 0001571996-19-000032 — 5.02, 5.07, 9.01
- 2019-07-03 0001571996-19-000030 — 3.02
- 2019-06-27 0001571996-19-000028 — 3.02
- 2019-05-30 0001571996-19-000021 — 2.02, 9.01
- 2019-04-02 0001571996-19-000010 — 5.02
- 2019-03-21 0001193125-19-082281 — 1.01, 1.02, 2.03, 9.01
- 2019-03-19 0001571996-19-000005 — 5.02, 9.01
- 2019-03-14 0001193125-19-074935 — 1.01, 2.03, 9.01
- 2019-03-07 0001193125-19-066045 — 8.01, 9.01
- 2019-02-28 0001571996-19-000002 — 2.02, 9.01
- 2018-12-28 0001193125-18-360943 — 1.01, 1.02, 3.01, 3.03, 5.02, 5.03, 7.01, 8.01, 9.01
- 2018-12-21 0001193125-18-356324 — 1.01, 2.03, 9.01
- 2018-12-14 0001193125-18-349469 — 8.01
- 2018-12-11 0001193125-18-346958 — 5.07, 8.01, 9.01
- 2018-11-29 0001571996-18-000041 — 2.02, 9.01
- 2018-11-28 0001571996-18-000037 — 7.01, 8.01, 9.01
- 2018-11-26 0001193125-18-333967 — 8.01, 9.01
- 2018-11-15 0001193125-18-328110 — 1.01, 9.01 — amendment of 0001193125-18-327222
- 2018-11-15 0001193125-18-327222 — 1.01, 7.01, 9.01
- 2018-10-03 0001193125-18-291390 — 8.01
- 2018-09-06 0001571996-18-000029 — 2.02, 9.01
- 2018-08-06 0001571996-18-000027 — 8.01, 9.01
- 2018-07-02 0001193125-18-210339 — 1.01, 7.01, 9.01
- 2018-06-28 0001571996-18-000024 — 5.07
- 2018-06-04 0001571996-18-000019 — 2.02, 9.01
- 2018-05-17 0001571996-18-000016 — 7.01
- 2018-04-26 0001571996-18-000009 — 7.01, 9.01
- 2018-03-08 0001193125-18-074168 — 2.02, 9.01
- 2018-02-02 0001193125-18-029947 — 7.01, 9.01
- 2017-12-07 0001571996-17-000042 — 2.02, 9.01
- 2017-10-24 0001571996-17-000037 — 1.01, 2.03, 9.01
- 2017-09-15 0001571996-17-000027 — 5.02
- 2017-09-07 0001571996-17-000017 — 2.02, 9.01
- 2017-08-24 0001571996-17-000014 — 8.01
- 2017-06-29 0001571996-17-000011 — 3.03, 5.07, 8.01, 9.01
- 2017-06-08 0001193125-17-197638 — 2.02, 9.01
- 2017-03-30 0001193125-17-102794 — 8.01
- 2017-03-30 0001193125-17-102777 — 2.02, 9.01
- 2017-03-09 0001193125-17-076981 — 1.01, 2.03, 9.01
- 2017-01-17 0001193125-17-011125 — 8.01
- 2016-12-15 0001193125-16-793722 — 8.01
- 2016-12-08 0001193125-16-787976 — 2.02, 9.01
- 2016-11-10 0001193125-16-765964 — 1.02, 8.01
- 2016-11-04 0001193125-16-760249 — 8.01
- 2016-09-13 0001193125-16-708600 — 3.02
- 2016-09-09 0001193125-16-706567 — 1.01, 1.02, 2.01, 2.03, 3.02, 3.03, 5.02, 9.01
- 2016-09-07 0001193125-16-703370 — 3.03, 5.07, 7.01, 8.01, 9.01
- 2016-09-06 0001193125-16-702057 — 2.02, 9.01
- 2016-08-31 0001193125-16-697268 — 8.01, 9.01
- 2016-08-26 0001193125-16-692921 — 8.01, 9.01
- 2016-07-11 0001193125-16-645610 — 8.01
- 2016-07-05 0001193125-16-641679 — 8.01
- 2016-06-22 0001193125-16-629055 — 1.01, 2.03, 8.01, 9.01
- 2016-06-21 0001193125-16-627071 — 8.01, 9.01
- 2016-06-10 0001193125-16-618483 — 2.02, 9.01
- 2016-06-09 0001193125-16-617893 — 8.01, 9.01

## late-filing notifications on or before 2026-03-16

- none on or before 2026-03-16

## item 2.02 — earnings release, exhibit 99.1

[0001571996-26-000003:8k_2_02:1]
EX-99.1
2
exhibit991earnings8kq4fy26.htm
EX-99.1

[0001571996-26-000003:8k_2_02:2]
Document

[0001571996-26-000003:8k_2_02:3]
Exhibit 99.1

[0001571996-26-000003:8k_2_02:4]
Dell Technologies Delivers Fourth Quarter and Full-Year Fiscal 2026 Results

[0001571996-26-000003:8k_2_02:5]
ROUND ROCK, Texas — February 26, 2026 — Dell Technologies (NYSE: DELL) announces financial results for its fiscal 2026 fourth quarter and full year ended January 30, 2026. The company also provides guidance for its fiscal 2027 first quarter and full year.

[0001571996-26-000003:8k_2_02:6]
Full-Year Summary

[0001571996-26-000003:8k_2_02:7]
•Record full-year revenue of $113.5 billion, up 19% year over year

[0001571996-26-000003:8k_2_02:8]
•Record full-year diluted earnings per share (EPS) of $8.68, up 36% year over year, and record full-year non-GAAP diluted EPS of $10.30, up 27%

[0001571996-26-000003:8k_2_02:9]
•Record full-year cash flow from operations of $11.2 billion

[0001571996-26-000003:8k_2_02:10]
•Announcing a cash dividend increase of 20% and $10 billion increase in share repurchase authorization

[0001571996-26-000003:8k_2_02:11]
•FY27 guidance: Full-year revenue growth of 23% at the midpoint, diluted EPS growth of 33% at the midpoint, and non-GAAP diluted EPS growth of 25% at the midpoint

[0001571996-26-000003:8k_2_02:12]
Fourth-Quarter Summary

[0001571996-26-000003:8k_2_02:13]
•Record revenue of $33.4 billion, up 39% year over year

[0001571996-26-000003:8k_2_02:14]
•Record fourth-quarter diluted EPS of $3.37, up 57% year over year, and record non-GAAP diluted EPS of $3.89, up 45%

[0001571996-26-000003:8k_2_02:15]
•Record cash flow from operations of $4.7 billion

[0001571996-26-000003:8k_2_02:16]
“FY26 was a defining year in our company’s history, with record full-year revenue of $113.5 billion, record EPS, and record cash generation,” said Jeff Clarke, vice chairman and chief operating officer, Dell Technologies. “The AI opportunity is transforming our company. We closed more than $64 billion in AI-optimized server orders, shipped more than $25 billion throughout the year, and are entering FY27 with record backlog of $43 billion — powerful proof that our engineering leadership and differentiated AI solutions are winning.”

[0001571996-26-000003:8k_2_02:17]
“We delivered record revenue of $33.4 billion in our fourth quarter, capping a record year for the company,” said David Kennedy, chief financial officer, Dell Technologies. “Our strong execution drove record annual cash flow of more than $11 billion and record capital returned to shareholders of $7.5 billion. We have the portfolio, operating model and growing customer base to exceed our long-term growth targets in FY27, with expected revenue of $140 billion at the midpoint of our range and EPS growth of 25%.”

[0001571996-26-000003:8k_2_02:18]
1

[0001571996-26-000003:8k_2_02:19]
Infrastructure Solutions Group (ISG)

[0001571996-26-000003:8k_2_02:20]
•Record full-year revenue: $60.8 billion, up 40% year over year

[0001571996-26-000003:8k_2_02:21]
•Record full-year operating income: $7.1 billion, up 27% year over year

[0001571996-26-000003:8k_2_02:22]
•Record quarterly revenue: $19.6 billion, up 73% year over year

[0001571996-26-000003:8k_2_02:23]
•Record quarterly AI-Optimized Servers revenue: $9.0 billion, up 342% year over year

[0001571996-26-000003:8k_2_02:24]
•Record quarterly Traditional Servers and Networking revenue: $5.9 billion, up 27% year over year

[0001571996-26-000003:8k_2_02:25]
•Fourth-quarter Storage revenue: $4.8 billion, up 2% year over year

[0001571996-26-000003:8k_2_02:26]
•Record quarterly operating income: $2.9 billion, up 41% year over year

[0001571996-26-000003:8k_2_02:27]
Client Solutions Group (CSG)

[0001571996-26-000003:8k_2_02:28]
•Full-year revenue: $51.0 billion, up 5% year over year

[0001571996-26-000003:8k_2_02:29]
•Full-year operating income: $2.8 billion, down 5% year over year

[0001571996-26-000003:8k_2_02:30]
•Fourth-quarter revenue: $13.5 billion, up 14% year over year

[0001571996-26-000003:8k_2_02:31]
•Fourth-quarter Commercial Client revenue: $11.6 billion, up 16% year over year

[0001571996-26-000003:8k_2_02:32]
•Fourth-quarter Consumer revenue: $1.9 billion, flat year over year

[0001571996-26-000003:8k_2_02:33]
•Fourth-quarter operating income: $629 million, flat year over year

[0001571996-26-000003:8k_2_02:34]
Capital Return

[0001571996-26-000003:8k_2_02:35]
The company also announced a cash dividend increase of 20% and $10 billion increase in share repurchase authorization. Dell Technologies returned $2.2 billion to shareholders in the fourth quarter through share repurchases and dividends. During the year, the company returned a record $7.5 billion to shareholders and repurchased roughly 54 million shares.

[0001571996-26-000003:8k_2_02:36]
Guidance Summary

[0001571996-26-000003:8k_2_02:37]
•Full-year FY27 revenue expected between $138.0 billion and $142.0 billion, up 23% year over year at the midpoint of $140.0 billion

[0001571996-26-000003:8k_2_02:38]
•Full-year AI-Optimized Servers revenue expected to be roughly $50 billion, up 103% year over year

[0001571996-26-000003:8k_2_02:39]
•Full-year FY27 GAAP diluted EPS expected to be $11.52 at the midpoint, up 33% year over year, and non-GAAP diluted EPS to be $12.90 at the midpoint, up 25%

[0001571996-26-000003:8k_2_02:40]
•First-quarter FY27 revenue expected between $34.7 billion and $35.7 billion, up 51% year over year at the midpoint of $35.2 billion

[0001571996-26-000003:8k_2_02:41]
•First-quarter FY27 GAAP diluted EPS expected to be $2.55 at the midpoint, up 86% year over year, and non-GAAP diluted EPS to be $2.90 at the midpoint, up 87%

[0001571996-26-000003:8k_2_02:42]
2

[0001571996-26-000003:8k_2_02:43]
Fourth Quarter and Fiscal 2026 Financial Results

[0001571996-26-000003:8k_2_02:44]
|  | Three Months Ended |  |  |  | Fiscal Year Ended |  |  |
|  | January 30, 2026 |  | January 31, 2025 |  | Change |  | January 30, 2026 |  | January 31, 2025 |  | Change |
|  | (in millions, except per share amounts and percentages; unaudited) |
| Net revenue | $ | 33,379 |  |  | $ | 23,931 |  |  | 39% |  | $ | 113,538 |  |  | $ | 95,567 |  |  | 19% |
| Operating income | $ | 3,092 |  |  | $ | 2,159 |  |  | 43% |  | $ | 8,149 |  |  | $ | 6,237 |  |  | 31% |
| Net income | $ | 2,259 |  |  | $ | 1,532 |  |  | 47% |  | $ | 5,936 |  |  | $ | 4,576 |  |  | 30% |
| Change in cash from operating activities | $ | 4,674 |  |  | $ | 585 |  |  | 699% |  | $ | 11,185 |  |  | $ | 4,521 |  |  | 147% |
| Earnings per share — diluted | $ | 3.37 |  |  | $ | 2.15 |  |  | 57% |  | $ | 8.68 |  |  | $ | 6.38 |  |  | 36% |
| Non-GAAP operating income | $ | 3,538 |  |  | $ | 2,674 |  |  | 32% |  | $ | 9,991 |  |  | $ | 8,529 |  |  | 17% |
| Non-GAAP net income | $ | 2,607 |  |  | $ | 1,911 |  |  | 36% |  | $ | 7,046 |  |  | $ | 5,865 |  |  | 20% |
| Adjusted free cash flow | $ | 5,088 |  |  | $ | 474 |  |  | 973% |  | $ | 11,508 |  |  | $ | 3,097 |  |  | 272% |
| Non-GAAP earnings per share — diluted | $ | 3.89 |  |  | $ | 2.68 |  |  | 45% |  | $ | 10.30 |  |  | $ | 8.14 |  |  | 27% |

[0001571996-26-000003:8k_2_02:45]
Information about Dell Technologies’ non-GAAP financial measures is provided under “Non-GAAP Financial Measures” below. All comparisons in this press release are year over year unless otherwise noted.

[0001571996-26-000003:8k_2_02:46]
Operating Segments Results

[0001571996-26-000003:8k_2_02:47]
|  | Three Months Ended |  |  |  | Fiscal Year Ended |  |  |
|  | January 30, 2026 |  | January 31, 2025 |  | Change |  | January 30, 2026 |  | January 31, 2025 |  | Change |
|  | (in millions, except percentages; unaudited) |
| Infrastructure Solutions Group (ISG): |  |  |  |  |  |  |  |  |  |  |  |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |
| AI-optimized servers | 8,952 |  |  | 2,026 |  |  | 342% |  | 24,683 |  |  | 9,286 |  |  | 166% |
| Traditional servers and networking | 5,853 |  |  | 4,608 |  |  | 27% |  | 19,512 |  |  | 17,850 |  |  | 9% |
| Storage | 4,797 |  |  | 4,718 |  |  | 2% |  | 16,631 |  |  | 16,457 |  |  | 1% |
| Total ISG net revenue | $ | 19,602 |  |  | $ | 11,352 |  |  | 73% |  | $ | 60,826 |  |  | $ | 43,593 |  |  | 40% |
| Operating income: |  |  |  |  |  |  |  |  |  |  |  |
| ISG operating income | $ | 2,900 |  |  | $ | 2,051 |  |  | 41% |  | $ | 7,111 |  |  | $ | 5,579 |  |  | 27% |
| % of ISG net revenue | 14.8 | % |  | 18.1 | % |  |  |  | 11.7 | % |  | 12.8 | % |  |  |
| % of total reportable segment operating income | 82 | % |  | 76 | % |  |  |  | 72 | % |  | 65 | % |  |  |
| Client Solutions Group (CSG): |  |  |  |  |  |  |  |  |  |  |  |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Commercial | $ | 11,614 |  |  | $ | 9,996 |  |  | 16% |  | $ | 44,062 |  |  | $ | 40,844 |  |  | 8% |
| Consumer | 1,880 |  |  | 1,885 |  |  | —% |  | 6,922 |  |  | 7,549 |  |  | (8)% |
| Total CSG net revenue | $ | 13,494 |  |  | $ | 11,881 |  |  | 14% |  | $ | 50,984 |  |  | $ | 48,393 |  |  | 5% |
| Operating income: |  |  |  |  |  |  |  |  |  |  |  |
| CSG operating income | $ | 629 |  |  | $ | 631 |  |  | —% |  | $ | 2,833 |  |  | $ | 2,972 |  |  | (5)% |
| % of CSG net revenue | 4.7 | % |  | 5.3 | % |  |  |  | 5.6 | % |  | 6.1 | % |  |  |
| % of total reportable segment operating income | 18 | % |  | 24 | % |  |  |  | 28 | % |  | 35 | % |  |  |

[0001571996-26-000003:8k_2_02:48]
3

[0001571996-26-000003:8k_2_02:49]
Conference call information

[0001571996-26-000003:8k_2_02:50]
As previously announced, the company will hold a conference call to discuss its performance and financial guidance on February 26 at 3:30 p.m. CST. Prior to the start of the conference call, prepared remarks and a presentation containing additional financial and operating information may be downloaded from investors.delltechnologies.com. The conference call will be presented live over the internet and can be accessed at https://investors.delltechnologies.com/news-events/upcoming-events.

[0001571996-26-000003:8k_2_02:51]
For those unable to listen to the live presentation, the final remarks and presentation with additional financial and operating information will be available following the presentation, and an archived version will be available at the same location for one year.

[0001571996-26-000003:8k_2_02:52]
About Dell Technologies

[0001571996-26-000003:8k_2_02:53]
Dell Technologies (NYSE:DELL) helps organizations and individuals build their digital future and transform how they work, live and play. The company provides customers with the industry’s broadest and most innovative technology and services portfolio for the AI era.

[0001571996-26-000003:8k_2_02:54]
Contacts

[0001571996-26-000003:8k_2_02:55]
Investors: Investor_Relations@Dell.com

[0001571996-26-000003:8k_2_02:56]
Media: Media.Relations@Dell.com

[0001571996-26-000003:8k_2_02:57]
# # #

[0001571996-26-000003:8k_2_02:58]
Copyright © 2026 Dell Inc. or its subsidiaries. All Rights Reserved. Dell Technologies, Dell, EMC and Dell EMC are trademarks of Dell Inc. or its subsidiaries. Other trademarks may be trademarks of their respective owners.

[0001571996-26-000003:8k_2_02:59]
Non-GAAP Financial Measures:

[0001571996-26-000003:8k_2_02:60]
This press release presents information about non-GAAP gross margin, non-GAAP operating expenses, non-GAAP operating income, non-GAAP net income, non-GAAP earnings per share attributable to Dell Technologies Inc. – diluted, free cash flow, and adjusted free cash flow, all of which are non-GAAP financial measures provided as a supplement to the results provided in accordance with generally accepted accounting principles in the United States of America (“GAAP”). A reconciliation of each non-GAAP financial measure to the most directly comparable GAAP financial measure is provided in the attached tables for each of the fiscal periods indicated.

[0001571996-26-000003:8k_2_02:61]
Special Note on Forward-Looking Statements:

[0001571996-26-000003:8k_2_02:62]
Forward-looking statements include, among others, any statements regarding Dell Technologies’ expectations for first-quarter and full-year fiscal 2027 revenue, GAAP diluted earnings per share and non-GAAP diluted earnings per share, and for full-year fiscal 2027 AI-optimized servers revenue, as well as any other statements regarding Dell Technologies’ prospects and its future operations, financial condition, volumes, cash flows, expenses or other financial items, including management’s plans or strategies and objectives for any of the foregoing and any assumptions, expectations or beliefs underlying any of the foregoing.

[0001571996-26-000003:8k_2_02:63]
Dell Technologies’ results or events in future periods could differ materially from those expressed or implied by these forward-looking statements because of risks, uncertainties, and other factors that include, but are not limited to, the following: adverse global economic conditions, trade disruptions, and instability in financial markets; competitive pressures; Dell Technologies’ ability to successfully execute its strategy; Dell Technologies’ relationships with third-party suppliers for products and components; Dell Technologies’ use of single-source or limited-source suppliers; effects on Dell Technologies’ operating performance related to demand for AI solutions; management of Dell Technologies’ AI solutions and use of AI in internal functions and operations; Dell Technologies’ ability to deliver high-quality products, software, and services and to manage solutions and products and services transitions in an effective manner; Dell Technologies’ ability to successfully implement its cost efficiency plans; Dell Technologies’ ability to successfully execute on strategic initiatives including acquisitions and divestitures; security incidents, including cyber-attacks; Dell Technologies’ foreign operations and ability to generate substantial non-U.S. net revenue; Dell Technologies’ product, services, customer, and geographic sales mix, and seasonal sales trends; the performance of Dell Technologies’ sales channel partners; access to the capital markets by Dell Technologies or its customers; adverse economic conditions, changing customer mix, and the effect of additional regulation on Dell Technologies’ financial services activities;

[0001571996-26-000003:8k_2_02:64]
counterparty default risks; material impairment of the value of goodwill or intangible assets; the loss by Dell Technologies of any contracts for ISG services and solutions and its ability to perform such contracts at their estimated costs; loss by Dell Technologies of government contracts; Dell Technologies’ ability to develop and protect its proprietary intellectual property or obtain licenses to intellectual property developed by others on commercially reasonable and competitive terms; disruptions in Dell Technologies’ infrastructure; Dell Technologies’ ability to hedge effectively its exposure to fluctuations in foreign currency exchange rates and interest rates; expiration of tax holidays or favorable tax rate structures, or unfavorable outcomes in tax audits and other tax compliance matters; impairment of portfolio investments; unfavorable results of legal proceedings; evolving and varied expectations and regulatory requirements relating to sustainability issues; the effect of global climate change and related legal, regulatory or market measures; compliance with environmental and safety laws; compliance requirements of anti-corruption laws, economic sanctions and other trade laws, human rights laws, or other laws; Dell Technologies’ dependence on the services of Michael Dell and key employees; Dell Technologies’ level of indebtedness; and business and financial factors and legal restrictions affecting continuation of Dell Technologies’ quarterly cash dividend policy and dividend rate.

[0001571996-26-000003:8k_2_02:65]
This list of risks, uncertainties, and other factors is not complete. Dell Technologies discusses some of these matters more fully, as well as certain risk factors that could affect Dell Technologies’ business, financial condition, results of operations, and prospects, in its reports filed with the SEC, including Dell Technologies’ annual report on Form 10-K for the fiscal year ended January 31, 2025, quarterly reports on Form 10-Q, and current reports on Form 8-K. These filings are available for review through the SEC’s website at www.sec.gov. Any or all forward-looking statements Dell Technologies makes may turn out to be wrong and can be affected by inaccurate assumptions Dell Technologies might make or by known or unknown risks, uncertainties, and other factors, including those identified in this press release. Accordingly, you should not place undue reliance on the forward-looking statements made in this press release, which speak only as of its date. Dell Technologies does not undertake to update, and expressly disclaims any duty to update, its forward-looking statements, whether as a result of circumstances or events that arise after the date they are made, new information, or otherwise.

[0001571996-26-000003:8k_2_02:66]
5

[0001571996-26-000003:8k_2_02:67]
DELL TECHNOLOGIES INC.

[0001571996-26-000003:8k_2_02:68]
Consolidated Statements of Income and Related Financial Highlights

[0001571996-26-000003:8k_2_02:69]
(in millions, except percentages; unaudited)

[0001571996-26-000003:8k_2_02:70]
|  | Three Months Ended |  |  |  | Fiscal Year Ended |  |  |
|  | January 30, 2026 |  | January 31, 2025 |  | Change |  | January 30, 2026 |  | January 31, 2025 |  | Change |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Products | $ | 27,616 |  |  | $ | 18,049 |  |  | 53% |  | $ | 90,405 |  |  | $ | 71,420 |  |  | 27% |
| Services | 5,763 |  |  | 5,882 |  |  | (2)% |  | 23,133 |  |  | 24,147 |  |  | (4)% |
| Total net revenue | 33,379 |  |  | 23,931 |  |  | 39% |  | 113,538 |  |  | 95,567 |  |  | 19% |
| Cost of net revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Products | 23,618 |  |  | 14,924 |  |  | 58% |  | 78,057 |  |  | 60,162 |  |  | 30% |
| Services | 3,031 |  |  | 3,329 |  |  | (9)% |  | 12,774 |  |  | 14,155 |  |  | (10)% |
| Total cost of net revenue | 26,649 |  |  | 18,253 |  |  | 46% |  | 90,831 |  |  | 74,317 |  |  | 22% |
| Gross margin | 6,730 |  |  | 5,678 |  |  | 19% |  | 22,707 |  |  | 21,250 |  |  | 7% |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |
| Selling, general, and administrative | 2,841 |  |  | 2,746 |  |  | 3% |  | 11,416 |  |  | 11,952 |  |  | (4)% |
| Research and development | 797 |  |  | 773 |  |  | 3% |  | 3,142 |  |  | 3,061 |  |  | 3% |
| Total operating expenses | 3,638 |  |  | 3,519 |  |  | 3% |  | 14,558 |  |  | 15,013 |  |  | (3)% |
| Operating income | 3,092 |  |  | 2,159 |  |  | 43% |  | 8,149 |  |  | 6,237 |  |  | 31% |
| Interest and other, net | (293) |  |  | (187) |  |  | (57)% |  | (886) |  |  | (1,189) |  |  | 25% |
| Income before income taxes | 2,799 |  |  | 1,972 |  |  | 42% |  | 7,263 |  |  | 5,048 |  |  | 44% |
| Income tax expense | 540 |  |  | 440 |  |  | 23% |  | 1,327 |  |  | 472 |  |  | 181% |
| Net income | 2,259 |  |  | 1,532 |  |  | 47% |  | 5,936 |  |  | 4,576 |  |  | 30% |
| Less: Net loss attributable to non-controlling interests | — |  |  | (1) |  |  | 100% |  | — |  |  | (16) |  |  | 100% |
| Net income attributable to Dell Technologies Inc. | $ | 2,259 |  |  | $ | 1,533 |  |  | 47% |  | $ | 5,936 |  |  | $ | 4,592 |  |  | 29% |
| Percentage of Total Net Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Gross margin | 20.2 | % |  | 23.7 | % |  |  |  | 20.0 | % |  | 22.2 | % |  |  |
| Selling, general, and administrative | 8.5 | % |  | 11.5 | % |  |  |  | 10.0 | % |  | 12.5 | % |  |  |
| Research and development | 2.4 | % |  | 3.2 | % |  |  |  | 2.8 | % |  | 3.2 | % |  |  |
| Operating expenses | 10.9 | % |  | 14.7 | % |  |  |  | 12.8 | % |  | 15.7 | % |  |  |
| Operating income | 9.3 | % |  | 9.0 | % |  |  |  | 7.2 | % |  | 6.5 | % |  |  |
| Income before income taxes | 8.4 | % |  | 8.2 | % |  |  |  | 6.4 | % |  | 5.3 | % |  |  |
| Net income | 6.8 | % |  | 6.4 | % |  |  |  | 5.2 | % |  | 4.8 | % |  |  |
| Income tax rate | 19.3 | % |  | 22.3 | % |  |  |  | 18.3 | % |  | 9.4 | % |  |  |

[0001571996-26-000003:8k_2_02:71]
Amounts are based on underlying data and may not visually foot due to rounding.

[0001571996-26-000003:8k_2_02:72]
DELL TECHNOLOGIES INC.

[0001571996-26-000003:8k_2_02:73]
Consolidated Statements of Financial Position

[0001571996-26-000003:8k_2_02:74]
(in millions; unaudited)

[0001571996-26-000003:8k_2_02:75]
|  | January 30, 2026 |  | January 31, 2025 |
| ASSETS |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 11,528 |  |  | $ | 3,633 |  |
| Accounts receivable, net of allowance of $77 and $63 | 17,585 |  |  | 10,298 |  |
| Short-term financing receivables, net of allowance of $121 and $78 | 8,458 |  |  | 5,304 |  |
| Inventories | 10,437 |  |  | 6,716 |  |
| Other current assets | 9,594 |  |  | 9,610 |  |
| Current assets held for sale | — |  |  | 668 |  |
| Total current assets | 57,602 |  |  | 36,229 |  |
| Property, plant, and equipment, net | 6,676 |  |  | 6,336 |  |
| Long-term investments | 1,730 |  |  | 1,496 |  |
| Long-term financing receivables, net of allowance of $92 and $75 | 5,822 |  |  | 5,927 |  |
| Goodwill | 19,547 |  |  | 19,120 |  |
| Intangible assets, net | 4,533 |  |  | 4,988 |  |
| Other non-current assets | 5,376 |  |  | 5,650 |  |
| Total assets | $ | 101,286 |  |  | $ | 79,746 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |
| Short-term debt | $ | 7,990 |  |  | $ | 5,204 |  |
| Accounts payable | 33,630 |  |  | 20,832 |  |
| Accrued and other | 8,315 |  |  | 6,597 |  |
| Short-term deferred revenue | 13,334 |  |  | 13,673 |  |
| Current liabilities held for sale | — |  |  | 221 |  |
| Total current liabilities | 63,269 |  |  | 46,527 |  |
| Long-term debt | 23,513 |  |  | 19,363 |  |
| Long-term deferred revenue | 13,596 |  |  | 12,292 |  |
| Other non-current liabilities | 3,378 |  |  | 2,951 |  |
| Total liabilities | 103,756 |  |  | 81,133 |  |
| Stockholders’ equity (deficit): |  |  |  |
| Common stock and capital in excess of $0.01 par value | 9,457 |  |  | 9,119 |  |
| Treasury stock at cost | (14,533) |  |  | (8,502) |  |
| Retained earnings (accumulated deficit) | 3,325 |  |  | (1,160) |  |
| Accumulated other comprehensive loss | (719) |  |  | (939) |  |
| Total Dell Technologies Inc. stockholders’ equity (deficit) | (2,470) |  |  | (1,482) |  |
| Non-controlling interests | — |  |  | 95 |  |
| Total stockholders’ equity (deficit) | (2,470) |  |  | (1,387) |  |
| Total liabilities and stockholders’ equity | $ | 101,286 |  |  | $ | 79,746 |  |

[0001571996-26-000003:8k_2_02:76]
7

[0001571996-26-000003:8k_2_02:77]
DELL TECHNOLOGIES INC.

[0001571996-26-000003:8k_2_02:78]
Consolidated Statements of Cash Flows

[0001571996-26-000003:8k_2_02:79]
(in millions; unaudited)

[0001571996-26-000003:8k_2_02:80]
|  | Three Months Ended |  | Fiscal Year Ended |
|  | January 30, 2026 |  | January 31, 2025 |  | January 30, 2026 |  | January 31, 2025 |
| Cash flows from operating activities: |  |  |  |  |  |  |  |
| Net income | $ | 2,259 |  |  | $ | 1,532 |  |  | $ | 5,936 |  |  | $ | 4,576 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: | 2,415 |  |  | (947) |  |  | 5,249 |  |  | (55) |  |
| Change in cash from operating activities | 4,674 |  |  | 585 |  |  | 11,185 |  |  | 4,521 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |
| Purchases of investments | (26) |  |  | (42) |  |  | (197) |  |  | (125) |  |
| Maturities and sales of investments | 116 |  |  | 45 |  |  | 246 |  |  | 382 |  |
| Capital expenditures and capitalized software development costs | (721) |  |  | (735) |  |  | (2,633) |  |  | (2,652) |  |
| Acquisition of businesses and assets, net | (84) |  |  | — |  |  | (84) |  |  | — |  |
| Divestitures of businesses and assets, net | — |  |  | — |  |  | 533 |  |  | — |  |
| Other | 20 |  |  | 54 |  |  | 80 |  |  | 180 |  |
| Change in cash from investing activities | (695) |  |  | (678) |  |  | (2,055) |  |  | (2,215) |  |
| Cash flows from financing activities: |  |  |  |  |  |  |  |
| Proceeds from the issuance of common stock | — |  |  | — |  |  | 5 |  |  | 1 |  |
| Repurchases of common stock | (1,847) |  |  | (734) |  |  | (6,014) |  |  | (2,588) |  |
| Repurchases of common stock for employee tax withholdings | (11) |  |  | (17) |  |  | (390) |  |  | (577) |  |
| Payments of dividends and dividend equivalents | (346) |  |  | (311) |  |  | (1,459) |  |  | (1,275) |  |
| Proceeds from debt | 1,232 |  |  | 645 |  |  | 15,004 |  |  | 9,258 |  |
| Repayments of debt | (1,121) |  |  | (976) |  |  | (8,522) |  |  | (10,570) |  |
| Debt-related costs and other, net | — |  |  | 2 |  |  | (88) |  |  | (64) |  |
| Change in cash from financing activities | (2,093) |  |  | (1,391) |  |  | (1,464) |  |  | (5,815) |  |
| Effect of exchange rate changes on cash, cash equivalents, and restricted cash | 87 |  |  | (101) |  |  | 221 |  |  | (179) |  |
| Change in cash, cash equivalents, and restricted cash | 1,973 |  |  | (1,585) |  |  | 7,887 |  |  | (3,688) |  |
| Cash, cash equivalents, and restricted cash at beginning of the period | 9,733 |  |  | 5,404 |  |  | 3,819 |  |  | 7,507 |  |
| Cash, cash equivalents, and restricted cash at end of the period | $ | 11,706 |  |  | $ | 3,819 |  |  | $ | 11,706 |  |  | $ | 3,819 |  |

[0001571996-26-000003:8k_2_02:81]
DELL TECHNOLOGIES INC.

[0001571996-26-000003:8k_2_02:82]
Segment Information

[0001571996-26-000003:8k_2_02:83]
(in millions, except percentages; unaudited; continued on next page)

[0001571996-26-000003:8k_2_02:84]
|  | Three Months Ended |  |  |  | Fiscal Year Ended |  |  |
|  | January 30, 2026 |  | January 31, 2025 |  | Change |  | January 30, 2026 |  | January 31, 2025 |  | Change |
| Infrastructure Solutions Group (ISG): |  |  |  |  |  |  |  |  |  |  |  |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |
| AI-optimized servers | $ | 8,952 |  | $ | 2,026 |  |  | 342% |  | $ | 24,683 |  |  | $ | 9,286 |  |  | 166% |
| Traditional servers and networking | 5,853 |  |  | 4,608 |  |  | 27% |  | 19,512 |  |  | 17,850 |  |  | 9% |
| Storage | 4,797 |  |  | 4,718 |  |  | 2% |  | 16,631 |  |  | 16,457 |  |  | 1% |
| Total ISG net revenue | $ | 19,602 |  |  | $ | 11,352 |  |  | 73% |  | $ | 60,826 |  |  | $ | 43,593 |  |  | 40% |
| Operating income: |  |  |  |  |  |  |  |  |  |  |  |
| ISG operating income | $ | 2,900 |  |  | $ | 2,051 |  |  | 41% |  | $ | 7,111 |  |  | $ | 5,579 |  |  | 27% |
| % of ISG net revenue | 14.8 | % |  | 18.1 | % |  |  |  | 11.7 | % |  | 12.8 | % |  |  |
| % of total reportable segment operating income | 82 | % |  | 76 | % |  |  |  | 72 | % |  | 65 | % |  |  |
| Client Solutions Group (CSG): |  |  |  |  |  |  |  |  |  |  |  |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Commercial | $ | 11,614 |  |  | $ | 9,996 |  |  | 16% |  | $ | 44,062 |  |  | $ | 40,844 |  |  | 8% |
| Consumer | 1,880 |  |  | 1,885 |  |  | —% |  | 6,922 |  |  | 7,549 |  |  | (8)% |
| Total CSG net revenue | $ | 13,494 |  |  | $ | 11,881 |  |  | 14% |  | $ | 50,984 |  |  | $ | 48,393 |  |  | 5% |
| Operating income: |  |  |  |  |  |  |  |  |  |  |  |
| CSG operating income | $ | 629 |  |  | $ | 631 |  |  | —% |  | $ | 2,833 |  |  | $ | 2,972 |  |  | (5)% |
| % of CSG net revenue | 4.7 | % |  | 5.3 | % |  |  |  | 5.6 | % |  | 6.1 | % |  |  |
| % of total reportable segment operating income | 18 | % |  | 24 | % |  |  |  | 28 | % |  | 35 | % |  |  |

[0001571996-26-000003:8k_2_02:85]
Amounts are based on underlying data and may not visually foot due to rounding.

[0001571996-26-000003:8k_2_02:86]
9

[0001571996-26-000003:8k_2_02:87]
DELL TECHNOLOGIES INC.

[0001571996-26-000003:8k_2_02:88]
Segment Information

[0001571996-26-000003:8k_2_02:89]
(in millions; unaudited; continued)

[0001571996-26-000003:8k_2_02:90]
|  | Three Months Ended |  | Fiscal Year Ended |
|  | January 30, 2026 |  | January 31, 2025 |  | January 30, 2026 |  | January 31, 2025 |
| Reconciliation to consolidated net revenue: |  |  |  |  |  |  |  |
| Reportable segment net revenue | $ | 33,096 |  |  | $ | 23,233 |  |  | $ | 111,810 |  |  | $ | 91,986 |  |
| Corporate and other (a) | 283 |  |  | 698 |  |  | 1,728 |  |  | 3,581 |  |
| Total consolidated net revenue | $ | 33,379 |  |  | $ | 23,931 |  |  | $ | 113,538 |  |  | $ | 95,567 |  |
| Reconciliation to consolidated operating income: |  |  |  |  |  |  |
| Reportable segment operating income (b) | $ | 3,529 |  |  | $ | 2,682 |  |  | $ | 9,944 |  |  | $ | 8,551 |  |
| Corporate and other (a) | 9 |  |  | (8) |  |  | 47 |  |  | (22) |  |
| Amortization of intangibles (c) | (125) |  |  | (163) |  |  | (497) |  |  | (667) |  |
| Stock-based compensation expense (d) | (189) |  |  | (186) |  |  | (723) |  |  | (785) |  |
| Other corporate expenses (e) | (132) |  |  | (166) |  |  | (622) |  |  | (840) |  |
| Total consolidated operating income (f) | $ | 3,092 |  |  | $ | 2,159 |  |  | $ | 8,149 |  |  | $ | 6,237 |  |

[0001571996-26-000003:8k_2_02:91]
_________________

[0001571996-26-000003:8k_2_02:92]
(a)Corporate and other consists of results of divested businesses or non-reportable segments whose offerings are no longer actively sold, including (i) VMware Resale, (ii) Secureworks, and (iii) Virtustream, and do not meet the requirements for a reportable segment, either individually or collectively. Additionally, Corporate and other includes other items that are managed at the corporate level and are not allocated to reportable segments.

[0001571996-26-000003:8k_2_02:93]
(b)Depreciation expense directly attributable to each reportable segment is included in the operating results of each segment. However, the Chief Operating Decision Maker does not evaluate depreciation expense by operating segment, and therefore such expense is not separately presented.

[0001571996-26-000003:8k_2_02:94]
(c)Amortization of intangibles includes non-cash purchase accounting adjustments that are primarily related to the EMC merger transaction completed in September 2016.

[0001571996-26-000003:8k_2_02:95]
(d)Stock-based compensation expense consists of equity awards granted based on the estimated fair value of those awards at grant date.

[0001571996-26-000003:8k_2_02:96]
(e)Other corporate expenses includes severance expenses, payroll taxes associated with stock-based compensation, incentive charges related to equity investments, facility action costs, transaction-related expenses, and impairment charges.

[0001571996-26-000003:8k_2_02:97]
(f)Income and expenses within Interest and other, net, is not allocated to the reportable segments. Therefore, the company only reports reportable segment operating income.

[0001571996-26-000003:8k_2_02:98]
SUPPLEMENTAL SELECTED NON-GAAP FINANCIAL MEASURES

[0001571996-26-000003:8k_2_02:99]
These tables present information about the company’s non-GAAP gross margin, non-GAAP operating expenses, non-GAAP operating income, non-GAAP net income, non-GAAP earnings per share attributable to Dell Technologies Inc. - diluted, free cash flow and adjusted free cash flow, all of which are non-GAAP financial measures provided as a supplement to the results provided in accordance with generally accepted accounting principles in the United States of America (“GAAP”). A detailed discussion of Dell Technologies’ reasons for including certain of these non-GAAP financial measures, the limitations associated with these measures, the items excluded from these measures, and the company’s reason for excluding those items are presented in “Management’s Discussion and Analysis of Financial Condition and Results of Operations — Non-GAAP Financial Measures” in the company’s periodic reports filed with the SEC. Dell Technologies encourages investors to review the non-GAAP discussion in these reports in conjunction with the presentation of non-GAAP financial measures.

[0001571996-26-000003:8k_2_02:100]
11

[0001571996-26-000003:8k_2_02:101]
DELL TECHNOLOGIES INC.

[0001571996-26-000003:8k_2_02:102]
Selected Financial Measures

[0001571996-26-000003:8k_2_02:103]
(in millions, except per share amounts and percentages; unaudited)

[0001571996-26-000003:8k_2_02:104]
|  | Three Months Ended |  |  |  | Fiscal Year Ended |  |  |
|  | January 30, 2026 |  | January 31, 2025 |  | Change |  | January 30, 2026 |  | January 31, 2025 |  | Change |
| Net revenue | $ | 33,379 |  |  | $ | 23,931 |  |  | 39% |  | $ | 113,538 |  |  | $ | 95,567 |  |  | 19% |
| Non-GAAP gross margin | $ | 6,844 |  |  | $ | 5,814 |  |  | 18% |  | $ | 23,159 |  |  | $ | 21,810 |  |  | 6% |
| % of net revenue | 20.5 | % |  | 24.3 | % |  |  |  | 20.4 | % |  | 22.8 | % |  |  |
| Non-GAAP operating expenses | $ | 3,306 |  |  | $ | 3,140 |  |  | 5% |  | $ | 13,168 |  |  | $ | 13,281 |  |  | (1)% |
| % of net revenue | 9.9 | % |  | 13.1 | % |  |  |  | 11.6 | % |  | 13.9 | % |  |  |
| Non-GAAP operating income | $ | 3,538 |  |  | $ | 2,674 |  |  | 32% |  | $ | 9,991 |  |  | $ | 8,529 |  |  | 17% |
| % of net revenue | 10.6 | % |  | 11.2 | % |  |  |  | 8.8 | % |  | 8.9 | % |  |  |
| Non-GAAP net income | $ | 2,607 |  |  | $ | 1,911 |  |  | 36% |  | $ | 7,046 |  |  | $ | 5,865 |  |  | 20% |
| % of net revenue | 7.8 | % |  | 8.0 | % |  |  |  | 6.2 | % |  | 6.1 | % |  |  |
| Non-GAAP earnings per share — diluted | $ | 3.89 |  |  | $ | 2.68 |  |  | 45% |  | $ | 10.30 |  |  | $ | 8.14 |  |  | 27% |

[0001571996-26-000003:8k_2_02:105]
Amounts are based on underlying data and may not visually foot due to rounding.

[0001571996-26-000003:8k_2_02:106]
DELL TECHNOLOGIES INC.

[0001571996-26-000003:8k_2_02:107]
Reconciliation of Selected Non-GAAP Financial Measures

[0001571996-26-000003:8k_2_02:108]
(in millions, except percentages; unaudited; continued on next page)

[0001571996-26-000003:8k_2_02:109]
|  | Three Months Ended |  |  |  | Fiscal Year Ended |  |  |
|  | January 30, 2026 |  | January 31, 2025 |  | Change |  | January 30, 2026 |  | January 31, 2025 |  | Change |
| Gross margin | $ | 6,730 |  |  | $ | 5,678 |  |  | 19% |  | $ | 22,707 |  |  | $ | 21,250 |  |  | 7% |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 41 |  |  | 59 |  |  |  |  | 162 |  |  | 238 |  |  |  |
| Stock-based compensation expense | 43 |  |  | 37 |  |  |  |  | 157 |  |  | 152 |  |  |  |
| Other corporate expenses | 30 |  |  | 40 |  |  |  |  | 133 |  |  | 170 |  |  |  |
| Non-GAAP gross margin | $ | 6,844 |  |  | $ | 5,814 |  |  | 18% |  | $ | 23,159 |  |  | $ | 21,810 |  |  | 6% |
| Operating expenses | $ | 3,638 |  |  | $ | 3,519 |  |  | 3% |  | $ | 14,558 |  |  | $ | 15,013 |  |  | (3)% |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | (84) |  |  | (104) |  |  |  |  | (335) |  |  | (429) |  |  |  |
| Stock-based compensation expense | (146) |  |  | (149) |  |  |  |  | (566) |  |  | (633) |  |  |  |
| Other corporate expenses | (102) |  |  | (126) |  |  |  |  | (489) |  |  | (670) |  |  |  |
| Non-GAAP operating expenses | $ | 3,306 |  |  | $ | 3,140 |  |  | 5% |  | $ | 13,168 |  |  | $ | 13,281 |  |  | (1)% |
| Operating income | $ | 3,092 |  |  | $ | 2,159 |  |  | 43% |  | $ | 8,149 |  |  | $ | 6,237 |  |  | 31% |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 125 |  |  | 163 |  |  |  |  | 497 |  |  | 667 |  |  |  |
| Stock-based compensation expense | 189 |  |  | 186 |  |  |  |  | 723 |  |  | 785 |  |  |  |
| Other corporate expenses | 132 |  |  | 166 |  |  |  |  | 622 |  |  | 840 |  |  |  |
| Non-GAAP operating income | $ | 3,538 |  |  | $ | 2,674 |  |  | 32% |  | $ | 9,991 |  |  | $ | 8,529 |  |  | 17% |
| Net income | $ | 2,259 |  |  | $ | 1,532 |  |  | 47% |  | $ | 5,936 |  |  | $ | 4,576 |  |  | 30% |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 125 |  |  | 163 |  |  |  |  | 497 |  |  | 667 |  |  |  |
| Stock-based compensation expense | 189 |  |  | 186 |  |  |  |  | 723 |  |  | 785 |  |  |  |
| Other corporate expenses | 127 |  |  | 165 |  |  |  |  | 364 |  |  | 830 |  |  |  |
| Fair value adjustments on equity investments | (60) |  |  | (156) |  |  |  |  | (254) |  |  | (177) |  |  |  |
| Aggregate adjustment for income taxes (a) | (33) |  |  | 21 |  |  |  |  | (220) |  |  | (816) |  |  |  |
| Non-GAAP net income | $ | 2,607 |  |  | $ | 1,911 |  |  | 36% |  | $ | 7,046 |  |  | $ | 5,865 |  |  | 20% |

[0001571996-26-000003:8k_2_02:110]
____________________

[0001571996-26-000003:8k_2_02:111]
(a)The company’s non-GAAP income tax is calculated using a fixed estimated annual tax rate.

[0001571996-26-000003:8k_2_02:112]
13

[0001571996-26-000003:8k_2_02:113]
DELL TECHNOLOGIES INC.

[0001571996-26-000003:8k_2_02:114]
Reconciliation of Selected Non-GAAP Financial Measures

[0001571996-26-000003:8k_2_02:115]
(unaudited; continued)

[0001571996-26-000003:8k_2_02:116]
|  | Three Months Ended |  |  |  | Fiscal Year Ended |  |  |
|  | January 30, 2026 |  | January 31, 2025 |  | Change |  | January 30, 2026 |  | January 31, 2025 |  | Change |
| Earnings per share attributable to Dell Technologies Inc. — diluted | $ | 3.37 |  |  | $ | 2.15 |  |  | 57 | % |  | $ | 8.68 |  |  | $ | 6.38 |  |  | 36 | % |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 0.19 |  |  | 0.22 |  |  |  |  | 0.72 |  |  | 0.93 |  |  |  |
| Stock-based compensation expense | 0.28 |  |  | 0.26 |  |  |  |  | 1.06 |  |  | 1.09 |  |  |  |
| Other corporate expenses | 0.19 |  |  | 0.23 |  |  |  |  | 0.53 |  |  | 1.16 |  |  |  |
| Fair value adjustments on equity investments | (0.09) |  |  | (0.22) |  |  |  |  | (0.37) |  |  | (0.25) |  |  |  |
| Aggregate adjustment for income taxes (a) | (0.05) |  |  | 0.04 |  |  |  |  | (0.32) |  |  | (1.15) |  |  |  |
| Total non-GAAP adjustments attributable to non-controlling interests | — |  |  | — |  |  |  |  | — |  |  | (0.02) |  |  |  |
| Non-GAAP earnings per share attributable to Dell Technologies Inc. — diluted | $ | 3.89 |  |  | $ | 2.68 |  |  | 45 | % |  | $ | 10.30 |  |  | $ | 8.14 |  |  | 27 | % |

[0001571996-26-000003:8k_2_02:117]
____________________

[0001571996-26-000003:8k_2_02:118]
(a)The company’s non-GAAP income tax is calculated using a fixed estimated annual tax rate.

[0001571996-26-000003:8k_2_02:119]
DELL TECHNOLOGIES INC.

[0001571996-26-000003:8k_2_02:120]
Reconciliation of Selected Non-GAAP Financial Measures

[0001571996-26-000003:8k_2_02:121]
(in millions, except percentages; unaudited; continued)

[0001571996-26-000003:8k_2_02:122]
|  | Three Months Ended |  |  |  | Fiscal Year Ended |  |  |
|  | January 30, 2026 |  | January 31, 2025 |  | Change |  | January 30, 2026 |  | January 31, 2025 |  | Change |
| Cash flow from operations | $ | 4,674 |  |  | $ | 585 |  |  | 699 | % |  | $ | 11,185 |  |  | $ | 4,521 |  |  | 147 | % |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Capital expenditures and capitalized software development costs, net (a) | (721) |  |  | (702) |  |  |  |  | (2,630) |  |  | (2,563) |  |  |  |
| Free cash flow | $ | 3,953 |  |  | $ | (117) |  |  | NM |  | $ | 8,555 |  |  | $ | 1,958 |  |  | 337 | % |
| Free cash flow | $ | 3,953 |  |  | $ | (117) |  |  | NM |  | $ | 8,555 |  |  | $ | 1,958 |  |  | 337 | % |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Financing receivables (b) | 1,036 |  |  | 532 |  |  |  |  | 2,740 |  |  | 951 |  |  |  |
| Equipment under operating leases (c) | 99 |  |  | 59 |  |  |  |  | 213 |  |  | 188 |  |  |  |
| Adjusted free cash flow | $ | 5,088 |  |  | $ | 474 |  |  | 973 | % |  | $ | 11,508 |  |  | $ | 3,097 |  |  | 272 | % |

[0001571996-26-000003:8k_2_02:123]
____________________

[0001571996-26-000003:8k_2_02:124]
(a)Capital expenditures and capitalized software development costs, net includes proceeds from sales of facilities, land, and other assets.

[0001571996-26-000003:8k_2_02:125]
(b)Financing receivables represent the operating cash flow impact from the change in financing receivables.

[0001571996-26-000003:8k_2_02:126]
(c)Equipment under operating leases represents the net impact of capital expenditures and depreciation expense for leases and contractually embedded leases identified within flexible consumption arrangements.

[0001571996-26-000003:8k_2_02:127]
DELL TECHNOLOGIES INC.

[0001571996-26-000003:8k_2_02:128]
Reconciliation of Non-GAAP Financial Measures in Summary Guidance

[0001571996-26-000003:8k_2_02:129]
(unaudited)

[0001571996-26-000003:8k_2_02:130]
|  |  | Three Months Ending |  | Fiscal Year Ending |
|  |  | May 1, 2026 |  | January 29, 2027 |
| Earnings per share attributable to Dell Technologies Inc. — diluted |  | $ | 2.55 |  |  | $ | 11.52 |  |
| Non-GAAP adjustments: |  |  |  |  |
| Amortization of intangibles (a) |  | 0.15 |  |  | 0.59 |  |
| Stock-based compensation |  | 0.28 |  |  | 1.10 |  |
| Other corporate expenses (b) |  | — |  |  | — |  |
| Fair value adjustments on equity investments (c) |  | — |  |  | — |  |
| Aggregate adjustment for income taxes (d) |  | (0.08) |  |  | (0.31) |  |
| Non-GAAP earnings per share attributable to Dell Technologies Inc. — diluted |  | $ | 2.90 |  |  | $ | 12.90 |  |

[0001571996-26-000003:8k_2_02:131]
____________________

[0001571996-26-000003:8k_2_02:132]
(a)Amortization of intangibles represents an estimate for acquisitions completed as of January 30, 2026 and does not include estimates for potential acquisitions, if any, during fiscal 2027.

[0001571996-26-000003:8k_2_02:133]
(b)Consists primarily of severance expenses, payroll taxes associated with stock-based compensation, facility action costs, transaction-related expenses, impairment charges, and incentive charges related to equity investments. No estimate is included for severance expense as such expense cannot be reasonably estimated at this time.

[0001571996-26-000003:8k_2_02:134]
(c)No estimates are included for potential fair value adjustments on strategic investments given the potential volatility of either gains or losses on those equity investments.

[0001571996-26-000003:8k_2_02:135]
(d)The fiscal 2027 aggregate adjustment to reconcile non-GAAP income tax expense to GAAP income tax expense is approximately $0.2 billion. The aggregate adjustment for income taxes is the estimated combined income tax effect for the adjustments shown above as well as an adjustment for discrete tax items. The company’s non-GAAP income tax is calculated using a fixed estimated annual tax rate.
