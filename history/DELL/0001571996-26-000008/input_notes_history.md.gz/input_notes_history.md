# DELL note change history — 0001571996-25-000102 → 0001571996-25-000127


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2025-12-09):
[0001571996-25-000127:note_history:1]
The Company has contractual obligations to purchase goods or services, which specify significant terms (including fixed or minimum quantities to be purchased), fixed, minimum, or variable price provisions, and the approximate timing of the transaction. Purchase obligations are primarily related to commitments with suppliers and software maintenance and support services. As of October 31, 2025, such purchase obligations were $6.0 billion for the remainder of Fiscal 2026, $0.7 billion for Fiscal 2027, $0.6 billion for Fiscal 2028, $0.5 billion for Fiscal 2029, and $0.7 billion for Fiscal 2030 and thereafter.
  (was, 2025-09-08, similarity 0.9887):
[0001571996-25-000102:note_history:1]
The Company has contractual obligations to purchase goods or services, which specify significant terms (including fixed or minimum quantities to be purchased), fixed, minimum, or variable price provisions, and the approximate timing of the transaction. Purchase obligations are primarily related to commitments with suppliers and software maintenance and support services. As of August 1, 2025, such purchase obligations were $5.1 billion for the remainder of Fiscal 2026, $0.7 billion for Fiscal 2027, $0.5 billion for Fiscal 2028, $0.4 billion for Fiscal 2029, and $0.5 billion for Fiscal 2030 and thereafter.

- changed (2025-12-09):
[0001571996-25-000127:note_history:2]
The Company accrues a liability when it believes that it is both probable that a liability has been incurred and that it can reasonably estimate the amount of the loss. The Company reviews these accruals at least quarterly and adjusts them to reflect ongoing negotiations, settlements, rulings, advice of legal counsel, and other relevant information. To the extent new information is obtained and the Company’s views on the probable outcomes of claims, suits, assessments, investigations, or legal proceedings change, changes in the Company’s accrued liabilities are recorded in the period in which such a determination is made. For some matters, the incurrence of a liability is not probable or the amount cannot be reasonably estimated and therefore accruals have not been made. As of October 31, 2025, the Company does not currently anticipate that any of the legal proceedings it is involved in will have a material adverse effect on its business, financial condition, results of operations, or cash flows.
  (was, 2025-09-08, similarity 0.9935):
[0001571996-25-000102:note_history:2]
The Company accrues a liability when it believes that it is both probable that a liability has been incurred and that it can reasonably estimate the amount of the loss. The Company reviews these accruals at least quarterly and adjusts them to reflect ongoing negotiations, settlements, rulings, advice of legal counsel, and other relevant information. To the extent new information is obtained and the Company’s views on the probable outcomes of claims, suits, assessments, investigations, or legal proceedings change, changes in the Company’s accrued liabilities are recorded in the period in which such a determination is made. For some matters, the incurrence of a liability is not probable or the amount cannot be reasonably estimated and therefore accruals have not been made. As of August 1, 2025, the Company does not currently anticipate that any of the legal proceedings it is involved in will have a material adverse effect on its business, financial condition, results of operations, or cash flows.

- added (2025-12-09):
[0001571996-25-000127:note_history:3]
In accordance with the relevant accounting guidance, the Company provides disclosures of matters where it is at least reasonably possible that the Company could experience a material loss exceeding the amounts already accrued for across all proceedings or matters. In addition, the Company also discloses matters based on its consideration of other matters and qualitative factors, including the experience of other companies in the industry, and investor, customer, and employee relations considerations. As of October 31, 2025, the Company does not believe there is a reasonable possibility that a material loss exceeding the amounts already accrued for across all proceedings or matters has been incurred. However, since the ultimate resolution of any such proceedings and matters is inherently unpredictable, the Company’s business, financial condition, results of operations, or cash flows could be materially affected in any particular period by unfavorable outcomes in one or more of these proceedings or matters. Whether the outcome of any claim, suit, assessment, investigation, or legal proceeding, individually or collectively, could have a material adverse effect on the Company’s business, financial condition, results of operations, or cash flows will depend on a number of factors, including the nature, timing, and amount of any associated expenses, amounts paid in settlement, damages, or other remedies or consequences.

- changed (2025-12-09):
[0001571996-25-000127:note_history:4]
Under the Separation and Distribution Agreement entered into with VMware, Inc. upon completion of its spin-off of VMware, Inc. on November 1, 2021, Dell Technologies agreed to indemnify VMware, Inc., each of its subsidiaries and each of their respective directors, officers, employees, as well as any successors and assigns of the foregoing, from and against all liabilities relating to, arising out of or resulting from, among other matters, the liabilities allocated to Dell Technologies as part of the separation of Dell Technologies and VMware, Inc. (currently operating under the name VMware LLC, and individually and together with its subsidiaries, “VMware”) and their respective businesses (the “Separation”). VMware similarly agreed to indemnify Dell Technologies Inc., each of its subsidiaries and each of their respective directors, officers, and employees from and against all liabilities relating to, arising out of or resulting from, among other matters, the liabilities allocated to VMware as part of the Separation. The amounts that VMware and Dell Technologies may be obligated to pay each other could vary depending on the outcome of certain unresolved tax matters, which may not be resolved for several years. Net income tax indemnification receivables from VMware were immaterial as of October 31, 2025 and January 31, 2025.
  (was, 2025-09-08, similarity 0.9951):
[0001571996-25-000102:note_history:4]
Under the Separation and Distribution Agreement entered into with VMware, Inc. upon completion of its spin-off of VMware, Inc. on November 1, 2021, Dell Technologies agreed to indemnify VMware, Inc., each of its subsidiaries and each of their respective directors, officers, employees, as well as any successors and assigns of the foregoing, from and against all liabilities relating to, arising out of or resulting from, among other matters, the liabilities allocated to Dell Technologies as part of the separation of Dell Technologies and VMware, Inc. (currently operating under the name VMware LLC, and individually and together with its subsidiaries, “VMware”) and their respective businesses (the “Separation”). VMware similarly agreed to indemnify Dell Technologies Inc., each of its subsidiaries and each of their respective directors, officers, and employees from and against all liabilities relating to, arising out of or resulting from, among other matters, the liabilities allocated to VMware as part of the Separation. The amounts that VMware and Dell Technologies may be obligated to pay each other could vary depending on the outcome of certain unresolved tax matters, which may not be resolved for several years. Net income tax indemnification receivables from VMware were immaterial as of August 1, 2025 and January 31, 2025.

- removed (2025-12-09):
[0001571996-25-000102:note_history:5]
In accordance with the relevant accounting guidance, the Company provides disclosures of matters where it is at least reasonably possible that the Company could experience a material loss exceeding the amounts already accrued for across all proceedings or matters. In addition, the Company also discloses matters based on its consideration of other matters and qualitative factors, including the experience of other companies in the industry, and investor, customer, and employee relations considerations. As of August 1, 2025, the Company does not believe there is a reasonable possibility that a material loss exceeding the amounts already accrued for across all proceedings or matters has been incurred. However, since the ultimate resolution of any such proceedings and matters is inherently unpredictable, the Company’s business, financial condition, results of operations, or cash flows could be materially affected in any particular period by unfavorable outcomes in one or more of these proceedings or matters. Whether the outcome of any claim, suit, assessment, investigation, or legal proceeding, individually or collectively, could have a material adverse effect on the Company’s business, financial condition, results of operations, or cash flows will depend on a number of factors, including the nature, timing, and amount of any associated expenses, amounts paid in settlement, damages, or other remedies or consequences.


## dell:CreditLossFinancialInstrumentLeasesDebtVariableInterestEntitiesAndCustomerReceivablesSalesTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-12-09):
[0001571996-25-000127:note_history:6]
FINANCIAL SERVICES 
The Company offers or arranges a portfolio of payment and consumption solutions and services for its customers globally, including utility, subscription, as-a-Service, leases, and loans, designed to match customers' consumption and financing preferences and to provide operational and financial flexibility.
  (was, 2025-09-08, similarity 0.98):
[0001571996-25-000102:note_history:6]
FINANCIAL SERVICES 
The Company offers or arranges a portfolio of payment and consumption solutions and services for its customers globally, including utility, subscription, as-a-Service, leases, and loans designed to match customers' consumption and financing preferences, and provide operational and financial flexibility.

- changed (2025-12-09):
[0001571996-25-000127:note_history:7]
To support financing solutions and services as part of the Dell Technologies portfolio, Dell Financial Services and its affiliates (“DFS”) originates, collects, and services customer financing arrangements primarily related to the purchase and use of Dell Technologies products and services. In some cases, the Company also offers financing for the purchase of third-party technology products that complement the portfolio of products and services. New financing originations were $3.1 billion and $1.6 billion for the three months ended October 31, 2025 and November 1, 2024, respectively, and $7.1 billion and $5.9 billion for the nine months ended October 31, 2025 and November 1, 2024, respectively.
  (was, 2025-09-08, similarity 0.7976):
[0001571996-25-000102:note_history:7]
To support financing solutions and services as part of the Dell Technologies portfolio, Dell Financial Services and its affiliates (“DFS”) originates, collects, and services customer financing arrangements primarily related to the purchase and use of Dell Technologies products and services. In some cases, the Company also offers financing for the purchase of third-party technology products that complement the portfolio of products and services. New financing originations were $2.4 billion for both the three months ended August 1, 2025 and August 2, 2024, and $4.0 billion and $4.3 billion for the six months ended August 1, 2025 and August 2, 2024, respectively.

- changed (2025-12-09):
[0001571996-25-000127:note_history:8]
Leases — The Company enters into fixed-term financing arrangements with customers who seek lease financing for equipment. Leases are generally classified as sales-type leases or operating leases. Additionally, utility, subscription, and as-a-Service flexible consumption models may result in identification of embedded lease arrangements that require the recognition of sales-type leases or operating leases. Leases with business customers generally have fixed terms of two to five years.
  (was, 2025-09-08, similarity 0.9795):
[0001571996-25-000102:note_history:8]
Leases — The Company enters into fixed-term financing arrangements with customers who seek lease financing for equipment. Leases are generally classified as sales-type leases or operating leases. Additionally, utility, subscription, and as-a-Service flexible consumption models may result in identification of embedded lease arrangements that require the recognition of sales-type leases or operating leases. Leases with business customers have fixed terms of generally two to five years.

- added (2025-12-09):
[0001571996-25-000127:note_history:9]
Loans — The Company also offers fixed-term loans to qualified small businesses, large commercial accounts, governmental organizations, educational entities, and certain individual consumer customers. These loans are repaid in periodic payments including interest and have defined terms typically ranging from one to five years. The fair value of the fixed-term loan portfolio is determined using market observable inputs. The carrying value of these loans approximates fair value.

- changed (2025-12-09):
[0001571996-25-000127:note_history:10]
The Company historically offered revolving loans primarily to small and medium-sized commercial customers. During Fiscal 2025, the Company discontinued remaining offerings under the revolving loan portfolio. The Company continues to support existing customer arrangements as well as to transition these customers to fixed-term offerings. Due to the short-term nature of the revolving loan portfolio, in which transactions are typically repaid within twelve months on average, the portfolio had substantially transitioned to fixed-term offerings as of October 31, 2025.
  (was, 2025-09-08, similarity 0.9839):
[0001571996-25-000102:note_history:10]
The Company historically offered revolving loans primarily to small and medium-sized commercial customers. During Fiscal 2025, the Company discontinued remaining offerings under the revolving loan portfolio. The Company continues to support existing customer arrangements as well as to transition these customers to fixed-term offerings. Due to the short-term nature of the revolving loan portfolio, in which transactions are typically repaid within twelve months on average, the portfolio had substantially transitioned to such fixed-term offerings as of August 1, 2025.

- changed (2025-12-09):
[0001571996-25-000127:note_history:11]
|  |  |  |  |  | October 31, 2025 |  |  |  |  |  | January 31, 2025 |
|  |  |  |  |  | (in millions) |
| Financing receivables, net: |  |  |  |  |  |  |  |  |  |  |  |
| Customer receivables, gross (a) |  |  |  |  | $ | 13,143 |  |  |  |  |  |  | $ | 11,216 |  |
| Allowance for losses |  |  |  |  | (177) |  |  |  |  |  |  | (153) |  |
| Customer receivables, net |  |  |  |  | 12,966 |  |  |  |  |  |  | 11,063 |  |
| Residual interest |  |  |  |  | 186 |  |  |  |  |  |  | 168 |  |
| Financing receivables, net |  |  |  |  | $ | 13,152 |  |  |  |  |  |  | $ | 11,231 |  |
| Short-term |  |  |  |  | $ | 6,427 |  |  |  |  |  |  | $ | 5,304 |  |
| Long-term |  |  |  |  | $ | 6,725 |  |  |  |  |  |  | $ | 5,927 |  |
  (was, 2025-09-08, similarity 0.9882):
[0001571996-25-000102:note_history:11]
|  |  |  |  |  | August 1, 2025 |  |  |  |  |  | January 31, 2025 |
|  |  |  |  |  | (in millions) |
| Financing receivables, net: |  |  |  |  |  |  |  |  |  |  |  |
| Customer receivables, gross (a) |  |  |  |  | $ | 11,989 |  |  |  |  |  |  | $ | 11,216 |  |
| Allowance for losses |  |  |  |  | (151) |  |  |  |  |  |  | (153) |  |
| Customer receivables, net |  |  |  |  | 11,838 |  |  |  |  |  |  | 11,063 |  |
| Residual interest |  |  |  |  | 185 |  |  |  |  |  |  | 168 |  |
| Financing receivables, net |  |  |  |  | $ | 12,023 |  |  |  |  |  |  | $ | 11,231 |  |
| Short-term |  |  |  |  | $ | 5,952 |  |  |  |  |  |  | $ | 5,304 |  |
| Long-term |  |  |  |  | $ | 6,071 |  |  |  |  |  |  | $ | 5,927 |  |

- changed (2025-12-09):
[0001571996-25-000127:note_history:12]
(a)Customer receivables, gross include amounts due from customers under fixed-term leases, fixed-term loans, and accrued interest, as well as immaterial remaining amounts under the revolving loans.
  (was, 2025-09-08, similarity 0.9899):
[0001571996-25-000102:note_history:12]
(a)Customer receivables, gross include amounts due from customers under fixed-term leases, fixed-term loans, and accrued interest, as well as the immaterial remaining amounts under the revolving loans.

- changed (2025-12-09):
[0001571996-25-000127:note_history:13]
|  | Three Months Ended |  |  |  |  |  | Nine Months Ended |
|  | October 31, 2025 |  | November 1, 2024 |  |  |  |  |  | October 31, 2025 |  |  |  |  |  | November 1, 2024 |  |  |
|  | (in millions) |  |  |  |  |  |  |
| Allowance for financing receivable losses: |
| Balances at beginning of period | $ | 151 |  |  | $ | 166 |  |  |  |  |  |  | $ | 153 |  |  |  |  |  |  | $ | 170 |  |  |  |  |  |  |  |
| Charge-offs, net of recoveries | (7) |  |  | (38) |  |  |  |  |  |  | (21) |  |  |  |  |  |  | (65) |  |  |  |  |  |  |  |
| Provision charged to income statement | 33 |  |  | 16 |  |  |  |  |  |  | 45 |  |  |  |  |  |  | 39 |  |  |  |  |  |  |  |
| Balances at end of period | $ | 177 |  |  | $ | 144 |  |  |  |  |  |  | $ | 177 |  |  |  |  |  |  | $ | 144 |  |  |  |  |  |  |  |
  (was, 2025-09-08, similarity 0.8808):
[0001571996-25-000102:note_history:13]
|  | Three Months Ended |  |  |  |  |  | Six Months Ended |
|  | August 1, 2025 |  | August 2, 2024 |  |  |  |  |  | August 1, 2025 |  |  |  |  |  | August 2, 2024 |  |  |
|  | (in millions) |  |  |  |  |  |  |
| Allowance for financing receivable losses: |
| Balances at beginning of period | $ | 144 |  |  | $ | 195 |  |  |  |  |  |  | $ | 153 |  |  |  |  |  |  | $ | 170 |  |  |  |  |  |  |  |
| Charge-offs, net of recoveries | (4) |  |  | (19) |  |  |  |  |  |  | (14) |  |  |  |  |  |  | (27) |  |  |  |  |  |  |  |
| Provision charged to income statement | 11 |  |  | (10) |  |  |  |  |  |  | 12 |  |  |  |  |  |  | 23 |  |  |  |  |  |  |  |
| Balances at end of period | $ | 151 |  |  | $ | 166 |  |  |  |  |  |  | $ | 151 |  |  |  |  |  |  | $ | 166 |  |  |  |  |  |  |  |

- changed (2025-12-09):
[0001571996-25-000127:note_history:14]
|  | October 31, 2025 |  | January 31, 2025 |
|  | (in millions) |
| Current 0 — 30 Days | $ | 12,802 |  |  | $ | 10,796 |  |
| Past Due 31 — 90 Days | 180 |  |  | 201 |  |
| Past Due > 90 Days | 161 |  |  | 219 |  |
| Total | $ | 13,143 |  |  | $ | 11,216 |  |
  (was, 2025-09-08, similarity 0.9681):
[0001571996-25-000102:note_history:14]
|  | August 1, 2025 |  | January 31, 2025 |
|  | (in millions) |
| Current 0 — 30 Days | $ | 11,355 |  |  | $ | 10,796 |  |
| Past Due 31 — 90 Days | 467 |  |  | 201 |  |
| Past Due > 90 Days | 167 |  |  | 219 |  |
| Total | $ | 11,989 |  |  | $ | 11,216 |  |

- changed (2025-12-09):
[0001571996-25-000127:note_history:15]
|  | October 31, 2025 |
|  | Fiscal Year of Origination |  |  |
|  | 2026 |  | 2025 |  | 2024 |  | 2023 |  | 2022 |  | Years Prior |  | Total |
|  | (in millions) |
| Higher | $ | 2,342 |  |  | $ | 1,832 |  |  | $ | 1,618 |  |  | $ | 679 |  |  | $ | 142 |  |  | $ | 27 |  |  | $ | 6,640 |  |
| Mid | 2,550 |  |  | 1,538 |  |  | 473 |  |  | 249 |  |  | 35 |  |  | 2 |  |  | 4,847 |  |
| Lower | 875 |  |  | 361 |  |  | 248 |  |  | 138 |  |  | 16 |  |  | 18 |  |  | 1,656 |  |
| Total | $ | 5,767 |  |  | $ | 3,731 |  |  | $ | 2,339 |  |  | $ | 1,066 |  |  | $ | 193 |  |  | $ | 47 |  |  | $ | 13,143 |  |
  (was, 2025-09-08, similarity 0.9853):
[0001571996-25-000102:note_history:15]
|  | August 1, 2025 |
|  | Fiscal Year of Origination |  |  |
|  | 2026 |  | 2025 |  | 2024 |  | 2023 |  | 2022 |  | Years Prior |  | Total |
|  | (in millions) |
| Higher | $ | 1,852 |  |  | $ | 1,949 |  |  | $ | 1,786 |  |  | $ | 824 |  |  | $ | 186 |  |  | $ | 38 |  |  | $ | 6,635 |  |
| Mid | 1,227 |  |  | 1,771 |  |  | 529 |  |  | 303 |  |  | 52 |  |  | 5 |  |  | 3,887 |  |
| Lower | 534 |  |  | 416 |  |  | 294 |  |  | 171 |  |  | 33 |  |  | 19 |  |  | 1,467 |  |
| Total | $ | 3,613 |  |  | $ | 4,136 |  |  | $ | 2,609 |  |  | $ | 1,298 |  |  | $ | 271 |  |  | $ | 62 |  |  | $ | 11,989 |  |

- changed (2025-12-09):
[0001571996-25-000127:note_history:16]
The categories shown in the tables above segregate customer receivables, gross, based on the relative degrees of credit risk. Credit quality indicators are updated on a periodic basis. An internal grading system is utilized that assigns a credit level score based on a number of considerations, including liquidity, operating performance, and industry outlook.
  (was, 2025-09-08, similarity 0.9751):
[0001571996-25-000102:note_history:16]
The categories shown in the tables above segregate customer receivables based on the relative degrees of credit risk. Credit quality indicators are generally updated on a periodic basis. An internal grading system is utilized that assigns a credit level score based on a number of considerations, including liquidity, operating performance, and industry outlook.

- changed (2025-12-09):
[0001571996-25-000127:note_history:17]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 31, 2025 |  | November 1, 2024 |  | October 31, 2025 |  | November 1, 2024 |  |  |
|  | (in millions) |
| Interest income — products | $ | 94 |  |  | $ | 82 |  |  | $ | 279 |  |  | $ | 221 |  |  |  |
| Net revenue — products | $ | 222 |  |  | $ | 401 |  |  | $ | 522 |  |  | $ | 1,751 |  |  |  |
| Cost of net revenue — products | 191 |  |  | 333 |  |  | 500 |  |  | 1,488 |  |  |  |
| Gross margin — products | $ | 31 |  |  | $ | 68 |  |  | $ | 22 |  |  | $ | 263 |  |  |  |
  (was, 2025-09-08, similarity 0.8195):
[0001571996-25-000102:note_history:17]
|  | Three Months Ended |  | Six Months Ended |
|  | August 1, 2025 |  | August 2, 2024 |  | August 1, 2025 |  | August 2, 2024 |  |  |
|  | (in millions) |
| Interest income — products | $ | 92 |  |  | $ | 73 |  |  | $ | 185 |  |  | $ | 139 |  |  |  |
| Net revenue — products | $ | 181 |  |  | $ | 622 |  |  | $ | 300 |  |  | $ | 1,350 |  |  |  |
| Cost of net revenue — products | 178 |  |  | 537 |  |  | 309 |  |  | 1,155 |  |  |  |
| Gross margin — products | $ | 3 |  |  | $ | 85 |  |  | $ | (9) |  |  | $ | 195 |  |  |  |

- changed (2025-12-09):
[0001571996-25-000127:note_history:18]
|  | October 31, 2025 |
|  | (in millions) |
| Fiscal 2026 (remaining three months) | $ | 956 |  |
| Fiscal 2027 | 2,832 |  |
| Fiscal 2028 | 1,484 |  |
| Fiscal 2029 | 879 |  |
| Fiscal 2030 and thereafter | 470 |  |
| Total undiscounted cash flows | 6,621 |  |
| Loans | 7,593 |  |
| Less: Unearned income | (1,071) |  |
| Total customer receivables, gross | $ | 13,143 |  |
  (was, 2025-09-08, similarity 0.7298):
[0001571996-25-000102:note_history:18]
|  | August 1, 2025 |
|  | (in millions) |
| Fiscal 2026 (remaining six months) | $ | 672 |  |
| Fiscal 2027 | 1,048 |  |
| Fiscal 2028 | 622 |  |
| Fiscal 2029 | 278 |  |
| Fiscal 2030 and thereafter | 99 |  |
| Total | $ | 2,719 |  |

- changed (2025-12-09):
[0001571996-25-000127:note_history:19]
|  | October 31, 2025 |  | January 31, 2025 |
|  | (in millions) |
| Equipment under operating lease, gross | $ | 4,529 |  |  | $ | 4,180 |  |
| Less: Accumulated depreciation | (2,179) |  |  | (1,995) |  |
| Equipment under operating lease, net | $ | 2,350 |  |  | $ | 2,185 |  |
  (was, 2025-09-08, similarity 0.9722):
[0001571996-25-000102:note_history:19]
|  | August 1, 2025 |  | January 31, 2025 |
|  | (in millions) |
| Equipment under operating lease, gross | $ | 4,492 |  |  | $ | 4,180 |  |
| Less: Accumulated depreciation | (2,178) |  |  | (1,995) |  |
| Equipment under operating lease, net | $ | 2,314 |  |  | $ | 2,185 |  |

- changed (2025-12-09):
[0001571996-25-000127:note_history:20]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 31, 2025 |  | November 1, 2024 |  | October 31, 2025 |  | November 1, 2024 |  |  |
|  | (in millions) |
| Income related to lease payments | $ | 409 |  |  | $ | 372 |  |  | $ | 1,157 |  |  | $ | 1,090 |  |  |  |
| Depreciation expense | $ | 251 |  |  | $ | 247 |  |  | $ | 751 |  |  | $ | 732 |  |  |  |
  (was, 2025-09-08, similarity 0.8061):
[0001571996-25-000102:note_history:20]
|  | Three Months Ended |  | Six Months Ended |
|  | August 1, 2025 |  | August 2, 2024 |  | August 1, 2025 |  | August 2, 2024 |  |  |
|  | (in millions) |
| Income related to lease payments | $ | 390 |  |  | $ | 362 |  |  | $ | 748 |  |  | $ | 718 |  |  |  |
| Depreciation expense | $ | 256 |  |  | $ | 245 |  |  | $ | 500 |  |  | $ | 485 |  |  |  |

- added (2025-12-09):
[0001571996-25-000127:note_history:21]
|  | October 31, 2025 |
|  | (in millions) |
| Fiscal 2026 (remaining three months) | $ | 362 |  |
| Fiscal 2027 | 1,171 |  |
| Fiscal 2028 | 726 |  |
| Fiscal 2029 | 357 |  |
| Fiscal 2030 and thereafter | 137 |  |
| Total | $ | 2,753 |  |

- changed (2025-12-09):
[0001571996-25-000127:note_history:22]
|  | October 31, 2025 |  | January 31, 2025 |
| DFS debt | (in millions) |
| DFS U.S. debt: |  |  |  |
| Asset-based financing facility | $ | 2,508 |  |  | $ | 3,018 |  |
| Fixed-term securitization offerings | 3,252 |  |  | 2,756 |  |
| Total DFS U.S. debt, principal amount | 5,760 |  |  | 5,774 |  |
| DFS international debt: |  |  |  |
| Securitization facility | 667 |  |  | 624 |  |
| Other borrowings | 743 |  |  | 754 |  |
| Dell Bank senior unsecured eurobonds | 1,735 |  |  | 1,559 |  |
| Total DFS international debt, principal amount | 3,145 |  |  | 2,937 |  |
| Total DFS debt, principal amount | $ | 8,905 |  |  | $ | 8,711 |  |
| Total short-term DFS debt | $ | 5,130 |  |  | $ | 5,175 |  |
| Total long-term DFS debt | $ | 3,775 |  |  | $ | 3,536 |  |
  (was, 2025-09-08, similarity 0.9899):
[0001571996-25-000102:note_history:22]
|  | August 1, 2025 |  | January 31, 2025 |
| DFS debt | (in millions) |
| DFS U.S. debt: |  |  |  |
| Asset-based financing facility | $ | 3,001 |  |  | $ | 3,018 |  |
| Fixed-term securitization offerings | 2,685 |  |  | 2,756 |  |
| Total DFS U.S. debt, principal amount | 5,686 |  |  | 5,774 |  |
| DFS international debt: |  |  |  |
| Securitization facility | 657 |  |  | 624 |  |
| Other borrowings | 760 |  |  | 754 |  |
| Dell Bank senior unsecured eurobonds | 1,712 |  |  | 1,559 |  |
| Total DFS international debt, principal amount | 3,129 |  |  | 2,937 |  |
| Total DFS debt, principal amount | $ | 8,815 |  |  | $ | 8,711 |  |
| Total short-term DFS debt | $ | 4,624 |  |  | $ | 5,175 |  |
| Total long-term DFS debt | $ | 4,191 |  |  | $ | 3,536 |  |

- changed (2025-12-09):
[0001571996-25-000127:note_history:23]
Asset-Based Financing Facility — The Company maintains an asset-based financing facility in the United States, which is a revolving facility for fixed-term leases and loans. This debt is collateralized solely by the U.S. lease and loan payments and associated equipment in the facility. The asset-based financing facility consists of two tranches, with effective dates through July 7, 2026 and July 7, 2027, respectively. As of October 31, 2025, the total debt capacity related to the asset-based financing facility was $4.6 billion. The debt has a variable interest rate, and the duration of the debt is based on the terms of the underlying lease and loan payment streams. The Company enters into interest rate swap agreements to economically convert a portion of this debt from a floating rate to a fixed rate. See Note 7 of the Notes to the Condensed Consolidated Financial Statements for additional information about the Company’s interest rate swaps.
  (was, 2025-09-08, similarity 0.9931):
[0001571996-25-000102:note_history:23]
Asset-Based Financing Facility — The Company maintains an asset-based financing facility in the United States, which is a revolving facility for fixed-term leases and loans. This debt is collateralized solely by the U.S. lease and loan payments and associated equipment in the facility. The asset-based financing facility consists of two tranches, with effective dates through July 7, 2026 and July 7, 2027, respectively. As of August 1, 2025, the total debt capacity related to the asset-based financing facility was $4.6 billion. The debt has a variable interest rate, and the duration of the debt is based on the terms of the underlying lease and loan payment streams. The Company enters into interest rate swap agreements to economically convert a portion of this debt from a floating rate to a fixed rate. See Note 7 of the Notes to the Condensed Consolidated Financial Statements for additional information about the Company’s interest rate swaps.

- changed (2025-12-09):
[0001571996-25-000127:note_history:24]
The asset-based financing facility contains standard structural features related to the performance of the funded receivables, which include defined credit losses, delinquencies, average credit scores, and minimum collection requirements. In the event one or more of these criteria are not met and the Company is unable to restructure the facility, no further funding of receivables will be permitted and the timing of the Company’s expected cash flows from over-collateralization will be delayed. As of October 31, 2025, these criteria were met.
  (was, 2025-09-08, similarity 0.988):
[0001571996-25-000102:note_history:24]
The asset-based financing facility contains standard structural features related to the performance of the funded receivables, which include defined credit losses, delinquencies, average credit scores, and minimum collection requirements. In the event one or more of these criteria are not met and the Company is unable to restructure the facility, no further funding of receivables will be permitted and the timing of the Company’s expected cash flows from over-collateralization will be delayed. As of August 1, 2025, these criteria were met.

- changed (2025-12-09):
[0001571996-25-000127:note_history:25]
Fixed-Term Securitization Offerings — The Company periodically issues asset-backed debt securities under fixed-term securitization programs to private investors. The asset-backed debt securities are collateralized solely by the U.S. fixed-term lease and loan payments and associated equipment, which are held by Special Purpose Entities (“SPEs”), as discussed below. The interest rate on these securities is fixed and ranges from 4.10% to 6.80% per annum as of October 31, 2025, and the duration of these securities is based on the terms of the underlying lease and loan payment streams.
  (was, 2025-09-08, similarity 0.9887):
[0001571996-25-000102:note_history:25]
Fixed-Term Securitization Offerings — The Company periodically issues asset-backed debt securities under fixed-term securitization programs to private investors. The asset-backed debt securities are collateralized solely by the U.S. fixed-term lease and loan payments and associated equipment, which are held by Special Purpose Entities (“SPEs”), as discussed below. The interest rate on these securities is fixed and ranges from 4.59% to 6.80% per annum as of August 1, 2025, and the duration of these securities is based on the terms of the underlying lease and loan payment streams.

- changed (2025-12-09):
[0001571996-25-000127:note_history:26]
Securitization Facility — The Company maintains a securitization facility in Europe for fixed-term leases and loans. The debt under this facility has a variable interest rate, and the duration of the debt is based on the terms of the underlying lease and loan payment streams. This facility is effective through December 22, 2026 and had a total debt capacity of $925 million as of October 31, 2025.
  (was, 2025-09-08, similarity 0.9728):
[0001571996-25-000102:note_history:26]
Securitization Facility — The Company maintains a securitization facility in Europe for fixed-term leases and loans. The debt under this facility has a variable interest rate, and the duration of the debt is based on the terms of the underlying lease and loan payment streams. This facility is effective through December 22, 2026 and had a total debt capacity of $913 million as of August 1, 2025.

- changed (2025-12-09):
[0001571996-25-000127:note_history:27]
The securitization facility contains standard structural features related to the performance of the securitized receivables, which include defined credit losses, delinquencies, average credit scores, and minimum collection requirements. In the event one or more of these criteria are not met and the Company is unable to restructure the program, no further funding of receivables will be permitted and the timing of the Company’s expected cash flows from over-collateralization will be delayed. As of October 31, 2025, these criteria were met.
  (was, 2025-09-08, similarity 0.9879):
[0001571996-25-000102:note_history:27]
The securitization facility contains standard structural features related to the performance of the securitized receivables, which include defined credit losses, delinquencies, average credit scores, and minimum collection requirements. In the event one or more of these criteria are not met and the Company is unable to restructure the program, no further funding of receivables will be permitted and the timing of the Company’s expected cash flows from over-collateralization will be delayed. As of August 1, 2025, these criteria were met.

- added (2025-12-09):
[0001571996-25-000127:note_history:28]
The duration of the debt in Canada, Europe, Australia and New Zealand, and the Middle East is based on the terms of the underlying lease and loan payment streams. These facilities are collateralized solely by the lease and loan payments and associated equipment in their respective region or country. The Canadian facility had a total debt capacity of $250 million as of October 31, 2025 and is effective through January 15, 2028. The European facility had a total debt capacity of $463 million as of October 31, 2025 and is effective through December 14, 2026. The Australia and New Zealand facility had a total debt capacity of $279 million as of October 31, 2025 and is effective through April 17, 2027. The Middle East facility had a total debt capacity of $150 million as of October 31, 2025 and is effective through March 14, 2027.

- changed (2025-12-09):
[0001571996-25-000127:note_history:29]
The Company also has two unsecured Singapore facilities, which had a total debt capacity of $254 million as of October 31, 2025 and are effective through July 3, 2026 and July 3, 2027, respectively.
  (was, 2025-09-08, similarity 0.9697):
[0001571996-25-000102:note_history:29]
The Company also has two unsecured Singapore facilities, which had a total debt capacity of $254 million as of August 1, 2025 and are effective through July 3, 2026 and July 3, 2027, respectively.

- changed (2025-12-09):
[0001571996-25-000127:note_history:30]
Dell Bank Senior Unsecured Eurobonds — On October 27, 2021, Dell Bank issued 500 million Euro of 0.5% senior unsecured five-year eurobonds due October 2026. On October 18, 2022, Dell Bank issued 500 million Euro of 4.5% senior unsecured five-year eurobonds due October 2027. On June 13, 2024, Dell Bank issued 500 million Euro of 3.6% senior unsecured five-year eurobonds due June 2029. The issuances of the senior unsecured eurobonds support the expansion of the financing operations in Europe.
  (was, 2025-09-08, similarity 0.9934):
[0001571996-25-000102:note_history:30]
Dell Bank Senior Unsecured Eurobonds — On October 27, 2021, Dell Bank issued 500 million Euro of 0.5% senior unsecured five year eurobonds due October 2026. On October 18, 2022, Dell Bank issued 500 million Euro of 4.5% senior unsecured five year eurobonds due October 2027. On June 13, 2024, Dell Bank issued 500 million Euro of 3.6% senior unsecured five year eurobonds due June 2029. The issuances of the senior unsecured eurobonds support the expansion of the financing operations in Europe.

- changed (2025-12-09):
[0001571996-25-000127:note_history:31]
|  | October 31, 2025 |  | January 31, 2025 |
|  | (in millions) |
| Assets held by consolidated VIEs |  |  |  |
| Other current assets | $ | 164 |  |  | $ | 123 |  |
| Financing receivables, net of allowance |  |  |  |
| Short-term | $ | 3,292 |  |  | $ | 3,262 |  |
| Long-term | $ | 2,726 |  |  | $ | 2,725 |  |
| Property, plant, and equipment, net | $ | 974 |  |  | $ | 984 |  |
| Liabilities held by consolidated VIEs |  |  |  |
| Debt, net of unamortized debt issuance costs |  |  |  |
| Short-term | $ | 4,069 |  |  | $ | 4,598 |  |
| Long-term | $ | 2,343 |  |  | $ | 1,788 |  |
  (was, 2025-09-08, similarity 0.9871):
[0001571996-25-000102:note_history:31]
|  | August 1, 2025 |  | January 31, 2025 |
|  | (in millions) |
| Assets held by consolidated VIEs |  |  |  |
| Other current assets | $ | 147 |  |  | $ | 123 |  |
| Financing receivables, net of allowance |  |  |  |
| Short-term | $ | 3,194 |  |  | $ | 3,262 |  |
| Long-term | $ | 2,738 |  |  | $ | 2,725 |  |
| Property, plant, and equipment, net | $ | 971 |  |  | $ | 984 |  |
| Liabilities held by consolidated VIEs |  |  |  |
| Debt, net of unamortized debt issuance costs |  |  |  |
| Short-term | $ | 4,129 |  |  | $ | 4,598 |  |
| Long-term | $ | 2,201 |  |  | $ | 1,788 |  |

- added (2025-12-09):
[0001571996-25-000127:note_history:32]
Lease and loan payments and associated equipment transferred via securitization through SPEs were $1.0 billion for both the three months ended October 31, 2025 and November 1, 2024, and $3.0 billion for both the nine months ended October 31, 2025 and November 1, 2024.

- changed (2025-12-09):
[0001571996-25-000127:note_history:33]
To manage certain concentrations of customer credit exposure, the Company may sell selected fixed-term customer receivables to unrelated third parties on a periodic basis, without recourse. The amounts of customer receivables sold for this purpose were immaterial for both the nine months ended October 31, 2025 and November 1, 2024. The Company’s continuing involvement in these customer receivables is primarily limited to servicing arrangements.
  (was, 2025-09-08, similarity 0.9289):
[0001571996-25-000102:note_history:33]
To manage certain concentrations of customer credit exposure, the Company may sell selected fixed-term customer receivables to unrelated third parties on a periodic basis, without recourse. The amounts of customer receivables sold for this purpose were immaterial for both the six months ended August 1, 2025 and August 2, 2024. The Company’s continuing involvement in these customer receivables is primarily limited to servicing arrangements.

- removed (2025-12-09):
[0001571996-25-000102:note_history:34]
Loans — The Company also offers fixed-term loans to qualified small businesses, large commercial accounts, governmental organizations, educational entities, and certain individual consumer customers. These loans are repaid in equal payments including interest and have defined terms of generally three to five years. The fair value of the fixed-term loan portfolio is determined using market observable inputs. The carrying value of these loans approximates fair value.

- removed (2025-12-09):
[0001571996-25-000102:note_history:35]
|  | August 1, 2025 |
|  | (in millions) |
| Fiscal 2026 (remaining six months) | $ | 1,702 |  |
| Fiscal 2027 | 2,665 |  |
| Fiscal 2028 | 1,308 |  |
| Fiscal 2029 | 700 |  |
| Fiscal 2030 and thereafter | 347 |  |
| Total undiscounted cash flows | 6,722 |  |
| Loans | 6,288 |  |
| Less: Unearned income | (1,021) |  |
| Total customer receivables, gross | $ | 11,989 |  |

- removed (2025-12-09):
[0001571996-25-000102:note_history:36]
The duration of the debt in Canada, Europe, Australia and New Zealand, and the Middle East is based on the terms of the underlying lease and loan payment streams. These facilities are collateralized solely by the lease and loan payments and associated equipment in their respective region or country. The Canadian facility had a total debt capacity of $253 million as of August 1, 2025 and is effective through January 15, 2028. The European facility had a total debt capacity of $457 million as of August 1, 2025 and is effective through December 14, 2026. The Australia and New Zealand facility had a total debt capacity of $273 million as of August 1, 2025 and is effective through April 17, 2027. The Middle East facility had a total debt capacity of $150 million as of August 1, 2025 and is effective through March 14, 2027.

- removed (2025-12-09):
[0001571996-25-000102:note_history:37]
Lease and loan payments and associated equipment transferred via securitization through SPEs were $0.8 billion and $1.2 billion for the three months ended August 1, 2025 and August 2, 2024, respectively, and $2.0 billion for both the six months ended August 1, 2025 and August 2, 2024.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-12-09):
[0001571996-25-000127:note_history:38]
|  | October 31, 2025 |  | January 31, 2025 |
|  | (in millions) |
| Senior Notes | $ | 21,573 |  |  | $ | 15,073 |  |
| Legacy Notes | 952 |  |  | 952 |  |
| DFS Debt (Note 4) | 8,905 |  |  | 8,711 |  |
| Other | 85 |  |  | 52 |  |
| Total debt, principal amount | 31,515 |  |  | 24,788 |  |
| Unamortized discount, net of unamortized premium | (115) |  |  | (110) |  |
| Debt issuance costs | (157) |  |  | (111) |  |
| Total debt, carrying value | $ | 31,243 |  |  | $ | 24,567 |  |
| Total short-term debt, carrying value | $ | 7,394 |  |  | $ | 5,204 |  |
| Total long-term debt, carrying value | $ | 23,849 |  |  | $ | 19,363 |  |
  (was, 2025-09-08, similarity 0.9876):
[0001571996-25-000102:note_history:38]
|  | August 1, 2025 |  | January 31, 2025 |
|  | (in millions) |
| Senior Notes | $ | 19,073 |  |  | $ | 15,073 |  |
| Legacy Notes | 952 |  |  | 952 |  |
| DFS Debt (Note 4) | 8,815 |  |  | 8,711 |  |
| Other | 89 |  |  | 52 |  |
| Total debt, principal amount | 28,929 |  |  | 24,788 |  |
| Unamortized discount, net of unamortized premium | (110) |  |  | (110) |  |
| Debt issuance costs | (130) |  |  | (111) |  |
| Total debt, carrying value | $ | 28,689 |  |  | $ | 24,567 |  |
| Total short-term debt, carrying value | $ | 7,154 |  |  | $ | 5,204 |  |
| Total long-term debt, carrying value | $ | 21,535 |  |  | $ | 19,363 |  |

- added (2025-12-09):
[0001571996-25-000127:note_history:39]
The Company completed the following transactions during the nine months ended October 31, 2025:

- changed (2025-12-09):
[0001571996-25-000127:note_history:40]
•the issuance of $1.0 billion principal amount of 4.75% Senior Notes due April 2028, $1.0 billion principal amount of 5.00% Senior Notes due April 2030, $1.0 billion principal amount of 5.30% Senior Notes due April 2032, and $1.0 billion principal amount of 5.50% Senior Notes due April 2035, the proceeds of which were utilized for general corporate purposes; and
  (was, 2025-09-08, similarity 0.8006):
[0001571996-25-000102:note_history:40]
During the six months ended August 1, 2025, the Company issued $1.0 billion principal amount of 4.75% Senior Notes due April 2028, $1.0 billion principal amount of 5.00% Senior Notes due April 2030, $1.0 billion principal amount of 5.30% Senior Notes due April 2032, and $1.0 billion principal amount of 5.50% Senior Notes due April 2035. The Company utilized the net proceeds of the issuances for general corporate purposes.

- added (2025-12-09):
[0001571996-25-000127:note_history:41]
•the issuance of $0.75 billion principal amount of 4.15% Senior Notes due February 2029, $1.25 billion principal amount of 4.50% Senior Notes due February 2031, $1.25 billion principal amount of 4.75% Senior Notes due October 2032, and $1.25 billion principal amount of 5.10% Senior Notes due February 2036, the proceeds of which were utilized for general corporate purposes and to prepay a portion of the outstanding 6.02% Senior Notes due June 2026.

- changed (2025-12-09):
[0001571996-25-000127:note_history:42]
Senior Notes — The Company completed offerings of multiple series of senior notes which were issued on June 1, 2016, June 22, 2016, March 20, 2019, April 9, 2020, December 13, 2021, January 24, 2023, March 18, 2024, October 8, 2024, April 1, 2025, and October 6, 2025 in aggregate principal amounts of $20.0 billion, $3.3 billion, $4.5 billion, $2.3 billion, $2.3 billion, $2.0 billion, $1.0 billion, $1.5 billion, $4.0 billion, and $4.5 billion, respectively (collectively, the “Senior Notes”). The Senior Notes currently outstanding have maturity dates ranging from 2026 through 2051. Interest rates on these borrowings are fixed, ranging from 3.38% to 8.35% per annum, and interest is payable semiannually.
  (was, 2025-09-08, similarity 0.9048):
[0001571996-25-000102:note_history:42]
Senior Notes — The Company completed offerings of multiple series of senior notes which were issued on June 1, 2016, June 22, 2016, March 20, 2019, April 9, 2020, December 13, 2021, January 24, 2023, March 18, 2024, October 8, 2024, and April 1, 2025 in aggregate principal amounts of $20.0 billion, $3.3 billion, $4.5 billion, $2.3 billion, $2.3 billion, $2.0 billion, $1.0 billion, $1.5 billion, and $4.0 billion, respectively (collectively, the “Senior Notes”). The Senior Notes currently outstanding have maturity dates ranging from 2026 through 2051. Interest rates on these borrowings are fixed, ranging from 3.38% to 8.35% per annum, and interest is payable semiannually.

- changed (2025-12-09):
[0001571996-25-000127:note_history:43]
As of October 31, 2025, the Company had no outstanding borrowings under the revolving credit facility.
  (was, 2025-09-08, similarity 0.9424):
[0001571996-25-000102:note_history:43]
As of August 1, 2025, the Company had no outstanding borrowings under the revolving credit facility.

- changed (2025-12-09):
[0001571996-25-000127:note_history:44]
Commercial Paper Program — The Company maintains a commercial paper program under which the Company may issue unsecured notes in a maximum aggregate face amount of $5.0 billion outstanding at any time, with maturities of up to 397 days from the date of issuance. The notes are sold on customary terms in the U.S. commercial paper market on a private placement basis. The proceeds of the notes are used for general corporate purposes. As of October 31, 2025, the Company had no outstanding issuances under the commercial paper program.
  (was, 2025-09-08, similarity 0.9876):
[0001571996-25-000102:note_history:44]
Commercial Paper Program — The Company maintains a commercial paper program under which the Company may issue unsecured notes in a maximum aggregate face amount of $5.0 billion outstanding at any time, with maturities of up to 397 days from the date of issuance. The notes are sold on customary terms in the U.S. commercial paper market on a private placement basis. The proceeds of the notes are used for general corporate purposes. As of August 1, 2025, the Company had no outstanding issuances under the commercial paper program.

- changed (2025-12-09):
[0001571996-25-000127:note_history:45]
Covenants — The credit agreement governing the revolving credit facility and the indentures governing the Senior Notes and the Legacy Notes impose various limitations, subject to exceptions, on creating certain liens and entering into sale and lease-back transactions. The foregoing credit agreement and indentures contain customary events of default, and the revolving credit facility is subject to an interest coverage ratio covenant that is tested at the end of each fiscal quarter with respect to the Company’s preceding four fiscal quarters. The Company was in compliance with this financial covenant as of October 31, 2025.
  (was, 2025-09-08, similarity 0.9896):
[0001571996-25-000102:note_history:45]
Covenants — The credit agreement governing the revolving credit facility and the indentures governing the Senior Notes and the Legacy Notes impose various limitations, subject to exceptions, on creating certain liens and entering into sale and lease-back transactions. The foregoing credit agreement and indentures contain customary events of default, and the revolving credit facility is subject to an interest coverage ratio covenant that is tested at the end of each fiscal quarter with respect to the Company’s preceding four fiscal quarters. The Company was in compliance with this financial covenant as of August 1, 2025.

- changed (2025-12-09):
[0001571996-25-000127:note_history:46]
The following table presents the aggregate future maturities of the Company’s debt as of October 31, 2025, excluding associated carrying value adjustments, for the periods indicated:
  (was, 2025-09-08, similarity 0.9687):
[0001571996-25-000102:note_history:46]
The following table presents the aggregate future maturities of the Company’s debt as of August 1, 2025, excluding associated carrying value adjustments, for the periods indicated:

- added (2025-12-09):
[0001571996-25-000127:note_history:47]
|  | October 31, 2025 |
|  | (in millions) |
| Fiscal 2026 (remaining three months) | $ | 1,307 |  |
| Fiscal 2027 | 6,819 |  |
| Fiscal 2028 | 2,621 |  |
| Fiscal 2029 | 2,613 |  |
| Fiscal 2030 | 3,855 |  |
| Thereafter | 14,300 |  |
| Total maturities, principal amount | $ | 31,515 |  |

- removed (2025-12-09):
[0001571996-25-000102:note_history:48]
|  | August 1, 2025 |
|  | (in millions) |
| Fiscal 2026 (remaining six months) | $ | 2,080 |  |
| Fiscal 2027 | 8,451 |  |
| Fiscal 2028 | 2,343 |  |
| Fiscal 2029 | 2,460 |  |
| Fiscal 2030 | 3,059 |  |
| Thereafter | 10,536 |  |
| Total maturities, principal amount | $ | 28,929 |  |


## us-gaap:ScheduleOfCarryingValuesAndEstimatedFairValuesOfDebtInstrumentsTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-12-09):
[0001571996-25-000127:note_history:49]
|  | October 31, 2025 |  | January 31, 2025 |
|  | Carrying Value |  | Fair Value |  | Carrying Value |  | Fair Value |
|  | (in billions) |
| Senior Notes | $ | 21.4 |  |  | $ | 21.9 |  |  | $ | 15.0 |  |  | $ | 15.0 |  |
| Legacy Notes | $ | 0.9 |  |  | $ | 1.0 |  |  | $ | 0.9 |  |  | $ | 1.0 |  |
| DFS Debt | $ | 8.9 |  |  | $ | 8.6 |  |  | $ | 8.7 |  |  | $ | 8.5 |  |
  (was, 2025-09-08, similarity 0.9821):
[0001571996-25-000102:note_history:49]
|  | August 1, 2025 |  | January 31, 2025 |
|  | Carrying Value |  | Fair Value |  | Carrying Value |  | Fair Value |
|  | (in billions) |
| Senior Notes | $ | 18.9 |  |  | $ | 19.3 |  |  | $ | 15.0 |  |  | $ | 15.0 |  |
| Legacy Notes | $ | 0.9 |  |  | $ | 1.0 |  |  | $ | 0.9 |  |  | $ | 1.0 |  |
| DFS Debt | $ | 8.8 |  |  | $ | 8.5 |  |  | $ | 8.7 |  |  | $ | 8.5 |  |


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-12-09):
[0001571996-25-000127:note_history:50]
|  | October 31, 2025 |  | January 31, 2025 |
| DFS debt | (in millions) |
| DFS U.S. debt: |  |  |  |
| Asset-based financing facility | $ | 2,508 |  |  | $ | 3,018 |  |
| Fixed-term securitization offerings | 3,252 |  |  | 2,756 |  |
| Total DFS U.S. debt, principal amount | 5,760 |  |  | 5,774 |  |
| DFS international debt: |  |  |  |
| Securitization facility | 667 |  |  | 624 |  |
| Other borrowings | 743 |  |  | 754 |  |
| Dell Bank senior unsecured eurobonds | 1,735 |  |  | 1,559 |  |
| Total DFS international debt, principal amount | 3,145 |  |  | 2,937 |  |
| Total DFS debt, principal amount | $ | 8,905 |  |  | $ | 8,711 |  |
| Total short-term DFS debt | $ | 5,130 |  |  | $ | 5,175 |  |
| Total long-term DFS debt | $ | 3,775 |  |  | $ | 3,536 |  |
  (was, 2025-09-08, similarity 0.9899):
[0001571996-25-000102:note_history:50]
|  | August 1, 2025 |  | January 31, 2025 |
| DFS debt | (in millions) |
| DFS U.S. debt: |  |  |  |
| Asset-based financing facility | $ | 3,001 |  |  | $ | 3,018 |  |
| Fixed-term securitization offerings | 2,685 |  |  | 2,756 |  |
| Total DFS U.S. debt, principal amount | 5,686 |  |  | 5,774 |  |
| DFS international debt: |  |  |  |
| Securitization facility | 657 |  |  | 624 |  |
| Other borrowings | 760 |  |  | 754 |  |
| Dell Bank senior unsecured eurobonds | 1,712 |  |  | 1,559 |  |
| Total DFS international debt, principal amount | 3,129 |  |  | 2,937 |  |
| Total DFS debt, principal amount | $ | 8,815 |  |  | $ | 8,711 |  |
| Total short-term DFS debt | $ | 4,624 |  |  | $ | 5,175 |  |
| Total long-term DFS debt | $ | 4,191 |  |  | $ | 3,536 |  |

- changed (2025-12-09):
[0001571996-25-000127:note_history:51]
|  | October 31, 2025 |  | January 31, 2025 |
|  | (in millions) |
| Senior Notes | $ | 21,573 |  |  | $ | 15,073 |  |
| Legacy Notes | 952 |  |  | 952 |  |
| DFS Debt (Note 4) | 8,905 |  |  | 8,711 |  |
| Other | 85 |  |  | 52 |  |
| Total debt, principal amount | 31,515 |  |  | 24,788 |  |
| Unamortized discount, net of unamortized premium | (115) |  |  | (110) |  |
| Debt issuance costs | (157) |  |  | (111) |  |
| Total debt, carrying value | $ | 31,243 |  |  | $ | 24,567 |  |
| Total short-term debt, carrying value | $ | 7,394 |  |  | $ | 5,204 |  |
| Total long-term debt, carrying value | $ | 23,849 |  |  | $ | 19,363 |  |
  (was, 2025-09-08, similarity 0.9876):
[0001571996-25-000102:note_history:51]
|  | August 1, 2025 |  | January 31, 2025 |
|  | (in millions) |
| Senior Notes | $ | 19,073 |  |  | $ | 15,073 |  |
| Legacy Notes | 952 |  |  | 952 |  |
| DFS Debt (Note 4) | 8,815 |  |  | 8,711 |  |
| Other | 89 |  |  | 52 |  |
| Total debt, principal amount | 28,929 |  |  | 24,788 |  |
| Unamortized discount, net of unamortized premium | (110) |  |  | (110) |  |
| Debt issuance costs | (130) |  |  | (111) |  |
| Total debt, carrying value | $ | 28,689 |  |  | $ | 24,567 |  |
| Total short-term debt, carrying value | $ | 7,154 |  |  | $ | 5,204 |  |
| Total long-term debt, carrying value | $ | 21,535 |  |  | $ | 19,363 |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-12-09):
[0001571996-25-000127:note_history:52]
The following table presents the aggregate future maturities of the Company’s debt as of October 31, 2025, excluding associated carrying value adjustments, for the periods indicated:
  (was, 2025-09-08, similarity 0.9687):
[0001571996-25-000102:note_history:52]
The following table presents the aggregate future maturities of the Company’s debt as of August 1, 2025, excluding associated carrying value adjustments, for the periods indicated:

- added (2025-12-09):
[0001571996-25-000127:note_history:53]
|  | October 31, 2025 |
|  | (in millions) |
| Fiscal 2026 (remaining three months) | $ | 1,307 |  |
| Fiscal 2027 | 6,819 |  |
| Fiscal 2028 | 2,621 |  |
| Fiscal 2029 | 2,613 |  |
| Fiscal 2030 | 3,855 |  |
| Thereafter | 14,300 |  |
| Total maturities, principal amount | $ | 31,515 |  |

- removed (2025-12-09):
[0001571996-25-000102:note_history:54]
|  | August 1, 2025 |
|  | (in millions) |
| Fiscal 2026 (remaining six months) | $ | 2,080 |  |
| Fiscal 2027 | 8,451 |  |
| Fiscal 2028 | 2,343 |  |
| Fiscal 2029 | 2,460 |  |
| Fiscal 2030 | 3,059 |  |
| Thereafter | 10,536 |  |
| Total maturities, principal amount | $ | 28,929 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2025-12-09):
[0001571996-25-000127:note_history:55]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 31, 2025 |  | November 1, 2024 |  | October 31, 2025 |  | November 1, 2024 |  |  |
|  | (in millions) |
| Net revenue: |  |  |  |  |  |  |  |  |  |
| Infrastructure Solutions Group: |  |  |  |  |  |  |  |  |  |
| Servers and networking | $ | 10,125 |  |  | $ | 7,364 |  |  | $ | 29,390 |  |  | $ | 20,502 |  |  |  |
| Storage | 3,982 |  |  | 4,004 |  |  | 11,834 |  |  | 11,739 |  |  |  |
| Total ISG net revenue | $ | 14,107 |  |  | $ | 11,368 |  |  | $ | 41,224 |  |  | $ | 32,241 |  |  |  |
| Client Solutions Group: |  |  |  |  |  |  |  |  |  |
| Commercial | $ | 10,621 |  |  | $ | 10,138 |  |  | $ | 32,448 |  |  | $ | 30,848 |  |  |  |
| Consumer | 1,857 |  |  | 1,993 |  |  | 5,042 |  |  | 5,664 |  |  |  |
| Total CSG net revenue | $ | 12,478 |  |  | $ | 12,131 |  |  | $ | 37,490 |  |  | $ | 36,512 |  |  |  |
  (was, 2025-09-08, similarity 0.9124):
[0001571996-25-000102:note_history:55]
|  | Three Months Ended |  | Six Months Ended |
|  | August 1, 2025 |  | August 2, 2024 |  | August 1, 2025 |  | August 2, 2024 |  |  |
|  | (in millions) |
| Net revenue: |  |  |  |  |  |  |  |  |  |
| Infrastructure Solutions Group: |  |  |  |  |  |  |  |  |  |
| Servers and networking | $ | 12,944 |  |  | $ | 7,672 |  |  | $ | 19,265 |  |  | $ | 13,138 |  |  |  |
| Storage | 3,856 |  |  | 3,974 |  |  | 7,852 |  |  | 7,735 |  |  |  |
| Total ISG net revenue | $ | 16,800 |  |  | $ | 11,646 |  |  | $ | 27,117 |  |  | $ | 20,873 |  |  |  |
| Client Solutions Group: |  |  |  |  |  |  |  |  |  |
| Commercial | $ | 10,781 |  |  | $ | 10,556 |  |  | $ | 21,827 |  |  | $ | 20,710 |  |  |  |
| Consumer | 1,722 |  |  | 1,858 |  |  | 3,185 |  |  | 3,671 |  |  |  |
| Total CSG net revenue | $ | 12,503 |  |  | $ | 12,414 |  |  | $ | 25,012 |  |  | $ | 24,381 |  |  |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2025-12-09):
[0001571996-25-000127:note_history:56]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 31, 2025 |  | November 1, 2024 |  | October 31, 2025 |  | November 1, 2024 |
|  | (in millions) |
| Deferred revenue: |  |  |  |  |  |  |  |
| Deferred revenue at beginning of period | $ | 26,181 |  |  | $ | 27,712 |  |  | $ | 25,965 |  |  | $ | 29,145 |  |
| Revenue deferrals | 3,944 |  |  | 3,897 |  |  | 14,371 |  |  | 13,286 |  |
| Revenue recognized | (5,017) |  |  | (5,262) |  |  | (15,228) |  |  | (16,084) |  |
| Other (a) | — |  |  | (136) |  |  | — |  |  | (136) |  |
| Deferred revenue at end of period | $ | 25,108 |  |  | $ | 26,211 |  |  | $ | 25,108 |  |  | $ | 26,211 |  |
| Short-term deferred revenue | $ | 12,649 |  |  | $ | 13,787 |  |  | $ | 12,649 |  |  | $ | 13,787 |  |
| Long-term deferred revenue | $ | 12,459 |  |  | $ | 12,424 |  |  | $ | 12,459 |  |  | $ | 12,424 |  |
  (was, 2025-09-08, similarity 0.6387):
[0001571996-25-000102:note_history:56]
|  | Three Months Ended |  | Six Months Ended |
|  | August 1, 2025 |  | August 2, 2024 |  | August 1, 2025 |  | August 2, 2024 |
|  | (in millions) |
| Deferred revenue: |  |  |  |  |  |  |  |
| Deferred revenue at beginning of period | $ | 26,320 |  |  | $ | 28,150 |  |  | $ | 25,965 |  |  | $ | 29,145 |  |
| Revenue deferrals | 4,972 |  |  | 4,920 |  |  | 10,427 |  |  | 9,389 |  |
| Revenue recognized | (5,111) |  |  | (5,358) |  |  | (10,211) |  |  | (10,822) |  |
| Deferred revenue at end of period | $ | 26,181 |  |  | $ | 27,712 |  |  | $ | 26,181 |  |  | $ | 27,712 |  |
| Short-term deferred revenue | $ | 13,759 |  |  | $ | 14,853 |  |  | $ | 13,759 |  |  | $ | 14,853 |  |
| Long-term deferred revenue | $ | 12,422 |  |  | $ | 12,859 |  |  | $ | 12,422 |  |  | $ | 12,859 |  |

- added (2025-12-09):
[0001571996-25-000127:note_history:57]
____________________

- added (2025-12-09):
[0001571996-25-000127:note_history:58]
(a) For the three and nine months ended November 1, 2024, Other represents the reclassification of Secureworks deferred revenue to liabilities held for sale. See Note 1 of the Notes to the Condensed Consolidated Financial Statements for more information about the sale of Secureworks

- changed (2025-12-09):
[0001571996-25-000127:note_history:59]
Remaining Performance Obligations — Remaining performance obligations represent the aggregate amount of the transaction price allocated to performance obligations not delivered, or partially undelivered, as of the end of the reporting period. Remaining performance obligations include deferred revenue plus unbilled amounts not yet recorded in deferred revenue. The value of the transaction price allocated to remaining performance obligations as of October 31, 2025 was approximately $51 billion. The Company expects to recognize approximately 67% of remaining performance obligations as revenue in the next twelve months, 16% in the following twelve months, and the remainder thereafter.
  (was, 2025-09-08, similarity 0.9904):
[0001571996-25-000102:note_history:59]
Remaining Performance Obligations — Remaining performance obligations represent the aggregate amount of the transaction price allocated to performance obligations not delivered, or partially undelivered, as of the end of the reporting period. Remaining performance obligations include deferred revenue plus unbilled amounts not yet recorded in deferred revenue. The value of the transaction price allocated to remaining performance obligations as of August 1, 2025 was approximately $44 billion. The Company expects to recognize approximately 65% of remaining performance obligations as revenue in the next twelve months, 17% in the following twelve months, and the remainder thereafter.

- changed (2025-12-09):
[0001571996-25-000127:note_history:60]
Remaining performance obligation estimates are subject to change and are affected by multiple factors, including terminations, changes in the scope of contracts, periodic revalidation, adjustments for revenue that have not materialized, and adjustments for currency.
  (was, 2025-09-08, similarity 0.9718):
[0001571996-25-000102:note_history:60]
Remaining performance obligation estimates are subject to change and are affected by several factors, including terminations, changes in the scope of contracts, periodic revalidation, adjustments for revenue that have not materialized, and adjustments for currency.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- changed (2025-12-09):
[0001571996-25-000127:note_history:61]
SUBSEQUENT EVENTS 
There were no known events occurring after October 31, 2025 and up until the date of issuance of this report that would materially affect the information presented herein.
  (was, 2025-09-08, similarity 0.97):
[0001571996-25-000102:note_history:61]
SUBSEQUENT EVENTS 
There were no known events occurring after August 1, 2025 and up until the date of issuance of this report that would materially affect the information presented herein.
