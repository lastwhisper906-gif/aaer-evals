# DELL 8-K — 0001571996-25-000014 filed 2025-02-27

## item codes, every 8-K on or before 2025-03-25

- 2025-02-27 0001571996-25-000014 — 2.02, 8.01, 9.01
- 2025-01-14 0001571996-25-000004 — 3.02
- 2024-12-03 0001571996-24-000136 — 3.02
- 2024-11-26 0001571996-24-000130 — 2.02, 9.01
- 2024-10-08 0001193125-24-234446 — 1.01, 2.03, 9.01
- 2024-10-02 0001193125-24-231195 — 8.01, 9.01
- 2024-09-19 0001571996-24-000105 — 3.02
- 2024-08-29 0001571996-24-000081 — 2.02, 9.01
- 2024-07-12 0001193125-24-178608 — 3.02
- 2024-07-02 0001571996-24-000074 — 5.07
- 2024-06-10 0001571996-24-000059 — 3.02
- 2024-05-30 0001571996-24-000050 — 2.02, 9.01
- 2024-03-26 0001571996-24-000038 — 3.02
- 2024-03-18 0001193125-24-070193 — 1.01, 2.03, 9.01
- 2024-03-07 0001571996-24-000012 — 3.02
- 2024-03-06 0001193125-24-059631 — 8.01, 9.01
- 2024-02-29 0001571996-24-000008 — 2.02, 9.01
- 2024-01-30 0001571996-24-000004 — 1.02
- 2024-01-18 0001571996-24-000002 — 3.02
- 2023-12-18 0001193125-23-297664 — 8.01, 9.01
- 2023-12-05 0001571996-23-000042 — 3.02
- 2023-12-04 0001193125-23-288428 — 8.01, 9.01
- 2023-11-30 0001571996-23-000039 — 2.02, 9.01
- 2023-10-05 0001193125-23-251131 — 7.01, 8.01, 9.01
- 2023-10-02 0001571996-23-000036 — 5.02 — amendment of 0001571996-23-000034
- 2023-09-26 0001571996-23-000034 — 5.02
- 2023-08-31 0001571996-23-000029 — 2.02, 9.01
- 2023-08-09 0001571996-23-000026 — 5.02 — amendment of 0001571996-23-000002
- 2023-07-28 0001571996-23-000024 — 5.02
- 2023-07-13 0001193125-23-186639 — 3.02
- 2023-06-30 0001193125-23-180570 — 8.01, 9.01
- 2023-06-22 0001571996-23-000021 — 5.02, 5.07, 9.01
- 2023-06-15 0001193125-23-167472 — 8.01, 9.01
- 2023-06-01 0001571996-23-000014 — 2.02, 9.01
- 2023-03-02 0001571996-23-000002 — 2.02, 5.02, 9.01
- 2023-02-06 0001193125-23-024781 — 7.01, 9.01
- 2023-01-24 0001193125-23-014260 — 1.01, 2.03, 9.01
- 2023-01-11 0001193125-23-006528 — 8.01, 9.01
- 2022-11-21 0001571996-22-000041 — 2.02, 9.01
- 2022-11-16 0001571996-22-000038 — 8.01
- 2022-08-25 0001571996-22-000028 — 2.02, 9.01
- 2022-07-18 0001193125-22-196334 — 2.03, 8.01
- 2022-06-29 0001571996-22-000025 — 3.03, 5.03, 5.07, 8.01, 9.01
- 2022-05-26 0001571996-22-000013 — 2.02, 9.01
- 2022-02-24 0001571996-22-000004 — 2.02, 8.01, 9.01
- 2021-12-20 0001193125-21-362482 — 8.01, 9.01
- 2021-12-15 0001193125-21-357927 — 1.01, 2.03, 9.01
- 2021-12-07 0001193125-21-349218 — 8.01, 9.01
- 2021-11-23 0001571996-21-000060 — 2.02, 9.01
- 2021-11-05 0001571996-21-000057 — 1.02, 2.01, 7.01, 8.01, 9.01 — amendment, the index does not say of what
- 2021-11-01 0001571996-21-000052 — 8.01, 9.01
- 2021-11-01 0001193125-21-315488 — 1.01, 1.02, 2.01, 8.01, 9.01
- 2021-10-21 0001193125-21-304052 — 8.01, 9.01
- 2021-10-19 0001571996-21-000050 — 8.01, 9.01
- 2021-10-07 0001193125-21-294210 — 8.01, 9.01
- 2021-09-30 0001571996-21-000047 — 5.02
- 2021-09-27 0001571996-21-000045 — 8.01
- 2021-09-23 0001193125-21-280190 — 7.01, 8.01, 9.01
- 2021-09-20 0001193125-21-276810 — 7.01, 9.01
- 2021-08-26 0001571996-21-000037 — 2.02, 9.01
- 2021-07-01 0001571996-21-000034 — 3.02
- 2021-06-24 0001571996-21-000031 — 5.07
- 2021-06-24 0001193125-21-197644 — 7.01, 9.01
- 2021-06-16 0001571996-21-000029 — 5.02
- 2021-05-27 0001571996-21-000019 — 2.02, 9.01
- 2021-05-03 0001571996-21-000010 — 8.01, 9.01
- 2021-04-14 0001193125-21-116271 — 1.01, 7.01, 9.01
- 2021-02-25 0001571996-21-000003 — 2.02, 9.01
- 2021-02-18 0001193125-21-047844 — 1.01, 2.03, 9.01
- 2020-11-24 0001571996-20-000048 — 2.02, 9.01
- 2020-08-27 0001571996-20-000041 — 2.02, 9.01
- 2020-07-02 0001571996-20-000037 — 5.07
- 2020-05-28 0001571996-20-000028 — 2.02, 9.01
- 2020-04-09 0001193125-20-102602 — 1.01, 2.03, 9.01
- 2020-04-08 0001571996-20-000021 — 5.02
- 2020-04-03 0001571996-20-000019 — 8.01, 9.01
- 2020-03-26 0001571996-20-000015 — 7.01
- 2020-02-27 0001571996-20-000009 — 2.02, 8.01, 9.01
- 2020-02-18 0001571996-20-000005 — 8.01, 9.01
- 2020-01-09 0001571996-20-000002 — 3.02
- 2020-01-06 0001193125-20-002200 — 3.02
- 2019-12-13 0001193125-19-313947 — 3.02
- 2019-12-10 0001571996-19-000052 — 5.02
- 2019-12-02 0001571996-19-000044 — 5.02, 7.01, 9.01
- 2019-11-26 0001571996-19-000042 — 2.02, 9.01
- 2019-09-23 0001193125-19-252192 — 1.01, 2.03, 9.01
- 2019-08-29 0001571996-19-000036 — 2.02, 9.01
- 2019-08-22 0001193125-19-226939 — 7.01, 8.01, 9.01
- 2019-07-11 0001571996-19-000032 — 5.02, 5.07, 9.01
- 2019-07-03 0001571996-19-000030 — 3.02
- 2019-06-27 0001571996-19-000028 — 3.02
- 2019-05-30 0001571996-19-000021 — 2.02, 9.01
- 2019-04-02 0001571996-19-000010 — 5.02
- 2019-03-21 0001193125-19-082281 — 1.01, 1.02, 2.03, 9.01
- 2019-03-19 0001571996-19-000005 — 5.02, 9.01
- 2019-03-14 0001193125-19-074935 — 1.01, 2.03, 9.01
- 2019-03-07 0001193125-19-066045 — 8.01, 9.01
- 2019-02-28 0001571996-19-000002 — 2.02, 9.01
- 2018-12-28 0001193125-18-360943 — 1.01, 1.02, 3.01, 3.03, 5.02, 5.03, 7.01, 8.01, 9.01
- 2018-12-21 0001193125-18-356324 — 1.01, 2.03, 9.01
- 2018-12-14 0001193125-18-349469 — 8.01
- 2018-12-11 0001193125-18-346958 — 5.07, 8.01, 9.01
- 2018-11-29 0001571996-18-000041 — 2.02, 9.01
- 2018-11-28 0001571996-18-000037 — 7.01, 8.01, 9.01
- 2018-11-26 0001193125-18-333967 — 8.01, 9.01
- 2018-11-15 0001193125-18-328110 — 1.01, 9.01 — amendment of 0001193125-18-327222
- 2018-11-15 0001193125-18-327222 — 1.01, 7.01, 9.01
- 2018-10-03 0001193125-18-291390 — 8.01
- 2018-09-06 0001571996-18-000029 — 2.02, 9.01
- 2018-08-06 0001571996-18-000027 — 8.01, 9.01
- 2018-07-02 0001193125-18-210339 — 1.01, 7.01, 9.01
- 2018-06-28 0001571996-18-000024 — 5.07
- 2018-06-04 0001571996-18-000019 — 2.02, 9.01
- 2018-05-17 0001571996-18-000016 — 7.01
- 2018-04-26 0001571996-18-000009 — 7.01, 9.01
- 2018-03-08 0001193125-18-074168 — 2.02, 9.01
- 2018-02-02 0001193125-18-029947 — 7.01, 9.01
- 2017-12-07 0001571996-17-000042 — 2.02, 9.01
- 2017-10-24 0001571996-17-000037 — 1.01, 2.03, 9.01
- 2017-09-15 0001571996-17-000027 — 5.02
- 2017-09-07 0001571996-17-000017 — 2.02, 9.01
- 2017-08-24 0001571996-17-000014 — 8.01
- 2017-06-29 0001571996-17-000011 — 3.03, 5.07, 8.01, 9.01
- 2017-06-08 0001193125-17-197638 — 2.02, 9.01
- 2017-03-30 0001193125-17-102794 — 8.01
- 2017-03-30 0001193125-17-102777 — 2.02, 9.01
- 2017-03-09 0001193125-17-076981 — 1.01, 2.03, 9.01
- 2017-01-17 0001193125-17-011125 — 8.01
- 2016-12-15 0001193125-16-793722 — 8.01
- 2016-12-08 0001193125-16-787976 — 2.02, 9.01
- 2016-11-10 0001193125-16-765964 — 1.02, 8.01
- 2016-11-04 0001193125-16-760249 — 8.01
- 2016-09-13 0001193125-16-708600 — 3.02
- 2016-09-09 0001193125-16-706567 — 1.01, 1.02, 2.01, 2.03, 3.02, 3.03, 5.02, 9.01
- 2016-09-07 0001193125-16-703370 — 3.03, 5.07, 7.01, 8.01, 9.01
- 2016-09-06 0001193125-16-702057 — 2.02, 9.01
- 2016-08-31 0001193125-16-697268 — 8.01, 9.01
- 2016-08-26 0001193125-16-692921 — 8.01, 9.01
- 2016-07-11 0001193125-16-645610 — 8.01
- 2016-07-05 0001193125-16-641679 — 8.01
- 2016-06-22 0001193125-16-629055 — 1.01, 2.03, 8.01, 9.01
- 2016-06-21 0001193125-16-627071 — 8.01, 9.01
- 2016-06-10 0001193125-16-618483 — 2.02, 9.01
- 2016-06-09 0001193125-16-617893 — 8.01, 9.01

## late-filing notifications on or before 2025-03-25

- none on or before 2025-03-25

## item 2.02 — earnings release, exhibit 99.1

[0001571996-25-000014:8k_2_02:1]
EX-99.1
2
exhibit991earnings8kq4fy25.htm
EX-99.1

[0001571996-25-000014:8k_2_02:2]
Document

[0001571996-25-000014:8k_2_02:3]
Exhibit 99.1

[0001571996-25-000014:8k_2_02:4]
Dell Technologies Delivers Fourth Quarter and Full-Year Fiscal 2025 Financial Results

[0001571996-25-000014:8k_2_02:5]
ROUND ROCK, Texas — Feb. 27, 2025 — Dell Technologies (NYSE: DELL) announces financial results for its fiscal 2025 fourth quarter and full year. The company also provides guidance for its fiscal 2026 first quarter and full year.

[0001571996-25-000014:8k_2_02:6]
Full-Year Summary

[0001571996-25-000014:8k_2_02:7]
•Full-year revenue of $95.6 billion, up 8% year over year

[0001571996-25-000014:8k_2_02:8]
•Full-year operating income of $6.2 billion, up 15% year over year, and non-GAAP operating income of $8.5 billion, up 8%

[0001571996-25-000014:8k_2_02:9]
•Record full-year diluted earnings per share of $6.38, up 39% year over year, and record non-GAAP diluted EPS of $8.14, up 10%

[0001571996-25-000014:8k_2_02:10]
•Cash flow from operations was $4.5 billion

[0001571996-25-000014:8k_2_02:11]
•Announcing a cash dividend increase of 18% and $10 billion increase in share repurchase authorization

[0001571996-25-000014:8k_2_02:12]
•FY26 guidance: Full-year revenue growth of 8%, diluted EPS growth of 23% and non-GAAP diluted EPS growth of 14%

[0001571996-25-000014:8k_2_02:13]
Fourth-Quarter Summary

[0001571996-25-000014:8k_2_02:14]
•Fourth-quarter revenue of $23.9 billion, up 7% year over year

[0001571996-25-000014:8k_2_02:15]
•Fourth-quarter operating income of $2.2 billion, up 40% year over year, and non-GAAP operating income of $2.7 billion, up 22%

[0001571996-25-000014:8k_2_02:16]
•Record fourth-quarter diluted EPS of $2.15, up 30% year over year, and record non-GAAP diluted EPS of $2.68, up 18%

[0001571996-25-000014:8k_2_02:17]
“FY25 was a transformative year – we hit $95.6 billion in revenue, grew our core business double digits, unlocked efficiencies, and drove record EPS,” said Yvonne McGill, chief financial officer, Dell Technologies. “We’re raising our annual dividend by 18%, demonstrating our commitment to shareholder return and confidence in our opportunity to grow in FY26.”

[0001571996-25-000014:8k_2_02:18]
“In Q4 we grew our Infrastructure Solutions Group revenue by 22%, and we’re well positioned to capture growth across every segment of our business,” said Jeff Clarke, vice chairman and chief operating officer, Dell Technologies. “Our prospects for AI are strong, as we extend AI from the largest cloud service providers, into the enterprise at-scale, and out to the edge with the PC. The deals we’ve booked with xAI and others puts our AI server backlog at roughly $9 billion as of today.”

[0001571996-25-000014:8k_2_02:19]
1

[0001571996-25-000014:8k_2_02:20]
Infrastructure Solutions Group (ISG)

[0001571996-25-000014:8k_2_02:21]
•Full-year revenue: $43.6 billion, up 29% year over year

[0001571996-25-000014:8k_2_02:22]
•Full-year operating income: $5.6 billion, up 30% year over year

[0001571996-25-000014:8k_2_02:23]
•Fourth-quarter revenue: $11.4 billion, up 22% year over year

[0001571996-25-000014:8k_2_02:24]
•Fourth-quarter Servers and Networking revenue: $6.6 billion, up 37%, driven by AI and traditional server demand

[0001571996-25-000014:8k_2_02:25]
•Fourth-quarter Storage revenue: $4.7 billion, up 5%

[0001571996-25-000014:8k_2_02:26]
•Record fourth-quarter operating income: $2.1 billion, up 44% year over year

[0001571996-25-000014:8k_2_02:27]
Client Solutions Group (CSG)

[0001571996-25-000014:8k_2_02:28]
•Full-year revenue: $48.4 billion, down 1% year over year

[0001571996-25-000014:8k_2_02:29]
•Full-year operating income: $3.0 billion, down 20% year over year

[0001571996-25-000014:8k_2_02:30]
•Fourth-quarter revenue: $11.9 billion, up 1% year over year

[0001571996-25-000014:8k_2_02:31]
•Fourth-quarter Commercial Client revenue: $10.0 billion, up 5%

[0001571996-25-000014:8k_2_02:32]
•Fourth-quarter Consumer revenue: $1.9 billion, down 12%

[0001571996-25-000014:8k_2_02:33]
•Fourth-quarter operating income: $631 million, down 19% year over year

[0001571996-25-000014:8k_2_02:34]
Capital Return

[0001571996-25-000014:8k_2_02:35]
Dell Technologies is increasing its annual cash dividend by 18% to an expected $2.10 per common share, with $0.525 per common share for the first quarterly distribution payable on May 2, 2025, to shareholders of record as of April 22, 2025. Additionally, the company’s board of directors approved a $10 billion increase in its share repurchase authorization.

[0001571996-25-000014:8k_2_02:36]
Guidance Summary

[0001571996-25-000014:8k_2_02:37]
•Full-year FY26 revenue expected between $101.0 billion and $105.0 billion, up 8% year over year at the midpoint of $103.0 billion

[0001571996-25-000014:8k_2_02:38]
•Full-year FY26 GAAP diluted EPS expected to be $7.85, up 23% year over year, and non-GAAP diluted EPS to be $9.30, up 14%

[0001571996-25-000014:8k_2_02:39]
•First-quarter FY26 revenue expected between $22.5 billion and $23.5 billion, up 3% year over year at the midpoint of $23.0 billion

[0001571996-25-000014:8k_2_02:40]
•First-quarter FY26 GAAP diluted EPS expected to be $1.29, down 6% year over year, and non-GAAP diluted EPS to be $1.65, up 25%

[0001571996-25-000014:8k_2_02:41]
2

[0001571996-25-000014:8k_2_02:42]
Fourth Quarter and Full-Year Fiscal 2025 Financial Results

[0001571996-25-000014:8k_2_02:43]
|  | Three Months Ended |  |  |  | Fiscal Year Ended |  |  |
|  | January 31, 2025 |  | February 2, 2024 |  | Change |  | January 31, 2025 |  | February 2, 2024 |  | Change |
|  | (in millions, except per share amounts and percentages; unaudited) |
| Net revenue | $ | 23,931 |  |  | $ | 22,318 |  |  | 7% |  | $ | 95,567 |  |  | $ | 88,425 |  |  | 8% |
| Operating income | $ | 2,159 |  |  | $ | 1,547 |  |  | 40% |  | $ | 6,237 |  |  | $ | 5,411 |  |  | 15% |
| Net income | $ | 1,532 |  |  | $ | 1,208 |  |  | 27% |  | $ | 4,576 |  |  | $ | 3,372 |  |  | 36% |
| Change in cash from operating activities | $ | 585 |  |  | $ | 1,533 |  |  | (62)% |  | $ | 4,521 |  |  | $ | 8,676 |  |  | (48)% |
| Earnings per share — diluted | $ | 2.15 |  |  | $ | 1.66 |  |  | 30% |  | $ | 6.38 |  |  | $ | 4.60 |  |  | 39% |
| Non-GAAP operating income | $ | 2,674 |  |  | $ | 2,195 |  |  | 22% |  | $ | 8,529 |  |  | $ | 7,878 |  |  | 8% |
| Non-GAAP net income | $ | 1,911 |  |  | $ | 1,660 |  |  | 15% |  | $ | 5,865 |  |  | $ | 5,422 |  |  | 8% |
| Adjusted free cash flow | $ | 474 |  |  | $ | 1,010 |  |  | (53)% |  | $ | 3,097 |  |  | $ | 5,607 |  |  | (45)% |
| Non-GAAP earnings per share — diluted | $ | 2.68 |  |  | $ | 2.27 |  |  | 18% |  | $ | 8.14 |  |  | $ | 7.37 |  |  | 10% |

[0001571996-25-000014:8k_2_02:44]
Information about Dell Technologies’ non-GAAP financial measures is provided under “Non-GAAP Financial Measures” below. All comparisons in this press release are year over year unless otherwise noted.

[0001571996-25-000014:8k_2_02:45]
Operating Segments Results

[0001571996-25-000014:8k_2_02:46]
|  | Three Months Ended |  |  |  | Fiscal Year Ended |  |  |
|  | January 31, 2025 |  | February 2, 2024 |  | Change |  | January 31, 2025 |  | February 2, 2024 |  | Change |
|  | (in millions, except percentages; unaudited) |
| Infrastructure Solutions Group (ISG): |  |  |  |  |  |  |  |  |  |  |  |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Servers and networking | $ | 6,634 |  | $ | 4,857 |  |  | 37% |  | $ | 27,136 |  |  | $ | 17,624 |  |  | 54% |
| Storage | 4,718 |  |  | 4,475 |  |  | 5% |  | 16,457 |  |  | 16,261 |  |  | 1% |
| Total ISG net revenue | $ | 11,352 |  |  | $ | 9,332 |  |  | 22% |  | $ | 43,593 |  |  | $ | 33,885 |  |  | 29% |
| Operating Income: |  |  |  |  |  |  |  |  |  |  |  |
| ISG operating income | $ | 2,051 |  |  | $ | 1,428 |  |  | 44% |  | $ | 5,579 |  |  | $ | 4,286 |  |  | 30% |
| % of ISG net revenue | 18.1 | % |  | 15.3 | % |  |  |  | 12.8 | % |  | 12.6 | % |  |  |
| % of total reportable segment operating income | 76 | % |  | 65 | % |  |  |  | 65 | % |  | 54 | % |  |  |
| Client Solutions Group (CSG): |  |  |  |  |  |  |  |  |  |  |  |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Commercial | $ | 9,996 |  |  | $ | 9,563 |  |  | 5% |  | $ | 40,844 |  |  | $ | 39,814 |  |  | 3% |
| Consumer | 1,885 |  |  | 2,152 |  |  | (12)% |  | 7,549 |  |  | 9,102 |  |  | (17)% |
| Total CSG net revenue | $ | 11,881 |  |  | $ | 11,715 |  |  | 1% |  | $ | 48,393 |  |  | $ | 48,916 |  |  | (1)% |
| Operating Income: |  |  |  |  |  |  |  |  |  |  |  |
| CSG operating income | $ | 631 |  |  | $ | 782 |  |  | (19)% |  | $ | 2,972 |  |  | $ | 3,712 |  |  | (20)% |
| % of CSG net revenue | 5.3 | % |  | 6.7 | % |  |  |  | 6.1 | % |  | 7.6 | % |  |  |
| % of total reportable segment operating income | 24 | % |  | 35 | % |  |  |  | 35 | % |  | 46 | % |  |  |

[0001571996-25-000014:8k_2_02:47]
3

[0001571996-25-000014:8k_2_02:48]
Revised Consolidated Financial Statements and Non-GAAP Financial Measures for Correction of Immaterial Errors

[0001571996-25-000014:8k_2_02:49]
During the fourth quarter of fiscal 2025, Dell Technologies discovered accumulated credits from suppliers that were not recorded or not recorded in the correct period in its previously reported financial results. The company initiated an investigation that indicated that the credits resulted from the actions of certain employees that support a limited number of suppliers, impacting the Client Solutions Group segment and overstating cost of goods sold by approximately $200 million in fiscal 2024 and $148 million in fiscal 2025 for the nine months ended November 1, 2024.

[0001571996-25-000014:8k_2_02:50]
The company determined the impacts were not material, individually or in the aggregate, to its previously issued consolidated financial statements for any of the prior quarters or the annual period in which they occurred. However, in accordance with SEC Staff Accounting Bulletin No. 108, the company concluded that correcting the cumulative misstatement in the current period would be material to its results of operations for fiscal 2025. The company has revised its prior period financial statements to correct for the overstatement of cost of goods sold in its Consolidated Statements of Income, net of the related income tax effect, and the corresponding amounts impacting the Consolidated Statements of Financial Position during the fiscal 2024 and fiscal 2025 interim periods and for the fiscal year ended February 2, 2024 as shown on Exhibit A, “Revision of Previously Issued Financial Results.”

[0001571996-25-000014:8k_2_02:51]
Conference call information

[0001571996-25-000014:8k_2_02:52]
As previously announced, the company will hold a conference call to discuss its performance and financial guidance on Feb. 27 at 3:30 p.m. CST. Prior to the start of the conference call, prepared remarks and a presentation containing additional financial and operating information may be downloaded from investors.delltechnologies.com. The conference call will be broadcast live over the internet and can be accessed at https://investors.delltechnologies.com/news-events/upcoming-events.

[0001571996-25-000014:8k_2_02:53]
For those unable to listen to the live broadcast, the final remarks and presentation with additional financial and operating information will be available following the broadcast, and an archived version will be available at the same location for one year.

[0001571996-25-000014:8k_2_02:54]
About Dell Technologies

[0001571996-25-000014:8k_2_02:55]
Dell Technologies (NYSE:DELL) helps organizations and individuals build their digital future and transform how they work, live and play. The company provides customers with the industry’s broadest and most innovative technology and services portfolio for the AI era.

[0001571996-25-000014:8k_2_02:56]
Contacts

[0001571996-25-000014:8k_2_02:57]
Investors: Investor_Relations@Dell.com

[0001571996-25-000014:8k_2_02:58]
Media: Media.Relations@Dell.com

[0001571996-25-000014:8k_2_02:59]
# # #

[0001571996-25-000014:8k_2_02:60]
Copyright © 2025 Dell Inc. or its subsidiaries. All Rights Reserved. Dell Technologies, Dell, EMC and Dell EMC are trademarks of Dell Inc. or its subsidiaries. Other trademarks may be trademarks of their respective owners.

[0001571996-25-000014:8k_2_02:61]
Non-GAAP Financial Measures:

[0001571996-25-000014:8k_2_02:62]
This press release presents information about non-GAAP gross margin, non-GAAP operating expenses, non-GAAP operating income, non-GAAP net income, non-GAAP earnings per share attributable to Dell Technologies Inc. – diluted, free cash flow, and adjusted free cash flow, all of which are non-GAAP financial measures provided as a supplement to the results provided in accordance with generally accepted accounting principles in the United States of America (“GAAP”). A reconciliation of each non-GAAP financial measure to the most directly comparable GAAP financial measure is provided in the attached tables for each of the fiscal periods indicated.

[0001571996-25-000014:8k_2_02:63]
Special Note on Forward-Looking Statements:

[0001571996-25-000014:8k_2_02:64]
Forward-looking statements include, among others, any statements regarding Dell Technologies’ expectations for first-quarter and full-year fiscal 2026 revenue, GAAP diluted earnings per share and non-GAAP diluted earnings per share, and any other statements regarding Dell Technologies’ prospects and its future operations, financial condition, volumes, cash flows, expenses or other financial items, including management’s plans or strategies and objectives for any of the foregoing and any assumptions, expectations or beliefs underlying any of the foregoing.

[0001571996-25-000014:8k_2_02:65]
Dell Technologies’ results or events in future periods could differ materially from those expressed or implied by these forward-looking statements because of risks, uncertainties, and other factors that include, but are not limited to, the following: adverse global economic conditions and instability in financial markets; competitive pressures; Dell Technologies’ reliance on third-party suppliers for products and components, including reliance on single-source or limited-source suppliers; Dell Technologies’ ability to achieve favorable pricing from its vendors; Dell Technologies’ execution of its strategy; social and ethical issues relating to the use of new and evolving technologies; Dell Technologies’ ability to manage solutions and products and services transitions in an effective manner; Dell Technologies’ ability to deliver high-quality products, software, and services; cyber attacks or other data security incidents; Dell Technologies’ ability to successfully execute on strategic initiatives including acquisitions, divestitures or cost savings measures; Dell Technologies’ foreign operations and ability to generate substantial non-U.S. net revenue; Dell Technologies’ product, services, customer, and geographic sales mix, and seasonal sales trends; the performance of Dell Technologies’ sales channel partners; access to the capital markets by Dell Technologies or its customers; material impairment of the value of goodwill or intangible assets; adverse economic conditions and the effect of additional regulation on Dell Technologies’ financial services activities; counterparty default risks; the loss by Dell Technologies of any contracts for ISG services and solutions and its ability to perform such contracts at their estimated costs; loss by Dell Technologies of government contracts; Dell Technologies’ ability to develop and protect its proprietary intellectual property or obtain licenses to intellectual property developed by others on commercially reasonable and competitive terms; disruptions in Dell Technologies’ infrastructure; Dell Technologies’ ability to hedge effectively its exposure to fluctuations in foreign currency exchange rates and interest rates; expiration of tax holidays or favorable tax rate structures, or unfavorable outcomes in tax audits and other tax compliance matters; impairment of portfolio investments; unfavorable results of legal proceedings; expectations relating to environmental, social and governance (ESG) considerations; compliance requirements of changing environmental and safety laws, human rights laws, or other laws; the effect of armed hostilities, terrorism, natural disasters, or public health issues; the effect of global climate change and legal, regulatory, or market measures to address climate change; Dell Technologies’ dependence on the services of Michael Dell and key employees; Dell Technologies’ level of indebtedness; and business and financial factors and legal restrictions affecting continuation of Dell Technologies’ quarterly cash dividend policy and dividend rate.

[0001571996-25-000014:8k_2_02:66]
This list of risks, uncertainties, and other factors is not complete. Dell Technologies discusses some of these matters more fully, as well as certain risk factors that could affect Dell Technologies’ business, financial condition, results of operations, and prospects, in its reports filed with the SEC, including Dell Technologies’ annual report on Form 10-K for the fiscal year ended February 2, 2024, quarterly reports on Form 10-Q, and current reports on Form 8-K. These filings are available for review through the SEC’s website at www.sec.gov. Any or all forward-looking statements Dell Technologies makes may turn out to be wrong and can be affected by inaccurate assumptions Dell Technologies might make or by known or unknown risks, uncertainties, and other factors, including those identified in this press release. Accordingly, you should not place undue reliance on the forward-looking statements made in this press release, which speak only as of its date. Dell Technologies does not undertake to update, and expressly disclaims any duty to update, its forward-looking statements, whether as a result of circumstances or events that arise after the date they are made, new information, or otherwise.

[0001571996-25-000014:8k_2_02:67]
5

[0001571996-25-000014:8k_2_02:68]
DELL TECHNOLOGIES INC.

[0001571996-25-000014:8k_2_02:69]
Consolidated Statements of Income and Related Financial Highlights

[0001571996-25-000014:8k_2_02:70]
(in millions, except percentages; unaudited)

[0001571996-25-000014:8k_2_02:71]
|  | Three Months Ended |  |  |  | Fiscal Year Ended |  |  |
|  | January 31, 2025 |  | February 2, 2024 |  | Change |  | January 31, 2025 |  | February 2, 2024 |  | Change |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Products | $ | 18,049 |  |  | $ | 16,149 |  |  | 12% |  | $ | 71,420 |  |  | $ | 64,353 |  |  | 11% |
| Services | 5,882 |  |  | 6,169 |  |  | (5)% |  | 24,147 |  |  | 24,072 |  |  | —% |
| Total net revenue | 23,931 |  |  | 22,318 |  |  | 7% |  | 95,567 |  |  | 88,425 |  |  | 8% |
| Cost of net revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Products | 14,924 |  |  | 13,337 |  |  | 12% |  | 60,162 |  |  | 53,116 |  |  | 13% |
| Services | 3,329 |  |  | 3,609 |  |  | (8)% |  | 14,155 |  |  | 14,240 |  |  | (1)% |
| Total cost of net revenue | 18,253 |  |  | 16,946 |  |  | 8% |  | 74,317 |  |  | 67,356 |  |  | 10% |
| Gross margin | 5,678 |  |  | 5,372 |  |  | 6% |  | 21,250 |  |  | 21,069 |  |  | 1% |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |
| Selling, general, and administrative | 2,746 |  |  | 3,109 |  |  | (12)% |  | 11,952 |  |  | 12,857 |  |  | (7)% |
| Research and development | 773 |  |  | 716 |  |  | 8% |  | 3,061 |  |  | 2,801 |  |  | 9% |
| Total operating expenses | 3,519 |  |  | 3,825 |  |  | (8)% |  | 15,013 |  |  | 15,658 |  |  | (4)% |
| Operating income | 2,159 |  |  | 1,547 |  |  | 40% |  | 6,237 |  |  | 5,411 |  |  | 15% |
| Interest and other, net | (187) |  |  | (203) |  |  | 8% |  | (1,189) |  |  | (1,324) |  |  | 10% |
| Income before income taxes | 1,972 |  |  | 1,344 |  |  | 47% |  | 5,048 |  |  | 4,087 |  |  | 24% |
| Income tax expense | 440 |  |  | 136 |  |  | 224% |  | 472 |  |  | 715 |  |  | (34)% |
| Net income | 1,532 |  |  | 1,208 |  |  | 27% |  | 4,576 |  |  | 3,372 |  |  | 36% |
| Less: Net loss attributable to non-controlling interests | (1) |  |  | (2) |  |  | 50% |  | (16) |  |  | (16) |  |  | —% |
| Net income attributable to Dell Technologies Inc. | $ | 1,533 |  |  | $ | 1,210 |  |  | 27% |  | $ | 4,592 |  |  | $ | 3,388 |  |  | 36% |
| Percentage of Total Net Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Gross margin | 23.7 | % |  | 24.1 | % |  |  |  | 22.2 | % |  | 23.8 | % |  |  |
| Selling, general, and administrative | 11.5 | % |  | 13.9 | % |  |  |  | 12.5 | % |  | 14.5 | % |  |  |
| Research and development | 3.2 | % |  | 3.2 | % |  |  |  | 3.2 | % |  | 3.2 | % |  |  |
| Operating expenses | 14.7 | % |  | 17.1 | % |  |  |  | 15.7 | % |  | 17.7 | % |  |  |
| Operating income | 9.0 | % |  | 6.9 | % |  |  |  | 6.5 | % |  | 6.1 | % |  |  |
| Income before income taxes | 8.2 | % |  | 6.0 | % |  |  |  | 5.3 | % |  | 4.6 | % |  |  |
| Net income | 6.4 | % |  | 5.4 | % |  |  |  | 4.8 | % |  | 3.8 | % |  |  |
| Income tax rate | 22.3 | % |  | 10.1 | % |  |  |  | 9.4 | % |  | 17.5 | % |  |  |

[0001571996-25-000014:8k_2_02:72]
Amounts are based on underlying data and may not visually foot due to rounding.

[0001571996-25-000014:8k_2_02:73]
6

[0001571996-25-000014:8k_2_02:74]
DELL TECHNOLOGIES INC.

[0001571996-25-000014:8k_2_02:75]
Consolidated Statements of Financial Position

[0001571996-25-000014:8k_2_02:76]
(in millions; unaudited)

[0001571996-25-000014:8k_2_02:77]
|  | January 31, 2025 |  | February 2, 2024 |
| ASSETS |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 3,633 |  |  | $ | 7,366 |  |
| Accounts receivable, net of allowance of $63 and $71 | 10,298 |  |  | 9,343 |  |
| Short-term financing receivables, net of allowance of $78 and $79 | 5,304 |  |  | 4,643 |  |
| Inventories | 6,716 |  |  | 3,622 |  |
| Other current assets | 9,610 |  |  | 11,010 |  |
| Current assets held for sale | 668 |  |  | — |  |
| Total current assets | 36,229 |  |  | 35,984 |  |
| Property, plant, and equipment, net | 6,336 |  |  | 6,432 |  |
| Long-term investments | 1,496 |  |  | 1,316 |  |
| Long-term financing receivables, net of allowance of $75 and $91 | 5,927 |  |  | 5,877 |  |
| Goodwill | 19,120 |  |  | 19,700 |  |
| Intangible assets, net | 4,988 |  |  | 5,701 |  |
| Other non-current assets | 5,650 |  |  | 7,116 |  |
| Total assets | $ | 79,746 |  |  | $ | 82,126 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |
| Short-term debt | $ | 5,204 |  |  | $ | 6,982 |  |
| Accounts payable | 20,832 |  |  | 19,226 |  |
| Accrued and other | 6,597 |  |  | 6,828 |  |
| Short-term deferred revenue | 13,673 |  |  | 15,318 |  |
| Current liabilities held for sale | 221 |  |  | — |  |
| Total current liabilities | 46,527 |  |  | 48,354 |  |
| Long-term debt | 19,363 |  |  | 19,012 |  |
| Long-term deferred revenue | 12,292 |  |  | 13,827 |  |
| Other non-current liabilities | 2,951 |  |  | 3,065 |  |
| Total liabilities | 81,133 |  |  | 84,258 |  |
| Stockholders’ equity (deficit): |  |  |  |
| Common stock and capital in excess of $0.01 par value | 9,119 |  |  | 8,926 |  |
| Treasury stock at cost | (8,502) |  |  | (5,900) |  |
| Accumulated deficit | (1,160) |  |  | (4,453) |  |
| Accumulated other comprehensive loss | (939) |  |  | (800) |  |
| Total Dell Technologies Inc. stockholders’ equity (deficit) | (1,482) |  |  | (2,227) |  |
| Non-controlling interests | 95 |  |  | 95 |  |
| Total stockholders’ equity (deficit) | (1,387) |  |  | (2,132) |  |
| Total liabilities and stockholders’ equity | $ | 79,746 |  |  | $ | 82,126 |  |

[0001571996-25-000014:8k_2_02:78]
7

[0001571996-25-000014:8k_2_02:79]
DELL TECHNOLOGIES INC.

[0001571996-25-000014:8k_2_02:80]
Consolidated Statements of Cash Flows

[0001571996-25-000014:8k_2_02:81]
(in millions; unaudited)

[0001571996-25-000014:8k_2_02:82]
|  | Three Months Ended |  | Fiscal Year Ended |
|  | January 31, 2025 |  | February 2, 2024 |  | January 31, 2025 |  | February 2, 2024 |
| Cash flows from operating activities: |  |  |  |  |  |  |  |
| Net income | $ | 1,532 |  |  | $ | 1,208 |  |  | $ | 4,576 |  |  | $ | 3,372 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: | (947) |  |  | 325 |  |  | (55) |  |  | 5,304 |  |
| Change in cash from operating activities | 585 |  |  | 1,533 |  |  | 4,521 |  |  | 8,676 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |
| Purchases of investments | (42) |  |  | (29) |  |  | (125) |  |  | (172) |  |
| Maturities and sales of investments | 45 |  |  | 76 |  |  | 382 |  |  | 226 |  |
| Capital expenditures and capitalized software development costs | (735) |  |  | (727) |  |  | (2,652) |  |  | (2,756) |  |
| Acquisition of businesses and assets, net | — |  |  | 1 |  |  | — |  |  | (126) |  |
| Other | 54 |  |  | 10 |  |  | 180 |  |  | 45 |  |
| Change in cash from investing activities | (678) |  |  | (669) |  |  | (2,215) |  |  | (2,783) |  |
| Cash flows from financing activities: |  |  |  |  |  |  |  |
| Proceeds from the issuance of common stock | — |  |  | 2 |  |  | 1 |  |  | 10 |  |
| Repurchases of common stock | (734) |  |  | (878) |  |  | (2,588) |  |  | (2,080) |  |
| Repurchases of common stock for employee tax withholdings | (17) |  |  | (18) |  |  | (577) |  |  | (372) |  |
| Payments of dividends and dividend equivalents | (311) |  |  | (261) |  |  | (1,275) |  |  | (1,072) |  |
| Proceeds from debt | 645 |  |  | 871 |  |  | 9,258 |  |  | 7,775 |  |
| Repayments of debt | (976) |  |  | (1,480) |  |  | (10,570) |  |  | (11,246) |  |
| Debt-related costs and other, net | 2 |  |  | (55) |  |  | (64) |  |  | (109) |  |
| Change in cash from financing activities | (1,391) |  |  | (1,819) |  |  | (5,815) |  |  | (7,094) |  |
| Effect of exchange rate changes on cash, cash equivalents, and restricted cash | (101) |  |  | 14 |  |  | (179) |  |  | (186) |  |
| Change in cash, cash equivalents, and restricted cash | (1,585) |  |  | (941) |  |  | (3,688) |  |  | (1,387) |  |
| Cash, cash equivalents, and restricted cash at beginning of the period | 5,404 |  |  | 8,448 |  |  | 7,507 |  |  | 8,894 |  |
| Cash, cash equivalents, and restricted cash at end of the period | $ | 3,819 |  |  | $ | 7,507 |  |  | $ | 3,819 |  |  | $ | 7,507 |  |

[0001571996-25-000014:8k_2_02:83]
8

[0001571996-25-000014:8k_2_02:84]
DELL TECHNOLOGIES INC.

[0001571996-25-000014:8k_2_02:85]
Segment Information

[0001571996-25-000014:8k_2_02:86]
(in millions, except percentages; unaudited; continued on next page)

[0001571996-25-000014:8k_2_02:87]
|  | Three Months Ended |  |  |  | Fiscal Year Ended |  |  |
|  | January 31, 2025 |  | February 2, 2024 |  | Change |  | January 31, 2025 |  | February 2, 2024 |  | Change |
| Infrastructure Solutions Group (ISG): |  |  |  |  |  |  |  |  |  |  |  |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Servers and networking | $ | 6,634 |  | $ | 4,857 |  |  | 37% |  | $ | 27,136 |  |  | $ | 17,624 |  |  | 54% |
| Storage | 4,718 |  |  | 4,475 |  |  | 5% |  | 16,457 |  |  | 16,261 |  |  | 1% |
| Total ISG net revenue | $ | 11,352 |  |  | $ | 9,332 |  |  | 22% |  | $ | 43,593 |  |  | $ | 33,885 |  |  | 29% |
| Operating Income: |  |  |  |  |  |  |  |  |  |  |  |
| ISG operating income | $ | 2,051 |  |  | $ | 1,428 |  |  | 44% |  | $ | 5,579 |  |  | $ | 4,286 |  |  | 30% |
| % of ISG net revenue | 18.1 | % |  | 15.3 | % |  |  |  | 12.8 | % |  | 12.6 | % |  |  |
| % of total reportable segment operating income | 76 | % |  | 65 | % |  |  |  | 65 | % |  | 54 | % |  |  |
| Client Solutions Group (CSG): |  |  |  |  |  |  |  |  |  |  |  |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Commercial | $ | 9,996 |  |  | $ | 9,563 |  |  | 5% |  | $ | 40,844 |  |  | $ | 39,814 |  |  | 3% |
| Consumer | 1,885 |  |  | 2,152 |  |  | (12)% |  | 7,549 |  |  | 9,102 |  |  | (17)% |
| Total CSG net revenue | $ | 11,881 |  |  | $ | 11,715 |  |  | 1% |  | $ | 48,393 |  |  | $ | 48,916 |  |  | (1)% |
| Operating Income: |  |  |  |  |  |  |  |  |  |  |  |
| CSG operating income | $ | 631 |  |  | $ | 782 |  |  | (19)% |  | $ | 2,972 |  |  | $ | 3,712 |  |  | (20)% |
| % of CSG net revenue | 5.3 | % |  | 6.7 | % |  |  |  | 6.1 | % |  | 7.6 | % |  |  |
| % of total reportable segment operating income | 24 | % |  | 35 | % |  |  |  | 35 | % |  | 46 | % |  |  |

[0001571996-25-000014:8k_2_02:88]
Amounts are based on underlying data and may not visually foot due to rounding.

[0001571996-25-000014:8k_2_02:89]
9

[0001571996-25-000014:8k_2_02:90]
DELL TECHNOLOGIES INC.

[0001571996-25-000014:8k_2_02:91]
Segment Information

[0001571996-25-000014:8k_2_02:92]
(in millions; unaudited; continued)

[0001571996-25-000014:8k_2_02:93]
|  | Three Months Ended |  | Fiscal Year Ended |  |  |
|  | January 31, 2025 |  | February 2, 2024 |  | January 31, 2025 |  | February 2, 2024 |  |  |
| Reconciliation to consolidated net revenue: |  |  |  |  |  |  |  |  |  |
| Reportable segment net revenue | $ | 23,233 |  |  | $ | 21,047 |  |  | $ | 91,986 |  |  | $ | 82,801 |  |  |  |
| Corporate and other (a) | 698 |  |  | 1,271 |  |  | 3,581 |  |  | 5,624 |  |  |  |
| Total consolidated net revenue | $ | 23,931 |  |  | $ | 22,318 |  |  | $ | 95,567 |  |  | $ | 88,425 |  |  |  |
| Reconciliation to consolidated operating income: |  |  |  |  |  |  |  |  |  |
| Reportable segment operating income | $ | 2,682 |  |  | $ | 2,210 |  |  | $ | 8,551 |  |  | $ | 7,998 |  |  |  |
| Corporate and other (a) | (8) |  |  | (15) |  |  | (22) |  |  | (120) |  |  |  |
| Amortization of intangibles (b) | (163) |  |  | (210) |  |  | (667) |  |  | (833) |  |  |  |
| Stock-based compensation expense (c) | (186) |  |  | (203) |  |  | (785) |  |  | (878) |  |  |  |
| Other corporate expenses (d) | (166) |  |  | (235) |  |  | (840) |  |  | (756) |  |  |  |
| Total consolidated operating income | $ | 2,159 |  |  | $ | 1,547 |  |  | $ | 6,237 |  |  | $ | 5,411 |  |  |  |

[0001571996-25-000014:8k_2_02:94]
_________________

[0001571996-25-000014:8k_2_02:95]
(a)Corporate and other consists of results of (i) VMware Resale, (ii) Secureworks, and (iii) Virtustream, and do not meet the requirements for a reportable segment, either individually or collectively. Additionally, Corporate and other includes other items that are managed at the corporate level and are not allocated to reportable segments.

[0001571996-25-000014:8k_2_02:96]
(b)Amortization of intangibles includes non-cash purchase accounting adjustments that are primarily related to the EMC merger transaction.

[0001571996-25-000014:8k_2_02:97]
(c)Stock-based compensation expense consists of equity awards granted based on the estimated fair value of those awards at grant date.

[0001571996-25-000014:8k_2_02:98]
(d)Other corporate expenses includes severance expenses, payroll taxes associated with stock-based compensation, facility action costs, transaction-related expenses, impairment charges, incentive charges related to equity investments, and other costs.

[0001571996-25-000014:8k_2_02:99]
10

[0001571996-25-000014:8k_2_02:100]
SUPPLEMENTAL SELECTED NON-GAAP FINANCIAL MEASURES

[0001571996-25-000014:8k_2_02:101]
These tables present information about the company’s non-GAAP gross margin, non-GAAP operating expenses, non-GAAP operating income, non-GAAP net income, non-GAAP earnings per share attributable to Dell Technologies Inc. - diluted, free cash flow and adjusted free cash flow, all of which are non-GAAP financial measures provided as a supplement to the results provided in accordance with generally accepted accounting principles in the United States of America (“GAAP”). A detailed discussion of Dell Technologies’ reasons for including certain of these non-GAAP financial measures, the limitations associated with these measures, the items excluded from these measures, and the company’s reason for excluding those items are presented in “Management’s Discussion and Analysis of Financial Condition and Results of Operations — Non-GAAP Financial Measures” in the company’s periodic reports filed with the SEC. Dell Technologies encourages investors to review the non-GAAP discussion in these reports in conjunction with the presentation of non-GAAP financial measures.

[0001571996-25-000014:8k_2_02:102]
11

[0001571996-25-000014:8k_2_02:103]
DELL TECHNOLOGIES INC.

[0001571996-25-000014:8k_2_02:104]
Selected Financial Measures

[0001571996-25-000014:8k_2_02:105]
(in millions, except per share amounts and percentages; unaudited)

[0001571996-25-000014:8k_2_02:106]
|  | Three Months Ended |  |  |  | Fiscal Year Ended |  |  |
|  | January 31, 2025 |  | February 2, 2024 |  | Change |  | January 31, 2025 |  | February 2, 2024 |  | Change |
| Net revenue | $ | 23,931 |  |  | $ | 22,318 |  |  | 7% |  | $ | 95,567 |  |  | $ | 88,425 |  |  | 8% |
| Non-GAAP gross margin | $ | 5,814 |  |  | $ | 5,524 |  |  | 5% |  | $ | 21,810 |  |  | $ | 21,644 |  |  | 1% |
| % of net revenue | 24.3 | % |  | 24.8 | % |  |  |  | 22.8 | % |  | 24.5 | % |  |  |
| Non-GAAP operating expenses | $ | 3,140 |  |  | $ | 3,329 |  |  | (6)% |  | $ | 13,281 |  |  | $ | 13,766 |  |  | (4)% |
| % of net revenue | 13.1 | % |  | 14.9 | % |  |  |  | 13.9 | % |  | 15.6 | % |  |  |
| Non-GAAP operating income | $ | 2,674 |  |  | $ | 2,195 |  |  | 22% |  | $ | 8,529 |  |  | $ | 7,878 |  |  | 8% |
| % of net revenue | 11.2 | % |  | 9.8 | % |  |  |  | 8.9 | % |  | 8.9 | % |  |  |
| Non-GAAP net income | $ | 1,911 |  |  | $ | 1,660 |  |  | 15% |  | $ | 5,865 |  |  | $ | 5,422 |  |  | 8% |
| % of net revenue | 8.0 | % |  | 7.4 | % |  |  |  | 6.1 | % |  | 6.1 | % |  |  |
| Non-GAAP earnings per share — diluted | $ | 2.68 |  |  | $ | 2.27 |  |  | 18% |  | $ | 8.14 |  |  | $ | 7.37 |  |  | 10% |

[0001571996-25-000014:8k_2_02:107]
Amounts are based on underlying data and may not visually foot due to rounding.

[0001571996-25-000014:8k_2_02:108]
DELL TECHNOLOGIES INC.

[0001571996-25-000014:8k_2_02:109]
Reconciliation of Selected Non-GAAP Financial Measures

[0001571996-25-000014:8k_2_02:110]
(in millions, except percentages; unaudited; continued on next page)

[0001571996-25-000014:8k_2_02:111]
|  | Three Months Ended |  |  |  | Fiscal Year Ended |  |  |
|  | January 31, 2025 |  | February 2, 2024 |  | Change |  | January 31, 2025 |  | February 2, 2024 |  | Change |
| Gross margin | $ | 5,678 |  |  | $ | 5,372 |  |  | 6% |  | $ | 21,250 |  |  | $ | 21,069 |  |  | 1% |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 59 |  |  | 84 |  |  |  |  | 238 |  |  | 331 |  |  |  |
| Stock-based compensation expense | 37 |  |  | 37 |  |  |  |  | 152 |  |  | 149 |  |  |  |
| Other corporate expenses | 40 |  |  | 31 |  |  |  |  | 170 |  |  | 95 |  |  |  |
| Non-GAAP gross margin | $ | 5,814 |  |  | $ | 5,524 |  |  | 5% |  | $ | 21,810 |  |  | $ | 21,644 |  |  | 1% |
| Operating expenses | $ | 3,519 |  |  | $ | 3,825 |  |  | (8)% |  | $ | 15,013 |  |  | $ | 15,658 |  |  | (4)% |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | (104) |  |  | (126) |  |  |  |  | (429) |  |  | (502) |  |  |  |
| Stock-based compensation expense | (149) |  |  | (166) |  |  |  |  | (633) |  |  | (729) |  |  |  |
| Other corporate expenses | (126) |  |  | (204) |  |  |  |  | (670) |  |  | (661) |  |  |  |
| Non-GAAP operating expenses | $ | 3,140 |  |  | $ | 3,329 |  |  | (6)% |  | $ | 13,281 |  |  | $ | 13,766 |  |  | (4)% |
| Operating income | $ | 2,159 |  |  | $ | 1,547 |  |  | 40% |  | $ | 6,237 |  |  | $ | 5,411 |  |  | 15% |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 163 |  |  | 210 |  |  |  |  | 667 |  |  | 833 |  |  |  |
| Stock-based compensation expense | 186 |  |  | 203 |  |  |  |  | 785 |  |  | 878 |  |  |  |
| Other corporate expenses | 166 |  |  | 235 |  |  |  |  | 840 |  |  | 756 |  |  |  |
| Non-GAAP operating income | $ | 2,674 |  |  | $ | 2,195 |  |  | 22% |  | $ | 8,529 |  |  | $ | 7,878 |  |  | 8% |
| Net income | $ | 1,532 |  |  | $ | 1,208 |  |  | 27% |  | $ | 4,576 |  |  | $ | 3,372 |  |  | 36% |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 163 |  |  | 210 |  |  |  |  | 667 |  |  | 833 |  |  |  |
| Stock-based compensation expense | 186 |  |  | 203 |  |  |  |  | 785 |  |  | 878 |  |  |  |
| Other corporate expenses | 165 |  |  | 227 |  |  |  |  | 830 |  |  | 793 |  |  |  |
| Fair value adjustments on equity investments | (156) |  |  | (83) |  |  |  |  | (177) |  |  | (47) |  |  |  |
| Aggregate adjustment for income taxes (a) | 21 |  |  | (105) |  |  |  |  | (816) |  |  | (407) |  |  |  |
| Non-GAAP net income | $ | 1,911 |  |  | $ | 1,660 |  |  | 15% |  | $ | 5,865 |  |  | $ | 5,422 |  |  | 8% |

[0001571996-25-000014:8k_2_02:112]
____________________

[0001571996-25-000014:8k_2_02:113]
(a)    Beginning in fiscal 2025, the company’s non-GAAP income tax is calculated using a fixed estimated annual tax rate.

[0001571996-25-000014:8k_2_02:114]
13

[0001571996-25-000014:8k_2_02:115]
DELL TECHNOLOGIES INC.

[0001571996-25-000014:8k_2_02:116]
Reconciliation of Selected Non-GAAP Financial Measures

[0001571996-25-000014:8k_2_02:117]
(unaudited; continued)

[0001571996-25-000014:8k_2_02:118]
|  | Three Months Ended |  |  |  | Fiscal Year Ended |  |  |  |  |  |  |
|  | January 31, 2025 |  | February 2, 2024 |  | Change |  | January 31, 2025 |  | February 2, 2024 |  | Change |  |  |  |  |
| Earnings per share attributable to Dell Technologies Inc. — diluted | $ | 2.15 |  |  | $ | 1.66 |  |  | 30 | % |  | $ | 6.38 |  |  | $ | 4.60 |  |  | 39 | % |  |  |  |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 0.22 |  |  | 0.29 |  |  |  |  | 0.93 |  |  | 1.13 |  |  |  |  |  |  |  |
| Stock-based compensation expense | 0.26 |  |  | 0.28 |  |  |  |  | 1.09 |  |  | 1.19 |  |  |  |  |  |  |  |
| Other corporate expenses | 0.23 |  |  | 0.31 |  |  |  |  | 1.16 |  |  | 1.08 |  |  |  |  |  |  |  |
| Fair value adjustments on equity investments | (0.22) |  |  | (0.11) |  |  |  |  | (0.25) |  |  | (0.06) |  |  |  |  |  |  |  |
| Aggregate adjustment for income taxes (a) | 0.04 |  |  | (0.16) |  |  |  |  | (1.15) |  |  | (0.55) |  |  |  |  |  |  |  |
| Total non-GAAP adjustments attributable to non-controlling interests | — |  |  | — |  |  |  |  | (0.02) |  |  | (0.02) |  |  |  |  |  |  |  |
| Non-GAAP earnings per share attributable to Dell Technologies Inc. — diluted | $ | 2.68 |  |  | $ | 2.27 |  |  | 18 | % |  | $ | 8.14 |  |  | $ | 7.37 |  |  | 10 | % |  |  |  |  |

[0001571996-25-000014:8k_2_02:119]
____________________

[0001571996-25-000014:8k_2_02:120]
(a)    Beginning in fiscal 2025, the company’s non-GAAP income tax is calculated using a fixed estimated annual tax rate.

[0001571996-25-000014:8k_2_02:121]
14

[0001571996-25-000014:8k_2_02:122]
DELL TECHNOLOGIES INC.

[0001571996-25-000014:8k_2_02:123]
Reconciliation of Selected Non-GAAP Financial Measures

[0001571996-25-000014:8k_2_02:124]
(in millions, except percentages; unaudited; continued)

[0001571996-25-000014:8k_2_02:125]
|  | Three Months Ended |  |  |  | Fiscal Year Ended |  |  |  |  |  |  |
|  | January 31, 2025 |  | February 2, 2024 |  | Change |  | January 31, 2025 |  | February 2, 2024 |  | Change |  |  |  |  |
| Cash flow from operations | $ | 585 |  |  | $ | 1,533 |  |  | (62) | % |  | $ | 4,521 |  |  | $ | 8,676 |  |  | (48) | % |  |  |  |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Capital expenditures and capitalized software development costs, net (a) | (702) |  |  | (727) |  |  |  |  | (2,563) |  |  | (2,753) |  |  |  |  |  |  |  |
| Free cash flow | $ | (117) |  |  | $ | 806 |  |  | (115) | % |  | $ | 1,958 |  |  | $ | 5,923 |  |  | (67) | % |  |  |  |  |
| Free cash flow | $ | (117) |  |  | $ | 806 |  |  | (115) | % |  | $ | 1,958 |  |  | $ | 5,923 |  |  | (67) | % |  |  |  |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Financing receivables (b) | 532 |  |  | 136 |  |  |  |  | 951 |  |  | (309) |  |  |  |  |  |  |  |
| Equipment under operating leases (c) | 59 |  |  | 68 |  |  |  |  | 188 |  |  | (7) |  |  |  |  |  |  |  |
| Adjusted free cash flow | $ | 474 |  |  | $ | 1,010 |  |  | (53) | % |  | $ | 3,097 |  |  | $ | 5,607 |  |  | (45) | % |  |  |  |  |

[0001571996-25-000014:8k_2_02:126]
____________________

[0001571996-25-000014:8k_2_02:127]
(a)    Capital expenditures and capitalized software development costs, net includes proceeds from sales of facilities, land, and other assets.

[0001571996-25-000014:8k_2_02:128]
(b)    Financing receivables represent the operating cash flow impact from the change in financing receivables.

[0001571996-25-000014:8k_2_02:129]
(c)    Equipment under operating leases represents the net impact of capital expenditures and depreciation expense for leases and contractually embedded leases identified within flexible consumption arrangements.

[0001571996-25-000014:8k_2_02:130]
15

[0001571996-25-000014:8k_2_02:131]
DELL TECHNOLOGIES INC.

[0001571996-25-000014:8k_2_02:132]
Reconciliation of Non-GAAP Financial Measures in Summary Guidance

[0001571996-25-000014:8k_2_02:133]
(unaudited)

[0001571996-25-000014:8k_2_02:134]
|  |  |  |  |  | Three Months Ending |  |  |  |  |  | Fiscal Year Ending |
|  |  |  |  |  | May 2, 2025 |  |  |  |  |  | January 30, 2026 |
| Earnings per share attributable to Dell Technologies Inc. — diluted |  |  |  |  | $ | 1.29 |  |  |  |  |  |  | $ | 7.85 |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles (a) |  |  |  |  | 0.17 |  |  |  |  |  |  | 0.70 |  |
| Stock-based compensation |  |  |  |  | 0.26 |  |  |  |  |  |  | 1.04 |  |
| Other corporate expenses (b) |  |  |  |  | — |  |  |  |  |  |  | — |  |
| Fair value adjustments on equity investments (c) |  |  |  |  | — |  |  |  |  |  |  | — |  |
| Aggregate adjustment for income taxes (d) |  |  |  |  | (0.07) |  |  |  |  |  |  | (0.29) |  |
| Non-GAAP earnings per share attributable to Dell Technologies Inc. — diluted |  |  |  |  | $ | 1.65 |  |  |  |  |  |  | $ | 9.30 |  |

[0001571996-25-000014:8k_2_02:135]
____________________

[0001571996-25-000014:8k_2_02:136]
(a)    Amortization of intangibles represents an estimate for acquisitions completed as of January 31, 2025 and does not include estimates for potential acquisitions, if any, during fiscal 2026.

[0001571996-25-000014:8k_2_02:137]
(b)    Consists primarily of severance expenses, payroll taxes associated with stock-based compensation, facility action costs, transaction-related expenses, impairment charges, and incentive charges related to equity investments. No estimate is included for severance expense as such expense cannot be reasonably estimated at this time.

[0001571996-25-000014:8k_2_02:138]
(c)    No estimates are included for potential fair value adjustments on strategic investments given the potential volatility of either gains or losses on those equity investments.

[0001571996-25-000014:8k_2_02:139]
(d)    The aggregate adjustment for income taxes is the estimated combined income tax effect for the adjustments shown above as well as an adjustment for discrete tax items. Beginning in fiscal 2025, the company’s non-GAAP income tax is calculated using a fixed estimated annual tax rate.

[0001571996-25-000014:8k_2_02:140]
EXHIBIT A

[0001571996-25-000014:8k_2_02:141]
DELL TECHNOLOGIES INC.

[0001571996-25-000014:8k_2_02:142]
Revision of Previously Issued Financial Results

[0001571996-25-000014:8k_2_02:143]
(in millions, except per share amounts; unaudited; continued on next page)

[0001571996-25-000014:8k_2_02:144]
|  | Three Months Ended |
|  | May 3, 2024 |  | May 5, 2023 |
|  | As Reported1 |  | Adjustment |  | As Revised |  | As Reported1 |  | Adjustment |  | As Revised |
| Condensed Consolidated Statements of Income: |  |  |  |  |  |  |  |  |
| Cost of net revenue — Products | $ | 13,766 |  |  | $ | (45) |  |  | $ | 13,721 |  |  | $ | 12,375 |  |  | $ | (62) |  |  | $ | 12,313 |  |
| Total cost of net revenue | $ | 17,438 |  |  | $ | (45) |  |  | $ | 17,393 |  |  | $ | 15,904 |  |  | $ | (62) |  |  | $ | 15,842 |  |
| Gross margin | $ | 4,806 |  |  | $ | 45 |  |  | $ | 4,851 |  |  | $ | 5,018 |  |  | $ | 62 |  |  | $ | 5,080 |  |
| Operating income | $ | 920 |  |  | $ | 45 |  |  | $ | 965 |  |  | $ | 1,069 |  |  | $ | 62 |  |  | $ | 1,131 |  |
| Income before income taxes | $ | 547 |  |  | $ | 45 |  |  | $ | 592 |  |  | $ | 705 |  |  | $ | 62 |  |  | $ | 767 |  |
| Income tax expense (benefit) | $ | (408) |  |  | $ | 8 |  |  | $ | (400) |  |  | $ | 127 |  |  | $ | 8 |  |  | $ | 135 |  |
| Net income | $ | 955 |  |  | $ | 37 |  |  | $ | 992 |  |  | $ | 578 |  |  | $ | 54 |  |  | $ | 632 |  |
| Net income attributable to Dell Technologies Inc. | $ | 960 |  |  | $ | 37 |  |  | $ | 997 |  |  | $ | 583 |  |  | $ | 54 |  |  | $ | 637 |  |
| Earnings per share attributable to Dell Technologies Inc. |  |  |  |  |  |  |  |  |
| Basic | $ | 1.36 |  |  | $ | 0.05 |  |  | $ | 1.41 |  |  | $ | 0.81 |  |  | $ | 0.07 |  |  | $ | 0.88 |  |
| Diluted | $ | 1.32 |  |  | $ | 0.05 |  |  | $ | 1.37 |  |  | $ | 0.79 |  |  | $ | 0.07 |  |  | $ | 0.86 |  |
| Segment Information: |  |  |  |  |  |  |  |  |  |  |  |
| CSG operating income | $ | 732 |  |  | $ | 45 |  |  | $ | 777 |  |  | $ | 892 |  |  | $ | 62 |  |  | $ | 954 |  |
| Reportable segment operating income | $ | 1,468 |  |  | $ | 45 |  |  | $ | 1,513 |  |  | $ | 1,632 |  |  | $ | 62 |  |  | $ | 1,694 |  |
| Non-GAAP Financial Measures: |  |  |  |  |  |  |  |
| Non-GAAP gross margin | $ | 4,947 |  |  | $ | 45 |  |  | $ | 4,992 |  |  | $ | 5,164 |  |  | $ | 62 |  |  | $ | 5,226 |  |
| Non-GAAP operating income | $ | 1,474 |  |  | $ | 45 |  |  | $ | 1,519 |  |  | $ | 1,598 |  |  | $ | 62 |  |  | $ | 1,660 |  |
| Non-GAAP net income | $ | 923 |  |  | $ | 36 |  |  | $ | 959 |  |  | $ | 963 |  |  | $ | 54 |  |  | $ | 1,017 |  |
| Non-GAAP earnings per share attributable to Dell Technologies Inc. — diluted | $ | 1.27 |  |  | $ | 0.05 |  |  | $ | 1.32 |  |  | $ | 1.31 |  |  | $ | 0.07 |  |  | $ | 1.38 |  |

[0001571996-25-000014:8k_2_02:145]
____________________

[0001571996-25-000014:8k_2_02:146]
(1)    As reported amounts represent the originally reported amounts in the company’s Quarterly Reports on Form 10-Q for the three months ended May 3, 2024 and May 5, 2023.

[0001571996-25-000014:8k_2_02:147]
17

[0001571996-25-000014:8k_2_02:148]
DELL TECHNOLOGIES INC.

[0001571996-25-000014:8k_2_02:149]
Revision of Previously Issued Financial Results

[0001571996-25-000014:8k_2_02:150]
(in millions, except per share amounts; unaudited; continued)

[0001571996-25-000014:8k_2_02:151]
|  | Three Months Ended |
|  | August 2, 2024 |  | August 4, 2023 |
|  | As Reported1 |  | Adjustment |  | As Revised |  | As Reported1 |  | Adjustment |  | As Revised |
| Condensed Consolidated Statements of Income: |  |  |  |  |  |  |  |  |
| Cost of net revenue — Products | $ | 16,079 |  |  | $ | (50) |  |  | $ | 16,029 |  |  | $ | 14,002 |  |  | $ | (29) |  |  | $ | 13,973 |  |
| Total cost of net revenue | $ | 19,715 |  |  | $ | (50) |  |  | $ | 19,665 |  |  | $ | 17,547 |  |  | $ | (29) |  |  | $ | 17,518 |  |
| Gross margin | $ | 5,311 |  |  | $ | 50 |  |  | $ | 5,361 |  |  | $ | 5,387 |  |  | $ | 29 |  |  | $ | 5,416 |  |
| Operating income | $ | 1,342 |  |  | $ | 50 |  |  | $ | 1,392 |  |  | $ | 1,165 |  |  | $ | 29 |  |  | $ | 1,194 |  |
| Income before income taxes | $ | 989 |  |  | $ | 50 |  |  | $ | 1,039 |  |  | $ | 714 |  |  | $ | 29 |  |  | $ | 743 |  |
| Income tax expense | $ | 148 |  |  | $ | 9 |  |  | $ | 157 |  |  | $ | 259 |  |  | $ | 2 |  |  | $ | 261 |  |
| Net income | $ | 841 |  |  | $ | 41 |  |  | $ | 882 |  |  | $ | 455 |  |  | $ | 27 |  |  | $ | 482 |  |
| Net income attributable to Dell Technologies Inc. | $ | 846 |  |  | $ | 41 |  |  | $ | 887 |  |  | $ | 462 |  |  | $ | 27 |  |  | $ | 489 |  |
| Earnings per share attributable to Dell Technologies Inc. |  |  |  |  |  |  |  |  |
| Basic | $ | 1.19 |  |  | $ | 0.06 |  |  | $ | 1.25 |  |  | $ | 0.64 |  |  | $ | 0.03 |  |  | $ | 0.67 |  |
| Diluted | $ | 1.17 |  |  | $ | 0.06 |  |  | $ | 1.23 |  |  | $ | 0.63 |  |  | $ | 0.03 |  |  | $ | 0.66 |  |
| Segment Information: |  |  |  |  |  |  |  |  |  |  |  |
| CSG operating income | $ | 767 |  |  | $ | 50 |  |  | $ | 817 |  |  | $ | 969 |  |  | $ | 29 |  |  | $ | 998 |  |
| Reportable segment operating income | $ | 2,051 |  |  | $ | 50 |  |  | $ | 2,101 |  |  | $ | 2,018 |  |  | $ | 29 |  |  | $ | 2,047 |  |
| Non-GAAP Financial Measures: |  |  |  |  |  |  |  |  |
| Non-GAAP gross margin | $ | 5,464 |  |  | $ | 50 |  |  | $ | 5,514 |  |  | $ | 5,536 |  |  | $ | 29 |  |  | $ | 5,565 |  |
| Non-GAAP operating income | $ | 2,034 |  |  | $ | 50 |  |  | $ | 2,084 |  |  | $ | 1,977 |  |  | $ | 29 |  |  | $ | 2,006 |  |
| Non-GAAP net income | $ | 1,371 |  |  | $ | 41 |  |  | $ | 1,412 |  |  | $ | 1,283 |  |  | $ | 27 |  |  | $ | 1,310 |  |
| Non-GAAP earnings per share attributable to Dell Technologies Inc. — diluted | $ | 1.89 |  |  | $ | 0.06 |  |  | $ | 1.95 |  |  | $ | 1.74 |  |  | $ | 0.04 |  |  | $ | 1.78 |  |

[0001571996-25-000014:8k_2_02:152]
____________________

[0001571996-25-000014:8k_2_02:153]
(1)    As reported amounts represent the originally reported amounts in the company’s Quarterly Reports on Form 10-Q for the three months ended August 2, 2024 and August 4, 2023.

[0001571996-25-000014:8k_2_02:154]
18

[0001571996-25-000014:8k_2_02:155]
DELL TECHNOLOGIES INC.

[0001571996-25-000014:8k_2_02:156]
Revision of Previously Issued Financial Results

[0001571996-25-000014:8k_2_02:157]
(in millions, except per share amounts; unaudited; continued)

[0001571996-25-000014:8k_2_02:158]
|  | Three Months Ended |
|  | November 1, 2024 |  | November 3, 2023 |
|  | As Reported1 |  | Adjustment |  | As Revised |  | As Reported1 |  | Adjustment |  | As Revised |
| Condensed Consolidated Statements of Income: |  |  |  |  |  |  |  |  |
| Cost of net revenue — Products | $ | 15,541 |  |  | $ | (53) |  |  | $ | 15,488 |  |  | $ | 13,546 |  |  | $ | (53) |  |  | $ | 13,493 |  |
| Total cost of net revenue | $ | 19,059 |  |  | $ | (53) |  |  | $ | 19,006 |  |  | $ | 17,103 |  |  | $ | (53) |  |  | $ | 17,050 |  |
| Gross margin | $ | 5,307 |  |  | $ | 53 |  |  | $ | 5,360 |  |  | $ | 5,148 |  |  | $ | 53 |  |  | $ | 5,201 |  |
| Operating income | $ | 1,668 |  |  | $ | 53 |  |  | $ | 1,721 |  |  | $ | 1,486 |  |  | $ | 53 |  |  | $ | 1,539 |  |
| Income before income taxes | $ | 1,392 |  |  | $ | 53 |  |  | $ | 1,445 |  |  | $ | 1,180 |  |  | $ | 53 |  |  | $ | 1,233 |  |
| Income tax expense | $ | 265 |  |  | $ | 10 |  |  | $ | 275 |  |  | $ | 176 |  |  | $ | 7 |  |  | $ | 183 |  |
| Net income | $ | 1,127 |  |  | $ | 43 |  |  | $ | 1,170 |  |  | $ | 1,004 |  |  | $ | 46 |  |  | $ | 1,050 |  |
| Net income attributable to Dell Technologies Inc. | $ | 1,132 |  |  | $ | 43 |  |  | $ | 1,175 |  |  | $ | 1,006 |  |  | $ | 46 |  |  | $ | 1,052 |  |
| Earnings per share attributable to Dell Technologies Inc. |  |  |  |  |  |  |  |  |
| Basic | $ | 1.61 |  |  | $ | 0.06 |  |  | $ | 1.67 |  |  | $ | 1.39 |  |  | $ | 0.07 |  |  | $ | 1.46 |  |
| Diluted | $ | 1.58 |  |  | $ | 0.06 |  |  | $ | 1.64 |  |  | $ | 1.36 |  |  | $ | 0.06 |  |  | $ | 1.42 |  |
| Segment Information: |  |  |  |  |  |  |  |  |  |  |  |
| CSG operating income | $ | 694 |  |  | $ | 53 |  |  | $ | 747 |  |  | $ | 925 |  |  | $ | 53 |  |  | $ | 978 |  |
| Reportable segment operating income | $ | 2,202 |  |  | $ | 53 |  |  | $ | 2,255 |  |  | $ | 1,994 |  |  | $ | 53 |  |  | $ | 2,047 |  |
| Non-GAAP Financial Measures: |  |  |  |  |  |  |  |  |
| Non-GAAP gross margin | $ | 5,437 |  |  | $ | 53 |  |  | $ | 5,490 |  |  | $ | 5,276 |  |  | $ | 53 |  |  | $ | 5,329 |  |
| Non-GAAP operating income | $ | 2,199 |  |  | $ | 53 |  |  | $ | 2,252 |  |  | $ | 1,964 |  |  | $ | 53 |  |  | $ | 2,017 |  |
| Non-GAAP net income | $ | 1,540 |  |  | $ | 43 |  |  | $ | 1,583 |  |  | $ | 1,389 |  |  | $ | 46 |  |  | $ | 1,435 |  |
| Non-GAAP earnings per share attributable to Dell Technologies Inc. — diluted | $ | 2.15 |  |  | $ | 0.06 |  |  | $ | 2.21 |  |  | $ | 1.88 |  |  | $ | 0.06 |  |  | $ | 1.94 |  |

[0001571996-25-000014:8k_2_02:159]
____________________

[0001571996-25-000014:8k_2_02:160]
(1)    As reported amounts represent the originally reported amounts in the company’s Quarterly Reports on Form 10-Q for the three months ended November 1, 2024 and November 3, 2023.

[0001571996-25-000014:8k_2_02:161]
19

[0001571996-25-000014:8k_2_02:162]
DELL TECHNOLOGIES INC.

[0001571996-25-000014:8k_2_02:163]
Revision of Previously Issued Financial Results

[0001571996-25-000014:8k_2_02:164]
(in millions, except per share amounts; unaudited; continued)

[0001571996-25-000014:8k_2_02:165]
|  | Three Months Ended |  | Fiscal Year Ended |
|  | February 2, 2024 |  | February 2, 2024 |
|  | As Reported1 |  | Adjustment |  | As Revised |  | As Reported1 |  | Adjustment |  | As Revised |
| Consolidated Statements of Income: |  |  |  |  |  |  |  |  |
| Cost of net revenue — Products | $ | 13,393 |  |  | $ | (56) |  |  | $ | 13,337 |  |  | $ | 53,316 |  |  | $ | (200) |  |  | $ | 53,116 |  |
| Total cost of net revenue | $ | 17,002 |  |  | $ | (56) |  |  | $ | 16,946 |  |  | $ | 67,556 |  |  | $ | (200) |  |  | $ | 67,356 |  |
| Gross margin | $ | 5,316 |  |  | $ | 56 |  |  | $ | 5,372 |  |  | $ | 20,869 |  |  | $ | 200 |  |  | $ | 21,069 |  |
| Operating income | $ | 1,491 |  |  | $ | 56 |  |  | $ | 1,547 |  |  | $ | 5,211 |  |  | $ | 200 |  |  | $ | 5,411 |  |
| Income before income taxes | $ | 1,288 |  |  | $ | 56 |  |  | $ | 1,344 |  |  | $ | 3,887 |  |  | $ | 200 |  |  | $ | 4,087 |  |
| Income tax expense | $ | 130 |  |  | $ | 6 |  |  | $ | 136 |  |  | $ | 692 |  |  | $ | 23 |  |  | $ | 715 |  |
| Net income | $ | 1,158 |  |  | $ | 50 |  |  | $ | 1,208 |  |  | $ | 3,195 |  |  | $ | 177 |  |  | $ | 3,372 |  |
| Net income attributable to Dell Technologies Inc. | $ | 1,160 |  |  | $ | 50 |  |  | $ | 1,210 |  |  | $ | 3,211 |  |  | $ | 177 |  |  | $ | 3,388 |  |
| Earnings per share attributable to Dell Technologies Inc. |  |  |  |  |  |  |  |  |
| Basic | $ | 1.63 |  |  | $ | 0.07 |  |  | $ | 1.70 |  |  | $ | 4.46 |  |  | $ | 0.25 |  |  | $ | 4.71 |  |
| Diluted | $ | 1.59 |  |  | $ | 0.07 |  |  | $ | 1.66 |  |  | $ | 4.36 |  |  | $ | 0.24 |  |  | $ | 4.60 |  |
| Segment Information: |  |  |  |  |  |  |  |  |  |  |  |
| CSG operating income | $ | 726 |  |  | $ | 56 |  |  | $ | 782 |  |  | $ | 3,512 |  |  | $ | 200 |  |  | $ | 3,712 |  |
| Reportable segment operating income | $ | 2,154 |  |  | $ | 56 |  |  | $ | 2,210 |  |  | $ | 7,798 |  |  | $ | 200 |  |  | $ | 7,998 |  |
| Non-GAAP Financial Measures: |  |  |  |  |  |  |  |  |
| Non-GAAP gross margin | $ | 5,468 |  |  | $ | 56 |  |  | $ | 5,524 |  |  | $ | 21,444 |  |  | $ | 200 |  |  | $ | 21,644 |  |
| Non-GAAP operating income | $ | 2,139 |  |  | $ | 56 |  |  | $ | 2,195 |  |  | $ | 7,678 |  |  | $ | 200 |  |  | $ | 7,878 |  |
| Non-GAAP net income | $ | 1,610 |  |  | $ | 50 |  |  | $ | 1,660 |  |  | $ | 5,245 |  |  | $ | 177 |  |  | $ | 5,422 |  |
| Non-GAAP earnings per share attributable to Dell Technologies Inc. — diluted | $ | 2.20 |  |  | $ | 0.07 |  |  | $ | 2.27 |  |  | $ | 7.13 |  |  | $ | 0.24 |  |  | $ | 7.37 |  |
| Consolidated Statements of Cash Flows: |  |  |  |  |  |  |  |  |  |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net income | $ | 1,158 |  |  | $ | 50 |  |  | $ | 1,208 |  |  | $ | 3,195 |  |  | $ | 177 |  |  | $ | 3,372 |  |
| Adjustments to reconcile net income to net cash provided by operating activities | $ | 375 |  |  | $ | (50) |  |  | $ | 325 |  |  | $ | 5,481 |  |  | $ | (177) |  |  | $ | 5,304 |  |

[0001571996-25-000014:8k_2_02:166]
_________________

[0001571996-25-000014:8k_2_02:167]
(1)    As reported amounts represent the originally reported amounts in the company’s press release furnished as Exhibit 99.1 to the company’s Form 8-K filed with the SEC on February 29, 2024, and in the company’s Annual Report on Form 10-K for the fiscal year ended February 2, 2024.

[0001571996-25-000014:8k_2_02:168]
DELL TECHNOLOGIES INC.

[0001571996-25-000014:8k_2_02:169]
Revision of Previously Issued Financial Results

[0001571996-25-000014:8k_2_02:170]
(in millions; unaudited; continued)

[0001571996-25-000014:8k_2_02:171]
|  | February 2, 2024 |
|  | As Reported1 |  | Adjustment |  | As Revised |
| Consolidated Statements of Financial Position: |  |  |  |  |  |
| Other current assets | $ | 10,973 |  |  | $ | 37 |  |  | $ | 11,010 |  |
| Total current assets | $ | 35,947 |  |  | $ | 37 |  |  | $ | 35,984 |  |
| Total assets | $ | 82,089 |  |  | $ | 37 |  |  | $ | 82,126 |  |
| Accounts payable | $ | 19,389 |  |  | $ | (163) |  |  | $ | 19,226 |  |
| Accrued and other | $ | 6,805 |  |  | $ | 23 |  |  | $ | 6,828 |  |
| Total current liabilities | $ | 48,494 |  |  | $ | (140) |  |  | $ | 48,354 |  |
| Total liabilities | $ | 84,398 |  |  | $ | (140) |  |  | $ | 84,258 |  |
| Accumulated deficit | $ | (4,630) |  |  | $ | 177 |  |  | $ | (4,453) |  |
| Total Dell Technologies Inc. stockholders' equity (deficit) | $ | (2,404) |  |  | $ | 177 |  |  | $ | (2,227) |  |
| Total stockholders' equity (deficit) | $ | (2,309) |  |  | $ | 177 |  |  | $ | (2,132) |  |
| Total liabilities and stockholders' equity | $ | 82,089 |  |  | $ | 37 |  |  | $ | 82,126 |  |

[0001571996-25-000014:8k_2_02:172]
_________________

[0001571996-25-000014:8k_2_02:173]
(1)    As reported amounts represent the originally reported amounts in the company’s Annual Report on Form 10-K for the fiscal year ended February 2, 2024.

[0001571996-25-000014:8k_2_02:174]
21

[0001571996-25-000014:8k_2_02:175]
DELL TECHNOLOGIES INC.

[0001571996-25-000014:8k_2_02:176]
Revision of Previously Issued Financial Results

[0001571996-25-000014:8k_2_02:177]
Reconciliation of Selected Non-GAAP Financial Measures

[0001571996-25-000014:8k_2_02:178]
(in millions, except per share amounts; unaudited)

[0001571996-25-000014:8k_2_02:179]
|  | Three Months Ended |
|  | November 1, 2024 |  | August 2, 2024 |  | May 3, 2024 |  | November 3, 2023 |  | August 4, 2023 |  | May 5, 2023 |
| Gross margin | $ | 5,360 |  |  | $ | 5,361 |  |  | $ | 4,851 |  |  | $ | 5,201 |  |  | $ | 5,416 |  |  | $ | 5,080 |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 60 |  |  | 59 |  |  | 60 |  |  | 84 |  |  | 84 |  |  | 79 |  |
| Stock-based compensation expense | 39 |  |  | 38 |  |  | 38 |  |  | 37 |  |  | 37 |  |  | 38 |  |
| Other corporate expenses | 31 |  |  | 56 |  |  | 43 |  |  | 7 |  |  | 28 |  |  | 29 |  |
| Non-GAAP gross margin | $ | 5,490 |  |  | $ | 5,514 |  |  | $ | 4,992 |  |  | $ | 5,329 |  |  | $ | 5,565 |  |  | $ | 5,226 |  |
| Operating income | $ | 1,721 |  |  | $ | 1,392 |  |  | $ | 965 |  |  | $ | 1,539 |  |  | $ | 1,194 |  |  | $ | 1,131 |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 168 |  |  | 168 |  |  | 168 |  |  | 207 |  |  | 213 |  |  | 203 |  |
| Stock-based compensation expense | 198 |  |  | 191 |  |  | 210 |  |  | 227 |  |  | 223 |  |  | 225 |  |
| Other corporate expenses | 165 |  |  | 333 |  |  | 176 |  |  | 44 |  |  | 376 |  |  | 101 |  |
| Non-GAAP operating income | $ | 2,252 |  |  | $ | 2,084 |  |  | $ | 1,519 |  |  | $ | 2,017 |  |  | $ | 2,006 |  |  | $ | 1,660 |  |
| Net income | $ | 1,170 |  |  | $ | 882 |  |  | $ | 992 |  |  | $ | 1,050 |  |  | $ | 482 |  |  | $ | 632 |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 168 |  |  | 168 |  |  | 168 |  |  | 207 |  |  | 213 |  |  | 203 |  |
| Stock-based compensation expense | 198 |  |  | 191 |  |  | 210 |  |  | 227 |  |  | 223 |  |  | 225 |  |
| Other corporate expenses | 166 |  |  | 329 |  |  | 170 |  |  | 36 |  |  | 432 |  |  | 98 |  |
| Fair value adjustments on equity investments | (46) |  |  | (5) |  |  | 30 |  |  | (8) |  |  | 29 |  |  | 15 |  |
| Aggregate adjustment for income taxes (a) | (73) |  |  | (153) |  |  | (611) |  |  | (77) |  |  | (69) |  |  | (156) |  |
| Non-GAAP net income | $ | 1,583 |  |  | $ | 1,412 |  |  | $ | 959 |  |  | $ | 1,435 |  |  | $ | 1,310 |  |  | $ | 1,017 |  |
| Earnings per share attributable to Dell Technologies Inc. — diluted | $ | 1.64 |  |  | $ | 1.23 |  |  | $ | 1.37 |  |  | $ | 1.42 |  |  | $ | 0.66 |  |  | $ | 0.86 |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 0.23 |  |  | 0.23 |  |  | 0.23 |  |  | 0.28 |  |  | 0.29 |  |  | 0.28 |  |
| Stock-based compensation expense | 0.28 |  |  | 0.26 |  |  | 0.29 |  |  | 0.31 |  |  | 0.30 |  |  | 0.30 |  |
| Other corporate expenses | 0.23 |  |  | 0.46 |  |  | 0.24 |  |  | 0.04 |  |  | 0.58 |  |  | 0.13 |  |
| Fair value adjustments on equity investments | (0.06) |  |  | (0.01) |  |  | 0.04 |  |  | (0.01) |  |  | 0.04 |  |  | 0.02 |  |
| Aggregate adjustment for income taxes (a) | (0.10) |  |  | (0.21) |  |  | (0.84) |  |  | (0.10) |  |  | (0.08) |  |  | (0.21) |  |
| Total non-GAAP adjustments attributable to non-controlling interests | (0.01) |  |  | (0.01) |  |  | (0.01) |  |  | — |  |  | (0.01) |  |  | — |  |
| Non-GAAP earnings per share attributable to Dell Technologies Inc. — diluted | $ | 2.21 |  |  | $ | 1.95 |  |  | $ | 1.32 |  |  | $ | 1.94 |  |  | $ | 1.78 |  |  | $ | 1.38 |  |

[0001571996-25-000014:8k_2_02:180]
____________________

[0001571996-25-000014:8k_2_02:181]
(a)    Beginning in fiscal 2025, the company’s non-GAAP income tax is calculated using a fixed estimated annual tax rate.
