# DELL notes — 0001571996-25-000034


## dei:DocumentsIncorporatedByReferenceTextBlock

[0001571996-25-000034:notes:1]
DOCUMENTS INCORPORATED BY REFERENCE

[0001571996-25-000034:notes:2]
The information required by Part III of this report, to the extent not set forth herein, is incorporated by reference from the registrant’s proxy statement relating to its annual meeting of stockholders to be held in 2025. The proxy statement will be filed with the Securities and Exchange Commission within 120 days after the end of the fiscal year to which this report relates.


## cyd:CybersecurityRiskManagementProcessesForAssessingIdentifyingAndManagingThreatsTextBlock

[0001571996-25-000034:notes:3]
We face numerous cybersecurity threats that range from cyber-attacks common to most industries to attacks from more advanced and persistent threat actors that target large information technology companies with products and services operating in strategic sectors. We could be adversely affected by cybersecurity incidents affecting our systems or the systems of our suppliers and other third-party service providers. To address these threats, we expend considerable resources on cybersecurity risk management, strategy, and governance.

[0001571996-25-000034:notes:4]
We assess, identify, and manage material cybersecurity risks in a number of ways. Our global security and resiliency organization, under the leadership of our Chief Security Officer (“CSO”), has established an internal governance structure to identify, assess, rate, and manage cybersecurity risks across the Company in an integrated manner. The security and resiliency organization advises each business unit and functional area on addressing cybersecurity risks and monitors initiatives to mitigate and manage such risks over time. Each business unit or functional area is responsible for managing risks and ensuring that security and resiliency policies and standards are implemented within the respective business unit or function. Compliance with our internal security and resiliency policies and standards is assessed by our internal audit team, which has a dedicated cybersecurity audit function.

[0001571996-25-000034:notes:5]
Our security and resiliency organization includes a dedicated cybersecurity function led by our Chief Information Security Officer (“CISO”). As part of our cybersecurity function, the cybersecurity and intelligence response team (“CSIRT”) administers a program to monitor, detect, investigate, respond to, and escalate management of internal and external cybersecurity threats and incidents. The CSIRT provides threat intelligence information to our CSO, broader security and resiliency organization, and relevant business units and functional areas.

[0001571996-25-000034:notes:6]
We also engage third parties in connection with our cybersecurity risk management processes, including cybersecurity consultants and auditors, to conduct evaluations of our security controls and provide certifications for industry-standard security frameworks, such as ISO27001 and SOC, Type 2.

[0001571996-25-000034:notes:7]
In addition to monitoring risks from threats to our own assets, we administer a third-party risk management program that helps identify and manage risks from cybersecurity threats arising from attacks against our suppliers and other service provider organizations. This program seeks to combine a methodology for risk ratings with targeted cybersecurity assessments, security-focused contractual requirements, and monitoring activities based on the risk profile of covered suppliers and service providers.

[0001571996-25-000034:notes:8]
Our CSO reports to our General Counsel and has principal executive responsibility and oversight for the Company’s strategy, planning, and operations on the management of both physical security and cybersecurity risk. Our CSO has extensive cybersecurity and program management experience and previously served in relevant leadership positions at another large multinational corporation and the U.S. Department of Defense. He is supported by our CISO, who has extensive cybersecurity experience in both the private and public sectors, and a team of cybersecurity professionals with relevant and expansive educational and industry experience.

[0001571996-25-000034:notes:9]
Cybersecurity risk management has been integrated into the Company’s overall enterprise risk management program (“ERM”) through the Company’s enterprise risk governing bodies, which are the Global Risk and Compliance Council (“GRCC”) and the Enterprise Risk Steering Committee (“ERSC”). Our CSO reports on cybersecurity risk to the GRCC and ERSC and also serves as a member of the ERSC. The CSO regularly meets with members of our executive leadership team to discuss cybersecurity risks, as well as related mitigation and remediation activities. In addition, information on cybersecurity risks is further integrated into our overall ERM through our central internal audit function, which incorporates such information in regular audits of our cybersecurity and data protection controls and processes.


## cyd:CybersecurityRiskBoardOfDirectorsOversightTextBlock

[0001571996-25-000034:notes:10]
Our Board of Directors oversees significant cybersecurity risks to the Company directly and through its Audit Committee. The Board of Directors meets with our CSO or his delegate annually to review significant cybersecurity risks as well as cybersecurity priorities and focus areas for the upcoming fiscal year. The Audit Committee meets with our CSO or his delegate quarterly to review significant cybersecurity incidents and risks, programmatic security modifications and enhancements, and progress made towards key cybersecurity initiatives and matters. The CSO may provide more frequent updates to the Board of Directors and Audit Committee if necessitated by a security incident or other developments. The Audit Committee reports regularly to our Board of Directors regarding the committee’s oversight of cybersecurity risk matters.


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0001571996-25-000034:notes:11]
Basis of Presentation — These Consolidated Financial Statements have been prepared in accordance with accounting principles generally accepted in the United States of America (“GAAP”).

[0001571996-25-000034:notes:12]
The Company’s fiscal year is the 52- or 53-week period ending on the Friday nearest January 31. The fiscal years ended January 31, 2025 and February 2, 2024 were 52-week periods. The fiscal year ended February 3, 2023 was a 53-week period.

[0001571996-25-000034:notes:13]
Revision of Previously Issued Financial Statements — During the fiscal year ended January 31, 2025, the Company discovered accumulated credits from certain suppliers that were not recorded or not recorded in the correct period in its previously reported financial results. The Company initiated an investigation that indicated that the credits resulted from the actions of certain procurement employees that support a limited number of suppliers, which affected the Client Solutions Group (“CSG”) segment. The revision did not have an impact on the Company’s net revenue.

[0001571996-25-000034:notes:14]
The Company determined that the impacts were not material, individually or in the aggregate, to its previously issued Consolidated Financial Statements and accompanying Notes to the Consolidated Financial Statements for any of the prior quarters or the annual period in which they occurred. However, in accordance with Staff Accounting Bulletin No. 108 of the Securities and Exchange Commission (“SEC”), the Company concluded that correcting the cumulative misstatement in the current period would be material to its results of operations for the fiscal year ended January 31, 2025. 
Accordingly, the Company has revised its previously issued Consolidated Financial Statements, as applicable, as of and for the fiscal year ended February 2, 2024.


## us-gaap:ScheduleOfErrorCorrectionsAndPriorPeriodAdjustmentsTextBlock

[0001571996-25-000034:notes:15]
A summary of the corrections to the impacted financial statement line items in these Consolidated Financial Statements is presented below.
Consolidated Statements of Financial Position

[0001571996-25-000034:notes:16]
|  | February 2, 2024 |
|  | As Reported |  | Adjustment |  | As Revised |
|  | (in millions) |
| Current assets: |  |  |  |  |  |
| Other current assets | $ | 10,973 |  |  | $ | 37 |  |  | $ | 11,010 |  |
| Total current assets | $ | 35,947 |  |  | $ | 37 |  |  | $ | 35,984 |  |
| Total assets | $ | 82,089 |  |  | $ | 37 |  |  | $ | 82,126 |  |
| Current liabilities: |  |  |  |  |  |
| Accounts payable | $ | 19,389 |  |  | $ | (163) |  |  | $ | 19,226 |  |
| Accrued and other | $ | 6,805 |  |  | $ | 23 |  |  | $ | 6,828 |  |
| Total current liabilities | $ | 48,494 |  |  | $ | (140) |  |  | $ | 48,354 |  |
| Total liabilities | $ | 84,398 |  |  | $ | (140) |  |  | $ | 84,258 |  |
| Stockholders' equity (deficit): |  |  |  |  |  |
| Accumulated deficit | $ | (4,630) |  |  | $ | 177 |  |  | $ | (4,453) |  |
| Total Dell Technologies Inc. stockholders' equity (deficit) | $ | (2,404) |  |  | $ | 177 |  |  | $ | (2,227) |  |
| Total stockholders' equity (deficit) | $ | (2,309) |  |  | $ | 177 |  |  | $ | (2,132) |  |
| Total liabilities and stockholders' equity | $ | 82,089 |  |  | $ | 37 |  |  | $ | 82,126 |  |

[0001571996-25-000034:notes:17]
Consolidated Statements of Income

[0001571996-25-000034:notes:18]
|  | Fiscal Year Ended |
|  | February 2, 2024 |
|  | As Reported |  | Adjustment |  | As Revised |
|  | (in millions, except per share amounts) |
| Cost of net revenue: |  |  |  |  |  |
| Products | $ | 53,316 |  |  | $ | (200) |  |  | $ | 53,116 |  |
| Total cost of net revenue | $ | 67,556 |  |  | $ | (200) |  |  | $ | 67,356 |  |
| Gross margin | $ | 20,869 |  |  | $ | 200 |  |  | $ | 21,069 |  |
| Operating income | $ | 5,211 |  |  | $ | 200 |  |  | $ | 5,411 |  |
| Income before income taxes | $ | 3,887 |  |  | $ | 200 |  |  | $ | 4,087 |  |
| Income tax expense | $ | 692 |  |  | $ | 23 |  |  | $ | 715 |  |
| Net income | $ | 3,195 |  |  | $ | 177 |  |  | $ | 3,372 |  |
| Net income attributable to Dell Technologies Inc. | $ | 3,211 |  |  | $ | 177 |  |  | $ | 3,388 |  |
| Earnings per share attributable to Dell Technologies Inc. |  |  |  |  |  |
| Basic | $ | 4.46 |  |  | $ | 0.25 |  |  | $ | 4.71 |  |
| Diluted | $ | 4.36 |  |  | $ | 0.24 |  |  | $ | 4.60 |  |

[0001571996-25-000034:notes:19]
Consolidated Statements of Comprehensive Income

[0001571996-25-000034:notes:20]
|  | Fiscal Year Ended |
|  | February 2, 2024 |
|  | As Reported |  | Adjustment |  | As Revised |
|  | (in millions) |
| Net income | $ | 3,195 |  |  | $ | 177 |  |  | $ | 3,372 |  |
| Comprehensive income, net of tax | $ | 3,396 |  |  | $ | 177 |  |  | $ | 3,573 |  |
| Comprehensive income attributable to Dell Technologies Inc. | $ | 3,412 |  |  | $ | 177 |  |  | $ | 3,589 |  |

[0001571996-25-000034:notes:21]
Consolidated Statements of Cash Flows

[0001571996-25-000034:notes:22]
|  | Fiscal Year Ended |
|  | February 2, 2024 |
|  | As Reported |  | Adjustment |  | As Revised |
|  | (in millions) |
| Cash flow from operations: |  |  |  |  |  |
| Net income | $ | 3,195 |  |  | $ | 177 |  |  | $ | 3,372 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |
| Other assets and liabilities | $ | (1,470) |  |  | $ | (14) |  |  | $ | (1,484) |  |
| Accounts payable | $ | (335) |  |  | $ | (163) |  |  | $ | (498) |  |

[0001571996-25-000034:notes:23]
A summary of the corrections to the affected financial statement line items in these Condensed Consolidated Financial Statements is presented below for each quarterly period.

[0001571996-25-000034:notes:24]
Condensed Consolidated Statements of Income

[0001571996-25-000034:notes:25]
|  | Three Months Ended |  | Three Months Ended |
|  | May 3, 2024 |  | May 5, 2023 |
|  | As Reported |  | Adjustment |  | As Revised |  | As Reported |  | Adjustment |  | As Revised |
|  | (in millions, except per share amounts) |
| Cost of net revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Products | $ | 13,766 |  |  | $ | (45) |  |  | $ | 13,721 |  |  | $ | 12,375 |  |  | $ | (62) |  |  | $ | 12,313 |  |
| Total cost of net revenue | $ | 17,438 |  |  | $ | (45) |  |  | $ | 17,393 |  |  | $ | 15,904 |  |  | $ | (62) |  |  | $ | 15,842 |  |
| Gross margin | $ | 4,806 |  |  | $ | 45 |  |  | $ | 4,851 |  |  | $ | 5,018 |  |  | $ | 62 |  |  | $ | 5,080 |  |
| Operating income | $ | 920 |  |  | $ | 45 |  |  | $ | 965 |  |  | $ | 1,069 |  |  | $ | 62 |  |  | $ | 1,131 |  |
| Income before income taxes | $ | 547 |  |  | $ | 45 |  |  | $ | 592 |  |  | $ | 705 |  |  | $ | 62 |  |  | $ | 767 |  |
| Income tax expense (benefit) | $ | (408) |  |  | $ | 8 |  |  | $ | (400) |  |  | $ | 127 |  |  | $ | 8 |  |  | $ | 135 |  |
| Net income | $ | 955 |  |  | $ | 37 |  |  | $ | 992 |  |  | $ | 578 |  |  | $ | 54 |  |  | $ | 632 |  |
| Net income attributable to Dell Technologies Inc. | $ | 960 |  |  | $ | 37 |  |  | $ | 997 |  |  | $ | 583 |  |  | $ | 54 |  |  | $ | 637 |  |
| Earnings per share attributable to Dell Technologies Inc. |  |  |  |  |  |  |  |  |
| Basic | $ | 1.36 |  |  | $ | 0.05 |  |  | $ | 1.41 |  |  | $ | 0.81 |  |  | $ | 0.07 |  |  | $ | 0.88 |  |
| Diluted | $ | 1.32 |  |  | $ | 0.05 |  |  | $ | 1.37 |  |  | $ | 0.79 |  |  | $ | 0.07 |  |  | $ | 0.86 |  |

[0001571996-25-000034:notes:26]
____________________

[0001571996-25-000034:notes:27]
(a)The Company’s Condensed Consolidated Statements of Comprehensive Income were also affected by the revised net income amounts for the periods presented above.

[0001571996-25-000034:notes:28]
|  | Three Months Ended |  | Three Months Ended |
|  | August 2, 2024 |  | August 4, 2023 |
|  | As Reported |  | Adjustment |  | As Revised |  | As Reported |  | Adjustment |  | As Revised |
|  | (in millions, except per share amounts) |
| Cost of net revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Products | $ | 16,079 |  |  | $ | (50) |  |  | $ | 16,029 |  |  | $ | 14,002 |  |  | $ | (29) |  |  | $ | 13,973 |  |
| Total cost of net revenue | $ | 19,715 |  |  | $ | (50) |  |  | $ | 19,665 |  |  | $ | 17,547 |  |  | $ | (29) |  |  | $ | 17,518 |  |
| Gross margin | $ | 5,311 |  |  | $ | 50 |  |  | $ | 5,361 |  |  | $ | 5,387 |  |  | $ | 29 |  |  | $ | 5,416 |  |
| Operating income | $ | 1,342 |  |  | $ | 50 |  |  | $ | 1,392 |  |  | $ | 1,165 |  |  | $ | 29 |  |  | $ | 1,194 |  |
| Income before income taxes | $ | 989 |  |  | $ | 50 |  |  | $ | 1,039 |  |  | $ | 714 |  |  | $ | 29 |  |  | $ | 743 |  |
| Income tax expense | $ | 148 |  |  | $ | 9 |  |  | $ | 157 |  |  | $ | 259 |  |  | $ | 2 |  |  | $ | 261 |  |
| Net income | $ | 841 |  |  | $ | 41 |  |  | $ | 882 |  |  | $ | 455 |  |  | $ | 27 |  |  | $ | 482 |  |
| Net income attributable to Dell Technologies Inc. | $ | 846 |  |  | $ | 41 |  |  | $ | 887 |  |  | $ | 462 |  |  | $ | 27 |  |  | $ | 489 |  |
| Earnings per share attributable to Dell Technologies Inc. |  |  |  |  |  |  |  |  |
| Basic | $ | 1.19 |  |  | $ | 0.06 |  |  | $ | 1.25 |  |  | $ | 0.64 |  |  | $ | 0.03 |  |  | $ | 0.67 |  |
| Diluted | $ | 1.17 |  |  | $ | 0.06 |  |  | $ | 1.23 |  |  | $ | 0.63 |  |  | $ | 0.03 |  |  | $ | 0.66 |  |

[0001571996-25-000034:notes:29]
|  | Three Months Ended |  | Three Months Ended |
|  | November 1, 2024 |  | November 3, 2023 |
|  | As Reported |  | Adjustment |  | As Revised |  | As Reported |  | Adjustment |  | As Revised |
|  | (in millions, except per share amounts) |
| Cost of net revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Products | $ | 15,541 |  |  | $ | (53) |  |  | $ | 15,488 |  |  | $ | 13,546 |  |  | $ | (53) |  |  | $ | 13,493 |  |
| Total cost of net revenue | $ | 19,059 |  |  | $ | (53) |  |  | $ | 19,006 |  |  | $ | 17,103 |  |  | $ | (53) |  |  | $ | 17,050 |  |
| Gross margin | $ | 5,307 |  |  | $ | 53 |  |  | $ | 5,360 |  |  | $ | 5,148 |  |  | $ | 53 |  |  | $ | 5,201 |  |
| Operating income | $ | 1,668 |  |  | $ | 53 |  |  | $ | 1,721 |  |  | $ | 1,486 |  |  | $ | 53 |  |  | $ | 1,539 |  |
| Income before income taxes | $ | 1,392 |  |  | $ | 53 |  |  | $ | 1,445 |  |  | $ | 1,180 |  |  | $ | 53 |  |  | $ | 1,233 |  |
| Income tax expense | $ | 265 |  |  | $ | 10 |  |  | $ | 275 |  |  | $ | 176 |  |  | $ | 7 |  |  | $ | 183 |  |
| Net income | $ | 1,127 |  |  | $ | 43 |  |  | $ | 1,170 |  |  | $ | 1,004 |  |  | $ | 46 |  |  | $ | 1,050 |  |
| Net income attributable to Dell Technologies Inc. | $ | 1,132 |  |  | $ | 43 |  |  | $ | 1,175 |  |  | $ | 1,006 |  |  | $ | 46 |  |  | $ | 1,052 |  |
| Earnings per share attributable to Dell Technologies Inc. |  |  |  |  |  |  |
| Basic | $ | 1.61 |  |  | $ | 0.06 |  |  | $ | 1.67 |  |  | $ | 1.39 |  |  | $ | 0.07 |  |  | $ | 1.46 |  |
| Diluted | $ | 1.58 |  |  | $ | 0.06 |  |  | $ | 1.64 |  |  | $ | 1.36 |  |  | $ | 0.06 |  |  | $ | 1.42 |  |

[0001571996-25-000034:notes:30]
|  | Three Months Ended |  |  |  |  |  |  |
|  | February 2, 2024 |  |  |  |  |  |  |
|  | As Reported |  | Adjustment |  | As Revised |  |  |  |  |  |  |
|  | (in millions, except per share amounts) |  |  |  |  |  |  |
| Cost of net revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Products | $ | 13,393 |  |  | $ | (56) |  |  | $ | 13,337 |  |  |  |  |  |  |  |
| Total cost of net revenue | $ | 17,002 |  |  | $ | (56) |  |  | $ | 16,946 |  |  |  |  |  |  |  |
| Gross margin | $ | 5,316 |  |  | $ | 56 |  |  | $ | 5,372 |  |  |  |  |  |  |  |
| Operating income | $ | 1,491 |  |  | $ | 56 |  |  | $ | 1,547 |  |  |  |  |  |  |  |
| Income before income taxes | $ | 1,288 |  |  | $ | 56 |  |  | $ | 1,344 |  |  |  |  |  |  |  |
| Income tax expense | $ | 130 |  |  | $ | 6 |  |  | $ | 136 |  |  |  |  |  |  |  |
| Net income | $ | 1,158 |  |  | $ | 50 |  |  | $ | 1,208 |  |  |  |  |  |  |  |
| Net income attributable to Dell Technologies Inc. | $ | 1,160 |  |  | $ | 50 |  |  | $ | 1,210 |  |  |  |  |  |  |  |
| Earnings per share attributable to Dell Technologies Inc. |  |  |  |  |  |  |  |  |  |  |  |
| Basic | $ | 1.63 |  |  | $ | 0.07 |  |  | $ | 1.70 |  |  |  |  |  |  |  |
| Diluted | $ | 1.59 |  |  | $ | 0.07 |  |  | $ | 1.66 |  |  |  |  |  |  |  |

[0001571996-25-000034:notes:31]
Condensed Consolidated Statements of Cash Flows

[0001571996-25-000034:notes:32]
|  | Three Months Ended |  | Six Months Ended |  | Nine Months Ended |
|  | May 3, 2024 |  | August 2, 2024 |  | November 1, 2024 |
|  | As Reported |  | Adjustment |  | As Revised |  | As Reported |  | Adjustment |  | As Revised |  | As Reported |  | Adjustment |  | As Revised |
|  | (in millions) |
| Cash flow from operations: |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income | $ | 955 |  |  | $ | 37 |  |  | $ | 992 |  |  | $ | 1,796 |  |  | $ | 78 |  |  | $ | 1,874 |  |  | $ | 2,923 |  |  | $ | 121 |  |  | $ | 3,044 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |
| Other assets and liabilities | $ | (592) |  |  | $ | (1) |  |  | $ | (593) |  |  | $ | 250 |  |  | $ | (3) |  |  | $ | 247 |  |  | $ | 2,147 |  |  | $ | (7) |  |  | $ | 2,140 |  |
| Accounts payable | $ | 1,241 |  |  | $ | (36) |  |  | $ | 1,205 |  |  | $ | 4,801 |  |  | $ | (75) |  |  | $ | 4,726 |  |  | $ | 4,089 |  |  | $ | (114) |  |  | $ | 3,975 |  |

[0001571996-25-000034:notes:33]
|  | Three Months Ended |  | Six Months Ended |  | Nine Months Ended |
|  | May 5, 2023 |  | August 4, 2023 |  | November 3, 2023 |
|  | As Reported |  | Adjustment |  | As Revised |  | As Reported |  | Adjustment |  | As Revised |  | As Reported |  | Adjustment |  | As Revised |
|  | (in millions) |
| Cash flow from operations: |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income | $ | 578 |  |  | $ | 54 |  |  | $ | 632 |  |  | $ | 1,033 |  |  | $ | 81 |  |  | $ | 1,114 |  |  | $ | 2,037 |  |  | $ | 127 |  |  | $ | 2,164 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |
| Other assets and liabilities | $ | (1,322) |  |  | $ | (11) |  |  | $ | (1,333) |  |  | $ | (2,248) |  |  | $ | (14) |  |  | $ | (2,262) |  |  | $ | (2,096) |  |  | $ | (13) |  |  | $ | (2,109) |  |
| Accounts payable | $ | (726) |  |  | $ | (43) |  |  | $ | (769) |  |  | $ | 1,427 |  |  | $ | (67) |  |  | $ | 1,360 |  |  | $ | 1,012 |  |  | $ | (114) |  |  | $ | 898 |  |


## us-gaap:ScheduleOfDisposalGroupsIncludingDiscontinuedOperationsIncomeStatementBalanceSheetAndAdditionalDisclosuresTextBlock

[0001571996-25-000034:notes:34]
The following table presents the major classes of assets and liabilities as of January 31, 2025 related to Secureworks, which were classified as held for sale as of the date indicated:

[0001571996-25-000034:notes:35]
|  | January 31, 2025 |
|  | (in millions) |
| ASSETS |
| Current assets: |  |
| Cash and cash equivalents | $ | 62 |  |
| Accounts receivable, net | 51 |  |
| Other current assets | 11 |  |
| Total current assets | 124 |  |
| Goodwill | 427 |  |
| Intangible assets, net | 63 |  |
| Other non-current assets | 54 |  |
| Total assets | $ | 668 |  |
| LIABILITIES |
| Current liabilities: |  |
| Accrued and other | $ | 71 |  |
| Short-term deferred revenue | 125 |  |
| Total current liabilities | 196 |  |
| Other non-current liabilities | 25 |  |
| Total liabilities | $ | 221 |  |


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock

[0001571996-25-000034:notes:36]
SUMMARY OF SIGNIFICANT ACCOUNTING POLICIES 
Principles of Consolidation — These Consolidated Financial Statements include the accounts of Dell Technologies and its wholly-owned subsidiaries, as well as the accounts of Secureworks, which, as indicated in Note 1 of the Notes to the Consolidated Financial Statements, was majority-owned by Dell Technologies as of January 31, 2025. All intercompany transactions have been eliminated.

[0001571996-25-000034:notes:37]
The Company also consolidates Variable Interest Entities ("VIEs") where it has been determined that the Company is the primary beneficiary of the applicable entities’ operations. For each VIE, the primary beneficiary is the party that has both the power to direct the activities that most significantly impact the VIE's economic performance and the obligation to absorb losses or the right to receive benefits of the VIE that could potentially be significant to such VIE. In evaluating whether the Company is the primary beneficiary of each entity, the Company evaluates its power to direct the most significant activities of the VIE by considering the purpose and design of each entity and the risks each entity was designed to create and pass through to its respective variable interest holders. The Company also evaluates its economic interests in each of the VIEs. See Note 5 of the Notes to the Consolidated Financial Statements for more information regarding consolidated VIEs.

[0001571996-25-000034:notes:38]
Use of Estimates — The preparation of financial statements in accordance with GAAP requires management to make estimates and assumptions that affect the amounts reported in the Consolidated Financial Statements and the accompanying Notes. Actual results could differ materially from those estimates.

[0001571996-25-000034:notes:39]
Cash and Cash Equivalents — All highly liquid investments with original maturities of 90 days or less at date of purchase are reported at fair value and are considered to be cash equivalents. Credit card receivables are classified as either cash and cash equivalents or receivables depending on the nature of the payment terms.

[0001571996-25-000034:notes:40]
Investments — The Company has strategic investments in equity and other securities as well as investments in fixed-income debt securities. All equity and other securities and long-term fixed income debt securities are recorded as long-term investments in the Consolidated Statements of Financial Position. Short-term fixed income debt securities are recorded as other current assets in the Consolidated Statements of Financial Position.

[0001571996-25-000034:notes:41]
Strategic investments in marketable equity and other securities are recorded at fair value based on quoted prices in active markets. Strategic investments in non-marketable equity and other securities without readily determinable fair values are recorded at cost, less impairment, and are adjusted for observable price changes. In evaluating equity investments without readily determinable fair values for impairment or observable price changes, the Company uses inputs that include pre- and post-money valuations of recent financing events and the impact of those events on its fully diluted ownership percentages, as well as other available information regarding the issuer’s historical and forecasted performance. Fair value measurements and impairments for strategic investments are recognized in interest and other, net in the Consolidated Statements of Income.

[0001571996-25-000034:notes:42]
Fixed-income debt securities are carried at amortized cost and approximate fair value. The Company intends to hold its fixed-income debt securities to maturity.

[0001571996-25-000034:notes:43]
Allowance for Expected Credit Losses on Accounts Receivable — The Company recognizes an allowance for losses on accounts receivable in an amount equal to the current expected credit losses. The estimation of the allowance is based on an analysis of historical loss experience, current receivables aging, and management’s assessment of current conditions and reasonable and supportable expectation of future conditions, as well as an assessment of specific identifiable customer accounts considered at risk or uncollectible. The Company assesses collectibility by pooling receivables where similar characteristics exist and evaluates receivables individually when specific customer balances no longer share those risk characteristics and are considered at risk or uncollectible. The expense associated with the allowance for expected credit losses is recognized in selling, general, and administrative expenses in the Consolidated Statements of Income.

[0001571996-25-000034:notes:44]
Accounting for Operating Leases as a Lessee — In its ordinary course of business, the Company enters into leases as a lessee for office buildings, warehouses, employee vehicles, and equipment. The Company determines if an arrangement is a lease or contains a lease at inception. The Company’s leases are generally classified as operating leases. The Company does not have any material finance leases. Operating leases result in the recognition of right of use (“ROU”) assets and lease liabilities on the Consolidated Statements of Financial Position. ROU assets represent the right to use an underlying asset for the lease term, and lease liabilities represent the obligation to make lease payments arising from the lease, measured on a discounted basis. At lease commencement, the lease liability is measured at the present value of the lease payments over the lease term. The operating lease ROU asset equals the lease liability adjusted for any initial direct costs, prepaid or deferred rent, and lease incentives. The Company uses the implicit rate when readily determinable. As most of the leases do not provide an implicit rate, the Company uses its incremental borrowing rate based on the information available at the commencement date to determine the present value of lease payments.

[0001571996-25-000034:notes:45]
The lease term may include options to extend or to terminate the lease that the Company is reasonably certain to exercise. The Company has elected not to record leases with an initial term of 12 months or less on the Consolidated Statements of Financial Position. Lease expense is recognized on a straight-line basis over the lease term in most instances. The Company does not generate material sublease income and has no material related party leases. The Company’s lease agreements do not contain any material residual value guarantees or material restrictive covenants.

[0001571996-25-000034:notes:46]
The Company’s office building agreements contain costs such as common area maintenance and other executory costs that may be either fixed or variable in nature. Variable lease costs are expensed as incurred. The Company combines lease and non-lease components, including fixed common area and other maintenance costs, in calculating the ROU assets and lease liabilities for its office buildings and employee vehicles. Under certain service agreements with third-party logistics providers, the Company directs the use of the inventory within the warehouses and, therefore, controls the assets. The warehouses and some of the equipment used are considered embedded leases. The Company accounts for the lease and non-lease components separately for its warehouses and equipment. The lease components consist of the warehouses and some of the equipment, such as conveyor belts. The non-lease components consist of services and other shared equipment, such as material handling and transportation. The Company allocates the consideration to the lease and non-lease components using their relative standalone values. See Note 6 of the Notes to the Consolidated Financial Statements for additional information.

[0001571996-25-000034:notes:47]
Accounting for Leases as a Lessor — The Company’s wholly-owned subsidiary Dell Financial Services and its affiliates (“DFS”) act as a lessor to provide equipment financing to customers through a variety of lease arrangements (“DFS leases”). The Company’s leases are classified as sales-type leases, direct financing leases, or operating leases. Direct financing leases are immaterial.

[0001571996-25-000034:notes:48]
The Company also offers alternative payment structures and as-a-Service offerings that are assessed to determine whether an embedded lease arrangement exists. The Company accounts for those contracts as a lease arrangement if it is determined that the contract contains an identified asset and that control of that asset has transferred to the customer.

[0001571996-25-000034:notes:49]
When a contract includes lease and non-lease components, the Company allocates consideration under the contract to each component based on relative standalone selling price and subsequently assesses lease classification for each lease component within a contract. DFS provides lessees with the option to extend the lease or purchase the underlying asset at the end of the lease term, which is considered when evaluating lease classification. In general, DFS lease arrangements do not have variable payment terms and are typically non-cancelable.

[0001571996-25-000034:notes:50]
On commencement of sales-type leases, the Company recognizes profit up-front, and amounts due from the customer under the lease contract are recognized as financing receivables on the Consolidated Statements of Financial Position. Interest income is recognized as net product revenue over the term of the lease based on the effective interest method. The Company has elected not to include sales and other taxes collected from the lessee as part of lease revenue.

[0001571996-25-000034:notes:51]
All other leases that do not meet the definition of a sales-type lease or direct financing lease are classified as operating leases. The underlying asset in an operating lease arrangement is carried at depreciated cost as “Assets in a customer contract” within Property, plant, and equipment, net on the Consolidated Statements of Financial Position. Depreciation is calculated using the straight-line method over the term of the underlying lease contract and is recognized as cost of net revenue. The depreciable basis is the original cost of the equipment less the estimated residual value of the equipment at the end of the lease term. The residual value is based upon estimates of the value of the equipment at the end of the lease term using historical studies, industry data, and future value-at-risk demand valuation methods. The Company recognizes operating lease income to product revenue generally on a straight-line basis over the lease term and expenses deferred initial direct costs on the same basis. The Company recognizes variable lease income to product revenue generally as earned. Impairment of assets in a customer contract is assessed on the same basis as other long-lived assets.

[0001571996-25-000034:notes:52]
Financing Receivables — Financing receivables are presented net of allowance for losses and consist of customer receivables and residual interest. Gross customer receivables include amounts due from customers under revolving loans, fixed-term loans, fixed-term sales-type or direct financing leases, and accrued interest. The Company has two portfolios, consisting of (i) fixed-term leases and loans and (ii) revolving loans, and assesses risk at the portfolio level to determine the appropriate allowance levels. The portfolio segments are further segregated into classes based on products, customer type, and credit risk evaluation. Fixed-term leases and loans are offered to qualified small and medium-sized businesses, large commercial accounts, governmental organizations, and educational entities. Fixed-term loans are also offered to qualified individual consumers. Revolving loans were primarily offered to small and medium-sized business customers, with the remaining offerings discontinued during the fiscal year ended January 31, 2025.

[0001571996-25-000034:notes:53]
The Company retains a residual interest in equipment leased under its fixed-term lease programs. The amount of the residual interest is established at the inception of the lease based upon estimates of the value of the equipment at the end of the lease term using historical studies, industry data, and future value-at-risk demand valuation methods.

[0001571996-25-000034:notes:54]
Allowance for Financing Receivable Losses — The Company recognizes an allowance for financing receivable losses, including both the lease receivable and unguaranteed residual, in an amount equal to the expected losses net of recoveries. The allowance for financing receivable losses on the lease receivable is determined based on various factors, including lifetime expected losses determined using macroeconomic forecast assumptions and management judgments applicable to and through the expected life of the portfolios as well as past due receivables, receivable type, and customer risk profile.

[0001571996-25-000034:notes:55]
Generally, expected credit losses as a result of residual value risk on equipment under lease are not considered to be significant primarily because of the existence of a secondary market with respect to the equipment. The Company’s lease agreements also generally define applicable return conditions and remedies for non-compliance to ensure that the leased equipment will be in good operating condition upon return. Model changes and updates, as well as market strength and product acceptance, are monitored and adjustments are made to residual values in accordance with the significance of any such changes.

[0001571996-25-000034:notes:56]
When an account is deemed to be uncollectible, customer account principal and interest are charged off to the allowance for losses. While the Company does not generally place financing receivables on non-accrual status during the delinquency period, accrued interest is included in the allowance for loss calculation and, therefore, the Company is adequately reserved in the event of charge off. Recoveries on receivables previously charged off as uncollectible are recorded to the allowance for financing receivable losses. The expense associated with the allowance for financing receivable losses is recognized as cost of net revenue.

[0001571996-25-000034:notes:57]
Asset Securitization — The Company transfers certain U.S. and European customer lease and loan payments and associated equipment to Special Purpose Entities (“SPEs”) that meet the definition of a Variable Interest Entity (“VIE”) and are consolidated into the Consolidated Financial Statements. These SPEs are bankruptcy-remote legal entities with separate assets and liabilities. The purpose of the SPEs is to facilitate the funding of customer lease and loan payments and associated equipment in the capital markets. Some of these SPEs have entered into financing arrangements with multi-seller conduits that, in turn, issue asset-backed debt securities in the capital markets. The asset securitizations in the SPEs are accounted for as secured borrowings.

[0001571996-25-000034:notes:58]
Inventories — The Company generally records inventory on the Consolidated Statements of Financial Position when legal title and risk of loss have passed to the Company for items that are held for sale in the ordinary course of business, that are in process of production for sale, or that will be consumed in the production of goods or services that will be held for sale.

[0001571996-25-000034:notes:59]
Inventories are stated at the lower of cost or net realizable value, with cost being determined on a first-in, first-out basis. Adjustments to reduce the cost of inventory to its net realizable value are made, if required, for estimated excess, obsolescence, or impaired balances. At the point of the loss recognition, a new, lower cost basis for that inventory is established, and subsequent changes in facts and circumstances do not result in the restoration or increase in the newly established cost basis.

[0001571996-25-000034:notes:60]
Property, Plant, and Equipment — Property, plant, and equipment are carried at depreciated cost. Depreciation is determined using the straight-line method over the shorter of the estimated useful lives of the assets or the lease term, as applicable. The estimated useful lives of the Company’s property, plant, and equipment are generally as follows:

[0001571996-25-000034:notes:61]
|  | Estimated Useful Life |
| Computer and other equipment | 3-5 years |
| Assets in a customer contract | Term of underlying lease contract |
| Buildings and building improvements | 10-30 years or term of underlying land lease |
| Leasehold improvements | 5 years or contract term |
| Internal use software | 5 years |

[0001571996-25-000034:notes:62]
Gains or losses related to retirements or dispositions of fixed assets are recognized in the period during which the retirement or disposition occurs.

[0001571996-25-000034:notes:63]
The Company capitalizes certain internal and external costs to acquire or create internal use software which are incurred subsequent to the completion of the preliminary project stage. Costs associated with maintenance and minor enhancements to the features and functionality of the Company’s internal use software are expensed as incurred.

[0001571996-25-000034:notes:64]
Capitalized Software Development Costs — Software development costs related to the development of new product offerings are capitalized subsequent to the establishment of technological feasibility, which is demonstrated by the completion of a detailed program design or working model, if no program design is completed. The Company amortizes capitalized software development costs on a straight-line basis over the estimated useful lives of the products, which is generally two years.

[0001571996-25-000034:notes:65]
As of January 31, 2025 and February 2, 2024, capitalized software development costs were $623 million and $646 million, respectively, and are included in other non-current assets, net in the accompanying Consolidated Statements of Financial Position. Amortization expense for the fiscal years ended January 31, 2025, February 2, 2024, and February 3, 2023 was $325 million, $416 million, and $317 million, respectively.

[0001571996-25-000034:notes:66]
Impairment of Long-Lived Assets — The Company reviews long-lived assets for impairment when events or changes in circumstances indicate that the carrying amount of an asset may not be recoverable. The Company assesses the recoverability of the asset based on the undiscounted future cash flows expected from the use and eventual disposition of the asset. If the carrying amount of the asset is determined not to be recoverable, a write-down to fair value is recorded. Fair values are determined based on quoted market values, discounted cash flows, or external appraisals, as applicable. Long-lived assets to be disposed of are reported at the lower of carrying amount or fair value less costs to sell.

[0001571996-25-000034:notes:67]
Intangible Assets Including Goodwill — Identifiable intangible assets with finite lives are amortized over their estimated useful lives. Indefinite-lived intangible assets are not amortized. Definite-lived intangible assets are reviewed for impairment when events and circumstances indicate the asset may be impaired. Goodwill and indefinite-lived intangible assets are tested for impairment annually during the third fiscal quarter and whenever events or circumstances indicate that an impairment may have occurred.

[0001571996-25-000034:notes:68]
Foreign Currency Translation — The majority of the Company’s international sales are made by international subsidiaries, some of which have the U.S. Dollar as their functional currency. The Company’s subsidiaries that do not use the U.S. Dollar as their functional currency translate assets and liabilities at current exchange rates in effect at the balance sheet date. Revenue and expenses from these international subsidiaries are translated using the monthly average exchange rates in effect for the period in which the activity was recognized. Foreign currency translation adjustments are included as a component of accumulated other comprehensive income (loss) (“AOCI”) in stockholders’ equity (deficit).

[0001571996-25-000034:notes:69]
Local currency transactions of international subsidiaries that have the U.S. Dollar as their functional currency are remeasured into U.S. Dollars using the current rates of exchange for monetary assets and liabilities and historical rates of exchange for nonmonetary assets and liabilities. Gains and losses from remeasurement of monetary assets and liabilities are included in interest and other, net on the Consolidated Statements of Income. See Note 20 of the Notes to the Consolidated Financial Statements for amounts recognized from remeasurement during the periods presented.

[0001571996-25-000034:notes:70]
Hedging Instruments — The Company uses derivative financial instruments, primarily forward contracts, options, and swaps, to hedge certain foreign currency and interest rate exposures. The relationships between hedging instruments and hedged items, as well as the risk management objectives and strategies for undertaking hedge transactions, are formally documented. The Company does not use derivatives for speculative purposes. All derivative instruments are recognized as either assets or liabilities in the Consolidated Statements of Financial Position and are measured at fair value. The Company’s hedge portfolio includes non-designated derivatives and derivatives designated as cash flow hedges and, from time to time, fair value hedges.

[0001571996-25-000034:notes:71]
For derivative instruments designated as a cash flow hedge, the Company assesses hedge effectiveness at the onset of the hedge, then performs qualitative assessments at regular intervals throughout the life of the derivative. The gain or loss on the hedge is recorded in AOCI, as a separate component of stockholders’ equity (deficit), and reclassified into earnings in the period during which the hedged transaction is recognized in earnings. For derivatives that are designated as a fair value hedge, the Company evaluates the effectiveness of the qualifying fair value hedge using the shortcut method of accounting under which hedges are assumed to be perfectly effective. The change in fair value of the hedge exactly offsets the fair value of the hedged item and there is no net impact recognized in earnings from the fair value of the derivative. For derivatives that are not designated as hedges or do not qualify for hedge accounting treatment, the Company recognizes the change in the instrument’s fair value in earnings as a component of interest and other, net.

[0001571996-25-000034:notes:72]
Cash flows from derivative instruments are presented in the same category on the Consolidated Statements of Cash Flows as the cash flows from the underlying hedged items. See Note 8 of the Notes to the Consolidated Financial Statements for a description of the Company’s derivative financial instrument activities.

[0001571996-25-000034:notes:73]
Revenue Recognition — The Company sells a wide portfolio of products and services to its customers. The Company’s agreements have varying requirements depending on the goods and services being sold, the rights and obligations conveyed, and the legal jurisdiction of the arrangement. While most of our agreements have standard terms and conditions, more complex agreements may contain nonstandard terms and conditions that require significant judgments in interpreting agreements to determine the appropriate accounting.

[0001571996-25-000034:notes:74]
Revenue is recognized for these arrangements based on the following five steps:

[0001571996-25-000034:notes:75]
(1)    Identify the contract with a customer. The Company evaluates facts and circumstances regarding sales transactions in order to identify contracts with its customers. An agreement must meet all of the following criteria to qualify as a contract eligible for revenue recognition under the model: (i) the contract must be approved by all parties who are committed to perform their respective obligations; (ii) each party’s rights regarding the goods and services to be transferred to the customer can be identified; (iii) the payment terms for the goods and services can be identified; (iv) the customer has the ability and intent to pay and it is probable that the Company will collect substantially all of the consideration to which it will be entitled; and (v) the contract must have commercial substance. Judgment is used in determining the customer’s ability and intent to pay, which is based upon various factors, including the customer’s historical payment experience or customer credit and financial information.

[0001571996-25-000034:notes:76]
(2)    Identify the performance obligations in the contract. The Company’s contracts with customers often include the promise to transfer multiple goods and services to the customer. Distinct promises within a contract are referred to as “performance obligations” and are accounted for as separate units of account. The Company assesses whether each promised good or service is distinct for the purpose of identifying the performance obligations in the contract. This assessment involves subjective determinations and requires management to make judgments about the individual promised goods or services and whether such goods or services are separable from the other aspects of the contractual relationship. Promised goods and services are considered distinct provided that: (i) the customer can benefit from the good or service either on its own or together with other resources that are readily available to the customer (that is, the good or service is capable of being distinct); and (ii) the Company’s promise to transfer the good or service to the customer is separately identifiable from other promises in the contract (that is, the promise to transfer the good or service is distinct within the context of the contract). The Company’s performance obligations include various distinct goods and services such as hardware, software licenses, support and maintenance agreements, and other service offerings and solutions. Promised goods and services are explicitly identified in the Company’s contracts and may be sold on a standalone basis or bundled as part of a combined solution. In certain hardware solutions, the hardware is highly interdependent on, and interrelated with, the embedded software. In these offerings, the hardware and software licenses are accounted for as a single performance obligation.

[0001571996-25-000034:notes:77]
(3)    Determine the transaction price. The transaction price reflects the amount of consideration to which the Company expects to be entitled in exchange for transferring goods or services to the customer. If the consideration promised in a contract includes a variable amount, the Company estimates the amount to which it expects to be entitled using either the expected value or most likely amount method. Generally, volume discounts, rebates, and sales returns reduce the transaction price. In determining the transaction price, the Company only includes amounts that are not subject to significant future reversal.

[0001571996-25-000034:notes:78]
(4)    Allocate the transaction price to performance obligations in the contract. When a contract includes multiple performance obligations, the transaction price is allocated to each performance obligation in an amount that depicts the consideration to which the Company expects to be entitled in exchange for transferring the promised goods or services. For contracts with multiple performance obligations, the transaction price is allocated in proportion to the standalone selling price (“SSP”) of each performance obligation.

[0001571996-25-000034:notes:79]
The best evidence of SSP is the observable price of a good or service when the Company sells that good or service separately in similar circumstances to similar customers. If a directly observable price is available, the Company will utilize that price for the SSP. If a directly observable price is not available, the SSP must be estimated. The Company estimates SSP by considering multiple factors, including, but not limited to, pricing practices, internal costs, and profit objectives as well as overall market conditions, which include geographic or regional specific factors, competitive positioning, and competitor actions.

[0001571996-25-000034:notes:80]
(5)    Recognize revenue when (or as) the performance obligation is satisfied. Revenue is recognized when obligations under the terms of the contract with the Company’s customer are satisfied. Revenue is recognized either over time or at a point in time, depending on when the underlying products or services are transferred to the customer. Revenue is recognized at a point in time for products upon transfer of control. Revenue is recognized over time for support and deployment services, software support, Software-as-a-Service (“SaaS”), and Infrastructure-as-a-Service (“IaaS”). Revenue is recognized either over time or at a point in time for professional services and training depending on the nature of the offering to the customer.

[0001571996-25-000034:notes:81]
The Company reports revenue net of any revenue-based taxes assessed by governmental authorities that are imposed on and concurrently with specific revenue-producing transactions.

[0001571996-25-000034:notes:82]
The Company has elected the following practical expedients:

[0001571996-25-000034:notes:83]
•The Company does not account for significant financing components if the period between revenue recognition and when the customer pays for the product or service will be one year or less.

[0001571996-25-000034:notes:84]
•The Company recognizes revenue equal to the amount it has a right to invoice when the amount corresponds directly with the value to the customer of the Company’s performance to date.

[0001571996-25-000034:notes:85]
•The Company does not account for shipping and handling activities as a separate performance obligation, but rather as an activity performed to transfer the promised good.

[0001571996-25-000034:notes:86]
The following summarizes the nature of revenue recognized and the manner in which the Company accounts for sales transactions.

[0001571996-25-000034:notes:87]
Products

[0001571996-25-000034:notes:88]
Product revenue consists of revenue from sales of hardware products, including notebooks and desktop PCs, servers, storage hardware, and other hardware-related devices, as well as revenue from software license sales, including non-essential software applications and third-party software licenses.

[0001571996-25-000034:notes:89]
Revenue from sales of hardware products is recognized when control has transferred to the customer, which typically occurs when the hardware has been shipped to the customer, risk of loss has transferred to the customer, the Company has a present right to payment, and customer acceptance has been satisfied. Customer acceptance is satisfied if acceptance is obtained from the customer, if all acceptance provisions lapse, or if the Company has evidence that all acceptance provisions will be, or have been, satisfied. Revenue from software license sales is generally recognized when control has transferred to the customer, which is typically upon shipment, electronic delivery, or when the software is available for download by the customer. For certain software arrangements in which the customer is granted a right to additional unspecified future software licenses, the Company’s promise to the customer is considered a stand-ready obligation in which the transfer of control and revenue recognition will occur over time.

[0001571996-25-000034:notes:90]
Services

[0001571996-25-000034:notes:91]
Services revenue consists of revenue from sales of support services, including hardware support that extends beyond the Company’s standard warranties, software maintenance, and installation; professional services; training; SaaS; and IaaS. Revenue associated with undelivered performance obligations is deferred and recognized when or as control is transferred to the customer. Revenue from fixed-price support or maintenance contracts sold for both hardware and software is recognized on a straight-line basis over the period of performance because the Company is required to provide services at any given time. Other services revenue is recognized when the Company performs the services and the customer receives and consumes the benefits.

[0001571996-25-000034:notes:92]
Other

[0001571996-25-000034:notes:93]
Revenue from leasing arrangements is not subject to the revenue standard for contracts with customers and remains separately accounted for under lease accounting guidance. The Company records operating lease rental revenue as product revenue on a straight-line basis over the lease term. The Company records revenue under sales-type leases as product revenue in an amount equal to the present value of minimum lease payments at the inception of the lease. Sales-type leases also produce financing income, which is included in product net revenue in the Consolidated Statements of Income and is recognized at effective rates of return over the lease term. The Company also offers qualified customers fixed-term loans as well as previously offered revolving lines of credit through DFS for the purchase of products and services offered by the Company. Financing income attributable to these loans is recognized in product net revenue on an accrual basis.

[0001571996-25-000034:notes:94]
Principal versus Agent — For transactions that involve a third party, the Company evaluates whether it is acting as the principal or the agent in the transaction. This determination requires significant judgment and impacts the amount and timing of revenue recognized. If the Company determines that it controls a good or service before it is transferred to the customer, the Company is acting as the principal and recognizes revenue at the gross amount of consideration it is entitled to from the customer. Indicators that the Company controls a good or service before transferring it to a customer include, but are not limited to, the Company being the primary obligor to the customer, establishing its own pricing, and having inventory and credit risks. Conversely, if the Company determines that it does not control the good or service before it is transferred to the customer, the Company is acting as an agent in the transaction. As an agent, the Company is arranging for the good or service to be provided by another party and recognizes revenue at the net amount of consideration retained.

[0001571996-25-000034:notes:95]
Disaggregation of Revenue — The Company’s revenue is presented on a disaggregated basis on the Consolidated Statements of Income and in Note 18 of the Notes to the Consolidated Financial Statements based on an evaluation of disclosures outside of the financial statements, information regularly provided to and reviewed by the Company’s chief operating decision maker for evaluating the financial performance of operating segments, and other information that is used to evaluate the Company’s financial performance and make resource allocations. This information includes revenue from products and services, revenue from reportable segments, and revenue by major product categories within the segments.

[0001571996-25-000034:notes:96]
Contract Assets — Contract assets are rights to consideration in exchange for goods or services that the Company has transferred to a customer when such a right is conditional on criteria other than the passage of time. Such amounts are immaterial as of January 31, 2025 and February 2, 2024.

[0001571996-25-000034:notes:97]
Contract Liabilities — Contract liabilities primarily consist of deferred revenue. Deferred revenue is recorded when the Company has invoiced or payments have been received for undelivered products or services, or in situations where revenue recognition criteria have not been met. Deferred revenue primarily includes amounts received in advance for extended warranty services and software maintenance. Revenue is recognized on these items when the revenue recognition criteria are met, generally resulting in ratable recognition over the contract term. The Company also has deferred revenue related to undelivered hardware and professional services, consisting of installations and consulting engagements, which are recognized when the Company’s performance obligations under the contract are completed. See Note 10 of the Notes to the Consolidated Financial Statements for additional information about deferred revenue.

[0001571996-25-000034:notes:98]
Deferred Costs — Deferred costs primarily consist of costs incurred to fulfill or obtain a contract and are included within other current assets and other non-current assets on the Consolidated Statements of Financial Position, based on when the expense is expected to be recognized.

[0001571996-25-000034:notes:99]
Costs incurred to fulfill revenue-generating contracts are mainly associated with third-party software support and maintenance offerings and VMware Resale offerings discussed in Note 18 and Note 19 of the Notes to the Consolidated Financial Statements. The Company defers and subsequently amortizes these charges on a straight-line basis over the life of the contract or the average contract duration. Amortization expense is included in cost of net revenue in the Consolidated Statements of Income. Deferred costs to fulfill revenue-generating contracts as of January 31, 2025 and February 2, 2024 were $4.8 billion and $7.7 billion, respectively. Amortization of deferred costs to fulfill revenue-generating contracts during the fiscal years ended January 31, 2025, February 2, 2024, and February 3, 2023 was $7.6 billion, $8.0 billion, and $7.3 billion, respectively.

[0001571996-25-000034:notes:100]
The Company capitalizes incremental direct costs to obtain a contract, primarily sales commissions and employer taxes related to commission payments, if the costs are deemed to be recoverable. The Company has elected, as a practical expedient, to expense as incurred costs to obtain a contract equal to or less than one year in duration. Capitalized costs are deferred and amortized over the period of contract performance or the estimated life of the customer relationship, if renewals are expected, and are typically amortized over an average period of one to five years. Amortization expense is recognized on a straight-line basis and included in selling, general, and administrative expenses in the Consolidated Statements of Income. Deferred costs to obtain a contract as of January 31, 2025 and February 2, 2024 were $540 million and $674 million, respectively. Amortization of costs to obtain a contract during the fiscal years ended January 31, 2025, February 2, 2024, and February 3, 2023 was $346 million, $383 million, and $390 million, respectively.

[0001571996-25-000034:notes:101]
The Company periodically reviews these deferred costs to determine whether events or changes in circumstances have occurred that could impact the carrying value or period of benefit of the costs to fulfill or costs to obtain a contract. There were no material impairment losses for deferred costs during the fiscal years ended January 31, 2025, February 2, 2024, and February 3, 2023.

[0001571996-25-000034:notes:102]
Standard Warranty Liabilities — The Company records warranty liabilities for estimated costs of fulfilling its obligations under standard limited hardware and software warranties at the time of sale. The liabilities for standard warranties are included in accrued and other and in other non-current liabilities in the Consolidated Statements of Financial Position. The specific warranty terms and conditions vary depending upon the product sold and the country in which the Company does business, but generally include technical support, parts, and labor over a period ranging from one to three years. Factors that affect the Company’s warranty liabilities include the number of installed units currently under warranty, historical and anticipated rates of warranty claims on those units, and cost per claim to satisfy the Company’s warranty obligation. The anticipated rate of warranty claims is the primary estimate used in determining the warranty liability and is relatively predictable using historical experience of failure rates. The average remaining aggregate warranty period of the covered installed base is approximately 17 months, repair parts are generally already in stock or available at pre-determined prices, and labor rates are generally arranged at preestablished amounts with service providers. If actual results differ from the estimates, the Company revises its estimated warranty liability. Each quarter, the Company reevaluates its estimates to assess the adequacy of its recorded warranty liabilities and adjusts the amounts as necessary. See Note 20 of the Notes to the Consolidated Financial Statements for additional information about standard warranty liabilities.

[0001571996-25-000034:notes:103]
Consideration Received from Vendors — The Company may receive consideration from vendors in the normal course of business. Certain of these funds received as consideration are rebates of purchase price paid and others are related to reimbursement of costs incurred by the Company to sell the vendor’s products. The Company recognizes a reduction to cost of net revenue if the funds are determined to be a reduction of the price of the vendor’s products. If the consideration is a reimbursement of costs incurred by the Company to sell or develop the vendor’s products, the consideration is classified as a reduction of such costs, most often operating expenses, in the Consolidated Statements of Income. In order to be recognized as a reduction of operating expenses, the reimbursement must be for a specific, incremental, and identifiable cost incurred by the Company in selling the vendor’s products or services.

[0001571996-25-000034:notes:104]
Loss Contingencies — The Company is subject to the possibility of various losses arising in the ordinary course of business. In determining loss contingencies, the Company considers the likelihood of loss or impairment of an asset or the incurrence of a liability, as well as the Company’s ability to reasonably estimate the amount of loss. An estimated loss contingency is accrued when it is probable that an asset has been impaired or a liability has been incurred and the amount of loss can be reasonably estimated. The Company regularly evaluates current information available to determine whether such accruals should be adjusted and whether new accruals are required.

[0001571996-25-000034:notes:105]
Shipping Costs — The Company’s shipping and handling costs are included in cost of net revenue in the Consolidated Statements of Income.

[0001571996-25-000034:notes:106]
Selling, General, and Administrative — Selling expenses include items such as sales salaries and commissions, marketing and advertising costs, and contractor services. Advertising costs are generally expensed as incurred in selling, general, and administrative expenses in the Consolidated Statements of Income. For the fiscal years ended January 31, 2025, February 2, 2024, and February 3, 2023, advertising expenses were $0.8 billion, $0.9 billion, and $1.1 billion, respectively. General and administrative expenses include items for the Company’s administrative functions, such as finance, legal, human resources, and information technology support. These functions include costs for items such as salaries and benefits and other personnel-related costs, maintenance and supplies, outside services, intangible asset amortization, and depreciation expense.

[0001571996-25-000034:notes:107]
Research and Development — Research and development (“R&D”) costs are primarily expensed as incurred. As noted in Capitalized Software Development Costs in this Note, qualifying software development costs are capitalized and amortized over time. R&D costs include salaries and benefits and other personnel-related costs associated with product development. Also included in R&D expenses are infrastructure costs, which consist of equipment and material costs, facilities-related costs, and depreciation expense.

[0001571996-25-000034:notes:108]
Income Taxes — The Company calculates a provision for income taxes using the asset and liability method, under which deferred tax assets and liabilities are recognized by identifying the temporary differences arising from the different treatment of items for tax and accounting purposes. Deferred tax assets and liabilities are recorded using enacted tax rates in effect for the year in which the differences are expected to reverse. The Company accounts for the tax impact of including Global Intangible Low-Taxed Income (GILTI) in U.S. taxable income as a period cost. The Company provides valuation allowances for deferred tax assets, where appropriate. In assessing the need for a valuation allowance, the Company considers all available evidence for each jurisdiction, including past operating results, estimates of future taxable income, and the feasibility of ongoing tax planning strategies. In the event the Company determines that all or part of the net deferred tax assets are not realizable in the future, the Company will make an adjustment to the valuation allowance that will be charged to earnings in the period in which such a determination is made.

[0001571996-25-000034:notes:109]
The accounting guidance for uncertainties in income tax prescribes a comprehensive model for the financial statement recognition, measurement, presentation, and disclosure of uncertain tax positions taken or expected to be taken in income tax returns. The Company recognizes a tax benefit from an uncertain tax position in the financial statements only when it is more likely than not that the position will be sustained upon examination, including resolution of any related appeals or litigation processes, based on the technical merits and a consideration of the relevant taxing authority’s administrative practices and precedents.

[0001571996-25-000034:notes:110]
Stock-Based Compensation — The Company measures stock-based compensation expense for all share-based awards granted based on the estimated fair value of those awards at grant date. To estimate the fair value of performance-based awards containing a market condition, the Company uses the Monte Carlo valuation model. The fair value of other share-based awards is generally based on the closing price of the Class C Common Stock as reported on the New York Stock Exchange (“NYSE”) on the date of grant.

[0001571996-25-000034:notes:111]
The compensation cost of service-based stock options, restricted stock, and restricted stock units is recognized net of any estimated forfeitures on a straight-line basis over the employee requisite service period. Compensation cost for performance-based awards is recognized on a graded accelerated basis net of estimated forfeitures over the requisite service period. Forfeiture rates are estimated at grant date based on historical experience and adjusted in subsequent periods for differences in actual forfeitures from those estimates.

[0001571996-25-000034:notes:112]
Recently Issued Accounting Pronouncements

[0001571996-25-000034:notes:113]
Expense Disaggregation Disclosures — In November 2024, the Financial Accounting Standards Board (“FASB”) issued guidance to improve disclosures about a public entity’s expenses by requiring disclosure of additional information about the types of expenses commonly presented in the financial statement on an annual and interim basis. Public entities must adopt the new guidance for fiscal years beginning after December 15, 2026, with early adoption permitted. Upon adoption, the guidance can be applied prospectively or retrospectively. Adoption of this new guidance will result in increased disclosures in the Notes to the Consolidated Financial Statements.

[0001571996-25-000034:notes:114]
Income Taxes — In December 2023, the FASB issued guidance which requires companies to provide disaggregated income tax disclosures within the income tax rate reconciliation and income taxes paid. Public entities must adopt the new guidance for fiscal years beginning after December 15, 2024, with early adoption permitted. The Company will adopt the guidance prospectively. Adoption of this new guidance will result in increased disclosures in the Notes to the Consolidated Financial Statements.

[0001571996-25-000034:notes:115]
Recently Adopted Accounting Pronouncements

[0001571996-25-000034:notes:116]
Segment Reporting — In November 2023, the FASB issued guidance to improve disclosures about a public entity’s reportable segments by requiring disclosure of additional information about a reportable segment’s expenses on an annual and interim basis. The Company adopted this standard as of January 31, 2025 on a retrospective basis. Adoption of this new guidance resulted in increased disclosures on reportable segments in Note 18 of the Notes to the Consolidated Financial Statements.


## us-gaap:CreditLossFinancialInstrumentPolicyTextBlock

[0001571996-25-000034:notes:117]
Generally, expected credit losses as a result of residual value risk on equipment under lease are not considered to be significant primarily because of the existence of a secondary market with respect to the equipment. The Company’s lease agreements also generally define applicable return conditions and remedies for non-compliance to ensure that the leased equipment will be in good operating condition upon return. Model changes and updates, as well as market strength and product acceptance, are monitored and adjustments are made to residual values in accordance with the significance of any such changes.
When an account is deemed to be uncollectible, customer account principal and interest are charged off to the allowance for losses. While the Company does not generally place financing receivables on non-accrual status during the delinquency period, accrued interest is included in the allowance for loss calculation and, therefore, the Company is adequately reserved in the event of charge off. Recoveries on receivables previously charged off as uncollectible are recorded to the allowance for financing receivable losses. The expense associated with the allowance for financing receivable losses is recognized as cost of net revenue.


## us-gaap:FairValueDisclosuresTextBlock

[0001571996-25-000034:notes:118]
FAIR VALUE MEASUREMENTS
The following table presents the Company’s hierarchy for its assets and liabilities measured at fair value on a recurring basis as of the dates indicated:

[0001571996-25-000034:notes:119]
|  | January 31, 2025 |  | February 2, 2024 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | Quoted Prices in Active Markets for Identical Assets |  | Significant Other Observable Inputs |  | Significant Unobservable Inputs |  |  |  | Quoted Prices in Active Markets for Identical Assets |  | Significant Other Observable Inputs |  | Significant Unobservable Inputs |  |  |
|  | (in millions) |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | $ | 571 |  |  | $ | — |  |  | $ | — |  |  | $ | 571 |  |  | $ | 3,170 |  |  | $ | — |  |  | $ | — |  |  | $ | 3,170 |  |
| Marketable equity and other securities | 8 |  |  | — |  |  | — |  |  | 8 |  |  | 10 |  |  | — |  |  | — |  |  | 10 |  |
| Derivative instruments | — |  |  | 302 |  |  | — |  |  | 302 |  |  | — |  |  | 104 |  |  | — |  |  | 104 |  |
| Total assets | $ | 579 |  |  | $ | 302 |  |  | $ | — |  |  | $ | 881 |  |  | $ | 3,180 |  |  | $ | 104 |  |  | $ | — |  |  | $ | 3,284 |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Derivative instruments | $ | — |  |  | $ | 75 |  |  | $ | — |  |  | $ | 75 |  |  | $ | — |  |  | $ | 84 |  |  | $ | — |  |  | $ | 84 |  |
| Total liabilities | $ | — |  |  | $ | 75 |  |  | $ | — |  |  | $ | 75 |  |  | $ | — |  |  | $ | 84 |  |  | $ | — |  |  | $ | 84 |  |

[0001571996-25-000034:notes:120]
The following section describes the valuation methodologies the Company uses to measure financial instruments at fair value.

[0001571996-25-000034:notes:121]
Money Market Funds — The Company’s investment in money market funds that are classified as cash equivalents hold underlying investments with a weighted average maturity of 90 days or less and are recognized at fair value. The valuations of these securities are based on quoted prices for identical assets in active markets, when available, or pricing models whereby all significant inputs are observable, can be derived from, or can be corroborated by, observable market data. The Company reviews security pricing and assesses money market fund liquidity on a quarterly basis. As of January 31, 2025, the Company’s portfolio had no material exposure to money market funds with a fluctuating net asset value.

[0001571996-25-000034:notes:122]
Marketable Equity and Other Securities — The Company’s investments in equity and other securities that are measured at fair value on a recurring basis consist of strategic investments in publicly-traded companies. The valuation of these securities is based on quoted prices in active markets.

[0001571996-25-000034:notes:123]
Derivative Instruments — The Company’s derivative financial instruments consist primarily of foreign currency forward and purchased option contracts and interest rate swaps. The fair value of the portfolio is determined using valuation models based on market observable inputs, including interest rate curves, forward and spot prices for currencies, and implied volatilities. Credit risk is also factored into the fair value calculation of the Company’s derivative financial instrument portfolio. See Note 8 of the Notes to the Consolidated Financial Statements for a description of the Company’s derivative financial instrument activities.

[0001571996-25-000034:notes:124]
Deferred Compensation Plans — The Company offers deferred compensation plans for eligible employees which allow participants to defer a portion of their compensation. Assets and liabilities associated with the plans are measured at fair value using Level 1 inputs. Assets were the same as liabilities associated with the plans at approximately $244 million and $214 million as of January 31, 2025 and February 2, 2024, respectively, and are included in other assets and other liabilities on the Consolidated Statements of Financial Position. The net impact on the Consolidated Statements of Income is not material since changes in the fair value of the assets substantially offset changes in the fair value of the liabilities. As such, assets and liabilities associated with these plans have not been included in the recurring fair value table above.

[0001571996-25-000034:notes:125]
Assets and Liabilities Measured at Fair Value on a Nonrecurring Basis — Certain assets are measured at fair value on a nonrecurring basis and therefore are not included in the recurring fair value table above. These assets consist primarily of financial assets such as the Company’s fixed income debt securities and strategic investments in non-marketable equity and other securities and non-financial assets such as goodwill and intangible assets.

[0001571996-25-000034:notes:126]
Fixed income debt securities are recorded at amortized cost and approximate fair value. The fair value of fixed income debt securities is determined based on observable market prices in a less active market or based on valuation methodologies using observable inputs. If measured at fair value in the Consolidated Statements of Financial Position, these securities would generally be classified as Level 2 in the fair value hierarchy. See Note 4 of the Notes to the Consolidated Financial Statements for additional information about the Company’s fixed income debt securities.

[0001571996-25-000034:notes:127]
Strategic investments in non-marketable equity and other securities and certain non-financial assets such as goodwill and intangibles are measured at fair value only if they are deemed to be impaired or when there is an adjustment from observable price changes in the current period. If measured at fair value in the Consolidated Statements of Financial Position, these securities would generally be classified as Level 3 in the fair value hierarchy. See Note 4 and Note 9 of the Notes to the Consolidated Financial Statements for additional information about the Company’s investments and goodwill and intangible assets, respectively.

[0001571996-25-000034:notes:128]
Carrying Value and Estimated Fair Value of Outstanding Debt — The following table presents the carrying value and estimated fair value of the Company’s outstanding debt as described in Note 7 of the Notes to the Consolidated Financial Statements, including the current portion, as of the dates indicated:

[0001571996-25-000034:notes:129]
|  | January 31, 2025 |  | February 2, 2024 |
|  | Carrying Value |  | Fair Value |  | Carrying Value |  | Fair Value |
|  | (in billions) |
| Senior Notes | $ | 15.0 |  |  | $ | 15.0 |  |  | $ | 15.5 |  |  | $ | 15.8 |  |
| Legacy Notes | $ | 0.9 |  |  | $ | 1.0 |  |  | $ | 0.9 |  |  | $ | 1.0 |  |
| DFS Debt | $ | 8.7 |  |  | $ | 8.5 |  |  | $ | 9.5 |  |  | $ | 9.1 |  |

[0001571996-25-000034:notes:130]
The fair values of the outstanding debt shown in the table above were determined based on observable market prices in a less active market or based on valuation methodologies using observable inputs and were categorized as Level 2 in the fair value hierarchy.


## us-gaap:InvestmentTextBlock

[0001571996-25-000034:notes:131]
INVESTMENTS
The Company has strategic investments in equity and other securities as well as investments in fixed income debt securities. All equity and other securities as well as long-term fixed income debt securities are recorded as long-term investments while short-term fixed income debt securities are recorded as other current assets in the Consolidated Statements of Financial Position.

[0001571996-25-000034:notes:132]
As of January 31, 2025 and February 2, 2024, total investments were $1.5 billion and $1.6 billion, respectively.

[0001571996-25-000034:notes:133]
Equity and Other Securities

[0001571996-25-000034:notes:134]
Equity and other securities include strategic investments in marketable and non-marketable securities. Investments in marketable securities are measured at fair value on a recurring basis. Investments in non-marketable equity and other securities represent primarily early-stage companies without readily determinable fair values. The Company has elected to apply the measurement alternative for non-marketable securities. Under the alternative, the Company measures investments without readily determinable fair values at cost, less impairment, adjusted for observable price changes. The Company makes a separate election to use the alternative for each eligible investment and is required to reassess at each reporting period whether an investment qualifies for the alternative. In evaluating these investments for impairment or observable price changes, the Company uses inputs including pre- and post-money valuations of recent financing events and the impact of those events on its fully diluted ownership percentages, as well as other available information regarding the issuer’s historical and forecasted performance.

[0001571996-25-000034:notes:135]
Carrying Value of Equity and Other Securities

[0001571996-25-000034:notes:136]
The following table presents the cost, cumulative unrealized gain, cumulative unrealized loss, and carrying value of the Company's strategic investments in marketable and non-marketable equity and other securities as of the dates indicated:

[0001571996-25-000034:notes:137]
|  | January 31, 2025 |  | February 2, 2024 |
|  | Cost |  | Unrealized Gain |  | Unrealized Loss |  | Carrying Value |  | Cost |  | Unrealized Gain |  | Unrealized Loss |  | Carrying Value |
|  | (in millions) |
| Marketable | $ | 11 |  |  | $ | 24 |  |  | $ | (27) |  |  | $ | 8 |  |  | $ | 12 |  |  | $ | 24 |  |  | $ | (26) |  |  | $ | 10 |  |
| Non-marketable | 739 |  |  | 1,009 |  |  | (261) |  |  | 1,487 |  |  | 732 |  |  | 1,015 |  |  | (454) |  |  | 1,293 |  |
| Total equity and other securities | $ | 750 |  |  | $ | 1,033 |  |  | $ | (288) |  |  | $ | 1,495 |  |  | $ | 744 |  |  | $ | 1,039 |  |  | $ | (480) |  |  | $ | 1,303 |  |

[0001571996-25-000034:notes:138]
Gains and Losses on Equity and Other Securities

[0001571996-25-000034:notes:139]
The following table presents unrealized gains and losses on marketable and non-marketable equity and other securities for the periods indicated:

[0001571996-25-000034:notes:140]
|  |  |  | Fiscal Year Ended |
|  |  |  |  |  | January 31, 2025 |  | February 2, 2024 |  | February 3, 2023 |
|  |  |  |  |  | (in millions) |
| Marketable securities: |  |  |  |  |  |  |  |  |  |
| Unrealized gain |  |  |  |  | $ | 5 |  |  | $ | 6 |  |  | $ | 57 |  |
| Unrealized loss |  |  |  |  | (6) |  |  | (24) |  |  | (47) |  |
| Net unrealized gain (loss) |  |  |  |  | (1) |  |  | (18) |  |  | 10 |  |
| Non-marketable securities: |  |  |  |  |  |  |  |  |  |
| Unrealized gain |  |  |  |  | 154 |  |  | 84 |  |  | 90 |  |
| Unrealized loss |  |  |  |  | (32) |  |  | (49) |  |  | (349) |  |
| Net unrealized gain (loss) (a) (b) |  |  |  |  | 122 |  |  | 35 |  |  | (259) |  |
| Net unrealized gain (loss) on equity and other securities |  |  |  |  | $ | 121 |  |  | $ | 17 |  |  | $ | (249) |  |

[0001571996-25-000034:notes:141]
(a)For the fiscal year ended January 31, 2025 and February 2, 2024, net unrealized gains on non-marketable securities were due to upward adjustments for observable price changes offset by losses primarily attributable to downward adjustments for observable price changes and impairments.

[0001571996-25-000034:notes:142]
(b)For the fiscal year ended February 3, 2023, net unrealized losses on non-marketable securities were primarily attributable to the recognition of impairments which were generally in line with extended public equity market declines.

[0001571996-25-000034:notes:143]
Fixed Income Debt Securities

[0001571996-25-000034:notes:144]
As of January 31, 2025 and February 2, 2024, the Company held fixed income debt securities of $27 million and $301 million, respectively, which it intends to hold to maturity. These investments are recorded at amortized cost and approximate fair value. As of January 31, 2025, the Company held $26 million in fixed income debt securities which will mature within one year and $1 million in fixed income debt securities which will mature within five years.


## dell:CreditLossFinancialInstrumentLeasesDebtVariableInterestEntitiesAndCustomerReceivablesSalesTextBlock

[0001571996-25-000034:notes:145]
FINANCIAL SERVICES 
The Company offers or arranges a portfolio of payment and consumption solutions and services for its customers globally, including as-a-Service, subscription, utility, leases, and loans designed to match customers' consumption and financing preferences, and provide operational and financial flexibility.

[0001571996-25-000034:notes:146]
To support financing solutions and services as part of the portfolio, DFS originates, collects, and services customer financing arrangements primarily related to the purchase and use of Dell Technologies products and services. In some cases, the Company also offers financing for the purchase of third-party technology products that complement the Dell Technologies portfolio of products and services. New financing originations were $8.4 billion for the fiscal years ended January 31, 2025 and February 2, 2024 and $9.7 billion for the fiscal year ended February 3, 2023.

[0001571996-25-000034:notes:147]
The Company’s financing arrangements with customers are aggregated primarily into the following categories:

[0001571996-25-000034:notes:148]
Fixed-term leases and loans — The Company enters into financing arrangements with customers who seek lease financing for equipment. Leases are generally classified as sales-type leases or operating leases. Additionally, utility, subscription, and as-a-Service flexible consumption models may result in identification of embedded lease arrangements that lead to the recognition of sales-type leases or operating leases. Leases with business customers have fixed terms of generally two to four years.

[0001571996-25-000034:notes:149]
The Company also offers fixed-term loans to qualified small businesses, large commercial accounts, governmental organizations, educational entities, and certain individual consumer customers. These loans are repaid in equal payments including interest and have defined terms of generally three to five years. The fair value of the fixed-term loan portfolio is determined using market observable inputs. The carrying value of these loans approximates fair value.

[0001571996-25-000034:notes:150]
Revolving loans — The Company primarily offered revolving loans to small and medium-sized commercial customers. Revolving loans provide qualified customers with a revolving credit line for the purchase of products and services offered by Dell Technologies. Revolving loans in the United States bear interest at a variable annual percentage rate that is tied to the prime rate. Based on historical payment patterns, revolving loan transactions are typically repaid within twelve months on average. Due to the short-term nature of the revolving loan portfolio, the carrying value of the portfolio approximates fair value.

[0001571996-25-000034:notes:151]
Prior to the sale of the U.S. consumer revolving customer receivables portfolio on October 4, 2023 described in Note 1 of the Notes to the Consolidated Financial Statements, the Company offered private label credit financing under the Dell Preferred Account (“DPA”) program. The DPA product was primarily offered to individual consumer customers. During the fiscal year ended January 31, 2025, the Company discontinued remaining offerings under the revolving loan portfolio. The Company will support existing customer arrangements as well as transition these customers to fixed-term offerings.

[0001571996-25-000034:notes:152]
Financing Receivables

[0001571996-25-000034:notes:153]
The following table presents the components of the Company’s financing receivables segregated by portfolio segment as of the dates indicated:

[0001571996-25-000034:notes:154]
|  | January 31, 2025 |  | February 2, 2024 |
|  | Revolving |  | Fixed-term |  | Total |  | Revolving |  | Fixed-term |  | Total |
|  | (in millions) |
| Financing receivables, net: |  |  |  |  |  |  |  |  |  |  |  |
| Customer receivables, gross (a) | $ | 86 |  |  | $ | 11,130 |  |  | $ | 11,216 |  |  | $ | 173 |  |  | $ | 10,360 |  |  | $ | 10,533 |  |
| Allowances for losses | (6) |  |  | (147) |  |  | (153) |  |  | (9) |  |  | (161) |  |  | (170) |  |
| Customer receivables, net | 80 |  |  | 10,983 |  |  | 11,063 |  |  | 164 |  |  | 10,199 |  |  | 10,363 |  |
| Residual interest | — |  |  | 168 |  |  | 168 |  |  | — |  |  | 157 |  |  | 157 |  |
| Financing receivables, net | $ | 80 |  |  | $ | 11,151 |  |  | $ | 11,231 |  |  | $ | 164 |  |  | $ | 10,356 |  |  | $ | 10,520 |  |
| Short-term | $ | 80 |  |  | $ | 5,224 |  |  | $ | 5,304 |  |  | $ | 164 |  |  | $ | 4,479 |  |  | $ | 4,643 |  |
| Long-term | $ | — |  |  | $ | 5,927 |  |  | $ | 5,927 |  |  | $ | — |  |  | $ | 5,877 |  |  | $ | 5,877 |  |

[0001571996-25-000034:notes:155]
(a)Customer receivables, gross include amounts due from customers under revolving loans, fixed-term loans, fixed-term leases, and accrued interest.

[0001571996-25-000034:notes:156]
The following table presents the changes in allowance for financing receivable losses for the periods indicated:

[0001571996-25-000034:notes:157]
|  | Fiscal Year Ended |
|  | January 31, 2025 |  | February 2, 2024 |  | February 3, 2023 |
|  | Revolving |  | Fixed-term |  | Total |  | Revolving |  | Fixed-term |  | Total |  | Revolving |  | Fixed-term |  | Total |
|  | (in millions) |
| Allowance for financing receivable losses: |
| Balances at beginning of period | $ | 9 |  |  | $ | 161 |  |  | $ | 170 |  |  | $ | 88 |  |  | $ | 113 |  |  | $ | 201 |  |  | $ | 102 |  |  | $ | 87 |  |  | $ | 189 |  |
| Charge-offs, net of recoveries | (12) |  |  | (59) |  |  | (71) |  |  | (41) |  |  | (8) |  |  | (49) |  |  | (52) |  |  | (8) |  |  | (60) |  |
| Provision charged to income statement | 9 |  |  | 45 |  |  | 54 |  |  | 36 |  |  | 56 |  |  | 92 |  |  | 38 |  |  | 34 |  |  | 72 |  |
| Other (a) | — |  |  | — |  |  | — |  |  | (74) |  |  | — |  |  | (74) |  |  | — |  |  | — |  |  | — |  |
| Balances at end of period | $ | 6 |  |  | $ | 147 |  |  | $ | 153 |  |  | $ | 9 |  |  | $ | 161 |  |  | $ | 170 |  |  | $ | 88 |  |  | $ | 113 |  |  | $ | 201 |  |

[0001571996-25-000034:notes:158]
(a)Other represents the derecognition of the allowance for financing receivable losses related to the sale of the U.S. consumer revolving customer receivables portfolio described in Note 1 of the Notes to the Consolidated Financial Statements.

[0001571996-25-000034:notes:159]
The Company recognizes an allowance for financing receivable losses, including both the lease receivable and unguaranteed residual, in an amount equal to the expected losses net of recoveries. The allowance for financing receivable losses on the lease receivable is determined based on various factors, including lifetime expected losses determined using macroeconomic forecast assumptions and management judgments applicable to and through the expected life of the portfolios as well as past due receivables, receivable type, and customer risk profile. The Company continues to monitor broader economic indicators and their potential impact on future credit loss performance.

[0001571996-25-000034:notes:160]
Aging

[0001571996-25-000034:notes:161]
The following table presents the aging of the Company’s customer financing receivables, gross, including accrued interest, segregated by class, as of the dates indicated:

[0001571996-25-000034:notes:162]
|  | January 31, 2025 |  | February 2, 2024 |
|  | Current |  | Past Due1 — 90 Days |  | Past Due>90 Days |  | Total |  | Current |  | Past Due1 — 90 Days |  | Past Due>90 Days |  | Total |
|  | (in millions) |
| Revolving | $ | 69 |  |  | $ | 12 |  |  | $ | 5 |  |  | $ | 86 |  |  | $ | 151 |  |  | $ | 17 |  |  | $ | 5 |  |  | $ | 173 |  |
| Fixed-term | 10,727 |  |  | 189 |  |  | 214 |  |  | 11,130 |  |  | 9,345 |  |  | 889 |  |  | 126 |  |  | 10,360 |  |
| Total customer receivables, gross | $ | 10,796 |  |  | $ | 201 |  |  | $ | 219 |  |  | $ | 11,216 |  |  | $ | 9,496 |  |  | $ | 906 |  |  | $ | 131 |  |  | $ | 10,533 |  |

[0001571996-25-000034:notes:163]
Aging is likely to fluctuate as a result of the variability in volume of large transactions entered into over the period, and the administrative processes that accompany those transactions. Aging is also impacted by the timing of the Company’s fiscal period end date relative to calendar month-end customer payment due dates. As a result of these factors, fluctuations in aging from period to period do not necessarily indicate a material change in the collectibility of the portfolio.

[0001571996-25-000034:notes:164]
Fixed-term customer receivables are placed on non-accrual status if principal or interest is past due and considered delinquent, or if there is concern about the collectibility of a specific customer receivable. The receivables identified as doubtful for collectibility may be classified as current for aging purposes. Aged revolving portfolio customer receivables identified as delinquent are charged off.

[0001571996-25-000034:notes:165]
Credit Quality

[0001571996-25-000034:notes:166]
The following tables present customer receivables, gross, including accrued interest, by credit quality indicator, segregated by class, as of the dates indicated:

[0001571996-25-000034:notes:167]
|  | January 31, 2025 |
|  | Fixed-term — Fiscal Year of Origination |  |  |  |  |
|  | 2025 |  | 2024 |  | 2023 |  | 2022 |  | 2021 |  | Years Prior |  | Revolving |  | Total |
|  | (in millions) |
| Higher | $ | 2,284 |  |  | $ | 2,160 |  |  | $ | 1,217 |  |  | $ | 357 |  |  | $ | 102 |  |  | $ | 4 |  |  | $ | 11 |  |  | $ | 6,135 |  |
| Mid | 2,431 |  |  | 695 |  |  | 464 |  |  | 107 |  |  | 17 |  |  | 4 |  |  | 24 |  |  | 3,742 |  |
| Lower | 501 |  |  | 407 |  |  | 283 |  |  | 68 |  |  | 28 |  |  | 1 |  |  | 51 |  |  | 1,339 |  |
| Total | $ | 5,216 |  |  | $ | 3,262 |  |  | $ | 1,964 |  |  | $ | 532 |  |  | $ | 147 |  |  | $ | 9 |  |  | $ | 86 |  |  | $ | 11,216 |  |

[0001571996-25-000034:notes:168]
|  | February 2, 2024 |
|  | Fixed-term — Fiscal Year of Origination |  |  |  |  |  |  |
|  | 2024 |  | 2023 |  | 2022 |  | 2021 |  | 2020 |  | Years Prior |  |  |  | Revolving |  | Total |
|  | (in millions) |
| Higher | $ | 3,261 |  |  | $ | 1,979 |  |  | $ | 833 |  |  | $ | 345 |  |  | $ | 64 |  |  | $ | — |  |  |  |  | $ | 47 |  |  | $ | 6,529 |  |
| Mid | 1,111 |  |  | 911 |  |  | 290 |  |  | 86 |  |  | 19 |  |  | — |  |  |  |  | 50 |  |  | 2,467 |  |
| Lower | 703 |  |  | 469 |  |  | 187 |  |  | 80 |  |  | 21 |  |  | 1 |  |  |  |  | 76 |  |  | 1,537 |  |
| Total | $ | 5,075 |  |  | $ | 3,359 |  |  | $ | 1,310 |  |  | $ | 511 |  |  | $ | 104 |  |  | $ | 1 |  |  |  |  | $ | 173 |  |  | $ | 10,533 |  |

[0001571996-25-000034:notes:169]
The categories shown in the tables above segregate customer receivables based on the relative degrees of credit risk. Credit quality indicators for revolving and fixed-term accounts are generally updated on a periodic basis.

[0001571996-25-000034:notes:170]
An internal grading system is utilized that assigns a credit level score based on a number of considerations, including liquidity, operating performance, and industry outlook. The grading criteria and classifications for the fixed-term products differ from those for the revolving products as loss experience varies between these product and customer groups. The credit quality categories cannot be compared between the different classes as loss experience varies substantially between the classes.

[0001571996-25-000034:notes:171]
Leases

[0001571996-25-000034:notes:172]
The following table presents amounts included in the Consolidated Statements of Income related to sales-type lease activity for the periods indicated:

[0001571996-25-000034:notes:173]
|  |  |  | Fiscal Year Ended |
|  |  |  |  |  | January 31, 2025 |  | February 2, 2024 |  | February 3, 2023 |
|  |  |  |  |  | (in millions) |
| Interest income — products |  |  |  |  | $ | 305 |  |  | $ | 175 |  |  | $ | 161 |  |
| Net revenue — products |  |  |  |  | $ | 1,992 |  |  | $ | 1,140 |  |  | $ | 851 |  |
| Cost of net revenue — products |  |  |  |  | 1,703 |  |  | 854 |  |  | 727 |  |
| Gross margin — products |  |  |  |  | $ | 289 |  |  | $ | 286 |  |  | $ | 124 |  |

[0001571996-25-000034:notes:174]
The following table presents the future maturity of the Company’s fixed-term customer leases and associated financing payments, and reconciles the undiscounted cash flows to the customer receivables, gross recognized on the Consolidated Statements of Financial Position as of the date indicated:

[0001571996-25-000034:notes:175]
|  | January 31, 2025 |
|  | (in millions) |
| Fiscal 2026 | $ | 3,327 |  |
| Fiscal 2027 | 2,296 |  |
| Fiscal 2028 | 998 |  |
| Fiscal 2029 | 477 |  |
| Fiscal 2030 and thereafter | 218 |  |
| Total undiscounted cash flows | 7,316 |  |
| Fixed-term loans | 4,914 |  |
| Revolving loans | 86 |  |
| Less: Unearned income | (1,100) |  |
| Total customer receivables, gross | $ | 11,216 |  |

[0001571996-25-000034:notes:176]
Operating Leases

[0001571996-25-000034:notes:177]
The Company’s operating leases primarily consist of fixed-term leases and contractually committed embedded leases identified within flexible consumption arrangements.

[0001571996-25-000034:notes:178]
The following table presents the components of the Company’s operating lease portfolio included in property, plant, and equipment, net as of the dates indicated:

[0001571996-25-000034:notes:179]
|  | January 31, 2025 |  | February 2, 2024 |
|  | (in millions) |
| Equipment under operating lease, gross | $ | 4,180 |  |  | $ | 4,002 |  |
| Less: Accumulated depreciation | (1,995) |  |  | (1,800) |  |
| Equipment under operating lease, net | $ | 2,185 |  |  | $ | 2,202 |  |

[0001571996-25-000034:notes:180]
The following table presents operating lease income related to lease payments and depreciation expense for the Company’s operating lease portfolio for the periods indicated:

[0001571996-25-000034:notes:181]
|  |  |  | Fiscal Year Ended |
|  |  |  |  |  | January 31, 2025 |  | February 2, 2024 |  | February 3, 2023 |
|  |  |  |  |  | (in millions) |
| Income related to lease payments |  |  |  |  | $ | 1,473 |  |  | $ | 1,353 |  |  | $ | 1,091 |  |
| Depreciation expense |  |  |  |  | $ | 956 |  |  | $ | 941 |  |  | $ | 803 |  |

[0001571996-25-000034:notes:182]
The following table presents the future payments to be received by the Company in operating lease contracts as of the date indicated:

[0001571996-25-000034:notes:183]
|  | January 31, 2025 |
|  | (in millions) |
| Fiscal 2026 | $ | 1,208 |  |
| Fiscal 2027 | 771 |  |
| Fiscal 2028 | 415 |  |
| Fiscal 2029 | 141 |  |
| Fiscal 2030 and thereafter | 42 |  |
| Total | $ | 2,577 |  |

[0001571996-25-000034:notes:184]
DFS Debt

[0001571996-25-000034:notes:185]
The Company maintains programs that facilitate the funding of leases, loans, and other alternative payment structures in the capital markets. The majority of DFS debt is non-recourse to Dell Technologies and represents borrowings under securitization programs and structured financing programs for which the Company’s risk of loss is limited to transferred lease and loan payments and associated equipment.

[0001571996-25-000034:notes:186]
The following table presents DFS debt as of the dates indicated and excludes the allocated portion of the Company’s other borrowings, which represents the additional amount considered to fund the DFS business:

[0001571996-25-000034:notes:187]
|  | January 31, 2025 |  | February 2, 2024 |
| DFS debt | (in millions) |
| DFS U.S. debt: |  |  |  |
| Asset-based financing facility | $ | 3,018 |  |  | $ | 2,730 |  |
| Fixed-term securitization offerings | 2,756 |  |  | 3,157 |  |
| Other | — |  |  | 28 |  |
| Total DFS U.S. debt, principal amount | 5,774 |  |  | 5,915 |  |
| DFS international debt: |  |  |  |
| Securitization facility | 624 |  |  | 761 |  |
| Other borrowings | 754 |  |  | 935 |  |
| Note payable | — |  |  | 250 |  |
| Dell Bank senior unsecured eurobonds | 1,559 |  |  | 1,631 |  |
| Total DFS international debt, principal amount | 2,937 |  |  | 3,577 |  |
| Total DFS debt, principal amount | $ | 8,711 |  |  | $ | 9,492 |  |
| Total short-term DFS debt | $ | 5,175 |  |  | $ | 5,863 |  |
| Total long-term DFS debt | $ | 3,536 |  |  | $ | 3,629 |  |

[0001571996-25-000034:notes:188]
DFS U.S. Debt

[0001571996-25-000034:notes:189]
Asset-Based Financing Facility — The Company maintains an asset-based financing facility in the United States, which is a revolving facility for fixed-term leases and loans. This debt is collateralized solely by the U.S. lease and loan payments and associated equipment in the facility. The asset-based financing facility consists of two tranches, with effective dates through July 7, 2025 and July 7, 2026, respectively. As of January 31, 2025, the total debt capacity related to the asset-based financing facility was $5.0 billion. The debt has a variable interest rate, and the duration of the debt is based on the terms of the underlying lease and loan payment streams. The Company enters into interest rate swap agreements to economically convert a portion of this debt from a floating rate to a fixed rate. See Note 8 of the Notes to the Consolidated Financial Statements for additional information about the Company’s interest rate swaps.

[0001571996-25-000034:notes:190]
The asset-based financing facility contains standard structural features related to the performance of the funded receivables, which include defined credit losses, delinquencies, average credit scores, and minimum collection requirements. In the event one or more of these criteria are not met and the Company is unable to restructure the facility, no further funding of receivables will be permitted and the timing of the Company’s expected cash flows from over-collateralization will be delayed. As of January 31, 2025, these criteria were met.

[0001571996-25-000034:notes:191]
Fixed-Term Securitization Offerings — The Company periodically issues asset-backed debt securities under fixed-term securitization programs to private investors. The asset-backed debt securities are collateralized solely by the U.S. fixed-term lease and loan payments and associated equipment, which are held by Special Purpose Entities (“SPEs”), as discussed below. The interest rate on these securities is fixed and ranges from 4.14% to 6.80% per annum as of January 31, 2025, and the duration of these securities is based on the terms of the underlying lease and loan payment streams.

[0001571996-25-000034:notes:192]
DFS International Debt

[0001571996-25-000034:notes:193]
Securitization Facility — The Company maintains a securitization facility in Europe for fixed-term leases and loans. The debt under this facility has a variable interest rate, and the duration of the debt is based on the terms of the underlying lease and loan payment streams. This facility is effective through December 22, 2026 and had a total debt capacity of $831 million as of January 31, 2025.

[0001571996-25-000034:notes:194]
The securitization facility contains standard structural features related to the performance of the securitized receivables, which include defined credit losses, delinquencies, average credit scores, and minimum collection requirements. In the event one or more of these criteria are not met and the Company is unable to restructure the program, no further funding of receivables will be permitted and the timing of the Company’s expected cash flows from over-collateralization will be delayed. As of January 31, 2025, these criteria were met.

[0001571996-25-000034:notes:195]
Other Borrowings — In connection with the Company’s international financing operations, the Company has entered into revolving structured financing debt programs related to its fixed-term lease and loan products sold in Canada, Europe, Australia, New Zealand, the Middle East, and Singapore. The debt under these programs has a variable interest rate.

[0001571996-25-000034:notes:196]
The duration of the debt in Canada, Europe, Australia, New Zealand, and the Middle East is based on the terms of the underlying lease and loan payment streams. These facilities are collateralized solely by the lease and loan payments and associated equipment in their respective region or country. The Canadian facility had a total debt capacity of $242 million as of January 31, 2025 and is effective through January 15, 2028. The European facility had a total debt capacity of $520 million as of January 31, 2025 and is effective through December 14, 2026. The Australia and New Zealand facility had a total debt capacity of $279 million as of January 31, 2025 and is effective through April 20, 2025. The Middle East facility had a total debt capacity of $150 million as of January 31, 2025 and was effective through March 24, 2025. Subsequent to the close of the fiscal year ended January 31, 2025, the Company extended the term of the Middle East facility to be effective through March 14, 2027.

[0001571996-25-000034:notes:197]
The Company also has two unsecured Singapore facilities with a total debt capacity of $244 million as of January 31, 2025 that are effective through July 3, 2026 and July 3, 2027, respectively.

[0001571996-25-000034:notes:198]
Note Payable — On May 25, 2022, the Company entered into an unsecured credit agreement which had an aggregate principal amount of $250 million to fund receivables in Mexico. The note bore interest at an annual rate of 4.24% and was paid in full on May 31, 2024.

[0001571996-25-000034:notes:199]
Dell Bank Senior Unsecured Eurobonds — On October 27, 2021, Dell Bank issued 500 million Euro of 0.5% senior unsecured five year eurobonds due October 2026. On October 18, 2022, Dell Bank issued 500 million Euro of 4.5% senior unsecured five year eurobonds due October 2027. On June 13, 2024, Dell Bank issued 500 million Euro of 3.6% senior unsecured five year eurobonds due June 2029. The issuances of the senior unsecured eurobonds support the expansion of the financing operations in Europe.

[0001571996-25-000034:notes:200]
Variable Interest Entities

[0001571996-25-000034:notes:201]
In connection with the asset-based financing facility, securitization facility, and fixed-term securitization offerings discussed above, the Company transfers certain U.S. and European lease and loan payments and associated equipment to SPEs that meet the definition of a VIE and are consolidated, along with the associated debt described above, into the Consolidated Financial Statements, as the Company is the primary beneficiary of the VIEs. The SPEs are bankruptcy-remote legal entities with separate assets and liabilities. The purpose of the SPEs is to facilitate the funding of customer lease and loan payments and associated equipment in the capital markets.

[0001571996-25-000034:notes:202]
Some of the SPEs have entered into financing arrangements with multi-seller conduits that, in turn, issue asset-backed debt securities in the capital markets. DFS debt outstanding held by the consolidated VIEs is collateralized by the lease and loan payments and associated equipment. The Company’s risk of loss related to securitized receivables is limited to the amount by which the Company’s right to receive collections for assets securitized exceeds the amount required to pay interest, principal, and fees and expenses related to the asset-backed securities. The Company provides credit enhancement to the securitization in the form of over-collateralization.

[0001571996-25-000034:notes:203]
The following table presents the assets and liabilities held by the consolidated VIEs as of the dates indicated, which are included in the Consolidated Statements of Financial Position:

[0001571996-25-000034:notes:204]
|  | January 31, 2025 |  | February 2, 2024 |
|  | (in millions) |
| Assets held by consolidated VIEs |  |  |  |
| Other current assets | $ | 123 |  |  | $ | 136 |  |
| Financing receivables, net of allowance |  |  |  |
| Short-term | $ | 3,262 |  |  | $ | 3,314 |  |
| Long-term | $ | 2,725 |  |  | $ | 2,747 |  |
| Property, plant, and equipment, net | $ | 984 |  |  | $ | 1,081 |  |
| Liabilities held by consolidated VIEs |  |  |  |
| Debt, net of unamortized debt issuance costs |  |  |  |
| Short-term | $ | 4,598 |  |  | $ | 4,450 |  |
| Long-term | $ | 1,788 |  |  | $ | 2,184 |  |

[0001571996-25-000034:notes:205]
Lease and loan payments and associated equipment transferred via securitization through SPEs were $3.6 billion and $4.6 billion for the fiscal years ended January 31, 2025 and February 2, 2024, respectively.

[0001571996-25-000034:notes:206]
Customer Receivables Sales

[0001571996-25-000034:notes:207]
To manage certain concentrations of customer credit exposure, the Company may sell selected fixed-term customer receivables to unrelated third parties on a periodic basis, without recourse. The amount of customer receivables sold for this purpose was $79 million, $222 million, and $680 million for the fiscal years ended January 31, 2025, February 2, 2024, and February 3, 2023, respectively. The Company’s continuing involvement in these customer receivables is primarily limited to servicing arrangements.


## us-gaap:ScheduleOfDebtTableTextBlock

[0001571996-25-000034:notes:208]
The following table summarizes the Company’s outstanding debt as of the dates indicated:

[0001571996-25-000034:notes:209]
|  | January 31, 2025 |  | February 2, 2024 |
|  | (in millions) |
| Senior Notes | $ | 15,073 |  |  | $ | 15,607 |  |
| Legacy Notes | 952 |  |  | 952 |  |
| DFS Debt (Note 5) | 8,711 |  |  | 9,492 |  |
| Other | 52 |  |  | 171 |  |
| Total debt, principal amount | 24,788 |  |  | 26,222 |  |
| Unamortized discount, net of unamortized premium | (110) |  |  | (114) |  |
| Debt issuance costs | (111) |  |  | (114) |  |
| Total debt, carrying value | $ | 24,567 |  |  | $ | 25,994 |  |
| Total short-term debt, carrying value | $ | 5,204 |  |  | $ | 6,982 |  |
| Total long-term debt, carrying value | $ | 19,363 |  |  | $ | 19,012 |  |


## us-gaap:LesseeOperatingLeasesTextBlock

[0001571996-25-000034:notes:210]
LEASES 
The Company enters into leasing transactions in which the Company is the lessee. These lease contracts are typically classified as operating leases. The Company’s lease contracts are generally for office buildings used to conduct its business, and the determination of whether such contracts contain leases generally does not require significant estimates or judgments. The Company also leases certain global logistics warehouses, employee vehicles, and equipment. As of January 31, 2025, the remaining terms of the Company’s leases range from one month to approximately eleven years. As of January 31, 2025 and February 2, 2024, there were no material finance leases in which the Company was a lessee.

[0001571996-25-000034:notes:211]
The Company also enters into leasing transactions in which the Company is the lessor, primarily through customer financing arrangements offered under DFS. DFS originates leases that are primarily classified as either sales-type leases or operating leases. See Note 5 of the Notes to the Consolidated Financial Statements for more information about the Company’s lessor arrangements.

[0001571996-25-000034:notes:212]
The following table presents components of lease costs included in the Consolidated Statements of Income for the periods indicated:

[0001571996-25-000034:notes:213]
|  |  |  | Fiscal Year Ended |
|  |  |  |  |  | January 31, 2025 |  | February 2, 2024 |  | February 3, 2023 |
|  |  |  |  |  | (in millions) |
| Operating lease costs |  |  |  |  | $ | 293 |  |  | $ | 291 |  |  | $ | 283 |  |
| Variable costs |  |  |  |  | 62 |  |  | 80 |  |  | 113 |  |
| Total lease costs |  |  |  |  | $ | 355 |  |  | $ | 371 |  |  | $ | 396 |  |

[0001571996-25-000034:notes:214]
During the fiscal years ended January 31, 2025, February 2, 2024, and February 3, 2023, sublease income, finance lease costs, and short-term lease costs were immaterial.

[0001571996-25-000034:notes:215]
The following table presents supplemental information related to operating leases included in the Consolidated Statements of Financial Position as of the dates indicated:

[0001571996-25-000034:notes:216]
|  | Classification |  | January 31, 2025 |  | February 2, 2024 |  |  |
|  |  |  | (in millions, except for term and discount rate) |
| Operating lease right-of-use assets | Other non-current assets |  | $ | 660 |  | $ | 707 |  |  |
| Current operating lease liabilities | Accrued and other current liabilities |  | $ | 236 |  | $ | 253 |  |  |
| Non-current operating lease liabilities | Other non-current liabilities |  | 522 |  | 576 |  |  |
| Total operating lease liabilities |  |  | $ | 758 |  | $ | 829 |  |  |
| Weighted-average remaining lease term (in years) |  |  | 4.36 |  | 4.56 |  |  |
| Weighted-average discount rate |  |  | 5.14 | % |  | 4.79 | % |  |  |

[0001571996-25-000034:notes:217]
The following table presents supplemental cash flow information related to leases for the periods indicated:

[0001571996-25-000034:notes:218]
|  | Fiscal Year Ended |
|  | January 31, 2025 |  | February 2, 2024 |  | February 3, 2023 |
|  | (in millions) |
| Cash paid for amounts included in the measurement of lease liabilities — operating cash outflows from operating leases | $ | 271 |  |  | $ | 300 |  |  | $ | 306 |  |
| Right-of-use assets obtained in exchange for new operating lease liabilities | $ | 184 |  |  | $ | 247 |  |  | $ | 226 |  |

[0001571996-25-000034:notes:219]
The following table presents the future maturity of the Company’s operating lease liabilities under non-cancelable leases and reconciles the undiscounted cash flows for these leases to the lease liability recognized on the Consolidated Statements of Financial Position as of the date indicated:

[0001571996-25-000034:notes:220]
|  | January 31, 2025 |
|  | (in millions) |
| Fiscal 2026 | $ | 233 |  |
| Fiscal 2027 | 200 |  |
| Fiscal 2028 | 157 |  |
| Fiscal 2029 | 105 |  |
| Fiscal 2030 | 77 |  |
| Thereafter | 68 |  |
| Total lease payments | 840 |  |
| Less: Imputed interest | 82 |  |
| Total | $ | 758 |  |
| Current operating lease liabilities | $ | 236 |  |
| Non-current operating lease liabilities | $ | 522 |  |

[0001571996-25-000034:notes:221]
As of January 31, 2025, the Company’s undiscounted operating leases that had not yet commenced were immaterial.


## us-gaap:DebtDisclosureTextBlock

[0001571996-25-000034:notes:222]
DEBT
The following table summarizes the Company’s outstanding debt as of the dates indicated:

[0001571996-25-000034:notes:223]
The Company completed the following transactions during the fiscal year ended January 31, 2025:

[0001571996-25-000034:notes:224]
•the issuance of $1 billion principal amount of 5.40% Senior Notes due April 2034, the proceeds of which were utilized to prepay a portion of the outstanding 6.02% Senior Notes due June 2026;

[0001571996-25-000034:notes:225]
•the repayment of $1 billion principal amount of the 4.00% Senior Notes due July 2024; and

[0001571996-25-000034:notes:226]
•the issuance of $0.7 billion principal amount of 4.35% Senior Notes due February 2030 and $0.8 billion principal amount of 4.85% Senior Notes due February 2035, the proceeds of which were utilized to redeem the 5.85% Senior Notes due July 2025.

[0001571996-25-000034:notes:227]
Outstanding Debt

[0001571996-25-000034:notes:228]
Senior Notes — The Company completed offerings of multiple series of senior notes which were issued on June 1, 2016, June 22, 2016, March 20, 2019, April 9, 2020, December 13, 2021, January 24, 2023, March 18, 2024, and October 8, 2024 in aggregate principal amounts of $20.0 billion, $3.3 billion, $4.5 billion, $2.3 billion, $2.3 billion, $2.0 billion, $1.0 billion, and $1.5 billion, respectively (collectively, the “Senior Notes”). The Senior Notes’ maturities range from 2026 through 2051. Interest rates on these borrowings are fixed, ranging from 3.38% to 8.35%, and interest is payable semiannually.

[0001571996-25-000034:notes:229]
Legacy Notes — The Company has outstanding unsecured notes and debentures (collectively, the “Legacy Notes”) that were issued by Dell Inc. (“Dell”), a wholly-owned subsidiary of Dell Technologies Inc., prior to the acquisition of Dell by Dell Technologies Inc. in the going-private transaction that closed in October 2013. The Legacy Notes’ maturities range from 2028 through 2040. Interest rates on these borrowings are fixed, ranging from 5.40% to 7.10%, and interest is payable semiannually.

[0001571996-25-000034:notes:230]
DFS Debt — See Note 5 and Note 8 of the Notes to the Consolidated Financial Statements, respectively, for discussion of DFS debt and the interest rate swap agreements that hedge a portion of that debt.

[0001571996-25-000034:notes:231]
Revolving Credit Facility — The Company’s revolving credit facility provides the Company with revolving commitments in an aggregate principal amount of $6.0 billion for general corporate purposes and includes a letter of credit sub-facility of up to $0.5 billion and a swing-line loan sub-facility of up to $0.5 billion. The revolving credit facility also allows the Company to obtain incremental additional commitments on one or more occasions in minimum amounts of $10 million.

[0001571996-25-000034:notes:232]
Borrowings under the revolving credit facility bear interest at a rate per annum equal to an applicable margin plus, at the borrowers’ option, either (a) the specified adjusted term Secured Overnight Financing Rate (“SOFR”) or (b) a base rate. The margin applicable to SOFR and base rate borrowings varies based upon the Company’s existing credit ratings. The base rate is calculated based upon the greatest of the specified prime rate, the specified federal reserve bank rate, or SOFR plus 1%. The borrowers may voluntarily repay outstanding loans at any time without premium or penalty, other than customary breakage costs. The facility matures on November 1, 2027.

[0001571996-25-000034:notes:233]
As of January 31, 2025, the Company had no outstanding borrowings under the revolving credit facility.

[0001571996-25-000034:notes:234]
Commercial Paper Program — The Company maintains a commercial paper program under which the Company may issue unsecured notes in a maximum aggregate face amount of $5.0 billion outstanding at any time, with maturities of up to 397 days from the date of issuance. The notes are sold on customary terms in the U.S. commercial paper market on a private placement basis. The proceeds of the notes are used for general corporate purposes. As of January 31, 2025, the Company had no outstanding issuances under the commercial paper program.

[0001571996-25-000034:notes:235]
The Company may purchase, redeem, prepay, refinance, or otherwise retire any amount of outstanding indebtedness under the terms of such indebtedness at any time and from time to time, in open market or negotiated transactions with the holders of such indebtedness or otherwise, as considered appropriate in light of market conditions and other relevant factors.

[0001571996-25-000034:notes:236]
Covenants — The credit agreement governing the revolving credit facility and the indentures governing the Senior Notes and the Legacy Notes impose various limitations, subject to exceptions, on creating certain liens and entering into sale and lease-back transactions. The foregoing credit agreement and indentures contain customary events of default, and the revolving credit facility is subject to an interest coverage ratio covenant that is tested at the end of each fiscal quarter with respect to the Company’s preceding four fiscal quarters. The Company was in compliance with this financial covenant as of January 31, 2025.

[0001571996-25-000034:notes:237]
Aggregate Future Maturities

[0001571996-25-000034:notes:238]
The following table presents the aggregate future maturities of the Company’s debt as of January 31, 2025, excluding associated carrying value adjustments, for the periods indicated:

[0001571996-25-000034:notes:239]
|  | January 31, 2025 |
|  | (in millions) |
| Fiscal 2026 | $ | 5,208 |  |
| Fiscal 2027 | 6,384 |  |
| Fiscal 2028 | 1,315 |  |
| Fiscal 2029 | 1,372 |  |
| Fiscal 2030 | 2,984 |  |
| Thereafter | 7,525 |  |
| Total maturities, principal amount | $ | 24,788 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001571996-25-000034:notes:240]
DERIVATIVE INSTRUMENTS AND HEDGING ACTIVITIES 
As part of its risk management strategy, the Company uses derivative instruments, primarily foreign currency forward and option contracts and interest rate swaps, to hedge certain foreign currency and interest rate exposures, respectively.

[0001571996-25-000034:notes:241]
The Company’s objective is to offset gains and losses resulting from these exposures with gains and losses on the derivative contracts used to hedge the exposures, thereby reducing volatility of earnings and protecting the fair values of assets and liabilities. The earnings effects of the derivative instruments are presented in the same line items on the Consolidated Statements of Income as the earnings effects of the hedged items. For derivatives designated as cash flow hedges, the Company assesses hedge effectiveness both at the onset of the hedge and at regular intervals throughout the life of the instruments. For derivatives designated as fair value hedges, the Company assesses hedge effectiveness on qualifying instruments using the shortcut method whereby the hedges are considered perfectly effective at the onset of the hedge and over the life of the hedging relationship.

[0001571996-25-000034:notes:242]
Foreign Exchange Risk

[0001571996-25-000034:notes:243]
The Company uses foreign currency forward and option contracts designated as cash flow hedges to protect against the foreign currency exchange rate risks inherent in its forecasted transactions denominated in currencies other than the U.S. Dollar. Hedge accounting is applied based upon the criteria established by accounting guidance for derivative instruments and hedging activities. The risk of loss associated with purchased options is limited to premium amounts paid for the option contracts. The risk of loss associated with forward contracts is equal to the exchange rate differential from the time the contract is entered into until the time it is settled. The majority of these contracts typically expire in twelve months or less.

[0001571996-25-000034:notes:244]
During the fiscal years ended January 31, 2025, February 2, 2024, and February 3, 2023, the Company did not discontinue any cash flow hedges related to foreign exchange contracts that had a material impact on the Company’s results of operations due to the probability that the forecasted cash flows would not occur.

[0001571996-25-000034:notes:245]
The Company uses forward contracts to hedge monetary assets and liabilities denominated in a foreign currency. These contracts generally expire in three months or less, are considered economic hedges, and are not designated for hedge accounting. The change in the fair value of these instruments represents a natural hedge as their gains and losses offset the changes in the underlying fair value of the monetary assets and liabilities due to movements in currency exchange rates.

[0001571996-25-000034:notes:246]
In connection with DFS operations in Europe, forward contracts are used to hedge financing receivables denominated in foreign currencies other than Euro. These contracts are not designated for hedge accounting and most expire within three years or less.

[0001571996-25-000034:notes:247]
Interest Rate Risk

[0001571996-25-000034:notes:248]
The Company uses interest rate swaps to hedge the variability in cash flows related to the interest rate payments on structured financing debt. The interest rate swaps economically convert the variable rate on the structured financing debt to a fixed interest rate to match the underlying fixed rate being received on fixed-term customer leases and loans. These contracts are not designated for hedge accounting and most expire within four years or less.

[0001571996-25-000034:notes:249]
Interest rate swaps are utilized to manage the interest rate risk, at a portfolio level, associated with DFS operations in Europe. The interest rate swaps economically convert the fixed rate on financing receivables to a one-month or three-month Euribor floating rate in order to match the floating rate nature of the banks’ funding pool. The Company also uses interest rate swaps to manage the cash flows related to interest payments on senior unsecured eurobonds. The interest rate swaps economically convert the fixed rate on the Company’s bonds to a floating rate to match the underlying lease repayments profile. These contracts are not designated for hedge accounting and most expire within five years or less. See Note 5 of the Notes to the Consolidated Financial Statements for more information about the Dell Bank senior unsecured eurobonds.

[0001571996-25-000034:notes:250]
The Company utilizes cross-currency amortizing swaps to hedge the currency and interest rate risk exposure associated with the European securitization program. The cross-currency swaps combine a Euro-based interest rate swap with a British Pound or U.S. Dollar foreign exchange forward contract in which the Company pays a fixed or floating British Pound or U.S. Dollar amount and receives a fixed or floating amount in Euros linked to the one-month Euribor rate. The notional value of the swaps amortizes in line with the expected cash flows and run-off of the securitized assets. The swaps are not designated for hedge accounting and expire within five years or less.

[0001571996-25-000034:notes:251]
Derivative Instruments

[0001571996-25-000034:notes:252]
The following table presents the notional amounts of outstanding derivative instruments as of the dates indicated:

[0001571996-25-000034:notes:253]
|  | January 31, 2025 |  | February 2, 2024 |
|  | (in millions) |
| Foreign exchange contracts: |  |  |  |
| Designated as cash flow hedging instruments | $ | 5,965 |  |  | $ | 6,339 |  |
| Non-designated as hedging instruments | 5,683 |  |  | 5,844 |  |
| Total | $ | 11,648 |  |  | $ | 12,183 |  |
| Interest rate contracts: |  |  |  |
| Non-designated as hedging instruments | $ | 6,353 |  |  | $ | 6,551 |  |

[0001571996-25-000034:notes:254]
The following table presents the effect of derivative instruments designated as cash flow hedging instruments on the Consolidated Statements of Financial Position and the Consolidated Statements of Income for the periods indicated:

[0001571996-25-000034:notes:255]
| Derivatives in Cash Flow Hedging Relationships |  | Gain Recognized in Accumulated OCI, Net of Tax, on Derivatives |  | Location of Gain (Loss) Reclassified from Accumulated OCI into Income |  | Gain (Loss) Reclassified from Accumulated OCI into Income |
|  |  | (in millions) |  |  |  | (in millions) |
| For the fiscal year ended January 31, 2025: |
|  |  |  |  | Total net revenue |  | $ | 100 |  |
| Foreign exchange contracts |  | $ | 246 |  |  | Total cost of net revenue |  | 11 |  |
| Total |  | $ | 246 |  |  | Total |  | $ | 111 |  |
| For the fiscal year ended February 2, 2024: |
|  |  |  |  | Total net revenue |  | $ | (98) |  |
| Foreign exchange contracts |  | $ | 85 |  |  | Total cost of net revenue |  | (9) |  |
| Total |  | $ | 85 |  |  | Total |  | $ | (107) |  |
| For the fiscal year ended February 3, 2023: |
|  |  |  |  | Total net revenue |  | $ | 736 |  |
| Foreign exchange contracts |  | $ | 354 |  |  | Total cost of net revenue |  | (31) |  |
| Total |  | $ | 354 |  |  | Total |  | $ | 705 |  |

[0001571996-25-000034:notes:256]
The following table presents the effect of derivative instruments not designated as hedging instruments on the Consolidated Statements of Income for the periods indicated:

[0001571996-25-000034:notes:257]
|  |  |  | Fiscal Year Ended |  |  |
|  |  |  |  |  | January 31, 2025 |  | February 2, 2024 |  | February 3, 2023 |  | Location of Gain (Loss) Recognized |
|  |  |  |  |  | (in millions) |  |  |
| Foreign exchange contracts |  |  |  |  | $ | (214) |  |  | $ | (35) |  |  | $ | (174) |  |  | Interest and other, net |
| Interest rate contracts |  |  |  |  | 27 |  |  | — |  |  | 50 |  |  | Interest and other, net |
| Total |  |  |  |  | $ | (187) |  |  | $ | (35) |  |  | $ | (124) |  |  |  |

[0001571996-25-000034:notes:258]
The Company presents its derivative instruments on a net basis in the Consolidated Statements of Financial Position due to the right of offset by its counterparties under master netting arrangements. The following tables present the fair value of those derivative instruments presented on a gross basis as of the dates indicated:

[0001571996-25-000034:notes:259]
|  | January 31, 2025 |
|  | Other Current Assets |  | Other Non-Current Assets |  | Other Current Liabilities |  | Other Non-Current Liabilities |  | Total Fair Value |
|  | (in millions) |
| Derivatives designated as hedging instruments: |
| Foreign exchange contracts in an asset position | $ | 136 |  |  | $ | — |  |  | $ | 9 |  |  | $ | — |  |  | $ | 145 |  |
| Foreign exchange contracts in a liability position | (7) |  |  | — |  |  | (3) |  |  | — |  |  | (10) |  |
| Net asset (liability) | 129 |  |  | — |  |  | 6 |  |  | — |  |  | 135 |  |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts in an asset position | 430 |  |  | — |  |  | 53 |  |  | — |  |  | 483 |  |
| Foreign exchange contracts in a liability position | (297) |  |  | — |  |  | (90) |  |  | — |  |  | (387) |  |
| Interest rate contracts in an asset position | — |  |  | 40 |  |  | — |  |  | — |  |  | 40 |  |
| Interest rate contracts in a liability position | — |  |  | — |  |  | (1) |  |  | (43) |  |  | (44) |  |
| Net asset (liability) | 133 |  |  | 40 |  |  | (38) |  |  | (43) |  |  | 92 |  |
| Total derivatives at fair value | $ | 262 |  |  | $ | 40 |  |  | $ | (32) |  |  | $ | (43) |  |  | $ | 227 |  |
|  | February 2, 2024 |
|  | Other Current Assets |  | Other Non-Current Assets |  | Other Current Liabilities |  | Other Non-Current Liabilities |  | Total Fair Value |
|  | (in millions) |
| Derivatives designated as hedging instruments: |
| Foreign exchange contracts in an asset position | $ | 44 |  |  | $ | — |  |  | $ | 19 |  |  | $ | — |  |  | $ | 63 |  |
| Foreign exchange contracts in a liability position | (5) |  |  | — |  |  | (15) |  |  | — |  |  | (20) |  |
| Net asset (liability) | 39 |  |  | — |  |  | 4 |  |  | — |  |  | 43 |  |
| Derivatives not designated as hedging instruments: |
| Foreign exchange contracts in an asset position | 90 |  |  | — |  |  | 71 |  |  | — |  |  | 161 |  |
| Foreign exchange contracts in a liability position | (68) |  |  | — |  |  | (121) |  |  | — |  |  | (189) |  |
| Interest rate contracts in an asset position | 3 |  |  | 40 |  |  | — |  |  | — |  |  | 43 |  |
| Interest rate contracts in a liability position | — |  |  | — |  |  | (10) |  |  | (28) |  |  | (38) |  |
| Net asset (liability) | 25 |  |  | 40 |  |  | (60) |  |  | (28) |  |  | (23) |  |
| Total derivatives at fair value | $ | 64 |  |  | $ | 40 |  |  | $ | (56) |  |  | $ | (28) |  |  | $ | 20 |  |

[0001571996-25-000034:notes:260]
The following tables present the gross amounts of the Company’s derivative instruments, amounts offset due to master netting agreements with the Company’s counterparties, and the net amounts recognized in the Consolidated Statements of Financial Position as of the dates indicated:

[0001571996-25-000034:notes:261]
|  | January 31, 2025 |
|  | Gross Amounts of Recognized Assets/(Liabilities) |  | Gross Amounts Offset in the Statement of Financial Position |  | Net Amounts of Assets/(Liabilities) Presented in the Statement of Financial Position |  | Gross Amounts not Offset in the Statement of Financial Position |  | Net Amount of Assets/ (Liabilities) Recognized in the Statement of Financial Position |
|  | Financial Instruments |  | Cash Collateral Received or Pledged |  |
|  | (in millions) |
| Derivative instruments: |  |  |  |  |  |  |  |  |  |  |  |
| Financial assets | $ | 668 |  |  | $ | (366) |  |  | $ | 302 |  |  | $ | — |  |  | $ | (36) |  |  | $ | 266 |  |
| Financial liabilities | (441) |  |  | 366 |  |  | (75) |  |  | — |  |  | 8 |  |  | (67) |  |
| Total derivative instruments | $ | 227 |  |  | $ | — |  |  | $ | 227 |  |  | $ | — |  |  | $ | (28) |  |  | $ | 199 |  |
|  | February 2, 2024 |
|  | Gross Amounts of Recognized Assets/(Liabilities) |  | Gross Amounts Offset in the Statement of Financial Position |  | Net Amounts of Assets/(Liabilities) Presented in the Statement of Financial Position |  | Gross Amounts not Offset in the Statement of Financial Position |  | Net Amount of Assets/ (Liabilities) Recognized in the Statement of Financial Position |
|  | Financial Instruments |  | Cash Collateral Received or Pledged |  |
|  | (in millions) |
| Derivative instruments: |  |  |  |  |  |  |  |  |  |  |  |
| Financial assets | $ | 267 |  |  | $ | (163) |  |  | $ | 104 |  |  | $ | — |  |  | $ | (24) |  |  | $ | 80 |  |
| Financial liabilities | (247) |  |  | 163 |  |  | (84) |  |  | — |  |  | 9 |  |  | (75) |  |
| Total derivative instruments | $ | 20 |  |  | $ | — |  |  | $ | 20 |  |  | $ | — |  |  | $ | (15) |  |  | $ | 5 |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001571996-25-000034:notes:262]
GOODWILL AND INTANGIBLE ASSETS
Goodwill

[0001571996-25-000034:notes:263]
The Infrastructure Solutions Group and Client Solutions Group reporting units are consistent with the reportable segments identified in Note 18 of the Notes to the Consolidated Financial Statements. Corporate and other consists of results of Secureworks, VMware Resale, and Virtustream, each of which represents a separate reporting unit not classified as a reportable segment, either individually or collectively.

[0001571996-25-000034:notes:264]
The following table presents goodwill allocated to the Company’s reportable segments and changes in the carrying amount of goodwill as of the dates indicated:

[0001571996-25-000034:notes:265]
|  | Infrastructure Solutions Group |  | Client Solutions Group |  | Corporate and other |  | Total |
|  | (in millions) |
| Balances as of February 3, 2023 | $ | 15,017 |  |  | $ | 4,232 |  |  | $ | 427 |  |  | $ | 19,676 |  |
| Goodwill acquired (a) | 77 |  |  | — |  |  | — |  |  | 77 |  |
| Impact of foreign currency translation and other | (53) |  |  | — |  |  | — |  |  | (53) |  |
| Balances as of February 2, 2024 | 15,041 |  |  | 4,232 |  |  | 427 |  |  | 19,700 |  |
| Impact of foreign currency translation and other | (153) |  |  | — |  |  | — |  |  | (153) |  |
| Reclassification to assets held for sale (b) | — |  |  | — |  |  | (427) |  |  | (427) |  |
| Balances as of January 31, 2025 | $ | 14,888 |  |  | $ | 4,232 |  |  | $ | — |  |  | $ | 19,120 |  |

[0001571996-25-000034:notes:266]
(a)Goodwill acquired represents goodwill recognized in connection with the Company’s acquisition of Moogsoft Inc. during the fiscal year ended February 2, 2024.

[0001571996-25-000034:notes:267]
(b)During the fiscal year ended January 31, 2025, Secureworks goodwill was reclassified to current assets held for sale on the Consolidated Statements of Financial Position. See Note 1 of the Notes to the Consolidated Financial Statements for additional information about the sale of Secureworks.

[0001571996-25-000034:notes:268]
Intangible Assets

[0001571996-25-000034:notes:269]
The following table presents the Company’s intangible assets as of the dates indicated:

[0001571996-25-000034:notes:270]
|  | January 31, 2025 |  | February 2, 2024 |
|  | Gross |  | AccumulatedAmortization |  | Net |  | Gross |  | AccumulatedAmortization |  | Net |
|  | (in millions) |
| Customer relationships | $ | 16,642 |  |  | $ | (15,013) |  |  | $ | 1,629 |  |  | $ | 16,968 |  |  | $ | (14,930) |  |  | $ | 2,038 |  |
| Developed technology | 9,500 |  |  | (9,211) |  |  | 289 |  |  | 9,506 |  |  | (8,980) |  |  | 526 |  |
| Trade names | 875 |  |  | (860) |  |  | 15 |  |  | 875 |  |  | (823) |  |  | 52 |  |
| Definite-lived intangible assets | 27,017 |  |  | (25,084) |  |  | 1,933 |  |  | 27,349 |  |  | (24,733) |  |  | 2,616 |  |
| Indefinite-lived trade names | 3,055 |  |  | — |  |  | 3,055 |  |  | 3,085 |  |  | — |  |  | 3,085 |  |
| Total intangible assets | $ | 30,072 |  |  | $ | (25,084) |  |  | $ | 4,988 |  |  | $ | 30,434 |  |  | $ | (24,733) |  |  | $ | 5,701 |  |

[0001571996-25-000034:notes:271]
Amortization expense related to definite-lived intangible assets was $0.7 billion, $0.8 billion, and $1.0 billion for the fiscal years ended January 31, 2025, February 2, 2024, and February 3, 2023, respectively. There were no material impairment charges related to intangible assets during the fiscal years ended January 31, 2025, February 2, 2024, and February 3, 2023.

[0001571996-25-000034:notes:272]
The following table presents the estimated future annual pre-tax amortization expense of definite-lived intangible assets as of the date indicated:

[0001571996-25-000034:notes:273]
|  | January 31, 2025 |
|  | (in millions) |
| Fiscal 2026 | $ | 480 |  |
| Fiscal 2027 | 372 |  |
| Fiscal 2028 | 230 |  |
| Fiscal 2029 | 190 |  |
| Fiscal 2030 | 153 |  |
| Thereafter | 508 |  |
| Total | $ | 1,933 |  |

[0001571996-25-000034:notes:274]
Goodwill and Indefinite-Lived Intangible Assets Impairment Testing

[0001571996-25-000034:notes:275]
Goodwill and indefinite-lived intangible assets are tested for impairment annually during the third fiscal quarter and whenever events or circumstances may indicate that an impairment has occurred.

[0001571996-25-000034:notes:276]
For the annual impairment review of the Infrastructure Solutions Group (“ISG”) and Client Solutions Group (“CSG”) reporting units during the third quarter of Fiscal 2025, the Company elected to bypass the assessment of qualitative factors to determine whether it was more likely than not that the fair value of a reporting unit was less than its carrying amount, including goodwill. In electing to bypass the qualitative assessment, the Company proceeded directly to perform a quantitative goodwill impairment test to measure the fair value of each goodwill reporting unit relative to its carrying amount, and to determine the amount of goodwill impairment loss to be recognized, if any. For the remaining reporting units, the Company performed a qualitative assessment of goodwill at the reporting unit level. The qualitative assessment included consideration of the relevant events and circumstances affecting the reporting unit, including macroeconomic, industry and market conditions, overall financial performance, and trends in the public company market valuation, where applicable. Additionally, Secureworks’ entry into an agreement, pursuant to which Secureworks was acquired in an all-cash transaction for approximately $0.9 billion, as discussed in Note 1 of the Notes to the Consolidated Financial Statements, provided a fair value indication that the Secureworks reporting unit exceeded its carrying value.

[0001571996-25-000034:notes:277]
Management exercised significant judgment related to the above assessments, including the identification of goodwill reporting units, assignment of assets and liabilities to goodwill reporting units, assignment of goodwill to reporting units, and determination of the fair value of each goodwill reporting unit. For the quantitative goodwill impairment test, the fair value of each goodwill reporting unit is generally estimated using a combination of public company multiples and discounted cash flow methodologies. The discounted cash flow and public company multiples methodologies require significant judgment, including estimation of future revenues, gross margins, and operating expenses, which are dependent on internal forecasts, current and anticipated economic conditions and trends, selection of market multiples through assessment of the reporting unit’s performance relative to peer competitors, the estimation of the long-term revenue growth rate and discount rate of the Company’s business, and the determination of the Company’s weighted average cost of capital. Changes in these estimates and assumptions could materially affect the fair value of the goodwill reporting unit, potentially resulting in a non-cash impairment charge.

[0001571996-25-000034:notes:278]
The fair value of the indefinite-lived trade names is generally estimated using discounted cash flow methodologies. These methodologies require significant judgment, including the estimation of future revenue, the estimation of the long-term revenue growth rate of the Company’s business and the determination of the Company’s weighted average cost of capital and royalty rates. Changes in these estimates and assumptions could materially affect the fair value of the indefinite-lived intangible assets, potentially resulting in a non-cash impairment charge.

[0001571996-25-000034:notes:279]
Based on the results of the annual impairment test performed during the fiscal year ended January 31, 2025, the fair values of each of the reporting units and indefinite-lived intangibles exceeded their carrying values. No goodwill or indefinite-lived assets impairment test was performed during the fiscal year ended January 31, 2025 other than the Company’s annual impairment review and the assessment of Secureworks.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001571996-25-000034:notes:280]
DEFERRED REVENUE 
Deferred revenue consists of support and deployment services, software maintenance, training, Software-as-a-Service, and undelivered hardware and professional services, consisting of installations and consulting engagements. Deferred revenue is recorded when the Company has invoiced or payments have been received for undelivered products or services where transfer of control has not occurred. Revenue is recognized as the Company’s performance obligations under the contract are completed.

[0001571996-25-000034:notes:281]
The following table presents the changes in the Company’s deferred revenue for the periods indicated:

[0001571996-25-000034:notes:282]
|  |  |  | Fiscal Year Ended |
|  |  |  |  |  | January 31, 2025 |  | February 2, 2024 |
|  |  |  |  |  | (in millions) |
| Deferred revenue: |  |  |  |  |  |  |  |
| Deferred revenue at beginning of period |  |  |  |  | $ | 29,145 |  |  | $ | 30,286 |  |
| Revenue deferrals |  |  |  |  | 18,135 |  |  | 20,866 |  |
| Revenue recognized |  |  |  |  | (21,179) |  |  | (22,022) |  |
| Other (a) |  |  |  |  | (136) |  |  | 15 |  |
| Deferred revenue at end of period |  |  |  |  | $ | 25,965 |  |  | $ | 29,145 |  |
| Short-term deferred revenue |  |  |  |  | $ | 13,673 |  |  | $ | 15,318 |  |
| Long-term deferred revenue |  |  |  |  | $ | 12,292 |  |  | $ | 13,827 |  |

[0001571996-25-000034:notes:283]
(a)For the fiscal year ended January 31, 2025, Other represents the reclassification of Secureworks deferred revenue to liabilities held for sale. See Note 1 of the Notes to the Consolidated Financial Statements for more information about the sale of Secureworks.

[0001571996-25-000034:notes:284]
Remaining Performance Obligations — Remaining performance obligations represent the aggregate amount of the transaction price allocated to performance obligations not delivered, or partially undelivered, as of the end of the reporting period. Remaining performance obligations include deferred revenue plus unbilled amounts not yet recorded in deferred revenue. The value of the transaction price allocated to remaining performance obligations as of January 31, 2025 was approximately $38 billion. The Company expects to recognize approximately 61% of remaining performance obligations as revenue in the next twelve months, 20% in the following twelve months, and the remainder thereafter.

[0001571996-25-000034:notes:285]
The aggregate amount of the transaction price allocated to remaining performance obligations does not include amounts owed under cancelable contracts where there is no substantive termination penalty. The Company applied the practical expedient to exclude the value of remaining performance obligations for contracts for which revenue is recognized at the amount to which the Company has the right to invoice for services performed.

[0001571996-25-000034:notes:286]
Remaining performance obligation estimates are subject to change and are affected by several factors, including terminations, changes in the scope of contracts, periodic revalidation, adjustments for revenue that have not materialized, and adjustments for currency.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001571996-25-000034:notes:287]
COMMITMENTS AND CONTINGENCIES 
Purchase Obligations

[0001571996-25-000034:notes:288]
The Company has contractual obligations to purchase goods or services, which specify significant terms (including fixed or minimum quantities to be purchased), fixed, minimum, or variable price provisions, and the approximate timing of the transaction. Purchase obligations are primarily related to commitments with suppliers and software maintenance and support services. As of January 31, 2025, such purchase obligations were $5.0 billion for Fiscal 2026, $0.6 billion for Fiscal 2027, and $0.9 billion for Fiscal 2028 and thereafter.

[0001571996-25-000034:notes:289]
Legal Matters

[0001571996-25-000034:notes:290]
The Company is involved in various claims, suits, assessments, investigations, and legal proceedings that arise from time to time in the ordinary course of its business, including those identified below, consisting of matters involving consumer, antitrust, tax, intellectual property, and other issues on a global basis.

[0001571996-25-000034:notes:291]
The Company accrues a liability when it believes that it is both probable that a liability has been incurred and that it can reasonably estimate the amount of the loss. The Company reviews these accruals at least quarterly and adjusts them to reflect ongoing negotiations, settlements, rulings, advice of legal counsel, and other relevant information. To the extent new information is obtained and the Company’s views on the probable outcomes of claims, suits, assessments, investigations, or legal proceedings change, changes in the Company’s accrued liabilities are recorded in the period in which such a determination is made. For some matters, the incurrence of a liability is not probable or the amount cannot be reasonably estimated and therefore accruals have not been made.

[0001571996-25-000034:notes:292]
The following is a discussion of the Company’s significant legal matters and other proceedings:

[0001571996-25-000034:notes:293]
Class Actions Related to the Class V Transaction — On December 28, 2018, the Company completed a transaction (the “Class V transaction”) in which it paid $14.0 billion in cash and issued 149,387,617 shares of its Class C Common Stock to holders of its Class V Common Stock in exchange for all outstanding shares of Class V Common Stock. As a result of the Class V transaction, the tracking stock feature of the Company’s capital structure associated with the Class V Common Stock was terminated. Certain stockholders of the Company subsequently brought class action complaints arising out of the Class V transaction in which they named as defendants (collectively, the “defendants”) Michael S. Dell and certain other directors serving on the Company’s board of directors at the time of the Class V transaction (collectively, the “director defendants”), certain stockholders of the Company, consisting of Mr. Dell and Silver Lake Group, L.L.C. and certain of its affiliated funds (collectively, the “stockholder defendants”), and Goldman Sachs & Co. LLC, which served as financial advisor to the Company in connection with the transaction. The plaintiffs generally alleged that the director defendants and the stockholder defendants breached their fiduciary duties under Delaware law to the former holders of the Class V Common Stock in connection with the Class V transaction by offering a transaction value that was allegedly billions of dollars below fair value.

[0001571996-25-000034:notes:294]
As previously reported, during the fourth quarter of the fiscal year ended February 3, 2023, the plaintiffs and the defendants entered into an agreement to settle the lawsuit. Under the terms of the settlement, the plaintiffs agreed to the dismissal of all claims upon payment of a total of $1.0 billion (the “settlement amount”), which included all costs, expenses and fees of the plaintiff class relating to the action and its resolution. On May 16, 2023, during the fiscal year ended February 2, 2024, the Company paid the settlement amount following approval of the settlement by the Delaware Court of Chancery. This matter is no longer material to the Company.

[0001571996-25-000034:notes:295]
R2 Semiconductor Patent Litigation — In November 2022, R2 Semiconductor, Inc. (“R2”) filed a lawsuit in the Dusseldorf Regional Court in Germany against Intel Deutschland GmbH, Dell GmbH, and certain other customers of Intel Corporation. R2 asserted that one European patent is infringed by certain Intel processors and those of the Company’s products that incorporate those processors. R2 sought an injunction prohibiting the sale of the allegedly infringing products and damages for the alleged infringement. The court conducted a trial on December 7, 2023 and, on February 7, 2024, issued a decision in favor of R2 and imposed an injunction prohibiting the sale and use of such products in Germany by Dell GmbH, and requiring Dell GmbH to issue a communication to certain customers recalling the covered products sold since March 5, 2020. On February 8, 2024, the Company filed an appeal. In April and May 2024, R2 filed lawsuits in Paris, France and Milan, Italy, against affiliates of Intel Corporation (“Intel”) and of the Company, raising similar allegations. Intel agreed to defend the foregoing actions and indemnify the Company and its affiliates against certain losses incurred by the Company in connection with R2’s claims. On August 30, 2024, Intel and R2 publicly announced an agreement to dismiss all litigation between the two companies that would include dismissal of all litigation against all subsidiaries of Dell Technologies named in the foregoing actions. Pursuant to that agreement, the Italian lawsuit was dismissed on September 2, 2024, the German lawsuit was dismissed on September 4, 2024, and the French lawsuit was dismissed on September 6, 2024.

[0001571996-25-000034:notes:296]
Other Litigation — Dell does not currently anticipate that any of the other legal proceedings it is involved in will have a material adverse effect on its business, financial condition, results of operations, or cash flows.

[0001571996-25-000034:notes:297]
In accordance with the relevant accounting guidance, the Company provides disclosures of matters where it is at least reasonably possible that the Company could experience a material loss exceeding the amounts already accrued for these or other proceedings or matters. In addition, the Company also discloses matters based on its consideration of other matters and qualitative factors, including the experience of other companies in the industry, and investor, customer, and employee relations considerations. As of January 31, 2025, the Company does not believe there is a reasonable possibility that a material loss exceeding the amounts already accrued for these or other proceedings or matters has been incurred. However, since the ultimate resolution of any such proceedings and matters is inherently unpredictable, the Company’s business, financial condition, results of operations, or cash flows could be materially affected in any particular period by unfavorable outcomes in one or more of these proceedings or matters. Whether the outcome of any claim, suit, assessment, investigation, or legal proceeding, individually or collectively, could have a material adverse effect on the Company’s business, financial condition, results of operations, or cash flows will depend on a number of factors, including the nature, timing, and amount of any associated expenses, amounts paid in settlement, damages, or other remedies or consequences.

[0001571996-25-000034:notes:298]
Indemnifications Obligations

[0001571996-25-000034:notes:299]
In the ordinary course of business, the Company enters into various contracts under which it may agree to indemnify other parties for losses incurred from certain events as defined in the relevant contract, such as litigation, regulatory penalties, or claims relating to past performance. Such indemnification obligations may not be subject to maximum loss clauses. Historically, payments related to these indemnification obligations have not been material to the Company.

[0001571996-25-000034:notes:300]
Under the Separation and Distribution Agreement entered into with VMware, Inc. upon completion of the spin-off of VMware, Inc. on November 1, 2021 (the “VMware Spin-off”), Dell Technologies agreed to indemnify VMware, Inc., each of its subsidiaries and each of their respective directors, officers, employees, as well as any successors and assigns of the foregoing, from and against all liabilities relating to, arising out of or resulting from, among other matters, the liabilities allocated to Dell Technologies as part of the separation of Dell Technologies and VMware, Inc. (currently operating under the name VMware LLC, and individually and together with its subsidiaries, “VMware”) and their respective businesses (the “Separation”). VMware similarly agreed to indemnify Dell Technologies Inc., each of its subsidiaries and each of their respective directors, officers, and employees from and against all liabilities relating to, arising out of or resulting from, among other matters, the liabilities allocated to VMware as part of the Separation. The amounts that VMware and Dell Technologies may be obligated to pay each other could vary depending on the outcome of certain unresolved tax matters, which may not be resolved for several years. Net income tax indemnification receivables from VMware were immaterial as of January 31, 2025 and February 2, 2024.

[0001571996-25-000034:notes:301]
Certain Concentrations

[0001571996-25-000034:notes:302]
The Company maintains cash and cash equivalents, derivatives, and certain other financial instruments with various financial institutions that potentially subject it to concentration of credit risk. As part of its risk management processes, the Company performs periodic evaluations of the relative credit standing of these financial institutions. The Company has not sustained material credit losses from instruments held at these financial institutions. Further, the Company does not anticipate nonperformance by any of the counterparties.

[0001571996-25-000034:notes:303]
The Company markets and sells its products and services to large corporate clients, governmental agencies, and health care and education accounts, as well as to small and medium-sized businesses and individuals. No single customer accounted for more than 10% of the Company’s consolidated net revenue during the fiscal years ended January 31, 2025, February 2, 2024, and February 3, 2023.

[0001571996-25-000034:notes:304]
The Company utilizes a limited number of contract manufacturers that assemble a portion of its products. The Company purchases components from suppliers and sells those components to such contract manufacturers. The Company reflects the sale of such components by recognizing non-trade receivables from the contract manufacturers and a reduction in inventory when title and risk of loss pass to the manufacturer. Cash flows related to such transactions are recorded within cash flows from operating activities. The Company does not reflect the sale of the components in revenue and does not recognize any profit on the component sales until the related products are sold to a customer.
The agreements with the majority of the contract manufacturers permit the Company to offset its payables against the receivables, thus mitigating the credit risk wholly or in part. Such receivables were $5.4 billion and $3.4 billion as of January 31, 2025 and February 2, 2024, respectively, and primarily consisted of receivables from the Company’s three largest contract manufacturers. The Company offset its corresponding payables against $4.7 billion and $2.7 billion of such receivables as of January 31, 2025 and February 2, 2024, respectively. The portion of receivables not offset is included in other current assets in the Consolidated Statements of Financial Position.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001571996-25-000034:notes:305]
INCOME AND OTHER TAXES
The following table presents components of the income tax expense (benefit) recognized for the periods indicated:

[0001571996-25-000034:notes:306]
|  | Fiscal Year Ended |
|  | January 31, 2025 |  | February 2, 2024 |  | February 3, 2023 |
|  | (in millions) |
| Current: |  |  |  |  |  |
| Federal | $ | (84) |  |  | $ | 161 |  |  | $ | 605 |  |
| State/local | (21) |  |  | 33 |  |  | 176 |  |
| Foreign | 785 |  |  | 612 |  |  | 739 |  |
| Current | 680 |  |  | 806 |  |  | 1,520 |  |
| Deferred: |  |  |  |  |  |
| Federal | (220) |  |  | (106) |  |  | (483) |  |
| State/local | (12) |  |  | (42) |  |  | (103) |  |
| Foreign | 24 |  |  | 57 |  |  | (131) |  |
| Deferred | (208) |  |  | (91) |  |  | (717) |  |
| Income tax expense | $ | 472 |  |  | $ | 715 |  |  | $ | 803 |  |

[0001571996-25-000034:notes:307]
The following table presents components of income (loss) before income taxes for the periods indicated:

[0001571996-25-000034:notes:308]
|  | Fiscal Year Ended |
|  | January 31, 2025 |  | February 2, 2024 |  | February 3, 2023 |
|  | (in millions) |
| Domestic | $ | (73) |  |  | $ | (52) |  |  | $ | (1,316) |  |
| Foreign | 5,121 |  |  | 4,139 |  |  | 4,541 |  |
| Income before income taxes | $ | 5,048 |  |  | $ | 4,087 |  |  | $ | 3,225 |  |

[0001571996-25-000034:notes:309]
The following table presents a reconciliation of the Company’s effective tax rate to the statutory U.S. federal tax rate for the periods indicated:

[0001571996-25-000034:notes:310]
|  | Fiscal Year Ended |
|  | January 31, 2025 |  | February 2, 2024 |  | February 3, 2023 |
| U.S. federal statutory rate | 21.0 | % |  | 21.0 | % |  | 21.0 | % |
| State income taxes, net of federal tax benefit | 1.4 |  |  | (0.2) |  |  | 2.0 |  |
| Tax impact of foreign operations | 0.6 |  |  | 2.1 |  |  | (0.8) |  |
| Change in valuation allowance | 1.1 |  |  | 0.3 |  |  | 0.4 |  |
| Non-deductible transaction-related costs | 0.1 |  |  | — |  |  | 0.8 |  |
| Stock-based compensation expense | (4.0) |  |  | (0.9) |  |  | (2.4) |  |
| U.S. R&D tax credits | (1.7) |  |  | (4.3) |  |  | (2.6) |  |
| Lapse of U.S. statutes of limitations | (8.5) |  |  | — |  |  | — |  |
| Class V transaction litigation settlement | — |  |  | — |  |  | 5.8 |  |
| Other | (0.6) |  |  | (0.5) |  |  | 0.7 |  |
| Total | 9.4 | % |  | 17.5 | % |  | 24.9 | % |

[0001571996-25-000034:notes:311]
Changes related to the Company’s effective tax rates for the fiscal years ended January 31, 2025, February 2, 2024, and February 3, 2023 were primarily attributable to discrete tax items and a change in the Company’s jurisdictional mix of income related to the tax impact of foreign operations and benefits from U.S. research and development tax credits. The Company’s effective tax rate for the fiscal year ended January 31, 2025 included discrete tax benefits of $0.4 billion related to the expiration of certain U.S. statutes of limitations and $0.2 billion related to stock-based compensation. The Company’s effective tax rate for the fiscal year ended February 3, 2023 included the impact of a $0.9 billion expense recognized in connection with the agreement to settle the Class V transaction litigation described in Note 11 of the Notes to the Consolidated Financial Statements.

[0001571996-25-000034:notes:312]
The differences between the effective income tax rates and the U.S. federal statutory rate of 21% principally result from the geographical distribution of income, differences between the book and tax treatment of certain items, and discrete tax items. In certain jurisdictions, the Company’s tax rate is significantly lower than the applicable statutory rate as a result of tax holidays. The majority of the Company’s foreign income subject to these tax holidays and lower tax rates is attributable to Singapore and China. Starting in the fiscal year ended January 31, 2025, the benefits of these tax holidays were limited by the impact of the Organisation for Economic Co-operation and Development’s Pillar Two global minimum tax. For the fiscal years ended January 31, 2025, February 2, 2024, and February 3, 2023, the income tax benefits attributable to the tax status of the affected subsidiaries were immaterial to the Company’s provision for income taxes and earnings per share.

[0001571996-25-000034:notes:313]
As of January 31, 2025, the Company has undistributed earnings of certain foreign subsidiaries of approximately $36.9 billion that remain indefinitely reinvested, and as such has not recognized a deferred tax liability. Determination of the amount of unrecognized deferred income tax liability related to these undistributed earnings is not practicable. The Company believes that a significant portion of the Company’s undistributed earnings as of January 31, 2025 will not be subject to further U.S. federal taxation.

[0001571996-25-000034:notes:314]
The following table presents the components of the Company’s net deferred tax assets (liabilities) as of the dates indicated:

[0001571996-25-000034:notes:315]
|  | January 31, 2025 |  | February 2, 2024 |
|  | (in millions) |
| Deferred tax assets: |  |  |  |
| Deferred revenue and warranty provisions | $ | 1,769 |  |  | $ | 1,878 |  |
| Credit carryforwards | 670 |  |  | 554 |  |
| Loss carryforwards | 697 |  |  | 619 |  |
| Operating and compensation related accruals | 482 |  |  | 478 |  |
| Capitalized research and development | 291 |  |  | 302 |  |
| Other | 256 |  |  | 320 |  |
| Deferred tax assets (a) | 4,165 |  |  | 4,151 |  |
| Valuation allowance | (1,368) |  |  | (1,232) |  |
| Deferred tax assets, net of valuation allowance | 2,797 |  |  | 2,919 |  |
| Deferred tax liabilities: |  |  |  |
| Leasing and financing | (285) |  |  | (397) |  |
| Property and equipment | (273) |  |  | (377) |  |
| Intangibles | (240) |  |  | (338) |  |
| Other | (393) |  |  | (375) |  |
| Deferred tax liabilities (a) | (1,191) |  |  | (1,487) |  |
| Net deferred tax assets | $ | 1,606 |  |  | $ | 1,432 |  |

[0001571996-25-000034:notes:316]
(a)Deferred tax assets and deferred tax liabilities are included in other non-current assets and other non-current liabilities in the Consolidated Statements of Financial Position.

[0001571996-25-000034:notes:317]
The following tables present the net operating loss carryforwards, tax credit carryforwards, and other deferred tax assets with related valuation allowances recognized as of the dates indicated:

[0001571996-25-000034:notes:318]
|  | January 31, 2025 |  |  |
|  | Deferred Tax Assets |  | Valuation Allowance |  | Net Deferred Tax Assets |  | First Year Expiring |
|  | (in millions) |  |  |
| Credit carryforwards | $ | 670 |  |  | $ | (664) |  |  | $ | 6 |  |  | Fiscal 2026 |
| Loss carryforwards | 697 |  |  | (484) |  |  | 213 |  |  | Fiscal 2026 |
| Other deferred tax assets | 2,798 |  |  | (220) |  |  | 2,578 |  |  | NA |
| Total | $ | 4,165 |  |  | $ | (1,368) |  |  | $ | 2,797 |  |  |  |
|  | February 2, 2024 |  |  |
|  | Deferred Tax Assets |  | Valuation Allowance |  | Net Deferred Tax Assets |  | First Year Expiring |
|  | (in millions) |  |  |
| Credit carryforwards | $ | 554 |  |  | $ | (549) |  |  | $ | 5 |  |  | Fiscal 2025 |
| Loss carryforwards | 619 |  |  | (405) |  |  | 214 |  |  | Fiscal 2025 |
| Other deferred tax assets | 2,978 |  |  | (278) |  |  | 2,700 |  |  | NA |
| Total | $ | 4,151 |  |  | $ | (1,232) |  |  | $ | 2,919 |  |  |  |

[0001571996-25-000034:notes:319]
The Company’s credit carryforwards as of January 31, 2025 and February 2, 2024 relate primarily to U.S. tax credits and include state tax credits associated with research and development, as well as foreign tax credits associated with the U.S. Tax Cuts and Jobs Act. The Company assessed the realizability of these U.S. tax credits and has recorded a valuation allowance against the credits it does not expect to utilize. The Company’s loss carryforwards as of January 31, 2025 and February 2, 2024 include net operating loss carryforwards from federal, state, and foreign jurisdictions. The valuation allowances for other deferred tax assets as of January 31, 2025 and February 2, 2024 primarily relate to foreign jurisdictions, the changes in which are included in the tax impact of foreign operations in the Company’s effective tax reconciliation. The Company has determined that it will be able to realize the remainder of its deferred tax assets.

[0001571996-25-000034:notes:320]
The following table presents the changes in the valuation allowance for deferred tax assets for the periods indicated:

[0001571996-25-000034:notes:321]
|  | Fiscal Year Ended |
|  | January 31, 2025 |  | February 2, 2024 |  | February 3, 2023 |
|  | (in millions) |
| Balance at beginning of period | $ | 1,232 |  |  | $ | 1,535 |  |  | $ | 1,423 |  |
| Charged to income tax provision | 277 |  |  | (299) |  |  | 84 |  |
| Charged to other accounts | (141) |  |  | (4) |  |  | 28 |  |
| Balance at end of period | $ | 1,368 |  |  | $ | 1,232 |  |  | $ | 1,535 |  |

[0001571996-25-000034:notes:322]
The following table presents a reconciliation of the Company’s beginning and ending balances of unrecognized tax benefits for the periods indicated:

[0001571996-25-000034:notes:323]
|  | Fiscal Year Ended |
|  | January 31, 2025 |  | February 2, 2024 |  | February 3, 2023 |
|  | (in millions) |
| Beginning Balance | $ | 2,367 |  |  | $ | 1,812 |  |  | $ | 1,595 |  |
| Increases related to tax positions of the current year | 121 |  |  | 4 |  |  | 132 |  |
| Increases related to tax position of prior years | 37 |  |  | 828 |  |  | 181 |  |
| Reductions for tax positions of prior years | (129) |  |  | (177) |  |  | (46) |  |
| Lapse of statutes of limitations | (388) |  |  | (35) |  |  | (41) |  |
| Audit settlements | (32) |  |  | (65) |  |  | (9) |  |
| Ending Balance | $ | 1,976 |  |  | $ | 2,367 |  |  | $ | 1,812 |  |

[0001571996-25-000034:notes:324]
The table above does not include accrued interest and penalties of $0.2 billion as of January 31, 2025 and $0.4 billion as of both February 2, 2024 and February 3, 2023. The table also does not include certain tax benefits associated with interest and state tax deductions and other indirect jurisdictional effects of uncertain tax positions, which were $1.3 billion, $1.4 billion, and $0.9 billion as of January 31, 2025, February 2, 2024, and February 3, 2023, respectively.

[0001571996-25-000034:notes:325]
After taking these items into account, the Company’s net unrecognized tax benefits were $0.9 billion as of January 31, 2025 and $1.3 billion as of February 2, 2024 and February 3, 2023, and are included in other non-current liabilities in the Consolidated Statements of Financial Position.

[0001571996-25-000034:notes:326]
The unrecognized tax benefits in the table above include $0.9 billion, $1.2 billion, and $1.1 billion as of January 31, 2025, February 2, 2024, and February 3, 2023, respectively, that, if recognized, would have impacted income tax expense. Interest and penalties related to income tax liabilities are included in income tax expense. The impact of interest and penalties on the Company’s tax provision was immaterial for the fiscal years ended January 31, 2025, February 2, 2024, and February 3, 2023.

[0001571996-25-000034:notes:327]
In June 2023, the Company received a Revenue Agent’s Report for the federal income tax examination by the Internal Revenue Service (“IRS”) of fiscal years 2018 through 2019. The IRS proposed adjustments primarily relating to certain transactions the Company completed as part of its business integration efforts. In August 2023, the Company submitted a written protest to the IRS relating to certain assessments. The Company received a rebuttal from the IRS to its written protest in April 2024. The Company disagrees with the IRS’s proposed adjustments and will contest them through the IRS administrative appeals procedures. The Company anticipates that the appeals process for the resolution of these matters will extend beyond the next twelve months. The IRS is also currently conducting a federal income tax examination of fiscal years 2020 through 2022.

[0001571996-25-000034:notes:328]
The Company is also currently under income tax audits in various U.S. state and foreign taxing jurisdictions. The Company is undergoing negotiations, and in some cases contested proceedings, relating to tax matters with the taxing authorities in these jurisdictions. With respect to major U.S. state and foreign taxing jurisdictions, the Company is generally not subject to tax examinations for years prior to the fiscal year ended February 2, 2018. The Company believes that it has provided adequate reserves related to all matters contained in tax periods open to examination, including the IRS audits described above. Although the Company believes it has made adequate provisions for the uncertainties with respect to these audits, should the Company experience unfavorable outcomes, such outcomes could have a material impact on its results of operations, financial position, and cash flows.

[0001571996-25-000034:notes:329]
Judgment is required in evaluating the Company’s uncertain tax positions and determining the Company’s provision for income taxes. The Company does not anticipate a significant change to the total amount of unrecognized tax benefits within the next twelve months.

[0001571996-25-000034:notes:330]
The Company takes certain non-income tax positions in the jurisdictions in which it operates and has received certain non-income tax assessments from various jurisdictions. The Company believes that a material loss in these matters is not probable and that it is not reasonably possible that a material loss exceeding amounts already accrued has been incurred. The Company believes its positions in these non-income tax litigation matters are supportable and that it ultimately will prevail in the matters. In the normal course of business, the Company’s positions and conclusions related to its non-income taxes could be challenged and assessments may be made. To the extent new information is obtained and the Company’s views on its positions, probable outcomes of assessments, or litigation change, changes in estimates to the Company’s accrued liabilities would be recorded in the period in which such a determination is made. In the resolution process for income tax and non-income tax audits, the Company is required in certain situations to provide collateral guarantees or indemnification to regulators and tax authorities until the matter is resolved.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001571996-25-000034:notes:331]
ACCUMULATED OTHER COMPREHENSIVE INCOME (LOSS) 
Accumulated other comprehensive income (loss) is presented in stockholders’ equity (deficit) in the Consolidated Statements of Financial Position and consists of amounts related to foreign currency translation adjustments, unrealized net gains (losses) on cash flow hedges, and actuarial net gains (losses) from pension and other postretirement plans.

[0001571996-25-000034:notes:332]
The following table presents changes in accumulated other comprehensive income (loss), net of tax, by the following components as of the dates indicated:

[0001571996-25-000034:notes:333]
|  | Foreign Currency Translation Adjustments |  |  |  | Cash Flow Hedges |  | Pension and Other Postretirement Plans |  | Accumulated Other Comprehensive Income (Loss) |
|  | (in millions) |
| Balances as of January 28, 2022 | $ | (526) |  |  |  |  | $ | 129 |  |  | $ | (34) |  |  | $ | (431) |  |
| Other comprehensive income (loss) before reclassifications | (222) |  |  |  |  | 354 |  |  | 1 |  |  | 133 |  |
| Amounts reclassified from accumulated other comprehensive income (loss) | — |  |  |  |  | (705) |  |  | 1 |  |  | (704) |  |
| Total change for the period | (222) |  |  |  |  | (351) |  |  | 2 |  |  | (571) |  |
| Less: Change in comprehensive loss attributable to non-controlling interests | (1) |  |  |  |  | — |  |  | — |  |  | (1) |  |
| Balances as of February 3, 2023 | $ | (747) |  |  |  |  | $ | (222) |  |  | $ | (32) |  |  | $ | (1,001) |  |
| Other comprehensive income (loss) before reclassifications | (8) |  |  |  |  | 85 |  |  | 15 |  |  | 92 |  |
| Amounts reclassified from accumulated other comprehensive income (loss) | — |  |  |  |  | 107 |  |  | 2 |  |  | 109 |  |
| Total change for the period | (8) |  |  |  |  | 192 |  |  | 17 |  |  | 201 |  |
| Balances as of February 2, 2024 | $ | (755) |  |  |  |  | $ | (30) |  |  | $ | (15) |  |  | $ | (800) |  |
| Other comprehensive income (loss) before reclassifications | (268) |  |  |  |  | 246 |  |  | — |  |  | (22) |  |
| Amounts reclassified from accumulated other comprehensive income (loss) | — |  |  |  |  | (111) |  |  | (6) |  |  | (117) |  |
| Total change for the period | (268) |  |  |  |  | 135 |  |  | (6) |  |  | (139) |  |
| Balances as of January 31, 2025 | $ | (1,023) |  |  |  |  | $ | 105 |  |  | $ | (21) |  |  | $ | (939) |  |

[0001571996-25-000034:notes:334]
Amounts related to the Company’s cash flow hedges are reclassified to net income during the same period in which the items being hedged are recognized in earnings. See Note 8 of the Notes to the Consolidated Financial Statements for more information about the Company’s derivative instruments.

[0001571996-25-000034:notes:335]
The following table presents reclassifications out of accumulated other comprehensive income (loss), net of tax, to net income for the periods indicated:

[0001571996-25-000034:notes:336]
|  |  |  | Fiscal Year Ended |
|  |  |  | January 31, 2025 |  | February 2, 2024 |  | February 3, 2023 |
|  |  |  | Cash Flow Hedges |  |  |  |  |  | Pensions |  |  |  | Total |  | Cash Flow Hedges |  | Pensions |  | Total |  | Cash Flow Hedges |  | Pensions |  | Total |
|  |  |  | (in millions) |
| Total reclassifications, net of tax: |  |  |  |  |  |  |
| Net revenue |  |  | $ | 100 |  |  |  |  |  |  | $ | — |  |  |  |  | $ | 100 |  |  | $ | (98) |  |  | $ | — |  |  | $ | (98) |  |  | $ | 736 |  |  | $ | — |  |  | $ | 736 |  |
| Cost of net revenue |  |  | 11 |  |  |  |  |  |  | — |  |  |  |  | 11 |  |  | (9) |  |  | — |  |  | (9) |  |  | (31) |  |  | — |  |  | (31) |  |
| Operating expenses |  |  | — |  |  |  |  |  |  | 6 |  |  |  |  | 6 |  |  | — |  |  | (2) |  |  | (2) |  |  | — |  |  | (1) |  |  | (1) |  |
| Total reclassifications, net of tax |  |  | $ | 111 |  |  |  |  |  |  | $ | 6 |  |  |  |  | $ | 117 |  |  | $ | (107) |  |  | $ | (2) |  |  | $ | (109) |  |  | $ | 705 |  |  | $ | (1) |  |  | $ | 704 |  |


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001571996-25-000034:notes:337]
CAPITALIZATION 
The following table presents the Company’s authorized, issued, and outstanding common stock as of the dates indicated:

[0001571996-25-000034:notes:338]
|  | Authorized |  | Issued |  | Outstanding |
|  | (in millions) |
| Common stock as of January 31, 2025 |
| Class A | 600 |  |  | 277 |  |  | 277 |  |
| Class B | 200 |  |  | 62 |  |  | 62 |  |
| Class C | 7,900 |  |  | 495 |  |  | 357 |  |
| Class D | 100 |  |  | — |  |  | — |  |
|  | 8,800 |  |  | 834 |  |  | 696 |  |
| Common stock as of February 2, 2024 |
| Class A | 600 |  |  | 353 |  |  | 353 |  |
| Class B | 200 |  |  | 86 |  |  | 86 |  |
| Class C | 7,900 |  |  | 382 |  |  | 266 |  |
| Class D | 100 |  |  | — |  |  | — |  |
|  | 8,800 |  |  | 821 |  |  | 705 |  |

[0001571996-25-000034:notes:339]
Preferred Stock

[0001571996-25-000034:notes:340]
The Company is authorized to issue one million shares of preferred stock, par value $0.01 per share. As of January 31, 2025 and February 2, 2024, no shares of preferred stock were issued or outstanding.

[0001571996-25-000034:notes:341]
Common Stock

[0001571996-25-000034:notes:342]
Dell Technologies Common Stock — The Class A Common Stock, the Class B Common Stock, the Class C Common Stock, and the Class D Common Stock are collectively referred to as Dell Technologies Common Stock. The par value for all series of Dell Technologies Common Stock is $0.01 per share. The Class A Common Stock, the Class B Common Stock, the Class C Common Stock, and the Class D Common Stock share equally in dividends declared or accumulated and have equal participation rights in undistributed earnings.

[0001571996-25-000034:notes:343]
Voting Rights — Each holder of record of (a) Class A Common Stock is entitled to ten votes per share of Class A Common Stock; (b) Class B Common Stock is entitled to ten votes per share of Class B Common Stock; (c) Class C Common Stock is entitled to one vote per share of Class C Common Stock; and (d) Class D Common Stock is not entitled to any vote on any matter except to the extent required by provisions of Delaware law (in which case such holder is entitled to one vote per share of Class D Common Stock).

[0001571996-25-000034:notes:344]
Conversion Rights — Under the Company’s certificate of incorporation, at any time and from time to time, any holder of Class A Common Stock or Class B Common Stock has the right to convert all or any of the shares of Class A Common Stock or Class B Common Stock, as applicable, held by such holder into shares of Class C Common Stock on a one-to-one basis.

[0001571996-25-000034:notes:345]
During the fiscal year ended January 31, 2025, the Company issued 100 million shares of Class C Common Stock to stockholders upon the conversion of 76 million shares of Class A Common Stock and 24 million shares of Class B Common Stock in accordance with the Company’s certificate of incorporation.

[0001571996-25-000034:notes:346]
During the fiscal year ended February 2, 2024, the Company issued 34 million shares of Class C Common Stock to stockholders upon the conversion of 25 million shares of Class A Common Stock and 9 million shares of Class B Common Stock in accordance with the Company’s certificate of incorporation.

[0001571996-25-000034:notes:347]
During the fiscal year ended February 3, 2023, there were no conversions of shares of Class A Common Stock or Class B Common Stock into shares of Class C Common Stock.

[0001571996-25-000034:notes:348]
Dividends

[0001571996-25-000034:notes:349]
The Company paid the following dividends during the periods presented:

[0001571996-25-000034:notes:350]
|  |  | Declaration Date |  | Record Date |  | Payment Date |  | Dividend per Share |  | Amount (in millions) |
|  |  | Fiscal 2025 |
|  |  | February 29, 2024 |  | April 23, 2024 |  | May 3, 2024 |  | $ | 0.445 |  |  | $ | 316 |  |
|  |  | June 11, 2024 |  | July 23, 2024 |  | August 2, 2024 |  | $ | 0.445 |  |  | $ | 314 |  |
|  |  | September 18, 2024 |  | October 22, 2024 |  | November 1, 2024 |  | $ | 0.445 |  |  | $ | 312 |  |
|  |  | December 3, 2024 |  | January 22, 2025 |  | January 31, 2025 |  | $ | 0.445 |  |  | $ | 310 |  |
|  |  | Fiscal 2024 |
|  |  | March 2, 2023 |  | April 25, 2023 |  | May 5, 2023 |  | $ | 0.37 |  |  | $ | 270 |  |
|  |  | June 16, 2023 |  | July 25, 2023 |  | August 4, 2023 |  | $ | 0.37 |  |  | $ | 268 |  |
|  |  | September 28, 2023 |  | October 24, 2023 |  | November 3, 2023 |  | $ | 0.37 |  |  | $ | 266 |  |
|  |  | December 5, 2023 |  | January 23, 2024 |  | February 2, 2024 |  | $ | 0.37 |  |  | $ | 261 |  |

[0001571996-25-000034:notes:351]
During the fiscal year ended January 31, 2025 and February 2, 2024, the Company also paid an immaterial amount of dividend equivalents on eligible vested equity awards which are not included above.

[0001571996-25-000034:notes:352]
On February 27, 2025, subsequent to the close of the Company’s fiscal year ended January 31, 2025, the Company announced that the Board of Directors approved an 18% increase in the dividend rate to $0.525 per share per fiscal quarter beginning in the first quarter of the fiscal year ending January 30, 2026.

[0001571996-25-000034:notes:353]
Repurchases of Common Stock

[0001571996-25-000034:notes:354]
On September 23, 2021, the Company’s Board of Directors approved the Company’s current stock repurchase program with no fixed expiration date under which the Company may repurchase up to $5 billion of shares of Class C Common Stock, exclusive of any fees, commissions, or other expenses related to such repurchases. On October 5, 2023 and February 27, 2025, subsequent to the close of the fiscal year ended January 31, 2025, the Company’s Board of Directors authorized additional shares for repurchase under the program of $5 billion and $10 billion, respectively. Following the February 27, 2025 approval, the Company had approximately $11.5 billion of authorized shares remaining under the program.

[0001571996-25-000034:notes:355]
During the fiscal year ended January 31, 2025, the Company repurchased approximately 22 million shares of Class C Common Stock for a total purchase price of approximately $2.6 billion. During the fiscal year ended February 2, 2024, the Company repurchased approximately 34 million shares of Class C Common Stock for a total purchase price of approximately $2.1 billion. During the fiscal year ended February 3, 2023, the Company repurchased approximately 62 million shares of Class C Common Stock for a total purchase price of approximately $2.8 billion.
The above repurchases of Class C Common Stock exclude U.S. federal excise taxes and shares withheld from stock awards to settle employee tax withholding obligations related to the vesting of such awards.


## us-gaap:EarningsPerShareTextBlock

[0001571996-25-000034:notes:356]
EARNINGS PER SHARE
Basic earnings per share is based on the weighted-average effect of all common shares issued and outstanding and is calculated by dividing net income by the weighted-average shares outstanding during the period. Diluted earnings per share is calculated by dividing net income by the weighted-average number of common shares used in the basic earnings per share calculation plus the number of common shares that would be issued assuming exercise or conversion of all potentially dilutive instruments. The Company excludes equity instruments from the calculation of diluted earnings per share if the effect of including such instruments is antidilutive.

[0001571996-25-000034:notes:357]
The following table presents basic and diluted earnings per share for the periods indicated:

[0001571996-25-000034:notes:358]
|  |  |  | Fiscal Year Ended |
|  |  |  |  |  | January 31, 2025 |  | February 2, 2024 |  | February 3, 2023 |
| Earnings per share attributable to Dell Technologies Inc. |  |  |
| Dell Technologies Common Stock — Basic |  |  |  |  | $ | 6.51 |  |  | $ | 4.71 |  |  | $ | 3.33 |  |
| Dell Technologies Common Stock — Diluted |  |  |  |  | $ | 6.38 |  |  | $ | 4.60 |  |  | $ | 3.24 |  |

[0001571996-25-000034:notes:359]
The following table presents the computation of basic and diluted earnings per share for the periods indicated:

[0001571996-25-000034:notes:360]
|  |  |  | Fiscal Year Ended |
|  |  |  |  |  | January 31, 2025 |  | February 2, 2024 |  | February 3, 2023 |
|  |  |  |  |  | (in millions) |
| Numerator: Dell Technologies Common Stock |  |  |  |  |  |  |  |  |  |
| Net income attributable to Dell Technologies Inc. — basic and diluted |  |  |  |  | $ | 4,592 |  |  | $ | 3,388 |  |  | $ | 2,442 |  |
| Denominator: Dell Technologies Common Stock weighted-average shares outstanding |  |  |  |  |  |  |  |  |  |
| Weighted-average shares outstanding — basic |  |  |  |  | 705 |  |  | 720 |  |  | 734 |  |
| Dilutive effect of equity awards |  |  |  |  | 15 |  |  | 16 |  |  | 19 |  |
| Weighted-average shares outstanding — diluted |  |  |  |  | 720 |  |  | 736 |  |  | 753 |  |
| Weighted-average shares outstanding — antidilutive |  |  |  |  | — |  |  | 4 |  |  | 9 |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001571996-25-000034:notes:361]
STOCK-BASED COMPENSATION 
The following table presents stock-based compensation expense recognized in the Consolidated Statements of Income for the periods indicated:

[0001571996-25-000034:notes:362]
|  | Fiscal Year Ended |
|  | January 31, 2025 |  | February 2, 2024 |  | February 3, 2023 |
|  | (in millions) |
| Stock-based compensation expense: |  |  |  |  |  |
| Cost of net revenue | $ | 152 |  |  | $ | 149 |  |  | $ | 152 |  |
| Operating expenses | 633 |  |  | 729 |  |  | 779 |  |
| Total stock-based compensation expense before taxes | 785 |  |  | 878 |  |  | 931 |  |
| Income tax benefit | (143) |  |  | (157) |  |  | (163) |  |
| Total stock-based compensation expense, net of income taxes | $ | 642 |  |  | $ | 721 |  |  | $ | 768 |  |

[0001571996-25-000034:notes:363]
Dell Technologies Inc. Stock-Based Compensation Plan

[0001571996-25-000034:notes:364]
Dell Technologies Inc. 2023 Stock Incentive Plan — Employees, consultants, non-employee directors, and other service providers of the Company or its affiliates are eligible to participate in the Dell Technologies Inc. 2023 Stock Incentive Plan, which became effective on June 20, 2023 upon its approval by stockholders (the “2023 Plan”). The 2023 Plan authorizes the Company to grant stock options, restricted stock units (“RSUs”), stock appreciation rights (“SARs”), restricted stock awards, deferred stock units, and dividend equivalents. The 2023 Plan replaced the Dell Technologies Inc. 2013 Stock Incentive Plan (as amended and restated, the “2013 Plan”). Upon effectiveness of the 2023 Plan, no further awards were authorized for grant under the 2013 Plan.

[0001571996-25-000034:notes:365]
The 2023 Plan authorizes the issuance of an aggregate of up to approximately 103.3 million shares of the Class C Common Stock, including (a) 50.0 million shares of Class C Common Stock that were authorized for offering and issuance under the 2023 Plan, (b) approximately 7.0 million shares of Class C Common Stock that remained available for issuance under the 2013 Plan as of the effective date of the 2023 Plan, and (c) up to approximately 46.3 million shares of Class C Common Stock subject to awards outstanding under the 2013 Plan as of the effective date of the 2023 Plan that subsequently expire or terminate prior to exercise or settlement. As of January 31, 2025, there were approximately 54 million shares of Class C Common Stock available for future grants under the 2023 Plan.

[0001571996-25-000034:notes:366]
Restricted Stock — The Company’s awards primarily consist of RSUs granted to employees. During the fiscal years ended January 31, 2025, February 2, 2024, and February 3, 2023, the Company granted long-term incentive awards in the form of service-based RSUs and performance-based RSUs (“PSUs”) in order to align critical talent retention programs with the interests of holders of the Class C Common Stock.

[0001571996-25-000034:notes:367]
Service-based RSUs have a fair value based on the closing price of the Class C Common Stock price as reported on the NYSE on the grant date or the trade day immediately preceding the grant date, if the grant date falls on a non-trading day. The majority of such RSUs vest ratably over a three-year period. Each service-based RSU represents the right to acquire one share of Class C Common Stock upon vesting.

[0001571996-25-000034:notes:368]
The PSUs granted during the periods presented are reflected as target units for performance periods not yet complete. The actual number of units that ultimately vest will range from 0% to 200% of target, based on the level of achievement of the performance goals and continued employment with the Company over a three-year performance period. Approximately half of the PSUs granted are subject to achievement of market-based performance goals based on relative total shareholder return and were valued utilizing a Monte Carlo valuation model to simulate the probabilities of achievement. The remaining PSUs are subject to internal financial measures and have fair values based on the closing price of the Class C Common Stock as reported on the NYSE on the accounting grant date.

[0001571996-25-000034:notes:369]
Beginning with grants made during the fiscal year ended February 3, 2023, dividend equivalents accrue on outstanding RSUs and PSUs when a dividend is paid to the Company’s common stockholders. Accrued dividend equivalents will be paid when the underlying RSUs and PSUs vest.

[0001571996-25-000034:notes:370]
The following table presents the assumptions utilized in the Monte Carlo valuation model for the periods indicated:

[0001571996-25-000034:notes:371]
|  | Fiscal Year Ended |
|  | January 31, 2025 |  | February 2, 2024 |  | February 3, 2023 |
| Weighted-average grant date fair value | $ | 172.99 |  | $ | 43.91 |  | $ | 73.26 |
| Term (in years) | 3 |  | 3 |  | 3 |
| Risk-free rate (U.S. Government Treasury Note) | 4.4 | % |  | 3.8 | % |  | 2.0 | % |
| Expected volatility | 39 | % |  | 35 | % |  | 39 | % |
| Expected dividend yield | — | % |  | — | % |  | — | % |

[0001571996-25-000034:notes:372]
The following table presents RSU activity settled in Class C Common Stock for the periods indicated:

[0001571996-25-000034:notes:373]
|  | Number of Units |  | Weighted-Average Grant Date Fair Value |  | Aggregate Intrinsic Value (a) |
|  | (in millions) |  | (per unit) |  |  |
| Outstanding as of January 28, 2022 | 59 |  |  | $ | 31.67 |  |  |  |
| Granted | 23 |  |  | 48.11 |  |  |  |
| Vested | (27) |  |  | 29.96 |  |  |  |
| Forfeited | (5) |  |  | 39.26 |  |  |  |
| Outstanding as of February 3, 2023 | 50 |  |  | 39.44 |  |  |  |
| Granted | 23 |  |  | 39.62 |  |  |  |
| Vested | (31) |  |  | 32.02 |  |  |  |
| Forfeited | (3) |  |  | 46.99 |  |  |  |
| Outstanding as of February 2, 2024 | 39 |  |  | 44.68 |  |  |  |
| Granted | 9 |  |  | 102.35 |  |  |  |
| Vested | (18) |  |  | 43.33 |  |  |  |
| Forfeited | (4) |  |  | 56.93 |  |  |  |
| Outstanding as of January 31, 2025 (b) | 26 |  |  | $ | 60.51 |  |  | $ | 2,673 |  |
| Vested and expected to vest, January 31, 2025 | 25 |  |  | $ | 59.82 |  |  | $ | 2,551 |  |

[0001571996-25-000034:notes:374]
(a)The aggregate intrinsic value represents the total pre-tax intrinsic values based on the closing price of $103.60 of the Class C Common Stock on January 31, 2025 as reported on the NYSE that would have been received by the RSU holders if the RSUs had been issued as of January 31, 2025.

[0001571996-25-000034:notes:375]
(b)As of January 31, 2025, the 26 million units outstanding included 21 million RSUs and 5 million PSUs.

[0001571996-25-000034:notes:376]
The total fair value of RSU awards that vested during the fiscal years ended January 31, 2025, February 2, 2024, and February 3, 2023 was $795 million, $973 million, and $827 million, respectively, with a pre-tax intrinsic value of $1,984 million, $1,230 million, and $1,371 million, respectively.

[0001571996-25-000034:notes:377]
As of January 31, 2025, there was $772 million of unrecognized stock-based compensation expense, net of estimated forfeitures, related to these awards expected to be recognized over a weighted-average period of approximately 1.7 years.

[0001571996-25-000034:notes:378]
Dell Technologies Shares Withheld for Taxes — Beginning in the fiscal year ended February 3, 2023, shares of Class C Common Stock are generally withheld from issuance to cover employee taxes for the vesting of restricted stock units. For the fiscal years ended January 31, 2025, February 2, 2024, and February 3, 2023, 5.0 million, 9.0 million, and 8.0 million shares, respectively, were withheld to cover $568 million, $366 million, and $388 million, respectively, of employees’ tax obligations. The value of the withheld shares was classified as a reduction to common stock and capital in excess of par value.

[0001571996-25-000034:notes:379]
Stock Option Activity — In addition to RSU activity, the Company also had stock option activity which was not material during the fiscal years ended January 31, 2025, February 2, 2024, and February 3, 2023. Stock options are granted with option exercise prices equal to the fair market value of the Company’s Class C Common Stock and expire ten years after the grant date.

[0001571996-25-000034:notes:380]
Other Plans
In addition to the 2023 Plan described above, the Company’s consolidated subsidiary, Secureworks, maintains its own equity plan and issues equity grants settling in its Class A common stock. The stock option and restricted stock unit activity under this plan was not material to the Company during the fiscal years ended January 31, 2025, February 2, 2024, and February 3, 2023.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001571996-25-000034:notes:381]
RETIREMENT PLAN BENEFITS 
Defined Benefit Retirement Plans

[0001571996-25-000034:notes:382]
The Company sponsors retirement plans for certain employees, some of which meet the criteria of a defined benefit retirement plan. Benefits under defined benefit retirement plans guarantee a particular payment to the employee in retirement. The amount of retirement benefit is defined by the plan and is typically a function of the number of years of service rendered by the employee and the employee’s average salary or salary at retirement. The annual costs of the plans are determined using the projected unit credit actuarial cost method that includes actuarial assumptions and estimates which are subject to change.

[0001571996-25-000034:notes:383]
U.S. Pension Plan — The Company sponsored a noncontributory defined benefit retirement plan in the United States (the “U.S. pension plan”), which was assumed in connection with the EMC merger transaction that was completed in September 2016. As of December 1999, the U.S. pension plan was frozen, so employees no longer accrue retirement benefits for future services.

[0001571996-25-000034:notes:384]
On August 20, 2024, the Company’s Board of Directors approved an amendment to terminate the U.S. pension plan with an effective date of September 30, 2024. The Company is transitioning the U.S. pension plan to a qualified insurance company and expects settlement in 12 to 18 months from the termination effective date. The Company does not expect the settlement of the U.S. pension plan obligations to have a material impact on its Consolidated Financial Statements.

[0001571996-25-000034:notes:385]
The measurement date for the U.S. pension plan is the end of the Company’s fiscal year. The Company did not make any material contributions to the U.S. pension plan for the fiscal years ended January 31, 2025, February 2, 2024, and February 3, 2023. Net periodic benefit costs related to the U.S. pension plan were immaterial for the fiscal years ended January 31, 2025, February 2, 2024, and February 3, 2023.

[0001571996-25-000034:notes:386]
The following table presents attributes of the U.S. pension plan as of the dates indicated:

[0001571996-25-000034:notes:387]
|  | January 31, 2025 |  | February 2, 2024 |
|  | (in millions) |
| Plan assets at fair value (a) | $ | 423 |  |  | $ | 440 |  |
| Benefit obligations | (437) |  |  | (457) |  |
| Underfunded position (b) | $ | (14) |  |  | $ | (17) |  |

[0001571996-25-000034:notes:388]
(a)Plan assets are managed by outside investment managers. Assets are recognized at fair value and are primarily classified within Level 2 of the fair value hierarchy.

[0001571996-25-000034:notes:389]
(b)The underfunded position of the U.S. pension plan is recognized in other non-current liabilities in the Consolidated Statements of Financial Position.

[0001571996-25-000034:notes:390]
As of January 31, 2025, future benefit payments for the U.S. pension plan are expected to be paid as follows: $38 million in Fiscal 2026; $39 million in Fiscal 2027; $39 million in Fiscal 2028; $39 million in Fiscal 2029; $38 million in Fiscal 2030; and $176 million from Fiscal 2031 through Fiscal 2035.

[0001571996-25-000034:notes:391]
International Pension Plans — The Company also sponsors retirement plans outside of the United States that qualify as defined benefit plans. The following table presents attributes of the international pension plans as of the dates indicated:

[0001571996-25-000034:notes:392]
|  | January 31, 2025 |  | February 2, 2024 |
|  | (in millions) |
| Plan assets at fair value (a) | $ | 228 |  |  | $ | 224 |  |
| Benefit obligations | (438) |  |  | (420) |  |
| Underfunded position (b) | $ | (210) |  |  | $ | (196) |  |

[0001571996-25-000034:notes:393]
(a)Plan assets are managed by outside investment managers. The Company’s investment strategy with respect to plan assets is to achieve a long-term growth of capital, consistent with an appropriate level of risk. Assets are recognized at fair value and are primarily classified within Level 2 of the fair value hierarchy for the fiscal year ended January 31, 2025 and were primarily classified within Level 1 of the fair value hierarchy for the fiscal year ended February 2, 2024.

[0001571996-25-000034:notes:394]
(b)The underfunded position is recognized in other non-current liabilities in the Consolidated Statements of Financial Position.

[0001571996-25-000034:notes:395]
Defined Contribution Retirement Plans
Dell 401(k) Plan — The Company maintains a defined contribution retirement plan (the “Dell 401(k) Plan”) that complies with Section 401(k) of the Internal Revenue Code. Only U.S. employees and employees of certain subsidiaries, except those who are covered by a collective bargaining agreement, classified as a leased employee or a nonresident alien, or are covered under a separate plan, are eligible to participate in the Dell 401(k) Plan. Participation in the Dell 401(k) Plan is at the election of the employee. As of January 31, 2025, the Company matched 100% of each participant’s voluntary contributions (the “Dell 401(k) employer match”), subject to a maximum contribution of 6% of the participant’s eligible compensation, up to an annual limit of $7,500. Participants vest immediately in all contributions to the Dell 401(k) Plan. The Company’s matching contributions as well as participants’ voluntary contributions are invested according to each participant’s elections in the investment options provided under the Dell 401(k) Plan. The Company’s contributions during the fiscal years ended January 31, 2025, February 2, 2024, and February 3, 2023 were $218 million, $238 million, and $263 million, respectively.


## us-gaap:ScheduleOfChangesInFairValueOfPlanAssetsTableTextBlock

[0001571996-25-000034:notes:396]
(b)The underfunded position of the U.S. pension plan is recognized in other non-current liabilities in the Consolidated Statements of Financial Position. 
The following table presents attributes of the international pension plans as of the dates indicated:

[0001571996-25-000034:notes:397]
(a)Plan assets are managed by outside investment managers. The Company’s investment strategy with respect to plan assets is to achieve a long-term growth of capital, consistent with an appropriate level of risk. Assets are recognized at fair value and are primarily classified within Level 2 of the fair value hierarchy for the fiscal year ended January 31, 2025 and were primarily classified within Level 1 of the fair value hierarchy for the fiscal year ended February 2, 2024.
(b)The underfunded position is recognized in other non-current liabilities in the Consolidated Statements of Financial Position.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001571996-25-000034:notes:398]
SEGMENT INFORMATION 
The Company reports its financial results through two reportable segments which are based on the following business units: Infrastructure Solutions Group (“ISG”) and Client Solutions Group (“CSG”). The Company organizes its reportable segments based on the manner in which management evaluates the performance of the Company.

[0001571996-25-000034:notes:399]
The Company’s Chief Executive Officer is the Chief Operating Decision Maker (“CODM”). The CODM is regularly provided and reviews segment revenue and segment operating income to assess the performance of each segment and allocate resources to the segments in the annual planning process. The Company’s measure of segment revenue and segment operating income for management reporting purposes excludes Corporate and other, amortization of intangible assets, stock-based compensation expense, and other corporate expenses, as applicable, which are not used in evaluating the results of, or in allocating resources to, the segments. The Company does not allocate assets to the above reportable segments for internal reporting purposes. Additionally, the accounting policies of the segments are the same as those described in Note 2 of the Notes to the Consolidated Financial Statements.

[0001571996-25-000034:notes:400]
ISG includes the Company’s servers and networking offerings and storage offerings. The Company’s server portfolio includes high-performance general-purpose and AI-optimized servers. The Company’s networking portfolio includes wide area network infrastructure, data center and edge networking switches, and cables and optics. The Company’s comprehensive storage portfolio includes modern and traditional storage solutions, including all-flash arrays, scale-out file, object platforms, hyper-converged infrastructure, and software-defined storage. ISG also offers software, peripherals, and services, including consulting and support and deployment.

[0001571996-25-000034:notes:401]
CSG includes the Company’s commercial offerings and consumer offerings. The Company’s CSG portfolio includes branded PCs, including notebooks, desktops, and workstations and branded peripherals that include displays, docking stations, keyboards, mice, and webcam and audio devices, as well as third-party software and peripherals. CSG also includes services offerings, such as configuration, support and deployment, and extended warranties.

[0001571996-25-000034:notes:402]
Following its acquisition by Broadcom on November 22, 2023, VMware announced changes to its go-to-market approach for VMware offerings that impacted the Company’s commercial relationship with VMware. On March 25, 2024, the Company terminated the Commercial Framework Agreement with VMware, which provided the framework pursuant to which the Company and VMware continued the commercial relationship following the VMware Spin-off described in Note 11 of the Notes to the Consolidated Financial Statements and under which Dell Technologies acted as a distributor of Broadcom’s VMware stand-alone products and services and purchased such products and services for resale to end-user customers (“VMware Resale”). Dell Technologies no longer acts as a distributor of VMware’s standalone products and services, although the Company will continue to support customers that have purchased resale offerings sold in prior periods. The results of VMware Resale transactions are reflected in Corporate and other. The Company continues to integrate and embed certain VMware products and services with select Dell Technologies’ offerings to end-users. The results of such offerings are reflected within CSG or ISG, depending upon the nature of the underlying offering sold.

[0001571996-25-000034:notes:403]
The following table presents a reconciliation of net revenue by the Company’s reportable segments to the Company’s consolidated net revenue as well as a reconciliation of segment operating income to the Company’s consolidated operating income for the periods indicated:

[0001571996-25-000034:notes:404]
|  |  |  | Fiscal Year Ended |
|  |  |  |  |  | January 31, 2025 |  | February 2, 2024 |  | February 3, 2023 |
|  |  |  |  |  | (in millions) |
| Consolidated net revenue: |  |  |  |  |  |  |  |  |  |
| Infrastructure Solutions Group |  |  |  |  | $ | 43,593 |  |  | $ | 33,885 |  |  | $ | 38,356 |  |
| Client Solutions Group |  |  |  |  | 48,393 |  |  | 48,916 |  |  | 58,213 |  |
| Reportable segment net revenue |  |  |  |  | 91,986 |  |  | 82,801 |  |  | 96,569 |  |
| Corporate and other (a) |  |  |  |  | 3,581 |  |  | 5,624 |  |  | 5,732 |  |
| Total consolidated net revenue |  |  |  |  | $ | 95,567 |  |  | $ | 88,425 |  |  | $ | 102,301 |  |
| Consolidated operating income: |  |  |  |  |  |  |  |  |  |
| Infrastructure Solutions Group |  |  |  |  | $ | 5,579 |  |  | $ | 4,286 |  |  | $ | 5,045 |  |
| Client Solutions Group |  |  |  |  | 2,972 |  |  | 3,712 |  |  | 3,824 |  |
| Reportable segment operating income (b) |  |  |  |  | 8,551 |  |  | 7,998 |  |  | 8,869 |  |
| Corporate and other (a) |  |  |  |  | (22) |  |  | (120) |  |  | (232) |  |
| Amortization of intangibles (c) |  |  |  |  | (667) |  |  | (833) |  |  | (1,014) |  |
| Stock-based compensation expense (d) |  |  |  |  | (785) |  |  | (878) |  |  | (931) |  |
| Other corporate expenses (e) |  |  |  |  | (840) |  |  | (756) |  |  | (921) |  |
| Total consolidated operating income (f) |  |  |  |  | $ | 6,237 |  |  | $ | 5,411 |  |  | $ | 5,771 |  |

[0001571996-25-000034:notes:405]
(a)Corporate and other consists of results of divested businesses or non-reportable segments whose offerings are no longer actively sold, including (i) VMware Resale, (ii) Secureworks, and (iii) Virtustream, and do not meet the requirements for a reportable segment, either individually or collectively. Additionally, Corporate and other includes other items that are managed at the corporate level and are not allocated to reportable segments.

[0001571996-25-000034:notes:406]
(b)Depreciation expense directly attributable to each reportable segment is included in the operating results of each segment. However, the CODM does not evaluate depreciation expense by operating segment, and therefore such expense is not separately presented.

[0001571996-25-000034:notes:407]
(c)Amortization of intangibles includes non-cash purchase accounting adjustments that are primarily related to the EMC merger transaction.

[0001571996-25-000034:notes:408]
(d)Stock-based compensation expense consists of equity awards granted based on the estimated fair value of those awards at grant date.

[0001571996-25-000034:notes:409]
(e)Other corporate expenses includes severance expenses, payroll taxes associated with stock-based compensation, incentive charges related to equity investments, facility action costs, transaction-related expenses, and impairment charges.

[0001571996-25-000034:notes:410]
(f)Income and expenses within Interest and other, net, is not allocated to the reportable segments. Therefore, the Company only reports reportable segment operating income.

[0001571996-25-000034:notes:411]
The following table presents the significant expense categories by reportable segment for the periods indicated:

[0001571996-25-000034:notes:412]
|  |  |  | Fiscal Year Ended |
|  |  |  |  |  | January 31, 2025 |  | February 2, 2024 |  | February 3, 2023 |
|  |  |  |  |  | (in millions) |
| Infrastructure Solutions Group: |  |  |  |  |  |  |  |  |  |
| Cost of net revenue |  |  |  |  | $ | 29,352 |  |  | $ | 20,943 |  |  | $ | 24,326 |  |
| Selling, general, and administrative |  |  |  |  | $ | 6,593 |  |  | $ | 6,752 |  |  | $ | 7,126 |  |
| Research and development |  |  |  |  | $ | 2,069 |  |  | $ | 1,904 |  |  | $ | 1,859 |  |
| Client Solutions Group: |  |  |  |  |  |  |  |  |  |
| Cost of net revenue |  |  |  |  | $ | 41,195 |  |  | $ | 40,658 |  |  | $ | 49,264 |  |
| Selling, general, and administrative |  |  |  |  | $ | 3,750 |  |  | $ | 4,080 |  |  | $ | 4,639 |  |
| Research and development |  |  |  |  | $ | 476 |  |  | $ | 466 |  |  | $ | 486 |  |

[0001571996-25-000034:notes:413]
The following table presents the disaggregation of net revenue by reportable segment and by major product categories within the segments for the periods indicated:

[0001571996-25-000034:notes:414]
|  |  |  | Fiscal Year Ended |
|  |  |  |  |  | January 31, 2025 |  | February 2, 2024 |  | February 3, 2023 |
|  |  |  |  |  | (in millions) |
| Net revenue: |  |  |  |  |  |  |  |  |  |
| Infrastructure Solutions Group: |  |  |  |  |  |  |  |  |  |
| Servers and networking |  |  |  |  | $ | 27,136 |  |  | $ | 17,624 |  |  | $ | 20,398 |  |
| Storage |  |  |  |  | 16,457 |  |  | 16,261 |  |  | 17,958 |  |
| Total ISG net revenue |  |  |  |  | $ | 43,593 |  |  | $ | 33,885 |  |  | $ | 38,356 |  |
| Client Solutions Group: |  |  |  |  |  |  |  |  |  |
| Commercial |  |  |  |  | $ | 40,844 |  |  | $ | 39,814 |  |  | $ | 45,556 |  |
| Consumer |  |  |  |  | 7,549 |  |  | 9,102 |  |  | 12,657 |  |
| Total CSG net revenue |  |  |  |  | $ | 48,393 |  |  | $ | 48,916 |  |  | $ | 58,213 |  |

[0001571996-25-000034:notes:415]
The following table presents net revenue allocated between the United States and foreign countries for the periods indicated:

[0001571996-25-000034:notes:416]
|  | Fiscal Year Ended |
|  | January 31, 2025 |  | February 2, 2024 |  | February 3, 2023 |
|  | (in millions) |
| Net revenue: |  |  |  |  |  |
| United States | $ | 51,014 |  |  | $ | 43,986 |  |  | $ | 49,201 |  |
| Foreign countries | 44,553 |  |  | 44,439 |  |  | 53,100 |  |
| Total net revenue | $ | 95,567 |  |  | $ | 88,425 |  |  | $ | 102,301 |  |

[0001571996-25-000034:notes:417]
The following table presents property, plant, and equipment, net allocated between the United States and foreign countries as of the dates indicated:

[0001571996-25-000034:notes:418]
|  | January 31, 2025 |  | February 2, 2024 |
|  | (in millions) |
| Property, plant, and equipment, net: |  |  |  |
| United States | $ | 4,396 |  |  | $ | 4,330 |  |
| Foreign countries | 1,940 |  |  | 2,102 |  |
| Total property, plant, and equipment, net | $ | 6,336 |  |  | $ | 6,432 |  |

[0001571996-25-000034:notes:419]
The allocation between domestic and foreign net revenue is based on the location of the customers. Net revenue from any single foreign country did not constitute more than 10% of the Company’s consolidated net revenue for any of the fiscal years ended January 31, 2025, February 2, 2024, and February 3, 2023. As of January 31, 2025 and February 2, 2024, property, plant, and equipment, net primarily related to domestic ownership. Within foreign countries, property, plant, and equipment, net located in Ireland was $0.7 billion and $0.8 billion for the fiscal years ended January 31, 2025 and February 2, 2024, respectively.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001571996-25-000034:notes:420]
RELATED PARTY TRANSACTIONS 
Prior to the acquisition on November 22, 2023 of VMware LLC (previously VMware, Inc. and individually and together with its consolidated subsidiaries, “VMware”) by Broadcom Inc. (“Broadcom”), VMware was considered a related party of the Company. Upon Broadcom’s acquisition of VMware, Michael Dell’s ownership interest in VMware and his position as Chairman of the Board of VMware terminated, and the Company determined no related party relationship exists with Broadcom or VMware effective as of November 22, 2023. The Company continues to engage in select transactions with VMware following the completion of Broadcom’s acquisition and the termination of the related party relationship. See Note 18 of the Notes to the Consolidated Financial Statements for additional information.

[0001571996-25-000034:notes:421]
Related Party Transactions with VMware

[0001571996-25-000034:notes:422]
The information provided below includes a summary of related party transactions with VMware for the periods presented within this report. Such transactions were considered related party transactions only through November 21, 2023, the day immediately preceding Broadcom’s acquisition of VMware.

[0001571996-25-000034:notes:423]
•Dell Technologies integrated or bundled select VMware products and services with Dell Technologies’ products and sold them to end-users. Dell Technologies also acted as a distributor, purchasing VMware’s standalone products and services for resale to end-user customers. Where applicable, costs under these arrangements were presented net of rebates received by Dell Technologies.

[0001571996-25-000034:notes:424]
•DFS provided financing to certain VMware end-users, which resulted in the recognition of amounts due to related parties on the Consolidated Statements of Financial Position. Associated financing fees were recorded to product net revenue on the Consolidated Statements of Income and were reflected within sales and leases of products to VMware in the table below.

[0001571996-25-000034:notes:425]
•Dell Technologies procured products and services from VMware for its internal use. For the fiscal years ended February 2, 2024 and February 3, 2023, costs incurred associated with products and services purchased from VMware for internal use were immaterial.

[0001571996-25-000034:notes:426]
•Dell Technologies sold and leased products and sold services to VMware. For the fiscal years ended February 2, 2024 and February 3, 2023, revenue recognized from sales of services to VMware was immaterial.

[0001571996-25-000034:notes:427]
•Dell Technologies and VMware entered into joint marketing, sales, and branding arrangements, for which both parties incurred costs. For the fiscal years ended February 2, 2024 and February 3, 2023, consideration received from VMware for joint marketing, sales, and branding arrangements was immaterial.

[0001571996-25-000034:notes:428]
•Dell Technologies and VMware entered into a transition services agreement in connection with the VMware Spin-off to provide various support services, including investment advisory services, certain support services from Dell Technologies personnel, and other transitional services. Costs incurred associated with this agreement were immaterial for the fiscal year ended February 3, 2023. Activities under the agreement concluded during Fiscal 2023.

[0001571996-25-000034:notes:429]
The following table presents information about the impact of Dell Technologies’ related party transactions with VMware on the Consolidated Statements of Income for the periods presented:

[0001571996-25-000034:notes:430]
|  |  |  |  |  |  |  | Fiscal Year Ended |
|  | Classification |  |  |  |  |  |  |  | February 2, 2024 (a) |  | February 3, 2023 |
|  |  |  |  |  |  |  |  |  | (in millions) |
| Sales and leases of products to VMware | Net revenue — products |  |  |  |  |  |  |  | $ | 103 |  |  | $ | 154 |  |
| Purchase of VMware products for resale | Cost of net revenue — products |  |  |  |  |  |  |  | $ | 1,010 |  |  | $ | 1,634 |  |
| Purchase of VMware services for resale | Cost of net revenue — services |  |  |  |  |  |  |  | $ | 2,810 |  |  | $ | 3,065 |  |

[0001571996-25-000034:notes:431]
(a)For the fiscal year ended February 2, 2024, amounts are reported only through November 21, 2023, the day immediately preceding the acquisition of VMware by Broadcom.

[0001571996-25-000034:notes:432]
In connection with the completion of the VMware Spin-off described in Note 11 of the Notes to the Consolidated Financial Statements, Dell Technologies and VMware entered into a Tax Matters Agreement effective as of April 14, 2021 (the “Tax Matters Agreement”), which governs the respective rights and obligations of Dell Technologies and VMware regarding income and other taxes as well as related matters, including tax liabilities and benefits, attributes, and returns for periods both preceding and following the VMware Spin-off.

[0001571996-25-000034:notes:433]
Pursuant to the Tax Matters Agreement, net receipts from VMware during the fiscal year ended February 2, 2024 were $286 million, a portion of which was received subsequent to the completion of Broadcom’s acquisition of VMware, and were immaterial during the fiscal year ended February 3, 2023. Such receipts were primarily related to VMware’s portion of the mandatory one-time transition tax on accumulated earnings of foreign subsidiaries and federal income taxes on Dell Technologies’ consolidated income tax return.

[0001571996-25-000034:notes:434]
Other Related Parties

[0001571996-25-000034:notes:435]
Transactions with other related parties during the periods presented were immaterial, individually and in aggregate.


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0001571996-25-000034:notes:436]
SUPPLEMENTAL CONSOLIDATED FINANCIAL INFORMATION
The following table presents additional information on selected assets included in the Consolidated Statements of Financial Position as of the dates indicated:

[0001571996-25-000034:notes:437]
|  | January 31, 2025 |  | February 2, 2024 |
|  | (in millions) |
| Cash, cash equivalents, and restricted cash: |  |  |  |
| Cash and cash equivalents | $ | 3,633 |  |  | $ | 7,366 |  |
| Cash and cash equivalents — held for sale (a) | 62 |  |  | — |  |
| Restricted cash — other current assets (b) | 123 |  |  | 136 |  |
| Restricted cash — other non-current assets (b) | 1 |  |  | 5 |  |
| Total cash, cash equivalents, and restricted cash | $ | 3,819 |  |  | $ | 7,507 |  |
| Inventories: |  |  |  |
| Production materials | $ | 4,432 |  |  | $ | 2,321 |  |
| Work-in-process | 1,128 |  |  | 607 |  |
| Finished goods | 1,156 |  |  | 694 |  |
| Total inventories | $ | 6,716 |  |  | $ | 3,622 |  |
| Prepaid expenses: |  |  |  |
| Total prepaid expenses (c) | $ | 564 |  |  | $ | 589 |  |
| Deferred costs: |  |  |  |
| Total deferred costs, current (c) | $ | 4,129 |  |  | $ | 5,548 |  |
| Property, plant, and equipment, net: |  |  |  |
| Assets in a customer contract | $ | 5,204 |  |  | $ | 5,022 |  |
| Computer and other equipment | 3,651 |  |  | 3,552 |  |
| Land and buildings | 2,838 |  |  | 2,877 |  |
| Internal use software | 2,403 |  |  | 2,166 |  |
| Total property, plant, and equipment | 14,096 |  |  | 13,617 |  |
| Accumulated depreciation and amortization (d) | (7,760) |  |  | (7,185) |  |
| Total property, plant, and equipment, net | $ | 6,336 |  |  | $ | 6,432 |  |

[0001571996-25-000034:notes:438]
(a)Held for sale represents the reclassification of Secureworks cash and cash equivalents to assets held for sale. See Note 1 of the Notes to the Consolidated Financial Statements for more information about the sale of Secureworks.

[0001571996-25-000034:notes:439]
(b)Restricted cash primarily includes cash required to be held in escrow pursuant to DFS securitization arrangements.

[0001571996-25-000034:notes:440]
(c)Deferred costs and prepaid expenses are included in other current assets in the Consolidated Statements of Financial Position. Amounts classified as long-term deferred costs and long-term prepaid expenses are included in other non-current assets and are not disclosed above.

[0001571996-25-000034:notes:441]
(d)During the fiscal years ended January 31, 2025, February 2, 2024, and February 3, 2023, the Company recognized $2.1 billion, $2.0 billion, and $1.8 billion, respectively, in depreciation expense.

[0001571996-25-000034:notes:442]
Warranty Liability

[0001571996-25-000034:notes:443]
The following table presents changes in the Company’s liability for standard limited warranties for the periods indicated:

[0001571996-25-000034:notes:444]
|  |  |  | Fiscal Year Ended |
|  |  |  |  |  | January 31, 2025 |  | February 2, 2024 |  | February 3, 2023 |
|  |  |  |  |  | (in millions) |
| Warranty liability: |  |  |  |  |  |  |  |  |  |
| Warranty liability at beginning of period |  |  |  |  | $ | 426 |  |  | $ | 467 |  |  | $ | 480 |  |
| Costs accrued for new warranty contracts and changes in estimates for pre-existing warranties (a) |  |  |  |  | 882 |  |  | 808 |  |  | 956 |  |
| Service obligations honored |  |  |  |  | (884) |  |  | (849) |  |  | (969) |  |
| Warranty liability at end of period (b) |  |  |  |  | $ | 424 |  |  | $ | 426 |  |  | $ | 467 |  |

[0001571996-25-000034:notes:445]
(a)Changes in cost estimates related to pre-existing warranties are aggregated with accruals for new standard warranty contracts. The Company’s warranty liability process does not differentiate between estimates made for pre-existing warranties and those made for new warranty obligations.

[0001571996-25-000034:notes:446]
(b)The liabilities for standard warranties are included in accrued and other and in non-current liabilities in the Consolidated Statements of Financial Position.

[0001571996-25-000034:notes:447]
Severance Charges

[0001571996-25-000034:notes:448]
The Company incurs costs related to employee severance and records a liability for these costs when it is probable that employees will be entitled to termination benefits and the amounts can be reasonably estimated. The liability related to these actions is included in accrued and other within current liabilities in the Consolidated Statements of Financial Position.

[0001571996-25-000034:notes:449]
The following table presents the activity related to the Company’s severance liability for the periods indicated:

[0001571996-25-000034:notes:450]
|  |  |  | Fiscal Year Ended |
|  |  |  |  |  | January 31, 2025 |  | February 2, 2024 |  | February 3, 2023 |
|  |  |  |  |  | (in millions) |
| Severance liability: |  |  |  |  |  |  |  |  |  |
| Severance liability at beginning of period |  |  |  |  | $ | 352 |  |  | $ | 408 |  |  | $ | 74 |  |
| Severance charges |  |  |  |  | 693 |  |  | 648 |  |  | 527 |  |
| Cash paid and other |  |  |  |  | (807) |  |  | (704) |  |  | (193) |  |
| Severance liability at end of period |  |  |  |  | $ | 238 |  |  | $ | 352 |  |  | $ | 408 |  |

[0001571996-25-000034:notes:451]
The following table presents severance charges as included in the Consolidated Statements of Income for the periods indicated:

[0001571996-25-000034:notes:452]
|  |  |  | Fiscal Year Ended |
|  |  |  |  |  | January 31, 2025 |  | February 2, 2024 |  | February 3, 2023 |
|  |  |  |  |  | (in millions) |
| Severance charges: |  |  |  |  |  |  |  |  |  |
| Cost of net revenue |  |  |  |  | $ | 155 |  |  | $ | 86 |  |  | $ | 108 |  |
| Selling, general, and administrative |  |  |  |  | 419 |  |  | 522 |  |  | 363 |  |
| Research and development |  |  |  |  | 119 |  |  | 40 |  |  | 56 |  |
| Total severance charges |  |  |  |  | $ | 693 |  |  | $ | 648 |  |  | $ | 527 |  |

[0001571996-25-000034:notes:453]
Supply Chain Finance Program

[0001571996-25-000034:notes:454]
The Company maintains a Supply Chain Finance Program (the “SCF Program”), which enables eligible suppliers, at the supplier's sole discretion, to sell receivables due from the Company to a third-party financial institution. The Company has no involvement in establishing the terms or conditions of the arrangement between its suppliers and the financial institution, no economic interest in a supplier's decision to sell a receivable, and does not provide legally secured assets or other forms of guarantees under the arrangement.

[0001571996-25-000034:notes:455]
The SCF Program does not impact the Company's liquidity as payments for participating supplier invoices are remitted by the Company to the financial institution on the original invoice due date, regardless of whether an individual invoice is sold by the supplier to the financial institution. Further, the Company negotiates payment terms with suppliers regardless of their decision to participate in the SCF Program. Payment terms with such suppliers vary and do not exceed 130 days. The Company’s outstanding obligations represent invoices due to suppliers confirmed as valid under the SCF Program and are included within accounts payable on the Consolidated Statements of Financial Position, while associated payments are included in cash flows from operating activities on the Consolidated Statements of Cash Flows.

[0001571996-25-000034:notes:456]
The following table presents the changes in the Company’s outstanding obligations for the periods indicated:

[0001571996-25-000034:notes:457]
|  | Fiscal Year Ended |
|  | January 31, 2025 |  |  |  |  |
|  | (in millions) |
| Confirmed obligations outstanding at the beginning of period | $ | 1,121 |  |  |  |  |  |
| Invoices confirmed | 5,191 |  |  |  |  |  |
| Confirmed invoices paid | (4,944) |  |  |  |  |  |
| Confirmed obligations outstanding at the end of period | $ | 1,368 |  |  |  |  |  |

[0001571996-25-000034:notes:458]
Interest and other, net

[0001571996-25-000034:notes:459]
The following table presents information regarding interest and other, net as included in the Consolidated Statements of Income for the periods indicated:

[0001571996-25-000034:notes:460]
|  |  |  | Fiscal Year Ended |
|  |  |  |  |  | January 31, 2025 |  | February 2, 2024 |  | February 3, 2023 |
|  |  |  |  |  | (in millions) |
| Interest and other, net: |  |  |  |  |  |  |  |  |  |
| Investment income, primarily interest |  |  |  |  | $ | 160 |  |  | $ | 305 |  |  | $ | 100 |  |
| Gain (loss) on investments, net |  |  |  |  | 177 |  |  | 47 |  |  | (206) |  |
| Interest expense |  |  |  |  | (1,394) |  |  | (1,501) |  |  | (1,222) |  |
| Foreign exchange |  |  |  |  | (112) |  |  | (199) |  |  | (265) |  |
| Legal settlement, net |  |  |  |  | — |  |  | — |  |  | (894) |  |
| Other |  |  |  |  | (20) |  |  | 24 |  |  | (59) |  |
| Total interest and other, net |  |  |  |  | $ | (1,189) |  |  | $ | (1,324) |  |  | $ | (2,546) |  |


## us-gaap:GovernmentAssistanceTextBlock

[0001571996-25-000034:notes:461]
GOVERNMENT ASSISTANCE
The Company receives government assistance in the form of grants and incentives which vary in size, duration, and conditions from various domestic and international governing bodies and related entities which are primarily structured as cash grants and non-income tax incentives. For government assistance in which no specific US GAAP applies, the Company accounts for such transactions as a gain contingency and by analogy to a grant model. Under such model, the Company recognizes the impact of the government assistance on the Consolidated Statements of Income upon reaching reasonable assurance that the Company will comply with the conditions of the assistance and that the grant will be received. The Company classifies the impact of government assistance on the Consolidated Statements of Income based on the underlying nature and purpose of the assistance.

[0001571996-25-000034:notes:462]
During the fiscal years ended January 31, 2025, February 2, 2024, and February 3, 2023, government assistance received primarily consisted of the following:

[0001571996-25-000034:notes:463]
The Company received assistance from foreign governmental entities designed, in part, to promote competitive pricing by providing companies with an offset to local sales taxes incurred on the sales of products to customers. The assistance received is broadly available to companies. To qualify for this assistance, companies are required to invest a portion of local revenue, derived from goods manufactured locally, into research and development activities. The incentives in place are currently set to expire at various dates through 2029. Such expirations could be impacted by future legislation. During the fiscal years ended January 31, 2025, February 2, 2024, and February 3, 2023, the Company recognized $279 million, $288 million, and $297 million, respectively, within net revenue on the Consolidated Statements of Income related to such assistance.

[0001571996-25-000034:notes:464]
The Company received incentives from foreign governmental entities to provide reimbursement for various costs incurred that are directly tied to the production or delivery of offerings sold to customers. The agreements governing such assistance require that the Company comply with certain conditions including, but not limited to, the achievement of future operational targets. These agreements currently expire at various dates through 2029. During the fiscal years ended January 31, 2025, February 2, 2024, and February 3, 2023, the Company recognized a benefit of $45 million, $166 million, and $318 million, respectively, to cost of net revenue on the Consolidated Statements of Income related to such assistance.


## us-gaap:QuarterlyFinancialInformationTextBlock

[0001571996-25-000034:notes:465]
QUARTERLY RESULTS (UNAUDITED) 
The following tables present selected unaudited Condensed Consolidated Statements of Income for each quarter of the periods indicated:

[0001571996-25-000034:notes:466]
|  | Three Months Ended |
|  | May 3, 2024 |  | August 2, 2024 |  | November 1, 2024 |  | January 31, 2025 |
|  | (in millions, except per share amounts) |
| Net revenue | $ | 22,244 |  |  | $ | 25,026 |  |  | $ | 24,366 |  |  | $ | 23,931 |  |
| Gross margin | $ | 4,851 |  |  | $ | 5,361 |  |  | $ | 5,360 |  |  | $ | 5,678 |  |
| Operating income | $ | 965 |  |  | $ | 1,392 |  |  | $ | 1,721 |  |  | $ | 2,159 |  |
| Net income | $ | 992 |  |  | $ | 882 |  |  | $ | 1,170 |  |  | $ | 1,532 |  |
| Net income attributable to Dell Technologies Inc. | $ | 997 |  |  | $ | 887 |  |  | $ | 1,175 |  |  | $ | 1,533 |  |
| Earnings per share attributable to Dell Technologies Inc. |  |  |  |  |
| Basic | $ | 1.41 |  |  | $ | 1.25 |  |  | $ | 1.67 |  |  | $ | 2.19 |  |
| Diluted | $ | 1.37 |  |  | $ | 1.23 |  |  | $ | 1.64 |  |  | $ | 2.15 |  |
|  | Three Months Ended |
|  | May 5, 2023 |  | August 4, 2023 |  | November 3, 2023 |  | February 2, 2024 |
|  | (in millions, except per share amounts) |
| Net revenue | $ | 20,922 |  |  | $ | 22,934 |  |  | $ | 22,251 |  |  | $ | 22,318 |  |
| Gross margin | $ | 5,080 |  |  | $ | 5,416 |  |  | $ | 5,201 |  |  | $ | 5,372 |  |
| Operating income | $ | 1,131 |  |  | $ | 1,194 |  |  | $ | 1,539 |  |  | $ | 1,547 |  |
| Net income | $ | 632 |  |  | $ | 482 |  |  | $ | 1,050 |  |  | $ | 1,208 |  |
| Net income attributable to Dell Technologies Inc. | $ | 637 |  |  | $ | 489 |  |  | $ | 1,052 |  |  | $ | 1,210 |  |
| Earnings per share attributable to Dell Technologies Inc. |  |  |  |  |
| Basic | $ | 0.88 |  |  | $ | 0.67 |  |  | $ | 1.46 |  |  | $ | 1.70 |  |
| Diluted | $ | 0.86 |  |  | $ | 0.66 |  |  | $ | 1.42 |  |  | $ | 1.66 |  |

[0001571996-25-000034:notes:467]
As discussed in Note 1 of the Notes to the Consolidated Financial Statements, the Company discovered accumulated credits from certain suppliers that were not recorded or not recorded in the correct period in its previously reported financial results. The Company will revise its previously reported quarterly financial information based on the summary presented below in its future filings with the SEC, as applicable, to correct for the overstatement of cost of net revenue to the Consolidated Statements of Income, net of the related income tax effect, and the corresponding amounts affecting the Consolidated Statements of Financial Position. The revision did not have an impact on the Company’s net revenue.


## us-gaap:SubsequentEventsTextBlock

[0001571996-25-000034:notes:468]
SUBSEQUENT EVENTS 
There were no known events occurring after January 31, 2025, and up until the date of issuance of this report that would materially affect the information presented herein.


## ecd:MtrlTermsOfTrdArrTextBlock

[0001571996-25-000034:notes:469]
On January 13, 2025, William Green, one of the Company’s directors, adopted a written plan for the sale of up to 272,736 shares of the Company’s Class C Common Stock that is intended to satisfy the affirmative defense conditions of Rule 10b5-1(c) under the Exchange Act. The plan will expire on December 31, 2025, or on any earlier date on which all of the shares have been sold.
