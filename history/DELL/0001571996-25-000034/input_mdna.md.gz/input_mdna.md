# DELL MD&A — 0001571996-25-000034


## mdna

[0001571996-25-000034:mdna:1]
ITEM 7 — MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS

[0001571996-25-000034:mdna:2]
This management’s discussion and analysis should be read in conjunction with the audited Consolidated Financial Statements and accompanying Notes included in this Annual Report on Form 10-K. This section of this Annual Report on Form 10-K generally discusses Fiscal 2025 and Fiscal 2024 items. This section also discusses Fiscal 2024 and Fiscal 2023 results, as the Company revised its Fiscal 2024 items to correct for a misstatement in its financial statements discovered during the fourth quarter of Fiscal 2025. The revisions ensure comparability across all periods reflected herein. For additional information, see Note 1 and Note 22 of the Notes to the Consolidated Financial Statements included in this report.

[0001571996-25-000034:mdna:3]
Unless otherwise indicated, all results presented are prepared in a manner that complies, in all material respects, with generally accepted accounting principles in the United States of America (“GAAP”). Unless otherwise indicated, all changes identified for the current-period results represent comparisons to results for the prior corresponding fiscal period.

[0001571996-25-000034:mdna:4]
Unless the context indicates otherwise, references in this report to “we,” “us,” “our,” the “Company,” and “Dell Technologies” mean Dell Technologies Inc. and its consolidated subsidiaries, references to “Dell” mean Dell Inc. and Dell Inc.’s consolidated subsidiaries, and references to “EMC” mean EMC Corporation and EMC Corporation’s consolidated subsidiaries.

[0001571996-25-000034:mdna:5]
Our fiscal year is the 52- or 53-week period ending on the Friday nearest January 31. We refer to our fiscal years ended January 31, 2025, February 2, 2024, and February 3, 2023 as “Fiscal 2025,” “Fiscal 2024,” and “Fiscal 2023,” respectively. Both Fiscal 2025 and Fiscal 2024 included 52 weeks, while Fiscal 2023 included 53 weeks.

[0001571996-25-000034:mdna:6]
INTRODUCTION

[0001571996-25-000034:mdna:7]
Company Overview

[0001571996-25-000034:mdna:8]
Dell Technologies is a leader in the global technology industry focused on providing broad and innovative technology solutions for the data and artificial intelligence (“AI”) era. We build and offer solutions ranging from client devices and peripherals to infrastructure solutions across servers, networking, and storage to meet the evolving needs of our customers and drive better business outcomes. With our extensive portfolio and our commitment to innovation, we offer secure, integrated solutions that extend from the edge to the core to the cloud, and we are at the forefront of AI, software-defined, and cloud native infrastructure solutions. Our vision is to become the most essential technology partner. We intend to realize our vision by executing our strategy of leveraging our strengths to extend our leadership positions and capture new growth.

[0001571996-25-000034:mdna:9]
We are organized into two business units which are also our reportable segments: Infrastructure Solutions Group and Client Solutions Group.

[0001571996-25-000034:mdna:10]
•Infrastructure Solutions Group (“ISG”) — ISG includes our servers and networking offerings and our storage offerings. Our server portfolio includes high-performance general-purpose and AI-optimized servers. Our networking portfolio includes wide area network infrastructure, data center and edge networking switches, and cables and optics. Our comprehensive storage portfolio includes modern and traditional storage solutions, including all-flash arrays, scale-out file, object platforms, hyper-converged infrastructure, and software-defined storage. ISG also offers software, peripherals, and services, including consulting and support and deployment.

[0001571996-25-000034:mdna:11]
•Client Solutions Group (“CSG”) — CSG includes offerings designed for commercial and consumer customers. Our CSG portfolio includes branded PCs, including notebooks, desktops, and workstations, branded peripherals, and third-party software and peripherals. CSG also includes services offerings, such as configuration, support and deployment, and extended warranties.

[0001571996-25-000034:mdna:12]
39

[0001571996-25-000034:mdna:13]
Our other businesses primarily consist of our resale of standalone offerings of VMware LLC (formerly VMware, Inc. and individually and together with its subsidiaries, “VMware”), referred to as “VMware Resale,” and offerings of SecureWorks Corp. (“Secureworks”). These businesses are divested businesses or their offerings are no longer actively sold, and are not classified as reportable segments, either individually or collectively. Their operating results are reported within Corporate and other. On October 21, 2024, Secureworks announced that it had entered into a definitive agreement providing for its sale to Sophos Inc., an affiliate of Thoma Bravo, L.P., a private equity and growth capital firm. The transaction was completed on February 3, 2025, subsequent to the close of the Company’s fiscal year ended January 31, 2025, in an all-cash transaction for a purchase price of approximately $0.9 billion.

[0001571996-25-000034:mdna:14]
For further discussion regarding our current reportable segments, see “Results of Operations — Business Unit Results” and Note 18 of the Notes to the Consolidated Financial Statements included in this report.

[0001571996-25-000034:mdna:15]
We offer customers choice in how they acquire our solutions, including traditional purchasing and offerings under the Dell Payment Solutions portfolio. These offerings provide both payment and consumption solutions, including as-a-Service, subscription, utility, leases, and loans, which allow our customers to pay over time and provide them with operational and financial flexibility. Dell Financial Services and its affiliates (“DFS”) support financing solutions and services as part of the portfolio. For additional information about our financing arrangements, see Note 5 of the Notes to the Consolidated Financial Statements included in this report.

[0001571996-25-000034:mdna:16]
Business Trends and Challenges

[0001571996-25-000034:mdna:17]
Fiscal 2025 Significant Developments — During Fiscal 2025, we executed our strategy with strong operating results, generating net revenue and operating income growth. The following trends and conditions affected the environment in which we operated:

[0001571996-25-000034:mdna:18]
•Macroeconomic environment: The demand environment was strong for our servers and networking offerings, which contributed to overall net revenue growth. Additionally, we saw modest demand improvement in our commercial offerings within CSG. Given the demand dynamics for the year, we experienced a shift in the mix of the business towards our ISG offerings.

[0001571996-25-000034:mdna:19]
•Demand for AI-optimized solutions: Our ISG business continued to benefit from increased demand for AI-optimized solutions as customers continue to adopt and further integrate AI into their operations. As a result of the continued strong demand for our AI-optimized servers, backlog levels for such offerings remained elevated as we exited the fiscal year.

[0001571996-25-000034:mdna:20]
•Supply chain: Notwithstanding the increased demand for AI-optimized solutions, our supply chain continued to operate efficiently. We experienced a modest increase in input costs, primarily driven by both component and logistics costs.

[0001571996-25-000034:mdna:21]
•Broadcom’s acquisition of VMware: On November 22, 2023, Broadcom Inc. (“Broadcom”) completed its acquisition of VMware, leading to changes to our relationship with VMware as described below.

[0001571996-25-000034:mdna:22]
We expect demand growth across our servers and networking offerings and, to a lesser extent, our storage offerings, which we expect will result in ISG net revenue growth in Fiscal 2026. We expect modest CSG net revenue growth for the full fiscal year, driven in part by the anticipated PC refresh cycle in the latter part of Fiscal 2026. Additionally, we expect a continued reduction of our Corporate and other net revenue as we no longer act as a distributor of VMware’s standalone products and services.

[0001571996-25-000034:mdna:23]
We expect a modest decline in input costs during the first half of Fiscal 2026. Input cost trends are dependent on the strength or weakness of actual end-user demand and supply dynamics, which will continue to fluctuate and ultimately impact our costs, pricing, and operating results.

[0001571996-25-000034:mdna:24]
We remain focused on executing our key strategic priorities, building long-term value creation for our stakeholders, and addressing our customers’ needs while continuing to make prudent decisions in response to the environment. We expect margin rate pressure resulting from a continuing shift in mix towards our AI-optimized servers and a competitive environment. We look to balance profitability and growth while maintaining disciplined pricing as we navigate through competitive pricing pressures.

[0001571996-25-000034:mdna:25]
We continue to advance our own capabilities to change the way we work and make decisions, improve business outcomes and the customer experience, and reduce costs by leveraging new technology and optimizing business processes. We remain committed to disciplined cost management in coordination with our ongoing business modernization initiatives and expect continued reductions in operating expenses as we take certain measures to reduce costs, including limitation of external hiring, employee reorganizations, and other actions to align our investments with our strategic priorities and customer needs. We anticipate these actions will result in additional reductions in our overall headcount. We believe our unique operating advantages provide a foundation to foster growth, drive efficiencies, and continue to position us for long-term success.

[0001571996-25-000034:mdna:26]
Relationship with VMware — On November 22, 2023, VMware was acquired by Broadcom, and subsequently announced changes to its go-to-market approach for VMware offerings that impacted our commercial relationship with VMware. On March 25, 2024, we terminated our Commercial Framework Agreement with VMware, which provided the framework under which we and VMware continued our commercial relationship following our spin-off of VMware on November 1, 2021. We no longer act as a distributor of Broadcom’s VMware standalone products and services, although we will continue to support customers that have purchased resale offerings sold in prior periods. We continue to integrate and embed certain VMware products and services with selected Dell Technologies’ offerings to end-users, such as through our VxRail solution. The results of such offerings are reflected within CSG or ISG, depending upon the nature of the underlying offering sold.

[0001571996-25-000034:mdna:27]
VMware was a related party until the date of its acquisition by Broadcom. The acquisition terminated the preexisting related party relationship with VMware such that no related party relationship exists with either Broadcom or VMware effective as of November 22, 2023. For more information regarding the impact of the Broadcom acquisition of VMware and our prior related party transactions with VMware, see Note 19 of the Notes to the Consolidated Financial Statements included in this report.

[0001571996-25-000034:mdna:28]
ISG — We expect ISG will continue to be impacted by the evolving nature of the IT infrastructure market and competitive environment. With our scale and market-leading solutions portfolio, we believe we are well-positioned to address the ongoing competitive dynamics and trends in technology and customer needs. Through our collaborative, customer-focused approach to innovation, we strive to deliver new and relevant solutions and software to our customers quickly and efficiently. We continue to focus on customer base expansion and the lifetime value of customer relationships.

[0001571996-25-000034:mdna:29]
We anticipate ISG will continue to benefit from technology advancements and interest in AI as customers continue to adopt and integrate AI into their operations. The timing of customer purchases reflects the varying stages of adoption of AI by different customer segments and drives variability in our revenue. To meet the growing demand and increasing complexity of our AI-optimized offerings, we have increased our purchases of certain components with suppliers, which has resulted in increased inventory levels, higher purchase obligations, and new working capital dynamics. Additionally, frequent component part updates or transitions create additional challenges in managing demand and supply levels. While we have seen lead times shorten, we anticipate the next-generation of these components will be subject to supply constraints as demand for these components remains high.

[0001571996-25-000034:mdna:30]
We expect that growth in data will continue to generate long-term demand for our storage solutions and services. Cloud native applications are expected to continue to be a key trend in the infrastructure market. We continue to expand our offerings in external storage arrays, which incorporate flexible, cloud-based functionality. We benefit from offering solutions that address software-defined storage, hyper-converged infrastructure, and modular solutions based on server-centric architectures. Our storage business is subject to seasonal trends, which may continue to impact ISG results.

[0001571996-25-000034:mdna:31]
CSG — We participate in all segments of the PC market with a focus on commercial and high-end consumer computing devices, which we believe represent the most stable and profitable markets. We anticipate that CSG will benefit from advances in AI over the long-term as customers will require PCs with the ability to run their complex AI workloads.

[0001571996-25-000034:mdna:32]
Competitive dynamics remain an important factor in our CSG business and continue to impact pricing and operating results. We are committed to our long-term CSG strategy and will continue to make investments to innovate across the portfolio. We expect that the CSG demand environment will be subject to seasonal trends and influenced by the timing and scale of the anticipated PC refresh cycle.

[0001571996-25-000034:mdna:33]
Recurring Revenue and Consumption Models — We expect that our flexible consumption models will further strengthen our customer relationships and provide a foundation for growth in recurring revenue. We define recurring revenue as revenue recognized that is primarily related to hardware and software maintenance, as well as operating leases, subscription, as-a-Service, and usage-based offerings.

[0001571996-25-000034:mdna:34]
Strategic Investments and Acquisitions — As part of our strategy, we will continue to evaluate opportunities for strategic investments through our venture capital investment arm, Dell Technologies Capital, with a focus on emerging technology areas that are relevant to our business and that will complement our existing portfolio of solutions. The technologies or products these companies have under development are typically in the early stages and may never have commercial value, which could result in a loss of a substantial part of our investment in the companies. In addition to these investments, we may also make targeted acquisitions of businesses that advance our strategic objectives and accelerate our innovation agenda.

[0001571996-25-000034:mdna:35]
Foreign Currency Exposure — We manage our business on a U.S. Dollar basis. However, we have a large global presence, generating approximately half of our net revenue from sales to customers outside of the United States during Fiscal 2025 and Fiscal 2024. As a result, our operating results can be, and particularly in recent periods have been, impacted by fluctuations in foreign currency exchange rates. We utilize a comprehensive hedging strategy intended to mitigate the impact of foreign currency volatility over time, and we adjust pricing when possible to further minimize foreign currency impacts.

[0001571996-25-000034:mdna:36]
Other Macroeconomic Risks and Uncertainties — The impacts of trade protection measures, including increases in tariffs and trade barriers, changes in government policies and international trade arrangements, geopolitical volatility, and global macroeconomic conditions (including those in China) may affect our ability to conduct business in some non-U.S. markets. We monitor and seek to mitigate these risks with adjustments to our manufacturing, supply chain, and distribution networks.

[0001571996-25-000034:mdna:37]
42

[0001571996-25-000034:mdna:38]
NON-GAAP FINANCIAL MEASURES

[0001571996-25-000034:mdna:39]
In this management’s discussion and analysis, we use supplemental measures of our performance which are derived from our consolidated financial information but which are not presented in our consolidated financial statements prepared in accordance with GAAP. These non-GAAP financial measures include non-GAAP product gross margin; non-GAAP services gross margin; non-GAAP gross margin; non-GAAP operating expenses; non-GAAP operating income; non-GAAP net income; non-GAAP earnings per share attributable to Dell Technologies Inc. - diluted; free cash flow; and adjusted free cash flow. These non-GAAP financial measures are not meant to be considered as indicators of performance or liquidity in isolation from or as a substitute for gross margin, operating expenses, operating income, net income, diluted earnings per share, or cash flows from operating activities prepared in accordance with GAAP, and should be read only in conjunction with financial information presented on a GAAP basis.

[0001571996-25-000034:mdna:40]
We use non-GAAP financial measures to supplement financial information presented on a GAAP basis. Management uses these non-GAAP measures in financial planning and forecasting and when evaluating our financial results and operating trends and performance. We believe, when used supplementally with GAAP financial measures, these non-GAAP financial measures provide our investors with useful and transparent information to help them evaluate our results by facilitating an enhanced understanding of our results of operations and enabling them to make period to period comparisons. There are limitations to the use of the non-GAAP financial measures presented in this report. Our non-GAAP financial measures may not be comparable to similarly titled measures of other companies. Other companies, including companies in our industry, may calculate non-GAAP financial measures differently than we do, limiting the usefulness of those measures for comparative purposes.

[0001571996-25-000034:mdna:41]
Non-GAAP product gross margin, non-GAAP services gross margin, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP operating income, non-GAAP net income, and non-GAAP earnings per share attributable to Dell Technologies Inc. - diluted, as defined by us, exclude amortization of intangible assets, stock-based compensation expense, other corporate expenses and, for non-GAAP net income and non-GAAP earnings per share attributable to Dell Technologies Inc. - diluted, fair value adjustments on equity investments and an aggregate adjustment for income taxes. As the excluded items may have a material impact on our financial results, our management compensates for this limitation by relying primarily on our GAAP results and using non-GAAP financial measures supplementally or for projections when comparable GAAP financial measures are not available.

[0001571996-25-000034:mdna:42]
Reconciliations of each non-GAAP financial measure to its most directly comparable GAAP financial measure are presented below. We encourage you to review the reconciliations in conjunction with the presentation of the non-GAAP financial measures for each of the periods presented. The discussion below includes information on each of the excluded items as well as our reasons for excluding them from our non-GAAP results. In future fiscal periods, we may exclude such items and may incur income and expenses similar to these excluded items. Accordingly, the exclusion of these items and other similar items in our non-GAAP presentation should not be interpreted as implying that these items are non-recurring, infrequent, or unusual.

[0001571996-25-000034:mdna:43]
The following is a summary of the items excluded from the most comparable GAAP financial measures to calculate our non-GAAP financial measures.

[0001571996-25-000034:mdna:44]
•Amortization of Intangible Assets — Amortization of intangible assets primarily consists of the amortization of customer relationships, developed technology, and trade names. In connection with our acquisition by merger of EMC, referred to as the “EMC merger transaction,” and the acquisition of Dell by Dell Technologies Inc., referred to as the “going-private transaction,” all of the tangible and intangible assets and liabilities of EMC and Dell, respectively, were accounted for and recognized at fair value on the transaction dates. We exclude amortization charges for the amortization of intangible assets as they do not reflect our current operating performance and charges are significantly impacted by the timing and magnitude of our acquisitions and, as a result, may vary in amount from period to period.

[0001571996-25-000034:mdna:45]
•Stock-based Compensation Expense — Stock-based compensation expense consists of equity awards granted based on the estimated fair value of those awards at grant date. To estimate the fair value of performance-based awards containing a market condition, we use the Monte Carlo valuation model. For other share-based awards, the fair value is generally based on the closing price of the Class C Common Stock as reported on the New York Stock Exchange on the date of grant. Although stock-based compensation is an important aspect of the compensation of our employees and executives, we exclude such expense because the fair value of the stock-based awards may fluctuate based on factors unrelated to the operating performance of the business and may bear little resemblance to the actual value realized upon the vesting or future exercise of the related stock-based awards.

[0001571996-25-000034:mdna:46]
•Other Corporate Expenses — Other corporate expenses consist primarily of severance expenses, payroll taxes associated with stock-based compensation, incentive charges related to equity investments, facility action costs, transaction-related expenses, and impairment charges. Severance costs are primarily related to severance and benefits for employees terminated pursuant to cost management initiatives. During Fiscal 2025, Fiscal 2024, and Fiscal 2023, we recognized $0.7 billion, $0.6 billion, and $0.5 billion, respectively, of severance expense related to workforce reduction activities. During Fiscal 2023, other corporate expenses also included $0.9 billion of net expense recognized within interest and other, net, in connection with an agreement to settle the Class V transaction litigation. See Note 11 of the Notes to the Consolidated Financial Statements included in this report for information about this matter. Transaction-related expenses typically consist of acquisition, integration, and divestitures related costs, primarily representing costs for legal, banking, consulting, and advisory services, and are expensed as incurred. Although we may incur these types of expenses in the future, we exclude other corporate expenses as they can vary from period to period, are significantly impacted by the timing and nature of these events, and are not used by management in assessing operating performance of the business.

[0001571996-25-000034:mdna:47]
•Fair Value Adjustments on Equity Investments — Fair value adjustments on equity investments primarily consist of the gain (loss) on strategic investments, which includes recurring fair value adjustments of investments in publicly-traded companies, as well as those in privately-held companies, which are adjusted for observable price changes and any potential impairments. See Note 4 of the Notes to the Consolidated Financial Statements included in this report for additional information on our strategic investment activity. We exclude fair value adjustments on equity investments given the volatility in ongoing adjustments to the valuation of these strategic investments and because such adjustments are unrelated to the operating performance of our business.

[0001571996-25-000034:mdna:48]
•Aggregate Adjustment for Income Taxes — The aggregate adjustment for income taxes is the estimated combined income tax effect for the adjustments described above and determined based on the tax jurisdictions where those adjustments were incurred, as well as an adjustment for discrete tax items. During Fiscal 2025, the aggregate adjustment for income taxes included discrete tax benefits of $0.4 billion related to changes in uncertain tax benefits resulting from the expiration of certain U.S. statutes of limitations and $0.2 billion related to stock-based compensation. We exclude these benefits or charges for purposes of calculating non-GAAP net income due to the variability in recognition of discrete tax items from period to period. The tax effects are determined based on the tax jurisdictions where the above items were incurred. See Note 12 of the Notes to the Consolidated Financial Statements included in this report for additional information about our income taxes. Beginning in Fiscal 2025, our non-GAAP income tax was calculated using a fixed estimated annual tax rate that is determined based on historical trends and projections for the current fiscal year. We may adjust our estimated annual tax rate during the fiscal year to take into account events that would significantly impact our income tax expense, including significant changes resulting from tax legislation, material changes in geographic mix of revenue and expenses, changes to our corporate structure, and other significant events.

[0001571996-25-000034:mdna:49]
44

[0001571996-25-000034:mdna:50]
The following table presents a reconciliation of each non-GAAP financial measure to the most directly comparable GAAP measure for the periods indicated:

[0001571996-25-000034:mdna:51]
|  |  |  | Fiscal Year Ended |
|  |  |  |  |  |  |  | January 31, 2025 |  | % Change |  | February 2, 2024 |  | % Change |  | February 3, 2023 |
|  |  |  |  |  |  |  | (in millions, except percentages) |
| Product gross margin |  |  |  |  |  |  | $ | 11,258 |  |  | — | % |  | $ | 11,237 |  |  | (15) | % |  | $ | 13,221 |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles |  |  |  |  |  |  | 238 |  |  |  |  | 331 |  |  |  |  | 416 |  |
| Stock-based compensation expense |  |  |  |  |  |  | 56 |  |  |  |  | 51 |  |  |  |  | 52 |  |
| Other corporate expenses |  |  |  |  |  |  | 22 |  |  |  |  | 23 |  |  |  |  | 32 |  |
| Non-GAAP product gross margin |  |  |  |  |  |  | $ | 11,574 |  |  | (1) | % |  | $ | 11,642 |  |  | (15) | % |  | $ | 13,721 |  |
| Services gross margin |  |  |  |  |  |  | $ | 9,992 |  |  | 2 | % |  | $ | 9,832 |  |  | 4 | % |  | $ | 9,465 |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation expense |  |  |  |  |  |  | 96 |  |  |  |  | 98 |  |  |  |  | 100 |  |
| Other corporate expenses |  |  |  |  |  |  | 148 |  |  |  |  | 72 |  |  |  |  | 141 |  |
| Non-GAAP services gross margin |  |  |  |  |  |  | $ | 10,236 |  |  | 2 | % |  | $ | 10,002 |  |  | 3 | % |  | $ | 9,706 |  |
| Gross margin |  |  |  |  |  |  | $ | 21,250 |  |  | 1 | % |  | $ | 21,069 |  |  | (7) | % |  | $ | 22,686 |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles |  |  |  |  |  |  | 238 |  |  |  |  | 331 |  |  |  |  | 416 |  |
| Stock-based compensation expense |  |  |  |  |  |  | 152 |  |  |  |  | 149 |  |  |  |  | 152 |  |
| Other corporate expenses |  |  |  |  |  |  | 170 |  |  |  |  | 95 |  |  |  |  | 173 |  |
| Non-GAAP gross margin |  |  |  |  |  |  | $ | 21,810 |  |  | 1 | % |  | $ | 21,644 |  |  | (8) | % |  | $ | 23,427 |  |
| Operating expenses |  |  |  |  |  |  | $ | 15,013 |  |  | (4) | % |  | $ | 15,658 |  |  | (7) | % |  | $ | 16,915 |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles |  |  |  |  |  |  | (429) |  |  |  |  | (502) |  |  |  |  | (598) |  |
| Stock-based compensation expense |  |  |  |  |  |  | (633) |  |  |  |  | (729) |  |  |  |  | (779) |  |
| Other corporate expenses |  |  |  |  |  |  | (670) |  |  |  |  | (661) |  |  |  |  | (748) |  |
| Non-GAAP operating expenses |  |  |  |  |  |  | $ | 13,281 |  |  | (4) | % |  | $ | 13,766 |  |  | (7) | % |  | $ | 14,790 |  |

[0001571996-25-000034:mdna:52]
|  |  |  | Fiscal Year Ended |
|  |  |  |  |  |  |  | January 31, 2025 |  | % Change |  | February 2, 2024 |  | % Change |  | February 3, 2023 |
|  |  |  |  |  |  |  | (in millions, except percentages and per share amounts) |
| Operating income |  |  |  |  |  |  | $ | 6,237 |  |  | 15 | % |  | $ | 5,411 |  |  | (6) | % |  | $ | 5,771 |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles |  |  |  |  |  |  | 667 |  |  |  |  | 833 |  |  |  |  | 1,014 |  |
| Stock-based compensation expense |  |  |  |  |  |  | 785 |  |  |  |  | 878 |  |  |  |  | 931 |  |
| Other corporate expenses |  |  |  |  |  |  | 840 |  |  |  |  | 756 |  |  |  |  | 921 |  |
| Non-GAAP operating income |  |  |  |  |  |  | $ | 8,529 |  |  | 8 | % |  | $ | 7,878 |  |  | (9) | % |  | $ | 8,637 |  |
| Net income |  |  |  |  |  |  | $ | 4,576 |  |  | 36 | % |  | $ | 3,372 |  |  | 39 | % |  | $ | 2,422 |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles |  |  |  |  |  |  | 667 |  |  |  |  | 833 |  |  |  |  | 1,014 |  |
| Stock-based compensation expense |  |  |  |  |  |  | 785 |  |  |  |  | 878 |  |  |  |  | 931 |  |
| Other corporate expenses |  |  |  |  |  |  | 830 |  |  |  |  | 793 |  |  |  |  | 1,796 |  |
| Fair value adjustments on equity investments |  |  |  |  |  |  | (177) |  |  |  |  | (47) |  |  |  |  | 206 |  |
| Aggregate adjustment for income taxes |  |  |  |  |  |  | (816) |  |  |  |  | (407) |  |  |  |  | (642) |  |
| Non-GAAP net income |  |  |  |  |  |  | $ | 5,865 |  |  | 8 | % |  | $ | 5,422 |  |  | (5) | % |  | $ | 5,727 |  |
| Earnings per share attributable to Dell Technologies Inc. — diluted |  |  |  |  |  |  | $ | 6.38 |  |  | 39 | % |  | $ | 4.60 |  |  | 42 | % |  | $ | 3.24 |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles |  |  |  |  |  |  | 0.93 |  |  |  |  | 1.13 |  |  |  |  | 1.35 |  |
| Stock-based compensation expense |  |  |  |  |  |  | 1.09 |  |  |  |  | 1.19 |  |  |  |  | 1.24 |  |
| Other corporate expenses |  |  |  |  |  |  | 1.16 |  |  |  |  | 1.08 |  |  |  |  | 2.39 |  |
| Fair value adjustments on equity investments |  |  |  |  |  |  | (0.25) |  |  |  |  | (0.06) |  |  |  |  | 0.27 |  |
| Aggregate adjustment for income taxes |  |  |  |  |  |  | (1.15) |  |  |  |  | (0.55) |  |  |  |  | (0.86) |  |
| Total non-GAAP adjustments attributable to non-controlling interests |  |  |  |  |  |  | (0.02) |  |  |  |  | (0.02) |  |  |  |  | (0.02) |  |
| Non-GAAP earnings per share attributable to Dell Technologies Inc. — diluted |  |  |  |  |  |  | $ | 8.14 |  |  | 10 | % |  | $ | 7.37 |  |  | (3) | % |  | $ | 7.61 |  |

[0001571996-25-000034:mdna:53]
46

[0001571996-25-000034:mdna:54]
In addition to the above measures, we use free cash flow and adjusted free cash flow as non-GAAP liquidity measures to evaluate our performance. As presented in the following table, we define free cash flow as cash flow from operations after excluding capital expenditures and capitalized software costs, net. To measure adjusted free cash flow, we exclude the impact of financing receivables and equipment under operating leases from free cash flow, as the initial funding of these DFS offerings at the time of origination is largely subsequently replaced with cash inflows from our DFS debt, the majority of which is asset-backed.

[0001571996-25-000034:mdna:55]
Free cash flow and adjusted free cash flow provide useful information to management and investors in part because we use these metrics in our long-term capital allocation framework. Further, we believe free cash flow and adjusted free cash flow are useful measures to management and investors because they reflect cash that we can use, among other purposes, to repurchase common stock, pay dividends on our common stock, invest in our business, pay down debt, and make strategic acquisitions.

[0001571996-25-000034:mdna:56]
As is the case with the other non-GAAP measures presented above, users should consider the limitations of using free cash flow and adjusted free cash flow, including the fact that those measures do not provide a complete measure of our cash flows for any period. Free cash flow and adjusted free cash flow do not purport to be alternatives to cash flows from operating activities as a measure of liquidity. In particular, free cash flow and adjusted free cash flow are not intended to be a measure of cash flow available for management’s discretionary use, as these measures do not reflect certain cash requirements, such as debt service requirements and other contractual commitments.

[0001571996-25-000034:mdna:57]
The following table presents a reconciliation of free cash flow and adjusted free cash flow to cash flow from operations for the periods indicated:

[0001571996-25-000034:mdna:58]
|  |  |  | Fiscal Year Ended |
|  |  |  |  |  |  |  | January 31, 2025 |  | % Change |  | February 2, 2024 |  | % Change |  | February 3, 2023 |
|  |  |  |  |  |  |  | (in millions, except percentages) |
| Cash flow from operations |  |  |  |  |  |  | $ | 4,521 |  |  | (48) | % |  | $ | 8,676 |  |  | 143 | % |  | $ | 3,565 |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Capital expenditures and capitalized software development costs, net (a) |  |  |  |  |  |  | (2,563) |  |  |  |  | (2,753) |  |  |  |  | (2,993) |  |
| Free cash flow |  |  |  |  |  |  | $ | 1,958 |  |  | (67) | % |  | $ | 5,923 |  |  | 935 | % |  | $ | 572 |  |
| Free cash flow |  |  |  |  |  |  | $ | 1,958 |  |  | (67) | % |  | $ | 5,923 |  |  | 935 | % |  | $ | 572 |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Financing receivables (b) |  |  |  |  |  |  | 951 |  |  |  |  | (309) |  |  |  |  | 461 |  |
| Equipment under operating leases (c) |  |  |  |  |  |  | 188 |  |  |  |  | (7) |  |  |  |  | 500 |  |
| Adjusted free cash flow |  |  |  |  |  |  | $ | 3,097 |  |  | (45) | % |  | $ | 5,607 |  |  | 266 | % |  | $ | 1,533 |  |

[0001571996-25-000034:mdna:59]
____________________

[0001571996-25-000034:mdna:60]
(a)Capital expenditures and capitalized software development costs, net includes proceeds from sales of facilities, land, and other assets.

[0001571996-25-000034:mdna:61]
(b)Financing receivables represent the operating cash flow impact from the change in financing receivables.

[0001571996-25-000034:mdna:62]
(c)Equipment under operating leases represents the net impact of capital expenditures and depreciation expense for leases and contractually embedded leases identified within flexible consumption arrangements.

[0001571996-25-000034:mdna:63]
47

[0001571996-25-000034:mdna:64]
RESULTS OF OPERATIONS

[0001571996-25-000034:mdna:65]
Consolidated Results

[0001571996-25-000034:mdna:66]
The following table summarizes our consolidated results for the periods indicated. Unless otherwise indicated, all changes identified for the current-period results represent comparisons to results for the prior corresponding fiscal period.

[0001571996-25-000034:mdna:67]
|  |  |  | Fiscal Year Ended |
|  |  |  |  |  |  |  | January 31, 2025 |  |  |  | February 2, 2024 |  |  |  | February 3, 2023 |
|  |  |  |  |  |  |  |  |  |  |  | Dollars |  | % of Net Revenue |  | % Change |  | Dollars |  | % of Net Revenue |  | % Change |  | Dollars |  | % of Net Revenue |
|  |  |  |  |  |  |  |  |  |  |  | (in millions, except percentages and per share amounts) |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Products |  |  |  |  |  |  |  |  |  |  | $ | 71,420 |  |  | 74.7 | % |  | 11 | % |  | $ | 64,353 |  |  | 72.8 | % |  | (19) | % |  | $ | 79,250 |  |  | 77.5 | % |
| Services |  |  |  |  |  |  |  |  |  |  | 24,147 |  |  | 25.3 | % |  | — | % |  | 24,072 |  |  | 27.2 | % |  | 4 | % |  | 23,051 |  |  | 22.5 | % |
| Total net revenue |  |  |  |  |  |  |  |  |  |  | $ | 95,567 |  |  | 100.0 | % |  | 8 | % |  | $ | 88,425 |  |  | 100.0 | % |  | (14) | % |  | $ | 102,301 |  |  | 100.0 | % |
| Gross margin: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Products |  |  |  |  |  |  |  |  |  |  | $ | 11,258 |  |  | 15.8 | % |  | — | % |  | $ | 11,237 |  |  | 17.5 | % |  | (15) | % |  | $ | 13,221 |  |  | 16.7 | % |
| Services |  |  |  |  |  |  |  |  |  |  | 9,992 |  |  | 41.4 | % |  | 2 | % |  | 9,832 |  |  | 40.8 | % |  | 4 | % |  | 9,465 |  |  | 41.1 | % |
| Total gross margin |  |  |  |  |  |  |  |  |  |  | $ | 21,250 |  |  | 22.2 | % |  | 1 | % |  | $ | 21,069 |  |  | 23.8 | % |  | (7) | % |  | $ | 22,686 |  |  | 22.2 | % |
| Operating expenses |  |  |  |  |  |  |  |  |  |  | $ | 15,013 |  |  | 15.7 | % |  | (4) | % |  | $ | 15,658 |  |  | 17.7 | % |  | (7) | % |  | $ | 16,915 |  |  | 16.6 | % |
| Operating income |  |  |  |  |  |  |  |  |  |  | $ | 6,237 |  |  | 6.5 | % |  | 15 | % |  | $ | 5,411 |  |  | 6.1 | % |  | (6) | % |  | $ | 5,771 |  |  | 5.6 | % |
| Net income |  |  |  |  |  |  |  |  |  |  | $ | 4,576 |  |  | 4.8 | % |  | 36 | % |  | $ | 3,372 |  |  | 3.8 | % |  | 39 | % |  | $ | 2,422 |  |  | 2.4 | % |
| Earnings per share attributable to Dell Technologies — diluted |  |  |  |  |  |  |  |  |  |  | $ | 6.38 |  |  |  |  | 39 | % |  | $ | 4.60 |  |  |  |  | 42 | % |  | $ | 3.24 |  |  |  |
| Cash flow from operations |  |  |  |  |  |  |  |  |  |  | $ | 4,521 |  |  |  |  | (48) | % |  | $ | 8,676 |  |  |  |  | 143 | % |  | $ | 3,565 |  |  |  |
| Non-GAAP Financial Information |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  |  | Fiscal Year Ended |
|  |  |  |  |  |  |  | January 31, 2025 |  |  |  | February 2, 2024 |  |  |  | February 3, 2023 |
|  |  |  |  |  |  |  |  |  |  |  | Dollars |  | % of Net Revenue |  | % Change |  | Dollars |  | % of Net Revenue |  | % Change |  | Dollars |  | % of Net Revenue |
|  |  |  |  |  |  |  |  |  |  |  | (in millions, except percentages and per share amounts) |
| Non-GAAP gross margin: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Products |  |  |  |  |  |  |  |  |  |  | $ | 11,574 |  |  | 16.2 | % |  | (1) | % |  | $ | 11,642 |  |  | 18.1 | % |  | (15) | % |  | $ | 13,721 |  |  | 17.3 | % |
| Services |  |  |  |  |  |  |  |  |  |  | 10,236 |  |  | 42.4 | % |  | 2 | % |  | 10,002 |  |  | 41.6 | % |  | 3 | % |  | 9,706 |  |  | 42.1 | % |
| Total non-GAAP gross margin |  |  |  |  |  |  |  |  |  |  | $ | 21,810 |  |  | 22.8 | % |  | 1 | % |  | $ | 21,644 |  |  | 24.5 | % |  | (8) | % |  | $ | 23,427 |  |  | 22.9 | % |
| Non-GAAP operating expenses |  |  |  |  |  |  |  |  |  |  | $ | 13,281 |  |  | 13.9 | % |  | (4) | % |  | $ | 13,766 |  |  | 15.6 | % |  | (7) | % |  | $ | 14,790 |  |  | 14.5 | % |
| Non-GAAP operating income |  |  |  |  |  |  |  |  |  |  | $ | 8,529 |  |  | 8.9 | % |  | 8 | % |  | $ | 7,878 |  |  | 8.9 | % |  | (9) | % |  | $ | 8,637 |  |  | 8.4 | % |
| Non-GAAP net income |  |  |  |  |  |  |  |  |  |  | $ | 5,865 |  |  | 6.1 | % |  | 8 | % |  | $ | 5,422 |  |  | 6.1 | % |  | (5) | % |  | $ | 5,727 |  |  | 5.6 | % |
| Non-GAAP earnings per share attributable to Dell Technologies — diluted |  |  |  |  |  |  |  |  |  |  | $ | 8.14 |  |  |  |  | 10 | % |  | $ | 7.37 |  |  |  |  | (3) | % |  | $ | 7.61 |  |  |  |
| Free cash flow |  |  |  |  |  |  |  |  |  |  | $ | 1,958 |  |  |  |  | (67) | % |  | $ | 5,923 |  |  |  |  | 935 | % |  | $ | 572 |  |  |  |
| Adjusted free cash flow |  |  |  |  |  |  |  |  |  |  | $ | 3,097 |  |  |  |  | (45) | % |  | $ | 5,607 |  |  |  |  | 266 | % |  | $ | 1,533 |  |  |  |

[0001571996-25-000034:mdna:68]
Non-GAAP product gross margin, non-GAAP services gross margin, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP operating income, non-GAAP net income, non-GAAP earnings per share attributable to Dell Technologies - diluted, free cash flow, and adjusted free cash flow are not measurements of financial performance prepared in accordance with GAAP. See “Non‑GAAP Financial Measures” for additional information about these non-GAAP financial measures, including our reasons for including these measures, material limitations with respect to the usefulness of the measures, and a reconciliation of each non-GAAP financial measure to the most directly comparable GAAP financial measure.

[0001571996-25-000034:mdna:69]
48

[0001571996-25-000034:mdna:70]
Overview

[0001571996-25-000034:mdna:71]
During Fiscal 2025, net revenue increased by 8%, driven by an increase in ISG net revenue that was partially offset by a decrease in Corporate and other net revenue and, to a lesser extent, CSG net revenue. The increase in ISG net revenue was driven by growth in our servers and networking offerings. Corporate and other net revenue declined primarily due to a decrease in VMware Resale revenue as we no longer act as a distributor of standalone VMware offerings. The decline in CSG net revenue was attributable to a decrease in sales of our consumer offerings.

[0001571996-25-000034:mdna:72]
During Fiscal 2025, operating income and non-GAAP operating income increased by 15% to $6.2 billion and 8% to $8.5 billion, respectively. During Fiscal 2025, the increases in operating income and non-GAAP operating income were primarily attributable to an increase in ISG operating income that was driven by our servers and networking offerings and, to a lesser extent, our storage offerings, which was partially offset by a decrease in CSG operating income.

[0001571996-25-000034:mdna:73]
During Fiscal 2025, operating income and non-GAAP operating income as a percentage of net revenue increased 40 basis points to 6.5% and remained flat at 8.9%, respectively. The operating income and non-GAAP operating income rates during the current year were affected by the favorable impact of a decrease in operating expense rate that was driven by strong ISG net revenue growth coupled with continued disciplined cost management. The favorable impact of a decrease in operating expense rate was offset by a decline in gross margin as a percentage of net revenue due to a shift in mix towards AI-optimized server offerings and a competitive CSG pricing environment.

[0001571996-25-000034:mdna:74]
Cash provided by operating activities was $4.5 billion during Fiscal 2025, and was driven by profitability, partially offset by working capital dynamics. Working capital was primarily impacted by AI, which led to higher inventory, accounts receivable, and accounts payable levels. During Fiscal 2024, cash provided by operating activities was $8.7 billion, which was primarily driven by profitability coupled with strong inventory management and cash collections performance. Cash provided by operating activities during Fiscal 2024 also reflected the impact of the $0.9 billion net payment to settle the Class V transaction litigation and $0.4 billion in proceeds from the sale of our U.S. consumer revolving customer receivables portfolio. See “Liquidity, Cash Requirements, and Market Conditions” for additional information about our cash flow metrics.

[0001571996-25-000034:mdna:75]
We continue to see opportunities to create value and grow as we respond to long-term demand for our IT solutions driven by a data- and AI-enabled world. We have demonstrated our ability to adjust to changing market conditions with complementary solutions and innovation across both segments of our business, an agile workforce, and the strength of our global supply chain. As we continue to innovate and modernize our offerings, we believe that Dell Technologies is well-positioned for long-term profitable growth.

[0001571996-25-000034:mdna:76]
Net Revenue

[0001571996-25-000034:mdna:77]
Fiscal 2025 compared to Fiscal 2024

[0001571996-25-000034:mdna:78]
During Fiscal 2025, net revenue increased 8%, primarily driven by an increase in ISG net revenue that was partially offset by a decrease in Corporate and other net revenue and, to a lesser extent, CSG net revenue. See “Business Unit Results” for further information.

[0001571996-25-000034:mdna:79]
•Product Net Revenue — Product net revenue includes revenue from the sale of hardware products and software licenses. During Fiscal 2025, product net revenue increased 11% due to an increase in ISG product net revenue driven by growth in our servers and networking offerings. The increase was partially offset by a decrease in CSG product net revenue as a result of a decrease in the average selling prices of our CSG offerings and, to a lesser extent, a decline in units sold within our consumer offerings, as well as a decline in Corporate and other product net revenue as we no longer act as a distributor of standalone VMware offerings.

[0001571996-25-000034:mdna:80]
•Services Net Revenue — Services net revenue includes revenue from our services offerings and support services related to hardware products and software licenses. During Fiscal 2025, services net revenue was flat as the growth within CSG services net revenue and, to a lesser extent, ISG services net revenue was offset by a decline in Corporate and other services net revenue. The increase in CSG services net revenue was primarily due to CSG third-party software support and maintenance as well as support and maintenance associated with products sold in prior periods. The increase in ISG services net revenue was primarily due to support and maintenance associated with products sold in prior periods. Corporate and other services net revenue declined as we no longer act as a distributor of standalone VMware offerings.

[0001571996-25-000034:mdna:81]
A substantial portion of services net revenue is derived from offerings that have been deferred over a period of time, and, as a result, reported growth rates for services net revenue will be different than reported growth rates for product net revenue.

[0001571996-25-000034:mdna:82]
From a geographical perspective, net revenue increased during Fiscal 2025 in the Americas and, to a lesser extent, APJ and remained flat in EMEA.

[0001571996-25-000034:mdna:83]
Fiscal 2024 compared to Fiscal 2023

[0001571996-25-000034:mdna:84]
During Fiscal 2024, net revenue decreased 14%, primarily driven by declines in CSG net revenue and, to a lesser extent, ISG net revenue. See “Business Unit Results” for further information.

[0001571996-25-000034:mdna:85]
•Product Net Revenue — During Fiscal 2024, product net revenue decreased 19% due to declines in CSG product net revenue and, to a lesser extent, ISG product net revenue. CSG product net revenue decreased primarily as a result of a decline in units sold, which impacted both our commercial and consumer offerings. The decline in ISG product net revenue was primarily attributable to a decrease in product net revenue attributable to our servers and networking offerings that was driven by a decrease in units sold and, to a lesser extent, a decline in our product net revenue attributable to storage offerings.

[0001571996-25-000034:mdna:86]
•Services Net Revenue — During Fiscal 2024, services net revenue increased 4%, driven primarily by growth within services net revenue attributable to CSG and Corporate and other. The increase in services net revenue attributable to CSG was driven primarily by third-party software support and maintenance and hardware support and maintenance. The increase in services net revenue attributable to Corporate and other was driven primarily by VMware software maintenance arrangements. See “Introduction” for additional information about the impact of Broadcom’s acquisition of VMware on our relationship with VMware.

[0001571996-25-000034:mdna:87]
From a geographical perspective, net revenue decreased in the Americas, EMEA, and APJ during Fiscal 2024, most notably within APJ.

[0001571996-25-000034:mdna:88]
Gross Margin

[0001571996-25-000034:mdna:89]
Fiscal 2025 compared to Fiscal 2024

[0001571996-25-000034:mdna:90]
During Fiscal 2025, both gross margin and non-GAAP gross margin increased 1%, to $21.3 billion and $21.8 billion, respectively, driven by an increase in ISG gross margin that was largely offset by a decrease in CSG gross margin. The increase in ISG gross margin was primarily attributable to growth in our AI-optimized server offerings and, to a lesser extent, our storage offerings. The decrease in CSG gross margin was primarily attributable to a competitive pricing environment.

[0001571996-25-000034:mdna:91]
During Fiscal 2025, gross margin and non-GAAP gross margin percentage decreased 160 basis points to 22.2% and 170 basis points to 22.8%, respectively. The decreases in gross margin percentage and non-GAAP gross margin percentage were primarily driven by a shift in mix towards AI-optimized server offerings and a competitive CSG pricing environment.

[0001571996-25-000034:mdna:92]
•Product Gross Margin — During Fiscal 2025, product gross margin and non-GAAP product gross margin remained flat at $11.3 billion and decreased 1% to $11.6 billion, respectively, as the decrease in CSG product gross margin was largely offset by an increase in ISG product gross margin. The decline in CSG product gross margin was primarily attributable to a competitive pricing environment. The increase in ISG product gross margin was primarily due to growth in our AI-optimized server offerings and, to a lesser extent, our storage offerings.

[0001571996-25-000034:mdna:93]
During Fiscal 2025, product gross margin percentage and non-GAAP product gross margin percentage decreased 170 basis points to 15.8% and 190 basis points to 16.2%, respectively. The declines were primarily attributable to a shift in mix towards our AI-optimized server offerings and a competitive CSG pricing environment.

[0001571996-25-000034:mdna:94]
•Services Gross Margin — During Fiscal 2025, both services gross margin and non-GAAP services gross margin increased 2%, to $10.0 billion and $10.2 billion, respectively. Services gross margin and non-GAAP services gross margin benefited from an increase in support and maintenance associated with products sold in prior periods within both ISG and CSG and, to a lesser extent, an increase in CSG third-party software support and maintenance.

[0001571996-25-000034:mdna:95]
During Fiscal 2025, services gross margin percentage and non-GAAP services gross margin percentage increased 60 basis points to 41.4% and 80 basis points to 42.4%, respectively. The increases in services gross margin percentage and non-GAAP services gross margin percentage were primarily driven by a shift in mix as we no longer act as a distributor of standalone VMware offerings.

[0001571996-25-000034:mdna:96]
Fiscal 2024 compared to Fiscal 2023

[0001571996-25-000034:mdna:97]
During Fiscal 2024, gross margin and non-GAAP gross margin decreased 7% to $21.1 billion and 8% to $21.6 billion, respectively. The declines were driven by decreases in both ISG and CSG gross margin that were primarily attributable to a decrease in net revenue, the effect of which was partially offset by lower input costs.

[0001571996-25-000034:mdna:98]
Both gross margin and non-GAAP gross margin percentage increased 160 basis points, to 23.8% and 24.5%, respectively, during Fiscal 2024. The increases were primarily attributable to the impacts of an overall decline in input costs coupled with an increase in average selling prices across many of our offerings as we continued to exercise disciplined pricing in an increasingly competitive environment.

[0001571996-25-000034:mdna:99]
•Product Gross Margin — During Fiscal 2024, product gross margin and non-GAAP product gross margin both decreased 15%, to $11.2 billion and $11.6 billion, respectively. The decreases were primarily driven by declines in both ISG and CSG product gross margin, which were largely attributable to declines in product net revenue, partially offset by lower input costs.

[0001571996-25-000034:mdna:100]
During Fiscal 2024, product gross margin percentage and non-GAAP product gross margin percentage both increased 80 basis points, to 17.5% and 18.1%, respectively, primarily due to an increase in CSG product gross margin percentage. CSG product gross margin percentage increased primarily as a result of the impacts of an overall decline in input costs coupled with an increase in average selling prices across many of our product offerings.

[0001571996-25-000034:mdna:101]
•Services Gross Margin — During Fiscal 2024, services gross margin and non-GAAP services gross margin increased 4% to $9.8 billion and 3% to $10.0 billion, respectively. The increases were primarily attributable to growth within ISG services gross margin and, to a lesser extent, CSG services gross margin that were driven by support and maintenance associated with products sold in prior periods.

[0001571996-25-000034:mdna:102]
During Fiscal 2024, services gross margin percentage decreased 30 basis points to 40.8% and non-GAAP services gross margin percentage decreased 50 basis points to 41.6%. The decreases were driven primarily by a shift in mix of services delivered.

[0001571996-25-000034:mdna:103]
Vendor Programs

[0001571996-25-000034:mdna:104]
Our gross margin is affected by our ability to achieve competitive pricing with our vendors and contract manufacturers, including through our negotiation of a variety of vendor rebate programs to achieve lower net costs for the various components we include in our products. Under these programs, vendors provide us with rebates or other discounts from the list prices for the components, which are generally elements of their pricing strategy. We account for vendor rebates and other discounts as a reduction in cost of net revenue. We manage our costs on a total net cost basis, which includes supplier list prices reduced by vendor rebates and other discounts.

[0001571996-25-000034:mdna:105]
The terms and conditions of our vendor rebate programs are largely based on product volumes and are generally negotiated either at the beginning of the annual or quarterly period, depending on the program. The timing and amount of vendor rebates and other discounts we receive under the programs may vary from period to period, reflecting changes in the competitive environment. We monitor our component costs and seek to address the effects of any changes to terms that might arise under our vendor rebate programs. Our gross margins for Fiscal 2025 and Fiscal 2024 were not materially affected by any changes to the terms of our vendor rebate programs, as the amounts we received under these programs were generally stable relative to our total net cost. We are not aware of any significant changes to our vendor rebate programs that will materially impact our results in the near term.

[0001571996-25-000034:mdna:106]
51

[0001571996-25-000034:mdna:107]
Operating Expenses

[0001571996-25-000034:mdna:108]
The following table presents information regarding our operating expenses for the periods indicated:

[0001571996-25-000034:mdna:109]
|  |  |  | Fiscal Year Ended |
|  |  |  |  |  |  |  | January 31, 2025 |  |  |  | February 2, 2024 |  |  |  | February 3, 2023 |
|  |  |  |  |  |  |  |  |  |  |  | Dollars |  | % of Net Revenue |  | % Change |  | Dollars |  | % of Net Revenue |  | % Change |  | Dollars |  | % of Net Revenue |
|  |  |  |  |  |  |  |  |  |  |  | (in millions, except percentages) |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling, general, and administrative |  |  |  |  |  |  |  |  |  |  | $ | 11,952 |  |  | 12.5 | % |  | (7) | % |  | $ | 12,857 |  |  | 14.5 | % |  | (9) | % |  | $ | 14,136 |  |  | 13.9 | % |
| Research and development |  |  |  |  |  |  |  |  |  |  | 3,061 |  |  | 3.2 | % |  | 9 | % |  | 2,801 |  |  | 3.2 | % |  | 1 | % |  | 2,779 |  |  | 2.7 | % |
| Total operating expenses |  |  |  |  |  |  |  |  |  |  | $ | 15,013 |  |  | 15.7 | % |  | (4) | % |  | $ | 15,658 |  |  | 17.7 | % |  | (7) | % |  | $ | 16,915 |  |  | 16.6 | % |
|  |  |  | Fiscal Year Ended |
|  |  |  |  |  |  |  | January 31, 2025 |  |  |  | February 2, 2024 |  |  |  | February 3, 2023 |
|  |  |  |  |  |  |  |  |  |  |  | Dollars |  | % of Net Revenue |  | % Change |  | Dollars |  | % of Net Revenue |  | % Change |  | Dollars |  | % of Net Revenue |
|  |  |  |  |  |  |  |  |  |  |  | (in millions, except percentages) |
| Non-GAAP operating expenses |  |  |  |  |  |  |  |  |  |  | $ | 13,281 |  |  | 13.9 | % |  | (4) | % |  | $ | 13,766 |  |  | 15.6 | % |  | (7) | % |  | $ | 14,790 |  |  | 14.5 | % |

[0001571996-25-000034:mdna:110]
Fiscal 2025 compared to Fiscal 2024

[0001571996-25-000034:mdna:111]
During Fiscal 2025, total operating expenses decreased 4%, due to a decline in selling, general, and administrative (“SG&A”) expenses.

[0001571996-25-000034:mdna:112]
•Selling, General, and Administrative — During Fiscal 2025, SG&A expenses decreased 7%, driven by a decrease in employee compensation and benefits expense, principally due to a decline in overall headcount.

[0001571996-25-000034:mdna:113]
•Research and Development — Research and development (“R&D”) expenses are primarily composed of personnel-related expenses incurred in connection with product development. R&D expenses increased 9% during Fiscal 2025, principally due to an increase in R&D-related employee compensation and benefits expense.

[0001571996-25-000034:mdna:114]
As a percentage of net revenue, R&D expenses for both Fiscal 2025 and Fiscal 2024 were 3.2%. We continue to support R&D initiatives to innovate and introduce new and enhanced solutions into the market.

[0001571996-25-000034:mdna:115]
During Fiscal 2025, non-GAAP operating expenses decreased 4%, driven by a decline in employee compensation and benefits expense, primarily resulting from a decline in overall headcount. The decline in employee compensation and benefits expense was partially offset by continued support of R&D initiatives.

[0001571996-25-000034:mdna:116]
We continue to make strategic investments designed to enable growth and innovation, while balancing our efforts to drive cost efficiencies in the business. We also expect to continue making investments in support of our own digital transformation, which aims to streamline and optimize our business processes.

[0001571996-25-000034:mdna:117]
Fiscal 2024 compared to Fiscal 2023

[0001571996-25-000034:mdna:118]
During Fiscal 2024, total operating expenses decreased 7% due to a decline in SG&A expenses.

[0001571996-25-000034:mdna:119]
•Selling, General, and Administrative — During Fiscal 2024, SG&A expenses decreased 9%, driven by a decrease in employee compensation and benefits expense, principally due to a decline in overall headcount and, to a lesser extent, a decrease in advertising and outside services expense as a result of continued disciplined cost management.

[0001571996-25-000034:mdna:120]
•Research and Development — R&D expenses increased 1% during Fiscal 2024 principally due to an increase in R&D-related employee compensation and benefits expense, partially offset by a decrease in outside services as a result of continued disciplined cost management.

[0001571996-25-000034:mdna:121]
52

[0001571996-25-000034:mdna:122]
As a percentage of net revenue, R&D expenses for Fiscal 2024 and Fiscal 2023 were 3.2% and 2.7%, respectively. The increases in R&D expenses as a percentage of net revenue were attributable to continued R&D investments as we support R&D initiatives to innovate and introduce new and enhanced solutions into the market.

[0001571996-25-000034:mdna:123]
During Fiscal 2024, non-GAAP operating expenses decreased 7% principally due to continued disciplined cost management, which resulted in a decline in employee compensation and benefits, outside services, and advertising expenses, among other items.

[0001571996-25-000034:mdna:124]
Operating Income

[0001571996-25-000034:mdna:125]
Fiscal 2025 compared to Fiscal 2024

[0001571996-25-000034:mdna:126]
During Fiscal 2025, operating income and non-GAAP operating income increased by 15% to $6.2 billion and 8% to $8.5 billion, respectively. During Fiscal 2025, the increases in operating income and non-GAAP operating income were primarily attributable to an increase in ISG operating income that was driven by our servers and networking offerings and, to a lesser extent, our storage offerings, which was partially offset by a decrease in CSG operating income.

[0001571996-25-000034:mdna:127]
During Fiscal 2025, operating income and non-GAAP operating income as a percentage of net revenue increased 40 basis points to 6.5% and remained flat at 8.9%, respectively. The operating income and non-GAAP operating income rates during the current year were affected by the favorable impact of a decrease in operating expense rate that was driven by strong ISG net revenue growth coupled with continued disciplined cost management. The favorable impact of a decrease in operating expense rate was offset by a decline in gross margin as a percentage of net revenue due to a shift in mix towards AI-optimized server offerings and a competitive CSG pricing environment.

[0001571996-25-000034:mdna:128]
Fiscal 2024 compared to Fiscal 2023

[0001571996-25-000034:mdna:129]
Operating income and non-GAAP operating income decreased by 6% to $5.4 billion and 9% to $7.9 billion, respectively, during Fiscal 2024. The decreases were driven by a decrease in ISG operating income, which declined primarily as a result of a decrease in net revenue that outpaced the favorable impacts of a decline in input costs and cost management measures. The decline in ISG operating income was primarily attributable to decreases in our servers and networking offerings and, to a lesser extent, our storage offerings. The decline in operating income was partially offset by decreases in other corporate expenses and amortization of intangibles.

[0001571996-25-000034:mdna:130]
During Fiscal 2024, both operating income and non-GAAP operating income as a percentage of net revenue increased 50 basis points, to 6.1% and 8.9%, respectively. The increases were due to an increase in gross margin as a percentage of net revenue, which was principally driven by a decline in input costs. The increase in operating income and non-GAAP operating income as a percentage of net revenue was offset by an increase in operating expense rate, principally within ISG, that was attributable to a decrease in net revenue which outpaced the impact of continued cost management measures.

[0001571996-25-000034:mdna:131]
Interest and Other, Net

[0001571996-25-000034:mdna:132]
The following table presents information regarding interest and other, net for the periods indicated:

[0001571996-25-000034:mdna:133]
|  |  |  | Fiscal Year Ended |
|  |  |  |  |  | January 31, 2025 |  | February 2, 2024 |  | February 3, 2023 |
|  |  |  |  |  | (in millions) |
| Interest and other, net: |  |  |  |  |  |  |  |  |  |
| Investment income, primarily interest |  |  |  |  | $ | 160 |  |  | $ | 305 |  |  | $ | 100 |  |
| Gain (loss) on investments, net |  |  |  |  | 177 |  |  | 47 |  |  | (206) |  |
| Interest expense |  |  |  |  | (1,394) |  |  | (1,501) |  |  | (1,222) |  |
| Foreign exchange |  |  |  |  | (112) |  |  | (199) |  |  | (265) |  |
| Legal settlement, net |  |  |  |  | — |  |  | — |  |  | (894) |  |
| Other |  |  |  |  | (20) |  |  | 24 |  |  | (59) |  |
| Total interest and other, net |  |  |  |  | $ | (1,189) |  |  | $ | (1,324) |  |  | $ | (2,546) |  |

[0001571996-25-000034:mdna:134]
Fiscal 2025 compared to Fiscal 2024

[0001571996-25-000034:mdna:135]
During Fiscal 2025, the change in interest and other, net was favorable primarily due to gains recognized within our strategic investments portfolio and a reduction in interest expense, partially offset by a decline in interest income on investments.

[0001571996-25-000034:mdna:136]
Fiscal 2024 compared to Fiscal 2023

[0001571996-25-000034:mdna:137]
The change in interest and other, net was favorable primarily as a result of $0.9 billion of expense recognized in Fiscal 2023 in connection with an agreement to settle the Class V transaction litigation, coupled with a gain on investments and an increase in investment income during Fiscal 2024. Favorable impacts within interest and other, net were partially offset by an increase in interest expense primarily associated with DFS securitization and structured financing programs. See Note 11 to the Notes to the Consolidated Financial Statements for additional information about the settlement of the Class V transaction litigation.

[0001571996-25-000034:mdna:138]
Income and Other Taxes

[0001571996-25-000034:mdna:139]
The following table presents information regarding our income and other taxes for the periods indicated:

[0001571996-25-000034:mdna:140]
|  |  |  | Fiscal Year Ended |
|  |  |  |  |  | January 31, 2025 |  | February 2, 2024 |  | February 3, 2023 |
|  |  |  |  |  | (in millions, except percentages) |
| Income before income taxes |  |  |  |  | $ | 5,048 |  |  | $ | 4,087 |  |  | $ | 3,225 |  |
| Income tax expense |  |  |  |  | $ | 472 |  |  | $ | 715 |  |  | $ | 803 |  |
| Effective income tax rate |  |  |  |  | 9.4 | % |  | 17.5 | % |  | 24.9 | % |

[0001571996-25-000034:mdna:141]
Fiscal 2025 compared to Fiscal 2024

[0001571996-25-000034:mdna:142]
For Fiscal 2025 and Fiscal 2024, our effective income tax rates were 9.4% and 17.5%, respectively. The change in our effective tax rates for Fiscal 2025 as compared to Fiscal 2024 was primarily attributable to discrete tax items. For Fiscal 2025, we recorded discrete tax benefits of $0.4 billion related to changes in uncertain tax benefits resulting from the expiration of certain U.S. statutes of limitations and $0.2 billion related to stock-based compensation.

[0001571996-25-000034:mdna:143]
54

[0001571996-25-000034:mdna:144]
Our effective income tax rate can fluctuate depending on the geographic distribution of our worldwide earnings, as our foreign earnings are generally taxed at lower rates than in the United States. The differences between our effective income tax rates and the U.S. federal statutory rate of 21% principally result from the geographical distribution of income, differences between the book and tax treatment of certain items, and discrete tax items. In certain jurisdictions, our tax rate is significantly less than the applicable statutory rate as a result of tax holidays. The majority of our foreign income subject to these tax holidays is attributable to Singapore and China. A significant portion of these income tax benefits relates to a tax holiday that will be effective until January 31, 2029. Most of our other tax holidays will expire in whole or in part during Fiscal 2030 and Fiscal 2031. Many of these tax holidays and reduced tax rates may be extended when certain conditions are met or may be terminated early if certain conditions are not met or as a result of changes in tax legislation. As of January 31, 2025, we were not aware of any matters of non-compliance. Our income tax benefits attributable to tax holidays and incentives of the affected subsidiaries were immaterial to our provision for income taxes and earnings per share for Fiscal 2025 and Fiscal 2024.

[0001571996-25-000034:mdna:145]
Many countries, including Singapore, a country in which we have a tax holiday, have enacted or are in the process of enacting laws based on the Pillar Two proposal relating to a global minimum tax issued by the Organisation for Economic Co-operation and Development (“OECD”). While we expect our effective income tax rate and cash income tax payments may increase in future years as a result of the global minimum tax, the tax did not have a material impact on our Fiscal 2025 consolidated results of operations and we do not expect a material impact for Fiscal 2026. Our assessment could be affected by legislative guidance and future enactment of additional provisions within the Pillar Two framework.

[0001571996-25-000034:mdna:146]
For further discussion regarding tax matters, including the status of income tax audits, see Note 12 of the Notes to the Consolidated Financial Statements included in this report.

[0001571996-25-000034:mdna:147]
Fiscal 2024 compared to Fiscal 2023

[0001571996-25-000034:mdna:148]
For Fiscal 2024 and Fiscal 2023, our effective income tax rates were 17.5% and 24.9%, respectively. The change related to our effective income tax rates for Fiscal 2024 as compared to Fiscal 2023 was primarily attributable to the tax impact of foreign operations and benefits from U.S. research and development tax credits. In addition, our effective tax rate for Fiscal 2023 included the impact of an expense recognized in connection with the agreement to settle the Class V transaction litigation described in Note 11 of the Notes to the Consolidated Financial Statements included in this report.

[0001571996-25-000034:mdna:149]
Net Income

[0001571996-25-000034:mdna:150]
Fiscal 2025 compared to Fiscal 2024

[0001571996-25-000034:mdna:151]
During Fiscal 2025, net income and non-GAAP net income increased 36% to $4.6 billion and 8% to $5.9 billion, respectively. Net income increased primarily due to an increase in operating income and, to a lesser extent, lower income tax expense. Non-GAAP net income increased primarily due to an increase in operating income.

[0001571996-25-000034:mdna:152]
Fiscal 2024 compared to Fiscal 2023

[0001571996-25-000034:mdna:153]
During Fiscal 2024, net income increased 39% to $3.4 billion, driven primarily by a favorable change in interest and other, net, partially offset by a decline in operating income. During Fiscal 2024, non-GAAP net income decreased 5% to $5.4 billion, driven by a decline in operating income, partially offset by a decline in income tax expense.

[0001571996-25-000034:mdna:154]
Business Unit Results

[0001571996-25-000034:mdna:155]
Our reportable segments are based on the ISG and CSG business units. A description of our business units is provided under “Introduction.” See Note 18 of the Notes to the Consolidated Financial Statements included in this report for a reconciliation of net revenue and operating income by reportable segment to consolidated net revenue and consolidated operating income, respectively.

[0001571996-25-000034:mdna:156]
Infrastructure Solutions Group

[0001571996-25-000034:mdna:157]
The following table presents net revenue and operating income attributable to ISG for the periods indicated:

[0001571996-25-000034:mdna:158]
|  |  |  | Fiscal Year Ended |
|  |  |  |  |  |  |  | January 31, 2025 |  | % Change |  | February 2, 2024 |  | % Change |  | February 3, 2023 |
|  |  |  |  |  |  |  | (in millions, except percentages) |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Servers and networking |  |  |  |  |  |  | $ | 27,136 |  | 54 | % |  | $ | 17,624 |  | (14) | % |  | $ | 20,398 |
| Storage |  |  |  |  |  |  | 16,457 |  | 1 | % |  | 16,261 |  | (9) | % |  | 17,958 |
| Total ISG net revenue |  |  |  |  |  |  | $ | 43,593 |  | 29 | % |  | $ | 33,885 |  | (12) | % |  | $ | 38,356 |
| Operating income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| ISG operating income |  |  |  |  |  |  | $ | 5,579 |  | 30 | % |  | $ | 4,286 |  | (15) | % |  | $ | 5,045 |
| % of segment net revenue |  |  |  |  |  |  | 12.8 | % |  |  |  | 12.6 | % |  |  |  | 13.2 | % |

[0001571996-25-000034:mdna:159]
Fiscal 2025 compared to Fiscal 2024

[0001571996-25-000034:mdna:160]
Net Revenue — During Fiscal 2025, ISG net revenue increased 29%, driven primarily by strength in our servers and networking offerings.

[0001571996-25-000034:mdna:161]
Net revenue from sales of servers and networking increased 54% during Fiscal 2025. The increase in servers and networking net revenue was driven by growth in our AI-optimized server offerings and, to a lesser extent, our traditional server and networking offerings.

[0001571996-25-000034:mdna:162]
Storage net revenue increased 1% during Fiscal 2025 primarily due to an increase in our core storage offerings.

[0001571996-25-000034:mdna:163]
From a geographical perspective, net revenue attributable to ISG increased across all regions during Fiscal 2025, most notably in the Americas.

[0001571996-25-000034:mdna:164]
Operating Income — During Fiscal 2025, ISG operating income as a percentage of net revenue increased 20 basis points to 12.8% due to a decline in operating expense as a percentage of revenue that outpaced the decline in gross margin rate. Operating expense as a percentage of net revenue declined primarily due to strong ISG net revenue growth coupled with continued disciplined cost management. Gross margin rate decreased primarily as the result of a shift in mix towards AI-optimized server offerings.

[0001571996-25-000034:mdna:165]
Fiscal 2024 compared to Fiscal 2023

[0001571996-25-000034:mdna:166]
Net Revenue — During Fiscal 2024, ISG net revenue decreased 12%, driven primarily by servers and networking net revenue and, to a lesser extent, storage net revenue as global macroeconomic conditions continued to impact demand.

[0001571996-25-000034:mdna:167]
Revenue from sales of servers and networking decreased 14% during Fiscal 2024, driven by a decrease in units sold, the effect of which was partially offset by an increase in the average selling prices of our server offerings. The average selling prices of our server offerings increased as a result of the impact of attached offerings and richer configurations.

[0001571996-25-000034:mdna:168]
During Fiscal 2024, storage net revenue decreased 9%, driven by a decline in net revenue across the majority of our storage offerings.

[0001571996-25-000034:mdna:169]
56

[0001571996-25-000034:mdna:170]
From a geographical perspective, net revenue attributable to ISG decreased in the Americas, EMEA, and APJ during Fiscal 2024.

[0001571996-25-000034:mdna:171]
Operating Income — During Fiscal 2024, ISG operating income as a percentage of net revenue decreased 60 basis points to 12.6% principally due to an increase in operating expenses as a percentage of net revenue. Operating expenses as a percentage of net revenue increased as a result of a decline in revenue that outpaced the impact of continued cost management measures coupled with continued investment in research and development. The impact of an increase in operating expenses as a percentage of net revenue was partially offset by an overall decline in input costs coupled with an increase in average selling prices.

[0001571996-25-000034:mdna:172]
57

[0001571996-25-000034:mdna:173]
Client Solutions Group

[0001571996-25-000034:mdna:174]
The following table presents net revenue and operating income attributable to CSG for the periods indicated:

[0001571996-25-000034:mdna:175]
|  |  |  | Fiscal Year Ended |
|  |  |  |  |  |  |  | January 31, 2025 |  | % Change |  | February 2, 2024 |  | % Change |  | February 3, 2023 |
|  |  |  |  |  |  |  | (in millions, except percentages) |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Commercial |  |  |  |  |  |  | $ | 40,844 |  | 3 | % |  | $ | 39,814 |  | (13) | % |  | $ | 45,556 |
| Consumer |  |  |  |  |  |  | 7,549 |  | (17) | % |  | 9,102 |  | (28) | % |  | 12,657 |
| Total CSG net revenue |  |  |  |  |  |  | $ | 48,393 |  | (1) | % |  | $ | 48,916 |  | (16) | % |  | $ | 58,213 |
| Operating income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| CSG operating income |  |  |  |  |  |  | $ | 2,972 |  | (20) | % |  | $ | 3,712 |  | (3) | % |  | $ | 3,824 |
| % of segment net revenue |  |  |  |  |  |  | 6.1 | % |  |  |  | 7.6 | % |  |  |  | 6.6 | % |

[0001571996-25-000034:mdna:176]
Fiscal 2025 compared to Fiscal 2024

[0001571996-25-000034:mdna:177]
Net Revenue — During Fiscal 2025, CSG net revenue declined 1% primarily due to a decrease in units sold and, to a lesser extent, a decline in the average selling prices of our offerings.

[0001571996-25-000034:mdna:178]
Commercial net revenue increased 3% during Fiscal 2025 primarily due to an increase in units sold. Consumer net revenue decreased 17% during Fiscal 2025, primarily as the result of a decline in units sold and, to a lesser extent, a decline in the average selling prices of our consumer offerings.

[0001571996-25-000034:mdna:179]
From a geographical perspective, net revenue attributable to CSG decreased in APJ and the Americas and increased in EMEA during Fiscal 2025.

[0001571996-25-000034:mdna:180]
Operating Income — During Fiscal 2025, CSG operating income as a percentage of net revenue decreased 150 basis points to 6.1% primarily due to a decline in gross margin rate, which was partially offset by a decrease in operating expenses as a percentage of net revenue. The decline in gross margin rate was primarily the result of a competitive pricing environment. The decline in operating expenses as a percentage of net revenue was due to continued disciplined cost management.

[0001571996-25-000034:mdna:181]
Fiscal 2024 compared to Fiscal 2023

[0001571996-25-000034:mdna:182]
Net Revenue — During Fiscal 2024, CSG net revenue decreased 16% driven by a decline in units sold as global macroeconomic conditions continued to impact demand.

[0001571996-25-000034:mdna:183]
Commercial net revenue decreased 13% during Fiscal 2024. The decline was primarily due to a decrease in units sold, which was partially offset by the effect of an increase in the average selling prices of our commercial offerings. Average selling prices of our commercial offerings increased primarily as a result of richer configurations and the mix of offerings sold. Consumer net revenue decreased 28% during Fiscal 2024 principally due to a decrease in units sold and, to a lesser extent, a decline in the average selling prices of our consumer offerings.

[0001571996-25-000034:mdna:184]
From a geographical perspective, net revenue attributable to CSG decreased primarily in APJ and, to a lesser extent, in the Americas and EMEA during Fiscal 2024.

[0001571996-25-000034:mdna:185]
Operating Income — During Fiscal 2024, CSG operating income as a percentage of net revenue increased 100 basis points to 7.6% primarily due to the impact of an overall decrease in input costs coupled with an increase in the average selling prices of our commercial offerings, as described above. The impact of these factors was partially offset by an increase in operating expenses as a percentage of net revenue, which increased as a result of a decline in CSG net revenue that outpaced the impact of continued cost management measures.

[0001571996-25-000034:mdna:186]
OTHER BALANCE SHEET ITEMS

[0001571996-25-000034:mdna:187]
Accounts Receivable

[0001571996-25-000034:mdna:188]
We sell products and services directly to customers and through a variety of sales channels, including retail distribution. Our accounts receivable, net was $10.3 billion and $9.3 billion as of January 31, 2025 and February 2, 2024, respectively. Accounts receivable, net was up due to growth in our AI-optimized server offerings and the timing of cash receipts. We maintain an allowance for expected credit losses to cover receivables that may be deemed uncollectible. The allowance for expected credit losses is an estimate based on an analysis of historical loss experience, current receivables aging, and management’s assessment of current conditions and its reasonable and supportable expectation of future conditions, as well as specific identifiable customer accounts that are deemed at risk. As of January 31, 2025 and February 2, 2024, the allowance for expected credit losses was $63 million and $71 million, respectively. Based on our assessment, we believe that we are adequately reserved for expected credit losses.

[0001571996-25-000034:mdna:189]
Dell Financial Services and Financing Receivables

[0001571996-25-000034:mdna:190]
We offer or arrange a portfolio of payment and consumption solutions and services for our customers globally, including as-a-Service, subscription, utility, leases, and loans designed to match customers' consumption and financing preferences. We believe these options provide operational and financial flexibility and strengthen our customer relationships. To support financing solutions and services as part of the portfolio, DFS originates, collects, and services customer receivables primarily related to the purchase of our product and services solutions. New financing originations were $8.4 billion for both Fiscal 2025 and Fiscal 2024 and $9.7 billion for Fiscal 2023.

[0001571996-25-000034:mdna:191]
Our leases are generally classified as sales-type leases or operating leases. On commencement of sales-type leases, we recognize profit up-front, and recognize amounts due from the customer under the lease contract as financing receivables. Interest income is recognized as net product revenue over the term of the lease. Upon origination of operating leases, we record equipment under operating leases, classified as property, plant, and equipment, net. We recognize product revenue and depreciation expense, classified as cost of net revenue, over the contract term.

[0001571996-25-000034:mdna:192]
As of January 31, 2025 and February 2, 2024, our financing receivables, net were $11.2 billion and $10.5 billion, respectively. We maintain an allowance to cover expected financing receivables credit losses and evaluate credit loss expectations based on our total portfolio. The principal charge-off rate for our financing receivables portfolio was 0.6% for Fiscal 2025 and 0.5% for both Fiscal 2024 and Fiscal 2023. The credit quality of our financing receivables remains strong due to the mix of high-quality commercial accounts in our portfolio. We continue to monitor broader economic indicators and their potential impact on future credit loss performance. We have an extensive process to manage our exposure to customer credit risk that includes active management of credit lines and collection activities. We also sell selected fixed-term financing receivables without recourse to unrelated third parties on a periodic basis, primarily to manage certain concentrations of customer credit exposure. Based on our assessment of the customer financing receivables, we believe that we are adequately reserved.

[0001571996-25-000034:mdna:193]
We retain a residual interest in equipment leased under our lease programs. As of January 31, 2025 and February 2, 2024, the residual interest recorded as part of financing receivables was $168 million and $157 million, respectively. The amount of the residual interest is established at the inception of the lease based upon estimates of the value of the equipment at the end of the lease term using historical studies, industry data, and future value-at-risk demand valuation methods. On a quarterly basis, we assess the carrying amount of our recorded residual values for expected losses. Generally, expected losses as a result of residual value risk on equipment under lease are not considered to be significant primarily because of the existence of a secondary market with respect to the equipment. Further, the lease agreement defines applicable return conditions and remedies for non-compliance to ensure that the leased equipment will be in good operating condition upon return. No expected losses were recorded related to residual assets during Fiscal 2025 and Fiscal 2024.

[0001571996-25-000034:mdna:194]
As of both January 31, 2025 and February 2, 2024, equipment under operating leases, net was $2.2 billion. We assess the carrying amount of the equipment under operating leases for impairment whenever events or circumstances may indicate that an impairment has occurred. No material impairment losses were recorded related to such equipment during Fiscal 2025, Fiscal 2024, and Fiscal 2023.

[0001571996-25-000034:mdna:195]
DFS offerings are initially funded through cash on hand at the time of origination, most of which is subsequently replaced with asset-backed financing. For offerings that qualify as sales-type leases, the initial funding of financing receivables is reflected as an impact to cash flows from operations and is largely subsequently offset by cash proceeds from financing. For offerings that qualify as operating leases, the initial funding is classified as a capital expenditure and reflected as an impact to cash flows used in investing activities.

[0001571996-25-000034:mdna:196]
See Note 5 of the Notes to the Consolidated Financial Statements included in this report for additional information about our financing receivables and the associated allowances, and equipment under operating leases.

[0001571996-25-000034:mdna:197]
60

[0001571996-25-000034:mdna:198]
LIQUIDITY, CASH REQUIREMENTS, AND MARKET CONDITIONS

[0001571996-25-000034:mdna:199]
Liquidity and Capital Resources

[0001571996-25-000034:mdna:200]
We rely on operating cash flows, which are impacted by trends in the demand environment, as our primary source of liquidity for our ongoing business operations. We monitor the efficiency of our balance sheet to ensure that we have adequate liquidity to support our business and strategic initiatives.

[0001571996-25-000034:mdna:201]
In addition to internally generated cash, we have access to other capital sources to finance our strategic initiatives and fund growth in our financing operations. Our strategy is to deploy capital from any potential source, whether internally generated cash or debt, depending on the adequacy and availability of that source of capital and whether it can be accessed in a cost-effective manner.

[0001571996-25-000034:mdna:202]
We believe that our current cash and cash equivalents, together with cash that will be provided by future operations and borrowings and issuances expected to be available under our revolving credit facility and commercial paper program, will be sufficient over the next twelve months and for the foreseeable future thereafter to meet our material cash requirements, including funding of our operations, debt-related payments, capital expenditures, and other corporate needs.

[0001571996-25-000034:mdna:203]
As part of our overall capital allocation strategy, we intend to return capital to our stockholders through both share repurchase programs and dividend payments and use the remaining available cash to drive growth and maintain our investment grade credit rating.

[0001571996-25-000034:mdna:204]
The following table presents our cash and cash equivalents as well as our available borrowings as of the dates indicated:

[0001571996-25-000034:mdna:205]
|  | January 31, 2025 |  | February 2, 2024 |
|  | (in millions) |
| Cash and cash equivalents, and available borrowings: |  |  |  |
| Cash and cash equivalents | $ | 3,633 |  |  | $ | 7,366 |  |
| Remaining available borrowings under the revolving credit facility | 5,999 |  |  | 5,999 |  |
| Total cash and cash equivalents, and available borrowings | $ | 9,632 |  |  | $ | 13,365 |  |

[0001571996-25-000034:mdna:206]
During Fiscal 2025, cash and cash equivalents decreased by $3.7 billion primarily due to the return of capital to our stockholders, capital expenditures, net repayment of DFS debt and Senior Notes, and payments to settle employee tax withholdings on stock-based compensation, the effects of which were partially offset by cash flows from operations.

[0001571996-25-000034:mdna:207]
As of January 31, 2025, our revolving credit facility had a maximum capacity of $6.0 billion. Available borrowings under this facility are reduced by draws on the facility and outstanding letters of credit. As of January 31, 2025, there were no borrowings outstanding under the facility and remaining available borrowings totaled approximately $6.0 billion. The revolving credit facility also acts as a backstop to provide liquidity support for our commercial paper program.

[0001571996-25-000034:mdna:208]
We maintain a commercial paper program under which we may issue unsecured notes in a maximum aggregate face amount of $5.0 billion outstanding at any time, with maturities of up to 397 days from the date of issue. As of January 31, 2025, we had no outstanding issuances under the program.

[0001571996-25-000034:mdna:209]
We may regularly use our available borrowings from the revolving credit facility and issuances under the commercial paper program, generally on a short-term basis, for general corporate purposes. See the following discussion for additional information about our debt.

[0001571996-25-000034:mdna:210]
Debt

[0001571996-25-000034:mdna:211]
The following table presents our outstanding debt as of the dates indicated:

[0001571996-25-000034:mdna:212]
|  | January 31, 2025 |  | Change |  | February 2, 2024 |
|  | (in millions) |
| Core debt |  |  |  |  |  |
| Senior Notes | $ | 15,073 |  |  | $ | (534) |  |  | $ | 15,607 |  |
| Legacy Notes | 952 |  |  | — |  |  | 952 |  |
| DFS allocated debt | (3,028) |  |  | (1,388) |  |  | (1,640) |  |
| Total core debt | 12,997 |  |  | (1,922) |  |  | 14,919 |  |
| DFS related debt |  |  |  |  |  |
| DFS debt | 8,711 |  |  | (781) |  |  | 9,492 |  |
| DFS allocated debt | 3,028 |  |  | 1,388 |  |  | 1,640 |  |
| Total DFS related debt | 11,739 |  |  | 607 |  |  | 11,132 |  |
| Other | 52 |  |  | (119) |  |  | 171 |  |
| Total debt, principal amount | 24,788 |  |  | (1,434) |  |  | 26,222 |  |
| Carrying value adjustments | (221) |  |  | 7 |  |  | (228) |  |
| Total debt, carrying value | $ | 24,567 |  |  | $ | (1,427) |  |  | $ | 25,994 |  |

[0001571996-25-000034:mdna:213]
The outstanding principal amount of our debt decreased $1.4 billion to $24.8 billion as of January 31, 2025, driven primarily by net repayments of our DFS debt and Senior Notes.

[0001571996-25-000034:mdna:214]
We define core debt as the total principal amount of our debt, less DFS related debt and other debt. Our core debt was $13.0 billion and $14.9 billion as of January 31, 2025 and February 2, 2024, respectively. See Note 7 of the Notes to the Consolidated Financial Statements included in this report for additional information about our debt.

[0001571996-25-000034:mdna:215]
DFS related debt primarily represents debt from our securitization and structured financing programs. Our risk of loss under these programs is limited to transferred lease and loan payments and associated equipment, as the credit holders have no recourse to Dell Technologies.

[0001571996-25-000034:mdna:216]
To fund the expansion of our DFS business, we balance the use of the securitization and structured financing programs with other sources of liquidity. We approximate the amount of our core debt used to fund the DFS business by applying a 7:1 debt-to-equity ratio to the sum of our financing receivables balance and equipment under operating leases, net, also referred to as DFS owned assets. The debt-to-equity ratio is based on the underlying credit quality of the assets. See Note 5 of the Notes to the Consolidated Financial Statements included in this report for additional information about our DFS debt.

[0001571996-25-000034:mdna:217]
The following table presents DFS owned assets as of the dates indicated:

[0001571996-25-000034:mdna:218]
|  | January 31, 2025 |  | February 2, 2024 |
|  | (in millions) |
| Financing receivables, net | $ | 11,231 |  |  | $ | 10,520 |  |
| Equipment under operating leases, net | 2,185 |  |  | 2,202 |  |
| DFS owned assets | $ | 13,416 |  |  | $ | 12,722 |  |

[0001571996-25-000034:mdna:219]
We believe we will continue to be able to make our debt principal and interest payments, including payment of short-term maturities, from existing and expected sources of cash, primarily from operating cash flows. Cash used for debt principal and interest payments may include short-term borrowings under our commercial paper program, our revolving credit facility, or other borrowings. Under our variable-rate debt, we could experience variations in our future interest expense from potential fluctuations in applicable reference rates, or from possible fluctuations in the level of DFS debt required to meet future demand for customer financing.

[0001571996-25-000034:mdna:220]
At our sole discretion, we may purchase, redeem, prepay, refinance, or otherwise retire any amount of our outstanding indebtedness under the terms of such indebtedness at any time and from time to time, in open market or negotiated transactions with the holders of such indebtedness or otherwise, as we consider appropriate in light of market conditions and other relevant factors.

[0001571996-25-000034:mdna:221]
Cash Flows

[0001571996-25-000034:mdna:222]
The following table presents a summary of our Consolidated Statements of Cash Flows for the periods indicated:

[0001571996-25-000034:mdna:223]
|  | Fiscal Year Ended |
|  | January 31, 2025 |  | February 2, 2024 |  | February 3, 2023 |
|  | (in millions) |
| Net change in cash from: |  |  |  |  |  |
| Operating activities | $ | 4,521 |  |  | $ | 8,676 |  |  | $ | 3,565 |  |
| Investing activities | (2,215) |  |  | (2,783) |  |  | (3,024) |  |
| Financing activities | (5,815) |  |  | (7,094) |  |  | (1,625) |  |
| Effect of exchange rate changes on cash, cash equivalents, and restricted cash | (179) |  |  | (186) |  |  | (104) |  |
| Change in cash, cash equivalents, and restricted cash | $ | (3,688) |  |  | $ | (1,387) |  |  | $ | (1,188) |  |

[0001571996-25-000034:mdna:224]
Operating Activities — Cash provided by operating activities was $4.5 billion during Fiscal 2025 and was driven by profitability, partially offset by working capital dynamics. Working capital was primarily impacted by AI, which led to higher inventory, accounts receivable, and accounts payable levels. During Fiscal 2024, cash provided by operating activities was $8.7 billion, which was primarily driven by profitability coupled with strong inventory management and cash collections performance. Cash provided by operating activities during Fiscal 2024 also reflected the impact of the $0.9 billion net payment to settle the Class V transaction litigation and $0.4 billion in proceeds from the sale of our U.S. consumer revolving customer receivables portfolio.

[0001571996-25-000034:mdna:225]
Investing Activities — Investing activities primarily consist of cash used to fund capital expenditures for property, plant, and equipment inclusive of equipment under operating leases and equipment used to support our as-a-Service offerings, which we refer to collectively as assets in a customer contract. Additional activities may include capitalized software development costs, the maturities, sales, and purchases of investments, and acquisitions and divestitures. Cash used in investing activities was $2.2 billion and $2.8 billion during Fiscal 2025 and Fiscal 2024, respectively, and was primarily applied to capital expenditures.

[0001571996-25-000034:mdna:226]
Financing Activities — Financing activities primarily consist of the proceeds and repayments of debt and return of capital to our stockholders. Cash used in financing activities was $5.8 billion during Fiscal 2025 and primarily consisted of repurchases of common stock, inclusive of payments to settle employee tax withholdings on stock-based compensation, net repayments of our DFS debt and Senior Notes, and the payment of quarterly dividends. During Fiscal 2024, cash used in financing activities was $7.1 billion and primarily consisted of principal repayments of our Senior Notes, repurchases of common stock, inclusive of payments to settle employee tax withholdings on stock-based compensation, and the payment of quarterly dividends.

[0001571996-25-000034:mdna:227]
DFS Cash Flow Impacts — DFS offerings are initially funded through cash on hand at the time of origination, most of which is subsequently replaced with asset-backed financing. For offerings that qualify as sales-type leases, the initial funding of financing receivables is reflected as an impact to cash flows from operations and is largely subsequently offset by cash proceeds from financing. For offerings that qualify as operating leases, the initial funding is classified as a capital expenditure and reflected as cash flows used in investing activities. DFS new financing originations were $8.4 billion during both Fiscal 2025 and Fiscal 2024 and $9.7 billion during Fiscal 2023. As of January 31, 2025, we had $11.2 billion of total net financing receivables and $2.2 billion of equipment under operating leases, net.

[0001571996-25-000034:mdna:228]
Supply Chain Finance Program — We maintain a Supply Chain Finance Program (the “SCF Program”) that enables eligible suppliers to sell receivables due from us to a third-party financial institution at the suppliers’ sole discretion. The SCF Program does not impact our liquidity, as payments by us to participating suppliers are remitted to the financial institution on the original invoice due date. Further, we negotiate payment terms with our suppliers regardless of their decision to participate in the SCF Program. Payments made under the SCF Program are included in cash flows from operating activities on the Consolidated Statements of Cash Flows. See Note 20 of the Notes to the Consolidated Financial Statements included in this report for more information regarding the SCF Program.

[0001571996-25-000034:mdna:229]
Material Capital Commitments and Cash Requirements

[0001571996-25-000034:mdna:230]
The Company’s material capital commitments include the following:

[0001571996-25-000034:mdna:231]
Capital Expenditures — We spent $2.7 billion and $2.8 billion during Fiscal 2025 and Fiscal 2024, respectively, on property, plant, and equipment and capitalized software development costs. Of total expenditures incurred, funding of assets in a customer contract totaled $1.3 billion and $1.2 billion during Fiscal 2025 and Fiscal 2024, respectively. Product demand, product mix, the use of contract manufacturers, and ongoing investments in operating and information technology infrastructure influence the level and prioritization of our capital expenditures.

[0001571996-25-000034:mdna:232]
Repurchases of Common Stock — On September 23, 2021, our Board of Directors approved a stock repurchase program with no fixed expiration date under which we may repurchase up to $5 billion of shares of Class C Common Stock, exclusive of any fees, commissions, or other expenses related to such repurchases. On October 5, 2023 and February 27, 2025, subsequent to the close of Fiscal 2025, our Board of Directors authorized additional shares for repurchase under the stock repurchase program of $5 billion and $10 billion, respectively. Following the February 27, 2025 approval, we had approximately $11.5 billion of authorized shares remaining under the program.

[0001571996-25-000034:mdna:233]
During Fiscal 2025, we repurchased approximately 22 million shares of Class C Common Stock for a total purchase price of approximately $2.6 billion. During Fiscal 2024, we repurchased approximately 34 million shares of Class C Common Stock for a total purchase price of approximately $2.1 billion.

[0001571996-25-000034:mdna:234]
Dividend Payments — During Fiscal 2025 and Fiscal 2024, the Company paid $1.3 billion and $1.1 billion in dividends and dividend equivalents at a rate of $0.445 and $0.37 per share per fiscal quarter, respectively.

[0001571996-25-000034:mdna:235]
On February 27, 2025, we announced that the Board of Directors approved an 18% increase in the dividend rate to $0.525 per share per fiscal quarter beginning in the first quarter of Fiscal 2026.

[0001571996-25-000034:mdna:236]
Additionally, the Company’s material cash requirements include the following contractual obligations:

[0001571996-25-000034:mdna:237]
Debt — Our expected principal cash payments on borrowings are exclusive of discounts and premiums. As of January 31, 2025, the Company had outstanding debt for an aggregate principal amount of $24.8 billion, with $5.2 billion payable within 12 months. Included within the aggregate principal amount was $16.1 billion of corporate and other debt with varying maturities, with an immaterial amount payable within 12 months, and $8.7 billion of DFS debt, with $5.2 billion payable within 12 months.

[0001571996-25-000034:mdna:238]
As of January 31, 2025, future interest payments associated with outstanding debt were $7.4 billion, with $1.2 billion payable within 12 months. Included within total future interest payments is $6.9 billion of payments related to corporate and other debt, with $0.9 billion payable within 12 months, and $0.5 billion of payments related to DFS debt, with $0.3 billion payable within 12 months.

[0001571996-25-000034:mdna:239]
Purchase Obligations — Purchase obligations are defined as contractual obligations to purchase goods or services that are enforceable and legally binding on us. These obligations specify all significant terms, including fixed or minimum quantities to be purchased; fixed, minimum, or variable price provisions; and the approximate timing of the transaction. Purchase obligations do not include contracts that may be canceled without penalty.

[0001571996-25-000034:mdna:240]
We utilize several suppliers to manufacture sub-assemblies for our products. Our efficient supply chain management allows us to enter into flexible and mutually beneficial purchase arrangements with our suppliers in order to minimize inventory risk. Consistent with industry practice, we acquire raw materials or other goods and services, including product components, by issuing to suppliers authorizations to purchase based on our projected demand and manufacturing needs. Additionally, to meet the growing demand and increasing complexity of our AI-optimized offerings, we have increased our purchases of certain components with suppliers, which has resulted in increased purchase obligations. These purchase orders are typically fulfilled within 30 days and are entered into during the ordinary course of business in order to establish best pricing and continuity of supply for our production. Purchase orders are not included in purchase obligations, as they typically represent our authorization to purchase rather than binding purchase obligations.

[0001571996-25-000034:mdna:241]
As of January 31, 2025, the Company had purchase obligations of $6.5 billion, of which $5.0 billion was payable within 12 months.

[0001571996-25-000034:mdna:242]
Operating Leases — We lease property and equipment, manufacturing facilities, and office space under non-cancelable leases. Certain of these leases obligate us to pay taxes, maintenance, and repair costs. As of January 31, 2025, the Company had operating lease obligations of $0.8 billion, with $0.2 billion payable within 12 months. See Note 6 of the Notes to the Consolidated Financial Statements included in this report for additional information about our leasing transactions in which we are the lessee.

[0001571996-25-000034:mdna:243]
Tax Obligations — Tax obligations represent a one-time mandatory deemed repatriation tax on undistributed earnings of foreign subsidiaries. As of January 31, 2025, the balance of tax obligations was $60 million, with the full amount payable within 12 months. Excluded from the amounts above are $0.9 billion in additional liabilities associated with uncertain tax positions as of January 31, 2025. We are unable to reliably estimate the expected payment dates for any liabilities for uncertain tax positions. See Note 12 of the Notes to the Consolidated Financial Statements included in this report for more information regarding these tax matters.

[0001571996-25-000034:mdna:244]
Market Conditions

[0001571996-25-000034:mdna:245]
We regularly monitor economic conditions and associated impacts on the financial markets and our business. We consistently evaluate the financial health of our supplier base, carefully manage customer credit, diversify counterparty risk, and monitor the concentration risk of our cash and cash equivalents balances globally. We routinely monitor our financial exposure to borrowers and counterparties.

[0001571996-25-000034:mdna:246]
We monitor credit risk associated with our financial counterparties using various market credit risk indicators such as credit ratings issued by nationally recognized credit rating agencies and changes in market credit default swap levels. Our AI solutions to date have been purchased primarily by a small number of larger customers and cloud service providers. Such purchases generally involve larger amounts of credit, and could impact overall credit risk in trade and financing receivables. We perform periodic evaluations of our positions with counterparties and may limit exposure to any one counterparty in accordance with our policies. We monitor and manage our positions based on current and expected market developments.

[0001571996-25-000034:mdna:247]
We use derivative instruments to hedge certain foreign currency exposures. We use forward contracts and purchased options designated as cash flow hedges to protect against the foreign currency exchange rate risks inherent in our forecasted transactions denominated in currencies other than the U.S. dollar. In addition, we primarily use forward contracts and may use purchased options to hedge monetary assets and liabilities denominated in a foreign currency. See Note 8 of the Notes to the Consolidated Financial Statements included in this report for additional information about our use of derivative instruments.

[0001571996-25-000034:mdna:248]
We are exposed to interest rate risk related to our variable-rate debt portfolio. In the normal course of business we follow established policies and procedures to manage this risk, including monitoring of our asset and liability mix and the use of derivative instruments. As a result, we do not anticipate any material losses from interest rate risk.

[0001571996-25-000034:mdna:249]
Summarized Guarantor Financial Information

[0001571996-25-000034:mdna:250]
The Company’s outstanding senior notes (“Senior Notes”) are registered, unsecured, and issued by Dell International L.L.C. and EMC Corporation (the “Issuers”), both of which are wholly-owned subsidiaries of Dell Technologies Inc. The Senior Notes are guaranteed on a joint and several unsecured basis by Dell Technologies Inc. and its wholly-owned subsidiaries, Denali Intermediate, Inc. and Dell Inc. (collectively, the “Guarantors”).

[0001571996-25-000034:mdna:251]
Basis of Preparation of the Summarized Financial Information — The tables below are summarized financial information provided in conformity with Rule 13-01 of the SEC’s Regulation S-X. The summarized financial information of the Issuers and Guarantors (collectively, the “Obligor Group”) is presented on a combined basis, excluding intercompany balances and transactions between entities in the Obligor Group. The Obligor Group’s investment balances in Non-Obligor Subsidiaries have been excluded. The Obligor Group’s amounts due from, amounts due to, and transactions with Non-Obligor Subsidiaries have been presented separately.

[0001571996-25-000034:mdna:252]
The following table presents summarized results of operations information for the Obligor Group for the period indicated:

[0001571996-25-000034:mdna:253]
|  | Fiscal Year Ended |
|  | January 31, 2025 |
|  | (in millions) |
| Net revenue | $ | 8,507 |  |
| Gross margin | 4,328 |  |
| Operating income | 908 |  |
| Interest and other, net | (4,021) |  |
| Loss before income taxes | $ | (3,113) |  |
| Net loss attributable to Obligor Group (a) | $ | (2,167) |  |

[0001571996-25-000034:mdna:254]
____________________

[0001571996-25-000034:mdna:255]
(a)Includes net loss from intercompany transactions with Non-Obligor Subsidiaries of $4,268 million, which primarily consists of interest expense, shared services, and the resale of solutions.

[0001571996-25-000034:mdna:256]
The following table presents summarized balance sheet information for the Obligor Group as of the dates indicated:

[0001571996-25-000034:mdna:257]
|  | January 31, 2025 |  | February 2, 2024 |
|  | (in millions) |
| ASSETS |
| Current assets | $ | 3,132 |  |  | $ | 2,631 |  |
| Intercompany receivables | 175 |  |  | 281 |  |
| Short-term intercompany loan receivables | — |  |  | 92 |  |
| Total current assets | 3,307 |  |  | 3,004 |  |
| Goodwill and intangible assets | 14,073 |  |  | 14,447 |  |
| Other non-current assets | 3,412 |  |  | 3,437 |  |
| Total assets | $ | 20,792 |  |  | $ | 20,888 |  |
| LIABILITIES |
| Current liabilities | $ | 4,097 |  |  | $ | 5,255 |  |
| Long-term debt | 15,824 |  |  | 15,353 |  |
| Long-term intercompany loan payables | 44,516 |  |  | 41,617 |  |
| Other non-current liabilities | 3,339 |  |  | 3,473 |  |
| Total liabilities | $ | 67,776 |  |  | $ | 65,698 |  |

[0001571996-25-000034:mdna:258]
67

[0001571996-25-000034:mdna:259]
Critical Accounting Estimates

[0001571996-25-000034:mdna:260]
We prepare our financial statements in conformity with GAAP, which requires certain estimates, assumptions, and judgments to be made that may affect our Consolidated Statements of Financial Position and Consolidated Statements of Income. Accounting policies that have a significant impact on our Consolidated Financial Statements are described in Note 2 of the Notes to the Consolidated Financial Statements included in this report. The accounting estimates and assumptions discussed in this section are those that we consider to be the most critical. We consider an accounting policy to be critical if the nature of the estimate or assumption is subject to a material level of judgment and if changes in those estimates or assumptions are reasonably likely to materially impact our Consolidated Financial Statements. We have discussed the development, selection, and disclosure of our critical accounting policies with the Audit Committee of our Board of Directors.

[0001571996-25-000034:mdna:261]
Revenue Recognition — We sell a wide portfolio of products and services offerings to our customers. Our agreements have varying terms and conditions depending on the goods and services being sold, the rights and obligations conveyed, and the legal jurisdiction of the arrangement. While most of our agreements have standard terms and conditions, more complex agreements may contain nonstandard terms and conditions. There are significant judgments in interpreting agreements to determine the appropriate accounting for nonstandard terms and conditions.

[0001571996-25-000034:mdna:262]
Our contracts with customers often include multiple performance obligations for various distinct goods and services such as hardware, software licenses, support and maintenance agreements, and other service offerings and solutions. We use significant judgment to assess whether these promises are distinct performance obligations that should be accounted for separately. In certain hardware solutions, the hardware is highly interdependent on, and interrelated with, the embedded software. In these offerings, the hardware and software licenses are accounted for as a single performance obligation.

[0001571996-25-000034:mdna:263]
The transaction price reflects the amount of consideration to which we expect to be entitled in exchange for transferring goods or services to the customer. If the consideration promised in a contract includes a variable amount, we estimate the amount to which we expect to be entitled using either the expected value or most likely amount method. Estimates are updated each reporting period as the variability is resolved or if additional information becomes available. Generally, volume discounts, rebates, and sales returns reduce the transaction price. When we determine the transaction price, we only include amounts that are not subject to significant future reversal.

[0001571996-25-000034:mdna:264]
When a contract includes multiple performance obligations, the transaction price is allocated to each performance obligation in proportion to the standalone selling price (“SSP”) of each performance obligation.

[0001571996-25-000034:mdna:265]
Judgment is required when determining the SSP of our performance obligations. If the observable price is available, we utilize that price for the SSP. If the observable price is not available, the SSP must be estimated. We estimate SSP by considering multiple factors, including, but not limited to, pricing practices, internal costs, and profit objectives as well as overall market conditions, which include geographic or regional specific factors, competitive positioning, and competitor actions. Our SSP estimates rely, in part, on company pricing trends. Market conditions could impact the selling price in the current period which may not be reflective of trends, and could lead to revenue timing, classification, and segment differences when compared to similar contracts in other periods. SSP for our performance obligations is periodically reassessed.

[0001571996-25-000034:mdna:266]
For transactions that involve a third party, the Company evaluates whether it is acting as the principal or the agent in the transaction. This determination requires significant judgment and impacts the amount and timing of revenue recognized. If the Company determines that it controls a good or service before it is transferred to the customer, the Company is acting as the principal and recognizes revenue at the gross amount of consideration it is entitled to from the customer. Indicators that the Company controls a good or service before transferring to a customer include, but are not limited to, the Company being the primary obligor to the customer, establishing its own pricing, and having inventory and credit risks.

[0001571996-25-000034:mdna:267]
Goodwill and Indefinite-Lived Intangible Assets Impairment Assessments — Goodwill and indefinite-lived intangible assets are tested for impairment annually during the third fiscal quarter and whenever events or circumstances may indicate that an impairment has occurred.

[0001571996-25-000034:mdna:268]
To determine whether goodwill is impaired, we first assess certain qualitative factors. Qualitative factors that may be assessed include, but are not limited to, macroeconomic conditions, industry and market considerations, cost factors, overall financial performance, or other relevant company-specific events. Based on this assessment, if it is determined to be more likely than not that the fair value of a goodwill reporting unit is less than its carrying amount, we perform a quantitative analysis of the goodwill impairment test. Alternatively, we may bypass the qualitative assessment and perform a quantitative impairment test.

[0001571996-25-000034:mdna:269]
Significant judgment is exercised in the identification of goodwill reporting units, assignment of assets and liabilities to goodwill reporting units, assignment of goodwill to reporting units, and determination of the fair value of each goodwill reporting unit. The fair value of each of our goodwill reporting units is generally estimated using a combination of public company multiples and discounted cash flow methodologies, which is then compared to the carrying value of each goodwill reporting unit. The discounted cash flow and public company multiples methodologies require significant judgment, including estimation of future revenues, gross margins, and operating expenses, which are dependent on internal forecasts, current and anticipated economic conditions and trends, selection of market multiples through assessment of the reporting unit’s performance relative to peer competitors, the estimation of the long-term revenue growth rate and discount rate of our business, and the determination of our weighted average cost of capital. Changes in these estimates and assumptions could materially affect the fair value of the goodwill reporting unit, potentially resulting in a non-cash impairment charge.

[0001571996-25-000034:mdna:270]
The fair value of the indefinite-lived intangible assets is generally estimated using discounted cash flow methodologies. The discounted cash flow methodologies require significant judgment, including estimation of future revenue, the estimation of the long-term revenue growth rate of our business, and the determination of the weighted average cost of capital and royalty rates. Changes in these estimates and assumptions could materially affect the fair value of the indefinite-lived intangible assets, potentially resulting in a non-cash impairment charge.

[0001571996-25-000034:mdna:271]
For our annual impairment test during the third fiscal quarter of Fiscal 2025, during which the Company elected to quantitatively test the Infrastructure Solutions Group and Client Solutions Group reporting units, we determined that the fair value of each of these reporting units substantially exceeded its carrying amount. For more information about our goodwill and intangible assets, see Note 9 of the Notes to the Consolidated Financial Statements included in this report.

[0001571996-25-000034:mdna:272]
Income Taxes — We are subject to income tax in the United States and numerous foreign jurisdictions. Significant judgments are required in determining the consolidated provision for income taxes. We calculate a provision for income taxes using the asset and liability method, under which deferred tax assets and liabilities are recognized by identifying the temporary differences arising from the different treatment of items for tax and accounting purposes. We account for the tax impact of including Global Intangible Low-Taxed Income (GILTI) in U.S. taxable income as a period cost. We provide related valuation allowances for deferred tax assets, where appropriate. Significant judgment is required in determining any valuation allowance against deferred tax assets. In assessing the need for a valuation allowance, we consider all available evidence for each jurisdiction, including past operating results, estimates of future taxable income, and the feasibility of ongoing tax planning strategies. In the event we determine that all or part of the net deferred tax assets are not realizable in the future, we will make an adjustment to the valuation allowance that would be charged to earnings in the period such determination is made.

[0001571996-25-000034:mdna:273]
Significant judgment is also required in evaluating our uncertain tax positions. Although we believe our tax return positions are sustainable, we recognize tax benefits from uncertain tax positions in the financial statements only when it is more likely than not that the positions will be sustained upon examination, including resolution of any related appeals or litigation processes, based on the technical merits and a consideration of the relevant taxing authority’s administrative practices and precedents. To the extent that the final tax outcome of these matters is different from the amounts recorded, such differences will impact the provision for income taxes in the period in which such determination is made. The provision for income taxes includes the impact of reserve provisions and changes to reserves that are considered appropriate, as well as the related net interest and penalties. We believe we have provided adequate reserves for all uncertain tax positions.

[0001571996-25-000034:mdna:274]
Legal and Other Contingencies — The outcomes of legal proceedings and claims brought against us are subject to significant uncertainty. An estimated loss from a loss contingency such as a legal proceeding or claim is accrued by a charge to income if it is probable that an asset has been impaired or a liability has been incurred and the amount of the loss can be reasonably estimated. In determining whether a loss should be accrued, we evaluate, among other factors, the degree of probability of an unfavorable outcome and the ability to make a reasonable estimate of the amount of loss. Significant judgment is required in determining whether a loss should be accrued, and changes in these factors could materially impact our Consolidated Financial Statements.

[0001571996-25-000034:mdna:275]
Inventories — We state our inventory at the lower of cost or net realizable value. We record a write-down for inventories of components and products, including third-party products held for resale, which have become obsolete or are in excess of anticipated demand or net realizable value. We perform a detailed review of inventory each fiscal quarter that considers multiple factors, including demand forecasts, product life cycle status, product development plans, current sales levels, product pricing, and component cost trends. The industries in which we compete are subject to demand changes. If future demand or market conditions for our products are less favorable than forecasted, or if unforeseen technological changes negatively impact the utility of component inventory, we may be required to record additional write-downs, which would adversely affect our gross margin.

[0001571996-25-000034:mdna:276]
Recently Issued Accounting Pronouncements

[0001571996-25-000034:mdna:277]
See Note 2 of the Notes to the Consolidated Financial Statements included in this report for a summary of recently issued accounting pronouncements that are applicable to our Consolidated Financial Statements.

[0001571996-25-000034:mdna:278]
70
