# DELL 10-K controls and the auditor's report


## auditors_report

[0001571996-25-000034:auditors_report:1]
Report of Independent Registered Public Accounting Firm

[0001571996-25-000034:auditors_report:2]
To the Board of Directors and Stockholders of Dell Technologies Inc.

[0001571996-25-000034:auditors_report:3]
Opinions on the Financial Statements and Internal Control over Financial Reporting

[0001571996-25-000034:auditors_report:4]
We have audited the accompanying consolidated statements of financial position of Dell Technologies Inc. and its subsidiaries (the “Company”) as of January 31, 2025 and February 2, 2024, and the related consolidated statements of income, of comprehensive income, of stockholders’ equity (deficit) and of cash flows for each of the three years in the period ended January 31, 2025, including the related notes (collectively referred to as the “consolidated financial statements”). We also have audited the Company's internal control over financial reporting as of January 31, 2025, based on criteria established in Internal Control - Integrated Framework (2013) issued by the Committee of Sponsoring Organizations of the Treadway Commission (COSO).

[0001571996-25-000034:auditors_report:5]
In our opinion, the consolidated financial statements referred to above present fairly, in all material respects, the financial position of the Company as of January 31, 2025 and February 2, 2024, and the results of its operations and its cash flows for each of the three years in the period ended January 31, 2025 in conformity with accounting principles generally accepted in the United States of America. Also in our opinion, the Company did not maintain, in all material respects, effective internal control over financial reporting as of January 31, 2025, based on criteria established in Internal Control - Integrated Framework (2013) issued by the COSO because a material weakness in internal control over financial reporting existed as of that date as the Company did not design and maintain effective controls over non-recurring credits from certain suppliers that related to cost of net revenue.

[0001571996-25-000034:auditors_report:6]
A material weakness is a deficiency, or a combination of deficiencies, in internal control over financial reporting, such that there is a reasonable possibility that a material misstatement of the annual or interim financial statements will not be prevented or detected on a timely basis. The material weakness referred to above is described in Management’s Annual Report on Internal Control over Financial Reporting appearing under Item 9A. We considered this material weakness in determining the nature, timing, and extent of audit tests applied in our audit of the 2025 consolidated financial statements, and our opinion regarding the effectiveness of the Company’s internal control over financial reporting does not affect our opinion on those consolidated financial statements.

[0001571996-25-000034:auditors_report:7]
Basis for Opinions

[0001571996-25-000034:auditors_report:8]
The Company's management is responsible for these consolidated financial statements, for maintaining effective internal control over financial reporting, and for its assessment of the effectiveness of internal control over financial reporting, included in management’s report referred to above. Our responsibility is to express opinions on the Company’s consolidated financial statements and on the Company's internal control over financial reporting based on our audits. We are a public accounting firm registered with the Public Company Accounting Oversight Board (United States) (PCAOB) and are required to be independent with respect to the Company in accordance with the U.S. federal securities laws and the applicable rules and regulations of the Securities and Exchange Commission and the PCAOB.

[0001571996-25-000034:auditors_report:9]
We conducted our audits in accordance with the standards of the PCAOB. Those standards require that we plan and perform the audits to obtain reasonable assurance about whether the consolidated financial statements are free of material misstatement, whether due to error or fraud, and whether effective internal control over financial reporting was maintained in all material respects.

[0001571996-25-000034:auditors_report:10]
Our audits of the consolidated financial statements included performing procedures to assess the risks of material misstatement of the consolidated financial statements, whether due to error or fraud, and performing procedures that respond to those risks. Such procedures included examining, on a test basis, evidence regarding the amounts and disclosures in the consolidated financial statements. Our audits also included evaluating the accounting principles used and significant estimates made by management, as well as evaluating the overall presentation of the consolidated financial statements. Our audit of internal control over financial reporting included obtaining an understanding of internal control over financial reporting, assessing the risk that a material weakness exists, and testing and evaluating the design and operating effectiveness of internal control based on the assessed risk. Our audits also included performing such other procedures as we considered necessary in the circumstances. We believe that our audits provide a reasonable basis for our opinions.

[0001571996-25-000034:auditors_report:11]
74

[0001571996-25-000034:auditors_report:12]
Definition and Limitations of Internal Control over Financial Reporting

[0001571996-25-000034:auditors_report:13]
A company’s internal control over financial reporting is a process designed to provide reasonable assurance regarding the reliability of financial reporting and the preparation of financial statements for external purposes in accordance with generally accepted accounting principles. A company’s internal control over financial reporting includes those policies and procedures that (i) pertain to the maintenance of records that, in reasonable detail, accurately and fairly reflect the transactions and dispositions of the assets of the company; (ii) provide reasonable assurance that transactions are recorded as necessary to permit preparation of financial statements in accordance with generally accepted accounting principles, and that receipts and expenditures of the company are being made only in accordance with authorizations of management and directors of the company; and (iii) provide reasonable assurance regarding prevention or timely detection of unauthorized acquisition, use, or disposition of the company’s assets that could have a material effect on the financial statements.

[0001571996-25-000034:auditors_report:14]
Because of its inherent limitations, internal control over financial reporting may not prevent or detect misstatements. Also, projections of any evaluation of effectiveness to future periods are subject to the risk that controls may become inadequate because of changes in conditions, or that the degree of compliance with the policies or procedures may deteriorate.

[0001571996-25-000034:auditors_report:15]
Critical Audit Matters

[0001571996-25-000034:auditors_report:16]
The critical audit matter communicated below is a matter arising from the current period audit of the consolidated financial statements that was communicated or required to be communicated to the audit committee and that (i) relates to accounts or disclosures that are material to the consolidated financial statements and (ii) involved our especially challenging, subjective, or complex judgments. The communication of critical audit matters does not alter in any way our opinion on the consolidated financial statements, taken as a whole, and we are not, by communicating the critical audit matter below, providing a separate opinion on the critical audit matter or on the accounts or disclosures to which it relates.

[0001571996-25-000034:auditors_report:17]
Revenue Recognition — Identification of Performance Obligations in Revenue Contracts

[0001571996-25-000034:auditors_report:18]
As described in Notes 2 and 18 to the consolidated financial statements, the Company’s contracts with customers often include the promise to transfer multiple goods and services to a customer. Distinct promises within a contract are referred to as performance obligations and are accounted for as separate units of account. Management assesses whether each promised good or service is distinct for the purpose of identifying the performance obligations in the contract. This assessment involves subjective determinations and requires management to make judgments about the individual promised goods or services and whether such goods or services are separable from the other aspects of the contractual relationship. The Company’s performance obligations include various distinct goods and services such as hardware, software licenses, support and maintenance agreements, and other service offerings and solutions. For the year ended January 31, 2025, a significant portion of the $43.6 billion Infrastructure Solutions Group (“ISG”) reportable segment net revenues relate to contracts with multiple performance obligations.

[0001571996-25-000034:auditors_report:19]
The principal considerations for our determination that performing procedures relating to the identification of performance obligations in revenue contracts is a critical audit matter are (i) the significant judgment by management in identifying performance obligations in revenue contracts and (ii) a high degree of auditor judgment, subjectivity and effort in performing procedures and evaluating audit evidence related to whether performance obligations in revenue contracts were appropriately identified by management.

[0001571996-25-000034:auditors_report:20]
Addressing the matter involved performing procedures and evaluating audit evidence in connection with forming our overall opinion on the consolidated financial statements. These procedures included testing the effectiveness of controls relating to the revenue recognition process, including controls related to the proper identification of performance obligations in revenue contracts. These procedures also included, among others, testing the completeness and accuracy of management’s identification of performance obligations by examining revenue contracts on a test basis.

[0001571996-25-000034:auditors_report:21]
/s/ PricewaterhouseCoopers LLP

[0001571996-25-000034:auditors_report:22]
Austin, Texas

[0001571996-25-000034:auditors_report:23]
March 25, 2025

[0001571996-25-000034:auditors_report:24]
We have served as the Company’s auditor since 1986.

[0001571996-25-000034:auditors_report:25]
75

[0001571996-25-000034:auditors_report:26]
DELL TECHNOLOGIES INC.

[0001571996-25-000034:auditors_report:27]
CONSOLIDATED STATEMENTS OF FINANCIAL POSITION

[0001571996-25-000034:auditors_report:28]
(in millions)

[0001571996-25-000034:auditors_report:29]
|  | January 31, 2025 |  | February 2, 2024 |
| ASSETS |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 3,633 |  |  | $ | 7,366 |  |
| Accounts receivable, net of allowance of $63 and $71 | 10,298 |  |  | 9,343 |  |
| Short-term financing receivables, net of allowance of $78 and $79 (Note 5) | 5,304 |  |  | 4,643 |  |
| Inventories | 6,716 |  |  | 3,622 |  |
| Other current assets | 9,610 |  |  | 11,010 |  |
| Current assets held for sale | 668 |  |  | — |  |
| Total current assets | 36,229 |  |  | 35,984 |  |
| Property, plant, and equipment, net | 6,336 |  |  | 6,432 |  |
| Long-term investments | 1,496 |  |  | 1,316 |  |
| Long-term financing receivables, net of allowance of $75 and $91 (Note 5) | 5,927 |  |  | 5,877 |  |
| Goodwill | 19,120 |  |  | 19,700 |  |
| Intangible assets, net | 4,988 |  |  | 5,701 |  |
| Other non-current assets | 5,650 |  |  | 7,116 |  |
| Total assets | $ | 79,746 |  |  | $ | 82,126 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |
| Short-term debt | $ | 5,204 |  |  | $ | 6,982 |  |
| Accounts payable | 20,832 |  |  | 19,226 |  |
| Accrued and other | 6,597 |  |  | 6,828 |  |
| Short-term deferred revenue | 13,673 |  |  | 15,318 |  |
| Current liabilities held for sale | 221 |  |  | — |  |
| Total current liabilities | 46,527 |  |  | 48,354 |  |
| Long-term debt | 19,363 |  |  | 19,012 |  |
| Long-term deferred revenue | 12,292 |  |  | 13,827 |  |
| Other non-current liabilities | 2,951 |  |  | 3,065 |  |
| Total liabilities | $ | 81,133 |  |  | $ | 84,258 |  |
| Commitments and contingencies (Note 11) |  |  |  |
| Stockholders’ equity (deficit): |  |  |  |
| Common stock and capital in excess of $0.01 par value (Note 14) | $ | 9,119 |  |  | $ | 8,926 |  |
| Treasury stock at cost | (8,502) |  |  | (5,900) |  |
| Accumulated deficit | (1,160) |  |  | (4,453) |  |
| Accumulated other comprehensive loss | (939) |  |  | (800) |  |
| Total Dell Technologies Inc. stockholders’ equity (deficit) | (1,482) |  |  | (2,227) |  |
| Non-controlling interests | 95 |  |  | 95 |  |
| Total stockholders’ equity (deficit) | (1,387) |  |  | (2,132) |  |
| Total liabilities and stockholders’ equity | $ | 79,746 |  |  | $ | 82,126 |  |

[0001571996-25-000034:auditors_report:30]
The accompanying notes are an integral part of these Consolidated Financial Statements.

[0001571996-25-000034:auditors_report:31]
76

[0001571996-25-000034:auditors_report:32]
DELL TECHNOLOGIES INC.


## item_9a

[0001571996-25-000034:item_9a:1]
ITEM 9A — CONTROLS AND PROCEDURES

[0001571996-25-000034:item_9a:2]
This report includes the certifications of our Chief Executive Officer and Chief Financial Officer required by Rule 13a-14 under the Securities Exchange Act of 1934 (the “Exchange Act”). See Exhibits 31.1 and 31.2 filed with this report. This Item 9A includes information concerning the controls and control evaluations referred to in those certifications.

[0001571996-25-000034:item_9a:3]
Evaluation of Disclosure Controls and Procedures

[0001571996-25-000034:item_9a:4]
Disclosure controls and procedures (as defined in Rules 13a-15(e) and 15d-15(e) under the Exchange Act) are designed to provide reasonable assurance that information required to be disclosed in reports filed or submitted under the Exchange Act is recorded, processed, summarized, and reported within the time periods specified in SEC rules and forms and that such information is accumulated and communicated to management, including the Chief Executive Officer and the Chief Financial Officer, as appropriate to allow timely decisions regarding required disclosures.

[0001571996-25-000034:item_9a:5]
In connection with the preparation of this report, our management, under the supervision and with the participation of our Chief Executive Officer and Chief Financial Officer, conducted an evaluation of the effectiveness of the design and operation of our disclosure controls and procedures as of January 31, 2025. Based on that evaluation, our Chief Executive Officer and Chief Financial Officer have concluded that as of January 31, 2025, the Company’s disclosure controls and procedures were not effective to accomplish their objectives at the reasonable assurance level due to the material weakness in internal control over financial reporting as described below.

[0001571996-25-000034:item_9a:6]
Management’s Annual Report on Internal Control Over Financial Reporting

[0001571996-25-000034:item_9a:7]
Management, under the supervision of the Chief Executive Officer and the Chief Financial Officer, is responsible for establishing and maintaining adequate internal control over financial reporting. Internal control over financial reporting (as defined in Rules 13a-15(f) and 15d(f) under the Exchange Act) is a process designed to provide reasonable assurance regarding the reliability of financial reporting and the preparation of financial statements for external purposes in accordance with generally accepted accounting principles. Internal control over financial reporting includes those policies and procedures which (a) pertain to the maintenance of records that, in reasonable detail, accurately and fairly reflect the transactions and dispositions of assets, (b) provide reasonable assurance that transactions are recorded as necessary to permit preparation of financial statements in accordance with generally accepted accounting principles and that receipts and expenditures of the issuer are being made only in accordance with appropriate authorization of management and the directors of the issuer, and (c) provide reasonable assurance regarding prevention or timely detection of unauthorized acquisition, use, or disposition of assets that could have a material effect on the financial statements.

[0001571996-25-000034:item_9a:8]
A material weakness is a deficiency, or a combination of deficiencies, in internal control over financial reporting, such that there is a reasonable possibility that a material misstatement of our annual or interim financial statements will not be prevented or detected on a timely basis.

[0001571996-25-000034:item_9a:9]
During the preparation of the Company’s financial statements for the fiscal year ended January 31, 2025, management identified a material weakness in its internal control over financial reporting as the Company did not design and maintain effective controls over non-recurring credits from certain suppliers that related to cost of net revenue. This material weakness resulted in the revision of the Company’s annual Consolidated Financial Statements previously issued for the fiscal year ended February 2, 2024 and the unaudited interim Condensed Consolidated Financial Statements previously issued for Fiscal 2025 and Fiscal 2024 interim periods. While the impacts were not material, individually or in the aggregate, to the Company’s previously issued Consolidated Financial Statements, the material weakness related to non-recurring credits from certain suppliers could result in a material misstatement to the annual or interim Consolidated Financial Statements that would not be prevented or detected until such material weakness is remediated.

[0001571996-25-000034:item_9a:10]
151

[0001571996-25-000034:item_9a:11]
In connection with the preparation of this report, our management, under the supervision and with the participation of our Chief Executive Officer and Chief Financial Officer, conducted an evaluation of the effectiveness of our internal control over financial reporting as of January 31, 2025, based on the criteria established in Internal Control — Integrated Framework (2013) issued by the Committee of Sponsoring Organizations of the Treadway Commission (COSO). As a result of the material weakness described above, management has concluded that our internal control over financial reporting was not effective as of January 31, 2025.

[0001571996-25-000034:item_9a:12]
The effectiveness of our internal control over financial reporting as of January 31, 2025 has been audited by PricewaterhouseCoopers LLP, our independent registered public accounting firm, as stated in their report, which is included in “Item 8 — Financial Statements and Supplementary Data.”

[0001571996-25-000034:item_9a:13]
Remediation of Material Weakness

[0001571996-25-000034:item_9a:14]
The Company is committed to addressing the material weakness described above and has begun to implement changes in processes designed to improve its internal control over financial reporting. To remediate the material weakness, we are designing and implementing a new control over non-recurring credits from certain suppliers.

[0001571996-25-000034:item_9a:15]
As the Company evaluates and enhances its internal control over financial reporting, it may take additional measures to modify, or add to, the remediation measures described above. Remediation will not occur until the plans are implemented and there has been appropriate time to conclude through testing that the controls operate effectively.

[0001571996-25-000034:item_9a:16]
Changes in Internal Control Over Financial Reporting

[0001571996-25-000034:item_9a:17]
We are in the process of an ongoing business modernization initiative to advance our capabilities, leverage new technology, and optimize business processes to change the way we work and make decisions, improve business outcomes, and reduce costs. As part of this initiative, we are modernizing accounting and finance systems. We have modified and will continue to modify the design and implementation of certain internal control processes to accommodate changes to our business processes and finance procedures, as our business modernization initiative continues.

[0001571996-25-000034:item_9a:18]
There were no other changes in our internal control over financial reporting during the fiscal quarter ended January 31, 2025 that have materially affected, or are reasonably likely to materially affect, our internal control over financial reporting.

[0001571996-25-000034:item_9a:19]
Limitations on the Effectiveness of Controls

[0001571996-25-000034:item_9a:20]
Our system of controls is designed to provide reasonable, not absolute, assurance regarding the reliability and integrity of accounting and financial reporting. Management does not expect that our disclosure controls and procedures or our internal control over financial reporting will prevent or detect all errors and all fraud. A control system, no matter how well designed and operated, can provide only reasonable, not absolute, assurance that the objectives of the control system will be met. These inherent limitations include the following:

[0001571996-25-000034:item_9a:21]
•Judgments in decision-making can be faulty, and control and process breakdowns can occur because of simple errors or mistakes.

[0001571996-25-000034:item_9a:22]
•Controls can be circumvented by individuals, acting alone or in collusion with each other, or by management override.

[0001571996-25-000034:item_9a:23]
•The design of any system of controls is based in part on certain assumptions about the likelihood of future events, and there can be no assurance that any design will succeed in achieving its stated goals under all potential future conditions.

[0001571996-25-000034:item_9a:24]
•Over time, controls may become inadequate because of changes in conditions or deterioration in the degree of compliance with associated policies or procedures.

[0001571996-25-000034:item_9a:25]
•The design of a control system must reflect the fact that resources are constrained, and the benefits of controls must be considered relative to their costs.

[0001571996-25-000034:item_9a:26]
152
