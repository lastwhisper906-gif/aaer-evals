# DELL 10-Q controls and the auditor's report


## item_4_controls

[0001571996-20-000034:item_4_controls:1]
ITEM 4 — CONTROLS AND PROCEDURES

[0001571996-20-000034:item_4_controls:2]
This report includes the certifications of our Chief Executive Officer and Chief Financial Officer required by Rule 13a-14 under the Securities Exchange Act of 1934 (the “Exchange Act”).  See Exhibits 31.1 and 31.2 filed with this report.  This Item 4 includes information concerning the controls and control evaluations referred to in those certifications.

[0001571996-20-000034:item_4_controls:3]
Evaluation of Disclosure Controls and Procedures

[0001571996-20-000034:item_4_controls:4]
Disclosure controls and procedures (as defined in Rules 13a-15(e) and 15d-15(e) under the Exchange Act) are designed to provide reasonable assurance that information required to be disclosed in reports filed or submitted under the Exchange Act is recorded, processed, summarized, and reported within the time periods specified in SEC rules and forms and that such information is accumulated and communicated to management, including the Chief Executive Officer and the Chief Financial Officer, as appropriate to allow timely decisions regarding required disclosures.

[0001571996-20-000034:item_4_controls:5]
In connection with the preparation of this report, our management, under the supervision and with the participation of our Chief Executive Officer and Chief Financial Officer, conducted an evaluation of the effectiveness of the design and operation of our disclosure controls and procedures as of May 1, 2020.  Based on that evaluation, our Chief Executive Officer and Chief Financial Officer have concluded that our disclosure controls and procedures were effective at the reasonable assurance level as of May 1, 2020.

[0001571996-20-000034:item_4_controls:6]
Changes in Internal Control Over Financial Reporting

[0001571996-20-000034:item_4_controls:7]
There were no changes in our internal control over financial reporting during the fiscal quarter ended May 1, 2020 that have materially affected, or are reasonably likely to materially affect, our internal control over financial reporting.  We have not experienced any material impact to our internal controls over financial reporting despite the fact that most of our employees are working remotely for their health and safety during the COVID-19 pandemic.  We are continually monitoring and assessing the potential impact of COVID-19 on our internal controls to minimize the impact on their design and operating effectiveness.

[0001571996-20-000034:item_4_controls:8]
86
