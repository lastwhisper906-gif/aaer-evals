# DELL 8-K — 0001571996-20-000028 filed 2020-05-28

## item codes, every 8-K on or before 2020-06-08

- 2020-05-28 0001571996-20-000028 — 2.02, 9.01
- 2020-04-09 0001193125-20-102602 — 1.01, 2.03, 9.01
- 2020-04-08 0001571996-20-000021 — 5.02
- 2020-04-03 0001571996-20-000019 — 8.01, 9.01
- 2020-03-26 0001571996-20-000015 — 7.01
- 2020-02-27 0001571996-20-000009 — 2.02, 8.01, 9.01
- 2020-02-18 0001571996-20-000005 — 8.01, 9.01
- 2020-01-09 0001571996-20-000002 — 3.02
- 2020-01-06 0001193125-20-002200 — 3.02
- 2019-12-13 0001193125-19-313947 — 3.02
- 2019-12-10 0001571996-19-000052 — 5.02
- 2019-12-02 0001571996-19-000044 — 5.02, 7.01, 9.01
- 2019-11-26 0001571996-19-000042 — 2.02, 9.01
- 2019-09-23 0001193125-19-252192 — 1.01, 2.03, 9.01
- 2019-08-29 0001571996-19-000036 — 2.02, 9.01
- 2019-08-22 0001193125-19-226939 — 7.01, 8.01, 9.01
- 2019-07-11 0001571996-19-000032 — 5.02, 5.07, 9.01
- 2019-07-03 0001571996-19-000030 — 3.02
- 2019-06-27 0001571996-19-000028 — 3.02
- 2019-05-30 0001571996-19-000021 — 2.02, 9.01
- 2019-04-02 0001571996-19-000010 — 5.02
- 2019-03-21 0001193125-19-082281 — 1.01, 1.02, 2.03, 9.01
- 2019-03-19 0001571996-19-000005 — 5.02, 9.01
- 2019-03-14 0001193125-19-074935 — 1.01, 2.03, 9.01
- 2019-03-07 0001193125-19-066045 — 8.01, 9.01
- 2019-02-28 0001571996-19-000002 — 2.02, 9.01
- 2018-12-28 0001193125-18-360943 — 1.01, 1.02, 3.01, 3.03, 5.02, 5.03, 7.01, 8.01, 9.01
- 2018-12-21 0001193125-18-356324 — 1.01, 2.03, 9.01
- 2018-12-14 0001193125-18-349469 — 8.01
- 2018-12-11 0001193125-18-346958 — 5.07, 8.01, 9.01
- 2018-11-29 0001571996-18-000041 — 2.02, 9.01
- 2018-11-28 0001571996-18-000037 — 7.01, 8.01, 9.01
- 2018-11-26 0001193125-18-333967 — 8.01, 9.01
- 2018-11-15 0001193125-18-328110 — 1.01, 9.01 — amendment of 0001193125-18-327222
- 2018-11-15 0001193125-18-327222 — 1.01, 7.01, 9.01
- 2018-10-03 0001193125-18-291390 — 8.01
- 2018-09-06 0001571996-18-000029 — 2.02, 9.01
- 2018-08-06 0001571996-18-000027 — 8.01, 9.01
- 2018-07-02 0001193125-18-210339 — 1.01, 7.01, 9.01
- 2018-06-28 0001571996-18-000024 — 5.07
- 2018-06-04 0001571996-18-000019 — 2.02, 9.01
- 2018-05-17 0001571996-18-000016 — 7.01
- 2018-04-26 0001571996-18-000009 — 7.01, 9.01
- 2018-03-08 0001193125-18-074168 — 2.02, 9.01
- 2018-02-02 0001193125-18-029947 — 7.01, 9.01
- 2017-12-07 0001571996-17-000042 — 2.02, 9.01
- 2017-10-24 0001571996-17-000037 — 1.01, 2.03, 9.01
- 2017-09-15 0001571996-17-000027 — 5.02
- 2017-09-07 0001571996-17-000017 — 2.02, 9.01
- 2017-08-24 0001571996-17-000014 — 8.01
- 2017-06-29 0001571996-17-000011 — 3.03, 5.07, 8.01, 9.01
- 2017-06-08 0001193125-17-197638 — 2.02, 9.01
- 2017-03-30 0001193125-17-102794 — 8.01
- 2017-03-30 0001193125-17-102777 — 2.02, 9.01
- 2017-03-09 0001193125-17-076981 — 1.01, 2.03, 9.01
- 2017-01-17 0001193125-17-011125 — 8.01
- 2016-12-15 0001193125-16-793722 — 8.01
- 2016-12-08 0001193125-16-787976 — 2.02, 9.01
- 2016-11-10 0001193125-16-765964 — 1.02, 8.01
- 2016-11-04 0001193125-16-760249 — 8.01
- 2016-09-13 0001193125-16-708600 — 3.02
- 2016-09-09 0001193125-16-706567 — 1.01, 1.02, 2.01, 2.03, 3.02, 3.03, 5.02, 9.01
- 2016-09-07 0001193125-16-703370 — 3.03, 5.07, 7.01, 8.01, 9.01
- 2016-09-06 0001193125-16-702057 — 2.02, 9.01
- 2016-08-31 0001193125-16-697268 — 8.01, 9.01
- 2016-08-26 0001193125-16-692921 — 8.01, 9.01
- 2016-07-11 0001193125-16-645610 — 8.01
- 2016-07-05 0001193125-16-641679 — 8.01
- 2016-06-22 0001193125-16-629055 — 1.01, 2.03, 8.01, 9.01
- 2016-06-21 0001193125-16-627071 — 8.01, 9.01
- 2016-06-10 0001193125-16-618483 — 2.02, 9.01
- 2016-06-09 0001193125-16-617893 — 8.01, 9.01

## late-filing notifications on or before 2020-06-08

- none on or before 2020-06-08

## item 2.02 — earnings release, exhibit 99.1

[0001571996-20-000028:8k_2_02:1]
EX-99.1
2
exhibit991earnings8kq1.htm
EXHIBIT 99.1

[0001571996-20-000028:8k_2_02:2]
Exhibit

[0001571996-20-000028:8k_2_02:3]
Exhibit 99.1

[0001571996-20-000028:8k_2_02:4]
News Release

[0001571996-20-000028:8k_2_02:5]
Innovation and Resiliency Drive Dell Technologies’ First Quarter

[0001571996-20-000028:8k_2_02:6]
Fiscal 2021 Financial Results

[0001571996-20-000028:8k_2_02:7]
ROUND ROCK, Texas — May 28, 2020

[0001571996-20-000028:8k_2_02:8]
News summary

[0001571996-20-000028:8k_2_02:9]
| • | Dell Technologies effectively navigates COVID-19 environment with innovative products, broad capabilities, flexible supply chain and resilient global workforce |

[0001571996-20-000028:8k_2_02:10]
| • | First quarter revenue of $21.9 billion |

[0001571996-20-000028:8k_2_02:11]
| • | Operating income up 28% to $702 million, non-GAAP operating income of $2.2 billion |

[0001571996-20-000028:8k_2_02:12]
| • | Client Solutions Group revenue up 2% to $11.1 billion; VMware revenue up 12% |

[0001571996-20-000028:8k_2_02:13]
Full story

[0001571996-20-000028:8k_2_02:14]
Dell Technologies (NYSE: DELL) announces financial results for its fiscal 2021 first quarter. First quarter revenue was $21.9 billion. During the quarter, the company generated operating income of $702 million, a 28 percent increase over the same period in the prior year, and non-GAAP operating income of $2.2 billion. Net income was $182 million, non-GAAP net income was $1.1 billion and adjusted EBITDA was $2.6 billion. Net cash used in operating activities was $0.8 billion. Diluted earnings per share was $0.19 and non-GAAP diluted earnings per share was $1.34.

[0001571996-20-000028:8k_2_02:15]
“Customers need essential technology now more than ever to put business continuity, remote working and learning plans into practice,” said Jeff Clarke, vice chairman and chief operating officer, Dell Technologies. “In Q1, we saw orders with banking and financial services, government, healthcare and life sciences customers up 15 to 20 percent — all to meet immediate needs of their customers, communities and patients. As the world pivots from response to recovery, we’ll continue to put our broad capabilities to work to deliver differentiated results for our customers and our company.”

[0001571996-20-000028:8k_2_02:16]
1

[0001571996-20-000028:8k_2_02:17]
First Quarter Fiscal 2021 Financial Results

[0001571996-20-000028:8k_2_02:18]
|  | Three Months Ended |  |  |
|  | May 1, 2020 |  | May 3, 2019 |  | Change |
|  | (in millions, except percentages; unaudited) |
| Total net revenue | $ | 21,897 |  |  | $ | 21,908 |  |  | — | % |
| Operating income | $ | 702 |  |  | $ | 550 |  |  | 28 | % |
| Net income | $ | 182 |  |  | $ | 329 |  |  | (45 | )% |
| Non-GAAP net revenue | $ | 21,945 |  |  | $ | 21,990 |  |  | — | % |
| Non-GAAP operating income | $ | 2,161 |  |  | $ | 2,196 |  |  | (2 | )% |
| Non-GAAP net income | $ | 1,143 |  |  | $ | 1,209 |  |  | (5 | )% |
| Adjusted EBITDA | $ | 2,607 |  |  | $ | 2,573 |  |  | 1 | % |

[0001571996-20-000028:8k_2_02:19]
Information about Dell Technologies’ use of non-GAAP financial information is provided under “Non-GAAP Financial Measures” below.  All comparisons in this press release are year-over-year unless otherwise noted.

[0001571996-20-000028:8k_2_02:20]
Dell Technologies ended the quarter with cash and investments of $13.2 billion, and total deferred revenue of $27.6 billion, up 14 percent year-over-year. Recurring revenue, which includes deferred revenue amortization, utility, and as-a-Service delivered as part of Dell Technologies on Demand, is now approximately $6 billion a quarter, up 16 percent year-over-year.

[0001571996-20-000028:8k_2_02:21]
“Since February, almost everything in the world has changed. What remains unchanged is our ability to deliver for customers and run the business in a disciplined way for the long-term — with an emphasis on growth, share gain, and a strong capital structure,” said Tom Sweet, chief financial officer, Dell Technologies.

[0001571996-20-000028:8k_2_02:22]
Operating segments summary

[0001571996-20-000028:8k_2_02:23]
Client Solutions Group revenue for the first quarter was $11.1 billion, up 2 percent versus the first quarter of last year. Operating income was $592 million or more than 5 percent of Client Solutions Group revenue.

[0001571996-20-000028:8k_2_02:24]
Key highlights:

[0001571996-20-000028:8k_2_02:25]
| • | Double-digit unit and revenue growth in commercial notebooks and high-single-digit revenue growth in mobile workstations |

[0001571996-20-000028:8k_2_02:26]
| • | Powered by a resilient supply chain, outperformed the PC industry, as the only top 5 vendor gaining year-over-year worldwide share in total and commercial client units1 |

[0001571996-20-000028:8k_2_02:27]
| • | Moved up to #2 worldwide in commercial PC sales with a 26.2 percent-unit share.1 |

[0001571996-20-000028:8k_2_02:28]
2

[0001571996-20-000028:8k_2_02:29]
Infrastructure Solutions Group revenue for the first quarter was $7.6 billion, an 8 percent decrease year-over-year, with customers directing more spend towards remote work and business continuity solutions. Storage revenue was $3.8 billion, down 5 percent year-over-year, while servers and networking revenue was $3.8 billion, down 10 percent. Operating income was $732 million for the first quarter, or approximately 10 percent of Infrastructure Solutions Group revenue.

[0001571996-20-000028:8k_2_02:30]
Key highlights:

[0001571996-20-000028:8k_2_02:31]
| • | Began shipping PowerStore — an innovative autonomous storage platform built from the ground up to support multiple workloads for the midrange segment, the biggest part of the external storage market. PowerStore includes CloudIQ storage monitoring and analytics software that combines machine learning and human intelligence. Dell Technologies will integrate CloudIQ across the full Dell Technologies infrastructure portfolio for greater insights. Dell EMC Cloud Storage Services can connect PowerStore to all of the big three public clouds as a managed service. |

[0001571996-20-000028:8k_2_02:32]
| • | Earlier this month, announced Dell Technologies Cloud OneFS for Google Cloud to help organizations control exponential data and application growth and ease the flow of files across their private clouds and Google Cloud |

[0001571996-20-000028:8k_2_02:33]
| • | Added a one-year term to Dell Technologies On Demand flexible consumption offerings, which can also be used with the Dell Technologies Cloud Platform to consume cloud infrastructure and rapidly get a hybrid cloud up and running. |

[0001571996-20-000028:8k_2_02:34]
VMware revenue was $2.8 billion for the first quarter, up 12 percent driven by broad-based strength across a diverse product portfolio. Operating income for the quarter was $773 million, or approximately 28 percent of VMware revenue.

[0001571996-20-000028:8k_2_02:35]
Key highlights:

[0001571996-20-000028:8k_2_02:36]
| • | Announced the new VMware Tanzu Portfolio and its suite of tools for deploying and managing Kubernetes and the new VMware vSphere 7. |

[0001571996-20-000028:8k_2_02:37]
| • | Released VMware Cloud Foundation 4, which delivers intrinsic security and lifecycle management across software-defined compute, storage and networking, and hybrid cloud environments. |

[0001571996-20-000028:8k_2_02:38]
Conference call information

[0001571996-20-000028:8k_2_02:39]
As previously announced, the Company will hold a conference call to discuss its first quarter performance today, May 28, 2020 at 4:30 p.m. CDT. The conference call will be broadcast live over the internet and can be accessed at https://investors.delltechnologies.com/events-and-presentations/upcoming-events

[0001571996-20-000028:8k_2_02:40]
For those unable to listen to the live broadcast, an archived version will be available at the same location for one year.

[0001571996-20-000028:8k_2_02:41]
Additional financial and operating information may be downloaded from

[0001571996-20-000028:8k_2_02:42]
https://investors.delltechnologies.com/financial-information/quarterly-results

[0001571996-20-000028:8k_2_02:43]
About Dell Technologies

[0001571996-20-000028:8k_2_02:44]
Dell Technologies (NYSE:DELL) helps organizations and individuals build their digital future and transform how they work, live and play.  The company provides customers with the industry’s broadest and most innovative technology and services portfolio for the data era.

[0001571996-20-000028:8k_2_02:45]
3

[0001571996-20-000028:8k_2_02:46]
Contacts

[0001571996-20-000028:8k_2_02:47]
Investors: Investor_Relations@Dell.com

[0001571996-20-000028:8k_2_02:48]
Media: Media.Relations@Dell.com

[0001571996-20-000028:8k_2_02:49]
# # #

[0001571996-20-000028:8k_2_02:50]
Copyright © 2020 Dell Inc. or its subsidiaries. All Rights Reserved. Dell Technologies, Dell, EMC and Dell EMC are trademarks of Dell Inc. or its subsidiaries. Other trademarks may be trademarks of their respective owners.

[0001571996-20-000028:8k_2_02:51]
1.    IDC WW Quarterly Personal Computing Device (PDC) Tracker CY20Q1.

[0001571996-20-000028:8k_2_02:52]
Non-GAAP Financial Measures:

[0001571996-20-000028:8k_2_02:53]
This press release presents information about Dell Technologies’ non-GAAP net revenue, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP operating income, non-GAAP net income, non-GAAP net income attributable to non-controlling interests, non-GAAP net income attributable to Dell Technologies Inc. - basic, non-GAAP net income attributable to Dell Technologies Inc. - diluted, non-GAAP earnings per share attributable to Dell Technologies Inc. - basic, non-GAAP earnings per share attributable to Dell Technologies Inc. - diluted, EBITDA, and adjusted EBITDA, which are non-GAAP financial measures provided as a supplement to the results provided in accordance with generally accepted accounting principles in the United States of America (“GAAP”). A reconciliation of each non-GAAP financial measure to the most directly comparable GAAP financial measure is provided in the attached tables for each of the fiscal periods indicated.

[0001571996-20-000028:8k_2_02:54]
Special Note on Forward-Looking Statements:

[0001571996-20-000028:8k_2_02:55]
Dell Technologies’ results or events in future periods could differ materially from those expressed or implied by these forward-looking statements because of risks, uncertainties, and other factors that include, but are not limited to, the following: competitive pressures; Dell Technologies’ reliance on third-party suppliers for products and components, including reliance on single-source or limited-source suppliers; Dell Technologies’ ability to achieve favorable pricing from its vendors; adverse global economic conditions and instability in financial markets, including as a result of the COVID-19 pandemic; Dell Technologies’ execution of its growth, business and acquisition strategies; the success of Dell Technologies’ cost efficiency measures; Dell Technologies’ ability to manage solutions and products and services transitions in an effective manner; Dell Technologies’ ability to deliver high-quality products and services; Dell Technologies’ foreign operations and ability to generate substantial non-U.S. net revenue; Dell Technologies’ product, customer, and geographic sales mix, and seasonal sales trends; the performance of Dell Technologies’ sales channel partners; access to the capital markets by Dell Technologies or its customers; weak economic conditions and additional regulation including tariffs and other effects of trade regulation; counterparty default risks; effects of customer defaults or the exercise of customer rights on the ability of Dell Technologies to produce revenue under its contracts for services and solutions at expected levels and to perform such contracts at estimated costs; the loss by Dell Technologies of government contracts; Dell Technologies’ ability to develop and protect its proprietary intellectual property or obtain licenses to intellectual property developed by others on commercially reasonable and competitive terms; infrastructure disruptions, cyberattacks, or other data security breaches; Dell Technologies’ ability to hedge effectively its exposure to fluctuations in foreign currency exchange rates and interest rates; expiration of tax holidays or favorable tax rate structures, or unfavorable outcomes in tax audits and other tax compliance matters; impairment of portfolio investments; unfavorable results of legal proceedings; Dell Technologies’ ability to develop and maintain effective internal control over financial reporting; compliance requirements of changing environmental and safety laws; the effect of armed hostilities, terrorism, natural disasters, climate change, and public health issues, including those relating to the COVID-19 pandemic; Dell Technologies’ substantial level of indebtedness; the impact of the financial performance of VMware Inc.; and the market volatility of Dell Technologies’ pension plan assets.

[0001571996-20-000028:8k_2_02:56]
This list of risks, uncertainties, and other factors is not complete. Dell Technologies discusses some of these matters more fully, as well as certain risk factors that could affect Dell Technologies’ business, financial condition, results of operations, and prospects, in its reports filed with the SEC, including Dell Technologies’ annual report on Form 10-K for the fiscal year ended January 31, 2020, quarterly reports on Form 10-Q, and current reports on Form 8-K. These filings are available for review through the SEC’s website at www.sec.gov. Any or all forward-looking statements Dell Technologies makes may turn out to be wrong and can be affected by inaccurate assumptions Dell Technologies might make or by known or unknown risks, uncertainties and other factors, including those identified in this press release. Accordingly, you should not place undue reliance on the forward-looking statements made in this press release, which speak only as of the date such statements are made. Dell Technologies does not undertake to update any forward-looking statement after the date as of which such statement was made, whether to reflect changes in circumstances or Dell Technologies’ expectations, the occurrence of unanticipated events, or otherwise.

[0001571996-20-000028:8k_2_02:57]
4

[0001571996-20-000028:8k_2_02:58]
DELL TECHNOLOGIES INC.

[0001571996-20-000028:8k_2_02:59]
Condensed Consolidated Statements of Income (Loss) and Related Financial Highlights

[0001571996-20-000028:8k_2_02:60]
(in millions, except percentages; unaudited)

[0001571996-20-000028:8k_2_02:61]
|  | Three Months Ended |  |  |
|  | May 1, 2020 |  | May 3, 2019 |  | Change |
| Net revenue (a): |  |  |  |  |  |
| Products | $ | 16,038 |  |  | $ | 16,575 |  |  | (3 | )% |
| Services | 5,859 |  |  | 5,333 |  |  | 10 | % |
| Total net revenue | 21,897 |  |  | 21,908 |  |  | — | % |
| Cost of net revenue: |  |  |  |  |  |
| Products | 12,804 |  |  | 13,079 |  |  | (2 | )% |
| Services | 2,240 |  |  | 2,032 |  |  | 10 | % |
| Total cost of net revenue | 15,044 |  |  | 15,111 |  |  | — | % |
| Gross margin | 6,853 |  |  | 6,797 |  |  | 1 | % |
| Operating expenses: |  |  |  |  |  |
| Selling, general, and administrative | 4,886 |  |  | 5,071 |  |  | (4 | )% |
| Research and development | 1,265 |  |  | 1,176 |  |  | 8 | % |
| Total operating expenses | 6,151 |  |  | 6,247 |  |  | (2 | )% |
| Operating income | 702 |  |  | 550 |  |  | 28 | % |
| Interest and other, net | (566 | ) |  | (693 | ) |  | 18 | % |
| Income (loss) before income taxes | 136 |  |  | (143 | ) |  | 195 | % |
| Income tax benefit | (46 | ) |  | (472 | ) |  | 90 | % |
| Net income | 182 |  |  | 329 |  |  | (45 | )% |
| Less: Net income attributable to non-controlling interests | 39 |  |  | 36 |  |  | 8 | % |
| Net income attributable to Dell Technologies Inc. | $ | 143 |  |  | $ | 293 |  |  | (51 | )% |
| Percentage of Total Net Revenue: |  |  |  |  |
| Gross margin | 31 | % |  | 31 | % |  |  |
| Selling, general, and administrative | 22 | % |  | 23 | % |  |  |
| Research and development | 6 | % |  | 5 | % |  |  |
| Operating expenses | 28 | % |  | 29 | % |  |  |
| Operating income | 3 | % |  | 3 | % |  |  |
| Income (loss) before income taxes | 1 | % |  | (1 | )% |  |  |
| Net income | 1 | % |  | 2 | % |  |  |
| Income tax rate | (33.8 | )% |  | 330.1 | % |  |  |

[0001571996-20-000028:8k_2_02:62]
____________________

[0001571996-20-000028:8k_2_02:63]
| (a) | During the fourth quarter of Fiscal 2020, the Company reclassified revenue associated with certain service and software-as-a-service offerings from product revenue to services revenue. There was no change to total revenue as a result of the reclassifications. Prior period results have been recast to conform with current period presentation. |

[0001571996-20-000028:8k_2_02:64]
5

[0001571996-20-000028:8k_2_02:65]
DELL TECHNOLOGIES INC.

[0001571996-20-000028:8k_2_02:66]
Consolidated Statements of Financial Position

[0001571996-20-000028:8k_2_02:67]
(in millions; unaudited)

[0001571996-20-000028:8k_2_02:68]
|  | May 1, 2020 |  | January 31, 2020 |
| ASSETS |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 12,229 |  |  | $ | 9,302 |  |
| Accounts receivable, net | 10,797 |  |  | 12,484 |  |
| Short-term financing receivables, net | 4,752 |  |  | 4,895 |  |
| Inventories, net | 3,616 |  |  | 3,281 |  |
| Other current assets | 7,437 |  |  | 6,906 |  |
| Current assets held for sale | 2,100 |  |  | — |  |
| Total current assets | 40,931 |  |  | 36,868 |  |
| Property, plant, and equipment, net | 6,100 |  |  | 6,055 |  |
| Long-term investments | 974 |  |  | 864 |  |
| Long-term financing receivables, net | 4,710 |  |  | 4,848 |  |
| Goodwill | 40,248 |  |  | 41,691 |  |
| Intangible assets, net | 16,827 |  |  | 18,107 |  |
| Other non-current assets | 10,446 |  |  | 10,428 |  |
| Total assets | $ | 120,236 |  |  | $ | 118,861 |  |
| LIABILITIES, REDEEMABLE SHARES, AND STOCKHOLDERS’ EQUITY (DEFICIT) |
| Current liabilities: |  |  |  |
| Short-term debt | $ | 8,375 |  |  | $ | 7,737 |  |
| Accounts payable | 18,432 |  |  | 20,065 |  |
| Accrued and other | 8,073 |  |  | 9,773 |  |
| Short-term deferred revenue | 14,766 |  |  | 14,881 |  |
| Current liabilities held for sale | 365 |  |  | — |  |
| Total current liabilities | 50,011 |  |  | 52,456 |  |
| Long-term debt | 48,353 |  |  | 44,319 |  |
| Long-term deferred revenue | 12,851 |  |  | 12,919 |  |
| Other non-current liabilities | 5,340 |  |  | 5,383 |  |
| Total liabilities | 116,555 |  |  | 115,077 |  |
| Redeemable shares | 441 |  |  | 629 |  |
| Stockholders’ equity (deficit): |  |  |  |
| Total Dell Technologies Inc. stockholders’ deficit | (1,614 | ) |  | (1,574 | ) |
| Non-controlling interests | 4,854 |  |  | 4,729 |  |
| Total stockholders’ equity (deficit) | 3,240 |  |  | 3,155 |  |
| Total liabilities, redeemable shares, and stockholders’ equity (deficit) | $ | 120,236 |  |  | $ | 118,861 |  |

[0001571996-20-000028:8k_2_02:69]
6

[0001571996-20-000028:8k_2_02:70]
DELL TECHNOLOGIES INC.

[0001571996-20-000028:8k_2_02:71]
Condensed Consolidated Statements of Cash Flows

[0001571996-20-000028:8k_2_02:72]
(in millions; unaudited)

[0001571996-20-000028:8k_2_02:73]
|  | Three Months Ended |
|  | May 1, 2020 |  | May 3, 2019 |
| Cash flows from operating activities: |  |  |  |
| Net income | $ | 182 |  |  | $ | 329 |  |
| Adjustments to reconcile net income to net cash provided by (used in) operating activities: | (978 | ) |  | 353 |  |
| Change in cash from operating activities | (796 | ) |  | 682 |  |
| Cash flows from investing activities: |  |  |  |
| Purchases of investments | (56 | ) |  | (38 | ) |
| Maturities and sales of investments | 39 |  |  | 337 |  |
| Capital expenditures and capitalized software development costs | (559 | ) |  | (716 | ) |
| Acquisition of businesses and assets, net | (38 | ) |  | (45 | ) |
| Divestitures of businesses and assets, net | 120 |  |  | (3 | ) |
| Other | 9 |  |  | 7 |  |
| Change in cash from investing activities | (485 | ) |  | (458 | ) |
| Cash flows from financing activities: |  |  |  |
| Proceeds from the issuance of common stock | 116 |  |  | 134 |  |
| Repurchases of parent common stock inclusive of tax withholdings | (240 | ) |  | (6 | ) |
| Repurchases of subsidiary common stock inclusive of tax withholdings | (300 | ) |  | (803 | ) |
| Proceeds from debt | 10,135 |  |  | 9,563 |  |
| Repayments of debt | (5,405 | ) |  | (9,569 | ) |
| Other | (42 | ) |  | (38 | ) |
| Change in cash from financing activities | 4,264 |  |  | (719 | ) |
| Effect of exchange rate changes on cash, cash equivalents, and restricted cash | (136 | ) |  | (36 | ) |
| Change in cash, cash equivalents, and restricted cash | 2,847 |  |  | (531 | ) |
| Cash, cash equivalents, and restricted cash at beginning of the period | 10,151 |  |  | 10,240 |  |
| Cash, cash equivalents, and restricted cash at end of the period | $ | 12,998 |  |  | $ | 9,709 |  |

[0001571996-20-000028:8k_2_02:74]
7

[0001571996-20-000028:8k_2_02:75]
DELL TECHNOLOGIES INC.

[0001571996-20-000028:8k_2_02:76]
Segment Information

[0001571996-20-000028:8k_2_02:77]
(in millions, except percentages; unaudited; continued on next page)

[0001571996-20-000028:8k_2_02:78]
|  | Three Months Ended |  |  |
|  | May 1, 2020 |  | May 3, 2019 |  | Change |
| Infrastructure Solutions Group (ISG): |
| Net Revenue: |  |  |  |  |  |
| Servers and networking | $ | 3,758 |  |  | $ | 4,180 |  |  | (10 | )% |
| Storage | 3,811 |  |  | 4,022 |  |  | (5 | )% |
| Total ISG net revenue | $ | 7,569 |  |  | $ | 8,202 |  |  | (8 | )% |
| Operating Income: |  |  |  |  |  |
| ISG operating income | $ | 732 |  |  | $ | 843 |  |  | (13 | )% |
| % of ISG net revenue | 10 | % |  | 10 | % |  |  |
| % of total reportable segment operating income | 35 | % |  | 38 | % |  |  |
| Client Solutions Group (CSG): |
| Net Revenue: |  |  |  |  |  |
| Commercial | $ | 8,634 |  |  | $ | 8,307 |  |  | 4 | % |
| Consumer | 2,470 |  |  | 2,603 |  |  | (5 | )% |
| Total CSG net revenue | $ | 11,104 |  |  | $ | 10,910 |  |  | 2 | % |
| Operating Income: |  |  |  |  |  |
| CSG operating income | $ | 592 |  |  | $ | 793 |  |  | (25 | )% |
| % of CSG net revenue | 5 | % |  | 7 | % |  |  |
| % of total reportable segment operating income | 28 | % |  | 36 | % |  |  |
| VMware (a): |
| Net Revenue: |  |  |  |  |  |
| Total VMware net revenue | $ | 2,755 |  |  | $ | 2,457 |  |  | 12 | % |
| Operating Income: |  |  |  |  |  |
| VMware operating income | $ | 773 |  |  | $ | 595 |  |  | 30 | % |
| % of VMware net revenue | 28 | % |  | 24 | % |  |  |
| % of total reportable segment operating income | 37 | % |  | 27 | % |  |  |

[0001571996-20-000028:8k_2_02:79]
____________________

[0001571996-20-000028:8k_2_02:80]
| (a) | During the fourth quarter of Fiscal 2020, the Company reclassified Pivotal operating results from Other businesses to the VMware reportable segment. There was no change to consolidated results as a result of the reclassification. Prior period results have been recast to conform with current period presentation. |

[0001571996-20-000028:8k_2_02:81]
8

[0001571996-20-000028:8k_2_02:82]
DELL TECHNOLOGIES INC.

[0001571996-20-000028:8k_2_02:83]
Segment Information

[0001571996-20-000028:8k_2_02:84]
(in millions, except percentages; unaudited; continued)

[0001571996-20-000028:8k_2_02:85]
|  | Three Months Ended |
|  | May 1, 2020 |  | May 3, 2019 |
| Reconciliation to consolidated net revenue: |  |  |
| Reportable segment net revenue (a) | $ | 21,428 |  |  | $ | 21,569 |  |
| Other businesses (a) (b) | 517 |  |  | 421 |  |
| Unallocated transactions (c) | — |  |  | — |  |
| Impact of purchase accounting (d) | (48 | ) |  | (82 | ) |
| Total consolidated net revenue | $ | 21,897 |  |  | $ | 21,908 |  |
| Reconciliation to consolidated operating income: |
| Reportable segment operating income (a) | $ | 2,097 |  |  | $ | 2,231 |  |
| Other businesses (a) (b) | 65 |  |  | (34 | ) |
| Unallocated transactions (c) | (1 | ) |  | (1 | ) |
| Impact of purchase accounting (d) | (63 | ) |  | (101 | ) |
| Amortization of intangibles | (855 | ) |  | (1,217 | ) |
| Transaction-related expenses (e) | (76 | ) |  | (42 | ) |
| Stock-based compensation expense (f) | (370 | ) |  | (263 | ) |
| Other corporate expenses (g) | (95 | ) |  | (23 | ) |
| Total consolidated operating income | $ | 702 |  |  | $ | 550 |  |

[0001571996-20-000028:8k_2_02:86]
_________________

[0001571996-20-000028:8k_2_02:87]
| (a) | During Fiscal 2020, the Company reclassified Pivotal operating results from Other businesses to the VMware reportable segment. Prior period results have been recast to conform with current period presentation. |

[0001571996-20-000028:8k_2_02:88]
| (b) | Secureworks, RSA Security, Virtustream, and Boomi constitute “Other businesses” and do not meet the requirements for a reportable segment, either individually or collectively. The results of Other businesses are not material to the Company’s overall results. |

[0001571996-20-000028:8k_2_02:89]
| (c) | Unallocated transactions includes other corporate items that are not allocated to Dell Technologies’ reportable segments. |

[0001571996-20-000028:8k_2_02:90]
| (d) | Impact of purchase accounting includes non-cash purchase accounting adjustments that are primarily related to the EMC merger transaction. |

[0001571996-20-000028:8k_2_02:91]
| (e) | Transaction-related expenses includes acquisition, integration, and divestiture related costs. |

[0001571996-20-000028:8k_2_02:92]
| (f) | Stock-based compensation expense consists of equity awards granted based on the estimated fair value of those awards at grant date. |

[0001571996-20-000028:8k_2_02:93]
| (g) | Other corporate expenses includes severance, facility action, and other costs. |

[0001571996-20-000028:8k_2_02:94]
9

[0001571996-20-000028:8k_2_02:95]
SUPPLEMENTAL SELECTED NON-GAAP FINANCIAL MEASURES

[0001571996-20-000028:8k_2_02:96]
These tables present information about the Company’s non-GAAP net revenue, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP operating income, non-GAAP net income, non-GAAP net income attributable to non-controlling interests, non-GAAP net income attributable to Dell Technologies Inc. - basic, non-GAAP net income attributable to Dell Technologies Inc. - diluted, non-GAAP earnings per share attributable to Dell Technologies Inc. - basic, non-GAAP earnings per share attributable to Dell Technologies Inc. - diluted, EBITDA, and adjusted EBITDA, which are non-GAAP financial measures provided as a supplement to the results provided in accordance with generally accepted accounting principles in the United States of America (“GAAP”). A detailed discussion of Dell Technologies’ reasons for including these non-GAAP financial measures, the limitations associated with these measures, the items excluded from these measures, and our reason for excluding those items are presented in “Management’s Discussion and Analysis of Financial Condition and Results of Operations — Non-GAAP Financial Measures” in our periodic reports filed with the SEC. Dell Technologies encourages investors to review the non-GAAP discussion in these reports in conjunction with the presentation of non-GAAP financial measures.

[0001571996-20-000028:8k_2_02:97]
10

[0001571996-20-000028:8k_2_02:98]
DELL TECHNOLOGIES INC.

[0001571996-20-000028:8k_2_02:99]
Selected Non-GAAP Financial Measures

[0001571996-20-000028:8k_2_02:100]
(in millions, except percentages; unaudited)

[0001571996-20-000028:8k_2_02:101]
|  | Three Months Ended |  |  |
|  | May 1, 2020 |  | May 3, 2019 |  | Change |
| Non-GAAP net revenue | $ | 21,945 |  |  | $ | 21,990 |  |  | — | % |
| Non-GAAP gross margin | $ | 7,325 |  |  | $ | 7,434 |  |  | (1 | )% |
| % of non-GAAP net revenue | 33 | % |  | 34 | % |  |  |
| Non-GAAP operating expenses | $ | 5,164 |  |  | $ | 5,238 |  |  | (1 | )% |
| % of non-GAAP net revenue | 24 | % |  | 24 | % |  |  |
| Non-GAAP operating income | $ | 2,161 |  |  | $ | 2,196 |  |  | (2 | )% |
| % of non-GAAP net revenue | 10 | % |  | 10 | % |  |  |
| Non-GAAP net income | $ | 1,143 |  |  | $ | 1,209 |  |  | (5 | )% |
| % of non-GAAP net revenue | 5 | % |  | 5 | % |  |  |
| Adjusted EBITDA | $ | 2,607 |  |  | $ | 2,573 |  |  | 1 | % |
| % of non-GAAP net revenue | 12 | % |  | 12 | % |  |  |

[0001571996-20-000028:8k_2_02:102]
11

[0001571996-20-000028:8k_2_02:103]
DELL TECHNOLOGIES INC.

[0001571996-20-000028:8k_2_02:104]
Reconciliation of Selected Non-GAAP Financial Measures

[0001571996-20-000028:8k_2_02:105]
(in millions, except percentages; unaudited; continued on next page)

[0001571996-20-000028:8k_2_02:106]
|  | Three Months Ended |  |  |
|  | May 1, 2020 |  | May 3, 2019 |  | Change |
| Net revenue | $ | 21,897 |  |  | $ | 21,908 |  |  | — | % |
| Non-GAAP adjustments: |  |  |  |  |  |
| Impact of purchase accounting | 48 |  |  | 82 |  |  |  |
| Non-GAAP net revenue | $ | 21,945 |  |  | $ | 21,990 |  |  | — | % |
| Gross margin | $ | 6,853 |  |  | $ | 6,797 |  |  | 1 | % |
| Non-GAAP adjustments: |  |  |  |  |  |
| Amortization of intangibles | 372 |  |  | 519 |  |  |  |
| Impact of purchase accounting | 51 |  |  | 84 |  |  |  |
| Transaction-related expenses | — |  |  | (5 | ) |  |  |
| Stock-based compensation expense | 40 |  |  | 26 |  |  |  |
| Other corporate expenses | 9 |  |  | 13 |  |  |  |
| Non-GAAP gross margin | $ | 7,325 |  |  | $ | 7,434 |  |  | (1 | )% |
| Operating expenses | $ | 6,151 |  |  | $ | 6,247 |  |  | (2 | )% |
| Non-GAAP adjustments: |  |  |  |  |  |
| Amortization of intangibles | (483 | ) |  | (698 | ) |  |  |
| Impact of purchase accounting | (12 | ) |  | (17 | ) |  |  |
| Transaction-related expenses | (76 | ) |  | (47 | ) |  |  |
| Stock-based compensation expense | (330 | ) |  | (237 | ) |  |  |
| Other corporate expenses | (86 | ) |  | (10 | ) |  |  |
| Non-GAAP operating expenses | $ | 5,164 |  |  | $ | 5,238 |  |  | (1 | )% |
| Operating income | $ | 702 |  |  | $ | 550 |  |  | 28 | % |
| Non-GAAP adjustments: |  |  |  |  |  |
| Amortization of intangibles | 855 |  |  | 1,217 |  |  |  |
| Impact of purchase accounting | 63 |  |  | 101 |  |  |  |
| Transaction-related expenses | 76 |  |  | 42 |  |  |  |
| Stock-based compensation expense | 370 |  |  | 263 |  |  |  |
| Other corporate expenses | 95 |  |  | 23 |  |  |  |
| Non-GAAP operating income | $ | 2,161 |  |  | $ | 2,196 |  |  | (2 | )% |

[0001571996-20-000028:8k_2_02:107]
12

[0001571996-20-000028:8k_2_02:108]
DELL TECHNOLOGIES INC.

[0001571996-20-000028:8k_2_02:109]
Reconciliation of Selected Non-GAAP Financial Measures

[0001571996-20-000028:8k_2_02:110]
(in millions, except percentages; unaudited; continued)

[0001571996-20-000028:8k_2_02:111]
|  | Three Months Ended |  |  |
|  | May 1, 2020 |  | May 3, 2019 |  | Change |
| Net income | $ | 182 |  |  | $ | 329 |  |  | (45 | )% |
| Non-GAAP adjustments: |  |  |  |  |  |
| Amortization of intangibles | 855 |  |  | 1,217 |  |  |  |
| Impact of purchase accounting | 63 |  |  | 101 |  |  |  |
| Transaction-related expenses | (44 | ) |  | 42 |  |  |  |
| Stock-based compensation expense | 370 |  |  | 263 |  |  |  |
| Other corporate expenses | 95 |  |  | 23 |  |  |  |
| Fair value adjustments on equity investments | (94 | ) |  | (62 | ) |  |  |
| Aggregate adjustment for income taxes | (284 | ) |  | (704 | ) |  |  |
| Non-GAAP net income | $ | 1,143 |  |  | $ | 1,209 |  |  | (5 | )% |
| Net income | $ | 182 |  |  | $ | 329 |  |  | (45 | )% |
| Adjustments: |  |  |  |  |  |
| Interest and other, net | 566 |  |  | 693 |  |  |  |
| Income tax benefit | (46 | ) |  | (472 | ) |  |  |
| Depreciation and amortization | 1,316 |  |  | 1,616 |  |  |  |
| EBITDA | $ | 2,018 |  |  | $ | 2,166 |  |  | (7 | )% |
| EBITDA | $ | 2,018 |  |  | $ | 2,166 |  |  | (7 | )% |
| Adjustments: |  |  |  |  |  |
| Stock-based compensation expense | 370 |  |  | 263 |  |  |  |
| Impact of purchase accounting | 48 |  |  | 83 |  |  |  |
| Transaction-related expenses | 76 |  |  | 42 |  |  |  |
| Other corporate expenses | 95 |  |  | 19 |  |  |  |
| Adjusted EBITDA | $ | 2,607 |  |  | $ | 2,573 |  |  | 1 | % |

[0001571996-20-000028:8k_2_02:112]
13

[0001571996-20-000028:8k_2_02:113]
DELL TECHNOLOGIES INC.

[0001571996-20-000028:8k_2_02:114]
Reconciliation of Selected Non-GAAP Financial Measures

[0001571996-20-000028:8k_2_02:115]
For the Three Months Ended May 1, 2020

[0001571996-20-000028:8k_2_02:116]
(in millions, except per share amounts; unaudited)

[0001571996-20-000028:8k_2_02:117]
|  | GAAP |  | Amortization of intangibles |  | Impact of purchase accounting |  | Transaction-related expenses |  | Stock-based compensation expense |  | Other corporate expenses |  | Fair value adjustments on equity investments |  | Aggregate adjustment for income taxes |  | Non-GAAP |
| Net income | $ | 182 |  |  | 855 |  |  | 63 |  |  | (44 | ) |  | 370 |  |  | 95 |  |  | (94 | ) |  | (284 | ) |  | $ | 1,143 |  |
| Less: Net income attributable to non-controlling interests (a) | 39 |  |  | 60 |  |  | 3 |  |  | 7 |  |  | 54 |  |  | — |  |  | (1 | ) |  | (35 | ) |  | 127 |  |
| Net income attributable to Dell Technologies Inc. - basic | 143 |  |  | 795 |  |  | 60 |  |  | (51 | ) |  | 316 |  |  | 95 |  |  | (93 | ) |  | (249 | ) |  | 1,016 |  |
| Incremental dilution from VMware, Inc. attributable to Dell Technologies Inc. (b) | (2 | ) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | (4 | ) |
| Net income attributable to Dell Technologies Inc. - diluted | $ | 141 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 1,012 |  |
| Earnings per share - basic | $ | 0.19 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 1.37 |  |
| Earnings per share - diluted | $ | 0.19 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 1.34 |  |
| Weighted-average shares outstanding - basic | 740 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 740 |  |
| Weighted-average shares outstanding - diluted | 755 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 755 |  |

[0001571996-20-000028:8k_2_02:118]
_________________

[0001571996-20-000028:8k_2_02:119]
| (a) | Net income attributable to non-controlling interests is calculated by multiplying the minority interest percentage of VMware, Inc. and SecureWorks Corp. by their non-GAAP net income adjustments for the period presented. |

[0001571996-20-000028:8k_2_02:120]
| (b) | Incremental dilution from VMware, Inc. attributable to Dell Technologies Inc. represents the impact of VMware, Inc.’s dilutive securities on the diluted earnings per share of Dell Technologies Inc. and is calculated by multiplying the difference between VMware, Inc.’s basic and diluted earnings per share by the number of shares of VMware, Inc. common stock held by Dell Technologies Inc. |

[0001571996-20-000028:8k_2_02:121]
DELL TECHNOLOGIES INC.

[0001571996-20-000028:8k_2_02:122]
Reconciliation of Selected Non-GAAP Financial Measures

[0001571996-20-000028:8k_2_02:123]
For the Three Months Ended May 3, 2019

[0001571996-20-000028:8k_2_02:124]
(in millions, except per share amounts; unaudited)

[0001571996-20-000028:8k_2_02:125]
|  | GAAP |  | Amortization of intangibles |  | Impact of purchase accounting |  | Transaction-related expenses |  | Stock-based compensation expense |  | Other corporate expenses |  | Fair value adjustments on equity investments |  | Aggregate adjustment for income taxes |  | Non-GAAP |
| Net income | $ | 329 |  |  | 1,217 |  |  | 101 |  |  | 42 |  |  | 263 |  |  | 23 |  |  | (62 | ) |  | (704 | ) |  | $ | 1,209 |  |
| Less: Net income attributable to non-controlling interests (a) | 36 |  |  | 73 |  |  | 6 |  |  | 3 |  |  | 46 |  |  | — |  |  | (26 | ) |  | (29 | ) |  | 109 |  |
| Net income attributable to Dell Technologies Inc. - basic | 293 |  |  | 1,144 |  |  | 95 |  |  | 39 |  |  | 217 |  |  | 23 |  |  | (36 | ) |  | (675 | ) |  | 1,100 |  |
| Incremental dilution from VMware, Inc. attributable to Dell Technologies Inc. (b) | (8 | ) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | (8 | ) |
| Net income attributable to Dell Technologies Inc. - diluted | $ | 285 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 1,092 |  |
| Earnings per share - basic | $ | 0.41 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 1.53 |  |
| Earnings per share - diluted | $ | 0.38 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 1.45 |  |
| Weighted-average shares outstanding - basic | 717 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 717 |  |
| Weighted-average shares outstanding - diluted | 751 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 751 |  |

[0001571996-20-000028:8k_2_02:126]
_________________

[0001571996-20-000028:8k_2_02:127]
| (a) | Net income attributable to non-controlling interests is calculated by multiplying the minority interest percentage of VMware, Inc., Pivotal Software, Inc., and SecureWorks Corp. by their non-GAAP net income adjustments for the period presented. |

[0001571996-20-000028:8k_2_02:128]
| (b) | Incremental dilution from VMware, Inc. attributable to Dell Technologies Inc. represents the impact of VMware, Inc.’s dilutive securities on the diluted earnings per share of Dell Technologies Inc. and is calculated by multiplying the difference between VMware, Inc.’s basic and diluted earnings per share by the number of shares of VMware, Inc. common stock held by Dell Technologies Inc. |

[0001571996-20-000028:8k_2_02:129]
15
