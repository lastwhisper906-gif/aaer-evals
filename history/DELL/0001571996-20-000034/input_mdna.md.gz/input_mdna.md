# DELL MD&A — 0001571996-20-000034


## mdna

[0001571996-20-000034:mdna:1]
[same as prior period, unchanged from 0001571996-19-000051:mdna:1]

[0001571996-20-000034:mdna:2]
[same as prior period, unchanged from 0001571996-19-000051:mdna:2]

[0001571996-20-000034:mdna:3]
[same as prior period, unchanged from 0001571996-19-000051:mdna:3]

[0001571996-20-000034:mdna:4]
Our fiscal year is the 52- or 53-week period ending on the Friday nearest January 31.  We refer to our fiscal year ending January 29, 2021 and our fiscal year ended January 31, 2020 as “Fiscal 2021” and “Fiscal 2020,” respectively.  Fiscal 2021 and Fiscal 2020 include 52 weeks.

[0001571996-20-000034:mdna:5]
[same as prior period, unchanged from 0001571996-19-000051:mdna:5]

[0001571996-20-000034:mdna:6]
Dell Technologies is a leading global end-to-end technology provider, with a comprehensive portfolio of IT hardware, software, and services solutions spanning both traditional infrastructure and emerging multi-cloud technologies that enable our customers to build their digital future and transform how they work and live.  We operate globally across key functional areas such as technology and product development, marketing, go-to-market, and global services, and are supported by Dell Financial Services.  We continue to seamlessly deliver differentiated and holistic IT solutions to our customers, which has driven significant revenue growth and share gains.

[0001571996-20-000034:mdna:7]
Dell Technologies operates with significant scale and an unmatched breadth of complementary offerings.  Digital transformation has become essential to all businesses, and we have expanded our portfolio to include holistic solutions that enable our customers to drive their ongoing digital transformation initiatives.  Dell Technologies’ integrated solutions help customers modernize their IT infrastructure, address workforce transformation, and provide critical security solutions to protect against the ever increasing and evolving security threats.  With our extensive portfolio and our commitment to innovation, we have the ability to offer secure, integrated solutions that extend from the edge to the core to the cloud, and we are at the forefront of the software-defined and cloud native infrastructure era.  Our end-to-end portfolio is supported by a differentiated go-to-market engine, which includes a 43,000-person sales force, a global network of channel partners, and a world-class supply chain that together drive long-term growth and operating efficiencies.

[0001571996-20-000034:mdna:8]
[same as prior period, unchanged from 0001571996-19-000051:mdna:8]

[0001571996-20-000034:mdna:9]
We design, develop, manufacture, market, sell, and support a wide range of comprehensive and integrated solutions, products, and services.  We are organized into the following business units, which are our reportable segments: Infrastructure Solutions Group; Client Solutions Group; and VMware.

[0001571996-20-000034:mdna:10]
| • | Infrastructure Solutions Group (“ISG”) — ISG enables the digital transformation of our customers through our trusted multi-cloud and big data solutions, which are built upon a modern data center infrastructure. ISG works with customers in the area of hybrid cloud deployment with the goal of simplifying, streamlining, and automating cloud operations. ISG solutions are built for multicloud environments and are optimized to run cloud native workloads in both public and private clouds, as well as traditional on-premise workloads. |

[0001571996-20-000034:mdna:11]
Our comprehensive portfolio of advanced storage solutions includes traditional storage solutions as well as next-generation storage solutions (such as all-flash arrays, scale-out file, object platforms, and software-defined solutions).  We have simplified our storage portfolio to ensure that we deliver the technology needed for our customers’ digital transformation.  Our server portfolio includes high-performance rack, blade, tower, and hyperscale servers, optimized for artificial intelligence and machine learning workloads.  Our networking portfolio helps our business customers transform and modernize their infrastructure, mobilize and enrich end-user experiences, and accelerate business applications and processes.  Our strengths in server, storage, and virtualization software solutions enable us to offer leading converged and hyper-converged solutions, allowing our customers to accelerate their IT transformation by acquiring scalable integrated IT solutions instead of building and assembling their own IT platforms.  ISG also offers attached software, peripherals, and services, including support and deployment, configuration, and extended warranty services.

[0001571996-20-000034:mdna:12]
[same as prior period, unchanged from 0001571996-19-000051:mdna:12]

[0001571996-20-000034:mdna:13]
[same as prior period, unchanged from 0001571996-19-000051:mdna:13]

[0001571996-20-000034:mdna:14]
[same as prior period, unchanged from 0001571996-19-000051:mdna:14]

[0001571996-20-000034:mdna:15]
| • | VMware — The VMware reportable segment (“VMware”) reflects the operations of VMware, Inc. (NYSE: VMW) within Dell Technologies. VMware works with customers in the areas of hybrid and multi-cloud, modern applications, networking, security, and digital workspaces, helping customers manage their IT resources across private clouds and complex multi-cloud, multi-device environments. VMware’s portfolio supports and addresses the key IT priorities of customers: accelerating their cloud journey, modernizing their applications, empowering digital workspaces, transforming networking, and embracing intrinsic security. VMware enables its customers to digitally transform their operations as they ready their applications, infrastructure, and employees for constantly evolving business needs. |

[0001571996-20-000034:mdna:16]
During the third quarter of Fiscal 2020, VMware, Inc. completed its acquisition of Carbon Black, Inc. (“Carbon Black”), a developer of cloud-native endpoint protection.

[0001571996-20-000034:mdna:17]
On December 30, 2019, VMware, Inc. completed its acquisition of Pivotal Software, Inc. (“Pivotal”).  Before the transaction, Pivotal was a majority-owned subsidiary of Dell Technologies through EMC and VMware, Inc.  Pivotal provides a leading cloud-native platform that makes software development and IT operations a strategic advantage for customers.  Pivotal’s cloud-native platform, Pivotal Cloud Foundry, accelerates and streamlines software development by reducing the complexity of building, deploying, and operating new cloud-native applications, and modernizing

[0001571996-20-000034:mdna:18]
legacy applications.  With the acquisition, which aligns key software assets, VMware, Inc. will drive and build on a comprehensive development platform with Kubernetes.

[0001571996-20-000034:mdna:19]
Dell Technologies now reports Pivotal results within the VMware reportable segment, and the historical segment results have been recast to reflect this change.  Pivotal results were previously reported within other businesses.  See Note 17 of the Notes to the Condensed Consolidated Financial Statements included in this report for the recast of segment results.

[0001571996-20-000034:mdna:20]
[same as prior period, unchanged from 0001571996-19-000051:mdna:18]

[0001571996-20-000034:mdna:21]
Our other businesses, described below, consist of product and service offerings of Secureworks, Virtustream, Boomi, and RSA Security, each of which is majority-owned by Dell Technologies.  These businesses are not classified as reportable segments, either individually or collectively, as the results of the businesses are not material to our overall results and the businesses do not meet the criteria for reportable segments.

[0001571996-20-000034:mdna:22]
[same as prior period, unchanged from 0001571996-19-000051:mdna:23]

[0001571996-20-000034:mdna:23]
[same as prior period, unchanged from 0001571996-19-000051:mdna:25]

[0001571996-20-000034:mdna:24]
[same as prior period, unchanged from 0001571996-19-000051:mdna:26]

[0001571996-20-000034:mdna:25]
| • | RSA Security provides essential cybersecurity solutions engineered to enable organizations to detect, investigate, and respond to advanced attacks, confirm and manage identities, and, ultimately, help reduce IP theft, fraud, and cybercrime. In February 2020, Dell Technologies announced its entry into a definitive agreement to sell RSA Security to a consortium of investors in an all-cash transaction for approximately $2.075 billion, subject to certain closing adjustments. The transaction, expected to close in the third quarter of Fiscal 2021, is intended to further simplify our product portfolio and corporate structure. |

[0001571996-20-000034:mdna:26]
We believe the collaboration, innovation, and coordination of the operations and strategies across all segments of our business, as well as our differentiated go-to-market model, will continue to drive revenue synergies.  Through our coordinated research and development activities, we are able to jointly engineer leading innovative solutions that incorporate the distinct set of hardware, software, and services across all segments of our business.

[0001571996-20-000034:mdna:27]
Our products and services offerings are continually evolving in response to industry dynamics.  As a result, reclassifications of certain products and services solutions in major product categories may be required.  For further discussion regarding our current reportable segments, see “Results of Operations — Business Unit Results” and Note 17 of the Notes to the Condensed Consolidated Financial Statements included in this report.

[0001571996-20-000034:mdna:28]
[same as prior period, unchanged from 0001571996-19-000051:mdna:31]

[0001571996-20-000034:mdna:29]
Dell Financial Services and its affiliates (“DFS”) support our businesses by offering and arranging various financing options and services for our customers in North America, Europe, Australia, and New Zealand.  DFS originates, collects, and services customer receivables primarily related to the purchase or use of our product, software, and service solutions.  We also arrange financing for some of our customers in various countries where DFS does not currently operate as a captive.  DFS further strengthens our customer relationships through its flexible consumption models, which enable us to offer our customers the option to pay over time and, in certain cases, based on utilization, providing them with financial flexibility to meet their changing technological requirements.  The results of these operations are allocated to our segments based on the underlying product or service financed.  For additional information about our financing arrangements, see Note 4 of the Notes to the Condensed Consolidated Financial Statements included in this report.

[0001571996-20-000034:mdna:30]
[same as prior period, unchanged from 0001571996-19-000051:mdna:33]

[0001571996-20-000034:mdna:31]
As part of our strategy, we will continue to evaluate opportunities for strategic investments through our venture capital investment arm, Dell Technologies Capital, with a focus on emerging technology areas that are relevant to all segments of our business and that will complement our existing portfolio of solutions.  Our investment areas include storage, software-defined networking, management and orchestration, security, machine learning and artificial intelligence, Big Data and analytics, cloud, Internet of Things (“IoT”), and software development operations.  In addition to these investments, we also may make disciplined acquisitions targeting businesses that advance our strategic objectives.  As of May 1, 2020 and January 31, 2020, Dell Technologies held strategic investments of $1.0 billion and $0.9 billion, respectively.

[0001571996-20-000034:mdna:32]
[same as prior period, unchanged from 0001571996-19-000051:mdna:35]

[0001571996-20-000034:mdna:33]
COVID-19 Pandemic and Response — In March 2020, the World Health Organization (“WHO”) declared the outbreak of the coronavirus disease 2019 (“COVID-19”) a global pandemic.  This declaration has been followed by significant governmental measures implemented in the United States and globally, including travel bans and restrictions, shelter-in-place orders, limitations and closures of non-essential businesses, and social distancing requirements in efforts to slow down and control the spread of the virus.

[0001571996-20-000034:mdna:34]
The health of our employees, customers, business partners, and communities remains our primary focus.  We have taken numerous actions to date in response to COVID-19, including a swift implementation of our business continuity plans.  Our crisis management team is actively engaged to respond to changes in our environment quickly and effectively, and to ensure that our preparedness plans and response activities are aligned with recommendations of the WHO, the U.S. Centers for Disease Control and Prevention and governmental regulations.  We have implemented broad travel restrictions and moved to virtual-only events.  Most of our employees were previously equipped with remote work capabilities over the past several years, thus we were able to quickly establish a work from home posture for the majority of our employees.  Further, we implemented pandemic-specific protocols for our essential employees whose jobs require them to be on-site or with customers.  Certain regions and municipalities within the United States and internationally are beginning to lift stay-at-home and quarantine mandates, and we are actively developing return-to-site protocols to ensure the health and safety of our employees, customers, and business partners.

[0001571996-20-000034:mdna:35]
We are working closely with our customers and business partners to support them as they expand their own remote work solutions and contingency plans, helping them access our products and services remotely.  We have benefited from our agility, our breadth, and our scale.  Notable actions we have taken include the following:

[0001571996-20-000034:mdna:36]
| • | Our global sales teams embraced a new selling process and are successfully supporting our customers and partners remotely. |

[0001571996-20-000034:mdna:37]
| • | We are helping to address our customers’ cash flow requirements by expanding our as-a-service and financing offerings. |

[0001571996-20-000034:mdna:38]
| • | Our close relationships and ability to connect directly with our customers through our e-commerce business have enabled us to quickly meet the immediate demands of the new work and learn from home environments. |

[0001571996-20-000034:mdna:39]
| • | The strength, scale, and resiliency of our global supply chain have afforded us flexibility to manage through this challenging time. We adapted to events unfolding real-time by applying predictive analytics to model a variety of outcomes to respond quickly to the changing environment. We were able to keep factories open by working through various local governmental regulations and mandates. During this time, we established robust safety measures to protect the health and safety of our essential team members. |

[0001571996-20-000034:mdna:40]
| • | We continue to drive innovation and excellence in engineering with a largely remote workforce. Engineers and product teams recently delivered several critical solutions, including cloud updates, and key client product refreshes, as well as the May 2020 launch of the PowerStore midrange storage solution. |

[0001571996-20-000034:mdna:41]
During the first quarter of Fiscal 2021, we also took certain precautionary measures to increase our cash position and preserve financial flexibility.  For additional information regarding our cash position, liquidity and capital structure, see “Market Conditions, Liquidity and Capital Commitments.”

[0001571996-20-000034:mdna:42]
60

[0001571996-20-000034:mdna:43]
We saw unique demand dynamics over the course of the quarter and see an uncertain environment as we look ahead.  We made a series of prudent decisions to manage expenses and preserve liquidity including but not limited to global hiring limitations, reduction in consulting and contractor costs, global travel restrictions, and, subsequent to May 1, 2020, a temporary suspension of the Dell 401(k) match program for U.S. employees.  All of these decisions are aligned with our strategy, which remains unchanged, of focusing on gaining share, integrating and innovating across the Dell Technologies portfolio, and strengthening our capital structure.

[0001571996-20-000034:mdna:44]
For additional information about impacts of COVID-19 on our operations, see “Results of Operations—Consolidated Results” and “—Business Unit Results.”

[0001571996-20-000034:mdna:45]
We are unable to accurately predict the full impact that this unprecedented environment may have on our results from operations, financial condition, liquidity and cash flows due to numerous uncertainties involved, including the progression of the COVID-19 pandemic, governmental responses, and the timing of recovery.  We will continue to actively monitor global events and make prudent decisions to navigate in this uncertain and ever-changing environment.  We believe we are well-positioned for long-term success, and that we will continue to lead the industry with innovative solutions and the essential technology that the world needs now more than ever.

[0001571996-20-000034:mdna:46]
Dell Technologies Vision and Innovation — Our vision is to be the essential technology company for the data era and a leader in end-user computing, software-defined data center solutions, data management, virtualization, IoT, and cloud software.  We believe that our results will benefit from an integrated go-to-market strategy, including enhanced coordination across all segments of our business, and from our differentiated products and solutions capabilities.  We intend to continue to execute on our business model and seek to balance liquidity, profitability, and growth to position our company for long-term success.

[0001571996-20-000034:mdna:47]
We are seeing an accelerated rate of change in the IT industry.  We seek to address our customers’ evolving needs and their broader digital transformation objectives as they embrace the hybrid multi-cloud environment of today.  New technologies are being introduced and adopted quickly.  In light of this rapid pace of innovation, we continue to invest in research and development, sales, and other key areas of our business to deliver superior products and solutions capabilities and to drive execution of long-term sustainable growth.

[0001571996-20-000034:mdna:48]
ISG — We expect that ISG will continue to be impacted by the changing nature of the IT infrastructure market and competitive environment.  The overall server demand environment was down for the quarter and remains varied among international regions.  We will continue to be selective in determining whether to pursue certain large hyperscale and other server transactions as we drive for balanced growth and profitability.  With our scale and strong solutions portfolio, we believe we are well positioned to respond to ongoing competitive dynamics.  We continue to focus on customer base expansion and lifetime value of customer measurements.

[0001571996-20-000034:mdna:49]
Cloud-native applications are expected to continue as a primary growth driver in the infrastructure market as IT organizations increasingly adopt cloud native architectures.  We believe the complementary cloud solutions across our business strongly position us to meet these demands for our customers, who are increasingly looking to leverage cloud native architectures, whether on-premises, private or public.

[0001571996-20-000034:mdna:50]
The unprecedented data growth throughout all industries is generating continued demand for our storage solutions and services.  We benefit by offering solutions that address the emerging trends of enterprises deploying software-defined storage, hyper-converged infrastructure, and modular solutions based on server-centric architectures.  These trends are changing the way customers are consuming our traditional storage offerings.  We continue to expand our offerings in external storage arrays, which incorporate flexible, cloud-based functionality.  Through our research and development efforts, we are developing new solutions in this rapidly changing industry that we believe will enable us to continue to provide superior solutions to our customers.

[0001571996-20-000034:mdna:51]
CSG — Our CSG offerings are an important element of our strategy, generating strong cash flow and opportunities for cross-selling of complementary solutions.  Given current market trends, we expect that the CSG demand environment will continue to be cyclical.  Although CSG demand was robust for portions of the first quarter of Fiscal 2021, industry analysts are forecasting overall demand for our CSG solutions will decelerate in Fiscal 2021 given the current macro-economic environment, including the effects of COVID-19.  Competitive dynamics will continue to be a factor in our CSG business as we seek to balance profitability and growth.  We are committed to a long-term growth strategy, and beyond Fiscal 2021 we believe the CSG demand environment will strengthen due to continued innovation across our solutions portfolio and the ongoing need for work from home solutions, as well as the consolidation trends that are occurring in the markets in which we compete.

[0001571996-20-000034:mdna:52]
Recurring Revenue and Consumption Models — Our customers are interested in new and innovative models that address how they consume our solutions.  We offer options including as-a-service, utility, leases, and immediate pay models, all designed to match customers’ consumption and financing preferences.  Our multi-year agreements typically result in recurring revenue streams over the term of the arrangement.  We expect our flexible consumption models will further strengthen our customer relationships and provide a foundation for growth in recurring revenue.

[0001571996-20-000034:mdna:53]
Supply Chain — During Fiscal 2020, we recognized benefits to our ISG and CSG operating results from significant component cost declines.  During the first quarter of Fiscal 2021, the cost environment continued to be deflationary in the aggregate for both ISG and CSG, but at a lower rate than in Fiscal 2020.  We currently expect the component cost environment to be inflationary during the second quarter of Fiscal 2021 and to continue to be inflationary for the second half of Fiscal 2021.  This may result in consolidated operating results for Fiscal 2021 that trend more toward Fiscal 2019 levels.  The component cost trends and forecasts are dependent on the strength or weakness of actual end user demand and supply dynamics, which will continue to evolve and ultimately impact the translation of the cost environment to pricing and operating results.

[0001571996-20-000034:mdna:54]
Dell Technologies maintains limited-source supplier relationships for processors, because the relationships are advantageous in the areas of performance, quality, support, delivery, capacity, and price considerations.  In recent periods, we have been impacted by processor and other supply constraints in certain product offerings.  Delays in the supply of limited-source components, including as a result of COVID-19, are affecting the timing of shipments of certain products in desired quantities or configurations.

[0001571996-20-000034:mdna:55]
Macro-Economic Risks and Uncertainties — The impacts of trade protection measures, including increases in tariffs and trade barriers, and changes in government policies and international trade arrangements may affect our ability to conduct business in some non-U.S. markets.  We monitor and seek to mitigate these risks with adjustments to our manufacturing, supply chain and distribution networks.

[0001571996-20-000034:mdna:56]
We manage our business on a U.S. dollar basis.  However, we have a large global presence, generating approximately half of our revenue by sales to customers outside of the United States during both the first quarter of Fiscal 2021 and Fiscal 2020.  As a result, our revenue can be impacted by fluctuations in foreign currency exchange rates.  We utilize a comprehensive hedging strategy intended to mitigate the impact of foreign currency volatility over time, and we adjust pricing when possible to further minimize foreign currency impacts.

[0001571996-20-000034:mdna:57]
[same as prior period, unchanged from 0001571996-19-000051:mdna:45]

[0001571996-20-000034:mdna:58]
[same as prior period, unchanged from 0001571996-19-000051:mdna:46]

[0001571996-20-000034:mdna:59]
[same as prior period, unchanged from 0001571996-19-000051:mdna:47]

[0001571996-20-000034:mdna:60]
[same as prior period, unchanged from 0001571996-19-000051:mdna:48]

[0001571996-20-000034:mdna:61]
62

[0001571996-20-000034:mdna:62]
[same as prior period, unchanged from 0001571996-19-000051:mdna:51]

[0001571996-20-000034:mdna:63]
[same as prior period, unchanged from 0001571996-19-000051:mdna:52]

[0001571996-20-000034:mdna:64]
[same as prior period, unchanged from 0001571996-19-000051:mdna:53]

[0001571996-20-000034:mdna:65]
[same as prior period, unchanged from 0001571996-19-000051:mdna:54]

[0001571996-20-000034:mdna:66]
[same as prior period, unchanged from 0001571996-19-000051:mdna:55]

[0001571996-20-000034:mdna:67]
Revenue Reclassification — During  Fiscal 2020, Dell Technologies made certain reclassifications of net revenue between the products and services categories on the Consolidated Statement of Net Income (Loss), which impacted previously reported amounts for the first quarter of Fiscal 2020.  The reclassifications were made to provide a more meaningful representation of the nature of certain service and software-as-a-service offerings of VMware, Inc.  The reclassifications resulted in an increase to services revenue and an equal and offsetting decrease to product revenue of $179 million for the first quarter of Fiscal 2020.  Total net revenue as previously reported remains unchanged.  The Company did not recast cost of goods sold for the related revenue reclassifications due to immateriality.

[0001571996-20-000034:mdna:68]
63

[0001571996-20-000034:mdna:69]
[same as prior period, unchanged from 0001571996-19-000051:mdna:57]

[0001571996-20-000034:mdna:70]
[same as prior period, unchanged from 0001571996-19-000051:mdna:58]

[0001571996-20-000034:mdna:71]
[same as prior period, unchanged from 0001571996-19-000051:mdna:59]

[0001571996-20-000034:mdna:72]
| • | Transaction-related Expenses — Transaction-related expenses typically consist of acquisition, integration, and divestiture related costs and are expensed as incurred. These expenses primarily represent costs for legal, banking, consulting, and advisory services. During both the first quarter of Fiscal 2021 and Fiscal 2020, transaction expenses related to VMware, Inc. acquisitions. From time to time, this category also may include transaction-related gains on divestitures of businesses or asset sales. During the first quarter of Fiscal 2021, we recognized a gain of $120 million on the sale of certain intellectual property assets. We exclude these items for purposes of calculating the non-GAAP financial measures presented below to facilitate a more meaningful evaluation of our current operating performance and comparisons to our past operating performance. |

[0001571996-20-000034:mdna:73]
| • | Stock-based Compensation Expense — Stock-based compensation expense consists of equity awards granted based on the estimated fair value of those awards at grant date. We estimate the fair value of service-based stock options using the Black-Scholes valuation model. To estimate the fair value of performance-based awards containing a market condition, we use the Monte Carlo valuation model. For all other share-based awards, the fair value is based on the closing price of the Class C Common Stock as reported on the NYSE on the date of grant. Although stock-based compensation is an important aspect of the compensation of our employees and executives, the fair value of the stock-based awards may bear little resemblance to the actual value realized upon the vesting or future exercise of the related stock-based awards. We believe that excluding stock-based compensation expense for purposes of calculating the non-GAAP financial measures presented below facilitates a more meaningful evaluation of our current operating performance and comparisons to our past operating performance. |

[0001571996-20-000034:mdna:74]
| • | Other Corporate Expenses — Other corporate expenses consists primarily of severance, facility action, and other costs. Severance costs are primarily related to severance and benefits for employees terminated pursuant to cost savings initiatives. We continue to integrate owned and leased facilities and may incur additional costs as we seek opportunities for operational efficiencies. Other corporate expenses vary from period to period and are significantly impacted by the timing and nature of these events. Therefore, although we may incur these types of expenses in the future, we believe that eliminating these charges for purposes of calculating the non-GAAP financial measures presented below facilitates a more meaningful evaluation of our current operating performance and comparisons to our past operating performance. |

[0001571996-20-000034:mdna:75]
64

[0001571996-20-000034:mdna:76]
[same as prior period, unchanged from 0001571996-19-000051:mdna:64]

[0001571996-20-000034:mdna:77]
| • | Aggregate Adjustment for Income Taxes — The aggregate adjustment for income taxes is the estimated combined income tax effect for the adjustments described above, as well as an adjustment for discrete tax items. Due to the variability in recognition of discrete tax items from period to period, we believe that excluding these benefits or charges for purposes of calculating non-GAAP net income facilitates a more meaningful evaluation of our current operating performance and comparisons to our past operating performance. The tax effects are determined based on the tax jurisdictions where the above items were incurred. This category includes discrete tax benefits of $59 million and $405 million related to intra-entity asset transfers that were completed during the first quarter of Fiscal 2021 and Fiscal 2020, respectively. See Note 11 of the Notes to the Condensed Consolidated Financial Statements for additional information on our income taxes. |

[0001571996-20-000034:mdna:78]
65

[0001571996-20-000034:mdna:79]
[same as prior period, unchanged from 0001571996-19-000051:mdna:67]

[0001571996-20-000034:mdna:80]
|  | Three Months Ended |
|  | May 1, 2020 |  | % Change |  | May 3, 2019 |
|  | (in millions, except percentages) |
| Product net revenue | $ | 16,038 |  |  | (3 | )% |  | $ | 16,575 |  |
| Non-GAAP adjustments: |  |  |  |  |  |
| Impact of purchase accounting | 4 |  |  |  |  | 4 |  |
| Non-GAAP product net revenue | $ | 16,042 |  |  | (3 | )% |  | $ | 16,579 |  |
| Services net revenue | $ | 5,859 |  |  | 10 | % |  | $ | 5,333 |  |
| Non-GAAP adjustments: |  |  |  |  |  |
| Impact of purchase accounting | 44 |  |  |  |  | 78 |  |
| Non-GAAP services net revenue | $ | 5,903 |  |  | 9 | % |  | $ | 5,411 |  |
| Net revenue | $ | 21,897 |  |  | — | % |  | $ | 21,908 |  |
| Non-GAAP adjustments: |  |  |  |  |  |
| Impact of purchase accounting | 48 |  |  |  |  | 82 |  |
| Non-GAAP net revenue | $ | 21,945 |  |  | — | % |  | $ | 21,990 |  |
| Product gross margin | $ | 3,234 |  |  | (7 | )% |  | $ | 3,496 |  |
| Non-GAAP adjustments: |  |  |  |  |  |
| Amortization of intangibles | 372 |  |  |  |  | 519 |  |
| Impact of purchase accounting | 7 |  |  |  |  | 6 |  |
| Transaction-related expenses | — |  |  |  |  | (2 | ) |
| Stock-based compensation expense | 4 |  |  |  |  | 2 |  |
| Other corporate expenses | 2 |  |  |  |  | 4 |  |
| Non-GAAP product gross margin | $ | 3,619 |  |  | (10 | )% |  | $ | 4,025 |  |
| Services gross margin | $ | 3,619 |  |  | 10 | % |  | $ | 3,301 |  |
| Non-GAAP adjustments: |  |  |  |  |  |
| Impact of purchase accounting | 44 |  |  |  |  | 78 |  |
| Transaction-related expenses | — |  |  |  |  | (3 | ) |
| Stock-based compensation expense | 36 |  |  |  |  | 24 |  |
| Other corporate expenses | 7 |  |  |  |  | 9 |  |
| Non-GAAP services gross margin | $ | 3,706 |  |  | 9 | % |  | $ | 3,409 |  |

[0001571996-20-000034:mdna:81]
|  | Three Months Ended |
|  | May 1, 2020 |  | % Change |  | May 3, 2019 |
|  | (in millions, except percentages) |
| Gross margin | $ | 6,853 |  |  | 1 | % |  | $ | 6,797 |  |
| Non-GAAP adjustments: |  |  |  |  |  |
| Amortization of intangibles | 372 |  |  |  |  | 519 |  |
| Impact of purchase accounting | 51 |  |  |  |  | 84 |  |
| Transaction-related expenses | — |  |  |  |  | (5 | ) |
| Stock-based compensation expense | 40 |  |  |  |  | 26 |  |
| Other corporate expenses | 9 |  |  |  |  | 13 |  |
| Non-GAAP gross margin | $ | 7,325 |  |  | (1 | )% |  | $ | 7,434 |  |
| Operating expenses | $ | 6,151 |  |  | (2 | )% |  | $ | 6,247 |  |
| Non-GAAP adjustments: |  |  |  |  |  |
| Amortization of intangibles | (483 | ) |  |  |  | (698 | ) |
| Impact of purchase accounting | (12 | ) |  |  |  | (17 | ) |
| Transaction-related expenses | (76 | ) |  |  |  | (47 | ) |
| Stock-based compensation expense | (330 | ) |  |  |  | (237 | ) |
| Other corporate expenses | (86 | ) |  |  |  | (10 | ) |
| Non-GAAP operating expenses | $ | 5,164 |  |  | (1 | )% |  | $ | 5,238 |  |
| Operating income | $ | 702 |  |  | 28 | % |  | $ | 550 |  |
| Non-GAAP adjustments: |  |  |  |  |  |
| Amortization of intangibles | 855 |  |  |  |  | 1,217 |  |
| Impact of purchase accounting | 63 |  |  |  |  | 101 |  |
| Transaction-related expenses | 76 |  |  |  |  | 42 |  |
| Stock-based compensation expense | 370 |  |  |  |  | 263 |  |
| Other corporate expenses | 95 |  |  |  |  | 23 |  |
| Non-GAAP operating income | $ | 2,161 |  |  | (2 | )% |  | $ | 2,196 |  |
| Net income | $ | 182 |  |  | (45 | )% |  | $ | 329 |  |
| Non-GAAP adjustments: |  |  |  |  |  |
| Amortization of intangibles | 855 |  |  |  |  | 1,217 |  |
| Impact of purchase accounting | 63 |  |  |  |  | 101 |  |
| Transaction-related (income) expenses | (44 | ) |  |  |  | 42 |  |
| Stock-based compensation expense | 370 |  |  |  |  | 263 |  |
| Other corporate expenses | 95 |  |  |  |  | 23 |  |
| Fair value adjustments on equity investments | (94 | ) |  |  |  | (62 | ) |
| Aggregate adjustment for income taxes | (284 | ) |  |  |  | (704 | ) |
| Non-GAAP net income | $ | 1,143 |  |  | (5 | )% |  | $ | 1,209 |  |

[0001571996-20-000034:mdna:82]
67

[0001571996-20-000034:mdna:83]
In addition to the above measures, we also use EBITDA and adjusted EBITDA to provide additional information for evaluation of our operating performance.  Adjusted EBITDA excludes purchase accounting adjustments related to the EMC merger transaction and the going-private transaction, acquisition, integration, and divestiture related costs, severance, facility action, and other costs, and stock-based compensation expense.  We believe that, due to the non-operational nature of the purchase accounting entries, it is appropriate to exclude these adjustments.

[0001571996-20-000034:mdna:84]
[same as prior period, unchanged from 0001571996-19-000051:mdna:74]

[0001571996-20-000034:mdna:85]
The table below presents a reconciliation of EBITDA and adjusted EBITDA to net income for the periods indicated:

[0001571996-20-000034:mdna:86]
|  | Three Months Ended |
|  | May 1, 2020 |  | % Change |  | May 3, 2019 |
|  | (in millions, except percentages) |
| Net income | $ | 182 |  |  | (45 | )% |  | $ | 329 |  |
| Adjustments: |  |  |  |  |  |
| Interest and other, net (a) | 566 |  |  |  |  | 693 |  |
| Income tax benefit (b) | (46 | ) |  |  |  | (472 | ) |
| Depreciation and amortization | 1,316 |  |  |  |  | 1,616 |  |
| EBITDA | $ | 2,018 |  |  | (7 | )% |  | $ | 2,166 |  |
| EBITDA | $ | 2,018 |  |  | (7 | )% |  | $ | 2,166 |  |
| Adjustments: |  |  |  |  |  |
| Stock-based compensation expense | 370 |  |  |  |  | 263 |  |
| Impact of purchase accounting (c) | 48 |  |  |  |  | 83 |  |
| Transaction-related expenses (d) | 76 |  |  |  |  | 42 |  |
| Other corporate expenses (e) | 95 |  |  |  |  | 19 |  |
| Adjusted EBITDA | $ | 2,607 |  |  | 1 | % |  | $ | 2,573 |  |

[0001571996-20-000034:mdna:87]
[same as prior period, unchanged from 0001571996-19-000051:mdna:77]

[0001571996-20-000034:mdna:88]
[same as prior period, unchanged from 0001571996-19-000051:mdna:78]

[0001571996-20-000034:mdna:89]
| (b) | See Note 11 of the Notes to the Condensed Consolidated Financial Statements included in this report for additional information on discrete tax items recorded during the first quarter of Fiscal 2021 and Fiscal 2020. |

[0001571996-20-000034:mdna:90]
[same as prior period, unchanged from 0001571996-19-000051:mdna:80]

[0001571996-20-000034:mdna:91]
| (d) | Transaction-related expenses consist of acquisition, integration, and divestiture related costs. |

[0001571996-20-000034:mdna:92]
| (e) | Other corporate expenses includes severance, facility action, and other costs. |

[0001571996-20-000034:mdna:93]
[same as prior period, unchanged from 0001571996-19-000051:mdna:84]

[0001571996-20-000034:mdna:94]
[same as prior period, unchanged from 0001571996-19-000051:mdna:85]

[0001571996-20-000034:mdna:95]
The following table summarizes our consolidated results for each of the periods presented.  Unless otherwise indicated, all changes identified for the current period results represent comparisons to results for the prior corresponding fiscal period.

[0001571996-20-000034:mdna:96]
|  | Three Months Ended |
|  | May 1, 2020 |  |  |  | May 3, 2019 |
|  | Dollars |  | % ofNet Revenue |  | %Change |  | Dollars |  | % ofNet Revenue |
|  | (in millions, except percentages) |
| Net revenue: |  |  |  |  |  |  |  |  |  |
| Products (a) | $ | 16,038 |  |  | 73.2 | % |  | (3 | )% |  | $ | 16,575 |  |  | 75.7 | % |
| Services (a) | 5,859 |  |  | 26.8 | % |  | 10 | % |  | 5,333 |  |  | 24.3 | % |
| Total net revenue | $ | 21,897 |  |  | 100.0 | % |  | — | % |  | $ | 21,908 |  |  | 100.0 | % |
| Gross margin: |  |  |  |  |  |  |  |  |  |
| Products (b) | $ | 3,234 |  |  | 20.2 | % |  | (7 | )% |  | $ | 3,496 |  |  | 21.1 | % |
| Services (c) | 3,619 |  |  | 61.8 | % |  | 10 | % |  | 3,301 |  |  | 61.9 | % |
| Total gross margin | $ | 6,853 |  |  | 31.3 | % |  | 1 | % |  | $ | 6,797 |  |  | 31.0 | % |
| Operating expenses | $ | 6,151 |  |  | 28.1 | % |  | (2 | )% |  | $ | 6,247 |  |  | 28.5 | % |
| Operating income | $ | 702 |  |  | 3.2 | % |  | 28 | % |  | $ | 550 |  |  | 2.5 | % |
| Net income | $ | 182 |  |  | 0.8 | % |  | (45 | )% |  | $ | 329 |  |  | 1.5 | % |
| Net income attributable to Dell Technologies Inc. | $ | 143 |  |  | 0.7 | % |  | (51 | )% |  | $ | 293 |  |  | 1.3 | % |
| Non-GAAP Financial Information |  |  |  |  |  |  |  |  |
| Non-GAAP net revenue: |  |  |  |  |  |  |  |  |  |
| Product | $ | 16,042 |  |  | 73.1 | % |  | (3 | )% |  | $ | 16,579 |  |  | 75.4 | % |
| Services | 5,903 |  |  | 26.9 | % |  | 9 | % |  | 5,411 |  |  | 24.6 | % |
| Total non-GAAP net revenue | $ | 21,945 |  |  | 100.0 | % |  | — | % |  | $ | 21,990 |  |  | 100.0 | % |
| Non-GAAP gross margin: |  |  |  |  |  |  |  |  |  |
| Product (a) | $ | 3,619 |  |  | 22.6 | % |  | (10 | )% |  | $ | 4,025 |  |  | 24.3 | % |
| Services (b) | 3,706 |  |  | 62.8 | % |  | 9 | % |  | 3,409 |  |  | 63.0 | % |
| Total non-GAAP gross margin | $ | 7,325 |  |  | 33.4 | % |  | (1 | )% |  | $ | 7,434 |  |  | 33.8 | % |
| Non-GAAP operating expenses | $ | 5,164 |  |  | 23.6 | % |  | (1 | )% |  | $ | 5,238 |  |  | 23.8 | % |
| Non-GAAP operating income | $ | 2,161 |  |  | 9.8 | % |  | (2 | )% |  | $ | 2,196 |  |  | 10.0 | % |
| Non-GAAP net income | $ | 1,143 |  |  | 5.2 | % |  | (5 | )% |  | $ | 1,209 |  |  | 5.5 | % |
| EBITDA | $ | 2,018 |  |  | 9.2 | % |  | (7 | )% |  | $ | 2,166 |  |  | 9.8 | % |
| Adjusted EBITDA | $ | 2,607 |  |  | 11.9 | % |  | 1 | % |  | $ | 2,573 |  |  | 11.7 | % |

[0001571996-20-000034:mdna:97]
[same as prior period, unchanged from 0001571996-19-000051:mdna:88]

[0001571996-20-000034:mdna:98]
| (a) | During Fiscal 2020, Dell Technologies made certain reclassifications of net revenue between the products and services categories on the Consolidated Statement of Net Income (Loss), which impacted previously reported amounts for the first quarter of Fiscal 2020. The Company did not recast cost of goods sold for the related revenue reclassifications due to immateriality. The reclassifications resulted in an increase to services revenue and an equal and offsetting decrease to product revenue of $179 million for the first quarter of Fiscal 2020. Total net revenue as previously reported remains unchanged. |

[0001571996-20-000034:mdna:99]
| (b) | Product gross margin percentages represent product gross margin as a percentage of product net revenue, and non-GAAP product gross margin percentages represent non-GAAP product gross margin as a percentage of non-GAAP product net revenue. |

[0001571996-20-000034:mdna:100]
| (c) | Services gross margin percentages represent services gross margin as a percentage of services net revenue, and non-GAAP services gross margin percentages represent non-GAAP services gross margin as a percentage of non-GAAP services net revenue. |

[0001571996-20-000034:mdna:101]
69

[0001571996-20-000034:mdna:102]
[same as prior period, unchanged from 0001571996-19-000051:mdna:93]

[0001571996-20-000034:mdna:103]
[same as prior period, unchanged from 0001571996-19-000051:mdna:94]

[0001571996-20-000034:mdna:104]
During the first quarter of Fiscal 2021, both our net revenue and non-GAAP net revenue remained flat, as we benefited from the strength of our broad technology solutions portfolio, which helped us navigate market volatility and competitive pressures, particularly due to the COVID-19 environment.  CSG and VMware net revenue increased, offset by a decline in ISG net revenue.  The increase in CSG net revenue was primarily driven by increased demand for work and learn from home solutions, particularly commercial notebooks.  VMware net revenue increased due to broad-based strength across the portfolio, including growth in software license revenue, new contracts and renewals of VMware enterprise agreements, maintenance contracts sold in previous periods, and additional maintenance contracts sold in conjunction with new software license sales.  ISG net revenue decreased primarily due to a weaker demand environment as customers shifted to investments in remote work solutions as part of business continuity plans.  Although we are in the midst of unprecedented uncertainty as a result of the ongoing COVID-19 pandemic, we believe we are well-positioned for long-term profitable growth while also maintaining the ability to adjust as needed to changing market conditions with complementary solutions across all segments of our business, an agile workforce, and the strength of our global supply chain.

[0001571996-20-000034:mdna:105]
During the first quarter of Fiscal 2021, our operating income increased 28% to $702 million due to an increase in operating income for VMware and a decrease in amortization of intangible assets.  These benefits were partially offset by a decrease in operating income for CSG and ISG and an increase in stock-based compensation expense.

[0001571996-20-000034:mdna:106]
Amortization of intangible assets and stock-based compensation expense that impacted our operating income totaled $1.2 billion and $1.5 billion for the first quarter of Fiscal 2021 and Fiscal 2020, respectively.  Excluding these costs, the impact of purchase accounting, transaction-related expenses, and other corporate expenses, our non-GAAP operating income was $2.2 billion during both the first quarter of Fiscal 2021 and Fiscal 2020.  Our non-GAAP operating income decreased 2 percent for the first quarter of Fiscal 2021 due to decreases in operating income for ISG and CSG, which were partially offset by increases in operating income for VMware and other businesses.

[0001571996-20-000034:mdna:107]
Cash used in operating activities was $0.8 billion for the first quarter of Fiscal 2021 compared to cash provided by operating activities of $0.7 billion for the first quarter of Fiscal 2020.  The decrease in operating cash flows during the first quarter of Fiscal 2021 was attributable to unfavorable working capital impacts related to the COVID-19 pandemic on timing of collections and higher inventory, most of which we expect to normalize by fiscal year-end.  See “Market Conditions, Liquidity, and Capital Commitments” for further information on our cash flow metrics.

[0001571996-20-000034:mdna:108]
[same as prior period, unchanged from 0001571996-19-000051:mdna:99]

[0001571996-20-000034:mdna:109]
During the first quarter of Fiscal 2021, our net revenue and non-GAAP net revenue remained flat, primarily due to increases in net revenue in CSG and VMware, which were offset by a decline in ISG net revenue.  See “Business Unit Results” for further information.

[0001571996-20-000034:mdna:110]
| • | Product Net Revenue — Product net revenue includes revenue from the sale of hardware products and software licenses. During the first quarter of Fiscal 2021, product net revenue and non-GAAP product net revenue both decreased 3% primarily due to a decrease in product net revenue for ISG. |

[0001571996-20-000034:mdna:111]
| • | Services Net Revenue — Services net revenue includes revenue from our services offerings and support services related to hardware products and software licenses. During the first quarter of Fiscal 2021, services net revenue and non-GAAP services net revenue increased 10% and 9%, respectively. These increases were primarily attributable to an increase in services revenue for hardware support and deployment and software maintenance due to growth in CSG and VMware. A substantial portion of services net revenue is derived from offerings that have been deferred over a period of time, and, as a result, reported services net revenue growth rates will be different than reported product net revenue growth rates. |

[0001571996-20-000034:mdna:112]
From a geographical perspective, net revenue generated by sales to customers in the Americas increased during the first quarter of Fiscal 2021 due to strong performance in CSG and VMware.  In EMEA, net revenue from sales to customers increased during the first quarter of Fiscal 2021 due to demand for CSG solutions.  Net revenue from sales to customers in APJ decreased during the first quarter of Fiscal 2021, primarily as the result of a weaker demand environment for CSG and ISG servers and networking, particularly in China.

[0001571996-20-000034:mdna:113]
[same as prior period, unchanged from 0001571996-19-000051:mdna:105]

[0001571996-20-000034:mdna:114]
During the first quarter of Fiscal 2021, our gross margin increased 1% to $6.9 billion, and our gross margin percentage increased 30 basis points to 31.3%.  The increases in our gross margin and gross margin percentage during the first quarter of Fiscal 2021 were primarily driven by a favorable impact of gross margin increases for VMware and our other businesses, and a decrease in amortization of intangible assets and purchase accounting adjustments.  These impacts were largely offset by decreases in gross margins for ISG and CSG.

[0001571996-20-000034:mdna:115]
Our gross margin for the first quarter of Fiscal 2021 and Fiscal 2020 included the impact of amortization of intangibles and purchase accounting adjustments of $0.4 billion and $0.6 billion, respectively.  Excluding these costs, transaction-related expenses, stock-based compensation expense, and other corporate expenses, non-GAAP gross margin decreased 1% to $7.3 billion, and non-GAAP gross margin percentage decreased 40 basis points to 33.4%.  The decreases in our non-GAAP gross margin and non-GAAP gross margin percentage were attributable to component costs that were deflationary in the aggregate for ISG and CSG (although to a lesser extent than in the first quarter of Fiscal 2020), increased supply chain costs to expedite product delivery for CSG sales in the COVID-19 environment, and a shift in product mix due to strong CSG performance.  These negative impacts were partially offset by increases in gross margin and gross margin percentage for VMware and other businesses.

[0001571996-20-000034:mdna:116]
| • | Products — During the first quarter of Fiscal 2021, product gross margin decreased 7% to $3.2 billion, and product gross margin percentage decreased 90 basis points to 20.2%. The decreases in product gross margin and product gross margin percentage were primarily driven by component costs that were deflationary in the aggregate for ISG and CSG (although to a lesser extent than in the first quarter of Fiscal 2020) and increased supply chain costs to expedite product delivery for CSG sales. These unfavorable impacts were partially offset by a decrease in amortization of intangibles. During the first quarter of Fiscal 2021, non-GAAP product gross margin decreased 10% to $3.6 billion, and non-GAAP product gross margin percentage decreased 170 basis points to 22.6% due to the same ISG and CSG dynamics discussed above. |

[0001571996-20-000034:mdna:117]
| • | Services — During the first quarter of Fiscal 2021, services gross margin increased 10% to $3.6 billion, and services gross margin percentage decreased 10 basis points to 61.8%. Services gross margin increased due to growth in VMware software maintenance and a decrease in purchase accounting adjustments. Excluding purchase accounting adjustments, transaction-related expenses, stock-based compensation expense, and other corporate expenses, non-GAAP services gross margin increased 9% to $3.7 billion primarily due to growth in VMware software maintenance. Non-GAAP services gross margin percentage decreased 20 basis points to 62.8% due to a decline in ISG services gross margin percentage, which was partially offset by an increase in VMware services gross margin percentage. |

[0001571996-20-000034:mdna:118]
[same as prior period, unchanged from 0001571996-19-000051:mdna:113]

[0001571996-20-000034:mdna:119]
[same as prior period, unchanged from 0001571996-19-000051:mdna:114]

[0001571996-20-000034:mdna:120]
The terms and conditions of our vendor rebate programs are largely based on product volumes and are generally negotiated either at the beginning of the annual or quarterly period, depending on the program.  The timing and amount of vendor rebates and other discounts we receive under the programs may vary from period to period, reflecting changes in the competitive environment.  We monitor our component costs and seek to address the effects of any changes to terms that might arise under our vendor rebate programs.  Our gross margins for the first quarter of Fiscal 2021 and Fiscal 2020 were not materially affected by any changes to the terms of our vendor rebate programs, as the amounts we received under these programs were generally stable relative to our total net cost.  We are not aware of any significant changes to vendor pricing or rebate programs that may impact our results in the near term.

[0001571996-20-000034:mdna:121]
[same as prior period, unchanged from 0001571996-19-000051:mdna:116]

[0001571996-20-000034:mdna:122]
[same as prior period, unchanged from 0001571996-19-000051:mdna:118]

[0001571996-20-000034:mdna:123]
[same as prior period, unchanged from 0001571996-19-000051:mdna:119]

[0001571996-20-000034:mdna:124]
|  | Three Months Ended |
|  | May 1, 2020 |  |  |  | May 3, 2019 |
|  | Dollars |  | % ofNet Revenue |  | %Change |  | Dollars |  | % ofNet Revenue |
|  | (in millions, except percentages) |
| Operating expenses: |  |  |  |  |  |  |  |  |  |
| Selling, general, and administrative | $ | 4,886 |  |  | 22.3 | % |  | (4 | )% |  | $ | 5,071 |  |  | 23.1 | % |
| Research and development | 1,265 |  |  | 5.8 | % |  | 8 | % |  | 1,176 |  |  | 5.4 | % |
| Total operating expenses | $ | 6,151 |  |  | 28.1 | % |  | (2 | )% |  | $ | 6,247 |  |  | 28.5 | % |
| Other Financial Information |  |  |  |  |  |  |  |  |
| Non-GAAP operating expenses | $ | 5,164 |  |  | 23.6 | % |  | (1 | )% |  | $ | 5,238 |  |  | 23.8 | % |

[0001571996-20-000034:mdna:125]
During the first quarter of Fiscal 2021, total operating expenses decreased 2% primarily due to a decrease in selling general and administrative expenses, offset partially by an increase in research and development expenses.  Our operating expenses include amortization of intangible assets, the impact of purchase accounting, transaction-related expenses, stock-based compensation expense, and other corporate expenses.  In aggregate, these items totaled $1.0 billion for both the first quarter of Fiscal 2021 and Fiscal 2020.  Excluding these costs, total non-GAAP operating expenses decreased 1% for the first quarter of Fiscal 2021.

[0001571996-20-000034:mdna:126]
| • | Selling, General, and Administrative — Selling, general, and administrative (“SG&A”) expenses decreased 4% during the first quarter of Fiscal 2021 primarily due to measures taken in March 2020 as a result of the COVID-19 pandemic which included a global hiring freeze, reduction in consulting and contractor costs, and global travel restrictions, as well as a decrease in amortization of intangibles. |

[0001571996-20-000034:mdna:127]
| • | Research and Development — Research and development (“R&D”) expenses are primarily composed of personnel-related expenses related to product development. R&D expenses as a percentage of net revenue were approximately 5.8% and 5.4% for the first quarter of Fiscal 2021 and Fiscal 2020, respectively. R&D expenses as a percentage of net revenue increased during the first quarter of Fiscal 2021 primarily due to an increase in compensation-related expense, including stock-based compensation expense, driven by VMware. As our industry continues to change and as the needs of our customers evolve, we intend to support R&D initiatives to innovate and introduce new and enhanced solutions into the market. |

[0001571996-20-000034:mdna:128]
We continue to make selective investments designed to enable growth, marketing, and R&D, while balancing our efforts to drive cost efficiencies in the business.  We also expect to continue to make investments in support of our own digital transformation to modernize and streamline our IT operations.

[0001571996-20-000034:mdna:129]
Operating Income

[0001571996-20-000034:mdna:130]
During the first quarter of Fiscal 2021, our operating income increased 28% to $702 million.  The increase in our operating income for the first quarter of Fiscal 2021 was primarily attributable to an increase in operating income for VMware and a decrease in amortization of intangible assets.  These benefits were partially offset by a decrease in operating income for CSG and ISG and an increase in stock-based compensation expense.

[0001571996-20-000034:mdna:131]
Amortization of intangible assets and stock-based compensation expense that impacted our operating income totaled $1.2 billion and $1.5 billion for the first quarter of Fiscal 2021 and Fiscal 2020, respectively.  Excluding these costs, the impact of

[0001571996-20-000034:mdna:132]
purchase accounting, transaction-related expenses, and other corporate expenses, our non-GAAP operating income decreased 2% to $2.2 billion during the first quarter of Fiscal 2021.  The decrease in our non-GAAP operating income for the first quarter of Fiscal 2021 was primarily due to decreases in operating income for ISG and CSG, which were partially offset by increases in operating income for VMware and other businesses.

[0001571996-20-000034:mdna:133]
[same as prior period, unchanged from 0001571996-19-000051:mdna:130]

[0001571996-20-000034:mdna:134]
[same as prior period, unchanged from 0001571996-19-000051:mdna:131]

[0001571996-20-000034:mdna:135]
|  | Three Months Ended |
|  | May 1, 2020 |  | May 3, 2019 |
|  | (in millions) |
| Interest and other, net: |  |  |  |  |  |
| Investment income, primarily interest | $ | 24 |  |  | $ | 44 |  |
| Gain on investments, net | 94 |  |  | 62 |  |
| Interest expense | (672 | ) |  | (699 | ) |
| Foreign exchange | (99 | ) |  | (45 | ) |
| Other | 87 |  |  | (55 | ) |
| Total interest and other, net | $ | (566 | ) |  | $ | (693 | ) |

[0001571996-20-000034:mdna:136]
During the first quarter of Fiscal 2021, the change in interest and other, net was favorable by $127 million, primarily due a gain of $120 million recognized from the sale of certain intellectual property assets.

[0001571996-20-000034:mdna:137]
[same as prior period, unchanged from 0001571996-19-000051:mdna:134]

[0001571996-20-000034:mdna:138]
For the first quarter of Fiscal 2021, our effective income tax rate was -33.8% on pre-tax income of $136 million.  For the first quarter of Fiscal 2020, our effective income tax rate was 330.1% on pre-tax losses of $143 million.  The change in our effective tax rate was primarily driven by discrete tax items and a change in our jurisdictional mix of income.  Our effective tax rates include discrete tax benefits of $59 million and $405 million resulting from intra-entity asset transfers of certain of our intellectual property to Irish subsidiaries for the first quarter of Fiscal 2021 and Fiscal 2020, respectively.  The tax benefit for each intra-entity asset transfer was recorded as a deferred tax asset in the period of transaction and represents the book and tax basis difference on the transferred assets measured based on the applicable Irish statutory tax rate.  We applied significant judgment when determining the fair value of the intellectual property, which serves as the tax basis of the deferred tax asset, and in evaluating the associated tax laws in the applicable jurisdictions.  The tax deductions for amortization of the assets will be recognized in the future, and any amortization not deducted for tax purposes will be carried forward indefinitely under Irish tax laws.  We expect to be able to realize the deferred tax assets resulting from these intra-entity asset transfers.

[0001571996-20-000034:mdna:139]
Our effective income tax rate can fluctuate depending on the geographic distribution of our worldwide earnings, as our foreign earnings are generally taxed at lower rates than in the United States.  The differences between our effective income tax rate and the U.S. federal statutory rate of 21% principally result from the geographical distribution of income, differences between the book and tax treatment of certain items, and the discrete tax items discussed above.  In certain jurisdictions, our tax rate is significantly less than the applicable statutory rate as a result of tax holidays.  The majority of our foreign income that is subject to these tax holidays and lower tax rates is attributable to Singapore, China, and Malaysia.  A significant portion of these income tax benefits relates to a tax holiday that will be effective until January 31, 2029.  Our other tax holidays will expire in whole or in part during Fiscal 2022 through Fiscal 2030.  Many of these tax holidays and reduced tax rates may be extended when certain conditions are met or may be terminated early if certain conditions are not met.  As of May 1, 2020, we were not aware of any matters of non-compliance related to these tax holidays.  The effective income tax rate for future quarters of Fiscal 2021 may be impacted by the actual mix of jurisdictions in which income is generated.

[0001571996-20-000034:mdna:140]
[same as prior period, unchanged from 0001571996-19-000051:mdna:139]

[0001571996-20-000034:mdna:141]
Net Income

[0001571996-20-000034:mdna:142]
During the first quarter of Fiscal 2021, net income decreased 45% to $182 million.  The decrease in net income during the first quarter of Fiscal 2021 was primarily due lower discrete tax benefits, which were partially offset by an increase in operating income and a decrease in interest and other, net.

[0001571996-20-000034:mdna:143]
Net income for the first quarter of Fiscal 2021 and Fiscal 2020 included amortization of intangible assets, the impact of purchase accounting, transaction-related expenses, stock-based compensation expense, other corporate expenses, fair value adjustments on equity investments, and discrete tax items.  Excluding these costs and the related tax impacts, non-GAAP net income decreased 5% to $1.1 billion.  The decrease in non-GAAP net income during the first quarter of Fiscal 2021 was primarily attributable to a decrease in non-GAAP operating income and an increase in non-GAAP interest and other, net.

[0001571996-20-000034:mdna:144]
[same as prior period, unchanged from 0001571996-19-000051:mdna:144]

[0001571996-20-000034:mdna:145]
During the first quarter of Fiscal 2021, net income or loss attributable to non-controlling interests consisted of net income or loss attributable to our non-controlling interests in VMware, Inc. and Secureworks.  During the first quarter of Fiscal 2020, net income or loss attributable to non-controlling interests consisted of net income or loss attributable to our non-controlling interests in VMware, Inc., Secureworks, and Pivotal.  Pivotal was acquired by VMware on December 30, 2019 and, as a result, we no longer have a separate non-controlling interest in Pivotal.

[0001571996-20-000034:mdna:146]
During the first quarter of Fiscal 2021 and Fiscal 2020, net income attributable to non-controlling interests was $39 million and $36 million, respectively.  The increase in net income attributable to non-controlling interests during the first quarter of Fiscal 2021 was attributable to an increase in net income attributable to our non-controlling interest in VMware, Inc.  For more information about our non-controlling interests, see Note 13 of the Notes to the Condensed Consolidated Financial Statements included in this report.

[0001571996-20-000034:mdna:147]
Net Income Attributable to Dell Technologies Inc.

[0001571996-20-000034:mdna:148]
Net income attributable to Dell Technologies Inc. represents net income and an adjustment for non-controlling interests.  During the first quarter of Fiscal 2021 and Fiscal 2020, net income attributable to Dell Technologies Inc. was $143 million and $293 million, respectively.  The decrease in net income attributable to Dell Technologies Inc. during the first quarter of Fiscal 2021 was primarily attributable to the decrease in net income for the period.

[0001571996-20-000034:mdna:149]
[same as prior period, unchanged from 0001571996-19-000051:mdna:149]

[0001571996-20-000034:mdna:150]
Our reportable segments are based on the following business units: ISG, CSG, and VMware.  A description of our three business units is provided under “Introduction.”  See Note 17 of the Notes to the Condensed Consolidated Financial Statements included in this report for a reconciliation of net revenue and operating income by reportable segment to consolidated net revenue and consolidated operating income, respectively.

[0001571996-20-000034:mdna:151]
[same as prior period, unchanged from 0001571996-19-000051:mdna:151]

[0001571996-20-000034:mdna:152]
[same as prior period, unchanged from 0001571996-19-000051:mdna:152]

[0001571996-20-000034:mdna:153]
|  | Three Months Ended |
|  | May 1, 2020 |  | % Change |  | May 3, 2019 |
|  | (in millions, except percentages) |
| Net revenue: |  |  |  |  |  |
| Servers and networking | $ | 3,758 |  |  | (10 | )% |  | $ | 4,180 |  |
| Storage | 3,811 |  |  | (5 | )% |  | 4,022 |  |
| Total ISG net revenue | $ | 7,569 |  |  | (8 | )% |  | $ | 8,202 |  |
| Operating income: |  |  |  |  |  |
| ISG operating income | $ | 732 |  |  | (13 | )% |  | $ | 843 |  |
| % of segment net revenue | 9.7 | % |  |  |  | 10.3 | % |

[0001571996-20-000034:mdna:154]
Net Revenue — During the first quarter of Fiscal 2021, ISG net revenue decreased 8% due to decreases in sales of servers and networking and storage.  ISG net revenue decreased primarily due to a weaker demand environment, as customers shifted to investments in remote work solutions as part of business continuity plans.  Revenue from the sales of servers and networking decreased 10% during the first quarter of Fiscal 2021, primarily driven by a decline in units sold of our PowerEdge servers due to a weaker demand environment, particularly in China, and a decrease in average selling prices for servers resulting from competitive pressures in certain geographies.  Storage revenue decreased 5% during the first quarter of Fiscal 2021 primarily due to a decline in demand.  We continue to make enhancements to our storage solutions offerings and expect that these offerings, including the release of our new PowerStore storage array in May 2020, will drive long-term improvements in the business.

[0001571996-20-000034:mdna:155]
ISG customers are interested in new and innovative models that address how they consume our solutions.  We offer options including as-a-service, utility, leases, and immediate pay models, all designed to match customers’ consumption and financing preferences.  Our multi-year agreements typically result in recurring revenue streams over the term of the arrangement.  We expect our flexible consumption models will further strengthen our customer relationships and provide a foundation for growth in recurring revenue.

[0001571996-20-000034:mdna:156]
From a geographical perspective, net revenue attributable to ISG decreased in all regions during the first quarter of Fiscal 2021, with the largest decline in EMEA, driven by a weaker demand environment as a result of pervasive global COVID-19 disruptions, which persisted for the majority of the quarter.

[0001571996-20-000034:mdna:157]
Operating Income — During the first quarter of Fiscal 2021, ISG operating income as a percentage of net revenue decreased 60 basis points to 9.7% primarily driven by weakness in gross margin for servers and networking due to competitive pricing dynamics.  The decline in gross margin percentage during the first quarter of Fiscal 2021 was also attributable to component costs that were deflationary in the aggregate for ISG, although to a lesser extent than in the first quarter of Fiscal 2020.  For the remaining nine months of Fiscal 2021, we currently expect an inflationary component cost environment, which may put pressure on ISG operating results, particularly from sales of servers and networking.  We will continue to monitor our pricing in response to the changing competitive and cost environment.

[0001571996-20-000034:mdna:158]
[same as prior period, unchanged from 0001571996-19-000051:mdna:159]

[0001571996-20-000034:mdna:159]
[same as prior period, unchanged from 0001571996-19-000051:mdna:160]

[0001571996-20-000034:mdna:160]
|  | Three Months Ended |
|  | May 1, 2020 |  | % Change |  | May 3, 2019 |
|  | (in millions, except percentages) |
| Net revenue: |  |  |  |  |  |
| Commercial | $ | 8,634 |  |  | 4 | % |  | $ | 8,307 |  |
| Consumer | 2,470 |  |  | (5 | )% |  | 2,603 |  |
| Total CSG net revenue | $ | 11,104 |  |  | 2 | % |  | $ | 10,910 |  |
| Operating income: |  |  |  |  |  |
| CSG operating income | $ | 592 |  |  | (25 | )% |  | $ | 793 |  |
| % of segment net revenue | 5.3 | % |  |  |  | 7.3 | % |

[0001571996-20-000034:mdna:161]
Net Revenue — During the first quarter of Fiscal 2021, CSG net revenue increased 2% due to an increase in commercial sales, partially offset by a decrease in consumer sales.  Commercial revenue increased 4% during the first quarter of Fiscal 2021 primarily due to increased demand from large commercial and governmental customers for work and learn from home solutions, particularly driving strong demand for commercial notebooks.  Consumer revenue decreased 5% during the first quarter of Fiscal 2021 due to lower consumer demand, particularly in retail, as a result of the COVID-19 market disruption.

[0001571996-20-000034:mdna:162]
From a geographical perspective, net revenue attributable to CSG increased in the Americas and EMEA during the first quarter of Fiscal 2021.  In APJ, particularly in China, net revenue decreased during the first quarter of Fiscal 2021.

[0001571996-20-000034:mdna:163]
Operating Income — During the first quarter of Fiscal 2021, CSG operating income as a percentage of net revenue decreased 200 basis points to 5.3%.  The decrease was primarily due to a decrease in CSG gross margin percentage, which was principally driven by increased supply chain costs to expedite delivery of certain products to meet strong demand in this environment, as well as by competitive pricing dynamics.  Also impacting the decrease in gross margin percentage, the aggregate CSG component cost environment was deflationary in the first quarter of Fiscal 2021, although to a lesser extent than in the first quarter of Fiscal 2020.  We expect an inflationary component cost environment in the remaining nine months of Fiscal 2021, which will put pressure on CSG operating results.  We will continue to monitor our pricing in response to the changing competitive and component cost environment.

[0001571996-20-000034:mdna:164]
[same as prior period, unchanged from 0001571996-19-000051:mdna:66]

[0001571996-20-000034:mdna:165]
[same as prior period, unchanged from 0001571996-19-000051:mdna:167]

[0001571996-20-000034:mdna:166]
The following table presents net revenue and operating income attributable to VMware for the periods indicated.  During Fiscal 2020, the Company reclassified Pivotal operating results from other businesses to the VMware reportable segment.  Prior period results have been recast to conform with the current period presentation.

[0001571996-20-000034:mdna:167]
|  | Three Months Ended |
|  | May 1, 2020 |  | % Change |  | May 3, 2019 |
|  | (in millions, except percentages) |
| Net revenue: |  |  |  |  |  |
| VMware net revenue | $ | 2,755 |  |  | 12 | % |  | $ | 2,457 |  |
| Operating income: |  |  |  |  |  |
| VMware operating income | $ | 773 |  |  | 30 | % |  | $ | 595 |  |
| % of segment net revenue | 28.1 | % |  |  |  | 24.2 | % |

[0001571996-20-000034:mdna:168]
Net Revenue — VMware net revenue, inclusive of Pivotal, primarily consists of revenue from the sale of software licenses under perpetual licenses and subscription and software-as-a-service (“SaaS”) offerings, as well as related software maintenance services, support, training, consulting services, and hosted services.  VMware net revenue for the first quarter of Fiscal 2021 increased 12% primarily due to growth in sales of subscriptions and SaaS, as well as an increase in sales of software maintenance services.  Software maintenance revenue benefited from new contracts and renewals of VMware enterprise agreements, revenue recognized from maintenance contracts sold in prior periods, and additional maintenance contracts sold in conjunction with new software license sales.

[0001571996-20-000034:mdna:169]
From a geographical perspective, approximately half of VMware net revenue during the first quarter of Fiscal 2021 was generated by sales to customers in the United States.  VMware net revenue for the first quarter of Fiscal 2021 increased in both the United States and internationally.

[0001571996-20-000034:mdna:170]
Operating Income — During the first quarter of Fiscal 2021, VMware operating income as a percentage of net revenue increased 390 basis points to 28.1%.  The increase was driven by an increase in gross margin as a percentage of net revenue. During the first quarter of Fiscal 2021, VMware net revenue growth outpaced increased operating expenses, particularly R&D compensation-related expenses resulting from acquisitions and additional investments.  While the COVID-19 pandemic has not had a significant adverse financial impact on VMware operations to date, in future periods we expect a negative impact on VMware results of operations, the size and duration of which we are currently unable to predict.

[0001571996-20-000034:mdna:171]
[same as prior period, unchanged from 0001571996-19-000051:mdna:174]

[0001571996-20-000034:mdna:172]
[same as prior period, unchanged from 0001571996-19-000051:mdna:175]

[0001571996-20-000034:mdna:173]
We sell products and services directly to customers and through a variety of sales channels, including retail distribution.  Our accounts receivable, net, was $10.8 billion and $12.5 billion as of May 1, 2020 and January 31, 2020, respectively.  We maintain an allowance for expected credit losses to cover receivables that may be deemed uncollectible.  The allowance for expected credit losses is an estimate based on an analysis of historical loss experience, current receivables aging, and management’s assessment of current conditions and reasonable and supportable expectation of future conditions, as well as specific identifiable customer accounts that are deemed at risk.  Our analysis includes assumptions regarding the impact of COVID-19 and continued market volatility, which is highly uncertain and subject to significant judgment.  Given this uncertainty, our allowance for expected credit losses in future periods may vary from our current estimates.  As of May 1, 2020 and January 31, 2020, the allowance for expected credit losses was $144 million and $94 million, respectively.  Allowance for expected credit losses of trade receivables as of May 1, 2020 includes the impact of adoption of the new current expected credit losses (“CECL”) standard, which was adopted as of February 1, 2020 using the modified retrospective method.  Based on our assessment, we believe that we are adequately reserved for expected credit losses.  We will continue to monitor the aging of our accounts receivable and take actions, where necessary, to reduce our exposure to credit losses.

[0001571996-20-000034:mdna:174]
[same as prior period, unchanged from 0001571996-19-000051:mdna:177]

[0001571996-20-000034:mdna:175]
Dell Financial Services and its affiliates (“DFS”) support Dell Technologies by offering and arranging various financing options and services for our customers globally, including through captive financing operations in North America, Europe, Australia, and New Zealand.  DFS originates, collects, and services customer receivables primarily related to the purchase of our product, software, and service solutions.  DFS further strengthens our customer relationships through its flexible consumption models, which enable us to offer our customers the option to pay over time and, in certain cases, based on utilization, to provide them with financial flexibility to meet their changing technological requirements.  New financing originations were $1.8 billion and $1.7 billion for the first quarter of Fiscal 2021 and Fiscal 2020, respectively.  In response to the COVID-19 pandemic, we are focused on supporting our customers and intend to provide up to $9 billion in financing support by offering low or zero percent interest rate programs as well as payment deferral options.  The financial impact to DFS and our securitization and structured  financing programs is not expected to be material.

[0001571996-20-000034:mdna:176]
Pursuant to the current lease accounting standard effective February 2, 2019, new DFS leases are classified as sales-type leases, direct financing leases, or operating leases.  Amounts due from lessees under sales-type leases or direct financing leases are recorded as part of financing receivables, with interest income recognized over the contract term.  On commencement of sales-type leases, we typically qualify for up-front revenue recognition.  On originations of operating leases, we record equipment under operating leases, classified as property, plant, and equipment, and recognize rental revenue and depreciation expense, classified as cost of net revenue, over the contract term.  Direct financing leases are immaterial.  Leases that commenced prior to the effective date of the current lease accounting standard continue to be accounted for under previous lease accounting guidance.

[0001571996-20-000034:mdna:177]
As of May 1, 2020 and January 31, 2020, our financing receivables, net were $9.5 billion and $9.7 billion, respectively.  We maintain an allowance to cover expected financing receivable credit losses and evaluate credit loss expectations based on our total portfolio.  Allowance for expected credit losses of financing receivables as of May 1, 2020 includes the impact of adoption of the CECL standard referred to above.  Our analysis includes assumptions regarding the impact of COVID-19 and continued market volatility, which is highly uncertain and subject to significant judgment.  Given this uncertainty, our allowance for expected credit losses in future periods may vary from our current estimates.  For both the first quarter of Fiscal 2021 and Fiscal 2020, the principal charge-off rate for our total portfolio was 1.0%.  The credit quality of our financing receivables has improved in recent years due to an overall improvement in the credit environment and as the mix of high-quality commercial accounts in our portfolio has continued to increase.  We continue to monitor broader economic indicators and their potential impact on future loss performance.  We have an extensive process to manage our exposure to customer credit risk, including active management of credit lines and our collection activities.  We also sell selected fixed-term financing receivables without recourse to unrelated third parties on a periodic basis, primarily to manage certain concentrations of customer credit exposure.  Based on our assessment of the customer financing receivables, we believe that we are adequately reserved.

[0001571996-20-000034:mdna:178]
[same as prior period, unchanged from 0001571996-19-000051:mdna:72]

[0001571996-20-000034:mdna:179]
We retain a residual interest in equipment leased under our lease programs.  As of May 1, 2020 and January 31, 2020, the residual interest recorded as part of financing receivables was $551 million and $582 million, respectively.  The amount of the residual interest is established at the inception of the lease based upon estimates of the value of the equipment at the end of the lease term using historical studies, industry data, and future value-at-risk demand valuation methods.  On a quarterly basis, we assess the carrying amount of our recorded residual values for impairment.  Generally, residual value risk on equipment under lease is not considered to be significant, because of the existence of a secondary market with respect to the equipment.  The lease agreement also clearly defines applicable return conditions and remedies for non-compliance, to ensure that the leased equipment will be in good operating condition upon return.  Model changes and updates, as well as market strength and product acceptance, are monitored and adjustments are made to residual values in accordance with the significance of any such changes.  Our remarketing sales staff works closely with customers and dealers to manage the sale of lease returns and the recovery of residual exposure.  No impairment losses were recorded related to residual assets during the first quarter of Fiscal 2021.

[0001571996-20-000034:mdna:180]
As of May 1, 2020 and January 31, 2020, equipment under operating leases, net was $975 million and $840 million, respectively.  Based on triggering events, we assess the carrying amount of the equipment under operating leases recorded for impairment.  No material impairment losses were recorded related to such equipment during the first quarter of Fiscal 2021.

[0001571996-20-000034:mdna:181]
DFS offerings are initially funded through cash on hand at the time of origination, most of which is subsequently replaced with third-party financing.  For DFS offerings which qualify as sales-type leases, the initial funding of financing receivables is reflected as an impact to cash flows from operations, and is largely subsequently offset by cash proceeds from financing.  For DFS operating leases, which have increased under the current lease standard, the initial funding is classified as a capital expenditure and reflected as an impact to cash flows used in investing activities.

[0001571996-20-000034:mdna:182]
See Note 4 of the Notes to the Condensed Consolidated Financial Statements included in this report for additional information about our financing receivables and the associated allowances, and the equipment under operating leases.

[0001571996-20-000034:mdna:183]
[same as prior period, unchanged from 0001571996-19-000051:mdna:186]

[0001571996-20-000034:mdna:184]
As of May 1, 2020, we had no off-balance sheet arrangements that have or are reasonably likely to have a current or future material effect on our financial condition or results of operations.

[0001571996-20-000034:mdna:185]
[same as prior period, unchanged from 0001571996-19-000051:mdna:188]

[0001571996-20-000034:mdna:186]
[same as prior period, unchanged from 0001571996-19-000051:mdna:189]

[0001571996-20-000034:mdna:187]
[same as prior period, unchanged from 0001571996-19-000051:mdna:190]

[0001571996-20-000034:mdna:188]
[same as prior period, unchanged from 0001571996-19-000051:mdna:191]

[0001571996-20-000034:mdna:189]
[same as prior period, unchanged from 0001571996-19-000051:mdna:192]

[0001571996-20-000034:mdna:190]
[same as prior period, unchanged from 0001571996-19-000051:mdna:193]

[0001571996-20-000034:mdna:191]
[same as prior period, unchanged from 0001571996-19-000051:mdna:194]

[0001571996-20-000034:mdna:192]
[same as prior period, unchanged from 0001571996-19-000051:mdna:195]

[0001571996-20-000034:mdna:193]
To support our ongoing business operations, we rely on operating cash flows as our primary source of liquidity.  We monitor the efficiency of our balance sheet to ensure that we have adequate liquidity to support our strategic initiatives.  In addition to internally generated cash, we have access to other capital sources to finance our strategic initiatives and fund growth in our financing operations.  Our strategy is to deploy capital from any potential source, whether internally generated cash or debt, depending on the adequacy and availability of that source of capital and whether it can be accessed in a cost-effective manner.

[0001571996-20-000034:mdna:194]
In this unprecedented environment resulting from the COVID-19 pandemic, we are taking actions to increase our cash position and preserve financial flexibility.  In March 2020, as previously reported, we drew $3.0 billion under the Revolving Credit Facility as a precautionary measure given the uncertainty in the global markets, which we repaid during the quarter.  Additionally, we accessed the debt markets in the first quarter of Fiscal 2021, in which we issued $2.25 billion aggregate principal amount of First Lien Notes and VMware, Inc. issued $2.0 billion aggregate principal amount of senior notes.  The proceeds from the issuance of these notes are expected to be used for general corporate purposes, including planned repayment of upcoming debt maturities.  Subsequent to the first quarter of Fiscal 2021, VMware, Inc. repaid $1.25 billion principal amount of its 2.30% Notes due August 2020.

[0001571996-20-000034:mdna:195]
The following table presents our cash and cash equivalents as well as our available borrowings as of the dates indicated:

[0001571996-20-000034:mdna:196]
|  | May 1, 2020 |  | January 31, 2020 |
|  | (in millions) |
| Cash and cash equivalents, and available borrowings: |  |  |  |
| Cash and cash equivalents (a) | $ | 12,229 |  |  | $ | 9,302 |  |
| Remaining available borrowings under revolving credit facilities | 5,472 |  |  | 5,972 |  |
| Total cash, cash equivalents, and available borrowings | $ | 17,701 |  |  | $ | 15,274 |  |

[0001571996-20-000034:mdna:197]
[same as prior period, unchanged from 0001571996-19-000051:mdna:203]

[0001571996-20-000034:mdna:198]
| (a) | Of the $12.2 billion of cash and cash equivalents as of May 1, 2020, $5.9 billion was held by VMware, Inc. |

[0001571996-20-000034:mdna:199]
Our revolving credit facilities as of May 1, 2020 include the Revolving Credit Facility.  The Revolving Credit Facility has a maximum aggregate borrowing capacity of $4.5 billion.  Available borrowings under this facility are reduced by draws on the facility and outstanding letters of credit.  As of May 1, 2020, there were no borrowings outstanding under the facility and remaining available borrowings totaled approximately $4.5 billion.  Subsequent to the first quarter of Fiscal 2021 on May 25, 2020, we entered into a new revolving credit facility for China (the “China Revolving Credit Facility”).  The new terms provide for collateralized and non-collateralized principal amounts not to exceed $1.0 billion Chinese renminbi and $1.8 billion Chinese renminbi, respectively, or equivalent amounts in U.S. dollars.  We may regularly use our available borrowings from both our Revolving Credit Facility and our China Revolving Credit Facility on a short-term basis for general corporate purposes.  See Note 19 of the Notes to the Condensed Consolidated Financial Statements included in this report for additional information about the new China Revolving Credit Facility.

[0001571996-20-000034:mdna:200]
The VMware Revolving Credit Facility has a maximum capacity of $1.0 billion.  As of May 1, 2020, $1.0 billion was available under the VMware Revolving Credit Facility.  The VMware Term Loan Facility had a borrowing capacity of up to $2.0 billion through February 7, 2020.  As of May 1, 2020, the outstanding borrowings under the VMware Term Loan Facility were $1.5 billion, with no remaining amount available for additional borrowings.  None of the net proceeds of borrowings under the VMware Revolving Credit Facility or the VMware Term Loan Facility will be made available to support the operations or satisfy any corporate purposes of Dell Technologies, other than the operations and corporate purposes of VMware, Inc. and VMware, Inc.’s subsidiaries.

[0001571996-20-000034:mdna:201]
[same as prior period, unchanged from 0001571996-19-000051:mdna:208]

[0001571996-20-000034:mdna:202]
We believe that our current cash and cash equivalents, together with cash that will be provided by future operations and borrowings expected to be available under our revolving credit facilities, will be sufficient over at least the next twelve months to fund our operations, debt service requirements and maturities, capital expenditures, share repurchases, and other corporate needs.

[0001571996-20-000034:mdna:203]
[same as prior period, unchanged from 0001571996-19-000051:mdna:210]

[0001571996-20-000034:mdna:204]
[same as prior period, unchanged from 0001571996-19-000051:mdna:211]

[0001571996-20-000034:mdna:205]
|  | May 1, 2020 |  | Increase (decrease) |  | January 31, 2020 |
|  | (in millions) |
| Core debt |  |  |  |  |  |
| Senior Secured Credit Facilities and First Lien Notes | $ | 31,857 |  |  | $ | 2,193 |  |  | $ | 29,664 |  |
| Unsecured Notes and Debentures | 1,352 |  |  | — |  |  | 1,352 |  |
| Senior Notes | 2,700 |  |  | — |  |  | 2,700 |  |
| EMC Notes | 1,600 |  |  | — |  |  | 1,600 |  |
| DFS allocated debt | (863 | ) |  | 632 |  |  | (1,495 | ) |
| Total core debt | 36,646 |  |  | 2,825 |  |  | 33,821 |  |
| DFS related debt |  |  |  |  |  |
| DFS debt | 8,269 |  |  | 504 |  |  | 7,765 |  |
| DFS allocated debt | 863 |  |  | (632 | ) |  | 1,495 |  |
| Total DFS related debt | 9,132 |  |  | (128 | ) |  | 9,260 |  |
| Margin Loan Facility and other | 4,014 |  |  | (10 | ) |  | 4,024 |  |
| Debt of public subsidiary |  |  |  |  |  |
| VMware Notes | 6,000 |  |  | 2,000 |  |  | 4,000 |  |
| VMware Term Loan Facility | 1,500 |  |  | — |  |  | 1,500 |  |
| Other | 55 |  |  | (5 | ) |  | 60 |  |
| Total public subsidiary debt | 7,555 |  |  | 1,995 |  |  | 5,560 |  |
| Total debt, principal amount | 57,347 |  |  | 4,682 |  |  | 52,665 |  |
| Carrying value adjustments | (619 | ) |  | (10 | ) |  | (609 | ) |
| Total debt, carrying value | $ | 56,728 |  |  | $ | 4,672 |  |  | $ | 52,056 |  |

[0001571996-20-000034:mdna:206]
During the first quarter of Fiscal 2021, the outstanding principal amount of our debt increased by $4.7 billion to $57.3 billion as of May 1, 2020.

[0001571996-20-000034:mdna:207]
During the first quarter of Fiscal 2021, our core debt increased by $2.8 billion to $36.6 billion as of May 1, 2020.  We define core debt as the total principal amount of our debt, less DFS related debt, our Margin Loan Facility and other debt, and public subsidiary debt.  The increase in core debt was primarily due to the issuance of multiple series of First Lien Notes in an aggregate principal amount of $2.25 billion on April 9, 2020.  See Note 6 of the Notes to the Condensed Consolidated Financial Statements included in this report for more information about our debt.  The change in DFS allocated debt also contributed to the increase, and is discussed further below.

[0001571996-20-000034:mdna:208]
During the first quarter of Fiscal 2021, we issued an additional $0.5 billion, net, in DFS debt to support the expansion of our financing receivables portfolio.  DFS related debt primarily represents debt from our securitization and structured financing programs.  The majority of DFS debt is non-recourse to Dell Technologies and represents borrowings under securitization programs and structured financing programs, for which our risk of loss is limited to transferred lease and loan payments and associated equipment, and under which the credit holders have no recourse to Dell Technologies.

[0001571996-20-000034:mdna:209]
To fund expansion of the DFS business, we balance the use of the securitization and structured financing programs with other sources of liquidity.  We approximate the amount of our debt used to fund the DFS business by applying a 7:1 debt to equity ratio to the sum of our financing receivables balance and equipment under our DFS operating leases, net.  The debt to equity ratio used is based on the underlying credit quality of the assets.  See Note 4 of the Notes to the Condensed Consolidated Financial Statements included in this report for more information about our DFS debt.

[0001571996-20-000034:mdna:210]
As of May 1, 2020, margin loan and other debt primarily consisted of the $4.0 billion Margin Loan Facility.

[0001571996-20-000034:mdna:211]
[same as prior period, unchanged from 0001571996-19-000051:mdna:110]

[0001571996-20-000034:mdna:212]
Debt of public subsidiary represents VMware, Inc. indebtedness.  The increase in debt of public subsidiary during the first quarter of Fiscal 2021 was due to the issuance of VMware Notes in an aggregate principal amount of $2.0 billion on April 7, 2020.  See Note 6 of the Notes to the Condensed Consolidated Financial Statements included in this report for more information about VMware, Inc. debt.

[0001571996-20-000034:mdna:213]
VMware, Inc. and its respective subsidiaries are unrestricted subsidiaries for purposes of the core debt of Dell Technologies.  Neither Dell Technologies nor any of its subsidiaries, other than VMware, Inc., is obligated to make payment on the VMware Notes or the VMware Term Loan Facility.  None of the net proceeds of the VMware Notes or, as discussed above, the VMware Term Loan Facility will be made available to support the operations or satisfy any corporate purposes of Dell Technologies, other than the operations and corporate purposes of VMware, Inc. and its subsidiaries.

[0001571996-20-000034:mdna:214]
Our requirements for cash to pay principal and interest on our core debt increased significantly due to the borrowings we incurred to finance the EMC merger transaction and, to a lesser extent, the Class V transaction.  We have made good progress in paying down core debt since the EMC merger transaction.  We believe we will continue to be able to make our debt principal and interest payments, including the short-term maturities, from existing and expected sources of cash, primarily from operating cash flows.  Cash used for debt principal and interest payments may also include short-term borrowings under our revolving credit facilities.  We will continue to focus on paying down core debt.  Under our variable-rate debt, we could have variations in our future interest expense from potential fluctuations in LIBOR, or from possible fluctuations in the level of DFS debt required to meet future demand for customer financing.

[0001571996-20-000034:mdna:215]
We or our affiliates or their related persons, at our or their sole discretion, may purchase, redeem, prepay, refinance, or otherwise retire any amount of our outstanding indebtedness under the terms of such indebtedness at any time and from time to time, in open market or negotiated transactions with the holders of such indebtedness or otherwise, as appropriate market conditions exist.

[0001571996-20-000034:mdna:216]
[same as prior period, unchanged from 0001571996-19-000051:mdna:220]

[0001571996-20-000034:mdna:217]
The following table presents a summary of our Condensed Consolidated Statements of Cash Flows for the periods indicated:

[0001571996-20-000034:mdna:218]
|  | Three Months Ended |
|  | May 1, 2020 |  | May 3, 2019 |
|  | (in millions) |
| Net change in cash from: |  |  |  |
| Operating activities | $ | (796 | ) |  | $ | 682 |  |
| Investing activities | (485 | ) |  | (458 | ) |
| Financing activities | 4,264 |  |  | (719 | ) |
| Effect of exchange rate changes on cash, cash equivalents, and restricted cash | (136 | ) |  | (36 | ) |
| Change in cash, cash equivalents, and restricted cash | $ | 2,847 |  |  | $ | (531 | ) |

[0001571996-20-000034:mdna:219]
Operating Activities — Cash used in operating activities was $0.8 billion for the first quarter of Fiscal 2021 compared to cash provided by operating activities of $0.7 billion for the first quarter of Fiscal 2020.  The decrease in operating cash flows during the first quarter of Fiscal 2021 was attributable to unfavorable working capital impacts related to the COVID-19 pandemic on timing of collections and maintenance of higher inventory levels for continuity of supply, most of which we expect to normalize by fiscal year-end.

[0001571996-20-000034:mdna:220]
Cash flow from operating activities during the first quarter of the fiscal year is typically lower due to parts of Dell Technologies’ business being subject to seasonal sales trends as well as timing of annual personnel-related payments.

[0001571996-20-000034:mdna:221]
DFS offerings are initially funded through cash on hand at the time of origination, most of which is subsequently replaced with third-party financing.  For DFS offerings which qualify as sales-type leases, the initial funding of financing receivables is reflected as an impact to cash flows from operations, and is largely subsequently offset by cash proceeds from financing.  For DFS operating leases, which have increased under the current leasing standard, the initial funding is classified as a capital expenditure and reflected as cash flows used in investing activities.  DFS new financing originations were $1.8 billion and $1.7 billion during the first quarter of Fiscal 2021 and Fiscal 2020, respectively.  As of May 1, 2020, DFS had $9.5 billion of total net financing receivables and $1.0 billion of equipment under DFS operating leases, net.

[0001571996-20-000034:mdna:222]
[same as prior period, unchanged from 0001571996-19-000051:mdna:117]

[0001571996-20-000034:mdna:223]
Investing Activities — Investing activities primarily consist of cash used to fund capital expenditures for property, plant, and equipment, which includes equipment under DFS operating leases, capitalized software development costs, strategic investments, and the maturities, sales, and purchases of investments.  During the first quarter of Fiscal 2021, cash used in investing activities was $485 million and was primarily driven by capital expenditures, which were partially offset by net cash proceeds from the sale of certain intellectual property assets.  In comparison, cash used by investing activities was $458 million during the first quarter of Fiscal 2020 and was primarily driven by capital expenditures, which were partially offset by net cash proceeds from the net sales of strategic investments.

[0001571996-20-000034:mdna:224]
Financing Activities — Financing activities primarily consist of the proceeds and repayments of debt, cash used to repurchase common stock, and proceeds from the issuance of common stock.  Cash provided by financing activities of $4.3 billion during the first quarter of Fiscal 2021 primarily consisted of cash proceeds from the issuances of multiple series of First Lien Notes in an aggregate principal amount of $2.25 billion and VMware Notes in an aggregate principal amount of $2.0 billion, as discussed above.  In comparison, cash used by financing activities of $719 million during the first quarter of Fiscal 2020 primarily consisted of repurchases of common stock of subsidiaries.

[0001571996-20-000034:mdna:225]
[same as prior period, unchanged from 0001571996-19-000051:mdna:228]

[0001571996-20-000034:mdna:226]
Capital Expenditures — During the first quarter of Fiscal 2021 and Fiscal 2020, we spent $0.5 billion and $0.6 billion, respectively, on property, plant, and equipment.  These expenditures were incurred in connection with our global expansion efforts and infrastructure investments made to support future growth, and the funding of equipment under DFS operating leases.  During the first quarter of Fiscal 2021 and Fiscal 2020, funding of gross equipment under DFS operating leases was $0.2 billion and $0.3 billion, respectively.  Product demand, product mix, and the use of contract manufacturers, as well as ongoing investments in operating and information technology infrastructure, influence the level and prioritization of our capital expenditures.  Aggregate capital expenditures for Fiscal 2021 are currently expected to total between $2.3 billion and $2.5 billion, of which approximately $1.0 billion is expected for equipment under DFS operating leases.

[0001571996-20-000034:mdna:227]
[same as prior period, unchanged from 0001571996-19-000051:mdna:230]

[0001571996-20-000034:mdna:228]
[same as prior period, unchanged from 0001571996-19-000051:mdna:231]

[0001571996-20-000034:mdna:229]
[same as prior period, unchanged from 0001571996-19-000051:mdna:126]
