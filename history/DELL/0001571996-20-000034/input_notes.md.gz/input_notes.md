# DELL notes — 0001571996-20-000034


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0001571996-20-000034:notes:1]
Basis of Presentation — The accompanying unaudited Condensed Consolidated Financial Statements should be read in conjunction with the audited Consolidated Financial Statements and accompanying Notes filed with the U.S. Securities and Exchange Commission (“SEC”) in the Company’s Annual Report on Form 10-K for the fiscal year ended January 31, 2020.  These Condensed Consolidated Financial Statements have been prepared in accordance with accounting principles generally accepted in the United States of America (“GAAP”).  In the opinion of management, the accompanying Condensed Consolidated Financial Statements reflect all adjustments of a normal recurring nature considered necessary to fairly state the financial position of Dell Technologies Inc. as of May 1, 2020 and January 31, 2020 and the results of its operations and corresponding comprehensive income (loss) and its cash flows for the three months ended May 1, 2020 and May 3, 2019.


## us-gaap:ConsolidationPolicyTextBlock

[0001571996-20-000034:notes:2]
Principles of Consolidation — These Condensed Consolidated Financial Statements include the accounts of Dell Technologies and its wholly-owned subsidiaries, as well as the accounts of VMware, Inc. and SecureWorks Corp. (“Secureworks”), each of which is majority-owned by Dell Technologies.  All intercompany transactions have been eliminated.


## us-gaap:ScheduleOfDisposalGroupsIncludingDiscontinuedOperationsIncomeStatementBalanceSheetAndAdditionalDisclosuresTextBlock

[0001571996-20-000034:notes:3]
The following table presents the major classes of assets and liabilities as of May 1, 2020 related to RSA Security which were classified as held for sale as of the date indicated:

[0001571996-20-000034:notes:4]
|  | May 1, 2020 |
|  | (in millions) |
| ASSETS |
| Current assets: |  |
| Accounts receivable, net | $ | 221 |  |
| Other current assets | 23 |  |
| Total current assets | 244 |  |
| Goodwill | 1,359 |  |
| Intangible assets, net | 440 |  |
| Other non-current assets | 55 |  |
| Total assets | $ | 2,098 |  |
| LIABILITIES |
| Current liabilities: |  |
| Accounts payable | $ | 25 |  |
| Accrued and other | 68 |  |
| Short-term deferred revenue | 206 |  |
| Total current liabilities | 299 |  |
| Long-term deferred revenue | 44 |  |
| Other non-current liabilities | 22 |  |
| Total liabilities | $ | 365 |  |


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001571996-20-000034:notes:5]
Recently Issued Accounting Pronouncements

[0001571996-20-000034:notes:6]
Simplifying Accounting for Income Taxes — In December 2019, the Financial Accounting Standards Board (“FASB”) issued guidance to simplify the accounting for income taxes by removing certain exceptions to the general principles in Topic 740, Income Taxes, and by clarifying and amending existing guidance in order to improve consistent application of GAAP for other areas of Topic 740.  Public entities must adopt the new guidance for fiscal years beginning after December 15, 2020, and interim periods within those fiscal years, with early adoption permitted for fiscal periods beginning after December 15, 2019.  The Company is currently evaluating the impact and timing of adoption of this guidance.

[0001571996-20-000034:notes:7]
Recently Adopted Accounting Pronouncements

[0001571996-20-000034:notes:8]
Measurement of Credit Losses on Financial Instruments — In June 2016, the FASB issued amended guidance which replaces the current incurred loss impairment methodology for measurement of credit losses on financial instruments with a methodology (the “current expected credit losses model,” or “CECL model”) that reflects expected credit losses and requires consideration of a broader range of reasonable and supportable information to inform credit loss estimates.  Under the CECL model, the allowance for losses on financial assets, measured at amortized cost, reflects management’s estimate of credit losses over the remaining expected life of such assets.

[0001571996-20-000034:notes:9]
The Company adopted the standard (the “new CECL standard”) as of February 1, 2020 using the modified retrospective method, with the cumulative-effect adjustment to the opening balance of stockholders’ equity (deficit) as of the adoption date.  The cumulative effect of adopting the new CECL standard resulted in an increase of $111 million and $27 million to the allowance for expected credit losses within financing receivables, net and accounts receivable, net, respectively, on the Condensed Consolidated Statements of Financial Position, and a corresponding decrease of $28 million to other non-current liabilities related to deferred taxes and $110 million to stockholders’ equity (deficit) as of February 1, 2020.  See Note 2, Note 4, and Note 18 of the Notes to the Condensed Consolidated Financial Statements for additional information about the Company’s allowance for financing receivables losses and allowance for expected credit losses of accounts receivable, respectively.

[0001571996-20-000034:notes:10]
Intangibles - Goodwill and Other - Internal-Use Software — In August 2018, the FASB issued guidance on a customer’s accounting for implementation costs incurred in a cloud-computing arrangement when hosted by a vendor.  The guidance provides that, in a hosting arrangement that is a service contract, certain implementation costs should be capitalized and amortized over the term of the arrangement.  The Company adopted the standard (the “new cloud computing standard”) during the three months ended May 1, 2020 using the prospective method.  The impact of the adoption of this standard was immaterial to the Condensed Consolidated Financial Statements.


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock

[0001571996-20-000034:notes:11]
[same as prior period, unchanged from 0001571996-19-000051:notes:12]

[0001571996-20-000034:notes:12]
As discussed in Note 1 of the Notes to the Condensed Consolidated Financial Statements, the Company adopted the new CECL standard as of February 1, 2020 using the modified retrospective method.  The new impairment methodology for measurement of credit losses on financial instruments reflects expected credit losses and requires consideration of a broader range of reasonable and supportable information to inform credit loss estimates.  Additionally, the Company adopted the new cloud computing standard during the three months ended May 1, 2020 using the prospective method.  In a cloud-computing hosting arrangement hosted by a vendor that is a service contract, certain implementation costs should be capitalized and amortized over the term of the arrangement.  The following accounting policies have been updated as part of the adoption of the new standards.

[0001571996-20-000034:notes:13]
Allowance for Expected Credit Losses — The Company recognizes an allowance for losses on accounts receivable in an amount equal to the current expected credit losses.  The estimation of the allowance is based on an analysis of historical loss experience, current receivables aging, and management’s assessment of current conditions and reasonable and supportable expectation of future conditions, as well as an assessment of specific identifiable customer accounts considered at risk or uncollectible.  The Company assesses collectibility by pooling receivables where similar characteristics exist and evaluates receivables individually when specific customer balances no longer share those risk characteristics and are considered at risk or uncollectible.  The expense associated with the allowance for expected credit losses is recognized in selling, general, and administrative expenses.

[0001571996-20-000034:notes:14]
Allowance for Financing Receivables Losses — The Company recognizes an allowance for losses on financing receivables in an amount equal to the probable losses net of recoveries.  The allowance for losses is determined based on various factors, including lifetime expected losses determined using macroeconomic forecast assumptions and management judgments applicable to and through the expected life of the portfolios as well as past due receivables, receivable type, and customer risk profile.  Both fixed and revolving receivable loss rates are affected by macroeconomic conditions, including the level of gross domestic product (“GDP”) growth, the level of commercial capital equipment investment, unemployment rates, and the credit quality of the borrower.

[0001571996-20-000034:notes:15]
Customer account principal and interest are charged to the allowance for losses when an account is deemed to be uncollectible or generally when the account is 180 days delinquent.  While the Company does not generally place financing receivables on non-accrual status during the delinquency period, accrued interest is included in the allowance for loss calculation and, therefore, the Company is adequately reserved in the event of charge off.  Recoveries on receivables previously charged off as uncollectible are recorded to the allowance for financing receivables losses.  The expense associated with the allowance for financing receivables losses is recognized as cost of net revenue.

[0001571996-20-000034:notes:16]
Capitalized Software Development Costs — The Company capitalizes certain internal and external costs to acquire or create internal use software which are incurred subsequent to the completion of the preliminary project stage.  Development costs are generally amortized on a straight-line basis over five years.  Costs associated with maintenance and minor enhancements to the features and functionality of the Company’s website are expensed as incurred.


## us-gaap:FairValueDisclosuresTextBlock

[0001571996-20-000034:notes:17]
[same as prior period, unchanged from 0001571996-19-000051:notes:27]

[0001571996-20-000034:notes:18]
[same as prior period, unchanged from 0001571996-19-000051:notes:28]

[0001571996-20-000034:notes:19]
|  | May 1, 2020 |  | January 31, 2020 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | Quoted Prices in Active Markets for Identical Assets |  | Significant Other Observable Inputs |  | Significant Unobservable Inputs |  |  |  | Quoted Prices in Active Markets for Identical Assets |  | Significant Other Observable Inputs |  | Significant Unobservable Inputs |  |  |
|  | (in millions) |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | $ | 7,981 |  |  | $ | — |  |  | $ | — |  |  | $ | 7,981 |  |  | $ | 4,621 |  |  | $ | — |  |  | $ | — |  |  | $ | 4,621 |  |
| Equity and other securities | 3 |  |  | — |  |  | — |  |  | 3 |  |  | 12 |  |  | — |  |  | — |  |  | 12 |  |
| Derivative instruments | — |  |  | 352 |  |  | — |  |  | 352 |  |  | — |  |  | 81 |  |  | — |  |  | 81 |  |
| Total assets | $ | 7,984 |  |  | $ | 352 |  |  | $ | — |  |  | $ | 8,336 |  |  | $ | 4,633 |  |  | $ | 81 |  |  | $ | — |  |  | $ | 4,714 |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Derivative instruments | $ | — |  |  | $ | 114 |  |  | $ | — |  |  | $ | 114 |  |  | $ | — |  |  | $ | 68 |  |  | $ | — |  |  | $ | 68 |  |
| Total liabilities | $ | — |  |  | $ | 114 |  |  | $ | — |  |  | $ | 114 |  |  | $ | — |  |  | $ | 68 |  |  | $ | — |  |  | $ | 68 |  |

[0001571996-20-000034:notes:20]
[same as prior period, unchanged from 0001571996-19-000051:notes:30]

[0001571996-20-000034:notes:21]
Money Market Funds — The Company’s investment in money market funds that are classified as cash equivalents hold underlying investments with a weighted average maturity of 90 days or less and are recognized at fair value.  The valuations of these securities are based on quoted prices in active markets for identical assets, when available, or pricing models whereby all significant inputs are observable or can be derived from or corroborated by observable market data.  The Company reviews security pricing and assesses liquidity on a quarterly basis.  As of May 1, 2020, the Company’s U.S. portfolio had no material exposure to money market funds with a fluctuating net asset value.

[0001571996-20-000034:notes:22]
Equity and Other Securities — The majority of the Company’s investments in equity and other securities that are measured at fair value on a recurring basis consist of strategic investments in publicly-traded companies.  The valuation of these securities is based on quoted prices in active markets.

[0001571996-20-000034:notes:23]
[same as prior period, unchanged from 0001571996-19-000051:notes:33]

[0001571996-20-000034:notes:24]
Deferred Compensation Plans — The Company offers deferred compensation plans for eligible employees, which allow participants to defer payment for a portion of their compensation.  Assets were the same as liabilities associated with the plans at approximately $231 million and $241 million as of May 1, 2020 and January 31, 2020, respectively, and are included in other assets and other liabilities on the Condensed Consolidated Statements of Financial Position.  The net impact to the Condensed Consolidated Statements of Income (Loss) is not material since changes in the fair value of the assets substantially offset changes in the fair value of the liabilities.  As such, assets and liabilities associated with these plans have not been included in the recurring fair value table above.

[0001571996-20-000034:notes:25]
[same as prior period, unchanged from 0001571996-19-000051:notes:35]

[0001571996-20-000034:notes:26]
As of May 1, 2020 and January 31, 2020, the Company held private strategic investments of $971 million and $852 million, respectively.  As these investments represent early-stage companies without readily determinable fair values, they are not included in the recurring fair value table above.

[0001571996-20-000034:notes:27]
The Company has elected to apply the measurement alternative for these investments.  Under the alternative, the Company measures investments without readily determinable fair values at cost, less impairment, adjusted by observable price changes.  The Company must make a separate election to use the alternative for each eligible investment and is required to reassess at each reporting period whether an investment qualifies for the alternative.  In evaluating these investments for impairment or observable price changes, the Company uses inputs including pre- and post-money valuations of recent financing events and the impact of those events on its fully diluted ownership percentages, as well as other available information regarding the issuer’s historical and forecasted performance.

[0001571996-20-000034:notes:28]
[same as prior period, unchanged from 0001571996-19-000051:notes:38]

[0001571996-20-000034:notes:29]
|  | May 1, 2020 |  | January 31, 2020 |
|  | Carrying Value |  | Fair Value |  | Carrying Value |  | Fair Value |
|  | (in billions) |
| Senior Secured Credit Facilities | $ | 8.7 |  |  | $ | 8.6 |  |  | $ | 8.8 |  |  | $ | 9.0 |  |
| First Lien Notes | $ | 22.8 |  |  | $ | 24.8 |  |  | $ | 20.5 |  |  | $ | 23.9 |  |
| Unsecured Notes and Debentures | $ | 1.2 |  |  | $ | 1.4 |  |  | $ | 1.2 |  |  | $ | 1.5 |  |
| Senior Notes | $ | 2.6 |  |  | $ | 2.8 |  |  | $ | 2.6 |  |  | $ | 2.8 |  |
| EMC Notes | $ | 1.6 |  |  | $ | 1.6 |  |  | $ | 1.6 |  |  | $ | 1.6 |  |
| VMware Notes and VMware Term Loan Facility | $ | 7.5 |  |  | $ | 7.7 |  |  | $ | 5.5 |  |  | $ | 5.6 |  |
| Margin Loan Facility | $ | 4.0 |  |  | $ | 3.9 |  |  | $ | 4.0 |  |  | $ | 3.9 |  |

[0001571996-20-000034:notes:30]
The fair values of the outstanding debt shown in the table above, as well as the Dell Financial Services (“DFS”) debt described in Note 4 of the Notes to the Condensed Consolidated Financial Statements, were determined based on observable market prices in a less active market or based on valuation methodologies using observable inputs and were categorized as Level 2 in the fair value hierarchy.  The carrying value of DFS debt approximates fair value.

[0001571996-20-000034:notes:31]
[same as prior period, unchanged from 0001571996-19-000051:notes:41]

[0001571996-20-000034:notes:32]
[same as prior period, unchanged from 0001571996-19-000051:notes:42]

[0001571996-20-000034:notes:33]
|  | May 1, 2020 |  | January 31, 2020 |
|  | Cost |  | Unrealized Gain |  | Unrealized (Loss) |  | Carrying Value |  | Cost |  | Unrealized Gain |  | Unrealized (Loss) |  | Carrying Value |
|  | (in millions) |
| Equity and other securities | $ | 904 |  |  | $ | 83 |  |  | $ | (13 | ) |  | $ | 974 |  |  | $ | 783 |  |  | $ | 116 |  |  | $ | (35 | ) |  | $ | 864 |  |

[0001571996-20-000034:notes:34]
For the three months ended May 1, 2020, the equity and other securities without readily determinable fair values of $971 million increased by $83 million, due to upward adjustments for observable price changes, offset by $11 million of downward adjustments primarily attributable to observable price changes.  The remainder of equity and other securities consists of publicly-traded investments that are measured at fair value on a recurring basis.


## dell:CreditLossFinancialInstrumentLeasesDebtVariableInterestEntitiesAndCustomerReceivablesSalesTextBlock

[0001571996-20-000034:notes:35]
NOTE 4 — FINANCIAL SERVICES

[0001571996-20-000034:notes:36]
The Company offers or arranges various financing options, services, and alternative payment structures for its customers in North America, Europe, Australia, and New Zealand through Dell Financial Services and its affiliates (“DFS”).  The Company also arranges financing for some of its customers in various countries where DFS does not currently operate as a captive enterprise.  The key activities of DFS include originating, collecting, and servicing customer financing arrangements primarily related to the purchase or use of Dell Technologies products and services.  In some cases, DFS also offers financing on the purchase of third-party technology products that complement the Dell Technologies portfolio of products and services.  New financing originations were $1.8 billion and $1.7 billion for the three months ended May 1, 2020 and May 3, 2019, respectively.

[0001571996-20-000034:notes:37]
The Company’s loan and lease arrangements with customers are aggregated into the following categories:

[0001571996-20-000034:notes:38]
Revolving loans — Revolving loans offered under private label credit financing programs provide qualified customers with a revolving credit line for the purchase of products and services offered by Dell Technologies.  These private label credit financing programs are referred to as Dell Preferred Account (“DPA”) and Dell Business Credit (“DBC”).  The DPA product is primarily offered to individual consumer customers, and the DBC product is primarily offered to small and medium-sized commercial customers.  Revolving loans in the United States bear interest at a variable annual percentage rate that is tied to the prime rate.  Based on historical payment patterns, revolving loan transactions are typically repaid within twelve months on average.  Due to the short-term nature of the revolving loan portfolio, the carrying value of the portfolio approximates fair value.

[0001571996-20-000034:notes:39]
Fixed-term leases and loans — The Company enters into financing arrangements with customers who seek lease financing for equipment they might otherwise purchase.  Pursuant to the current lease accounting standard effective February 2, 2019, new DFS leases are classified as sales-type leases, direct financing leases, or operating leases.  When the terms of the DFS lease transfer control of the underlying asset to the lessee, the contract is typically classified as a sales-type lease.  Direct financing leases are immaterial.  All other new DFS leases are classified as operating leases.  Leases that commenced prior to the effective date of the current lease accounting standard continue to be accounted for under previous lease accounting guidance.  Leases with business customers have fixed terms of generally two to four years.

[0001571996-20-000034:notes:40]
The Company also offers fixed-term loans to qualified small businesses, large commercial accounts, governmental organizations, educational entities, and certain individual consumer customers.  These loans are repaid in equal payments including interest and have defined terms of generally three to five years.  The fair value of the fixed-term loan portfolio is determined using market observable inputs.  The carrying value of these loans approximates fair value.

[0001571996-20-000034:notes:41]
Financing Receivables

[0001571996-20-000034:notes:42]
The following table presents the components of the Company’s financing receivables segregated by portfolio segment as of the dates indicated:

[0001571996-20-000034:notes:43]
|  | May 1, 2020 |  | January 31, 2020 |
|  | Revolving |  | Fixed-term |  | Total |  | Revolving |  | Fixed-term |  | Total |
|  | (in millions) |
| Financing receivables, net: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer receivables, gross (a) | $ | 786 |  |  | $ | 8,446 |  |  | $ | 9,232 |  |  | $ | 824 |  |  | $ | 8,486 |  |  | $ | 9,310 |  |
| Allowances for losses | (144 | ) |  | (177 | ) |  | (321 | ) |  | (70 | ) |  | (79 | ) |  | (149 | ) |
| Customer receivables, net | 642 |  |  | 8,269 |  |  | 8,911 |  |  | 754 |  |  | 8,407 |  |  | 9,161 |  |
| Residual interest | — |  |  | 551 |  |  | 551 |  |  | — |  |  | 582 |  |  | 582 |  |
| Financing receivables, net | $ | 642 |  |  | $ | 8,820 |  |  | $ | 9,462 |  |  | $ | 754 |  |  | $ | 8,989 |  |  | $ | 9,743 |  |
| Short-term | $ | 642 |  |  | $ | 4,110 |  |  | $ | 4,752 |  |  | $ | 754 |  |  | $ | 4,141 |  |  | $ | 4,895 |  |
| Long-term | $ | — |  |  | $ | 4,710 |  |  | $ | 4,710 |  |  | $ | — |  |  | $ | 4,848 |  |  | $ | 4,848 |  |

[0001571996-20-000034:notes:44]
____________________

[0001571996-20-000034:notes:45]
| (a) | Customer receivables, gross includes amounts due from customers under revolving loans, fixed-term loans, fixed-term sales-type or direct financing leases, and accrued interest. |

[0001571996-20-000034:notes:46]
The allowance for losses as of May 1, 2020 includes the adoption of the new CECL standard, which was adopted as of February 1, 2020 using the modified retrospective method.  Prior period amounts have not been recast.  The provision recognized on the Condensed Consolidated Statements of Income (Loss) during the three months ended May 1, 2020 is based on an assessment of the impact of current and expected future economic conditions, inclusive of the effect of the COVID-19 pandemic on credit losses.  The duration and severity of COVID-19 and continued market volatility is highly uncertain and, as such, the impact on expected losses is subject to significant judgment and may cause variability in the Company’s allowance for credit losses in future periods.  See Note 1 and Note 2 of the Notes to the Condensed Consolidated Financial Statements for additional information about the new CECL standard.

[0001571996-20-000034:notes:47]
The following table presents the changes in allowance for financing receivable losses for the periods indicated:

[0001571996-20-000034:notes:48]
|  | Three Months Ended |
|  | May 1, 2020 |  | May 3, 2019 |
|  | Revolving |  | Fixed-term |  | Total |  | Revolving |  | Fixed-term |  | Total |
|  | (in millions) |
| Allowance for financing receivable losses: |  |  |  |  |  |  |  |  |  |  |  |
| Balances at beginning of period | $ | 70 |  |  | $ | 79 |  |  | $ | 149 |  |  | $ | 75 |  |  | $ | 61 |  |  | $ | 136 |  |
| Adjustment for adoption of the new CECL standard (Note 1) | 40 |  |  | 71 |  |  | 111 |  |  | — |  |  | — |  |  | — |  |
| Charge-offs, net of recoveries | (20 | ) |  | (9 | ) |  | (29 | ) |  | (20 | ) |  | (3 | ) |  | (23 | ) |
| Provision charged to income statement | 54 |  |  | 36 |  |  | 90 |  |  | 15 |  |  | 15 |  |  | 30 |  |
| Balances at end of period | $ | 144 |  |  | $ | 177 |  |  | $ | 321 |  |  | $ | 70 |  |  | $ | 73 |  |  | $ | 143 |  |

[0001571996-20-000034:notes:49]
Aging

[0001571996-20-000034:notes:50]
The following table presents the aging of the Company’s customer financing receivables, gross, including accrued interest, segregated by class, as of the dates indicated:

[0001571996-20-000034:notes:51]
|  | May 1, 2020 |  | January 31, 2020 |
|  | Current |  | Past Due1 — 90 Days |  | Past Due>90 Days |  | Total |  | Current |  | Past Due1 — 90 Days |  | Past Due>90 Days |  | Total |
|  | (in millions) |
| Revolving — DPA | $ | 547 |  |  | $ | 34 |  |  | $ | 17 |  |  | $ | 598 |  |  | $ | 550 |  |  | $ | 51 |  |  | $ | 20 |  |  | $ | 621 |  |
| Revolving — DBC | 162 |  |  | 21 |  |  | 5 |  |  | 188 |  |  | 184 |  |  | 15 |  |  | 4 |  |  | 203 |  |
| Fixed-term — Consumer and Commercial | 6,963 |  |  | 1,333 |  |  | 150 |  |  | 8,446 |  |  | 8,005 |  |  | 373 |  |  | 108 |  |  | 8,486 |  |
| Total customer receivables, gross | $ | 7,672 |  |  | $ | 1,388 |  |  | $ | 172 |  |  | $ | 9,232 |  |  | $ | 8,739 |  |  | $ | 439 |  |  | $ | 132 |  |  | $ | 9,310 |  |

[0001571996-20-000034:notes:52]
Aging is likely to fluctuate as a result of the variability in volume of large transactions entered into over the period, and the administrative processes that accompany those larger transactions.  Aging is also impacted by the timing of Dell Technologies fiscal period end date, relative to calendar month-end customer payment due dates.  As a result of these factors, fluctuations in aging from period to period do not necessarily indicate a material change in the collectibility of the portfolio.

[0001571996-20-000034:notes:53]
Fixed-term consumer and commercial customer receivables are placed on non-accrual status if principal or interest is past due and considered delinquent, or if there is concern about collectibility of a specific customer receivable.  These receivables identified as doubtful for collectibility may be classified as current for aging purposes.  Aged revolving portfolio customer receivables identified as delinquent are charged off.

[0001571996-20-000034:notes:54]
Credit Quality

[0001571996-20-000034:notes:55]
The following table presents customer receivables, gross, including accrued interest, by credit quality indicator segregated by class and year of origination, as of the date indicated:

[0001571996-20-000034:notes:56]
|  | May 1, 2020 |
|  | Fixed-term — Consumer and Commercial |  |  |  |  |  |  |
|  | Fiscal Year of Origination |  |  |  |  |  |  |
|  | 2021 |  | 2020 |  | 2019 |  | 2018 |  | 2017 |  | Years Prior |  | Revolving — DPA (a) |  | Revolving — DBC (a) |  | Total |
|  | (in millions) |
| Higher | $ | 1,150 |  |  | $ | 2,438 |  |  | $ | 1,141 |  |  | $ | 393 |  |  | $ | 68 |  |  | $ | 2 |  |  | $ | 135 |  |  | $ | 51 |  |  | $ | 5,378 |  |
| Mid | 229 |  |  | 883 |  |  | 498 |  |  | 182 |  |  | 34 |  |  | 2 |  |  | 169 |  |  | 56 |  |  | 2,053 |  |
| Lower | 184 |  |  | 647 |  |  | 443 |  |  | 119 |  |  | 29 |  |  | 4 |  |  | 294 |  |  | 81 |  |  | 1,801 |  |
| Total | $ | 1,563 |  |  | $ | 3,968 |  |  | $ | 2,082 |  |  | $ | 694 |  |  | $ | 131 |  |  | $ | 8 |  |  | $ | 598 |  |  | $ | 188 |  |  | $ | 9,232 |  |

[0001571996-20-000034:notes:57]
| (a) | The revolving portfolio is exempt from the requirement to disclose the amortized cost basis by year of origination since determining the appropriate origination year can be complex due to the nature of the revolving portfolio. |

[0001571996-20-000034:notes:58]
The following table presents customer receivables, gross, including accrued interest, by credit quality indicator segregated by class, as of the date indicated, and was not recast to reflect the impact of adoption of the new CECL standard:

[0001571996-20-000034:notes:59]
|  | January 31, 2020 |
|  | Fixed-term — Consumer and Commercial |  | Revolving — DPA |  | Revolving — DBC |  | Total |
|  | (in millions) |
| Higher | $ | 5,042 |  |  | $ | 137 |  |  | $ | 55 |  |  | $ | 5,234 |  |
| Mid | 2,036 |  |  | 175 |  |  | 63 |  |  | 2,274 |  |
| Lower | 1,408 |  |  | 309 |  |  | 85 |  |  | 1,802 |  |
| Total | $ | 8,486 |  |  | $ | 621 |  |  | $ | 203 |  |  | $ | 9,310 |  |

[0001571996-20-000034:notes:60]
The categories shown in the tables above segregate customer receivables based on the relative degrees of credit risk.  The credit quality indicators for DPA revolving accounts are measured primarily as of each quarter-end date, while all other indicators are generally updated on a periodic basis.

[0001571996-20-000034:notes:61]
For DPA revolving receivables shown in the table above, the Company makes credit decisions based on proprietary scorecards, which include the customer’s credit history, payment history, credit usage, and other credit agency-related elements.  The higher quality category includes prime accounts generally of a higher credit quality that are comparable to U.S. customer FICO scores of 720 or above.  The mid-category represents the mid-tier accounts that are comparable to U.S. customer FICO scores from 660 to 719.  The lower category is generally sub-prime and represents lower credit quality accounts that are comparable to U.S. customer FICO scores below 660.  For the DBC revolving receivables and fixed-term commercial receivables shown in the table above, an internal grading system is utilized that assigns a credit level score based on a number of considerations, including liquidity, operating performance, and industry outlook.  The grading criteria and classifications for the fixed-term products differ from those for the revolving products as loss experience varies between these product and customer groups.  The credit quality categories cannot be compared between the different classes as loss experience varies substantially between the classes.

[0001571996-20-000034:notes:62]
Leases

[0001571996-20-000034:notes:63]
Interest income on sales-type lease receivables was $65 million and $64 million for the three months ended May 1, 2020 and May 3, 2019, respectively.

[0001571996-20-000034:notes:64]
The following table presents the net revenue, cost of net revenue, and gross margin recognized at the commencement date of sales-type leases for the periods indicated:

[0001571996-20-000034:notes:65]
|  | Three Months Ended |
|  | May 1, 2020 |  | May 3, 2019 |
|  | (in millions) |
| Net revenue — products | $ | 215 |  |  | $ | 130 |  |
| Cost of net revenue — products | 159 |  |  | 81 |  |
| Gross margin — products | $ | 56 |  |  | $ | 49 |  |

[0001571996-20-000034:notes:66]
The following table presents the future maturity of the Company’s fixed-term customer leases and associated financing payments, and reconciles the undiscounted cash flows to the customer receivables, gross recognized on the Condensed Consolidated Statements of Financial Position as of the date indicated:

[0001571996-20-000034:notes:67]
|  | May 1, 2020 |
| Fiscal Years | (in millions) |
| Fiscal 2021 (remaining nine months) | $ | 2,050 |  |
| Fiscal 2022 | 1,812 |  |
| Fiscal 2023 | 1,045 |  |
| Fiscal 2024 | 406 |  |
| Fiscal 2025 and beyond | 137 |  |
| Total undiscounted cash flows | 5,450 |  |
| Fixed-term loans | 3,588 |  |
| Revolving loans | 786 |  |
| Less: unearned income | (592 | ) |
| Total customer receivables, gross | $ | 9,232 |  |

[0001571996-20-000034:notes:68]
Operating Leases

[0001571996-20-000034:notes:69]
The following table presents the components of the Company’s operating lease portfolio included in Property, plant, and equipment, net as of the dates indicated:

[0001571996-20-000034:notes:70]
|  | May 1, 2020 |  | January 31, 2020 |
|  | (in millions) |
| Equipment under operating lease, gross | $ | 1,150 |  |  | $ | 956 |  |
| Less: accumulated depreciation | (175 | ) |  | (116 | ) |
| Equipment under operating lease, net | $ | 975 |  |  | $ | 840 |  |

[0001571996-20-000034:notes:71]
Operating lease income relating to lease payments was $87 million and $4 million for the three months ended May 1, 2020 and May 3, 2019, respectively.  Depreciation expense was $62 million and $3 million for the three months ended May 1, 2020 and May 3, 2019, respectively.

[0001571996-20-000034:notes:72]
The following table presents the future payments to be received by the Company as lessor in operating lease contracts as of the date indicated:

[0001571996-20-000034:notes:73]
|  | May 1, 2020 |
| Fiscal Years | (in millions) |
| Fiscal 2021 (remaining nine months) | $ | 306 |  |
| Fiscal 2022 | 370 |  |
| Fiscal 2023 | 269 |  |
| Fiscal 2024 | 54 |  |
| Fiscal 2025 and beyond | 7 |  |
| Total | $ | 1,006 |  |

[0001571996-20-000034:notes:74]
DFS Debt

[0001571996-20-000034:notes:75]
The Company maintains programs that facilitate the funding of leases, loans, and other alternative payment structures in the capital markets.  The majority of DFS debt is non-recourse to Dell Technologies and represents borrowings under securitization programs and structured financing programs, for which the Company’s risk of loss is limited to transferred loan and lease payments and associated equipment.  The following table presents DFS debt as of the dates indicated.  The table excludes the allocated portion of the Company’s other borrowings, which represents the additional amount considered to fund the DFS business.

[0001571996-20-000034:notes:76]
|  | May 1, 2020 |  | January 31, 2020 |
|  | (in millions) |
| DFS U.S. debt: |  |  |  |
| Asset-based financing and securitization facilities | $ | 2,429 |  |  | $ | 2,606 |  |
| Fixed-term securitization offerings | 3,251 |  |  | 2,593 |  |
| Other | 117 |  |  | 141 |  |
| Total DFS U.S. debt | 5,797 |  |  | 5,340 |  |
| DFS international debt: |  |  |  |
| Securitization facility | 773 |  |  | 743 |  |
| Other borrowings | 970 |  |  | 931 |  |
| Note payable | 181 |  |  | 200 |  |
| Dell Bank Senior Unsecured Eurobonds | 548 |  |  | 551 |  |
| Total DFS international debt | 2,472 |  |  | 2,425 |  |
| Total DFS debt | $ | 8,269 |  |  | $ | 7,765 |  |
| Total short-term DFS debt | $ | 4,397 |  |  | $ | 4,152 |  |
| Total long-term DFS debt | $ | 3,872 |  |  | $ | 3,613 |  |

[0001571996-20-000034:notes:77]
DFS U.S. Debt

[0001571996-20-000034:notes:78]
Asset-Based Financing and Securitization Facilities — The Company maintains separate asset-based financing facilities and a securitization facility in the United States, which are revolving facilities for fixed-term leases and loans and for revolving loans, respectively.  This debt is collateralized solely by the U.S. loan and lease payments and associated equipment in the facilities.  The debt has a variable interest rate and the duration of the debt is based on the terms of the underlying loan and lease payment streams.  As of May 1, 2020, the total debt capacity related to the U.S. asset-based financing and securitization facilities was $4.0 billion.  The Company enters into interest swap agreements to effectively convert a portion of this debt from a floating rate to a fixed rate.  See Note 7 of the Notes to the Condensed Consolidated Financial Statements for additional information about interest rate swaps.

[0001571996-20-000034:notes:79]
The Company’s U.S. securitization facility for revolving loans is effective through June 25, 2022.  The Company’s two U.S. asset-based financing facilities for fixed-term leases and loans are effective through August 22, 2021 and July 26, 2022, respectively.

[0001571996-20-000034:notes:80]
The asset-based financing and securitization facilities contain standard structural features related to the performance of the funded receivables, which include defined credit losses, delinquencies, average credit scores, and minimum collection requirements.  In the event one or more of these criteria are not met and the Company is unable to restructure the facility, no further funding of receivables will be permitted and the timing of the Company’s expected cash flows from over-collateralization will be delayed.  As of May 1, 2020, these criteria were met.

[0001571996-20-000034:notes:81]
Fixed-Term Securitization Offerings — The Company periodically issues asset-backed debt securities under fixed-term securitization programs to private investors.  The asset-backed debt securities are collateralized solely by the U.S. fixed-term leases and loans in the offerings, which are held by Special Purpose Entities (“SPEs”), as discussed below.  The interest rate on these securities is fixed and ranges from 1.91% to 5.92% per annum, and the duration of these securities is based on the terms of the underlying loan and lease payment streams.

[0001571996-20-000034:notes:82]
DFS International Debt

[0001571996-20-000034:notes:83]
Securitization Facility — The Company maintains a securitization facility in Europe for fixed-term leases and loans.  This facility is effective through December 21, 2020 and has a total debt capacity of $876 million as of May 1, 2020.

[0001571996-20-000034:notes:84]
The securitization facility contains standard structural features related to the performance of the securitized receivables, which include defined credit losses, delinquencies, average credit scores, and minimum collection requirements.  In the event one or more of these criteria are not met and the Company is unable to restructure the program, no further funding of receivables will be permitted and the timing of the Company’s expected cash flows from over-collateralization will be delayed.  As of May 1, 2020, these criteria were met.

[0001571996-20-000034:notes:85]
Other Borrowings — In connection with the Company’s international financing operations, the Company has entered into revolving structured financing debt programs related to its fixed-term lease and loan products sold in Canada, Europe, Australia, and New Zealand.  The Canadian facility, which is collateralized solely by Canadian loan and lease payments and associated equipment, had a total debt capacity of $269 million as of May 1, 2020, and is effective through January 16, 2023.  The European facility, which is collateralized solely by European loan and lease payments and associated equipment, had a total debt capacity of $657 million as of May 1, 2020, and is effective through June 14, 2022.  The Australia and New Zealand facility, which is collateralized solely by Australia and New Zealand loan and lease payments and associated equipment, had a total debt capacity of $228 million as of May 1, 2020, and is effective through December 20, 2021.

[0001571996-20-000034:notes:86]
Note Payable — On November 27, 2017, the Company entered into an unsecured credit agreement to fund receivables in Mexico.  As of May 1, 2020, the aggregate principal amount of the note payable is $181 million.  The note bears interest at either the applicable London Interbank Offered Rate (“LIBOR”) plus 2.25%, for the borrowings denominated in U.S. dollars, or the Mexican Interbank Equilibrium Interest Rate (“TIIE”) plus 2.00%, for the borrowings denominated in Mexican pesos.  The note will mature on December 1, 2020.

[0001571996-20-000034:notes:87]
Dell Bank Senior Unsecured Eurobonds — On October 17, 2019, Dell Bank International D.A.C. issued 500 million Euro of 0.625% senior unsecured three year eurobonds due October 2022.  The issuance of the senior unsecured eurobonds supports the expansion of the financing operations in Europe.

[0001571996-20-000034:notes:88]
Variable Interest Entities

[0001571996-20-000034:notes:89]
In connection with the asset-based financing facilities, securitization facilities, and fixed-term securitization offerings discussed above, the Company transfers certain U.S. and European loan and lease payments and associated equipment to SPEs that meet the definition of a Variable Interest Entity (“VIE”) and are consolidated, along with the associated debt detailed above, into the Consolidated Financial Statements, as the Company is the primary beneficiary of those VIEs.  The SPEs are bankruptcy-remote legal entities with separate assets and liabilities.  The purpose of the SPEs is to facilitate the funding of customer loan and lease payments and associated equipment in the capital markets.

[0001571996-20-000034:notes:90]
The following table presents financing receivables and equipment under operating leases, net held by the consolidated VIEs as of the dates indicated:

[0001571996-20-000034:notes:91]
|  | May 1, 2020 |  | January 31, 2020 |
|  | (in millions) |
| Assets held by consolidated VIEs, net: |  |  |  |  |  |
| Short-term, net | $ | 3,384 |  |  | $ | 3,316 |  |
| Long-term, net | 3,628 |  |  | 3,348 |  |
| Assets held by consolidated VIEs, net | $ | 7,012 |  |  | $ | 6,664 |  |

[0001571996-20-000034:notes:92]
Loan and lease payments and associated equipment transferred via securitization through SPEs were $1.8 billion and $1.5 billion for the three months ended May 1, 2020 and May 3, 2019, respectively.

[0001571996-20-000034:notes:93]
Some of the SPEs have entered into financing arrangements with multi-seller conduits that, in turn, issue asset-backed debt securities in the capital markets.  The DFS debt outstanding, which is collateralized by the loan and lease payments and associated equipment held by the consolidated VIEs, was $6.5 billion and $5.9 billion as of May 1, 2020 and January 31, 2020, respectively.  The Company’s risk of loss related to securitized receivables is limited to the amount by which the Company’s right to receive collections for assets securitized exceeds the amount required to pay interest, principal, and fees and expenses related to the asset-backed securities.  The Company provides credit enhancement to the securitizations in the form of over-collateralization.

[0001571996-20-000034:notes:94]
Customer Receivables Sales

[0001571996-20-000034:notes:95]
To manage certain concentrations of customer credit exposure, the Company may sell selected fixed-term customer receivables to unrelated third parties on a periodic basis, without recourse.  The amount of customer receivables sold for this purpose was $21 million and $101 million for the three months ended May 1, 2020 and May 3, 2019, respectively.  The Company’s continuing involvement in the above mentioned customer receivables is primarily limited to servicing arrangements.


## us-gaap:ScheduleOfDebtTableTextBlock

[0001571996-20-000034:notes:96]
The following table presents DFS debt as of the dates indicated.  The table excludes the allocated portion of the Company’s other borrowings, which represents the additional amount considered to fund the DFS business.

[0001571996-20-000034:notes:97]
The following table presents the Company’s outstanding debt as of the dates indicated:

[0001571996-20-000034:notes:98]
|  | May 1, 2020 |  | January 31, 2020 |
|  | (in millions) |
| Secured Debt |  |  |  |
| Senior Secured Credit Facilities: |  |  |  |
| 2.75% Term Loan B-1 Facility due September 2025 | $ | 4,726 |  |  | $ | 4,738 |  |
| 2.16% Term Loan A-4 Facility due December 2023 | 679 |  |  | 679 |  |
| 2.32% Term Loan A-6 Facility due March 2024 | 3,452 |  |  | 3,497 |  |
| First Lien Notes: |  |  |  |
| 4.42% due June 2021 | 4,500 |  |  | 4,500 |  |
| 5.45% due June 2023 | 3,750 |  |  | 3,750 |  |
| 4.00% due July 2024 | 1,000 |  |  | 1,000 |  |
| 5.85% due July 2025 | 1,000 |  |  | — |  |
| 6.02% due June 2026 | 4,500 |  |  | 4,500 |  |
| 4.90% due October 2026 | 1,750 |  |  | 1,750 |  |
| 6.10% due July 2027 | 500 |  |  | — |  |
| 5.30% due October 2029 | 1,750 |  |  | 1,750 |  |
| 6.20% due July 2030 | 750 |  |  | — |  |
| 8.10% due July 2036 | 1,500 |  |  | 1,500 |  |
| 8.35% due July 2046 | 2,000 |  |  | 2,000 |  |
| Unsecured Debt |  |  |  |
| Unsecured Notes and Debentures: |  |  |  |
| 4.625% due April 2021 | 400 |  |  | 400 |  |
| 7.10% due April 2028 | 300 |  |  | 300 |  |
| 6.50% due April 2038 | 388 |  |  | 388 |  |
| 5.40% due September 2040 | 264 |  |  | 264 |  |
| Senior Notes: |  |  |  |
| 5.875% due June 2021 | 1,075 |  |  | 1,075 |  |
| 7.125% due June 2024 | 1,625 |  |  | 1,625 |  |
| EMC Notes: |  |  |  |
| 2.650% due June 2020 | 600 |  |  | 600 |  |
| 3.375% due June 2023 | 1,000 |  |  | 1,000 |  |
| Debt of Public Subsidiary |  |  |  |
| VMware Notes: |  |  |  |
| 2.30% due August 2020 | 1,250 |  |  | 1,250 |  |
| 2.95% due August 2022 | 1,500 |  |  | 1,500 |  |
| 4.50% due May 2025 | 750 |  |  | — |  |
| 4.65% due May 2027 | 500 |  |  | — |  |
| 3.90% due August 2027 | 1,250 |  |  | 1,250 |  |
| 4.70% due May 2030 | 750 |  |  | — |  |
| VMware Term Loan Facility | 1,500 |  |  | 1,500 |  |
| DFS Debt (Note 4) | 8,269 |  |  | 7,765 |  |
| Other |  |  |  |
| 4.03% Margin Loan Facility due April 2022 | 4,000 |  |  | 4,000 |  |
| Other | 69 |  |  | 84 |  |
| Total debt, principal amount | $ | 57,347 |  |  | $ | 52,665 |  |

[0001571996-20-000034:notes:99]
|  | May 1, 2020 |  | January 31, 2020 |
|  | (in millions) |
| Total debt, principal amount | $ | 57,347 |  |  | $ | 52,665 |  |
| Unamortized discount, net of unamortized premium | (234 | ) |  | (241 | ) |
| Debt issuance costs | (385 | ) |  | (368 | ) |
| Total debt, carrying value | $ | 56,728 |  |  | $ | 52,056 |  |
| Total short-term debt, carrying value | $ | 8,375 |  |  | $ | 7,737 |  |
| Total long-term debt, carrying value | $ | 48,353 |  |  | $ | 44,319 |  |


## us-gaap:LesseeOperatingLeasesTextBlock

[0001571996-20-000034:notes:100]
[same as prior period, unchanged from 0001571996-19-000051:notes:106]

[0001571996-20-000034:notes:101]
The Company enters into leasing transactions in which the Company is the lessee.  These lease contracts are typically classified as operating leases.  The Company’s lease contracts are generally for office buildings used to conduct its business, and the determination of whether such contracts contain leases generally does not require significant estimates or judgments.  The Company also leases certain global logistics warehouses, employee vehicles, and equipment.  As of May 1, 2020, the remaining terms of the Company’s leases range from less than one month to 26 years.

[0001571996-20-000034:notes:102]
[same as prior period, unchanged from 0001571996-19-000051:notes:108]

[0001571996-20-000034:notes:103]
In adopting the current lease accounting standard effective February 2, 2019, the Company elected to apply a transition method that does not require the retrospective application to periods prior to the effective date.  Financial information associated with the Company’s leases in which the Company is the lessee is contained in this Note.  As of May 1, 2020 and January 31, 2020, there were no material finance leases for which the Company was a lessee.

[0001571996-20-000034:notes:104]
[same as prior period, unchanged from 0001571996-19-000051:notes:110]

[0001571996-20-000034:notes:105]
|  | Three Months Ended |
|  | May 1, 2020 |  | May 3, 2019 |
|  | (in millions) |
| Operating lease costs | $ | 131 |  |  | $ | 117 |  |
| Variable costs | 44 |  |  | 38 |  |
| Total lease costs | $ | 175 |  |  | $ | 155 |  |

[0001571996-20-000034:notes:106]
During both the three months ended May 1, 2020 and May 3, 2019, sublease income, finance lease costs, and short-term lease costs were immaterial.

[0001571996-20-000034:notes:107]
The following table presents supplemental information related to operating leases included in the Condensed Consolidated Statements of Financial Position as of the dates indicated:

[0001571996-20-000034:notes:108]
|  | Classification |  | May 1, 2020 |  | January 31, 2020 |
|  |  |  | (in millions, except for term and discount rate) |
| Operating lease right of use (“ROU”) assets | Other non-current assets |  | $ | 1,745 |  |  | $ | 1,780 |  |
| Current operating lease liabilities | Accrued and other current liabilities |  | $ | 403 |  |  | $ | 432 |  |
| Non-current operating lease liabilities | Other non-current liabilities |  | 1,350 |  |  | 1,360 |  |
| Total operating lease liabilities |  |  | $ | 1,753 |  |  | $ | 1,792 |  |
| Weighted-average remaining lease term (in years) |  |  | 8.70 |  |  | 8.57 |  |
| Weighted-average discount rate |  |  | 3.84 | % |  | 3.81 | % |

[0001571996-20-000034:notes:109]
The following table presents supplemental cash flow information related to leases for the periods indicated:

[0001571996-20-000034:notes:110]
|  | Three Months Ended |
|  | May 1, 2020 |  | May 3, 2019 |
|  | (in millions) |
| Cash paid for amounts included in the measurement of lease liabilities — operating cash outflows from operating leases | $ | 131 |  |  | $ | 122 |  |
| ROU assets obtained in exchange for new operating lease liabilities | $ | 120 |  |  | $ | 42 |  |

[0001571996-20-000034:notes:111]
[same as prior period, unchanged from 0001571996-19-000051:notes:117]

[0001571996-20-000034:notes:112]
|  | May 1, 2020 |
| Fiscal Years | (in millions) |
| Fiscal 2021 (remaining nine months) | $ | 337 |  |
| Fiscal 2022 | 401 |  |
| Fiscal 2023 | 315 |  |
| Fiscal 2024 | 217 |  |
| Fiscal 2025 | 147 |  |
| Thereafter | 701 |  |
| Total lease payments | $ | 2,118 |  |
| Less: Imputed interest | (365 | ) |
| Total | $ | 1,753 |  |
| Current operating lease liabilities | $ | 403 |  |
| Non-current operating lease liabilities | $ | 1,350 |  |

[0001571996-20-000034:notes:113]
The amount of future lease commitments after Fiscal 2025 is primarily for the ground lease on VMware, Inc.’s Palo Alto, California headquarter facilities, which expires in Fiscal 2047.

[0001571996-20-000034:notes:114]
As of May 1, 2020, the Company has additional operating leases that have not yet commenced of $697 million.  These operating leases will commence during Fiscal 2021 with lease terms of one year to 16 years.


## us-gaap:DebtDisclosureTextBlock

[0001571996-20-000034:notes:115]
NOTE 6 — DEBT

[0001571996-20-000034:notes:116]
During the three months ended May 1, 2020, the net increase in the Company’s debt balance was primarily due to new debt issuances of $2.25 billion of First Lien Notes on April 9, 2020 and $2.0 billion of VMware Notes on April 7, 2020, both described below, and an additional $0.5 billion, net, in DFS debt to support the expansion of its financing receivables portfolio.

[0001571996-20-000034:notes:117]
Secured Debt

[0001571996-20-000034:notes:118]
Senior Secured Credit Facilities — The Company has entered into a credit agreement that provides for senior secured credit facilities (the “Senior Secured Credit Facilities”) comprising (a) term loan facilities and (b) a senior secured Revolving Credit Facility, which provides for a borrowing capacity of up to $4.5 billion for general corporate purposes, including capacity for up to $0.5 billion of letters of credit and for borrowings of up to $0.4 billion under swing-line loans.

[0001571996-20-000034:notes:119]
As of May 1, 2020, available borrowings under the Revolving Credit Facility totaled $4.5 billion.  The Senior Secured Credit Facilities provide that the borrowers have the right at any time, subject to customary conditions, to request incremental term loans or incremental revolving commitments.

[0001571996-20-000034:notes:120]
Borrowings under the Senior Secured Credit Facilities bear interest at a rate per annum equal to an applicable margin, plus, at the borrowers’ option, either (a) a base rate, or (b) the London Interbank Offered Rate (“LIBOR”).  The Term Loan B-1 Facility bears interest at LIBOR plus an applicable margin of 2.00% or a base rate plus an applicable margin of 1.00%.  The Term Loan A-4 Facility and the Term Loan A-6 Facility bear interest at LIBOR plus an applicable margin ranging from 1.25% to 2.00% or a base rate plus an applicable margin ranging from 0.25% to 1.00%.  Interest is payable, in the case of loans bearing interest based on LIBOR, at the end of each interest period (but at least every three months), in arrears and, in the case of loans bearing interest based on the base rate, quarterly in arrears.

[0001571996-20-000034:notes:121]
The Term Loan B-1 Facility amortizes in equal quarterly installments in aggregate annual amounts equal to 1% of the original principal amount.  The Term Loan A-4 Facility amortizes in equal quarterly installments in aggregate annual amounts equal to 5% of the original principal amount in each of the first four years after the facility closing date of December 20, 2018, and 80% of the original principal amount in the fifth year after December 20, 2018.  The Term Loan A-6 Facility amortizes in equal quarterly installments in aggregate annual amounts equal to 5% of the original principal amount in each of the first four years after the facility closing date of March 13, 2019, and 80% of the original principal amount in the fifth year after March 13, 2019.  The Revolving Credit Facility has no amortization.

[0001571996-20-000034:notes:122]
The borrowers may voluntarily repay outstanding loans under the term loan facilities and the Revolving Credit Facility at any time without premium or penalty, other than customary “breakage” costs.

[0001571996-20-000034:notes:123]
All obligations of the borrowers under the Senior Secured Credit Facilities and certain swap agreements, cash management arrangements, and certain letters of credit provided by any lender or agent party to the Senior Secured Credit Facilities or any of its affiliates and certain other persons are secured by (a) a first-priority security interest in certain tangible and intangible assets of the borrowers and the guarantors and (b) a first-priority pledge of 100% of the capital stock of the borrowers, Dell Inc., a wholly‑owned subsidiary of the Company (“Dell”), and each wholly-owned material restricted subsidiary of the borrowers and the guarantors, in each case subject to certain thresholds, exceptions, and permitted liens.

[0001571996-20-000034:notes:124]
First Lien Notes — Dell International L.L.C. and EMC Corporation, both of which are wholly-owned subsidiaries of Dell Technologies Inc., completed private offerings of multiple series of senior secured notes (collectively, the “First Lien Notes”) which were issued on June 1, 2016, March 20, 2019, and April 9, 2020 in aggregate principal amounts of $20.0 billion, $4.5 billion, and $2.25 billion, respectively.  Interest on the First Lien Notes is payable semiannually.  The First Lien Notes are secured on a pari passu basis with the Senior Secured Credit Facilities, on a first-priority basis by substantially all of the tangible and intangible assets of the issuers and guarantors that secure obligations under the Senior Secured Credit Facilities, including pledges of all capital stock of the issuers, Dell, and certain wholly-owned material subsidiaries of the issuers and the guarantors, subject to certain exceptions.

[0001571996-20-000034:notes:125]
The Company has agreed to use commercially reasonable efforts to register with the SEC notes having terms substantially identical to the terms of the First Lien Notes as part of an offer to exchange such registered notes for the First Lien Notes.  The Company will be obligated to pay additional interest on the First Lien Notes if it fails to consummate such an exchange offer within five years after the closing date of the EMC merger transaction, in the case of the First Lien Notes issued on June 1, 2016 and within five years after their respective issue dates, in the case of the First Lien Notes issued on March 20, 2019 and April 9, 2020.

[0001571996-20-000034:notes:126]
China Revolving Credit Facility — During the fiscal year ended January 31, 2020, the Company renewed its credit agreement for a China revolving credit facility with a bank lender, which provided an uncommitted line with an aggregate principal amount not to exceed $500 million at an interest rate of LIBOR plus 0.6% per annum.  The facility was terminated upon expiration on February 26, 2020.

[0001571996-20-000034:notes:127]
Unsecured Debt

[0001571996-20-000034:notes:128]
Unsecured Notes and Debentures — The Company has outstanding unsecured notes and debentures (collectively, the “Unsecured Notes and Debentures”) that were issued by Dell prior to the acquisition of Dell by Dell Technologies Inc. in the going-private transaction that closed in October 2013.  Interest on these borrowings is payable semiannually.

[0001571996-20-000034:notes:129]
Senior Notes — The senior unsecured notes (collectively, the “Senior Notes”) were issued on June 22, 2016 in an aggregate principal amount of $3.25 billion.  Interest on these borrowings is payable semiannually.

[0001571996-20-000034:notes:130]
EMC Notes — On September 7, 2016, EMC had outstanding $2.5 billion aggregate principal amount of its 1.875% Notes due June 2018, which the Company fully repaid during the three months ended August 3, 2018, $2.0 billion aggregate principal amount of its 2.650% Notes due June 2020, and $1.0 billion aggregate principal amount of its 3.375% Notes due June 2023 (collectively, the “EMC Notes”).  Interest on these borrowings is payable semiannually.

[0001571996-20-000034:notes:131]
VMware Notes — VMware, Inc. completed public offerings of unsecured senior notes in the aggregate amounts of $4.0 billion and $2.0 billion on August 21, 2017 and April 7, 2020, respectively (the “VMware Notes”).  None of the net proceeds of such borrowings will be made available to support the operations or satisfy any corporate purposes of Dell Technologies, other than the operations and corporate purposes of VMware, Inc. and VMware, Inc.’s subsidiaries.  Interest on these borrowings is payable semiannually.

[0001571996-20-000034:notes:132]
VMware Revolving Credit Facility — On September 12, 2017, VMware, Inc. entered into an unsecured credit agreement, establishing a revolving credit facility (the “VMware Revolving Credit Facility”) with a syndicate of lenders that provides the company with a borrowing capacity of up to $1.0 billion for VMware, Inc. general corporate purposes.  Commitments under the VMware Revolving Credit Facility are available for a period of five years, which may be extended, subject to the satisfaction of certain conditions, by up to two one year periods.  The credit agreement contains certain representations, warranties, and covenants.  Commitment fees, interest rates, and other terms of borrowing under the VMware Revolving Credit Facility may vary based on VMware, Inc.’s external credit ratings.  None of the net proceeds of such borrowings will be made available to support the operations or satisfy any corporate purposes of Dell Technologies, other than the operations and corporate purposes of VMware, Inc. and VMware, Inc.’s subsidiaries.  As of May 1, 2020, there were no outstanding borrowings under the VMware Revolving Credit Facility.

[0001571996-20-000034:notes:133]
VMware Term Loan Facility — On September 26, 2019, VMware, Inc. entered into a senior unsecured term loan facility (the “VMware Term Loan Facility”) with a syndicate of lenders that provided VMware, Inc. with a borrowing capacity of up to $2.0 billion through February 7, 2020, for VMware, Inc. general corporate purposes.  The VMware Term Loan Facility matures on the 364th day following the initial funding under the facility.  The VMware Term Loan Facility bears interest at LIBOR plus 0.75% to 1.25%, or an alternative base rate plus 0.00% to 0.25%, depending on VMware Inc.’s external credit ratings.

[0001571996-20-000034:notes:134]
As of May 1, 2020 and January 31, 2020, the outstanding borrowings under the VMware Term Loan Facility were $1.5 billion, with no remaining amount available for additional borrowings.  The VMware Term Loan Facility contains certain representations, warranties, and covenants.  None of the net proceeds of such borrowings will be made available to support the operations or satisfy any corporate purposes of Dell Technologies, other than the operations and corporate purposes of VMware, Inc. and VMware, Inc.’s subsidiaries.

[0001571996-20-000034:notes:135]
See Note 4 and Note 7 of the Notes to the Condensed Consolidated Financial Statements, respectively, for discussion of DFS debt and the interest rate swap agreements that hedge a portion of that debt.

[0001571996-20-000034:notes:136]
Other

[0001571996-20-000034:notes:137]
Margin Loan Facility — On April 12, 2017, the Company entered into the Margin Loan Facility in an aggregate principal amount of $2.0 billion, under which VMW Holdco LLC, a wholly-owned subsidiary of EMC, is the borrower.  In connection with the Class V transaction described in Note 1 of the Notes to the Condensed Consolidated Financial Statements, on December 20, 2018, the Company amended the Margin Loan Facility to increase the aggregate principal amount to $3.35 billion.  In connection with obtaining the Term Loan A-6 Facility during the fiscal year ended January 31, 2020, the Company increased the aggregate principal amount of the Margin Loan Facility to $4.0 billion.

[0001571996-20-000034:notes:138]
During the three months ended May 1, 2020, due to volatility in the U.S. stock market resulting from the outbreak of COVID-19, VMware Holdco LLC proactively pledged additional shares of VMware, Inc. common stock to secure its obligations under the Margin Loan Facility agreement.  This resulted in an aggregate number of shares pledged of approximately 76 million shares of Class B common stock of VMware, Inc. and approximately 24 million shares of Class A common stock of VMware, Inc.

[0001571996-20-000034:notes:139]
Loans under the Margin Loan Facility bear interest at a rate per annum payable, at the borrower’s option, either at (a) a base rate plus 1.25% per annum or (b) a LIBOR-based rate plus 2.25% per annum.  Interest under the Margin Loan Facility is payable quarterly.  The Margin Loan Facility will mature in April 2022.  The borrower may voluntarily repay outstanding loans under the Margin Loan Facility at any time without premium or penalty, other than customary “breakage” costs, subject to certain minimum threshold amounts for prepayment.

[0001571996-20-000034:notes:140]
Aggregate Future Maturities

[0001571996-20-000034:notes:141]
The following table presents the aggregate future maturities of the Company’s debt as of May 1, 2020 for the periods indicated:

[0001571996-20-000034:notes:142]
|  | Maturities by Fiscal Year |
|  | 2021 (remaining nine months) |  | 2022 |  | 2023 |  | 2024 |  | 2025 |  | Thereafter |  | Total |
|  | (in millions) |
| Senior Secured Credit Facilities and First Lien Notes | $ | 172 |  |  | $ | 4,672 |  |  | $ | 286 |  |  | $ | 6,702 |  |  | $ | 1,775 |  |  | $ | 18,250 |  |  | $ | 31,857 |  |
| Unsecured Notes and Debentures | — |  |  | 400 |  |  | — |  |  | — |  |  | — |  |  | 952 |  |  | 1,352 |  |
| Senior Notes and EMC Notes | 600 |  |  | 1,075 |  |  | — |  |  | 1,000 |  |  | 1,625 |  |  | — |  |  | 4,300 |  |
| VMware Notes | 2,750 |  |  | — |  |  | 1,500 |  |  | — |  |  | — |  |  | 3,250 |  |  | 7,500 |  |
| DFS Debt | 3,661 |  |  | 2,537 |  |  | 1,877 |  |  | 157 |  |  | 37 |  |  | — |  |  | 8,269 |  |
| Margin Loan Facility | — |  |  | — |  |  | 4,000 |  |  | — |  |  | — |  |  | — |  |  | 4,000 |  |
| Other | 8 |  |  | 6 |  |  | 7 |  |  | 8 |  |  | 7 |  |  | 33 |  |  | 69 |  |
| Total maturities, principal amount | 7,191 |  |  | 8,690 |  |  | 7,670 |  |  | 7,867 |  |  | 3,444 |  |  | 22,485 |  |  | 57,347 |  |
| Associated carrying value adjustments | (2 | ) |  | (43 | ) |  | (24 | ) |  | (47 | ) |  | (91 | ) |  | (412 | ) |  | (619 | ) |
| Total maturities, carrying value amount | $ | 7,189 |  |  | $ | 8,647 |  |  | $ | 7,646 |  |  | $ | 7,820 |  |  | $ | 3,353 |  |  | $ | 22,073 |  |  | $ | 56,728 |  |

[0001571996-20-000034:notes:143]
Covenants and Unrestricted Net Assets — The credit agreement for the Senior Secured Credit Facilities contains customary negative covenants that generally limit the ability of Denali Intermediate Inc., a wholly-owned subsidiary of Dell Technologies (“Dell Intermediate”), Dell, and Dell’s and Denali Intermediate’s other restricted subsidiaries to incur debt, create liens, make fundamental changes, enter into asset sales, make certain investments, pay dividends or distribute or redeem certain equity interests, prepay or redeem certain debt, and enter into certain transactions with affiliates.  The indenture governing the Senior Notes contains customary negative covenants that generally limit the ability of Denali Intermediate, Dell, and Dell’s and Denali Intermediate’s other restricted subsidiaries to incur additional debt or issue certain preferred shares, pay dividends on or make other distributions in respect of capital stock or make other restricted payments, make certain investments, sell or transfer certain assets, create liens on certain assets to secure debt, consolidate, merge, sell, or otherwise dispose of all or substantially all assets, enter into certain transactions with affiliates, and designate subsidiaries as unrestricted subsidiaries.  The negative covenants under such credit agreements and indenture are subject to certain exceptions, qualifications, and “baskets.”  The indentures governing the First Lien Notes, the Unsecured Notes and Debentures, and the EMC Notes variously impose limitations, subject to specified exceptions, on creating certain liens, entering into sale and lease-back transactions, and entering into certain asset sales.  The foregoing credit agreements and indentures contain customary events of default, including failure to make required payments, failure to comply with covenants, and the occurrence of certain events of bankruptcy and insolvency.

[0001571996-20-000034:notes:144]
As of May 1, 2020, the Company had certain consolidated subsidiaries that were designated as unrestricted subsidiaries for all purposes of the applicable credit agreements and the indentures governing the First Lien Notes and the Senior Notes.  Substantially all of the net assets of the Company’s consolidated subsidiaries were restricted, with the exception of the Company’s unrestricted subsidiaries, primarily VMware, Inc., Secureworks, and their respective subsidiaries, as of May 1, 2020.

[0001571996-20-000034:notes:145]
The Term Loan A-4 Facility, the Term Loan A-6 Facility, and the Revolving Credit Facility are subject to a first lien leverage ratio covenant that is tested at the end of each fiscal quarter of Dell with respect to Dell’s preceding four fiscal quarters.  The Company was in compliance with all financial covenants as of May 1, 2020.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001571996-20-000034:notes:146]
[same as prior period, unchanged from 0001571996-19-000051:notes:161]

[0001571996-20-000034:notes:147]
[same as prior period, unchanged from 0001571996-19-000051:notes:162]

[0001571996-20-000034:notes:148]
[same as prior period, unchanged from 0001571996-19-000051:notes:163]

[0001571996-20-000034:notes:149]
[same as prior period, unchanged from 0001571996-19-000051:notes:164]

[0001571996-20-000034:notes:150]
The Company uses foreign currency forward and option contracts designated as cash flow hedges to protect against the foreign currency exchange rate risks inherent in its forecasted transactions denominated in currencies other than the U.S. Dollar.  Hedge accounting is applied based upon the criteria established by accounting guidance for derivative instruments and hedging activities.  The risk of loss associated with purchased options is limited to premium amounts paid for the option contracts.  The risk of loss associated with forward contracts is equal to the exchange rate differential from the time the contract is entered into until the time it is settled.  The majority of these contracts typically expire in twelve months or less.

[0001571996-20-000034:notes:151]
During the three months ended May 1, 2020 and May 3, 2019, the Company did not discontinue any cash flow hedges related to foreign exchange contracts that had a material impact on the Company’s results of operations due to the probability that the forecasted cash flows would not occur.

[0001571996-20-000034:notes:152]
[same as prior period, unchanged from 0001571996-19-000051:notes:167]

[0001571996-20-000034:notes:153]
[same as prior period, unchanged from 0001571996-19-000051:notes:168]

[0001571996-20-000034:notes:154]
[same as prior period, unchanged from 0001571996-19-000051:notes:169]

[0001571996-20-000034:notes:155]
[same as prior period, unchanged from 0001571996-19-000051:notes:170]

[0001571996-20-000034:notes:156]
[same as prior period, unchanged from 0001571996-19-000051:notes:171]

[0001571996-20-000034:notes:157]
[same as prior period, unchanged from 0001571996-19-000051:notes:172]

[0001571996-20-000034:notes:158]
[same as prior period, unchanged from 0001571996-19-000051:notes:173]

[0001571996-20-000034:notes:159]
[same as prior period, unchanged from 0001571996-19-000051:notes:174]

[0001571996-20-000034:notes:160]
|  | May 1, 2020 |  | January 31, 2020 |
|  | (in millions) |
| Foreign exchange contracts: |  |  |  |  |  |
| Designated as cash flow hedging instruments | $ | 8,910 |  |  | $ | 8,703 |  |
| Non-designated as hedging instruments | 7,490 |  |  | 7,711 |  |
| Total | $ | 16,400 |  |  | $ | 16,414 |  |
| Interest rate contracts: |  |  |  |
| Non-designated as hedging instruments | $ | 4,559 |  |  | $ | 4,043 |  |

[0001571996-20-000034:notes:161]
[same as prior period, unchanged from 0001571996-19-000051:notes:176]

[0001571996-20-000034:notes:162]
| Derivatives in Cash Flow Hedging Relationships |  | Gain (Loss) Recognized in Accumulated OCI, Net of Tax, on Derivatives |  | Location of Gain (Loss) Reclassified from Accumulated OCI into Income |  | Gain (Loss) Reclassified from Accumulated OCI into Income |
|  |  | (in millions) |  |  |  | (in millions) |
| For the three months ended May 1, 2020 |
|  |  |  |  |  | Total net revenue |  | $ | 96 |  |
| Foreign exchange contracts |  | $ | 167 |  |  | Total cost of net revenue |  | 4 |  |
| Interest rate contracts |  | — |  |  | Interest and other, net |  | — |  |
| Total |  | $ | 167 |  |  |  |  | $ | 100 |  |
| For the three months ended May 3, 2019 |
|  |  |  |  |  | Total net revenue |  | $ | 58 |  |
| Foreign exchange contracts |  | $ | 152 |  |  | Total cost of net revenue |  | — |  |
| Interest rate contracts |  | — |  |  | Interest and other, net |  | — |  |
| Total |  | $ | 152 |  |  |  |  | $ | 58 |  |

[0001571996-20-000034:notes:163]
[same as prior period, unchanged from 0001571996-19-000051:notes:178]

[0001571996-20-000034:notes:164]
|  |  | Three Months Ended |  |  |
|  |  | May 1, 2020 |  | May 3, 2019 |  | Location of Gain (Loss) Recognized |
|  |  | (in millions) |  |  |
| Gain (Loss) Recognized: |  |  |  |  |  |  |
| Foreign exchange contracts |  | $ | 52 |  |  | $ | (66 | ) |  | Interest and other, net |
| Interest rate contracts |  | (39 | ) |  | (7 | ) |  | Interest and other, net |
| Total |  | $ | 13 |  |  | $ | (73 | ) |  |  |

[0001571996-20-000034:notes:165]
[same as prior period, unchanged from 0001571996-19-000051:notes:180]

[0001571996-20-000034:notes:166]
[same as prior period, unchanged from 0001571996-19-000051:notes:181]

[0001571996-20-000034:notes:167]
|  | May 1, 2020 |
|  | Other CurrentAssets |  | Other Non-Current Assets |  | Other CurrentLiabilities |  | Other Non-CurrentLiabilities |  | TotalFair Value |
|  | (in millions) |
| Derivatives designated as hedging instruments: |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts in an asset position | $ | 206 |  |  | $ | — |  |  | $ | 7 |  |  | $ | — |  |  | $ | 213 |  |
| Foreign exchange contracts in a liability position | (21 | ) |  | — |  |  | (20 | ) |  | — |  |  | (41 | ) |
| Net asset (liability) | 185 |  |  | — |  |  | (13 | ) |  | — |  |  | 172 |  |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts in an asset position | 410 |  |  | — |  |  | 5 |  |  | — |  |  | 415 |  |
| Foreign exchange contracts in a liability position | (246 | ) |  | — |  |  | (44 | ) |  | (5 | ) |  | (295 | ) |
| Interest rate contracts in an asset position | — |  |  | 3 |  |  | — |  |  | — |  |  | 3 |  |
| Interest rate contracts in a liability position | — |  |  | — |  |  | — |  |  | (57 | ) |  | (57 | ) |
| Net asset (liability) | 164 |  |  | 3 |  |  | (39 | ) |  | (62 | ) |  | 66 |  |
| Total derivatives at fair value | $ | 349 |  |  | $ | 3 |  |  | $ | (52 | ) |  | $ | (62 | ) |  | $ | 238 |  |
|  | January 31, 2020 |
|  | Other CurrentAssets |  | Other Non-Current Assets |  | Other CurrentLiabilities |  | Other Non-CurrentLiabilities |  | TotalFair Value |
|  | (in millions) |
| Derivatives designated as hedging instruments: |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts in an asset position | $ | 108 |  |  | $ | — |  |  | $ | 15 |  |  | $ | — |  |  | $ | 123 |  |
| Foreign exchange contracts in a liability position | (2 | ) |  | — |  |  | (3 | ) |  | — |  |  | (5 | ) |
| Net asset (liability) | 106 |  |  | — |  |  | 12 |  |  | — |  |  | 118 |  |
| Derivatives not designated as hedging instruments: |
| Foreign exchange contracts in an asset position | 136 |  |  | — |  |  | 39 |  |  | — |  |  | 175 |  |
| Foreign exchange contracts in a liability position | (162 | ) |  | — |  |  | (81 | ) |  | (6 | ) |  | (249 | ) |
| Interest rate contracts in an asset position | — |  |  | 1 |  |  | — |  |  | — |  |  | 1 |  |
| Interest rate contracts in a liability position | — |  |  | — |  |  | — |  |  | (32 | ) |  | (32 | ) |
| Net asset (liability) | (26 | ) |  | 1 |  |  | (42 | ) |  | (38 | ) |  | (105 | ) |
| Total derivatives at fair value | $ | 80 |  |  | $ | 1 |  |  | $ | (30 | ) |  | $ | (38 | ) |  | $ | 13 |  |

[0001571996-20-000034:notes:168]
[same as prior period, unchanged from 0001571996-19-000051:notes:183]

[0001571996-20-000034:notes:169]
|  | May 1, 2020 |
|  | Gross Amounts of Recognized Assets/ (Liabilities) |  | Gross Amounts Offset in the Statement of Financial Position |  | Net Amounts of Assets/ (Liabilities) Presented in the Statement of Financial Position |  | Gross Amounts not Offset in the Statement of Financial Position |  | Net Amount |
|  | Financial Instruments |  | Cash Collateral Received or Pledged |  |
|  | (in millions) |
| Derivative instruments: |  |  |  |  |  |  |  |  |  |  |  |
| Financial assets | $ | 631 |  |  | $ | (279 | ) |  | $ | 352 |  |  | $ | — |  |  | $ | — |  |  | $ | 352 |  |
| Financial liabilities | (393 | ) |  | 279 |  |  | (114 | ) |  | — |  |  | 10 |  |  | (104 | ) |
| Total derivative instruments | $ | 238 |  |  | $ | — |  |  | $ | 238 |  |  | $ | — |  |  | $ | 10 |  |  | $ | 248 |  |
|  | January 31, 2020 |
|  | Gross Amounts of Recognized Assets/ (Liabilities) |  | Gross Amounts Offset in the Statement of Financial Position |  | Net Amounts of Assets/ (Liabilities) Presented in the Statement of Financial Position |  | Gross Amounts not Offset in the Statement of Financial Position |  | Net Amount |
|  | Financial Instruments |  | Cash Collateral Received or Pledged |  |
|  | (in millions) |
| Derivative instruments: |  |  |  |  |  |  |  |  |  |  |  |
| Financial assets | $ | 299 |  |  | $ | (218 | ) |  | $ | 81 |  |  | $ | — |  |  | $ | — |  |  | $ | 81 |  |
| Financial liabilities | (286 | ) |  | 218 |  |  | (68 | ) |  | — |  |  | 15 |  |  | (53 | ) |
| Total derivative instruments | $ | 13 |  |  | $ | — |  |  | $ | 13 |  |  | $ | — |  |  | $ | 15 |  |  | $ | 28 |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001571996-20-000034:notes:170]
NOTE 8 — BUSINESS COMBINATIONS, GOODWILL AND INTANGIBLE ASSETS

[0001571996-20-000034:notes:171]
Business Combinations

[0001571996-20-000034:notes:172]
VMware, Inc. Acquisition

[0001571996-20-000034:notes:173]
Nyansa, Inc. — During the three months ended May 1, 2020, VMware, Inc. completed the acquisition of Nyansa, Inc., a developer of artificial intelligence-based network analytics, to accelerate the delivery of end-to-end monitoring and troubleshooting capabilities within VMware SD-WAN by VeloCloud.  The total purchase price, net of cash acquired, was $38 million.  The purchase price primarily included $14 million of identifiable intangible assets and $24 million of goodwill that is not expected to be deductible for tax purposes.  The identifiable intangible assets, which primarily consisted of completed technology, have estimated useful lives of one year to four years.

[0001571996-20-000034:notes:174]
[same as prior period, unchanged from 0001571996-19-000051:notes:186]

[0001571996-20-000034:notes:175]
The Infrastructure Solutions Group, Client Solutions Group, and VMware reporting units are consistent with the reportable segments identified in Note 17 of the Notes to the Condensed Consolidated Financial Statements.  Offerings within Other businesses as defined below represent separate reporting units.

[0001571996-20-000034:notes:176]
The following table presents goodwill allocated to the Company’s reportable segments and changes in the carrying amount of goodwill as of the dates indicated:

[0001571996-20-000034:notes:177]
|  | Infrastructure Solutions Group |  | Client Solutions Group |  | VMware |  | Other Businesses (a) |  | Total |
|  | (in millions) |
| Balance as of January 31, 2020 | $ | 15,089 |  |  | $ | 4,237 |  |  | $ | 20,532 |  |  | $ | 1,833 |  |  | $ | 41,691 |  |
| Goodwill acquired (b) | — |  |  | — |  |  | 24 |  |  | — |  |  | 24 |  |
| Impact of foreign currency translation | (91 | ) |  | — |  |  | — |  |  | (17 | ) |  | (108 | ) |
| Reclassification to assets held for sale (c) | — |  |  | — |  |  | — |  |  | (1,359 | ) |  | (1,359 | ) |
| Balance as of May 1, 2020 | $ | 14,998 |  |  | $ | 4,237 |  |  | $ | 20,556 |  |  | $ | 457 |  |  | $ | 40,248 |  |

[0001571996-20-000034:notes:178]
| (a) | As of May 1, 2020, goodwill allocated to Other businesses consists of Secureworks, Virtustream, and Boomi. |

[0001571996-20-000034:notes:179]
| (b) | VMware, Inc. business combination completed during the three months ended May 1, 2020, as discussed above. |

[0001571996-20-000034:notes:180]
| (c) | During the three months ended May 1, 2020, RSA Security’s goodwill was reclassified to current assets held for sale on the Condensed Consolidated Statements of Financial Position due to the Company’s entry into a definitive agreement to sell RSA Security. See Note 1 of the Notes to the Condensed Consolidated Financial Statements for additional information about the pending sale of RSA Security. |

[0001571996-20-000034:notes:181]
Goodwill Impairment Tests — Goodwill and indefinite-lived intangible assets are tested for impairment annually during the third fiscal quarter and whenever events or circumstances may indicate that an impairment has occurred.  As a result of the changes in the current economic environment related to the COVID-19 pandemic, the Company considered whether there was a potential triggering event requiring the evaluation of whether goodwill of any of the reporting units should be tested for impairment.  The Company determined there was no triggering event and no impairment test was performed as of May 1, 2020.

[0001571996-20-000034:notes:182]
For our annual impairment review in the third quarter of Fiscal 2020, the Company elected to bypass the assessment of qualitative factors to determine whether it was more likely than not that the fair value of a reporting unit was less than its carrying amount, including goodwill.  In electing to bypass the qualitative assessment, the Company proceeded directly to performing a quantitative goodwill impairment test to measure the fair value of each goodwill reporting unit relative to its carrying amount, and to determine the amount of goodwill impairment loss to be recognized, if any.

[0001571996-20-000034:notes:183]
Management exercised significant judgment related to the above assessment, including the identification of goodwill reporting units, assignment of assets and liabilities to goodwill reporting units, assignment of goodwill to reporting units, and determination of the fair value of each goodwill reporting unit.  The fair value of each goodwill reporting unit is generally estimated using a combination of public company multiples and discounted cash flow methodologies, unless the reporting unit relates to a publicly-traded entity (VMware, Inc. or Secureworks), in which case the fair value is determined based primarily on the public company market valuation.  The discounted cash flow and public company multiples methodologies require significant judgment, including estimation of future cash flows, which is dependent on internal forecasts, current and anticipated economic conditions and trends, selection of market multiples through assessment of the reporting unit’s performance relative to peer competitors, the estimation of the long-term revenue growth rate and discount rate of the Company’s business, and the determination of the Company’s weighted average cost of capital.  Changes in these estimates and assumptions could materially affect the fair value of the goodwill reporting unit, potentially resulting in a non-cash impairment charge.

[0001571996-20-000034:notes:184]
The fair value of the indefinite-lived trade names is generally estimated using discounted cash flow methodologies. The discounted cash flow methodology requires significant judgment, including estimation of future revenue, which is dependent on internal forecasts, the estimation of the long-term revenue growth rate of the Company’s business and the determination of the Company’s weighted average cost of capital and royalty rates. Changes in these estimates and assumptions could materially affect the fair value of the indefinite-lived intangible assets, potentially resulting in a non-cash impairment charge.

[0001571996-20-000034:notes:185]
Based on the results of the annual impairment test performed during the fiscal year ended January 31, 2020, the fair values of each of the reporting units exceeded their carrying values.  Based on this annual impairment test, it was determined that the fair value of the RSA Security reporting unit exceeded its carrying value by 13% as of November 1, 2019.  The Company’s entry into a definitive agreement to sell RSA Security for $2.075 billion, as discussed in Note 1 of the Notes to the Condensed Consolidated Financial Statements, provided a new fair value indication that the RSA Security reporting unit exceeds its carrying value.  Accordingly, subsequent to the annual impairment test, based on fair value indicators as of January 31, 2020 and May 1, 2020, it was determined that the fair value of the RSA Security reporting unit exceeded its carrying amount by 20%.

[0001571996-20-000034:notes:186]
During the fiscal year ended January 31, 2020, an interim impairment assessment of Virtustream was required.  There are no remaining balances of Virtustream goodwill, intangible assets, or property, plant, and equipment as of January 31, 2020 following the gross impairment charges of $619 million and $190 million recognized during the fiscal years ended January 31, 2020 and February 1, 2019, respectively.

[0001571996-20-000034:notes:187]
[same as prior period, unchanged from 0001571996-19-000051:notes:217]

[0001571996-20-000034:notes:188]
[same as prior period, unchanged from 0001571996-19-000051:notes:218]

[0001571996-20-000034:notes:189]
|  | May 1, 2020 |  | January 31, 2020 |
|  | Gross |  | AccumulatedAmortization |  | Net |  | Gross |  | AccumulatedAmortization |  | Net |
|  | (in millions) |
| Customer relationships | $ | 22,383 |  |  | $ | (14,109 | ) |  | $ | 8,274 |  |  | $ | 22,950 |  |  | $ | (13,821 | ) |  | $ | 9,129 |  |
| Developed technology | 15,376 |  |  | (11,011 | ) |  | 4,365 |  |  | 15,707 |  |  | (10,974 | ) |  | 4,733 |  |
| Trade names | 1,266 |  |  | (833 | ) |  | 433 |  |  | 1,306 |  |  | (816 | ) |  | 490 |  |
| Definite-lived intangible assets | 39,025 |  |  | (25,953 | ) |  | 13,072 |  |  | 39,963 |  |  | (25,611 | ) |  | 14,352 |  |
| Indefinite-lived trade names | 3,755 |  |  | — |  |  | 3,755 |  |  | 3,755 |  |  | — |  |  | 3,755 |  |
| Total intangible assets | $ | 42,780 |  |  | $ | (25,953 | ) |  | $ | 16,827 |  |  | $ | 43,718 |  |  | $ | (25,611 | ) |  | $ | 18,107 |  |

[0001571996-20-000034:notes:190]
Amortization expense related to definite-lived intangible assets was approximately $855 million and $1.2 billion for the three months ended May 1, 2020 and May 3, 2019, respectively.  There were no material impairment charges related to intangible assets during the three months ended May 1, 2020 and May 3, 2019.

[0001571996-20-000034:notes:191]
During the three months ended May 1, 2020, the Company recognized proceeds and a gain of $120 million from the sale of certain internally developed intellectual property assets.

[0001571996-20-000034:notes:192]
[same as prior period, unchanged from 0001571996-19-000051:notes:221]

[0001571996-20-000034:notes:193]
|  | May 1, 2020 |
| Fiscal Years | (in millions) |
| 2021 (remaining nine months) | $ | 2,521 |  |
| 2022 | 2,665 |  |
| 2023 | 1,788 |  |
| 2024 | 1,426 |  |
| 2025 | 1,091 |  |
| Thereafter | 3,581 |  |
| Total | $ | 13,072 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001571996-20-000034:notes:194]
[same as prior period, unchanged from 0001571996-19-000051:notes:223]

[0001571996-20-000034:notes:195]
[same as prior period, unchanged from 0001571996-19-000051:notes:224]

[0001571996-20-000034:notes:196]
[same as prior period, unchanged from 0001571996-19-000051:notes:225]

[0001571996-20-000034:notes:197]
|  | Three Months Ended |
|  | May 1, 2020 |  | May 3, 2019 |
|  | (in millions) |
| Deferred revenue: |  |  |  |
| Deferred revenue at beginning of period | $ | 27,800 |  |  | $ | 24,010 |  |
| Revenue deferrals | 5,423 |  |  | 4,900 |  |
| Revenue recognized | (5,356 | ) |  | (4,732 | ) |
| Other (a) | (250 | ) |  | — |  |
| Deferred revenue at end of period | $ | 27,617 |  |  | $ | 24,178 |  |
| Short-term deferred revenue | $ | 14,766 |  |  | $ | 13,043 |  |
| Long-term deferred revenue | $ | 12,851 |  |  | $ | 11,135 |  |

[0001571996-20-000034:notes:198]
(a) Reclassification of RSA Security deferred revenue to liabilities held for sale as of May 1, 2020.  See Note 1 of the Notes to the Condensed Consolidated Financial Statements for more information about the pending divestiture of RSA Security.

[0001571996-20-000034:notes:199]
Remaining Performance Obligations — Remaining performance obligations represent the aggregate amount of the transaction price allocated to performance obligations not delivered, or partially undelivered, as of the end of the reporting period.  Remaining performance obligations include deferred revenue plus unbilled amounts not yet recorded in deferred revenue.  The value of the transaction price allocated to remaining performance obligations as of May 1, 2020 was approximately $37 billion.  The Company expects to recognize approximately 63% of remaining performance obligations as revenue in the next twelve months, and the remainder thereafter.

[0001571996-20-000034:notes:200]
The aggregate amount of the transaction price allocated to remaining performance obligations does not include amounts owed under cancelable contracts where there is no substantive termination penalty.  The Company applied the practical expedient to exclude the value of remaining performance obligations for contracts for which revenue is recognized at the amount to which the Company has the right to invoice for services performed.

[0001571996-20-000034:notes:201]
[same as prior period, unchanged from 0001571996-19-000051:notes:232]


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001571996-20-000034:notes:202]
NOTE 10 — COMMITMENTS AND CONTINGENCIES

[0001571996-20-000034:notes:203]
Legal Matters

[0001571996-20-000034:notes:204]
The Company is involved in various claims, suits, assessments, investigations, and legal proceedings that arise from time to time in the ordinary course of its business, including those identified below, consisting of matters involving consumer, antitrust, tax, intellectual property, and other issues on a global basis.

[0001571996-20-000034:notes:205]
The Company accrues a liability when it believes that it is both probable that a liability has been incurred and that it can reasonably estimate the amount of the loss.  The Company reviews these accruals at least quarterly and adjusts them to reflect ongoing negotiations, settlements, rulings, advice of legal counsel, and other relevant information.  To the extent new information is obtained and the Company’s views on the probable outcomes of claims, suits, assessments, investigations, or legal proceedings change, changes in the Company’s accrued liabilities would be recorded in the period in which such a determination is made.  For some matters, the amount of liability is not probable or the amount cannot be reasonably estimated and therefore accruals have not been made.

[0001571996-20-000034:notes:206]
The following is a discussion of the Company’s significant legal matters and other proceedings:

[0001571996-20-000034:notes:207]
Class Actions Related to the Class V Transaction — Four purported stockholders brought putative class action complaints arising out of the Class V transaction described in Note 1of the Notes to the Condensed Consolidated Financial Statements.  The actions were captioned Hallandale Beach Police and Fire Retirement Plan v. Michael Dell et al. (Civil Action No. 2018-0816-JTL), Howard Karp v. Michael Dell et al. (Civil Action No. 2019-0032-JTL), Miramar Police Officers’ Retirement Plan v. Michael Dell et al. (Civil Action No. 2019-0049-JTL), and Steamfitters Local 449 Pension Plan v. Michael Dell et al. (Civil Action No. 2019-0115-JTL).  The four actions were consolidated in the Delaware Chancery Court into In Re Dell Class V Litigation (Consol. C.A. No. 2018-0816-JTL), which names as defendants the Company’s board of directors and certain stockholders of the Company, including Michael S. Dell.  The plaintiffs generally allege that the defendants breached their fiduciary duties to the former holders of Class V Common Stock in connection with the Class V transaction by allegedly causing the Company to enter into a transaction that favored the interests of the controlling stockholders at the expense of such former stockholders.  The plaintiffs seek, among other remedies, a judicial declaration that the defendants breached their fiduciary duties and an award of damages, fees, and costs.  The plaintiffs filed an amended complaint in August 2019 making substantially similar allegations to those described above.  The defendants filed a motion to dismiss the action in September 2019.  The plaintiffs replied to the motion to dismiss in November 2019, and the defendants filed a reply in December 2019.  A hearing on the motion to dismiss was held on March 13, 2020.  The Court has taken this motion under consideration.

[0001571996-20-000034:notes:208]
Patent Litigation — On April 25, 2019, Cirba Inc. (“Cirba”) filed a lawsuit against VMware, Inc. in the United States District Court for the District of Delaware, alleging two patent infringement claims and three trademark infringement-related claims.  On May 6, 2019, Cirba filed a motion seeking a preliminary injunction tied to one of the two patents it alleges VMware, Inc. infringes.  Following a hearing on August 6, 2019, the Court denied Cirba’s preliminary injunction motion and set the case for trial in mid-January 2020.  On August 20, 2019, VMware, Inc. filed counterclaims against Cirba, asserting among other claims that Cirba is infringing four VMware, Inc. patents.  The Delaware Court severed those claims from the January 2020 trial on Cirba’s claims, and the trial on VMware, Inc.’s patent claims is currently set for September 2021.  On October 22, 2019, VMware, Inc. filed a separate patent infringement lawsuit against Cirba in the United States District Court for the Eastern District of Virginia, asserting that Cirba infringes four additional VMware, Inc. patents.  The trial on Cirba’s claims in Delaware was completed on January 23, 2020, and on January 24, 2020, the jury returned a verdict finding that VMware, Inc. willfully infringed the two asserted patents and awarding approximately $237 million in damages.  The jury further found that VMware, Inc. was not liable on Cirba’s trademark infringement-related claims.  A total of $237 million was accrued for the Delaware action during the fiscal year ended January 31, 2020 and reflects the estimated losses that are considered both probable and reasonably estimable at this time.  The parties have completed the post-trial briefing stage in the Delaware Court, with the hearing on those motions having occurred on May 15, 2020.  The Court has taken those motions under consideration.  VMware, Inc. intends to vigorously defend itself in this matter, including having sought to overturn the jury’s verdict in the first Delaware trial during the post-trial briefing stage and, if necessary, on appeal.  In its post-trial motions, Cirba sought a permanent injunction, enhanced damages, and attorneys’ fees in the Delaware action.  As noted above, VMware, Inc. intends to pursue arguments both in the Delaware Court and, if necessary, the

[0001571996-20-000034:notes:209]
Federal Circuit to overturn the jury’s verdict.  Final resolution of this matter could be materially different from the amount accrued.  The amount accrued for this matter is included in Accrued and other in the Condensed Consolidated Statements of Financial Position as of May 1, 2020 and January 31, 2020, and the charge was classified in Selling, general and administrative in the Consolidated Statements of Income (Loss) during the fiscal year ended January 31, 2020.

[0001571996-20-000034:notes:210]
Other Litigation — The various legal proceedings in which Dell is involved include commercial and intellectual property litigation.  Dell does not currently anticipate that any of these matters will have a material adverse effect on its business, financial condition, results of operations, or cash flows.

[0001571996-20-000034:notes:211]
As of May 1, 2020, the Company does not believe there is a reasonable possibility that a material loss exceeding the amounts already accrued for these or other proceedings or matters has been incurred.  However, since the ultimate resolution of any such proceedings and matters is inherently unpredictable, the Company’s business, financial condition, results of operations, or cash flows could be materially affected in any particular period by unfavorable outcomes in one or more of these proceedings or matters.  Whether the outcome of any claim, suit, assessment, investigation, or legal proceeding, individually or collectively, could have a material adverse effect on the Company’s business, financial condition, results of operations, or cash flows will depend on a number of variables, including the nature, timing, and amount of any associated expenses, amounts paid in settlement, damages, or other remedies or consequences.

[0001571996-20-000034:notes:212]
Indemnifications

[0001571996-20-000034:notes:213]
In the ordinary course of business, the Company enters into contractual arrangements under which it may agree to indemnify the third party to such arrangements from any losses incurred relating to the services it performs on behalf of the Company or for losses arising from certain events as defined in the particular contract, such as litigation or claims relating to past performance.  Such indemnification obligations may not be subject to maximum loss clauses.  Historically, payments related to these indemnifications have not been material to the Company.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001571996-20-000034:notes:214]
NOTE 11 — INCOME AND OTHER TAXES

[0001571996-20-000034:notes:215]
For the three months ended May 1, 2020, the Company’s effective income tax rate was -33.8% on pre-tax income of $136 million.  For the three months ended May 3, 2019, the Company’s effective income tax rate was 330.1% on pre-tax losses of $143 million.  The change in the Company’s effective tax rate is primarily driven by discrete tax items and a change in the Company’s jurisdictional mix of income.  For the three months ended May 1, 2020, the Company’s effective income tax rate benefit includes a discrete tax benefit of $59 million from an intra-entity asset transfer of certain of Pivotal’s intellectual property to an Irish subsidiary that was completed by VMware, Inc. during the quarter.  For the three months ended May 3, 2019, the Company’s effective tax rate includes a discrete tax benefit of $405 million related to a similar intra-entity asset transfer.  The tax benefit for each intra-entity asset transfer was recorded as a deferred tax asset in the period of transaction and represents the book and tax basis difference on the transferred assets measured based on the intellectual property’s current fair value and applicable Irish statutory tax rate.   The Company applied significant judgment when determining the fair value of the intellectual property, which serves as the tax basis of the deferred tax asset, and in evaluating the associated tax laws in the applicable jurisdictions.  The tax deductions for amortization of the assets will be recognized in the future, and any amortization not deducted for tax purposes will be carried forward indefinitely under Irish tax laws.  The Company expects to be able to realize the deferred tax assets resulting from these intra-entity asset transfers.

[0001571996-20-000034:notes:216]
The differences between the estimated effective income tax rates and the U.S. federal statutory rate of 21% principally result from the Company’s geographical distribution of income, differences between the book and tax treatment of certain items, and the discrete tax items discussed above.  In certain jurisdictions, the Company’s tax rate is significantly less than the applicable statutory rate as a result of tax holidays.  The majority of the Company’s foreign income that is subject to these tax holidays and lower tax rates is attributable to Singapore, China, and Malaysia.  A significant portion of these income tax benefits relates to a tax holiday that will be effective until January 31, 2029.  The Company’s other tax holidays will expire in whole or in part during fiscal years 2022 through 2030.  Many of these tax holidays and reduced tax rates may be extended when certain conditions are met or may be terminated early if certain conditions are not met.  As of May 1, 2020, the Company was not aware of any matters of non-compliance related to these tax holidays.  The effective income tax rate for future quarters of Fiscal 2021 may be impacted by the actual mix of jurisdictions in which income is generated.

[0001571996-20-000034:notes:217]
In December 2019, the Company received a Revenue Agent’s Report for the examination by the Internal Revenue Service (“IRS”) of fiscal years 2010 through 2014.  The Company has protested certain proposed assessments within the IRS administrative procedures.  This process has been progressing and although the timing of any resolution remains uncertain, the Company anticipates reaching a settlement with the IRS in Fiscal 2021.  The IRS has started its examination of fiscal years 2015 through 2019.  The Company believes it has valid positions supporting its tax returns and that it is adequately reserved.

[0001571996-20-000034:notes:218]
The Company is also currently under income tax audits in various state and foreign jurisdictions.  The Company is undergoing negotiations, and in some cases contested proceedings, relating to tax matters with the taxing authorities in these jurisdictions.  The Company believes that it has provided adequate reserves related to all matters contained in tax periods open to examination.  Although the Company believes it has made adequate provisions for the uncertainties surrounding these audits, should the Company experience unfavorable outcomes, such outcomes could have a material impact on its results of operations, financial position, and cash flows.  With respect to major U.S., state and foreign taxing jurisdictions, the Company is generally not subject to tax examinations for years prior to the fiscal year ended January 29, 2010.

[0001571996-20-000034:notes:219]
Judgment is required in evaluating the Company’s uncertain tax positions and determining the Company’s provision for income taxes.  The unrecognized tax benefits were $2.5 billion as of both May 1, 2020 and January 31, 2020, and are included in accrued and other and other non-current liabilities in the Condensed Consolidated Statements of Financial Position.  Although timing of resolution or closure of uncertain tax positions is not certain, the Company believes it is reasonably possible that certain tax matters in various jurisdictions, including those matters discussed above, could be concluded within the next twelve months.  The resolution of these audits could reduce the Company’s unrecognized tax benefits by an estimated amount of between $550 million and $850 million.  Such a reduction will have a material impact on the Company’s effective tax rate.

[0001571996-20-000034:notes:220]
The Company takes certain non-income tax positions in the jurisdictions in which it operates and has received certain non-income tax assessments from various jurisdictions.  The Company believes that a material loss in these matters is not probable and that it is not reasonably possible that a material loss exceeding amounts already accrued has been incurred.  The Company believes its positions in these non-income tax litigation matters are supportable and that it ultimately will prevail in the matters.  In the normal course of business, the Company’s positions and conclusions related to its non-income taxes could be challenged and assessments may be made.  To the extent new information is obtained and the Company’s views on its positions, probable outcomes of assessments, or litigation change, changes in estimates to the Company’s accrued liabilities would be recorded in the period in which such a determination is made.  In the resolution process for income tax and non-income tax audits, the Company is required in certain situations to provide collateral guarantees or indemnification to regulators and tax authorities until the matter is resolved.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001571996-20-000034:notes:221]
[same as prior period, unchanged from 0001571996-19-000051:notes:254]

[0001571996-20-000034:notes:222]
Accumulated other comprehensive income (loss) is presented in stockholders’ equity (deficit) in the Condensed Consolidated Statements of Financial Position and consists of amounts related to foreign currency translation adjustments, unrealized net gains (losses) on cash flow hedges, and actuarial net gains (losses) from pension and other postretirement plans.

[0001571996-20-000034:notes:223]
[same as prior period, unchanged from 0001571996-19-000051:notes:256]

[0001571996-20-000034:notes:224]
|  | Foreign Currency Translation Adjustments |  | Cash Flow Hedges |  | Pension and Other Postretirement Plans |  | Accumulated Other Comprehensive Income (Loss) |
|  | (in millions) |
| Balances as of January 31, 2020 | $ | (678 | ) |  | $ | 14 |  |  | $ | (45 | ) |  | $ | (709 | ) |
| Other comprehensive income (loss) before reclassifications | (146 | ) |  | 167 |  |  | (7 | ) |  | 14 |  |
| Amounts reclassified from accumulated other comprehensive income (loss) | — |  |  | (100 | ) |  | 2 |  |  | (98 | ) |
| Total change for the period | (146 | ) |  | 67 |  |  | (5 | ) |  | (84 | ) |
| Less: Change in comprehensive loss attributable to non-controlling interests | — |  |  | (3 | ) |  | — |  |  | (3 | ) |
| Balances as of May 1, 2020 | $ | (824 | ) |  | $ | 84 |  |  | $ | (50 | ) |  | $ | (790 | ) |

[0001571996-20-000034:notes:225]
Amounts related to the Company’s cash flow hedges are reclassified to net income during the same period in which the items being hedged are recognized in earnings.  See Note 7 of the Notes to the Condensed Consolidated Financial Statements for more information on the Company’s derivative instruments.

[0001571996-20-000034:notes:226]
The following table presents reclassifications out of accumulated other comprehensive income (loss), net of tax, to net income for the periods indicated:

[0001571996-20-000034:notes:227]
|  | Three Months Ended |
|  | May 1, 2020 |  | May 3, 2019 |
|  | Cash Flow Hedges |  | Pensions |  | Total |  | Cash Flow Hedges |  | Pensions |  | Total |
|  | (in millions) |
| Total reclassifications, net of tax: |  |  |  |  |  |  |  |  |  |  |  |
| Net revenue | $ | 96 |  |  | $ | — |  |  | $ | 96 |  |  | $ | 58 |  |  | $ | — |  |  | $ | 58 |  |
| Cost of net revenue | 4 |  |  | — |  |  | 4 |  |  | — |  |  | — |  |  | — |  |
| Operating expenses | — |  |  | (2 | ) |  | (2 | ) |  | — |  |  | — |  |  | — |  |
| Total reclassifications, net of tax | $ | 100 |  |  | $ | (2 | ) |  | $ | 98 |  |  | $ | 58 |  |  | $ | — |  |  | $ | 58 |  |


## us-gaap:MinorityInterestDisclosureTextBlock

[0001571996-20-000034:notes:228]
[same as prior period, unchanged from 0001571996-19-000051:notes:261]

[0001571996-20-000034:notes:229]
VMware, Inc. — The non-controlling interests’ share of equity in VMware, Inc. is reflected as a component of the non-controlling interests in the Condensed Consolidated Statements of Financial Position and was $4.8 billion and $4.6 billion as of May 1, 2020 and January 31, 2020, respectively.  As of May 1, 2020 and January 31, 2020, the Company held approximately 80.6% and 80.9%, respectively, of the outstanding equity interest in VMware, Inc.

[0001571996-20-000034:notes:230]
As a result of VMware, Inc.’s acquisition of the non-controlling interest in Pivotal from Pivotal’s public shareholders on December 30, 2019, as described in Note 1 of the Notes to the Condensed Consolidated Financial Statements, the non-controlling interests’ share of equity in Pivotal is only reflected as a component of the non-controlling interest through December 30, 2019.  Pivotal’s Class A common stock ceased to be listed and traded on the NYSE as of the acquisition date, and there was no non-controlling interest in Pivotal as of May 1, 2020 and January 31, 2020.

[0001571996-20-000034:notes:231]
Secureworks — The non-controlling interests’ share of equity in Secureworks is reflected as a component of the non-controlling interests in the Condensed Consolidated Statements of Financial Position and was $92 million and $88 million as of May 1, 2020 and January 31, 2020, respectively.  As of May 1, 2020 and January 31, 2020, the Company held approximately 86.0% and 86.8%, respectively, of the outstanding equity interest in Secureworks, excluding restricted stock awards (“RSAs”).  As of May 1, 2020 and January 31, 2020, the Company held approximately 85.2% and 86.2%, respectively, of the outstanding equity interest in Secureworks, including RSAs.

[0001571996-20-000034:notes:232]
The following table presents the effect of changes in the Company’s ownership interest in VMware, Inc. and Secureworks on the Company’s equity for the period indicated:

[0001571996-20-000034:notes:233]
|  | Three Months Ended |
|  | May 1, 2020 |
|  | (in millions) |
| Net income attributable to Dell Technologies Inc. | $ | 143 |  |
| Transfers (to)/from the non-controlling interests: |  |
| Increase in Dell Technologies Inc. additional paid-in-capital for equity issuances and other equity activity | 251 |  |
| Decrease in Dell Technologies Inc. additional paid-in-capital for equity issuances and other equity activity | (292 | ) |
| Net transfers to non-controlling interests | (41 | ) |
| Change from net income attributable to Dell Technologies Inc. and transfers to the non-controlling interests | $ | 102 |  |


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001571996-20-000034:notes:234]
[same as prior period, unchanged from 0001571996-19-000051:notes:267]

[0001571996-20-000034:notes:235]
[same as prior period, unchanged from 0001571996-19-000051:notes:268]

[0001571996-20-000034:notes:236]
|  | Authorized |  | Issued |  | Outstanding |
|  | (in millions) |
| Common stock as of May 1, 2020 |
| Class A | 600 |  |  | 385 |  |  | 385 |  |
| Class B | 200 |  |  | 102 |  |  | 102 |  |
| Class C | 7,900 |  |  | 261 |  |  | 253 |  |
| Class D | 100 |  |  | — |  |  | — |  |
| Class V | 343 |  |  | — |  |  | — |  |
|  | 9,143 |  |  | 748 |  |  | 740 |  |
| Common stock as of January 31, 2020 |
| Class A | 600 |  |  | 385 |  |  | 385 |  |
| Class B | 200 |  |  | 102 |  |  | 102 |  |
| Class C | 7,900 |  |  | 258 |  |  | 256 |  |
| Class D | 100 |  |  | — |  |  | — |  |
| Class V | 343 |  |  | — |  |  | — |  |
|  | 9,143 |  |  | 745 |  |  | 743 |  |

[0001571996-20-000034:notes:237]
Under the Company’s certificate of incorporation as amended and restated upon the completion of the Class V transaction described in Note 1 of the Notes to the Condensed Consolidated Financial Statements, the Company is prohibited from issuing any of the authorized shares of Class V Common Stock.

[0001571996-20-000034:notes:238]
[same as prior period, unchanged from 0001571996-19-000051:notes:271]

[0001571996-20-000034:notes:239]
The Company is authorized to issue one million shares of preferred stock, par value $0.01 per share.  As of May 1, 2020 and January 31, 2020, no shares of preferred stock were issued or outstanding.

[0001571996-20-000034:notes:240]
[same as prior period, unchanged from 0001571996-19-000051:notes:273]

[0001571996-20-000034:notes:241]
Dell Technologies Common Stock — The Class A Common Stock, the Class B Common Stock, the Class C Common Stock, and the Class D Common Stock are collectively referred to as Dell Technologies Common Stock.  The par value for all classes of Dell Technologies Common Stock is $0.01 per share.  The Class A Common Stock, the Class B Common Stock, the Class C Common Stock, and the Class D Common Stock share equally in dividends declared or accumulated and have equal participation rights in undistributed earnings.

[0001571996-20-000034:notes:242]
[same as prior period, unchanged from 0001571996-19-000051:notes:279]

[0001571996-20-000034:notes:243]
Conversion Rights — Under the Company’s certificate of incorporation, at any time and from time to time, any holder of Class A Common Stock or Class B Common Stock has the right to convert all or any of the shares of Class A Common Stock or Class B Common Stock, as applicable, held by such holder into shares of Class C Common Stock on a one-to-one basis.  During the three months ended May 1, 2020, there were no conversions of Class A Common Stock or Class B Common Stock into Class C Common Stock.

[0001571996-20-000034:notes:244]
[same as prior period, unchanged from 0001571996-19-000051:notes:285]

[0001571996-20-000034:notes:245]
Dell Technologies Common Stock Repurchases by Dell Technologies

[0001571996-20-000034:notes:246]
On February 24, 2020, the Company’s board of directors approved a stock repurchase program under which the Company is authorized to repurchase up to $1.0 billion of shares of the Class C Common Stock over a 24-month period expiring on February 28, 2022, of which approximately $760 million remained available as of May 1, 2020.  During the three months ended May 1, 2020, the Company repurchased approximately 6 million shares of Class C Common Stock for approximately $240 million.  During the same period, the Company suspended activity under its stock repurchase program.  During the three months ended May 3, 2019, Dell Technologies Common Stock repurchases were immaterial.

[0001571996-20-000034:notes:247]
To the extent not retired, shares repurchased under the repurchase program are placed in the Company’s treasury.

[0001571996-20-000034:notes:248]
[same as prior period, unchanged from 0001571996-19-000051:notes:286]

[0001571996-20-000034:notes:249]
On May 29, 2019, VMware, Inc.’s board of directors authorized the repurchase of up to $1.5 billion of VMware, Inc.’s Class A common stock through January 29, 2021, of which $819 million remained available as of May 1, 2020.  During the three months ended May 1, 2020, VMware, Inc. repurchased 1.5 million shares of its Class A common stock in the open market for approximately $181 million.  During the three months ended May 3, 2019, VMware, Inc. repurchased 3.3 million shares of its Class A common stock in the open market for approximately $591 million.

[0001571996-20-000034:notes:250]
[same as prior period, unchanged from 0001571996-19-000051:notes:288]

[0001571996-20-000034:notes:251]
The above VMware, Inc. Class A common stock repurchases for the three months ended May 1, 2020 and May 3, 2019 exclude shares repurchased to settle employee tax withholding related to the vesting of VMware, Inc. stock awards of $154 million and $207 million, respectively.


## us-gaap:EarningsPerShareTextBlock

[0001571996-20-000034:notes:252]
NOTE 15 — EARNINGS PER SHARE

[0001571996-20-000034:notes:253]
Basic earnings per share is based on the weighted-average effect of all common shares issued and outstanding and is calculated by dividing net income by the weighted-average shares outstanding during the period.  Diluted earnings per share is calculated by dividing net income by the weighted-average number of common shares used in the basic earnings per share calculation plus the number of common shares that would be issued assuming exercise or conversion of all potentially dilutive instruments.  The Company excludes equity instruments from the calculation of diluted earnings per share if the effect of including such instruments is antidilutive.

[0001571996-20-000034:notes:254]
The Class A Common Stock, the Class B Common Stock, the Class C Common Stock, and the Class D Common Stock are collectively referred to as Dell Technologies Common Stock.

[0001571996-20-000034:notes:255]
For purposes of calculating earnings per share, the Company uses the two-class method.  As all classes of Dell Technologies Common Stock share the same rights in dividends, basic and diluted earnings per share are the same for each class of Dell Technologies Common Stock.

[0001571996-20-000034:notes:256]
The following table presents the basic and diluted earnings per share for the periods indicated:

[0001571996-20-000034:notes:257]
|  | Three Months Ended |
|  | May 1, 2020 |  | May 3, 2019 |
| Earnings per share attributable to Dell Technologies Inc. |
| Dell Technologies Common Stock — Basic | $ | 0.19 |  |  | $ | 0.41 |  |
| Dell Technologies Common Stock — Diluted | $ | 0.19 |  |  | $ | 0.38 |  |

[0001571996-20-000034:notes:258]
The following table presents the computation of basic and diluted earnings per share for the periods indicated:

[0001571996-20-000034:notes:259]
|  | Three Months Ended |
|  | May 1, 2020 |  | May 3, 2019 |
|  | (in millions) |
| Numerator: Dell Technologies Common Stock |  |  |  |
| Net income attributable to Dell Technologies — basic | $ | 143 |  |  | $ | 293 |  |
| Incremental dilution from VMware, Inc. attributable to Dell Technologies (a) | (2 | ) |  | (8 | ) |
| Net income attributable to Dell Technologies — diluted | $ | 141 |  |  | $ | 285 |  |
| Denominator: Dell Technologies Common Stock weighted-average shares outstanding |
| Weighted-average shares outstanding — basic | 740 |  |  | 717 |  |
| Dilutive effect of options, restricted stock units, restricted stock, and other | 15 |  |  | 34 |  |
| Weighted-average shares outstanding — diluted | 755 |  |  | 751 |  |
| Weighted-average shares outstanding — antidilutive | 8 |  |  | 6 |  |

[0001571996-20-000034:notes:260]
[same as prior period, unchanged from 0001571996-19-000051:notes:308]

[0001571996-20-000034:notes:261]
The incremental dilution from VMware, Inc. represents the impact of VMware, Inc.’s dilutive securities on diluted earnings  per share of Dell Technologies Common Stock, and is calculated by multiplying the difference between VMware, Inc.’s basic and diluted earnings per share by the number of shares of VMware, Inc. common stock held by the Company.  For the three months ended May 3, 2019, the incremental dilution from VMware, Inc. was calculated by the Company without regard to VMware Inc.’s required retrospective adjustments for the Pivotal acquisition in its stand-alone financial statements, and there was no incremental dilution from Pivotal due to its net loss position.  For both periods presented, there was no incremental dilution from Secureworks due to its net loss position.


## dell:TemporaryEquityTextBlock

[0001571996-20-000034:notes:262]
NOTE 16 — REDEEMABLE SHARES

[0001571996-20-000034:notes:263]
[same as prior period, unchanged from 0001571996-19-000051:notes:320]

[0001571996-20-000034:notes:264]
[same as prior period, unchanged from 0001571996-19-000051:notes:321]

[0001571996-20-000034:notes:265]
| • | For stock appreciation rights, restricted stock units (“RSUs”), or restricted stock awards (“RSAs”), any of which stock award types are subject to service requirements, the fair value of the share is multiplied by the portion of the share for which services have been rendered. |

[0001571996-20-000034:notes:266]
[same as prior period, unchanged from 0001571996-19-000051:notes:323]

[0001571996-20-000034:notes:267]
In connection with the Class V transaction described in Note 1 of the Notes to the Condensed Consolidated Financial Statements, the put feature provisions were amended to provide that the put feature applicable to transfers of Dell Technologies securities will terminate upon the earlier of two years after the expiration on June 27, 2019 of the post-transaction lock-up or consummation of any underwritten public offering of shares of Class C Common Stock.

[0001571996-20-000034:notes:268]
[same as prior period, unchanged from 0001571996-19-000051:notes:325]

[0001571996-20-000034:notes:269]
|  | May 1, 2020 |  | January 31, 2020 |
|  | (in millions) |
| Redeemable shares classified as temporary equity | $ | 441 |  |  | $ | 629 |  |
| Issued and outstanding unrestricted common shares | 2 |  |  | 2 |  |
| Restricted stock units | — |  |  | 1 |  |
| Restricted stock awards | — |  |  | — |  |
| Outstanding stock options | 14 |  |  | 15 |  |

[0001571996-20-000034:notes:270]
The decrease in the value of redeemable shares during the three months ended May 1, 2020 was primarily attributable to a decrease in Class C Common Stock fair value and a reduction in the number of shares eligible for put rights.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001571996-20-000034:notes:271]
NOTE 17 — SEGMENT INFORMATION

[0001571996-20-000034:notes:272]
[same as prior period, unchanged from 0001571996-19-000051:notes:329]

[0001571996-20-000034:notes:273]
On December 30, 2019, VMware, Inc. completed its acquisition of Pivotal.  Due to the Company’s ownership of a controlling interest in Pivotal, the Company and VMware, Inc. accounted for the Pivotal acquisition as a transaction between entities under common control, and consequently the transaction had no net effect to the Company’s consolidated financial statements.  Pivotal now operates as a wholly-owned subsidiary of VMware, Inc. and Dell Technologies reports Pivotal results within the VMware reportable segment.  Previously, Pivotal results were reported within Other businesses.  Prior period results have been recast to conform with the current period presentation.

[0001571996-20-000034:notes:274]
[same as prior period, unchanged from 0001571996-19-000051:notes:330]

[0001571996-20-000034:notes:275]
[same as prior period, unchanged from 0001571996-19-000051:notes:331]

[0001571996-20-000034:notes:276]
VMware works with customers in the areas of hybrid and multi-cloud, modern applications, networking, security, and digital workspaces, helping customers manage their IT resources across private clouds and complex multi-cloud, multi-device environments.  VMware enables its customers to digitally transform their operations as they ready their applications, infrastructure, and employees for constantly evolving business needs.

[0001571996-20-000034:notes:277]
The reportable segments disclosed herein are based on information reviewed by the Company’s management to evaluate the business segment results.  The Company’s measure of segment revenue and segment operating income for management reporting purposes excludes the impact of Other businesses, unallocated corporate transactions, the impact of purchase accounting, amortization of intangible assets, transaction-related expenses, stock-based compensation expense, and other corporate expenses, as applicable.  The Company does not allocate assets to the above reportable segments for internal reporting purposes.

[0001571996-20-000034:notes:278]
[same as prior period, unchanged from 0001571996-19-000051:notes:335]

[0001571996-20-000034:notes:279]
|  | Three Months Ended |
|  | May 1, 2020 |  | May 3, 2019 |
|  | (in millions) |
| Consolidated net revenue: |  |  |  |  |
| Infrastructure Solutions Group | $ | 7,569 |  |  | $ | 8,202 |  |
| Client Solutions Group | 11,104 |  |  | 10,910 |  |
| VMware | 2,755 |  |  | 2,457 |  |
| Reportable segment net revenue | 21,428 |  |  | 21,569 |  |
| Other businesses (a) | 517 |  |  | 421 |  |
| Impact of purchase accounting (c) | (48 | ) |  | (82 | ) |
| Total consolidated net revenue | $ | 21,897 |  |  | $ | 21,908 |  |
| Consolidated operating income: |  |  |  |
| Infrastructure Solutions Group | $ | 732 |  |  | $ | 843 |  |
| Client Solutions Group | 592 |  |  | 793 |  |
| VMware | 773 |  |  | 595 |  |
| Reportable segment operating income | 2,097 |  |  | 2,231 |  |
| Other businesses (a) | 65 |  |  | (34 | ) |
| Unallocated transactions (b) | (1 | ) |  | (1 | ) |
| Impact of purchase accounting (c) | (63 | ) |  | (101 | ) |
| Amortization of intangibles | (855 | ) |  | (1,217 | ) |
| Transaction-related expenses (d) | (76 | ) |  | (42 | ) |
| Stock-based compensation expense (e) | (370 | ) |  | (263 | ) |
| Other corporate expenses (f) | (95 | ) |  | (23 | ) |
| Total consolidated operating income | $ | 702 |  |  | $ | 550 |  |

[0001571996-20-000034:notes:280]
| (a) | Secureworks, RSA Security, Virtustream, and Boomi constitute “Other businesses” and do not meet the requirements for a reportable segment, either individually or collectively. The results of Other businesses are not material to the Company’s overall results. |

[0001571996-20-000034:notes:281]
[same as prior period, unchanged from 0001571996-19-000051:notes:338]

[0001571996-20-000034:notes:282]
[same as prior period, unchanged from 0001571996-19-000051:notes:339]

[0001571996-20-000034:notes:283]
| (d) | Transaction-related expenses includes acquisition, integration, and divestiture related costs. |

[0001571996-20-000034:notes:284]
[same as prior period, unchanged from 0001571996-19-000051:notes:341]

[0001571996-20-000034:notes:285]
| (f) | Other corporate expenses includes severance, facility action, and other costs. |

[0001571996-20-000034:notes:286]
[same as prior period, unchanged from 0001571996-19-000051:notes:343]

[0001571996-20-000034:notes:287]
|  | Three Months Ended |
|  | May 1, 2020 |  | May 3, 2019 |
|  | (in millions) |
| Net revenue: |  |  |  |  |
| Infrastructure Solutions Group: |  |  |  |
| Servers and networking | $ | 3,758 |  |  | $ | 4,180 |  |
| Storage | 3,811 |  |  | 4,022 |  |
| Total ISG net revenue | 7,569 |  |  | 8,202 |  |
| Client Solutions Group: |  |  |  |
| Commercial | 8,634 |  |  | 8,307 |  |
| Consumer | 2,470 |  |  | 2,603 |  |
| Total CSG net revenue | 11,104 |  |  | 10,910 |  |
| VMware: |  |  |  |
| Total VMware net revenue | 2,755 |  |  | 2,457 |  |
| Total segment net revenue | $ | 21,428 |  |  | $ | 21,569 |  |


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0001571996-20-000034:notes:288]
NOTE 18 — SUPPLEMENTAL CONSOLIDATED FINANCIAL INFORMATION

[0001571996-20-000034:notes:289]
[same as prior period, unchanged from 0001571996-19-000051:notes:346]

[0001571996-20-000034:notes:290]
|  | May 1, 2020 |  | January 31, 2020 |
|  | (in millions) |
| Cash, cash equivalents, and restricted cash: |  |  |  |
| Cash and cash equivalents | $ | 12,229 |  |  | $ | 9,302 |  |
| Restricted cash - other current assets (a) | 669 |  |  | 730 |  |
| Restricted cash - other non-current assets (a) | 100 |  |  | 119 |  |
| Total cash, cash equivalents, and restricted cash | $ | 12,998 |  |  | $ | 10,151 |  |
| Inventories, net: |  |  |  |
| Production materials | $ | 1,982 |  |  | $ | 1,590 |  |
| Work-in-process | 563 |  |  | 563 |  |
| Finished goods | 1,071 |  |  | 1,128 |  |
| Total inventories, net | $ | 3,616 |  |  | $ | 3,281 |  |
| Other non-current assets: |  |  |  |
| Deferred and other tax assets | $ | 6,043 |  |  | $ | 5,960 |  |
| Operating lease ROU assets | 1,745 |  |  | 1,780 |  |
| Deferred Commissions | 986 |  |  | 998 |  |
| Other | 1,672 |  |  | 1,690 |  |
| Total other non-current assets | $ | 10,446 |  |  | $ | 10,428 |  |
| Other non-current liabilities: |  |  |  |
| Deferred and other tax liabilities | $ | 2,874 |  |  | $ | 3,110 |  |
| Operating lease liabilities | 1,350 |  |  | 1,360 |  |
| Warranty liability | 143 |  |  | 155 |  |
| Other | 973 |  |  | 758 |  |
| Total other non-current liabilities | $ | 5,340 |  |  | $ | 5,383 |  |

[0001571996-20-000034:notes:291]
[same as prior period, unchanged from 0001571996-19-000051:notes:348]

[0001571996-20-000034:notes:292]
Trade Receivables — Allowance for Expected Credit Losses

[0001571996-20-000034:notes:293]
Allowance for expected credit losses of trade receivables as of May 1, 2020 includes the impact of adoption of the new CECL standard, which was adopted as of February 1, 2020 using the modified retrospective method.  The provision recognized on the Condensed Consolidated Statements of Income (Loss) during the three months ended May 1, 2020 is based on an assessment of the impact of current and expected future conditions, inclusive of the effect of the COVID-19 pandemic on credit losses.  The duration and severity of COVID-19 and continued market volatility is highly uncertain and, as such, the impact on expected credit losses is subject to significant judgment and may cause variability in the Company’s allowance for credit losses in future periods.

[0001571996-20-000034:notes:294]
The following table presents the changes in Company’s allowance for expected credit losses for the period indicated:

[0001571996-20-000034:notes:295]
|  | Three Months Ended |
|  | May 1, 2020 |
|  | (in millions) |
| Trade Receivables - Allowance for expected credit losses: |  |
| Balance at beginning of period | $ | 94 |  |
| Adjustment for adoption of the new CECL standard (Note 1) | 27 |  |
| Provision charged to income statement | 36 |  |
| Bad debt write-offs | (13 | ) |
| Balance at end of period | $ | 144 |  |

[0001571996-20-000034:notes:296]
[same as prior period, unchanged from 0001571996-19-000051:notes:349]

[0001571996-20-000034:notes:297]
[same as prior period, unchanged from 0001571996-19-000051:notes:350]

[0001571996-20-000034:notes:298]
|  | Three Months Ended |
|  | May 1, 2020 |  | May 3, 2019 |
|  | (in millions) |
| Warranty liability: |  |  |  |
| Warranty liability at beginning of period | $ | 496 |  |  | $ | 524 |  |
| Costs accrued for new warranty contracts and changes in estimates for pre-existing warranties (a) (b) | 148 |  |  | 203 |  |
| Service obligations honored | (168 | ) |  | (227 | ) |
| Warranty liability at end of period | $ | 476 |  |  | $ | 500 |  |
| Current portion | $ | 333 |  |  | $ | 338 |  |
| Non-current portion | $ | 143 |  |  | $ | 162 |  |

[0001571996-20-000034:notes:299]
[same as prior period, unchanged from 0001571996-19-000051:notes:352]

[0001571996-20-000034:notes:300]
[same as prior period, unchanged from 0001571996-19-000051:notes:353]

[0001571996-20-000034:notes:301]
[same as prior period, unchanged from 0001571996-19-000051:notes:354]


## us-gaap:SubsequentEventsTextBlock

[0001571996-20-000034:notes:302]
NOTE 19 — SUBSEQUENT EVENTS

[0001571996-20-000034:notes:303]
On May 11, 2020, VMware, Inc. repaid $1.25 billion principal amount of its 2.30% Notes due August 2020.

[0001571996-20-000034:notes:304]
The Company entered into a new revolving credit facility for China (the “China Revolving Credit Facility”) effective May 25, 2020.  The new terms provide for collateralized and non-collateralized principal amounts not to exceed $1.0 billion Chinese renminbi and $1.8 billion Chinese renminbi, respectively, or equivalent amounts in U.S. dollars.  Outstanding borrowings under the collateralized portion of the China Revolving Credit Facility bear interest at the loan prime rate (LPR) less 0.2%, for borrowings denominated in Chinese renminbi, or LIBOR plus 1.0%, for borrowings denominated in U.S. dollars, and outstanding borrowings under the non-collateralized portion bear interest at LPR less 0.2%, for borrowings denominated in Chinese renminbi, or LIBOR plus 1.4%, for borrowings denominated in U.S. dollars.  The new facility expires on August 30, 2020.

[0001571996-20-000034:notes:305]
Other than the matters identified above, there were no known events occurring after May 1, 2020 and up until the date of the issuance of this report that would materially affect the information presented herein.
