# DELL note change history — 0001571996-19-000051 → 0001571996-20-000034


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2020-06-08):
[0001571996-20-000034:note_history:1]
Class Actions Related to the Class V Transaction — Four purported stockholders brought putative class action complaints arising out of the Class V transaction described in Note 1of the Notes to the Condensed Consolidated Financial Statements.  The actions were captioned Hallandale Beach Police and Fire Retirement Plan v. Michael Dell et al. (Civil Action No. 2018-0816-JTL), Howard Karp v. Michael Dell et al. (Civil Action No. 2019-0032-JTL), Miramar Police Officers’ Retirement Plan v. Michael Dell et al. (Civil Action No. 2019-0049-JTL), and Steamfitters Local 449 Pension Plan v. Michael Dell et al. (Civil Action No. 2019-0115-JTL).  The four actions were consolidated in the Delaware Chancery Court into In Re Dell Class V Litigation (Consol. C.A. No. 2018-0816-JTL), which names as defendants the Company’s board of directors and certain stockholders of the Company, including Michael S. Dell.  The plaintiffs generally allege that the defendants breached their fiduciary duties to the former holders of Class V Common Stock in connection with the Class V transaction by allegedly causing the Company to enter into a transaction that favored the interests of the controlling stockholders at the expense of such former stockholders.  The plaintiffs seek, among other remedies, a judicial declaration that the defendants breached their fiduciary duties and an award of damages, fees, and costs.  The plaintiffs filed an amended complaint in August 2019 making substantially similar allegations to those described above.  The defendants filed a motion to dismiss the action in September 2019.  The plaintiffs replied to the motion to dismiss in November 2019, and the defendants filed a reply in December 2019.  A hearing on the motion to dismiss was held on March 13, 2020.  The Court has taken this motion under consideration.
  (was, 2019-12-09, similarity 0.8345):
[0001571996-19-000051:note_history:1]
Class Actions Related to the Class V Transaction — Four purported stockholders brought putative class action complaints arising out of the Class V transaction described in Note 14 of the Notes to the Condensed Consolidated Financial Statements.  The actions were captioned Hallandale Beach Police and Fire Retirement Plan v. Michael Dell et al. (Civil Action No. 2018-0816-JTL), Howard Karp v. Michael Dell et al. (Civil Action No. 2019-0032-JTL), Miramar Police Officers’ Retirement Plan v. Michael Dell et al. (Civil Action No. 2019-0049-JTL), and Steamfitters Local 449 Pension Plan v. Michael Dell et al. (Civil Action No. 2019-0115-JTL).  The four actions were consolidated into In Re Dell Class V Litigation (Consol. C.A. No. 2018-0816-JTL), which names as defendants the Company’s board of directors and certain stockholders of the Company, including Michael S. Dell.  The plaintiffs generally allege that the defendants breached their fiduciary duties to the former holders of Class V Common Stock in connection with the Class V transaction by allegedly causing the Company to enter into a transaction that favored the interests of the controlling stockholders at the expense of such former stockholders.  The plaintiffs filed an amended complaint on August 9, 2019 making substantially similar allegations to those described above.  The defendants filed a motion to dismiss the action on September 30, 2019.  The plaintiffs replied to the motion to dismiss on November 15, 2019, and the defendant’s reply is due December 13, 2019.  A ruling on the pending motion is expected in early 2020.

- added (2020-06-08):
[0001571996-20-000034:note_history:2]
Patent Litigation — On April 25, 2019, Cirba Inc. (“Cirba”) filed a lawsuit against VMware, Inc. in the United States District Court for the District of Delaware, alleging two patent infringement claims and three trademark infringement-related claims.  On May 6, 2019, Cirba filed a motion seeking a preliminary injunction tied to one of the two patents it alleges VMware, Inc. infringes.  Following a hearing on August 6, 2019, the Court denied Cirba’s preliminary injunction motion and set the case for trial in mid-January 2020.  On August 20, 2019, VMware, Inc. filed counterclaims against Cirba, asserting among other claims that Cirba is infringing four VMware, Inc. patents.  The Delaware Court severed those claims from the January 2020 trial on Cirba’s claims, and the trial on VMware, Inc.’s patent claims is currently set for September 2021.  On October 22, 2019, VMware, Inc. filed a separate patent infringement lawsuit against Cirba in the United States District Court for the Eastern District of Virginia, asserting that Cirba infringes four additional VMware, Inc. patents.  The trial on Cirba’s claims in Delaware was completed on January 23, 2020, and on January 24, 2020, the jury returned a verdict finding that VMware, Inc. willfully infringed the two asserted patents and awarding approximately $237 million in damages.  The jury further found that VMware, Inc. was not liable on Cirba’s trademark infringement-related claims.  A total of $237 million was accrued for the Delaware action during the fiscal year ended January 31, 2020 and reflects the estimated losses that are considered both probable and reasonably estimable at this time.  The parties have completed the post-trial briefing stage in the Delaware Court, with the hearing on those motions having occurred on May 15, 2020.  The Court has taken those motions under consideration.  VMware, Inc. intends to vigorously defend itself in this matter, including having sought to overturn the jury’s verdict in the first Delaware trial during the post-trial briefing stage and, if necessary, on appeal.  In its post-trial motions, Cirba sought a permanent injunction, enhanced damages, and attorneys’ fees in the Delaware action.  As noted above, VMware, Inc. intends to pursue arguments both in the Delaware Court and, if necessary, the

- added (2020-06-08):
[0001571996-20-000034:note_history:3]
Federal Circuit to overturn the jury’s verdict.  Final resolution of this matter could be materially different from the amount accrued.  The amount accrued for this matter is included in Accrued and other in the Condensed Consolidated Statements of Financial Position as of May 1, 2020 and January 31, 2020, and the charge was classified in Selling, general and administrative in the Consolidated Statements of Income (Loss) during the fiscal year ended January 31, 2020.

- changed (2020-06-08):
[0001571996-20-000034:note_history:4]
As of May 1, 2020, the Company does not believe there is a reasonable possibility that a material loss exceeding the amounts already accrued for these or other proceedings or matters has been incurred.  However, since the ultimate resolution of any such proceedings and matters is inherently unpredictable, the Company’s business, financial condition, results of operations, or cash flows could be materially affected in any particular period by unfavorable outcomes in one or more of these proceedings or matters.  Whether the outcome of any claim, suit, assessment, investigation, or legal proceeding, individually or collectively, could have a material adverse effect on the Company’s business, financial condition, results of operations, or cash flows will depend on a number of variables, including the nature, timing, and amount of any associated expenses, amounts paid in settlement, damages, or other remedies or consequences.
  (was, 2019-12-09, similarity 0.9941):
[0001571996-19-000051:note_history:4]
As of November 1, 2019, the Company does not believe there is a reasonable possibility that a material loss exceeding the amounts already accrued for these or other proceedings or matters has been incurred.  However, since the ultimate resolution of any such proceedings and matters is inherently unpredictable, the Company’s business, financial condition, results of operations, or cash flows could be materially affected in any particular period by unfavorable outcomes in one or more of these proceedings or matters.  Whether the outcome of any claim, suit, assessment, investigation, or legal proceeding, individually or collectively, could have a material adverse effect on the Company’s business, financial condition, results of operations, or cash flows will depend on a number of variables, including the nature, timing, and amount of any associated expenses, amounts paid in settlement, damages, or other remedies or consequences.

- removed (2020-06-08):
[0001571996-19-000051:note_history:5]
Securities Litigation — On May 21, 2014, a securities class action seeking compensatory damages was filed in the United States District Court for the Southern District of New York, captioned City of Pontiac General Employees’ Retirement System v. Dell Inc., et. al. (Case No. 1:14-cv-03644).  The action names as defendants Dell Inc. (“Dell”) and certain current and former executive officers, and alleges that Dell made false and misleading statements about Dell’s financial results and future prospects between February 21, 2012 and May 22, 2012, which resulted in artificially inflated stock prices.  The case was transferred to the United States District Court for the Western District of Texas under the same caption (Case No. 1:15-cv-00374), where the defendants filed a motion to dismiss.  On September 16, 2016, the Court denied the motion to dismiss.  On March 29, 2018, the Court granted the plaintiffs’ motion for class certification, and certified a class consisting of all purchasers of Dell common stock between February 22, 2012 and May 22, 2012.  Fact and expert discovery is now closed.  The parties have agreed to an immaterial settlement amount, and the Court has preliminarily approved the settlement.  Notice of the settlement was mailed to shareholders in October 2019.  Shareholders have until December 20, 2019 to opt out or object to the settlement.  A hearing for the final approval of the settlement is set for January 10, 2020.

- removed (2020-06-08):
[0001571996-19-000051:note_history:6]
Copyright Levies — The Company is involved in various proceedings and negotiations regarding Dell’s obligation to collect and remit copyright levies in certain countries.  The Company continues to collect levies in countries where it has determined that local laws require payment.  The Company, along with other companies and/or industry associations, also continues to oppose levy schemes that do not comply with controlling law.  The Company does not currently anticipate that any of these matters will have a material adverse effect on its business, financial condition, results of operations, or cash flows.


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2020-06-08):
[0001571996-20-000034:note_history:7]
As discussed in Note 1 of the Notes to the Condensed Consolidated Financial Statements, the Company adopted the new CECL standard as of February 1, 2020 using the modified retrospective method.  The new impairment methodology for measurement of credit losses on financial instruments reflects expected credit losses and requires consideration of a broader range of reasonable and supportable information to inform credit loss estimates.  Additionally, the Company adopted the new cloud computing standard during the three months ended May 1, 2020 using the prospective method.  In a cloud-computing hosting arrangement hosted by a vendor that is a service contract, certain implementation costs should be capitalized and amortized over the term of the arrangement.  The following accounting policies have been updated as part of the adoption of the new standards.

- added (2020-06-08):
[0001571996-20-000034:note_history:8]
Allowance for Expected Credit Losses — The Company recognizes an allowance for losses on accounts receivable in an amount equal to the current expected credit losses.  The estimation of the allowance is based on an analysis of historical loss experience, current receivables aging, and management’s assessment of current conditions and reasonable and supportable expectation of future conditions, as well as an assessment of specific identifiable customer accounts considered at risk or uncollectible.  The Company assesses collectibility by pooling receivables where similar characteristics exist and evaluates receivables individually when specific customer balances no longer share those risk characteristics and are considered at risk or uncollectible.  The expense associated with the allowance for expected credit losses is recognized in selling, general, and administrative expenses.

- added (2020-06-08):
[0001571996-20-000034:note_history:9]
Allowance for Financing Receivables Losses — The Company recognizes an allowance for losses on financing receivables in an amount equal to the probable losses net of recoveries.  The allowance for losses is determined based on various factors, including lifetime expected losses determined using macroeconomic forecast assumptions and management judgments applicable to and through the expected life of the portfolios as well as past due receivables, receivable type, and customer risk profile.  Both fixed and revolving receivable loss rates are affected by macroeconomic conditions, including the level of gross domestic product (“GDP”) growth, the level of commercial capital equipment investment, unemployment rates, and the credit quality of the borrower.

- added (2020-06-08):
[0001571996-20-000034:note_history:10]
Customer account principal and interest are charged to the allowance for losses when an account is deemed to be uncollectible or generally when the account is 180 days delinquent.  While the Company does not generally place financing receivables on non-accrual status during the delinquency period, accrued interest is included in the allowance for loss calculation and, therefore, the Company is adequately reserved in the event of charge off.  Recoveries on receivables previously charged off as uncollectible are recorded to the allowance for financing receivables losses.  The expense associated with the allowance for financing receivables losses is recognized as cost of net revenue.

- added (2020-06-08):
[0001571996-20-000034:note_history:11]
Capitalized Software Development Costs — The Company capitalizes certain internal and external costs to acquire or create internal use software which are incurred subsequent to the completion of the preliminary project stage.  Development costs are generally amortized on a straight-line basis over five years.  Costs associated with maintenance and minor enhancements to the features and functionality of the Company’s website are expensed as incurred.

- removed (2020-06-08):
[0001571996-19-000051:note_history:12]
As discussed in Note 1 of the Notes to the Condensed Consolidated Financial Statements, the Company adopted the new lease standard as of February 2, 2019, using the modified retrospective method.  A lease is defined as a contract that conveys the right to control the use of an identified asset for a period of time in exchange for consideration.  The Company enters into contracts that are, or contain, leases as both a lessee and a lessor.  The following accounting policies have been updated as part of the adoption of the new lease standard.

- removed (2020-06-08):
[0001571996-19-000051:note_history:13]
Accounting for Operating Leases as a Lessee — In its ordinary course of business, the Company enters into leases as a lessee for office buildings, warehouses, employee vehicles, and equipment.  The Company determines if an arrangement is a lease or contains a lease at inception.  Operating leases result in the recognition of ROU assets and lease liabilities on the Consolidated Statements of Financial Position.  ROU assets represent the right to use an underlying asset for the lease term and lease liabilities represent the obligation to make lease payments arising from the lease, measured on a discounted basis.

- removed (2020-06-08):
[0001571996-19-000051:note_history:14]
At lease inception, the lease liability is measured at the present value of the lease payments over the lease term.  The operating lease ROU asset equals the lease liability adjusted for any initial direct costs, prepaid or deferred rent, and lease incentives.  The Company uses the implicit rate when readily determinable.  As most of the leases do not provide an implicit rate, the Company uses its incremental borrowing rate based on the information available at the commencement date to determine the present value of lease payments.  Incremental borrowing rates used to determine the present value of lease payments were derived by reference to the Company’s secured-debt yields corresponding to the lease commencement date.

- removed (2020-06-08):
[0001571996-19-000051:note_history:15]
The lease term may include options to extend or to terminate the lease that the Company is reasonably certain to exercise.  Lease expense is recognized on a straight-line basis over the lease term in most instances.

- removed (2020-06-08):
[0001571996-19-000051:note_history:16]
The Company has elected not to record leases with an initial term of 12 months or less on the Consolidated Statements of Financial Position.  Lease expense on such leases is recognized on a straight-line basis over the lease term.  The Company does not generate material sublease income and has no material related party leases.  The Company’s lease agreements do not contain any material residual value guarantees or material restrictive covenants.

- removed (2020-06-08):
[0001571996-19-000051:note_history:17]
The Company’s office building agreements contain costs such as common area maintenance and other executory costs that are variable in nature.  Variable lease costs are expensed as incurred.  The Company combines lease and non-lease components, such as common area and other maintenance costs, in calculating the ROU assets and lease liabilities for its office buildings and employee vehicles.  Under certain service agreements with third-party logistics providers, the Company directs the use of the inventory within the warehouses and, therefore, controls the assets.  The warehouses and some of the equipment used are considered embedded leases.  The Company accounts for the lease and non-lease components separately.  The lease components consist of the warehouses and some of the equipment, such as conveyor belts.  The non-lease components consist of services and other shared equipment, such as material handling and transportation.  The Company allocates the consideration to the lease and non-lease components using their relative standalone values.  See Note 5 of the Notes to the Condensed Consolidated Financial Statements for additional information.

- removed (2020-06-08):
[0001571996-19-000051:note_history:18]
Accounting for Leases as a Lessor — The Company’s wholly-owned subsidiary Dell Financial Services and its affiliates (“DFS”) acts as a lessor to provide equipment financing to customers through a variety of lease arrangements (“DFS leases”).  Subsequent to the adoption of the new lease standard, new DFS leases are classified as sales-type leases, direct financing leases, or operating leases.  Direct financing leases under the new lease standard are immaterial.  Leases that commenced prior to the adoption of the new lease standard were not reassessed or restated pursuant to the practical expedients elected and will continue to be accounted for under previous lease accounting guidance.

- removed (2020-06-08):
[0001571996-19-000051:note_history:19]
When a contract includes lease and non-lease components, DFS allocates consideration under the contract to each component based on relative standalone selling price.  Whenever the terms of the lease transfer control to the lessee, the contract is typically classified as a sales-type lease.  Through these arrangements, the lessee has the right to substantially all of the economic benefits from use of the identified asset and has the right to direct the use of such asset during the period of use.  In many arrangements, the lessee also retains ownership at the end of the lease term.  On commencement of sales-type leases, the Company recognizes profit up-front, and amounts due from the customer under the lease contract are recognized as financing receivables on the Consolidated Statements of Financial Position.  Interest income is recognized as Net revenue over the term of the lease based on the effective interest method.  For sales and other taxes collected from the lessee, the Company has elected not to include such taxes as part of lease revenue.

- removed (2020-06-08):
[0001571996-19-000051:note_history:20]
All other leases which do not meet the definition of a sales-type lease or direct financing lease are classified as operating leases.  The underlying asset in an operating lease arrangement is carried at depreciated cost as “Equipment under operating leases” within Property, plant, and equipment, net on the Consolidated Statements of Financial Position.  Depreciation is calculated using the straight-line method over the term of the underlying lease contract and is recognized as Cost of net revenue.  The depreciable basis is the original cost of the equipment less the estimated residual value of the equipment at the end of the lease term.  The Company recognizes operating lease revenue on a straight-line basis over the lease term and expenses deferred initial direct costs on the same basis.  Impairment of equipment under operating leases is assessed on the same basis as other long-lived assets.

- removed (2020-06-08):
[0001571996-19-000051:note_history:21]
DFS provides lessees with the option to extend the lease or purchase the underlying asset at the end of the lease term, which is considered when evaluating lease classification.  In general, DFS’s lease arrangements do not have variable payment terms and are non-cancelable.

- removed (2020-06-08):
[0001571996-19-000051:note_history:22]
See Note 4 of the Notes to the Condensed Consolidated Financial Statements for more information regarding DFS leasing arrangements.

- removed (2020-06-08):
[0001571996-19-000051:note_history:23]
Financing Receivables — Financing receivables are presented net of allowance for losses and consist of customer receivables and residual interest.  Customer receivables, gross includes amounts due from customers under revolving loans, fixed-term loans, fixed-term sales-type or direct financing leases, and accrued interest.  The Company has two portfolios, consisting of: (1) fixed-term leases and loans and (2) revolving loans, and assesses risk at the portfolio level to determine the appropriate allowance levels.  The portfolio segments are further segregated into classes based on products, customer type, and credit risk evaluation: (1) Revolving - Dell Preferred Account (“DPA”); (2) Revolving - Dell Business Credit (“DBC”); and (3) Fixed-term - Consumer and Commercial.  Fixed-term leases and loans are offered to qualified small and medium-sized businesses, large commercial accounts, governmental organizations, and educational entities.  Additionally, fixed-term loans are also offered to certain individual consumer customers.  Revolving loans are offered under private label credit financing programs.  The DPA revolving loan programs are primarily offered to individual consumer customers and the DBC revolving loan programs are primarily offered to small and medium-sized commercial customers.

- removed (2020-06-08):
[0001571996-19-000051:note_history:24]
The Company retains a residual interest in equipment leased under its fixed-term lease programs.  The amount of the residual interest is established at the inception of the lease based upon estimates of the value of the equipment at the end of the lease term using historical studies, industry data, and future value-at-risk demand valuation methods.  On a quarterly basis, the Company assesses the carrying amount of its recorded residual values for impairment.  Anticipated declines in specific future residual values that are considered to be other-than-temporary are recorded currently in earnings.  Generally, residual value risk on equipment under lease is not considered to be significant because of the existence of a secondary market with respect to the equipment.  The lease agreement also clearly defines applicable return conditions and remedies for non-compliance, to ensure that the leased equipment will be in good operating condition upon return.  Model changes and updates, as well as market strength and product acceptance, are monitored and adjustments are made to residual values in accordance with the significance of any such changes.  The remarketing sales staff works closely with customers and dealers to manage the sale of lease returns and the recovery of residual exposure.  As of November 1, 2019, the Company has not recorded significant residual value impairment.

- removed (2020-06-08):
[0001571996-19-000051:note_history:25]
Asset Securitization — The Company transfers certain U.S. and European customer loan and lease payments and associated equipment to Special Purpose Entities (“SPEs”) that meet the definition of a Variable Interest Entity (“VIE”) and are consolidated into the Consolidated Financial Statements.  These SPEs are bankruptcy-remote legal entities with separate assets and liabilities.  The purpose of the SPEs is to facilitate the funding of customer loan and lease payments and associated equipment in the capital markets.  These SPEs have entered into financing arrangements with multi-seller conduits that, in turn, issue asset-backed debt securities in the capital markets.  The asset securitizations in the SPEs are accounted for as secured borrowings.  See Note 4 of the Notes to the Condensed Consolidated Financial Statements for additional information on the impact of the consolidation.


## dell:CreditLossFinancialInstrumentLeasesDebtVariableInterestEntitiesAndCustomerReceivablesSalesTextBlock (debt) — matched_by: no_prior_note, score: 0.0

- added (2020-06-08):
[0001571996-20-000034:note_history:26]
NOTE 4 — FINANCIAL SERVICES

- added (2020-06-08):
[0001571996-20-000034:note_history:27]
The Company offers or arranges various financing options, services, and alternative payment structures for its customers in North America, Europe, Australia, and New Zealand through Dell Financial Services and its affiliates (“DFS”).  The Company also arranges financing for some of its customers in various countries where DFS does not currently operate as a captive enterprise.  The key activities of DFS include originating, collecting, and servicing customer financing arrangements primarily related to the purchase or use of Dell Technologies products and services.  In some cases, DFS also offers financing on the purchase of third-party technology products that complement the Dell Technologies portfolio of products and services.  New financing originations were $1.8 billion and $1.7 billion for the three months ended May 1, 2020 and May 3, 2019, respectively.

- added (2020-06-08):
[0001571996-20-000034:note_history:28]
The Company’s loan and lease arrangements with customers are aggregated into the following categories:

- added (2020-06-08):
[0001571996-20-000034:note_history:29]
Revolving loans — Revolving loans offered under private label credit financing programs provide qualified customers with a revolving credit line for the purchase of products and services offered by Dell Technologies.  These private label credit financing programs are referred to as Dell Preferred Account (“DPA”) and Dell Business Credit (“DBC”).  The DPA product is primarily offered to individual consumer customers, and the DBC product is primarily offered to small and medium-sized commercial customers.  Revolving loans in the United States bear interest at a variable annual percentage rate that is tied to the prime rate.  Based on historical payment patterns, revolving loan transactions are typically repaid within twelve months on average.  Due to the short-term nature of the revolving loan portfolio, the carrying value of the portfolio approximates fair value.

- added (2020-06-08):
[0001571996-20-000034:note_history:30]
Fixed-term leases and loans — The Company enters into financing arrangements with customers who seek lease financing for equipment they might otherwise purchase.  Pursuant to the current lease accounting standard effective February 2, 2019, new DFS leases are classified as sales-type leases, direct financing leases, or operating leases.  When the terms of the DFS lease transfer control of the underlying asset to the lessee, the contract is typically classified as a sales-type lease.  Direct financing leases are immaterial.  All other new DFS leases are classified as operating leases.  Leases that commenced prior to the effective date of the current lease accounting standard continue to be accounted for under previous lease accounting guidance.  Leases with business customers have fixed terms of generally two to four years.

- added (2020-06-08):
[0001571996-20-000034:note_history:31]
The Company also offers fixed-term loans to qualified small businesses, large commercial accounts, governmental organizations, educational entities, and certain individual consumer customers.  These loans are repaid in equal payments including interest and have defined terms of generally three to five years.  The fair value of the fixed-term loan portfolio is determined using market observable inputs.  The carrying value of these loans approximates fair value.

- added (2020-06-08):
[0001571996-20-000034:note_history:32]
Financing Receivables

- added (2020-06-08):
[0001571996-20-000034:note_history:33]
The following table presents the components of the Company’s financing receivables segregated by portfolio segment as of the dates indicated:

- added (2020-06-08):
[0001571996-20-000034:note_history:34]
|  | May 1, 2020 |  | January 31, 2020 |
|  | Revolving |  | Fixed-term |  | Total |  | Revolving |  | Fixed-term |  | Total |
|  | (in millions) |
| Financing receivables, net: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer receivables, gross (a) | $ | 786 |  |  | $ | 8,446 |  |  | $ | 9,232 |  |  | $ | 824 |  |  | $ | 8,486 |  |  | $ | 9,310 |  |
| Allowances for losses | (144 | ) |  | (177 | ) |  | (321 | ) |  | (70 | ) |  | (79 | ) |  | (149 | ) |
| Customer receivables, net | 642 |  |  | 8,269 |  |  | 8,911 |  |  | 754 |  |  | 8,407 |  |  | 9,161 |  |
| Residual interest | — |  |  | 551 |  |  | 551 |  |  | — |  |  | 582 |  |  | 582 |  |
| Financing receivables, net | $ | 642 |  |  | $ | 8,820 |  |  | $ | 9,462 |  |  | $ | 754 |  |  | $ | 8,989 |  |  | $ | 9,743 |  |
| Short-term | $ | 642 |  |  | $ | 4,110 |  |  | $ | 4,752 |  |  | $ | 754 |  |  | $ | 4,141 |  |  | $ | 4,895 |  |
| Long-term | $ | — |  |  | $ | 4,710 |  |  | $ | 4,710 |  |  | $ | — |  |  | $ | 4,848 |  |  | $ | 4,848 |  |

- added (2020-06-08):
[0001571996-20-000034:note_history:35]
____________________

- added (2020-06-08):
[0001571996-20-000034:note_history:36]
| (a) | Customer receivables, gross includes amounts due from customers under revolving loans, fixed-term loans, fixed-term sales-type or direct financing leases, and accrued interest. |

- added (2020-06-08):
[0001571996-20-000034:note_history:37]
The allowance for losses as of May 1, 2020 includes the adoption of the new CECL standard, which was adopted as of February 1, 2020 using the modified retrospective method.  Prior period amounts have not been recast.  The provision recognized on the Condensed Consolidated Statements of Income (Loss) during the three months ended May 1, 2020 is based on an assessment of the impact of current and expected future economic conditions, inclusive of the effect of the COVID-19 pandemic on credit losses.  The duration and severity of COVID-19 and continued market volatility is highly uncertain and, as such, the impact on expected losses is subject to significant judgment and may cause variability in the Company’s allowance for credit losses in future periods.  See Note 1 and Note 2 of the Notes to the Condensed Consolidated Financial Statements for additional information about the new CECL standard.

- added (2020-06-08):
[0001571996-20-000034:note_history:38]
The following table presents the changes in allowance for financing receivable losses for the periods indicated:

- added (2020-06-08):
[0001571996-20-000034:note_history:39]
|  | Three Months Ended |
|  | May 1, 2020 |  | May 3, 2019 |
|  | Revolving |  | Fixed-term |  | Total |  | Revolving |  | Fixed-term |  | Total |
|  | (in millions) |
| Allowance for financing receivable losses: |  |  |  |  |  |  |  |  |  |  |  |
| Balances at beginning of period | $ | 70 |  |  | $ | 79 |  |  | $ | 149 |  |  | $ | 75 |  |  | $ | 61 |  |  | $ | 136 |  |
| Adjustment for adoption of the new CECL standard (Note 1) | 40 |  |  | 71 |  |  | 111 |  |  | — |  |  | — |  |  | — |  |
| Charge-offs, net of recoveries | (20 | ) |  | (9 | ) |  | (29 | ) |  | (20 | ) |  | (3 | ) |  | (23 | ) |
| Provision charged to income statement | 54 |  |  | 36 |  |  | 90 |  |  | 15 |  |  | 15 |  |  | 30 |  |
| Balances at end of period | $ | 144 |  |  | $ | 177 |  |  | $ | 321 |  |  | $ | 70 |  |  | $ | 73 |  |  | $ | 143 |  |

- added (2020-06-08):
[0001571996-20-000034:note_history:40]
Aging

- added (2020-06-08):
[0001571996-20-000034:note_history:41]
The following table presents the aging of the Company’s customer financing receivables, gross, including accrued interest, segregated by class, as of the dates indicated:

- added (2020-06-08):
[0001571996-20-000034:note_history:42]
|  | May 1, 2020 |  | January 31, 2020 |
|  | Current |  | Past Due1 — 90 Days |  | Past Due>90 Days |  | Total |  | Current |  | Past Due1 — 90 Days |  | Past Due>90 Days |  | Total |
|  | (in millions) |
| Revolving — DPA | $ | 547 |  |  | $ | 34 |  |  | $ | 17 |  |  | $ | 598 |  |  | $ | 550 |  |  | $ | 51 |  |  | $ | 20 |  |  | $ | 621 |  |
| Revolving — DBC | 162 |  |  | 21 |  |  | 5 |  |  | 188 |  |  | 184 |  |  | 15 |  |  | 4 |  |  | 203 |  |
| Fixed-term — Consumer and Commercial | 6,963 |  |  | 1,333 |  |  | 150 |  |  | 8,446 |  |  | 8,005 |  |  | 373 |  |  | 108 |  |  | 8,486 |  |
| Total customer receivables, gross | $ | 7,672 |  |  | $ | 1,388 |  |  | $ | 172 |  |  | $ | 9,232 |  |  | $ | 8,739 |  |  | $ | 439 |  |  | $ | 132 |  |  | $ | 9,310 |  |

- added (2020-06-08):
[0001571996-20-000034:note_history:43]
Aging is likely to fluctuate as a result of the variability in volume of large transactions entered into over the period, and the administrative processes that accompany those larger transactions.  Aging is also impacted by the timing of Dell Technologies fiscal period end date, relative to calendar month-end customer payment due dates.  As a result of these factors, fluctuations in aging from period to period do not necessarily indicate a material change in the collectibility of the portfolio.

- added (2020-06-08):
[0001571996-20-000034:note_history:44]
Fixed-term consumer and commercial customer receivables are placed on non-accrual status if principal or interest is past due and considered delinquent, or if there is concern about collectibility of a specific customer receivable.  These receivables identified as doubtful for collectibility may be classified as current for aging purposes.  Aged revolving portfolio customer receivables identified as delinquent are charged off.

- added (2020-06-08):
[0001571996-20-000034:note_history:45]
Credit Quality

- added (2020-06-08):
[0001571996-20-000034:note_history:46]
The following table presents customer receivables, gross, including accrued interest, by credit quality indicator segregated by class and year of origination, as of the date indicated:

- added (2020-06-08):
[0001571996-20-000034:note_history:47]
|  | May 1, 2020 |
|  | Fixed-term — Consumer and Commercial |  |  |  |  |  |  |
|  | Fiscal Year of Origination |  |  |  |  |  |  |
|  | 2021 |  | 2020 |  | 2019 |  | 2018 |  | 2017 |  | Years Prior |  | Revolving — DPA (a) |  | Revolving — DBC (a) |  | Total |
|  | (in millions) |
| Higher | $ | 1,150 |  |  | $ | 2,438 |  |  | $ | 1,141 |  |  | $ | 393 |  |  | $ | 68 |  |  | $ | 2 |  |  | $ | 135 |  |  | $ | 51 |  |  | $ | 5,378 |  |
| Mid | 229 |  |  | 883 |  |  | 498 |  |  | 182 |  |  | 34 |  |  | 2 |  |  | 169 |  |  | 56 |  |  | 2,053 |  |
| Lower | 184 |  |  | 647 |  |  | 443 |  |  | 119 |  |  | 29 |  |  | 4 |  |  | 294 |  |  | 81 |  |  | 1,801 |  |
| Total | $ | 1,563 |  |  | $ | 3,968 |  |  | $ | 2,082 |  |  | $ | 694 |  |  | $ | 131 |  |  | $ | 8 |  |  | $ | 598 |  |  | $ | 188 |  |  | $ | 9,232 |  |

- added (2020-06-08):
[0001571996-20-000034:note_history:48]
____________________

- added (2020-06-08):
[0001571996-20-000034:note_history:49]
| (a) | The revolving portfolio is exempt from the requirement to disclose the amortized cost basis by year of origination since determining the appropriate origination year can be complex due to the nature of the revolving portfolio. |

- added (2020-06-08):
[0001571996-20-000034:note_history:50]
The following table presents customer receivables, gross, including accrued interest, by credit quality indicator segregated by class, as of the date indicated, and was not recast to reflect the impact of adoption of the new CECL standard:

- added (2020-06-08):
[0001571996-20-000034:note_history:51]
|  | January 31, 2020 |
|  | Fixed-term — Consumer and Commercial |  | Revolving — DPA |  | Revolving — DBC |  | Total |
|  | (in millions) |
| Higher | $ | 5,042 |  |  | $ | 137 |  |  | $ | 55 |  |  | $ | 5,234 |  |
| Mid | 2,036 |  |  | 175 |  |  | 63 |  |  | 2,274 |  |
| Lower | 1,408 |  |  | 309 |  |  | 85 |  |  | 1,802 |  |
| Total | $ | 8,486 |  |  | $ | 621 |  |  | $ | 203 |  |  | $ | 9,310 |  |

- added (2020-06-08):
[0001571996-20-000034:note_history:52]
The categories shown in the tables above segregate customer receivables based on the relative degrees of credit risk.  The credit quality indicators for DPA revolving accounts are measured primarily as of each quarter-end date, while all other indicators are generally updated on a periodic basis.

- added (2020-06-08):
[0001571996-20-000034:note_history:53]
For DPA revolving receivables shown in the table above, the Company makes credit decisions based on proprietary scorecards, which include the customer’s credit history, payment history, credit usage, and other credit agency-related elements.  The higher quality category includes prime accounts generally of a higher credit quality that are comparable to U.S. customer FICO scores of 720 or above.  The mid-category represents the mid-tier accounts that are comparable to U.S. customer FICO scores from 660 to 719.  The lower category is generally sub-prime and represents lower credit quality accounts that are comparable to U.S. customer FICO scores below 660.  For the DBC revolving receivables and fixed-term commercial receivables shown in the table above, an internal grading system is utilized that assigns a credit level score based on a number of considerations, including liquidity, operating performance, and industry outlook.  The grading criteria and classifications for the fixed-term products differ from those for the revolving products as loss experience varies between these product and customer groups.  The credit quality categories cannot be compared between the different classes as loss experience varies substantially between the classes.

- added (2020-06-08):
[0001571996-20-000034:note_history:54]
Leases

- added (2020-06-08):
[0001571996-20-000034:note_history:55]
Interest income on sales-type lease receivables was $65 million and $64 million for the three months ended May 1, 2020 and May 3, 2019, respectively.

- added (2020-06-08):
[0001571996-20-000034:note_history:56]
The following table presents the net revenue, cost of net revenue, and gross margin recognized at the commencement date of sales-type leases for the periods indicated:

- added (2020-06-08):
[0001571996-20-000034:note_history:57]
|  | Three Months Ended |
|  | May 1, 2020 |  | May 3, 2019 |
|  | (in millions) |
| Net revenue — products | $ | 215 |  |  | $ | 130 |  |
| Cost of net revenue — products | 159 |  |  | 81 |  |
| Gross margin — products | $ | 56 |  |  | $ | 49 |  |

- added (2020-06-08):
[0001571996-20-000034:note_history:58]
The following table presents the future maturity of the Company’s fixed-term customer leases and associated financing payments, and reconciles the undiscounted cash flows to the customer receivables, gross recognized on the Condensed Consolidated Statements of Financial Position as of the date indicated:

- added (2020-06-08):
[0001571996-20-000034:note_history:59]
|  | May 1, 2020 |
| Fiscal Years | (in millions) |
| Fiscal 2021 (remaining nine months) | $ | 2,050 |  |
| Fiscal 2022 | 1,812 |  |
| Fiscal 2023 | 1,045 |  |
| Fiscal 2024 | 406 |  |
| Fiscal 2025 and beyond | 137 |  |
| Total undiscounted cash flows | 5,450 |  |
| Fixed-term loans | 3,588 |  |
| Revolving loans | 786 |  |
| Less: unearned income | (592 | ) |
| Total customer receivables, gross | $ | 9,232 |  |

- added (2020-06-08):
[0001571996-20-000034:note_history:60]
Operating Leases

- added (2020-06-08):
[0001571996-20-000034:note_history:61]
The following table presents the components of the Company’s operating lease portfolio included in Property, plant, and equipment, net as of the dates indicated:

- added (2020-06-08):
[0001571996-20-000034:note_history:62]
|  | May 1, 2020 |  | January 31, 2020 |
|  | (in millions) |
| Equipment under operating lease, gross | $ | 1,150 |  |  | $ | 956 |  |
| Less: accumulated depreciation | (175 | ) |  | (116 | ) |
| Equipment under operating lease, net | $ | 975 |  |  | $ | 840 |  |

- added (2020-06-08):
[0001571996-20-000034:note_history:63]
Operating lease income relating to lease payments was $87 million and $4 million for the three months ended May 1, 2020 and May 3, 2019, respectively.  Depreciation expense was $62 million and $3 million for the three months ended May 1, 2020 and May 3, 2019, respectively.

- added (2020-06-08):
[0001571996-20-000034:note_history:64]
The following table presents the future payments to be received by the Company as lessor in operating lease contracts as of the date indicated:

- added (2020-06-08):
[0001571996-20-000034:note_history:65]
|  | May 1, 2020 |
| Fiscal Years | (in millions) |
| Fiscal 2021 (remaining nine months) | $ | 306 |  |
| Fiscal 2022 | 370 |  |
| Fiscal 2023 | 269 |  |
| Fiscal 2024 | 54 |  |
| Fiscal 2025 and beyond | 7 |  |
| Total | $ | 1,006 |  |

- added (2020-06-08):
[0001571996-20-000034:note_history:66]
DFS Debt

- added (2020-06-08):
[0001571996-20-000034:note_history:67]
The Company maintains programs that facilitate the funding of leases, loans, and other alternative payment structures in the capital markets.  The majority of DFS debt is non-recourse to Dell Technologies and represents borrowings under securitization programs and structured financing programs, for which the Company’s risk of loss is limited to transferred loan and lease payments and associated equipment.  The following table presents DFS debt as of the dates indicated.  The table excludes the allocated portion of the Company’s other borrowings, which represents the additional amount considered to fund the DFS business.

- added (2020-06-08):
[0001571996-20-000034:note_history:68]
|  | May 1, 2020 |  | January 31, 2020 |
|  | (in millions) |
| DFS U.S. debt: |  |  |  |
| Asset-based financing and securitization facilities | $ | 2,429 |  |  | $ | 2,606 |  |
| Fixed-term securitization offerings | 3,251 |  |  | 2,593 |  |
| Other | 117 |  |  | 141 |  |
| Total DFS U.S. debt | 5,797 |  |  | 5,340 |  |
| DFS international debt: |  |  |  |
| Securitization facility | 773 |  |  | 743 |  |
| Other borrowings | 970 |  |  | 931 |  |
| Note payable | 181 |  |  | 200 |  |
| Dell Bank Senior Unsecured Eurobonds | 548 |  |  | 551 |  |
| Total DFS international debt | 2,472 |  |  | 2,425 |  |
| Total DFS debt | $ | 8,269 |  |  | $ | 7,765 |  |
| Total short-term DFS debt | $ | 4,397 |  |  | $ | 4,152 |  |
| Total long-term DFS debt | $ | 3,872 |  |  | $ | 3,613 |  |

- added (2020-06-08):
[0001571996-20-000034:note_history:69]
DFS U.S. Debt

- added (2020-06-08):
[0001571996-20-000034:note_history:70]
Asset-Based Financing and Securitization Facilities — The Company maintains separate asset-based financing facilities and a securitization facility in the United States, which are revolving facilities for fixed-term leases and loans and for revolving loans, respectively.  This debt is collateralized solely by the U.S. loan and lease payments and associated equipment in the facilities.  The debt has a variable interest rate and the duration of the debt is based on the terms of the underlying loan and lease payment streams.  As of May 1, 2020, the total debt capacity related to the U.S. asset-based financing and securitization facilities was $4.0 billion.  The Company enters into interest swap agreements to effectively convert a portion of this debt from a floating rate to a fixed rate.  See Note 7 of the Notes to the Condensed Consolidated Financial Statements for additional information about interest rate swaps.

- added (2020-06-08):
[0001571996-20-000034:note_history:71]
The Company’s U.S. securitization facility for revolving loans is effective through June 25, 2022.  The Company’s two U.S. asset-based financing facilities for fixed-term leases and loans are effective through August 22, 2021 and July 26, 2022, respectively.

- added (2020-06-08):
[0001571996-20-000034:note_history:72]
The asset-based financing and securitization facilities contain standard structural features related to the performance of the funded receivables, which include defined credit losses, delinquencies, average credit scores, and minimum collection requirements.  In the event one or more of these criteria are not met and the Company is unable to restructure the facility, no further funding of receivables will be permitted and the timing of the Company’s expected cash flows from over-collateralization will be delayed.  As of May 1, 2020, these criteria were met.

- added (2020-06-08):
[0001571996-20-000034:note_history:73]
Fixed-Term Securitization Offerings — The Company periodically issues asset-backed debt securities under fixed-term securitization programs to private investors.  The asset-backed debt securities are collateralized solely by the U.S. fixed-term leases and loans in the offerings, which are held by Special Purpose Entities (“SPEs”), as discussed below.  The interest rate on these securities is fixed and ranges from 1.91% to 5.92% per annum, and the duration of these securities is based on the terms of the underlying loan and lease payment streams.

- added (2020-06-08):
[0001571996-20-000034:note_history:74]
DFS International Debt

- added (2020-06-08):
[0001571996-20-000034:note_history:75]
Securitization Facility — The Company maintains a securitization facility in Europe for fixed-term leases and loans.  This facility is effective through December 21, 2020 and has a total debt capacity of $876 million as of May 1, 2020.

- added (2020-06-08):
[0001571996-20-000034:note_history:76]
The securitization facility contains standard structural features related to the performance of the securitized receivables, which include defined credit losses, delinquencies, average credit scores, and minimum collection requirements.  In the event one or more of these criteria are not met and the Company is unable to restructure the program, no further funding of receivables will be permitted and the timing of the Company’s expected cash flows from over-collateralization will be delayed.  As of May 1, 2020, these criteria were met.

- added (2020-06-08):
[0001571996-20-000034:note_history:77]
Other Borrowings — In connection with the Company’s international financing operations, the Company has entered into revolving structured financing debt programs related to its fixed-term lease and loan products sold in Canada, Europe, Australia, and New Zealand.  The Canadian facility, which is collateralized solely by Canadian loan and lease payments and associated equipment, had a total debt capacity of $269 million as of May 1, 2020, and is effective through January 16, 2023.  The European facility, which is collateralized solely by European loan and lease payments and associated equipment, had a total debt capacity of $657 million as of May 1, 2020, and is effective through June 14, 2022.  The Australia and New Zealand facility, which is collateralized solely by Australia and New Zealand loan and lease payments and associated equipment, had a total debt capacity of $228 million as of May 1, 2020, and is effective through December 20, 2021.

- added (2020-06-08):
[0001571996-20-000034:note_history:78]
Note Payable — On November 27, 2017, the Company entered into an unsecured credit agreement to fund receivables in Mexico.  As of May 1, 2020, the aggregate principal amount of the note payable is $181 million.  The note bears interest at either the applicable London Interbank Offered Rate (“LIBOR”) plus 2.25%, for the borrowings denominated in U.S. dollars, or the Mexican Interbank Equilibrium Interest Rate (“TIIE”) plus 2.00%, for the borrowings denominated in Mexican pesos.  The note will mature on December 1, 2020.

- added (2020-06-08):
[0001571996-20-000034:note_history:79]
Dell Bank Senior Unsecured Eurobonds — On October 17, 2019, Dell Bank International D.A.C. issued 500 million Euro of 0.625% senior unsecured three year eurobonds due October 2022.  The issuance of the senior unsecured eurobonds supports the expansion of the financing operations in Europe.

- added (2020-06-08):
[0001571996-20-000034:note_history:80]
Variable Interest Entities

- added (2020-06-08):
[0001571996-20-000034:note_history:81]
In connection with the asset-based financing facilities, securitization facilities, and fixed-term securitization offerings discussed above, the Company transfers certain U.S. and European loan and lease payments and associated equipment to SPEs that meet the definition of a Variable Interest Entity (“VIE”) and are consolidated, along with the associated debt detailed above, into the Consolidated Financial Statements, as the Company is the primary beneficiary of those VIEs.  The SPEs are bankruptcy-remote legal entities with separate assets and liabilities.  The purpose of the SPEs is to facilitate the funding of customer loan and lease payments and associated equipment in the capital markets.

- added (2020-06-08):
[0001571996-20-000034:note_history:82]
The following table presents financing receivables and equipment under operating leases, net held by the consolidated VIEs as of the dates indicated:

- added (2020-06-08):
[0001571996-20-000034:note_history:83]
|  | May 1, 2020 |  | January 31, 2020 |
|  | (in millions) |
| Assets held by consolidated VIEs, net: |  |  |  |  |  |
| Short-term, net | $ | 3,384 |  |  | $ | 3,316 |  |
| Long-term, net | 3,628 |  |  | 3,348 |  |
| Assets held by consolidated VIEs, net | $ | 7,012 |  |  | $ | 6,664 |  |

- added (2020-06-08):
[0001571996-20-000034:note_history:84]
Loan and lease payments and associated equipment transferred via securitization through SPEs were $1.8 billion and $1.5 billion for the three months ended May 1, 2020 and May 3, 2019, respectively.

- added (2020-06-08):
[0001571996-20-000034:note_history:85]
Some of the SPEs have entered into financing arrangements with multi-seller conduits that, in turn, issue asset-backed debt securities in the capital markets.  The DFS debt outstanding, which is collateralized by the loan and lease payments and associated equipment held by the consolidated VIEs, was $6.5 billion and $5.9 billion as of May 1, 2020 and January 31, 2020, respectively.  The Company’s risk of loss related to securitized receivables is limited to the amount by which the Company’s right to receive collections for assets securitized exceeds the amount required to pay interest, principal, and fees and expenses related to the asset-backed securities.  The Company provides credit enhancement to the securitizations in the form of over-collateralization.

- added (2020-06-08):
[0001571996-20-000034:note_history:86]
Customer Receivables Sales

- added (2020-06-08):
[0001571996-20-000034:note_history:87]
To manage certain concentrations of customer credit exposure, the Company may sell selected fixed-term customer receivables to unrelated third parties on a periodic basis, without recourse.  The amount of customer receivables sold for this purpose was $21 million and $101 million for the three months ended May 1, 2020 and May 3, 2019, respectively.  The Company’s continuing involvement in the above mentioned customer receivables is primarily limited to servicing arrangements.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2020-06-08):
[0001571996-20-000034:note_history:88]
|  | May 1, 2020 |  | January 31, 2020 |
|  | (in millions) |
| Secured Debt |  |  |  |
| Senior Secured Credit Facilities: |  |  |  |
| 2.75% Term Loan B-1 Facility due September 2025 | $ | 4,726 |  |  | $ | 4,738 |  |
| 2.16% Term Loan A-4 Facility due December 2023 | 679 |  |  | 679 |  |
| 2.32% Term Loan A-6 Facility due March 2024 | 3,452 |  |  | 3,497 |  |
| First Lien Notes: |  |  |  |
| 4.42% due June 2021 | 4,500 |  |  | 4,500 |  |
| 5.45% due June 2023 | 3,750 |  |  | 3,750 |  |
| 4.00% due July 2024 | 1,000 |  |  | 1,000 |  |
| 5.85% due July 2025 | 1,000 |  |  | — |  |
| 6.02% due June 2026 | 4,500 |  |  | 4,500 |  |
| 4.90% due October 2026 | 1,750 |  |  | 1,750 |  |
| 6.10% due July 2027 | 500 |  |  | — |  |
| 5.30% due October 2029 | 1,750 |  |  | 1,750 |  |
| 6.20% due July 2030 | 750 |  |  | — |  |
| 8.10% due July 2036 | 1,500 |  |  | 1,500 |  |
| 8.35% due July 2046 | 2,000 |  |  | 2,000 |  |
| Unsecured Debt |  |  |  |
| Unsecured Notes and Debentures: |  |  |  |
| 4.625% due April 2021 | 400 |  |  | 400 |  |
| 7.10% due April 2028 | 300 |  |  | 300 |  |
| 6.50% due April 2038 | 388 |  |  | 388 |  |
| 5.40% due September 2040 | 264 |  |  | 264 |  |
| Senior Notes: |  |  |  |
| 5.875% due June 2021 | 1,075 |  |  | 1,075 |  |
| 7.125% due June 2024 | 1,625 |  |  | 1,625 |  |
| EMC Notes: |  |  |  |
| 2.650% due June 2020 | 600 |  |  | 600 |  |
| 3.375% due June 2023 | 1,000 |  |  | 1,000 |  |
| Debt of Public Subsidiary |  |  |  |
| VMware Notes: |  |  |  |
| 2.30% due August 2020 | 1,250 |  |  | 1,250 |  |
| 2.95% due August 2022 | 1,500 |  |  | 1,500 |  |
| 4.50% due May 2025 | 750 |  |  | — |  |
| 4.65% due May 2027 | 500 |  |  | — |  |
| 3.90% due August 2027 | 1,250 |  |  | 1,250 |  |
| 4.70% due May 2030 | 750 |  |  | — |  |
| VMware Term Loan Facility | 1,500 |  |  | 1,500 |  |
| DFS Debt (Note 4) | 8,269 |  |  | 7,765 |  |
| Other |  |  |  |
| 4.03% Margin Loan Facility due April 2022 | 4,000 |  |  | 4,000 |  |
| Other | 69 |  |  | 84 |  |
| Total debt, principal amount | $ | 57,347 |  |  | $ | 52,665 |  |

- changed (2020-06-08):
[0001571996-20-000034:note_history:89]
|  | May 1, 2020 |  | January 31, 2020 |
|  | (in millions) |
| Total debt, principal amount | $ | 57,347 |  |  | $ | 52,665 |  |
| Unamortized discount, net of unamortized premium | (234 | ) |  | (241 | ) |
| Debt issuance costs | (385 | ) |  | (368 | ) |
| Total debt, carrying value | $ | 56,728 |  |  | $ | 52,056 |  |
| Total short-term debt, carrying value | $ | 8,375 |  |  | $ | 7,737 |  |
| Total long-term debt, carrying value | $ | 48,353 |  |  | $ | 44,319 |  |
  (was, 2019-12-09, similarity 0.9554):
[0001571996-19-000051:note_history:89]
|  | November 1, 2019 |  | February 1, 2019 |
|  | (in millions) |
| Total debt, principal amount | $ | 53,026 |  |  | $ | 54,239 |  |
| Unamortized discount, net of unamortized premium | (246 | ) |  | (271 | ) |
| Debt issuance costs | (389 | ) |  | (447 | ) |
| Total debt, carrying value | $ | 52,391 |  |  | $ | 53,521 |  |
| Total short-term debt, carrying value | $ | 7,664 |  |  | $ | 4,320 |  |
| Total long-term debt, carrying value | $ | 44,727 |  |  | $ | 49,201 |  |

- added (2020-06-08):
[0001571996-20-000034:note_history:90]
During the three months ended May 1, 2020, the net increase in the Company’s debt balance was primarily due to new debt issuances of $2.25 billion of First Lien Notes on April 9, 2020 and $2.0 billion of VMware Notes on April 7, 2020, both described below, and an additional $0.5 billion, net, in DFS debt to support the expansion of its financing receivables portfolio.

- changed (2020-06-08):
[0001571996-20-000034:note_history:91]
Senior Secured Credit Facilities — The Company has entered into a credit agreement that provides for senior secured credit facilities (the “Senior Secured Credit Facilities”) comprising (a) term loan facilities and (b) a senior secured Revolving Credit Facility, which provides for a borrowing capacity of up to $4.5 billion for general corporate purposes, including capacity for up to $0.5 billion of letters of credit and for borrowings of up to $0.4 billion under swing-line loans.
  (was, 2019-12-09, similarity 0.7618):
[0001571996-19-000051:note_history:91]
Senior Secured Credit Facilities — The Company has entered into a credit agreement that provides for senior secured credit facilities (the “Senior Secured Credit Facilities”) comprising (a) term loan facilities and (b) a senior secured Revolving Credit Facility, which includes capacity for up to $0.5 billion of letters of credit and for borrowings of up to $0.4 billion under swing-line loans.

- changed (2020-06-08):
[0001571996-20-000034:note_history:92]
As of May 1, 2020, available borrowings under the Revolving Credit Facility totaled $4.5 billion.  The Senior Secured Credit Facilities provide that the borrowers have the right at any time, subject to customary conditions, to request incremental term loans or incremental revolving commitments.
  (was, 2019-12-09, similarity 0.981):
[0001571996-19-000051:note_history:92]
As of November 1, 2019, available borrowings under the Revolving Credit Facility totaled $4.5 billion.  The Senior Secured Credit Facilities provide that the borrowers have the right at any time, subject to customary conditions, to request incremental term loans or incremental revolving commitments.

- added (2020-06-08):
[0001571996-20-000034:note_history:93]
First Lien Notes — Dell International L.L.C. and EMC Corporation, both of which are wholly-owned subsidiaries of Dell Technologies Inc., completed private offerings of multiple series of senior secured notes (collectively, the “First Lien Notes”) which were issued on June 1, 2016, March 20, 2019, and April 9, 2020 in aggregate principal amounts of $20.0 billion, $4.5 billion, and $2.25 billion, respectively.  Interest on the First Lien Notes is payable semiannually.  The First Lien Notes are secured on a pari passu basis with the Senior Secured Credit Facilities, on a first-priority basis by substantially all of the tangible and intangible assets of the issuers and guarantors that secure obligations under the Senior Secured Credit Facilities, including pledges of all capital stock of the issuers, Dell, and certain wholly-owned material subsidiaries of the issuers and the guarantors, subject to certain exceptions.

- changed (2020-06-08):
[0001571996-20-000034:note_history:94]
The Company has agreed to use commercially reasonable efforts to register with the SEC notes having terms substantially identical to the terms of the First Lien Notes as part of an offer to exchange such registered notes for the First Lien Notes.  The Company will be obligated to pay additional interest on the First Lien Notes if it fails to consummate such an exchange offer within five years after the closing date of the EMC merger transaction, in the case of the First Lien Notes issued on June 1, 2016 and within five years after their respective issue dates, in the case of the First Lien Notes issued on March 20, 2019 and April 9, 2020.
  (was, 2019-12-09, similarity 0.9628):
[0001571996-19-000051:note_history:94]
The Company has agreed to use commercially reasonable efforts to register with the SEC notes having terms substantially identical to the terms of the First Lien Notes as part of an offer to exchange such registered notes for the First Lien Notes.  The Company will be obligated to pay additional interest on the First Lien Notes if it fails to consummate such an exchange offer within five years after the closing date of the EMC merger transaction, in the case of the First Lien Notes issued on June 1, 2016, and within five years after their issue date, in the case of the First Lien Notes issued on March 20, 2019.

- added (2020-06-08):
[0001571996-20-000034:note_history:95]
China Revolving Credit Facility — During the fiscal year ended January 31, 2020, the Company renewed its credit agreement for a China revolving credit facility with a bank lender, which provided an uncommitted line with an aggregate principal amount not to exceed $500 million at an interest rate of LIBOR plus 0.6% per annum.  The facility was terminated upon expiration on February 26, 2020.

- added (2020-06-08):
[0001571996-20-000034:note_history:96]
VMware Notes — VMware, Inc. completed public offerings of unsecured senior notes in the aggregate amounts of $4.0 billion and $2.0 billion on August 21, 2017 and April 7, 2020, respectively (the “VMware Notes”).  None of the net proceeds of such borrowings will be made available to support the operations or satisfy any corporate purposes of Dell Technologies, other than the operations and corporate purposes of VMware, Inc. and VMware, Inc.’s subsidiaries.  Interest on these borrowings is payable semiannually.

- changed (2020-06-08):
[0001571996-20-000034:note_history:97]
VMware Revolving Credit Facility — On September 12, 2017, VMware, Inc. entered into an unsecured credit agreement, establishing a revolving credit facility (the “VMware Revolving Credit Facility”) with a syndicate of lenders that provides the company with a borrowing capacity of up to $1.0 billion for VMware, Inc. general corporate purposes.  Commitments under the VMware Revolving Credit Facility are available for a period of five years, which may be extended, subject to the satisfaction of certain conditions, by up to two one year periods.  The credit agreement contains certain representations, warranties, and covenants.  Commitment fees, interest rates, and other terms of borrowing under the VMware Revolving Credit Facility may vary based on VMware, Inc.’s external credit ratings.  None of the net proceeds of such borrowings will be made available to support the operations or satisfy any corporate purposes of Dell Technologies, other than the operations and corporate purposes of VMware, Inc. and VMware, Inc.’s subsidiaries.  As of May 1, 2020, there were no outstanding borrowings under the VMware Revolving Credit Facility.
  (was, 2019-12-09, similarity 0.9951):
[0001571996-19-000051:note_history:97]
VMware Revolving Credit Facility — On September 12, 2017, VMware, Inc. entered into an unsecured credit agreement, establishing a revolving credit facility (the “VMware Revolving Credit Facility”) with a syndicate of lenders that provides the company with a borrowing capacity of up to $1.0 billion for VMware, Inc. general corporate purposes.  Commitments under the VMware Revolving Credit Facility are available for a period of five years, which may be extended, subject to the satisfaction of certain conditions, by up to two one year periods.  The credit agreement contains certain representations, warranties, and covenants.  Commitment fees, interest rates, and other terms of borrowing under the VMware Revolving Credit Facility may vary based on VMware, Inc.’s external credit ratings.  None of the net proceeds of such borrowings will be made available to support the operations or satisfy any corporate purposes of Dell Technologies, other than the operations and corporate purposes of VMware, Inc. and VMware, Inc.’s subsidiaries.  As of November 1, 2019, there were no outstanding borrowings under the VMware Revolving Credit Facility.

- added (2020-06-08):
[0001571996-20-000034:note_history:98]
VMware Term Loan Facility — On September 26, 2019, VMware, Inc. entered into a senior unsecured term loan facility (the “VMware Term Loan Facility”) with a syndicate of lenders that provided VMware, Inc. with a borrowing capacity of up to $2.0 billion through February 7, 2020, for VMware, Inc. general corporate purposes.  The VMware Term Loan Facility matures on the 364th day following the initial funding under the facility.  The VMware Term Loan Facility bears interest at LIBOR plus 0.75% to 1.25%, or an alternative base rate plus 0.00% to 0.25%, depending on VMware Inc.’s external credit ratings.

- added (2020-06-08):
[0001571996-20-000034:note_history:99]
As of May 1, 2020 and January 31, 2020, the outstanding borrowings under the VMware Term Loan Facility were $1.5 billion, with no remaining amount available for additional borrowings.  The VMware Term Loan Facility contains certain representations, warranties, and covenants.  None of the net proceeds of such borrowings will be made available to support the operations or satisfy any corporate purposes of Dell Technologies, other than the operations and corporate purposes of VMware, Inc. and VMware, Inc.’s subsidiaries.

- added (2020-06-08):
[0001571996-20-000034:note_history:100]
Margin Loan Facility — On April 12, 2017, the Company entered into the Margin Loan Facility in an aggregate principal amount of $2.0 billion, under which VMW Holdco LLC, a wholly-owned subsidiary of EMC, is the borrower.  In connection with the Class V transaction described in Note 1 of the Notes to the Condensed Consolidated Financial Statements, on December 20, 2018, the Company amended the Margin Loan Facility to increase the aggregate principal amount to $3.35 billion.  In connection with obtaining the Term Loan A-6 Facility during the fiscal year ended January 31, 2020, the Company increased the aggregate principal amount of the Margin Loan Facility to $4.0 billion.

- added (2020-06-08):
[0001571996-20-000034:note_history:101]
During the three months ended May 1, 2020, due to volatility in the U.S. stock market resulting from the outbreak of COVID-19, VMware Holdco LLC proactively pledged additional shares of VMware, Inc. common stock to secure its obligations under the Margin Loan Facility agreement.  This resulted in an aggregate number of shares pledged of approximately 76 million shares of Class B common stock of VMware, Inc. and approximately 24 million shares of Class A common stock of VMware, Inc.

- changed (2020-06-08):
[0001571996-20-000034:note_history:102]
Loans under the Margin Loan Facility bear interest at a rate per annum payable, at the borrower’s option, either at (a) a base rate plus 1.25% per annum or (b) a LIBOR-based rate plus 2.25% per annum.  Interest under the Margin Loan Facility is payable quarterly.  The Margin Loan Facility will mature in April 2022.  The borrower may voluntarily repay outstanding loans under the Margin Loan Facility at any time without premium or penalty, other than customary “breakage” costs, subject to certain minimum threshold amounts for prepayment.
  (was, 2019-12-09, similarity 0.6783):
[0001571996-19-000051:note_history:102]
The Margin Loan Facility will mature in April 2022.  The borrower may voluntarily repay outstanding loans under the Margin Loan Facility at any time without premium or penalty, other than customary “breakage” costs, subject to certain minimum threshold amounts for prepayment.

- changed (2020-06-08):
[0001571996-20-000034:note_history:103]
The following table presents the aggregate future maturities of the Company’s debt as of May 1, 2020 for the periods indicated:
  (was, 2019-12-09, similarity 0.9641):
[0001571996-19-000051:note_history:103]
The following table presents the aggregate future maturities of the Company’s debt as of November 1, 2019 for the periods indicated:

- changed (2020-06-08):
[0001571996-20-000034:note_history:104]
|  | Maturities by Fiscal Year |
|  | 2021 (remaining nine months) |  | 2022 |  | 2023 |  | 2024 |  | 2025 |  | Thereafter |  | Total |
|  | (in millions) |
| Senior Secured Credit Facilities and First Lien Notes | $ | 172 |  |  | $ | 4,672 |  |  | $ | 286 |  |  | $ | 6,702 |  |  | $ | 1,775 |  |  | $ | 18,250 |  |  | $ | 31,857 |  |
| Unsecured Notes and Debentures | — |  |  | 400 |  |  | — |  |  | — |  |  | — |  |  | 952 |  |  | 1,352 |  |
| Senior Notes and EMC Notes | 600 |  |  | 1,075 |  |  | — |  |  | 1,000 |  |  | 1,625 |  |  | — |  |  | 4,300 |  |
| VMware Notes | 2,750 |  |  | — |  |  | 1,500 |  |  | — |  |  | — |  |  | 3,250 |  |  | 7,500 |  |
| DFS Debt | 3,661 |  |  | 2,537 |  |  | 1,877 |  |  | 157 |  |  | 37 |  |  | — |  |  | 8,269 |  |
| Margin Loan Facility | — |  |  | — |  |  | 4,000 |  |  | — |  |  | — |  |  | — |  |  | 4,000 |  |
| Other | 8 |  |  | 6 |  |  | 7 |  |  | 8 |  |  | 7 |  |  | 33 |  |  | 69 |  |
| Total maturities, principal amount | 7,191 |  |  | 8,690 |  |  | 7,670 |  |  | 7,867 |  |  | 3,444 |  |  | 22,485 |  |  | 57,347 |  |
| Associated carrying value adjustments | (2 | ) |  | (43 | ) |  | (24 | ) |  | (47 | ) |  | (91 | ) |  | (412 | ) |  | (619 | ) |
| Total maturities, carrying value amount | $ | 7,189 |  |  | $ | 8,647 |  |  | $ | 7,646 |  |  | $ | 7,820 |  |  | $ | 3,353 |  |  | $ | 22,073 |  |  | $ | 56,728 |  |
  (was, 2019-12-09, similarity 0.903):
[0001571996-19-000051:note_history:104]
|  | Maturities by Fiscal Year |
|  | 2020 (remaining three months) |  | 2021 |  | 2022 |  | 2023 |  | 2024 |  | Thereafter |  | Total |
|  | (in millions) |
| Senior Secured Credit Facilities and First Lien Notes | $ | 91 |  |  | $ | 184 |  |  | $ | 4,717 |  |  | $ | 286 |  |  | $ | 6,702 |  |  | $ | 17,742 |  |  | $ | 29,722 |  |
| Unsecured Notes and Debentures | — |  |  | — |  |  | 400 |  |  | — |  |  | — |  |  | 952 |  |  | 1,352 |  |
| Senior Notes and EMC Notes | — |  |  | 2,000 |  |  | 1,075 |  |  | — |  |  | 1,000 |  |  | 1,625 |  |  | 5,700 |  |
| VMware Notes | — |  |  | 1,850 |  |  | — |  |  | 1,500 |  |  | — |  |  | 1,250 |  |  | 4,600 |  |
| DFS Debt | 1,249 |  |  | 3,611 |  |  | 1,418 |  |  | 1,198 |  |  | 84 |  |  | 8 |  |  | 7,568 |  |
| Margin Loan Facility | — |  |  | — |  |  | — |  |  | 4,000 |  |  | — |  |  | — |  |  | 4,000 |  |
| Other | 11 |  |  | 21 |  |  | 7 |  |  | 8 |  |  | 7 |  |  | 30 |  |  | 84 |  |
| Total maturities, principal amount | 1,351 |  |  | 7,666 |  |  | 7,617 |  |  | 6,992 |  |  | 7,793 |  |  | 21,607 |  |  | 53,026 |  |
| Associated carrying value adjustments | — |  |  | (8 | ) |  | (57 | ) |  | (26 | ) |  | (53 | ) |  | (491 | ) |  | (635 | ) |
| Total maturities, carrying value amount | $ | 1,351 |  |  | $ | 7,658 |  |  | $ | 7,560 |  |  | $ | 6,966 |  |  | $ | 7,740 |  |  | $ | 21,116 |  |  | $ | 52,391 |  |

- changed (2020-06-08):
[0001571996-20-000034:note_history:105]
As of May 1, 2020, the Company had certain consolidated subsidiaries that were designated as unrestricted subsidiaries for all purposes of the applicable credit agreements and the indentures governing the First Lien Notes and the Senior Notes.  Substantially all of the net assets of the Company’s consolidated subsidiaries were restricted, with the exception of the Company’s unrestricted subsidiaries, primarily VMware, Inc., Secureworks, and their respective subsidiaries, as of May 1, 2020.
  (was, 2019-12-09, similarity 0.9685):
[0001571996-19-000051:note_history:105]
As of November 1, 2019, the Company had certain consolidated subsidiaries that were designated as unrestricted subsidiaries for all purposes of the applicable credit agreements and the indentures governing the First Lien Notes and the Senior Notes.  Substantially all of the net assets of the Company’s consolidated subsidiaries were restricted, with the exception of the Company’s unrestricted subsidiaries, primarily VMware, Inc., Pivotal, Secureworks, and their respective subsidiaries, as of November 1, 2019.

- changed (2020-06-08):
[0001571996-20-000034:note_history:106]
The Term Loan A-4 Facility, the Term Loan A-6 Facility, and the Revolving Credit Facility are subject to a first lien leverage ratio covenant that is tested at the end of each fiscal quarter of Dell with respect to Dell’s preceding four fiscal quarters.  The Company was in compliance with all financial covenants as of May 1, 2020.
  (was, 2019-12-09, similarity 0.9833):
[0001571996-19-000051:note_history:106]
The Term Loan A-4 Facility, the Term Loan A-6 Facility, and the Revolving Credit Facility are subject to a first lien leverage ratio covenant that is tested at the end of each fiscal quarter of Dell with respect to Dell’s preceding four fiscal quarters.  The Company was in compliance with all financial covenants as of November 1, 2019.

- removed (2020-06-08):
[0001571996-19-000051:note_history:107]
|  | November 1, 2019 |  | February 1, 2019 |
|  | (in millions) |
| Secured Debt |  |  |  |
| Senior Secured Credit Facilities: |  |  |  |
| 4.24% Term Loan B Facility due September 2023 | $ | — |  |  | $ | 4,938 |  |
| 3.79% Term Loan B-1 Facility due September 2025 | 4,750 |  |  | — |  |
| 4.16% Term Loan A-2 Facility due September 2021 | — |  |  | 4,116 |  |
| 3.54% Term Loan A-4 Facility due December 2023 | 679 |  |  | 1,650 |  |
| 4.25% Term Loan A-5 Facility due December 2019 | — |  |  | 2,016 |  |
| 3.60% Term Loan A-6 Facility due March 2024 | 3,543 |  |  | — |  |
| First Lien Notes: |  |  |  |
| 3.48% due June 2019 | — |  |  | 3,750 |  |
| 4.42% due June 2021 | 4,500 |  |  | 4,500 |  |
| 5.45% due June 2023 | 3,750 |  |  | 3,750 |  |
| 4.00% due July 2024 | 1,000 |  |  | — |  |
| 6.02% due June 2026 | 4,500 |  |  | 4,500 |  |
| 4.90% due October 2026 | 1,750 |  |  | — |  |
| 5.30% due October 2029 | 1,750 |  |  | — |  |
| 8.10% due July 2036 | 1,500 |  |  | 1,500 |  |
| 8.35% due July 2046 | 2,000 |  |  | 2,000 |  |
| Unsecured Debt |  |  |  |
| Unsecured Notes and Debentures: |  |  |  |
| 5.875% due June 2019 | — |  |  | 600 |  |
| 4.625% due April 2021 | 400 |  |  | 400 |  |
| 7.10% due April 2028 | 300 |  |  | 300 |  |
| 6.50% due April 2038 | 388 |  |  | 388 |  |
| 5.40% due September 2040 | 264 |  |  | 264 |  |
| Senior Notes: |  |  |  |
| 5.875% due June 2021 | 1,075 |  |  | 1,625 |  |
| 7.125% due June 2024 | 1,625 |  |  | 1,625 |  |
| EMC Notes: |  |  |  |
| 2.650% due June 2020 | 2,000 |  |  | 2,000 |  |
| 3.375% due June 2023 | 1,000 |  |  | 1,000 |  |
| Public Subsidiary Debt |  |  |  |
| VMware Notes: |  |  |  |
| 2.30% due August 2020 | 1,250 |  |  | 1,250 |  |
| 2.95% due August 2022 | 1,500 |  |  | 1,500 |  |
| 3.90% due August 2027 | 1,250 |  |  | 1,250 |  |
| VMware Term Loan Facility | 600 |  |  | — |  |
| DFS Debt (Note 4) | 7,568 |  |  | 5,929 |  |
| Other |  |  |  |
| 4.18% Margin Loan Facility due April 2022 | 4,000 |  |  | 3,350 |  |
| Other | 84 |  |  | 38 |  |
| Total debt, principal amount | $ | 53,026 |  |  | $ | 54,239 |  |

- removed (2020-06-08):
[0001571996-19-000051:note_history:108]
During the nine months ended November 1, 2019, the Company repaid $550 million principal amount of its 5.875% senior unsecured notes due June 2021, $600 million principal amount of its 5.875% senior unsecured notes due June 2019 upon maturity, $950 million principal amount of its Term Loan A-4 Facility, and approximately $136 million of principal amortization under its term loan facilities.  The Company also repaid $162.5 million principal amount as part of the Term Loan B Facility refinancing and the remaining principal amount of approximately $1,277 million of its Term Loan A-2 Facility in connection with the First Lien Notes issued on March 20, 2019, as described below under “Refinancing Transactions.”  Additionally, during the nine months ended November 1, 2019, the Company issued an additional $1.6 billion, net, in DFS debt to support the expansion of its financing receivables portfolio.

- removed (2020-06-08):
[0001571996-19-000051:note_history:109]
Refinancing Transactions

- removed (2020-06-08):
[0001571996-19-000051:note_history:110]
On March 7, 2019, the Company amended the Margin Loan Agreement to increase the aggregate principal amount of borrowings under the Margin Loan Facility by $650 million.

- removed (2020-06-08):
[0001571996-19-000051:note_history:111]
On March 13, 2019, the Company entered into an amendment to the credit agreement for the Senior Secured Credit Facilities to obtain a new senior secured Term Loan A-6 Facility in order to refinance the $5 billion aggregate principal amount of debt incurred in connection with the Class V transaction described in Note 14 of the Notes to the Condensed Consolidated Financial Statements.  The Term Loan A-6 Facility aggregate principal amount of $3,634 million matures on March 13, 2024, of which $2,839 million aggregate principal amount represents the amounts outstanding under the Term Loan A-2 Facility that rolled-over into the new facility.  Immediately after the rollover, an aggregate principal amount of $1,277 million remained outstanding under the Term Loan A-2 Facility.

- removed (2020-06-08):
[0001571996-19-000051:note_history:112]
On March 20, 2019, Dell International L.L.C. and EMC Corporation, both of which are wholly-owned subsidiaries of Dell Technologies Inc., completed a private offering of multiple series of First Lien Notes in an aggregate principal amount of $4.5 billion.  The principal amount, interest rate, and maturity of each series of such First Lien Notes were $1,000 million of 4.00% First Lien Notes due July 15, 2024, $1,750 million of 4.90% First Lien Notes due October 1, 2026, and $1,750 million of 5.30% First Lien Notes due October 1, 2029.

- removed (2020-06-08):
[0001571996-19-000051:note_history:113]
A majority of the proceeds from the First Lien Notes issued on March 20, 2019 was used to repay all of the outstanding $3,750 million principal amount of the 3.48% First Lien Notes due June 2019.  In addition, proceeds of approximately $800 million of borrowings under the new Term Loan A-6 Facility, the proceeds of the $650 million increase in the Margin Loan Facility, and a portion of the proceeds from the 2019 First Lien Notes were used to repay all $2,016 million of the Company’s outstanding amounts under the Term Loan A-5 Facility due December 2019.  During the three months ended May 3, 2019, the remaining proceeds available from the 2019 First Lien Notes were used to repay $550 million of outstanding amounts under the Term Loan A-2 Facility and to pay related premiums, accrued interest, fees, and expenses.  The Term Loan A-2 Facility was subsequently paid off as of August 2, 2019.

- removed (2020-06-08):
[0001571996-19-000051:note_history:114]
On September 19, 2019, the Company entered into a sixth refinancing amendment to the Senior Secured Credit Agreement (the “Sixth Refinancing Amendment”) to refinance the Term Loan B Facility due September 2023 with a new term loan B facility consisting of an aggregate principal amount of $4,750 million refinancing term B-1 loans maturing on September 19, 2025 (“Term Loan B-1 Facility due September 2025” or “Term Loan B-1 Facility”).  The Company used the proceeds from the Term Loan B-1 Facility, together with other funds available, to repay $4,913 million of outstanding amounts under the Term Loan B Facility due September 2023 and to pay related accrued interest, fees and expenses.

- removed (2020-06-08):
[0001571996-19-000051:note_history:115]
The refinancing and amendments were evaluated in accordance with FASB ASC 470, “Debt-Modifications and Extinguishments.”  The amendment to the Margin Loan Agreement and the term debt refinancing were accounted for as modifications for all existing lenders and as new issuances for new lenders.  The First Lien Notes issued on March 20, 2019 were accounted for as new issuances for all lenders, and repayment of the Company’s outstanding amounts under the Term Loan A-5 Facility was accounted for as an extinguishment.  During the three months ended May 3, 2019, the Company capitalized $74.5 million in new fees paid to creditors as a result of the modifications and new issuances.  In addition, the Company recognized expenses of $32.3 million in unamortized costs and $7.1 million in new third-party costs during the three months ended May 3, 2019.  The Term Loan B Facility refinancing was accounted for as a modification for all existing lenders and as a new issuance for new lenders.  During the three months ended November 1, 2019, the Company capitalized $5.9 million in new fees paid to creditors as a result of the modifications and new issuances.  In addition, the Company recognized expenses of $1.5 million in unamortized costs and $5.1 million in new third-party costs during the three months ended November 1, 2019.

- removed (2020-06-08):
[0001571996-19-000051:note_history:116]
First Lien Notes — The senior secured notes (collectively, the “First Lien Notes”) were issued on June 1, 2016 and March 20, 2019 in an aggregate principal amount of $20.0 billion and $4.5 billion, respectively.  As discussed above, during the three months ended May 3, 2019, the Company used a portion of the $4.5 billion proceeds from the First Lien Notes issued on March 20, 2019 to repay all of the outstanding $3,750 million principal amount of its 3.48% First Lien Notes due June 2019.  Interest on these borrowings is payable semiannually.  The First Lien Notes are secured on a pari passu basis with the Senior Secured Credit Facilities, on a first-priority basis by substantially all of the tangible and intangible assets of the issuers and guarantors that secure obligations under the Senior Secured Credit Facilities, including pledges of all capital stock of the issuers, Dell, and certain wholly-owned material subsidiaries of the issuers and the guarantors, subject to certain exceptions.

- removed (2020-06-08):
[0001571996-19-000051:note_history:117]
China Revolving Credit Facility — During the three months ended May 3, 2019, the Company renewed its credit agreement (the “China Revolving Credit Facility”) with a bank lender for a secured revolving loan facility in an aggregate principal amount not to exceed $500 million at an interest rate of LIBOR plus 0.6% per annum.  The facility will expire on February 26, 2020.  As of November 1, 2019, there were no outstanding borrowings under the China Revolving Credit Facility.

- removed (2020-06-08):
[0001571996-19-000051:note_history:118]
VMware Notes — On August 21, 2017, VMware, Inc. completed a public offering of unsecured senior notes in the aggregate amount of $4.0 billion, consisting of outstanding principal due on the following dates: $1.25 billion due August 21, 2020, $1.5 billion due August 21, 2022, and $1.25 billion due August 21, 2027 (collectively, the “VMware Notes”).  The VMware Notes bear interest, payable semiannually, at annual rates of 2.30%, 2.95%, and 3.90%, respectively.  None of the net proceeds of such borrowings will be made available to support the operations or satisfy any corporate purposes of Dell Technologies, other than the operations and corporate purposes of VMware, Inc. and VMware, Inc.’s subsidiaries.

- removed (2020-06-08):
[0001571996-19-000051:note_history:119]
VMware Term Loan Facility — On September 26, 2019, VMware, Inc. entered into a senior unsecured term loan facility (the “VMware Term Loan Facility”) with a syndicate of lenders that provides VMware, Inc. with a borrowing capacity of up to $2.0 billion for VMware, Inc. general corporate purposes.  VMware, Inc. may borrow against the VMware Term Loan Facility two times up to its borrowing capacity of $2.0 billion until February 7, 2020.  The VMware Term Loan Facility matures on the 364th day following the initial funding under the facility.  The VMware Term Loan Facility bears interest at LIBOR plus 0.75% to 1.25%, or an alternative base rate plus 0.00% to 0.25%, depending on VMware Inc.’s external credit ratings.  VMware, Inc. drew down $2.0 billion and repaid $1.4 billion during the three months ended November 1, 2019.  As of November 1, 2019, the outstanding balance was $600 million, and $1.4 billion remained available to be drawn down for future borrowing purposes.  The VMware Term Loan Facility contains certain representations, warranties, and covenants.  None of the net proceeds of such borrowings will be made available to support the operations or satisfy any corporate purposes of Dell Technologies, other than the operations and corporate purposes of VMware, Inc. and VMware, Inc.’s subsidiaries.

- removed (2020-06-08):
[0001571996-19-000051:note_history:120]
Margin Loan Facility — On April 12, 2017, the Company entered into the Margin Loan Facility in an aggregate principal amount of $2.0 billion.  In connection with the Class V transaction, on December 20, 2018, the Company amended the Margin Loan Facility to increase the aggregate principal amount to $3.35 billion.  In connection with obtaining the Term Loan A-6 Facility, the Company increased the aggregate principal amount of the Margin Loan Facility to $4.0 billion.  VMW Holdco LLC, a wholly-owned subsidiary of EMC, is the borrower under the Margin Loan Facility, which is secured by 60 million shares of Class B common stock of VMware, Inc. and 20 million shares of Class A common stock of VMware, Inc.  Loans under the Margin Loan Facility bear interest at a rate per annum payable, at the borrower’s option, either at (a) a base rate plus 1.25% per annum or (b) a LIBOR-based rate plus 2.25% per annum.  Interest under the Margin Loan Facility is payable quarterly.

- removed (2020-06-08):
[0001571996-19-000051:note_history:121]
Pivotal Revolving Credit Facility — On September 7, 2017, Pivotal entered into a credit agreement (the “Pivotal Revolving Credit Facility”) that provided for a senior secured revolving loan facility in an aggregate principal amount not to exceed $100 million.   The credit facility contained customary representations, warranties, and covenants, including financial covenants.  During the three months ended November 1, 2019, the Pivotal Revolving Credit Facility was terminated.


## us-gaap:ScheduleOfCarryingValuesAndEstimatedFairValuesOfDebtInstrumentsTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-06-08):
[0001571996-20-000034:note_history:122]
|  | May 1, 2020 |  | January 31, 2020 |
|  | Carrying Value |  | Fair Value |  | Carrying Value |  | Fair Value |
|  | (in billions) |
| Senior Secured Credit Facilities | $ | 8.7 |  |  | $ | 8.6 |  |  | $ | 8.8 |  |  | $ | 9.0 |  |
| First Lien Notes | $ | 22.8 |  |  | $ | 24.8 |  |  | $ | 20.5 |  |  | $ | 23.9 |  |
| Unsecured Notes and Debentures | $ | 1.2 |  |  | $ | 1.4 |  |  | $ | 1.2 |  |  | $ | 1.5 |  |
| Senior Notes | $ | 2.6 |  |  | $ | 2.8 |  |  | $ | 2.6 |  |  | $ | 2.8 |  |
| EMC Notes | $ | 1.6 |  |  | $ | 1.6 |  |  | $ | 1.6 |  |  | $ | 1.6 |  |
| VMware Notes and VMware Term Loan Facility | $ | 7.5 |  |  | $ | 7.7 |  |  | $ | 5.5 |  |  | $ | 5.6 |  |
| Margin Loan Facility | $ | 4.0 |  |  | $ | 3.9 |  |  | $ | 4.0 |  |  | $ | 3.9 |  |
  (was, 2019-12-09, similarity 0.9734):
[0001571996-19-000051:note_history:122]
|  | November 1, 2019 |  | February 1, 2019 |
|  | Carrying Value |  | Fair Value |  | Carrying Value |  | Fair Value |
|  | (in billions) |
| Senior Secured Credit Facilities | $ | 8.9 |  |  | $ | 9.0 |  |  | $ | 12.5 |  |  | $ | 12.6 |  |
| First Lien Notes | $ | 20.5 |  |  | $ | 23.3 |  |  | $ | 19.8 |  |  | $ | 21.0 |  |
| Unsecured Notes and Debentures | $ | 1.2 |  |  | $ | 1.4 |  |  | $ | 1.8 |  |  | $ | 1.9 |  |
| Senior Notes | $ | 2.6 |  |  | $ | 2.8 |  |  | $ | 3.1 |  |  | $ | 3.4 |  |
| EMC Notes | $ | 3.0 |  |  | $ | 3.0 |  |  | $ | 3.0 |  |  | $ | 2.9 |  |
| VMware Notes and VMware Term Loan Facility | $ | 4.6 |  |  | $ | 4.7 |  |  | $ | 4.0 |  |  | $ | 3.9 |  |
| Margin Loan Facility | $ | 4.0 |  |  | $ | 4.0 |  |  | $ | 3.3 |  |  | $ | 3.4 |  |


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2020-06-08):
[0001571996-20-000034:note_history:123]
|  | May 1, 2020 |  | January 31, 2020 |
|  | (in millions) |
| DFS U.S. debt: |  |  |  |
| Asset-based financing and securitization facilities | $ | 2,429 |  |  | $ | 2,606 |  |
| Fixed-term securitization offerings | 3,251 |  |  | 2,593 |  |
| Other | 117 |  |  | 141 |  |
| Total DFS U.S. debt | 5,797 |  |  | 5,340 |  |
| DFS international debt: |  |  |  |
| Securitization facility | 773 |  |  | 743 |  |
| Other borrowings | 970 |  |  | 931 |  |
| Note payable | 181 |  |  | 200 |  |
| Dell Bank Senior Unsecured Eurobonds | 548 |  |  | 551 |  |
| Total DFS international debt | 2,472 |  |  | 2,425 |  |
| Total DFS debt | $ | 8,269 |  |  | $ | 7,765 |  |
| Total short-term DFS debt | $ | 4,397 |  |  | $ | 4,152 |  |
| Total long-term DFS debt | $ | 3,872 |  |  | $ | 3,613 |  |

- added (2020-06-08):
[0001571996-20-000034:note_history:124]
|  | May 1, 2020 |  | January 31, 2020 |
|  | (in millions) |
| Secured Debt |  |  |  |
| Senior Secured Credit Facilities: |  |  |  |
| 2.75% Term Loan B-1 Facility due September 2025 | $ | 4,726 |  |  | $ | 4,738 |  |
| 2.16% Term Loan A-4 Facility due December 2023 | 679 |  |  | 679 |  |
| 2.32% Term Loan A-6 Facility due March 2024 | 3,452 |  |  | 3,497 |  |
| First Lien Notes: |  |  |  |
| 4.42% due June 2021 | 4,500 |  |  | 4,500 |  |
| 5.45% due June 2023 | 3,750 |  |  | 3,750 |  |
| 4.00% due July 2024 | 1,000 |  |  | 1,000 |  |
| 5.85% due July 2025 | 1,000 |  |  | — |  |
| 6.02% due June 2026 | 4,500 |  |  | 4,500 |  |
| 4.90% due October 2026 | 1,750 |  |  | 1,750 |  |
| 6.10% due July 2027 | 500 |  |  | — |  |
| 5.30% due October 2029 | 1,750 |  |  | 1,750 |  |
| 6.20% due July 2030 | 750 |  |  | — |  |
| 8.10% due July 2036 | 1,500 |  |  | 1,500 |  |
| 8.35% due July 2046 | 2,000 |  |  | 2,000 |  |
| Unsecured Debt |  |  |  |
| Unsecured Notes and Debentures: |  |  |  |
| 4.625% due April 2021 | 400 |  |  | 400 |  |
| 7.10% due April 2028 | 300 |  |  | 300 |  |
| 6.50% due April 2038 | 388 |  |  | 388 |  |
| 5.40% due September 2040 | 264 |  |  | 264 |  |
| Senior Notes: |  |  |  |
| 5.875% due June 2021 | 1,075 |  |  | 1,075 |  |
| 7.125% due June 2024 | 1,625 |  |  | 1,625 |  |
| EMC Notes: |  |  |  |
| 2.650% due June 2020 | 600 |  |  | 600 |  |
| 3.375% due June 2023 | 1,000 |  |  | 1,000 |  |
| Debt of Public Subsidiary |  |  |  |
| VMware Notes: |  |  |  |
| 2.30% due August 2020 | 1,250 |  |  | 1,250 |  |
| 2.95% due August 2022 | 1,500 |  |  | 1,500 |  |
| 4.50% due May 2025 | 750 |  |  | — |  |
| 4.65% due May 2027 | 500 |  |  | — |  |
| 3.90% due August 2027 | 1,250 |  |  | 1,250 |  |
| 4.70% due May 2030 | 750 |  |  | — |  |
| VMware Term Loan Facility | 1,500 |  |  | 1,500 |  |
| DFS Debt (Note 4) | 8,269 |  |  | 7,765 |  |
| Other |  |  |  |
| 4.03% Margin Loan Facility due April 2022 | 4,000 |  |  | 4,000 |  |
| Other | 69 |  |  | 84 |  |
| Total debt, principal amount | $ | 57,347 |  |  | $ | 52,665 |  |

- changed (2020-06-08):
[0001571996-20-000034:note_history:125]
|  | May 1, 2020 |  | January 31, 2020 |
|  | (in millions) |
| Total debt, principal amount | $ | 57,347 |  |  | $ | 52,665 |  |
| Unamortized discount, net of unamortized premium | (234 | ) |  | (241 | ) |
| Debt issuance costs | (385 | ) |  | (368 | ) |
| Total debt, carrying value | $ | 56,728 |  |  | $ | 52,056 |  |
| Total short-term debt, carrying value | $ | 8,375 |  |  | $ | 7,737 |  |
| Total long-term debt, carrying value | $ | 48,353 |  |  | $ | 44,319 |  |
  (was, 2019-12-09, similarity 0.9554):
[0001571996-19-000051:note_history:125]
|  | November 1, 2019 |  | February 1, 2019 |
|  | (in millions) |
| Total debt, principal amount | $ | 53,026 |  |  | $ | 54,239 |  |
| Unamortized discount, net of unamortized premium | (246 | ) |  | (271 | ) |
| Debt issuance costs | (389 | ) |  | (447 | ) |
| Total debt, carrying value | $ | 52,391 |  |  | $ | 53,521 |  |
| Total short-term debt, carrying value | $ | 7,664 |  |  | $ | 4,320 |  |
| Total long-term debt, carrying value | $ | 44,727 |  |  | $ | 49,201 |  |

- removed (2020-06-08):
[0001571996-19-000051:note_history:126]
|  | November 1, 2019 |  | February 1, 2019 |
|  | (in millions) |
| DFS U.S. debt: |  |  |  |
| Securitization facilities | $ | 2,019 |  |  | $ | 1,914 |  |
| Fixed-term securitization offerings | 3,003 |  |  | 2,303 |  |
| Other | 183 |  |  | 223 |  |
| Total DFS U.S. debt | 5,205 |  |  | 4,440 |  |
| DFS international debt: |  |  |  |
| Securitization facility | 716 |  |  | 584 |  |
| Other borrowings | 893 |  |  | 708 |  |
| Note payable | 198 |  |  | 197 |  |
| Dell Bank Senior Unsecured Eurobonds | 556 |  |  | — |  |
| Total DFS international debt | 2,363 |  |  | 1,489 |  |
| Total DFS debt | $ | 7,568 |  |  | $ | 5,929 |  |
| Total short-term DFS debt | $ | 3,576 |  |  | $ | 3,113 |  |
| Total long-term DFS debt | $ | 3,992 |  |  | $ | 2,816 |  |

- removed (2020-06-08):
[0001571996-19-000051:note_history:127]
|  | November 1, 2019 |  | February 1, 2019 |
|  | (in millions) |
| Secured Debt |  |  |  |
| Senior Secured Credit Facilities: |  |  |  |
| 4.24% Term Loan B Facility due September 2023 | $ | — |  |  | $ | 4,938 |  |
| 3.79% Term Loan B-1 Facility due September 2025 | 4,750 |  |  | — |  |
| 4.16% Term Loan A-2 Facility due September 2021 | — |  |  | 4,116 |  |
| 3.54% Term Loan A-4 Facility due December 2023 | 679 |  |  | 1,650 |  |
| 4.25% Term Loan A-5 Facility due December 2019 | — |  |  | 2,016 |  |
| 3.60% Term Loan A-6 Facility due March 2024 | 3,543 |  |  | — |  |
| First Lien Notes: |  |  |  |
| 3.48% due June 2019 | — |  |  | 3,750 |  |
| 4.42% due June 2021 | 4,500 |  |  | 4,500 |  |
| 5.45% due June 2023 | 3,750 |  |  | 3,750 |  |
| 4.00% due July 2024 | 1,000 |  |  | — |  |
| 6.02% due June 2026 | 4,500 |  |  | 4,500 |  |
| 4.90% due October 2026 | 1,750 |  |  | — |  |
| 5.30% due October 2029 | 1,750 |  |  | — |  |
| 8.10% due July 2036 | 1,500 |  |  | 1,500 |  |
| 8.35% due July 2046 | 2,000 |  |  | 2,000 |  |
| Unsecured Debt |  |  |  |
| Unsecured Notes and Debentures: |  |  |  |
| 5.875% due June 2019 | — |  |  | 600 |  |
| 4.625% due April 2021 | 400 |  |  | 400 |  |
| 7.10% due April 2028 | 300 |  |  | 300 |  |
| 6.50% due April 2038 | 388 |  |  | 388 |  |
| 5.40% due September 2040 | 264 |  |  | 264 |  |
| Senior Notes: |  |  |  |
| 5.875% due June 2021 | 1,075 |  |  | 1,625 |  |
| 7.125% due June 2024 | 1,625 |  |  | 1,625 |  |
| EMC Notes: |  |  |  |
| 2.650% due June 2020 | 2,000 |  |  | 2,000 |  |
| 3.375% due June 2023 | 1,000 |  |  | 1,000 |  |
| Public Subsidiary Debt |  |  |  |
| VMware Notes: |  |  |  |
| 2.30% due August 2020 | 1,250 |  |  | 1,250 |  |
| 2.95% due August 2022 | 1,500 |  |  | 1,500 |  |
| 3.90% due August 2027 | 1,250 |  |  | 1,250 |  |
| VMware Term Loan Facility | 600 |  |  | — |  |
| DFS Debt (Note 4) | 7,568 |  |  | 5,929 |  |
| Other |  |  |  |
| 4.18% Margin Loan Facility due April 2022 | 4,000 |  |  | 3,350 |  |
| Other | 84 |  |  | 38 |  |
| Total debt, principal amount | $ | 53,026 |  |  | $ | 54,239 |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-06-08):
[0001571996-20-000034:note_history:128]
The following table presents the aggregate future maturities of the Company’s debt as of May 1, 2020 for the periods indicated:
  (was, 2019-12-09, similarity 0.9641):
[0001571996-19-000051:note_history:128]
The following table presents the aggregate future maturities of the Company’s debt as of November 1, 2019 for the periods indicated:

- changed (2020-06-08):
[0001571996-20-000034:note_history:129]
|  | Maturities by Fiscal Year |
|  | 2021 (remaining nine months) |  | 2022 |  | 2023 |  | 2024 |  | 2025 |  | Thereafter |  | Total |
|  | (in millions) |
| Senior Secured Credit Facilities and First Lien Notes | $ | 172 |  |  | $ | 4,672 |  |  | $ | 286 |  |  | $ | 6,702 |  |  | $ | 1,775 |  |  | $ | 18,250 |  |  | $ | 31,857 |  |
| Unsecured Notes and Debentures | — |  |  | 400 |  |  | — |  |  | — |  |  | — |  |  | 952 |  |  | 1,352 |  |
| Senior Notes and EMC Notes | 600 |  |  | 1,075 |  |  | — |  |  | 1,000 |  |  | 1,625 |  |  | — |  |  | 4,300 |  |
| VMware Notes | 2,750 |  |  | — |  |  | 1,500 |  |  | — |  |  | — |  |  | 3,250 |  |  | 7,500 |  |
| DFS Debt | 3,661 |  |  | 2,537 |  |  | 1,877 |  |  | 157 |  |  | 37 |  |  | — |  |  | 8,269 |  |
| Margin Loan Facility | — |  |  | — |  |  | 4,000 |  |  | — |  |  | — |  |  | — |  |  | 4,000 |  |
| Other | 8 |  |  | 6 |  |  | 7 |  |  | 8 |  |  | 7 |  |  | 33 |  |  | 69 |  |
| Total maturities, principal amount | 7,191 |  |  | 8,690 |  |  | 7,670 |  |  | 7,867 |  |  | 3,444 |  |  | 22,485 |  |  | 57,347 |  |
| Associated carrying value adjustments | (2 | ) |  | (43 | ) |  | (24 | ) |  | (47 | ) |  | (91 | ) |  | (412 | ) |  | (619 | ) |
| Total maturities, carrying value amount | $ | 7,189 |  |  | $ | 8,647 |  |  | $ | 7,646 |  |  | $ | 7,820 |  |  | $ | 3,353 |  |  | $ | 22,073 |  |  | $ | 56,728 |  |
  (was, 2019-12-09, similarity 0.903):
[0001571996-19-000051:note_history:129]
|  | Maturities by Fiscal Year |
|  | 2020 (remaining three months) |  | 2021 |  | 2022 |  | 2023 |  | 2024 |  | Thereafter |  | Total |
|  | (in millions) |
| Senior Secured Credit Facilities and First Lien Notes | $ | 91 |  |  | $ | 184 |  |  | $ | 4,717 |  |  | $ | 286 |  |  | $ | 6,702 |  |  | $ | 17,742 |  |  | $ | 29,722 |  |
| Unsecured Notes and Debentures | — |  |  | — |  |  | 400 |  |  | — |  |  | — |  |  | 952 |  |  | 1,352 |  |
| Senior Notes and EMC Notes | — |  |  | 2,000 |  |  | 1,075 |  |  | — |  |  | 1,000 |  |  | 1,625 |  |  | 5,700 |  |
| VMware Notes | — |  |  | 1,850 |  |  | — |  |  | 1,500 |  |  | — |  |  | 1,250 |  |  | 4,600 |  |
| DFS Debt | 1,249 |  |  | 3,611 |  |  | 1,418 |  |  | 1,198 |  |  | 84 |  |  | 8 |  |  | 7,568 |  |
| Margin Loan Facility | — |  |  | — |  |  | — |  |  | 4,000 |  |  | — |  |  | — |  |  | 4,000 |  |
| Other | 11 |  |  | 21 |  |  | 7 |  |  | 8 |  |  | 7 |  |  | 30 |  |  | 84 |  |
| Total maturities, principal amount | 1,351 |  |  | 7,666 |  |  | 7,617 |  |  | 6,992 |  |  | 7,793 |  |  | 21,607 |  |  | 53,026 |  |
| Associated carrying value adjustments | — |  |  | (8 | ) |  | (57 | ) |  | (26 | ) |  | (53 | ) |  | (491 | ) |  | (635 | ) |
| Total maturities, carrying value amount | $ | 1,351 |  |  | $ | 7,658 |  |  | $ | 7,560 |  |  | $ | 6,966 |  |  | $ | 7,740 |  |  | $ | 21,116 |  |  | $ | 52,391 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2020-06-08):
[0001571996-20-000034:note_history:130]
|  | Three Months Ended |
|  | May 1, 2020 |  | May 3, 2019 |
|  | (in millions) |
| Net revenue: |  |  |  |  |
| Infrastructure Solutions Group: |  |  |  |
| Servers and networking | $ | 3,758 |  |  | $ | 4,180 |  |
| Storage | 3,811 |  |  | 4,022 |  |
| Total ISG net revenue | 7,569 |  |  | 8,202 |  |
| Client Solutions Group: |  |  |  |
| Commercial | 8,634 |  |  | 8,307 |  |
| Consumer | 2,470 |  |  | 2,603 |  |
| Total CSG net revenue | 11,104 |  |  | 10,910 |  |
| VMware: |  |  |  |
| Total VMware net revenue | 2,755 |  |  | 2,457 |  |
| Total segment net revenue | $ | 21,428 |  |  | $ | 21,569 |  |
  (was, 2019-12-09, similarity 0.7735):
[0001571996-19-000051:note_history:130]
|  | Three Months Ended |  | Nine Months Ended |
|  | November 1, 2019 |  | November 2, 2018 |  | November 1, 2019 |  | November 2, 2018 |
|  | (in millions) |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |
| Infrastructure Solutions Group: |  |  |  |  |  |  |  |
| Servers and networking | $ | 4,241 |  |  | $ | 5,054 |  |  | $ | 12,858 |  |  | $ | 14,700 |  |
| Storage | 4,149 |  |  | 3,883 |  |  | 12,355 |  |  | 12,131 |  |
| Total ISG net revenue | 8,390 |  |  | 8,937 |  |  | 25,213 |  |  | 26,831 |  |
| Client Solutions Group: |  |  |  |  |  |  |  |
| Commercial | 8,330 |  |  | 7,613 |  |  | 25,714 |  |  | 23,085 |  |
| Consumer | 3,080 |  |  | 3,292 |  |  | 8,354 |  |  | 9,219 |  |
| Total CSG net revenue | 11,410 |  |  | 10,905 |  |  | 34,068 |  |  | 32,304 |  |
| VMware: |  |  |  |  |  |  |  |
| Total VMware net revenue | 2,483 |  |  | 2,229 |  |  | 7,231 |  |  | 6,451 |  |
| Total segment net revenue | $ | 22,283 |  |  | $ | 22,071 |  |  | $ | 66,512 |  |  | $ | 65,586 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2020-06-08):
[0001571996-20-000034:note_history:131]
|  | Three Months Ended |
|  | May 1, 2020 |  | May 3, 2019 |
|  | (in millions) |
| Deferred revenue: |  |  |  |
| Deferred revenue at beginning of period | $ | 27,800 |  |  | $ | 24,010 |  |
| Revenue deferrals | 5,423 |  |  | 4,900 |  |
| Revenue recognized | (5,356 | ) |  | (4,732 | ) |
| Other (a) | (250 | ) |  | — |  |
| Deferred revenue at end of period | $ | 27,617 |  |  | $ | 24,178 |  |
| Short-term deferred revenue | $ | 14,766 |  |  | $ | 13,043 |  |
| Long-term deferred revenue | $ | 12,851 |  |  | $ | 11,135 |  |
  (was, 2019-12-09, similarity 0.697):
[0001571996-19-000051:note_history:131]
|  | Three Months Ended |  | Nine Months Ended |
|  | November 1, 2019 |  | November 2, 2018 |  | November 1, 2019 |  | November 2, 2018 |
|  | (in millions) |
| Deferred revenue: |  |  |  |  |  |  |  |
| Deferred revenue at beginning of period | $ | 25,348 |  |  | $ | 21,700 |  |  | $ | 24,010 |  |  | $ | 20,816 |  |
| Revenue deferrals for new contracts and changes in estimates for pre-existing contracts (a) (b) | 5,326 |  |  | 4,852 |  |  | 16,201 |  |  | 14,165 |  |
| Revenue recognized (b) | (4,922 | ) |  | (4,409 | ) |  | (14,459 | ) |  | (12,838 | ) |
| Other (c) | 151 |  |  | — |  |  | 151 |  |  | — |  |
| Deferred revenue at end of period | $ | 25,903 |  |  | $ | 22,143 |  |  | $ | 25,903 |  |  | $ | 22,143 |  |
| Short-term deferred revenue | $ | 13,787 |  |  | $ | 12,079 |  |  | $ | 13,787 |  |  | $ | 12,079 |  |
| Long-term deferred revenue | $ | 12,116 |  |  | $ | 10,064 |  |  | $ | 12,116 |  |  | $ | 10,064 |  |

- added (2020-06-08):
[0001571996-20-000034:note_history:132]
(a) Reclassification of RSA Security deferred revenue to liabilities held for sale as of May 1, 2020.  See Note 1 of the Notes to the Condensed Consolidated Financial Statements for more information about the pending divestiture of RSA Security.

- changed (2020-06-08):
[0001571996-20-000034:note_history:133]
Remaining Performance Obligations — Remaining performance obligations represent the aggregate amount of the transaction price allocated to performance obligations not delivered, or partially undelivered, as of the end of the reporting period.  Remaining performance obligations include deferred revenue plus unbilled amounts not yet recorded in deferred revenue.  The value of the transaction price allocated to remaining performance obligations as of May 1, 2020 was approximately $37 billion.  The Company expects to recognize approximately 63% of remaining performance obligations as revenue in the next twelve months, and the remainder thereafter.
  (was, 2019-12-09, similarity 0.613):
[0001571996-19-000051:note_history:133]
Remaining Performance Obligations — Remaining performance obligations represent the aggregate amount of the transaction price allocated to performance obligations not delivered, or partially undelivered, as of the end of the reporting period.  Remaining performance obligations include deferred revenue plus unbilled amounts not yet recorded in deferred revenue.  The aggregate amount of the transaction price allocated to remaining performance obligations does not include amounts owed under cancelable contracts where there is no substantive termination penalty.

- added (2020-06-08):
[0001571996-20-000034:note_history:134]
The aggregate amount of the transaction price allocated to remaining performance obligations does not include amounts owed under cancelable contracts where there is no substantive termination penalty.  The Company applied the practical expedient to exclude the value of remaining performance obligations for contracts for which revenue is recognized at the amount to which the Company has the right to invoice for services performed.

- removed (2020-06-08):
[0001571996-19-000051:note_history:135]
| (a) | Includes the impact of foreign currency exchange rate fluctuations. |

- removed (2020-06-08):
[0001571996-19-000051:note_history:136]
| (b) | The Company conformed the presentation of certain deferred revenue rollforward activity for the three and nine months ended November 2, 2018 to align current year presentation. The beginning and ending deferred revenue liability balances remain unchanged. |

- removed (2020-06-08):
[0001571996-19-000051:note_history:137]
(c)   Acquired deferred revenue from Carbon Black, Inc. by VMware, Inc. during the three months ended November 1, 2019. See Note 8 of the Notes to the Condensed Consolidated Financial Statements for additional information related to this acquisition.

- removed (2020-06-08):
[0001571996-19-000051:note_history:138]
The Company applied the practical expedient to exclude the value of remaining performance obligations for contracts for which revenue is recognized at the amount to which the Company has the right to invoice for services performed.  The Company also applied the practical expedient to not disclose the amount of transaction price allocated to remaining performance obligations for the periods prior to adoption of the new revenue standard.

- removed (2020-06-08):
[0001571996-19-000051:note_history:139]
The value of the transaction price allocated to remaining performance obligations as of November 1, 2019 was approximately $34 billion.  The Company expects to recognize approximately 62% of remaining performance obligations as revenue in the next twelve months, and the remainder thereafter.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_prior_note, score: 0.0

- added (2020-06-08):
[0001571996-20-000034:note_history:140]
NOTE 19 — SUBSEQUENT EVENTS

- added (2020-06-08):
[0001571996-20-000034:note_history:141]
On May 11, 2020, VMware, Inc. repaid $1.25 billion principal amount of its 2.30% Notes due August 2020.

- added (2020-06-08):
[0001571996-20-000034:note_history:142]
The Company entered into a new revolving credit facility for China (the “China Revolving Credit Facility”) effective May 25, 2020.  The new terms provide for collateralized and non-collateralized principal amounts not to exceed $1.0 billion Chinese renminbi and $1.8 billion Chinese renminbi, respectively, or equivalent amounts in U.S. dollars.  Outstanding borrowings under the collateralized portion of the China Revolving Credit Facility bear interest at the loan prime rate (LPR) less 0.2%, for borrowings denominated in Chinese renminbi, or LIBOR plus 1.0%, for borrowings denominated in U.S. dollars, and outstanding borrowings under the non-collateralized portion bear interest at LPR less 0.2%, for borrowings denominated in Chinese renminbi, or LIBOR plus 1.4%, for borrowings denominated in U.S. dollars.  The new facility expires on August 30, 2020.

- added (2020-06-08):
[0001571996-20-000034:note_history:143]
Other than the matters identified above, there were no known events occurring after May 1, 2020 and up until the date of the issuance of this report that would materially affect the information presented herein.
