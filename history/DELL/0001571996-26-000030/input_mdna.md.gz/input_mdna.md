# DELL MD&A — 0001571996-26-000030


## mdna

[0001571996-26-000030:mdna:1]
[same as prior period, unchanged from 0001571996-25-000127:mdna:1]

[0001571996-26-000030:mdna:2]
[same as prior period, unchanged from 0001571996-25-000127:mdna:2]

[0001571996-26-000030:mdna:3]
Unless the context indicates otherwise, references in this management’s discussion and analysis to “we,” “us,” “our,” the “Company,” and “Dell Technologies” mean Dell Technologies Inc. and its consolidated subsidiaries.

[0001571996-26-000030:mdna:4]
Our fiscal year is the 52- or 53-week period ending on the Friday nearest January 31. We refer to our fiscal year ending January 29, 2027 as “Fiscal 2027” and our fiscal year ended January 30, 2026 as “Fiscal 2026.” Fiscal 2027 and Fiscal 2026 include 52 weeks.

[0001571996-26-000030:mdna:5]
[same as prior period, unchanged from 0001571996-25-000127:mdna:5]

[0001571996-26-000030:mdna:6]
[same as prior period, unchanged from 0001571996-25-000127:mdna:6]

[0001571996-26-000030:mdna:7]
[same as prior period, unchanged from 0001571996-25-000127:mdna:7]

[0001571996-26-000030:mdna:8]
[same as prior period, unchanged from 0001571996-25-000127:mdna:8]

[0001571996-26-000030:mdna:9]
Infrastructure Solutions Group (“ISG”) — We provide a comprehensive portfolio of advanced infrastructure solutions designed to help customers simplify, streamline, and automate information technology (“IT”) operations. ISG also offers software, peripherals, and services, including consulting and support and deployment. Our major product categories within ISG include our AI-optimized servers offerings, our traditional servers and networking offerings, and our storage offerings.

[0001571996-26-000030:mdna:10]
•AI-optimized servers — We offer a specialized portfolio of AI-optimized servers designed to handle the most demanding compute-intensive workloads, including AI model training, fine-tuning, and inferencing.

[0001571996-26-000030:mdna:11]
•Traditional servers and networking — Our traditional servers portfolio provides the trusted foundation for modern IT environments, supporting a wide range of general-purpose and mission-critical workloads, including certain AI-related workloads such as inferencing. Our networking portfolio helps our business customers transform and modernize their infrastructure, complementing our storage and AI-optimized and traditional servers offerings, and includes wide area network infrastructure, data center and edge networking switches, and cables and optics.

[0001571996-26-000030:mdna:12]
•Storage — Our comprehensive storage portfolio includes modern and traditional storage solutions that span primary, unstructured and data protection offerings and are delivered through multiple architectures, including all-flash, purpose-built, software-defined, and hyper-converged infrastructure platforms.

[0001571996-26-000030:mdna:13]
47

[0001571996-26-000030:mdna:14]
Client Solutions Group (“CSG”) — Our CSG portfolio includes branded personal computers (“PCs”), including notebooks, desktops, and workstations, branded peripherals, and third-party software and peripherals. CSG also includes services offerings, such as configuration, support and deployment, and extended warranties. Our major product categories within CSG include our commercial offerings and consumer offerings.

[0001571996-26-000030:mdna:15]
•Commercial — Our commercial portfolio provides customers with solutions centered on flexibility to address their complex needs such as IT modernization, hybrid work transformation, and other critical areas.

[0001571996-26-000030:mdna:16]
•Consumer — Our consumer portfolio provides customers with solutions ranging from essential computing, connectivity, and productivity needs of the everyday user to powerful performance, processing, and end-user experiences in high-end consumer and gaming offerings.

[0001571996-26-000030:mdna:17]
Corporate and other primarily consists of our historical resale of standalone offerings of VMware LLC (formerly VMware, Inc. and individually and together with its subsidiaries, “VMware”), referred to as “VMware Resale.” These offerings are no longer actively sold and Corporate and other is not classified as an operating segment.

[0001571996-26-000030:mdna:18]
[same as prior period, unchanged from 0001571996-25-000127:mdna:13]

[0001571996-26-000030:mdna:19]
[same as prior period, unchanged from 0001571996-25-000127:mdna:14]

[0001571996-26-000030:mdna:20]
[same as prior period, unchanged from 0001571996-25-000127:mdna:15]

[0001571996-26-000030:mdna:21]
During the first quarter of Fiscal 2027, we executed our strategy and delivered exceptional operating results, generating significant net revenue and operating income growth. The following trends and conditions affected the environment in which we operated:

[0001571996-26-000030:mdna:22]
•Macroeconomic environment: We experienced substantial demand growth across our ISG offerings, resulting in ISG net revenue growth and a continued shift in the mix of the business towards our ISG offerings. Additionally, the demand environment was significant for our CSG offerings, resulting in CSG net revenue growth.

[0001571996-26-000030:mdna:23]
•Demand for AI-optimized servers: Our ISG business benefitted from substantial demand for our AI-optimized servers offerings as customers continue to adopt and further integrate AI, resulting in a significant increase in backlog as we exited the quarter. Given the scale of the AI opportunities, the varying stages of customer readiness, and the frequency of component part updates or transitions, there is inherent non-linearity in the timing of demand and subsequent shipments for our AI-optimized servers offerings, which continues to drive variability in our revenue.

[0001571996-26-000030:mdna:24]
•Technology refresh: Within our ISG business, we continue to see customers modernize and consolidate their data centers as more customers transition to next-generation products and expand capacity to support growing workloads, which has resulted in significant demand within our traditional servers and networking offerings and our storage offerings. Additionally, within our CSG business, the PC refresh cycle is underway as customers continue to upgrade their devices, which has contributed to significant demand for our commercial offerings.

[0001571996-26-000030:mdna:25]
•Supply Chain: We experienced an increase in input costs, driven primarily by higher component costs. Strong and accelerating industry demand for AI‑optimized solutions, together with current limitations in capacity from memory manufacturers, has resulted in global supply constraints and substantial inflation in memory component costs.

[0001571996-26-000030:mdna:26]
•Business modernization initiatives: We continue to prioritize ongoing modernization initiatives to achieve greater efficiencies and streamline our processes, while also continuing to make strategic investments designed to enable growth and innovation. These initiatives have partially contributed to a net reduction in our operating expense rate.

[0001571996-26-000030:mdna:27]
We remain focused on executing our key strategic priorities, creating long-term value for our shareholders, and addressing our customers’ needs. We have the following expectations regarding our performance for the full fiscal year:

[0001571996-26-000030:mdna:28]
•Revenue: Overall, while customers continue to reassess their spending priorities throughout the year in light of the dynamic commodity supply environment, we expect significant ISG and strong CSG net revenue growth. We expect ISG net revenue growth will be driven largely by increased demand for our servers and networking offerings and, to a lesser extent, our storage offerings. We anticipate CSG net revenue growth to be driven in part by the continuation of the PC refresh cycle.

[0001571996-26-000030:mdna:29]
•Gross margin: We expect margin growth, while balancing anticipated margin rate pressure resulting from a continuing shift in mix towards our AI-optimized servers offerings. We expect the notable inflationary environment for component costs will persist throughout the remainder of Fiscal 2027. We continue to monitor the rapidly evolving commodity supply environment and will leverage the agility and scale of our world-class supply chain as we seek to maintain disciplined pricing while balancing profitability and growth.

[0001571996-26-000030:mdna:30]
•Operating expenses: We continue to advance our own capabilities to change the way we work and make decisions, improve business outcomes and the customer experience, leverage new technology, and optimize business processes. We remain committed to disciplined cost management in coordination with our ongoing business modernization initiatives, and expect to continue to scale operating expenses as we take targeted measures to manage costs, including employee reorganizations, limitation of external hiring, and other actions to align our investments with our strategic priorities and customer needs.

[0001571996-26-000030:mdna:31]
We believe our unique operating advantages provide a foundation to foster business growth, enable innovation, drive efficiencies, and continue to position us for long-term success.

[0001571996-26-000030:mdna:32]
ISG — We expect that ISG will be influenced by the dynamic nature of the IT infrastructure market and the competitive landscape. With our extensive scale and market-leading solutions portfolio, we believe we are well-positioned to navigate these competitive dynamics and evolving technology trends to meet customer needs. By leveraging our collaborative, customer-focused approach to innovation, we aim to deliver relevant new and next-generation solutions and software to our customers swiftly and efficiently. We remain focused on expanding our customer base and enhancing the lifetime value of our customer relationships.

[0001571996-26-000030:mdna:33]
We anticipate that ISG will continue to benefit from technology advancements and interest in AI as customers continue to adopt and integrate AI. The timing of customer purchases reflects the varying stages of adoption of AI by different customer segments and drives variability in our revenue. To meet the growing demand and increasing complexity of our AI-optimized servers offerings, we have increased our purchases of certain components with suppliers, which has resulted in increased inventory levels, higher purchase obligations, and new working capital dynamics. Additionally, frequent component part updates or transitions create additional challenges in managing demand and supply levels. While we have seen lead times shorten, we anticipate the next generation of these components, for which demand remains high, will be subject to supply constraints.

[0001571996-26-000030:mdna:34]
[same as prior period, unchanged from 0001571996-25-000127:mdna:27]

[0001571996-26-000030:mdna:35]
CSG — Our CSG offerings are an important element of our strategy, generating strong cash flow and opportunities for cross-selling of complementary solutions. We maintain a broad presence across all segments of the PC market. Our strategic focus is on driving share gain while balancing profitability across all segments, enhancing our product portfolio to address evolving customer needs, and expanding our presence across the broader PC ecosystem through branded peripherals. We anticipate that CSG will benefit from advances in AI over the long-term as customers will require PCs with the ability to run their complex AI workloads.

[0001571996-26-000030:mdna:36]
Competitive dynamics remain an important factor in our CSG business and continue to influence pricing and operating results. We are committed to our long-term CSG strategy and will continue to make investments to innovate across the portfolio. We expect that the CSG demand environment will continue to be subject to seasonal trends and to be influenced by the PC refresh cycle.

[0001571996-26-000030:mdna:37]
Relationship with VMware — In March 2024, following the acquisition of VMware by Broadcom, we terminated our Commercial Framework Agreement with VMware, whereby we acted as a distributor of VMware standalone products and services. We no longer act as a distributor of those products and services, although we continue to support customers that have purchased resale offerings sold in prior periods. We continue to integrate and embed certain VMware products and services with our VxRail solution for end-user customers. The results for this integrated offering are reflected within ISG.

[0001571996-26-000030:mdna:38]
[same as prior period, unchanged from 0001571996-25-000127:mdna:30]

[0001571996-26-000030:mdna:39]
[same as prior period, unchanged from 0001571996-25-000127:mdna:31]

[0001571996-26-000030:mdna:40]
Foreign Currency Exposure — We manage our business on a U.S. Dollar basis. However, we have a large global presence, generating approximately 45% and 50% of our net revenue from sales to customers outside of the United States during the first quarter of Fiscal 2027 and the first quarter of Fiscal 2026, respectively. As a result, our operating results can be impacted by fluctuations in foreign currency exchange rates. We utilize a comprehensive hedging strategy intended to mitigate the impact of foreign currency volatility over time, and we adjust pricing when possible to further minimize foreign currency impacts.

[0001571996-26-000030:mdna:41]
Other Macroeconomic Risks and Uncertainties — The impacts of trade protection measures, including changes in tariffs and trade barriers, changes in government policies and international trade arrangements, geopolitical volatility associated with terrorism, military conflicts (including the Iran conflict), and other events, and global macroeconomic conditions, or uncertainty regarding the impact of proposed or future trade protection measures, may affect our results of operations in some markets. We continue to leverage the agility and scale of our world-class supply chain to mitigate impacts of trade protection measures and will continue to respond to changing market conditions as needed.

[0001571996-26-000030:mdna:42]
50

[0001571996-26-000030:mdna:43]
[same as prior period, unchanged from 0001571996-25-000127:mdna:35]

[0001571996-26-000030:mdna:44]
In this management’s discussion and analysis, we use supplemental measures of our performance which are derived from our consolidated financial information but which are not presented in our consolidated financial statements prepared in accordance with GAAP. These non-GAAP financial measures include non-GAAP product gross margin; non-GAAP services gross margin; non-GAAP gross margin; non-GAAP operating expenses; non-GAAP operating income; non-GAAP net income; non-GAAP earnings per share - diluted; free cash flow; and adjusted free cash flow. These non-GAAP financial measures are not meant to be considered as indicators of performance or liquidity in isolation from or as a substitute for gross margin, operating expenses, operating income, net income, diluted earnings per share, or cash flows from operating activities prepared in accordance with GAAP, and should be read only in conjunction with financial information presented on a GAAP basis.

[0001571996-26-000030:mdna:45]
[same as prior period, unchanged from 0001571996-25-000127:mdna:37]

[0001571996-26-000030:mdna:46]
Non-GAAP product gross margin, non-GAAP services gross margin, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP operating income, non-GAAP net income, and non-GAAP earnings per share - diluted, as defined by us, exclude amortization of intangible assets, stock-based compensation expense, other corporate (income) expenses and, for non-GAAP net income and non-GAAP earnings per share - diluted, fair value adjustments on equity investments and an aggregate adjustment for income taxes. As the excluded items may have a material impact on our financial results, our management compensates for this limitation by relying primarily on our GAAP results and using non-GAAP financial measures supplementally or for projections when comparable GAAP financial measures are not available.

[0001571996-26-000030:mdna:47]
[same as prior period, unchanged from 0001571996-25-000127:mdna:39]

[0001571996-26-000030:mdna:48]
[same as prior period, unchanged from 0001571996-25-000127:mdna:40]

[0001571996-26-000030:mdna:49]
[same as prior period, unchanged from 0001571996-25-000127:mdna:41]

[0001571996-26-000030:mdna:50]
•Stock-based Compensation Expense — Stock-based compensation expense consists of equity awards granted based on the estimated fair value of those awards at grant date. To estimate the fair value of performance-based awards containing a market condition, we use the Monte Carlo valuation model. For other share-based awards, the fair value is generally based on the closing price of the Class C Common Stock as reported on the New York Stock Exchange on the date of grant or most recent preceding trading day if the grant date falls on a non-trading day. Although stock-based compensation is an important aspect of the compensation of our employees and executives, we exclude such expense because the fair value of the stock-based awards may fluctuate based on factors unrelated to the operating performance of the business and may bear little resemblance to the actual value realized upon the vesting or future exercise of the related stock-based awards.

[0001571996-26-000030:mdna:51]
•Other Corporate (Income) Expenses — Other corporate (income) expenses consist primarily of severance expenses, transaction-related impacts of the sales of businesses, payroll taxes associated with stock-based compensation, incentive charges related to equity investments, and transaction-related expenses. Severance costs are primarily related to severance and benefits for employees impacted by cost management initiatives. During the first quarter of Fiscal 2027, we recognized $0.2 billion of severance expense related to workforce reduction activities. During the first quarter of Fiscal 2026, we recognized a $0.2 billion gain related to the sale of our subsidiary SecureWorks Corp. (“Secureworks”). Although we may incur these types of items in the future, we exclude other corporate (income) expenses as they can vary from period to period, are significantly impacted by the timing and nature of these events, and are not used by management in assessing operating performance of the business.

[0001571996-26-000030:mdna:52]
•Fair Value Adjustments on Equity Investments — Fair value adjustments on equity investments primarily consist of the gain (loss) on strategic investments, which includes recurring fair value adjustments of investments in publicly-traded companies, as well as those in privately-held companies, which are adjusted for observable price changes and any potential impairments. During the first quarter of Fiscal 2027, we recognized a $0.6 billion gain from our strategic investment portfolio related to a single investee. See Note 3 of the Notes to the Condensed Consolidated Financial Statements included in this report for additional information on our strategic investment activity. We exclude fair value adjustments on equity investments given the volatility in ongoing adjustments to the valuation of these strategic investments and because such adjustments are unrelated to the operating performance of our business.

[0001571996-26-000030:mdna:53]
•Aggregate Adjustment for Income Taxes — The aggregate adjustment for income taxes is the estimated combined income tax effect for the adjustments described above and determined based on the tax jurisdictions where those adjustments were incurred, as well as an adjustment for discrete tax items. We exclude these benefits or charges for purposes of calculating non-GAAP net income due to the variability in recognition of discrete tax items from period to period. The tax effects are determined based on the tax jurisdictions where the above items were incurred. See Note 11 of the Notes to the Condensed Consolidated Financial Statements included in this report for additional information about our income taxes. Our non-GAAP income tax was calculated using a fixed estimated annual tax rate that is determined based on historical trends and projections for the current fiscal year. We may adjust our estimated annual tax rate during the fiscal year to take into account events that would significantly impact our income tax expense, including significant changes resulting from tax legislation, material changes in geographic mix of net revenue and expenses, changes to our corporate structure, and other significant events.

[0001571996-26-000030:mdna:54]
[same as prior period, unchanged from 0001571996-25-000127:mdna:47]

[0001571996-26-000030:mdna:55]
|  |  |  | Three Months Ended |
|  |  |  |  |  |  |  | May 1, 2026 |  | % Change |  | May 2, 2025 |  |  |  |  |
|  |  |  |  |  |  |  | (in millions, except percentages) |
| Product gross margin |  |  |  |  |  |  | $ | 5,253 |  |  | 112 | % |  | $ | 2,483 |  |  |  |  |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles |  |  |  |  |  |  | 26 |  |  |  |  | 41 |  |  |  |  |  |
| Stock-based compensation expense |  |  |  |  |  |  | 21 |  |  |  |  | 15 |  |  |  |  |  |
| Other corporate expenses |  |  |  |  |  |  | 9 |  |  |  |  | 9 |  |  |  |  |  |
| Non-GAAP product gross margin |  |  |  |  |  |  | $ | 5,309 |  |  | 108 | % |  | $ | 2,548 |  |  |  |  |  |
| Services gross margin |  |  |  |  |  |  | $ | 2,529 |  |  | 3 | % |  | $ | 2,454 |  |  |  |  |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation expense |  |  |  |  |  |  | 23 |  |  |  |  | 24 |  |  |  |  |  |
| Other corporate expenses |  |  |  |  |  |  | 86 |  |  |  |  | 31 |  |  |  |  |  |
| Non-GAAP services gross margin |  |  |  |  |  |  | $ | 2,638 |  |  | 5 | % |  | $ | 2,509 |  |  |  |  |  |

[0001571996-26-000030:mdna:56]
[same as prior period, unchanged from 0001571996-25-000127:mdna:11]

[0001571996-26-000030:mdna:57]
|  |  |  | Three Months Ended |
|  |  |  |  |  |  |  | May 1, 2026 |  | % Change |  | May 2, 2025 |  |  |  |  |
|  |  |  |  |  |  |  | (in millions, except percentages and per share amounts) |
| Gross margin |  |  |  |  |  |  | $ | 7,782 |  |  | 58 | % |  | $ | 4,937 |  |  |  |  |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles |  |  |  |  |  |  | 26 |  |  |  |  | 41 |  |  |  |  |  |
| Stock-based compensation expense |  |  |  |  |  |  | 44 |  |  |  |  | 39 |  |  |  |  |  |
| Other corporate expenses |  |  |  |  |  |  | 95 |  |  |  |  | 40 |  |  |  |  |  |
| Non-GAAP gross margin |  |  |  |  |  |  | $ | 7,947 |  |  | 57 | % |  | $ | 5,057 |  |  |  |  |  |
| Operating expenses |  |  |  |  |  |  | $ | 4,126 |  |  | 9 | % |  | $ | 3,772 |  |  |  |  |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles |  |  |  |  |  |  | (71) |  |  |  |  | (85) |  |  |  |  |  |
| Stock-based compensation expense |  |  |  |  |  |  | (145) |  |  |  |  | (151) |  |  |  |  |  |
| Other corporate expenses |  |  |  |  |  |  | (198) |  |  |  |  | (145) |  |  |  |  |  |
| Non-GAAP operating expenses |  |  |  |  |  |  | $ | 3,712 |  |  | 9 | % |  | $ | 3,391 |  |  |  |  |  |
| Operating income |  |  |  |  |  |  | $ | 3,656 |  |  | 214 | % |  | $ | 1,165 |  |  |  |  |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles |  |  |  |  |  |  | 97 |  |  |  |  | 126 |  |  |  |  |  |
| Stock-based compensation expense |  |  |  |  |  |  | 189 |  |  |  |  | 190 |  |  |  |  |  |
| Other corporate expenses |  |  |  |  |  |  | 293 |  |  |  |  | 185 |  |  |  |  |  |
| Non-GAAP operating income |  |  |  |  |  |  | $ | 4,235 |  |  | 154 | % |  | $ | 1,666 |  |  |  |  |  |
| Net income |  |  |  |  |  |  | $ | 3,438 |  |  | 256 | % |  | $ | 965 |  |  |  |  |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles |  |  |  |  |  |  | 97 |  |  |  |  | 126 |  |  |  |  |  |
| Stock-based compensation expense |  |  |  |  |  |  | 189 |  |  |  |  | 190 |  |  |  |  |  |
| Other corporate (income) expenses |  |  |  |  |  |  | 288 |  |  |  |  | (58) |  |  |  |  |  |
| Fair value adjustments on equity investments |  |  |  |  |  |  | (631) |  |  |  |  | (17) |  |  |  |  |  |
| Aggregate adjustment for income taxes |  |  |  |  |  |  | (191) |  |  |  |  | (120) |  |  |  |  |  |
| Non-GAAP net income |  |  |  |  |  |  | $ | 3,190 |  |  | 194 | % |  | $ | 1,086 |  |  |  |  |  |
| Earnings per share — diluted |  |  |  |  |  |  | $ | 5.24 |  |  | 282 | % |  | $ | 1.37 |  |  |  |  |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles |  |  |  |  |  |  | 0.14 |  |  |  |  | 0.18 |  |  |  |  |  |
| Stock-based compensation expense |  |  |  |  |  |  | 0.29 |  |  |  |  | 0.27 |  |  |  |  |  |
| Other corporate (income) expenses |  |  |  |  |  |  | 0.44 |  |  |  |  | (0.08) |  |  |  |  |  |
| Fair value adjustments on equity investments |  |  |  |  |  |  | (0.96) |  |  |  |  | (0.02) |  |  |  |  |  |
| Aggregate adjustment for income taxes |  |  |  |  |  |  | (0.29) |  |  |  |  | (0.17) |  |  |  |  |  |
| Non-GAAP earnings per share — diluted |  |  |  |  |  |  | $ | 4.86 |  |  | 214 | % |  | $ | 1.55 |  |  |  |  |  |

[0001571996-26-000030:mdna:58]
In addition to the above measures, we use free cash flow and adjusted free cash flow as non-GAAP liquidity measures to evaluate our performance. As presented in the following table, we define free cash flow as cash flow from operations after excluding capital expenditures and capitalized software development costs, net. To measure adjusted free cash flow, we exclude the impact of financing receivables and equipment under operating leases from free cash flow, as the initial funding of these DFS offerings at the time of origination is largely subsequently replaced with cash inflows from our DFS related debt.

[0001571996-26-000030:mdna:59]
[same as prior period, unchanged from 0001571996-25-000127:mdna:52]

[0001571996-26-000030:mdna:60]
[same as prior period, unchanged from 0001571996-25-000127:mdna:53]

[0001571996-26-000030:mdna:61]
[same as prior period, unchanged from 0001571996-25-000127:mdna:54]

[0001571996-26-000030:mdna:62]
|  |  |  | Three Months Ended |
|  |  |  |  |  |  |  | May 1, 2026 |  | % Change |  | May 2, 2025 |  |  |  |  |
|  |  |  |  |  |  |  | (in millions, except percentages) |
| Cash flow from operations |  |  |  |  |  |  | $ | 4,081 |  |  | 46 | % |  | $ | 2,796 |  |  |  |  |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Capital expenditures and capitalized software development costs, net (a) |  |  |  |  |  |  | (963) |  |  |  |  | (568) |  |  |  |  |  |
| Free cash flow |  |  |  |  |  |  | $ | 3,118 |  |  | 40 | % |  | $ | 2,228 |  |  |  |  |  |
| Free cash flow |  |  |  |  |  |  | $ | 3,118 |  |  | 40 | % |  | $ | 2,228 |  |  |  |  |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Financing receivables (b) |  |  |  |  |  |  | (263) |  |  |  |  | (23) |  |  |  |  |  |
| Equipment under operating leases (c) |  |  |  |  |  |  | 310 |  |  |  |  | 27 |  |  |  |  |  |
| Adjusted free cash flow |  |  |  |  |  |  | $ | 3,165 |  |  | 42 | % |  | $ | 2,232 |  |  |  |  |  |

[0001571996-26-000030:mdna:63]
[same as prior period, unchanged from 0001571996-25-000127:mdna:56]

[0001571996-26-000030:mdna:64]
[same as prior period, unchanged from 0001571996-25-000127:mdna:57]

[0001571996-26-000030:mdna:65]
[same as prior period, unchanged from 0001571996-25-000127:mdna:58]

[0001571996-26-000030:mdna:66]
[same as prior period, unchanged from 0001571996-25-000127:mdna:59]

[0001571996-26-000030:mdna:67]
[same as prior period, unchanged from 0001571996-25-000127:mdna:61]

[0001571996-26-000030:mdna:68]
[same as prior period, unchanged from 0001571996-25-000127:mdna:62]

[0001571996-26-000030:mdna:69]
[same as prior period, unchanged from 0001571996-25-000127:mdna:63]

[0001571996-26-000030:mdna:70]
|  |  |  | Three Months Ended |
|  |  |  |  |  |  |  | May 1, 2026 |  |  |  | May 2, 2025 |  |  |  |  |
|  |  |  |  |  |  |  |  |  |  |  | Dollars |  | % of Net Revenue |  | % Change |  | Dollars |  | % of Net Revenue |  |  |  |  |  |  |
|  |  |  |  |  |  |  |  |  |  |  | (in millions, except percentages and per share amounts) |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Products |  |  |  |  |  |  |  |  |  |  | $ | 38,105 |  |  | 86.9 | % |  | 117 | % |  | $ | 17,599 |  |  | 75.3 | % |  |  |  |  |  |  |
| Services |  |  |  |  |  |  |  |  |  |  | 5,737 |  |  | 13.1 | % |  | (1) | % |  | 5,779 |  |  | 24.7 | % |  |  |  |  |  |  |
| Total net revenue |  |  |  |  |  |  |  |  |  |  | $ | 43,842 |  |  | 100.0 | % |  | 88 | % |  | $ | 23,378 |  |  | 100.0 | % |  |  |  |  |  |  |
| Gross margin: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Products |  |  |  |  |  |  |  |  |  |  | $ | 5,253 |  |  | 13.8 | % |  | 112 | % |  | $ | 2,483 |  |  | 14.1 | % |  |  |  |  |  |  |
| Services |  |  |  |  |  |  |  |  |  |  | 2,529 |  |  | 44.1 | % |  | 3 | % |  | 2,454 |  |  | 42.5 | % |  |  |  |  |  |  |
| Total gross margin |  |  |  |  |  |  |  |  |  |  | $ | 7,782 |  |  | 17.8 | % |  | 58 | % |  | $ | 4,937 |  |  | 21.1 | % |  |  |  |  |  |  |
| Operating expenses |  |  |  |  |  |  |  |  |  |  | $ | 4,126 |  |  | 9.5 | % |  | 9 | % |  | $ | 3,772 |  |  | 16.1 | % |  |  |  |  |  |  |
| Operating income |  |  |  |  |  |  |  |  |  |  | $ | 3,656 |  |  | 8.3 | % |  | 214 | % |  | $ | 1,165 |  |  | 5.0 | % |  |  |  |  |  |  |
| Net income |  |  |  |  |  |  |  |  |  |  | $ | 3,438 |  |  | 7.8 | % |  | 256 | % |  | $ | 965 |  |  | 4.1 | % |  |  |  |  |  |  |
| Earnings per share — diluted |  |  |  |  |  |  |  |  |  |  | $ | 5.24 |  |  |  |  | 282 | % |  | $ | 1.37 |  |  |  |  |  |  |  |  |  |
| Cash flow from operations |  |  |  |  |  |  |  |  |  |  | $ | 4,081 |  |  |  |  | 46 | % |  | $ | 2,796 |  |  |  |  |  |  |  |  |  |
| Non-GAAP Financial Information |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  |  | Three Months Ended |
|  |  |  |  |  |  |  | May 1, 2026 |  |  |  | May 2, 2025 |  |  |  |  |
|  |  |  |  |  |  |  |  |  |  |  | Dollars |  | % of Net Revenue |  | % Change |  | Dollars |  | % of Net Revenue |  |  |  |  |  |  |
|  |  |  |  |  |  |  |  |  |  |  | (in millions, except percentages and per share amounts) |
| Non-GAAP gross margin: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Products |  |  |  |  |  |  |  |  |  |  | $ | 5,309 |  |  | 13.9 | % |  | 108 | % |  | $ | 2,548 |  |  | 14.5 | % |  |  |  |  |  |  |
| Services |  |  |  |  |  |  |  |  |  |  | 2,638 |  |  | 46.0 | % |  | 5 | % |  | 2,509 |  |  | 43.4 | % |  |  |  |  |  |  |
| Total non-GAAP gross margin |  |  |  |  |  |  |  |  |  |  | $ | 7,947 |  |  | 18.1 | % |  | 57 | % |  | $ | 5,057 |  |  | 21.6 | % |  |  |  |  |  |  |
| Non-GAAP operating expenses |  |  |  |  |  |  |  |  |  |  | $ | 3,712 |  |  | 8.4 | % |  | 9 | % |  | $ | 3,391 |  |  | 14.5 | % |  |  |  |  |  |  |
| Non-GAAP operating income |  |  |  |  |  |  |  |  |  |  | $ | 4,235 |  |  | 9.7 | % |  | 154 | % |  | $ | 1,666 |  |  | 7.1 | % |  |  |  |  |  |  |
| Non-GAAP net income |  |  |  |  |  |  |  |  |  |  | $ | 3,190 |  |  | 7.3 | % |  | 194 | % |  | $ | 1,086 |  |  | 4.6 | % |  |  |  |  |  |  |
| Non-GAAP earnings per share — diluted |  |  |  |  |  |  |  |  |  |  | $ | 4.86 |  |  |  |  | 214 | % |  | $ | 1.55 |  |  |  |  |  |  |  |  |  |
| Free cash flow |  |  |  |  |  |  |  |  |  |  | $ | 3,118 |  |  |  |  | 40 | % |  | $ | 2,228 |  |  |  |  |  |  |  |  |  |
| Adjusted free cash flow |  |  |  |  |  |  |  |  |  |  | $ | 3,165 |  |  |  |  | 42 | % |  | $ | 2,232 |  |  |  |  |  |  |  |  |  |

[0001571996-26-000030:mdna:71]
Non-GAAP product gross margin, non-GAAP services gross margin, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP operating income, non-GAAP net income, non-GAAP earnings per share - diluted, free cash flow, and adjusted free cash flow are not measurements of financial performance prepared in accordance with GAAP. See “Non‑GAAP Financial Measures” for additional information about these non-GAAP financial measures, including our reasons for including these measures, material limitations with respect to the usefulness of the measures, and a reconciliation of each non-GAAP financial measure to the most directly comparable GAAP financial measure.

[0001571996-26-000030:mdna:72]
[same as prior period, unchanged from 0001571996-25-000127:mdna:34]

[0001571996-26-000030:mdna:73]
[same as prior period, unchanged from 0001571996-25-000127:mdna:67]

[0001571996-26-000030:mdna:74]
During the first quarter of Fiscal 2027, net revenue increased by 88%, driven by an increase in ISG net revenue and, to a lesser extent, CSG net revenue that was partially offset by a decrease in Corporate and other net revenue. The increase in ISG net revenue was primarily driven by growth in our AI-optimized servers offerings and, to a lesser extent, our traditional servers and networking offerings and our storage offerings. The increase in CSG net revenue was primarily attributable to an increase in sales of our commercial offerings. Corporate and other net revenue declined primarily due to a decrease in VMware Resale revenue, as we no longer act as a distributor of standalone VMware offerings.

[0001571996-26-000030:mdna:75]
During the first quarter of Fiscal 2027, operating income and non-GAAP operating income increased by 214% to $3.7 billion and 154% to $4.2 billion, respectively. The increases were primarily attributable to an increase in ISG operating income and, to a lesser extent, CSG operating income. The increase in ISG operating income was driven by our servers and networking offerings and, to a lesser extent, our storage offerings. The increase in CSG operating income was driven primarily by our commercial offerings.

[0001571996-26-000030:mdna:76]
During the first quarter of Fiscal 2027, operating income and non-GAAP operating income as a percentage of net revenue increased 330 basis points to 8.3% and 260 basis points to 9.7%, respectively. Operating income as a percentage of net revenue benefited from the favorable impact of a decline in operating expense rate as a result of substantial net revenue growth. The favorable impact of operating expense rate was partially offset by a decline in gross margin rate due to a shift in mix towards our AI-optimized servers offerings.

[0001571996-26-000030:mdna:77]
Cash provided by operating activities was $4.1 billion during the first quarter of Fiscal 2027 and was driven by net revenue growth and profitability, partially offset by working capital dynamics. Working capital was primarily affected by increased demand for our AI-optimized servers offerings. During the first quarter of Fiscal 2026, cash provided by operating activities was $2.8 billion and was driven by profitability and similar working capital dynamics as well as by other business impacts, including annual incentive-based personnel-related payments. See “Liquidity, Cash Requirements, and Market Conditions” for additional information about our cash flow metrics.

[0001571996-26-000030:mdna:78]
[same as prior period, unchanged from 0001571996-25-000127:mdna:72]

[0001571996-26-000030:mdna:79]
[same as prior period, unchanged from 0001571996-25-000127:mdna:73]

[0001571996-26-000030:mdna:80]
During the first quarter of Fiscal 2027, net revenue increased 88%, driven by an increase in ISG net revenue and, to a lesser extent, CSG net revenue that was partially offset by a decrease in Corporate and other net revenue. See “Business Unit Results” for further information.

[0001571996-26-000030:mdna:81]
•Product Net Revenue — Product net revenue includes revenue from the sale of hardware products and software licenses. During the first quarter of Fiscal 2027, product net revenue increased 117% due to an increase in ISG product net revenue and, to a lesser extent, CSG product net revenue. The increase in ISG product net revenue was primarily driven by growth in our AI-optimized servers offerings and, to a lesser extent, our traditional servers and networking offerings and our storage offerings. The increase in CSG product net revenue was primarily attributable to growth in our commercial offerings.

[0001571996-26-000030:mdna:82]
•Services Net Revenue — Services net revenue includes revenue from our services offerings and support services related to hardware products and software licenses. During the first quarter of Fiscal 2027, services net revenue decreased 1% due to a decline in Corporate and other services net revenue, which was driven by a decrease in VMware Resale revenue. The decline was largely offset by an increase in ISG services net revenue, which was driven by higher AI-optimized servers offerings and support and maintenance associated with products sold in prior periods.

[0001571996-26-000030:mdna:83]
[same as prior period, unchanged from 0001571996-25-000127:mdna:77]

[0001571996-26-000030:mdna:84]
From a geographical perspective, net revenue increased in the Americas, the Europe, Middle East and Africa region (“EMEA”), and the Asia-Pacific and Japan region (“APJ”) during the first quarter of Fiscal 2027, most notably within the Americas.

[0001571996-26-000030:mdna:85]
[same as prior period, unchanged from 0001571996-25-000127:mdna:79]

[0001571996-26-000030:mdna:86]
During the first quarter of Fiscal 2027, gross margin and non-GAAP gross margin increased 58% to $7.8 billion and 57% to $7.9 billion, respectively, primarily due to an increase in ISG gross margin and, to a lesser extent, CSG gross margin. The increase in ISG gross margin was driven by growth in our servers and networking offerings and, to a lesser extent, our storage offerings. The increase in CSG gross margin was primarily driven by growth in our commercial offerings.

[0001571996-26-000030:mdna:87]
During the first quarter of Fiscal 2027, gross margin percentage and non-GAAP gross margin percentage decreased 330 basis points to 17.8% and 350 basis points to 18.1%, respectively. The decreases were primarily driven by a shift in mix towards our AI-optimized servers offerings.

[0001571996-26-000030:mdna:88]
•Product Gross Margin — During the first quarter of Fiscal 2027, product gross margin and non-GAAP product gross margin increased 112% and 108%, respectively, to $5.3 billion. The increases were attributable to an increase in ISG product gross margin and, to a lesser extent, CSG product gross margin. The increase in ISG product gross margin was driven by growth in our servers and networking offerings and, to a lesser extent, our storage offerings. The increase in CSG gross margin was primarily attributable to growth in our commercial offerings.

[0001571996-26-000030:mdna:89]
During the first quarter of Fiscal 2027, product gross margin percentage and non-GAAP product gross margin percentage decreased 30 basis points to 13.8% and 60 basis points to 13.9%, respectively, primarily due to a shift in mix towards our AI-optimized servers offerings.

[0001571996-26-000030:mdna:90]
•Services Gross Margin — During the first quarter of Fiscal 2027, services gross margin and non-GAAP services gross margin increased 3% to $2.5 billion and 5% to $2.6 billion, respectively. The increases were attributable to an increase in ISG services gross margin, which was primarily driven by higher support and maintenance associated with products sold in prior periods and increased demand for our servers and networking offerings.

[0001571996-26-000030:mdna:91]
During the first quarter of Fiscal 2027, services gross margin percentage and non-GAAP services gross margin percentage increased 160 basis points to 44.1% and 260 basis points to 46.0%, respectively, primarily driven by a shift in mix, as we no longer act as a distributor of standalone VMware offerings.

[0001571996-26-000030:mdna:92]
[same as prior period, unchanged from 0001571996-25-000127:mdna:86]

[0001571996-26-000030:mdna:93]
[same as prior period, unchanged from 0001571996-25-000127:mdna:87]

[0001571996-26-000030:mdna:94]
The terms and conditions of our vendor rebate programs are largely based on product volumes and are generally negotiated either at the beginning of the annual or quarterly period, depending on the program. The timing and amount of vendor rebates and other discounts we receive under the programs may vary from period to period, reflecting changes in the competitive environment. We monitor our component costs and seek to address the effects of any changes to terms that might arise under our vendor rebate programs. Our gross margins for the first quarter of Fiscal 2027 were not materially affected by any changes to the terms of our vendor rebate programs, as the amounts we received under these programs were generally stable relative to our total net cost. We are not aware of any significant changes to our vendor rebate programs that will materially impact our results in the near term.

[0001571996-26-000030:mdna:95]
[same as prior period, unchanged from 0001571996-25-000127:mdna:46]

[0001571996-26-000030:mdna:96]
[same as prior period, unchanged from 0001571996-25-000127:mdna:89]

[0001571996-26-000030:mdna:97]
[same as prior period, unchanged from 0001571996-25-000127:mdna:90]

[0001571996-26-000030:mdna:98]
|  |  |  | Three Months Ended |
|  |  |  |  |  |  |  | May 1, 2026 |  |  |  | May 2, 2025 |  |  |  |  |
|  |  |  |  |  |  |  |  |  |  |  | Dollars |  | % of Net Revenue |  | % Change |  | Dollars |  | % of Net Revenue |  |  |  |  |  |  |
|  |  |  |  |  |  |  |  |  |  |  | (in millions, except percentages) |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling, general, and administrative |  |  |  |  |  |  |  |  |  |  | $ | 3,143 |  |  | 7.3 | % |  | 6 | % |  | $ | 2,964 |  |  | 12.6 | % |  |  |  |  |  |  |
| Research and development |  |  |  |  |  |  |  |  |  |  | 983 |  |  | 2.2 | % |  | 22 | % |  | 808 |  |  | 3.5 | % |  |  |  |  |  |  |
| Total operating expenses |  |  |  |  |  |  |  |  |  |  | $ | 4,126 |  |  | 9.5 | % |  | 9 | % |  | $ | 3,772 |  |  | 16.1 | % |  |  |  |  |  |  |
|  |  |  | Three Months Ended |
|  |  |  |  |  |  |  | May 1, 2026 |  |  |  | May 2, 2025 |  |  |  |  |
|  |  |  |  |  |  |  |  |  |  |  | Dollars |  | % of Net Revenue |  | % Change |  | Dollars |  | % of Net Revenue |  |  |  |  |  |  |
|  |  |  |  |  |  |  |  |  |  |  | (in millions, except percentages) |
| Non-GAAP operating expenses |  |  |  |  |  |  |  |  |  |  | $ | 3,712 |  |  | 8.4 | % |  | 9 | % |  | $ | 3,391 |  |  | 14.5 | % |  |  |  |  |  |  |

[0001571996-26-000030:mdna:99]
During the first quarter of Fiscal 2027, total operating expenses increased 9% due to an increase in research and development (“R&D”) expenses and selling, general, and administrative (“SG&A”) expenses.

[0001571996-26-000030:mdna:100]
•Selling, General, and Administrative — During the first quarter of Fiscal 2027, SG&A expenses increased 6%, principally due to an increase in employee compensation and benefits expense related primarily to an increase in variable compensation.

[0001571996-26-000030:mdna:101]
•Research and Development — R&D expenses increased 22% during the first quarter of Fiscal 2027, principally due to an increase in employee compensation and benefits expense related primarily to an increase in variable compensation.

[0001571996-26-000030:mdna:102]
As a percentage of net revenue, R&D expenses for the first quarter of Fiscal 2027 and Fiscal 2026 were 2.2% and 3.5%, respectively. The decline in R&D expense as a percentage of revenue was driven by an increase in net revenue. We continue to support R&D initiatives to innovate and introduce new and enhanced solutions into the market.

[0001571996-26-000030:mdna:103]
During the first quarter of Fiscal 2027, non-GAAP operating expenses increased 9%, principally due to an increase in employee compensation and benefits expense related primarily to an increase in variable compensation.

[0001571996-26-000030:mdna:104]
[same as prior period, unchanged from 0001571996-25-000127:mdna:97]

[0001571996-26-000030:mdna:105]
[same as prior period, unchanged from 0001571996-25-000127:mdna:98]

[0001571996-26-000030:mdna:106]
During the first quarter of Fiscal 2027, operating income and non-GAAP operating income increased by 214% to $3.7 billion and 154% to $4.2 billion, respectively. The increases were primarily attributable to an increase in ISG operating income and, to a lesser extent, CSG operating income. The increase in ISG operating income was driven by our servers and networking offerings and, to a lesser extent, our storage offerings. The increase in CSG operating income was driven primarily by our commercial offerings.

[0001571996-26-000030:mdna:107]
During the first quarter of Fiscal 2027, operating income and non-GAAP operating income as a percentage of net revenue increased 330 basis points to 8.3% and 260 basis points to 9.7%, respectively. Operating income as a percentage of net revenue benefited from the favorable impact of a decline in operating expense rate as a result of substantial net revenue growth. The favorable impact of operating expense rate was partially offset by a decline in gross margin rate due to a shift in mix towards our AI-optimized servers offerings.

[0001571996-26-000030:mdna:108]
58

[0001571996-26-000030:mdna:109]
[same as prior period, unchanged from 0001571996-25-000127:mdna:101]

[0001571996-26-000030:mdna:110]
[same as prior period, unchanged from 0001571996-25-000127:mdna:102]

[0001571996-26-000030:mdna:111]
|  |  |  | Three Months Ended |
|  |  |  |  |  | May 1, 2026 |  | May 2, 2025 |  |  |
|  |  |  |  |  | (in millions) |
| Investment income, primarily interest |  |  |  |  | $ | 81 |  |  | $ | 31 |  |  |  |
| Gain on investments, net |  |  |  |  | 631 |  |  | 17 |  |  |  |
| Interest expense |  |  |  |  | (391) |  |  | (354) |  |  |  |
| Foreign exchange |  |  |  |  | (17) |  |  | (5) |  |  |  |
| Gain on disposition of businesses and assets |  |  |  |  | — |  |  | 236 |  |  |  |
| Other |  |  |  |  | (12) |  |  | (7) |  |  |  |
| Total interest and other, net |  |  |  |  | $ | 292 |  |  | $ | (82) |  |  |  |

[0001571996-26-000030:mdna:112]
During the first quarter of Fiscal 2027, the change in interest and other, net was favorable primarily due to gains recognized within our strategic investments portfolio, partially offset by the gain on the sale of Secureworks recognized during the first quarter of Fiscal 2026.

[0001571996-26-000030:mdna:113]
[same as prior period, unchanged from 0001571996-25-000127:mdna:106]

[0001571996-26-000030:mdna:114]
[same as prior period, unchanged from 0001571996-25-000127:mdna:107]

[0001571996-26-000030:mdna:115]
|  |  |  | Three Months Ended |
|  |  |  |  |  | May 1, 2026 |  | May 2, 2025 |  |  |
|  |  |  |  |  | (in millions, except percentages) |
| Income before income taxes |  |  |  |  | $ | 3,948 |  |  | $ | 1,083 |  |  |  |
| Income tax expense |  |  |  |  | $ | 510 |  |  | $ | 118 |  |  |  |
| Effective income tax rate |  |  |  |  | 12.9 | % |  | 10.9 | % |  |  |

[0001571996-26-000030:mdna:116]
For the first quarter of Fiscal 2027 and Fiscal 2026, our effective income tax rates were 12.9% and 10.9%, respectively. The changes in our effective income tax rates for Fiscal 2027 as compared to Fiscal 2026 were primarily attributable to discrete tax items. For the first quarter of Fiscal 2027 and Fiscal 2026, we recorded discrete tax benefits of $0.2 billion and $0.1 billion, respectively, related to stock-based compensation.

[0001571996-26-000030:mdna:117]
See Note 11 of the Notes to the Condensed Consolidated Financial Statements included in this report for additional information about our income and other taxes.

[0001571996-26-000030:mdna:118]
[same as prior period, unchanged from 0001571996-25-000127:mdna:114]

[0001571996-26-000030:mdna:119]
During the first quarter of Fiscal 2027, net income increased 256% to $3.4 billion primarily due to an increase in operating income and, to a lesser extent, a favorable change in interest and other, net, the effects of which were partially offset by higher income tax expense.

[0001571996-26-000030:mdna:120]
During the first quarter of Fiscal 2027, non-GAAP net income increased 194% to $3.2 billion, primarily due to an increase in operating income, partially offset by higher income tax expense.

[0001571996-26-000030:mdna:121]
[same as prior period, unchanged from 0001571996-25-000127:mdna:118]

[0001571996-26-000030:mdna:122]
[same as prior period, unchanged from 0001571996-25-000127:mdna:119]

[0001571996-26-000030:mdna:123]
[same as prior period, unchanged from 0001571996-25-000127:mdna:120]

[0001571996-26-000030:mdna:124]
[same as prior period, unchanged from 0001571996-25-000127:mdna:121]

[0001571996-26-000030:mdna:125]
|  |  |  | Three Months Ended |
|  |  |  |  |  |  |  | May 1, 2026 |  | % Change |  | May 2, 2025 |  |  |  |  |
|  |  |  |  |  |  |  | (in millions, except percentages) |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| AI-optimized servers |  |  |  |  |  |  | $ | 16,132 |  | 757 | % |  | $ | 1,882 |  |  |  |  |
| Traditional servers and networking |  |  |  |  |  |  | 8,543 |  | 92 | % |  | 4,439 |  |  |  |  |
| Servers and networking |  |  |  |  |  |  | 24,675 |  | 290 | % |  | 6,321 |  |  |  |  |
| Storage |  |  |  |  |  |  | 4,334 |  | 8 | % |  | 3,996 |  |  |  |  |
| Total ISG net revenue |  |  |  |  |  |  | $ | 29,009 |  | 181 | % |  | $ | 10,317 |  |  |  |  |
| Operating income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| ISG operating income |  |  |  |  |  |  | $ | 3,055 |  | 206 | % |  | $ | 998 |  |  |  |  |
| % of segment net revenue |  |  |  |  |  |  | 10.5 | % |  |  |  | 9.7 | % |  |  |  |  |

[0001571996-26-000030:mdna:126]
Net Revenue — During the first quarter of Fiscal 2027, ISG net revenue increased 181%, driven by strength in our AI-optimized servers offerings and, to a lesser extent, our traditional servers and networking offerings and our storage offerings.

[0001571996-26-000030:mdna:127]
AI-optimized servers net revenue increased 757% during the first quarter of Fiscal 2027, primarily driven by an increase in units sold as a result of significant increased demand for these offerings.

[0001571996-26-000030:mdna:128]
In addition to unit demand growth that exceeded supply, traditional servers and networking net revenue increased 92% during the first quarter of Fiscal 2027, primarily due to an increase in the average selling price of these offerings, driven by disciplined pricing as we navigated the macroeconomic environment and, to a lesser extent, richer configurations.

[0001571996-26-000030:mdna:129]
During the first quarter of Fiscal 2027, storage net revenue increased 8% primarily due to growth in demand for our Dell-IP storage offerings.

[0001571996-26-000030:mdna:130]
From a geographical perspective, ISG net revenue increased in the Americas, EMEA, and APJ during the first quarter of Fiscal 2027, most notably within the Americas.

[0001571996-26-000030:mdna:131]
Operating Income — During the first quarter of Fiscal 2027, ISG operating income as a percentage of net revenue increased 80 basis points to 10.5%, due to a decline in operating expense rate that outpaced the decline in gross margin rate. Operating expense rate declined primarily due to substantial ISG net revenue growth. Gross margin rate decreased primarily as the result of a shift in mix towards our AI-optimized servers offerings.

[0001571996-26-000030:mdna:132]
[same as prior period, unchanged from 0001571996-25-000127:mdna:129]

[0001571996-26-000030:mdna:133]
[same as prior period, unchanged from 0001571996-25-000127:mdna:130]

[0001571996-26-000030:mdna:134]
|  |  |  | Three Months Ended |
|  |  |  |  |  |  |  | May 1, 2026 |  | % Change |  | May 2, 2025 |  |  |  |  |
|  |  |  |  |  |  |  | (in millions, except percentages) |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Commercial |  |  |  |  |  |  | $ | 13,020 |  | 18 | % |  | $ | 11,046 |  |  |  |  |
| Consumer |  |  |  |  |  |  | 1,589 |  | 9 | % |  | 1,463 |  |  |  |  |
| Total CSG net revenue |  |  |  |  |  |  | $ | 14,609 |  | 17 | % |  | $ | 12,509 |  |  |  |  |
| Operating income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| CSG operating income |  |  |  |  |  |  | $ | 1,170 |  | 79 | % |  | $ | 653 |  |  |  |  |
| % of segment net revenue |  |  |  |  |  |  | 8.0 | % |  |  |  | 5.2 | % |  |  |  |  |

[0001571996-26-000030:mdna:135]
Net Revenue — During the first quarter of Fiscal 2027, CSG net revenue increased 17%, primarily driven by strength in our commercial offerings and, to a lesser extent, our consumer offerings.

[0001571996-26-000030:mdna:136]
During the first quarter of Fiscal 2027, commercial net revenue increased 18% primarily due to an increase in the average selling prices of our commercial offerings and an increase in units sold.

[0001571996-26-000030:mdna:137]
Consumer net revenue increased 9% during the first quarter of Fiscal 2027 due to an increase in the average selling prices of our consumer offerings, partially offset by a decline in units sold.

[0001571996-26-000030:mdna:138]
The increase in the average selling prices of our CSG offerings was primarily attributable to disciplined pricing as we navigated the macroeconomic environment.

[0001571996-26-000030:mdna:139]
From a geographical perspective, CSG net revenue increased in EMEA, APJ, and the Americas during the first quarter of Fiscal 2027, most notably in EMEA.

[0001571996-26-000030:mdna:140]
Operating Income — During the first quarter of Fiscal 2027, CSG operating income as a percentage of net revenue increased 280 basis points to 8.0%. The increase in operating income rate during the first quarter of Fiscal 2027 was due to an increase in gross margin rate primarily driven by disciplined pricing as we navigated the macroeconomic environment and, to a lesser extent, a decline in operating expense rate driven by CSG net revenue growth.

[0001571996-26-000030:mdna:141]
[same as prior period, unchanged from 0001571996-25-000127:mdna:137]

[0001571996-26-000030:mdna:142]
[same as prior period, unchanged from 0001571996-25-000127:mdna:138]

[0001571996-26-000030:mdna:143]
We sell products and services directly to customers and through a variety of sales channels, including retail distribution. Our accounts receivable, net was $25.9 billion and $17.6 billion as of May 1, 2026 and January 30, 2026, respectively. The increase in accounts receivable, net was primarily driven by an increase in net revenue largely due to our AI-optimized servers offerings. We maintain an allowance for expected credit losses to cover receivables that may be deemed uncollectible. The allowance for expected credit losses is an estimate based on an analysis of historical loss experience, current receivables aging, and management’s assessment of current conditions, as well as specific identifiable customer accounts considered at risk or uncollectible. As of both May 1, 2026 and January 30, 2026, the allowance for expected credit losses was $77 million. Based on our assessment, we believe that we are adequately reserved for expected credit losses.

[0001571996-26-000030:mdna:144]
[same as prior period, unchanged from 0001571996-25-000127:mdna:140]

[0001571996-26-000030:mdna:145]
We offer or arrange a portfolio of payment and consumption solutions and services for our customers globally, including as-a-Service, subscription, utility, leases, and loans, designed to match customers' consumption and financing preferences. We believe these options provide operational and financial flexibility and strengthen our customer relationships. To support financing solutions and services as part of the portfolio, DFS originates, collects, and services customer receivables primarily related to the purchase of our product and services solutions. New financing originations were $2.8 billion and $1.6 billion for the first quarter of Fiscal 2027 and Fiscal 2026, respectively.

[0001571996-26-000030:mdna:146]
[same as prior period, unchanged from 0001571996-25-000127:mdna:142]

[0001571996-26-000030:mdna:147]
As of May 1, 2026 and January 30, 2026, our financing receivables, net were $14.0 billion and $14.3 billion, respectively. We maintain an allowance to cover expected financing receivables credit losses and evaluate credit loss expectations based on our total portfolio. The principal charge-off rate for our financing receivables portfolio was 0.3% for both the first quarter of Fiscal 2027 and Fiscal 2026. The credit quality of our financing receivables remains strong due to the mix of high-quality commercial accounts in our portfolio. We continue to monitor broader economic indicators and their potential impact on future credit loss performance. We have an extensive process to manage our exposure to customer credit risk that includes active management of credit lines and collection activities. We also sell select fixed-term financing receivables without recourse to unrelated third parties on a periodic basis, primarily to manage certain concentrations of customer credit exposure. Based on our assessment of the customer financing receivables, we believe that we are adequately reserved.

[0001571996-26-000030:mdna:148]
We retain a residual interest in equipment leased under our lease programs. As of May 1, 2026 and January 30, 2026, the residual interest recorded as part of financing receivables was $196 million and $198 million, respectively. The amount of the residual interest is established at the inception of the lease based upon estimates of the value of the equipment at the end of the lease term using historical studies, industry data, and future value-at-risk demand valuation methods. On a quarterly basis, we assess the carrying amount of our recorded residual values for expected losses. Generally, expected losses as a result of residual value risk on equipment under lease are not considered to be significant primarily because of the existence of a secondary market with respect to the equipment. Further, the lease agreement defines applicable return conditions and remedies for non-compliance to ensure that the leased equipment will be in good operating condition upon return. No expected losses were recorded related to residual assets during the first quarter of Fiscal 2027 and Fiscal 2026.

[0001571996-26-000030:mdna:149]
As of May 1, 2026 and January 30, 2026, equipment under operating leases, net was $2.7 billion and $2.5 billion, respectively. We assess the carrying amount of the equipment under operating leases for impairment whenever events or circumstances may indicate that an impairment has occurred. No material impairment losses were recorded related to such equipment during the first quarter of Fiscal 2027 and Fiscal 2026.

[0001571996-26-000030:mdna:150]
[same as prior period, unchanged from 0001571996-25-000127:mdna:147]

[0001571996-26-000030:mdna:151]
[same as prior period, unchanged from 0001571996-25-000127:mdna:149]

[0001571996-26-000030:mdna:152]
[same as prior period, unchanged from 0001571996-25-000127:mdna:150]

[0001571996-26-000030:mdna:153]
[same as prior period, unchanged from 0001571996-25-000127:mdna:151]

[0001571996-26-000030:mdna:154]
[same as prior period, unchanged from 0001571996-25-000127:mdna:152]

[0001571996-26-000030:mdna:155]
We believe that our current cash and cash equivalents, together with cash that will be provided by future operations and borrowings and issuances expected to be available under our revolving credit facility and commercial paper program, will be sufficient over the next twelve months and for the foreseeable future thereafter to meet our material cash requirements, including funding of our operations, debt-related payments, capital expenditures, and other corporate needs.

[0001571996-26-000030:mdna:156]
[same as prior period, unchanged from 0001571996-25-000127:mdna:154]

[0001571996-26-000030:mdna:157]
[same as prior period, unchanged from 0001571996-25-000127:mdna:155]

[0001571996-26-000030:mdna:158]
|  | May 1, 2026 |  | January 30, 2026 |
|  | (in millions) |
| Cash and cash equivalents, and available borrowings: |  |  |  |
| Cash and cash equivalents | $ | 11,578 |  |  | $ | 11,528 |  |
| Remaining available borrowings under the revolving credit facility | 5,884 |  |  | 5,886 |  |
| Total cash and cash equivalents, and available borrowings | $ | 17,462 |  |  | $ | 17,414 |  |

[0001571996-26-000030:mdna:159]
During the first quarter of Fiscal 2027, cash and cash equivalents increased by $0.1 billion primarily due to cash flows from operating activities, the effects of which were largely offset by the return of capital to our stockholders, capital expenditures, payments to settle employee tax withholdings on stock-based compensation, and our net debt repayments.

[0001571996-26-000030:mdna:160]
As of May 1, 2026, our revolving credit facility had a maximum capacity of $6.0 billion. Available borrowings under this facility are reduced by draws on the facility and outstanding letters of credit. As of May 1, 2026, there were no borrowings outstanding under the facility and remaining available borrowings totaled approximately $5.9 billion. The facility also acts as a backstop to provide liquidity support for our commercial paper program.

[0001571996-26-000030:mdna:161]
We maintain a commercial paper program under which we may issue unsecured notes in a maximum aggregate face amount of $5.0 billion outstanding at any time, with maturities of up to 397 days from the date of issue. As of May 1, 2026, we had no outstanding issuances under the program.

[0001571996-26-000030:mdna:162]
We may regularly use our available borrowings from the revolving credit facility and issuances under the commercial paper program, generally on a short-term basis, for general corporate purposes. See the following discussion for additional information about our debt.

[0001571996-26-000030:mdna:163]
[same as prior period, unchanged from 0001571996-25-000127:mdna:162]

[0001571996-26-000030:mdna:164]
[same as prior period, unchanged from 0001571996-25-000127:mdna:163]

[0001571996-26-000030:mdna:165]
|  | May 1, 2026 |  | Change |  | January 30, 2026 |
|  | (in millions) |
| Core debt: |  |  |  |  |  |
| Senior Notes | $ | 21,073 |  |  | $ | (500) |  |  | $ | 21,573 |  |
| Legacy Notes | 952 |  |  | — |  |  | 952 |  |
| DFS allocated debt | (5,318) |  |  | 189 |  |  | (5,507) |  |
| Total core debt | 16,707 |  |  | (311) |  |  | 17,018 |  |
| DFS related debt: |  |  |  |  |  |
| DFS debt | 9,278 |  |  | 139 |  |  | 9,139 |  |
| DFS allocated debt | 5,318 |  |  | (189) |  |  | 5,507 |  |
| Total DFS related debt | 14,596 |  |  | (50) |  |  | 14,646 |  |
| Other: | 110 |  |  | 11 |  |  | 99 |  |
| Total debt, principal amount | 31,413 |  |  | (350) |  |  | 31,763 |  |
| Carrying value adjustments | (252) |  |  | 8 |  |  | (260) |  |
| Total debt, carrying value | $ | 31,161 |  |  | $ | (342) |  |  | $ | 31,503 |  |

[0001571996-26-000030:mdna:166]
During the first quarter of Fiscal 2027, the outstanding principal amount of our total debt decreased $0.4 billion to $31.4 billion, driven primarily by net repayments of our Senior Notes.

[0001571996-26-000030:mdna:167]
We define core debt as the total principal amount of our debt, less DFS related debt and other debt. Our core debt was $16.7 billion and $17.0 billion as of May 1, 2026 and January 30, 2026, respectively. See Note 6 of the Notes to the Condensed Consolidated Financial Statements included in this report for additional information about our debt.

[0001571996-26-000030:mdna:168]
[same as prior period, unchanged from 0001571996-25-000127:mdna:167]

[0001571996-26-000030:mdna:169]
[same as prior period, unchanged from 0001571996-25-000127:mdna:168]

[0001571996-26-000030:mdna:170]
[same as prior period, unchanged from 0001571996-25-000127:mdna:169]

[0001571996-26-000030:mdna:171]
|  | May 1, 2026 |  | January 30, 2026 |
|  | (in millions) |
| Financing receivables, net | $ | 13,950 |  |  | $ | 14,280 |  |
| Equipment under operating leases, net | 2,731 |  |  | 2,459 |  |
| DFS owned assets | $ | 16,681 |  |  | $ | 16,739 |  |

[0001571996-26-000030:mdna:172]
We believe we will continue to be able to make our debt principal and interest payments, including payment of short-term maturities, from existing and expected sources of cash. Cash used for debt principal and interest payments may include operating cash flows, short-term borrowings under our commercial paper program or our revolving credit facility, or other borrowings. Under our variable-rate debt, we could experience variations in our future interest expense from potential fluctuations in applicable reference rates, or from possible fluctuations in the level of DFS debt required to meet future demand for customer financing.

[0001571996-26-000030:mdna:173]
[same as prior period, unchanged from 0001571996-25-000127:mdna:173]

[0001571996-26-000030:mdna:174]
[same as prior period, unchanged from 0001571996-25-000127:mdna:174]

[0001571996-26-000030:mdna:175]
[same as prior period, unchanged from 0001571996-25-000127:mdna:175]

[0001571996-26-000030:mdna:176]
|  | Three Months Ended |
|  | May 1, 2026 |  | May 2, 2025 |  |  |
|  | (in millions) |
| Net change in cash from: |  |  |  |  |  |
| Operating activities | $ | 4,081 |  |  | $ | 2,796 |  |  |  |
| Investing activities | (1,067) |  |  | (88) |  |  |  |
| Financing activities | (2,954) |  |  | 1,237 |  |  |  |
| Effect of exchange rate changes on cash, cash equivalents, and restricted cash | (13) |  |  | 89 |  |  |  |
| Change in cash, cash equivalents, and restricted cash | $ | 47 |  |  | $ | 4,034 |  |  |  |

[0001571996-26-000030:mdna:177]
Operating Activities — Cash provided by operating activities was $4.1 billion during the first quarter of Fiscal 2027 and was driven by net revenue growth and profitability, partially offset by working capital dynamics. Working capital was primarily affected by increased demand for our AI-optimized servers offerings. During the first quarter of Fiscal 2026, cash provided by operating activities was $2.8 billion and was driven by profitability and similar working capital dynamics as well as by other business impacts, including annual incentive-based personnel-related payments.

[0001571996-26-000030:mdna:178]
Investing Activities — Investing activities primarily consist of cash used to fund capital expenditures for property, plant, and equipment inclusive of equipment under operating leases and equipment used to support our as-a-Service offerings, which we refer to collectively as assets in a customer contract. Additional activities may include capitalized software development costs, the maturities, sales, and purchases of investments, and acquisitions and divestitures. Cash used in investing activities was $1.1 billion during the first quarter of Fiscal 2027 and primarily consisted of cash used for capital expenditures. Cash used in investing activities was $0.1 billion during the first quarter of Fiscal 2026 and consisted of cash used for capital expenditures, largely offset by cash proceeds from the sale of Secureworks.

[0001571996-26-000030:mdna:179]
Financing Activities — Financing activities primarily consist of the proceeds and repayments of debt and return of capital to our stockholders. Cash used in financing activities was $3.0 billion during the first quarter of Fiscal 2027 and primarily consisted of repurchases of common stock, inclusive of payments to settle employee tax withholdings on stock-based compensation, the payment of quarterly dividends, and our net debt repayments. Cash provided by financing activities was $1.2 billion during the first quarter of Fiscal 2026 and primarily consisted of net proceeds from the issuance of Senior Notes and DFS debt, partially offset by repurchases of common stock, inclusive of payments to settle employee tax withholdings on stock-based compensation, and the payment of quarterly dividends.

[0001571996-26-000030:mdna:180]
DFS Cash Flow Impacts — DFS offerings are initially funded through cash on hand at the time of origination, some of which is subsequently replaced with financing. For offerings that qualify as sales-type leases, the initial funding of financing receivables is reflected as an impact to cash flows from operations. For offerings that qualify as operating leases, the initial funding is classified as a capital expenditure and reflected as cash flows used in investing activities. DFS new financing originations were $2.8 billion during the first quarter of Fiscal 2027 and $1.6 billion during the first quarter of Fiscal 2026. As of May 1, 2026, we had $14.0 billion of total net financing receivables and $2.7 billion of equipment under operating leases, net.

[0001571996-26-000030:mdna:181]
[same as prior period, unchanged from 0001571996-25-000127:mdna:181]

[0001571996-26-000030:mdna:182]
[same as prior period, unchanged from 0001571996-25-000127:mdna:182]

[0001571996-26-000030:mdna:183]
Capital Expenditures — We spent $1.0 billion and $0.6 billion during the first quarter of Fiscal 2027 and Fiscal 2026, respectively, on property, plant, and equipment and capitalized software development costs. Of total expenditures incurred, funding of assets in a customer contract totaled $0.7 billion and $0.3 billion during the first quarter of Fiscal 2027 and Fiscal 2026, respectively. Product demand, product mix, the use of contract manufacturers, and ongoing investments in operating and information technology infrastructure influence the level and prioritization of our capital expenditures.

[0001571996-26-000030:mdna:184]
Repurchases of Common Stock — On September 23, 2021, our Board of Directors approved a stock repurchase program with no fixed expiration date under which we were authorized to repurchase a specified dollar value of Class C Common Stock, exclusive of any fees, commissions, or other expenses related to such repurchases. As of January 30, 2026, our Board of Directors authorized the repurchase of up to $20 billion of Class C Common Stock and on February 26, 2026 authorized an additional $10 billion of Class C Common Stock for repurchase. Following the February 26, 2026 approval, we had approximately $15.2 billion of authorized shares remaining under the program.

[0001571996-26-000030:mdna:185]
During the first quarter of Fiscal 2027, we repurchased approximately 11 million shares of Class C Common Stock for a total purchase price of approximately $1.6 billion. During the first quarter of Fiscal 2026, we repurchased approximately 22 million shares of Class C Common Stock for a total purchase price of approximately $2.0 billion.

[0001571996-26-000030:mdna:186]
Dividend Payments — During the first quarter of Fiscal 2027 and Fiscal 2026, we paid $0.5 billion and $0.4 billion in dividends and dividend equivalents, respectively, at a rate of $0.630 and $0.525 per share per fiscal quarter, respectively.

[0001571996-26-000030:mdna:187]
Purchase Obligations — Purchase obligations are contractual obligations that are enforceable and legally binding on us to purchase goods or services and that specify all significant terms, including fixed or minimum quantities to be purchased; fixed, minimum, or variable price provisions; and the approximate timing of the transaction. Purchase obligations include the non-cancelable portion or the minimum cancellation fee under the contract, and they are primarily related to commitments with suppliers, software maintenance, and support services.

[0001571996-26-000030:mdna:188]
Purchase obligations exclude contracts that may be canceled without penalty, open purchase orders that are entered into during the ordinary course of business, and certain portions of strategic supplier agreements. Open purchase orders typically represent flexible and mutually beneficial purchase arrangements with our suppliers which authorize us to make purchases based on our projected demand and manufacturing needs rather than through binding purchase obligations. Strategic supplier agreements are typically long-term in nature with fixed or minimum quantities to be purchased from our suppliers throughout the term of the contract in order to minimize inventory risk, particularly in a dynamic commodity supply environment. The portions of strategic supplier agreements for which certain commodities will be purchased at a price to be mutually agreed upon after the balance sheet date cannot be reasonably estimated and therefore are excluded from purchase obligations.

[0001571996-26-000030:mdna:189]
To meet growing demand, we have increased our purchases of certain components with suppliers, resulting in increased purchase obligations. We expect our purchases of those components will continue to increase, including committed purchases under long-term strategic supplier agreements at prices to be mutually agreed upon at a future date.

[0001571996-26-000030:mdna:190]
As of May 1, 2026, we had purchase obligations of $20.8 billion, of which $17.3 billion is payable within twelve months.

[0001571996-26-000030:mdna:191]
[same as prior period, unchanged from 0001571996-25-000127:mdna:190]

[0001571996-26-000030:mdna:192]
[same as prior period, unchanged from 0001571996-25-000127:mdna:191]

[0001571996-26-000030:mdna:193]
We monitor credit risk associated with our financial counterparties using various market credit risk indicators such as credit ratings issued by nationally recognized credit rating agencies and changes in market credit default swap levels. To date, the majority of revenue from our AI‑optimized solutions has involved purchases by a relatively small number of large customers and cloud service providers. Such purchases generally involve larger amounts of credit, and could impact our overall credit risk in trade and financing receivables. We perform periodic evaluations of our positions with counterparties and may limit exposure to any one counterparty in accordance with our policies. We monitor and manage our positions based on current and expected market developments.

[0001571996-26-000030:mdna:194]
[same as prior period, unchanged from 0001571996-25-000127:mdna:193]

[0001571996-26-000030:mdna:195]
We are exposed to interest rate risk related to our variable-rate debt portfolio. In the normal course of business we follow established policies and procedures to manage this risk, including monitoring of our asset and liability mix and the use of derivative instruments. As a result, we do not anticipate any material losses from interest rate risk.

[0001571996-26-000030:mdna:196]
[same as prior period, unchanged from 0001571996-25-000127:mdna:117]

[0001571996-26-000030:mdna:197]
[same as prior period, unchanged from 0001571996-25-000127:mdna:196]

[0001571996-26-000030:mdna:198]
[same as prior period, unchanged from 0001571996-25-000127:mdna:197]

[0001571996-26-000030:mdna:199]
[same as prior period, unchanged from 0001571996-25-000127:mdna:198]

[0001571996-26-000030:mdna:200]
[same as prior period, unchanged from 0001571996-25-000127:mdna:199]

[0001571996-26-000030:mdna:201]
|  | Three Months Ended |
|  | May 1, 2026 |
|  | (in millions) |
| Net revenue | $ | 1,778 |  |
| Gross margin | 925 |  |
| Operating income | 85 |  |
| Interest and other, net | (942) |  |
| Loss before income taxes | $ | (857) |  |
| Net loss attributable to Obligor Group (a) | $ | (594) |  |

[0001571996-26-000030:mdna:202]
[same as prior period, unchanged from 0001571996-25-000127:mdna:201]

[0001571996-26-000030:mdna:203]
(a)Includes net loss from intercompany transactions with Non-Obligor Subsidiaries of $1.0 billion, which primarily consists of interest expense, shared services, and the resale of solutions.

[0001571996-26-000030:mdna:204]
[same as prior period, unchanged from 0001571996-25-000127:mdna:203]

[0001571996-26-000030:mdna:205]
|  | May 1, 2026 |  | January 30, 2026 |
|  | (in millions) |
| ASSETS |
| Current assets | $ | 2,623 |  |  | $ | 2,470 |  |
| Intercompany receivables | — |  |  | 317 |  |
| Short-term intercompany loan receivables | 494 |  |  | 306 |  |
| Total current assets | 3,117 |  |  | 3,093 |  |
| Goodwill and intangible assets | 13,733 |  |  | 13,788 |  |
| Other non-current assets | 3,428 |  |  | 3,319 |  |
| Total assets | $ | 20,278 |  |  | $ | 20,200 |  |
| LIABILITIES |
| Current liabilities | $ | 5,321 |  |  | $ | 6,037 |  |
| Intercompany payable | 460 |  |  | — |  |
| Total current liabilities | 5,781 |  |  | 6,037 |  |
| Long-term debt | 20,043 |  |  | 20,035 |  |
| Long-term intercompany loan payables | 44,826 |  |  | 44,825 |  |
| Other non-current liabilities | 3,120 |  |  | 3,293 |  |
| Total liabilities | $ | 73,770 |  |  | $ | 74,190 |  |
