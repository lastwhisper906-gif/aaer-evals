# DELL notes — 0001571996-26-000030


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0001571996-26-000030:notes:1]
Basis of Presentation — The accompanying unaudited Condensed Consolidated Financial Statements should be read in conjunction with the audited Consolidated Financial Statements and accompanying Notes filed with the U.S. Securities and Exchange Commission (“SEC”) in the Company’s Annual Report on Form 10-K for the fiscal year ended January 30, 2026. These Condensed Consolidated Financial Statements have been prepared in accordance with accounting principles generally accepted in the United States of America (“GAAP”). In the opinion of management, the accompanying Condensed Consolidated Financial Statements reflect all adjustments of a normal recurring nature considered necessary to fairly state the financial position of the Company as of May 1, 2026 and January 30, 2026 and the results of its operations, corresponding comprehensive income, changes in stockholders’ equity (deficit), and cash flows for the three months ended May 1, 2026 and May 2, 2025.

[0001571996-26-000030:notes:2]
The preparation of financial statements in accordance with GAAP requires management to make estimates and assumptions that affect the amounts reported in the Condensed Consolidated Financial Statements and the accompanying Notes. Actual results could differ materially from those estimates. The results of its operations, corresponding comprehensive income, changes in stockholders’ equity (deficit), and cash flows for the three months ended May 1, 2026 and May 2, 2025 are not necessarily indicative of the results to be expected for the full fiscal year or for any other fiscal period.

[0001571996-26-000030:notes:3]
The Company’s fiscal year is the 52- or 53-week period ending on the Friday nearest January 31. The fiscal year ending January 29, 2027 and the fiscal year ended January 30, 2026 may be referred to as “Fiscal 2027” and “Fiscal 2026,” respectively. Both the fiscal year ending January 29, 2027 and the fiscal year ended January 30, 2026 are 52-week periods.


## us-gaap:ConsolidationPolicyTextBlock

[0001571996-26-000030:notes:4]
Principles of Consolidation — These Condensed Consolidated Financial Statements include the accounts of Dell Technologies Inc. and its wholly-owned subsidiaries, as well as the accounts of SecureWorks Corp. (“Secureworks”), which was majority-owned by Dell Technologies through the date of the sale of Secureworks as discussed below. All intercompany transactions have been eliminated.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001571996-26-000030:notes:5]
Recently Issued Accounting Pronouncements

[0001571996-26-000030:notes:6]
Environmental Credits and Environmental Credit Obligations — In May 2026, the Financial Accounting Standards Board (“FASB”) issued guidance to improve the financial accounting disclosure of environmental credits and environmental credit obligations, providing recognition, measurement, presentation, and disclosure requirements for all entities that generate, purchase, or receive environmental credits or have a regulatory compliance obligation that may be settled with environmental credits. Public entities must adopt the new guidance for fiscal years beginning after December 15, 2027, with early adoption permitted. Upon adoption, the guidance will be applied retrospectively. The Company is currently evaluating the impact and timing of adoption of this guidance.

[0001571996-26-000030:notes:7]
Internal-Use Software — In September 2025, the FASB issued guidance to modernize internal-use software capitalization by removing references to software development project stages, increasing the operability of the recognition guidance permitting consideration of different methods of software development, including the agile method. Public entities must adopt the new guidance for fiscal years beginning after December 15, 2027, with early adoption permitted. Upon adoption, the guidance may be applied prospectively, retrospectively, or through a modified approach. The Company is currently evaluating the impact and timing of adoption of this guidance.

[0001571996-26-000030:notes:8]
Expense Disaggregation Disclosures — In November 2024, the FASB issued guidance to improve disclosures about a public entity’s expenses by requiring disclosure of additional information about the types of expenses commonly presented in the financial statements on an annual and interim basis. Public entities must adopt the new guidance for fiscal years beginning after December 15, 2026, with early adoption permitted. Upon adoption, the guidance will be applied prospectively. Adoption of this new guidance will result in increased disclosures in the Notes to the Condensed Consolidated Financial Statements.


## us-gaap:FairValueDisclosuresTextBlock

[0001571996-26-000030:notes:9]
[same as prior period, unchanged from 0001571996-25-000127:notes:8]

[0001571996-26-000030:notes:10]
|  | May 1, 2026 |  | January 30, 2026 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | Quoted Prices in Active Markets for Identical Assets |  | Significant Other Observable Inputs |  | Significant Unobservable Inputs |  |  |  | Quoted Prices in Active Markets for Identical Assets |  | Significant Other Observable Inputs |  | Significant Unobservable Inputs |  |  |
|  | (in millions) |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | $ | 7,520 |  |  | $ | — |  |  | $ | — |  |  | $ | 7,520 |  |  | $ | 8,052 |  |  | $ | — |  |  | $ | — |  |  | $ | 8,052 |  |
| Marketable equity and other securities | 77 |  |  | — |  |  | — |  |  | 77 |  |  | 77 |  |  | — |  |  | — |  |  | 77 |  |
| Derivative instruments | — |  |  | 97 |  |  | — |  |  | 97 |  |  | — |  |  | 160 |  |  | — |  |  | 160 |  |
| Total assets | $ | 7,597 |  |  | $ | 97 |  |  | $ | — |  |  | $ | 7,694 |  |  | $ | 8,129 |  |  | $ | 160 |  |  | $ | — |  |  | $ | 8,289 |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Derivative instruments | $ | — |  |  | $ | 116 |  |  | $ | — |  |  | $ | 116 |  |  | $ | — |  |  | $ | 126 |  |  | $ | — |  |  | $ | 126 |  |
| Total liabilities | $ | — |  |  | $ | 116 |  |  | $ | — |  |  | $ | 116 |  |  | $ | — |  |  | $ | 126 |  |  | $ | — |  |  | $ | 126 |  |

[0001571996-26-000030:notes:11]
[same as prior period, unchanged from 0001571996-25-000127:notes:10]

[0001571996-26-000030:notes:12]
Money Market Funds — The Company’s investment in money market funds that are classified as cash equivalents hold underlying investments with a weighted average maturity of 90 days or less and are recognized at fair value. The valuations of these securities are based on quoted prices for identical assets in active markets, when available, or pricing models whereby all significant inputs are observable, or can be derived from, or corroborated by, observable market data. The Company reviews security pricing and assesses money market fund liquidity on a quarterly basis. As of May 1, 2026, the Company’s portfolio had no exposure to money market funds with a fluctuating net asset value.

[0001571996-26-000030:notes:13]
[same as prior period, unchanged from 0001571996-25-000127:notes:12]

[0001571996-26-000030:notes:14]
[same as prior period, unchanged from 0001571996-25-000127:notes:13]

[0001571996-26-000030:notes:15]
Deferred Compensation Plans — The Company offers deferred compensation plans for eligible employees which allow participants to defer a portion of their compensation. Assets and liabilities associated with the plans are measured at fair value using Level 1 inputs. Assets were the same as liabilities associated with the plans at approximately $269 million and $274 million as of May 1, 2026 and January 30, 2026, respectively, and are included in other assets and other liabilities on the Condensed Consolidated Statements of Financial Position. The net impact on the Condensed Consolidated Statements of Income is not material since changes in the fair value of the assets substantially offset changes in the fair value of the liabilities. As such, assets and liabilities associated with these plans have not been included in the recurring fair value table above.

[0001571996-26-000030:notes:16]
[same as prior period, unchanged from 0001571996-25-000127:notes:15]

[0001571996-26-000030:notes:17]
[same as prior period, unchanged from 0001571996-25-000127:notes:16]

[0001571996-26-000030:notes:18]
[same as prior period, unchanged from 0001571996-25-000127:notes:17]

[0001571996-26-000030:notes:19]
|  | May 1, 2026 |  | January 30, 2026 |
|  | Carrying Value |  | Fair Value |  | Carrying Value |  | Fair Value |
|  | (in billions) |
| Senior Notes | $ | 20.9 |  |  | $ | 21.1 |  |  | $ | 21.4 |  |  | $ | 21.8 |  |
| Legacy Notes | $ | 0.9 |  |  | $ | 1.0 |  |  | $ | 0.9 |  |  | $ | 1.0 |  |
| DFS Debt | $ | 9.3 |  |  | $ | 9.1 |  |  | $ | 9.1 |  |  | $ | 8.9 |  |

[0001571996-26-000030:notes:20]
[same as prior period, unchanged from 0001571996-25-000127:notes:19]


## us-gaap:InvestmentTextBlock

[0001571996-26-000030:notes:21]
INVESTMENTS
The Company has strategic investments in equity and other securities as well as immaterial investments in fixed income debt securities that are recorded as long-term investments in the Condensed Consolidated Statements of Financial Position. As of May 1, 2026 and January 30, 2026, total investments were $2.5 billion and $1.7 billion, respectively.

[0001571996-26-000030:notes:22]
Equity and other securities include strategic investments in marketable and non-marketable securities. Investments in marketable securities are measured at fair value on a recurring basis. Investments in non-marketable equity and other securities primarily represent early-stage companies without readily determinable fair values. The Company has elected to apply the measurement alternative for non-marketable securities which allows investments without readily determinable fair values to be measured at cost, less impairment, adjusted for observable price changes. The Company makes a separate election to apply the measurement alternative for each eligible investment and is required to reassess at each reporting period whether an investment qualifies for the alternative. In evaluating these investments for impairment or observable price changes, the Company uses inputs including pre- and post-money valuations of recent financing events and the impact of those events on its fully diluted ownership percentages, as well as other available information regarding the issuer’s historical and forecasted performance.

[0001571996-26-000030:notes:23]
The following table presents the carrying value of the Company's strategic investments in marketable and non-marketable equity and other securities as of the dates indicated:

[0001571996-26-000030:notes:24]
|  | May 1, 2026 |  | January 30, 2026 |
|  | (in millions) |
| Marketable | $ | 77 |  |  | $ | 77 |  |
| Non-marketable | 2,394 |  |  | 1,640 |  |
| Total equity and other securities | $ | 2,471 |  |  | $ | 1,717 |  |

[0001571996-26-000030:notes:25]
[same as prior period, unchanged from 0001571996-25-000127:notes:26]

[0001571996-26-000030:notes:26]
|  |  |  | Three Months Ended |
|  |  |  |  |  | May 1, 2026 |  | May 2, 2025 |  |  |
|  |  |  |  |  | (in millions) |
| Marketable securities: |  |  |  |  |  |  |  |  |  |
| Net unrealized losses |  |  |  |  | $ | (24) |  |  | $ | (1) |  |  |  |
| Non-marketable securities: |  |  |  |  |  |  |  |  |  |
| Unrealized gains |  |  |  |  | 681 |  |  | 22 |  |  |  |
| Unrealized losses |  |  |  |  | (26) |  |  | (6) |  |  |  |
| Net unrealized gains (a) |  |  |  |  | 655 |  |  | 16 |  |  |  |
| Net unrealized gains on equity and other securities |  |  |  |  | $ | 631 |  |  | $ | 15 |  |  |  |

[0001571996-26-000030:notes:27]
[same as prior period, unchanged from 0001571996-25-000127:notes:28]

[0001571996-26-000030:notes:28]
(a)During the three months ended May 1, 2026, net unrealized gains on non-marketable securities was primarily attributable to an upward observable price adjustment of $0.6 billion related to a single investee.

[0001571996-26-000030:notes:29]
As of May 1, 2026 and January 30, 2026, the cumulative unrealized gains on non-marketable securities were $1.8 billion and $1.1 billion, respectively. As of both May 1, 2026 and January 30, 2026, the cumulative unrealized losses, including impairments, on non-marketable securities were $0.3 billion.


## dell:CreditLossFinancialInstrumentLeasesDebtVariableInterestEntitiesAndCustomerReceivablesSalesTextBlock

[0001571996-26-000030:notes:30]
FINANCIAL SERVICES 
The Company offers or arranges a portfolio of payment and consumption solutions and services for its customers globally, including utility, subscription, as-a-Service, leases, and loans, designed to match customers' consumption and financing preferences and to provide operational and financial flexibility.

[0001571996-26-000030:notes:31]
To support financing solutions and services as part of the Dell Technologies portfolio, Dell Financial Services and its affiliates (“DFS”) originate, collect, and service customer financing arrangements primarily related to the purchase and use of Dell Technologies products and services. In some cases, the Company also offers financing for the purchase of third-party technology products that complement the portfolio of the Company’s products and services. New financing originations were $2.8 billion and $1.6 billion for the three months ended May 1, 2026 and May 2, 2025, respectively.

[0001571996-26-000030:notes:32]
The Company’s financing arrangements with customers are aggregated as fixed-term leases and loans as described below.

[0001571996-26-000030:notes:33]
Leases — The Company enters into fixed-term financing arrangements with customers who seek lease financing for equipment. Leases are generally classified as sales-type leases or operating leases. Additionally, utility, subscription, and as-a-Service flexible consumption models may result in identification of embedded lease arrangements that require the recognition of sales-type leases or operating leases. Leases with business customers generally have fixed terms of two to five years.

[0001571996-26-000030:notes:34]
Loans — The Company also offers fixed-term loans to qualified small businesses, large commercial accounts, governmental organizations, educational entities, and certain individual consumer customers. These loans are repaid in periodic payments including interest and have defined terms typically ranging from one to five years. The fair value of the fixed-term loan portfolio is determined using market observable inputs. The carrying value of these loans approximates fair value.

[0001571996-26-000030:notes:35]
Financing Receivables

[0001571996-26-000030:notes:36]
The following table presents the components of the Company’s financing receivables as of the dates indicated:

[0001571996-26-000030:notes:37]
|  |  |  |  |  | May 1, 2026 |  |  |  |  |  | January 30, 2026 |
|  |  |  |  |  | (in millions) |
| Customer receivables, gross (a) |  |  |  |  | $ | 13,966 |  |  |  |  |  |  | $ | 14,295 |  |
| Allowance for losses |  |  |  |  | (212) |  |  |  |  |  |  | (213) |  |
| Customer receivables, net |  |  |  |  | 13,754 |  |  |  |  |  |  | 14,082 |  |
| Residual interest |  |  |  |  | 196 |  |  |  |  |  |  | 198 |  |
| Financing receivables, net |  |  |  |  | $ | 13,950 |  |  |  |  |  |  | $ | 14,280 |  |
| Short-term |  |  |  |  | $ | 8,237 |  |  |  |  |  |  | $ | 8,458 |  |
| Long-term |  |  |  |  | $ | 5,713 |  |  |  |  |  |  | $ | 5,822 |  |

[0001571996-26-000030:notes:38]
(a)Customer receivables, gross include amounts due from customers under fixed-term leases and loans and accrued interest.

[0001571996-26-000030:notes:39]
The following table presents the changes in allowance for financing receivable losses for the periods indicated:

[0001571996-26-000030:notes:40]
|  |  |  |  |  |  |  | Three Months Ended |
|  |  |  |  |  |  |  |  |  | May 1, 2026 |  |  |  |  |  | May 2, 2025 |  |  |
|  |  |  |  |  |  |  |  |  | (in millions) |
| Balances at beginning of period |  |  |  |  |  |  |  |  | $ | 213 |  |  |  |  |  |  | $ | 153 |  |  |  |  |  |  |  |
| Charge-offs, net of recoveries |  |  |  |  |  |  |  |  | (10) |  |  |  |  |  |  | (10) |  |  |  |  |  |  |  |
| Provision charged to income statement |  |  |  |  |  |  |  |  | 9 |  |  |  |  |  |  | 1 |  |  |  |  |  |  |  |
| Balances at end of period |  |  |  |  |  |  |  |  | $ | 212 |  |  |  |  |  |  | $ | 144 |  |  |  |  |  |  |  |

[0001571996-26-000030:notes:41]
The Company recognizes an allowance for financing receivable losses, including both the lease receivable and unguaranteed residual, in an amount equal to the expected credit losses, net of recoveries. The allowance for financing receivable losses on the lease receivable is determined based on various factors, including lifetime expected losses determined using macroeconomic forecast assumptions and management judgments applicable to and through the expected life of the portfolios as well as past due receivables, receivable type, and customer risk profile. The Company continues to monitor broader economic indicators and their potential impact on future credit loss performance.

[0001571996-26-000030:notes:42]
Aging

[0001571996-26-000030:notes:43]
The following table presents the aging of the Company’s customer financing receivables, gross, including accrued interest, as of the dates indicated:

[0001571996-26-000030:notes:44]
|  | May 1, 2026 |  | January 30, 2026 |
|  | (in millions) |
| Current 0 — 30 Days | $ | 13,723 |  |  | $ | 13,985 |  |
| Past Due 31 — 90 Days | 120 |  |  | 195 |  |
| Past Due > 90 Days | 123 |  |  | 115 |  |
| Total | $ | 13,966 |  |  | $ | 14,295 |  |

[0001571996-26-000030:notes:45]
Aging is likely to fluctuate as a result of the variability in volume of large transactions entered into over the period, and the administrative processes that accompany those transactions. Aging is also impacted by the timing of the Company’s fiscal period end date relative to calendar month-end customer payment due dates. As a result of these factors, fluctuations in aging from period to period do not necessarily indicate a material change in the collectibility of the portfolio.

[0001571996-26-000030:notes:46]
Customer receivables are placed on non-accrual status if principal or interest is past due and considered delinquent, or if there is concern about the collectibility of a specific customer receivable. The receivables identified as doubtful for collectibility may be classified as current for aging purposes.

[0001571996-26-000030:notes:47]
Credit Quality

[0001571996-26-000030:notes:48]
The following tables present customer receivables, gross, including accrued interest, by credit quality indicator, as of the dates indicated:

[0001571996-26-000030:notes:49]
|  | May 1, 2026 |
|  | Fiscal Year of Origination |  |  |
|  | 2027 |  | 2026 |  | 2025 |  | 2024 |  | 2023 |  | Years Prior |  | Total |
|  | (in millions) |
| Higher | $ | 980 |  |  | $ | 2,378 |  |  | $ | 1,508 |  |  | $ | 1,185 |  |  | $ | 420 |  |  | $ | 54 |  |  | $ | 6,525 |  |
| Mid | 705 |  |  | 3,492 |  |  | 962 |  |  | 299 |  |  | 89 |  |  | 11 |  |  | 5,558 |  |
| Lower | 356 |  |  | 992 |  |  | 268 |  |  | 163 |  |  | 88 |  |  | 16 |  |  | 1,883 |  |
| Total | $ | 2,041 |  |  | $ | 6,862 |  |  | $ | 2,738 |  |  | $ | 1,647 |  |  | $ | 597 |  |  | $ | 81 |  |  | $ | 13,966 |  |

[0001571996-26-000030:notes:50]
|  | January 30, 2026 |
|  | Fiscal Year of Origination |  |  |
|  | 2026 |  | 2025 |  | 2024 |  | 2023 |  | 2022 |  | Years Prior |  | Total |
|  | (in millions) |
| Higher | $ | 2,671 |  |  | $ | 1,683 |  |  | $ | 1,430 |  |  | $ | 564 |  |  | $ | 84 |  |  | $ | 14 |  |  | $ | 6,446 |  |
| Mid | 4,077 |  |  | 1,354 |  |  | 419 |  |  | 163 |  |  | 22 |  |  | 1 |  |  | 6,036 |  |
| Lower | 1,153 |  |  | 321 |  |  | 209 |  |  | 109 |  |  | 11 |  |  | 10 |  |  | 1,813 |  |
| Total | $ | 7,901 |  |  | $ | 3,358 |  |  | $ | 2,058 |  |  | $ | 836 |  |  | $ | 117 |  |  | $ | 25 |  |  | $ | 14,295 |  |

[0001571996-26-000030:notes:51]
The categories shown in the tables above segregate customer receivables, gross, based on the relative degrees of credit risk. Credit quality indicators are updated on a periodic basis. An internal grading system is utilized that assigns a credit level score based on a number of considerations, including liquidity, operating performance, and industry outlook.

[0001571996-26-000030:notes:52]
Leases

[0001571996-26-000030:notes:53]
The following table presents amounts included in the Condensed Consolidated Statements of Income related to sales-type lease activity for the periods indicated:

[0001571996-26-000030:notes:54]
|  |  |  | Three Months Ended |
|  |  |  |  |  | May 1, 2026 |  | May 2, 2025 |  |  |
|  |  |  |  |  | (in millions) |
| Interest income — products |  |  |  |  | $ | 86 |  |  | $ | 93 |  |  |  |
| Net revenue — products |  |  |  |  | $ | 534 |  |  | $ | 119 |  |  |  |
| Cost of net revenue — products |  |  |  |  | 525 |  |  | 131 |  |  |  |
| Gross margin — products |  |  |  |  | $ | 9 |  |  | $ | (12) |  |  |  |

[0001571996-26-000030:notes:55]
The following table presents the future maturity of the Company’s customer leases and associated financing payments, and reconciles the undiscounted cash flows to the customer receivables, gross recognized on the Condensed Consolidated Statements of Financial Position as of the date indicated:

[0001571996-26-000030:notes:56]
|  | May 1, 2026 |
|  | (in millions) |
| Fiscal 2027 (remaining nine months) | $ | 2,382 |  |
| Fiscal 2028 | 2,090 |  |
| Fiscal 2029 | 1,373 |  |
| Fiscal 2030 | 645 |  |
| Fiscal 2031 and thereafter | 328 |  |
| Total undiscounted cash flows | 6,818 |  |
| Loans | 8,337 |  |
| Less: Unearned income | (1,189) |  |
| Total customer receivables, gross | $ | 13,966 |  |

[0001571996-26-000030:notes:57]
Operating Leases

[0001571996-26-000030:notes:58]
The Company’s operating leases primarily consist of fixed-term leases and contractually committed embedded leases identified within flexible consumption arrangements.

[0001571996-26-000030:notes:59]
The following table presents the components of the Company’s operating lease portfolio included in property, plant, and equipment, net as of the dates indicated:

[0001571996-26-000030:notes:60]
|  | May 1, 2026 |  | January 30, 2026 |
|  | (in millions) |
| Equipment under operating lease, gross | $ | 4,946 |  |  | $ | 4,651 |  |
| Less: Accumulated depreciation | (2,215) |  |  | (2,192) |  |
| Equipment under operating lease, net | $ | 2,731 |  |  | $ | 2,459 |  |

[0001571996-26-000030:notes:61]
The following table presents operating lease income related to lease payments and depreciation expense for the Company’s operating lease portfolio for the periods indicated:

[0001571996-26-000030:notes:62]
|  |  |  | Three Months Ended |
|  |  |  |  |  | May 1, 2026 |  | May 2, 2025 |  |  |
|  |  |  |  |  | (in millions) |
| Income related to lease payments |  |  |  |  | $ | 405 |  |  | $ | 358 |  |  |  |
| Depreciation expense |  |  |  |  | $ | 254 |  |  | $ | 244 |  |  |  |

[0001571996-26-000030:notes:63]
The following table presents the future payments to be received by the Company in operating lease contracts as of the date indicated:

[0001571996-26-000030:notes:64]
|  | May 1, 2026 |
|  | (in millions) |
| Fiscal 2027 (remaining nine months) | $ | 1,111 |  |
| Fiscal 2028 | 1,118 |  |
| Fiscal 2029 | 711 |  |
| Fiscal 2030 | 240 |  |
| Fiscal 2031 and thereafter | 114 |  |
| Total | $ | 3,294 |  |

[0001571996-26-000030:notes:65]
DFS Debt

[0001571996-26-000030:notes:66]
The Company maintains programs that facilitate the funding of leases, loans, and other alternative payment structures in the capital markets. The majority of DFS debt is non-recourse to Dell Technologies and represents borrowings under securitization programs and structured financing programs for which the Company’s risk of loss is limited to transferred lease and loan payments and associated equipment.

[0001571996-26-000030:notes:67]
The following table presents DFS debt as of the dates indicated and excludes the allocated portion of the Company’s other borrowings, which represents the additional amount considered to fund the DFS business:

[0001571996-26-000030:notes:68]
|  | May 1, 2026 |  | January 30, 2026 |
|  | (in millions) |
| DFS U.S. debt: |  |  |  |
| Asset-based financing facility | $ | 2,901 |  |  | $ | 3,146 |  |
| Fixed-term securitization offerings | 3,033 |  |  | 2,648 |  |
| Total DFS U.S. debt, principal amount | 5,934 |  |  | 5,794 |  |
| DFS international debt: |  |  |  |
| Securitization facility | 656 |  |  | 698 |  |
| Other borrowings | 928 |  |  | 851 |  |
| Dell Bank senior unsecured eurobonds | 1,760 |  |  | 1,796 |  |
| Total DFS international debt, principal amount | 3,344 |  |  | 3,345 |  |
| Total DFS debt, principal amount | $ | 9,278 |  |  | $ | 9,139 |  |
| Short-term | $ | 5,775 |  |  | $ | 5,719 |  |
| Long-term | $ | 3,503 |  |  | $ | 3,420 |  |

[0001571996-26-000030:notes:69]
DFS U.S. Debt

[0001571996-26-000030:notes:70]
Asset-Based Financing Facility — The Company maintains an asset-based financing facility in the United States, which is a revolving facility for fixed-term leases and loans. This debt is collateralized solely by the U.S. lease and loan payments and associated equipment in the facility. The asset-based financing facility consists of two tranches, with effective dates through July 7, 2026 and July 7, 2027, respectively. As of May 1, 2026, the total debt capacity related to the asset-based financing facility was $4.6 billion. The debt has a variable interest rate, and the duration of the debt is based on the terms of the underlying lease and loan payment streams. The Company enters into interest rate swap agreements to economically convert a portion of this debt from a floating rate to a fixed rate. See Note 7 of the Notes to the Condensed Consolidated Financial Statements for additional information about the Company’s interest rate swaps.

[0001571996-26-000030:notes:71]
The asset-based financing facility contains standard structural features related to the performance of the funded receivables, which include defined credit losses, delinquencies, average credit scores, and minimum collection requirements. In the event one or more of these criteria are not met and the Company is unable to restructure the facility, no further funding of receivables will be permitted and the timing of the Company’s expected cash flows from over-collateralization will be delayed. As of May 1, 2026, these criteria were met.

[0001571996-26-000030:notes:72]
Fixed-Term Securitization Offerings — The Company periodically issues asset-backed debt securities under fixed-term securitization programs to private investors. The asset-backed debt securities are collateralized solely by the U.S. fixed-term lease and loan payments and associated equipment, which are held by Special Purpose Entities (“SPEs”), as discussed below. The interest rate on these securities is fixed and ranges from 4.01% to 6.75% per annum as of May 1, 2026, and the duration of these securities is based on the terms of the underlying lease and loan payment streams.

[0001571996-26-000030:notes:73]
DFS International Debt

[0001571996-26-000030:notes:74]
Securitization Facility — The Company maintains a securitization facility in Europe for fixed-term leases and loans. The debt under this facility has a variable interest rate, and the duration of the debt is based on the terms of the underlying lease and loan payment streams. This facility is effective through December 22, 2026 and had a total debt capacity of $938 million as of May 1, 2026.

[0001571996-26-000030:notes:75]
The securitization facility contains standard structural features related to the performance of the securitized receivables, which include defined credit losses, delinquencies, average credit scores, and minimum collection requirements. In the event one or more of these criteria are not met and the Company is unable to restructure the program, no further funding of receivables will be permitted and the timing of the Company’s expected cash flows from over-collateralization will be delayed. As of May 1, 2026, these criteria were met.

[0001571996-26-000030:notes:76]
Other Borrowings — In connection with the Company’s international financing operations, the Company has entered into revolving structured financing debt programs related to its fixed-term lease and loan products sold in Canada, Europe, the Middle East, Australia and New Zealand, and Singapore. The debt under these programs has a variable interest rate.

[0001571996-26-000030:notes:77]
The duration of the debt in Canada, Europe, the Middle East, and Australia and New Zealand is based on the terms of the underlying lease and loan payment streams. These facilities are collateralized solely by the lease and loan payments and associated equipment in their respective region or country.

[0001571996-26-000030:notes:78]
As of May 1, 2026,

[0001571996-26-000030:notes:79]
•the Canadian facility had a total debt capacity of $258 million and is effective through January 15, 2028,

[0001571996-26-000030:notes:80]
•the European facility had a total debt capacity of $469 million and is effective through December 14, 2026,

[0001571996-26-000030:notes:81]
•the Middle East facility had a total debt capacity of $150 million and is effective through March 14, 2028, and

[0001571996-26-000030:notes:82]
•the Australia and New Zealand facility had a total debt capacity of $306 million and is effective through April 17, 2027.

[0001571996-26-000030:notes:83]
The Company also has two unsecured Singapore facilities, which had a total debt capacity of $259 million as of May 1, 2026 and are effective through July 12, 2026 and July 3, 2027, respectively. Subsequent to the close of the three months ended May 1, 2026, the Company extended the term of the July 12, 2026 facility to be effective through July 12, 2027.

[0001571996-26-000030:notes:84]
Dell Bank Senior Unsecured Eurobonds — On October 27, 2021, Dell Bank issued €500 million of 0.5% senior unsecured five-year eurobonds due October 2026. On October 18, 2022, Dell Bank issued €500 million of 4.5% senior unsecured five-year eurobonds due October 2027. On June 24, 2024, Dell Bank issued €500 million of 3.6% senior unsecured five-year eurobonds due June 2029. The issuances of the senior unsecured eurobonds support the expansion of the financing operations in Europe.

[0001571996-26-000030:notes:85]
Variable Interest Entities

[0001571996-26-000030:notes:86]
In connection with the asset-based financing facility, fixed-term securitization offerings, and securitization facility discussed above, the Company transfers certain U.S. and European lease and loan payments and associated equipment to SPEs that meet the definition of a VIE and are consolidated, along with the associated debt described above, into the Condensed Consolidated Financial Statements, as the Company is the primary beneficiary of the VIEs. The SPEs are bankruptcy-remote legal entities with separate assets and liabilities. The purpose of the SPEs is to facilitate the funding of customer lease and loan payments and associated equipment in the capital markets.

[0001571996-26-000030:notes:87]
Some of the SPEs have entered into financing arrangements with multi-seller conduits that, in turn, issue asset-backed debt securities in the capital markets. DFS debt outstanding held by the consolidated VIEs is collateralized by the lease and loan payments and associated equipment. The Company’s risk of loss related to securitized receivables is limited to the amount by which the Company’s right to receive collections for assets securitized exceeds the amount required to pay interest, principal, and fees and expenses related to the asset-backed securities. The Company provides credit enhancement to the securitization offerings in the form of over-collateralization.

[0001571996-26-000030:notes:88]
The following table presents the assets and liabilities held by the consolidated VIEs as of the dates indicated, which are included in the Condensed Consolidated Statements of Financial Position:

[0001571996-26-000030:notes:89]
|  | May 1, 2026 |  | January 30, 2026 |
|  | (in millions) |
| Assets held by consolidated VIEs: |  |  |  |
| Other current assets | $ | 174 |  |  | $ | 176 |  |
| Financing receivables, net of allowance: |  |  |  |
| Short-term | $ | 3,143 |  |  | $ | 3,280 |  |
| Long-term | $ | 2,945 |  |  | $ | 2,704 |  |
| Property, plant, and equipment, net | $ | 964 |  |  | $ | 984 |  |
| Liabilities held by consolidated VIEs: |  |  |  |
| Debt, net of unamortized debt issuance costs: |  |  |  |
| Short-term | $ | 4,373 |  |  | $ | 4,548 |  |
| Long-term | $ | 2,204 |  |  | $ | 1,933 |  |

[0001571996-26-000030:notes:90]
Lease and loan payments and associated equipment transferred via securitization through SPEs were $1.3 billion and $1.2 billion for the three months ended May 1, 2026, and May 2, 2025, respectively.

[0001571996-26-000030:notes:91]
Customer Receivables Sales

[0001571996-26-000030:notes:92]
To manage certain concentrations of customer credit exposure, the Company may sell selected fixed-term customer receivables to unrelated third parties on a periodic basis, without recourse. The amounts of customer receivables sold for this purpose were immaterial for both the three months ended May 1, 2026 and May 2, 2025. The Company’s continuing involvement in these customer receivables is primarily limited to servicing arrangements.


## us-gaap:ScheduleOfDebtTableTextBlock

[0001571996-26-000030:notes:93]
The following table summarizes the Company’s outstanding debt as of the dates indicated:

[0001571996-26-000030:notes:94]
|  | May 1, 2026 |  | January 30, 2026 |
|  | (in millions) |
| Senior Notes | $ | 21,073 |  |  | $ | 21,573 |  |
| Legacy Notes | 952 |  |  | 952 |  |
| DFS Debt (Note 4) | 9,278 |  |  | 9,139 |  |
| Other | 110 |  |  | 99 |  |
| Total debt, principal amount | 31,413 |  |  | 31,763 |  |
| Unamortized discount, net of unamortized premium | (109) |  |  | (112) |  |
| Debt issuance costs | (143) |  |  | (148) |  |
| Total debt, carrying value | $ | 31,161 |  |  | $ | 31,503 |  |
| Short-term | $ | 7,550 |  |  | $ | 7,990 |  |
| Long-term | $ | 23,611 |  |  | $ | 23,513 |  |


## us-gaap:LesseeOperatingLeasesTextBlock

[0001571996-26-000030:notes:95]
LEASES 
The Company enters into leasing transactions in which the Company is the lessee. These lease contracts are typically classified as operating leases. The Company’s lease contracts are generally for office space used to conduct its business, and the determination of whether such contracts contain leases generally does not require significant estimates or judgments. The Company also leases certain property, equipment, and warehouses. As of May 1, 2026, the remaining terms of the Company’s leases generally range from one month to approximately ten years. As of May 1, 2026 and January 30, 2026, there were no material finance leases in which the Company was a lessee.

[0001571996-26-000030:notes:96]
[same as prior period, unchanged from 0001571996-25-000127:notes:92]

[0001571996-26-000030:notes:97]
[same as prior period, unchanged from 0001571996-25-000127:notes:93]

[0001571996-26-000030:notes:98]
|  |  |  | Three Months Ended |
|  |  |  |  |  | May 1, 2026 |  | May 2, 2025 |  |  |
|  |  |  |  |  | (in millions) |
| Operating lease costs |  |  |  |  | $ | 67 |  |  | $ | 58 |  |  |  |
| Variable costs |  |  |  |  | 21 |  |  | 23 |  |  |  |
| Total lease costs |  |  |  |  | $ | 88 |  |  | $ | 81 |  |  |  |

[0001571996-26-000030:notes:99]
During the three months ended May 1, 2026 and May 2, 2025, sublease income, finance lease costs, and short-term lease costs were immaterial.

[0001571996-26-000030:notes:100]
[same as prior period, unchanged from 0001571996-25-000127:notes:96]

[0001571996-26-000030:notes:101]
|  | Classification |  | May 1, 2026 |  | January 30, 2026 |  |  |
|  |  |  | (in millions, except for term and discount rate) |
| Operating lease right-of-use assets | Other non-current assets |  | $ | 661 |  | $ | 640 |  |  |
| Current operating lease liabilities | Accrued and other current liabilities |  | $ | 250 |  | $ | 246 |  |  |
| Non-current operating lease liabilities | Other non-current liabilities |  | 495 |  | 481 |  |  |
| Total operating lease liabilities |  |  | $ | 745 |  | $ | 727 |  |  |
| Weighted-average remaining lease term (in years) |  |  | 4.19 |  | 4.11 |  |  |
| Weighted-average discount rate |  |  | 4.70 | % |  | 4.74 | % |  |  |

[0001571996-26-000030:notes:102]
[same as prior period, unchanged from 0001571996-25-000127:notes:98]

[0001571996-26-000030:notes:103]
|  | Three Months Ended |
|  | May 1, 2026 |  | May 2, 2025 |  |  |
|  | (in millions) |
| Cash paid for amounts included in the measurement of lease liabilities — operating cash outflows from operating leases | $ | 67 |  |  | $ | 63 |  |  |  |
| Right-of-use assets obtained in exchange for new operating lease liabilities | $ | 78 |  |  | $ | 65 |  |  |  |

[0001571996-26-000030:notes:104]
[same as prior period, unchanged from 0001571996-25-000127:notes:100]

[0001571996-26-000030:notes:105]
|  | May 1, 2026 |
|  | (in millions) |
| Fiscal 2027 (remaining nine months) | $ | 191 |  |
| Fiscal 2028 | 216 |  |
| Fiscal 2029 | 161 |  |
| Fiscal 2030 | 110 |  |
| Fiscal 2031 | 65 |  |
| Thereafter | 77 |  |
| Total lease payments | 820 |  |
| Less: Imputed interest | 75 |  |
| Total | $ | 745 |  |
| Current operating lease liabilities | $ | 250 |  |
| Non-current operating lease liabilities | $ | 495 |  |

[0001571996-26-000030:notes:106]
As of May 1, 2026, the Company’s undiscounted operating leases that had not yet commenced were immaterial.


## us-gaap:DebtDisclosureTextBlock

[0001571996-26-000030:notes:107]
DEBT
The following table summarizes the Company’s outstanding debt as of the dates indicated:

[0001571996-26-000030:notes:108]
During the three months ended May 1, 2026, the Company repaid the remaining outstanding $0.5 billion principal amount of 6.02% Senior Notes due June 2026.

[0001571996-26-000030:notes:109]
Outstanding Debt

[0001571996-26-000030:notes:110]
Senior Notes — The Company completed offerings of multiple series of senior notes which were issued on June 1, 2016, March 20, 2019, April 9, 2020, December 13, 2021, January 24, 2023, March 18, 2024, October 8, 2024, April 1, 2025, and October 6, 2025 in aggregate principal amounts of $20.0 billion, $4.5 billion, $2.3 billion, $2.3 billion, $2.0 billion, $1.0 billion, $1.5 billion, $4.0 billion, and $4.5 billion, respectively (collectively, the “Senior Notes”). The Senior Notes have maturity dates ranging from 2026 through 2051. Interest rates on these borrowings are fixed, ranging from 3.38% to 8.35% per annum, and interest is payable semiannually.

[0001571996-26-000030:notes:111]
Legacy Notes — The Company has outstanding unsecured notes and debentures (collectively, the “Legacy Notes”) that were issued by Dell Inc. (“Dell”), a wholly-owned subsidiary of Dell Technologies Inc., prior to the acquisition of Dell by Dell Technologies Inc. in the going-private transaction that closed in October 2013. The Legacy Notes’ maturities range from 2028 through 2040. Interest rates on these borrowings are fixed, ranging from 5.40% to 7.10% per annum, and interest is payable semiannually.

[0001571996-26-000030:notes:112]
DFS Debt — See Note 4 and Note 7 of the Notes to the Condensed Consolidated Financial Statements, respectively, for discussion of DFS debt and the interest rate swap agreements that hedge a portion of that debt.

[0001571996-26-000030:notes:113]
Revolving Credit Facility — The Company’s revolving credit facility provides the Company with revolving commitments in an aggregate principal amount of $6.0 billion for general corporate purposes and includes a letter of credit sub-facility of up to $0.5 billion and a swing-line loan sub-facility of up to $0.5 billion. The revolving credit facility allows the Company to obtain incremental additional commitments on one or more occasions in minimum amounts of $10 million. The facility also acts as a backstop to provide liquidity support for the Company’s commercial paper program.

[0001571996-26-000030:notes:114]
Borrowings under the revolving credit facility bear interest at a rate per annum equal to an applicable margin plus, at the borrowers’ option, either (a) the specified adjusted term Secured Overnight Financing Rate (“SOFR”) or (b) a base rate. The margin applicable to SOFR and base rate borrowings varies based upon the Company’s existing credit ratings. The base rate is calculated based upon the greatest of the specified prime rate, the specified federal reserve bank rate, or SOFR plus 1%. The borrowers may voluntarily repay outstanding loans at any time without premium or penalty, other than customary breakage costs. The facility matures on November 1, 2027.

[0001571996-26-000030:notes:115]
As of May 1, 2026, the Company had no outstanding borrowings under the revolving credit facility.

[0001571996-26-000030:notes:116]
Commercial Paper Program — The Company maintains a commercial paper program under which the Company may issue unsecured notes in a maximum aggregate face amount of $5.0 billion outstanding at any time, with maturities of up to 397 days from the date of issuance. The notes are sold on customary terms in the U.S. commercial paper market on a private placement basis. The proceeds of the notes are used for general corporate purposes. As of May 1, 2026, the Company had no outstanding issuances under the commercial paper program.

[0001571996-26-000030:notes:117]
The Company may purchase, redeem, prepay, refinance, or otherwise retire any amount of outstanding indebtedness under the terms of such indebtedness at any time and from time to time, in open market or negotiated transactions with the holders of such indebtedness or otherwise, as considered appropriate in light of market conditions and other relevant factors.

[0001571996-26-000030:notes:118]
Covenants — The credit agreement governing the revolving credit facility and the indentures governing the Senior Notes and the Legacy Notes impose various limitations, subject to exceptions, on creating certain liens and entering into sale and lease-back transactions. The foregoing credit agreement and indentures contain customary events of default, and the revolving credit facility is subject to an interest coverage ratio covenant that is tested at the end of each fiscal quarter with respect to the Company’s preceding four fiscal quarters. The Company was in compliance with this financial covenant as of May 1, 2026.

[0001571996-26-000030:notes:119]
Aggregate Future Maturities

[0001571996-26-000030:notes:120]
The following table presents the aggregate future maturities of the Company’s debt as of May 1, 2026, excluding associated carrying value adjustments, for the periods indicated:

[0001571996-26-000030:notes:121]
|  | May 1, 2026 |
|  | (in millions) |
| Fiscal 2027 (remaining nine months) | $ | 6,910 |  |
| Fiscal 2028 | 3,368 |  |
| Fiscal 2029 | 2,864 |  |
| Fiscal 2030 | 3,957 |  |
| Fiscal 2031 | 1,773 |  |
| Thereafter | 12,541 |  |
| Total maturities, principal amount | $ | 31,413 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001571996-26-000030:notes:122]
[same as prior period, unchanged from 0001571996-25-000127:notes:120]

[0001571996-26-000030:notes:123]
The Company’s objective is to offset gains and losses resulting from these exposures with gains and losses on the derivative contracts used to hedge the exposures, thereby reducing volatility of earnings and protecting the fair values of assets and liabilities. The earnings effects of the derivative instruments are presented in the same line items on the Condensed Consolidated Statements of Income as the earnings effects of the hedged items. For derivatives designated as cash flow hedges, the Company assesses hedge effectiveness both at the onset of the hedge and at regular intervals throughout the life of the instruments.

[0001571996-26-000030:notes:124]
[same as prior period, unchanged from 0001571996-25-000127:notes:122]

[0001571996-26-000030:notes:125]
The Company uses foreign currency forward and option contracts designated as cash flow hedges to protect against the foreign currency exchange rate risks inherent in its forecasted transactions denominated in currencies other than the U.S. Dollar. Hedge accounting is applied based upon the criteria established by accounting guidance for derivative instruments and hedging activities. The risk of loss associated with forward contracts is equal to the exchange rate differential from the time the contract is entered into until the time it is settled. The risk of loss associated with purchased options is limited to premium amounts paid for the option contracts. The majority of these contracts typically expire in twelve months or less.

[0001571996-26-000030:notes:126]
During the three months ended May 1, 2026 and May 2, 2025, the Company did not discontinue any cash flow hedges related to foreign exchange contracts that had a material impact on the Company’s results of operations due to the probability that the forecasted cash flows would not occur.

[0001571996-26-000030:notes:127]
[same as prior period, unchanged from 0001571996-25-000127:notes:125]

[0001571996-26-000030:notes:128]
[same as prior period, unchanged from 0001571996-25-000127:notes:126]

[0001571996-26-000030:notes:129]
[same as prior period, unchanged from 0001571996-25-000127:notes:127]

[0001571996-26-000030:notes:130]
[same as prior period, unchanged from 0001571996-25-000127:notes:128]

[0001571996-26-000030:notes:131]
[same as prior period, unchanged from 0001571996-25-000127:notes:129]

[0001571996-26-000030:notes:132]
[same as prior period, unchanged from 0001571996-25-000127:notes:130]

[0001571996-26-000030:notes:133]
[same as prior period, unchanged from 0001571996-25-000127:notes:131]

[0001571996-26-000030:notes:134]
[same as prior period, unchanged from 0001571996-25-000127:notes:132]

[0001571996-26-000030:notes:135]
|  | May 1, 2026 |  | January 30, 2026 |
|  | (in millions) |
| Foreign exchange contracts: |  |  |  |
| Designated as cash flow hedging instruments | $ | 8,579 |  |  | $ | 7,491 |  |
| Non-designated as hedging instruments | 6,701 |  |  | 5,887 |  |
| Total | $ | 15,280 |  |  | $ | 13,378 |  |
| Interest rate contracts: |  |  |  |
| Non-designated as hedging instruments | $ | 6,809 |  |  | $ | 7,048 |  |

[0001571996-26-000030:notes:136]
[same as prior period, unchanged from 0001571996-25-000127:notes:134]

[0001571996-26-000030:notes:137]
| Derivatives in Cash Flow Hedging Relationships |  | Gain (Loss) Recognized in Accumulated OCI, Net of Tax, on Derivatives |  | Location of Gain (Loss) Reclassified from Accumulated OCI into Income |  | Gain (Loss) Reclassified from Accumulated OCI into Income |
|  |  | (in millions) |  |  |  | (in millions) |
| For the three months ended May 1, 2026: |
|  |  |  |  | Total net revenue |  | $ | (4) |  |
| Foreign exchange contracts |  | $ | 75 |  |  | Total cost of net revenue |  | (4) |  |
| Total |  | $ | 75 |  |  | Total |  | $ | (8) |  |
| For the three months ended May 2, 2025: |
|  |  |  |  | Total net revenue |  | $ | (8) |  |
| Foreign exchange contracts |  | $ | (257) |  |  | Total cost of net revenue |  | (3) |  |
| Total |  | $ | (257) |  |  | Total |  | $ | (11) |  |

[0001571996-26-000030:notes:138]
[same as prior period, unchanged from 0001571996-25-000127:notes:136]

[0001571996-26-000030:notes:139]
|  |  |  | Three Months Ended |  |  |
|  |  |  |  |  | May 1, 2026 |  | May 2, 2025 |  |  |  | Location of Gain (Loss) Recognized |
|  |  |  |  |  | (in millions) |  |  |
| Foreign exchange contracts |  |  |  |  | $ | (101) |  |  | $ | 298 |  |  |  |  | Interest and other, net |
| Interest rate contracts |  |  |  |  | 10 |  |  | (14) |  |  |  |  | Interest and other, net |
| Total |  |  |  |  | $ | (91) |  |  | $ | 284 |  |  |  |  |  |

[0001571996-26-000030:notes:140]
[same as prior period, unchanged from 0001571996-25-000127:notes:138]

[0001571996-26-000030:notes:141]
|  | May 1, 2026 |
|  | Other Current Assets |  | Other Non-Current Assets |  | Other Current Liabilities |  | Other Non-Current Liabilities |  | Total Fair Value |
|  | (in millions) |
| Derivatives designated as hedging instruments: |
| Foreign exchange contracts in an asset position | $ | 52 |  |  | $ | — |  |  | $ | 16 |  |  | $ | — |  |  | $ | 68 |  |
| Foreign exchange contracts in a liability position | (14) |  |  | — |  |  | (32) |  |  | — |  |  | (46) |  |
| Net asset (liability) | 38 |  |  | — |  |  | (16) |  |  | — |  |  | 22 |  |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts in an asset position | 88 |  |  | — |  |  | 86 |  |  | — |  |  | 174 |  |
| Foreign exchange contracts in a liability position | (66) |  |  | — |  |  | (168) |  |  | — |  |  | (234) |  |
| Interest rate contracts in an asset position | 3 |  |  | 34 |  |  | — |  |  | — |  |  | 37 |  |
| Interest rate contracts in a liability position | — |  |  | — |  |  | (1) |  |  | (17) |  |  | (18) |  |
| Net asset (liability) | 25 |  |  | 34 |  |  | (83) |  |  | (17) |  |  | (41) |  |
| Total derivatives at fair value | $ | 63 |  |  | $ | 34 |  |  | $ | (99) |  |  | $ | (17) |  |  | $ | (19) |  |
|  | January 30, 2026 |
|  | Other Current Assets |  | Other Non-Current Assets |  | Other Current Liabilities |  | Other Non-Current Liabilities |  | Total Fair Value |
|  | (in millions) |
| Derivatives designated as hedging instruments: |
| Foreign exchange contracts in an asset position | $ | 26 |  |  | $ | — |  |  | $ | 13 |  |  | $ | — |  |  | $ | 39 |  |
| Foreign exchange contracts in a liability position | (54) |  |  | — |  |  | (59) |  |  | — |  |  | (113) |  |
| Net asset (liability) | (28) |  |  | — |  |  | (46) |  |  | — |  |  | (74) |  |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts in an asset position | 291 |  |  | 1 |  |  | 119 |  |  | — |  |  | 411 |  |
| Foreign exchange contracts in a liability position | (146) |  |  | — |  |  | (169) |  |  | — |  |  | (315) |  |
| Interest rate contracts in an asset position | 5 |  |  | 37 |  |  | — |  |  | — |  |  | 42 |  |
| Interest rate contracts in a liability position | — |  |  | — |  |  | — |  |  | (30) |  |  | (30) |  |
| Net asset (liability) | 150 |  |  | 38 |  |  | (50) |  |  | (30) |  |  | 108 |  |
| Total derivatives at fair value | $ | 122 |  |  | $ | 38 |  |  | $ | (96) |  |  | $ | (30) |  |  | $ | 34 |  |

[0001571996-26-000030:notes:142]
[same as prior period, unchanged from 0001571996-25-000127:notes:140]

[0001571996-26-000030:notes:143]
|  | May 1, 2026 |
|  | Gross Amounts of Recognized Assets/(Liabilities) |  | Gross Amounts Offset in the Statement of Financial Position |  | Net Amounts of Assets/(Liabilities) Presented in the Statement of Financial Position |  | Gross Amounts not Offset in the Statement of Financial Position |  | Net Amount of Assets/ (Liabilities) Recognized in the Statement of Financial Position |
|  | Financial Instruments |  | Cash Collateral Received or Pledged |  |
|  | (in millions) |
| Financial assets | $ | 279 |  |  | $ | (182) |  |  | $ | 97 |  |  | $ | — |  |  | $ | (49) |  |  | $ | 48 |  |
| Financial liabilities | (298) |  |  | 182 |  |  | (116) |  |  | — |  |  | — |  |  | (116) |  |
| Total derivative instruments | $ | (19) |  |  | $ | — |  |  | $ | (19) |  |  | $ | — |  |  | $ | (49) |  |  | $ | (68) |  |
|  | January 30, 2026 |
|  | Gross Amounts of Recognized Assets/(Liabilities) |  | Gross Amounts Offset in the Statement of Financial Position |  | Net Amounts of Assets/(Liabilities) Presented in the Statement of Financial Position |  | Gross Amounts not Offset in the Statement of Financial Position |  | Net Amount of Assets/ (Liabilities) Recognized in the Statement of Financial Position |
|  | Financial Instruments |  | Cash Collateral Received or Pledged |  |
|  | (in millions) |
| Financial assets | $ | 492 |  |  | $ | (332) |  |  | $ | 160 |  |  | $ | — |  |  | $ | (46) |  |  | $ | 114 |  |
| Financial liabilities | (458) |  |  | 332 |  |  | (126) |  |  | — |  |  | 1 |  |  | (125) |  |
| Total derivative instruments | $ | 34 |  |  | $ | — |  |  | $ | 34 |  |  | $ | — |  |  | $ | (45) |  |  | $ | (11) |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001571996-26-000030:notes:144]
[same as prior period, unchanged from 0001571996-25-000127:notes:142]

[0001571996-26-000030:notes:145]
The Infrastructure Solutions Group (“ISG”) and Client Solutions Group (“CSG”) reporting units are consistent with the reportable segments identified in Note 15 of the Notes to the Condensed Consolidated Financial Statements.

[0001571996-26-000030:notes:146]
[same as prior period, unchanged from 0001571996-25-000127:notes:144]

[0001571996-26-000030:notes:147]
|  | Infrastructure Solutions Group |  | Client Solutions Group |  |  |  | Total |
|  | (in millions) |
| Balances as of January 30, 2026 | $ | 15,315 |  |  | $ | 4,232 |  |  |  |  | $ | 19,547 |  |
| Impact of foreign currency translation and other | (43) |  |  | — |  |  |  |  | (43) |  |
| Balances as of May 1, 2026 | $ | 15,272 |  |  | $ | 4,232 |  |  |  |  | $ | 19,504 |  |

[0001571996-26-000030:notes:148]
[same as prior period, unchanged from 0001571996-25-000127:notes:146]

[0001571996-26-000030:notes:149]
[same as prior period, unchanged from 0001571996-25-000127:notes:147]

[0001571996-26-000030:notes:150]
|  | May 1, 2026 |  | January 30, 2026 |
|  | Gross |  | Accumulated Amortization |  | Net |  | Gross |  | Accumulated Amortization |  | Net |
|  | (in millions) |
| Customer relationships | $ | 16,644 |  |  | $ | (15,386) |  |  | $ | 1,258 |  |  | $ | 16,644 |  |  | $ | (15,321) |  |  | $ | 1,323 |  |
| Developed technology | 9,524 |  |  | (9,402) |  |  | 122 |  |  | 9,525 |  |  | (9,376) |  |  | 149 |  |
| Trade names | 875 |  |  | (871) |  |  | 4 |  |  | 875 |  |  | (869) |  |  | 6 |  |
| Definite-lived intangible assets | 27,043 |  |  | (25,659) |  |  | 1,384 |  |  | 27,044 |  |  | (25,566) |  |  | 1,478 |  |
| Indefinite-lived trade names | 3,055 |  |  | — |  |  | 3,055 |  |  | 3,055 |  |  | — |  |  | 3,055 |  |
| Total intangible assets | $ | 30,098 |  |  | $ | (25,659) |  |  | $ | 4,439 |  |  | $ | 30,099 |  |  | $ | (25,566) |  |  | $ | 4,533 |  |

[0001571996-26-000030:notes:151]
For both the three months ended May 1, 2026 and May 2, 2025, amortization expense related to definite-lived intangible assets was $0.1 billion. There were no material impairment charges related to intangible assets during the three months ended May 1, 2026 and May 2, 2025.

[0001571996-26-000030:notes:152]
[same as prior period, unchanged from 0001571996-25-000127:notes:150]

[0001571996-26-000030:notes:153]
|  | May 1, 2026 |
|  | (in millions) |
| Fiscal 2027 (remaining nine months) | $ | 282 |  |
| Fiscal 2028 | 236 |  |
| Fiscal 2029 | 196 |  |
| Fiscal 2030 | 159 |  |
| Fiscal 2031 | 132 |  |
| Thereafter | 379 |  |
| Total | $ | 1,384 |  |

[0001571996-26-000030:notes:154]
[same as prior period, unchanged from 0001571996-25-000127:notes:152]

[0001571996-26-000030:notes:155]
Goodwill and indefinite-lived intangible assets are tested for impairment annually during the third fiscal quarter and whenever events or circumstances may indicate that an impairment has occurred.

[0001571996-26-000030:notes:156]
For the annual impairment review performed during the third quarter of Fiscal 2026, the Company assessed the goodwill in each of its reporting units and indefinite-lived intangible assets. The Company is permitted to conduct a qualitative assessment to determine whether it is necessary to perform a quantitative goodwill impairment test. The Company’s qualitative assessment included consideration of the relevant events and circumstances affecting the reporting unit, including macroeconomic, industry and market conditions, recent market transactions, overall financial performance, trends in the public company market valuation, changes in projected future cash flows, and the results of the most recent quantitative assessment, where applicable. Based on this assessment, the Company concluded that it was more likely than not that the estimated fair values of the reporting units and indefinite-lived intangible assets were higher than their respective carrying values. No goodwill or indefinite-lived assets impairment test was performed during the three months ended May 1, 2026.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001571996-26-000030:notes:157]
DEFERRED REVENUE 
Deferred revenue consists of support and deployment services, software maintenance, training, software-as-a-service, and undelivered hardware and professional services, consisting of installations and consulting engagements. Deferred revenue is recorded when the Company has invoiced or payments have been received for undelivered products or services, or in situations where revenue recognition criteria have not been met. Revenue is recognized as the Company’s performance obligations under the contract are completed.

[0001571996-26-000030:notes:158]
[same as prior period, unchanged from 0001571996-25-000127:notes:155]

[0001571996-26-000030:notes:159]
|  |  |  | Three Months Ended |
|  |  |  |  |  | May 1, 2026 |  | May 2, 2025 |
|  |  |  |  |  | (in millions) |
| Deferred revenue at beginning of period |  |  |  |  | $ | 26,930 |  |  | $ | 25,965 |  |
| Revenue deferrals |  |  |  |  | 5,540 |  |  | 5,455 |  |
| Revenue recognized |  |  |  |  | (5,018) |  |  | (5,100) |  |
| Deferred revenue at end of period |  |  |  |  | $ | 27,452 |  |  | $ | 26,320 |  |
| Short-term |  |  |  |  | $ | 13,193 |  |  | $ | 13,907 |  |
| Long-term |  |  |  |  | $ | 14,259 |  |  | $ | 12,413 |  |

[0001571996-26-000030:notes:160]
Remaining Performance Obligations

[0001571996-26-000030:notes:161]
Remaining performance obligations represent the aggregate amount of the transaction price allocated to performance obligations not delivered, or partially undelivered, as of the end of the reporting period. Remaining performance obligations include deferred revenue plus unbilled amounts not yet recorded in deferred revenue. The value of the transaction price allocated to remaining performance obligations as of May 1, 2026 was approximately $97 billion. The Company expects to recognize approximately 80% of remaining performance obligations as revenue in the next twelve months, approximately 10% in the following twelve months, and the remainder thereafter.

[0001571996-26-000030:notes:162]
[same as prior period, unchanged from 0001571996-25-000127:notes:159]

[0001571996-26-000030:notes:163]
[same as prior period, unchanged from 0001571996-25-000127:notes:160]


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001571996-26-000030:notes:164]
COMMITMENTS AND CONTINGENCIES 
Purchase Obligations

[0001571996-26-000030:notes:165]
The Company has contractual obligations that are enforceable and legally binding to purchase goods or services and that specify all significant terms, including fixed or minimum quantities to be purchased; fixed, minimum, or variable price provisions; and the approximate timing of the transaction. Purchase obligations include the non-cancelable portion or the minimum cancellation fee under the contract, and are primarily related to commitments with suppliers, software maintenance, and support services. As of May 1, 2026, such purchase obligations were $16.9 billion for the remainder of Fiscal 2027, $1.2 billion for Fiscal 2028, $1.4 billion for Fiscal 2029, $0.8 billion for Fiscal 2030, and $0.5 billion for Fiscal 2031 and thereafter.

[0001571996-26-000030:notes:166]
Legal Matters

[0001571996-26-000030:notes:167]
The Company is involved in various claims, suits, assessments, investigations, and legal proceedings that arise from time to time in the ordinary course of its business, including those identified below, consisting of matters involving consumer, antitrust, tax, intellectual property, and other issues on a global basis.

[0001571996-26-000030:notes:168]
The Company accrues a liability when it believes that it is both probable that a liability has been incurred and that it can reasonably estimate the amount of the loss. The Company reviews these accruals at least quarterly and adjusts them to reflect ongoing negotiations, settlements, rulings, advice of legal counsel, and other relevant information. To the extent new information is obtained and the Company’s views on the probable outcomes of claims, suits, assessments, investigations, or legal proceedings change, changes in the Company’s accrued liabilities are recorded in the period in which such a determination is made. For some matters, the incurrence of a liability is not probable or the amount cannot be reasonably estimated and therefore accruals have not been made.

[0001571996-26-000030:notes:169]
Class Action Relating to Dell 401(k) Plan — On January 28, 2026, a complaint was filed in the U.S. District Court for the Western District of Texas in a putative class action captioned Lowbruck et al. v. Dell Technologies Inc., et al., against the Company, the Company’s Board of Directors, and the Dell Benefits Administration Committee alleging a breach of fiduciary duties under the Employment Retirement Income Security Act of 1974 (“ERISA”). In the complaint, the plaintiffs seek a judicial declaration that the defendants breached their fiduciary duties by failing to remove imprudent investments from the Dell 401(k) (“Plan”) in a reasonable time, engaging in transactions allegedly prohibited under ERISA, and failing to monitor the fiduciaries responsible for the Plan’s administration. The plaintiffs also seek, among other remedies, an award of damages, fees, and costs in an unspecified amount. The Company intends to vigorously defend this action.

[0001571996-26-000030:notes:170]
In accordance with the relevant accounting guidance, the Company provides disclosures of matters where it is at least reasonably possible that the Company could experience a material loss exceeding the amounts already accrued for across all proceedings or matters. In addition, the Company also discloses matters based on its consideration of other matters and qualitative factors, including the experience of other companies in the industry, and investor, customer, and employee relations considerations. As of May 1, 2026, the Company does not believe there is a reasonable possibility that a material loss exceeding the amounts already accrued for across all proceedings or matters has been incurred. However, since the ultimate resolution of any such proceedings and matters is inherently unpredictable, the Company’s business, financial condition, results of operations, or cash flows could be materially affected in any particular period by unfavorable outcomes in one or more of these proceedings or matters. Whether the outcome of any claim, suit, assessment, investigation, or legal proceeding, individually or collectively, could have a material adverse effect on the Company’s business, financial condition, results of operations, or cash flows will depend on a number of factors, including the nature, timing, and amount of any associated expenses, amounts paid in settlement, damages, or other remedies or consequences.

[0001571996-26-000030:notes:171]
Indemnifications Obligations

[0001571996-26-000030:notes:172]
In the ordinary course of business, the Company enters into various contracts under which it may agree to indemnify other parties for losses incurred from certain events as defined in the relevant contract, such as litigation, regulatory penalties, or claims relating to past performance. Such indemnification obligations may not be subject to maximum loss clauses. Historically, payments related to these indemnification obligations have not been material to the Company.

[0001571996-26-000030:notes:173]
Under the Separation and Distribution Agreement entered into with VMware, Inc. (currently operating under the name VMware LLC, and individually and together with its subsidiaries, “VMware”), Dell Technologies and VMware agreed to indemnify each other and their respective subsidiaries, directors, officers, employees, and any successors and assigns of the foregoing, from and against all liabilities relating to, arising out of or resulting from, among other matters, the liabilities allocated to each party as part of the separation of their respective businesses. The amounts that VMware and Dell Technologies may be obligated to pay each other could vary depending on the outcome of certain unresolved tax matters, which may not be resolved for several years. Net income tax indemnification receivables from VMware were immaterial as of May 1, 2026 and January 30, 2026.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001571996-26-000030:notes:174]
INCOME AND OTHER TAXES
For the three months ended May 1, 2026, the Company’s effective income tax rate was 12.9% on pre-tax income of $3.9 billion compared to 10.9% on pre-tax income of $1.1 billion for the three months ended May 2, 2025. The changes in the Company’s effective income tax rate were primarily driven by discrete tax items. For the three months ended May 1, 2026 and May 2, 2025, the Company recorded discrete tax benefits of $0.2 billion and $0.1 billion, respectively, related to stock-based compensation.

[0001571996-26-000030:notes:175]
The differences between the estimated effective income tax rates and the U.S. federal statutory rate of 21% is primarily due to foreign earnings taxed at different rates, as well as to discrete tax items.

[0001571996-26-000030:notes:176]
In June 2023, the Company received a Revenue Agent’s Report for the federal income tax examination by the Internal Revenue Service (“IRS”) of fiscal years 2018 through 2019. The IRS proposed significant adjustments primarily relating to certain transactions the Company completed as part of its business integration efforts. In August 2023, the Company submitted a written protest to the IRS relating to certain assessments. The Company received a rebuttal from the IRS to its written protest in April 2024. The Company disagrees with the IRS’s proposed adjustments and will contest them through the IRS administrative appeals procedures. The Company expects to continue discussions with the IRS Independent Office of Appeals throughout the fiscal year and anticipates that the appeals process for the resolution of these matters will extend beyond the next twelve months. The IRS is also currently conducting a federal income tax examination of the Company for fiscal years 2020 through 2022.

[0001571996-26-000030:notes:177]
[same as prior period, unchanged from 0001571996-25-000127:notes:174]

[0001571996-26-000030:notes:178]
The Company believes that it has provided adequate reserves related to all income tax matters contained in tax periods open to examination, including the IRS audits described above. Although the Company believes it has made adequate provisions for the uncertainties with respect to these audits, should the Company experience unfavorable outcomes, such outcomes could have a material impact on its results of operations, financial position, and cash flows.
Judgment is required in evaluating the Company’s uncertain tax positions and determining the Company’s provision for income taxes. Net unrecognized tax benefits were $1.1 billion as of both May 1, 2026 and January 30, 2026, and are included in other non-current liabilities in the Condensed Consolidated Statements of Financial Position.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001571996-26-000030:notes:179]
[same as prior period, unchanged from 0001571996-25-000127:notes:178]

[0001571996-26-000030:notes:180]
[same as prior period, unchanged from 0001571996-25-000127:notes:179]

[0001571996-26-000030:notes:181]
|  | Foreign Currency Translation Adjustments |  |  |  | Cash Flow Hedges |  | Pension and Other Postretirement Plans |  | Accumulated Other Comprehensive Income (Loss) |
|  | (in millions) |
| Balances as of January 30, 2026 | $ | (565) |  |  |  |  | $ | (129) |  |  | $ | (25) |  |  | $ | (719) |  |
| Other comprehensive income (loss) before reclassifications | (74) |  |  |  |  | 75 |  |  | 1 |  |  | 2 |  |
| Amounts reclassified from accumulated other comprehensive income | — |  |  |  |  | 8 |  |  | — |  |  | 8 |  |
| Total change for the period | (74) |  |  |  |  | 83 |  |  | 1 |  |  | 10 |  |
| Balances as of May 1, 2026 | $ | (639) |  |  |  |  | $ | (46) |  |  | $ | (24) |  |  | $ | (709) |  |

[0001571996-26-000030:notes:182]
[same as prior period, unchanged from 0001571996-25-000127:notes:182]

[0001571996-26-000030:notes:183]
The following table present reclassifications out of accumulated other comprehensive income (loss), net of tax, to net income for the periods indicated:

[0001571996-26-000030:notes:184]
|  |  |  | Three Months Ended |
|  |  |  | May 1, 2026 |  | May 2, 2025 |  |  |
|  |  |  | Cash Flow Hedges |  |  |  |  |  |  |  |  |  |  |  | Cash Flow Hedges |  |  |  |  |  |  |  |  |  |  |
|  |  |  | (in millions) |
| Net revenue |  |  | $ | (4) |  |  |  |  |  |  |  |  |  |  |  |  | $ | (8) |  |  |  |  |  |  |  |  |  |  |  |
| Cost of net revenue |  |  | (4) |  |  |  |  |  |  |  |  |  |  |  |  | (3) |  |  |  |  |  |  |  |  |  |  |  |
| Total reclassifications, net of tax |  |  | $ | (8) |  |  |  |  |  |  |  |  |  |  |  |  | $ | (11) |  |  |  |  |  |  |  |  |  |  |  |


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001571996-26-000030:notes:185]
[same as prior period, unchanged from 0001571996-25-000127:notes:186]

[0001571996-26-000030:notes:186]
|  | Authorized |  | Issued |  | Outstanding |
|  | (in millions) |
| Common stock as of May 1, 2026: |
| Class A | 600 |  |  | 277 |  |  | 277 |  |
| Class B | 200 |  |  | 48 |  |  | 48 |  |
| Class C | 7,900 |  |  | 527 |  |  | 324 |  |
| Class D | 100 |  |  | — |  |  | — |  |
|  | 8,800 |  |  | 852 |  |  | 649 |  |
| Common stock as of January 30, 2026: |
| Class A | 600 |  |  | 277 |  |  | 277 |  |
| Class B | 200 |  |  | 52 |  |  | 52 |  |
| Class C | 7,900 |  |  | 515 |  |  | 323 |  |
| Class D | 100 |  |  | — |  |  | — |  |
|  | 8,800 |  |  | 844 |  |  | 652 |  |

[0001571996-26-000030:notes:187]
[same as prior period, unchanged from 0001571996-25-000127:notes:188]

[0001571996-26-000030:notes:188]
The Company is authorized to issue one million shares of preferred stock, par value $0.01 per share. As of May 1, 2026 and January 30, 2026, no shares of preferred stock were issued or outstanding.

[0001571996-26-000030:notes:189]
[same as prior period, unchanged from 0001571996-25-000127:notes:190]

[0001571996-26-000030:notes:190]
[same as prior period, unchanged from 0001571996-25-000127:notes:191]

[0001571996-26-000030:notes:191]
[same as prior period, unchanged from 0001571996-25-000127:notes:192]

[0001571996-26-000030:notes:192]
[same as prior period, unchanged from 0001571996-25-000127:notes:193]

[0001571996-26-000030:notes:193]
During the three months ended May 1, 2026, the Company issued approximately 4 million shares of Class C Common Stock to stockholders upon the conversion of the same number of shares of Class B Common Stock in accordance with the Company’s certificate of incorporation.

[0001571996-26-000030:notes:194]
During the fiscal year ended January 30, 2026, the Company issued approximately 10 million shares of Class C Common Stock to stockholders upon the conversion of an immaterial number of Class A Common Stock shares and 10 million shares of Class B Common Stock in accordance with the Company’s certificate of incorporation.

[0001571996-26-000030:notes:195]
[same as prior period, unchanged from 0001571996-25-000127:notes:195]

[0001571996-26-000030:notes:196]
On February 26, 2026, the Company announced that the Board of Directors approved a 20% increase in the quarterly dividend rate to $0.630 per share per fiscal quarter beginning in the first quarter of Fiscal 2027.

[0001571996-26-000030:notes:197]
[same as prior period, unchanged from 0001571996-25-000127:notes:197]

[0001571996-26-000030:notes:198]
| Three Months Ended |  | Declaration Date |  | Record Date |  | Payment Date |  | Dividend per Share |  | Amount (in millions) |
| Fiscal 2027: |
| May 1, 2026 |  | March 2, 2026 |  | April 21, 2026 |  | May 1, 2026 |  | $ | 0.630 |  |  | $ | 410 |  |
| Fiscal 2026: |
| May 2, 2025 |  | February 27, 2025 |  | April 22, 2025 |  | May 2, 2025 |  | $ | 0.525 |  |  | $ | 360 |  |

[0001571996-26-000030:notes:199]
During the three months ended May 1, 2026 and May 2, 2025, the Company also paid an immaterial amount of dividend equivalents on eligible vested equity awards which are not included above.

[0001571996-26-000030:notes:200]
[same as prior period, unchanged from 0001571996-25-000127:notes:200]

[0001571996-26-000030:notes:201]
On September 23, 2021, the Company’s Board of Directors approved the Company’s current stock repurchase program with no fixed expiration date under which the Company may repurchase a specified dollar value of Class C Common Stock, exclusive of any fees, commissions, or other expenses related to such repurchases. As of January 30, 2026, the Company’s Board of Directors authorized the repurchase of up to $20 billion of Class C Common Stock and on February 26, 2026 authorized an additional $10 billion of Class C Common Stock for repurchase. Following the February 26, 2026 approval, the Company had approximately $15.2 billion of authorized shares remaining for repurchase under the program.

[0001571996-26-000030:notes:202]
During the three months ended May 1, 2026 and May 2, 2025, the Company repurchased approximately 11 million and 22 million shares of Class C Common Stock for total purchase prices of approximately $1.6 billion and $2.0 billion, respectively. The foregoing amounts exclude U.S. federal excise taxes and shares withheld from equity awards to settle employee tax withholding obligations related to the vesting of such awards.


## us-gaap:EarningsPerShareTextBlock

[0001571996-26-000030:notes:203]
[same as prior period, unchanged from 0001571996-25-000127:notes:203]

[0001571996-26-000030:notes:204]
[same as prior period, unchanged from 0001571996-25-000127:notes:204]

[0001571996-26-000030:notes:205]
|  |  |  | Three Months Ended |
|  |  |  |  |  | May 1, 2026 |  | May 2, 2025 |  |  |
| Earnings per share: |  |  |
| Basic |  |  |  |  | $ | 5.30 |  |  | $ | 1.39 |  |  |  |
| Diluted |  |  |  |  | $ | 5.24 |  |  | $ | 1.37 |  |  |  |

[0001571996-26-000030:notes:206]
[same as prior period, unchanged from 0001571996-25-000127:notes:206]

[0001571996-26-000030:notes:207]
|  |  |  | Three Months Ended |
|  |  |  |  |  | May 1, 2026 |  | May 2, 2025 |  |  |
|  |  |  |  |  | (in millions) |
| Numerator: |  |  |  |  |  |  |  |  |  |
| Net income — basic and diluted |  |  |  |  | $ | 3,438 |  |  | $ | 965 |  |  |  |
| Denominator: |  |  |  |  |  |  |  |  |  |
| Weighted-average shares outstanding — basic |  |  |  |  | 649 |  |  | 692 |  |  |  |
| Dilutive effect of equity awards |  |  |  |  | 7 |  |  | 10 |  |  |  |
| Weighted-average shares outstanding — diluted |  |  |  |  | 656 |  |  | 702 |  |  |  |
| Weighted-average shares outstanding — antidilutive |  |  |  |  | — |  |  | 4 |  |  |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001571996-26-000030:notes:208]
[same as prior period, unchanged from 0001571996-25-000127:notes:208]

[0001571996-26-000030:notes:209]
The Company’s Chief Executive Officer is the Chief Operating Decision Maker (“CODM”). The CODM is regularly provided and reviews segment revenue and segment operating income to assess the performance of each segment and allocate resources to the segments in the annual planning process. The Company’s measure of segment revenue and segment operating income for management reporting purposes excludes Corporate and other, amortization of intangible assets, stock-based compensation expense, and other corporate expenses, as applicable, which are not used in evaluating the results of, or in allocating resources to, the segments. The Company does not allocate assets to its reportable segments for internal reporting purposes. The accounting policies of the segments are the same as those described in Note 2 to the Company’s Annual Report on Form 10-K for the fiscal year ended January 30, 2026.

[0001571996-26-000030:notes:210]
ISG includes the Company’s Artificial Intelligence (“AI”)-optimized servers offerings, traditional servers and networking offerings, and storage offerings as major product categories. The Company’s AI-optimized servers are designed to run high-value workloads, including AI model training, fine-tuning, and inferencing. The Company’s traditional servers are high-performance general-purpose servers designed to deliver scalable performance, reliability, and efficient management across a wide range of enterprise workloads. The Company’s networking portfolio includes wide area network infrastructure, data center and edge networking switches, and cables and optics. The Company’s comprehensive storage portfolio includes modern and traditional storage solutions that span primary, unstructured and data protection offerings and are delivered through multiple architectures, including all-flash, purpose-built, software-defined, and hyper-converged infrastructure platforms. ISG also offers software, peripherals, and services, including consulting and support and deployment.

[0001571996-26-000030:notes:211]
CSG includes the Company’s commercial offerings and consumer offerings as major product categories. The Company’s CSG portfolio includes branded PCs, including notebooks, desktops, and workstations and branded peripherals that include displays, docking stations, keyboards, mice, and webcam and audio devices, as well as third-party software and peripherals. CSG also includes services offerings, such as configuration, support and deployment, and extended warranties.

[0001571996-26-000030:notes:212]
In March 2024, the Company terminated the Commercial Framework Agreement with VMware, whereby Dell Technologies acted as a distributor of VMware’s stand-alone products and services and purchased such products and services for resale to end-user customers (“VMware Resale”). Dell Technologies no longer acts as a distributor of those products and services, although it continues to support customers that have purchased resale offerings sold in prior periods. The results of VMware Resale transactions are reflected in Corporate and other. The Company continues to integrate and embed certain VMware products and services with the Company’s VxRail solution to end-user customers. The results for this integrated offering are reflected within ISG.

[0001571996-26-000030:notes:213]
[same as prior period, unchanged from 0001571996-25-000127:notes:213]

[0001571996-26-000030:notes:214]
|  |  |  | Three Months Ended |
|  |  |  |  |  | May 1, 2026 |  | May 2, 2025 |  |  |
|  |  |  |  |  | (in millions) |
| Consolidated net revenue: |  |  |  |  |  |  |  |  |  |
| Infrastructure Solutions Group |  |  |  |  | $ | 29,009 |  |  | $ | 10,317 |  |  |  |
| Client Solutions Group |  |  |  |  | 14,609 |  |  | 12,509 |  |  |  |
| Reportable segment net revenue |  |  |  |  | 43,618 |  |  | 22,826 |  |  |  |
| Corporate and other (a) |  |  |  |  | 224 |  |  | 552 |  |  |  |
| Total consolidated net revenue |  |  |  |  | $ | 43,842 |  |  | $ | 23,378 |  |  |  |
| Consolidated operating income: |  |  |  |  |  |  |  |  |  |
| Infrastructure Solutions Group |  |  |  |  | $ | 3,055 |  |  | $ | 998 |  |  |  |
| Client Solutions Group |  |  |  |  | 1,170 |  |  | 653 |  |  |  |
| Reportable segment operating income (b) |  |  |  |  | 4,225 |  |  | 1,651 |  |  |  |
| Corporate and other (a) |  |  |  |  | 10 |  |  | 15 |  |  |  |
| Amortization of intangibles (c) |  |  |  |  | (97) |  |  | (126) |  |  |  |
| Stock-based compensation expense (d) |  |  |  |  | (189) |  |  | (190) |  |  |  |
| Other corporate expenses (e) |  |  |  |  | (293) |  |  | (185) |  |  |  |
| Total consolidated operating income (f) |  |  |  |  | $ | 3,656 |  |  | $ | 1,165 |  |  |  |

[0001571996-26-000030:notes:215]
(a)Corporate and other includes VMware Resale and other items that are managed at the corporate level and are not allocated to reportable segments.

[0001571996-26-000030:notes:216]
[same as prior period, unchanged from 0001571996-25-000127:notes:216]

[0001571996-26-000030:notes:217]
[same as prior period, unchanged from 0001571996-25-000127:notes:217]

[0001571996-26-000030:notes:218]
[same as prior period, unchanged from 0001571996-25-000127:notes:218]

[0001571996-26-000030:notes:219]
(e)Other corporate expenses includes severance expenses, payroll taxes associated with stock-based compensation, incentive charges related to equity investments, transaction-related expenses, and impairment charges.

[0001571996-26-000030:notes:220]
[same as prior period, unchanged from 0001571996-25-000127:notes:220]

[0001571996-26-000030:notes:221]
[same as prior period, unchanged from 0001571996-25-000127:notes:221]

[0001571996-26-000030:notes:222]
|  |  |  | Three Months Ended |
|  |  |  |  |  | May 1, 2026 |  | May 2, 2025 |  |  |
|  |  |  |  |  | (in millions) |
| Infrastructure Solutions Group: |  |  |  |  |  |  |  |  |  |
| Cost of net revenue |  |  |  |  | $ | 23,475 |  |  | $ | 7,050 |  |  |  |
| Selling, general, and administrative |  |  |  |  | $ | 1,794 |  |  | $ | 1,695 |  |  |  |
| Research and development |  |  |  |  | $ | 685 |  |  | $ | 574 |  |  |  |
| Client Solutions Group: |  |  |  |  |  |  |  |  |  |
| Cost of net revenue |  |  |  |  | $ | 12,204 |  |  | $ | 10,738 |  |  |  |
| Selling, general, and administrative |  |  |  |  | $ | 1,043 |  |  | $ | 982 |  |  |  |
| Research and development |  |  |  |  | $ | 192 |  |  | $ | 136 |  |  |  |

[0001571996-26-000030:notes:223]
[same as prior period, unchanged from 0001571996-25-000127:notes:223]

[0001571996-26-000030:notes:224]
|  |  |  | Three Months Ended |
|  |  |  |  |  | May 1, 2026 |  | May 2, 2025 |  |  |
|  |  |  |  |  | (in millions) |
| Net revenue: |  |  |  |  |  |  |  |  |  |
| Infrastructure Solutions Group: |  |  |  |  |  |  |  |  |  |
| AI-optimized servers |  |  |  |  | $ | 16,132 |  |  | $ | 1,882 |  |  |  |
| Traditional servers and networking |  |  |  |  | 8,543 |  |  | 4,439 |  |  |  |
| Storage |  |  |  |  | 4,334 |  |  | 3,996 |  |  |  |
| Total ISG net revenue |  |  |  |  | $ | 29,009 |  |  | $ | 10,317 |  |  |  |
| Client Solutions Group: |  |  |  |  |  |  |  |  |  |
| Commercial |  |  |  |  | $ | 13,020 |  |  | $ | 11,046 |  |  |  |
| Consumer |  |  |  |  | 1,589 |  |  | 1,463 |  |  |  |
| Total CSG net revenue |  |  |  |  | $ | 14,609 |  |  | $ | 12,509 |  |  |  |


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0001571996-26-000030:notes:225]
[same as prior period, unchanged from 0001571996-25-000127:notes:225]

[0001571996-26-000030:notes:226]
|  | May 1, 2026 |  | January 30, 2026 |
|  | (in millions) |
| Cash, cash equivalents, and restricted cash: |  |  |  |
| Cash and cash equivalents | $ | 11,578 |  |  | $ | 11,528 |  |
| Restricted cash (a) | 175 |  |  | 178 |  |
| Total cash, cash equivalents, and restricted cash | $ | 11,753 |  |  | $ | 11,706 |  |
| Inventories: |  |  |  |
| Production materials | $ | 10,634 |  |  | $ | 6,696 |  |
| Work-in-process | 3,483 |  |  | 2,772 |  |
| Finished goods | 935 |  |  | 969 |  |
| Total inventories | $ | 15,052 |  |  | $ | 10,437 |  |
| Prepaid expenses: |  |  |  |
| Total prepaid expenses (b) | $ | 729 |  |  | $ | 552 |  |
| Property, plant, and equipment, net: |  |  |  |
| Assets in a customer contract | $ | 6,217 |  |  | $ | 5,777 |  |
| Computer and other equipment | 3,949 |  |  | 3,849 |  |
| Land and buildings | 3,151 |  |  | 3,134 |  |
| Internal use software | 2,128 |  |  | 2,083 |  |
| Total property, plant, and equipment | 15,445 |  |  | 14,843 |  |
| Accumulated depreciation and amortization | (8,500) |  |  | (8,167) |  |
| Total property, plant, and equipment, net | $ | 6,945 |  |  | $ | 6,676 |  |

[0001571996-26-000030:notes:227]
(a)Restricted cash is primarily classified as other current assets in the Condensed Consolidated Statements of Financial Position and consists predominantly of cash required to be held in escrow pursuant to DFS securitization arrangements.

[0001571996-26-000030:notes:228]
(b)Prepaid expenses are included in other current assets in the Condensed Consolidated Statements of Financial Position. Amounts classified as long-term prepaid expenses are included in other non-current assets and are not disclosed above.

[0001571996-26-000030:notes:229]
[same as prior period, unchanged from 0001571996-25-000127:notes:230]

[0001571996-26-000030:notes:230]
[same as prior period, unchanged from 0001571996-25-000127:notes:231]

[0001571996-26-000030:notes:231]
|  |  |  | Three Months Ended |
|  |  |  |  |  | May 1, 2026 |  | May 2, 2025 |  |  |
|  |  |  |  |  | (in millions) |
| Warranty liability at beginning of period |  |  |  |  | $ | 450 |  |  | $ | 424 |  |  |  |
| Costs accrued for new warranty contracts and changes in estimates for pre-existing warranties (a) |  |  |  |  | 819 |  |  | 211 |  |  |  |
| Service obligations honored |  |  |  |  | (234) |  |  | (220) |  |  |  |
| Warranty liability at end of period (b) |  |  |  |  | $ | 1,035 |  |  | $ | 415 |  |  |  |

[0001571996-26-000030:notes:232]
[same as prior period, unchanged from 0001571996-25-000127:notes:233]

[0001571996-26-000030:notes:233]
[same as prior period, unchanged from 0001571996-25-000127:notes:234]

[0001571996-26-000030:notes:234]
[same as prior period, unchanged from 0001571996-25-000127:notes:235]

[0001571996-26-000030:notes:235]
[same as prior period, unchanged from 0001571996-25-000127:notes:236]

[0001571996-26-000030:notes:236]
[same as prior period, unchanged from 0001571996-25-000127:notes:237]

[0001571996-26-000030:notes:237]
|  |  |  | Three Months Ended |
|  |  |  |  |  | May 1, 2026 |  | May 2, 2025 |  |  |
|  |  |  |  |  | (in millions) |
| Severance liability at beginning of period |  |  |  |  | $ | 136 |  |  | $ | 238 |  |  |  |
| Severance charges |  |  |  |  | 227 |  |  | 130 |  |  |  |
| Cash paid and other |  |  |  |  | (121) |  |  | (217) |  |  |  |
| Severance liability at end of period |  |  |  |  | $ | 242 |  |  | $ | 151 |  |  |  |

[0001571996-26-000030:notes:238]
[same as prior period, unchanged from 0001571996-25-000127:notes:239]

[0001571996-26-000030:notes:239]
|  |  |  | Three Months Ended |
|  |  |  |  |  | May 1, 2026 |  | May 2, 2025 |  |  |
|  |  |  |  |  | (in millions) |
| Cost of net revenue |  |  |  |  | $ | 81 |  |  | $ | 30 |  |  |  |
| Selling, general, and administrative |  |  |  |  | 106 |  |  | 67 |  |  |  |
| Research and development |  |  |  |  | 40 |  |  | 33 |  |  |  |
| Total severance charges |  |  |  |  | $ | 227 |  |  | $ | 130 |  |  |  |

[0001571996-26-000030:notes:240]
[same as prior period, unchanged from 0001571996-25-000127:notes:241]

[0001571996-26-000030:notes:241]
The Company maintains a Supply Chain Finance Program (the “SCF Program”), which enables eligible suppliers, at the supplier's sole discretion, to sell receivables due from the Company to a third-party financial institution. The Company has no involvement in establishing the terms or conditions of the arrangement between its suppliers and the financial institution, no economic interest in a supplier's decision to sell a receivable, and does not provide legally secured assets or other forms of guarantees under the arrangement. The SCF Program does not impact the Company's liquidity, as payments for participating supplier invoices are remitted by the Company to the financial institution on the original invoice due date, regardless of whether an individual invoice is sold by the supplier to the financial institution.

[0001571996-26-000030:notes:242]
As of May 1, 2026 and January 30, 2026, the Company had $3.1 billion and $2.0 billion, respectively, included within accounts payable on the Condensed Consolidated Statements of Financial Position representing invoices due to suppliers confirmed as valid under the SCF Program.

[0001571996-26-000030:notes:243]
Interest and Other, Net

[0001571996-26-000030:notes:244]
[same as prior period, unchanged from 0001571996-25-000127:notes:244]

[0001571996-26-000030:notes:245]
|  |  |  | Three Months Ended |
|  |  |  |  |  | May 1, 2026 |  | May 2, 2025 |  |  |
|  |  |  |  |  | (in millions) |
| Investment income, primarily interest |  |  |  |  | $ | 81 |  |  | $ | 31 |  |  |  |
| Gain on investments, net |  |  |  |  | 631 |  |  | 17 |  |  |  |
| Interest expense |  |  |  |  | (391) |  |  | (354) |  |  |  |
| Foreign exchange |  |  |  |  | (17) |  |  | (5) |  |  |  |
| Gain on disposition of businesses and assets |  |  |  |  | — |  |  | 236 |  |  |  |
| Other |  |  |  |  | (12) |  |  | (7) |  |  |  |
| Total interest and other, net |  |  |  |  | $ | 292 |  |  | $ | (82) |  |  |  |


## us-gaap:SubsequentEventsTextBlock

[0001571996-26-000030:notes:246]
SUBSEQUENT EVENTS 
There were no known events occurring after May 1, 2026 and up until the date of issuance of this report that would materially affect the information presented herein.


## ecd:MtrlTermsOfTrdArrTextBlock

[0001571996-26-000030:notes:247]
On March 10, 2026, Richard J. Rothberg, our General Counsel, adopted a written plan for the sale of up to 45,000 shares of the Company’s Class C Common Stock that is intended to satisfy the affirmative defense conditions of Rule 10b5-1(c) under the Exchange Act. The plan will expire on June 30, 2026, or on any earlier date on which all of the shares have been sold.

[0001571996-26-000030:notes:248]
On March 24, 2026, Lynn M. Vojvodich, one of the Company’s directors, adopted a written plan for the sale of up to 28,198 shares of the Company’s Class C Common Stock that is intended to satisfy the affirmative defense conditions of Rule 10b5-1(c) under the Exchange Act. The plan will expire on March 5, 2027, or on any earlier date on which all of the shares have been sold.
