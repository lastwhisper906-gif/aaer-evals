# DELL note change history — 0001571996-25-000127 → 0001571996-26-000030


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- added (2026-06-09):
[0001571996-26-000030:note_history:1]
The Company has contractual obligations that are enforceable and legally binding to purchase goods or services and that specify all significant terms, including fixed or minimum quantities to be purchased; fixed, minimum, or variable price provisions; and the approximate timing of the transaction. Purchase obligations include the non-cancelable portion or the minimum cancellation fee under the contract, and are primarily related to commitments with suppliers, software maintenance, and support services. As of May 1, 2026, such purchase obligations were $16.9 billion for the remainder of Fiscal 2027, $1.2 billion for Fiscal 2028, $1.4 billion for Fiscal 2029, $0.8 billion for Fiscal 2030, and $0.5 billion for Fiscal 2031 and thereafter.

- added (2026-06-09):
[0001571996-26-000030:note_history:2]
The Company is involved in various claims, suits, assessments, investigations, and legal proceedings that arise from time to time in the ordinary course of its business, including those identified below, consisting of matters involving consumer, antitrust, tax, intellectual property, and other issues on a global basis.

- changed (2026-06-09):
[0001571996-26-000030:note_history:3]
The Company accrues a liability when it believes that it is both probable that a liability has been incurred and that it can reasonably estimate the amount of the loss. The Company reviews these accruals at least quarterly and adjusts them to reflect ongoing negotiations, settlements, rulings, advice of legal counsel, and other relevant information. To the extent new information is obtained and the Company’s views on the probable outcomes of claims, suits, assessments, investigations, or legal proceedings change, changes in the Company’s accrued liabilities are recorded in the period in which such a determination is made. For some matters, the incurrence of a liability is not probable or the amount cannot be reasonably estimated and therefore accruals have not been made.
  (was, 2025-12-09, similarity 0.8746):
[0001571996-25-000127:note_history:3]
The Company accrues a liability when it believes that it is both probable that a liability has been incurred and that it can reasonably estimate the amount of the loss. The Company reviews these accruals at least quarterly and adjusts them to reflect ongoing negotiations, settlements, rulings, advice of legal counsel, and other relevant information. To the extent new information is obtained and the Company’s views on the probable outcomes of claims, suits, assessments, investigations, or legal proceedings change, changes in the Company’s accrued liabilities are recorded in the period in which such a determination is made. For some matters, the incurrence of a liability is not probable or the amount cannot be reasonably estimated and therefore accruals have not been made. As of October 31, 2025, the Company does not currently anticipate that any of the legal proceedings it is involved in will have a material adverse effect on its business, financial condition, results of operations, or cash flows.

- added (2026-06-09):
[0001571996-26-000030:note_history:4]
Class Action Relating to Dell 401(k) Plan — On January 28, 2026, a complaint was filed in the U.S. District Court for the Western District of Texas in a putative class action captioned Lowbruck et al. v. Dell Technologies Inc., et al., against the Company, the Company’s Board of Directors, and the Dell Benefits Administration Committee alleging a breach of fiduciary duties under the Employment Retirement Income Security Act of 1974 (“ERISA”). In the complaint, the plaintiffs seek a judicial declaration that the defendants breached their fiduciary duties by failing to remove imprudent investments from the Dell 401(k) (“Plan”) in a reasonable time, engaging in transactions allegedly prohibited under ERISA, and failing to monitor the fiduciaries responsible for the Plan’s administration. The plaintiffs also seek, among other remedies, an award of damages, fees, and costs in an unspecified amount. The Company intends to vigorously defend this action.

- changed (2026-06-09):
[0001571996-26-000030:note_history:5]
In accordance with the relevant accounting guidance, the Company provides disclosures of matters where it is at least reasonably possible that the Company could experience a material loss exceeding the amounts already accrued for across all proceedings or matters. In addition, the Company also discloses matters based on its consideration of other matters and qualitative factors, including the experience of other companies in the industry, and investor, customer, and employee relations considerations. As of May 1, 2026, the Company does not believe there is a reasonable possibility that a material loss exceeding the amounts already accrued for across all proceedings or matters has been incurred. However, since the ultimate resolution of any such proceedings and matters is inherently unpredictable, the Company’s business, financial condition, results of operations, or cash flows could be materially affected in any particular period by unfavorable outcomes in one or more of these proceedings or matters. Whether the outcome of any claim, suit, assessment, investigation, or legal proceeding, individually or collectively, could have a material adverse effect on the Company’s business, financial condition, results of operations, or cash flows will depend on a number of factors, including the nature, timing, and amount of any associated expenses, amounts paid in settlement, damages, or other remedies or consequences.
  (was, 2025-12-09, similarity 0.9965):
[0001571996-25-000127:note_history:5]
In accordance with the relevant accounting guidance, the Company provides disclosures of matters where it is at least reasonably possible that the Company could experience a material loss exceeding the amounts already accrued for across all proceedings or matters. In addition, the Company also discloses matters based on its consideration of other matters and qualitative factors, including the experience of other companies in the industry, and investor, customer, and employee relations considerations. As of October 31, 2025, the Company does not believe there is a reasonable possibility that a material loss exceeding the amounts already accrued for across all proceedings or matters has been incurred. However, since the ultimate resolution of any such proceedings and matters is inherently unpredictable, the Company’s business, financial condition, results of operations, or cash flows could be materially affected in any particular period by unfavorable outcomes in one or more of these proceedings or matters. Whether the outcome of any claim, suit, assessment, investigation, or legal proceeding, individually or collectively, could have a material adverse effect on the Company’s business, financial condition, results of operations, or cash flows will depend on a number of factors, including the nature, timing, and amount of any associated expenses, amounts paid in settlement, damages, or other remedies or consequences.

- added (2026-06-09):
[0001571996-26-000030:note_history:6]
Under the Separation and Distribution Agreement entered into with VMware, Inc. (currently operating under the name VMware LLC, and individually and together with its subsidiaries, “VMware”), Dell Technologies and VMware agreed to indemnify each other and their respective subsidiaries, directors, officers, employees, and any successors and assigns of the foregoing, from and against all liabilities relating to, arising out of or resulting from, among other matters, the liabilities allocated to each party as part of the separation of their respective businesses. The amounts that VMware and Dell Technologies may be obligated to pay each other could vary depending on the outcome of certain unresolved tax matters, which may not be resolved for several years. Net income tax indemnification receivables from VMware were immaterial as of May 1, 2026 and January 30, 2026.

- removed (2026-06-09):
[0001571996-25-000127:note_history:7]
The Company has contractual obligations to purchase goods or services, which specify significant terms (including fixed or minimum quantities to be purchased), fixed, minimum, or variable price provisions, and the approximate timing of the transaction. Purchase obligations are primarily related to commitments with suppliers and software maintenance and support services. As of October 31, 2025, such purchase obligations were $6.0 billion for the remainder of Fiscal 2026, $0.7 billion for Fiscal 2027, $0.6 billion for Fiscal 2028, $0.5 billion for Fiscal 2029, and $0.7 billion for Fiscal 2030 and thereafter.

- removed (2026-06-09):
[0001571996-25-000127:note_history:8]
The Company is involved in various claims, suits, assessments, investigations, and legal proceedings that arise from time to time in the ordinary course of its business, consisting of matters involving consumer, antitrust, tax, intellectual property, and other issues on a global basis.

- removed (2026-06-09):
[0001571996-25-000127:note_history:9]
Under the Separation and Distribution Agreement entered into with VMware, Inc. upon completion of its spin-off of VMware, Inc. on November 1, 2021, Dell Technologies agreed to indemnify VMware, Inc., each of its subsidiaries and each of their respective directors, officers, employees, as well as any successors and assigns of the foregoing, from and against all liabilities relating to, arising out of or resulting from, among other matters, the liabilities allocated to Dell Technologies as part of the separation of Dell Technologies and VMware, Inc. (currently operating under the name VMware LLC, and individually and together with its subsidiaries, “VMware”) and their respective businesses (the “Separation”). VMware similarly agreed to indemnify Dell Technologies Inc., each of its subsidiaries and each of their respective directors, officers, and employees from and against all liabilities relating to, arising out of or resulting from, among other matters, the liabilities allocated to VMware as part of the Separation. The amounts that VMware and Dell Technologies may be obligated to pay each other could vary depending on the outcome of certain unresolved tax matters, which may not be resolved for several years. Net income tax indemnification receivables from VMware were immaterial as of October 31, 2025 and January 31, 2025.


## dell:CreditLossFinancialInstrumentLeasesDebtVariableInterestEntitiesAndCustomerReceivablesSalesTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2026-06-09):
[0001571996-26-000030:note_history:10]
To support financing solutions and services as part of the Dell Technologies portfolio, Dell Financial Services and its affiliates (“DFS”) originate, collect, and service customer financing arrangements primarily related to the purchase and use of Dell Technologies products and services. In some cases, the Company also offers financing for the purchase of third-party technology products that complement the portfolio of the Company’s products and services. New financing originations were $2.8 billion and $1.6 billion for the three months ended May 1, 2026 and May 2, 2025, respectively.
  (was, 2025-12-09, similarity 0.7614):
[0001571996-25-000127:note_history:10]
To support financing solutions and services as part of the Dell Technologies portfolio, Dell Financial Services and its affiliates (“DFS”) originates, collects, and services customer financing arrangements primarily related to the purchase and use of Dell Technologies products and services. In some cases, the Company also offers financing for the purchase of third-party technology products that complement the portfolio of products and services. New financing originations were $3.1 billion and $1.6 billion for the three months ended October 31, 2025 and November 1, 2024, respectively, and $7.1 billion and $5.9 billion for the nine months ended October 31, 2025 and November 1, 2024, respectively.

- changed (2026-06-09):
[0001571996-26-000030:note_history:11]
The Company’s financing arrangements with customers are aggregated as fixed-term leases and loans as described below.
  (was, 2025-12-09, similarity 0.959):
[0001571996-25-000127:note_history:11]
The Company’s financing arrangements with customers are aggregated primarily as fixed-term leases and loans as described below.

- changed (2026-06-09):
[0001571996-26-000030:note_history:12]
|  |  |  |  |  | May 1, 2026 |  |  |  |  |  | January 30, 2026 |
|  |  |  |  |  | (in millions) |
| Customer receivables, gross (a) |  |  |  |  | $ | 13,966 |  |  |  |  |  |  | $ | 14,295 |  |
| Allowance for losses |  |  |  |  | (212) |  |  |  |  |  |  | (213) |  |
| Customer receivables, net |  |  |  |  | 13,754 |  |  |  |  |  |  | 14,082 |  |
| Residual interest |  |  |  |  | 196 |  |  |  |  |  |  | 198 |  |
| Financing receivables, net |  |  |  |  | $ | 13,950 |  |  |  |  |  |  | $ | 14,280 |  |
| Short-term |  |  |  |  | $ | 8,237 |  |  |  |  |  |  | $ | 8,458 |  |
| Long-term |  |  |  |  | $ | 5,713 |  |  |  |  |  |  | $ | 5,822 |  |
  (was, 2025-12-09, similarity 0.8484):
[0001571996-25-000127:note_history:12]
|  |  |  |  |  | October 31, 2025 |  |  |  |  |  | January 31, 2025 |
|  |  |  |  |  | (in millions) |
| Financing receivables, net: |  |  |  |  |  |  |  |  |  |  |  |
| Customer receivables, gross (a) |  |  |  |  | $ | 13,143 |  |  |  |  |  |  | $ | 11,216 |  |
| Allowance for losses |  |  |  |  | (177) |  |  |  |  |  |  | (153) |  |
| Customer receivables, net |  |  |  |  | 12,966 |  |  |  |  |  |  | 11,063 |  |
| Residual interest |  |  |  |  | 186 |  |  |  |  |  |  | 168 |  |
| Financing receivables, net |  |  |  |  | $ | 13,152 |  |  |  |  |  |  | $ | 11,231 |  |
| Short-term |  |  |  |  | $ | 6,427 |  |  |  |  |  |  | $ | 5,304 |  |
| Long-term |  |  |  |  | $ | 6,725 |  |  |  |  |  |  | $ | 5,927 |  |

- changed (2026-06-09):
[0001571996-26-000030:note_history:13]
(a)Customer receivables, gross include amounts due from customers under fixed-term leases and loans and accrued interest.
  (was, 2025-12-09, similarity 0.7484):
[0001571996-25-000127:note_history:13]
(a)Customer receivables, gross include amounts due from customers under fixed-term leases, fixed-term loans, and accrued interest, as well as immaterial remaining amounts under the revolving loans.

- added (2026-06-09):
[0001571996-26-000030:note_history:14]
|  |  |  |  |  |  |  | Three Months Ended |
|  |  |  |  |  |  |  |  |  | May 1, 2026 |  |  |  |  |  | May 2, 2025 |  |  |
|  |  |  |  |  |  |  |  |  | (in millions) |
| Balances at beginning of period |  |  |  |  |  |  |  |  | $ | 213 |  |  |  |  |  |  | $ | 153 |  |  |  |  |  |  |  |
| Charge-offs, net of recoveries |  |  |  |  |  |  |  |  | (10) |  |  |  |  |  |  | (10) |  |  |  |  |  |  |  |
| Provision charged to income statement |  |  |  |  |  |  |  |  | 9 |  |  |  |  |  |  | 1 |  |  |  |  |  |  |  |
| Balances at end of period |  |  |  |  |  |  |  |  | $ | 212 |  |  |  |  |  |  | $ | 144 |  |  |  |  |  |  |  |

- changed (2026-06-09):
[0001571996-26-000030:note_history:15]
The Company recognizes an allowance for financing receivable losses, including both the lease receivable and unguaranteed residual, in an amount equal to the expected credit losses, net of recoveries. The allowance for financing receivable losses on the lease receivable is determined based on various factors, including lifetime expected losses determined using macroeconomic forecast assumptions and management judgments applicable to and through the expected life of the portfolios as well as past due receivables, receivable type, and customer risk profile. The Company continues to monitor broader economic indicators and their potential impact on future credit loss performance.
  (was, 2025-12-09, similarity 0.9949):
[0001571996-25-000127:note_history:15]
The Company recognizes an allowance for financing receivable losses, including both the lease receivable and unguaranteed residual, in an amount equal to the expected losses, net of recoveries. The allowance for financing receivable losses on the lease receivable is determined based on various factors, including lifetime expected losses determined using macroeconomic forecast assumptions and management judgments applicable to and through the expected life of the portfolios as well as past due receivables, receivable type, and customer risk profile. The Company continues to monitor broader economic indicators and their potential impact on future credit loss performance.

- changed (2026-06-09):
[0001571996-26-000030:note_history:16]
|  | May 1, 2026 |  | January 30, 2026 |
|  | (in millions) |
| Current 0 — 30 Days | $ | 13,723 |  |  | $ | 13,985 |  |
| Past Due 31 — 90 Days | 120 |  |  | 195 |  |
| Past Due > 90 Days | 123 |  |  | 115 |  |
| Total | $ | 13,966 |  |  | $ | 14,295 |  |
  (was, 2025-12-09, similarity 0.9752):
[0001571996-25-000127:note_history:16]
|  | October 31, 2025 |  | January 31, 2025 |
|  | (in millions) |
| Current 0 — 30 Days | $ | 12,802 |  |  | $ | 10,796 |  |
| Past Due 31 — 90 Days | 180 |  |  | 201 |  |
| Past Due > 90 Days | 161 |  |  | 219 |  |
| Total | $ | 13,143 |  |  | $ | 11,216 |  |

- changed (2026-06-09):
[0001571996-26-000030:note_history:17]
|  | May 1, 2026 |
|  | Fiscal Year of Origination |  |  |
|  | 2027 |  | 2026 |  | 2025 |  | 2024 |  | 2023 |  | Years Prior |  | Total |
|  | (in millions) |
| Higher | $ | 980 |  |  | $ | 2,378 |  |  | $ | 1,508 |  |  | $ | 1,185 |  |  | $ | 420 |  |  | $ | 54 |  |  | $ | 6,525 |  |
| Mid | 705 |  |  | 3,492 |  |  | 962 |  |  | 299 |  |  | 89 |  |  | 11 |  |  | 5,558 |  |
| Lower | 356 |  |  | 992 |  |  | 268 |  |  | 163 |  |  | 88 |  |  | 16 |  |  | 1,883 |  |
| Total | $ | 2,041 |  |  | $ | 6,862 |  |  | $ | 2,738 |  |  | $ | 1,647 |  |  | $ | 597 |  |  | $ | 81 |  |  | $ | 13,966 |  |
  (was, 2025-12-09, similarity 0.9887):
[0001571996-25-000127:note_history:17]
|  | October 31, 2025 |
|  | Fiscal Year of Origination |  |  |
|  | 2026 |  | 2025 |  | 2024 |  | 2023 |  | 2022 |  | Years Prior |  | Total |
|  | (in millions) |
| Higher | $ | 2,342 |  |  | $ | 1,832 |  |  | $ | 1,618 |  |  | $ | 679 |  |  | $ | 142 |  |  | $ | 27 |  |  | $ | 6,640 |  |
| Mid | 2,550 |  |  | 1,538 |  |  | 473 |  |  | 249 |  |  | 35 |  |  | 2 |  |  | 4,847 |  |
| Lower | 875 |  |  | 361 |  |  | 248 |  |  | 138 |  |  | 16 |  |  | 18 |  |  | 1,656 |  |
| Total | $ | 5,767 |  |  | $ | 3,731 |  |  | $ | 2,339 |  |  | $ | 1,066 |  |  | $ | 193 |  |  | $ | 47 |  |  | $ | 13,143 |  |

- changed (2026-06-09):
[0001571996-26-000030:note_history:18]
|  |  |  | Three Months Ended |
|  |  |  |  |  | May 1, 2026 |  | May 2, 2025 |  |  |
|  |  |  |  |  | (in millions) |
| Interest income — products |  |  |  |  | $ | 86 |  |  | $ | 93 |  |  |  |
| Net revenue — products |  |  |  |  | $ | 534 |  |  | $ | 119 |  |  |  |
| Cost of net revenue — products |  |  |  |  | 525 |  |  | 131 |  |  |  |
| Gross margin — products |  |  |  |  | $ | 9 |  |  | $ | (12) |  |  |  |
  (was, 2025-12-09, similarity 0.6751):
[0001571996-25-000127:note_history:18]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 31, 2025 |  | November 1, 2024 |  | October 31, 2025 |  | November 1, 2024 |  |  |
|  | (in millions) |
| Interest income — products | $ | 94 |  |  | $ | 82 |  |  | $ | 279 |  |  | $ | 221 |  |  |  |
| Net revenue — products | $ | 222 |  |  | $ | 401 |  |  | $ | 522 |  |  | $ | 1,751 |  |  |  |
| Cost of net revenue — products | 191 |  |  | 333 |  |  | 500 |  |  | 1,488 |  |  |  |
| Gross margin — products | $ | 31 |  |  | $ | 68 |  |  | $ | 22 |  |  | $ | 263 |  |  |  |

- changed (2026-06-09):
[0001571996-26-000030:note_history:19]
|  | May 1, 2026 |
|  | (in millions) |
| Fiscal 2027 (remaining nine months) | $ | 2,382 |  |
| Fiscal 2028 | 2,090 |  |
| Fiscal 2029 | 1,373 |  |
| Fiscal 2030 | 645 |  |
| Fiscal 2031 and thereafter | 328 |  |
| Total undiscounted cash flows | 6,818 |  |
| Loans | 8,337 |  |
| Less: Unearned income | (1,189) |  |
| Total customer receivables, gross | $ | 13,966 |  |
  (was, 2025-12-09, similarity 0.9567):
[0001571996-25-000127:note_history:19]
|  | October 31, 2025 |
|  | (in millions) |
| Fiscal 2026 (remaining three months) | $ | 956 |  |
| Fiscal 2027 | 2,832 |  |
| Fiscal 2028 | 1,484 |  |
| Fiscal 2029 | 879 |  |
| Fiscal 2030 and thereafter | 470 |  |
| Total undiscounted cash flows | 6,621 |  |
| Loans | 7,593 |  |
| Less: Unearned income | (1,071) |  |
| Total customer receivables, gross | $ | 13,143 |  |

- changed (2026-06-09):
[0001571996-26-000030:note_history:20]
|  | May 1, 2026 |  | January 30, 2026 |
|  | (in millions) |
| Equipment under operating lease, gross | $ | 4,946 |  |  | $ | 4,651 |  |
| Less: Accumulated depreciation | (2,215) |  |  | (2,192) |  |
| Equipment under operating lease, net | $ | 2,731 |  |  | $ | 2,459 |  |
  (was, 2025-12-09, similarity 0.9138):
[0001571996-25-000127:note_history:20]
|  | October 31, 2025 |  | January 31, 2025 |
|  | (in millions) |
| Equipment under operating lease, gross | $ | 4,529 |  |  | $ | 4,180 |  |
| Less: Accumulated depreciation | (2,179) |  |  | (1,995) |  |
| Equipment under operating lease, net | $ | 2,350 |  |  | $ | 2,185 |  |

- added (2026-06-09):
[0001571996-26-000030:note_history:21]
|  |  |  | Three Months Ended |
|  |  |  |  |  | May 1, 2026 |  | May 2, 2025 |  |  |
|  |  |  |  |  | (in millions) |
| Income related to lease payments |  |  |  |  | $ | 405 |  |  | $ | 358 |  |  |  |
| Depreciation expense |  |  |  |  | $ | 254 |  |  | $ | 244 |  |  |  |

- changed (2026-06-09):
[0001571996-26-000030:note_history:22]
|  | May 1, 2026 |
|  | (in millions) |
| Fiscal 2027 (remaining nine months) | $ | 1,111 |  |
| Fiscal 2028 | 1,118 |  |
| Fiscal 2029 | 711 |  |
| Fiscal 2030 | 240 |  |
| Fiscal 2031 and thereafter | 114 |  |
| Total | $ | 3,294 |  |
  (was, 2025-12-09, similarity 0.9561):
[0001571996-25-000127:note_history:22]
|  | October 31, 2025 |
|  | (in millions) |
| Fiscal 2026 (remaining three months) | $ | 362 |  |
| Fiscal 2027 | 1,171 |  |
| Fiscal 2028 | 726 |  |
| Fiscal 2029 | 357 |  |
| Fiscal 2030 and thereafter | 137 |  |
| Total | $ | 2,753 |  |

- added (2026-06-09):
[0001571996-26-000030:note_history:23]
|  | May 1, 2026 |  | January 30, 2026 |
|  | (in millions) |
| DFS U.S. debt: |  |  |  |
| Asset-based financing facility | $ | 2,901 |  |  | $ | 3,146 |  |
| Fixed-term securitization offerings | 3,033 |  |  | 2,648 |  |
| Total DFS U.S. debt, principal amount | 5,934 |  |  | 5,794 |  |
| DFS international debt: |  |  |  |
| Securitization facility | 656 |  |  | 698 |  |
| Other borrowings | 928 |  |  | 851 |  |
| Dell Bank senior unsecured eurobonds | 1,760 |  |  | 1,796 |  |
| Total DFS international debt, principal amount | 3,344 |  |  | 3,345 |  |
| Total DFS debt, principal amount | $ | 9,278 |  |  | $ | 9,139 |  |
| Short-term | $ | 5,775 |  |  | $ | 5,719 |  |
| Long-term | $ | 3,503 |  |  | $ | 3,420 |  |

- changed (2026-06-09):
[0001571996-26-000030:note_history:24]
Asset-Based Financing Facility — The Company maintains an asset-based financing facility in the United States, which is a revolving facility for fixed-term leases and loans. This debt is collateralized solely by the U.S. lease and loan payments and associated equipment in the facility. The asset-based financing facility consists of two tranches, with effective dates through July 7, 2026 and July 7, 2027, respectively. As of May 1, 2026, the total debt capacity related to the asset-based financing facility was $4.6 billion. The debt has a variable interest rate, and the duration of the debt is based on the terms of the underlying lease and loan payment streams. The Company enters into interest rate swap agreements to economically convert a portion of this debt from a floating rate to a fixed rate. See Note 7 of the Notes to the Condensed Consolidated Financial Statements for additional information about the Company’s interest rate swaps.
  (was, 2025-12-09, similarity 0.9947):
[0001571996-25-000127:note_history:24]
Asset-Based Financing Facility — The Company maintains an asset-based financing facility in the United States, which is a revolving facility for fixed-term leases and loans. This debt is collateralized solely by the U.S. lease and loan payments and associated equipment in the facility. The asset-based financing facility consists of two tranches, with effective dates through July 7, 2026 and July 7, 2027, respectively. As of October 31, 2025, the total debt capacity related to the asset-based financing facility was $4.6 billion. The debt has a variable interest rate, and the duration of the debt is based on the terms of the underlying lease and loan payment streams. The Company enters into interest rate swap agreements to economically convert a portion of this debt from a floating rate to a fixed rate. See Note 7 of the Notes to the Condensed Consolidated Financial Statements for additional information about the Company’s interest rate swaps.

- changed (2026-06-09):
[0001571996-26-000030:note_history:25]
The asset-based financing facility contains standard structural features related to the performance of the funded receivables, which include defined credit losses, delinquencies, average credit scores, and minimum collection requirements. In the event one or more of these criteria are not met and the Company is unable to restructure the facility, no further funding of receivables will be permitted and the timing of the Company’s expected cash flows from over-collateralization will be delayed. As of May 1, 2026, these criteria were met.
  (was, 2025-12-09, similarity 0.9907):
[0001571996-25-000127:note_history:25]
The asset-based financing facility contains standard structural features related to the performance of the funded receivables, which include defined credit losses, delinquencies, average credit scores, and minimum collection requirements. In the event one or more of these criteria are not met and the Company is unable to restructure the facility, no further funding of receivables will be permitted and the timing of the Company’s expected cash flows from over-collateralization will be delayed. As of October 31, 2025, these criteria were met.

- changed (2026-06-09):
[0001571996-26-000030:note_history:26]
Fixed-Term Securitization Offerings — The Company periodically issues asset-backed debt securities under fixed-term securitization programs to private investors. The asset-backed debt securities are collateralized solely by the U.S. fixed-term lease and loan payments and associated equipment, which are held by Special Purpose Entities (“SPEs”), as discussed below. The interest rate on these securities is fixed and ranges from 4.01% to 6.75% per annum as of May 1, 2026, and the duration of these securities is based on the terms of the underlying lease and loan payment streams.
  (was, 2025-12-09, similarity 0.9913):
[0001571996-25-000127:note_history:26]
Fixed-Term Securitization Offerings — The Company periodically issues asset-backed debt securities under fixed-term securitization programs to private investors. The asset-backed debt securities are collateralized solely by the U.S. fixed-term lease and loan payments and associated equipment, which are held by Special Purpose Entities (“SPEs”), as discussed below. The interest rate on these securities is fixed and ranges from 4.10% to 6.80% per annum as of October 31, 2025, and the duration of these securities is based on the terms of the underlying lease and loan payment streams.

- changed (2026-06-09):
[0001571996-26-000030:note_history:27]
Securitization Facility — The Company maintains a securitization facility in Europe for fixed-term leases and loans. The debt under this facility has a variable interest rate, and the duration of the debt is based on the terms of the underlying lease and loan payment streams. This facility is effective through December 22, 2026 and had a total debt capacity of $938 million as of May 1, 2026.
  (was, 2025-12-09, similarity 0.9766):
[0001571996-25-000127:note_history:27]
Securitization Facility — The Company maintains a securitization facility in Europe for fixed-term leases and loans. The debt under this facility has a variable interest rate, and the duration of the debt is based on the terms of the underlying lease and loan payment streams. This facility is effective through December 22, 2026 and had a total debt capacity of $925 million as of October 31, 2025.

- changed (2026-06-09):
[0001571996-26-000030:note_history:28]
The securitization facility contains standard structural features related to the performance of the securitized receivables, which include defined credit losses, delinquencies, average credit scores, and minimum collection requirements. In the event one or more of these criteria are not met and the Company is unable to restructure the program, no further funding of receivables will be permitted and the timing of the Company’s expected cash flows from over-collateralization will be delayed. As of May 1, 2026, these criteria were met.
  (was, 2025-12-09, similarity 0.9907):
[0001571996-25-000127:note_history:28]
The securitization facility contains standard structural features related to the performance of the securitized receivables, which include defined credit losses, delinquencies, average credit scores, and minimum collection requirements. In the event one or more of these criteria are not met and the Company is unable to restructure the program, no further funding of receivables will be permitted and the timing of the Company’s expected cash flows from over-collateralization will be delayed. As of October 31, 2025, these criteria were met.

- changed (2026-06-09):
[0001571996-26-000030:note_history:29]
Other Borrowings — In connection with the Company’s international financing operations, the Company has entered into revolving structured financing debt programs related to its fixed-term lease and loan products sold in Canada, Europe, the Middle East, Australia and New Zealand, and Singapore. The debt under these programs has a variable interest rate.
  (was, 2025-12-09, similarity 0.952):
[0001571996-25-000127:note_history:29]
Other Borrowings — In connection with the Company’s international financing operations, the Company has entered into revolving structured financing debt programs related to its fixed-term lease and loan products sold in Canada, Europe, Australia and New Zealand, the Middle East, and Singapore. The debt under these programs has a variable interest rate.

- added (2026-06-09):
[0001571996-26-000030:note_history:30]
The duration of the debt in Canada, Europe, the Middle East, and Australia and New Zealand is based on the terms of the underlying lease and loan payment streams. These facilities are collateralized solely by the lease and loan payments and associated equipment in their respective region or country.

- added (2026-06-09):
[0001571996-26-000030:note_history:31]
As of May 1, 2026,

- changed (2026-06-09):
[0001571996-26-000030:note_history:32]
•the Canadian facility had a total debt capacity of $258 million and is effective through January 15, 2028,
  (was, 2025-12-09, similarity 0.6406):
[0001571996-25-000127:note_history:32]
The Company also has two unsecured Singapore facilities, which had a total debt capacity of $254 million as of October 31, 2025 and are effective through July 3, 2026 and July 3, 2027, respectively.

- added (2026-06-09):
[0001571996-26-000030:note_history:33]
•the European facility had a total debt capacity of $469 million and is effective through December 14, 2026,

- added (2026-06-09):
[0001571996-26-000030:note_history:34]
•the Middle East facility had a total debt capacity of $150 million and is effective through March 14, 2028, and

- added (2026-06-09):
[0001571996-26-000030:note_history:35]
•the Australia and New Zealand facility had a total debt capacity of $306 million and is effective through April 17, 2027.

- added (2026-06-09):
[0001571996-26-000030:note_history:36]
The Company also has two unsecured Singapore facilities, which had a total debt capacity of $259 million as of May 1, 2026 and are effective through July 12, 2026 and July 3, 2027, respectively. Subsequent to the close of the three months ended May 1, 2026, the Company extended the term of the July 12, 2026 facility to be effective through July 12, 2027.

- changed (2026-06-09):
[0001571996-26-000030:note_history:37]
Dell Bank Senior Unsecured Eurobonds — On October 27, 2021, Dell Bank issued €500 million of 0.5% senior unsecured five-year eurobonds due October 2026. On October 18, 2022, Dell Bank issued €500 million of 4.5% senior unsecured five-year eurobonds due October 2027. On June 24, 2024, Dell Bank issued €500 million of 3.6% senior unsecured five-year eurobonds due June 2029. The issuances of the senior unsecured eurobonds support the expansion of the financing operations in Europe.
  (was, 2025-12-09, similarity 0.9799):
[0001571996-25-000127:note_history:37]
Dell Bank Senior Unsecured Eurobonds — On October 27, 2021, Dell Bank issued 500 million Euro of 0.5% senior unsecured five-year eurobonds due October 2026. On October 18, 2022, Dell Bank issued 500 million Euro of 4.5% senior unsecured five-year eurobonds due October 2027. On June 13, 2024, Dell Bank issued 500 million Euro of 3.6% senior unsecured five-year eurobonds due June 2029. The issuances of the senior unsecured eurobonds support the expansion of the financing operations in Europe.

- changed (2026-06-09):
[0001571996-26-000030:note_history:38]
|  | May 1, 2026 |  | January 30, 2026 |
|  | (in millions) |
| Assets held by consolidated VIEs: |  |  |  |
| Other current assets | $ | 174 |  |  | $ | 176 |  |
| Financing receivables, net of allowance: |  |  |  |
| Short-term | $ | 3,143 |  |  | $ | 3,280 |  |
| Long-term | $ | 2,945 |  |  | $ | 2,704 |  |
| Property, plant, and equipment, net | $ | 964 |  |  | $ | 984 |  |
| Liabilities held by consolidated VIEs: |  |  |  |
| Debt, net of unamortized debt issuance costs: |  |  |  |
| Short-term | $ | 4,373 |  |  | $ | 4,548 |  |
| Long-term | $ | 2,204 |  |  | $ | 1,933 |  |
  (was, 2025-12-09, similarity 0.6865):
[0001571996-25-000127:note_history:38]
|  | October 31, 2025 |  | January 31, 2025 |
|  | (in millions) |
| Assets held by consolidated VIEs |  |  |  |
| Other current assets | $ | 164 |  |  | $ | 123 |  |
| Financing receivables, net of allowance |  |  |  |
| Short-term | $ | 3,292 |  |  | $ | 3,262 |  |
| Long-term | $ | 2,726 |  |  | $ | 2,725 |  |
| Property, plant, and equipment, net | $ | 974 |  |  | $ | 984 |  |
| Liabilities held by consolidated VIEs |  |  |  |
| Debt, net of unamortized debt issuance costs |  |  |  |
| Short-term | $ | 4,069 |  |  | $ | 4,598 |  |
| Long-term | $ | 2,343 |  |  | $ | 1,788 |  |

- changed (2026-06-09):
[0001571996-26-000030:note_history:39]
Lease and loan payments and associated equipment transferred via securitization through SPEs were $1.3 billion and $1.2 billion for the three months ended May 1, 2026, and May 2, 2025, respectively.
  (was, 2025-12-09, similarity 0.6075):
[0001571996-25-000127:note_history:39]
Lease and loan payments and associated equipment transferred via securitization through SPEs were $1.0 billion for both the three months ended October 31, 2025 and November 1, 2024, and $3.0 billion for both the nine months ended October 31, 2025 and November 1, 2024.

- changed (2026-06-09):
[0001571996-26-000030:note_history:40]
To manage certain concentrations of customer credit exposure, the Company may sell selected fixed-term customer receivables to unrelated third parties on a periodic basis, without recourse. The amounts of customer receivables sold for this purpose were immaterial for both the three months ended May 1, 2026 and May 2, 2025. The Company’s continuing involvement in these customer receivables is primarily limited to servicing arrangements.
  (was, 2025-12-09, similarity 0.9332):
[0001571996-25-000127:note_history:40]
To manage certain concentrations of customer credit exposure, the Company may sell selected fixed-term customer receivables to unrelated third parties on a periodic basis, without recourse. The amounts of customer receivables sold for this purpose were immaterial for both the nine months ended October 31, 2025 and November 1, 2024. The Company’s continuing involvement in these customer receivables is primarily limited to servicing arrangements.

- removed (2026-06-09):
[0001571996-25-000127:note_history:41]
The Company historically offered revolving loans primarily to small and medium-sized commercial customers. During Fiscal 2025, the Company discontinued remaining offerings under the revolving loan portfolio. The Company continues to support existing customer arrangements as well as to transition these customers to fixed-term offerings. Due to the short-term nature of the revolving loan portfolio, in which transactions are typically repaid within twelve months on average, the portfolio had substantially transitioned to fixed-term offerings as of October 31, 2025.

- removed (2026-06-09):
[0001571996-25-000127:note_history:42]
|  | Three Months Ended |  |  |  |  |  | Nine Months Ended |
|  | October 31, 2025 |  | November 1, 2024 |  |  |  |  |  | October 31, 2025 |  |  |  |  |  | November 1, 2024 |  |  |
|  | (in millions) |  |  |  |  |  |  |
| Allowance for financing receivable losses: |
| Balances at beginning of period | $ | 151 |  |  | $ | 166 |  |  |  |  |  |  | $ | 153 |  |  |  |  |  |  | $ | 170 |  |  |  |  |  |  |  |
| Charge-offs, net of recoveries | (7) |  |  | (38) |  |  |  |  |  |  | (21) |  |  |  |  |  |  | (65) |  |  |  |  |  |  |  |
| Provision charged to income statement | 33 |  |  | 16 |  |  |  |  |  |  | 45 |  |  |  |  |  |  | 39 |  |  |  |  |  |  |  |
| Balances at end of period | $ | 177 |  |  | $ | 144 |  |  |  |  |  |  | $ | 177 |  |  |  |  |  |  | $ | 144 |  |  |  |  |  |  |  |

- removed (2026-06-09):
[0001571996-25-000127:note_history:43]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 31, 2025 |  | November 1, 2024 |  | October 31, 2025 |  | November 1, 2024 |  |  |
|  | (in millions) |
| Income related to lease payments | $ | 409 |  |  | $ | 372 |  |  | $ | 1,157 |  |  | $ | 1,090 |  |  |  |
| Depreciation expense | $ | 251 |  |  | $ | 247 |  |  | $ | 751 |  |  | $ | 732 |  |  |  |

- removed (2026-06-09):
[0001571996-25-000127:note_history:44]
|  | October 31, 2025 |  | January 31, 2025 |
| DFS debt | (in millions) |
| DFS U.S. debt: |  |  |  |
| Asset-based financing facility | $ | 2,508 |  |  | $ | 3,018 |  |
| Fixed-term securitization offerings | 3,252 |  |  | 2,756 |  |
| Total DFS U.S. debt, principal amount | 5,760 |  |  | 5,774 |  |
| DFS international debt: |  |  |  |
| Securitization facility | 667 |  |  | 624 |  |
| Other borrowings | 743 |  |  | 754 |  |
| Dell Bank senior unsecured eurobonds | 1,735 |  |  | 1,559 |  |
| Total DFS international debt, principal amount | 3,145 |  |  | 2,937 |  |
| Total DFS debt, principal amount | $ | 8,905 |  |  | $ | 8,711 |  |
| Total short-term DFS debt | $ | 5,130 |  |  | $ | 5,175 |  |
| Total long-term DFS debt | $ | 3,775 |  |  | $ | 3,536 |  |

- removed (2026-06-09):
[0001571996-25-000127:note_history:45]
The duration of the debt in Canada, Europe, Australia and New Zealand, and the Middle East is based on the terms of the underlying lease and loan payment streams. These facilities are collateralized solely by the lease and loan payments and associated equipment in their respective region or country. The Canadian facility had a total debt capacity of $250 million as of October 31, 2025 and is effective through January 15, 2028. The European facility had a total debt capacity of $463 million as of October 31, 2025 and is effective through December 14, 2026. The Australia and New Zealand facility had a total debt capacity of $279 million as of October 31, 2025 and is effective through April 17, 2027. The Middle East facility had a total debt capacity of $150 million as of October 31, 2025 and is effective through March 14, 2027.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2026-06-09):
[0001571996-26-000030:note_history:46]
|  | May 1, 2026 |  | January 30, 2026 |
|  | (in millions) |
| Senior Notes | $ | 21,073 |  |  | $ | 21,573 |  |
| Legacy Notes | 952 |  |  | 952 |  |
| DFS Debt (Note 4) | 9,278 |  |  | 9,139 |  |
| Other | 110 |  |  | 99 |  |
| Total debt, principal amount | 31,413 |  |  | 31,763 |  |
| Unamortized discount, net of unamortized premium | (109) |  |  | (112) |  |
| Debt issuance costs | (143) |  |  | (148) |  |
| Total debt, carrying value | $ | 31,161 |  |  | $ | 31,503 |  |
| Short-term | $ | 7,550 |  |  | $ | 7,990 |  |
| Long-term | $ | 23,611 |  |  | $ | 23,513 |  |

- added (2026-06-09):
[0001571996-26-000030:note_history:47]
During the three months ended May 1, 2026, the Company repaid the remaining outstanding $0.5 billion principal amount of 6.02% Senior Notes due June 2026.

- changed (2026-06-09):
[0001571996-26-000030:note_history:48]
Senior Notes — The Company completed offerings of multiple series of senior notes which were issued on June 1, 2016, March 20, 2019, April 9, 2020, December 13, 2021, January 24, 2023, March 18, 2024, October 8, 2024, April 1, 2025, and October 6, 2025 in aggregate principal amounts of $20.0 billion, $4.5 billion, $2.3 billion, $2.3 billion, $2.0 billion, $1.0 billion, $1.5 billion, $4.0 billion, and $4.5 billion, respectively (collectively, the “Senior Notes”). The Senior Notes have maturity dates ranging from 2026 through 2051. Interest rates on these borrowings are fixed, ranging from 3.38% to 8.35% per annum, and interest is payable semiannually.
  (was, 2025-12-09, similarity 0.7556):
[0001571996-25-000127:note_history:48]
Senior Notes — The Company completed offerings of multiple series of senior notes which were issued on June 1, 2016, June 22, 2016, March 20, 2019, April 9, 2020, December 13, 2021, January 24, 2023, March 18, 2024, October 8, 2024, April 1, 2025, and October 6, 2025 in aggregate principal amounts of $20.0 billion, $3.3 billion, $4.5 billion, $2.3 billion, $2.3 billion, $2.0 billion, $1.0 billion, $1.5 billion, $4.0 billion, and $4.5 billion, respectively (collectively, the “Senior Notes”). The Senior Notes currently outstanding have maturity dates ranging from 2026 through 2051. Interest rates on these borrowings are fixed, ranging from 3.38% to 8.35% per annum, and interest is payable semiannually.

- changed (2026-06-09):
[0001571996-26-000030:note_history:49]
Revolving Credit Facility — The Company’s revolving credit facility provides the Company with revolving commitments in an aggregate principal amount of $6.0 billion for general corporate purposes and includes a letter of credit sub-facility of up to $0.5 billion and a swing-line loan sub-facility of up to $0.5 billion. The revolving credit facility allows the Company to obtain incremental additional commitments on one or more occasions in minimum amounts of $10 million. The facility also acts as a backstop to provide liquidity support for the Company’s commercial paper program.
  (was, 2025-12-09, similarity 0.8904):
[0001571996-25-000127:note_history:49]
Revolving Credit Facility — The Company’s revolving credit facility provides the Company with revolving commitments in an aggregate principal amount of $6.0 billion for general corporate purposes and includes a letter of credit sub-facility of up to $0.5 billion and a swing-line loan sub-facility of up to $0.5 billion. The revolving credit facility also allows the Company to obtain incremental additional commitments on one or more occasions in minimum amounts of $10 million.

- changed (2026-06-09):
[0001571996-26-000030:note_history:50]
As of May 1, 2026, the Company had no outstanding borrowings under the revolving credit facility.
  (was, 2025-12-09, similarity 0.9468):
[0001571996-25-000127:note_history:50]
As of October 31, 2025, the Company had no outstanding borrowings under the revolving credit facility.

- changed (2026-06-09):
[0001571996-26-000030:note_history:51]
Commercial Paper Program — The Company maintains a commercial paper program under which the Company may issue unsecured notes in a maximum aggregate face amount of $5.0 billion outstanding at any time, with maturities of up to 397 days from the date of issuance. The notes are sold on customary terms in the U.S. commercial paper market on a private placement basis. The proceeds of the notes are used for general corporate purposes. As of May 1, 2026, the Company had no outstanding issuances under the commercial paper program.
  (was, 2025-12-09, similarity 0.9904):
[0001571996-25-000127:note_history:51]
Commercial Paper Program — The Company maintains a commercial paper program under which the Company may issue unsecured notes in a maximum aggregate face amount of $5.0 billion outstanding at any time, with maturities of up to 397 days from the date of issuance. The notes are sold on customary terms in the U.S. commercial paper market on a private placement basis. The proceeds of the notes are used for general corporate purposes. As of October 31, 2025, the Company had no outstanding issuances under the commercial paper program.

- changed (2026-06-09):
[0001571996-26-000030:note_history:52]
Covenants — The credit agreement governing the revolving credit facility and the indentures governing the Senior Notes and the Legacy Notes impose various limitations, subject to exceptions, on creating certain liens and entering into sale and lease-back transactions. The foregoing credit agreement and indentures contain customary events of default, and the revolving credit facility is subject to an interest coverage ratio covenant that is tested at the end of each fiscal quarter with respect to the Company’s preceding four fiscal quarters. The Company was in compliance with this financial covenant as of May 1, 2026.
  (was, 2025-12-09, similarity 0.9919):
[0001571996-25-000127:note_history:52]
Covenants — The credit agreement governing the revolving credit facility and the indentures governing the Senior Notes and the Legacy Notes impose various limitations, subject to exceptions, on creating certain liens and entering into sale and lease-back transactions. The foregoing credit agreement and indentures contain customary events of default, and the revolving credit facility is subject to an interest coverage ratio covenant that is tested at the end of each fiscal quarter with respect to the Company’s preceding four fiscal quarters. The Company was in compliance with this financial covenant as of October 31, 2025.

- changed (2026-06-09):
[0001571996-26-000030:note_history:53]
The following table presents the aggregate future maturities of the Company’s debt as of May 1, 2026, excluding associated carrying value adjustments, for the periods indicated:
  (was, 2025-12-09, similarity 0.9713):
[0001571996-25-000127:note_history:53]
The following table presents the aggregate future maturities of the Company’s debt as of October 31, 2025, excluding associated carrying value adjustments, for the periods indicated:

- changed (2026-06-09):
[0001571996-26-000030:note_history:54]
|  | May 1, 2026 |
|  | (in millions) |
| Fiscal 2027 (remaining nine months) | $ | 6,910 |  |
| Fiscal 2028 | 3,368 |  |
| Fiscal 2029 | 2,864 |  |
| Fiscal 2030 | 3,957 |  |
| Fiscal 2031 | 1,773 |  |
| Thereafter | 12,541 |  |
| Total maturities, principal amount | $ | 31,413 |  |
  (was, 2025-12-09, similarity 0.9409):
[0001571996-25-000127:note_history:54]
|  | October 31, 2025 |
|  | (in millions) |
| Fiscal 2026 (remaining three months) | $ | 1,307 |  |
| Fiscal 2027 | 6,819 |  |
| Fiscal 2028 | 2,621 |  |
| Fiscal 2029 | 2,613 |  |
| Fiscal 2030 | 3,855 |  |
| Thereafter | 14,300 |  |
| Total maturities, principal amount | $ | 31,515 |  |

- removed (2026-06-09):
[0001571996-25-000127:note_history:55]
|  | October 31, 2025 |  | January 31, 2025 |
|  | (in millions) |
| Senior Notes | $ | 21,573 |  |  | $ | 15,073 |  |
| Legacy Notes | 952 |  |  | 952 |  |
| DFS Debt (Note 4) | 8,905 |  |  | 8,711 |  |
| Other | 85 |  |  | 52 |  |
| Total debt, principal amount | 31,515 |  |  | 24,788 |  |
| Unamortized discount, net of unamortized premium | (115) |  |  | (110) |  |
| Debt issuance costs | (157) |  |  | (111) |  |
| Total debt, carrying value | $ | 31,243 |  |  | $ | 24,567 |  |
| Total short-term debt, carrying value | $ | 7,394 |  |  | $ | 5,204 |  |
| Total long-term debt, carrying value | $ | 23,849 |  |  | $ | 19,363 |  |

- removed (2026-06-09):
[0001571996-25-000127:note_history:56]
The Company completed the following transactions during the nine months ended October 31, 2025:

- removed (2026-06-09):
[0001571996-25-000127:note_history:57]
•the issuance of $1.0 billion principal amount of 4.75% Senior Notes due April 2028, $1.0 billion principal amount of 5.00% Senior Notes due April 2030, $1.0 billion principal amount of 5.30% Senior Notes due April 2032, and $1.0 billion principal amount of 5.50% Senior Notes due April 2035, the proceeds of which were utilized for general corporate purposes; and

- removed (2026-06-09):
[0001571996-25-000127:note_history:58]
•the issuance of $0.75 billion principal amount of 4.15% Senior Notes due February 2029, $1.25 billion principal amount of 4.50% Senior Notes due February 2031, $1.25 billion principal amount of 4.75% Senior Notes due October 2032, and $1.25 billion principal amount of 5.10% Senior Notes due February 2036, the proceeds of which were utilized for general corporate purposes and to prepay a portion of the outstanding 6.02% Senior Notes due June 2026.


## us-gaap:ScheduleOfCarryingValuesAndEstimatedFairValuesOfDebtInstrumentsTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2026-06-09):
[0001571996-26-000030:note_history:59]
The following table presents the carrying value and estimated fair value of the Company’s outstanding debt as described in Note 6 of the Notes to the Condensed Consolidated Financial Statements, including the current portion, as of the dates indicated:
  (was, 2025-12-09, similarity 0.8905):
[0001571996-25-000127:note_history:59]
Carrying Value and Estimated Fair Value of Outstanding Debt — The following table presents the carrying value and estimated fair value of the Company’s outstanding debt as described in Note 6 of the Notes to the Condensed Consolidated Financial Statements, including the current portion, as of the dates indicated:

- changed (2026-06-09):
[0001571996-26-000030:note_history:60]
|  | May 1, 2026 |  | January 30, 2026 |
|  | Carrying Value |  | Fair Value |  | Carrying Value |  | Fair Value |
|  | (in billions) |
| Senior Notes | $ | 20.9 |  |  | $ | 21.1 |  |  | $ | 21.4 |  |  | $ | 21.8 |  |
| Legacy Notes | $ | 0.9 |  |  | $ | 1.0 |  |  | $ | 0.9 |  |  | $ | 1.0 |  |
| DFS Debt | $ | 9.3 |  |  | $ | 9.1 |  |  | $ | 9.1 |  |  | $ | 8.9 |  |
  (was, 2025-12-09, similarity 0.9837):
[0001571996-25-000127:note_history:60]
|  | October 31, 2025 |  | January 31, 2025 |
|  | Carrying Value |  | Fair Value |  | Carrying Value |  | Fair Value |
|  | (in billions) |
| Senior Notes | $ | 21.4 |  |  | $ | 21.9 |  |  | $ | 15.0 |  |  | $ | 15.0 |  |
| Legacy Notes | $ | 0.9 |  |  | $ | 1.0 |  |  | $ | 0.9 |  |  | $ | 1.0 |  |
| DFS Debt | $ | 8.9 |  |  | $ | 8.6 |  |  | $ | 8.7 |  |  | $ | 8.5 |  |


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2026-06-09):
[0001571996-26-000030:note_history:61]
|  | May 1, 2026 |  | January 30, 2026 |
|  | (in millions) |
| DFS U.S. debt: |  |  |  |
| Asset-based financing facility | $ | 2,901 |  |  | $ | 3,146 |  |
| Fixed-term securitization offerings | 3,033 |  |  | 2,648 |  |
| Total DFS U.S. debt, principal amount | 5,934 |  |  | 5,794 |  |
| DFS international debt: |  |  |  |
| Securitization facility | 656 |  |  | 698 |  |
| Other borrowings | 928 |  |  | 851 |  |
| Dell Bank senior unsecured eurobonds | 1,760 |  |  | 1,796 |  |
| Total DFS international debt, principal amount | 3,344 |  |  | 3,345 |  |
| Total DFS debt, principal amount | $ | 9,278 |  |  | $ | 9,139 |  |
| Short-term | $ | 5,775 |  |  | $ | 5,719 |  |
| Long-term | $ | 3,503 |  |  | $ | 3,420 |  |

- added (2026-06-09):
[0001571996-26-000030:note_history:62]
|  | May 1, 2026 |  | January 30, 2026 |
|  | (in millions) |
| Senior Notes | $ | 21,073 |  |  | $ | 21,573 |  |
| Legacy Notes | 952 |  |  | 952 |  |
| DFS Debt (Note 4) | 9,278 |  |  | 9,139 |  |
| Other | 110 |  |  | 99 |  |
| Total debt, principal amount | 31,413 |  |  | 31,763 |  |
| Unamortized discount, net of unamortized premium | (109) |  |  | (112) |  |
| Debt issuance costs | (143) |  |  | (148) |  |
| Total debt, carrying value | $ | 31,161 |  |  | $ | 31,503 |  |
| Short-term | $ | 7,550 |  |  | $ | 7,990 |  |
| Long-term | $ | 23,611 |  |  | $ | 23,513 |  |

- removed (2026-06-09):
[0001571996-25-000127:note_history:63]
|  | October 31, 2025 |  | January 31, 2025 |
| DFS debt | (in millions) |
| DFS U.S. debt: |  |  |  |
| Asset-based financing facility | $ | 2,508 |  |  | $ | 3,018 |  |
| Fixed-term securitization offerings | 3,252 |  |  | 2,756 |  |
| Total DFS U.S. debt, principal amount | 5,760 |  |  | 5,774 |  |
| DFS international debt: |  |  |  |
| Securitization facility | 667 |  |  | 624 |  |
| Other borrowings | 743 |  |  | 754 |  |
| Dell Bank senior unsecured eurobonds | 1,735 |  |  | 1,559 |  |
| Total DFS international debt, principal amount | 3,145 |  |  | 2,937 |  |
| Total DFS debt, principal amount | $ | 8,905 |  |  | $ | 8,711 |  |
| Total short-term DFS debt | $ | 5,130 |  |  | $ | 5,175 |  |
| Total long-term DFS debt | $ | 3,775 |  |  | $ | 3,536 |  |

- removed (2026-06-09):
[0001571996-25-000127:note_history:64]
|  | October 31, 2025 |  | January 31, 2025 |
|  | (in millions) |
| Senior Notes | $ | 21,573 |  |  | $ | 15,073 |  |
| Legacy Notes | 952 |  |  | 952 |  |
| DFS Debt (Note 4) | 8,905 |  |  | 8,711 |  |
| Other | 85 |  |  | 52 |  |
| Total debt, principal amount | 31,515 |  |  | 24,788 |  |
| Unamortized discount, net of unamortized premium | (115) |  |  | (110) |  |
| Debt issuance costs | (157) |  |  | (111) |  |
| Total debt, carrying value | $ | 31,243 |  |  | $ | 24,567 |  |
| Total short-term debt, carrying value | $ | 7,394 |  |  | $ | 5,204 |  |
| Total long-term debt, carrying value | $ | 23,849 |  |  | $ | 19,363 |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2026-06-09):
[0001571996-26-000030:note_history:65]
The following table presents the aggregate future maturities of the Company’s debt as of May 1, 2026, excluding associated carrying value adjustments, for the periods indicated:
  (was, 2025-12-09, similarity 0.9713):
[0001571996-25-000127:note_history:65]
The following table presents the aggregate future maturities of the Company’s debt as of October 31, 2025, excluding associated carrying value adjustments, for the periods indicated:

- changed (2026-06-09):
[0001571996-26-000030:note_history:66]
|  | May 1, 2026 |
|  | (in millions) |
| Fiscal 2027 (remaining nine months) | $ | 6,910 |  |
| Fiscal 2028 | 3,368 |  |
| Fiscal 2029 | 2,864 |  |
| Fiscal 2030 | 3,957 |  |
| Fiscal 2031 | 1,773 |  |
| Thereafter | 12,541 |  |
| Total maturities, principal amount | $ | 31,413 |  |
  (was, 2025-12-09, similarity 0.9409):
[0001571996-25-000127:note_history:66]
|  | October 31, 2025 |
|  | (in millions) |
| Fiscal 2026 (remaining three months) | $ | 1,307 |  |
| Fiscal 2027 | 6,819 |  |
| Fiscal 2028 | 2,621 |  |
| Fiscal 2029 | 2,613 |  |
| Fiscal 2030 | 3,855 |  |
| Thereafter | 14,300 |  |
| Total maturities, principal amount | $ | 31,515 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2026-06-09):
[0001571996-26-000030:note_history:67]
|  |  |  | Three Months Ended |
|  |  |  |  |  | May 1, 2026 |  | May 2, 2025 |  |  |
|  |  |  |  |  | (in millions) |
| Net revenue: |  |  |  |  |  |  |  |  |  |
| Infrastructure Solutions Group: |  |  |  |  |  |  |  |  |  |
| AI-optimized servers |  |  |  |  | $ | 16,132 |  |  | $ | 1,882 |  |  |  |
| Traditional servers and networking |  |  |  |  | 8,543 |  |  | 4,439 |  |  |  |
| Storage |  |  |  |  | 4,334 |  |  | 3,996 |  |  |  |
| Total ISG net revenue |  |  |  |  | $ | 29,009 |  |  | $ | 10,317 |  |  |  |
| Client Solutions Group: |  |  |  |  |  |  |  |  |  |
| Commercial |  |  |  |  | $ | 13,020 |  |  | $ | 11,046 |  |  |  |
| Consumer |  |  |  |  | 1,589 |  |  | 1,463 |  |  |  |
| Total CSG net revenue |  |  |  |  | $ | 14,609 |  |  | $ | 12,509 |  |  |  |
  (was, 2025-12-09, similarity 0.6068):
[0001571996-25-000127:note_history:67]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 31, 2025 |  | November 1, 2024 |  | October 31, 2025 |  | November 1, 2024 |  |  |
|  | (in millions) |
| Net revenue: |  |  |  |  |  |  |  |  |  |
| Infrastructure Solutions Group: |  |  |  |  |  |  |  |  |  |
| Servers and networking | $ | 10,125 |  |  | $ | 7,364 |  |  | $ | 29,390 |  |  | $ | 20,502 |  |  |  |
| Storage | 3,982 |  |  | 4,004 |  |  | 11,834 |  |  | 11,739 |  |  |  |
| Total ISG net revenue | $ | 14,107 |  |  | $ | 11,368 |  |  | $ | 41,224 |  |  | $ | 32,241 |  |  |  |
| Client Solutions Group: |  |  |  |  |  |  |  |  |  |
| Commercial | $ | 10,621 |  |  | $ | 10,138 |  |  | $ | 32,448 |  |  | $ | 30,848 |  |  |  |
| Consumer | 1,857 |  |  | 1,993 |  |  | 5,042 |  |  | 5,664 |  |  |  |
| Total CSG net revenue | $ | 12,478 |  |  | $ | 12,131 |  |  | $ | 37,490 |  |  | $ | 36,512 |  |  |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2026-06-09):
[0001571996-26-000030:note_history:68]
DEFERRED REVENUE 
Deferred revenue consists of support and deployment services, software maintenance, training, software-as-a-service, and undelivered hardware and professional services, consisting of installations and consulting engagements. Deferred revenue is recorded when the Company has invoiced or payments have been received for undelivered products or services, or in situations where revenue recognition criteria have not been met. Revenue is recognized as the Company’s performance obligations under the contract are completed.
  (was, 2025-12-09, similarity 0.9044):
[0001571996-25-000127:note_history:68]
DEFERRED REVENUE 
Deferred revenue consists of support and deployment services, software maintenance, training, software-as-a-service, and undelivered hardware and professional services, consisting of installations and consulting engagements. Deferred revenue is recorded when the Company has invoiced or payments have been received for undelivered products or services where transfer of control has not occurred. Revenue is recognized as the Company’s performance obligations under the contract are completed.

- changed (2026-06-09):
[0001571996-26-000030:note_history:69]
|  |  |  | Three Months Ended |
|  |  |  |  |  | May 1, 2026 |  | May 2, 2025 |
|  |  |  |  |  | (in millions) |
| Deferred revenue at beginning of period |  |  |  |  | $ | 26,930 |  |  | $ | 25,965 |  |
| Revenue deferrals |  |  |  |  | 5,540 |  |  | 5,455 |  |
| Revenue recognized |  |  |  |  | (5,018) |  |  | (5,100) |  |
| Deferred revenue at end of period |  |  |  |  | $ | 27,452 |  |  | $ | 26,320 |  |
| Short-term |  |  |  |  | $ | 13,193 |  |  | $ | 13,907 |  |
| Long-term |  |  |  |  | $ | 14,259 |  |  | $ | 12,413 |  |
  (was, 2025-12-09, similarity 0.6108):
[0001571996-25-000127:note_history:69]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 31, 2025 |  | November 1, 2024 |  | October 31, 2025 |  | November 1, 2024 |
|  | (in millions) |
| Deferred revenue: |  |  |  |  |  |  |  |
| Deferred revenue at beginning of period | $ | 26,181 |  |  | $ | 27,712 |  |  | $ | 25,965 |  |  | $ | 29,145 |  |
| Revenue deferrals | 3,944 |  |  | 3,897 |  |  | 14,371 |  |  | 13,286 |  |
| Revenue recognized | (5,017) |  |  | (5,262) |  |  | (15,228) |  |  | (16,084) |  |
| Other (a) | — |  |  | (136) |  |  | — |  |  | (136) |  |
| Deferred revenue at end of period | $ | 25,108 |  |  | $ | 26,211 |  |  | $ | 25,108 |  |  | $ | 26,211 |  |
| Short-term deferred revenue | $ | 12,649 |  |  | $ | 13,787 |  |  | $ | 12,649 |  |  | $ | 13,787 |  |
| Long-term deferred revenue | $ | 12,459 |  |  | $ | 12,424 |  |  | $ | 12,459 |  |  | $ | 12,424 |  |

- added (2026-06-09):
[0001571996-26-000030:note_history:70]
Remaining Performance Obligations

- changed (2026-06-09):
[0001571996-26-000030:note_history:71]
Remaining performance obligations represent the aggregate amount of the transaction price allocated to performance obligations not delivered, or partially undelivered, as of the end of the reporting period. Remaining performance obligations include deferred revenue plus unbilled amounts not yet recorded in deferred revenue. The value of the transaction price allocated to remaining performance obligations as of May 1, 2026 was approximately $97 billion. The Company expects to recognize approximately 80% of remaining performance obligations as revenue in the next twelve months, approximately 10% in the following twelve months, and the remainder thereafter.
  (was, 2025-12-09, similarity 0.9551):
[0001571996-25-000127:note_history:71]
Remaining Performance Obligations — Remaining performance obligations represent the aggregate amount of the transaction price allocated to performance obligations not delivered, or partially undelivered, as of the end of the reporting period. Remaining performance obligations include deferred revenue plus unbilled amounts not yet recorded in deferred revenue. The value of the transaction price allocated to remaining performance obligations as of October 31, 2025 was approximately $51 billion. The Company expects to recognize approximately 67% of remaining performance obligations as revenue in the next twelve months, 16% in the following twelve months, and the remainder thereafter.

- removed (2026-06-09):
[0001571996-25-000127:note_history:72]
____________________

- removed (2026-06-09):
[0001571996-25-000127:note_history:73]
(a) For the three and nine months ended November 1, 2024, Other represents the reclassification of Secureworks deferred revenue to liabilities held for sale. See Note 1 of the Notes to the Condensed Consolidated Financial Statements for more information about the sale of Secureworks


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- changed (2026-06-09):
[0001571996-26-000030:note_history:74]
SUBSEQUENT EVENTS 
There were no known events occurring after May 1, 2026 and up until the date of issuance of this report that would materially affect the information presented herein.
  (was, 2025-12-09, similarity 0.9725):
[0001571996-25-000127:note_history:74]
SUBSEQUENT EVENTS 
There were no known events occurring after October 31, 2025 and up until the date of issuance of this report that would materially affect the information presented herein.
