# DELL 8-K — 0001571996-26-000021 filed 2026-05-28

## item codes, every 8-K on or before 2026-06-09

- 2026-05-28 0001571996-26-000021 — 2.02, 9.01
- 2026-04-20 0001571996-26-000013 — 3.02
- 2026-02-26 0001571996-26-000003 — 2.02, 9.01
- 2025-11-25 0001571996-25-000120 — 5.02 — amendment of 0001571996-25-000104
- 2025-11-25 0001571996-25-000118 — 2.02, 9.01
- 2025-10-17 0001571996-25-000114 — 5.02 — amendment of 0001571996-25-000093
- 2025-10-07 0001193125-25-232662 — 7.01, 9.01
- 2025-10-06 0001193125-25-231904 — 1.01, 2.03, 9.01
- 2025-10-02 0001571996-25-000112 — 5.02 — amendment of 0001571996-25-000104
- 2025-10-02 0001571996-25-000111 — 5.02, 9.01
- 2025-09-26 0001571996-25-000107 — 3.02
- 2025-09-23 0001193125-25-213629 — 8.01, 9.01
- 2025-09-08 0001571996-25-000104 — 5.02
- 2025-08-28 0001571996-25-000096 — 2.02, 9.01
- 2025-08-12 0001571996-25-000093 — 5.02
- 2025-07-16 0001571996-25-000081 — 3.02
- 2025-07-01 0001571996-25-000078 — 5.07
- 2025-05-29 0001571996-25-000046 — 2.02, 9.01
- 2025-04-01 0001193125-25-070461 — 1.01, 2.03, 9.01
- 2025-03-27 0001193125-25-065594 — 8.01, 9.01
- 2025-02-27 0001571996-25-000014 — 2.02, 8.01, 9.01
- 2025-01-14 0001571996-25-000004 — 3.02
- 2024-12-03 0001571996-24-000136 — 3.02
- 2024-11-26 0001571996-24-000130 — 2.02, 9.01
- 2024-10-08 0001193125-24-234446 — 1.01, 2.03, 9.01
- 2024-10-02 0001193125-24-231195 — 8.01, 9.01
- 2024-09-19 0001571996-24-000105 — 3.02
- 2024-08-29 0001571996-24-000081 — 2.02, 9.01
- 2024-07-12 0001193125-24-178608 — 3.02
- 2024-07-02 0001571996-24-000074 — 5.07
- 2024-06-10 0001571996-24-000059 — 3.02
- 2024-05-30 0001571996-24-000050 — 2.02, 9.01
- 2024-03-26 0001571996-24-000038 — 3.02
- 2024-03-18 0001193125-24-070193 — 1.01, 2.03, 9.01
- 2024-03-07 0001571996-24-000012 — 3.02
- 2024-03-06 0001193125-24-059631 — 8.01, 9.01
- 2024-02-29 0001571996-24-000008 — 2.02, 9.01
- 2024-01-30 0001571996-24-000004 — 1.02
- 2024-01-18 0001571996-24-000002 — 3.02
- 2023-12-18 0001193125-23-297664 — 8.01, 9.01
- 2023-12-05 0001571996-23-000042 — 3.02
- 2023-12-04 0001193125-23-288428 — 8.01, 9.01
- 2023-11-30 0001571996-23-000039 — 2.02, 9.01
- 2023-10-05 0001193125-23-251131 — 7.01, 8.01, 9.01
- 2023-10-02 0001571996-23-000036 — 5.02 — amendment of 0001571996-23-000034
- 2023-09-26 0001571996-23-000034 — 5.02
- 2023-08-31 0001571996-23-000029 — 2.02, 9.01
- 2023-08-09 0001571996-23-000026 — 5.02 — amendment of 0001571996-23-000002
- 2023-07-28 0001571996-23-000024 — 5.02
- 2023-07-13 0001193125-23-186639 — 3.02
- 2023-06-30 0001193125-23-180570 — 8.01, 9.01
- 2023-06-22 0001571996-23-000021 — 5.02, 5.07, 9.01
- 2023-06-15 0001193125-23-167472 — 8.01, 9.01
- 2023-06-01 0001571996-23-000014 — 2.02, 9.01
- 2023-03-02 0001571996-23-000002 — 2.02, 5.02, 9.01
- 2023-02-06 0001193125-23-024781 — 7.01, 9.01
- 2023-01-24 0001193125-23-014260 — 1.01, 2.03, 9.01
- 2023-01-11 0001193125-23-006528 — 8.01, 9.01
- 2022-11-21 0001571996-22-000041 — 2.02, 9.01
- 2022-11-16 0001571996-22-000038 — 8.01
- 2022-08-25 0001571996-22-000028 — 2.02, 9.01
- 2022-07-18 0001193125-22-196334 — 2.03, 8.01
- 2022-06-29 0001571996-22-000025 — 3.03, 5.03, 5.07, 8.01, 9.01
- 2022-05-26 0001571996-22-000013 — 2.02, 9.01
- 2022-02-24 0001571996-22-000004 — 2.02, 8.01, 9.01
- 2021-12-20 0001193125-21-362482 — 8.01, 9.01
- 2021-12-15 0001193125-21-357927 — 1.01, 2.03, 9.01
- 2021-12-07 0001193125-21-349218 — 8.01, 9.01
- 2021-11-23 0001571996-21-000060 — 2.02, 9.01
- 2021-11-05 0001571996-21-000057 — 1.02, 2.01, 7.01, 8.01, 9.01 — amendment, the index does not say of what
- 2021-11-01 0001571996-21-000052 — 8.01, 9.01
- 2021-11-01 0001193125-21-315488 — 1.01, 1.02, 2.01, 8.01, 9.01
- 2021-10-21 0001193125-21-304052 — 8.01, 9.01
- 2021-10-19 0001571996-21-000050 — 8.01, 9.01
- 2021-10-07 0001193125-21-294210 — 8.01, 9.01
- 2021-09-30 0001571996-21-000047 — 5.02
- 2021-09-27 0001571996-21-000045 — 8.01
- 2021-09-23 0001193125-21-280190 — 7.01, 8.01, 9.01
- 2021-09-20 0001193125-21-276810 — 7.01, 9.01
- 2021-08-26 0001571996-21-000037 — 2.02, 9.01
- 2021-07-01 0001571996-21-000034 — 3.02
- 2021-06-24 0001571996-21-000031 — 5.07
- 2021-06-24 0001193125-21-197644 — 7.01, 9.01
- 2021-06-16 0001571996-21-000029 — 5.02
- 2021-05-27 0001571996-21-000019 — 2.02, 9.01
- 2021-05-03 0001571996-21-000010 — 8.01, 9.01
- 2021-04-14 0001193125-21-116271 — 1.01, 7.01, 9.01
- 2021-02-25 0001571996-21-000003 — 2.02, 9.01
- 2021-02-18 0001193125-21-047844 — 1.01, 2.03, 9.01
- 2020-11-24 0001571996-20-000048 — 2.02, 9.01
- 2020-08-27 0001571996-20-000041 — 2.02, 9.01
- 2020-07-02 0001571996-20-000037 — 5.07
- 2020-05-28 0001571996-20-000028 — 2.02, 9.01
- 2020-04-09 0001193125-20-102602 — 1.01, 2.03, 9.01
- 2020-04-08 0001571996-20-000021 — 5.02
- 2020-04-03 0001571996-20-000019 — 8.01, 9.01
- 2020-03-26 0001571996-20-000015 — 7.01
- 2020-02-27 0001571996-20-000009 — 2.02, 8.01, 9.01
- 2020-02-18 0001571996-20-000005 — 8.01, 9.01
- 2020-01-09 0001571996-20-000002 — 3.02
- 2020-01-06 0001193125-20-002200 — 3.02
- 2019-12-13 0001193125-19-313947 — 3.02
- 2019-12-10 0001571996-19-000052 — 5.02
- 2019-12-02 0001571996-19-000044 — 5.02, 7.01, 9.01
- 2019-11-26 0001571996-19-000042 — 2.02, 9.01
- 2019-09-23 0001193125-19-252192 — 1.01, 2.03, 9.01
- 2019-08-29 0001571996-19-000036 — 2.02, 9.01
- 2019-08-22 0001193125-19-226939 — 7.01, 8.01, 9.01
- 2019-07-11 0001571996-19-000032 — 5.02, 5.07, 9.01
- 2019-07-03 0001571996-19-000030 — 3.02
- 2019-06-27 0001571996-19-000028 — 3.02
- 2019-05-30 0001571996-19-000021 — 2.02, 9.01
- 2019-04-02 0001571996-19-000010 — 5.02
- 2019-03-21 0001193125-19-082281 — 1.01, 1.02, 2.03, 9.01
- 2019-03-19 0001571996-19-000005 — 5.02, 9.01
- 2019-03-14 0001193125-19-074935 — 1.01, 2.03, 9.01
- 2019-03-07 0001193125-19-066045 — 8.01, 9.01
- 2019-02-28 0001571996-19-000002 — 2.02, 9.01
- 2018-12-28 0001193125-18-360943 — 1.01, 1.02, 3.01, 3.03, 5.02, 5.03, 7.01, 8.01, 9.01
- 2018-12-21 0001193125-18-356324 — 1.01, 2.03, 9.01
- 2018-12-14 0001193125-18-349469 — 8.01
- 2018-12-11 0001193125-18-346958 — 5.07, 8.01, 9.01
- 2018-11-29 0001571996-18-000041 — 2.02, 9.01
- 2018-11-28 0001571996-18-000037 — 7.01, 8.01, 9.01
- 2018-11-26 0001193125-18-333967 — 8.01, 9.01
- 2018-11-15 0001193125-18-328110 — 1.01, 9.01 — amendment of 0001193125-18-327222
- 2018-11-15 0001193125-18-327222 — 1.01, 7.01, 9.01
- 2018-10-03 0001193125-18-291390 — 8.01
- 2018-09-06 0001571996-18-000029 — 2.02, 9.01
- 2018-08-06 0001571996-18-000027 — 8.01, 9.01
- 2018-07-02 0001193125-18-210339 — 1.01, 7.01, 9.01
- 2018-06-28 0001571996-18-000024 — 5.07
- 2018-06-04 0001571996-18-000019 — 2.02, 9.01
- 2018-05-17 0001571996-18-000016 — 7.01
- 2018-04-26 0001571996-18-000009 — 7.01, 9.01
- 2018-03-08 0001193125-18-074168 — 2.02, 9.01
- 2018-02-02 0001193125-18-029947 — 7.01, 9.01
- 2017-12-07 0001571996-17-000042 — 2.02, 9.01
- 2017-10-24 0001571996-17-000037 — 1.01, 2.03, 9.01
- 2017-09-15 0001571996-17-000027 — 5.02
- 2017-09-07 0001571996-17-000017 — 2.02, 9.01
- 2017-08-24 0001571996-17-000014 — 8.01
- 2017-06-29 0001571996-17-000011 — 3.03, 5.07, 8.01, 9.01
- 2017-06-08 0001193125-17-197638 — 2.02, 9.01
- 2017-03-30 0001193125-17-102794 — 8.01
- 2017-03-30 0001193125-17-102777 — 2.02, 9.01
- 2017-03-09 0001193125-17-076981 — 1.01, 2.03, 9.01
- 2017-01-17 0001193125-17-011125 — 8.01
- 2016-12-15 0001193125-16-793722 — 8.01
- 2016-12-08 0001193125-16-787976 — 2.02, 9.01
- 2016-11-10 0001193125-16-765964 — 1.02, 8.01
- 2016-11-04 0001193125-16-760249 — 8.01
- 2016-09-13 0001193125-16-708600 — 3.02
- 2016-09-09 0001193125-16-706567 — 1.01, 1.02, 2.01, 2.03, 3.02, 3.03, 5.02, 9.01
- 2016-09-07 0001193125-16-703370 — 3.03, 5.07, 7.01, 8.01, 9.01
- 2016-09-06 0001193125-16-702057 — 2.02, 9.01
- 2016-08-31 0001193125-16-697268 — 8.01, 9.01
- 2016-08-26 0001193125-16-692921 — 8.01, 9.01
- 2016-07-11 0001193125-16-645610 — 8.01
- 2016-07-05 0001193125-16-641679 — 8.01
- 2016-06-22 0001193125-16-629055 — 1.01, 2.03, 8.01, 9.01
- 2016-06-21 0001193125-16-627071 — 8.01, 9.01
- 2016-06-10 0001193125-16-618483 — 2.02, 9.01
- 2016-06-09 0001193125-16-617893 — 8.01, 9.01

## late-filing notifications on or before 2026-06-09

- none on or before 2026-06-09

## item 2.02 — earnings release, exhibit 99.1

[0001571996-26-000021:8k_2_02:1]
EX-99.1
2
exhibit991earnings8kq1fy27.htm
EX-99.1

[0001571996-26-000021:8k_2_02:2]
Document

[0001571996-26-000021:8k_2_02:3]
Exhibit 99.1

[0001571996-26-000021:8k_2_02:4]
Dell Technologies Delivers First Quarter Fiscal 2027 Financial Results

[0001571996-26-000021:8k_2_02:5]
ROUND ROCK, Texas — May 28, 2026 — Dell Technologies (NYSE: DELL) announces financial results for its fiscal 2027 first quarter and provides guidance for its fiscal 2027 second quarter and full year.

[0001571996-26-000021:8k_2_02:6]
First-Quarter Summary

[0001571996-26-000021:8k_2_02:7]
•Record revenue of $43.8 billion, up 88% year over year

[0001571996-26-000021:8k_2_02:8]
•Record diluted earnings per share (EPS) of $5.24, up 282% year over year, and record non-GAAP diluted EPS of $4.86, up 214%

[0001571996-26-000021:8k_2_02:9]
•Record first-quarter cash flow from operations of $4.1 billion

[0001571996-26-000021:8k_2_02:10]
“Our record Q1 performance reflects strong in-quarter demand, as well as our pace of innovation across the full stack of PCs, compute and storage,” said Jeff Clarke, vice chairman and chief operating officer, Dell Technologies. “We booked $24.4 billion in AI orders and recognized $16.1 billion of AI server revenue. We’re increasing our AI server revenue expectations for FY27 to $60 billion, which only goes to show the AI opportunity shows no signs of slowing.”

[0001571996-26-000021:8k_2_02:11]
“Execution was exceptionally strong across the business – from supply chain to sales to pricing – driving record revenue of $43.8 billion, record EPS, record Q1 cash flow of $4.1 billion and continued strong shareholder returns of $2.1 billion,” said David Kennedy, chief financial officer, Dell Technologies. “We entered FY27 with clear momentum, raising our full-year revenue outlook to $167 billion at the midpoint, up nearly 50% year over year.”

[0001571996-26-000021:8k_2_02:12]
Infrastructure Solutions Group (ISG)

[0001571996-26-000021:8k_2_02:13]
•Record revenue: $29.0 billion, up 181% year over year

[0001571996-26-000021:8k_2_02:14]
•Record AI-Optimized Servers revenue: $16.1 billion, up 757% year over year

[0001571996-26-000021:8k_2_02:15]
•Record Traditional Servers and Networking revenue: $8.5 billion, up 92% year over year

[0001571996-26-000021:8k_2_02:16]
•Record first-quarter Storage revenue: $4.3 billion, up 8% year over year

[0001571996-26-000021:8k_2_02:17]
•Record operating income: $3.1 billion, up 206% year over year

[0001571996-26-000021:8k_2_02:18]
Client Solutions Group (CSG)

[0001571996-26-000021:8k_2_02:19]
•Revenue: $14.6 billion, up 17% year over year

[0001571996-26-000021:8k_2_02:20]
•Record Commercial Client revenue: $13.0 billion, up 18% year over year

[0001571996-26-000021:8k_2_02:21]
•Consumer revenue: $1.6 billion, up 9% year over year

[0001571996-26-000021:8k_2_02:22]
•Record operating income: $1.2 billion, up 79% year over year

[0001571996-26-000021:8k_2_02:23]
Capital Return

[0001571996-26-000021:8k_2_02:24]
Dell Technologies returned $2.1 billion to shareholders in the first quarter through share repurchases and dividends.

[0001571996-26-000021:8k_2_02:25]
1

[0001571996-26-000021:8k_2_02:26]
Guidance Summary

[0001571996-26-000021:8k_2_02:27]
•Second-quarter FY27 revenue expected between $44.0 billion and $45.0 billion, up 49% year over year at the midpoint of $44.5 billion

[0001571996-26-000021:8k_2_02:28]
•Second-quarter FY27 GAAP diluted EPS expected to be $4.48 at the midpoint, up 164% year over year, and non-GAAP diluted EPS to be $4.80 at the midpoint, up 107%

[0001571996-26-000021:8k_2_02:29]
•Full-year FY27 revenue expected between $165.0 billion and $169.0 billion, up 47% year over year at the midpoint of $167.0 billion

[0001571996-26-000021:8k_2_02:30]
•Full-year AI-Optimized Servers revenue expected to be roughly $60 billion, up 144% year over year

[0001571996-26-000021:8k_2_02:31]
•Full-year FY27 GAAP diluted EPS expected to be $17.31 at the midpoint, up 99% year over year, and non-GAAP diluted EPS to be $17.90 at the midpoint, up 74%

[0001571996-26-000021:8k_2_02:32]
2

[0001571996-26-000021:8k_2_02:33]
First Quarter Fiscal 2027 Financial Results

[0001571996-26-000021:8k_2_02:34]
|  | Three Months Ended |  |  |  |  |  |  |
|  | May 1, 2026 |  | May 2, 2025 |  | Change |  |  |  |  |  |  |
|  | (in millions, except per share amounts and percentages; unaudited) |
| Net revenue | $ | 43,842 |  |  | $ | 23,378 |  |  | 88% |  |  |  |  |  |  |
| Operating income | $ | 3,656 |  |  | $ | 1,165 |  |  | 214% |  |  |  |  |  |  |
| Net income | $ | 3,438 |  |  | $ | 965 |  |  | 256% |  |  |  |  |  |  |
| Change in cash from operating activities | $ | 4,081 |  |  | $ | 2,796 |  |  | 46% |  |  |  |  |  |  |
| Earnings per share — diluted | $ | 5.24 |  |  | $ | 1.37 |  |  | 282% |  |  |  |  |  |  |
| Non-GAAP operating income | $ | 4,235 |  |  | $ | 1,666 |  |  | 154% |  |  |  |  |  |  |
| Non-GAAP net income | $ | 3,190 |  |  | $ | 1,086 |  |  | 194% |  |  |  |  |  |  |
| Adjusted free cash flow | $ | 3,165 |  |  | $ | 2,232 |  |  | 42% |  |  |  |  |  |  |
| Non-GAAP earnings per share — diluted | $ | 4.86 |  |  | $ | 1.55 |  |  | 214% |  |  |  |  |  |  |

[0001571996-26-000021:8k_2_02:35]
Information about Dell Technologies’ non-GAAP financial measures is provided under “Non-GAAP Financial Measures” below. All comparisons in this press release are year over year unless otherwise noted.

[0001571996-26-000021:8k_2_02:36]
Operating Segments Results

[0001571996-26-000021:8k_2_02:37]
|  | Three Months Ended |  |  |  |  |  |  |
|  | May 1, 2026 |  | May 2, 2025 |  | Change |  |  |  |  |  |  |
|  | (in millions, except percentages; unaudited) |
| Infrastructure Solutions Group (ISG): |  |  |  |  |  |  |  |  |  |  |  |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |
| AI-optimized servers | $ | 16,132 |  |  | $ | 1,882 |  |  | 757% |  |  |  |  |  |  |
| Traditional servers and networking | 8,543 |  |  | 4,439 |  |  | 92% |  |  |  |  |  |  |
| Storage | 4,334 |  |  | 3,996 |  |  | 8% |  |  |  |  |  |  |
| Total ISG net revenue | $ | 29,009 |  |  | $ | 10,317 |  |  | 181% |  |  |  |  |  |  |
| Operating income: |  |  |  |  |  |  |  |  |  |  |  |
| ISG operating income | $ | 3,055 |  |  | $ | 998 |  |  | 206% |  |  |  |  |  |  |
| % of ISG net revenue | 10.5 | % |  | 9.7 | % |  |  |  |  |  |  |  |  |
| % of total reportable segment operating income | 72 | % |  | 60 | % |  |  |  |  |  |  |  |  |
| Client Solutions Group (CSG): |  |  |  |  |  |  |  |  |  |  |  |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Commercial | $ | 13,020 |  |  | $ | 11,046 |  |  | 18% |  |  |  |  |  |  |
| Consumer | 1,589 |  |  | 1,463 |  |  | 9% |  |  |  |  |  |  |
| Total CSG net revenue | $ | 14,609 |  |  | $ | 12,509 |  |  | 17% |  |  |  |  |  |  |
| Operating income: |  |  |  |  |  |  |  |  |  |  |  |
| CSG operating income | $ | 1,170 |  |  | $ | 653 |  |  | 79% |  |  |  |  |  |  |
| % of CSG net revenue | 8.0 | % |  | 5.2 | % |  |  |  |  |  |  |  |  |
| % of total reportable segment operating income | 28 | % |  | 40 | % |  |  |  |  |  |  |  |  |

[0001571996-26-000021:8k_2_02:38]
Conference call information

[0001571996-26-000021:8k_2_02:39]
As previously announced, the company will hold a conference call to discuss its performance and financial guidance on May 28 at 3:30 p.m. CST. Prior to the start of the conference call, prepared remarks and a presentation containing additional financial and operating information may be downloaded from investors.delltechnologies.com. The conference call will be presented live over the internet and can be accessed at https://investors.delltechnologies.com/news-events/upcoming-events.

[0001571996-26-000021:8k_2_02:40]
For those unable to listen to the live presentation, the final remarks and presentation with additional financial and operating information will be available following the presentation, and an archived version will be available at the same location for one year.

[0001571996-26-000021:8k_2_02:41]
About Dell Technologies

[0001571996-26-000021:8k_2_02:42]
Dell Technologies (NYSE: DELL) helps organizations and individuals build their digital future and

[0001571996-26-000021:8k_2_02:43]
transform how they work, live and play. The company provides customers with the industry’s broadest

[0001571996-26-000021:8k_2_02:44]
and most innovative technology and services portfolio for the AI era.

[0001571996-26-000021:8k_2_02:45]
Contacts

[0001571996-26-000021:8k_2_02:46]
Investors: Investor_Relations@Dell.com

[0001571996-26-000021:8k_2_02:47]
Media: Media.Relations@Dell.com

[0001571996-26-000021:8k_2_02:48]
# # #

[0001571996-26-000021:8k_2_02:49]
Copyright © 2026 Dell Inc. or its subsidiaries. All Rights Reserved. Dell Technologies, Dell, EMC and Dell EMC are trademarks of Dell Inc. or its subsidiaries. Other trademarks may be trademarks of their respective owners.

[0001571996-26-000021:8k_2_02:50]
Non-GAAP Financial Measures:

[0001571996-26-000021:8k_2_02:51]
This press release presents information about non-GAAP gross margin, non-GAAP operating expenses, non-GAAP operating income, non-GAAP net income, non-GAAP earnings per share  – diluted, free cash flow, and adjusted free cash flow, all of which are non-GAAP financial measures provided as a supplement to the results provided in accordance with generally accepted accounting principles in the United States of America (“GAAP”). A reconciliation of each non-GAAP financial measure to the most directly comparable GAAP financial measure is provided in the attached tables for each of the fiscal periods indicated.

[0001571996-26-000021:8k_2_02:52]
Special Note on Forward-Looking Statements:

[0001571996-26-000021:8k_2_02:53]
Forward-looking statements include, among others, any statements regarding Dell Technologies’ expectations for second-quarter and full-year fiscal 2027 revenue, GAAP diluted earnings per share and non-GAAP diluted earnings per share, and for full-year fiscal 2027 AI-optimized servers revenue, as well as any other statements regarding Dell Technologies’ prospects and its future operations, financial condition, volumes, cash flows, expenses or other financial items, including management’s plans or strategies and objectives for any of the foregoing and any assumptions, expectations or beliefs underlying any of the foregoing.

[0001571996-26-000021:8k_2_02:54]
Dell Technologies’ results or events in future periods could differ materially from those expressed or implied by these forward-looking statements because of risks, uncertainties, and other factors that include, but are not limited to, the following: adverse global economic conditions, trade disruptions, and instability in financial markets; competitive pressures; Dell Technologies’ ability to successfully execute its strategy; Dell Technologies’ relationships with third-party suppliers for products and components; Dell Technologies’ use of single-source or limited-source suppliers; effects on Dell Technologies’ operating performance related to demand for AI solutions; management of Dell Technologies’ AI solutions and use of AI in internal functions and operations; Dell Technologies’ ability to deliver high-quality products, software, and services and to manage solutions and products and services transitions in an effective manner; Dell Technologies’ ability to successfully implement its cost efficiency plans; Dell Technologies’ ability to successfully execute on strategic initiatives including acquisitions and divestitures; security incidents, including cyber-attacks; Dell Technologies’ foreign operations and ability to generate substantial non-U.S. net revenue; Dell Technologies’ product, services, customer, and geographic sales mix, and seasonal sales trends; the performance of Dell Technologies’ sales channel partners; access to the capital markets by Dell Technologies or its customers; adverse economic conditions, changing customer mix, and the effect of additional regulation on Dell Technologies’ financial services activities;

[0001571996-26-000021:8k_2_02:55]
counterparty default risks; material impairment of the value of goodwill or intangible assets; the loss by Dell Technologies of any contracts for ISG services and solutions and its ability to perform such contracts at their estimated costs; loss by Dell Technologies of government contracts; Dell Technologies’ ability to develop and protect its proprietary intellectual property or obtain licenses to intellectual property developed by others on commercially reasonable and competitive terms; disruptions in Dell Technologies’ infrastructure; Dell Technologies’ ability to hedge effectively its exposure to fluctuations in foreign currency exchange rates and interest rates; expiration of tax holidays or favorable tax rate structures, or unfavorable outcomes in tax audits and other tax compliance matters; impairment of portfolio investments; unfavorable results of legal proceedings; evolving and varied expectations and regulatory requirements relating to sustainability issues; the effect of global climate change and related legal, regulatory or market measures; compliance with environmental and safety laws; compliance requirements of anti-corruption laws, economic sanctions and other trade laws, human rights laws, or other laws; Dell Technologies’ dependence on the services of Michael Dell and key employees; Dell Technologies’ level of indebtedness; and business and financial factors and legal restrictions affecting continuation of Dell Technologies’ quarterly cash dividend policy and dividend rate.

[0001571996-26-000021:8k_2_02:56]
This list of risks, uncertainties, and other factors is not complete. Dell Technologies discusses some of these matters more fully, as well as certain risk factors that could affect Dell Technologies’ business, financial condition, results of operations, and prospects, in its reports filed with the SEC, including Dell Technologies’ annual report on Form 10-K for the fiscal year ended January 30, 2026, quarterly reports on Form 10-Q, and current reports on Form 8-K. These filings are available for review through the SEC’s website at www.sec.gov. Any or all forward-looking statements Dell Technologies makes may turn out to be wrong and can be affected by inaccurate assumptions Dell Technologies might make or by known or unknown risks, uncertainties, and other factors, including those identified in this press release. Accordingly, you should not place undue reliance on the forward-looking statements made in this press release, which speak only as of its date. Dell Technologies does not undertake to update, and expressly disclaims any duty to update, its forward-looking statements, whether as a result of circumstances or events that arise after the date they are made, new information, or otherwise.

[0001571996-26-000021:8k_2_02:57]
5

[0001571996-26-000021:8k_2_02:58]
DELL TECHNOLOGIES INC.

[0001571996-26-000021:8k_2_02:59]
Condensed Consolidated Statements of Income and Related Financial Highlights

[0001571996-26-000021:8k_2_02:60]
(in millions, except per share amounts and percentages; unaudited)

[0001571996-26-000021:8k_2_02:61]
|  | Three Months Ended |  |  |  |  |  |  |
|  | May 1, 2026 |  | May 2, 2025 |  | Change |  |  |  |  |  |  |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Products | $ | 38,105 |  |  | $ | 17,599 |  |  | 117% |  |  |  |  |  |  |
| Services | 5,737 |  |  | 5,779 |  |  | (1)% |  |  |  |  |  |  |
| Total net revenue | 43,842 |  |  | 23,378 |  |  | 88% |  |  |  |  |  |  |
| Cost of net revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Products | 32,852 |  |  | 15,116 |  |  | 117% |  |  |  |  |  |  |
| Services | 3,208 |  |  | 3,325 |  |  | (4)% |  |  |  |  |  |  |
| Total cost of net revenue | 36,060 |  |  | 18,441 |  |  | 96% |  |  |  |  |  |  |
| Gross margin | 7,782 |  |  | 4,937 |  |  | 58% |  |  |  |  |  |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |
| Selling, general, and administrative | 3,143 |  |  | 2,964 |  |  | 6% |  |  |  |  |  |  |
| Research and development | 983 |  |  | 808 |  |  | 22% |  |  |  |  |  |  |
| Total operating expenses | 4,126 |  |  | 3,772 |  |  | 9% |  |  |  |  |  |  |
| Operating income | 3,656 |  |  | 1,165 |  |  | 214% |  |  |  |  |  |  |
| Interest and other, net | 292 |  |  | (82) |  |  | 456% |  |  |  |  |  |  |
| Income before income taxes | 3,948 |  |  | 1,083 |  |  | 265% |  |  |  |  |  |  |
| Income tax expense | 510 |  |  | 118 |  |  | 332% |  |  |  |  |  |  |
| Net income | $ | 3,438 |  |  | $ | 965 |  |  | 256% |  |  |  |  |  |  |
| Earnings per share: |  |  |  |  |  |  |  |  |  |  |  |
| Basic | $ | 5.30 |  |  | $ | 1.39 |  |  | 281% |  |  |  |  |  |  |
| Diluted | $ | 5.24 |  |  | $ | 1.37 |  |  | 282% |  |  |  |  |  |  |
| Weighted average shares: |  |  |  |  |  |  |  |  |  |  |  |
| Basic | 649 |  |  | 692 |  |  | (6)% |  |  |  |  |  |  |
| Diluted | 656 |  |  | 702 |  |  | (7)% |  |  |  |  |  |  |
| Percentage of Total Net Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Gross margin | 17.8 | % |  | 21.1 | % |  |  |  |  |  |  |  |  |
| Selling, general, and administrative | 7.3 | % |  | 12.6 | % |  |  |  |  |  |  |  |  |
| Research and development | 2.2 | % |  | 3.5 | % |  |  |  |  |  |  |  |  |
| Operating expenses | 9.5 | % |  | 16.1 | % |  |  |  |  |  |  |  |  |
| Operating income | 8.3 | % |  | 5.0 | % |  |  |  |  |  |  |  |  |
| Income before income taxes | 9.0 | % |  | 4.6 | % |  |  |  |  |  |  |  |  |
| Net income | 7.8 | % |  | 4.1 | % |  |  |  |  |  |  |  |  |
| Income tax rate | 12.9 | % |  | 10.9 | % |  |  |  |  |  |  |  |  |

[0001571996-26-000021:8k_2_02:62]
Amounts are based on underlying data and may not visually foot due to rounding.

[0001571996-26-000021:8k_2_02:63]
DELL TECHNOLOGIES INC.

[0001571996-26-000021:8k_2_02:64]
Condensed Consolidated Statements of Financial Position

[0001571996-26-000021:8k_2_02:65]
(in millions; unaudited)

[0001571996-26-000021:8k_2_02:66]
|  | May 1, 2026 |  | January 30, 2026 |
| ASSETS |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 11,578 |  |  | $ | 11,528 |  |
| Accounts receivable, net of allowance of $77 and $77 | 25,854 |  |  | 17,585 |  |
| Short-term financing receivables, net of allowance of $124 and $121 | 8,237 |  |  | 8,458 |  |
| Inventories | 15,052 |  |  | 10,437 |  |
| Other current assets | 9,886 |  |  | 9,594 |  |
| Total current assets | 70,607 |  |  | 57,602 |  |
| Property, plant, and equipment, net | 6,945 |  |  | 6,676 |  |
| Long-term investments | 2,484 |  |  | 1,730 |  |
| Long-term financing receivables, net of allowance of $88 and $92 | 5,713 |  |  | 5,822 |  |
| Goodwill | 19,504 |  |  | 19,547 |  |
| Intangible assets, net | 4,439 |  |  | 4,533 |  |
| Other non-current assets | 5,221 |  |  | 5,376 |  |
| Total assets | $ | 114,913 |  |  | $ | 101,286 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |
| Short-term debt | $ | 7,550 |  |  | $ | 7,990 |  |
| Accounts payable | 45,261 |  |  | 33,630 |  |
| Accrued and other | 8,594 |  |  | 8,315 |  |
| Short-term deferred revenue | 13,193 |  |  | 13,334 |  |
| Total current liabilities | 74,598 |  |  | 63,269 |  |
| Long-term debt | 23,611 |  |  | 23,513 |  |
| Long-term deferred revenue | 14,259 |  |  | 13,596 |  |
| Other non-current liabilities | 3,849 |  |  | 3,378 |  |
| Total liabilities | 116,317 |  |  | 103,756 |  |
| Stockholders’ equity (deficit): |  |  |  |
| Common stock and capital in excess of $0.01 par value | 9,111 |  |  | 9,457 |  |
| Treasury stock at cost | (16,149) |  |  | (14,533) |  |
| Retained earnings | 6,343 |  |  | 3,325 |  |
| Accumulated other comprehensive loss | (709) |  |  | (719) |  |
| Total stockholders’ equity (deficit) | (1,404) |  |  | (2,470) |  |
| Total liabilities and stockholders’ equity | $ | 114,913 |  |  | $ | 101,286 |  |

[0001571996-26-000021:8k_2_02:67]
7

[0001571996-26-000021:8k_2_02:68]
DELL TECHNOLOGIES INC.

[0001571996-26-000021:8k_2_02:69]
Condensed Consolidated Statements of Cash Flows

[0001571996-26-000021:8k_2_02:70]
(in millions; unaudited)

[0001571996-26-000021:8k_2_02:71]
|  | Three Months Ended |  |  |
|  | May 1, 2026 |  | May 2, 2025 |  |  |  |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |
| Net income | $ | 3,438 |  |  | $ | 965 |  |  |  |  |  |
| Adjustments to reconcile net income to net cash provided by operating activities: | 643 |  |  | 1,831 |  |  |  |  |  |
| Change in cash from operating activities | 4,081 |  |  | 2,796 |  |  |  |  |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |
| Purchases of investments | (124) |  |  | (97) |  |  |  |  |  |
| Maturities and sales of investments | 1 |  |  | 31 |  |  |  |  |  |
| Capital expenditures and capitalized software development costs | (963) |  |  | (568) |  |  |  |  |  |
| Divestitures of businesses and assets, net | — |  |  | 533 |  |  |  |  |  |
| Other | 19 |  |  | 13 |  |  |  |  |  |
| Change in cash from investing activities | (1,067) |  |  | (88) |  |  |  |  |  |
| Cash flows from financing activities: |  |  |  |  |  |  |  |
| Repurchases of common stock | (1,628) |  |  | (1,980) |  |  |  |  |  |
| Repurchases of common stock for employee tax withholdings | (537) |  |  | (352) |  |  |  |  |  |
| Payments of dividends and dividend equivalents | (464) |  |  | (396) |  |  |  |  |  |
| Proceeds from debt | 2,465 |  |  | 6,308 |  |  |  |  |  |
| Repayments of debt | (2,788) |  |  | (2,310) |  |  |  |  |  |
| Debt-related costs and other, net | (2) |  |  | (33) |  |  |  |  |  |
| Change in cash from financing activities | (2,954) |  |  | 1,237 |  |  |  |  |  |
| Effect of exchange rate changes on cash, cash equivalents, and restricted cash | (13) |  |  | 89 |  |  |  |  |  |
| Change in cash, cash equivalents, and restricted cash | 47 |  |  | 4,034 |  |  |  |  |  |
| Cash, cash equivalents, and restricted cash at beginning of the period | 11,706 |  |  | 3,819 |  |  |  |  |  |
| Cash, cash equivalents, and restricted cash at end of the period | $ | 11,753 |  |  | $ | 7,853 |  |  |  |  |  |

[0001571996-26-000021:8k_2_02:72]
DELL TECHNOLOGIES INC.

[0001571996-26-000021:8k_2_02:73]
Segment Information

[0001571996-26-000021:8k_2_02:74]
(in millions, except percentages; unaudited; continued on next page)

[0001571996-26-000021:8k_2_02:75]
|  | Three Months Ended |  |  |  |  |  |  |
|  | May 1, 2026 |  | May 2, 2025 |  | Change |  |  |  |  |  |  |
| Infrastructure Solutions Group (ISG): |  |  |  |  |  |  |  |  |  |  |  |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |
| AI-optimized servers | $ | 16,132 |  |  | $ | 1,882 |  |  | 757% |  |  |  |  |  |  |
| Traditional servers and networking | 8,543 |  |  | 4,439 |  |  | 92% |  |  |  |  |  |  |
| Storage | 4,334 |  |  | 3,996 |  |  | 8% |  |  |  |  |  |  |
| Total ISG net revenue | $ | 29,009 |  |  | $ | 10,317 |  |  | 181% |  |  |  |  |  |  |
| Operating income: |  |  |  |  |  |  |  |  |  |  |  |
| ISG operating income | $ | 3,055 |  |  | $ | 998 |  |  | 206% |  |  |  |  |  |  |
| % of ISG net revenue | 10.5 | % |  | 9.7 | % |  |  |  |  |  |  |  |  |
| % of total reportable segment operating income | 72 | % |  | 60 | % |  |  |  |  |  |  |  |  |
| Client Solutions Group (CSG): |  |  |  |  |  |  |  |  |  |  |  |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Commercial | $ | 13,020 |  |  | $ | 11,046 |  |  | 18% |  |  |  |  |  |  |
| Consumer | 1,589 |  |  | 1,463 |  |  | 9% |  |  |  |  |  |  |
| Total CSG net revenue | $ | 14,609 |  |  | $ | 12,509 |  |  | 17% |  |  |  |  |  |  |
| Operating income: |  |  |  |  |  |  |  |  |  |  |  |
| CSG operating income | $ | 1,170 |  |  | $ | 653 |  |  | 79% |  |  |  |  |  |  |
| % of CSG net revenue | 8.0 | % |  | 5.2 | % |  |  |  |  |  |  |  |  |
| % of total reportable segment operating income | 28 | % |  | 40 | % |  |  |  |  |  |  |  |  |

[0001571996-26-000021:8k_2_02:76]
Amounts are based on underlying data and may not visually foot due to rounding.

[0001571996-26-000021:8k_2_02:77]
9

[0001571996-26-000021:8k_2_02:78]
DELL TECHNOLOGIES INC.

[0001571996-26-000021:8k_2_02:79]
Segment Information

[0001571996-26-000021:8k_2_02:80]
(in millions; unaudited; continued)

[0001571996-26-000021:8k_2_02:81]
|  | Three Months Ended |  |  |
|  | May 1, 2026 |  | May 2, 2025 |  |  |  |  |
| Reconciliation to consolidated net revenue: |  |  |  |  |  |  |  |
| Reportable segment net revenue | $ | 43,618 |  |  | $ | 22,826 |  |  |  |  |  |
| Corporate and other (a) | 224 |  |  | 552 |  |  |  |  |  |
| Total consolidated net revenue | $ | 43,842 |  |  | $ | 23,378 |  |  |  |  |  |
| Reconciliation to consolidated operating income: |  |  |  |  |  |  |
| Reportable segment operating income (b) | $ | 4,225 |  |  | $ | 1,651 |  |  |  |  |  |
| Corporate and other (a) | 10 |  |  | 15 |  |  |  |  |  |
| Amortization of intangibles (c) | (97) |  |  | (126) |  |  |  |  |  |
| Stock-based compensation expense (d) | (189) |  |  | (190) |  |  |  |  |  |
| Other corporate expenses (e) | (293) |  |  | (185) |  |  |  |  |  |
| Total consolidated operating income (f) | $ | 3,656 |  |  | $ | 1,165 |  |  |  |  |  |

[0001571996-26-000021:8k_2_02:82]
_________________

[0001571996-26-000021:8k_2_02:83]
(a)Corporate and other includes VMware Resale and other items that are managed at the corporate level and are not allocated to reportable segments.

[0001571996-26-000021:8k_2_02:84]
(b)Depreciation expense directly attributable to each reportable segment is included in the operating results of each segment. However, the Chief Operating Decision Maker does not evaluate depreciation expense by operating segment, and therefore such expense is not separately presented.

[0001571996-26-000021:8k_2_02:85]
(c)Amortization of intangibles includes non-cash purchase accounting adjustments that are primarily related to the EMC merger transaction completed in September 2016.

[0001571996-26-000021:8k_2_02:86]
(d)Stock-based compensation expense consists of equity awards granted based on the estimated fair value of those awards at grant date.

[0001571996-26-000021:8k_2_02:87]
(e)Other corporate expenses includes severance expenses, payroll taxes associated with stock-based compensation, incentive charges related to equity investments, transaction-related expenses, and impairment charges.

[0001571996-26-000021:8k_2_02:88]
(f)Income and expenses within Interest and other, net, is not allocated to the reportable segments. Therefore, the company only reports reportable segment operating income.

[0001571996-26-000021:8k_2_02:89]
10

[0001571996-26-000021:8k_2_02:90]
SUPPLEMENTAL SELECTED NON-GAAP FINANCIAL MEASURES

[0001571996-26-000021:8k_2_02:91]
These tables present information about the company’s non-GAAP gross margin, non-GAAP operating expenses, non-GAAP operating income, non-GAAP net income, non-GAAP earnings per share - diluted, free cash flow and adjusted free cash flow, all of which are non-GAAP financial measures provided as a supplement to the results provided in accordance with generally accepted accounting principles in the United States of America (“GAAP”). A detailed discussion of Dell Technologies’ reasons for including certain of these non-GAAP financial measures, the limitations associated with these measures, the items excluded from these measures, and the company’s reason for excluding those items are presented in “Management’s Discussion and Analysis of Financial Condition and Results of Operations — Non-GAAP Financial Measures” in the company’s periodic reports filed with the SEC. Dell Technologies encourages investors to review the non-GAAP discussion in these reports in conjunction with the presentation of non-GAAP financial measures.

[0001571996-26-000021:8k_2_02:92]
11

[0001571996-26-000021:8k_2_02:93]
DELL TECHNOLOGIES INC.

[0001571996-26-000021:8k_2_02:94]
Selected Financial Measures

[0001571996-26-000021:8k_2_02:95]
(in millions, except per share amounts and percentages; unaudited)

[0001571996-26-000021:8k_2_02:96]
|  | Three Months Ended |  |  |  |  |  |  |
|  | May 1, 2026 |  | May 2, 2025 |  | Change |  |  |  |  |  |  |
| Net revenue | $ | 43,842 |  |  | $ | 23,378 |  |  | 88% |  |  |  |  |  |  |
| Non-GAAP gross margin | $ | 7,947 |  |  | $ | 5,057 |  |  | 57% |  |  |  |  |  |  |
| % of net revenue | 18.1 | % |  | 21.6 | % |  |  |  |  |  |  |  |  |
| Non-GAAP operating expenses | $ | 3,712 |  |  | $ | 3,391 |  |  | 9% |  |  |  |  |  |  |
| % of net revenue | 8.4 | % |  | 14.5 | % |  |  |  |  |  |  |  |  |
| Non-GAAP operating income | $ | 4,235 |  |  | $ | 1,666 |  |  | 154% |  |  |  |  |  |  |
| % of net revenue | 9.7 | % |  | 7.1 | % |  |  |  |  |  |  |  |  |
| Non-GAAP net income | $ | 3,190 |  |  | $ | 1,086 |  |  | 194% |  |  |  |  |  |  |
| % of net revenue | 7.3 | % |  | 4.6 | % |  |  |  |  |  |  |  |  |
| Non-GAAP earnings per share — diluted | $ | 4.86 |  |  | $ | 1.55 |  |  | 214% |  |  |  |  |  |  |

[0001571996-26-000021:8k_2_02:97]
Amounts are based on underlying data and may not visually foot due to rounding.

[0001571996-26-000021:8k_2_02:98]
DELL TECHNOLOGIES INC.

[0001571996-26-000021:8k_2_02:99]
Reconciliation of Selected Non-GAAP Financial Measures

[0001571996-26-000021:8k_2_02:100]
(in millions, except percentages; unaudited; continued on next page)

[0001571996-26-000021:8k_2_02:101]
|  | Three Months Ended |  |  |  |  |  |  |
|  | May 1, 2026 |  | May 2, 2025 |  | Change |  |  |  |  |  |  |
| Gross margin | $ | 7,782 |  |  | $ | 4,937 |  |  | 58% |  |  |  |  |  |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 26 |  |  | 41 |  |  |  |  |  |  |  |  |  |
| Stock-based compensation expense | 44 |  |  | 39 |  |  |  |  |  |  |  |  |  |
| Other corporate expenses | 95 |  |  | 40 |  |  |  |  |  |  |  |  |  |
| Non-GAAP gross margin | $ | 7,947 |  |  | $ | 5,057 |  |  | 57% |  |  |  |  |  |  |
| Operating expenses | $ | 4,126 |  |  | $ | 3,772 |  |  | 9% |  |  |  |  |  |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | (71) |  |  | (85) |  |  |  |  |  |  |  |  |  |
| Stock-based compensation expense | (145) |  |  | (151) |  |  |  |  |  |  |  |  |  |
| Other corporate expenses | (198) |  |  | (145) |  |  |  |  |  |  |  |  |  |
| Non-GAAP operating expenses | $ | 3,712 |  |  | $ | 3,391 |  |  | 9% |  |  |  |  |  |  |
| Operating income | $ | 3,656 |  |  | $ | 1,165 |  |  | 214% |  |  |  |  |  |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 97 |  |  | 126 |  |  |  |  |  |  |  |  |  |
| Stock-based compensation expense | 189 |  |  | 190 |  |  |  |  |  |  |  |  |  |
| Other corporate expenses | 293 |  |  | 185 |  |  |  |  |  |  |  |  |  |
| Non-GAAP operating income | $ | 4,235 |  |  | $ | 1,666 |  |  | 154% |  |  |  |  |  |  |
| Net income | $ | 3,438 |  |  | $ | 965 |  |  | 256% |  |  |  |  |  |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 97 |  |  | 126 |  |  |  |  |  |  |  |  |  |
| Stock-based compensation expense | 189 |  |  | 190 |  |  |  |  |  |  |  |  |  |
| Other corporate (income) expenses | 288 |  |  | (58) |  |  |  |  |  |  |  |  |  |
| Fair value adjustments on equity investments | (631) |  |  | (17) |  |  |  |  |  |  |  |  |  |
| Aggregate adjustment for income taxes (a) | (191) |  |  | (120) |  |  |  |  |  |  |  |  |  |
| Non-GAAP net income | $ | 3,190 |  |  | $ | 1,086 |  |  | 194% |  |  |  |  |  |  |

[0001571996-26-000021:8k_2_02:102]
____________________

[0001571996-26-000021:8k_2_02:103]
(a)The company’s non-GAAP income tax is calculated using a fixed estimated annual tax rate.

[0001571996-26-000021:8k_2_02:104]
13

[0001571996-26-000021:8k_2_02:105]
DELL TECHNOLOGIES INC.

[0001571996-26-000021:8k_2_02:106]
Reconciliation of Selected Non-GAAP Financial Measures

[0001571996-26-000021:8k_2_02:107]
(unaudited; continued)

[0001571996-26-000021:8k_2_02:108]
|  | Three Months Ended |  |  |  |  |  |  |
|  | May 1, 2026 |  | May 2, 2025 |  | Change |  |  |  |  |  |  |
| Earnings per share — diluted | $ | 5.24 |  |  | $ | 1.37 |  |  | 282 | % |  |  |  |  |  |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 0.14 |  |  | 0.18 |  |  |  |  |  |  |  |  |  |
| Stock-based compensation expense | 0.29 |  |  | 0.27 |  |  |  |  |  |  |  |  |  |
| Other corporate (income) expenses | 0.44 |  |  | (0.08) |  |  |  |  |  |  |  |  |  |
| Fair value adjustments on equity investments | (0.96) |  |  | (0.02) |  |  |  |  |  |  |  |  |  |
| Aggregate adjustment for income taxes (a) | (0.29) |  |  | (0.17) |  |  |  |  |  |  |  |  |  |
| Non-GAAP earnings per share — diluted | $ | 4.86 |  |  | $ | 1.55 |  |  | 214 | % |  |  |  |  |  |  |

[0001571996-26-000021:8k_2_02:109]
____________________

[0001571996-26-000021:8k_2_02:110]
(a)The company’s non-GAAP income tax is calculated using a fixed estimated annual tax rate.

[0001571996-26-000021:8k_2_02:111]
DELL TECHNOLOGIES INC.

[0001571996-26-000021:8k_2_02:112]
Reconciliation of Selected Non-GAAP Financial Measures

[0001571996-26-000021:8k_2_02:113]
(in millions, except percentages; unaudited; continued)

[0001571996-26-000021:8k_2_02:114]
|  | Three Months Ended |  |  |  |  |  |  |
|  | May 1, 2026 |  | May 2, 2025 |  | Change |  |  |  |  |  |  |
| Cash flow from operations | $ | 4,081 |  |  | $ | 2,796 |  |  | 46 | % |  |  |  |  |  |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Capital expenditures and capitalized software development costs, net (a) | (963) |  |  | (568) |  |  |  |  |  |  |  |  |  |
| Free cash flow | $ | 3,118 |  |  | $ | 2,228 |  |  | 40 | % |  |  |  |  |  |  |
| Free cash flow | $ | 3,118 |  |  | $ | 2,228 |  |  | 40 | % |  |  |  |  |  |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Financing receivables (b) | (263) |  |  | (23) |  |  |  |  |  |  |  |  |  |
| Equipment under operating leases (c) | 310 |  |  | 27 |  |  |  |  |  |  |  |  |  |
| Adjusted free cash flow | $ | 3,165 |  |  | $ | 2,232 |  |  | 42 | % |  |  |  |  |  |  |

[0001571996-26-000021:8k_2_02:115]
____________________

[0001571996-26-000021:8k_2_02:116]
(a)Capital expenditures and capitalized software development costs, net includes proceeds from sales of facilities, land, and other assets.

[0001571996-26-000021:8k_2_02:117]
(b)Financing receivables represent the operating cash flow impact from the change in financing receivables.

[0001571996-26-000021:8k_2_02:118]
(c)Equipment under operating leases represents the net impact of capital expenditures and depreciation expense for leases and contractually embedded leases identified within flexible consumption arrangements.

[0001571996-26-000021:8k_2_02:119]
15

[0001571996-26-000021:8k_2_02:120]
DELL TECHNOLOGIES INC.

[0001571996-26-000021:8k_2_02:121]
Reconciliation of Non-GAAP Financial Measures in Summary Guidance

[0001571996-26-000021:8k_2_02:122]
(unaudited)

[0001571996-26-000021:8k_2_02:123]
|  | Three Months Ending |  | Fiscal Year Ending |
|  | July 31, 2026 |  | January 29, 2027 |
| Earnings per share — diluted | $ | 4.48 |  |  | $ | 17.31 |  |
| Non-GAAP adjustments: |  |  |  |
| Amortization of intangibles (a) | 0.15 |  |  | 0.59 |  |
| Stock-based compensation | 0.29 |  |  | 1.16 |  |
| Other corporate expenses (b) | — |  |  | 0.45 |  |
| Fair value adjustments on equity investments (c) | — |  |  | (0.97) |  |
| Aggregate adjustment for income taxes (d) | (0.12) |  |  | (0.64) |  |
| Non-GAAP earnings per share — diluted | $ | 4.80 |  |  | $ | 17.90 |  |

[0001571996-26-000021:8k_2_02:124]
____________________

[0001571996-26-000021:8k_2_02:125]
(a)Amortization of intangibles represents an estimate for acquisitions completed as of May 1, 2026 and does not include estimates for potential acquisitions, if any, during fiscal 2027.

[0001571996-26-000021:8k_2_02:126]
(b)Consists primarily of severance expenses, payroll taxes associated with stock-based compensation, transaction-related expenses, impairment charges, and incentive charges related to equity investments. No estimate is included for severance expense as such expense cannot be reasonably estimated at this time.

[0001571996-26-000021:8k_2_02:127]
(c)No estimates are included for potential fair value adjustments on strategic investments given the potential volatility of either gains or losses on those equity investments.

[0001571996-26-000021:8k_2_02:128]
(d)The fiscal 2027 aggregate adjustment to reconcile non-GAAP income tax expense to GAAP income tax expense is approximately $0.4 billion. The aggregate adjustment for income taxes is the estimated combined income tax effect for the adjustments shown above as well as an adjustment for discrete tax items. The company’s non-GAAP income tax is calculated using a fixed estimated annual tax rate.
