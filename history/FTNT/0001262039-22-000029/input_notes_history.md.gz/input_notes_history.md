# FTNT note change history — 0001262039-22-000019 → 0001262039-22-000029


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2022-08-05):
[0001262039-22-000029:note_history:1]
COMMITMENTS AND CONTINGENCIES
The following table summarizes our inventory purchase commitments as of June 30, 2022 (in millions):
  (was, 2022-05-06, similarity 0.9641):
[0001262039-22-000019:note_history:1]
COMMITMENTS AND CONTINGENCIES
The following table summarizes our inventory purchase commitments as of March 31, 2022 (in millions):

- added (2022-08-05):
[0001262039-22-000029:note_history:2]
Inventory Purchase Commitments—Our independent contract manufacturers and certain component suppliers procure components and build our products based on our forecasts and the availability of various components. These forecasts are based on estimates of future demand for our products, which are in turn based on historical trends and an analysis from our sales and marketing organizations, adjusted for extended lead times, changes in supplier delivery commitments and other supply chain matters and other market conditions. In order to manage manufacturing lead times, plan for adequate component supply and incentivize suppliers to deliver, we may issue purchase orders to some of our independent contract manufacturers which are non-cancelable. As of June 30, 2022 and December 31, 2021, we had $1.49 billion and $1.14 billion, respectively, of open purchase orders with our independent contract manufacturers that are non-cancelable.

- changed (2022-08-05):
[0001262039-22-000029:note_history:3]
Other Contractual Commitments and Open Purchase Orders—In addition to commitments with contract manufacturers, we have open purchase orders and contractual obligations in the ordinary course of business for which we have not received goods or services. A significant portion of our reported purchase commitments consist of firm and non-cancelable commitments. In certain instances, contractual commitments allow us the option to cancel, reschedule and adjust our requirements based on our business needs prior to firm orders being placed. As of June 30, 2022 and December 31, 2021, we had $117.1 million and $126.7 million, respectively, in other contractual commitments having a remaining term in excess of one year that are non-cancelable and an additional $80.0 million and $68.9 million, respectively, in contractual commitments for operating lease liabilities.
  (was, 2022-05-06, similarity 0.9946):
[0001262039-22-000019:note_history:3]
Other Contractual Commitments and Open Purchase Orders—In addition to commitments with contract manufacturers, we have open purchase orders and contractual obligations in the ordinary course of business for which we have not received goods or services. A significant portion of our reported purchase commitments consist of firm and non-cancelable commitments. In certain instances, contractual commitments allow us the option to cancel, reschedule and adjust our requirements based on our business needs prior to firm orders being placed. As of March 31, 2022 and December 31, 2021, we had $114.4 million and $126.7 million, respectively, in other contractual commitments having a remaining term in excess of one year that are non-cancelable and an additional $85.4 million and $68.9 million, respectively, in contractual commitments for operating lease liabilities.

- changed (2022-08-05):
[0001262039-22-000029:note_history:4]
In December 2021, we entered into an agreement that provided for settlement and dismissal of an existing patent infringement lawsuit and a mutual covenant-not-to-sue for a defined duration of time. We have settled and paid $10.0 million in cash, of which $5.6 million was related to the dismissal of the lawsuit and was expensed as a general and administrative expense, and $4.4 million was deferred and will be expensed over time as royalty cost of revenue. Litigation loss contingency accruals associated with other outstanding cases were not material as of June 30, 2022 and December 31, 2021.
  (was, 2022-05-06, similarity 0.9886):
[0001262039-22-000019:note_history:4]
In December 2021, we entered into an agreement that provided for settlement and dismissal of an existing patent infringement lawsuit and a mutual covenant-not-to-sue for a defined duration of time. We have settled and paid $10.0 million in cash, of which $5.6 million was related to the dismissal of lawsuit and was expensed as a general and administrative expense, and $4.4 million was deferred and will be expensed over time as royalty cost of revenue. Litigation loss contingency accruals associated with other outstanding cases were not material as of March 31, 2022 and December 31, 2021.

- removed (2022-08-05):
[0001262039-22-000019:note_history:5]
Inventory Purchase Commitments—Our independent contract manufacturers and certain component suppliers procure components and build our products based on our forecasts. These forecasts are based on estimates of future demand for our products, which are in turn based on historical trends and an analysis from our sales and marketing organizations, adjusted for extended lead times, changes in supplier delivery commitments and other supply chain matters and other market conditions.

- removed (2022-08-05):
[0001262039-22-000019:note_history:6]
In order to manage manufacturing lead times, plan for adequate component supply and incentivize suppliers to deliver, we may issue purchase orders to some of our independent contract manufacturers which are non-cancelable. As of March 31, 2022 and December 31, 2021, we had $1.37 billion and $1.14 billion, respectively, of open purchase orders with our independent contract manufacturers that are non-cancelable.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2022-08-05):
[0001262039-22-000029:note_history:7]
SUMMARY OF SIGNIFICANT ACCOUNTING POLICIES
Basis of Presentation and Preparation—The unaudited condensed consolidated financial statements of Fortinet, Inc. and its subsidiaries (collectively, “we,” “us” or “our”) have been prepared in accordance with generally accepted accounting principles in the United States (“GAAP”) for interim financial information, as well as the instructions to Form 10-Q pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (the “SEC”). Accordingly, they do not include all of the information and footnotes required by GAAP for complete financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the year ended December 31, 2021, contained in our Annual Report on Form 10-K filed with the SEC on February 25, 2022. In the opinion of management, all adjustments, which include normal recurring adjustments, considered necessary for a fair presentation, have been included. The results of operations for the three and six months ended June 30, 2022 are not necessarily indicative of the results to be expected for the full year or for any future periods. The condensed consolidated balance sheet as of December 31, 2021 is derived from the audited consolidated financial statements for the year ended December 31, 2021.
  (was, 2022-05-06, similarity 0.792):
[0001262039-22-000019:note_history:7]
SUMMARY OF SIGNIFICANT ACCOUNTING POLICIES
Basis of Presentation and Preparation—The unaudited condensed consolidated financial statements of Fortinet, Inc. and its subsidiaries (collectively, “we,” “us” or “our”) have been prepared in accordance with generally accepted accounting principles in the United States (“GAAP”) for interim financial information, as well as the instructions to Form 10-Q pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (the “SEC”). Accordingly, they do not include all of the information and footnotes required by GAAP for complete financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the year ended December 31, 2021, contained in our Annual Report on Form 10-K filed with the SEC on February 25, 2022. In the opinion of management, all adjustments, which include normal recurring adjustments, considered necessary for a fair presentation, have been included. The results of operations for the three months ended March 31, 2022 are not necessarily indicative of the results to be expected for the full year or for any future periods. The condensed consolidated balance sheet as of December 31, 2021 is derived from the audited consolidated financial statements for the year ended December 31, 2021.

- added (2022-08-05):
[0001262039-22-000029:note_history:8]
On April 14, 2022, our Board of Directors approved a five-for-one forward stock split of our common stock (the "Forward Stock Split"), which was conditioned upon obtaining stockholder approval for the Forward Stock Split, and to increase the number of our authorized shares of common stock. On June 17, 2022, at our 2022 Annual Meeting of Stockholders, our stockholders approved the Forward Stock Split and the amendment and restatement of our amended and restated certificate of incorporation to increase the number of authorized shares of common stock from 300 million to 1.5 billion. The par value of our common stock was not adjusted as a result of the Forward Stock Split. Effective June 22, 2022, we filed our amended and restated certification of incorporation and completed the Forward Stock Split. All share and per share amounts and related stockholders’ equity (deficit) balances presented herein have been retroactively adjusted to reflect the Forward Stock Split.

- changed (2022-08-05):
[0001262039-22-000029:note_history:9]
There have been no material changes to our significant accounting policies as of and for the three and six months ended June 30, 2022.
  (was, 2022-05-06, similarity 0.9317):
[0001262039-22-000019:note_history:9]
There have been no material changes to our significant accounting policies as of and for the three months ended March 31, 2022.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-08-05):
[0001262039-22-000029:note_history:10]
On March 5, 2021, we issued $1.0 billion aggregate principal amount of senior notes (collectively, the “Senior Notes”), consisting of $500.0 million aggregate principal amount of 1.0% notes due March 15, 2026 (the “2026 Senior Notes”) and $500.0 million aggregate principal amount of 2.2% notes due March 15, 2031 (the “2031 Senior Notes”), in an underwritten registered public offering. The Senior Notes are senior unsecured obligations and rank equally with each other in right of payment and with our other outstanding obligations. We may redeem the Senior Notes at any time in whole or in part for cash, at specified redemption prices that include accrued and unpaid interest, if any, and a make-whole premium. However, no make-whole premium will be paid for redemptions of the 2026 Senior Notes on or after February 15, 2026, or the 2031 Senior Notes on or after December 15, 2030. Interest on the Senior Notes is payable on March 15 and September 15 of each year, beginning on September 15, 2021. As of June 30, 2022 and December 31, 2021, the Senior Notes were recorded as long-term debt, net of discount and issuance costs, which are amortized to interest expense over the respective contractual terms of these notes using the effective interest method.
  (was, 2022-05-06, similarity 0.9962):
[0001262039-22-000019:note_history:10]
On March 5, 2021, we issued $1.0 billion aggregate principal amount of senior notes (collectively, the “Senior Notes”), consisting of $500.0 million aggregate principal amount of 1.0% notes due March 15, 2026 (the “2026 Senior Notes”) and $500.0 million aggregate principal amount of 2.2% notes due March 15, 2031 (the “2031 Senior Notes”), in an underwritten registered public offering. The Senior Notes are senior unsecured obligations and rank equally with each other in right of payment and with our other outstanding obligations. We may redeem the Senior Notes at any time in whole or in part for cash, at specified redemption prices that include accrued and unpaid interest, if any, and a make-whole premium. However, no make-whole premium will be paid for redemptions of the 2026 Senior Notes on or after February 15, 2026, or the 2031 Senior Notes on or after December 15, 2030. Interest on the Senior Notes is payable on March 15 and September 15 of each year, beginning on September 15, 2021. As of March 31, 2022 and December 31, 2021, the Senior Notes were recorded as long-term debt, net of discount and issuance costs, which are amortized to interest expense over the respective contractual terms of these notes using the effective interest method.

- changed (2022-08-05):
[0001262039-22-000029:note_history:11]
|  | Maturity |  | Coupon Rate |  | Effective Interest Rate |  | June 30,2022 |  | December 31,2021 |
| Debt |  |  |  |  |  |  |  |  |  |
| 2026 Senior Notes | March 2026 |  | 1.0% |  | 1.3% |  | $ | 500.0 |  |  | $ | 500.0 |  |
| 2031 Senior Notes | March 2031 |  | 2.2% |  | 2.3% |  | 500.0 |  |  | 500.0 |  |
| Total debt |  |  |  |  |  |  | 1,000.0 |  |  | 1,000.0 |  |
| Less: Unamortized discount and debt issuance costs |  |  |  |  |  |  | 10.6 |  |  | 11.6 |  |
| Total long-term debt |  |  |  |  |  |  | $ | 989.4 |  |  | $ | 988.4 |  |
  (was, 2022-05-06, similarity 0.9892):
[0001262039-22-000019:note_history:11]
|  | Maturity |  | Coupon Rate |  | Effective Interest Rate |  | March 31,2022 |  | December 31,2021 |
| Debt |  |  |  |  |  |  |  |  |  |
| 2026 Senior Notes | March 2026 |  | 1.0% |  | 1.3% |  | $ | 500.0 |  |  | $ | 500.0 |  |
| 2031 Senior Notes | March 2031 |  | 2.2% |  | 2.3% |  | 500.0 |  |  | 500.0 |  |
| Total debt |  |  |  |  |  |  | 1,000.0 |  |  | 1,000.0 |  |
| Less: Unamortized discount and debt issuance costs |  |  |  |  |  |  | 11.1 |  |  | 11.6 |  |
| Total long-term debt |  |  |  |  |  |  | $ | 988.9 |  |  | $ | 988.4 |  |

- added (2022-08-05):
[0001262039-22-000029:note_history:12]
As of June 30, 2022 and December 31, 2021, we accrued interest payable of $4.7 million, and there are no financial covenants with which we must comply. During the three months ended June 30, 2022 and 2021 we recorded $4.5 million of total interest expense in relation to these Senior Notes in each quarter. During the six months ended June 30, 2022 and 2021 we recorded $9.0 million and $5.8 million of total interest expense in relation to these Senior Notes, respectively. No interest costs were capitalized for the three months or six months ended June 30, 2022 and 2021, as the costs that qualified for capitalization were not material.

- changed (2022-08-05):
[0001262039-22-000029:note_history:13]
The total estimated fair value of the outstanding Senior Notes was approximately $848.4 million, including accrued and unpaid interest, as of June 30, 2022. The fair value was determined based on observable market prices of identical instruments in less active markets. The estimated fair values are based on Level 2 inputs.
  (was, 2022-05-06, similarity 0.9857):
[0001262039-22-000019:note_history:13]
The total estimated fair value of the outstanding Senior Notes was approximately $899.5 million, including accrued and unpaid interest, as of March 31, 2022. The fair value was determined based on observable market prices of identical instruments in less active markets. The estimated fair values are based on Level 2 inputs.

- removed (2022-08-05):
[0001262039-22-000019:note_history:14]
As of March 31, 2022 and December 31, 2021, we accrued interest payable of $0.7 million and $4.7 million, and there are no financial covenants with which we must comply. During the three months ended March 31, 2022 and 2021 we recorded $4.5 million and $1.3 million of total interest expense in relation to these Senior Notes, respectively. No interest costs were capitalized for the three months ended March 31, 2022 and 2021, as the costs that qualified for capitalization were not material.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-08-05):
[0001262039-22-000029:note_history:15]
|  | Maturity |  | Coupon Rate |  | Effective Interest Rate |  | June 30,2022 |  | December 31,2021 |
| Debt |  |  |  |  |  |  |  |  |  |
| 2026 Senior Notes | March 2026 |  | 1.0% |  | 1.3% |  | $ | 500.0 |  |  | $ | 500.0 |  |
| 2031 Senior Notes | March 2031 |  | 2.2% |  | 2.3% |  | 500.0 |  |  | 500.0 |  |
| Total debt |  |  |  |  |  |  | 1,000.0 |  |  | 1,000.0 |  |
| Less: Unamortized discount and debt issuance costs |  |  |  |  |  |  | 10.6 |  |  | 11.6 |  |
| Total long-term debt |  |  |  |  |  |  | $ | 989.4 |  |  | $ | 988.4 |  |
  (was, 2022-05-06, similarity 0.9892):
[0001262039-22-000019:note_history:15]
|  | Maturity |  | Coupon Rate |  | Effective Interest Rate |  | March 31,2022 |  | December 31,2021 |
| Debt |  |  |  |  |  |  |  |  |  |
| 2026 Senior Notes | March 2026 |  | 1.0% |  | 1.3% |  | $ | 500.0 |  |  | $ | 500.0 |  |
| 2031 Senior Notes | March 2031 |  | 2.2% |  | 2.3% |  | 500.0 |  |  | 500.0 |  |
| Total debt |  |  |  |  |  |  | 1,000.0 |  |  | 1,000.0 |  |
| Less: Unamortized discount and debt issuance costs |  |  |  |  |  |  | 11.1 |  |  | 11.6 |  |
| Total long-term debt |  |  |  |  |  |  | $ | 988.9 |  |  | $ | 988.4 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2022-08-05):
[0001262039-22-000029:note_history:16]
|  | Three Months Ended |  | Six Months Ended |
|  | June 30,2022 |  | June 30,2021 |  | June 30,2022 |  | June 30,2021 |
| Product | $ | 400.7 |  |  | $ | 298.3 |  |  | $ | 771.7 |  |  | $ | 539.0 |  |
| Service: |  |  |  |  |  |  |  |
| Security subscription | 340.4 |  |  | 272.9 |  |  | 653.3 |  |  | 528.2 |  |
| Technical support and other | 289.0 |  |  | 229.9 |  |  | 559.9 |  |  | 444.2 |  |
| Total service revenue | 629.4 |  |  | 502.8 |  |  | 1,213.2 |  |  | 972.4 |  |
| Total revenue | $ | 1,030.1 |  |  | $ | 801.1 |  |  | $ | 1,984.9 |  |  | $ | 1,511.4 |  |

- removed (2022-08-05):
[0001262039-22-000019:note_history:17]
|  | Three Months Ended |  |  |
|  | March 31,2022 |  | March 31,2021 |  |  |  |  |
| Product | $ | 371.0 |  |  | $ | 240.7 |  |  |  |  |  |
| Service: |  |  |  |  |  |  |  |
| Security subscription | 312.9 |  |  | 255.3 |  |  |  |  |  |
| Technical support and other | 270.9 |  |  | 214.3 |  |  |  |  |  |
| Total service revenue | 583.8 |  |  | 469.6 |  |  |  |  |  |
| Total revenue | $ | 954.8 |  |  | $ | 710.3 |  |  |  |  |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2022-08-05):
[0001262039-22-000029:note_history:18]
|  | Three Months Ended |  | Six Months Ended |
|  | June 30,2022 |  | June 30,2021 |  | June 30,2022 |  | June 30,2021 |
| Product | $ | 400.7 |  |  | $ | 298.3 |  |  | $ | 771.7 |  |  | $ | 539.0 |  |
| Service: |  |  |  |  |  |  |  |
| Security subscription | 340.4 |  |  | 272.9 |  |  | 653.3 |  |  | 528.2 |  |
| Technical support and other | 289.0 |  |  | 229.9 |  |  | 559.9 |  |  | 444.2 |  |
| Total service revenue | 629.4 |  |  | 502.8 |  |  | 1,213.2 |  |  | 972.4 |  |
| Total revenue | $ | 1,030.1 |  |  | $ | 801.1 |  |  | $ | 1,984.9 |  |  | $ | 1,511.4 |  |

- changed (2022-08-05):
[0001262039-22-000029:note_history:19]
During the three and six months ended June 30, 2022, we recognized $457.6 million and $964.9 million in service revenue that was included in the deferred revenue balance as of December 31, 2021, respectively. During the three and six months ended June 30, 2021, we recognized $371.2 million and $789.1 million in service revenue that was included in the deferred revenue balance as of December 31, 2020, respectively.
  (was, 2022-05-06, similarity 0.6386):
[0001262039-22-000019:note_history:19]
During the three months ended March 31, 2022 and 2021, we recognized $507.3 million and $417.9 million in service revenue that was included in the deferred revenue balance as of December 31, 2021 and 2020, respectively.

- changed (2022-08-05):
[0001262039-22-000029:note_history:20]
As of June 30, 2022, the aggregate amount of the transaction price allocated to remaining performance obligations was $3.93 billion, which was substantially comprised of deferred security subscription and technical support services revenue. We expect to recognize approximately $2.01 billion as revenue over the next 12 months and the remainder thereafter.
  (was, 2022-05-06, similarity 0.9869):
[0001262039-22-000019:note_history:20]
As of March 31, 2022, the aggregate amount of the transaction price allocated to remaining performance obligations was $3.66 billion, which was substantially comprised of deferred security subscription and technical support services revenue. We expect to recognize approximately $1.89 billion as revenue over the next 12 months and the remainder thereafter.

- changed (2022-08-05):
[0001262039-22-000029:note_history:21]
The allowance for credit losses was $5.2 million and $2.4 million as of June 30, 2022 and December 31, 2021, respectively. Provisions, write-offs and recoveries were not material during the six months ended June 30, 2022 and 2021.
  (was, 2022-05-06, similarity 0.8221):
[0001262039-22-000019:note_history:21]
The allowance for credit losses was $2.5 million and $2.4 million as of March 31, 2022 and December 31, 2021, respectively. Provisions, write-offs and recoveries were not material during the three months ended March 31, 2022 and 2021.

- changed (2022-08-05):
[0001262039-22-000029:note_history:22]
Amortization of deferred contract costs during the three months ended June 30, 2022 and 2021 were $54.6 million and $42.1 million, respectively. Amortization of deferred contract costs during the six months ended June 30, 2022 and 2021 were $107.1 million and $81.8 million, respectively.
  (was, 2022-05-06, similarity 0.6462):
[0001262039-22-000019:note_history:22]
Amortization of deferred contract costs during the three months ended March 31, 2022 and 2021 were $52.5 million and $39.7 million, respectively.

- removed (2022-08-05):
[0001262039-22-000019:note_history:23]
|  | Three Months Ended |  |  |
|  | March 31,2022 |  | March 31,2021 |  |  |  |  |
| Product | $ | 371.0 |  |  | $ | 240.7 |  |  |  |  |  |
| Service: |  |  |  |  |  |  |  |
| Security subscription | 312.9 |  |  | 255.3 |  |  |  |  |  |
| Technical support and other | 270.9 |  |  | 214.3 |  |  |  |  |  |
| Total service revenue | 583.8 |  |  | 469.6 |  |  |  |  |  |
| Total revenue | $ | 954.8 |  |  | $ | 710.3 |  |  |  |  |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- added (2022-08-05):
[0001262039-22-000029:note_history:24]
SUBSEQUENT EVENTS
Real property purchase

- added (2022-08-05):
[0001262039-22-000029:note_history:25]
In July 2022, we purchased real property in Union City totaling approximately 59,000 square feet for a cash payment of $65.3 million.

- added (2022-08-05):
[0001262039-22-000029:note_history:26]
Share Repurchase Program

- added (2022-08-05):
[0001262039-22-000029:note_history:27]
In July 2022, our board of directors approved a $1.00 billion increase in the authorized stock repurchase under our share repurchase program. As of August 4, 2022, approximately $1.03 billion remained available for future share repurchases.

- removed (2022-08-05):
[0001262039-22-000019:note_history:28]
SUBSEQUENT EVENTS
Common Stock Split

- removed (2022-08-05):
[0001262039-22-000019:note_history:29]
On April 14, 2022, our Board of Directors approved a five-for-one forward stock split of our common stock, conditioned on obtaining stockholder approval at our upcoming 2022 Annual Meeting of Stockholders to be held on June 17, 2022 (the “Stock Split”). If approved by our stockholders, the Stock Split would be effected through an amendment and restatement of our amended and restated certificate of incorporation.
