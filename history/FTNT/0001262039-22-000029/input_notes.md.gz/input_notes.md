# FTNT notes — 0001262039-22-000029


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001262039-22-000029:notes:1]
SUMMARY OF SIGNIFICANT ACCOUNTING POLICIES
Basis of Presentation and Preparation—The unaudited condensed consolidated financial statements of Fortinet, Inc. and its subsidiaries (collectively, “we,” “us” or “our”) have been prepared in accordance with generally accepted accounting principles in the United States (“GAAP”) for interim financial information, as well as the instructions to Form 10-Q pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (the “SEC”). Accordingly, they do not include all of the information and footnotes required by GAAP for complete financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the year ended December 31, 2021, contained in our Annual Report on Form 10-K filed with the SEC on February 25, 2022. In the opinion of management, all adjustments, which include normal recurring adjustments, considered necessary for a fair presentation, have been included. The results of operations for the three and six months ended June 30, 2022 are not necessarily indicative of the results to be expected for the full year or for any future periods. The condensed consolidated balance sheet as of December 31, 2021 is derived from the audited consolidated financial statements for the year ended December 31, 2021.

[0001262039-22-000029:notes:2]
[same as prior period, unchanged from 0001262039-22-000019:notes:2]

[0001262039-22-000029:notes:3]
[same as prior period, unchanged from 0001262039-22-000019:notes:3]

[0001262039-22-000029:notes:4]
On April 14, 2022, our Board of Directors approved a five-for-one forward stock split of our common stock (the "Forward Stock Split"), which was conditioned upon obtaining stockholder approval for the Forward Stock Split, and to increase the number of our authorized shares of common stock. On June 17, 2022, at our 2022 Annual Meeting of Stockholders, our stockholders approved the Forward Stock Split and the amendment and restatement of our amended and restated certificate of incorporation to increase the number of authorized shares of common stock from 300 million to 1.5 billion. The par value of our common stock was not adjusted as a result of the Forward Stock Split. Effective June 22, 2022, we filed our amended and restated certification of incorporation and completed the Forward Stock Split. All share and per share amounts and related stockholders’ equity (deficit) balances presented herein have been retroactively adjusted to reflect the Forward Stock Split.

[0001262039-22-000029:notes:5]
There have been no material changes to our significant accounting policies as of and for the three and six months ended June 30, 2022.

[0001262039-22-000029:notes:6]
Recently Adopted and Recently Issued Accounting Standards

[0001262039-22-000029:notes:7]
There were no recently adopted accounting standards which would have a material effect on our condensed consolidated financial statements and accompanying disclosures, and no recently issued accounting standards that are expected to have a material impact on our condensed consolidated financial statements and accompanying disclosures.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001262039-22-000029:notes:8]
[same as prior period, unchanged from 0001262039-22-000019:notes:7]

[0001262039-22-000029:notes:9]
[same as prior period, unchanged from 0001262039-22-000019:notes:8]

[0001262039-22-000029:notes:10]
|  | Three Months Ended |  | Six Months Ended |
|  | June 30,2022 |  | June 30,2021 |  | June 30,2022 |  | June 30,2021 |
| Product | $ | 400.7 |  |  | $ | 298.3 |  |  | $ | 771.7 |  |  | $ | 539.0 |  |
| Service: |  |  |  |  |  |  |  |
| Security subscription | 340.4 |  |  | 272.9 |  |  | 653.3 |  |  | 528.2 |  |
| Technical support and other | 289.0 |  |  | 229.9 |  |  | 559.9 |  |  | 444.2 |  |
| Total service revenue | 629.4 |  |  | 502.8 |  |  | 1,213.2 |  |  | 972.4 |  |
| Total revenue | $ | 1,030.1 |  |  | $ | 801.1 |  |  | $ | 1,984.9 |  |  | $ | 1,511.4 |  |

[0001262039-22-000029:notes:11]
[same as prior period, unchanged from 0001262039-22-000019:notes:10]

[0001262039-22-000029:notes:12]
During the three and six months ended June 30, 2022, we recognized $457.6 million and $964.9 million in service revenue that was included in the deferred revenue balance as of December 31, 2021, respectively. During the three and six months ended June 30, 2021, we recognized $371.2 million and $789.1 million in service revenue that was included in the deferred revenue balance as of December 31, 2020, respectively.

[0001262039-22-000029:notes:13]
[same as prior period, unchanged from 0001262039-22-000019:notes:12]

[0001262039-22-000029:notes:14]
As of June 30, 2022, the aggregate amount of the transaction price allocated to remaining performance obligations was $3.93 billion, which was substantially comprised of deferred security subscription and technical support services revenue. We expect to recognize approximately $2.01 billion as revenue over the next 12 months and the remainder thereafter.

[0001262039-22-000029:notes:15]
[same as prior period, unchanged from 0001262039-22-000019:notes:14]

[0001262039-22-000029:notes:16]
[same as prior period, unchanged from 0001262039-22-000019:notes:15]

[0001262039-22-000029:notes:17]
The allowance for credit losses was $5.2 million and $2.4 million as of June 30, 2022 and December 31, 2021, respectively. Provisions, write-offs and recoveries were not material during the six months ended June 30, 2022 and 2021.

[0001262039-22-000029:notes:18]
[same as prior period, unchanged from 0001262039-22-000019:notes:17]

[0001262039-22-000029:notes:19]
Amortization of deferred contract costs during the three months ended June 30, 2022 and 2021 were $54.6 million and $42.1 million, respectively. Amortization of deferred contract costs during the six months ended June 30, 2022 and 2021 were $107.1 million and $81.8 million, respectively.


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0001262039-22-000029:notes:20]
FINANCIAL INSTRUMENTS AND FAIR VALUE
Available-for-sale Securities

[0001262039-22-000029:notes:21]
The following tables summarize our available-for-sale securities (in millions):

[0001262039-22-000029:notes:22]
|  | June 30, 2022 |
|  | AmortizedCost |  | UnrealizedGains |  | UnrealizedLosses |  | FairValue |
| Corporate debt securities | $ | 410.6 |  |  | $ | — |  |  | $ | (6.2) |  |  | $ | 404.4 |  |
| U.S. government and agency securities | 380.2 |  |  | — |  |  | (6.1) |  |  | 374.1 |  |
| Commercial paper | 306.4 |  |  | — |  |  | (1.4) |  |  | 305.0 |  |
| Certificates of deposit and term deposits | 120.8 |  |  | — |  |  | (0.4) |  |  | 120.4 |  |
| Municipal bonds | 5.3 |  |  | — |  |  | (0.1) |  |  | 5.2 |  |
| Total available-for-sale securities | $ | 1,223.3 |  |  | $ | — |  |  | $ | (14.2) |  |  | $ | 1,209.1 |  |

[0001262039-22-000029:notes:23]
|  | December 31, 2021 |
|  | AmortizedCost |  | UnrealizedGains |  | UnrealizedLosses |  | FairValue |
| Corporate debt securities | $ | 540.7 |  |  | $ | — |  |  | $ | (1.2) |  |  | $ | 539.5 |  |
| U.S. government and agency securities | 356.1 |  |  | — |  |  | (1.0) |  |  | 355.1 |  |
| Commercial paper | 566.0 |  |  | — |  |  | (0.2) |  |  | 565.8 |  |
| Certificates of deposit and term deposits | 169.1 |  |  | — |  |  | (0.1) |  |  | 169.0 |  |
| Municipal bonds | 5.4 |  |  | — |  |  | — |  |  | 5.4 |  |
| Total available-for-sale securities | $ | 1,637.3 |  |  | $ | — |  |  | $ | (2.5) |  |  | $ | 1,634.8 |  |

[0001262039-22-000029:notes:24]
[same as prior period, unchanged from 0001262039-22-000019:notes:22]

[0001262039-22-000029:notes:25]
|  | June 30, 2022 |
|  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
|  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |
| Corporate debt securities | $ | 376.2 |  |  | $ | (5.8) |  |  | $ | 25.7 |  |  | $ | (0.4) |  |  | $ | 401.9 |  |  | $ | (6.2) |  |
| U.S. government and agency securities | 359.3 |  |  | (5.9) |  |  | 14.9 |  |  | (0.2) |  |  | 374.2 |  |  | (6.1) |  |
| Commercial paper | 303.0 |  |  | (1.4) |  |  | — |  |  | — |  |  | 303.0 |  |  | (1.4) |  |
| Certificates of deposit and term deposits | 113.3 |  |  | (0.4) |  |  | — |  |  | — |  |  | 113.3 |  |  | (0.4) |  |
| Municipal bonds | 5.1 |  |  | (0.1) |  |  | — |  |  | — |  |  | 5.1 |  |  | (0.1) |  |
| Total available-for-sale securities | $ | 1,156.9 |  |  | $ | (13.6) |  |  | $ | 40.6 |  |  | $ | (0.6) |  |  | $ | 1,197.5 |  |  | $ | (14.2) |  |

[0001262039-22-000029:notes:26]
|  | December 31, 2021 |
|  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
|  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |
| Corporate debt securities | $ | 494.4 |  |  | $ | (1.2) |  |  | $ | — |  |  | $ | — |  |  | $ | 494.4 |  |  | $ | (1.2) |  |
| U.S. government and agency securities | 334.2 |  |  | (1.0) |  |  | — |  |  | — |  |  | 334.2 |  |  | (1.0) |  |
| Commercial paper | 288.0 |  |  | (0.2) |  |  | — |  |  | — |  |  | 288.0 |  |  | (0.2) |  |
| Certificates of deposit and term deposits | 93.1 |  |  | (0.1) |  |  | — |  |  | — |  |  | 93.1 |  |  | (0.1) |  |
| Municipal bonds | 5.3 |  |  | — |  |  | — |  |  | — |  |  | 5.3 |  |  | — |  |
| Total available-for-sale securities | $ | 1,215.0 |  |  | $ | (2.5) |  |  | $ | — |  |  | $ | — |  |  | $ | 1,215.0 |  |  | $ | (2.5) |  |

[0001262039-22-000029:notes:27]
[same as prior period, unchanged from 0001262039-22-000019:notes:25]

[0001262039-22-000029:notes:28]
|  | June 30,2022 |  | December 31,2021 |
| Due within one year | $ | 1,020.6 |  |  | $ | 1,194.0 |  |
| Due within one to three years | 188.5 |  |  | 440.8 |  |
| Total | $ | 1,209.1 |  |  | $ | 1,634.8 |  |

[0001262039-22-000029:notes:29]
Available-for-sale securities are reported at fair value, with unrealized gains and losses and the related tax impact included as a separate component of equity (deficit) and in comprehensive income. We do not intend to sell any of the securities in an unrealized loss position and it is not more likely than not that we would be required to sell these securities before recovery of their amortized cost basis, which may be at maturity.

[0001262039-22-000029:notes:30]
[same as prior period, unchanged from 0001262039-22-000019:notes:28]

[0001262039-22-000029:notes:31]
Marketable Equity Securities

[0001262039-22-000029:notes:32]
Our marketable equity securities were $24.3 million and $38.6 million as of June 30, 2022 and December 31, 2021. The changes in fair value of our marketable equity securities are recorded in other expense, net on the condensed consolidated statements of income. We recognized $8.1 million and $14.3 million loss during the three and six months ended June 30, 2022, respectively. We recognized $0.5 million and $0.8 million gain during the three and six months ended June 30, 2021, respectively.

[0001262039-22-000029:notes:33]
[same as prior period, unchanged from 0001262039-22-000019:notes:37]

[0001262039-22-000029:notes:34]
[same as prior period, unchanged from 0001262039-22-000019:notes:30]

[0001262039-22-000029:notes:35]
[same as prior period, unchanged from 0001262039-22-000019:notes:31]

[0001262039-22-000029:notes:36]
[same as prior period, unchanged from 0001262039-22-000019:notes:32]

[0001262039-22-000029:notes:37]
[same as prior period, unchanged from 0001262039-22-000019:notes:33]

[0001262039-22-000029:notes:38]
[same as prior period, unchanged from 0001262039-22-000019:notes:34]

[0001262039-22-000029:notes:39]
[same as prior period, unchanged from 0001262039-22-000019:notes:35]

[0001262039-22-000029:notes:40]
[same as prior period, unchanged from 0001262039-22-000019:notes:36]

[0001262039-22-000029:notes:41]
[same as prior period, unchanged from 0001262039-22-000019:notes:38]

[0001262039-22-000029:notes:42]
[same as prior period, unchanged from 0001262039-22-000019:notes:39]

[0001262039-22-000029:notes:43]
|  | June 30, 2022 |  | December 31, 2021 |
|  | AggregateFairValue |  | QuotedPrices inActiveMarkets ForIdenticalAssets |  | SignificantOtherObservableRemainingInputs |  | SignificantOtherUnobservableRemainingInputs |  | AggregateFairValue |  | QuotedPrices inActiveMarkets ForIdenticalAssets |  | SignificantOtherObservableRemainingInputs |  | SignificantOtherUnobservableRemainingInputs |
|  |  |  | (Level 1) |  | (Level 2) |  | (Level 3) |  |  |  | (Level 1) |  | (Level 2) |  | (Level 3) |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate debt securities | $ | 404.4 |  |  | $ | — |  |  | $ | 404.4 |  |  | $ | — |  |  | $ | 542.5 |  |  | $ | — |  |  | $ | 542.5 |  |  | $ | — |  |
| U.S. government and agency securities | 374.1 |  |  | 364.6 |  |  | 9.5 |  |  | — |  |  | 355.1 |  |  | 345.2 |  |  | 9.9 |  |  | — |  |
| Commercial paper | 305.0 |  |  | — |  |  | 305.0 |  |  | — |  |  | 580.3 |  |  | — |  |  | 580.3 |  |  | — |  |
| Certificates of deposit and term deposits | 120.5 |  |  | — |  |  | 120.5 |  |  | — |  |  | 259.0 |  |  | — |  |  | 259.0 |  |  | — |  |
| Money market funds | 277.7 |  |  | 277.7 |  |  | — |  |  | — |  |  | 57.5 |  |  | 57.5 |  |  | — |  |  | — |  |
| Municipal bonds | 5.2 |  |  | — |  |  | 5.2 |  |  | — |  |  | 5.4 |  |  | — |  |  | 5.4 |  |  | — |  |
| Marketable equity securities | 24.3 |  |  | 24.3 |  |  | — |  |  | — |  |  | 38.6 |  |  | 38.6 |  |  | — |  |  | — |  |
| Total | $ | 1,511.2 |  |  | $ | 666.6 |  |  | $ | 844.6 |  |  | $ | — |  |  | $ | 1,838.4 |  |  | $ | 441.3 |  |  | $ | 1,397.1 |  |  | $ | — |  |
| Reported as: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents | $ | 277.8 |  |  |  |  |  |  |  |  | $ | 165.0 |  |  |  |  |  |  |  |
| Marketable equity securities | 24.3 |  |  |  |  |  |  |  |  | 38.6 |  |  |  |  |  |  |  |
| Short-term investments | 1,020.6 |  |  |  |  |  |  |  |  | 1,194.0 |  |  |  |  |  |  |  |
| Long-term investments | 188.5 |  |  |  |  |  |  |  |  | 440.8 |  |  |  |  |  |  |  |
| Total | $ | 1,511.2 |  |  |  |  |  |  |  |  | $ | 1,838.4 |  |  |  |  |  |  |  |

[0001262039-22-000029:notes:44]
There were no transfers between Level 1 and Level 2 of the fair value hierarchy during the six months ended June 30, 2022 and year ended December 31, 2021.


## us-gaap:InventoryDisclosureTextBlock

[0001262039-22-000029:notes:45]
[same as prior period, unchanged from 0001262039-22-000019:notes:42]

[0001262039-22-000029:notes:46]
|  | June 30,2022 |  | December 31,2021 |
| Raw materials | $ | 41.3 |  |  | $ | 40.2 |  |
| Work in process | 9.6 |  |  | 9.8 |  |
| Finished goods | 144.3 |  |  | 125.8 |  |
| Inventory | $ | 195.2 |  |  | $ | 175.8 |  |


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001262039-22-000029:notes:47]
[same as prior period, unchanged from 0001262039-22-000019:notes:44]

[0001262039-22-000029:notes:48]
|  | June 30,2022 |  | December 31,2021 |
| Land | $ | 253.4 |  |  | $ | 204.5 |  |
| Buildings and improvements | 475.3 |  |  | 416.2 |  |
| Computer equipment and software | 207.8 |  |  | 176.1 |  |
| Leasehold improvements | 48.8 |  |  | 40.1 |  |
| Evaluation units | 14.0 |  |  | 15.6 |  |
| Furniture and fixtures | 30.4 |  |  | 26.9 |  |
| Construction-in-progress | 27.5 |  |  | 19.9 |  |
| Total property and equipment | 1,057.2 |  |  | 899.3 |  |
| Less: accumulated depreciation | (242.6) |  |  | (211.7) |  |
| Property and equipment—net | $ | 814.6 |  |  | $ | 687.6 |  |

[0001262039-22-000029:notes:49]
Depreciation expense was $19.1 million and $15.3 million during the three months ended June 30, 2022 and 2021, respectively. Depreciation expense was $38.2 million and $29.3 million during the six months ended June 30, 2022 and 2021, respectively.


## us-gaap:InvestmentTextBlock

[0001262039-22-000029:notes:50]
[same as prior period, unchanged from 0001262039-22-000019:notes:47]

[0001262039-22-000029:notes:51]
On March 19, 2021, we invested $75.0 million in cash for shares of the Series A Preferred Stock of Linksys for a 32.6% ownership interest in this privately-held company. On September 24, 2021, we invested an additional $85.0 million in cash for shares of Series A Preferred Stock of Linksys, and as of June 30, 2022 and December 31, 2021, we held 50.8% of the outstanding common stock (on an as-converted basis) of Linksys. Linksys provides router connectivity solutions to the consumer and small business markets.

[0001262039-22-000029:notes:52]
We have concluded that our investment in Linksys is an in-substance common stock investment and that we do not hold an absolute controlling financial interest in Linksys, but that we have the ability to exercise significant influence over the operating and financial policies of Linksys. Determining that we have significant influence but not control over the operating and financial policies of Linksys required significant judgement of many factors, including but not limited to the ownership interest in Linksys, board representation, participation in policy-making processes and participation rights in certain significant financial and operating decisions of Linksys in the ordinary course of business. Therefore, we determined to account for this investment using the equity method of accounting. We record our share of Linksys’ financial results on a three-month lag basis. We determined that there was a basis difference between the cost of our investment in Linksys and the amount of underlying equity in net assets of Linksys. Our share of loss of Linksys’ financial results, as well as our share of the amortization of the basis differences, in total was $8.1 million and $16.6 million for the three and six months ended June 30, 2022, and has been recorded in loss from equity method investment on the condensed consolidated statements of income. As of June 30, 2022 and December 31, 2021, the investment was included in other assets on our condensed consolidated balance sheets. Transaction costs related to this investment were not material.
Due to the presence of impairment indicators, such as a series of operating losses, we evaluated our equity method investment for an other-than-temporary impairment (“OTTI”) during the three months ended June 30, 2022. We considered various factors in determining whether an OTTI has occurred, including the limited operating history available, our ability and intent to hold the investment until its fair value recovers, the implied revenue valuation multiples compared to guideline public companies, Linksys’ ability to achieve milestones and any notable operational and strategic changes. After the evaluation, we determined that an OTTI has not occurred as of June 30, 2022 and as of the date of this Quarterly Report on Form 10-Q. However, we may be required to recognize an impairment loss in future reporting periods if and when our evaluation of the aforementioned factors indicates that the investment in Linksys is determined to be other than temporarily impaired. Such determination will be based on the prevailing facts and circumstances at that time, including the reported results and disclosures of Linksys.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001262039-22-000029:notes:53]
[same as prior period, unchanged from 0001262039-22-000019:notes:51]

[0001262039-22-000029:notes:54]
[same as prior period, unchanged from 0001262039-22-000019:notes:52]

[0001262039-22-000029:notes:55]
On August 31, 2021, we closed an acquisition of 75% of equity interests as controlling interests in Alaxala Networks Corporation (“Alaxala”), a privately held network hardware equipment company in Japan, for $64.2 million in cash. We acquired the equity interests in Alaxala to broaden our offering of secure switches integrated with our Core Platform and Platform Extension functionality, and, over time, to innovate and rebrand certain of Alaxala’s switches to offer a broader suite of secure switches globally.

[0001262039-22-000029:notes:56]
[same as prior period, unchanged from 0001262039-22-000019:notes:55]

[0001262039-22-000029:notes:57]
[same as prior period, unchanged from 0001262039-22-000019:notes:56]

[0001262039-22-000029:notes:58]
[same as prior period, unchanged from 0001262039-22-000019:notes:57]

[0001262039-22-000029:notes:59]
[same as prior period, unchanged from 0001262039-22-000019:notes:58]

[0001262039-22-000029:notes:60]
[same as prior period, unchanged from 0001262039-22-000019:notes:59]

[0001262039-22-000029:notes:61]
[same as prior period, unchanged from 0001262039-22-000019:notes:60]

[0001262039-22-000029:notes:62]
Developed technology relates to Alaxala’s network equipment. We valued the developed technology using the relief-from-royalty method under the income approach. This method reflects the present value of the projected cost savings that are expected to be realized by the owner of the royalty granted in exchange for the use of the asset. The economic useful life was determined based on the technology cycle related to each developed technology, as well as the cash flows over the forecast period.

[0001262039-22-000029:notes:63]
[same as prior period, unchanged from 0001262039-22-000019:notes:63]

[0001262039-22-000029:notes:64]
[same as prior period, unchanged from 0001262039-22-000019:notes:64]

[0001262039-22-000029:notes:65]
[same as prior period, unchanged from 0001262039-22-000019:notes:65]

[0001262039-22-000029:notes:66]
[same as prior period, unchanged from 0001262039-22-000019:notes:66]

[0001262039-22-000029:notes:67]
[same as prior period, unchanged from 0001262039-22-000019:notes:67]

[0001262039-22-000029:notes:68]
|  | Three Months Ended |  | Six Months Ended |
|  | June 30,2021 |  |  |  | June 30,2021 |  |  |
| Pro forma revenue | $ | 825.2 |  |  |  |  | $ | 1,572.6 |  |  |  |
| Pro forma net income attributable to Fortinet, Inc. | $ | 134.9 |  |  |  |  | $ | 242.4 |  |  |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001262039-22-000029:notes:69]
[same as prior period, unchanged from 0001262039-22-000019:notes:71]

[0001262039-22-000029:notes:70]
[same as prior period, unchanged from 0001262039-22-000019:notes:72]

[0001262039-22-000029:notes:71]
|  | Amount |
| Balance—December 31, 2021 | $ | 125.1 |  |
| Foreign currency translation adjustments | (3.8) |  |
| Balance—June 30, 2022 | $ | 121.3 |  |

[0001262039-22-000029:notes:72]
There were no impairments to goodwill during the six months ended June 30, 2022 or during prior periods.

[0001262039-22-000029:notes:73]
[same as prior period, unchanged from 0001262039-22-000019:notes:75]

[0001262039-22-000029:notes:74]
[same as prior period, unchanged from 0001262039-22-000019:notes:76]

[0001262039-22-000029:notes:75]
|  | June 30, 2022 |
|  | Weighted-Average Useful Life (in Years) |  | Gross |  | Accumulated Amortization |  | Net |
| Other intangible assets—net: |  |  |  |  |  |  |  |
| Finite-lived intangible assets: |  |  |  |  |  |  |  |
| Developed technologies | 4.0 |  | $ | 78.2 |  |  | $ | 45.7 |  |  | $ | 32.5 |  |
| Customer relationships | 5.7 |  | 20.7 |  |  | 13.1 |  |  | 7.6 |  |
| Trade name | 10.0 |  | 5.1 |  |  | 0.4 |  |  | 4.7 |  |
| Backlog | 1.0 |  | 4.0 |  |  | 3.4 |  |  | 0.6 |  |
| Total other intangible assets—net |  |  | $ | 108.0 |  |  | $ | 62.6 |  |  | $ | 45.4 |  |

[0001262039-22-000029:notes:76]
[same as prior period, unchanged from 0001262039-22-000019:notes:78]

[0001262039-22-000029:notes:77]
Amortization expense was $6.0 million and $3.5 million during the three months ended June 30, 2022 and 2021, respectively. Amortization expense was $12.4 million and $6.9 million during the six months ended June 30, 2022 and 2021, respectively.

[0001262039-22-000029:notes:78]
[same as prior period, unchanged from 0001262039-22-000019:notes:80]

[0001262039-22-000029:notes:79]
|  | Amount |
| Years: |  |
| 2022 (the remainder of 2022) | $ | 9.1 |  |
| 2023 | 14.9 |  |
| 2024 | 10.2 |  |
| 2025 | 5.2 |  |
| 2026 | 1.1 |  |
| Thereafter | 4.9 |  |
| Total | $ | 45.4 |  |


## us-gaap:EarningsPerShareTextBlock

[0001262039-22-000029:notes:80]
NET INCOME PER SHARE
Basic net income per share is computed by dividing net income attributable to Fortinet, Inc., by the weighted-average number of shares of common stock outstanding during the period. Diluted net income per share is computed by dividing net income attributable to Fortinet, Inc. by the weighted-average number of shares of common stock outstanding during the period, plus the dilutive effects of restricted stock units (“RSUs”) and stock options. Dilutive shares of common stock are determined by applying the treasury stock method.

[0001262039-22-000029:notes:81]
A reconciliation of the numerator and denominator used in the calculation of basic and diluted net income per share attributable to Fortinet, Inc. is as follows (in millions, except per share amounts):

[0001262039-22-000029:notes:82]
|  | Three Months Ended |  | Six Months Ended |
|  | June 30,2022 |  | June 30,2021 |  | June 30,2022 |  | June 30,2021 |
| Numerator: |  |  |  |  |  |  |  |
| Net income including non-controlling interests | $ | 173.4 |  |  | $ | 137.5 |  |  | $ | 311.7 |  |  | $ | 244.7 |  |
| Net loss attributable to non-controlling interests | (0.1) |  |  | — |  |  | (0.2) |  |  | — |  |
| Net income attributable to Fortinet, Inc. | $ | 173.5 |  |  | $ | 137.5 |  |  | $ | 311.9 |  |  | $ | 244.7 |  |
| Denominator: |  |  |  |  |  |  |  |
| Basic shares: |  |  |  |  |  |  |  |
| Weighted-average common stock outstanding-basic | 795.4 |  |  | 816.7 |  |  | 799.4 |  |  | 815.9 |  |
| Diluted shares: |  |  |  |  |  |  |  |
| Weighted-average common stock outstanding-basic | 795.4 |  |  | 816.7 |  |  | 799.4 |  |  | 815.9 |  |
| Effect of potentially dilutive securities: |  |  |  |  |  |  |  |
| RSUs | 6.4 |  |  | 11.0 |  |  | 7.5 |  |  | 10.6 |  |
| Stock options | 8.3 |  |  | 7.7 |  |  | 8.5 |  |  | 7.2 |  |
| Weighted-average shares used to compute diluted net income per share attributable to Fortinet, Inc. | 810.1 |  |  | 835.4 |  |  | 815.4 |  |  | 833.7 |  |
| Net income per share attributable to Fortinet, Inc.: |  |  |  |  |  |  |  |
| Basic | $ | 0.22 |  |  | $ | 0.17 |  |  | $ | 0.39 |  |  | $ | 0.30 |  |
| Diluted | $ | 0.21 |  |  | $ | 0.16 |  |  | $ | 0.38 |  |  | $ | 0.29 |  |

[0001262039-22-000029:notes:83]
[same as prior period, unchanged from 0001262039-22-000019:notes:84]

[0001262039-22-000029:notes:84]
|  | Three Months Ended |  | Six Months Ended |
|  | June 30,2022 |  | June 30,2021 |  | June 30,2022 |  | June 30,2021 |
| RSUs | 0.4 |  |  | 0.4 |  |  | 0.4 |  |  | 1.1 |  |
| Stock options | 1.6 |  |  | 2.5 |  |  | 1.2 |  |  | 2.1 |  |
| Total | 2.0 |  |  | 2.9 |  |  | 1.6 |  |  | 3.2 |  |


## us-gaap:DebtDisclosureTextBlock

[0001262039-22-000029:notes:85]
DEBT
2026 and 2031 Senior Notes

[0001262039-22-000029:notes:86]
On March 5, 2021, we issued $1.0 billion aggregate principal amount of senior notes (collectively, the “Senior Notes”), consisting of $500.0 million aggregate principal amount of 1.0% notes due March 15, 2026 (the “2026 Senior Notes”) and $500.0 million aggregate principal amount of 2.2% notes due March 15, 2031 (the “2031 Senior Notes”), in an underwritten registered public offering. The Senior Notes are senior unsecured obligations and rank equally with each other in right of payment and with our other outstanding obligations. We may redeem the Senior Notes at any time in whole or in part for cash, at specified redemption prices that include accrued and unpaid interest, if any, and a make-whole premium. However, no make-whole premium will be paid for redemptions of the 2026 Senior Notes on or after February 15, 2026, or the 2031 Senior Notes on or after December 15, 2030. Interest on the Senior Notes is payable on March 15 and September 15 of each year, beginning on September 15, 2021. As of June 30, 2022 and December 31, 2021, the Senior Notes were recorded as long-term debt, net of discount and issuance costs, which are amortized to interest expense over the respective contractual terms of these notes using the effective interest method.

[0001262039-22-000029:notes:87]
The total outstanding debt is summarized below (in millions, except percentages):

[0001262039-22-000029:notes:88]
|  | Maturity |  | Coupon Rate |  | Effective Interest Rate |  | June 30,2022 |  | December 31,2021 |
| Debt |  |  |  |  |  |  |  |  |  |
| 2026 Senior Notes | March 2026 |  | 1.0% |  | 1.3% |  | $ | 500.0 |  |  | $ | 500.0 |  |
| 2031 Senior Notes | March 2031 |  | 2.2% |  | 2.3% |  | 500.0 |  |  | 500.0 |  |
| Total debt |  |  |  |  |  |  | 1,000.0 |  |  | 1,000.0 |  |
| Less: Unamortized discount and debt issuance costs |  |  |  |  |  |  | 10.6 |  |  | 11.6 |  |
| Total long-term debt |  |  |  |  |  |  | $ | 989.4 |  |  | $ | 988.4 |  |

[0001262039-22-000029:notes:89]
As of June 30, 2022 and December 31, 2021, we accrued interest payable of $4.7 million, and there are no financial covenants with which we must comply. During the three months ended June 30, 2022 and 2021 we recorded $4.5 million of total interest expense in relation to these Senior Notes in each quarter. During the six months ended June 30, 2022 and 2021 we recorded $9.0 million and $5.8 million of total interest expense in relation to these Senior Notes, respectively. No interest costs were capitalized for the three months or six months ended June 30, 2022 and 2021, as the costs that qualified for capitalization were not material.

[0001262039-22-000029:notes:90]
The total estimated fair value of the outstanding Senior Notes was approximately $848.4 million, including accrued and unpaid interest, as of June 30, 2022. The fair value was determined based on observable market prices of identical instruments in less active markets. The estimated fair values are based on Level 2 inputs.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001262039-22-000029:notes:91]
COMMITMENTS AND CONTINGENCIES
The following table summarizes our inventory purchase commitments as of June 30, 2022 (in millions):

[0001262039-22-000029:notes:92]
|  | Total |  | 2022 |  | Thereafter |
| Inventory purchase commitments | $ | 1,492.1 |  |  | $ | 1,203.4 |  |  | $ | 288.7 |  |

[0001262039-22-000029:notes:93]
Inventory Purchase Commitments—Our independent contract manufacturers and certain component suppliers procure components and build our products based on our forecasts and the availability of various components. These forecasts are based on estimates of future demand for our products, which are in turn based on historical trends and an analysis from our sales and marketing organizations, adjusted for extended lead times, changes in supplier delivery commitments and other supply chain matters and other market conditions. In order to manage manufacturing lead times, plan for adequate component supply and incentivize suppliers to deliver, we may issue purchase orders to some of our independent contract manufacturers which are non-cancelable. As of June 30, 2022 and December 31, 2021, we had $1.49 billion and $1.14 billion, respectively, of open purchase orders with our independent contract manufacturers that are non-cancelable.

[0001262039-22-000029:notes:94]
Other Contractual Commitments and Open Purchase Orders—In addition to commitments with contract manufacturers, we have open purchase orders and contractual obligations in the ordinary course of business for which we have not received goods or services. A significant portion of our reported purchase commitments consist of firm and non-cancelable commitments. In certain instances, contractual commitments allow us the option to cancel, reschedule and adjust our requirements based on our business needs prior to firm orders being placed. As of June 30, 2022 and December 31, 2021, we had $117.1 million and $126.7 million, respectively, in other contractual commitments having a remaining term in excess of one year that are non-cancelable and an additional $80.0 million and $68.9 million, respectively, in contractual commitments for operating lease liabilities.

[0001262039-22-000029:notes:95]
Litigation—We are involved in disputes, litigation, and other legal actions. For lawsuits where we are the defendant, we are in the process of defending these litigation matters, and while there can be no assurances and the outcome of certain of these matters is currently not determinable and not predictable, we currently are unaware of any existing claims or proceedings that we believe are likely to have a material adverse effect on our financial position. There are many uncertainties associated with any litigation and these actions or other third-party claims against us may cause us to incur costly litigation fees, costs and substantial settlement charges, and possibly subject us to damages and other penalties. In addition, the resolution of any IP litigation may require us to make royalty payments, which could adversely affect our gross margins in future periods. If any of those events were to occur, our business, financial condition, results of operations, and cash flows could be adversely affected. Litigation is unpredictable and the actual liability in any such matters may be materially different from our current estimates, which could result in the need to adjust any accrued liability and record additional expenses. We accrue for contingencies when we believe that a loss is probable and that we can reasonably estimate the amount of any such loss. These accruals are generally based on a range of possible outcomes that require significant management judgement. If no amount within a range is a better estimate than any other, we accrue the minimum amount.

[0001262039-22-000029:notes:96]
In December 2021, we entered into an agreement that provided for settlement and dismissal of an existing patent infringement lawsuit and a mutual covenant-not-to-sue for a defined duration of time. We have settled and paid $10.0 million in cash, of which $5.6 million was related to the dismissal of the lawsuit and was expensed as a general and administrative expense, and $4.4 million was deferred and will be expensed over time as royalty cost of revenue. Litigation loss contingency accruals associated with other outstanding cases were not material as of June 30, 2022 and December 31, 2021.

[0001262039-22-000029:notes:97]
Indemnification and Other Matters—Under the indemnification provisions of our standard sales contracts, we agree to defend our customers against third-party claims asserting various allegations such as product defects and infringement of certain IP rights, which may include patents, copyrights, trademarks or trade secrets, and to pay judgments entered on such claims. In some contracts, our exposure under these indemnification provisions is limited by the terms of the contracts to certain defined limits, such as the total amount paid by our customer under the agreement. However, certain agreements include covenants, penalties and indemnification provisions including and beyond indemnification for third-party claims of IP infringement that could potentially expose us to losses in excess of the amount received under the agreement, and in some instances to potential liability that is not contractually limited. Although from time to time there are indemnification claims asserted against us and currently there are pending indemnification claims, to date there have been no material awards under such indemnification provisions.

[0001262039-22-000029:notes:98]
Similar to other security companies and companies in other industries, we have in the past experienced, and we may in the future experience, cybersecurity threats, malicious activity directed against our information technology infrastructure or 
unauthorized attempts to gain access to our and our customers’ sensitive information and systems. We currently are unaware of any existing claims or proceedings related to these types of matters, including any that we believe are likely to have a material adverse effect on our financial position.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001262039-22-000029:notes:99]
EQUITY (DEFICIT)
Stock-Based Compensation Plans

[0001262039-22-000029:notes:100]
We maintain the Amended and Restated Fortinet, Inc. 2009 Equity Incentive Plan (the “Amended Plan”) pursuant to which we have granted RSUs and stock options. As of June 30, 2022, there were a total of 57.3 million shares of common stock available for grant under the Amended Plan.

[0001262039-22-000029:notes:101]
[same as prior period, unchanged from 0001262039-22-000019:notes:106]

[0001262039-22-000029:notes:102]
[same as prior period, unchanged from 0001262039-22-000019:notes:107]

[0001262039-22-000029:notes:103]
|  | Restricted Stock Units Outstanding |
|  | Number of Shares |  | Weighted-Average Grant Date Fair Value per Share |
| Balance—December 31, 2021 | 15.7 |  |  | $ | 27.06 |  |
| Granted | 2.7 |  |  | 60.67 |  |
| Forfeited | (0.7) |  |  | 33.06 |  |
| Vested | (4.9) |  |  | 22.36 |  |
| Balance—June 30, 2022 | 12.8 |  |  | $ | 35.61 |  |

[0001262039-22-000029:notes:104]
Stock compensation expense is recognized on a straight-line basis over the vesting period of each RSU. As of June 30, 2022, total compensation expense related to unvested RSUs granted to employees and non-employees under the Amended Plan, but not yet recognized, was $413.7 million, with a weighted-average remaining vesting period of 2.7 years.

[0001262039-22-000029:notes:105]
[same as prior period, unchanged from 0001262039-22-000019:notes:110]

[0001262039-22-000029:notes:106]
[same as prior period, unchanged from 0001262039-22-000019:notes:111]

[0001262039-22-000029:notes:107]
|  | Three Months Ended |  | Six Months Ended |
|  | June 30,2022 |  | June 30,2021 |  | June 30,2022 |  | June 30,2021 |
| Shares withheld for taxes | 0.6 |  |  | 0.9 |  |  | 1.7 |  |  | 2.2 |  |
| Amount withheld for taxes | $ | 35.3 |  |  | $ | 34.7 |  |  | $ | 100.1 |  |  | $ | 76.1 |  |

[0001262039-22-000029:notes:108]
[same as prior period, unchanged from 0001262039-22-000019:notes:113]

[0001262039-22-000029:notes:109]
[same as prior period, unchanged from 0001262039-22-000019:notes:114]

[0001262039-22-000029:notes:110]
|  | Three Months Ended |  | Six Months Ended |
|  | June 30,2022 |  | June 30,2021 |  | June 30,2022 |  | June 30,2021 |
| Expected term in years | 4.4 |  | 4.4 |  | 4.4 |  | 4.4 |
| Volatility | 43.6 | % |  | 36.6 | % |  | 41.1 | % |  | 39.4 | % |
| Risk-free interest rate | 2.9 | % |  | 0.7 | % |  | 1.9 | % |  | 0.5 | % |
| Dividend rate | — | % |  | — | % |  | — | % |  | — | % |

[0001262039-22-000029:notes:111]
[same as prior period, unchanged from 0001262039-22-000019:notes:116]

[0001262039-22-000029:notes:112]
|  | Options Outstanding |
|  | Numberof Shares |  | Weighted-AverageExercisePrice |  | Weighted-AverageRemainingContractualLife (Years) |  | AggregateIntrinsicValue |
| Balance—December 31, 2021 | 13.7 |  |  | $ | 18.57 |  |  | 4.0 |  | $ | 729.9 |  |
| Granted | 1.4 |  |  | 61.71 |  |  |  |  |  |
| Forfeited | (0.1) |  |  | 35.94 |  |  |  |  |  |
| Exercised | (1.0) |  |  | 16.30 |  |  |  |  |  |
| Balance—June 30, 2022 | 14.0 |  |  | $ | 22.83 |  |  |  |  |  |
| Options vested and expected to vest—June 30, 2022 | 14.0 |  |  | $ | 22.83 |  |  | 3.8 |  | $ | 482.2 |  |
| Options exercisable—June 30, 2022 | 9.0 |  |  | $ | 14.10 |  |  | 2.9 |  | $ | 383.8 |  |

[0001262039-22-000029:notes:113]
The aggregate intrinsic value represents the difference between the exercise price of stock options and the quoted market price of our common stock on June 30, 2022 for all in-the-money stock options. Stock compensation expense is recognized on a straight-line basis over the vesting period of each stock option. As of June 30, 2022, total compensation expense related to unvested stock options granted to employees but not yet recognized was $61.6 million, with a weighted-average remaining vesting period of 2.9 years.

[0001262039-22-000029:notes:114]
[same as prior period, unchanged from 0001262039-22-000019:notes:119]

[0001262039-22-000029:notes:115]
|  | Three Months Ended |  | Six Months Ended |
|  | June 30,2022 |  | June 30,2021 |  | June 30,2022 |  | June 30,2021 |
| Weighted-average fair value per share granted | $ | 21.33 |  |  | $ | 12.28 |  |  | $ | 22.28 |  |  | $ | 11.35 |  |
| Intrinsic value of options exercised | $ | 13.8 |  |  | $ | 16.9 |  |  | $ | 43.7 |  |  | $ | 39.3 |  |
| Fair value of options vested | $ | 4.8 |  |  | $ | 3.7 |  |  | $ | 15.0 |  |  | $ | 10.7 |  |

[0001262039-22-000029:notes:116]
[same as prior period, unchanged from 0001262039-22-000019:notes:121]

[0001262039-22-000029:notes:117]
[same as prior period, unchanged from 0001262039-22-000019:notes:122]

[0001262039-22-000029:notes:118]
|  | Three Months Ended |  | Six Months Ended |
|  | June 30,2022 |  | June 30,2021 |  | June 30,2022 |  | June 30,2021 |
| Cost of product revenue | $ | 0.4 |  |  | $ | 0.5 |  |  | $ | 0.8 |  |  | $ | 0.9 |  |
| Cost of service revenue | 4.7 |  |  | 3.8 |  |  | 9.2 |  |  | 7.3 |  |
| Research and development | 16.1 |  |  | 14.5 |  |  | 31.2 |  |  | 27.5 |  |
| Sales and marketing | 26.4 |  |  | 27.7 |  |  | 53.1 |  |  | 54.5 |  |
| General and administrative | 7.7 |  |  | 7.0 |  |  | 14.9 |  |  | 13.3 |  |
| Total stock-based compensation expense | $ | 55.3 |  |  | $ | 53.5 |  |  | $ | 109.2 |  |  | $ | 103.5 |  |

[0001262039-22-000029:notes:119]
[same as prior period, unchanged from 0001262039-22-000019:notes:124]

[0001262039-22-000029:notes:120]
|  | Three Months Ended |  | Six Months Ended |
|  | June 30,2022 |  | June 30,2021 |  | June 30,2022 |  | June 30,2021 |
| RSUs | $ | 49.0 |  |  | $ | 48.5 |  |  | $ | 97.3 |  |  | $ | 94.3 |  |
| Stock options | 6.3 |  |  | 5.0 |  |  | 11.9 |  |  | 9.2 |  |
| Total stock-based compensation expense | $ | 55.3 |  |  | $ | 53.5 |  |  | $ | 109.2 |  |  | $ | 103.5 |  |

[0001262039-22-000029:notes:121]
[same as prior period, unchanged from 0001262039-22-000019:notes:126]

[0001262039-22-000029:notes:122]
|  | Three Months Ended |  | Six Months Ended |
|  | June 30,2022 |  | June 30,2021 |  | June 30,2022 |  | June 30,2021 |
| Income tax benefit associated with stock-based compensation | $ | 12.2 |  |  | $ | 11.8 |  |  | $ | 24.0 |  |  | $ | 22.8 |  |

[0001262039-22-000029:notes:123]
[same as prior period, unchanged from 0001262039-22-000019:notes:128]

[0001262039-22-000029:notes:124]
In October 2021, under the Share Repurchase Program originally approved by our board of directors in January 2016 (the “Repurchase Program”), our board of directors approved a $1.25 billion increase and extended the term to February 28, 2023, bringing the aggregate amount authorized to be repurchased to $4.25 billion. Share repurchases may be made by us from time to time in privately negotiated transactions or in open-market transactions. The Repurchase Program does not require us to purchase a minimum number of shares, and may be suspended, modified or discontinued at any time without prior notice. Refer to Note 16. Subsequent Events for information of the approved $1.0 billion increase in the authorized stock repurchase under the Repurchase Program in July 2022.

[0001262039-22-000029:notes:125]
During the three and six months ended June 30, 2022, we repurchased 14.4 million and 25.8 million shares of common stock, respectively, under the Repurchase Program in open-market transactions at a weighted-average price of $55.45 per share and $57.82 per share, respectively, for an aggregate purchase price of $800.0 million and $1.49 billion, respectively. As of June 30, 2022, $29.6 million remained available for future share repurchases under the Repurchase Program.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001262039-22-000029:notes:126]
INCOME TAXES
Our effective tax rate was 1% for the three months ended June 30, 2022, compared to an effective tax rate of 5% for the same period last year. Our effective tax rate was negative 2% for the six months ended June 30, 2022, compared to an effective tax rate of 7% for the same period last year. The effective tax rates for the periods presented are primarily comprised of U.S. federal and state taxes, withholding taxes, foreign taxes, the tax benefit from foreign-derived intangible income deduction (the “FDII deduction”) and excess tax benefits from stock-based compensation expense. The tax rates for the three months ended June 30, 2022 and 2021 were composed of U.S. federal and state taxes, withholding taxes and foreign taxes that amounted to $54.5 million and $38.0 million, respectively. The tax rate for the three months ended June 30, 2022 was impacted by a tax benefit of $18.6 million from the FDII deduction, excess tax benefits from stock-based compensation expense of $17.3 million and release of reserves of $16.2 million on uncertain tax positions and the accrued interest thereon due to the expiration of the statute of limitations. The tax rate for the three months ended June 30, 2021 was impacted by a tax benefit of $7.1 million from the FDII deduction, excess tax benefits from stock-based compensation expense of $18.2 million and release of reserves of $5.2 million on uncertain tax positions and the accrued interest thereon due to the expiration of the statute of limitations.

[0001262039-22-000029:notes:127]
The tax rates for the six months ended June 30, 2022 and 2021 were composed of U.S. federal and state taxes, withholding taxes and foreign taxes that amounted to $93.3 million and $75.4 million, respectively. The tax rate for the six months ended June 30, 2022 was impacted by a tax benefit of $33.3 million from the FDII deduction, excess tax benefits from stock-based compensation expense of $49.5 million and release of reserves of $16.2 million on uncertain tax positions and the accrued interest thereon due to the expiration of the statute of limitations. The tax rate for the six months ended June 30, 2021 was impacted by a tax benefit of $15.2 million from the FDII deduction, excess tax benefits from stock-based compensation

[0001262039-22-000029:notes:128]
expense of $35.3 million and release of reserves of $5.2 million on uncertain tax positions and the accrued interest thereon due to the expiration of the statute of limitations.

[0001262039-22-000029:notes:129]
As of June 30, 2022 and December 31, 2021, unrecognized tax benefits were $64.9 million and $73.3 million, respectively. If recognized, $56.6 million of the unrecognized tax benefits as of June 30, 2022 would favorably affect our effective tax rate. It is our policy to include accrued interest and penalties related to unrecognized tax benefits in income tax expense. As of June 30, 2022 and December 31, 2021, accrued interest and penalties were $9.8 million and $13.3 million, respectively. It is reasonably possible that our gross unrecognized tax benefits will decrease by up to $21.1 million in the next 12 months, due to the lapse of statutes of limitation in various jurisdictions. This decrease, if recognized, would favorably impact our effective tax rate, and would be recognized as additional tax benefits.

[0001262039-22-000029:notes:130]
We file income tax returns in the U.S. federal jurisdiction and in various U.S. state and foreign jurisdictions. Generally, we are no longer subject to examination by U.S federal income tax authorities for tax years prior to 2015. We are no longer subject to U.S. state and foreign income tax examinations by tax authorities for tax years prior to 2010. We currently have ongoing tax audits in the United Kingdom, Canada, Germany and several other foreign jurisdictions. The focus of these audits is the inter-company profit allocation.
On September 29, 2020, the United States Department of the Treasury (the “U.S. Treasury”) and the Internal Revenue Service (the “IRS”) released final regulations related to foreign tax credits that were the subject of proposed regulations issued in December 2019 and proposed certain provisions in proposed regulations issued in December 2019. The final and proposed regulations provide administrative guidance for the foreign tax credit regime, which was updated in the 2017 Tax Cuts and Jobs Act (the “2017 Tax Act”). Generally, the provisions that were included in the 2019 proposed regulations apply to taxable years ended on or after December 16, 2019, except as otherwise specified. On December 28, 2021, the U.S. Treasury and the IRS released final regulations addressing various aspects of the foreign tax credit regime, which did not have a material impact on our consolidated financial statements as of December 31, 2021. On January 4, 2022, the U.S. Treasury and the IRS published another tranche of final regulations regarding the foreign tax credit. These final regulations impose new requirements that a foreign tax must meet in order to be creditable against U.S. income taxes, and generally apply to tax years beginning on or after December 28, 2021. These final regulations adversely impact our ability to claim foreign tax credits in the United States for certain taxes imposed by certain foreign jurisdictions. These final regulations increased our tax expense in the six months ended June 30, 2022 by approximately $9.3 million.


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0001262039-22-000029:notes:131]
DEFINED CONTRIBUTION PLANSOur tax-deferred savings plan under our 401(k) Plan permits participating U.S. employees to contribute a portion of their pre-tax or after-tax earnings. In Canada, we have a Group Registered Retirement Savings Plan Program (the “RRSP”), which permits participants to make pre-tax contributions. Our board of directors approved 50% matching contributions on employee contributions up to 4% of each employee’s eligible earnings. Our matching contributions to our 401(k) Plan and the RRSP for the three months ended June 30, 2022 and 2021 were $3.2 million and $2.7 million, respectively. Our matching contributions to our 401(k) Plan and the RRSP for the six months ended June 30, 2022 and 2021 were $6.6 million and $5.4 million, respectively.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001262039-22-000029:notes:132]
SEGMENT INFORMATIONOperating segments are defined as components of an enterprise about which separate financial information is available that is evaluated regularly by the chief operating decision maker in deciding how to allocate resources and in assessing performance. Our chief operating decision maker is our chief executive officer. Our chief executive officer reviews financial information presented on a consolidated basis, accompanied by information about revenue by geographic region for purposes of allocating resources and evaluating financial performance. We have one business activity, and there are no segment managers who are held accountable for operations, operating results and plans for levels or components below the consolidated unit level. Accordingly, we have determined that we have one operating segment, and therefore, one reportable segment.
Revenue by geographic region is based on the billing address of our customers. The following tables set forth revenue and property and equipment—net by geographic region (in millions):

[0001262039-22-000029:notes:133]
|  | Three Months Ended |  | Six Months Ended |
| Revenue | June 30,2022 |  | June 30,2021 |  | June 30,2022 |  | June 30,2021 |
| Americas: |  |  |  |  |  |  |  |
| United States | $ | 312.9 |  |  | $ | 251.7 |  |  | $ | 598.7 |  |  | $ | 464.2 |  |
| Other Americas | 100.7 |  |  | 85.3 |  |  | 197.5 |  |  | 163.7 |  |
| Total Americas | 413.6 |  |  | 337.0 |  |  | 796.2 |  |  | 627.9 |  |
| Europe, Middle East and Africa (“EMEA”) | 391.8 |  |  | 306.2 |  |  | 737.8 |  |  | 581.9 |  |
| Asia Pacific (“APAC”) | 224.7 |  |  | 157.9 |  |  | 450.9 |  |  | 301.6 |  |
| Total revenue | $ | 1,030.1 |  |  | $ | 801.1 |  |  | $ | 1,984.9 |  |  | $ | 1,511.4 |  |

[0001262039-22-000029:notes:134]
| Property and Equipment—net | June 30,2022 |  | December 31,2021 |
| Americas: |  |  |  |
| United States | $ | 564.0 |  |  | $ | 472.4 |  |
| Canada | 196.5 |  |  | 170.9 |  |
| Latin America | 1.3 |  |  | 1.6 |  |
| Total Americas | 761.8 |  |  | 644.9 |  |
| EMEA | 34.1 |  |  | 31.0 |  |
| APAC | 18.7 |  |  | 11.7 |  |
| Total property and equipment—net | $ | 814.6 |  |  | $ | 687.6 |  |

[0001262039-22-000029:notes:135]
[same as prior period, unchanged from 0001262039-22-000019:notes:139]

[0001262039-22-000029:notes:136]
|  | Three Months Ended |  | Six Months Ended |
|  | June 30,2022 |  | June 30,2021 |  | June 30,2022 |  | June 30,2021 |
| Distributor A | 29 | % |  | 31 | % |  | 29 | % |  | 32 | % |
| Distributor B | 14 | % |  | 12 | % |  | 14 | % |  | 12 | % |
| Distributor C | 13 | % |  | * |  | 14 | % |  | * |

[0001262039-22-000029:notes:137]
[same as prior period, unchanged from 0001262039-22-000019:notes:141]

[0001262039-22-000029:notes:138]
[same as prior period, unchanged from 0001262039-22-000019:notes:142]

[0001262039-22-000029:notes:139]
|  | June 30,2022 |  | December 31,2021 |
| Distributor A | 30 | % |  | 33 | % |
| Distributor B | 12 | % |  | 13 | % |
| Distributor C | 16 | % |  | 13 | % |


## us-gaap:SubsequentEventsTextBlock

[0001262039-22-000029:notes:140]
SUBSEQUENT EVENTS
Real property purchase

[0001262039-22-000029:notes:141]
In July 2022, we purchased real property in Union City totaling approximately 59,000 square feet for a cash payment of $65.3 million.

[0001262039-22-000029:notes:142]
In July 2022, our board of directors approved a $1.00 billion increase in the authorized stock repurchase under our share repurchase program. As of August 4, 2022, approximately $1.03 billion remained available for future share repurchases.
