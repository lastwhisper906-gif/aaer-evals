# FTNT 8-K — 0001262039-22-000026 filed 2022-08-03

## item codes, every 8-K on or before 2022-08-05

- 2022-08-03 0001262039-22-000026 — 2.02, 9.01
- 2022-06-22 0001262039-22-000023 — 5.03, 9.01
- 2022-06-21 0001262039-22-000021 — 5.07
- 2022-05-04 0001262039-22-000015 — 2.02, 9.01
- 2022-05-02 0001262039-22-000012 — 5.02
- 2022-04-22 0001262039-22-000010 — 8.01
- 2022-02-03 0001262039-22-000005 — 2.02, 9.01
- 2022-01-26 0001262039-22-000002 — 5.02, 9.01 — amendment, the index does not say of what
- 2021-11-04 0001262039-21-000027 — 2.02, 9.01
- 2021-10-06 0001262039-21-000024 — 5.02, 9.01
- 2021-07-29 0001262039-21-000019 — 2.02, 9.01
- 2021-06-23 0001262039-21-000016 — 5.07
- 2021-04-30 0001104659-21-059008 — 5.03 — amendment, the index does not say of what
- 2021-04-29 0001262039-21-000011 — 2.02, 9.01
- 2021-04-28 0001104659-21-056360 — 5.02, 5.03, 9.01
- 2021-03-05 0001193125-21-071498 — 1.01, 9.01
- 2021-02-25 0001193125-21-057281 — 1.01, 9.01
- 2021-02-04 0001262039-21-000005 — 2.02, 9.01
- 2020-12-08 0001262039-20-000070 — 8.01
- 2020-10-29 0001262039-20-000063 — 2.02, 9.01
- 2020-10-20 0001262039-20-000060 — 5.02 — amendment, the index does not say of what
- 2020-08-26 0001262039-20-000056 — 5.02, 9.01
- 2020-08-06 0001262039-20-000051 — 2.02, 9.01
- 2020-07-21 0001262039-20-000044 — 5.03, 8.01, 9.01
- 2020-06-24 0001262039-20-000038 — 5.07
- 2020-05-06 0001262039-20-000029 — 2.02, 9.01
- 2020-04-23 0001262039-20-000025 — 5.03, 9.01
- 2020-04-23 0001262039-20-000024 — 5.02 — amendment of 0001262039-20-000025
- 2020-02-28 0001262039-20-000015 — 5.02, 9.01
- 2020-02-06 0001262039-20-000004 — 2.02, 9.01
- 2019-12-12 0001262039-19-000038 — 8.01
- 2019-10-31 0001262039-19-000032 — 2.02, 9.01
- 2019-10-28 0001262039-19-000027 — 8.01
- 2019-10-23 0001262039-19-000025 — 5.02, 9.01
- 2019-08-01 0001262039-19-000021 — 2.02, 9.01
- 2019-06-26 0001262039-19-000018 — 5.07
- 2019-05-02 0001262039-19-000010 — 2.02, 9.01
- 2019-02-06 0001262039-19-000002 — 2.02, 9.01
- 2018-11-01 0001262039-18-000037 — 2.02, 9.01
- 2018-10-23 0001262039-18-000035 — 8.01
- 2018-08-01 0001262039-18-000025 — 2.02, 9.01
- 2018-06-28 0001262039-18-000023 — 5.03, 5.07, 9.01
- 2018-06-04 0001262039-18-000021 — 8.01
- 2018-05-03 0001262039-18-000017 — 2.02, 5.02, 9.01
- 2018-02-05 0001262039-18-000004 — 2.02, 5.02, 9.01
- 2017-10-26 0001262039-17-000031 — 2.02, 9.01
- 2017-10-19 0001262039-17-000029 — 5.02 — amendment, the index does not say of what
- 2017-07-26 0001262039-17-000025 — 2.02, 9.01
- 2017-06-27 0001262039-17-000023 — 5.07
- 2017-05-31 0001262039-17-000021 — 5.02 — amendment of 0001262039-17-000019
- 2017-05-30 0001262039-17-000019 — 5.02, 9.01
- 2017-04-27 0001262039-17-000013 — 2.02, 9.01
- 2017-02-02 0001262039-17-000003 — 2.02, 9.01
- 2016-10-27 0001262039-16-000085 — 2.02, 9.01
- 2016-10-11 0001262039-16-000082 — 2.02, 9.01
- 2016-07-28 0001262039-16-000076 — 2.02, 9.01
- 2016-07-22 0001262039-16-000073 — 8.01, 9.01
- 2016-06-20 0001262039-16-000068 — 5.07
- 2016-06-07 0001193125-16-614788 — 8.01
- 2016-04-26 0001262039-16-000061 — 2.02, 9.01
- 2016-01-28 0001262039-16-000051 — 2.02, 9.01
- 2015-10-27 0001262039-15-000045 — 2.02
- 2015-10-22 0001262039-15-000042 — 5.02 — amendment, the index does not say of what
- 2015-10-22 0001262039-15-000041 — 5.02 — amendment, the index does not say of what
- 2015-10-22 0001262039-15-000039 — 2.02, 9.01
- 2015-09-28 0001262039-15-000034 — 5.02, 9.01
- 2015-09-22 0001262039-15-000031 — 9.01 — amendment of 0001193125-15-248065
- 2015-08-28 0001262039-15-000027 — 3.01, 5.02
- 2015-07-23 0001262039-15-000021 — 5.02
- 2015-07-22 0001262039-15-000019 — 2.02, 9.01
- 2015-07-08 0001193125-15-248065 — 2.01, 8.01, 9.01
- 2015-06-22 0001193125-15-229099 — 5.07
- 2015-06-19 0001193125-15-228428 — 5.02, 9.01
- 2015-04-20 0001262039-15-000014 — 2.02, 9.01
- 2015-01-28 0001262039-15-000005 — 2.02, 9.01
- 2014-10-22 0001262039-14-000036 — 2.02, 9.01
- 2014-07-23 0001262039-14-000030 — 2.02, 9.01
- 2014-06-24 0001262039-14-000027 — 5.07
- 2014-04-23 0001262039-14-000021 — 2.02, 9.01
- 2014-04-21 0001262039-14-000018 — 5.03, 9.01
- 2014-01-29 0001262039-14-000004 — 2.02, 9.01
- 2013-12-20 0001262039-13-000061 — 5.02, 9.01
- 2013-11-27 0001262039-13-000057 — 5.02, 7.01, 9.01
- 2013-11-12 0001445305-13-002993 — 5.02
- 2013-10-23 0001262039-13-000051 — 2.02, 9.01
- 2013-07-30 0001262039-13-000039 — 2.02, 9.01
- 2013-06-25 0001262039-13-000030 — 5.07
- 2013-04-30 0001262039-13-000023 — 2.02, 9.01
- 2013-04-19 0001262039-13-000020 — 5.02, 9.01
- 2013-04-19 0001262039-13-000018 — 5.02 — amendment of 0001262039-13-000020
- 2013-04-10 0001262039-13-000016 — 2.02, 9.01
- 2013-03-26 0001262039-13-000013 — 5.02
- 2013-01-30 0001262039-13-000005 — 2.02, 9.01
- 2013-01-24 0001262039-13-000002 — 5.02, 9.01
- 2012-10-16 0001262039-12-000048 — 2.02, 9.01
- 2012-10-01 0001262039-12-000045 — 5.02
- 2012-09-26 0001262039-12-000043 — 5.01
- 2012-07-25 0001262039-12-000038 — 2.02, 9.01
- 2012-07-19 0001262039-12-000034 — 5.02
- 2012-06-20 0001193125-12-275869 — 5.07
- 2012-04-27 0001262039-12-000029 — 5.02
- 2012-04-24 0001262039-12-000025 — 2.02, 9.01
- 2012-01-31 0001262039-12-000006 — 2.02, 9.01
- 2012-01-25 0001262039-12-000003 — 5.03
- 2011-10-24 0001262039-11-000036 — 2.02
- 2011-07-19 0001262039-11-000014 — 2.02, 9.01
- 2011-06-27 0001193125-11-174474 — 5.02, 5.07, 9.01
- 2011-04-27 0001193125-11-111938 — 2.02, 9.01
- 2011-01-25 0001193125-11-013914 — 2.02, 9.01
- 2010-10-21 0001193125-10-233676 — 2.02, 9.01
- 2010-09-02 0001193125-10-203099 — 8.01
- 2010-07-22 0001193125-10-163844 — 2.02, 9.01
- 2010-06-24 0001193125-10-146082 — 5.07
- 2010-04-28 0001193125-10-096698 — 2.02, 9.01
- 2010-02-09 0001193125-10-024614 — 8.01
- 2010-01-27 0001193125-10-014292 — 2.02, 9.01
- 2010-01-26 0001193125-10-013031 — 5.02, 9.01

## late-filing notifications on or before 2022-08-05

- none on or before 2022-08-05

## item 2.02 — earnings release, exhibit 99.1

[0001262039-22-000026:8k_2_02:1]
EX-99.1
2
ftntq2-2022ex991.htm
PRESS RELEASE

[0001262039-22-000026:8k_2_02:2]
Document

[0001262039-22-000026:8k_2_02:3]
Press Release

[0001262039-22-000026:8k_2_02:4]
Fortinet Reports Second Quarter 2022 Financial Results

[0001262039-22-000026:8k_2_02:5]
Second Quarter 2022 Highlights

[0001262039-22-000026:8k_2_02:6]
•Product revenue of $400.7 million, up 34% year over year

[0001262039-22-000026:8k_2_02:7]
•Total revenue of $1.03 billion, up 29% year over year

[0001262039-22-000026:8k_2_02:8]
•Bookings of $1.38 billion, up 42% year over year1

[0001262039-22-000026:8k_2_02:9]
•Billings of $1.30 billion, up 36% year over year2

[0001262039-22-000026:8k_2_02:10]
•Deferred revenue of $3.93 billion, up 35% year over year

[0001262039-22-000026:8k_2_02:11]
•GAAP operating margin of 19.0%

[0001262039-22-000026:8k_2_02:12]
•Non-GAAP operating margin of 24.8%2

[0001262039-22-000026:8k_2_02:13]
•GAAP diluted net income per share attributable to Fortinet, Inc. of $0.213

[0001262039-22-000026:8k_2_02:14]
•Non-GAAP diluted net income per share attributable to Fortinet, Inc. of $0.242,3

[0001262039-22-000026:8k_2_02:15]
•Cash flow from operations of $323.4 million

[0001262039-22-000026:8k_2_02:16]
•Free cash flow of $283.5 million2

[0001262039-22-000026:8k_2_02:17]
•Cash paid for share repurchases of $800.0 million

[0001262039-22-000026:8k_2_02:18]
SUNNYVALE, Calif. - August 3, 2022 - Fortinet® (Nasdaq: FTNT), a global leader in broad, integrated and automated cybersecurity solutions, today announced financial results for the second quarter ended June 30, 2022.

[0001262039-22-000026:8k_2_02:19]
“We delivered strong revenue and billings growth in the second quarter driven by an over 50% year-over-year increase in the number of transactions larger than one million dollars. Large enterprise companies continue to favor Fortinet’s industry leading cost for performance advantage and integrated platform strategy,” said Ken Xie, Founder, Chairman, and Chief Executive Officer. “Fortinet’s market share gains are being driven by the convergence of networking and security and an accelerating focus on vendor consolidation with our Core Platform and Platform Extension solutions designed to secure our customers’ entire infrastructure from the data center to the cloud.”

[0001262039-22-000026:8k_2_02:20]
Financial Highlights for the Second Quarter of 2022

[0001262039-22-000026:8k_2_02:21]
•Revenue: Total revenue was $1.03 billion for the second quarter of 2022, an increase of 28.6% compared to $801.1 million for the same quarter of 2021.

[0001262039-22-000026:8k_2_02:22]
•Product Revenue: Product revenue was $400.7 million for the second quarter of 2022, an increase of 34.3% compared to $298.3 million for the same quarter of 2021.

[0001262039-22-000026:8k_2_02:23]
•Service Revenue: Service revenue was $629.4 million for the second quarter of 2022, an increase of 25.2% compared to $502.8 million for the same quarter of 2021.

[0001262039-22-000026:8k_2_02:24]
•Bookings1: Total bookings were $1.38 billion for the second quarter of 2022, an increase of 42.1% compared to $967.9 million for the same quarter of 2021. Backlog was $349.9 million as of June 30, 2022, an increase of $188.0 million compared to $161.9 million as of December 31, 2021.

[0001262039-22-000026:8k_2_02:25]
•Billings2: Total billings were $1.30 billion for the second quarter of 2022, an increase of 35.7% compared to $960.9 million for the same quarter of 2021.

[0001262039-22-000026:8k_2_02:26]
•Deferred Revenue: Total deferred revenue was $3.93 billion as of June 30, 2022, an increase of 35.3% compared to $2.91 billion as of June 30, 2021.

[0001262039-22-000026:8k_2_02:27]
•GAAP Operating Income and Margin: GAAP operating income was $195.3 million for the second quarter of 2022, representing a GAAP operating margin of 19.0%. GAAP operating income was $147.5 million for the same quarter of 2021, representing a GAAP operating margin of 18.4%.

[0001262039-22-000026:8k_2_02:28]
•Non-GAAP Operating Income and Margin2: Non-GAAP operating income was $255.4 million for the second quarter of 2022, representing a non-GAAP operating margin of 24.8%. Non-GAAP operating income was $203.3 million for the same quarter of 2021, representing a non-GAAP operating margin of 25.4%.

[0001262039-22-000026:8k_2_02:29]
•GAAP Net Income and Diluted Net Income Per Share Attributable to Fortinet, Inc.3: GAAP net income was $173.5 million for the second quarter of 2022, compared to GAAP net income of $137.5 million for the same quarter of 2021. GAAP diluted net income per share was $0.21 for the second quarter of 2022, based on 810.1 million diluted weighted-average shares outstanding, compared to GAAP diluted net income per share of $0.16 for the same quarter of 2021, based on 835.4 million diluted weighted-average shares outstanding.

[0001262039-22-000026:8k_2_02:30]
•Non-GAAP Net Income and Diluted Net Income Per Share Attributable to Fortinet, Inc.2,3: Non-GAAP net income was $194.1 million for the second quarter of 2022, compared to non-GAAP net income of $158.7 million for the same quarter of 2021. Non-GAAP diluted net income per share was $0.24 for the second quarter of 2022, based on 810.1 million diluted weighted-average shares outstanding, compared to $0.19 for the same quarter of 2021, based on 835.4 million diluted weighted-average shares outstanding.

[0001262039-22-000026:8k_2_02:31]
•Cash Flow: Cash flow from operations was $323.4 million for the second quarter of 2022, compared to $418.2 million for the same quarter of 2021.

[0001262039-22-000026:8k_2_02:32]
•Free Cash Flow2: Free cash flow was $283.5 million for the second quarter of 2022, compared to $394.7 million for the same quarter of 2021.

[0001262039-22-000026:8k_2_02:33]
•Share Repurchase Program3: During the three and six months ended June 30, 2022, Fortinet repurchased 14.4 million and 25.8 million shares of its common stock at an average price of  $55.45 and $57.82 per share and for an aggregate purchase price of   $800.0 million and $1.49 billion, respectively. During the three and six months ended June 30, 2021, Fortinet repurchased 2.3 million shares of its common stock at an average price of $40.28 per share and for an aggregate purchase price of $91.6 million. In July 2022, Fortinet’s board of directors authorized a $1.0 billion increase in the authorized stock repurchase under our share repurchase program. As of August 1, 2022, approximately $1.03 billion remained available for future share repurchases.

[0001262039-22-000026:8k_2_02:34]
Guidance

[0001262039-22-000026:8k_2_02:35]
For the third quarter of 2022, Fortinet currently expects:

[0001262039-22-000026:8k_2_02:36]
•Revenue in the range of $1.105 billion to $1.135 billion

[0001262039-22-000026:8k_2_02:37]
•Billings in the range of $1.385 billion to $1.415 billion

[0001262039-22-000026:8k_2_02:38]
•Non-GAAP gross margin in the range of 75.0% to 76.0%

[0001262039-22-000026:8k_2_02:39]
•Non-GAAP operating margin in the range of 25.0% to 26.0%

[0001262039-22-000026:8k_2_02:40]
•Diluted non-GAAP net income per share attributable to Fortinet, Inc. in the range of $0.26 to $0.28, assuming a non-GAAP effective tax rate of 17%. This assumes a diluted share count of 810 million to 820 million.

[0001262039-22-000026:8k_2_02:41]
For the fiscal year 2022, Fortinet currently expects:

[0001262039-22-000026:8k_2_02:42]
•Revenue in the range of $4.350 billion to $4.400 billion

[0001262039-22-000026:8k_2_02:43]
•Service revenue in the range of $2.620 billion to $2.670 billion

[0001262039-22-000026:8k_2_02:44]
•Billings in the range of $5.560 billion to $5.640 billion

[0001262039-22-000026:8k_2_02:45]
•Non-GAAP gross margin in the range of 75.0% to 76.0%

[0001262039-22-000026:8k_2_02:46]
•Non-GAAP operating margin in the range of 25.0% to 26.0%

[0001262039-22-000026:8k_2_02:47]
•Diluted non-GAAP net income per share attributable to Fortinet, Inc. in the range of $1.01 to $1.06, assuming a non-GAAP effective tax rate of 17%. This assumes a diluted share count of 810 million to 820 million.

[0001262039-22-000026:8k_2_02:48]
Our guidance with respect to non-GAAP financial measures excludes stock-based compensation, amortization of acquired intangible assets and gain on intellectual property matters. We have not reconciled our guidance with respect to non-GAAP financial measures to the corresponding GAAP measures because certain items that impact these measures are uncertain or out of our control, or cannot be reasonably predicted. Accordingly, a reconciliation of these non-GAAP financial measures to the corresponding GAAP measures is not available without unreasonable effort.

[0001262039-22-000026:8k_2_02:49]
1 Bookings represents the total value of all orders received during the period. Backlog represents orders received but not fulfilled and excludes Alaxala Networks Corporation. When an order is fulfilled, billings and revenue are recognized.

[0001262039-22-000026:8k_2_02:50]
2 A reconciliation of GAAP to non-GAAP measures has been provided in the financial statement tables included in this press release. An explanation of these measures is also included below under the heading “Non-GAAP Financial Measures”.

[0001262039-22-000026:8k_2_02:51]
3 All share and per share amounts presented herein have been retroactively adjusted to reflect the five-for-one forward stock split which was effective June 22, 2022.

[0001262039-22-000026:8k_2_02:52]
Conference Call Details

[0001262039-22-000026:8k_2_02:53]
Fortinet will host a conference call today at 1:30 p.m. Pacific Time (4:30 p.m. Eastern Time) to discuss the earnings results. A live webcast of the conference call and supplemental slides will be accessible from the Investor Relations page of Fortinet’s website at https://investor.fortinet.com and a replay will be archived and accessible at https://investor.fortinet.com/events-and-presentations.

[0001262039-22-000026:8k_2_02:54]
Third Quarter 2022 Conference Participation Schedule:

[0001262039-22-000026:8k_2_02:55]
•KeyBanc Technology Leadership Conference

[0001262039-22-000026:8k_2_02:56]
August 8, 2022

[0001262039-22-000026:8k_2_02:57]
•Stifel Tech Executive Summit Deer Valley

[0001262039-22-000026:8k_2_02:58]
August 29-31, 2022

[0001262039-22-000026:8k_2_02:59]
•Citibank Investor Conference

[0001262039-22-000026:8k_2_02:60]
September 7, 2022

[0001262039-22-000026:8k_2_02:61]
•Evercore Investor Conference

[0001262039-22-000026:8k_2_02:62]
September 8, 2022

[0001262039-22-000026:8k_2_02:63]
•Goldman Sachs Communicopia Conference

[0001262039-22-000026:8k_2_02:64]
September 12, 2022

[0001262039-22-000026:8k_2_02:65]
Members of Fortinet’s management team are expected to present at these conferences and discuss the latest company strategies and initiatives. Fortinet’s conference presentations are expected to be available via webcast on the company’s web site. To access the most updated information, pre-register and listen to the webcast of each event, please visit the Investor Presentation & Events page of Fortinet’s website at https://investor.fortinet.com/events-and-presentations. The schedule is subject to change.

[0001262039-22-000026:8k_2_02:66]
About Fortinet (www.fortinet.com)

[0001262039-22-000026:8k_2_02:67]
Fortinet (NASDAQ: FTNT) makes possible a digital world that we can trust through its mission to protect people, devices and data everywhere. This is why many of the world’s largest enterprises, service providers and government organizations choose Fortinet to securely accelerate their digital journey. The Fortinet Core Platform and Platform Extension products deliver broad, integrated and automated protections across the entire digital attack surface, securing critical devices, data, applications, and connections from the data center to the cloud to the home office. The Fortinet NSE Training Institute, an initiative of Fortinet’s Training Advancement Agenda, provides one of the largest and broadest training programs in the industry to make cyber training and new career opportunities available to everyone. Learn more at https://www.fortinet.com, the Fortinet Blog or FortiGuard Labs.

[0001262039-22-000026:8k_2_02:68]
#          #          #

[0001262039-22-000026:8k_2_02:69]
Copyright © 2022 Fortinet, Inc. All rights reserved. The symbols ® and ™ denote respectively federally registered trademarks and common law trademarks of Fortinet, Inc., its subsidiaries and affiliates. Fortinet’s trademarks include, but are not limited to, the following: Fortinet, the Fortinet logo, FortiGate, FortiOS, FortiGuard, FortiCare, FortiAnalyzer, FortiManager, FortiASIC, FortiClient, FortiCloud, FortiMail, FortiSandbox, FortiADC, FortiAI, FortiAIOps, FortiAntenna, FortiAP, FortiAPCam, FortiAuthenticator, FortiCache, FortiCall, FortiCam, FortiCamera, FortiCarrier, FortiCASB, FortiCentral, FortiConnect, FortiController, FortiConverter, FortiCWP, FortiDB, FortiDDoS, FortiDeceptor, FortiDeploy, FortiDevSec, FortiEdge, FortiEDR, FortiExplorer, FortiExtender, FortiFirewall, FortiFone, FortiGSLB, FortiHypervisor, FortiInsight, FortiIsolator, FortiLAN, FortiLink, FortiMoM, FortiMonitor, FortiNAC, FortiNDR, FortiPenTest, FortiPhish, FortiPlanner, FortiPolicy, FortiPortal, FortiPresence, FortiProxy, FortiRecon, FortiRecorder, FortiSASE, FortiSDNConnector, FortiSIEM, FortiSMS, FortiSOAR, FortiSwitch, FortiTester, FortiToken, FortiTrust, FortiVoice, FortiWAN, FortiWeb, FortiWiFi, FortiWLC, FortiWLM and FortiXDR. Other trademarks belong to their respective owners. Fortinet has not independently verified statements or certifications herein attributed to third parties and Fortinet does not independently endorse such statements. Notwithstanding anything to the contrary herein, nothing herein constitutes a warranty, guarantee, contract, binding specification or other

[0001262039-22-000026:8k_2_02:70]
binding commitment by Fortinet or any indication of intent related to a binding commitment, and performance and other specification information herein may be unique to certain environments.

[0001262039-22-000026:8k_2_02:71]
FTNT-F

[0001262039-22-000026:8k_2_02:72]
Forward-Looking Statements

[0001262039-22-000026:8k_2_02:73]
This press release contains forward-looking statements that involve risks and uncertainties. These forward-looking statements include statements regarding any indications related to future market share gains, guidance and expectations around future financial results, including guidance and expectations for the third quarter and full year 2022, statements regarding the momentum in our business and future growth expectations, and any statements regarding our market opportunity and market size, and business momentum. Although we attempt to be accurate in making forward-looking statements, it is possible that future circumstances might differ from the assumptions on which such statements are based such that actual results are materially different from our forward-looking statements in this release. Important factors that could cause results to differ materially from the statements herein include the following: general economic risks, including those caused by the COVID-19 pandemic, the war in Ukraine, economic challenges, fears of a recession, and any actual recession, and the effects of increased inflation in certain geographies; significantly heightened supply chain challenges due to the current global environment; negative impacts from the COVID-19 pandemic on sales, billings, revenue, demand and buying patterns, component supply and ability to manufacture products to meet demand in a timely fashion, and costs such as possible increased costs for shipping and components; global economic conditions, country-specific economic conditions, and foreign currency risks; competitiveness in the security market; the dynamic nature of the security market and its products and services; specific economic risks worldwide and in different geographies, and among different customer segments; uncertainty regarding demand and increased business and renewals from existing customers; uncertainties around continued success in sales growth and market share gains; uncertainties in market opportunities and the market size; actual or perceived vulnerabilities in our supply chain, products or services, and any actual or perceived breach of our network or our customers’ networks; longer sales cycles, particularly for larger enterprise, service providers, government and other large organization customers; the effectiveness of our salesforce and failure to convert sales pipeline into final sales; risks associated with successful implementation of multiple integrated software products and other product functionality risks; risks associated with integrating acquisitions and changes in circumstances and plans associated therewith, including, among other risks, changes in plans related to product and services integrations, product and services plans and sales strategies; sales and marketing execution risks; execution risks around new product development and introductions and innovation; litigation and disputes and the potential cost, distraction and damage to sales and reputation caused thereby or by other factors; cybersecurity threats, breaches and other disruptions; market acceptance of new products and services; the ability to attract and retain personnel; changes in strategy; risks associated with management of growth; lengthy sales and implementation cycles, particularly in larger organizations; technological changes that make our products and services less competitive; risks associated with the adoption of, and demand for, our products and services in general and by specific customer segments, including those caused by the COVID-19 pandemic; competition and pricing pressure; product inventory shortages for any reason, including those caused by the COVID-19 pandemic, the war in Ukraine and the effects of increased inflation in certain geographies; risks associated with business disruption caused by natural disasters and health emergencies such as earthquakes, fires, power outages, typhoons, floods, health epidemics and viruses such as the COVID-19 pandemic, and by manmade events such as civil unrest, labor disruption, international trade disputes, international conflicts such as the war in Ukraine, terrorism, wars, and critical infrastructure attacks; tariffs, trade disputes and other trade barriers, and negative impact on sales based on geo-political dynamics and disputes and protectionist policies; any political and government disruption around the world, including the impact of any future shutdowns of the U.S. government; and the other risk factors set forth from time to time in our most recent Annual Report on Form 10-K, our most recent Quarterly Report on Form 10-Q and

[0001262039-22-000026:8k_2_02:74]
COVID-19 Impact

[0001262039-22-000026:8k_2_02:75]
While the broader implications of the COVID-19 pandemic on our employees and overall financial performance remain uncertain, we have seen certain impacts on our business and operations, results of operations, financial condition, cash flows, liquidity and capital and financial resources. Going forward, the situation is uncertain, rapidly changing and hard to predict, and the COVID-19 pandemic may have a material negative impact on our future periods, including our results for the three months ending September 30, 2022, our annual results for 2022, and beyond. To highlight the uncertainty remaining for the three-month period ending September 30, 2022, it should be noted that, due to customer buying patterns and the efforts of our sales force and channel partners to meet or exceed quarterly quotas, we have historically received a substantial portion of each quarter’s sales orders and generated a substantial portion of each quarter’s billings and revenue during the last two weeks of the quarter. Additionally, significantly heightened supply chain challenges are impacting businesses around the globe. If we experience significant changes in our billings growth rates or if we are unable to supply product to meet demand, it will impact product revenue in the current quarter and FortiGuard and FortiCare service revenues in subsequent quarters, as we sell annual and multi-year service contracts that are recognized ratably over the contractual service term. In addition, the broader implications of the pandemic on our business and operations and our financial results, including the extent to which the effects of the pandemic will impact future results and growth in the cybersecurity industry, remain uncertain. The duration and severity of the economic downturn from the pandemic may negatively impact our business and operations, results of operations, financial condition, cash flows, liquidity and capital and financial resources in a material way. As a result, the effects of the pandemic may not be fully reflected in our results of operations until future periods.

[0001262039-22-000026:8k_2_02:76]
Non-GAAP Financial Measures

[0001262039-22-000026:8k_2_02:77]
We have provided in this release financial information that has not been prepared in accordance with U.S. Generally Accepted Accounting Principles (GAAP). These non-GAAP financial and liquidity measures are not based on any standardized methodology prescribed by GAAP and are not necessarily comparable to similar measures presented by other companies. We use these non-GAAP financial measures internally in analyzing our financial results and believe they are useful to investors, as a supplement to GAAP measures, in evaluating our ongoing operational performance. We believe that the use of these non-GAAP financial measures provides an additional tool for investors to use in evaluating ongoing operating results and trends and in comparing our financial results with peer companies, many of which present similar non-GAAP financial measures to investors.

[0001262039-22-000026:8k_2_02:78]
Non-GAAP financial measures should not be considered in isolation from, or as a substitute for, financial information prepared in accordance with GAAP. Investors are encouraged to review the reconciliation of these non-GAAP financial measures to their most directly comparable GAAP financial measures provided in the financial statement tables below.

[0001262039-22-000026:8k_2_02:79]
Billings (non-GAAP). We define billings as revenue recognized in accordance with GAAP plus the change in deferred revenue from the beginning to the end of the period, less any deferred revenue balances acquired from business combination(s) and adjustment due to adoption of new accounting standard during the period. We consider billings to be a useful metric for management and investors because billings drive current and future revenue, which is an

[0001262039-22-000026:8k_2_02:80]
important indicator of the health and viability of our business. There are a number of limitations related to the use of billings instead of GAAP revenue. First, billings include amounts that have not yet been recognized as revenue and are impacted by the term of security and support agreements. Second, we may calculate billings in a manner that is different from peer companies that report similar financial measures. Management accounts for these limitations by providing specific information regarding GAAP revenue and evaluating billings together with GAAP revenue.

[0001262039-22-000026:8k_2_02:81]
Free cash flow (non-GAAP). We define free cash flow as net cash provided by operating activities minus purchases of property and equipment and excluding any significant non-recurring items, such as proceeds from intellectual property matter. We believe free cash flow to be a liquidity measure that provides useful information to management and investors about the amount of cash generated by the business that, after capital expenditures and net of proceeds from intellectual property matter, can be used for strategic opportunities, including repurchasing outstanding common stock, investing in our business, making strategic acquisitions and strengthening the balance sheet. A limitation of using free cash flow rather than the GAAP measures of cash provided by or used in operating activities, investing activities, and financing activities is that free cash flow does not represent the total increase or decrease in the cash and cash equivalents balance for the period because it excludes cash flows from significant non-recurring items, such as proceeds from intellectual property matter, investing activities other than capital expenditures and cash flows from financing activities. Management accounts for this limitation by providing information about our capital expenditures and other investing and financing activities on the face of the cash flow statement and under the caption “Management’s Discussion and Analysis of Financial Condition and Results of Operations—Liquidity and Capital Resources” in our most recent Quarterly Report on Form 10-Q and Annual Report on Form 10-K and by presenting cash flows from investing and financing activities in our reconciliation of free cash flow. In addition, it is important to note that other companies, including companies in our industry, may not use free cash flow, may calculate free cash flow in a different manner than we do or may use other financial measures to evaluate their performance, all of which could reduce the usefulness of free cash flow as a comparative measure.

[0001262039-22-000026:8k_2_02:82]
Non-GAAP operating income and operating margin. We define non-GAAP operating income as operating income plus stock-based compensation, impairment and amortization of acquired intangible assets, less gain on intellectual property matter and, when applicable, other significant non-recurring items in a given quarter, such as non-recurring gains or losses on litigation-related matters. Non-GAAP operating margin is defined as non-GAAP operating income divided by GAAP revenue. We consider these non-GAAP financial measures to be useful metrics for management and investors because they exclude the items noted above so that our management and investors can compare our recurring core business operating results over multiple periods. There are a number of limitations related to the use of non-GAAP operating income instead of operating income calculated in accordance with GAAP. First, non-GAAP operating income excludes the items noted above. Second, the components of the costs that we exclude from our calculation of non-GAAP operating income may differ from the components that peer companies exclude when they report their non-GAAP results of operations. Management accounts for these limitations by providing specific information regarding the GAAP amounts excluded from non-GAAP operating income and evaluating non-GAAP operating income together with operating income calculated in accordance with GAAP.

[0001262039-22-000026:8k_2_02:83]
Non-GAAP net income and diluted net income per share attributable to Fortinet, Inc. We define non-GAAP net income as net income or loss plus the items noted above under non-GAAP operating income and operating margin. In addition, we adjust non-GAAP net income and diluted net income per share for gains or losses on investments in privately held companies, a tax adjustment required for an effective tax rate on a non-GAAP basis and adjustments attributable to non-controlling interests, which differs from the GAAP effective tax rate. We define non-GAAP diluted net income per share as non-GAAP net income divided by the non-

[0001262039-22-000026:8k_2_02:84]
GAAP diluted weighted-average shares outstanding. We consider these non-GAAP financial measures to be useful metrics for management and investors for the same reasons that we use non-GAAP operating income and non-GAAP operating margin. However, in order to provide a more complete picture of our recurring core business operating results, we include in non-GAAP net income and non-GAAP diluted net income per share, the tax adjustment required resulting in an effective tax rate on a non-GAAP basis, which often differs from the GAAP tax rate. We believe the non-GAAP effective tax rates we use are reasonable estimates of normalized tax rates for our current and prior fiscal years under our global operating structure. The same limitations described above regarding our use of non-GAAP operating income and non-GAAP operating margin apply to our use of non-GAAP net income and non-GAAP diluted net income per share. We account for these limitations by providing specific information regarding the GAAP amounts excluded from non-GAAP net income and non-GAAP diluted net income per share and evaluating non-GAAP net income and non-GAAP diluted net income per share together with net income or loss and diluted net income per share calculated in accordance with GAAP.

[0001262039-22-000026:8k_2_02:85]
FORTINET, INC.

[0001262039-22-000026:8k_2_02:86]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001262039-22-000026:8k_2_02:87]
(Unaudited, in millions)

[0001262039-22-000026:8k_2_02:88]
|  | June 30,2022 |  | December 31,2021 |
| ASSETS |  |  |  |
| CURRENT ASSETS: |  |  |  |
| Cash and cash equivalents | $ | 710.0 |  |  | $ | 1,319.1 |  |
| Short-term investments | 1,020.6 |  |  | 1,194.0 |  |
| Marketable equity securities | 24.3 |  |  | 38.6 |  |
| Accounts receivable—net | 919.5 |  |  | 807.7 |  |
| Inventory | 195.2 |  |  | 175.8 |  |
| Prepaid expenses and other current assets | 83.3 |  |  | 65.4 |  |
| Total current assets | 2,952.9 |  |  | 3,600.6 |  |
| LONG-TERM INVESTMENTS | 188.5 |  |  | 440.8 |  |
| PROPERTY AND EQUIPMENT—NET | 814.6 |  |  | 687.6 |  |
| DEFERRED CONTRACT COSTS | 456.9 |  |  | 423.3 |  |
| DEFERRED TAX ASSETS | 480.2 |  |  | 342.3 |  |
| GOODWILL AND OTHER INTANGIBLE ASSETS—NET | 166.7 |  |  | 188.7 |  |
| OTHER ASSETS | 234.7 |  |  | 235.8 |  |
| TOTAL ASSETS | $ | 5,294.5 |  |  | $ | 5,919.1 |  |
| LIABILITIES AND EQUITY (DEFICIT) |  |  |  |
| CURRENT LIABILITIES: |  |  |  |
| Accounts payable | $ | 193.1 |  |  | $ | 148.4 |  |
| Accrued liabilities | 241.2 |  |  | 197.3 |  |
| Accrued payroll and compensation | 187.4 |  |  | 195.0 |  |
| Deferred revenue | 2,013.2 |  |  | 1,777.4 |  |
| Total current liabilities | 2,634.9 |  |  | 2,318.1 |  |
| DEFERRED REVENUE | 1,918.8 |  |  | 1,675.5 |  |
| INCOME TAX LIABILITIES | 67.1 |  |  | 79.5 |  |
| LONG-TERM DEBT | 989.4 |  |  | 988.4 |  |
| OTHER LIABILITIES | 63.9 |  |  | 59.2 |  |
| Total liabilities | 5,674.1 |  |  | 5,120.7 |  |
| COMMITMENTS AND CONTINGENCIES |  |  |  |
| EQUITY (DEFICIT): |  |  |  |
| Common stock | 0.8 |  |  | 0.8 |  |
| Additional paid-in capital | 1,237.3 |  |  | 1,253.6 |  |
| Accumulated other comprehensive loss | (23.4) |  |  | (4.8) |  |
| Accumulated deficit | (1,607.6) |  |  | (467.9) |  |
| Total Fortinet, Inc. stockholders’ equity (deficit) | (392.9) |  |  | 781.7 |  |
| Non-controlling interests | 13.3 |  |  | 16.7 |  |
| Total equity (deficit) | (379.6) |  |  | 798.4 |  |
| TOTAL LIABILITIES AND EQUITY (DEFICIT) | $ | 5,294.5 |  |  | $ | 5,919.1 |  |

[0001262039-22-000026:8k_2_02:89]
FORTINET, INC.

[0001262039-22-000026:8k_2_02:90]
CONDENSED CONSOLIDATED STATEMENTS OF INCOME

[0001262039-22-000026:8k_2_02:91]
(Unaudited, in millions, except per share amounts)

[0001262039-22-000026:8k_2_02:92]
|  | Three Months Ended |  | Six Months Ended |
|  | June 30,2022 |  | June 30,2021 |  | June 30,2022 |  | June 30,2021 |
| REVENUE: |  |  |  |  |  |  |  |
| Product | $ | 400.7 |  |  | $ | 298.3 |  |  | $ | 771.7 |  |  | $ | 539.0 |  |
| Service | 629.4 |  |  | 502.8 |  |  | 1,213.2 |  |  | 972.4 |  |
| Total revenue | 1,030.1 |  |  | 801.1 |  |  | 1,984.9 |  |  | 1,511.4 |  |
| COST OF REVENUE: |  |  |  |  |  |  |  |
| Product | 155.2 |  |  | 115.6 |  |  | 316.2 |  |  | 206.9 |  |
| Service | 95.6 |  |  | 71.3 |  |  | 188.4 |  |  | 136.6 |  |
| Total cost of revenue | 250.8 |  |  | 186.9 |  |  | 504.6 |  |  | 343.5 |  |
| GROSS PROFIT: |  |  |  |  |  |  |  |
| Product | 245.5 |  |  | 182.7 |  |  | 455.5 |  |  | 332.1 |  |
| Service | 533.8 |  |  | 431.5 |  |  | 1,024.8 |  |  | 835.8 |  |
| Total gross profit | 779.3 |  |  | 614.2 |  |  | 1,480.3 |  |  | 1,167.9 |  |
| OPERATING EXPENSES: |  |  |  |  |  |  |  |
| Research and development | 124.3 |  |  | 106.6 |  |  | 249.2 |  |  | 203.8 |  |
| Sales and marketing | 415.5 |  |  | 326.9 |  |  | 803.1 |  |  | 630.9 |  |
| General and administrative | 45.4 |  |  | 34.4 |  |  | 84.0 |  |  | 66.4 |  |
| Gain on intellectual property matter | (1.2) |  |  | (1.2) |  |  | (2.3) |  |  | (2.3) |  |
| Total operating expenses | 584.0 |  |  | 466.7 |  |  | 1,134.0 |  |  | 898.8 |  |
| OPERATING INCOME | 195.3 |  |  | 147.5 |  |  | 346.3 |  |  | 269.1 |  |
| INTEREST INCOME | 2.4 |  |  | 1.2 |  |  | 3.7 |  |  | 2.3 |  |
| INTEREST EXPENSE | (4.5) |  |  | (4.5) |  |  | (9.0) |  |  | (5.8) |  |
| OTHER INCOME (EXPENSE)—NET | (9.3) |  |  | 0.8 |  |  | (18.4) |  |  | (1.2) |  |
| INCOME BEFORE INCOME TAXES AND LOSS FROM EQUITY METHOD INVESTMENT | 183.9 |  |  | 145.0 |  |  | 322.6 |  |  | 264.4 |  |
| PROVISION FOR (BENEFIT FROM) INCOME TAXES | 2.4 |  |  | 7.5 |  |  | (5.7) |  |  | 19.7 |  |
| LOSS FROM EQUITY METHOD INVESTMENT | (8.1) |  |  | — |  |  | (16.6) |  |  | — |  |
| NET INCOME INCLUDING NON-CONTROLLING INTERESTS | 173.4 |  |  | 137.5 |  |  | 311.7 |  |  | 244.7 |  |
| Less: NET LOSS ATTRIBUTABLE TO NON-CONTROLLING INTERESTS, NET OF TAX | (0.1) |  |  | — |  |  | (0.2) |  |  | — |  |
| NET INCOME ATTRIBUTABLE TO FORTINET, INC. | $ | 173.5 |  |  | $ | 137.5 |  |  | $ | 311.9 |  |  | $ | 244.7 |  |
| Net income per share attributable to Fortinet, Inc. (a): |  |  |  |  |  |  |  |
| Basic | $ | 0.22 |  |  | $ | 0.17 |  |  | $ | 0.39 |  |  | $ | 0.30 |  |
| Diluted | $ | 0.21 |  |  | $ | 0.16 |  |  | $ | 0.38 |  |  | $ | 0.29 |  |
| Weighted-average shares used to compute net income per share attributable to Fortinet, Inc. (a): |  |  |  |  |  |  |  |
| Basic | 795.4 |  |  | 816.7 |  |  | 799.4 |  |  | 815.9 |  |
| Diluted | 810.1 |  |  | 835.4 |  |  | 815.4 |  |  | 833.7 |  |

[0001262039-22-000026:8k_2_02:93]
(a) All share and per share amounts presented herein have been retroactively adjusted to reflect the five-for-one forward stock split which was effective June 22, 2022.

[0001262039-22-000026:8k_2_02:94]
FORTINET, INC.

[0001262039-22-000026:8k_2_02:95]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001262039-22-000026:8k_2_02:96]
(Unaudited, in millions)

[0001262039-22-000026:8k_2_02:97]
|  | Six Months Ended |
|  | June 30,2022 |  | June 30,2021 |
| CASH FLOWS FROM OPERATING ACTIVITIES: |  |  |  |
| Net income including non-controlling interests | $ | 311.7 |  |  | $ | 244.7 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |
| Stock-based compensation | 107.9 |  |  | 102.1 |  |
| Amortization of deferred contract costs | 107.1 |  |  | 81.8 |  |
| Depreciation and amortization | 50.6 |  |  | 36.2 |  |
| Amortization of investment premiums | 2.8 |  |  | 2.9 |  |
| Loss from equity method investment | 16.6 |  |  | — |  |
| Other | 22.8 |  |  | 0.3 |  |
| Changes in operating assets and liabilities, net of impact of business combinations: |  |  |  |
| Accounts receivable—net | (119.3) |  |  | 135.6 |  |
| Inventory | (31.2) |  |  | (20.1) |  |
| Prepaid expenses and other current assets | (18.2) |  |  | (16.4) |  |
| Deferred contract costs | (140.6) |  |  | (124.8) |  |
| Deferred tax assets | (136.3) |  |  | (25.8) |  |
| Other assets | (16.7) |  |  | (11.8) |  |
| Accounts payable | 52.7 |  |  | (9.5) |  |
| Accrued liabilities | 30.1 |  |  | 21.3 |  |
| Accrued payroll and compensation | (6.8) |  |  | 18.7 |  |
| Other liabilities | 5.7 |  |  | (1.2) |  |
| Deferred revenue | 480.6 |  |  | 300.1 |  |
| Net cash provided by operating activities | 719.5 |  |  | 734.1 |  |
| CASH FLOWS FROM INVESTING ACTIVITIES: |  |  |  |
| Purchases of investments | (389.1) |  |  | (1,262.5) |  |
| Sales of investments | 3.0 |  |  | 71.4 |  |
| Maturities of investments | 797.3 |  |  | 600.3 |  |
| Purchases of property and equipment | (162.5) |  |  | (75.6) |  |
| Purchases of investment in privately held company | — |  |  | (75.0) |  |
| Payments made in connection with business combinations, net of cash acquired | — |  |  | (10.3) |  |
| Net cash provided by (used in) investing activities | 248.7 |  |  | (751.7) |  |
| CASH FLOWS FROM FINANCING ACTIVITIES: |  |  |  |
| Proceeds from long-term borrowings, net of discount and underwriting fees | — |  |  | 989.4 |  |
| Payments for debt issuance costs | — |  |  | (2.4) |  |
| Repurchase and retirement of common stock | (1,491.2) |  |  | (91.6) |  |
| Proceeds from issuance of common stock | 15.9 |  |  | 15.8 |  |
| Taxes paid related to net share settlement of equity awards | (99.9) |  |  | (76.0) |  |
| Other | (1.1) |  |  | (0.1) |  |
| Net cash provided by (used in) financing activities | (1,576.3) |  |  | 835.1 |  |
| EFFECT OF EXCHANGE RATE CHANGES ON CASH AND CASH EQUIVALENTS | (1.0) |  |  | — |  |
| NET INCREASE (DECREASE) IN CASH AND CASH EQUIVALENTS | (609.1) |  |  | 817.5 |  |
| CASH AND CASH EQUIVALENTS—Beginning of period | 1,319.1 |  |  | 1,061.8 |  |
| CASH AND CASH EQUIVALENTS—End of period | $ | 710.0 |  |  | $ | 1,879.3 |  |

[0001262039-22-000026:8k_2_02:98]
Reconciliations of non-GAAP results of operations measures to the nearest comparable GAAP measures

[0001262039-22-000026:8k_2_02:99]
(Unaudited, in millions, except per share amounts)

[0001262039-22-000026:8k_2_02:100]
Reconciliation of net cash provided by operating activities to free cash flow

[0001262039-22-000026:8k_2_02:101]
|  | Three Months Ended |
|  | June 30,2022 |  | June 30,2021 |
| Net cash provided by operating activities | $ | 323.4 |  |  | $ | 418.2 |  |
| Less: Purchases of property and equipment | (39.9) |  |  | (23.5) |  |
| Free cash flow | $ | 283.5 |  |  | $ | 394.7 |  |
| Net cash provided by (used in) investing activities | $ | 294.1 |  |  | $ | (278.2) |  |
| Net cash used in financing activities | $ | (830.3) |  |  | $ | (120.9) |  |

[0001262039-22-000026:8k_2_02:102]
Reconciliation of GAAP operating income to non-GAAP operating income, operating margin, net income attributable to Fortinet, Inc. and diluted net income per share attributable to Fortinet, Inc.

[0001262039-22-000026:8k_2_02:103]
|  | Three Months Ended June 30, 2022 |  | Three Months Ended June 30, 2021 |
|  | GAAP Results |  | Adjustments |  | Non-GAAP Results |  | GAAP Results |  | Adjustments |  | Non-GAAP Results |
| Operating income | $ | 195.3 |  |  | $ | 60.1 |  | (a) | $ | 255.4 |  |  | $ | 147.5 |  |  | $ | 55.8 |  | (b) | $ | 203.3 |  |
| Operating margin | 19.0 | % |  |  |  | 24.8 | % |  | 18.4 | % |  |  |  | 25.4 | % |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | 55.3 |  |  |  |  |  |  | 53.5 |  |  |  |
| Amortization of acquired intangible assets |  |  | 6.0 |  |  |  |  |  |  | 3.5 |  |  |  |
| Gain on intellectual property matter |  |  | (1.2) |  |  |  |  |  |  | (1.2) |  |  |  |
| Tax adjustment |  |  | (39.1) |  | (c) |  |  |  |  | (34.6) |  | (c) |  |
| Adjustments attributable non-controlling interests |  |  | (0.4) |  | (d) |  |  |  |  | — |  |  |  |
| Net income attributable to Fortinet, Inc. | $ | 173.5 |  |  | $ | 20.6 |  |  | $ | 194.1 |  |  | $ | 137.5 |  |  | $ | 21.2 |  |  | $ | 158.7 |  |
| Diluted net income per share attributable to Fortinet, Inc.(e) | $ | 0.21 |  |  |  |  | $ | 0.24 |  |  | $ | 0.16 |  |  |  |  | $ | 0.19 |  |
| Shares used in diluted net income per share attributable to Fortinet, Inc. calculations (e) | 810.1 |  |  |  |  | 810.1 |  |  | 835.4 |  |  |  |  | 835.4 |  |

[0001262039-22-000026:8k_2_02:104]
(a) To exclude $55.3 million of stock-based compensation and $6.0 million of amortization of acquired intangible assets, offset by a $1.2 million gain on intellectual property matter in the three months ended June 30, 2022.

[0001262039-22-000026:8k_2_02:105]
(b) To exclude $53.5 million of stock-based compensation and $3.5 million of amortization of acquired intangible assets, offset by a $1.2 million gain on intellectual property matter in the three months ended June 30, 2021.

[0001262039-22-000026:8k_2_02:106]
(c) Non-GAAP financial information is adjusted to an effective tax rate of 17% and 21% in the three months ended June 30, 2022 and 2021, respectively, on a non-GAAP basis, which differs from the GAAP effective tax rate.

[0001262039-22-000026:8k_2_02:107]
(d) Adjustments related to the non-GAAP results attributable to non-controlling interests, which were adjusted to an effective tax rate of 31% for the subsidiary of Alaxala Networks Corporation in the three months ended June 30, 2022.

[0001262039-22-000026:8k_2_02:108]
(e) All share and per share amounts presented herein have been retroactively adjusted to reflect the five-for-one forward stock split which was effective June 22, 2022.

[0001262039-22-000026:8k_2_02:109]
Reconciliation of total revenue to total billings

[0001262039-22-000026:8k_2_02:110]
|  | Three Months Ended |
|  | June 30,2022 |  | June 30,2021 |
| Total revenue | $ | 1,030.1 |  |  | $ | 801.1 |  |
| Add: Change in deferred revenue | 274.1 |  |  | 159.8 |  |
| Total billings | $ | 1,304.2 |  |  | $ | 960.9 |  |

[0001262039-22-000026:8k_2_02:111]
| Investor Contact: |  | Media Contact: |
| Peter Salkowski |  | Sandra Wheatley |
| Fortinet, Inc. |  | Fortinet, Inc. |
| 408-331-4595 |  | 408-391-9408 |
| psalkowski@fortinet.com |  | swheatley@fortinet.com |
