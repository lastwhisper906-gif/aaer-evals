# FTNT MD&A — 0001262039-22-000029


## mdna

[0001262039-22-000029:mdna:1]
[same as prior period, unchanged from 0001262039-22-000019:mdna:1]

[0001262039-22-000029:mdna:2]
[same as prior period, unchanged from 0001262039-22-000019:mdna:2]

[0001262039-22-000029:mdna:3]
•the duration and impact of the COVID-19 pandemic, including various COVID-19 variants, the implementation of “return to office” plans and marketing events and employee travel;

[0001262039-22-000029:mdna:4]
[same as prior period, unchanged from 0001262039-22-000019:mdna:4]

[0001262039-22-000029:mdna:5]
•effects of increased inflation in many geographies;

[0001262039-22-000029:mdna:6]
[same as prior period, unchanged from 0001262039-22-000019:mdna:6]

[0001262039-22-000029:mdna:7]
[same as prior period, unchanged from 0001262039-22-000019:mdna:7]

[0001262039-22-000029:mdna:8]
[same as prior period, unchanged from 0001262039-22-000019:mdna:8]

[0001262039-22-000029:mdna:9]
[same as prior period, unchanged from 0001262039-22-000019:mdna:9]

[0001262039-22-000029:mdna:10]
•the proportion of our revenue that consists of product and service revenue, and the mix of billings between products and services, the mix of backlog and the duration of service contracts;

[0001262039-22-000029:mdna:11]
[same as prior period, unchanged from 0001262039-22-000019:mdna:11]

[0001262039-22-000029:mdna:12]
[same as prior period, unchanged from 0001262039-22-000019:mdna:12]

[0001262039-22-000029:mdna:13]
[same as prior period, unchanged from 0001262039-22-000019:mdna:13]

[0001262039-22-000029:mdna:14]
[same as prior period, unchanged from 0001262039-22-000019:mdna:14]

[0001262039-22-000029:mdna:15]
[same as prior period, unchanged from 0001262039-22-000019:mdna:15]

[0001262039-22-000029:mdna:16]
•risks and expectations related to acquisitions and equity interests in private and public companies, including integration issues related to product plans, employee groups, controls and processes and the acquired technology, and risks of negative impact by such acquisitions and equity investments on our financial results;

[0001262039-22-000029:mdna:17]
[same as prior period, unchanged from 0001262039-22-000019:mdna:17]

[0001262039-22-000029:mdna:18]
[same as prior period, unchanged from 0001262039-22-000019:mdna:18]

[0001262039-22-000029:mdna:19]
[same as prior period, unchanged from 0001262039-22-000019:mdna:19]

[0001262039-22-000029:mdna:20]
[same as prior period, unchanged from 0001262039-22-000019:mdna:20]

[0001262039-22-000029:mdna:21]
[same as prior period, unchanged from 0001262039-22-000019:mdna:45]

[0001262039-22-000029:mdna:22]
[same as prior period, unchanged from 0001262039-22-000019:mdna:22]

[0001262039-22-000029:mdna:23]
[same as prior period, unchanged from 0001262039-22-000019:mdna:23]

[0001262039-22-000029:mdna:24]
[same as prior period, unchanged from 0001262039-22-000019:mdna:24]

[0001262039-22-000029:mdna:25]
[same as prior period, unchanged from 0001262039-22-000019:mdna:25]

[0001262039-22-000029:mdna:26]
•statements regarding expected outcomes and liabilities in litigation;

[0001262039-22-000029:mdna:27]
[same as prior period, unchanged from 0001262039-22-000019:mdna:27]

[0001262039-22-000029:mdna:28]
[same as prior period, unchanged from 0001262039-22-000019:mdna:28]

[0001262039-22-000029:mdna:29]
[same as prior period, unchanged from 0001262039-22-000019:mdna:29]

[0001262039-22-000029:mdna:30]
[same as prior period, unchanged from 0001262039-22-000019:mdna:30]

[0001262039-22-000029:mdna:31]
[same as prior period, unchanged from 0001262039-22-000019:mdna:31]

[0001262039-22-000029:mdna:32]
[same as prior period, unchanged from 0001262039-22-000019:mdna:32]

[0001262039-22-000029:mdna:33]
[same as prior period, unchanged from 0001262039-22-000019:mdna:33]

[0001262039-22-000029:mdna:34]
[same as prior period, unchanged from 0001262039-22-000019:mdna:34]

[0001262039-22-000029:mdna:35]
[same as prior period, unchanged from 0001262039-22-000019:mdna:35]

[0001262039-22-000029:mdna:36]
[same as prior period, unchanged from 0001262039-22-000019:mdna:36]

[0001262039-22-000029:mdna:37]
[same as prior period, unchanged from 0001262039-22-000019:mdna:59]

[0001262039-22-000029:mdna:38]
[same as prior period, unchanged from 0001262039-22-000019:mdna:37]

[0001262039-22-000029:mdna:39]
[same as prior period, unchanged from 0001262039-22-000019:mdna:38]

[0001262039-22-000029:mdna:40]
[same as prior period, unchanged from 0001262039-22-000019:mdna:39]

[0001262039-22-000029:mdna:41]
[same as prior period, unchanged from 0001262039-22-000019:mdna:40]

[0001262039-22-000029:mdna:42]
[same as prior period, unchanged from 0001262039-22-000019:mdna:41]

[0001262039-22-000029:mdna:43]
[same as prior period, unchanged from 0001262039-22-000019:mdna:42]

[0001262039-22-000029:mdna:44]
•Cloud Security—We help customers connect securely to and across their individual, hybrid cloud, multi-cloud and virtualized data center environments by offering security through our virtual firewall and other software products and through integrated cloud- native capabilities with major cloud platforms. Our public and private cloud security solutions, including virtual appliances and hosted solutions, bring our Platform Extension products and services into and across cloud environments, delivering security that follows their applications and data. Our Secure SD-WAN for Multi-Cloud solution automates deployment of an overlay network across different cloud networks and offers visibility, control and centralized management that integrates functionality across multiple cloud environments. Our Cloud Security portfolio also secures applications, including email and web applications and APIs. Fortinet cloud security offerings are available for deployment in major public and private cloud environments, including Alibaba Cloud, Amazon Web Services, Google Cloud, IBM Cloud, Microsoft Azure, Oracle Cloud and VMWare Cloud. We also offer managed IPS and web application firewall (“WAF”) rules delivered by FortiGuard Labs as an overlay service to native security offerings offered by Amazon Web Services.

[0001262039-22-000029:mdna:45]
[same as prior period, unchanged from 0001262039-22-000019:mdna:44]

[0001262039-22-000029:mdna:46]
29

[0001262039-22-000029:mdna:47]
[same as prior period, unchanged from 0001262039-22-000019:mdna:46]

[0001262039-22-000029:mdna:48]
[same as prior period, unchanged from 0001262039-22-000019:mdna:47]

[0001262039-22-000029:mdna:49]
[same as prior period, unchanged from 0001262039-22-000019:mdna:48]

[0001262039-22-000029:mdna:50]
•Total revenue was $1.03 billion and $1.98 billion during the three and six months ended June 30, 2022, an increase of 29% and 31%, respectively, compared to $801.1 million and $1.51 billion in the same periods last year. Product revenue was $400.7 million and $771.7 million during the three and six months ended June 30, 2022, an increase of 34% and 43%, respectively, compared to $298.3 million and $539.0 million in the same periods last year. Service revenue was $629.4 million and $1.21 billion during the three and six months ended June 30, 2022, an increase of 25%, in each period respectively, compared to $502.8 million and $972.4 million in the same periods last year.

[0001262039-22-000029:mdna:51]
•Total gross profit was $779.3 million and $1.48 billion during the three and six months ended June 30, 2022, an increase of 27%, in each period respectively, compared to $614.2 million and $1.17 billion in the same periods last year.

[0001262039-22-000029:mdna:52]
•Cash, cash equivalents, short-term and long-term investments and marketable equity securities were $1.94 billion as of June 30, 2022.

[0001262039-22-000029:mdna:53]
•During the six months ended June 30, 2022, we repurchased 25.8 million shares of common stock under our Share Repurchase Program (the “Repurchase Program”), for a total purchase price of $1.49 billion.

[0001262039-22-000029:mdna:54]
•Deferred revenue was $3.93 billion as of June 30, 2022, an increase of $479.1 million, or 14%, compared to $3.45 billion as of December 31, 2021. Deferred revenue was $2.91 billion as of June 30, 2021, an increase of $300.1 million, or 12%, compared to $2.61 billion as of December 31, 2020. Short-term deferred revenue was $2.01 billion as of June 30, 2022, an increase of $235.8 million, or 13%, compared to $1.78 billion as of December 31, 2021. Short-term deferred revenue was $1.53 billion as of June 30, 2021, as increase of $140.2 million, or 10%, compared to $1.39 billion as of December 31, 2020.

[0001262039-22-000029:mdna:55]
•We generated cash flows from operating activities of $719.5 million during the six months ended June 30, 2022, a decrease of $14.6 million, or 2%, compared to the same period last year.

[0001262039-22-000029:mdna:56]
•Total bookings were $1.38 billion during the three months ended June 30, 2022, an increase of 42% compared to $967.9 million in the same period last year. We define bookings as the total value of all orders received during the period.

[0001262039-22-000029:mdna:57]
•Backlog was $349.9 million as of June 30, 2022, an increase of $71.6 million compared to $278.3 million as of March 31, 2022 and an increase of $188.0 million compared to $161.9 million as of December 31, 2021. Backlog represents orders received but not fulfilled and excludes backlog related to Alaxala which was not significant.

[0001262039-22-000029:mdna:58]
On a geographic basis, revenue continues to be diversified, which remains a key strength of our business. During the three months ended June 30, 2022, the Americas region, the Europe, Middle East and Africa (“EMEA”) region and the Asia Pacific (“APAC”) region contributed 40%, 38% and 22% of our total revenue, respectively, and increased by 23%, 28% and 42% compared to the same period last year, respectively. During the six months ended June 30, 2022, the Americas region, the EMEA region and the APAC region contributed 40%, 37% and 23% of our total revenue, respectively, and increased by 27%, 27% and 50% compared to the same period last year, respectively.

[0001262039-22-000029:mdna:59]
Our revenue growth was driven by strong product revenue performance. Product revenue grew 34% and 43% during the three and six months ended June 30, 2022, respectively, compared to the same periods last year. Product revenue growth was consistent with an elevated cyber threat landscape. Core Platform products accounted for more than half of the product revenue growth during the three months ended June 30, 2022. While Secure SD-WAN contributed to product revenue growth, a main driver was the strong demand for the wide range of other operating system capabilities embedded in the Core Platform products. We experienced strong product revenue growth across many of our Platform Extension products, including our OT solutions, secure access products and software licenses. The impact of the increase in backlog was mainly seen in FortiGate, FortiSwitch and FortiAP products. Service revenue growth of 25% during both the three and six months ended June 30, 2022 compared to the same periods last year, was driven by the strength of our FortiCare technical support and other service revenue which grew 26%, and of FortiGuard and other security subscription revenue, which grew 25% and 24%, respectively.

[0001262039-22-000029:mdna:60]
Our billings were diversified on a geographic basis. During the three months ended June 30, 2022, approximately 45% of our billings in the aggregate were from over 100 countries that each individually contributed less than 3% of our billings.

[0001262039-22-000029:mdna:61]
Operating expenses as a percentage of revenue decreased by 1.6 and 2.4 percentage points during the three and six months ended June 30, 2022, respectively, compared to the same periods last year. Headcount increased to 11,508 employees and contractors as of June 30, 2022, a 13% increase compared to 10,195 as of December 31, 2021.

[0001262039-22-000029:mdna:62]
[same as prior period, unchanged from 0001262039-22-000019:mdna:63]

[0001262039-22-000029:mdna:63]
[same as prior period, unchanged from 0001262039-22-000019:mdna:64]

[0001262039-22-000029:mdna:64]
While the broader implications of the COVID-19 pandemic on our employees and overall financial performance continue to evolve, we have seen certain impacts on our business and operations, results of operations, financial condition, cash flows, liquidity and capital and financial resources as of and during the three and six months ended June 30, 2022. Conversely, some aspects of our business do not appear to have been significantly affected. During the three and six months ended June 30, 2022, we have observed the following:

[0001262039-22-000029:mdna:65]
[same as prior period, unchanged from 0001262039-22-000019:mdna:66]

[0001262039-22-000029:mdna:66]
•In many countries, our employees’ ability to travel was reduced and certain in-person sales and marketing events or meetings that would normally have been held were canceled, postponed or converted into virtual events. However, as certain country’s restrictions continued to ease, we have started to see an increase in expenses related to travel and marketing events. Although we cannot predict if or when such expenses will return to pre-pandemic levels, as of June 30, 2022, we have started to see an increase in such expenses as compared to the same period last year.

[0001262039-22-000029:mdna:67]
[same as prior period, unchanged from 0001262039-22-000019:mdna:68]

[0001262039-22-000029:mdna:68]
•Our days sales outstanding increased to 80 days in the second quarter of 2022, compared to 66 days in the same period last year, primarily due to the sales linearity. The accounts receivable allowance for credit losses was $5.2 million as of June 30, 2022, increased by $2.8 million compared to $2.4 million as of December 31, 2021, primarily due to an increase in past due invoices over 60 and 90 days.

[0001262039-22-000029:mdna:69]
Going forward, the situation remains uncertain, rapidly changing and hard to predict, and the COVID-19 pandemic may have a material negative impact on our future periods. If we experience component, shipping, inventory challenges or customer payment, it will negatively impact billings and product revenue in the current quarter and FortiGuard and FortiCare service revenues in subsequent quarters, as we sell annual and multi-year service contracts that are recognized ratably over the contractual service term, generally starting on the contract registration date. In addition, the broader implications of the pandemic on our business and operations and our financial results, including the extent to which the effects of the pandemic will impact future results and growth in the cybersecurity industry, remain uncertain. The extent of the impact of the COVID-19

[0001262039-22-000029:mdna:70]
[same as prior period, unchanged from 0001262039-22-000019:mdna:89]

[0001262039-22-000029:mdna:71]
pandemic on our operational and financial performance will depend on ongoing developments, including the duration and spread of the virus and its variants, the impact on our end-customers’ spending, the volume of sales and length of our sales cycles, the impact on our partners, suppliers, and employees, actions that may be taken by governmental authorities and other factors identified in Part II, Item 1A “Risk Factors” in this Form 10-Q. Given the dynamic nature of these circumstances, the full impact of the COVID-19 pandemic on our business and operations, results of operations, financial condition, cash flows, liquidity and capital and financial resources cannot be reasonably estimated at this time.

[0001262039-22-000029:mdna:72]
[same as prior period, unchanged from 0001262039-22-000019:mdna:70]

[0001262039-22-000029:mdna:73]
Due to the war in Ukraine and the resulting sanctions and other actions against Russia and Belarus and due to inflation and the economic downturn and possible recession, there has been uncertainty and disruption in the global economy. At the beginning of the war in Ukraine in late February 2022, we experienced immediate reductions in orders from Russia. On March 7, 2022, we announced that we were suspending sales, support and other operations in Russia. Starting from March 7, 2022, we are not recognizing service revenue on service contracts that have been suspended in Russia.

[0001262039-22-000029:mdna:74]
Although the Russian war against Ukraine did not have a material adverse impact on our revenue or other financial results for the three and six months ended June 30, 2022, at this time we are unable to fully assess the aggregate impact it will have on our business in future periods due to various uncertainties, which include, but are not limited to, the duration of the war, its effect on the economy, its impact to the businesses of our customers and distributors, actions that may be taken by governmental authorities related to the war, and other factors identified in Part II, Item 1A, “Risk Factors” in this Quarterly Report, including the risk factor titled “The war in Ukraine and our suspension of operations in Russia have affected and may continue to affect our business.”

[0001262039-22-000029:mdna:75]
[same as prior period, unchanged from 0001262039-22-000019:mdna:74]

[0001262039-22-000029:mdna:76]
[same as prior period, unchanged from 0001262039-22-000019:mdna:75]

[0001262039-22-000029:mdna:77]
We also offer our products hosted in our own data centers and through major cloud providers, and have recognized revenue on a usage basis from our data centers as well as Alibaba Cloud, Amazon Web Services, Google Cloud, IBM Cloud, Microsoft Azure and Oracle Cloud. We have also recognized revenue from customers who deploy our products in a bring-your-own-license (“BYOL”) arrangement in private clouds or at cloud providers. In a BYOL arrangement, a customer purchases a software license from us through our channel partners and deploys the software in a cloud provider’s environment. Similarly, customers may purchase such a license from us and deploy it in third-party clouds or in their private cloud.

[0001262039-22-000029:mdna:78]
Our customers purchase our hardware products and software licenses, as well as our FortiGuard and other security subscription and FortiCare technical support services. We generally invoice at the time of our sale for the total price of the products and security and technical support services. Standard payment terms are generally no more than 60 days, though we may offer extended payment terms to certain distributors or related to certain transactions.

[0001262039-22-000029:mdna:79]
[same as prior period, unchanged from 0001262039-22-000019:mdna:78]

[0001262039-22-000029:mdna:80]
We monitor several key metrics, including the key financial metrics set forth below, in order to help us evaluate growth trends, establish budgets, measure the effectiveness of our sales and marketing efforts, and assess operational efficiencies. The following table summarizes revenue, deferred revenue, billings (non-GAAP), net cash provided by operating activities, and free cash flow (non-GAAP). We discuss revenue below under “Results of Operations,” and we discuss net cash

[0001262039-22-000029:mdna:81]
[same as prior period, unchanged from 0001262039-22-000019:mdna:101]

[0001262039-22-000029:mdna:82]
provided by operating activities below under “—Liquidity and Capital Resources.” Deferred revenue, billings (non-GAAP), and free cash flow (non-GAAP) are discussed immediately below the following table:

[0001262039-22-000029:mdna:83]
|  | Three Months Ended Or As Of |
|  | June 30, 2022 |  | June 30, 2021 |
|  | (in millions) |
| Revenue | $ | 1,030.1 |  |  | $ | 801.1 |  |
| Deferred revenue | $ | 3,932.0 |  |  | $ | 2,905.4 |  |
| Billings (non-GAAP) | $ | 1,304.2 |  |  | $ | 960.9 |  |
| Net cash provided by operating activities | $ | 323.4 |  |  | $ | 418.2 |  |
| Free cash flow (non-GAAP) | $ | 283.5 |  |  | $ | 394.7 |  |

[0001262039-22-000029:mdna:84]
Deferred revenue. Our deferred revenue consists of amounts that have been invoiced but that have not yet been recognized as revenue. The majority of our deferred revenue balance consists of the unrecognized portion of service revenue from FortiGuard and other security subscription and FortiCare technical support service contracts, which is recognized as revenue ratably over the contractual service period. We monitor our deferred revenue balance, short term and total deferred revenue growth and the mix of short-term and long-term deferred revenue because deferred revenue represents a significant portion of free cash flow and of revenue to be recognized in future periods. Deferred revenue was $3.93 billion as of June 30, 2022, an increase of $479.1 million, or 14%, from December 31, 2021. Short term deferred revenue was $2.01 billion as of June 30, 2022, an increase of $235.8 million, or 13%, from December 31, 2021.

[0001262039-22-000029:mdna:85]
Billings (non-GAAP). We define billings as revenue recognized in accordance with GAAP plus the change in deferred revenue from the beginning to the end of the period, less any deferred revenue balances acquired from business combination(s) during the period. We consider billings to be a useful metric for management and investors because billings drive current and future revenue, which is an important indicator of the health and viability of our business. There are several limitations related to the use of billings instead of GAAP revenue. First, billings include amounts that have not yet been recognized as revenue and are impacted by the term of FortiGuard security and FortiCare and other support agreements. Second, we may calculate billings in a manner that is different from peer companies that report similar financial measures. Management accounts for these limitations by providing specific information regarding GAAP revenue and evaluating billings together with GAAP revenue. Total billings were $1.30 billion for the three months ended June 30, 2022, an increase of 36% compared to $960.9 million in the same period last year.

[0001262039-22-000029:mdna:86]
[same as prior period, unchanged from 0001262039-22-000019:mdna:83]

[0001262039-22-000029:mdna:87]
|  | Three Months Ended |
|  | June 30, 2022 |  | June 30, 2021 |
|  | (in millions) |
| Billings: |  |  |  |
| Revenue | $ | 1,030.1 |  |  | $ | 801.1 |  |
| Add: Change in deferred revenue | 274.1 |  |  | 159.8 |  |
| Total billings (non-GAAP) | $ | 1,304.2 |  |  | $ | 960.9 |  |

[0001262039-22-000029:mdna:88]
Free cash flow (non-GAAP). We define free cash flow as net cash provided by operating activities minus purchases of property and equipment and excluding any significant non-recurring items. We believe free cash flow to be a liquidity measure that provides useful information to management and investors about the amount of cash generated by the business that, after capital expenditures, can be used for strategic opportunities, including repurchasing outstanding common stock, investing in our business, making strategic acquisitions, and strengthening the balance sheet. A limitation of using free cash flow rather than the GAAP measures of cash provided by or used in operating activities, investing activities, and financing activities is that free cash flow does not represent the total increase or decrease in the cash and cash equivalents balance for the period because it excludes cash flows from investing activities other than capital expenditures and cash flows from financing activities. Management accounts for this limitation by providing information about our capital expenditures and other investing and financing activities on the face of the consolidated statements of cash flows and under “—Liquidity and Capital Resources” and by presenting cash flows from investing and financing activities in our reconciliation of free cash flow. In addition, it is important to note that other companies, including companies in our industry, may not use free cash flow, may calculate free cash flow in a different manner than we do or may use other financial measures to evaluate their performance, all of which could reduce the usefulness of free

[0001262039-22-000029:mdna:89]
33

[0001262039-22-000029:mdna:90]
cash flow as a comparative measure. A reconciliation of net cash provided by operating activities, the most directly comparable financial measure calculated and presented in accordance with GAAP, to free cash flow is provided below:

[0001262039-22-000029:mdna:91]
|  | Three Months Ended |
|  | June 30, 2022 |  | June 30, 2021 |
|  | (in millions) |
| Free Cash Flow: |  |  |  |
| Net cash provided by operating activities | $ | 323.4 |  |  | $ | 418.2 |  |
| Less: Purchases of property and equipment | (39.9) |  |  | (23.5) |  |
| Free cash flow (non-GAAP) | $ | 283.5 |  |  | $ | 394.7 |  |
| Net cash provided (used) in investing activities | $ | 294.1 |  |  | $ | (278.2) |  |
| Net cash used in financing activities | $ | (830.3) |  |  | $ | (120.9) |  |

[0001262039-22-000029:mdna:92]
[same as prior period, unchanged from 0001262039-22-000019:mdna:87]

[0001262039-22-000029:mdna:93]
Our discussion and analysis of our financial condition and results of operations are based upon our financial statements, which have been prepared in accordance with GAAP. These principles require us to make estimates and judgments that affect the reported amounts of assets, liabilities, revenue, cost of revenue and expenses, and related disclosures. We base our estimates on historical experience and on various other assumptions that we believe to be reasonable under the circumstances. To the extent that there are material differences between these estimates and our actual results, our future financial statements will be affected.

[0001262039-22-000029:mdna:94]
Except as noted below, there were no material changes to our critical accounting policies and estimates as of and for the three and six months ended June 30, 2022, as compared to the critical accounting policies and estimates described in our Annual Report on Form 10-K filed with the SEC on February 25, 2022 (the “Form 10-K”).

[0001262039-22-000029:mdna:95]
[same as prior period, unchanged from 0001262039-22-000019:mdna:92]

[0001262039-22-000029:mdna:96]
Equity Method Investments

[0001262039-22-000029:mdna:97]
We evaluate our investments for OTTIs when circumstances indicate those assets may be impaired. When the decline in value is deemed to be other than temporary, an impairment is recognized to the extent that the fair value is less than the carrying value of the investment. We consider various factors in determining whether a loss in value of an investment is other than temporary including: the length of time and the extent to which the fair value has been below cost; the financial condition of the investees, and our intent and ability to retain the investment for a period of time sufficient to allow for recovery of value. Management makes certain judgments and estimates in its assessment including but not limited to: identifying if circumstances indicate a decline in value is other than temporary, expectations about the business operations of investees, as well as industry, financial and market factors. Any significant changes in assumptions or judgments in assessing impairments could result in an impairment charge.

[0001262039-22-000029:mdna:98]
[same as prior period, unchanged from 0001262039-22-000019:mdna:122]

[0001262039-22-000029:mdna:99]
[same as prior period, unchanged from 0001262039-22-000019:mdna:93]

[0001262039-22-000029:mdna:100]
Three Months Ended June 30, 2022 and 2021

[0001262039-22-000029:mdna:101]
[same as prior period, unchanged from 0001262039-22-000019:mdna:95]

[0001262039-22-000029:mdna:102]
|  | Three Months Ended |  |  |  |  |
| June 30,2022 |  | June 30,2021 |  |  |  |  |
| Amount |  | % ofRevenue |  | Amount |  | % ofRevenue |  | Change |  | % Change |
| (in millions, except percentages) |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 400.7 |  |  | 39 | % |  | $ | 298.3 |  |  | 37 | % |  | $ | 102.4 |  |  | 34 | % |
| Service | 629.4 |  |  | 61 |  |  | 502.8 |  |  | 63 |  |  | 126.6 |  |  | 25 |  |
| Total revenue | $ | 1,030.1 |  |  | 100 | % |  | $ | 801.1 |  |  | 100 | % |  | $ | 229.0 |  |  | 29 | % |
| Revenue by geography: |  |  |  |  |  |  |  |  |  |  |  |
| Americas | $ | 413.6 |  |  | 40 | % |  | $ | 337.0 |  |  | 42 | % |  | $ | 76.6 |  |  | 23 | % |
| EMEA | 391.8 |  |  | 38 |  |  | 306.2 |  |  | 38 |  |  | 85.6 |  |  | 28 |  |
| APAC | 224.7 |  |  | 22 |  |  | 157.9 |  |  | 20 |  |  | 66.8 |  |  | 42 |  |
| Total revenue | $ | 1,030.1 |  |  | 100 | % |  | $ | 801.1 |  |  | 100 | % |  | $ | 229.0 |  |  | 29 | % |

[0001262039-22-000029:mdna:103]
Total revenue increased by $229.0 million, or 29%, during the three months ended June 30, 2022 compared to the same period last year. We continued to experience significant organic revenue growth (i.e. revenue growth excluding attribution from recent acquisitions) with diversification of revenue geographically, and across both customers and industries. Revenue from all regions grew, with EMEA contributing the largest portion of the increase on an absolute dollar basis and APAC, which included Alaxala, contributing the largest portion of the increase on a percentage basis.

[0001262039-22-000029:mdna:104]
Product revenue increased by $102.4 million, or 34%, during the three months ended June 30, 2022 compared to the same period last year. Product revenue growth was consistent with an elevated cyber threat landscape and included the benefit of certain pricing actions. Core Platform products accounted for more than half of the product revenue growth in the three months ended June 30, 2022. While Secure SD-WAN contributed to product revenue growth, the main driver was the strong demand for the wide range of other operating system capabilities embedded in the Core Platform products. We also experienced strong revenue growth across many Platform Extension products, including operational technology “OT” solutions and other secure access.

[0001262039-22-000029:mdna:105]
Service revenue increased by $126.6 million, or 25%, during the three months ended June 30, 2022 compared to the same period last year. FortiGuard security subscription and FortiCare and other technical support and other revenues increased by $67.5 million, or 25%, and by $59.1 million, or 26%, respectively, during the three months ended June 30, 2022 compared to the same period last year. The increases were primarily due to the recognition of revenue from our growing deferred revenue balance related to FortiGuard and other security subscriptions delivered to on-premise and cloud based environments as well as FortiCare and other technical support, including our customers moving to higher-tier support offerings.

[0001262039-22-000029:mdna:106]
Of the service revenue recognized during the three months ended June 30, 2022, 87% was included in the deferred revenue balance as of March 31, 2022. Of the service revenue recognized during the three months ended June 30, 2021, 89% was included in the deferred revenue balance as of March 31, 2021. We expect service revenue growth will continue to increase through the remainder of 2022, as our business is expected to grow and as service revenue benefits from previous pricing actions. However, there are risks to service revenue growth rates, including customers reducing their spending, supply chain constraints, customers taking longer to buy their service, or other reasons.

[0001262039-22-000029:mdna:107]
[same as prior period, unchanged from 0001262039-22-000019:mdna:102]

[0001262039-22-000029:mdna:108]
|  | Three Months Ended |  |  |  |  |
| June 30,2022 |  | June 30,2021 |  | Change |  | % Change |
| (in millions, except percentages) |
| Cost of revenue: |  |  |  |  |  |  |  |
| Product | $ | 155.2 |  |  | $ | 115.6 |  |  | $ | 39.6 |  |  | 34 | % |
| Service | 95.6 |  |  | 71.3 |  |  | 24.3 |  |  | 34 |  |
| Total cost of revenue | $ | 250.8 |  |  | $ | 186.9 |  |  | $ | 63.9 |  |  | 34 | % |
| Gross margin (%): |  |  |  |  |  |  |  |
| Product | 61.3 | % |  | 61.2 | % |  |  |  |  |
| Service | 84.8 |  |  | 85.8 |  |  |  |  |  |
| Total gross margin | 75.7 | % |  | 76.7 | % |  |  |  |  |

[0001262039-22-000029:mdna:109]
Total gross margin decreased by 1.0 percentage points during the three months ended June 30, 2022 compared to the same period last year, driven by the consolidation of Alaxala, costs increases and a change in revenue mix to lower margin product revenue from higher margin service revenue. Revenue mix shifted by 1.7 percentage points from service revenue to product revenue, as a percentage of total revenue. Total gross margin also reflected a decline in services gross margin.

[0001262039-22-000029:mdna:110]
Product gross margin increased by 0.1 percentage points during the three months ended June 30, 2022 compared to the same period last year. The increase in product margin is driven by higher average selling prices, and a mix shift to higher margin high end appliances, partially offset by higher expedite fees, freight fees and other product costs due to supply chain constraints and the consolidation of Alaxala. Cost of product revenue was comprised primarily of third-party contract manufacturers’ costs and the costs of materials used in production.

[0001262039-22-000029:mdna:111]
Service gross margin decreased by 1.0 percentage points during the three months ended June 30, 2022 compared to the same period last year. Cost of service revenue was comprised primarily of personnel and data center costs. The decrease in service gross margin was primarily impacted by our consolidation of Alaxala and our data center expansion.

[0001262039-22-000029:mdna:112]
[same as prior period, unchanged from 0001262039-22-000019:mdna:107]

[0001262039-22-000029:mdna:113]
|  | Three Months Ended |  | Change |  | % Change |
| June 30,2022 |  | June 30,2021 |  |
| Amount |  | % ofRevenue |  | Amount |  | % ofRevenue |  |
| (in millions, except percentages) |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | $ | 124.3 |  |  | 12 | % |  | $ | 106.6 |  |  | 13 | % |  | $ | 17.7 |  |  | 17 | % |
| Sales and marketing | 415.5 |  |  | 40 |  |  | 326.9 |  |  | 41 |  |  | 88.6 |  |  | 27 |  |
| General and administrative | 45.4 |  |  | 4 |  |  | 34.4 |  |  | 4 |  |  | 11.0 |  |  | 32 |  |
| Gain on IP matter | (1.2) |  |  | — |  |  | (1.2) |  |  | — |  |  | — |  |  | — |  |
| Total operating expenses | $ | 584.0 |  |  | 57 | % |  | $ | 466.7 |  |  | 58 | % |  | $ | 117.3 |  |  | 25 | % |
| Percentages have been rounded for presentation purposes and may differ from unrounded results. |

[0001262039-22-000029:mdna:114]
[same as prior period, unchanged from 0001262039-22-000019:mdna:109]

[0001262039-22-000029:mdna:115]
Research and development expense increased by $17.7 million, or 17%, during the three months ended June 30, 2022 compared to the same period last year, primarily due to an increase of $12.7 million in personnel-related costs as a result of increased headcount to support the development of new products and continued enhancements to our existing products. In addition, we incurred increases in depreciation and other occupancy costs of $5.7 million, partially offset by a decrease of $1.3 million of product development costs, such as third-party testing and prototypes. We currently intend to continue to invest in our research and development organization, and expect research and development expense to increase in absolute dollars during the remainder of 2022.

[0001262039-22-000029:mdna:116]
[same as prior period, unchanged from 0001262039-22-000019:mdna:144]

[0001262039-22-000029:mdna:117]
[same as prior period, unchanged from 0001262039-22-000019:mdna:111]

[0001262039-22-000029:mdna:118]
Sales and marketing expense increased by $88.6 million, or 27%, during the three months ended June 30, 2022 compared to the same period last year, primarily due to an increase of $49.6 million in personnel-related costs as a result of increases to sales and marketing headcount in order to drive global market revenue increases. In addition, we incurred increases in marketing-related expense of $14.7 million, travel expense of $11.4 million and depreciation and other occupancy expense of $4.7 million. We currently intend to continue to make investments in sales and marketing resources, which are critical to support our future growth, and expect sales and marketing expense to increase in absolute dollars during the remainder of 2022.

[0001262039-22-000029:mdna:119]
[same as prior period, unchanged from 0001262039-22-000019:mdna:113]

[0001262039-22-000029:mdna:120]
General and administrative expense increased by $11.0 million, or 32%, during the three months ended June 30, 2022 compared to the same period last year, primarily due to an increase of $3.9 million in personnel-related costs and an increase of $3.1 million in provision for expected credit losses. We currently expect general and administrative expense to increase in absolute dollars during the remainder of 2022.

[0001262039-22-000029:mdna:121]
[same as prior period, unchanged from 0001262039-22-000019:mdna:115]

[0001262039-22-000029:mdna:122]
In January 2020, we entered into an agreement with a competitor in the network security industry, whereby, in February 2020, the competitor party paid us a lump sum of $50.0 million for a mutual covenant-not-to-sue for patent claims. During the three months ended June 30, 2022 and 2021, we recorded $1.2 million in amortization of the deferred component as a gain on IP matter in our condensed consolidated statements of income.

[0001262039-22-000029:mdna:123]
[same as prior period, unchanged from 0001262039-22-000019:mdna:117]

[0001262039-22-000029:mdna:124]
We generated operating income of $195.3 million during the three months ended June 30, 2022, an increase of $47.8 million, or 32%, compared to $147.5 million in the same period last year. Operating income as a percentage of revenue was 19% during the three months ended June 30, 2022, compared to 18% in the same period last year. The increase in operating margin is primarily due to 1.2 percentage point and 0.5 percentage points decreases in research and development expense and sales and marketing expense as percentage of revenue, respectively, partially offset by 1.0 percentage points decrease in gross margin and 0.1 percentage point increase in general and administrative expense as percentage of revenue.

[0001262039-22-000029:mdna:125]
Interest income, interest expense and other income (expense)—net

[0001262039-22-000029:mdna:126]
|  | Three Months Ended |  |  |  |  |
| June 30,2022 |  | June 30,2021 |  | Change |  | % Change |
| (in millions, except percentages) |
| Interest income | $ | 2.4 |  |  | $ | 1.2 |  |  | $ | 1.2 |  |  | 100 | % |
| Interest expense | $ | (4.5) |  |  | $ | (4.5) |  |  | $ | — |  |  | — | % |
| Other income (expense)—net | $ | (9.3) |  |  | $ | 0.8 |  |  | $ | (10.1) |  |  | (1,263) | % |

[0001262039-22-000029:mdna:127]
Interest income increased by $1.2 million during the three months ended June 30, 2022 compared to the same period last year, as a result of higher interest rates. Interest income varies depending on our average investment balances during the period, types and mix of investments, and market interest rates. Interest expense remained flat during the three months ended June 30, 2022 compared to the same period last year. The change of Other income (expense)—net during the three months ended June 30, 2022 compared to the same period last year, was primarily due to an increase of $8.6 million loss on marketable equity securities and an increase of $1.7 million of foreign currency exchange loss.

[0001262039-22-000029:mdna:128]
Provision for income taxes

[0001262039-22-000029:mdna:129]
|  | Three Months Ended |  | Change |  | % Change |
| June 30,2022 |  | June 30,2021 |  |
| (in millions, except percentages) |
| Provision for income taxes | $ | 2.4 |  |  | $ | 7.5 |  |  | $ | (5.1) |  |  | (68) | % |
| Effective tax rate (%) | 1 | % |  | 5 | % |  |  |  |  |

[0001262039-22-000029:mdna:130]
37

[0001262039-22-000029:mdna:131]
Our effective tax rate was 1% for the three months ended June 30, 2022 compared to an effective tax rate of 5% for the same period last year. The provision for income taxes for the three months ended June 30, 2022 was primarily comprised of U.S. federal and state taxes, withholding taxes and foreign taxes that were $54.5 million, which were favorably affected by a tax benefit of $18.6 million from the foreign-derived intangible income deduction (the “FDII deduction”), excess tax benefits from stock-based compensation expense of $17.3 million and release of reserves of $16.2 million on uncertain tax positions and the accrued interest thereon due to the expiration of the statute of limitations.

[0001262039-22-000029:mdna:132]
The provision for income taxes for the three months ended June 30, 2021 was comprised of U.S. federal and state taxes, withholding taxes, and foreign taxes that were $38.0 million, which were offset by a tax benefit of $7.1 million from the FDII deduction, excess tax benefits from stock-based compensation expense of $18.2 million and release of reserves of $5.2 million on uncertain tax positions and the accrued interest thereon due to the expiration of the statute of limitations.

[0001262039-22-000029:mdna:133]
Six Months Ended June 30, 2022 and 2021

[0001262039-22-000029:mdna:134]
Revenue

[0001262039-22-000029:mdna:135]
|  | Six Months Ended |  |  |  |  |
| June 30,2022 |  | June 30,2021 |  |  |  |  |
| Amount |  | % ofRevenue |  | Amount |  | % ofRevenue |  | Change |  | % Change |
| (in millions, except percentages) |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 771.7 |  |  | 39 | % |  | $ | 539.0 |  |  | 36 | % |  | $ | 232.7 |  |  | 43 | % |
| Service | 1,213.2 |  |  | 61 |  |  | 972.4 |  |  | 64 |  |  | 240.8 |  |  | 25 |  |
| Total revenue | $ | 1,984.9 |  |  | 100 | % |  | $ | 1,511.4 |  |  | 100 | % |  | $ | 473.5 |  |  | 31 | % |
| Revenue by geography: |  |  |  |  |  |  |  |  |  |  |  |
| Americas | $ | 796.2 |  |  | 40 | % |  | $ | 627.9 |  |  | 41 | % |  | $ | 168.3 |  |  | 27 | % |
| EMEA | 737.8 |  |  | 37 |  |  | 581.9 |  |  | 39 |  |  | 155.9 |  |  | 27 |  |
| APAC | 450.9 |  |  | 23 |  |  | 301.6 |  |  | 20 |  |  | 149.3 |  |  | 50 |  |
| Total revenue | $ | 1,984.9 |  |  | 100 | % |  | $ | 1,511.4 |  |  | 100 | % |  | $ | 473.5 |  |  | 31 | % |

[0001262039-22-000029:mdna:136]
Total revenue increased by $473.5 million, or 31%, during the six months ended June 30, 2022 compared to the same period last year. We continue to experience significant organic revenue growth (i.e. revenue growth excluding attribution from acquisitions) with diversification of revenue geographically, and across both customer and industry segments. Revenue from all regions grew, with Americas contributing the largest portion of the increase on an absolute dollar basis and APAC, which included Alaxala, contributing the largest portion of the increase on a percentage basis.

[0001262039-22-000029:mdna:137]
Product revenue increased by $232.7 million, or 43%, during the six months ended June 30, 2022 compared to the same period last year. Product revenue growth was consistent with an elevated cyber threat landscape and included the benefit of certain pricing actions. Core Platform products accounted for more than half of the product revenue growth in the six months ended June 30, 2022. While Secure SD-WAN contributed to product revenue growth, the main driver was the strong demand for the wide range of other operating system capabilities embedded in the Core Platform products. We also experienced strong revenue growth across many Platform Extension products, including OT solutions and other secure access.

[0001262039-22-000029:mdna:138]
Service revenue increased by $240.8 million, or 25%, during the six months ended June 30, 2022 compared to the same period last year. FortiGuard security subscription and FortiCare technical support and other revenues increased by $125.1 million, or 24%, and by $115.7 million, or 26%, respectively, during the six months ended June 30, 2022 compared to the same period last year. The increases were primarily due to the recognition of revenue from our growing deferred revenue balance related to FortiGuard and other security subscriptions delivered to on-premise and cloud-based environments, as well as FortiCare and other technical support, including our customers moving to higher-tier support offerings.

[0001262039-22-000029:mdna:139]
Of the service revenue recognized during the six months ended June 30, 2022, 80% was included in the deferred revenue balance as of December 31, 2021. Of the service revenue recognized during the six months ended June 30, 2021, 81% was included in the deferred revenue balance as of December 31, 2020. We expect service revenue growth will continue to increase through the remainder of 2022, as our business is expected to grow and as service revenue benefits from previous pricing actions. However, there are risks to service revenue growth rates, including customers reducing their spending, supply chain constraints, customers taking longer to buy their service, or other reasons.

[0001262039-22-000029:mdna:140]
38

[0001262039-22-000029:mdna:141]
Cost of revenue and gross margin

[0001262039-22-000029:mdna:142]
|  | Six Months Ended |  |  |  |  |
| June 30,2022 |  | June 30,2021 |  | Change |  | % Change |
| (in millions, except percentages) |
| Cost of revenue: |  |  |  |  |  |  |  |
| Product | $ | 316.2 |  |  | $ | 206.9 |  |  | $ | 109.3 |  |  | 53 | % |
| Service | 188.4 |  |  | 136.6 |  |  | 51.8 |  |  | 38 | % |
| Total cost of revenue | $ | 504.6 |  |  | $ | 343.5 |  |  | $ | 161.1 |  |  | 47 | % |
| Gross margin (%): |  |  |  |  |  |  |  |
| Product | 59.0 | % |  | 61.6 | % |  |  |  |  |
| Service | 84.5 |  |  | 86.0 |  |  |  |  |  |
| Total gross margin | 74.6 | % |  | 77.3 | % |  |  |  |  |

[0001262039-22-000029:mdna:143]
Total gross margin decreased by 2.7 percentage points during the six months ended June 30, 2022 compared to the same period last year, driven by the consolidation of Alaxala, costs increases and a change in revenue mix to lower margin product revenue from higher margin service revenue. Revenue mix shifted by 3.2 percentage points from service revenue to product revenue, as a percentage of total revenue. Total gross margin also reflected a decline in product gross margin and services gross margin.

[0001262039-22-000029:mdna:144]
Product gross margin decreased by 2.6 percentage points during the six months ended June 30, 2022 compared to the same period last year. The decrease in product margin is driven by higher expedite fees, freight fees and other product costs due to supply chain constraints and the consolidation of Alaxala, partially offset by higher average selling prices and a mix shift to higher margin high end appliances. Cost of product revenue was comprised primarily of third-party contract manufacturers’ costs and the costs of materials used in production.

[0001262039-22-000029:mdna:145]
Service gross margin decreased by 1.5 percentage points during the six months ended June 30, 2022 compared to the same period last year. Cost of service revenue was comprised primarily of personnel and data center costs. The decrease in service gross margin was primarily impacted by our consolidation of Alaxala and our data center expansion.

[0001262039-22-000029:mdna:146]
39

[0001262039-22-000029:mdna:147]
Operating expenses

[0001262039-22-000029:mdna:148]
|  | Six Months Ended |  | Change |  | % Change |
| June 30,2022 |  | June 30,2021 |  |
| Amount |  | % ofRevenue |  | Amount |  | % ofRevenue |  |
| (in millions, except percentages) |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | $ | 249.2 |  |  | 13 | % |  | $ | 203.8 |  |  | 14 | % |  | $ | 45.4 |  |  | 22 | % |
| Sales and marketing | 803.1 |  |  | 41 |  |  | 630.9 |  |  | 42 |  |  | 172.2 |  |  | 27 |  |
| General and administrative | 84.0 |  |  | 4 |  |  | 66.4 |  |  | 4 |  |  | 17.6 |  |  | 27 |  |
| Gain on IP matter | (2.3) |  |  | — |  |  | (2.3) |  |  | — |  |  | — |  |  | — |  |
| Total operating expenses | $ | 1,134.0 |  |  | 57 | % |  | $ | 898.8 |  |  | 60 | % |  | $ | 235.2 |  |  | 26 | % |
| Percentages have been rounded for presentation purposes and may differ from unrounded results. |

[0001262039-22-000029:mdna:149]
Research and development

[0001262039-22-000029:mdna:150]
Research and development expense increased by $45.4 million, or 22%, during the six months ended June 30, 2022 compared to the same period last year, primarily due to an increase of $32.0 million in personnel-related costs as a result of increased headcount to support the development of new products and continued enhancements to our existing products. In addition, we incurred increases in depreciation and other occupancy costs of $13.3 million. We currently intend to continue to invest in our research and development organization, and expect research and development expense to increase sequentially in absolute dollars during the remainder of 2022.

[0001262039-22-000029:mdna:151]
Sales and marketing

[0001262039-22-000029:mdna:152]
Sales and marketing expense increased by $172.2 million, or 27%, during the six months ended June 30, 2022 compared to the same period last year, primarily due to an increase of $106.3 million in personnel-related costs as a result of increases to sales and marketing headcount in order to drive global market revenue increases. In addition, marketing-related expense increased by $24.3 million, travel expense increased by $18.1 million and depreciation expense and other occupancy-related expense increased by $9.2 million. We currently intend to continue to make investments in sales and marketing resources, which are critical to support our future growth, and expect sales and marketing expense to increase sequentially in absolute dollars during the remainder of 2022.

[0001262039-22-000029:mdna:153]
General and administrative

[0001262039-22-000029:mdna:154]
General and administrative expense increased by $17.6 million, or 27%, during the six months ended June 30, 2022 compared to the same period last year, primarily due to an increase of $8.5 million in personnel-related costs, an increase of $3.0 million in provision for expected credit losses, an increase of $1.9 million in depreciation and other occupancy costs, an increase of $1.2 million in postage and freight expense and an increase of $1.0 million in supplies expense. We currently expect general and administrative expense to increase sequentially in absolute dollars during the remainder of 2022.

[0001262039-22-000029:mdna:155]
Operating income and margin

[0001262039-22-000029:mdna:156]
We generated operating income of $346.3 million during the six months ended June 30, 2022, an increase of $77.2 million, or 29%, compared to $269.1 million in the same period last year. Operating income as a percentage of revenue decreased to 17% during the six months ended June 30, 2022 compared to 18% in the same period last year. The decrease in our operating margin was primarily due to a 2.7 percentage points decrease in gross margin, partially offset by 1.2 percentage point, 0.9 percentage point and 0.2 percentage point decreases in sales and marketing expense, research and development expense and general and administrative expense as percentage of revenue, respectively.

[0001262039-22-000029:mdna:157]
40

[0001262039-22-000029:mdna:158]
Interest income, interest expense and other expense—net

[0001262039-22-000029:mdna:159]
|  | Six Months Ended |  |  |  |  |
| June 30,2022 |  | June 30,2021 |  | Change |  | % Change |
| (in millions, except percentages) |
| Interest income | $ | 3.7 |  |  | $ | 2.3 |  |  | $ | 1.4 |  |  | 61 | % |
| Interest expense | $ | (9.0) |  |  | $ | (5.8) |  |  | $ | (3.2) |  |  | 55 | % |
| Other expense—net | $ | (18.4) |  |  | $ | (1.2) |  |  | $ | (17.2) |  |  | 1,433 | % |

[0001262039-22-000029:mdna:160]
Interest income increased by $1.4 million during the six months ended June 30, 2022 compared to the same period last year, primarily as a result of higher interest rates. Interest income varies depending on our average investment balances during the period, types and mix of investments, and market interest rates. Interest expense increased by $3.2 million during the six months ended June 30, 2022 compared to the same period last year, primarily due to the senior notes issued in the first quarter of 2021. The other expense—net increased by $17.2 million during the six months ended June 30, 2022 compared to the same period last year due to a $15.1 million increase of loss on marketable equity securities and a $4.0 million increase of foreign currency exchange loss, partially offset by net rental income of $2.0 million from real estate.

[0001262039-22-000029:mdna:161]
[same as prior period, unchanged from 0001262039-22-000019:mdna:123]

[0001262039-22-000029:mdna:162]
|  | Six Months Ended |  | Change |  | % Change |
| June 30,2022 |  | June 30,2021 |  |
| (in millions, except percentages) |
| Provision for (benefit from) income taxes | $ | (5.7) |  |  | $ | 19.7 |  |  | $ | (25.4) |  |  | (129) | % |
| Effective tax rate (%) | (2) | % |  | 7 | % |  |  |  |  |

[0001262039-22-000029:mdna:163]
Our effective tax rate was negative 2% for the six months ended June 30, 2022 compared to an effective tax rate of 7% for the same period last year. The provision for income taxes for the six months ended June 30, 2022 was primarily comprised of U.S. federal and state taxes, withholding taxes and foreign taxes that were $93.3 million. This tax provision for income taxes was favorably affected by a tax benefit of $33.3 million from the FDII deduction, excess tax benefits from stock-based compensation expense of $49.5 million and release of reserves of $16.2 million on uncertain tax positions and the accrued interest thereon due to the expiration of the statute of limitations.

[0001262039-22-000029:mdna:164]
The provision for income taxes for the six months ended June 30, 2021 was comprised of U.S. federal and state taxes, withholding taxes, and foreign taxes that were $75.4 million, which were offset by a tax benefit of $15.2 million from the FDII deduction, excess tax benefits from stock-based compensation expense of $35.3 million and release of reserves of $5.2 million on uncertain tax positions and the accrued interest thereon due to the expiration of the statute of limitations.

[0001262039-22-000029:mdna:165]
41

[0001262039-22-000029:mdna:166]
[same as prior period, unchanged from 0001262039-22-000019:mdna:127]

[0001262039-22-000029:mdna:167]
|  | As of |
|  | June 30,2022 |  | December 31,2021 |
|  | (in millions) |
| Cash and cash equivalents | $ | 710.0 |  |  | $ | 1,319.1 |  |
| Short-term and long-term investments | 1,209.1 |  |  | 1,634.8 |  |
| Marketable equity securities | 24.3 |  |  | 38.6 |  |
| Total cash, cash equivalents, investments and marketable equity securities | $ | 1,943.4 |  |  | $ | 2,992.5 |  |
| Working capital | $ | 318.0 |  |  | $ | 1,282.5 |  |
|  | Six Months Ended |
|  | June 30,2022 |  | June 30,2021 |
|  | (in millions) |
| Net cash provided by operating activities | $ | 719.5 |  |  | $ | 734.1 |  |
| Net cash provided by (used in) investing activities | 248.7 |  |  | (751.7) |  |
| Net cash provided by (used in) financing activities | (1,576.3) |  |  | 835.1 |  |
| Effect of exchange rate changes on cash and cash equivalents | (1.0) |  |  | — |  |
| Net increase (decrease) in cash and cash equivalents | $ | (609.1) |  |  | $ | 817.5 |  |

[0001262039-22-000029:mdna:168]
Liquidity and capital resources may be impacted by our operating activities, as well as by our stock repurchases, proceeds from the issuance of common stock, investment grade debt issuance and payment of taxes in connection with the net settlement of equity awards, real estate and other capital expenditures, business acquisitions and the timing of inventory deliveries and the related shipments to customers and completeness of such shipments.

[0001262039-22-000029:mdna:169]
[same as prior period, unchanged from 0001262039-22-000019:mdna:130]

[0001262039-22-000029:mdna:170]
In October 2021, our board of directors authorized a $1.25 billion increase in the authorized stock repurchase under the Repurchase Program and extended the term of the Repurchase Program to February 28, 2023, bringing the aggregate amount of authorized to be repurchased to $4.25 billion of our outstanding common stock through February 28, 2023. During the six months ended June 30, 2022, we repurchased 25.8 million shares of common stock under the Repurchase Program for an aggregate purchase price of $1.49 billion. As of June 30, 2022, $29.6 million remained available for future share repurchases under the Repurchase Program.  Refer to Note 16. Subsequent Events in Part I, Item1 of this Quarterly Report on Form 10-Q for information of the approved $1.0 billion increase in the authorized stock repurchase under the Repurchase Program in July 2022.

[0001262039-22-000029:mdna:171]
[same as prior period, unchanged from 0001262039-22-000019:mdna:133]

[0001262039-22-000029:mdna:172]
We expect to continue to increase our office and warehouse capacity to support growth. As we purchase new properties, we will work to incorporate these properties into the environmental goals we have established. We estimate capital expenditures to be between approximately $140 million and $170 million for the second half of 2022.

[0001262039-22-000029:mdna:173]
We believe that our cash provided by operating activities, together with our existing cash, cash equivalents and investments will be sufficient to meet our anticipated cash needs and do not currently intend to retire these Notes early. Refer to Note 10. Debt in Part I, Item 1 of this Quarterly Report on Form 10-Q for information on the Notes. As of June 30, 2022, the long-term debt, net of unamortized discount and debt issuance costs, was $989.4 million.

[0001262039-22-000029:mdna:174]
42

[0001262039-22-000029:mdna:175]
We enter into non-cancellable agreements with contract manufacturers and certain component suppliers to procure inventory based on our requirements in order to negotiate manufacturing lead times and encourage and incentivize vendors to deliver components and finished goods. These purchase commitments as of June 30, 2022 totaled $1.49 billion, an increase of $0.35 billion compared to $1.14 billion as of December 31, 2021 as we increased our commitments in order to address significant supply constraints seen industry-wide due to component shortages caused, in part, by the COVID-19 pandemic, and for which the duration of such constraints is uncertain. Our agreements secured supply and pricing for certain product components and commitments with contract manufacturers to meet customer demand and to address extended lead times. We also have open purchase orders and contractual obligations in the ordinary course of business for which we have not received goods or services. As of June 30, 2022, we had $117.1 million in other contractual commitments having a remaining term in excess of one year that are non-cancelable.

[0001262039-22-000029:mdna:176]
There have been no significant changes to our leases as disclosed in our Annual Report on Form 10-K for the year ended December 31, 2021 other than as of June 30, 2022 we had additional minimum lease payments of $38.9 million relating to operating leases that had been signed but had not yet commenced. These leases will commence during the second half of 2022 and will have lease terms of approximately one to six years.

[0001262039-22-000029:mdna:177]
As of June 30, 2022, our cash, cash equivalents, short-term and long-term investments and marketable equity securities of $1.94 billion were invested primarily in deposit accounts, money market funds, corporate debt securities, commercial paper, certificates of deposit and term deposits, U.S. government and agency securities, municipal bonds and marketable equity securities. It is our investment policy to invest excess cash in a manner that preserves capital, provides liquidity and generates return without significantly increasing risk. We do not enter into investments for trading or speculative purposes.

[0001262039-22-000029:mdna:178]
The amount of cash, cash equivalents and investments held by our international subsidiaries was $150.8 million as of June 30, 2022 and $132.4 million as of December 31, 2021.

[0001262039-22-000029:mdna:179]
[same as prior period, unchanged from 0001262039-22-000019:mdna:140]

[0001262039-22-000029:mdna:180]
As of June 30, 2022, we did not have any relationships with unconsolidated organizations or financial partnerships, such as structured finance or special purpose entities that would have been established for the purpose of facilitating off-balance sheet arrangements or other contractually narrow or limited purposes.

[0001262039-22-000029:mdna:181]
[same as prior period, unchanged from 0001262039-22-000019:mdna:142]

[0001262039-22-000029:mdna:182]
Cash generated by operating activities is our primary source of liquidity. It is primarily comprised of net income, as adjusted for non-cash items and changes in operating assets and liabilities. Non-cash adjustments consist primarily of stock-based compensation, amortization of deferred contract costs and depreciation and amortization. Changes in operating assets and liabilities consist primarily of changes in deferred revenue, deferred contract costs, deferred tax assets and accounts receivable, net.

[0001262039-22-000029:mdna:183]
Our operating activities during the six months ended June 30, 2022 provided cash flows of $719.5 million as a result of the continued growth of our business and our ability to successfully manage our working capital. Changes in operating assets and liabilities primarily resulted from an increase in sales of our FortiGuard and other security subscription services and FortiCare technical support services to new and existing customers, as reflected by an increase of $480.6 million in our deferred revenue during the six months ended June 30, 2022.

[0001262039-22-000029:mdna:184]
[same as prior period, unchanged from 0001262039-22-000019:mdna:147]

[0001262039-22-000029:mdna:185]
The changes in cash flows from investing activities primarily relate to timing of purchases, maturities and sales of investments and purchases of property and equipment. Historically, in making a lease versus ownership decision related to our larger facilities, we have considered various factors including financial metrics and the impact on our engineers and other employees. In certain cases, we have elected to own a facility if we believed that ownership rather than leasing is more closely

[0001262039-22-000029:mdna:186]
43

[0001262039-22-000029:mdna:187]
aligned with our long-term strategy. We expect to make similar decisions in the future. We may also make cash payments in connection with future business combinations.

[0001262039-22-000029:mdna:188]
During the six months ended June 30, 2022, cash provided by investing activities was $248.7 million, driven by $411.2 million in cash proceeds from maturities and sales of investments, net of purchases of investments and $162.5 million of purchases of property and equipment.

[0001262039-22-000029:mdna:189]
[same as prior period, unchanged from 0001262039-22-000019:mdna:150]

[0001262039-22-000029:mdna:190]
[same as prior period, unchanged from 0001262039-22-000019:mdna:151]

[0001262039-22-000029:mdna:191]
During the six months ended June 30, 2022, cash used in financing activities was $1.58 billion, primarily driven by $1.49 billion used to repurchase shares of our common stock and $84.0 million used to pay tax withholding, net of proceeds from the issuance of common stock.
