# FTNT notes — 0001262039-22-000008


## dei:DocumentsIncorporatedByReferenceTextBlock

[0001262039-22-000008:notes:1]
Portions of the registrant’s definitive Proxy Statement relating to its 2022 Annual Meeting of Stockholders (“Proxy Statement”) are incorporated by reference into Part III of this Annual Report on Form 10-K where indicated. Such Proxy Statement will be filed with the United States Securities and Exchange Commission within 120 days after the end of the fiscal year to which this report relates


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001262039-22-000008:notes:2]
THE COMPANY AND SUMMARY OF SIGNIFICANT ACCOUNTING POLICIES
Business—Fortinet, Inc. (“Fortinet”) was incorporated in Delaware in 2000 and is a global leader in broad, integrated and automated cybersecurity solutions. Fortinet provides high performance cybersecurity solutions to a wide variety of businesses, such as large enterprises, communication service providers, government organizations and small to medium-sized enterprises. Fortinet’s cybersecurity solutions are designed to provide broad visibility and segmentation of the digital attack surface, through our integrated Fortinet Security Fabric cybersecurity mesh platform with automated protection, detection and responses.

[0001262039-22-000008:notes:3]
Basis of Presentation and Preparation—The consolidated financial statements of Fortinet and its subsidiaries (collectively, the “Company,” “we,” “us” or “our”) have been prepared in accordance with generally accepted accounting principles in the United States (“GAAP”). We consolidate all legal entities in which we have an absolute controlling financial interest. All intercompany transactions and balances have been eliminated in consolidation.

[0001262039-22-000008:notes:4]
Use of Estimates—The preparation of consolidated financial statements in accordance with GAAP requires management to make estimates and assumptions that affect the amounts reported in the consolidated financial statements and accompanying notes. Such management estimates include, but are not limited to, the determination of contingent liabilities, the determination of our ability to exercise control or significant influence over our investee, the standalone selling price for our products and services, the period of benefit for deferred contract costs for commissions, stock-based compensation, inventory valuation, the fair value of tangible and intangible assets acquired and liabilities assumed in business combinations, the measurement of liabilities for uncertain tax positions and deferred tax assets and liabilities, the assessment of recoverability of our goodwill and other long-lived assets, measurement of non-marketable equity securities and the determination of sales returns reserves. We base our estimates on historical experience and also on assumptions that we believe are reasonable. Actual results could differ materially from those estimates.

[0001262039-22-000008:notes:5]
Concentration Risk—Financial instruments that subject us to concentrations of credit risk consist primarily of cash, cash equivalents, short-term and long-term investments, marketable equity securities and accounts receivable. Our cash balances are maintained as deposits with various large financial institutions in the United States and around the world. Balances in the United States typically exceed the amount of insurance provided on such deposits. We maintain our cash equivalents and investments in money market funds, corporate debt securities, U.S. government and agency securities, commercial paper, certificates of deposit and term deposits and municipal bonds with major financial institutions that our management believes are financially sound.

[0001262039-22-000008:notes:6]
Our accounts receivable are derived from our customers in various geographic locations. We perform ongoing credit evaluations of our customers. We generally do not require collateral on accounts receivable, and we maintain reserves for estimated credit losses. As of December 31, 2021, Exclusive Networks Group (“Exclusive”), TD Synnex and Ingram Micro Inc. (“Ingram Micro”) accounted for 33%, 13% and 13% of total net accounts receivable, respectively. As of December 31, 2020, Exclusive and Ingram Micro accounted for 34% and 11% of total net accounts receivable, respectively.

[0001262039-22-000008:notes:7]
During 2021, Exclusive and Ingram Micro accounted for 31% and 12% of total revenue, respectively. During 2020, Exclusive and Ingram Micro accounted for 30% and 10% of total revenue, respectively. During 2019, Exclusive and Ingram Micro accounted for 31% and 11% of total revenue, respectively.

[0001262039-22-000008:notes:8]
We rely on a small number of manufacturing partners, primarily in Taiwan, to manufacture our products, and some of the chips and other components of our products used by the contract manufacturers are available from limited or sole sources of supply. Our proprietary Application-Specific Integrated Circuits are built by contract manufacturers located in Japan and Taiwan; other integrated circuits are provided by other chip manufacturers and are currently in short supply.

[0001262039-22-000008:notes:9]
Financial Instruments and Fair Value—We define fair value as the price that would be received from selling an asset, or paid to transfer a liability, in an orderly transaction between market participants at the measurement date. When determining the fair value measurements for assets and liabilities which are required to be recorded at fair value, we consider the principal or most advantageous market in which to transact and the market-based risk. We apply fair value accounting for all financial assets and liabilities and non-financial assets and liabilities that are recognized or disclosed at fair value in the financial statements on a recurring basis. Due to their short-term nature, the carrying amounts reported in the consolidated financial statements approximate the fair value for cash and cash equivalents, accounts receivable, accounts payable, accrued liabilities, and accrued payroll and compensation.

[0001262039-22-000008:notes:10]
Comprehensive Income—Comprehensive income includes certain changes in equity from non-owner sources that are excluded from net income, specifically, cumulative foreign currency translation adjustments, unrealized gains and losses on available-for-sale investments and the related tax impact.

[0001262039-22-000008:notes:11]
Foreign Currency and Transaction Gains and Losses—The functional currency for most of our foreign subsidiaries is the U.S. dollar. For our international subsidiary whose functional currency is the local currency, we translate the financial statements of these subsidiaries to U.S. dollars using the exchange rates in effect at the balance sheet dates for assets and liabilities, and average monthly rates of exchange for revenues, costs, and expenses. We record translation gains and losses in accumulated other comprehensive income as a component of equity. We reflect net foreign exchange transaction gains and losses resulting from the conversion of the transaction currency to functional currency as a component of foreign currency exchange gain (loss) in other expense, net. We recognized a foreign currency loss of $8.2 million, $5.5 million and $4.7 million in other expense, net, for 2021, 2020, and 2019, respectively.

[0001262039-22-000008:notes:12]
Cash and Cash Equivalents—We consider all highly liquid investments, purchased with original maturities of three months or less, to be cash equivalents. Cash and cash equivalents consist of balances with banks and highly liquid investments in commercial paper, corporate debt, term deposits and money market funds.

[0001262039-22-000008:notes:13]
Available-for-Sale Investments—We hold investment grade securities consisting of commercial paper, corporate debt securities, U.S. government and agency securities, certificates of deposit and term deposits, money market funds and municipal bonds that our management believes are financially sound. We classify our investments as available-for-sale (“AFS”) at the time of purchase, since it is our intent that these investments are available for current operations. Investments with original maturities greater than three months with a remaining maturity of less than one year from the consolidated balance sheet date are classified as short-term investments. Investments with remaining maturities greater than one year from the consolidated balance sheet date are classified as long-term investments.

[0001262039-22-000008:notes:14]
Our AFS investments in debt securities are carried at estimated fair value with any unrealized gains and losses, net of taxes, included in accumulated other comprehensive income (loss) in consolidated statements of equity. AFS debt securities with an amortized cost basis in excess of estimated fair value are assessed to determine what amount of that difference, if any, is caused by expected credit losses. An investment is impaired if the fair value of the investment is less than its cost. If the fair value of an investment is less than its amortized cost basis at the balance sheet date and if we do not intend to sell the investment, we consider available evidence to assess whether it is more likely than not that we will be required to sell the investment before the recovery of its amortized cost basis. We consult with our investment managers and consider available quantitative and qualitative evidence in evaluating, among other factors, general market conditions, the duration and extent to which the fair value is less than cost, and our ability to hold the investment. Once an impairment is determined to be attributable to credit-related factors, allowance for credit losses (i.e., the credit loss component) on AFS debt securities is recognized as credit loss expense, a charge in other expense—net, on our consolidated statements of income, and any remaining unrealized losses (i.e., the non-credit loss component), net of taxes, are included in accumulated other comprehensive income (loss) on our consolidated statements of equity.

[0001262039-22-000008:notes:15]
Prior to 2020, we followed the guidance in Accounting Standards Codification (“ASC”) 320 Investments—Debt and Equity Securities in determining whether unrealized losses were other than temporary. In June 2016, the Financial Accounting Standards Board (the “FASB”) issued Accounting Standards Update (“ASU”) 2016-13—Financial Instruments—Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments (“Topic 326”). We adopted Topic 326 on January 1, 2020, and now consider whether unrealized losses have resulted from a credit loss or other factors. The unrealized losses on our AFS debt securities as of December 31, 2021 and 2020 were caused by fluctuations in market value and interest rates as a result of the market conditions. We concluded that an allowance for credit losses was unnecessary as of December 31, 2021 and 2020 and that the unrealized losses as of December 31, 2019 were temporary because (i) the decline in market value was attributable to changes in market conditions and not credit quality, and (ii) we concluded that neither do we intend to sell nor is it more likely than not that we will be required to sell these investments prior to recovery of their amortized cost basis. As a result, we had no credit losses recorded for the year ended December 31, 2021 and 2020, and there was no impairment charge for any unrealized losses in 2019.

[0001262039-22-000008:notes:16]
We determine realized gains or losses on sale of AFS debt securities using specific identification method to determine the cost basis of investments sold and record such gains or losses as other income (expense)-net on the consolidated statements of income. We have elected to not record an allowance for credit losses for accrued interest for AFS investments in debt

[0001262039-22-000008:notes:17]
securities and will reverse the accrued interest against interest income in the period in which we determine the accrued interest to be uncollectible.

[0001262039-22-000008:notes:18]
Marketable Equity Securities—Our marketable equity investments with readily determinable fair values are accounted for at fair value through net income. Realized gains and losses on these securities are reported in other income (expense)-net, and are determined using the specific identification method.

[0001262039-22-000008:notes:19]
Investments in privately held companies—Our investments in privately held companies consist of investments in common stock or in-substance common stock of entities. Certain of these investments provide us with the ability to exercise significant influence over the investee, but not an absolute controlling financial interest. These investments are accounted for under the equity method of accounting and were initially recorded at cost. Subsequently, we recognize our proportionate share of the entities’ net income or loss and the amortization of any basis differences as gain or loss from equity method investments in the consolidated statements of income and as an adjustment to the investment balance. We record our proportionate share of the results of equity method investments on a three-month lag basis. We evaluate our equity method investments at the end of each reporting period to determine whether events or changes in business circumstances indicate that the carrying value of the investment may not be recoverable. As of December 31, 2021, our investment in Linksys Holdings, Inc. (“Linksys”) was our only equity method investment and was recorded in other assets. Our remaining investments in privately held companies are recorded at cost and are not material.

[0001262039-22-000008:notes:20]
Accounts receivable—Trade accounts receivable are recorded at the invoiced amount. On January 1, 2020, we adopted Topic 326, which provides guidance on how to measure credit losses on financial instruments, including accounts receivable. Prior to our adoption of Topic 326, our accounts receivable balance was reduced by an allowance for doubtful accounts that we determined based on our assessment of the collectability of customer accounts. Under Topic 326, our accounts receivable balance is reduced by an allowance for expected credit losses. We measure expected credit losses of accounts receivable on a collective (pooled) basis, aggregating accounts receivable that are either current or no more than 60 days past due, and aggregating accounts receivable that are more than 60 days past due. We apply a credit-loss percentage to each of the pools that is based on our historical credit losses. We review whether each of our significant accounts receivable that is more than 60 days past due continues to exhibit similar risk characteristics with the other accounts receivable in the pool. If we determine that it does not, we evaluate it for expected credit losses on an individual basis.

[0001262039-22-000008:notes:21]
We further consider collectability trends for the allowance for credit losses based on our assessment of various factors, including credit quality of our customers, current economic conditions, reasonable and supportable forecasts of future economic conditions, and other factors that may affect our ability to collect from our customers. Expected credit losses are recorded as general and administrative expenses on our consolidated statements of income. The allowance for credit losses was $2.4 million and $2.5 million as of December 31, 2021 and 2020, respectively. Provisions, write-offs and recoveries were not material during the years ended December 31, 2021, 2020 and 2019.

[0001262039-22-000008:notes:22]
Inventory—Inventory is recorded at the lower of cost or net realizable value. Cost is computed using the first-in, first-out method. In assessing the ultimate recoverability of inventory, we make estimates regarding future customer demand, the timing of new product introductions, economic trends and market conditions. If the actual product demand is significantly lower than forecasted, we could be required to record inventory write-downs which would be charged to cost of product revenue.

[0001262039-22-000008:notes:23]
Property and Equipment—Property and equipment are stated at cost less accumulated depreciation. We do not depreciate the allocated cost of land. Depreciation is computed using the straight-line method over the estimated useful lives of the assets as follows:

[0001262039-22-000008:notes:24]
|  | Estimated Useful Lives |
| Building and building improvements | 2 to 40 years |
| Computer equipment and software | 1 to 7 years |
| Evaluation units | 1 year |
| Furniture and fixtures | 3 to 8 years |
| Leasehold improvements | Shorter of useful life or lease term |

[0001262039-22-000008:notes:25]
Business Combinations—We include the results of operations of the businesses that we acquire as of the respective dates of acquisition. We allocate the fair value of the purchase price of our business acquisitions to the tangible and intangible assets acquired and liabilities assumed, based on their estimated fair values. The excess of the purchase price over the fair

[0001262039-22-000008:notes:26]
values of these identifiable assets and liabilities is recorded as goodwill. Our estimates and assumptions are subject to change and we often continue to gather additional information throughout the measurement period, which is up to 12 months after the acquisition date, and if we make changes to the amounts recorded, such amounts are recorded in the period in which they are identified.

[0001262039-22-000008:notes:27]
Impairment of Long-Lived Assets—We evaluate events and changes in circumstances that could indicate carrying amounts of long-lived assets, including intangible assets, may not be recoverable. When such events or changes in circumstances occur, we assess the recoverability of long-lived assets by determining whether the carrying value of such assets will be recovered through undiscounted expected future cash flows. If the total of the future undiscounted cash flows is less than the carrying amount of those assets, we record an impairment charge in the period in which we make the determination. If such assets are considered to be impaired, the impairment to be recognized is measured by the amount by which the carrying amount of the assets exceeds the fair value of the assets. There were no impairments in 2021, 2020 and 2019.

[0001262039-22-000008:notes:28]
Goodwill—Goodwill represents the excess of purchase consideration over the estimated fair value of net assets of businesses acquired in a business combination. Goodwill acquired in a business combination is not amortized, but instead tested for impairment at least annually during the fourth quarter, or sooner when circumstances indicate an impairment may exist. We perform a qualitative assessment in the fourth quarter of each year, or more frequently if indicators of potential impairment exist, to determine if any events or circumstances exist, such as an adverse change in business climate or a decline in the overall industry that would indicate that it would more likely than not reduce the fair value of a reporting unit below its carrying amount, including goodwill. Then we perform a quantitative impairment test by comparing the fair value of a reporting unit with its carrying amount. Any excess in the carrying value of a reporting unit over its fair value is recognized as an impairment loss in goodwill, limited to the total amount of goodwill allocated to that reporting unit.

[0001262039-22-000008:notes:29]
We performed our annual goodwill impairment analysis and did not identify any impairment indicators as a result of the review. As of December 31, 2021, we had one reporting unit.

[0001262039-22-000008:notes:30]
Other Intangible Assets—Intangible assets with finite lives are carried at cost, less accumulated amortization. Amortization is computed using the straight-line or accelerated method over the estimated economic lives of the assets, which range from one to ten years.

[0001262039-22-000008:notes:31]
Income Taxes—We record income taxes using the asset and liability method, which requires the recognition of deferred tax assets and liabilities for the expected future tax consequences of events that have been recognized in our financial statements or tax returns. In addition, deferred tax assets are recorded for the future benefit of utilizing net operating losses and research and development credit carryforwards. Deferred tax assets and liabilities are measured using the currently enacted tax rates that apply to taxable income in effect for the years in which those tax assets and liabilities are expected to be realized or settled. Valuation allowances are provided when necessary to reduce deferred tax assets to the amount expected to be realized.

[0001262039-22-000008:notes:32]
As part of the process of preparing our consolidated financial statements, we are required to estimate our taxes in each of the jurisdictions in which we operate. We estimate actual current tax exposure together with assessing temporary differences resulting from differing treatment of items, such as accruals and allowances not currently deductible for tax purposes. These differences result in deferred tax assets, which are included in our consolidated balance sheets. In general, deferred tax assets represent future tax benefits to be received when certain expenses previously recognized in our consolidated statements of income become deductible expenses under applicable income tax laws, or loss or credit carryforwards are utilized.

[0001262039-22-000008:notes:33]
In assessing the realizability of deferred tax assets, management considers whether it is more likely than not that some portion or all of the deferred tax assets will be realized. The ultimate realization of deferred tax assets is dependent upon the generation of future taxable income during the periods in which those temporary differences become deductible. We continue to assess the need for a valuation allowance on the deferred tax assets by evaluating both positive and negative evidence that may exist. Any adjustment to the valuation allowance on deferred tax assets would be recorded in the consolidated statements of income for the period that the adjustment is determined to be required.

[0001262039-22-000008:notes:34]
We recognize tax benefits from an uncertain tax position only if it is more likely than not, based on the technical merits of the position, that the tax position will be sustained on examination by the tax authorities. The tax benefits recognized in the financial statements from such positions are then measured based on the largest benefit that has a greater than 50% likelihood of being realized upon ultimate settlement.

[0001262039-22-000008:notes:35]
We have elected to account for Global Intangible Low-Taxed Income (“GILTI”), which was introduced in the 2017 Tax Act, as a current period expense.

[0001262039-22-000008:notes:36]
Stock-Based Compensation—The fair value of restricted stock units (“RSUs”) is based on the closing market price of our common stock on the date of grant. We have elected to use the Black-Scholes-Merton (“Black-Scholes”) pricing model to determine the fair value of our employee stock options and our equity incentive plans. Stock-based compensation expense is amortized on a straight-line basis over the service period. We account for forfeitures of all stock-based payment awards when they occur.

[0001262039-22-000008:notes:37]
Leases—We determine if an arrangement is a lease at inception. The right-of-use (“ROU”) assets and the short and long-term lease liabilities from our operating leases are included in other assets, accrued liabilities and other liabilities in our consolidated balance sheets, respectively. The corresponding assets and, the short and long-term lease liabilities from our finance leases are included in property and equipment, accrued liabilities and other liabilities in our consolidated balance sheets, respectively.

[0001262039-22-000008:notes:38]
The ROU assets represent our right to use an underlying asset for the lease term. Lease liabilities represent our obligation to make lease payments under the lease. Operating lease ROU assets and liabilities are recognized at the lease commencement date based on the present value of lease payments over the lease term. The implicit rate within our operating leases is generally not determinable and therefore we use our incremental borrowing rate at the lease commencement date to determine the present value of lease payments. The determination of our incremental borrowing rate requires judgment. We determine our incremental borrowing rate for each lease using indicative bank borrowing rates, adjusted for various factors including level of collateralization, term and currency to align with the terms of a lease. The operating lease ROU asset also includes any lease prepayments and initial direct costs, net of lease incentives. Certain leases include options to extend or terminate the lease. An option to extend the lease is considered in connection with determining the ROU asset and lease liability when it is reasonably certain we will exercise that option. An option to terminate is considered unless it is reasonably certain we will not exercise the option.

[0001262039-22-000008:notes:39]
Lease expense for lease payments for our operating leases is recognized on a straight-line basis over the term of the lease. We begin recognizing rent expense on the date that a lessor makes an underlying asset that is subject to the lease available for our use. For our finance leases, we recognize amortization expense from the amortization of the corresponding assets and interest expense on the related lease liabilities.

[0001262039-22-000008:notes:40]
Advertising Expense—Advertising costs are expensed when incurred and are included in operating expenses in the accompanying consolidated statements of income. Our advertising expenses were not material for any periods presented.

[0001262039-22-000008:notes:41]
Research and Development Costs—Research and development costs are expensed as incurred.

[0001262039-22-000008:notes:42]
Software Development Costs—The costs to develop software that is marketed have not been capitalized as we believe our current software development process is essentially completed concurrently with the establishment of technological feasibility. Such costs are expensed as incurred and included in research and development in our consolidated statements of income.

[0001262039-22-000008:notes:43]
The costs to obtain or develop software for internal use are capitalized based on qualifying criteria, which includes a determination of whether such costs are incurred during the application development stage. Such costs are amortized over the software’s estimated useful life.

[0001262039-22-000008:notes:44]
Deferred Contract Costs and Commission Expense—Sales commissions earned by our sales force are considered incremental and recoverable costs of obtaining a contract with a customer. We recognize sales commissions expenses related to product sales upfront while sales commissions expenses for service contracts are deferred as deferred contract costs in the consolidated balance sheets and amortized over the applicable amortization period. Commission costs for initial contracts that are not commensurate with commissions on renewal contracts are amortized on a straight-line basis over the period of benefit, which we have determined to be five years and which is typically longer than the initial contract term. The amortization of deferred contract costs is included in sales and marketing expense in our consolidated statements of income. Amortization of deferred contract costs during 2021, 2020 and 2019 was $175.9 million, $137.4 million and $107.9 million, respectively. No impairment loss was recognized during 2021, 2020 and 2019.

[0001262039-22-000008:notes:45]
Deferred Revenue—Deferred revenue consists of amounts that have been invoiced but that have not yet been recognized as revenue. Deferred revenue that will be recognized during the succeeding 12-month period is recorded as current deferred revenue and the remaining portion is recorded as non-current deferred revenue. The majority of deferred revenue is comprised of security subscription and technical support services which are invoiced upfront and delivered over 12 months or longer.

[0001262039-22-000008:notes:46]
Revenue Recognition—Our revenue consists of product and service revenue. Revenues are recognized when control of these goods or services is transferred to our customers, in an amount that reflects the consideration we expect to be entitled to in exchange for those goods or services. We determine revenue recognition through the following steps:

[0001262039-22-000008:notes:47]
•identification of a contract or contracts with a customer;

[0001262039-22-000008:notes:48]
•identification of the performance obligations in a contract, including evaluation of performance obligations and evaluating the distinct goods or services in a contract;

[0001262039-22-000008:notes:49]
•determination of a transaction price;

[0001262039-22-000008:notes:50]
•allocation of a transaction price to the performance obligations in a contract; and

[0001262039-22-000008:notes:51]
•recognition of revenue when, or as, we satisfy a performance obligation.

[0001262039-22-000008:notes:52]
We derive a majority of product sales from our FortiGate hardware and virtual machine products which include a broad set of built-in security and networking features and functionalities, including firewall, next-generation firewall, secure web gateway, secure sockets layer (“SSL”) inspection, software-defined wide-area network, intrusion prevention, SSL data leak prevention, virtual private network, switch and wireless controller and wide area network edge.

[0001262039-22-000008:notes:53]
We recognize product revenue upon shipment when control of the promised goods is transferred to the customer. Our term software licenses represent multiple performance obligations, which include software licenses and software support services where the term licenses are recognized upfront upon transfer of control, with the associated software support services recognized ratably over the contract term as services and software updates are provided.

[0001262039-22-000008:notes:54]
Service revenue relates to sales of our FortiGuard security subscription, FortiCare technical support services and other services. Our typical subscription and contractual support term is one to five years. We generally recognize revenue from these services ratably over the support period because of continuous transfer of control to the customer. We also generate a small portion of our revenue from other services consisting of professional services, training and software-as-a-service (“SaaS”) which is either hosted by us or provided through cloud-providers. We recognize revenue from professional and training services as the services are provided. We recognize revenue from SaaS as the subscription service is delivered over the term, which is typically one year, or on a monthly usage basis. To date, SaaS revenue has not represented a significant percentage of our total revenue.

[0001262039-22-000008:notes:55]
Our sales contracts typically contain multiple deliverables, such as hardware, software license, security subscription, technical support services and other services, which are generally capable of being distinct and accounted for as separate performance obligations. Our hardware and software licenses have significant standalone functionalities and capabilities. Accordingly, the hardware and software licenses are distinct from the security subscription and technical support services, as a customer can benefit from the product without the services and the services are separately identifiable within a contract. We allocate a transaction price to each performance obligation based on relative standalone selling price. We establish standalone selling price using the prices charged for a deliverable when sold separately. If not observable through past transactions, we determine standalone selling price by considering multiple historical factors including, but not limited to, cost of products, gross margin objectives, pricing practices, geographies and the term of a service contract. Revenue is reported net of sales tax.

[0001262039-22-000008:notes:56]
In certain circumstances, our contracts include provisions for sales rebates and other customer incentive programs. Additionally, in limited circumstances, we may permit end-customers, distributors and resellers to return our products, subject to varying limitations, for a refund within a reasonably short period from the date of purchase. These amounts are accounted for as variable consideration that can decrease the transaction price. We estimate variable consideration using the expected-value method based on the most likely amounts to which we expect our customers to be entitled. We include estimated amounts in the transaction price to the extent that it is probable that a significant reversal of cumulative revenue recognized will not occur when the uncertainty associated with the variable consideration is resolved. Our estimate for refund liabilities, which include sales returns reserve and customer rebates, was $49.2 million and $43.0 million as of December 31, 2021 and 2020, respectively, and is included in current liabilities in our consolidated balance sheet.

[0001262039-22-000008:notes:57]
We generally invoice at the time of our sale for the total price of the hardware, software licenses, security and technical support and other services. Standard payment terms are generally no more than 60 days, though we continue to offer extended payment terms to certain distributors. We also invoice certain services on a monthly basis. Amounts billed and due from our customers are classified as receivables on the balance sheet and do not bear interest. Our deferred revenue primarily consists of amounts that have been invoiced but have not been recognized as revenue as of period end.

[0001262039-22-000008:notes:58]
Shipping and handling fees charged to our customers are recognized as revenue in the period shipped and the related costs for providing these services are recorded in cost of revenue. Shipping and handling fees recognized were not material during 2021, 2020 and 2019.

[0001262039-22-000008:notes:59]
Warranties—We generally provide a one-year warranty for most hardware products and a 90-day warranty for software. We also provide extended warranties under the terms of our support agreements. A provision for estimated future costs related to warranty activities in the first year after product sale is recorded as a component of cost of product revenues when the product revenue is recognized, based upon historical product failure rates and historical costs incurred in correcting product failures. Warranty costs related to extended warranties sold under support agreements are recognized as cost of service revenue as incurred. In the event we change our warranty reserve estimates, the resulting charge against future cost of revenue or reversal of previously recorded charges may materially affect our gross margins and operating results. Accrued warranty was not significant as of December 31, 2021 and 2020.

[0001262039-22-000008:notes:60]
Contingent Liabilities—From time to time, we are involved in disputes, litigation, and other legal actions. There are many uncertainties associated with any disputes, litigation and other legal actions, and these actions or other third-party claims against us may cause us to incur costly litigation fees, costs and substantial settlement charges, and possibly subject us to damages and other penalties, which are inherently difficult to estimate and could adversely affect our results of operations. In addition, the resolution of any IP litigation may require us to make royalty payments, which could adversely affect our gross margins in future periods. We periodically review significant claims and litigation matters for the probability of an adverse outcome. Estimates can change as individual claims develop. The actual liability in any such matters may be materially different from our estimates, which could result in the need to adjust our liability and record additional expenses, which may be material.

[0001262039-22-000008:notes:61]
Recently Adopted Accounting Standards

[0001262039-22-000008:notes:62]
Income Taxes

[0001262039-22-000008:notes:63]
In December 2019, the Financial Accounting Standards Board (the “FASB”) issued Accounting Standards Update (“ASU”) 2019-12—Income Taxes (“Topic 740”): Simplifying the Accounting for Income Taxes. The amendments in ASU 2019-12 simplify the accounting for income taxes by removing certain exceptions to the general principles in Topic 740. The amendments also improve consistent application and simplification of GAAP for other areas of Topic 740 by clarifying and amending existing guidance. ASU 2019-12 was effective for us beginning on January 1, 2021. The adoption of this guidance did not have any impact on our consolidated financial statements and accompanying disclosures.

[0001262039-22-000008:notes:64]
Business Combinations

[0001262039-22-000008:notes:65]
In October 2021, the FASB issued ASU 2021-08—Business Combinations (“Topic 805”): Accounting for Contract Assets and Contract Liabilities from Contracts with Customers. The amendments in ASU 2021-08 require that an entity recognizes and measures contract assets and contract liabilities acquired in a business combination in accordance with ASC 606, Revenue from Contracts with Customers (“Topic 606”). At the acquisition date, an acquirer should account for the related revenue contracts in accordance with Topic 606 as if it had originated the contracts. The amendments improve comparability for both the recognition and measurement of acquired revenue contracts with customers at the date of and after a business combination. 
We early adopted ASU 2021-08 on January 1, 2021 on a retrospective basis for all business combinations for which the acquisition date occurred subsequent to January 1, 2021. The adoption of ASU 2021-08 resulted in the increase of goodwill by $3.0 million attributable mainly to the acquisition of Alaxala in 2021, as a result of the revised measurement of the assumed deferred revenue balance. The adoption of ASU 2021-08 did not have a material impact to our consolidated statement of income or consolidated statement of cash flows. The adoption did not have a material impact on the other acquisitions in 2021.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001262039-22-000008:notes:66]
REVENUE RECOGNITION
We sell cybersecurity solutions to a variety of organizations, such as enterprises, communication service providers, government organizations and small to medium-sized enterprises. Our revenue consists of product and service revenue. Product revenue is generated by our FortiGate network security products, our Fortinet Security Fabric cybersecurity mesh platform products and other products. Service revenue relates to sales of our security subscription services, which mainly consists of our FortiGuard security solutions, as well as our FortiCare technical support services and other services.

[0001262039-22-000008:notes:67]
Disaggregation of Revenue

[0001262039-22-000008:notes:68]
The following table presents our revenue disaggregated by major product and service lines (in millions):

[0001262039-22-000008:notes:69]
|  | Year Ended December 31, |
|  | 2021 |  | 2020 |  | 2019 |
| Product | $ | 1,255.0 |  |  | $ | 916.4 |  |  | $ | 788.5 |  |
| Service: |  |  |  |  |  |
| Security subscription | 1,125.0 |  |  | 918.7 |  |  | 750.8 |  |
| Technical support and other | 962.2 |  |  | 759.3 |  |  | 623.7 |  |
| Total service revenue | 2,087.2 |  |  | 1,678.0 |  |  | 1,374.5 |  |
| Total revenue | $ | 3,342.2 |  |  | $ | 2,594.4 |  |  | $ | 2,163.0 |  |

[0001262039-22-000008:notes:70]
Deferred Revenue

[0001262039-22-000008:notes:71]
Our deferred revenue consists of amounts that have been invoiced but have not been recognized as revenue as of period end. During 2021, we recognized $1.37 billion in revenue that was included in the deferred revenue balance as of December 31, 2020. During 2020, we recognized $1.15 billion in revenue that was included in the deferred revenue balance as of December 31, 2019.

[0001262039-22-000008:notes:72]
Transaction Price Allocated to the Remaining Performance Obligations

[0001262039-22-000008:notes:73]
As of December 31, 2021, the aggregate amount of the transaction price allocated to remaining performance obligations was $3.45 billion, which was substantially comprised of deferred security subscription and technical support services. We expect to recognize approximately $1.78 billion as revenue over the next 12 months and the remainder thereafter.


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0001262039-22-000008:notes:74]
FINANCIAL INSTRUMENTS AND FAIR VALUE
The following tables summarize our available-for-sale securities (in millions):

[0001262039-22-000008:notes:75]
|  | December 31, 2021 |
|  | AmortizedCost |  | UnrealizedGains |  | UnrealizedLosses |  | FairValue |
| Commercial paper | $ | 566.0 |  |  | $ | — |  |  | $ | (0.2) |  |  | $ | 565.8 |  |
| Corporate debt securities | 540.7 |  |  | — |  |  | (1.2) |  |  | 539.5 |  |
| U.S. government and agency securities | 356.1 |  |  | — |  |  | (1.0) |  |  | 355.1 |  |
| Certificates of deposit and term deposits (1) | 169.1 |  |  | — |  |  | (0.1) |  |  | 169.0 |  |
| Municipal Bonds | 5.4 |  |  | — |  |  | — |  |  | 5.4 |  |
| Total available-for-sale securities | $ | 1,637.3 |  |  | $ | — |  |  | $ | (2.5) |  |  | $ | 1,634.8 |  |
|  | December 31, 2020 |
|  | AmortizedCost |  | UnrealizedGains |  | UnrealizedLosses |  | FairValue |
| Commercial paper | $ | 185.4 |  |  | $ | — |  |  | $ | — |  |  | $ | 185.4 |  |
| Corporate debt securities | 410.5 |  |  | 1.0 |  |  | — |  |  | 411.5 |  |
| U.S. government securities | 184.9 |  |  | — |  |  | — |  |  | 184.9 |  |
| Certificates of deposit and term deposits (1) | 112.0 |  |  | — |  |  | — |  |  | 112.0 |  |
| Total available-for-sale securities | $ | 892.8 |  |  | $ | 1.0 |  |  | $ | — |  |  | $ | 893.8 |  |
| (1) The majority of our certificates of deposit and term deposits are foreign deposits. |

[0001262039-22-000008:notes:76]
The following tables show the gross unrealized losses and the related fair values of our available-for-sale securities that have been in a continuous unrealized loss position (in millions):

[0001262039-22-000008:notes:77]
|  | December 31, 2021 |
|  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
|  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |
| Commercial paper | $ | 288.0 |  |  | $ | (0.2) |  |  | $ | — |  |  | $ | — |  |  | $ | 288.0 |  |  | $ | (0.2) |  |
| Corporate debt securities | 494.4 |  |  | (1.2) |  |  | — |  |  | — |  |  | 494.4 |  |  | (1.2) |  |
| U.S. government and agency securities | 334.2 |  |  | (1.0) |  |  | — |  |  | — |  |  | 334.2 |  |  | (1.0) |  |
| Certificates of deposit and term deposits | 93.1 |  |  | (0.1) |  |  | — |  |  | — |  |  | 93.1 |  |  | (0.1) |  |
| Municipal Bonds | 5.3 |  |  | — |  |  | — |  |  | — |  |  | 5.3 |  |  | — |  |
| Total available-for-sale securities | $ | 1,215.0 |  |  | $ | (2.5) |  |  | $ | — |  |  | $ | — |  |  | $ | 1,215.0 |  |  | $ | (2.5) |  |

[0001262039-22-000008:notes:78]
|  | December 31, 2020 |
|  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
|  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |
| Commercial paper | $ | 61.5 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 61.5 |  |  | $ | — |  |
| Corporate debt securities | 111.3 |  |  | — |  |  | — |  |  | — |  |  | 111.3 |  |  | — |  |
| U.S. government securities | 38.1 |  |  | — |  |  | — |  |  | — |  |  | 38.1 |  |  | — |  |
| Certificates of deposit and term deposits | 29.5 |  |  | — |  |  | — |  |  | — |  |  | 29.5 |  |  | — |  |
| Total available-for-sale securities | $ | 240.4 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 240.4 |  |  | $ | — |  |

[0001262039-22-000008:notes:79]
The contractual maturities of our investments were as follows (in millions):

[0001262039-22-000008:notes:80]
|  | December 31,2021 |  | December 31,2020 |
| Due within one year | $ | 1,194.0 |  |  | $ | 775.5 |  |
| Due within one to three years | 440.8 |  |  | 118.3 |  |
| Total | $ | 1,634.8 |  |  | $ | 893.8 |  |

[0001262039-22-000008:notes:81]
Available-for-sale securities are reported at fair value, with unrealized gains and losses and the related tax impact included as a separate component of equity and in comprehensive income.

[0001262039-22-000008:notes:82]
Realized gains and losses on available-for-sale securities were insignificant in the periods presented.

[0001262039-22-000008:notes:83]
Our marketable equity securities were $38.6 million as of December 31, 2021. The changes in fair value of our marketable equity securities are recorded in other expense, net on the consolidated statements of income. We recognized $5.1 million of losses in 2021.

[0001262039-22-000008:notes:84]
Fair Value Accounting—We apply the following fair value hierarchy for disclosure of the inputs used to measure fair value. This hierarchy prioritizes the inputs into three broad levels as follows:

[0001262039-22-000008:notes:85]
Level 1—Inputs are unadjusted quoted prices in active markets for identical assets or liabilities.

[0001262039-22-000008:notes:86]
Level 2—Inputs are quoted prices for similar assets and liabilities in active markets or inputs that are observable for the assets or liabilities, either directly or indirectly through market corroboration, for substantially the full term of the financial instruments.

[0001262039-22-000008:notes:87]
Level 3—Unobservable inputs based on our own assumptions used to measure assets and liabilities at fair value. The inputs require significant management judgment or estimation.

[0001262039-22-000008:notes:88]
We measure the fair value of money market funds, certain U.S. government and agency securities and marketable equity securities using quoted prices in active markets for identical assets. The fair value of all other financial instruments was based on quoted prices for similar assets in active markets, or model-driven valuations using significant inputs derived from or corroborated by observable market data.

[0001262039-22-000008:notes:89]
We classify investments within Level 1 if quoted prices are available in active markets for identical securities.

[0001262039-22-000008:notes:90]
We classify items within Level 2 if the investments are valued using model-driven valuations using observable inputs such as quoted market prices, benchmark yields, reported trades, broker/dealer quotes or alternative pricing sources with reasonable levels of price transparency. Investments are held by custodians who obtain investment prices from a third-party pricing provider that incorporates standard inputs in various asset price models.

[0001262039-22-000008:notes:91]
Fair Value of Financial Instruments

[0001262039-22-000008:notes:92]
Assets Measured at Fair Value on a Recurring Basis

[0001262039-22-000008:notes:93]
The following tables present the fair value of our financial assets measured at fair value on a recurring basis (in millions):

[0001262039-22-000008:notes:94]
|  | December 31, 2021 |  | December 31, 2020 |
|  | AggregateFairValue |  | QuotedPrices inActiveMarkets ForIdenticalAssets |  | SignificantOtherObservableRemainingInputs |  | SignificantOtherUnobservableRemainingInputs |  | AggregateFairValue |  | QuotedPrices inActiveMarkets ForIdenticalAssets |  | SignificantOtherObservableRemainingInputs |  | SignificantOtherUnobservableRemainingInputs |
|  |  |  | (Level 1) |  | (Level 2) |  | (Level 3) |  |  |  | (Level 1) |  | (Level 2) |  | (Level 3) |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Commercial paper | $ | 580.3 |  |  | $ | — |  |  | $ | 580.3 |  |  | $ | — |  |  | $ | 197.2 |  |  | $ | — |  |  | $ | 197.2 |  |  | $ | — |  |
| Corporate debt securities | 542.5 |  |  | — |  |  | 542.5 |  |  | — |  |  | 413.7 |  |  | — |  |  | 413.7 |  |  | — |  |
| U.S. government and agency securities | 355.1 |  |  | 345.2 |  |  | 9.9 |  |  | — |  |  | 184.9 |  |  | 184.9 |  |  | — |  |  | — |  |
| Certificates of deposit and term deposits | 259.0 |  |  | — |  |  | 259.0 |  |  | — |  |  | 112.0 |  |  | — |  |  | 112.0 |  |  | — |  |
| Money market funds | 57.5 |  |  | 57.5 |  |  | — |  |  | — |  |  | 152.7 |  |  | 152.7 |  |  | — |  |  | — |  |
| Municipal bonds | 5.4 |  |  | — |  |  | 5.4 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Marketable equity securities | 38.6 |  |  | 38.6 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Total | $ | 1,838.4 |  |  | $ | 441.3 |  |  | $ | 1,397.1 |  |  | $ | — |  |  | $ | 1,060.5 |  |  | $ | 337.6 |  |  | $ | 722.9 |  |  | $ | — |  |
| Reported as: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents | $ | 165.0 |  |  |  |  |  |  |  |  | $ | 166.7 |  |  |  |  |  |  |  |
| Marketable equity securities | 38.6 |  |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  |
| Short-term investments | 1,194.0 |  |  |  |  |  |  |  |  | 775.5 |  |  |  |  |  |  |  |
| Long-term investments | 440.8 |  |  |  |  |  |  |  |  | 118.3 |  |  |  |  |  |  |  |
| Total | $ | 1,838.4 |  |  |  |  |  |  |  |  | $ | 1,060.5 |  |  |  |  |  |  |  |

[0001262039-22-000008:notes:95]
There were no transfers between Level 1 and Level 2 of the fair value hierarchy during the years ended December 31, 2021 and December 31, 2020.


## us-gaap:InventoryDisclosureTextBlock

[0001262039-22-000008:notes:96]
INVENTORY
Inventory consisted of the following (in millions):

[0001262039-22-000008:notes:97]
|  | December 31,2021 |  | December 31,2020 |
| Raw materials | $ | 40.2 |  |  | $ | 13.8 |  |
| Work in process | 9.8 |  |  | — |  |
| Finished goods | 125.8 |  |  | 126.0 |  |
| Inventory | $ | 175.8 |  |  | $ | 139.8 |  |


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001262039-22-000008:notes:98]
PROPERTY AND EQUIPMENT—Net
Property and equipment—net consisted of the following (in millions):

[0001262039-22-000008:notes:99]
|  | December 31,2021 |  | December 31,2020 |
| Land | $ | 204.5 |  |  | $ | 93.3 |  |
| Buildings and improvements | 416.2 |  |  | 150.6 |  |
| Computer equipment and software | 176.1 |  |  | 137.2 |  |
| Leasehold improvements | 40.1 |  |  | 31.9 |  |
| Evaluation units | 15.6 |  |  | 19.8 |  |
| Furniture and fixtures | 26.9 |  |  | 21.3 |  |
| Construction-in-progress | 19.9 |  |  | 166.4 |  |
| Total property and equipment | 899.3 |  |  | 620.5 |  |
| Less: accumulated depreciation | (211.7) |  |  | (172.5) |  |
| Property and equipment—net | $ | 687.6 |  |  | $ | 448.0 |  |

[0001262039-22-000008:notes:100]
We completed construction of a second building at our headquarters campus and it has been placed in service as of June 30, 2021. In conjunction with the completion of the building, we evaluated the range of useful lives of our property and equipment. The range of useful lives for buildings and improvements is now two to forty years, an increase from two to thirty years, and for furniture and fixtures the range is now three to eight years, an increase from three to five years.

[0001262039-22-000008:notes:101]
During 2021, we purchased certain real estate in the United States, Canada and France totaling $180.9 million. The purchases were accounted for under the asset acquisition method. The cost of the assets acquired was allocated to land, buildings, and construction-in-progress based on their relative fair values. The amounts allocated to land, buildings, and construction-in-progress were $111.1 million, $68.9 million and $0.9 million, respectively.

[0001262039-22-000008:notes:102]
Depreciation expense was $65.9 million, $55.5 million and $50.7 million in 2021, 2020 and 2019, respectively.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001262039-22-000008:notes:103]
INVESTMENTS IN PRIVATELY HELD COMPANIES
Linksys Holdings, Inc.

[0001262039-22-000008:notes:104]
On March 19, 2021, we invested $75.0 million in cash for shares of the Series A Preferred Stock of Linksys for a 32.6% ownership interest. On September 24, 2021, we invested an additional $85.0 million in cash for shares of Series A Preferred Stock of Linksys, and as of September 30, 2021, we held 50.8% of the outstanding common stock (on an as-converted basis) of Linksys. Linksys provides router connectivity solutions to the consumer and small business markets.

[0001262039-22-000008:notes:105]
We have concluded that our investment in Linksys is an in-substance common stock investment and that we do not hold an absolute controlling financial interest in Linksys, but that we have the ability to exercise significant influence over the operating and financial policies of Linksys. Determining that we have significant influence but not control over the operating and financial policies of Linksys required significant judgement when considering many factors, including but not limited to the ownership interest in Linksys, board representation, participation in policy-making processes, and participation rights in certain significant financial and operating decisions of Linksys in the ordinary course of business. Therefore, we determined to account for this investment using the equity method of accounting. We record our share of Linksys’ financial results on a three-month lag basis. We determined that there was a basis difference between the cost of our investment in Linksys and the amount of underlying equity in net assets of Linksys. Our share of loss of Linksys’ financial results as well as our share of the amortization of the basis differences, in total was $7.6 million in 2021, and has been recorded in loss from equity method investment on the consolidated statements of income.

[0001262039-22-000008:notes:106]
As of December 31, 2021, the investment was included in other assets on our consolidated balance sheet. Transaction costs related to this investment were not material.

[0001262039-22-000008:notes:107]
Other investments

[0001262039-22-000008:notes:108]
Our investments in the equity securities of privately held companies without readily determinable fair values totaled $1.0 million as of December 31, 2021 and 2020.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001262039-22-000008:notes:109]
BUSINESS COMBINATIONS
2021 Acquisitions

[0001262039-22-000008:notes:110]
Alaxala Networks Corporation

[0001262039-22-000008:notes:111]
On August 31, 2021, we closed an acquisition of 75% of equity interests as controlling interests in Alaxala, a privately held network hardware equipment company in Japan, for $64.2 million in cash. We acquired the equity interest in Alaxala to broaden our offering of secure switches integrated with FortiGate Firewalls and Security Fabric functionality, and, over time, to innovate and rebrand certain of Alaxala’s switches to offer a broader suite of secure switches globally.

[0001262039-22-000008:notes:112]
Under the acquisition method of accounting in accordance with ASC 805, the total preliminary purchase price was allocated to Alaxala’s identifiable tangible and intangible assets acquired and liabilities assumed based on their estimated fair values using management’s best estimates and assumptions to assign fair value as of the acquisition date. The following table provides the assets acquired and liabilities assumed as of the date of acquisition:

[0001262039-22-000008:notes:113]
| (in millions) | Estimated Fair Value |
| ASSETS |  |
| Cash | $ | 1.1 |  |
| Accounts receivable—net | 15.6 |  |
| Inventory | 33.4 |  |
| Prepaid expenses and other current assets | 2.9 |  |
| Property and equipment | 5.3 |  |
| Goodwill | 25.5 |  |
| Other intangible assets | 48.0 |  |
| Other long-term assets | 5.2 |  |
| TOTAL ASSETS | $ | 137.0 |  |
| LIABILITIES |  |
| Accounts payable | $ | 11.0 |  |
| Current portion of long-term debt | 20.2 |  |
| Accrued and other current liabilities | 17.1 |  |
| Other long-term liabilities | 6.7 |  |
| TOTAL LIABILITIES | $ | 55.0 |  |
| NON-CONTROLLING INTERESTS | $ | 17.8 |  |
| Net purchase consideration | $ | 64.2 |  |

[0001262039-22-000008:notes:114]
The fair values assigned were updated to reflect the retrospective adoption of ASU 2021-08, which resulted in increases to the fair values assigned to goodwill, accrued and other current liabilities and other long-term liabilities as of the acquisition date. Refer to Note 1 for further discussion. The excess of the purchase consideration and the fair value of non-controlling interests over the fair value of net tangible and identified intangible assets acquired was recorded as goodwill, which is not deductible for tax purposes. Goodwill is primarily attributable to the assembled workforce of Alaxala and the anticipated operational synergies.

[0001262039-22-000008:notes:115]
The fair value of the non-controlling interests of $17.8 million was estimated based on the non-controlling interests’ respective share of the fair value of Alaxala.

[0001262039-22-000008:notes:116]
Identified intangible assets acquired and their estimated useful lives (in years) as of August 31, 2021, were as follows (in millions, except years):

[0001262039-22-000008:notes:117]
|  | Fair Value |  | Estimated Useful Life (in years) |
| Developed technology | $ | 26.6 |  |  | 4 |
| Customer relationships | 10.0 |  |  | 10 |
| Trade name | 6.4 |  |  | 10 |
| Backlog | 5.0 |  |  | 1 |
| Total identified intangible assets: | $ | 48.0 |  |  |  |

[0001262039-22-000008:notes:118]
Developed technology relates to Alaxala’s network equipment. We valued the developed technology using the relief-from-royalty method under the income approach. This method reflects the present value of the projected cost savings that are expected to be realized by the owner of the need to pay a royalty to another party in exchange for the use of the asset. The economic useful life was determined based on the technology cycle related to each developed technology, as well as the cash flows over the forecast period.

[0001262039-22-000008:notes:119]
Customer relationships represent the fair value of future projected revenue that will be derived from sales to existing customers of Alaxala. Customer contracts and related relationships were valued using the multi-period excess earnings method. This method reflects the present value of the projected cash flows that are expected to be generated by the customer contracts and relationships less charges representing the contribution of other assets to those cash flows. The economic useful life was determined based on historical customer turnover rates.

[0001262039-22-000008:notes:120]
Trade name relates to the “Alaxala” trade name. The fair value was determined by applying the relief-from-royalty method under the income approach. This method is based on the application of a royalty rate to forecasted revenue under the trade name. The economic useful life was determined based on the expected life of the trade name and the cash flows anticipated over the forecast period.

[0001262039-22-000008:notes:121]
Customer backlog relates to the unfulfilled customer contract orders. Backlog was valued using the multi-period excess earnings method. This method reflects the present value of the projected cash flows that are expected to be generated by the execution of the unfulfilled customer contract orders less charges representing the contribution of other assets to those cash flows. The economic useful life was determined based on the anticipated contract orders’ execution timeframe.

[0001262039-22-000008:notes:122]
Our estimates and assumptions are subject to change within the measurement period, which is up to 12 months after the acquisition date. The allocation of the purchase price for this acquisition has been prepared on a preliminary basis and changes to the allocation of certain assets and liabilities may occur as additional information becomes available. The primary areas of the purchase price that are not yet finalized are related to income taxes and the valuation of acquired assets and assumed liabilities.

[0001262039-22-000008:notes:123]
In connection with our acquisition of Alaxala, we assumed certain current debt liabilities of $20.2 million as of August 31, 2021. We concluded that the fair value of this debt approximated its book value as of the acquisition date. We repaid this debt in full in September and October 2021. During the post-acquisition period from September 1, 2021 through the repayment dates, interest expense related to Alaxala debt was not material.

[0001262039-22-000008:notes:124]
The operating results of the acquired company were included in our consolidated financial statements from the date of acquisition which was August 31, 2021. For the period from September 1, 2021 through December 31, 2021, Alaxala contributed revenue of $44.4 million. Income before income taxes for the period from September 1, 2021 through December 31, 2021 was not material. Acquisition-related costs for this acquisition were not material and were recorded as general and administrative expense.

[0001262039-22-000008:notes:125]
The following unaudited pro forma financial information presents the combined results of operations of Fortinet, Inc. and Alaxala, as if Alaxala had been acquired as of the beginning of business on January 1, 2020. The unaudited pro forma financial information is presented for informational purposes only and is not necessarily indicative of our consolidated results of operations of the combined business that would have been achieved if the acquisition had taken place at the beginning of business on January 1, 2020, or of the results of our future operations of the combined business. The following unaudited pro forma financial information for all periods presented includes purchase accounting adjustments for amortization of acquired intangible assets, depreciation of acquired property and equipment, the purchase accounting effect on inventory acquired and related tax effects (in millions):

[0001262039-22-000008:notes:126]
|  | Year Ended December 31, |
|  | 2021 |  | 2020 |  |  |
| Pro forma revenue | $ | 3,424.3 |  |  | $ | 2,714.7 |  |  |  |
| Pro forma net income attributable to Fortinet, Inc. | $ | 608.2 |  |  | $ | 480.0 |  |  |  |

[0001262039-22-000008:notes:127]
ShieldX Networks, Inc.

[0001262039-22-000008:notes:128]
On March 10, 2021, we closed an acquisition of certain assets and liabilities of ShieldX Networks Inc. (“ShieldX”), a provider of a security platform focusing on protecting multi-cloud data centers from the risk of lateral movement that can lead to attacks such as ransomware, data loss and service disruption, for $10.8 million in cash. This acquisition was accounted for as a business combination using the acquisition method of accounting. Of the purchase price, $6.2 million was allocated to goodwill, $4.1 million was allocated to developed technology intangible asset and $0.5 million was allocated to other net assets acquired. Goodwill recorded in connection with this acquisition represents the value we expect to be created through expansion into markets within our existing business and potential cost savings and synergies. All acquired goodwill is expected to be deductible for tax purposes. Acquisition-related costs related to this acquisition were not material and were recorded as general and administrative expense.

[0001262039-22-000008:notes:129]
2020 Acquisitions

[0001262039-22-000008:notes:130]
Panopta Holdings LLC

[0001262039-22-000008:notes:131]
On December 9, 2020, we acquired all outstanding shares of Panopta Holdings LLC (“Panopta”), a privately held SaaS platform innovator that provides visibility, automated management and alerting, and remediation for enterprise networks and infrastructure. The purchase price for Panopta was $31.9 million in cash, of which $24.8 million was allocated to goodwill and $9.0 million was allocated to identifiable intangible assets, the majority of which was developed technology, offset by $1.9 million of net liabilities assumed, which predominantly included cash and accounts payable. $15.8 million of goodwill is expected to be deductible for tax purposes.

[0001262039-22-000008:notes:132]
OPAQ Networks, Inc.

[0001262039-22-000008:notes:133]
On July 20, 2020, we acquired all outstanding shares of OPAQ Networks, Inc. (“OPAQ”), a privately held Secure Access Service Edge cloud provider. The purchase price for OPAQ was $8.0 million in cash, of which $1.0 million was allocated to goodwill, $4.7 million was allocated to identifiable intangible assets, the majority of which was developed technology, and $2.3 million was allocated to other net assets acquired, which predominantly included cash, deferred tax assets, operating lease right-of-use assets and lease liabilities, accounts payable, accrued liabilities and assumed debt. The purchase price included a $1.3 million indemnity fund held in escrow for 12 months after the transaction closing date, of which $0.4 million was received by Fortinet and the remainder was released to OPAQ shareholders during the year ended December 31, 2021.

[0001262039-22-000008:notes:134]
2019 Acquisitions

[0001262039-22-000008:notes:135]
CyberSponse, Inc.

[0001262039-22-000008:notes:136]
On December 12, 2019, we acquired all outstanding shares of CyberSponse, Inc. (“CyberSponse”), a provider of security orchestration, automation and response products and services. The purchase price for CyberSponse was $26.1 million, of which $18.6 million was allocated to goodwill that was non-deductible for tax purposes and $9.1 million was allocated to identifiable intangible assets, the majority of which was developed technology, offset by $1.6 million of net liabilities assumed. We incurred a $4.1 million liability in connection with this business combination, the majority of which related to the settlement of CyberSponse’s equity awards in cash, which we included in accrued liabilities in our consolidated balance sheet as of December 31, 2019, and paid during the year ended December 31, 2020. The purchase price included $3.0 million of this liability and the remaining $1.1 million was recognized as compensation cost in the consolidated statements of income for the year ended December 31, 2019. The purchase price also included $3.8 million held in indemnity escrow, of which $2.8 million was held for 12 months and released to CyberSponse shareholders during the year ended December 31, 2020, and the remaining $1.0 million will be held for 36 months after the transaction closing date.

[0001262039-22-000008:notes:137]
enSilo Limited

[0001262039-22-000008:notes:138]
On October 28, 2019, we acquired all outstanding shares of enSilo Limited (“enSilo”), a provider of endpoint detection and response products and services. The purchase price for enSilo was $15.8 million, of which $10.4 million was allocated to goodwill, $10.8 million was allocated to identifiable intangible assets, the majority of which was developed technology, offset by $5.4 million of net liabilities assumed. The purchase price included $2.0 million held in indemnity escrow for 12 months after the transaction closing date, of which $1.7 million was received by Fortinet and the remainder was released to enSilo shareholders during the year ended December 31, 2020.

[0001262039-22-000008:notes:139]
Additional Acquisition-Related Information

[0001262039-22-000008:notes:140]
The operating results of the acquired companies are included in our consolidated statements of income from the respective dates of acquisition. Acquisition-related costs related to each acquisition were not material. Pro forma information has not been presented, except for Alaxala as disclosed above, as the impact of these acquisitions, individually and in the aggregate, in each year were not material to our consolidated financial statements.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001262039-22-000008:notes:141]
GOODWILL AND OTHER INTANGIBLE ASSETS—Net
Goodwill

[0001262039-22-000008:notes:142]
The following table presents the changes in the carrying amount of goodwill (in millions):

[0001262039-22-000008:notes:143]
|  | Amount |
| Balance—December 31, 2020 | $ | 93.0 |  |
| Additions due to business combinations | 30.2 |  |
| Adjustment due to adoption of ASU 2021-08 | 3.0 |  |
| Foreign currency translation adjustments | (1.1) |  |
| Balance—December 31, 2021 | $ | 125.1 |  |

[0001262039-22-000008:notes:144]
There were no impairments to goodwill during 2021, 2020 and 2019, or any previous years.

[0001262039-22-000008:notes:145]
Other Intangible Assets—Net

[0001262039-22-000008:notes:146]
The following tables present other intangible assets—net (in millions, except years):

[0001262039-22-000008:notes:147]
|  | December 31, 2021 |
|  | Weighted-Average Useful Life (in Years) |  | Gross |  | Accumulated Amortization |  | Net |
| Other intangible assets—net: |  |  |  |  |  |  |  |
| Finite-lived intangible assets: |  |  |  |  |  |  |  |
| Developed technologies | 4.0 |  | $ | 82.2 |  |  | $ | 38.0 |  |  | $ | 44.2 |  |
| Customer relationships | 6.0 |  | 22.2 |  |  | 11.9 |  |  | 10.3 |  |
| Trade name | 10.0 |  | 6.1 |  |  | 0.2 |  |  | 5.9 |  |
| Backlog | 1.0 |  | 4.8 |  |  | 1.6 |  |  | 3.2 |  |
| Total other intangible assets—net |  |  | $ | 115.3 |  |  | $ | 51.7 |  |  | $ | 63.6 |  |

[0001262039-22-000008:notes:148]
|  | December 31, 2020 |
|  | Weighted-Average Useful Life (in Years) |  | Gross |  | Accumulated Amortization |  | Net |
| Other intangible assets—net: |  |  |  |  |  |  |  |
| Finite-lived intangible assets: |  |  |  |  |  |  |  |
| Developed technologies | 4.0 |  | $ | 59.3 |  |  | $ | 32.3 |  |  | $ | 27.0 |  |
| Customer relationships | 4.0 |  | 24.8 |  |  | 20.2 |  |  | 4.6 |  |
| Total other intangible assets—net |  |  | $ | 84.1 |  |  | $ | 52.5 |  |  | $ | 31.6 |  |

[0001262039-22-000008:notes:149]
Amortization expense of finite-lived intangible assets was $18.5 million, $13.3 million and $10.9 million in 2021, 2020, and 2019, respectively. The following table summarizes estimated future amortization expense of finite-lived intangible assets (in millions):

[0001262039-22-000008:notes:150]
| Year Ending December 31, | Amount |
| 2022 | $ | 22.7 |  |
| 2023 | 16.2 |  |
| 2024 | 11.4 |  |
| 2025 | 6.1 |  |
| Thereafter | 7.2 |  |
| Total | $ | 63.6 |  |


## us-gaap:EarningsPerShareTextBlock

[0001262039-22-000008:notes:151]
NET INCOME PER SHAREBasic net income per share is computed by dividing net income attributable to Fortinet, Inc., by the weighted-average number of shares of common stock outstanding during the period. Diluted net income per share is computed by dividing net income attributable to Fortinet, Inc. by the weighted-average number of shares of common stock outstanding during the period, plus the dilutive effects of restricted stock units (“RSUs”) and stock options. Dilutive shares of common stock are determined by applying the treasury stock method.
A reconciliation of the numerator and denominator used in the calculation of basic and diluted net income per share attributable to Fortinet, Inc. is as follows (in millions, except per share amounts):

[0001262039-22-000008:notes:152]
|  | Year Ended December 31, |
|  | 2021 |  | 2020 |  | 2019 |
| Numerator: |  |  |  |  |  |
| Net income including non-controlling interests | $ | 606.7 |  |  | $ | 488.5 |  |  | $ | 331.7 |  |
| Net loss attributable to non-controlling interests | (0.1) |  |  | — |  |  | — |  |
| Net income attributable to Fortinet, Inc. | $ | 606.8 |  |  | $ | 488.5 |  |  | $ | 331.7 |  |
| Denominator: |  |  |  |  |  |
| Basic shares: |  |  |  |  |  |
| Weighted-average common stock outstanding-basic | 163.2 |  |  | 164.2 |  |  | 171.0 |  |
| Diluted shares: |  |  |  |  |  |
| Weighted-average common stock outstanding-basic | 163.2 |  |  | 164.2 |  |  | 171.0 |  |
| Effect of potentially dilutive securities: |  |  |  |  |  |
| RSUs | 2.2 |  |  | 2.3 |  |  | 2.8 |  |
| Stock options | 1.7 |  |  | 1.2 |  |  | 1.2 |  |
| Weighted-average shares used to compute diluted net income per share attributable to Fortinet, Inc. | 167.1 |  |  | 167.7 |  |  | 175.0 |  |
| Net income per share attributable to Fortinet, Inc.: |  |  |  |  |  |
| Basic | $ | 3.72 |  |  | $ | 2.98 |  |  | $ | 1.94 |  |
| Diluted | $ | 3.63 |  |  | $ | 2.91 |  |  | $ | 1.90 |  |

[0001262039-22-000008:notes:153]
The following weighted-average shares of common stock were excluded from the computation of diluted net income per share attributable to Fortinet, Inc. for the periods presented, as their effect would have been antidilutive (in millions):

[0001262039-22-000008:notes:154]
|  | Year Ended December 31, |
|  | 2021 |  | 2020 |  | 2019 |
| RSUs | 0.1 |  |  | 0.3 |  |  | 0.3 |  |
| Stock options | 0.2 |  |  | 0.5 |  |  | 0.6 |  |
| Total | 0.3 |  |  | 0.8 |  |  | 0.9 |  |


## us-gaap:LesseeFinanceLeasesTextBlock

[0001262039-22-000008:notes:155]
LEASES
We have operating leases for offices, research and development facilities and data centers. Our leases have remaining terms that range from less than one year to approximately six years, some of which include one or more options to renew, with renewal terms of up to six years. Unless and until we are reasonably certain we will exercise these renewal options, we do not include renewal options in our lease terms for calculating our lease liability, as the renewal options allow us to maintain operational flexibility. Our finance leases were not material to our consolidated financial statements.

[0001262039-22-000008:notes:156]
The components of lease expense were as follows (in millions):

[0001262039-22-000008:notes:157]
|  | Year Ended December 31, |
|  | 2021 |  | 2020 |  | 2019 |
| Operating lease expense | $ | 26.5 |  |  | $ | 18.5 |  |  | $ | 15.3 |  |
| Variable lease expense (1) | 3.1 |  |  | 2.3 |  |  | 2.6 |  |
| Short-term lease expense | 3.7 |  |  | 3.8 |  |  | 3.2 |  |
| Total lease expense | $ | 33.3 |  |  | $ | 24.6 |  |  | $ | 21.1 |  |
| (1) Variable lease expense for the year ended December 31, 2021, 2020 and 2019 predominantly included common area maintenance charges and parking expense. |

[0001262039-22-000008:notes:158]
Supplemental balance sheet information related to our operating leases was as follows (in millions, except lease term and discount rate):

[0001262039-22-000008:notes:159]
|  | Classification |  | December 31,2021 |  | December 31,2020 |
| Operating lease ROU assets – non-current | Other assets |  | $ | 65.1 |  |  | $ | 49.3 |  |
| Operating lease liabilities – current | Accrued liabilities |  | $ | 26.3 |  |  | $ | 19.1 |  |
| Operating lease liabilities – non-current | Other liabilities |  | 40.5 |  |  | 34.0 |  |
| Total operating lease liabilities |  |  | $ | 66.8 |  |  | $ | 53.1 |  |
| Weighted average remaining lease term in years – operating leases |  |  | 3.0 |  | 3.5 |
| Weighted average discount rate – operating leases |  |  | 2.1 | % |  | 3.2 | % |

[0001262039-22-000008:notes:160]
Supplemental cash flow information related to leases was as follows (in millions):

[0001262039-22-000008:notes:161]
|  | Year Ended December 31, |
|  | 2021 |  | 2020 |  | 2019 |
| Cash paid for amounts included in the measurement of lease liabilities |  |  |  |  |  |
| Operating cash flows used for operating leases | $ | 25.8 |  |  | $ | 18.9 |  |  | $ | 16.2 |  |

[0001262039-22-000008:notes:162]
Maturities of operating lease liabilities as of December 31, 2021 were as follows (in millions):

[0001262039-22-000008:notes:163]
| Year Ending December 31, | Amount |
| 2022 | $ | 27.3 |  |
| 2023 | 20.5 |  |
| 2024 | 14.0 |  |
| 2025 | 5.1 |  |
| 2026 | 1.6 |  |
| Thereafter | 0.4 |  |
| Total lease payments | $ | 68.9 |  |
| Less imputed interest | (2.1) |  |
| Total | $ | 66.8 |  |

[0001262039-22-000008:notes:164]
As of December 31, 2021, we had additional minimum lease payments of $11.4 million relating to operating leases that had been signed but had not yet commenced. These leases will commence during 2022 and will have lease terms of approximately one to six years.


## us-gaap:DebtDisclosureTextBlock

[0001262039-22-000008:notes:165]
DEBT
2026 and 2031 Senior Notes

[0001262039-22-000008:notes:166]
On March 5, 2021, we issued $1.0 billion aggregate principal amount of senior notes (collectively, the “Senior Notes”), consisting of $500.0 million aggregate principal amount of 1.0% notes due March 15, 2026 (the “2026 Senior Notes”) and $500.0 million aggregate principal amount of 2.2% notes due March 15, 2031 (the “2031 Senior Notes”), in an underwritten registered public offering. The Senior Notes are senior unsecured obligations and rank equally with each other in right of payment and with our other outstanding obligations. We may redeem the Senior Notes at any time in whole or in part for cash, at specified redemption prices that include accrued and unpaid interest, if any, and a make-whole premium. However, no make-whole premium will be paid for redemptions of the 2026 Senior Notes on or after February 15, 2026, or the 2031 Senior Notes on or after December 15, 2030. Interest on the Senior Notes is payable on March 15 and September 15 of each year, beginning on September 15, 2021. As of December 31, 2021, the Senior Notes were recorded as long-term debt, net of discount and issuance costs, which are amortized to interest expense over the respective contractual terms of these notes using the effective interest method.

[0001262039-22-000008:notes:167]
The total outstanding debt is summarized below (in millions, except percentages):

[0001262039-22-000008:notes:168]
|  | Maturity |  | Coupon Rate |  | Effective Interest Rate |  | December 31,2021 |
| Debt |  |  |  |  |  |  |  |
| 2026 Senior Notes | March 2026 |  | 1.0 | % |  | 1.3 | % |  | $ | 500.0 |  |
| 2031 Senior Notes | March 2031 |  | 2.2 | % |  | 2.3 | % |  | 500.0 |  |
| Total debt |  |  |  |  |  |  | 1,000.0 |  |
| Less: Unamortized discount and debt issuance costs |  |  |  |  |  |  | 11.6 |  |
| Total long-term debt |  |  |  |  |  |  | $ | 988.4 |  |

[0001262039-22-000008:notes:169]
As of December 31, 2021 we accrued interest payable of $4.7 million, and there are no financial covenants with which we must comply. In 2021, we recorded $14.7 million of total interest expense in relation to these Senior Notes and repaid $8.4 million of interest in cash. No interest costs were capitalized in 2021, as the costs that qualified for capitalization were not material.

[0001262039-22-000008:notes:170]
The total estimated fair value of the outstanding Senior Notes was approximately $980.5 million, including accrued and unpaid interest, as of December 31, 2021. The fair value was determined based on observable market prices of identical instruments in less active markets. The estimated fair values are based on Level 2 inputs.


## ftnt:MutualCovenantNottoSueAgreementDisclosureTextBlock

[0001262039-22-000008:notes:171]
MUTUAL COVENANT-NOT-TO-SUE AND RELEASE AGREEMENT
In January 2020, we entered into an agreement with a competitor in the network security industry whereby, in February 2020, the competitor party paid us a lump sum of $50.0 million for a seven-year mutual covenant-not-to-sue for patent claims. Pursuant to this agreement, at the end of this first seven-year period, either party may extend the agreement for an additional seven-year mutual covenant-not-to-sue in return for this competitor paying us an additional $50.0 million. This agreement arose after expiration of previous agreements between the parties whereby the competitor had paid us sums for a limited term license to certain of our intellectual property (“IP”) and a limited term mutual covenant-not-to-sue.

[0001262039-22-000008:notes:172]
We concluded that the agreement was a 14-year contract with a total transaction price of $100.0 million, and that it contained two material distinct performance obligations: (1) the right to use our existing patents, and (2) the right to use any patents that we develop over the term of the contract. We allocated $36.0 million to the functional patents, which was recognized upon commencement of the contract; the remaining $64.0 million, representing the right to utilize future patents, will be recognized over the contract term. We further concluded that our existing patents represent functional IP that should be recognized upon granting our competitor access. We also concluded that the right to receive additional functional IP that we will develop in the future represents a stand ready obligation. Therefore, the transaction price allocated to this obligation is recognized ratably over the 14-year contract term. We estimated the stand-alone selling price of each distinct performance obligation and allocated the $100.0 million transaction price.

[0001262039-22-000008:notes:173]
During the year ended December 31, 2021 and 2020, we recorded $4.6 million and $40.2 million gain on IP matter in our consolidated statements of income, respectively. We had $5.2 million and $9.8 million in accrued liabilities and other liabilities in our consolidated balance sheets as of December 31, 2021 and 2020, respectively.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001262039-22-000008:notes:174]
COMMITMENTS AND CONTINGENCIES
The following table summarizes our inventory purchase commitments as of December 31, 2021 (in millions):

[0001262039-22-000008:notes:175]
|  | Total |  | 2022 |  | Thereafter |
| Inventory purchase commitments | $ | 1,140.5 |  |  | $ | 1,075.0 |  |  | $ | 65.5 |  |

[0001262039-22-000008:notes:176]
Inventory Purchase Commitments—Our independent contract manufacturers procure certain components and build our products based on our forecasts. These forecasts are based on estimates of future demand for our products, which are in turn based on historical trends and an analysis from our sales and marketing organizations, adjusted for supply chain matters and other market conditions. In order to attempt to control manufacturing lead times, plan for adequate component supply and incentivize suppliers to deliver, we may issue purchase orders to some of our independent contract manufacturers which are non-cancelable. As of December 31, 2021 and 2020, we had $1.14 billion and $259.4 million, respectively, of open purchase orders with our independent contract manufacturers that are non-cancelable.

[0001262039-22-000008:notes:177]
Other Contractual Commitments and Open Purchase Orders—In addition to commitments with contract manufacturers and certain component suppliers, we have open purchase orders and contractual obligations in the ordinary course of business for which we have not received goods or services. A significant portion of our reported purchase commitments consist of firm and non-cancelable commitments.  In certain instances, contractual commitments allow us the option to cancel, reschedule, and adjust our requirements based on our business needs prior to firm orders being placed. As of December 31, 2021 and 2020, we had $126.7 million and $28.9 million, respectively, in other contractual commitments having a remaining term in excess of one year that are non-cancelable.

[0001262039-22-000008:notes:178]
Litigation—We are involved in disputes, litigation, and other legal actions. For lawsuits where we are the defendant, we are in the process of defending these litigation matters, and while there can be no assurances and the outcome of certain of these matters is currently not determinable and not predictable, we currently are unaware of any existing claims or proceedings that we believe are likely to have a material adverse effect on our financial position. There are many uncertainties associated with any litigation and these actions or other third-party claims against us may cause us to incur costly litigation fees, costs and substantial settlement charges, and possibly subject us to damages and other penalties. In addition, the resolution of any IP litigation may require us to make royalty payments, which could adversely affect our gross margins in future periods. If any of those events were to occur, our business, financial condition, results of operations, and cash flows could be adversely affected. Litigation is unpredictable and the actual liability in any such matters may be materially different from our current estimates, which could result in the need to adjust any accrued liability and record additional expenses. We accrue for contingencies when we believe that a loss is probable and that we can reasonably estimate the amount of any such loss. These accruals are generally

[0001262039-22-000008:notes:179]
based on a range of possible outcomes that require significant management judgement. If no amount within a range is a better estimate than any other, the Company accrues the minimum amount.

[0001262039-22-000008:notes:180]
In December 2021, we entered into an agreement that provided for settlement and dismissal of an existing patent infringement lawsuit and a mutual covenant-not-to-sue for a defined duration of time. We have settled and paid $10.0 million in cash, of which $5.6 million related to the dismissal of lawsuit and was expensed as a general and administrative expense, and $4.4 million was deferred and will be expensed over time as royalty cost of revenue. Litigation loss contingency accruals associated with other outstanding cases were not material as of December 31, 2021 and 2020.

[0001262039-22-000008:notes:181]
Indemnification and Other Matters—Under the indemnification provisions of our standard sales contracts, we agree to defend our customers against third-party claims asserting various allegations such as product defects and infringement of certain IP rights, which may include patents, copyrights, trademarks or trade secrets, and to pay judgments entered on such claims. In some contracts, our exposure under these indemnification provisions is limited by the terms of the contracts to certain defined limits, such as the total amount paid by our customer under the agreement. However, certain agreements include covenants, penalties and indemnification provisions including and beyond indemnification for third-party claims of IP infringement that could potentially expose us to losses in excess of the amount received under the agreement, and in some instances to potential liability that is not contractually limited. Although from time to time there are indemnification claims asserted against us and currently there are pending indemnification claims, to date there have been no material awards under such indemnification provisions.

[0001262039-22-000008:notes:182]
Similar to other security companies and companies in other industries, we have in the past experienced, and we may in the future experience, cybersecurity threats, malicious activity directed against our information technology infrastructure or unauthorized attempts to gain access to our and our customers’ sensitive information and systems. We currently are unaware of any existing claims or proceedings related to these types of matters, including any that we believe are likely to have a material adverse effect on our financial position.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001262039-22-000008:notes:183]
EQUITY
Stock-Based Compensation Plans

[0001262039-22-000008:notes:184]
We have one primary stock incentive plan, the 2009 Equity Incentive Plan, under which we have granted RSUs and stock options. We also previously had an ESPP for eligible employees, which was terminated in February 2019.

[0001262039-22-000008:notes:185]
2009 Equity Incentive Plan—Our board of directors approved the 2009 Equity Incentive Plan in 2009. On June 21, 2019, our stockholders approved the Amended and Restated Fortinet, Inc. 2009 Equity Incentive Plan (the “2009 Plan”). Among other things, the 2009 Plan provided for a net decrease in the number of shares of common stock that were authorized and available for issuance pursuant to future awards granted on or following the effective date of the 2009 Plan. On June 28, 2019, we deregistered from various registration statements on Form S-8 an aggregate of 46.2 million shares of common stock that were originally registered for issuance under the 2009 Plan.

[0001262039-22-000008:notes:186]
The maximum aggregate number of shares that may be issued under the 2009 Plan is 47,873,531 shares; provided, however, that only 13,500,000 shares may be issued or transferred pursuant to new awards granted on or following the effective date of the 2009 Plan. We may grant awards to employees, directors and other service providers. In the case of an incentive stock option granted to an employee who, at the time of the grant, owns stock representing more than 10% of the voting power of all classes of stock, the exercise price shall be no less than 110% of the fair market value per share on the date of grant and expire no more than five years from the date of grant, and options granted to any other employee, the per share exercise price shall be no less than 100% of the closing stock price on the date of grant. In the case of a non-statutory stock option and options granted to other service providers, the per share exercise price shall be no less than 100% of the fair market value per share on the date of grant. Options granted to individuals owning less than 10% of the total combined voting power of all classes of stock generally have a contractual term of no more than ten years and options generally vest over four years.

[0001262039-22-000008:notes:187]
As of December 31, 2021, there were a total of 11.8 million shares of common stock available for grant under the 2009 Plan.

[0001262039-22-000008:notes:188]
2011 Employee Stock Purchase Plan—In June 2011, our stockholders approved the ESPP. The ESPP permitted eligible employees to purchase common stock through regular, systematic payroll deductions, up to a maximum of 15% of

[0001262039-22-000008:notes:189]
employees’ compensation for each purchase period at purchase prices equal to 85% of the lesser of the fair market value of our common stock at the first trading date of the applicable offering period or the purchase date, subject to purchase limits of 4,000 shares for each purchase period or $25,000 worth of stock for each calendar year. Our board of directors voluntarily determined to terminate the ESPP, effective February 2019 at the completion of the prior offering period.

[0001262039-22-000008:notes:190]
Restricted Stock Units

[0001262039-22-000008:notes:191]
The following table summarizes the activity and related information for RSUs for the periods presented below (in millions, except per share amounts):

[0001262039-22-000008:notes:192]
|  | Restricted Stock Units Outstanding |
|  | Number of Shares |  | Weighted-Average Grant Date Fair Value per Share |
| Balance—December 31, 2018 | 7.8 |  |  | $ | 46.07 |  |
| Granted | 2.7 |  |  | 87.09 |  |
| Forfeited | (0.7) |  |  | 55.13 |  |
| Vested | (3.7) |  |  | 43.31 |  |
| Balance—December 31, 2019 | 6.1 |  |  | 64.56 |  |
| Granted | 1.9 |  |  | 121.16 |  |
| Forfeited | (0.4) |  |  | 79.83 |  |
| Vested | (2.9) |  |  | 58.20 |  |
| Balance—December 31, 2020 | 4.7 |  |  | 90.46 |  |
| Granted | 1.2 |  |  | 202.63 |  |
| Forfeited | (0.4) |  |  | 114.96 |  |
| Vested | (2.3) |  |  | 81.52 |  |
| Balance—December 31, 2021 | 3.2 |  |  | $ | 136.08 |  |

[0001262039-22-000008:notes:193]
Stock compensation expense is recognized on a straight-line basis over the vesting period of each RSU. As of December 31, 2021, total compensation expense related to unvested RSUs granted to employees and non-employees under the 2009 Plan, but not yet recognized, was $367.8 million, with a weighted-average remaining vesting period of 2.6 years.

[0001262039-22-000008:notes:194]
RSUs settle into shares of common stock upon vesting. Upon the vesting of the RSUs, we net-settle the RSUs and withhold a portion of the shares to satisfy employee withholding tax requirements. The payment of the withheld taxes to the tax authorities is reflected as a financing activity within the consolidated statements of cash flows.

[0001262039-22-000008:notes:195]
The following summarizes the number and value of the shares withheld for employee taxes (in millions):

[0001262039-22-000008:notes:196]
|  | Year Ended December 31, |
|  | 2021 |  | 2020 |  | 2019 |
| Shares withheld for taxes | 0.8 |  |  | 0.9 |  |  | 1.1 |  |
| Amount withheld for taxes | $ | 167.9 |  |  | $ | 108.2 |  |  | $ | 96.0 |  |

[0001262039-22-000008:notes:197]
Employee Stock Options

[0001262039-22-000008:notes:198]
In determining the fair value of our employee stock options, we use the Black-Scholes model, which employs the following assumptions.

[0001262039-22-000008:notes:199]
Expected Term—The expected term represents the period that our stock-based awards are expected to be outstanding. We believe that we have sufficient historical experience for determining the expected term of the stock option award, and therefore, we calculated our expected term based on historical experience instead of using the simplified method.

[0001262039-22-000008:notes:200]
Expected Volatility—The expected volatility of our common stock is based on our weighted-average implied and historical volatility.

[0001262039-22-000008:notes:201]
Fair Value of Common Stock—The fair value of our common stock is the closing sales price of the common stock effective on the date of grant.

[0001262039-22-000008:notes:202]
Risk-Free Interest Rate—We base the risk-free interest rate on the implied yield available on U.S. Treasury zero-coupon issues with an equivalent remaining term.

[0001262039-22-000008:notes:203]
Expected Dividend—The expected dividend weighted-average assumption is zero.

[0001262039-22-000008:notes:204]
The following table summarizes the weighted-average assumptions relating to our employee stock options:

[0001262039-22-000008:notes:205]
|  | Year Ended December 31, |
|  | 2021 |  | 2020 |  | 2019 |
| Expected term in years | 4.4 |  | 4.4 |  | 4.4 |
| Volatility | 39.1 | % |  | 34.8 | % |  | 34.3 | % |
| Risk-free interest rate | 0.5 | % |  | 1.1 | % |  | 2.4 | % |
| Dividend rate | — | % |  | — | % |  | — | % |

[0001262039-22-000008:notes:206]
The following table summarizes the stock option activity and related information for the periods presented below (in millions, except exercise prices and contractual life):

[0001262039-22-000008:notes:207]
|  | Options Outstanding |
|  | Numberof Shares |  | Weighted-AverageExercisePrice |  | Weighted-AverageRemainingContractualLife (Years) |  | AggregateIntrinsicValue |
| Balance—December 31, 2018 | 3.0 |  |  | $ | 35.53 |  |  | 4.0 |  | $ | 105.6 |  |
| Granted | 0.7 |  |  | 85.02 |  |  |  |  |  |
| Forfeited | (0.1) |  |  | 62.93 |  |  |  |  |  |
| Exercised | (0.9) |  |  | 30.21 |  |  |  |  |  |
| Balance—December 31, 2019 | 2.7 |  |  | 50.37 |  |  | 4.5 |  | 150.3 |  |
| Granted | 0.6 |  |  | 118.80 |  |  |  |  |  |
| Forfeited | (0.1) |  |  | 91.52 |  |  |  |  |  |
| Exercised | (0.5) |  |  | 41.49 |  |  |  |  |  |
| Balance—December 31, 2020 | 2.7 |  |  | 67.53 |  |  | 4.2 |  | 220.4 |  |
| Granted | 0.6 |  |  | 186.28 |  |  |  |  |  |
| Forfeited | (0.1) |  |  | 122.65 |  |  |  |  |  |
| Exercised | (0.5) |  |  | 55.07 |  |  |  |  |  |
| Balance—December 31, 2021 | 2.7 |  |  | $ | 92.87 |  |  |  |  |  |
| Options vested and expected to vest—December 31, 2021 | 2.7 |  |  | $ | 92.87 |  |  | 4.0 |  | $ | 729.9 |  |
| Options exercisable—December 31, 2021 | 1.7 |  |  | $ | 58.53 |  |  | 2.9 |  | $ | 496.7 |  |

[0001262039-22-000008:notes:208]
The aggregate intrinsic value represents the difference between the exercise price of stock options and the quoted market price of our common stock on December 31, 2021 for all in-the-money stock options. Stock compensation expense is recognized on a straight-line basis over the vesting period of each stock option. As of December 31, 2021, total compensation expense related to unvested stock options granted to employees but not yet recognized was $43.6 million, with a weighted-average remaining vesting period of 2.7 years.

[0001262039-22-000008:notes:209]
Additional information related to our stock options is summarized below (in millions, except per share amounts):

[0001262039-22-000008:notes:210]
|  | Year Ended December 31, |
|  | 2021 |  | 2020 |  | 2019 |
| Weighted-average fair value per share granted | $ | 60.76 |  |  | $ | 35.79 |  |  | $ | 27.19 |  |
| Intrinsic value of options exercised | $ | 83.5 |  |  | $ | 43.5 |  |  | $ | 54.6 |  |
| Fair value of options vested | $ | 17.2 |  |  | $ | 13.5 |  |  | $ | 10.1 |  |

[0001262039-22-000008:notes:211]
The following table summarizes information about outstanding and exercisable stock options as of December 31, 2021, as follows (in millions, except exercise prices and contractual life):

[0001262039-22-000008:notes:212]
|  |  | Options Outstanding |  | Options Exercisable |
| Range of Exercise Prices |  | NumberOutstanding |  | Weighted-AverageRemainingContractualLife (Years) |  | Weighted-AverageExercisePrice |  | NumberExercisable |  | Weighted-AverageExercisePrice |
| $23.83-$23.83 |  | 0.3 |  |  | 1.1 |  | $ | 23.83 |  |  | 0.3 |  |  | $ | 23.83 |  |
| $31.39-$39.49 |  | 0.3 |  |  | 1.9 |  | 36.43 |  |  | 0.4 |  |  | 36.43 |  |
| $48.83-$72.75 |  | 0.5 |  |  | 3.0 |  | 50.10 |  |  | 0.5 |  |  | 49.91 |  |
| $76.22-$343.51 |  | 1.6 |  |  | 5.2 |  | 131.05 |  |  | 0.5 |  |  | 98.79 |  |
|  |  | 2.7 |  |  |  |  |  |  | 1.7 |  |  |  |

[0001262039-22-000008:notes:213]
Employee Stock Purchase Plan

[0001262039-22-000008:notes:214]
There were no grants under the ESPP during the year ended December 31, 2021, 2020 and 2019, respectively.

[0001262039-22-000008:notes:215]
Additional information related to the ESPP is provided below (in millions, except per share amounts):

[0001262039-22-000008:notes:216]
|  |  |  | December 31,2019 |
| Shares issued under the ESPP |  |  | 0.3 |  |
| Weighted-average price per share issued |  |  | $ | 64.79 |  |

[0001262039-22-000008:notes:217]
Shares Reserved for Future Issuances

[0001262039-22-000008:notes:218]
The following table presents the common stock reserved for future issuance (in millions):

[0001262039-22-000008:notes:219]
|  | December 31,2021 |
| Reserved for future equity award grants | 11.8 |  |
| Outstanding stock options and RSUs | 5.9 |  |
| Total common stock reserved for future issuances | 17.7 |  |

[0001262039-22-000008:notes:220]
Stock-Based Compensation Expense

[0001262039-22-000008:notes:221]
Stock-based compensation expense, including stock-based compensation expense related to awards classified as liabilities, is included in costs and expenses as follows (in millions):

[0001262039-22-000008:notes:222]
|  | Year Ended December 31, |
|  | 2021 |  | 2020 |  | 2019 |
| Cost of product revenue | $ | 1.7 |  |  | $ | 1.6 |  |  | $ | 1.5 |  |
| Cost of service revenue | 15.7 |  |  | 12.9 |  |  | 11.3 |  |
| Research and development | 56.7 |  |  | 47.6 |  |  | 38.7 |  |
| Sales and marketing | 110.0 |  |  | 108.4 |  |  | 101.7 |  |
| General and administrative | 27.1 |  |  | 23.3 |  |  | 20.9 |  |
| Total stock-based compensation expense | $ | 211.2 |  |  | $ | 193.8 |  |  | $ | 174.1 |  |

[0001262039-22-000008:notes:223]
The following table summarizes stock-based compensation expense, including stock-based compensation expense related to awards classified as liabilities, by award type (in millions):

[0001262039-22-000008:notes:224]
|  | Year Ended December 31, |
|  | 2021 |  | 2020 |  | 2019 |
| RSUs | $ | 191.8 |  |  | $ | 179.7 |  |  | $ | 160.2 |  |
| Stock options | 19.4 |  |  | 14.1 |  |  | 12.6 |  |
| ESPP | — |  |  | — |  |  | 1.3 |  |
| Total stock-based compensation expense | $ | 211.2 |  |  | $ | 193.8 |  |  | $ | 174.1 |  |

[0001262039-22-000008:notes:225]
Total income tax benefit associated with stock-based compensation that is recognized in the consolidated statements of income is as follows (in millions):

[0001262039-22-000008:notes:226]
|  | Year Ended December 31, |
|  | 2021 |  | 2020 |  | 2019 |
| Income tax benefit associated with stock-based compensation | $ | 45.4 |  |  | $ | 42.1 |  |  | $ | 38.3 |  |

[0001262039-22-000008:notes:227]
Share Repurchase Program

[0001262039-22-000008:notes:228]
In January 2016, our board of directors approved the Share Repurchase Program (the “Repurchase Program”), which authorized the repurchase of up to $200.0 million of our outstanding common stock through December 31, 2017. From 2016 through 2020, our board of directors approved increases to our Repurchase Program by various amounts, bringing the aggregated amount authorized to $3.0 billion. In October 2021, our board of directors approved a $1.25 billion increase and extended the term to February 28, 2023, bringing the aggregate amount authorized to be repurchased to $4.25 billion. Under the Repurchase Program, share repurchases may be made by us from time to time in privately negotiated transactions or in open market transactions. The Repurchase Program does not require us to purchase a minimum number of shares, and may be suspended, modified or discontinued at any time without prior notice. In 2021, we repurchased 2.6 million shares of common stock under the Repurchase Program in open market transactions for an aggregate purchase price of $741.8 million. As of December 31, 2021, $1.52 billion remained available for future share repurchases under the Repurchase Program.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001262039-22-000008:notes:229]
INCOME TAXES 
Income before income taxes and loss from equity method investment consisted of the following (in millions):

[0001262039-22-000008:notes:230]
|  | Year Ended December 31, |
|  | 2021 |  | 2020 |  | 2019 |
| Domestic | $ | 567.7 |  |  | $ | 490.6 |  |  | $ | 371.7 |  |
| Foreign | 60.7 |  |  | 51.1 |  |  | 14.3 |  |
| Total income before income taxes and loss from equity method investment | $ | 628.4 |  |  | $ | 541.7 |  |  | $ | 386.0 |  |

[0001262039-22-000008:notes:231]
The provision for (benefit from) income taxes consisted of the following (in millions):

[0001262039-22-000008:notes:232]
|  | Year Ended December 31, |
|  | 2021 |  | 2020 |  | 2019 |
| Current: |  |  |  |  |  |
| Federal | $ | 80.7 |  |  | $ | 38.6 |  |  | $ | 11.0 |  |
| State | 2.5 |  |  | 8.1 |  |  | 0.1 |  |
| Foreign | 23.3 |  |  | 13.6 |  |  | 11.4 |  |
| Total current | $ | 106.5 |  |  | $ | 60.3 |  |  | $ | 22.5 |  |
| Deferred: |  |  |  |  |  |
| Federal | $ | (90.2) |  |  | $ | (8.1) |  |  | $ | 40.6 |  |
| State | (1.1) |  |  | (0.8) |  |  | (6.0) |  |
| Foreign | (1.1) |  |  | 1.8 |  |  | (2.8) |  |
| Total deferred | (92.4) |  |  | (7.1) |  |  | 31.8 |  |
| Provision for income taxes | $ | 14.1 |  |  | $ | 53.2 |  |  | $ | 54.3 |  |

[0001262039-22-000008:notes:233]
The foreign tax provision included the tax impacts from U.S. GAAP to local tax return book to tax differences and return to provision adjustments that create a permanent addback including but not limited to stock compensation, meals and entertainment, and settlement of prior year tax audits with foreign jurisdiction adjustments.

[0001262039-22-000008:notes:234]
The provision for income taxes differs from the amount computed by applying the statutory federal income tax rate as follows (in millions):

[0001262039-22-000008:notes:235]
|  | Year Ended December 31, |
|  | 2021 |  | 2020 |  | 2019 |
| Tax at federal statutory tax rate | $ | 132.0 |  |  | $ | 113.8 |  |  | $ | 81.2 |  |
| Foreign income taxed at different rates | 2.9 |  |  | 16.4 |  |  | 12.3 |  |
| Foreign withholding taxes | 37.4 |  |  | 18.8 |  |  | 16.0 |  |
| Stock-based compensation expense | (74.8) |  |  | (39.6) |  |  | (30.6) |  |
| Foreign tax credit | (53.2) |  |  | (30.1) |  |  | (30.4) |  |
| State taxes—net of federal benefit | (4.6) |  |  | 4.9 |  |  | (11.3) |  |
| Research and development credit | (11.1) |  |  | (7.5) |  |  | (6.8) |  |
| Valuation allowance | 20.0 |  |  | 11.9 |  |  | 22.0 |  |
| Impact of the 2017 Tax Act: |  |  |  |  |  |
| One-time transition tax | 5.8 |  |  | 2.6 |  |  | (2.1) |  |
| Foreign-Derived Intangible Income | (33.6) |  |  | (44.3) |  |  | — |  |
| Other | (6.7) |  |  | 6.3 |  |  | 4.0 |  |
| Total provision for income taxes | $ | 14.1 |  |  | $ | 53.2 |  |  | $ | 54.3 |  |

[0001262039-22-000008:notes:236]
On September 29, 2020, the U.S. Treasury and the IRS released final regulations related to foreign tax credits that were the subject of proposed regulations issued in December 2019 and proposed certain provisions in proposed regulations issued in December 2019. The final and proposed regulations provide administrative guidance for the foreign tax credit regime, which was updated in the 2017 Tax Cuts and Jobs Act (the “2017 Tax Act”). Generally, the provisions that were included in the 2019 proposed regulations apply to taxable years ended on or after December 16, 2019, except as otherwise specified. On December 28, 2021, the U.S. Treasury and the IRS released final regulations addressing various aspects of the foreign tax credit regime. These final regulations did not have a material impact on our consolidated financial statements.

[0001262039-22-000008:notes:237]
The tax effects of temporary differences that give rise to significant portions of the deferred tax assets as of the years ended are presented below (in millions):

[0001262039-22-000008:notes:238]
|  | December 31,2021 |  | December 31,2020 |
| Deferred tax assets: |  |  |  |
| General business credit carryforward | $ | 63.5 |  |  | $ | 48.9 |  |
| Deferred revenue | 276.5 |  |  | 216.4 |  |
| Reserves and accruals | 59.5 |  |  | 41.9 |  |
| Net operating loss carryforward | 22.2 |  |  | 23.4 |  |
| Stock-based compensation expense | 18.3 |  |  | 17.5 |  |
| Depreciation and amortization | 17.0 |  |  | 6.3 |  |
| Capitalized research expenditures | 64.2 |  |  | 16.6 |  |
| Operating lease liabilities | 13.1 |  |  | 11.6 |  |
| Total deferred tax assets | 534.3 |  |  | 382.6 |  |
| Less: Valuation allowance | (75.0) |  |  | (54.9) |  |
| Deferred tax assets, net of valuation allowance | 459.3 |  |  | 327.7 |  |
| Deferred tax liabilities: |  |  |  |
| Deferred contract costs | (97.4) |  |  | (74.0) |  |
| Operating lease ROU assets | (11.9) |  |  | (10.8) |  |
| Acquired intangibles | (15.7) |  |  | (5.7) |  |
| Total deferred tax liabilities | (125.0) |  |  | (90.5) |  |
| Net deferred tax assets | $ | 334.3 |  |  | $ | 237.2 |  |

[0001262039-22-000008:notes:239]
As of December 31, 2021, we had a deferred tax asset of $342.3 million and a deferred tax liability of $7.9 million. In assessing the realizability of deferred tax assets, we considered whether it is more likely than not that some portion or all of our deferred tax assets will be realized. This realization is dependent upon the generation of future taxable income during the periods in which those temporary differences become deductible. We concluded that it is more likely than not that we will be able to realize the benefits of our deferred tax assets in the future except for our California research and development (“R&D”) credits carryforward, certain impairment losses in business investments, certain foreign tax credits from foreign disregarded entities and certain tax attributes from business acquisitions. We believe that it is more likely than not that the deferred tax assets for California R&D credits, impairment losses, foreign tax credits from foreign disregarded entities and acquired foreign tax attributes will not be realized. As of December 31, 2021, we had a valuation allowance of $75.0 million against deferred tax assets for California R&D credits carryforwards (net of the unrecognized tax benefits), impairment losses, certain foreign tax credits and certain acquired tax attributes.

[0001262039-22-000008:notes:240]
As of December 31, 2021, our federal and California net operating loss carryforwards for income tax purposes were $78.4 million and $20.8 million, respectively. All the net operating loss carryforwards were from acquisitions which were limited by Section 382 of the Internal Revenue Code. If not utilized, the federal net operating loss carryforwards will begin to expire in 2022, and California net operating loss carryforwards will begin to expire in 2034.

[0001262039-22-000008:notes:241]
As of December 31, 2021, we had state tax credit carryforwards of $41.0 million. The state credits can be carried forward indefinitely.

[0001262039-22-000008:notes:242]
Under the 2017 Tax Act, starting on January 1, 2018, we are no longer subject to federal income tax on earnings remitted from our foreign subsidiaries. We have analyzed our global working capital and cash requirements and the potential tax liabilities attributable to repatriation, and have determined that we will be repatriating certain unremitted foreign earnings which was previously deemed indefinitely reinvested. For those investments from which we were able to make a reasonable estimate of the tax effects of such repatriation, we have recorded a provisional estimate for withholding and state taxes. For those investments from which we were not able to make a reasonable estimate, we have not recorded any deferred taxes.

[0001262039-22-000008:notes:243]
We operated under a tax incentive agreement in Singapore, which was effective through December 31, 2020. The tax incentive agreement was conditional upon our meeting certain employment and investment thresholds.

[0001262039-22-000008:notes:244]
As of December 31, 2021, we had $73.3 million of unrecognized tax benefits, of which, if recognized, $65.5 million would favorably affect our effective tax rate. Our policy is to include accrued interest and penalties related to uncertain tax benefits in income tax expense. As of December 31, 2021, 2020 and 2019, accrued interest and penalties were $13.3 million, $14.5 million and $14.1 million, respectively.

[0001262039-22-000008:notes:245]
The aggregate changes in the balance of unrecognized tax benefits are as follows (in millions):

[0001262039-22-000008:notes:246]
|  | Year Ended December 31, |
|  | 2021 |  | 2020 |  | 2019 |
| Unrecognized tax benefits, beginning of year | $ | 77.3 |  |  | $ | 67.5 |  |  | $ | 63.5 |  |
| Gross increases for tax positions related to the current year | 7.6 |  |  | 13.1 |  |  | 11.4 |  |
| Gross decreases for tax positions related to the current year | — |  |  | — |  |  | — |  |
| Gross increases for tax positions related to the prior year | 8.7 |  |  | 6.1 |  |  | 3.0 |  |
| Gross decreases for tax positions related to prior year | (0.7) |  |  | (1.3) |  |  | (0.3) |  |
| Gross decreases for tax positions related to prior year audit settlements | — |  |  | (1.4) |  |  | (1.7) |  |
| Gross decreases for tax positions related to expiration of statute of limitations | (19.6) |  |  | (6.7) |  |  | (8.4) |  |
| Unrecognized tax benefits, end of year | $ | 73.3 |  |  | $ | 77.3 |  |  | $ | 67.5 |  |

[0001262039-22-000008:notes:247]
We recorded a net decrease of gross unrecognized tax benefits of approximately $4.0 million during the year ended December 31, 2021. The net decrease was primarily due to the reversal of gross unrecognized tax benefits in connection with the lapse of statutes of limitations.

[0001262039-22-000008:notes:248]
As of December 31, 2021, 2020 and 2019, $79.5 million, $90.3 million and $82.8 million, respectively, of the amounts reflected above were recorded as income tax liabilities—non-current in our consolidated balance sheets.

[0001262039-22-000008:notes:249]
It is reasonably possible that our gross unrecognized tax benefits will decrease by up to $18.5 million in the next 12 months, primarily due to the lapse of the statute of limitations. These adjustments, if recognized, would favorably impact our effective tax rate, and would be recognized as additional tax benefits.

[0001262039-22-000008:notes:250]
We file income tax returns in the U.S. federal jurisdiction and in various U.S. state and foreign jurisdictions. Generally, we are no longer subject to examination by U.S federal income tax authorities for tax years prior to 2015. We are no longer subject to U.S. state and foreign income tax examinations by tax authorities for tax years prior to 2010. We currently have ongoing tax audits in the United Kingdom, Canada, Germany and several other foreign jurisdictions. The focus of these audits is the inter-company profit allocation.


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0001262039-22-000008:notes:251]
DEFINED CONTRIBUTION PLANSOur tax-deferred savings plan under our 401(k) Plan permits participating U.S. employees to contribute a portion of their pre-tax or after-tax earnings. In Canada, we have a Group Registered Retirement Savings Plan Program (the “RRSP”), which permits participants to make tax-deductible contributions. Our board of directors approved 50% matching contributions on employee contributions up to 4% of each employee’s eligible earnings. Our matching contributions to our 401(k) Plan and the RRSP for 2021, 2020 and 2019 were $10.0 million, $8.3 million and $6.6 million, respectively.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001262039-22-000008:notes:252]
SEGMENT INFORMATION
Operating segments are defined as components of an enterprise about which separate financial information is available that is evaluated regularly by the chief operating decision maker in deciding how to allocate resources and in assessing performance. Our chief operating decision maker is our chief executive officer. Our chief executive officer reviews financial information presented on a consolidated basis, accompanied by information about revenue by geographic region for purposes of allocating resources and evaluating financial performance. We have one business activity, and there are no segment managers who are held accountable for operations, operating results and plans for levels or components below the consolidated unit level. Accordingly, we have determined that we have one operating segment, and therefore, one reportable segment.

[0001262039-22-000008:notes:253]
Revenue by geographic region is based on the billing address of our customers. The following tables set forth revenue and property and equipment—net by geographic region (in millions):

[0001262039-22-000008:notes:254]
|  | Year Ended December 31, |
| Revenue | 2021 |  | 2020 |  | 2019 |
| Americas: |  |  |  |  |  |
| United States | $ | 1,006.8 |  |  | $ | 813.3 |  |  | $ | 695.5 |  |
| Other Americas | 352.0 |  |  | 263.9 |  |  | 224.7 |  |
| Total Americas | 1,358.8 |  |  | 1,077.2 |  |  | 920.2 |  |
| Europe, Middle East and Africa (“EMEA”) | 1,275.9 |  |  | 991.9 |  |  | 816.5 |  |
| Asia Pacific (“APAC”) | 707.5 |  |  | 525.3 |  |  | 426.3 |  |
| Total revenue | $ | 3,342.2 |  |  | $ | 2,594.4 |  |  | $ | 2,163.0 |  |

[0001262039-22-000008:notes:255]
| Property and Equipment—net | December 31,2021 |  | December 31,2020 |
| Americas: |  |  |  |
| United States | $ | 472.4 |  |  | $ | 296.3 |  |
| Canada | 170.9 |  |  | 121.3 |  |
| Latin America | 1.6 |  |  | 2.0 |  |
| Total Americas | 644.9 |  |  | 419.6 |  |
| EMEA | 31.0 |  |  | 20.6 |  |
| APAC | 11.7 |  |  | 7.8 |  |
| Total property and equipment—net | $ | 687.6 |  |  | $ | 448.0 |  |


## us-gaap:SubsequentEventsTextBlock

[0001262039-22-000008:notes:256]
SUBSEQUENT EVENT
Real property purchase

[0001262039-22-000008:notes:257]
In February 2022, we purchased real property in Chicago totaling approximately 90,000 square feet for a cash payment of $20.8 million.

[0001262039-22-000008:notes:258]
Share repurchase

[0001262039-22-000008:notes:259]
Subsequent to December 31, 2021 and through the filing of this Annual Report on Form 10-K, we repurchased 1.8 million shares of our common stock, for an aggregate purchase price of $547.6 million at an average price of $310.05 per share, under the Repurchase Program.
