# FTNT 8-K — 0001262039-22-000005 filed 2022-02-03

## item codes, every 8-K on or before 2022-02-25

- 2022-02-03 0001262039-22-000005 — 2.02, 9.01
- 2022-01-26 0001262039-22-000002 — 5.02, 9.01 — amendment, the index does not say of what
- 2021-11-04 0001262039-21-000027 — 2.02, 9.01
- 2021-10-06 0001262039-21-000024 — 5.02, 9.01
- 2021-07-29 0001262039-21-000019 — 2.02, 9.01
- 2021-06-23 0001262039-21-000016 — 5.07
- 2021-04-30 0001104659-21-059008 — 5.03 — amendment, the index does not say of what
- 2021-04-29 0001262039-21-000011 — 2.02, 9.01
- 2021-04-28 0001104659-21-056360 — 5.02, 5.03, 9.01
- 2021-03-05 0001193125-21-071498 — 1.01, 9.01
- 2021-02-25 0001193125-21-057281 — 1.01, 9.01
- 2021-02-04 0001262039-21-000005 — 2.02, 9.01
- 2020-12-08 0001262039-20-000070 — 8.01
- 2020-10-29 0001262039-20-000063 — 2.02, 9.01
- 2020-10-20 0001262039-20-000060 — 5.02 — amendment, the index does not say of what
- 2020-08-26 0001262039-20-000056 — 5.02, 9.01
- 2020-08-06 0001262039-20-000051 — 2.02, 9.01
- 2020-07-21 0001262039-20-000044 — 5.03, 8.01, 9.01
- 2020-06-24 0001262039-20-000038 — 5.07
- 2020-05-06 0001262039-20-000029 — 2.02, 9.01
- 2020-04-23 0001262039-20-000025 — 5.03, 9.01
- 2020-04-23 0001262039-20-000024 — 5.02 — amendment of 0001262039-20-000025
- 2020-02-28 0001262039-20-000015 — 5.02, 9.01
- 2020-02-06 0001262039-20-000004 — 2.02, 9.01
- 2019-12-12 0001262039-19-000038 — 8.01
- 2019-10-31 0001262039-19-000032 — 2.02, 9.01
- 2019-10-28 0001262039-19-000027 — 8.01
- 2019-10-23 0001262039-19-000025 — 5.02, 9.01
- 2019-08-01 0001262039-19-000021 — 2.02, 9.01
- 2019-06-26 0001262039-19-000018 — 5.07
- 2019-05-02 0001262039-19-000010 — 2.02, 9.01
- 2019-02-06 0001262039-19-000002 — 2.02, 9.01
- 2018-11-01 0001262039-18-000037 — 2.02, 9.01
- 2018-10-23 0001262039-18-000035 — 8.01
- 2018-08-01 0001262039-18-000025 — 2.02, 9.01
- 2018-06-28 0001262039-18-000023 — 5.03, 5.07, 9.01
- 2018-06-04 0001262039-18-000021 — 8.01
- 2018-05-03 0001262039-18-000017 — 2.02, 5.02, 9.01
- 2018-02-05 0001262039-18-000004 — 2.02, 5.02, 9.01
- 2017-10-26 0001262039-17-000031 — 2.02, 9.01
- 2017-10-19 0001262039-17-000029 — 5.02 — amendment, the index does not say of what
- 2017-07-26 0001262039-17-000025 — 2.02, 9.01
- 2017-06-27 0001262039-17-000023 — 5.07
- 2017-05-31 0001262039-17-000021 — 5.02 — amendment of 0001262039-17-000019
- 2017-05-30 0001262039-17-000019 — 5.02, 9.01
- 2017-04-27 0001262039-17-000013 — 2.02, 9.01
- 2017-02-02 0001262039-17-000003 — 2.02, 9.01
- 2016-10-27 0001262039-16-000085 — 2.02, 9.01
- 2016-10-11 0001262039-16-000082 — 2.02, 9.01
- 2016-07-28 0001262039-16-000076 — 2.02, 9.01
- 2016-07-22 0001262039-16-000073 — 8.01, 9.01
- 2016-06-20 0001262039-16-000068 — 5.07
- 2016-06-07 0001193125-16-614788 — 8.01
- 2016-04-26 0001262039-16-000061 — 2.02, 9.01
- 2016-01-28 0001262039-16-000051 — 2.02, 9.01
- 2015-10-27 0001262039-15-000045 — 2.02
- 2015-10-22 0001262039-15-000042 — 5.02 — amendment, the index does not say of what
- 2015-10-22 0001262039-15-000041 — 5.02 — amendment, the index does not say of what
- 2015-10-22 0001262039-15-000039 — 2.02, 9.01
- 2015-09-28 0001262039-15-000034 — 5.02, 9.01
- 2015-09-22 0001262039-15-000031 — 9.01 — amendment of 0001193125-15-248065
- 2015-08-28 0001262039-15-000027 — 3.01, 5.02
- 2015-07-23 0001262039-15-000021 — 5.02
- 2015-07-22 0001262039-15-000019 — 2.02, 9.01
- 2015-07-08 0001193125-15-248065 — 2.01, 8.01, 9.01
- 2015-06-22 0001193125-15-229099 — 5.07
- 2015-06-19 0001193125-15-228428 — 5.02, 9.01
- 2015-04-20 0001262039-15-000014 — 2.02, 9.01
- 2015-01-28 0001262039-15-000005 — 2.02, 9.01
- 2014-10-22 0001262039-14-000036 — 2.02, 9.01
- 2014-07-23 0001262039-14-000030 — 2.02, 9.01
- 2014-06-24 0001262039-14-000027 — 5.07
- 2014-04-23 0001262039-14-000021 — 2.02, 9.01
- 2014-04-21 0001262039-14-000018 — 5.03, 9.01
- 2014-01-29 0001262039-14-000004 — 2.02, 9.01
- 2013-12-20 0001262039-13-000061 — 5.02, 9.01
- 2013-11-27 0001262039-13-000057 — 5.02, 7.01, 9.01
- 2013-11-12 0001445305-13-002993 — 5.02
- 2013-10-23 0001262039-13-000051 — 2.02, 9.01
- 2013-07-30 0001262039-13-000039 — 2.02, 9.01
- 2013-06-25 0001262039-13-000030 — 5.07
- 2013-04-30 0001262039-13-000023 — 2.02, 9.01
- 2013-04-19 0001262039-13-000020 — 5.02, 9.01
- 2013-04-19 0001262039-13-000018 — 5.02 — amendment of 0001262039-13-000020
- 2013-04-10 0001262039-13-000016 — 2.02, 9.01
- 2013-03-26 0001262039-13-000013 — 5.02
- 2013-01-30 0001262039-13-000005 — 2.02, 9.01
- 2013-01-24 0001262039-13-000002 — 5.02, 9.01
- 2012-10-16 0001262039-12-000048 — 2.02, 9.01
- 2012-10-01 0001262039-12-000045 — 5.02
- 2012-09-26 0001262039-12-000043 — 5.01
- 2012-07-25 0001262039-12-000038 — 2.02, 9.01
- 2012-07-19 0001262039-12-000034 — 5.02
- 2012-06-20 0001193125-12-275869 — 5.07
- 2012-04-27 0001262039-12-000029 — 5.02
- 2012-04-24 0001262039-12-000025 — 2.02, 9.01
- 2012-01-31 0001262039-12-000006 — 2.02, 9.01
- 2012-01-25 0001262039-12-000003 — 5.03
- 2011-10-24 0001262039-11-000036 — 2.02
- 2011-07-19 0001262039-11-000014 — 2.02, 9.01
- 2011-06-27 0001193125-11-174474 — 5.02, 5.07, 9.01
- 2011-04-27 0001193125-11-111938 — 2.02, 9.01
- 2011-01-25 0001193125-11-013914 — 2.02, 9.01
- 2010-10-21 0001193125-10-233676 — 2.02, 9.01
- 2010-09-02 0001193125-10-203099 — 8.01
- 2010-07-22 0001193125-10-163844 — 2.02, 9.01
- 2010-06-24 0001193125-10-146082 — 5.07
- 2010-04-28 0001193125-10-096698 — 2.02, 9.01
- 2010-02-09 0001193125-10-024614 — 8.01
- 2010-01-27 0001193125-10-014292 — 2.02, 9.01
- 2010-01-26 0001193125-10-013031 — 5.02, 9.01

## late-filing notifications on or before 2022-02-25

- none on or before 2022-02-25

## item 2.02 — earnings release, exhibit 99.1

[0001262039-22-000005:8k_2_02:1]
EX-99.1
2
ftntq4-2021ex991.htm
PRESS RELEASE

[0001262039-22-000005:8k_2_02:2]
Document

[0001262039-22-000005:8k_2_02:3]
Press Release

[0001262039-22-000005:8k_2_02:4]
Fortinet Reports Fourth Quarter and Full Year 2021 Financial Results

[0001262039-22-000005:8k_2_02:5]
Fourth Quarter 2021 Highlights

[0001262039-22-000005:8k_2_02:6]
•Total revenue of $963.6 million, up 29% year over year

[0001262039-22-000005:8k_2_02:7]
•Product revenue of $378.9 million, up 31% year over year

[0001262039-22-000005:8k_2_02:8]
•Service revenue of $584.7 million, up 27% year over year

[0001262039-22-000005:8k_2_02:9]
•Billings of $1.31 billion, up 36% year over year1

[0001262039-22-000005:8k_2_02:10]
•Bookings of $1.43 billion, up 49% year over year2

[0001262039-22-000005:8k_2_02:11]
•GAAP operating margin of 22.3%

[0001262039-22-000005:8k_2_02:12]
•Non-GAAP operating margin of 28.5%1

[0001262039-22-000005:8k_2_02:13]
•Cash paid for share repurchases of $571.8 million

[0001262039-22-000005:8k_2_02:14]
Full Year 2021 Highlights

[0001262039-22-000005:8k_2_02:15]
•Total revenue of $3.34 billion, up 29% year over year

[0001262039-22-000005:8k_2_02:16]
•Product revenue of $1.26 billion, up 37% year over year

[0001262039-22-000005:8k_2_02:17]
•Service revenue of $2.09 billion, up 24% year over year

[0001262039-22-000005:8k_2_02:18]
•Billings of $4.18 billion, up 35% year over year1

[0001262039-22-000005:8k_2_02:19]
•Bookings of $4.33 billion, up 40% year over year2

[0001262039-22-000005:8k_2_02:20]
•Deferred revenue of $3.45 billion, up 33% year over year

[0001262039-22-000005:8k_2_02:21]
•GAAP operating margin of 19.5%

[0001262039-22-000005:8k_2_02:22]
•Non-GAAP operating margin of 26.2%1

[0001262039-22-000005:8k_2_02:23]
•Cash flow from operations of $1.50 billion

[0001262039-22-000005:8k_2_02:24]
•Cash paid for share repurchases of $741.8 million

[0001262039-22-000005:8k_2_02:25]
•Free cash flow of $1.20 billion1

[0001262039-22-000005:8k_2_02:26]
SUNNYVALE, Calif. - February 3, 2022 - Fortinet® (Nasdaq: FTNT), a global leader in broad, integrated and automated cybersecurity solutions, today announced financial results for the fourth quarter and full year ended December 31, 2021.

[0001262039-22-000005:8k_2_02:27]
“Revenue growth accelerated to 29% in 2021, after three consecutive years with revenue growth of 20% or more. Cash flow from operations was $1.5 billion and free cash flow was a record $1.2 billion for the year,” said Ken Xie, Founder, Chairman and Chief Executive Officer. “Our 2021 performance was driven by increased demand for our cybersecurity solutions and exceptional execution from our global operations and sales teams and excellent support from our channel partners and distributors. Fortinet’s integrated and single platform approach to security is resonating with customers that want to effectively protect their corporate networks from a wide range of attack vectors. Given our robust pipeline and strong business momentum, we expect several more years of solid growth as Fortinet is well positioned to address our $174 billion market opportunity.”

[0001262039-22-000005:8k_2_02:28]
Financial Highlights for the Fourth Quarter of 2021

[0001262039-22-000005:8k_2_02:29]
•Revenue: Total revenue was $963.6 million for the fourth quarter of 2021, an increase of 28.8% compared to $748.0 million for the same quarter of 2020.

[0001262039-22-000005:8k_2_02:30]
•Product Revenue: Product revenue was $378.9 million for the fourth quarter of 2021, an increase of 31.4% compared to $288.4 million for the same quarter of 2020.

[0001262039-22-000005:8k_2_02:31]
•Service Revenue: Service revenue was $584.7 million for the fourth quarter of 2021, an increase of 27.2% compared to $459.6 million for the same quarter of 2020.

[0001262039-22-000005:8k_2_02:32]
•Billings1: Total billings were $1.31 billion for the fourth quarter of 2021, an increase of 35.9% compared to $960.9 million for the same quarter of 2020.

[0001262039-22-000005:8k_2_02:33]
•Bookings2: Total bookings were $1.43 billion for the fourth quarter of 2021, an increase of 48.7% compared to $960.3 million for the same quarter of 2020. Backlog2 was $161.9 million as of December 31, 2021 an increase of $149.7 million compared to $12.2 million as of December 31, 2020.

[0001262039-22-000005:8k_2_02:34]
•GAAP Operating Income and Margin: GAAP operating income was $214.9 million for the fourth quarter of 2021, representing a GAAP operating margin of 22.3%. GAAP operating income was $169.4 million for the same quarter of 2020, representing a GAAP operating margin of 22.6%.

[0001262039-22-000005:8k_2_02:35]
•Non-GAAP Operating Income and Margin1: Non-GAAP operating income was $274.7 million for the fourth quarter of 2021, representing a non-GAAP operating margin of 28.5%. Non-GAAP operating income was $219.9 million for the same quarter of 2020, representing a non-GAAP operating margin of 29.4%.

[0001262039-22-000005:8k_2_02:36]
•GAAP Net Income and Diluted Net Income Per Share Attributable to Fortinet, Inc.: GAAP net income was $199.0 million for the fourth quarter of 2021, compared to GAAP net income of $146.7 million for the same quarter of 2020. GAAP diluted net income per share was $1.19 for the fourth quarter of 2021, based on 167.0 million diluted weighted-average shares outstanding, compared to GAAP diluted net income per share of $0.89 for the same quarter of 2020, based on 165.5 million diluted weighted-average shares outstanding.

[0001262039-22-000005:8k_2_02:37]
•Non-GAAP Net Income and Diluted Net Income Per Share Attributable to Fortinet, Inc.1: Non-GAAP net income was $205.8 million for the fourth quarter of 2021, compared to non-GAAP net income of $175.5 million for the same quarter of 2020. Non-GAAP diluted net income per share was $1.23 for the fourth quarter of 2021, based on 167.0 million diluted weighted-average shares outstanding, compared to $1.06 for the same quarter of 2020, based on 165.5 million diluted weighted-average shares outstanding.

[0001262039-22-000005:8k_2_02:38]
•Cash Flow: Cash flow from operations was $366.8 million for the fourth quarter of 2021, compared to $296.5 million for the same quarter of 2020.

[0001262039-22-000005:8k_2_02:39]
•Free Cash Flow1: Free cash flow was $215.5 million for the fourth quarter of 2021, compared to $264.2 million for the same quarter of 2020.

[0001262039-22-000005:8k_2_02:40]
Financial Highlights for the Full Year 2021

[0001262039-22-000005:8k_2_02:41]
•Revenue: Total revenue was $3.34 billion for 2021, an increase of 28.8% compared to $2.59 billion in 2020.

[0001262039-22-000005:8k_2_02:42]
•Product Revenue: Product revenue was $1.26 billion for 2021, an increase of 36.9% compared to $916.4 million in 2020.

[0001262039-22-000005:8k_2_02:43]
•Service Revenue: Service revenue was $2.09 billion for 2021, an increase of 24.4% compared to $1.68 billion in 2020.

[0001262039-22-000005:8k_2_02:44]
•Billings1: Total billings were $4.18 billion for 2021, an increase of 35.3% compared to $3.09 billion in 2020.

[0001262039-22-000005:8k_2_02:45]
•Bookings2: Total bookings were $4.33 billion for 2021, an increase of 40.2% compared to $3.09 billion in 2020.

[0001262039-22-000005:8k_2_02:46]
•Deferred Revenue: Total deferred revenue was $3.45 billion as of December 31, 2021, an increase of 32.5% compared to $2.61 billion as of December 31, 2020.

[0001262039-22-000005:8k_2_02:47]
•GAAP Operating Income and Margin: GAAP operating income was $650.4 million for  2021, representing a GAAP operating margin of 19.5%. GAAP operating income was $531.8 million for 2020, representing a GAAP operating margin of 20.5%.

[0001262039-22-000005:8k_2_02:48]
•Non-GAAP Operating Income and Margin1: Non-GAAP operating income was $875.5 million for 2021, representing a non-GAAP operating margin of 26.2%. Non-GAAP operating income was $698.0 million for 2020, representing a non-GAAP operating margin of 26.9%.

[0001262039-22-000005:8k_2_02:49]
•GAAP Net Income and Diluted Net Income Per Share Attributable to Fortinet, Inc.: GAAP net income was $606.8 million for 2021, compared to GAAP net income of $488.5 million for 2020. GAAP diluted net income per share was $3.63 for 2021, based on 167.1 million diluted weighted-average shares outstanding, compared to GAAP diluted net income per share of $2.91 for 2020, based on 167.7 million diluted weighted-average shares outstanding.

[0001262039-22-000005:8k_2_02:50]
•Non-GAAP Net Income and Diluted Net Income Per Share Attributable to Fortinet, Inc.1: Non-GAAP net income was $666.0 million for 2021, compared to non-GAAP net income of $562.6 million for 2020. Non-GAAP diluted net income per share was $3.99 for 2021, based on 167.1 million diluted weighted-average shares outstanding, compared to $3.35 for 2020, based on 167.7 million diluted weighted-average shares outstanding.

[0001262039-22-000005:8k_2_02:51]
•Cash Flow: In 2021, cash flow from operations was $1.50 billion compared to $1.08 billion in 2020.

[0001262039-22-000005:8k_2_02:52]
•Free Cash Flow1: Free cash flow was $1.20 billion during 2021, compared to $907.8 million in 2020.

[0001262039-22-000005:8k_2_02:53]
Guidance

[0001262039-22-000005:8k_2_02:54]
For the first quarter of 2022, Fortinet currently expects:

[0001262039-22-000005:8k_2_02:55]
•Revenue in the range of $865 million to $895 million

[0001262039-22-000005:8k_2_02:56]
•Billings in the range of $1.050 billion to $1.090 billion

[0001262039-22-000005:8k_2_02:57]
•Non-GAAP gross margin in the range of 75.5% to 76.5%

[0001262039-22-000005:8k_2_02:58]
•Non-GAAP operating margin in the range of 19.5% to 20.5%

[0001262039-22-000005:8k_2_02:59]
•Diluted non-GAAP net income per share attributable to Fortinet, Inc. in the range of $0.75 to $0.80, assuming a non-GAAP effective tax rate of 18%. This assumes a diluted share count of 166 million to 168 million.

[0001262039-22-000005:8k_2_02:60]
For the fiscal year 2022, Fortinet currently expects:

[0001262039-22-000005:8k_2_02:61]
•Revenue in the range of $4.275 billion to $4.325 billion

[0001262039-22-000005:8k_2_02:62]
•Service revenue in the range of $2.685 billion to $2.715 billion

[0001262039-22-000005:8k_2_02:63]
•Billings in the range of $5.400 billion to $5.480 billion

[0001262039-22-000005:8k_2_02:64]
•Non-GAAP gross margin in the range of 74.0% to 76.0%

[0001262039-22-000005:8k_2_02:65]
•Non-GAAP operating margin in the range of 24.0% to 26.0%

[0001262039-22-000005:8k_2_02:66]
•Diluted non-GAAP net income per share attributable to Fortinet, Inc. in the range of $4.85 to $5.00, assuming a non-GAAP effective tax rate of 18%. This assumes a diluted share count of 169 million to 171 million.

[0001262039-22-000005:8k_2_02:67]
Our guidance with respect to non-GAAP financial measures excludes stock-based compensation, amortization of acquired intangible assets and gain on intellectual property matter. We have not reconciled our guidance with respect to non-GAAP financial measures to the corresponding GAAP measures because certain items that impact these measures are uncertain or out of our control, or cannot be reasonably predicted. Accordingly, a reconciliation of these non-GAAP financial measures to the corresponding GAAP measures is not available without unreasonable effort.

[0001262039-22-000005:8k_2_02:68]
1 A reconciliation of GAAP to non-GAAP measures has been provided in the financial statement tables included in this press release. An explanation of these measures is also included below under the heading “Non-GAAP Financial Measures”.

[0001262039-22-000005:8k_2_02:69]
2 Bookings represents the total value of all orders received during the fiscal period. Backlog represents orders received but not fulfilled and excludes Alaxala. When an order is fulfilled, billings and revenue are recognized.

[0001262039-22-000005:8k_2_02:70]
Conference Call Details

[0001262039-22-000005:8k_2_02:71]
Fortinet will host a conference call today at 1:30 p.m. Pacific Time (4:30 p.m. Eastern Time) to discuss the earnings results. The call can be accessed by dialing (877) 303-6913 (domestic) or (224) 357-2188 (international) with conference ID #1957267. A live webcast of the conference call and supplemental slides will be accessible from the Investor Relations page of Fortinet’s website at https://investor.fortinet.com and a replay will be archived and accessible at https://investor.fortinet.com/events-and-presentations. A replay of this conference call can also be accessed through February 10, 2022, by dialing (855) 859-2056 (domestic) or (404) 537-3406 (international) with conference ID #1957267.

[0001262039-22-000005:8k_2_02:72]
First Quarter 2022 Virtual Conference Participation Schedule:

[0001262039-22-000005:8k_2_02:73]
•Morgan Stanley Technology, Media & Telecom Conference

[0001262039-22-000005:8k_2_02:74]
March 9, 2022 – San Francisco, CA

[0001262039-22-000005:8k_2_02:75]
Members of Fortinet’s management team are expected to present at these conferences and discuss the latest company strategies and initiatives. Fortinet’s conference presentations are expected to be available via webcast on the company’s web site. To access the most updated

[0001262039-22-000005:8k_2_02:76]
information and listen to the webcast of each event, please visit the Investor Relations page of Fortinet’s website at https://investor.fortinet.com. The schedule is subject to change.

[0001262039-22-000005:8k_2_02:77]
About Fortinet (www.fortinet.com)

[0001262039-22-000005:8k_2_02:78]
Fortinet (Nasdaq: FTNT) secures the largest enterprise, service provider, and government organizations around the world. Fortinet empowers its customers with complete visibility and control across the expanding attack surface and the power to take on ever-increasing performance requirements today and into the future. The Fortinet Security Fabric platform can address the most critical security challenges and protect data across the entire digital infrastructure, whether in networked, application, multi-cloud or edge environments. Both a technology company and a learning organization, the Fortinet Network Security Institute has one of the largest and broadest cybersecurity training programs in the industry. Learn more at https://www.fortinet.com, the Fortinet Blog or FortiGuard Labs.

[0001262039-22-000005:8k_2_02:79]
#          #          #

[0001262039-22-000005:8k_2_02:80]
Copyright © 2022 Fortinet, Inc. All rights reserved. The symbols ® and ™ denote respectively federally registered trademarks and common law trademarks of Fortinet, Inc., its subsidiaries and affiliates. Fortinet’s trademarks include, but are not limited to, the following: Fortinet, the Fortinet logo, FortiGate, FortiOS, FortiGuard, FortiCare, FortiAnalyzer, FortiManager, FortiASIC, FortiClient, FortiCloud, FortiMail, FortiSandbox, FortiADC, FortiAI, FortiAIOps, FortiAntenna, FortiAP, FortiAPCam, FortiAuthenticator, FortiCache, FortiCall, FortiCam, FortiCamera, FortiCarrier, FortiCASB, FortiCentral, FortiConnect, FortiController, FortiConverter, FortiCWP, FortiDB, FortiDDoS, FortiDeceptor, FortiDeploy, FortiDevSec, FortiEdge, FortiEDR, FortiExplorer, FortiExtender, FortiFirewall, FortiFone, FortiGSLB, FortiHypervisor, FortiInsight, FortiIsolator, FortiLAN, FortiLink, FortiMoM, FortiMonitor, FortiNAC, FortiNDR, FortiPenTest, FortiPhish, FortiPlanner, FortiPolicy, FortiPortal, FortiPresence, FortiProxy, FortiRecorder, FortiSASE, FortiSDNConnector, FortiSIEM, FortiSMS, FortiSOAR, FortiSwitch, FortiTester, FortiToken, FortiVoice, FortiWAN, FortiWeb, FortiWiFi, FortiWLC, FortiWLM and FortiXDR. Other trademarks belong to their respective owners. Fortinet has not independently verified statements or certifications herein attributed to third parties and Fortinet does not independently endorse such statements. Notwithstanding anything to the contrary herein, nothing herein constitutes a warranty, guarantee, contract, binding specification or other binding commitment by Fortinet or any indication of intent related to a binding commitment, and performance and other specification information herein may be unique to certain environments.

[0001262039-22-000005:8k_2_02:81]
FTNT-F

[0001262039-22-000005:8k_2_02:82]
Forward-Looking Statements

[0001262039-22-000005:8k_2_02:83]
This press release contains forward-looking statements that involve risks and uncertainties. These forward-looking statements include statements regarding demand for our products and services, guidance and expectations around future financial results, including guidance and expectations for the first quarter and full year 2022, statements regarding the momentum in our business and future growth expectations, and statements regarding our robust pipeline, market opportunity and market size, strong business momentum, and expectations of several more years of solid growth. Although we attempt to be accurate in making forward-looking statements, it is possible that future circumstances might differ from the assumptions on which such statements are based such that actual results are materially different from our forward-looking statements in this release. Important factors that could cause results to differ materially from the statements herein include the following: general economic risks, including those caused by the COVID-19 pandemic; significantly heightened supply chain challenges due to the current global environment; negative impacts from the COVID-19 pandemic on sales, billings, revenue, demand and buying patterns, component supply and ability to manufacture products to meet demand in a timely fashion, and costs such as possible increased costs for shipping and components; global economic conditions, country-specific economic conditions, and foreign

[0001262039-22-000005:8k_2_02:84]
COVID-19 Impact

[0001262039-22-000005:8k_2_02:85]
While the broader implications of the COVID-19 pandemic on our employees and overall financial performance remain uncertain, we have seen certain impacts on our business and operations, results of operations, financial condition, cash flows, liquidity and capital and financial resources. Going forward, the situation is uncertain, rapidly changing and hard to predict, and the COVID-19 pandemic may have a material negative impact on our future periods, including our results for the three months ending March 31, 2022, our annual results for 2022, and beyond. To highlight the uncertainty remaining for the three-month period ending March 31, 2022, it should be noted that, due to customer buying patterns and the efforts of our sales force and channel partners to meet or exceed quarterly quotas, we have historically received a substantial portion of each quarter’s sales orders and generated a substantial portion of each quarter’s billings and revenue during the last two weeks of the quarter. Additionally, significantly heightened supply chain challenges are impacting businesses around the globe. If we experience significant changes in our billings growth rates or if we are unable to supply product to meet demand, it will impact product revenue in the current quarter and FortiGuard and FortiCare service revenues in subsequent quarters, as we sell annual and multi-year service contracts that are recognized ratably over the contractual service term. In addition, the broader implications of the pandemic on our business and operations and our financial results,

[0001262039-22-000005:8k_2_02:86]
including the extent to which the effects of the pandemic will impact future results and growth in the cybersecurity industry, remain uncertain. The duration and severity of the economic downturn from the pandemic may negatively impact our business and operations, results of operations, financial condition, cash flows, liquidity and capital and financial resources in a material way. As a result, the effects of the pandemic may not be fully reflected in our results of operations until future periods.

[0001262039-22-000005:8k_2_02:87]
Non-GAAP Financial Measures

[0001262039-22-000005:8k_2_02:88]
We have provided in this release financial information that has not been prepared in accordance with U.S. Generally Accepted Accounting Principles (GAAP). These non-GAAP financial and liquidity measures are not based on any standardized methodology prescribed by GAAP and are not necessarily comparable to similar measures presented by other companies. We use these non-GAAP financial measures internally in analyzing our financial results and believe they are useful to investors, as a supplement to GAAP measures, in evaluating our ongoing operational performance. We believe that the use of these non-GAAP financial measures provides an additional tool for investors to use in evaluating ongoing operating results and trends and in comparing our financial results with peer companies, many of which present similar non-GAAP financial measures to investors.

[0001262039-22-000005:8k_2_02:89]
Non-GAAP financial measures should not be considered in isolation from, or as a substitute for, financial information prepared in accordance with GAAP. Investors are encouraged to review the reconciliation of these non-GAAP financial measures to their most directly comparable GAAP financial measures provided in the financial statement tables below.

[0001262039-22-000005:8k_2_02:90]
Billings (non-GAAP). We define billings as revenue recognized in accordance with GAAP plus the change in deferred revenue from the beginning to the end of the period, less any deferred revenue balances acquired from business combination(s) and adjustment due to adoption of new accounting standard during the period. We consider billings to be a useful metric for management and investors because billings drive current and future revenue, which is an important indicator of the health and viability of our business. There are a number of limitations related to the use of billings instead of GAAP revenue. First, billings include amounts that have not yet been recognized as revenue and are impacted by the term of security and support agreements. Second, we may calculate billings in a manner that is different from peer companies that report similar financial measures. Management accounts for these limitations by providing specific information regarding GAAP revenue and evaluating billings together with GAAP revenue.

[0001262039-22-000005:8k_2_02:91]
Free cash flow (non-GAAP). We define free cash flow as net cash provided by operating activities minus purchases of property and equipment and excluding any significant non-recurring items, such as proceeds from intellectual property matter. We believe free cash flow to be a liquidity measure that provides useful information to management and investors about the amount of cash generated by the business that, after capital expenditures and net of proceeds from intellectual property matter, can be used for strategic opportunities, including repurchasing outstanding common stock, investing in our business, making strategic acquisitions and strengthening the balance sheet. A limitation of using free cash flow rather than the GAAP measures of cash provided by or used in operating activities, investing activities, and financing activities is that free cash flow does not represent the total increase or decrease in the cash and cash equivalents balance for the period because it excludes cash flows from significant non-recurring items, such as proceeds from intellectual property matter, investing activities other than capital expenditures and cash flows from financing activities. Management accounts for this limitation by providing information about our capital expenditures and other investing and financing activities on the face of the cash flow statement and under the caption “Management’s Discussion and Analysis of Financial Condition and Results of Operations—Liquidity and Capital Resources” in our most recent Quarterly Report on Form 10-Q and Annual Report on Form 10-K

[0001262039-22-000005:8k_2_02:92]
and by presenting cash flows from investing and financing activities in our reconciliation of free cash flow. In addition, it is important to note that other companies, including companies in our industry, may not use free cash flow, may calculate free cash flow in a different manner than we do or may use other financial measures to evaluate their performance, all of which could reduce the usefulness of free cash flow as a comparative measure.

[0001262039-22-000005:8k_2_02:93]
Non-GAAP operating income and operating margin. We define non-GAAP operating income as operating income plus stock-based compensation, impairment and amortization of acquired intangible assets, less gain on intellectual property matter and, when applicable, other significant non-recurring items in a given quarter, such as non-recurring gains or losses on litigation-related matters. Non-GAAP operating margin is defined as non-GAAP operating income divided by GAAP revenue. We consider these non-GAAP financial measures to be useful metrics for management and investors because they exclude the items noted above so that our management and investors can compare our recurring core business operating results over multiple periods. There are a number of limitations related to the use of non-GAAP operating income instead of operating income calculated in accordance with GAAP. First, non-GAAP operating income excludes the items noted above. Second, the components of the costs that we exclude from our calculation of non-GAAP operating income may differ from the components that peer companies exclude when they report their non-GAAP results of operations. Management accounts for these limitations by providing specific information regarding the GAAP amounts excluded from non-GAAP operating income and evaluating non-GAAP operating income together with operating income calculated in accordance with GAAP.

[0001262039-22-000005:8k_2_02:94]
Non-GAAP net income and diluted net income per share attributable to Fortinet, Inc. We define non-GAAP net income as net income or loss plus the items noted above under non-GAAP operating income and operating margin. In addition, we adjust non-GAAP net income and diluted net income per share for gains or losses on investments in privately held companies, a tax adjustment required for an effective tax rate on a non-GAAP basis and adjustments attributable to non-controlling interests, which differs from the GAAP effective tax rate. We define non-GAAP diluted net income per share as non-GAAP net income divided by the non-GAAP diluted weighted-average shares outstanding. We consider these non-GAAP financial measures to be useful metrics for management and investors for the same reasons that we use non-GAAP operating income and non-GAAP operating margin. However, in order to provide a more complete picture of our recurring core business operating results, we include in non-GAAP net income and non-GAAP diluted net income per share, the tax adjustment required resulting in an effective tax rate on a non-GAAP basis, which often differs from the GAAP tax rate. We believe the non-GAAP effective tax rates we use are reasonable estimates of normalized tax rates for our current and prior fiscal years under our global operating structure. The same limitations described above regarding our use of non-GAAP operating income and non-GAAP operating margin apply to our use of non-GAAP net income and non-GAAP diluted net income per share. We account for these limitations by providing specific information regarding the GAAP amounts excluded from non-GAAP net income and non-GAAP diluted net income per share and evaluating non-GAAP net income and non-GAAP diluted net income per share together with net income or loss and diluted net income per share calculated in accordance with GAAP.

[0001262039-22-000005:8k_2_02:95]
FORTINET, INC.

[0001262039-22-000005:8k_2_02:96]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001262039-22-000005:8k_2_02:97]
(Unaudited, in millions)

[0001262039-22-000005:8k_2_02:98]
|  | December 31,2021 |  | December 31,2020 |
| ASSETS |  |  |  |
| CURRENT ASSETS: |  |  |  |
| Cash and cash equivalents | $ | 1,319.1 |  |  | $ | 1,061.8 |  |
| Short-term investments | 1,194.0 |  |  | 775.5 |  |
| Marketable equity securities | 38.6 |  |  | — |  |
| Accounts receivable—net | 807.7 |  |  | 720.0 |  |
| Inventory | 175.8 |  |  | 139.8 |  |
| Prepaid expenses and other current assets | 65.4 |  |  | 43.3 |  |
| Total current assets | 3,600.6 |  |  | 2,740.4 |  |
| LONG-TERM INVESTMENTS | 440.8 |  |  | 118.3 |  |
| PROPERTY AND EQUIPMENT—NET | 687.6 |  |  | 448.0 |  |
| DEFERRED CONTRACT COSTS | 423.3 |  |  | 304.8 |  |
| DEFERRED TAX ASSETS | 342.3 |  |  | 245.2 |  |
| GOODWILL AND OTHER INTANGIBLE ASSETS—NET | 188.7 |  |  | 124.6 |  |
| OTHER ASSETS | 235.8 |  |  | 63.2 |  |
| TOTAL ASSETS | $ | 5,919.1 |  |  | $ | 4,044.5 |  |
| LIABILITIES AND EQUITY |  |  |  |
| CURRENT LIABILITIES: |  |  |  |
| Accounts payable | $ | 148.4 |  |  | $ | 141.6 |  |
| Accrued liabilities | 197.3 |  |  | 149.2 |  |
| Accrued payroll and compensation | 195.0 |  |  | 145.9 |  |
| Deferred revenue | 1,777.4 |  |  | 1,392.8 |  |
| Total current liabilities | 2,318.1 |  |  | 1,829.5 |  |
| DEFERRED REVENUE | 1,675.5 |  |  | 1,212.5 |  |
| INCOME TAX LIABILITIES | 79.5 |  |  | 90.3 |  |
| LONG-TERM DEBT | 988.4 |  |  | — |  |
| OTHER LIABILITIES | 59.2 |  |  | 56.2 |  |
| Total liabilities | 5,120.7 |  |  | 3,188.5 |  |
| COMMITMENTS AND CONTINGENCIES |  |  |  |
| EQUITY: |  |  |  |
| Common stock | 0.2 |  |  | 0.2 |  |
| Additional paid-in capital | 1,254.2 |  |  | 1,207.2 |  |
| Accumulated other comprehensive income (loss) | (4.8) |  |  | 0.7 |  |
| Accumulated deficit | (467.9) |  |  | (352.1) |  |
| Total Fortinet, Inc. stockholders’ equity | 781.7 |  |  | 856.0 |  |
| Non-controlling interests | 16.7 |  |  | — |  |
| Total equity | 798.4 |  |  | 856.0 |  |
| TOTAL LIABILITIES AND EQUITY | $ | 5,919.1 |  |  | $ | 4,044.5 |  |

[0001262039-22-000005:8k_2_02:99]
FORTINET, INC.

[0001262039-22-000005:8k_2_02:100]
CONDENSED CONSOLIDATED STATEMENTS OF INCOME

[0001262039-22-000005:8k_2_02:101]
(Unaudited, in millions, except per share amounts)

[0001262039-22-000005:8k_2_02:102]
|  | Three Months Ended |  | Year Ended |
|  | December 31,2021 |  | December 31,2020 |  | December 31,2021 |  | December 31,2020 |
| REVENUE: |  |  |  |  |  |  |  |
| Product | $ | 378.9 |  |  | $ | 288.4 |  |  | $ | 1,255.0 |  |  | $ | 916.4 |  |
| Service | 584.7 |  |  | 459.6 |  |  | 2,087.2 |  |  | 1,678.0 |  |
| Total revenue | 963.6 |  |  | 748.0 |  |  | 3,342.2 |  |  | 2,594.4 |  |
| COST OF REVENUE: |  |  |  |  |  |  |  |
| Product | 146.5 |  |  | 107.4 |  |  | 487.7 |  |  | 352.4 |  |
| Service | 81.8 |  |  | 59.6 |  |  | 295.3 |  |  | 217.6 |  |
| Total cost of revenue | 228.3 |  |  | 167.0 |  |  | 783.0 |  |  | 570.0 |  |
| GROSS PROFIT: |  |  |  |  |  |  |  |
| Product | 232.4 |  |  | 181.0 |  |  | 767.3 |  |  | 564.0 |  |
| Service | 502.9 |  |  | 400.0 |  |  | 1,791.9 |  |  | 1,460.4 |  |
| Total gross profit | 735.3 |  |  | 581.0 |  |  | 2,559.2 |  |  | 2,024.4 |  |
| OPERATING EXPENSES: |  |  |  |  |  |  |  |
| Research and development | 112.6 |  |  | 89.0 |  |  | 424.2 |  |  | 341.4 |  |
| Sales and marketing | 367.7 |  |  | 291.4 |  |  | 1,345.7 |  |  | 1,071.9 |  |
| General and administrative | 41.3 |  |  | 32.4 |  |  | 143.5 |  |  | 119.5 |  |
| Gain on intellectual property matter | (1.2) |  |  | (1.2) |  |  | (4.6) |  |  | (40.2) |  |
| Total operating expenses | 520.4 |  |  | 411.6 |  |  | 1,908.8 |  |  | 1,492.6 |  |
| OPERATING INCOME | 214.9 |  |  | 169.4 |  |  | 650.4 |  |  | 531.8 |  |
| INTEREST INCOME | 1.0 |  |  | 2.0 |  |  | 4.5 |  |  | 17.7 |  |
| INTEREST EXPENSE | (4.5) |  |  | — |  |  | (14.9) |  |  | — |  |
| OTHER INCOME (EXPENSE)—NET | (4.1) |  |  | 0.3 |  |  | (11.6) |  |  | (7.8) |  |
| INCOME BEFORE INCOME TAXES AND LOSS FROM EQUITY METHOD INVESTMENT | 207.3 |  |  | 171.7 |  |  | 628.4 |  |  | 541.7 |  |
| PROVISION FOR INCOME TAXES | 3.7 |  |  | 25.0 |  |  | 14.1 |  |  | 53.2 |  |
| LOSS FROM EQUITY METHOD INVESTMENT | (4.8) |  |  | — |  |  | (7.6) |  |  | — |  |
| NET INCOME INCLUDING NON-CONTROLLING INTERESTS | 198.8 |  |  | 146.7 |  |  | 606.7 |  |  | 488.5 |  |
| Less: NET LOSS ATTRIBUTABLE TO NON-CONTROLLING INTERESTS, NET OF TAX | (0.2) |  |  | — |  |  | (0.1) |  |  | — |  |
| NET INCOME ATTRIBUTABLE TO FORTINET, INC. | $ | 199.0 |  |  | $ | 146.7 |  |  | $ | 606.8 |  |  | $ | 488.5 |  |
| Net income per share attributable to Fortinet, Inc.: |  |  |  |  |  |  |  |
| Basic | $ | 1.22 |  |  | $ | 0.90 |  |  | $ | 3.72 |  |  | $ | 2.98 |  |
| Diluted | $ | 1.19 |  |  | $ | 0.89 |  |  | $ | 3.63 |  |  | $ | 2.91 |  |
| Weighted-average shares used to compute net income per share attributable to Fortinet, Inc.: |  |  |  |  |  |  |  |
| Basic | 163.0 |  |  | 162.5 |  |  | 163.2 |  |  | 164.2 |  |
| Diluted | 167.0 |  |  | 165.5 |  |  | 167.1 |  |  | 167.7 |  |

[0001262039-22-000005:8k_2_02:103]
FORTINET, INC.

[0001262039-22-000005:8k_2_02:104]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001262039-22-000005:8k_2_02:105]
(Unaudited, in millions)

[0001262039-22-000005:8k_2_02:106]
|  | Year Ended |
|  | December 31,2021 |  | December 31,2020 |
| CASH FLOWS FROM OPERATING ACTIVITIES: |  |  |  |
| Net income including non-controlling interests | $ | 606.7 |  |  | $ | 488.5 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |
| Stock-based compensation | 207.9 |  |  | 191.7 |  |
| Amortization of deferred contract costs | 175.9 |  |  | 137.4 |  |
| Depreciation and amortization | 84.4 |  |  | 68.8 |  |
| Amortization of investment premiums | 6.9 |  |  | 1.3 |  |
| Loss from equity method investment | 7.6 |  |  | — |  |
| Other | 7.9 |  |  | 6.0 |  |
| Changes in operating assets and liabilities, net of impact of business combinations: |  |  |  |
| Accounts receivable—net | (72.5) |  |  | (176.4) |  |
| Inventory | (19.4) |  |  | (42.2) |  |
| Prepaid expenses and other current assets | (17.7) |  |  | (2.8) |  |
| Deferred contract costs | (294.5) |  |  | (205.1) |  |
| Deferred tax assets | (94.0) |  |  | (10.5) |  |
| Other assets | (19.0) |  |  | (4.6) |  |
| Accounts payable | (13.1) |  |  | 37.4 |  |
| Accrued liabilities | 49.9 |  |  | 45.8 |  |
| Accrued payroll and compensation | 44.0 |  |  | 43.1 |  |
| Other liabilities | (0.7) |  |  | 9.7 |  |
| Deferred revenue | 839.4 |  |  | 495.6 |  |
| Net cash provided by operating activities | 1,499.7 |  |  | 1,083.7 |  |
| CASH FLOWS FROM INVESTING ACTIVITIES: |  |  |  |
| Purchases of investments | (2,308.0) |  |  | (1,079.0) |  |
| Sales of investments | 85.5 |  |  | 152.2 |  |
| Maturities of investments | 1,470.3 |  |  | 1,018.8 |  |
| Purchases of property and equipment | (295.9) |  |  | (125.9) |  |
| Purchases of investment in privately held company | (160.0) |  |  | — |  |
| Payments made in connection with business combinations, net of cash acquired | (74.9) |  |  | (40.2) |  |
| Purchases of marketable equity securities | (42.5) |  |  | — |  |
| Other | 0.4 |  |  | 1.3 |  |
| Net cash used in investing activities | (1,325.1) |  |  | (72.8) |  |
| CASH FLOWS FROM FINANCING ACTIVITIES: |  |  |  |
| Proceeds from long-term borrowings, net of discount and underwriting fees | 989.4 |  |  | — |  |
| Payments for debt issuance costs | (2.4) |  |  | — |  |
| Repurchase and retirement of common stock | (741.8) |  |  | (1,080.1) |  |
| Proceeds from issuance of common stock | 26.0 |  |  | 22.1 |  |
| Taxes paid related to net share settlement of equity awards | (167.9) |  |  | (108.2) |  |
| Payments of debt assumed in connection with business combinations | (19.5) |  |  | (4.1) |  |
| Other | (1.0) |  |  | (1.3) |  |
| Net cash provided by (used in) financing activities | 82.8 |  |  | (1,171.6) |  |
| EFFECT OF EXCHANGE RATE CHANGES ON CASH AND CASH EQUIVALENTS | (0.1) |  |  | — |  |
| NET INCREASE (DECREASE) IN CASH AND CASH EQUIVALENTS | 257.3 |  |  | (160.7) |  |
| CASH AND CASH EQUIVALENTS—Beginning of year | 1,061.8 |  |  | 1,222.5 |  |
| CASH AND CASH EQUIVALENTS—End of year | $ | 1,319.1 |  |  | $ | 1,061.8 |  |

[0001262039-22-000005:8k_2_02:107]
Reconciliations of non-GAAP results of operations measures to the nearest comparable GAAP measures

[0001262039-22-000005:8k_2_02:108]
(Unaudited, in millions, except per share amounts)

[0001262039-22-000005:8k_2_02:109]
Reconciliation of net cash provided by operating activities to free cash flow

[0001262039-22-000005:8k_2_02:110]
|  | Three Months Ended |  | Year Ended |
|  | December 31,2021 |  | December 31,2020 |  | December 31,2021 |  | December 31,2020 |
| Net cash provided by operating activities | $ | 366.8 |  |  | $ | 296.5 |  |  | $ | 1,499.7 |  |  | $ | 1,083.7 |  |
| Less: Purchases of property and equipment | (151.3) |  |  | (32.3) |  |  | (295.9) |  |  | (125.9) |  |
| Less: Proceeds from intellectual property matter | — |  |  | — |  |  | — |  |  | (50.0) |  |
| Free cash flow | $ | 215.5 |  |  | $ | 264.2 |  |  | $ | 1,203.8 |  |  | $ | 907.8 |  |
| Net cash used in investing activities | $ | (265.9) |  |  | $ | (65.0) |  |  | $ | (1,325.1) |  |  | $ | (72.8) |  |
| Net cash provided by (used in) financing activities | $ | (633.6) |  |  | $ | (52.0) |  |  | $ | 82.8 |  |  | $ | (1,171.6) |  |

[0001262039-22-000005:8k_2_02:111]
Reconciliation of GAAP operating income to non-GAAP operating income, operating margin, net income attributable to Fortinet, Inc. and diluted net income per share attributable to Fortinet, Inc.

[0001262039-22-000005:8k_2_02:112]
|  | Three Months Ended December 31, 2021 |  | Three Months Ended December 31, 2020 |
|  | GAAP Results |  | Adjustments |  | Non-GAAP Results |  | GAAP Results |  | Adjustments |  | Non-GAAP Results |
| Operating income | $ | 214.9 |  |  | $ | 59.8 |  | (a) | $ | 274.7 |  |  | $ | 169.4 |  |  | $ | 50.5 |  | (b) | $ | 219.9 |  |
| Operating margin | 22.3 | % |  |  |  | 28.5 | % |  | 22.6 | % |  |  |  | 29.4 | % |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | 54.2 |  |  |  |  |  |  | 48.9 |  |  |  |
| Amortization of acquired intangible assets |  |  | 6.8 |  |  |  |  |  |  | 2.8 |  |  |  |
| Gain on intellectual property matter |  |  | (1.2) |  |  |  |  |  |  | (1.2) |  |  |  |
| Tax adjustment |  |  | (52.4) |  | (c) |  |  |  |  | (21.7) |  | (c) |  |
| Adjustments attributable non-controlling interests |  |  | (0.6) |  | (d) |  |  |  |  | — |  |  |  |
| Net income attributable to Fortinet, Inc. | $ | 199.0 |  |  | $ | 6.8 |  |  | $ | 205.8 |  |  | $ | 146.7 |  |  | $ | 28.8 |  |  | $ | 175.5 |  |
| Diluted net income per share attributable to Fortinet, Inc. | $ | 1.19 |  |  |  |  | $ | 1.23 |  |  | $ | 0.89 |  |  |  |  | $ | 1.06 |  |
| Shares used in diluted net income per share attributable to Fortinet, Inc. calculations | 167.0 |  |  |  |  | 167.0 |  |  | 165.5 |  |  |  |  | 165.5 |  |

[0001262039-22-000005:8k_2_02:113]
(a) To exclude $54.2 million of stock-based compensation and $6.8 million of amortization of acquired intangible assets, offset by a $1.2 million gain on intellectual property matter in the three months ended December 31, 2021.

[0001262039-22-000005:8k_2_02:114]
(b) To exclude $48.9 million of stock-based compensation and $2.8 million of amortization of acquired intangible assets, offset by a $1.2 million gain on intellectual property matter in the three months ended December 31, 2020.

[0001262039-22-000005:8k_2_02:115]
(c) Non-GAAP financial information is adjusted to an overall effective tax rate of 21% in the three months ended December 31, 2021 and 2020, on a non-GAAP basis, which differs from the GAAP effective tax rate.

[0001262039-22-000005:8k_2_02:116]
(d) Adjustments related to the non-GAAP results attributable to non-controlling interests, which were adjusted to an effective tax rate of 31% for the subsidiary of Alaxala Networks Corporation (“Alaxala”) in the three months ended December 31, 2021.

[0001262039-22-000005:8k_2_02:117]
|  | Year Ended December 31, 2021 |  | Year Ended December 31, 2020 |
|  | GAAP Results |  | Adjustments |  | Non-GAAP Results |  | GAAP Results |  | Adjustments |  | Non-GAAP Results |
| Operating income | $ | 650.4 |  |  | $ | 225.1 |  | (a) | $ | 875.5 |  |  | $ | 531.8 |  |  | $ | 166.2 |  | (b) | $ | 698.0 |  |
| Operating margin | 19.5 | % |  |  |  | 26.2 | % |  | 20.5 | % |  |  |  | 26.9 | % |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | 211.2 |  |  |  |  |  |  | 193.8 |  |  |  |
| Amortization of acquired intangible assets |  |  | 18.5 |  |  |  |  |  |  | 13.3 |  |  |  |
| Gain on intellectual property matter |  |  | (4.6) |  |  |  |  |  |  | (40.2) |  |  |  |
| Litigation-related matter |  |  | — |  |  |  |  |  |  | (0.7) |  |  |  |
| Loss on investments in privately-held companies |  |  | — |  |  |  |  |  |  | 4.3 |  | (c) |  |
| Tax adjustment |  |  | (165.1) |  | (d) |  |  |  |  | (96.4) |  | (d) |  |
| Adjustments attributable non-controlling interests |  |  | (0.8) |  | (e) |  |  |  |  | — |  |  |  |
| Net income attributable to Fortinet, Inc. | $ | 606.8 |  |  | $ | 59.2 |  |  | $ | 666.0 |  |  | $ | 488.5 |  |  | $ | 74.1 |  |  | $ | 562.6 |  |
| Diluted net income per share attributable to Fortinet, Inc. | $ | 3.63 |  |  |  |  | $ | 3.99 |  |  | $ | 2.91 |  |  |  |  | $ | 3.35 |  |
| Shares used in diluted net income per share calculations | 167.1 |  |  |  |  | 167.1 |  |  | 167.7 |  |  |  |  | 167.7 |  |

[0001262039-22-000005:8k_2_02:118]
(a) To exclude $211.2 million of stock-based compensation and $18.5 million of amortization of acquired intangible assets, offset by a $4.6 million gain on intellectual property matter in 2021.

[0001262039-22-000005:8k_2_02:119]
(b) To exclude $193.8 million of stock-based compensation and $13.3 million of amortization of acquired intangible assets, offset by a $40.2 million gain on intellectual property matter and a $0.7 million adjustment for a litigation-related matter in 2020.

[0001262039-22-000005:8k_2_02:120]
(c) To exclude a $4.3 million impairment charge on an investment in a privately held company in 2020.

[0001262039-22-000005:8k_2_02:121]
(d) Non-GAAP financial information is adjusted to an overall effective tax rate of 21% in 2021 and 2020, on a non-GAAP basis, which differs from the GAAP effective tax rate.

[0001262039-22-000005:8k_2_02:122]
(e) Adjustments related to the non-GAAP results attributable to non-controlling interests, which were adjusted to an effective tax rate of 31% for the subsidiary of Alaxala in 2021.

[0001262039-22-000005:8k_2_02:123]
Reconciliation of total revenue to total billings

[0001262039-22-000005:8k_2_02:124]
|  | Three Months Ended |  | Year Ended |
|  | December 31,2021 |  | December 31,2020 |  | December 31,2021 |  | December 31,2020 |
| Total revenue | $ | 963.6 |  |  | $ | 748.0 |  |  | $ | 3,342.2 |  |  | $ | 2,594.4 |  |
| Add: Change in deferred revenue | 346.5 |  |  | 213.3 |  |  | 847.6 |  |  | 496.2 |  |
| Less: Deferred revenue balance acquired in business acquisitions | — |  |  | (0.4) |  |  | (4.1) |  |  | (0.6) |  |
| Less: Adjustment due to adoption of ASU 2021-083 | (4.3) |  |  | — |  |  | (4.3) |  |  | — |  |
| Total billings | $ | 1,305.8 |  |  | $ | 960.9 |  |  | $ | 4,181.4 |  |  | $ | 3,090.0 |  |

[0001262039-22-000005:8k_2_02:125]
3 We early adopted ASU 2021-08 on a retrospective basis and effective for us beginning on January 1, 2021. The adoption of ASU 2021-08 resulted in a $4.3 million adjustment attributable to the acquisition of Alaxala in 2021, as a result of the revised measurement of deferred revenue for acquisition.

[0001262039-22-000005:8k_2_02:126]
| Investor Contact: |  | Media Contact: |
| Peter Salkowski |  | Sandra Wheatley |
| Fortinet, Inc. |  | Fortinet, Inc. |
| 408-331-4595 |  | 408-391-9408 |
| psalkowski@fortinet.com |  | swheatley@fortinet.com |
