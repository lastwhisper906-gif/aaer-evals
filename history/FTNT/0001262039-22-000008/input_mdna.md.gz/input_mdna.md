# FTNT MD&A — 0001262039-22-000008


## mdna

[0001262039-22-000008:mdna:1]
ITEM 7.     Management’s Discussion and Analysis of Financial Condition and Results of Operations

[0001262039-22-000008:mdna:2]
•the effects of supply chain constraints and the global chip and component shortages and other factors affecting our manufacturing capacity, delivery, cost and inventory management;

[0001262039-22-000008:mdna:3]
•the duration and impact of the COVID-19 pandemic, including various COVID-19 variants, and the implementation of “return to office” plans;

[0001262039-22-000008:mdna:4]
•continued growth and market share gains;

[0001262039-22-000008:mdna:5]
•variability in sales in certain product categories from year to year and between quarters;

[0001262039-22-000008:mdna:6]
•expected impact of sales of certain products and services;

[0001262039-22-000008:mdna:7]
•the impact of macro-economic, geopolitical factors and other disruption on our manufacturing or sales, including the impact of the COVID-19 pandemic and other public health issues and natural disasters;

[0001262039-22-000008:mdna:8]
•the proportion of our revenue that consists of product and service revenue, and the mix of billings between products and services, and the duration of service contracts;

[0001262039-22-000008:mdna:9]
•the impact of our product innovation strategy;

[0001262039-22-000008:mdna:10]
•the effects of government regulation, tariffs and other policies;

[0001262039-22-000008:mdna:11]
•drivers of long-term growth and operating leverage, such as sales productivity and capacity, functionality and value in our subscription service offerings;

[0001262039-22-000008:mdna:12]
•growing our sales to businesses, service providers and government organizations, our ability to execute these sales and the complexity of selling to all segments (including the increased competition and unpredictability of timing associated with sales to larger enterprises), the impact of sales to these organizations on our long-term growth, expansion and operating results, and the effectiveness of our sales organization;

[0001262039-22-000008:mdna:13]
•our ability to hire properly qualified and effective sales, support and engineering employees;

[0001262039-22-000008:mdna:14]
•risks and expectations related to acquisitions and equity interests in private and public companies, including integration issues related to product plans and the acquired technology, and risks of negative impact by such acquisitions and equity investments on our financial results;

[0001262039-22-000008:mdna:15]
•trends in revenue, cost of revenue and gross margin;

[0001262039-22-000008:mdna:16]
•trends in our operating expenses, including sales and marketing expense, research and development expense, general and administrative expense, and expectations regarding these expenses;

[0001262039-22-000008:mdna:17]
•expectations that our operating expense will increase in absolute dollars during 2022;

[0001262039-22-000008:mdna:18]
•expectations that proceeds from the exercise of stock options in future years will be adversely impacted by the increased mix of restricted stock units versus stock options granted;

[0001262039-22-000008:mdna:19]
•expectations regarding uncertain tax benefits and our effective domestic and global tax rates, and the impact of the Tax Cuts and Jobs Act and the Coronavirus Aid, Relief, and Economic Security Act (the “CARES Act”);

[0001262039-22-000008:mdna:20]
•expectations regarding spending related to real estate acquisitions and development, data center investments, as well as other capital expenditures and to the impact on free cash flow;

[0001262039-22-000008:mdna:21]
49

[0001262039-22-000008:mdna:22]
•estimates of a range of 2022 spending on capital expenditures;

[0001262039-22-000008:mdna:23]
•competition in our markets;

[0001262039-22-000008:mdna:24]
•statements regarding expected outcomes and liabilities in litigation;

[0001262039-22-000008:mdna:25]
•our intentions regarding share repurchases and the sufficiency of our existing cash, cash equivalents and investments to meet our cash needs, including our debt servicing requirements, for at least the next 12 months;

[0001262039-22-000008:mdna:26]
•other statements regarding our future operations, financial condition and prospects and business strategies; and

[0001262039-22-000008:mdna:27]
•adoption and impact of new accounting standards.

[0001262039-22-000008:mdna:28]
Business Overview

[0001262039-22-000008:mdna:29]
Fortinet is a global leader in cybersecurity solutions provided to a wide variety of organizations, including enterprises, communication service providers and security service providers, government organizations and small businesses. Our cybersecurity solutions are designed to provide broad visibility and segmentation of the digital attack surface through our integrated Fortinet Security Fabric cybersecurity mesh platform, which features automated protection, detection and response along with consolidated visibility across both Fortinet developed solutions and a broad ecosystem of third-party solutions and technologies. The Fortinet Security Fabric cybersecurity mesh platform leverages a common operating system or integration to this operating system across our product offerings and helps organizations better secure their environments and reduce their security and network complexities. The Fortinet Security Fabric has an open architecture designed to connect Fortinet solutions and third-party solutions in a single ecosystem, enabling holistic detection and coordinated response across the attack cycle and surface through integration and automation.

[0001262039-22-000008:mdna:30]
Our product offerings consist of our FortiGate network security physical and virtual products and our non-FortiGate physical and virtual, software, and cloud-hosted products. In addition to high performing security and networking features, we offer a rich set of cloud-delivered security services that can be added to different products across the Fortinet Security Fabric and customized to the organization’s use cases.

[0001262039-22-000008:mdna:31]
Our cloud- and hosted- products and services include sandboxing, endpoint detection and response (“EDR”), email security, web application and API security and cloud networking security as well as Fortinet Security Fabric management and analytics.

[0001262039-22-000008:mdna:32]
Our FortiGuard security services are enabled by FortiGuard Labs, which provides threat research and artificial intelligence capabilities from a cloud network to deliver coordinated protection for the ever-expanding attack surface through FortiGate appliance and virtual machine as well as all Fortinet Security Fabric products that are registered by the end-customer.

[0001262039-22-000008:mdna:33]
Our proprietary Security Processing Units (“SPUs”) are Application-Specific Integrated Circuits that are implemented in our physical FortiGate appliances and are designed to enhance the security processing capabilities implemented in software by accelerating computationally intensive tasks such as firewall policy enforcement, software-defined wide-area network (“SD-WAN”), network address translation, Intrusion Prevention Systems (“IPS”), threat detection and encryption. We also provide virtualized Security Processing Units (“vSPUs”) across our FortiGate virtual appliances to deliver similar accelerated capabilities when run in virtualized environments.

[0001262039-22-000008:mdna:34]
Our FortiOS operating system provides the foundation for the operation of all FortiGate network security appliances, whether physical, virtual, private- or public-cloud based. FortiOS directs the operations of processors and SPUs and provides system management functions. We make regular updates to FortiOS available through our FortiCare support services.

[0001262039-22-000008:mdna:35]
FortiOS, its associated security and networking functions and products that run or are integrated with FortiOS are combined to form the Fortinet Security Fabric cybersecurity mesh platform. This approach to security ties discrete security solutions together into an integrated whole that provides centralized management and visibility, automation and intelligence sharing to simplify network and security operations and rapid response to threats.

[0001262039-22-000008:mdna:36]
The focus areas of our business consist of:

[0001262039-22-000008:mdna:37]
•Security-Driven Networking—Our Security-Driven Networking solutions enables the convergence of networking and security across all edges to provide next-generation firewall (“NGFW”), software-defined wide area network (“SD-WAN”), LAN Edge (Wi-Fi and switch) and secure access service edge (“SASE”). We derive a majority of product sales from our FortiGate network security appliances. FortiGate network security appliances include a broad set of built-in security and networking features and functionalities, including firewall, next-generation firewall, secure web gateway, secure sockets layer (“SSL”) inspection, software-defined wide area network (“SD-WAN”), Intrusion Prevention system (“IPS”), sandboxing, data leak prevention, virtual private network (“VPN”), switch and wireless controller and wide area network (“WAN”) edge. Our network security appliances are managed by our FortiOS network operating system, which provides the foundation for FortiGate security functions. We enhance the performance of our network security appliances from branch to data center by designing and implementing Security Processing Units (“SPUs”) technology within our appliances, enabling us to add security and network functionality with minimal impact to network throughput performance. Along with our secure Wi-fi access points and switches, Fortinet helps organizations secure their networks across campuses, branches, and work-from-home deployments.

[0001262039-22-000008:mdna:38]
•Zero Trust Access—The Fortinet Security Fabric cybersecurity mesh platform extends beyond the network to cover other attack vectors. Our Zero Trust Access solutions enable customers to know and control who and what is on their network, in addition to providing security for work from anywhere (“WFA”). Zero Trust Access solutions include FortiNAC, FortiAuthenticator, FortiClient and FortiToken. Additionally, the proliferation of internet of things (“IoT”) and operational technology (“OT”) devices has generated new opportunities for us to grow our business. Our network access control solutions provide visibility, control and automated event responses in order to secure IoT and OT devices.

[0001262039-22-000008:mdna:39]
•Adaptive Cloud Security—We help customers connect securely to and across their individual, hybrid cloud, multi-cloud, and virtualized data center environments by offering security through our virtual firewall and other software products and through integrated capabilities with major cloud platforms. Our public and private cloud security solutions, including virtual appliances and hosted solutions, extend the core capabilities of the Fortinet Security Fabric cybersecurity mesh platform in and across cloud environments, delivering security that follows their applications and data. Our Secure SD-WAN for Multi-Cloud solution automates deployment of an overlay network across different cloud networks and offers visibility, control and centralized management that integrates functionality across multiple cloud environments. Our Cloud Security portfolio also includes securing applications, including email and web. Fortinet cloud security offerings are available for deployment in major public and private cloud environments, including Alibaba Cloud, Amazon Web Services, Google Cloud, IBM Cloud, Microsoft Azure, Oracle Cloud and VMWare Cloud. We also offer managed IPS and web application firewall (“WAF”) rules delivered by FortiGuard Labs as an overlay service to native security offerings offered by Amazon Web Services.

[0001262039-22-000008:mdna:40]
•AI-Driven Security Operations—We develop and provide a range of products and services that enable the security operations center (“SOC”) teams to identify, investigate and remediate potential incidents in which cybercriminals bypass prevention-oriented controls. Given the breadth of the attack surface to monitor, as well as the volume and sophistication of cyber threats, artificial intelligence (“AI”) is a key part of these offerings, which include: FortiGuard and other security subscription services, modern endpoint security with EDR, a range of breach-protection technologies plus our security information and event management (“SIEM”) and security orchestration, automation and response (“SOAR”), all of which can be applied across the entire Fortinet Security Fabric cybersecurity mesh platform. These solutions automatically deliver security intelligence and insights that enable organizations to protect against and respond to threats faster through integration with Fortinet and third-party controls.

[0001262039-22-000008:mdna:41]
•Security as a Service—Our customers purchase our natively integrated FortiGuard security subscription services as an add-on to products and solutions across the Fortinet Security Fabric with the goal of receiving real-time threat intelligence and protection updates. The rich set of FortiGuard services is built from the ground up to provide comprehensive protection for users and applications, including market leading offerings for IPS, Web, video and DNS filtering, AV and cloud sandbox as well as IoT and OT Security. The FortiGuard security services are provided from our FortiGuard Labs and cloud-delivered to provide real-time unified protection across network endpoint and cloud. FortiCare technical support services and the support of technical account managers, resident engineers and professional service consultants for implementations or training services.

[0001262039-22-000008:mdna:42]
•Support and Professional Services – Fortinet offers technical support, FortiOS updates and extended product warranty through our FortiCare support services.  In addition to our technical support services, we offer a range of advanced services, including premium support, professional services and expedited warranty replacement. Our professional service offerings include resident engineers and professional service consultants for implementations or trainings.

[0001262039-22-000008:mdna:43]
Financial Highlights

[0001262039-22-000008:mdna:44]
•Total revenue was $3.34 billion in 2021, an increase of 29% compared to $2.59 billion in 2020. Product revenue was $1.26 billion in 2021, an increase of 37% compared to $916.4 million in 2020. Service revenue was $2.09 billion in 2021, an increase of 24% compared to $1.68 billion in 2020.

[0001262039-22-000008:mdna:45]
•Total gross profit was $2.56 billion in 2021, an increase of 26% compared to $2.02 billion in 2020.

[0001262039-22-000008:mdna:46]
•We generated operating income of $650.4 million in 2021, an increase of 22% compared to $531.8 million in 2020. Operating income for 2021 included gains on an IP matter of $4.6 million.

[0001262039-22-000008:mdna:47]
•Cash, cash equivalents, investments and marketable equity securities were $2.99 billion as of December 31, 2021, an increase of $1.04 billion, or 53%, from December 31, 2020.

[0001262039-22-000008:mdna:48]
•In March 2021, we issued $1.0 billion of Senior Notes. Long-term debt, net of unamortized discount and debt issuance costs, was $988.4 million as of December 31, 2021. There was no such debt outstanding at December 31, 2020.

[0001262039-22-000008:mdna:49]
•In 2021, we repurchased 2.6 million shares of common stock under the Repurchase Program for an aggregate purchase price of $741.8 million. In 2020, we repurchased 11.7 million shares of common stock for a total purchase price of $1.08 billion.

[0001262039-22-000008:mdna:50]
•Deferred revenue was $3.45 billion as of December 31, 2021, an increase of $847.6 million, or 33%, from December 31, 2020. Short-term deferred revenue was $1.78 billion as of December 31, 2021, an increase of $384.6 million, or 28%, from December 31, 2020.

[0001262039-22-000008:mdna:51]
•We generated cash flows from operating activities of $1.50 billion in 2021, an increase of $416.0 million, or 38%, compared to 2020. We received $50.0 million of proceeds from an IP matter in the first quarter of 2020.

[0001262039-22-000008:mdna:52]
•Total bookings were $4.33 billion for 2021, an increase of 40.2% compared to $3.09 billion in 2020. We define bookings as the total value of all orders received during the fiscal period.

[0001262039-22-000008:mdna:53]
•Backlog was $161.9 million as of December 31, 2021, an increase of $149.7 million compared to $12.2 million as of December 31, 2020. Backlog represents orders received but not fulfilled and excludes backlog related to Alaxala Networks Corporation's (“Alaxala”) products and services of $26.0 million.

[0001262039-22-000008:mdna:54]
•On August 31, 2021, we closed an acquisition of 75% of the equity interests in Alaxala, a privately-held network hardware equipment company in Japan, to help broaden our offering of secure switches integrated with FortiGate Firewalls and Security Fabric functionality, and, over time, to innovate and rebrand certain of Alaxala’s switches to offer a broader suite of secure switches globally. From September 1, 2021 to December 31, 2021, Alaxala’s revenue was $44.4 million, or 1.3% of total revenue during the year ended December 31, 2021. During the first quarter of 2021 and subsequently in the third quarter, we made an equity method investment in Linksys which provides router connectivity solutions to the consumer and small business markets.

[0001262039-22-000008:mdna:55]
Our revenue growth was driven by both product and service revenue. On a geographic basis, revenue continues to be diversified globally, which remains a key strength of our business. In 2021, the Americas region, the Europe, Middle East and Africa (“EMEA”) region and the Asia Pacific (“APAC”) region contributed 41%, 38% and 21% of our total revenue, respectively, and increased by 26%, 29% and 35% compared to 2020, respectively.

[0001262039-22-000008:mdna:56]
Product revenue grew 37% in 2021. Product revenue growth was consistent with an elevated cyber threat landscape. FortiGate products accounted for more than half of the product revenue growth in 2021. While Secure SD-WAN contributed to product revenue growth, the main driver was the strong demand for the wide range of other operating system capabilities embedded in the FortiGate products. We experienced strong product revenue growth across many of our security fabric platform products, including our OT solutions, secure access products and software licenses. The impact of the increase in backlog was largely seen in certain fabric platform products. Service revenue growth of 24% in 2021 was driven by the strength

[0001262039-22-000008:mdna:57]
of our FortiGuard and other security subscription revenue and FortiGate technical support and other service revenue, which grew 22% and 27%, respectively, in 2021.

[0001262039-22-000008:mdna:58]
Our billings were diversified on a geographic basis. In 2021, six countries represented approximately 50% of our billings and the remaining 50% in the aggregate were from over 100 countries that individually contributed less than 3% of our billings.

[0001262039-22-000008:mdna:59]
In 2021 and 2020, we recognized gains of $4.6 million and $40.2 million, respectively, on an IP matter in connection with a mutual covenant-no-to-sue and release agreement with a competitor in the network security industry. Excluding the gains on the IP matter, operating expenses as a percentage of revenue decreased by approximately 1.9 percentage points compared to 2020. Headcount increased by 24% to 10,195 employees and contractors as of December 31, 2021, up from 8,238 as of December 31, 2020.

[0001262039-22-000008:mdna:60]
COVID-19 Pandemic Update

[0001262039-22-000008:mdna:61]
The United States and the global community we serve are facing unprecedented challenges posed by the COVID-19 pandemic, including the various COVID-19 variants. In response to the pandemic, we undertook a number of actions to protect our employees, including restricting travel and directing many of our employees to work from home. In certain geographies, we have started to transition back to an in-person working mode, allowing increasing numbers of employees to work from our offices with reasonable precautions and, in all cases, subject to abiding by local legal restrictions. We intend to continue to monitor and abide by local employee health and safety protocols and other regulations as applicable to each local office.

[0001262039-22-000008:mdna:62]
While the broader implications of the COVID-19 pandemic on our employees and overall financial performance continue to evolve, we have seen certain impacts on our business and operations, results of operations, financial condition, cash flows, liquidity and capital and financial resources as of and during the year ended December 31, 2021. Conversely, some aspects of our business do not appear to have been significantly affected. During the year ended December 31, 2021, we have observed the following:

[0001262039-22-000008:mdna:63]
•We have seen supply chain challenges increase, including chip and other component shortages and increased costs for certain chips and other components and shipping, and we do not have enough inventory to promptly meet all demand for all products.

[0001262039-22-000008:mdna:64]
•In most countries, our employees’ ability to travel has been reduced. In-person sales and marketing events or meetings that would normally have been held were canceled, postponed or converted into virtual events. However, as certain country’s restrictions start to ease, we have started to see an increase in expenses related to travel and marketing events. Although we cannot predict if or when such expenses will return to pre-pandemic levels, as of December 31, 2021, we have started to see an increase in such expenses as compared to the same period last year.

[0001262039-22-000008:mdna:65]
•In order to mitigate supply chain disruption and other supply chain risks and in anticipation of future demand, we worked to increase our on-hand stock of certain products. We increased our commitments with certain suppliers to secure capacity, and are meeting regularly with our contract manufacturers and component suppliers to manage future commitments, address component shortages and monitor delivery of finished goods. We have also transitioned primarily to air shipping to avoid port congestion and extended ocean freight time.

[0001262039-22-000008:mdna:66]
•In accordance with the CARES Act, we have deferred the deposit and payment of our employer’s share of Social Security taxes. This did not materially affect net cash provided by operating activities during the period.

[0001262039-22-000008:mdna:67]
Going forward, the situation remains uncertain, rapidly changing and hard to predict, and the COVID-19 pandemic may have a material negative impact on our future periods. If we experience greater component, shipping or inventory challenges than we expect or significant changes in our billings growth rates, it will negatively impact billings and product revenue in the current quarter and FortiGuard and FortiCare service revenues in subsequent quarters, as we sell annual and multi-year service contracts that are recognized ratably over the contractual service term. In addition, the broader implications of the pandemic on our business and operations and our financial results, including the extent to which the effects of the pandemic will impact future results and growth in the cybersecurity industry, remain uncertain. The extent of the impact of the COVID-19 pandemic on our operational and financial performance will depend on ongoing developments, including the duration and spread of the virus and its variants, the impact on our end-customers’ spending, the volume of sales and length of our sales cycles, the impact on our partners, suppliers, and employees, actions that may be taken by governmental authorities and other factors identified in Part I, Item 1A “Risk Factors” in this Form 10-K. Given the dynamic nature of these circumstances, the full impact of the COVID-19 pandemic on our business and operations, results of operations, financial condition, cash flows, liquidity and capital and financial resources cannot be reasonably estimated at this time.

[0001262039-22-000008:mdna:68]
Business Model

[0001262039-22-000008:mdna:69]
We typically sell our security solutions to distributors that sell to networking security focused resellers and to service providers and managed security service providers (“MSSPs”), who, in turn, sell to end-customers or use our products and services to provided hosted solutions to other enterprises. At times, we also sell directly to large service providers and major systems integrators. Our end-customers are located in over 100 countries and include small, medium and large enterprises and government organizations across a wide range of industries, including telecommunications, government, financial services, retail, technology, education, manufacturing and healthcare. An end-customer deployment may involve as few as one or as many as thousands of appliances and other Fortinet Security Fabric cybersecurity mesh platform products, depending on the end-customer’s size and security requirements.

[0001262039-22-000008:mdna:70]
We also offer our products hosted in our own data centers and through major cloud providers, and have recognized revenue on a usage basis from Alibaba Cloud, Amazon Web Services, Google Cloud, IBM Cloud, Microsoft Azure and Oracle Cloud. We have also recognized revenue from customers who deploy our products in a bring-your-own-license (“BYOL”) arrangement in private clouds or at cloud providers. In a BYOL arrangement, a customer purchases a software license from us through our channel partners and deploys the software in a cloud provider’s environment. Similarly, customers may purchase such a license from us and deploy in third-party clouds or in their private cloud.

[0001262039-22-000008:mdna:71]
Our customers purchase our hardware products and software licenses, as well as our FortiGuard and other security subscription and FortiCare technical support services. We generally invoice at the time of our sale for the total price of the products and security and technical support services. Standard payment terms are generally no more than 60 days, though we continue to offer extended payment terms to certain distributors.

[0001262039-22-000008:mdna:72]
Key Metrics

[0001262039-22-000008:mdna:73]
We monitor a number of key metrics, including the key financial metrics set forth below, in order to help us evaluate growth trends, establish budgets, measure the effectiveness of our sales and marketing efforts, and assess operational efficiencies. The following table summarizes revenue, deferred revenue, billings (non-GAAP), net cash provided by operating activities, and free cash flow (non-GAAP). We discuss revenue below under “—Components of Operating Results,” and we discuss net cash provided by operating activities below under “—Liquidity and Capital Resources.” Deferred revenue, billings (non-GAAP), and free cash flow (non-GAAP) are discussed immediately below the following table.

[0001262039-22-000008:mdna:74]
|  | Year Ended or As of December 31, |
|  | 2021 |  | 2020 |  | 2019 |
|  | (in millions) |
| Revenue | $ | 3,342.2 |  |  | $ | 2,594.4 |  |  | $ | 2,163.0 |  |
| Deferred revenue | $ | 3,452.9 |  |  | $ | 2,605.3 |  |  | $ | 2,109.1 |  |
| Billings (non-GAAP) | $ | 4,181.4 |  |  | $ | 3,090.0 |  |  | $ | 2,602.9 |  |
| Net cash provided by operating activities | $ | 1,499.7 |  |  | $ | 1,083.7 |  |  | $ | 808.0 |  |
| Free cash flow (non-GAAP) | $ | 1,203.8 |  |  | $ | 907.8 |  |  | $ | 715.8 |  |

[0001262039-22-000008:mdna:75]
Deferred revenue. Our deferred revenue consists of amounts that have been invoiced but that have not yet been recognized as revenue. The majority of our deferred revenue balance consists of the unrecognized portion of service revenue from FortiGuard and other security subscription and FortiCare technical support service contracts, which is recognized as revenue ratably over the contractual service period. We monitor our deferred revenue balance, deferred revenue growth and the mix of short-term and long-term deferred revenue because deferred revenue represents a significant portion of free cash flow and of revenue to be recognized in future periods. Deferred revenue was $3.45 billion as of December 31, 2021, an increase of $847.6 million, or 33%, from December 31, 2020.

[0001262039-22-000008:mdna:76]
Billings (non-GAAP). We define billings as revenue recognized in accordance with generally accepted accounting principles in the United States (“GAAP”) plus the change in deferred revenue from the beginning to the end of the period, less any deferred revenue balances acquired from business combination(s) and an adjustment due to adoption of Accounting Standards Update (“ASU”) 2021-08 during the period. We consider billings to be a useful metric for management and investors because billings drive current and future revenue, which is an important indicator of the health and viability of our business. There are a number of limitations related to the use of billings instead of GAAP revenue. First, billings include amounts that have not yet been recognized as revenue and are impacted by the term of FortiGuard security and FortiCare support agreements. Second, we may calculate billings in a manner that is different from peer companies that report similar financial measures. Management accounts for these limitations by providing specific information regarding GAAP revenue and evaluating billings together with GAAP revenue. Total billings were $4.18 billion for 2021, an increase of 35% compared to $3.09 billion in 2020.

[0001262039-22-000008:mdna:77]
A reconciliation of revenue, the most directly comparable financial measure calculated and presented in accordance with GAAP, to billings is provided below:

[0001262039-22-000008:mdna:78]
|  | Year Ended December 31, |
| 2021 |  | 2020 |  | 2019 |
| (in millions) |
| Billings: |  |  |  |  |  |
| Revenue | $ | 3,342.2 |  |  | $ | 2,594.4 |  |  | $ | 2,163.0 |  |
| Add: Change in deferred revenue | 847.6 |  |  | 496.2 |  |  | 442.3 |  |
| Less: Deferred revenue balance acquired in business combinations | (4.1) |  |  | (0.6) |  |  | (2.4) |  |
| Less: Adjustment due to adoption of ASU 2021-08 | (4.3) |  |  | — |  |  | — |  |
| Total billings (non-GAAP) | $ | 4,181.4 |  |  | $ | 3,090.0 |  |  | $ | 2,602.9 |  |

[0001262039-22-000008:mdna:79]
Free cash flow (non-GAAP). We define free cash flow as net cash provided by operating activities minus purchases of property and equipment and excluding any significant non-recurring items. We believe free cash flow to be a liquidity measure that provides useful information to management and investors about the amount of cash generated by the business that, after capital expenditures, can be used for strategic opportunities, including repurchasing outstanding common stock, investing in our business, making strategic acquisitions and strengthening the balance sheet. A limitation of using free cash flow rather than the GAAP measures of cash provided by or used in operating activities, investing activities, and financing activities is that free cash flow does not represent the total increase or decrease in the cash and cash equivalents balance for the period because it excludes cash flows from investing activities other than capital expenditures and cash flows from financing activities. Management accounts for this limitation by providing information about our capital expenditures and other investing and financing activities on the face of the consolidated statements of cash flows and under “—Liquidity and Capital Resources” and by presenting cash flows from investing and financing activities in our reconciliation of free cash flow. In addition, it is important to note that other companies, including companies in our industry, may not use free cash flow, may calculate free cash flow in a different manner than we do or may use other financial measures to evaluate their performance, all of which could reduce the usefulness of free cash flow as a comparative measure. A reconciliation of net cash provided by operating activities, the most directly comparable financial measure calculated and presented in accordance with GAAP, to free cash flow is provided below:

[0001262039-22-000008:mdna:80]
|  | Year Ended December 31, |
| 2021 |  | 2020 |  | 2019 |
| (in millions) |
| Free Cash Flow: |  |  |  |  |  |
| Net cash provided by operating activities | $ | 1,499.7 |  |  | $ | 1,083.7 |  |  | $ | 808.0 |  |
| Less: Purchases of property and equipment | (295.9) |  |  | (125.9) |  |  | (92.2) |  |
| Less: Proceeds from intellectual property matter | — |  |  | (50.0) |  |  | — |  |
| Free cash flow (non-GAAP) | $ | 1,203.8 |  |  | $ | 907.8 |  |  | $ | 715.8 |  |
| Net cash used in investing activities | $ | (1,325.1) |  |  | $ | (72.8) |  |  | $ | (502.3) |  |
| Net cash provided by (used in) financing activities | $ | 82.8 |  |  | $ | (1,171.6) |  |  | $ | (195.6) |  |

[0001262039-22-000008:mdna:81]
Components of Operating Results

[0001262039-22-000008:mdna:82]
Revenue. We generate the majority of our revenue from sales of our hardware and software products and amortization of amounts included in deferred revenue related to previous sales of FortiGuard security subscription and FortiCare technical support services. We also recognize revenue from cloud security solutions, professional services and training.

[0001262039-22-000008:mdna:83]
Our total revenue is comprised of the following:

[0001262039-22-000008:mdna:84]
•Product revenue. Product revenue is primarily generated from sales of our physical and virtual machine appliances. The majority of our product revenue continues to be generated by our FortiGate product line. Product revenue also includes revenue derived from sales of Fabric appliance and software products. As a percentage of total revenue, our product revenue has varied from quarter to quarter.

[0001262039-22-000008:mdna:85]
•Service revenue. Service revenue is generated primarily from FortiGuard security subscription services and FortiCare technical support services. We recognize revenue from FortiGuard security subscription and

[0001262039-22-000008:mdna:86]
FortiCare technical support services over the contractual service period. Our typical contractual support and subscription term is one to five years. We also generate a small portion of our revenue from other services, for which we recognize revenue as the services are provided, and cloud-based services, for which we recognize revenue as the services are delivered or on a monthly usage basis. As a percentage of total revenue, we continue to expect service revenue to be higher than product revenue. Our service revenue growth rate depends significantly on the growth of our customer base, the expansion of our service bundle offerings, the expansion and introduction of new service offerings, the attach rate of service contracts to new product sales, and the renewal of service contracts by our existing customers.

[0001262039-22-000008:mdna:87]
Our total cost of revenue is comprised of the following:

[0001262039-22-000008:mdna:88]
•Cost of product revenue. The majority of the cost of product revenue consists of third-party contract manufacturers’ costs and the costs of materials used in production. Our cost of product revenue also includes supplies, shipping costs, personnel costs associated with logistics and quality control, facility-related costs, excess and obsolete inventory costs, warranty costs and amortization of intangible assets. Personnel costs include direct compensation benefits and stock based compensation.

[0001262039-22-000008:mdna:89]
•Cost of service revenue. Cost of service revenue is primarily comprised of personnel costs, third-party repair and contract fulfillment, data center costs, colocation expenses and cloud hosting, supplies and facility-related costs.

[0001262039-22-000008:mdna:90]
Gross margin. Gross profit as a percentage of revenue, or gross margin, has been and will continue to be affected by a variety of factors, including the average sales price of our products, product costs, the mix of products sold and the mix of revenue between hardware products, software licenses and services and any excess inventory write-offs. Service revenue and software licenses have had a positive effect on our total gross margin given the higher gross margins compared to hardware product gross margins. During 2021, product gross margin benefited from gains in average selling price, as well as lower direct and indirect product costs as a percentage of product revenue. It also benefited from product mix, software revenue growth and a stable product transition environment. Service gross margin benefited from renewals and continued sales of services and subscriptions, growing faster than related expenses. Overall gross margin in 2022 will be impacted by service and product revenue mix.

[0001262039-22-000008:mdna:91]
Operating expenses. Our operating expenses consist of research and development, sales and marketing and general and administrative expenses. Personnel costs are the most significant component of operating expenses and consist primarily of salaries, benefits, bonuses, sales commission and stock-based compensation. We expect personnel costs to continue to increase in absolute dollars as we expand our workforce.

[0001262039-22-000008:mdna:92]
•Research and development. Research and development expense consists primarily of personnel costs. Additional research and development expenses include ASIC and system prototypes and certification-related expenses, depreciation of property and equipment and facility-related expenses. The majority of our research and development is focused on software development and the ongoing development of our hardware products. We record research and development expenses as incurred. As of December 31, 2021, approximately 88% of our research and development teams were located in Canada, the United States and India.

[0001262039-22-000008:mdna:93]
•Sales and marketing. Sales and marketing expense is the largest component of our operating expenses and primarily consists of personnel costs. Additional sales and marketing expenses include product marketing, public relations, field marketing and channel marketing programs (e.g. partner cooperative marketing arrangements), as well as travel, depreciation of property and equipment and facility-related expenses. We intend to hire additional personnel focused on sales and marketing and expand our sales and marketing efforts worldwide in order to capture market share.

[0001262039-22-000008:mdna:94]
•General and administrative. General and administrative expense consists of personnel costs, as well as professional fees, depreciation of property and equipment and software and facility-related expenses. General and administrative personnel include our executive, finance, human resources, information technology and legal organizations. Our professional fees principally consist of outside legal, auditing, tax, information technology and other consulting costs.

[0001262039-22-000008:mdna:95]
•Gain on intellectual property matter. Gain on intellectual property matter consists of the amortization of the deferred component of an agreement with a competitor in the network security industry, whereby, the

[0001262039-22-000008:mdna:96]
competitor party paid us a lump sum of $50.0 million for a seven-year mutual covenant-not-to-sue for patent claims.

[0001262039-22-000008:mdna:97]
Interest income—net. Interest income—net consists primarily of interest earned on our cash equivalents and investments. Historically, our investments include corporate debt securities, certificates of deposit and term deposits, commercial paper, money market funds, and U.S. government and agency securities.

[0001262039-22-000008:mdna:98]
Other expense—net. Other expense—net consists primarily of foreign exchange gains and losses related to foreign currency remeasurement, gains or losses due to the changes in fair value of our marketable equity securities, as well as the gain on the sale or the impairment charges of our investments in privately held companies.

[0001262039-22-000008:mdna:99]
Provision for income taxes. We are subject to income taxes in the United States, as well as other tax jurisdictions or countries in which we conduct business. Earnings from our non-U.S. activities are subject to income taxes in local countries and may be subject to U.S. income taxes. Our effective tax rate differs from the U.S. statutory rate primarily due to foreign income subject to different tax rates than in the U.S., nondeductible stock-based compensation expense, federal research and development tax credit, state taxes, withholding taxes, excess tax benefits related to stock-based compensation expense and the tax impacts of the 2017 Tax Cuts and Jobs Act (the “2017 Tax Act”), including the foreign-derived intangible income (“FDII”) deduction.

[0001262039-22-000008:mdna:100]
Critical Accounting Policies and Estimates

[0001262039-22-000008:mdna:101]
Our discussion and analysis of our financial condition and results of operations are based upon our financial statements, which have been prepared in accordance with GAAP. These principles require us to make estimates and judgments that affect the reported amounts of assets, liabilities, revenue, cost of revenue and expenses, and related disclosures. We base our estimates on historical experience and on various other assumptions that we believe to be reasonable under the circumstances. To the extent that there are material differences between these estimates and our actual results, our future financial statements will be affected.

[0001262039-22-000008:mdna:102]
We believe that, of the significant accounting policies described in Note 1 to our consolidated financial statements included in Part II, Item 8 of this Annual Report on Form 10-K, the following accounting policies involve a greater degree of judgment and complexity. Accordingly, we believe these are the most critical to fully understand and evaluate our financial condition and results of operations.

[0001262039-22-000008:mdna:103]
Revenue Recognition

[0001262039-22-000008:mdna:104]
Revenues are recognized when control of goods or services is transferred to our customers, in an amount that reflects the consideration we expect to be entitled to in exchange for those goods or services.

[0001262039-22-000008:mdna:105]
We determine revenue recognition through the following steps:

[0001262039-22-000008:mdna:106]
•identification of a contract or contracts with a customer;

[0001262039-22-000008:mdna:107]
•identification of the performance obligations in a contract, including evaluation of performance obligations as to being distinct goods or services in a contract;

[0001262039-22-000008:mdna:108]
•determination of a transaction price;

[0001262039-22-000008:mdna:109]
•allocation of a transaction price to the performance obligations in a contract; and

[0001262039-22-000008:mdna:110]
•recognition of revenue when, or as, we satisfy a performance obligation.

[0001262039-22-000008:mdna:111]
Our sales contracts typically contain multiple deliverables, such as hardware, software license, security subscription, technical support services and other services, which are generally capable of being distinct and accounted for as separate performance obligations. Our hardware and software licenses have significant standalone functionalities and capabilities. Accordingly, the hardware and software licenses are distinct from the security subscription and technical support services, as a customer can benefit from the product without the services and the services are separately identifiable within a contract. We allocate a transaction price to each performance obligation based on relative standalone selling price. We establish standalone selling price using the prices charged for a deliverable when sold separately. If not observable through past transactions, we determine standalone selling price by considering multiple historical factors including, but not limited to, cost of products, gross margin objectives, pricing practices, geographies and the term of a service contract.

[0001262039-22-000008:mdna:112]
57

[0001262039-22-000008:mdna:113]
Deferred Contract Costs and Commission Expense

[0001262039-22-000008:mdna:114]
We defer contract costs that are recoverable and incremental to obtaining customer sales contracts. Contract costs, which primarily consist of sales commissions, are amortized on a systematic basis that is consistent with the transfer to the customer of the goods or services to which the asset relates. Costs for initial contracts that are not commensurate with commissions on renewal contracts are amortized on a straight-line basis over the period of benefit of five years. Estimates, assumptions, and judgments in accounting for deferred contract costs include, but are not limited to, identification of contract costs, anticipated billings and the expected period of benefit.

[0001262039-22-000008:mdna:115]
Business Combinations

[0001262039-22-000008:mdna:116]
We include the results of operations of the businesses that we acquire as of the respective dates of acquisition. We allocate the fair value of the purchase price of our business acquisitions to the tangible and intangible assets acquired and liabilities assumed based on their estimated fair values. The excess of the purchase price over the fair values of these identifiable assets and liabilities is recorded as goodwill. We often continue to gather additional information throughout the measurement period, and if we make changes to the amounts recorded, such changes are recorded in the period in which they are identified.

[0001262039-22-000008:mdna:117]
Contingent Liabilities

[0001262039-22-000008:mdna:118]
From time to time, we are involved in disputes, litigation and other legal actions. However, there are many uncertainties associated with any litigation, and these actions or other third-party claims against us may cause us to incur substantial settlement charges, which are inherently difficult to estimate and could adversely affect our results of operations. We periodically review significant claims and litigation matters for the probability of an adverse outcome. We accrue for a loss contingency if a loss is probable and the amount of the loss can be reasonably estimated. These accruals are generally based on a range of possible outcomes that require significant judgement. Estimates can change as individual claims develop. The actual liability in any such matters may be materially different from our estimates, which could result in the need to adjust our liability and record additional expenses.

[0001262039-22-000008:mdna:119]
Accounting for Income Taxes

[0001262039-22-000008:mdna:120]
We record income taxes using the asset and liability method, which requires the recognition of deferred tax assets and liabilities for the expected future tax consequences of events that have been recognized in our financial statements or tax returns. In addition, deferred tax assets are recorded for the future benefit of utilizing net operating losses and research and development credit carryforwards. Deferred tax assets and liabilities are measured using the currently enacted tax rates that apply to taxable income in effect for the years in which those tax assets and liabilities are expected to be realized or settled. Valuation allowances are provided when necessary to reduce deferred tax assets to the amount expected to be realized.

[0001262039-22-000008:mdna:121]
As part of the process of preparing our consolidated financial statements, we are required to estimate our taxes in each of the jurisdictions in which we operate. We estimate actual current tax exposure together with assessing temporary differences resulting from differing treatment of items, such as accruals and allowances not currently deductible for tax purposes. These differences result in deferred tax assets, which are included in our consolidated balance sheets. In general, deferred tax assets represent future tax benefits to be received when certain expenses previously recognized in our consolidated statements of income become deductible expenses under applicable income tax laws, or loss or credit carryforwards are utilized.

[0001262039-22-000008:mdna:122]
In assessing the realizability of deferred tax assets, management considers whether it is more likely than not that some portion or all of the deferred tax assets will be realized. The ultimate realization of deferred tax assets is dependent upon the generation of future taxable income during the periods in which those temporary differences become deductible. We continue to assess the need for a valuation allowance on the deferred tax assets by evaluating both positive and negative evidence that may exist. Any adjustment to the valuation allowance on deferred tax assets would be recorded in the consolidated statements of income for the period that the adjustment is determined to be required.

[0001262039-22-000008:mdna:123]
We recognize tax benefits from an uncertain tax position only if it is more likely than not, based on the technical merits of the position that the tax position will be sustained on examination by the tax authorities. The tax benefits recognized in the financial statements from such positions are then measured based on the largest benefit that has a greater than 50% likelihood of being realized upon ultimate settlement.

[0001262039-22-000008:mdna:124]
We have elected to account for Global Intangible Low-Taxed Income (“GILTI”), which was introduced in the 2017 Tax Act, as a current period expense.

[0001262039-22-000008:mdna:125]
58

[0001262039-22-000008:mdna:126]
Investments in privately held companies

[0001262039-22-000008:mdna:127]
Our investments in privately held companies primarily consist of investments in common stock or in-substance common stock of entities that provide us with the ability to exercise significant influence over the operating and financial policies of the investee, but not an absolute controlling financial interest, and are accounted for under the equity method of accounting. Determining that we do not control but exercise significant influence over the operating and financial policies of the investee requires significant judgement when considering many factors, including but not limited to, the ownership interest in the investee, board representation, participation in policy-making processes, and participation rights in certain significant financial and operating decisions of the investee in the ordinary course of business. Our investment in Linksys is our only equity method investment. We record our proportionate share of the net earnings or losses of Linksys based on the most recently available financial statements of Linksys, which are provided to us on a three-month lag, and our share of the amortization of any basis differences, in gain or loss from equity method investment in our consolidated statements of income.

[0001262039-22-000008:mdna:128]
Results of Operations

[0001262039-22-000008:mdna:129]
The following tables set forth our results of operations for the periods presented and as a percentage of our total revenue for those periods. The period-to-period comparison of financial results is not necessarily indicative of financial results to be achieved in future periods.

[0001262039-22-000008:mdna:130]
|  | Year Ended December 31, |
|  | 2021 |  | 2020 |  | 2019 |
|  | (in millions) |
| Consolidated Statements of Income Data: |  |  |  |  |  |
| Revenue: |  |  |  |  |  |
| Product | $ | 1,255.0 |  |  | $ | 916.4 |  |  | $ | 788.5 |  |
| Service | 2,087.2 |  |  | 1,678.0 |  |  | 1,374.5 |  |
| Total revenue | 3,342.2 |  |  | 2,594.4 |  |  | 2,163.0 |  |
| Cost of revenue: |  |  |  |  |  |
| Product | 487.7 |  |  | 352.4 |  |  | 324.6 |  |
| Service | 295.3 |  |  | 217.6 |  |  | 181.3 |  |
| Total cost of revenue | 783.0 |  |  | 570.0 |  |  | 505.9 |  |
| Gross profit: |  |  |  |  |  |
| Product | 767.3 |  |  | 564.0 |  |  | 463.9 |  |
| Service | 1,791.9 |  |  | 1,460.4 |  |  | 1,193.2 |  |
| Total gross profit | 2,559.2 |  |  | 2,024.4 |  |  | 1,657.1 |  |
| Operating expenses: |  |  |  |  |  |
| Research and development | 424.2 |  |  | 341.4 |  |  | 277.1 |  |
| Sales and marketing | 1,345.7 |  |  | 1,071.9 |  |  | 926.9 |  |
| General and administrative | 143.5 |  |  | 119.5 |  |  | 102.1 |  |
| Gain on intellectual property matter | (4.6) |  |  | (40.2) |  |  | — |  |
| Total operating expenses | 1,908.8 |  |  | 1,492.6 |  |  | 1,306.1 |  |
| Operating income | 650.4 |  |  | 531.8 |  |  | 351.0 |  |
| Interest income | 4.5 |  |  | 17.7 |  |  | 42.5 |  |
| Interest expense | (14.9) |  |  | — |  |  | — |  |
| Other expense—net | (11.6) |  |  | (7.8) |  |  | (7.5) |  |
| Income before income taxes and loss from equity method investment | 628.4 |  |  | 541.7 |  |  | 386.0 |  |
| Provision for income taxes | 14.1 |  |  | 53.2 |  |  | 54.3 |  |
| Loss from equity method investment | (7.6) |  |  | — |  |  | — |  |
| Net income including non-controlling interests | 606.7 |  |  | 488.5 |  |  | 331.7 |  |
| Less: net loss attributable to non-controlling interests, net of tax | (0.1) |  |  | — |  |  | — |  |
| Net income attributable to Fortinet, Inc. | $ | 606.8 |  |  | $ | 488.5 |  |  | $ | 331.7 |  |

[0001262039-22-000008:mdna:131]
59

[0001262039-22-000008:mdna:132]
|  | Year Ended December 31, |
| 2021 |  | 2020 |  | 2019 |
| (as percentage of revenue) |
| Revenue: |  |  |  |  |  |
| Product | 38 | % |  | 35 | % |  | 36 | % |
| Service | 62 |  |  | 65 |  |  | 64 |  |
| Total revenue | 100 |  |  | 100 |  |  | 100 |  |
| Cost of revenue: |  |  |  |  |  |
| Product | 15 |  |  | 14 |  |  | 15 |  |
| Service | 9 |  |  | 8 |  |  | 8 |  |
| Total cost of revenue | 23 |  |  | 22 |  |  | 23 |  |
| Gross margin: |  |  |  |  |  |
| Product | 61 |  |  | 62 |  |  | 59 |  |
| Service | 86 |  |  | 87 |  |  | 87 |  |
| Total gross margin | 77 |  |  | 78 |  |  | 77 |  |
| Operating expenses: |  |  |  |  |  |
| Research and development | 13 |  |  | 13 |  |  | 13 |  |
| Sales and marketing | 40 |  |  | 41 |  |  | 43 |  |
| General and administrative | 4 |  |  | 5 |  |  | 5 |  |
| Gain on intellectual property matter | — |  |  | (2) |  |  | — |  |
| Total operating expenses | 57 |  |  | 58 |  |  | 60 |  |
| Operating margin | 19 |  |  | 20 |  |  | 16 |  |
| Interest income | — |  |  | 1 |  |  | 2 |  |
| Interest expense | — |  |  | — |  |  | — |  |
| Other expense—net | — |  |  | — |  |  | — |  |
| Income before income taxes and loss from equity method investment | 19 |  |  | 21 |  |  | 18 |  |
| Provision for income taxes | — |  |  | 2 |  |  | 3 |  |
| Loss from equity method investment | — |  |  | — |  |  | — |  |
| Net income including non-controlling interests | 18 |  |  | 19 |  |  | 15 |  |
| Less: net loss attributable to non-controlling interests, net of tax | — |  |  | — |  |  | — |  |
| Net income attributable to Fortinet, Inc. | 18 | % |  | 19 | % |  | 15 | % |
| Percentages have been rounded for presentation purposes and may differ from unrounded results. |

[0001262039-22-000008:mdna:133]
Discussion regarding our financial condition and results of operations for 2020 as compared to 2019 can be found in Item 7 of our Annual Report on Form 10-K for the fiscal year ended December 31, 2020, filed with the SEC on February 19, 2021.

[0001262039-22-000008:mdna:134]
60

[0001262039-22-000008:mdna:135]
2021 and 2020

[0001262039-22-000008:mdna:136]
Revenue

[0001262039-22-000008:mdna:137]
|  | Year Ended December 31, |  |  |  |  |
| 2021 |  | 2020 |  |  |  |  |
| Amount |  | % ofRevenue |  | Amount |  | % ofRevenue |  | Change |  | % Change |
| (in millions, except percentages) |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 1,255.0 |  |  | 38 | % |  | $ | 916.4 |  |  | 35 | % |  | $ | 338.6 |  |  | 37 | % |
| Service | 2,087.2 |  |  | 62 |  |  | 1,678.0 |  |  | 65 |  |  | 409.2 |  |  | 24 |  |
| Total revenue | $ | 3,342.2 |  |  | 100 | % |  | $ | 2,594.4 |  |  | 100 | % |  | $ | 747.8 |  |  | 29 | % |
| Revenue by geography: |  |  |  |  |  |  |  |  |  |  |  |
| Americas | $ | 1,358.8 |  |  | 41 | % |  | $ | 1,077.2 |  |  | 42 | % |  | $ | 281.6 |  |  | 26 | % |
| EMEA | 1,275.9 |  |  | 38 |  |  | 991.9 |  |  | 38 |  |  | 284.0 |  |  | 29 |  |
| APAC | 707.5 |  |  | 21 |  |  | 525.3 |  |  | 20 |  |  | 182.2 |  |  | 35 |  |
| Total revenue | $ | 3,342.2 |  |  | 100 | % |  | $ | 2,594.4 |  |  | 100 | % |  | $ | 747.8 |  |  | 29 | % |

[0001262039-22-000008:mdna:138]
Total revenue increased by $747.8 million, or 29%, in 2021 compared to 2020. We continued to experience diversification of revenue globally, and across both customer and industry segments. Revenue from all regions grew, with EMEA contributing the largest portion of the increase on an absolute dollar basis and APAC, which included Alaxala, contributing the fastest growth on a percentage basis.

[0001262039-22-000008:mdna:139]
Product revenue increased by $338.6 million, or 37%, in 2021 compared to 2020. We experienced revenue growth across many of our products due to an increase in product revenue from our FortiGate products and security fabric platform products, including our SD-WAN solutions, and software licenses.

[0001262039-22-000008:mdna:140]
Service revenue increased by $409.2 million, or 24%, in 2021 compared to 2020. FortiGuard security subscription, FortiCare technical support and other revenues increased by $206.3 million, or 22%, and $202.9 million, or 27%, respectively, in 2021 compared to 2020. The increases were primarily due to the recognition of revenue from our growing deferred revenue balance related to FortiGuard and other security subscriptions and FortiCare technical support, including our customers moving to higher-tier support offerings as well as growth from our service bundles and professional services.

[0001262039-22-000008:mdna:141]
Of the service revenue recognized in 2021, 65% was included in the deferred revenue balance as of December 31, 2020. Of the service revenue recognized in 2020, 68% was included in the deferred revenue balance as of December 31, 2019.

[0001262039-22-000008:mdna:142]
Cost of revenue and gross margin

[0001262039-22-000008:mdna:143]
|  | Year Ended December 31, |  |  |  |  |
| 2021 |  | 2020 |  | Change |  | % Change |
| (in millions, except percentages) |
| Cost of revenue: |  |  |  |  |  |  |  |
| Product | $ | 487.7 |  |  | $ | 352.4 |  |  | $ | 135.3 |  |  | 38 | % |
| Service | 295.3 |  |  | 217.6 |  |  | 77.7 |  |  | 36 |  |
| Total cost of revenue | $ | 783.0 |  |  | $ | 570.0 |  |  | $ | 213.0 |  |  | 37 | % |
| Gross margin (%): |  |  |  |  |  |  |  |
| Product | 61.1 | % |  | 61.5 | % |  |  |  |  |
| Service | 85.9 | % |  | 87.0 | % |  |  |  |  |
| Total gross margin | 76.6 | % |  | 78.0 | % |  |  |  |  |

[0001262039-22-000008:mdna:144]
Total gross margin decreased by 1.4 percentage points in 2021 compared to 2020, driven by shift in the revenue mix to lower margin product revenue from higher margin service revenue. As a percentage of total revenue, the revenue mix shifted by 2.3 percentage points to product revenue from service revenue.

[0001262039-22-000008:mdna:145]
61

[0001262039-22-000008:mdna:146]
Product gross margin decreased by 0.4 percentage points in 2021 compared to 2020, driven by higher component costs related to supply constraints, higher freight costs, and the impact of Alaxala’s product gross margin. Cost of product revenue was comprised primarily of third-party contract manufacturers’ costs and the costs of materials used in production.

[0001262039-22-000008:mdna:147]
Service gross margin decreased by 1.1 percentage points in 2021 compared to 2020. Cost of service revenue was comprised primarily of personnel costs, third-party repair and contract fulfillment, data center costs, colocation expenses, and cloud hosting, supplies and facility-related costs. The decrease in service gross margin was primarily due to foreign currency fluctuation, increased costs associated with an expansion in our data centers and the impact of Alaxala’s service gross margin.

[0001262039-22-000008:mdna:148]
Operating expenses

[0001262039-22-000008:mdna:149]
|  | Year Ended December 31, |  | Change |  | % Change |
| 2021 |  | 2020 |  |
| Amount |  | % ofRevenue |  | Amount |  | % ofRevenue |  |
| (in millions, except percentages) |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | $ | 424.2 |  |  | 13 | % |  | $ | 341.4 |  |  | 13 | % |  | $ | 82.8 |  |  | 24 | % |
| Sales and marketing | 1,345.7 |  |  | 40 |  |  | 1,071.9 |  |  | 41 |  |  | 273.8 |  |  | 26 |  |
| General and administrative | 143.5 |  |  | 4 |  |  | 119.5 |  |  | 5 |  |  | 24.0 |  |  | 20 |  |
| Gain on intellectual property matter | (4.6) |  |  | — |  |  | (40.2) |  |  | (2) |  |  | 35.6 |  |  | (89) |  |
| Total operating expenses | $ | 1,908.8 |  |  | 57 | % |  | $ | 1,492.6 |  |  | 58 | % |  | $ | 416.2 |  |  | 28 | % |
| Percentages have been rounded for presentation purposes and may differ from unrounded results. |

[0001262039-22-000008:mdna:150]
Research and development

[0001262039-22-000008:mdna:151]
Research and development expense increased by $82.8 million, or 24%, in 2021 compared to 2020, primarily due to an increase in personnel-related costs of $69.5 million as a result of increased headcount to support the development of new products and continued enhancements to our existing products and foreign currency fluctuations. In addition, we incurred increases in depreciation and other occupancy costs of $8.4 million and third party product development costs of $8.3 million, such as third-party testing and prototypes, partially offset by a decrease in other costs of $3.6 million. We currently intend to continue to invest in our research and development organization, and expect research and development expense to increase in absolute dollars in 2022.

[0001262039-22-000008:mdna:152]
Sales and marketing

[0001262039-22-000008:mdna:153]
Sales and marketing expense increased by $273.8 million, or 26%, in 2021 compared to 2020, primarily due to an increase in personnel-related costs of $213.7 million as a result of increases to sales and marketing headcount in order to drive global market revenue increases and foreign currency fluctuations. Marketing related expenses increased $32.9 million and included expenses related to our sponsorship of the Fortinet Championship, a Professional Golfers’ Association tour event that we sponsored in September 2021. In addition, we incurred increases in depreciation and other occupancy expense of $9.4 million, marketing supplies expense of $5.8 million and travel expense of $5.2 million. We currently intend to continue to make investments in sales and marketing resources, which are critical to support our future growth, and expect sales and marketing expense to increase in absolute dollars in 2022.

[0001262039-22-000008:mdna:154]
General and administrative

[0001262039-22-000008:mdna:155]
General and administrative expense increased by $24.0 million, or 20%, in 2021 compared to 2020, primarily due to an increase in personnel-related costs of $12.8 million. Legal-related costs increased by $6.3 million and included $5.6 million related to the settlement and dismissal of an existing patent infringement lawsuit and a mutual covenant-not-to-sue for a defined duration of time. Refer to Note 13. Commitments and contingencies in Part II, Item 8 of this Annual Report on Form 10-K for additional information. In addition, professional services fee increased by $5.2 million, partially offset by a decrease in provision for expected credit losses of $2.0 million. We currently expect general and administrative expense to increase in absolute dollars in 2022.

[0001262039-22-000008:mdna:156]
62

[0001262039-22-000008:mdna:157]
Gain on IP matter

[0001262039-22-000008:mdna:158]
In January 2020, we entered into an agreement with a competitor in the network security industry, whereby, in February 2020, the competitor party paid us a lump sum of $50.0 million for a mutual covenant-not-to-sue for patent claims. Of this amount, we recorded a $4.6 million gain on intellectual property matter in our consolidated statements of income in 2021, compared to $40.2 million in 2020. Refer to Note 12 of the notes to consolidated financial statements included in Part II, Item 8 of this Annual Report on Form 10-K for additional information regarding the gain on IP matter.

[0001262039-22-000008:mdna:159]
Operating income and margin

[0001262039-22-000008:mdna:160]
We generated operating income of $650.4 million in 2021, an increase of $118.6 million, or 22%, compared to $531.8 million in 2020. Operating income as a percentage of revenue decreased to 19% in 2021 compared to 20% in 2020. We recorded a $4.6 million gain on intellectual property matter in our consolidated statements of income in 2021, compared to a $40.2 million gain in 2020, which increased our operating margin by 1.5 percentage points in 2020. Excluding the impact of these gains, our operating margin increased 0.4 percentage points primarily due to 1.0 percentage point, 0.5 percentage point and 0.3 percentage point decreases in sales and marketing expense, research and development expense and general and administrative expense as percentage of revenue, respectively, partially offset by a decrease in gross margin largely driven by the mix shift from service revenue to product revenue.

[0001262039-22-000008:mdna:161]
Interest income, interest expense and other expense—net

[0001262039-22-000008:mdna:162]
|  | Year Ended December 31, |  |  |  |  |
| 2021 |  | 2020 |  | Change |  | % Change |
| (in millions, except percentages) |
| Interest income | $ | 4.5 |  |  | $ | 17.7 |  |  | $ | (13.2) |  |  | (75) | % |
| Interest expense | (14.9) |  |  | — |  |  | (14.9) |  |  | * |
| Other expense—net | (11.6) |  |  | (7.8) |  |  | (3.8) |  |  | 49 | % |

[0001262039-22-000008:mdna:163]
* Not meaningful

[0001262039-22-000008:mdna:164]
Interest income decreased by $13.2 million in 2021 as compared to 2020, primarily as a result of lower interest rates. Interest income varies depending on our average investment balances during the period, types and mix of investments, and market interest rates. Interest expense increased by $14.9 million due to the senior notes issued in the first quarter of 2021. Other expense—net increase by $3.8 million in 2021 as compared to 2020 was primarily the result of an increase of $5.1 million in losses on marketable equity securities and an increase of $2.7 million in foreign exchange losses in 2021 compared to 2020. In 2020, we recognized a $4.3 million impairment charge on an investment in a privately held company and there were no such impairment charges in 2021.

[0001262039-22-000008:mdna:165]
Provision for income taxes

[0001262039-22-000008:mdna:166]
|  | Year Ended December 31, |  | Change |  | % Change |
| 2021 |  | 2020 |  |
| (in millions, except percentages) |
| Provision for income taxes | $ | 14.1 |  |  | $ | 53.2 |  |  | $ | (39.1) |  |  | (73) | % |
| Effective tax rate | 2 | % |  | 10 | % |  |  |  |  |

[0001262039-22-000008:mdna:167]
Our provision for income taxes for 2021 reflects an effective tax rate of 2%, compared to an effective tax rate of 10% for 2020. The provision for income taxes for 2021 was comprised primarily of a $140.8 million tax expense related to U.S. federal and state taxes, other foreign income taxes, foreign withholding taxes and unrecognized tax benefits. The provision was partially offset by excess tax benefits of $82.0 million from stock-based compensation expense, a tax benefit of $33.6 million from the FDII deduction, and tax benefits of $11.1 million from federal research and development tax credits.

[0001262039-22-000008:mdna:168]
Our provision for income taxes for 2020 reflects an effective tax rate of 10%, compared to an effective tax rate of 14% for 2019. The provision for income taxes for 2020 was comprised primarily of a $146.8 million tax expense related to U.S. federal and state taxes, other foreign income taxes, foreign withholding taxes and unrecognized tax benefits. The provision was partially offset by a tax benefit of $44.3 million from the FDII deduction, excess tax benefits of $42.0 million from stock-based compensation expense and tax benefits of $7.5 million from federal research and development tax credits.

[0001262039-22-000008:mdna:169]
Seasonality, Cyclicality and Quarterly Revenue Trends

[0001262039-22-000008:mdna:170]
Our quarterly results reflect a pattern of increased customer buying at year-end, which has positively impacted billings and product revenue activity in the fourth quarter. In the first quarter, we generally experience lower sequential customer product buying, followed by an increase in buying in the second and third quarters. Although these seasonal factors may be common in the technology sector, historical patterns should not be considered a reliable indicator of our future sales activity or performance. On a quarterly basis, we have usually generated the majority of our product revenue in the final month of each quarter and a significant amount in the last two weeks of each quarter. We believe this is due to customer buying patterns typical in this industry.

[0001262039-22-000008:mdna:171]
Consistent with the seasonality note above, our total quarterly revenue over the past two years has increased sequentially each year. Product revenue increased year-over-year as compared to 2020, as we have continued product innovation and launched new product models, expanded our solution sales, including SD-WAN and WFA solutions and increased our investments in our sales and marketing organizations.

[0001262039-22-000008:mdna:172]
Total gross margin has fluctuated on a quarterly basis primarily due to the relative product and service mix as well as the timing of supplier cost increases and our own price increases. Product gross margin varies based on the types of products sold, their cost profile and their average selling prices. In 2021, product gross margin was impacted by new product introductions, the mix of high-end, mid-range and entry-level FortiGate products and the mix of other Fabric products, software sales and the timing and impact of supplier cost increases and our own price list increases. In 2021, we experienced an unusual level of component suppliers charging new expedite fees and increases in freight costs. Historically, we have been able to improve our direct cost of appliances and our product gross margin. Service gross margin is impacted by revenue growth and our personnel-related costs, third-party repair and contract fulfillment, data center, colocation fees, cloud hosting, supplies, facility-related costs and foreign currency fluctuations.

[0001262039-22-000008:mdna:173]
Liquidity and Capital Resources

[0001262039-22-000008:mdna:174]
|  | As of December 31, |
|  | 2021 |  | 2020 |  | 2019 |
|  | (in millions) |
| Cash and cash equivalents | $ | 1,319.1 |  |  | $ | 1,061.8 |  |  | $ | 1,222.5 |  |
| Short-term and long-term investments | 1,634.8 |  |  | 893.8 |  |  | 987.4 |  |
| Marketable equity securities | 38.6 |  |  | — |  |  | — |  |
| Total cash, cash equivalents, investments and marketable equity securities | $ | 2,992.5 |  |  | $ | 1,955.6 |  |  | $ | 2,209.9 |  |
| Working capital | $ | 1,282.5 |  |  | $ | 910.9 |  |  | $ | 1,313.2 |  |
|  | Year Ended December 31, |
|  | 2021 |  | 2020 |  | 2019 |
|  | (in millions) |
| Net cash provided by operating activities | $ | 1,499.7 |  |  | $ | 1,083.7 |  |  | $ | 808.0 |  |
| Net cash used in investing activities | (1,325.1) |  |  | (72.8) |  |  | (502.3) |  |
| Net cash provided by (used in) financing activities | 82.8 |  |  | (1,171.6) |  |  | (195.6) |  |
| Effect of exchange rate changes on cash and cash equivalents | (0.1) |  |  | — |  |  | — |  |
| Net increase (decrease) in cash and cash equivalents | $ | 257.3 |  |  | $ | (160.7) |  |  | $ | 110.1 |  |

[0001262039-22-000008:mdna:175]
64

[0001262039-22-000008:mdna:176]
Liquidity and capital resources are impacted by our operating activities, proceeds from issuance of our investment grade debt and from exercise of stock options issued to employees, as well as cash used on stock repurchases, real estate purchases and other capital expenditures, investments in various companies and business acquisitions.

[0001262039-22-000008:mdna:177]
In recent years, we have received significant capital resources from our billings to customers, issuance of investment grade debt and, to some extent, from the exercise of stock options by our employees. Additional increases in billings may depend on a number of factors, including demand for our products and services, competition, market or industry changes, macroeconomic events such as the COVID-19 pandemic, supply chain capacity and disruptions, international conflicts and our ability to execute. We expect proceeds from the exercise of stock options in future years to be impacted by the increased mix of restricted stock units versus stock options granted to our employees and to vary based on our share price.

[0001262039-22-000008:mdna:178]
In October 2021, our board of directors authorized a $1.25 billion increase in the authorized stock repurchase under the Repurchase Program and extended the term of the Repurchase Program to February 28, 2023, bringing the aggregate amount of authorized to be repurchased to $4.25 billion. In 2021, we repurchased 2.6 million shares of common stock under the Repurchase Program for an aggregate purchase price of $741.8 million. As of December 31, 2021, $1.52 billion remained available for future share repurchases under the Repurchase Program.

[0001262039-22-000008:mdna:179]
In March 2021, we issued $1.0 billion aggregate principal amount of senior notes, consisting of $500.0 million aggregate principal amount of 1.0% notes due March 15, 2026 and $500.0 million aggregate principal amount of 2.2% notes due March 15, 2031, in an underwritten registered public offering (the “Notes”). We do not currently intend to retire these Notes early. Refer to Note 11. Debt in Part II, Item 8 of this Annual Report on Form 10-K for information on the Notes.

[0001262039-22-000008:mdna:180]
In February 2020, we received a cash payment of $50.0 million pursuant to a mutual covenant-not-to-sue and release agreement with a competitor in the network security industry.

[0001262039-22-000008:mdna:181]
In 2021, we completed our new, net-zero building on our Sunnyvale headquarters campus. We expect to continue to increase our office and warehouse capacity to support growth. As we purchase new properties, we will work to incorporate these properties into the environmental goals we have established. We estimate 2022 capital expenditures to be between $270 million and $300 million.

[0001262039-22-000008:mdna:182]
Our principal commitments consist of obligations under our Notes, inventory purchase and other contractual commitments.  As of December 31, 2021, the long-term debt, net of unamortized discount and debt issuance costs, was $988.4 million. In addition, we enter into non-cancellable agreements with contract manufacturers to procure inventory based on our requirements in order to reduce manufacturing lead times, plan for adequate component supply or incentivize suppliers to deliver. In 2021, we significantly increased these commitments as contract manufacturers and component suppliers significantly increased their pricing and lead times. Inventory purchase commitments as of December 31, 2021, were $1.14 billion, an increase of $881.1 million compared to $259.4 million as of December 31, 2020. We estimate payments of $1.08 billion due on or before December 31, 2022 related to these commitments. We also have open purchase orders and contractual obligations in the ordinary course of business for which we have not received goods or services. As of December 31, 2021, we had $126.7 million in other contractual commitments having a remaining term in excess of one year that are non-cancelable.

[0001262039-22-000008:mdna:183]
As of December 31, 2021, our cash, cash equivalents, investments and marketable equity securities of $2.99 billion were invested primarily in deposit accounts, commercial paper, corporate debt securities,  U.S. government and agency securities, certificates of deposit and term deposits, money market funds,  municipal bonds and marketable equity securities. It is our investment policy to invest excess cash in a manner that preserves capital, provides liquidity and generates return without significantly increasing risk. We do not enter into investments for trading or speculative purposes.

[0001262039-22-000008:mdna:184]
The amount of cash, cash equivalents and investments held by our international subsidiaries was $132.4 million and $119.8 million as of December 31, 2021 and 2020, respectively.

[0001262039-22-000008:mdna:185]
We believe that our existing cash and cash equivalents and cash flow from operations will be sufficient for at least the next 12 months to meet our requirements and plans for cash, including meeting our working capital requirements and capital expenditure requirements. In the long term, our ability to support our requirements and plans for cash, including our working capital and capital expenditure requirements will depend on many factors, including our growth rate, the timing and amount of our share repurchases, the expansion of sales and marketing activities, the introduction of new and enhanced products and services offerings, the continuing market acceptance of our products, the timing and extent of spending to support development efforts, our investments in purchasing or leasing real estate and macroeconomic impacts such as the COVID-19 pandemic. Historically, we have required capital principally to fund our working capital needs, share repurchases, capital expenditures and acquisition activities. In the event that additional financing is required from outside sources, we may not be able to raise it on terms acceptable to us or at all.

[0001262039-22-000008:mdna:186]
65

[0001262039-22-000008:mdna:187]
During 2021, 2020 and 2019, we did not have any relationships with unconsolidated organizations or financial partnerships, such as structured finance or special purpose entities that would have been established for the purpose of facilitating off-balance sheet arrangements or other contractually narrow or limited purposes.

[0001262039-22-000008:mdna:188]
Operating Activities

[0001262039-22-000008:mdna:189]
Cash generated by operating activities is our primary source of liquidity. It is primarily comprised of net income, as adjusted for non-cash items and changes in operating assets and liabilities. Non-cash adjustments consist primarily of stock-based compensation, amortization of deferred contract costs and depreciation and amortization. Changes in operating assets and liabilities consist primarily of changes in deferred revenue, deferred contract costs, deferred tax assets, and accounts receivable.

[0001262039-22-000008:mdna:190]
Our operating activities during 2021 provided cash flows of $1.50 billion as a result of the continued growth of our business and our ability to successfully manage our working capital. Changes in operating assets and liabilities primarily resulted from an increase in sales of our FortiGuard and other security subscription services and FortiCare technical support services to new and existing customers, as reflected by an increase in our deferred revenue. Our total deferred revenue balance grew $847.6 million, or 33%, during 2021.

[0001262039-22-000008:mdna:191]
Investing Activities

[0001262039-22-000008:mdna:192]
The changes in cash flows from investing activities primarily relate to timing of purchases, maturities and sales of investments, purchases of property and equipment, investments in various companies and business acquisitions. Historically, in making a lease versus ownership decision related to our larger facilities, we have considered various factors including financial metrics and the impact on our engineers and other employees, and expected long-term growth rates. In certain cases, we have elected to own the facility if we believed that purchasing building or developing buildings rather than leasing is more in line with our long-term strategy. We may make similar decisions in the future. We may also make cash payments in connection with future business combinations.

[0001262039-22-000008:mdna:193]
During 2021, cash used in investing activities was primarily driven by $752.2 million spent for purchases of investments, net of maturities and sales of investments, $295.9 million of purchases of property and equipment, a large portion of which relates to our headquarters building construction, $160.0 million used for purchases of investment in a privately held company, and $74.9 million used for the acquisitions of Alaxala, ShieldX and other, net of cash and $42.5 million used for purchases of marketable equity securities.

[0001262039-22-000008:mdna:194]
Financing Activities

[0001262039-22-000008:mdna:195]
The changes in cash flows from financing activities primarily relate to the issuance of the Notes, repurchase and retirement of common stock, and taxes paid related to net share settlement of equity awards, net of proceeds from the issuance of common stock under the 2009 Plan.

[0001262039-22-000008:mdna:196]
During 2021, cash provided by financing activities was $82.8 million, primarily driven by $987.0 million in cash proceeds from long-term investment grade debt, net of discount and underwriting fees, partially offset by $741.8 million used to repurchase shares of our common stock and $141.9 million used to pay tax withholding, net of proceeds from the issuance of common stock.

[0001262039-22-000008:mdna:197]
Recent Accounting Pronouncements

[0001262039-22-000008:mdna:198]
Refer to Note 1 of the notes to our consolidated financial statements in Part II, Item 8 of this Annual Report on Form 10-K for a full description of recently adopted accounting pronouncements.
