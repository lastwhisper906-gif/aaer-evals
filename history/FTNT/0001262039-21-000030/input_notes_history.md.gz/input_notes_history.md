# FTNT note change history — 0001262039-21-000022 → 0001262039-21-000030


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2021-11-08):
[0001262039-21-000030:note_history:1]
COMMITMENTS AND CONTINGENCIES
The following table summarizes our inventory purchase commitments as of September 30, 2021 (in millions):
  (was, 2021-08-02, similarity 0.9569):
[0001262039-21-000022:note_history:1]
COMMITMENTS AND CONTINGENCIES
The following table summarizes our inventory purchase commitments as of June 30, 2021 (in millions):

- changed (2021-11-08):
[0001262039-21-000030:note_history:2]
Inventory Purchase Commitments—Our independent contract manufacturers procure components and build our products based on our forecasts. These forecasts are based on estimates of future demand for our products, which are in turn based on historical trends and an analysis from our sales and marketing organizations, adjusted for supply chain matters and other market conditions. In order to reduce manufacturing lead times, plan for adequate component supply and incentivize suppliers to deliver, we may issue purchase orders to some of our independent contract manufacturers, which are non-cancelable. As of September 30, 2021, we had $868.0 million of open purchase orders with our independent contract manufacturers that are non-cancelable.
  (was, 2021-08-02, similarity 0.6293):
[0001262039-21-000022:note_history:2]
Inventory Purchase Commitments—Our independent contract manufacturers procure components and build our products based on our forecasts. These forecasts are based on estimates of future demand for our products, which are in turn based on historical trends and an analysis from our sales and marketing organizations, adjusted for overall market conditions. In order to reduce manufacturing lead times and plan for adequate component supply, we may issue purchase orders to some of our independent contract manufacturers, which may not be cancelable. As of June 30, 2021, we had $628.7 million of open purchase orders with our independent contract manufacturers that may not be cancelable.

- changed (2021-11-08):
[0001262039-21-000030:note_history:3]
Other Contractual Commitments and Open Purchase Orders—In addition to commitments with contract manufacturers, we have open purchase orders and contractual obligations in the ordinary course of business for which we have not received goods or services. As of September 30, 2021, we had $68.9 million in other contractual commitments having a remaining term in excess of one year that are non-cancelable.
  (was, 2021-08-02, similarity 0.9415):
[0001262039-21-000022:note_history:3]
Other Contractual Commitments and Open Purchase Orders—In addition to commitments with contract manufacturers, we have open purchase orders and contractual obligations in the ordinary course of business for which we have not received goods or services. As of June 30, 2021, we had $67.9 million in other contractual commitments having a remaining term in excess of one year that may not be cancelable.

- changed (2021-11-08):
[0001262039-21-000030:note_history:4]
Litigation—We are involved in disputes, litigation, and other legal actions. For lawsuits where we are the defendant, we are in the process of defending these litigation matters, and while there can be no assurances and the outcome of certain of these matters is currently not determinable and not predictable, we currently are unaware of any existing claims or proceedings that we believe are likely to have a material adverse effect on our financial position. There are many uncertainties associated with any litigation and these actions or other third-party claims against us may cause us to incur costly litigation fees, costs and substantial settlement charges, and possibly subject us to damages and other penalties. In addition, the resolution of any IP litigation may require us to make royalty payments, which could adversely affect our gross margins in future periods. If any of those events were to occur, our business, financial condition, results of operations, and cash flows could be adversely affected. Litigation is unpredictable and the actual liability in any such matters may be materially different from our current estimates, which could result in the need to adjust any accrued liability and record additional expenses. We accrue for contingencies when we believe that a loss is probable and that we can reasonably estimate the amount of any such loss.
  (was, 2021-08-02, similarity 0.7478):
[0001262039-21-000022:note_history:4]
with any litigation and these actions or other third-party claims against us may cause us to incur costly litigation fees, costs and substantial settlement charges, and possibly subject us to damages and other penalties. In addition, the resolution of any IP litigation may require us to make royalty payments, which could adversely affect our gross margins in future periods. If any of those events were to occur, our business, financial condition, results of operations, and cash flows could be adversely affected. Litigation is unpredictable and the actual liability in any such matters may be materially different from our current estimates, which could result in the need to adjust any accrued liability and record additional expenses. We accrue for contingencies when we believe that a loss is probable and that we can reasonably estimate the amount of any such loss. Litigation loss contingency accruals were not material as of June 30, 2021 and December 31, 2020.

- added (2021-11-08):
[0001262039-21-000030:note_history:5]
In October 2021, we held settlement discussions related to an existing patent infringement lawsuit. Pursuant to such discussions, we may enter into an agreement that provides for the settlement and dismissal of the patent lawsuit and a mutual covenant not to sue for a defined duration of time.  As a result, we have determined that a loss in connection with such lawsuit is now probable. We accrued $5 million as a loss contingency in the quarter ended September 30, 2021 and the associated charge was recorded against revenue in the income statement. Litigation loss contingency accruals associated with other outstanding cases were not material as of September 30, 2021 and December 31, 2020.

- added (2021-11-08):
[0001262039-21-000030:note_history:6]
Indemnification and Other Matters—Under the indemnification provisions of our standard sales contracts, we agree to defend our customers against third-party claims asserting various allegations such as product defects and infringement of certain IP rights, which may include patents, copyrights, trademarks or trade secrets, and to pay judgments entered on such

- changed (2021-11-08):
[0001262039-21-000030:note_history:7]
claims. In some contracts, our exposure under these indemnification provisions is limited by the terms of the contracts to certain defined limits, such as the total amount paid by our customer under the agreement. However, certain agreements include covenants, penalties and indemnification provisions including and beyond indemnification for third-party claims of IP infringement that could potentially expose us to losses in excess of the amount received under the agreement, and in some instances to potential liability that is not contractually limited. Although from time to time there are indemnification claims asserted against us and currently there are pending indemnification claims, to date there have been no material awards under such indemnification provisions.
  (was, 2021-08-02, similarity 0.8107):
[0001262039-21-000022:note_history:7]
Indemnification and Other Matters—Under the indemnification provisions of our standard sales contracts, we agree to defend our customers against third-party claims asserting various allegations such as product defects and infringement of certain IP rights, which may include patents, copyrights, trademarks or trade secrets, and to pay judgments entered on such claims. In some contracts, our exposure under these indemnification provisions is limited by the terms of the contracts to certain defined limits, such as the total amount paid by our customer under the agreement. However, certain agreements include covenants, penalties and indemnification provisions including and beyond indemnification for third-party claims of IP infringement that could potentially expose us to losses in excess of the amount received under the agreement, and in some instances to potential liability that is not contractually limited. Although from time to time there are indemnification claims asserted against us and currently there are pending indemnification claims, to date there have been no material awards under such indemnification provisions.

- removed (2021-11-08):
[0001262039-21-000022:note_history:8]
Litigation—We are involved in disputes, litigation, and other legal actions. For lawsuits where we are the defendant, we are in the process of defending these litigation matters, and while there can be no assurances and the outcome of certain of these matters is currently not determinable and not predictable, we currently are unaware of any existing claims or proceedings that we believe are likely to have a material adverse effect on our financial position. There are many uncertainties associated


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2021-11-08):
[0001262039-21-000030:note_history:9]
SUMMARY OF SIGNIFICANT ACCOUNTING POLICIES
Basis of Presentation and Preparation—The unaudited condensed consolidated financial statements of Fortinet, Inc. and its subsidiaries (collectively, “we,” “us” or “our”) have been prepared in accordance with generally accepted accounting principles in the United States (“GAAP”) for interim financial information, as well as the instructions to Form 10-Q pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (the “SEC”). Accordingly, they do not include all of the information and footnotes required by GAAP for complete financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the year ended December 31, 2020, contained in our Annual Report on Form 10-K filed with the SEC on February 19, 2021. In the opinion of management, all adjustments, which includes normal recurring adjustments, considered necessary for a fair presentation have been included. The results of operations for the three and nine months ended September 30, 2021 are not necessarily indicative of the results to be expected for the full year or for any future periods. The condensed consolidated balance sheet as of December 31, 2020 is derived from the audited consolidated financial statements for the year ended December 31, 2020.
  (was, 2021-08-02, similarity 0.7766):
[0001262039-21-000022:note_history:9]
SUMMARY OF SIGNIFICANT ACCOUNTING POLICIES
Basis of Presentation and Preparation—The unaudited condensed consolidated financial statements of Fortinet, Inc. and its wholly owned subsidiaries (collectively, “we,” “us” or “our”) have been prepared in accordance with generally accepted accounting principles in the United States (“GAAP”) for interim financial information, as well as the instructions to Form 10-Q pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (the “SEC”). Accordingly, they do not include all of the information and footnotes required by GAAP for complete financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the year ended December 31, 2020, contained in our Annual Report on Form 10-K filed with the SEC on February 19, 2021. In the opinion of management, all adjustments, which includes normal recurring adjustments, considered necessary for a fair presentation have been included. All intercompany balances, transactions and cash flows have been eliminated. The results of operations for the three and six months ended June 30, 2021 are not necessarily indicative of the results for the full year or for any future periods. The condensed consolidated balance sheet as of December 31, 2020 is derived from the audited consolidated financial statements for the year ended December 31, 2020.

- added (2021-11-08):
[0001262039-21-000030:note_history:10]
The condensed consolidated financial statements include the accounts of Fortinet, Inc. and its subsidiaries. We consolidate all legal entities in which we have an absolute controlling financial interest. All intercompany balances and transactions have been eliminated in consolidation.

- added (2021-11-08):
[0001262039-21-000030:note_history:11]
Investments in common stock or in-substance common stock of entities that provide us with the ability to exercise significant influence, but not an absolute controlling financial interest, over the investee are accounted for under the equity method of accounting. Investments accounted for under the equity method are initially recorded at cost. Subsequently, we recognize our proportionate share of the entities’ net income or loss and the amortization of any basis differences through the condensed consolidated statements of income and as an adjustment to the investment balance. We record our share of the results of equity method investments on a three-month lag basis as income or loss from equity method investments, net of tax in the condensed consolidated statements of income. We evaluate our equity method investments at the end of each reporting period to determine whether events or changes in business circumstances indicate that the carrying value of the investment may not be recoverable. As of September 30, 2021, our investment in Linksys Holdings, Inc. (“Linksys”) was our only equity method investment.

- added (2021-11-08):
[0001262039-21-000030:note_history:12]
There have been no other material changes to our significant accounting policies as of and for the three and nine months ended September 30, 2021.

- added (2021-11-08):
[0001262039-21-000030:note_history:13]
Recent Accounting Standards Not Yet Effective

- added (2021-11-08):
[0001262039-21-000030:note_history:14]
Business Combinations

- added (2021-11-08):
[0001262039-21-000030:note_history:15]
In October 2021, the FASB issued ASU 2021-08—Business Combinations (“Topic 805”): Accounting for Contract Assets and Contract Liabilities from Contracts with Customers. The amendments in ASU 2021-08 require that an entity 
recognizes and measures contract assets and contract liabilities acquired in a business combination in accordance with ASC 606, Revenue from Contracts with Customers (“Topic 606”). At the acquisition date, an acquirer should account for the related revenue contracts in accordance with Topic 606 as if it had originated the contracts. The amendments improve comparability for both the recognition and measurement of acquired revenue contracts with customers at the date of and after a business combination. ASU 2021-08 will be effective for us beginning on January 1, 2023. We are currently evaluating the impact of ASU 2021-08 on our condensed consolidated financial statements.

- removed (2021-11-08):
[0001262039-21-000022:note_history:16]
Except for the update to the range of useful lives for property and equipment discussed in Note 6 and our policy election for how we account for our share of financial results for a specific investment in privately held companies on a three-month lag basis as discussed in Note 7, there have been no material changes to our significant accounting policies as of and for the three and six months ended June 30, 2021.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2021-11-08):
[0001262039-21-000030:note_history:17]
DEBT
2026 and 2031 Senior Notes

- changed (2021-11-08):
[0001262039-21-000030:note_history:18]
On March 5, 2021, we issued $1.0 billion aggregate principal amount of senior notes (collectively, the “Senior Notes”), consisting of $500.0 million aggregate principal amount of 1.0% notes due March 15, 2026 (the “2026 Senior Notes”) and $500.0 million aggregate principal amount of 2.2% notes due March 15, 2031 (the “2031 Senior Notes”), in an underwritten registered public offering. The Senior Notes are senior unsecured obligations and rank equally with each other in right of payment and with our other outstanding obligations. We may redeem the Senior Notes at any time in whole or in part for cash, at specified redemption prices that include accrued and unpaid interest, if any, and a make-whole premium. However, no make-whole premium will be paid for redemptions of the 2026 Senior Notes on or after February 15, 2026, or the 2031 Senior Notes on or after December 15, 2030. Interest on the Senior Notes is payable on March 15 and September 15 of each year, beginning on September 15, 2021. As of September 30, 2021, the Senior Notes were recorded as long-term debt, net of discount and issuance costs, which are amortized to interest expense over the respective contractual terms of these notes using the effective interest method.
  (was, 2021-08-02, similarity 0.9924):
[0001262039-21-000022:note_history:18]
DEBT
On March 5, 2021, we issued $1.0 billion aggregate principal amount of senior notes (collectively, the “Senior Notes”), consisting of $500.0 million aggregate principal amount of 1.0% notes due March 15, 2026 (the “2026 Senior Notes”) and $500.0 million aggregate principal amount of 2.2% notes due March 15, 2031 (the “2031 Senior Notes”), in an underwritten registered public offering. The Senior Notes are senior unsecured obligations and rank equally with each other in right of payment and with our other outstanding obligations. We may redeem the Senior Notes at any time in whole or in part for cash, at specified redemption prices that include accrued and unpaid interest, if any, and a make-whole premium. However, no make-whole premium will be paid for redemptions of the 2026 Senior Notes on or after February 15, 2026, or the 2031 Senior Notes on or after December 15, 2030. Interest on the Senior Notes is payable on March 15 and September 15 of each year, beginning on September 15, 2021. As of June 30, 2021, the Senior Notes were recorded as long-term debt, net of discount and issuance costs, which are amortized to interest expense over the respective contractual terms of these notes using the effective interest method.

- added (2021-11-08):
[0001262039-21-000030:note_history:19]
|  | Maturity |  | Coupon Rate |  | Effective Interest Rate |  | September 30, 2021 |
| Debt |  |  |  |  |  |  |  |
| 2026 Senior Notes | March 2026 |  | 1.0 | % |  | 1.3 | % |  | $ | 500.0 |  |
| 2031 Senior Notes | March 2031 |  | 2.2 | % |  | 2.3 | % |  | 500.0 |  |
| Total debt |  |  |  |  |  |  | 1,000.0 |  |
| Less: Unamortized discount and debt issuance costs |  |  |  |  |  |  | 12.0 |  |
| Total long-term debt |  |  |  |  |  |  | $ | 988.0 |  |

- added (2021-11-08):
[0001262039-21-000030:note_history:20]
As of September 30, 2021 we accrued interest payable of $0.7 million, and there are no financial covenants with which we must comply. During the three and nine months ended September 30, 2021 we recorded $4.4 million and $10.2 million of total interest expense in relation to these Senior Notes, respectively. No interest costs were capitalized for the three and nine months ended September 30, 2021, as the costs that qualified for capitalization were not material.

- added (2021-11-08):
[0001262039-21-000030:note_history:21]
The total estimated fair value of the outstanding Senior Notes was approximately $991.1 million, including accrued and unpaid interest, as of September 30, 2021. The fair value was determined based on observable market prices of identical instruments in less active markets. The estimated fair values are based on Level 2 inputs.

- added (2021-11-08):
[0001262039-21-000030:note_history:22]
AlaxalA debt

- added (2021-11-08):
[0001262039-21-000030:note_history:23]
In connection with our acquisition of AlaxalA, we assumed certain current debt liabilities of $20.2 million as of August 31, 2021. We concluded that the fair value of debt approximated its book value as of the acquisition date. We had $17.6 million of this debt outstanding and recorded as current portion of long-term debt on our condensed consolidated balance sheet as of September 30, 2021. We repaid this balance in full in October 2021. As of September 30, 2021, the accrued interest under the assumed AlaxalA debt obligations was not material. During the post-acquisition period from September 1, 2021 through September 30, 2021, interest expense related to AlaxalA debt was not material.

- removed (2021-11-08):
[0001262039-21-000022:note_history:24]
|  | Maturity |  | Coupon Rate |  | Effective Interest Rate |  | June 30, 2021 |
| Debt |  |  |  |  |  |  |  |
| 2026 Senior Notes | March 2026 |  | 1.0 | % |  | 1.3 | % |  | $ | 500.0 |  |
| 2031 Senior Notes | March 2031 |  | 2.2 | % |  | 2.3 | % |  | 500.0 |  |
| Total debt |  |  |  |  |  |  | 1,000.0 |  |
| Less: Unamortized discount and debt issuance costs |  |  |  |  |  |  | (12.5) |  |
| Total long-term debt |  |  |  |  |  |  | $ | 987.5 |  |

- removed (2021-11-08):
[0001262039-21-000022:note_history:25]
As of June 30, 2021 we accrued interest payable of $5.2 million, and there are no financial covenants with which we must comply. During the three and six months ended June 30, 2021 we recorded $4.5 million and $5.8 million of total interest

- removed (2021-11-08):
[0001262039-21-000022:note_history:26]
expense in relation to these Senior Notes, respectively. No interest costs were capitalized for the three and six months ended June 30, 2021, as the costs that qualified for capitalization were not material.

- removed (2021-11-08):
[0001262039-21-000022:note_history:27]
The total estimated fair value of the outstanding Senior Notes was approximately $999.9 million, including accrued and unpaid interest, as of June 30, 2021. The fair value was determined based on observable market prices of identical instruments in less active markets. The estimated fair values are based on Level 2 inputs.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2021-11-08):
[0001262039-21-000030:note_history:28]
|  | Maturity |  | Coupon Rate |  | Effective Interest Rate |  | September 30, 2021 |
| Debt |  |  |  |  |  |  |  |
| 2026 Senior Notes | March 2026 |  | 1.0 | % |  | 1.3 | % |  | $ | 500.0 |  |
| 2031 Senior Notes | March 2031 |  | 2.2 | % |  | 2.3 | % |  | 500.0 |  |
| Total debt |  |  |  |  |  |  | 1,000.0 |  |
| Less: Unamortized discount and debt issuance costs |  |  |  |  |  |  | 12.0 |  |
| Total long-term debt |  |  |  |  |  |  | $ | 988.0 |  |

- removed (2021-11-08):
[0001262039-21-000022:note_history:29]
|  | Maturity |  | Coupon Rate |  | Effective Interest Rate |  | June 30, 2021 |
| Debt |  |  |  |  |  |  |  |
| 2026 Senior Notes | March 2026 |  | 1.0 | % |  | 1.3 | % |  | $ | 500.0 |  |
| 2031 Senior Notes | March 2031 |  | 2.2 | % |  | 2.3 | % |  | 500.0 |  |
| Total debt |  |  |  |  |  |  | 1,000.0 |  |
| Less: Unamortized discount and debt issuance costs |  |  |  |  |  |  | (12.5) |  |
| Total long-term debt |  |  |  |  |  |  | $ | 987.5 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2021-11-08):
[0001262039-21-000030:note_history:30]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30,2021 |  | September 30,2020 |  | September 30,2021 |  | September 30,2020 |
| Product | $ | 337.1 |  |  | $ | 223.8 |  |  | $ | 876.1 |  |  | $ | 628.0 |  |
| Service: |  |  |  |  |  |  |  |
| Security subscription | 287.4 |  |  | 235.4 |  |  | 815.6 |  |  | 669.4 |  |
| Technical support and other | 242.7 |  |  | 191.9 |  |  | 686.9 |  |  | 549.0 |  |
| Total service revenue | 530.1 |  |  | 427.3 |  |  | 1,502.5 |  |  | 1,218.4 |  |
| Total revenue | $ | 867.2 |  |  | $ | 651.1 |  |  | $ | 2,378.6 |  |  | $ | 1,846.4 |  |
  (was, 2021-08-02, similarity 0.881):
[0001262039-21-000022:note_history:30]
|  | Three Months Ended |  | Six Months Ended |
|  | June 30,2021 |  | June 30,2020 |  | June 30,2021 |  | June 30,2020 |
| Product | $ | 298.3 |  |  | $ | 211.9 |  |  | $ | 539.0 |  |  | $ | 404.2 |  |
| Service: |  |  |  |  |  |  |  |
| Security subscription | 272.9 |  |  | 222.6 |  |  | 528.2 |  |  | 434.0 |  |
| Technical support and other | 229.9 |  |  | 183.1 |  |  | 444.2 |  |  | 357.1 |  |
| Total service revenue | 502.8 |  |  | 405.7 |  |  | 972.4 |  |  | 791.1 |  |
| Total revenue | $ | 801.1 |  |  | $ | 617.6 |  |  | $ | 1,511.4 |  |  | $ | 1,195.3 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2021-11-08):
[0001262039-21-000030:note_history:31]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30,2021 |  | September 30,2020 |  | September 30,2021 |  | September 30,2020 |
| Product | $ | 337.1 |  |  | $ | 223.8 |  |  | $ | 876.1 |  |  | $ | 628.0 |  |
| Service: |  |  |  |  |  |  |  |
| Security subscription | 287.4 |  |  | 235.4 |  |  | 815.6 |  |  | 669.4 |  |
| Technical support and other | 242.7 |  |  | 191.9 |  |  | 686.9 |  |  | 549.0 |  |
| Total service revenue | 530.1 |  |  | 427.3 |  |  | 1,502.5 |  |  | 1,218.4 |  |
| Total revenue | $ | 867.2 |  |  | $ | 651.1 |  |  | $ | 2,378.6 |  |  | $ | 1,846.4 |  |
  (was, 2021-08-02, similarity 0.881):
[0001262039-21-000022:note_history:31]
|  | Three Months Ended |  | Six Months Ended |
|  | June 30,2021 |  | June 30,2020 |  | June 30,2021 |  | June 30,2020 |
| Product | $ | 298.3 |  |  | $ | 211.9 |  |  | $ | 539.0 |  |  | $ | 404.2 |  |
| Service: |  |  |  |  |  |  |  |
| Security subscription | 272.9 |  |  | 222.6 |  |  | 528.2 |  |  | 434.0 |  |
| Technical support and other | 229.9 |  |  | 183.1 |  |  | 444.2 |  |  | 357.1 |  |
| Total service revenue | 502.8 |  |  | 405.7 |  |  | 972.4 |  |  | 791.1 |  |
| Total revenue | $ | 801.1 |  |  | $ | 617.6 |  |  | $ | 1,511.4 |  |  | $ | 1,195.3 |  |

- changed (2021-11-08):
[0001262039-21-000030:note_history:32]
During the three months ended September 30, 2021 and September 30, 2020, we recognized $309.2 million and $263.1 million in service revenue that was included in the deferred revenue balance as of December 31, 2020 and December 31, 2019, respectively. During the nine months ended September 30, 2021 and September 30, 2020, we recognized $1.10 billion and $921.7 million in service revenue that was included in the deferred revenue balance as of December 31, 2020 and December 31, 2019, respectively.
  (was, 2021-08-02, similarity 0.8545):
[0001262039-21-000022:note_history:32]
During the three months ended June 30, 2021 and June 30, 2020, we recognized $371.2 million and $302.0 million in service revenue that was included in the deferred revenue balance as of December 31, 2020 and December 31, 2019, respectively. During the six months ended June 30, 2021 and June 30, 2020, we recognized $789.1 million and $645.3 million in service revenue that was included in the deferred revenue balance as of December 31, 2020 and December 31, 2019, respectively.

- changed (2021-11-08):
[0001262039-21-000030:note_history:33]
As of September 30, 2021, the aggregate amount of the transaction price allocated to remaining performance obligations was $3.11 billion, which was substantially comprised of deferred security subscription and technical support services revenue. We expect to recognize approximately $1.62 billion as revenue over the next 12 months and the remainder thereafter.
  (was, 2021-08-02, similarity 0.9812):
[0001262039-21-000022:note_history:33]
As of June 30, 2021, the aggregate amount of the transaction price allocated to remaining performance obligations was $2.91 billion, which was substantially comprised of deferred security subscription and technical support services revenue. We expect to recognize approximately $1.53 billion as revenue over the next 12 months and the remainder thereafter.

- changed (2021-11-08):
[0001262039-21-000030:note_history:34]
The allowance for credit losses was $2.6 million and $2.5 million as of September 30, 2021 and December 31, 2020, respectively. Provisions, write-offs and recoveries were not material during the nine months ended September 30, 2021 and 2020.
  (was, 2021-08-02, similarity 0.8747):
[0001262039-21-000022:note_history:34]
The allowance for credit losses was $2.7 million and $2.5 million as of June 30, 2021 and December 31, 2020, respectively. Provisions, write-offs and recoveries were not material during the six months ended June 30, 2021 and 2020.

- changed (2021-11-08):
[0001262039-21-000030:note_history:35]
Amortization of deferred contract costs during the three months ended September 30, 2021 and 2020 were $45.1 million and $35.3 million, respectively. Amortization of deferred contract costs during the nine months ended September 30, 2021 and 2020 were $126.9 million and $99.8 million, respectively.
  (was, 2021-08-02, similarity 0.8847):
[0001262039-21-000022:note_history:35]
Amortization of deferred contract costs during the three months ended June 30, 2021 and 2020 were $42.1 million and $33.2 million, respectively. Amortization of deferred contract costs during the six months ended June 30, 2021 and 2020 were $81.8 million and $64.5 million, respectively.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- changed (2021-11-08):
[0001262039-21-000030:note_history:36]
SUBSEQUENT EVENTS 
Debt Repayment
  (was, 2021-08-02, similarity 0.6667):
[0001262039-21-000022:note_history:36]
SUBSEQUENT EVENTS
Investments in Linksys

- added (2021-11-08):
[0001262039-21-000030:note_history:37]
In October 2021, we fully repaid the outstanding $17.6 million of debt liabilities assumed in the AlaxalA transaction.

- added (2021-11-08):
[0001262039-21-000030:note_history:38]
Building Purchase

- added (2021-11-08):
[0001262039-21-000030:note_history:39]
In October 2021, we purchased real property in Texas totaling approximately 87,000 square feet for a cash payment of $22.5 million.

- added (2021-11-08):
[0001262039-21-000030:note_history:40]
Share Repurchase Program

- added (2021-11-08):
[0001262039-21-000030:note_history:41]
In October 2021, our board of directors approved a $1.25 billion increase in the authorized stock repurchase under the Repurchase Program and extended the term of the Repurchase Program to February 28, 2023, bringing the aggregate amount authorized to be repurchased to $4.25 billion of our outstanding common stock through February 28, 2023.

- removed (2021-11-08):
[0001262039-21-000022:note_history:42]
As discussed in Note 7, on March 19, 2021 we invested $75.0 million in Linksys. On August  2, 2021, we entered into a share purchase agreement with Linksys (the “Share Purchase Agreement”), whereby we would invest an additional $85.0 million in Linksys (the “Second Tranche Investment”), subject to certain closing conditions. Following the closing of the Second Tranche Investment, we are expected to own 50.8% of the issued and outstanding capital stock of Linksys. We are evaluating the future accounting impact of this additional investment on our condensed consolidated financial statements.
