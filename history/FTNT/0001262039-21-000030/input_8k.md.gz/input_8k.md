# FTNT 8-K — 0001262039-21-000027 filed 2021-11-04

## item codes, every 8-K on or before 2021-11-08

- 2021-11-04 0001262039-21-000027 — 2.02, 9.01
- 2021-10-06 0001262039-21-000024 — 5.02, 9.01
- 2021-07-29 0001262039-21-000019 — 2.02, 9.01
- 2021-06-23 0001262039-21-000016 — 5.07
- 2021-04-30 0001104659-21-059008 — 5.03 — amendment, the index does not say of what
- 2021-04-29 0001262039-21-000011 — 2.02, 9.01
- 2021-04-28 0001104659-21-056360 — 5.02, 5.03, 9.01
- 2021-03-05 0001193125-21-071498 — 1.01, 9.01
- 2021-02-25 0001193125-21-057281 — 1.01, 9.01
- 2021-02-04 0001262039-21-000005 — 2.02, 9.01
- 2020-12-08 0001262039-20-000070 — 8.01
- 2020-10-29 0001262039-20-000063 — 2.02, 9.01
- 2020-10-20 0001262039-20-000060 — 5.02 — amendment, the index does not say of what
- 2020-08-26 0001262039-20-000056 — 5.02, 9.01
- 2020-08-06 0001262039-20-000051 — 2.02, 9.01
- 2020-07-21 0001262039-20-000044 — 5.03, 8.01, 9.01
- 2020-06-24 0001262039-20-000038 — 5.07
- 2020-05-06 0001262039-20-000029 — 2.02, 9.01
- 2020-04-23 0001262039-20-000025 — 5.03, 9.01
- 2020-04-23 0001262039-20-000024 — 5.02 — amendment of 0001262039-20-000025
- 2020-02-28 0001262039-20-000015 — 5.02, 9.01
- 2020-02-06 0001262039-20-000004 — 2.02, 9.01
- 2019-12-12 0001262039-19-000038 — 8.01
- 2019-10-31 0001262039-19-000032 — 2.02, 9.01
- 2019-10-28 0001262039-19-000027 — 8.01
- 2019-10-23 0001262039-19-000025 — 5.02, 9.01
- 2019-08-01 0001262039-19-000021 — 2.02, 9.01
- 2019-06-26 0001262039-19-000018 — 5.07
- 2019-05-02 0001262039-19-000010 — 2.02, 9.01
- 2019-02-06 0001262039-19-000002 — 2.02, 9.01
- 2018-11-01 0001262039-18-000037 — 2.02, 9.01
- 2018-10-23 0001262039-18-000035 — 8.01
- 2018-08-01 0001262039-18-000025 — 2.02, 9.01
- 2018-06-28 0001262039-18-000023 — 5.03, 5.07, 9.01
- 2018-06-04 0001262039-18-000021 — 8.01
- 2018-05-03 0001262039-18-000017 — 2.02, 5.02, 9.01
- 2018-02-05 0001262039-18-000004 — 2.02, 5.02, 9.01
- 2017-10-26 0001262039-17-000031 — 2.02, 9.01
- 2017-10-19 0001262039-17-000029 — 5.02 — amendment, the index does not say of what
- 2017-07-26 0001262039-17-000025 — 2.02, 9.01
- 2017-06-27 0001262039-17-000023 — 5.07
- 2017-05-31 0001262039-17-000021 — 5.02 — amendment of 0001262039-17-000019
- 2017-05-30 0001262039-17-000019 — 5.02, 9.01
- 2017-04-27 0001262039-17-000013 — 2.02, 9.01
- 2017-02-02 0001262039-17-000003 — 2.02, 9.01
- 2016-10-27 0001262039-16-000085 — 2.02, 9.01
- 2016-10-11 0001262039-16-000082 — 2.02, 9.01
- 2016-07-28 0001262039-16-000076 — 2.02, 9.01
- 2016-07-22 0001262039-16-000073 — 8.01, 9.01
- 2016-06-20 0001262039-16-000068 — 5.07
- 2016-06-07 0001193125-16-614788 — 8.01
- 2016-04-26 0001262039-16-000061 — 2.02, 9.01
- 2016-01-28 0001262039-16-000051 — 2.02, 9.01
- 2015-10-27 0001262039-15-000045 — 2.02
- 2015-10-22 0001262039-15-000042 — 5.02 — amendment, the index does not say of what
- 2015-10-22 0001262039-15-000041 — 5.02 — amendment, the index does not say of what
- 2015-10-22 0001262039-15-000039 — 2.02, 9.01
- 2015-09-28 0001262039-15-000034 — 5.02, 9.01
- 2015-09-22 0001262039-15-000031 — 9.01 — amendment of 0001193125-15-248065
- 2015-08-28 0001262039-15-000027 — 3.01, 5.02
- 2015-07-23 0001262039-15-000021 — 5.02
- 2015-07-22 0001262039-15-000019 — 2.02, 9.01
- 2015-07-08 0001193125-15-248065 — 2.01, 8.01, 9.01
- 2015-06-22 0001193125-15-229099 — 5.07
- 2015-06-19 0001193125-15-228428 — 5.02, 9.01
- 2015-04-20 0001262039-15-000014 — 2.02, 9.01
- 2015-01-28 0001262039-15-000005 — 2.02, 9.01
- 2014-10-22 0001262039-14-000036 — 2.02, 9.01
- 2014-07-23 0001262039-14-000030 — 2.02, 9.01
- 2014-06-24 0001262039-14-000027 — 5.07
- 2014-04-23 0001262039-14-000021 — 2.02, 9.01
- 2014-04-21 0001262039-14-000018 — 5.03, 9.01
- 2014-01-29 0001262039-14-000004 — 2.02, 9.01
- 2013-12-20 0001262039-13-000061 — 5.02, 9.01
- 2013-11-27 0001262039-13-000057 — 5.02, 7.01, 9.01
- 2013-11-12 0001445305-13-002993 — 5.02
- 2013-10-23 0001262039-13-000051 — 2.02, 9.01
- 2013-07-30 0001262039-13-000039 — 2.02, 9.01
- 2013-06-25 0001262039-13-000030 — 5.07
- 2013-04-30 0001262039-13-000023 — 2.02, 9.01
- 2013-04-19 0001262039-13-000020 — 5.02, 9.01
- 2013-04-19 0001262039-13-000018 — 5.02 — amendment of 0001262039-13-000020
- 2013-04-10 0001262039-13-000016 — 2.02, 9.01
- 2013-03-26 0001262039-13-000013 — 5.02
- 2013-01-30 0001262039-13-000005 — 2.02, 9.01
- 2013-01-24 0001262039-13-000002 — 5.02, 9.01
- 2012-10-16 0001262039-12-000048 — 2.02, 9.01
- 2012-10-01 0001262039-12-000045 — 5.02
- 2012-09-26 0001262039-12-000043 — 5.01
- 2012-07-25 0001262039-12-000038 — 2.02, 9.01
- 2012-07-19 0001262039-12-000034 — 5.02
- 2012-06-20 0001193125-12-275869 — 5.07
- 2012-04-27 0001262039-12-000029 — 5.02
- 2012-04-24 0001262039-12-000025 — 2.02, 9.01
- 2012-01-31 0001262039-12-000006 — 2.02, 9.01
- 2012-01-25 0001262039-12-000003 — 5.03
- 2011-10-24 0001262039-11-000036 — 2.02
- 2011-07-19 0001262039-11-000014 — 2.02, 9.01
- 2011-06-27 0001193125-11-174474 — 5.02, 5.07, 9.01
- 2011-04-27 0001193125-11-111938 — 2.02, 9.01
- 2011-01-25 0001193125-11-013914 — 2.02, 9.01
- 2010-10-21 0001193125-10-233676 — 2.02, 9.01
- 2010-09-02 0001193125-10-203099 — 8.01
- 2010-07-22 0001193125-10-163844 — 2.02, 9.01
- 2010-06-24 0001193125-10-146082 — 5.07
- 2010-04-28 0001193125-10-096698 — 2.02, 9.01
- 2010-02-09 0001193125-10-024614 — 8.01
- 2010-01-27 0001193125-10-014292 — 2.02, 9.01
- 2010-01-26 0001193125-10-013031 — 5.02, 9.01

## late-filing notifications on or before 2021-11-08

- none on or before 2021-11-08

## item 2.02 — earnings release, exhibit 99.1

[0001262039-21-000027:8k_2_02:1]
EX-99.1
2
ftntq3-2021ex991.htm
PRESS RELEASE

[0001262039-21-000027:8k_2_02:2]
Document

[0001262039-21-000027:8k_2_02:3]
Press Release

[0001262039-21-000027:8k_2_02:4]
Fortinet Reports Third Quarter 2021 Financial Results

[0001262039-21-000027:8k_2_02:5]
Third Quarter 2021 Highlights

[0001262039-21-000027:8k_2_02:6]
•Total revenue of $867.2 million, up 33% year over year

[0001262039-21-000027:8k_2_02:7]
•Product revenue of $337.1 million, up 51% year over year

[0001262039-21-000027:8k_2_02:8]
•Service revenue of $530.1 million, up 24% year over year

[0001262039-21-000027:8k_2_02:9]
•Billings of $1.06 billion, up 42% year over year1

[0001262039-21-000027:8k_2_02:10]
•Deferred revenue of $3.11 billion, up 30% year over year

[0001262039-21-000027:8k_2_02:11]
•GAAP operating margin of 19.2%

[0001262039-21-000027:8k_2_02:12]
•Non-GAAP operating margin of 25.8%1

[0001262039-21-000027:8k_2_02:13]
•GAAP diluted net income per share attributable to Fortinet, Inc. common stockholders of $0.97

[0001262039-21-000027:8k_2_02:14]
•Non-GAAP diluted net income per share attributable to Fortinet, Inc. common stockholders of $0.991

[0001262039-21-000027:8k_2_02:15]
•Cash flow from operations of $398.8 million

[0001262039-21-000027:8k_2_02:16]
•Free cash flow of $329.8 million1

[0001262039-21-000027:8k_2_02:17]
SUNNYVALE, Calif. - November 4, 2021 - Fortinet® (Nasdaq: FTNT), a global leader in broad, integrated and automated cybersecurity solutions, today announced financial results for the third quarter ended September 30, 2021.

[0001262039-21-000027:8k_2_02:18]
“We are extremely pleased with our third quarter performance as we exceeded $1 billion in quarterly billings for the first time in Fortinet’s history. Additionally, Gartner again recognized our Secure SD-WAN solution as a Leader in the 2021 Magic Quadrant for WAN Edge Infrastructure while placing highest in its ability to execute,” said Ken Xie, Founder, Chairman, and Chief Executive Officer. “The total addressable market for network security is rapidly expanding from the data center outward to the local and wide-area networks, to the work-from-anywhere environment and to the cloud. We are focused on leveraging our ASIC-supported security fabric platform across this expanding total addressable market to drive better than industry average long-term growth for Fortinet.”

[0001262039-21-000027:8k_2_02:19]
Financial Highlights for the Third Quarter of 2021

[0001262039-21-000027:8k_2_02:20]
•Revenue: Total revenue was $867.2 million for the third quarter of 2021, an increase of 33.2% compared to $651.1 million for the same quarter of 2020.

[0001262039-21-000027:8k_2_02:21]
•Product Revenue: Product revenue was $337.1 million for the third quarter of 2021, an increase of 50.6% compared to $223.8 million for the same quarter of 2020.

[0001262039-21-000027:8k_2_02:22]
•Service Revenue: Service revenue was $530.1 million for the third quarter of 2021, an increase of 24.1% compared to $427.3 million for the same quarter of 2020.

[0001262039-21-000027:8k_2_02:23]
•Billings1: Total billings were $1.06 billion for the third quarter of 2021, an increase of 41.9% compared to $749.8 million for the same quarter of 2020.

[0001262039-21-000027:8k_2_02:24]
•Deferred Revenue: Total deferred revenue was $3.11 billion as of September 30, 2021, an increase of 29.9% compared to $2.39 billion as of September 30, 2020.

[0001262039-21-000027:8k_2_02:25]
•GAAP Operating Income and Margin: GAAP operating income was $166.4 million for the third quarter of 2021, representing a GAAP operating margin of 19.2%. GAAP operating income was $126.9 million for the same quarter of 2020, representing a GAAP operating margin of 19.5%.

[0001262039-21-000027:8k_2_02:26]
•Non-GAAP Operating Income and Margin1: Non-GAAP operating income was $223.6 million for the third quarter of 2021, representing a non-GAAP operating margin of 25.8%. Non-GAAP operating income was $178.6 million for the same quarter of 2020, representing a non-GAAP operating margin of 27.4%.

[0001262039-21-000027:8k_2_02:27]
•GAAP Net Income and Diluted Net Income Per Share Attributable to Fortinet, Inc. Common Stockholders: GAAP net income was $163.1 million for the third quarter of 2021, compared to GAAP net income of $123.4 million for the same quarter of 2020. GAAP diluted net income per share was $0.97 for the third quarter of 2021, based on 167.7 million diluted weighted-average shares outstanding, compared to GAAP diluted net income per share of $0.75 for the same quarter of 2020, based on 165.6 million diluted weighted-average shares outstanding.

[0001262039-21-000027:8k_2_02:28]
•Non-GAAP Net Income and Diluted Net Income Per Share Attributable to Fortinet, Inc. Common Stockholders1: Non-GAAP net income was $165.9 million for the third quarter of 2021, compared to non-GAAP net income of $145.4 million for the same quarter of 2020. Non-GAAP diluted net income per share was $0.99 for the third quarter of 2021, based on 167.7 million diluted weighted-average shares outstanding, compared to $0.88 for the same quarter of 2020, based on 165.6 million diluted weighted-average shares outstanding.

[0001262039-21-000027:8k_2_02:29]
•Cash Flow: Cash flow from operations was $398.8 million for the third quarter of 2021, compared to $220.8 million for the same quarter of 2020.

[0001262039-21-000027:8k_2_02:30]
•Free Cash Flow1: Free cash flow was $329.8 million for the third quarter of 2021, compared to $185.7 million for the same quarter of 2020.

[0001262039-21-000027:8k_2_02:31]
•Share Repurchase Program: In October 2021, Fortinet’s Board of Directors authorized a $1.25 billion increase in the authorized stock repurchase under the Repurchase Program and extended the term of the Repurchase Program to February 28, 2023. As of November 1, 2021, approximately $2 billion remained available for future share repurchases.

[0001262039-21-000027:8k_2_02:32]
Guidance

[0001262039-21-000027:8k_2_02:33]
For the fourth quarter of 2021, Fortinet currently expects:

[0001262039-21-000027:8k_2_02:34]
•Revenue in the range of $940 million to $970 million

[0001262039-21-000027:8k_2_02:35]
•Billings in the range of $1.165 billion to $1.215 billion

[0001262039-21-000027:8k_2_02:36]
•Non-GAAP gross margin in the range of 75.0% to 76.0%

[0001262039-21-000027:8k_2_02:37]
•Non-GAAP operating margin in the range of 27.0% to 28.0%

[0001262039-21-000027:8k_2_02:38]
•Diluted non-GAAP net income per share attributable to Fortinet, Inc. common stockholders in the range of $1.10 to $1.15, assuming a non-GAAP effective tax rate of 21%. This assumes a diluted share count of 168 million to 170 million.

[0001262039-21-000027:8k_2_02:39]
For the fiscal year 2021, Fortinet currently expects:

[0001262039-21-000027:8k_2_02:40]
•Revenue in the range of $3.320 billion to $3.350 billion

[0001262039-21-000027:8k_2_02:41]
•Service revenue in the range of $2.080 billion to $2.090 billion

[0001262039-21-000027:8k_2_02:42]
•Billings in the range of $4.040 billion to $4.090 billion

[0001262039-21-000027:8k_2_02:43]
•Non-GAAP gross margin in the range of 76.5% to 77.5%

[0001262039-21-000027:8k_2_02:44]
•Non-GAAP operating margin in the range of 25.5% to 26.5%

[0001262039-21-000027:8k_2_02:45]
•Diluted non-GAAP net income per share attributable to Fortinet, Inc. common stockholders in the range of $3.85 to $3.95, assuming a non-GAAP effective tax rate of 21%. This assumes a diluted share count of 167 million to 169 million.

[0001262039-21-000027:8k_2_02:46]
Our guidance with respect to non-GAAP financial measures excludes stock-based compensation, amortization of acquired intangible assets and gain on intellectual property matter. We have not reconciled our guidance with respect to non-GAAP financial measures to the corresponding GAAP measures because certain items that impact these measures are uncertain or out of our control, or cannot be reasonably predicted. Accordingly, a reconciliation of these non-GAAP financial measures to the corresponding GAAP measures is not available without unreasonable effort.

[0001262039-21-000027:8k_2_02:47]
1 A reconciliation of GAAP to non-GAAP measures has been provided in the financial statement tables included in this press release. An explanation of these measures is also included below under the heading “Non-GAAP Financial Measures”.

[0001262039-21-000027:8k_2_02:48]
Conference Call Details

[0001262039-21-000027:8k_2_02:49]
Fortinet will host a conference call today at 1:30 p.m. Pacific Time (4:30 p.m. Eastern Time) to discuss the earnings results. The call can be accessed by dialing (877) 303-6913 (domestic) or (224) 357-2188 (international) with conference ID # 2990496. A live webcast of the conference call and supplemental slides will be accessible from the Investor Relations page of Fortinet’s website at https://investor.fortinet.com and a replay will be archived and accessible at https://investor.fortinet.com/events-and-presentations. A replay of this conference call can also be accessed through November 11, 2021 by dialing (855) 859-2056 (domestic) or (404) 537-3406 (international) with conference ID # 2990496.

[0001262039-21-000027:8k_2_02:50]
Fourth Quarter 2021 Virtual Conference Participation Schedule:

[0001262039-21-000027:8k_2_02:51]
•Wells Fargo Virtual 5th Annual TMT Summit

[0001262039-21-000027:8k_2_02:52]
November 30, 2021

[0001262039-21-000027:8k_2_02:53]
•Nasdaq 45th Investor Conference

[0001262039-21-000027:8k_2_02:54]
December 1 - 2, 2021

[0001262039-21-000027:8k_2_02:55]
•UBS Global TMT Virtual Conference

[0001262039-21-000027:8k_2_02:56]
December 7, 2021

[0001262039-21-000027:8k_2_02:57]
•Barclays Global Technology, Media and Telecommunications Conference

[0001262039-21-000027:8k_2_02:58]
December 8, 2021

[0001262039-21-000027:8k_2_02:59]
Members of Fortinet’s management team are expected to present at these conferences and discuss the latest company strategies and initiatives. Fortinet’s conference presentations are expected to be available via webcast on the company’s web site. To access the most updated information and listen to the webcast of each event, please visit the Investor Relations page of Fortinet’s website at https://investor.fortinet.com. The schedule is subject to change.

[0001262039-21-000027:8k_2_02:60]
About Fortinet (www.fortinet.com)

[0001262039-21-000027:8k_2_02:61]
Fortinet (Nasdaq: FTNT) secures the largest enterprise, service provider, and government organizations around the world. Fortinet empowers its customers with complete visibility and control across the expanding attack surface and the power to take on ever-increasing performance requirements today and into the future. The Fortinet Security Fabric platform can address the most critical security challenges and protect data across the entire digital infrastructure, whether in networked, application, multi-cloud or edge environments. Both a technology company and a learning organization, the Fortinet Network Security Institute has one of the largest and broadest cybersecurity training programs in the industry. Learn more at https://www.fortinet.com, the Fortinet Blog or FortiGuard Labs.

[0001262039-21-000027:8k_2_02:62]
#          #          #

[0001262039-21-000027:8k_2_02:63]
Copyright © 2021 Fortinet, Inc. All rights reserved. The symbols ® and ™ denote respectively federally registered trademarks and common law trademarks of Fortinet, Inc., its subsidiaries and affiliates. Fortinet’s trademarks include, but are not limited to, the following: Fortinet, the Fortinet logo, FortiGate, FortiOS, FortiGuard, FortiCare, FortiAnalyzer, FortiManager, FortiASIC, FortiClient, FortiCloud, FortiMail, FortiSandbox, FortiADC, FortiAI, FortiAIOps, FortiAntenna, FortiAP, FortiAuthenticator, FortiCache, FortiCall, FortiCam, FortiCamera, FortiCarrier, FortiCASB, FortiCentral, FortiConnect, FortiController, FortiConverter, FortiCWP, FortiDB, FortiDDoS, FortiDeceptor, FortiDeploy, FortiDirector, FortiEDR, FortiExplorer, FortiExtender, FortiFirewall, FortiFone, FortiGSLB, FortiHypervisor, FortiInsight, FortiIsolator, FortiLAN, FortiLink, FortiMoM, FortiMonitor, FortiNAC, FortiPenTest, FortiPhish, FortiPlanner, FortiPortal, FortiPresence, FortiProxy, FortiRecorder, FortiSASE, FortiSDNConnector, FortiSIEM, FortiSMS, FortiSOAR, FortiSwitch, FortiTester, FortiToken, FortiVoice, FortiWAN, FortiWeb, FortiWiFi, FortiWLC and FortiWLM. Other trademarks belong to their respective owners. Fortinet has not independently verified statements or certifications herein attributed to third parties and Fortinet does not independently endorse such statements. Notwithstanding anything to the contrary herein, nothing herein constitutes a warranty, guarantee, contract, binding specification or other binding commitment by Fortinet or any indication of intent related to a binding commitment, and performance and other specification information herein may be unique to certain environments.

[0001262039-21-000027:8k_2_02:64]
FTNT-F

[0001262039-21-000027:8k_2_02:65]
Forward-Looking Statements

[0001262039-21-000027:8k_2_02:66]
This press release contains forward-looking statements that involve risks and uncertainties. These forward-looking statements include statements regarding demand for our products and services, guidance and expectations around future financial results, including guidance and

[0001262039-21-000027:8k_2_02:67]
COVID-19 Impact

[0001262039-21-000027:8k_2_02:68]
While the broader implications of the COVID-19 pandemic on our employees and overall financial performance remain uncertain, we have seen certain impacts on our business and operations, results of operations, financial condition, cash flows, liquidity and capital and financial resources. Going forward, the situation is uncertain, rapidly changing and hard to

[0001262039-21-000027:8k_2_02:69]
predict, and the COVID-19 pandemic may have a material negative impact on our future periods, including our results for the three months ending December 31, 2021, our annual results for 2021, and beyond. To highlight the uncertainty remaining for the three-month period ending December 31, 2021, it should be noted that, due to customer buying patterns and the efforts of our sales force and channel partners to meet or exceed quarterly quotas, we have historically received a substantial portion of each quarter’s sales orders and generated a substantial portion of each quarter’s billings and revenue during the last two weeks of the quarter. Additionally, supply chain challenges are impacting businesses around the world. If we experience significant changes in our billings growth rates or if we are unable to supply product to meet demand, it will impact product revenue in the current quarter and FortiGuard and FortiCare service revenues in subsequent quarters, as we sell annual and multi-year service contracts that are recognized ratably over the contractual service term. In addition, the broader implications of the pandemic on our business and operations and our financial results, including the extent to which the effects of the pandemic will impact future results and growth in the cybersecurity industry, remain uncertain. The duration and severity of the economic downturn from the pandemic may negatively impact our business and operations, results of operations, financial condition, cash flows, liquidity and capital and financial resources in a material way. As a result, the effects of the pandemic may not be fully reflected in our results of operations until future periods.

[0001262039-21-000027:8k_2_02:70]
Non-GAAP Financial Measures

[0001262039-21-000027:8k_2_02:71]
We have provided in this release financial information that has not been prepared in accordance with U.S. Generally Accepted Accounting Principles (GAAP). These non-GAAP financial and liquidity measures are not based on any standardized methodology prescribed by GAAP and are not necessarily comparable to similar measures presented by other companies. We use these non-GAAP financial measures internally in analyzing our financial results and believe they are useful to investors, as a supplement to GAAP measures, in evaluating our ongoing operational performance. We believe that the use of these non-GAAP financial measures provides an additional tool for investors to use in evaluating ongoing operating results and trends and in comparing our financial results with peer companies, many of which present similar non-GAAP financial measures to investors.

[0001262039-21-000027:8k_2_02:72]
Non-GAAP financial measures should not be considered in isolation from, or as a substitute for, financial information prepared in accordance with GAAP. Investors are encouraged to review the reconciliation of these non-GAAP financial measures to their most directly comparable GAAP financial measures provided in the financial statement tables below.

[0001262039-21-000027:8k_2_02:73]
Billings (non-GAAP). We define billings as revenue recognized in accordance with GAAP plus the change in deferred revenue from the beginning to the end of the period, less any deferred revenue balances acquired from business combination(s) during the period. We consider billings to be a useful metric for management and investors because billings drive current and future revenue, which is an important indicator of the health and viability of our business. There are a number of limitations related to the use of billings instead of GAAP revenue. First, billings include amounts that have not yet been recognized as revenue and are impacted by the term of security and support agreements. Second, we may calculate billings in a manner that is different from peer companies that report similar financial measures. Management accounts for these limitations by providing specific information regarding GAAP revenue and evaluating billings together with GAAP revenue.

[0001262039-21-000027:8k_2_02:74]
Free cash flow (non-GAAP). We define free cash flow as net cash provided by operating activities minus purchases of property and equipment and excluding any significant non-recurring items, such as proceeds from intellectual property matter. We believe free cash flow to be a liquidity measure that provides useful information to management and investors about the amount of cash generated by the business that, after capital expenditures and net of proceeds

[0001262039-21-000027:8k_2_02:75]
from intellectual property matter, can be used for strategic opportunities, including repurchasing outstanding common stock, investing in our business, making strategic acquisitions and strengthening the balance sheet. A limitation of using free cash flow rather than the GAAP measures of cash provided by or used in operating activities, investing activities, and financing activities is that free cash flow does not represent the total increase or decrease in the cash and cash equivalents balance for the period because it excludes cash flows from significant non-recurring items, such as proceeds from intellectual property matter, investing activities other than capital expenditures and cash flows from financing activities. Management accounts for this limitation by providing information about our capital expenditures and other investing and financing activities on the face of the cash flow statement and under the caption “Management’s Discussion and Analysis of Financial Condition and Results of Operations—Liquidity and Capital Resources” in our most recent Quarterly Report on Form 10-Q and Annual Report on Form 10-K and by presenting cash flows from investing and financing activities in our reconciliation of free cash flow. In addition, it is important to note that other companies, including companies in our industry, may not use free cash flow, may calculate free cash flow in a different manner than we do or may use other financial measures to evaluate their performance, all of which could reduce the usefulness of free cash flow as a comparative measure.

[0001262039-21-000027:8k_2_02:76]
Non-GAAP operating income and operating margin. We define non-GAAP operating income as operating income plus stock-based compensation, impairment and amortization of acquired intangible assets, less gain on intellectual property matter and, when applicable, other significant non-recurring items in a given quarter, such as non-recurring gains or losses on litigation-related matters. Non-GAAP operating margin is defined as non-GAAP operating income divided by GAAP revenue. We consider these non-GAAP financial measures to be useful metrics for management and investors because they exclude the items noted above so that our management and investors can compare our recurring core business operating results over multiple periods. There are a number of limitations related to the use of non-GAAP operating income instead of operating income calculated in accordance with GAAP. First, non-GAAP operating income excludes the items noted above. Second, the components of the costs that we exclude from our calculation of non-GAAP operating income may differ from the components that peer companies exclude when they report their non-GAAP results of operations. Management accounts for these limitations by providing specific information regarding the GAAP amounts excluded from non-GAAP operating income and evaluating non-GAAP operating income together with operating income calculated in accordance with GAAP.

[0001262039-21-000027:8k_2_02:77]
Non-GAAP net income and diluted net income per share attributable to Fortinet, Inc. common stockholders. We define non-GAAP net income as net income or loss plus the items noted above under non-GAAP operating income and operating margin. In addition, we adjust non-GAAP net income and diluted net income per share for gains or losses on investments in privately held companies, a tax adjustment required for an effective tax rate on a non-GAAP basis and adjustments attributable to non-controlling interests, which differs from the GAAP effective tax rate. We define non-GAAP diluted net income per share as non-GAAP net income divided by the non-GAAP diluted weighted-average shares outstanding. We consider these non-GAAP financial measures to be useful metrics for management and investors for the same reasons that we use non-GAAP operating income and non-GAAP operating margin. However, in order to provide a more complete picture of our recurring core business operating results, we include in non-GAAP net income and non-GAAP diluted net income per share, the tax adjustment required resulting in an effective tax rate on a non-GAAP basis, which often differs from the GAAP tax rate. We believe the non-GAAP effective tax rates we use are reasonable estimates of normalized tax rates for our current and prior fiscal years under our global operating structure. The same limitations described above regarding our use of non-GAAP operating income and non-GAAP operating margin apply to our use of non-GAAP net income and non-GAAP diluted net income per share. We account for these limitations by providing specific information regarding the GAAP amounts excluded from non-GAAP net income and non-GAAP diluted net income per share and evaluating non-GAAP net income and

[0001262039-21-000027:8k_2_02:78]
non-GAAP diluted net income per share together with net income or loss and diluted net income per share calculated in accordance with GAAP.

[0001262039-21-000027:8k_2_02:79]
FORTINET, INC.

[0001262039-21-000027:8k_2_02:80]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001262039-21-000027:8k_2_02:81]
(Unaudited, in millions)

[0001262039-21-000027:8k_2_02:82]
|  | September 30,2021 |  | December 31,2020 |
| ASSETS |  |  |  |
| CURRENT ASSETS: |  |  |  |
| Cash and cash equivalents | $ | 1,852.1 |  |  | $ | 1,061.8 |  |
| Short-term investments | 1,228.1 |  |  | 775.5 |  |
| Marketable equity securities | 40.8 |  |  | — |  |
| Accounts receivable—net | 604.9 |  |  | 720.0 |  |
| Inventory | 177.9 |  |  | 139.8 |  |
| Prepaid expenses and other current assets | 59.7 |  |  | 43.3 |  |
| Total current assets | 3,963.5 |  |  | 2,740.4 |  |
| LONG-TERM INVESTMENTS | 298.2 |  |  | 118.3 |  |
| PROPERTY AND EQUIPMENT—NET | 556.6 |  |  | 448.0 |  |
| DEFERRED CONTRACT COSTS | 378.8 |  |  | 304.8 |  |
| DEFERRED TAX ASSETS | 337.3 |  |  | 245.2 |  |
| GOODWILL AND OTHER INTANGIBLE ASSETS—NET | 198.6 |  |  | 124.6 |  |
| OTHER ASSETS | 237.6 |  |  | 63.2 |  |
| TOTAL ASSETS | $ | 5,970.6 |  |  | $ | 4,044.5 |  |
| LIABILITIES AND EQUITY |  |  |  |
| CURRENT LIABILITIES: |  |  |  |
| Accounts payable | $ | 142.3 |  |  | $ | 141.6 |  |
| Accrued liabilities | 247.8 |  |  | 149.2 |  |
| Accrued payroll and compensation | 174.2 |  |  | 145.9 |  |
| Current portion of long-term debt | 17.6 |  |  | — |  |
| Deferred revenue | 1,616.1 |  |  | 1,392.8 |  |
| Total current liabilities | 2,198.0 |  |  | 1,829.5 |  |
| DEFERRED REVENUE | 1,490.3 |  |  | 1,212.5 |  |
| INCOME TAX LIABILITIES | 96.5 |  |  | 90.3 |  |
| LONG-TERM DEBT | 988.0 |  |  | — |  |
| OTHER LIABILITIES | 62.2 |  |  | 56.2 |  |
| Total liabilities | 4,835.0 |  |  | 3,188.5 |  |
| COMMITMENTS AND CONTINGENCIES |  |  |  |
| EQUITY: |  |  |  |
| Common stock | 0.2 |  |  | 0.2 |  |
| Additional paid-in capital | 1,257.7 |  |  | 1,207.2 |  |
| Accumulated other comprehensive income (loss) | (1.2) |  |  | 0.7 |  |
| Accumulated deficit | (138.6) |  |  | (352.1) |  |
| Total Fortinet, Inc. stockholders’ equity | 1,118.1 |  |  | 856.0 |  |
| Non-controlling interests | 17.5 |  |  | — |  |
| Total equity | 1,135.6 |  |  | 856.0 |  |
| TOTAL LIABILITIES AND EQUITY | $ | 5,970.6 |  |  | $ | 4,044.5 |  |

[0001262039-21-000027:8k_2_02:83]
FORTINET, INC.

[0001262039-21-000027:8k_2_02:84]
CONDENSED CONSOLIDATED STATEMENTS OF INCOME

[0001262039-21-000027:8k_2_02:85]
(Unaudited, in millions, except per share amounts)

[0001262039-21-000027:8k_2_02:86]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30,2021 |  | September 30,2020 |  | September 30,2021 |  | September 30,2020 |
| REVENUE: |  |  |  |  |  |  |  |
| Product | $ | 337.1 |  |  | $ | 223.8 |  |  | $ | 876.1 |  |  | $ | 628.0 |  |
| Service | 530.1 |  |  | 427.3 |  |  | 1,502.5 |  |  | 1,218.4 |  |
| Total revenue | 867.2 |  |  | 651.1 |  |  | 2,378.6 |  |  | 1,846.4 |  |
| COST OF REVENUE: |  |  |  |  |  |  |  |
| Product | 134.3 |  |  | 84.3 |  |  | 341.2 |  |  | 245.0 |  |
| Service | 76.9 |  |  | 54.9 |  |  | 213.5 |  |  | 158.0 |  |
| Total cost of revenue | 211.2 |  |  | 139.2 |  |  | 554.7 |  |  | 403.0 |  |
| GROSS PROFIT: |  |  |  |  |  |  |  |
| Product | 202.8 |  |  | 139.5 |  |  | 534.9 |  |  | 383.0 |  |
| Service | 453.2 |  |  | 372.4 |  |  | 1,289.0 |  |  | 1,060.4 |  |
| Total gross profit | 656.0 |  |  | 511.9 |  |  | 1,823.9 |  |  | 1,443.4 |  |
| OPERATING EXPENSES: |  |  |  |  |  |  |  |
| Research and development | 107.8 |  |  | 90.0 |  |  | 311.6 |  |  | 252.4 |  |
| Sales and marketing | 347.1 |  |  | 266.7 |  |  | 978.0 |  |  | 780.5 |  |
| General and administrative | 35.8 |  |  | 29.4 |  |  | 102.2 |  |  | 87.1 |  |
| Gain on intellectual property matter | (1.1) |  |  | (1.1) |  |  | (3.4) |  |  | (39.0) |  |
| Total operating expenses | 489.6 |  |  | 385.0 |  |  | 1,388.4 |  |  | 1,081.0 |  |
| OPERATING INCOME | 166.4 |  |  | 126.9 |  |  | 435.5 |  |  | 362.4 |  |
| INTEREST INCOME | 1.2 |  |  | 2.5 |  |  | 3.5 |  |  | 15.7 |  |
| INTEREST EXPENSE | (4.6) |  |  | — |  |  | (10.4) |  |  | — |  |
| OTHER EXPENSE—NET | (6.3) |  |  | (1.0) |  |  | (7.5) |  |  | (8.1) |  |
| INCOME BEFORE INCOME TAXES AND LOSS FROM EQUITY METHOD INVESTMENT | 156.7 |  |  | 128.4 |  |  | 421.1 |  |  | 370.0 |  |
| PROVISION FOR (BENEFIT FROM) INCOME TAXES | (9.3) |  |  | 5.0 |  |  | 10.4 |  |  | 28.2 |  |
| LOSS FROM EQUITY METHOD INVESTMENT | (2.8) |  |  | — |  |  | (2.8) |  |  | — |  |
| NET INCOME INCLUDING NON-CONTROLLING INTERESTS | 163.2 |  |  | 123.4 |  |  | 407.9 |  |  | 341.8 |  |
| Less: NET INCOME ATTRIBUTABLE TO NON-CONTROLLING INTERESTS, NET OF TAX | 0.1 |  |  | — |  |  | 0.1 |  |  | — |  |
| NET INCOME ATTRIBUTABLE TO FORTINET, INC. | $ | 163.1 |  |  | $ | 123.4 |  |  | $ | 407.8 |  |  | $ | 341.8 |  |
| Net income per share attributable to Fortinet, Inc. common stockholders: |  |  |  |  |  |  |  |
| Basic | $ | 1.00 |  |  | $ | 0.76 |  |  | $ | 2.50 |  |  | $ | 2.07 |  |
| Diluted | $ | 0.97 |  |  | $ | 0.75 |  |  | $ | 2.44 |  |  | $ | 2.03 |  |
| Weighted-average shares outstanding: |  |  |  |  |  |  |  |
| Basic | 163.5 |  |  | 162.1 |  |  | 163.3 |  |  | 164.8 |  |
| Diluted | 167.7 |  |  | 165.6 |  |  | 167.1 |  |  | 168.4 |  |

[0001262039-21-000027:8k_2_02:87]
FORTINET, INC.

[0001262039-21-000027:8k_2_02:88]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001262039-21-000027:8k_2_02:89]
(Unaudited, in millions)

[0001262039-21-000027:8k_2_02:90]
|  | Nine Months Ended |
|  | September 30,2021 |  | September 30,2020 |
| CASH FLOWS FROM OPERATING ACTIVITIES: |  |  |  |
| Net income including non-controlling interests | $ | 407.9 |  |  | $ | 341.8 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |
| Stock-based compensation | 154.8 |  |  | 143.0 |  |
| Amortization of deferred contract costs | 126.9 |  |  | 99.8 |  |
| Depreciation and amortization | 59.1 |  |  | 52.1 |  |
| Amortization of investment premium | 4.8 |  |  | 0.2 |  |
| Loss from equity method investment | 2.8 |  |  | — |  |
| Other | 4.4 |  |  | 5.8 |  |
| Changes in operating assets and liabilities, net of impact of business combinations: |  |  |  |
| Accounts receivable—net | 130.6 |  |  | (3.1) |  |
| Inventory | (19.5) |  |  | (31.0) |  |
| Prepaid expenses and other current assets | (12.5) |  |  | (4.6) |  |
| Deferred contract costs | (201.0) |  |  | (143.9) |  |
| Deferred tax assets | (91.9) |  |  | 4.4 |  |
| Other assets | (15.7) |  |  | (2.0) |  |
| Accounts payable | (11.8) |  |  | (4.2) |  |
| Accrued liabilities | 77.0 |  |  | 16.5 |  |
| Accrued payroll and compensation | 23.1 |  |  | 19.5 |  |
| Other liabilities | (3.2) |  |  | 10.3 |  |
| Deferred revenue | 497.1 |  |  | 282.6 |  |
| Net cash provided by operating activities | 1,132.9 |  |  | 787.2 |  |
| CASH FLOWS FROM INVESTING ACTIVITIES: |  |  |  |
| Purchases of investments | (1,749.9) |  |  | (776.3) |  |
| Sales of investments | 82.2 |  |  | 141.4 |  |
| Maturities of investments | 1,029.0 |  |  | 730.3 |  |
| Purchases of property and equipment | (144.6) |  |  | (93.6) |  |
| Purchase of investment in privately held company | (160.0) |  |  | — |  |
| Payments made in connection with business combinations, net of cash acquired | (73.4) |  |  | (9.2) |  |
| Purchases of marketable equity securities | (42.5) |  |  | (0.4) |  |
| Net cash used in investing activities | (1,059.2) |  |  | (7.8) |  |
| CASH FLOWS FROM FINANCING ACTIVITIES: |  |  |  |
| Proceeds from long-term borrowings, net of discount and underwriting fees | 989.4 |  |  | — |  |
| Payments for debt issuance costs | (2.4) |  |  | — |  |
| Payments of debt assumed in connection with business combination | (2.2) |  |  | (4.1) |  |
| Repurchase and retirement of common stock | (170.0) |  |  | (1,046.0) |  |
| Proceeds from issuance of common stock | 20.7 |  |  | 18.2 |  |
| Taxes paid related to net share settlement of equity awards | (118.9) |  |  | (86.5) |  |
| Other | (0.2) |  |  | (1.2) |  |
| Net cash provided by (used in) financing activities | 716.4 |  |  | (1,119.6) |  |
| EFFECT OF EXCHANGE RATE CHANGES ON CASH AND CASH EQUIVALENTS | 0.2 |  |  | — |  |
| NET INCREASE (DECREASE) IN CASH AND CASH EQUIVALENTS | 790.3 |  |  | (340.2) |  |
| CASH AND CASH EQUIVALENTS—Beginning of period | 1,061.8 |  |  | 1,222.5 |  |
| CASH AND CASH EQUIVALENTS—End of period | $ | 1,852.1 |  |  | $ | 882.3 |  |
| SUPPLEMENTAL DISCLOSURES OF CASH FLOW INFORMATION: |  |  |  |
| Cash paid for income taxes—net | $ | 69.9 |  |  | $ | 27.6 |  |
| Operating lease liabilities arising from obtaining right-of-use assets | $ | 31.0 |  |  | $ | 14.7 |  |

[0001262039-21-000027:8k_2_02:91]
Reconciliations of non-GAAP results of operations measures to the nearest comparable GAAP measures

[0001262039-21-000027:8k_2_02:92]
(Unaudited, in millions, except per share amounts)

[0001262039-21-000027:8k_2_02:93]
Reconciliation of net cash provided by operating activities to free cash flow

[0001262039-21-000027:8k_2_02:94]
|  | Three Months Ended |
|  | September 30,2021 |  | September 30,2020 |
| Net cash provided by operating activities | $ | 398.8 |  |  | $ | 220.8 |  |
| Less: Purchases of property and equipment | (69.0) |  |  | (35.1) |  |
| Free cash flow | $ | 329.8 |  |  | $ | 185.7 |  |
| Net cash used in investing activities | $ | (307.5) |  |  | $ | (224.6) |  |
| Net cash used in financing activities | $ | (118.7) |  |  | $ | (30.3) |  |

[0001262039-21-000027:8k_2_02:95]
Reconciliation of GAAP operating income to non-GAAP operating income, operating margin, net income and diluted net income per share attributable to Fortinet, Inc. common stockholders

[0001262039-21-000027:8k_2_02:96]
|  | Three Months Ended September 30, 2021 |  | Three Months Ended September 30, 2020 |
|  | GAAP Results |  | Adjustments |  | Non-GAAP Results |  | GAAP Results |  | Adjustments |  | Non-GAAP Results |
| Operating income | $ | 166.4 |  |  | $ | 57.2 |  | (a) | $ | 223.6 |  |  | $ | 126.9 |  |  | $ | 51.7 |  | (b) | $ | 178.6 |  |
| Operating margin | 19.2 | % |  |  |  | 25.8 | % |  | 19.5 | % |  |  |  | 27.4 | % |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | 53.5 |  |  |  |  |  |  | 50.0 |  |  |  |
| Amortization of acquired intangible assets |  |  | 4.8 |  |  |  |  |  |  | 2.8 |  |  |  |
| Gain on intellectual property matter |  |  | (1.1) |  |  |  |  |  |  | (1.1) |  |  |  |
| Tax adjustment |  |  | (54.2) |  | (c) |  |  |  |  | (29.7) |  | (c) |  |
| Adjustments attributable non-controlling interests |  |  | (0.2) |  | (d) |  |  |  |  | — |  |  |  |
| Net income attributable to Fortinet, Inc. | $ | 163.1 |  |  | $ | 2.8 |  |  | $ | 165.9 |  |  | $ | 123.4 |  |  | $ | 22.0 |  |  | $ | 145.4 |  |
| Diluted net income per share attributable to Fortinet, Inc. common stockholders | $ | 0.97 |  |  |  |  | $ | 0.99 |  |  | $ | 0.75 |  |  |  |  | $ | 0.88 |  |
| Shares used in diluted net income per share calculations | 167.7 |  |  |  |  | 167.7 |  |  | 165.6 |  |  |  |  | 165.6 |  |

[0001262039-21-000027:8k_2_02:97]
(a) To exclude $53.5 million of stock-based compensation and $4.8 million of amortization of acquired intangible assets, offset by a $1.1 million gain on intellectual property matter in the three months ended September 30, 2021.

[0001262039-21-000027:8k_2_02:98]
(b) To exclude $50.0 million of stock-based compensation and $2.8 million of amortization of acquired intangible assets, offset by a $1.1 million gain on intellectual property matter in the three months ended September 30, 2020.

[0001262039-21-000027:8k_2_02:99]
(c) Non-GAAP financial information is adjusted to an effective tax rate of 21% and 19% in the three months ended September 30, 2021 and 2020, respectively, on a non-GAAP basis, which differs from the GAAP effective tax rate.

[0001262039-21-000027:8k_2_02:100]
(d) Adjustments include amortization of acquired intangible assets attributable to non-controlling interests and Non-GAAP financial information adjusted to an effective tax rate of 31% for the subsidiary of AlaxalA standalone in the three months ended September 30, 2021.

[0001262039-21-000027:8k_2_02:101]
Reconciliation of total consolidated revenue to total billings

[0001262039-21-000027:8k_2_02:102]
|  | Three Months Ended |
|  | September 30,2021 |  | September 30,2020 |
| Total revenue | $ | 867.2 |  |  | $ | 651.1 |  |
| Add: Change in deferred revenue | 201.0 |  |  | 98.9 |  |
| Less: Deferred revenue balance acquired in business combination | (4.1) |  |  | (0.2) |  |
| Total billings | $ | 1,064.1 |  |  | $ | 749.8 |  |

[0001262039-21-000027:8k_2_02:103]
| Investor Contact: |  | Media Contact: |
| Peter Salkowski |  | Sandra Wheatley |
| Fortinet, Inc. |  | Fortinet, Inc. |
| 408-331-4595 |  | 408-391-9408 |
| psalkowski@fortinet.com |  | swheatley@fortinet.com |
