# FTNT notes — 0001262039-21-000030


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001262039-21-000030:notes:1]
SUMMARY OF SIGNIFICANT ACCOUNTING POLICIES
Basis of Presentation and Preparation—The unaudited condensed consolidated financial statements of Fortinet, Inc. and its subsidiaries (collectively, “we,” “us” or “our”) have been prepared in accordance with generally accepted accounting principles in the United States (“GAAP”) for interim financial information, as well as the instructions to Form 10-Q pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (the “SEC”). Accordingly, they do not include all of the information and footnotes required by GAAP for complete financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the year ended December 31, 2020, contained in our Annual Report on Form 10-K filed with the SEC on February 19, 2021. In the opinion of management, all adjustments, which includes normal recurring adjustments, considered necessary for a fair presentation have been included. The results of operations for the three and nine months ended September 30, 2021 are not necessarily indicative of the results to be expected for the full year or for any future periods. The condensed consolidated balance sheet as of December 31, 2020 is derived from the audited consolidated financial statements for the year ended December 31, 2020.

[0001262039-21-000030:notes:2]
The condensed consolidated financial statements include the accounts of Fortinet, Inc. and its subsidiaries. We consolidate all legal entities in which we have an absolute controlling financial interest. All intercompany balances and transactions have been eliminated in consolidation.

[0001262039-21-000030:notes:3]
Investments in common stock or in-substance common stock of entities that provide us with the ability to exercise significant influence, but not an absolute controlling financial interest, over the investee are accounted for under the equity method of accounting. Investments accounted for under the equity method are initially recorded at cost. Subsequently, we recognize our proportionate share of the entities’ net income or loss and the amortization of any basis differences through the condensed consolidated statements of income and as an adjustment to the investment balance. We record our share of the results of equity method investments on a three-month lag basis as income or loss from equity method investments, net of tax in the condensed consolidated statements of income. We evaluate our equity method investments at the end of each reporting period to determine whether events or changes in business circumstances indicate that the carrying value of the investment may not be recoverable. As of September 30, 2021, our investment in Linksys Holdings, Inc. (“Linksys”) was our only equity method investment.

[0001262039-21-000030:notes:4]
[same as prior period, unchanged from 0001262039-21-000022:notes:2]

[0001262039-21-000030:notes:5]
There have been no other material changes to our significant accounting policies as of and for the three and nine months ended September 30, 2021.

[0001262039-21-000030:notes:6]
Recently Adopted Accounting Standards

[0001262039-21-000030:notes:7]
[same as prior period, unchanged from 0001262039-21-000022:notes:5]

[0001262039-21-000030:notes:8]
In December 2019, the Financial Accounting Standards Board (the “FASB”) issued Accounting Standards Update (“ASU”) 2019-12—Income Taxes (“Topic 740”): Simplifying the Accounting for Income Taxes. The amendments in ASU 2019-12 simplify the accounting for income taxes by removing certain exceptions to the general principles in Topic 740. The amendments also improve consistent application and simplification of GAAP for other areas of Topic 740 by clarifying and amending existing guidance. ASU 2019-12 was effective for us beginning on January 1, 2021. The adoption of this guidance did not have any impact on our condensed consolidated financial statements and accompanying disclosures.

[0001262039-21-000030:notes:9]
Recent Accounting Standards Not Yet Effective

[0001262039-21-000030:notes:10]
Business Combinations

[0001262039-21-000030:notes:11]
In October 2021, the FASB issued ASU 2021-08—Business Combinations (“Topic 805”): Accounting for Contract Assets and Contract Liabilities from Contracts with Customers. The amendments in ASU 2021-08 require that an entity 
recognizes and measures contract assets and contract liabilities acquired in a business combination in accordance with ASC 606, Revenue from Contracts with Customers (“Topic 606”). At the acquisition date, an acquirer should account for the related revenue contracts in accordance with Topic 606 as if it had originated the contracts. The amendments improve comparability for both the recognition and measurement of acquired revenue contracts with customers at the date of and after a business combination. ASU 2021-08 will be effective for us beginning on January 1, 2023. We are currently evaluating the impact of ASU 2021-08 on our condensed consolidated financial statements.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001262039-21-000030:notes:12]
[same as prior period, unchanged from 0001262039-21-000022:notes:15]

[0001262039-21-000030:notes:13]
[same as prior period, unchanged from 0001262039-21-000022:notes:16]

[0001262039-21-000030:notes:14]
[same as prior period, unchanged from 0001262039-21-000022:notes:17]

[0001262039-21-000030:notes:15]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30,2021 |  | September 30,2020 |  | September 30,2021 |  | September 30,2020 |
| Product | $ | 337.1 |  |  | $ | 223.8 |  |  | $ | 876.1 |  |  | $ | 628.0 |  |
| Service: |  |  |  |  |  |  |  |
| Security subscription | 287.4 |  |  | 235.4 |  |  | 815.6 |  |  | 669.4 |  |
| Technical support and other | 242.7 |  |  | 191.9 |  |  | 686.9 |  |  | 549.0 |  |
| Total service revenue | 530.1 |  |  | 427.3 |  |  | 1,502.5 |  |  | 1,218.4 |  |
| Total revenue | $ | 867.2 |  |  | $ | 651.1 |  |  | $ | 2,378.6 |  |  | $ | 1,846.4 |  |

[0001262039-21-000030:notes:16]
[same as prior period, unchanged from 0001262039-21-000022:notes:19]

[0001262039-21-000030:notes:17]
During the three months ended September 30, 2021 and September 30, 2020, we recognized $309.2 million and $263.1 million in service revenue that was included in the deferred revenue balance as of December 31, 2020 and December 31, 2019, respectively. During the nine months ended September 30, 2021 and September 30, 2020, we recognized $1.10 billion and $921.7 million in service revenue that was included in the deferred revenue balance as of December 31, 2020 and December 31, 2019, respectively.

[0001262039-21-000030:notes:18]
[same as prior period, unchanged from 0001262039-21-000022:notes:21]

[0001262039-21-000030:notes:19]
As of September 30, 2021, the aggregate amount of the transaction price allocated to remaining performance obligations was $3.11 billion, which was substantially comprised of deferred security subscription and technical support services revenue. We expect to recognize approximately $1.62 billion as revenue over the next 12 months and the remainder thereafter.

[0001262039-21-000030:notes:20]
[same as prior period, unchanged from 0001262039-21-000022:notes:23]

[0001262039-21-000030:notes:21]
[same as prior period, unchanged from 0001262039-21-000022:notes:24]

[0001262039-21-000030:notes:22]
The allowance for credit losses was $2.6 million and $2.5 million as of September 30, 2021 and December 31, 2020, respectively. Provisions, write-offs and recoveries were not material during the nine months ended September 30, 2021 and 2020.

[0001262039-21-000030:notes:23]
[same as prior period, unchanged from 0001262039-21-000022:notes:26]

[0001262039-21-000030:notes:24]
Amortization of deferred contract costs during the three months ended September 30, 2021 and 2020 were $45.1 million and $35.3 million, respectively. Amortization of deferred contract costs during the nine months ended September 30, 2021 and 2020 were $126.9 million and $99.8 million, respectively.


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0001262039-21-000030:notes:25]
FINANCIAL INSTRUMENTS AND FAIR VALUE
The following tables summarize our available-for-sale securities (in millions):

[0001262039-21-000030:notes:26]
|  | September 30, 2021 |
|  | AmortizedCost |  | UnrealizedGains |  | UnrealizedLosses |  | FairValue |
| Commercial paper | $ | 647.0 |  |  | $ | 0.1 |  |  | $ | — |  |  | $ | 647.1 |  |
| Corporate debt securities | 484.6 |  |  | 0.2 |  |  | (0.2) |  |  | 484.6 |  |
| Certificates of deposit and term deposits (1) | 214.5 |  |  | — |  |  | — |  |  | 214.5 |  |
| U.S. government securities | 174.7 |  |  | — |  |  | (0.1) |  |  | 174.6 |  |
| Municipal Bonds | 5.5 |  |  | — |  |  | — |  |  | 5.5 |  |
| Total available-for-sale securities | $ | 1,526.3 |  |  | $ | 0.3 |  |  | $ | (0.3) |  |  | $ | 1,526.3 |  |

[0001262039-21-000030:notes:27]
[same as prior period, unchanged from 0001262039-21-000022:notes:30]

[0001262039-21-000030:notes:28]
The following tables show the gross unrealized losses and the related fair values of our available-for-sale securities that have been in a continuous unrealized loss position (in millions):

[0001262039-21-000030:notes:29]
|  | September 30, 2021 |
|  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
|  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |
| Commercial paper | $ | 116.3 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 116.3 |  |  | $ | — |  |
| Corporate debt securities | 281.0 |  |  | (0.2) |  |  | — |  |  | — |  |  | 281.0 |  |  | (0.2) |  |
| Certificates of deposit and term deposits | 15.8 |  |  | — |  |  | — |  |  | — |  |  | 15.8 |  |  | — |  |
| U.S. government securities | 80.6 |  |  | (0.1) |  |  | — |  |  | — |  |  | 80.6 |  |  | (0.1) |  |
| Municipal Bonds | 5.4 |  |  | — |  |  | — |  |  | — |  |  | 5.4 |  |  | — |  |
| Total available-for-sale securities | $ | 499.1 |  |  | $ | (0.3) |  |  | $ | — |  |  | $ | — |  |  | $ | 499.1 |  |  | $ | (0.3) |  |

[0001262039-21-000030:notes:30]
[same as prior period, unchanged from 0001262039-21-000022:notes:33]

[0001262039-21-000030:notes:31]
[same as prior period, unchanged from 0001262039-21-000022:notes:34]

[0001262039-21-000030:notes:32]
|  | September 30,2021 |  | December 31,2020 |
| Due within one year | $ | 1,228.1 |  |  | $ | 775.5 |  |
| Due within one to three years | 298.2 |  |  | 118.3 |  |
| Total | $ | 1,526.3 |  |  | $ | 893.8 |  |

[0001262039-21-000030:notes:33]
Available-for-sale securities are reported at fair value, with unrealized gains and losses and the related tax impact included as a separate component of equity and in comprehensive income. Accrued interest receivable of $2.4 million as of September 30, 2021 was excluded from the fair value of our available-for-sale securities and was recorded in prepaid expenses and other current assets in our condensed consolidated balance sheet.

[0001262039-21-000030:notes:34]
[same as prior period, unchanged from 0001262039-21-000022:notes:37]

[0001262039-21-000030:notes:35]
Our marketable equity securities were $40.8 million as of September 30, 2021. The changes in fair value of our marketable equity securities are recorded in other expense, net on the condensed consolidated statements of income. We recognized $3.7 million loss and $0.1 million loss during the three months ended September 30, 2021 and 2020, respectively, and $2.9 million loss and $0.3 million gain during the nine months ended September 30, 2021 and 2020, respectively.

[0001262039-21-000030:notes:36]
[same as prior period, unchanged from 0001262039-21-000022:notes:38]

[0001262039-21-000030:notes:37]
[same as prior period, unchanged from 0001262039-21-000022:notes:39]

[0001262039-21-000030:notes:38]
[same as prior period, unchanged from 0001262039-21-000022:notes:40]

[0001262039-21-000030:notes:39]
[same as prior period, unchanged from 0001262039-21-000022:notes:41]

[0001262039-21-000030:notes:40]
We measure the fair value of money market funds, certain U.S. government securities and marketable equity securities using quoted prices in active markets for identical assets. The fair value of all other financial instruments was based on quoted prices for similar assets in active markets, or model-driven valuations using significant inputs derived from or corroborated by observable market data.

[0001262039-21-000030:notes:41]
[same as prior period, unchanged from 0001262039-21-000022:notes:43]

[0001262039-21-000030:notes:42]
[same as prior period, unchanged from 0001262039-21-000022:notes:44]

[0001262039-21-000030:notes:43]
[same as prior period, unchanged from 0001262039-21-000022:notes:45]

[0001262039-21-000030:notes:44]
[same as prior period, unchanged from 0001262039-21-000022:notes:46]

[0001262039-21-000030:notes:45]
[same as prior period, unchanged from 0001262039-21-000022:notes:47]

[0001262039-21-000030:notes:46]
|  | September 30, 2021 |  | December 31, 2020 |
|  | AggregateFairValue |  | QuotedPrices inActiveMarkets ForIdenticalAssets |  | SignificantOtherObservableRemainingInputs |  | SignificantOtherUnobservableRemainingInputs |  | AggregateFairValue |  | QuotedPrices inActiveMarkets ForIdenticalAssets |  | SignificantOtherObservableRemainingInputs |  | SignificantOtherUnobservableRemainingInputs |
|  |  |  | (Level 1) |  | (Level 2) |  | (Level 3) |  |  |  | (Level 1) |  | (Level 2) |  | (Level 3) |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Commercial paper | $ | 651.1 |  |  | $ | — |  |  | $ | 651.1 |  |  | $ | — |  |  | $ | 197.2 |  |  | $ | — |  |  | $ | 197.2 |  |  | $ | — |  |
| Corporate debt securities | 484.6 |  |  | — |  |  | 484.6 |  |  | — |  |  | 413.7 |  |  | — |  |  | 413.7 |  |  | — |  |
| Certificates of deposit and term deposits | 214.5 |  |  | — |  |  | 214.5 |  |  | — |  |  | 112.0 |  |  | — |  |  | 112.0 |  |  | — |  |
| U.S. government securities | 174.6 |  |  | 164.6 |  |  | 10.0 |  |  | — |  |  | 184.9 |  |  | 184.9 |  |  | — |  |  | — |  |
| Money market funds | 32.3 |  |  | 32.3 |  |  | — |  |  | — |  |  | 152.7 |  |  | 152.7 |  |  | — |  |  | — |  |
| Municipal Bonds | 5.5 |  |  | — |  |  | 5.5 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Marketable equity securities | 40.8 |  |  | 40.8 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Total | $ | 1,603.4 |  |  | $ | 237.7 |  |  | $ | 1,365.7 |  |  | $ | — |  |  | $ | 1,060.5 |  |  | $ | 337.6 |  |  | $ | 722.9 |  |  | $ | — |  |
| Reported as: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents | $ | 36.3 |  |  |  |  |  |  |  |  | $ | 166.7 |  |  |  |  |  |  |  |
| Marketable equity securities | 40.8 |  |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  |
| Short-term investments | 1,228.1 |  |  |  |  |  |  |  |  | 775.5 |  |  |  |  |  |  |  |
| Long-term investments | 298.2 |  |  |  |  |  |  |  |  | 118.3 |  |  |  |  |  |  |  |
| Total | $ | 1,603.4 |  |  |  |  |  |  |  |  | $ | 1,060.5 |  |  |  |  |  |  |  |

[0001262039-21-000030:notes:47]
There were no transfers between Level 1 and Level 2 of the fair value hierarchy during the nine months ended September 30, 2021 and year ended December 31, 2020.


## us-gaap:InventoryDisclosureTextBlock

[0001262039-21-000030:notes:48]
[same as prior period, unchanged from 0001262039-21-000022:notes:50]

[0001262039-21-000030:notes:49]
|  | September 30,2021 |  | December 31,2020 |
| Raw materials | $ | 35.6 |  |  | $ | 13.8 |  |
| Work in process | 7.9 |  |  | — |  |
| Finished goods | 134.4 |  |  | 126.0 |  |
| Inventory | $ | 177.9 |  |  | $ | 139.8 |  |


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001262039-21-000030:notes:50]
[same as prior period, unchanged from 0001262039-21-000022:notes:52]

[0001262039-21-000030:notes:51]
|  | September 30,2021 |  | December 31,2020 |
| Land | $ | 128.3 |  |  | $ | 93.3 |  |
| Buildings and improvements | 365.4 |  |  | 150.6 |  |
| Computer equipment and software | 166.4 |  |  | 137.2 |  |
| Leasehold improvements | 38.8 |  |  | 31.9 |  |
| Evaluation units | 19.8 |  |  | 19.8 |  |
| Furniture and fixtures | 27.0 |  |  | 21.3 |  |
| Construction-in-progress | 16.9 |  |  | 166.4 |  |
| Total property and equipment | 762.6 |  |  | 620.5 |  |
| Less: accumulated depreciation | (206.0) |  |  | (172.5) |  |
| Property and equipment—net | $ | 556.6 |  |  | $ | 448.0 |  |

[0001262039-21-000030:notes:52]
In September 2021, we purchased certain real estate in Burnaby, Canada for $37.7 million. The purchase was accounted for under the asset acquisition method. The cost of the assets acquired was allocated to land and buildings based on their relative fair values. The amounts allocated to land and buildings were $16.6 million and $21.1 million, respectively.

[0001262039-21-000030:notes:53]
Depreciation expense was $18.1 million and $13.9 million during the three months ended September 30, 2021 and 2020, respectively. Depreciation expense was $47.4 million and $41.6 million during the nine months ended September 30, 2021 and 2020, respectively.


## us-gaap:InvestmentTextBlock

[0001262039-21-000030:notes:54]
[same as prior period, unchanged from 0001262039-21-000022:notes:56]

[0001262039-21-000030:notes:55]
On March 19, 2021, we invested $75.0 million in cash for shares of the Series A Preferred Stock of Linksys for a 32.6% ownership interest. Linksys provides router connectivity solutions to the consumer and small business markets. On September 24, 2021, we invested an additional $85.0 million in cash for shares of Series A Preferred Stock of Linksys, and as of September 30, 2021, we held 50.8% of the outstanding common stock (on an as-converted basis) of Linksys.

[0001262039-21-000030:notes:56]
We have concluded that our investment in Linksys is an in-substance common stock investment and that we do not hold an absolute controlling financial interest in Linksys, but that we have the ability to exercise significant influence over the operating and financial policies of Linksys. Therefore, we determined to account for this investment using the equity method of accounting. We record our share of Linksys’ financial results on a three-month lag basis. Our share of the earnings of Linksys’ financial results, which are accounted for under the three-month lag basis, was $2.8 million for the three and nine months ended September 30, 2021, and has been recorded in loss from equity method investment on the condensed consolidated statements of income.

[0001262039-21-000030:notes:57]
As of September 30, 2021, the investment was included in other assets on our condensed consolidated balance sheet. Transaction costs related to this investment were not material.

[0001262039-21-000030:notes:58]
Other investments

[0001262039-21-000030:notes:59]
Our other investments in the equity securities of privately held companies without readily determinable fair values totaled $1.0 million as of September 30, 2021 and December 31, 2020.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001262039-21-000030:notes:60]
BUSINESS COMBINATION
AlaxalA Networks Corporation

[0001262039-21-000030:notes:61]
On August 31, 2021, we closed an acquisition of 75% of equity interests in AlaxalA Networks Corporation (“AlaxalA”), a privately held network hardware equipment company in Japan, for $64.2 million in cash. We acquired the equity interest in AlaxalA to help address the increasing need for secure switches integrated with FortiGate Firewalls and Security Fabric functionality, and, over time, to innovate and rebrand certain of AlaxalA’s switches to offer a broader suite of secure switches globally.

[0001262039-21-000030:notes:62]
Under the acquisition method of accounting in accordance with ASC 805, the total preliminary purchase price was allocated to AlaxalA’s identifiable tangible and intangible assets acquired and liabilities assumed based on their estimated fair values using management’s best estimates and assumptions to assign fair value as of the acquisition date. The following table provides the assets acquired and liabilities assumed as of the date of acquisition:

[0001262039-21-000030:notes:63]
| (in millions) | Estimated Fair Value |
| ASSETS |  |
| Cash | $ | 1.1 |  |
| Accounts receivable—net | 15.6 |  |
| Inventory | 33.4 |  |
| Prepaid expenses and other current assets | 2.9 |  |
| Property and equipment | 5.3 |  |
| Goodwill | 29.0 |  |
| Other intangible assets | 48.0 |  |
| Other long-term assets | 2.7 |  |
| TOTAL ASSETS | $ | 138.0 |  |
| LIABILITIES |  |
| Accounts payable | $ | 11.0 |  |
| Current portion of long-term debt | 20.2 |  |
| Accrued and other current liabilities | 14.7 |  |
| Other long-term liabilities | 10.1 |  |
| TOTAL LIABILITIES | $ | 56.0 |  |
| NON-CONTROLLING INTERESTS | $ | 17.8 |  |
| Net purchase consideration | $ | 64.2 |  |

[0001262039-21-000030:notes:64]
The excess of the purchase consideration and the fair value of non-controlling interests over the fair value of net tangible and identified intangible assets acquired was recorded as goodwill, which is not deductible for tax purposes. Goodwill is primarily attributable to the assembled workforce of AlaxalA and the anticipated operational synergies.

[0001262039-21-000030:notes:65]
The fair value of the non-controlling interests of $17.8 million was estimated based on the non-controlling interests’ respective share of the AlaxalA business value.

[0001262039-21-000030:notes:66]
Identified intangible assets acquired and their estimated useful lives (in years) as of August 31, 2021, were as follows (in millions, except years):

[0001262039-21-000030:notes:67]
|  | Fair Value |  | Estimated Useful Life (in years) |
| Developed technology | $ | 26.6 |  |  | 4 |
| Customer relationships | 10.0 |  |  | 10 |
| Trade name | 6.4 |  |  | 10 |
| Backlog | 5.0 |  |  | 1 |
| Total identified intangible assets: | $ | 48.0 |  |  |  |

[0001262039-21-000030:notes:68]
Developed technology relates to AlaxalA’s network equipment. We valued the developed technology using the relief-from-royalty method under the income approach. This method reflects the present value of the projected cash flows that are expected to be generated by the developed technology. The economic useful life was determined based on the technology cycle related to each developed technology, as well as the cash flows over the forecast period.

[0001262039-21-000030:notes:69]
Customer relationships represent the fair value of future projected revenue that will be derived from sales to existing customers of AlaxalA. Customer contracts and related relationships were valued using the multi-period excess earnings method. This method reflects the present value of the projected cash flows that are expected to be generated by the customer contracts and relationships less charges representing the contribution of other assets to those cash flows. The economic useful life was determined based on historical customer turnover rates.

[0001262039-21-000030:notes:70]
Trade name relates to the “AlaxalA” trade name. The fair value was determined by applying the relief-from-royalty method under the income approach. This method is based on the application of a royalty rate to forecasted revenue under the trade name. The economic useful life was determined based on the expected life of the trade name and the cash flows anticipated over the forecast period.

[0001262039-21-000030:notes:71]
Customer backlog relates to the unfulfilled customer contract orders. Backlog was valued using the multi-period excess earnings method. This method reflects the present value of the projected cash flows that are expected to be generated by the execution of the unfulfilled customer contract orders less charges representing the contribution of other assets to those cash flows. The economic useful life was determined based on the anticipated contract orders’ execution timeframe.

[0001262039-21-000030:notes:72]
Our estimates and assumptions are subject to change within the measurement period, which is up to 12 months after the acquisition date. The allocation of the purchase price for this acquisition has been prepared on a preliminary basis and changes to the allocation of certain assets and liabilities may occur as additional information becomes available. The primary areas of the purchase price that are not yet finalized are related to income taxes and the valuation of acquired assets and assumed liabilities.

[0001262039-21-000030:notes:73]
The operating results of the acquired company were included in our condensed consolidated financial statements from the date of acquisition which was August 31, 2021. For the period from September 1, 2021 through September 30, 2021, AlaxalA contributed revenue of $15.6 million. Income before income taxes for the period from September 1, 2021 through September 30, 2021 was not material. Acquisition-related costs for this acquisition were not material and were recorded as general and administrative expense.

[0001262039-21-000030:notes:74]
The following unaudited pro forma financial information presents the combined results of operations of Fortinet, Inc. and AlaxalA, as if AlaxalA had been acquired as of the beginning of business on January 1, 2020. The unaudited pro forma financial information is presented for informational purposes only and is not necessarily indicative of our consolidated results of operations of the combined business that would have been achieved if the acquisition had taken place at the beginning of business on January 1, 2020, or of the results of our future operations of the combined business. The following unaudited pro forma financial information for all periods presented includes purchase accounting adjustments for amortization of acquired intangible assets, depreciation of acquired property and equipment, the purchase accounting effect on inventory acquired and related tax effects (in millions):

[0001262039-21-000030:notes:75]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30,2021 |  | September 30,2020 |  | September 30,2021 |  | September 30,2020 |
| Pro forma revenue | $ | 887.6 |  |  | $ | 684.3 |  |  | $ | 2,460.5 |  |  | $ | 1,939.6 |  |
| Pro forma net income attributable to Fortinet, Inc. | $ | 165.1 |  |  | $ | 122.8 |  |  | $ | 407.3 |  |  | $ | 334.8 |  |

[0001262039-21-000030:notes:76]
ShieldX Networks, Inc.

[0001262039-21-000030:notes:77]
On March 10, 2021, we closed an acquisition of certain assets and liabilities of ShieldX Networks Inc. (“ShieldX”), a provider of a security platform focusing on protecting multi-cloud data centers from the risk of lateral movement that can lead to attacks such as ransomware, data loss and service disruption, for $10.8 million in cash. This acquisition was accounted for as a business combination using the acquisition method of accounting. Of the purchase price, $6.2 million was allocated to goodwill, $4.1 million was allocated to developed technology intangible asset and $0.5 million was allocated to other net assets acquired. Goodwill recorded in connection with this acquisition represents the value we expect to be created through expansion into markets within our existing business and potential cost savings and synergies. All acquired goodwill is expected to be deductible for tax purposes. Acquisition-related costs related to this acquisition were not material and were recorded as general and administrative expense.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001262039-21-000030:notes:78]
[same as prior period, unchanged from 0001262039-21-000022:notes:63]

[0001262039-21-000030:notes:79]
[same as prior period, unchanged from 0001262039-21-000022:notes:64]

[0001262039-21-000030:notes:80]
|  | Amount |
| Balance—December 31, 2020 | $ | 93.0 |  |
| Additions due to business combinations | 35.2 |  |
| Foreign currency translation adjustments | (0.6) |  |
| Balance—September 30, 2021 | $ | 127.6 |  |

[0001262039-21-000030:notes:81]
There were no impairments to goodwill during the nine months ended September 30, 2021 or during prior periods.

[0001262039-21-000030:notes:82]
[same as prior period, unchanged from 0001262039-21-000022:notes:67]

[0001262039-21-000030:notes:83]
[same as prior period, unchanged from 0001262039-21-000022:notes:68]

[0001262039-21-000030:notes:84]
|  | September 30, 2021 |
|  | Weighted-Average Useful Life (in Years) |  | Gross |  | Accumulated Amortization |  | Net |
| Other intangible assets—net: |  |  |  |  |  |  |  |
| Finite-lived intangible assets: |  |  |  |  |  |  |  |
| Developed technologies | 4.0 |  | $ | 89.5 |  |  | $ | 40.8 |  |  | $ | 48.7 |  |
| Customer relationships | 5.7 |  | 34.6 |  |  | 23.0 |  |  | 11.6 |  |
| Trade name | 10.0 |  | 6.3 |  |  | 0.1 |  |  | 6.2 |  |
| Backlog | 1.0 |  | 4.9 |  |  | $ | 0.4 |  |  | 4.5 |  |
| Total other intangible assets—net |  |  | $ | 135.3 |  |  | $ | 64.3 |  |  | $ | 71.0 |  |

[0001262039-21-000030:notes:85]
[same as prior period, unchanged from 0001262039-21-000022:notes:70]

[0001262039-21-000030:notes:86]
Amortization expense was $4.8 million and $2.8 million during the three months ended September 30, 2021 and 2020, respectively. Amortization expense was $11.7 million and $10.5 million during the nine months ended September 30, 2021 and 2020, respectively.

[0001262039-21-000030:notes:87]
[same as prior period, unchanged from 0001262039-21-000022:notes:72]

[0001262039-21-000030:notes:88]
|  | Amount |
| Years: |  |
| 2021 (the remainder of 2021) | $ | 6.8 |  |
| 2022 | 22.9 |  |
| 2023 | 16.3 |  |
| 2024 | 11.5 |  |
| 2025 | 6.2 |  |
| Thereafter | 7.3 |  |
| Total | $ | 71.0 |  |


## us-gaap:EarningsPerShareTextBlock

[0001262039-21-000030:notes:89]
NET INCOME PER SHAREBasic net income per share is computed by dividing net income attributable to Fortinet, Inc. by the weighted-average number of shares of common stock outstanding during the period. Diluted net income per share is computed by dividing net income by the weighted-average number of shares of common stock outstanding during the period, plus the dilutive effects of restricted stock units (“RSUs”) and stock options. Dilutive shares of common stock are determined by applying the treasury stock method.
A reconciliation of the numerator and denominator used in the calculation of basic and diluted net income per share is as follows (in millions, except per share amounts):

[0001262039-21-000030:notes:90]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30,2021 |  | September 30,2020 |  | September 30,2021 |  | September 30,2020 |
| Numerator: |  |  |  |  |  |  |  |
| Net income including non-controlling interests | $ | 163.2 |  |  | $ | 123.4 |  |  | $ | 407.9 |  |  | $ | 341.8 |  |
| Net income attributable to non-controlling interests | 0.1 |  |  | — |  |  | 0.1 |  |  | — |  |
| Net income attributable to Fortinet, Inc. | $ | 163.1 |  |  | $ | 123.4 |  |  | $ | 407.8 |  |  | $ | 341.8 |  |
| Denominator: |  |  |  |  |  |  |  |
| Basic shares: |  |  |  |  |  |  |  |
| Weighted-average common stock outstanding-basic | 163.5 |  |  | 162.1 |  |  | 163.3 |  |  | 164.8 |  |
| Diluted shares: |  |  |  |  |  |  |  |
| Weighted-average common stock outstanding-basic | 163.5 |  |  | 162.1 |  |  | 163.3 |  |  | 164.8 |  |
| Effect of potentially dilutive securities: |  |  |  |  |  |  |  |
| RSUs | 2.4 |  |  | 2.3 |  |  | 2.2 |  |  | 2.4 |  |
| Stock options | 1.8 |  |  | 1.2 |  |  | 1.6 |  |  | 1.2 |  |
| Weighted-average shares used to compute diluted net income per share attributable to Fortinet, Inc. common stockholders | 167.7 |  |  | 165.6 |  |  | 167.1 |  |  | 168.4 |  |
| Net income per share attributable to Fortinet, Inc. common stockholders: |  |  |  |  |  |  |  |
| Basic | $ | 1.00 |  |  | $ | 0.76 |  |  | $ | 2.50 |  |  | $ | 2.07 |  |
| Diluted | $ | 0.97 |  |  | $ | 0.75 |  |  | $ | 2.44 |  |  | $ | 2.03 |  |

[0001262039-21-000030:notes:91]
[same as prior period, unchanged from 0001262039-21-000022:notes:77]

[0001262039-21-000030:notes:92]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30,2021 |  | September 30,2020 |  | September 30,2021 |  | September 30,2020 |
| RSUs | 0.1 |  |  | 0.3 |  |  | 0.2 |  |  | 0.3 |  |
| Stock options | — |  |  | 0.6 |  |  | 0.3 |  |  | 0.5 |  |
| Total | 0.1 |  |  | 0.9 |  |  | 0.5 |  |  | 0.8 |  |


## us-gaap:LesseeOperatingLeasesTextBlock

[0001262039-21-000030:notes:93]
[same as prior period, unchanged from 0001262039-21-000022:notes:79]

[0001262039-21-000030:notes:94]
[same as prior period, unchanged from 0001262039-21-000022:notes:80]

[0001262039-21-000030:notes:95]
[same as prior period, unchanged from 0001262039-21-000022:notes:81]

[0001262039-21-000030:notes:96]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30,2021 |  | September 30,2020 |  | September 30,2021 |  | September 30,2020 |
| Operating lease expense | $ | 6.8 |  |  | $ | 4.8 |  |  | $ | 18.9 |  |  | $ | 13.5 |  |
| Variable lease expense (1) | 0.8 |  |  | 0.7 |  |  | 2.3 |  |  | 1.7 |  |
| Short-term lease expense | 1.0 |  |  | 1.0 |  |  | 2.7 |  |  | 2.9 |  |
| Total lease expense | $ | 8.6 |  |  | $ | 6.5 |  |  | $ | 23.9 |  |  | $ | 18.1 |  |

[0001262039-21-000030:notes:97]
(1) Variable lease expense for the three and nine months ended September 30, 2021 and 2020 predominantly included common area maintenance charges and parking expense.

[0001262039-21-000030:notes:98]
[same as prior period, unchanged from 0001262039-21-000022:notes:84]

[0001262039-21-000030:notes:99]
|  | Classification | September 30,2021 |  | December 31,2020 |
| Operating lease ROU assets - non-current | Other assets | $ | 63.6 |  |  | $ | 49.3 |  |
| Operating lease liabilities - current | Accrued liabilities | $ | 25.0 |  |  | $ | 19.1 |  |
| Operating lease liabilities - non-current | Other liabilities | 40.5 |  |  | 34.0 |  |
| Total operating lease liabilities |  | $ | 65.5 |  |  | $ | 53.1 |  |
| Weighted average remaining lease term in years - operating leases |  | 3.1 |  | 3.5 |
| Weighted average discount rate - operating leases |  | 2.2 | % |  | 3.2 | % |

[0001262039-21-000030:notes:100]
[same as prior period, unchanged from 0001262039-21-000022:notes:86]

[0001262039-21-000030:notes:101]
|  | Nine Months Ended |
|  | September 30,2021 |  | September 30,2020 |
| Cash paid for amounts included in the measurement of lease liabilities |  |  |  |
| Operating cash flows used for operating leases | $ | 18.8 |  |  | $ | 13.8 |  |

[0001262039-21-000030:notes:102]
Maturities of operating lease liabilities as of September 30, 2021 were as follows (in millions):

[0001262039-21-000030:notes:103]
| Year Ending December 31, | Amount |
| 2021 (the remainder of 2021) | $ | 6.8 |  |
| 2022 | 25.0 |  |
| 2023 | 18.4 |  |
| 2024 | 11.8 |  |
| 2025 | 4.3 |  |
| Thereafter | 1.4 |  |
| Total lease payments | 67.7 |  |
| Less imputed interest | (2.2) |  |
| Total | $ | 65.5 |  |

[0001262039-21-000030:notes:104]
As of September 30, 2021, we had additional minimum lease payments of $7.7 million relating to operating leases that had been signed but had not yet commenced. These leases will commence during 2021 and will have lease terms of approximately two to five years.


## us-gaap:DebtDisclosureTextBlock

[0001262039-21-000030:notes:105]
DEBT
2026 and 2031 Senior Notes

[0001262039-21-000030:notes:106]
On March 5, 2021, we issued $1.0 billion aggregate principal amount of senior notes (collectively, the “Senior Notes”), consisting of $500.0 million aggregate principal amount of 1.0% notes due March 15, 2026 (the “2026 Senior Notes”) and $500.0 million aggregate principal amount of 2.2% notes due March 15, 2031 (the “2031 Senior Notes”), in an underwritten registered public offering. The Senior Notes are senior unsecured obligations and rank equally with each other in right of payment and with our other outstanding obligations. We may redeem the Senior Notes at any time in whole or in part for cash, at specified redemption prices that include accrued and unpaid interest, if any, and a make-whole premium. However, no make-whole premium will be paid for redemptions of the 2026 Senior Notes on or after February 15, 2026, or the 2031 Senior Notes on or after December 15, 2030. Interest on the Senior Notes is payable on March 15 and September 15 of each year, beginning on September 15, 2021. As of September 30, 2021, the Senior Notes were recorded as long-term debt, net of discount and issuance costs, which are amortized to interest expense over the respective contractual terms of these notes using the effective interest method.

[0001262039-21-000030:notes:107]
The total outstanding debt is summarized below (in millions, except percentages):

[0001262039-21-000030:notes:108]
|  | Maturity |  | Coupon Rate |  | Effective Interest Rate |  | September 30, 2021 |
| Debt |  |  |  |  |  |  |  |
| 2026 Senior Notes | March 2026 |  | 1.0 | % |  | 1.3 | % |  | $ | 500.0 |  |
| 2031 Senior Notes | March 2031 |  | 2.2 | % |  | 2.3 | % |  | 500.0 |  |
| Total debt |  |  |  |  |  |  | 1,000.0 |  |
| Less: Unamortized discount and debt issuance costs |  |  |  |  |  |  | 12.0 |  |
| Total long-term debt |  |  |  |  |  |  | $ | 988.0 |  |

[0001262039-21-000030:notes:109]
As of September 30, 2021 we accrued interest payable of $0.7 million, and there are no financial covenants with which we must comply. During the three and nine months ended September 30, 2021 we recorded $4.4 million and $10.2 million of total interest expense in relation to these Senior Notes, respectively. No interest costs were capitalized for the three and nine months ended September 30, 2021, as the costs that qualified for capitalization were not material.

[0001262039-21-000030:notes:110]
The total estimated fair value of the outstanding Senior Notes was approximately $991.1 million, including accrued and unpaid interest, as of September 30, 2021. The fair value was determined based on observable market prices of identical instruments in less active markets. The estimated fair values are based on Level 2 inputs.

[0001262039-21-000030:notes:111]
AlaxalA debt

[0001262039-21-000030:notes:112]
In connection with our acquisition of AlaxalA, we assumed certain current debt liabilities of $20.2 million as of August 31, 2021. We concluded that the fair value of debt approximated its book value as of the acquisition date. We had $17.6 million of this debt outstanding and recorded as current portion of long-term debt on our condensed consolidated balance sheet as of September 30, 2021. We repaid this balance in full in October 2021. As of September 30, 2021, the accrued interest under the assumed AlaxalA debt obligations was not material. During the post-acquisition period from September 1, 2021 through September 30, 2021, interest expense related to AlaxalA debt was not material.


## ftnt:MutualCovenantNottoSueAgreementDisclosureTextBlock

[0001262039-21-000030:notes:113]
MUTUAL COVENANT-NOT-TO-SUE AND RELEASE AGREEMENT
In January 2020, we entered into an agreement with a competitor in the network security industry whereby, in February 2020, the competitor party paid us a lump sum of $50.0 million for a seven-year mutual covenant-not-to-sue for patent claims. Pursuant to this agreement, at the end of this first seven-year period, either party may extend the agreement for an additional seven-year mutual covenant-not-to-sue in return for this competitor paying us an additional $50.0 million. This agreement arose after expiration of previous agreements between the parties whereby the competitor had paid us sums for a limited term license to certain of our intellectual property (“IP”) and a limited term mutual covenant-not-to-sue.

[0001262039-21-000030:notes:114]
We concluded that the agreement was a 14-year contract with a total transaction price of $100.0 million, and that it contained two material distinct performance obligations: (1) the right to use our existing patents, and (2) the right to use any

[0001262039-21-000030:notes:115]
patents that we develop over the term of the contract. We allocated $36.0 million to the functional patents, which was recognized upon commencement of the contract; the remaining $64.0 million, representing the right to utilize future patents, will be recognized over the contract term. We further concluded that our existing patents represent functional IP that should be recognized upon granting our competitor access. We also concluded that the right to receive additional functional IP that we will develop in the future represents a stand ready obligation. Therefore, the transaction price allocated to this obligation is recognized ratably over the 14-year contract term. We estimated the stand-alone selling price of each distinct performance obligation and allocated the $100.0 million transaction price.

[0001262039-21-000030:notes:116]
During the three months ended September 30, 2021 and 2020, we recorded $1.1 million gain on IP matter in our condensed consolidated statements of income. During the nine months ended September 30, 2021 and 2020, we recorded $3.4 million and $39.0 million gain on IP matter in our condensed consolidated statements of income, respectively. We recorded $6.4 million and $9.8 million in accrued liabilities and other liabilities in our condensed consolidated balance sheets as of September 30, 2021 and December 31, 2020, respectively.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001262039-21-000030:notes:117]
COMMITMENTS AND CONTINGENCIES
The following table summarizes our inventory purchase commitments as of September 30, 2021 (in millions):

[0001262039-21-000030:notes:118]
|  | Total |  | 2021 |  | 2022 |  | 2023 |  | 2024 |  | 2025 |  | Thereafter |
| Inventory purchase commitments | $ | 868.0 |  |  | $ | 376.7 |  |  | $ | 491.3 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |

[0001262039-21-000030:notes:119]
Inventory Purchase Commitments—Our independent contract manufacturers procure components and build our products based on our forecasts. These forecasts are based on estimates of future demand for our products, which are in turn based on historical trends and an analysis from our sales and marketing organizations, adjusted for supply chain matters and other market conditions. In order to reduce manufacturing lead times, plan for adequate component supply and incentivize suppliers to deliver, we may issue purchase orders to some of our independent contract manufacturers, which are non-cancelable. As of September 30, 2021, we had $868.0 million of open purchase orders with our independent contract manufacturers that are non-cancelable.

[0001262039-21-000030:notes:120]
Other Contractual Commitments and Open Purchase Orders—In addition to commitments with contract manufacturers, we have open purchase orders and contractual obligations in the ordinary course of business for which we have not received goods or services. As of September 30, 2021, we had $68.9 million in other contractual commitments having a remaining term in excess of one year that are non-cancelable.

[0001262039-21-000030:notes:121]
Litigation—We are involved in disputes, litigation, and other legal actions. For lawsuits where we are the defendant, we are in the process of defending these litigation matters, and while there can be no assurances and the outcome of certain of these matters is currently not determinable and not predictable, we currently are unaware of any existing claims or proceedings that we believe are likely to have a material adverse effect on our financial position. There are many uncertainties associated with any litigation and these actions or other third-party claims against us may cause us to incur costly litigation fees, costs and substantial settlement charges, and possibly subject us to damages and other penalties. In addition, the resolution of any IP litigation may require us to make royalty payments, which could adversely affect our gross margins in future periods. If any of those events were to occur, our business, financial condition, results of operations, and cash flows could be adversely affected. Litigation is unpredictable and the actual liability in any such matters may be materially different from our current estimates, which could result in the need to adjust any accrued liability and record additional expenses. We accrue for contingencies when we believe that a loss is probable and that we can reasonably estimate the amount of any such loss.

[0001262039-21-000030:notes:122]
In October 2021, we held settlement discussions related to an existing patent infringement lawsuit. Pursuant to such discussions, we may enter into an agreement that provides for the settlement and dismissal of the patent lawsuit and a mutual covenant not to sue for a defined duration of time.  As a result, we have determined that a loss in connection with such lawsuit is now probable. We accrued $5 million as a loss contingency in the quarter ended September 30, 2021 and the associated charge was recorded against revenue in the income statement. Litigation loss contingency accruals associated with other outstanding cases were not material as of September 30, 2021 and December 31, 2020.

[0001262039-21-000030:notes:123]
Indemnification and Other Matters—Under the indemnification provisions of our standard sales contracts, we agree to defend our customers against third-party claims asserting various allegations such as product defects and infringement of certain IP rights, which may include patents, copyrights, trademarks or trade secrets, and to pay judgments entered on such

[0001262039-21-000030:notes:124]
claims. In some contracts, our exposure under these indemnification provisions is limited by the terms of the contracts to certain defined limits, such as the total amount paid by our customer under the agreement. However, certain agreements include covenants, penalties and indemnification provisions including and beyond indemnification for third-party claims of IP infringement that could potentially expose us to losses in excess of the amount received under the agreement, and in some instances to potential liability that is not contractually limited. Although from time to time there are indemnification claims asserted against us and currently there are pending indemnification claims, to date there have been no material awards under such indemnification provisions.

[0001262039-21-000030:notes:125]
Similar to other security companies and companies in other industries, we have in the past experienced, and we may in the future experience, cybersecurity threats, malicious activity directed against our information technology infrastructure or unauthorized attempts to gain access to our and our customers’ sensitive information and systems. We currently are unaware of any existing claims or proceedings related to these types of matters, including any that we believe are likely to have a material adverse effect on our financial position.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001262039-21-000030:notes:126]
EQUITY
Stock-Based Compensation Plans

[0001262039-21-000030:notes:127]
We maintain the Amended and Restated Fortinet, Inc. 2009 Equity Incentive Plan (the “Amended Plan”) pursuant to which we have granted RSUs and stock options. As of September 30, 2021, there were a total of 11.7 million shares of common stock available for grant under the Amended Plan.

[0001262039-21-000030:notes:128]
[same as prior period, unchanged from 0001262039-21-000022:notes:110]

[0001262039-21-000030:notes:129]
[same as prior period, unchanged from 0001262039-21-000022:notes:111]

[0001262039-21-000030:notes:130]
|  | Restricted Stock Units Outstanding |
|  | Number of Shares |  | Weighted-Average Grant Date Fair Value per Share |
| Balance—December 31, 2020 | 4.7 |  |  | $ | 90.46 |  |
| Granted | 1.1 |  |  | 190.47 |  |
| Forfeited | (0.3) |  |  | 111.20 |  |
| Vested | (1.9) |  |  | 81.15 |  |
| Balance—September 30, 2021 | 3.6 |  |  | $ | 123.67 |  |

[0001262039-21-000030:notes:131]
Stock compensation expense is recognized on a straight-line basis over the vesting period of each RSU. As of September 30, 2021, total compensation expense related to unvested RSUs granted to employees and non-employees under the Amended Plan, but not yet recognized, was $391.2 million, with a weighted-average remaining vesting period of 2.7 years.

[0001262039-21-000030:notes:132]
[same as prior period, unchanged from 0001262039-21-000022:notes:114]

[0001262039-21-000030:notes:133]
[same as prior period, unchanged from 0001262039-21-000022:notes:115]

[0001262039-21-000030:notes:134]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30,2021 |  | September 30,2020 |  | September 30,2021 |  | September 30,2020 |
| Shares withheld for taxes | 0.1 |  |  | 0.2 |  |  | 0.6 |  |  | 0.7 |  |
| Amount withheld for taxes | $ | 42.9 |  |  | $ | 27.6 |  |  | $ | 119.0 |  |  | $ | 86.5 |  |

[0001262039-21-000030:notes:135]
[same as prior period, unchanged from 0001262039-21-000022:notes:117]

[0001262039-21-000030:notes:136]
[same as prior period, unchanged from 0001262039-21-000022:notes:118]

[0001262039-21-000030:notes:137]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30,2021 |  | September 30,2020 |  | September 30,2021 |  | September 30,2020 |
| Expected term in years | 4.4 |  | 4.4 |  | 4.4 |  | 4.4 |
| Volatility | 36.9 | % |  | 39.9 | % |  | 39.2 | % |  | 34.6 | % |
| Risk-free interest rate | 0.7 | % |  | 0.2 | % |  | 0.5 | % |  | 1.1 | % |
| Dividend rate | — | % |  | — | % |  | — | % |  | — | % |

[0001262039-21-000030:notes:138]
[same as prior period, unchanged from 0001262039-21-000022:notes:120]

[0001262039-21-000030:notes:139]
|  | Options Outstanding |
|  | Numberof Shares |  | Weighted-AverageExercisePrice |  | Weighted-AverageRemainingContractualLife (Years) |  | AggregateIntrinsicValue |
| Balance—December 31, 2020 | 2.7 |  |  | $ | 67.53 |  |  | 4.2 |  | $ | 220.4 |  |
| Granted | 0.6 |  |  | 179.95 |  |  |  |  |  |
| Forfeited | (0.1) |  |  | 117.60 |  |  |  |  |  |
| Exercised | (0.4) |  |  | 53.26 |  |  |  |  |  |
| Balance—September 30, 2021 | 2.8 |  |  | $ | 90.20 |  |  |  |  |  |
| Options vested and expected to vest—September 30, 2021 | 2.8 |  |  | $ | 90.20 |  |  | 4.1 |  | $ | 567.2 |  |
| Options exercisable—September 30, 2021 | 1.6 |  |  | $ | 56.62 |  |  | 3.1 |  | $ | 379.9 |  |

[0001262039-21-000030:notes:140]
The aggregate intrinsic value represents the difference between the exercise price of stock options and the quoted market price of our common stock on September 30, 2021 for all in-the-money stock options. Stock compensation expense is recognized on a straight-line basis over the vesting period of each stock option. As of September 30, 2021, total compensation expense related to unvested stock options granted to employees but not yet recognized was $46.6 million, with a weighted-average remaining vesting period of 2.9 years.

[0001262039-21-000030:notes:141]
[same as prior period, unchanged from 0001262039-21-000022:notes:123]

[0001262039-21-000030:notes:142]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30,2021 |  | September 30,2020 |  | September 30,2021 |  | September 30,2020 |
| Weighted-average fair value per share granted | $ | 95.33 |  |  | $ | 43.80 |  |  | $ | 58.69 |  |  | $ | 35.76 |  |
| Intrinsic value of options exercised | $ | 20.9 |  |  | $ | 5.5 |  |  | $ | 60.2 |  |  | $ | 35.8 |  |
| Fair value of options vested | $ | 3.3 |  |  | $ | 2.5 |  |  | $ | 13.9 |  |  | $ | 10.9 |  |

[0001262039-21-000030:notes:143]
[same as prior period, unchanged from 0001262039-21-000022:notes:125]

[0001262039-21-000030:notes:144]
[same as prior period, unchanged from 0001262039-21-000022:notes:126]

[0001262039-21-000030:notes:145]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30,2021 |  | September 30,2020 |  | September 30,2021 |  | September 30,2020 |
| Cost of product revenue | $ | 0.4 |  |  | $ | 0.4 |  |  | $ | 1.3 |  |  | $ | 1.2 |  |
| Cost of service revenue | 4.1 |  |  | 3.3 |  |  | 11.4 |  |  | 9.5 |  |
| Research and development | 14.5 |  |  | 12.7 |  |  | 42.0 |  |  | 35.6 |  |
| Sales and marketing | 27.6 |  |  | 27.7 |  |  | 82.1 |  |  | 81.3 |  |
| General and administrative | 6.9 |  |  | 5.9 |  |  | 20.2 |  |  | 17.3 |  |
| Total stock-based compensation expense | $ | 53.5 |  |  | $ | 50.0 |  |  | $ | 157.0 |  |  | $ | 144.9 |  |

[0001262039-21-000030:notes:146]
[same as prior period, unchanged from 0001262039-21-000022:notes:128]

[0001262039-21-000030:notes:147]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30,2021 |  | September 30,2020 |  | September 30,2021 |  | September 30,2020 |
| RSUs | $ | 48.5 |  |  | $ | 46.4 |  |  | $ | 142.8 |  |  | $ | 134.5 |  |
| Stock options | 5.0 |  |  | 3.6 |  |  | 14.2 |  |  | 10.4 |  |
| Total stock-based compensation expense | $ | 53.5 |  |  | $ | 50.0 |  |  | $ | 157.0 |  |  | $ | 144.9 |  |

[0001262039-21-000030:notes:148]
[same as prior period, unchanged from 0001262039-21-000022:notes:130]

[0001262039-21-000030:notes:149]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30,2021 |  | September 30,2020 |  | September 30,2021 |  | September 30,2020 |
| Income tax benefit associated with stock-based compensation | $ | 11.7 |  |  | $ | 11.0 |  |  | $ | 34.5 |  |  | $ | 31.9 |  |

[0001262039-21-000030:notes:150]
[same as prior period, unchanged from 0001262039-21-000022:notes:132]

[0001262039-21-000030:notes:151]
In July 2020, under the Share Repurchase Program originally approved by our board of directors in January 2016 (the “Repurchase Program”), our board of directors approved a $500.0 million increase and extended the term to February 28, 2022, bringing the aggregate amount authorized to be repurchased to $3.0 billion. Share repurchases may be made by us from time to time in privately negotiated transactions or in open-market transactions. The Repurchase Program does not require us to purchase a minimum number of shares, and may be suspended, modified or discontinued at any time without prior notice. Refer to Note 18. Subsequent Events for information of the approved $1.25 billion increase in the authorized stock repurchase under the Repurchase Program in October 2021.

[0001262039-21-000030:notes:152]
During the three and nine months ended September 30, 2021, we repurchased 0.3 million and 0.8 million shares of common stock, respectively, under the Repurchase Program in open-market transactions at a weighted-average price of $294.07 per share and $242.95 per share, respectively, for an aggregate purchase price of $108.8 million and $200.4 million, respectively. As of September 30, 2021, $812.3 million remained available for future share repurchases under the Repurchase Program.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001262039-21-000030:notes:153]
INCOME TAXESOur effective tax rate was negative 6% for the three months ended September 30, 2021, compared to an effective tax rate of 4% for the same period last year. Our effective tax rate was 2% for the nine months ended September 30, 2021, compared to an effective tax rate of 8% for the same period last year. The effective tax rates for the periods presented are 
primarily comprised of U.S. federal and state taxes, withholding taxes, foreign taxes, the tax benefit from foreign-derived intangible income deduction (the “FDII deduction”) and excess tax benefits from stock-based compensation expense. The tax rates for the three months ended September 30, 2021 and 2020 were composed of U.S. federal and state taxes, withholding taxes and foreign taxes that amounted to $40.1 million and $33.8 million, respectively. The tax rate for the three months ended September 30, 2021 was impacted by a tax benefit of $8.7 million from the FDII deduction and excess tax benefits from stock-based compensation expense of $25.0 million. In addition, the tax rate for the three months ended September 30, 2021 was further impacted by a tax benefit of $15.7 million for a change in tax accounting positions in finalization of the prior year tax return. The tax rate for the three months ended September 30, 2020 was impacted by a tax benefit of $16.3 million from the FDII deduction and excess tax benefits from stock-based compensation expense of $12.5 million.

[0001262039-21-000030:notes:154]
The tax rates for the nine months ended September 30, 2021 and 2020 were composed of U.S. federal and state taxes, withholding taxes and foreign taxes that amounted to $115.8 million and $100.7 million, respectively. The tax rate for the nine months ended September 30, 2021 was impacted by a tax benefit of $23.9 million from the FDII deduction, excess tax benefits from stock-based compensation expense of $60.3 million and release of reserves of $5.5 million on uncertain tax positions and the interest due to the expiration of the statute of limitations. In addition, the tax rate for the nine months ended September 30, 2021 was further impacted by a tax benefit of $15.7 million for a change in tax accounting positions in finalization of the prior year tax return. The tax rate for the nine months ended September 30, 2020 was impacted by a tax benefit of $25.9 million from the FDII deduction, excess tax benefits from stock-based compensation expense of $37.6 million and release of reserves of $9.0 million on uncertain tax positions and the interest due to the expiration of the statute of limitations.

[0001262039-21-000030:notes:155]
As of September 30, 2021 and December 31, 2020, unrecognized tax benefits were $80.7 million and $77.3 million, respectively. If recognized, $73.3 million of the unrecognized tax benefits would favorably affect our effective tax rate. It is our policy to include accrued interest and penalties related to unrecognized tax benefits in income tax expense. As of September 30, 2021 and December 31, 2020, accrued interest and penalties were $16.2 million and $14.5 million, respectively. It is reasonably possible that our gross unrecognized tax benefits will decrease by up to $27.3 million in the next 12 months, due to the lapse of the statute of limitations. This decrease, if recognized, would favorably impact our effective tax rate, and would be recognized as additional tax benefits.

[0001262039-21-000030:notes:156]
[same as prior period, unchanged from 0001262039-21-000022:notes:138]

[0001262039-21-000030:notes:157]
[same as prior period, unchanged from 0001262039-21-000022:notes:139]

[0001262039-21-000030:notes:158]
[same as prior period, unchanged from 0001262039-21-000022:notes:140]


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0001262039-21-000030:notes:159]
DEFINED CONTRIBUTION PLANSOur tax-deferred savings plan under our 401(k) Plan permits participating U.S. employees to contribute a portion of their pre-tax or after-tax earnings. In Canada, we have a Group Registered Retirement Savings Plan Program (the “RRSP”), which permits participants to make tax-deductible contributions. Our board of directors approved 50% matching contributions on employee contributions up to 4% of each employee’s eligible earnings. Our matching contributions to our 401(k) Plan and the RRSP for the three months ended September 30, 2021 and 2020 were $2.5 million and $2.1 million, respectively. Our matching contributions to our 401(k) Plan and the RRSP for the nine months ended September 30, 2021 and 2020 were $7.9 million and $6.5 million, respectively.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001262039-21-000030:notes:160]
[same as prior period, unchanged from 0001262039-21-000022:notes:142]

[0001262039-21-000030:notes:161]
[same as prior period, unchanged from 0001262039-21-000022:notes:143]

[0001262039-21-000030:notes:162]
|  | Three Months Ended |  | Nine Months Ended |
| Revenue | September 30,2021 |  | September 30,2020 |  | September 30,2021 |  | September 30,2020 |
| Americas: |  |  |  |  |  |  |  |
| United States | $ | 258.4 |  |  | $ | 206.0 |  |  | $ | 722.6 |  |  | $ | 589.1 |  |
| Other Americas | 91.7 |  |  | 66.4 |  |  | 255.4 |  |  | 186.9 |  |
| Total Americas | 350.1 |  |  | 272.4 |  |  | 978.0 |  |  | 776.0 |  |
| Europe, Middle East and Africa (“EMEA”) | 323.2 |  |  | 243.3 |  |  | 905.1 |  |  | 693.5 |  |
| Asia Pacific (“APAC”) | 193.9 |  |  | 135.4 |  |  | 495.5 |  |  | 376.9 |  |
| Total revenue | $ | 867.2 |  |  | $ | 651.1 |  |  | $ | 2,378.6 |  |  | $ | 1,846.4 |  |

[0001262039-21-000030:notes:163]
| Property and Equipment—net | September 30,2021 |  | December 31,2020 |
| Americas: |  |  |  |
| United States | $ | 357.1 |  |  | $ | 296.3 |  |
| Canada | 160.9 |  |  | 121.3 |  |
| Latin America | 1.8 |  |  | 2.0 |  |
| Total Americas | 519.8 |  |  | 419.6 |  |
| EMEA | 23.8 |  |  | 20.6 |  |
| APAC | 13.0 |  |  | 7.8 |  |
| Total property and equipment—net | $ | 556.6 |  |  | $ | 448.0 |  |

[0001262039-21-000030:notes:164]
[same as prior period, unchanged from 0001262039-21-000022:notes:146]

[0001262039-21-000030:notes:165]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30,2021 |  | September 30,2020 |  | September 30,2021 |  | September 30,2020 |
| Exclusive Networks Group (“Exclusive”) | 31 | % |  | 29 | % |  | 32 | % |  | 30 | % |
| Ingram Micro, Inc. (“Ingram Micro”) | 12 | % |  | 10 | % |  | 12 | % |  | 10 | % |

[0001262039-21-000030:notes:166]
[same as prior period, unchanged from 0001262039-21-000022:notes:149]

[0001262039-21-000030:notes:167]
|  | September 30,2021 |  | December 31,2020 |
| Exclusive | 30 | % |  | 34 | % |
| TD Synnex | 15 | % |  | * |
| Ingram Micro | 11 | % |  | 11 | % |


## us-gaap:SubsequentEventsTextBlock

[0001262039-21-000030:notes:168]
SUBSEQUENT EVENTS 
Debt Repayment

[0001262039-21-000030:notes:169]
In October 2021, we fully repaid the outstanding $17.6 million of debt liabilities assumed in the AlaxalA transaction.

[0001262039-21-000030:notes:170]
Building Purchase

[0001262039-21-000030:notes:171]
In October 2021, we purchased real property in Texas totaling approximately 87,000 square feet for a cash payment of $22.5 million.

[0001262039-21-000030:notes:172]
In October 2021, our board of directors approved a $1.25 billion increase in the authorized stock repurchase under the Repurchase Program and extended the term of the Repurchase Program to February 28, 2023, bringing the aggregate amount authorized to be repurchased to $4.25 billion of our outstanding common stock through February 28, 2023.
