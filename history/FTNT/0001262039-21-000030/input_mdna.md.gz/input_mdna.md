# FTNT MD&A — 0001262039-21-000030


## mdna

[0001262039-21-000030:mdna:1]
[same as prior period, unchanged from 0001262039-21-000022:mdna:1]

[0001262039-21-000030:mdna:2]
•the effects of supply chain constraints and the global chip and component shortages and other factors affecting our manufacturing capacity, delivery, cost and inventory management;

[0001262039-21-000030:mdna:3]
[same as prior period, unchanged from 0001262039-21-000022:mdna:2]

[0001262039-21-000030:mdna:4]
[same as prior period, unchanged from 0001262039-21-000022:mdna:3]

[0001262039-21-000030:mdna:5]
[same as prior period, unchanged from 0001262039-21-000022:mdna:4]

[0001262039-21-000030:mdna:6]
[same as prior period, unchanged from 0001262039-21-000022:mdna:5]

[0001262039-21-000030:mdna:7]
[same as prior period, unchanged from 0001262039-21-000022:mdna:6]

[0001262039-21-000030:mdna:8]
[same as prior period, unchanged from 0001262039-21-000022:mdna:7]

[0001262039-21-000030:mdna:9]
[same as prior period, unchanged from 0001262039-21-000022:mdna:8]

[0001262039-21-000030:mdna:10]
[same as prior period, unchanged from 0001262039-21-000022:mdna:9]

[0001262039-21-000030:mdna:11]
[same as prior period, unchanged from 0001262039-21-000022:mdna:11]

[0001262039-21-000030:mdna:12]
[same as prior period, unchanged from 0001262039-21-000022:mdna:12]

[0001262039-21-000030:mdna:13]
[same as prior period, unchanged from 0001262039-21-000022:mdna:13]

[0001262039-21-000030:mdna:14]
•risks and expectations related to acquisitions and equity interests in private companies, including integration issues related to product plans and the acquired technology, and risks of negative impact by such acquisitions and equity investments on our financial results;

[0001262039-21-000030:mdna:15]
[same as prior period, unchanged from 0001262039-21-000022:mdna:14]

[0001262039-21-000030:mdna:16]
[same as prior period, unchanged from 0001262039-21-000022:mdna:15]

[0001262039-21-000030:mdna:17]
[same as prior period, unchanged from 0001262039-21-000022:mdna:17]

[0001262039-21-000030:mdna:18]
[same as prior period, unchanged from 0001262039-21-000022:mdna:18]

[0001262039-21-000030:mdna:19]
•expectations regarding uncertain tax benefits and our effective domestic and global tax rates, and the impact of the Tax Cuts and Jobs Act and the Coronavirus Aid, Relief, and Economic Security Act (the “CARES Act”);

[0001262039-21-000030:mdna:20]
27

[0001262039-21-000030:mdna:21]
[same as prior period, unchanged from 0001262039-21-000022:mdna:21]

[0001262039-21-000030:mdna:22]
[same as prior period, unchanged from 0001262039-21-000022:mdna:22]

[0001262039-21-000030:mdna:23]
[same as prior period, unchanged from 0001262039-21-000022:mdna:23]

[0001262039-21-000030:mdna:24]
•statements regarding expected outcomes and liabilities in litigation;

[0001262039-21-000030:mdna:25]
[same as prior period, unchanged from 0001262039-21-000022:mdna:25]

[0001262039-21-000030:mdna:26]
[same as prior period, unchanged from 0001262039-21-000022:mdna:26]

[0001262039-21-000030:mdna:27]
[same as prior period, unchanged from 0001262039-21-000022:mdna:27]

[0001262039-21-000030:mdna:28]
[same as prior period, unchanged from 0001262039-21-000022:mdna:28]

[0001262039-21-000030:mdna:29]
Fortinet is a global leader in cybersecurity solutions provided to a wide variety of organizations, including enterprises, communication service providers and security service providers, government organizations and small businesses. Our cybersecurity solutions are designed to provide broad visibility and segmentation of the digital attack surface through our integrated Fortinet Security Fabric cybersecurity platform, which features automated protection, detection and response. The Fortinet Security Fabric platform leverages a common operating system or integration to this operating system across our product offerings and helps organizations better secure their environments and reduce their security and network complexities. The Fortinet Security Fabric platform has an open architecture designed to connect Fortinet solutions and third-party solutions into a single ecosystem, enabling holistic detection and coordinated response across the attack cycle and surface through integration and automation.

[0001262039-21-000030:mdna:30]
Our product offerings consist of our FortiGate network security products and our non-FortiGate products. In addition to high performing networking features, we offer a rich set of cloud-delivered Security Services that can be added to different products across the Fortinet Security Fabric and customized to the organization use cases. Our security services are enabled by FortiGuard Labs, which provides threat research and artificial intelligence capabilities from a cloud network to deliver coordinated protection for the ever-expanding attack surface through FortiGate appliance and virtual machine as well as all Security Fabric products that are registered by the end-customer.

[0001262039-21-000030:mdna:31]
Our proprietary Security Processing Units (“SPUs”) are Application-Specific Integrated Circuits that are implemented in our physical FortiGate appliances and are designed to enhance the security processing capabilities implemented in software by accelerating computationally intensive tasks such as firewall policy enforcement, software-defined wide-area network (“SD-WAN”), network address translation, Intrusion Prevention Systems (“IPS”), threat detection and encryption. We also provide virtualized Security Processing Units (“vSPUs”) across our FortiGate virtual appliances to deliver similar accelerated capabilities when run in virtualized environments.

[0001262039-21-000030:mdna:32]
Our FortiOS operating system provides the foundation for the operation of all FortiGate network security appliances, whether physical, virtual, private- or public-cloud based. FortiOS directs the operations of processors and SPUs and provides system management functions. We make regular updates to FortiOS available through our FortiCare support services.

[0001262039-21-000030:mdna:33]
FortiOS, its associated security and networking functions and products that run or are integrated with FortiOS are combined to form the Fortinet Security Fabric cybersecurity platform. This approach to security ties discrete security solutions

[0001262039-21-000030:mdna:34]
[same as prior period, unchanged from 0001262039-21-000022:mdna:58]

[0001262039-21-000030:mdna:35]
together into an integrated whole that provides centralized management and visibility, automation and intelligence sharing to simplify network and security operations and rapid response to threats.

[0001262039-21-000030:mdna:36]
[same as prior period, unchanged from 0001262039-21-000022:mdna:36]

[0001262039-21-000030:mdna:37]
•Security-Driven Networking—Our Security-Driven Networking solutions enables the convergence of networking and security across all edges to provide next-generation firewall (“NGFW”), software-defined wide area network (“SD-WAN”), LAN Edge (Wi-Fi and switch) and secure access service edge (“SASE”). We derive a majority of product sales from our FortiGate network security appliances. FortiGate network security appliances include a broad set of built-in security and networking features and functionalities, including firewall, next-generation firewall, secure web gateway, secure sockets layer (“SSL”) inspection, software-defined wide area network (“SD-WAN”), Intrusion Prevention system (“IPS”), sandboxing, data leak prevention, virtual private network (“VPN”), switch and wireless controller and wide area network (“WAN”) edge. Our network security appliances are managed by our FortiOS network operating system, which provides the foundation for FortiGate security functions. We enhance the performance of our network security appliances from branch to data center by designing and implementing Security Processing Units (“SPUs”) technology within our appliances, enabling us to add security and network functionality with minimal impact to network throughput performance.

[0001262039-21-000030:mdna:38]
•Zero Trust Access—The Fortinet Security Fabric platform extends beyond the network to cover other attack vectors. Our Zero Trust Access solutions enable customers to know and control who and what is on their network, in addition to providing security for work from anywhere (“WFA”). Zero Trust Access solutions include FortiNAC, FortiAuthenticator, FortiClient and FortiToken. Additionally, the proliferation of internet of things (“IoT”) and operational technology (“OT”) devices has generated new opportunities for us to grow our business. Our network access control solutions provide visibility, control and automated event responses in order to secure IoT and OT devices.

[0001262039-21-000030:mdna:39]
[same as prior period, unchanged from 0001262039-21-000022:mdna:39]

[0001262039-21-000030:mdna:40]
•AI-Driven Security Operations—We develop and provide a range of products and services that enable the security operations center (“SOC”) teams to identify, investigate and remediate potential incidents in which cybercriminals bypass prevention-oriented controls. Given the breadth of the attack surface to monitor, as well as the volume and sophistication of cyber threats, Artificial Intelligence (“AI”) is a key part of these offerings, which include: FortiGuard and other security subscription services, modern endpoint security with endpoint detection and response (“EDR”), a range of breach-protection technologies plus our security information and event management (“SIEM”) and security orchestration, automation and response (“SOAR”), all of which can be applied across the entire Fortinet Security Fabric platform. These solutions automatically deliver security intelligence and insights that enable organizations to protect against and respond to threats faster through integration with Fortinet and third-party controls.

[0001262039-21-000030:mdna:41]
•Security as a Service—Our customers purchase our natively integrated FortiGuard security subscription services as an add-on to products and solutions across the Fortinet Security Fabric with the goal of receiving real-time threat intelligence and protection updates. The rich set of FortiGuard Services is built from the ground up to provide comprehensive protection for users and applications, including market leading offerings for IPS, Web, video and DNS filtering, AV and cloud sandbox as well as IoT and OT Security. The FortiGuard Security Services are provided from our FortiGuard Labs and cloud-delivered to provide real-time unified protection across network endpoint and cloud. FortiCare technical support services and the support of technical account managers, resident engineers and professional service consultants for implementations or training services.

[0001262039-21-000030:mdna:42]
[same as prior period, unchanged from 0001262039-21-000022:mdna:72]

[0001262039-21-000030:mdna:43]
[same as prior period, unchanged from 0001262039-21-000022:mdna:47]

[0001262039-21-000030:mdna:44]
•Total revenue was $867.2 million and $2.38 billion during the three and nine months ended September 30, 2021, an increase of 33% and 29%, respectively, compared to $651.1 million and $1.85 billion in the same periods last year. Product revenue was $337.1 million and $876.1 million during the three and nine months ended September 30, 2021, an increase of 51% and 40%, respectively, compared to $223.8 million and $628.0 million in the same periods last year. Service revenue was $530.1 million and $1.50 billion during the three and nine months ended September 30, 2021, an increase of 24% and 23%, respectively, compared to $427.3 million and $1.22 billion in the same periods last year.

[0001262039-21-000030:mdna:45]
•Total gross profit was $656.0 million and $1.82 billion during the three and nine months ended September 30, 2021, an increase of 28% and 26%, respectively, compared to $511.9 million and $1.44 billion in the same periods last year.

[0001262039-21-000030:mdna:46]
•We generated operating income of $166.4 million and $435.5 million during the three and nine months ended September 30, 2021, an increase of 31% and 20%, respectively, compared to $126.9 million and $362.4 million in the same periods last year. Operating income during the three months ended September 30, 2021 and 2020 included gains on an intellectual property (“IP”) matter of $1.1 million. Operating income during the nine months ended September 30, 2021 and 2020 included gains on an intellectual property (“IP”) matter of $3.4 million and $39.0 million, respectively.

[0001262039-21-000030:mdna:47]
•Cash, cash equivalents, short-term and long-term investments and marketable equity securities were $3.42 billion as of September 30, 2021.

[0001262039-21-000030:mdna:48]
•During the nine months ended September 30, 2021, we repurchased 0.8 million shares of common stock under our Share Repurchase Program (the “Repurchase Program”), for a total purchase price of $200.4 million.

[0001262039-21-000030:mdna:49]
•In March 2021, we issued $1.0 billion of Senior Notes. Long-term debt, net of unamortized discount and debt issuance costs, was $988.0 million as of September 30, 2021. There was no such debt outstanding at December 31, 2020.

[0001262039-21-000030:mdna:50]
•Deferred revenue was $3.11 billion as of September 30, 2021, an increase of $501.1 million, or 19%, from December 31, 2020. Short-term deferred revenue was $1.62 billion as of September 30, 2021, an increase of $223.3 million, or 16%, from December 31, 2020.

[0001262039-21-000030:mdna:51]
•We generated cash flows from operating activities of $1.13 billion during the nine months ended September 30, 2021, an increase of $345.7 million, or 44%, compared to the same period last year. We generated $50.0 million of proceeds from an IP matter in the first quarter of 2020.

[0001262039-21-000030:mdna:52]
•On August 31, 2021, we closed an acquisition of 75% of the equity interests in AlaxalA Networks Corporation (“AlaxalA”), a privately held network hardware equipment company in Japan, to help address the increasing need for secure switches integrated with FortiGate Firewalls and Security Fabric functionality, and, over time, to innovate and rebrand certain of AlaxalA’s switches to offer a broader suite of secure switches globally. From September 1, 2021 to September 30, 2021, AlaxalA’s revenue was $15.6 million, or 1.8% and 0.7% of total revenue during the three and nine months ended September 30, 2021, respectively.

[0001262039-21-000030:mdna:53]
Our revenue growth was driven by both product and service revenue. On a geographic basis, revenue continues to be diversified, which remains a key strength of our business. During the three months ended September 30, 2021, the Americas region, the Europe, Middle East and Africa (“EMEA”) region and the Asia Pacific (“APAC”) region contributed 41%, 37% and 22% of our total revenue, respectively, and increased by 29%, 33% and 43% compared to the same periods last year, respectively. During the nine months ended September 30, 2021, the Americas region, the EMEA region and the APAC region contributed 41%, 38% and 21% of our total revenue, respectively, and increased by 26%, 31% and 31% compared to the same periods last year, respectively.

[0001262039-21-000030:mdna:54]
Product revenue grew 51% and 40% during the three and nine months ended September 30, 2021, respectively, compared to the same period last year. Product revenue growth was consistent with an elevated cyber threat landscape. FortiGate products accounted for more than half of the product revenue growth during the three months ended September 30, 2021. While Secure SD-WAN contributed to product revenue growth, the main driver was the strong demand for the wide range of other operating system capabilities embedded in the FortiGate products. We experienced strong product revenue growth across many of our security fabric platform products, including our OT solutions, secure access products and software

[0001262039-21-000030:mdna:55]
[same as prior period, unchanged from 0001262039-21-000022:mdna:82]

[0001262039-21-000030:mdna:56]
licenses. The impact of the increase in backlog was largely seen in certain fabric platform products. Service revenue growth of 24% and 23% during the three and nine months ended September 30, 2021, respectively, compared to the same periods last year, was driven by the strength of our FortiCare technical support and other service revenue which grew 26% and 25%, respectively, and of FortiGuard and other security subscription revenue, which grew 22%.

[0001262039-21-000030:mdna:57]
Our billings were diversified on a geographic basis. During the three months ended September 30, 2021, approximately 50% of our billings in the aggregate were from over 100 countries that individually contributed less than 3% of our billings.

[0001262039-21-000030:mdna:58]
During the three months ended September 30, 2021 and 2020, we recognized gains of $1.1 million, on an IP matter in connection with a mutual covenant-not-to-sue and release agreement with a competitor in the network security industry. Excluding the gains on the IP matter during the three months ended September 30, 2021 and 2020, operating expenses as a percentage of revenue stayed flat during the three months ended September 30, 2021 compared to the same period last year. During the nine months ended September 30, 2021 and 2020, we recognized gains of $3.4 million and $39.0 million, respectively, on an IP matter in connection with a mutual covenant-not-to-sue and release agreement with a competitor in the network security industry. Excluding the gains on the IP matter during the nine months ended September 30, 2021 and 2020, operating expenses as a percentage of revenue decreased by 2.2 percentage points during the nine months ended September 30, 2021 compared to the same period last year. Headcount increased to 9,700 employees and contractors as of September 30, 2021, an 18% increase compared to 8,238 as of December 31, 2020.

[0001262039-21-000030:mdna:59]
[same as prior period, unchanged from 0001262039-21-000022:mdna:61]

[0001262039-21-000030:mdna:60]
The United States and the global community we serve are facing unprecedented challenges posed by the COVID-19 pandemic, including the various COVID-19 variants. In response to the pandemic, we undertook a number of actions to protect our employees, including restricting travel and directing many of our employees to work from home. In certain geographies, we have started to transition back to an in-person working mode, allowing more employees to work from our offices with reasonable precautions and, in all cases, subject to abiding by local legal restrictions. We intend to continue to monitor and abide by local employee health and safety protocols and other regulations as applicable to each local office.

[0001262039-21-000030:mdna:61]
While the broader implications of the COVID-19 pandemic on our employees and overall financial performance continue to evolve, we have seen certain impacts on our business and operations, results of operations, financial condition, cash flows, liquidity and capital and financial resources as of and during the three and nine months ended September 30, 2021. Conversely, some aspects of our business do not appear to have been significantly affected. During the three and nine months ended September 30, 2021, we have observed the following:

[0001262039-21-000030:mdna:62]
•We have seen supply chain challenges increase, including chip and other component shortages and increased costs for certain chips and other components and shipping, and we do not have enough inventory to promptly meet all demand for all products.

[0001262039-21-000030:mdna:63]
•In most countries, our employees’ ability to travel has been reduced. In-person sales and marketing events or meetings that would normally have been held were canceled, postponed or converted into virtual events. However, as certain country’s restrictions start to ease, we have started to see an increase in expenses related to travel and marketing events. Although we cannot predict if or when such expenses will return to pre-pandemic levels, as of September 30, 2021 we have started to see an increase in such expenses as compared to the same period last year.

[0001262039-21-000030:mdna:64]
•The countries and geographic regions in which we experienced the fastest billings growth in the third quarter of 2021, as compared to the third quarter of 2020, were countries and geographic regions in which the COVID-19 pandemic is generally considered to currently have a comparatively less severe impact on the local population and economy.

[0001262039-21-000030:mdna:65]
[same as prior period, unchanged from 0001262039-21-000022:mdna:66]

[0001262039-21-000030:mdna:66]
•In order to mitigate supply chain disruption and other supply chain risk and in anticipation of future demand, we worked to increase our on-hand stock of certain products. We increased our commitments with certain suppliers to secure capacity and, are meeting regularly with our contract manufacturer to manage future commitments, address component shortages and monitor delivery of finished goods. We have also transitioned primarily to air shipping to avoid port congestion and extended ocean freight time.

[0001262039-21-000030:mdna:67]
•The yield on investment-grade debt has decreased, and while the risk of credit losses on our investments and cash equivalents has not changed significantly, as the debt securities in our portfolio have matured, they have been replaced

[0001262039-21-000030:mdna:68]
31

[0001262039-21-000030:mdna:69]
by securities with lower effective interest rates. This has contributed to a decrease in our interest income during the three and nine months ended September 30, 2021, compared to the same period last year.

[0001262039-21-000030:mdna:70]
[same as prior period, unchanged from 0001262039-21-000022:mdna:70]

[0001262039-21-000030:mdna:71]
Going forward, the situation remains uncertain, rapidly changing and hard to predict, and the COVID-19 pandemic may have a material negative impact on our future periods. If we experience greater component, shipping or inventory challenges than we expect or significant changes in our billings growth rates, it will negatively impact billings and product revenue in the current quarter and FortiGuard and FortiCare service revenues in subsequent quarters, as we sell annual and multi-year service contracts that are recognized ratably over the contractual service term. In addition, the broader implications of the pandemic on our business and operations and our financial results, including the extent to which the effects of the pandemic will impact future results and growth in the cybersecurity industry, remain uncertain. The extent of the impact of the COVID-19 pandemic on our operational and financial performance will depend on ongoing developments, including the duration and spread of the virus and its variants, the impact on our end-customers’ spending, the volume of sales and length of our sales cycles, the impact on our partners, suppliers, and employees, actions that may be taken by governmental authorities and other factors identified in Part II, Item 1A “Risk Factors” in this Form 10-Q. Given the dynamic nature of these circumstances, the full impact of the COVID-19 pandemic on our business and operations, results of operations, financial condition, cash flows, liquidity and capital and financial resources cannot be reasonably estimated at this time.

[0001262039-21-000030:mdna:72]
[same as prior period, unchanged from 0001262039-21-000022:mdna:74]

[0001262039-21-000030:mdna:73]
We typically sell our security solutions to distributors that sell to networking security focused resellers and to service providers and managed security service providers (“MSSPs”), who, in turn, sell to end-customers. At times, we also sell directly to large service providers and major systems integrators who may sell to our end-customers or use our products and services to provided hosted solutions to other enterprises. Our end-customers are located in over 100 countries and include small, medium and large enterprises and government organizations across a wide range of industries, including telecommunications, government, financial services, retail, technology, education, manufacturing and healthcare. An end-customer deployment may involve as few as one or as many as thousands of appliances and other Fortinet Security Fabric platform products, depending on the end-customer’s size and security requirements.

[0001262039-21-000030:mdna:74]
We also offer our products through major cloud providers, and have recognized revenue on a usage basis from Amazon Web Services, Microsoft Azure, Alibaba Cloud, Google Cloud, Oracle Cloud and IBM Cloud. We have also recognized revenue from customers who deploy our products in a bring-your-own-license (“BYOL”) arrangement in private clouds or at cloud providers. In a BYOL arrangement, a customer purchases a software license from us through our channel partners and deploys the software in a cloud provider’s environment. Similarly, customers may purchase such a license from us and deploy in third-party clouds or in their private cloud.

[0001262039-21-000030:mdna:75]
[same as prior period, unchanged from 0001262039-21-000022:mdna:77]

[0001262039-21-000030:mdna:76]
[same as prior period, unchanged from 0001262039-21-000022:mdna:78]

[0001262039-21-000030:mdna:77]
We monitor a number of key metrics, including the key financial metrics set forth below, in order to help us evaluate growth trends, establish budgets, measure the effectiveness of our sales and marketing efforts, and assess operational efficiencies. The following table summarizes revenue, deferred revenue, billings (non-GAAP), net cash provided by operating activities, and free cash flow (non-GAAP). We discuss revenue below under “Results of Operations,” and we discuss net cash

[0001262039-21-000030:mdna:78]
provided by operating activities below under “—Liquidity and Capital Resources.” Deferred revenue, billings (non-GAAP), and free cash flow (non-GAAP) are discussed immediately below the following table:

[0001262039-21-000030:mdna:79]
|  | Three Months Ended Or As Of |
|  | September 30, 2021 |  | September 30, 2020 |
|  | (in millions) |
| Revenue | $ | 867.2 |  |  | $ | 651.1 |  |
| Deferred revenue | $ | 3,106.4 |  |  | $ | 2,392.0 |  |
| Billings (non-GAAP) | $ | 1,064.1 |  |  | $ | 749.8 |  |
| Net cash provided by operating activities | $ | 398.8 |  |  | $ | 220.8 |  |
| Free cash flow (non-GAAP) | $ | 329.8 |  |  | $ | 185.7 |  |

[0001262039-21-000030:mdna:80]
Deferred revenue. Our deferred revenue consists of amounts that have been invoiced but that have not yet been recognized as revenue. The majority of our deferred revenue balance consists of the unrecognized portion of service revenue from FortiGuard and other security subscription and FortiCare technical support service contracts, which is recognized as revenue ratably over the contractual service period. We monitor our deferred revenue balance, deferred revenue growth and the mix of short-term and long-term deferred revenue because deferred revenue represents a significant portion of free cash flow and of revenue to be recognized in future periods. Deferred revenue was $3.11 billion as of September 30, 2021, an increase of $501.1 million, or 19%, from December 31, 2020.

[0001262039-21-000030:mdna:81]
Billings (non-GAAP). We define billings as revenue recognized in accordance with GAAP plus the change in deferred revenue from the beginning to the end of the period, less any deferred revenue balances acquired from business combination(s) during the period. We consider billings to be a useful metric for management and investors because billings drive current and future revenue, which is an important indicator of the health and viability of our business. There are a number of limitations related to the use of billings instead of GAAP revenue. First, billings include amounts that have not yet been recognized as revenue and are impacted by the term of security and support agreements. Second, we may calculate billings in a manner that is different from peer companies that report similar financial measures. Management accounts for these limitations by providing specific information regarding GAAP revenue and evaluating billings together with GAAP revenue. Total billings were $1.06 billion for the three months ended September 30, 2021, an increase of 42% compared to $749.8 million in the same period last year.

[0001262039-21-000030:mdna:82]
[same as prior period, unchanged from 0001262039-21-000022:mdna:85]

[0001262039-21-000030:mdna:83]
|  | Three Months Ended |
|  | September 30, 2021 |  | September 30, 2020 |
|  | (in millions) |
| Billings: |  |  |  |
| Revenue | $ | 867.2 |  |  | $ | 651.1 |  |
| Add: Change in deferred revenue | 201.0 |  |  | 98.9 |  |
| Less: Deferred revenue balance acquired in business combination | (4.1) |  |  | (0.2) |  |
| Total billings (non-GAAP) | $ | 1,064.1 |  |  | $ | 749.8 |  |

[0001262039-21-000030:mdna:84]
Free cash flow (non-GAAP). We define free cash flow as net cash provided by operating activities minus purchases of property and equipment and excluding any significant non-recurring items. We believe free cash flow to be a liquidity measure that provides useful information to management and investors about the amount of cash generated by the business that, after capital expenditures, can be used for strategic opportunities, including repurchasing outstanding common stock, investing in our business, making strategic acquisitions and strengthening the balance sheet. A limitation of using free cash flow rather than the GAAP measures of cash provided by or used in operating activities, investing activities, and financing activities is that free cash flow does not represent the total increase or decrease in the cash and cash equivalents balance for the period because it excludes cash flows from investing activities other than capital expenditures and cash flows from financing activities. Management accounts for this limitation by providing information about our capital expenditures and other investing and financing activities on the face of the consolidated statements of cash flows and under “—Liquidity and Capital Resources” and by presenting cash flows from investing and financing activities in our reconciliation of free cash flow. In addition, it is important to note that other companies, including companies in our industry, may not use free cash flow, may calculate free cash flow in a different manner than we do or may use other financial measures to evaluate their performance, all of which could reduce the usefulness of free

[0001262039-21-000030:mdna:85]
[same as prior period, unchanged from 0001262039-21-000022:mdna:109]

[0001262039-21-000030:mdna:86]
cash flow as a comparative measure. A reconciliation of net cash provided by operating activities, the most directly comparable financial measure calculated and presented in accordance with GAAP, to free cash flow is provided below:

[0001262039-21-000030:mdna:87]
|  | Three Months Ended |
|  | September 30, 2021 |  | September 30, 2020 |
|  | (in millions) |
| Free Cash Flow: |  |  |  |
| Net cash provided by operating activities | $ | 398.8 |  |  | $ | 220.8 |  |
| Less: Purchases of property and equipment | (69.0) |  |  | (35.1) |  |
| Free cash flow (non-GAAP) | $ | 329.8 |  |  | $ | 185.7 |  |
| Net cash used in investing activities | $ | (307.5) |  |  | $ | (224.6) |  |
| Net cash used in financing activities | $ | (118.7) |  |  | $ | (30.3) |  |

[0001262039-21-000030:mdna:88]
[same as prior period, unchanged from 0001262039-21-000022:mdna:89]

[0001262039-21-000030:mdna:89]
Our discussion and analysis of our financial condition and results of operations are based upon our financial statements, which have been prepared in accordance with GAAP. These principles require us to make estimates and judgments that affect the reported amounts of assets, liabilities, revenue, cost of revenue and expenses, and related disclosures. We base our estimates on historical experience and on various other assumptions that we believe to be reasonable under the circumstances. To the extent that there are material differences between these estimates and our actual results, our future financial statements will be affected.

[0001262039-21-000030:mdna:90]
There were no material changes to our critical accounting policies and estimates as of and for the three and nine months ended September 30, 2021, as compared to the critical accounting policies and estimates described in our Annual Report on Form 10-K filed with the SEC on February 19, 2021 (the “Form 10-K”), except as noted below.

[0001262039-21-000030:mdna:91]
Non-marketable equity investments

[0001262039-21-000030:mdna:92]
Our non-marketable investments include equity investments in privately held companies without a readily determinable fair value. We measure these investments at cost minus impairment, if any, plus or minus changes resulting from observable price changes in orderly transactions for identical or similar investments of the same issuer. Gains and losses on these investments, whether realized or unrealized, are recognized in other expense, net in our condensed consolidated statements of income.

[0001262039-21-000030:mdna:93]
Also, our non-marketable investments include investments in common stock or in-substance common stock of entities that provide us with the ability to exercise significant influence over the investee, but not an absolute controlling financial interest, and are accounted for under the equity method of accounting. Our investment in Linksys is our only equity method investment. We record our proportionate share of the net earnings (losses) and the amortization of any basis differences of Linksys based on the most recently available financial statements of Linksys, which are provided to us on a three-month lag, in loss from equity method investment in our condensed consolidated statements of income.

[0001262039-21-000030:mdna:94]
[same as prior period, unchanged from 0001262039-21-000022:mdna:93]

[0001262039-21-000030:mdna:95]
[same as prior period, unchanged from 0001262039-21-000022:mdna:94]

[0001262039-21-000030:mdna:96]
[same as prior period, unchanged from 0001262039-21-000022:mdna:122]

[0001262039-21-000030:mdna:97]
[same as prior period, unchanged from 0001262039-21-000022:mdna:95]

[0001262039-21-000030:mdna:98]
Three Months Ended September 30, 2021 and September 30, 2020

[0001262039-21-000030:mdna:99]
[same as prior period, unchanged from 0001262039-21-000022:mdna:97]

[0001262039-21-000030:mdna:100]
|  | Three Months Ended |  |  |  |  |
| September 30,2021 |  | September 30,2020 |  |  |  |  |
| Amount |  | % ofRevenue |  | Amount |  | % ofRevenue |  | Change |  | % Change |
| (in millions, except percentages) |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 337.1 |  |  | 39 | % |  | $ | 223.8 |  |  | 34 | % |  | $ | 113.3 |  |  | 51 | % |
| Service | 530.1 |  |  | 61 |  |  | 427.3 |  |  | 66 |  |  | 102.8 |  |  | 24 |  |
| Total revenue | $ | 867.2 |  |  | 100 | % |  | $ | 651.1 |  |  | 100 | % |  | $ | 216.1 |  |  | 33 | % |
| Revenue by geography: |  |  |  |  |  |  |  |  |  |  |  |
| Americas | $ | 350.1 |  |  | 41 | % |  | $ | 272.4 |  |  | 42 | % |  | $ | 77.7 |  |  | 29 | % |
| EMEA | 323.2 |  |  | 37 |  |  | 243.3 |  |  | 37 |  |  | 79.9 |  |  | 33 |  |
| APAC | 193.9 |  |  | 22 |  |  | 135.4 |  |  | 21 |  |  | 58.5 |  |  | 43 |  |
| Total revenue | $ | 867.2 |  |  | 100 | % |  | $ | 651.1 |  |  | 100 | % |  | $ | 216.1 |  |  | 33 | % |

[0001262039-21-000030:mdna:101]
Total revenue increased by $216.1 million, or 33%, during the three months ended September 30, 2021 compared to the same period last year. Total revenue for the three months ended September 30, 2021 included AlaxalA’s revenue from September 1, 2021 to September 30, 2021 of $15.6 million, or 1.8% of total revenue. Excluding AlaxalA, our revenue was $851.6 million, an increase of 31% compared to the same quarter last year. We continued to experience largely organic revenue growth (i.e. revenue growth excluding attribution from recent acquisitions) with diversification of revenue geographically, and across both customer and industry segments. Revenue from all regions grew, with EMEA contributing the largest portion of the increase on an absolute dollar basis and APAC, including AlaxalA, contributing the largest portion of the increase on a percentage basis.

[0001262039-21-000030:mdna:102]
Product revenue increased by $113.3 million, or 51%, during the three months ended September 30, 2021 compared to the same period last year. Product revenue growth was consistent with an elevated cyber threat landscape. FortiGate products accounted for more than half of the product revenue growth in the three months ended September 30, 2021. While Secure SD-WAN contributed to product revenue growth, the main driver was the strong demand for the wide range of other operating system capabilities embedded in the FortiGate products. We also experienced strong revenue growth across many of our security fabric platform products, including OT solutions, secure access products and software licenses.

[0001262039-21-000030:mdna:103]
Service revenue increased by $102.8 million, or 24%, during the three months ended September 30, 2021 compared to the same period last year. FortiGuard security subscription and FortiCare technical support and other revenues increased by $52.0 million, or 22%, and by $50.8 million, or 26%, respectively, during the three months ended September 30, 2021 compared to the same period last year. The increases were primarily due to the recognition of revenue from our growing deferred revenue balance related to FortiGuard and other security subscriptions delivered to on-premise and cloud based environments as well as FortiCare technical support, including our customers moving to higher-tier support offerings.

[0001262039-21-000030:mdna:104]
Of the service revenue recognized during the three months ended September 30, 2021, 89% was included in the deferred revenue balance as of June 30, 2021.

[0001262039-21-000030:mdna:105]
35

[0001262039-21-000030:mdna:106]
[same as prior period, unchanged from 0001262039-21-000022:mdna:104]

[0001262039-21-000030:mdna:107]
|  | Three Months Ended |  |  |  |  |
| September 30,2021 |  | September 30,2020 |  | Change |  | % Change |
| (in millions, except percentages) |
| Cost of revenue: |  |  |  |  |  |  |  |
| Product | $ | 134.3 |  |  | $ | 84.3 |  |  | $ | 50.0 |  |  | 59 | % |
| Service | 76.9 |  |  | 54.9 |  |  | 22.0 |  |  | 40 |  |
| Total cost of revenue | $ | 211.2 |  |  | $ | 139.2 |  |  | $ | 72.0 |  |  | 52 | % |
| Gross margin (%): |  |  |  |  |  |  |  |
| Product | 60.2 | % |  | 62.3 | % |  |  |  |  |
| Service | 85.5 |  |  | 87.2 |  |  |  |  |  |
| Total gross margin | 75.6 | % |  | 78.6 | % |  |  |  |  |

[0001262039-21-000030:mdna:108]
Total gross margin decreased by 3.0 percentage points during the three months ended September 30, 2021 compared to the same period last year, driven by change in revenue mix to lower margin product revenue from higher margin service revenue year over year. Revenue mix shifted by 4.5 percentage points from service revenue to product revenue, as a percentage of total revenue.

[0001262039-21-000030:mdna:109]
Product gross margin decreased by 2.1 percentage points during the three months ended September 30, 2021 compared to the same period last year. The decrease in product gross margin was impacted by our consolidation of AlaxalA, higher product costs due to supply chain constraints and a change in our product mix. Cost of product revenue was comprised primarily of third-party contract manufacturers’ costs and the costs of materials used in production.

[0001262039-21-000030:mdna:110]
Service gross margin decreased by 1.7 percentage points during the three months ended September 30, 2021 compared to the same period last year. Cost of service revenue was comprised primarily of personnel costs and data center costs. The decrease in service gross margin was primarily impacted by our consolidation of AlaxalA and our data center expansion.

[0001262039-21-000030:mdna:111]
[same as prior period, unchanged from 0001262039-21-000022:mdna:110]

[0001262039-21-000030:mdna:112]
|  | Three Months Ended |  | Change |  | % Change |
| September 30,2021 |  | September 30,2020 |  |
| Amount |  | % ofRevenue |  | Amount |  | % ofRevenue |  |
| (in millions, except percentages) |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | $ | 107.8 |  |  | 12 | % |  | $ | 90.0 |  |  | 14 | % |  | $ | 17.8 |  |  | 20 | % |
| Sales and marketing | 347.1 |  |  | 40 |  |  | 266.7 |  |  | 41 |  |  | 80.4 |  |  | 30 |  |
| General and administrative | 35.8 |  |  | 4 |  |  | 29.4 |  |  | 5 |  |  | 6.4 |  |  | 22 |  |
| Gain on IP matter | (1.1) |  |  | — |  |  | (1.1) |  |  | — |  |  | — |  |  | — |  |
| Total operating expenses | $ | 489.6 |  |  | 56 | % |  | $ | 385.0 |  |  | 59 | % |  | $ | 104.6 |  |  | 27 | % |
| Percentages have been rounded for presentation purposes and may differ from unrounded results. |

[0001262039-21-000030:mdna:113]
[same as prior period, unchanged from 0001262039-21-000022:mdna:112]

[0001262039-21-000030:mdna:114]
Research and development expense increased by $17.8 million, or 20%, during the three months ended September 30, 2021 compared to the same period last year, primarily due to an increase of $17.3 million in personnel-related costs as a result of increased headcount to support the development of new products and continued enhancements to our existing products and foreign currency fluctuations. We currently intend to continue to invest in our research and development organization, and expect research and development expense to increase in absolute dollars during the remainder of 2021.

[0001262039-21-000030:mdna:115]
[same as prior period, unchanged from 0001262039-21-000022:mdna:114]

[0001262039-21-000030:mdna:116]
Sales and marketing expense increased by $80.4 million, or 30%, during the three months ended September 30, 2021 compared to the same period last year, primarily due to an increase of $52.9 million in personnel-related costs as a result of increases to sales and marketing headcount in order to drive global market revenue increases and foreign currency fluctuations. Marketing-related expense increased by $15.9 million, and included expenses related to the Fortinet Championship, the PGA tour event that we sponsored in September 2021. In addition, travel expense increased by $4.4 million. We currently intend to continue to make investments in sales and marketing resources, which are critical to support our future growth, and expect sales and marketing expense to increase in absolute dollars during the remainder of 2021.

[0001262039-21-000030:mdna:117]
[same as prior period, unchanged from 0001262039-21-000022:mdna:116]

[0001262039-21-000030:mdna:118]
General and administrative expense increased by $6.4 million, or 22%, during the three months ended September 30, 2021 compared to the same period last year, primarily due to an increase in personnel-related costs of $3.4 million, an increase in acquisition expense of $1.1 million, an increase in depreciation and other occupancy-related costs of $0.3 million and an increase in professional services costs of $0.3 million. We currently expect general and administrative expense to increase in absolute dollars during the remainder of 2021.

[0001262039-21-000030:mdna:119]
[same as prior period, unchanged from 0001262039-21-000022:mdna:118]

[0001262039-21-000030:mdna:120]
In January 2020, we entered into an agreement with a competitor in the network security industry, whereby, in February 2020, the competitor party paid us a lump sum of $50.0 million for a mutual covenant-not-to-sue for patent claims. During the three months ended September 30, 2021 and 2020, we recorded $1.1 million in amortization of the deferred component as a gain on IP matter in our condensed consolidated statements of income. See Note 12 of the notes to condensed consolidated financial statements included in Part I, Item 1 of this Quarterly Report on Form 10-Q for additional information regarding the gain on IP matter.

[0001262039-21-000030:mdna:121]
[same as prior period, unchanged from 0001262039-21-000022:mdna:120]

[0001262039-21-000030:mdna:122]
We generated operating income of $166.4 million during the three months ended September 30, 2021, an increase of $39.5 million, or 31%, compared to $126.9 million in the same period last year. Operating income as a percentage of revenue was 19% during the three months ended September 30, 2021, which was flat compared to the same period last year.

[0001262039-21-000030:mdna:123]
[same as prior period, unchanged from 0001262039-21-000022:mdna:124]

[0001262039-21-000030:mdna:124]
|  | Three Months Ended |  |  |  |  |
| September 30,2021 |  | September 30,2020 |  | Change |  | % Change |
| (in millions, except percentages) |
| Interest income | $ | 1.2 |  |  | $ | 2.5 |  |  | $ | (1.3) |  |  | (52) | % |
| Interest expense | $ | (4.6) |  |  | $ | — |  |  | $ | (4.6) |  |  | * |
| Other expense—net | $ | (6.3) |  |  | $ | (1.0) |  |  | $ | (5.3) |  |  | 530 | % |

[0001262039-21-000030:mdna:125]
* Not meaningful

[0001262039-21-000030:mdna:126]
Interest income decreased by $1.3 million during the three months ended September 30, 2021 compared to the same period last year, as a result of lower interest rates. Interest income varies depending on our average investment balances during the period, types and mix of investments, and market interest rates. Interest expense increased by $4.6 million during the three months ended September 30, 2021 compared to the same period last year, primarily due to the senior notes issued in the first quarter of 2021. Other expense—net increased by $5.3 million during the three months ended September 30, 2021 compared to the same period last year, primarily due to an increase of $3.7 million loss on marketable equity securities and an increase of $1.2 million of foreign currency exchange loss.

[0001262039-21-000030:mdna:127]
[same as prior period, unchanged from 0001262039-21-000022:mdna:149]

[0001262039-21-000030:mdna:128]
Provision for (benefit from) income taxes

[0001262039-21-000030:mdna:129]
|  | Three Months Ended |  | Change |  | % Change |
| September 30,2021 |  | September 30,2020 |  |
| (in millions, except percentages) |
| Provision for (benefit from) income taxes | $ | (9.3) |  |  | $ | 5.0 |  |  | $ | (14.3) |  |  | (286) | % |
| Effective tax rate (%) | (6) | % |  | 4 | % |  |  |  |  |

[0001262039-21-000030:mdna:130]
Our effective tax rate was negative 6% for the three months ended September 30, 2021 compared to an effective tax rate of 4% for the same period last year. The benefit from income taxes for the three months ended September 30, 2021 was primarily comprised of U.S. federal and state taxes, withholding taxes and foreign taxes that were $40.1 million. This tax provision for income taxes was favorably affected by a tax benefit of $8.7 million from the foreign-derived intangible income deduction (the “FDII deduction”) and excess tax benefits from stock-based compensation expense of $25.0 million. The tax provision for income taxes was further impacted by a tax benefit of $15.7 million for a change in tax accounting positions in finalization of the prior year tax return.

[0001262039-21-000030:mdna:131]
The provision for income taxes for the three months ended September 30, 2020 was comprised of U.S. federal and state taxes, withholding taxes, and foreign taxes that were $33.8 million, which were offset by a tax benefit of $16.3 million from the FDII deduction and excess tax benefits from stock-based compensation expense of $12.5 million.

[0001262039-21-000030:mdna:132]
[same as prior period, unchanged from 0001262039-21-000022:mdna:131]

[0001262039-21-000030:mdna:133]
Nine Months Ended September 30, 2021 and September 30, 2020

[0001262039-21-000030:mdna:134]
[same as prior period, unchanged from 0001262039-21-000022:mdna:133]

[0001262039-21-000030:mdna:135]
|  | Nine Months Ended |  |  |  |  |
| September 30,2021 |  | September 30,2020 |  |  |  |  |
| Amount |  | % ofRevenue |  | Amount |  | % ofRevenue |  | Change |  | % Change |
| (in millions, except percentages) |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 876.1 |  |  | 37 | % |  | $ | 628.0 |  |  | 34 | % |  | $ | 248.1 |  |  | 40 | % |
| Service | 1,502.5 |  |  | 63 |  |  | 1,218.4 |  |  | 66 |  |  | 284.1 |  |  | 23 |  |
| Total revenue | $ | 2,378.6 |  |  | 100 | % |  | $ | 1,846.4 |  |  | 100 | % |  | $ | 532.2 |  |  | 29 | % |
| Revenue by geography: |  |  |  |  |  |  |  |  |  |  |  |
| Americas | $ | 978.0 |  |  | 41 | % |  | $ | 776.0 |  |  | 42 | % |  | $ | 202.0 |  |  | 26 | % |
| EMEA | 905.1 |  |  | 38 |  |  | 693.5 |  |  | 38 |  |  | 211.6 |  |  | 31 |  |
| APAC | 495.5 |  |  | 21 |  |  | 376.9 |  |  | 20 |  |  | 118.6 |  |  | 31 |  |
| Total revenue | $ | 2,378.6 |  |  | 100 | % |  | $ | 1,846.4 |  |  | 100 | % |  | $ | 532.2 |  |  | 29 | % |

[0001262039-21-000030:mdna:136]
Total revenue increased by $532.2 million, or 29%, during the nine months ended September 30, 2021 compared to the same period last year. We continue to experience largely organic revenue growth (i.e. revenue growth excluding attribution from acquisitions) with diversification of revenue geographically, and across both customer and industry segments. Revenue from all regions grew, with EMEA contributing the largest portion of the increase on an absolute dollar basis and EMEA and APAC contributing the largest portion of the increase on a percentage basis.

[0001262039-21-000030:mdna:137]
Product revenue increased by $248.1 million, or 40%, during the nine months ended September 30, 2021 compared to the same period last year. We experienced revenue growth across many of our products primarily due to an increase in product revenue from our security fabric platform products, including our SD-WAN solutions, and software licenses.

[0001262039-21-000030:mdna:138]
[same as prior period, unchanged from 0001262039-21-000022:mdna:161]

[0001262039-21-000030:mdna:139]
Service revenue increased by $284.1 million, or 23%, during the nine months ended September 30, 2021 compared to the same period last year. FortiGuard security subscription and FortiCare technical support and other revenues increased by $146.2 million, or 22%, and by $137.9 million, or 25%, respectively, during the nine months ended September 30, 2021 compared to the same period last year. The increases were primarily due to the recognition of revenue from our growing deferred revenue balance related to FortiGuard and other security subscriptions and FortiCare technical support, including our customers moving to higher-tier support offerings.

[0001262039-21-000030:mdna:140]
Of the service revenue recognized during the nine months ended September 30, 2021, 73% was included in the deferred revenue balance as of December 31, 2020.

[0001262039-21-000030:mdna:141]
[same as prior period, unchanged from 0001262039-21-000022:mdna:140]

[0001262039-21-000030:mdna:142]
|  | Nine Months Ended |  |  |  |  |
| September 30,2021 |  | September 30,2020 |  | Change |  | % Change |
| (in millions, except percentages) |
| Cost of revenue: |  |  |  |  |  |  |  |
| Product | $ | 341.2 |  |  | $ | 245.0 |  |  | $ | 96.2 |  |  | 39 | % |
| Service | 213.5 |  |  | 158.0 |  |  | 55.5 |  |  | 35 | % |
| Total cost of revenue | $ | 554.7 |  |  | $ | 403.0 |  |  | $ | 151.7 |  |  | 38 | % |
| Gross margin (%): |  |  |  |  |  |  |  |
| Product | 61.1 | % |  | 61.0 | % |  |  |  |  |
| Service | 85.8 |  |  | 87.0 |  |  |  |  |  |
| Total gross margin | 76.7 | % |  | 78.2 | % |  |  |  |  |

[0001262039-21-000030:mdna:143]
Total gross margin decreased by 1.5 percentage points during the nine months ended September 30, 2021 compared to the same period last year, driven by change in revenue to lower margin product revenue from higher margin service revenue. Revenue mix shifted by 2.8 percentage points from service revenue to product revenue, as a percentage of total revenue.

[0001262039-21-000030:mdna:144]
Product gross margin increased by 0.1 percentage points during the nine months ended September 30, 2021 compared to the same period last year. Product gross margin benefited from lower direct product costs as a percentage of product revenue. Cost of product revenue was comprised primarily of third-party contract manufacturers’ costs and the costs of materials used in production.

[0001262039-21-000030:mdna:145]
Service gross margin decreased by 1.2 percentage points during the nine months ended September 30, 2021 compared to the same period last year. Cost of service revenue was comprised primarily of personnel costs and data center costs. The decrease in service gross margin was primarily due to foreign currency fluctuations and increased costs associated with an expansion in our data centers.

[0001262039-21-000030:mdna:146]
[same as prior period, unchanged from 0001262039-21-000022:mdna:145]

[0001262039-21-000030:mdna:147]
|  | Nine Months Ended |  | Change |  | % Change |
| September 30,2021 |  | September 30,2020 |  |
| Amount |  | % ofRevenue |  | Amount |  | % ofRevenue |  |
| (in millions, except percentages) |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | $ | 311.6 |  |  | 13 | % |  | $ | 252.4 |  |  | 14 | % |  | $ | 59.2 |  |  | 23 | % |
| Sales and marketing | 978.0 |  |  | 41 |  |  | 780.5 |  |  | 42 |  |  | 197.5 |  |  | 25 |  |
| General and administrative | 102.2 |  |  | 4 |  |  | 87.1 |  |  | 5 |  |  | 15.1 |  |  | 17 |  |
| Gain on IP matter | (3.4) |  |  | — |  |  | (39.0) |  |  | (2) |  |  | 35.6 |  |  | (91) |  |
| Total operating expenses | $ | 1,388.4 |  |  | 58 | % |  | $ | 1,081.0 |  |  | 59 | % |  | $ | 307.4 |  |  | 28 | % |

[0001262039-21-000030:mdna:148]
[same as prior period, unchanged from 0001262039-21-000022:mdna:171]

[0001262039-21-000030:mdna:149]
[same as prior period, unchanged from 0001262039-21-000022:mdna:147]

[0001262039-21-000030:mdna:150]
Research and development expense increased by $59.2 million, or 23%, during the nine months ended September 30, 2021 compared to the same period last year, primarily due to an increase of $51.9 million in personnel-related costs as a result of increased headcount to support the development of new products and continued enhancements to our existing products and foreign currency fluctuations. In addition, product development costs, such as third-party testing and prototypes, increased by $7.5 million. We currently intend to continue to invest in our research and development organization, and expect research and development expense to increase in absolute dollars during the remainder of 2021.

[0001262039-21-000030:mdna:151]
[same as prior period, unchanged from 0001262039-21-000022:mdna:150]

[0001262039-21-000030:mdna:152]
Sales and marketing expense increased by $197.5 million, or 25%, during the nine months ended September 30, 2021 compared to the same period last year, primarily due to an increase of $157.2 million in personnel-related costs as a result of increases to sales and marketing headcount in order to drive global market revenue increases and foreign currency fluctuations. Marketing-related expense increased by $27.1 million, and included the expenses related to the Fortinet Championship, the PGA tour event that we sponsored in September 2021. In addition, depreciation expense and other occupancy-related expense increased by $5.7 million. We currently intend to continue to make investments in sales and marketing resources, which are critical to support our future growth, and expect sales and marketing expense to increase in absolute dollars during the remainder of 2021.

[0001262039-21-000030:mdna:153]
[same as prior period, unchanged from 0001262039-21-000022:mdna:152]

[0001262039-21-000030:mdna:154]
General and administrative expense increased by $15.1 million, or 17%, during the nine months ended September 30, 2021 compared to the same period last year, primarily due to an increase in personnel-related costs of $8.8 million, an increase in professional services fee of $3.7 million, an increase in acquisition expense of $1.4 million and an increase in litigation settlement expense of $1.1 million. We currently expect general and administrative expense to increase in absolute dollars during the remainder of 2021.

[0001262039-21-000030:mdna:155]
[same as prior period, unchanged from 0001262039-21-000022:mdna:154]

[0001262039-21-000030:mdna:156]
In January 2020, we entered into an agreement with a competitor in the network security industry, whereby, in February 2020, the competitor party paid us a lump sum of $50.0 million for a mutual covenant-not-to-sue for patent claims. During the nine months ended September 30, 2021, we recorded $3.4 million in amortization of the deferred component as a gain on IP matter in our condensed consolidated statements of income. During the nine months ended September 30, 2020, we recorded $36.0 million upfront and additional $3.0 million in amortization of the deferred component as a gain on IP matter in our condensed consolidated statements of income. See Note 12 of the notes to condensed consolidated financial statements included in Part I, Item 1 of this Quarterly Report on Form 10-Q for additional information regarding the gain on IP matter.

[0001262039-21-000030:mdna:157]
[same as prior period, unchanged from 0001262039-21-000022:mdna:156]

[0001262039-21-000030:mdna:158]
We generated operating income of $435.5 million during the nine months ended September 30, 2021, an increase of $73.1 million, or 20%, compared to $362.4 million in the same period last year. Operating income as a percentage of revenue decreased to 18% during the nine months ended September 30, 2021 compared to 20% in the same period last year. During the nine months ended September 30, 2020, we recorded $36.0 million upfront and additional $3.0 million in amortization of the deferred component as a gain on IP matter, which increased our operating margin by 2.1 percentage points. Excluding the impact of this gain, our operating margin increased 0.7 percentage points primarily due to 1.2 percentage point, 0.6 percentage point and 0.4 percentage point decreases in sales and marketing expense, research and development expense and general and administrative expense as percentage of revenue, respectively, partially offset by a decrease in gross margin largely driven by the mix shift from service revenue to product revenue.

[0001262039-21-000030:mdna:159]
40

[0001262039-21-000030:mdna:160]
[same as prior period, unchanged from 0001262039-21-000022:mdna:158]

[0001262039-21-000030:mdna:161]
|  | Nine Months Ended |  |  |  |  |
| September 30,2021 |  | September 30,2020 |  | Change |  | % Change |
| (in millions, except percentages) |
| Interest income | $ | 3.5 |  |  | $ | 15.7 |  |  | $ | (12.2) |  |  | (78) | % |
| Interest expense | $ | (10.4) |  |  | $ | — |  |  | $ | (10.4) |  |  | * |
| Other expense—net | $ | (7.5) |  |  | $ | (8.1) |  |  | $ | 0.6 |  |  | (7) | % |

[0001262039-21-000030:mdna:162]
* Not meaningful

[0001262039-21-000030:mdna:163]
Interest income decreased by $12.2 million during the nine months ended September 30, 2021 compared to the same period last year, primarily as a result of lower interest rates. Interest income varies depending on our average investment balances during the period, types and mix of investments, and market interest rates. Interest expense increased by $10.4 million during the nine months ended September 30, 2021 compared to the same period last year, primarily due to the senior notes issued in the first quarter of 2021. The other expense—net decreased by $0.6 during the nine months ended September 30, 2021 compared to the same period last year was the result of a $4.3 million impairment charge on an investment in a privately held company during the first quarter of 2020, partially offset by a $3.2 million increase of loss on marketable equity securities and a $0.3 million increase of foreign currency exchange loss during the nine months ended September 30, 2021 compared to the same period last year.

[0001262039-21-000030:mdna:164]
[same as prior period, unchanged from 0001262039-21-000022:mdna:127]

[0001262039-21-000030:mdna:165]
|  | Nine Months Ended |  | Change |  | % Change |
| September 30,2021 |  | September 30,2020 |  |
| (in millions, except percentages) |
| Provision for income taxes | $ | 10.4 |  |  | $ | 28.2 |  |  | $ | (17.8) |  |  | (63) | % |
| Effective tax rate (%) | 2 | % |  | 8 | % |  |  |  |  |

[0001262039-21-000030:mdna:166]
Our effective tax rate was 2% for the nine months ended September 30, 2021 compared to an effective tax rate of 8% for the same period last year. The provision for income taxes for the nine months ended September 30, 2021 was primarily comprised of U.S. federal and state taxes, withholding taxes and foreign taxes that were $115.8 million. This tax provision for income taxes was favorably affected by a tax benefit of $23.9 million from the FDII deduction, excess tax benefits from stock-based compensation expense of $60.3 million and release of reserves of $5.5 million on uncertain tax positions and the interest due to the expiration of the statute of limitations. The tax provision for income taxes was further impacted by a tax benefit of $15.7 million for a change in tax accounting positions in finalization of the prior year tax return.

[0001262039-21-000030:mdna:167]
The provision for income taxes for the nine months ended September 30, 2020 was comprised of U.S. federal and state taxes, withholding taxes, and foreign taxes that were $100.7 million, which were offset by a tax benefit of $25.9 million from the FDII deduction, excess tax benefits from stock-based compensation expense of $37.6 million and release of reserves of $9.0 million on uncertain tax positions and the interest due to the expiration of the statute of limitations.

[0001262039-21-000030:mdna:168]
41

[0001262039-21-000030:mdna:169]
[same as prior period, unchanged from 0001262039-21-000022:mdna:166]

[0001262039-21-000030:mdna:170]
|  | As of |
|  | September 30,2021 |  | December 31,2020 |
|  | (in millions) |
| Cash and cash equivalents | $ | 1,852.1 |  |  | $ | 1,061.8 |  |
| Short-term and long-term investments | 1,526.3 |  |  | 893.8 |  |
| Marketable equity securities | 40.8 |  |  | — |  |
| Total cash, cash equivalents, investments and marketable equity securities | $ | 3,419.2 |  |  | $ | 1,955.6 |  |
| Working capital | $ | 1,765.5 |  |  | $ | 910.9 |  |
|  | Nine Months Ended |
|  | September 30,2021 |  | September 30,2020 |
|  | (in millions) |
| Net cash provided by operating activities | $ | 1,132.9 |  |  | $ | 787.2 |  |
| Net cash used in investing activities | (1,059.2) |  |  | (7.8) |  |
| Net cash provided by (used in) financing activities | 716.4 |  |  | (1,119.6) |  |
| Effect of exchange rate changes on cash and cash equivalents | 0.2 |  |  | — |  |
| Net increase (decrease) in cash and cash equivalents | $ | 790.3 |  |  | $ | (340.2) |  |

[0001262039-21-000030:mdna:171]
[same as prior period, unchanged from 0001262039-21-000022:mdna:168]

[0001262039-21-000030:mdna:172]
[same as prior period, unchanged from 0001262039-21-000022:mdna:169]

[0001262039-21-000030:mdna:173]
In February 2020, we received a cash payment of $50.0 million pursuant to a mutual covenant-not-to-sue and release agreement with a competitor in the network security industry.

[0001262039-21-000030:mdna:174]
In October 2021, our board of directors authorized a $1.25 billion increase in the authorized stock repurchase under the Repurchase Program and extended the term of the Repurchase Program to February 28, 2023, bringing the aggregate amount of authorized to be repurchased to $4.25 billion of our outstanding common stock through February 28, 2023. During the nine months ended September 30, 2021, we repurchased 0.8 million shares of common stock under the Repurchase Program for an aggregate purchase price of $200.4 million. As of September 30, 2021, $812.3 million remained available for future share repurchases under the Repurchase Program.

[0001262039-21-000030:mdna:175]
[same as prior period, unchanged from 0001262039-21-000022:mdna:173]

[0001262039-21-000030:mdna:176]
We believe that our cash provided by operating activities, together with our existing cash, cash equivalents and investments will be sufficient to meet our anticipated cash needs and do not intend to retire these Notes early. Refer to Note 11. Debt in Part I, Item 1 of this Quarterly Report on Form 10-Q for information on the Notes. As of September 30, 2021, the long-term debt, net of unamortized discount and debt issuance costs, was $988.0 million.

[0001262039-21-000030:mdna:177]
Construction of a second building at our headquarters campus started in the fourth quarter of 2018 and was completed in the second quarter of 2021. We estimate the full year capital expenditures to be between $315.0 and $335.0 million. Our estimated 2021 capital expenditures increased compared to our prior quarter guidance mainly due to our real estate purchases.

[0001262039-21-000030:mdna:178]
42

[0001262039-21-000030:mdna:179]
We enter into non-cancellable agreements with contract manufacturers and certain suppliers to procure inventory based on our requirements in order to reduce manufacturing lead times, plan for adequate component supply or incentivize suppliers to deliver. These purchase commitments totaled $868.0 million as of September 30, 2021.

[0001262039-21-000030:mdna:180]
As of September 30, 2021, our cash, cash equivalents, short-term and long-term investments and marketable equity securities of $3.42 billion were invested primarily in deposit accounts, money market funds, corporate debt securities, commercial paper, certificates of deposit and term deposits, U.S. government securities, municipal bonds and marketable equity securities. It is our investment policy to invest excess cash in a manner that preserves capital, provides liquidity and generates return without significantly increasing risk. We do not enter into investments for trading or speculative purposes.

[0001262039-21-000030:mdna:181]
The amount of cash, cash equivalents and investments held by our international subsidiaries was $126.4 million as of September 30, 2021 and $119.8 million as of December 31, 2020.

[0001262039-21-000030:mdna:182]
[same as prior period, unchanged from 0001262039-21-000022:mdna:178]

[0001262039-21-000030:mdna:183]
[same as prior period, unchanged from 0001262039-21-000022:mdna:179]

[0001262039-21-000030:mdna:184]
[same as prior period, unchanged from 0001262039-21-000022:mdna:180]

[0001262039-21-000030:mdna:185]
Our operating activities during the nine months ended September 30, 2021 provided cash flows of $1.13 billion as a result of the continued growth of our business and our ability to successfully manage our working capital. Changes in operating assets and liabilities primarily resulted from an increase in sales of our FortiGuard and other security subscription services and FortiCare technical support services to new and existing customers, as reflected by an increase in our deferred revenue. Our total deferred revenue balance grew $501.1 million, or 19%, during the nine months ended September 30, 2021.

[0001262039-21-000030:mdna:186]
[same as prior period, unchanged from 0001262039-21-000022:mdna:182]

[0001262039-21-000030:mdna:187]
[same as prior period, unchanged from 0001262039-21-000022:mdna:183]

[0001262039-21-000030:mdna:188]
During the nine months ended September 30, 2021, cash used in investing activities was $1.06 billion, driven by $638.7 million spent for purchases of investments, net of maturities and sales of investments, $160.0 million used for purchases of investment in a privately held company, $144.6 million of purchases of property and equipment, a large portion of which relates to our headquarters building construction, $73.4 million used for the acquisition of AlaxalA and ShieldX Networks, Inc. (“ShieldX”), net of cash and $42.5 million used for purchases of marketable equity securities.

[0001262039-21-000030:mdna:189]
[same as prior period, unchanged from 0001262039-21-000022:mdna:185]

[0001262039-21-000030:mdna:190]
[same as prior period, unchanged from 0001262039-21-000022:mdna:186]

[0001262039-21-000030:mdna:191]
During the nine months ended September 30, 2021, cash provided by financing activities was $716.4 million, primarily driven by $989.4 million in cash proceeds from long-term investment grade debt, net of discount and underwriting

[0001262039-21-000030:mdna:192]
43

[0001262039-21-000030:mdna:193]
fees, partially offset by $170.0 million used to repurchase shares of our common stock and $98.2 million used to pay tax withholding, net of proceeds from the issuance of common stock.

[0001262039-21-000030:mdna:194]
[same as prior period, unchanged from 0001262039-21-000022:mdna:188]

[0001262039-21-000030:mdna:195]
There were no material changes outside the ordinary course of business during the nine months ended September 30, 2021 to the contractual obligations and commitments disclosed in Management’s Discussion and Analysis of Financial Condition and Results of Operations, set forth in Part II, Item 7, of the Form 10-K. See Note 13 of the notes to condensed consolidated financial statements included in Part I, Item 1 of this Quarterly Report on Form 10-Q for additional information regarding contractual obligations and commitments.

[0001262039-21-000030:mdna:196]
[same as prior period, unchanged from 0001262039-21-000022:mdna:190]

[0001262039-21-000030:mdna:197]
As of September 30, 2021, we did not have any relationships with unconsolidated organizations or financial partnerships, such as structured finance or special purpose entities that would have been established for the purpose of facilitating off-balance sheet arrangements or other contractually narrow or limited purposes.
