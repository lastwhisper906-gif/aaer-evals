# FTNT note change history — 0001262039-25-000017 → 0001262039-25-000028


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2025-08-08):
[0001262039-25-000028:note_history:1]
COMMITMENTS AND CONTINGENCIES
The following table summarizes our inventory purchase commitments as of June 30, 2025 (in millions):
  (was, 2025-05-08, similarity 0.9641):
[0001262039-25-000017:note_history:1]
COMMITMENTS AND CONTINGENCIES
The following table summarizes our inventory purchase commitments as of March 31, 2025 (in millions):

- changed (2025-08-08):
[0001262039-25-000028:note_history:2]
As of June 30, 2025, we had $714.4 million of non-cancelable inventory purchase commitments with our independent contract manufacturers. We recorded a liability for these purchase commitments for quantities in excess of our future estimated demand forecasts, consistent with the valuation of our excess and obsolete inventory. As of June 30, 2025 and December 31, 2024, the liability for these inventory purchase commitments was $41.9 million and $54.0 million, respectively, and was recorded in accrued liabilities on our condensed consolidated balance sheets. The expense related to such accrued liability for inventory purchase commitments is recorded in cost of product revenue on the condensed consolidated statements of income. It was immaterial during the three and six months ended June 30, 2025, and was $7.0 million and $38.6 million during the three and six months ended June 30, 2024, respectively.
  (was, 2025-05-08, similarity 0.791):
[0001262039-25-000017:note_history:2]
As of March 31, 2025, we had $689.0 million of non-cancelable inventory purchase commitments with our independent contract manufacturers. We recorded a liability for these purchase commitments for quantities in excess of our future estimated demand forecasts, consistent with the valuation of our excess and obsolete inventory. As of March 31, 2025 and December 31, 2024, the liability for these inventory purchase commitments was $47.5 million and $54.0 million, respectively, and was recorded in accrued liabilities on our condensed consolidated balance sheets. The expense related to such accrued liability for inventory purchase commitments was $4.5 million benefit and a $31.6 million cost during the three months ended March 31, 2025 and 2024, respectively, and was recorded in cost of product revenue on the condensed consolidated statements of income.

- changed (2025-08-08):
[0001262039-25-000028:note_history:3]
Other Contractual Commitments and Open Purchase Orders—In addition to commitments with contract manufacturers, we have open purchase orders and contractual obligations in the ordinary course of business for which we have not received goods or services. A significant portion of our reported purchase commitments consist of non-cancelable commitments. In certain instances, contractual commitments allow us the option to cancel, reschedule and adjust our requirements based on our business needs prior to firm orders being placed. As of June 30, 2025, we had $102.7 million in other contractual commitments having a remaining term in excess of one year that are non-cancelable.
  (was, 2025-05-08, similarity 0.9932):
[0001262039-25-000017:note_history:3]
Other Contractual Commitments and Open Purchase Orders—In addition to commitments with contract manufacturers, we have open purchase orders and contractual obligations in the ordinary course of business for which we have not received goods or services. A significant portion of our reported purchase commitments consist of non-cancelable commitments. In certain instances, contractual commitments allow us the option to cancel, reschedule and adjust our requirements based on our business needs prior to firm orders being placed. As of March 31, 2025, we had $94.7 million in other contractual commitments having a remaining term in excess of one year that are non-cancelable.

- changed (2025-08-08):
[0001262039-25-000028:note_history:4]
As of June 30, 2025, we had $93.4 million in contractual commitments related to payments for operating leases.
  (was, 2025-05-08, similarity 0.9557):
[0001262039-25-000017:note_history:4]
As of March 31, 2025, we had $81.6 million in contractual commitments related to payments for operating leases.

- changed (2025-08-08):
[0001262039-25-000028:note_history:5]
Litigation—We are involved in disputes, litigation, and other legal actions. For lawsuits where we are the defendant, we are in the process of defending these litigation matters, and while there can be no assurances and the outcome of certain of these matters is currently not determinable and not predictable, we currently are unaware of any existing claims or proceedings that we believe are likely to have a material adverse effect on our financial position. There are many uncertainties associated with any litigation and these actions or other third-party claims against us may cause us to incur costly litigation fees, costs and substantial settlement charges, and possibly subject us to damages and other penalties. In addition, the resolution of any intellectual property (“IP”) litigation may require us to make royalty payments, which could adversely affect our gross margins in future periods. If any of those events were to occur, our business, financial condition, results of operations, and cash flows could be adversely affected. Litigation is unpredictable and the actual liability in any such matters may be materially different from our current estimates, which could result in the need to adjust any accrued liability and record additional expenses. We accrue for contingencies when we believe that a loss is probable and that we can reasonably estimate the amount of any such loss. These accruals are generally based on a range of possible outcomes that require significant management judgement. If no amount within a range is a better estimate than any other, we accrue the minimum amount. Litigation loss contingency accruals associated with outstanding cases were not material as of June 30, 2025 and December 31, 2024.
  (was, 2025-05-08, similarity 0.9974):
[0001262039-25-000017:note_history:5]
Litigation—We are involved in disputes, litigation, and other legal actions. For lawsuits where we are the defendant, we are in the process of defending these litigation matters, and while there can be no assurances and the outcome of certain of these matters is currently not determinable and not predictable, we currently are unaware of any existing claims or proceedings that we believe are likely to have a material adverse effect on our financial position. There are many uncertainties associated with any litigation and these actions or other third-party claims against us may cause us to incur costly litigation fees, costs and substantial settlement charges, and possibly subject us to damages and other penalties. In addition, the resolution of any intellectual property (“IP”) litigation may require us to make royalty payments, which could adversely affect our gross margins in future periods. If any of those events were to occur, our business, financial condition, results of operations, and cash flows could be adversely affected. Litigation is unpredictable and the actual liability in any such matters may be materially different from our current estimates, which could result in the need to adjust any accrued liability and record additional expenses. We accrue for contingencies when we believe that a loss is probable and that we can reasonably estimate the amount of any such loss. These accruals are generally based on a range of possible outcomes that require significant management judgement. If no amount within a range is a better estimate than any other, we accrue the minimum amount. Litigation loss contingency accruals associated with outstanding cases were not material as of March 31, 2025, and December 31, 2024.

- changed (2025-08-08):
[0001262039-25-000028:note_history:6]
On March 21, 2019, we were sued by Alorica Inc. (“Alorica”) in Santa Clara County Superior Court in California. Alorica alleged breach of warranty and misrepresentation claims, which we denied. After trial, a jury returned a verdict fully in favor of us and against Alorica on October 4, 2024. Alorica has filed a notice of appeal. We believe that the ultimate outcome of this matter will not materially impact our financial position, results of operations or cash flows. However, any further legal proceedings, including Alorica’s appeal, would be subject to inherent uncertainties, and a future unfavorable ruling could occur. No loss accrual had been recorded as of June 30, 2025 or December 31, 2024 related to this litigation.
  (was, 2025-05-08, similarity 0.9937):
[0001262039-25-000017:note_history:6]
On March 21, 2019, we were sued by Alorica Inc. (“Alorica”) in Santa Clara County Superior Court in California. Alorica alleged breach of warranty and misrepresentation claims, which we denied. After trial, a jury returned a verdict fully in favor of us and against Alorica on October 4, 2024. Alorica has filed a notice of appeal. We believe that the ultimate outcome of this matter will not materially impact our financial position, results of operations or cash flows. However, any further legal proceedings, including Alorica’s appeal, would be subject to inherent uncertainties, and a future unfavorable ruling could occur. No loss accrual had been recorded as of March 31, 2025 or December 31, 2024 related to this litigation.

- added (2025-08-08):
[0001262039-25-000028:note_history:7]
Indemnification and Other Matters—We enter into indemnification provisions in the ordinary course of business with other companies such as partners, customers, and vendors, where we agree to indemnify, hold harmless, and reimburse the indemnified party for certain losses suffered or incurred by the indemnified party as a result of our activities, including defending against third-party claims asserting various allegations such as product defects, breach of representations or covenants, and infringement of certain IP rights, which may include patents, copyrights, trademarks or trade secrets, and to pay judgments entered on such claims. In some contracts, our exposure under these indemnification provisions is limited by the terms of the contracts to certain defined limits, such as the total amount paid by our customer under the agreement. However, certain agreements include covenants, penalties and indemnification provisions including and beyond indemnification for third-party claims of IP infringement that could potentially expose us to losses in excess of the amount received under the agreement, and in some instances to potential liability that is not contractually limited. Although from time to time there are indemnification claims asserted against us and currently there are pending indemnification claims, to date there have been no material awards under such indemnification provisions.

- removed (2025-08-08):
[0001262039-25-000017:note_history:8]
Indemnification and Other Matters—We enter into indemnification provisions in the ordinary course of business with other companies such as partners, customers, and vendors, where we agree to indemnify, hold harmless, and reimburse the

- removed (2025-08-08):
[0001262039-25-000017:note_history:9]
indemnified party for certain losses suffered or incurred by the indemnified party as a result of our activities, including defending against third-party claims asserting various allegations such as product defects, breach of representations or covenants, and infringement of certain IP rights, which may include patents, copyrights, trademarks or trade secrets, and to pay judgments entered on such claims. In some contracts, our exposure under these indemnification provisions is limited by the terms of the contracts to certain defined limits, such as the total amount paid by our customer under the agreement. However, certain agreements include covenants, penalties and indemnification provisions including and beyond indemnification for third-party claims of IP infringement that could potentially expose us to losses in excess of the amount received under the agreement, and in some instances to potential liability that is not contractually limited. Although from time to time there are indemnification claims asserted against us and currently there are pending indemnification claims, to date there have been no material awards under such indemnification provisions.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2025-08-08):
[0001262039-25-000028:note_history:10]
SUMMARY OF SIGNIFICANT ACCOUNTING POLICIES
Basis of Presentation and Preparation—The unaudited condensed consolidated financial statements of Fortinet, Inc. and its subsidiaries (collectively, “we,” “us” or “our”) have been prepared in accordance with generally accepted accounting principles in the United States (“GAAP”) for interim financial information, as well as the instructions to Form 10-Q pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (the “SEC”). Accordingly, they do not include all of the information and footnotes required by GAAP for complete financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the year ended December 31, 2024, contained in our Annual Report on Form 10-K filed with the SEC on February 21, 2025. In the opinion of management, all adjustments, which include normal recurring adjustments, considered necessary for a fair presentation, have been included. The results of operations for the three and six months ended June 30, 2025 are not necessarily indicative of the results to be expected for the full year or for any future periods. The condensed consolidated balance sheet as of December 31, 2024 is derived from the audited consolidated financial statements for the year ended December 31, 2024.
  (was, 2025-05-08, similarity 0.792):
[0001262039-25-000017:note_history:10]
SUMMARY OF SIGNIFICANT ACCOUNTING POLICIES
Basis of Presentation and Preparation—The unaudited condensed consolidated financial statements of Fortinet, Inc. and its subsidiaries (collectively, “we,” “us” or “our”) have been prepared in accordance with generally accepted accounting principles in the United States (“GAAP”) for interim financial information, as well as the instructions to Form 10-Q pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (the “SEC”). Accordingly, they do not include all of the information and footnotes required by GAAP for complete financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the year ended December 31, 2024, contained in our Annual Report on Form 10-K filed with the SEC on February 21, 2025. In the opinion of management, all adjustments, which include normal recurring adjustments, considered necessary for a fair presentation, have been included. The results of operations for the three months ended March 31, 2025 are not necessarily indicative of the results to be expected for the full year or for any future periods. The condensed consolidated balance sheet as of December 31, 2024 is derived from the audited consolidated financial statements for the year ended December 31, 2024.

- changed (2025-08-08):
[0001262039-25-000028:note_history:11]
Amounts previously reported as gain on bargain purchase are included in other income (expense)—net in prior periods to conform with current period presentation in our condensed consolidated statements of income. Amounts previously reported as loss from equity method investments and gain on bargain purchase are included in other in prior periods to conform with current period presentation in section of net cash provided by operating activities in our condensed consolidated statements of cash flows.
  (was, 2025-05-08, similarity 0.8298):
[0001262039-25-000017:note_history:11]
Amounts previously reported as marketable equity securities are included in short-term investments in prior periods to conform with current period presentation in our condensed consolidated balance sheets. Amounts previously reported as gain on bargain purchase are included in other income (expense)—net in prior periods to conform with current period presentation in our condensed consolidated statements of income. Amounts previously reported as loss from equity method investments and gain on bargain purchase are included in other in prior periods to conform with current period presentation in section of net cash provided by operating activities in our condensed consolidated statements of cash flows.

- changed (2025-08-08):
[0001262039-25-000028:note_history:12]
There have been no material changes to our significant accounting policies as of and for the six months ended June 30, 2025, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended December 31, 2024 filed with the SEC.
  (was, 2025-05-08, similarity 0.9174):
[0001262039-25-000017:note_history:12]
There have been no material changes to our significant accounting policies as of and for the three months ended March 31, 2025, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended December 31, 2024 filed with the SEC.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-08-08):
[0001262039-25-000028:note_history:13]
On March 5, 2021, we issued $1.0 billion aggregate principal amount of senior notes (collectively, the “Senior Notes”), consisting of $500.0 million aggregate principal amount of 1.0% notes due March 15, 2026 (the “2026 Senior Notes”) and $500.0 million aggregate principal amount of 2.2% notes due March 15, 2031 (the “2031 Senior Notes”), in an underwritten registered public offering. The Senior Notes are senior unsecured obligations and rank equally with each other in right of payment and with our other outstanding obligations. We may redeem the Senior Notes at any time in whole or in part for cash, at specified redemption prices that include accrued and unpaid interest, if any, and a make-whole premium. However, no make-whole premium will be paid for redemptions of the 2026 Senior Notes on or after February 15, 2026, or the 2031 Senior Notes on or after December 15, 2030. Interest on the Senior Notes is payable on March 15 and September 15 of each year, beginning on September 15, 2021. The 2026 Senior Notes were recorded as current portion of long-term debt and the 2031 Senior Notes were recorded as long-term debt as of June 30, 2025 and both of the Senior Notes were recorded as long-term debt as of December 31, 2024, net of discount and issuance costs, which are amortized to interest expense over the respective contractual terms of these notes using the effective interest method.
  (was, 2025-05-08, similarity 0.9966):
[0001262039-25-000017:note_history:13]
On March 5, 2021, we issued $1.0 billion aggregate principal amount of senior notes (collectively, the “Senior Notes”), consisting of $500.0 million aggregate principal amount of 1.0% notes due March 15, 2026 (the “2026 Senior Notes”) and $500.0 million aggregate principal amount of 2.2% notes due March 15, 2031 (the “2031 Senior Notes”), in an underwritten registered public offering. The Senior Notes are senior unsecured obligations and rank equally with each other in right of payment and with our other outstanding obligations. We may redeem the Senior Notes at any time in whole or in part for cash, at specified redemption prices that include accrued and unpaid interest, if any, and a make-whole premium. However, no make-whole premium will be paid for redemptions of the 2026 Senior Notes on or after February 15, 2026, or the 2031 Senior Notes on or after December 15, 2030. Interest on the Senior Notes is payable on March 15 and September 15 of each year, beginning on September 15, 2021. The 2026 Senior Notes were recorded as current portion of long-term debt and the 2031 Senior Notes were recorded as long-term debt as of March 31, 2025 and both of the Senior Notes were recorded as long-term debt as of December 31, 2024, net of discount and issuance costs, which are amortized to interest expense over the respective contractual terms of these notes using the effective interest method.

- changed (2025-08-08):
[0001262039-25-000028:note_history:14]
|  | Maturity |  | Coupon Rate |  | Effective Interest Rate |  | June 30,2025 |  | December 31,2024 |
| Debt |  |  |  |  |  |  |  |  |  |
| 2026 Senior Notes | March 2026 |  | 1.0% |  | 1.3% |  | $ | 500.0 |  |  | $ | 500.0 |  |
| 2031 Senior Notes | March 2031 |  | 2.2% |  | 2.3% |  | 500.0 |  |  | 500.0 |  |
| Total debt |  |  |  |  |  |  | 1,000.0 |  |  | 1,000.0 |  |
| Less: Unamortized discount and debt issuance costs |  |  |  |  |  |  | 4.7 |  |  | 5.7 |  |
| Less: Current portion of long-term debt |  |  |  |  |  |  | $ | 499.0 |  |  | $ | — |  |
| Total long-term debt |  |  |  |  |  |  | $ | 496.3 |  |  | $ | 994.3 |  |
  (was, 2025-05-08, similarity 0.9909):
[0001262039-25-000017:note_history:14]
|  | Maturity |  | Coupon Rate |  | Effective Interest Rate |  | March 31,2025 |  | December 31,2024 |
| Debt |  |  |  |  |  |  |  |  |  |
| 2026 Senior Notes | March 2026 |  | 1.0% |  | 1.3% |  | $ | 500.0 |  |  | $ | 500.0 |  |
| 2031 Senior Notes | March 2031 |  | 2.2% |  | 2.3% |  | 500.0 |  |  | 500.0 |  |
| Total debt |  |  |  |  |  |  | 1,000.0 |  |  | 1,000.0 |  |
| Less: Unamortized discount and debt issuance costs |  |  |  |  |  |  | 5.1 |  |  | 5.7 |  |
| Less: Current portion of long-term debt |  |  |  |  |  |  | $ | 498.7 |  |  | $ | — |  |
| Total long-term debt |  |  |  |  |  |  | $ | 496.2 |  |  | $ | 994.3 |  |

- changed (2025-08-08):
[0001262039-25-000028:note_history:15]
As of June 30, 2025 and December 31, 2024, we accrued interest payable of $4.7 million, and there are no financial covenants with which we must comply. During the three months ended June 30, 2025 and 2024, we recorded $4.5 million of total interest expense in relation to these Senior Notes in each period. During the six months ended June 30, 2025 and 2024, we recorded $9.0 million of total interest expense in relation to these Senior Notes in each period. No interest costs were capitalized for the six months ended June 30, 2025 and 2024, as the costs that qualified for capitalization were not material.
  (was, 2025-05-08, similarity 0.6536):
[0001262039-25-000017:note_history:15]
As of March 31, 2025 and December 31, 2024, we accrued interest payable of $0.7 million and $4.7 million, respectively, and there are no financial covenants with which we must comply. During the three months ended March 31, 2025 and 2024, we recorded $4.5 million of total interest expense in relation to these Senior Notes in each period. No interest costs were capitalized for the three months ended March 31, 2025 and 2024, as the costs that qualified for capitalization were not material.

- changed (2025-08-08):
[0001262039-25-000028:note_history:16]
The total estimated fair value of the outstanding Senior Notes was approximately $933.1 million, including accrued and unpaid interest, as of June 30, 2025. The fair value was determined based on observable market prices of identical instruments in less active markets. The estimated fair values are based on Level 2 inputs.
  (was, 2025-05-08, similarity 0.9857):
[0001262039-25-000017:note_history:16]
The total estimated fair value of the outstanding Senior Notes was approximately $919.6 million, including accrued and unpaid interest, as of March 31, 2025. The fair value was determined based on observable market prices of identical instruments in less active markets. The estimated fair values are based on Level 2 inputs.


## us-gaap:DebtSecuritiesAvailableForSaleUnrealizedLossPositionFairValueTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-08-08):
[0001262039-25-000028:note_history:17]
|  | June 30, 2025 |
|  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
|  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |
| U.S. government and agency securities | $ | 393.7 |  |  | $ | (0.1) |  |  | $ | — |  |  | $ | — |  |  | $ | 393.7 |  |  | $ | (0.1) |  |
| Commercial paper | 355.1 |  |  | (0.1) |  |  | — |  |  | — |  |  | 355.1 |  |  | (0.1) |  |
| Corporate debt securities | 119.1 |  |  | (0.1) |  |  | — |  |  | — |  |  | 119.1 |  |  | (0.1) |  |
| Certificates of deposit and term deposits | 19.3 |  |  | — |  |  | — |  |  | — |  |  | 19.3 |  |  | — |  |
| Total available-for-sale investments | $ | 887.2 |  |  | $ | (0.3) |  |  | $ | — |  |  | $ | — |  |  | $ | 887.2 |  |  | $ | (0.3) |  |
  (was, 2025-05-08, similarity 0.869):
[0001262039-25-000017:note_history:17]
|  | March 31, 2025 |
|  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
|  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |
| U.S. government and agency securities | $ | 119.7 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 119.7 |  |  | $ | — |  |
| Commercial paper | 260.5 |  |  | (0.1) |  |  | — |  |  | — |  |  | 260.5 |  |  | (0.1) |  |
| Corporate debt securities | 83.8 |  |  | (0.1) |  |  | — |  |  | — |  |  | 83.8 |  |  | (0.1) |  |
| Certificates of deposit and term deposits | 9.5 |  |  | — |  |  | — |  |  | — |  |  | 9.5 |  |  | — |  |
| Total available-for-sale investments | $ | 473.5 |  |  | $ | (0.2) |  |  | $ | — |  |  | $ | — |  |  | $ | 473.5 |  |  | $ | (0.2) |  |


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-08-08):
[0001262039-25-000028:note_history:18]
|  | Maturity |  | Coupon Rate |  | Effective Interest Rate |  | June 30,2025 |  | December 31,2024 |
| Debt |  |  |  |  |  |  |  |  |  |
| 2026 Senior Notes | March 2026 |  | 1.0% |  | 1.3% |  | $ | 500.0 |  |  | $ | 500.0 |  |
| 2031 Senior Notes | March 2031 |  | 2.2% |  | 2.3% |  | 500.0 |  |  | 500.0 |  |
| Total debt |  |  |  |  |  |  | 1,000.0 |  |  | 1,000.0 |  |
| Less: Unamortized discount and debt issuance costs |  |  |  |  |  |  | 4.7 |  |  | 5.7 |  |
| Less: Current portion of long-term debt |  |  |  |  |  |  | $ | 499.0 |  |  | $ | — |  |
| Total long-term debt |  |  |  |  |  |  | $ | 496.3 |  |  | $ | 994.3 |  |
  (was, 2025-05-08, similarity 0.9909):
[0001262039-25-000017:note_history:18]
|  | Maturity |  | Coupon Rate |  | Effective Interest Rate |  | March 31,2025 |  | December 31,2024 |
| Debt |  |  |  |  |  |  |  |  |  |
| 2026 Senior Notes | March 2026 |  | 1.0% |  | 1.3% |  | $ | 500.0 |  |  | $ | 500.0 |  |
| 2031 Senior Notes | March 2031 |  | 2.2% |  | 2.3% |  | 500.0 |  |  | 500.0 |  |
| Total debt |  |  |  |  |  |  | 1,000.0 |  |  | 1,000.0 |  |
| Less: Unamortized discount and debt issuance costs |  |  |  |  |  |  | 5.1 |  |  | 5.7 |  |
| Less: Current portion of long-term debt |  |  |  |  |  |  | $ | 498.7 |  |  | $ | — |  |
| Total long-term debt |  |  |  |  |  |  | $ | 496.2 |  |  | $ | 994.3 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2025-08-08):
[0001262039-25-000028:note_history:19]
|  | Three Months Ended |  | Six Months Ended |
|  | June 30,2025 |  | June 30,2024 |  | June 30,2025 |  | June 30,2024 |
| Product | $ | 508.9 |  |  | $ | 451.9 |  |  | $ | 968.0 |  |  | $ | 860.8 |  |
| Service: |  |  |  |  |  |  |  |
| Security subscription | 644.4 |  |  | 558.7 |  |  | 1,267.5 |  |  | 1,095.6 |  |
| Technical support and other | 476.7 |  |  | 423.7 |  |  | 934.2 |  |  | 831.2 |  |
| Total service revenue | 1,121.1 |  |  | 982.4 |  |  | 2,201.7 |  |  | 1,926.8 |  |
| Total revenue | $ | 1,630.0 |  |  | $ | 1,434.3 |  |  | $ | 3,169.7 |  |  | $ | 2,787.6 |  |

- removed (2025-08-08):
[0001262039-25-000017:note_history:20]
|  | Three Months Ended |  |  |
|  | March 31,2025 |  | March 31,2024 |  |  |  |  |
| Product | $ | 459.1 |  |  | $ | 408.9 |  |  |  |  |  |
| Service: |  |  |  |  |  |  |  |
| Security subscription | 623.1 |  |  | 536.9 |  |  |  |  |  |
| Technical support and other | 457.5 |  |  | 407.5 |  |  |  |  |  |
| Total service revenue | 1,080.6 |  |  | 944.4 |  |  |  |  |  |
| Total revenue | $ | 1,539.7 |  |  | $ | 1,353.3 |  |  |  |  |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2025-08-08):
[0001262039-25-000028:note_history:21]
|  | Three Months Ended |  | Six Months Ended |
|  | June 30,2025 |  | June 30,2024 |  | June 30,2025 |  | June 30,2024 |
| Product | $ | 508.9 |  |  | $ | 451.9 |  |  | $ | 968.0 |  |  | $ | 860.8 |  |
| Service: |  |  |  |  |  |  |  |
| Security subscription | 644.4 |  |  | 558.7 |  |  | 1,267.5 |  |  | 1,095.6 |  |
| Technical support and other | 476.7 |  |  | 423.7 |  |  | 934.2 |  |  | 831.2 |  |
| Total service revenue | 1,121.1 |  |  | 982.4 |  |  | 2,201.7 |  |  | 1,926.8 |  |
| Total revenue | $ | 1,630.0 |  |  | $ | 1,434.3 |  |  | $ | 3,169.7 |  |  | $ | 2,787.6 |  |

- changed (2025-08-08):
[0001262039-25-000028:note_history:22]
During the three and six months ended June 30, 2025, we recognized $876.8 million and $1.85 billion in revenue that was included in the deferred revenue balance as of December 31, 2024, respectively. During the three and six months ended June 30, 2024, we recognized $764.3 million and $1.62 billion in revenue that was included in the deferred revenue balance as of December 31, 2023, respectively.
  (was, 2025-05-08, similarity 0.6337):
[0001262039-25-000017:note_history:22]
During the three months ended March 31, 2025 and 2024, we recognized $972.5 million and $851.1 million in revenue that was included in the deferred revenue balance as of December 31, 2024 and 2023, respectively.

- changed (2025-08-08):
[0001262039-25-000028:note_history:23]
As of June 30, 2025, the aggregate amount of the transaction price allocated to remaining performance obligations was $6.64 billion, which was substantially comprised of deferred security subscription and technical support services revenue as well as unbilled contract revenue from non-cancellable contracts that will be recognized in future periods. We expect to recognize approximately $3.45 billion as revenue over the next 12 months, $2.61 billion in years two and three, and the remainder thereafter.
  (was, 2025-05-08, similarity 0.9908):
[0001262039-25-000017:note_history:23]
As of March 31, 2025, the aggregate amount of the transaction price allocated to remaining performance obligations was $6.49 billion, which was substantially comprised of deferred security subscription and technical support services revenue as well as unbilled contract revenue from non-cancellable contracts that will be recognized in future periods. We expect to recognize approximately $3.38 billion as revenue over the next 12 months, $2.55 billion in years two and three, and the remainder thereafter.

- changed (2025-08-08):
[0001262039-25-000028:note_history:24]
Amortization of deferred contract costs during the three months ended June 30, 2025 and 2024 was $82.0 million and $72.7 million, respectively. Amortization of deferred contract costs during the six months ended June 30, 2025 and 2024 was $160.0 million and $144.7 million, respectively.
  (was, 2025-05-08, similarity 0.634):
[0001262039-25-000017:note_history:24]
Amortization of deferred contract costs during the three months ended March 31, 2025 and 2024 were $78.0 million and $72.0 million, respectively.

- removed (2025-08-08):
[0001262039-25-000017:note_history:25]
|  | Three Months Ended |  |  |
|  | March 31,2025 |  | March 31,2024 |  |  |  |  |
| Product | $ | 459.1 |  |  | $ | 408.9 |  |  |  |  |  |
| Service: |  |  |  |  |  |  |  |
| Security subscription | 623.1 |  |  | 536.9 |  |  |  |  |  |
| Technical support and other | 457.5 |  |  | 407.5 |  |  |  |  |  |
| Total service revenue | 1,080.6 |  |  | 944.4 |  |  |  |  |  |
| Total revenue | $ | 1,539.7 |  |  | $ | 1,353.3 |  |  |  |  |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- added (2025-08-08):
[0001262039-25-000028:note_history:26]
SUBSEQUENT EVENTS
One Big Beautiful Bill Act

- added (2025-08-08):
[0001262039-25-000028:note_history:27]
On July 4, 2025, H.R. 1, An Act to Provide for Reconciliation Pursuant to Title II of House Concurrent Resolution 14 (the “Act”), commonly referred to as the One Big Beautiful Bill Act, was enacted. The Act makes permanent certain elements of the Tax Cuts and Jobs Act, including immediate expensing of U.S. research and development expenditures, immediate expensing of certain eligible assets, and various modifications to the international tax framework. We are evaluating the impact of the Act on our consolidated financial statements, but our preliminary analysis indicates that our cash tax payments for 2025 could be reduced by approximately $100 million to $150 million and our GAAP effective tax rate for 2025 could increase by approximately 1 point as a result of the provisions of the Act.

- changed (2025-08-08):
[0001262039-25-000028:note_history:28]
Share Repurchase Program
  (was, 2025-05-08, similarity 0.7273):
[0001262039-25-000017:note_history:28]
SUBSEQUENT EVENTS
Share Repurchase Program

- changed (2025-08-08):
[0001262039-25-000028:note_history:29]
Subsequent to June 30, 2025 through the filing of this Quarterly Report on Form 10-Q, we repurchased 1.0 million shares of our common stock at an average price of $72.29 per share, for an aggregate purchase price of $71.2 million, under the Repurchase Program. As of the filing of this Quarterly Report on Form 10-Q, approximately $1.56 billion remained available for future share repurchases through February 28, 2026 under the Repurchase Program.
  (was, 2025-05-08, similarity 0.9894):
[0001262039-25-000017:note_history:29]
Subsequent to March 31, 2025 through the filing of this Quarterly Report on Form 10-Q, we repurchased 4.6 million shares of our common stock at an average price of $87.89 per share, for an aggregate purchase price of $401.1 million, under the Repurchase Program. As of the filing of this Quarterly Report on Form 10-Q, approximately $1.63 billion remained available for future share repurchases through February 28, 2026 under the Repurchase Program.

- removed (2025-08-08):
[0001262039-25-000017:note_history:30]
Real Property Purchases

- removed (2025-08-08):
[0001262039-25-000017:note_history:31]
In April 2025, we purchased real property in Burnaby, Canada, totaling approximately 245,000 square feet, to be used for office space, for $99.9 million in cash.
