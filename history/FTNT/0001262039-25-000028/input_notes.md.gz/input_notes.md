# FTNT notes — 0001262039-25-000028


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001262039-25-000028:notes:1]
SUMMARY OF SIGNIFICANT ACCOUNTING POLICIES
Basis of Presentation and Preparation—The unaudited condensed consolidated financial statements of Fortinet, Inc. and its subsidiaries (collectively, “we,” “us” or “our”) have been prepared in accordance with generally accepted accounting principles in the United States (“GAAP”) for interim financial information, as well as the instructions to Form 10-Q pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (the “SEC”). Accordingly, they do not include all of the information and footnotes required by GAAP for complete financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the year ended December 31, 2024, contained in our Annual Report on Form 10-K filed with the SEC on February 21, 2025. In the opinion of management, all adjustments, which include normal recurring adjustments, considered necessary for a fair presentation, have been included. The results of operations for the three and six months ended June 30, 2025 are not necessarily indicative of the results to be expected for the full year or for any future periods. The condensed consolidated balance sheet as of December 31, 2024 is derived from the audited consolidated financial statements for the year ended December 31, 2024.

[0001262039-25-000028:notes:2]
Amounts previously reported as gain on bargain purchase are included in other income (expense)—net in prior periods to conform with current period presentation in our condensed consolidated statements of income. Amounts previously reported as loss from equity method investments and gain on bargain purchase are included in other in prior periods to conform with current period presentation in section of net cash provided by operating activities in our condensed consolidated statements of cash flows.

[0001262039-25-000028:notes:3]
[same as prior period, unchanged from 0001262039-25-000017:notes:3]

[0001262039-25-000028:notes:4]
[same as prior period, unchanged from 0001262039-25-000017:notes:4]

[0001262039-25-000028:notes:5]
There have been no material changes to our significant accounting policies as of and for the six months ended June 30, 2025, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended December 31, 2024 filed with the SEC.

[0001262039-25-000028:notes:6]
[same as prior period, unchanged from 0001262039-25-000017:notes:6]

[0001262039-25-000028:notes:7]
[same as prior period, unchanged from 0001262039-25-000017:notes:7]

[0001262039-25-000028:notes:8]
In December 2023, the FASB issued ASU 2023-09, Income Taxes (Topic 740): Improvements to Income Tax Disclosures, which includes amendments that further enhance income tax disclosures, primarily through standardization and disaggregation of rate reconciliation categories and income taxes paid by jurisdiction. The amendments are effective for our annual period beginning fiscal year 2025, with early adoption permitted, and should be applied prospectively. We are currently evaluating the ASU to determine its impact on our disclosures.

[0001262039-25-000028:notes:9]
[same as prior period, unchanged from 0001262039-25-000017:notes:9]

[0001262039-25-000028:notes:10]
In November 2024, the FASB issued ASU 2024-03, Income Statement—Reporting Comprehensive Income—Expense Disaggregation Disclosures (Subtopic 220-40): Disaggregation of Income Statement Expenses (ASU 2024-03), and in January 2025, the FASB issued ASU No. 2025-01, Income Statement—Reporting Comprehensive Income—Expense Disaggregation Disclosures (Subtopic 220-40): Clarifying the Effective Date, which clarified the effective date of ASU 2024-03. ASU 2024-03 enhances the disclosures required for expense disaggregation in our annual and interim consolidated financial statements. The amendments are effective for our annual reporting period beginning fiscal year 2027, with early adoption permitted, and can be applied prospectively or retrospectively. We are currently evaluating the ASU to determine its impact on our disclosures.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001262039-25-000028:notes:11]
[same as prior period, unchanged from 0001262039-25-000017:notes:11]

[0001262039-25-000028:notes:12]
[same as prior period, unchanged from 0001262039-25-000017:notes:12]

[0001262039-25-000028:notes:13]
|  | Three Months Ended |  | Six Months Ended |
|  | June 30,2025 |  | June 30,2024 |  | June 30,2025 |  | June 30,2024 |
| Product | $ | 508.9 |  |  | $ | 451.9 |  |  | $ | 968.0 |  |  | $ | 860.8 |  |
| Service: |  |  |  |  |  |  |  |
| Security subscription | 644.4 |  |  | 558.7 |  |  | 1,267.5 |  |  | 1,095.6 |  |
| Technical support and other | 476.7 |  |  | 423.7 |  |  | 934.2 |  |  | 831.2 |  |
| Total service revenue | 1,121.1 |  |  | 982.4 |  |  | 2,201.7 |  |  | 1,926.8 |  |
| Total revenue | $ | 1,630.0 |  |  | $ | 1,434.3 |  |  | $ | 3,169.7 |  |  | $ | 2,787.6 |  |

[0001262039-25-000028:notes:14]
[same as prior period, unchanged from 0001262039-25-000017:notes:14]

[0001262039-25-000028:notes:15]
During the three and six months ended June 30, 2025, we recognized $876.8 million and $1.85 billion in revenue that was included in the deferred revenue balance as of December 31, 2024, respectively. During the three and six months ended June 30, 2024, we recognized $764.3 million and $1.62 billion in revenue that was included in the deferred revenue balance as of December 31, 2023, respectively.

[0001262039-25-000028:notes:16]
[same as prior period, unchanged from 0001262039-25-000017:notes:16]

[0001262039-25-000028:notes:17]
As of June 30, 2025, the aggregate amount of the transaction price allocated to remaining performance obligations was $6.64 billion, which was substantially comprised of deferred security subscription and technical support services revenue as well as unbilled contract revenue from non-cancellable contracts that will be recognized in future periods. We expect to recognize approximately $3.45 billion as revenue over the next 12 months, $2.61 billion in years two and three, and the remainder thereafter.

[0001262039-25-000028:notes:18]
[same as prior period, unchanged from 0001262039-25-000017:notes:18]

[0001262039-25-000028:notes:19]
Amortization of deferred contract costs during the three months ended June 30, 2025 and 2024 was $82.0 million and $72.7 million, respectively. Amortization of deferred contract costs during the six months ended June 30, 2025 and 2024 was $160.0 million and $144.7 million, respectively.


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0001262039-25-000028:notes:20]
[same as prior period, unchanged from 0001262039-25-000017:notes:20]

[0001262039-25-000028:notes:21]
[same as prior period, unchanged from 0001262039-25-000017:notes:21]

[0001262039-25-000028:notes:22]
|  | June 30, 2025 |
|  | AmortizedCost |  | UnrealizedGains |  | UnrealizedLosses |  | FairValue |
| U.S. government and agency securities | $ | 514.5 |  |  | $ | 0.1 |  |  | $ | (0.1) |  |  | $ | 514.5 |  |
| Commercial paper | 433.2 |  |  | — |  |  | (0.1) |  |  | 433.1 |  |
| Corporate debt securities | 177.6 |  |  | — |  |  | (0.1) |  |  | 177.5 |  |
| Certificates of deposit and term deposits | 97.3 |  |  | — |  |  | — |  |  | 97.3 |  |
| Total available-for-sale investments | 1,222.6 |  |  | 0.1 |  |  | (0.3) |  |  | 1,222.4 |  |
| Marketable equity securities |  |  |  |  |  |  | 84.0 |  |
| Total short-term and long-term investments | $ | 1,222.6 |  |  | $ | 0.1 |  |  | $ | (0.3) |  |  | $ | 1,306.4 |  |

[0001262039-25-000028:notes:23]
[same as prior period, unchanged from 0001262039-25-000017:notes:23]

[0001262039-25-000028:notes:24]
[same as prior period, unchanged from 0001262039-25-000017:notes:24]

[0001262039-25-000028:notes:25]
|  | June 30, 2025 |
|  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
|  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |
| U.S. government and agency securities | $ | 393.7 |  |  | $ | (0.1) |  |  | $ | — |  |  | $ | — |  |  | $ | 393.7 |  |  | $ | (0.1) |  |
| Commercial paper | 355.1 |  |  | (0.1) |  |  | — |  |  | — |  |  | 355.1 |  |  | (0.1) |  |
| Corporate debt securities | 119.1 |  |  | (0.1) |  |  | — |  |  | — |  |  | 119.1 |  |  | (0.1) |  |
| Certificates of deposit and term deposits | 19.3 |  |  | — |  |  | — |  |  | — |  |  | 19.3 |  |  | — |  |
| Total available-for-sale investments | $ | 887.2 |  |  | $ | (0.3) |  |  | $ | — |  |  | $ | — |  |  | $ | 887.2 |  |  | $ | (0.3) |  |

[0001262039-25-000028:notes:26]
[same as prior period, unchanged from 0001262039-25-000017:notes:26]

[0001262039-25-000028:notes:27]
[same as prior period, unchanged from 0001262039-25-000017:notes:27]

[0001262039-25-000028:notes:28]
|  | June 30,2025 |  | December 31,2024 |
| Due within one year | $ | 1,110.4 |  |  | $ | 1,126.4 |  |
| Due within one to three years | 112.0 |  |  | — |  |
| Total | $ | 1,222.4 |  |  | $ | 1,126.4 |  |

[0001262039-25-000028:notes:29]
[same as prior period, unchanged from 0001262039-25-000017:notes:29]

[0001262039-25-000028:notes:30]
[same as prior period, unchanged from 0001262039-25-000017:notes:30]

[0001262039-25-000028:notes:31]
The changes in fair value of our marketable equity securities are recorded in other income (expense)—net on the condensed consolidated statements of income. We recognized an $11.3 million gain and $3.4 million loss during the three and six months ended June 30, 2025, respectively. We recognized a $0.2 million loss and $0.1 million gain during the three and six months ended June 30, 2024, respectively.

[0001262039-25-000028:notes:32]
[same as prior period, unchanged from 0001262039-25-000017:notes:33]

[0001262039-25-000028:notes:33]
The following table presents the fair value of our financial assets measured at fair value on a recurring basis (in millions):

[0001262039-25-000028:notes:34]
|  | June 30, 2025 |  | December 31, 2024 |
|  | AggregateFairValue |  | QuotedPrices inActiveMarkets ForIdenticalAssets |  | SignificantOtherObservableRemainingInputs |  | SignificantOtherUnobservableRemainingInputs |  | AggregateFairValue |  | QuotedPrices inActiveMarkets ForIdenticalAssets |  | SignificantOtherObservableRemainingInputs |  | SignificantOtherUnobservableRemainingInputs |
|  |  |  | (Level 1) |  | (Level 2) |  | (Level 3) |  |  |  | (Level 1) |  | (Level 2) |  | (Level 3) |
| Cash equivalents: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | $ | 251.7 |  |  | $ | 251.7 |  |  | $ | — |  |  | $ | — |  |  | $ | 296.1 |  |  | $ | 296.1 |  |  | $ | — |  |  | $ | — |  |
| Commercial paper | 36.3 |  |  | — |  |  | 36.3 |  |  | — |  |  | 59.7 |  |  | — |  |  | 59.7 |  |  | — |  |
| Corporate debt securities | 2.0 |  |  | — |  |  | 2.0 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Total cash equivalents | 290.0 |  |  | 251.7 |  |  | 38.3 |  |  | — |  |  | 355.8 |  |  | 296.1 |  |  | 59.7 |  |  | — |  |
| Short-term investments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. government and agency securities | 454.0 |  |  | 450.5 |  |  | 3.5 |  |  | — |  |  | 469.5 |  |  | 464.5 |  |  | 5.0 |  |  | — |  |
| Commercial paper | 433.1 |  |  | — |  |  | 433.1 |  |  | — |  |  | 428.7 |  |  | — |  |  | 428.7 |  |  | — |  |
| Corporate debt securities | 126.0 |  |  | — |  |  | 126.0 |  |  | — |  |  | 166.4 |  |  | — |  |  | 166.4 |  |  | — |  |
| Certificates of deposit and term deposits | 97.3 |  |  | — |  |  | 97.3 |  |  | — |  |  | 61.8 |  |  | — |  |  | 61.8 |  |  | — |  |
| Marketable equity securities | 84.0 |  |  | 84.0 |  |  | — |  |  | — |  |  | 64.2 |  |  | 64.2 |  |  | — |  |  | — |  |
| Total short-term investments | 1,194.4 |  |  | 534.5 |  |  | 659.9 |  |  | — |  |  | 1,190.6 |  |  | 528.7 |  |  | 661.9 |  |  | — |  |
| Long-term investments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. government and agency securities | 60.5 |  |  | 55.2 |  |  | 5.3 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Corporate debt securities | 51.5 |  |  | — |  |  | 51.5 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Total long-term investments | 112.0 |  |  | 55.2 |  |  | 56.8 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Total | $ | 1,596.4 |  |  | $ | 841.4 |  |  | $ | 755.0 |  |  | $ | — |  |  | $ | 1,546.4 |  |  | $ | 824.8 |  |  | $ | 721.6 |  |  | $ | — |  |

[0001262039-25-000028:notes:35]
There were no transfers between Level 1 and Level 2 of the fair value hierarchy during the six months ended June 30, 2025 and year ended December 31, 2024.


## us-gaap:InventoryDisclosureTextBlock

[0001262039-25-000028:notes:36]
[same as prior period, unchanged from 0001262039-25-000017:notes:37]

[0001262039-25-000028:notes:37]
|  | June 30,2025 |  | December 31,2024 |
| Raw materials | $ | 72.0 |  |  | $ | 90.9 |  |
| Work in process | 4.8 |  |  | 4.1 |  |
| Finished goods | 328.4 |  |  | 220.5 |  |
| Inventory | $ | 405.2 |  |  | $ | 315.5 |  |

[0001262039-25-000028:notes:38]
The excess and obsolete inventory reserve was $146.4 million and $144.8 million as of June 30, 2025 and December 31, 2024, respectively. Inventory write-downs related to excess and obsolete inventory were immaterial during the three and six months ended June 30, 2025, respectively, and were $10.7 million and $28.8 million during the three and six

[0001262039-25-000028:notes:39]
months ended June 30, 2024, respectively. These were recorded in cost of product revenue on the condensed consolidated statements of income.


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001262039-25-000028:notes:40]
[same as prior period, unchanged from 0001262039-25-000017:notes:40]

[0001262039-25-000028:notes:41]
|  | June 30,2025 |  | December 31,2024 |
| Land | $ | 560.5 |  |  | $ | 500.6 |  |
| Buildings and improvements | 934.0 |  |  | 801.4 |  |
| Computer equipment and software | 307.5 |  |  | 279.1 |  |
| Leasehold improvements | 63.4 |  |  | 64.3 |  |
| Evaluation units | 34.8 |  |  | 31.8 |  |
| Furniture and fixtures | 37.2 |  |  | 36.4 |  |
| Construction-in-progress | 62.2 |  |  | 52.0 |  |
| Total property and equipment | 1,999.6 |  |  | 1,765.6 |  |
| Less: accumulated depreciation | (454.8) |  |  | (416.1) |  |
| Property and equipment—net | $ | 1,544.8 |  |  | $ | 1,349.5 |  |

[0001262039-25-000028:notes:42]
During the three months ended March 31, 2025, we purchased certain real estate property in Germany totaling $54.5 million, to be used predominantly for data center operations and as office space. The purchase was accounted for under the asset acquisition method, with $16.8 million allocated to land and $37.7 million allocated to buildings and improvements, based on their relative fair values.

[0001262039-25-000028:notes:43]
During the three months ended June 30, 2025, we purchased certain real estate properties in Canada, the United States and the Netherlands for an aggregate purchase price of $130.5 million, to be used predominantly for data center operations, office space and warehouse operations. The purchases were accounted for under the asset acquisition method, with $43.0 million allocated to land and $87.5 million allocated to buildings and improvements, based on their relative fair values.

[0001262039-25-000028:notes:44]
Depreciation expense was $25.1 million and $25.9 million during the three months ended June 30, 2025 and 2024, respectively. Depreciation expense was $49.1 million and $51.5 million during the six months ended June 30, 2025 and 2024, respectively.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001262039-25-000028:notes:45]
BUSINESS COMBINATIONS
2025 Acquisitions

[0001262039-25-000028:notes:46]
Linksys Holdings, Inc.

[0001262039-25-000028:notes:47]
[same as prior period, unchanged from 0001262039-25-000017:notes:44]

[0001262039-25-000028:notes:48]
This acquisition was accounted for as a business combination using the acquisition method of accounting. Of the aggregate purchase price, $17.5 million was allocated to identifiable intangible assets acquired, and $64.7 million was allocated to other net assets acquired which predominantly included deferred tax asset of $45.8 million, inventory of $21.4 million, and cash of $8.8 million, offset by $11.3 million of net other assets and liabilities assumed. The excess of the fair values of the net assets acquired over the net purchase consideration was recorded as a gain on bargain purchase of $39.9 million within other income (expense)—net on the condensed consolidated statements of income. The gain on bargain purchase occurred primarily due to the recognition of the deferred tax assets. The deferred tax assets were comprised primarily of pre-acquisition federal net

[0001262039-25-000028:notes:49]
operating loss carryforwards with an indefinite carryforward period. In addition, we had previously recorded a deferred tax asset of $30.6 million for an outside basis difference in our investment in Linksys when it was accounted for under the equity method. As a result of the acquisition of the remaining shares, we now account for our investment in Linksys under the consolidation method, and therefore we have derecognized this deferred tax asset. The charge is included in the provision for income taxes on the condensed consolidated statements of income. Acquisition-related costs related to this acquisition were not material and were recorded as general and administrative expense.

[0001262039-25-000028:notes:50]
Other acquisitions

[0001262039-25-000028:notes:51]
During the three months ended June 30, 2025, we completed other acquisitions for total purchase consideration of $38.3 million in cash. We have accounted for the transactions as business combinations and recorded goodwill of $21.9 million, among which $8.6 million of goodwill is expected to be deductible and $13.3 million of goodwill is not deductible for income tax purposes. Acquisition-related costs were not material and were recorded as general and administrative expense.

[0001262039-25-000028:notes:52]
2024 Acquisitions

[0001262039-25-000028:notes:53]
[same as prior period, unchanged from 0001262039-25-000017:notes:46]

[0001262039-25-000028:notes:54]
On December 5, 2024, we acquired certain assets and liabilities of Perception Point Ltd., a business specializing in advanced collaboration and email security paid in cash. This acquisition was accounted for as a business combination using the acquisition method of accounting. Of the $33.7 million purchase price, $24.5 million was allocated to goodwill, $9.5 million was allocated to developed technology intangible asset, $6.5 million was allocated to customer relationships intangible asset, and $6.8 million was allocated to other net liabilities assumed, which predominantly include deferred revenue. Goodwill recorded in connection with this acquisition is primarily attributable to the assembled workforce acquired and the anticipated operational synergies. All acquired goodwill is expected to be deductible for tax purposes. Acquisition-related costs were not material and were recorded as general and administrative expense.

[0001262039-25-000028:notes:55]
[same as prior period, unchanged from 0001262039-25-000017:notes:49]

[0001262039-25-000028:notes:56]
[same as prior period, unchanged from 0001262039-25-000017:notes:50]

[0001262039-25-000028:notes:57]
This acquisition was accounted for as a business combination using the acquisition method of accounting. The total preliminary purchase price was allocated to Next DLP’s identifiable tangible and intangible assets acquired and liabilities assumed based on their estimated fair values using management’s best estimates and assumptions to assign fair value as of the acquisition date. Of the total preliminary purchase price, $82.6 million was allocated to goodwill, $13.5 million was allocated to developed technology intangible asset, $10.5 million was allocated to customer relationships intangible asset, offset by $1.6 million of net liabilities assumed, which predominantly included deferred revenue and deferred tax liabilities. Goodwill recorded in connection with this acquisition represents the value we expect to be created through expansion into markets within our existing business, and the anticipated operational synergies, and goodwill is expected to be deductible for U.S. tax purposes. Acquisition-related costs related to this acquisition were not material and were recorded as general and administrative expense.

[0001262039-25-000028:notes:58]
[same as prior period, unchanged from 0001262039-25-000017:notes:52]

[0001262039-25-000028:notes:59]
[same as prior period, unchanged from 0001262039-25-000017:notes:53]

[0001262039-25-000028:notes:60]
[same as prior period, unchanged from 0001262039-25-000017:notes:54]

[0001262039-25-000028:notes:61]
This acquisition was accounted for as a business combination using the acquisition method of accounting. The total preliminary purchase price was allocated to Lacework’s identifiable tangible and intangible assets acquired and liabilities

[0001262039-25-000028:notes:62]
assumed based on their estimated fair values using management’s best estimates and assumptions to assign fair value as of the acquisition date. Of the total preliminary purchase price, $244.4 million was allocated to deferred tax assets, $61.3 million allocation to identifiable intangible assets, and $6.2 million cash, offset by net other assets and liabilities assumed of $53.3 million, which predominantly included deferred revenue and other current liabilities. The excess of the fair values of the net assets acquired over the net purchase consideration was recorded as a gain on bargain purchase of $106.3 million within other income (expense)—net on the condensed consolidated statements of income. The gain on bargain purchase occurred primarily due to the recognition of the deferred tax assets. The deferred tax assets were comprised primarily of pre-acquisition federal net operating loss carryforwards with an indefinite carryforward period. Acquisition-related costs related to this acquisition were not material and were recorded as general and administrative expense.

[0001262039-25-000028:notes:63]
[same as prior period, unchanged from 0001262039-25-000017:notes:56]

[0001262039-25-000028:notes:64]
[same as prior period, unchanged from 0001262039-25-000017:notes:57]

[0001262039-25-000028:notes:65]
[same as prior period, unchanged from 0001262039-25-000017:notes:58]

[0001262039-25-000028:notes:66]
[same as prior period, unchanged from 0001262039-25-000017:notes:59]


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001262039-25-000028:notes:67]
[same as prior period, unchanged from 0001262039-25-000017:notes:60]

[0001262039-25-000028:notes:68]
[same as prior period, unchanged from 0001262039-25-000017:notes:61]

[0001262039-25-000028:notes:69]
|  | Amount |
| Balance—December 31, 2024 | $ | 235.4 |  |
| Additions due to business combinations | 21.9 |  |
| Foreign currency translation adjustments | 1.6 |  |
| Balance—June 30, 2025 | $ | 258.9 |  |

[0001262039-25-000028:notes:70]
There were no impairments to goodwill during the six months ended June 30, 2025 or during prior periods.

[0001262039-25-000028:notes:71]
[same as prior period, unchanged from 0001262039-25-000017:notes:64]

[0001262039-25-000028:notes:72]
[same as prior period, unchanged from 0001262039-25-000017:notes:65]

[0001262039-25-000028:notes:73]
|  | June 30, 2025 |
|  | Weighted-Average Useful Life (in Years) |  | Gross |  | Accumulated Amortization |  | Net |
| Other intangible assets—net: |  |  |  |  |  |  |  |
| Finite-lived intangible assets: |  |  |  |  |  |  |  |
| Developed technologies | 4.3 |  | $ | 160.6 |  |  | $ | 86.6 |  |  | $ | 74.0 |  |
| Customer relationships | 5.3 |  | 67.5 |  |  | 33.4 |  |  | 34.1 |  |
| Trade name | 7.1 |  | 11.6 |  |  | 2.7 |  |  | 8.9 |  |
| Backlog | 2.4 |  | 13.8 |  |  | 7.5 |  |  | 6.3 |  |
| Total other intangible assets—net |  |  | $ | 253.5 |  |  | $ | 130.2 |  |  | $ | 123.3 |  |

[0001262039-25-000028:notes:74]
[same as prior period, unchanged from 0001262039-25-000017:notes:67]

[0001262039-25-000028:notes:75]
Amortization expense was $13.2 million and $3.3 million during the three months ended June 30, 2025 and 2024, respectively. Amortization expense was $25.0 million and $6.3 million during the six months ended June 30, 2025 and 2024, respectively.

[0001262039-25-000028:notes:76]
[same as prior period, unchanged from 0001262039-25-000017:notes:69]

[0001262039-25-000028:notes:77]
|  | Amount |
| Years: |  |
| 2025 (the remainder of 2025) | $ | 23.7 |  |
| 2026 | 35.4 |  |
| 2027 | 28.2 |  |
| 2028 | 21.4 |  |
| 2029 | 10.4 |  |
| Thereafter | 4.2 |  |
| Total | $ | 123.3 |  |


## us-gaap:EarningsPerShareTextBlock

[0001262039-25-000028:notes:78]
[same as prior period, unchanged from 0001262039-25-000017:notes:71]

[0001262039-25-000028:notes:79]
[same as prior period, unchanged from 0001262039-25-000017:notes:72]

[0001262039-25-000028:notes:80]
|  | Three Months Ended |  | Six Months Ended |
|  | June 30,2025 |  | June 30,2024 |  | June 30,2025 |  | June 30,2024 |
| Numerator: |  |  |  |  |  |  |  |
| Net income | $ | 440.1 |  |  | $ | 379.8 |  |  | $ | 873.5 |  |  | $ | 679.1 |  |
| Denominator: |  |  |  |  |  |  |  |
| Basic shares: |  |  |  |  |  |  |  |
| Weighted-average common stock outstanding-basic | 765.5 |  |  | 763.8 |  |  | 766.9 |  |  | 763.1 |  |
| Diluted shares: |  |  |  |  |  |  |  |
| Weighted-average common stock outstanding-basic | 765.5 |  |  | 763.8 |  |  | 766.9 |  |  | 763.1 |  |
| Effect of potentially dilutive securities: |  |  |  |  |  |  |  |
| RSUs | 2.6 |  |  | 1.5 |  |  | 3.0 |  |  | 2.1 |  |
| Stock options | 4.0 |  |  | 4.5 |  |  | 4.3 |  |  | 4.8 |  |
| PSUs | 0.6 |  |  | 0.1 |  |  | 0.6 |  |  | 0.2 |  |
| Weighted-average shares used to compute diluted net income per share | 772.7 |  |  | 769.9 |  |  | 774.8 |  |  | 770.2 |  |
| Net income per share |  |  |  |  |  |  |  |
| Basic | $ | 0.57 |  |  | $ | 0.50 |  |  | $ | 1.14 |  |  | $ | 0.89 |  |
| Diluted | $ | 0.57 |  |  | $ | 0.49 |  |  | $ | 1.13 |  |  | $ | 0.88 |  |

[0001262039-25-000028:notes:81]
[same as prior period, unchanged from 0001262039-25-000017:notes:74]

[0001262039-25-000028:notes:82]
|  | Three Months Ended |  | Six Months Ended |
|  | June 30,2025 |  | June 30,2024 |  | June 30,2025 |  | June 30,2024 |
| RSUs | 2.1 |  |  | — |  |  | 1.5 |  |  | — |  |
| Stock options | 0.6 |  |  | 3.6 |  |  | 0.5 |  |  | 3.4 |  |
| PSUs | — |  |  | 0.2 |  |  | — |  |  | 0.1 |  |
| Total | 2.7 |  |  | 3.8 |  |  | 2.0 |  |  | 3.5 |  |


## us-gaap:DebtDisclosureTextBlock

[0001262039-25-000028:notes:83]
DEBT
2026 and 2031 Senior Notes

[0001262039-25-000028:notes:84]
On March 5, 2021, we issued $1.0 billion aggregate principal amount of senior notes (collectively, the “Senior Notes”), consisting of $500.0 million aggregate principal amount of 1.0% notes due March 15, 2026 (the “2026 Senior Notes”) and $500.0 million aggregate principal amount of 2.2% notes due March 15, 2031 (the “2031 Senior Notes”), in an underwritten registered public offering. The Senior Notes are senior unsecured obligations and rank equally with each other in right of payment and with our other outstanding obligations. We may redeem the Senior Notes at any time in whole or in part for cash, at specified redemption prices that include accrued and unpaid interest, if any, and a make-whole premium. However, no make-whole premium will be paid for redemptions of the 2026 Senior Notes on or after February 15, 2026, or the 2031 Senior Notes on or after December 15, 2030. Interest on the Senior Notes is payable on March 15 and September 15 of each year, beginning on September 15, 2021. The 2026 Senior Notes were recorded as current portion of long-term debt and the 2031 Senior Notes were recorded as long-term debt as of June 30, 2025 and both of the Senior Notes were recorded as long-term debt as of December 31, 2024, net of discount and issuance costs, which are amortized to interest expense over the respective contractual terms of these notes using the effective interest method.

[0001262039-25-000028:notes:85]
The total outstanding debt is summarized below (in millions, except percentages):

[0001262039-25-000028:notes:86]
|  | Maturity |  | Coupon Rate |  | Effective Interest Rate |  | June 30,2025 |  | December 31,2024 |
| Debt |  |  |  |  |  |  |  |  |  |
| 2026 Senior Notes | March 2026 |  | 1.0% |  | 1.3% |  | $ | 500.0 |  |  | $ | 500.0 |  |
| 2031 Senior Notes | March 2031 |  | 2.2% |  | 2.3% |  | 500.0 |  |  | 500.0 |  |
| Total debt |  |  |  |  |  |  | 1,000.0 |  |  | 1,000.0 |  |
| Less: Unamortized discount and debt issuance costs |  |  |  |  |  |  | 4.7 |  |  | 5.7 |  |
| Less: Current portion of long-term debt |  |  |  |  |  |  | $ | 499.0 |  |  | $ | — |  |
| Total long-term debt |  |  |  |  |  |  | $ | 496.3 |  |  | $ | 994.3 |  |

[0001262039-25-000028:notes:87]
As of June 30, 2025 and December 31, 2024, we accrued interest payable of $4.7 million, and there are no financial covenants with which we must comply. During the three months ended June 30, 2025 and 2024, we recorded $4.5 million of total interest expense in relation to these Senior Notes in each period. During the six months ended June 30, 2025 and 2024, we recorded $9.0 million of total interest expense in relation to these Senior Notes in each period. No interest costs were capitalized for the six months ended June 30, 2025 and 2024, as the costs that qualified for capitalization were not material.

[0001262039-25-000028:notes:88]
The total estimated fair value of the outstanding Senior Notes was approximately $933.1 million, including accrued and unpaid interest, as of June 30, 2025. The fair value was determined based on observable market prices of identical instruments in less active markets. The estimated fair values are based on Level 2 inputs.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001262039-25-000028:notes:89]
COMMITMENTS AND CONTINGENCIES
The following table summarizes our inventory purchase commitments as of June 30, 2025 (in millions):

[0001262039-25-000028:notes:90]
|  | Total |  | 2025 |  | Thereafter |
| Inventory purchase commitments | $ | 714.4 |  |  | $ | 537.2 |  |  | $ | 177.2 |  |

[0001262039-25-000028:notes:91]
Inventory Purchase Commitments—We purchase components of our inventory from certain suppliers and use several independent contract manufacturers to provide manufacturing services for our products. During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, we enter into agreements with contract manufacturers and suppliers that allow them to procure inventory based upon criteria as defined by us or establish the parameters defining our requirements. A significant portion of our reported purchase commitments arising from these agreements consists of firm, non-cancelable and unconditional commitments. Certain of these inventory purchase commitments with contract manufacturers and suppliers relate to arrangements to secure supply and pricing for certain product components for multi-year periods. In certain instances, these agreements allow us the option to reschedule and adjust our requirements based on our business needs prior to firm orders being placed.

[0001262039-25-000028:notes:92]
As of June 30, 2025, we had $714.4 million of non-cancelable inventory purchase commitments with our independent contract manufacturers. We recorded a liability for these purchase commitments for quantities in excess of our future estimated demand forecasts, consistent with the valuation of our excess and obsolete inventory. As of June 30, 2025 and December 31, 2024, the liability for these inventory purchase commitments was $41.9 million and $54.0 million, respectively, and was recorded in accrued liabilities on our condensed consolidated balance sheets. The expense related to such accrued liability for inventory purchase commitments is recorded in cost of product revenue on the condensed consolidated statements of income. It was immaterial during the three and six months ended June 30, 2025, and was $7.0 million and $38.6 million during the three and six months ended June 30, 2024, respectively.

[0001262039-25-000028:notes:93]
Other Contractual Commitments and Open Purchase Orders—In addition to commitments with contract manufacturers, we have open purchase orders and contractual obligations in the ordinary course of business for which we have not received goods or services. A significant portion of our reported purchase commitments consist of non-cancelable commitments. In certain instances, contractual commitments allow us the option to cancel, reschedule and adjust our requirements based on our business needs prior to firm orders being placed. As of June 30, 2025, we had $102.7 million in other contractual commitments having a remaining term in excess of one year that are non-cancelable.

[0001262039-25-000028:notes:94]
As of June 30, 2025, we had $93.4 million in contractual commitments related to payments for operating leases.

[0001262039-25-000028:notes:95]
Litigation—We are involved in disputes, litigation, and other legal actions. For lawsuits where we are the defendant, we are in the process of defending these litigation matters, and while there can be no assurances and the outcome of certain of these matters is currently not determinable and not predictable, we currently are unaware of any existing claims or proceedings that we believe are likely to have a material adverse effect on our financial position. There are many uncertainties associated with any litigation and these actions or other third-party claims against us may cause us to incur costly litigation fees, costs and substantial settlement charges, and possibly subject us to damages and other penalties. In addition, the resolution of any intellectual property (“IP”) litigation may require us to make royalty payments, which could adversely affect our gross margins in future periods. If any of those events were to occur, our business, financial condition, results of operations, and cash flows could be adversely affected. Litigation is unpredictable and the actual liability in any such matters may be materially different from our current estimates, which could result in the need to adjust any accrued liability and record additional expenses. We accrue for contingencies when we believe that a loss is probable and that we can reasonably estimate the amount of any such loss. These accruals are generally based on a range of possible outcomes that require significant management judgement. If no amount within a range is a better estimate than any other, we accrue the minimum amount. Litigation loss contingency accruals associated with outstanding cases were not material as of June 30, 2025 and December 31, 2024.

[0001262039-25-000028:notes:96]
On March 21, 2019, we were sued by Alorica Inc. (“Alorica”) in Santa Clara County Superior Court in California. Alorica alleged breach of warranty and misrepresentation claims, which we denied. After trial, a jury returned a verdict fully in favor of us and against Alorica on October 4, 2024. Alorica has filed a notice of appeal. We believe that the ultimate outcome of this matter will not materially impact our financial position, results of operations or cash flows. However, any further legal proceedings, including Alorica’s appeal, would be subject to inherent uncertainties, and a future unfavorable ruling could occur. No loss accrual had been recorded as of June 30, 2025 or December 31, 2024 related to this litigation.

[0001262039-25-000028:notes:97]
Indemnification and Other Matters—We enter into indemnification provisions in the ordinary course of business with other companies such as partners, customers, and vendors, where we agree to indemnify, hold harmless, and reimburse the indemnified party for certain losses suffered or incurred by the indemnified party as a result of our activities, including defending against third-party claims asserting various allegations such as product defects, breach of representations or covenants, and infringement of certain IP rights, which may include patents, copyrights, trademarks or trade secrets, and to pay judgments entered on such claims. In some contracts, our exposure under these indemnification provisions is limited by the terms of the contracts to certain defined limits, such as the total amount paid by our customer under the agreement. However, certain agreements include covenants, penalties and indemnification provisions including and beyond indemnification for third-party claims of IP infringement that could potentially expose us to losses in excess of the amount received under the agreement, and in some instances to potential liability that is not contractually limited. Although from time to time there are indemnification claims asserted against us and currently there are pending indemnification claims, to date there have been no material awards under such indemnification provisions.

[0001262039-25-000028:notes:98]
Similar to other security companies and companies in other industries, we have experienced and may experience in the future, cybersecurity threats, malicious activity directed against our information technology infrastructure or unauthorized attempts to gain access to our and our customers’ sensitive information and systems. We currently are unaware of any claims or proceedings related to these types of matters that we believe are likely to have a material adverse effect on our financial position.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001262039-25-000028:notes:99]
[same as prior period, unchanged from 0001262039-25-000017:notes:93]

[0001262039-25-000028:notes:100]
We maintain the Amended and Restated Fortinet, Inc. 2009 Equity Incentive Plan (the “Amended Plan”) pursuant to which we have granted RSUs, stock options and PSUs. As of June 30, 2025, there were a total of 48.9 million shares of common stock available for grant under the Amended Plan.

[0001262039-25-000028:notes:101]
[same as prior period, unchanged from 0001262039-25-000017:notes:95]

[0001262039-25-000028:notes:102]
[same as prior period, unchanged from 0001262039-25-000017:notes:96]

[0001262039-25-000028:notes:103]
|  | Restricted Stock Units Outstanding |
|  | Number of Shares |  | Weighted-Average Grant Date Fair Value per Share |
| Balance—December 31, 2024 | 8.4 |  |  | $ | 64.70 |  |
| Granted | 2.3 |  |  | 108.63 |  |
| Forfeited | (0.5) |  |  | 73.71 |  |
| Vested | (2.1) |  |  | 59.07 |  |
| Balance—June 30, 2025 | 8.1 |  |  | $ | 78.72 |  |

[0001262039-25-000028:notes:104]
Stock compensation expense is recognized on a straight-line basis over the vesting period of each RSU. As of June 30, 2025, total compensation expense related to unvested RSUs granted to employees and non-employees under the Amended Plan, but not yet recognized, was $574.6 million, with a weighted-average remaining vesting period of 2.9 years.

[0001262039-25-000028:notes:105]
[same as prior period, unchanged from 0001262039-25-000017:notes:99]

[0001262039-25-000028:notes:106]
We grant market/performance-based PSUs under the Amended Plan to certain of our executives. Based on the achievement of the market/performance-based vesting conditions during the performance period, the final settlement of the PSUs will range between 0% and 200% of the target shares underlying the PSUs based on the percentile ranking of our total stockholder return over one-, two-, three- and four-year periods among companies included in the S&P 500 Index. 20%, 20%, 20% and 40% of the PSUs vest over one-, two-, three- and four-year service periods, respectively.

[0001262039-25-000028:notes:107]
The following table summarizes the activity and related information for PSUs for the periods presented below (in millions, except per share amounts):

[0001262039-25-000028:notes:108]
|  | Performance Stock Units Outstanding |
|  | Number of Shares |  | Weighted-Average Grant Date Fair Value per Share |
| Balance—December 31, 2024 | 0.4 |  |  | $ | 94.93 |  |
| Granted | 0.1 |  |  | 168.93 |  |
| Forfeited | (0.1) |  |  | 113.36 |  |
| Vested | (0.2) |  |  | 91.19 |  |
| Balance—June 30, 2025 | 0.2 |  |  | $ | 118.43 |  |

[0001262039-25-000028:notes:109]
As of June 30, 2025, total compensation expense related to unvested PSUs that were granted to certain of our executives, but not yet recognized, was $30.0 million. This expense is expected to be amortized on a graded vesting method over a weighted-average vesting period of 2.3 years.

[0001262039-25-000028:notes:110]
[same as prior period, unchanged from 0001262039-25-000017:notes:106]

[0001262039-25-000028:notes:111]
[same as prior period, unchanged from 0001262039-25-000017:notes:107]

[0001262039-25-000028:notes:112]
|  | Three Months Ended |  | Six Months Ended |
|  | June 30,2025 |  | June 30,2024 |  | June 30,2025 |  | June 30,2024 |
| Shares withheld for taxes | 0.2 |  |  | 0.3 |  |  | 0.7 |  |  | 0.9 |  |
| Amount withheld for taxes | $ | 23.4 |  |  | $ | 20.2 |  |  | $ | 77.2 |  |  | $ | 63.1 |  |

[0001262039-25-000028:notes:113]
[same as prior period, unchanged from 0001262039-25-000017:notes:109]

[0001262039-25-000028:notes:114]
[same as prior period, unchanged from 0001262039-25-000017:notes:110]

[0001262039-25-000028:notes:115]
|  | Three Months Ended |  | Six Months Ended |
|  | June 30,2025 |  | June 30,2024 |  | June 30,2025 |  | June 30,2024 |
| Expected term in years | 4.5 |  | 4.5 |  | 4.5 |  | 4.5 |
| Volatility | 41.4 | % |  | 41.9 | % |  | 41.6 | % |  | 42.8 | % |
| Risk-free interest rate | 4.1 | % |  | 4.4 | % |  | 4.2 | % |  | 4.3 | % |
| Dividend rate | — | % |  | — | % |  | — | % |  | — | % |

[0001262039-25-000028:notes:116]
[same as prior period, unchanged from 0001262039-25-000017:notes:112]

[0001262039-25-000028:notes:117]
|  | Options Outstanding |
|  | Numberof Shares |  | Weighted-AverageExercisePrice |  | Weighted-AverageRemainingContractualLife (Years) |  | AggregateIntrinsicValue |
| Balance—December 31, 2024 | 8.7 |  |  | $ | 37.81 |  |  | 3.1 |  | $ | 493.8 |  |
| Granted | 0.6 |  |  | 108.90 |  |  |  |  |  |
| Forfeited | (0.1) |  |  | 71.07 |  |  |  |  |  |
| Exercised | (1.5) |  |  | 20.63 |  |  |  |  |  |
| Balance—June 30, 2025 | 7.7 |  |  | $ | 46.82 |  |  |  |  |  |
| Options vested and expected to vest—June 30, 2025 | 7.7 |  |  | $ | 46.82 |  |  | 3.3 |  | $ | 458.5 |  |
| Options exercisable—June 30, 2025 | 5.8 |  |  | $ | 36.34 |  |  | 2.5 |  | $ | 404.9 |  |

[0001262039-25-000028:notes:118]
The aggregate intrinsic value represents the difference between the exercise price of stock options and the quoted market price of our common stock at the date of the balance sheet for all in-the-money stock options. Stock compensation expense is recognized on a straight-line basis over the vesting period of each stock option. As of June 30, 2025, total compensation expense related to unvested stock options granted to employees but not yet recognized was $57.3 million, with a weighted-average remaining vesting period of 2.8 years.

[0001262039-25-000028:notes:119]
[same as prior period, unchanged from 0001262039-25-000017:notes:115]

[0001262039-25-000028:notes:120]
|  | Three Months Ended |  | Six Months Ended |
|  | June 30,2025 |  | June 30,2024 |  | June 30,2025 |  | June 30,2024 |
| Weighted-average fair value per share granted | $ | 41.05 |  |  | $ | 24.93 |  |  | $ | 43.83 |  |  | $ | 26.79 |  |
| Intrinsic value of options exercised | $ | 28.9 |  |  | $ | 18.1 |  |  | $ | 131.2 |  |  | $ | 69.9 |  |
| Fair value of options vested | $ | 5.5 |  |  | $ | 6.5 |  |  | $ | 15.0 |  |  | $ | 18.6 |  |

[0001262039-25-000028:notes:121]
[same as prior period, unchanged from 0001262039-25-000017:notes:117]

[0001262039-25-000028:notes:122]
[same as prior period, unchanged from 0001262039-25-000017:notes:118]

[0001262039-25-000028:notes:123]
|  | Three Months Ended |  | Six Months Ended |
|  | June 30,2025 |  | June 30,2024 |  | June 30,2025 |  | June 30,2024 |
| Cost of product revenue | $ | 0.5 |  |  | $ | 0.4 |  |  | $ | 1.0 |  |  | $ | 0.9 |  |
| Cost of service revenue | 7.0 |  |  | 6.5 |  |  | 13.5 |  |  | 12.7 |  |
| Research and development | 25.1 |  |  | 21.3 |  |  | 48.1 |  |  | 41.1 |  |
| Sales and marketing | 29.7 |  |  | 25.9 |  |  | 56.2 |  |  | 52.6 |  |
| General and administrative | 7.6 |  |  | 10.2 |  |  | 18.0 |  |  | 20.0 |  |
| Total stock-based compensation expense | $ | 69.9 |  |  | $ | 64.3 |  |  | $ | 136.8 |  |  | $ | 127.3 |  |

[0001262039-25-000028:notes:124]
[same as prior period, unchanged from 0001262039-25-000017:notes:120]

[0001262039-25-000028:notes:125]
|  | Three Months Ended |  | Six Months Ended |
|  | June 30,2025 |  | June 30,2024 |  | June 30,2025 |  | June 30,2024 |
| RSUs | $ | 60.8 |  |  | $ | 54.0 |  |  | $ | 117.1 |  |  | $ | 106.0 |  |
| Stock options | 6.8 |  |  | 7.1 |  |  | 13.4 |  |  | 14.4 |  |
| PSUs | 2.3 |  |  | 3.2 |  |  | 6.3 |  |  | 6.9 |  |
| Total stock-based compensation expense | $ | 69.9 |  |  | $ | 64.3 |  |  | $ | 136.8 |  |  | $ | 127.3 |  |

[0001262039-25-000028:notes:126]
[same as prior period, unchanged from 0001262039-25-000017:notes:122]

[0001262039-25-000028:notes:127]
|  | Three Months Ended |  | Six Months Ended |
|  | June 30,2025 |  | June 30,2024 |  | June 30,2025 |  | June 30,2024 |
| Income tax benefit associated with stock-based compensation | $ | 15.3 |  |  | $ | 14.3 |  |  | $ | 30.0 |  |  | $ | 28.2 |  |

[0001262039-25-000028:notes:128]
[same as prior period, unchanged from 0001262039-25-000017:notes:124]

[0001262039-25-000028:notes:129]
In October 2024, our board of directors approved a $1.0 billion increase in the authorized stock repurchase amount under the Repurchase Program and extended the term of the Repurchase Program to February 28, 2026, bringing the aggregate amount authorized to be repurchased to $8.25 billion of our outstanding common stock through February 28, 2026. Share repurchases may be made by us from time to time in privately negotiated transactions or in open-market transactions. The Repurchase Program does not require us to purchase a minimum number of shares, and may be suspended, modified or discontinued at any time without prior notice.
During the three and six months ended June 30, 2025, we repurchased 4.6 million shares of our common stock under the Repurchase Program in open-market transactions, at a weighted-average price of $87.89 per share, for an aggregate purchase price of $401.1 million, which excludes a $0.8 million accrual related to the 1% excise tax imposed by the Inflation Reduction Act of 2022. As of June 30, 2025, approximately $1.63 billion remained available for future share repurchases under the Repurchase Program.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001262039-25-000028:notes:130]
INCOME TAXES
Our effective tax rate was 15% for the three months ended June 30, 2025, compared to an effective tax rate of 16% for the same period last year. Our effective tax rate was 17% for the six months ended June 30, 2025, compared to an effective tax rate of 14% for the same period last year. The tax rates for the three months ended June 30, 2025 and 2024 were comprised of U.S. federal and state taxes, withholding taxes and foreign taxes that amounted to $114.6 million and $109.9 million,

[0001262039-25-000028:notes:131]
respectively. The tax rate for the three months ended June 30, 2025 included a tax benefit of $25.1 million from the foreign-derived intangible income (“FDII”) deduction, and excess tax benefits from stock-based compensation expense of $12.4 million. The tax rate for the three months ended June 30, 2024 was impacted by a tax benefit of $27.2 million from the FDII deduction, and excess tax benefits from stock-based compensation expense of $6.2 million.

[0001262039-25-000028:notes:132]
The tax rates for the six months ended June 30, 2025 and 2024 were composed of U.S. federal and state taxes, withholding taxes and foreign taxes that amounted to $243.2 million and $191.3 million, respectively. The tax rate for the six months ended June 30, 2025 included a tax provision of $30.6 million related to the derecognition of deferred tax assets from the business combination with Linksys, a tax benefit of $50.9 million from the FDII deduction, and excess tax benefits from stock-based compensation expense of $49.3 million. The tax rate for the six months ended June 30, 2024 was impacted by a tax benefit of $50.8 million from the FDII deduction, and excess tax benefits from stock-based compensation expense of $24.5 million.

[0001262039-25-000028:notes:133]
As of June 30, 2025 and December 31, 2024, unrecognized tax benefits were $83.0 million and $75.9 million, respectively. If recognized, $67.6 million of the unrecognized tax benefits as of June 30, 2025 would favorably affect our effective tax rate. It is our policy to include accrued interest and penalties related to unrecognized tax benefits in income tax expense. As of June 30, 2025 and December 31, 2024, accrued interest and penalties were $10.8 million and $8.8 million, respectively.

[0001262039-25-000028:notes:134]
[same as prior period, unchanged from 0001262039-25-000017:notes:128]

[0001262039-25-000028:notes:135]
On January 4, 2022, the U.S. Treasury published another tranche of final regulations regarding the foreign tax credit. These final regulations impose new requirements that a foreign tax must meet in order to be creditable against U.S. income taxes, and generally apply to tax years beginning on or after December 28, 2021. On July 26, 2022, the U.S. Treasury released corrections to the final regulations. On July 21, 2023, the Internal Revenue Service (“IRS”) released a notice that suspended the application of significant portions of the final regulations regarding the foreign tax credit for tax years 2022 and 2023. The notice released in July 2023 favorably impacted our ability to claim foreign tax credits in the United States for certain taxes imposed by certain foreign jurisdictions. On December 11, 2023, the IRS released a notice that extended the suspension of significant portions of the final regulations beyond December 31, 2023, until further guidance is issued. 
In December 2021, the Organisation for Economic Co-operation and Development (the “OECD”) enacted model rules for a new global minimum tax framework (“BEPS Pillar Two”), and various governments around the world have enacted, or are in the process of enacting, legislation on this. The OECD continues to release additional guidance on these rules. Based on the enacted laws, BEPS Pillar Two has no impact to our effective tax rate or cash flows for the six months ended June 30, 2025. We will continue to evaluate the impact of these tax law changes on future reporting periods.


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0001262039-25-000028:notes:136]
DEFINED CONTRIBUTION PLANS
Our tax-deferred savings plan under our 401(k) Plan permits participating U.S. employees to contribute a portion of their pre-tax or after-tax earnings. In Canada, we have a Group Registered Retirement Savings Plan Program (the “RRSP”), which permits participants to make pre-tax contributions. Our board of directors approved 50% matching contributions on employee contributions up to 4% of each employee’s eligible earnings. Our matching contributions to our 401(k) Plan and the RRSP for the three months ended June 30, 2025 and 2024 were $5.1 million and $4.3 million, respectively. Our matching contributions to our 401(k) Plan and the RRSP for the six months ended June 30, 2025 and 2024 were $10.7 million and $10.6 million, respectively.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001262039-25-000028:notes:137]
SEGMENT INFORMATION
Operating segments are defined as components of an enterprise about which separate financial information is available that is evaluated regularly by the chief operating decision maker in deciding how to allocate resources and in assessing performance. Our chief operating decision maker is our chief executive officer. Our chief executive officer reviews financial information presented on a consolidated basis, accompanied by information about revenue by geographic region for purposes of allocating resources and evaluating financial performance. We have one business activity, and there are no segment managers

[0001262039-25-000028:notes:138]
who are held accountable for operations, operating results and plans for levels or components below the consolidated unit level. Accordingly, we have determined that we have one operating segment, and therefore, one reportable segment.

[0001262039-25-000028:notes:139]
[same as prior period, unchanged from 0001262039-25-000017:notes:132]

[0001262039-25-000028:notes:140]
|  | Three Months Ended |  | Six Months Ended |
| June 30, 2025 |  | June 30, 2024 |  | June 30, 2025 |  | June 30, 2024 |
| Total revenue | $ | 1,630.0 |  |  | $ | 1,434.3 |  |  | $ | 3,169.7 |  |  | $ | 2,787.6 |  |
| Less: |  |  |  |  |  |  |  |
| Cost of product revenue | 165.9 |  |  | 155.1 |  |  | 315.8 |  |  | 337.9 |  |
| Cost of service revenue | 149.0 |  |  | 119.9 |  |  | 292.2 |  |  | 241.8 |  |
| Research and development expense | 209.5 |  |  | 165.4 |  |  | 408.1 |  |  | 338.4 |  |
| Other sales and marketing expense (1) | 483.7 |  |  | 403.2 |  |  | 923.4 |  |  | 815.8 |  |
| Commission expense | 108.3 |  |  | 98.1 |  |  | 211.3 |  |  | 186.6 |  |
| General and administrative expense | 56.9 |  |  | 56.6 |  |  | 114.7 |  |  | 111.0 |  |
| Other segment items (2) | 60.5 |  |  | 20.3 |  |  | 142.9 |  |  | 39.0 |  |
| Provision for income taxes | 77.1 |  |  | 76.5 |  |  | 173.6 |  |  | 116.0 |  |
| Net income | $ | 440.1 |  |  | $ | 379.8 |  |  | $ | 873.5 |  |  | $ | 679.1 |  |

[0001262039-25-000028:notes:141]
[same as prior period, unchanged from 0001262039-25-000017:notes:134]

[0001262039-25-000028:notes:142]
[same as prior period, unchanged from 0001262039-25-000017:notes:135]

[0001262039-25-000028:notes:143]
|  | Three Months Ended |  | Six Months Ended |
| June 30, 2025 |  | June 30, 2024 |  | June 30, 2025 |  | June 30, 2024 |
| Gain on intellectual property matters | $ | 1.3 |  |  | $ | 1.2 |  |  | $ | 7.6 |  |  | $ | 2.3 |  |
| Interest income | 45.0 |  |  | 38.3 |  |  | 89.3 |  |  | 70.5 |  |
| Interest expense | (4.6) |  |  | (5.0) |  |  | (9.5) |  |  | (10.1) |  |
| Other income (expense)—net | 18.9 |  |  | (2.2) |  |  | 45.0 |  |  | (5.1) |  |
| Gain (loss) from equity method investments | (0.1) |  |  | (12.0) |  |  | 10.5 |  |  | (18.6) |  |
| Total other segment items | $ | 60.5 |  |  | $ | 20.3 |  |  | $ | 142.9 |  |  | $ | 39.0 |  |

[0001262039-25-000028:notes:144]
[same as prior period, unchanged from 0001262039-25-000017:notes:137]

[0001262039-25-000028:notes:145]
|  | Three Months Ended |  | Six Months Ended |
| June 30, 2025 |  | June 30, 2024 |  | June 30, 2025 |  | June 30, 2024 |
| Significant non-cash items: |  |  |  |  |  |  |  |
| Stock‐based compensation expense | $ | 69.9 |  |  | $ | 64.3 |  |  | $ | 136.8 |  |  | $ | 127.3 |  |
| Depreciation and amortization expense | 38.3 |  |  | 29.2 |  |  | 74.1 |  |  | 57.8 |  |
| Total assets | $ | 10,641.4 |  |  | $ | 8,052.9 |  |  | $ | 10,641.4 |  |  | $ | 8,052.9 |  |
| Purchases of property and equipment | $ | 167.8 |  |  | $ | 23.1 |  |  | $ | 234.3 |  |  | $ | 245.0 |  |

[0001262039-25-000028:notes:146]
[same as prior period, unchanged from 0001262039-25-000017:notes:139]

[0001262039-25-000028:notes:147]
|  | Three Months Ended |  | Six Months Ended |
| Revenue | June 30,2025 |  | June 30,2024 |  | June 30,2025 |  | June 30,2024 |
| Americas: |  |  |  |  |  |  |  |
| United States | $ | 473.0 |  |  | $ | 435.7 |  |  | $ | 928.4 |  |  | $ | 842.8 |  |
| Other Americas | 185.8 |  |  | 159.6 |  |  | 360.2 |  |  | 309.5 |  |
| Total Americas | 658.8 |  |  | 595.3 |  |  | 1,288.6 |  |  | 1,152.3 |  |
| Europe, Middle East and Africa (“EMEA”) | 667.1 |  |  | 565.2 |  |  | 1,295.5 |  |  | 1,104.6 |  |
| Asia Pacific (“APAC”) | 304.1 |  |  | 273.8 |  |  | 585.6 |  |  | 530.7 |  |
| Total revenue | $ | 1,630.0 |  |  | $ | 1,434.3 |  |  | $ | 3,169.7 |  |  | $ | 2,787.6 |  |

[0001262039-25-000028:notes:148]
| Property and Equipment—net | June 30,2025 |  | December 31,2024 |
| Americas: |  |  |  |
| United States | $ | 1,009.6 |  |  | $ | 993.5 |  |
| Canada | 316.2 |  |  | 216.8 |  |
| Latin America | 4.1 |  |  | 4.4 |  |
| Total Americas | 1,329.9 |  |  | 1,214.7 |  |
| EMEA | 145.2 |  |  | 73.3 |  |
| APAC | 69.7 |  |  | 61.5 |  |
| Total property and equipment—net | $ | 1,544.8 |  |  | $ | 1,349.5 |  |

[0001262039-25-000028:notes:149]
[same as prior period, unchanged from 0001262039-25-000017:notes:142]

[0001262039-25-000028:notes:150]
|  | Three Months Ended |  | Six Months Ended |
|  | June 30,2025 |  | June 30,2024 |  | June 30,2025 |  | June 30,2024 |
| Distributor A | 27 | % |  | 30 | % |  | 27 | % |  | 29 | % |
| Distributor B | 15 | % |  | 16 | % |  | 15 | % |  | 15 | % |
| Distributor C | 12 | % |  | 14 | % |  | 12 | % |  | 13 | % |

[0001262039-25-000028:notes:151]
[same as prior period, unchanged from 0001262039-25-000017:notes:144]

[0001262039-25-000028:notes:152]
|  | June 30,2025 |  | December 31, 2024 |
| Distributor A | 27 | % |  | 31 | % |
| Distributor B | 13 | % |  | 14 | % |
| Distributor C | 9 | % |  | 10 | % |


## us-gaap:SubsequentEventsTextBlock

[0001262039-25-000028:notes:153]
SUBSEQUENT EVENTS
One Big Beautiful Bill Act

[0001262039-25-000028:notes:154]
On July 4, 2025, H.R. 1, An Act to Provide for Reconciliation Pursuant to Title II of House Concurrent Resolution 14 (the “Act”), commonly referred to as the One Big Beautiful Bill Act, was enacted. The Act makes permanent certain elements of the Tax Cuts and Jobs Act, including immediate expensing of U.S. research and development expenditures, immediate expensing of certain eligible assets, and various modifications to the international tax framework. We are evaluating the impact of the Act on our consolidated financial statements, but our preliminary analysis indicates that our cash tax payments for 2025 could be reduced by approximately $100 million to $150 million and our GAAP effective tax rate for 2025 could increase by approximately 1 point as a result of the provisions of the Act.

[0001262039-25-000028:notes:155]
Subsequent to June 30, 2025 through the filing of this Quarterly Report on Form 10-Q, we repurchased 1.0 million shares of our common stock at an average price of $72.29 per share, for an aggregate purchase price of $71.2 million, under the Repurchase Program. As of the filing of this Quarterly Report on Form 10-Q, approximately $1.56 billion remained available for future share repurchases through February 28, 2026 under the Repurchase Program.


## ecd:MtrlTermsOfTrdArrTextBlock

[0001262039-25-000028:notes:156]
As previously reported, our former Chief Financial Officer, Keith Jensen, retired on May 15, 2025. In connection with Mr. Jensen’s retirement, his pre-arranged written stock sale plan for the sale of shares of our common stock adopted on March 6, 2024 was terminated.
