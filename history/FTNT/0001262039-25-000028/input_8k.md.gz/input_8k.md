# FTNT 8-K — 0001262039-25-000025 filed 2025-08-06

## item codes, every 8-K on or before 2025-08-08

- 2025-08-06 0001262039-25-000025 — 2.02, 9.01
- 2025-06-18 0001262039-25-000022 — 5.07
- 2025-05-15 0001262039-25-000020 — 5.02 — amendment, the index does not say of what
- 2025-05-07 0001262039-25-000014 — 2.02, 9.01
- 2025-02-06 0001262039-25-000007 — 2.02, 5.02, 9.01
- 2025-01-22 0001262039-25-000003 — 5.02 — amendment, the index does not say of what
- 2024-11-12 0001262039-24-000045 — 5.02, 9.01
- 2024-11-07 0001262039-24-000040 — 2.02, 9.01
- 2024-08-07 0001262039-24-000034 — 2.02, 9.01 — amendment of 0001262039-24-000032
- 2024-08-06 0001262039-24-000032 — 2.02, 9.01
- 2024-07-24 0001262039-24-000028 — 5.02 — amendment, the index does not say of what
- 2024-06-20 0001262039-24-000025 — 5.07
- 2024-05-02 0001262039-24-000017 — 2.02, 9.01
- 2024-02-23 0001262039-24-000011 — 5.02, 9.01
- 2024-02-06 0001262039-24-000006 — 2.02, 9.01
- 2024-01-18 0001262039-24-000003 — 5.02
- 2023-12-01 0001262039-23-000041 — 5.02
- 2023-11-02 0001262039-23-000035 — 2.02, 9.01
- 2023-08-03 0001262039-23-000027 — 2.02, 9.01
- 2023-06-23 0001262039-23-000024 — 5.03, 5.07, 9.01
- 2023-05-04 0001262039-23-000013 — 2.02, 9.01
- 2023-02-08 0001262039-23-000006 — 5.03, 9.01
- 2023-02-07 0001262039-23-000003 — 2.02, 9.01
- 2022-11-02 0001262039-22-000035 — 2.02, 9.01
- 2022-08-03 0001262039-22-000026 — 2.02, 9.01
- 2022-06-22 0001262039-22-000023 — 5.03, 9.01
- 2022-06-21 0001262039-22-000021 — 5.07
- 2022-05-04 0001262039-22-000015 — 2.02, 9.01
- 2022-05-02 0001262039-22-000012 — 5.02
- 2022-04-22 0001262039-22-000010 — 8.01
- 2022-02-03 0001262039-22-000005 — 2.02, 9.01
- 2022-01-26 0001262039-22-000002 — 5.02, 9.01 — amendment, the index does not say of what
- 2021-11-04 0001262039-21-000027 — 2.02, 9.01
- 2021-10-06 0001262039-21-000024 — 5.02, 9.01
- 2021-07-29 0001262039-21-000019 — 2.02, 9.01
- 2021-06-23 0001262039-21-000016 — 5.07
- 2021-04-30 0001104659-21-059008 — 5.03 — amendment, the index does not say of what
- 2021-04-29 0001262039-21-000011 — 2.02, 9.01
- 2021-04-28 0001104659-21-056360 — 5.02, 5.03, 9.01
- 2021-03-05 0001193125-21-071498 — 1.01, 9.01
- 2021-02-25 0001193125-21-057281 — 1.01, 9.01
- 2021-02-04 0001262039-21-000005 — 2.02, 9.01
- 2020-12-08 0001262039-20-000070 — 8.01
- 2020-10-29 0001262039-20-000063 — 2.02, 9.01
- 2020-10-20 0001262039-20-000060 — 5.02 — amendment, the index does not say of what
- 2020-08-26 0001262039-20-000056 — 5.02, 9.01
- 2020-08-06 0001262039-20-000051 — 2.02, 9.01
- 2020-07-21 0001262039-20-000044 — 5.03, 8.01, 9.01
- 2020-06-24 0001262039-20-000038 — 5.07
- 2020-05-06 0001262039-20-000029 — 2.02, 9.01
- 2020-04-23 0001262039-20-000025 — 5.03, 9.01
- 2020-04-23 0001262039-20-000024 — 5.02 — amendment of 0001262039-20-000025
- 2020-02-28 0001262039-20-000015 — 5.02, 9.01
- 2020-02-06 0001262039-20-000004 — 2.02, 9.01
- 2019-12-12 0001262039-19-000038 — 8.01
- 2019-10-31 0001262039-19-000032 — 2.02, 9.01
- 2019-10-28 0001262039-19-000027 — 8.01
- 2019-10-23 0001262039-19-000025 — 5.02, 9.01
- 2019-08-01 0001262039-19-000021 — 2.02, 9.01
- 2019-06-26 0001262039-19-000018 — 5.07
- 2019-05-02 0001262039-19-000010 — 2.02, 9.01
- 2019-02-06 0001262039-19-000002 — 2.02, 9.01
- 2018-11-01 0001262039-18-000037 — 2.02, 9.01
- 2018-10-23 0001262039-18-000035 — 8.01
- 2018-08-01 0001262039-18-000025 — 2.02, 9.01
- 2018-06-28 0001262039-18-000023 — 5.03, 5.07, 9.01
- 2018-06-04 0001262039-18-000021 — 8.01
- 2018-05-03 0001262039-18-000017 — 2.02, 5.02, 9.01
- 2018-02-05 0001262039-18-000004 — 2.02, 5.02, 9.01
- 2017-10-26 0001262039-17-000031 — 2.02, 9.01
- 2017-10-19 0001262039-17-000029 — 5.02 — amendment, the index does not say of what
- 2017-07-26 0001262039-17-000025 — 2.02, 9.01
- 2017-06-27 0001262039-17-000023 — 5.07
- 2017-05-31 0001262039-17-000021 — 5.02 — amendment of 0001262039-17-000019
- 2017-05-30 0001262039-17-000019 — 5.02, 9.01
- 2017-04-27 0001262039-17-000013 — 2.02, 9.01
- 2017-02-02 0001262039-17-000003 — 2.02, 9.01
- 2016-10-27 0001262039-16-000085 — 2.02, 9.01
- 2016-10-11 0001262039-16-000082 — 2.02, 9.01
- 2016-07-28 0001262039-16-000076 — 2.02, 9.01
- 2016-07-22 0001262039-16-000073 — 8.01, 9.01
- 2016-06-20 0001262039-16-000068 — 5.07
- 2016-06-07 0001193125-16-614788 — 8.01
- 2016-04-26 0001262039-16-000061 — 2.02, 9.01
- 2016-01-28 0001262039-16-000051 — 2.02, 9.01
- 2015-10-27 0001262039-15-000045 — 2.02
- 2015-10-22 0001262039-15-000042 — 5.02 — amendment, the index does not say of what
- 2015-10-22 0001262039-15-000041 — 5.02 — amendment, the index does not say of what
- 2015-10-22 0001262039-15-000039 — 2.02, 9.01
- 2015-09-28 0001262039-15-000034 — 5.02, 9.01
- 2015-09-22 0001262039-15-000031 — 9.01 — amendment of 0001193125-15-248065
- 2015-08-28 0001262039-15-000027 — 3.01, 5.02
- 2015-07-23 0001262039-15-000021 — 5.02
- 2015-07-22 0001262039-15-000019 — 2.02, 9.01
- 2015-07-08 0001193125-15-248065 — 2.01, 8.01, 9.01
- 2015-06-22 0001193125-15-229099 — 5.07
- 2015-06-19 0001193125-15-228428 — 5.02, 9.01
- 2015-04-20 0001262039-15-000014 — 2.02, 9.01
- 2015-01-28 0001262039-15-000005 — 2.02, 9.01
- 2014-10-22 0001262039-14-000036 — 2.02, 9.01
- 2014-07-23 0001262039-14-000030 — 2.02, 9.01
- 2014-06-24 0001262039-14-000027 — 5.07
- 2014-04-23 0001262039-14-000021 — 2.02, 9.01
- 2014-04-21 0001262039-14-000018 — 5.03, 9.01
- 2014-01-29 0001262039-14-000004 — 2.02, 9.01
- 2013-12-20 0001262039-13-000061 — 5.02, 9.01
- 2013-11-27 0001262039-13-000057 — 5.02, 7.01, 9.01
- 2013-11-12 0001445305-13-002993 — 5.02
- 2013-10-23 0001262039-13-000051 — 2.02, 9.01
- 2013-07-30 0001262039-13-000039 — 2.02, 9.01
- 2013-06-25 0001262039-13-000030 — 5.07
- 2013-04-30 0001262039-13-000023 — 2.02, 9.01
- 2013-04-19 0001262039-13-000020 — 5.02, 9.01
- 2013-04-19 0001262039-13-000018 — 5.02 — amendment of 0001262039-13-000020
- 2013-04-10 0001262039-13-000016 — 2.02, 9.01
- 2013-03-26 0001262039-13-000013 — 5.02
- 2013-01-30 0001262039-13-000005 — 2.02, 9.01
- 2013-01-24 0001262039-13-000002 — 5.02, 9.01
- 2012-10-16 0001262039-12-000048 — 2.02, 9.01
- 2012-10-01 0001262039-12-000045 — 5.02
- 2012-09-26 0001262039-12-000043 — 5.01
- 2012-07-25 0001262039-12-000038 — 2.02, 9.01
- 2012-07-19 0001262039-12-000034 — 5.02
- 2012-06-20 0001193125-12-275869 — 5.07
- 2012-04-27 0001262039-12-000029 — 5.02
- 2012-04-24 0001262039-12-000025 — 2.02, 9.01
- 2012-01-31 0001262039-12-000006 — 2.02, 9.01
- 2012-01-25 0001262039-12-000003 — 5.03
- 2011-10-24 0001262039-11-000036 — 2.02
- 2011-07-19 0001262039-11-000014 — 2.02, 9.01
- 2011-06-27 0001193125-11-174474 — 5.02, 5.07, 9.01
- 2011-04-27 0001193125-11-111938 — 2.02, 9.01
- 2011-01-25 0001193125-11-013914 — 2.02, 9.01
- 2010-10-21 0001193125-10-233676 — 2.02, 9.01
- 2010-09-02 0001193125-10-203099 — 8.01
- 2010-07-22 0001193125-10-163844 — 2.02, 9.01
- 2010-06-24 0001193125-10-146082 — 5.07
- 2010-04-28 0001193125-10-096698 — 2.02, 9.01
- 2010-02-09 0001193125-10-024614 — 8.01
- 2010-01-27 0001193125-10-014292 — 2.02, 9.01
- 2010-01-26 0001193125-10-013031 — 5.02, 9.01

## late-filing notifications on or before 2025-08-08

- none on or before 2025-08-08

## item 2.02 — earnings release, exhibit 99.1

[0001262039-25-000025:8k_2_02:1]
EX-99.1
2
ftntq2-2025ex991.htm
PRESS RELEASE

[0001262039-25-000025:8k_2_02:2]
Document

[0001262039-25-000025:8k_2_02:3]
Press Release

[0001262039-25-000025:8k_2_02:4]
Fortinet Reports Second Quarter 2025 Financial Results

[0001262039-25-000025:8k_2_02:5]
Highlights

[0001262039-25-000025:8k_2_02:6]
•Revenue grew 14% year over year to $1.63 billion

[0001262039-25-000025:8k_2_02:7]
•Billings grew 15% year over year to $1.78 billion1

[0001262039-25-000025:8k_2_02:8]
•Unified SASE ARR up 22% and Security Operations ARR up 35%, year over year2

[0001262039-25-000025:8k_2_02:9]
•GAAP operating margin of 28%

[0001262039-25-000025:8k_2_02:10]
•Non-GAAP operating margin of 33%1

[0001262039-25-000025:8k_2_02:11]
•Raised 2025 full year billings guidance midpoint by $100 million

[0001262039-25-000025:8k_2_02:12]
SUNNYVALE, Calif. - August 6, 2025 - Fortinet® (Nasdaq: FTNT), a global cybersecurity leader driving the convergence of networking and security, today announced financial results for the second quarter ended June 30, 2025.

[0001262039-25-000025:8k_2_02:13]
“Our strong second quarter performance and consistent track record of growth are a direct result of our continued innovation and customer-first strategy, enabling us to beat our billings guidance for the quarter and raise our full year billings outlook,” said Ken Xie, Founder, Chairman and Chief Executive Officer of Fortinet. “We are the industry leader in network security, with the most deployed firewalls worldwide, a New-Generation SASE Firewall, and recognized leadership in the 2025 Gartner® Magic Quadrant™ for SASE Platforms. This recognition, along with our strong business momentum, financial outlook, innovation, and leadership across five separate network security Magic Quadrant™ reports, underscores the strength of our AI-driven security approach and the strategic advantage of our unified FortiOS operating system.”

[0001262039-25-000025:8k_2_02:14]
Recent Market Leadership Highlights

[0001262039-25-000025:8k_2_02:15]
•Recognized as a Leader in the 2025 Gartner® Magic Quadrant™ for SASE Platforms, #1 in the Critical Capabilities for SASE Platforms report for the Secure Branch Network Modernization use case, and the only vendor in five different network security Magic Quadrant™ reports.

[0001262039-25-000025:8k_2_02:16]
•Expanded FortiCloud with three new natively integrated services: FortiIdentity, FortiDrive, and FortiConnect.

[0001262039-25-000025:8k_2_02:17]
•Recognized as the Overall Leader in the Westlands Advisory IT/OT Network Protection Platform Navigator 2025TM report for the third time in a row.

[0001262039-25-000025:8k_2_02:18]
•Named a Leader in the 2025 Gartner® Magic Quadrant™ for Enterprise Wired and Wireless LAN Infrastructure for the second year in a row.

[0001262039-25-000025:8k_2_02:19]
•Recognized as a Gartner Peer Insights™ Customers’ Choice for SD-WAN for the sixth consecutive year and for Endpoint Protection for the third consecutive year.

[0001262039-25-000025:8k_2_02:20]
•Crossed 1,400 issued patents worldwide, and over 500 issued and pending AI patents, driven by R&D investments.

[0001262039-25-000025:8k_2_02:21]
Guidance

[0001262039-25-000025:8k_2_02:22]
For the third quarter of 2025, Fortinet currently expects:

[0001262039-25-000025:8k_2_02:23]
•Revenue in the range of $1.670 billion to $1.730 billion

[0001262039-25-000025:8k_2_02:24]
•Billings in the range of $1.760 billion to $1.840 billion

[0001262039-25-000025:8k_2_02:25]
•Non-GAAP gross margin in the range of 80.0% to 81.0%

[0001262039-25-000025:8k_2_02:26]
•Non-GAAP operating margin in the range of 32.5% to 33.5%

[0001262039-25-000025:8k_2_02:27]
•Diluted non-GAAP net income per share in the range of $0.62 to $0.64, assuming a non-GAAP effective tax rate of 18%. This assumes a diluted share count of 772 million to 776 million.

[0001262039-25-000025:8k_2_02:28]
For the fiscal year 2025, Fortinet currently expects:

[0001262039-25-000025:8k_2_02:29]
•Revenue in the range of $6.675 billion to $6.825 billion

[0001262039-25-000025:8k_2_02:30]
•Service revenue in the range of $4.550 billion to $4.650 billion

[0001262039-25-000025:8k_2_02:31]
•Billings in the range of $7.325 billion to $7.475 billion

[0001262039-25-000025:8k_2_02:32]
•Non-GAAP gross margin in the range of 79.0% to 81.0%

[0001262039-25-000025:8k_2_02:33]
•Non-GAAP operating margin in the range of 32.0% to 33.5%

[0001262039-25-000025:8k_2_02:34]
•Diluted non-GAAP net income per share in the range of $2.47 to $2.53, assuming a non-GAAP effective tax rate of 18%. This assumes a diluted share count of 773 million to 777 million.

[0001262039-25-000025:8k_2_02:35]
Our guidance with respect to non-GAAP financial measures excludes stock-based compensation, amortization of acquired intangible assets, gain on intellectual property matters, gain on bargain purchase related to acquisition, gain from an equity method investment and a tax adjustment required for an effective tax rate on a non-GAAP basis, which differs from the GAAP effective tax rate. We have not reconciled our guidance with respect to non-GAAP financial measures to the corresponding GAAP measures because certain items that impact these measures are uncertain or out of our control, or cannot be reasonably predicted. Accordingly, a reconciliation of these non-GAAP financial measures to the corresponding GAAP measures is not available without unreasonable effort.

[0001262039-25-000025:8k_2_02:36]
Conference Call Details

[0001262039-25-000025:8k_2_02:37]
Fortinet will host a conference call today at 1:30 p.m. Pacific Time (4:30 p.m. Eastern Time) to discuss the earnings results. A live webcast of the conference call and supplemental slides will be accessible from the Investor Relations page of Fortinet’s website at https://investor.fortinet.com and a replay will be archived and accessible at https://investor.fortinet.com/events-and-presentations.

[0001262039-25-000025:8k_2_02:38]
Third Quarter 2025 Conference Participation Schedule:

[0001262039-25-000025:8k_2_02:39]
•Deutsche Bank Technology Conference

[0001262039-25-000025:8k_2_02:40]
August 27, 2025

[0001262039-25-000025:8k_2_02:41]
•Citi Global TMT Conference

[0001262039-25-000025:8k_2_02:42]
September 5, 2025

[0001262039-25-000025:8k_2_02:43]
•Goldman Sachs Communacopia + Technology Conference

[0001262039-25-000025:8k_2_02:44]
September 11, 2025

[0001262039-25-000025:8k_2_02:45]
Members of Fortinet’s management team are expected to present at these conferences and discuss the latest company strategies and initiatives. Fortinet’s conference presentations are expected to be available via webcast on the company’s website. To access the most updated information, pre-register and listen to the webcast of each event, please visit the Investor Presentation & Events page of Fortinet’s website at https://investor.fortinet.com/events-and-presentations. The schedule is subject to change.

[0001262039-25-000025:8k_2_02:46]
About Fortinet (www.fortinet.com)

[0001262039-25-000025:8k_2_02:47]
Fortinet (Nasdaq: FTNT) is a driving force in the evolution of cybersecurity and the convergence of networking and security. Our mission is to secure people, devices and data everywhere, and today we deliver cybersecurity everywhere our customers need it with the largest integrated portfolio of over 50 enterprise-grade products. Well over half a million customers trust Fortinet’s solutions, which are among the most deployed, most patented and most validated in the industry. The Fortinet Training Institute, one of the largest and broadest training programs in the industry, is dedicated to making cybersecurity training and new career opportunities available to everyone. Collaboration with esteemed organizations from both the public and private sectors, including Computer Emergency Response Teams (“CERTs”), government entities, and academia, is a fundamental aspect of Fortinet’s commitment to enhance cyber resilience globally. FortiGuard Labs, Fortinet’s elite threat intelligence and research organization, develops and utilizes leading-edge machine learning and AI technologies to provide customers with timely and consistently top-rated protection and actionable threat intelligence. Learn more at https://www.fortinet.com, the Fortinet Blog or FortiGuard Labs.

[0001262039-25-000025:8k_2_02:48]
Forward-Looking Statements

[0001262039-25-000025:8k_2_02:49]
This press release contains forward-looking statements that involve risks and uncertainties. These forward-looking statements include statements regarding any indications related to future growth and market share gains, our strategy going forward, and guidance and expectations around future financial results, including guidance and expectations for the third quarter and full year 2025, and any statements regarding our market opportunity and market size, and business momentum. Although we attempt to be accurate in making forward-looking statements, it is possible that future circumstances might differ from the assumptions on which such statements are based such that actual results are materially different from our forward-looking statements in this release. Important factors that could cause results to differ materially from the statements herein include the following: general economic risks, including those caused by economic challenges, a possible economic downturn or recession and the effects of inflation or stagflation, rising interest rates or reduced information technology spending; supply chain challenges; negative impacts from the ongoing war in Ukraine and its related macroeconomic effects and our decision to reduce operations in Russia; competitiveness in the security market; the dynamic nature of the security market and its products and services; specific economic risks worldwide and in different geographies, and among different customer segments; uncertainty regarding demand and increased business and renewals from existing customers; sales execution risks, including risks in connection with the timing and completion of large strategic deals; uncertainties around continued success in sales growth and market share gains; uncertainties in market opportunities and the market size; actual or perceived vulnerabilities in our supply chain, products or services, and any actual or perceived breach of our network or our customers’ networks; longer sales cycles, particularly for larger enterprise, service providers, government and other large organization customers; the effectiveness of our salesforce and failure to convert sales pipeline into final sales; risks associated with successful implementation of multiple integrated software products and other product functionality risks; risks associated with integrating acquisitions and changes in circumstances and plans associated therewith, including, among other risks, changes in plans related to product and services integrations,

[0001262039-25-000025:8k_2_02:50]
Use of Non-GAAP Financial Measures

[0001262039-25-000025:8k_2_02:51]
We believe that the presentation of non-GAAP financial information provides important supplemental information to management and investors regarding financial and business trends relating to our financial condition and results of operations. For further information regarding why we believe that these non-GAAP measures provide useful information to investors, the specific manner in which management uses these measures, and some of the limitations associated with the use of these measures, please refer to the “Explanation of Non-GAAP Financial Measures” section of this press release.

[0001262039-25-000025:8k_2_02:52]
FORTINET, INC.

[0001262039-25-000025:8k_2_02:53]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001262039-25-000025:8k_2_02:54]
(Unaudited, in millions)

[0001262039-25-000025:8k_2_02:55]
|  | June 30,2025 |  | December 31,2024 |
| ASSETS |  |  |  |
| CURRENT ASSETS: |  |  |  |
| Cash and cash equivalents | $ | 3,368.5 |  |  | $ | 2,875.9 |  |
| Short-term investments | 1,194.4 |  |  | 1,190.6 |  |
| Accounts receivable—net | 1,215.7 |  |  | 1,463.4 |  |
| Inventory | 405.2 |  |  | 315.5 |  |
| Prepaid expenses and other current assets | 162.5 |  |  | 126.1 |  |
| Total current assets | 6,346.3 |  |  | 5,971.5 |  |
| LONG-TERM INVESTMENTS | 112.0 |  |  | — |  |
| PROPERTY AND EQUIPMENT—NET | 1,544.8 |  |  | 1,349.5 |  |
| DEFERRED CONTRACT COSTS | 665.4 |  |  | 622.9 |  |
| DEFERRED TAX ASSETS | 1,457.2 |  |  | 1,335.6 |  |
| GOODWILL AND OTHER INTANGIBLE ASSETS—NET | 382.2 |  |  | 350.4 |  |
| OTHER ASSETS | 133.5 |  |  | 133.2 |  |
| TOTAL ASSETS | $ | 10,641.4 |  |  | $ | 9,763.1 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |
| CURRENT LIABILITIES: |  |  |  |
| Accounts payable | $ | 245.2 |  |  | $ | 190.9 |  |
| Accrued liabilities | 339.1 |  |  | 337.9 |  |
| Accrued payroll and compensation | 281.3 |  |  | 255.7 |  |
| Current portion of long-term debt | 499.0 |  |  | — |  |
| Deferred revenue | 3,412.5 |  |  | 3,276.2 |  |
| Total current liabilities | 4,777.1 |  |  | 4,060.7 |  |
| DEFERRED REVENUE | 3,155.1 |  |  | 3,084.7 |  |
| LONG-TERM DEBT | 496.3 |  |  | 994.3 |  |
| OTHER LIABILITIES | 152.5 |  |  | 129.6 |  |
| Total liabilities | 8,581.0 |  |  | 8,269.3 |  |
| COMMITMENTS AND CONTINGENCIES |  |  |  |
| STOCKHOLDERS’ EQUITY: |  |  |  |
| Common stock | 0.8 |  |  | 0.8 |  |
| Additional paid-in capital | 1,715.9 |  |  | 1,636.2 |  |
| Accumulated other comprehensive loss | (20.7) |  |  | (26.1) |  |
| Retained earnings (accumulated deficit) | 364.4 |  |  | (117.1) |  |
| Total stockholders’ equity | 2,060.4 |  |  | 1,493.8 |  |
| TOTAL LIABILITIES AND STOCKHOLDERS’ EQUITY | $ | 10,641.4 |  |  | $ | 9,763.1 |  |

[0001262039-25-000025:8k_2_02:56]
FORTINET, INC.

[0001262039-25-000025:8k_2_02:57]
CONDENSED CONSOLIDATED STATEMENTS OF INCOME

[0001262039-25-000025:8k_2_02:58]
(Unaudited, in millions, except per share amounts)

[0001262039-25-000025:8k_2_02:59]
|  | Three Months Ended |  | Six Months Ended |
|  | June 30,2025 |  | June 30,2024 |  | June 30,2025 |  | June 30,2024 |
| REVENUE: |  |  |  |  |  |  |  |
| Product | $ | 508.9 |  |  | $ | 451.9 |  |  | $ | 968.0 |  |  | $ | 860.8 |  |
| Service | 1,121.1 |  |  | 982.4 |  |  | 2,201.7 |  |  | 1,926.8 |  |
| Total revenue | 1,630.0 |  |  | 1,434.3 |  |  | 3,169.7 |  |  | 2,787.6 |  |
| COST OF REVENUE: |  |  |  |  |  |  |  |
| Product | 165.9 |  |  | 155.1 |  |  | 315.8 |  |  | 337.9 |  |
| Service | 149.0 |  |  | 119.9 |  |  | 292.2 |  |  | 241.8 |  |
| Total cost of revenue | 314.9 |  |  | 275.0 |  |  | 608.0 |  |  | 579.7 |  |
| GROSS PROFIT: |  |  |  |  |  |  |  |
| Product | 343.0 |  |  | 296.8 |  |  | 652.2 |  |  | 522.9 |  |
| Service | 972.1 |  |  | 862.5 |  |  | 1,909.5 |  |  | 1,685.0 |  |
| Total gross profit | 1,315.1 |  |  | 1,159.3 |  |  | 2,561.7 |  |  | 2,207.9 |  |
| OPERATING EXPENSES: |  |  |  |  |  |  |  |
| Research and development | 209.5 |  |  | 165.4 |  |  | 408.1 |  |  | 338.4 |  |
| Sales and marketing | 592.0 |  |  | 501.3 |  |  | 1,134.7 |  |  | 1,002.4 |  |
| General and administrative | 56.9 |  |  | 56.6 |  |  | 114.7 |  |  | 111.0 |  |
| Gain on intellectual property matters | (1.3) |  |  | (1.2) |  |  | (7.6) |  |  | (2.3) |  |
| Total operating expenses | 857.1 |  |  | 722.1 |  |  | 1,649.9 |  |  | 1,449.5 |  |
| OPERATING INCOME | 458.0 |  |  | 437.2 |  |  | 911.8 |  |  | 758.4 |  |
| INTEREST INCOME | 45.0 |  |  | 38.3 |  |  | 89.3 |  |  | 70.5 |  |
| INTEREST EXPENSE | (4.6) |  |  | (5.0) |  |  | (9.5) |  |  | (10.1) |  |
| OTHER INCOME (EXPENSE)—NET | 18.9 |  |  | (2.2) |  |  | 45.0 |  |  | (5.1) |  |
| INCOME BEFORE INCOME TAXES AND GAIN (LOSS) FROM EQUITY METHOD INVESTMENTS | 517.3 |  |  | 468.3 |  |  | 1,036.6 |  |  | 813.7 |  |
| PROVISION FOR INCOME TAXES | 77.1 |  |  | 76.5 |  |  | 173.6 |  |  | 116.0 |  |
| GAIN (LOSS) FROM EQUITY METHOD INVESTMENTS | (0.1) |  |  | (12.0) |  |  | 10.5 |  |  | (18.6) |  |
| NET INCOME | $ | 440.1 |  |  | $ | 379.8 |  |  | $ | 873.5 |  |  | $ | 679.1 |  |
| Net income per share: |  |  |  |  |  |  |  |
| Basic | $ | 0.57 |  |  | $ | 0.50 |  |  | $ | 1.14 |  |  | $ | 0.89 |  |
| Diluted | $ | 0.57 |  |  | $ | 0.49 |  |  | $ | 1.13 |  |  | $ | 0.88 |  |
| Weighted-average shares outstanding: |  |  |  |  |  |  |  |
| Basic | 765.5 |  |  | 763.8 |  |  | 766.9 |  |  | 763.1 |  |
| Diluted | 772.7 |  |  | 769.9 |  |  | 774.8 |  |  | 770.2 |  |

[0001262039-25-000025:8k_2_02:60]
FORTINET, INC.

[0001262039-25-000025:8k_2_02:61]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001262039-25-000025:8k_2_02:62]
(Unaudited, in millions)

[0001262039-25-000025:8k_2_02:63]
|  | Six Months Ended |
|  | June 30,2025 |  | June 30,2024 |
| CASH FLOWS FROM OPERATING ACTIVITIES: |  |  |  |
| Net income | $ | 873.5 |  |  | $ | 679.1 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |
| Stock-based compensation | 135.2 |  |  | 126.2 |  |
| Amortization of deferred contract costs | 160.0 |  |  | 144.7 |  |
| Depreciation and amortization | 74.1 |  |  | 57.8 |  |
| Amortization of investment discounts | (19.4) |  |  | (24.9) |  |
| Other | (44.8) |  |  | 25.6 |  |
| Changes in operating assets and liabilities, net of impact of business combinations: |  |  |  |
| Accounts receivable—net | 262.7 |  |  | 318.9 |  |
| Inventory | (79.6) |  |  | 85.2 |  |
| Prepaid expenses and other current assets | (32.1) |  |  | (12.3) |  |
| Deferred contract costs | (202.5) |  |  | (136.0) |  |
| Deferred tax assets | (75.3) |  |  | (130.3) |  |
| Other assets | (11.7) |  |  | (7.6) |  |
| Accounts payable | 46.8 |  |  | (67.2) |  |
| Accrued liabilities | (9.7) |  |  | (24.9) |  |
| Accrued payroll and compensation | 22.9 |  |  | (24.3) |  |
| Deferred revenue | 204.8 |  |  | 161.7 |  |
| Other liabilities | 10.3 |  |  | 0.7 |  |
| Net cash provided by operating activities | 1,315.2 |  |  | 1,172.4 |  |
| CASH FLOWS FROM INVESTING ACTIVITIES: |  |  |  |
| Purchases of investments | (976.5) |  |  | (974.3) |  |
| Sales of investments | 5.7 |  |  | — |  |
| Maturities of investments | 869.6 |  |  | 904.6 |  |
| Purchases of property and equipment | (234.3) |  |  | (245.0) |  |
| Payments made in connection with business combinations, net of cash acquired | (41.6) |  |  | (5.7) |  |
| Other | 0.1 |  |  | — |  |
| Net cash used in investing activities | (377.0) |  |  | (320.4) |  |
| CASH FLOWS FROM FINANCING ACTIVITIES: |  |  |  |
| Repurchase and retirement of common stock | (401.1) |  |  | — |  |
| Proceeds from issuance of common stock | 31.3 |  |  | 19.6 |  |
| Taxes paid related to net share settlement of equity awards | (77.0) |  |  | (63.1) |  |
| Other | (0.1) |  |  | (0.8) |  |
| Net cash used in financing activities | (446.9) |  |  | (44.3) |  |
| EFFECT OF EXCHANGE RATE CHANGES ON CASH AND CASH EQUIVALENTS | 1.3 |  |  | (2.4) |  |
| NET INCREASE IN CASH AND CASH EQUIVALENTS | 492.6 |  |  | 805.3 |  |
| CASH AND CASH EQUIVALENTS—Beginning of period | 2,875.9 |  |  | 1,397.9 |  |
| CASH AND CASH EQUIVALENTS—End of period | $ | 3,368.5 |  |  | $ | 2,203.2 |  |

[0001262039-25-000025:8k_2_02:64]
Reconciliations of non-GAAP results of operations measures to the nearest comparable GAAP measures

[0001262039-25-000025:8k_2_02:65]
(Unaudited, in millions, except per share amounts)

[0001262039-25-000025:8k_2_02:66]
Reconciliation of GAAP operating income to non-GAAP operating income, operating margin, net income and diluted net income per share

[0001262039-25-000025:8k_2_02:67]
|  | Three Months Ended |  |  |
|  | June 30,2025 |  | June 30,2024 |  |  |  |  |
| Reconciliation of non-GAAP operating income: |  |  |  |  |  |  |  |
| GAAP operating income | $ | 458.0 |  |  | $ | 437.2 |  |  |  |  |  |
| GAAP operating margin | 28.1 | % |  | 30.5 | % |  |  |  |  |
| Add back: |  |  |  |  |  |  |  |
| Stock‐based compensation | 69.9 |  |  | 64.3 |  |  |  |  |  |
| Amortization of acquired intangible assets | 13.2 |  |  | 3.3 |  |  |  |  |  |
| Gain on intellectual property matters | (1.3) |  |  | (1.2) |  |  |  |  |  |
| Non‐GAAP operating income | $ | 539.8 |  |  | $ | 503.6 |  |  |  |  |  |
| Non‐GAAP operating margin | 33.1 | % |  | 35.1 | % |  |  |  |  |
| Reconciliation of non-GAAP net income: |  |  |  |  |  |  |  |
| GAAP net income | $ | 440.1 |  |  | $ | 379.8 |  |  |  |  |  |
| Add back: |  |  |  |  |  |  |  |
| Stock‐based compensation | 69.9 |  |  | 64.3 |  |  |  |  |  |
| Amortization of acquired intangible assets | 13.2 |  |  | 3.3 |  |  |  |  |  |
| Gain on intellectual property matters | (1.3) |  |  | (1.2) |  |  |  |  |  |
| Tax adjustment (a) | (30.8) |  |  | (14.3) |  |  |  |  |  |
| Non-cash charge on equity method investment | — |  |  | 8.0 |  |  |  |  |  |
| Non-GAAP net income | $ | 491.1 |  |  | $ | 439.9 |  |  |  |  |  |
| Non-GAAP net income per share, diluted |  |  |  |  |  |  |  |
| Non-GAAP net income | $ | 491.1 |  |  | $ | 439.9 |  |  |  |  |  |
| Non-GAAP shares used in diluted net income per share calculations | 772.7 |  |  | 769.9 |  |  |  |  |  |
| Non-GAAP net income per share, diluted | $ | 0.64 |  |  | $ | 0.57 |  |  |  |  |  |
| Reconciliation of non-GAAP net income per share, diluted |  |  |  |  |  |  |  |
| GAAP net income per share, diluted | $ | 0.57 |  |  | $ | 0.49 |  |  |  |  |  |
| Add back: |  |  |  |  |  |  |  |
| Non-GAAP adjustments to net income per share | 0.07 |  |  | 0.08 |  |  |  |  |  |
| Non-GAAP net income per share, diluted | $ | 0.64 |  |  | $ | 0.57 |  |  |  |  |  |

[0001262039-25-000025:8k_2_02:68]
(a) Non-GAAP financial information is adjusted to an effective tax rate of 18% and 17% in the three months ended June 30, 2025 and 2024, respectively, on a non-GAAP basis, which differs from the GAAP effective tax rate.

[0001262039-25-000025:8k_2_02:69]
Reconciliation of net cash provided by operating activities to free cash flow

[0001262039-25-000025:8k_2_02:70]
|  | Three Months Ended |
|  | June 30,2025 |  | June 30,2024 |
| Net cash provided by operating activities | $ | 451.9 |  |  | $ | 342.0 |  |
| Less: Purchases of property and equipment | (167.8) |  |  | (23.1) |  |
| Free cash flow | $ | 284.1 |  |  | $ | 318.9 |  |
| Net cash used in investing activities | $ | (266.2) |  |  | $ | (50.1) |  |
| Net cash used in financing activities | $ | (414.2) |  |  | $ | (14.0) |  |

[0001262039-25-000025:8k_2_02:71]
Reconciliation of total revenue to total billings

[0001262039-25-000025:8k_2_02:72]
|  | Three Months Ended |
|  | June 30,2025 |  | June 30,2024 |
| Total revenue | $ | 1,630.0 |  |  | $ | 1,434.3 |  |
| Add: Change in deferred revenue | 149.2 |  |  | 106.3 |  |
| Less: Deferred revenue balance acquired in business acquisitions | (0.8) |  |  | — |  |
| Total billings | $ | 1,778.4 |  |  | $ | 1,540.6 |  |

[0001262039-25-000025:8k_2_02:73]
1 A reconciliation of GAAP to non-GAAP measures has been provided in the financial statement tables included in this press release. An explanation of these measures is also included below under the heading “Explanation of Non-GAAP Financial Measures”.

[0001262039-25-000025:8k_2_02:74]
2 Annual Recurring Revenue or ARR is defined as the annualized value of renewable / recurring customer agreements as of the measurement date, assuming any contract that expires during the next 12 months is renewed at its existing value.

[0001262039-25-000025:8k_2_02:75]
Explanation of Non-GAAP Financial Measures

[0001262039-25-000025:8k_2_02:76]
We have provided in this release financial information that has not been prepared in accordance with U.S. Generally Accepted Accounting Principles (“GAAP”). These non-GAAP financial and liquidity measures are not based on any standardized methodology prescribed by GAAP and are not necessarily comparable to similar measures presented by other companies. We use these non-GAAP financial measures internally in analyzing our financial results and believe they are useful to investors, as a supplement to GAAP measures, in evaluating our ongoing operational performance. We believe that the use of these non-GAAP financial measures provides an additional tool for investors to use in evaluating ongoing operating results and trends and in comparing our financial results with peer companies, many of which present similar non-GAAP financial measures to investors.

[0001262039-25-000025:8k_2_02:77]
Non-GAAP financial measures should not be considered in isolation from, or as a substitute for, financial information prepared in accordance with GAAP. Investors are encouraged to review the reconciliation of these non-GAAP financial measures to their most directly comparable GAAP financial measures provided in the financial statement tables below.

[0001262039-25-000025:8k_2_02:78]
Billings (non-GAAP). We define billings as revenue recognized in accordance with GAAP plus the change in deferred revenue from the beginning to the end of the period less any deferred revenue balances acquired from business combination(s) during the period. We consider billings to be a useful metric for management and investors because billings drive current and future revenue, which is an important indicator of the health and viability of our business and cash flows. There are a number of limitations related to the use of billings instead of GAAP revenue. First, billings include amounts that have not yet been recognized as revenue and are impacted by the term of security and support agreements. Second, we may calculate billings in a manner that is different from peer companies that report similar financial measures. Management accounts for these limitations by providing specific information regarding GAAP revenue and evaluating billings together with GAAP revenue.

[0001262039-25-000025:8k_2_02:79]
Free cash flow (non-GAAP). We define free cash flow as net cash provided by operating activities minus purchases of property and equipment. We believe free cash flow to be a liquidity measure that provides useful information to management and investors about the amount of cash generated by the business that, after capital expenditures, can be used for strategic opportunities, including repurchasing outstanding common stock, investing in our business, making strategic acquisitions and strengthening the balance sheet. A limitation of using free cash flow rather than the GAAP measures of cash provided by or used in operating activities, investing activities, and financing activities is that free cash flow does not represent the total increase or decrease in the cash and cash equivalents balance for the period because it excludes investing activities other than capital expenditures and cash flows from financing activities. Management accounts for this limitation by providing information about our capital expenditures and other investing and financing activities on the face of the cash flow statement and under the caption “Management’s Discussion and Analysis of Financial Condition and Results of Operations—Liquidity and Capital Resources” in our most recent Quarterly Report on Form 10-Q and Annual Report on Form 10-K and by presenting cash flows from investing and financing activities in our reconciliation of free cash flow. In addition, it is important to note that other companies, including companies in our industry, may not use free cash flow, may calculate free cash flow in a different manner than we do or may use other financial measures to evaluate their performance, all of which could reduce the usefulness of free cash flow as a comparative measure.

[0001262039-25-000025:8k_2_02:80]
Non-GAAP operating income and operating margin. We define non-GAAP operating income as operating income plus stock-based compensation, amortization of acquired intangible assets, less gain on intellectual property matters and, when applicable, other significant non-recurring items in a given quarter. Non-GAAP operating margin is defined as non-GAAP operating income divided by GAAP revenue. We consider these non-GAAP financial measures to be useful metrics for management and investors because they exclude the items noted above so that our management and investors can compare our recurring core business operating results over multiple periods. There are a number of

[0001262039-25-000025:8k_2_02:81]
limitations related to the use of non-GAAP operating income instead of operating income calculated in accordance with GAAP. First, non-GAAP operating income excludes the items noted above. Second, the components of the costs that we exclude from our calculation of non-GAAP operating income may differ from the components that peer companies exclude when they report their non-GAAP results of operations. Management accounts for these limitations by providing specific information regarding the GAAP amounts excluded from non-GAAP operating income and evaluating non-GAAP operating income together with operating income calculated in accordance with GAAP.

[0001262039-25-000025:8k_2_02:82]
Non-GAAP net income and diluted net income per share. We define non-GAAP net income as net income plus the items noted above under non-GAAP operating income and operating margin. In addition, we adjust non-GAAP net income and diluted net income per share for a non-cash charge of impairment on an equity method investment and a tax adjustment required for an effective tax rate on a non-GAAP basis, which differs from the GAAP effective tax rate. We define non-GAAP diluted net income per share as non-GAAP net income divided by the non-GAAP diluted weighted-average shares outstanding. We consider these non-GAAP financial measures to be useful metrics for management and investors for the same reasons that we use non-GAAP operating income and non-GAAP operating margin. However, in order to provide a more complete picture of our recurring core business operating results, we include in non-GAAP net income and non-GAAP diluted net income per share, the tax adjustment required resulting in an effective tax rate on a non-GAAP basis, which often differs from the GAAP tax rate. We believe the non-GAAP effective tax rates we use are reasonable estimates of normalized tax rates for our current and prior fiscal years under our global operating structure. The same limitations described above regarding our use of non-GAAP operating income and non-GAAP operating margin apply to our use of non-GAAP net income and non-GAAP diluted net income per share. We account for these limitations by providing specific information regarding the GAAP amounts excluded from non-GAAP net income and non-GAAP diluted net income per share and evaluating non-GAAP net income and non-GAAP diluted net income per share together with net income and diluted net income per share calculated in accordance with GAAP.

[0001262039-25-000025:8k_2_02:83]
#          #          #

[0001262039-25-000025:8k_2_02:84]
Copyright © 2025 Fortinet, Inc. All rights reserved. The symbols ® and ™ denote respectively federally registered trademarks and common law trademarks of Fortinet, Inc., its subsidiaries and affiliates. Fortinet’s trademarks include, but are not limited to, the following: Fortinet, the Fortinet logo, FortiGate, FortiOS, FortiGuard, FortiCare, FortiAnalyzer, FortiManager, FortiASIC, FortiClient, FortiCloud, FortiCore, FortiMail, FortiSandbox, FortiADC, FortiAgent, FortiAI, FortiAIOps, FortiAntenna, FortiAP, FortiAPCam, FortiAppSec, FortiAuthenticator, FortiBranchSASE, FortiCall, FortiCam, FortiCamera, FortiCarrier, FortiCART, FortiCASB, FortiCentral, FortiCNP, FortiConnect, FortiController, FortiConverter, FortiCSPM, FortiCWP, FortiDAST, FortiDATA, FortiDB, FortiDDoS, FortiDeceptor, FortiDeploy, FortiDevice, FortiDevSec, FortiDLP, FortiEdge, FortiEDR, FortiEndpoint, FortiExplorer, FortiExtender, FortiFirewall, FortiFlex, FortiFone, FortiGSLB, FortiGuest, FortiHypervisor, FortiInsight, FortiIsolator, FortiLAN, FortiLink, FortiMonitor, FortiNAC, FortiNDR, FortiPAM, FortiPenTest, FortiPhish, FortiPoint, FortiPoints, FortiPolicy, FortiPortal, FortiPresence, FortiProxy, FortiRecon, FortiRecorder, FortiSASE, FortiScanner, FortiSDNConnector, FortiSEC, FortiSIEM, FortiSMS, FortiSOAR, FortiSRA, FortiStack, FortiSwitch, FortiTelemetry, FortiTester, FortiToken, FortiTrust, FortiVoice, FortiWAN, FortiWeb, FortiWiFi, FortiWLC, FortiWLM, FortiXDR, Lacework FortiCNAPP, Linksys, Intelligent Mesh, Velop, Max-Stream, Performance Perfected and SECURITY FABRIC. Other trademarks belong to their respective owners. Fortinet has not independently verified statements or certifications herein attributed to third parties and Fortinet does not independently endorse such statements. Notwithstanding anything to the contrary herein, nothing herein constitutes a warranty, guarantee, contract, binding specification or other binding commitment by Fortinet or any indication of intent related to a binding commitment, and performance and other specification information herein may be unique to certain environments.

[0001262039-25-000025:8k_2_02:85]
FTNT-F

[0001262039-25-000025:8k_2_02:86]
GARTNER is a registered trademark and service mark of Gartner, Inc. and/or its affiliates in the U.S. and internationally, Magic Quadrant is a registered trademark of Gartner, Inc. and/or its affiliates and is used herein with permission. All rights reserved.

[0001262039-25-000025:8k_2_02:87]
Gartner does not endorse any vendor, product, or service depicted in its research publications, and does not advise technology users to select only those vendors with the highest ratings or other designation. Gartner research publications consist of the opinions of Gartner’s research organization and should not be construed as statements of fact. Gartner disclaims all warranties, expressed or implied, with respect to this research, including any warranties of merchantability or fitness for a particular purpose.

[0001262039-25-000025:8k_2_02:88]
Note for Gartner Peer Insights™: Reviews from vendor partners or end users of companies with less than $50 million in revenue are excluded from this methodology. See the full “Voice of the Customer” methodology.

[0001262039-25-000025:8k_2_02:89]
Gartner and Peer Insights are trademarks of Gartner, Inc. and/or its affiliates. All rights reserved. Gartner Peer Insights content consists of the opinions of individual end users based on their own experiences, and should not be construed as statements of fact, nor do they represent the views of Gartner or its affiliates. Gartner does not endorse any vendor, product or service depicted in this content nor makes any warranties, expressed or implied, with respect to this content, about its accuracy or completeness, including any warranties of merchantability or fitness for a particular purpose.

[0001262039-25-000025:8k_2_02:90]
Gartner, Magic Quadrant for SASE Platforms, By Jonathan Forest, Neil MacDonald, Dale Koeppen, 09 July 2025

[0001262039-25-000025:8k_2_02:91]
Gartner, Critical Capabilities for SASE Platforms, By Jonathan Forest, John Watts, Andrew Lerner, Charlie Winckless, 14 July 2025

[0001262039-25-000025:8k_2_02:92]
Gartner, Magic Quadrant for Enterprise Wired and Wireless LAN Infrastructure, By Mike Leibovitz, Christian Canales, Nauman Raja, Tim Zimmerman, 25 June 2025

[0001262039-25-000025:8k_2_02:93]
Gartner, Gartner Peer Insights™ ‘Voice of the Customer’: SD-WAN, Peer Contributors, 2025, 2024, & 2023

[0001262039-25-000025:8k_2_02:94]
Gartner, Gartner Peer Insights™ ‘Voice of the Customer’: Endpoint Protection Platform, Peer Contributors, 2025, 2024, & 2023

[0001262039-25-000025:8k_2_02:95]
| Investor Contact: |  | Media Contact: |
| Aaron Ovadia |  | Stephanie Lira |
| Fortinet, Inc. |  | Fortinet, Inc. |
| 408-235-7700 |  | 408-235-7700 |
| investors@fortinet.com |  | pr@fortinet.com |
