# FTNT MD&A — 0001262039-25-000028


## mdna

[0001262039-25-000028:mdna:1]
[same as prior period, unchanged from 0001262039-25-000017:mdna:1]

[0001262039-25-000028:mdna:2]
[same as prior period, unchanged from 0001262039-25-000017:mdna:2]

[0001262039-25-000028:mdna:3]
[same as prior period, unchanged from 0001262039-25-000017:mdna:3]

[0001262039-25-000028:mdna:4]
[same as prior period, unchanged from 0001262039-25-000017:mdna:4]

[0001262039-25-000028:mdna:5]
[same as prior period, unchanged from 0001262039-25-000017:mdna:5]

[0001262039-25-000028:mdna:6]
[same as prior period, unchanged from 0001262039-25-000017:mdna:6]

[0001262039-25-000028:mdna:7]
[same as prior period, unchanged from 0001262039-25-000017:mdna:7]

[0001262039-25-000028:mdna:8]
[same as prior period, unchanged from 0001262039-25-000017:mdna:8]

[0001262039-25-000028:mdna:9]
•drivers of long-term growth and operating leverage, such as pricing of our products and services, sales productivity, pipeline and capacity, functionality, value and technology improvements in our product and service offerings;

[0001262039-25-000028:mdna:10]
[same as prior period, unchanged from 0001262039-25-000017:mdna:10]

[0001262039-25-000028:mdna:11]
[same as prior period, unchanged from 0001262039-25-000017:mdna:11]

[0001262039-25-000028:mdna:12]
[same as prior period, unchanged from 0001262039-25-000017:mdna:12]

[0001262039-25-000028:mdna:13]
[same as prior period, unchanged from 0001262039-25-000017:mdna:13]

[0001262039-25-000028:mdna:14]
[same as prior period, unchanged from 0001262039-25-000017:mdna:14]

[0001262039-25-000028:mdna:15]
[same as prior period, unchanged from 0001262039-25-000017:mdna:15]

[0001262039-25-000028:mdna:16]
[same as prior period, unchanged from 0001262039-25-000017:mdna:16]

[0001262039-25-000028:mdna:17]
[same as prior period, unchanged from 0001262039-25-000017:mdna:17]

[0001262039-25-000028:mdna:18]
[same as prior period, unchanged from 0001262039-25-000017:mdna:18]

[0001262039-25-000028:mdna:19]
[same as prior period, unchanged from 0001262039-25-000017:mdna:19]

[0001262039-25-000028:mdna:20]
[same as prior period, unchanged from 0001262039-25-000017:mdna:20]

[0001262039-25-000028:mdna:21]
•expectations regarding our gross margins and operating expenses for 2025;

[0001262039-25-000028:mdna:22]
[same as prior period, unchanged from 0001262039-25-000017:mdna:22]

[0001262039-25-000028:mdna:23]
[same as prior period, unchanged from 0001262039-25-000017:mdna:23]

[0001262039-25-000028:mdna:24]
[same as prior period, unchanged from 0001262039-25-000017:mdna:24]

[0001262039-25-000028:mdna:25]
[same as prior period, unchanged from 0001262039-25-000017:mdna:25]

[0001262039-25-000028:mdna:26]
[same as prior period, unchanged from 0001262039-25-000017:mdna:26]

[0001262039-25-000028:mdna:27]
•expected outcomes and liabilities in litigation;

[0001262039-25-000028:mdna:28]
[same as prior period, unchanged from 0001262039-25-000017:mdna:28]

[0001262039-25-000028:mdna:29]
[same as prior period, unchanged from 0001262039-25-000017:mdna:29]

[0001262039-25-000028:mdna:30]
[same as prior period, unchanged from 0001262039-25-000017:mdna:30]

[0001262039-25-000028:mdna:31]
[same as prior period, unchanged from 0001262039-25-000017:mdna:31]

[0001262039-25-000028:mdna:32]
Fortinet is a leader in cybersecurity, driving the convergence of networking and security. Our mission is to secure people, devices and data everywhere. Our integrated platform, the Fortinet Security Fabric, spans secure networking, unified SASE and AI-driven security operations (“SecOps”). As of June 30, 2025, our end-customers were located in over 100 countries and included enterprises across a wide variety of market verticals, including financial services, retail, healthcare and operational technology (“OT”) market verticals, communication and security service providers, and government organizations. As a global company headquartered in Sunnyvale, California, our research and development is centered in the United States and Canada with a global footprint of support and centers of excellence around the world. As of June 30, 2025, we held 1,067 U.S. patents and 1,401 global patents, including 288 AI-related patents. We have been recognized in over 140 enterprise analyst reports demonstrating both our vision and execution across security and networking products.

[0001262039-25-000028:mdna:33]
[same as prior period, unchanged from 0001262039-25-000017:mdna:33]

[0001262039-25-000028:mdna:34]
•FortiOS—FortiOS enables the convergence of security and networking to enforce consistent security policies across form factors and edges. As the foundation of the Fortinet Security Fabric, FortiOS empowers organizations to unify management and analytics for comprehensive network visibility and control at scale. To further validate our strategy, FortiOS has been recognized across five Gartner Magic Quadrants, including Firewall, Software-Defined Wide-Area

[0001262039-25-000028:mdna:35]
Network (“SD-WAN”), Security Service Edge (“SSE”), SASE Platforms and Wired and Wireless Local Area Network (“LAN”).

[0001262039-25-000028:mdna:36]
[same as prior period, unchanged from 0001262039-25-000017:mdna:36]

[0001262039-25-000028:mdna:37]
[same as prior period, unchanged from 0001262039-25-000017:mdna:37]

[0001262039-25-000028:mdna:38]
[same as prior period, unchanged from 0001262039-25-000017:mdna:38]

[0001262039-25-000028:mdna:39]
[same as prior period, unchanged from 0001262039-25-000017:mdna:39]

[0001262039-25-000028:mdna:40]
[same as prior period, unchanged from 0001262039-25-000017:mdna:40]

[0001262039-25-000028:mdna:41]
[same as prior period, unchanged from 0001262039-25-000017:mdna:41]

[0001262039-25-000028:mdna:42]
[same as prior period, unchanged from 0001262039-25-000017:mdna:42]

[0001262039-25-000028:mdna:43]
•Unified Secure Access Service Edge (SASE)—As applications move to the cloud and hybrid workforce is now the norm, enabling secure access for users with zero trust framework becomes important. The Fortinet Unified SASE solution includes a single-vendor SASE solution that includes firewall, SD-WAN, secure web gateway, cloud access services broker, DLP and zero trust network access to deliver flexible secure access for all users. We are one of the few vendors to deliver consistent convergence and AI-powered security across Secure SD-WAN and SSE to enable a single-vendor SASE framework with a cloud-centric architecture powered by FortiOS. Our global and scalable cloud network includes over 150 PoPs to deliver the seamless secure access experience. Given this, we believe we are well positioned to support customers expanding from SD-WAN to a single-vendor SASE platform. Additionally, we offer a full suite of comprehensive, integrated cloud security solutions that enable customers to secure their applications from code to cloud. Our solutions include application security that includes our web application firewalls, cloud network security with virtualized firewalls and cloud-native firewalls, cloud-native application protection and code security. We deliver a holistic approach to cloud security, offering a single unified platform, consolidating protection across multiple disparate tools, including coding, deploying, and running applications across hybrid and multi-clouds. Additionally, we also offer flexible consumption licensing programs that enable organizations to dynamically optimize

[0001262039-25-000028:mdna:44]
their cloud security needs and investments as well as readily meet their cloud minimum spend commitment obligations with Cloud Service Providers.

[0001262039-25-000028:mdna:45]
•AI-Driven Security Operations (SecOps)—Our AI-Driven SecOps portfolio provides a comprehensive suite of cybersecurity solutions that identify, protect, detect, respond and recover from threats, all integrated within the Fortinet Security Fabric. At the core is FortiAnalyzer, which serves as the central SOC platform with its unified data lake that provides built-in Security information and event management (“SIEM”), Security, orchestration, automation, and response (“SOAR”), XDR and threat intelligence, enabling centralized visibility, analytics and automation with complete control. FortiSIEM delivers robust security information and event management for more advanced SOC requirements, while FortiSOAR enables automated orchestration and playbook-driven response. This solution set also includes FortiEDR, FortiXDR, FortiNDR, FortiSandbox, FortiDeceptor, FortiDLP and FortiRecon, helping organizations achieve defense in depth, ensuring attackers face multiple layers of detection and mitigation across endpoints, networks, and applications. To bolster their security posture, organizations contending with staff shortages can tap into FortiGuard services, including SOC-as-a-Service, Managed detection and response, Security Posture Assessment and Incident Response. Finally, FortiAI generative AI assistance streamlines operations, helping security teams stay ahead of an ever-evolving threat landscape.

[0001262039-25-000028:mdna:46]
FortiGuard Labs is our cybersecurity threat intelligence and research organization comprised of experienced threat hunters, researchers, analysts, engineers and data scientists who develop and utilize Machine Learning (“ML”) and AI technologies to provide timely protection updates and actionable threat intelligence for the benefit of our customers. Using millions of global network sensors, FortiGuard Labs monitors the worldwide attack surface and employs AI to mine that data for new threats.

[0001262039-25-000028:mdna:47]
[same as prior period, unchanged from 0001262039-25-000017:mdna:47]

[0001262039-25-000028:mdna:48]
[same as prior period, unchanged from 0001262039-25-000017:mdna:48]

[0001262039-25-000028:mdna:49]
[same as prior period, unchanged from 0001262039-25-000017:mdna:49]

[0001262039-25-000028:mdna:50]
Additionally, we are committed to addressing the cybersecurity skills shortage through training and certification programs for customers, partners and employees. The Fortinet Training Institute’s ecosystem of public and private partnerships around the world extend to industry, academia, government and nonprofits to ensure we are reaching and increasing access of our cybersecurity certifications and training to all populations. The Fortinet Training Institute has issued approximately two million certifications to date.

[0001262039-25-000028:mdna:51]
[same as prior period, unchanged from 0001262039-25-000017:mdna:51]

[0001262039-25-000028:mdna:52]
•Total revenue was $1.63 billion and $3.17 billion during the three and six months ended June 30, 2025, an increase of 14% in each period, compared to $1.43 billion and $2.79 billion in the same periods last year. Product revenue was $508.9 million and $968.0 million during the three and six months ended June 30, 2025, an increase of 13% and 12%, respectively, compared to $451.9 million and $860.8 million in the same periods last year. Service revenue was $1.12 billion and $2.20 billion during the three and six months ended June 30, 2025, an increase of 14% in each period, compared to $982.4 million and $1.93 billion in the same periods last year.

[0001262039-25-000028:mdna:53]
•Total gross profit was $1.32 billion and $2.56 billion during the three and six months ended June 30, 2025, an increase of 13% and 16%, respectively, compared to $1.16 billion and $2.21 billion in the same periods last year.

[0001262039-25-000028:mdna:54]
•Total gross margin was 80.7% and 80.8% during the three and six months ended June 30, 2025, a decrease of 0.1 percentage points and an increase of 1.6 percentage points, respectively, compared to 80.8% and 79.2% in the same periods last year.

[0001262039-25-000028:mdna:55]
[same as prior period, unchanged from 0001262039-25-000017:mdna:85]

[0001262039-25-000028:mdna:56]
•Operating income was $458.0 million and $911.8 million and during the three and six months ended June 30, 2025, an increase of 5% and 20%, respectively, compared to $437.2 million and $758.4 million in the same periods last year.

[0001262039-25-000028:mdna:57]
•Operating margin was 28.1% and 28.8% during the three and six months ended June 30, 2025, a decrease of 2.4 percentage points and an increase of 1.6 percentage points, respectively, compared to 30.5% and 27.2% in the same periods last year.

[0001262039-25-000028:mdna:58]
•Cash, cash equivalents, short-term and long-term investments were $4.67 billion as of June 30, 2025.

[0001262039-25-000028:mdna:59]
•Deferred revenue was $6.57 billion, including short-term deferred revenue of $3.41 billion, as of June 30, 2025.

[0001262039-25-000028:mdna:60]
•Cash flows from operating activities were $1.32 billion during the six months ended June 30, 2025, an increase of $142.8 million, or 12%, compared to the same period last year.

[0001262039-25-000028:mdna:61]
Revenue continues to be diversified globally, which remains a key strength of our business. During the three months ended June 30, 2025, the EMEA region, the Americas region and the APAC region contributed 41%, 40% and 19% of our total revenue, respectively, and increased 18%, 11% and 11% compared to the same period last year, respectively. During the six months ended June 30, 2025, EMEA, the Americas and APAC regions contributed 41%, 41% and 18% of our total revenue, respectively, and increased by 17%, 12% and 10% compared to the same period last year, respectively.

[0001262039-25-000028:mdna:62]
Product revenue increased 13% and 12% during the three and six months ended June 30, 2025, respectively, compared to the same periods last year. We experienced product revenue growth across our hardware products and software licensing, mainly benefited from growth in secure networking hardware products and term licenses. We expect our product revenue to continue to grow for the remainder of 2025.

[0001262039-25-000028:mdna:63]
Service revenue growth during the three and six months ended June 30, 2025 was 14% in each period, as compared to the same periods last year, primarily driven by the strength of our security subscription revenue, which grew 15% and 16%, respectively. The increase was primarily due to the recognition of service revenue from our growing deferred revenue balance related to FortiGuard and other security subscriptions delivered to on-premise and cloud-based environments and strength in unified SASE and SecOps. We expect our service revenue to continue to grow for the remainder of 2025, with growth opportunities that include unified SASE and SecOps offerings as well as the year over year increase in current deferred revenue.

[0001262039-25-000028:mdna:64]
Our billings were diversified on a geographic basis. During the three months ended June 30, 2025, seven countries represented approximately 50% of our billings and the remaining approximately 50% in the aggregate were from over 100 countries that each individually contributed less than 3% of our billings.

[0001262039-25-000028:mdna:65]
Total gross margin decreased 0.1 percentage points during the three months ended June 30, 2025 compared to the same period last year, primarily driven by increased cloud service costs, partially offset by the benefit from normalized inventory related reserves expense in comparison to elevated levels we saw in the same period in 2024. Total gross margin increased 1.6 percentage points during the six months ended June 30, 2025 compared to the same period last year, primarily driven by increased product gross margin benefiting from lower impact of inventory reserves expense in comparison to the first half of 2024. Our overall gross margin for the full year of 2025 will be impacted by service and product revenue mix and their respective gross margins. We do not expect our product gross margin to significantly change for the full year 2025 as compared to 2024. We expect our service gross margin to decrease for the full year of 2025 compared to 2024, as we expand our data center footprint and colocation and cloud hosting capacity to support the growth in our unified SASE and SecOps offerings. We currently do not expect the U.S. tariffs to have a meaningful impact on our gross margin. If tariffs increase in the future, we expect any resulting impact on our gross margin to mostly be on our hardware sales to U.S. customers.

[0001262039-25-000028:mdna:66]
Operating expenses as a percentage of revenue increased 2.3 and 0.1 percentage points during the three and six months ended June 30, 2025, respectively, compared to the same periods last year, mainly driven by an increase in personnel-related costs in research and development and sales and marketing. Headcount increased to 14,898 employees as of June 30, 2025, a 10% increase compared to 13,527 as of June 30, 2024.

[0001262039-25-000028:mdna:67]
Operating margin decreased 2.4 percentage points during the three months ended June 30, 2025, as a result of increase in operating expenses as a percentage of revenue and decreased gross margin. Operating margin increased 1.6 percentage points during the six months ended June 30, 2025, as a result of improvement in gross margin. We expect our operating margin to decrease for the full year of 2025 compared to 2024 as we grow our sales and marketing and research and development workforce organically and through acquisitions, increase our product development investments, and expand our data center footprint and our colocation and cloud hosting capacity to support business growth. In addition, we expect higher operating

[0001262039-25-000028:mdna:68]
32

[0001262039-25-000028:mdna:69]
expenses driven in part by the weakening of the U.S. dollar compared to foreign currencies, as a portion of our expenses are incurred and paid in currencies other than the U.S. dollar.

[0001262039-25-000028:mdna:70]
[same as prior period, unchanged from 0001262039-25-000017:mdna:67]

[0001262039-25-000028:mdna:71]
Our overall performance depends in part on worldwide economic and geopolitical conditions, such as trade policies and tariffs, GDP growth or contraction (both domestically and internationally), geopolitical instability and uncertainty, the war in Ukraine or tensions between China and Taiwan, and their impact on customer behavior. Worsening economic conditions, including tariffs, inflation, changing interest rates and other trade disruptions, slower growth, any recession, fluctuations in foreign exchange rates and other changes in economic conditions, may result in decreased sales productivity, lower growth and adversely affect our results of operations and financial performance. We have seen, and could continue to see, certain impacts on our business, results of operations, financial condition, cash flows, liquidity and capital and financial resources such as longer sales cycles, delayed purchases and increased commitments with certain suppliers and increased inventory and inventory purchase commitment reserves. For example, earlier this year the United States announced tariffs on imported goods from most countries, some of which have been temporarily suspended or adjusted from time to time. U.S. tariffs, and any new or additional retaliatory tariffs that could be imposed by other countries in response to such U.S. tariffs could have a material adverse impact on global trade, supply chains worldwide, and other worldwide economic and geopolitical conditions, which could increase our product costs for the remainder of 2025 and beyond, and also affect customer sentiment in deciding whether to purchase our products. We continue to monitor the impact of tariffs on our business.

[0001262039-25-000028:mdna:72]
[same as prior period, unchanged from 0001262039-25-000017:mdna:70]

[0001262039-25-000028:mdna:73]
[same as prior period, unchanged from 0001262039-25-000017:mdna:71]

[0001262039-25-000028:mdna:74]
[same as prior period, unchanged from 0001262039-25-000017:mdna:72]

[0001262039-25-000028:mdna:75]
[same as prior period, unchanged from 0001262039-25-000017:mdna:73]

[0001262039-25-000028:mdna:76]
[same as prior period, unchanged from 0001262039-25-000017:mdna:74]

[0001262039-25-000028:mdna:77]
[same as prior period, unchanged from 0001262039-25-000017:mdna:75]

[0001262039-25-000028:mdna:78]
We monitor several key metrics, including the key financial metrics set forth below, in order to help us evaluate growth trends, establish budgets, measure the effectiveness of our sales and marketing efforts, and assess operational efficiencies. The following table summarizes revenue, deferred revenue, billings (non-GAAP), net cash provided by operating activities, and free cash flow (non-GAAP). We discuss revenue below under “Results of Operations,” and we discuss net cash

[0001262039-25-000028:mdna:79]
provided by operating activities below under “—Liquidity and Capital Resources.” Deferred revenue, billings (non-GAAP), and free cash flow (non-GAAP) are discussed immediately below the following table:

[0001262039-25-000028:mdna:80]
|  | Three Months Ended Or As Of |
|  | June 30, 2025 |  | June 30, 2024 |
|  | (in millions) |
| Revenue | $ | 1,630.0 |  |  | $ | 1,434.3 |  |
| Deferred revenue | $ | 6,567.6 |  |  | $ | 5,896.2 |  |
| Billings (non-GAAP) | $ | 1,778.4 |  |  | $ | 1,540.6 |  |
| Net cash provided by operating activities | $ | 451.9 |  |  | $ | 342.0 |  |
| Free cash flow (non-GAAP) | $ | 284.1 |  |  | $ | 318.9 |  |

[0001262039-25-000028:mdna:81]
Deferred revenue. Our deferred revenue consists of amounts that have been invoiced but that have not yet been recognized as revenue. The majority of our deferred revenue balance consists of the unrecognized portion of service revenue from FortiGuard and other security subscriptions and FortiCare technical support service contracts, which is recognized as revenue ratably over the service term. We monitor our deferred revenue balance, short-term and total deferred revenue growth and the mix of short-term and long-term deferred revenue because deferred revenue represents a significant portion of free cash flow and of revenue to be recognized in future periods. Deferred revenue was $6.57 billion as of June 30, 2025, an increase of $206.7 million, or 3%, from December 31, 2024. Short-term deferred revenue was $3.41 billion as of June 30, 2025, an increase of $136.3 million, or 4%, from December 31, 2024.

[0001262039-25-000028:mdna:82]
Billings (non-GAAP). We define billings as revenue recognized in accordance with GAAP plus the change in deferred revenue from the beginning to the end of the period less any deferred revenue balances acquired from business combination(s) during the period. We consider billings to be a useful metric for management and investors because billings drive current and future revenue, which is an important indicator of the health and viability of our business and cash flows. There are a number of limitations related to the use of billings instead of GAAP revenue. First, billings include amounts that have not yet been recognized as revenue and are impacted by the term of security and support agreements. Second, we may calculate billings in a manner that is different from peer companies that report similar financial measures. Management accounts for these limitations by providing specific information regarding GAAP revenue and evaluating billings together with GAAP revenue. Total billings were $1.78 billion for the three months ended June 30, 2025, an increase of 15% compared to $1.54 billion in the same period last year.

[0001262039-25-000028:mdna:83]
[same as prior period, unchanged from 0001262039-25-000017:mdna:81]

[0001262039-25-000028:mdna:84]
[same as prior period, unchanged from 0001262039-25-000017:mdna:82]

[0001262039-25-000028:mdna:85]
|  | Three Months Ended |
|  | June 30, 2025 |  | June 30, 2024 |
|  | (in millions) |
| Billings: |  |  |  |
| Revenue | $ | 1,630.0 |  |  | $ | 1,434.3 |  |
| Add: Change in deferred revenue | 149.2 |  |  | 106.3 |  |
| Less: Deferred revenue balance acquired in business combinations | (0.8) |  |  | — |  |
| Total billings (non-GAAP) | $ | 1,778.4 |  |  | $ | 1,540.6 |  |

[0001262039-25-000028:mdna:86]
Free cash flow (non-GAAP). We define free cash flow as net cash provided by operating activities minus purchases of property and equipment and excluding any significant non-recurring items, such as proceeds from IP matters. We believe free cash flow to be a liquidity measure that provides useful information to management and investors about the amount of cash generated by the business that, after capital expenditures and net of proceeds from IP matters, can be used for strategic opportunities, including repurchasing outstanding common stock, investing in our business, making strategic acquisitions and strengthening the balance sheet. A limitation of using free cash flow rather than the GAAP measures of cash provided by or used in operating activities, investing activities, and financing activities is that free cash flow does not represent the total increase or decrease in the cash and cash equivalents balance for the period because it excludes cash flows from significant non-recurring items, such as proceeds from IP matters, investing activities other than capital expenditures and cash flows from

[0001262039-25-000028:mdna:87]
financing activities. Management accounts for this limitation by providing information about our proceeds from IP matters, our capital expenditures and other investing and financing activities on the condensed consolidated statements of cash flows and under “—Liquidity and Capital Resources” and by presenting cash flows from investing and financing activities in our reconciliation of free cash flow. In addition, it is important to note that other companies, including companies in our industry, may not use free cash flow, may calculate free cash flow in a different manner than we do or may use other financial measures to evaluate their performance, all of which could reduce the usefulness of free cash flow as a comparative measure. A reconciliation of net cash provided by operating activities, the most directly comparable financial measure calculated and presented in accordance with GAAP, to free cash flow is provided below:

[0001262039-25-000028:mdna:88]
|  | Three Months Ended |
|  | June 30, 2025 |  | June 30, 2024 |
|  | (in millions) |
| Free Cash Flow: |  |  |  |
| Net cash provided by operating activities | $ | 451.9 |  |  | $ | 342.0 |  |
| Less: Purchases of property and equipment | (167.8) |  |  | (23.1) |  |
| Free cash flow (non-GAAP) | $ | 284.1 |  |  | $ | 318.9 |  |
| Net cash used in investing activities | $ | (266.2) |  |  | $ | (50.1) |  |
| Net cash used in financing activities | $ | (414.2) |  |  | $ | (14.0) |  |

[0001262039-25-000028:mdna:89]
[same as prior period, unchanged from 0001262039-25-000017:mdna:87]

[0001262039-25-000028:mdna:90]
[same as prior period, unchanged from 0001262039-25-000017:mdna:88]

[0001262039-25-000028:mdna:91]
There were no material changes to our critical accounting policies and estimates as of and for the six months ended June 30, 2025, as compared to the critical accounting policies and estimates described in our Annual Report on Form 10-K filed with the SEC on February 21, 2025 (the “Form 10-K”).

[0001262039-25-000028:mdna:92]
[same as prior period, unchanged from 0001262039-25-000017:mdna:90]

[0001262039-25-000028:mdna:93]
[same as prior period, unchanged from 0001262039-25-000017:mdna:124]

[0001262039-25-000028:mdna:94]
[same as prior period, unchanged from 0001262039-25-000017:mdna:91]

[0001262039-25-000028:mdna:95]
Three Months Ended June 30, 2025 and 2024

[0001262039-25-000028:mdna:96]
[same as prior period, unchanged from 0001262039-25-000017:mdna:93]

[0001262039-25-000028:mdna:97]
|  | Three Months Ended |  |  |  |  |
| June 30,2025 |  | June 30,2024 |  |  |  |  |
| Amount |  | % ofRevenue |  | Amount |  | % ofRevenue |  | Change |  | % Change |
| (in millions, except percentages) |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 508.9 |  |  | 31 | % |  | $ | 451.9 |  |  | 32 | % |  | $ | 57.0 |  |  | 13 | % |
| Service | 1,121.1 |  |  | 69 |  |  | 982.4 |  |  | 68 |  |  | 138.7 |  |  | 14 |  |
| Total revenue | $ | 1,630.0 |  |  | 100 | % |  | $ | 1,434.3 |  |  | 100 | % |  | $ | 195.7 |  |  | 14 | % |
| Revenue by geography: |  |  |  |  |  |  |  |  |  |  |  |
| Americas | $ | 658.8 |  |  | 40 | % |  | $ | 595.3 |  |  | 42 | % |  | $ | 63.5 |  |  | 11 | % |
| EMEA | 667.1 |  |  | 41 |  |  | 565.2 |  |  | 39 |  |  | 101.9 |  |  | 18 |  |
| APAC | 304.1 |  |  | 19 |  |  | 273.8 |  |  | 19 |  |  | 30.3 |  |  | 11 |  |
| Total revenue | $ | 1,630.0 |  |  | 100 | % |  | $ | 1,434.3 |  |  | 100 | % |  | $ | 195.7 |  |  | 14 | % |

[0001262039-25-000028:mdna:98]
Total revenue increased $195.7 million, or 14%, during the three months ended June 30, 2025 compared to the same period last year. We continued to experience diversification of revenue geographically, and across customer and industry verticals. Revenue from all regions grew, with EMEA contributing the largest portion of the increase on an absolute dollar basis and on a percentage basis.

[0001262039-25-000028:mdna:99]
Product revenue increased $57.0 million, or 13%, during the three months ended June 30, 2025 compared to the same period last year. We experienced product revenue growth across our hardware products and software licensing, mainly driven by growth in secure networking hardware products and term licenses.

[0001262039-25-000028:mdna:100]
Service revenue increased $138.7 million, or 14%, during the three months ended June 30, 2025 compared to the same period last year. Security subscription revenue increased $85.7 million, or 15%, and technical support and other services revenue increased $53.0 million, or 13%, during the three months ended June 30, 2025 compared to the same period last year. The increase was primarily due to the recognition of revenue from our growing deferred revenue balance related to FortiGuard and other security subscriptions delivered to on-premise and cloud-based environments and growth in SaaS solutions, including unified SASE and SecOps.

[0001262039-25-000028:mdna:101]
Of the service revenue recognized during the three months ended June 30, 2025, 90% was included in the deferred revenue balance as of March 31, 2025. Of the service revenue recognized during the three months ended June 30, 2024, 90% was included in the deferred revenue balance as of March 31, 2024.

[0001262039-25-000028:mdna:102]
36

[0001262039-25-000028:mdna:103]
[same as prior period, unchanged from 0001262039-25-000017:mdna:99]

[0001262039-25-000028:mdna:104]
|  | Three Months Ended |  |  |  |  |
| June 30,2025 |  | June 30,2024 |  | Change |  | % Change |
| (in millions, except percentages) |
| Cost of revenue: |  |  |  |  |  |  |  |
| Product | $ | 165.9 |  |  | $ | 155.1 |  |  | $ | 10.8 |  |  | 7 | % |
| Service | 149.0 |  |  | 119.9 |  |  | 29.1 |  |  | 24 |  |
| Total cost of revenue | $ | 314.9 |  |  | $ | 275.0 |  |  | $ | 39.9 |  |  | 15 | % |
| Gross margin (%): |  |  |  |  |  |  |  |
| Product | 67.4 | % |  | 65.7 | % |  |  |  |  |
| Service | 86.7 |  |  | 87.8 |  |  |  |  |  |
| Total gross margin | 80.7 | % |  | 80.8 | % |  |  |  |  |

[0001262039-25-000028:mdna:105]
Total gross margin decreased 0.1 percentage points during the three months ended June 30, 2025 compared to the same period last year, primarily driven by decreased service gross margin, partially offset by increased product gross margin.

[0001262039-25-000028:mdna:106]
Product gross margin increased 1.7 percentage points during the three months ended June 30, 2025 compared to the same period last year, as inventory related reserves expense normalized from the elevated levels we saw in the first half of 2024. Cost of product revenue was comprised primarily of third-party contract manufacturers’ costs, and costs of materials used in production.

[0001262039-25-000028:mdna:107]
Service gross margin decreased 1.1 percentage points during the three months ended June 30, 2025 compared to the same period last year, primarily driven by an increase in cloud service costs as a result of our acquisitions and investment in data centers, partially offset by service revenue growth outpacing labor, replacement, and repair costs increase. Cost of service revenue was comprised primarily of personnel-related costs, replacement and repair costs, cloud services costs from data centers, colocation provider and cloud providers, infrastructure, software and delivery costs, and facility-related costs.

[0001262039-25-000028:mdna:108]
[same as prior period, unchanged from 0001262039-25-000017:mdna:104]

[0001262039-25-000028:mdna:109]
|  | Three Months Ended |  | Change |  | % Change |
| June 30,2025 |  | June 30,2024 |  |
| Amount |  | % ofRevenue |  | Amount |  | % ofRevenue |  |
| (in millions, except percentages) |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | $ | 209.5 |  |  | 13 | % |  | $ | 165.4 |  |  | 12 | % |  | $ | 44.1 |  |  | 27 | % |
| Sales and marketing | 592.0 |  |  | 36 |  |  | 501.3 |  |  | 35 |  |  | 90.7 |  |  | 18 |  |
| General and administrative | 56.9 |  |  | 4 |  |  | 56.6 |  |  | 4 |  |  | 0.3 |  |  | 1 |  |
| Gain on intellectual property matters | (1.3) |  |  | — |  |  | (1.2) |  |  | — |  |  | (0.1) |  |  | 8 |  |
| Total operating expenses | $ | 857.1 |  |  | 53 | % |  | $ | 722.1 |  |  | 50 | % |  | $ | 135.0 |  |  | 19 | % |
| Percentages have been rounded for presentation purposes and may differ from unrounded results. |

[0001262039-25-000028:mdna:110]
[same as prior period, unchanged from 0001262039-25-000017:mdna:106]

[0001262039-25-000028:mdna:111]
Research and development expense increased $44.1 million, or 27%, during the three months ended June 30, 2025 compared to the same period last year, primarily due to an increase of $31.3 million in personnel-related costs as a result of increased headcount and compensation rates to support the development of new products and continued enhancements to our existing products and the impact of the recent acquisitions. In addition, non-personnel-related product development costs increased $12.1 million. We currently intend to continue investing in our research and development organization, and expect research and development expense to increase in absolute dollars year over year during the remainder of 2025.

[0001262039-25-000028:mdna:112]
[same as prior period, unchanged from 0001262039-25-000017:mdna:108]

[0001262039-25-000028:mdna:113]
Sales and marketing expense increased $90.7 million, or 18%, during the three months ended June 30, 2025 compared to the same period last year, primarily due to an increase of $71.8 million in personnel-related costs, an increase of $7.0 million in marketing program and related expenses and unfavorable impact of foreign currency fluctuations. We currently intend to continue to make investments in sales and marketing resources, which are critical to support our future growth, and expect our sales and marketing expense to increase in absolute dollars year over year during the remainder of 2025.

[0001262039-25-000028:mdna:114]
[same as prior period, unchanged from 0001262039-25-000017:mdna:110]

[0001262039-25-000028:mdna:115]
General and administrative expense remained flat during the three months ended June 30, 2025 compared to the same period last year. We currently expect general and administrative expense to increase in absolute dollars year over year during the remainder of 2025.

[0001262039-25-000028:mdna:116]
[same as prior period, unchanged from 0001262039-25-000017:mdna:112]

[0001262039-25-000028:mdna:117]
We generated operating income of $458.0 million during the three months ended June 30, 2025, an increase of $20.8 million, or 5%, compared to $437.2 million in the same period last year. Operating margin was 28.1% during the three months ended June 30, 2025, compared to 30.5% in the same period last year. The 2.4 percentage points decrease in operating margin was primarily due to 1.4 and 1.3 percentage points increases in research and development expense and sales and marketing expense as a percentage of revenue, respectively, and 0.1 percentage points decrease in gross margin, partially offset by 0.4 percentage points decrease in general and administrative expense as a percentage of revenue.

[0001262039-25-000028:mdna:118]
[same as prior period, unchanged from 0001262039-25-000017:mdna:114]

[0001262039-25-000028:mdna:119]
|  | Three Months Ended |  |  |  |  |
| June 30,2025 |  | June 30,2024 |  | Change |  | % Change |
| (in millions, except percentages) |
| Interest income | $ | 45.0 |  |  | $ | 38.3 |  |  | $ | 6.7 |  |  | 17 | % |
| Interest expense | $ | (4.6) |  |  | $ | (5.0) |  |  | $ | 0.4 |  |  | (8) | % |
| Other income (expense)—net | $ | 18.9 |  |  | $ | (2.2) |  |  | $ | 21.1 |  |  | (959) | % |

[0001262039-25-000028:mdna:120]
Interest income increased $6.7 million during the three months ended June 30, 2025 compared to the same period last year, primarily as a result of higher investment balances. Interest income varies depending on our average investment balances during the period, types and mix of investments, and interest rates. Interest expense remained comparatively flat during the three months ended June 30, 2025 compared to the same period last year. The $21.1 million change in other income (expense)—net during the three months ended June 30, 2025 compared to the same period last year, was primarily due to a $11.6 million gain on marketable equity securities and a $7.6 million increase in foreign currency exchange gains.

[0001262039-25-000028:mdna:121]
[same as prior period, unchanged from 0001262039-25-000017:mdna:117]

[0001262039-25-000028:mdna:122]
|  | Three Months Ended |  | Change |  | % Change |
| June 30,2025 |  | June 30,2024 |  |
| (in millions, except percentages) |
| Provision for income taxes | $ | 77.1 |  |  | $ | 76.5 |  |  | $ | 0.6 |  |  | 1 | % |
| Effective tax rate (%) | 15 | % |  | 16 | % |  |  |  |  |

[0001262039-25-000028:mdna:123]
Our effective tax rate was 15% for the three months ended June 30, 2025 compared to an effective tax rate of 16% for the same period last year. The provision for income taxes for the three months ended June 30, 2025 was primarily comprised of U.S. federal and state taxes, withholding taxes and foreign taxes totaling $114.6 million, which was favorably affected by a tax benefit of $25.1 million from the foreign-derived intangible income deduction (the “FDII deduction”) and excess tax benefits from stock-based compensation expense of $12.4 million.

[0001262039-25-000028:mdna:124]
The provision for income taxes for the three months ended June 30, 2024 was comprised of U.S. federal and state taxes, withholding taxes, and foreign taxes totaling $109.9 million, which were favorably affected by a tax benefit of $27.2 million from the FDII deduction and excess tax benefits from stock-based compensation expense of $6.2 million.

[0001262039-25-000028:mdna:125]
On July 4, 2025, H.R. 1, the Act, commonly referred to as the One Big Beautiful Bill Act, was enacted. The Act makes permanent certain elements of the Tax Cuts and Jobs Act, including immediate expensing of U.S. research and development expenditures, immediate expensing of certain eligible assets, and various modifications to the international tax framework. We are evaluating the impact of the Act on our consolidated financial statements, but our preliminary analysis indicates that our cash tax payments for 2025 could be reduced by approximately $100 million to $150 million and our GAAP effective tax rate for 2025 could increase by approximately 1 point as a result of the provisions of the Act.

[0001262039-25-000028:mdna:126]
Loss from equity method investments

[0001262039-25-000028:mdna:127]
|  | Three Months Ended |  | Change |  | % Change |
| June 30,2025 |  | June 30,2024 |  |
| (in millions, except percentages) |
| Loss from equity method investments | $ | (0.1) |  |  | $ | (12.0) |  |  | $ | 11.9 |  |  | (99) | % |

[0001262039-25-000028:mdna:128]
Loss from equity method investments decreased $11.9 million during the three months ended June 30, 2025 compared to the same period last year was primarily driven by an $8.0 million other-than-temporary impairment (“OTTI”) charge and a $3.8 million loss due to our proportionate share of Linksys’ financial results including our share of the amortization of the basis differences during the three months ended June 30, 2024.

[0001262039-25-000028:mdna:129]
Six Months Ended June 30, 2025 and 2024

[0001262039-25-000028:mdna:130]
Revenue

[0001262039-25-000028:mdna:131]
|  | Six Months Ended |  |  |  |  |
| June 30,2025 |  | June 30,2024 |  |  |  |  |
| Amount |  | % ofRevenue |  | Amount |  | % ofRevenue |  | Change |  | % Change |
| (in millions, except percentages) |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 968.0 |  |  | 31 | % |  | $ | 860.8 |  |  | 31 | % |  | $ | 107.2 |  |  | 12 | % |
| Service | 2,201.7 |  |  | 69 |  |  | 1,926.8 |  |  | 69 |  |  | 274.9 |  |  | 14 |  |
| Total revenue | $ | 3,169.7 |  |  | 100 | % |  | $ | 2,787.6 |  |  | 100 | % |  | $ | 382.1 |  |  | 14 | % |
| Revenue by geography: |  |  |  |  |  |  |  |  |  |  |  |
| Americas | $ | 1,288.6 |  |  | 41 | % |  | $ | 1,152.3 |  |  | 41 | % |  | $ | 136.3 |  |  | 12 | % |
| EMEA | 1,295.5 |  |  | 41 |  |  | 1,104.6 |  |  | 40 |  |  | 190.9 |  |  | 17 |  |
| APAC | 585.6 |  |  | 18 |  |  | 530.7 |  |  | 19 |  |  | 54.9 |  |  | 10 |  |
| Total revenue | $ | 3,169.7 |  |  | 100 | % |  | $ | 2,787.6 |  |  | 100 | % |  | $ | 382.1 |  |  | 14 | % |

[0001262039-25-000028:mdna:132]
Total revenue increased $382.1 million, or 14%, during the six months ended June 30, 2025 compared to the same period last year. We continued to experience diversification of revenue geographically, and across customer and industry verticals. Revenue from all regions grew, with EMEA contributing the largest portion of the increase on an absolute dollar basis and on a percentage basis.

[0001262039-25-000028:mdna:133]
Product revenue increased $107.2 million, or 12%, during the six months ended June 30, 2025 compared to the same period last year. We experienced product revenue growth across our hardware products and software licensing mainly benefited from growth in secure networking hardware products and term licenses.

[0001262039-25-000028:mdna:134]
Service revenue increased $274.9 million, or 14%, during the six months ended June 30, 2025 compared to the same period last year. Security subscription revenue increased $171.9 million, or 16%, and technical support and other services revenue increased $103.0 million, or 12%, during the six months ended June 30, 2025 compared to the same period last year. The increase was primarily due to the recognition of revenue from our growing deferred revenue balance related to FortiGuard and other security subscriptions delivered to on-premise and cloud-based environments and growth in SaaS solutions, including unified SASE and SecOps.

[0001262039-25-000028:mdna:135]
39

[0001262039-25-000028:mdna:136]
Of the service revenue recognized during the six months ended June 30, 2025, 84% was included in the deferred revenue balance as of December 31, 2024. Of the service revenue recognized during the six months ended June 30, 2024, 84% was included in the deferred revenue balance as of December 31, 2023.

[0001262039-25-000028:mdna:137]
Cost of revenue and gross margin

[0001262039-25-000028:mdna:138]
|  | Six Months Ended |  |  |  |  |
| June 30,2025 |  | June 30,2024 |  | Change |  | % Change |
| (in millions, except percentages) |
| Cost of revenue: |  |  |  |  |  |  |  |
| Product | $ | 315.8 |  |  | $ | 337.9 |  |  | $ | (22.1) |  |  | (7) | % |
| Service | 292.2 |  |  | 241.8 |  |  | 50.4 |  |  | 21 |  |
| Total cost of revenue | $ | 608.0 |  |  | $ | 579.7 |  |  | $ | 28.3 |  |  | 5 | % |
| Gross margin (%): |  |  |  |  |  |  |  |
| Product | 67.4 | % |  | 60.7 | % |  |  |  |  |
| Service | 86.7 |  |  | 87.5 |  |  |  |  |  |
| Total gross margin | 80.8 | % |  | 79.2 | % |  |  |  |  |

[0001262039-25-000028:mdna:139]
Total gross margin increased 1.6 percentage points during the six months ended June 30, 2025 compared to the same period last year, primarily driven by increased product gross margin.

[0001262039-25-000028:mdna:140]
Product gross margin increased 6.7 percentage points during the six months ended June 30, 2025 compared to the same period last year, as inventory related reserves expense normalized from the elevated levels we saw in the first half of 2024. Cost of product revenue was comprised primarily of third-party contract manufacturers’ costs and costs of materials used in production.

[0001262039-25-000028:mdna:141]
Service gross margin decreased 0.8 percentage points during the six months ended June 30, 2025 compared to the same period last year, primarily due to an increase in cloud service costs, partially offset by service revenue growth outpacing labor, replacement, and repair costs increase. Cost of service revenue was comprised primarily of personnel-related costs, replacement and repair costs, cloud services costs from data centers, colocation provider and cloud providers, infrastructure, software and delivery costs, and facility-related costs.

[0001262039-25-000028:mdna:142]
40

[0001262039-25-000028:mdna:143]
Operating expenses

[0001262039-25-000028:mdna:144]
|  | Six Months Ended |  | Change |  | % Change |
| June 30,2025 |  | June 30,2024 |  |
| Amount |  | % ofRevenue |  | Amount |  | % ofRevenue |  |
| (in millions, except percentages) |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | $ | 408.1 |  |  | 13 | % |  | $ | 338.4 |  |  | 12 | % |  | $ | 69.7 |  |  | 21 | % |
| Sales and marketing | 1,134.7 |  |  | 36 |  |  | 1,002.4 |  |  | 36 |  |  | 132.3 |  |  | 13 |  |
| General and administrative | 114.7 |  |  | 4 |  |  | 111.0 |  |  | 4 |  |  | 3.7 |  |  | 3 |  |
| Gain on intellectual property matters | (7.6) |  |  | — |  |  | (2.3) |  |  | — |  |  | (5.3) |  |  | 230 |  |
| Total operating expenses | $ | 1,649.9 |  |  | 52 | % |  | $ | 1,449.5 |  |  | 52 | % |  | $ | 200.4 |  |  | 14 | % |
| Percentages have been rounded for presentation purposes and may differ from unrounded results. |

[0001262039-25-000028:mdna:145]
Research and development

[0001262039-25-000028:mdna:146]
Research and development expense increased $69.7 million, or 21%, during the six months ended June 30, 2025 compared to the same period last year, primarily due to an increase of $52.0 million in personnel-related costs as a result of increased headcount and compensation rates to support the development of new products and continued enhancements to our existing products and the impact of the recent acquisitions. In addition, non-personnel-related product development costs increased $19.3 million.

[0001262039-25-000028:mdna:147]
Sales and marketing

[0001262039-25-000028:mdna:148]
Sales and marketing expense increased $132.3 million, or 13%, during the six months ended June 30, 2025 compared to the same period last year, primarily due to an increase of $100.2 million in personnel-related costs. In addition, marketing program and related expenses increased $12.5 million and amortization expense of certain intangible assets increased $9.2 million.

[0001262039-25-000028:mdna:149]
General and administrative

[0001262039-25-000028:mdna:150]
General and administrative expense increased $3.7 million, or 3%, during the six months ended June 30, 2025 compared to the same period last year, primarily due to an increase of $2.7 million in personnel-related costs and an increase of $1.0 million in subscriptions and other expense.

[0001262039-25-000028:mdna:151]
Operating income and margin

[0001262039-25-000028:mdna:152]
We generated operating income of $911.8 million during the six months ended June 30, 2025, an increase of $153.4 million, or 20%, compared to $758.4 million in the same period last year. Operating margin was 28.8% during the six months ended June 30, 2025, compared to 27.2% in the same period last year. The 1.6 percentage points increase in operating margin was primarily due to 1.6 percentage points increase in gross margin.

[0001262039-25-000028:mdna:153]
Interest income, interest expense and other income (expense)—net

[0001262039-25-000028:mdna:154]
|  | Six Months Ended |  |  |  |  |
| June 30,2025 |  | June 30,2024 |  | Change |  | % Change |
| (in millions, except percentages) |
| Interest income | $ | 89.3 |  |  | $ | 70.5 |  |  | $ | 18.8 |  |  | 27 | % |
| Interest expense | $ | (9.5) |  |  | $ | (10.1) |  |  | $ | 0.6 |  |  | (6) | % |
| Other income (expense)—net | $ | 45.0 |  |  | $ | (5.1) |  |  | $ | 50.1 |  |  | (982) | % |

[0001262039-25-000028:mdna:155]
Interest income increased $18.8 million during the six months ended June 30, 2025 compared to the same period last year, primarily as a result of investment balances. Interest income varies depending on our average investment balances during the period, types and mix of investments, and interest rates. Interest expense remained comparatively flat during the six months

[0001262039-25-000028:mdna:156]
41

[0001262039-25-000028:mdna:157]
ended June 30, 2025 compared to the same period last year. The $50.1 million change in other income (expense)—net during the six months ended June 30, 2025 compared to the same period last year, was primarily due to a gain on bargain purchase of $39.9 million related to our acquisition of Linksys in the first quarter of 2025 and a $12.1 million increase in foreign currency exchange gains.

[0001262039-25-000028:mdna:158]
Provision for income taxes

[0001262039-25-000028:mdna:159]
|  | Six Months Ended |  | Change |  | % Change |
| June 30,2025 |  | June 30,2024 |  |
| (in millions, except percentages) |
| Provision for income taxes | $ | 173.6 |  |  | $ | 116.0 |  |  | $ | 57.6 |  |  | 50 | % |
| Effective tax rate (%) | 17 | % |  | 14 | % |  |  |  |  |

[0001262039-25-000028:mdna:160]
Our effective tax rate was 17% for the six months ended June 30, 2025 compared to an effective tax rate of 14% for the same period last year. The provision for income taxes for the six months ended June 30, 2025 was primarily comprised of U.S. federal and state taxes, withholding taxes and foreign taxes that were $243.2 million and a tax provision of $30.6 million related to the derecognition of deferred tax assets from the business combination with Linksys. This provision for income taxes was favorably affected by a tax benefit of $50.9 million from the FDII deduction, and excess tax benefits from stock-based compensation expense of $49.3 million.

[0001262039-25-000028:mdna:161]
The provision for income taxes for the six months ended June 30, 2024 was comprised of U.S. federal and state taxes, withholding taxes, and foreign taxes that were $191.3 million, which were favorably affected by a tax benefit of $50.8 million from the FDII deduction, and excess tax benefits from stock-based compensation expense of $24.5 million.

[0001262039-25-000028:mdna:162]
[same as prior period, unchanged from 0001262039-25-000017:mdna:121]

[0001262039-25-000028:mdna:163]
|  | Six Months Ended |  | Change |  | % Change |
| June 30,2025 |  | June 30,2024 |  |
| (in millions, except percentages) |
| Gain (loss) from equity method investments | $ | 10.5 |  |  | $ | (18.6) |  |  | $ | 29.1 |  |  | (156) | % |

[0001262039-25-000028:mdna:164]
The $29.1 million change in gain (loss) from equity method investments during the six months ended June 30, 2025 compared to the same period last year was primarily driven by a $10.8 million gain related to our acquisition of Linksys in the first quarter of 2025 and a $10.2 million loss due to our proportionate share of Linksys’ financial results including our share of the amortization of the basis differences and an OTTI charge of $8.0 million during the six months ended June 30, 2024.

[0001262039-25-000028:mdna:165]
42

[0001262039-25-000028:mdna:166]
[same as prior period, unchanged from 0001262039-25-000017:mdna:125]

[0001262039-25-000028:mdna:167]
|  | As of |
|  | June 30,2025 |  | December 31,2024 |
|  | (in millions) |
| Cash and cash equivalents | $ | 3,368.5 |  |  | $ | 2,875.9 |  |
| Short-term investments | 1,194.4 |  |  | 1,190.6 |  |
| Long-term investments | 112.0 |  |  | — |  |
| Total cash, cash equivalents and investments | $ | 4,674.9 |  |  | $ | 4,066.5 |  |
| Working capital | $ | 1,569.2 |  |  | $ | 1,910.8 |  |
|  | Six Months Ended |
|  | June 30,2025 |  | June 30,2024 |
|  | (in millions) |
| Net cash provided by operating activities | $ | 1,315.2 |  |  | $ | 1,172.4 |  |
| Net cash used in investing activities | (377.0) |  |  | (320.4) |  |
| Net cash used in financing activities | (446.9) |  |  | (44.3) |  |
| Effect of exchange rate changes on cash and cash equivalents | 1.3 |  |  | (2.4) |  |
| Net increase in cash and cash equivalents | $ | 492.6 |  |  | $ | 805.3 |  |

[0001262039-25-000028:mdna:168]
Liquidity and capital resources are primarily impacted by our operating activities, as well as real estate purchases, other capital expenditures and business acquisitions, repurchases of our common stock, payment of taxes in connection with the net settlement of equity awards and proceeds from the issuance of common stock and investment grade debt.

[0001262039-25-000028:mdna:169]
[same as prior period, unchanged from 0001262039-25-000017:mdna:128]

[0001262039-25-000028:mdna:170]
In October 2024, our board of directors approved a $1.0 billion increase in the authorized stock repurchase amount under the Repurchase Program and extended the term of the Repurchase Program to February 28, 2026, bringing the aggregate amount authorized to be repurchased to $8.25 billion of our outstanding common stock through February 28, 2026. During the six months ended June 30, 2025, we repurchased 4.6 million shares of common stock under the Repurchase program for an aggregate purchase price of $401.1 million. As of June 30, 2025, approximately $1.63 billion remained available for future share repurchases. Refer to Note 11. Equity Plans and Share Repurchase Program.

[0001262039-25-000028:mdna:171]
We expect to continue to increase our data centers, PoPs, office and warehouse capacity to support growth and the expansion of existing services or introduction of new services. As we purchase new properties, we will work to incorporate these properties into the environmental goals we have established. We estimate capital expenditures to be between approximately $146 million and $196 million in second half of 2025.

[0001262039-25-000028:mdna:172]
We believe that our cash provided by operating activities, together with our existing cash, cash equivalents and investments will be sufficient to meet our anticipated cash needs and do not currently intend to retire our Senior Notes early. Refer to Note 9. Debt in Part I, Item 1 of this Quarterly Report on Form 10-Q for information on the Senior Notes. As of June 30, 2025, the current portion of long-term debt and long-term debt, net of unamortized discount and debt issuance costs, were $995.3 million.

[0001262039-25-000028:mdna:173]
We purchase components of our inventory from certain suppliers and use several independent contract manufacturers to provide manufacturing services for our products. During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, we enter into agreements with contract manufacturers and suppliers that allow them to procure inventory based upon criteria as defined by us or establish the parameters defining our requirements. A significant portion of our reported purchase commitments arising from these agreements consists of firm, non-cancelable and

[0001262039-25-000028:mdna:174]
unconditional commitments. Certain of these inventory purchase commitments with contract manufacturers and suppliers relate to arrangements to secure supply and pricing for certain product components for multi-year periods. In certain instances, these agreements allow us the option to reschedule and adjust our requirements based on our business needs prior to firm orders being placed.

[0001262039-25-000028:mdna:175]
These inventory purchase commitments as of June 30, 2025 totaled $714.4 million, an increase of $123.3 million compared to $591.1 million as of December 31, 2024 due to fulfillment of customer demand as our supply availability improved and our continued efforts to work with contract manufacturers and suppliers to optimize our inventory and purchase commitments position. We record a liability for inventory purchase commitments in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. As of June 30, 2025 and December 31, 2024, the liability for these inventory purchase commitments was $41.9 million and $54.0 million, respectively, and was recorded in accrued liabilities on our condensed consolidated balance sheets.

[0001262039-25-000028:mdna:176]
[same as prior period, unchanged from 0001262039-25-000017:mdna:135]

[0001262039-25-000028:mdna:177]
We also have open purchase orders and contractual obligations in the ordinary course of business for which we have not received goods or services. As of June 30, 2025, we had $102.7 million in other contractual commitments having a remaining term in excess of one year that are non-cancelable.

[0001262039-25-000028:mdna:178]
[same as prior period, unchanged from 0001262039-25-000017:mdna:137]

[0001262039-25-000028:mdna:179]
As of June 30, 2025, our cash, cash equivalents and short-term and long-term investments of $4.67 billion were invested primarily in deposit accounts, commercial paper, corporate debt securities, U.S. government and agency securities, certificates of deposit and term deposits, money market funds and marketable equity securities. It is our investment policy to invest excess cash in a manner that preserves capital, provides liquidity, and generates return without significantly increasing risk. We believe that we have sufficient liquidity to meet our operating requirements for at least the next 12 months and thereafter for the foreseeable future, including our foreseeable future supply obligations, debt repayment, capital expenditures and share repurchases.

[0001262039-25-000028:mdna:180]
The amount of cash, cash equivalents and investments held by our international subsidiaries was $240.1 million as of June 30, 2025 and $207.8 million as of December 31, 2024.

[0001262039-25-000028:mdna:181]
[same as prior period, unchanged from 0001262039-25-000017:mdna:140]

[0001262039-25-000028:mdna:182]
As of June 30, 2025, we did not have any relationships with unconsolidated organizations or financial partnerships, such as structured finance or special purpose entities that would have been established for the purpose of facilitating off-balance sheet arrangements or other contractually narrow or limited purposes.

[0001262039-25-000028:mdna:183]
[same as prior period, unchanged from 0001262039-25-000017:mdna:142]

[0001262039-25-000028:mdna:184]
Cash generated by operating activities is our primary source of liquidity. It is primarily comprised of net income, as adjusted for non-cash items and changes in operating assets and liabilities. Non-cash adjustments consist primarily of amortization of deferred contract costs, stock-based compensation and depreciation and amortization. Changes in operating assets and liabilities consist primarily of changes in accounts receivable—net, deferred revenue, deferred contract costs, inventory, deferred tax assets, accounts payable, and accrued liabilities.

[0001262039-25-000028:mdna:185]
Our operating activities during the six months ended June 30, 2025 provided cash flows of $1.32 billion as a result of the continued growth of our business, improved profitability and our ability to successfully manage our working capital.

[0001262039-25-000028:mdna:186]
Changes in operating assets and liabilities were primarily driven by a decrease of $262.7 million in accounts receivable—net, an increase of $204.8 million in our deferred revenue and an increase of $202.5 million in deferred contract costs during six months ended June 30, 2025. In addition, changes in operating assets and liabilities were driven by an increase of $79.6 million in inventory, an increase of $75.3 million in deferred tax asset, an increase of $46.8 million in accounts payable, and an increase of $32.1 million in prepaid expenses and other current assets.

[0001262039-25-000028:mdna:187]
[same as prior period, unchanged from 0001262039-25-000017:mdna:146]

[0001262039-25-000028:mdna:188]
[same as prior period, unchanged from 0001262039-25-000017:mdna:147]

[0001262039-25-000028:mdna:189]
During the six months ended June 30, 2025, cash used in investing activities was $377.0 million, primarily driven by $234.3 million used for the purchases of property and equipment, $101.2 million spent for purchases of investments, net of maturities and sales of investments, and $41.6 million used for payments made in connection with business combinations, net of cash acquired.

[0001262039-25-000028:mdna:190]
[same as prior period, unchanged from 0001262039-25-000017:mdna:149]

[0001262039-25-000028:mdna:191]
[same as prior period, unchanged from 0001262039-25-000017:mdna:150]

[0001262039-25-000028:mdna:192]
During the six months ended June 30, 2025, cash used in financing activities was $446.9 million, driven by $401.1 million used to repurchase shares of our common stock and $45.7 million used to pay tax withholding, net of proceeds from the issuance of common stock.
