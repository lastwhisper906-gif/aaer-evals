# FTNT 8-K — 0001262039-24-000032 filed 2024-08-06

## item codes, every 8-K on or before 2024-08-08

- 2024-08-07 0001262039-24-000034 — 2.02, 9.01 — amendment of 0001262039-24-000032
- 2024-08-06 0001262039-24-000032 — 2.02, 9.01
- 2024-07-24 0001262039-24-000028 — 5.02 — amendment, the index does not say of what
- 2024-06-20 0001262039-24-000025 — 5.07
- 2024-05-02 0001262039-24-000017 — 2.02, 9.01
- 2024-02-23 0001262039-24-000011 — 5.02, 9.01
- 2024-02-06 0001262039-24-000006 — 2.02, 9.01
- 2024-01-18 0001262039-24-000003 — 5.02
- 2023-12-01 0001262039-23-000041 — 5.02
- 2023-11-02 0001262039-23-000035 — 2.02, 9.01
- 2023-08-03 0001262039-23-000027 — 2.02, 9.01
- 2023-06-23 0001262039-23-000024 — 5.03, 5.07, 9.01
- 2023-05-04 0001262039-23-000013 — 2.02, 9.01
- 2023-02-08 0001262039-23-000006 — 5.03, 9.01
- 2023-02-07 0001262039-23-000003 — 2.02, 9.01
- 2022-11-02 0001262039-22-000035 — 2.02, 9.01
- 2022-08-03 0001262039-22-000026 — 2.02, 9.01
- 2022-06-22 0001262039-22-000023 — 5.03, 9.01
- 2022-06-21 0001262039-22-000021 — 5.07
- 2022-05-04 0001262039-22-000015 — 2.02, 9.01
- 2022-05-02 0001262039-22-000012 — 5.02
- 2022-04-22 0001262039-22-000010 — 8.01
- 2022-02-03 0001262039-22-000005 — 2.02, 9.01
- 2022-01-26 0001262039-22-000002 — 5.02, 9.01 — amendment, the index does not say of what
- 2021-11-04 0001262039-21-000027 — 2.02, 9.01
- 2021-10-06 0001262039-21-000024 — 5.02, 9.01
- 2021-07-29 0001262039-21-000019 — 2.02, 9.01
- 2021-06-23 0001262039-21-000016 — 5.07
- 2021-04-30 0001104659-21-059008 — 5.03 — amendment, the index does not say of what
- 2021-04-29 0001262039-21-000011 — 2.02, 9.01
- 2021-04-28 0001104659-21-056360 — 5.02, 5.03, 9.01
- 2021-03-05 0001193125-21-071498 — 1.01, 9.01
- 2021-02-25 0001193125-21-057281 — 1.01, 9.01
- 2021-02-04 0001262039-21-000005 — 2.02, 9.01
- 2020-12-08 0001262039-20-000070 — 8.01
- 2020-10-29 0001262039-20-000063 — 2.02, 9.01
- 2020-10-20 0001262039-20-000060 — 5.02 — amendment, the index does not say of what
- 2020-08-26 0001262039-20-000056 — 5.02, 9.01
- 2020-08-06 0001262039-20-000051 — 2.02, 9.01
- 2020-07-21 0001262039-20-000044 — 5.03, 8.01, 9.01
- 2020-06-24 0001262039-20-000038 — 5.07
- 2020-05-06 0001262039-20-000029 — 2.02, 9.01
- 2020-04-23 0001262039-20-000025 — 5.03, 9.01
- 2020-04-23 0001262039-20-000024 — 5.02 — amendment of 0001262039-20-000025
- 2020-02-28 0001262039-20-000015 — 5.02, 9.01
- 2020-02-06 0001262039-20-000004 — 2.02, 9.01
- 2019-12-12 0001262039-19-000038 — 8.01
- 2019-10-31 0001262039-19-000032 — 2.02, 9.01
- 2019-10-28 0001262039-19-000027 — 8.01
- 2019-10-23 0001262039-19-000025 — 5.02, 9.01
- 2019-08-01 0001262039-19-000021 — 2.02, 9.01
- 2019-06-26 0001262039-19-000018 — 5.07
- 2019-05-02 0001262039-19-000010 — 2.02, 9.01
- 2019-02-06 0001262039-19-000002 — 2.02, 9.01
- 2018-11-01 0001262039-18-000037 — 2.02, 9.01
- 2018-10-23 0001262039-18-000035 — 8.01
- 2018-08-01 0001262039-18-000025 — 2.02, 9.01
- 2018-06-28 0001262039-18-000023 — 5.03, 5.07, 9.01
- 2018-06-04 0001262039-18-000021 — 8.01
- 2018-05-03 0001262039-18-000017 — 2.02, 5.02, 9.01
- 2018-02-05 0001262039-18-000004 — 2.02, 5.02, 9.01
- 2017-10-26 0001262039-17-000031 — 2.02, 9.01
- 2017-10-19 0001262039-17-000029 — 5.02 — amendment, the index does not say of what
- 2017-07-26 0001262039-17-000025 — 2.02, 9.01
- 2017-06-27 0001262039-17-000023 — 5.07
- 2017-05-31 0001262039-17-000021 — 5.02 — amendment of 0001262039-17-000019
- 2017-05-30 0001262039-17-000019 — 5.02, 9.01
- 2017-04-27 0001262039-17-000013 — 2.02, 9.01
- 2017-02-02 0001262039-17-000003 — 2.02, 9.01
- 2016-10-27 0001262039-16-000085 — 2.02, 9.01
- 2016-10-11 0001262039-16-000082 — 2.02, 9.01
- 2016-07-28 0001262039-16-000076 — 2.02, 9.01
- 2016-07-22 0001262039-16-000073 — 8.01, 9.01
- 2016-06-20 0001262039-16-000068 — 5.07
- 2016-06-07 0001193125-16-614788 — 8.01
- 2016-04-26 0001262039-16-000061 — 2.02, 9.01
- 2016-01-28 0001262039-16-000051 — 2.02, 9.01
- 2015-10-27 0001262039-15-000045 — 2.02
- 2015-10-22 0001262039-15-000042 — 5.02 — amendment, the index does not say of what
- 2015-10-22 0001262039-15-000041 — 5.02 — amendment, the index does not say of what
- 2015-10-22 0001262039-15-000039 — 2.02, 9.01
- 2015-09-28 0001262039-15-000034 — 5.02, 9.01
- 2015-09-22 0001262039-15-000031 — 9.01 — amendment of 0001193125-15-248065
- 2015-08-28 0001262039-15-000027 — 3.01, 5.02
- 2015-07-23 0001262039-15-000021 — 5.02
- 2015-07-22 0001262039-15-000019 — 2.02, 9.01
- 2015-07-08 0001193125-15-248065 — 2.01, 8.01, 9.01
- 2015-06-22 0001193125-15-229099 — 5.07
- 2015-06-19 0001193125-15-228428 — 5.02, 9.01
- 2015-04-20 0001262039-15-000014 — 2.02, 9.01
- 2015-01-28 0001262039-15-000005 — 2.02, 9.01
- 2014-10-22 0001262039-14-000036 — 2.02, 9.01
- 2014-07-23 0001262039-14-000030 — 2.02, 9.01
- 2014-06-24 0001262039-14-000027 — 5.07
- 2014-04-23 0001262039-14-000021 — 2.02, 9.01
- 2014-04-21 0001262039-14-000018 — 5.03, 9.01
- 2014-01-29 0001262039-14-000004 — 2.02, 9.01
- 2013-12-20 0001262039-13-000061 — 5.02, 9.01
- 2013-11-27 0001262039-13-000057 — 5.02, 7.01, 9.01
- 2013-11-12 0001445305-13-002993 — 5.02
- 2013-10-23 0001262039-13-000051 — 2.02, 9.01
- 2013-07-30 0001262039-13-000039 — 2.02, 9.01
- 2013-06-25 0001262039-13-000030 — 5.07
- 2013-04-30 0001262039-13-000023 — 2.02, 9.01
- 2013-04-19 0001262039-13-000020 — 5.02, 9.01
- 2013-04-19 0001262039-13-000018 — 5.02 — amendment of 0001262039-13-000020
- 2013-04-10 0001262039-13-000016 — 2.02, 9.01
- 2013-03-26 0001262039-13-000013 — 5.02
- 2013-01-30 0001262039-13-000005 — 2.02, 9.01
- 2013-01-24 0001262039-13-000002 — 5.02, 9.01
- 2012-10-16 0001262039-12-000048 — 2.02, 9.01
- 2012-10-01 0001262039-12-000045 — 5.02
- 2012-09-26 0001262039-12-000043 — 5.01
- 2012-07-25 0001262039-12-000038 — 2.02, 9.01
- 2012-07-19 0001262039-12-000034 — 5.02
- 2012-06-20 0001193125-12-275869 — 5.07
- 2012-04-27 0001262039-12-000029 — 5.02
- 2012-04-24 0001262039-12-000025 — 2.02, 9.01
- 2012-01-31 0001262039-12-000006 — 2.02, 9.01
- 2012-01-25 0001262039-12-000003 — 5.03
- 2011-10-24 0001262039-11-000036 — 2.02
- 2011-07-19 0001262039-11-000014 — 2.02, 9.01
- 2011-06-27 0001193125-11-174474 — 5.02, 5.07, 9.01
- 2011-04-27 0001193125-11-111938 — 2.02, 9.01
- 2011-01-25 0001193125-11-013914 — 2.02, 9.01
- 2010-10-21 0001193125-10-233676 — 2.02, 9.01
- 2010-09-02 0001193125-10-203099 — 8.01
- 2010-07-22 0001193125-10-163844 — 2.02, 9.01
- 2010-06-24 0001193125-10-146082 — 5.07
- 2010-04-28 0001193125-10-096698 — 2.02, 9.01
- 2010-02-09 0001193125-10-024614 — 8.01
- 2010-01-27 0001193125-10-014292 — 2.02, 9.01
- 2010-01-26 0001193125-10-013031 — 5.02, 9.01

## late-filing notifications on or before 2024-08-08

- none on or before 2024-08-08

## item 2.02 — earnings release, exhibit 99.1

[0001262039-24-000032:8k_2_02:1]
EX-99.1
2
ftntq2-2024ex991.htm
PRESS RELEASE

[0001262039-24-000032:8k_2_02:2]
Document

[0001262039-24-000032:8k_2_02:3]
Press Release

[0001262039-24-000032:8k_2_02:4]
Fortinet Reports Second Quarter 2024 Financial Results

[0001262039-24-000032:8k_2_02:5]
Record quarterly GAAP and Non-GAAP operating margins

[0001262039-24-000032:8k_2_02:6]
Raises 2024 revenue and Non-GAAP operating margin guidance

[0001262039-24-000032:8k_2_02:7]
Continuing to invest in the fast-growing Unified SASE and Security Operations markets

[0001262039-24-000032:8k_2_02:8]
Second Quarter 2024 Highlights

[0001262039-24-000032:8k_2_02:9]
•Total revenue of $1.43 billion, up 11% year over year

[0001262039-24-000032:8k_2_02:10]
•Service revenue of $982 million, up 20% year over year

[0001262039-24-000032:8k_2_02:11]
•Record GAAP operating margin of 30.5%

[0001262039-24-000032:8k_2_02:12]
•Record Non-GAAP operating margin of 35.1%1

[0001262039-24-000032:8k_2_02:13]
•Cash flow from operations of $342 million

[0001262039-24-000032:8k_2_02:14]
SUNNYVALE, Calif. - August 6, 2024 - Fortinet® (Nasdaq: FTNT), a global cybersecurity leader driving the convergence of networking and security, today announced financial results for the second quarter ended June 30, 2024.

[0001262039-24-000032:8k_2_02:15]
“In the second quarter, we successfully balanced growth and profitability as our non-GAAP operating margin increased 820 basis points year-over-year to a company record of 35.1%1, while billings and revenue were at the high end of their respective guidance ranges,” said Ken Xie, Founder, Chairman and Chief Executive Officer of Fortinet. “We are continuing to execute our strategy to invest in the fast-growing Unified SASE and Security Operations markets, while gaining market share in Secure Networking. We expect to emerge as a SASE leader, as we are the only vendor in the Gartner Magic Quadrant™ for Single-Vendor SASE that is also recognized in five different network security Magic Quadrant™ reports.2”

[0001262039-24-000032:8k_2_02:16]
Financial Highlights for the Second Quarter of 2024

[0001262039-24-000032:8k_2_02:17]
•Revenue: Total revenue was $1.43 billion for the second quarter of 2024, an increase of 10.9% compared to $1.29 billion for the same quarter of 2023.

[0001262039-24-000032:8k_2_02:18]
•Product Revenue: Product revenue was $451.9 million for the second quarter of 2024, a decrease of 4.4% compared to $472.6 million for the same quarter of 2023.

[0001262039-24-000032:8k_2_02:19]
•Service Revenue: Service revenue was $982.4 million for the second quarter of 2024, an increase of 19.8% compared to $820.2 million for the same quarter of 2023.

[0001262039-24-000032:8k_2_02:20]
•Billings1: Total billings were $1.54 billion for the second quarter of 2024, remaining flat compared to $1.54 billion for the same quarter of 2023.

[0001262039-24-000032:8k_2_02:21]
•Deferred Revenue: Total deferred revenue was $5.90 billion as of June 30, 2024, an increase of 15.0% compared to $5.13 billion as of June 30, 2023.

[0001262039-24-000032:8k_2_02:22]
•GAAP Operating Income and Margin: GAAP operating income was $437.2 million for the second quarter of 2024, representing a GAAP operating margin of 30.5%. GAAP operating income was $279.0 million for the same quarter of 2023, representing a GAAP operating margin of 21.6%.

[0001262039-24-000032:8k_2_02:23]
•Non-GAAP Operating Income and Margin1: Non-GAAP operating income was $503.6 million for the second quarter of 2024, representing a non-GAAP operating margin of 35.1%. Non-GAAP operating income was $348.1 million for the same quarter of 2023, representing a non-GAAP operating margin of 26.9%.

[0001262039-24-000032:8k_2_02:24]
•GAAP Net Income and Diluted Net Income Per Share: GAAP net income was $379.8 million for the second quarter of 2024, compared to GAAP net income of $266.3 million for the same quarter of 2023. GAAP diluted net income per share was $0.49 for the second quarter of 2024, based on 769.9 million diluted weighted-average shares outstanding, compared to GAAP diluted net income per share of $0.33 for the same quarter of 2023, based on 795.9 million diluted weighted-average shares outstanding.

[0001262039-24-000032:8k_2_02:25]
•Non-GAAP Net Income and Diluted Net Income Per Share1: Non-GAAP net income was $439.9 million for the second quarter of 2024, compared to non-GAAP net income of $300.4 million for the same quarter of 2023. Non-GAAP diluted net income per share was $0.57 for the second quarter of 2024, based on 769.9 million diluted weighted-average shares outstanding, compared to $0.38 for the same quarter of 2023, based on 795.9 million diluted weighted-average shares outstanding.

[0001262039-24-000032:8k_2_02:26]
•Cash Flow: Cash flow from operations was $342.0 million for the second quarter of 2024, compared to $515.1 million for the same quarter of 2023.

[0001262039-24-000032:8k_2_02:27]
•Free Cash Flow1: Free cash flow was $318.9 million for the second quarter of 2024, compared to $438.3 million for the same quarter of 2023.

[0001262039-24-000032:8k_2_02:28]
Guidance

[0001262039-24-000032:8k_2_02:29]
For the third quarter of 2024, Fortinet currently expects:

[0001262039-24-000032:8k_2_02:30]
•Revenue in the range of $1.445 billion to $1.505 billion

[0001262039-24-000032:8k_2_02:31]
•Billings in the range of $1.530 billion to $1.600 billion

[0001262039-24-000032:8k_2_02:32]
•Non-GAAP gross margin in the range of 79.0% to 80.0%

[0001262039-24-000032:8k_2_02:33]
•Non-GAAP operating margin in the range of 30.5% to 31.5%

[0001262039-24-000032:8k_2_02:34]
•Diluted non-GAAP net income per share in the range of $0.56 to $0.58, assuming a non-GAAP effective tax rate of 17%. This assumes a diluted share count of 767 million to 777 million.

[0001262039-24-000032:8k_2_02:35]
For the fiscal year 2024, Fortinet currently expects:

[0001262039-24-000032:8k_2_02:36]
•Revenue in the range of $5.800 billion to $5.900 billion

[0001262039-24-000032:8k_2_02:37]
•Service revenue in the range of $3.975 billion to $4.025 billion

[0001262039-24-000032:8k_2_02:38]
•Billings in the range of $6.400 billion to $6.600 billion

[0001262039-24-000032:8k_2_02:39]
•Non-GAAP gross margin in the range of 79.0% to 80.0%

[0001262039-24-000032:8k_2_02:40]
•Non-GAAP operating margin in the range of 30.0% to 31.5%

[0001262039-24-000032:8k_2_02:41]
•Diluted non-GAAP net income per share in the range of $2.13 to $2.19, assuming a non-GAAP effective tax rate of 17%. This assumes a diluted share count of 767 million to 777 million.

[0001262039-24-000032:8k_2_02:42]
Our guidance with respect to non-GAAP financial measures excludes stock-based compensation, amortization of acquired intangible assets, gain on intellectual property matters and non-cash charge on equity method investment of impairment. We have not reconciled our guidance with respect to non-GAAP financial measures to the corresponding GAAP measures because certain items that impact these measures are uncertain or out of our control, or cannot be reasonably predicted. Accordingly, a reconciliation of these non-GAAP financial measures to the corresponding GAAP measures is not available without unreasonable effort.

[0001262039-24-000032:8k_2_02:43]
GARTNER is a registered trademark and service mark of Gartner and Magic Quadrant is a registered trademark of Gartner, Inc. and/or its affiliates in the U.S. and internationally and are used herein with permission. All rights reserved.

[0001262039-24-000032:8k_2_02:44]
Gartner does not endorse any vendor, product or service depicted in our research publications, and does not advise technology users to select only those vendors with the highest ratings or other designation. Gartner research publications consist of the opinions of Gartner research organization and should not be construed as statements of fact. Gartner disclaims all warranties, expressed or implied, with respect to this research, including any warranties of merchantability or fitness for a particular purpose.

[0001262039-24-000032:8k_2_02:45]
1 A reconciliation of GAAP to non-GAAP measures has been provided in the financial statement tables included in this press release. An explanation of these measures is also included below under the heading “Non-GAAP Financial Measures”.

[0001262039-24-000032:8k_2_02:46]
2 Magic Quadrant for SD-WAN, Jonathan Forest, Naresh Singh, Andrew Lerner, Karen Brown, Published 27 September 2023

[0001262039-24-000032:8k_2_02:47]
Magic Quadrant for Enterprise Wired and Wireless LAN Infrastructure, Tim Zimmerman, Christian Canales, Nauman Raja, Mike Leibovitz, Published 06 March 2024

[0001262039-24-000032:8k_2_02:48]
Magic Quadrant for Network Firewalls, Rajpreet Kaur, Adam Hils, Thomas Lintemuth, Published 19 December 2022

[0001262039-24-000032:8k_2_02:49]
Magic Quadrant for Security Service Edge, Charlie Winckless, Thomas Lintemuth, Dale Koeppen, Published 15 April 2024

[0001262039-24-000032:8k_2_02:50]
Magic Quadrant for Single-Vendor SASE, Andrew Lerner, Jonathan Forest, Neil MacDonald, Nat Smith, Charlie Winckless, Published 16 August 2023

[0001262039-24-000032:8k_2_02:51]
Conference Call Details

[0001262039-24-000032:8k_2_02:52]
Fortinet will host a conference call today at 1:30 p.m. Pacific Time (4:30 p.m. Eastern Time) to discuss the earnings results. A live webcast of the conference call and supplemental slides will be accessible from the Investor Relations page of Fortinet’s website at https://investor.fortinet.com and a replay will be archived and accessible at https://investor.fortinet.com/events-and-presentations.

[0001262039-24-000032:8k_2_02:53]
Third Quarter 2024 Conference Participation Schedule:

[0001262039-24-000032:8k_2_02:54]
•Oppenheimer Technology, Internet & Communications Conference

[0001262039-24-000032:8k_2_02:55]
August 12, 2024

[0001262039-24-000032:8k_2_02:56]
•Deutsche Bank Technology Conference

[0001262039-24-000032:8k_2_02:57]
August 28, 2024

[0001262039-24-000032:8k_2_02:58]
•Goldman Sachs Communacopia + Technology Conference

[0001262039-24-000032:8k_2_02:59]
September 9, 2024

[0001262039-24-000032:8k_2_02:60]
Members of Fortinet’s management team are expected to present at these conferences and discuss the latest company strategies and initiatives. Fortinet’s conference presentations are

[0001262039-24-000032:8k_2_02:61]
expected to be available via webcast on the company’s website. To access the most updated information, pre-register and listen to the webcast of each event, please visit the Investor Presentation & Events page of Fortinet’s website at https://investor.fortinet.com/events-and-presentations. The schedule is subject to change.

[0001262039-24-000032:8k_2_02:62]
About Fortinet (www.fortinet.com)

[0001262039-24-000032:8k_2_02:63]
Fortinet (Nasdaq: FTNT) is a driving force in the evolution of cybersecurity and the convergence of networking and security. Our mission is to secure people, devices and data everywhere, and today we deliver cybersecurity everywhere our customers need it with the largest integrated portfolio of over 50 enterprise-grade products. Over half a million customers trust Fortinet’s solutions, which are among the most deployed, most patented and most validated in the industry. The Fortinet Training Institute, one of the largest and broadest training programs in the industry, is dedicated to making cybersecurity training and new career opportunities available to everyone. Collaboration with high-profile, well-respected organizations from both the public and private sectors, including CERTs, government entities, and academia, is a fundamental aspect of Fortinet’s commitment to enhance cyber resilience globally. FortiGuard Labs, Fortinet’s elite threat intelligence and research organization, develops and utilizes leading-edge machine learning and AI technologies to provide customers with timely and consistently top-rated protection and actionable threat intelligence. Learn more at https://www.fortinet.com, the Fortinet Blog or FortiGuard Labs.

[0001262039-24-000032:8k_2_02:64]
#          #          #

[0001262039-24-000032:8k_2_02:65]
Copyright © 2024 Fortinet, Inc. All rights reserved. The symbols ® and ™ denote respectively federally registered trademarks and common law trademarks of Fortinet, Inc., its subsidiaries and affiliates. Fortinet’s trademarks include, but are not limited to, the following: Fortinet, the Fortinet logo, FortiGate, FortiOS, FortiGuard, FortiCare, FortiAnalyzer, FortiManager, FortiASIC, FortiClient, FortiCloud, FortiMail, FortiSandbox, FortiADC, FortiAI, FortiAIOps, FortiAntenna, FortiAP, FortiAPCam, FortiAuthenticator, FortiCache, FortiCam, FortiCamera, FortiCarrier, FortiCASB, FortiCentral, FortiCNP, FortiConnect, FortiController, FortiConverter, FortiCSPM, FortiCWP, FortiDAST, FortiDB, FortiDDoS, FortiDeceptor, FortiDeploy, FortiDevSec, FortiEDR, FortiExplorer, FortiExtender, FortiFirewall, FortiFlex, FortiFone, FortiGSLB, FortiGuest, FortiHypervisor, FortiInsight, FortiIsolator, FortiLAN, FortiLink, FortiMonitor, FortiNAC, FortiNDR, FortiPAM, FortiPenTest, FortiPhish, FortiPoint, FortiPolicy, FortiPortal, FortiPresence, FortiProxy, FortiRecon, FortiRecorder, FortiSASE, FortiSDNConnector, FortiSIEM, FortiSMS, FortiSOAR, FortiStack, FortiSwitch, FortiTester, FortiToken, FortiTrust, FortiVoice, FortiWAN, FortiWeb, FortiWiFi, FortiWLC, FortiWLM and FortiXDR. Other trademarks belong to their respective owners. Fortinet has not independently verified statements or certifications herein attributed to third parties and Fortinet does not independently endorse such statements. Notwithstanding anything to the contrary herein, nothing herein constitutes a warranty, guarantee, contract, binding specification or other binding commitment by Fortinet or any indication of intent related to a binding commitment, and performance and other specification information herein may be unique to certain environments.

[0001262039-24-000032:8k_2_02:66]
FTNT-F

[0001262039-24-000032:8k_2_02:67]
Forward-Looking Statements

[0001262039-24-000032:8k_2_02:68]
This press release contains forward-looking statements that involve risks and uncertainties. These forward-looking statements include statements regarding any indications related to future growth and market share gains, our strategy going forward, and guidance and expectations around future financial results, including guidance and expectations for the third quarter and full year 2024, and any statements regarding our market opportunity and market size, and business momentum. Although we attempt to be accurate in making forward-looking statements, it is possible that future circumstances might differ from the assumptions on which such statements are based such that actual results are materially different from our forward-looking statements in this release. Important factors that could cause results to differ materially from the statements herein include the following: general economic risks, including those caused by economic

[0001262039-24-000032:8k_2_02:69]
Non-GAAP Financial Measures

[0001262039-24-000032:8k_2_02:70]
We have provided in this release financial information that has not been prepared in accordance with U.S. Generally Accepted Accounting Principles (GAAP). These non-GAAP financial and liquidity measures are not based on any standardized methodology prescribed by GAAP and are not necessarily comparable to similar measures presented by other companies. We use these non-GAAP financial measures internally in analyzing our financial results and believe they are useful to investors, as a supplement to GAAP measures, in evaluating our ongoing operational performance. We believe that the use of these non-GAAP financial measures provides an additional tool for investors to use in evaluating ongoing operating results and trends and in comparing our financial results with peer companies, many of which present similar non-GAAP financial measures to investors.

[0001262039-24-000032:8k_2_02:71]
Non-GAAP financial measures should not be considered in isolation from, or as a substitute for, financial information prepared in accordance with GAAP. Investors are encouraged to review the reconciliation of these non-GAAP financial measures to their most directly comparable GAAP financial measures provided in the financial statement tables below.

[0001262039-24-000032:8k_2_02:72]
Billings (non-GAAP). We define billings as revenue recognized in accordance with GAAP plus the change in deferred revenue from the beginning to the end of the period less any deferred revenue balances acquired from business combination(s) during the period. We consider billings to be a useful metric for management and investors because billings drive current and future revenue, which is an important indicator of the health and viability of our business. There are a number of limitations related to the use of billings instead of GAAP revenue. First, billings include amounts that have not yet been recognized as revenue and are impacted by the term of security and support agreements. Second, we may calculate billings in a manner that is different from peer companies that report similar financial measures. Management accounts for these limitations by providing specific information regarding GAAP revenue and evaluating billings together with GAAP revenue.

[0001262039-24-000032:8k_2_02:73]
Free cash flow (non-GAAP). We define free cash flow as net cash provided by operating activities minus purchases of property and equipment and excluding any significant non-recurring items. We believe free cash flow to be a liquidity measure that provides useful information to management and investors about the amount of cash generated by the business that, after capital expenditures, can be used for strategic opportunities, including repurchasing outstanding common stock, investing in our business, making strategic acquisitions and strengthening the balance sheet. A limitation of using free cash flow rather than the GAAP measures of cash provided by or used in operating activities, investing activities, and financing activities is that free cash flow does not represent the total increase or decrease in the cash and cash equivalents balance for the period because it excludes cash flows from significant non-recurring items, investing activities other than capital expenditures and cash flows from financing activities. Management accounts for this limitation by providing information about our capital expenditures and other investing and financing activities on the face of the cash flow statement and under the caption “Management’s Discussion and Analysis of Financial Condition and Results of Operations—Liquidity and Capital Resources” in our most recent Quarterly Report on Form 10-Q and Annual Report on Form 10-K and by presenting cash flows from investing and financing activities in our reconciliation of free cash flow. In addition, it is important to note that other companies, including companies in our industry, may not use free cash flow, may calculate free cash flow in a different manner than we do or may use other financial measures to evaluate their performance, all of which could reduce the usefulness of free cash flow as a comparative measure.

[0001262039-24-000032:8k_2_02:74]
Non-GAAP operating income and operating margin. We define non-GAAP operating income as operating income plus stock-based compensation, amortization of acquired intangible assets, less gain on intellectual property matter and, when applicable, other significant non-recurring items in a given quarter. Non-GAAP operating margin is defined as non-GAAP operating income divided by GAAP revenue. We consider these non-GAAP financial measures to be useful metrics for management and investors because they exclude the items noted above so that our management and investors can compare our recurring core business operating results over multiple periods. There are a number of limitations related to the use of non-GAAP operating income instead of operating income calculated in accordance with GAAP. First, non-GAAP operating income excludes the items noted above. Second, the components of the costs that we exclude from our calculation of non-GAAP operating income may differ from the components that peer companies exclude when they report their non-GAAP results of operations. Management accounts for these limitations by providing specific information regarding the GAAP amounts excluded from non-GAAP operating income and evaluating non-GAAP operating income together with operating income calculated in accordance with GAAP.

[0001262039-24-000032:8k_2_02:75]
Non-GAAP net income and diluted net income per share. We define non-GAAP net income as net income plus the items noted above under non-GAAP operating income and operating margin. In addition, we adjust non-GAAP net income and diluted net income per share for a non-cash charge of impairment on equity method investment, a tax adjustment required for an effective tax rate on a non-GAAP basis, which differs from the GAAP effective tax rate. We define non-GAAP diluted net income per share as non-GAAP net income divided by the non-GAAP diluted weighted-average shares outstanding. We consider these non-GAAP financial measures to be useful metrics for management and investors for the same reasons that we use non-GAAP operating income and non-GAAP operating margin. However, in order to provide a more complete picture of our recurring core business operating results, we include in non-GAAP net income and non-GAAP diluted net income per share, the tax adjustment required resulting in an effective tax rate on a non-GAAP basis, which often differs from the GAAP tax rate. We believe the non-GAAP effective tax rates we use are reasonable estimates of normalized tax rates for our current and prior fiscal years under our global operating structure. The same limitations described above regarding our use of non-GAAP operating income and non-GAAP operating margin apply to our use of non-GAAP net income and non-GAAP diluted net income per share. We account for these limitations by providing specific information regarding the GAAP amounts excluded from non-GAAP net income and non-GAAP diluted net income per share and evaluating non-GAAP net income and non-GAAP diluted net income per share together with net income and diluted net income per share calculated in accordance with GAAP.

[0001262039-24-000032:8k_2_02:76]
FORTINET, INC.

[0001262039-24-000032:8k_2_02:77]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001262039-24-000032:8k_2_02:78]
(Unaudited, in millions)

[0001262039-24-000032:8k_2_02:79]
|  | June 30,2024 |  | December 31,2023 |
| ASSETS |  |  |  |
| CURRENT ASSETS: |  |  |  |
| Cash and cash equivalents | $ | 2,203.2 |  |  | $ | 1,397.9 |  |
| Short-term investments | 1,114.9 |  |  | 1,021.5 |  |
| Marketable equity securities | 21.2 |  |  | 21.0 |  |
| Accounts receivable—net | 1,083.4 |  |  | 1,402.0 |  |
| Inventory | 383.2 |  |  | 484.8 |  |
| Prepaid expenses and other current assets | 113.4 |  |  | 101.1 |  |
| Total current assets | 4,919.3 |  |  | 4,428.3 |  |
| PROPERTY AND EQUIPMENT—NET | 1,242.7 |  |  | 1,044.4 |  |
| DEFERRED CONTRACT COSTS | 596.9 |  |  | 605.6 |  |
| DEFERRED TAX ASSETS | 998.5 |  |  | 868.8 |  |
| GOODWILL AND OTHER INTANGIBLE ASSETS—NET | 158.1 |  |  | 161.8 |  |
| OTHER ASSETS | 137.4 |  |  | 150.0 |  |
| TOTAL ASSETS | $ | 8,052.9 |  |  | $ | 7,258.9 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY (DEFICIT) |  |  |  |
| CURRENT LIABILITIES: |  |  |  |
| Accounts payable | $ | 132.1 |  |  | $ | 204.3 |  |
| Accrued liabilities | 400.6 |  |  | 423.7 |  |
| Accrued payroll and compensation | 217.3 |  |  | 242.3 |  |
| Deferred revenue | 2,975.3 |  |  | 2,848.7 |  |
| Total current liabilities | 3,725.3 |  |  | 3,719.0 |  |
| DEFERRED REVENUE | 2,920.9 |  |  | 2,886.3 |  |
| LONG-TERM DEBT | 993.3 |  |  | 992.3 |  |
| OTHER LIABILITIES | 125.2 |  |  | 124.7 |  |
| Total liabilities | 7,764.7 |  |  | 7,722.3 |  |
| COMMITMENTS AND CONTINGENCIES |  |  |  |
| STOCKHOLDERS’ EQUITY (DEFICIT): |  |  |  |
| Common stock | 0.8 |  |  | 0.8 |  |
| Additional paid-in capital | 1,499.0 |  |  | 1,416.4 |  |
| Accumulated other comprehensive loss | (29.0) |  |  | (18.9) |  |
| Accumulated deficit | (1,182.6) |  |  | (1,861.7) |  |
| Total stockholders’ equity (deficit) | 288.2 |  |  | (463.4) |  |
| TOTAL LIABILITIES AND STOCKHOLDERS’ EQUITY (DEFICIT) | $ | 8,052.9 |  |  | $ | 7,258.9 |  |

[0001262039-24-000032:8k_2_02:80]
FORTINET, INC.

[0001262039-24-000032:8k_2_02:81]
CONDENSED CONSOLIDATED STATEMENTS OF INCOME

[0001262039-24-000032:8k_2_02:82]
(Unaudited, in millions, except per share amounts)

[0001262039-24-000032:8k_2_02:83]
|  | Three Months Ended |  | Six Months Ended |
|  | June 30,2024 |  | June 30,2023 |  | June 30,2024 |  | June 30,2023 |
| REVENUE: |  |  |  |  |  |  |  |
| Product | $ | 451.9 |  |  | $ | 472.6 |  |  | $ | 860.8 |  |  | $ | 973.3 |  |
| Service | 982.4 |  |  | 820.2 |  |  | 1,926.8 |  |  | 1,581.8 |  |
| Total revenue | 1,434.3 |  |  | 1,292.8 |  |  | 2,787.6 |  |  | 2,555.1 |  |
| COST OF REVENUE: |  |  |  |  |  |  |  |
| Product | 155.1 |  |  | 174.5 |  |  | 337.9 |  |  | 368.1 |  |
| Service | 119.9 |  |  | 121.3 |  |  | 241.8 |  |  | 235.5 |  |
| Total cost of revenue | 275.0 |  |  | 295.8 |  |  | 579.7 |  |  | 603.6 |  |
| GROSS PROFIT: |  |  |  |  |  |  |  |
| Product | 296.8 |  |  | 298.1 |  |  | 522.9 |  |  | 605.2 |  |
| Service | 862.5 |  |  | 698.9 |  |  | 1,685.0 |  |  | 1,346.3 |  |
| Total gross profit | 1,159.3 |  |  | 997.0 |  |  | 2,207.9 |  |  | 1,951.5 |  |
| OPERATING EXPENSES: |  |  |  |  |  |  |  |
| Research and development | 165.4 |  |  | 153.3 |  |  | 338.4 |  |  | 304.4 |  |
| Sales and marketing | 501.3 |  |  | 515.9 |  |  | 1,002.4 |  |  | 994.2 |  |
| General and administrative | 56.6 |  |  | 49.9 |  |  | 111.0 |  |  | 102.7 |  |
| Gain on intellectual property matter | (1.2) |  |  | (1.1) |  |  | (2.3) |  |  | (2.3) |  |
| Total operating expenses | 722.1 |  |  | 718.0 |  |  | 1,449.5 |  |  | 1,399.0 |  |
| OPERATING INCOME | 437.2 |  |  | 279.0 |  |  | 758.4 |  |  | 552.5 |  |
| INTEREST INCOME | 38.3 |  |  | 31.6 |  |  | 70.5 |  |  | 52.2 |  |
| INTEREST EXPENSE | (5.0) |  |  | (5.2) |  |  | (10.1) |  |  | (10.2) |  |
| OTHER EXPENSE—NET | (2.2) |  |  | (6.2) |  |  | (5.1) |  |  | (4.2) |  |
| INCOME BEFORE INCOME TAXES AND LOSS FROM EQUITY METHOD INVESTMENTS | 468.3 |  |  | 299.2 |  |  | 813.7 |  |  | 590.3 |  |
| PROVISION FOR INCOME TAXES | 76.5 |  |  | 27.6 |  |  | 116.0 |  |  | 48.9 |  |
| LOSS FROM EQUITY METHOD INVESTMENTS | (12.0) |  |  | (5.3) |  |  | (18.6) |  |  | (27.4) |  |
| NET INCOME | $ | 379.8 |  |  | $ | 266.3 |  |  | $ | 679.1 |  |  | $ | 514.0 |  |
| Net income per share: |  |  |  |  |  |  |  |
| Basic | $ | 0.50 |  |  | $ | 0.34 |  |  | $ | 0.89 |  |  | $ | 0.66 |  |
| Diluted | $ | 0.49 |  |  | $ | 0.33 |  |  | $ | 0.88 |  |  | $ | 0.65 |  |
| Weighted-average shares outstanding: |  |  |  |  |  |  |  |
| Basic | 763.8 |  |  | 785.0 |  |  | 763.1 |  |  | 784.1 |  |
| Diluted | 769.9 |  |  | 795.9 |  |  | 770.2 |  |  | 794.7 |  |

[0001262039-24-000032:8k_2_02:84]
FORTINET, INC.

[0001262039-24-000032:8k_2_02:85]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001262039-24-000032:8k_2_02:86]
(Unaudited, in millions)

[0001262039-24-000032:8k_2_02:87]
|  | Six Months Ended |
|  | June 30,2024 |  | June 30,2023 |
| CASH FLOWS FROM OPERATING ACTIVITIES: |  |  |  |
| Net income | $ | 679.1 |  |  | $ | 514.0 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |
| Stock-based compensation | 126.2 |  |  | 121.3 |  |
| Amortization of deferred contract costs | 144.7 |  |  | 127.9 |  |
| Depreciation and amortization | 57.8 |  |  | 54.9 |  |
| Amortization of investment discounts | (24.9) |  |  | (5.9) |  |
| Loss from equity method investments | 18.6 |  |  | 27.4 |  |
| Other | 7.0 |  |  | 8.8 |  |
| Changes in operating assets and liabilities, net of impact of business combination: |  |  |  |
| Accounts receivable—net | 318.9 |  |  | 179.0 |  |
| Inventory | 85.2 |  |  | (130.2) |  |
| Prepaid expenses and other current assets | (12.3) |  |  | (35.4) |  |
| Deferred contract costs | (136.0) |  |  | (168.5) |  |
| Deferred tax assets | (130.3) |  |  | (161.8) |  |
| Other assets | (7.6) |  |  | 10.8 |  |
| Accounts payable | (67.2) |  |  | (3.6) |  |
| Accrued liabilities | (24.9) |  |  | 168.3 |  |
| Accrued payroll and compensation | (24.3) |  |  | 6.0 |  |
| Other liabilities | 0.7 |  |  | (9.7) |  |
| Deferred revenue | 161.7 |  |  | 489.3 |  |
| Net cash provided by operating activities | 1,172.4 |  |  | 1,192.6 |  |
| CASH FLOWS FROM INVESTING ACTIVITIES: |  |  |  |
| Purchases of investments | (974.3) |  |  | (804.6) |  |
| Maturities of investments | 904.6 |  |  | 445.1 |  |
| Purchases of property and equipment | (245.0) |  |  | (107.1) |  |
| Payments made in connection with business combination, net of cash acquired | (5.7) |  |  | — |  |
| Other | — |  |  | 0.1 |  |
| Net cash used in investing activities | (320.4) |  |  | (466.5) |  |
| CASH FLOWS FROM FINANCING ACTIVITIES: |  |  |  |
| Proceeds from issuance of common stock | 19.6 |  |  | 29.3 |  |
| Taxes paid related to net share settlement of equity awards | (63.1) |  |  | (59.7) |  |
| Other | (0.8) |  |  | (1.0) |  |
| Net cash used in financing activities | (44.3) |  |  | (31.4) |  |
| EFFECT OF EXCHANGE RATE CHANGES ON CASH AND CASH EQUIVALENTS | (2.4) |  |  | (1.3) |  |
| NET INCREASE IN CASH AND CASH EQUIVALENTS | 805.3 |  |  | 693.4 |  |
| CASH AND CASH EQUIVALENTS—Beginning of period | 1,397.9 |  |  | 1,682.9 |  |
| CASH AND CASH EQUIVALENTS—End of period | $ | 2,203.2 |  |  | $ | 2,376.3 |  |

[0001262039-24-000032:8k_2_02:88]
Reconciliations of non-GAAP results of operations measures to the nearest comparable GAAP measures

[0001262039-24-000032:8k_2_02:89]
(Unaudited, in millions, except per share amounts)

[0001262039-24-000032:8k_2_02:90]
Reconciliation of GAAP operating income to non-GAAP operating income, operating margin, net income and diluted net income per share

[0001262039-24-000032:8k_2_02:91]
|  | Three Months Ended |  |  |
|  | June 30,2024 |  | June 30,2023 |  |  |  |  |
| Reconciliation of non-GAAP operating income: |  |  |  |  |  |  |  |
| GAAP operating income | $ | 437.2 |  |  | $ | 279.0 |  |  |  |  |  |
| GAAP operating margin | 30.5 | % |  | 21.6 | % |  |  |  |  |
| Add back: |  |  |  |  |  |  |  |
| Stock‐based compensation | 64.3 |  |  | 65.7 |  |  |  |  |  |
| Amortization of acquired intangible assets | 3.3 |  |  | 4.5 |  |  |  |  |  |
| Gain on intellectual property matter | (1.2) |  |  | (1.1) |  |  |  |  |  |
| Non‐GAAP operating income | $ | 503.6 |  |  | $ | 348.1 |  |  |  |  |  |
| Non‐GAAP operating margin | 35.1 | % |  | 26.9 | % |  |  |  |  |
| Reconciliation of non-GAAP net income: |  |  |  |  |  |  |  |
| GAAP net income | $ | 379.8 |  |  | $ | 266.3 |  |  |  |  |  |
| Add back: |  |  |  |  |  |  |  |
| Stock‐based compensation | 64.3 |  |  | 65.7 |  |  |  |  |  |
| Amortization of acquired intangible assets | 3.3 |  |  | 4.5 |  |  |  |  |  |
| Gain on intellectual property matter | (1.2) |  |  | (1.1) |  |  |  |  |  |
| Tax adjustment (a) | (14.3) |  |  | (35.0) |  |  |  |  |  |
| Non-cash charge on equity method investment (b) | 8.0 |  |  | — |  |  |  |  |  |
| Non-GAAP net income | $ | 439.9 |  |  | $ | 300.4 |  |  |  |  |  |
| Non-GAAP net income per share, diluted |  |  |  |  |  |  |  |
| Non-GAAP net income | $ | 439.9 |  |  | $ | 300.4 |  |  |  |  |  |
| Non-GAAP shares used in diluted net income per share calculations | 769.9 |  |  | 795.9 |  |  |  |  |  |
| Non-GAAP net income per share, diluted | $ | 0.57 |  |  | $ | 0.38 |  |  |  |  |  |
| Reconciliation of non-GAAP net income per share, diluted |  |  |  |  |  |  |  |
| GAAP net income per share | $ | 0.49 |  |  | $ | 0.33 |  |  |  |  |  |
| Add back: |  |  |  |  |  |  |  |
| Non-GAAP adjustments to net income per share | 0.08 |  |  | 0.05 |  |  |  |  |  |
| Non-GAAP net income per share, diluted | $ | 0.57 |  |  | $ | 0.38 |  |  |  |  |  |

[0001262039-24-000032:8k_2_02:92]
(a) Non-GAAP financial information is adjusted to an effective tax rate of 17% in the three months ended June 30, 2024 and 2023, respectively, on a non-GAAP basis, which differs from the GAAP effective tax rate.

[0001262039-24-000032:8k_2_02:93]
(b) To exclude an $8.0 million non-cash charge of impairment on our equity method investment in Linksys.

[0001262039-24-000032:8k_2_02:94]
Reconciliation of net cash provided by operating activities to free cash flow

[0001262039-24-000032:8k_2_02:95]
|  | Three Months Ended |
|  | June 30,2024 |  | June 30,2023 |
| Net cash provided by operating activities | $ | 342.0 |  |  | $ | 515.1 |  |
| Less: Purchases of property and equipment | (23.1) |  |  | (76.8) |  |
| Free cash flow | $ | 318.9 |  |  | $ | 438.3 |  |
| Net cash used in investing activities | $ | (50.1) |  |  | $ | (424.1) |  |
| Net cash used in financing activities | $ | (14.0) |  |  | $ | (17.7) |  |

[0001262039-24-000032:8k_2_02:96]
Reconciliation of total revenue to total billings

[0001262039-24-000032:8k_2_02:97]
|  | Three Months Ended |
|  | June 30,2024 |  | June 30,2023 |
| Total revenue | $ | 1,434.3 |  |  | $ | 1,292.8 |  |
| Add: Change in deferred revenue | 106.3 |  |  | 247.7 |  |
| Total billings | $ | 1,540.6 |  |  | $ | 1,540.5 |  |

[0001262039-24-000032:8k_2_02:98]
| Investor Contact: |  | Media Contact: |
| Aaron Ovadia |  | Michelle Zimmermann |
| Fortinet, Inc. |  | Fortinet, Inc. |
| 408-235-7700 |  | 408-235-7700 |
| investors@fortinet.com |  | pr@fortinet.com |
