# FTNT notes — 0001262039-24-000037


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001262039-24-000037:notes:1]
SUMMARY OF SIGNIFICANT ACCOUNTING POLICIES
Basis of Presentation and Preparation—The unaudited condensed consolidated financial statements of Fortinet, Inc. and its subsidiaries (collectively, “we,” “us” or “our”) have been prepared in accordance with generally accepted accounting principles in the United States (“GAAP”) for interim financial information, as well as the instructions to Form 10-Q pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (the “SEC”). Accordingly, they do not include all of the information and footnotes required by GAAP for complete financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the year ended December 31, 2023, contained in our Annual Report on Form 10-K filed with the SEC on February 26, 2024. In the opinion of management, all adjustments, which include normal recurring adjustments, considered necessary for a fair presentation, have been included. The results of operations for the three and six months ended June 30, 2024 are not necessarily indicative of the results to be expected for the full year or for any future periods. The condensed consolidated balance sheet as of December 31, 2023 is derived from the audited consolidated financial statements for the year ended December 31, 2023.

[0001262039-24-000037:notes:2]
[same as prior period, unchanged from 0001262039-24-000020:notes:2]

[0001262039-24-000037:notes:3]
[same as prior period, unchanged from 0001262039-24-000020:notes:3]

[0001262039-24-000037:notes:4]
There have been no material changes to our significant accounting policies as of and for the three and six months ended June 30, 2024, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended December 31, 2023 filed with the SEC.

[0001262039-24-000037:notes:5]
[same as prior period, unchanged from 0001262039-24-000020:notes:5]

[0001262039-24-000037:notes:6]
[same as prior period, unchanged from 0001262039-24-000020:notes:6]

[0001262039-24-000037:notes:7]
In November 2023, the Financial Accounting Standards Board (the “FASB”) issued Accounting Standards Update (“ASU”) 2023-07, Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures, which is intended to improve reportable segment disclosure requirements, primarily through enhanced disclosures about significant expenses. The amendments are effective for our annual reporting for fiscal year 2024, and for our interim period reporting starting in fiscal year 2025 retrospectively, with early adoption permitted. We are currently evaluating the ASU to determine its impact on our disclosures.

[0001262039-24-000037:notes:8]
[same as prior period, unchanged from 0001262039-24-000020:notes:8]

[0001262039-24-000037:notes:9]
In December 2023, the FASB issued ASU 2023-09, Income Taxes (Topic 740): Improvements to Income Tax Disclosures, which includes amendments that further enhance income tax disclosures, primarily through standardization and disaggregation of rate reconciliation categories and income taxes paid by jurisdiction. The amendments are effective for our annual period beginning fiscal year 2025, with early adoption permitted, and should be applied prospectively. We are currently evaluating the ASU to determine its impact on our disclosures.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001262039-24-000037:notes:10]
[same as prior period, unchanged from 0001262039-24-000020:notes:10]

[0001262039-24-000037:notes:11]
[same as prior period, unchanged from 0001262039-24-000020:notes:11]

[0001262039-24-000037:notes:12]
|  | Three Months Ended |  | Six Months Ended |
|  | June 30,2024 |  | June 30,2023 |  | June 30,2024 |  | June 30,2023 |
| Product | $ | 451.9 |  |  | $ | 472.6 |  |  | $ | 860.8 |  |  | $ | 973.3 |  |
| Service: |  |  |  |  |  |  |  |
| Security subscription | 558.7 |  |  | 457.3 |  |  | 1,095.6 |  |  | 879.0 |  |
| Technical support and other | 423.7 |  |  | 362.9 |  |  | 831.2 |  |  | 702.8 |  |
| Total service revenue | 982.4 |  |  | 820.2 |  |  | 1,926.8 |  |  | 1,581.8 |  |
| Total revenue | $ | 1,434.3 |  |  | $ | 1,292.8 |  |  | $ | 2,787.6 |  |  | $ | 2,555.1 |  |

[0001262039-24-000037:notes:13]
[same as prior period, unchanged from 0001262039-24-000020:notes:13]

[0001262039-24-000037:notes:14]
During the three and six months ended June 30, 2024, we recognized $764.3 million and $1.62 billion in revenue that was included in the deferred revenue balance as of December 31, 2023, respectively. During the three and six months ended June 30, 2023, we recognized $609.8 million and $1.29 billion in revenue that was included in the deferred revenue balance as of December 31, 2022, respectively.

[0001262039-24-000037:notes:15]
[same as prior period, unchanged from 0001262039-24-000020:notes:15]

[0001262039-24-000037:notes:16]
As of June 30, 2024, the aggregate amount of the transaction price allocated to remaining performance obligations was $5.92 billion, which was substantially comprised of deferred security subscription and technical support services revenue that will be recognized in future periods. We expect to recognize approximately $2.99 billion as revenue over the next 12 months and the remainder thereafter.

[0001262039-24-000037:notes:17]
[same as prior period, unchanged from 0001262039-24-000020:notes:17]

[0001262039-24-000037:notes:18]
[same as prior period, unchanged from 0001262039-24-000020:notes:18]

[0001262039-24-000037:notes:19]
The allowance for credit losses was $5.7 million and $8.2 million as of June 30, 2024 and December 31, 2023, respectively. Provisions, write-offs and recoveries were not material during the six months ended June 30, 2024 and 2023.

[0001262039-24-000037:notes:20]
[same as prior period, unchanged from 0001262039-24-000020:notes:20]

[0001262039-24-000037:notes:21]
Amortization of deferred contract costs during the three months ended June 30, 2024 and 2023 were $72.7 million and $65.4 million, respectively. Amortization of deferred contract costs during the six months ended June 30, 2024 and 2023 were $144.7 million and $127.9 million, respectively.


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0001262039-24-000037:notes:22]
[same as prior period, unchanged from 0001262039-24-000020:notes:22]

[0001262039-24-000037:notes:23]
[same as prior period, unchanged from 0001262039-24-000020:notes:23]

[0001262039-24-000037:notes:24]
|  | June 30, 2024 |
|  | AmortizedCost |  | UnrealizedGains |  | UnrealizedLosses |  | FairValue |
| Commercial paper | $ | 483.1 |  |  | $ | — |  |  | $ | (0.4) |  |  | $ | 482.7 |  |
| U.S. government and agency securities | 481.2 |  |  | — |  |  | (0.3) |  |  | 480.9 |  |
| Corporate debt securities | 92.8 |  |  | — |  |  | (0.1) |  |  | 92.7 |  |
| Certificates of deposit and term deposits | 58.6 |  |  | — |  |  | — |  |  | 58.6 |  |
| Total available-for-sale investments | $ | 1,115.7 |  |  | $ | — |  |  | $ | (0.8) |  |  | $ | 1,114.9 |  |

[0001262039-24-000037:notes:25]
|  | December 31, 2023 |
|  | AmortizedCost |  | UnrealizedGains |  | UnrealizedLosses |  | FairValue |
| Commercial paper | $ | 401.7 |  |  | $ | 0.2 |  |  | $ | (0.1) |  |  | $ | 401.8 |  |
| U.S. government and agency securities | 461.5 |  |  | 0.2 |  |  | (0.3) |  |  | 461.4 |  |
| Corporate debt securities | 70.0 |  |  | 0.1 |  |  | (0.1) |  |  | 70.0 |  |
| Certificates of deposit and term deposits | 88.2 |  |  | 0.1 |  |  | — |  |  | 88.3 |  |
| Total available-for-sale investments | $ | 1,021.4 |  |  | $ | 0.6 |  |  | $ | (0.5) |  |  | $ | 1,021.5 |  |

[0001262039-24-000037:notes:26]
[same as prior period, unchanged from 0001262039-24-000020:notes:26]

[0001262039-24-000037:notes:27]
|  | June 30, 2024 |
|  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
|  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |
| Commercial paper | $ | 455.2 |  |  | $ | (0.4) |  |  | $ | — |  |  | $ | — |  |  | $ | 455.2 |  |  | $ | (0.4) |  |
| U.S. government and agency securities | 456.0 |  |  | (0.3) |  |  | — |  |  | — |  |  | 456.0 |  |  | (0.3) |  |
| Corporate debt securities | 88.5 |  |  | (0.1) |  |  | — |  |  | — |  |  | 88.5 |  |  | (0.1) |  |
| Total available-for-sale investments | $ | 999.7 |  |  | $ | (0.8) |  |  | $ | — |  |  | $ | — |  |  | $ | 999.7 |  |  | $ | (0.8) |  |

[0001262039-24-000037:notes:28]
|  | December 31, 2023 |
|  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
|  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |
| Commercial paper | $ | 200.8 |  |  | $ | (0.1) |  |  | $ | — |  |  | $ | — |  |  | $ | 200.8 |  |  | $ | (0.1) |  |
| U.S. government and agency securities | 47.1 |  |  | — |  |  | 11.7 |  |  | (0.3) |  |  | 58.8 |  |  | (0.3) |  |
| Corporate debt securities | 21.8 |  |  | — |  |  | 26.9 |  |  | (0.1) |  |  | 48.7 |  |  | (0.1) |  |
| Total available-for-sale investments | $ | 269.7 |  |  | $ | (0.1) |  |  | $ | 38.6 |  |  | $ | (0.4) |  |  | $ | 308.3 |  |  | $ | (0.5) |  |

[0001262039-24-000037:notes:29]
[same as prior period, unchanged from 0001262039-24-000020:notes:29]

[0001262039-24-000037:notes:30]
|  | June 30,2024 |  | December 31,2023 |
| Due within one year | $ | 1,114.9 |  |  | $ | 1,021.5 |  |
| Due within one to three years | — |  |  | — |  |
| Total | $ | 1,114.9 |  |  | $ | 1,021.5 |  |

[0001262039-24-000037:notes:31]
[same as prior period, unchanged from 0001262039-24-000020:notes:31]

[0001262039-24-000037:notes:32]
[same as prior period, unchanged from 0001262039-24-000020:notes:32]

[0001262039-24-000037:notes:33]
[same as prior period, unchanged from 0001262039-24-000020:notes:33]

[0001262039-24-000037:notes:34]
Our marketable equity securities were $21.2 million and $21.0 million as of June 30, 2024 and December 31, 2023. The changes in fair value of our marketable equity securities are recorded in other expense—net on the condensed consolidated statements of income. We recognized a $0.2 million loss and $0.1 million gain during the three and six months ended June 30, 2024, respectively. We recognized a $4.0 million loss and $3.4 million loss during the three and six months ended June 30, 2023, respectively.

[0001262039-24-000037:notes:35]
[same as prior period, unchanged from 0001262039-24-000020:notes:35]

[0001262039-24-000037:notes:36]
[same as prior period, unchanged from 0001262039-24-000020:notes:36]

[0001262039-24-000037:notes:37]
[same as prior period, unchanged from 0001262039-24-000020:notes:37]

[0001262039-24-000037:notes:38]
[same as prior period, unchanged from 0001262039-24-000020:notes:38]

[0001262039-24-000037:notes:39]
[same as prior period, unchanged from 0001262039-24-000020:notes:39]

[0001262039-24-000037:notes:40]
[same as prior period, unchanged from 0001262039-24-000020:notes:40]

[0001262039-24-000037:notes:41]
[same as prior period, unchanged from 0001262039-24-000020:notes:41]

[0001262039-24-000037:notes:42]
[same as prior period, unchanged from 0001262039-24-000020:notes:42]

[0001262039-24-000037:notes:43]
[same as prior period, unchanged from 0001262039-24-000020:notes:43]

[0001262039-24-000037:notes:44]
[same as prior period, unchanged from 0001262039-24-000020:notes:44]

[0001262039-24-000037:notes:45]
|  | June 30, 2024 |  | December 31, 2023 |
|  | AggregateFairValue |  | QuotedPrices inActiveMarkets ForIdenticalAssets |  | SignificantOtherObservableRemainingInputs |  | SignificantOtherUnobservableRemainingInputs |  | AggregateFairValue |  | QuotedPrices inActiveMarkets ForIdenticalAssets |  | SignificantOtherObservableRemainingInputs |  | SignificantOtherUnobservableRemainingInputs |
|  |  |  | (Level 1) |  | (Level 2) |  | (Level 3) |  |  |  | (Level 1) |  | (Level 2) |  | (Level 3) |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Commercial paper | $ | 514.5 |  |  | $ | — |  |  | $ | 514.5 |  |  | $ | — |  |  | $ | 472.2 |  |  | $ | — |  |  | $ | 472.2 |  |  | $ | — |  |
| U.S. government and agency securities | 484.4 |  |  | 461.9 |  |  | 22.5 |  |  | — |  |  | 501.4 |  |  | 433.3 |  |  | 68.1 |  |  | — |  |
| Corporate debt securities | 93.7 |  |  | — |  |  | 93.7 |  |  | — |  |  | 73.0 |  |  | — |  |  | 73.0 |  |  | — |  |
| Certificates of deposit and term deposits | 58.6 |  |  | — |  |  | 58.6 |  |  | — |  |  | 104.8 |  |  | — |  |  | 104.8 |  |  | — |  |
| Money market funds | 296.4 |  |  | 296.4 |  |  | — |  |  | — |  |  | 277.1 |  |  | 277.1 |  |  | — |  |  | — |  |
| Marketable equity securities | 21.2 |  |  | 21.2 |  |  | — |  |  | — |  |  | 21.0 |  |  | 21.0 |  |  | — |  |  | — |  |
| Total | $ | 1,468.8 |  |  | $ | 779.5 |  |  | $ | 689.3 |  |  | $ | — |  |  | $ | 1,449.5 |  |  | $ | 731.4 |  |  | $ | 718.1 |  |  | $ | — |  |
| Reported as: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents | $ | 332.7 |  |  |  |  |  |  |  |  | $ | 407.0 |  |  |  |  |  |  |  |
| Marketable equity securities | 21.2 |  |  |  |  |  |  |  |  | 21.0 |  |  |  |  |  |  |  |
| Short-term investments | 1,114.9 |  |  |  |  |  |  |  |  | 1,021.5 |  |  |  |  |  |  |  |
| Total | $ | 1,468.8 |  |  |  |  |  |  |  |  | $ | 1,449.5 |  |  |  |  |  |  |  |

[0001262039-24-000037:notes:46]
There were no transfers between Level 1 and Level 2 of the fair value hierarchy during the six months ended June 30, 2024 and year ended December 31, 2023.


## us-gaap:InventoryDisclosureTextBlock

[0001262039-24-000037:notes:47]
[same as prior period, unchanged from 0001262039-24-000020:notes:47]

[0001262039-24-000037:notes:48]
|  | June 30,2024 |  | December 31,2023 |
| Raw materials | $ | 96.0 |  |  | $ | 92.1 |  |
| Work in process | 7.3 |  |  | 7.7 |  |
| Finished goods | 279.9 |  |  | 385.0 |  |
| Inventory | $ | 383.2 |  |  | $ | 484.8 |  |

[0001262039-24-000037:notes:49]
The excess and obsolete inventory reserve was $128.0 million and $89.2 million as of June 30, 2024 and December 31, 2023, respectively. Inventory write-downs related to excess and obsolete inventory were $10.7 million and $28.8 million for the three and six months ended June 30, 2024, respectively, and were $7.2 million and $12.3 million for the three and six months ended June 30, 2023, respectively. These were recorded in cost of product revenue on the condensed consolidated statements of income.


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001262039-24-000037:notes:50]
[same as prior period, unchanged from 0001262039-24-000020:notes:50]

[0001262039-24-000037:notes:51]
|  | June 30,2024 |  | December 31,2023 |
| Land | $ | 453.0 |  |  | $ | 351.7 |  |
| Buildings and improvements | 713.3 |  |  | 595.5 |  |
| Computer equipment and software | 270.7 |  |  | 261.1 |  |
| Leasehold improvements | 67.0 |  |  | 61.4 |  |
| Evaluation units | 33.3 |  |  | 30.8 |  |
| Furniture and fixtures | 35.9 |  |  | 33.6 |  |
| Construction-in-progress | 65.2 |  |  | 63.3 |  |
| Total property and equipment | 1,638.4 |  |  | 1,397.4 |  |
| Less: accumulated depreciation | (395.7) |  |  | (353.0) |  |
| Property and equipment—net | $ | 1,242.7 |  |  | $ | 1,044.4 |  |

[0001262039-24-000037:notes:52]
During the three months ended March 31, 2024, we purchased certain real estate properties in California for a total purchase price of $207.1 million to be used predominantly for research and development and warehousing operations. The purchases were accounted for under the asset acquisition method. The cost of the assets allocated to land, buildings and improvements, and furniture and fixtures were $101.4 million, $104.8 million, and $0.9 million, respectively, based on their relative fair values.

[0001262039-24-000037:notes:53]
Depreciation expense was $25.9 million and $22.9 million during the three months ended June 30, 2024 and 2023, respectively. Depreciation expense was $51.5 million and $45.7 million during the six months ended June 30, 2024 and 2023, respectively.


## us-gaap:InvestmentTextBlock

[0001262039-24-000037:notes:54]
[same as prior period, unchanged from 0001262039-24-000020:notes:53]

[0001262039-24-000037:notes:55]
During 2021, we invested $160.0 million in cash for shares of the Series A Preferred Stock of privately held Linksys Holdings, Inc. (“Linksys”), for a 50.8% ownership interest in outstanding equity of Linksys. As of June 30, 2024 and December 31, 2023, our ownership interest remained the same. Linksys provides router connectivity solutions to the consumer and small business markets.

[0001262039-24-000037:notes:56]
We have concluded that our investment in Linksys is an in-substance common stock investment and that we do not hold an absolute controlling financial interest in Linksys, but that we have the ability to exercise significant influence over the operating and financial policies of Linksys. Therefore, we determined to account for this investment using the equity method of accounting. We record our share of Linksys’ financial results on a three-month lag basis, with the exception of material transactions or events that occur during the intervening period that materially affect the financial position or results of operations. We determined that there was a basis difference between the cost of our investment in Linksys and the amount of underlying equity in net assets of Linksys.

[0001262039-24-000037:notes:57]
Due to the presence of impairment indicators, such as a series of operating losses, current expected performance relative to expected performance as of the most recent previous quarter, organizational and go to market changes, performance relative to peers and the results of a discounted cash flows analysis, we evaluated our equity method investment for an other-than-temporary impairment (“OTTI”) during the second quarter of 2024. We considered various factors in determining whether an OTTI has occurred, including Linksys’ financial results, operating history, our ability and intent to hold the investment until its fair value recovers, the discounted cash flows analysis, Linksys’ ability to achieve milestones and any notable operational and strategic changes. After this evaluation, we noted that certain factors were present that indicate that the equity method investment’s decline in value is other-than-temporary, primarily driven by Linksys’ continuous losses, decrease in revenue and operating results, current forecasted results for the foreseeable future as compared to the expected performance as of the most recent previous quarter, and the results of a discounted cash flows analysis. To determine the fair value of our investment in Linksys, we utilized a market approach referencing revenue multiples from publicly traded peer companies and concluded that

[0001262039-24-000037:notes:58]
the estimated fair value of the investment was lower than its carrying value. During the three months ended June 30, 2024, we recorded a non-cash charge of $8.0 million related to impairment recognized on our equity method investment in Linksys.
Our loss from our Linksys investment totaled $11.8 million and $18.2 million for the three and six months ended June 30, 2024, respectively, which comprised of our proportionate share of Linksys' financial results as well as the amortization of the basis differences of $3.8 million and $10.2 million for the three and six months ended June 30, 2024, respectively, and an OTTI charge of $8.0 million. Our share of loss of Linksys’ financial results, as well as our share of the amortization of the basis differences, totaled $5.3 million and $27.4 million for the three and six months ended June 30, 2023, respectively. These losses and the OTTI charge were recorded in loss from equity method investments on the condensed consolidated statements of income. The carrying amount of our Linksys investment was $24.0 million and $42.2 million as of June 30, 2024 and December 31, 2023, respectively, and the investment was included in other assets on our condensed consolidated balance sheets.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001262039-24-000037:notes:59]
[same as prior period, unchanged from 0001262039-24-000020:notes:58]

[0001262039-24-000037:notes:60]
[same as prior period, unchanged from 0001262039-24-000020:notes:59]

[0001262039-24-000037:notes:61]
|  | Amount |
| Balance—December 31, 2023 | $ | 126.5 |  |
| Additions due to business combination | 3.9 |  |
| Foreign currency translation adjustments | (2.5) |  |
| Balance—June 30, 2024 | $ | 127.9 |  |

[0001262039-24-000037:notes:62]
There were no impairments to goodwill during the six months ended June 30, 2024 or during prior periods.

[0001262039-24-000037:notes:63]
[same as prior period, unchanged from 0001262039-24-000020:notes:62]

[0001262039-24-000037:notes:64]
[same as prior period, unchanged from 0001262039-24-000020:notes:63]

[0001262039-24-000037:notes:65]
|  | June 30, 2024 |
|  | Weighted-Average Useful Life (in Years) |  | Gross |  | Accumulated Amortization |  | Net |
| Other intangible assets—net: |  |  |  |  |  |  |  |
| Finite-lived intangible assets: |  |  |  |  |  |  |  |
| Developed technologies | 4.1 |  | $ | 79.0 |  |  | $ | 63.5 |  |  | $ | 15.5 |  |
| Customer relationships | 6.9 |  | 30.2 |  |  | 18.6 |  |  | 11.6 |  |
| Trade name | 10.0 |  | 4.3 |  |  | 1.2 |  |  | 3.1 |  |
| Backlog | 1.0 |  | 3.4 |  |  | 3.4 |  |  | — |  |
| Total other intangible assets—net |  |  | $ | 116.9 |  |  | $ | 86.7 |  |  | $ | 30.2 |  |

[0001262039-24-000037:notes:66]
[same as prior period, unchanged from 0001262039-24-000020:notes:65]

[0001262039-24-000037:notes:67]
Amortization expense was $3.3 million and $4.5 million during the three months ended June 30, 2024 and 2023, respectively. Amortization expense was $6.3 million and $9.2 million during the six months ended June 30, 2024 and 2023, respectively.

[0001262039-24-000037:notes:68]
[same as prior period, unchanged from 0001262039-24-000020:notes:67]

[0001262039-24-000037:notes:69]
|  | Amount |
| Years: |  |
| 2024 (the remainder of 2024) | $ | 6.2 |  |
| 2025 | 8.4 |  |
| 2026 | 4.7 |  |
| 2027 | 4.3 |  |
| 2028 | 1.5 |  |
| Thereafter | 5.1 |  |
| Total | $ | 30.2 |  |


## us-gaap:EarningsPerShareTextBlock

[0001262039-24-000037:notes:70]
[same as prior period, unchanged from 0001262039-24-000020:notes:69]

[0001262039-24-000037:notes:71]
[same as prior period, unchanged from 0001262039-24-000020:notes:70]

[0001262039-24-000037:notes:72]
|  | Three Months Ended |  | Six Months Ended |
|  | June 30,2024 |  | June 30,2023 |  | June 30,2024 |  | June 30,2023 |
| Numerator: |  |  |  |  |  |  |  |
| Net income | $ | 379.8 |  |  | $ | 266.3 |  |  | $ | 679.1 |  |  | $ | 514.0 |  |
| Denominator: |  |  |  |  |  |  |  |
| Basic shares: |  |  |  |  |  |  |  |
| Weighted-average common stock outstanding-basic | 763.8 |  |  | 785.0 |  |  | 763.1 |  |  | 784.1 |  |
| Diluted shares: |  |  |  |  |  |  |  |
| Weighted-average common stock outstanding-basic | 763.8 |  |  | 785.0 |  |  | 763.1 |  |  | 784.1 |  |
| Effect of potentially dilutive securities: |  |  |  |  |  |  |  |
| RSUs | 1.5 |  |  | 4.1 |  |  | 2.1 |  |  | 3.9 |  |
| Stock options | 4.5 |  |  | 6.6 |  |  | 4.8 |  |  | 6.6 |  |
| PSUs | 0.1 |  |  | 0.2 |  |  | 0.2 |  |  | 0.1 |  |
| Weighted-average shares used to compute diluted net income per share | 769.9 |  |  | 795.9 |  |  | 770.2 |  |  | 794.7 |  |
| Net income per share |  |  |  |  |  |  |  |
| Basic | $ | 0.50 |  |  | $ | 0.34 |  |  | $ | 0.89 |  |  | $ | 0.66 |  |
| Diluted | $ | 0.49 |  |  | $ | 0.33 |  |  | $ | 0.88 |  |  | $ | 0.65 |  |

[0001262039-24-000037:notes:73]
[same as prior period, unchanged from 0001262039-24-000020:notes:72]

[0001262039-24-000037:notes:74]
|  | Three Months Ended |  | Six Months Ended |
|  | June 30,2024 |  | June 30,2023 |  | June 30,2024 |  | June 30,2023 |
| RSUs | — |  |  | — |  |  | — |  |  | 0.9 |  |
| Stock options | 3.6 |  |  | 3.0 |  |  | 3.4 |  |  | 2.6 |  |
| PSUs | 0.2 |  |  | — |  |  | 0.1 |  |  | — |  |
| Total | 3.6 |  |  | 3.0 |  |  | 3.4 |  |  | 3.5 |  |


## us-gaap:DebtDisclosureTextBlock

[0001262039-24-000037:notes:75]
DEBT
2026 and 2031 Senior Notes

[0001262039-24-000037:notes:76]
On March 5, 2021, we issued $1.0 billion aggregate principal amount of senior notes (collectively, the “Senior Notes”), consisting of $500.0 million aggregate principal amount of 1.0% notes due March 15, 2026 (the “2026 Senior Notes”) and $500.0 million aggregate principal amount of 2.2% notes due March 15, 2031 (the “2031 Senior Notes”), in an underwritten registered public offering. The Senior Notes are senior unsecured obligations and rank equally with each other in right of payment and with our other outstanding obligations. We may redeem the Senior Notes at any time in whole or in part for cash, at specified redemption prices that include accrued and unpaid interest, if any, and a make-whole premium. However, no make-whole premium will be paid for redemptions of the 2026 Senior Notes on or after February 15, 2026, or the 2031 Senior Notes on or after December 15, 2030. Interest on the Senior Notes is payable on March 15 and September 15 of each year, beginning on September 15, 2021. As of June 30, 2024 and December 31, 2023, the Senior Notes were recorded as long-term debt, net of discount and issuance costs, which are amortized to interest expense over the respective contractual terms of these notes using the effective interest method.

[0001262039-24-000037:notes:77]
The total outstanding debt is summarized below (in millions, except percentages):

[0001262039-24-000037:notes:78]
|  | Maturity |  | Coupon Rate |  | Effective Interest Rate |  | June 30,2024 |  | December 31,2023 |
| Debt |  |  |  |  |  |  |  |  |  |
| 2026 Senior Notes | March 2026 |  | 1.0% |  | 1.3% |  | $ | 500.0 |  |  | $ | 500.0 |  |
| 2031 Senior Notes | March 2031 |  | 2.2% |  | 2.3% |  | 500.0 |  |  | 500.0 |  |
| Total debt |  |  |  |  |  |  | 1,000.0 |  |  | 1,000.0 |  |
| Less: Unamortized discount and debt issuance costs |  |  |  |  |  |  | 6.7 |  |  | 7.7 |  |
| Total long-term debt |  |  |  |  |  |  | $ | 993.3 |  |  | $ | 992.3 |  |

[0001262039-24-000037:notes:79]
As of June 30, 2024 and December 31, 2023, we accrued interest payable of $4.7 million, and there are no financial covenants with which we must comply. During the three months ended June 30, 2024 and 2023, we recorded $4.5 million of total interest expense in relation to these Senior Notes in each period. During the six months ended June 30, 2024 and 2023, we recorded $9.0 million of total interest expense in relation to these Senior Notes in each period. No interest costs were capitalized for the six months ended June 30, 2024 and 2023, as the costs that qualified for capitalization were not material.

[0001262039-24-000037:notes:80]
The total estimated fair value of the outstanding Senior Notes was approximately $880.6 million, including accrued and unpaid interest, as of June 30, 2024. The fair value was determined based on observable market prices of identical instruments in less active markets. The estimated fair values are based on Level 2 inputs.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001262039-24-000037:notes:81]
COMMITMENTS AND CONTINGENCIES
The following table summarizes our inventory purchase commitments as of June 30, 2024 (in millions):

[0001262039-24-000037:notes:82]
|  | Total |  | 2024 |  | Thereafter |
| Inventory purchase commitments | $ | 566.7 |  |  | $ | 500.1 |  |  | $ | 66.6 |  |

[0001262039-24-000037:notes:83]
Inventory Purchase Commitments—We purchase components of our inventory from certain suppliers and use several independent contract manufacturers to provide manufacturing services for our products. During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, we enter into agreements with contract manufacturers and suppliers that allow them to procure inventory based upon criteria as defined by us or establish the parameters defining our requirements. A significant portion of our reported purchase commitments arising from these agreements consists of firm, non-cancelable and unconditional commitments. Certain of these inventory purchase commitments with contract manufacturers and suppliers relate to arrangements to secure supply and pricing for certain product components for multi-year periods. In certain instances, these agreements allow us the option to reschedule and adjust our requirements based on our business needs prior to firm orders being placed.

[0001262039-24-000037:notes:84]
As of June 30, 2024, we had $566.7 million of non-cancelable inventory purchase commitments with our independent contract manufacturers. We recorded a liability for these purchase commitments for quantities in excess of our future estimated demand forecasts, consistent with the valuation of our excess and obsolete inventory. As of June 30, 2024 and December 31, 2023, the liability for these inventory purchase commitments was $105.2 million and $84.7 million, respectively, and was recorded in accrued liabilities on our condensed consolidated balance sheets. The expense related to such accrued liability for inventory purchase commitments was $7.0 million and $12.0 million during the three months ended June 30, 2024 and 2023, respectively, and was recorded in cost of product revenue on the condensed consolidated statements of income. The expense related to such accrued liability for inventory purchase commitments was $38.6 million and $22.4 million during the six months ended June 30, 2024 and 2023, respectively, and was recorded in cost of product revenue on the condensed consolidated statements of income.

[0001262039-24-000037:notes:85]
Other Contractual Commitments and Open Purchase Orders—In addition to commitments with contract manufacturers, we have open purchase orders and contractual obligations in the ordinary course of business for which we have not received goods or services. A significant portion of our reported purchase commitments consist of non-cancelable commitments. In certain instances, contractual commitments allow us the option to cancel, reschedule and adjust our requirements based on our business needs prior to firm orders being placed. As of June 30, 2024, we had $40.4 million in other contractual commitments having a remaining term in excess of one year that are non-cancelable.

[0001262039-24-000037:notes:86]
As of June 30, 2024, we had $82.9 million in contractual commitments related to payments for operating leases.

[0001262039-24-000037:notes:87]
Litigation—We are involved in disputes, litigation, and other legal actions. For lawsuits where we are the defendant, we are in the process of defending these litigation matters, and while there can be no assurances and the outcome of certain of these matters is currently not determinable and not predictable, we currently are unaware of any existing claims or proceedings that we believe are likely to have a material adverse effect on our financial position. There are many uncertainties associated with any litigation and these actions or other third-party claims against us may cause us to incur costly litigation fees, costs and substantial settlement charges, and possibly subject us to damages and other penalties. In addition, the resolution of any intellectual property (“IP”) litigation may require us to make royalty payments, which could adversely affect our gross margins in future periods. If any of those events were to occur, our business, financial condition, results of operations, and cash flows could be adversely affected. Litigation is unpredictable and the actual liability in any such matters may be materially different from our current estimates, which could result in the need to adjust any accrued liability and record additional expenses. We accrue for contingencies when we believe that a loss is probable and that we can reasonably estimate the amount of any such loss. These accruals are generally based on a range of possible outcomes that require significant management judgement. If no amount within a range is a better estimate than any other, we accrue the minimum amount. Litigation loss contingency accruals associated with outstanding cases were not material as of June 30, 2024, and December 31, 2023.

[0001262039-24-000037:notes:88]
On March 21, 2019, we were sued by Alorica Inc. (“Alorica”) in Santa Clara County Superior Court in California. Alorica has alleged breach of warranty and misrepresentation claims, which we deny. Fact discovery closed during the quarter ended June 30, 2023 and trial is currently set for September 2024. Although we believe that the ultimate outcome of this matter will not materially impact our financial position, results of operations or cash flows, legal proceedings are subject to inherent uncertainties, and an unfavorable ruling could occur, which may result in a material adverse impact on our business, financial position, results of operations and cash flows. No loss accrual had been recorded as of June 30, 2024 or December 31, 2023 related to this litigation.

[0001262039-24-000037:notes:89]
Indemnification and Other Matters—We enter into indemnification provisions in the ordinary course of business with other companies such as partners, customers, and vendors, where we agree to indemnify, hold harmless, and reimburse the indemnified party for certain losses suffered or incurred by the indemnified party as a result of our activities, including defending against third-party claims asserting various allegations such as product defects, breach of representations or covenants, and infringement of certain IP rights, which may include patents, copyrights, trademarks or trade secrets, and to pay judgments entered on such claims. In some contracts, our exposure under these indemnification provisions is limited by the terms of the contracts to certain defined limits, such as the total amount paid by our customer under the agreement. However, certain agreements include covenants, penalties and indemnification provisions including and beyond indemnification for third-party claims of IP infringement that could potentially expose us to losses in excess of the amount received under the agreement, and in some instances to potential liability that is not contractually limited. Although from time to time there are indemnification claims asserted against us and currently there are pending indemnification claims, to date there have been no material awards under such indemnification provisions.

[0001262039-24-000037:notes:90]
Similar to other security companies and companies in other industries, we have experienced and may experience in the future, cybersecurity threats, malicious activity directed against our information technology infrastructure or unauthorized attempts to gain access to our and our customers’ sensitive information and systems. We currently are unaware of any existing claims or proceedings related to these types of matters, including any that we believe are likely to have a material adverse effect on our financial position.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001262039-24-000037:notes:91]
[same as prior period, unchanged from 0001262039-24-000020:notes:91]

[0001262039-24-000037:notes:92]
We maintain the Amended and Restated Fortinet, Inc. 2009 Equity Incentive Plan (the “Amended Plan”) pursuant to which we have granted RSUs, stock options and PSUs. As of June 30, 2024, there were a total of 51.2 million shares of common stock available for grant under the Amended Plan.

[0001262039-24-000037:notes:93]
[same as prior period, unchanged from 0001262039-24-000020:notes:93]

[0001262039-24-000037:notes:94]
[same as prior period, unchanged from 0001262039-24-000020:notes:94]

[0001262039-24-000037:notes:95]
|  | Restricted Stock Units Outstanding |
|  | Number of Shares |  | Weighted-Average Grant Date Fair Value per Share |
| Balance—December 31, 2023 | 9.1 |  |  | $ | 53.61 |  |
| Granted | 3.0 |  |  | 64.89 |  |
| Forfeited | (0.5) |  |  | 56.99 |  |
| Vested | (2.7) |  |  | 48.62 |  |
| Balance—June 30, 2024 | 8.9 |  |  | $ | 58.81 |  |

[0001262039-24-000037:notes:96]
Stock compensation expense is recognized on a straight-line basis over the vesting period of each RSU. As of June 30, 2024, total compensation expense related to unvested RSUs granted to employees and non-employees under the Amended Plan, but not yet recognized, was $477.6 million, with a weighted-average remaining vesting period of 2.7 years.

[0001262039-24-000037:notes:97]
[same as prior period, unchanged from 0001262039-24-000020:notes:97]

[0001262039-24-000037:notes:98]
[same as prior period, unchanged from 0001262039-24-000020:notes:98]

[0001262039-24-000037:notes:99]
|  | Three Months Ended |  | Six Months Ended |
|  | June 30,2024 |  | June 30,2023 |  | June 30,2024 |  | June 30,2023 |
| Shares withheld for taxes | 0.3 |  |  | 0.4 |  |  | 0.9 |  |  | 1.1 |  |
| Amount withheld for taxes | $ | 20.2 |  |  | $ | 25.1 |  |  | $ | 63.1 |  |  | $ | 59.7 |  |

[0001262039-24-000037:notes:100]
[same as prior period, unchanged from 0001262039-24-000020:notes:100]

[0001262039-24-000037:notes:101]
[same as prior period, unchanged from 0001262039-24-000020:notes:101]

[0001262039-24-000037:notes:102]
|  | Three Months Ended |  | Six Months Ended |
|  | June 30,2024 |  | June 30,2023 |  | June 30,2024 |  | June 30,2023 |
| Expected term in years | 4.5 |  | 4.4 |  | 4.5 |  | 4.4 |
| Volatility | 41.9 | % |  | 41.0 | % |  | 42.8 | % |  | 41.9 | % |
| Risk-free interest rate | 4.4 | % |  | 3.8 | % |  | 4.3 | % |  | 4.2 | % |
| Dividend rate | — | % |  | — | % |  | — | % |  | — | % |

[0001262039-24-000037:notes:103]
[same as prior period, unchanged from 0001262039-24-000020:notes:103]

[0001262039-24-000037:notes:104]
|  | Options Outstanding |
|  | Numberof Shares |  | Weighted-AverageExercisePrice |  | Weighted-AverageRemainingContractualLife (Years) |  | AggregateIntrinsicValue |
| Balance—December 31, 2023 | 11.2 |  |  | $ | 31.14 |  |  | 3.3 |  | $ | 315.8 |  |
| Granted | 0.7 |  |  | 65.07 |  |  |  |  |  |
| Forfeited | (0.1) |  |  | 52.93 |  |  |  |  |  |
| Exercised | (1.4) |  |  | 14.25 |  |  |  |  |  |
| Balance—June 30, 2024 | 10.4 |  |  | $ | 35.29 |  |  |  |  |  |
| Options vested and expected to vest—June 30, 2024 | 10.4 |  |  | $ | 35.29 |  |  | 3.3 |  | $ | 266.5 |  |
| Options exercisable—June 30, 2024 | 7.8 |  |  | $ | 27.89 |  |  | 2.6 |  | $ | 255.5 |  |

[0001262039-24-000037:notes:105]
The aggregate intrinsic value represents the difference between the exercise price of stock options and the quoted market price of our common stock for all in-the-money stock options. Stock compensation expense is recognized on a straight-line basis over the vesting period of each stock option. As of June 30, 2024, total compensation expense related to unvested stock options granted to employees but not yet recognized was $55.7 million, with a weighted-average remaining vesting period of 2.6 years.

[0001262039-24-000037:notes:106]
[same as prior period, unchanged from 0001262039-24-000020:notes:106]

[0001262039-24-000037:notes:107]
|  | Three Months Ended |  | Six Months Ended |
|  | June 30,2024 |  | June 30,2023 |  | June 30,2024 |  | June 30,2023 |
| Weighted-average fair value per share granted | $ | 24.93 |  |  | $ | 26.55 |  |  | $ | 26.79 |  |  | $ | 24.41 |  |
| Intrinsic value of options exercised | $ | 18.1 |  |  | $ | 24.3 |  |  | $ | 69.9 |  |  | $ | 97.0 |  |
| Fair value of options vested | $ | 6.5 |  |  | $ | 5.7 |  |  | $ | 18.6 |  |  | $ | 17.4 |  |

[0001262039-24-000037:notes:108]
[same as prior period, unchanged from 0001262039-24-000020:notes:108]

[0001262039-24-000037:notes:109]
[same as prior period, unchanged from 0001262039-24-000020:notes:109]

[0001262039-24-000037:notes:110]
[same as prior period, unchanged from 0001262039-24-000020:notes:110]

[0001262039-24-000037:notes:111]
|  | Three Months Ended |  | Six Months Ended |
|  | June 30,2024 |  | June 30,2023 |  | June 30,2024 |  | June 30,2023 |
| Expected term in years | 2.8 |  | 2.7 |  | 2.7 |  | 2.7 |
| Volatility | 44.5 | % |  | 47.5 | % |  | 45.4 | % |  | 47.5 | % |
| Risk-free interest rate | 4.6 | % |  | 4.6 | % |  | 4.5 | % |  | 4.6 | % |
| Dividend rate | — | % |  | — | % |  | — | % |  | — | % |

[0001262039-24-000037:notes:112]
We granted less than 0.1 million shares of PSU awards and approximately 0.3 million shares of PSU awards with a weighted-average grant date fair value of $73.00 and $97.22 per share to certain of our executives during the three and six months ended June 30, 2024, respectively. We granted approximately 0.3 million shares of PSU awards with a weighted-average grant date fair value of $90.96 per share to certain of our executives during the three and six months ended June 30, 2023. The grant date fair value of these awards was determined using a Monte Carlo simulation pricing model. Approximately 0.1 million shares of PSU awards vested during the first quarter of 2024. No shares of PSU awards vested during the second quarter of 2024 or the six months ended June 30, 2023. Approximately 0.1 million shares of PSU awards were forfeited during the three and six months ended June 30, 2024. None of these PSU awards were forfeited during the six months ended June 30, 2023.

[0001262039-24-000037:notes:113]
As of June 30, 2024, total compensation expense related to unvested PSUs that were granted to certain of our executives, but not yet recognized, was $31.6 million. This expense is expected to be amortized on a graded vesting method over a weighted-average vesting period of 2.4 years.

[0001262039-24-000037:notes:114]
[same as prior period, unchanged from 0001262039-24-000020:notes:114]

[0001262039-24-000037:notes:115]
[same as prior period, unchanged from 0001262039-24-000020:notes:115]

[0001262039-24-000037:notes:116]
|  | Three Months Ended |  | Six Months Ended |
|  | June 30,2024 |  | June 30,2023 |  | June 30,2024 |  | June 30,2023 |
| Cost of product revenue | $ | 0.4 |  |  | $ | 0.5 |  |  | $ | 0.9 |  |  | $ | 0.9 |  |
| Cost of service revenue | 6.5 |  |  | 6.0 |  |  | 12.7 |  |  | 11.1 |  |
| Research and development | 21.3 |  |  | 20.0 |  |  | 41.1 |  |  | 37.0 |  |
| Sales and marketing | 25.9 |  |  | 29.3 |  |  | 52.6 |  |  | 55.6 |  |
| General and administrative | 10.2 |  |  | 9.9 |  |  | 20.0 |  |  | 18.1 |  |
| Total stock-based compensation expense | $ | 64.3 |  |  | $ | 65.7 |  |  | $ | 127.3 |  |  | $ | 122.7 |  |

[0001262039-24-000037:notes:117]
[same as prior period, unchanged from 0001262039-24-000020:notes:117]

[0001262039-24-000037:notes:118]
|  | Three Months Ended |  | Six Months Ended |
|  | June 30,2024 |  | June 30,2023 |  | June 30,2024 |  | June 30,2023 |
| RSUs | $ | 54.0 |  |  | $ | 55.1 |  |  | $ | 106.0 |  |  | $ | 104.2 |  |
| Stock options | 7.1 |  |  | 7.3 |  |  | 14.4 |  |  | 14.0 |  |
| PSUs | 3.2 |  |  | 3.3 |  |  | 6.9 |  |  | 4.5 |  |
| Total stock-based compensation expense | $ | 64.3 |  |  | $ | 65.7 |  |  | $ | 127.3 |  |  | $ | 122.7 |  |

[0001262039-24-000037:notes:119]
[same as prior period, unchanged from 0001262039-24-000020:notes:119]

[0001262039-24-000037:notes:120]
|  | Three Months Ended |  | Six Months Ended |
|  | June 30,2024 |  | June 30,2023 |  | June 30,2024 |  | June 30,2023 |
| Income tax benefit associated with stock-based compensation | $ | 14.3 |  |  | $ | 14.5 |  |  | $ | 28.2 |  |  | $ | 27.1 |  |

[0001262039-24-000037:notes:121]
[same as prior period, unchanged from 0001262039-24-000020:notes:121]

[0001262039-24-000037:notes:122]
[same as prior period, unchanged from 0001262039-24-000020:notes:122]

[0001262039-24-000037:notes:123]
There were no shares repurchased under the Repurchase Program during the six months ended June 30, 2024. As of June 30, 2024, $1.03 billion remained available for future share repurchases under the Repurchase Program.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001262039-24-000037:notes:124]
INCOME TAXES
Our effective tax rate was 16% for the three months ended June 30, 2024, compared to an effective tax rate of 9% for the same period last year. Our effective tax rate was 14% for the six months ended June 30, 2024, compared to an effective tax rate of 8% for the same period last year. The tax rates for the three months ended June 30, 2024 and 2023 were composed of U.S. federal and state taxes, withholding taxes and foreign taxes that amounted to $109.9 million and $84.8 million, respectively. The tax rate for the three months ended June 30, 2024 was impacted by a tax benefit of $27.2 million from the foreign-derived intangible income (“FDII”) deduction, and excess tax benefits from stock-based compensation expense of $6.2 million. The tax rate for the three months ended June 30, 2023 was impacted by a tax benefit of $25.8 million from the FDII deduction, excess tax benefits from stock-based compensation expense of $13.3 million, and the release of reserves of $18.1 million on uncertain tax positions and the accrued interest thereon due to the expiration of statues of limitations.

[0001262039-24-000037:notes:125]
The tax rates for the six months ended June 30, 2024 and 2023 were composed of U.S. federal and state taxes, withholding taxes and foreign taxes that amounted to $191.3 million and $170.6 million, respectively. The tax rate for the six months ended June 30, 2024 was impacted by a tax benefit of $50.8 million from the FDII deduction, and excess tax benefits from stock-based compensation expense of $24.5 million. The tax rate for the six months ended June 30, 2023 was impacted by a tax benefit of $64.0 million from the FDII deduction, excess tax benefits from stock-based compensation expense of $39.6 million, and the release of reserves of $18.1 million on uncertain tax positions and the accrued interest thereon due to the expiration of statutes of limitations.

[0001262039-24-000037:notes:126]
As of June 30, 2024 and December 31, 2023, unrecognized tax benefits were $68.3 million and $65.8 million, respectively. If recognized, $57.4 million of the unrecognized tax benefits as of June 30, 2024 would favorably affect our effective tax rate. It is our policy to include accrued interest and penalties related to unrecognized tax benefits in income tax expense. As of June 30, 2024 and December 31, 2023, accrued interest and penalties were $7.5 million and $6.4 million, respectively. It is reasonably possible that our gross unrecognized tax benefits will decrease by up to $3.9 million in the next 12

[0001262039-24-000037:notes:127]
months, due to the lapse of statutes of limitation in various jurisdictions. This decrease, if recognized, would favorably impact our effective tax rate, and would be recognized as an additional tax benefit.

[0001262039-24-000037:notes:128]
[same as prior period, unchanged from 0001262039-24-000020:notes:126]

[0001262039-24-000037:notes:129]
On January 4, 2022, the U.S. Treasury published another tranche of final regulations regarding the foreign tax credit. These final regulations impose new requirements that a foreign tax must meet in order to be creditable against U.S. income taxes, and generally apply to tax years beginning on or after December 28, 2021. On July 26, 2022, the U.S. Treasury released corrections to the final regulations. On July 21, 2023, the IRS released a notice that suspended the application of significant portions of the final regulations regarding the foreign tax credit for tax years 2022 and 2023. The notice released in July 2023 favorably impacted our ability to claim foreign tax credits in the United States for certain taxes imposed by certain foreign jurisdictions. On December 11, 2023, the IRS released a notice that extended the suspension of significant portions of the final regulations beyond December 31, 2023, until further guidance is issued. 
In December 2021, the Organisation for Economic Co-operation and Development (the “OECD”) enacted model rules for a new global minimum tax framework (“BEPS Pillar Two”), and various governments around the world have enacted, or are in the process of enacting, legislation on this. The OECD continues to release additional guidance on these rules. Based on the enacted laws, BEPS Pillar Two has no impact to our effective tax rate or cash flows for the six months ended June 30, 2024. We will continue to evaluate the impact of these tax law changes on future reporting periods.


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0001262039-24-000037:notes:130]
DEFINED CONTRIBUTION PLANS
Our tax-deferred savings plan under our 401(k) Plan permits participating U.S. employees to contribute a portion of their pre-tax or after-tax earnings. In Canada, we have a Group Registered Retirement Savings Plan Program (the “RRSP”), which permits participants to make pre-tax contributions. Our board of directors approved 50% matching contributions on employee contributions up to 4% of each employee’s eligible earnings. Our matching contributions to our 401(k) Plan and the RRSP for the three months ended June 30, 2024 and 2023 were $4.3 million and $5.7 million, respectively. Our matching contributions to our 401(k) Plan and the RRSP for the six months ended June 30, 2024 and 2023 were $10.6 million and $10.1 million, respectively.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001262039-24-000037:notes:131]
[same as prior period, unchanged from 0001262039-24-000020:notes:129]

[0001262039-24-000037:notes:132]
[same as prior period, unchanged from 0001262039-24-000020:notes:130]

[0001262039-24-000037:notes:133]
|  | Three Months Ended |  | Six Months Ended |
| Revenue | June 30,2024 |  | June 30,2023 |  | June 30,2024 |  | June 30,2023 |
| Americas: |  |  |  |  |  |  |  |
| United States | $ | 435.7 |  |  | $ | 404.7 |  |  | $ | 842.8 |  |  | $ | 788.8 |  |
| Other Americas | 159.6 |  |  | 132.3 |  |  | 309.5 |  |  | 271.7 |  |
| Total Americas | 595.3 |  |  | 537.0 |  |  | 1,152.3 |  |  | 1,060.5 |  |
| Europe, Middle East and Africa (“EMEA”) | 565.2 |  |  | 506.9 |  |  | 1,104.6 |  |  | 985.1 |  |
| Asia Pacific (“APAC”) | 273.8 |  |  | 248.9 |  |  | 530.7 |  |  | 509.5 |  |
| Total revenue | $ | 1,434.3 |  |  | $ | 1,292.8 |  |  | $ | 2,787.6 |  |  | $ | 2,555.1 |  |

[0001262039-24-000037:notes:134]
| Property and Equipment—net | June 30,2024 |  | December 31,2023 |
| Americas: |  |  |  |
| United States | $ | 906.1 |  |  | $ | 701.6 |  |
| Canada | 208.5 |  |  | 212.8 |  |
| Latin America | 2.8 |  |  | 2.3 |  |
| Total Americas | 1,117.4 |  |  | 916.7 |  |
| EMEA | 66.8 |  |  | 65.5 |  |
| APAC | 58.5 |  |  | 62.2 |  |
| Total property and equipment—net | $ | 1,242.7 |  |  | $ | 1,044.4 |  |

[0001262039-24-000037:notes:135]
[same as prior period, unchanged from 0001262039-24-000020:notes:133]

[0001262039-24-000037:notes:136]
|  | Three Months Ended |  | Six Months Ended |
|  | June 30,2024 |  | June 30,2023 |  | June 30,2024 |  | June 30,2023 |
| Distributor A | 30 | % |  | 27 | % |  | 29 | % |  | 28 | % |
| Distributor B | 16 | % |  | 15 | % |  | 15 | % |  | 14 | % |
| Distributor C | 14 | % |  | 14 | % |  | 13 | % |  | 14 | % |

[0001262039-24-000037:notes:137]
[same as prior period, unchanged from 0001262039-24-000020:notes:135]

[0001262039-24-000037:notes:138]
|  | June 30,2024 |  | December 31,2023 |
| Distributor A | 30 | % |  | 33 | % |
| Distributor B | 13 | % |  | 14 | % |
| Distributor C | 11 | % |  | 10 | % |


## us-gaap:SubsequentEventsTextBlock

[0001262039-24-000037:notes:139]
SUBSEQUENT EVENTS 
Acquisition of Lacework, Inc.

[0001262039-24-000037:notes:140]
On August 1, 2024 (“Lacework Acquisition Date”), we completed the acquisition of Lacework, Inc. (“Lacework”), a privately held data-driven cloud security company, for approximately $149 million in cash, net of cash acquired. We intend to integrate Lacework’s Cloud-Native Application Protection Platform solution into our existing portfolio. Given the short period of time between the Lacework Acquisition Date and the condensed consolidated financial statements in this Quarterly Report on Form 10-Q, the preliminary allocation of the cash purchase price to the fair value of assets acquired and liabilities assumed has not yet been completed.

[0001262039-24-000037:notes:141]
Acquisition of Next DLP Holdings Limited

[0001262039-24-000037:notes:142]
On August 5, 2024 (“Next DLP Acquisition Date”), we completed the acquisition of Next DLP Holdings Limited (“Next DLP”), a privately-held company that focuses on insider risk and data loss protection (“DLP”), for approximately $96 million in cash, net of cash acquired. With this acquisition, we will improve our position in the standalone enterprise DLP market and strengthen our leadership in integrated DLP markets within endpoint and SASE in alignment with our business strategy. Given the short period of time between the Next DLP Acquisition Date and the issuance of the condensed consolidated financial statements in this Quarterly Report on Form 10-Q, the preliminary allocation of the cash purchase price to the fair value of assets acquired and liabilities assumed has not yet been completed.

[0001262039-24-000037:notes:143]
Real Property Purchases

[0001262039-24-000037:notes:144]
In July and August 2024, we signed definitive agreements to purchase real property in Calgary, Canada, and Union City, California, for $6.5 million and $16.2 million in cash, respectively.


## ecd:MtrlTermsOfTrdArrTextBlock

[0001262039-24-000037:notes:145]
On May 22, 2024, John Whittle, our Chief Operating Officer, entered into a pre-arranged written stock sale plan in accordance with Rule 10b5-1 under the Exchange Act for the sale of shares of our common stock (the “Whittle Plan”) during an open trading window in accordance with our insider trading policy. The Whittle Plan is intended to satisfy the affirmative defense of Rule 10b5-1(c) under the Exchange Act. The Whittle Plan provides for the potential sale by Mr. Whittle of up to 141,820 shares of our common stock, issued upon the exercise of vested options to purchase shares of our common stock, at the market price, between August 21, 2024 and February 20, 2026.

[0001262039-24-000037:notes:146]
The Whittle Plan includes a representation from Mr. Whittle to the broker administering the plan that he was not in possession of any material nonpublic information regarding us or the securities subject to the Whittle Plan at the time that he entered into the Whittle Plan. He made a similar representation to us in connection with the adoption of the Whittle Plan under our insider trading policy. The representation was made as of May 22, 2024 and speaks only as of that date. In making the representation, Mr. Whittle did not provide assurance with respect to any material nonpublic information of which he was unaware, or with respect to any material nonpublic information acquired by him or us after the date of the representation.

[0001262039-24-000037:notes:147]
Once executed, transactions under the Whittle Plan will be disclosed publicly through Form 4 and/or Form 144 filings with the SEC in accordance with applicable securities laws, rules and regulations. Except as may be required by law, we do not undertake any obligation to update or report any modification, termination or other activity under current or future Rule 10b5-1 plans that may be adopted by Mr. Whittle or our other officers or directors or their affiliated entities.
