# FTNT MD&A — 0001262039-24-000037


## mdna

[0001262039-24-000037:mdna:1]
[same as prior period, unchanged from 0001262039-24-000020:mdna:1]

[0001262039-24-000037:mdna:2]
[same as prior period, unchanged from 0001262039-24-000020:mdna:2]

[0001262039-24-000037:mdna:3]
[same as prior period, unchanged from 0001262039-24-000020:mdna:3]

[0001262039-24-000037:mdna:4]
[same as prior period, unchanged from 0001262039-24-000020:mdna:4]

[0001262039-24-000037:mdna:5]
[same as prior period, unchanged from 0001262039-24-000020:mdna:5]

[0001262039-24-000037:mdna:6]
[same as prior period, unchanged from 0001262039-24-000020:mdna:6]

[0001262039-24-000037:mdna:7]
•macroeconomic, geopolitical factors and other disruption on our manufacturing or sales, including public health issues, wars, natural disasters and economic growth;

[0001262039-24-000037:mdna:8]
[same as prior period, unchanged from 0001262039-24-000020:mdna:8]

[0001262039-24-000037:mdna:9]
[same as prior period, unchanged from 0001262039-24-000020:mdna:9]

[0001262039-24-000037:mdna:10]
[same as prior period, unchanged from 0001262039-24-000020:mdna:10]

[0001262039-24-000037:mdna:11]
•our ability to successfully anticipate market changes including those related to cloud-based solutions and to sell, support and meet service level agreements related to cloud-based solutions;

[0001262039-24-000037:mdna:12]
[same as prior period, unchanged from 0001262039-24-000020:mdna:12]

[0001262039-24-000037:mdna:13]
[same as prior period, unchanged from 0001262039-24-000020:mdna:13]

[0001262039-24-000037:mdna:14]
[same as prior period, unchanged from 0001262039-24-000020:mdna:14]

[0001262039-24-000037:mdna:15]
•the effect of backlog from current or prior quarters, including its effect on growth of in-quarter billings and revenue;

[0001262039-24-000037:mdna:16]
[same as prior period, unchanged from 0001262039-24-000020:mdna:16]

[0001262039-24-000037:mdna:17]
[same as prior period, unchanged from 0001262039-24-000020:mdna:17]

[0001262039-24-000037:mdna:18]
•trends in revenue, cost of revenue and gross margin, including expectations regarding product revenue, service revenue growth and inventory related charges;

[0001262039-24-000037:mdna:19]
•trends in our operating expense, including sales and marketing expense, research and development expense, general and administrative expense, and expectations regarding these expenses;

[0001262039-24-000037:mdna:20]
[same as prior period, unchanged from 0001262039-24-000020:mdna:20]

[0001262039-24-000037:mdna:21]
•expectations that our operating expense will increase year over year in absolute dollars during the remainder of 2024;

[0001262039-24-000037:mdna:22]
[same as prior period, unchanged from 0001262039-24-000020:mdna:23]

[0001262039-24-000037:mdna:23]
[same as prior period, unchanged from 0001262039-24-000020:mdna:24]

[0001262039-24-000037:mdna:24]
•expectations regarding spending related to real estate assets, acquisitions and development, including data centers and points of presence, office building and warehouse investments, as well as other capital expenditures and to the impact on free cash flow and expenses;

[0001262039-24-000037:mdna:25]
[same as prior period, unchanged from 0001262039-24-000020:mdna:26]

[0001262039-24-000037:mdna:26]
•expected outcomes and liabilities in litigation;

[0001262039-24-000037:mdna:27]
[same as prior period, unchanged from 0001262039-24-000020:mdna:28]

[0001262039-24-000037:mdna:28]
[same as prior period, unchanged from 0001262039-24-000020:mdna:29]

[0001262039-24-000037:mdna:29]
[same as prior period, unchanged from 0001262039-24-000020:mdna:30]

[0001262039-24-000037:mdna:30]
[same as prior period, unchanged from 0001262039-24-000020:mdna:31]

[0001262039-24-000037:mdna:31]
Fortinet is a leader in cybersecurity and the convergence of networking and security. Our mission is to secure people, devices and data everywhere. Our integrated platform, the Fortinet Security Fabric, spans secure networking, unified SASE and AI-driven security operations to deliver cybersecurity where our customers need it. As of June 30, 2024, over a half million customers trusted our solutions, including enterprises such as in the financial services, retail, healthcare and operational technology market verticals, communication and security service providers, and government organizations. As a global company headquartered in Sunnyvale, California our research and development is centered in the United States and Canada with a global footprint of support and centers of excellence around the world. As of June 30, 2024, we held 985 U.S. patents and 1,323 global patents and we are recognized in over 100 enterprise analyst reports demonstrating both our vision and execution across security and networking products.

[0001262039-24-000037:mdna:32]
•Secure Networking—Our Secure Networking solutions focus on the convergence of networking and security via FortiOS, our networking and security operating system that is the foundation of our Fortinet Security Fabric platform and supports over 30 functions that can be delivered via a physical, virtual, cloud or software as a service (“SaaS”) solution. When delivered via our network firewall appliances, functionality is accelerated through our proprietary ASIC technology. These proprietary ASICs, allow our systems to scale, run multiple applications at higher performance, lower power consumption and perform more processor-intensive operations, such as inspecting encrypted traffic, including streaming video. The Network Firewall solution consists of FortiGate data centers, hyperscale and distributed firewalls, as well as encrypted applications (SSL inspection, Virtual Private Network and IPsec connectivity). Our ability to converge networking and security also enables the ethernet to become an extension of a company’s security infrastructure through FortiSwitch and FortiLink. Our wireless LAN solution leverages secure networking to provide secure wireless access for the enterprise LAN edge. FortiExtender secures 5G/LTE and remote

[0001262039-24-000037:mdna:33]
ethernet extenders to connect and secure any branch environment. The Secure Connectivity solution includes FortiSwitch Secure Ethernet Switches, FortiAP Wireless Local Area Network Access Points and FortiExtender 5G Connectivity Gateways.

[0001262039-24-000037:mdna:34]
[same as prior period, unchanged from 0001262039-24-000020:mdna:35]

[0001262039-24-000037:mdna:35]
[same as prior period, unchanged from 0001262039-24-000020:mdna:36]

[0001262039-24-000037:mdna:36]
[same as prior period, unchanged from 0001262039-24-000020:mdna:37]

[0001262039-24-000037:mdna:37]
[same as prior period, unchanged from 0001262039-24-000020:mdna:38]

[0001262039-24-000037:mdna:38]
Additionally, Fortinet is committed to addressing the cybersecurity skills shortage through training and certification programs for customers, partners and employees. The Fortinet Training Institute’s ecosystem of public and private partnerships around the world extend to industry, academia, government and nonprofits to ensure we are reaching and increasing access of our cybersecurity certifications and training to all populations. The Fortinet Training Institute has issued over 1 million certifications to date.

[0001262039-24-000037:mdna:39]
[same as prior period, unchanged from 0001262039-24-000020:mdna:40]

[0001262039-24-000037:mdna:40]
•Total revenue was $1.43 billion and $2.79 billion during the three and six months ended June 30, 2024, an increase of 11% and 9%, respectively, compared to $1.29 billion and $2.56 billion in the same periods last year. Our revenue growth was driven by the growth in service revenue. Product revenue was $451.9 million and $860.8 million during the three and six months ended June 30, 2024, a decrease of 4% and 12%, respectively, compared to $472.6 million and $973.3 million in the same periods last year. Service revenue was $982.4 million and $1.93 billion during the three and six months ended June 30, 2024, an increase of 20% and 22%, respectively, compared to $820.2 million and $1.58 billion in the same periods last year.

[0001262039-24-000037:mdna:41]
•Total gross profit was $1.16 billion and $2.21 billion during the three and six months ended June 30, 2024, an increase of 16% and 13%, respectively, compared to $997.0 million and $1.95 billion in the same periods last year.

[0001262039-24-000037:mdna:42]
•Total gross margin was 80.8% and 79.2% during the three and six months ended June 30, 2024, an increase of 3.7 and 2.8 percentage points, respectively, compared to 77.1% and 76.4% in the same periods last year.

[0001262039-24-000037:mdna:43]
•Operating income was $437.2 million and $758.4 million during the three and six months ended June 30, 2024, an increase of 57% and 37%, respectively, compared to $279.0 million and $552.5 million in the same periods last year.

[0001262039-24-000037:mdna:44]
•Operating margin was 30.5% and 27.2% during the three and six months ended June 30, 2024, an increase of 8.9 and 5.6 percentage points, respectively, compared to 21.6% in the same periods last year.

[0001262039-24-000037:mdna:45]
•Cash, cash equivalents, short-term and long-term investments and marketable equity securities were $3.34 billion as of June 30, 2024.

[0001262039-24-000037:mdna:46]
•Deferred revenue was $5.90 billion, including short-term deferred revenue of $2.98 billion, as of June 30, 2024.

[0001262039-24-000037:mdna:47]
•Cash flows from operating activities were $1.17 billion during the six months ended June 30, 2024, a decrease of $20.2 million, or 2%, compared to the same period last year.

[0001262039-24-000037:mdna:48]
On a geographic basis, revenue continues to be diversified globally, which remains a key strength of our business. During the three months ended June 30, 2024, the Americas region, the Europe, Middle East and Africa (“EMEA”) region, and the Asia Pacific (“APAC”) region contributed 42%, 39% and 19% of our total revenue, respectively and increased 11%, 12%, and 10% compared to the same period last year, respectively. During the six months ended June 30, 2024, the Americas, EMEA, and APAC regions contributed 41%, 40% and 19% of our total revenue, respectively, and increased by 9%, 12% and 4% compared to the same period last year, respectively.

[0001262039-24-000037:mdna:49]
Product revenue decreased 4% and 12%, respectively, during the three and six months ended June 30, 2024 compared to the same periods last year, due to the decrease in hardware revenue, partially offset by the increase in software revenue. The decrease in hardware revenue was impacted by the change in backlog from hardware shipped in the prior periods, reduced net prices on certain products and macroeconomic conditions. When we fulfill, ship and bill during a quarter to satisfy backlog, this increases our aggregate billings and revenue during any particular quarter. As the supply chain challenges normalize, our product revenue growth rate may be lower versus prior quarters where delivery from backlog contributed more to billings. For the remainder of 2024, we expect product revenue growth rates will continue to be impacted by drawdown of backlog and pricing actions in earlier periods.

[0001262039-24-000037:mdna:50]
Service revenue growth during the three and six months ended June 30, 2024 was 20% and 22%, respectively, as compared to the same periods last year, was primarily driven by the strength of our security subscription revenue, which grew 22% and 25%, respectively. The increase was primarily due to the recognition of service revenue from our growing deferred revenue balance related to FortiGuard and other security subscriptions delivered to on-premise and cloud-based environments and strength in unified SASE and SecOps. We expect our service revenue to continue to grow for the remainder of 2024, with growth opportunities that include unified SASE and SecOps offerings. While service revenue is expected to grow, we anticipate that the growth rates will ease for the remainder of 2024.

[0001262039-24-000037:mdna:51]
Our billings were diversified on a geographic basis. During the three months ended June 30, 2024, seven countries represented approximately 50% of our billings and the remaining 50% in the aggregate were from over 100 countries that each individually contributed less than 3% of our billings.

[0001262039-24-000037:mdna:52]
Operating expenses as a percentage of revenue decreased 5.2 and 2.8 percentage points, respectively, during the three and six months ended June 30, 2024 compared to the same periods last year, mainly driven by a decrease in personnel-related costs in sales and marking and a decrease in marketing expenses. Headcount decreased to 13,527 employees and contractors as of June 30, 2024, comparatively flat compared to 13,568 as of December 31, 2023.

[0001262039-24-000037:mdna:53]
Impact of Macroeconomic and Geopolitical Developments

[0001262039-24-000037:mdna:54]
Our overall performance depends in part on worldwide economic and geopolitical conditions, such GDP growth, the war in Ukraine and the Israel-Hamas war or tensions between China and Taiwan, and their impact on customer behavior. Worsening economic conditions, including inflation, higher interest rates, slower growth, any recession, fluctuations in foreign exchange rates and other changes in economic conditions, may result in decreased sales productivity and growth and adversely affect our results of operations and financial performance. We have seen certain impacts on our business, results of operations, financial condition, cash flows, liquidity and capital and financial resources such as longer sales cycles, delayed purchases and increased commitments with certain suppliers and increased inventory and inventory purchase commitment reserves.

[0001262039-24-000037:mdna:55]
[same as prior period, unchanged from 0001262039-24-000020:mdna:54]

[0001262039-24-000037:mdna:56]
[same as prior period, unchanged from 0001262039-24-000020:mdna:55]

[0001262039-24-000037:mdna:57]
We typically sell our security solutions to distributors that sell to networking security focused resellers and to certain service providers and managed security service providers (“MSSPs”), who, in turn, sell to end-customers or use our products and services to provide hosted solutions to other enterprises. At times, we also sell directly to certain large enterprise customers, large service providers and major systems integrators. In addition, we sell our software licenses and services via different cloud service provider platforms, both directly and through our channel partners. Our end-customers are located in over 100 countries and include small, medium and large enterprises and government organizations across a wide range of industries, including financial services, government, healthcare, manufacturing, retail, technology and telecommunications. An end-customer deployment may involve as few as one or as many as thousands of secure networking, unified SASE and security operations technology products, depending on the end-customer’s size and security requirements.

[0001262039-24-000037:mdna:58]
Our customers purchase our hardware products, software licenses and cloud-delivered solutions, as well as our FortiGuard and other security subscription and FortiCare technical support services. We generally invoice at the time of our sale for the total price of the products and services. Standard payment terms are generally no more than 60 days, though we may offer extended payment terms to certain distributors or certain transactions.

[0001262039-24-000037:mdna:59]
[same as prior period, unchanged from 0001262039-24-000020:mdna:59]

[0001262039-24-000037:mdna:60]
[same as prior period, unchanged from 0001262039-24-000020:mdna:60]

[0001262039-24-000037:mdna:61]
[same as prior period, unchanged from 0001262039-24-000020:mdna:61]

[0001262039-24-000037:mdna:62]
|  | Three Months Ended Or As Of |
|  | June 30, 2024 |  | June 30, 2023 |
|  | (in millions) |
| Revenue | $ | 1,434.3 |  |  | $ | 1,292.8 |  |
| Deferred revenue | $ | 5,896.2 |  |  | $ | 5,128.6 |  |
| Billings (non-GAAP) | $ | 1,540.6 |  |  | $ | 1,540.5 |  |
| Net cash provided by operating activities | $ | 342.0 |  |  | $ | 515.1 |  |
| Free cash flow (non-GAAP) | $ | 318.9 |  |  | $ | 438.3 |  |

[0001262039-24-000037:mdna:63]
Deferred revenue. Our deferred revenue consists of amounts that have been invoiced but that have not yet been recognized as revenue. The majority of our deferred revenue balance consists of the unrecognized portion of service revenue from FortiGuard and other security subscriptions and FortiCare technical support service contracts, which is recognized as revenue ratably over the service term. We monitor our deferred revenue balance, short-term and total deferred revenue growth and the mix of short-term and long-term deferred revenue because deferred revenue represents a significant portion of free cash flow and of revenue to be recognized in future periods. Deferred revenue was $5.90 billion as of June 30, 2024, an increase of $161.2 million, or 3%, from December 31, 2023. Short term deferred revenue was $2.98 billion as of June 30, 2024, an increase of $126.6 million, or 4%, from December 31, 2023.

[0001262039-24-000037:mdna:64]
Billings (non-GAAP). We define billings as revenue recognized in accordance with GAAP plus the change in deferred revenue from the beginning to the end of the period. We consider billings to be a useful metric for management and investors because billings drive current and future revenue, which is an important indicator of the health and viability of our business. There are several limitations related to the use of billings instead of GAAP revenue. First, billings include amounts that have not yet been recognized as revenue and are impacted by the term of FortiGuard security subscription and FortiCare and other support agreements. Second, we may calculate billings in a manner that is different from peer companies that report similar financial measures. Management accounts for these limitations by providing specific information regarding GAAP revenue and evaluating billings together with GAAP revenue. Total billings were $1.54 billion for the three months ended June 30, 2024, remained flat compared to $1.54 billion in the same period last year.

[0001262039-24-000037:mdna:65]
Our backlog may fluctuate over quarters. A reduction to backlog increases our aggregate billings and revenue during the quarter when delivered. If we experience supply chain shortages and cannot fulfill orders, our backlog may increase, which will negatively impact our aggregate billings and revenue in such quarter, and as the supply chain challenges normalized, our product revenue growth rate may be lower versus prior quarters where delivery from backlog contributed more to billings.

[0001262039-24-000037:mdna:66]
[same as prior period, unchanged from 0001262039-24-000020:mdna:66]

[0001262039-24-000037:mdna:67]
|  | Three Months Ended |
|  | June 30, 2024 |  | June 30, 2023 |
|  | (in millions) |
| Billings: |  |  |  |
| Revenue | $ | 1,434.3 |  |  | $ | 1,292.8 |  |
| Add: Change in deferred revenue | 106.3 |  |  | 247.7 |  |
| Total billings (non-GAAP) | $ | 1,540.6 |  |  | $ | 1,540.5 |  |

[0001262039-24-000037:mdna:68]
[same as prior period, unchanged from 0001262039-24-000020:mdna:68]

[0001262039-24-000037:mdna:69]
|  | Three Months Ended |
|  | June 30, 2024 |  | June 30, 2023 |
|  | (in millions) |
| Free Cash Flow: |  |  |  |
| Net cash provided by operating activities | $ | 342.0 |  |  | $ | 515.1 |  |
| Less: Purchases of property and equipment | (23.1) |  |  | (76.8) |  |
| Free cash flow (non-GAAP) | $ | 318.9 |  |  | $ | 438.3 |  |
| Net cash used in investing activities | $ | (50.1) |  |  | $ | (424.1) |  |
| Net cash used in financing activities | $ | (14.0) |  |  | $ | (17.7) |  |

[0001262039-24-000037:mdna:70]
[same as prior period, unchanged from 0001262039-24-000020:mdna:70]

[0001262039-24-000037:mdna:71]
[same as prior period, unchanged from 0001262039-24-000020:mdna:71]

[0001262039-24-000037:mdna:72]
There were no material changes to our critical accounting policies and estimates as of and for the three and six months ended June 30, 2024, as compared to the critical accounting policies and estimates described in our Annual Report on Form 10-K filed with the SEC on February 26, 2024 (the “Form 10-K”).

[0001262039-24-000037:mdna:73]
31

[0001262039-24-000037:mdna:74]
[same as prior period, unchanged from 0001262039-24-000020:mdna:73]

[0001262039-24-000037:mdna:75]
[same as prior period, unchanged from 0001262039-24-000020:mdna:74]

[0001262039-24-000037:mdna:76]
Three Months Ended June 30, 2024 and 2023

[0001262039-24-000037:mdna:77]
[same as prior period, unchanged from 0001262039-24-000020:mdna:76]

[0001262039-24-000037:mdna:78]
|  | Three Months Ended |  |  |  |  |
| June 30,2024 |  | June 30,2023 |  |  |  |  |
| Amount |  | % ofRevenue |  | Amount |  | % ofRevenue |  | Change |  | % Change |
| (in millions, except percentages) |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 451.9 |  |  | 32 | % |  | $ | 472.6 |  |  | 37 | % |  | $ | (20.7) |  |  | (4) | % |
| Service | 982.4 |  |  | 68 |  |  | 820.2 |  |  | 63 |  |  | 162.2 |  |  | 20 |  |
| Total revenue | $ | 1,434.3 |  |  | 100 | % |  | $ | 1,292.8 |  |  | 100 | % |  | $ | 141.5 |  |  | 11 | % |
| Revenue by geography: |  |  |  |  |  |  |  |  |  |  |  |
| Americas | $ | 595.3 |  |  | 42 | % |  | $ | 537.0 |  |  | 42 | % |  | $ | 58.3 |  |  | 11 | % |
| EMEA | 565.2 |  |  | 39 |  |  | 506.9 |  |  | 39 |  |  | 58.3 |  |  | 12 |  |
| APAC | 273.8 |  |  | 19 |  |  | 248.9 |  |  | 19 |  |  | 24.9 |  |  | 10 |  |
| Total revenue | $ | 1,434.3 |  |  | 100 | % |  | $ | 1,292.8 |  |  | 100 | % |  | $ | 141.5 |  |  | 11 | % |

[0001262039-24-000037:mdna:79]
Total revenue increased $141.5 million, or 11%, during the three months ended June 30, 2024 compared to the same period last year. We continued to experience diversification of revenue geographically, and across customer and industry segments. Revenue from all regions grew, with the Americas and EMEA contributing the larger portion of the increase on an absolute dollar basis and EMEA, contributing the largest portion of the increase on a percentage basis.

[0001262039-24-000037:mdna:80]
Product revenue decreased $20.7 million, or 4%, during the three months ended June 30, 2024 compared to the same period last year, due to the decrease in hardware revenue, partially offset by the increase in software revenue. The decrease in hardware revenue was impacted by the change in backlog from hardware shipped in the prior periods, reduced net prices on certain products and macroeconomic conditions. When we fulfill, ship and bill during a quarter to satisfy backlog, this increases our aggregate billings and revenue during any particular quarter. As the supply chain challenges normalize, our product revenue growth rate may be lower versus prior quarters where delivery from backlog contributed more to billings. For the remainder of 2024, we expect product revenue growth rates will continue to be impacted by drawdown of backlog in earlier periods and earlier pricing actions.

[0001262039-24-000037:mdna:81]
Service revenue increased $162.2 million, or 20%, during the three months ended June 30, 2024 compared to the same period last year. Security subscription revenue increased $101.4 million, or 22%, and technical support and other services revenue increased $60.8 million, or 17%, during the three months ended June 30, 2024 compared to the same period last year. The increase was primarily due to the recognition of revenue from our growing deferred revenue balance related to FortiGuard and other security subscriptions delivered to on-premise and cloud-based environments and growth in SaaS solutions, including SASE and SecOps.

[0001262039-24-000037:mdna:82]
Of the service revenue recognized during the three months ended June 30, 2024, 90% was included in the deferred revenue balance as of March 31, 2024. Of the service revenue recognized during the three months ended June 30, 2023, 89% was included in the deferred revenue balance as of March 31, 2023. We expect service revenue growth rates to ease throughout the remainder of 2024 due to slowing deferred revenue and product revenue growth over the past several quarters, partially offset by increases in SaaS revenue.

[0001262039-24-000037:mdna:83]
32

[0001262039-24-000037:mdna:84]
[same as prior period, unchanged from 0001262039-24-000020:mdna:83]

[0001262039-24-000037:mdna:85]
|  | Three Months Ended |  |  |  |  |
| June 30,2024 |  | June 30,2023 |  | Change |  | % Change |
| (in millions, except percentages) |
| Cost of revenue: |  |  |  |  |  |  |  |
| Product | $ | 155.1 |  |  | $ | 174.5 |  |  | $ | (19.4) |  |  | (11) | % |
| Service | 119.9 |  |  | 121.3 |  |  | (1.4) |  |  | (1) |  |
| Total cost of revenue | $ | 275.0 |  |  | $ | 295.8 |  |  | $ | (20.8) |  |  | (7) | % |
| Gross margin (%): |  |  |  |  |  |  |  |
| Product | 65.7 | % |  | 63.1 | % |  |  |  |  |
| Service | 87.8 |  |  | 85.2 |  |  |  |  |  |
| Total gross margin | 80.8 | % |  | 77.1 | % |  |  |  |  |

[0001262039-24-000037:mdna:86]
Total gross margin increased 3.7 percentage points during the three months ended June 30, 2024 compared to the same period last year, primarily driven by increased product and service gross margin and a shift in the revenue mix to higher margin service revenue. Revenue mix shifted by 5.1 percentage points from product revenue to service revenue, as a percentage of total revenue.

[0001262039-24-000037:mdna:87]
Product gross margin increased 2.6 percentage points during the three months ended June 30, 2024 compared to the same period last year, primarily due to lower expedite fees, a shift in revenue mix from hardware to software, lower freight costs and inventory related reserves expense, partially offset by reduced prices on certain products. During the first quarter 2024, we lowered list prices on select products. Cost of product revenue was comprised primarily of third-party contract manufacturers’ costs, costs of materials used in production and inventory reserves.

[0001262039-24-000037:mdna:88]
Service gross margin increased 2.6 percentage points during the three months ended June 30, 2024 compared to the same period last year, primarily driven by slower labor and other cost growth and a revenue mix shift towards higher margin security subscription services. Cost of service revenue was comprised primarily of personnel-related costs, third-party repair and contract fulfillment, data center costs, colocation and cloud provider fees, supplies and facility-related costs.

[0001262039-24-000037:mdna:89]
[same as prior period, unchanged from 0001262039-24-000020:mdna:88]

[0001262039-24-000037:mdna:90]
|  | Three Months Ended |  | Change |  | % Change |
| June 30,2024 |  | June 30,2023 |  |
| Amount |  | % ofRevenue |  | Amount |  | % ofRevenue |  |
| (in millions, except percentages) |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | $ | 165.4 |  |  | 12 | % |  | $ | 153.3 |  |  | 12 | % |  | $ | 12.1 |  |  | 8 | % |
| Sales and marketing | 501.3 |  |  | 35 |  |  | 515.9 |  |  | 40 |  |  | (14.6) |  |  | (3) |  |
| General and administrative | 56.6 |  |  | 4 |  |  | 49.9 |  |  | 4 |  |  | 6.7 |  |  | 13 |  |
| Gain on intellectual property matter | (1.2) |  |  | — |  |  | (1.1) |  |  | — |  |  | (0.1) |  |  | 9 |  |
| Total operating expenses | $ | 722.1 |  |  | 50 | % |  | $ | 718.0 |  |  | 56 | % |  | $ | 4.1 |  |  | 1 | % |

[0001262039-24-000037:mdna:91]
[same as prior period, unchanged from 0001262039-24-000020:mdna:90]

[0001262039-24-000037:mdna:92]
Research and development expense increased $12.1 million, or 8%, during the three months ended June 30, 2024 compared to the same period last year, primarily due to an increase of $8.8 million in personnel-related costs as a result of increased headcount and compensation rates to support the development of new products and continued enhancements to our existing products. In addition, depreciation expense and other occupancy-related expense increased $2.0 million and product development costs increased $1.1 million. We currently intend to continue investing in our research and development organization, and expect research and development expense to increase in absolute dollars year over year during the remainder of 2024.

[0001262039-24-000037:mdna:93]
[same as prior period, unchanged from 0001262039-24-000020:mdna:92]

[0001262039-24-000037:mdna:94]
Sales and marketing expense decreased $14.6 million, or 3%, during the three months ended June 30, 2024 compared to the same period last year, primarily due to a decrease of $11.4 million in personnel-related costs, a decrease of $5.5 million in marketing expenses and the favorable impact of foreign currency fluctuations. The decreases were partially offset by an increase of $1.6 million in travel expense. We currently intend to continue making investments in sales and marketing resources critical to support our future growth and expect our sales and marketing expense to increase in absolute dollars year over year during the remainder of 2024.

[0001262039-24-000037:mdna:95]
[same as prior period, unchanged from 0001262039-24-000020:mdna:94]

[0001262039-24-000037:mdna:96]
General and administrative expense increased $6.7 million, or 13%, during the three months ended June 30, 2024 compared to the same period last year, primarily due to an increase of $6.3 million in legal related fees and other professional services fees. We currently expect general and administrative expense to increase in absolute dollars year over year during the remainder of 2024.

[0001262039-24-000037:mdna:97]
[same as prior period, unchanged from 0001262039-24-000020:mdna:96]

[0001262039-24-000037:mdna:98]
We generated operating income of $437.2 million during the three months ended June 30, 2024, an increase of $158.2 million, or 57%, compared to $279.0 million in the same period last year. Operating margin was 30.5% during the three months ended June 30, 2024, compared to 21.6% in the same period last year. The increase in operating margin was primarily due to 5.0 percentage points decrease in sales and marketing expense as a percentage of revenue, 3.7 percentage points increase in gross margin and 0.3 percentage points decrease in research and development expense as a percentage of revenue, partially offset by a 0.1 percentage point increase in general and administrative expense as a percentage of revenue.

[0001262039-24-000037:mdna:99]
Interest income, interest expense and other expense—net

[0001262039-24-000037:mdna:100]
|  | Three Months Ended |  |  |  |  |
| June 30,2024 |  | June 30,2023 |  | Change |  | % Change |
| (in millions, except percentages) |
| Interest income | $ | 38.3 |  |  | $ | 31.6 |  |  | $ | 6.7 |  |  | 21 | % |
| Interest expense | $ | (5.0) |  |  | $ | (5.2) |  |  | $ | 0.2 |  |  | (4) | % |
| Other expense—net | $ | (2.2) |  |  | $ | (6.2) |  |  | $ | 4.0 |  |  | (65) | % |

[0001262039-24-000037:mdna:101]
Interest income increased $6.7 million during the three months ended June 30, 2024 compared to the same period last year, primarily as a result of higher interest rates and investment balances. Interest income varies depending on our average investment balances during the period, types and mix of investments, and market interest rates. Interest expense remained comparatively flat during the three months ended June 30, 2024 compared to the same period last year. The $4.0 million change in Other expense—net during the three months ended June 30, 2024 compared to the same period last year, was primarily due to a $3.8 million lower loss on marketable equity securities.

[0001262039-24-000037:mdna:102]
[same as prior period, unchanged from 0001262039-24-000020:mdna:101]

[0001262039-24-000037:mdna:103]
|  | Three Months Ended |  | Change |  | % Change |
| June 30,2024 |  | June 30,2023 |  |
| (in millions, except percentages) |
| Provision for income taxes | $ | 76.5 |  |  | $ | 27.6 |  |  | $ | 48.9 |  |  | 177 | % |
| Effective tax rate (%) | 16 | % |  | 9 | % |  |  |  |  |

[0001262039-24-000037:mdna:104]
Our effective tax rate was 16% for the three months ended June 30, 2024 compared to an effective tax rate of 9% for the same period last year. The provision for income taxes for the three months ended June 30, 2024 was primarily comprised of U.S. federal and state taxes, withholding taxes and foreign taxes totaling $109.9 million, which were favorably affected by a tax benefit of $27.2 million from the foreign-derived intangible income deduction (the “FDII deduction”) and excess tax benefits from stock-based compensation expense of $6.2 million.

[0001262039-24-000037:mdna:105]
The provision for income taxes for the three months ended June 30, 2023 was comprised of U.S. federal and state taxes, withholding taxes, and foreign taxes totaling $84.8 million, which were favorably affected by a tax benefit of $25.8 million from the FDII deduction, excess tax benefits from stock-based compensation expense of $13.3 million, and the release of reserves of $18.1 million on uncertain tax positions and the accrued interest thereon due to the expiration of statues of limitations.

[0001262039-24-000037:mdna:106]
[same as prior period, unchanged from 0001262039-24-000020:mdna:105]

[0001262039-24-000037:mdna:107]
|  | Three Months Ended |  | Change |  | % Change |
| June 30,2024 |  | June 30,2023 |  |
| (in millions, except percentages) |
| Loss from equity method investments | $ | (12.0) |  |  | $ | (5.3) |  |  | $ | (6.7) |  |  | 126 | % |

[0001262039-24-000037:mdna:108]
Loss from equity method investments increased $6.7 million during the three months ended June 30, 2024 compared to the same period last year, primarily driven by the OTTI charge of $8.0 million recorded during the three months ended June 30, 2024, partially offset by our proportionate share of Linksys’ financial results including our share of the amortization of the basis differences improved over the same period last year .

[0001262039-24-000037:mdna:109]
Six Months Ended June 30, 2024 and 2023

[0001262039-24-000037:mdna:110]
Revenue

[0001262039-24-000037:mdna:111]
|  | Six Months Ended |  |  |  |  |
| June 30,2024 |  | June 30,2023 |  |  |  |  |
| Amount |  | % ofRevenue |  | Amount |  | % ofRevenue |  | Change |  | % Change |
| (in millions, except percentages) |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 860.8 |  |  | 31 | % |  | $ | 973.3 |  |  | 38 | % |  | $ | (112.5) |  |  | (12) | % |
| Service | 1,926.8 |  |  | 69 |  |  | 1,581.8 |  |  | 62 |  |  | 345.0 |  |  | 22 |  |
| Total revenue | $ | 2,787.6 |  |  | 100 | % |  | $ | 2,555.1 |  |  | 100 | % |  | $ | 232.5 |  |  | 9 | % |
| Revenue by geography: |  |  |  |  |  |  |  |  |  |  |  |
| Americas | $ | 1,152.3 |  |  | 41 | % |  | $ | 1,060.5 |  |  | 41 | % |  | $ | 91.8 |  |  | 9 | % |
| EMEA | 1,104.6 |  |  | 40 |  |  | 985.1 |  |  | 39 |  |  | 119.5 |  |  | 12 |  |
| APAC | 530.7 |  |  | 19 |  |  | 509.5 |  |  | 20 |  |  | 21.2 |  |  | 4 |  |
| Total revenue | $ | 2,787.6 |  |  | 100 | % |  | $ | 2,555.1 |  |  | 100 | % |  | $ | 232.5 |  |  | 9 | % |
| Percentages have been rounded for presentation purposes and may differ from unrounded results. |

[0001262039-24-000037:mdna:112]
Total revenue increased $232.5 million, or 9%, during the six months ended June 30, 2024 compared to the same period last year. We continued to experience diversification of revenue geographically, and across customer and industry segments. Revenue from all regions grew, with EMEA contributing the largest portion of the increase on an absolute dollar basis and on a percentage basis.

[0001262039-24-000037:mdna:113]
Product revenue decreased $112.5 million, or 12%, during the six months ended June 30, 2024 compared to the same period last year, due to the decrease in hardware revenue, partially offset by the increase in software revenue. The decrease in hardware revenue was impacted by the change in backlog from hardware shipped in the prior periods, reduced net prices on certain products and macroeconomic conditions. When we fulfill, ship and bill during a quarter to satisfy backlog, this increases our aggregate billings and revenue during any particular quarter. As the supply chain challenges normalize, our product revenue growth rate may be lower versus prior quarters where delivery from backlog contributed more to billings.

[0001262039-24-000037:mdna:114]
35

[0001262039-24-000037:mdna:115]
Service revenue increased $345.0 million, or 22%, during the six months ended June 30, 2024 compared to the same period last year. Security subscription revenue increased $216.6 million, or 25%, and technical support and other services revenue increased $128.4 million, or 18%, during the six months ended June 30, 2024 compared to the same period last year. The increase was primarily due to the recognition of revenue from our growing deferred revenue balance related to FortiGuard and other security subscriptions delivered to on-premise and cloud-based environments and growth in SaaS solutions, including SASE and SecOps.

[0001262039-24-000037:mdna:116]
Of the service revenue recognized during the six months ended June 30, 2024, 84% was included in the deferred revenue balance as of December 31, 2023. Of the service revenue recognized during the six months ended June 30, 2023, 81% was included in the deferred revenue balance as of December 31, 2022. We expect service revenue growth rates to ease throughout the remainder of 2024 due to slowing deferred revenue and product revenue growth over the past several quarters, partially offset by increases in SaaS revenue.

[0001262039-24-000037:mdna:117]
Cost of revenue and gross margin

[0001262039-24-000037:mdna:118]
|  | Six Months Ended |  |  |  |  |
| June 30,2024 |  | June 30,2023 |  | Change |  | % Change |
| (in millions, except percentages) |
| Cost of revenue: |  |  |  |  |  |  |  |
| Product | $ | 337.9 |  |  | $ | 368.1 |  |  | $ | (30.2) |  |  | (8) | % |
| Service | 241.8 |  |  | 235.5 |  |  | 6.3 |  |  | 3 | % |
| Total cost of revenue | $ | 579.7 |  |  | $ | 603.6 |  |  | $ | (23.9) |  |  | (4) | % |
| Gross margin (%): |  |  |  |  |  |  |  |
| Product | 60.7 | % |  | 62.2 | % |  |  |  |  |
| Service | 87.5 |  |  | 85.1 |  |  |  |  |  |
| Total gross margin | 79.2 | % |  | 76.4 | % |  |  |  |  |

[0001262039-24-000037:mdna:119]
Total gross margin increased 2.8 percentage points during the six months ended June 30, 2024 compared to the same period last year, primarily driven by a shift in the revenue mix to higher margin service revenue and increased service gross margin, partially offset by decreased product gross margin. Revenue mix shifted by 7.2 percentage points from product revenue to service revenue, as a percentage of total revenue.

[0001262039-24-000037:mdna:120]
Product gross margin decreased 1.5 percentage points during the six months ended June 30, 2024 compared to the same period last year, primarily due to inventory related reserves expense and reduced prices on certain products, partially offset by lower expedite fees, a shift in revenue mix from hardware to software and lower freight costs. During the first quarter of 2024, we lowered list prices on select products. Cost of product revenue was comprised primarily of third-party contract manufacturers’ costs, costs of materials used in production and inventory reserves.

[0001262039-24-000037:mdna:121]
Service gross margin increased 2.4 percentage points during the six months ended June 30, 2024 compared to the same period last year, primarily driven by slower labor and other cost growth, pricing actions in earlier periods and a revenue mix shift towards higher margin security subscription services. Cost of service revenue was comprised primarily of personnel-related costs, third-party repair and contract fulfillment, data center costs, colocation and cloud provider fees, supplies and facility-related costs.

[0001262039-24-000037:mdna:122]
36

[0001262039-24-000037:mdna:123]
Operating expenses

[0001262039-24-000037:mdna:124]
|  | Six Months Ended |  | Change |  | % Change |
| June 30,2024 |  | June 30,2023 |  |
| Amount |  | % ofRevenue |  | Amount |  | % ofRevenue |  |
| (in millions, except percentages) |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | $ | 338.4 |  |  | 12 | % |  | $ | 304.4 |  |  | 12 | % |  | $ | 34.0 |  |  | 11 | % |
| Sales and marketing | 1,002.4 |  |  | 36 |  |  | 994.2 |  |  | 39 |  |  | 8.2 |  |  | 1 |  |
| General and administrative | 111.0 |  |  | 4 |  |  | 102.7 |  |  | 4 |  |  | 8.3 |  |  | 8 |  |
| Gain on intellectual property matter | (2.3) |  |  | — |  |  | (2.3) |  |  | — |  |  | — |  |  | — |  |
| Total operating expenses | $ | 1,449.5 |  |  | 52 | % |  | $ | 1,399.0 |  |  | 55 | % |  | $ | 50.5 |  |  | 4 | % |

[0001262039-24-000037:mdna:125]
Research and development

[0001262039-24-000037:mdna:126]
Research and development expense increased $34.0 million, or 11%, during the six months ended June 30, 2024 compared to the same period last year, primarily due to an increase of $24.6 million in personnel-related costs as a result of increased headcount and compensation rates to support the development of new products and continued enhancements to our existing products. In addition, depreciation expense and other occupancy-related expense increased $5.7 million and non-personnel-related product development costs increased $3.1 million, partially offset by the favorable impact of foreign currency fluctuations.

[0001262039-24-000037:mdna:127]
Sales and marketing

[0001262039-24-000037:mdna:128]
Sales and marketing expense increased $8.2 million, or 1%, during the six months ended June 30, 2024 compared to the same period last year, primarily due to an increase of $10.3 million in personnel-related costs. In addition, travel expense increased $4.4 million and depreciation expense and other occupancy-related expense increased $1.9 million. The increases were partially offset by a decrease of $10.8 million in marketing-related expense and the favorable impact of foreign currency fluctuations.

[0001262039-24-000037:mdna:129]
General and administrative

[0001262039-24-000037:mdna:130]
General and administrative expense increased $8.3 million, or 8%, during the six months ended June 30, 2024 compared to the same period last year, primarily due to an increase of $10.1 million in legal related fees and other professional services fees, an increase of $2.0 million in depreciation expense and other occupancy-related expense, partially offset by a decrease of $2.9 million in provision for expected credit losses.

[0001262039-24-000037:mdna:131]
Operating income and margin

[0001262039-24-000037:mdna:132]
We generated operating income of $758.4 million during the six months ended June 30, 2024, an increase of $205.9 million, or 37%, compared to $552.5 million in the same period last year. Operating margin was 27.2% during the six months ended June 30, 2024, compared to 21.6% in the same period last year. The increase in operating margin was primarily due to 3.0 percentage points decrease in sales and marketing expense as a percentage of revenue and 2.8 percentage points increase in gross margin, partially offset by a 0.2 percentage point increase in research and development expense as a percentage of revenue.

[0001262039-24-000037:mdna:133]
Interest income, interest expense and other expense—net

[0001262039-24-000037:mdna:134]
|  | Six Months Ended |  |  |  |  |
| June 30,2024 |  | June 30,2023 |  | Change |  | % Change |
| (in millions, except percentages) |
| Interest income | $ | 70.5 |  |  | $ | 52.2 |  |  | $ | 18.3 |  |  | 35 | % |
| Interest expense | $ | (10.1) |  |  | $ | (10.2) |  |  | $ | 0.1 |  |  | (1) | % |
| Other expense—net | $ | (5.1) |  |  | $ | (4.2) |  |  | $ | (0.9) |  |  | 21 | % |

[0001262039-24-000037:mdna:135]
37

[0001262039-24-000037:mdna:136]
Interest income increased $18.3 million during the six months ended June 30, 2024 compared to the same period last year, primarily as a result of higher interest rates and investment balances. Interest income varies depending on our average investment balances during the period, types and mix of investments, and market interest rates. Interest expense remained comparatively flat during the six months ended June 30, 2024 compared to the same period last year. The $0.9 million change in Other expense—net during the six months ended June 30, 2024 compared to the same period last year, was primarily due to an increase of $4.0 million foreign currency exchange losses, partially offset by a $3.5 million lower loss on marketable equity securities.

[0001262039-24-000037:mdna:137]
Provision for income taxes

[0001262039-24-000037:mdna:138]
|  | Six Months Ended |  | Change |  | % Change |
| June 30,2024 |  | June 30,2023 |  |
| (in millions, except percentages) |
| Provision for income taxes | $ | 116.0 |  |  | $ | 48.9 |  |  | $ | 67.1 |  |  | 137 | % |
| Effective tax rate (%) | 14 | % |  | 8 | % |  |  |  |  |

[0001262039-24-000037:mdna:139]
Our effective tax rate was 14% for the six months ended June 30, 2024 compared to an effective tax rate of 8% for the same period last year. The provision for income taxes for the six months ended June 30, 2024 was primarily comprised of U.S. federal and state taxes, withholding taxes and foreign taxes that were $191.3 million. This provision for income taxes was favorably affected by a tax benefit of $50.8 million from the FDII deduction, and excess tax benefits from stock-based compensation expense of $24.5 million.

[0001262039-24-000037:mdna:140]
The provision for income taxes for the six months ended June 30, 2023 was comprised of U.S. federal and state taxes, withholding taxes, and foreign taxes that were $170.6 million, which were offset by a tax benefit of $64.0 million from the FDII deduction, excess tax benefits from stock-based compensation expense of $39.6 million, and the release of reserves of $18.1 million on uncertain tax positions and the accrued interest thereon due to the expiration of statutes of limitations.

[0001262039-24-000037:mdna:141]
Loss from Equity Method Investments

[0001262039-24-000037:mdna:142]
|  | Six Months Ended |  | Change |  | % Change |
| June 30,2024 |  | June 30,2023 |  |
| (in millions, except percentages) |
| Loss from equity method investments | $ | (18.6) |  |  | $ | (27.4) |  |  | $ | 8.8 |  |  | (32) | % |

[0001262039-24-000037:mdna:143]
Loss from equity method investments decreased $8.8 million during the six months ended June 30, 2024 compared to the same period last year, primarily driven by our proportionate share of Linksys’ financial results including our share of the amortization of the basis differences improved over the same period last year, partially offset by the OTTI charge of $8.0 million recorded during the three months ended June 30, 2024.

[0001262039-24-000037:mdna:144]
38

[0001262039-24-000037:mdna:145]
[same as prior period, unchanged from 0001262039-24-000020:mdna:108]

[0001262039-24-000037:mdna:146]
|  | As of |
|  | June 30,2024 |  | December 31,2023 |
|  | (in millions) |
| Cash and cash equivalents | $ | 2,203.2 |  |  | $ | 1,397.9 |  |
| Short-term and long-term investments | 1,114.9 |  |  | 1,021.5 |  |
| Marketable equity securities | 21.2 |  |  | 21.0 |  |
| Total cash, cash equivalents, investments and marketable equity securities | $ | 3,339.3 |  |  | $ | 2,440.4 |  |
| Working capital | $ | 1,194.0 |  |  | $ | 709.3 |  |
|  | Six Months Ended |
|  | June 30,2024 |  | June 30,2023 |
|  | (in millions) |
| Net cash provided by operating activities | $ | 1,172.4 |  |  | $ | 1,192.6 |  |
| Net cash used in investing activities | (320.4) |  |  | (466.5) |  |
| Net cash used in financing activities | (44.3) |  |  | (31.4) |  |
| Effect of exchange rate changes on cash and cash equivalents | (2.4) |  |  | (1.3) |  |
| Net increase in cash and cash equivalents | $ | 805.3 |  |  | $ | 693.4 |  |

[0001262039-24-000037:mdna:147]
Liquidity and capital resources are primarily impacted by our operating activities, as well as real estate purchases and other capital expenditures, payment of taxes in connection with the net settlement of equity awards and proceeds from the issuance of common stock and repurchases of our common stock.

[0001262039-24-000037:mdna:148]
[same as prior period, unchanged from 0001262039-24-000020:mdna:111]

[0001262039-24-000037:mdna:149]
In January 2024, our board of directors approved a $500.0 million increase in the authorized share repurchase amount under the Repurchase Program, bringing the aggregate amount authorized to be repurchased to $7.25 billion of our outstanding common stock. In February 2024, our board of directors approved an extension of the Repurchase Program to February 28, 2025. As of June 30, 2024, approximately $1.03 billion remained available for future share repurchases.

[0001262039-24-000037:mdna:150]
We expect to continue to increase our data centers, PoPs, office and warehouse capacity to support growth and the expansion of existing services or introduction of new services. As we purchase new properties, we will work to incorporate these properties into the environmental goals we have established. We estimate capital expenditures to be between approximately $75.0 million and $115.0 million in the second half of 2024.

[0001262039-24-000037:mdna:151]
We believe that our cash provided by operating activities, together with our existing cash, cash equivalents and investments will be sufficient to meet our anticipated cash needs and do not currently intend to retire our Senior Notes early. Refer to Note 9, Debt, in Part I, Item 1 of this Quarterly Report on Form 10-Q for information on the Senior Notes. As of June 30, 2024, the long-term debt, net of unamortized discount and debt issuance costs, was $993.3 million.

[0001262039-24-000037:mdna:152]
[same as prior period, unchanged from 0001262039-24-000020:mdna:115]

[0001262039-24-000037:mdna:153]
39

[0001262039-24-000037:mdna:154]
These inventory purchase commitments as of June 30, 2024 totaled $566.7 million, a decrease of $70.6 million compared to $637.3 million as of December 31, 2023 due to fulfillment of customer demand as our supply availability improved and our continued efforts to work with contract manufacturers and suppliers to optimize our inventory and purchase commitment position. We record a liability for inventory purchase commitments in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. As of June 30, 2024 and December 31, 2023, the liability for these inventory purchase commitments was $105.2 million and $84.7 million, respectively, and was recorded in accrued liabilities on our condensed consolidated balance sheets.

[0001262039-24-000037:mdna:155]
[same as prior period, unchanged from 0001262039-24-000020:mdna:117]

[0001262039-24-000037:mdna:156]
[same as prior period, unchanged from 0001262039-24-000020:mdna:118]

[0001262039-24-000037:mdna:157]
We also have open purchase orders and contractual obligations in the ordinary course of business for which we have not received goods or services. As of June 30, 2024, we had $40.4 million in other contractual commitments having a remaining term in excess of one year that are non-cancelable.

[0001262039-24-000037:mdna:158]
[same as prior period, unchanged from 0001262039-24-000020:mdna:120]

[0001262039-24-000037:mdna:159]
As of June 30, 2024, our cash, cash equivalents and short-term and long-term investments of $3.32 billion were invested primarily in deposit accounts, commercial paper, corporate debt securities, U.S. government and agency securities, certificates of deposit and term deposits and money market funds. It is our investment policy to invest excess cash in a manner that preserves capital, provides liquidity and generates return without significantly increasing risk. We do not enter into investments for trading or speculative purposes.

[0001262039-24-000037:mdna:160]
The amount of cash, cash equivalents and investments held by our international subsidiaries was $164.0 million as of June 30, 2024 and $199.9 million as of December 31, 2023.

[0001262039-24-000037:mdna:161]
We believe that our existing cash and cash equivalents and cash flow from operations will be sufficient for at least the next 12 months to meet our requirements and plans for cash, including meeting our working capital requirements and capital expenditure requirements. In the long term, our ability to support our requirements and plans for cash, including our working capital and capital expenditure requirements will depend on many factors, including our growth rate; the timing and amount of our share repurchases; the expansion of sales and marketing activities, pricing actions, the introduction of new and enhanced products and services offerings; the continuing market acceptance of our products; the timing and extent of spending to support development efforts; our investments in purchasing, developing or leasing real estate; cash paid for taxes and macroeconomic impacts such as rising inflation and interest rates; and the war in Ukraine and the Israel-Hamas war. Historically, we have required capital principally to fund our working capital needs, share repurchases, capital expenditures and acquisition activities. In the event that additional financing is required from outside sources, we may not be able to raise it on terms acceptable to us or at all.

[0001262039-24-000037:mdna:162]
As of June 30, 2024, we did not have any relationships with unconsolidated organizations or financial partnerships, such as structured finance or special purpose entities that would have been established for the purpose of facilitating off-balance sheet arrangements or other contractually narrow or limited purposes.

[0001262039-24-000037:mdna:163]
[same as prior period, unchanged from 0001262039-24-000020:mdna:126]

[0001262039-24-000037:mdna:164]
Cash generated by operating activities is our primary source of liquidity. It is primarily comprised of net income, as adjusted for non-cash items and changes in operating assets and liabilities. Non-cash adjustments consist primarily of amortization of deferred contract costs, stock-based compensation and depreciation and amortization. Changes in operating assets and liabilities consist primarily of changes in accounts receivable—net, deferred revenue, deferred contract costs, deferred tax assets, inventory, accounts payable and accrued liabilities.

[0001262039-24-000037:mdna:165]
Our operating activities during the six months ended June 30, 2024 provided cash flows of $1.17 billion as a result of the continued growth of our business, improved profitability and our ability to successfully manage our working capital. Changes in operating assets and liabilities primarily resulted from an increase in sales of our security subscription services and technical support services to new and existing customers, as reflected by an increase of $161.7 million in our deferred revenue

[0001262039-24-000037:mdna:166]
40

[0001262039-24-000037:mdna:167]
during the six months ended June 30, 2024. In addition, changes in operating assets and liabilities were driven by a decrease of $318.9 million in accounts receivable—net, an increase of $136.0 million in deferred contract costs, an increase of $130.3 million in deferred tax assets, a decrease of $85.2 million in inventory, a decrease of $67.2 million in accounts payable and a decrease of $24.9 million in accrued liabilities.

[0001262039-24-000037:mdna:168]
[same as prior period, unchanged from 0001262039-24-000020:mdna:129]

[0001262039-24-000037:mdna:169]
[same as prior period, unchanged from 0001262039-24-000020:mdna:130]

[0001262039-24-000037:mdna:170]
During the six months ended June 30, 2024, cash used in investing activities was $320.4 million, primarily driven by $245.0 million used for the purchases of property and equipment, $69.7 million spent for purchases of investments, net of maturities and sales of investments and $5.7 million used for the acquisitions of certain assets and liabilities in a business combination, net of cash.

[0001262039-24-000037:mdna:171]
[same as prior period, unchanged from 0001262039-24-000020:mdna:132]

[0001262039-24-000037:mdna:172]
[same as prior period, unchanged from 0001262039-24-000020:mdna:133]

[0001262039-24-000037:mdna:173]
During the six months ended June 30, 2024, cash used in financing activities was $44.3 million, primarily driven by $43.5 million used to pay tax withholding, net of proceeds from the issuance of common stock.
