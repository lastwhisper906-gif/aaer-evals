# FTNT note change history — 0001262039-21-000030 → 0001262039-22-000019


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2022-05-06):
[0001262039-22-000019:note_history:1]
COMMITMENTS AND CONTINGENCIES
The following table summarizes our inventory purchase commitments as of March 31, 2022 (in millions):
  (was, 2021-11-08, similarity 0.9609):
[0001262039-21-000030:note_history:1]
COMMITMENTS AND CONTINGENCIES
The following table summarizes our inventory purchase commitments as of September 30, 2021 (in millions):

- changed (2022-05-06):
[0001262039-22-000019:note_history:2]
|  | Total |  | 2022 |  | Thereafter |
| Inventory purchase commitments | $ | 1,372.6 |  |  | $ | 1,283.3 |  |  | $ | 89.3 |  |
  (was, 2021-11-08, similarity 0.7372):
[0001262039-21-000030:note_history:2]
|  | Total |  | 2021 |  | 2022 |  | 2023 |  | 2024 |  | 2025 |  | Thereafter |
| Inventory purchase commitments | $ | 868.0 |  |  | $ | 376.7 |  |  | $ | 491.3 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |

- added (2022-05-06):
[0001262039-22-000019:note_history:3]
Inventory Purchase Commitments—Our independent contract manufacturers and certain component suppliers procure components and build our products based on our forecasts. These forecasts are based on estimates of future demand for our products, which are in turn based on historical trends and an analysis from our sales and marketing organizations, adjusted for extended lead times, changes in supplier delivery commitments and other supply chain matters and other market conditions.

- added (2022-05-06):
[0001262039-22-000019:note_history:4]
In order to manage manufacturing lead times, plan for adequate component supply and incentivize suppliers to deliver, we may issue purchase orders to some of our independent contract manufacturers which are non-cancelable. As of March 31, 2022 and December 31, 2021, we had $1.37 billion and $1.14 billion, respectively, of open purchase orders with our independent contract manufacturers that are non-cancelable.

- added (2022-05-06):
[0001262039-22-000019:note_history:5]
Other Contractual Commitments and Open Purchase Orders—In addition to commitments with contract manufacturers, we have open purchase orders and contractual obligations in the ordinary course of business for which we have not received goods or services. A significant portion of our reported purchase commitments consist of firm and non-cancelable commitments. In certain instances, contractual commitments allow us the option to cancel, reschedule and adjust our requirements based on our business needs prior to firm orders being placed. As of March 31, 2022 and December 31, 2021, we had $114.4 million and $126.7 million, respectively, in other contractual commitments having a remaining term in excess of one year that are non-cancelable and an additional $85.4 million and $68.9 million, respectively, in contractual commitments for operating lease liabilities.

- changed (2022-05-06):
[0001262039-22-000019:note_history:6]
Litigation—We are involved in disputes, litigation, and other legal actions. For lawsuits where we are the defendant, we are in the process of defending these litigation matters, and while there can be no assurances and the outcome of certain of these matters is currently not determinable and not predictable, we currently are unaware of any existing claims or proceedings that we believe are likely to have a material adverse effect on our financial position. There are many uncertainties associated with any litigation and these actions or other third-party claims against us may cause us to incur costly litigation fees, costs and substantial settlement charges, and possibly subject us to damages and other penalties. In addition, the resolution of any IP litigation may require us to make royalty payments, which could adversely affect our gross margins in future periods. If any of those events were to occur, our business, financial condition, results of operations, and cash flows could be adversely affected. Litigation is unpredictable and the actual liability in any such matters may be materially different from our current estimates, which could result in the need to adjust any accrued liability and record additional expenses. We accrue for contingencies when we believe that a loss is probable and that we can reasonably estimate the amount of any such loss. These accruals are generally based on a range of possible outcomes that require significant management judgement. If no amount within a range is a better estimate than any other, we accrue the minimum amount.
  (was, 2021-11-08, similarity 0.9294):
[0001262039-21-000030:note_history:6]
Litigation—We are involved in disputes, litigation, and other legal actions. For lawsuits where we are the defendant, we are in the process of defending these litigation matters, and while there can be no assurances and the outcome of certain of these matters is currently not determinable and not predictable, we currently are unaware of any existing claims or proceedings that we believe are likely to have a material adverse effect on our financial position. There are many uncertainties associated with any litigation and these actions or other third-party claims against us may cause us to incur costly litigation fees, costs and substantial settlement charges, and possibly subject us to damages and other penalties. In addition, the resolution of any IP litigation may require us to make royalty payments, which could adversely affect our gross margins in future periods. If any of those events were to occur, our business, financial condition, results of operations, and cash flows could be adversely affected. Litigation is unpredictable and the actual liability in any such matters may be materially different from our current estimates, which could result in the need to adjust any accrued liability and record additional expenses. We accrue for contingencies when we believe that a loss is probable and that we can reasonably estimate the amount of any such loss.

- added (2022-05-06):
[0001262039-22-000019:note_history:7]
In December 2021, we entered into an agreement that provided for settlement and dismissal of an existing patent infringement lawsuit and a mutual covenant-not-to-sue for a defined duration of time. We have settled and paid $10.0 million in cash, of which $5.6 million was related to the dismissal of lawsuit and was expensed as a general and administrative expense, and $4.4 million was deferred and will be expensed over time as royalty cost of revenue. Litigation loss contingency accruals associated with other outstanding cases were not material as of March 31, 2022 and December 31, 2021.

- changed (2022-05-06):
[0001262039-22-000019:note_history:8]
Indemnification and Other Matters—Under the indemnification provisions of our standard sales contracts, we agree to defend our customers against third-party claims asserting various allegations such as product defects and infringement of certain IP rights, which may include patents, copyrights, trademarks or trade secrets, and to pay judgments entered on such claims. In some contracts, our exposure under these indemnification provisions is limited by the terms of the contracts to certain defined limits, such as the total amount paid by our customer under the agreement. However, certain agreements include covenants, penalties and indemnification provisions including and beyond indemnification for third-party claims of IP infringement that could potentially expose us to losses in excess of the amount received under the agreement, and in some instances to potential liability that is not contractually limited. Although from time to time there are indemnification claims asserted against us and currently there are pending indemnification claims, to date there have been no material awards under such indemnification provisions.
  (was, 2021-11-08, similarity 0.8107):
[0001262039-21-000030:note_history:8]
claims. In some contracts, our exposure under these indemnification provisions is limited by the terms of the contracts to certain defined limits, such as the total amount paid by our customer under the agreement. However, certain agreements include covenants, penalties and indemnification provisions including and beyond indemnification for third-party claims of IP infringement that could potentially expose us to losses in excess of the amount received under the agreement, and in some instances to potential liability that is not contractually limited. Although from time to time there are indemnification claims asserted against us and currently there are pending indemnification claims, to date there have been no material awards under such indemnification provisions.

- removed (2022-05-06):
[0001262039-21-000030:note_history:9]
Inventory Purchase Commitments—Our independent contract manufacturers procure components and build our products based on our forecasts. These forecasts are based on estimates of future demand for our products, which are in turn based on historical trends and an analysis from our sales and marketing organizations, adjusted for supply chain matters and other market conditions. In order to reduce manufacturing lead times, plan for adequate component supply and incentivize suppliers to deliver, we may issue purchase orders to some of our independent contract manufacturers, which are non-cancelable. As of September 30, 2021, we had $868.0 million of open purchase orders with our independent contract manufacturers that are non-cancelable.

- removed (2022-05-06):
[0001262039-21-000030:note_history:10]
Other Contractual Commitments and Open Purchase Orders—In addition to commitments with contract manufacturers, we have open purchase orders and contractual obligations in the ordinary course of business for which we have not received goods or services. As of September 30, 2021, we had $68.9 million in other contractual commitments having a remaining term in excess of one year that are non-cancelable.

- removed (2022-05-06):
[0001262039-21-000030:note_history:11]
In October 2021, we held settlement discussions related to an existing patent infringement lawsuit. Pursuant to such discussions, we may enter into an agreement that provides for the settlement and dismissal of the patent lawsuit and a mutual covenant not to sue for a defined duration of time.  As a result, we have determined that a loss in connection with such lawsuit is now probable. We accrued $5 million as a loss contingency in the quarter ended September 30, 2021 and the associated charge was recorded against revenue in the income statement. Litigation loss contingency accruals associated with other outstanding cases were not material as of September 30, 2021 and December 31, 2020.

- removed (2022-05-06):
[0001262039-21-000030:note_history:12]
Indemnification and Other Matters—Under the indemnification provisions of our standard sales contracts, we agree to defend our customers against third-party claims asserting various allegations such as product defects and infringement of certain IP rights, which may include patents, copyrights, trademarks or trade secrets, and to pay judgments entered on such


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2022-05-06):
[0001262039-22-000019:note_history:13]
SUMMARY OF SIGNIFICANT ACCOUNTING POLICIES
Basis of Presentation and Preparation—The unaudited condensed consolidated financial statements of Fortinet, Inc. and its subsidiaries (collectively, “we,” “us” or “our”) have been prepared in accordance with generally accepted accounting principles in the United States (“GAAP”) for interim financial information, as well as the instructions to Form 10-Q pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (the “SEC”). Accordingly, they do not include all of the information and footnotes required by GAAP for complete financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the year ended December 31, 2021, contained in our Annual Report on Form 10-K filed with the SEC on February 25, 2022. In the opinion of management, all adjustments, which include normal recurring adjustments, considered necessary for a fair presentation, have been included. The results of operations for the three months ended March 31, 2022 are not necessarily indicative of the results to be expected for the full year or for any future periods. The condensed consolidated balance sheet as of December 31, 2021 is derived from the audited consolidated financial statements for the year ended December 31, 2021.
  (was, 2021-11-08, similarity 0.9805):
[0001262039-21-000030:note_history:13]
SUMMARY OF SIGNIFICANT ACCOUNTING POLICIES
Basis of Presentation and Preparation—The unaudited condensed consolidated financial statements of Fortinet, Inc. and its subsidiaries (collectively, “we,” “us” or “our”) have been prepared in accordance with generally accepted accounting principles in the United States (“GAAP”) for interim financial information, as well as the instructions to Form 10-Q pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (the “SEC”). Accordingly, they do not include all of the information and footnotes required by GAAP for complete financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the year ended December 31, 2020, contained in our Annual Report on Form 10-K filed with the SEC on February 19, 2021. In the opinion of management, all adjustments, which includes normal recurring adjustments, considered necessary for a fair presentation have been included. The results of operations for the three and nine months ended September 30, 2021 are not necessarily indicative of the results to be expected for the full year or for any future periods. The condensed consolidated balance sheet as of December 31, 2020 is derived from the audited consolidated financial statements for the year ended December 31, 2020.

- changed (2022-05-06):
[0001262039-22-000019:note_history:14]
The preparation of the condensed consolidated financial statements in accordance with GAAP requires management to make estimates and assumptions that affect the amounts reported in the condensed consolidated financial statements and accompanying notes. Actual results could differ materially from those estimates.
  (was, 2021-11-08, similarity 0.9549):
[0001262039-21-000030:note_history:14]
The preparation of financial statements in accordance with GAAP requires management to make estimates and assumptions that affect the amounts reported in the condensed consolidated financial statements and accompanying notes. Actual results could differ materially from those estimates.

- changed (2022-05-06):
[0001262039-22-000019:note_history:15]
There have been no material changes to our significant accounting policies as of and for the three months ended March 31, 2022.
  (was, 2021-11-08, similarity 0.9042):
[0001262039-21-000030:note_history:15]
There have been no other material changes to our significant accounting policies as of and for the three and nine months ended September 30, 2021.

- changed (2022-05-06):
[0001262039-22-000019:note_history:16]
Recently Adopted and Recently Issued Accounting Standards
  (was, 2021-11-08, similarity 0.7872):
[0001262039-21-000030:note_history:16]
Recently Adopted Accounting Standards

- added (2022-05-06):
[0001262039-22-000019:note_history:17]
There were no recently adopted accounting standards which would have a material effect on our condensed consolidated financial statements and accompanying disclosures, and no recently issued accounting standards that are expected to have a material impact on our condensed consolidated financial statements and accompanying disclosures.

- removed (2022-05-06):
[0001262039-21-000030:note_history:18]
Investments in common stock or in-substance common stock of entities that provide us with the ability to exercise significant influence, but not an absolute controlling financial interest, over the investee are accounted for under the equity method of accounting. Investments accounted for under the equity method are initially recorded at cost. Subsequently, we recognize our proportionate share of the entities’ net income or loss and the amortization of any basis differences through the condensed consolidated statements of income and as an adjustment to the investment balance. We record our share of the results of equity method investments on a three-month lag basis as income or loss from equity method investments, net of tax in the condensed consolidated statements of income. We evaluate our equity method investments at the end of each reporting period to determine whether events or changes in business circumstances indicate that the carrying value of the investment may not be recoverable. As of September 30, 2021, our investment in Linksys Holdings, Inc. (“Linksys”) was our only equity method investment.

- removed (2022-05-06):
[0001262039-21-000030:note_history:19]
Income Taxes

- removed (2022-05-06):
[0001262039-21-000030:note_history:20]
In December 2019, the Financial Accounting Standards Board (the “FASB”) issued Accounting Standards Update (“ASU”) 2019-12—Income Taxes (“Topic 740”): Simplifying the Accounting for Income Taxes. The amendments in ASU 2019-12 simplify the accounting for income taxes by removing certain exceptions to the general principles in Topic 740. The amendments also improve consistent application and simplification of GAAP for other areas of Topic 740 by clarifying and amending existing guidance. ASU 2019-12 was effective for us beginning on January 1, 2021. The adoption of this guidance did not have any impact on our condensed consolidated financial statements and accompanying disclosures.

- removed (2022-05-06):
[0001262039-21-000030:note_history:21]
Recent Accounting Standards Not Yet Effective

- removed (2022-05-06):
[0001262039-21-000030:note_history:22]
Business Combinations

- removed (2022-05-06):
[0001262039-21-000030:note_history:23]
In October 2021, the FASB issued ASU 2021-08—Business Combinations (“Topic 805”): Accounting for Contract Assets and Contract Liabilities from Contracts with Customers. The amendments in ASU 2021-08 require that an entity 
recognizes and measures contract assets and contract liabilities acquired in a business combination in accordance with ASC 606, Revenue from Contracts with Customers (“Topic 606”). At the acquisition date, an acquirer should account for the related revenue contracts in accordance with Topic 606 as if it had originated the contracts. The amendments improve comparability for both the recognition and measurement of acquired revenue contracts with customers at the date of and after a business combination. ASU 2021-08 will be effective for us beginning on January 1, 2023. We are currently evaluating the impact of ASU 2021-08 on our condensed consolidated financial statements.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-05-06):
[0001262039-22-000019:note_history:24]
On March 5, 2021, we issued $1.0 billion aggregate principal amount of senior notes (collectively, the “Senior Notes”), consisting of $500.0 million aggregate principal amount of 1.0% notes due March 15, 2026 (the “2026 Senior Notes”) and $500.0 million aggregate principal amount of 2.2% notes due March 15, 2031 (the “2031 Senior Notes”), in an underwritten registered public offering. The Senior Notes are senior unsecured obligations and rank equally with each other in right of payment and with our other outstanding obligations. We may redeem the Senior Notes at any time in whole or in part for cash, at specified redemption prices that include accrued and unpaid interest, if any, and a make-whole premium. However, no make-whole premium will be paid for redemptions of the 2026 Senior Notes on or after February 15, 2026, or the 2031 Senior Notes on or after December 15, 2030. Interest on the Senior Notes is payable on March 15 and September 15 of each year, beginning on September 15, 2021. As of March 31, 2022 and December 31, 2021, the Senior Notes were recorded as long-term debt, net of discount and issuance costs, which are amortized to interest expense over the respective contractual terms of these notes using the effective interest method.
  (was, 2021-11-08, similarity 0.9911):
[0001262039-21-000030:note_history:24]
On March 5, 2021, we issued $1.0 billion aggregate principal amount of senior notes (collectively, the “Senior Notes”), consisting of $500.0 million aggregate principal amount of 1.0% notes due March 15, 2026 (the “2026 Senior Notes”) and $500.0 million aggregate principal amount of 2.2% notes due March 15, 2031 (the “2031 Senior Notes”), in an underwritten registered public offering. The Senior Notes are senior unsecured obligations and rank equally with each other in right of payment and with our other outstanding obligations. We may redeem the Senior Notes at any time in whole or in part for cash, at specified redemption prices that include accrued and unpaid interest, if any, and a make-whole premium. However, no make-whole premium will be paid for redemptions of the 2026 Senior Notes on or after February 15, 2026, or the 2031 Senior Notes on or after December 15, 2030. Interest on the Senior Notes is payable on March 15 and September 15 of each year, beginning on September 15, 2021. As of September 30, 2021, the Senior Notes were recorded as long-term debt, net of discount and issuance costs, which are amortized to interest expense over the respective contractual terms of these notes using the effective interest method.

- changed (2022-05-06):
[0001262039-22-000019:note_history:25]
|  | Maturity |  | Coupon Rate |  | Effective Interest Rate |  | March 31,2022 |  | December 31,2021 |
| Debt |  |  |  |  |  |  |  |  |  |
| 2026 Senior Notes | March 2026 |  | 1.0% |  | 1.3% |  | $ | 500.0 |  |  | $ | 500.0 |  |
| 2031 Senior Notes | March 2031 |  | 2.2% |  | 2.3% |  | 500.0 |  |  | 500.0 |  |
| Total debt |  |  |  |  |  |  | 1,000.0 |  |  | 1,000.0 |  |
| Less: Unamortized discount and debt issuance costs |  |  |  |  |  |  | 11.1 |  |  | 11.6 |  |
| Total long-term debt |  |  |  |  |  |  | $ | 988.9 |  |  | $ | 988.4 |  |
  (was, 2021-11-08, similarity 0.7123):
[0001262039-21-000030:note_history:25]
|  | Maturity |  | Coupon Rate |  | Effective Interest Rate |  | September 30, 2021 |
| Debt |  |  |  |  |  |  |  |
| 2026 Senior Notes | March 2026 |  | 1.0 | % |  | 1.3 | % |  | $ | 500.0 |  |
| 2031 Senior Notes | March 2031 |  | 2.2 | % |  | 2.3 | % |  | 500.0 |  |
| Total debt |  |  |  |  |  |  | 1,000.0 |  |
| Less: Unamortized discount and debt issuance costs |  |  |  |  |  |  | 12.0 |  |
| Total long-term debt |  |  |  |  |  |  | $ | 988.0 |  |

- changed (2022-05-06):
[0001262039-22-000019:note_history:26]
As of March 31, 2022 and December 31, 2021, we accrued interest payable of $0.7 million and $4.7 million, and there are no financial covenants with which we must comply. During the three months ended March 31, 2022 and 2021 we recorded $4.5 million and $1.3 million of total interest expense in relation to these Senior Notes, respectively. No interest costs were capitalized for the three months ended March 31, 2022 and 2021, as the costs that qualified for capitalization were not material.
  (was, 2021-11-08, similarity 0.8289):
[0001262039-21-000030:note_history:26]
As of September 30, 2021 we accrued interest payable of $0.7 million, and there are no financial covenants with which we must comply. During the three and nine months ended September 30, 2021 we recorded $4.4 million and $10.2 million of total interest expense in relation to these Senior Notes, respectively. No interest costs were capitalized for the three and nine months ended September 30, 2021, as the costs that qualified for capitalization were not material.

- added (2022-05-06):
[0001262039-22-000019:note_history:27]
The total estimated fair value of the outstanding Senior Notes was approximately $899.5 million, including accrued and unpaid interest, as of March 31, 2022. The fair value was determined based on observable market prices of identical instruments in less active markets. The estimated fair values are based on Level 2 inputs.

- removed (2022-05-06):
[0001262039-21-000030:note_history:28]
The total estimated fair value of the outstanding Senior Notes was approximately $991.1 million, including accrued and unpaid interest, as of September 30, 2021. The fair value was determined based on observable market prices of identical instruments in less active markets. The estimated fair values are based on Level 2 inputs.

- removed (2022-05-06):
[0001262039-21-000030:note_history:29]
AlaxalA debt

- removed (2022-05-06):
[0001262039-21-000030:note_history:30]
In connection with our acquisition of AlaxalA, we assumed certain current debt liabilities of $20.2 million as of August 31, 2021. We concluded that the fair value of debt approximated its book value as of the acquisition date. We had $17.6 million of this debt outstanding and recorded as current portion of long-term debt on our condensed consolidated balance sheet as of September 30, 2021. We repaid this balance in full in October 2021. As of September 30, 2021, the accrued interest under the assumed AlaxalA debt obligations was not material. During the post-acquisition period from September 1, 2021 through September 30, 2021, interest expense related to AlaxalA debt was not material.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-05-06):
[0001262039-22-000019:note_history:31]
|  | Maturity |  | Coupon Rate |  | Effective Interest Rate |  | March 31,2022 |  | December 31,2021 |
| Debt |  |  |  |  |  |  |  |  |  |
| 2026 Senior Notes | March 2026 |  | 1.0% |  | 1.3% |  | $ | 500.0 |  |  | $ | 500.0 |  |
| 2031 Senior Notes | March 2031 |  | 2.2% |  | 2.3% |  | 500.0 |  |  | 500.0 |  |
| Total debt |  |  |  |  |  |  | 1,000.0 |  |  | 1,000.0 |  |
| Less: Unamortized discount and debt issuance costs |  |  |  |  |  |  | 11.1 |  |  | 11.6 |  |
| Total long-term debt |  |  |  |  |  |  | $ | 988.9 |  |  | $ | 988.4 |  |
  (was, 2021-11-08, similarity 0.7123):
[0001262039-21-000030:note_history:31]
|  | Maturity |  | Coupon Rate |  | Effective Interest Rate |  | September 30, 2021 |
| Debt |  |  |  |  |  |  |  |
| 2026 Senior Notes | March 2026 |  | 1.0 | % |  | 1.3 | % |  | $ | 500.0 |  |
| 2031 Senior Notes | March 2031 |  | 2.2 | % |  | 2.3 | % |  | 500.0 |  |
| Total debt |  |  |  |  |  |  | 1,000.0 |  |
| Less: Unamortized discount and debt issuance costs |  |  |  |  |  |  | 12.0 |  |
| Total long-term debt |  |  |  |  |  |  | $ | 988.0 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2022-05-06):
[0001262039-22-000019:note_history:32]
|  | Three Months Ended |  |  |
|  | March 31,2022 |  | March 31,2021 |  |  |  |  |
| Product | $ | 371.0 |  |  | $ | 240.7 |  |  |  |  |  |
| Service: |  |  |  |  |  |  |  |
| Security subscription | 312.9 |  |  | 255.3 |  |  |  |  |  |
| Technical support and other | 270.9 |  |  | 214.3 |  |  |  |  |  |
| Total service revenue | 583.8 |  |  | 469.6 |  |  |  |  |  |
| Total revenue | $ | 954.8 |  |  | $ | 710.3 |  |  |  |  |  |
  (was, 2021-11-08, similarity 0.6518):
[0001262039-21-000030:note_history:32]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30,2021 |  | September 30,2020 |  | September 30,2021 |  | September 30,2020 |
| Product | $ | 337.1 |  |  | $ | 223.8 |  |  | $ | 876.1 |  |  | $ | 628.0 |  |
| Service: |  |  |  |  |  |  |  |
| Security subscription | 287.4 |  |  | 235.4 |  |  | 815.6 |  |  | 669.4 |  |
| Technical support and other | 242.7 |  |  | 191.9 |  |  | 686.9 |  |  | 549.0 |  |
| Total service revenue | 530.1 |  |  | 427.3 |  |  | 1,502.5 |  |  | 1,218.4 |  |
| Total revenue | $ | 867.2 |  |  | $ | 651.1 |  |  | $ | 2,378.6 |  |  | $ | 1,846.4 |  |

- removed (2022-05-06):
[0001262039-21-000030:note_history:33]
Disaggregation of Revenue


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2022-05-06):
[0001262039-22-000019:note_history:34]
REVENUE RECOGNITIONWe sell cybersecurity solutions to a variety of organizations, such as enterprises, communication service providers, government organizations and small to medium-sized enterprises. Our revenue consists of product and service revenue. Product revenue is generated by our Core Platform (previously referred to as FortiGate network security and other products), our Platform Extensions (previously referred to as Fortinet Security Fabric products and other products). Service revenue relates to sales of our security subscription services, which mainly consists of our FortiGuard security subscriptions, as well as our FortiCare technical support services and other services.
Disaggregation of Revenue
  (was, 2021-11-08, similarity 0.8158):
[0001262039-21-000030:note_history:34]
REVENUE RECOGNITION
We sell cybersecurity solutions to a variety of organizations, such as enterprises, communication service providers, government organizations and small to medium-sized enterprises. Our revenue consists of product and service revenue. Product revenue is generated by our FortiGate network security products, our Fortinet Security Fabric platform products and other products. Service revenue relates to sales of our security subscription services, which mainly consists of our FortiGuard security solutions, as well as our FortiCare technical support services and other services.

- changed (2022-05-06):
[0001262039-22-000019:note_history:35]
|  | Three Months Ended |  |  |
|  | March 31,2022 |  | March 31,2021 |  |  |  |  |
| Product | $ | 371.0 |  |  | $ | 240.7 |  |  |  |  |  |
| Service: |  |  |  |  |  |  |  |
| Security subscription | 312.9 |  |  | 255.3 |  |  |  |  |  |
| Technical support and other | 270.9 |  |  | 214.3 |  |  |  |  |  |
| Total service revenue | 583.8 |  |  | 469.6 |  |  |  |  |  |
| Total revenue | $ | 954.8 |  |  | $ | 710.3 |  |  |  |  |  |
  (was, 2021-11-08, similarity 0.6518):
[0001262039-21-000030:note_history:35]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30,2021 |  | September 30,2020 |  | September 30,2021 |  | September 30,2020 |
| Product | $ | 337.1 |  |  | $ | 223.8 |  |  | $ | 876.1 |  |  | $ | 628.0 |  |
| Service: |  |  |  |  |  |  |  |
| Security subscription | 287.4 |  |  | 235.4 |  |  | 815.6 |  |  | 669.4 |  |
| Technical support and other | 242.7 |  |  | 191.9 |  |  | 686.9 |  |  | 549.0 |  |
| Total service revenue | 530.1 |  |  | 427.3 |  |  | 1,502.5 |  |  | 1,218.4 |  |
| Total revenue | $ | 867.2 |  |  | $ | 651.1 |  |  | $ | 2,378.6 |  |  | $ | 1,846.4 |  |

- added (2022-05-06):
[0001262039-22-000019:note_history:36]
During the three months ended March 31, 2022 and 2021, we recognized $507.3 million and $417.9 million in service revenue that was included in the deferred revenue balance as of December 31, 2021 and 2020, respectively.

- changed (2022-05-06):
[0001262039-22-000019:note_history:37]
As of March 31, 2022, the aggregate amount of the transaction price allocated to remaining performance obligations was $3.66 billion, which was substantially comprised of deferred security subscription and technical support services revenue. We expect to recognize approximately $1.89 billion as revenue over the next 12 months and the remainder thereafter.
  (was, 2021-11-08, similarity 0.9798):
[0001262039-21-000030:note_history:37]
As of September 30, 2021, the aggregate amount of the transaction price allocated to remaining performance obligations was $3.11 billion, which was substantially comprised of deferred security subscription and technical support services revenue. We expect to recognize approximately $1.62 billion as revenue over the next 12 months and the remainder thereafter.

- changed (2022-05-06):
[0001262039-22-000019:note_history:38]
The allowance for credit losses was $2.5 million and $2.4 million as of March 31, 2022 and December 31, 2021, respectively. Provisions, write-offs and recoveries were not material during the three months ended March 31, 2022 and 2021.
  (was, 2021-11-08, similarity 0.8103):
[0001262039-21-000030:note_history:38]
The allowance for credit losses was $2.6 million and $2.5 million as of September 30, 2021 and December 31, 2020, respectively. Provisions, write-offs and recoveries were not material during the nine months ended September 30, 2021 and 2020.

- changed (2022-05-06):
[0001262039-22-000019:note_history:39]
Amortization of deferred contract costs during the three months ended March 31, 2022 and 2021 were $52.5 million and $39.7 million, respectively.
  (was, 2021-11-08, similarity 0.6284):
[0001262039-21-000030:note_history:39]
Amortization of deferred contract costs during the three months ended September 30, 2021 and 2020 were $45.1 million and $35.3 million, respectively. Amortization of deferred contract costs during the nine months ended September 30, 2021 and 2020 were $126.9 million and $99.8 million, respectively.

- removed (2022-05-06):
[0001262039-21-000030:note_history:40]
Disaggregation of Revenue

- removed (2022-05-06):
[0001262039-21-000030:note_history:41]
During the three months ended September 30, 2021 and September 30, 2020, we recognized $309.2 million and $263.1 million in service revenue that was included in the deferred revenue balance as of December 31, 2020 and December 31, 2019, respectively. During the nine months ended September 30, 2021 and September 30, 2020, we recognized $1.10 billion and $921.7 million in service revenue that was included in the deferred revenue balance as of December 31, 2020 and December 31, 2019, respectively.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- changed (2022-05-06):
[0001262039-22-000019:note_history:42]
SUBSEQUENT EVENTS
Common Stock Split
  (was, 2021-11-08, similarity 0.6176):
[0001262039-21-000030:note_history:42]
SUBSEQUENT EVENTS 
Debt Repayment

- added (2022-05-06):
[0001262039-22-000019:note_history:43]
On April 14, 2022, our Board of Directors approved a five-for-one forward stock split of our common stock, conditioned on obtaining stockholder approval at our upcoming 2022 Annual Meeting of Stockholders to be held on June 17, 2022 (the “Stock Split”). If approved by our stockholders, the Stock Split would be effected through an amendment and restatement of our amended and restated certificate of incorporation.

- removed (2022-05-06):
[0001262039-21-000030:note_history:44]
In October 2021, we fully repaid the outstanding $17.6 million of debt liabilities assumed in the AlaxalA transaction.

- removed (2022-05-06):
[0001262039-21-000030:note_history:45]
Building Purchase

- removed (2022-05-06):
[0001262039-21-000030:note_history:46]
In October 2021, we purchased real property in Texas totaling approximately 87,000 square feet for a cash payment of $22.5 million.

- removed (2022-05-06):
[0001262039-21-000030:note_history:47]
Share Repurchase Program

- removed (2022-05-06):
[0001262039-21-000030:note_history:48]
In October 2021, our board of directors approved a $1.25 billion increase in the authorized stock repurchase under the Repurchase Program and extended the term of the Repurchase Program to February 28, 2023, bringing the aggregate amount authorized to be repurchased to $4.25 billion of our outstanding common stock through February 28, 2023.
