# FTNT MD&A — 0001262039-22-000019


## mdna

[0001262039-22-000019:mdna:1]
[same as prior period, unchanged from 0001262039-21-000030:mdna:1]

[0001262039-22-000019:mdna:2]
[same as prior period, unchanged from 0001262039-21-000030:mdna:2]

[0001262039-22-000019:mdna:3]
[same as prior period, unchanged from 0001262039-21-000030:mdna:3]

[0001262039-22-000019:mdna:4]
•effects of the war in Ukraine, related macroeconomic effects and the impact of our decision to suspend operations in Russia;

[0001262039-22-000019:mdna:5]
•effects of increased inflation in certain geographies;

[0001262039-22-000019:mdna:6]
[same as prior period, unchanged from 0001262039-21-000030:mdna:4]

[0001262039-22-000019:mdna:7]
[same as prior period, unchanged from 0001262039-21-000030:mdna:5]

[0001262039-22-000019:mdna:8]
[same as prior period, unchanged from 0001262039-21-000030:mdna:6]

[0001262039-22-000019:mdna:9]
[same as prior period, unchanged from 0001262039-21-000030:mdna:7]

[0001262039-22-000019:mdna:10]
•the proportion of our revenue that consists of product and service revenue, and the mix of billings between products and services, and the duration of service contracts;

[0001262039-22-000019:mdna:11]
[same as prior period, unchanged from 0001262039-21-000030:mdna:9]

[0001262039-22-000019:mdna:12]
[same as prior period, unchanged from 0001262039-21-000030:mdna:10]

[0001262039-22-000019:mdna:13]
•drivers of long-term growth and operating leverage, such as sales productivity and capacity, functionality and value in our subscription service offerings;

[0001262039-22-000019:mdna:14]
•growing our sales to businesses, service providers and government organizations, our ability to execute these sales and the complexity of selling to all segments (including the increased competition and unpredictability of timing associated with sales to larger enterprises), the impact of sales to these organizations on our long-term growth, expansion and operating results, and the effectiveness of our sales organization;

[0001262039-22-000019:mdna:15]
[same as prior period, unchanged from 0001262039-21-000030:mdna:13]

[0001262039-22-000019:mdna:16]
•risks and expectations related to acquisitions and equity interests in private and public companies, including integration issues related to product plans and the acquired technology, and risks of negative impact by such acquisitions and equity investments on our financial results;

[0001262039-22-000019:mdna:17]
[same as prior period, unchanged from 0001262039-21-000030:mdna:15]

[0001262039-22-000019:mdna:18]
[same as prior period, unchanged from 0001262039-21-000030:mdna:16]

[0001262039-22-000019:mdna:19]
•expectations that our operating expense will increase in absolute dollars during 2022;

[0001262039-22-000019:mdna:20]
[same as prior period, unchanged from 0001262039-21-000030:mdna:18]

[0001262039-22-000019:mdna:21]
25

[0001262039-22-000019:mdna:22]
[same as prior period, unchanged from 0001262039-21-000030:mdna:19]

[0001262039-22-000019:mdna:23]
•expectations regarding spending related to real estate acquisitions and development, data center investments, as well as other capital expenditures and to the impact on free cash flow;

[0001262039-22-000019:mdna:24]
•estimates of a range of 2022 spending on capital expenditures;

[0001262039-22-000019:mdna:25]
[same as prior period, unchanged from 0001262039-21-000030:mdna:23]

[0001262039-22-000019:mdna:26]
•statements regarding expected outcomes and liabilities in litigation;

[0001262039-22-000019:mdna:27]
[same as prior period, unchanged from 0001262039-21-000030:mdna:25]

[0001262039-22-000019:mdna:28]
[same as prior period, unchanged from 0001262039-21-000030:mdna:26]

[0001262039-22-000019:mdna:29]
[same as prior period, unchanged from 0001262039-21-000030:mdna:27]

[0001262039-22-000019:mdna:30]
[same as prior period, unchanged from 0001262039-21-000030:mdna:28]

[0001262039-22-000019:mdna:31]
Fortinet is a global leader in cybersecurity solutions provided to a wide variety of organizations, including enterprises, communication service providers and security service providers, government organizations and small businesses. Our cybersecurity solutions are designed to provide broad visibility and segmentation of the digital attack surface through our integrated cybersecurity platform products and services providing a mesh architecture, which feature automated protection, detection and response along with consolidated visibility across both Fortinet developed solutions and a broad ecosystem of third-party solutions and technologies. Our cybersecurity platform portfolio leverages a common operating system or integration to this operating system across our product offerings and helps organizations better secure their environments and reduce their security and network complexities. The Fortinet operating system has an open architecture designed to integrate Fortinet solutions with third-party solutions in a single ecosystem, enabling automated detection and response across the attack surface.

[0001262039-22-000019:mdna:32]
Our product offerings consist of our Core Platform (previously referred to as FortiGate network security physical and virtual products) and our Platform Extension (previously referred to as non-FortiGate physical and virtual, software and cloud-hosted products). In addition to high performing security and networking features, we offer a rich set of cloud-delivered security services that can be added to Platform Extension products and customized to the organization’s use cases.

[0001262039-22-000019:mdna:33]
Our cloud- and hosted- Platform Extension products and services include sandboxing, endpoint detection and response (“EDR”), email security, web application and API security and cloud networking security as well as management and analytics.

[0001262039-22-000019:mdna:34]
Our FortiGuard security services are enabled by FortiGuard Labs, which provides threat research and artificial intelligence capabilities from a cloud network to deliver coordinated protection for the ever-expanding attack surface through Core Platform appliance and virtual machine as well as all Platform Extension products that are registered by the end-customer.

[0001262039-22-000019:mdna:35]
Our FortiCare services provide both technical support and professional services to help our customers deploy, maintain, and operationalize Fortinet’s Core Platform and Platform Extension products and services.

[0001262039-22-000019:mdna:36]
Our proprietary Security Processing Units (“SPUs”) are Application-Specific Integrated Circuits that are implemented in our physical Core Platform appliances and are designed to enhance the security processing capabilities implemented in

[0001262039-22-000019:mdna:37]
software by accelerating computationally intensive tasks such as firewall policy enforcement, software-defined wide-area network (“SD-WAN”), network address translation, Intrusion Prevention Systems (“IPS”), threat detection and encryption. We also provide virtualized Security Processing Units (“vSPUs”) across our Core Platform virtual appliances to deliver similar accelerated capabilities when run in virtualized environments.

[0001262039-22-000019:mdna:38]
Our FortiOS operating system provides the foundation for the operation of all Core Platform and Platform Extension products, whether physical, virtual, private- or public-cloud based. FortiOS directs the operations of processors and SPUs and provides system management functions. We make regular updates to FortiOS available through our FortiCare support services.

[0001262039-22-000019:mdna:39]
Networking functionality and security capabilities are integrated into the FortiOS operating system to run both the Core Platform and Platform Extension capabilities of Fortinet’s cybersecurity mesh architecture. This approach to security combines discrete security solutions together into an integrated operating system which provides centralized management, visibility, automation and intelligence sharing to simplify operations and respond rapidly to threats.

[0001262039-22-000019:mdna:40]
[same as prior period, unchanged from 0001262039-21-000030:mdna:36]

[0001262039-22-000019:mdna:41]
•Secure Networking—Our Security-Driven Networking solutions enables the convergence of networking and security across all edges to provide next-generation firewall (“NGFW”), software-defined wide area network (“SD-WAN”), LAN Edge (Wi-Fi and switch) and secure access service edge (“SASE”). We derive a majority of product sales from our Core Platform network security appliances. Core Platform network security appliances include a broad set of built-in security and networking features and functionalities, including firewall, next-generation firewall, secure web gateway, secure sockets layer (“SSL”) inspection, software-defined wide area network (“SD-WAN”), Intrusion Prevention system (“IPS”), sandboxing, data leak prevention, virtual private network (“VPN”), switch and wireless controller and wide area network (“WAN”) edge. Our network security appliances are managed by our FortiOS network operating system, which provides the foundation for Core Platform security functions. We enhance the performance of our network security appliances from branch to data center by designing and implementing Security Processing Units (“SPUs”) technology within our appliances, enabling us to add security and network functionality with minimal impact to network throughput performance. Along with our secure Wi-Fi access points and switches, Fortinet helps organizations secure their networks across campuses, branches and work-from-home deployments.

[0001262039-22-000019:mdna:42]
•Zero Trust Access—Fortinet’s Platform Extension products and services extend beyond the network to create a cybersecurity mesh architecture to cover other attack vectors. Our Zero Trust Access solutions enable customers to know and control who and what is on their network, in addition to providing security for work from anywhere (“WFA”). Zero Trust Access solutions include FortiNAC, FortiAuthenticator, FortiClient and FortiToken. Additionally, the proliferation of operational technology (“OT”) and internet of things (“IoT”) devices has generated new opportunities for us to grow our business. Our network access control solutions provide visibility, control and automated event responses in order to secure OT and IoT devices.

[0001262039-22-000019:mdna:43]
•Cloud Security—We help customers connect securely to and across their individual, hybrid cloud, multi-cloud and virtualized data center environments by offering security through our virtual firewall and other software products and through integrated capabilities with major cloud platforms. Our public and private cloud security solutions, including virtual appliances and hosted solutions, bring our Platform Extension products and services into and across cloud environments, delivering security that follows their applications and data. Our Secure SD-WAN for Multi-Cloud solution automates deployment of an overlay network across different cloud networks and offers visibility, control and centralized management that integrates functionality across multiple cloud environments. Our Cloud Security portfolio also secures applications, including email and web. Fortinet cloud security offerings are available for deployment in major public and private cloud environments, including Alibaba Cloud, Amazon Web Services, Google Cloud, IBM Cloud, Microsoft Azure, Oracle Cloud and VMWare Cloud. We also offer managed IPS and web application firewall (“WAF”) rules delivered by FortiGuard Labs as an overlay service to native security offerings offered by Amazon Web Services.

[0001262039-22-000019:mdna:44]
•Security Operations—We develop and provide a range of products and services that enable the security operations center (“SOC”) teams to identify, investigate and remediate potential incidents in which cybercriminals bypass prevention-oriented controls. Given the breadth of the attack surface to monitor, as well as the volume and sophistication of cyber threats, artificial intelligence is a key part of these offerings, which include: FortiGuard and other security subscription services, modern endpoint security with EDR, a range of breach-protection technologies plus our security information and event management (“SIEM”) and security orchestration, automation and response (“SOAR”), all of which can be applied across the entire set of Platform Extension products and services. These solutions automatically deliver security intelligence and insights that enable organizations to protect against and respond to threats faster through integration with Fortinet and third-party controls.

[0001262039-22-000019:mdna:45]
[same as prior period, unchanged from 0001262039-21-000030:mdna:20]

[0001262039-22-000019:mdna:46]
•Security as a Service—Our customers purchase our natively integrated FortiGuard security subscription services as an add-on to products and solutions across the Platform Extension products and services with the goal of receiving real-time threat intelligence and protection updates. The rich set of FortiGuard services is built from the ground up to provide comprehensive protection for users and applications, including market leading offerings for IPS, Web, video and DNS filtering, AV and cloud sandbox as well as OT and IoT Security. The FortiGuard security services are provided from our FortiGuard Labs and cloud-delivered to provide real-time unified protection across network endpoint and cloud. FortiCare technical support services and the support of technical account managers, resident engineers and professional service consultants for implementations or training services.

[0001262039-22-000019:mdna:47]
•Support and Professional Services—Fortinet offers technical support, FortiOS updates and extended product warranty through our FortiCare support services. In addition to our technical support services, we offer a range of advanced services, including premium support, professional services and expedited warranty replacement. Our professional service offerings include resident engineers and professional service consultants for implementations or trainings.

[0001262039-22-000019:mdna:48]
[same as prior period, unchanged from 0001262039-21-000030:mdna:43]

[0001262039-22-000019:mdna:49]
•Total revenue was $954.8 million during the three months ended March 31, 2022, an increase of 34%, compared to $710.3 million in the same period last year. Product revenue was $371.0 million during the three months ended March 31, 2022, an increase of 54%, compared to $240.7 million in the same period last year. Service revenue was $583.8 million during the three months ended March 31, 2022, an increase of 24%, compared to $469.6 million in the same period last year.

[0001262039-22-000019:mdna:50]
•Total gross profit was $701.0 million during the three months ended March 31, 2022, an increase of 27%, compared to $553.7 million in the same period last year.

[0001262039-22-000019:mdna:51]
•Cash, cash equivalents, short-term and long-term investments and marketable equity securities were $2.50 billion as of March 31, 2022.

[0001262039-22-000019:mdna:52]
•During the three months ended March 31, 2022, we repurchased 2.3 million shares of common stock under our Share Repurchase Program (the “Repurchase Program”), for a total purchase price of $691.2 million.

[0001262039-22-000019:mdna:53]
•Deferred revenue was $3.66 billion as of March 31, 2022, an increase of $205.0 million, or 6%, from December 31, 2021. Short-term deferred revenue was $1.89 billion as of March 31, 2022, an increase of $115.9 million, or 7%, from December 31, 2021.

[0001262039-22-000019:mdna:54]
•We generated cash flows from operating activities of $396.1 million during the three months ended March 31, 2022, an increase of $80.2 million, or 25%, compared to the same period last year.

[0001262039-22-000019:mdna:55]
•Total bookings were $1.28 billion during the three months ended March 31, 2022, an increase of 50% compared to $851.6 million in the same period last year. We define bookings as the total value of all orders received during the period.

[0001262039-22-000019:mdna:56]
•Backlog was $278.3 million as of March 31, 2022, an increase of $116.4 million compared to $161.9 million as of December 31, 2021. Backlog represents orders received but not fulfilled and excludes backlog related to Alaxala’s products and services of $48.7 million.

[0001262039-22-000019:mdna:57]
On a geographic basis, revenue continues to be diversified, which remains a key strength of our business. During the three months ended March 31, 2022, the Americas region, the Europe, Middle East and Africa (“EMEA”) region and the Asia Pacific (“APAC”) region contributed 40%, 36% and 24% of our total revenue, respectively, and increased by 32%, 25% and 57% compared to the same periods last year, respectively.

[0001262039-22-000019:mdna:58]
Our revenue growth was driven by strong product revenue performance. Product revenue grew 54% during the three months ended March 31, 2022, compared to the same period last year. Product revenue growth was consistent with an elevated cyber threat landscape. Core Platform products accounted for more than half of the product revenue growth during the three months ended March 31, 2022. While Secure SD-WAN contributed to product revenue growth, the main driver was the strong demand for the wide range of other operating system capabilities embedded in the Core Platform products. We experienced strong product revenue growth across many of our Platform Extension products, including our OT solutions, secure access products and software licenses. The impact of the increase in backlog was seen in Core Platform and Platform Extension products. Service revenue growth of 24% during the three months ended March 31, 2022, compared to the same period last

[0001262039-22-000019:mdna:59]
[same as prior period, unchanged from 0001262039-21-000030:mdna:34]

[0001262039-22-000019:mdna:60]
year, was driven by the strength of our FortiCare technical support and other service revenue which grew 26%. FortiGuard and other security subscription revenue, grew 23%.

[0001262039-22-000019:mdna:61]
Our billings were diversified on a geographic basis. During the three months ended March 31, 2022, approximately 50% of our billings in the aggregate were from over 100 countries that each individually contributed less than 3% of our billings.

[0001262039-22-000019:mdna:62]
Operating margin decreased by 1.3 percentage points during the three months ended March 31, 2022 compared to the same period last year. Headcount increased to 10,860 employees and contractors as of March 31, 2022, a 7% increase compared to 10,195 as of December 31, 2021.

[0001262039-22-000019:mdna:63]
[same as prior period, unchanged from 0001262039-21-000030:mdna:59]

[0001262039-22-000019:mdna:64]
The United States and the global community we serve are facing unprecedented challenges posed by the COVID-19 pandemic, including the various COVID-19 variants. In response to the pandemic, we undertook a number of actions to protect our employees, including restricting travel and directing many of our employees to work from home. In certain geographies, we have started to transition back to an in-person working mode, allowing increasing numbers of employees to work from our offices with reasonable precautions and, in all cases, subject to abiding by local legal restrictions. We intend to continue to monitor and abide by local employee health and safety protocols and other regulations as applicable to each local office.

[0001262039-22-000019:mdna:65]
While the broader implications of the COVID-19 pandemic on our employees and overall financial performance continue to evolve, we have seen certain impacts on our business and operations, results of operations, financial condition, cash flows, liquidity and capital and financial resources as of and during the three months ended March 31, 2022. Conversely, some aspects of our business do not appear to have been significantly affected. During the three months ended March 31, 2022, we have observed the following:

[0001262039-22-000019:mdna:66]
•We have seen continued supply chain challenges, including chip and other component shortages and increased costs for certain chips and other components and shipping, and we do not have enough inventory to promptly meet all demand for all products.

[0001262039-22-000019:mdna:67]
•In many countries, our employees’ ability to travel has been reduced. Certain in-person sales and marketing events or meetings that would normally have been held were canceled, postponed or converted into virtual events. However, as certain country’s restrictions start to ease, we have started to see an increase in expenses related to travel and marketing events. Although we cannot predict if or when such expenses will return to pre-pandemic levels, as of March 31, 2022, we have started to see an increase in such expenses as compared to the same period last year.

[0001262039-22-000019:mdna:68]
•In order to mitigate supply chain disruption and other supply chain risks and in anticipation of future demand, we increased our commitments with certain suppliers to secure capacity, and are meeting regularly with our contract manufacturers and component suppliers to manage future commitments, address component shortages and monitor delivery. We have also transitioned primarily to air shipping to avoid port congestion and extended ocean freight time.

[0001262039-22-000019:mdna:69]
Going forward, the situation remains uncertain, rapidly changing and hard to predict, and the COVID-19 pandemic may have a material negative impact on our future periods. If we experience component, shipping or inventory challenges, it will negatively impact billings and product revenue in the current quarter and FortiGuard and FortiCare service revenues in subsequent quarters, as we sell annual and multi-year service contracts that are recognized ratably over the contractual service term. In addition, the broader implications of the pandemic on our business and operations and our financial results, including the extent to which the effects of the pandemic will impact future results and growth in the cybersecurity industry, remain uncertain. The extent of the impact of the COVID-19 pandemic on our operational and financial performance will depend on ongoing developments, including the duration and spread of the virus and its variants, the impact on our end-customers’ spending, the volume of sales and length of our sales cycles, the impact on our partners, suppliers, and employees, actions that may be taken by governmental authorities and other factors identified in Part II, Item 1A “Risk Factors” in this Form 10-Q. Given the dynamic nature of these circumstances, the full impact of the COVID-19 pandemic on our business and operations, results of operations, financial condition, cash flows, liquidity and capital and financial resources cannot be reasonably estimated at this time.

[0001262039-22-000019:mdna:70]
Recent Events

[0001262039-22-000019:mdna:71]
Due to the war in Ukraine and the resulting sanctions and other actions against Russia and Belarus, there has been uncertainty and disruption in the global economy. At the beginning of the war in Ukraine in late February 2022, we experienced

[0001262039-22-000019:mdna:72]
immediate reductions in orders from Russia. On March 7, 2022, we announced that we were suspending sales, support and other operations in Russia.

[0001262039-22-000019:mdna:73]
Although the Russian war against Ukraine did not have a material adverse impact on our revenue or other financial results for the three months ended March 31, 2022, at this time we are unable to fully assess the aggregate impact it will have on our business in future periods due to various uncertainties, which include, but are not limited to, the duration of the war, its effect on the economy, its impact to the businesses of our customers and distributors, actions that may be taken by governmental authorities related to the war, and other factors identified in Part II, Item 1A, “Risk Factors” in this Quarterly Report, including the risk factor titled “The war in Ukraine and our suspension of operations in Russia have affected and may continue to affect our business.”

[0001262039-22-000019:mdna:74]
[same as prior period, unchanged from 0001262039-21-000030:mdna:72]

[0001262039-22-000019:mdna:75]
We typically sell our security solutions to distributors that sell to networking security focused resellers and to service providers and managed security service providers (“MSSPs”), who, in turn, sell to end-customers or use our products and services to provide hosted solutions to other enterprises. At times, we also sell directly to large service providers and major systems integrators. Our end-customers are located in over 100 countries and include small, medium and large enterprises and government organizations across a wide range of industries, including education, financial services, government, healthcare, manufacturing, retail, technology and telecommunications. An end-customer deployment may involve as few as one or as many as thousands of Core Platform as well as Platform Extension products, depending on the end-customer’s size and security requirements.

[0001262039-22-000019:mdna:76]
We also offer our products hosted in our own data centers and through major cloud providers, and have recognized revenue on a usage basis from Alibaba Cloud, Amazon Web Services, Google Cloud, IBM Cloud, Microsoft Azure and Oracle Cloud. We have also recognized revenue from customers who deploy our products in a bring-your-own-license (“BYOL”) arrangement in private clouds or at cloud providers. In a BYOL arrangement, a customer purchases a software license from us through our channel partners and deploys the software in a cloud provider’s environment. Similarly, customers may purchase such a license from us and deploy it in third-party clouds or in their private cloud.

[0001262039-22-000019:mdna:77]
Our customers purchase our hardware products and software licenses, as well as our FortiGuard and other security subscription and FortiCare technical support services. We generally invoice at the time of our sale for the total price of the products and security and technical support services. Standard payment terms are generally no more than 60 days, though we continue to offer extended payment terms to certain distributors.

[0001262039-22-000019:mdna:78]
[same as prior period, unchanged from 0001262039-21-000030:mdna:76]

[0001262039-22-000019:mdna:79]
We monitor several key metrics, including the key financial metrics set forth below, in order to help us evaluate growth trends, establish budgets, measure the effectiveness of our sales and marketing efforts, and assess operational efficiencies. The following table summarizes revenue, deferred revenue, billings (non-GAAP), net cash provided by operating activities, and free cash flow (non-GAAP). We discuss revenue below under “Results of Operations,” and we discuss net cash provided by operating activities below under “—Liquidity and Capital Resources.” Deferred revenue, billings (non-GAAP), and free cash flow (non-GAAP) are discussed immediately below the following table:

[0001262039-22-000019:mdna:80]
|  | Three Months Ended Or As Of |
|  | March 31, 2022 |  | March 31, 2021 |
|  | (in millions) |
| Revenue | $ | 954.8 |  |  | $ | 710.3 |  |
| Deferred revenue | $ | 3,657.9 |  |  | $ | 2,745.6 |  |
| Billings (non-GAAP) | $ | 1,159.8 |  |  | $ | 850.6 |  |
| Net cash provided by operating activities | $ | 396.1 |  |  | $ | 315.9 |  |
| Free cash flow (non-GAAP) | $ | 273.5 |  |  | $ | 263.8 |  |

[0001262039-22-000019:mdna:81]
Deferred revenue. Our deferred revenue consists of amounts that have been invoiced but that have not yet been recognized as revenue. The majority of our deferred revenue balance consists of the unrecognized portion of service revenue from FortiGuard and other security subscription and FortiCare technical support service contracts, which is recognized as revenue ratably over the contractual service period. We monitor our deferred revenue balance, deferred revenue growth and the mix of short-term and long-term deferred revenue because deferred revenue represents a significant portion of free cash flow and of revenue to be recognized in future periods. Deferred revenue was $3.66 billion as of March 31, 2022, an increase of $205.0 million, or 6%, from December 31, 2021.

[0001262039-22-000019:mdna:82]
Billings (non-GAAP). We define billings as revenue recognized in accordance with GAAP plus the change in deferred revenue from the beginning to the end of the period, less any deferred revenue balances acquired from business combination(s) during the period. We consider billings to be a useful metric for management and investors because billings drive current and future revenue, which is an important indicator of the health and viability of our business. There are several limitations related to the use of billings instead of GAAP revenue. First, billings include amounts that have not yet been recognized as revenue and are impacted by the term of FortiGuard security and FortiCare and other support agreements. Second, we may calculate billings in a manner that is different from peer companies that report similar financial measures. Management accounts for these limitations by providing specific information regarding GAAP revenue and evaluating billings together with GAAP revenue. Total billings were $1.16 billion for the three months ended March 31, 2022, an increase of 36% compared to $850.6 million in the same period last year.

[0001262039-22-000019:mdna:83]
[same as prior period, unchanged from 0001262039-21-000030:mdna:82]

[0001262039-22-000019:mdna:84]
|  | Three Months Ended |
|  | March 31, 2022 |  | March 31, 2021 |
|  | (in millions) |
| Billings: |  |  |  |
| Revenue | $ | 954.8 |  |  | $ | 710.3 |  |
| Add: Change in deferred revenue | 205.0 |  |  | 140.3 |  |
| Total billings (non-GAAP) | $ | 1,159.8 |  |  | $ | 850.6 |  |

[0001262039-22-000019:mdna:85]
Free cash flow (non-GAAP). We define free cash flow as net cash provided by operating activities minus purchases of property and equipment and excluding any significant non-recurring items. We believe free cash flow to be a liquidity measure that provides useful information to management and investors about the amount of cash generated by the business that, after capital expenditures, can be used for strategic opportunities, including repurchasing outstanding common stock, investing in our business, making strategic acquisitions, and strengthening the balance sheet. A limitation of using free cash flow rather than the GAAP measures of cash provided by or used in operating activities, investing activities, and financing activities is that free cash flow does not represent the total increase or decrease in the cash and cash equivalents balance for the period because it excludes cash flows from investing activities other than capital expenditures and cash flows from financing activities. Management accounts for this limitation by providing information about our capital expenditures and other investing and financing activities on the face of the consolidated statements of cash flows and under “—Liquidity and Capital Resources” and by presenting cash flows from investing and financing activities in our reconciliation of free cash flow. In addition, it is important to note that other companies, including companies in our industry, may not use free cash flow, may calculate free cash flow in a different manner than we do or may use other financial measures to evaluate their performance, all of which could reduce the usefulness of free cash flow as a comparative measure. A reconciliation of net cash provided by operating activities, the most directly comparable financial measure calculated and presented in accordance with GAAP, to free cash flow is provided below:

[0001262039-22-000019:mdna:86]
|  | Three Months Ended |
|  | March 31, 2022 |  | March 31, 2021 |
|  | (in millions) |
| Free Cash Flow: |  |  |  |
| Net cash provided by operating activities | $ | 396.1 |  |  | $ | 315.9 |  |
| Less: Purchases of property and equipment | (122.6) |  |  | (52.1) |  |
| Free cash flow (non-GAAP) | $ | 273.5 |  |  | $ | 263.8 |  |
| Net cash used in investing activities | $ | (45.4) |  |  | $ | (473.5) |  |
| Net cash provided by (used in) financing activities | $ | (746.0) |  |  | $ | 956.0 |  |

[0001262039-22-000019:mdna:87]
[same as prior period, unchanged from 0001262039-21-000030:mdna:88]

[0001262039-22-000019:mdna:88]
Our discussion and analysis of our financial condition and results of operations are based upon our financial statements, which have been prepared in accordance with GAAP. These principles require us to make estimates and judgments that affect the reported amounts of assets, liabilities, revenue, cost of revenue and expenses, and related disclosures. We base our estimates on historical experience and on various other assumptions that we believe to be reasonable under the

[0001262039-22-000019:mdna:89]
[same as prior period, unchanged from 0001262039-21-000030:mdna:68]

[0001262039-22-000019:mdna:90]
circumstances. To the extent that there are material differences between these estimates and our actual results, our future financial statements will be affected.

[0001262039-22-000019:mdna:91]
There were no material changes to our critical accounting policies and estimates as of and for the three months ended March 31, 2022, as compared to the critical accounting policies and estimates described in our Annual Report on Form 10-K filed with the SEC on February 25, 2022 (the “Form 10-K”).

[0001262039-22-000019:mdna:92]
[same as prior period, unchanged from 0001262039-21-000030:mdna:95]

[0001262039-22-000019:mdna:93]
[same as prior period, unchanged from 0001262039-21-000030:mdna:97]

[0001262039-22-000019:mdna:94]
Three Months Ended March 31, 2022 and 2021

[0001262039-22-000019:mdna:95]
[same as prior period, unchanged from 0001262039-21-000030:mdna:99]

[0001262039-22-000019:mdna:96]
|  | Three Months Ended |  |  |  |  |
| March 31,2022 |  | March 31,2021 |  |  |  |  |
| Amount |  | % ofRevenue |  | Amount |  | % ofRevenue |  | Change |  | % Change |
| (in millions, except percentages) |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 371.0 |  |  | 39 | % |  | $ | 240.7 |  |  | 34 | % |  | $ | 130.3 |  |  | 54 | % |
| Service | 583.8 |  |  | 61 |  |  | 469.6 |  |  | 66 |  |  | 114.2 |  |  | 24 |  |
| Total revenue | $ | 954.8 |  |  | 100 | % |  | $ | 710.3 |  |  | 100 | % |  | $ | 244.5 |  |  | 34 | % |
| Revenue by geography: |  |  |  |  |  |  |  |  |  |  |  |
| Americas | $ | 382.6 |  |  | 40 | % |  | $ | 290.9 |  |  | 41 | % |  | $ | 91.7 |  |  | 32 | % |
| EMEA | 346.0 |  |  | 36 |  |  | 275.7 |  |  | 39 |  |  | 70.3 |  |  | 25 |  |
| APAC | 226.2 |  |  | 24 |  |  | 143.7 |  |  | 20 |  |  | 82.5 |  |  | 57 |  |
| Total revenue | $ | 954.8 |  |  | 100 | % |  | $ | 710.3 |  |  | 100 | % |  | $ | 244.5 |  |  | 34 | % |

[0001262039-22-000019:mdna:97]
Total revenue increased by $244.5 million, or 34%, during the three months ended March 31, 2022 compared to the same period last year. We continued to experience largely organic revenue growth (i.e. revenue growth excluding attribution from recent acquisitions) with diversification of revenue geographically, and across both customers and industries. Revenue from all regions grew, with Americas contributing the largest portion of the increase on an absolute dollar basis and APAC, which included Alaxala, contributing the largest portion of the increase on a percentage basis.

[0001262039-22-000019:mdna:98]
Product revenue increased by $130.3 million, or 54%, during the three months ended March 31, 2022 compared to the same period last year. Product revenue growth was consistent with an elevated cyber threat landscape and included the benefit of certain pricing actions, largely in the second half of 2021. Core Platform products accounted for more than half of the product revenue growth in the three months ended March 31, 2022. While Secure SD-WAN contributed to product revenue growth, the main driver was the strong demand for the wide range of other operating system capabilities embedded in the Core Platform products. We also experienced strong revenue growth across many Platform Extension products, including OT solutions and other secure access.

[0001262039-22-000019:mdna:99]
Service revenue increased by $114.2 million, or 24%, during the three months ended March 31, 2022 compared to the same period last year. FortiGuard security subscription and FortiCare and other technical support and other revenues increased by $57.6 million, or 23%, and by $56.6 million, or 26%, respectively, during the three months ended March 31, 2022 compared to the same period last year. The increases were primarily due to the recognition of revenue from our growing deferred revenue balance related to FortiGuard and other security subscriptions delivered to on-premise and cloud based environments as well as FortiCare and other technical support, including our customers moving to higher-tier support offerings.

[0001262039-22-000019:mdna:100]
Of the service revenue recognized during the three months ended March 31, 2022, 87% was included in the deferred revenue balance as of December 31, 2021. Of the service revenue recognized during the three months ended March 31, 2021, 89% was included in the deferred revenue balance as of December 31, 2020.

[0001262039-22-000019:mdna:101]
32

[0001262039-22-000019:mdna:102]
[same as prior period, unchanged from 0001262039-21-000030:mdna:106]

[0001262039-22-000019:mdna:103]
|  | Three Months Ended |  |  |  |  |
| March 31,2022 |  | March 31,2021 |  | Change |  | % Change |
| (in millions, except percentages) |
| Cost of revenue: |  |  |  |  |  |  |  |
| Product | $ | 161.0 |  |  | $ | 91.3 |  |  | $ | 69.7 |  |  | 76 | % |
| Service | 92.8 |  |  | 65.3 |  |  | 27.5 |  |  | 42 |  |
| Total cost of revenue | $ | 253.8 |  |  | $ | 156.6 |  |  | $ | 97.2 |  |  | 62 | % |
| Gross margin (%): |  |  |  |  |  |  |  |
| Product | 56.6 | % |  | 62.1 | % |  |  |  |  |
| Service | 84.1 |  |  | 86.1 |  |  |  |  |  |
| Total gross margin | 73.4 | % |  | 78.0 | % |  |  |  |  |

[0001262039-22-000019:mdna:104]
Total gross margin decreased by 4.6 percentage points during the three months ended March 31, 2022 compared to the same period last year, driven by the consolidation of Alaxala and a change in revenue mix to lower margin product revenue from higher margin service revenue. Revenue mix shifted by 5.1 percentage points from service revenue to product revenue, as a percentage of total revenue. Total gross margin also reflected a decline in product gross margin and services gross margin.

[0001262039-22-000019:mdna:105]
Product gross margin decreased by 5.5 percentage points during the three months ended March 31, 2022 compared to the same period last year. The decrease in product margin is driven by higher product costs and expedite fees due to supply chain constraints and the consolidation of Alaxala, partially offset by higher average selling prices. Cost of product revenue was comprised primarily of third-party contract manufacturers’ costs and the costs of materials used in production.

[0001262039-22-000019:mdna:106]
Service gross margin decreased by 2.0 percentage points during the three months ended March 31, 2022 compared to the same period last year. Cost of service revenue was comprised primarily of personnel and data center costs. The decrease in service gross margin was primarily impacted by our consolidation of Alaxala and our data center expansion.

[0001262039-22-000019:mdna:107]
[same as prior period, unchanged from 0001262039-21-000030:mdna:111]

[0001262039-22-000019:mdna:108]
|  | Three Months Ended |  | Change |  | % Change |
| March 31,2022 |  | March 31,2021 |  |
| Amount |  | % ofRevenue |  | Amount |  | % ofRevenue |  |
| (in millions, except percentages) |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | $ | 124.9 |  |  | 13 | % |  | $ | 97.2 |  |  | 14 | % |  | $ | 27.7 |  |  | 28 | % |
| Sales and marketing | 387.6 |  |  | 41 |  |  | 304.0 |  |  | 43 |  |  | 83.6 |  |  | 28 |  |
| General and administrative | 38.6 |  |  | 4 |  |  | 32.0 |  |  | 5 |  |  | 6.6 |  |  | 21 |  |
| Gain on IP matter | (1.1) |  |  | — |  |  | (1.1) |  |  | — |  |  | — |  |  | — |  |
| Total operating expenses | $ | 550.0 |  |  | 58 | % |  | $ | 432.1 |  |  | 61 | % |  | $ | 117.9 |  |  | 27 | % |
| Percentages have been rounded for presentation purposes and may differ from unrounded results. |

[0001262039-22-000019:mdna:109]
[same as prior period, unchanged from 0001262039-21-000030:mdna:113]

[0001262039-22-000019:mdna:110]
Research and development expense increased by $27.7 million, or 28%, during the three months ended March 31, 2022 compared to the same period last year, primarily due to an increase of $19.3 million in personnel-related costs as a result of increased headcount to support the development of new products and continued enhancements to our existing products. In addition, we incurred increases in depreciation and other occupancy costs of $7.7 million. We currently intend to continue to invest in our research and development organization, and expect research and development expense to increase in absolute dollars during the remainder of 2022.

[0001262039-22-000019:mdna:111]
[same as prior period, unchanged from 0001262039-21-000030:mdna:115]

[0001262039-22-000019:mdna:112]
Sales and marketing expense increased by $83.6 million, or 28%, during the three months ended March 31, 2022 compared to the same period last year, primarily due to an increase of $56.7 million in personnel-related costs as a result of increases to sales and marketing headcount in order to drive global market revenue increases. In addition, we incurred increases in marketing-related expense of $9.5 million, travel expense of $6.7 million and depreciation and other occupancy expense of $4.4 million. We currently intend to continue to make investments in sales and marketing resources, which are critical to support our future growth, and expect sales and marketing expense to increase in absolute dollars during the remainder of 2022.

[0001262039-22-000019:mdna:113]
[same as prior period, unchanged from 0001262039-21-000030:mdna:117]

[0001262039-22-000019:mdna:114]
General and administrative expense increased by $6.6 million, or 21%, during the three months ended March 31, 2022 compared to the same period last year, primarily due to an increase in personnel-related costs of $4.6 million, an increase in depreciation and other occupancy-related costs of $1.0 million. We currently expect general and administrative expense to increase in absolute dollars during the remainder of 2022.

[0001262039-22-000019:mdna:115]
[same as prior period, unchanged from 0001262039-21-000030:mdna:119]

[0001262039-22-000019:mdna:116]
In January 2020, we entered into an agreement with a competitor in the network security industry, whereby, in February 2020, the competitor party paid us a lump sum of $50.0 million for a mutual covenant-not-to-sue for patent claims. During the three months ended March 31, 2022 and 2021, we recorded $1.1 million in amortization of the deferred component as a gain on IP matter in our condensed consolidated statements of income. See Note 11 of the notes to condensed consolidated financial statements included in Part I, Item 1 of this Quarterly Report on Form 10-Q for additional information regarding the gain on IP matter.

[0001262039-22-000019:mdna:117]
[same as prior period, unchanged from 0001262039-21-000030:mdna:121]

[0001262039-22-000019:mdna:118]
We generated operating income of $151.0 million during the three months ended March 31, 2022, an increase of $29.4 million, or 24%, compared to $121.6 million in the same period last year. Operating income as a percentage of revenue was 16% during the three months ended March 31, 2022, compared to 17% in the same period last year. The decrease in operating margin is primarily due to 4.6 percentage points decrease in gross margin, partially offset by 2.2 percentage points, 0.6 percentage point and 0.5 percentage point decreases in sales and marketing expense, research and development expense, general and administrative expense as percentage of revenue, respectively.

[0001262039-22-000019:mdna:119]
[same as prior period, unchanged from 0001262039-21-000030:mdna:123]

[0001262039-22-000019:mdna:120]
|  | Three Months Ended |  |  |  |  |
| March 31,2022 |  | March 31,2021 |  | Change |  | % Change |
| (in millions, except percentages) |
| Interest income | $ | 1.3 |  |  | $ | 1.1 |  |  | $ | 0.2 |  |  | 18 | % |
| Interest expense | $ | (4.5) |  |  | $ | (1.3) |  |  | $ | (3.2) |  |  | 246 | % |
| Other expense—net | $ | (9.1) |  |  | $ | (2.0) |  |  | $ | (7.1) |  |  | 355 | % |

[0001262039-22-000019:mdna:121]
Interest income increased by $0.2 million during the three months ended March 31, 2022 compared to the same period last year, as a result of higher interest rates. Interest income varies depending on our average investment balances during the period, types and mix of investments, and market interest rates. Interest expense increased by $3.2 million during the three months ended March 31, 2022 compared to the same period last year, primarily due to the senior notes issued in the first quarter of 2021. Other expense—net increased by $7.1 million during the three months ended March 31, 2022 compared to the same period last year, primarily due to an increase of $6.5 million loss on marketable equity securities and an increase of $2.3 million of foreign currency exchange loss, partially offset by net rental income of $1.9 million from real estate.

[0001262039-22-000019:mdna:122]
[same as prior period, unchanged from 0001262039-21-000030:mdna:96]

[0001262039-22-000019:mdna:123]
[same as prior period, unchanged from 0001262039-21-000030:mdna:128]

[0001262039-22-000019:mdna:124]
|  | Three Months Ended |  | Change |  | % Change |
| March 31,2022 |  | March 31,2021 |  |
| (in millions, except percentages) |
| Provision for (benefit from) income taxes | $ | (8.1) |  |  | $ | 12.2 |  |  | $ | (20.3) |  |  | (166) | % |
| Effective tax rate (%) | (6) | % |  | 10 | % |  |  |  |  |

[0001262039-22-000019:mdna:125]
Our effective tax rate was negative 6% for the three months ended March 31, 2022 compared to an effective tax rate of 10% for the same period last year. The benefit from income taxes for the three months ended March 31, 2022 was primarily comprised of U.S. federal and state taxes, withholding taxes and foreign taxes that were $38.5 million, which were favorably affected by a tax benefit of $14.4 million from the foreign-derived intangible income deduction (the “FDII deduction”) and excess tax benefits from stock-based compensation expense of $32.2 million.

[0001262039-22-000019:mdna:126]
The provision for income taxes for the three months ended March 31, 2021 was comprised of U.S. federal and state taxes, withholding taxes, and foreign taxes that were $35.7 million, which were offset by a tax benefit of $7.3 million from the FDII deduction and excess tax benefits from stock-based compensation expense of $16.2 million.

[0001262039-22-000019:mdna:127]
[same as prior period, unchanged from 0001262039-21-000030:mdna:169]

[0001262039-22-000019:mdna:128]
|  | As of |
|  | March 31,2022 |  | December 31,2021 |
|  | (in millions) |
| Cash and cash equivalents | $ | 923.5 |  |  | $ | 1,319.1 |  |
| Short-term and long-term investments | 1,546.5 |  |  | 1,634.8 |  |
| Marketable equity securities | 32.4 |  |  | 38.6 |  |
| Total cash, cash equivalents, investments and marketable equity securities | $ | 2,502.4 |  |  | $ | 2,992.5 |  |
| Working capital | $ | 697.8 |  |  | $ | 1,282.5 |  |
|  | Three Months Ended |
|  | March 31,2022 |  | March 31,2021 |
|  | (in millions) |
| Net cash provided by operating activities | $ | 396.1 |  |  | $ | 315.9 |  |
| Net cash used in investing activities | (45.4) |  |  | (473.5) |  |
| Net cash provided by (used in) financing activities | (746.0) |  |  | 956.0 |  |
| Effect of exchange rate changes on cash and cash equivalents | (0.3) |  |  | — |  |
| Net increase (decrease) in cash and cash equivalents | $ | (395.6) |  |  | $ | 798.4 |  |

[0001262039-22-000019:mdna:129]
Liquidity and capital resources may be impacted by our operating activities, as well as by our stock repurchases, proceeds from the issuance of common stock, investment grade debt issuance and payment of taxes in connection with the net settlement of equity awards, real estate and other capital expenditures, business acquisitions and the timing of inventory deliveries.

[0001262039-22-000019:mdna:130]
In recent years, we have received significant capital resources from our billings to customers, issuance of investment grade debt and, to some extent, from the exercise of stock options by our employees. Additional increases in billings may depend on a number of factors, including demand for and availability of our products and services, competition, market or industry changes, macroeconomic events such as the COVID-19 pandemic, supply chain capacity and disruptions, international conflicts, including the war in Ukraine, and our ability to execute. We expect proceeds from the exercise of stock options in future years to be impacted by the increased mix of restricted stock units versus stock options granted to our employees and to vary based on our share price.

[0001262039-22-000019:mdna:131]
In October 2021, our board of directors authorized a $1.25 billion increase in the authorized stock repurchase under the Repurchase Program and extended the term of the Repurchase Program to February 28, 2023, bringing the aggregate amount of

[0001262039-22-000019:mdna:132]
authorized to be repurchased to $4.25 billion of our outstanding common stock through February 28, 2023. During the three months ended March 31, 2022, we repurchased 2.3 million shares of common stock under the Repurchase Program for an aggregate purchase price of $691.2 million. As of March 31, 2022, $829.6 million remained available for future share repurchases under the Repurchase Program.

[0001262039-22-000019:mdna:133]
[same as prior period, unchanged from 0001262039-21-000030:mdna:175]

[0001262039-22-000019:mdna:134]
We expect to continue to increase our office and warehouse capacity to support growth. As we purchase new properties, we will work to incorporate these properties into the environmental goals we have established. We estimate capital expenditures to be between $150.0 million and $180.0 million in the rest of 2022.

[0001262039-22-000019:mdna:135]
We believe that our cash provided by operating activities, together with our existing cash, cash equivalents and investments will be sufficient to meet our anticipated cash needs and do not currently intend to retire these Notes early. Refer to Note 10. Debt in Part I, Item 1 of this Quarterly Report on Form 10-Q for information on the Notes. As of March 31, 2022, the long-term debt, net of unamortized discount and debt issuance costs, was $988.9 million.

[0001262039-22-000019:mdna:136]
We enter into non-cancellable agreements with contract manufacturers and certain component suppliers to procure inventory based on our requirements in order to negotiate manufacturing lead times and encourage and incentivize vendors to deliver components and finished goods. These purchase commitments totaled $1.37 billion as of March 31, 2022. We also have open purchase orders and contractual obligations in the ordinary course of business for which we have not received goods or services. As of March 31, 2022, we had $114.4 million in other contractual commitments having a remaining term in excess of one year that are non-cancelable.

[0001262039-22-000019:mdna:137]
There have been no significant changes to our leases as disclosed in our Annual Report on Form 10-K for the year ended December 31, 2021 other than as of March 31, 2022 we had additional minimum lease payments of $39.7 million relating to operating leases that had been signed but had not yet commenced. These leases will commence during 2022 and will have lease terms of approximately one to six years.

[0001262039-22-000019:mdna:138]
As of March 31, 2022, our cash, cash equivalents, short-term and long-term investments and marketable equity securities of $2.50 billion were invested primarily in deposit accounts, money market funds, corporate debt securities, commercial paper, certificates of deposit and term deposits, U.S. government and agency securities, municipal bonds and marketable equity securities. It is our investment policy to invest excess cash in a manner that preserves capital, provides liquidity and generates return without significantly increasing risk. We do not enter into investments for trading or speculative purposes.

[0001262039-22-000019:mdna:139]
The amount of cash, cash equivalents and investments held by our international subsidiaries was $143.9 million as of March 31, 2022 and $132.4 million as of December 31, 2021.

[0001262039-22-000019:mdna:140]
We believe that our existing cash and cash equivalents and cash flow from operations will be sufficient for at least the next 12 months to meet our requirements and plans for cash, including meeting our working capital requirements and capital expenditure requirements. In the long term, our ability to support our requirements and plans for cash, including our working capital and capital expenditure requirements will depend on many factors, including our growth rate, the timing and amount of our share repurchases, the expansion of sales and marketing activities, the introduction of new and enhanced products and services offerings, the continuing market acceptance of our products, the timing and extent of spending to support development efforts, our investments in purchasing or leasing real estate and macroeconomic impacts such as the COVID-19 pandemic. Historically, we have required capital principally to fund our working capital needs, share repurchases, capital expenditures and acquisition activities. In the event that additional financing is required from outside sources, we may not be able to raise it on terms acceptable to us or at all.

[0001262039-22-000019:mdna:141]
As of March 31, 2022, we did not have any relationships with unconsolidated organizations or financial partnerships, such as structured finance or special purpose entities that would have been established for the purpose of facilitating off-balance sheet arrangements or other contractually narrow or limited purposes.

[0001262039-22-000019:mdna:142]
[same as prior period, unchanged from 0001262039-21-000030:mdna:183]

[0001262039-22-000019:mdna:143]
Cash generated by operating activities is our primary source of liquidity. It is primarily comprised of net income, as adjusted for non-cash items and changes in operating assets and liabilities. Non-cash adjustments consist primarily of stock-

[0001262039-22-000019:mdna:144]
36

[0001262039-22-000019:mdna:145]
based compensation, amortization of deferred contract costs and depreciation and amortization. Changes in operating assets and liabilities consist primarily of changes in deferred revenue, deferred tax assets, accrued liabilities and deferred contract costs.

[0001262039-22-000019:mdna:146]
Our operating activities during the three months ended March 31, 2022 provided cash flows of $396.1 million as a result of the continued growth of our business and our ability to successfully manage our working capital. Changes in operating assets and liabilities primarily resulted from an increase in sales of our FortiGuard and other security subscription services and FortiCare technical support services to new and existing customers, as reflected by an increase in our deferred revenue. Our total deferred revenue balance grew $205 million, or 6%, during the three months ended March 31, 2022.

[0001262039-22-000019:mdna:147]
[same as prior period, unchanged from 0001262039-21-000030:mdna:186]

[0001262039-22-000019:mdna:148]
The changes in cash flows from investing activities primarily relate to timing of purchases, maturities and sales of investments and purchases of property and equipment. Historically, in making a lease versus ownership decision related to our larger facilities, we have considered various factors including financial metrics and the impact on our engineers and other employees. In certain cases, we have elected to own a facility if we believed that ownership rather than leasing is more closely aligned with our long-term strategy. We expect to make similar decisions in the future. We may also make cash payments in connection with future business combinations.

[0001262039-22-000019:mdna:149]
During the three months ended March 31, 2022, cash used in investing activities was $45.4 million, driven by $122.6 million of purchases of property and equipment and $77.2 million spent for purchases of investments, net of maturities and sales of investments.

[0001262039-22-000019:mdna:150]
[same as prior period, unchanged from 0001262039-21-000030:mdna:189]

[0001262039-22-000019:mdna:151]
[same as prior period, unchanged from 0001262039-21-000030:mdna:190]

[0001262039-22-000019:mdna:152]
During the three months ended March 31, 2022, cash used in financing activities was $746.0 million, primarily driven by $691.2 million used to repurchase shares of our common stock and $53.8 million used to pay tax withholding, net of proceeds from the issuance of common stock.
