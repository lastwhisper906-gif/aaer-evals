# FTNT notes — 0001262039-20-000067


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001262039-20-000067:notes:1]
SUMMARY OF SIGNIFICANT ACCOUNTING POLICIES
Basis of Presentation and Preparation—The unaudited condensed consolidated financial statements of Fortinet, Inc. and its wholly owned subsidiaries (collectively, “we,” “us” or “our”) have been prepared in accordance with generally accepted accounting principles in the United States (“GAAP”) for interim financial information, as well as the instructions to Form 10-Q pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (the “SEC”). Accordingly, they do not include all of the information and footnotes required by GAAP for complete financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the year ended December 31, 2019, contained in our Annual Report on Form 10-K filed with the SEC on February 26, 2020. In the opinion of management, all adjustments, which includes normal recurring adjustments, considered necessary for a fair presentation have been included. All intercompany balances, transactions and cash flows have been eliminated. The results of operations for the three and nine months ended September 30, 2020 are not necessarily indicative of the results for the full year or for any future periods. The condensed consolidated balance sheet as of December 31, 2019 is derived from the audited consolidated financial statements for the year ended December 31, 2019. For 2020, the amounts previously reported as Income taxes payable are included in Accrued liabilities. Prior periods have been reclassified to conform with current period presentation.

[0001262039-20-000067:notes:2]
[same as prior period, unchanged from 0001262039-20-000053:notes:2]

[0001262039-20-000067:notes:3]
There have been no material changes to our significant accounting policies as of and for the three and nine months ended September 30, 2020.

[0001262039-20-000067:notes:4]
Recently Adopted Accounting Standards

[0001262039-20-000067:notes:5]
[same as prior period, unchanged from 0001262039-20-000053:notes:5]

[0001262039-20-000067:notes:6]
In June 2016, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) 2016-13—Financial Instruments—Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments (“Topic 326”), which provides guidance on how an entity should measure credit losses on financial instruments. The standard replaces the existing incurred loss model with an expected credit loss model for financial assets measured at amortized cost, including trade receivables, and requires that credit losses on available-for-sale debt securities be presented as an allowance rather than as a write-down. The new approach to estimating credit losses (referred to as the current expected credit losses model) generally accelerates recognition of credit losses. We adopted Topic 326 on January 1, 2020 using the modified retrospective method. The adoption of this standard did not have a material impact on our condensed consolidated financial statements.

[0001262039-20-000067:notes:7]
[same as prior period, unchanged from 0001262039-20-000053:notes:7]

[0001262039-20-000067:notes:8]
In August 2018, the FASB issued ASU 2018-15—Intangibles—Goodwill and Other—Internal-Use Software (Subtopic 350-40): Customer’s Accounting for Implementation Costs Incurred in a Cloud Computing Arrangement That Is a Service Contract, which requires a customer in a cloud computing arrangement that is a service contract to follow the internal-use software guidance in Accounting Standards Codification (“ASC”) Topic 350, Intangibles—Goodwill and Other, to determine which implementation costs to capitalize as assets or expense as incurred. We adopted ASU 2018-15 on January 1, 2020. The adoption of this standard did not have a material impact on our condensed consolidated financial statements.

[0001262039-20-000067:notes:9]
[same as prior period, unchanged from 0001262039-20-000053:notes:9]

[0001262039-20-000067:notes:10]
In August 2018, the FASB issued ASU 2018-13—Fair Value Measurement (Topic 820): Disclosure Framework—Changes to the Disclosure Requirements for Fair Value Measurement, which eliminates, adds and modifies certain disclosure requirements for fair value measurements in ASC 820, Fair Value Measurement, as part of its disclosure framework project. We adopted ASU 2018-13 on January 1, 2020. The adoption of this standard did not have a material impact on our disclosures.

[0001262039-20-000067:notes:11]
[same as prior period, unchanged from 0001262039-20-000053:notes:11]

[0001262039-20-000067:notes:12]
[same as prior period, unchanged from 0001262039-20-000053:notes:12]

[0001262039-20-000067:notes:13]
In December 2019, the FASB issued ASU 2019-12—Income Taxes (Topic 740): Simplifying the Accounting for Income Taxes. The amendments in ASU 2019-12 simplify the accounting for income taxes by removing certain exceptions to the general principles in Topic 740. The amendments also improve consistent application and simplification of GAAP for other areas of Topic 740 by clarifying and amending existing guidance. ASU 2019-12 is effective for us beginning on January 1, 2021. We are currently evaluating the impact of ASU 2019-12 on our condensed consolidated financial statements.


## us-gaap:AccountingChangesAndErrorCorrectionsTextBlock

[0001262039-20-000067:notes:14]
IMMATERIAL CORRECTION OF PRIOR PERIOD FINANCIAL STATEMENTS
Subsequent to the issuance of our condensed consolidated financial statements for the period ended June 30, 2020, we identified an immaterial error related to the commencement of revenue recognition for certain FortiCare standalone service contracts. Rather than commencing recognition upon end user registration, we should have begun to recognize revenue over the service period when control had passed to the distributor which we have determined is our customer. We assessed the effect of this correction, individually and in the aggregate, on prior periods’ financial statements in accordance with the SEC’s Staff Accounting Bulletins No. 99 and 108 and, based on an analysis of quantitative and qualitative factors, determined that the correction was not individually material to any of our prior interim or annual consolidated financial statements.

[0001262039-20-000067:notes:15]
All financial information contained in the accompanying notes to these condensed consolidated financial statements has been revised to reflect the correction of this error.

[0001262039-20-000067:notes:16]
The corrections to our condensed consolidated balance sheet as of December 31, 2019 were as follows (in millions):

[0001262039-20-000067:notes:17]
|  | December 31, 2019 |
|  | As Previously Reported |  | Corrections |  | As Corrected |
| ASSETS |  |  |  |  |  |
| DEFERRED TAX ASSETS | $ | 232.6 |  |  | $ | (6.3) |  |  | $ | 226.3 |  |
| TOTAL ASSETS | 3,885.5 |  |  | (6.3) |  |  | 3,879.2 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |  |  |
| CURRENT LIABILITIES: |  |  |  |  |  |
| Deferred revenue | 1,173.6 |  |  | (17.8) |  |  | 1,155.8 |  |
| Total current liabilities | 1,473.6 |  |  | (17.8) |  |  | 1,455.8 |  |
| DEFERRED REVENUE | 962.3 |  |  | (9.0) |  |  | 953.3 |  |
| Total liabilities | 2,563.6 |  |  | (26.8) |  |  | 2,536.8 |  |
| STOCKHOLDERS’ EQUITY: |  |  |  |  |  |
| Retained earnings (accumulated deficit) | 140.3 |  |  | 20.5 |  |  | 160.8 |  |
| Total stockholders’ equity | 1,321.9 |  |  | 20.5 |  |  | 1,342.4 |  |
| TOTAL LIABILITIES AND STOCKHOLDERS’ EQUITY | $ | 3,885.5 |  |  | $ | (6.3) |  |  | $ | 3,879.2 |  |

[0001262039-20-000067:notes:18]
The corrections to our condensed consolidated statements of income for the three and nine months ended September 30, 2019 were as follows (in millions, except per share amounts):

[0001262039-20-000067:notes:19]
|  | Three Months Ended September 30, 2019 |
|  | As Previously Reported |  | Corrections |  | As Corrected |
| REVENUE: |  |  |  |  |  |
| Service | $ | 350.4 |  |  | $ | 0.6 |  |  | $ | 351.0 |  |
| Total revenue | 547.5 |  |  | 0.6 |  |  | 548.1 |  |
| GROSS PROFIT: |  |  |  |  |  |
| Service | 305.3 |  |  | 0.6 |  |  | 305.9 |  |
| Total gross profit | 423.4 |  |  | 0.6 |  |  | 424.0 |  |
| OPERATING INCOME | 100.0 |  |  | 0.6 |  |  | 100.6 |  |
| INCOME BEFORE INCOME TAXES | 105.4 |  |  | 0.6 |  |  | 106.0 |  |
| PROVISION FOR INCOME TAXES | 25.6 |  |  | 0.2 |  |  | 25.8 |  |
| NET INCOME | $ | 79.8 |  |  | $ | 0.4 |  |  | $ | 80.2 |  |
| Net income per share (Note 10): |  |  |  |  |  |
| Basic | $ | 0.47 |  |  | $ | — |  |  | $ | 0.47 |  |
| Diluted | $ | 0.46 |  |  | $ | — |  |  | $ | 0.46 |  |

[0001262039-20-000067:notes:20]
|  | Nine Months Ended September 30, 2019 |
|  | As Previously Reported |  | Corrections |  | As Corrected |
| REVENUE: |  |  |  |  |  |
| Service | $ | 992.1 |  |  | $ | 3.1 |  |  | $ | 995.2 |  |
| Total revenue | 1,541.8 |  |  | 3.1 |  |  | 1,544.9 |  |
| GROSS PROFIT: |  |  |  |  |  |
| Service | 858.6 |  |  | 3.1 |  |  | 861.7 |  |
| Total gross profit | 1,176.4 |  |  | 3.1 |  |  | 1,179.5 |  |
| OPERATING INCOME | 225.8 |  |  | 3.1 |  |  | 228.9 |  |
| INCOME BEFORE INCOME TAXES | 251.5 |  |  | 3.1 |  |  | 254.6 |  |
| PROVISION FOR INCOME TAXES | 40.2 |  |  | 0.9 |  |  | 41.1 |  |
| NET INCOME | $ | 211.3 |  |  | $ | 2.2 |  |  | $ | 213.5 |  |
| Net income per share (Note 10): |  |  |  |  |  |
| Basic | $ | 1.24 |  |  | $ | 0.01 |  |  | $ | 1.25 |  |
| Diluted | $ | 1.21 |  |  | $ | 0.01 |  |  | $ | 1.22 |  |

[0001262039-20-000067:notes:21]
The corrections to our condensed consolidated statements of cash flows for the nine months ended September 30, 2019 were as follows (in millions):

[0001262039-20-000067:notes:22]
|  | Nine Months Ended September 30, 2019 |
|  | As Previously Reported |  | Corrections |  | As Corrected |
| CASH FLOWS FROM OPERATING ACTIVITIES: |  |  |  |  |  |
| Net income | $ | 211.3 |  |  | $ | 2.2 |  |  | $ | 213.5 |  |
| Changes in operating assets and liabilities: |  |  |  |  |  |
| Deferred tax assets | 10.6 |  |  | 0.9 |  |  | 11.5 |  |
| Deferred revenue | 258.8 |  |  | (3.1) |  |  | 255.7 |  |
| Net cash provided by operating activities | $ | 617.6 |  |  | $ | — |  |  | $ | 617.6 |  |

[0001262039-20-000067:notes:23]
The results for the nine months ended September 30, 2020 include corrections to increase revenue, gross profit and operating income by $0.8 million and $2.1 million for the three months ended March 31, 2020 and June 30, 2020, respectively, and to increase net income by $0.6 million and $1.7 million for the three months ended March 31, 2020 and June 30, 2020, respectively. The correction did not change diluted net income per share for the three months ended March 31, 2020 but did increase diluted net income per share by $0.01 for the three months ended June 30, 2020. For all periods in which we corrected net income, we made corresponding corrections to net income and comprehensive income in our condensed consolidated statements of comprehensive income and to net income, retained earnings (accumulated deficit) and total stockholders’ equity in our condensed consolidated statements of stockholders’ equity.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001262039-20-000067:notes:24]
REVENUE RECOGNITION
We sell cybersecurity solutions to a variety of organizations, such as enterprises, communication service providers, government organizations and small businesses. Our revenue consists of product and service revenue. Product revenue is generated by our FortiGate network security appliances, our Fortinet Security Fabric platform products and other products. Service revenue relates to sales of our security subscription services, which mainly consist of our FortiGuard security solutions, as well as our FortiCare technical support services and other services.

[0001262039-20-000067:notes:25]
[same as prior period, unchanged from 0001262039-20-000053:notes:15]

[0001262039-20-000067:notes:26]
[same as prior period, unchanged from 0001262039-20-000053:notes:16]

[0001262039-20-000067:notes:27]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30,2020 |  | September 30,2019 |  | September 30,2020 |  | September 30,2019 |
| Product | $ | 223.8 |  |  | $ | 197.1 |  |  | $ | 628.0 |  |  | $ | 549.7 |  |
| Service: |  |  |  |  |  |  |  |
| Security subscription | 235.4 |  |  | 192.8 |  |  | 669.4 |  |  | 545.5 |  |
| Technical support and other | 191.9 |  |  | 158.2 |  |  | 549.0 |  |  | 449.7 |  |
| Total service revenue | 427.3 |  |  | 351.0 |  |  | 1,218.4 |  |  | 995.2 |  |
| Total revenue | $ | 651.1 |  |  | $ | 548.1 |  |  | $ | 1,846.4 |  |  | $ | 1,544.9 |  |

[0001262039-20-000067:notes:28]
[same as prior period, unchanged from 0001262039-20-000053:notes:18]

[0001262039-20-000067:notes:29]
During the three months ended September 30, 2020 and September 30, 2019, we recognized $263.1 million and $211.8 million in service revenue that was included in the deferred revenue balance as of December 31, 2019 and December 31, 2018, respectively. During the nine months ended September 30, 2020 and September 30, 2019, we recognized $921.7 million and $754.5 million in service revenue that was included in the deferred revenue balance as of December 31, 2019 and December 31, 2018, respectively.

[0001262039-20-000067:notes:30]
[same as prior period, unchanged from 0001262039-20-000053:notes:20]

[0001262039-20-000067:notes:31]
As of September 30, 2020, the aggregate amount of the transaction price allocated to remaining performance obligations was $2.39 billion, which was substantially comprised of deferred security subscription and technical support services revenue. We expect to recognize approximately $1.30 billion as revenue over the next 12 months and the remainder thereafter.

[0001262039-20-000067:notes:32]
[same as prior period, unchanged from 0001262039-20-000053:notes:22]

[0001262039-20-000067:notes:33]
Trade accounts receivable are recorded at the invoiced amount. On January 1, 2020, we adopted Topic 326, which provides guidance on how to measure credit losses on financial instruments, including accounts receivable. Prior to our adoption of Topic 326, our accounts receivable balance was reduced by an allowance for doubtful accounts that we determined based on our assessment of the collectability of customer accounts. Under Topic 326, our accounts receivable balance is reduced by an allowance for expected credit losses. We measure expected credit losses of accounts receivable on a collective (pooled) basis, aggregating accounts receivable that are either current or no more than 60 days past due, and aggregating accounts receivable that are more than 60 days past due. We apply a credit-loss percentage to each of the pools that is based on our historical credit losses. We review whether each of our significant accounts receivable that is more than 60 days past due continues to exhibit similar risk characteristics with the other accounts receivable in the pool. If we determine that it does not, we evaluate it for expected credit losses on an individual basis.

[0001262039-20-000067:notes:34]
[same as prior period, unchanged from 0001262039-20-000053:notes:25]

[0001262039-20-000067:notes:35]
The allowance for credit losses was $2.2 million as of September 30, 2020, and the allowance for doubtful accounts was $1.2 million as of December 31, 2019. Provisions, write-offs and recoveries were not material during the nine months ended September 30, 2020.

[0001262039-20-000067:notes:36]
[same as prior period, unchanged from 0001262039-20-000053:notes:27]

[0001262039-20-000067:notes:37]
Sales commissions earned by our sales force are considered incremental and recoverable costs of obtaining a contract with a customer. The amortization of deferred contract costs is included in sales and marketing expense in our condensed consolidated statements of income. Amortization of deferred contract costs during the three months ended September 30, 2020 and September 30, 2019 were $35.3 million and $27.5 million, respectively. Amortization of deferred contract costs during the nine months ended September 30, 2020 and September 30, 2019 were $99.8 million and $78.5 million, respectively.


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0001262039-20-000067:notes:38]
[same as prior period, unchanged from 0001262039-20-000053:notes:29]

[0001262039-20-000067:notes:39]
|  | September 30, 2020 |
|  | AmortizedCost |  | UnrealizedGains |  | UnrealizedLosses |  | FairValue |
| Corporate debt securities | $ | 501.1 |  |  | $ | 1.8 |  |  | $ | (0.1) |  |  | $ | 502.8 |  |
| U.S. government securities | 166.3 |  |  | 0.1 |  |  | — |  |  | 166.4 |  |
| Commercial paper | 125.2 |  |  | 0.1 |  |  | — |  |  | 125.3 |  |
| Certificates of deposit and term deposits (1) | 97.8 |  |  | — |  |  | — |  |  | 97.8 |  |
| Total available-for-sale securities | $ | 890.4 |  |  | $ | 2.0 |  |  | $ | (0.1) |  |  | $ | 892.3 |  |

[0001262039-20-000067:notes:40]
|  | December 31, 2019 |
|  | AmortizedCost |  | UnrealizedGains |  | UnrealizedLosses |  | FairValue |
| Corporate debt securities | $ | 576.1 |  |  | $ | 1.0 |  |  | $ | (0.1) |  |  | $ | 577.0 |  |
| U.S. government securities | 195.0 |  |  | 0.2 |  |  | — |  |  | 195.2 |  |
| Commercial paper | 148.7 |  |  | 0.1 |  |  | — |  |  | 148.8 |  |
| Certificates of deposit and term deposits (1) | 66.4 |  |  | — |  |  | — |  |  | 66.4 |  |
| Total available-for-sale securities | $ | 986.2 |  |  | $ | 1.3 |  |  | $ | (0.1) |  |  | $ | 987.4 |  |
| (1) The majority of our certificates of deposit and term deposits are foreign deposits. |

[0001262039-20-000067:notes:41]
[same as prior period, unchanged from 0001262039-20-000053:notes:32]

[0001262039-20-000067:notes:42]
|  | September 30, 2020 |
|  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
|  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |
| Corporate debt securities | $ | 103.9 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 103.9 |  |  | $ | — |  |
| U.S. government securities | 42.1 |  |  | — |  |  | — |  |  | — |  |  | 42.1 |  |  | — |  |
| Commercial paper | 24.6 |  |  | — |  |  | — |  |  | — |  |  | 24.6 |  |  | — |  |
| Certificates of deposit and term deposits | 17.3 |  |  | (0.1) |  |  | — |  |  | — |  |  | 17.3 |  |  | (0.1) |  |
| Total available-for-sale securities | $ | 187.9 |  |  | $ | (0.1) |  |  | $ | — |  |  | $ | — |  |  | $ | 187.9 |  |  | $ | (0.1) |  |

[0001262039-20-000067:notes:43]
|  | December 31, 2019 |
|  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
|  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |
| Corporate debt securities | $ | 117.3 |  |  | $ | (0.1) |  |  | $ | 16.1 |  |  | $ | — |  |  | $ | 133.4 |  |  | $ | (0.1) |  |
| U.S. government securities | 47.1 |  |  | — |  |  | — |  |  | — |  |  | 47.1 |  |  | — |  |
| Commercial paper | 26.0 |  |  | — |  |  | — |  |  | — |  |  | 26.0 |  |  | — |  |
| Certificates of deposit and term deposits | 13.0 |  |  | — |  |  | — |  |  | — |  |  | 13.0 |  |  | — |  |
| Total available-for-sale securities | $ | 203.4 |  |  | $ | (0.1) |  |  | $ | 16.1 |  |  | $ | — |  |  | $ | 219.5 |  |  | $ | (0.1) |  |

[0001262039-20-000067:notes:44]
[same as prior period, unchanged from 0001262039-20-000053:notes:35]

[0001262039-20-000067:notes:45]
|  | September 30,2020 |  | December 31,2019 |
| Due within one year | $ | 774.4 |  |  | $ | 843.1 |  |
| Due within one to three years | 117.9 |  |  | 144.3 |  |
| Total | $ | 892.3 |  |  | $ | 987.4 |  |

[0001262039-20-000067:notes:46]
Available-for-sale securities are reported at fair value, with unrealized gains and losses and the related tax impact included as a separate component of stockholders’ equity and in comprehensive income. Accrued interest of $3.2 million as of September 30, 2020 is excluded from both the fair value and the amortized cost of our available-for-sale securities and is recorded in Prepaid expenses and other current assets in our condensed consolidated balance sheet. We have elected to not record an allowance for credit losses for accrued interest for available-for-sale securities and will reverse the accrued interest against interest income in the period in which we determine the accrued interest to be uncollectible.

[0001262039-20-000067:notes:47]
Prior to 2020, we followed the guidance in ASC 320 Investments—Debt and Equity Securities in determining whether unrealized losses were other than temporary. We adopted Topic 326 on January 1, 2020, and now consider whether unrealized losses have resulted from a credit loss or other factors. The unrealized losses on our available-for-sale securities as of September 30, 2020 and as of December 31, 2019 were caused by fluctuations in market value and interest rates as a result of the economic environment. We concluded that an allowance for credit losses was unnecessary as of September 30, 2020 and that the impairments as of December 31, 2019 were not other than temporary because (i) the decline in market value was attributable to changes in market conditions and not credit quality, and (ii) we concluded that neither do we intend to sell nor is it more likely than not that we will be required to sell these investments prior to recovery of their amortized cost basis.

[0001262039-20-000067:notes:48]
[same as prior period, unchanged from 0001262039-20-000053:notes:39]

[0001262039-20-000067:notes:49]
[same as prior period, unchanged from 0001262039-20-000053:notes:40]

[0001262039-20-000067:notes:50]
[same as prior period, unchanged from 0001262039-20-000053:notes:41]

[0001262039-20-000067:notes:51]
[same as prior period, unchanged from 0001262039-20-000053:notes:42]

[0001262039-20-000067:notes:52]
[same as prior period, unchanged from 0001262039-20-000053:notes:43]

[0001262039-20-000067:notes:53]
[same as prior period, unchanged from 0001262039-20-000053:notes:44]

[0001262039-20-000067:notes:54]
[same as prior period, unchanged from 0001262039-20-000053:notes:45]

[0001262039-20-000067:notes:55]
[same as prior period, unchanged from 0001262039-20-000053:notes:46]

[0001262039-20-000067:notes:56]
[same as prior period, unchanged from 0001262039-20-000053:notes:47]

[0001262039-20-000067:notes:57]
[same as prior period, unchanged from 0001262039-20-000053:notes:48]

[0001262039-20-000067:notes:58]
The following tables present the fair value of our financial assets measured at fair value on a recurring basis as of September 30, 2020 and December 31, 2019 (in millions):

[0001262039-20-000067:notes:59]
|  | September 30, 2020 |  | December 31, 2019 |
|  | AggregateFairValue |  | QuotedPrices inActiveMarkets ForIdenticalAssets |  | SignificantOtherObservableRemainingInputs |  | SignificantOtherUnobservableRemainingInputs |  | AggregateFairValue |  | QuotedPrices inActiveMarkets ForIdenticalAssets |  | SignificantOtherObservableRemainingInputs |  | SignificantOtherUnobservableRemainingInputs |
|  |  |  | (Level 1) |  | (Level 2) |  | (Level 3) |  |  |  | (Level 1) |  | (Level 2) |  | (Level 3) |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate debt securities | $ | 505.9 |  |  | $ | — |  |  | $ | 505.9 |  |  | $ | — |  |  | $ | 577.0 |  |  | $ | — |  |  | $ | 577.0 |  |  | $ | — |  |
| U.S. government securities | 166.4 |  |  | 166.4 |  |  | — |  |  | — |  |  | 195.2 |  |  | 195.2 |  |  | — |  |  | — |  |
| Commercial paper | 125.3 |  |  | — |  |  | 125.3 |  |  | — |  |  | 165.8 |  |  | — |  |  | 165.8 |  |  | — |  |
| Certificates of deposit and term deposits | 97.8 |  |  | — |  |  | 97.8 |  |  | — |  |  | 66.4 |  |  | — |  |  | 66.4 |  |  | — |  |
| Money market funds | 164.0 |  |  | 164.0 |  |  | — |  |  | — |  |  | 15.0 |  |  | 15.0 |  |  | — |  |  | — |  |
| Total | $ | 1,059.4 |  |  | $ | 330.4 |  |  | $ | 729.0 |  |  | $ | — |  |  | $ | 1,019.4 |  |  | $ | 210.2 |  |  | $ | 809.2 |  |  | $ | — |  |
| Reported as: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents | $ | 167.1 |  |  |  |  |  |  |  |  | $ | 32.0 |  |  |  |  |  |  |  |
| Short-term investments | 774.4 |  |  |  |  |  |  |  |  | 843.1 |  |  |  |  |  |  |  |
| Long-term investments | 117.9 |  |  |  |  |  |  |  |  | 144.3 |  |  |  |  |  |  |  |
| Total | $ | 1,059.4 |  |  |  |  |  |  |  |  | $ | 1,019.4 |  |  |  |  |  |  |  |

[0001262039-20-000067:notes:60]
There were no transfers between Level 1 and Level 2 of the fair value hierarchy during the nine months ended September 30, 2020 and year ended December 31, 2019.


## us-gaap:InventoryDisclosureTextBlock

[0001262039-20-000067:notes:61]
[same as prior period, unchanged from 0001262039-20-000053:notes:52]

[0001262039-20-000067:notes:62]
|  | September 30,2020 |  | December 31,2019 |
| Raw materials | $ | 15.6 |  |  | $ | 9.7 |  |
| Finished goods | 118.9 |  |  | 108.2 |  |
| Inventory | $ | 134.5 |  |  | $ | 117.9 |  |


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001262039-20-000067:notes:63]
[same as prior period, unchanged from 0001262039-20-000053:notes:54]

[0001262039-20-000067:notes:64]
|  | September 30,2020 |  | December 31,2019 |
| Land | $ | 93.3 |  |  | $ | 93.3 |  |
| Building and building improvements | 148.1 |  |  | 147.4 |  |
| Computer equipment and software | 131.5 |  |  | 116.7 |  |
| Leasehold improvements | 30.3 |  |  | 25.5 |  |
| Evaluation units | 18.8 |  |  | 19.9 |  |
| Furniture and fixtures | 20.0 |  |  | 17.3 |  |
| Construction-in-progress | 140.8 |  |  | 61.2 |  |
| Total property and equipment | 582.8 |  |  | 481.3 |  |
| Less: accumulated depreciation | (163.4) |  |  | (137.0) |  |
| Property and equipment—net | $ | 419.4 |  |  | $ | 344.3 |  |

[0001262039-20-000067:notes:65]
Construction-in-progress consists primarily of costs incurred in connection with the construction of a second building at our headquarters campus.

[0001262039-20-000067:notes:66]
Depreciation expense was $13.9 million and $12.8 million during the three months ended September 30, 2020 and September 30, 2019, respectively. Depreciation expense was $41.6 million and $37.8 million during the nine months ended September 30, 2020 and September 30, 2019, respectively.


## us-gaap:InvestmentTextBlock

[0001262039-20-000067:notes:67]
INVESTMENTS IN PRIVATELY HELD COMPANIESOur investments in the equity securities of privately held companies without readily determinable fair values totaled $1.0 million and $5.3 million as of September 30, 2020 and December 31, 2019, respectively. These investments are accounted for at cost, adjusted for changes in observable prices minus impairment. We own less than 20% of the voting securities in each of these investments and do not have the ability to exercise significant influence over operating and financial policies of the respective entities. These investments are recorded as Other assets in our condensed consolidated balance sheets and would be measured at fair value if indicators of an increase in value or impairment existed. In the first quarter of 2020 and in the third quarter of 2019, we recognized non-cash impairment charges of $4.3 million and $3.8 million in Other expense—net in our condensed consolidated statements of income, respectively. Cumulative impairment adjustments to all equity securities without readily determinable fair values totaled $8.1 million since their respective acquisitions through September 30, 2020. As of September 30, 2020, no other events have occurred that would affect the carrying value of these investments.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001262039-20-000067:notes:68]
BUSINESS COMBINATION
OPAQ Networks, Inc.

[0001262039-20-000067:notes:69]
On July 20, 2020, we acquired all outstanding shares of OPAQ Networks, Inc. (“OPAQ”), a privately held Secure Access Service Edge (“SASE”) cloud provider.

[0001262039-20-000067:notes:70]
Under the acquisition method of accounting in accordance with ASC 805, the total preliminary purchase price was allocated to OPAQ’s identifiable tangible and intangible assets acquired and liabilities assumed based on their estimated fair values using management’s best estimates and assumptions to assign fair value as of the acquisition date. The preliminary purchase price for OPAQ was $8.0 million in cash, of which $1.0 million was allocated to goodwill, $4.7 million was allocated to identifiable intangible assets, the majority of which was developed technology, and $2.3 million was allocated to other net assets acquired, which predominantly included cash, deferred tax assets, operating lease right-of-use assets and lease liabilities, accounts payable, accrued liabilities and assumed debt. The preliminary purchase price included a $1.3 million indemnity fund held in escrow for 12 months after the transaction closing date. Goodwill recorded in connection with this acquisition represents the value we expect to be created through expansion into markets within our existing business, and potential cost savings and synergies, and goodwill is non-deductible for tax purposes.

[0001262039-20-000067:notes:71]
Our estimates and assumptions are subject to change within the measurement period, which is up to 12 months after the acquisition date. The allocation of the purchase price for this acquisition has been prepared on a preliminary basis and changes to the allocation of certain assets and liabilities may occur as additional information becomes available. The primary areas of the purchase price that are not yet finalized are related to income taxes and the valuation of acquired assets and assumed liabilities.

[0001262039-20-000067:notes:72]
The operating results of the acquired company are included in our condensed consolidated statement of income from the date of acquisition. Acquisition-related costs for this acquisition were not material. Pro forma information has not been presented as the impact of this acquisition was not material to our condensed consolidated financial statements.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001262039-20-000067:notes:73]
[same as prior period, unchanged from 0001262039-20-000053:notes:58]

[0001262039-20-000067:notes:74]
The following table presents the changes in the carrying amount of goodwill (in millions):

[0001262039-20-000067:notes:75]
|  | Amount |
| Balance—December 2019 | $ | 67.2 |  |
| Addition due to business combination | 1.0 |  |
| Balance—September 2020 | $ | 68.2 |  |

[0001262039-20-000067:notes:76]
There were no impairments to goodwill during the nine months ended September 30, 2020 or during prior periods.

[0001262039-20-000067:notes:77]
[same as prior period, unchanged from 0001262039-20-000053:notes:60]

[0001262039-20-000067:notes:78]
The following tables present other intangible assets—net as of September 30, 2020 and December 31, 2019 (in millions, except years):

[0001262039-20-000067:notes:79]
|  | September 30, 2020 |
|  | Weighted-Average Useful Life (in Years) |  | Gross |  | Accumulated Amortization |  | Net |
| Other intangible assets—net: |  |  |  |  |  |  |  |
| Finite-lived intangible assets: |  |  |  |  |  |  |  |
| Developed technologies | 4.0 |  | $ | 53.3 |  |  | $ | 30.2 |  |  | $ | 23.1 |  |
| Customer relationships | 4.1 |  | 21.8 |  |  | 19.6 |  |  | 2.2 |  |
| Total other intangible assets—net |  |  | $ | 75.1 |  |  | $ | 49.8 |  |  | $ | 25.3 |  |

[0001262039-20-000067:notes:80]
|  | December 31, 2019 |
|  | Weighted-Average Useful Life (in Years) |  | Gross |  | Accumulated Amortization |  | Net |
| Other intangible assets—net: |  |  |  |  |  |  |  |
| Finite-lived intangible assets: |  |  |  |  |  |  |  |
| Developed technologies | 4.0 |  | $ | 50.2 |  |  | $ | 24.6 |  |  | $ | 25.6 |  |
| Customer relationships | 4.1 |  | 21.6 |  |  | 16.1 |  |  | 5.5 |  |
| Total other intangible assets—net |  |  | $ | 71.8 |  |  | $ | 40.7 |  |  | $ | 31.1 |  |

[0001262039-20-000067:notes:81]
Amortization expense was $2.8 million and $2.2 million during the three months ended September 30, 2020 and September 30, 2019, respectively. Amortization expense was $10.5 million and $8.1 million during the nine months ended September 30, 2020 and September 30, 2019, respectively.

[0001262039-20-000067:notes:82]
[same as prior period, unchanged from 0001262039-20-000053:notes:65]

[0001262039-20-000067:notes:83]
|  | Amount |
| Years: |  |
| 2020 (the remainder of 2020) | $ | 2.7 |  |
| 2021 | 9.6 |  |
| 2022 | 7.5 |  |
| 2023 | 4.8 |  |
| 2024 | 0.7 |  |
| Total | $ | 25.3 |  |


## us-gaap:EarningsPerShareTextBlock

[0001262039-20-000067:notes:84]
NET INCOME PER SHARE
Basic net income per share is computed by dividing net income by the weighted-average number of shares of common stock outstanding during the period. Diluted net income per share is computed by dividing net income by the weighted-average number of shares of common stock outstanding during the period, plus the dilutive effects of restricted stock units (“RSUs”) and stock options. Dilutive shares of common stock are determined by applying the treasury stock method.

[0001262039-20-000067:notes:85]
A reconciliation of the numerator and denominator used in the calculation of basic and diluted net income per share is as follows (in millions, except per share amounts):

[0001262039-20-000067:notes:86]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30,2020 |  | September 30,2019 |  | September 30,2020 |  | September 30,2019 |
| Numerator: |  |  |  |  |  |  |  |
| Net income | $ | 123.4 |  |  | $ | 80.2 |  |  | $ | 341.8 |  |  | $ | 213.5 |  |
| Denominator: |  |  |  |  |  |  |  |
| Basic shares: |  |  |  |  |  |  |  |
| Weighted-average common stock outstanding-basic | 162.1 |  |  | 171.3 |  |  | 164.8 |  |  | 170.9 |  |
| Diluted shares: |  |  |  |  |  |  |  |
| Weighted-average common stock outstanding-basic | 162.1 |  |  | 171.3 |  |  | 164.8 |  |  | 170.9 |  |
| Effect of potentially dilutive securities: |  |  |  |  |  |  |  |
| RSUs | 2.3 |  |  | 2.4 |  |  | 2.4 |  |  | 2.9 |  |
| Stock options | 1.2 |  |  | 1.1 |  |  | 1.2 |  |  | 1.1 |  |
| Weighted-average shares used to compute diluted net income per share | 165.6 |  |  | 174.8 |  |  | 168.4 |  |  | 174.9 |  |
| Net income per share: |  |  |  |  |  |  |  |
| Basic | $ | 0.76 |  |  | $ | 0.47 |  |  | $ | 2.07 |  |  | $ | 1.25 |  |
| Diluted | $ | 0.75 |  |  | $ | 0.46 |  |  | $ | 2.03 |  |  | $ | 1.22 |  |

[0001262039-20-000067:notes:87]
[same as prior period, unchanged from 0001262039-20-000053:notes:69]

[0001262039-20-000067:notes:88]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30,2020 |  | September 30,2019 |  | September 30,2020 |  | September 30,2019 |
| RSUs | 0.3 |  |  | 0.2 |  |  | 0.3 |  |  | 0.3 |  |
| Stock options | 0.6 |  |  | 0.7 |  |  | 0.5 |  |  | 0.6 |  |
| Total | 0.9 |  |  | 0.9 |  |  | 0.8 |  |  | 0.9 |  |


## us-gaap:LesseeOperatingLeasesTextBlock

[0001262039-20-000067:notes:89]
LEASES 
We have operating leases for offices, research and development facilities and data centers. Our leases have remaining terms that range from less than one year to approximately seven years, some of which include one or more options to renew, with renewal terms of up to six years. Unless and until we are reasonably certain we will exercise these renewal options, we do not include renewal options in our lease terms for calculating our lease liability, as the renewal options allow us to maintain operational flexibility.

[0001262039-20-000067:notes:90]
During the year ended December 31, 2019, we entered into a finance lease with $3.6 million lease liabilities arising from obtaining right-of-use assets with a lease term of approximately two years. Our remaining finance leases were not material to our condensed consolidated financial statements. The related assumptions and further disclosures for finance leases are not material.

[0001262039-20-000067:notes:91]
The components of lease expense were as follows (in millions):

[0001262039-20-000067:notes:92]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30,2020 |  | September 30,2019 |  | September 30,2020 |  | September 30,2019 |
| Operating lease expense | $ | 4.8 |  |  | $ | 3.8 |  |  | $ | 13.5 |  |  | $ | 11.1 |  |
| Variable lease expense (1) | 0.7 |  |  | 0.7 |  |  | 1.7 |  |  | 1.9 |  |
| Short-term lease expense | 1.0 |  |  | 0.8 |  |  | 2.9 |  |  | 2.2 |  |
| Total lease expense | $ | 6.5 |  |  | $ | 5.3 |  |  | $ | 18.1 |  |  | $ | 15.2 |  |

[0001262039-20-000067:notes:93]
(1) Variable lease expense for the nine months ended September 30, 2020 and September 30, 2019 predominantly included common area maintenance charges and parking expense.

[0001262039-20-000067:notes:94]
Supplemental balance sheet information related to our operating leases was as follows (in millions, except lease term and discount rate):

[0001262039-20-000067:notes:95]
|  | Classification | September 30,2020 |  | December 31,2019 |
| Operating lease ROU assets - non-current | Other assets | $ | 45.6 |  |  | $ | 44.3 |  |
| Operating lease liabilities - current | Accrued liabilities | $ | 17.2 |  |  | $ | 15.5 |  |
| Operating lease liabilities - non-current | Other liabilities | 31.0 |  |  | 30.6 |  |
| Total operating lease liabilities |  | $ | 48.2 |  |  | $ | 46.1 |  |
| Weighted average remaining lease term in years - operating leases |  | 3.6 |  | 3.7 |
| Weighted average discount rate - operating leases |  | 3.2 | % |  | 2.8 | % |

[0001262039-20-000067:notes:96]
Supplemental cash flow information related to leases was as follows (in millions):

[0001262039-20-000067:notes:97]
|  | Nine Months Ended |  | Nine Months Ended |
|  | September 30,2020 |  | September 30,2019 |
| Cash paid for amounts included in the measurement of lease liabilities |  |  |  |
| Operating cash flows used for operating leases | $ | 13.8 |  |  | $ | 11.9 |  |

[0001262039-20-000067:notes:98]
Maturities of operating lease liabilities as of September 30, 2020 were as follows (in millions):

[0001262039-20-000067:notes:99]
| Year ending December 31, | Amount |
| 2020 (the remainder of 2020) | $ | 4.2 |  |
| 2021 | 17.8 |  |
| 2022 | 12.6 |  |
| 2023 | 7.2 |  |
| 2024 | 5.3 |  |
| Thereafter | 4.0 |  |
| Total lease payments | 51.1 |  |
| Less imputed interest | (2.9) |  |
| Total | $ | 48.2 |  |

[0001262039-20-000067:notes:100]
As of September 30, 2020, we had additional minimum lease payments of $3.8 million relating to operating leases that had been signed but had not yet commenced and therefore were excluded from the table above. These leases will commence during 2020 and will have lease terms of approximately three to five years.


## ftnt:MutualCovenantNottoSueAgreementDisclosureTextBlock

[0001262039-20-000067:notes:101]
MUTUAL COVENANT-NOT-TO-SUE AND RELEASE AGREEMENT
In January 2020, we entered into an agreement with a competitor in the network security industry whereby, in February 2020, the competitor party paid us a lump sum of $50.0 million for a seven-year mutual covenant-not-to-sue for patent claims. Pursuant to this agreement, at the end of this first seven-year period, either party may extend the agreement for an additional seven-year mutual covenant-not-to-sue in return for this competitor paying us an additional $50.0 million. This agreement arose after expiration of previous agreements between the parties whereby the competitor had paid us sums for a limited term license to certain of our intellectual property (“IP”) and a limited term mutual covenant-not-to-sue.

[0001262039-20-000067:notes:102]
We concluded that the agreement was a 14-year contract with a total transaction price of $100.0 million, and that it contained two material distinct performance obligations: (1) the right to use our existing patents, and (2) the right to use any patents that we develop over the term of the contract. We allocated $36.0 million to the functional patents, which was recognized upon commencement of the contract; the remaining $64.0 million, representing the right to utilize future patents, will be recognized over the contract term. We further concluded that our existing patents represent functional IP that should be recognized upon granting our competitor access. We also concluded that the right to receive additional functional IP that we will develop in the future represents a stand ready obligation. Therefore, the transaction price allocated to this obligation is recognized ratably over the 14-year contract term. We estimated the stand-alone selling price of each distinct performance obligation and allocated the $100.0 million transaction price.

[0001262039-20-000067:notes:103]
During the three and nine months ended September 30, 2020, we recorded $1.1 million and $39.0 million in Gain on IP matter in our condensed consolidated statements of income, respectively. We recorded $11.0 million in Accrued liabilities and Other liabilities in our condensed consolidated balance sheet as of September 30, 2020.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001262039-20-000067:notes:104]
COMMITMENTS AND CONTINGENCIES
The following table summarizes our inventory purchase commitments as of September 30, 2020 (in millions):

[0001262039-20-000067:notes:105]
|  | Total |  | 2020 |  | 2021 |  | 2022 |  | 2023 |  | 2024 |  | Thereafter |
| Inventory purchase commitments | $ | 284.7 |  |  | $ | 207.6 |  |  | $ | 77.1 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |

[0001262039-20-000067:notes:106]
Inventory Purchase Commitments—Our independent contract manufacturers procure components and build our products based on our forecasts. These forecasts are based on estimates of future demand for our products, which are in turn based on historical trends and an analysis from our sales and marketing organizations, adjusted for overall market conditions. In order to reduce manufacturing lead times and plan for adequate component supply, we may issue purchase orders to some of our independent contract manufacturers, which may not be cancelable. As of September 30, 2020, we had $284.7 million of open purchase orders with our independent contract manufacturers that may not be cancelable.

[0001262039-20-000067:notes:107]
Other Contractual Commitments and Open Purchase Orders—In addition to commitments with contract manufacturers, we have open purchase orders and contractual obligations in the ordinary course of business for which we have not received goods or services. As of September 30, 2020, we had $23.1 million in other contractual commitments having a remaining term in excess of one year that may not be cancelable.

[0001262039-20-000067:notes:108]
Litigation—We are involved in disputes, litigation, and other legal actions. For lawsuits where we are the defendant, we are in the process of defending these litigation matters, and while there can be no assurances and the outcome of certain of these matters is currently not determinable and not predictable, we currently are unaware of any existing claims or proceedings that we believe are likely to have a material adverse effect on our financial position. There are many uncertainties associated with any litigation and these actions or other third-party claims against us may cause us to incur costly litigation fees, costs and substantial settlement charges, and possibly subject us to damages and other penalties. In addition, the resolution of any IP litigation may require us to make royalty payments, which could adversely affect our gross margins in future periods. If any of those events were to occur, our business, financial condition, results of operations, and cash flows could be adversely affected. Litigation is unpredictable and the actual liability in any such matters may be materially different from our current estimates, which could result in the need to adjust any accrued liability and record additional expenses. We accrue for contingencies when we believe that a loss is probable and that we can reasonably estimate the amount of any such loss.

[0001262039-20-000067:notes:109]
Indemnification and Other Matters—Under the indemnification provisions of our standard sales contracts, we agree to defend our customers against third-party claims asserting various allegations such as product defects and infringement of certain IP rights, which may include patents, copyrights, trademarks or trade secrets, and to pay judgments entered on such claims. In some contracts, our exposure under these indemnification provisions is limited by the terms of the contracts to certain defined limits, such as the total amount paid by our customer under the agreement. However, certain agreements include covenants, penalties and indemnification provisions including and beyond indemnification for third-party claims of IP infringement that could potentially expose us to losses in excess of the amount received under the agreement, and in some instances to potential liability that is not contractually limited. Although from time to time there are indemnification claims asserted against us and currently there are pending indemnification claims, to date there have been no material awards under such indemnification provisions.

[0001262039-20-000067:notes:110]
Similar to other security companies and companies in other industries, we have in the past experienced, and we may in the future experience, cybersecurity threats, malicious activity directed against our information technology infrastructure or unauthorized attempts to gain access to our and our customers’ sensitive information and systems. We currently are unaware of any existing claims or proceedings related to these types of matters, including any that we believe are likely to have a material adverse effect on our financial position.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001262039-20-000067:notes:111]
[same as prior period, unchanged from 0001262039-20-000053:notes:93]

[0001262039-20-000067:notes:112]
We maintain the Amended and Restated Fortinet, Inc. 2009 Equity Incentive Plan (the “Amended Plan”) pursuant to which we have granted RSUs and stock options. As of September 30, 2020, there was a total of 12.1 million shares of common

[0001262039-20-000067:notes:113]
stock available for grant under the Amended Plan. We also previously had an Employee Stock Purchase Plan (“ESPP”) for eligible employees, which was terminated in February 2019.

[0001262039-20-000067:notes:114]
[same as prior period, unchanged from 0001262039-20-000053:notes:95]

[0001262039-20-000067:notes:115]
[same as prior period, unchanged from 0001262039-20-000053:notes:96]

[0001262039-20-000067:notes:116]
|  | Restricted Stock Units Outstanding |
|  | Number of Shares |  | Weighted-Average Grant Date Fair Value per Share |
| Balance—December 31, 2019 | 6.1 |  |  | $ | 64.56 |  |
| Granted | 1.8 |  |  | 121.30 |  |
| Forfeited | (0.3) |  |  | 76.80 |  |
| Vested | (2.3) |  |  | 57.07 |  |
| Balance—September 30, 2020 | 5.3 |  |  | $ | 86.31 |  |

[0001262039-20-000067:notes:117]
Stock compensation expense is recognized on a straight-line basis over the vesting period of each RSU. As of September 30, 2020, total compensation expense related to unvested RSUs granted to employees and non-employees under the 2009 Plan, but not yet recognized, was $399.1 million, with a weighted-average remaining vesting period of 2.7 years.

[0001262039-20-000067:notes:118]
RSUs settle into shares of common stock upon vesting. Upon the vesting of the RSUs, we net-settle the RSUs and withhold a portion of the shares to satisfy employee withholding tax requirements. The payment of the withheld taxes to the tax authorities is reflected as a financing activity within the condensed consolidated statements of cash flows.

[0001262039-20-000067:notes:119]
[same as prior period, unchanged from 0001262039-20-000053:notes:100]

[0001262039-20-000067:notes:120]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30,2020 |  | September 30,2019 |  | September 30,2020 |  | September 30,2019 |
| Shares withheld for taxes | 0.2 |  |  | 0.2 |  |  | 0.7 |  |  | 0.9 |  |
| Amount withheld for taxes | $ | 27.6 |  |  | $ | 19.6 |  |  | $ | 86.5 |  |  | $ | 76.1 |  |

[0001262039-20-000067:notes:121]
[same as prior period, unchanged from 0001262039-20-000053:notes:102]

[0001262039-20-000067:notes:122]
[same as prior period, unchanged from 0001262039-20-000053:notes:103]

[0001262039-20-000067:notes:123]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30,2020 |  | September 30,2019 |  | September 30,2020 |  | September 30,2019 |
| Expected term in years | 4.4 |  | 4.4 |  | 4.4 |  | 4.4 |
| Volatility | 39.9 | % |  | 35.3 | % |  | 34.6 | % |  | 34.2 | % |
| Risk-free interest rate | 0.2 | % |  | 1.4 | % |  | 1.1 | % |  | 2.4 | % |
| Dividend rate | — | % |  | — | % |  | — | % |  | — | % |

[0001262039-20-000067:notes:124]
[same as prior period, unchanged from 0001262039-20-000053:notes:105]

[0001262039-20-000067:notes:125]
|  | Options Outstanding |
|  | Numberof Shares |  | Weighted-AverageExercisePrice |  | Weighted-AverageRemainingContractualLife (Years) |  | AggregateIntrinsicValue |
| Balance—December 31, 2019 | 2.7 |  |  | $ | 50.37 |  |  |  |  |  |
| Granted | 0.6 |  |  | 118.96 |  |  |  |  |  |
| Forfeited | (0.1) |  |  | 91.73 |  |  |  |  |  |
| Exercised | (0.4) |  |  | 40.99 |  |  |  |  |  |
| Balance—September 30, 2020 | 2.8 |  |  | $ | 66.72 |  |  |  |  |  |
| Options vested and expected to vest—September 30, 2020 | 2.8 |  |  | $ | 66.72 |  |  | 4.4 |  | $ | 146.4 |  |
| Options exercisable—September 30, 2020 | 1.5 |  |  | $ | 42.81 |  |  | 3.3 |  | $ | 109.6 |  |

[0001262039-20-000067:notes:126]
The aggregate intrinsic value represents the difference between the exercise price of stock options and the quoted market price of our common stock on September 30, 2020 for all in-the-money stock options. Stock compensation expense is recognized on a straight-line basis over the vesting period of each stock option. As of September 30, 2020, total compensation expense related to unvested stock options granted to employees but not yet recognized was $35.1 million, with a weighted-average remaining vesting period of 2.8 years.

[0001262039-20-000067:notes:127]
[same as prior period, unchanged from 0001262039-20-000053:notes:108]

[0001262039-20-000067:notes:128]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30,2020 |  | September 30,2019 |  | September 30,2020 |  | September 30,2019 |
| Weighted-average fair value per share granted | $ | 43.80 |  |  | $ | 24.97 |  |  | $ | 35.76 |  |  | $ | 26.96 |  |
| Intrinsic value of options exercised | 5.5 |  |  | 3.2 |  |  | 35.8 |  |  | 40.1 |  |
| Fair value of options vested | 2.5 |  |  | 2.0 |  |  | 10.9 |  |  | 8.2 |  |

[0001262039-20-000067:notes:129]
[same as prior period, unchanged from 0001262039-20-000053:notes:110]

[0001262039-20-000067:notes:130]
[same as prior period, unchanged from 0001262039-20-000053:notes:111]

[0001262039-20-000067:notes:131]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30,2020 |  | September 30,2019 |  | September 30,2020 |  | September 30,2019 |
| Cost of product revenue | $ | 0.4 |  |  | $ | 0.4 |  |  | $ | 1.2 |  |  | $ | 1.2 |  |
| Cost of service revenue | 3.3 |  |  | 2.7 |  |  | 9.5 |  |  | 8.4 |  |
| Research and development | 12.7 |  |  | 9.3 |  |  | 35.6 |  |  | 28.7 |  |
| Sales and marketing | 27.7 |  |  | 24.9 |  |  | 81.3 |  |  | 76.6 |  |
| General and administrative | 5.9 |  |  | 5.1 |  |  | 17.3 |  |  | 15.5 |  |
| Total stock-based compensation expense | $ | 50.0 |  |  | $ | 42.4 |  |  | $ | 144.9 |  |  | $ | 130.4 |  |

[0001262039-20-000067:notes:132]
[same as prior period, unchanged from 0001262039-20-000053:notes:113]

[0001262039-20-000067:notes:133]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30,2020 |  | September 30,2019 |  | September 30,2020 |  | September 30,2019 |
| RSUs | $ | 46.4 |  |  | $ | 39.5 |  |  | $ | 134.5 |  |  | $ | 120.6 |  |
| Stock options | 3.6 |  |  | 2.9 |  |  | 10.4 |  |  | 8.5 |  |
| ESPP | — |  |  | — |  |  | — |  |  | 1.3 |  |
| Total stock-based compensation expense | $ | 50.0 |  |  | $ | 42.4 |  |  | $ | 144.9 |  |  | $ | 130.4 |  |

[0001262039-20-000067:notes:134]
[same as prior period, unchanged from 0001262039-20-000053:notes:115]

[0001262039-20-000067:notes:135]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30,2020 |  | September 30,2019 |  | September 30,2020 |  | September 30,2019 |
| Income tax benefit associated with stock-based compensation | $ | 11.0 |  |  | $ | 9.8 |  |  | $ | 31.9 |  |  | $ | 30.1 |  |

[0001262039-20-000067:notes:136]
[same as prior period, unchanged from 0001262039-20-000053:notes:117]

[0001262039-20-000067:notes:137]
In July 2020, under the Share Repurchase Program originally approved by our board of directors in January 2016 (the “Repurchase Program”), our board of directors approved a $500.0 million increase and extended the term to February 28, 2022, bringing the aggregate amount authorized to be repurchased to $3.0 billion. Share repurchases may be made by us from time to time in privately negotiated transactions or in open market transactions. The Repurchase Program does not require us to purchase a minimum number of shares, and may be suspended, modified or discontinued at any time without prior notice.

[0001262039-20-000067:notes:138]
During the nine months ended September 30, 2020, we repurchased 11.4 million shares of common stock under the Repurchase Program in open market transactions at an average price $91.55 per share, for an aggregate purchase price $1.05 billion. As of September 30, 2020, $1.05 billion remained available for future share repurchases under the Repurchase Program.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001262039-20-000067:notes:139]
INCOME TAXES 
Our effective tax rate was 4% for the three months ended September 30, 2020, compared to an effective tax rate of 24% for the same period last year. Our effective tax rate was 8% for the nine months ended September 30, 2020, compared to an effective tax rate of 16% for the same period last year. The effective tax rates for the periods presented are primarily comprised of U.S. federal and state taxes, withholding taxes, foreign taxes and excess tax benefits from stock-based compensation expense. The tax rates for the three months ended September 30, 2020 and September 30, 2019 were impacted by U.S. federal and state taxes, withholding taxes and foreign taxes that were $17.5 million and $32.7 million, respectively. The U.S. federal and state taxes included a tax benefit of $16.0 million from the foreign-derived intangible income deduction for the three months ended September 30, 2020. The tax rates for the three months ended September 30, 2020 and September 30, 2019 were impacted by excess tax benefits from stock-based compensation expense of $12.5 million and $6.9 million, respectively.

[0001262039-20-000067:notes:140]
The tax rates for the nine months ended September 30, 2020 and September 30, 2019 were impacted by U.S. federal and state taxes, withholding taxes and foreign taxes of $74.8 million and $75.4 million, respectively. The U.S. federal and state taxes included a tax benefit of $25.6 million from the foreign-derived intangible income deduction for the nine months ended September 30, 2020. The tax rates for the nine months ended September 30, 2020 and September 30, 2019 were impacted by excess tax benefits from stock-based compensation expense of $37.6 million and $34.6 million, respectively, and release of reserves of $9.0 million and $10.0 million, respectively, on uncertain tax positions and the interest due to the expiration of the statute of limitations. The provision for income taxes for the nine months ended September 30, 2019 was further impacted by an increase in tax expense of $10.3 million for an unrecognized tax benefit related to the opinion of the U.S. Court of Appeals for the Ninth Circuit (the “Ninth Circuit”) in Altera Corporation and Subsidiaries vs. Commissioner of Internal Revenue (“Altera”) described below, regarding stock-based compensation expense in cost sharing arrangements.

[0001262039-20-000067:notes:141]
As of September 30, 2020 and December 31, 2019, unrecognized tax benefits were $67.1 million and $67.5 million, respectively. If recognized, $61.7 million of the unrecognized tax benefits would favorably affect our effective tax rate. It is our policy to include accrued interest and penalties related to unrecognized tax benefits in income tax expense. As of September 30, 2020 and December 31, 2019, accrued interest and penalties were $13.1 million and $14.1 million, respectively. It is reasonably possible that our gross unrecognized tax benefits will decrease by up to $4.0 million in the next 12 months, due to the lapse of the statute of limitations. This decrease, if recognized, would positively impact our effective tax rate, and would be recognized as additional tax benefits.

[0001262039-20-000067:notes:142]
[same as prior period, unchanged from 0001262039-20-000053:notes:124]

[0001262039-20-000067:notes:143]
[same as prior period, unchanged from 0001262039-20-000053:notes:125]

[0001262039-20-000067:notes:144]
[same as prior period, unchanged from 0001262039-20-000053:notes:126]

[0001262039-20-000067:notes:145]
On July 9, 2020, the United States Department of the Treasury (the “U.S. Treasury”) and the Internal Revenue Service (the “IRS”) released final Section 250 regulations, providing guidance on foreign-derived intangible income deduction and global intangible low-taxed income. Generally, the final regulations are applicable for taxable years beginning on or after January 1, 2021. However, taxpayers may apply the final regulations for taxable years beginning on or after January 1, 2018. We have elected to apply the final regulations to the year ending December 31, 2020 and included the tax impact from the final regulations on our foreign-derived intangible income deduction calculation.

[0001262039-20-000067:notes:146]
On September 29, 2020, the U.S. Treasury and the IRS released final regulations related to foreign tax credits that were the subject of proposed regulations issued in December 2019 and proposed certain provisions in proposed regulations issued in December 2019. The final and proposed regulations provide administrative guidance for the foreign tax credit regime, which was updated in the 2017 Tax Cuts and Jobs Act. Generally, the provisions that were included in the 2019 proposed regulations apply to taxable years ending on or after December 16, 2019, except as otherwise specified. We are in the process of analyzing the tax impact from the final regulations on our foreign tax credit calculation.


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0001262039-20-000067:notes:147]
DEFINED CONTRIBUTION PLANSOur tax-deferred savings plan under our 401(k) Plan permits participating U.S. employees to contribute a portion of their pre-tax or after-tax earnings. In Canada, we have a Group Registered Retirement Savings Plan Program (the “RRSP”), which permits participants to make tax-deductible contributions. Our board of directors approved 50% matching contributions on employee contributions up to 4% of each employee’s eligible earnings. Our matching contributions to our 401(k) Plan and the RRSP for the three months ended September 30, 2020 and September 30, 2019 were $2.1 million and $1.8 million, respectively. Our matching contributions to our 401(k) Plan and the RRSP for the nine months ended September 30, 2020 and September 30, 2019 were $6.5 million and $5.2 million, respectively.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001262039-20-000067:notes:148]
SEGMENT INFORMATION
Operating segments are defined as components of an enterprise about which separate financial information is available that is evaluated regularly by the chief operating decision maker in deciding how to allocate resources and in assessing performance. Our chief operating decision maker is our chief executive officer. Our chief executive officer reviews financial information presented on a consolidated basis, accompanied by information about revenue by geographic region for purposes of allocating resources and evaluating financial performance. We have one business activity, and there are no segment managers who are held accountable for operations, operating results and plans for levels or components below the consolidated unit level. Accordingly, we have determined that we have one operating segment, and therefore, one reportable segment.

[0001262039-20-000067:notes:149]
[same as prior period, unchanged from 0001262039-20-000053:notes:130]

[0001262039-20-000067:notes:150]
|  | Three Months Ended |  | Nine Months Ended |
| Revenue | September 30,2020 |  | September 30,2019 |  | September 30,2020 |  | September 30,2019 |
| Americas: |  |  |  |  |  |  |  |
| United States | $ | 206.0 |  |  | $ | 182.3 |  |  | $ | 589.1 |  |  | $ | 506.9 |  |
| Other Americas | 66.4 |  |  | 58.7 |  |  | 186.9 |  |  | 161.1 |  |
| Total Americas | 272.4 |  |  | 241.0 |  |  | 776.0 |  |  | 668.0 |  |
| Europe, Middle East and Africa (“EMEA”) | 243.3 |  |  | 200.9 |  |  | 693.5 |  |  | 571.1 |  |
| Asia Pacific (“APAC”) | 135.4 |  |  | 106.2 |  |  | 376.9 |  |  | 305.8 |  |
| Total revenue | $ | 651.1 |  |  | $ | 548.1 |  |  | $ | 1,846.4 |  |  | $ | 1,544.9 |  |

[0001262039-20-000067:notes:151]
| Property and Equipment—net | September 30,2020 |  | December 31,2019 |
| Americas: |  |  |  |
| United States | $ | 270.9 |  |  | $ | 197.4 |  |
| Canada | 121.3 |  |  | 120.5 |  |
| Latin America | 6.9 |  |  | 5.5 |  |
| Total Americas | 399.1 |  |  | 323.4 |  |
| EMEA | 15.3 |  |  | 15.2 |  |
| APAC | 5.0 |  |  | 5.7 |  |
| Total property and equipment—net | $ | 419.4 |  |  | $ | 344.3 |  |

[0001262039-20-000067:notes:152]
[same as prior period, unchanged from 0001262039-20-000053:notes:133]

[0001262039-20-000067:notes:153]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30,2020 |  | September 30,2019 |  | September 30,2020 |  | September 30,2019 |
| Exclusive Networks Group (“Exclusive”) | 29 | % |  | 30 | % |  | 30 | % |  | 31 | % |
| Ingram Micro, Inc. (“Ingram Micro”) | 10 | % |  | 11 | % |  | 10 | % |  | 11 | % |

[0001262039-20-000067:notes:154]
[same as prior period, unchanged from 0001262039-20-000053:notes:135]

[0001262039-20-000067:notes:155]
|  | September 30,2020 |  | December 31,2019 |
| Exclusive | 31 | % |  | 36 | % |
| Ingram Micro | 11 | % |  | 10 | % |
| Tech Data Corporation | 10 | % |  | * |
| * Represents less than 10% |
