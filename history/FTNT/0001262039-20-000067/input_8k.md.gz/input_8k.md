# FTNT 8-K — 0001262039-20-000063 filed 2020-10-29

## item codes, every 8-K on or before 2020-11-06

- 2020-10-29 0001262039-20-000063 — 2.02, 9.01
- 2020-10-20 0001262039-20-000060 — 5.02 — amendment, the index does not say of what
- 2020-08-26 0001262039-20-000056 — 5.02, 9.01
- 2020-08-06 0001262039-20-000051 — 2.02, 9.01
- 2020-07-21 0001262039-20-000044 — 5.03, 8.01, 9.01
- 2020-06-24 0001262039-20-000038 — 5.07
- 2020-05-06 0001262039-20-000029 — 2.02, 9.01
- 2020-04-23 0001262039-20-000025 — 5.03, 9.01
- 2020-04-23 0001262039-20-000024 — 5.02 — amendment of 0001262039-20-000025
- 2020-02-28 0001262039-20-000015 — 5.02, 9.01
- 2020-02-06 0001262039-20-000004 — 2.02, 9.01
- 2019-12-12 0001262039-19-000038 — 8.01
- 2019-10-31 0001262039-19-000032 — 2.02, 9.01
- 2019-10-28 0001262039-19-000027 — 8.01
- 2019-10-23 0001262039-19-000025 — 5.02, 9.01
- 2019-08-01 0001262039-19-000021 — 2.02, 9.01
- 2019-06-26 0001262039-19-000018 — 5.07
- 2019-05-02 0001262039-19-000010 — 2.02, 9.01
- 2019-02-06 0001262039-19-000002 — 2.02, 9.01
- 2018-11-01 0001262039-18-000037 — 2.02, 9.01
- 2018-10-23 0001262039-18-000035 — 8.01
- 2018-08-01 0001262039-18-000025 — 2.02, 9.01
- 2018-06-28 0001262039-18-000023 — 5.03, 5.07, 9.01
- 2018-06-04 0001262039-18-000021 — 8.01
- 2018-05-03 0001262039-18-000017 — 2.02, 5.02, 9.01
- 2018-02-05 0001262039-18-000004 — 2.02, 5.02, 9.01
- 2017-10-26 0001262039-17-000031 — 2.02, 9.01
- 2017-10-19 0001262039-17-000029 — 5.02 — amendment, the index does not say of what
- 2017-07-26 0001262039-17-000025 — 2.02, 9.01
- 2017-06-27 0001262039-17-000023 — 5.07
- 2017-05-31 0001262039-17-000021 — 5.02 — amendment of 0001262039-17-000019
- 2017-05-30 0001262039-17-000019 — 5.02, 9.01
- 2017-04-27 0001262039-17-000013 — 2.02, 9.01
- 2017-02-02 0001262039-17-000003 — 2.02, 9.01
- 2016-10-27 0001262039-16-000085 — 2.02, 9.01
- 2016-10-11 0001262039-16-000082 — 2.02, 9.01
- 2016-07-28 0001262039-16-000076 — 2.02, 9.01
- 2016-07-22 0001262039-16-000073 — 8.01, 9.01
- 2016-06-20 0001262039-16-000068 — 5.07
- 2016-06-07 0001193125-16-614788 — 8.01
- 2016-04-26 0001262039-16-000061 — 2.02, 9.01
- 2016-01-28 0001262039-16-000051 — 2.02, 9.01
- 2015-10-27 0001262039-15-000045 — 2.02
- 2015-10-22 0001262039-15-000042 — 5.02 — amendment, the index does not say of what
- 2015-10-22 0001262039-15-000041 — 5.02 — amendment, the index does not say of what
- 2015-10-22 0001262039-15-000039 — 2.02, 9.01
- 2015-09-28 0001262039-15-000034 — 5.02, 9.01
- 2015-09-22 0001262039-15-000031 — 9.01 — amendment of 0001193125-15-248065
- 2015-08-28 0001262039-15-000027 — 3.01, 5.02
- 2015-07-23 0001262039-15-000021 — 5.02
- 2015-07-22 0001262039-15-000019 — 2.02, 9.01
- 2015-07-08 0001193125-15-248065 — 2.01, 8.01, 9.01
- 2015-06-22 0001193125-15-229099 — 5.07
- 2015-06-19 0001193125-15-228428 — 5.02, 9.01
- 2015-04-20 0001262039-15-000014 — 2.02, 9.01
- 2015-01-28 0001262039-15-000005 — 2.02, 9.01
- 2014-10-22 0001262039-14-000036 — 2.02, 9.01
- 2014-07-23 0001262039-14-000030 — 2.02, 9.01
- 2014-06-24 0001262039-14-000027 — 5.07
- 2014-04-23 0001262039-14-000021 — 2.02, 9.01
- 2014-04-21 0001262039-14-000018 — 5.03, 9.01
- 2014-01-29 0001262039-14-000004 — 2.02, 9.01
- 2013-12-20 0001262039-13-000061 — 5.02, 9.01
- 2013-11-27 0001262039-13-000057 — 5.02, 7.01, 9.01
- 2013-11-12 0001445305-13-002993 — 5.02
- 2013-10-23 0001262039-13-000051 — 2.02, 9.01
- 2013-07-30 0001262039-13-000039 — 2.02, 9.01
- 2013-06-25 0001262039-13-000030 — 5.07
- 2013-04-30 0001262039-13-000023 — 2.02, 9.01
- 2013-04-19 0001262039-13-000020 — 5.02, 9.01
- 2013-04-19 0001262039-13-000018 — 5.02 — amendment of 0001262039-13-000020
- 2013-04-10 0001262039-13-000016 — 2.02, 9.01
- 2013-03-26 0001262039-13-000013 — 5.02
- 2013-01-30 0001262039-13-000005 — 2.02, 9.01
- 2013-01-24 0001262039-13-000002 — 5.02, 9.01
- 2012-10-16 0001262039-12-000048 — 2.02, 9.01
- 2012-10-01 0001262039-12-000045 — 5.02
- 2012-09-26 0001262039-12-000043 — 5.01
- 2012-07-25 0001262039-12-000038 — 2.02, 9.01
- 2012-07-19 0001262039-12-000034 — 5.02
- 2012-06-20 0001193125-12-275869 — 5.07
- 2012-04-27 0001262039-12-000029 — 5.02
- 2012-04-24 0001262039-12-000025 — 2.02, 9.01
- 2012-01-31 0001262039-12-000006 — 2.02, 9.01
- 2012-01-25 0001262039-12-000003 — 5.03
- 2011-10-24 0001262039-11-000036 — 2.02
- 2011-07-19 0001262039-11-000014 — 2.02, 9.01
- 2011-06-27 0001193125-11-174474 — 5.02, 5.07, 9.01
- 2011-04-27 0001193125-11-111938 — 2.02, 9.01
- 2011-01-25 0001193125-11-013914 — 2.02, 9.01
- 2010-10-21 0001193125-10-233676 — 2.02, 9.01
- 2010-09-02 0001193125-10-203099 — 8.01
- 2010-07-22 0001193125-10-163844 — 2.02, 9.01
- 2010-06-24 0001193125-10-146082 — 5.07
- 2010-04-28 0001193125-10-096698 — 2.02, 9.01
- 2010-02-09 0001193125-10-024614 — 8.01
- 2010-01-27 0001193125-10-014292 — 2.02, 9.01
- 2010-01-26 0001193125-10-013031 — 5.02, 9.01

## late-filing notifications on or before 2020-11-06

- none on or before 2020-11-06

## item 2.02 — earnings release, exhibit 99.1

[0001262039-20-000063:8k_2_02:1]
EX-99.1
2
ftntq3-2020ex991.htm
PRESS RELEASE

[0001262039-20-000063:8k_2_02:2]
Document

[0001262039-20-000063:8k_2_02:3]
Press Release

[0001262039-20-000063:8k_2_02:4]
Fortinet Reports Third Quarter 2020 Financial Results

[0001262039-20-000063:8k_2_02:5]
Third Quarter 2020 Highlights

[0001262039-20-000063:8k_2_02:6]
•Total revenue of $651.1 million, up 19% year over year

[0001262039-20-000063:8k_2_02:7]
•Product revenue of $223.8 million, up 14% year over year

[0001262039-20-000063:8k_2_02:8]
•Service revenue of $427.3 million, up 22% year over year

[0001262039-20-000063:8k_2_02:9]
•Billings of $749.8 million, up 20% year over year1

[0001262039-20-000063:8k_2_02:10]
•Deferred revenue of $2.39 billion, up 24% year over year

[0001262039-20-000063:8k_2_02:11]
•GAAP operating margin of 19.5%, up 110 basis points year over year

[0001262039-20-000063:8k_2_02:12]
•Non-GAAP operating margin of 27.4%, up 90 basis points year over year1

[0001262039-20-000063:8k_2_02:13]
•GAAP diluted net income per share of $0.75

[0001262039-20-000063:8k_2_02:14]
•Non-GAAP diluted net income per share of $0.881

[0001262039-20-000063:8k_2_02:15]
•Cash flow from operations of $220.8 million

[0001262039-20-000063:8k_2_02:16]
•Free cash flow of $185.7 million1

[0001262039-20-000063:8k_2_02:17]
SUNNYVALE, Calif. - October 29, 2020 - Fortinet® (Nasdaq: FTNT), a global leader in broad, integrated and automated cybersecurity solutions, today announced financial results for the third quarter ended September 30, 2020.

[0001262039-20-000063:8k_2_02:18]
“Strong performances by our Secure SD-WAN, cloud, and Security Fabric offerings resulted in solid third-quarter year-over-year total revenue growth. In the quarter, Secure SD-WAN revenue more than doubled from the same period a year ago. At the end of the third quarter, Gartner recognized our differentiated SD-WAN offering as a Leader in the 2020 WAN Edge Infrastructure Magic Quadrant,” said Ken Xie, Founder, Chairman, and Chief Executive Officer. “The pandemic has accelerated digital transformation and cloud migration efforts creating multiple edges that require protection. Fortinet’s security-driven networking approach protects these edges, whether they are at the branch, cloud, data center, home, network or WAN edge.”

[0001262039-20-000063:8k_2_02:19]
Financial Highlights for the Third Quarter of 20202

[0001262039-20-000063:8k_2_02:20]
•Revenue: Total revenue was $651.1 million for the third quarter of 2020, an increase of 18.8% compared to $548.1 million for the same quarter of 2019.

[0001262039-20-000063:8k_2_02:21]
•Product Revenue: Product revenue was $223.8 million for the third quarter of 2020, an increase of 13.5% compared to $197.1 million for the same quarter of 2019.

[0001262039-20-000063:8k_2_02:22]
•Service Revenue: Service revenue was $427.3 million for the third quarter of 2020, an increase of 21.7% compared to $351.0 million for the same quarter of 2019.

[0001262039-20-000063:8k_2_02:23]
•Billings1: Total billings were $749.8 million for the third quarter of 2020, an increase of 19.7% compared to $626.6 million for the same quarter of 2019.

[0001262039-20-000063:8k_2_02:24]
•Deferred Revenue: Total deferred revenue was $2.39 billion as of September 30, 2020, an increase of 24.4% compared to $1.92 billion as of September 30, 2019.

[0001262039-20-000063:8k_2_02:25]
•GAAP Operating Income and Margin: GAAP operating income was $126.9 million for the third quarter of 2020, representing a GAAP operating margin of 19.5%. GAAP operating income was $100.6 million for the same quarter of 2019, representing a GAAP operating margin of 18.4%.

[0001262039-20-000063:8k_2_02:26]
•Non-GAAP Operating Income and Margin1: Non-GAAP operating income was $178.6 million for the third quarter of 2020, representing a non-GAAP operating margin of 27.4%. Non-GAAP operating income was $145.2 million for the third quarter of 2019, representing a non-GAAP operating margin of 26.5%.

[0001262039-20-000063:8k_2_02:27]
•GAAP Net Income and Diluted Net Income Per Share: GAAP net income was $123.4 million for the third quarter of 2020, compared to GAAP net income of $80.2 million for the same quarter of 2019. GAAP diluted net income per share was $0.75 for the third quarter of 2020, based on 165.6 million diluted weighted-average shares outstanding, compared to GAAP diluted net income per share of $0.46 for the same quarter of 2019, based on 174.8 million diluted weighted-average shares outstanding.

[0001262039-20-000063:8k_2_02:28]
•Non-GAAP Net Income and Diluted Net Income Per Share1: Non-GAAP net income was $145.4 million for the third quarter of 2020, compared to non-GAAP net income of $117.3 million for the same quarter of 2019. Non-GAAP diluted net income per share was $0.88 for the third quarter of 2020, based on 165.6 million diluted weighted-average shares outstanding, compared to $0.67 for the same quarter of 2019, based on 174.8 million diluted weighted-average shares outstanding.

[0001262039-20-000063:8k_2_02:29]
•Cash Flow and Free Cash Flow1: In the third quarter of 2020, cash flow from operations was $220.8 million compared to $221.2 million in the same quarter of 2019. Free cash flow was $185.7 million during the third quarter of 2020, compared to $203.7 million for the same quarter of 2019.

[0001262039-20-000063:8k_2_02:30]
Guidance

[0001262039-20-000063:8k_2_02:31]
For the fourth quarter of 2020, Fortinet currently expects:

[0001262039-20-000063:8k_2_02:32]
•Revenue in the range of $710 million to $730 million

[0001262039-20-000063:8k_2_02:33]
•Billings in the range of $890 million to $920 million

[0001262039-20-000063:8k_2_02:34]
•Non-GAAP gross margin in the range of 78.0% to 80.0%

[0001262039-20-000063:8k_2_02:35]
•Non-GAAP operating margin in the range of 27.0% to 29.0%

[0001262039-20-000063:8k_2_02:36]
•Diluted non-GAAP net income per share in the range of $0.95 to $0.97, assuming a non-GAAP effective tax rate of 21%. This assumes a diluted share count of 167 million to 169 million.

[0001262039-20-000063:8k_2_02:37]
Our guidance with respect to non-GAAP financial measures excludes stock-based compensation, amortization of acquired intangible assets and gain on intellectual property matter. We have not reconciled our guidance with respect to non-GAAP financial measures to the corresponding GAAP measures because certain items that impact these measures are uncertain or out of our control, or cannot be reasonably predicted. Accordingly, a reconciliation

[0001262039-20-000063:8k_2_02:38]
of these non-GAAP financial measures to the corresponding GAAP measures is not available without unreasonable effort.

[0001262039-20-000063:8k_2_02:39]
1 A reconciliation of GAAP to non-GAAP measures has been provided in the financial statement tables included in this press release. An explanation of these measures is also included below under the heading “Non-GAAP Financial Measures.”

[0001262039-20-000063:8k_2_02:40]
2 During the third quarter, Fortinet identified and made an immaterial correction to the recognition of revenue related to certain service contracts, increasing previously reported amounts. The financial results presented for 2019 and 2020 reflect the effects of the correction.

[0001262039-20-000063:8k_2_02:41]
Conference Call Details

[0001262039-20-000063:8k_2_02:42]
Fortinet will host a conference call today at 1:30 p.m. Pacific Time (4:30 p.m. Eastern Time) to discuss the earnings results. The call can be accessed by dialing (877) 303-6913 (domestic) or (224) 357-2188 (international) with conference ID # 9928897. A live webcast of the conference call and supplemental slides will be accessible from the Investor Relations page of Fortinet’s website at https://investor.fortinet.com and a replay will be archived and accessible at https://investor.fortinet.com/events-and-presentations. A replay of this conference call can also be accessed through November 5, 2020, by dialing (855) 859-2056 (domestic) or (404) 537-3406 (international) with conference ID #9928897.

[0001262039-20-000063:8k_2_02:43]
Fourth Quarter 2020 Virtual Conference Participation Schedule:

[0001262039-20-000063:8k_2_02:44]
•Credit Suisse – Disruptive Security Series

[0001262039-20-000063:8k_2_02:45]
November 13, 2020

[0001262039-20-000063:8k_2_02:46]
•Credit Suisse 24th Annual Technology Conference

[0001262039-20-000063:8k_2_02:47]
December 2, 2020

[0001262039-20-000063:8k_2_02:48]
•Raymond James Technology Conference (IR Only)

[0001262039-20-000063:8k_2_02:49]
December 7, 2020

[0001262039-20-000063:8k_2_02:50]
•UBS Global TMT Virtual Conference

[0001262039-20-000063:8k_2_02:51]
December 8, 2020

[0001262039-20-000063:8k_2_02:52]
•Barclays Technology, Media and Telecommunications Conference

[0001262039-20-000063:8k_2_02:53]
December 9, 2020

[0001262039-20-000063:8k_2_02:54]
Members of Fortinet’s management team are expected to present at these conferences and discuss the latest company strategies and initiatives. Fortinet’s conference presentations are expected to be available via webcast on the company’s web site. To access the most updated information and listen to the webcast of each event, please visit the Investor Relations page of Fortinet’s website at https://investor.fortinet.com. The schedule is subject to change.

[0001262039-20-000063:8k_2_02:55]
About Fortinet (www.fortinet.com)

[0001262039-20-000063:8k_2_02:56]
Fortinet (Nasdaq: FTNT) secures the largest enterprise, service provider, and government organizations around the world. Fortinet empowers its customers with complete visibility and control across the expanding attack surface and the power to take on ever-increasing performance requirements today and into the future. Only the Fortinet Security Fabric platform can address the most critical security challenges and protect data across the entire digital infrastructure, whether in networked, application, multi-cloud or edge environments. Both a technology company and a learning organization, the Fortinet Network Security Institute has one

[0001262039-20-000063:8k_2_02:57]
of the largest and broadest cybersecurity training programs in the industry. Learn more at https://www.fortinet.com, the Fortinet Blog or FortiGuard Labs.

[0001262039-20-000063:8k_2_02:58]
#          #          #

[0001262039-20-000063:8k_2_02:59]
Copyright © 2020 Fortinet, Inc. All rights reserved. The symbols ® and ™ denote respectively federally registered trademarks and common law trademarks of Fortinet, Inc., its subsidiaries and affiliates. Fortinet’s trademarks include, but are not limited to, the following: Fortinet, the Fortinet logo, FortiGate, FortiOS, FortiGuard, FortiCare, FortiAnalyzer, FortiManager, FortiASIC, FortiClient, FortiCloud, FortiCore, FortiMail, FortiSandbox, FortiADC, FortiAI, FortiAP, FortiAppEngine, FortiAppMonitor, FortiAuthenticator, FortiBalancer, FortiBIOS, FortiBridge, FortiCache, FortiCall, FortiCam, FortiCamera, FortiCarrier, FortiCASB, FortiCenter, FortiCentral, FortiConnect, FortiController, FortiConverter, FortiCWP, FortiDB, FortiDDoS, FortiDeceptor, FortiDirector, FortiDNS, FortiEDR, FortiExplorer, FortiExtender, FortiFone, FortiGSLB, FortiHypervisor, FortiInsight, FortiIsolator, FortiLocator, FortiLog, FortiMeter, FortiMoM, FortiMonitor, FortiNAC, FortiPartner, FortiPortal, FortiPresence , FortiProtect, FortiProxy, FortiRecorder, FortiReporter, FortiSASE, FortiScan, FortiSDNConnector, FortiSIEM, FortiSDWAN, FortiSMS, FortiSOAR, FortiSwitch, FortiTester, FortiToken, FortiTrust, FortiVoice, FortiVoIP, FortiWAN, FortiWeb, FortiWiFi, FortiWLC, FortiWLCOS and FortiWLM. Other trademarks belong to their respective owners. Fortinet has not independently verified statements or certifications herein attributed to third parties and Fortinet does not independently endorse such statements. Notwithstanding anything to the contrary herein, nothing herein constitutes a warranty, guarantee, contract, binding specification or other binding commitment by Fortinet or any indication of intent related to a binding commitment, and performance and other specification information herein may be unique to certain environments.

[0001262039-20-000063:8k_2_02:60]
FTNT-F

[0001262039-20-000063:8k_2_02:61]
Forward-Looking Statements

[0001262039-20-000063:8k_2_02:62]
This press release contains forward-looking statements that involve risks and uncertainties. These forward-looking statements include statements regarding demand for our products and services, guidance and expectations around future financial results, including guidance and expectations for the fourth quarter 2020, statements regarding market share gains and innovation and investment areas, statements regarding the acceleration of digital transformation and cloud migration efforts as a result of the COVID-19, and statements regarding the momentum in our business and future growth expectations and objectives. Although we attempt to be accurate in making forward-looking statements, it is possible that future circumstances might differ from the assumptions on which such statements are based such that actual results are materially different from our forward-looking statements in this release. Important factors that could cause results to differ materially from the statements herein include the following: general economic risks, including those caused by the COVID-19 pandemic; negative impacts from the COVID-19 pandemic on sales, billings, revenue, demand and buying patterns, component supply and ability to manufacture products to meet demand in a timely fashion, and costs such as possible increased costs for shipping and components; global economic conditions, country-specific economic conditions, and foreign currency risks; competitiveness in the security market; the dynamic nature of the security market and its products and services; specific economic risks worldwide and in different geographies, and among different customer segments; uncertainty regarding demand and increased business and renewals from existing customers; uncertainties around continued success in sales growth and market share gains; actual or perceived vulnerabilities in our supply chain, products or services, and any actual or perceived breach of our network or our customers’ networks; longer sales cycles, particularly for larger enterprise, service providers, government and other large organization customers; the effectiveness of our salesforce and failure to convert sales pipeline into final sales; risks associated with successful implementation of multiple integrated software products and other product functionality risks; risks associated with integrating acquisitions and changes in

[0001262039-20-000063:8k_2_02:63]
COVID-19 Impact

[0001262039-20-000063:8k_2_02:64]
While the broader implications of the COVID-19 pandemic on our employees and overall financial performance remain uncertain, we have seen certain impacts on our business and operations, results of operations, financial condition, cash flows, liquidity and capital and financial resources. Going forward, the situation is uncertain, rapidly changing and hard to predict, and the COVID-19 pandemic may have a material negative impact on our future periods, including our results for the three months ending December 31, 2020 and beyond. To highlight the uncertainty remaining for the three-month period ending December 31, 2020, it should be noted that, due to customer buying patterns and the efforts of our sales force and channel partners to meet or exceed quarterly quotas, we have historically received a substantial portion of each quarter’s sales orders and generated a substantial portion of each quarter’s billings and revenue during the last two weeks of the quarter. If we experience significant changes in our billings growth rates, it will impact product revenue in the current quarter and FortiGuard and FortiCare service revenues in subsequent quarters, as we sell annual and multi-year service contracts that are recognized ratably over the contractual service term. In addition, the broader implications of the pandemic on our business and operations and our financial results, including the extent to which the effects of the pandemic will impact future results and growth in the cybersecurity industry, remain uncertain. The duration and severity of the economic downturn from the pandemic may negatively impact our business and operations, results of operations, financial condition, cash flows, liquidity and capital and financial resources in a material way. As a result, the effects of the pandemic may not be fully reflected in our results of operations until future periods.

[0001262039-20-000063:8k_2_02:65]
Non-GAAP Financial Measures

[0001262039-20-000063:8k_2_02:66]
We have provided in this release financial information that has not been prepared in accordance with U.S. Generally Accepted Accounting Principles (GAAP). These non-GAAP financial and liquidity measures are not based on any standardized methodology prescribed by GAAP and are not necessarily comparable to similar measures presented by other companies. We use these non-GAAP financial measures internally in analyzing our financial results and believe they are useful to investors, as a supplement to GAAP measures, in evaluating our ongoing operational performance. We believe that the use of these non-GAAP financial measures provides an additional tool for investors to use in evaluating ongoing operating results and trends and in comparing our financial results with peer companies, many of which present similar non-GAAP financial measures to investors.

[0001262039-20-000063:8k_2_02:67]
Non-GAAP financial measures should not be considered in isolation from, or as a substitute for, financial information prepared in accordance with GAAP. Investors are encouraged to review the reconciliation of these non-GAAP financial measures to their most directly comparable GAAP financial measures provided in the financial statement tables below.

[0001262039-20-000063:8k_2_02:68]
Billings (non-GAAP). We define billings as revenue recognized in accordance with GAAP plus the change in deferred revenue from the beginning to the end of the period, less any deferred revenue balances acquired from business combination(s) during the period. We consider billings to be a useful metric for management and investors because billings drive current and future revenue, which is an important indicator of the health and viability of our business. There are a number of limitations related to the use of billings instead of GAAP revenue. First, billings include amounts that have not yet been recognized as revenue and are impacted by the term of security and support agreements. Second, we may calculate billings in a manner that is different from peer companies that report similar financial measures. Management accounts for these limitations by providing specific information regarding GAAP revenue and evaluating billings together with GAAP revenue.

[0001262039-20-000063:8k_2_02:69]
Free cash flow (non-GAAP). We define free cash flow as net cash provided by operating activities minus purchases of property and equipment and excluding any significant non-recurring items, such as proceeds from intellectual property matter. We believe free cash flow to be a liquidity measure that provides useful information to management and investors about the amount of cash generated by the business that, after capital expenditures and net of proceeds from intellectual property matter, can be used for strategic opportunities, including repurchasing outstanding common stock, investing in our business, making strategic acquisitions and strengthening the balance sheet. A limitation of using free cash flow rather than the GAAP measures of cash provided by or used in operating activities, investing activities, and financing activities is that free cash flow does not represent the total increase or decrease in the cash and cash equivalents balance for the period because it excludes cash flows from significant non-recurring items, such as proceeds from intellectual property matter, investing activities other than capital expenditures and cash flows from financing activities. Management accounts for this limitation by providing information about our capital expenditures and other investing and financing activities on the face of the cash flow statement and under the caption “Management’s Discussion and Analysis of Financial Condition and Results of Operations—Liquidity and Capital Resources” in our most recent Quarterly Report on Form 10-Q and Annual Report on Form 10-K and by presenting cash flows from investing and financing activities in our reconciliation of free cash flow. In addition, it is important to note that other companies, including companies in our industry, may not use free cash flow, may calculate free cash flow in a different manner than we do or may use other financial measures to evaluate their performance, all of which could reduce the usefulness of free cash flow as a comparative measure.

[0001262039-20-000063:8k_2_02:70]
Non-GAAP operating income and operating margin. We define non-GAAP operating income as operating income plus stock-based compensation, impairment and amortization of acquired intangible assets, gain on intellectual property matter and, when applicable, other significant non-recurring items in a given quarter, such as non-recurring gains or losses on litigation-related matters. Non-GAAP operating margin is defined as non-GAAP operating income divided by GAAP revenue. We consider these non-GAAP financial measures to be useful metrics for management and investors because they exclude the items noted above so that our management and investors can compare our recurring core business operating results over multiple periods. There are a number of limitations related to the use of non-GAAP operating income instead of operating income or loss calculated in accordance with GAAP. First, non-GAAP operating income excludes the items noted above. Second, the components of the costs that we exclude from our calculation of non-GAAP operating income may differ from the components that peer companies exclude when they report their non-GAAP results of operations. Management accounts for these limitations by providing specific information regarding the GAAP amounts excluded from non-GAAP operating income and evaluating non-GAAP operating income together with operating income calculated in accordance with GAAP.

[0001262039-20-000063:8k_2_02:71]
Non-GAAP net income and diluted net income per share. We define non-GAAP net income as net income or loss plus the items noted above under non-GAAP operating income and operating margin. In addition, we adjust non-GAAP net income and diluted net income per share for gains or losses on investments in privately held companies and a tax adjustment required for an effective tax rate on a non-GAAP basis, which differs from the GAAP effective tax rate. We define non-GAAP diluted net income per share as non-GAAP net income divided by the non-GAAP diluted weighted-average shares outstanding. We consider these non-GAAP financial measures to be useful metrics for management and investors for the same reasons that we use non-GAAP operating income and non-GAAP operating margin. However, in order to provide a more complete picture of our recurring core business operating results, we include in non-GAAP net income and non-GAAP diluted net income per share, the tax adjustment required resulting in an effective tax rate on a non-GAAP basis, which often differs from the GAAP tax rate. We believe the non-GAAP effective tax rates we use are reasonable estimates of normalized tax rates for our current and prior fiscal years under our global operating structure. The same limitations described above regarding our use of non-GAAP operating income and non-GAAP operating margin apply to our use of non-GAAP net income and non-GAAP diluted net income per share. We account for these limitations by providing specific information regarding the GAAP amounts excluded from non-GAAP net income and non-GAAP diluted net income per share and evaluating non-GAAP net income and non-GAAP diluted net income per share together with net income or loss and diluted net income per share calculated in accordance with GAAP.

[0001262039-20-000063:8k_2_02:72]
FORTINET, INC.

[0001262039-20-000063:8k_2_02:73]
CONDENSED CONSOLIDATED BALANCE SHEETS1

[0001262039-20-000063:8k_2_02:74]
(Unaudited, in millions)

[0001262039-20-000063:8k_2_02:75]
|  | September 30,2020 |  | December 31,2019 |
| ASSETS |  |  |  |
| CURRENT ASSETS: |  |  |  |
| Cash and cash equivalents | $ | 882.3 |  |  | $ | 1,222.5 |  |
| Short-term investments | 774.4 |  |  | 843.1 |  |
| Accounts receivable—net | 546.6 |  |  | 544.3 |  |
| Inventory | 134.5 |  |  | 117.9 |  |
| Prepaid expenses and other current assets | 46.8 |  |  | 41.2 |  |
| Total current assets | 2,384.6 |  |  | 2,769.0 |  |
| LONG-TERM INVESTMENTS | 117.9 |  |  | 144.3 |  |
| PROPERTY AND EQUIPMENT—NET | 419.4 |  |  | 344.3 |  |
| DEFERRED CONTRACT COSTS | 281.1 |  |  | 237.0 |  |
| DEFERRED TAX ASSETS | 230.1 |  |  | 226.3 |  |
| GOODWILL AND OTHER INTANGIBLE ASSETS—NET | 93.5 |  |  | 98.3 |  |
| OTHER ASSETS | 59.6 |  |  | 60.0 |  |
| TOTAL ASSETS | $ | 3,586.2 |  |  | $ | 3,879.2 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |
| CURRENT LIABILITIES: |  |  |  |
| Accounts payable | $ | 95.9 |  |  | $ | 96.4 |  |
| Accrued liabilities | 127.8 |  |  | 101.8 |  |
| Accrued payroll and compensation | 121.9 |  |  | 101.8 |  |
| Deferred revenue | 1,300.0 |  |  | 1,155.8 |  |
| Total current liabilities | 1,645.6 |  |  | 1,455.8 |  |
| DEFERRED REVENUE | 1,092.0 |  |  | 953.3 |  |
| INCOME TAX LIABILITIES | 79.3 |  |  | 82.8 |  |
| OTHER LIABILITIES | 56.1 |  |  | 44.9 |  |
| Total liabilities | 2,873.0 |  |  | 2,536.8 |  |
| COMMITMENTS AND CONTINGENCIES |  |  |  |
| STOCKHOLDERS’ EQUITY: |  |  |  |
| Common stock | 0.2 |  |  | 0.2 |  |
| Additional paid-in capital | 1,178.5 |  |  | 1,180.3 |  |
| Accumulated other comprehensive income | 1.4 |  |  | 1.1 |  |
| Retained earnings (accumulated deficit) | (466.9) |  |  | 160.8 |  |
| Total stockholders’ equity | 713.2 |  |  | 1,342.4 |  |
| TOTAL LIABILITIES AND STOCKHOLDERS’ EQUITY | $ | 3,586.2 |  |  | $ | 3,879.2 |  |

[0001262039-20-000063:8k_2_02:76]
1 During the third quarter, Fortinet identified and made an immaterial correction to the recognition of revenue related to certain service contracts, increasing previously reported amounts. The financial results presented for 2019 and 2020 reflect the effects of the correction.

[0001262039-20-000063:8k_2_02:77]
FORTINET, INC.

[0001262039-20-000063:8k_2_02:78]
CONDENSED CONSOLIDATED STATEMENTS OF INCOME1

[0001262039-20-000063:8k_2_02:79]
(Unaudited, in millions, except per share amounts)

[0001262039-20-000063:8k_2_02:80]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30,2020 |  | September 30,2019 |  | September 30,2020 |  | September 30,2019 |
| REVENUE: |  |  |  |  |  |  |  |
| Product | $ | 223.8 |  |  | $ | 197.1 |  |  | $ | 628.0 |  |  | $ | 549.7 |  |
| Service | 427.3 |  |  | 351.0 |  |  | 1,218.4 |  |  | 995.2 |  |
| Total revenue | 651.1 |  |  | 548.1 |  |  | 1,846.4 |  |  | 1,544.9 |  |
| COST OF REVENUE: |  |  |  |  |  |  |  |
| Product | 84.3 |  |  | 79.0 |  |  | 245.0 |  |  | 231.9 |  |
| Service | 54.9 |  |  | 45.1 |  |  | 158.0 |  |  | 133.5 |  |
| Total cost of revenue | 139.2 |  |  | 124.1 |  |  | 403.0 |  |  | 365.4 |  |
| GROSS PROFIT: |  |  |  |  |  |  |  |
| Product | 139.5 |  |  | 118.1 |  |  | 383.0 |  |  | 317.8 |  |
| Service | 372.4 |  |  | 305.9 |  |  | 1,060.4 |  |  | 861.7 |  |
| Total gross profit | 511.9 |  |  | 424.0 |  |  | 1,443.4 |  |  | 1,179.5 |  |
| OPERATING EXPENSES: |  |  |  |  |  |  |  |
| Research and development | 90.0 |  |  | 69.9 |  |  | 252.4 |  |  | 205.9 |  |
| Sales and marketing | 266.7 |  |  | 227.4 |  |  | 780.5 |  |  | 669.8 |  |
| General and administrative | 29.4 |  |  | 26.1 |  |  | 87.1 |  |  | 74.9 |  |
| Gain on intellectual property matter | (1.1) |  |  | — |  |  | (39.0) |  |  | — |  |
| Total operating expenses | 385.0 |  |  | 323.4 |  |  | 1,081.0 |  |  | 950.6 |  |
| OPERATING INCOME | 126.9 |  |  | 100.6 |  |  | 362.4 |  |  | 228.9 |  |
| INTEREST INCOME—NET | 2.5 |  |  | 11.4 |  |  | 15.7 |  |  | 32.6 |  |
| OTHER EXPENSE—NET | (1.0) |  |  | (6.0) |  |  | (8.1) |  |  | (6.9) |  |
| INCOME BEFORE INCOME TAXES | 128.4 |  |  | 106.0 |  |  | 370.0 |  |  | 254.6 |  |
| PROVISION FOR INCOME TAXES | 5.0 |  |  | 25.8 |  |  | 28.2 |  |  | 41.1 |  |
| NET INCOME | $ | 123.4 |  |  | $ | 80.2 |  |  | $ | 341.8 |  |  | $ | 213.5 |  |
| Net income per share: |  |  |  |  |  |  |  |
| Basic | $ | 0.76 |  |  | $ | 0.47 |  |  | $ | 2.07 |  |  | $ | 1.25 |  |
| Diluted | $ | 0.75 |  |  | $ | 0.46 |  |  | $ | 2.03 |  |  | $ | 1.22 |  |
| Weighted-average shares outstanding: |  |  |  |  |  |  |  |
| Basic | 162.1 |  |  | 171.3 |  |  | 164.8 |  |  | 170.9 |  |
| Diluted | 165.6 |  |  | 174.8 |  |  | 168.4 |  |  | 174.9 |  |

[0001262039-20-000063:8k_2_02:81]
1 During the third quarter, Fortinet identified and made an immaterial correction to the recognition of revenue related to certain service contracts, increasing previously reported amounts. The financial results presented for 2019 and 2020 reflect the effects of the correction.

[0001262039-20-000063:8k_2_02:82]
FORTINET, INC.

[0001262039-20-000063:8k_2_02:83]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS1

[0001262039-20-000063:8k_2_02:84]
(Unaudited, in millions)

[0001262039-20-000063:8k_2_02:85]
|  | Nine Months Ended |
|  | September 30,2020 |  | September 30,2019 |
| CASH FLOWS FROM OPERATING ACTIVITIES: |  |  |  |
| Net income | $ | 341.8 |  |  | $ | 213.5 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |
| Stock-based compensation | 143.0 |  |  | 130.4 |  |
| Amortization of deferred contract costs | 99.8 |  |  | 78.5 |  |
| Depreciation and amortization | 52.1 |  |  | 45.9 |  |
| Amortization of investment discounts | 0.2 |  |  | (4.7) |  |
| Other | 5.8 |  |  | 5.0 |  |
| Changes in operating assets and liabilities: |  |  |  |
| Accounts receivable—net | (3.1) |  |  | 60.5 |  |
| Inventory | (31.0) |  |  | (25.2) |  |
| Prepaid expenses and other current assets | (4.6) |  |  | (6.3) |  |
| Deferred contract costs | (143.9) |  |  | (113.1) |  |
| Deferred tax assets | 4.4 |  |  | 11.5 |  |
| Other assets | (2.0) |  |  | (0.8) |  |
| Accounts payable | (4.2) |  |  | (6.2) |  |
| Accrued liabilities | 16.5 |  |  | (16.6) |  |
| Accrued payroll and compensation | 19.5 |  |  | (9.5) |  |
| Other liabilities | 10.3 |  |  | (1.0) |  |
| Deferred revenue | 282.6 |  |  | 255.7 |  |
| Net cash provided by operating activities | 787.2 |  |  | 617.6 |  |
| CASH FLOWS FROM INVESTING ACTIVITIES: |  |  |  |
| Purchases of investments | (776.3) |  |  | (1,072.4) |  |
| Sales of investments | 141.4 |  |  | 19.7 |  |
| Maturities of investments | 730.3 |  |  | 695.0 |  |
| Purchases of property and equipment | (93.6) |  |  | (45.0) |  |
| Payments made in connection with business combination, net of cash acquired | (9.2) |  |  | — |  |
| Other | (0.4) |  |  | — |  |
| Net cash used in investing activities | (7.8) |  |  | (402.7) |  |
| CASH FLOWS FROM FINANCING ACTIVITIES: |  |  |  |
| Repurchase and retirement of common stock | (1,046.0) |  |  | (117.6) |  |
| Proceeds from issuance of common stock | 18.2 |  |  | 41.8 |  |
| Taxes paid related to net share settlement of equity awards | (86.5) |  |  | (76.0) |  |
| Payment of debt assumed in connection with business combination | (4.1) |  |  | — |  |
| Other | (1.2) |  |  | — |  |
| Net cash used in financing activities | (1,119.6) |  |  | (151.8) |  |
| NET DECREASE IN CASH AND CASH EQUIVALENTS | (340.2) |  |  | 63.1 |  |
| CASH AND CASH EQUIVALENTS—Beginning of period | 1,222.5 |  |  | 1,112.4 |  |
| CASH AND CASH EQUIVALENTS—End of period | $ | 882.3 |  |  | $ | 1,175.5 |  |

[0001262039-20-000063:8k_2_02:86]
1 During the third quarter, Fortinet identified and made an immaterial correction to the recognition of revenue related to certain service contracts, increasing previously reported amounts. The financial results presented for 2019 and 2020 reflect the effects of the correction.

[0001262039-20-000063:8k_2_02:87]
Reconciliations of non-GAAP results of operations measures to the nearest comparable GAAP measures

[0001262039-20-000063:8k_2_02:88]
(Unaudited, in millions, except per share amounts)

[0001262039-20-000063:8k_2_02:89]
Reconciliation of net cash provided by operating activities to free cash flow1

[0001262039-20-000063:8k_2_02:90]
|  | Three Months Ended |
|  | September 30,2020 |  | September 30,2019 |
| Net cash provided by operating activities | $ | 220.8 |  |  | $ | 221.2 |  |
| Less: Purchases of property and equipment | (35.1) |  |  | (17.5) |  |
| Free cash flow | $ | 185.7 |  |  | $ | 203.7 |  |
| Net cash used in investing activities | $ | (224.6) |  |  | $ | (27.1) |  |
| Net cash used in financing activities | $ | (30.3) |  |  | $ | (40.7) |  |

[0001262039-20-000063:8k_2_02:91]
Reconciliation of GAAP operating income to non-GAAP operating income, operating margin, net income and diluted net income per share1

[0001262039-20-000063:8k_2_02:92]
|  | Three Months Ended September 30, 2020 |  | Three Months Ended September 30, 2019 |
|  | GAAP Results |  | Adjustments |  | Non-GAAP Results |  | GAAP Results |  | Adjustments |  | Non-GAAP Results |
| Operating income | $ | 126.9 |  |  | $ | 51.7 |  | (a) | $ | 178.6 |  |  | $ | 100.6 |  |  | $ | 44.6 |  | (b) | $ | 145.2 |  |
| Operating margin | 19.5 | % |  |  |  | 27.4 | % |  | 18.4 | % |  |  |  | 26.5 | % |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | 50.0 |  |  |  |  |  |  | 42.4 |  |  |  |
| Amortization of acquired intangible assets |  |  | 2.8 |  |  |  |  |  |  | 2.2 |  |  |  |
| Gain on intellectual property matter |  |  | (1.1) |  |  |  |  |  |  | — |  |  |  |
| Loss on investments in privately-held companies |  |  | — |  |  |  |  |  |  | 3.8 |  | (c) |  |
| Tax adjustment |  |  | (29.7) |  | (d) |  |  |  |  | (11.3) |  | (d) |  |
| Net income | $ | 123.4 |  |  | $ | 22.0 |  |  | $ | 145.4 |  |  | $ | 80.2 |  |  | $ | 37.1 |  |  | $ | 117.3 |  |
| Diluted net income per share | $ | 0.75 |  |  |  |  | $ | 0.88 |  |  | $ | 0.46 |  |  |  |  | $ | 0.67 |  |
| Shares used in diluted net income per share calculations | 165.6 |  |  |  |  | 165.6 |  |  | 174.8 |  |  |  |  | 174.8 |  |

[0001262039-20-000063:8k_2_02:93]
(a) To exclude $50.0 million of stock-based compensation and $2.8 million of amortization of acquired intangible assets, offset by a $1.1 million gain on intellectual property matter, in the three months ended September 30, 2020.

[0001262039-20-000063:8k_2_02:94]
(b) To exclude $42.4 million of stock-based compensation and $2.2 million of amortization of acquired intangible assets in the three months ended September 30, 2019.

[0001262039-20-000063:8k_2_02:95]
(c) To exclude a $3.8 million impairment charge on an investment in a privately held company.

[0001262039-20-000063:8k_2_02:96]
(d) Non-GAAP financial information is adjusted to an effective tax rate of 19% and 24% in the three months ended 2020 and 2019, respectively, on a non-GAAP basis, which differs from the GAAP effective tax rate.

[0001262039-20-000063:8k_2_02:97]
Reconciliation of total revenue to total billings1

[0001262039-20-000063:8k_2_02:98]
|  | Three Months Ended |
|  | September 30,2020 |  | September 30,2019 |
| Total revenue | $ | 651.1 |  |  | $ | 548.1 |  |
| Add: Change in deferred revenue | 98.9 |  |  | 78.5 |  |
| Less: Deferred revenue balance acquired in business acquisition | (0.2) |  |  | — |  |
| Total billings | $ | 749.8 |  |  | $ | 626.6 |  |

[0001262039-20-000063:8k_2_02:99]
1 During the third quarter, Fortinet identified and made an immaterial correction to the recognition of revenue related to certain service contracts, increasing previously reported amounts. The financial results presented for 2019 and 2020 reflect the effects of the correction.

[0001262039-20-000063:8k_2_02:100]
| Investor Contact: |  | Media Contact: |
| Peter Salkowski |  | Sandra Wheatley |
| Fortinet, Inc. |  | Fortinet, Inc. |
| 408-331-4595 |  | 408-391-9408 |
| psalkowski@fortinet.com |  | swheatley@fortinet.com |
