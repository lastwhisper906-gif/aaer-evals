# FTNT MD&A — 0001262039-20-000067


## mdna

[0001262039-20-000067:mdna:1]
ITEM 2.     Management’s Discussion and Analysis of Financial Condition and Results of Operations

[0001262039-20-000067:mdna:2]
[same as prior period, unchanged from 0001262039-20-000053:mdna:2]

[0001262039-20-000067:mdna:3]
[same as prior period, unchanged from 0001262039-20-000053:mdna:3]

[0001262039-20-000067:mdna:4]
[same as prior period, unchanged from 0001262039-20-000053:mdna:4]

[0001262039-20-000067:mdna:5]
[same as prior period, unchanged from 0001262039-20-000053:mdna:5]

[0001262039-20-000067:mdna:6]
[same as prior period, unchanged from 0001262039-20-000053:mdna:6]

[0001262039-20-000067:mdna:7]
[same as prior period, unchanged from 0001262039-20-000053:mdna:7]

[0001262039-20-000067:mdna:8]
[same as prior period, unchanged from 0001262039-20-000053:mdna:8]

[0001262039-20-000067:mdna:9]
[same as prior period, unchanged from 0001262039-20-000053:mdna:9]

[0001262039-20-000067:mdna:10]
[same as prior period, unchanged from 0001262039-20-000053:mdna:10]

[0001262039-20-000067:mdna:11]
[same as prior period, unchanged from 0001262039-20-000053:mdna:11]

[0001262039-20-000067:mdna:12]
[same as prior period, unchanged from 0001262039-20-000053:mdna:12]

[0001262039-20-000067:mdna:13]
[same as prior period, unchanged from 0001262039-20-000053:mdna:13]

[0001262039-20-000067:mdna:14]
[same as prior period, unchanged from 0001262039-20-000053:mdna:14]

[0001262039-20-000067:mdna:15]
[same as prior period, unchanged from 0001262039-20-000053:mdna:15]

[0001262039-20-000067:mdna:16]
[same as prior period, unchanged from 0001262039-20-000053:mdna:16]

[0001262039-20-000067:mdna:17]
[same as prior period, unchanged from 0001262039-20-000053:mdna:17]

[0001262039-20-000067:mdna:18]
[same as prior period, unchanged from 0001262039-20-000053:mdna:18]

[0001262039-20-000067:mdna:19]
[same as prior period, unchanged from 0001262039-20-000053:mdna:19]

[0001262039-20-000067:mdna:20]
[same as prior period, unchanged from 0001262039-20-000053:mdna:20]

[0001262039-20-000067:mdna:21]
27

[0001262039-20-000067:mdna:22]
•expectations regarding uncertain tax benefits and our effective domestic and global tax rates, and the impact of the Tax Cuts and Jobs Act (the “2017 Tax Act”);

[0001262039-20-000067:mdna:23]
[same as prior period, unchanged from 0001262039-20-000053:mdna:22]

[0001262039-20-000067:mdna:24]
[same as prior period, unchanged from 0001262039-20-000053:mdna:23]

[0001262039-20-000067:mdna:25]
•statements regarding expected outcomes and liabilities in litigation;

[0001262039-20-000067:mdna:26]
[same as prior period, unchanged from 0001262039-20-000053:mdna:25]

[0001262039-20-000067:mdna:27]
[same as prior period, unchanged from 0001262039-20-000053:mdna:26]

[0001262039-20-000067:mdna:28]
[same as prior period, unchanged from 0001262039-20-000053:mdna:27]

[0001262039-20-000067:mdna:29]
[same as prior period, unchanged from 0001262039-20-000053:mdna:28]

[0001262039-20-000067:mdna:30]
Fortinet is a global leader in cybersecurity solutions provided to a wide variety of organizations, including enterprises, communication service providers, government organizations and small businesses. Our cybersecurity solutions are designed to provide broad visibility and segmentation of the digital attack surface through our integrated Fortinet Security Fabric platform, which features automated protection, detection and response. The Fortinet Security Fabric platform helps organizations secure their environments and reduce their security and network complexities. The Fortinet Security Fabric platform has an open architecture designed to connect Fortinet solutions and third-party solutions into a single ecosystem, enabling integration and automation.

[0001262039-20-000067:mdna:31]
Our product offerings consist of our FortiGate network security product family and our non-FortiGate products. Our FortiGate hardware and software licenses are sold with a set of security services in addition to networking features. Our security services are enabled by FortiGuard Labs, which provides threat research and artificial intelligence capabilities from a cloud network to deliver protection services to each FortiGate appliance and virtual machine that is registered by the end-customer.

[0001262039-20-000067:mdna:32]
Our FortiOS operating system, virtual machines and associated security and networking functions are combined to form the Fortinet Security Fabric platform. This approach to security ties discrete security solutions together into an integrated whole.

[0001262039-20-000067:mdna:33]
Our proprietary Security Processing Units (“SPUs”) are Application-Specific Integrated Circuits that are designed to enhance the security processing capabilities implemented in software by accelerating computationally intensive tasks such as firewall policy enforcement, software-defined wide-area network (“SD-WAN”), network address translation, Intrusion Prevention Systems (“IPS”), threat detection and encryption.

[0001262039-20-000067:mdna:34]
FortiOS provides the foundation for the operation of all FortiGate network security appliances, whether physical, virtual, private- or public-cloud based, and is at the heart of the Fortinet Security Fabric platform. We make regular updates to FortiOS available through our FortiCare support services. The security and networking capabilities of the Fortinet Security Fabric platform are controlled through FortiOS. FortiOS directs the operations of processors and SPUs and provides system management functions.

[0001262039-20-000067:mdna:35]
[same as prior period, unchanged from 0001262039-20-000053:mdna:30]

[0001262039-20-000067:mdna:36]
•Security-Driven Networking—We derive a majority of product sales from our FortiGate network security appliances. Our FortiGate network security appliances include a broad set of built-in security and networking features and functionalities, including firewall, next-generation firewall, secure web gateway, secure sockets layer inspection, SD-WAN, IPS, sandboxing, data leak prevention, virtual private network (“VPN”), switch and wireless controller and WAN edge. Our network security appliances are managed by our FortiOS network operating system, which provides the foundation for FortiGate security functions. We enhance the performance of our network security appliances from branch to data center by designing and implementing SPU technology within our appliances, enabling us to add security and network functionality with minimal impact to network throughput performance.

[0001262039-20-000067:mdna:37]
•Infrastructure Security—The Fortinet Security Fabric platform extends beyond the network to cover other attack vectors. Other infrastructure solutions covered include teleworker and remote security solutions such as FortiAuthenticator, FortiClient and FortiToken, as well as Secure Access (Wi-Fi and switch).

[0001262039-20-000067:mdna:38]
•Dynamic Cloud Security—We help customers connect securely to and across their individual, hybrid and multi-cloud environments by offering security through our virtual firewall and other software products and through integrated capabilities with major cloud platforms. Our public and private cloud security solutions, including virtual appliances and hosted solutions, extend the core capabilities of the Fortinet Security Fabric platform in and across cloud environments, delivering security that follows their applications and data. Our Secure SD-WAN for Multi-Cloud solution automates deployment of an overlay network across different cloud networks and offers visibility, control and centralized management that integrates functionality across multiple cloud environments. Fortinet cloud security offerings are available across all major public and private cloud providers, including Amazon Web Services, Microsoft Azure, Google Cloud, Oracle Cloud, Alibaba Cloud, IBM Cloud and VMWare Cloud. Our Cloud Security portfolio also includes securing applications, including email and web.

[0001262039-20-000067:mdna:39]
[same as prior period, unchanged from 0001262039-20-000053:mdna:35]

[0001262039-20-000067:mdna:40]
•AI-Driven Security Operations—We develop and provide AI-driven security operations solutions, including FortiGuard and other security subscription services, endpoint detection and response, and our security operations, analytics, and reporting (“SOAR”) capabilities and solutions, that can be applied across the entire Fortinet Security Fabric platform. These solutions deliver intelligence and insights.

[0001262039-20-000067:mdna:41]
In addition to our security solutions, our customers may purchase FortiGuard and other security subscription services to receive threat intelligence updates and protection updates delivered by FortiGuard Labs, FortiCare technical support services and the support of Technical Account Managers, Resident Engineers and professional service consultants for implementations or training services.

[0001262039-20-000067:mdna:42]
Correction of Prior Period Financial Data

[0001262039-20-000067:mdna:43]
As discussed further in Note 2 of the notes to condensed consolidated financial statements included in Part I, Item 1 of this Quarterly Report on Form 10-Q, we identified an immaterial error related to the commencement of revenue recognition for certain FortiCare standalone service contracts, which resulted in an understatement of revenue during the three and nine months ended September 30, 2019 and the six months ended June 30, 2020.

[0001262039-20-000067:mdna:44]
The correction of this error resulted in increases to service revenue, gross profit and operating income of $2.9 million for the six months ended June 30, 2020 and $0.6 million and $3.1 million for the three and nine months ended September 30, 2019, respectively. Net income increased by $2.3 million for the six months ended June 30, 2020 and by $0.4 million and $2.2 million for the three and nine months ended September 30, 2019, which resulted in an increase to diluted net income per share of $0.02 for the six months ended June 30, 2020, no impact for the three months ended September 30, 2019 and an increase of $0.01 for the nine months ended September 30, 2019.

[0001262039-20-000067:mdna:45]
[same as prior period, unchanged from 0001262039-20-000053:mdna:75]

[0001262039-20-000067:mdna:46]
We evaluated the effect of this correction on the previous results of operations and determined that it did not impact any trends previously disclosed. This correction did not impact billings, net cash provided by operating activities or free cash flows.

[0001262039-20-000067:mdna:47]
[same as prior period, unchanged from 0001262039-20-000053:mdna:38]

[0001262039-20-000067:mdna:48]
•Total revenue was $651.1 million and $1.85 billion during the three and nine months ended September 30, 2020, respectively, an increase of 19% and 20%, respectively, compared to $548.1 million and $1.54 billion in the same periods last year, respectively. Product revenue was $223.8 million and $628.0 million during the three and nine months ended September 30, 2020, respectively, an increase of 14% in both periods, compared to $197.1 million and $549.7 million in the same periods last year, respectively. Service revenue was $427.3 million and $1.22 billion during the three and nine months ended September 30, 2020, respectively, an increase of 22% in both periods, compared to $351.0 million and $995.2 million in the same periods last year, respectively.

[0001262039-20-000067:mdna:49]
•Total gross profit was $511.9 million and $1.44 billion during the three and nine months ended September 30, 2020, respectively, an increase of 21% and 22%, respectively, compared to $424.0 million and $1.18 billion in the same periods last year, respectively.

[0001262039-20-000067:mdna:50]
•We generated operating income of $126.9 million and $362.4 million during the three and nine months ended September 30, 2020, respectively, an increase of 26% and 58%, respectively, compared to $100.6 million and $228.9 million in the same periods last year, respectively. Operating income during the three and nine months ended September 30, 2020 included gains on an intellectual property (“IP”) matter of $1.1 million and $39.0 million, respectively.

[0001262039-20-000067:mdna:51]
•Cash, cash equivalents and investments were $1.77 billion as of September 30, 2020.

[0001262039-20-000067:mdna:52]
•During the nine months ended September 30, 2020, we repurchased 11.4 million shares of common stock under our Share Repurchase Program (the “Repurchase Program”), for a total purchase price of $1.05 billion.

[0001262039-20-000067:mdna:53]
•Deferred revenue was $2.39 billion as of September 30, 2020, an increase of $282.9 million, or 13%, from December 31, 2019.

[0001262039-20-000067:mdna:54]
•We generated cash flows from operating activities of $787.2 million, which includes $50.0 million proceeds from an IP matter, during the nine months ended September 30, 2020, an increase of $169.6 million, or 27%, compared to the same period last year.

[0001262039-20-000067:mdna:55]
Our revenue growth was driven by both product and service revenue. On a geographic basis, revenue continues to be diversified, which remains a key strength of our business. During the three months ended September 30, 2020, the Americas region, the Europe, Middle East and Africa (“EMEA”) region and the Asia Pacific (“APAC”) region contributed 42%, 37% and 21% of our total revenue, respectively, and increased by 13%, 21% and 27% compared to the same period last year, respectively. During the nine months ended September 30, 2020, the Americas region, the Europe, Middle East and Africa region and the Asia Pacific region contributed 42%, 38% and 20% of our total revenue, respectively, and increased by 16%, 21% and 23% compared to the same period last year, respectively.

[0001262039-20-000067:mdna:56]
Product revenue grew 14% during both the three and nine months ended September 30, 2020 compared to the same periods last year. We experienced revenue growth across several of our hardware and software products, including SD-WAN and teleworker and remote security solutions. Service revenue growth of 22% during both the three and nine months ended September 30, 2020 compared to the same periods last year was driven by the strength of our FortiGuard and other security subscription revenue, which grew 22% and 23%, respectively, and of our FortiCare technical support and other service revenue, which grew 21% and 22%, respectively, compared to the same periods last year.

[0001262039-20-000067:mdna:57]
Our billings were diversified on a geographic basis. During the three months ended September 30, 2020, approximately 50% of our billings in the aggregate were from over 80 countries that individually contributed less than 3% of our billings.

[0001262039-20-000067:mdna:58]
During the third quarter of 2020, we acquired OPAQ Networks, Inc. (“OPAQ”) to further enhance the Fortinet Security Fabric platform by providing enterprises with OPAQ’s patented Zero Trust Network Access, SASE cloud solution. The impact of this acquisition was not material to our condensed consolidated financial statements.

[0001262039-20-000067:mdna:59]
During the three and nine months ended September 30, 2020, we recognized gains of $1.1 million and $39.0 million, respectively, on an IP matter in connection with a mutual covenant-not-to-sue and release agreement with a competitor in the network security industry. Excluding the gains on the IP matter, operating expenses as a percentage of revenue increased by 0.3 percentage points and decreased by 0.8 percentage points, respectively, during the three and nine months ended September 30, 2020 compared to the same periods last year. Headcount increased to 8,075 employees and contractors as of September 30, 2020, a 4% increase compared to 7,756 as of June 30, 2020 and a 14% increase compared to 7,082 as of December 31, 2019. The acquisition of OPAQ increased headcount by 44 employees.

[0001262039-20-000067:mdna:60]
[same as prior period, unchanged from 0001262039-20-000053:mdna:49]

[0001262039-20-000067:mdna:61]
The United States and the global community we serve are facing unprecedented challenges posed by the COVID-19 pandemic. In response to the pandemic, we have taken a number of actions to protect our employees, including restricting travel and directing most of our employees to work from home. Where onsite work is permitted, we have implemented measures such as staggered work shifts, social distancing, the use of face coverings, health safety awareness training and frequent disinfection of shared spaces. We have implemented our readiness plans, which include steps to maintain critical internet infrastructure with most employees working remotely.

[0001262039-20-000067:mdna:62]
We are also providing free online information technology security training for the public, aimed at helping high school and college students and professionals augment their security skill sets to open career opportunities and to help narrow the security skills gap. As of September 30, 2020, there have been over 600,000 registrations for our free online trainings since we launched the program.

[0001262039-20-000067:mdna:63]
While the broader implications of the COVID-19 pandemic on our employees and overall financial performance remain uncertain, we have seen certain impacts on our business and operations, results of operations, financial condition, cash flows, liquidity and capital and financial resources as of and during the three and nine months ended September 30, 2020. Conversely, some aspects of our business do not appear to have been significantly affected. During the three and nine months ended September 30, 2020, we have observed the following:

[0001262039-20-000067:mdna:64]
•The practice of social distancing in most countries has reduced the ability for travel by our employees. In-person sales and marketing events or meetings that would normally have been held during the three and nine months ended September 30, 2020 were canceled, postponed or converted into virtual events. As a result, expenses related to travel and marketing events decreased significantly. To the extent that it becomes safe for our employees to travel and for us to hold or attend marketing events, these expenses may increase in the future, although we cannot predict if or when such expenses will increase or return to pre-pandemic levels.

[0001262039-20-000067:mdna:65]
•We have offered payment terms in excess of our contractual agreements to some of our distributor customers, which has resulted in an increase to the average collection period of our trade receivables. As of September 30, 2020, 94% of our outstanding trade accounts receivable was due to be collected during the fourth quarter of 2020.

[0001262039-20-000067:mdna:66]
•The countries and geographic regions in which we experienced the fastest billings growth in the third quarter of 2020, as compared to the third quarter of 2019, were countries and geographic regions in which the COVID-19 pandemic is generally considered to have had a comparatively shorter or less severe impact on the local population and economy during the quarter.

[0001262039-20-000067:mdna:67]
[same as prior period, unchanged from 0001262039-20-000053:mdna:56]

[0001262039-20-000067:mdna:68]
•Our average service contract duration remained consistent in the third quarter of 2020 as compared to the third quarter of 2019.

[0001262039-20-000067:mdna:69]
•In order to mitigate supply chain risk and in anticipation of fourth-quarter demand, we have increased our on-hand stock of certain products.

[0001262039-20-000067:mdna:70]
•The yield on investment-grade debt has decreased, and while the risk of credit losses on our investments and cash equivalents has not changed significantly, as the debt securities in our portfolio have matured, they have been replaced by securities with lower effective interest rates. This has contributed to a decrease in our interest income during the three and nine months ended September 30, 2020, compared to the same periods last year.

[0001262039-20-000067:mdna:71]
[same as prior period, unchanged from 0001262039-20-000053:mdna:60]

[0001262039-20-000067:mdna:72]
Through the filing of this Quarterly Report on Form 10-Q, there have been no material changes to the trends described above. Going forward, however, the situation is uncertain, rapidly changing and hard to predict, and the COVID-19 pandemic may have a material negative impact on our future periods, including our results for the three months ending December 31, 2020 and beyond. To highlight the uncertainty remaining for the three months ending December 31, 2020, it should be noted that, due to customer buying patterns and the efforts of our sales force and channel partners to meet or exceed quarterly quotas, we have historically received a substantial portion of each quarter’s sales orders and generated a substantial portion of each quarter’s billings and revenue during the last two weeks of the quarter. If we experience significant changes in our billings growth rates, it will impact product revenue in the current quarter and FortiGuard and FortiCare service revenues in subsequent quarters, as we sell annual and multi-year service contracts that are recognized ratably over the contractual service term. In addition, the broader implications of the pandemic on our business and operations and our financial results, including the extent to which the effects of the pandemic will impact future results and growth in the cybersecurity industry, remain uncertain. The duration and severity of the economic downturn from the pandemic may negatively impact our business and operations, results of operations, financial condition, cash flows, liquidity and capital and financial resources in a material way. As a result, the effects of the pandemic may not be fully reflected in our results of operations until future periods. For further discussion, see Part II, Item 1A of this Quarterly Report on Form 10-Q.

[0001262039-20-000067:mdna:73]
[same as prior period, unchanged from 0001262039-20-000053:mdna:62]

[0001262039-20-000067:mdna:74]
We typically sell our security solutions to distributors that sell to networking security and enterprise-focused resellers and to service providers and managed security service providers (“MSSPs”), who, in turn, sell to our end-customers. During the three months ended September 30, 2020, we sold products to over 8,000 different resellers. At times, we also sell directly to large service providers and major systems integrators who may sell to our end-customers or use our products and services to provided hosted solutions to other enterprises. Our end-customers are located in over 80 countries and include small and medium-sized businesses, large enterprises and government organizations across a wide range of industries, including telecommunications, government, financial services, retail, technology, education, manufacturing and healthcare. An end-customer deployment may involve as few as one or as many as thousands of appliances and other Fortinet Security Fabric platform products, depending on the end-customer’s size and security requirements.

[0001262039-20-000067:mdna:75]
We also offer our products through major cloud providers, and have recognized revenue on a usage basis from Amazon Web Services, Microsoft Azure, Google Cloud, Oracle Cloud, Alibaba Cloud and IBM Cloud. We have also recognized revenue from customers who deploy our products in a bring-your-own-license (“BYOL”) arrangement in private clouds or at cloud providers. In a BYOL arrangement, a customer purchases a software license from us through our channel partners and deploys the software in a cloud provider’s environment. Similarly, customers may purchase such a license from us and deploy in their private cloud.

[0001262039-20-000067:mdna:76]
Our customers purchase our hardware products and software licenses, as well as our FortiGuard and other security subscription and FortiCare technical support services. We generally invoice at the time of our sale for the total price of the products and security and technical support services. The invoice is typically payable within 30 to 60 days, though, as noted in the COVID-19 Update above, we have recently offered extended payment terms to certain customers.

[0001262039-20-000067:mdna:77]
[same as prior period, unchanged from 0001262039-20-000053:mdna:65]

[0001262039-20-000067:mdna:78]
We monitor a number of key metrics, including the key financial metrics set forth below, in order to help us evaluate growth trends, establish budgets, measure the effectiveness of our sales and marketing efforts, and assess operational efficiencies. The following table summarizes revenue, deferred revenue, billings (non-GAAP), net cash provided by operating activities, and free cash flow (non-GAAP). We discuss revenue below under “Results of Operations,” and we discuss net cash

[0001262039-20-000067:mdna:79]
provided by operating activities below under “—Liquidity and Capital Resources.” Deferred revenue, billings (non-GAAP), and free cash flow (non-GAAP) are discussed immediately below the following table:

[0001262039-20-000067:mdna:80]
|  | Three Months Ended Or As Of |
|  | September 30, 2020 |  | September 30, 2019 |
|  | (in millions) |
| Revenue | $ | 651.1 |  |  | $ | 548.1 |  |
| Deferred revenue | $ | 2,392.0 |  |  | $ | 1,922.5 |  |
| Billings (non-GAAP) | $ | 749.8 |  |  | $ | 626.6 |  |
| Net cash provided by operating activities | $ | 220.8 |  |  | $ | 221.2 |  |
| Free cash flow (non-GAAP) | $ | 185.7 |  |  | $ | 203.7 |  |

[0001262039-20-000067:mdna:81]
Deferred revenue. Our deferred revenue consists of amounts that have been invoiced but that have not yet been recognized as revenue. The majority of our deferred revenue balance consists of the unrecognized portion of service revenue from FortiGuard and other security subscription and FortiCare technical support service contracts, which is recognized as revenue ratably over the contractual service period. We monitor our deferred revenue balance, deferred revenue growth and the mix of short-term and long-term deferred revenue because deferred revenue represents a significant portion of free cash flow and of revenue to be recognized in future periods. Deferred revenue was $2.39 billion as of September 30, 2020, an increase of $282.9 million, or 13%, from December 31, 2019.

[0001262039-20-000067:mdna:82]
Billings (non-GAAP). We define billings as revenue recognized in accordance with GAAP plus the change in deferred revenue from the beginning to the end of the period, less any deferred revenue balances acquired from business combination(s) during the period. We consider billings to be a useful metric for management and investors because billings drive current and future revenue, which is an important indicator of the health and viability of our business. There are a number of limitations related to the use of billings instead of GAAP revenue. First, billings include amounts that have not yet been recognized as revenue and are impacted by the term of security and support agreements. Second, we may calculate billings in a manner that is different from peer companies that report similar financial measures. Management accounts for these limitations by providing specific information regarding GAAP revenue and evaluating billings together with GAAP revenue. Total billings were $749.8 million for the three months ended September 30, 2020, an increase of 20% compared to $626.6 million in the same period last year.

[0001262039-20-000067:mdna:83]
[same as prior period, unchanged from 0001262039-20-000053:mdna:71]

[0001262039-20-000067:mdna:84]
|  | Three Months Ended |
|  | September 30, 2020 |  | September 30, 2019 |
|  | (in millions) |
| Billings: |  |  |  |
| Revenue | $ | 651.1 |  |  | $ | 548.1 |  |
| Add: Change in deferred revenue | 98.9 |  |  | 78.5 |  |
| Less: Deferred revenue balance acquired in business combination | (0.2) |  |  | — |  |
| Total billings (non-GAAP) | $ | 749.8 |  |  | $ | 626.6 |  |

[0001262039-20-000067:mdna:85]
Free cash flow (non-GAAP). We define free cash flow as net cash provided by operating activities minus purchases of property and equipment and excluding any significant non-recurring items. We believe free cash flow to be a liquidity measure that provides useful information to management and investors about the amount of cash generated by the business that, after capital expenditures, can be used for strategic opportunities, including repurchasing outstanding common stock, investing in our business, making strategic acquisitions and strengthening the balance sheet. A limitation of using free cash flow rather than the GAAP measures of cash provided by or used in operating activities, investing activities, and financing activities is that free cash flow does not represent the total increase or decrease in the cash and cash equivalents balance for the period because it excludes cash flows from investing activities other than capital expenditures and cash flows from financing activities. Management accounts for this limitation by providing information about our capital expenditures and other investing and financing activities on the face of the consolidated statements of cash flows and under “—Liquidity and Capital Resources” and by presenting cash flows from investing and financing activities in our reconciliation of free cash flow. In addition, it is important to note that other companies, including companies in our industry, may not use free cash flow, may calculate free cash flow in a different manner

[0001262039-20-000067:mdna:86]
33

[0001262039-20-000067:mdna:87]
than we do or may use other financial measures to evaluate their performance, all of which could reduce the usefulness of free cash flow as a comparative measure. A reconciliation of net cash provided by operating activities, the most directly comparable financial measure calculated and presented in accordance with GAAP, to free cash flow is provided below:

[0001262039-20-000067:mdna:88]
|  | Three Months Ended |
|  | September 30, 2020 |  | September 30, 2019 |
|  | (in millions) |
| Free Cash Flow: |  |  |  |
| Net cash provided by operating activities | $ | 220.8 |  |  | $ | 221.2 |  |
| Less: Purchases of property and equipment | (35.1) |  |  | (17.5) |  |
| Free cash flow (non-GAAP) | $ | 185.7 |  |  | $ | 203.7 |  |
| Net cash used in investing activities | $ | (224.6) |  |  | $ | (27.1) |  |
| Net cash used in financing activities | $ | (30.3) |  |  | $ | (40.7) |  |

[0001262039-20-000067:mdna:89]
[same as prior period, unchanged from 0001262039-20-000053:mdna:76]

[0001262039-20-000067:mdna:90]
[same as prior period, unchanged from 0001262039-20-000053:mdna:77]

[0001262039-20-000067:mdna:91]
There were no material changes to our critical accounting policies and estimates as of and for the three and nine months ended September 30, 2020, as compared to the critical accounting policies and estimates described in our Annual Report on Form 10-K filed with the SEC on February 26, 2020 (the “Form 10-K”).

[0001262039-20-000067:mdna:92]
[same as prior period, unchanged from 0001262039-20-000053:mdna:79]

[0001262039-20-000067:mdna:93]
[same as prior period, unchanged from 0001262039-20-000053:mdna:80]

[0001262039-20-000067:mdna:94]
[same as prior period, unchanged from 0001262039-20-000053:mdna:81]

[0001262039-20-000067:mdna:95]
Three Months Ended September 30, 2020 and September 30, 2019

[0001262039-20-000067:mdna:96]
[same as prior period, unchanged from 0001262039-20-000053:mdna:83]

[0001262039-20-000067:mdna:97]
|  | Three Months Ended |  |  |  |  |
| September 30,2020 |  | September 30,2019 |  |  |  |  |
| Amount |  | % ofRevenue |  | Amount |  | % ofRevenue |  | Change |  | % Change |
| (in millions, except percentages) |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 223.8 |  |  | 34 | % |  | $ | 197.1 |  |  | 36 | % |  | $ | 26.7 |  |  | 14 | % |
| Service | 427.3 |  |  | 66 |  |  | 351.0 |  |  | 64 |  |  | 76.3 |  |  | 22 |  |
| Total revenue | $ | 651.1 |  |  | 100 | % |  | $ | 548.1 |  |  | 100 | % |  | $ | 103.0 |  |  | 19 | % |
| Revenue by geography: |  |  |  |  |  |  |  |  |  |  |  |
| Americas | $ | 272.4 |  |  | 42 | % |  | $ | 241.0 |  |  | 44 | % |  | $ | 31.4 |  |  | 13 | % |
| EMEA | 243.3 |  |  | 37 |  |  | 200.9 |  |  | 37 |  |  | 42.4 |  |  | 21 |  |
| APAC | 135.4 |  |  | 21 |  |  | 106.2 |  |  | 19 |  |  | 29.2 |  |  | 27 |  |
| Total revenue | $ | 651.1 |  |  | 100 | % |  | $ | 548.1 |  |  | 100 | % |  | $ | 103.0 |  |  | 19 | % |

[0001262039-20-000067:mdna:98]
[same as prior period, unchanged from 0001262039-20-000053:mdna:127]

[0001262039-20-000067:mdna:99]
Total revenue increased by $103.0 million, or 19%, during the three months ended September 30, 2020 compared to the same period last year. We continued to experience diversification of revenue geographically and across both customer and industry segments. Revenue from all regions grew, with EMEA contributing the largest portion of the increase on an absolute dollar basis and APAC contributing the largest growth on a percentage basis.

[0001262039-20-000067:mdna:100]
Product revenue increased by $26.7 million, or 14%, during the three months ended September 30, 2020 compared to the same period last year. We experienced revenue growth across many of our products due to an increase in product revenue from our FortiGate SD-WAN solutions, our security fabric platform products and software licenses.

[0001262039-20-000067:mdna:101]
Service revenue increased by $76.3 million, or 22%, during the three months ended September 30, 2020 compared to the same period last year. FortiGuard and other security subscription and FortiCare technical support and other revenues increased by $42.6 million, or 22%, and by $33.7 million, or 21%, respectively, during the three months ended September 30, 2020 compared to the same period last year. The increases were primarily due to the recognition of revenue from our growing deferred revenue balance related to FortiGuard and other security subscriptions and FortiCare technical support, including our customers moving to higher-tier support offerings. Of the service revenue recognized during the three months ended September 30, 2020, 92% was included in the deferred revenue balance as of June 30, 2020.

[0001262039-20-000067:mdna:102]
[same as prior period, unchanged from 0001262039-20-000053:mdna:88]

[0001262039-20-000067:mdna:103]
|  | Three Months Ended |  |  |  |  |
| September 30,2020 |  | September 30,2019 |  | Change |  | % Change |
| (in millions, except percentages) |
| Cost of revenue: |  |  |  |  |  |  |  |
| Product | $ | 84.3 |  |  | $ | 79.0 |  |  | $ | 5.3 |  |  | 7 | % |
| Service | 54.9 |  |  | 45.1 |  |  | 9.8 |  |  | 22 |  |
| Total cost of revenue | $ | 139.2 |  |  | $ | 124.1 |  |  | $ | 15.1 |  |  | 12 | % |
| Gross margin (%): |  |  |  |  |  |  |  |
| Product | 62.3 | % |  | 59.9 | % |  |  |  |  |
| Service | 87.2 |  |  | 87.2 |  |  |  |  |  |
| Total gross margin | 78.6 | % |  | 77.4 | % |  |  |  |  |

[0001262039-20-000067:mdna:104]
Total gross margin increased by 1.2 percentage points during the three months ended September 30, 2020 compared to the same period last year, driven by improvements to product gross margins.

[0001262039-20-000067:mdna:105]
Product gross margin increased by 2.4 percentage points during the three months ended September 30, 2020 compared to the same period last year. Product gross margin benefited from lower direct costs of hardware as a percentage of product revenue. Cost of product revenue was comprised primarily of third party contract manufacturers’ costs and the costs of materials used in production.

[0001262039-20-000067:mdna:106]
Service gross margin was flat during the three months ended September 30, 2020 compared to the same period last year. Cost of service revenue was comprised primarily of personnel costs.

[0001262039-20-000067:mdna:107]
[same as prior period, unchanged from 0001262039-20-000053:mdna:93]

[0001262039-20-000067:mdna:108]
|  | Three Months Ended |  | Change |  | % Change |
| September 30,2020 |  | September 30,2019 |  |
| Amount |  | % ofRevenue |  | Amount |  | % ofRevenue |  |
| (in millions, except percentages) |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | $ | 90.0 |  |  | 14% |  | $ | 69.9 |  |  | 13 | % |  | $ | 20.1 |  |  | 29 | % |
| Sales and marketing | 266.7 |  |  | 41 |  | 227.4 |  |  | 41 |  |  | 39.3 |  |  | 17 |  |
| General and administrative | 29.4 |  |  | 5 |  | 26.1 |  |  | 5 |  |  | 3.3 |  |  | 13 |  |
| Gain on IP matter | (1.1) |  |  | — |  | — |  |  | — |  |  | (1.1) |  |  | * |
| Total operating expenses | $ | 385.0 |  |  | 59% |  | $ | 323.4 |  |  | 59 | % |  | $ | 61.6 |  |  | 19 | % |

[0001262039-20-000067:mdna:109]
[same as prior period, unchanged from 0001262039-20-000053:mdna:95]

[0001262039-20-000067:mdna:110]
[same as prior period, unchanged from 0001262039-20-000053:mdna:96]

[0001262039-20-000067:mdna:111]
[same as prior period, unchanged from 0001262039-20-000053:mdna:97]

[0001262039-20-000067:mdna:112]
Research and development expense increased by $20.1 million, or 29%, during the three months ended September 30, 2020 compared to the same period last year, primarily due to an increase of $14.1 million in personnel-related costs as a result of increased headcount to support the development of new products, continued enhancements to our existing products and patent creation. In addition, product development expenses, such as third-party testing, prototypes and supplies, increased by $3.6 million. We currently intend to continue to invest in our research and development organization, and expect research and development expense to remain at or increase in absolute dollars during the remainder of 2020.

[0001262039-20-000067:mdna:113]
[same as prior period, unchanged from 0001262039-20-000053:mdna:99]

[0001262039-20-000067:mdna:114]
Sales and marketing expense increased by $39.3 million, or 17%, during the three months ended September 30, 2020 compared to the same period last year, primarily due to an increase of $50.0 million in personnel-related costs as a result of increases to sales and marketing headcount in order to drive global market share gains. This increase was offset by savings related to decreased travel and fewer in-person marketing events as a result of the COVID-19 pandemic. We currently intend to continue to make investments in our sales resources and infrastructure and marketing strategy, which are critical to support our future growth, and expect sales and marketing expense to increase in absolute dollars during the remainder of 2020.

[0001262039-20-000067:mdna:115]
[same as prior period, unchanged from 0001262039-20-000053:mdna:101]

[0001262039-20-000067:mdna:116]
General and administrative expense increased by $3.3 million, or 13%, during the three months ended September 30, 2020 compared to the same period last year, primarily due to an increase in personnel-related costs of $2.5 million. We currently expect general and administrative expense to remain at or increase in absolute dollars during the remainder of 2020.

[0001262039-20-000067:mdna:117]
[same as prior period, unchanged from 0001262039-20-000053:mdna:103]

[0001262039-20-000067:mdna:118]
In January 2020, we entered into an agreement with a competitor in the network security industry, whereby, in February 2020, the competitor party paid us a lump sum of $50.0 million for a mutual covenant-not-to-sue for patent claims. During the three months ended September 30, 2020, we recorded $1.1 million in amortization of the deferred component as a gain on IP matter in our condensed consolidated statements of income. See Note 12 of the notes to condensed consolidated financial statements included in Part I, Item 1 of this Quarterly Report on Form 10-Q for additional information regarding the gain on IP matter.

[0001262039-20-000067:mdna:119]
[same as prior period, unchanged from 0001262039-20-000053:mdna:105]

[0001262039-20-000067:mdna:120]
We generated operating income of $126.9 million during the three months ended September 30, 2020, an increase of $26.3 million, or 26%, compared to $100.6 million in the same period last year. Operating income as a percentage of revenue increased to 19% during the three months ended September 30, 2020 compared to 18% in the same period last year. The increase in operating margin is primarily due to the 1.2 percentage point increase in gross margin and the 0.5 percentage point

[0001262039-20-000067:mdna:121]
[same as prior period, unchanged from 0001262039-20-000053:mdna:151]

[0001262039-20-000067:mdna:122]
decrease in sales and marketing expense as a percentage of revenue, partially offset by the 1.0 percentage point increase in research and development expense as percentage of revenue.

[0001262039-20-000067:mdna:123]
Interest income—net and other expense—net

[0001262039-20-000067:mdna:124]
|  | Three Months Ended |  |  |  |  |
| September 30,2020 |  | September 30,2019 |  | Change |  | % Change |
| (in millions, except percentages) |
| Interest income—net | $ | 2.5 |  |  | $ | 11.4 |  |  | $ | (8.9) |  |  | (78) | % |
| Other expense—net | $ | (1.0) |  |  | $ | (6.0) |  |  | $ | 5.0 |  |  | (83) | % |

[0001262039-20-000067:mdna:125]
Interest income—net decreased during the three months ended September 30, 2020 compared to the same period last year, primarily due to lower interest rates and lower invested balances of cash, cash equivalents and investments. The lower cash, cash equivalents and investments were mainly due to our repurchases of common stock under the Repurchase Program during the past twelve months. The change in other expense—net during the three months ended September 30, 2020 compared to the same period last year was the result of a $3.8 million impairment charge on an investment in a privately held company during the third quarter of 2019. In addition, foreign currency exchange losses decreased by $1.4 million compared to the same period last year.

[0001262039-20-000067:mdna:126]
[same as prior period, unchanged from 0001262039-20-000053:mdna:111]

[0001262039-20-000067:mdna:127]
|  | Three Months Ended |  | Change |  | % Change |
| September 30,2020 |  | September 30,2019 |  |
| (in millions, except percentages) |
| Provision for income taxes | $ | 5.0 |  |  | $ | 25.8 |  |  | $ | (20.8) |  |  | (81) | % |
| Effective tax rate (%) | 4 | % |  | 24 | % |  |  |  |  |

[0001262039-20-000067:mdna:128]
Our effective tax rate was 4% for the three months ended September 30, 2020 compared to an effective tax rate of 24% for the same period last year. The provision for income taxes for the three months ended September 30, 2020 was primarily comprised of U.S. federal and state taxes, withholding taxes and foreign taxes that were $17.5 million, which included a tax benefit of $16.0 million from the foreign-derived intangible income deduction. This tax provision for income taxes was favorably affected by excess tax benefits from stock-based compensation expense of $12.5 million.

[0001262039-20-000067:mdna:129]
The provision for income taxes for the three months ended September 30, 2019 was comprised of U.S. federal and state taxes, withholding taxes, and foreign taxes that were $32.7 million, which were offset by excess tax benefits from stock-based compensation expense of $6.9 million.

[0001262039-20-000067:mdna:130]
[same as prior period, unchanged from 0001262039-20-000053:mdna:162]

[0001262039-20-000067:mdna:131]
[same as prior period, unchanged from 0001262039-20-000053:mdna:115]

[0001262039-20-000067:mdna:132]
Nine Months Ended September 30, 2020 and September 30, 2019

[0001262039-20-000067:mdna:133]
[same as prior period, unchanged from 0001262039-20-000053:mdna:117]

[0001262039-20-000067:mdna:134]
|  | Nine Months Ended |  |  |  |  |
| September 30,2020 |  | September 30,2019 |  |  |  |  |
| Amount |  | % ofRevenue |  | Amount |  | % ofRevenue |  | Change |  | % Change |
| (in millions, except percentages) |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 628.0 |  |  | 34 | % |  | $ | 549.7 |  |  | 36 | % |  | $ | 78.3 |  |  | 14 | % |
| Service | 1,218.4 |  |  | 66 |  |  | 995.2 |  |  | 64 |  |  | 223.2 |  |  | 22 |  |
| Total revenue | $ | 1,846.4 |  |  | 100 | % |  | $ | 1,544.9 |  |  | 100 | % |  | $ | 301.5 |  |  | 20 | % |
| Revenue by geography: |  |  |  |  |  |  |  |  |  |  |  |
| Americas | $ | 776.0 |  |  | 42 | % |  | $ | 668.0 |  |  | 43 | % |  | $ | 108.0 |  |  | 16 | % |
| EMEA | 693.5 |  |  | 38 |  |  | 571.1 |  |  | 37 |  |  | 122.4 |  |  | 21 |  |
| APAC | 376.9 |  |  | 20 |  |  | 305.8 |  |  | 20 |  |  | 71.1 |  |  | 23 |  |
| Total revenue | $ | 1,846.4 |  |  | 100 | % |  | $ | 1,544.9 |  |  | 100 | % |  | $ | 301.5 |  |  | 20 | % |

[0001262039-20-000067:mdna:135]
Total revenue increased by $301.5 million, or 20%, during the nine months ended September 30, 2020 compared to the same period last year. We continued to experience diversification of revenue geographically and across both customer and industry segments. Revenue from all regions grew, with EMEA contributing the largest portion of the increase on an absolute dollar basis and APAC contributing the fastest growth on a percentage basis.

[0001262039-20-000067:mdna:136]
Product revenue increased by $78.3 million, or 14%, during the nine months ended September 30, 2020 compared to the same period last year. We experienced revenue growth across many of our products due to an increase in product revenue from our FortiGate SD-WAN solutions, software licenses and our security fabric platform products.

[0001262039-20-000067:mdna:137]
Service revenue increased by $223.2 million, or 22%, during the nine months ended September 30, 2020 compared to the same period last year. FortiGuard and other security subscription and FortiCare technical support and other revenues increased by $123.9 million, or 23%, and by $99.3 million, or 22%, respectively, during the nine months ended September 30, 2020 compared to the same period last year. The increases were primarily due to the recognition of revenue from our growing deferred revenue balance related to FortiGuard and other security subscriptions and FortiCare technical support, including our customers moving to higher-tier support offerings. Of the service revenue recognized during the nine months ended September 30, 2020, 76% was included in the deferred revenue balance as of December 31, 2019.

[0001262039-20-000067:mdna:138]
[same as prior period, unchanged from 0001262039-20-000053:mdna:122]

[0001262039-20-000067:mdna:139]
|  | Nine Months Ended |  |  |  |  |
| September 30,2020 |  | September 30,2019 |  | Change |  | % Change |
| (in millions, except percentages) |
| Cost of revenue: |  |  |  |  |  |  |  |
| Product | $ | 245.0 |  |  | $ | 231.9 |  |  | $ | 13.1 |  |  | 6 | % |
| Service | 158.0 |  |  | 133.5 |  |  | 24.5 |  |  | 18 |  |
| Total cost of revenue | $ | 403.0 |  |  | $ | 365.4 |  |  | $ | 37.6 |  |  | 10 | % |
| Gross margin (%): |  |  |  |  |  |  |  |
| Product | 61.0 | % |  | 57.8 | % |  |  |  |  |
| Service | 87.0 |  |  | 86.6 |  |  |  |  |  |
| Total gross margin | 78.2 | % |  | 76.3 | % |  |  |  |  |

[0001262039-20-000067:mdna:140]
[same as prior period, unchanged from 0001262039-20-000053:mdna:177]

[0001262039-20-000067:mdna:141]
Total gross margin increased by 1.9 percentage points during the nine months ended September 30, 2020 compared to the same period last year, driven by improvements to both product and service gross margins.

[0001262039-20-000067:mdna:142]
Product gross margin increased by 3.2 percentage points during the nine months ended September 30, 2020 compared to the same period last year. Product gross margin benefited from lower direct costs of hardware as a percentage of product revenue and increased software sales. Cost of product revenue was comprised primarily of third-party contract manufacturers’ costs and the costs of materials used in production.

[0001262039-20-000067:mdna:143]
Service gross margin increased by 0.4 percentage points during the nine months ended September 30, 2020 compared to the same period last year, as our personnel costs grew more slowly than our service revenue and we experienced lower costs to replace and repair our products. Cost of service revenue was comprised primarily of personnel costs.

[0001262039-20-000067:mdna:144]
[same as prior period, unchanged from 0001262039-20-000053:mdna:128]

[0001262039-20-000067:mdna:145]
|  | Nine Months Ended |  | Change |  | % Change |
| September 30,2020 |  | September 30,2019 |  |
| Amount |  | % ofRevenue |  | Amount |  | % ofRevenue |  |
| (in millions, except percentages) |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | $ | 252.4 |  |  | 14% |  | $ | 205.9 |  |  | 13 | % |  | $ | 46.5 |  |  | 23 | % |
| Sales and marketing | 780.5 |  |  | 42 |  | 669.8 |  |  | 43 |  |  | 110.7 |  |  | 17 |  |
| General and administrative | 87.1 |  |  | 5 |  | 74.9 |  |  | 5 |  |  | 12.2 |  |  | 16 |  |
| Gain on IP matter | (39.0) |  |  | (2) |  | — |  |  | — |  |  | (39.0) |  |  | * |
| Total operating expenses | $ | 1,081.0 |  |  | 59% |  | $ | 950.6 |  |  | 62 | % |  | $ | 130.4 |  |  | 14 | % |

[0001262039-20-000067:mdna:146]
[same as prior period, unchanged from 0001262039-20-000053:mdna:130]

[0001262039-20-000067:mdna:147]
[same as prior period, unchanged from 0001262039-20-000053:mdna:131]

[0001262039-20-000067:mdna:148]
[same as prior period, unchanged from 0001262039-20-000053:mdna:132]

[0001262039-20-000067:mdna:149]
Research and development expense increased by $46.5 million, or 23%, during the nine months ended September 30, 2020 compared to the same period last year, primarily due to an increase of $37.7 million in personnel-related costs as a result of increased headcount to support the development of new products, continued enhancements to our existing products and patent creation.

[0001262039-20-000067:mdna:150]
[same as prior period, unchanged from 0001262039-20-000053:mdna:134]

[0001262039-20-000067:mdna:151]
Sales and marketing expense increased by $110.7 million, or 17%, during the nine months ended September 30, 2020 compared to the same period last year, primarily due to an increase of $128.3 million in personnel-related costs as a result of increases to sales and marketing headcount in order to drive global market share gains. This increase was offset by savings related to decreased travel and fewer in-person marketing events as a result of the COVID-19 pandemic.

[0001262039-20-000067:mdna:152]
[same as prior period, unchanged from 0001262039-20-000053:mdna:136]

[0001262039-20-000067:mdna:153]
General and administrative expense increased by $12.2 million, or 16%, during the nine months ended September 30, 2020 compared to the same period last year, primarily due to an increase in personnel-related costs of $8.1 million and an increase in the provision for expected credit losses of $1.3 million.

[0001262039-20-000067:mdna:154]
[same as prior period, unchanged from 0001262039-20-000053:mdna:138]

[0001262039-20-000067:mdna:155]
In January 2020, we entered into an agreement with a competitor in the network security industry, whereby, in February 2020, the competitor party paid us a lump sum of $50.0 million for a mutual covenant-not-to-sue for patent claims. During the nine months ended September 30, 2020, we recorded $36.0 million upfront and an additional $3.0 million in amortization of the deferred component as a gain on IP matter in our condensed consolidated statements of income. See Note 12 of the notes to condensed consolidated financial statements included in Part I, Item 1 of this Quarterly Report on Form 10-Q for additional information regarding the gain on IP matter.

[0001262039-20-000067:mdna:156]
[same as prior period, unchanged from 0001262039-20-000053:mdna:140]

[0001262039-20-000067:mdna:157]
We generated operating income of $362.4 million during the nine months ended September 30, 2020, an increase of $133.5 million, or 58%, compared to $228.9 million in the same period last year. Operating income as a percentage of revenue increased to 20% during the nine months ended September 30, 2020 compared to 15% in the same period last year. The increase in operating margin is primarily due to the $39.0 million gain on IP matter, the 1.9 percentage point improvement in gross margin and the 1.1 percentage point decrease in sales and marketing expense as a percentage of revenue.

[0001262039-20-000067:mdna:158]
Interest income—net and other expense—net

[0001262039-20-000067:mdna:159]
|  | Nine Months Ended |  |  |  |  |
| September 30,2020 |  | September 30,2019 |  | Change |  | % Change |
| (in millions, except percentages) |
| Interest income—net | $ | 15.7 |  |  | $ | 32.6 |  |  | $ | (16.9) |  |  | (52) | % |
| Other expense—net | $ | (8.1) |  |  | $ | (6.9) |  |  | $ | (1.2) |  |  | 17 | % |

[0001262039-20-000067:mdna:160]
Interest income—net decreased during the nine months ended September 30, 2020 compared to the same period last year, primarily due to lower interest rates and lower invested balances of cash, cash equivalents and investments. The lower cash, cash equivalents and investments were mainly due to our repurchases of common stock under the Repurchase Program during the past twelve months. The change in other expense—net during the nine months ended September 30, 2020 compared to the same period last year was the result of a $4.3 million impairment charge on an investment in a privately held company during the first quarter of 2020 compared to a $3.8 million impairment charge on an investment in a privately held company during the third quarter of 2019 . In addition, foreign currency exchange losses increased by $1.0 million compared to the same period last year.

[0001262039-20-000067:mdna:161]
[same as prior period, unchanged from 0001262039-20-000053:mdna:147]

[0001262039-20-000067:mdna:162]
|  | Nine Months Ended |  | Change |  | % Change |
| September 30,2020 |  | September 30,2019 |  |
| (in millions, except percentages) |
| Provision for income taxes | $ | 28.2 |  |  | $ | 41.1 |  |  | $ | (12.9) |  |  | (31) | % |
| Effective tax rate (%) | 8 | % |  | 16 | % |  |  |  |  |

[0001262039-20-000067:mdna:163]
Our effective tax rate was 8% for the nine months ended September 30, 2020 compared to an effective tax rate of 16% for the same period last year. The provision for income taxes for the nine months ended September 30, 2020 was primarily comprised of U.S. federal and state taxes, withholding taxes and foreign taxes that were $74.8 million, which included a tax benefit of $25.6 million from the foreign-derived intangible income deduction. This tax provision for income taxes was favorably affected by excess tax benefits from stock-based compensation expense of $37.6 million and release of reserves of $9.0 million on uncertain tax positions and the interest due to the expiration of the statute of limitations.

[0001262039-20-000067:mdna:164]
The provision for income taxes for the nine months ended September 30, 2019 was comprised of U.S. federal and state taxes, withholding taxes, and foreign taxes that were $75.4 million, which were offset by excess tax benefits from stock-based compensation expense of $34.6 million and release of reserves of $10.0 million on uncertain tax positions and the interest due to the expiration of the statute of limitations. This tax provision for income taxes was further impacted by an increase in tax expense of $10.3 million for an unrecognized tax benefit related to the Ninth Circuit’s Altera decision, regarding stock-based compensation expense in cost sharing arrangements.

[0001262039-20-000067:mdna:165]
[same as prior period, unchanged from 0001262039-20-000053:mdna:152]

[0001262039-20-000067:mdna:166]
|  | As of |
|  | September 30,2020 |  | December 31,2019 |
|  | (in millions) |
| Cash and cash equivalents | $ | 882.3 |  |  | $ | 1,222.5 |  |
| Investments | 892.3 |  |  | 987.4 |  |
| Total cash, cash equivalents and investments | $ | 1,774.6 |  |  | $ | 2,209.9 |  |
| Working capital | $ | 739.0 |  |  | $ | 1,313.2 |  |
|  | Nine Months Ended |
|  | September 30,2020 |  | September 30,2019 |
|  | (in millions) |
| Net cash provided by operating activities | $ | 787.2 |  |  | $ | 617.6 |  |
| Net cash used in investing activities | (7.8) |  |  | (402.7) |  |
| Net cash used in financing activities | (1,119.6) |  |  | (151.8) |  |
| Net increase (decrease) in cash and cash equivalents | $ | (340.2) |  |  | $ | 63.1 |  |

[0001262039-20-000067:mdna:167]
Liquidity and capital resources may be impacted by our operating activities, as well as by our stock repurchases, proceeds from the issuance of common stock under our the Amended and Restated Fortinet, Inc. 2009 Equity Incentive Plan (the “Amended Plan”) and payment of taxes in connection with the net settlement of equity awards, real estate and other capital expenditures and business acquisitions.

[0001262039-20-000067:mdna:168]
[same as prior period, unchanged from 0001262039-20-000053:mdna:155]

[0001262039-20-000067:mdna:169]
In February 2020, we received a cash payment of $50.0 million pursuant to a mutual covenant-not-to-sue and release agreement with a competitor in the network security industry.

[0001262039-20-000067:mdna:170]
In July 2020, our board of directors approved a $500.0 million increase in the authorized stock repurchase amount under the Repurchase Program and extended the term of the Repurchase Program to February 28, 2022, bringing the aggregate amount authorized to be repurchased to $3.0 billion. During the nine months ended September 30, 2020, we repurchased $1.05 billion in shares of our common stock under the Repurchase Program. As of September 30, 2020, $1.05 billion remained available for future share repurchases under the Repurchase Program.

[0001262039-20-000067:mdna:171]
Construction of a second building at our headquarters campus started in the fourth quarter of 2018 and related spending will continue in 2020 and until project completion. We estimate 2020 spending on the headquarters campus project to be between $95.0 million and $105.0 million dollars. The COVID-19 pandemic has resulted in a delay to the project schedule. We estimate construction to be completed in the first half of 2021.

[0001262039-20-000067:mdna:172]
As of September 30, 2020, our cash, cash equivalents and investments of $1.77 billion were invested primarily in deposit accounts, money market funds, corporate debt securities, commercial paper, certificates of deposit and term deposits and U.S. government securities. It is our investment policy to invest excess cash in a manner that preserves capital, provides

[0001262039-20-000067:mdna:173]
41

[0001262039-20-000067:mdna:174]
liquidity and generates return without significantly increasing risk. We do not enter into investments for trading or speculative purposes.

[0001262039-20-000067:mdna:175]
The amount of cash, cash equivalents and investments held by our international subsidiaries was $121.9 million as of September 30, 2020 and $109.3 million as of December 31, 2019.

[0001262039-20-000067:mdna:176]
We believe that our existing cash and cash equivalents will be sufficient to meet our anticipated cash needs for at least the next 12 months. Our future capital requirements will depend on many factors, including our growth rate, the timing and amount of our share repurchases, the expansion of sales and marketing activities, the introduction of new and enhanced products and services offerings, the continuing market acceptance of our products, the timing and extent of spending to support development efforts, our investments in purchasing or leasing real estate and macroeconomic impacts such as the COVID-19 pandemic. Historically, we have required capital principally to fund our working capital needs, share repurchases, capital expenditures and acquisition activities. In the event that additional financing is required from outside sources, we may not be able to raise it on terms acceptable to us or at all.

[0001262039-20-000067:mdna:177]
[same as prior period, unchanged from 0001262039-20-000053:mdna:164]

[0001262039-20-000067:mdna:178]
[same as prior period, unchanged from 0001262039-20-000053:mdna:165]

[0001262039-20-000067:mdna:179]
Our operating activities during the nine months ended September 30, 2020 provided cash flows of $787.2 million. Changes in operating assets and liabilities primarily resulted from an increase in sales of our FortiGuard and other security subscription services and FortiCare technical support services to new and existing customers, as reflected by an increase in our deferred revenue, and proceeds from the mutual covenant-not-to-sue and release agreement. Our total deferred revenue balance grew $282.9 million, or 13%, during the nine months ended September 30, 2020.

[0001262039-20-000067:mdna:180]
[same as prior period, unchanged from 0001262039-20-000053:mdna:167]

[0001262039-20-000067:mdna:181]
[same as prior period, unchanged from 0001262039-20-000053:mdna:168]

[0001262039-20-000067:mdna:182]
During the nine months ended September 30, 2020, cash used in investing activities was $7.8 million, primarily driven by $93.6 million of purchases of property and equipment, a large portion of which relates to our headquarters building construction, and $9.2 million used for the OPAQ acquisition, net of cash acquired, and partially offset by $95.4 million in cash proceeds from maturities and sales of investments, net of purchases of investments.

[0001262039-20-000067:mdna:183]
[same as prior period, unchanged from 0001262039-20-000053:mdna:170]

[0001262039-20-000067:mdna:184]
[same as prior period, unchanged from 0001262039-20-000053:mdna:171]

[0001262039-20-000067:mdna:185]
During the nine months ended September 30, 2020, cash used in financing activities was $1.12 billion, primarily driven by $1.05 billion used to repurchase shares of our common stock, $68.3 million used to pay tax withholding, net of proceeds from the issuance of common stock and $4.1 million used to pay debt assumed in connection with the OPAQ acquisition.

[0001262039-20-000067:mdna:186]
[same as prior period, unchanged from 0001262039-20-000053:mdna:173]

[0001262039-20-000067:mdna:187]
There were no material changes outside the ordinary course of business during the nine months ended September 30, 2020 to the contractual obligations and commitments disclosed in Management’s Discussion and Analysis of Financial Condition and Results of Operations, set forth in Part II, Item 7, of the Form 10-K. See Note 13 of the notes to condensed

[0001262039-20-000067:mdna:188]
42

[0001262039-20-000067:mdna:189]
consolidated financial statements included in Part I, Item 1 of this Quarterly Report on Form 10-Q for additional information regarding contractual obligations and commitments.

[0001262039-20-000067:mdna:190]
[same as prior period, unchanged from 0001262039-20-000053:mdna:175]

[0001262039-20-000067:mdna:191]
As of September 30, 2020, we did not have any relationships with unconsolidated organizations or financial partnerships, such as structured finance or special purpose entities that would have been established for the purpose of facilitating off-balance sheet arrangements or other contractually narrow or limited purposes.
