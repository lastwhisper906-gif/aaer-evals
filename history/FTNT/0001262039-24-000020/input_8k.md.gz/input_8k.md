# FTNT 8-K — 0001262039-24-000017 filed 2024-05-02

## item codes, every 8-K on or before 2024-05-06

- 2024-05-02 0001262039-24-000017 — 2.02, 9.01
- 2024-02-23 0001262039-24-000011 — 5.02, 9.01
- 2024-02-06 0001262039-24-000006 — 2.02, 9.01
- 2024-01-18 0001262039-24-000003 — 5.02
- 2023-12-01 0001262039-23-000041 — 5.02
- 2023-11-02 0001262039-23-000035 — 2.02, 9.01
- 2023-08-03 0001262039-23-000027 — 2.02, 9.01
- 2023-06-23 0001262039-23-000024 — 5.03, 5.07, 9.01
- 2023-05-04 0001262039-23-000013 — 2.02, 9.01
- 2023-02-08 0001262039-23-000006 — 5.03, 9.01
- 2023-02-07 0001262039-23-000003 — 2.02, 9.01
- 2022-11-02 0001262039-22-000035 — 2.02, 9.01
- 2022-08-03 0001262039-22-000026 — 2.02, 9.01
- 2022-06-22 0001262039-22-000023 — 5.03, 9.01
- 2022-06-21 0001262039-22-000021 — 5.07
- 2022-05-04 0001262039-22-000015 — 2.02, 9.01
- 2022-05-02 0001262039-22-000012 — 5.02
- 2022-04-22 0001262039-22-000010 — 8.01
- 2022-02-03 0001262039-22-000005 — 2.02, 9.01
- 2022-01-26 0001262039-22-000002 — 5.02, 9.01 — amendment, the index does not say of what
- 2021-11-04 0001262039-21-000027 — 2.02, 9.01
- 2021-10-06 0001262039-21-000024 — 5.02, 9.01
- 2021-07-29 0001262039-21-000019 — 2.02, 9.01
- 2021-06-23 0001262039-21-000016 — 5.07
- 2021-04-30 0001104659-21-059008 — 5.03 — amendment, the index does not say of what
- 2021-04-29 0001262039-21-000011 — 2.02, 9.01
- 2021-04-28 0001104659-21-056360 — 5.02, 5.03, 9.01
- 2021-03-05 0001193125-21-071498 — 1.01, 9.01
- 2021-02-25 0001193125-21-057281 — 1.01, 9.01
- 2021-02-04 0001262039-21-000005 — 2.02, 9.01
- 2020-12-08 0001262039-20-000070 — 8.01
- 2020-10-29 0001262039-20-000063 — 2.02, 9.01
- 2020-10-20 0001262039-20-000060 — 5.02 — amendment, the index does not say of what
- 2020-08-26 0001262039-20-000056 — 5.02, 9.01
- 2020-08-06 0001262039-20-000051 — 2.02, 9.01
- 2020-07-21 0001262039-20-000044 — 5.03, 8.01, 9.01
- 2020-06-24 0001262039-20-000038 — 5.07
- 2020-05-06 0001262039-20-000029 — 2.02, 9.01
- 2020-04-23 0001262039-20-000025 — 5.03, 9.01
- 2020-04-23 0001262039-20-000024 — 5.02 — amendment of 0001262039-20-000025
- 2020-02-28 0001262039-20-000015 — 5.02, 9.01
- 2020-02-06 0001262039-20-000004 — 2.02, 9.01
- 2019-12-12 0001262039-19-000038 — 8.01
- 2019-10-31 0001262039-19-000032 — 2.02, 9.01
- 2019-10-28 0001262039-19-000027 — 8.01
- 2019-10-23 0001262039-19-000025 — 5.02, 9.01
- 2019-08-01 0001262039-19-000021 — 2.02, 9.01
- 2019-06-26 0001262039-19-000018 — 5.07
- 2019-05-02 0001262039-19-000010 — 2.02, 9.01
- 2019-02-06 0001262039-19-000002 — 2.02, 9.01
- 2018-11-01 0001262039-18-000037 — 2.02, 9.01
- 2018-10-23 0001262039-18-000035 — 8.01
- 2018-08-01 0001262039-18-000025 — 2.02, 9.01
- 2018-06-28 0001262039-18-000023 — 5.03, 5.07, 9.01
- 2018-06-04 0001262039-18-000021 — 8.01
- 2018-05-03 0001262039-18-000017 — 2.02, 5.02, 9.01
- 2018-02-05 0001262039-18-000004 — 2.02, 5.02, 9.01
- 2017-10-26 0001262039-17-000031 — 2.02, 9.01
- 2017-10-19 0001262039-17-000029 — 5.02 — amendment, the index does not say of what
- 2017-07-26 0001262039-17-000025 — 2.02, 9.01
- 2017-06-27 0001262039-17-000023 — 5.07
- 2017-05-31 0001262039-17-000021 — 5.02 — amendment of 0001262039-17-000019
- 2017-05-30 0001262039-17-000019 — 5.02, 9.01
- 2017-04-27 0001262039-17-000013 — 2.02, 9.01
- 2017-02-02 0001262039-17-000003 — 2.02, 9.01
- 2016-10-27 0001262039-16-000085 — 2.02, 9.01
- 2016-10-11 0001262039-16-000082 — 2.02, 9.01
- 2016-07-28 0001262039-16-000076 — 2.02, 9.01
- 2016-07-22 0001262039-16-000073 — 8.01, 9.01
- 2016-06-20 0001262039-16-000068 — 5.07
- 2016-06-07 0001193125-16-614788 — 8.01
- 2016-04-26 0001262039-16-000061 — 2.02, 9.01
- 2016-01-28 0001262039-16-000051 — 2.02, 9.01
- 2015-10-27 0001262039-15-000045 — 2.02
- 2015-10-22 0001262039-15-000042 — 5.02 — amendment, the index does not say of what
- 2015-10-22 0001262039-15-000041 — 5.02 — amendment, the index does not say of what
- 2015-10-22 0001262039-15-000039 — 2.02, 9.01
- 2015-09-28 0001262039-15-000034 — 5.02, 9.01
- 2015-09-22 0001262039-15-000031 — 9.01 — amendment of 0001193125-15-248065
- 2015-08-28 0001262039-15-000027 — 3.01, 5.02
- 2015-07-23 0001262039-15-000021 — 5.02
- 2015-07-22 0001262039-15-000019 — 2.02, 9.01
- 2015-07-08 0001193125-15-248065 — 2.01, 8.01, 9.01
- 2015-06-22 0001193125-15-229099 — 5.07
- 2015-06-19 0001193125-15-228428 — 5.02, 9.01
- 2015-04-20 0001262039-15-000014 — 2.02, 9.01
- 2015-01-28 0001262039-15-000005 — 2.02, 9.01
- 2014-10-22 0001262039-14-000036 — 2.02, 9.01
- 2014-07-23 0001262039-14-000030 — 2.02, 9.01
- 2014-06-24 0001262039-14-000027 — 5.07
- 2014-04-23 0001262039-14-000021 — 2.02, 9.01
- 2014-04-21 0001262039-14-000018 — 5.03, 9.01
- 2014-01-29 0001262039-14-000004 — 2.02, 9.01
- 2013-12-20 0001262039-13-000061 — 5.02, 9.01
- 2013-11-27 0001262039-13-000057 — 5.02, 7.01, 9.01
- 2013-11-12 0001445305-13-002993 — 5.02
- 2013-10-23 0001262039-13-000051 — 2.02, 9.01
- 2013-07-30 0001262039-13-000039 — 2.02, 9.01
- 2013-06-25 0001262039-13-000030 — 5.07
- 2013-04-30 0001262039-13-000023 — 2.02, 9.01
- 2013-04-19 0001262039-13-000020 — 5.02, 9.01
- 2013-04-19 0001262039-13-000018 — 5.02 — amendment of 0001262039-13-000020
- 2013-04-10 0001262039-13-000016 — 2.02, 9.01
- 2013-03-26 0001262039-13-000013 — 5.02
- 2013-01-30 0001262039-13-000005 — 2.02, 9.01
- 2013-01-24 0001262039-13-000002 — 5.02, 9.01
- 2012-10-16 0001262039-12-000048 — 2.02, 9.01
- 2012-10-01 0001262039-12-000045 — 5.02
- 2012-09-26 0001262039-12-000043 — 5.01
- 2012-07-25 0001262039-12-000038 — 2.02, 9.01
- 2012-07-19 0001262039-12-000034 — 5.02
- 2012-06-20 0001193125-12-275869 — 5.07
- 2012-04-27 0001262039-12-000029 — 5.02
- 2012-04-24 0001262039-12-000025 — 2.02, 9.01
- 2012-01-31 0001262039-12-000006 — 2.02, 9.01
- 2012-01-25 0001262039-12-000003 — 5.03
- 2011-10-24 0001262039-11-000036 — 2.02
- 2011-07-19 0001262039-11-000014 — 2.02, 9.01
- 2011-06-27 0001193125-11-174474 — 5.02, 5.07, 9.01
- 2011-04-27 0001193125-11-111938 — 2.02, 9.01
- 2011-01-25 0001193125-11-013914 — 2.02, 9.01
- 2010-10-21 0001193125-10-233676 — 2.02, 9.01
- 2010-09-02 0001193125-10-203099 — 8.01
- 2010-07-22 0001193125-10-163844 — 2.02, 9.01
- 2010-06-24 0001193125-10-146082 — 5.07
- 2010-04-28 0001193125-10-096698 — 2.02, 9.01
- 2010-02-09 0001193125-10-024614 — 8.01
- 2010-01-27 0001193125-10-014292 — 2.02, 9.01
- 2010-01-26 0001193125-10-013031 — 5.02, 9.01

## late-filing notifications on or before 2024-05-06

- none on or before 2024-05-06

## item 2.02 — earnings release, exhibit 99.1

[0001262039-24-000017:8k_2_02:1]
EX-99.1
2
ftntq1-2024ex991.htm
PRESS RELEASE

[0001262039-24-000017:8k_2_02:2]
Document

[0001262039-24-000017:8k_2_02:3]
Press Release

[0001262039-24-000017:8k_2_02:4]
Fortinet Reports First Quarter 2024 Financial Results

[0001262039-24-000017:8k_2_02:5]
First Quarter 2024 Highlights

[0001262039-24-000017:8k_2_02:6]
•Total revenue of $1.35 billion, up 7% year over year

[0001262039-24-000017:8k_2_02:7]
•Service revenue of $944 million, up 24% year over year

[0001262039-24-000017:8k_2_02:8]
•GAAP operating margin of 23.7%

[0001262039-24-000017:8k_2_02:9]
•Non-GAAP operating margin of 28.5%1

[0001262039-24-000017:8k_2_02:10]
•Cash flow from operations of $830 million

[0001262039-24-000017:8k_2_02:11]
•Free cash flow of $609 million1

[0001262039-24-000017:8k_2_02:12]
SUNNYVALE, Calif. - May 2, 2024 - Fortinet® (Nasdaq: FTNT), a global cybersecurity leader driving the convergence of networking and security, today announced financial results for the first quarter ended March 31, 2024.

[0001262039-24-000017:8k_2_02:13]
“We are diligently executing on our strategy announced six months ago to leverage our scale, go-to-market capabilities, customer-first focus, and engineering expertise to capitalize on the fast-growing Unified SASE and Security Operations markets while continuing to gain market share in Secure Networking,” said Ken Xie, Founder, Chairman and Chief Executive Officer of Fortinet. “We believe our Unified SASE offering is the most comprehensive in the industry and we are well-positioned to lead in our three core growth areas by leveraging our expertise in converging networking and security, our history of AI innovation, and our ability to integrate products across our FortiOS operating system. We’re pleased to have executed with strong financial discipline in the first quarter leading to outperforming on Non-GAAP operating margin and free cash flow.”

[0001262039-24-000017:8k_2_02:14]
Financial Highlights for the First Quarter of 2024

[0001262039-24-000017:8k_2_02:15]
•Revenue: Total revenue was $1.35 billion for the first quarter of 2024, an increase of 7.2% compared to $1.26 billion for the same quarter of 2023.

[0001262039-24-000017:8k_2_02:16]
•Product Revenue: Product revenue was $408.9 million for the first quarter of 2024, a decrease of 18.3% compared to $500.7 million for the same quarter of 2023.

[0001262039-24-000017:8k_2_02:17]
•Service Revenue: Service revenue was $944.4 million for the first quarter of 2024, an increase of 24.0% compared to $761.6 million for the same quarter of 2023.

[0001262039-24-000017:8k_2_02:18]
•Billings1: Total billings were $1.41 billion for the first quarter of 2024, a decrease of 6.4% compared to $1.50 billion for the same quarter of 2023.

[0001262039-24-000017:8k_2_02:19]
•Deferred Revenue: Total deferred revenue was $5.79 billion as of March 31, 2024, an increase of 18.6% compared to $4.88 billion as of March 31, 2023.

[0001262039-24-000017:8k_2_02:20]
•GAAP Operating Income and Margin: GAAP operating income was $321.2 million for the first quarter of 2024, representing a GAAP operating margin of 23.7%. GAAP operating income was $273.5 million for the same quarter of 2023, representing a GAAP operating margin of 21.7%.

[0001262039-24-000017:8k_2_02:21]
•Non-GAAP Operating Income and Margin1: Non-GAAP operating income was $386.1 million for the first quarter of 2024, representing a non-GAAP operating margin of 28.5%. Non-GAAP operating income was $334.0 million for the same quarter of 2023, representing a non-GAAP operating margin of 26.5%.

[0001262039-24-000017:8k_2_02:22]
•GAAP Net Income and Diluted Net Income Per Share: GAAP net income was $299.3 million for the first quarter of 2024, compared to GAAP net income of $247.7 million for the same quarter of 2023. GAAP diluted net income per share was $0.39 for the first quarter of 2024, based on 770.5 million diluted weighted-average shares outstanding, compared to GAAP diluted net income per share of $0.31 for the same quarter of 2023, based on 793.4 million diluted weighted-average shares outstanding.

[0001262039-24-000017:8k_2_02:23]
•Non-GAAP Net Income and Diluted Net Income Per Share1: Non-GAAP net income was $333.9 million for the first quarter of 2024, compared to non-GAAP net income of $269.7 million for the same quarter of 2023. Non-GAAP diluted net income per share was $0.43 for the first quarter of 2024, based on 770.5 million diluted weighted-average shares outstanding, compared to $0.34 for the same quarter of 2023, based on 793.4 million diluted weighted-average shares outstanding.

[0001262039-24-000017:8k_2_02:24]
•Cash Flow: Cash flow from operations was $830.4 million for the first quarter of 2024, compared to $677.5 million for the same quarter of 2023.

[0001262039-24-000017:8k_2_02:25]
•Free Cash Flow1: Free cash flow was $608.5 million for the first quarter of 2024, compared to $647.2 million for the same quarter of 2023.

[0001262039-24-000017:8k_2_02:26]
Guidance

[0001262039-24-000017:8k_2_02:27]
For the second quarter of 2024, Fortinet currently expects:

[0001262039-24-000017:8k_2_02:28]
•Revenue in the range of $1.375 billion to $1.435 billion

[0001262039-24-000017:8k_2_02:29]
•Billings in the range of $1.490 billion to $1.550 billion

[0001262039-24-000017:8k_2_02:30]
•Non-GAAP gross margin in the range of 76.50% to 77.50%

[0001262039-24-000017:8k_2_02:31]
•Non-GAAP operating margin in the range of 25.75% to 26.75%

[0001262039-24-000017:8k_2_02:32]
•Diluted non-GAAP net income per share in the range of $0.39 to $0.41, assuming a non-GAAP effective tax rate of 17%. This assumes a diluted share count of 775 million to 785 million.

[0001262039-24-000017:8k_2_02:33]
For the fiscal year 2024, Fortinet currently expects:

[0001262039-24-000017:8k_2_02:34]
•Revenue in the range of $5.745 billion to $5.845 billion

[0001262039-24-000017:8k_2_02:35]
•Service revenue in the range of $3.940 billion to $3.990 billion

[0001262039-24-000017:8k_2_02:36]
•Billings in the range of $6.400 billion to $6.600 billion

[0001262039-24-000017:8k_2_02:37]
•Non-GAAP gross margin in the range of 76.50% to 78.00%

[0001262039-24-000017:8k_2_02:38]
•Non-GAAP operating margin in the range of 26.50% to 28.00%

[0001262039-24-000017:8k_2_02:39]
•Diluted non-GAAP net income per share in the range of $1.73 to $1.79, assuming a non-GAAP effective tax rate of 17%. This assumes a diluted share count of 780 million to 790 million.

[0001262039-24-000017:8k_2_02:40]
Our guidance with respect to non-GAAP financial measures excludes stock-based compensation, amortization of acquired intangible assets and gain on intellectual property matters. We have not reconciled our guidance with respect to non-GAAP financial measures to the corresponding GAAP measures because certain items that impact these measures are uncertain or out of our control, or cannot be reasonably predicted. Accordingly, a reconciliation of these non-GAAP financial measures to the corresponding GAAP measures is not available without unreasonable effort.

[0001262039-24-000017:8k_2_02:41]
1 A reconciliation of GAAP to non-GAAP measures has been provided in the financial statement tables included in this press release. An explanation of these measures is also included below under the heading “Non-GAAP Financial Measures”.

[0001262039-24-000017:8k_2_02:42]
Conference Call Details

[0001262039-24-000017:8k_2_02:43]
Fortinet will host a conference call today at 1:30 p.m. Pacific Time (4:30 p.m. Eastern Time) to discuss the earnings results. A live webcast of the conference call and supplemental slides will be accessible from the Investor Relations page of Fortinet’s website at https://investor.fortinet.com and a replay will be archived and accessible at https://investor.fortinet.com/events-and-presentations.

[0001262039-24-000017:8k_2_02:44]
Second Quarter 2024 Conference Participation Schedule:

[0001262039-24-000017:8k_2_02:45]
•J.P. Morgan Global Technology, Media and Communications Conference

[0001262039-24-000017:8k_2_02:46]
May 21, 2024

[0001262039-24-000017:8k_2_02:47]
•Bank of America Global Technology Conference

[0001262039-24-000017:8k_2_02:48]
June 5, 2024

[0001262039-24-000017:8k_2_02:49]
Members of Fortinet’s management team are expected to present at these conferences and discuss the latest company strategies and initiatives. Fortinet’s conference presentations are expected to be available via webcast on the company’s web site. To access the most updated information, pre-register and listen to the webcast of each event, please visit the Investor Presentation & Events page of Fortinet’s website at https://investor.fortinet.com/events-and-presentations. The schedule is subject to change.

[0001262039-24-000017:8k_2_02:50]
About Fortinet (www.fortinet.com)

[0001262039-24-000017:8k_2_02:51]
Fortinet (Nasdaq: FTNT) is a driving force in the evolution of cybersecurity and the convergence of networking and security. Our mission is to secure people, devices and data everywhere, and today we deliver cybersecurity everywhere our customers need it with the largest integrated portfolio of over 50 enterprise-grade products. Over half a million customers trust Fortinet’s solutions, which are among the most deployed, most patented and most validated in the industry. The Fortinet Training Institute, one of the largest and broadest training programs in the industry, is dedicated to making cybersecurity training and new career opportunities available to everyone. Collaboration with high-profile, well-respected organizations from both the public and private sectors, including CERTs, government entities, and academia, is a fundamental aspect of Fortinet’s commitment to enhance cyber resilience globally. FortiGuard Labs, Fortinet’s elite threat intelligence and research organization, develops and utilizes leading-edge machine learning and AI technologies to provide customers with timely and consistently top-rated protection and actionable threat intelligence. Learn more at https://www.fortinet.com, the Fortinet Blog or FortiGuard Labs.

[0001262039-24-000017:8k_2_02:52]
#          #          #

[0001262039-24-000017:8k_2_02:53]
Copyright © 2024 Fortinet, Inc. All rights reserved. The symbols ® and ™ denote respectively

[0001262039-24-000017:8k_2_02:54]
federally registered trademarks and common law trademarks of Fortinet, Inc., its subsidiaries and affiliates. Fortinet’s trademarks include, but are not limited to, the following: Fortinet, the Fortinet logo, FortiGate, FortiOS, FortiGuard, FortiCare, FortiAnalyzer, FortiManager, FortiASIC, FortiClient, FortiCloud, FortiMail, FortiSandbox, FortiADC, FortiAIOps, FortiAntenna, FortiAP, FortiAPCam, FortiAuthenticator, FortiCache, FortiCam, FortiCamera, FortiCarrier, FortiCASB, FortiCentral, FortiCNP, FortiConnect, FortiController, FortiConverter, FortiCWP, FortiDAST, FortiDB, FortiDDoS, FortiDeceptor, FortiDeploy, FortiDevSec, FortiEDR, FortiExplorer, FortiExtender, FortiFirewall, FortiFlex, FortiFone, FortiGSLB, FortiGuest, FortiHypervisor, FortiInsight, FortiIsolator, FortiLAN, FortiLink, FortiMonitor, FortiNAC, FortiNDR, FortiPAM, FortiPenTest, FortiPhish, FortiPoint, FortiPolicy, FortiPortal, FortiPresence, FortiProxy, FortiRecon, FortiRecorder, FortiSASE, FortiSDNConnector, FortiSIEM, FortiSMS, FortiSOAR, FortiStack, FortiSwitch, FortiTester, FortiToken, FortiTrust, FortiVoice, FortiWAN, FortiWeb, FortiWiFi, FortiWLC, FortiWLM and FortiXDR. Other trademarks belong to their respective owners. Fortinet has not independently verified statements or certifications herein attributed to third parties and Fortinet does not independently endorse such statements. Notwithstanding anything to the contrary herein, nothing herein constitutes a warranty, guarantee, contract, binding specification or other binding commitment by Fortinet or any indication of intent related to a binding commitment, and performance and other specification information herein may be unique to certain environments.

[0001262039-24-000017:8k_2_02:55]
FTNT-F

[0001262039-24-000017:8k_2_02:56]
Forward-Looking Statements

[0001262039-24-000017:8k_2_02:57]
This press release contains forward-looking statements that involve risks and uncertainties. These forward-looking statements include statements regarding any indications related to future growth and market share gains, our strategy going forward, and guidance and expectations around future financial results, including guidance and expectations for the second quarter and full year 2024, and any statements regarding our market opportunity and market size, and business momentum. Although we attempt to be accurate in making forward-looking statements, it is possible that future circumstances might differ from the assumptions on which such statements are based such that actual results are materially different from our forward-looking statements in this release. Important factors that could cause results to differ materially from the statements herein include the following: general economic risks, including those caused by economic challenges, a possible economic downturn or recession and the effects of inflation or stagflation, rising interest rates or reduced information technology spending; supply chain challenges; negative impacts from the ongoing war in Ukraine and its related macroeconomic effects and our decision to reduce operations in Russia, as well as the Israel-Hamas war; competitiveness in the security market; the dynamic nature of the security market and its products and services; specific economic risks worldwide and in different geographies, and among different customer segments; uncertainty regarding demand and increased business and renewals from existing customers; sales execution risks, including general sales execution risks and risks around closing large deals and timing of large deals; uncertainties around continued success in sales growth and market share gains; uncertainties in market opportunities and the market size; actual or perceived vulnerabilities in our supply chain, products or services, and any actual or perceived breach of our network or our customers’ networks; longer sales cycles, particularly for larger enterprise, service providers, government and other large organization customers; the effectiveness of our salesforce and failure to convert sales pipeline into final sales; risks associated with successful implementation of multiple integrated software products and other product functionality risks; risks associated with integrating acquisitions and changes in circumstances and plans associated therewith, including, among other risks, changes in plans related to product and services integrations, product and services plans and sales strategies; sales and marketing execution risks; execution risks around new product development and introductions and innovation; litigation and disputes and the potential cost, distraction and damage to sales and reputation caused thereby or by other factors; cybersecurity threats, breaches and other disruptions; market acceptance of new products and services; the ability to attract and retain personnel; changes in strategy; risks associated with management of growth; lengthy sales and implementation cycles, particularly in larger organizations; technological

[0001262039-24-000017:8k_2_02:58]
Non-GAAP Financial Measures

[0001262039-24-000017:8k_2_02:59]
We have provided in this release financial information that has not been prepared in accordance with U.S. Generally Accepted Accounting Principles (GAAP). These non-GAAP financial and liquidity measures are not based on any standardized methodology prescribed by GAAP and are not necessarily comparable to similar measures presented by other companies. We use these non-GAAP financial measures internally in analyzing our financial results and believe they are useful to investors, as a supplement to GAAP measures, in evaluating our ongoing operational performance. We believe that the use of these non-GAAP financial measures provides an additional tool for investors to use in evaluating ongoing operating results and trends and in comparing our financial results with peer companies, many of which present similar non-GAAP financial measures to investors.

[0001262039-24-000017:8k_2_02:60]
Non-GAAP financial measures should not be considered in isolation from, or as a substitute for, financial information prepared in accordance with GAAP. Investors are encouraged to review the reconciliation of these non-GAAP financial measures to their most directly comparable GAAP financial measures provided in the financial statement tables below.

[0001262039-24-000017:8k_2_02:61]
Billings (non-GAAP). We define billings as revenue recognized in accordance with GAAP plus the change in deferred revenue from the beginning to the end of the period less any deferred revenue balances acquired from business combination(s) during the period. We consider billings to be a useful metric for management and investors because billings drive current and future revenue, which is an important indicator of the health and viability of our business. There are a number of limitations related to the use of billings instead of GAAP revenue. First, billings include amounts that have not yet been recognized as revenue and are impacted by the term of security and support agreements. Second, we may calculate billings in a manner that is different from peer companies that report similar financial measures. Management accounts for these limitations by providing specific information regarding GAAP revenue and evaluating billings together with GAAP revenue.

[0001262039-24-000017:8k_2_02:62]
Free cash flow (non-GAAP). We define free cash flow as net cash provided by operating activities minus purchases of property and equipment and excluding any significant non-recurring items. We believe free cash flow to be a liquidity measure that provides useful information to management and investors about the amount of cash generated by the business

[0001262039-24-000017:8k_2_02:63]
that, after capital expenditures, can be used for strategic opportunities, including repurchasing outstanding common stock, investing in our business, making strategic acquisitions and strengthening the balance sheet. A limitation of using free cash flow rather than the GAAP measures of cash provided by or used in operating activities, investing activities, and financing activities is that free cash flow does not represent the total increase or decrease in the cash and cash equivalents balance for the period because it excludes cash flows from significant non-recurring items, investing activities other than capital expenditures and cash flows from financing activities. Management accounts for this limitation by providing information about our capital expenditures and other investing and financing activities on the face of the cash flow statement and under the caption “Management’s Discussion and Analysis of Financial Condition and Results of Operations—Liquidity and Capital Resources” in our most recent Quarterly Report on Form 10-Q and Annual Report on Form 10-K and by presenting cash flows from investing and financing activities in our reconciliation of free cash flow. In addition, it is important to note that other companies, including companies in our industry, may not use free cash flow, may calculate free cash flow in a different manner than we do or may use other financial measures to evaluate their performance, all of which could reduce the usefulness of free cash flow as a comparative measure.

[0001262039-24-000017:8k_2_02:64]
Non-GAAP operating income and operating margin. We define non-GAAP operating income as operating income plus stock-based compensation, amortization of acquired intangible assets, less gain on intellectual property matter and, when applicable, other significant non-recurring items in a given quarter. Non-GAAP operating margin is defined as non-GAAP operating income divided by GAAP revenue. We consider these non-GAAP financial measures to be useful metrics for management and investors because they exclude the items noted above so that our management and investors can compare our recurring core business operating results over multiple periods. There are a number of limitations related to the use of non-GAAP operating income instead of operating income calculated in accordance with GAAP. First, non-GAAP operating income excludes the items noted above. Second, the components of the costs that we exclude from our calculation of non-GAAP operating income may differ from the components that peer companies exclude when they report their non-GAAP results of operations. Management accounts for these limitations by providing specific information regarding the GAAP amounts excluded from non-GAAP operating income and evaluating non-GAAP operating income together with operating income calculated in accordance with GAAP.

[0001262039-24-000017:8k_2_02:65]
Non-GAAP net income and diluted net income per share. We define non-GAAP net income as net income plus the items noted above under non-GAAP operating income and operating margin. In addition, we adjust non-GAAP net income and diluted net income per share for a tax adjustment required for an effective tax rate on a non-GAAP basis, which differs from the GAAP effective tax rate. We define non-GAAP diluted net income per share as non-GAAP net income divided by the non-GAAP diluted weighted-average shares outstanding. We consider these non-GAAP financial measures to be useful metrics for management and investors for the same reasons that we use non-GAAP operating income and non-GAAP operating margin. However, in order to provide a more complete picture of our recurring core business operating results, we include in non-GAAP net income and non-GAAP diluted net income per share, the tax adjustment required resulting in an effective tax rate on a non-GAAP basis, which often differs from the GAAP tax rate. We believe the non-GAAP effective tax rates we use are reasonable estimates of normalized tax rates for our current and prior fiscal years under our global operating structure. The same limitations described above regarding our use of non-GAAP operating income and non-GAAP operating margin apply to our use of non-GAAP net income and non-GAAP diluted net income per share. We account for these limitations by providing specific information regarding the GAAP amounts excluded from non-GAAP net income and non-GAAP diluted net income per share and evaluating non-GAAP net income and non-GAAP diluted net income per share together with net income and diluted net income per share calculated in accordance with GAAP.

[0001262039-24-000017:8k_2_02:66]
FORTINET, INC.

[0001262039-24-000017:8k_2_02:67]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001262039-24-000017:8k_2_02:68]
(Unaudited, in millions)

[0001262039-24-000017:8k_2_02:69]
|  | March 31,2024 |  | December 31,2023 |
| ASSETS |  |  |  |
| CURRENT ASSETS: |  |  |  |
| Cash and cash equivalents | $ | 1,926.3 |  |  | $ | 1,397.9 |  |
| Short-term investments | 1,075.4 |  |  | 1,021.5 |  |
| Marketable equity securities | 21.4 |  |  | 21.0 |  |
| Accounts receivable—net | 996.2 |  |  | 1,402.0 |  |
| Inventory | 439.5 |  |  | 484.8 |  |
| Prepaid expenses and other current assets | 100.9 |  |  | 101.1 |  |
| Total current assets | 4,559.7 |  |  | 4,428.3 |  |
| PROPERTY AND EQUIPMENT—NET | 1,247.4 |  |  | 1,044.4 |  |
| DEFERRED CONTRACT COSTS | 600.0 |  |  | 605.6 |  |
| DEFERRED TAX ASSETS | 942.5 |  |  | 868.8 |  |
| GOODWILL AND OTHER INTANGIBLE ASSETS—NET | 163.1 |  |  | 161.8 |  |
| OTHER ASSETS | 149.4 |  |  | 150.0 |  |
| TOTAL ASSETS | $ | 7,662.1 |  |  | $ | 7,258.9 |  |
| LIABILITIES AND STOCKHOLDERS’ DEFICIT |  |  |  |
| CURRENT LIABILITIES: |  |  |  |
| Accounts payable | $ | 135.2 |  |  | $ | 204.3 |  |
| Accrued liabilities | 538.7 |  |  | 423.7 |  |
| Accrued payroll and compensation | 214.5 |  |  | 242.3 |  |
| Deferred revenue | 2,912.0 |  |  | 2,848.7 |  |
| Total current liabilities | 3,800.4 |  |  | 3,719.0 |  |
| DEFERRED REVENUE | 2,877.9 |  |  | 2,886.3 |  |
| LONG-TERM DEBT | 992.8 |  |  | 992.3 |  |
| OTHER LIABILITIES | 128.5 |  |  | 124.7 |  |
| Total liabilities | 7,799.6 |  |  | 7,722.3 |  |
| COMMITMENTS AND CONTINGENCIES |  |  |  |
| STOCKHOLDERS’ DEFICIT: |  |  |  |
| Common stock | 0.8 |  |  | 0.8 |  |
| Additional paid-in capital | 1,448.9 |  |  | 1,416.4 |  |
| Accumulated other comprehensive loss | (24.8) |  |  | (18.9) |  |
| Accumulated deficit | (1,562.4) |  |  | (1,861.7) |  |
| Total stockholders’ deficit | (137.5) |  |  | (463.4) |  |
| TOTAL LIABILITIES AND STOCKHOLDERS’ DEFICIT | $ | 7,662.1 |  |  | $ | 7,258.9 |  |

[0001262039-24-000017:8k_2_02:70]
FORTINET, INC.

[0001262039-24-000017:8k_2_02:71]
CONDENSED CONSOLIDATED STATEMENTS OF INCOME

[0001262039-24-000017:8k_2_02:72]
(Unaudited, in millions, except per share amounts)

[0001262039-24-000017:8k_2_02:73]
|  | Three Months Ended |  |  |
|  | March 31,2024 |  | March 31,2023 |  |  |  |  |
| REVENUE: |  |  |  |  |  |  |  |
| Product | $ | 408.9 |  |  | $ | 500.7 |  |  |  |  |  |
| Service | 944.4 |  |  | 761.6 |  |  |  |  |  |
| Total revenue | 1,353.3 |  |  | 1,262.3 |  |  |  |  |  |
| COST OF REVENUE: |  |  |  |  |  |  |  |
| Product | 182.8 |  |  | 193.6 |  |  |  |  |  |
| Service | 121.9 |  |  | 114.2 |  |  |  |  |  |
| Total cost of revenue | 304.7 |  |  | 307.8 |  |  |  |  |  |
| GROSS PROFIT: |  |  |  |  |  |  |  |
| Product | 226.1 |  |  | 307.1 |  |  |  |  |  |
| Service | 822.5 |  |  | 647.4 |  |  |  |  |  |
| Total gross profit | 1,048.6 |  |  | 954.5 |  |  |  |  |  |
| OPERATING EXPENSES: |  |  |  |  |  |  |  |
| Research and development | 173.0 |  |  | 151.1 |  |  |  |  |  |
| Sales and marketing | 501.1 |  |  | 478.3 |  |  |  |  |  |
| General and administrative | 54.4 |  |  | 52.8 |  |  |  |  |  |
| Gain on intellectual property matter | (1.1) |  |  | (1.2) |  |  |  |  |  |
| Total operating expenses | 727.4 |  |  | 681.0 |  |  |  |  |  |
| OPERATING INCOME | 321.2 |  |  | 273.5 |  |  |  |  |  |
| INTEREST INCOME | 32.2 |  |  | 20.6 |  |  |  |  |  |
| INTEREST EXPENSE | (5.1) |  |  | (5.0) |  |  |  |  |  |
| OTHER INCOME (EXPENSE)—NET | (2.9) |  |  | 2.0 |  |  |  |  |  |
| INCOME BEFORE INCOME TAXES AND LOSS FROM EQUITY METHOD INVESTMENTS | 345.4 |  |  | 291.1 |  |  |  |  |  |
| PROVISION FOR INCOME TAXES | 39.5 |  |  | 21.3 |  |  |  |  |  |
| LOSS FROM EQUITY METHOD INVESTMENTS | (6.6) |  |  | (22.1) |  |  |  |  |  |
| NET INCOME | $ | 299.3 |  |  | $ | 247.7 |  |  |  |  |  |
| Net income per share: |  |  |  |  |  |  |  |
| Basic | $ | 0.39 |  |  | $ | 0.32 |  |  |  |  |  |
| Diluted | $ | 0.39 |  |  | $ | 0.31 |  |  |  |  |  |
| Weighted-average shares outstanding: |  |  |  |  |  |  |  |
| Basic | 762.4 |  |  | 783.2 |  |  |  |  |  |
| Diluted | 770.5 |  |  | 793.4 |  |  |  |  |  |

[0001262039-24-000017:8k_2_02:74]
FORTINET, INC.

[0001262039-24-000017:8k_2_02:75]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001262039-24-000017:8k_2_02:76]
(Unaudited, in millions)

[0001262039-24-000017:8k_2_02:77]
|  | Three Months Ended |
|  | March 31,2024 |  | March 31,2023 |
| CASH FLOWS FROM OPERATING ACTIVITIES: |  |  |  |
| Net income | $ | 299.3 |  |  | $ | 247.7 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |
| Stock-based compensation | 62.3 |  |  | 56.3 |  |
| Amortization of deferred contract costs | 72.0 |  |  | 62.5 |  |
| Depreciation and amortization | 28.6 |  |  | 27.5 |  |
| Amortization of investment discounts | (12.2) |  |  | (0.3) |  |
| Loss from equity method investments | 6.6 |  |  | 22.1 |  |
| Other | 3.3 |  |  | 3.8 |  |
| Changes in operating assets and liabilities, net of impact of business combination: |  |  |  |
| Accounts receivable—net | 405.6 |  |  | 171.1 |  |
| Inventory | 36.5 |  |  | (45.3) |  |
| Prepaid expenses and other current assets | (0.1) |  |  | (16.0) |  |
| Deferred contract costs | (66.5) |  |  | (81.2) |  |
| Deferred tax assets | (73.9) |  |  | (81.1) |  |
| Other assets | (6.2) |  |  | 4.5 |  |
| Accounts payable | (61.6) |  |  | (4.1) |  |
| Accrued liabilities | 105.0 |  |  | 80.0 |  |
| Accrued payroll and compensation | (27.4) |  |  | (6.0) |  |
| Other liabilities | 4.3 |  |  | (4.7) |  |
| Deferred revenue | 54.8 |  |  | 240.7 |  |
| Net cash provided by operating activities | 830.4 |  |  | 677.5 |  |
| CASH FLOWS FROM INVESTING ACTIVITIES: |  |  |  |
| Purchases of investments | (436.1) |  |  | (207.2) |  |
| Maturities of investments | 393.4 |  |  | 195.0 |  |
| Purchases of property and equipment | (221.9) |  |  | (30.3) |  |
| Payments made in connection with business combination, net of cash acquired | (5.7) |  |  | — |  |
| Other | — |  |  | 0.1 |  |
| Net cash used in investing activities | (270.3) |  |  | (42.4) |  |
| CASH FLOWS FROM FINANCING ACTIVITIES: |  |  |  |
| Proceeds from issuance of common stock | 13.4 |  |  | 21.2 |  |
| Taxes paid related to net share settlement of equity awards | (42.9) |  |  | (34.5) |  |
| Other | (0.8) |  |  | (0.4) |  |
| Net cash used in financing activities | (30.3) |  |  | (13.7) |  |
| EFFECT OF EXCHANGE RATE CHANGES ON CASH AND CASH EQUIVALENTS | (1.4) |  |  | (0.1) |  |
| NET INCREASE IN CASH AND CASH EQUIVALENTS | 528.4 |  |  | 621.3 |  |
| CASH AND CASH EQUIVALENTS—Beginning of period | 1,397.9 |  |  | 1,682.9 |  |
| CASH AND CASH EQUIVALENTS—End of period | $ | 1,926.3 |  |  | $ | 2,304.2 |  |

[0001262039-24-000017:8k_2_02:78]
Reconciliations of non-GAAP results of operations measures to the nearest comparable GAAP measures

[0001262039-24-000017:8k_2_02:79]
(Unaudited, in millions, except per share amounts)

[0001262039-24-000017:8k_2_02:80]
Reconciliation of GAAP operating income to non-GAAP operating income, operating margin, net income and diluted net income per share

[0001262039-24-000017:8k_2_02:81]
|  | Three Months Ended |  |  |
|  | March 31,2024 |  | March 31,2023 |  |  |  |  |
| Reconciliation of non-GAAP operating income: |  |  |  |  |  |  |  |
| GAAP operating income | $ | 321.2 |  |  | $ | 273.5 |  |  |  |  |  |
| GAAP operating margin | 23.7 | % |  | 21.7 | % |  |  |  |  |
| Add back: |  |  |  |  |  |  |  |
| Stock‐based compensation | 63.0 |  |  | 57.0 |  |  |  |  |  |
| Amortization of acquired intangible assets | 3.0 |  |  | 4.7 |  |  |  |  |  |
| Gain on intellectual property matter | (1.1) |  |  | (1.2) |  |  |  |  |  |
| Non‐GAAP operating income | $ | 386.1 |  |  | $ | 334.0 |  |  |  |  |  |
| Non‐GAAP operating margin | 28.5 | % |  | 26.5 | % |  |  |  |  |
| Reconciliation of non-GAAP net income: |  |  |  |  |  |  |  |
| GAAP net income | $ | 299.3 |  |  | $ | 247.7 |  |  |  |  |  |
| Add back: |  |  |  |  |  |  |  |
| Stock‐based compensation | 63.0 |  |  | 57.0 |  |  |  |  |  |
| Amortization of acquired intangible assets | 3.0 |  |  | 4.7 |  |  |  |  |  |
| Gain on intellectual property matter | (1.1) |  |  | (1.2) |  |  |  |  |  |
| Tax adjustment (a) | (30.3) |  |  | (38.5) |  |  |  |  |  |
| Non-GAAP net income | $ | 333.9 |  |  | $ | 269.7 |  |  |  |  |  |
| Non-GAAP net income per share, diluted |  |  |  |  |  |  |  |
| Non-GAAP net income | $ | 333.9 |  |  | $ | 269.7 |  |  |  |  |  |
| Non-GAAP shares used in diluted net income per share calculations | 770.5 |  |  | 793.4 |  |  |  |  |  |
| Non-GAAP net income per share, diluted | $ | 0.43 |  |  | $ | 0.34 |  |  |  |  |  |
| Reconciliation of non-GAAP net income per share, diluted |  |  |  |  |  |  |  |
| GAAP net income per share | $ | 0.39 |  |  | $ | 0.31 |  |  |  |  |  |
| Add back: |  |  |  |  |  |  |  |
| Non-GAAP adjustments to net income per share | 0.04 |  |  | 0.03 |  |  |  |  |  |
| Non-GAAP net income per share, diluted | $ | 0.43 |  |  | $ | 0.34 |  |  |  |  |  |

[0001262039-24-000017:8k_2_02:82]
(a) Non-GAAP financial information is adjusted to an effective tax rate of 17% in the three months ended March 31, 2024 and 2023, respectively, on a non-GAAP basis, which differs from the GAAP effective tax rate.

[0001262039-24-000017:8k_2_02:83]
Reconciliation of net cash provided by operating activities to free cash flow

[0001262039-24-000017:8k_2_02:84]
|  | Three Months Ended |
|  | March 31,2024 |  | March 31,2023 |
| Net cash provided by operating activities | $ | 830.4 |  |  | $ | 677.5 |  |
| Less: Purchases of property and equipment | (221.9) |  |  | (30.3) |  |
| Free cash flow | $ | 608.5 |  |  | $ | 647.2 |  |
| Net cash used in investing activities | $ | (270.3) |  |  | $ | (42.4) |  |
| Net cash used in financing activities | $ | (30.3) |  |  | $ | (13.7) |  |

[0001262039-24-000017:8k_2_02:85]
Reconciliation of total revenue to total billings

[0001262039-24-000017:8k_2_02:86]
|  | Three Months Ended |
|  | March 31,2024 |  | March 31,2023 |
| Total revenue | $ | 1,353.3 |  |  | $ | 1,262.3 |  |
| Add: Change in deferred revenue | 54.9 |  |  | 240.6 |  |
| Less: Deferred revenue balance acquired in business combination | (1.0) |  |  | — |  |
| Total billings | $ | 1,407.2 |  |  | $ | 1,502.9 |  |

[0001262039-24-000017:8k_2_02:87]
| Investor Contact: |  | Media Contact: |
| Peter Salkowski |  | Michelle Zimmermann |
| Fortinet, Inc. |  | Fortinet, Inc. |
| 408-331-4595 |  | 408-235-7700 |
| psalkowski@fortinet.com |  | pr@fortinet.com |
