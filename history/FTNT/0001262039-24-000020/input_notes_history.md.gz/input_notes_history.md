# FTNT note change history — 0001262039-23-000038 → 0001262039-24-000020


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2024-05-06):
[0001262039-24-000020:note_history:1]
COMMITMENTS AND CONTINGENCIES
The following table summarizes our inventory purchase commitments as of March 31, 2024 (in millions):
  (was, 2023-11-07, similarity 0.9609):
[0001262039-23-000038:note_history:1]
COMMITMENTS AND CONTINGENCIES
The following table summarizes our inventory purchase commitments as of September 30, 2023 (in millions):

- added (2024-05-06):
[0001262039-24-000020:note_history:2]
Inventory Purchase Commitments—We purchase components of our inventory from certain suppliers and use several independent contract manufacturers to provide manufacturing services for our products. During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, we enter into agreements with contract manufacturers and suppliers that allow them to procure inventory based upon criteria as defined by us or establish the parameters defining our requirements. A significant portion of our reported purchase commitments arising from these agreements consists of firm, non-cancelable and unconditional commitments. Certain of these inventory purchase commitments with contract manufacturers and suppliers relate to arrangements to secure supply and pricing for certain product components for multi-year periods. In certain instances, these agreements allow us the option to reschedule and adjust our requirements based on our business needs prior to firm orders being placed.

- added (2024-05-06):
[0001262039-24-000020:note_history:3]
As of March 31, 2024, we had $629.7 million of non-cancelable inventory purchase commitments with our independent contract manufacturers. We recorded a liability for these purchase commitments for quantities in excess of our future estimated demand forecasts, consistent with the valuation of our excess and obsolete inventory. As of March 31, 2024 and December 31, 2023, the liability for these inventory purchase commitments was $115.0 million and $84.7 million, respectively, and was recorded in accrued liabilities on our condensed consolidated balance sheets. The expense related to such accrued liability for inventory purchase commitments was $31.6 million and $10.4 million during the three months ended March 31, 2024 and 2023, respectively, and was recorded in cost of product revenue on the condensed consolidated statements of income.

- changed (2024-05-06):
[0001262039-24-000020:note_history:4]
Other Contractual Commitments and Open Purchase Orders—In addition to commitments with contract manufacturers, we have open purchase orders and contractual obligations in the ordinary course of business for which we have not received goods or services. A significant portion of our reported purchase commitments consist of non-cancelable commitments. In certain instances, contractual commitments allow us the option to cancel, reschedule and adjust our requirements based on our business needs prior to firm orders being placed. As of March 31, 2024, we had $40.4 million in other contractual commitments having a remaining term in excess of one year that are non-cancelable.
  (was, 2023-11-07, similarity 0.9895):
[0001262039-23-000038:note_history:4]
Other Contractual Commitments and Open Purchase Orders—In addition to commitments with contract manufacturers, we have open purchase orders and contractual obligations in the ordinary course of business for which we have not received goods or services. A significant portion of our reported purchase commitments consist of non-cancelable commitments. In certain instances, contractual commitments allow us the option to cancel, reschedule and adjust our requirements based on our business needs prior to firm orders being placed. As of September 30, 2023, we had $76.8 million in other contractual commitments having a remaining term in excess of one year that are non-cancelable.

- changed (2024-05-06):
[0001262039-24-000020:note_history:5]
As of March 31, 2024, we had $89.8 million in contractual commitments related to payments for operating leases.
  (was, 2023-11-07, similarity 0.9519):
[0001262039-23-000038:note_history:5]
As of September 30, 2023, we had $89.5 million in contractual commitments related to payments for operating leases.

- changed (2024-05-06):
[0001262039-24-000020:note_history:6]
Litigation—We are involved in disputes, litigation, and other legal actions. For lawsuits where we are the defendant, we are in the process of defending these litigation matters, and while there can be no assurances and the outcome of certain of these matters is currently not determinable and not predictable, we currently are unaware of any existing claims or proceedings that we believe are likely to have a material adverse effect on our financial position. There are many uncertainties associated with any litigation and these actions or other third-party claims against us may cause us to incur costly litigation fees, costs and substantial settlement charges, and possibly subject us to damages and other penalties. In addition, the resolution of any intellectual property (“IP”) litigation may require us to make royalty payments, which could adversely affect our gross margins in future periods. If any of those events were to occur, our business, financial condition, results of operations, and cash flows could be adversely affected. Litigation is unpredictable and the actual liability in any such matters may be materially different from our current estimates, which could result in the need to adjust any accrued liability and record additional expenses. We accrue for contingencies when we believe that a loss is probable and that we can reasonably estimate the amount of any such loss. These accruals are generally based on a range of possible outcomes that require significant management judgement. If no amount within a range is a better estimate than any other, we accrue the minimum amount. Litigation loss contingency accruals associated with outstanding cases were not material as of March 31, 2024, and December 31, 2023.
  (was, 2023-11-07, similarity 0.996):
[0001262039-23-000038:note_history:6]
Litigation—We are involved in disputes, litigation, and other legal actions. For lawsuits where we are the defendant, we are in the process of defending these litigation matters, and while there can be no assurances and the outcome of certain of these matters is currently not determinable and not predictable, we currently are unaware of any existing claims or proceedings that we believe are likely to have a material adverse effect on our financial position. There are many uncertainties associated with any litigation and these actions or other third-party claims against us may cause us to incur costly litigation fees, costs and substantial settlement charges, and possibly subject us to damages and other penalties. In addition, the resolution of any intellectual property (“IP”) litigation may require us to make royalty payments, which could adversely affect our gross margins in future periods. If any of those events were to occur, our business, financial condition, results of operations, and cash flows could be adversely affected. Litigation is unpredictable and the actual liability in any such matters may be materially different from our current estimates, which could result in the need to adjust any accrued liability and record additional expenses. We accrue for contingencies when we believe that a loss is probable and that we can reasonably estimate the amount of any such loss. These accruals are generally based on a range of possible outcomes that require significant management judgement. If no amount within a range is a better estimate than any other, we accrue the minimum amount. Litigation loss contingency accruals associated with outstanding cases were not material as of September 30, 2023, and December 31, 2022.

- added (2024-05-06):
[0001262039-24-000020:note_history:7]
On March 21, 2019, we were sued by Alorica Inc. (“Alorica”) in Santa Clara County Superior Court in California. Alorica has alleged breach of warranty and misrepresentation claims, which we deny. Fact discovery closed during the quarter ended June 30, 2023 and trial is currently set for September 2024. Although we believe that the ultimate outcome of this matter will not materially impact our financial position, results of operations or cash flows, legal proceedings are subject to inherent uncertainties, and an unfavorable ruling could occur, which may result in a material adverse impact on our business, financial position, results of operations and cash flows. No loss accrual had been recorded as of March 31, 2024 or December 31, 2023 related to this litigation.

- changed (2024-05-06):
[0001262039-24-000020:note_history:8]
Indemnification and Other Matters—Under the indemnification provisions of our standard sales contracts, we agree to defend our customers against third-party claims asserting various allegations such as product defects and infringement of certain IP rights, which may include patents, copyrights, trademarks or trade secrets, and to pay judgments entered on such claims. In some contracts, our exposure under these indemnification provisions is limited by the terms of the contracts to certain defined limits, such as the total amount paid by our customer under the agreement. However, certain agreements include covenants, penalties and indemnification provisions including and beyond indemnification for third-party claims of IP infringement that could potentially expose us to losses in excess of the amount received under the agreement, and in some instances to potential liability that is not contractually limited. Although from time to time there are indemnification claims
  (was, 2023-11-07, similarity 0.9253):
[0001262039-23-000038:note_history:8]
Indemnification and Other Matters—Under the indemnification provisions of our standard sales contracts, we agree to defend our customers against third-party claims asserting various allegations such as product defects and infringement of certain IP rights, which may include patents, copyrights, trademarks or trade secrets, and to pay judgments entered on such claims. In some contracts, our exposure under these indemnification provisions is limited by the terms of the contracts to certain defined limits, such as the total amount paid by our customer under the agreement. However, certain agreements include covenants, penalties and indemnification provisions including and beyond indemnification for third-party claims of IP infringement that could potentially expose us to losses in excess of the amount received under the agreement, and in some instances to potential liability that is not contractually limited. Although from time to time there are indemnification claims asserted against us and currently there are pending indemnification claims, to date there have been no material awards under such indemnification provisions.

- added (2024-05-06):
[0001262039-24-000020:note_history:9]
asserted against us and currently there are pending indemnification claims, to date there have been no material awards under such indemnification provisions.

- removed (2024-05-06):
[0001262039-23-000038:note_history:10]
Inventory Purchase Commitments—Our independent contract manufacturers and certain component suppliers procure components and build our products based on our forecasts, the availability of various components and their capacity. These forecasts are based on estimates of future demand for our products, which are in turn based on historical trends and an analysis from our sales and marketing organizations, adjusted for lead times, changes in supplier delivery commitments and other supply chain matters and market conditions. In order to manage manufacturing lead times, plan for adequate component supply and incentivize suppliers to deliver, we may issue purchase orders to some of our independent contract manufacturers, which are non-cancelable. As of September 30, 2023, we had $820.6 million of open purchase orders with our independent contract manufacturers that consist of non-cancelable commitments. In certain instances, these agreements allow us the option to reschedule and adjust our requirements based on our business needs prior to firm orders being placed. We recorded a liability

- removed (2024-05-06):
[0001262039-23-000038:note_history:11]
for non-cancelable inventory purchase commitments for quantities in excess of our future estimated demand forecasts, consistent with the valuation of our excess and obsolete inventory. As of September 30, 2023, the liability for these inventory purchase commitments was $64.6 million and was included in accrued liabilities. As of December 31, 2022, the liability for these purchase commitments was not material. The expense related to such accrued liability for inventory purchase commitments was $36.9 million and $59.3 million during the three and nine months ended September 30, 2023, respectively, and was recorded in product cost of revenue on the condensed consolidated statements of income.

- removed (2024-05-06):
[0001262039-23-000038:note_history:12]
On March 21, 2019, we were sued by Alorica Inc. (“Alorica”) in Santa Clara County Superior Court in California. Alorica has alleged breach of warranty and misrepresentation claims, which we deny. Fact discovery closed during the quarter ended June 30, 2023. Although we believe that the ultimate outcome of this matter will not materially impact our financial position, results of operations or cash flows, legal proceedings are subject to inherent uncertainties, and an unfavorable ruling could occur, which may result in a material adverse impact on our business, financial position, results of operations and cash flows. No loss accrual had been recorded as of September 30, 2023 or December 31, 2022 related to this litigation.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2024-05-06):
[0001262039-24-000020:note_history:13]
SUMMARY OF SIGNIFICANT ACCOUNTING POLICIES
Basis of Presentation and Preparation—The unaudited condensed consolidated financial statements of Fortinet, Inc. and its subsidiaries (collectively, “we,” “us” or “our”) have been prepared in accordance with generally accepted accounting principles in the United States (“GAAP”) for interim financial information, as well as the instructions to Form 10-Q pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (the “SEC”). Accordingly, they do not include all of the information and footnotes required by GAAP for complete financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the year ended December 31, 2023, contained in our Annual Report on Form 10-K filed with the SEC on February 26, 2024. In the opinion of management, all adjustments, which include normal recurring adjustments, considered necessary for a fair presentation, have been included. The results of operations for the three months ended March 31, 2024 are not necessarily indicative of the results to be expected for the full year or for any future periods. The condensed consolidated balance sheet as of December 31, 2023 is derived from the audited consolidated financial statements for the year ended December 31, 2023.
  (was, 2023-11-07, similarity 0.9813):
[0001262039-23-000038:note_history:13]
SUMMARY OF SIGNIFICANT ACCOUNTING POLICIES
Basis of Presentation and Preparation—The unaudited condensed consolidated financial statements of Fortinet, Inc. and its subsidiaries (collectively, “we,” “us” or “our”) have been prepared in accordance with generally accepted accounting principles in the United States (“GAAP”) for interim financial information, as well as the instructions to Form 10-Q pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (the “SEC”). Accordingly, they do not include all of the information and footnotes required by GAAP for complete financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the year ended December 31, 2022, contained in our Annual Report on Form 10-K filed with the SEC on February 24, 2023. In the opinion of management, all adjustments, which include normal recurring adjustments, considered necessary for a fair presentation, have been included. The results of operations for the three and nine months ended September 30, 2023 are not necessarily indicative of the results to be expected for the full year or for any future periods. The condensed consolidated balance sheet as of December 31, 2022 is derived from the audited consolidated financial statements for the year ended December 31, 2022.

- changed (2024-05-06):
[0001262039-24-000020:note_history:14]
There have been no material changes to our significant accounting policies as of and for the three months ended March 31, 2024, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended December 31, 2023 filed with the SEC.
  (was, 2023-11-07, similarity 0.7325):
[0001262039-23-000038:note_history:14]
There have been no material changes to our significant accounting policies as of and for the three and nine months ended September 30, 2023, as compared to the significant accounting policies described in the Form 10-K.

- added (2024-05-06):
[0001262039-24-000020:note_history:15]
Recent Accounting Standards Not Yet Effective

- added (2024-05-06):
[0001262039-24-000020:note_history:16]
Segment Reporting

- added (2024-05-06):
[0001262039-24-000020:note_history:17]
In November 2023, the Financial Accounting Standards Board (the “FASB”) issued Accounting Standards Update (“ASU”) 2023-07, Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures, which is intended to improve reportable segment disclosure requirements, primarily through enhanced disclosures about significant expenses. The amendments are effective for our annual reporting for fiscal year 2024, and for our interim period reporting starting in fiscal year 2025 retrospectively, with early adoption permitted. We are currently evaluating the ASU to determine its impact on our disclosures.

- added (2024-05-06):
[0001262039-24-000020:note_history:18]
Income Taxes

- added (2024-05-06):
[0001262039-24-000020:note_history:19]
In December 2023, the FASB issued ASU 2023-09, Income Taxes (Topic 740): Improvements to Income Tax Disclosures, which includes amendments that further enhance income tax disclosures, primarily through standardization and disaggregation of rate reconciliation categories and income taxes paid by jurisdiction. The amendments are effective for our annual period beginning fiscal year 2025, with early adoption permitted, and should be applied prospectively. We are currently evaluating the ASU to determine its impact on our disclosures.

- removed (2024-05-06):
[0001262039-23-000038:note_history:20]
Amounts related to income taxes payable have been reclassified in prior periods to conform with current period presentation.

- removed (2024-05-06):
[0001262039-23-000038:note_history:21]
Recently Adopted and Recently Issued Accounting Standards

- removed (2024-05-06):
[0001262039-23-000038:note_history:22]
There were no recently adopted accounting standards which would have a material effect on our condensed consolidated financial statements and accompanying disclosures, and no recently issued accounting standards that are expected to have a material impact on our condensed consolidated financial statements and accompanying disclosures.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-05-06):
[0001262039-24-000020:note_history:23]
On March 5, 2021, we issued $1.0 billion aggregate principal amount of senior notes (collectively, the “Senior Notes”), consisting of $500.0 million aggregate principal amount of 1.0% notes due March 15, 2026 (the “2026 Senior Notes”) and $500.0 million aggregate principal amount of 2.2% notes due March 15, 2031 (the “2031 Senior Notes”), in an underwritten registered public offering. The Senior Notes are senior unsecured obligations and rank equally with each other in right of payment and with our other outstanding obligations. We may redeem the Senior Notes at any time in whole or in part for cash, at specified redemption prices that include accrued and unpaid interest, if any, and a make-whole premium. However, no make-whole premium will be paid for redemptions of the 2026 Senior Notes on or after February 15, 2026, or the 2031 Senior Notes on or after December 15, 2030. Interest on the Senior Notes is payable on March 15 and September 15 of each year, beginning on September 15, 2021. As of March 31, 2024 and December 31, 2023, the Senior Notes were recorded as long-term debt, net of discount and issuance costs, which are amortized to interest expense over the respective contractual terms of these notes using the effective interest method.
  (was, 2023-11-07, similarity 0.9941):
[0001262039-23-000038:note_history:23]
On March 5, 2021, we issued $1.0 billion aggregate principal amount of senior notes (collectively, the “Senior Notes”), consisting of $500.0 million aggregate principal amount of 1.0% notes due March 15, 2026 (the “2026 Senior Notes”) and $500.0 million aggregate principal amount of 2.2% notes due March 15, 2031 (the “2031 Senior Notes”), in an underwritten registered public offering. The Senior Notes are senior unsecured obligations and rank equally with each other in right of payment and with our other outstanding obligations. We may redeem the Senior Notes at any time in whole or in part for cash, at specified redemption prices that include accrued and unpaid interest, if any, and a make-whole premium. However, no make-whole premium will be paid for redemptions of the 2026 Senior Notes on or after February 15, 2026, or the 2031 Senior Notes on or after December 15, 2030. Interest on the Senior Notes is payable on March 15 and September 15 of each year, beginning on September 15, 2021. As of September 30, 2023 and December 31, 2022, the Senior Notes were recorded as long-term debt, net of discount and issuance costs, which are amortized to interest expense over the respective contractual terms of these notes using the effective interest method.

- changed (2024-05-06):
[0001262039-24-000020:note_history:24]
|  | Maturity |  | Coupon Rate |  | Effective Interest Rate |  | March 31,2024 |  | December 31,2023 |
| Debt |  |  |  |  |  |  |  |  |  |
| 2026 Senior Notes | March 2026 |  | 1.0% |  | 1.3% |  | $ | 500.0 |  |  | $ | 500.0 |  |
| 2031 Senior Notes | March 2031 |  | 2.2% |  | 2.3% |  | 500.0 |  |  | 500.0 |  |
| Total debt |  |  |  |  |  |  | 1,000.0 |  |  | 1,000.0 |  |
| Less: Unamortized discount and debt issuance costs |  |  |  |  |  |  | 7.2 |  |  | 7.7 |  |
| Total long-term debt |  |  |  |  |  |  | $ | 992.8 |  |  | $ | 992.3 |  |
  (was, 2023-11-07, similarity 0.9834):
[0001262039-23-000038:note_history:24]
|  | Maturity |  | Coupon Rate |  | Effective Interest Rate |  | September 30,2023 |  | December 31,2022 |
| Debt |  |  |  |  |  |  |  |  |  |
| 2026 Senior Notes | March 2026 |  | 1.0% |  | 1.3% |  | $ | 500.0 |  |  | $ | 500.0 |  |
| 2031 Senior Notes | March 2031 |  | 2.2% |  | 2.3% |  | 500.0 |  |  | 500.0 |  |
| Total debt |  |  |  |  |  |  | 1,000.0 |  |  | 1,000.0 |  |
| Less: Unamortized discount and debt issuance costs |  |  |  |  |  |  | 8.2 |  |  | 9.6 |  |
| Total long-term debt |  |  |  |  |  |  | $ | 991.8 |  |  | $ | 990.4 |  |

- added (2024-05-06):
[0001262039-24-000020:note_history:25]
As of March 31, 2024 and December 31, 2023, we accrued interest payable of $0.7 million and $4.7 million, respectively, and there are no financial covenants with which we must comply. During the three months ended March 31, 2024 and 2023, we recorded $4.5 million of total interest expense in relation to these Senior Notes in each period. No interest costs were capitalized for the three months ended March 31, 2024 and 2023, as the costs that qualified for capitalization were not material.

- added (2024-05-06):
[0001262039-24-000020:note_history:26]
The total estimated fair value of the outstanding Senior Notes was approximately $878.9 million, including accrued and unpaid interest, as of March 31, 2024. The fair value was determined based on observable market prices of identical instruments in less active markets. The estimated fair values are based on Level 2 inputs.

- removed (2024-05-06):
[0001262039-23-000038:note_history:27]
As of September 30, 2023 and December 31, 2022, we accrued interest payable of $0.7 million and $4.7 million, respectively, and there are no financial covenants with which we must comply. During the three months ended September 30, 2023 and 2022, we recorded $4.5 million and $4.4 million of total interest expense in relation to these Senior Notes in each quarter, respectively. During the nine months ended September 30, 2023 and 2022, we recorded $13.5 million and $13.4 million of total interest expense in relation to the Senior Notes in each period, respectively. No interest costs were capitalized for the nine months ended September 30, 2023 and 2022, as the costs that qualified for capitalization were not material.

- removed (2024-05-06):
[0001262039-23-000038:note_history:28]
The total estimated fair value of the outstanding Senior Notes was approximately $834.8 million, including accrued and unpaid interest, as of September 30, 2023. The fair value was determined based on observable market prices of identical instruments in less active markets. The estimated fair values are based on Level 2 inputs.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-05-06):
[0001262039-24-000020:note_history:29]
|  | Maturity |  | Coupon Rate |  | Effective Interest Rate |  | March 31,2024 |  | December 31,2023 |
| Debt |  |  |  |  |  |  |  |  |  |
| 2026 Senior Notes | March 2026 |  | 1.0% |  | 1.3% |  | $ | 500.0 |  |  | $ | 500.0 |  |
| 2031 Senior Notes | March 2031 |  | 2.2% |  | 2.3% |  | 500.0 |  |  | 500.0 |  |
| Total debt |  |  |  |  |  |  | 1,000.0 |  |  | 1,000.0 |  |
| Less: Unamortized discount and debt issuance costs |  |  |  |  |  |  | 7.2 |  |  | 7.7 |  |
| Total long-term debt |  |  |  |  |  |  | $ | 992.8 |  |  | $ | 992.3 |  |
  (was, 2023-11-07, similarity 0.9834):
[0001262039-23-000038:note_history:29]
|  | Maturity |  | Coupon Rate |  | Effective Interest Rate |  | September 30,2023 |  | December 31,2022 |
| Debt |  |  |  |  |  |  |  |  |  |
| 2026 Senior Notes | March 2026 |  | 1.0% |  | 1.3% |  | $ | 500.0 |  |  | $ | 500.0 |  |
| 2031 Senior Notes | March 2031 |  | 2.2% |  | 2.3% |  | 500.0 |  |  | 500.0 |  |
| Total debt |  |  |  |  |  |  | 1,000.0 |  |  | 1,000.0 |  |
| Less: Unamortized discount and debt issuance costs |  |  |  |  |  |  | 8.2 |  |  | 9.6 |  |
| Total long-term debt |  |  |  |  |  |  | $ | 991.8 |  |  | $ | 990.4 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2024-05-06):
[0001262039-24-000020:note_history:30]
|  | Three Months Ended |  |  |
|  | March 31,2024 |  | March 31,2023 |  |  |  |  |
| Product | $ | 408.9 |  |  | $ | 500.7 |  |  |  |  |  |
| Service: |  |  |  |  |  |  |  |
| Security subscription | 536.9 |  |  | 421.7 |  |  |  |  |  |
| Technical support and other | 407.5 |  |  | 339.9 |  |  |  |  |  |
| Total service revenue | 944.4 |  |  | 761.6 |  |  |  |  |  |
| Total revenue | $ | 1,353.3 |  |  | $ | 1,262.3 |  |  |  |  |  |
  (was, 2023-11-07, similarity 0.6518):
[0001262039-23-000038:note_history:30]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30,2023 |  | September 30,2022 |  | September 30,2023 |  | September 30,2022 |
| Product | $ | 465.9 |  |  | $ | 468.7 |  |  | $ | 1,439.2 |  |  | $ | 1,240.4 |  |
| Service: |  |  |  |  |  |  |  |
| Security subscription | 494.6 |  |  | 369.8 |  |  | 1,373.6 |  |  | 1,023.1 |  |
| Technical support and other | 374.1 |  |  | 311.0 |  |  | 1,076.9 |  |  | 870.9 |  |
| Total service revenue | 868.7 |  |  | 680.8 |  |  | 2,450.5 |  |  | 1,894.0 |  |
| Total revenue | $ | 1,334.6 |  |  | $ | 1,149.5 |  |  | $ | 3,889.7 |  |  | $ | 3,134.4 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2024-05-06):
[0001262039-24-000020:note_history:31]
|  | Three Months Ended |  |  |
|  | March 31,2024 |  | March 31,2023 |  |  |  |  |
| Product | $ | 408.9 |  |  | $ | 500.7 |  |  |  |  |  |
| Service: |  |  |  |  |  |  |  |
| Security subscription | 536.9 |  |  | 421.7 |  |  |  |  |  |
| Technical support and other | 407.5 |  |  | 339.9 |  |  |  |  |  |
| Total service revenue | 944.4 |  |  | 761.6 |  |  |  |  |  |
| Total revenue | $ | 1,353.3 |  |  | $ | 1,262.3 |  |  |  |  |  |
  (was, 2023-11-07, similarity 0.6518):
[0001262039-23-000038:note_history:31]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30,2023 |  | September 30,2022 |  | September 30,2023 |  | September 30,2022 |
| Product | $ | 465.9 |  |  | $ | 468.7 |  |  | $ | 1,439.2 |  |  | $ | 1,240.4 |  |
| Service: |  |  |  |  |  |  |  |
| Security subscription | 494.6 |  |  | 369.8 |  |  | 1,373.6 |  |  | 1,023.1 |  |
| Technical support and other | 374.1 |  |  | 311.0 |  |  | 1,076.9 |  |  | 870.9 |  |
| Total service revenue | 868.7 |  |  | 680.8 |  |  | 2,450.5 |  |  | 1,894.0 |  |
| Total revenue | $ | 1,334.6 |  |  | $ | 1,149.5 |  |  | $ | 3,889.7 |  |  | $ | 3,134.4 |  |

- added (2024-05-06):
[0001262039-24-000020:note_history:32]
During the three months ended March 31, 2024 and 2023, we recognized $851.1 million and $675.9 million in service revenue that was included in the deferred revenue balance as of December 31, 2023 and 2022, respectively.

- changed (2024-05-06):
[0001262039-24-000020:note_history:33]
As of March 31, 2024, the aggregate amount of the transaction price allocated to remaining performance obligations was $5.81 billion, which was substantially comprised of deferred security subscription and technical support services revenue that will be recognized in future periods. We expect to recognize approximately $2.93 billion as revenue over the next 12 months and the remainder thereafter.
  (was, 2023-11-07, similarity 0.9041):
[0001262039-23-000038:note_history:33]
As of September 30, 2023, the aggregate amount of the transaction price allocated to remaining performance obligations was $5.30 billion, which was substantially comprised of deferred security subscription, technical support services revenue and unbilled contract revenue from non-cancellable contracts that will be recognized in future periods. We expect to recognize approximately $2.66 billion as revenue over the next 12 months and the remainder thereafter.

- changed (2024-05-06):
[0001262039-24-000020:note_history:34]
Trade accounts receivable are recorded at the invoiced amount, net of an allowance for expected credit losses. We measure expected credit losses of accounts receivable on a collective (pooled) basis, aggregating accounts receivable that are either current or no more than 60 days past due, and aggregating accounts receivable that are more than 60 days past due. We apply a credit-loss percentage to each of the pools that is based on our historical credit losses. We review whether each of our significant accounts receivable that is more than 60 days past due continues to exhibit similar risk characteristics with the other accounts receivable in the pool. If we determine that it does not, we evaluate it for expected credit losses on an individual basis. Expected credit losses are recorded as general and administrative expenses on our condensed consolidated statements of income.
  (was, 2023-11-07, similarity 0.9943):
[0001262039-23-000038:note_history:34]
Trade accounts receivable are recorded at the invoiced amount, net of an allowance for expected credit losses. We measure expected credit losses of accounts receivable on a collective (pooled) basis, aggregating accounts receivable that are either current or no more than 60 days past due, and aggregating accounts receivable that are more than 60 days past due. We apply a credit-loss percentage to each of the pools that is based on our historical credit losses. We review whether each of our significant accounts receivable that is more than 60 days past due continues to exhibit similar risk characteristics with the other accounts receivable in the pool. If we determine that it does not, we evaluate it for expected credit losses on an individual basis. Expected credit losses are recorded as general and administrative expenses on our consolidated statements of income.

- changed (2024-05-06):
[0001262039-24-000020:note_history:35]
The allowance for credit losses was $6.9 million and $8.2 million as of March 31, 2024 and December 31, 2023, respectively. Provisions, write-offs and recoveries were not material during the three months ended March 31, 2024 and 2023.
  (was, 2023-11-07, similarity 0.8103):
[0001262039-23-000038:note_history:35]
The allowance for credit losses was $5.3 million and $3.6 million as of September 30, 2023 and December 31, 2022, respectively. Provisions, write-offs and recoveries were not material during the nine months ended September 30, 2023 and 2022.

- changed (2024-05-06):
[0001262039-24-000020:note_history:36]
Amortization of deferred contract costs during the three months ended March 31, 2024 and 2023 were $72.0 million and $62.5 million, respectively.
  (was, 2023-11-07, similarity 0.6284):
[0001262039-23-000038:note_history:36]
Amortization of deferred contract costs during the three months ended September 30, 2023 and 2022 were $68.0 million and $56.7 million, respectively. Amortization of deferred contract costs during the nine months ended September 30, 2023 and 2022 were $195.9 million and $163.8 million, respectively.

- removed (2024-05-06):
[0001262039-23-000038:note_history:37]
During the three and nine months ended September 30, 2023, we recognized $514.3 million and $1.80 billion in service revenue that was included in the deferred revenue balance as of December 31, 2022, respectively. During the three and nine months ended September 30, 2022, we recognized $401.9 million and $1.37 billion in service revenue that was included in the deferred revenue balance as of December 31, 2021, respectively.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_current_note, score: 0.0

- removed (2024-05-06):
[0001262039-23-000038:note_history:38]
SUBSEQUENT EVENT
Share Repurchase Program

- removed (2024-05-06):
[0001262039-23-000038:note_history:39]
Subsequent to September 30, 2023 through the filing of this Quarterly Report on Form 10-Q, we repurchased 11.2 million shares of our common stock at an average price of $54.87 per share for an aggregate purchase price of $613.5 million under the Repurchase Program, which excludes a $5.7 million accrual related to the 1% excise tax imposed by the Inflation Reduction Act of 2022.
