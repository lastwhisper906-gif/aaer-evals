# FTNT notes — 0001262039-24-000020


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001262039-24-000020:notes:1]
SUMMARY OF SIGNIFICANT ACCOUNTING POLICIES
Basis of Presentation and Preparation—The unaudited condensed consolidated financial statements of Fortinet, Inc. and its subsidiaries (collectively, “we,” “us” or “our”) have been prepared in accordance with generally accepted accounting principles in the United States (“GAAP”) for interim financial information, as well as the instructions to Form 10-Q pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (the “SEC”). Accordingly, they do not include all of the information and footnotes required by GAAP for complete financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the year ended December 31, 2023, contained in our Annual Report on Form 10-K filed with the SEC on February 26, 2024. In the opinion of management, all adjustments, which include normal recurring adjustments, considered necessary for a fair presentation, have been included. The results of operations for the three months ended March 31, 2024 are not necessarily indicative of the results to be expected for the full year or for any future periods. The condensed consolidated balance sheet as of December 31, 2023 is derived from the audited consolidated financial statements for the year ended December 31, 2023.

[0001262039-24-000020:notes:2]
[same as prior period, unchanged from 0001262039-23-000038:notes:3]

[0001262039-24-000020:notes:3]
[same as prior period, unchanged from 0001262039-23-000038:notes:4]

[0001262039-24-000020:notes:4]
There have been no material changes to our significant accounting policies as of and for the three months ended March 31, 2024, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended December 31, 2023 filed with the SEC.

[0001262039-24-000020:notes:5]
Recent Accounting Standards Not Yet Effective

[0001262039-24-000020:notes:6]
Segment Reporting

[0001262039-24-000020:notes:7]
In November 2023, the Financial Accounting Standards Board (the “FASB”) issued Accounting Standards Update (“ASU”) 2023-07, Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures, which is intended to improve reportable segment disclosure requirements, primarily through enhanced disclosures about significant expenses. The amendments are effective for our annual reporting for fiscal year 2024, and for our interim period reporting starting in fiscal year 2025 retrospectively, with early adoption permitted. We are currently evaluating the ASU to determine its impact on our disclosures.

[0001262039-24-000020:notes:8]
Income Taxes

[0001262039-24-000020:notes:9]
In December 2023, the FASB issued ASU 2023-09, Income Taxes (Topic 740): Improvements to Income Tax Disclosures, which includes amendments that further enhance income tax disclosures, primarily through standardization and disaggregation of rate reconciliation categories and income taxes paid by jurisdiction. The amendments are effective for our annual period beginning fiscal year 2025, with early adoption permitted, and should be applied prospectively. We are currently evaluating the ASU to determine its impact on our disclosures.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001262039-24-000020:notes:10]
[same as prior period, unchanged from 0001262039-23-000038:notes:8]

[0001262039-24-000020:notes:11]
[same as prior period, unchanged from 0001262039-23-000038:notes:9]

[0001262039-24-000020:notes:12]
|  | Three Months Ended |  |  |
|  | March 31,2024 |  | March 31,2023 |  |  |  |  |
| Product | $ | 408.9 |  |  | $ | 500.7 |  |  |  |  |  |
| Service: |  |  |  |  |  |  |  |
| Security subscription | 536.9 |  |  | 421.7 |  |  |  |  |  |
| Technical support and other | 407.5 |  |  | 339.9 |  |  |  |  |  |
| Total service revenue | 944.4 |  |  | 761.6 |  |  |  |  |  |
| Total revenue | $ | 1,353.3 |  |  | $ | 1,262.3 |  |  |  |  |  |

[0001262039-24-000020:notes:13]
[same as prior period, unchanged from 0001262039-23-000038:notes:11]

[0001262039-24-000020:notes:14]
During the three months ended March 31, 2024 and 2023, we recognized $851.1 million and $675.9 million in service revenue that was included in the deferred revenue balance as of December 31, 2023 and 2022, respectively.

[0001262039-24-000020:notes:15]
[same as prior period, unchanged from 0001262039-23-000038:notes:13]

[0001262039-24-000020:notes:16]
As of March 31, 2024, the aggregate amount of the transaction price allocated to remaining performance obligations was $5.81 billion, which was substantially comprised of deferred security subscription and technical support services revenue that will be recognized in future periods. We expect to recognize approximately $2.93 billion as revenue over the next 12 months and the remainder thereafter.

[0001262039-24-000020:notes:17]
[same as prior period, unchanged from 0001262039-23-000038:notes:15]

[0001262039-24-000020:notes:18]
Trade accounts receivable are recorded at the invoiced amount, net of an allowance for expected credit losses. We measure expected credit losses of accounts receivable on a collective (pooled) basis, aggregating accounts receivable that are either current or no more than 60 days past due, and aggregating accounts receivable that are more than 60 days past due. We apply a credit-loss percentage to each of the pools that is based on our historical credit losses. We review whether each of our significant accounts receivable that is more than 60 days past due continues to exhibit similar risk characteristics with the other accounts receivable in the pool. If we determine that it does not, we evaluate it for expected credit losses on an individual basis. Expected credit losses are recorded as general and administrative expenses on our condensed consolidated statements of income.

[0001262039-24-000020:notes:19]
The allowance for credit losses was $6.9 million and $8.2 million as of March 31, 2024 and December 31, 2023, respectively. Provisions, write-offs and recoveries were not material during the three months ended March 31, 2024 and 2023.

[0001262039-24-000020:notes:20]
[same as prior period, unchanged from 0001262039-23-000038:notes:18]

[0001262039-24-000020:notes:21]
Amortization of deferred contract costs during the three months ended March 31, 2024 and 2023 were $72.0 million and $62.5 million, respectively.


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0001262039-24-000020:notes:22]
FINANCIAL INSTRUMENTS AND FAIR VALUE
Available-for-Sale Investments

[0001262039-24-000020:notes:23]
The following tables summarize our available-for-sale investments (in millions):

[0001262039-24-000020:notes:24]
|  | March 31, 2024 |
|  | AmortizedCost |  | UnrealizedGains |  | UnrealizedLosses |  | FairValue |
| U.S. government and agency securities | $ | 479.9 |  |  | $ | — |  |  | $ | (0.4) |  |  | $ | 479.5 |  |
| Commercial paper | 478.1 |  |  | — |  |  | (0.4) |  |  | 477.7 |  |
| Certificates of deposit and term deposits | 71.6 |  |  | — |  |  | — |  |  | 71.6 |  |
| Corporate debt securities | 46.6 |  |  | — |  |  | — |  |  | 46.6 |  |
| Total available-for-sale investments | $ | 1,076.2 |  |  | $ | — |  |  | $ | (0.8) |  |  | $ | 1,075.4 |  |

[0001262039-24-000020:notes:25]
|  | December 31, 2023 |
|  | AmortizedCost |  | UnrealizedGains |  | UnrealizedLosses |  | FairValue |
| U.S. government and agency securities | $ | 461.5 |  |  | $ | 0.2 |  |  | $ | (0.3) |  |  | $ | 461.4 |  |
| Commercial paper | 401.7 |  |  | 0.2 |  |  | (0.1) |  |  | 401.8 |  |
| Certificates of deposit and term deposits | 88.2 |  |  | 0.1 |  |  | — |  |  | 88.3 |  |
| Corporate debt securities | 70.0 |  |  | 0.1 |  |  | (0.1) |  |  | 70.0 |  |
| Total available-for-sale investments | $ | 1,021.4 |  |  | $ | 0.6 |  |  | $ | (0.5) |  |  | $ | 1,021.5 |  |

[0001262039-24-000020:notes:26]
The following tables show the gross unrealized losses and the related fair values of our available-for-sale investments that have been in a continuous unrealized loss position (in millions):

[0001262039-24-000020:notes:27]
|  | March 31, 2024 |
|  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
|  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |
| U.S. government and agency securities | $ | 302.1 |  |  | $ | (0.3) |  |  | $ | 9.9 |  |  | $ | (0.1) |  |  | $ | 312.0 |  |  | $ | (0.4) |  |
| Commercial paper | 417.5 |  |  | (0.4) |  |  | — |  |  | — |  |  | 417.5 |  |  | (0.4) |  |
| Corporate debt securities | 29.1 |  |  | — |  |  | 2.0 |  |  | — |  |  | 31.1 |  |  | — |  |
| Total available-for-sale investments | $ | 748.7 |  |  | $ | (0.7) |  |  | $ | 11.9 |  |  | $ | (0.1) |  |  | $ | 760.6 |  |  | $ | (0.8) |  |

[0001262039-24-000020:notes:28]
|  | December 31, 2023 |
|  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
|  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |
| U.S. government and agency securities | $ | 47.1 |  |  | $ | — |  |  | $ | 11.7 |  |  | $ | (0.3) |  |  | $ | 58.8 |  |  | $ | (0.3) |  |
| Commercial paper | 200.8 |  |  | (0.1) |  |  | — |  |  | — |  |  | 200.8 |  |  | (0.1) |  |
| Corporate debt securities | 21.8 |  |  | — |  |  | 26.9 |  |  | (0.1) |  |  | 48.7 |  |  | (0.1) |  |
| Total available-for-sale investments | $ | 269.7 |  |  | $ | (0.1) |  |  | $ | 38.6 |  |  | $ | (0.4) |  |  | $ | 308.3 |  |  | $ | (0.5) |  |

[0001262039-24-000020:notes:29]
[same as prior period, unchanged from 0001262039-23-000038:notes:27]

[0001262039-24-000020:notes:30]
|  | March 31,2024 |  | December 31,2023 |
| Due within one year | $ | 1,075.4 |  |  | $ | 1,021.5 |  |
| Due within one to three years | — |  |  | — |  |
| Total | $ | 1,075.4 |  |  | $ | 1,021.5 |  |

[0001262039-24-000020:notes:31]
Available-for-sale investments are reported at fair value, with unrealized gains and losses and the related tax impact included as a separate component of stockholders’ equity (deficit) and in comprehensive income. We do not intend to sell any of the securities in an unrealized loss position and it is not more likely than not that we would be required to sell these securities before recovery of their amortized cost basis, which may be at maturity.

[0001262039-24-000020:notes:32]
Realized gains and losses on available-for-sale investments were insignificant in the periods presented.

[0001262039-24-000020:notes:33]
[same as prior period, unchanged from 0001262039-23-000038:notes:31]

[0001262039-24-000020:notes:34]
Our marketable equity securities were $21.4 million and $21.0 million as of March 31, 2024 and December 31, 2023. The changes in fair value of our marketable equity securities are recorded in other income (expense)—net on the condensed consolidated statements of income. We recognized a $0.3 million and $0.6 million gain during the three months ended March 31, 2024 and 2023, respectively.

[0001262039-24-000020:notes:35]
[same as prior period, unchanged from 0001262039-23-000038:notes:33]

[0001262039-24-000020:notes:36]
[same as prior period, unchanged from 0001262039-23-000038:notes:34]

[0001262039-24-000020:notes:37]
[same as prior period, unchanged from 0001262039-23-000038:notes:35]

[0001262039-24-000020:notes:38]
[same as prior period, unchanged from 0001262039-23-000038:notes:36]

[0001262039-24-000020:notes:39]
[same as prior period, unchanged from 0001262039-23-000038:notes:37]

[0001262039-24-000020:notes:40]
[same as prior period, unchanged from 0001262039-23-000038:notes:38]

[0001262039-24-000020:notes:41]
[same as prior period, unchanged from 0001262039-23-000038:notes:39]

[0001262039-24-000020:notes:42]
[same as prior period, unchanged from 0001262039-23-000038:notes:40]

[0001262039-24-000020:notes:43]
[same as prior period, unchanged from 0001262039-23-000038:notes:41]

[0001262039-24-000020:notes:44]
[same as prior period, unchanged from 0001262039-23-000038:notes:42]

[0001262039-24-000020:notes:45]
|  | March 31, 2024 |  | December 31, 2023 |
|  | AggregateFairValue |  | QuotedPrices inActiveMarkets ForIdenticalAssets |  | SignificantOtherObservableRemainingInputs |  | SignificantOtherUnobservableRemainingInputs |  | AggregateFairValue |  | QuotedPrices inActiveMarkets ForIdenticalAssets |  | SignificantOtherObservableRemainingInputs |  | SignificantOtherUnobservableRemainingInputs |
|  |  |  | (Level 1) |  | (Level 2) |  | (Level 3) |  |  |  | (Level 1) |  | (Level 2) |  | (Level 3) |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. government and agency securities | $ | 495.4 |  |  | $ | 438.9 |  |  | $ | 56.5 |  |  | $ | — |  |  | $ | 501.4 |  |  | $ | 433.3 |  |  | $ | 68.1 |  |  | $ | — |  |
| Commercial paper | 555.3 |  |  | — |  |  | 555.3 |  |  | — |  |  | 472.2 |  |  | — |  |  | 472.2 |  |  | — |  |
| Certificates of deposit and term deposits | 92.8 |  |  | — |  |  | 92.8 |  |  | — |  |  | 104.8 |  |  | — |  |  | 104.8 |  |  | — |  |
| Corporate debt securities | 47.5 |  |  | — |  |  | 47.5 |  |  | — |  |  | 73.0 |  |  | — |  |  | 73.0 |  |  | — |  |
| Money market funds | 254.6 |  |  | 254.6 |  |  | — |  |  | — |  |  | 277.1 |  |  | 277.1 |  |  | — |  |  | — |  |
| Marketable equity securities | 21.4 |  |  | 21.4 |  |  | — |  |  | — |  |  | 21.0 |  |  | 21.0 |  |  | — |  |  | — |  |
| Total | $ | 1,467.0 |  |  | $ | 714.9 |  |  | $ | 752.1 |  |  | $ | — |  |  | $ | 1,449.5 |  |  | $ | 731.4 |  |  | $ | 718.1 |  |  | $ | — |  |
| Reported as: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents | $ | 370.2 |  |  |  |  |  |  |  |  | $ | 407.0 |  |  |  |  |  |  |  |
| Marketable equity securities | 21.4 |  |  |  |  |  |  |  |  | 21.0 |  |  |  |  |  |  |  |
| Short-term investments | 1,075.4 |  |  |  |  |  |  |  |  | 1,021.5 |  |  |  |  |  |  |  |
| Total | $ | 1,467.0 |  |  |  |  |  |  |  |  | $ | 1,449.5 |  |  |  |  |  |  |  |

[0001262039-24-000020:notes:46]
There were no transfers between Level 1 and Level 2 of the fair value hierarchy during the three months ended March 31, 2024 and year ended December 31, 2023.


## us-gaap:InventoryDisclosureTextBlock

[0001262039-24-000020:notes:47]
INVENTORY
Inventory, net of reserves, consisted of (in millions):

[0001262039-24-000020:notes:48]
|  | March 31,2024 |  | December 31,2023 |
| Raw materials | $ | 104.5 |  |  | $ | 92.1 |  |
| Work in process | 6.2 |  |  | 7.7 |  |
| Finished goods | 328.8 |  |  | 385.0 |  |
| Inventory | $ | 439.5 |  |  | $ | 484.8 |  |

[0001262039-24-000020:notes:49]
The excess and obsolete inventory reserve was $101.6 million and $89.2 million as of March 31, 2024 and December 31, 2023, respectively. Inventory write-downs related to excess and obsolete inventory were $18.1 million for the three months ended March 31, 2024, and were not material for the three months ended March 31, 2023. These were recorded in cost of product revenue on the condensed consolidated statements of income.


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001262039-24-000020:notes:50]
[same as prior period, unchanged from 0001262039-23-000038:notes:47]

[0001262039-24-000020:notes:51]
|  | March 31,2024 |  | December 31,2023 |
| Land | $ | 453.0 |  |  | $ | 351.7 |  |
| Buildings and improvements | 712.5 |  |  | 595.5 |  |
| Computer equipment and software | 265.6 |  |  | 261.1 |  |
| Leasehold improvements | 66.7 |  |  | 61.4 |  |
| Evaluation units | 32.3 |  |  | 30.8 |  |
| Furniture and fixtures | 35.2 |  |  | 33.6 |  |
| Construction-in-progress | 56.0 |  |  | 63.3 |  |
| Total property and equipment | 1,621.3 |  |  | 1,397.4 |  |
| Less: accumulated depreciation | (373.9) |  |  | (353.0) |  |
| Property and equipment—net | $ | 1,247.4 |  |  | $ | 1,044.4 |  |

[0001262039-24-000020:notes:52]
During the three months ended March 31, 2024, we purchased certain real estate properties in California for a total purchase price of $207.1 million to be used predominantly for research and development and warehousing operations. The purchases were accounted for under the asset acquisition method. The cost of the assets allocated to land, buildings and improvements, and furniture and fixtures were $101.4 million, $104.8 million, and $0.9 million, respectively, based on their relative fair values. 
Depreciation expense was $25.6 million and $22.8 million during the three months ended March 31, 2024 and 2023, respectively.


## us-gaap:InvestmentTextBlock

[0001262039-24-000020:notes:53]
INVESTMENT IN PRIVATELY HELD COMPANY
Linksys Holdings, Inc.

[0001262039-24-000020:notes:54]
During 2021, we invested $160.0 million in cash for shares of the Series A Preferred Stock of privately held Linksys Holdings, Inc. (“Linksys”), for a 50.8% ownership interest in outstanding equity of Linksys. As of March 31, 2024 and December 31, 2023, our ownership interest remained the same. Linksys provides router connectivity solutions to the consumer and small business markets.

[0001262039-24-000020:notes:55]
We have concluded that our investment in Linksys is an in-substance common stock investment and that we do not hold an absolute controlling financial interest in Linksys, but that we have the ability to exercise significant influence over the operating and financial policies of Linksys. Determining that we have significant influence but not control over the operating and financial policies of Linksys required significant judgement of many factors, including but not limited to the ownership interest in Linksys, board representation, participation in policy-making processes and participation rights in certain significant financial and operating decisions of Linksys in the ordinary course of business. Therefore, we determined to account for this investment using the equity method of accounting. We record our share of Linksys’ financial results on a three-month lag basis, with the exception of material transactions or events that occur during the intervening period that materially affect the financial position or results of operations. We determined that there was a basis difference between the cost of our investment in Linksys and the amount of underlying equity in net assets of Linksys.

[0001262039-24-000020:notes:56]
Our share of loss of Linksys’ financial results, as well as our share of the amortization of the basis differences, totaled $6.4 million and $22.1 million for the three months ended March 31, 2024 and 2023, respectively, and has been recorded in loss from equity method investments on the condensed consolidated statements of income. The carrying amount of our Linksys investment was $35.8 million and $42.2 million as of March 31, 2024 and December 31, 2023, respectively, and the investment was included in other assets on our condensed consolidated balance sheets.

[0001262039-24-000020:notes:57]
Due to the presence of impairment indicators, such as a series of operating losses, we evaluated our equity method investment for an other-than-temporary impairment (“OTTI”) during the three months ended March 31, 2024. We considered various factors in determining whether an OTTI has occurred, including the limited operating history available, our ability and intent to hold the investment until its fair value recovers, the implied revenue valuation multiples compared to guideline public 
companies, Linksys’ ability to achieve milestones and any notable operational and strategic changes. After the evaluation, we determined that an additional OTTI has not occurred as of March 31, 2024. However, we may be required to recognize an impairment loss in future reporting periods if and when our evaluation of the aforementioned factors indicates that the investment in Linksys is determined to be other than temporarily impaired. Such determination will be based on the prevailing facts and circumstances at that time, including the results and disclosures of Linksys.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001262039-24-000020:notes:58]
[same as prior period, unchanged from 0001262039-23-000038:notes:60]

[0001262039-24-000020:notes:59]
[same as prior period, unchanged from 0001262039-23-000038:notes:61]

[0001262039-24-000020:notes:60]
|  | Amount |
| Balance—December 31, 2023 | $ | 126.5 |  |
| Additions due to business combination | 3.9 |  |
| Foreign currency translation adjustments | (1.4) |  |
| Balance—March 31, 2024 | $ | 129.0 |  |

[0001262039-24-000020:notes:61]
There were no impairments to goodwill during the three months ended March 31, 2024 or during prior periods.

[0001262039-24-000020:notes:62]
[same as prior period, unchanged from 0001262039-23-000038:notes:64]

[0001262039-24-000020:notes:63]
[same as prior period, unchanged from 0001262039-23-000038:notes:65]

[0001262039-24-000020:notes:64]
|  | March 31, 2024 |
|  | Weighted-Average Useful Life (in Years) |  | Gross |  | Accumulated Amortization |  | Net |
| Other intangible assets—net: |  |  |  |  |  |  |  |
| Finite-lived intangible assets: |  |  |  |  |  |  |  |
| Developed technologies | 4.6 |  | $ | 80.1 |  |  | $ | 62.0 |  |  | $ | 18.1 |  |
| Customer relationships | 7.0 |  | 30.6 |  |  | 18.0 |  |  | 12.6 |  |
| Trade name | 10.0 |  | 4.6 |  |  | 1.2 |  |  | 3.4 |  |
| Backlog | 1.0 |  | 3.6 |  |  | 3.6 |  |  | — |  |
| Total other intangible assets—net |  |  | $ | 118.9 |  |  | $ | 84.8 |  |  | $ | 34.1 |  |

[0001262039-24-000020:notes:65]
|  | December 31, 2023 |
|  | Weighted-Average Useful Life (in Years) |  | Gross |  | Accumulated Amortization |  | Net |
| Other intangible assets—net: |  |  |  |  |  |  |  |
| Finite-lived intangible assets: |  |  |  |  |  |  |  |
| Developed technologies | 4.4 |  | $ | 79.4 |  |  | $ | 60.6 |  |  | $ | 18.8 |  |
| Customer relationships | 7.1 |  | 30.4 |  |  | 17.7 |  |  | 12.7 |  |
| Trade name | 10.0 |  | 5.0 |  |  | 1.2 |  |  | 3.8 |  |
| Backlog | 1.0 |  | 3.9 |  |  | 3.9 |  |  | — |  |
| Total other intangible assets—net |  |  | $ | 118.7 |  |  | $ | 83.4 |  |  | $ | 35.3 |  |

[0001262039-24-000020:notes:66]
Amortization expense was $3.0 million and $4.7 million during the three months ended March 31, 2024 and 2023, respectively.

[0001262039-24-000020:notes:67]
[same as prior period, unchanged from 0001262039-23-000038:notes:69]

[0001262039-24-000020:notes:68]
|  | Amount |
| Years: |  |
| 2024 (the remainder of 2024) | $ | 9.5 |  |
| 2025 | 8.6 |  |
| 2026 | 4.8 |  |
| 2027 | 4.4 |  |
| 2028 | 1.5 |  |
| Thereafter | 5.3 |  |
| Total | $ | 34.1 |  |


## us-gaap:EarningsPerShareTextBlock

[0001262039-24-000020:notes:69]
NET INCOME PER SHARE
Basic net income per share is computed by dividing net income by the weighted-average number of shares of common stock outstanding during the period. Diluted net income per share is computed by dividing net income by the weighted-average number of shares of common stock outstanding during the period, plus the dilutive effects of restricted stock units (“RSUs”), stock options and performance stock units (“PSUs”). Dilutive shares of common stock are determined by applying the treasury stock method.

[0001262039-24-000020:notes:70]
A reconciliation of the numerator and denominator used in the calculation of basic and diluted net income per share is (in millions, except per share amounts):

[0001262039-24-000020:notes:71]
|  | Three Months Ended |  |  |
|  | March 31,2024 |  | March 31,2023 |  |  |  |  |
| Numerator: |  |  |  |  |  |  |  |
| Net income | $ | 299.3 |  |  | $ | 247.7 |  |  |  |  |  |
| Denominator: |  |  |  |  |  |  |  |
| Basic shares: |  |  |  |  |  |  |  |
| Weighted-average common stock outstanding-basic | 762.4 |  |  | 783.2 |  |  |  |  |  |
| Diluted shares: |  |  |  |  |  |  |  |
| Weighted-average common stock outstanding-basic | 762.4 |  |  | 783.2 |  |  |  |  |  |
| Effect of potentially dilutive securities: |  |  |  |  |  |  |  |
| RSUs | 2.7 |  |  | 3.6 |  |  |  |  |  |
| Stock options | 5.1 |  |  | 6.6 |  |  |  |  |  |
| PSUs | 0.3 |  |  | — |  |  |  |  |  |
| Weighted-average shares used to compute diluted net income per share | 770.5 |  |  | 793.4 |  |  |  |  |  |
| Net income per share |  |  |  |  |  |  |  |
| Basic | $ | 0.39 |  |  | $ | 0.32 |  |  |  |  |  |
| Diluted | $ | 0.39 |  |  | $ | 0.31 |  |  |  |  |  |

[0001262039-24-000020:notes:72]
The following weighted-average shares of common stock were excluded from the computation of diluted net income per share for the periods presented, as their effect would have been antidilutive (in millions):

[0001262039-24-000020:notes:73]
|  | Three Months Ended |  |  |
|  | March 31,2024 |  | March 31,2023 |  |  |  |  |
| RSUs | — |  |  | 1.8 |  |  |  |  |  |
| Stock options | 3.1 |  |  | 2.3 |  |  |  |  |  |
| Total | 3.1 |  |  | 4.1 |  |  |  |  |  |


## us-gaap:DebtDisclosureTextBlock

[0001262039-24-000020:notes:74]
DEBT
2026 and 2031 Senior Notes

[0001262039-24-000020:notes:75]
On March 5, 2021, we issued $1.0 billion aggregate principal amount of senior notes (collectively, the “Senior Notes”), consisting of $500.0 million aggregate principal amount of 1.0% notes due March 15, 2026 (the “2026 Senior Notes”) and $500.0 million aggregate principal amount of 2.2% notes due March 15, 2031 (the “2031 Senior Notes”), in an underwritten registered public offering. The Senior Notes are senior unsecured obligations and rank equally with each other in right of payment and with our other outstanding obligations. We may redeem the Senior Notes at any time in whole or in part for cash, at specified redemption prices that include accrued and unpaid interest, if any, and a make-whole premium. However, no make-whole premium will be paid for redemptions of the 2026 Senior Notes on or after February 15, 2026, or the 2031 Senior Notes on or after December 15, 2030. Interest on the Senior Notes is payable on March 15 and September 15 of each year, beginning on September 15, 2021. As of March 31, 2024 and December 31, 2023, the Senior Notes were recorded as long-term debt, net of discount and issuance costs, which are amortized to interest expense over the respective contractual terms of these notes using the effective interest method.

[0001262039-24-000020:notes:76]
The total outstanding debt is summarized below (in millions, except percentages):

[0001262039-24-000020:notes:77]
|  | Maturity |  | Coupon Rate |  | Effective Interest Rate |  | March 31,2024 |  | December 31,2023 |
| Debt |  |  |  |  |  |  |  |  |  |
| 2026 Senior Notes | March 2026 |  | 1.0% |  | 1.3% |  | $ | 500.0 |  |  | $ | 500.0 |  |
| 2031 Senior Notes | March 2031 |  | 2.2% |  | 2.3% |  | 500.0 |  |  | 500.0 |  |
| Total debt |  |  |  |  |  |  | 1,000.0 |  |  | 1,000.0 |  |
| Less: Unamortized discount and debt issuance costs |  |  |  |  |  |  | 7.2 |  |  | 7.7 |  |
| Total long-term debt |  |  |  |  |  |  | $ | 992.8 |  |  | $ | 992.3 |  |

[0001262039-24-000020:notes:78]
As of March 31, 2024 and December 31, 2023, we accrued interest payable of $0.7 million and $4.7 million, respectively, and there are no financial covenants with which we must comply. During the three months ended March 31, 2024 and 2023, we recorded $4.5 million of total interest expense in relation to these Senior Notes in each period. No interest costs were capitalized for the three months ended March 31, 2024 and 2023, as the costs that qualified for capitalization were not material.

[0001262039-24-000020:notes:79]
The total estimated fair value of the outstanding Senior Notes was approximately $878.9 million, including accrued and unpaid interest, as of March 31, 2024. The fair value was determined based on observable market prices of identical instruments in less active markets. The estimated fair values are based on Level 2 inputs.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001262039-24-000020:notes:80]
COMMITMENTS AND CONTINGENCIES
The following table summarizes our inventory purchase commitments as of March 31, 2024 (in millions):

[0001262039-24-000020:notes:81]
|  | Total |  | 2024 |  | Thereafter |
| Inventory purchase commitments | $ | 629.7 |  |  | $ | 575.4 |  |  | $ | 54.3 |  |

[0001262039-24-000020:notes:82]
Inventory Purchase Commitments—We purchase components of our inventory from certain suppliers and use several independent contract manufacturers to provide manufacturing services for our products. During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, we enter into agreements with contract manufacturers and suppliers that allow them to procure inventory based upon criteria as defined by us or establish the parameters defining our requirements. A significant portion of our reported purchase commitments arising from these agreements consists of firm, non-cancelable and unconditional commitments. Certain of these inventory purchase commitments with contract manufacturers and suppliers relate to arrangements to secure supply and pricing for certain product components for multi-year periods. In certain instances, these agreements allow us the option to reschedule and adjust our requirements based on our business needs prior to firm orders being placed.

[0001262039-24-000020:notes:83]
As of March 31, 2024, we had $629.7 million of non-cancelable inventory purchase commitments with our independent contract manufacturers. We recorded a liability for these purchase commitments for quantities in excess of our future estimated demand forecasts, consistent with the valuation of our excess and obsolete inventory. As of March 31, 2024 and December 31, 2023, the liability for these inventory purchase commitments was $115.0 million and $84.7 million, respectively, and was recorded in accrued liabilities on our condensed consolidated balance sheets. The expense related to such accrued liability for inventory purchase commitments was $31.6 million and $10.4 million during the three months ended March 31, 2024 and 2023, respectively, and was recorded in cost of product revenue on the condensed consolidated statements of income.

[0001262039-24-000020:notes:84]
Other Contractual Commitments and Open Purchase Orders—In addition to commitments with contract manufacturers, we have open purchase orders and contractual obligations in the ordinary course of business for which we have not received goods or services. A significant portion of our reported purchase commitments consist of non-cancelable commitments. In certain instances, contractual commitments allow us the option to cancel, reschedule and adjust our requirements based on our business needs prior to firm orders being placed. As of March 31, 2024, we had $40.4 million in other contractual commitments having a remaining term in excess of one year that are non-cancelable.

[0001262039-24-000020:notes:85]
As of March 31, 2024, we had $89.8 million in contractual commitments related to payments for operating leases.

[0001262039-24-000020:notes:86]
Litigation—We are involved in disputes, litigation, and other legal actions. For lawsuits where we are the defendant, we are in the process of defending these litigation matters, and while there can be no assurances and the outcome of certain of these matters is currently not determinable and not predictable, we currently are unaware of any existing claims or proceedings that we believe are likely to have a material adverse effect on our financial position. There are many uncertainties associated with any litigation and these actions or other third-party claims against us may cause us to incur costly litigation fees, costs and substantial settlement charges, and possibly subject us to damages and other penalties. In addition, the resolution of any intellectual property (“IP”) litigation may require us to make royalty payments, which could adversely affect our gross margins in future periods. If any of those events were to occur, our business, financial condition, results of operations, and cash flows could be adversely affected. Litigation is unpredictable and the actual liability in any such matters may be materially different from our current estimates, which could result in the need to adjust any accrued liability and record additional expenses. We accrue for contingencies when we believe that a loss is probable and that we can reasonably estimate the amount of any such loss. These accruals are generally based on a range of possible outcomes that require significant management judgement. If no amount within a range is a better estimate than any other, we accrue the minimum amount. Litigation loss contingency accruals associated with outstanding cases were not material as of March 31, 2024, and December 31, 2023.

[0001262039-24-000020:notes:87]
On March 21, 2019, we were sued by Alorica Inc. (“Alorica”) in Santa Clara County Superior Court in California. Alorica has alleged breach of warranty and misrepresentation claims, which we deny. Fact discovery closed during the quarter ended June 30, 2023 and trial is currently set for September 2024. Although we believe that the ultimate outcome of this matter will not materially impact our financial position, results of operations or cash flows, legal proceedings are subject to inherent uncertainties, and an unfavorable ruling could occur, which may result in a material adverse impact on our business, financial position, results of operations and cash flows. No loss accrual had been recorded as of March 31, 2024 or December 31, 2023 related to this litigation.

[0001262039-24-000020:notes:88]
Indemnification and Other Matters—Under the indemnification provisions of our standard sales contracts, we agree to defend our customers against third-party claims asserting various allegations such as product defects and infringement of certain IP rights, which may include patents, copyrights, trademarks or trade secrets, and to pay judgments entered on such claims. In some contracts, our exposure under these indemnification provisions is limited by the terms of the contracts to certain defined limits, such as the total amount paid by our customer under the agreement. However, certain agreements include covenants, penalties and indemnification provisions including and beyond indemnification for third-party claims of IP infringement that could potentially expose us to losses in excess of the amount received under the agreement, and in some instances to potential liability that is not contractually limited. Although from time to time there are indemnification claims

[0001262039-24-000020:notes:89]
asserted against us and currently there are pending indemnification claims, to date there have been no material awards under such indemnification provisions.

[0001262039-24-000020:notes:90]
Similar to other security companies and companies in other industries, we have experienced and may experience in the future, cybersecurity threats, malicious activity directed against our information technology infrastructure or unauthorized attempts to gain access to our and our customers’ sensitive information and systems. We currently are unaware of any existing claims or proceedings related to these types of matters, including any that we believe are likely to have a material adverse effect on our financial position.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001262039-24-000020:notes:91]
[same as prior period, unchanged from 0001262039-23-000038:notes:91]

[0001262039-24-000020:notes:92]
We maintain the Amended and Restated Fortinet, Inc. 2009 Equity Incentive Plan (the “Amended Plan”) pursuant to which we have granted RSUs, stock options and PSUs. As of March 31, 2024, there were a total of 50.8 million shares of common stock available for grant under the Amended Plan.

[0001262039-24-000020:notes:93]
[same as prior period, unchanged from 0001262039-23-000038:notes:93]

[0001262039-24-000020:notes:94]
[same as prior period, unchanged from 0001262039-23-000038:notes:94]

[0001262039-24-000020:notes:95]
|  | Restricted Stock Units Outstanding |
|  | Number of Shares |  | Weighted-Average Grant Date Fair Value per Share |
| Balance—December 31, 2023 | 9.1 |  |  | $ | 53.61 |  |
| Granted | 2.7 |  |  | 65.34 |  |
| Forfeited | (0.2) |  |  | 55.59 |  |
| Vested | (1.7) |  |  | 47.69 |  |
| Balance—March 31, 2024 | 9.9 |  |  | $ | 57.90 |  |

[0001262039-24-000020:notes:96]
Stock compensation expense is recognized on a straight-line basis over the vesting period of each RSU. As of March 31, 2024, total compensation expense related to unvested RSUs granted to employees and non-employees under the Amended Plan, but not yet recognized, was $529.6 million, with a weighted-average remaining vesting period of 2.9 years.

[0001262039-24-000020:notes:97]
[same as prior period, unchanged from 0001262039-23-000038:notes:97]

[0001262039-24-000020:notes:98]
[same as prior period, unchanged from 0001262039-23-000038:notes:98]

[0001262039-24-000020:notes:99]
|  | Three Months Ended |  |  |
|  | March 31,2024 |  | March 31,2023 |  |  |  |  |
| Shares withheld for taxes | 0.6 |  |  | 0.7 |  |  |  |  |  |
| Amount withheld for taxes | $ | 42.9 |  |  | $ | 34.6 |  |  |  |  |  |

[0001262039-24-000020:notes:100]
[same as prior period, unchanged from 0001262039-23-000038:notes:100]

[0001262039-24-000020:notes:101]
[same as prior period, unchanged from 0001262039-23-000038:notes:101]

[0001262039-24-000020:notes:102]
|  | Three Months Ended |  |  |
|  | March 31,2024 |  | March 31,2023 |  |  |  |  |
| Expected term in years | 4.5 |  | 4.4 |  |  |  |  |
| Volatility | 42.9 | % |  | 42.0 | % |  |  |  |  |
| Risk-free interest rate | 4.34 | % |  | 4.2 | % |  |  |  |  |
| Dividend rate | — | % |  | — | % |  |  |  |  |

[0001262039-24-000020:notes:103]
[same as prior period, unchanged from 0001262039-23-000038:notes:103]

[0001262039-24-000020:notes:104]
|  | Options Outstanding |
|  | Numberof Shares |  | Weighted-AverageExercisePrice |  | Weighted-AverageRemainingContractualLife (Years) |  | AggregateIntrinsicValue |
| Balance—December 31, 2023 | 11.2 |  |  | $ | 31.14 |  |  | 3.3 |  | $ | 315.8 |  |
| Granted | 0.6 |  |  | 65.34 |  |  |  |  |  |
| Forfeited | — |  |  | 56.93 |  |  |  |  |  |
| Exercised | (1.0) |  |  | 13.50 |  |  |  |  |  |
| Balance—March 31, 2024 | 10.8 |  |  | $ | 34.64 |  |  |  |  |  |
| Options vested and expected to vest—March 31, 2024 | 10.8 |  |  | $ | 34.64 |  |  | 3.5 |  | $ | 365.3 |  |
| Options exercisable—March 31, 2024 | 7.9 |  |  | $ | 26.34 |  |  | 2.7 |  | $ | 330.1 |  |

[0001262039-24-000020:notes:105]
The aggregate intrinsic value represents the difference between the exercise price of stock options and the quoted market price of our common stock for all in-the-money stock options. Stock compensation expense is recognized on a straight-line basis over the vesting period of each stock option. As of March 31, 2024, total compensation expense related to unvested stock options granted to employees but not yet recognized was $63.6 million, with a weighted-average remaining vesting period of 2.7 years.

[0001262039-24-000020:notes:106]
[same as prior period, unchanged from 0001262039-23-000038:notes:106]

[0001262039-24-000020:notes:107]
|  | Three Months Ended |  |  |
|  | March 31,2024 |  | March 31,2023 |  |  |  |  |
| Weighted-average fair value per share granted | $ | 26.92 |  |  | $ | 24.24 |  |  |  |  |  |
| Intrinsic value of options exercised | $ | 51.8 |  |  | $ | 72.7 |  |  |  |  |  |
| Fair value of options vested | $ | 12.1 |  |  | $ | 11.7 |  |  |  |  |  |

[0001262039-24-000020:notes:108]
[same as prior period, unchanged from 0001262039-23-000038:notes:108]

[0001262039-24-000020:notes:109]
[same as prior period, unchanged from 0001262039-23-000038:notes:109]

[0001262039-24-000020:notes:110]
The following table summarizes the weighted-average assumptions relating to our PSUs:

[0001262039-24-000020:notes:111]
|  | Three Months Ended |
|  | March 31,2024 |  | March 31,2023 |
| Expected term in years | 2.7 |  | 2.7 |
| Volatility | 45.5 | % |  | 47.5 | % |
| Risk-free interest rate | 4.5 | % |  | 4.6 | % |
| Dividend rate | — | % |  | — | % |

[0001262039-24-000020:notes:112]
We granted approximately 0.3 million shares of PSU awards with a weighted-average grant date fair value of $98.19 and $90.96 per share to certain of our executives during the first quarter of 2024 and 2023, respectively. The grant date fair value of these awards was determined using a Monte Carlo simulation pricing model. Approximately 0.1 million shares of PSU awards vested during the three months ended March 31, 2024. No shares of PSU awards vested during the three months ended March 31, 2023. None of these PSU awards were forfeited during the three months ended March 31, 2024 and 2023.

[0001262039-24-000020:notes:113]
As of March 31, 2024, total compensation expense related to unvested PSUs that were granted to certain of our executives, but not yet recognized, was $38.7 million. This expense is expected to be amortized on a graded vesting method over a weighted-average vesting period of 2.5 years.

[0001262039-24-000020:notes:114]
[same as prior period, unchanged from 0001262039-23-000038:notes:114]

[0001262039-24-000020:notes:115]
[same as prior period, unchanged from 0001262039-23-000038:notes:115]

[0001262039-24-000020:notes:116]
|  | Three Months Ended |  |  |
|  | March 31,2024 |  | March 31,2023 |  |  |  |  |
| Cost of product revenue | $ | 0.5 |  |  | $ | 0.4 |  |  |  |  |  |
| Cost of service revenue | 6.2 |  |  | 5.1 |  |  |  |  |  |
| Research and development | 19.8 |  |  | 17.0 |  |  |  |  |  |
| Sales and marketing | 26.7 |  |  | 26.3 |  |  |  |  |  |
| General and administrative | 9.8 |  |  | 8.2 |  |  |  |  |  |
| Total stock-based compensation expense | $ | 63.0 |  |  | $ | 57.0 |  |  |  |  |  |

[0001262039-24-000020:notes:117]
[same as prior period, unchanged from 0001262039-23-000038:notes:117]

[0001262039-24-000020:notes:118]
|  | Three Months Ended |  |  |
|  | March 31,2024 |  | March 31,2023 |  |  |  |  |
| RSUs | $ | 52.0 |  |  | $ | 49.1 |  |  |  |  |  |
| Stock options | 7.3 |  |  | 6.7 |  |  |  |  |  |
| PSUs | 3.7 |  |  | 1.2 |  |  |  |  |  |
| Total stock-based compensation expense | $ | 63.0 |  |  | $ | 57.0 |  |  |  |  |  |

[0001262039-24-000020:notes:119]
Total income tax benefit associated with stock-based compensation that is recognized in the condensed consolidated statements of income is (in millions):

[0001262039-24-000020:notes:120]
|  | Three Months Ended |  |  |
|  | March 31,2024 |  | March 31,2023 |  |  |  |  |
| Income tax benefit associated with stock-based compensation | $ | 13.9 |  |  | $ | 12.6 |  |  |  |  |  |

[0001262039-24-000020:notes:121]
[same as prior period, unchanged from 0001262039-23-000038:notes:121]

[0001262039-24-000020:notes:122]
In January 2024, our board of directors approved a $500.0 million increase in the authorized share repurchase amount under the Repurchase Program, bringing the aggregate amount authorized to be repurchased to $7.25 billion of our outstanding common stock. In February 2024, our board of directors approved an extension of the Repurchase Program to February 28, 2025. Share repurchases may be made by us from time to time in privately negotiated transactions or in open-market transactions. The Repurchase Program does not require us to purchase a minimum number of shares, and may be suspended, modified or discontinued at any time without prior notice.

[0001262039-24-000020:notes:123]
There were no shares repurchased under the Repurchase Program during the three months ended March 31, 2024. As of March 31, 2024, $1.03 billion remained available for future share repurchases under the Repurchase Program.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001262039-24-000020:notes:124]
INCOME TAXES
Our effective tax rate was 11% for the three months ended March 31, 2024, compared to an effective tax rate of 7% for the same period last year. The tax rates for the three months ended March 31, 2024 and 2023 were composed of U.S. federal and state taxes, withholding taxes and foreign taxes that amounted to $81.7 million and $85.8 million, respectively. The tax rate for the three months ended March 31, 2024 was impacted by a tax benefit of $24.0 million from the FDII deduction, and excess tax benefits from stock-based compensation expense of $18.2 million. The tax rate for the three months ended March 31, 2023 was impacted by a tax benefit of $38.2 million from the FDII deduction and excess tax benefits from stock-based compensation expense of $26.3 million.

[0001262039-24-000020:notes:125]
As of March 31, 2024 and December 31, 2023, unrecognized tax benefits were $66.0 million and $65.8 million, respectively. If recognized, $55.4 million of the unrecognized tax benefits as of March 31, 2024 would favorably affect our effective tax rate. It is our policy to include accrued interest and penalties related to unrecognized tax benefits in income tax expense. As of March 31, 2024 and December 31, 2023, accrued interest and penalties were $6.9 million and $6.4 million, respectively. It is reasonably possible that our gross unrecognized tax benefits will decrease by up to $4.7 million in the next 12 months, due to the lapse of statutes of limitation in various jurisdictions. This decrease, if recognized, would favorably impact our effective tax rate, and would be recognized as an additional tax benefit.

[0001262039-24-000020:notes:126]
We file income tax returns in the U.S. federal jurisdiction and in various U.S. state and foreign jurisdictions. Generally, we are no longer subject to examination by U.S federal income tax authorities for tax years prior to 2015. We are no longer subject to U.S. state and foreign income tax examinations by tax authorities for tax years prior to 2010. We currently have ongoing tax audits in the United Kingdom, Canada and several other foreign jurisdictions. The focus of these audits is the inter-company profit allocation.

[0001262039-24-000020:notes:127]
On January 4, 2022, the U.S. Treasury published another tranche of final regulations regarding the foreign tax credit. These final regulations impose new requirements that a foreign tax must meet in order to be creditable against U.S. income taxes, and generally apply to tax years beginning on or after December 28, 2021. On July 26, 2022, the U.S. Treasury released corrections to the final regulations. On July 21, 2023, the IRS released a notice that suspended the application of significant portions of the final regulations regarding the foreign tax credit for tax years 2022 and 2023. The notice released in July 2023 favorably impacted our ability to claim foreign tax credits in the United States for certain taxes imposed by certain foreign jurisdictions. On December 11, 2023, the IRS released a notice that extended the suspension of significant portions of the final regulations beyond December 31, 2023, until further guidance is issued. 
In December 2021, the Organisation for Economic Co-operation and Development (the “OECD”) enacted model rules for a new global minimum tax framework (“BEPS Pillar Two”), and various governments around the world have enacted, or are in the process of enacting, legislation on this. The OECD continues to release additional guidance on these rules. Based on the enacted laws, BEPS Pillar Two has no impact to our effective tax rate or cash flows for the three months ended March 31, 2024. We will continue to evaluate the impact of these tax law changes on future reporting periods.


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0001262039-24-000020:notes:128]
DEFINED CONTRIBUTION PLANS
Our tax-deferred savings plan under our 401(k) Plan permits participating U.S. employees to contribute a portion of their pre-tax or after-tax earnings. In Canada, we have a Group Registered Retirement Savings Plan Program (the “RRSP”), which permits participants to make pre-tax contributions. Our board of directors approved 50% matching contributions on 
employee contributions up to 4% of each employee’s eligible earnings. Our matching contributions to our 401(k) Plan and the RRSP for the three months ended March 31, 2024 and 2023 were $6.3 million and $4.4 million, respectively.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001262039-24-000020:notes:129]
[same as prior period, unchanged from 0001262039-23-000038:notes:131]

[0001262039-24-000020:notes:130]
[same as prior period, unchanged from 0001262039-23-000038:notes:132]

[0001262039-24-000020:notes:131]
|  | Three Months Ended |  |  |
| Revenue | March 31,2024 |  | March 31,2023 |  |  |  |  |
| Americas: |  |  |  |  |  |  |  |
| United States | $ | 407.1 |  |  | $ | 384.1 |  |  |  |  |  |
| Other Americas | 149.9 |  |  | 139.4 |  |  |  |  |  |
| Total Americas | 557.0 |  |  | 523.5 |  |  |  |  |  |
| Europe, Middle East and Africa (“EMEA”) | 539.4 |  |  | 478.2 |  |  |  |  |  |
| Asia Pacific (“APAC”) | 256.9 |  |  | 260.6 |  |  |  |  |  |
| Total revenue | $ | 1,353.3 |  |  | $ | 1,262.3 |  |  |  |  |  |

[0001262039-24-000020:notes:132]
| Property and Equipment—net | March 31,2024 |  | December 31,2023 |
| Americas: |  |  |  |
| United States | $ | 908.0 |  |  | $ | 701.6 |  |
| Canada | 213.2 |  |  | 212.8 |  |
| Latin America | 2.3 |  |  | 2.3 |  |
| Total Americas | 1,123.5 |  |  | 916.7 |  |
| EMEA | 63.5 |  |  | 65.5 |  |
| APAC | 60.4 |  |  | 62.2 |  |
| Total property and equipment—net | $ | 1,247.4 |  |  | $ | 1,044.4 |  |

[0001262039-24-000020:notes:133]
[same as prior period, unchanged from 0001262039-23-000038:notes:135]

[0001262039-24-000020:notes:134]
|  | Three Months Ended |  |  |
|  | March 31,2024 |  | March 31,2023 |  |  |  |  |
| Distributor A | 31 | % |  | 28 | % |  |  |  |  |
| Distributor B | 15 | % |  | 14 | % |  |  |  |  |
| Distributor C | 13 | % |  | 14 | % |  |  |  |  |

[0001262039-24-000020:notes:135]
[same as prior period, unchanged from 0001262039-23-000038:notes:137]

[0001262039-24-000020:notes:136]
|  | March 31,2024 |  | December 31,2023 |
| Distributor A | 28 | % |  | 33 | % |
| Distributor B | 13 | % |  | 14 | % |
| Distributor C | 13 | % |  | 10 | % |


## ecd:MtrlTermsOfTrdArrTextBlock

[0001262039-24-000020:notes:137]
[same as prior period, unchanged from 0001262039-23-000038:notes:141]

[0001262039-24-000020:notes:138]
On March 6, 2024, Keith Jensen, our Chief Financial Officer, entered into a pre-arranged written stock sale plan in accordance with Rule 10b5-1 under the Exchange Act for the sale of shares of our common stock (the “Jensen Plan”) during an open trading window in accordance with our insider trading policy. The Jensen Plan is intended to satisfy the affirmative defense of Rule 10b5-1(c) under the Exchange Act. The Jensen Plan provides for the potential sale by Keith Jensen of up to (a) 163,170 shares of our common stock, including upon the (i) vesting and settlement of RSUs and PSUs for shares of our common stock or (ii) exercise of vested options to purchase shares of our common stock, and (b) the net shares (which are not yet determinable) after shares are withheld to satisfy tax obligations upon such vesting and settlement, in each case, at the market price, all between June 5, 2024 and June 7, 2025.

[0001262039-24-000020:notes:139]
The Jensen Plan includes a representation from Keith Jensen to the broker administering the plan that he was not in possession of any material nonpublic information regarding us or the securities subject to the Jensen Plan at the time that he entered into the Jensen Plan. He made a similar representation to us in connection with the adoption of the Jensen Plan under our insider trading policy. The representation was made as of March 6, 2024 and speaks only as of that date. In making the representation, Mr. Jensen did not provide assurance with respect to any material nonpublic information of which he was unaware, or with respect to any material nonpublic information acquired by him or us after the date of the representation.

[0001262039-24-000020:notes:140]
Once executed, transactions under the Jensen Plan will be disclosed publicly through Form 4 and/or Form 144 filings with the SEC in accordance with applicable securities laws, rules and regulations. Except as may be required by law, we do not undertake any obligation to update or report any modification, termination or other activity under current or future Rule 10b5-1 plans that may be adopted by Keith Jensen or our other officers or directors or their affiliated entities.
