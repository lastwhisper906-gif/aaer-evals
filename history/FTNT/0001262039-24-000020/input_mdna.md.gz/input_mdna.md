# FTNT MD&A — 0001262039-24-000020


## mdna

[0001262039-24-000020:mdna:1]
[same as prior period, unchanged from 0001262039-23-000038:mdna:1]

[0001262039-24-000020:mdna:2]
[same as prior period, unchanged from 0001262039-23-000038:mdna:2]

[0001262039-24-000020:mdna:3]
[same as prior period, unchanged from 0001262039-23-000038:mdna:3]

[0001262039-24-000020:mdna:4]
[same as prior period, unchanged from 0001262039-23-000038:mdna:4]

[0001262039-24-000020:mdna:5]
•increasing or decreasing inflation or stagflation, and changing interest rates in many geographies and changes in currency exchange rates and currency regulations;

[0001262039-24-000020:mdna:6]
[same as prior period, unchanged from 0001262039-23-000038:mdna:6]

[0001262039-24-000020:mdna:7]
[same as prior period, unchanged from 0001262039-23-000038:mdna:7]

[0001262039-24-000020:mdna:8]
[same as prior period, unchanged from 0001262039-23-000038:mdna:9]

[0001262039-24-000020:mdna:9]
[same as prior period, unchanged from 0001262039-23-000038:mdna:10]

[0001262039-24-000020:mdna:10]
[same as prior period, unchanged from 0001262039-23-000038:mdna:11]

[0001262039-24-000020:mdna:11]
[same as prior period, unchanged from 0001262039-23-000038:mdna:12]

[0001262039-24-000020:mdna:12]
•growth expectations for the secure networking market;

[0001262039-24-000020:mdna:13]
[same as prior period, unchanged from 0001262039-23-000038:mdna:13]

[0001262039-24-000020:mdna:14]
[same as prior period, unchanged from 0001262039-23-000038:mdna:14]

[0001262039-24-000020:mdna:15]
[same as prior period, unchanged from 0001262039-23-000038:mdna:15]

[0001262039-24-000020:mdna:16]
[same as prior period, unchanged from 0001262039-23-000038:mdna:17]

[0001262039-24-000020:mdna:17]
[same as prior period, unchanged from 0001262039-23-000038:mdna:18]

[0001262039-24-000020:mdna:18]
[same as prior period, unchanged from 0001262039-23-000038:mdna:19]

[0001262039-24-000020:mdna:19]
[same as prior period, unchanged from 0001262039-23-000038:mdna:20]

[0001262039-24-000020:mdna:20]
[same as prior period, unchanged from 0001262039-23-000038:mdna:21]

[0001262039-24-000020:mdna:21]
24

[0001262039-24-000020:mdna:22]
•expectations that our operating expenses will increase year over year in absolute dollars during the remainder of 2024;

[0001262039-24-000020:mdna:23]
[same as prior period, unchanged from 0001262039-23-000038:mdna:23]

[0001262039-24-000020:mdna:24]
•uncertain tax benefits and our effective domestic and global tax rates, the impact of interpretations of or changes to tax law, and the timing of tax payments;

[0001262039-24-000020:mdna:25]
•expectations regarding spending related to real estate assets, acquisitions and development, including data center, office building and warehouse investments, as well as other capital expenditures and to the impact on free cash flow and expenses;

[0001262039-24-000020:mdna:26]
•estimates of a range of 2024 spending on capital expenditures;

[0001262039-24-000020:mdna:27]
•expected outcomes and liabilities in litigation;

[0001262039-24-000020:mdna:28]
[same as prior period, unchanged from 0001262039-23-000038:mdna:28]

[0001262039-24-000020:mdna:29]
[same as prior period, unchanged from 0001262039-23-000038:mdna:29]

[0001262039-24-000020:mdna:30]
[same as prior period, unchanged from 0001262039-23-000038:mdna:30]

[0001262039-24-000020:mdna:31]
[same as prior period, unchanged from 0001262039-23-000038:mdna:31]

[0001262039-24-000020:mdna:32]
Fortinet is a leader in cybersecurity and the convergence of networking and security. Our mission is to secure people, devices and data everywhere. Our integrated platform, the Fortinet Security Fabric, spans secure networking, unified SASE and AI-driven security operations to deliver cybersecurity where our customers need it. As of March 31, 2024, over a half million customers trusted our solutions, including enterprises such as in the financial services, retail, healthcare and operational technology market verticals, communication and security service providers, and government organizations. As a global company headquartered in Sunnyvale, California our research and development is centered in the United States and Canada with a global footprint of support and centers of excellence around the world. As of March 31, 2024, we held 978 U.S. patents and 1,318 global patents and we are recognized in over 100 enterprise analyst reports demonstrating both our vision and execution across security and networking products.

[0001262039-24-000020:mdna:33]
•Secure Networking—Our Secure Networking solutions focus on the convergence of networking and security via FortiOS, our networking and security operating system that is the foundation of our Fortinet Security Fabric platform and supports over 30 functions that can be delivered via a physical, virtual, cloud or SaaS solution. When delivered via our network firewall appliances, functionality is accelerated through our proprietary ASIC technology. These proprietary ASICs, allow our systems to scale, run multiple applications at higher performance, lower power consumption and perform more processor-intensive operations, such as inspecting encrypted traffic, including streaming video. The Network Firewall solution consists of FortiGate data centers, hyperscale and distributed firewalls, as well as encrypted applications (SSL inspection, Virtual Private Network and IPsec connectivity). Our ability to converge networking and security also enables the ethernet to become an extension of a company’s security infrastructure through FortiSwitch and FortiLink. Our wireless LAN solution leverages secure networking to provide secure wireless access for the enterprise LAN edge. FortiExtender secures 5G/LTE and remote ethernet extenders to

[0001262039-24-000020:mdna:34]
connect and secure any branch environment. The Secure Connectivity solution includes FortiSwitch Secure Ethernet Switches, FortiAP Wireless Local Area Network Access Points and FortiExtender 5G Connectivity Gateways.

[0001262039-24-000020:mdna:35]
•Unified Secure Access Service Edge (SASE)—As applications move to the cloud and work from anywhere becomes established, cloud delivery enables secure access to applications on any cloud. The Fortinet Unified SASE solution is a single-vendor SASE solution that includes Firewall, SD-WAN, Secure Web Gateway, Cloud Access Services Broker, Data Loss Prevention, Zero Trust Network Access and cloud security, including Web Application Firewalls, Virtualized Firewalls and Cloud-Native Firewalls, among other products. These functions are delivered through our FortiOS operating systems, which can deploy the full SASE stack through the cloud or on our ASIC-driven appliances. All functions can be managed through a unified management console.

[0001262039-24-000020:mdna:36]
•Security Operations (SecOps)—Fortinet’s Security Operations portfolio is comprised of cybersecurity solutions that identify, protect, detect, respond and recover, and are delivered as a platform that automates detection and response to accelerate discovery and remediation. The SecOps solution includes FortiAI generative AI assistant, FortiSIEM Security Information and Event Management, FortiSOAR Security Orchestration, Automation and Response, FortiEDR Endpoint Detection and Response, FortiXDR Extended Detection and Response, FortiMDR Managed Detection and Response Service, FortiNDR Network Detection and Response, FortiRecon Digital Risk Protection, FortiDeceptor Deception technology, FortiGuard SoCaaS, FortiSandbox Sandboxing Services and FortiGuard Incident Response Services, among other products.

[0001262039-24-000020:mdna:37]
FortiGuard Labs is our cybersecurity threat intelligence and research organization comprised of experienced threat hunters, researchers, analysts, engineers and data scientists who develop and utilize machine learning and AI technologies to provide timely protection updates and actionable threat intelligence for the benefit of our customers. FortiGuard Security Services are a suite of AI-powered security capabilities that are natively integrated as part of the Fortinet Security Fabric to deliver coordinated detection and enforcement across the entire attack surface. The portfolio consists of FortiGuard application security services, content security services, device security services, NOC/SOC security services and web security services.

[0001262039-24-000020:mdna:38]
FortiCare Technical Support Service is a per-device technical support service, which provides customers access to experts to ensure efficient and effective operations and maintenance of their Fortinet capabilities. Global technical support is offered 24x7 with flexible add-ons, including enhanced SLAs and premium hardware replacement through in-country depots. Organizations have the flexibility to procure different levels of service for different devices based on their availability needs. We offer three per-device support options tailored to the needs of our enterprise customers: FortiCare Premium, FortiCare Elite and FortiCare Essential. The FortiCare Elite service aims to provide 15-minute response times for key product families.

[0001262039-24-000020:mdna:39]
Additionally, Fortinet is committed to addressing the cybersecurity skills shortage through training and certification programs for customers, partners and employees. The Fortinet Training Institute’s ecosystem of public and private partnerships around the world extend to industry, academia, government and nonprofits to ensure we are reaching and increasing access of our cybersecurity certifications and training to all populations. The Fortinet Training Institute has issued over 1.5 million certifications to date.

[0001262039-24-000020:mdna:40]
[same as prior period, unchanged from 0001262039-23-000038:mdna:41]

[0001262039-24-000020:mdna:41]
•Total revenue was $1.35 billion during the three months ended March 31, 2024, an increase of 7%, compared to $1.26 billion in the same period last year. Our revenue growth was driven by growth in service revenue. Product revenue was $408.9 million during the three months ended March 31, 2024, a decrease of 18%, compared to $500.7 million in the same period last year. Service revenue was $944.4 million during the three months ended March 31, 2024, an increase of 24%, compared to $761.6 million in the same period last year.

[0001262039-24-000020:mdna:42]
•Total gross profit was $1.05 billion during the three months ended March 31, 2024, an increase of 10%, compared to $954.5 million in the same period last year. Total gross margin was 77.5% during the three months ended March 31, 2024, an increase of 1.9 percentage points, compared to 75.6% in the same period last year.

[0001262039-24-000020:mdna:43]
•Operating income was $321.2 million during the three months ended March 31, 2024, an increase of 17%, compared to $273.5 million in the same period last year.

[0001262039-24-000020:mdna:44]
•Cash, cash equivalents, short-term and long-term investments and marketable equity securities were $3.02 billion as of March 31, 2024.

[0001262039-24-000020:mdna:45]
•Deferred revenue was $5.79 billion, including short-term deferred revenue of $2.91 billion, as of March 31, 2024.

[0001262039-24-000020:mdna:46]
•Cash flows from operating activities were $830.4 million during the three months ended March 31, 2024, an increase of $152.9 million, or 23%, compared to the same period last year.

[0001262039-24-000020:mdna:47]
On a geographic basis, revenue continues to be diversified globally, which remains a key strength of our business. During the three months ended March 31, 2024, the Americas region, the Europe, Middle East and Africa (“EMEA”) region and the Asia Pacific (“APAC”) region contributed 41%, 40% and 19% of our total revenue, respectively. Americas region and EMEA region increased 6% and 13%, respectively, and APAC region decreased 1% during the three months ended March 31, 2024 compared to the same period last year.

[0001262039-24-000020:mdna:48]
Product revenue decreased 18% during the three months ended March 31, 2024 compared to the same period last year, due to the decrease in hardware revenue, partially offset by the increase in software revenue. The decrease in hardware revenue was impacted by the backlog drawdown in the prior period, continued product digestion of previously placed orders, reduced net prices on certain products and macroeconomic conditions. When we fulfill, ship and bill during a quarter to satisfy backlog, this increases our aggregate billings and revenue during any particular quarter. As the supply chain challenges normalize, the growth comparisons versus prior quarters where backlog contributed more to billings become more challenging. For the remainder of 2024, we expect product revenue growth rates will continue to be impacted by drawdown of backlog in earlier periods and earlier pricing actions.

[0001262039-24-000020:mdna:49]
Service revenue growth during the three months ended March 31, 2024 was 24%, as compared to the same period last year, was primarily driven by the strength of our security subscription revenue, which grew 27%. The increase was primarily due to the recognition of revenue from our growing deferred revenue balance related to FortiGuard and other security subscriptions delivered to on-premise and cloud-based environments and strength in unified SASE and SecOps. We expect our service revenue to continue to grow for the remainder of 2024, with growth opportunities that include unified SASE and SecOps offerings. While service revenue is expected to grow, we anticipate that the growth rates will ease for the remainder of 2024.

[0001262039-24-000020:mdna:50]
Our billings were diversified on a geographic basis. During the three months ended March 31, 2024, six countries represented approximately 50% of our billings and the remaining 50% in the aggregate were from over 100 countries that each individually contributed less than 3% of our billings.

[0001262039-24-000020:mdna:51]
Operating expenses as a percentage of revenue decreased 0.1 percentage points during the three months ended March 31, 2024 compared to the same period last year, mainly driven by a decrease in marketing expense. Headcount decreased to 13,522 employees and contractors as of March 31, 2024, a 0.3% decrease compared to 13,568 as of December 31, 2023.

[0001262039-24-000020:mdna:52]
[same as prior period, unchanged from 0001262039-23-000038:mdna:58]

[0001262039-24-000020:mdna:53]
Our overall performance depends in part on worldwide economic and geopolitical conditions, such as the war in Ukraine and the Israel-Hamas war or tensions between China and Taiwan, and their impact on customer behavior. Worsening economic conditions, including inflation, higher interest rates, slower growth, any recession, fluctuations in foreign exchange rates and other changes in economic conditions, may result in decreased sales productivity and growth and adversely affect our results of operations and financial performance. We have seen certain impacts on our business, results of operations, financial condition, cash flows, liquidity and capital and financial resources such as longer sales cycles, delayed purchases and increased commitments with certain suppliers and increased inventory and inventory purchase commitment reserves.

[0001262039-24-000020:mdna:54]
[same as prior period, unchanged from 0001262039-23-000038:mdna:61]

[0001262039-24-000020:mdna:55]
[same as prior period, unchanged from 0001262039-23-000038:mdna:62]

[0001262039-24-000020:mdna:56]
We typically sell our security solutions to distributors that sell to networking security focused resellers and to certain service providers and managed security service providers (“MSSPs”), who, in turn, sell to end-customers or use our products and services to provide hosted solutions to other enterprises. At times, we also sell directly to certain large enterprise customers, large service providers and major systems integrators. In addition, we sell our software licenses and services via different cloud service provider platforms, both directly and through our channel partners. Our end-customers are located in over 100 countries and include small, medium and large enterprises and government organizations across a wide range of industries, including financial services, government, healthcare, manufacturing, retail, technology and telecommunications. An end-customer

[0001262039-24-000020:mdna:57]
deployment may involve as few as one or as many as thousands of secure networking, unified SASE and security operations technology products, depending on the end-customer’s size and security requirements.

[0001262039-24-000020:mdna:58]
Our customers purchase our hardware products, software licenses and cloud-delivered solutions, as well as our FortiGuard and other security subscription and FortiCare technical support services. We generally invoice at the time of our sale for the total price of the products and services. Standard payment terms are generally no more than 60 days, though we may offer extended payment terms to certain distributors or related to certain transactions.

[0001262039-24-000020:mdna:59]
We also offer our products hosted in our own data centers, PoPs and through co-locations and major cloud service providers, including Amazon Web Services, Microsoft Azure and Google Cloud. We have also recognized revenue from customers who deploy our products in a bring-your-own-license (“BYOL”) arrangements at cloud service providers or at private clouds. In a BYOL arrangement, a customer purchases a software license through our channel partners and deploys the software in a cloud provider’s environment, in third-party clouds or in their private cloud.

[0001262039-24-000020:mdna:60]
[same as prior period, unchanged from 0001262039-23-000038:mdna:66]

[0001262039-24-000020:mdna:61]
We monitor several key metrics, including the key financial metrics set forth below, in order to help us evaluate growth trends, establish budgets, measure the effectiveness of our sales and marketing efforts, and assess operational efficiencies. The following table summarizes revenue, deferred revenue, billings (non-GAAP), net cash provided by operating activities, and free cash flow (non-GAAP). We discuss revenue below under “Results of Operations,” and we discuss net cash provided by operating activities below under “—Liquidity and Capital Resources.” Deferred revenue, billings (non-GAAP), and free cash flow (non-GAAP) are discussed immediately below the following table:

[0001262039-24-000020:mdna:62]
|  | Three Months Ended Or As Of |
|  | March 31, 2024 |  | March 31, 2023 |
|  | (in millions) |
| Revenue | $ | 1,353.3 |  |  | $ | 1,262.3 |  |
| Deferred revenue | $ | 5,789.9 |  |  | $ | 4,880.9 |  |
| Billings (non-GAAP) | $ | 1,407.2 |  |  | $ | 1,502.9 |  |
| Net cash provided by operating activities | $ | 830.4 |  |  | $ | 677.5 |  |
| Free cash flow (non-GAAP) | $ | 608.5 |  |  | $ | 647.2 |  |

[0001262039-24-000020:mdna:63]
Deferred revenue. Our deferred revenue consists of amounts that have been invoiced but that have not yet been recognized as revenue. The majority of our deferred revenue balance consists of the unrecognized portion of service revenue from FortiGuard and other security subscriptions and FortiCare technical support service contracts, which is recognized as revenue ratably over the service term. We monitor our deferred revenue balance, short-term and total deferred revenue growth and the mix of short-term and long-term deferred revenue because deferred revenue represents a significant portion of free cash flow and of revenue to be recognized in future periods. Deferred revenue was $5.79 billion as of March 31, 2024, an increase of $54.9 million, or 1%, from December 31, 2023. Short term deferred revenue was $2.91 billion as of March 31, 2024, an increase of $63.3 million, or 2%, from December 31, 2023.

[0001262039-24-000020:mdna:64]
Billings (non-GAAP). We define billings as revenue recognized in accordance with GAAP plus the change in deferred revenue from the beginning to the end of the period, less any deferred revenue balances acquired from business combination(s) during the period. We consider billings to be a useful metric for management and investors because billings drive current and future revenue, which is an important indicator of the health and viability of our business. There are several limitations related to the use of billings instead of GAAP revenue. First, billings include amounts that have not yet been recognized as revenue and are impacted by the term of FortiGuard security subscription and FortiCare and other support agreements. Second, we may calculate billings in a manner that is different from peer companies that report similar financial measures. Management accounts for these limitations by providing specific information regarding GAAP revenue and evaluating billings together with GAAP revenue. Total billings were $1.41 billion for the three months ended March 31, 2024, a decrease of 6% compared to $1.50 billion in the same period last year.

[0001262039-24-000020:mdna:65]
Our backlog fluctuated over quarters and any decrease in growth or negative growth of in-quarter billings and revenue may not be reflected by our aggregate billings and revenue. When we have fulfilled, shipped and billed during a quarter to satisfy backlog, this increased our aggregate billings and revenue during any particular quarter, and as the supply chain challenges normalized, the growth comparisons versus prior quarters where backlog contributed more to billings became more challenging.

[0001262039-24-000020:mdna:66]
[same as prior period, unchanged from 0001262039-23-000038:mdna:75]

[0001262039-24-000020:mdna:67]
|  | Three Months Ended |
|  | March 31, 2024 |  | March 31, 2023 |
|  | (in millions) |
| Billings: |  |  |  |
| Revenue | $ | 1,353.3 |  |  | $ | 1,262.3 |  |
| Add: Change in deferred revenue | 54.9 |  |  | 240.6 |  |
| Less: Deferred revenue balance acquired in business combination | (1.0) |  |  | — |  |
| Total billings (non-GAAP) | $ | 1,407.2 |  |  | $ | 1,502.9 |  |

[0001262039-24-000020:mdna:68]
Free cash flow (non-GAAP). We define free cash flow as net cash provided by operating activities minus purchases of property and equipment and excluding any significant non-recurring items. We believe free cash flow to be a liquidity measure that provides useful information to management and investors about the amount of cash generated by the business that, after capital expenditures, can be used for strategic opportunities, including repurchasing outstanding common stock, investing in our business, making strategic acquisitions, and strengthening the balance sheet. A limitation of using free cash flow rather than the GAAP measures of cash provided by or used in operating activities, investing activities, and financing activities is that free cash flow does not represent the total increase or decrease in the cash and cash equivalents balance for the period because it excludes cash flows from investing activities other than capital expenditures and cash flows from financing activities. Management accounts for this limitation by providing information about our capital expenditures and other investing and financing activities on the condensed consolidated statements of cash flows and under “—Liquidity and Capital Resources” and by presenting cash flows from investing and financing activities in our reconciliation of free cash flow. In addition, it is important to note that other companies, including companies in our industry, may not use free cash flow, may calculate free cash flow in a different manner than we do or may use other financial measures to evaluate their performance, all of which could reduce the usefulness of free cash flow as a comparative measure. A reconciliation of net cash provided by operating activities, the most directly comparable financial measure calculated and presented in accordance with GAAP, to free cash flow is provided below:

[0001262039-24-000020:mdna:69]
|  | Three Months Ended |
|  | March 31, 2024 |  | March 31, 2023 |
|  | (in millions) |
| Free Cash Flow: |  |  |  |
| Net cash provided by operating activities | $ | 830.4 |  |  | $ | 677.5 |  |
| Less: Purchases of property and equipment | (221.9) |  |  | (30.3) |  |
| Free cash flow (non-GAAP) | $ | 608.5 |  |  | $ | 647.2 |  |
| Net cash used in investing activities | $ | (270.3) |  |  | $ | (42.4) |  |
| Net cash used in financing activities | $ | (30.3) |  |  | $ | (13.7) |  |

[0001262039-24-000020:mdna:70]
[same as prior period, unchanged from 0001262039-23-000038:mdna:80]

[0001262039-24-000020:mdna:71]
[same as prior period, unchanged from 0001262039-23-000038:mdna:81]

[0001262039-24-000020:mdna:72]
There were no material changes to our critical accounting policies and estimates as of and for the three months ended March 31, 2024, as compared to the critical accounting policies and estimates described in our Annual Report on Form 10-K filed with the SEC on February 26, 2024 (the “Form 10-K”).

[0001262039-24-000020:mdna:73]
[same as prior period, unchanged from 0001262039-23-000038:mdna:83]

[0001262039-24-000020:mdna:74]
[same as prior period, unchanged from 0001262039-23-000038:mdna:85]

[0001262039-24-000020:mdna:75]
Three Months Ended March 31, 2024 and 2023

[0001262039-24-000020:mdna:76]
[same as prior period, unchanged from 0001262039-23-000038:mdna:87]

[0001262039-24-000020:mdna:77]
|  | Three Months Ended |  |  |  |  |
| March 31,2024 |  | March 31,2023 |  |  |  |  |
| Amount |  | % ofRevenue |  | Amount |  | % ofRevenue |  | Change |  | % Change |
| (in millions, except percentages) |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 408.9 |  |  | 30 | % |  | $ | 500.7 |  |  | 40 | % |  | $ | (91.8) |  |  | (18) | % |
| Service | 944.4 |  |  | 70 |  |  | 761.6 |  |  | 60 |  |  | 182.8 |  |  | 24 |  |
| Total revenue | $ | 1,353.3 |  |  | 100 | % |  | $ | 1,262.3 |  |  | 100 | % |  | $ | 91.0 |  |  | 7 | % |
| Revenue by geography: |  |  |  |  |  |  |  |  |  |  |  |
| Americas | $ | 557.0 |  |  | 41 | % |  | $ | 523.5 |  |  | 41 | % |  | $ | 33.5 |  |  | 6 | % |
| EMEA | 539.4 |  |  | 40 |  |  | 478.2 |  |  | 38 |  |  | 61.2 |  |  | 13 |  |
| APAC | 256.9 |  |  | 19 |  |  | 260.6 |  |  | 21 |  |  | (3.7) |  |  | (1) |  |
| Total revenue | $ | 1,353.3 |  |  | 100 | % |  | $ | 1,262.3 |  |  | 100 | % |  | $ | 91.0 |  |  | 7 | % |

[0001262039-24-000020:mdna:78]
Total revenue increased $91.0 million, or 7%, during the three months ended March 31, 2024 compared to the same period last year. We continued to experience diversification of revenue geographically, and across customer and industry segments. Revenue from the Americas and EMEA grew, with EMEA contributing the larger portion of the increase on an absolute dollar basis and on a percentage basis.

[0001262039-24-000020:mdna:79]
Product revenue decreased $91.8 million, or 18%, during the three months ended March 31, 2024 compared to the same period last year, due to the decrease in hardware revenue, partially offset by the increase in software revenue. The decrease in hardware revenue was impacted by the backlog drawdown in the prior period, continued product digestion of previously placed orders, reduced net prices on certain products and macroeconomic conditions. When we fulfill, ship and bill during a quarter to satisfy backlog, this increases our aggregate billings and revenue during any particular quarter. As the supply chain challenges normalize, the growth comparisons versus prior quarters where backlog contributed more to billings become more challenging. For the remainder of 2024, we expect product revenue growth rates will continue to be impacted by drawdown of backlog in earlier periods and earlier pricing actions.

[0001262039-24-000020:mdna:80]
Service revenue increased $182.8 million, or 24%, during the three months ended March 31, 2024 compared to the same period last year. Security subscription revenue increased $115.2 million, or 27%, and technical support and other services revenue increased $67.6 million, or 20%, during the three months ended March 31, 2024 compared to the same period last year. The increase was primarily due to the recognition of revenue from our growing deferred revenue balance related to FortiGuard and other security subscriptions delivered to on-premise and cloud-based environments and strength in unified SASE and SecOps.

[0001262039-24-000020:mdna:81]
Of the service revenue recognized during the three months ended March 31, 2024, 90% was included in the deferred revenue balance as of December 31, 2023. Of the service revenue recognized during the three months ended March 31, 2023, 89% was included in the deferred revenue balance as of December 31, 2022. We expect service revenue growth rates to ease throughout the remainder of 2024 due to slowing deferred revenue and product revenue growth over the past several quarters.

[0001262039-24-000020:mdna:82]
30

[0001262039-24-000020:mdna:83]
[same as prior period, unchanged from 0001262039-23-000038:mdna:93]

[0001262039-24-000020:mdna:84]
|  | Three Months Ended |  |  |  |  |
| March 31,2024 |  | March 31,2023 |  | Change |  | % Change |
| (in millions, except percentages) |
| Cost of revenue: |  |  |  |  |  |  |  |
| Product | $ | 182.8 |  |  | $ | 193.6 |  |  | $ | (10.8) |  |  | (6) | % |
| Service | 121.9 |  |  | 114.2 |  |  | 7.7 |  |  | 7 |  |
| Total cost of revenue | $ | 304.7 |  |  | $ | 307.8 |  |  | $ | (3.1) |  |  | (1) | % |
| Gross margin (%): |  |  |  |  |  |  |  |
| Product | 55.3 | % |  | 61.3 | % |  |  |  |  |
| Service | 87.1 |  |  | 85.0 |  |  |  |  |  |
| Total gross margin | 77.5 | % |  | 75.6 | % |  |  |  |  |

[0001262039-24-000020:mdna:85]
Total gross margin increased 1.9 percentage points during the three months ended March 31, 2024 compared to the same period last year, primarily driven by a shift in the revenue mix and increased service gross margin, partially offset by decreased product gross margin. Revenue mix shifted by 9.5 percentage points from product revenue to service revenue, as a percentage of total revenue.

[0001262039-24-000020:mdna:86]
Product gross margin decreased 6.0 percentage points during the three months ended March 31, 2024 compared to the same period last year, primarily due to inventory related reserves expense and reduced net prices on certain products, partially offset by lower expedite fees and freight costs and a shift in revenue mix from hardware to software. During the first quarter, we lowered list prices on select products. Cost of product revenue was comprised primarily of third-party contract manufacturers’ costs, costs of materials used in production and inventory reserves.

[0001262039-24-000020:mdna:87]
Service gross margin increased 2.1 percentage points during the three months ended March 31, 2024 compared to the same period last year, primarily driven by pricing actions in earlier periods, a revenue mix shift towards higher margin security subscription services and slower labor cost growth. Cost of service revenue was comprised primarily of personnel-related costs, third-party repair and contract fulfillment, data center costs, colocation and cloud provider fees, supplies and facility-related costs.

[0001262039-24-000020:mdna:88]
[same as prior period, unchanged from 0001262039-23-000038:mdna:99]

[0001262039-24-000020:mdna:89]
|  | Three Months Ended |  | Change |  | % Change |
| March 31,2024 |  | March 31,2023 |  |
| Amount |  | % ofRevenue |  | Amount |  | % ofRevenue |  |
| (in millions, except percentages) |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | $ | 173.0 |  |  | 13 | % |  | $ | 151.1 |  |  | 12 | % |  | $ | 21.9 |  |  | 14 | % |
| Sales and marketing | 501.1 |  |  | 37 |  |  | 478.3 |  |  | 38 |  |  | 22.8 |  |  | 5 |  |
| General and administrative | 54.4 |  |  | 4 |  |  | 52.8 |  |  | 4 |  |  | 1.6 |  |  | 3 |  |
| Gain on intellectual property matter | (1.1) |  |  | — |  |  | (1.2) |  |  | — |  |  | 0.1 |  |  | (8) |  |
| Total operating expenses | $ | 727.4 |  |  | 54 | % |  | $ | 681.0 |  |  | 54 | % |  | $ | 46.4 |  |  | 7 | % |

[0001262039-24-000020:mdna:90]
[same as prior period, unchanged from 0001262039-23-000038:mdna:101]

[0001262039-24-000020:mdna:91]
Research and development expense increased $21.9 million, or 14%, during the three months ended March 31, 2024 compared to the same period last year, primarily due to an increase of $15.8 million in personnel-related costs as a result of increased headcount and compensation rates to support the development of new products and continued enhancements to our existing products. In addition, depreciation expenses and other occupancy-related expenses increased $3.7 million. We currently intend to continue investing in our research and development organization, and expect research and development expenses to increase in absolute dollars year over year during the remainder of 2024.

[0001262039-24-000020:mdna:92]
[same as prior period, unchanged from 0001262039-23-000038:mdna:103]

[0001262039-24-000020:mdna:93]
Sales and marketing expense increased $22.8 million, or 5%, during the three months ended March 31, 2024 compared to the same period last year, primarily due to an increase of $21.7 million in personnel-related costs as we increased our sales capacity. The increase in headcount is expected to help drive global market revenue increases. In addition, travel expense increased $2.8 million. The increases were partially offset by a decrease of $5.3 million in marketing-related expenses. We currently intend to continue making investments in sales and marketing resources critical to support our future growth and expect our sales and marketing expenses to increase in absolute dollars year over year during the remainder of 2024.

[0001262039-24-000020:mdna:94]
[same as prior period, unchanged from 0001262039-23-000038:mdna:105]

[0001262039-24-000020:mdna:95]
General and administrative expense increased $1.6 million, or 3%, during the three months ended March 31, 2024 compared to the same period last year, primarily due to an increase of $3.7 million in professional services fees, an increase of $1.4 million in personnel-related costs and an increase of $1.2 million in depreciation expenses and other occupancy-related expenses, partially offset by a decrease of $4.3 million in provision for expected credit losses. We currently expect general and administrative expenses to increase in absolute dollars year over year during the remainder of 2024.

[0001262039-24-000020:mdna:96]
[same as prior period, unchanged from 0001262039-23-000038:mdna:107]

[0001262039-24-000020:mdna:97]
We generated operating income of $321.2 million during the three months ended March 31, 2024, an increase of $47.7 million, or 17%, compared to $273.5 million in the same period last year. Operating margin was 23.7% during the three months ended March 31, 2024, compared to 21.7% in the same period last year. The increase in operating margin was primarily due to 1.9 percentage points increase in gross margin, 0.9 percentage points decrease and 0.2 percentage points decrease in sales and marketing expenses and general and administrative expenses as a percentage of revenue, respectively, partially offset by 0.8 percentage points increase in research and development expense as a percentage of revenue.

[0001262039-24-000020:mdna:98]
Interest income, interest expense and other income (expense)—net

[0001262039-24-000020:mdna:99]
|  | Three Months Ended |  |  |  |  |
| March 31,2024 |  | March 31,2023 |  | Change |  | % Change |
| (in millions, except percentages) |
| Interest income | $ | 32.2 |  |  | $ | 20.6 |  |  | $ | 11.6 |  |  | 56 | % |
| Interest expense | $ | (5.1) |  |  | $ | (5.0) |  |  | $ | (0.1) |  |  | 2 | % |
| Other income (expense)—net | $ | (2.9) |  |  | $ | 2.0 |  |  | $ | (4.9) |  |  | (245) | % |

[0001262039-24-000020:mdna:100]
Interest income increased $11.6 million during the three months ended March 31, 2024 compared to the same period last year, primarily as a result of higher interest rates and investment balances. Interest income varies depending on our average investment balances during the period, types and mix of investments, and market interest rates. Interest expense remained comparatively flat during the three months ended March 31, 2024 compared to the same period last year. The $4.9 million change in Other income (expense)—net during the three months ended March 31, 2024 compared to the same period last year, was primarily due to an increase of $4.4 million foreign currency exchange losses and a $0.3 million lower gain on marketable equity securities.

[0001262039-24-000020:mdna:101]
[same as prior period, unchanged from 0001262039-23-000038:mdna:147]

[0001262039-24-000020:mdna:102]
|  | Three Months Ended |  | Change |  | % Change |
| March 31,2024 |  | March 31,2023 |  |
| (in millions, except percentages) |
| Provision for income taxes | $ | 39.5 |  |  | $ | 21.3 |  |  | $ | 18.2 |  |  | 85 | % |
| Effective tax rate (%) | 11 | % |  | 7 | % |  |  |  |  |

[0001262039-24-000020:mdna:103]
Our effective tax rate was 11% for the three months ended March 31, 2024 compared to an effective tax rate of 7% for the same period last year. The provision for income taxes for the three months ended March 31, 2024 was primarily comprised of U.S. federal and state taxes, withholding taxes and foreign taxes totaling $81.7 million, which were favorably affected by a tax benefit of $24.0 million from the foreign-derived intangible income deduction (the “FDII deduction”) and excess tax benefits from stock-based compensation expense of $18.2 million.

[0001262039-24-000020:mdna:104]
The provision for income taxes for the three months ended March 31, 2023 was comprised of U.S. federal and state taxes, withholding taxes, and foreign taxes totaling $85.8 million, which were favorably affected by a tax benefit of $38.2 million from the FDII deduction and excess tax benefits from stock-based compensation expense of $26.3 million.

[0001262039-24-000020:mdna:105]
Loss from Equity Method Investments

[0001262039-24-000020:mdna:106]
|  | Three Months Ended |  | Change |  | % Change |
| March 31,2024 |  | March 31,2023 |  |
| (in millions, except percentages) |
| Loss from equity method investments | $ | (6.6) |  |  | $ | (22.1) |  |  | $ | 15.5 |  |  | (70) | % |

[0001262039-24-000020:mdna:107]
Loss from equity method investments decreased $15.5 million during the three months ended March 31, 2024 compared to the same period last year, primarily driven by our proportionate share of Linksys’ financial results including our share of the amortization of the basis differences improved over the same period last year.

[0001262039-24-000020:mdna:108]
[same as prior period, unchanged from 0001262039-23-000038:mdna:155]

[0001262039-24-000020:mdna:109]
|  | As of |
|  | March 31,2024 |  | December 31,2023 |
|  | (in millions) |
| Cash and cash equivalents | $ | 1,926.3 |  |  | $ | 1,397.9 |  |
| Short-term and long-term investments | 1,075.4 |  |  | 1,021.5 |  |
| Marketable equity securities | 21.4 |  |  | 21.0 |  |
| Total cash, cash equivalents, investments and marketable equity securities | $ | 3,023.1 |  |  | $ | 2,440.4 |  |
| Working capital | $ | 759.3 |  |  | $ | 709.3 |  |
|  | Three Months Ended |
|  | March 31,2024 |  | March 31,2023 |
|  | (in millions) |
| Net cash provided by operating activities | $ | 830.4 |  |  | $ | 677.5 |  |
| Net cash used in investing activities | (270.3) |  |  | (42.4) |  |
| Net cash used in financing activities | (30.3) |  |  | (13.7) |  |
| Effect of exchange rate changes on cash and cash equivalents | (1.4) |  |  | (0.1) |  |
| Net increase in cash and cash equivalents | $ | 528.4 |  |  | $ | 621.3 |  |

[0001262039-24-000020:mdna:110]
Liquidity and capital resources are primarily impacted by our operating activities, as well as real estate purchases and other capital expenditures, payment of taxes in connection with the net settlement of equity awards and proceeds from the issuance of common stock.

[0001262039-24-000020:mdna:111]
[same as prior period, unchanged from 0001262039-23-000038:mdna:158]

[0001262039-24-000020:mdna:112]
In January 2024, our board of directors approved a $500.0 million increase in the authorized share repurchase amount under the Repurchase Program, bringing the aggregate amount authorized to be repurchased to $7.25 billion of our outstanding common stock. In February 2024, our board of directors approved an extension of the Repurchase Program to February 28, 2025. As of March 31, 2024, approximately $1.03 billion remained available for future share repurchases.

[0001262039-24-000020:mdna:113]
We expect to continue to increase our data centers, PoPs, office and warehouse capacity to support growth and the expansion of existing services or introduction of new services. As we purchase new properties, we will work to incorporate these properties into the environmental goals we have established. We estimate capital expenditures to be between approximately $350.0 million and $400.0 million in 2024.

[0001262039-24-000020:mdna:114]
We believe that our cash provided by operating activities, together with our existing cash, cash equivalents and investments will be sufficient to meet our anticipated cash needs and do not currently intend to retire our Senior Notes early. Refer to Note 9, Debt, in Part I, Item 1 of this Quarterly Report on Form 10-Q for information on the Senior Notes. As of March 31, 2024, the long-term debt, net of unamortized discount and debt issuance costs, was $992.8 million.

[0001262039-24-000020:mdna:115]
We purchase components of our inventory from certain suppliers and use several independent contract manufacturers to provide manufacturing services for our products. During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, we enter into agreements with contract manufacturers and suppliers that allow them to procure inventory based upon criteria as defined by us or establish the parameters defining our requirements. A significant portion of our reported purchase commitments arising from these agreements consists of firm, non-cancelable and unconditional commitments. Certain of these inventory purchase commitments with contract manufacturers and suppliers relate to arrangements to secure supply and pricing for certain product components for multi-year periods. In certain instances, these agreements allow us the option to reschedule and adjust our requirements based on our business needs prior to firm orders being placed.

[0001262039-24-000020:mdna:116]
These inventory purchase commitments as of March 31, 2024 totaled $629.7 million, a decrease of $7.6 million compared to $637.3 million as of December 31, 2023 due to fulfillment of customer demand as our supply availability improved and our continued efforts to work with contract manufacturers and suppliers to optimize our inventory and purchase commitment position. As of March 31, 2024 and December 31, 2023, the liability for these inventory purchase commitments was $115.0 million and $84.7 million, respectively, and was recorded in accrued liabilities on our condensed consolidated balance sheets.

[0001262039-24-000020:mdna:117]
We increased our purchase commitments in prior years to address significant supply constraints seen industry-wide due to component shortages. Our agreements secured supply and pricing for certain product components with contract manufacturers to meet customer demand and to address extended lead times.

[0001262039-24-000020:mdna:118]
Inventory and supply chain management remain areas of focus as we balance the need to maintain supply chain flexibility to help ensure competitive lead times with the risk of inventory obsolescence because of supply constraints, rapidly changing technology and customer requirements. We believe the amount of our inventory and purchase commitments is appropriate for our current and expected customer demand and revenue levels.

[0001262039-24-000020:mdna:119]
We also have open purchase orders and contractual obligations in the ordinary course of business for which we have not received goods or services. As of March 31, 2024, we had $40.4 million in other contractual commitments having a remaining term in excess of one year that are non-cancelable.

[0001262039-24-000020:mdna:120]
There have been no significant changes to our leases as disclosed in our Annual Report on Form 10-K for the year ended December 31, 2023.

[0001262039-24-000020:mdna:121]
As of March 31, 2024, our cash, cash equivalents and short-term and long-term investments of $3.00 billion were invested primarily in deposit accounts, commercial paper, corporate debt securities, U.S. government and agency securities, certificates of deposit and term deposits and money market funds. It is our investment policy to invest excess cash in a manner that preserves capital, provides liquidity and generates return without significantly increasing risk. We do not enter into investments for trading or speculative purposes.

[0001262039-24-000020:mdna:122]
The amount of cash, cash equivalents and investments held by our international subsidiaries was $191.4 million as of March 31, 2024 and $199.9 million as of December 31, 2023.

[0001262039-24-000020:mdna:123]
We believe that our existing cash and cash equivalents and cash flow from operations will be sufficient for at least the next 12 months to meet our requirements and plans for cash, including meeting our working capital requirements and capital expenditure requirements. In the long term, our ability to support our requirements and plans for cash, including our working capital and capital expenditure requirements will depend on many factors, including our growth rate; the timing and amount of our share repurchases; the expansion of sales and marketing activities, pricing actions, the introduction of new and enhanced products and services offerings; the continuing market acceptance of our products; the timing and extent of spending to support development efforts; our investments in purchasing, developing or leasing real estate; cash paid for taxes and macroeconomic impacts such as rising inflation and interest rates; and the war in Ukraine and the Israel-Hamas war. Historically, we have required capital principally to fund our working capital needs, share repurchases, capital expenditures and acquisition activities.

[0001262039-24-000020:mdna:124]
In the event that additional financing is required from outside sources, we may not be able to raise it on terms acceptable to us or at all.

[0001262039-24-000020:mdna:125]
As of March 31, 2024, we did not have any relationships with unconsolidated organizations or financial partnerships, such as structured finance or special purpose entities that would have been established for the purpose of facilitating off-balance sheet arrangements or other contractually narrow or limited purposes.

[0001262039-24-000020:mdna:126]
[same as prior period, unchanged from 0001262039-23-000038:mdna:170]

[0001262039-24-000020:mdna:127]
Cash generated by operating activities is our primary source of liquidity. It is primarily comprised of net income, as adjusted for non-cash items and changes in operating assets and liabilities. Non-cash adjustments consist primarily of amortization of deferred contract costs, stock-based compensation and depreciation and amortization. Changes in operating assets and liabilities consist primarily of changes in accounts receivable—net, accrued liabilities, deferred tax assets, deferred contract costs, accounts payable, deferred revenue and inventory.

[0001262039-24-000020:mdna:128]
Our operating activities during the three months ended March 31, 2024 provided cash flows of $830.4 million, an increase of $152.9 million compared to the same period last year, as a result of the continued growth of our business, improved profitability and our ability to successfully manage our working capital. Changes in operating assets and liabilities primarily resulted from an increase in sales of our security subscription services and technical support services to new and existing customers, as reflected by an increase of $54.8 million in our deferred revenue during the three months ended March 31, 2024. In addition, changes in operating assets and liabilities were driven by a decrease of $405.6 million in accounts receivable—net, an increase of $105.0 million in accrued liabilities, an increase of $73.9 million in deferred tax assets, an increase of $66.5 million in deferred contract costs, a decrease of $61.6 million in accounts payable and a decrease of $36.5 million in inventory.

[0001262039-24-000020:mdna:129]
[same as prior period, unchanged from 0001262039-23-000038:mdna:175]

[0001262039-24-000020:mdna:130]
The changes in cash flows from investing activities primarily relate to timing of purchases, maturities and sales of investments, purchases of property and equipment, investments in various companies and business acquisitions. Historically, in making a lease-versus-ownership decision related to warehouse, office or data center space, we have considered various factors including financial metrics, expected long-term growth rates, time to market and changes in asset values. In certain cases, we have elected to own a facility if we believe that purchasing or developing buildings rather than leasing is more closely aligned with our long-term strategy. We expect to make similar decisions in the future. We may also make cash payments in connection with future business combinations.

[0001262039-24-000020:mdna:131]
During the three months ended March 31, 2024, cash used in investing activities was $270.3 million, primarily driven by $221.9 million used for the purchases of property and equipment, $42.7 million spent for purchases of investments, net of maturities and sales of investments and $5.7 million used for the acquisitions of certain assets and liabilities in a business combination, net of cash.

[0001262039-24-000020:mdna:132]
[same as prior period, unchanged from 0001262039-23-000038:mdna:178]

[0001262039-24-000020:mdna:133]
The changes in cash flows from financing activities primarily relate to repurchase and retirement of common stock, and taxes paid related to net share settlement of equity awards, net of proceeds from the issuance of common stock under our Amended and Restated Fortinet, Inc. 2009 Equity Incentive Plan.

[0001262039-24-000020:mdna:134]
During the three months ended March 31, 2024, cash used in financing activities was $30.3 million, primarily driven by $29.5 million used to pay tax withholding, net of proceeds from the issuance of common stock.
