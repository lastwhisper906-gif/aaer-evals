# FTNT note change history — 0001262039-20-000032 → 0001262039-20-000053


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2020-08-06):
[0001262039-20-000053:note_history:1]
COMMITMENTS AND CONTINGENCIES
The following table summarizes our inventory purchase commitments as of June 30, 2020 (in millions):
  (was, 2020-05-07, similarity 0.8235):
[0001262039-20-000032:note_history:1]
The following table summarizes our inventory purchase commitments as of March 31, 2020 (in millions):

- changed (2020-08-06):
[0001262039-20-000053:note_history:2]
|  | Total |  | 2020 |  | 2021 |  | 2022 |  | 2023 |  | 2024 |  | Thereafter |
| Inventory purchase commitments | $ | 282.1 |  |  | $ | 281.8 |  |  | $ | 0.3 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
  (was, 2020-05-07, similarity 0.9942):
[0001262039-20-000032:note_history:2]
|  | Total |  | 2020 |  | 2021 |  | 2022 |  | 2023 |  | 2024 |  | Thereafter |
| Inventory purchase commitments | $ | 247.2 |  |  | $ | 247.2 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |

- changed (2020-08-06):
[0001262039-20-000053:note_history:3]
Inventory Purchase Commitments—Our independent contract manufacturers procure components and build our products based on our forecasts. These forecasts are based on estimates of future demand for our products, which are in turn based on historical trends and an analysis from our sales and marketing organizations, adjusted for overall market conditions. In order to reduce manufacturing lead times and plan for adequate component supply, we may issue purchase orders to some of our independent contract manufacturers, which may not be cancelable. As of June 30, 2020, we had $282.1 million of open purchase orders with our independent contract manufacturers that may not be cancelable.
  (was, 2020-05-07, similarity 0.6912):
[0001262039-20-000032:note_history:3]
Inventory Purchase Commitments—Our independent contract manufacturers procure components and build our products based on our forecasts. These forecasts are based on estimates of future demand for our products, which are in turn based on historical trends and an analysis from our sales and marketing organizations, adjusted for overall market conditions. In

- changed (2020-08-06):
[0001262039-20-000053:note_history:4]
Other Contractual Commitments and Open Purchase Orders—In addition to commitments with contract manufacturers, we have open purchase orders and contractual obligations in the ordinary course of business for which we have not received goods or services. As of June 30, 2020, we had $27.8 million in other contractual commitments having a remaining term in excess of one year that may not be cancelable.
  (was, 2020-05-07, similarity 0.9885):
[0001262039-20-000032:note_history:4]
Other Contractual Commitments and Open Purchase Orders—In addition to commitments with contract manufacturers, we have open purchase orders and contractual obligations in the ordinary course of business for which we have not received goods or services. As of March 31, 2020, we had $10.9 million in other contractual commitments having a remaining term in excess of one year that may not be cancelable.

- changed (2020-08-06):
[0001262039-20-000053:note_history:5]
Indemnification and Other Matters—Under the indemnification provisions of our standard sales contracts, we agree to defend our customers against third-party claims asserting various allegations such as product defects and infringement of certain IP rights, which may include patents, copyrights, trademarks or trade secrets, and to pay judgments entered on such claims. In some contracts, our exposure under these indemnification provisions is limited by the terms of the contracts to certain defined limits, such as the total amount paid by our customer under the agreement. However, certain agreements include covenants, penalties and indemnification provisions including and beyond indemnification for third-party claims of IP infringement that could potentially expose us to losses in excess of the amount received under the agreement, and in some instances to potential liability that is not contractually limited. Although from time to time there are indemnification claims asserted against us and currently there are pending indemnification claims, to date there have been no material awards under such indemnification provisions.
  (was, 2020-05-07, similarity 0.9921):
[0001262039-20-000032:note_history:5]
Indemnification and Other Matters—Under the indemnification provisions of our standard sales contracts, we agree to defend our customers against third-party claims asserting various allegations such as product defects and infringement of certain IP rights, which may include patents, copyrights, trademarks or trade secrets, and to pay judgments entered on such claims. In some contracts, our exposure under these indemnification provisions is limited by the terms of the contracts to certain defined limits, such as the total amount paid by our customer under the agreement. However, certain agreements include covenants, penalties and indemnification provisions including and beyond indemnification for third-party claims of IP infringement, that could potentially expose us to losses in excess of the amount received under the agreement, and in some instances to potential liability that is not contractually limited. To date, although from time to time there are indemnification claims asserted against us and currently there are pending indemnification claims, there have been no material awards under such indemnification provisions.

- added (2020-08-06):
[0001262039-20-000053:note_history:6]
Similar to other security companies and companies in other industries, we have in the past experienced, and we may in the future experience, cybersecurity threats, malicious activity directed against our information technology infrastructure or unauthorized attempts to gain access to our and our customers’ sensitive information and systems. We currently are unaware of any existing claims or proceedings related to these types of matters, including any that we believe are likely to have a material adverse effect on our financial position.

- removed (2020-08-06):
[0001262039-20-000032:note_history:7]
COMMITMENTS AND CONTINGENCIES

- removed (2020-08-06):
[0001262039-20-000032:note_history:8]
order to reduce manufacturing lead times and plan for adequate component supply, we may issue purchase orders to some of our independent contract manufacturers, which may not be cancelable. As of March 31, 2020, we had $247.2 million of open purchase orders with our independent contract manufacturers that may not be cancelable.

- removed (2020-08-06):
[0001262039-20-000032:note_history:9]
Periodically, we, like other security companies and companies in other industries, may experience cybersecurity threats, malicious activity directed against our information technology infrastructure and unauthorized attempts to gain access to our and our customers’ sensitive information and systems.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2020-08-06):
[0001262039-20-000053:note_history:10]
SUMMARY OF SIGNIFICANT ACCOUNTING POLICIES
Basis of Presentation and Preparation—The unaudited condensed consolidated financial statements of Fortinet, Inc. and its wholly owned subsidiaries (collectively, “we,” “us” or “our”) have been prepared in accordance with generally accepted accounting principles in the United States (“GAAP”) for interim financial information, as well as the instructions to Form 10-Q pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (the “SEC”). Accordingly, they do not include all of the information and footnotes required by GAAP for complete financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the year ended December 31, 2019, contained in our Annual Report on Form 10-K filed with the SEC on February 26, 2020. In the opinion of management, all adjustments, which includes normal recurring adjustments, considered necessary for a fair presentation have been included. All intercompany balances, transactions and cash flows have been eliminated. The results of operations for the three and six months ended June 30, 2020 are not necessarily indicative of the results for the full year or for any future periods. The condensed consolidated balance sheet as of December 31, 2019 is derived from the audited consolidated financial statements for the year ended December 31, 2019. For 2020, the amounts previously reported as Income taxes payable are included in Accrued liabilities. Prior periods have been reclassified to conform with current period presentation.
  (was, 2020-05-07, similarity 0.6968):
[0001262039-20-000032:note_history:10]
Basis of Presentation and Preparation—The unaudited condensed consolidated financial statements of Fortinet, Inc. and its wholly owned subsidiaries (collectively, “we,” “us” or “our”) have been prepared in accordance with generally accepted accounting principles in the United States (“GAAP”) for interim financial information, as well as the instructions to Form 10-Q pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (the “SEC”). Accordingly, they do not include all of the information and footnotes required by GAAP for complete financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the year ended December 31, 2019, contained in our Annual Report on Form 10-K filed with the SEC on February 26, 2020. In the opinion of management, all adjustments, which includes normal recurring adjustments, considered necessary for a fair presentation have been included. All intercompany balances, transactions and cash flows have been eliminated. The results of operations for the three months ended March 31, 2020 are not necessarily indicative of the results for the full year or for any future periods. The condensed consolidated balance sheet as of December 31, 2019 is derived from the audited consolidated financial statements for the year ended December 31, 2019. For 2020, the amounts previously reported as Income taxes payable are included in Accrued liabilities. Prior periods have been reclassified to conform with current period presentation.

- changed (2020-08-06):
[0001262039-20-000053:note_history:11]
There have been no material changes to our significant accounting policies as of and for the three and six months ended June 30, 2020.
  (was, 2020-05-07, similarity 0.9317):
[0001262039-20-000032:note_history:11]
There have been no material changes to our significant accounting policies as of and for the three months ended March 31, 2020.

- changed (2020-08-06):
[0001262039-20-000053:note_history:12]
In December 2019, the FASB issued ASU 2019-12—Income Taxes (Topic 740): Simplifying the Accounting for Income Taxes. The amendments in ASU 2019-12 simplify the accounting for income taxes by removing certain exceptions to the general principles in Topic 740. The amendments also improve consistent application and simplification of GAAP for other areas of Topic 740 by clarifying and amending existing guidance. ASU 2019-12 is effective for us beginning on January 1, 2021. We are currently evaluating the impact of ASU 2019-12 on our condensed consolidated financial statements.
  (was, 2020-05-07, similarity 0.9588):
[0001262039-20-000032:note_history:12]
In December 2019, the FASB issued ASU 2019-12—Income Taxes (Topic 740): Simplifying the Accounting for Income Taxes. The amendments in ASU 2019-12 simplify the accounting for income taxes by removing certain exceptions to the general principles in Topic 740. The amendments also improve consistent application and simplification of GAAP for other areas of Topic 740 by clarifying and amending existing guidance. ASU 2019-12 is effective for us beginning on January 1, 2021. Early adoption of the amendments is permitted. We are currently evaluating the impact of ASU 2019-12 on our condensed consolidated financial statements.

- removed (2020-08-06):
[0001262039-20-000032:note_history:13]
SUMMARY OF SIGNIFICANT ACCOUNTING POLICIES


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2020-08-06):
[0001262039-20-000053:note_history:14]
|  | Three Months Ended |  |  |  | Six Months Ended |  |  |
|  | June 30,2020 |  | June 30,2019 |  | June 30,2020 |  | June 30,2019 |
| Product | $ | 211.9 |  |  | $ | 189.9 |  |  | $ | 404.2 |  |  | $ | 352.6 |  |
| Service: |  |  |  |  |  |  |  |
| Security subscription | 222.6 |  |  | 183.1 |  |  | 434.0 |  |  | 352.7 |  |
| Technical support and other | 181.0 |  |  | 148.7 |  |  | 354.2 |  |  | 289.0 |  |
| Total service revenue | 403.6 |  |  | 331.8 |  |  | 788.2 |  |  | 641.7 |  |
| Total revenue | $ | 615.5 |  |  | $ | 521.7 |  |  | $ | 1,192.4 |  |  | $ | 994.3 |  |
  (was, 2020-05-07, similarity 0.6878):
[0001262039-20-000032:note_history:14]
|  | Three Months Ended |
|  | March 31, 2020 |  | March 31, 2019 |
| Product | $ | 192.3 |  |  | $ | 162.7 |  |
| Service: |  |  |  |
| Security subscription | 211.4 |  |  | 169.6 |  |
| Technical support and other | 173.2 |  |  | 140.3 |  |
| Total service revenue | 384.6 |  |  | 309.9 |  |
| Total revenue | $ | 576.9 |  |  | $ | 472.6 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2020-08-06):
[0001262039-20-000053:note_history:15]
REVENUE RECOGNITION
Our revenue consists of product and service revenue. Product revenue is generated by sales of our FortiGate products and other hardware and software solutions. Service revenue relates to sales of our security subscription services, which mainly consist of our FortiGuard security solutions, as well as our FortiCare technical support services and other services.
  (was, 2020-05-07, similarity 0.8304):
[0001262039-20-000032:note_history:15]
Our revenue consists of product and service revenue. Product revenue is generated by sales of our FortiGate products and other hardware and software solutions. Service revenue relates to sales of our FortiGuard security subscription, FortiCare technical support services and other services.

- changed (2020-08-06):
[0001262039-20-000053:note_history:16]
|  | Three Months Ended |  |  |  | Six Months Ended |  |  |
|  | June 30,2020 |  | June 30,2019 |  | June 30,2020 |  | June 30,2019 |
| Product | $ | 211.9 |  |  | $ | 189.9 |  |  | $ | 404.2 |  |  | $ | 352.6 |  |
| Service: |  |  |  |  |  |  |  |
| Security subscription | 222.6 |  |  | 183.1 |  |  | 434.0 |  |  | 352.7 |  |
| Technical support and other | 181.0 |  |  | 148.7 |  |  | 354.2 |  |  | 289.0 |  |
| Total service revenue | 403.6 |  |  | 331.8 |  |  | 788.2 |  |  | 641.7 |  |
| Total revenue | $ | 615.5 |  |  | $ | 521.7 |  |  | $ | 1,192.4 |  |  | $ | 994.3 |  |
  (was, 2020-05-07, similarity 0.6878):
[0001262039-20-000032:note_history:16]
|  | Three Months Ended |
|  | March 31, 2020 |  | March 31, 2019 |
| Product | $ | 192.3 |  |  | $ | 162.7 |  |
| Service: |  |  |  |
| Security subscription | 211.4 |  |  | 169.6 |  |
| Technical support and other | 173.2 |  |  | 140.3 |  |
| Total service revenue | 384.6 |  |  | 309.9 |  |
| Total revenue | $ | 576.9 |  |  | $ | 472.6 |  |

- changed (2020-08-06):
[0001262039-20-000053:note_history:17]
During the three months ended June 30, 2020 and June 30, 2019, we recognized $307.9 million and $252.0 million in service revenue that was included in the deferred revenue balance as of December 31, 2019 and December 31, 2018, respectively. During the six months ended June 30, 2020 and June 30, 2019, we recognized $656.8 million and $540.6 million in service revenue that was included in the deferred revenue balance as of December 31, 2019 and December 31, 2018, respectively.
  (was, 2020-05-07, similarity 0.6117):
[0001262039-20-000032:note_history:17]
During the three months ended March 31, 2020 and March 31, 2019, we recognized $348.9 million and $288.6 million in service revenue that was included in the deferred revenue balance as of December 31, 2019 and December 31, 2018, respectively.

- changed (2020-08-06):
[0001262039-20-000053:note_history:18]
As of June 30, 2020, the aggregate amount of the transaction price allocated to remaining performance obligations was $2.32 billion, which was substantially comprised of deferred security subscription and technical support services revenue. We expect to recognize approximately $1.28 billion as revenue over the next 12 months and the remainder thereafter.
  (was, 2020-05-07, similarity 0.9869):
[0001262039-20-000032:note_history:18]
As of March 31, 2020, the aggregate amount of the transaction price allocated to remaining performance obligations was $2.23 billion, which was substantially comprised of deferred security subscription and technical support services revenue. We expect to recognize approximately $1.23 billion as revenue over the next 12 months and the remainder thereafter.

- changed (2020-08-06):
[0001262039-20-000053:note_history:19]
Trade accounts receivable are recorded at the invoiced amount. On January 1, 2020, we adopted Topic 326, which provides guidance on how to measure credit losses on financial instruments, including accounts receivable. Prior to our adoption of Topic 326, our accounts receivable balance was reduced by an allowance for doubtful accounts that we determined based on our assessment of the collectability of customer accounts. Under Topic 326, our accounts receivable balance is reduced by an allowance for credit losses. We measure expected credit losses of accounts receivable on a collective (pool) basis, aggregating accounts receivable that are either current or no more than 60 days past due, and aggregating accounts receivable that are more than 60 days past due. We apply a credit-loss percentage to each of the pools that is based on our historical credit losses. We review whether each of our significant accounts receivable that is more than 60 days past due
  (was, 2020-05-07, similarity 0.9891):
[0001262039-20-000032:note_history:19]
Trade accounts receivable are recorded at the invoiced amount. On January 1, 2020, we adopted Topic 326, which provides guidance on how to measure credit losses on financial instruments, including accounts receivable. Prior to our adoption of Topic 326, our accounts receivable balance was reduced by an allowance for doubtful accounts that we determined based on our assessment of the collectability of customer accounts. Under Topic 326, our accounts receivable balance is reduced by an allowance for credit losses. We measure expected credit losses of accounts receivable on a collective (pool) basis, aggregating accounts receivable that are either current or no more than 60 days past due, and aggregating accounts receivable that are more than 60 days past due. We apply a credit-loss percentage to each of the pools that is based on our historical credit losses. We review whether each of our significant accounts receivable that is more than 60 days past due continues to exhibit

- changed (2020-08-06):
[0001262039-20-000053:note_history:20]
continues to exhibit similar risk characteristics with the other accounts receivable in the pool. If we determine that it does not, we evaluate it for expected credit losses on an individual basis.
  (was, 2020-05-07, similarity 0.9437):
[0001262039-20-000032:note_history:20]
similar risk characteristics with the other accounts receivable in the pool. If we determine that it does not, we evaluate it for expected credit losses on an individual basis.

- added (2020-08-06):
[0001262039-20-000053:note_history:21]
The COVID-19 pandemic and the recent economic downturn prompted us to perform additional credit reviews of our existing customers, including obtaining recent credit reports and reviewing their latest available statements of financial position. In addition, we have seen an increase in requests for extended payment terms. After performing our additional reviews, we increased the allowance for credit losses for certain accounts receivable.

- changed (2020-08-06):
[0001262039-20-000053:note_history:22]
The allowance for credit losses was $2.2 million as of June 30, 2020, and the allowance for doubtful accounts was $1.2 million as of December 31, 2019. Provisions, write-offs and recoveries were not material during the six months ended June 30, 2020.
  (was, 2020-05-07, similarity 0.8652):
[0001262039-20-000032:note_history:22]
The allowance for credit losses was $1.1 million as of March 31, 2020, and the allowance for doubtful accounts was $1.2 million as of December 31, 2019. Provisions, write-offs and recoveries were not material during the three months ended March 31, 2020.

- changed (2020-08-06):
[0001262039-20-000053:note_history:23]
Sales commissions earned by our sales force are considered incremental and recoverable costs of obtaining a contract with a customer. The amortization of deferred contract costs is included in sales and marketing expense in our condensed consolidated statements of income. Amortization of deferred contract costs during the three months ended June 30, 2020 and June 30, 2019 were $33.2 million and $25.9 million, respectively. Amortization of deferred contract costs during the six months ended June 30, 2020 and June 30, 2019 were $64.5 million and $51.0 million, respectively.
  (was, 2020-05-07, similarity 0.8205):
[0001262039-20-000032:note_history:23]
Sales commissions earned by our sales force are considered incremental and recoverable costs of obtaining a contract with a customer. The amortization of deferred contract costs is included in sales and marketing expense in our condensed consolidated statements of income. Amortization of deferred contract costs during the three months ended March 31, 2020 and March 31, 2019 were $31.3 million and $25.1 million, respectively.

- removed (2020-08-06):
[0001262039-20-000032:note_history:24]
REVENUE RECOGNITION

- removed (2020-08-06):
[0001262039-20-000032:note_history:25]
The COVID-19 pandemic and the recent economic downturn prompted us to perform additional credit reviews of our existing customers, including obtaining recent credit reports and reviewing their latest available statements of financial position. After performing our additional reviews, we determined that, while there may be delays in our collections, the risk of credit loss on our trade accounts receivable as of March 31, 2020 was expected to be consistent with prior periods and that our methodology for estimating credit losses was appropriate.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- changed (2020-08-06):
[0001262039-20-000053:note_history:26]
SUBSEQUENT EVENTS
Share Repurchase
  (was, 2020-05-07, similarity 0.64):
[0001262039-20-000032:note_history:26]
SUBSEQUENT EVENT

- added (2020-08-06):
[0001262039-20-000053:note_history:27]
In July 2020, our board of directors approved a $500.0 million increase in the authorized stock repurchase amount under the Repurchase Program and extended the term of the Repurchase Program to February 28, 2022, bringing the aggregate amount authorized to be repurchased to $3.0 billion. As of August 6, 2020, $1.05 billion remained available for future share repurchases under the Repurchase Program.

- added (2020-08-06):
[0001262039-20-000053:note_history:28]
Business Combination

- added (2020-08-06):
[0001262039-20-000053:note_history:29]
On July 20, 2020, we acquired OPAQ Networks, Inc. (“OPAQ”), a privately held Secure Access Service Edge cloud provider. We acquired OPAQ for approximately $13.0 million in cash consideration, subject to certain adjustments.

- added (2020-08-06):
[0001262039-20-000053:note_history:30]
We are currently in the process of evaluating the business combination accounting, including the consideration transferred and the initial purchase price allocation.

- removed (2020-08-06):
[0001262039-20-000032:note_history:31]
Share repurchase

- removed (2020-08-06):
[0001262039-20-000032:note_history:32]
Subsequent to March 31, 2020 through the filing of this Quarterly Report on Form 10-Q, we repurchased 1.5 million shares of our common stock under the Repurchase Program, for an aggregate purchase price of $146.1 million.
