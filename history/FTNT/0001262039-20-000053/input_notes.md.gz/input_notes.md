# FTNT notes — 0001262039-20-000053


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001262039-20-000053:notes:1]
SUMMARY OF SIGNIFICANT ACCOUNTING POLICIES
Basis of Presentation and Preparation—The unaudited condensed consolidated financial statements of Fortinet, Inc. and its wholly owned subsidiaries (collectively, “we,” “us” or “our”) have been prepared in accordance with generally accepted accounting principles in the United States (“GAAP”) for interim financial information, as well as the instructions to Form 10-Q pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (the “SEC”). Accordingly, they do not include all of the information and footnotes required by GAAP for complete financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the year ended December 31, 2019, contained in our Annual Report on Form 10-K filed with the SEC on February 26, 2020. In the opinion of management, all adjustments, which includes normal recurring adjustments, considered necessary for a fair presentation have been included. All intercompany balances, transactions and cash flows have been eliminated. The results of operations for the three and six months ended June 30, 2020 are not necessarily indicative of the results for the full year or for any future periods. The condensed consolidated balance sheet as of December 31, 2019 is derived from the audited consolidated financial statements for the year ended December 31, 2019. For 2020, the amounts previously reported as Income taxes payable are included in Accrued liabilities. Prior periods have been reclassified to conform with current period presentation.

[0001262039-20-000053:notes:2]
[same as prior period, unchanged from 0001262039-20-000032:notes:3]

[0001262039-20-000053:notes:3]
There have been no material changes to our significant accounting policies as of and for the three and six months ended June 30, 2020.

[0001262039-20-000053:notes:4]
Recently Adopted Accounting Standards

[0001262039-20-000053:notes:5]
[same as prior period, unchanged from 0001262039-20-000032:notes:6]

[0001262039-20-000053:notes:6]
In June 2016, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) 2016-13—Financial Instruments—Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments (“Topic 326”), which provides guidance on how an entity should measure credit losses on financial instruments. The standard replaces the existing incurred loss model with an expected credit loss model for financial assets measured at amortized cost, including trade receivables, and requires that credit losses on available-for-sale debt securities be presented as an allowance rather than as a write-down. The new approach to estimating credit losses (referred to as the current expected credit losses model) generally accelerates recognition of credit losses. We adopted Topic 326 on January 1, 2020 using the modified retrospective method. The adoption of this standard did not have a material impact on our condensed consolidated financial statements.

[0001262039-20-000053:notes:7]
[same as prior period, unchanged from 0001262039-20-000032:notes:8]

[0001262039-20-000053:notes:8]
In August 2018, the FASB issued ASU 2018-15—Intangibles—Goodwill and Other—Internal-Use Software (Subtopic 350-40): Customer’s Accounting for Implementation Costs Incurred in a Cloud Computing Arrangement That Is a Service Contract, which requires a customer in a cloud computing arrangement that is a service contract to follow the internal-use software guidance in Accounting Standards Codification (“ASC”) Topic 350, Intangibles—Goodwill and Other, to determine which implementation costs to capitalize as assets or expense as incurred. We adopted ASU 2018-15 on January 1, 2020. The adoption of this standard did not have a material impact on our condensed consolidated financial statements.

[0001262039-20-000053:notes:9]
[same as prior period, unchanged from 0001262039-20-000032:notes:10]

[0001262039-20-000053:notes:10]
In August 2018, the FASB issued ASU 2018-13—Fair Value Measurement (Topic 820): Disclosure Framework—Changes to the Disclosure Requirements for Fair Value Measurement, which eliminates, adds and modifies certain disclosure requirements for fair value measurements in ASC 820, Fair Value Measurement, as part of its disclosure framework project. We adopted ASU 2018-13 on January 1, 2020. The adoption of this standard did not have a material impact on our disclosures.

[0001262039-20-000053:notes:11]
[same as prior period, unchanged from 0001262039-20-000032:notes:12]

[0001262039-20-000053:notes:12]
[same as prior period, unchanged from 0001262039-20-000032:notes:13]

[0001262039-20-000053:notes:13]
In December 2019, the FASB issued ASU 2019-12—Income Taxes (Topic 740): Simplifying the Accounting for Income Taxes. The amendments in ASU 2019-12 simplify the accounting for income taxes by removing certain exceptions to the general principles in Topic 740. The amendments also improve consistent application and simplification of GAAP for other areas of Topic 740 by clarifying and amending existing guidance. ASU 2019-12 is effective for us beginning on January 1, 2021. We are currently evaluating the impact of ASU 2019-12 on our condensed consolidated financial statements.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001262039-20-000053:notes:14]
REVENUE RECOGNITION
Our revenue consists of product and service revenue. Product revenue is generated by sales of our FortiGate products and other hardware and software solutions. Service revenue relates to sales of our security subscription services, which mainly consist of our FortiGuard security solutions, as well as our FortiCare technical support services and other services.

[0001262039-20-000053:notes:15]
[same as prior period, unchanged from 0001262039-20-000032:notes:17]

[0001262039-20-000053:notes:16]
[same as prior period, unchanged from 0001262039-20-000032:notes:18]

[0001262039-20-000053:notes:17]
|  | Three Months Ended |  |  |  | Six Months Ended |  |  |
|  | June 30,2020 |  | June 30,2019 |  | June 30,2020 |  | June 30,2019 |
| Product | $ | 211.9 |  |  | $ | 189.9 |  |  | $ | 404.2 |  |  | $ | 352.6 |  |
| Service: |  |  |  |  |  |  |  |
| Security subscription | 222.6 |  |  | 183.1 |  |  | 434.0 |  |  | 352.7 |  |
| Technical support and other | 181.0 |  |  | 148.7 |  |  | 354.2 |  |  | 289.0 |  |
| Total service revenue | 403.6 |  |  | 331.8 |  |  | 788.2 |  |  | 641.7 |  |
| Total revenue | $ | 615.5 |  |  | $ | 521.7 |  |  | $ | 1,192.4 |  |  | $ | 994.3 |  |

[0001262039-20-000053:notes:18]
[same as prior period, unchanged from 0001262039-20-000032:notes:20]

[0001262039-20-000053:notes:19]
During the three months ended June 30, 2020 and June 30, 2019, we recognized $307.9 million and $252.0 million in service revenue that was included in the deferred revenue balance as of December 31, 2019 and December 31, 2018, respectively. During the six months ended June 30, 2020 and June 30, 2019, we recognized $656.8 million and $540.6 million in service revenue that was included in the deferred revenue balance as of December 31, 2019 and December 31, 2018, respectively.

[0001262039-20-000053:notes:20]
[same as prior period, unchanged from 0001262039-20-000032:notes:22]

[0001262039-20-000053:notes:21]
As of June 30, 2020, the aggregate amount of the transaction price allocated to remaining performance obligations was $2.32 billion, which was substantially comprised of deferred security subscription and technical support services revenue. We expect to recognize approximately $1.28 billion as revenue over the next 12 months and the remainder thereafter.

[0001262039-20-000053:notes:22]
[same as prior period, unchanged from 0001262039-20-000032:notes:24]

[0001262039-20-000053:notes:23]
Trade accounts receivable are recorded at the invoiced amount. On January 1, 2020, we adopted Topic 326, which provides guidance on how to measure credit losses on financial instruments, including accounts receivable. Prior to our adoption of Topic 326, our accounts receivable balance was reduced by an allowance for doubtful accounts that we determined based on our assessment of the collectability of customer accounts. Under Topic 326, our accounts receivable balance is reduced by an allowance for credit losses. We measure expected credit losses of accounts receivable on a collective (pool) basis, aggregating accounts receivable that are either current or no more than 60 days past due, and aggregating accounts receivable that are more than 60 days past due. We apply a credit-loss percentage to each of the pools that is based on our historical credit losses. We review whether each of our significant accounts receivable that is more than 60 days past due

[0001262039-20-000053:notes:24]
continues to exhibit similar risk characteristics with the other accounts receivable in the pool. If we determine that it does not, we evaluate it for expected credit losses on an individual basis.

[0001262039-20-000053:notes:25]
The COVID-19 pandemic and the recent economic downturn prompted us to perform additional credit reviews of our existing customers, including obtaining recent credit reports and reviewing their latest available statements of financial position. In addition, we have seen an increase in requests for extended payment terms. After performing our additional reviews, we increased the allowance for credit losses for certain accounts receivable.

[0001262039-20-000053:notes:26]
The allowance for credit losses was $2.2 million as of June 30, 2020, and the allowance for doubtful accounts was $1.2 million as of December 31, 2019. Provisions, write-offs and recoveries were not material during the six months ended June 30, 2020.

[0001262039-20-000053:notes:27]
[same as prior period, unchanged from 0001262039-20-000032:notes:29]

[0001262039-20-000053:notes:28]
Sales commissions earned by our sales force are considered incremental and recoverable costs of obtaining a contract with a customer. The amortization of deferred contract costs is included in sales and marketing expense in our condensed consolidated statements of income. Amortization of deferred contract costs during the three months ended June 30, 2020 and June 30, 2019 were $33.2 million and $25.9 million, respectively. Amortization of deferred contract costs during the six months ended June 30, 2020 and June 30, 2019 were $64.5 million and $51.0 million, respectively.


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0001262039-20-000053:notes:29]
FINANCIAL INSTRUMENTS AND FAIR VALUE
The following tables summarize our investments (in millions):

[0001262039-20-000053:notes:30]
|  | June 30, 2020 |  |  |  |  |  |  |
|  | AmortizedCost |  | UnrealizedGains |  | UnrealizedLosses |  | FairValue |
| Corporate debt securities | $ | 502.2 |  |  | $ | 3.0 |  |  | $ | (0.1) |  |  | $ | 505.1 |  |
| Commercial paper | 75.6 |  |  | 0.2 |  |  | — |  |  | 75.8 |  |
| Certificates of deposit and term deposits (1) | 69.0 |  |  | 0.1 |  |  | (0.1) |  |  | 69.0 |  |
| U.S. government securities | 60.8 |  |  | 0.2 |  |  | — |  |  | 61.0 |  |
| Total available-for-sale securities | $ | 707.6 |  |  | $ | 3.5 |  |  | $ | (0.2) |  |  | $ | 710.9 |  |

[0001262039-20-000053:notes:31]
|  | December 31, 2019 |  |  |  |  |  |  |
|  | AmortizedCost |  | UnrealizedGains |  | UnrealizedLosses |  | FairValue |
| Corporate debt securities | $ | 576.1 |  |  | $ | 1.0 |  |  | $ | (0.1) |  |  | $ | 577.0 |  |
| Commercial paper | 148.7 |  |  | 0.1 |  |  | — |  |  | 148.8 |  |
| Certificates of deposit and term deposits (1) | 66.4 |  |  | — |  |  | — |  |  | 66.4 |  |
| U.S. government securities | 195.0 |  |  | 0.2 |  |  | — |  |  | 195.2 |  |
| Total available-for-sale securities | $ | 986.2 |  |  | $ | 1.3 |  |  | $ | (0.1) |  |  | $ | 987.4 |  |
| (1) The majority of our certificates of deposit and term deposits are foreign deposits. |  |  |  |  |  |  |  |

[0001262039-20-000053:notes:32]
[same as prior period, unchanged from 0001262039-20-000032:notes:35]

[0001262039-20-000053:notes:33]
|  | June 30, 2020 |  |  |  |  |  |  |  |  |  |  |
|  | Less Than 12 Months |  |  |  | 12 Months or Greater |  |  |  | Total |  |  |
|  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |
| Corporate debt securities | $ | 62.6 |  |  | $ | (0.1) |  |  | $ | — |  |  | $ | — |  |  | $ | 62.6 |  |  | $ | (0.1) |  |
| Commercial paper | 2.0 |  |  | — |  |  | — |  |  | — |  |  | 2.0 |  |  | — |  |
| Certificates of deposit and term deposits | 18.3 |  |  | (0.1) |  |  | — |  |  | — |  |  | 18.3 |  |  | (0.1) |  |
| Total available-for-sale securities | $ | 82.9 |  |  | $ | (0.2) |  |  | $ | — |  |  | $ | — |  |  | $ | 82.9 |  |  | $ | (0.2) |  |

[0001262039-20-000053:notes:34]
|  | December 31, 2019 |  |  |  |  |  |  |  |  |  |  |
|  | Less Than 12 Months |  |  |  | 12 Months or Greater |  |  |  | Total |  |  |
|  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |
| Corporate debt securities | $ | 117.3 |  |  | $ | (0.1) |  |  | $ | 16.1 |  |  | $ | — |  |  | $ | 133.4 |  |  | $ | (0.1) |  |
| Commercial paper | 26.0 |  |  | — |  |  | — |  |  | — |  |  | 26.0 |  |  | — |  |
| Certificates of deposit and term deposits | 13.0 |  |  | — |  |  | — |  |  | — |  |  | 13.0 |  |  | — |  |
| U.S. government securities | 47.1 |  |  | — |  |  | — |  |  | — |  |  | 47.1 |  |  | — |  |
| Total available-for-sale securities | $ | 203.4 |  |  | $ | (0.1) |  |  | $ | 16.1 |  |  | $ | — |  |  | $ | 219.5 |  |  | $ | (0.1) |  |

[0001262039-20-000053:notes:35]
[same as prior period, unchanged from 0001262039-20-000032:notes:38]

[0001262039-20-000053:notes:36]
|  | June 30,2020 |  | December 31,2019 |
| Due within one year | $ | 610.5 |  |  | $ | 843.1 |  |
| Due within one to three years | 100.4 |  |  | 144.3 |  |
| Total | $ | 710.9 |  |  | $ | 987.4 |  |

[0001262039-20-000053:notes:37]
Available-for-sale securities are reported at fair value, with unrealized gains and losses and the related tax impact included as a separate component of stockholders’ equity and in comprehensive income. Accrued interest of $3.7 million as of June 30, 2020 is excluded from both the fair value and the amortized cost of our available-for-sale securities and is recorded in Prepaid expenses and other current assets in our condensed consolidated balance sheet. We have elected to not record an allowance for credit losses for accrued interest for available-for-sale securities and will reverse the accrued interest against interest income in the period in which we determine the accrued interest to be uncollectible.

[0001262039-20-000053:notes:38]
Prior to 2020, we followed the guidance in ASC 320 Investments—Debt and Equity Securities in determining whether unrealized losses were other than temporary. We adopted Topic 326 on January 1, 2020, and now consider whether unrealized losses have resulted from a credit loss or other factors. The unrealized losses on our available-for-sale securities as of June 30, 2020 and as of December 31, 2019 were caused by fluctuations in market value and interest rates as a result of the economic environment. We concluded that an allowance for credit losses was unnecessary as of June 30, 2020 and that the impairments as of December 31, 2019 were not other than temporary because (i) the decline in market value was attributable to changes in market conditions and not credit quality, and (ii) we concluded that neither do we intend to sell nor is it more likely than not that we will be required to sell these investments prior to recovery of their amortized cost basis.

[0001262039-20-000053:notes:39]
Realized gains and losses on available-for-sale securities were insignificant in the periods presented and are included in Other income (expense)—net in our consolidated statements of income. We use the specific identification method to determine the cost basis of investments sold.

[0001262039-20-000053:notes:40]
[same as prior period, unchanged from 0001262039-20-000032:notes:43]

[0001262039-20-000053:notes:41]
[same as prior period, unchanged from 0001262039-20-000032:notes:44]

[0001262039-20-000053:notes:42]
[same as prior period, unchanged from 0001262039-20-000032:notes:45]

[0001262039-20-000053:notes:43]
[same as prior period, unchanged from 0001262039-20-000032:notes:46]

[0001262039-20-000053:notes:44]
[same as prior period, unchanged from 0001262039-20-000032:notes:47]

[0001262039-20-000053:notes:45]
[same as prior period, unchanged from 0001262039-20-000032:notes:48]

[0001262039-20-000053:notes:46]
[same as prior period, unchanged from 0001262039-20-000032:notes:49]

[0001262039-20-000053:notes:47]
[same as prior period, unchanged from 0001262039-20-000032:notes:50]

[0001262039-20-000053:notes:48]
[same as prior period, unchanged from 0001262039-20-000032:notes:51]

[0001262039-20-000053:notes:49]
The following tables present the fair value of our financial assets measured at fair value on a recurring basis as of June 30, 2020 and December 31, 2019 (in millions):

[0001262039-20-000053:notes:50]
|  | June 30, 2020 |  |  |  |  |  |  |  | December 31, 2019 |  |  |  |  |  |  |
|  | AggregateFairValue |  | QuotedPrices inActiveMarkets ForIdenticalAssets |  | SignificantOtherObservableRemainingInputs |  | SignificantOtherUnobservableRemainingInputs |  | AggregateFairValue |  | QuotedPrices inActiveMarkets ForIdenticalAssets |  | SignificantOtherObservableRemainingInputs |  | SignificantOtherUnobservableRemainingInputs |
|  |  |  | (Level 1) |  | (Level 2) |  | (Level 3) |  |  |  | (Level 1) |  | (Level 2) |  | (Level 3) |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate debt securities | $ | 505.1 |  |  | $ | — |  |  | $ | 505.1 |  |  | $ | — |  |  | $ | 577.0 |  |  | $ | — |  |  | $ | 577.0 |  |  | $ | — |  |
| Commercial paper | 75.8 |  |  | — |  |  | 75.8 |  |  | — |  |  | 165.8 |  |  | — |  |  | 165.8 |  |  | — |  |
| Certificates of deposit and term deposits | 69.0 |  |  | — |  |  | 69.0 |  |  | — |  |  | 66.4 |  |  | — |  |  | 66.4 |  |  | — |  |
| U.S. government securities | 61.0 |  |  | 61.0 |  |  | — |  |  | — |  |  | 195.2 |  |  | 195.2 |  |  | — |  |  | — |  |
| Money market funds | 347.0 |  |  | 347.0 |  |  | — |  |  | — |  |  | 15.0 |  |  | 15.0 |  |  | — |  |  | — |  |
| Total | $ | 1,057.9 |  |  | $ | 408.0 |  |  | $ | 649.9 |  |  | $ | — |  |  | $ | 1,019.4 |  |  | $ | 210.2 |  |  | $ | 809.2 |  |  | $ | — |  |
| Reported as: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents | $ | 347.0 |  |  |  |  |  |  |  |  | $ | 32.0 |  |  |  |  |  |  |  |
| Short-term investments | 610.5 |  |  |  |  |  |  |  |  | 843.1 |  |  |  |  |  |  |  |
| Long-term investments | 100.4 |  |  |  |  |  |  |  |  | 144.3 |  |  |  |  |  |  |  |
| Total | $ | 1,057.9 |  |  |  |  |  |  |  |  | $ | 1,019.4 |  |  |  |  |  |  |  |

[0001262039-20-000053:notes:51]
There were no transfers between Level 1 and Level 2 of the fair value hierarchy during the six months ended June 30, 2020 and year ended December 31, 2019.


## us-gaap:InventoryDisclosureTextBlock

[0001262039-20-000053:notes:52]
INVENTORY
Inventory consisted of the following (in millions):

[0001262039-20-000053:notes:53]
|  | June 30,2020 |  | December 31,2019 |
| Raw materials | $ | 14.1 |  |  | $ | 9.7 |  |
| Finished goods | 111.9 |  |  | 108.2 |  |
| Inventory | $ | 126.0 |  |  | $ | 117.9 |  |


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001262039-20-000053:notes:54]
PROPERTY AND EQUIPMENT—Net
Property and equipment—net consisted of the following (in millions):

[0001262039-20-000053:notes:55]
|  | June 30,2020 |  | December 31,2019 |
| Land | $ | 93.3 |  |  | $ | 93.3 |  |
| Building and building improvements | 148.0 |  |  | 147.4 |  |
| Computer equipment and software | 126.9 |  |  | 116.7 |  |
| Leasehold improvements | 26.7 |  |  | 25.5 |  |
| Evaluation units | 20.4 |  |  | 19.9 |  |
| Furniture and fixtures | 18.7 |  |  | 17.3 |  |
| Construction-in-progress | 114.1 |  |  | 61.2 |  |
| Total property and equipment | 548.1 |  |  | 481.3 |  |
| Less: accumulated depreciation | (155.5) |  |  | (137.0) |  |
| Property and equipment—net | $ | 392.6 |  |  | $ | 344.3 |  |

[0001262039-20-000053:notes:56]
Construction-in-progress consists primarily of costs incurred in connection with the construction of a second building at our headquarters campus. Depreciation expense was $14.1 million and $12.3 million during the three months ended June 30, 2020 and June 30, 2019, respectively. Depreciation expense was $27.7 million and $25.0 million during the six months ended June 30, 2020 and June 30, 2019, respectively.


## us-gaap:InvestmentTextBlock

[0001262039-20-000053:notes:57]
INVESTMENTS IN PRIVATELY HELD COMPANIESOur investments in the equity securities of privately held companies totaled $1.0 million and $5.3 million as of June 30, 2020 and December 31, 2019, respectively. These investments are accounted for at cost, adjusted for changes in observable prices minus impairment. We own less than 20% of the voting securities in each of these investments and do not have the ability to exercise significant influence over operating and financial policies of the respective entities. These investments are recorded as Other assets in our condensed consolidated balance sheets and would be measured at fair value if indicators of an increase in value or impairment existed. In the first quarter of 2020, we determined that one investment was impaired. As a result, we recognized and included a non-cash impairment charge of $4.3 million in Other income (expense)—net in our condensed consolidated statements of income. As of June 30, 2020, no other events have occurred that would affect the carrying value of these investments.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001262039-20-000053:notes:58]
GOODWILL AND OTHER INTANGIBLE ASSETS—Net
Goodwill

[0001262039-20-000053:notes:59]
As of June 30, 2020 and December 31, 2019, we had goodwill of $67.2 million. There were no impairments to goodwill during the six months ended June 30, 2020 or during prior periods.

[0001262039-20-000053:notes:60]
[same as prior period, unchanged from 0001262039-20-000032:notes:67]

[0001262039-20-000053:notes:61]
The following tables present other intangible assets—net as of June 30, 2020 and December 31, 2019 (in millions, except years):

[0001262039-20-000053:notes:62]
|  | June 30, 2020 |  |  |  |  |  |  |
|  | Weighted-Average Useful Life (in Years) |  | Gross |  | Accumulated Amortization |  | Net |
| Other intangible assets—net: |  |  |  |  |  |  |  |
| Finite-lived intangible assets: |  |  |  |  |  |  |  |
| Developed technologies | 4.0 |  | $ | 48.8 |  |  | $ | 28.2 |  |  | $ | 20.6 |  |
| Customer relationships | 4.1 |  | 21.6 |  |  | 18.8 |  |  | 2.8 |  |
| Total other intangible assets—net |  |  | $ | 70.4 |  |  | $ | 47.0 |  |  | $ | 23.4 |  |

[0001262039-20-000053:notes:63]
|  | December 31, 2019 |  |  |  |  |  |  |
|  | Weighted-Average Useful Life (in Years) |  | Gross |  | Accumulated Amortization |  | Net |
| Other intangible assets—net: |  |  |  |  |  |  |  |
| Finite-lived intangible assets: |  |  |  |  |  |  |  |
| Developed technologies | 4.0 |  | $ | 50.2 |  |  | $ | 24.6 |  |  | $ | 25.6 |  |
| Customer relationships | 4.1 |  | 21.6 |  |  | 16.1 |  |  | 5.5 |  |
| Total other intangible assets—net |  |  | $ | 71.8 |  |  | $ | 40.7 |  |  | $ | 31.1 |  |

[0001262039-20-000053:notes:64]
Amortization expense was $3.7 million and $2.9 million during the three months ended June 30, 2020 and June 30, 2019, respectively. Amortization expense was $7.7 million and $5.9 million during the six months ended June 30, 2020 and June 30, 2019, respectively.

[0001262039-20-000053:notes:65]
[same as prior period, unchanged from 0001262039-20-000032:notes:72]

[0001262039-20-000053:notes:66]
|  | Amount |
| Years: |  |
| 2020 (the remainder of 2020) | $ | 5.0 |  |
| 2021 | 8.3 |  |
| 2022 | 6.4 |  |
| 2023 | 3.7 |  |
| Total | $ | 23.4 |  |


## us-gaap:EarningsPerShareTextBlock

[0001262039-20-000053:notes:67]
NET INCOME PER SHAREBasic net income per share is computed by dividing net income by the weighted-average number of shares of common stock outstanding during the period. Diluted net income per share is computed by dividing net income by the weighted-average number of shares of common stock outstanding during the period, plus the dilutive effects of restricted stock units (“RSUs”) and stock options. Dilutive shares of common stock are determined by applying the treasury stock method.
A reconciliation of the numerator and denominator used in the calculation of basic and diluted net income per share is as follows (in millions, except per share amounts):

[0001262039-20-000053:notes:68]
|  | Three Months Ended |  |  |  | Six Months Ended |  |  |
|  | June 30,2020 |  | June 30,2019 |  | June 30,2020 |  | June 30,2019 |
| Numerator: |  |  |  |  |  |  |  |
| Net income | $ | 112.1 |  |  | $ | 72.7 |  |  | $ | 216.1 |  |  | $ | 131.5 |  |
| Denominator: |  |  |  |  |  |  |  |
| Basic shares: |  |  |  |  |  |  |  |
| Weighted-average common stock outstanding-basic | 161.6 |  |  | 171.1 |  |  | 166.1 |  |  | 170.6 |  |
| Diluted shares: |  |  |  |  |  |  |  |
| Weighted-average common stock outstanding-basic | 161.6 |  |  | 171.1 |  |  | 166.1 |  |  | 170.6 |  |
| Effect of potentially dilutive securities: |  |  |  |  |  |  |  |
| RSUs | 2.6 |  |  | 2.9 |  |  | 2.5 |  |  | 3.2 |  |
| Stock options | 1.2 |  |  | 1.1 |  |  | 1.2 |  |  | 1.2 |  |
| Weighted-average shares used to compute diluted net income per share | 165.4 |  |  | 175.1 |  |  | 169.8 |  |  | 175.0 |  |
| Net income per share: |  |  |  |  |  |  |  |
| Basic | $ | 0.69 |  |  | $ | 0.42 |  |  | $ | 1.30 |  |  | $ | 0.77 |  |
| Diluted | $ | 0.68 |  |  | $ | 0.42 |  |  | $ | 1.27 |  |  | $ | 0.75 |  |

[0001262039-20-000053:notes:69]
[same as prior period, unchanged from 0001262039-20-000032:notes:78]

[0001262039-20-000053:notes:70]
|  | Three Months Ended |  |  |  | Six Months Ended |  |  |
|  | June 30,2020 |  | June 30,2019 |  | June 30,2020 |  | June 30,2019 |
| RSUs | 0.1 |  |  | 0.1 |  |  | 0.3 |  |  | 0.4 |  |
| Stock options | 0.6 |  |  | 0.7 |  |  | 0.5 |  |  | 0.5 |  |
| Total | 0.7 |  |  | 0.8 |  |  | 0.8 |  |  | 0.9 |  |


## us-gaap:LesseeFinanceLeasesTextBlock

[0001262039-20-000053:notes:71]
LEASES 
We have operating leases for offices, research and development facilities and data centers. Our leases have remaining terms that range from less than one year to approximately six years, some of which include one or more options to renew, with renewal terms of up to six years. We do not include renewal options in our lease terms for calculating our lease liability, as the renewal options allow us to maintain operational flexibility and we are not reasonably certain we will exercise these renewal options at the time of the lease commencement.

[0001262039-20-000053:notes:72]
[same as prior period, unchanged from 0001262039-20-000032:notes:82]

[0001262039-20-000053:notes:73]
[same as prior period, unchanged from 0001262039-20-000032:notes:83]

[0001262039-20-000053:notes:74]
|  | Three Months Ended |  |  |  | Six Months Ended |  |  |
|  | June 30,2020 |  | June 30,2019 |  | June 30,2020 |  | June 30,2019 |
| Operating lease expense | $ | 4.4 |  |  | $ | 3.7 |  |  | $ | 8.7 |  |  | $ | 7.3 |  |
| Variable lease expense (1) | 0.4 |  |  | 0.6 |  |  | 1.0 |  |  | 1.2 |  |
| Short-term lease expense | 1.0 |  |  | 0.7 |  |  | 1.9 |  |  | 1.4 |  |
| Total lease expense | $ | 5.8 |  |  | $ | 5.0 |  |  | $ | 11.6 |  |  | $ | 9.9 |  |

[0001262039-20-000053:notes:75]
(1) Variable lease expense for the six months ended June 30, 2020 and June 30, 2019 predominantly included common area maintenance charges and parking expense.

[0001262039-20-000053:notes:76]
[same as prior period, unchanged from 0001262039-20-000032:notes:86]

[0001262039-20-000053:notes:77]
|  | Classification | June 30,2020 |  | December 31,2019 |
| Operating lease ROU assets - non-current | Other assets | $ | 42.1 |  |  | $ | 44.3 |  |
| Operating lease liabilities - current | Accrued liabilities | $ | 15.7 |  |  | $ | 15.5 |  |
| Operating lease liabilities - non-current | Other liabilities | 27.6 |  |  | 30.6 |  |
| Total operating lease liabilities |  | $ | 43.3 |  |  | $ | 46.1 |  |
| Weighted average remaining lease term in years - operating leases |  | 3.5 |  | 3.7 |
| Weighted average discount rate - operating leases |  | 3.0 | % |  | 2.8 | % |

[0001262039-20-000053:notes:78]
[same as prior period, unchanged from 0001262039-20-000032:notes:88]

[0001262039-20-000053:notes:79]
|  | Six Months Ended |  | Six Months Ended |
|  | June 30,2020 |  | June 30,2019 |
| Cash paid for amounts included in the measurement of lease liabilities |  |  |  |
| Operating cash flows used for operating leases | $ | 8.7 |  |  | $ | 8.5 |  |
| Lease liabilities arising from obtaining right-of-use assets |  |  |  |
| Operating leases | $ | 5.9 |  |  | $ | 4.9 |  |

[0001262039-20-000053:notes:80]
Maturities of operating lease liabilities as of June 30, 2020 were as follows (in millions):

[0001262039-20-000053:notes:81]
| Year ending December 31, | Amount |
| 2020 (the remainder of 2020) | $ | 8.5 |  |
| 2021 | 14.7 |  |
| 2022 | 9.9 |  |
| 2023 | 6.2 |  |
| 2024 | 4.4 |  |
| Thereafter | 2.0 |  |
| Total lease payments | 45.7 |  |
| Less imputed interest | (2.4) |  |
| Total | $ | 43.3 |  |

[0001262039-20-000053:notes:82]
As of June 30, 2020, we had additional minimum lease payments of $8.2 million relating to operating leases that had been signed but had not yet commenced and therefore were excluded from the table above. These leases will commence during 2020 and will have lease terms of approximately three to seven years.


## ftnt:MutualCovenantNottoSueAgreementDisclosureTextBlock

[0001262039-20-000053:notes:83]
MUTUAL COVENANT-NOT-TO-SUE AND RELEASE AGREEMENT
In January 2020, we entered into an agreement with a competitor in the network security industry whereby, in February 2020, the competitor party paid us a lump sum of $50.0 million for a seven-year mutual covenant-not-to-sue for patent claims. Pursuant to this agreement, at the end of this first seven-year period, either party may extend the agreement for an additional seven-year mutual covenant-not-to-sue in return for this competitor paying us an additional $50.0 million. This agreement arose after expiration of previous agreements between the parties whereby the competitor had paid us sums for a limited term license to certain of our intellectual property (“IP”) and a limited term mutual covenant-not-to-sue.

[0001262039-20-000053:notes:84]
We concluded that the agreement was a 14-year contract with a total transaction price of $100.0 million, and that it contained two material distinct performance obligations: (1) the right to use our existing patents, and (2) the right to use any patents that we develop over the term of the contract. We allocated $36.0 million to the functional patents, which was recognized upon commencement of the contract; the remaining $64.0 million, representing the right to utilize future patents, will be recognized over the contract term. We further concluded that our existing patents represent functional IP that should be recognized upon granting our competitor access. We also concluded that the right to receive additional functional IP that we will develop in the future represents a stand ready obligation. Therefore, the transaction price allocated to this obligation is recognized ratably over the 14-year contract term. We estimated the stand-alone selling price of each distinct performance obligation and allocated the $100.0 million transaction price.

[0001262039-20-000053:notes:85]
During the three and six months ended June 30, 2020, we recorded $1.1 million and $37.9 million in Gain on IP matter in our condensed consolidated statements of income, respectively. We recorded $12.1 million in Accrued liabilities and Other liabilities in our condensed consolidated balance sheet as of June 30, 2020.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001262039-20-000053:notes:86]
COMMITMENTS AND CONTINGENCIES
The following table summarizes our inventory purchase commitments as of June 30, 2020 (in millions):

[0001262039-20-000053:notes:87]
|  | Total |  | 2020 |  | 2021 |  | 2022 |  | 2023 |  | 2024 |  | Thereafter |
| Inventory purchase commitments | $ | 282.1 |  |  | $ | 281.8 |  |  | $ | 0.3 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |

[0001262039-20-000053:notes:88]
Inventory Purchase Commitments—Our independent contract manufacturers procure components and build our products based on our forecasts. These forecasts are based on estimates of future demand for our products, which are in turn based on historical trends and an analysis from our sales and marketing organizations, adjusted for overall market conditions. In order to reduce manufacturing lead times and plan for adequate component supply, we may issue purchase orders to some of our independent contract manufacturers, which may not be cancelable. As of June 30, 2020, we had $282.1 million of open purchase orders with our independent contract manufacturers that may not be cancelable.

[0001262039-20-000053:notes:89]
Other Contractual Commitments and Open Purchase Orders—In addition to commitments with contract manufacturers, we have open purchase orders and contractual obligations in the ordinary course of business for which we have not received goods or services. As of June 30, 2020, we had $27.8 million in other contractual commitments having a remaining term in excess of one year that may not be cancelable.

[0001262039-20-000053:notes:90]
Litigation—We are involved in disputes, litigation, and other legal actions. For lawsuits where we are the defendant, we are in the process of defending these litigation matters, and while there can be no assurances and the outcome of certain of these matters is currently not determinable and not predictable, we currently are unaware of any existing claims or proceedings that we believe are likely to have a material adverse effect on our financial position. There are many uncertainties associated with any litigation and these actions or other third-party claims against us may cause us to incur costly litigation fees, costs and substantial settlement charges, and possibly subject us to damages and other penalties. In addition, the resolution of any IP litigation may require us to make royalty payments, which could adversely affect our gross margins in future periods. If any of those events were to occur, our business, financial condition, results of operations, and cash flows could be adversely affected. Litigation is unpredictable and the actual liability in any such matters may be materially different from our current estimates, which could result in the need to adjust any accrued liability and record additional expenses. We accrue for contingencies when we believe that a loss is probable and that we can reasonably estimate the amount of any such loss.

[0001262039-20-000053:notes:91]
Indemnification and Other Matters—Under the indemnification provisions of our standard sales contracts, we agree to defend our customers against third-party claims asserting various allegations such as product defects and infringement of certain IP rights, which may include patents, copyrights, trademarks or trade secrets, and to pay judgments entered on such claims. In some contracts, our exposure under these indemnification provisions is limited by the terms of the contracts to certain defined limits, such as the total amount paid by our customer under the agreement. However, certain agreements include covenants, penalties and indemnification provisions including and beyond indemnification for third-party claims of IP infringement that could potentially expose us to losses in excess of the amount received under the agreement, and in some instances to potential liability that is not contractually limited. Although from time to time there are indemnification claims asserted against us and currently there are pending indemnification claims, to date there have been no material awards under such indemnification provisions.

[0001262039-20-000053:notes:92]
Similar to other security companies and companies in other industries, we have in the past experienced, and we may in the future experience, cybersecurity threats, malicious activity directed against our information technology infrastructure or unauthorized attempts to gain access to our and our customers’ sensitive information and systems. We currently are unaware of any existing claims or proceedings related to these types of matters, including any that we believe are likely to have a material adverse effect on our financial position.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001262039-20-000053:notes:93]
STOCKHOLDERS’ EQUITY
Stock-Based Compensation Plans

[0001262039-20-000053:notes:94]
We maintain the Amended and Restated Fortinet, Inc. 2009 Equity Incentive Plan (the “Amended Plan”) pursuant to which we have granted RSUs and stock options. We also previously had an Employee Stock Purchase Plan (“ESPP”) for eligible employees, which was terminated in February 2019. As of June 30, 2020, there was a total of 12.0 million shares of common stock available for grant under the Amended Plan.

[0001262039-20-000053:notes:95]
[same as prior period, unchanged from 0001262039-20-000032:notes:109]

[0001262039-20-000053:notes:96]
[same as prior period, unchanged from 0001262039-20-000032:notes:110]

[0001262039-20-000053:notes:97]
|  | Restricted Stock Units Outstanding |  |  |
|  | Number of Shares |  | Weighted-Average Grant Date Fair Value per Share |
| Balance—December 31, 2019 | 6.1 |  |  | $ | 64.56 |  |
| Granted | 1.6 |  |  | 120.02 |  |
| Forfeited | (0.2) |  |  | 72.69 |  |
| Vested | (1.7) |  |  | 56.98 |  |
| Balance—June 30, 2020 | 5.8 |  |  | $ | 81.49 |  |

[0001262039-20-000053:notes:98]
Stock compensation expense is recognized on a straight-line basis over the vesting period of each RSU. As of June 30, 2020, total compensation expense related to unvested RSUs granted to employees and non-employees under the 2009 Plan, but not yet recognized, was $427.5 million, with a weighted-average remaining vesting period of 2.9 years.

[0001262039-20-000053:notes:99]
RSUs settle into shares of common stock upon vesting. Upon the vesting of the RSUs, we net-settle the RSUs and withhold a portion of the shares to satisfy minimum statutory employee withholding tax requirements. The payment of the withheld taxes to the tax authorities is reflected as a financing activity within the condensed consolidated statements of cash flows.

[0001262039-20-000053:notes:100]
[same as prior period, unchanged from 0001262039-20-000032:notes:114]

[0001262039-20-000053:notes:101]
|  | Three Months Ended |  |  |  | Six Months Ended |  |  |
|  | June 30,2020 |  | June 30,2019 |  | June 30,2020 |  | June 30,2019 |
| Shares withheld for taxes | 0.2 |  |  | 0.3 |  |  | 0.5 |  |  | 0.7 |  |
| Amount withheld for taxes | $ | 21.1 |  |  | $ | 24.5 |  |  | $ | 58.9 |  |  | $ | 56.5 |  |

[0001262039-20-000053:notes:102]
[same as prior period, unchanged from 0001262039-20-000032:notes:116]

[0001262039-20-000053:notes:103]
[same as prior period, unchanged from 0001262039-20-000032:notes:117]

[0001262039-20-000053:notes:104]
|  | Three Months Ended |  |  |  | Six Months Ended |  |  |
|  | June 30,2020 |  | June 30,2019 |  | June 30,2020 |  | June 30,2019 |
| Expected term in years | 4.4 |  | 4.4 |  | 4.4 |  | 4.4 |
| Volatility | 39.0 | % |  | 34.4 | % |  | 34.4 | % |  | 34.2 | % |
| Risk-free interest rate | 0.3 | % |  | 2.2 | % |  | 1.1 | % |  | 2.5 | % |
| Dividend rate | — | % |  | — | % |  | — | % |  | — | % |

[0001262039-20-000053:notes:105]
[same as prior period, unchanged from 0001262039-20-000032:notes:119]

[0001262039-20-000053:notes:106]
|  | Options Outstanding |  |  |  |  |  |  |
|  | Numberof Shares |  | Weighted-AverageExercisePrice |  | Weighted-AverageRemainingContractualLife (Years) |  | AggregateIntrinsicValue |
| Balance—December 31, 2019 | 2.7 |  |  | $ | 50.37 |  |  |  |  |  |
| Granted | 0.6 |  |  | 118.50 |  |  |  |  |  |
| Forfeited | — |  |  | 80.97 |  |  |  |  |  |
| Exercised | (0.4) |  |  | 40.78 |  |  |  |  |  |
| Balance—June 30, 2020 | 2.9 |  |  | $ | 66.01 |  |  |  |  |  |
| Options vested and expected to vest—June 30, 2020 | 2.9 |  |  | $ | 66.01 |  |  | 4.7 |  | $ | 206.0 |  |
| Options exercisable—June 30, 2020 | 1.4 |  |  | $ | 41.09 |  |  | 3.5 |  | $ | 134.3 |  |

[0001262039-20-000053:notes:107]
The aggregate intrinsic value represents the difference between the exercise price of stock options and the quoted market price of our common stock on June 30, 2020 for all in-the-money stock options. Stock compensation expense is recognized on a straight-line basis over the vesting period of each stock option. As of June 30, 2020, total compensation expense related to unvested stock options granted to employees but not yet recognized was $38.5 million, with a weighted-average remaining vesting period of 3.0 years.

[0001262039-20-000053:notes:108]
[same as prior period, unchanged from 0001262039-20-000032:notes:122]

[0001262039-20-000053:notes:109]
|  | Three Months Ended |  |  |  | Six Months Ended |  |  |
|  | June 30,2020 |  | June 30,2019 |  | June 30,2020 |  | June 30,2019 |
| Weighted-average fair value per share granted | $ | 46.92 |  |  | $ | 26.38 |  |  | $ | 35.51 |  |  | $ | 27.08 |  |
| Intrinsic value of options exercised | $ | 17.3 |  |  | $ | 9.6 |  |  | 30.4 |  |  | 36.8 |  |
| Fair value of options vested | $ | 2.4 |  |  | $ | 2.0 |  |  | 8.4 |  |  | 6.2 |  |

[0001262039-20-000053:notes:110]
[same as prior period, unchanged from 0001262039-20-000032:notes:124]

[0001262039-20-000053:notes:111]
[same as prior period, unchanged from 0001262039-20-000032:notes:125]

[0001262039-20-000053:notes:112]
|  | Three Months Ended |  |  |  | Six Months Ended |  |  |
|  | June 30,2020 |  | June 30,2019 |  | June 30,2020 |  | June 30,2019 |
| Cost of product revenue | $ | 0.4 |  |  | $ | 0.4 |  |  | $ | 0.8 |  |  | $ | 0.8 |  |
| Cost of service revenue | 3.2 |  |  | 2.9 |  |  | 6.2 |  |  | 5.7 |  |
| Research and development | 12.0 |  |  | 10.0 |  |  | 22.9 |  |  | 19.4 |  |
| Sales and marketing | 27.9 |  |  | 26.3 |  |  | 53.6 |  |  | 51.7 |  |
| General and administrative | 6.1 |  |  | 5.4 |  |  | 11.4 |  |  | 10.4 |  |
| Total stock-based compensation expense | $ | 49.6 |  |  | $ | 45.0 |  |  | $ | 94.9 |  |  | $ | 88.0 |  |

[0001262039-20-000053:notes:113]
[same as prior period, unchanged from 0001262039-20-000032:notes:127]

[0001262039-20-000053:notes:114]
|  | Three Months Ended |  |  |  | Six Months Ended |  |  |
|  | June 30,2020 |  | June 30,2019 |  | June 30,2020 |  | June 30,2019 |
| RSUs | $ | 45.9 |  |  | $ | 41.9 |  |  | $ | 88.1 |  |  | $ | 81.1 |  |
| Stock options | 3.7 |  |  | 3.1 |  |  | 6.8 |  |  | 5.6 |  |
| ESPP | — |  |  | — |  |  | — |  |  | 1.3 |  |
| Total stock-based compensation expense | $ | 49.6 |  |  | $ | 45.0 |  |  | $ | 94.9 |  |  | $ | 88.0 |  |

[0001262039-20-000053:notes:115]
[same as prior period, unchanged from 0001262039-20-000032:notes:129]

[0001262039-20-000053:notes:116]
|  | Three Months Ended |  |  |  | Six Months Ended |  |  |
|  | June 30,2020 |  | June 30,2019 |  | June 30,2020 |  | June 30,2019 |
| Income tax benefit associated with stock-based compensation | $ | 10.9 |  |  | $ | 10.4 |  |  | $ | 20.9 |  |  | $ | 20.4 |  |

[0001262039-20-000053:notes:117]
[same as prior period, unchanged from 0001262039-20-000032:notes:131]

[0001262039-20-000053:notes:118]
[same as prior period, unchanged from 0001262039-20-000032:notes:132]

[0001262039-20-000053:notes:119]
During the three and six months ended June 30, 2020, we repurchased 1.4 million and 11.4 million shares of common stock, respectively, under the Repurchase Program in open market transactions at an average price of $99.69 per share and $91.55 per share, respectively, for an aggregate purchase price of $146.1 million and $1.0 billion, respectively. As of June 30, 2020, $546.8 million remained available for future share repurchases under the Repurchase Program.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001262039-20-000053:notes:120]
INCOME TAXES 
Our effective tax rate was 8% for the three months ended June 30, 2020, compared to an effective tax rate of 15% for the same period last year. Our effective tax rate was 9% for the six months ended June 30, 2020, compared to an effective tax rate of 10% for the same period last year. The effective tax rates for the periods presented are primarily comprised of U.S. federal and state taxes, withholding taxes, foreign taxes and excess tax benefits from stock-based compensation expense. The tax rates for the three months ended June 30, 2020 and June 30, 2019 were impacted by U.S. federal and state taxes, withholding taxes and foreign taxes that were $28.2 million and $24.5 million, respectively. U.S. federal and state taxes were lowered by a tax benefit of $5.0 million from the foreign-derived intangible income deduction for the three months ended June 30, 2020. The tax rates for the three months ended June 30, 2020 and June 30, 2019 were impacted by excess tax benefits from stock-based compensation expense of $10.0 million and $11.7 million, respectively, and release of reserves of $8.7 million and $10.0 million, respectively, on uncertain tax positions and the interest due to the expiration of the statute of limitations. The tax rate for the three months ended June 30, 2019 was further impacted by an increase in tax expense of $10.3 million related to the U.S. Court of Appeals for the Ninth Circuit’s (the “Ninth Circuit”) opinion in Altera Corporation and Subsidiaries vs. Commissioner of Internal Revenue (“Altera”), as described below, regarding stock-based compensation expense in cost sharing arrangements.

[0001262039-20-000053:notes:121]
The tax rates for the six months ended June 30, 2020 and June 30, 2019 were impacted by U.S. federal and state taxes, withholding taxes and foreign taxes of $56.5 million and $42.0 million, respectively. U.S. federal and state taxes were lowered by a tax benefit of $9.6 million from the foreign-derived intangible income deduction for the six months ended June 30, 2020. The tax rates for the six months ended June 30, 2020 and June 30, 2019 were impacted by excess tax benefits from stock-based compensation expense of $25.2 million and $27.7 million, respectively, and release of reserves of $8.7 million and $10.0 million, respectively, on uncertain tax positions and the interest due to the expiration of the statute of limitations. The tax

[0001262039-20-000053:notes:122]
rate for the six months ended June 30, 2019 was further impacted by an increase in tax expense of $10.3 million related to the Ninth Circuit’s Altera decision, regarding stock-based compensation expense in cost sharing arrangements.

[0001262039-20-000053:notes:123]
As of June 30, 2020 and December 31, 2019, unrecognized tax benefits were $62.9 million and $67.5 million, respectively. If recognized, $57.6 million of the unrecognized tax benefits would favorably affect our effective tax rate. It is our policy to include accrued interest and penalties related to uncertain tax benefits in income tax expense. As of June 30, 2020 and December 31, 2019, accrued interest and penalties were $13.4 million and $14.1 million, respectively. It is reasonably possible that our gross unrecognized tax benefits will decrease by up to $4.4 million in the next 12 months, due to the lapse of the statute of limitations. This decrease, if recognized, would positively impact our effective tax rate, and would be recognized as additional tax benefits.

[0001262039-20-000053:notes:124]
[same as prior period, unchanged from 0001262039-20-000032:notes:137]

[0001262039-20-000053:notes:125]
On June 7, 2019, the Ninth Circuit overturned the U.S. Tax Court’s decision in Altera and ruled in favor of the Commissioner, validating the regulations requiring that stock-based compensation be included in a cost sharing arrangement. On June 22, 2020, the Supreme Court of the United States (the “Supreme Court”) issued an order declining the petition for certiorari in Altera. As a result, the Ninth Circuit’s decision requiring that stock-based compensation be included in cost sharing arrangements is the controlling law at present. However, as we are no longer part of a cost sharing arrangement, this does not impact our future income tax provisions. The Ninth Circuit’s decision, together with Supreme Court’s order, did not have a material impact on our condensed consolidated financial statements.

[0001262039-20-000053:notes:126]
On March 27, 2020, the President signed into law the Coronavirus Aid, Relief, and Economic Security Act (the “CARES Act”). The CARES Act provides numerous tax provisions and other stimulus measures, including temporary changes regarding the prior and future utilization of net operating losses, temporary changes to the prior and future limitations on interest deductions, temporary suspension of certain payment requirements for the employer portion of Social Security taxes, technical corrections from prior tax legislation for tax depreciation of certain qualified improvement property and the creation of certain refundable employee retention credits. We do not expect there to be a material tax impact on our condensed consolidated financial statements at this time and will continue to assess the implications of the CARES Act and its continuing developments and interpretations.

[0001262039-20-000053:notes:127]
On July 9, 2020, the United States Department of the Treasury and the Internal Revenue Service (the “IRS”) released final Section 250 regulations, providing guidance on foreign-derived intangible income deduction and global intangible low-taxed income. Generally, the final regulations are applicable for taxable years beginning on or after January 1, 2021. However, taxpayers may apply the final regulations for taxable years beginning on or after January 1, 2018. We are in the process of analyzing the tax impact from the final regulations on our foreign-derived intangible income deduction calculation.


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0001262039-20-000053:notes:128]
DEFINED CONTRIBUTION PLANSOur tax-deferred savings plan under our 401(k) Plan permits participating U.S. employees to contribute a portion of their pre-tax or after-tax earnings. In Canada, we have a Group Registered Retirement Savings Plan Program (the “RRSP”), which permits participants to make tax-deductible contributions. Our board of directors approved 50% matching contributions on employee contributions up to 4% of each employee’s eligible earnings. Our matching contributions to our 401(k) Plan and the RRSP for the three months ended June 30, 2020 and June 30, 2019 were $2.2 million and $1.7 million, respectively. Our matching contributions to our 401(k) Plan and the RRSP for the six months ended June 30, 2020 and June 30, 2019 were $4.4 million and $3.4 million, respectively.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001262039-20-000053:notes:129]
SEGMENT INFORMATIONOperating segments are defined as components of an enterprise about which separate financial information is available that is evaluated regularly by the chief operating decision maker in deciding how to allocate resources and in assessing performance. Our chief operating decision maker is our chief executive officer. Our chief executive officer reviews financial information presented on a consolidated basis, accompanied by information about revenue by geographic region for purposes of allocating resources and evaluating financial performance. We have one business activity, and there are no segment managers 
who are held accountable for operations, operating results and plans for levels or components below the consolidated unit level. Accordingly, we have determined that we have one operating segment, and therefore, one reportable segment.

[0001262039-20-000053:notes:130]
[same as prior period, unchanged from 0001262039-20-000032:notes:144]

[0001262039-20-000053:notes:131]
|  | Three Months Ended |  |  |  | Six Months Ended |  |  |
| Revenue | June 30,2020 |  | June 30,2019 |  | June 30,2020 |  | June 30,2019 |
| Americas: |  |  |  |  |  |  |  |
| United States | $ | 200.6 |  |  | $ | 173.5 |  |  | $ | 382.2 |  |  | $ | 323.8 |  |
| Other Americas | 59.6 |  |  | 52.0 |  |  | 120.2 |  |  | 102.2 |  |
| Total Americas | 260.2 |  |  | 225.5 |  |  | 502.4 |  |  | 426.0 |  |
| Europe, Middle East and Africa (“EMEA”) | 228.4 |  |  | 192.0 |  |  | 449.1 |  |  | 369.2 |  |
| Asia Pacific (“APAC”) | 126.9 |  |  | 104.2 |  |  | 240.9 |  |  | 199.1 |  |
| Total revenue | $ | 615.5 |  |  | $ | 521.7 |  |  | $ | 1,192.4 |  |  | $ | 994.3 |  |

[0001262039-20-000053:notes:132]
| Property and Equipment—net | June 30,2020 |  | December 31,2019 |
| Americas: |  |  |  |
| United States | $ | 245.5 |  |  | $ | 197.4 |  |
| Canada | 121.6 |  |  | 120.5 |  |
| Latin America | 6.2 |  |  | 5.5 |  |
| Total Americas | 373.3 |  |  | 323.4 |  |
| EMEA | 14.0 |  |  | 15.2 |  |
| APAC | 5.3 |  |  | 5.7 |  |
| Total property and equipment—net | $ | 392.6 |  |  | $ | 344.3 |  |

[0001262039-20-000053:notes:133]
[same as prior period, unchanged from 0001262039-20-000032:notes:147]

[0001262039-20-000053:notes:134]
|  | Three Months Ended |  |  |  | Six Months Ended |  |  |
|  | June 30,2020 |  | June 30,2019 |  | June 30,2020 |  | June 30,2019 |
| Exclusive Networks Group | 31 | % |  | 31 | % |  | 31 | % |  | 31 | % |
| Ingram Micro | * |  | 11 | % |  | * |  | 11 | % |

[0001262039-20-000053:notes:135]
[same as prior period, unchanged from 0001262039-20-000032:notes:149]

[0001262039-20-000053:notes:136]
|  | June 30,2020 |  | December 31,2019 |
| Exclusive Networks Group | 31 | % |  | 36 | % |
| Ingram Micro | 11 | % |  | 10 | % |
| * Represents less than 10% |  |  |  |


## us-gaap:SubsequentEventsTextBlock

[0001262039-20-000053:notes:137]
SUBSEQUENT EVENTS
Share Repurchase

[0001262039-20-000053:notes:138]
In July 2020, our board of directors approved a $500.0 million increase in the authorized stock repurchase amount under the Repurchase Program and extended the term of the Repurchase Program to February 28, 2022, bringing the aggregate amount authorized to be repurchased to $3.0 billion. As of August 6, 2020, $1.05 billion remained available for future share repurchases under the Repurchase Program.

[0001262039-20-000053:notes:139]
Business Combination

[0001262039-20-000053:notes:140]
On July 20, 2020, we acquired OPAQ Networks, Inc. (“OPAQ”), a privately held Secure Access Service Edge cloud provider. We acquired OPAQ for approximately $13.0 million in cash consideration, subject to certain adjustments.

[0001262039-20-000053:notes:141]
We are currently in the process of evaluating the business combination accounting, including the consideration transferred and the initial purchase price allocation.
