# FTNT MD&A — 0001262039-20-000053


## mdna

[0001262039-20-000053:mdna:1]
ITEM 2.  Management’s Discussion and Analysis of Financial Condition and Results of Operations

[0001262039-20-000053:mdna:2]
•the duration and impact of the COVID-19 pandemic;

[0001262039-20-000053:mdna:3]
•continued growth and market share gains;

[0001262039-20-000053:mdna:4]
•variability in sales in certain product categories from year to year and between quarters;

[0001262039-20-000053:mdna:5]
•expected impact of sales of certain products and services;

[0001262039-20-000053:mdna:6]
•the impact of macro-economic, geopolitical factors and other disruption on our manufacturing or sales, including the impact of the COVID-19 pandemic and other public health issues and natural disasters;

[0001262039-20-000053:mdna:7]
•the proportion of our revenue that consists of our product and service revenue, and the mix of billings between products and services, and the duration of service contracts;

[0001262039-20-000053:mdna:8]
•the impact of our product innovation strategy;

[0001262039-20-000053:mdna:9]
•the effects of government regulation, tariffs and other related policies;

[0001262039-20-000053:mdna:10]
•drivers of long-term growth and operating leverage, such as sales productivity, functionality and value in our standalone and bundled subscription service offerings;

[0001262039-20-000053:mdna:11]
•growing our sales to businesses, service providers and government organizations, our ability to execute these sales and of the complexity of selling to all segments (including the increased competition and unpredictability of timing associated with sales to larger enterprises), the impact of sales to these organizations on our long-term growth, expansion and operating results, and the effectiveness of our internal sales organization;

[0001262039-20-000053:mdna:12]
•our ability to hire properly qualified and effective sales, support and engineering employees;

[0001262039-20-000053:mdna:13]
•trends in revenue, cost of revenue and gross margin;

[0001262039-20-000053:mdna:14]
•trends in our operating expenses, including sales and marketing expense, research and development expense, general and administrative expense, and expectations regarding these expenses;

[0001262039-20-000053:mdna:15]
•risks and expectations related to acquisitions or sales of assets, including integration issues related to product plans and products, including the acquired technology;

[0001262039-20-000053:mdna:16]
•continued investments in research and development, and expectations that our research and development expense will increase in absolute dollars during 2020;

[0001262039-20-000053:mdna:17]
•continued investments in our sales resources and infrastructure and marketing strategy, and expectations that our sales and marketing expense will increase in absolute dollars during 2020;

[0001262039-20-000053:mdna:18]
•expectations that our general and administrative expense will increase in absolute dollars during 2020;

[0001262039-20-000053:mdna:19]
•expectations that proceeds from the exercise of stock options in future years will be adversely impacted by the increased mix of restricted stock units versus stock options granted;

[0001262039-20-000053:mdna:20]
•estimates of a range of 2020 spending on our headquarters expansion project;

[0001262039-20-000053:mdna:21]
•expectations regarding uncertain tax benefits and our effective domestic and global tax rates, and the impact of the Tax Cuts and Jobs Act (the “2017 Tax Act”) and the U.S. Court of Appeals for the Ninth Circuit’s (the “Ninth Circuit”) decision in Altera Corporation and Subsidiaries vs. Commissioner of Internal Revenue (“Altera”) regarding stock-based compensation in cost sharing arrangements;

[0001262039-20-000053:mdna:22]
•expectations regarding spending related to real estate and other capital expenditures and to the impact on free cash flows;

[0001262039-20-000053:mdna:23]
•competition in our markets;

[0001262039-20-000053:mdna:24]
•statements regarding expected outcomes and liabilities in litigation;

[0001262039-20-000053:mdna:25]
•our intentions regarding share repurchases and the sufficiency of our existing cash, cash equivalents and investments to meet our cash needs for at least the next 12 months;

[0001262039-20-000053:mdna:26]
•other statements regarding our future operations, financial condition and prospects and business strategies; and

[0001262039-20-000053:mdna:27]
•adoption and impact of new accounting standards.

[0001262039-20-000053:mdna:28]
[same as prior period, unchanged from 0001262039-20-000032:mdna:29]

[0001262039-20-000053:mdna:29]
[same as prior period, unchanged from 0001262039-20-000032:mdna:30]

[0001262039-20-000053:mdna:30]
[same as prior period, unchanged from 0001262039-20-000032:mdna:31]

[0001262039-20-000053:mdna:31]
•Security-Driven Networking—We derive a majority of product sales from our FortiGate network security appliances. Our FortiGate network security appliances include a broad set of built-in security and networking features and functionalities, including firewall, next-generation firewall, secure web gateway, secure sockets layer inspection, software-defined wide-area network (“SD-WAN”), intrusion prevention, data leak prevention, virtual private network (“VPN”), switch and wireless controller and wide area network edge. Our network security appliances are managed by our FortiOS network operating system, which provides the foundation for FortiGate security functions. We enhance the performance of our network security appliances from branch to data center by designing and implementing Security Processing Unit (“SPU”) technology within our appliances, enabling us to add security and network functionality with minimal impact to network throughput performance.

[0001262039-20-000053:mdna:32]
•Infrastructure Security—The Fortinet Security Fabric platform is a broad, automated and integrated security platform that extends beyond the network to cover other attack vectors. Other infrastructure solutions covered include Secure Access (Wi-Fi and switch) and teleworker and remote security solutions such as FortiAuthenticator, FortiClient and FortiToken.

[0001262039-20-000053:mdna:33]
•Dynamic Cloud Security—We help customers connect securely to and across their hybrid, public and private cloud environments by offering security through our virtual firewall and other software products. Our public and private cloud security solutions, including virtual appliances and hosted solutions, extend the core capabilities of the Fortinet Security Fabric platform to provide businesses with the same level of cybersecurity and threat intelligence in and across cloud environments that they receive on their physical networks, delivering security that follows their

[0001262039-20-000053:mdna:34]
applications and data. Fortinet cloud security offerings are available across all major cloud providers, including Amazon Web Services, Microsoft Azure, Google Cloud, Oracle Cloud, Alibaba Cloud and IBM Cloud. Our Cloud Security portfolio also includes securing applications, including email and web.

[0001262039-20-000053:mdna:35]
•Endpoint Protection, Internet of Things (“IoT”) and Operational Technology (“OT”) Security—We protect end-customers from advanced threats that target their devices and the data that reside on them through our advanced endpoint solutions that provide core endpoint protection, advanced threat protection, incident monitoring, and response. Additionally, the proliferation of IoT and the digitization of OT devices has generated new opportunities for us to grow our business. We offer network access control solutions that provide visibility, control and automated event responses in order to secure IoT devices.

[0001262039-20-000053:mdna:36]
•AI-Driven Security Operations—We develop and provide AI-driven security operations solutions, including FortiGuard and other security subscription services and our security operations, analytics, and reporting (“SOAR”) capabilities and solutions, that can be applied across the entire Fortinet Security Fabric platform. These solutions help customers better secure their environments by delivering deeper intelligence and insights and by narrowing the gaps in security skills and resources that are present in many organizations.

[0001262039-20-000053:mdna:37]
[same as prior period, unchanged from 0001262039-20-000032:mdna:39]

[0001262039-20-000053:mdna:38]
[same as prior period, unchanged from 0001262039-20-000032:mdna:40]

[0001262039-20-000053:mdna:39]
•Total revenue was $615.5 million and $1.19 billion during the three and six months ended June 30, 2020, respectively, an increase of 18% and 20%, respectively, compared to $521.7 million and $994.3 million in the same periods last year, respectively. Product revenue was $211.9 million and $404.2 million during the three and six months ended June 30, 2020, respectively, an increase of 12% and 15%, respectively, compared to $189.9 million and $352.6 million in the same periods last year, respectively. Service revenue was $403.6 million and $788.2 million during the three and six months ended June 30, 2020, respectively, an increase of 22% and 23%, respectively, compared to $331.8 million and $641.7 million in the same periods last year, respectively.

[0001262039-20-000053:mdna:40]
•Total gross profit was $480.4 million and $928.6 million during the three and six months ended June 30, 2020, respectively, an increase of 22% and 23%, respectively, compared to $393.4 million and $753.0 million in the same periods last year.

[0001262039-20-000053:mdna:41]
•We generated operating income of $116.7 million and $232.6 million during the three and six months ended June 30, 2020, respectively, an increase of 55% and 85%, respectively, compared to $75.2 million and $125.8 million in the same periods last year, respectively. Operating income during the three and six months ended June 30, 2020 included gains on an intellectual property (“IP”) matter of $1.1 million and $37.9 million, respectively.

[0001262039-20-000053:mdna:42]
•Cash, cash equivalents and investments were $1.63 billion as of June 30, 2020, a decrease of $582.6 million, or 26%, from December 31, 2019.

[0001262039-20-000053:mdna:43]
•During the six months ended June 30, 2020, we repurchased 11.4 million shares of common stock under our Share Repurchase Program (the “Repurchase Program”), for a total purchase price of $1.05 billion.

[0001262039-20-000053:mdna:44]
•Deferred revenue was $2.32 billion as of June 30, 2020, an increase of $186.9 million, or 9%, from December 31, 2019.

[0001262039-20-000053:mdna:45]
•We generated cash flows from operating activities of $566.4 million, which includes $50.0 million proceeds from an IP matter, during the six months ended June 30, 2020, an increase of $170.0 million, or 43%, compared to the same period last year.

[0001262039-20-000053:mdna:46]
Our revenue growth was driven by both product and service revenue. On a geographic basis, revenue continues to be diversified globally, which remains a key strength of our business. Product revenue grew 12% and 15% during the three and six months ended June 30, 2020, respectively, compared to the same periods last year. We experienced revenue growth across several of our hardware and software products, including SD-WAN and teleworker and remote security solutions. Service revenue growth of 22% and 23% during the three and six months ended June 30, 2020, respectively, compared to the same periods last year was driven by the strength of our FortiGuard and other security subscription revenue, which grew 22% and

[0001262039-20-000053:mdna:47]
23%, respectively, and of our FortiCare technical support and other service revenue, which grew 22% and 23%, respectively, compared to the same periods last year.

[0001262039-20-000053:mdna:48]
During the three and six months ended June 30, 2020, we recognized gains of $1.1 million and $37.9 million, respectively, on an IP matter in connection with a mutual covenant-not-to-sue and release agreement with a competitor in the network security industry. Excluding the gains on the IP matter, operating expenses as a percentage of revenue decreased by 1.9% and 1.6%, respectively, during the three and six months ended June 30, 2020 compared to the same periods last year. Headcount increased to 7,756 employees and contractors as of June 30, 2020, a 4% growth compared to 7,448 as of March 31, 2020 and a 10% growth compared to 7,082 as of December 31, 2019.

[0001262039-20-000053:mdna:49]
[same as prior period, unchanged from 0001262039-20-000032:mdna:50]

[0001262039-20-000053:mdna:50]
The United States and the global community we serve are facing unprecedented challenges posed by the COVID-19 pandemic. In response to the pandemic, we have taken a number of actions to protect our employees, including restricting travel and directing most of our employees to work from home. Where onsite work is permitted, we have implemented measures such as staggered work shifts, social distancing, health safety awareness training and frequent disinfection of shared spaces. We have implemented our readiness plans, which include steps to maintain critical internet infrastructure with most employees working remotely. We have not conducted any employee layoffs related to the COVID-19 pandemic, and we do not anticipate any related layoffs for the foreseeable future.

[0001262039-20-000053:mdna:51]
We have also increased our employee charitable contribution matching program to match employees’ contributions up to $2,000 per employee. We are also providing free online information technology security training for the public, aimed at helping high school and college students and professionals augment their security skill sets to open career opportunities and to help narrow the security skills gap. As of August 6, 2020, there have been over 500,000 registrations for our free online trainings since we launched the program. Costs incurred to date relating to COVID-19 pandemic impact mitigation efforts have not been material.

[0001262039-20-000053:mdna:52]
While the broader implications of the COVID-19 pandemic on our employees and overall financial performance remain uncertain, we have seen certain impacts on our business and operations, results of operations, financial condition, cash flows, liquidity and capital and financial resources as of and during the three and six months ended June 30, 2020. Conversely, some aspects of our business do not appear to have been significantly affected. During the three and six months ended June 30, 2020, we have observed the following:

[0001262039-20-000053:mdna:53]
•The practice of social distancing in most countries has reduced the ability for travel by our employees. In-person sales and marketing events or meetings that would normally have been held during the three and six months ended June 30, 2020 were canceled, postponed or converted into virtual events. As a result, expenses related to travel and marketing events decreased significantly. To the extent that it becomes safe for our employees to travel and for us to hold or attend marketing events, we expect these expenses to increase in the future.

[0001262039-20-000053:mdna:54]
•We have offered payment terms in excess of our contractual agreements to some of our distributor customers, which we believe will result in an increase to the average collection period of our trade receivables.

[0001262039-20-000053:mdna:55]
•The countries and geographic regions in which we experienced the fastest billings growth in the second quarter of 2020, as compared to the second quarter of 2019, were countries and geographic regions in which the COVID-19 pandemic is generally considered to have had a comparatively less severe impact on the population and economy during the quarter.

[0001262039-20-000053:mdna:56]
•We have noted that, for some of our customers, sales cycles appear to have lengthened, though it is unclear by how long or whether this trend will persist.

[0001262039-20-000053:mdna:57]
•Our average service contract duration remained consistent with the same period of 2019.

[0001262039-20-000053:mdna:58]
•With respect to our supply chain, our product backlog was in line with historical averages and our suppliers delivered over 90% of their commitments to us. Our channel inventory levels were consistent with prior quarters. In order to mitigate supply chain risk, we have increased, and we plan to further increase, our on-hand stock of certain products.

[0001262039-20-000053:mdna:59]
•The yield on investment-grade debt has decreased, contributing to the decrease in our interest income.

[0001262039-20-000053:mdna:60]
•In accordance with the Coronavirus Aid, Relief, and Economic Security Act (the “CARES Act”), we have deferred the deposit and payment of our employer’s share of Social Security taxes. This did not materially affect net cash provided by operating activities during the period.

[0001262039-20-000053:mdna:61]
Through the filing of this Quarterly Report on Form 10-Q, there have been no material changes to the trends described above. Going forward, however, the situation is uncertain, rapidly changing and hard to predict, and the COVID-19 pandemic may have a material negative impact on our future periods, including our results for the three months ending September 30, 2020, our annual results for 2020, and beyond. To highlight the uncertainty remaining for the three months ending September 30, 2020, it should be noted that, due to customer buying patterns and the efforts of our sales force and channel partners to meet or exceed quarterly quotas, we have historically received a substantial portion of each quarter’s sales orders and generated a substantial portion of each quarter’s billings and revenue during the last two weeks of the quarter. If we experience significant changes in our billings growth rates, it will impact product revenue in the current quarter and FortiGuard and FortiCare service revenues in subsequent quarters, as we sell annual and multi-year service contracts that are recognized ratably over the contractual service term. In addition, the broader implications of the pandemic on our business and operations and our financial results, including the extent to which the effects of the pandemic will impact future results and growth in the cybersecurity industry, remain uncertain. The duration and severity of the economic downturn from the pandemic may negatively impact our business and operations, results of operations, financial condition, cash flows, liquidity and capital and financial resources in a material way. As a result, the effects of the pandemic may not be fully reflected in our results of operations until future periods. For further discussion, see Part II, Item 1A of this Quarterly Report on Form 10-Q.

[0001262039-20-000053:mdna:62]
[same as prior period, unchanged from 0001262039-20-000032:mdna:54]

[0001262039-20-000053:mdna:63]
We primarily sell our products and services through a two-tier distribution model. We sell to distributors that sell to networking security and enterprise-focused resellers and to service providers and managed security service providers (“MSSPs”), who, in turn, sell to our end-customers. In certain cases, we sell directly to large service providers and major systems integrators. We also offer our products through major cloud providers, and have recognized revenue on a usage basis from Amazon Web Services, Microsoft Azure, IBM Cloud, Google Cloud, Oracle Cloud and Alibaba Cloud. We have also recognized revenue from customers who deploy our products in a bring-your-own-license (“BYOL”) arrangement in private clouds or at cloud providers. In a BYOL arrangement, a customer purchases a software license from us through our channel partners and deploys the software in a cloud provider’s environment. Similarly, customers may purchase such a license from us and deploy in their private cloud.

[0001262039-20-000053:mdna:64]
Our customers purchase our hardware products and software licenses, as well as our FortiGuard and other security subscription and FortiCare technical support services. We generally invoice at the time of our sale for the total price of the products and security and technical support services. The invoice is typically payable within 30 to 60 days, though we have recently offered extended payment terms to certain customers.

[0001262039-20-000053:mdna:65]
[same as prior period, unchanged from 0001262039-20-000032:mdna:57]

[0001262039-20-000053:mdna:66]
We monitor a number of key metrics, including the key financial metrics set forth below, in order to help us evaluate growth trends, establish budgets, measure the effectiveness of our sales and marketing efforts, and assess operational efficiencies. The following table summarizes revenue, deferred revenue, billings (non-GAAP), net cash provided by operating activities, and free cash flow (non-GAAP). We discuss revenue below under “Results of Operations,” and we discuss net cash provided by operating activities below under “—Liquidity and Capital Resources.” Deferred revenue, billings (non-GAAP), and free cash flow (non-GAAP) are discussed immediately below the following table:

[0001262039-20-000053:mdna:67]
|  | Three Months Ended Or As Of |  |  |
|  | June 30, 2020 |  | June 30, 2019 |
|  | (in millions) |  |  |
| Revenue | $ | 615.5 |  |  | $ | 521.7 |  |
| Deferred revenue | $ | 2,322.8 |  |  | $ | 1,866.5 |  |
| Billings (non-GAAP) | $ | 711.5 |  |  | $ | 622.4 |  |
| Net cash provided by operating activities | $ | 247.0 |  |  | $ | 195.1 |  |
| Free cash flow (non-GAAP) | $ | 216.1 |  |  | $ | 177.8 |  |

[0001262039-20-000053:mdna:68]
Deferred revenue. Our deferred revenue consists of amounts that have been invoiced but that have not yet been recognized as revenue. The majority of our deferred revenue balance consists of the unrecognized portion of service revenue

[0001262039-20-000053:mdna:69]
from FortiGuard and other security subscription and FortiCare technical support service contracts, which is recognized as revenue ratably over the contractual service period. We monitor our deferred revenue balance, deferred revenue growth and the mix of short-term and long-term deferred revenue because deferred revenue represents a significant portion of free cash flow and of revenue to be recognized in future periods. Deferred revenue was $2.32 billion as of June 30, 2020, an increase of $186.9 million, or 9%, from December 31, 2019.

[0001262039-20-000053:mdna:70]
Billings (non-GAAP). We define billings as revenue recognized in accordance with GAAP plus the change in deferred revenue from the beginning to the end of the period, less any deferred revenue balances acquired from business combination(s) during the period. We consider billings to be a useful metric for management and investors because billings drive current and future revenue, which is an important indicator of the health and viability of our business. There are a number of limitations related to the use of billings instead of GAAP revenue. First, billings include amounts that have not yet been recognized as revenue and are impacted by the term of security and support agreements. Second, we may calculate billings in a manner that is different from peer companies that report similar financial measures. Management accounts for these limitations by providing specific information regarding GAAP revenue and evaluating billings together with GAAP revenue. Total billings were $711.5 million for the three months ended June 30, 2020, an increase of 14% compared to $622.4 million in the same period last year.

[0001262039-20-000053:mdna:71]
[same as prior period, unchanged from 0001262039-20-000032:mdna:64]

[0001262039-20-000053:mdna:72]
|  | Three Months Ended |  |  |
|  | June 30, 2020 |  | June 30, 2019 |
|  | (in millions) |  |  |
| Billings: |  |  |  |
| Revenue | $ | 615.5 |  |  | $ | 521.7 |  |
| Add: Change in deferred revenue | 96.0 |  |  | 100.7 |  |
| Total billings (non-GAAP) | $ | 711.5 |  |  | $ | 622.4 |  |

[0001262039-20-000053:mdna:73]
Free cash flow (non-GAAP). We define free cash flow as net cash provided by operating activities minus purchases of property and equipment and excluding any significant non-recurring items. We believe free cash flow to be a liquidity measure that provides useful information to management and investors about the amount of cash generated by the business that, after capital expenditures, can be used for strategic opportunities, including repurchasing outstanding common stock, investing in our business, making strategic acquisitions and strengthening the balance sheet. A limitation of using free cash flow rather than the GAAP measures of cash provided by or used in operating activities, investing activities, and financing activities is that free cash flow does not represent the total increase or decrease in the cash and cash equivalents balance for the period because it excludes cash flows from investing activities other than capital expenditures and cash flows from financing activities. Management accounts for this limitation by providing information about our capital expenditures and other investing and financing activities on the face of the consolidated statements of cash flows and under “—Liquidity and Capital Resources” and by presenting cash flows from investing and financing activities in our reconciliation of free cash flow. In addition, it is important to note that other companies, including companies in our industry, may not use free cash flow, may calculate free cash flow in a different manner than we do or may use other financial measures to evaluate their performance, all of which could reduce the usefulness of free cash flow as a comparative measure. A reconciliation of net cash provided by operating activities, the most directly comparable financial measure calculated and presented in accordance with GAAP, to free cash flow is provided below:

[0001262039-20-000053:mdna:74]
|  | Three Months Ended |  |  |
|  | June 30, 2020 |  | June 30, 2019 |
|  | (in millions) |  |  |
| Free Cash Flow: |  |  |  |
| Net cash provided by operating activities | $ | 247.0 |  |  | $ | 195.1 |  |
| Less: Purchases of property and equipment | (30.9) |  |  | (17.3) |  |
| Free cash flow (non-GAAP) | $ | 216.1 |  |  | $ | 177.8 |  |
| Net cash provided by (used in) investing activities | $ | 212.2 |  |  | $ | (336.6) |  |
| Net cash used in financing activities | $ | (168.9) |  |  | $ | (53.3) |  |

[0001262039-20-000053:mdna:75]
29

[0001262039-20-000053:mdna:76]
[same as prior period, unchanged from 0001262039-20-000032:mdna:70]

[0001262039-20-000053:mdna:77]
[same as prior period, unchanged from 0001262039-20-000032:mdna:71]

[0001262039-20-000053:mdna:78]
There were no material changes to our critical accounting policies and estimates as of and for the three and six months ended June 30, 2020, as compared to the critical accounting policies and estimates described in our Annual Report on Form 10-K filed with the SEC on February 26, 2020 (the “Form 10-K”).

[0001262039-20-000053:mdna:79]
[same as prior period, unchanged from 0001262039-20-000032:mdna:73]

[0001262039-20-000053:mdna:80]
[same as prior period, unchanged from 0001262039-20-000032:mdna:74]

[0001262039-20-000053:mdna:81]
[same as prior period, unchanged from 0001262039-20-000032:mdna:75]

[0001262039-20-000053:mdna:82]
Three Months Ended June 30, 2020 and June 30, 2019

[0001262039-20-000053:mdna:83]
[same as prior period, unchanged from 0001262039-20-000032:mdna:77]

[0001262039-20-000053:mdna:84]
|  | Three Months Ended |  |  |  |  |  |  |  |  |  |  |
|  | June 30,2020 |  |  |  | June 30,2019 |  |  |  |  |  |  |
|  | Amount |  | % ofRevenue |  | Amount |  | % ofRevenue |  | Change |  | % Change |
|  | (in millions, except percentages) |  |  |  |  |  |  |  |  |  |  |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 211.9 |  |  | 34 | % |  | $ | 189.9 |  |  | 36 | % |  | $ | 22.0 |  |  | 12 | % |
| Service | 403.6 |  |  | 66 |  |  | 331.8 |  |  | 64 |  |  | 71.8 |  |  | 22 |  |
| Total revenue | $ | 615.5 |  |  | 100 | % |  | $ | 521.7 |  |  | 100 | % |  | $ | 93.8 |  |  | 18 | % |
| Revenue by geography: |  |  |  |  |  |  |  |  |  |  |  |
| Americas | $ | 260.2 |  |  | 42 | % |  | $ | 225.5 |  |  | 43 | % |  | $ | 34.7 |  |  | 15 | % |
| Europe, Middle East and Africa (“EMEA”) | 228.4 |  |  | 37 |  |  | 192.0 |  |  | 37 |  |  | 36.4 |  |  | 19 |  |
| Asia Pacific (“APAC”) | 126.9 |  |  | 21 |  |  | 104.2 |  |  | 20 |  |  | 22.7 |  |  | 22 |  |
| Total revenue | $ | 615.5 |  |  | 100 | % |  | $ | 521.7 |  |  | 100 | % |  | $ | 93.8 |  |  | 18 | % |

[0001262039-20-000053:mdna:85]
Total revenue increased by $93.8 million, or 18%, during the three months ended June 30, 2020 compared to the same period last year. We continued to experience diversification of revenue globally and across both customer and industry segments. Revenue from all regions grew, with EMEA contributing the largest portion of our revenue growth on an absolute dollar basis.

[0001262039-20-000053:mdna:86]
Product revenue increased by $22.0 million, or 12%, during the three months ended June 30, 2020 compared to the same period last year. We experienced revenue growth across many of our hardware and software products due to an increase in product revenue from our FortiGate solutions, including SD-WAN, as well as growth in sales of our Infrastructure Security, Cloud Security and Endpoint Protection solutions, including virtual firewall, teleworker and remote security solutions.

[0001262039-20-000053:mdna:87]
Service revenue increased by $71.8 million, or 22%, during the three months ended June 30, 2020 compared to the same period last year. FortiGuard and other security subscription and FortiCare technical support and other revenues increased by $39.5 million, or 22%, and by $32.3 million, or 22%, respectively, during the three months ended June 30, 2020 compared to the same period last year. The increases were primarily due to the recognition of revenue from our growing deferred revenue balance related to FortiGuard and other security subscriptions and FortiCare technical support, including our customers moving to higher-tier support offerings. Of the service revenue recognized during the three months ended June 30, 2020, 91% was included in the deferred revenue balance as of March 31, 2020.

[0001262039-20-000053:mdna:88]
[same as prior period, unchanged from 0001262039-20-000032:mdna:82]

[0001262039-20-000053:mdna:89]
|  | Three Months Ended |  |  |  |  |  |  |
|  | June 30,2020 |  | June 30,2019 |  | Change |  | % Change |
|  | (in millions, except percentages) |  |  |  |  |  |  |
| Cost of revenue: |  |  |  |  |  |  |  |
| Product | $ | 84.4 |  |  | $ | 82.7 |  |  | $ | 1.7 |  |  | 2 | % |
| Service | 50.7 |  |  | 45.6 |  |  | 5.1 |  |  | 11 |  |
| Total cost of revenue | $ | 135.1 |  |  | $ | 128.3 |  |  | $ | 6.8 |  |  | 5 | % |
| Gross margin (%): |  |  |  |  |  |  |  |
| Product | 60.2 | % |  | 56.5 | % |  |  |  |  |
| Service | 87.4 |  |  | 86.3 |  |  |  |  |  |
| Total gross margin | 78.1 | % |  | 75.4 | % |  |  |  |  |

[0001262039-20-000053:mdna:90]
Total gross margin increased by 2.7 percentage points during the three months ended June 30, 2020 compared to the same period last year, driven by improvements to both product and service gross margins.

[0001262039-20-000053:mdna:91]
Product gross margin increased by 3.7 percentage points during the three months ended June 30, 2020 compared to the same period last year. Product gross margin benefited from increased software sales and lower direct costs of hardware as a percentage of product revenue. Cost of product revenue was comprised primarily of third party contract manufacturers’ costs and the costs of materials used in production.

[0001262039-20-000053:mdna:92]
Service gross margin increased by 1.1 percentage points during the three months ended June 30, 2020 compared to the same period last year, as we experienced lower costs to replace and repair our products and our personnel costs grew more slowly than our service revenue. Cost of service revenue was comprised primarily of personnel costs.

[0001262039-20-000053:mdna:93]
[same as prior period, unchanged from 0001262039-20-000032:mdna:87]

[0001262039-20-000053:mdna:94]
|  | Three Months Ended |  |  |  |  |  |  |  | Change |  | % Change |
|  | June 30,2020 |  |  |  | June 30,2019 |  |  |  |  |  |  |
|  | Amount |  | % ofRevenue |  | Amount |  | % ofRevenue |  |  |  |  |
|  | (in millions, except percentages) |  |  |  |  |  |  |  |  |  |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | $ | 82.1 |  |  | 13% |  | $ | 67.4 |  |  | 12 | % |  | $ | 14.7 |  |  | 22 | % |
| Sales and marketing | 253.8 |  |  | 41 |  | 226.5 |  |  | 43 |  |  | 27.3 |  |  | 12 |  |
| General and administrative | 28.9 |  |  | 5 |  | 24.3 |  |  | 5 |  |  | 4.6 |  |  | 19 |  |
| Gain on IP matter | (1.1) |  |  | — |  | — |  |  | — |  |  | (1.1) |  |  | * |
| Total operating expenses | $ | 363.7 |  |  | 59% |  | $ | 318.2 |  |  | 61 | % |  | $ | 45.5 |  |  | 14 | % |

[0001262039-20-000053:mdna:95]
[same as prior period, unchanged from 0001262039-20-000032:mdna:89]

[0001262039-20-000053:mdna:96]
[same as prior period, unchanged from 0001262039-20-000032:mdna:90]

[0001262039-20-000053:mdna:97]
[same as prior period, unchanged from 0001262039-20-000032:mdna:91]

[0001262039-20-000053:mdna:98]
Research and development expense increased by $14.7 million, or 22%, during the three months ended June 30, 2020 compared to the same period last year, primarily due to an increase of $12.0 million in personnel-related costs as a result of increased headcount to support the development of new products, continued enhancements to our existing products and patent creation. We currently intend to continue to invest in our research and development organization, and expect research and development expense to remain at or increase in absolute dollars during the remainder of 2020.

[0001262039-20-000053:mdna:99]
[same as prior period, unchanged from 0001262039-20-000032:mdna:93]

[0001262039-20-000053:mdna:100]
Sales and marketing expense increased by $27.3 million, or 12%, during the three months ended June 30, 2020 compared to the same period last year, primarily due to an increase of $40.4 million in personnel-related costs as a result of increases to sales and marketing headcount in order to drive global market share gains. This increase was offset by savings related to decreased travel and fewer in-person marketing events as a result of the COVID-19 pandemic. We currently intend to continue to make investments in our sales resources and infrastructure and marketing strategy, which are critical to support our future growth, and expect sales and marketing expense to remain at or increase in absolute dollars during the remainder of 2020.

[0001262039-20-000053:mdna:101]
[same as prior period, unchanged from 0001262039-20-000032:mdna:95]

[0001262039-20-000053:mdna:102]
General and administrative expense increased by $4.6 million, or 19%, during the three months ended June 30, 2020 compared to the same period last year, primarily due to an increase in personnel-related costs of $3.2 million and an increase in the provision for expected credit losses of $1.1 million. We currently expect general and administrative expense to remain at or increase in absolute dollars during the remainder of 2020.

[0001262039-20-000053:mdna:103]
[same as prior period, unchanged from 0001262039-20-000032:mdna:97]

[0001262039-20-000053:mdna:104]
In January 2020, we entered into an agreement with a competitor in the network security industry, whereby, in February 2020, the competitor party paid us a lump sum of $50.0 million for a mutual covenant-not-to-sue for patent claims. During the three months ended June 30, 2020, we recorded $1.1 in amortization of the deferred component as a gain on IP matter in our condensed consolidated statements of income. See Note 10 of the notes to condensed consolidated financial statements included in Part I, Item 1 of this Quarterly Report on Form 10-Q for additional information regarding the gain on IP matter.

[0001262039-20-000053:mdna:105]
[same as prior period, unchanged from 0001262039-20-000032:mdna:99]

[0001262039-20-000053:mdna:106]
We generated operating income of $116.7 million during the three months ended June 30, 2020, an increase of $41.5 million, or 55%, compared to $75.2 million in the same period last year. Operating income as a percentage of revenue increased to 19% during the three months ended June 30, 2020 compared to 14% in the same period last year. The increase in operating margin is primarily due to the 2.7 percentage point improvement in gross margin and the 2.2 percentage point decrease in sales and marketing expense as a percentage of revenue.

[0001262039-20-000053:mdna:107]
Interest income—net and other income (expense)—net

[0001262039-20-000053:mdna:108]
|  | Three Months Ended |  |  |  |  |  |  |
|  | June 30,2020 |  | June 30,2019 |  | Change |  | % Change |
|  | (in millions, except percentages) |  |  |  |  |  |  |
| Interest income—net | $ | 4.0 |  |  | $ | 11.0 |  |  | $ | (7.0) |  |  | (64) | % |
| Other income (expense)—net | $ | 0.9 |  |  | $ | (0.4) |  |  | $ | 1.3 |  |  | (325) | % |

[0001262039-20-000053:mdna:109]
Interest income—net decreased during the three months ended June 30, 2020 compared to the same period last year, primarily due to lower interest rates and lower invested balances of cash, cash equivalents and investments. The lower cash, cash equivalents and investments were mainly due to our repurchases of common stock under the Repurchase Program during the past twelve months. Interest income—net varies depending on our average investment balances during the period, types and mix of investments, and market interest rates. The change in other income (expense)—net during the three months ended

[0001262039-20-000053:mdna:110]
June 30, 2020 compared to the same period last year was primarily due to net gains from foreign currency exchange compared to net losses in the same period last year.

[0001262039-20-000053:mdna:111]
[same as prior period, unchanged from 0001262039-20-000032:mdna:104]

[0001262039-20-000053:mdna:112]
|  | Three Months Ended |  |  |  | Change |  | % Change |
|  | June 30,2020 |  | June 30,2019 |  |  |  |  |
|  | (in millions, except percentages) |  |  |  |  |  |  |
| Provision for income taxes | $ | 9.5 |  |  | $ | 13.1 |  |  | $ | (3.6) |  |  | (27) | % |
| Effective tax rate (%) | 8 | % |  | 15 | % |  |  |  |  |

[0001262039-20-000053:mdna:113]
Our effective tax rate was 8% for the three months ended June 30, 2020 compared to an effective tax rate of 15% for the same period last year. The provision for income taxes for the three months ended June 30, 2020 was primarily comprised of U.S. federal and state taxes, withholding taxes and foreign taxes that were $28.2 million, which included a tax benefit of $5.0 million from the foreign-derived intangible income deduction. This tax provision for income taxes was favorably affected by excess tax benefits from stock-based compensation expense of $10.0 million and release of reserves of $8.7 million on uncertain tax positions and the interest due to the expiration of the statute of limitations.

[0001262039-20-000053:mdna:114]
The provision for income taxes for the three months ended June 30, 2019 was comprised of U.S. federal and state taxes, withholding taxes, and foreign taxes that were $24.5 million, which were offset by excess tax benefits from stock-based compensation expense of $11.7 million and release of reserves of $10.0 million on uncertain tax positions and the interest due to the expiration of the statute of limitations. This tax provision for income taxes was further impacted by an increase in tax expense of $10.3 million for an unrecognized tax benefit related to the Ninth Circuit’s Altera decision, regarding stock-based compensation expense in cost sharing arrangements.

[0001262039-20-000053:mdna:115]
Results of Operations

[0001262039-20-000053:mdna:116]
Six Months Ended June 30, 2020 and June 30, 2019

[0001262039-20-000053:mdna:117]
Revenue

[0001262039-20-000053:mdna:118]
|  | Six Months Ended |  |  |  |  |  |  |  |  |  |  |
|  | June 30,2020 |  |  |  | June 30,2019 |  |  |  |  |  |  |
|  | Amount |  | % ofRevenue |  | Amount |  | % ofRevenue |  | Change |  | % Change |
|  | (in millions, except percentages) |  |  |  |  |  |  |  |  |  |  |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 404.2 |  |  | 34 | % |  | $ | 352.6 |  |  | 35 | % |  | $ | 51.6 |  |  | 15 | % |
| Service | 788.2 |  |  | 66 |  |  | 641.7 |  |  | 65 |  |  | 146.5 |  |  | 23 |  |
| Total revenue | $ | 1,192.4 |  |  | 100 | % |  | $ | 994.3 |  |  | 100 | % |  | $ | 198.1 |  |  | 20 | % |
| Revenue by geography: |  |  |  |  |  |  |  |  |  |  |  |
| Americas | $ | 502.4 |  |  | 42 | % |  | $ | 426.0 |  |  | 43 | % |  | $ | 76.4 |  |  | 18 | % |
| EMEA | 449.1 |  |  | 38 |  |  | 369.2 |  |  | 37 |  |  | 79.9 |  |  | 22 |  |
| APAC | 240.9 |  |  | 20 |  |  | 199.1 |  |  | 20 |  |  | 41.8 |  |  | 21 |  |
| Total revenue | $ | 1,192.4 |  |  | 100 | % |  | $ | 994.3 |  |  | 100 | % |  | $ | 198.1 |  |  | 20 | % |

[0001262039-20-000053:mdna:119]
Total revenue increased by $198.1 million, or 20%, during the six months ended June 30, 2020 compared to the same period last year. We continued to experience diversification of revenue globally and across both customer and industry segments. Revenue from all regions grew, with EMEA contributing the largest portion of our revenue growth on a percentage basis and on an absolute dollar basis.

[0001262039-20-000053:mdna:120]
Product revenue increased by $51.6 million, or 15%, during the six months ended June 30, 2020 compared to the same period last year. We experienced revenue growth across many of our hardware and software products due to an increase in product revenue from our FortiGate solutions, including SD-WAN, as well as growth in sales of our Infrastructure Security, Cloud Security and Endpoint Protection solutions, including virtual firewall, teleworker and remote security solutions.

[0001262039-20-000053:mdna:121]
Service revenue increased by $146.5 million, or 23%, during the six months ended June 30, 2020 compared to the same period last year. FortiGuard and other security subscription and FortiCare technical support and other revenues increased by $81.3 million, or 23%, and by $65.2 million, or 23%, respectively, during the six months ended June 30, 2020 compared to the same period last year. The increases were primarily due to the recognition of revenue from our growing deferred revenue balance related to FortiGuard and other security subscriptions and FortiCare technical support, including our customers moving to higher-tier support offerings. Of the service revenue recognized during the six months ended June 30, 2020, 83% was included in the deferred revenue balance as of December 31, 2019.

[0001262039-20-000053:mdna:122]
Cost of revenue and gross margin

[0001262039-20-000053:mdna:123]
|  | Six Months Ended |  |  |  |  |  |  |
|  | June 30,2020 |  | June 30,2019 |  | Change |  | % Change |
|  | (in millions, except percentages) |  |  |  |  |  |  |
| Cost of revenue: |  |  |  |  |  |  |  |
| Product | $ | 160.7 |  |  | $ | 152.9 |  |  | $ | 7.8 |  |  | 5 | % |
| Service | 103.1 |  |  | 88.4 |  |  | 14.7 |  |  | 17 |  |
| Total cost of revenue | $ | 263.8 |  |  | $ | 241.3 |  |  | $ | 22.5 |  |  | 9 | % |
| Gross margin (%): |  |  |  |  |  |  |  |
| Product | 60.2 | % |  | 56.6 | % |  |  |  |  |
| Service | 86.9 |  |  | 86.2 |  |  |  |  |  |
| Total gross margin | 77.9 | % |  | 75.7 | % |  |  |  |  |

[0001262039-20-000053:mdna:124]
Total gross margin increased by 2.2 percentage points during the six months ended June 30, 2020 compared to the same period last year, driven by improvements to both product and service gross margins.

[0001262039-20-000053:mdna:125]
Product gross margin increased by 3.6 percentage points during the six months ended June 30, 2020 compared to the same period last year. Product gross margin benefited from increased software sales and lower direct costs of hardware as a percentage of product revenue. Cost of product revenue was comprised primarily of third-party contract manufacturers’ costs and the costs of materials used in production.

[0001262039-20-000053:mdna:126]
Service gross margin increased by 0.7 percentage points during the six months ended June 30, 2020 compared to the same period last year, as our personnel costs grew more slowly than our service revenue and we experienced lower costs to replace and repair our products. Cost of service revenue was comprised primarily of personnel costs.

[0001262039-20-000053:mdna:127]
34

[0001262039-20-000053:mdna:128]
Operating expenses

[0001262039-20-000053:mdna:129]
|  | Six Months Ended |  |  |  |  |  |  |  | Change |  | % Change |
|  | June 30,2020 |  |  |  | June 30,2019 |  |  |  |  |  |  |
|  | Amount |  | % ofRevenue |  | Amount |  | % ofRevenue |  |  |  |  |
|  | (in millions, except percentages) |  |  |  |  |  |  |  |  |  |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | $ | 162.4 |  |  | 14% |  | $ | 136.0 |  |  | 14 | % |  | $ | 26.4 |  |  | 19 | % |
| Sales and marketing | 513.8 |  |  | 43 |  | 442.4 |  |  | 44 |  |  | 71.4 |  |  | 16 |  |
| General and administrative | 57.7 |  |  | 5 |  | 48.8 |  |  | 5 |  |  | 8.9 |  |  | 18 |  |
| Gain on IP matter | (37.9) |  |  | (3) |  | — |  |  | — |  |  | (37.9) |  |  | * |
| Total operating expenses | $ | 696.0 |  |  | 58% |  | $ | 627.2 |  |  | 63 | % |  | $ | 68.8 |  |  | 11 | % |

[0001262039-20-000053:mdna:130]
Percentages have been rounded for presentation purposes and may differ from unrounded results.

[0001262039-20-000053:mdna:131]
* Not meaningful

[0001262039-20-000053:mdna:132]
Research and development

[0001262039-20-000053:mdna:133]
Research and development expense increased by $26.4 million, or 19%, during the six months ended June 30, 2020 compared to the same period last year, primarily due to an increase of $23.6 million in personnel-related costs as a result of increased headcount to support the development of new products, continued enhancements to our existing products and patent creation. We currently intend to continue to invest in our research and development organization, and expect research and development expense to remain at or increase in absolute dollars during the remainder of 2020.

[0001262039-20-000053:mdna:134]
Sales and marketing

[0001262039-20-000053:mdna:135]
Sales and marketing expense increased by $71.4 million, or 16%, during the six months ended June 30, 2020 compared to the same period last year, primarily due to an increase of $78.3 million in personnel-related costs as a result of increases to sales and marketing headcount in order to drive global market share gains. This increase was offset by savings related to decreased travel and fewer in-person marketing events as a result of the COVID-19 pandemic. We currently intend to continue to make investments in our sales resources and infrastructure and marketing strategy, which are critical to support our future growth, and expect sales and marketing expense to remain at or increase in absolute dollars during the remainder of 2020.

[0001262039-20-000053:mdna:136]
General and administrative

[0001262039-20-000053:mdna:137]
General and administrative expense increased by $8.9 million, or 18%, during the six months ended June 30, 2020 compared to the same period last year, primarily due to an increase in personnel-related costs of $5.6 million and an increase in the provision for expected credit losses of $1.1 million. We currently expect general and administrative expense to remain at or increase in absolute dollars during the remainder of 2020.

[0001262039-20-000053:mdna:138]
Gain on IP matter

[0001262039-20-000053:mdna:139]
In January 2020, we entered into an agreement with a competitor in the network security industry, whereby, in February 2020, the competitor party paid us a lump sum of $50.0 million for a mutual covenant-not-to-sue for patent claims. During the six months ended June 30, 2020, we recorded $36.0 million upfront and an additional $1.9 million in amortization of the deferred component as a gain on IP matter in our condensed consolidated statements of income. See Note 10 of the notes to condensed consolidated financial statements included in Part I, Item 1 of this Quarterly Report on Form 10-Q for additional information regarding the gain on IP matter.

[0001262039-20-000053:mdna:140]
Operating income and margin

[0001262039-20-000053:mdna:141]
We generated operating income of $232.6 million during the six months ended June 30, 2020, an increase of $106.8 million, or 85%, compared to $125.8 million in the same period last year. Operating income as a percentage of revenue increased to 20% during the six months ended June 30, 2020 compared to 13% in the same period last year. The increase in

[0001262039-20-000053:mdna:142]
35

[0001262039-20-000053:mdna:143]
operating margin is primarily due to the $37.9 million gain on IP matter, the 2.2 percentage point improvement in gross margin and the 1.4 percentage point decrease in sales and marketing expense as a percentage of revenue.

[0001262039-20-000053:mdna:144]
Interest income—net and other income (expense)—net

[0001262039-20-000053:mdna:145]
|  | Six Months Ended |  |  |  |  |  |  |
|  | June 30,2020 |  | June 30,2019 |  | Change |  | % Change |
|  | (in millions, except percentages) |  |  |  |  |  |  |
| Interest income—net | $ | 13.2 |  |  | $ | 21.2 |  |  | $ | (8.0) |  |  | (38) | % |
| Other income (expense)—net | $ | (7.1) |  |  | $ | (0.9) |  |  | $ | (6.2) |  |  | 689 | % |

[0001262039-20-000053:mdna:146]
Interest income—net decreased during the six months ended June 30, 2020 compared to the same period last year, primarily due to lower interest rates and lower invested balances of cash, cash equivalents and investments. The lower cash, cash equivalents and investments were mainly due to our repurchases of common stock under the Repurchase Program during the past twelve months. Interest income—net varies depending on our average investment balances during the period, types and mix of investments, and market interest rates. The change in other income (expense)—net during the six months ended June 30, 2020 compared to the same period last year was the result of a $4.3 million impairment charge on an investment in a privately held company during the first quarter of 2020. In addition, foreign currency exchange losses increased by $2.4 million compared to the same period last year.

[0001262039-20-000053:mdna:147]
Provision for income taxes

[0001262039-20-000053:mdna:148]
|  | Six Months Ended |  |  |  | Change |  | % Change |
|  | June 30,2020 |  | June 30,2019 |  |  |  |  |
|  | (in millions, except percentages) |  |  |  |  |  |  |
| Provision for income taxes | $ | 22.6 |  |  | $ | 14.6 |  |  | $ | 8.0 |  |  | 55 | % |
| Effective tax rate (%) | 9 | % |  | 10 | % |  |  |  |  |

[0001262039-20-000053:mdna:149]
Our effective tax rate was 9% for the six months ended June 30, 2020 compared to an effective tax rate of 10% for the same period last year. The provision for income taxes for the six months ended June 30, 2020 was primarily comprised of U.S. federal and state taxes, withholding taxes and foreign taxes that were $56.5 million, which included a tax benefit of $9.6 million from the foreign-derived intangible income deduction. This tax provision for income taxes was favorably affected by excess tax benefits from stock-based compensation expense of $25.2 million and release of reserves of $8.7 million on uncertain tax positions and the interest due to the expiration of the statute of limitations.

[0001262039-20-000053:mdna:150]
The provision for income taxes for the six months ended June 30, 2019 was comprised of U.S. federal and state taxes, withholding taxes, and foreign taxes that were $42.0 million, which were offset by excess tax benefits from stock-based compensation expense of $27.7 million and release of reserves of $10.0 million on uncertain tax positions and the interest due to the expiration of the statute of limitations. This tax provision for income taxes was further impacted by an increase in tax expense of $10.3 million for an unrecognized tax benefit related to the Ninth Circuit’s Altera decision, regarding stock-based compensation expense in cost sharing arrangements.

[0001262039-20-000053:mdna:151]
36

[0001262039-20-000053:mdna:152]
[same as prior period, unchanged from 0001262039-20-000032:mdna:107]

[0001262039-20-000053:mdna:153]
|  | As of |  |  |
|  | June 30,2020 |  | December 31,2019 |
|  | (in millions) |  |  |
| Cash and cash equivalents | $ | 916.4 |  |  | $ | 1,222.5 |  |
| Investments | 710.9 |  |  | 987.4 |  |
| Total cash, cash equivalents and investments | $ | 1,627.3 |  |  | $ | 2,209.9 |  |
| Working capital | $ | 596.8 |  |  | $ | 1,295.4 |  |
|  | Six Months Ended |  |  |
|  | June 30,2020 |  | June 30,2019 |
|  | (in millions) |  |  |
| Net cash provided by operating activities | $ | 566.4 |  |  | $ | 396.4 |  |
| Net cash provided by (used in) investing activities | 216.8 |  |  | (375.6) |  |
| Net cash used in financing activities | (1,089.3) |  |  | (111.1) |  |
| Net decrease in cash and cash equivalents | $ | (306.1) |  |  | $ | (90.3) |  |

[0001262039-20-000053:mdna:154]
Liquidity and capital resources may be impacted by our operating activities, as well as by our stock repurchases, proceeds associated with stock option exercises, issuances of common stock under our the Amended and Restated Fortinet, Inc. 2009 Equity Incentive Plan (the “Amended Plan”) and payment of taxes in connection with the net settlement of equity awards, real estate and other capital expenditures and business acquisitions.

[0001262039-20-000053:mdna:155]
In recent years, we have received significant capital resources from our billings to customers and, to some extent, from the exercise of stock options by our employees. Additional increases in billings may depend on a number of factors, including demand for our products and services, competition, market or industry changes, macroeconomic events such as the COVID-19 pandemic and our ability to execute. We expect proceeds from the exercise of stock options in future years to be impacted by the increased mix of restricted stock units versus stock options granted to our employees and to vary based on our share price.

[0001262039-20-000053:mdna:156]
In February 2020, we received a cash payment of $50.0 million pursuant to a mutual covenant-not-to-sue and release agreement with a competitor in the network security industry.

[0001262039-20-000053:mdna:157]
In July 2020, our board of directors approved a $500.0 million increase in the authorized stock repurchase amount under the Repurchase Program and extended the term of the Repurchase Program to February 28, 2022, bringing the aggregate amount authorized to be repurchased to $3.0 billion. During the six months ended June 30, 2020, we repurchased $1.05 billion in shares of our common stock under the Repurchase Program. As of August 6, 2020, $1.05 billion remained available for future share repurchases under the Repurchase Program.

[0001262039-20-000053:mdna:158]
Construction of a second building at our headquarters campus started in the fourth quarter of 2018 and related spending will continue in 2020 and until project completion. We estimate 2020 spending on the headquarters campus project to be between $100.0 million and $110.0 million dollars. The COVID-19 pandemic has resulted in a delay to the project schedule. We now estimate construction to be completed in early 2021.

[0001262039-20-000053:mdna:159]
As of June 30, 2020, our cash, cash equivalents and investments of $1.63 billion were invested primarily in deposit accounts, money market funds, corporate debt securities, commercial paper, certificates of deposit and term deposits and U.S. government securities. It is our investment policy to invest excess cash in a manner that preserves capital, provides liquidity and generates return without significantly increasing risk. We do not enter into investments for trading or speculative purposes.

[0001262039-20-000053:mdna:160]
The amount of cash, cash equivalents and investments held by our international subsidiaries was $113.6 million as of June 30, 2020 and $109.3 million as of December 31, 2019.

[0001262039-20-000053:mdna:161]
We believe that our existing cash and cash equivalents will be sufficient to meet our anticipated cash needs for at least the next 12 months. Our future capital requirements will depend on many factors, including our growth rate, the timing and amount of our share repurchases, the timing and extent of spending to support development efforts, the expansion of sales and

[0001262039-20-000053:mdna:162]
37

[0001262039-20-000053:mdna:163]
marketing activities, the introduction of new and enhanced products and services offerings, the continuing market acceptance of our products, our investments in purchasing or leasing real estate and macroeconomic impacts such as the COVID-19 pandemic. Historically, we have required capital principally to fund our working capital needs, share repurchases, capital expenditures and acquisition activities. In the event that additional financing is required from outside sources, we may not be able to raise it on terms acceptable to us or at all.

[0001262039-20-000053:mdna:164]
[same as prior period, unchanged from 0001262039-20-000032:mdna:116]

[0001262039-20-000053:mdna:165]
[same as prior period, unchanged from 0001262039-20-000032:mdna:117]

[0001262039-20-000053:mdna:166]
Our operating activities during the six months ended June 30, 2020 provided $566.4 million in cash as a result of the continued growth of our business and our ability to successfully manage our working capital. Changes in operating assets and liabilities primarily resulted from an increase in sales of our FortiGuard and other security subscription and FortiCare technical support services to new and existing customers, as reflected by an increase in our deferred revenue, and proceeds from the mutual covenant-not-to-sue and release agreement. Our total deferred revenue balance grew $186.9 million, or 9%, during the six months ended June 30, 2020.

[0001262039-20-000053:mdna:167]
[same as prior period, unchanged from 0001262039-20-000032:mdna:119]

[0001262039-20-000053:mdna:168]
[same as prior period, unchanged from 0001262039-20-000032:mdna:120]

[0001262039-20-000053:mdna:169]
During the six months ended June 30, 2020, cash provided by investing activities was $216.8 million, primarily driven by $278.8 million in cash proceeds from maturities and sales of investments, net of purchases of investments, and partially offset by $58.5 million of purchases of property and equipment, a large portion of which relates to our headquarters building construction.

[0001262039-20-000053:mdna:170]
[same as prior period, unchanged from 0001262039-20-000032:mdna:122]

[0001262039-20-000053:mdna:171]
[same as prior period, unchanged from 0001262039-20-000032:mdna:123]

[0001262039-20-000053:mdna:172]
During the six months ended June 30, 2020, cash used in financing activities was $1.09 billion, primarily driven by $1.05 billion used to repurchase shares of our common stock and $43.2 million used to pay tax withholding, net of proceeds from the issuance of common stock.

[0001262039-20-000053:mdna:173]
[same as prior period, unchanged from 0001262039-20-000032:mdna:125]

[0001262039-20-000053:mdna:174]
There were no material changes outside the ordinary course of business during the six months ended June 30, 2020 to the contractual obligations and commitments disclosed in Management’s Discussion and Analysis of Financial Condition and Results of Operations, set forth in Part II, Item 7, of the Form 10-K. See Note 11 of the notes to condensed consolidated financial statements included in Part I, Item 1 of this Quarterly Report on Form 10-Q for additional information regarding contractual obligations and commitments.

[0001262039-20-000053:mdna:175]
[same as prior period, unchanged from 0001262039-20-000032:mdna:127]

[0001262039-20-000053:mdna:176]
As of June 30, 2020, we did not have any relationships with unconsolidated organizations or financial partnerships, such as structured finance or special purpose entities that would have been established for the purpose of facilitating off-balance sheet arrangements or other contractually narrow or limited purposes.

[0001262039-20-000053:mdna:177]
38
