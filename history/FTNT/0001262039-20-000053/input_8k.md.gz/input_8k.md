# FTNT 8-K — 0001262039-20-000051 filed 2020-08-06

## item codes, every 8-K on or before 2020-08-06

- 2020-08-06 0001262039-20-000051 — 2.02, 9.01
- 2020-07-21 0001262039-20-000044 — 5.03, 8.01, 9.01
- 2020-06-24 0001262039-20-000038 — 5.07
- 2020-05-06 0001262039-20-000029 — 2.02, 9.01
- 2020-04-23 0001262039-20-000025 — 5.03, 9.01
- 2020-04-23 0001262039-20-000024 — 5.02 — amendment of 0001262039-20-000025
- 2020-02-28 0001262039-20-000015 — 5.02, 9.01
- 2020-02-06 0001262039-20-000004 — 2.02, 9.01
- 2019-12-12 0001262039-19-000038 — 8.01
- 2019-10-31 0001262039-19-000032 — 2.02, 9.01
- 2019-10-28 0001262039-19-000027 — 8.01
- 2019-10-23 0001262039-19-000025 — 5.02, 9.01
- 2019-08-01 0001262039-19-000021 — 2.02, 9.01
- 2019-06-26 0001262039-19-000018 — 5.07
- 2019-05-02 0001262039-19-000010 — 2.02, 9.01
- 2019-02-06 0001262039-19-000002 — 2.02, 9.01
- 2018-11-01 0001262039-18-000037 — 2.02, 9.01
- 2018-10-23 0001262039-18-000035 — 8.01
- 2018-08-01 0001262039-18-000025 — 2.02, 9.01
- 2018-06-28 0001262039-18-000023 — 5.03, 5.07, 9.01
- 2018-06-04 0001262039-18-000021 — 8.01
- 2018-05-03 0001262039-18-000017 — 2.02, 5.02, 9.01
- 2018-02-05 0001262039-18-000004 — 2.02, 5.02, 9.01
- 2017-10-26 0001262039-17-000031 — 2.02, 9.01
- 2017-10-19 0001262039-17-000029 — 5.02 — amendment, the index does not say of what
- 2017-07-26 0001262039-17-000025 — 2.02, 9.01
- 2017-06-27 0001262039-17-000023 — 5.07
- 2017-05-31 0001262039-17-000021 — 5.02 — amendment of 0001262039-17-000019
- 2017-05-30 0001262039-17-000019 — 5.02, 9.01
- 2017-04-27 0001262039-17-000013 — 2.02, 9.01
- 2017-02-02 0001262039-17-000003 — 2.02, 9.01
- 2016-10-27 0001262039-16-000085 — 2.02, 9.01
- 2016-10-11 0001262039-16-000082 — 2.02, 9.01
- 2016-07-28 0001262039-16-000076 — 2.02, 9.01
- 2016-07-22 0001262039-16-000073 — 8.01, 9.01
- 2016-06-20 0001262039-16-000068 — 5.07
- 2016-06-07 0001193125-16-614788 — 8.01
- 2016-04-26 0001262039-16-000061 — 2.02, 9.01
- 2016-01-28 0001262039-16-000051 — 2.02, 9.01
- 2015-10-27 0001262039-15-000045 — 2.02
- 2015-10-22 0001262039-15-000042 — 5.02 — amendment, the index does not say of what
- 2015-10-22 0001262039-15-000041 — 5.02 — amendment, the index does not say of what
- 2015-10-22 0001262039-15-000039 — 2.02, 9.01
- 2015-09-28 0001262039-15-000034 — 5.02, 9.01
- 2015-09-22 0001262039-15-000031 — 9.01 — amendment of 0001193125-15-248065
- 2015-08-28 0001262039-15-000027 — 3.01, 5.02
- 2015-07-23 0001262039-15-000021 — 5.02
- 2015-07-22 0001262039-15-000019 — 2.02, 9.01
- 2015-07-08 0001193125-15-248065 — 2.01, 8.01, 9.01
- 2015-06-22 0001193125-15-229099 — 5.07
- 2015-06-19 0001193125-15-228428 — 5.02, 9.01
- 2015-04-20 0001262039-15-000014 — 2.02, 9.01
- 2015-01-28 0001262039-15-000005 — 2.02, 9.01
- 2014-10-22 0001262039-14-000036 — 2.02, 9.01
- 2014-07-23 0001262039-14-000030 — 2.02, 9.01
- 2014-06-24 0001262039-14-000027 — 5.07
- 2014-04-23 0001262039-14-000021 — 2.02, 9.01
- 2014-04-21 0001262039-14-000018 — 5.03, 9.01
- 2014-01-29 0001262039-14-000004 — 2.02, 9.01
- 2013-12-20 0001262039-13-000061 — 5.02, 9.01
- 2013-11-27 0001262039-13-000057 — 5.02, 7.01, 9.01
- 2013-11-12 0001445305-13-002993 — 5.02
- 2013-10-23 0001262039-13-000051 — 2.02, 9.01
- 2013-07-30 0001262039-13-000039 — 2.02, 9.01
- 2013-06-25 0001262039-13-000030 — 5.07
- 2013-04-30 0001262039-13-000023 — 2.02, 9.01
- 2013-04-19 0001262039-13-000020 — 5.02, 9.01
- 2013-04-19 0001262039-13-000018 — 5.02 — amendment of 0001262039-13-000020
- 2013-04-10 0001262039-13-000016 — 2.02, 9.01
- 2013-03-26 0001262039-13-000013 — 5.02
- 2013-01-30 0001262039-13-000005 — 2.02, 9.01
- 2013-01-24 0001262039-13-000002 — 5.02, 9.01
- 2012-10-16 0001262039-12-000048 — 2.02, 9.01
- 2012-10-01 0001262039-12-000045 — 5.02
- 2012-09-26 0001262039-12-000043 — 5.01
- 2012-07-25 0001262039-12-000038 — 2.02, 9.01
- 2012-07-19 0001262039-12-000034 — 5.02
- 2012-06-20 0001193125-12-275869 — 5.07
- 2012-04-27 0001262039-12-000029 — 5.02
- 2012-04-24 0001262039-12-000025 — 2.02, 9.01
- 2012-01-31 0001262039-12-000006 — 2.02, 9.01
- 2012-01-25 0001262039-12-000003 — 5.03
- 2011-10-24 0001262039-11-000036 — 2.02
- 2011-07-19 0001262039-11-000014 — 2.02, 9.01
- 2011-06-27 0001193125-11-174474 — 5.02, 5.07, 9.01
- 2011-04-27 0001193125-11-111938 — 2.02, 9.01
- 2011-01-25 0001193125-11-013914 — 2.02, 9.01
- 2010-10-21 0001193125-10-233676 — 2.02, 9.01
- 2010-09-02 0001193125-10-203099 — 8.01
- 2010-07-22 0001193125-10-163844 — 2.02, 9.01
- 2010-06-24 0001193125-10-146082 — 5.07
- 2010-04-28 0001193125-10-096698 — 2.02, 9.01
- 2010-02-09 0001193125-10-024614 — 8.01
- 2010-01-27 0001193125-10-014292 — 2.02, 9.01
- 2010-01-26 0001193125-10-013031 — 5.02, 9.01

## late-filing notifications on or before 2020-08-06

- none on or before 2020-08-06

## item 2.02 — earnings release, exhibit 99.1

[0001262039-20-000051:8k_2_02:1]
EX-99.1
2
ftntq2-2020ex991.htm
PRESS RELEASE

[0001262039-20-000051:8k_2_02:2]
Document

[0001262039-20-000051:8k_2_02:3]
Press Release

[0001262039-20-000051:8k_2_02:4]
Fortinet Reports Second Quarter 2020 Financial Results

[0001262039-20-000051:8k_2_02:5]
Second Quarter 2020 Highlights

[0001262039-20-000051:8k_2_02:6]
•Total revenue of $615.5 million, up 18% year over year

[0001262039-20-000051:8k_2_02:7]
•Product revenue of $211.9 million, up 12% year over year

[0001262039-20-000051:8k_2_02:8]
•Billings of $711.5 million, up 14% year over year1

[0001262039-20-000051:8k_2_02:9]
•Deferred revenue of $2.32 billion, up 24% year over year

[0001262039-20-000051:8k_2_02:10]
•GAAP operating margin of 19.0%, up 460 basis points year over year

[0001262039-20-000051:8k_2_02:11]
•Non-GAAP operating margin of 27.3%, up 370 basis points year over year1

[0001262039-20-000051:8k_2_02:12]
•GAAP diluted net income per share of $0.68

[0001262039-20-000051:8k_2_02:13]
•Non-GAAP diluted net income per share of $0.821

[0001262039-20-000051:8k_2_02:14]
•Cash flow from operations of $247.0 million

[0001262039-20-000051:8k_2_02:15]
•Free cash flow of $216.1 million, up $38.3 million year over year1

[0001262039-20-000051:8k_2_02:16]
•Cash paid for share repurchases of $156.1 million

[0001262039-20-000051:8k_2_02:17]
SUNNYVALE, Calif. - August 6, 2020 - Fortinet® (Nasdaq: FTNT), a global leader in broad, integrated and automated cybersecurity solutions, today announced financial results for the second quarter ended June 30, 2020.

[0001262039-20-000051:8k_2_02:18]
“Strong demand for secure SD-WAN and work-from-home capabilities helped power 18% second quarter revenue growth. Secure SD-WAN billings were approximately 12% of second quarter billings, making this the first time in which SD-WAN represented over 10% of quarterly billings,” said Ken Xie, Founder, Chairman and Chief Executive Officer. “With the network edge stretched across the entire digital infrastructure, we believe networking and security will continue to converge. Recent Secure Access Service Edge, or SASE, market momentum further validates our security-driven networking approach. Our OPAQ Networks acquisition means Fortinet will have one of the most comprehensive SASE platforms.”

[0001262039-20-000051:8k_2_02:19]
Financial Highlights for the Second Quarter of 2020

[0001262039-20-000051:8k_2_02:20]
•Revenue: Total revenue was $615.5 million for the second quarter of 2020, an increase of 18.0% compared to $521.7 million for the same quarter of 2019.

[0001262039-20-000051:8k_2_02:21]
•Product Revenue: Product revenue was $211.9 million for the second quarter of 2020, an increase of 11.6% compared to $189.9 million for the same quarter of 2019.

[0001262039-20-000051:8k_2_02:22]
•Service Revenue: Service revenue was $403.6 million for the second quarter of 2020, an increase of 21.6% compared to $331.8 million for the same quarter of 2019.

[0001262039-20-000051:8k_2_02:23]
•Billings1: Total billings were $711.5 million for the second quarter of 2020, an increase of 14.3% compared to $622.4 million for the same quarter of 2019.

[0001262039-20-000051:8k_2_02:24]
•Deferred Revenue: Total deferred revenue was $2.32 billion as of June 30, 2020, an increase of 24.4% compared to $1.87 billion as of June 30, 2019.

[0001262039-20-000051:8k_2_02:25]
•GAAP Operating Income and Margin: GAAP operating income was $116.7 million for the second quarter of 2020, representing a GAAP operating margin of 19.0%. GAAP operating income was $75.2 million for the same quarter of 2019, representing a GAAP operating margin of 14.4%.

[0001262039-20-000051:8k_2_02:26]
•Non-GAAP Operating Income and Margin1: Non-GAAP operating income was $168.2 million for the second quarter of 2020, representing a non-GAAP operating margin of 27.3%. Non-GAAP operating income was $123.1 million for the second quarter of 2019, representing a non-GAAP operating margin of 23.6%.

[0001262039-20-000051:8k_2_02:27]
•GAAP Net Income and Diluted Net Income Per Share: GAAP net income was $112.1 million for the second quarter of 2020, compared to GAAP net income of $72.7 million for the same quarter of 2019. GAAP diluted net income per share was $0.68 for the second quarter of 2020, based on 165.4 million diluted weighted-average shares outstanding, compared to GAAP diluted net income per share of $0.42 for the same quarter of 2019, based on 175.1 million diluted weighted-average shares outstanding.

[0001262039-20-000051:8k_2_02:28]
•Non-GAAP Net Income and Diluted Net Income Per Share1: Non-GAAP net income was $135.1 million for the second quarter of 2020, compared to non-GAAP net income of $101.6 million for the same quarter of 2019. Non-GAAP diluted net income per share was $0.82 for the second quarter of 2020, based on 165.4 million diluted weighted-average shares outstanding, compared to $0.58 for the same quarter of 2019, based on 175.1 million diluted weighted-average shares outstanding.

[0001262039-20-000051:8k_2_02:29]
•Cash Flow and Free Cash Flow1: In the second quarter of 2020, cash flow from operations was $247.0 million compared to $195.1 million in the same quarter of 2019. Free cash flow was $216.1 million during the second quarter of 2020, compared to $177.8 million for the same quarter of 2019.

[0001262039-20-000051:8k_2_02:30]
•Share Repurchase: In the second quarter of 2020, cash paid for share repurchases was $156.1 million compared to $33.8 million in the same quarter of 2019. In July 2020, Fortinet’s Board of Directors has authorized the increase of $500.0 million to $3.0 billion of our outstanding common stock and extended the share repurchase program through February 28, 2022. As of August 6, 2020, $1.05 billion remained available for future share repurchase.

[0001262039-20-000051:8k_2_02:31]
Guidance

[0001262039-20-000051:8k_2_02:32]
For the third quarter of 2020, Fortinet currently expects:

[0001262039-20-000051:8k_2_02:33]
•Revenue in the range of $630 million to $645 million

[0001262039-20-000051:8k_2_02:34]
•Billings in the range of $705 million to $730 million

[0001262039-20-000051:8k_2_02:35]
•Non-GAAP gross margin in the range of 78.0% to 79.0%

[0001262039-20-000051:8k_2_02:36]
•Non-GAAP operating margin in the range of 25.5% to 26.5%

[0001262039-20-000051:8k_2_02:37]
•Diluted non-GAAP net income per share in the range of $0.76 to $0.78, assuming a non-GAAP effective tax rate of 22%. This assumes a diluted share count of 168 million to 170 million.

[0001262039-20-000051:8k_2_02:38]
Our guidance with respect to non-GAAP financial measures excludes stock-based compensation, amortization of acquired intangible assets and gain on intellectual property matter. We have not reconciled our guidance with respect to non-GAAP financial measures to the corresponding GAAP measures because certain items that impact these measures are uncertain or out of our control, or cannot be reasonably predicted. Accordingly, a reconciliation of these non-GAAP financial measures to the corresponding GAAP measures is not available without unreasonable effort.

[0001262039-20-000051:8k_2_02:39]
1 A reconciliation of GAAP to non-GAAP measures has been provided in the financial statement tables included in this press release. An explanation of these measures is also included below under the heading “Non-GAAP Financial Measures.”

[0001262039-20-000051:8k_2_02:40]
Conference Call Details

[0001262039-20-000051:8k_2_02:41]
Fortinet will host a conference call today at 1:30 p.m. Pacific Time (4:30 p.m. Eastern Time) to discuss the earnings results. The call can be accessed by dialing (877) 303-6913 (domestic) or (224) 357-2188 (international) with conference ID # 2588048. A live webcast of the conference call and supplemental slides will be accessible from the Investor Relations page of Fortinet’s website at https://investor.fortinet.com and a replay will be archived and accessible at https://investor.fortinet.com/events-and-presentations. A replay of this conference call can also be accessed through August 13, 2020, by dialing (855) 859-2056 (domestic) or (404) 537-3406 (international) with conference ID #2588048.

[0001262039-20-000051:8k_2_02:42]
Third Quarter 2020 Virtual Conference Participation Schedule:

[0001262039-20-000051:8k_2_02:43]
•Oppenheimer 23rd Annual Virtual Technology, Internet & Communications Conference

[0001262039-20-000051:8k_2_02:44]
August 11, 2020

[0001262039-20-000051:8k_2_02:45]
•BMO 2020 Virtual Technology Summit

[0001262039-20-000051:8k_2_02:46]
August 25, 2020

[0001262039-20-000051:8k_2_02:47]
•Citibank 2020 Global Technology Virtual Conference

[0001262039-20-000051:8k_2_02:48]
September 9, 2020

[0001262039-20-000051:8k_2_02:49]
•2020 Colliers Institutional Investor Conference (IR Only)

[0001262039-20-000051:8k_2_02:50]
September 10, 2020

[0001262039-20-000051:8k_2_02:51]
Members of Fortinet’s management team are expected to present at these conferences and discuss the latest company strategies and initiatives. Fortinet’s conference presentations are expected to be available via webcast on the company’s web site. To access the most updated information and listen to the webcast of each event, please visit the Investor Relations page of Fortinet’s website at https://investor.fortinet.com. The schedule is subject to change.

[0001262039-20-000051:8k_2_02:52]
About Fortinet (www.fortinet.com)

[0001262039-20-000051:8k_2_02:53]
Fortinet (Nasdaq: FTNT) secures the largest enterprise, service provider, and government organizations around the world. Fortinet empowers its customers with complete visibility and control across the expanding attack surface and the power to take on ever-increasing performance requirements today and into the future. Only the Fortinet Security Fabric platform can address the most critical security challenges and protect data across the entire digital infrastructure, whether in networked, application, multi-cloud or edge environments. Both a technology company and a learning organization, the Fortinet Network Security Institute has one

[0001262039-20-000051:8k_2_02:54]
of the largest and broadest cybersecurity training programs in the industry. Learn more at https://www.fortinet.com, the Fortinet Blog or FortiGuard Labs.

[0001262039-20-000051:8k_2_02:55]
#          #          #

[0001262039-20-000051:8k_2_02:56]
Copyright © 2020 Fortinet, Inc. All rights reserved. The symbols ® and ™ denote respectively federally registered trademarks and common law trademarks of Fortinet, Inc., its subsidiaries and affiliates. Fortinet’s trademarks include, but are not limited to, the following: Fortinet, the Fortinet logo, FortiGate, FortiOS, FortiGuard, FortiCare, FortiAnalyzer, FortiManager, FortiASIC, FortiClient, FortiCloud, FortiCore, FortiMail, FortiSandbox, FortiADC, FortiAI, FortiAP, FortiAppEngine, FortiAppMonitor, FortiAuthenticator, FortiBalancer, FortiBIOS, FortiBridge, FortiCache, FortiCam, FortiCamera, FortiCarrier, FortiCASB, FortiCenter, FortiCentral, FortiConnect, FortiController, FortiConverter, FortiCWP, FortiDB, FortiDDoS, FortiDeceptor, FortiDirector, FortiDNS, FortiEDR, FortiExplorer, FortiExtender, FortiFone, FortiHypervisor, FortiInsight, FortiIsolator, FortiLocator, FortiLog, FortiMeter, FortiMoM, FortiMonitor, FortiNAC, FortiPartner, FortiPortal, FortiPresence , FortiProtect, FortiProxy, FortiRecorder, FortiReporter, FortiSASE, FortiScan, FortiSDNConnector, FortiSIEM, FortiSDWAN, FortiSMS, FortiSOAR, FortiSwitch, FortiTester, FortiToken, FortiTrust, FortiVoice, FortiVoIP, FortiWAN, FortiWeb, FortiWiFi, FortiWLC, FortiWLCOS and FortiWLM. Other trademarks belong to their respective owners. Fortinet has not independently verified statements or certifications herein attributed to third parties and Fortinet does not independently endorse such statements. Notwithstanding anything to the contrary herein, nothing herein constitutes a warranty, guarantee, contract, binding specification or other binding commitment by Fortinet or any indication of intent related to a binding commitment, and performance and other specification information herein may be unique to certain environments.

[0001262039-20-000051:8k_2_02:57]
FTNT-F

[0001262039-20-000051:8k_2_02:58]
Forward-Looking Statements

[0001262039-20-000051:8k_2_02:59]
This press release contains forward-looking statements that involve risks and uncertainties. These forward-looking statements include statements regarding demand for our products and services, guidance and expectations around future financial results, including guidance and expectations for the third quarter, statements regarding market share gains and innovation and investment areas, statements that we will have one of the most comprehensive SASE platforms, statements regarding continued convergence of networking and security and validation of our approach, and statements regarding the momentum in our business and future growth expectations and objectives. Although we attempt to be accurate in making forward-looking statements, it is possible that future circumstances might differ from the assumptions on which such statements are based such that actual results are materially different from our forward-looking statements in this release. Important factors that could cause results to differ materially from the statements herein include the following: general economic risks, including those caused by the COVID-19 pandemic; negative impacts from the COVID-19 pandemic on sales, billings, revenue, demand and buying patterns, component supply and ability to manufacture products to meet demand in a timely fashion, and costs such as possible increased costs for shipping and components; global economic conditions, country-specific economic conditions, and foreign currency risks; competitiveness in the security market; the dynamic nature of the security market and its products and services; specific economic risks worldwide and in different geographies, and among different customer segments; uncertainty regarding demand and increased business and renewals from existing customers; uncertainties around continued success in sales growth and market share gains; actual or perceived vulnerabilities in our supply chain, products or services, and any actual or perceived breach of our network or our customers’ networks; longer sales cycles, particularly for larger enterprise, service providers, government and other large organization customers; the effectiveness of our salesforce and failure to convert sales pipeline into final sales; risks associated with successful implementation

[0001262039-20-000051:8k_2_02:60]
COVID-19 Impact

[0001262039-20-000051:8k_2_02:61]
While the broader implications of the COVID-19 pandemic on our employees and overall financial performance remain uncertain, we have seen certain impacts on our business and operations, results of operations, financial condition, cash flows, liquidity and capital and financial resources. Going forward, the situation is uncertain, rapidly changing and hard to predict, and the COVID-19 pandemic may have a material negative impact on our future periods, including our results for the three months ending September 30, 2020, our annual results for 2020, and beyond. To highlight the uncertainty remaining for the three-month period ending September 30, 2020, it should be noted that, due to customer buying patterns and the efforts of our sales force and channel partners to meet or exceed quarterly quotas, we have historically received a substantial portion of each quarter’s sales orders and generated a substantial portion of each quarter’s billings and revenue during the last two weeks of the quarter. If we experience significant changes in our billings growth rates, it will impact product revenue in the current quarter and FortiGuard and FortiCare service revenues in subsequent quarters, as we sell annual and multi-year service contracts that are recognized ratably over the contractual service term. In addition, the broader implications of the pandemic on our business and operations and our financial results, including the extent to which the effects of the pandemic will impact future results and growth in the cybersecurity industry, remain uncertain. The duration and severity of the economic downturn from the pandemic may negatively impact our business and operations, results of operations, financial condition, cash flows, liquidity and capital and financial resources in a material way. As a result, the effects of the pandemic may not be fully reflected in our results of operations until future periods.

[0001262039-20-000051:8k_2_02:62]
Non-GAAP Financial Measures

[0001262039-20-000051:8k_2_02:63]
We have provided in this release financial information that has not been prepared in accordance with U.S. Generally Accepted Accounting Principles (GAAP). These non-GAAP financial and liquidity measures are not based on any standardized methodology prescribed by GAAP and are not necessarily comparable to similar measures presented by other companies. We use these non-GAAP financial measures internally in analyzing our financial results and believe they are useful to investors, as a supplement to GAAP measures, in evaluating our ongoing operational performance. We believe that the use of these non-GAAP financial measures provides an additional tool for investors to use in evaluating ongoing operating results and trends and in comparing our financial results with peer companies, many of which present similar non-GAAP financial measures to investors.

[0001262039-20-000051:8k_2_02:64]
Non-GAAP financial measures should not be considered in isolation from, or as a substitute for, financial information prepared in accordance with GAAP. Investors are encouraged to review the reconciliation of these non-GAAP financial measures to their most directly comparable GAAP financial measures provided in the financial statement tables below.

[0001262039-20-000051:8k_2_02:65]
Billings (non-GAAP). We define billings as revenue recognized in accordance with GAAP plus the change in deferred revenue from the beginning to the end of the period less any deferred revenue balances acquired from business combination(s) during the period. We consider billings to be a useful metric for management and investors because billings drive current and future revenue, which is an important indicator of the health and viability of our business. There are a number of limitations related to the use of billings instead of GAAP revenue. First, billings include amounts that have not yet been recognized as revenue and are impacted by the term of security and support agreements. Second, we may calculate billings in a manner that is different from peer companies that report similar financial measures. Management accounts for these limitations by providing specific information regarding GAAP revenue and evaluating billings together with GAAP revenue.

[0001262039-20-000051:8k_2_02:66]
Free cash flow (non-GAAP). We define free cash flow as net cash provided by operating activities minus purchases of property and equipment and excluding any significant non-recurring items, such as proceeds from intellectual property matter. We believe free cash flow to be a liquidity measure that provides useful information to management and investors about the amount of cash generated by the business that, after capital expenditures and net of proceeds from intellectual property matter, can be used for strategic opportunities, including repurchasing outstanding common stock, investing in our business, making strategic acquisitions and strengthening the balance sheet. A limitation of using free cash flow rather than the GAAP measures of cash provided by or used in operating activities, investing activities, and financing activities is that free cash flow does not represent the total increase or decrease in the cash and cash equivalents balance for the period because it excludes cash flows from significant non-recurring items, such as proceeds from intellectual property matter, investing activities other than capital expenditures and cash flows from financing activities. Management accounts for this limitation by providing information about our capital expenditures and other investing and financing activities on the face of the cash flow statement and under the caption “Management’s Discussion and Analysis of Financial Condition and Results of Operations—Liquidity and Capital Resources” in our most recent Quarterly Report on Form 10-Q and Annual Report on Form 10-K and by presenting cash flows from investing and financing activities in our reconciliation of free cash flow. In addition, it is important to note that other companies, including companies in our industry, may not use free cash flow, may calculate free cash flow in a different manner than we do or may use other financial measures to evaluate their performance, all of which could reduce the usefulness of free cash flow as a comparative measure.

[0001262039-20-000051:8k_2_02:67]
Non-GAAP operating income and operating margin. We define non-GAAP operating income as operating income plus stock-based compensation, impairment and amortization of acquired intangible assets, gain on intellectual property matter and, when applicable, other significant non-recurring items in a given quarter, such as non-recurring gains or losses on litigation-related matters. Non-GAAP operating margin is defined as non-GAAP operating income divided by GAAP revenue. We consider these non-GAAP financial measures to be useful metrics for management and investors because they exclude the items noted above so that our management and investors can compare our recurring core business operating results over multiple periods. There are a number of limitations related to the use of non-GAAP operating income instead of operating income or loss calculated in accordance with GAAP. First, non-GAAP operating income excludes the items noted above. Second, the components of the costs that we exclude from our calculation of non-GAAP operating income may differ from the components that peer companies exclude when they report their non-GAAP results of operations. Management accounts for these limitations by providing specific information regarding the GAAP amounts excluded from non-GAAP operating income and evaluating non-GAAP operating income together with operating income calculated in accordance with GAAP.

[0001262039-20-000051:8k_2_02:68]
Non-GAAP net income and diluted net income per share. We define non-GAAP net income as net income or loss plus the items noted above under non-GAAP operating income and operating margin. In addition, we adjust non-GAAP net income and diluted net income per share for gains or losses on investments in privately held companies and a tax adjustment required for an effective tax rate on a non-GAAP basis, which differs from the GAAP effective tax rate. We define non-GAAP diluted net income per share as non-GAAP net income divided by the non-GAAP diluted weighted-average shares outstanding. We consider these non-GAAP financial measures to be useful metrics for management and investors for the same reasons that we use non-GAAP operating income and non-GAAP operating margin. However, in order to provide a more complete picture of our recurring core business operating results, we include in non-GAAP net income and non-GAAP diluted net income per share, the tax adjustment required resulting in an effective tax rate on a non-GAAP basis, which often differs from the GAAP tax rate. We believe the non-GAAP effective tax rates we use are reasonable estimates of normalized tax rates for our current and prior fiscal years under our global operating structure. The same limitations described above regarding our use of non-GAAP operating income and non-GAAP operating margin apply to our use of non-GAAP net income and non-GAAP diluted net income per share. We account for these limitations by providing specific information regarding the GAAP amounts excluded from non-GAAP net income and non-GAAP diluted net income per share and evaluating non-GAAP net income and non-GAAP diluted net income per share together with net income or loss and diluted net income per share calculated in accordance with GAAP.

[0001262039-20-000051:8k_2_02:69]
FORTINET, INC.

[0001262039-20-000051:8k_2_02:70]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001262039-20-000051:8k_2_02:71]
(Unaudited, in millions)

[0001262039-20-000051:8k_2_02:72]
|  | June 30,2020 |  | December 31,2019 |
| ASSETS |  |  |  |
| CURRENT ASSETS: |  |  |  |
| Cash and cash equivalents | $ | 916.4 |  |  | $ | 1,222.5 |  |
| Short-term investments | 610.5 |  |  | 843.1 |  |
| Accounts receivable—net | 498.7 |  |  | 544.3 |  |
| Inventory | 126.0 |  |  | 117.9 |  |
| Prepaid expenses and other current assets | 57.1 |  |  | 41.2 |  |
| Total current assets | 2,208.7 |  |  | 2,769.0 |  |
| LONG-TERM INVESTMENTS | 100.4 |  |  | 144.3 |  |
| PROPERTY AND EQUIPMENT—NET | 392.6 |  |  | 344.3 |  |
| DEFERRED CONTRACT COSTS | 263.5 |  |  | 237.0 |  |
| DEFERRED TAX ASSETS | 218.9 |  |  | 232.6 |  |
| GOODWILL AND OTHER INTANGIBLE ASSETS—NET | 90.6 |  |  | 98.3 |  |
| OTHER ASSETS | 55.9 |  |  | 60.0 |  |
| TOTAL ASSETS | $ | 3,330.6 |  |  | $ | 3,885.5 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |
| CURRENT LIABILITIES: |  |  |  |
| Accounts payable | $ | 107.2 |  |  | $ | 96.4 |  |
| Accrued liabilities | 118.2 |  |  | 101.8 |  |
| Accrued payroll and compensation | 110.7 |  |  | 101.8 |  |
| Deferred revenue | 1,275.8 |  |  | 1,173.6 |  |
| Total current liabilities | 1,611.9 |  |  | 1,473.6 |  |
| DEFERRED REVENUE | 1,047.0 |  |  | 962.3 |  |
| INCOME TAX LIABILITIES | 77.3 |  |  | 82.8 |  |
| OTHER LIABILITIES | 50.5 |  |  | 44.9 |  |
| Total liabilities | 2,786.7 |  |  | 2,563.6 |  |
| COMMITMENTS AND CONTINGENCIES |  |  |  |
| STOCKHOLDERS’ EQUITY: |  |  |  |
| Common stock | 0.2 |  |  | 0.2 |  |
| Additional paid-in capital | 1,154.3 |  |  | 1,180.3 |  |
| Accumulated other comprehensive income | 2.5 |  |  | 1.1 |  |
| Retained earnings (accumulated deficit) | (613.1) |  |  | 140.3 |  |
| Total stockholders’ equity | 543.9 |  |  | 1,321.9 |  |
| TOTAL LIABILITIES AND STOCKHOLDERS’ EQUITY | $ | 3,330.6 |  |  | $ | 3,885.5 |  |

[0001262039-20-000051:8k_2_02:73]
FORTINET, INC.

[0001262039-20-000051:8k_2_02:74]
CONDENSED CONSOLIDATED STATEMENTS OF INCOME

[0001262039-20-000051:8k_2_02:75]
(Unaudited, in millions, except per share amounts)

[0001262039-20-000051:8k_2_02:76]
|  | Three Months Ended |  |  |  | Six Months Ended |  |  |
|  | June 30,2020 |  | June 30,2019 |  | June 30,2020 |  | June 30,2019 |
| REVENUE: |  |  |  |  |  |  |  |
| Product | $ | 211.9 |  |  | $ | 189.9 |  |  | $ | 404.2 |  |  | $ | 352.6 |  |
| Service | 403.6 |  |  | 331.8 |  |  | 788.2 |  |  | 641.7 |  |
| Total revenue | 615.5 |  |  | 521.7 |  |  | 1,192.4 |  |  | 994.3 |  |
| COST OF REVENUE: |  |  |  |  |  |  |  |
| Product | 84.4 |  |  | 82.7 |  |  | 160.7 |  |  | 152.9 |  |
| Service | 50.7 |  |  | 45.6 |  |  | 103.1 |  |  | 88.4 |  |
| Total cost of revenue | 135.1 |  |  | 128.3 |  |  | 263.8 |  |  | 241.3 |  |
| GROSS PROFIT: |  |  |  |  |  |  |  |
| Product | 127.5 |  |  | 107.2 |  |  | 243.5 |  |  | 199.7 |  |
| Service | 352.9 |  |  | 286.2 |  |  | 685.1 |  |  | 553.3 |  |
| Total gross profit | 480.4 |  |  | 393.4 |  |  | 928.6 |  |  | 753.0 |  |
| OPERATING EXPENSES: |  |  |  |  |  |  |  |
| Research and development | 82.1 |  |  | 67.4 |  |  | 162.4 |  |  | 136.0 |  |
| Sales and marketing | 253.8 |  |  | 226.5 |  |  | 513.8 |  |  | 442.4 |  |
| General and administrative | 28.9 |  |  | 24.3 |  |  | 57.7 |  |  | 48.8 |  |
| Gain on intellectual property matter | (1.1) |  |  | — |  |  | (37.9) |  |  | — |  |
| Total operating expenses | 363.7 |  |  | 318.2 |  |  | 696.0 |  |  | 627.2 |  |
| OPERATING INCOME | 116.7 |  |  | 75.2 |  |  | 232.6 |  |  | 125.8 |  |
| INTEREST INCOME—NET | 4.0 |  |  | 11.0 |  |  | 13.2 |  |  | 21.2 |  |
| OTHER INCOME (EXPENSE)—NET | 0.9 |  |  | (0.4) |  |  | (7.1) |  |  | (0.9) |  |
| INCOME BEFORE INCOME TAXES | 121.6 |  |  | 85.8 |  |  | 238.7 |  |  | 146.1 |  |
| PROVISION FOR INCOME TAXES | 9.5 |  |  | 13.1 |  |  | 22.6 |  |  | 14.6 |  |
| NET INCOME | $ | 112.1 |  |  | $ | 72.7 |  |  | $ | 216.1 |  |  | $ | 131.5 |  |
| Net income per share: |  |  |  |  |  |  |  |
| Basic | $ | 0.69 |  |  | $ | 0.42 |  |  | $ | 1.30 |  |  | $ | 0.77 |  |
| Diluted | $ | 0.68 |  |  | $ | 0.42 |  |  | $ | 1.27 |  |  | $ | 0.75 |  |
| Weighted-average shares outstanding: |  |  |  |  |  |  |  |
| Basic | 161.6 |  |  | 171.1 |  |  | 166.1 |  |  | 170.6 |  |
| Diluted | 165.4 |  |  | 175.1 |  |  | 169.8 |  |  | 175.0 |  |

[0001262039-20-000051:8k_2_02:77]
FORTINET, INC.

[0001262039-20-000051:8k_2_02:78]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001262039-20-000051:8k_2_02:79]
(Unaudited, in millions)

[0001262039-20-000051:8k_2_02:80]
|  | Six Months Ended |  |  |
|  | June 30,2020 |  | June 30,2019 |
| CASH FLOWS FROM OPERATING ACTIVITIES: |  |  |  |
| Net income | $ | 216.1 |  |  | $ | 131.5 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |
| Stock-based compensation | 93.7 |  |  | 88.0 |  |
| Amortization of deferred contract costs | 64.5 |  |  | 51.0 |  |
| Depreciation and amortization | 35.4 |  |  | 30.9 |  |
| Amortization of investment discounts | (0.4) |  |  | (3.0) |  |
| Other | 5.5 |  |  | 0.5 |  |
| Changes in operating assets and liabilities: |  |  |  |
| Accounts receivable—net | 44.5 |  |  | 41.5 |  |
| Inventory | (17.9) |  |  | (5.5) |  |
| Prepaid expenses and other current assets | (15.2) |  |  | (5.4) |  |
| Deferred contract costs | (91.1) |  |  | (72.4) |  |
| Deferred tax assets | 13.0 |  |  | (4.4) |  |
| Other assets | 0.7 |  |  | 2.4 |  |
| Accounts payable | 9.7 |  |  | (14.6) |  |
| Accrued liabilities | 6.5 |  |  | (13.1) |  |
| Accrued payroll and compensation | 8.9 |  |  | (7.9) |  |
| Other liabilities | 5.6 |  |  | (2.8) |  |
| Deferred revenue | 186.9 |  |  | 179.7 |  |
| Net cash provided by operating activities | 566.4 |  |  | 396.4 |  |
| CASH FLOWS FROM INVESTING ACTIVITIES: |  |  |  |
| Purchases of investments | (399.3) |  |  | (748.1) |  |
| Sales of investments | 130.0 |  |  | 15.1 |  |
| Maturities of investments | 548.1 |  |  | 384.9 |  |
| Purchases of property and equipment | (58.5) |  |  | (27.5) |  |
| Payments made in connection with business combination, net of cash acquired | (3.1) |  |  | — |  |
| Other | (0.4) |  |  | — |  |
| Net cash provided by (used in) investing activities | 216.8 |  |  | (375.6) |  |
| CASH FLOWS FROM FINANCING ACTIVITIES: |  |  |  |
| Repurchase and retirement of common stock | (1,046.0) |  |  | (94.2) |  |
| Proceeds from issuance of common stock | 15.7 |  |  | 39.6 |  |
| Taxes paid related to net share settlement of equity awards | (58.9) |  |  | (56.5) |  |
| Other | (0.1) |  |  | — |  |
| Net cash used in financing activities | (1,089.3) |  |  | (111.1) |  |
| NET DECREASE IN CASH AND CASH EQUIVALENTS | (306.1) |  |  | (90.3) |  |
| CASH AND CASH EQUIVALENTS—Beginning of period | 1,222.5 |  |  | 1,112.4 |  |
| CASH AND CASH EQUIVALENTS—End of period | $ | 916.4 |  |  | $ | 1,022.1 |  |

[0001262039-20-000051:8k_2_02:81]
Reconciliations of non-GAAP results of operations measures to the nearest comparable GAAP measures

[0001262039-20-000051:8k_2_02:82]
(Unaudited, in millions, except per share amounts)

[0001262039-20-000051:8k_2_02:83]
Reconciliation of net cash provided by operating activities to free cash flow

[0001262039-20-000051:8k_2_02:84]
|  | Three Months Ended |  |  |
|  | June 30,2020 |  | June 30,2019 |
| Net cash provided by operating activities | $ | 247.0 |  |  | $ | 195.1 |  |
| Less: Purchases of property and equipment | (30.9) |  |  | (17.3) |  |
| Free cash flow | $ | 216.1 |  |  | $ | 177.8 |  |
| Net cash provided by (used in) investing activities | $ | 212.2 |  |  | $ | (336.6) |  |
| Net cash used in financing activities | $ | (168.9) |  |  | $ | (53.3) |  |

[0001262039-20-000051:8k_2_02:85]
Reconciliation of GAAP operating income to non-GAAP operating income, operating margin, net income and diluted net income per share

[0001262039-20-000051:8k_2_02:86]
|  | Three Months Ended June 30, 2020 |  |  |  |  |  | Three Months Ended June 30, 2019 |  |  |  |  |
|  | GAAP Results |  | Adjustments |  | Non-GAAP Results |  | GAAP Results |  | Adjustments |  | Non-GAAP Results |
| Operating income | $ | 116.7 |  |  | $ | 51.5 |  | (a) | $ | 168.2 |  |  | $ | 75.2 |  |  | $ | 47.9 |  | (b) | $ | 123.1 |  |
| Operating margin | 19.0 | % |  |  |  | 27.3 | % |  | 14.4 | % |  |  |  | 23.6 | % |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | 49.6 |  |  |  |  |  |  | 45.0 |  |  |  |
| Amortization of acquired intangible assets |  |  | 3.7 |  |  |  |  |  |  | 2.9 |  |  |  |
| Gain on intellectual property matter |  |  | (1.1) |  |  |  |  |  |  | — |  |  |  |
| Litigation-related matter |  |  | (0.7) |  |  |  |  |  |  | — |  |  |  |
| Tax adjustment |  |  | (28.5) |  | (c) |  |  |  |  | (19.0) |  | (c) |  |
| Net income | $ | 112.1 |  |  | $ | 23.0 |  |  | $ | 135.1 |  |  | $ | 72.7 |  |  | $ | 28.9 |  |  | $ | 101.6 |  |
| Diluted net income per share | $ | 0.68 |  |  |  |  | $ | 0.82 |  |  | $ | 0.42 |  |  |  |  | $ | 0.58 |  |
| Shares used in diluted net income per share calculations | 165.4 |  |  |  |  | 165.4 |  |  | 175.1 |  |  |  |  | 175.1 |  |

[0001262039-20-000051:8k_2_02:87]
(a) To exclude $49.6 million of stock-based compensation and $3.7 million of amortization of acquired intangible assets, offset by a $1.1 million gain on intellectual property matter and a $0.7 million adjustment for a litigation-related matter in the three months ended June 30, 2020.

[0001262039-20-000051:8k_2_02:88]
(b) To exclude $45.0 million of stock-based compensation and $2.9 million of amortization of acquired intangible assets in the three months ended June 30, 2019.

[0001262039-20-000051:8k_2_02:89]
(c) Non-GAAP financial information is adjusted to an overall effective tax rate of 22% and 24% in 2020 and 2019, respectively, on a non-GAAP basis, which differs from the GAAP effective tax rate.

[0001262039-20-000051:8k_2_02:90]
Reconciliation of total revenue to total billings

[0001262039-20-000051:8k_2_02:91]
|  | Three Months Ended |  |  |
|  | June 30,2020 |  | June 30,2019 |
| Total revenue | $ | 615.5 |  |  | $ | 521.7 |  |
| Add: Change in deferred revenue | 96.0 |  |  | 100.7 |  |
| Total billings | $ | 711.5 |  |  | $ | 622.4 |  |

[0001262039-20-000051:8k_2_02:92]
| Investor Contact: |  | Media Contact: |
| Peter Salkowski |  | Sandra Wheatley |
| Fortinet, Inc. |  | Fortinet, Inc. |
| 408-331-4595 |  | 408-391-9408 |
| psalkowski@fortinet.com |  | swheatley@fortinet.com |
