# FTNT notes — 0001262039-16-000053


## ftnt:CashandCashEquivalentsandAvailableforSaleInvestmentsPolicyTextBlock

[0001262039-16-000053:notes:1]
Cash, Cash Equivalents and Available-for-sale Investments—We consider all highly liquid investments, purchased with original maturities of three months or less, to be cash equivalents. Cash and cash equivalents consist of balances with banks and highly liquid investments in money market funds and commercial paper.

[0001262039-16-000053:notes:2]
We classify our investments as available-for-sale at the time of purchase, since it is our intent that these investments are available for current operations. Investments with original maturities greater than three months that mature less than one year from the consolidated balance sheet date are classified as short-term investments. Investments with maturities greater than one year from the consolidated balance sheet date are classified as long-term investments.

[0001262039-16-000053:notes:3]
Investments are considered to be impaired when a decline in fair value is judged to be other-than-temporary. We consult with our investment managers and consider available quantitative and qualitative evidence in evaluating potential impairment of our investments on a quarterly basis. If the cost of an individual investment exceeds its fair value, we evaluate, among other factors, general market conditions, the duration and extent to which the fair value is less than cost, and our intent and ability to hold the investment. Once a decline in fair value is determined to be other-than-temporary, an impairment charge is recorded and a new cost basis in the investment is established.

[0001262039-16-000053:notes:4]
For debt securities in an unrealized loss position which is deemed to be other-than-temporary, the difference between the security’s then-current amortized cost basis and fair value is separated into (i) the amount of the impairment related to the credit loss (i.e., the credit loss component) and (ii) the amount of the impairment related to all other factors (i.e., the non-credit loss component). The credit loss component is recognized in earnings. The non-credit loss component is recognized in accumulated other comprehensive loss.


## ftnt:ComprehensiveIncomeLossPolicyTextBlock

[0001262039-16-000053:notes:5]
Comprehensive Income—Comprehensive income includes certain changes in equity from non-owner sources that are excluded from net income, specifically, unrealized gains and losses on available-for-sale investments.


## ftnt:ConcentrationRiskPolicyTextBlock

[0001262039-16-000053:notes:6]
Concentration of Credit Risk—Financial instruments that subject us to concentrations of credit risk consist primarily of cash, cash equivalents, short-term and long-term investments and accounts receivable. We maintain our cash, cash equivalents and investments in fixed income securities with major financial institutions in order to limit the exposure of each investment. Deposits held with banks may exceed the amount of insurance provided on such deposits.

[0001262039-16-000053:notes:7]
Our accounts receivables are primarily derived from our channel partners in various geographical locations. We perform ongoing credit evaluations of our customers. We generally do not require collateral on accounts receivable and we maintain reserves for estimated potential credit losses.


## ftnt:IncomeTaxBenefitFromStockOptionPlansTableTextBlock

[0001262039-16-000053:notes:8]
Total income tax benefit associated with stock-based compensation that is recognized in the consolidated statements of operations is as follows (in thousands):

[0001262039-16-000053:notes:9]
|  | Year Ended December 31, |
|  | 2015 |  | 2014 |  | 2013 |
| Income tax benefit associated with stock-based compensation | $ | 25,189 |  |  | $ | 11,086 |  |  | $ | 8,331 |  |


## ftnt:PresentationAndPreparationOfConsolidatedFinancialStatementsPolicyTextBlock

[0001262039-16-000053:notes:10]
Basis of Presentation and Preparation—The consolidated financial statements of Fortinet and its wholly-owned subsidiaries (collectively, the “Company,” “we,” “us” or “our”) have been prepared in accordance with generally accepted accounting principles in the United States (“GAAP”). All intercompany transactions and balances have been eliminated in consolidation.


## ftnt:ScheduleOfAmortizedCostsUnrealizedGainsAndLossesAndFairValueOfAvailableForSaleSecuritiesTableTextBlock

[0001262039-16-000053:notes:11]
The following table summarizes our investments (in thousands):

[0001262039-16-000053:notes:12]
|  | December 31, 2015 |
|  | AmortizedCost |  | UnrealizedGains |  | UnrealizedLosses |  | FairValue |
| Corporate debt securities | $ | 438,533 |  |  | $ | 30 |  |  | $ | (1,369 | ) |  | $ | 437,194 |  |
| Commercial paper | 66,263 |  |  | 3 |  |  | (34 | ) |  | 66,232 |  |
| Municipal bonds | 61,050 |  |  | 12 |  |  | (40 | ) |  | 61,022 |  |
| Certificates of deposit and term deposits (1) | 14,897 |  |  | — |  |  | — |  |  | 14,897 |  |
| U.S. government and agency securities | 41,727 |  |  | 3 |  |  | (42 | ) |  | 41,688 |  |
| Total available-for-sale securities | $ | 622,470 |  |  | $ | 48 |  |  | $ | (1,485 | ) |  | $ | 621,033 |  |
|  | December 31, 2014 |
|  | AmortizedCost |  | UnrealizedGains |  | UnrealizedLosses |  | FairValue |
| Corporate debt securities | $ | 589,526 |  |  | $ | 365 |  |  | $ | (875 | ) |  | $ | 589,016 |  |
| Commercial paper | 51,156 |  |  | 3 |  |  | (4 | ) |  | 51,155 |  |
| Municipal bonds | 39,745 |  |  | 15 |  |  | (39 | ) |  | 39,721 |  |
| Certificates of deposit and term deposits (1) | 22,854 |  |  | — |  |  | — |  |  | 22,854 |  |
| U.S. government and agency securities | 5,749 |  |  | 1 |  |  | (6 | ) |  | 5,744 |  |
| Total available-for-sale securities | $ | 709,030 |  |  | $ | 384 |  |  | $ | (924 | ) |  | $ | 708,490 |  |
| (1) The majority of our certificates of deposit and term deposits are foreign deposits. |


## ftnt:ScheduleOfShareBasedPaymentAwardStockOptionsValuationAssumptionsAndAllocationOfRecognizedPeriodCostsTableTextBlock

[0001262039-16-000053:notes:13]
The following table summarizes the weighted-average assumptions relating to our employee stock options:

[0001262039-16-000053:notes:14]
|  | Year Ended December 31, |
|  | 2015 |  | 2014 |  | 2013 |
| Expected term in years | 4.3 |  |  | 4.8 |  |  | 4.6 |  |
| Volatility | 37% – 41% |  |  | 41% – 45% |  |  | 45% – 48% |  |
| Risk-free interest rate | 1.5% – 1.6% |  |  | 1.6% – 1.7% |  |  | 1.2 | % |
| Dividend rate | — | % |  | — | % |  | — | % |


## ftnt:ScheduleOfSharesReservedForFutureIssuanceTableTextBlock

[0001262039-16-000053:notes:15]
The following table presents the common stock reserved for future issuance (in thousands):

[0001262039-16-000053:notes:16]
|  | December 31, 2015 |
| Outstanding stock options and RSUs | 16,225 |  |
| Reserved for future stock option, RSU and other equity award grants | 35,613 |  |
| Reserved for future ESPP issuances | 5,217 |  |
| Total common stock reserved for future issuances | 57,055 |  |


## ftnt:ScheduleofEmployeeServiceSharebasedCompensationAllocationofRecognizedPeriodCostsbyAwardTypeTableTextBlock

[0001262039-16-000053:notes:17]
The following table summarizes stock-based compensation expense by award type (in thousands):

[0001262039-16-000053:notes:18]
|  | Year Ended December 31, |
|  | 2015 |  | 2014 |  | 2013 |
| Stock options | $ | 11,425 |  |  | $ | 17,555 |  |  | $ | 20,806 |  |
| RSUs | 77,262 |  |  | 37,068 |  |  | 18,968 |  |
| ESPP | 6,401 |  |  | 4,371 |  |  | 4,697 |  |
| Total stock-based compensation expense | $ | 95,088 |  |  | $ | 58,994 |  |  | $ | 44,471 |  |


## ftnt:ScheduleofEstimatedUsefulLivesofPropertyPlantandEquipmentTableTextBlock

[0001262039-16-000053:notes:19]
Depreciation is computed using the straight-line method over the estimated useful lives of the assets as follows:

[0001262039-16-000053:notes:20]
|  | Estimated Useful Lives |
| Building and building improvements | 20 years |
| Evaluation units | 1 year |
| Computer equipment and software | 1 - 5 years |
| Furniture and fixtures | 3 - 5 years |
| Leasehold improvements | Shorter of useful life or lease term |


## ftnt:ScheduleofSharebasedCompensationSharesWithheldforTaxesTableTextBlock

[0001262039-16-000053:notes:21]
The following summarizes the number and value of the shares withheld for employee taxes (in thousands):

[0001262039-16-000053:notes:22]
|  | Year Ended December 31, |
|  | 2015 |  | 2014 |  | 2013 |
| Shares withheld for taxes | 761 |  |  | 461 |  |  | 70 |  |
| Amount withheld for taxes | $ | 28,871 |  |  | $ | 10,598 |  |  | $ | 1,452 |  |


## ftnt:ScheduleofSharebasedPaymentAwardEmployeeStockPurchasePlanAdditionalInformationTableTextBlock

[0001262039-16-000053:notes:23]
Additional information related to the ESPP is provided below (in thousands, except per share amounts):

[0001262039-16-000053:notes:24]
|  | Year Ended December 31, |
|  | 2015 |  | 2014 |  | 2013 |
| Weighted-average fair value per share granted | $ | 9.56 |  |  | $ | 5.91 |  |  | $ | 6.11 |  |
| Shares issued under the ESPP | 764 |  |  | 770 |  |  | 672 |  |
| Weighted-average price per share issued | $ | 24.30 |  |  | $ | 18.17 |  |  | $ | 18.88 |  |


## ftnt:ScheduleofSharebasedPaymentAwardEquityInstrumentsOtherthanOptionsValuationAssumptionsTableTextBlock

[0001262039-16-000053:notes:25]
The following table summarizes the weighted-average assumptions relating to the PSUs granted to executive officers:

[0001262039-16-000053:notes:26]
|  | Year Ended December 31, |
|  | 2015 |  | 2014 |  | 2013 |
| Expected term in years | 3.0 |  |  | 3.0 |  |  | 3.0 |  |
| Volatility | 38 | % |  | 46 | % |  | 50 | % |
| Risk-free interest rate | 1.1 | % |  | 0.9 | % |  | 0.7 | % |
| Dividend rate | — | % |  | — | % |  | — | % |


## us-gaap:BusinessAcquisitionProFormaInformationTextBlock

[0001262039-16-000053:notes:27]
The following pro forma financial information for all periods presented includes purchase accounting adjustments for amortization charges from acquired intangible assets, depreciation of acquired property, plant and equipment, stock-based compensation and related tax effects (in thousands):

[0001262039-16-000053:notes:28]
|  | Years Ended December 31, |
|  | 2015 |  | 2014 |
| Pro forma revenue | $ | 1,046,972 |  |  | $ | 861,255 |  |
| Pro forma income (loss) from operations | $ | (1,983 | ) |  | $ | 34,105 |  |
| Pro forma net income (loss) | $ | (4,634 | ) |  | $ | 5,968 |  |
| Pro forma net income (loss) per share: |  |  |  |
| Basic | $ | (0.03 | ) |  | $ | 0.04 |  |
| Diluted | $ | (0.03 | ) |  | $ | 0.04 |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001262039-16-000053:notes:29]
BUSINESS COMBINATIONS

[0001262039-16-000053:notes:30]
On July 8, 2015, we completed our acquisition of all of the outstanding shares of Meru Networks, Inc. (“Meru”), a provider of Wi-Fi networking products and services. With this acquisition, we expect to expand on our secure wireless vision and enterprise growth focus, broaden our solutions portfolio, and enhance our opportunity to address the global enterprise Wi-Fi market with integrated and intelligent secure wireless solutions.

[0001262039-16-000053:notes:31]
In connection with the acquisition, we paid total cash consideration of $40.9 million and incurred $0.4 million of withholding tax liability. In addition, all of the outstanding RSUs of Meru were converted into RSUs for 53,401 shares of our common stock. The cash payment, along with the estimated fair value of the earned RSUs assumed, resulted in a purchase price of $41.8 million. The total purchase price was as follows (in thousands):

[0001262039-16-000053:notes:32]
| Purchase Price: |  |
| Cash | $ | 40,914 |  |
| Estimated fair value of shares withheld for taxes | 379 |  |
| Estimated fair value of earned equity awards assumed by Fortinet | 471 |  |
| Total purchase price | $ | 41,764 |  |

[0001262039-16-000053:notes:33]
We accounted for this transaction as a business combination. We expensed acquisition-related costs of $1.7 million in general and administrative expenses in the consolidated statement of operations. The total purchase price was allocated to Meru’s identifiable tangible and intangible assets acquired and liabilities assumed based on their estimated fair values as of the acquisition date.

[0001262039-16-000053:notes:34]
Total allocation of the purchase price was as follows (in thousands):

[0001262039-16-000053:notes:35]
| Cash and cash equivalents | $ | 3,268 |  |
| Accounts receivable | 8,191 |  |
| Inventory | 11,610 |  |
| Prepaid expenses and other assets | 2,409 |  |
| Property and equipment | 920 |  |
| Deferred tax assets | 18,585 |  |
| Identifiable intangible assets | 19,600 |  |
| Goodwill | 1,868 |  |
| Total assets acquired | 66,451 |  |
| Deferred revenue | 9,800 |  |
| Accounts payable and accrued liabilities | 14,887 |  |
| Total liabilities assumed | 24,687 |  |
| Total purchase price allocation | $ | 41,764 |  |

[0001262039-16-000053:notes:36]
The goodwill of $1.9 million represents the premium we paid over the fair value of the net tangible liabilities assumed and identified intangible assets acquired, due primarily to Meru’s assembled workforce. The goodwill recorded as part of the Meru acquisition is not deductible for U.S. federal income tax purposes.

[0001262039-16-000053:notes:37]
Intangible assets consist primarily of customer relationships and developed technologies. Customer relationships represent Meru’s installed base and the ability to sell existing, in-process and future versions of our products and services to its existing customers. Developed technologies represent the virtualized wireless local area network solutions offering centralized coordination and control of various access points on the network. This includes patented and unpatented technology, know-how, processes, designs and computer software. The estimated useful life and fair values of the acquired identifiable intangible assets were as follows (in thousands, except for estimated useful life):

[0001262039-16-000053:notes:38]
|  | Estimated Useful Life (in years) |  | Fair Values |
| Customer relationships | 5 |  | $ | 12,200 |  |
| Developed technologies | 4 |  | 7,200 |  |
| Trade name | 0.5 |  | 200 |  |
| Total |  |  | $ | 19,600 |  |

[0001262039-16-000053:notes:39]
Customer relationships and trade name are amortized on a straight-line basis and the amortization expense is recorded in sales and marketing expenses in the consolidated statement of operations. Developed technologies is amortized on a straight-line basis and the amortization expense is recorded in cost of product revenue in the consolidated statement of operations.

[0001262039-16-000053:notes:40]
Upon the acquisition, Meru became our wholly-owned subsidiary. The results of operations of Meru have been included in our consolidated statement of operations for 2015 from the acquisition date. Revenue and net loss of Meru from July 8, 2015 through December 31, 2015 were $28.1 million and $14.0 million, respectively.

[0001262039-16-000053:notes:41]
The unaudited financial information below summarizes the combined results of Fortinet and Meru on a pro forma basis, after giving effect to the acquisition of Meru on July 8, 2015, as though the business combination occurred on January 1, 2014. The pro forma financial information is presented for informational purposes and is not indicative of the results of operations that would have been achieved if the acquisition had taken place at the beginning of each of the periods presented. The following pro forma financial information for all periods presented includes purchase accounting adjustments for amortization charges from acquired intangible assets, depreciation of acquired property, plant and equipment, stock-based compensation and related tax effects (in thousands):

[0001262039-16-000053:notes:42]
2013 Acquisitions

[0001262039-16-000053:notes:43]
In March 2013, we acquired all of the outstanding equity securities of Coyote, a provider of application delivery, load balancing and acceleration solutions, for $6.0 million in cash. In connection with this acquisition, we acquired intangible assets of $8.2 million, which included $2.8 million of goodwill. We also assumed net tangible liabilities of $2.2 million. The acquisition included a contingent obligation that required payment if certain future operational objectives were met. The operational objectives that would require payment were not met.

[0001262039-16-000053:notes:44]
In September 2013, we acquired certain assets of Xtera Communications, Inc., including certain load balancing solutions and certain patents, for a total consideration of $1.8 million.

[0001262039-16-000053:notes:45]
The financial results of these acquisitions were not considered material for purposes of pro-forma financial disclosures. The results of operations of our 2013 acquisitions were in our consolidated statements of operations from their respective acquisition dates.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001262039-16-000053:notes:46]
COMMITMENTS AND CONTINGENCIES

[0001262039-16-000053:notes:47]
The following table summarizes our future principal contractual obligations as of December 31, 2015 (in thousands):

[0001262039-16-000053:notes:48]
|  | Total |  | 2016 |  | 2017 |  | 2018 |  | 2019 |  | 2020 |  | Thereafter |
| Operating lease commitments | $ | 61,013 |  |  | $ | 17,052 |  |  | $ | 11,922 |  |  | $ | 10,018 |  |  | $ | 8,106 |  |  | $ | 5,659 |  |  | $ | 8,256 |  |
| Inventory purchase commitments | 70,018 |  |  | 70,018 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Other contractual commitments and open purchase orders | 37,346 |  |  | 33,375 |  |  | 2,138 |  |  | 847 |  |  | 593 |  |  | 393 |  |  | — |  |
| Total | $ | 168,377 |  |  | $ | 120,445 |  |  | $ | 14,060 |  |  | $ | 10,865 |  |  | $ | 8,699 |  |  | $ | 6,052 |  |  | $ | 8,256 |  |

[0001262039-16-000053:notes:49]
Operating Leases—We lease certain facilities under various non-cancelable operating leases, which expire through 2024. Certain leases require us to pay variable costs such as taxes, maintenance, and insurance. The terms of certain operating leases also provide for renewal options and escalation clauses. Rent expense was $13.8 million, $10.6 million and $9.8 million for 2015, 2014 and 2013, respectively. Rent expense is recognized using the straight-line method over the term of the lease.

[0001262039-16-000053:notes:50]
Inventory Purchase Commitments—Our independent contract manufacturers procure components and build our products based on our forecasts. These forecasts are based on estimates of future demand for our products, which are in turn based on historical trends and an analysis from our sales and marketing organizations, adjusted for overall market conditions. In order to reduce manufacturing lead times and plan for adequate component supply, we may issue purchase orders to some of our independent contract manufacturers which may not be cancelable. As of December 31, 2015, we had $70.0 million of open purchase orders with our independent contract manufacturers that may not be cancelable.

[0001262039-16-000053:notes:51]
Other Contractual Commitments and Open Purchase Orders—In addition to commitments with contract manufacturers, we have open purchase orders and contractual obligations in the ordinary course of business for which we have not received goods or services. As of December 31, 2015, we had $37.3 million in other contractual commitments that may not be cancelable.

[0001262039-16-000053:notes:52]
Litigation—We are involved in disputes, litigation, and other legal actions. For lawsuits where we are the defendant, we are in the process of defending these litigation matters, and while there can be no assurances and the outcome of these matters is currently not determinable, we currently believe that there are no existing claims or proceedings that are likely to have a material adverse effect on our financial position. There are many uncertainties associated with any litigation and these actions or other third-party claims against us may cause us to incur costly litigation fees, including contingent legal fees with related parties, costs and substantial settlement charges, and possibly subject us to damages and other penalties. In addition, the resolution of any intellectual property litigation may require us to make royalty payments, which could adversely affect our gross margins in future periods. If any of those events were to occur, our business, financial condition, results of operations, and cash flows could be adversely affected. The actual liability in any such matters may be materially different from our estimates, if any, which could result in the need to adjust the liability and record additional expenses. We have not recorded any significant accrual for loss contingencies associated with such legal proceedings; determined that a significant unfavorable outcome is probable or reasonably possible; or determined that the amount or range of any possible loss is reasonably estimable.

[0001262039-16-000053:notes:53]
In December 2015, we received $9.0 million from a third-party for a release of claims. In addition, we agreed to a three-year covenant-not-to-sue. Of the $9.0 million consideration received, $2.0 million was used to offset contingent legal fees incurred in connection with the litigation and the remaining $7.0 million was deferred, with the short-term portion recorded as accrued liabilities and the long-term portion recorded as other liabilities in the consolidated balance sheet. The deferral will be recognized ratably through 2018 as an offset to general and administrative expenses in the consolidated statement of operations.

[0001262039-16-000053:notes:54]
In January 2014, we received $20.0 million pursuant to a six-year mutual covenant-not-to-sue and release agreement with Palo Alto Networks, Inc. The $20.0 million was deferred, with the short-term portion recorded as accrued liabilities and the long-term portion recorded as other liabilities in the consolidated balance sheet. The deferral will be recognized ratably through 2020 as an offset to general and administrative expenses in the consolidated statement of operations.

[0001262039-16-000053:notes:55]
Indemnification—Under the indemnification provisions of our standard sales contracts, we agree to defend our customers against third-party claims asserting various allegations such as product defects and infringement of certain intellectual property rights, which may include patents, copyrights, trademarks or trade secrets, and to pay judgments entered on such claims. In some contracts, our exposure under these indemnification provisions is limited by the terms of the contracts to certain defined limits, such as the total amount paid by our customer under the agreement. However, certain agreements include covenants, penalties and indemnification provisions including and beyond indemnification for third-party claims of intellectual property infringement and that could potentially expose us to losses in excess of the amount received under the agreement, and in some instances to potential liability that is not contractually limited. To date, there have been no awards under such indemnification provisions.


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0001262039-16-000053:notes:56]
DEFINED CONTRIBUTION PLANS

[0001262039-16-000053:notes:57]
Our tax-deferred savings plan under our 401(k) Plan, permits participating employees to defer a portion of their pre-tax earnings. In Canada, we have a Group Registered Retirement Savings Plan program (the “RRSP”), which permits participants to make tax deductible contributions. Our board of directors approved 50% matching contributions on employee contributions up to 4% of each employee’s eligible earnings. Our matching contributions to the 401(k) Plans and RRSP for 2015, 2014 and 2013 were $3.5 million, $2.5 million and $2.1 million, respectively.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001262039-16-000053:notes:58]
ACCUMULATED OTHER COMPREHENSIVE LOSS

[0001262039-16-000053:notes:59]
The following table summarizes the changes in accumulated balances of other comprehensive income for 2015 and 2014 (in thousands):

[0001262039-16-000053:notes:60]
|  | December 31, 2015 |
|  | Unrealized Losses on Investments |  | Tax benefit related to items of other comprehensive income or loss |  | Total |
| Beginning balance | $ | (540 | ) |  | $ | 191 |  |  | $ | (349 | ) |
| Other comprehensive loss before reclassifications | (896 | ) |  | 313 |  |  | (583 | ) |
| Amounts reclassified from accumulated other comprehensive loss | (1 | ) |  | — |  |  | (1 | ) |
| Net current-period other comprehensive loss | (897 | ) |  | 313 |  |  | (584 | ) |
| Ending balance | $ | (1,437 | ) |  | $ | 504 |  |  | $ | (933 | ) |

[0001262039-16-000053:notes:61]
|  | December 31, 2014 |
|  | Foreign Currency Translation Gains and Losses |  | Unrealized Gains and Losses on Investments |  | Tax benefit or provision related to items of other comprehensive income or loss |  | Total |
| Beginning balance | $ | 333 |  |  | $ | 1,168 |  |  | $ | (409 | ) |  | $ | 1,092 |  |
| Other comprehensive loss before reclassifications | — |  |  | (1,694 | ) |  | 595 |  |  | (1,099 | ) |
| Amounts reclassified from accumulated other comprehensive loss | (333 | ) |  | (14 | ) |  | 5 |  |  | (342 | ) |
| Net current-period other comprehensive loss | (333 | ) |  | (1,708 | ) |  | 600 |  |  | (1,441 | ) |
| Ending balance | $ | — |  |  | $ | (540 | ) |  | $ | 191 |  |  | $ | (349 | ) |

[0001262039-16-000053:notes:62]
The following table provides details about the reclassification out of accumulated other comprehensive loss for 2015 and 2014 (in thousands):

[0001262039-16-000053:notes:63]
| Year Ended December 31, 2015 |
| Details about Accumulated Other Comprehensive Income Components |  | Amount Reclassified from Accumulated Other Comprehensive Loss |  | Affected Line Item in the Statement Where Net Income is Presented |
| Unrealized losses on investments |  | $ | (1 | ) |  | Other expense—net |
| Tax provision related to items of other comprehensive loss |  | — |  |  | Provision for income taxes |
| Total reclassification for the period |  | $ | (1 | ) |  |  |

[0001262039-16-000053:notes:64]
| Year Ended December 31, 2014 |
| Details about Accumulated Other Comprehensive Income Components |  | Amount Reclassified from Accumulated Other Comprehensive Income |  | Affected Line Item in the Statement Where Net Income is Presented |
| Foreign currency translation losses |  | $ | (333 | ) |  | Other expense—net |
| Unrealized losses on investments |  | (14 | ) |  | Other expense—net |
| Tax provision related to items of other comprehensive loss |  | 5 |  |  | Provision for income taxes |
| Total reclassification for the period |  | $ | (342 | ) |  |  |


## us-gaap:CostMethodInvestmentsDescriptionTextBlock

[0001262039-16-000053:notes:65]
INVESTMENTS IN PRIVATELY-HELD COMPANIES

[0001262039-16-000053:notes:66]
Our investments in the equity securities of three privately-held companies totaled $10.3 million and $6.4 million as of December 31, 2015 and 2014, respectively. Each of these investments are accounted for as cost-basis investments, as we own less than 20% of the voting securities and do not have the ability to exercise significant influence over operating and financial policies of the respective entities. These investments are carried at historical cost and are recorded as Other assets on our consolidated balance sheet and would be measured at fair value if indicators of impairment exist. As of December 31, 2015, no events have occurred that would adversely affect the carrying value of these investments.

[0001262039-16-000053:notes:67]
We determined that we had a variable interest in these privately-held companies. However, we determined that we were not the primary beneficiary as we did not have the power to direct their activities that most significantly affect their economic performance. The variable interest entities were not required to be consolidated in our consolidated financial statements.


## us-gaap:CostsAssociatedWithExitOrDisposalActivitiesOrRestructuringsPolicyTextBlock

[0001262039-16-000053:notes:68]
Restructuring Charges—We recognize a liability for exit and disposal activities when the liability is incurred. Our restructuring charges consist of severance and other one-time benefits, contract terminations and other charges. Liabilities for costs associated with a restructuring activity are measured at fair value and are recognized when the liability is incurred. One-time termination benefits are expensed at the date we notify the employee, unless the employee must provide future service, in which case the benefits are expensed ratably over the future service period. A liability for contract termination costs represents a liability for costs to terminate a contract before the end of its term and is recognized at fair value when we terminate the contract in accordance with the contract terms, which is usually done by giving written notice to the counterparty within the notification period specified by the contract or by otherwise negotiating a termination with the counterparty. A liability for costs that will continue to be incurred under a contract for its remaining term without economic benefit to the entity is recognized at the cease-use date. Costs to terminate a lease before the end of its term are recognized when the property is vacated. Other costs primarily consist of asset write-offs, which are expensed when incurred.

[0001262039-16-000053:notes:69]
We continually evaluate the adequacy of the remaining liabilities under our restructuring initiatives. Although we believe that these estimates accurately reflect the costs of our restructuring plan, actual results may differ and thereby require us to record an additional provision or reverse a portion of such a provision.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001262039-16-000053:notes:70]
STOCKHOLDERS’ EQUITY

[0001262039-16-000053:notes:71]
Stock-Based Compensation Plans

[0001262039-16-000053:notes:72]
Our stock-based compensation plans include the 2000 Stock Plan (the “2000 Plan”), the 2008 Stock Plan (the “2008 Plan”), the 2009 Equity Incentive Plan (the “2009 Plan”), and the 2011 Employee Stock Purchase Plan (the “ESPP”) and equity plans assumed through the Meru acquisition. Under these plans, we have granted (or, in the case of acquired plan, assumed) stock options and RSUs, including PSUs.

[0001262039-16-000053:notes:73]
Stock Plans—Our board of directors adopted the 2000 Plan in 2000 and the 2008 Plan in 2008. The plans include both incentive and non-statutory stock options, which allowed us to grant options to purchase common stock to employees, directors, and other service providers. During 2015, 2014 and 2013, we issued no stock options under these plans. As of December 31, 2015, no shares remain available for grant under these plans.

[0001262039-16-000053:notes:74]
2009 Equity Incentive Plan—In 2009, our board of directors approved the 2009 Plan, which includes awards of stock options, stock appreciation rights, restricted stock, RSUs, PSUs. The maximum aggregate number of shares that may be issued under the 2009 Plan is 9.0 million shares, plus any shares subject to stock options or similar awards granted under the 2008 Plan and the 2000 Plan that expire or otherwise terminate without having been exercised in full and shares issued pursuant to awards granted under the 2008 Plan and the 2000 Plan that are forfeited to or repurchased by us, with the maximum number of shares to be added to the 2009 Plan pursuant to such terminations, forfeitures and repurchases not to exceed 21.0 million shares. The shares may be authorized, but unissued or reacquired common stock. The number of shares available for issuance under the 2009 Plan will be increased on the first day of each year beginning with 2011, in an amount equal to the lesser of (i) 14.0 million shares (as adjusted in connection with the stock split effected in June 2011), (ii) 5% of the outstanding shares on the last day of the immediately preceding year or (iii) such number of shares determined by our board of directors. Under the 2009 Plan, we may grant awards to employees, directors and other service providers. In the case of an incentive stock option granted to an employee who, at the time of the grant, owns stock representing more than 10% of the voting power of all classes of stock, the exercise price shall be no less than 110% of the fair market value per share on the date of grant and expire five years from the date of grant, and options granted to any other employee, the per share exercise price shall be no less than 100% of the fair market value per share on the date of grant. In the case of a non-statutory stock option and options granted to other service providers, the per share exercise price shall be no less than 100% of the fair market value per share on the date of grant. Options granted to individuals owning less than 10% of the total combined voting power of all classes of stock generally have a contractual term of seven years and options generally vest over four years.

[0001262039-16-000053:notes:75]
2011 Employee Stock Purchase Plan—In June 2011, our stockholders approved the ESPP. The ESPP permits eligible employees to purchase common stock through regular, systematic payroll deductions, up to a maximum of 15% of employees’ compensation for each purchase period at purchase prices equal to 85% of the lesser of the fair market value of our common stock at the first trading date of the applicable offering period or the purchase date, subject to purchase limits of 4,000 shares for each purchase period or $25,000 worth of stock for each calendar year.

[0001262039-16-000053:notes:76]
Meru 2010 Equity Incentive Plan—In connection with the Meru acquisition, we assumed and exchanged Meru’s outstanding RSUs with an estimated fair value of $2.0 million. Of the total estimated fair value, $0.5 million relating to earned equity awards was allocated to the purchase price and the remainder relating to future services is being recognized over the remaining service period. No new equity awards can be granted under the assumed plan. As of December 31, 2015, RSUs representing 34,571 shares of common stock were outstanding under the awards assumed through the acquisition of Meru.

[0001262039-16-000053:notes:77]
As of December 31, 2015, there were a total of 40,827,422 shares of common stock available for grant under our stock-based compensation plans.

[0001262039-16-000053:notes:78]
Employee Stock Options

[0001262039-16-000053:notes:79]
In determining the fair value of our employee stock options, we use the Black-Scholes option pricing model, which employs the following assumptions.

[0001262039-16-000053:notes:80]
Valuation method—We estimate the fair value of stock options granted.

[0001262039-16-000053:notes:81]
Expected Term—The expected term represents the period that our stock-based awards are expected to be outstanding. Beginning in the first quarter of 2014, we changed the methodology of calculating the expected term. We believe that we have sufficient historical experience for determining the expected term of the stock option award, and therefore, we calculated our expected term based on historical experience instead of using the simplified method.

[0001262039-16-000053:notes:82]
Expected Volatility—The expected volatility of our common stock is based on our weighted-average implied and historical volatility.

[0001262039-16-000053:notes:83]
Fair Value of Common Stock—The fair value of our common stock is the closing sales price of the common stock (or the closing bid, if no sales were reported) effective on the date of grant.

[0001262039-16-000053:notes:84]
Risk-Free Interest Rate—We base the risk-free interest rate used in the Black-Scholes valuation model on the implied yield available on U.S. Treasury zero-coupon issues with an equivalent remaining term.

[0001262039-16-000053:notes:85]
Expected Dividend—The expected dividend weighted-average assumption is zero.

[0001262039-16-000053:notes:86]
The following table summarizes the stock option activity and related information for the periods presented below (in thousands, except exercise prices and contractual life):

[0001262039-16-000053:notes:87]
|  | Options Outstanding |
|  | Numberof Shares |  | Weighted-AverageExercisePrice |  | Weighted-AverageRemainingContractualLife (Years) |  | AggregateIntrinsicValue |
| Balance—December 31, 2012 | 18,571 |  |  | $ | 12.40 |  |  |  |  |  |
| Granted | 258 |  |  | 20.89 |  |  |  |  |  |
| Forfeited | (820 | ) |  | 22.14 |  |  |  |  |  |
| Exercised | (2,488 | ) |  | 5.18 |  |  |  |  |  |
| Balance—December 31, 2013 | 15,521 |  |  | 13.18 |  |  |  |  |  |
| Granted | 387 |  |  | 23.08 |  |  |  |  |  |
| Forfeited | (443 | ) |  | 24.21 |  |  |  |  |  |
| Exercised | (4,763 | ) |  | 8.91 |  |  |  |  |  |
| Balance—December 31, 2014 | 10,702 |  |  | 14.98 |  |  |  |  |  |  |
| Granted | 819 |  |  | 39.50 |  |  |  |  |  |
| Forfeited | (150 | ) |  | 28.67 |  |  |  |  |  |
| Exercised | (4,403 | ) |  | 11.10 |  |  |  |  |  |
| Balance—December 31, 2015 | 6,968 |  |  | $ | 20.03 |  |  |  |  |  |
| Options vested and expected to vest—December 31, 2015 | 6,891 |  |  | $ | 19.82 |  |  | 2.67 |  | $ | 83,992 |  |
| Options exercisable—December 31, 2015 | 5,818 |  |  | $ | 17.24 |  |  | 2.09 |  | $ | 81,037 |  |

[0001262039-16-000053:notes:88]
The aggregate intrinsic value represents the pre-tax difference between the exercise price of stock options and the quoted market price of our common stock on December 31, 2015, for all in-the-money options. As of December 31, 2015, total compensation expense related to unvested stock options granted to employees but not yet recognized was $10.0 million. This expense is expected to be amortized on a straight-line basis over a weighted-average period of 2.8 years.

[0001262039-16-000053:notes:89]
Additional information related to our stock options is summarized below (in thousands, except per share amounts):

[0001262039-16-000053:notes:90]
|  | Year Ended December 31, |
|  | 2015 |  | 2014 |  | 2013 |
| Weighted-average fair value per share granted | $ | 13.20 |  |  | $ | 8.90 |  |  | $ | 8.42 |  |
| Intrinsic value of options exercised | 113,786 |  |  | 76,731 |  |  | 41,484 |  |
| Fair value of options vested | 10,943 |  |  | 17,098 |  |  | 26,411 |  |

[0001262039-16-000053:notes:91]
The following table summarizes information about outstanding and exercisable stock options as of December 31, 2015, as follows (in thousands, except exercise prices and contractual life):

[0001262039-16-000053:notes:92]
|  |  | Options Outstanding |  | Options Exercisable |
| Range of Exercise Prices |  | NumberOutstanding |  | Weighted-AverageRemainingContractualLife (Years) |  | Weighted-AverageExercisePrice |  | NumberExercisable |  | Weighted-AverageExercisePrice |
| $0.98–$1.20 |  | 302 |  |  | 0.45 |  | $ | 1.07 |  |  | 302 |  |  | $ | 1.07 |  |
| 3.74–4.65 |  | 720 |  |  | 0.10 |  | 3.78 |  |  | 720 |  |  | 3.78 |  |
| 5.50–6.25 |  | 36 |  |  | 0.82 |  | 5.59 |  |  | 36 |  |  | 5.59 |  |
| 8.43–8.99 |  | 851 |  |  | 1.19 |  | 8.51 |  |  | 851 |  |  | 8.51 |  |
| 15.28–19.94 |  | 136 |  |  | 2.65 |  | 16.52 |  |  | 115 |  |  | 15.89 |  |
| 20.13–24.92 |  | 2,647 |  |  | 2.83 |  | 21.23 |  |  | 2,392 |  |  | 21.12 |  |
| 26.49–26.70 |  | 1,494 |  |  | 3.18 |  | 26.69 |  |  | 1,394 |  |  | 26.70 |  |
| 32.79–33.31 |  | 416 |  |  | 6.33 |  | 32.99 |  |  | 8 |  |  | 32.79 |  |
| 38.73–48.83 |  | 366 |  |  | 6.52 |  | 46.80 |  |  | — |  |  | — |  |
|  |  | 6,968 |  |  |  |  |  |  | 5,818 |  |  |  |

[0001262039-16-000053:notes:93]
Restricted Stock Units

[0001262039-16-000053:notes:94]
The following table summarizes the activity and related information for RSUs for the periods presented below (in thousands, except per share amounts):

[0001262039-16-000053:notes:95]
|  | Restricted Stock Units Outstanding |
|  | Number of Shares |  | Weighted-Average Grant Date Fair Value per Share |
| Balance—December 31, 2012 | 830 |  |  | $ | 23.73 |  |
| Granted | 4,104 |  |  | 21.75 |  |
| Forfeited | (507 | ) |  | 21.48 |  |
| Vested | (228 | ) |  | 23.89 |  |
| Balance—December 31, 2013 | 4,199 |  |  | 22.00 |  |
| Granted | 4,047 |  |  | 23.13 |  |
| Forfeited | (472 | ) |  | 21.92 |  |
| Vested | (1,483 | ) |  | 22.23 |  |
| Balance—December 31, 2014 | 6,291 |  |  | 22.93 |  |
| Granted | 6,303 |  |  | 39.04 |  |
| Forfeited | (1,029 | ) |  | 31.78 |  |
| Vested | (2,308 | ) |  | 22.74 |  |
| Balance—December 31, 2015 | 9,257 |  |  | $ | 32.97 |  |
| RSUs expected to vest—December 31, 2015 | 8,645 |  |  | $ | 32.47 |  |

[0001262039-16-000053:notes:96]
As of December 31, 2015, total compensation expense related to unvested RSUs that were granted to employees and non-employees under the 2009 Plan, but not yet recognized, was $258.4 million. This expense is expected to be amortized on a straight-line basis over a weighted-average vesting period of 3.06 years.

[0001262039-16-000053:notes:97]
RSUs settle into shares of common stock upon vesting. Upon the vesting of the RSUs, we net-settle the RSUs and withhold a portion of the shares to satisfy minimum statutory employee withholding taxes. Total payment for the employees’ tax obligations to the taxing authorities is reflected as a financing activity within the consolidated statements of cash flows.

[0001262039-16-000053:notes:98]
Performance Stock Units

[0001262039-16-000053:notes:99]
We have granted PSUs to certain of our executive officers. PSUs granted to executive officers are based on the achievement of the market-based vesting conditions during the performance period. The final settlement of the PSUs will range between 0% and 150% of the target shares underlying the PSUs based on a specified objective formula approved by our Compensation Committee. The PSUs entitle our executive officers to receive a number of shares of our common stock based on the performance of our stock price over a two- or three-year period as compared to the NASDAQ Composite index for the same periods.

[0001262039-16-000053:notes:100]
During 2015, we also granted PSUs to employees who are not executive officers. These PSUs are based on the achievement of personal- and company-based performance vesting conditions during the performance period. The final settlement of these PSUs will range from 50% to 150% of the target shares underlying the PSUs, based on specified objective formulas approved by our Compensation Committee. The PSUs entitle such employees to receive a number of shares of our common stock based on a one-year performance period, and vest equally in the second and third years. The share-based compensation expenses related to these awards are not considered material.

[0001262039-16-000053:notes:101]
The following table summarizes the activity and related information for PSUs granted to executive officers and other employees for the periods presented below (in thousands, except per share amounts):

[0001262039-16-000053:notes:102]
|  | Year Ended December 31, |
|  | 2015 |  | 2014 |  | 2013 |
| Shares granted to executive officers and employees | 206 |  |  | 120 |  |  | 213 |  |
| Weighted-average fair value per share granted | $ | 34.86 |  |  | $ | 21.21 |  |  | $ | 22.06 |  |

[0001262039-16-000053:notes:103]
As of December 31, 2015, total compensation expense related to unvested PSUs that were granted to certain of our executive officers, but not yet recognized, was $5.0 million. This expense is expected to be amortized on a straight-line basis over a weighted-average vesting period of 1.87 years.

[0001262039-16-000053:notes:104]
Employee Stock Purchase Plan

[0001262039-16-000053:notes:105]
In determining the fair value of our ESPP, we use the Black-Scholes option pricing model that employs the following weighted-average assumptions:

[0001262039-16-000053:notes:106]
|  | Year Ended December 31, |
|  | 2015 |  | 2014 |  | 2013 |
| Expected term in years | 0.5 |  |  | 0.5 |  |  | 0.5 |  |
| Volatility | 30 | % |  | 34 | % |  | 44 | % |
| Risk-free interest rate | 0.2 | % |  | 0.1 | % |  | 0.1 | % |
| Dividend rate | — | % |  | — | % |  | — | % |

[0001262039-16-000053:notes:107]
Shares Reserved for Future Issuances

[0001262039-16-000053:notes:108]
Stock-based Compensation Expense

[0001262039-16-000053:notes:109]
Stock-based compensation expense is included in costs and expenses as follows (in thousands):

[0001262039-16-000053:notes:110]
|  | Year Ended December 31, |
|  | 2015 |  | 2014 |  | 2013 |
| Cost of product revenue | $ | 973 |  |  | $ | 483 |  |  | $ | 383 |  |
| Cost of service revenue | 7,121 |  |  | 5,826 |  |  | 4,841 |  |
| Research and development | 24,555 |  |  | 17,264 |  |  | 13,271 |  |
| Sales and marketing | 49,436 |  |  | 26,744 |  |  | 19,526 |  |
| General and administrative | 13,003 |  |  | 8,677 |  |  | 6,450 |  |
| Total stock-based compensation expense | $ | 95,088 |  |  | $ | 58,994 |  |  | $ | 44,471 |  |

[0001262039-16-000053:notes:111]
Share Repurchase Program

[0001262039-16-000053:notes:112]
On December 6, 2013, our board of directors authorized a Share Repurchase Program (“the Program”) to repurchase up to $200.0 million of our outstanding common stock through December 31, 2014. Under the Program, share repurchases may be made by us from time to time in privately negotiated transactions or in open market transactions. The Program does not require us to purchase a minimum number of shares, and may be suspended, modified or discontinued at any time without prior notice.  On October 17, 2014, our board of directors extended the share repurchase authorization under the Program through December 31, 2015. In 2015, we repurchased 1.8 million shares of common stock under the Program in open market transactions for an aggregate purchase price of $60.0 million. The Program expired on December 31, 2015 with an unused balance under the Program of $62.5 million.


## us-gaap:EarningsPerShareTextBlock

[0001262039-16-000053:notes:113]
NET INCOME PER SHARE

[0001262039-16-000053:notes:114]
Basic net income per share is computed by dividing net income by the weighted-average number of shares of common stock outstanding during the period. Diluted net income per share is computed by dividing net income by the weighted-average number of shares of common stock outstanding, plus the dilutive effects of stock options, RSUs including PSUs, and ESPP. Dilutive shares of common stock are determined by applying the treasury stock method.

[0001262039-16-000053:notes:115]
A reconciliation of the numerator and denominator used in the calculation of basic and diluted net income per share is as follows (in thousands, except per share amounts):

[0001262039-16-000053:notes:116]
|  | Year Ended December 31, |
|  | 2015 |  | 2014 |  | 2013 |
| Numerator: |  |  |  |  |  |
| Net income | $ | 7,987 |  |  | $ | 25,343 |  |  | $ | 44,273 |  |
| Denominator: |  |  |  |  |  |
| Basic shares: |  |  |  |  |  |
| Weighted-average common stock outstanding-basic | 170,385 |  |  | 163,831 |  |  | 162,435 |  |
| Diluted shares: |  |  |  |  |  |
| Weighted-average common stock outstanding-basic | 170,385 |  |  | 163,831 |  |  | 162,435 |  |
| Effect of potentially dilutive securities: |  |  |  |  |  |
| Stock options | 3,427 |  |  | 4,583 |  |  | 5,685 |  |
| RSUs (including PSUs) | 2,260 |  |  | 844 |  |  | 35 |  |
| ESPP | 69 |  |  | 31 |  |  | 28 |  |
| Weighted-average shares used to compute diluted net income per share | 176,141 |  |  | 169,289 |  |  | 168,183 |  |
| Net income per share: |  |  |  |  |  |
| Basic | $ | 0.05 |  |  | $ | 0.15 |  |  | $ | 0.27 |  |
| Diluted | $ | 0.05 |  |  | $ | 0.15 |  |  | $ | 0.26 |  |

[0001262039-16-000053:notes:117]
The following weighted-average shares of common stock were excluded from the computation of diluted net income per share for the periods presented, as their effect would have been antidilutive (in thousands):

[0001262039-16-000053:notes:118]
|  | Year Ended December 31, |
|  | 2015 |  | 2014 |  | 2013 |
| Stock options | 382 |  |  | 3,469 |  |  | 7,397 |  |
| RSUs (including PSUs) | 1,393 |  |  | 768 |  |  | 2,774 |  |
| ESPP | 94 |  |  | 99 |  |  | 419 |  |
|  | 1,869 |  |  | 4,336 |  |  | 10,590 |  |


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0001262039-16-000053:notes:119]
FINANCIAL INSTRUMENTS AND FAIR VALUE

[0001262039-16-000053:notes:120]
The following table shows the gross unrealized losses and the related fair values of our investments that have been in a continuous unrealized loss position (in thousands):

[0001262039-16-000053:notes:121]
|  | December 31, 2015 |
|  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
|  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |
| Corporate debt securities | $ | 348,534 |  |  | $ | (1,187 | ) |  | $ | 42,033 |  |  | $ | (182 | ) |  | $ | 390,567 |  |  | $ | (1,369 | ) |
| Commercial paper | 31,977 |  |  | (34 | ) |  | — |  |  | — |  |  | 31,977 |  |  | (34 | ) |
| Municipal bonds | 41,677 |  |  | (36 | ) |  | 1,008 |  |  | (4 | ) |  | 42,685 |  |  | (40 | ) |
| U.S. government and agency securities | 34,703 |  |  | (42 | ) |  | — |  |  | — |  |  | 34,703 |  |  | (42 | ) |
| Total available-for-sale securities | $ | 456,891 |  |  | $ | (1,299 | ) |  | $ | 43,041 |  |  | $ | (186 | ) |  | $ | 499,932 |  |  | $ | (1,485 | ) |

[0001262039-16-000053:notes:122]
|  | December 31, 2014 |
|  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
|  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |
| Corporate debt securities | $ | 317,011 |  |  | $ | (858 | ) |  | $ | 6,011 |  |  | $ | (17 | ) |  | $ | 323,022 |  |  | $ | (875 | ) |
| Commercial paper | 8,185 |  |  | (4 | ) |  | — |  |  | — |  |  | 8,185 |  |  | (4 | ) |
| Municipal bonds | 26,684 |  |  | (39 | ) |  | — |  |  | — |  |  | 26,684 |  |  | (39 | ) |
| U.S. government and agency securities | $ | 4,745 |  |  | $ | (6 | ) |  | — |  |  | $ | — |  |  | 4,745 |  |  | (6 | ) |
| Total available-for-sale securities | $ | 356,625 |  |  | $ | (907 | ) |  | $ | 6,011 |  |  | $ | (17 | ) |  | $ | 362,636 |  |  | $ | (924 | ) |

[0001262039-16-000053:notes:123]
The contractual maturities of our investments are as follows (in thousands):

[0001262039-16-000053:notes:124]
|  | December 31, 2015 |  | December 31, 2014 |
| Due within one year | $ | 348,074 |  |  | $ | 436,766 |  |
| Due within one to three years | 272,959 |  |  | 271,724 |  |
| Total | $ | 621,033 |  |  | $ | 708,490 |  |

[0001262039-16-000053:notes:125]
Available-for-sale securities are reported at fair value, with unrealized gains and losses, net of tax, included as a separate component of stockholders’ equity and in total comprehensive income. Realized gains and losses on available-for-sale securities are insignificant in the periods presented and are included in Other expense—net in our consolidated statements of operations. We use the specific identification method to determine the cost basis of investments sold.

[0001262039-16-000053:notes:126]
The unrealized losses on our available-for-sale securities were caused by fluctuations in market value and interest rates as a result of the economic environment. As the decline in market value are attributable to changes in market conditions and not credit quality, and because we have concluded currently that we neither intend to sell nor is it more likely than not that we will be required to sell these investments prior to a recovery of par value, we do not consider these investments to be other-than temporarily impaired as of December 31, 2015.

[0001262039-16-000053:notes:127]
Fair Value Accounting—We apply the following fair value hierarchy for disclosure of the inputs used to measure fair value. This hierarchy prioritizes the inputs into three broad levels as follows:

[0001262039-16-000053:notes:128]
Level 1—Inputs are unadjusted quoted prices in active markets for identical assets or liabilities.

[0001262039-16-000053:notes:129]
Level 2—Inputs are quoted prices for similar assets and liabilities in active markets or inputs that are observable for the assets or liabilities, either directly or indirectly through market corroboration, for substantially the full term of the financial instruments.

[0001262039-16-000053:notes:130]
Level 3—Unobservable inputs based on our own assumptions used to measure assets and liabilities at fair value. The inputs require significant management judgment or estimation.

[0001262039-16-000053:notes:131]
We measure the fair value of money market funds and certain U.S. government and agency securities using quoted prices in active markets for identical assets. The fair value of all other financial instruments was based on quoted prices for similar assets in active markets, or model driven valuations using significant inputs derived from or corroborated by observable market data.

[0001262039-16-000053:notes:132]
We classify investments within Level 1 if quoted prices are available in active markets for identical securities.

[0001262039-16-000053:notes:133]
We classify items within Level 2 if the investments are valued using model driven valuations using observable inputs such as quoted market prices, benchmark yields, reported trades, broker/dealer quotes or alternative pricing sources with reasonable levels of price transparency. Investments are held by custodians who obtain investment prices from a third-party pricing provider that incorporates standard inputs in various asset price models.

[0001262039-16-000053:notes:134]
Fair Value of Financial Instruments

[0001262039-16-000053:notes:135]
Assets Measured at Fair Value on a Recurring Basis

[0001262039-16-000053:notes:136]
The following table presents the fair value of our financial assets measured at fair value on a recurring basis as of December 31, 2015 and December 31, 2014 (in thousands):

[0001262039-16-000053:notes:137]
|  | December 31, 2015 |  |  |  | December 31, 2014 |  |  |
|  | AggregateFairValue |  | QuotedPrices inActiveMarkets ForIdenticalAssets |  | SignificantOtherObservableRemainingInputs |  | SignificantOtherUnobservableRemainingInputs |  | AggregateFairValue |  | QuotedPrices inActiveMarkets ForIdenticalAssets |  | SignificantOtherObservableRemainingInputs |  | SignificantOtherUnobservableRemainingInputs |
|  |  |  | (Level 1) |  | (Level 2) |  | (Level 3) |  |  |  | (Level 1) |  | (Level 2) |  | (Level 3) |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate debt securities | $ | 437,194 |  |  | $ | — |  |  | $ | 437,194 |  |  | $ | — |  |  | $ | 589,016 |  |  | $ | — |  |  | $ | 589,016 |  |  | $ | — |  |
| Commercial paper | 69,231 |  |  | — |  |  | 69,231 |  |  | — |  |  | 51,155 |  |  | — |  |  | 51,155 |  |  | — |  |
| Municipal bonds | 61,022 |  |  | — |  |  | 61,022 |  |  | — |  |  | 39,721 |  |  | — |  |  | 39,721 |  |  | — |  |
| Certificates of deposit and term deposits | 14,897 |  |  | — |  |  | 14,897 |  |  | — |  |  | 22,854 |  |  | — |  |  | 22,854 |  |  | — |  |
| Money market funds | 50,030 |  |  | 50,030 |  |  | — |  |  | — |  |  | 13,311 |  |  | 13,311 |  |  | — |  |  | — |  |
| U.S. government and agency securities | 41,688 |  |  | 25,693 |  |  | 15,995 |  |  | — |  |  | 5,744 |  |  | 1,998 |  |  | 3,746 |  |  | — |  |
| Total | $ | 674,062 |  |  | $ | 75,723 |  |  | $ | 598,339 |  |  | $ | — |  |  | $ | 721,801 |  |  | $ | 15,309 |  |  | $ | 706,492 |  |  | $ | — |  |
| Reported as: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents | $ | 53,029 |  |  |  |  |  |  |  |  | $ | 13,311 |  |  |  |  |  |  |  |
| Short-term investments | 348,074 |  |  |  |  |  |  |  |  | 436,766 |  |  |  |  |  |  |  |
| Long-term investments | 272,959 |  |  |  |  |  |  |  |  | 271,724 |  |  |  |  |  |  |  |
| Total | $ | 674,062 |  |  |  |  |  |  |  |  | $ | 721,801 |  |  |  |  |  |  |  |

[0001262039-16-000053:notes:138]
There were no transfers between Level 1 and Level 2 of the fair value hierarchy during the year ended December 31, 2015 and December 31, 2014.

[0001262039-16-000053:notes:139]
Assets Measured at Fair Value on a Nonrecurring Basis

[0001262039-16-000053:notes:140]
We measure certain assets, including goodwill, other intangible assets—net, and investments in privately-held companies at fair value on a nonrecurring basis when there are identifiable events or changes in circumstances that may have a significant adverse impact on the fair value of these assets.

[0001262039-16-000053:notes:141]
During the second quarter of 2015, we reassessed the fair value and the remaining useful life of the developed technologies and customer relationship acquired from the Coyote Point Systems (“Coyote”) business acquisition. Based on this reassessment, we determined a decrease in the projected cash flow and that the remaining net book value of the developed technologies and customer relationships were impaired. As a result, we recorded an impairment charge of $1.6 million associated with these assets. The impairment charge is included within cost of product revenue and sales and marketing in the consolidated statements of operations.

[0001262039-16-000053:notes:142]
During 2014, a decrease in the projected cash flow of the other intangible assets acquired from Coyote resulted in an impairment charge of $2.4 million to adjust the total fair value of the other intangible assets acquired from Coyote to $2.0 million. The impairment charge is included within Cost of product revenue in the consolidated statements of operations.


## us-gaap:ForeignCurrencyTransactionsAndTranslationsPolicyTextBlock

[0001262039-16-000053:notes:143]
Foreign Currency Translation and Transaction Gains and Losses—Prior to the third quarter of 2014, the assets and liabilities of our international subsidiaries were translated into U.S. dollars using the applicable exchange rates. The resulting foreign translation adjustments were included in the consolidated balance sheets as a component of accumulated other comprehensive income (loss) and in the consolidated statements of comprehensive income.

[0001262039-16-000053:notes:144]
In the third quarter of 2014, we reevaluated the selected functional currency of our international subsidiaries due to the nature of our business operations and recorded the cumulative impact of the reevaluation of the functional currency in the consolidated statement of operations. Subsequently, the remeasurement of the assets and liabilities of all international subsidiaries was recorded in the consolidated statement of operations prospectively. The impact of this reevaluation was not material in 2014 or any of our previously issued financial statements.

[0001262039-16-000053:notes:145]
As of December 31, 2015 and 2014, the functional currency of our foreign subsidiaries is the U.S. dollar. Monetary assets and liabilities denominated in foreign currencies have been remeasured into U.S. dollars using the exchange rates in effect at the balance sheet dates. Foreign currency denominated income and expenses have been remeasured using the average exchange rates in effect during each period.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001262039-16-000053:notes:146]
GOODWILL AND OTHER INTANGIBLE ASSETS—Net

[0001262039-16-000053:notes:147]
Goodwill

[0001262039-16-000053:notes:148]
There were no impairments to goodwill during 2015. The following table presents the changes in the carrying amount of goodwill (in thousands):

[0001262039-16-000053:notes:149]
|  | Amount |
| Balance—December 31, 2014 | $ | 2,824 |  |
| Addition due to business acquisition | 1,868 |  |
| Balance—December 31, 2015 | $ | 4,692 |  |

[0001262039-16-000053:notes:150]
Other Intangible Assets—net

[0001262039-16-000053:notes:151]
The following tables present other intangible assets—net (in thousands):

[0001262039-16-000053:notes:152]
|  | December 31, 2015 |
|  | Weighted-Average Useful Life (in Years) |  | Gross |  | Accumulated Amortization |  | Net |
| Other intangible assets—net: |  |  |  |  |  |  |  |
| Customer relationships | 5.0 |  | $ | 12,200 |  |  | $ | 1,220 |  |  | $ | 10,980 |  |
| Developed technologies and other | 3.6 |  | 11,384 |  |  | 4,724 |  |  | 6,660 |  |
| Total other intangible assets—net |  |  | $ | 23,584 |  |  | $ | 5,944 |  |  | $ | 17,640 |  |

[0001262039-16-000053:notes:153]
|  | December 31, 2014 |
|  | Weighted-Average Useful Life (in Years) |  | Gross |  | Accumulated Amortization |  | Net |
| Other intangible assets—net: |  |  |  |  |  |  |  |
| Developed technology | 3.6 |  | $ | 5,606 |  |  | $ | 3,128 |  |  | $ | 2,478 |  |
| Customer relationships | 6.0 |  | 500 |  |  | 146 |  |  | 354 |  |
| Total other intangible assets—net |  |  | $ | 6,106 |  |  | $ | 3,274 |  |  | $ | 2,832 |  |

[0001262039-16-000053:notes:154]
During 2015 and 2014, we reassessed the fair value and the remaining useful life of the developed technologies and customer relationships acquired from the Coyote business acquisition. Based on this reassessment, we determined a decrease in the projected cash flow and that the remaining net book value of the developed technologies and customer relationships were impaired. As a result, we recorded an impairment charge of $1.6 million and $2.4 million in 2015 and 2014, respectively. The impairment charge is included within cost of product revenue and sales and marketing in the consolidated statements of operations.

[0001262039-16-000053:notes:155]
Amortization expense was $3.2 million, $1.5 million, and $1.7 million in 2015, 2014 and 2013, respectively. The following table summarizes estimated future amortization expense of Other intangible assets—net (in thousands):

[0001262039-16-000053:notes:156]
|  | Amount |
| Years: |  |
| 2016 | $ | 4,600 |  |
| 2017 | 4,240 |  |
| 2018 | 4,240 |  |
| 2019 | 3,340 |  |
| 2020 | 1,220 |  |
| Total | $ | 17,640 |  |


## us-gaap:ImpairmentOrDisposalOfLongLivedAssetsPolicyTextBlock

[0001262039-16-000053:notes:157]
Impairment of Long-Lived Assets—We evaluate events and changes in circumstances that could indicate carrying amounts of long-lived assets, including intangible assets, may not be recoverable. When such events or changes in circumstances occur, we assess the recoverability of long-lived assets by determining whether the carrying value of such assets will be recovered through undiscounted expected future cash flows. If the total of the future undiscounted cash flows is less than the carrying amount of those assets, we record an impairment charge in the period in which we make the determination. If such assets are considered to be impaired, the impairment to be recognized is measured by the amount by which the carrying amount of the assets exceeds the fair value of the assets.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001262039-16-000053:notes:158]
INCOME TAXES

[0001262039-16-000053:notes:159]
Income before income taxes consisted of the following (in thousands):

[0001262039-16-000053:notes:160]
|  | Year Ended December 31, |
|  | 2015 |  | 2014 |  | 2013 |
| Domestic | $ | (37,437 | ) |  | $ | 35,778 |  |  | $ | 83,076 |  |
| Foreign | 54,442 |  |  | 25,771 |  |  | (7,135 | ) |
| Total income before income taxes | $ | 17,005 |  |  | $ | 61,549 |  |  | $ | 75,941 |  |

[0001262039-16-000053:notes:161]
The provision for income taxes consisted of the following (in thousands):

[0001262039-16-000053:notes:162]
|  | Year Ended December 31, |
|  | 2015 |  | 2014 |  | 2013 |
| Current: |  |  |  |  |  |
| Federal | $ | 9,864 |  |  | $ | 17,717 |  |  | $ | 43,384 |  |
| State | (136 | ) |  | 1,110 |  |  | 2,490 |  |
| Foreign | 13,683 |  |  | 8,921 |  |  | 4,175 |  |
| Total current | $ | 23,411 |  |  | $ | 27,748 |  |  | $ | 50,049 |  |
| Deferred: |  |  |  |  |  |
| Federal | $ | (9,383 | ) |  | $ | 6,742 |  |  | $ | (17,149 | ) |
| State | (2,988 | ) |  | (36 | ) |  | (1,232 | ) |
| Foreign | (2,022 | ) |  | 1,752 |  |  | — |  |
| Total deferred | (14,393 | ) |  | 8,458 |  |  | (18,381 | ) |
| Provision for income taxes | $ | 9,018 |  |  | $ | 36,206 |  |  | $ | 31,668 |  |

[0001262039-16-000053:notes:163]
The provision for income taxes differs from the amount computed by applying the statutory federal income tax rate as follows (in thousands):

[0001262039-16-000053:notes:164]
|  | Year Ended December 31, |
|  | 2015 |  | 2014 |  | 2013 |
| Tax at federal statutory tax rate | $ | 5,951 |  |  | $ | 21,542 |  |  | $ | 26,579 |  |
| Stock-based compensation expense | 6,369 |  |  | 7,367 |  |  | 4,571 |  |
| State taxes—net of federal benefit | (2,454 | ) |  | 975 |  |  | 419 |  |
| Domestic production activities deduction | — |  |  | — |  |  | (3,256 | ) |
| Foreign tax credit | (6,901 | ) |  | (4,433 | ) |  | (2,853 | ) |
| Research and development credit | (3,529 | ) |  | (880 | ) |  | (1,650 | ) |
| Foreign income taxed at different rates | (11,225 | ) |  | (406 | ) |  | 2,927 |  |
| Foreign withholding taxes | 10,962 |  |  | 9,085 |  |  | 6,622 |  |
| Canadian deemed dividend distribution | 9,647 |  |  | — |  |  | — |  |
| Other | 198 |  |  | 2,956 |  |  | (1,691 | ) |
| Total provision for income taxes | $ | 9,018 |  |  | $ | 36,206 |  |  | $ | 31,668 |  |

[0001262039-16-000053:notes:165]
Significant permanent differences arise from the portion of stock-based compensation expense that is not expected to generate a tax deduction, such as stock-based compensation expense on stock option grants to certain foreign employees, offset by the actual tax benefits in the current periods from disqualifying dispositions of shares held by our U.S. employees. For stock options exercised by our U.S. employees, we receive an income tax benefit calculated as the difference between the fair market value of the stock issued at the time of the exercise and the option price, tax effected. For 2015, income tax payable was reduced by excess tax benefits from the exercise or vesting of stock-based awards of $1.3 million. For 2014, income tax payable was not reduced by excess tax benefits from the exercise or vesting of stock-based awards, therefore we did not recognize a significant benefit in additional paid-in-capital. The income tax benefits for 2013 associated with dispositions from employee stock transactions of $3.5 million was recognized as additional paid-in capital because it reduced income taxes payable.

[0001262039-16-000053:notes:166]
As of December 31, 2015, there was additional Federal deferred tax assets related to stock-based compensation excess tax benefits of $29.7 million that we did not recognize. Unrecognized excess tax benefits will be accounted for as a credit to additional paid-in capital when realized through a reduction in income taxes payable.

[0001262039-16-000053:notes:167]
Our 2015 income tax provision reflected a $1.2 million tax benefit due to a recent U.S. Tax Court opinion involving an independent third party filed on July 27, 2015. Based on the findings of the U.S. Tax Court, we recognized the tax benefit for excluding the share-based compensation from intercompany charges in prior periods.

[0001262039-16-000053:notes:168]
During 2015, we completed a corporate reorganization to convert our Canadian company to a branch of our U.S. company resulting on a $27.6 million deemed dividend distribution. The tax impact of the Canadian deemed dividend distribution of $9.6 million was partially offset by an additional tax benefit of $6.4 million due to the deferred tax benefit of the Canadian stock based compensation expense.

[0001262039-16-000053:notes:169]
The tax effects of temporary differences that give rise to significant portions of the deferred tax assets as of the years ended are presented below (in thousands):

[0001262039-16-000053:notes:170]
|  | December 31, 2015 |  | December 31, 2014 |
| Deferred tax assets: |  |  |  |
| Net operating loss carryforward | $ | 9,757 |  |  | $ | 1,293 |  |
| Deferred revenue | 39,509 |  |  | 31,545 |  |
| Nondeductible reserves and accruals | 22,240 |  |  | 20,904 |  |
| Depreciation and amortization | 2,873 |  |  | 193 |  |
| General business credit carryforward | 22,121 |  |  | 2,155 |  |
| Stock-based compensation expense | 22,714 |  |  | 16,463 |  |
| Other | 2 |  |  | 11 |  |
| Total deferred tax assets | $ | 119,216 |  |  | $ | 72,564 |  |

[0001262039-16-000053:notes:171]
In assessing the realizability of deferred tax assets, we considered whether it is more likely than not that some portion or all of our deferred tax assets will be realized. This realization is dependent upon the generation of future taxable income during the periods in which those temporary differences become deductible. We concluded that it is more likely than not that we would be able to realize the benefits of our deferred tax assets in the future.

[0001262039-16-000053:notes:172]
As of December 31, 2015, we had $84.9 million in federal net operating loss carryforwards to offset future income that will not expire until 2035, which is not limited by section 382. With the acquisition of Meru, we also had $22.9 million in federal net operating loss carryforwards which is limited by section 382 available from year 2019 with an annual limitation of $1.1 million. We had $17.4 million federal tax credits with certain amount available to carryback and claim federal tax refunds from prior year and the rest available to offset future federal taxes. As of December 31, 2015, we had $16.2 million in California net operating loss carryforwards to offset future income that will not expire until 2031. With the acquisition of Meru, we also had $22.1 million in California net operating loss carryforwards which is subject to section 382 limitation. We had state tax credit carryforwards of $12.3 million available to offset our future state taxes. The state credits carry forward indefinitely.

[0001262039-16-000053:notes:173]
Our policy with respect to undistributed foreign subsidiaries’ earnings is to consider those earnings to be indefinitely reinvested and, accordingly, no related provision of U.S. federal and state income taxes has been provided on such earnings. Upon distribution of those earnings in the form of dividends or otherwise, we would be subject to both U.S. income taxes (subject to an adjustment for foreign tax credits) and withholding taxes in the various foreign countries. As of December 31, 2015, we have not recorded U.S. income tax on $47.4 million of foreign earnings that are deemed to be permanently reinvested overseas.

[0001262039-16-000053:notes:174]
We operate under a tax incentive agreement in Singapore, which is effective through December 31, 2023, and may be extended if certain additional requirements are satisfied. The tax incentive agreement is conditional upon our meeting certain employment and investment thresholds.

[0001262039-16-000053:notes:175]
As of December 31, 2015, we had $59.7 million of unrecognized tax benefits, of which, if recognized, $58.4 million would favorably affect our effective tax rate. Our policy is to include accrued interest and penalties related to uncertain tax benefits in income tax expense. As of December 31, 2015, 2014 and 2013, accrued interest and penalties were $5.5 million, $1.7 million and $1.0 million, respectively.

[0001262039-16-000053:notes:176]
The aggregate changes in the balance of unrecognized tax benefits are as follows (in thousands):

[0001262039-16-000053:notes:177]
|  | Year Ended December 31, |
|  | 2015 |  | 2014 |  | 2013 |
| Unrecognized tax benefits, beginning of year | $ | 44,151 |  |  | $ | 29,604 |  |  | $ | 27,808 |  |
| Gross increases for tax positions related to the current year | 17,478 |  |  | 14,547 |  |  | 4,713 |  |
| Gross increases for tax positions related to the prior year | 8,319 |  |  | — |  |  | 405 |  |
| Gross decreases for tax positions related to prior year | (9,207 | ) |  | — |  |  | (3,322 | ) |
| Gross decreases for tax positions related to expiration of statute of limitations | (1,069 | ) |  | — |  |  | — |  |
| Unrecognized tax benefits, end of year | $ | 59,672 |  |  | $ | 44,151 |  |  | $ | 29,604 |  |

[0001262039-16-000053:notes:178]
As of December 31, 2015, 2014 and 2013, $60.6 million, $45.1 million and $30.2 million, respectively, of the amounts reflected above were recorded as Income tax liabilities—non-current in our consolidated balance sheet.

[0001262039-16-000053:notes:179]
As of December 31, 2015, there was no unrecognized tax benefits that we expect would change significantly over the next 12 months.

[0001262039-16-000053:notes:180]
We file income tax returns in the U.S. federal jurisdiction, and various U.S. state and foreign jurisdictions. The statute of limitations is open for years that generated state net operating loss carryforwards and after 2009 for state jurisdictions. Additionally, we have foreign net operating losses that have an indefinite life. Generally, we are no longer subject to non-U.S. income tax examinations by tax authorities for tax years prior to 2009.  We are no longer subject to examination by U.S federal income tax authorities for tax years prior to 2012. We are currently under examination by U.S federal income tax authorities for tax year 2014, 2013 and 2012.


## us-gaap:IncomeTaxPolicyTextBlock

[0001262039-16-000053:notes:181]
Income Taxes—We record income taxes using the asset and liability method, which requires the recognition of deferred tax assets and liabilities for the expected future tax consequences of events that have been recognized in our financial statements or tax returns. In addition, deferred tax assets are recorded for the future benefit of utilizing net operating losses and research and development credit carryforwards. Deferred tax assets and liabilities are measured using the currently enacted tax rates that apply to taxable income in effect for the years in which those tax assets and liabilities are expected to be realized or settled. Valuation allowances are provided when necessary to reduce deferred tax assets to the amount expected to be realized.

[0001262039-16-000053:notes:182]
We recognize tax benefits from an uncertain tax position only if it is more likely than not, based on the technical merits of the position, that the tax position will be sustained on examination by the taxing authorities. The tax benefits recognized in the financial statements from such positions are then measured based on the largest benefit that has a greater than 50% likelihood of being realized upon ultimate settlement.


## us-gaap:InventoryDisclosureTextBlock

[0001262039-16-000053:notes:183]
INVENTORY

[0001262039-16-000053:notes:184]
Inventory consisted of the following (in thousands):

[0001262039-16-000053:notes:185]
|  | December 31, 2015 |  | December 31, 2014 |
| Raw materials | $ | 15,425 |  |  | $ | 10,617 |  |
| Finished goods | 68,443 |  |  | 58,860 |  |
| Inventory | $ | 83,868 |  |  | $ | 69,477 |  |

[0001262039-16-000053:notes:186]
Inventory includes finished goods held by distributors where revenue is recognized on a sell-through basis of $1.1 million and $1.2 million as of December 31, 2015 and 2014, respectively. Inventory also includes materials at contract manufacturers of $4.9 million and $4.8 million as of December 31, 2015 and 2014, respectively.


## us-gaap:InventoryPolicyTextBlock

[0001262039-16-000053:notes:187]
Inventory—Inventory is recorded at the lower of cost (using the first-in, first-out method) or market, after we give appropriate consideration to obsolescence and inventory in excess of anticipated future demand. In assessing the ultimate recoverability of inventory, we make estimates regarding future customer demand, the timing of new product introductions, economic trends and market conditions. If the actual product demand is significantly lower than forecasted, we could be required to record additional inventory write-downs which would be charged to cost product revenue. Any write-downs could have an adverse impact on our gross margins and profitability.


## us-gaap:LeasePolicyTextBlock

[0001262039-16-000053:notes:188]
Leases—We rent our facilities under operating lease agreements and recognize related rent expense on a straight-line basis over the term of the lease. Some of our lease agreements contain rent holidays, scheduled rent increases, lease incentives and renewal options. Rent holidays and scheduled rent increases are included in the determination of rent expense to be recorded over the lease term. Lease incentives are recognized as a reduction of rent expense on a straight-line basis over the term of the lease. Renewals are not assumed in the determination of the lease term unless they are deemed to be reasonably assured at the inception of the lease. We begin recognizing rent expense on the date that we obtain the legal right to use and control the leased space.


## us-gaap:LongLivedAssetsByGeographicAreasTableTextBlock

[0001262039-16-000053:notes:189]
| Property and Equipment—net | December 31, 2015 |  | December 31, 2014 |
| Americas: |  |  |  |
| United States | $ | 61,064 |  |  | $ | 46,116 |  |
| Canada | 8,224 |  |  | 6,054 |  |
| Other Americas | 748 |  |  | 875 |  |
| Total Americas | 70,036 |  |  | 53,045 |  |
| EMEA: |  |  |  |
| France | 13,201 |  |  | 2,052 |  |
| Other EMEA | 3,977 |  |  | 1,204 |  |
| Total EMEA | 17,178 |  |  | 3,256 |  |
| APAC | 3,853 |  |  | 2,618 |  |
| Total property and equipment—net | $ | 91,067 |  |  | $ | 58,919 |  |


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001262039-16-000053:notes:190]
Recent Accounting Pronouncements

[0001262039-16-000053:notes:191]
In February 2016, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”)2016-02—Leases. The FASB amended lease accounting requirements to begin recording assets and liabilities arising from leases on the balance sheet. The new guidance will also require significant additional disclosures about the amount, timing and uncertainty of cash flows from leases. This new guidance will be effective for us beginning on January 1, 2019 using a modified retrospective approach. The modified retrospective approach includes a number of optional practical expedients that entities may elect to apply. We are currently evaluating the impact ASU 2016-02 will have on our consolidated financial statements.

[0001262039-16-000053:notes:192]
In January 2016, the FASB issued ASU 2016-01—Financial Instruments-Overall: Recognition and Measurement of Financial Assets and Financial Liabilities. ASU 2016-01 modifies how entities measure equity investments and present changes in the fair value of financial liabilities. Under the new guidance, entities will have to measure equity investments that do not result in consolidation and are not accounted under the equity method at fair value and recognize any changes in fair value in net income unless the investments qualify for the new practicality exception. A practicality exception will apply to those equity investments that do not have a readily determinable fair value and do not qualify for the practical expedient to estimate fair value, and as such these investments may be measured at cost. ASU 2016-01 will be effective for us beginning on January 1, 2018. We do not expect the impact of ASU 2016-01 on our consolidated financial statements to be significant.

[0001262039-16-000053:notes:193]
In November 2015, the FASB issued ASU 2015-17—Balance Sheet Classification of Deferred Taxes, which simplifies the presentation of deferred income taxes. ASU 2015-17 requires that deferred tax assets and liabilities be classified as noncurrent assets or noncurrent liabilities. We early adopted this standard effective December 31, 2015 on a retrospective basis. The adoption of this standard resulted in the reclassification of $41.8 million from Deferred tax assets—current in the consolidated balance sheet as of December 31, 2014 to Deferred tax assets—noncurrent.

[0001262039-16-000053:notes:194]
In September 2015, the FASB issued ASU 2015-16—Simplifying the Accounting for Measurement-Period Adjustments, which eliminates the requirement for an acquirer in a business combination to account for measurement-period adjustments retrospectively. Instead, acquirers must recognize measurement-period adjustments during the period in which they determine the amounts, including the effect on earnings of any amounts they would have recorded in previous periods if the accounting had been completed at the acquisition date. ASU 2015-16 will be effective for us beginning on January 1, 2016. We do not expect the impact of ASU 2015-16 on our consolidated financial statements to be significant.

[0001262039-16-000053:notes:195]
In July 2015, the FASB issued ASU 2015-11—Inventory—Simplifying the Measurement of Inventory (Topic 330). ASU 2015-11 changes the measurement principle for inventory from the lower of cost or market to lower of cost and net realizable value. It applies to entities that measure inventory using a method other than last-in, first-out or the retail inventory method (e.g., first-in first-out, average cost). ASU 2015-11 will be effective for us beginning on January 1, 2017. We do not expect the impact of ASU 2015-11 on our consolidated financial statements to be significant.

[0001262039-16-000053:notes:196]
In May 2014, the FASB issued ASU 2014-09—Revenue from Contracts with Customers (Topic 606) to create a single, joint revenue standard that is consistent across all industries and markets for companies that prepare their financial statements in accordance with GAAP. Under ASU 2014-09, an entity is required to recognize revenue upon the transfer of promised goods or services to customers in an amount that reflects the consideration the entity expects to be entitled to receive in exchange for those goods or services. In July 2015, the FASB decided to delay the effective date of the new revenue standard by one year. As such, ASU 2014-09 is effective for us beginning on January 1, 2018, with the option to adopt earlier on January 1, 2017. We are currently evaluating the impact ASU 2014-09 will have on our consolidated financial statements.

[0001262039-16-000053:notes:197]
In April 2015, the FASB issued ASU 2015-05—Intangibles—Goodwill and Other-Internal-Use Software: Customer’s Accounting for Fees Paid in a Cloud Computing Arrangement, which provides guidance on determining whether a cloud computing arrangement contains a software license. If a cloud computing arrangement includes a software license, then the customer should account for the software license element of the arrangement consistent with the acquisition of other software licenses. If a cloud computing arrangement does not include a software license, the customer should account for the arrangement as a service contract. ASU 2015-05 will be effective for us beginning on January 1, 2016. We are currently evaluating the impact of ASU 2015-05 will have on our consolidated financial statements.


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001262039-16-000053:notes:198]
PROPERTY AND EQUIPMENT—Net

[0001262039-16-000053:notes:199]
Property and equipment—net consisted of the following (in thousands):

[0001262039-16-000053:notes:200]
|  | December 31, 2015 |  | December 31, 2014 |
| Land | $ | 21,683 |  |  | $ | 13,895 |  |
| Building and building improvements | 28,841 |  |  | 20,166 |  |
| Evaluation units | 15,784 |  |  | 11,773 |  |
| Computer equipment and software | 45,632 |  |  | 31,821 |  |
| Furniture and fixtures | 8,901 |  |  | 5,096 |  |
| Construction-in-progress | 8,106 |  |  | 3,902 |  |
| Leasehold improvements | 11,179 |  |  | 7,998 |  |
| Total property and equipment | 140,126 |  |  | 94,651 |  |
| Less: accumulated depreciation | (49,059 | ) |  | (35,732 | ) |
| Property and equipment—net | $ | 91,067 |  |  | $ | 58,919 |  |

[0001262039-16-000053:notes:201]
Depreciation expense was $28.4 million, $20.5 million and $13.9 million in 2015, 2014 and 2013, respectively.

[0001262039-16-000053:notes:202]
In 2015, we purchased certain real properties, including land and buildings in Sunnyvale, California and Sophia, France, for cash of $13.9 million to support the growth in our business operations. Of the total cost, we allocated $7.8 million to land and $6.1 million to building. During 2015, construction-in-progress increased primarily due to $2.6 million related to our enterprise resource planning software capitalization and $1.0 million related to assets not yet placed in service due to ongoing building improvements at the newly purchased Sophia property. Fully depreciated evaluation units amounting to $27.2 million and $19.7 million as of December 31, 2015 and 2014, respectively, were written-off.


## us-gaap:PropertyPlantAndEquipmentPolicyTextBlock

[0001262039-16-000053:notes:203]
Property and Equipment—Property and equipment are stated at cost less accumulated depreciation. Depreciation is computed using the straight-line method over the estimated useful lives of the assets as follows:


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001262039-16-000053:notes:204]
RELATED PARTY TRANSACTIONS

[0001262039-16-000053:notes:205]
The son of one member of our board of directors is a partner of an outside law firm that we utilize for certain complex litigation matters. Expenses for legal services provided by the law firm related to matters that arose subsequent to the member joining our board of directors were $7.2 million, $1.7 million and $0.1 million in 2015, 2014 and 2013, respectively. Of such amounts, $2.5 million was incurred under contingent fee arrangements in 2015. There was no contingent fee arrangement in 2014 and 2013. Amounts due and payable to the law firm were $5.3 million and $1.3 million as of December 31, 2015 and December 31, 2014, respectively.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001262039-16-000053:notes:206]
RESTRUCTURING CHARGES

[0001262039-16-000053:notes:207]
In connection with the acquisition of Meru, we initiated planned cost reduction and restructuring activities to improve our cost structure and operational efficiencies. We estimate that we will incur $8.0 million of restructuring charges, consisting of severance and other one-time benefits, contract terminations and other charges. We incurred $7.6 million of restructuring charges during 2015, which are included in operating expense in the consolidated statements of operations. These charges are primarily related to severance and other one-time benefits to be paid in cash. We expect the remainder of the amount to be incurred in 2016.

[0001262039-16-000053:notes:208]
The following table provides a summary of restructuring activity as of December 31, 2015 (in thousands):

[0001262039-16-000053:notes:209]
|  | Employee Severance and Other Benefits |  | Contract Terminations and Other Charges |  | Total |
| Balance as of December 31, 2014 | $ | — |  |  | $ | — |  |  | $ | — |  |
| Costs incurred | 7,109 |  |  | 491 |  |  | 7,600 |  |
| Less cash payments | (3,104 | ) |  | (71 | ) |  | (3,175 | ) |
| Less non-cash charges | (316 | ) |  | (191 | ) |  | (507 | ) |
| Balance as of December 31, 2015 | $ | 3,689 |  |  | $ | 229 |  |  | $ | 3,918 |  |

[0001262039-16-000053:notes:210]
Cash payments for the restructuring activities are expected to be made through 2017, primarily relating to severance and other one-time benefits. The short-term portion of the restructuring reserve of $3.4 million is included in accrued liabilities and the remaining long-term portion of $0.5 million is included in other liabilities on the consolidated balance sheet as of December 31, 2015.


## us-gaap:RevenueFromExternalCustomersByGeographicAreasTableTextBlock

[0001262039-16-000053:notes:211]
|  | Year Ended December 31, |
| Revenue | 2015 |  | 2014 |  | 2013 |
| Americas: |  |  |  |  |  |
| United States | $ | 279,564 |  |  | $ | 200,294 |  |  | $ | 162,327 |  |
| Canada | 101,594 |  |  | 81,968 |  |  | 58,708 |  |
| Other Americas | 54,124 |  |  | 42,397 |  |  | 31,751 |  |
| Total Americas | 435,282 |  |  | 324,659 |  |  | 252,786 |  |
| Europe, Middle East, and Africa (“EMEA”) | 366,018 |  |  | 270,537 |  |  | 208,979 |  |
| Asia Pacific (“APAC”) | 207,968 |  |  | 175,168 |  |  | 153,532 |  |
| Total revenue | $ | 1,009,268 |  |  | $ | 770,364 |  |  | $ | 615,297 |  |


## us-gaap:RevenueRecognitionPolicyTextBlock

[0001262039-16-000053:notes:212]
Deferred Revenue—Deferred revenue consists of amounts that have been invoiced but that have not yet been recognized as revenue. The majority of deferred revenue is comprised of security subscription and technical support services which are invoiced upfront and delivered over twelve months or longer.

[0001262039-16-000053:notes:213]
Revenue Recognition—We derive the majority of our revenue from sales of our hardware, software, FortiGuard security subscription and FortiCare technical support services, and other services through our channel partners and a direct sales force.

[0001262039-16-000053:notes:214]
Revenue is recognized when all of the following criteria have been met:

[0001262039-16-000053:notes:215]
| • | Persuasive evidence of an arrangement exists. Binding contracts or purchase orders are generally used to determine the existence of an arrangement. |

[0001262039-16-000053:notes:216]
| • | Delivery has occurred or services have been rendered. Delivery occurs when we fulfill an order and title and risk of loss has been transferred. Service revenue is deferred and recognized ratably over the contractual service period, which is typically from one to three years and is generally recognized upon delivery or completion of service. |

[0001262039-16-000053:notes:217]
| • | Sales price is fixed or determinable. We assess whether the sales price is fixed or determinable based on the payment terms associated with the transaction and when the sales price is deemed final. |

[0001262039-16-000053:notes:218]
| • | Collectability is reasonably assured. We assess collectability based primarily on creditworthiness as determined by credit checks, analysis, and payment history. |

[0001262039-16-000053:notes:219]
We recognize product revenue for sales to distributors that have no general right of return and direct sales to end-customers upon shipment, based on general revenue recognition accounting guidance once all other revenue recognition criteria have been met. Certain distributors are granted stock rotation rights, limited rights of return and rebates for sales of our products. The arrangement fee for this group of distributors is not typically fixed or determinable when products are shipped and revenue is therefore deferred and recognized upon sell-through. For sales that include end-customer acceptance criteria, revenue is recognized upon acceptance.

[0001262039-16-000053:notes:220]
Substantially all of our products have been sold in combination with services, which consist of security subscriptions and technical support services. Security services provide access to our antivirus, intrusion prevention, web filtering and anti-spam functionality. Support services include rights to unspecified software upgrades, maintenance releases and patches, telephone and Internet access to technical support personnel, and hardware support.  We recognize revenue from these services ratably over the contractual service period.  Revenue related to subsequent renewals of these services are recognized over the term of the renewal agreement.

[0001262039-16-000053:notes:221]
We reduce revenue for estimates of sales returns and allowances and record reductions to revenue for rebates and estimated commitments related to price protection and other customer incentive programs. Additionally, in limited circumstances, we may permit end-customers, distributors and resellers to return our products, subject to varying limitations, for a refund within a reasonably short period from the date of purchase. We estimate and record reserves for sales incentives and sales returns based on historical experience.

[0001262039-16-000053:notes:222]
Our sales arrangements typically contain multiple elements, such as hardware, security subscription, technical support services and other services. The majority of our hardware appliance products contain our operating system software that together function to deliver the essential functionality of the product. Our products and services generally qualify as separate units of accounting. We allocate revenue to each unit of accounting based on an estimated selling price using vendor-specific objective evidence (“VSOE”) of selling price, if it exists, or third-party evidence (“TPE”) of selling price. If neither VSOE nor TPE of selling price exist for a deliverable, we use our best estimate of selling price (“BESP”) for that deliverable. Revenue allocated to each element is then recognized when the basic revenue recognition criteria are met for each element.

[0001262039-16-000053:notes:223]
For our hardware appliances, we use BESP as our selling price. For our support and other services, we generally use VSOE as our selling price estimate. We determine VSOE of fair value for elements of an arrangement based on the historical pricing and discounting practices for those services when sold separately. In establishing VSOE, we require that a substantial majority of the selling prices for a service fall within a reasonably narrow pricing range, generally evidenced by a substantial majority of such historical stand-alone transactions falling within a reasonably narrow range as a percentage of list price. When we are unable to establish a selling price using VSOE for our support and other services, we use BESP in our allocation of arrangement consideration. We determine BESP for a product or service by considering multiple historical factors including, but not limited to, cost of products, gross margin objectives, pricing practices, geographies, customer classes and distribution channels that fall within a reasonably narrow range as a percentage of list price.

[0001262039-16-000053:notes:224]
For multiple-element arrangements where software deliverables are included, revenue is allocated to the non-software deliverables and to the software deliverables as a group using the relative estimated selling prices of each of the deliverables in the arrangement based on the estimated selling price hierarchy. The amount allocated to the software deliverables is then allocated to each software deliverable using the residual method when VSOE of fair value exists. If evidence of VSOE of fair value of one or more undelivered elements does not exist, all software allocated revenue is deferred and recognized when delivery of those elements occurs or when fair value can be established. When the undelivered element for which we do not have VSOE of fair value is support, revenue for the entire arrangement is recognized ratably over the support period. The same residual method and VSOE of fair value principles apply for our multiple element arrangements that contain only software elements.

[0001262039-16-000053:notes:225]
Shipping and Handling—Shipping and handling fees charged to our customers are recognized as product revenue in the period shipped and the related costs for providing these services are recorded as a cost of sale.


## us-gaap:ScheduleOfNotionalAmountsOfOutstandingDerivativePositionsTableTextBlock

[0001262039-16-000053:notes:226]
The notional amount of forward exchange contracts to hedge balance sheet accounts as of December 31, 2015 and 2014 were (in thousands):

[0001262039-16-000053:notes:227]
|  | Buy/Sell |  | Notional |
| Balance Sheet Contracts: |  |  |  |
| Currency—As of December 31, 2015 |  |  |  |
| CAD | Sell |  | $ | 7,011 |  |
| Currency—As of December 31, 2014 |  |  |  |
| CAD | Sell |  | $ | 6,879 |  |


## us-gaap:ScheduleOfProductWarrantyLiabilityTableTextBlock

[0001262039-16-000053:notes:228]
Accrued warranty activities are summarized as follows (in thousands):

[0001262039-16-000053:notes:229]
|  | Year Ended December 31, |
|  | 2015 |  | 2014 |  | 2013 |
| Accrued warranty balance—beginning of the period | $ | 4,269 |  |  | $ | 3,037 |  |  | $ | 2,309 |  |
| Warranty costs incurred | (4,534 | ) |  | (3,653 | ) |  | (3,444 | ) |
| Provision for warranty for the year, including warranty liabilities assumed in connection with a business acquisition | 4,890 |  |  | 5,209 |  |  | 3,965 |  |
| Adjustment related to pre-existing warranties | (1,481 | ) |  | (324 | ) |  | 207 |  |
| Accrued warranty balance—end of the period | $ | 3,144 |  |  | $ | 4,269 |  |  | $ | 3,037 |  |


## us-gaap:ScheduleOfValuationAndQualifyingAccountsDisclosureTextBlock

[0001262039-16-000053:notes:230]
SCHEDULE II—VALUATION AND QUALIFYING ACCOUNTS

[0001262039-16-000053:notes:231]
|  | Year Ended December 31, |
|  | 2015 |  | 2014 |  | 2013 |
|  | (in thousands) |
| Sales Returns Reserve: |  |  |  |  |  |
| Beginning balance | $ | 5,842 |  |  | $ | 4,573 |  |  | $ | 2,267 |  |
| Charged (credited) to costs and expenses, net of deductions | (360 | ) |  | 1,269 |  |  | 2,306 |  |
| Ending balance | $ | 5,482 |  |  | $ | 5,842 |  |  | $ | 4,573 |  |
| Allowance for Doubtful Accounts: |  |  |  |  |  |
| Beginning balance | $ | 362 |  |  | $ | 32 |  |  | $ | 115 |  |
| Charged (credited) to costs and expenses, net of write-offs | 384 |  |  | 330 |  |  | (83 | ) |
| Ending balance | $ | 746 |  |  | $ | 362 |  |  | $ | 32 |  |

[0001262039-16-000053:notes:232]
Schedules not listed above have been omitted because they are not applicable or are not required or the information required to be set forth therein is included in the consolidated financial statements or notes thereto.

[0001262039-16-000053:notes:233]
| 3. | Exhibits: See Item 15(b) below. We have filed, or incorporated into this Annual Report on Form 10-K by reference, the exhibits listed on the accompanying Exhibit Index immediately following the signature page of this Annual Report on Form 10-K. |

[0001262039-16-000053:notes:234]
(b) Exhibits:

[0001262039-16-000053:notes:235]
The exhibit list in the Exhibit Index immediately following the signature page of this Annual Report on Form 10-K is incorporated herein by reference as the list of exhibits required by this Item 15(b).

[0001262039-16-000053:notes:236]
(c) Financial Statement Schedules: See Item 15(a) above.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001262039-16-000053:notes:237]
SEGMENT INFORMATION

[0001262039-16-000053:notes:238]
Operating segments are defined as components of an enterprise about which separate financial information is available that is evaluated regularly by the chief operating decision maker in deciding how to allocate resources and in assessing performance. Our chief operating decision maker is our chief executive officer. Our chief executive officer reviews financial information presented on a consolidated basis, accompanied by information about revenue by geographic region for purposes of allocating resources and evaluating financial performance. We have one business activity, and there are no segment managers who are held accountable for operations, operating results and plans for levels or components below the consolidated unit level. Accordingly, we have determined that we have one operating segment, and therefore, one reportable segment.

[0001262039-16-000053:notes:239]
Revenue by geographic region is based on the billing address of the customer. The following tables set forth revenue and property and equipment by geographic region (in thousands):


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001262039-16-000053:notes:240]
SUMMARY OF SIGNIFICANT ACCOUNTING POLICIES

[0001262039-16-000053:notes:241]
Business—Fortinet, Inc. (“Fortinet”) was incorporated in Delaware in November 2000 and is a leading provider of network security appliances to enterprises, service providers and government organizations worldwide. Fortinet’s solutions are designed to integrate multiple levels of security protection, including firewall, virtual private networking, application control, anti-malware, intrusion prevention, web filtering, vulnerability management, anti-spam, wireless controller and WAN acceleration. Our security solutions are fast, secure and designed to provide broad, rapid protection against dynamic security threats while simplifying the IT infrastructure of our end-customers worldwide.

[0001262039-16-000053:notes:242]
Use of Estimates—The preparation of consolidated financial statements in accordance with GAAP requires management to make estimates and assumptions that affect the amounts reported in the consolidated financial statements and accompanying notes. Such management estimates include, but are not limited to, the best estimate of selling price for our products and services, stock-based compensation, inventory valuation and warranty reserve, fair value of assets acquired and liabilities assumed in business combinations, measurement of liabilities for uncertain tax positions and deferred tax assets, assessment of recoverability of our goodwill and other long-lived assets, sales returns reserve and allowance for doubtful accounts, restructuring charges, and other loss contingencies. We base our estimates on historical experience and also on assumptions that we believe are reasonable. Actual results could differ from those estimates.

[0001262039-16-000053:notes:243]
Our accounts receivables are primarily derived from our channel partners in various geographical locations. We perform ongoing credit evaluations of our customers. We generally do not require collateral on accounts receivable and we maintain reserves for estimated potential credit losses. As of December 31, 2015 and December 31, 2014, one distributor, Exclusive Networks Group, accounted for 23% and 18% of total net accounts receivable, respectively.

[0001262039-16-000053:notes:244]
During 2015, 2014 and 2013, this same distributor accounted for 18%, 15% and 12% of total revenue, respectively.

[0001262039-16-000053:notes:245]
Financial Instruments and Fair Value—We apply fair value accounting for all financial assets and liabilities and non-financial assets and liabilities that are recognized or disclosed at fair value in the financial statements on a recurring basis. Due to their short-term nature, the carrying amounts reported in the consolidated financial statements approximate the fair value for accounts receivable, accounts payable, accrued liabilities, and accrued payroll and compensation.

[0001262039-16-000053:notes:246]
As of December 31, 2015 and 2014, the functional currency of our foreign subsidiaries is the U.S. dollar. Monetary assets and liabilities denominated in foreign currencies have been remeasured into U.S. dollars using the exchange rates in effect at the balance sheet dates. Foreign currency denominated income and expenses have been remeasured using the average exchange rates in effect during each period. Foreign currency remeasurement losses of $3.2 million, $3.2 million and $1.5 million, are included in other expense—net for 2015, 2014 and 2013, respectively.

[0001262039-16-000053:notes:247]
Other Investments—Investments in privately-held companies where we own less than 20% of the voting stock and have no indicators of significant influence over operating and financial policies of those companies are included in other assets in the consolidated balance sheets and are accounted for under the cost method. For these non-quoted investments, we regularly review the assumptions underlying the operating performance and cash flow forecasts based on information provided by these privately-held companies. If it is determined that an other-than-temporary decline exists in an equity security, we write down the investment to its fair value and record the related impairment as an investment loss in our consolidated statements of operations.

[0001262039-16-000053:notes:248]
Consolidation of Variable Interest Entities—We use a qualitative approach in assessing the consolidation requirement for variable interest entities (“VIEs”). This approach focuses on determining whether we have the power to direct the activities of the VIE that most significantly affect the VIE’s economic performance and whether we have the obligation to absorb losses, or the right to receive benefits, that could potentially be significant to the VIE. For all periods presented in the accompanying consolidated financial statements, we have determined that we are not the primary beneficiary of any VIEs.

[0001262039-16-000053:notes:249]
Business Combinations—We include the results of operations of the businesses that we acquire as of the respective dates of acquisition. We allocate the fair value of the purchase price of our business acquisitions to the tangible assets acquired, liabilities assumed, and intangible assets acquired, based on their estimated fair values. The excess of the purchase price over the fair values of these identifiable assets and liabilities is recorded as goodwill. Additional information existing as of the acquisition date but unknown to us may become known during the remainder of the measurement period, not to exceed 12 months from the acquisition date, which may result in changes to the amounts and allocations recorded.

[0001262039-16-000053:notes:250]
Goodwill —Goodwill represents the excess of purchase consideration over the estimated fair value of net assets of businesses acquired in a business combination. Goodwill acquired in a business combination are not amortized, but instead tested for impairment at least annually during the fourth quarter. We perform our annual goodwill impairment analysis at the reporting unit level. As of December 31, 2015, we had one reporting unit.

[0001262039-16-000053:notes:251]
In reviewing goodwill for impairment we have the option to (i) assess qualitative factors to determine whether it is more-likely-than-not that the fair value of the reporting unit is less than its carrying amount or (ii) bypass the qualitative assessment and proceed directly to a quantitative assessment. If we opt to perform a qualitative assessment, the factors we may review include, but are not limited to (a) macroeconomic conditions; (b) industry and market considerations; (c) cost factors; (d) overall financial performance; (e) other relevant entity-specific events such as changes in management, strategy, customers or litigation; (f) events affecting the reporting unit; or (g) or sustained decrease in share price. If we believe, as a result of the qualitative assessment, that it is more-likely-than-not that the fair value of the reporting unit is less than its carrying amount, the quantitative impairment test will be required. Otherwise, no further testing will be required. A quantitative assessment utilizes a two-step process. In the first step, the fair value of the reporting unit is determined, and is compared against its carrying amount, including goodwill. We consider a combination of an income-based approach using projected discounted cash flows and a market-based approach using multiples of comparable companies to determine the fair value. The fair value of the reporting unit is estimated using significant judgment based on a combination of the income and the market approaches. Under the income approach, we estimate fair value of the reporting unit based on the present value of forecasted future cash flows that the reporting unit is expected to generate over its remaining life. Under the market approach, we estimate fair value of our reporting unit based on an analysis that compares the value of the reporting unit to values of other companies in similar lines of business. If the fair value of the reporting unit is less than its carrying value, then we perform the second step to measure the amount of impairment loss. The amount of impairment is determined by comparing the implied fair value of reporting unit goodwill to the carrying value of the goodwill. When the carrying value of the reporting unit’s goodwill exceeds its implied fair value, we record an impairment loss equal to the difference. We have not been required to perform this second step of the process because the fair value of our reporting unit exceeded the net book value as of December 31, 2015.

[0001262039-16-000053:notes:252]
Determining the fair value of the reporting unit requires us to make judgments and involves the use of significant estimates and assumptions. These estimates and assumptions include revenue growth rates and operating margins used to calculate projected future cash flows, operating trends, risk-adjusted discount rates, future economic and market conditions and determination of appropriate market comparables. We base our fair value estimates on assumptions we believe to be reasonable but that are unpredictable and inherently uncertain. Actual future results may differ from those estimates. We may also test goodwill for impairment between annual tests in the presence of impairment indicators.

[0001262039-16-000053:notes:253]
Other Intangible Assets—Intangible assets with finite lives are carried at cost, less accumulated amortization. Amortization is computed using the straight-line method over the estimated economic lives of the assets, which range from one to five years.

[0001262039-16-000053:notes:254]
Stock-Based Compensation—We have elected to use the Black-Scholes option pricing model to determine the fair value of our employee stock options and employee stock purchase plans (“ESPP”). The fair value of restricted stock units (“RSU”) is based on the closing market price of our common stock on the date of grant. Stock-based compensation expense, net of estimated forfeitures, is amortized on a straight-line basis. Preferred stock units (“PSU”) are RSUs that contain both service-based and market-based vesting conditions. PSUs vest over a specified service period upon the satisfaction of certain market-based vesting conditions, and settle into shares of our common stock upon vesting over a two- or three-year period.  The fair value of a PSU is calculated using the Monte Carlo simulation model on the date of grant and is based on the market price of our common stock on the date of grant modified to reflect the impact of the market-based vesting condition, including the estimated payout level based on that condition. We do not adjust compensation cost for subsequent changes in the expected outcome of the market-based vesting conditions.

[0001262039-16-000053:notes:255]
Advertising Expense—Advertising costs are expensed when incurred and are included in operating expenses in the accompanying consolidated statements of operations. Our advertising expenses were not significant for any periods presented.

[0001262039-16-000053:notes:256]
Research and Development Costs—Research and development costs are expensed as incurred.

[0001262039-16-000053:notes:257]
Software Development Costs—The costs to develop software that is marketed have not been capitalized as we believe our current software development process is essentially completed concurrently with the establishment of technological feasibility. Such costs are expensed as incurred and included in research and development in our consolidated statements of operations.

[0001262039-16-000053:notes:258]
The costs to obtain or develop software for internal use are capitalized based on qualifying criteria, which includes a determination of whether such costs are incurred during the application development stage.  Such costs are amortized over the software’s estimated useful life.

[0001262039-16-000053:notes:259]
Accounts Receivable—Trade accounts receivable are recorded at the invoiced amount, net of sales returns reserve and allowances for doubtful accounts. The sales returns reserve is determined based on specific criteria including agreements to provide rebates and other factors known at the time, as well as estimates of the amount of goods shipped that will be returned. To determine the adequacy of the sales returns reserve, we analyze historical experience of actual rebates and returns. The sales returns reserve was $5.5 million and $5.8 million as of December 31, 2015 and 2014, respectively. The allowance for doubtful accounts is determined based on our assessment of the collectability of customer accounts. The allowance for doubtful accounts was $0.7 million and $0.4 million as of December 31, 2015 and 2014.

[0001262039-16-000053:notes:260]
Warranties—We generally provide a 1-year warranty on hardware products and a 90-day warranty on software. A provision for estimated future costs related to warranty activities is recorded as a component of cost of product revenues when the product revenue is recognized, based upon historical product failure rates and historical costs incurred in correcting product failures. In the event we change our warranty reserve estimates, the resulting charge against future cost of sales or reversal of previously recorded charges may materially affect our gross margins and operating results.

[0001262039-16-000053:notes:261]
Foreign Currency Derivatives—Our sales contracts are primarily denominated in U.S. dollars and therefore substantially all of our revenue is not subject to foreign currency translation risk. However, a substantial portion of our operating expenses incurred outside the U.S. are denominated in foreign currencies and are subject to fluctuations due to changes in foreign currency exchange rates, particularly changes in the CAD and the EUR. To help protect against significant fluctuations in value and the volatility of future cash flows caused by changes in currency exchange rates, we engage in foreign currency risk management activities to hedge balance sheet items denominated in CAD. We do not use these contracts for speculative or trading purposes. All of the derivative instruments are with high quality financial institutions and we monitor the creditworthiness of these parties. These contracts typically have maturities between one and three months. Changes in the fair value of forward exchange contracts related to balance sheet accounts are insignificant and are included in Other expense—net in the consolidated statement of operations. As of December 31, 2015, the fair value of the forward exchange contracts was not material.

[0001262039-16-000053:notes:262]
Additionally, independent of any hedging activities, fluctuations in foreign currency exchange rates may cause us to recognize transaction gains and losses in our consolidated statements of operations. Our hedging activities are intended to reduce, but not eliminate, the impact of currency exchange rate movements. As our hedging activities are relatively short-term in nature and are focused on CAD, long-term material changes in the value of the U.S. dollar against other foreign currencies, such as the EUR, GBP and CNY could adversely impact our operating expenses in the future.


## us-gaap:SubsequentEventsTextBlock

[0001262039-16-000053:notes:263]
SUBSEQUENT EVENTS

[0001262039-16-000053:notes:264]
New Share Repurchase Program

[0001262039-16-000053:notes:265]
In January 2016, our board of directors approved a new Share Repurchase Program (the “New Program”), which authorizes the repurchase of up to $200.0 million of our outstanding common stock through December 31, 2017. Under the program, share repurchases may be made by us from time to time in privately negotiated transactions or in open market transactions. The program does not require us to purchase a minimum number of shares, and may be suspended, modified or discontinued at any time without prior notice. Subsequent to December 31, 2015, through the filing of this Report, we have repurchased 2.0 million shares of our common stock under the new program at an average price of $24.97 per share, for $50.0 million. We have $150.0 million authorized funds remaining under the new program as of the filing date.

[0001262039-16-000053:notes:266]
Building Purchase

[0001262039-16-000053:notes:267]
In February 2016, we purchased certain property in Union City, California totaling approximately 200,000 square feet for a total cash payment of $18.5 million.
