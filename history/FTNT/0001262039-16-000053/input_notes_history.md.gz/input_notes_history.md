# FTNT note change history — 0001262039-15-000024 → 0001262039-15-000048


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2015-11-09):
[0001262039-15-000048:note_history:1]
The following table summarizes our future principal contractual obligations as of September 30, 2015 (in thousands):
  (was, 2015-08-04, similarity 0.9493):
[0001262039-15-000024:note_history:1]
The following table summarizes our future principal contractual obligations as of June 30, 2015 (in thousands):

- changed (2015-11-09):
[0001262039-15-000048:note_history:2]
|  | Total |  | 2015 (remainder) |  | 2016 |  | 2017 |  | 2018 |  | 2019 |  | Thereafter |
| Operating lease commitments | $ | 56,775 |  |  | $ | 4,167 |  |  | $ | 15,679 |  |  | $ | 10,879 |  |  | $ | 8,404 |  |  | $ | 7,053 |  |  | $ | 10,593 |  |
| Inventory purchase commitments | 75,984 |  |  | 73,038 |  |  | 2,946 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Other contractual commitments and open purchase orders | 38,072 |  |  | 26,233 |  |  | 7,995 |  |  | 2,149 |  |  | 751 |  |  | 609 |  |  | 335 |  |
| Total | $ | 170,831 |  |  | $ | 103,438 |  |  | $ | 26,620 |  |  | $ | 13,028 |  |  | $ | 9,155 |  |  | $ | 7,662 |  |  | $ | 10,928 |  |
  (was, 2015-08-04, similarity 0.8415):
[0001262039-15-000024:note_history:2]
|  | Total |  | 2015 (remainder) |  | 2016 |  | 2017 |  | 2018 |  | 2019 |  | Thereafter |
| Operating lease commitments | $ | 50,093 |  |  | $ | 7,064 |  |  | $ | 12,054 |  |  | $ | 8,536 |  |  | $ | 6,865 |  |  | $ | 5,684 |  |  | $ | 9,890 |  |
| Less: sublease rental income | 57 |  |  | 57 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Operating lease commitments—net | 50,036 |  |  | 7,007 |  |  | 12,054 |  |  | 8,536 |  |  | 6,865 |  |  | 5,684 |  |  | 9,890 |  |
| Inventory purchase commitments | 74,322 |  |  | 74,322 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Other contractual commitments and open purchase orders | 33,944 |  |  | 28,729 |  |  | 3,675 |  |  | 978 |  |  | 305 |  |  | 193 |  |  | 64 |  |
| Total | $ | 158,302 |  |  | $ | 110,058 |  |  | $ | 15,729 |  |  | $ | 9,514 |  |  | $ | 7,170 |  |  | $ | 5,877 |  |  | $ | 9,954 |  |

- changed (2015-11-09):
[0001262039-15-000048:note_history:3]
Operating Leases—We lease certain facilities under various non-cancelable operating leases, which expire through 2025. In addition to the amounts above, certain leases require us to pay variable costs such as taxes, maintenance, insurance, and asset retirement obligations. The terms of certain operating leases also provide for renewal options and escalation clauses. Rent expense was $3.7 million and $2.6 million during the three months ended September 30, 2015 and 2014, respectively. Rent expense was $9.7 million and $7.7 million during the nine months ended September 30, 2015 and 2014, respectively. Rent expense is recognized using the straight-line method over the term of the lease.
  (was, 2015-08-04, similarity 0.9536):
[0001262039-15-000024:note_history:3]
Operating Leases—We lease certain facilities under various non-cancelable operating leases, which expire through 2025. In addition to the amounts above, certain leases require us to pay variable costs such as taxes, maintenance, insurance, and asset retirement obligations. The terms of certain operating leases also provide for renewal options and escalation clauses. Rent expense was $2.9 million and $2.4 million during the three months ended June 30, 2015 and 2014, respectively. Rent expense was $6.0 million and $5.1 million during the six months ended June 30, 2015 and 2014, respectively. Rent expense is recognized using the straight-line method over the term of the lease.

- changed (2015-11-09):
[0001262039-15-000048:note_history:4]
Inventory Purchase —Our independent contract manufacturers procure certain inventory items and build our products based on our forecasts. These forecasts are based on estimates of future demand for our products, which are in turn based on historical trends and analysis, adjusted for overall market conditions. In order to reduce manufacturing lead times and plan for adequate component supply, we may issue purchase orders to some of our independent contract manufacturers which may not be cancelable. As of September 30, 2015, we had $76.0 million of open purchase orders with our independent contract manufacturers.
  (was, 2015-08-04, similarity 0.915):
[0001262039-15-000024:note_history:4]
Contract Manufacturer and Other Commitments—Our independent contract manufacturers procure components and build our products based on our forecasts. These forecasts are based on estimates of future demand for our products, which are in turn based on historical trends and analysis, adjusted for overall market conditions. In order to reduce manufacturing lead times and plan for adequate component supply, we may issue purchase orders to some of our independent contract manufacturers which may not be cancelable. As of June 30, 2015, we had $74.3 million of open purchase orders with our independent contract manufacturers.

- changed (2015-11-09):
[0001262039-15-000048:note_history:5]
Other Contractual Commitments and Open Purchase Orders —In addition to commitments with contract manufacturers, we have other contractual commitments and open purchase orders in the ordinary course of business for which we have not received goods or services. As of September 30, 2015, we had $38.1 million in other contractual commitments and open purchase orders.
  (was, 2015-08-04, similarity 0.894):
[0001262039-15-000024:note_history:5]
In addition to commitments with contract manufacturers, we have other contractual commitments and open purchase orders in the ordinary course of business for which we have not received goods or services. As of June 30, 2015, we had $33.9 million in other contractual commitments and open purchase orders.

- added (2015-11-09):
[0001262039-15-000048:note_history:6]
|  | Nine Months Ended |
|  | September 30, 2015 |  | September 30, 2014 |
| Accrued warranty balance—beginning of the period | $ | 4,269 |  |  | $ | 3,037 |  |
| Warranty costs incurred | (3,413 | ) |  | (2,597 | ) |
| Provision for warranty for the period, including warranty liabilities assumed in connection with a business acquisition | 3,638 |  |  | 3,786 |  |
| Adjustment related to pre-existing warranties | (94 | ) |  | (540 | ) |
| Accrued warranty balance—end of the period | $ | 4,400 |  |  | $ | 3,686 |  |

- added (2015-11-09):
[0001262039-15-000048:note_history:7]
Indemnification—Under the indemnification provisions of our standard sales contracts, we agree to defend our customers against third-party claims asserting various allegations such as damage resulting from product defects and infringement of certain intellectual property rights, which may include patents, copyrights, trademarks, or trade secrets, and to pay judgments entered on such claims. In some contracts, our exposure under these indemnification provisions is limited by the terms of the contracts to certain defined limits, such as the total amount paid by our customer under the agreement. However, certain agreements include covenants, penalties and indemnification provisions including and beyond indemnification for third-party claims of intellectual property infringement and that could potentially expose us to losses in excess of the amount received under the agreement and, in some instances, to potential liability that is not contractually limited. To date, there have been no awards under such indemnification provisions.

- removed (2015-11-09):
[0001262039-15-000024:note_history:8]
|  | Six Months Ended |
|  | June 30, 2015 |  | June 30, 2014 |
| Accrued warranty balance—beginning of the period | $ | 4,269 |  |  | $ | 3,037 |  |
| Warranty costs incurred | (2,059 | ) |  | (1,728 | ) |
| Provision for warranty for the period | 2,294 |  |  | 2,560 |  |
| Adjustment related to pre-existing warranties | 171 |  |  | (415 | ) |
| Accrued warranty balance—end of the period | $ | 4,675 |  |  | $ | 3,454 |  |

- removed (2015-11-09):
[0001262039-15-000024:note_history:9]
Indemnification—Under the indemnification provisions of our standard sales contracts, we agree to defend our customers against third-party claims asserting various allegations such as damage resulting from product defects and infringement of certain intellectual property rights, which may include patents, copyrights, trademarks, or trade secrets, and to pay judgments entered on such claims. Our exposure under these indemnification provisions is generally limited by the terms of our contracts to certain defined limits, such as the total amount paid by our customer under the agreement. However, certain agreements include covenants and indemnification provisions including and beyond indemnification for third-party claims of intellectual property infringement and that could potentially expose us to losses in excess of the amount received under the agreement and, in some instances, to potential liability that is not contractually limited. To date, there have been no awards under such indemnification provisions.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2015-11-09):
[0001262039-15-000048:note_history:10]
Basis of Presentation and Preparation—The unaudited condensed consolidated financial statements of Fortinet, Inc. and its wholly-owned subsidiaries (collectively, “we,” “us” or “our”) have been prepared in accordance with generally accepted accounting principles in the United States (“GAAP”) for interim financial information as well as the instructions to Form 10-Q pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (“SEC”). Accordingly, they do not include all of the information and footnotes required by GAAP for complete financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the year ended December 31, 2014, contained in our Annual Report on Form 10-K (“Form 10-K”) filed with the SEC on March 2, 2015. In the opinion of management, all adjustments, which includes normal recurring adjustments, considered necessary for a fair presentation have been included. All intercompany balances, transactions and cash flows have been eliminated. The results of operations for the three and nine months ended September 30, 2015 are not necessarily indicative of the results for the full year or for any future periods. The condensed consolidated balance sheet as of December 31, 2014 is derived from the audited consolidated financial statements for the year ended December 31, 2014.
  (was, 2015-08-04, similarity 0.8095):
[0001262039-15-000024:note_history:10]
Basis of Presentation and Preparation—The unaudited condensed consolidated financial statements of Fortinet, Inc. and its wholly-owned subsidiaries (collectively, “we,” “us” or “our”) have been prepared in accordance with generally accepted accounting principles in the United States (“GAAP”) for interim financial information as well as the instructions to Form 10-Q pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (“SEC”). Accordingly, they do not include all of the information and footnotes required by GAAP for complete financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the year ended December 31, 2014, contained in our Annual Report on Form 10-K (“Form 10-K”) filed with the SEC on March 2, 2015. In the opinion of management, all adjustments, which includes normal recurring adjustments, considered necessary for a fair presentation have been included. All intercompany balances, transactions and cash flows have been eliminated. The results of operations for the three and six months ended June 30, 2015 are not necessarily indicative of the results for the full year or for any future periods. The condensed consolidated balance sheet as of December 31, 2014 is derived from the audited consolidated financial statements for the year ended December 31, 2014.

- changed (2015-11-09):
[0001262039-15-000048:note_history:11]
There have been no material changes to our significant accounting policies as of and for the three and nine months ended September 30, 2015, except for the inclusion of policies related to business combinations and restructuring charges.
  (was, 2015-08-04, similarity 0.6852):
[0001262039-15-000024:note_history:11]
There have been no material changes to our significant accounting policies as of and for the three and six months ended June 30, 2015.

- added (2015-11-09):
[0001262039-15-000048:note_history:12]
Business combinations—We include the results of operations of the businesses that we acquire as of the respective dates of acquisition. We allocate the fair value of the purchase price of our business acquisitions to the tangible assets acquired, liabilities assumed, and intangible assets acquired, based on their estimated fair values. The excess of the purchase price over the fair values of these identifiable assets and liabilities is recorded as goodwill. Additional information existing as of the acquisition date but unknown to us may become known during the remainder of the measurement period, not to exceed 12 months from the acquisition date, which may result in changes to the amounts and allocations recorded.

- added (2015-11-09):
[0001262039-15-000048:note_history:13]
Restructuring charges—We recognize liability for exit and disposal activities when the liability is incurred. Our restructuring charges consist of one-time termination benefits related to the reduction of our workforce, contract-termination costs, such as lease exit costs, and other costs. Liabilities for costs associated with a restructuring activity are measured at fair value and are recognized when the liability is incurred. One-time termination benefits are expensed at the date we notify the employee, unless the employee must provide future service, in which case the benefits are expensed ratably over the future service period. A liability for contract-termination costs represents a liability for costs to terminate a contract before the end of its term and is recognized at fair value when we terminate the contract in accordance with the contract terms, which is usually done by giving written notice to the counterparty within the notification period specified by the contract or by otherwise negotiating a termination with the counterparty. A liability for costs that will continue to be incurred under a contract for its remaining term without economic benefit to the entity is recognized at the cease-use date. Costs to terminate a lease before the end of its term are recognized when the property is vacated. Other costs primarily consist of asset write-offs and consulting fees, which are expensed when incurred.

- added (2015-11-09):
[0001262039-15-000048:note_history:14]
We continually evaluate the adequacy of the remaining liabilities under our restructuring initiatives. Although we believe that these estimates accurately reflect the costs of our restructuring plans, actual results may differ and thereby require us to record an additional provision or reverse a portion of such a provision.

- added (2015-11-09):
[0001262039-15-000048:note_history:15]
In September 2015, the Financial Accounting Standards Board (“FASB“) issued Accounting Standards Update 2015-16—Simplifying the Accounting for Measurement-Period Adjustments (“ASU 2015-16”).  ASU 2015-16 eliminates the requirement for an acquirer in a business combination to account for measurement-period adjustments retrospectively.  Instead, acquirers must recognize measurement-period adjustments during the period in which they determine the amounts, including the effect on earnings of any amounts they would have recorded in previous periods if the accounting had been completed at the acquisition date.  ASU 2015-16 will be effective for us beginning on January 1, 2016.

- changed (2015-11-09):
[0001262039-15-000048:note_history:16]
In July 2015, the FASB issued Accounting Standards Update 2015-11—Inventory—Simplifying the Measurement of Inventory (Topic 330) (“ASU 2015-11”). ASU 2015-11 changes the measurement principle for inventory from the lower of cost or market to lower of cost and net realizable value. It applies to entities that measure inventory using a method other than last-in, first-out or the retail inventory method (e.g., first-in first-out, average cost). ASU 2015-11 will be effective for us beginning on January 1, 2017. We do not expect the impact of ASU 2015-11 on our consolidated financial statements to be significant.
  (was, 2015-08-04, similarity 0.812):
[0001262039-15-000024:note_history:16]
In July 2015, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update 2015-11—Inventory—Simplifying the Measurement of Inventory (Topic 330) (“ASU 2015-11”). ASU 2015-11 changes the measurement principle for inventory from the lower of cost or market to lower of cost and net realizable value. It applies to entities that measure inventory using a method other than last-in, first-out or the retail inventory method (e.g., first-in first-out, average cost). ASU 2015-11 will be effective for us beginning on January 1, 2017. We are currently evaluating the impact of ASU 2015-11 on our consolidated financial statements.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2015-11-09):
[0001262039-15-000048:note_history:17]
The son of one member of our Board of Directors (“Board”) is a partner in an outside law firm that we utilize for certain complex litigation matters. Expenses for legal services provided by the law firm related to matters that arose subsequent to the member joining our Board were $0.9 million each for the three months ended September 30, 2015 and September 30, 2014, respectively. Expenses for legal services provided by the law firm related to matters that arose subsequent to the member joining our Board were $3.7 million and $1.7 million for the nine months ended September 30, 2015 and September 30, 2014, respectively. Amounts due and payable to the law firm were $1.4 million and $1.3 million as of September 30, 2015 and December 31, 2014, respectively.
  (was, 2015-08-04, similarity 0.8497):
[0001262039-15-000024:note_history:17]
The son of one member of our Board of Directors (“Board”) is a partner of an outside law firm that we utilize for certain complex litigation matters. Expenses for legal services provided by the law firm related to matters that arose subsequent to the member joining our Board were $0.9 million and $0.5 million for the three months ended June 30, 2015 and June 30, 2014, respectively. Expenses for legal services provided by the law firm related to matters that arose subsequent to the member joining our Board were $2.8 million and $0.7 million for the six months ended June 30, 2015 and June 30, 2014, respectively. Amounts due and payable to the law firm were $2.3 million and $1.3 million as of June 30, 2015 and December 31, 2014, respectively.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_current_note, score: 0.0

- removed (2015-11-09):
[0001262039-15-000024:note_history:18]
SUBSEQUENT EVENT

- removed (2015-11-09):
[0001262039-15-000024:note_history:19]
In July 2015, we acquired Meru Networks, Inc. (“Meru”), which offers Wi-Fi networking solutions, for a total consideration of approximately $44.0 million. The acquisition expands on our secure wireless vision and enterprise growth focus, broadens our portfolio of solutions , and expands our opportunity to address the global enterprise Wi-Fi market with integrated secure wireless solutions. We are still in the process of evaluating the business combination accounting considerations, including the consideration transferred and the initial purchase price allocation.
