# FTNT 8-K — 0001262039-16-000051 filed 2016-01-28

## item codes, every 8-K on or before 2016-02-26

- 2016-01-28 0001262039-16-000051 — 2.02, 9.01
- 2015-10-27 0001262039-15-000045 — 2.02
- 2015-10-22 0001262039-15-000042 — 5.02 — amendment, the index does not say of what
- 2015-10-22 0001262039-15-000041 — 5.02 — amendment, the index does not say of what
- 2015-10-22 0001262039-15-000039 — 2.02, 9.01
- 2015-09-28 0001262039-15-000034 — 5.02, 9.01
- 2015-09-22 0001262039-15-000031 — 9.01 — amendment of 0001193125-15-248065
- 2015-08-28 0001262039-15-000027 — 3.01, 5.02
- 2015-07-23 0001262039-15-000021 — 5.02
- 2015-07-22 0001262039-15-000019 — 2.02, 9.01
- 2015-07-08 0001193125-15-248065 — 2.01, 8.01, 9.01
- 2015-06-22 0001193125-15-229099 — 5.07
- 2015-06-19 0001193125-15-228428 — 5.02, 9.01
- 2015-04-20 0001262039-15-000014 — 2.02, 9.01
- 2015-01-28 0001262039-15-000005 — 2.02, 9.01
- 2014-10-22 0001262039-14-000036 — 2.02, 9.01
- 2014-07-23 0001262039-14-000030 — 2.02, 9.01
- 2014-06-24 0001262039-14-000027 — 5.07
- 2014-04-23 0001262039-14-000021 — 2.02, 9.01
- 2014-04-21 0001262039-14-000018 — 5.03, 9.01
- 2014-01-29 0001262039-14-000004 — 2.02, 9.01
- 2013-12-20 0001262039-13-000061 — 5.02, 9.01
- 2013-11-27 0001262039-13-000057 — 5.02, 7.01, 9.01
- 2013-11-12 0001445305-13-002993 — 5.02
- 2013-10-23 0001262039-13-000051 — 2.02, 9.01
- 2013-07-30 0001262039-13-000039 — 2.02, 9.01
- 2013-06-25 0001262039-13-000030 — 5.07
- 2013-04-30 0001262039-13-000023 — 2.02, 9.01
- 2013-04-19 0001262039-13-000020 — 5.02, 9.01
- 2013-04-19 0001262039-13-000018 — 5.02 — amendment of 0001262039-13-000020
- 2013-04-10 0001262039-13-000016 — 2.02, 9.01
- 2013-03-26 0001262039-13-000013 — 5.02
- 2013-01-30 0001262039-13-000005 — 2.02, 9.01
- 2013-01-24 0001262039-13-000002 — 5.02, 9.01
- 2012-10-16 0001262039-12-000048 — 2.02, 9.01
- 2012-10-01 0001262039-12-000045 — 5.02
- 2012-09-26 0001262039-12-000043 — 5.01
- 2012-07-25 0001262039-12-000038 — 2.02, 9.01
- 2012-07-19 0001262039-12-000034 — 5.02
- 2012-06-20 0001193125-12-275869 — 5.07
- 2012-04-27 0001262039-12-000029 — 5.02
- 2012-04-24 0001262039-12-000025 — 2.02, 9.01
- 2012-01-31 0001262039-12-000006 — 2.02, 9.01
- 2012-01-25 0001262039-12-000003 — 5.03
- 2011-10-24 0001262039-11-000036 — 2.02
- 2011-07-19 0001262039-11-000014 — 2.02, 9.01
- 2011-06-27 0001193125-11-174474 — 5.02, 5.07, 9.01
- 2011-04-27 0001193125-11-111938 — 2.02, 9.01
- 2011-01-25 0001193125-11-013914 — 2.02, 9.01
- 2010-10-21 0001193125-10-233676 — 2.02, 9.01
- 2010-09-02 0001193125-10-203099 — 8.01
- 2010-07-22 0001193125-10-163844 — 2.02, 9.01
- 2010-06-24 0001193125-10-146082 — 5.07
- 2010-04-28 0001193125-10-096698 — 2.02, 9.01
- 2010-02-09 0001193125-10-024614 — 8.01
- 2010-01-27 0001193125-10-014292 — 2.02, 9.01
- 2010-01-26 0001193125-10-013031 — 5.02, 9.01

## late-filing notifications on or before 2016-02-26

- none on or before 2016-02-26

## item 2.02 — earnings release, exhibit 99.1

[0001262039-16-000051:8k_2_02:1]
EX-99.1
2
ftntq4-2015ex991.htm
PRESS RELEASE

[0001262039-16-000051:8k_2_02:2]
Exhibit

[0001262039-16-000051:8k_2_02:3]
Press Release

[0001262039-16-000051:8k_2_02:4]
| Investor Contact: |  | Media Contact: |
| Michelle Spolver |  | Sandra Wheatley |
| Fortinet, Inc. |  | Fortinet, Inc. |
| 408-486-7837 |  | 408-391-9408 |
| mspolver@fortinet.com |  | swheatley@fortinet.com |

[0001262039-16-000051:8k_2_02:5]
Fortinet Reports Fourth Quarter and Full Year 2015 Financial Results

[0001262039-16-000051:8k_2_02:6]
Company grows Q415 billings 35% and FY15 billings 37% year over year

[0001262039-16-000051:8k_2_02:7]
Fourth Quarter 2015 Highlights

[0001262039-16-000051:8k_2_02:8]
•Billings of $380.9 million, up 35% year over year1

[0001262039-16-000051:8k_2_02:9]
•Revenue of $296.5 million, up 32% year over year

[0001262039-16-000051:8k_2_02:10]
•Non-GAAP diluted net income per share of $0.181

[0001262039-16-000051:8k_2_02:11]
•Cash flow from operations of $68.6 million

[0001262039-16-000051:8k_2_02:12]
•Free cash flow of $60.2 million1

[0001262039-16-000051:8k_2_02:13]
| • | Cash, cash equivalents and investments of $1.16 billion |

[0001262039-16-000051:8k_2_02:14]
| • | Deferred revenue of $791.3 million, up 42% year over year |

[0001262039-16-000051:8k_2_02:15]
Full Year 2015 Highlights

[0001262039-16-000051:8k_2_02:16]
•Billings of $1.23 billion, up 37% year over year1

[0001262039-16-000051:8k_2_02:17]
•Revenue of $1.01 billion, up 31% year over year

[0001262039-16-000051:8k_2_02:18]
•Non-GAAP diluted net income per share of $0.511

[0001262039-16-000051:8k_2_02:19]
•Cash flow from operations of $282.5 million

[0001262039-16-000051:8k_2_02:20]
•Free cash flow of $245.2 million1

[0001262039-16-000051:8k_2_02:21]
SUNNYVALE, Calif. - January 28, 2016 - Fortinet® (NASDAQ: FTNT), a global leader in high performance cyber security solutions, today announced financial results for the fourth quarter and full year ended December 31, 2015.

[0001262039-16-000051:8k_2_02:22]
“Fortinet’s solid fourth quarter results help close a strong year, highlighted by our ability to achieve, for the full year, 37% billings growth and reach more than $1 billion in billings and revenue,” said Ken Xie, founder, chairman and chief executive officer. “Very few companies have achieved this type of growth at Fortinet’s scale and it is due to our strong technology advantage and early returns on our customer acquisition and expansion strategy. With cyber security remaining at the forefront of enterprise IT priorities, Fortinet is well-positioned to grow and gain global market share in 2016 and beyond.”

[0001262039-16-000051:8k_2_02:23]
Financial Highlights for the Fourth Quarter of 2015

[0001262039-16-000051:8k_2_02:24]
| • | Billings1: Total billings were $380.9 million for the fourth quarter of 2015, an increase of 35% compared to $282.7 million in the same quarter of 2014. Total billings for the fourth quarter of 2015 of $380.9 million included billings of $16.5 million from products and services pursuant to our July 2015 acquisition of Meru Networks. Excluding Meru, our billings were $364.4 million, an increase of 29% compared to the same quarter last year. |

[0001262039-16-000051:8k_2_02:25]
| • | Revenue: Total revenue was $296.5 million for the fourth quarter of 2015, an increase of 32% compared to $224.0 million in the same quarter of 2014. Total revenue for the fourth quarter of 2015 of $296.5 million included Meru’s revenue of $16.0 million. Excluding Meru, our revenue was $280.5 million, an increase of 25% compared to the same quarter last year. |

[0001262039-16-000051:8k_2_02:26]
Within total revenue, product revenue was $144.8 million, an increase of 31% compared to $110.7 million in the same quarter of 2014. Product revenue included revenue from Meru of $12.7 million. Service revenue was $151.8 million, an increase of 34% compared to $113.3 million in the same quarter of 2014. Service revenue included revenue from Meru of $3.3 million.

[0001262039-16-000051:8k_2_02:27]
| • | Deferred Revenue: Total deferred revenue was $791.3 million as of December 31, 2015, an increase of $84.4 million compared to $706.9 million as of September 30, 2015. Total deferred revenue as of December 31, 2015 of $791.3 million included deferred revenue relating to Meru of $14.5 million, or 2% of total deferred revenue. Excluding Meru, our deferred revenue was $776.8 million, an increase of $83.9 million or 12% compared to September 30, 2015. |

[0001262039-16-000051:8k_2_02:28]
| • | Cash and Cash Flow2: As of December 31, 2015, cash, cash equivalents and investments were $1.16 billion, compared to $1.17 billion as of September 30, 2015. In the fourth quarter of 2015, cash flow from operations was $68.6 million compared to $35.4 million in the same quarter of 2014. Free cash flow1 was $60.2 million during the fourth quarter of 2015 compared to $30.0 million in the same quarter of 2014. |

[0001262039-16-000051:8k_2_02:29]
| • | GAAP Operating Income: GAAP operating income was $12.9 million for the fourth quarter of 2015, representing a GAAP operating margin of 4%. GAAP operating income was $19.9 million for the same quarter of 2014, representing a GAAP operating margin of 9%. |

[0001262039-16-000051:8k_2_02:30]
| • | Non-GAAP Operating Income1: Non-GAAP operating income was $47.6 million for the fourth quarter of 2015, representing a non-GAAP operating margin of 16%. Non-GAAP operating income was $36.8 million for the same quarter of 2014, representing a non-GAAP operating margin of 16%. |

[0001262039-16-000051:8k_2_02:31]
| • | GAAP Net Income or Loss and Diluted Net Income or Loss Per Share: GAAP net loss was $2.5 million for the fourth quarter of 2015, compared to GAAP net income of $6.8 million for the same quarter of 2014. GAAP diluted net loss per share was $0.01 for the fourth quarter of 2015, compared to GAAP diluted net income per share of $0.04 for the same quarter of 2014. |

[0001262039-16-000051:8k_2_02:32]
| • | Non-GAAP Net Income and Diluted Net Income Per Share1: Non-GAAP net income was $32.4 million for the fourth quarter of 2015, compared to non-GAAP net income of |

[0001262039-16-000051:8k_2_02:33]
$24.1 million for the same quarter of 2014.  Non-GAAP diluted net income per share was $0.18 for the fourth quarter of 2015, compared to $0.14 for the same quarter of 2014.

[0001262039-16-000051:8k_2_02:34]
Financial Highlights for the Full Year 2015

[0001262039-16-000051:8k_2_02:35]
| • | Billings1: Total billings were $1.23 billion for 2015, an increase of 37% compared to $896.5 million in 2014. Total billings in 2015 of $1.23 billion included Meru’s billings from July 8, 2015 to December 31, 2015 of $32.8 million, or 3% of total billings. Excluding Meru, our billings were $1.20 billion, an increase of 34% compared to 2014. |

[0001262039-16-000051:8k_2_02:36]
| • | Revenue: Total revenue was $1.01 billion for 2015, an increase of 31% compared to $770.4 million in 2014. Total revenue in 2015 of $1.01 billion included Meru’s revenue from July 8, 2015 to December 31, 2015 of $28.1 million, or 3% of total revenue. Excluding Meru, our revenue was $981.2 million, an increase of 27% compared to 2014. |

[0001262039-16-000051:8k_2_02:37]
Within total revenue, product revenue was $476.8 million, an increase of 32% compared to $360.6 million in 2014. Product revenue included revenue from Meru of $22.2 million.  Service revenue was $532.5 million, an increase of 30% compared to $409.8 million in 2014. Service revenue included revenue from Meru of $5.8 million.

[0001262039-16-000051:8k_2_02:38]
| • | Deferred Revenue: Total deferred revenue was $791.3 million as of December 31, 2015, an increase of $232.5 million compared to $558.8 million as of December 31, 2014. Total deferred revenue as of December 31, 2015 of $791.3 million included deferred revenue relating to Meru of $14.5 million, or 2% of total deferred revenue. Excluding Meru, our deferred revenue was $776.8 million, an increase of $218.0 million or 39% compared to December 31, 2014. |

[0001262039-16-000051:8k_2_02:39]
| • | Cash and Cash Flow2: As of December 31, 2015, cash, cash equivalents and investments were $1.16 billion, compared to $991.7 million as of December 31, 2014. In 2015, cash flow from operations was $282.5 million compared to $196.6 million in 2014. Free cash flow1 was $245.2 million in 2015 compared to $164.4 million in 2014. |

[0001262039-16-000051:8k_2_02:40]
| • | GAAP Operating Income: GAAP operating income was $14.9 million for 2015, representing a GAAP operating margin of 1%. GAAP operating income was $59.3 million for 2014, representing a GAAP operating margin of 8%. |

[0001262039-16-000051:8k_2_02:41]
| • | Non-GAAP Operating Income1: Non-GAAP operating income was $133.3 million for 2015, representing a non-GAAP operating margin of 13%. Non-GAAP operating income was $122.1 million for 2014, representing a non-GAAP operating margin of 16%. |

[0001262039-16-000051:8k_2_02:42]
| • | GAAP Net Income and Diluted Net Income Per Share: GAAP net income was $8.0 million for 2015, compared to GAAP net income of $25.3 million for 2014. GAAP diluted net income per share was $0.05 for 2015, compared to $0.15 for 2014. |

[0001262039-16-000051:8k_2_02:43]
| • | Non-GAAP Net Income and Diluted Net Income Per Share1: Non-GAAP net income was $89.4 million for 2015, compared to non-GAAP net income of $80.8 million for 2014. Non-GAAP diluted net income per share was $0.51 for 2015, compared to $0.48 for 2014. |

[0001262039-16-000051:8k_2_02:44]
1 A reconciliation of GAAP to non-GAAP financial measures has been provided in the financial statement tables included in this press release. An explanation of these measures is also included below under the heading “Non-GAAP Financial Measures.”

[0001262039-16-000051:8k_2_02:45]
2 During the fourth quarter and year ended December 31, 2015, we repurchased $60.0 million of our common stock under our share repurchase program. During the fourth quarter and year ended December 31, 2014, we repurchased $5.4 million and $38.6 million, respectively, of our common stock under our share repurchase program.

[0001262039-16-000051:8k_2_02:46]
Conference Call Details

[0001262039-16-000051:8k_2_02:47]
Fortinet will host a conference call today, January 28, 2016, at 1:30 p.m. Pacific Time (4:30 p.m. Eastern Time) to discuss its financial results.  To access this call, dial (877) 303-6913 (domestic) or (224) 357-2188 (international) with conference ID # 20590459. A live webcast of the conference call and supplemental slides will be accessible from the Investor Relations page of Fortinet's website at http://investor.fortinet.com and a replay will be archived and accessible at http://investor.fortinet.com/events.cfm.  A replay of this conference call can also be accessed through February 4, 2016, by dialing (855) 859-2056 (domestic) or (404) 537-3406 (international) with conference ID# 20590459.

[0001262039-16-000051:8k_2_02:48]
Following Fortinet's financial results conference call, the Company will host an additional question-and-answer session at 3:30 p.m. Pacific Time (6:30 p.m. Eastern Time) to provide an opportunity for financial analysts and investors to ask more detailed questions. To access this call, dial (877) 303-6913 (domestic) or (224) 357-2188 (international) with conference ID # 20592139. This follow-up call will be webcast live and accessible at http://investor.fortinet.com, and a replay will be archived and available after the call at http://investor.fortinet.com/events.cfm. A replay of this conference call will also be available through February 4, 2016 by dialing (855) 859-2056 (domestic) or (404) 537-3406 (international) with conference ID # 20592139.

[0001262039-16-000051:8k_2_02:49]
About Fortinet (www.fortinet.com)

[0001262039-16-000051:8k_2_02:50]
Fortinet (NASDAQ: FTNT) protects the most valuable assets of some of the largest enterprise, service provider and government organizations across the globe. The company’s fast, secure and global cyber security solutions provide broad, high-performance protection against dynamic security threats while simplifying the IT infrastructure. They are strengthened by the industry’s highest level of threat research, intelligence and analytics. Unlike pure-play network security providers, Fortinet can solve organizations’ most important security challenges, whether in networked, application or mobile environments - be it virtualized/cloud or physical. More than 200,000 customers worldwide, including some of the largest and most complex organizations, trust Fortinet to protect their brands. Learn more at www.fortinet.com, the Fortinet Blog or FortiGuard Labs.

[0001262039-16-000051:8k_2_02:51]
#          #          #

[0001262039-16-000051:8k_2_02:52]
Copyright © 2016 Fortinet, Inc. All rights reserved. The symbols ® and ™ denote respectively federally registered trademarks and unregistered trademarks of Fortinet, Inc., its subsidiaries and affiliates. Fortinet's trademarks include, but are not limited to, the following: Fortinet, FortiGate, FortiGuard, FortiManager, FortiMail, FortiClient, FortiCloud, FortiCare, FortiAnalyzer, FortiReporter, FortiOS, FortiASIC, FortiWiFi, FortiSwitch, FortiVoIP, FortiBIOS, FortiLog, FortiResponse, FortiCarrier, FortiScan, FortiAP, FortiDB, FortiVoice and FortiWeb. Other trademarks belong to their respective owners.

[0001262039-16-000051:8k_2_02:53]
FTNT-F

[0001262039-16-000051:8k_2_02:54]
Forward-looking Statements

[0001262039-16-000051:8k_2_02:55]
This press release contains forward-looking statements that involve risks and uncertainties.

[0001262039-16-000051:8k_2_02:56]
Non-GAAP Financial Measures

[0001262039-16-000051:8k_2_02:57]
We have provided in this release financial information that has not been prepared in accordance with Generally Accepted Accounting Principles (GAAP). These non-GAAP financial measures are not based on any standardized methodology prescribed by GAAP and are not necessarily comparable to similar measures presented by other companies. We use these non-GAAP financial measures internally in analyzing our financial results and believe they are useful to investors, as a supplement to GAAP measures, in evaluating our ongoing operational performance. We believe that the use of these non-GAAP financial measures provides an additional tool for investors to use in evaluating ongoing operating results and trends and in comparing our financial results with peer companies, many of which present similar non-GAAP financial measures to investors.

[0001262039-16-000051:8k_2_02:58]
Non-GAAP financial measures should not be considered in isolation from, or as a substitute for, financial information prepared in accordance with GAAP. Investors are encouraged to review the reconciliation of these non-GAAP financial measures to their most directly comparable GAAP financial measures provided in the financial statement tables below.

[0001262039-16-000051:8k_2_02:59]
Billings. We define billings as revenue recognized in accordance with GAAP plus the change in deferred revenue from the beginning to the end of the period less any deferred revenue balances acquired from business combination(s) during the period. We consider billings to be a useful metric for management and investors because billings drives deferred revenue, which is an important indicator of the health and viability of our business. There are a number of limitations related to the use of billings versus GAAP revenue. First, billings include amounts that have not yet been recognized as revenue. Second, we may calculate billings in a manner

[0001262039-16-000051:8k_2_02:60]
that is different from peer companies that report similar financial measures. Management compensates for these limitations by providing specific information regarding GAAP revenue and evaluating billings together with GAAP revenue.

[0001262039-16-000051:8k_2_02:61]
Free cash flow. We define free cash flow as net cash provided by operating activities minus capital expenditures (purchases of property and equipment). We consider free cash flow to be a liquidity measure that provides useful information to management and investors about the amount of cash generated by the business that, after the acquisition of property and equipment, can be used for strategic opportunities, including investing in our business, making strategic acquisitions, repurchasing outstanding common stock, and strengthening the balance sheet. Analysis of free cash flow facilitates management’s comparisons of our operating results to peer companies. A limitation of using free cash flow versus the GAAP measure of net cash provided by operating activities as a means for evaluating liquidity is that free cash flow does not represent the total increase or decrease in the cash, cash equivalents and investments balance for the period because free cash flow excludes cash provided by or used for other investing and financing activities. Management compensates for this limitation by providing information about our capital expenditures and other investing and financing activities on the face of the cash flow statement and under the caption “Management’s Discussion and Analysis of Financial Condition and Results of Operations - Liquidity and Capital Resources” in our most recent Quarterly Report on Form 10-Q and Annual Report on Form 10-K.

[0001262039-16-000051:8k_2_02:62]
Non-GAAP operating income and operating margin. We define non-GAAP operating income as operating income plus stock-based compensation, business acquisition-related charges, including inventory fair value adjustment amortization and other purchase accounting adjustments, impairment and amortization of acquired intangible assets, restructuring charges, expenses associated with the implementation of a new Enterprise Resource Planning (ERP) system, and, when applicable, any other significant non-recurring items in a given quarter. Non-GAAP operating margin is defined as non-GAAP operating income divided by GAAP revenue. We consider these non-GAAP financial measures to be useful metrics for management and investors because they exclude the items noted above so that our management and investors can compare our recurring core business operating results over multiple periods. There are a number of limitations related to the use of non-GAAP operating income versus operating income calculated in accordance with GAAP. First, non-GAAP operating income excludes the items noted above. Stock-based compensation has been and will continue to be, for the foreseeable future, a significant recurring expense in our business. Second, stock-based compensation expense is an important part of our employees’ compensation and may impact their performance. Third, the components of the costs that we exclude from our calculation of non-GAAP operating income may differ from the components that peer companies exclude when they report their non-GAAP results of operations. Management compensates for these limitations by providing specific information regarding the GAAP amounts excluded from non-GAAP operating income and evaluating non-GAAP operating income together with operating income calculated in accordance with GAAP.

[0001262039-16-000051:8k_2_02:63]
Non-GAAP net income and diluted net income per share. We define non-GAAP net income as net income plus the items noted above under non-GAAP operating income and operating margin, adjusted for the impact of the tax adjustment, if any required, resulting in an effective tax rate on a non-GAAP basis, which often differs from the GAAP effective tax rate. We define non-GAAP diluted net income per share as non-GAAP net income divided by the weighted-average diluted shares outstanding. We consider these non-GAAP financial measures to be useful metrics for management and investors for the same reasons that we use non-GAAP operating income and non-GAAP operating margin. However, in order to provide a complete picture of our recurring core business operating results, we include in non-GAAP net income and non-GAAP diluted net income per share, the tax adjustment required resulting in an

[0001262039-16-000051:8k_2_02:64]
effective tax rate on a non-GAAP basis, which often differs from the GAAP tax rate. We believe the effective tax rates we used are reasonable estimates of normalized tax rates for our current and prior fiscal years under our global operating structure. The same limitations described above regarding our use of non-GAAP operating income and non-GAAP operating margin apply to our use of non-GAAP net income and non-GAAP diluted net income per share. We compensate for these limitations by providing specific information regarding the GAAP amounts excluded from non-GAAP net income and non-GAAP diluted net income per share and evaluating non-GAAP net income and non-GAAP diluted net income per share together with net income and diluted net income per share calculated in accordance with GAAP.

[0001262039-16-000051:8k_2_02:65]
FORTINET, INC.

[0001262039-16-000051:8k_2_02:66]
CONSOLIDATED BALANCE SHEETS

[0001262039-16-000051:8k_2_02:67]
(Unaudited, in thousands)

[0001262039-16-000051:8k_2_02:68]
|  | December 31, 2015 |  | December 31, 2014 |
| ASSETS |  |  |  |
| CURRENT ASSETS: |  |  |  |
| Cash and cash equivalents | $ | 543,277 |  |  | $ | 283,254 |  |
| Short-term investments | 348,074 |  |  | 436,766 |  |
| Accounts receivable—net | 259,563 |  |  | 184,741 |  |
| Inventory | 83,868 |  |  | 69,477 |  |
| Prepaid expenses and other current assets | 35,761 |  |  | 31,143 |  |
| Total current assets | 1,270,543 |  |  | 1,005,381 |  |
| LONG-TERM INVESTMENTS | 272,959 |  |  | 271,724 |  |
| DEFFERRED TAX ASSETS 1 | 119,216 |  |  | 72,564 |  |
| PROPERTY AND EQUIPMENT—net | 91,067 |  |  | 58,919 |  |
| OTHER INTANGIBLE ASSETS—net | 17,640 |  |  | 2,832 |  |
| GOODWILL | 4,692 |  |  | 2,824 |  |
| OTHER ASSETS | 14,393 |  |  | 10,530 |  |
| TOTAL ASSETS | $ | 1,790,510 |  |  | $ | 1,424,774 |  |
| LIABILITIES AND STOCKHOLDERS' EQUITY |  |  |  |
| CURRENT LIABILITIES: |  |  |  |
| Accounts payable | $ | 61,500 |  |  | $ | 49,947 |  |
| Accrued liabilities | 33,028 |  |  | 29,016 |  |
| Accrued payroll and compensation | 61,111 |  |  | 45,875 |  |
| Income taxes payable | 8,379 |  |  | 2,689 |  |
| Deferred revenue | 514,652 |  |  | 368,929 |  |
| Total current liabilities | 678,670 |  |  | 496,456 |  |
| DEFERRED REVENUE | 276,651 |  |  | 189,828 |  |
| INCOME TAXES PAYABLE | 60,624 |  |  | 45,139 |  |
| OTHER LIABILITIES | 19,188 |  |  | 17,385 |  |
| Total liabilities | 1,035,133 |  |  | 748,808 |  |
| STOCKHOLDERS' EQUITY: |  |  |  |
| Common stock | 171 |  |  | 166 |  |
| Additional paid-in capital | 687,658 |  |  | 562,504 |  |
| Accumulated other comprehensive loss | (933 | ) |  | (349 | ) |
| Retained earnings | 68,481 |  |  | 113,645 |  |
| Total stockholders’ equity | 755,377 |  |  | 675,966 |  |
| TOTAL LIABILITIES AND STOCKHOLDERS’ EQUITY | $ | 1,790,510 |  |  | $ | 1,424,774 |  |

[0001262039-16-000051:8k_2_02:69]
1 In November 2015, the Financial Accounting Standards Board issued Accounting Standard Update No. 2015-17, which requires that deferred tax assets be classified as noncurrent in a classified statement of financial position. We early adopted this standard and applied the requirements retrospectively. The adoption of this standard resulted in the reclassification of $41.5 million from deferred tax assets—current in the consolidated balance sheet as of December 31, 2014 to deferred tax assets—noncurrent.

[0001262039-16-000051:8k_2_02:70]
FORTINET, INC.

[0001262039-16-000051:8k_2_02:71]
CONSOLIDATED STATEMENTS OF OPERATIONS

[0001262039-16-000051:8k_2_02:72]
(Unaudited, in thousands, except per share amounts)

[0001262039-16-000051:8k_2_02:73]
|  | Three Months Ended |  | Year Ended |
|  | December 31, 2015 |  | December 31, 2014 |  | December 31, 2015 |  | December 31, 2014 |
| REVENUE: |  |  |  |  |  |  |  |
| Product | $ | 144,759 |  |  | $ | 110,678 |  |  | $ | 476,782 |  |  | $ | 360,558 |  |
| Service | 151,770 |  |  | 113,291 |  |  | 532,486 |  |  | 409,806 |  |
| Total revenue | 296,529 |  |  | 223,969 |  |  | 1,009,268 |  |  | 770,364 |  |
| COST OF REVENUE: |  |  |  |  |  |  |  |
| Product 1 | 55,466 |  |  | 46,070 |  |  | 190,398 |  |  | 151,300 |  |
| Service 1 | 26,510 |  |  | 19,554 |  |  | 96,379 |  |  | 79,709 |  |
| Total cost of revenue | 81,976 |  |  | 65,624 |  |  | 286,777 |  |  | 231,009 |  |
| GROSS PROFIT: |  |  |  |  |  |  |  |
| Product | 89,293 |  |  | 64,608 |  |  | 286,384 |  |  | 209,258 |  |
| Service | 125,260 |  |  | 93,737 |  |  | 436,107 |  |  | 330,097 |  |
| Total gross profit | 214,553 |  |  | 158,345 |  |  | 722,491 |  |  | 539,355 |  |
| OPERATING EXPENSES: |  |  |  |  |  |  |  |
| Research and development 1 | 42,814 |  |  | 33,097 |  |  | 158,129 |  |  | 122,880 |  |
| Sales and marketing 1 | 136,840 |  |  | 93,228 |  |  | 470,371 |  |  | 315,804 |  |
| General and administrative 1 | 20,315 |  |  | 12,104 |  |  | 71,514 |  |  | 41,347 |  |
| Restructuring charges | 1,717 |  |  | — |  |  | 7,600 |  |  | — |  |
| Total operating expenses | 201,686 |  |  | 138,429 |  |  | 707,614 |  |  | 480,031 |  |
| OPERATING INCOME | 12,867 |  |  | 19,916 |  |  | 14,877 |  |  | 59,324 |  |
| INTEREST INCOME | 1,176 |  |  | 1,402 |  |  | 5,295 |  |  | 5,393 |  |
| OTHER EXPENSE—net | (1,007 | ) |  | (1,200 | ) |  | (3,167 | ) |  | (3,168 | ) |
| INCOME BEFORE INCOME TAXES | 13,036 |  |  | 20,118 |  |  | 17,005 |  |  | 61,549 |  |
| PROVISION FOR INCOME TAXES | 15,570 |  |  | 13,305 |  |  | 9,018 |  |  | 36,206 |  |
| NET INCOME (LOSS) | $ | (2,534 | ) |  | $ | 6,813 |  |  | $ | 7,987 |  |  | $ | 25,343 |  |
| Net income (loss) per share: |  |  |  |  |  |  |  |
| Basic | $ | (0.01 | ) |  | $ | 0.04 |  |  | $ | 0.05 |  |  | $ | 0.15 |  |
| Diluted | $ | (0.01 | ) |  | $ | 0.04 |  |  | $ | 0.05 |  |  | $ | 0.15 |  |
| Weighted-average shares outstanding: |  |  |  |  |  |  |  |
| Basic | 171,831 |  |  | 165,439 |  |  | 170,385 |  |  | 163,831 |  |
| Diluted | 171,831 |  |  | 170,927 |  |  | 176,141 |  |  | 169,289 |  |
| 1 Includes stock-based compensation as follows: |  |  |  |  |  |  |  |
| Cost of product revenue | $ | 332 |  |  | $ | 132 |  |  | $ | 973 |  |  | $ | 483 |  |
| Cost of service revenue | 1,980 |  |  | 1,612 |  |  | 7,121 |  |  | 5,826 |  |
| Research and development | 7,194 |  |  | 4,706 |  |  | 24,555 |  |  | 17,264 |  |
| Sales and marketing | 14,954 |  |  | 7,854 |  |  | 49,436 |  |  | 26,744 |  |
| General and administrative | 3,627 |  |  | 2,377 |  |  | 13,003 |  |  | 8,677 |  |
|  | $ | 28,087 |  |  | $ | 16,681 |  |  | $ | 95,088 |  |  | $ | 58,994 |  |

[0001262039-16-000051:8k_2_02:74]
FORTINET, INC.

[0001262039-16-000051:8k_2_02:75]
CONSOLIDATED STATEMENTS OF COMPREHENSIVE INCOME (LOSS)

[0001262039-16-000051:8k_2_02:76]
(Unaudited, in thousands)

[0001262039-16-000051:8k_2_02:77]
|  | Three Months Ended |  | Year Ended |
|  | December 31, 2015 |  | December 31, 2014 |  | December 31, 2015 |  | December 31, 2014 |
| Net income (loss) | $ | (2,534 | ) |  | $ | 6,813 |  |  | $ | 7,987 |  |  | $ | 25,343 |  |
| Other comprehensive loss—net of taxes: |  |  |  |  |  |  |  |
| Foreign currency translation losses | — |  |  | — |  |  | — |  |  | (333 | ) |
| Unrealized losses on investments | (1,297 | ) |  | (715 | ) |  | (897 | ) |  | (1,708 | ) |
| Tax provision related to items of other comprehensive loss | 454 |  |  | 252 |  |  | 313 |  |  | 600 |  |
| Other comprehensive loss—net of taxes | (843 | ) |  | (463 | ) |  | (584 | ) |  | (1,441 | ) |
| Comprehensive income (loss) | $ | (3,377 | ) |  | $ | 6,350 |  |  | $ | 7,403 |  |  | $ | 23,902 |  |

[0001262039-16-000051:8k_2_02:78]
FORTINET, INC.

[0001262039-16-000051:8k_2_02:79]
CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001262039-16-000051:8k_2_02:80]
(Unaudited, in thousands)

[0001262039-16-000051:8k_2_02:81]
|  | Three Months Ended |  | Year Ended |
|  | December 31, 2015 |  | December 31, 2014 |  | December 31, 2015 |  | December 31, 2014 |
| CASH FLOWS FROM OPERATING ACTIVITIES: |  |  |  |  |  |  |  |
| Net income (loss) | $ | (2,534 | ) |  | $ | 6,813 |  |  | $ | 7,987 |  |  | $ | 25,343 |  |
| Adjustments to reconcile net income (loss) to net cash provided by operating activities: |  |  |  |  |  |  |  |
| Depreciation and amortization | 9,383 |  |  | 5,509 |  |  | 31,589 |  |  | 22,028 |  |
| Amortization of investment premiums | 1,687 |  |  | 2,023 |  |  | 7,457 |  |  | 8,703 |  |
| Stock-based compensation | 28,087 |  |  | 16,681 |  |  | 95,088 |  |  | 58,994 |  |
| Excess tax benefit from stock-based compensation | — |  |  | 4,325 |  |  | — |  |  | — |  |
| Other non-cash items—net | 1,285 |  |  | 339 |  |  | 3,965 |  |  | 4,140 |  |
| Changes in operating assets and liabilities, net of assets acquired and liabilities assumed in business acquisitions: |  |  |  |  |  |  |  |
| Accounts receivable—net | (86,125 | ) |  | (69,028 | ) |  | (65,202 | ) |  | (55,888 | ) |
| Inventory | (6,661 | ) |  | (21,364 | ) |  | (19,088 | ) |  | (32,459 | ) |
| Deferred tax assets | (1,554 | ) |  | 21,258 |  |  | (29,851 | ) |  | 9,072 |  |
| Prepaid expenses and other current assets | 5,176 |  |  | (13,219 | ) |  | (2,630 | ) |  | (16,000 | ) |
| Other assets | 931 |  |  | (1,143 | ) |  | 667 |  |  | (1,302 | ) |
| Accounts payable | 7,325 |  |  | 14,227 |  |  | (2,517 | ) |  | 18,033 |  |
| Accrued liabilities | 4,179 |  |  | 4,302 |  |  | 883 |  |  | 7,120 |  |
| Accrued payroll and compensation | 13,196 |  |  | 5,184 |  |  | 11,301 |  |  | 10,835 |  |
| Other liabilities | 3,247 |  |  | (32 | ) |  | 2,016 |  |  | 14,318 |  |
| Deferred revenue | 84,317 |  |  | 59,410 |  |  | 220,510 |  |  | 127,416 |  |
| Income taxes payable | 6,619 |  |  | 79 |  |  | 20,372 |  |  | (3,771 | ) |
| Net cash provided by operating activities | 68,558 |  |  | 35,364 |  |  | 282,547 |  |  | 196,582 |  |
| CASH FLOWS FROM INVESTING ACTIVITIES: |  |  |  |  |  |  |  |
| Purchases of investments | (130,216 | ) |  | (108,276 | ) |  | (459,903 | ) |  | (497,084 | ) |
| Sales of investments | 12,516 |  |  | 14,473 |  |  | 47,900 |  |  | 41,755 |  |
| Maturities of investments | 122,163 |  |  | 86,356 |  |  | 486,419 |  |  | 458,193 |  |
| Purchases of property and equipment | (8,345 | ) |  | (5,395 | ) |  | (37,358 | ) |  | (32,197 | ) |
| Payments made in connection with business acquisitions— net of cash acquired | — |  |  | — |  |  | (38,025 | ) |  | (17 | ) |
| Net cash used in investing activities | (3,882 | ) |  | (12,842 | ) |  | (967 | ) |  | (29,350 | ) |
| CASH FLOWS FROM FINANCING ACTIVITIES: |  |  |  |  |  |  |  |
| Proceeds from issuance of common stock | 3,771 |  |  | 14,795 |  |  | 67,314 |  |  | 55,324 |  |
| Taxes paid related to net share settlement of equity awards | (5,882 | ) |  | (2,092 | ) |  | (28,871 | ) |  | (10,598 | ) |
| Excess tax benefit from stock-based compensation | — |  |  | (4,325 | ) |  | — |  |  | — |  |
| Repurchase and retirement of common stock | (60,000 | ) |  | (5,742 | ) |  | (60,000 | ) |  | (43,977 | ) |
| Net cash provided by (used in) financing activities | (62,111 | ) |  | 2,636 |  |  | (21,557 | ) |  | 749 |  |
| EFFECT OF EXCHANGE RATES ON CASH AND CASH EQUIVALENTS | — |  |  | — |  |  | — |  |  | (600 | ) |
| NET INCREASE IN CASH AND CASH EQUIVALENTS | 2,565 |  |  | 25,158 |  |  | 260,023 |  |  | 167,381 |  |
| CASH AND CASH EQUIVALENTS—Beginning of period | 540,712 |  |  | 258,096 |  |  | 283,254 |  |  | 115,873 |  |
| CASH AND CASH EQUIVALENTS—End of period | $ | 543,277 |  |  | $ | 283,254 |  |  | $ | 543,277 |  |  | $ | 283,254 |  |

[0001262039-16-000051:8k_2_02:82]
Reconciliations of non-GAAP results of operations measures to the nearest comparable GAAP measures

[0001262039-16-000051:8k_2_02:83]
(Unaudited, in thousands)

[0001262039-16-000051:8k_2_02:84]
Reconciliation of total consolidated GAAP revenue to billings

[0001262039-16-000051:8k_2_02:85]
|  | Three Months Ended |  | Year Ended |
|  | December 31, 2015 |  | December 31, 2014 |  | December 31, 2015 |  | December 31, 2014 |
| Total revenue | $ | 296,529 |  |  | $ | 223,969 |  |  | $ | 1,009,268 |  |  | $ | 770,364 |  |
| Add increase in deferred revenue | 84,392 |  |  | 58,745 |  |  | 232,546 |  |  | 126,129 |  |
| Less deferred revenue balance acquired in business combination | — |  |  | — |  |  | (9,800 | ) |  | — |  |
| Total billings (Non-GAAP) | $ | 380,921 |  |  | $ | 282,714 |  |  | $ | 1,232,014 |  |  | $ | 896,493 |  |

[0001262039-16-000051:8k_2_02:86]
Reconciliation of Meru's GAAP revenue to billings

[0001262039-16-000051:8k_2_02:87]
|  | Three Months Ended |  | Year Ended |
|  | December 31, 2015 |  | December 31, 2015 |
| Total revenue | $ | 16,026 |  |  | $ | 28,050 |  |
| Add increase in deferred revenue | 513 |  |  | 4,706 |  |
| Total billings (Non-GAAP) | $ | 16,539 |  |  | $ | 32,756 |  |

[0001262039-16-000051:8k_2_02:88]
Reconciliation of net cash provided by operating activities to free cash flow

[0001262039-16-000051:8k_2_02:89]
|  | Three Months Ended |  | Year Ended |
|  | December 31, 2015 |  | December 31, 2014 |  | December 31, 2015 |  | December 31, 2014 |
| Net cash provided by operating activities | $ | 68,558 |  |  | $ | 35,364 |  |  | $ | 282,547 |  |  | $ | 196,582 |  |
| Less purchases of property and equipment | (8,345 | ) |  | (5,395 | ) |  | (37,358 | ) |  | (32,197 | ) |
| Free cash flow (Non-GAAP) | $ | 60,213 |  |  | $ | 29,969 |  |  | $ | 245,189 |  |  | $ | 164,385 |  |

[0001262039-16-000051:8k_2_02:90]
Reconciliation of non-GAAP results of operations to the nearest comparable GAAP measures

[0001262039-16-000051:8k_2_02:91]
(Unaudited, in thousands, except per share amounts)

[0001262039-16-000051:8k_2_02:92]
Reconciliation of GAAP operating income to Non-GAAP operating income, operating margin, net income and diluted net income per share

[0001262039-16-000051:8k_2_02:93]
|  | Three Months Ended December 31, 2015 |  | Three Months Ended December 31, 2014 |
|  | GAAP Results |  | Adjustments |  | Non-GAAP Results |  | GAAP Results |  | Adjustments |  | Non-GAAP Results |
| Operating income | $ | 12,867 |  |  | $ | 34,712 |  | (a) | $ | 47,579 |  |  | $ | 19,916 |  |  | $ | 16,925 |  | (b) | $ | 36,841 |  |
| Operating margin | 4 | % |  |  |  | 16 | % |  | 9 | % |  |  |  | 16 | % |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | 28,087 |  |  |  |  |  |  | 16,681 |  |  |  |
| Amortization of acquired intangible assets |  |  | 1,319 |  |  |  |  |  |  | 244 |  |  |  |
| ERP-related expenses |  |  | 1,558 |  |  |  |  |  |  | — |  |  |  |
| Business acquisition-related charges |  |  | 451 |  |  |  |  |  |  | — |  |  |  |
| Inventory fair value adjustment amortization |  |  | 1,580 |  |  |  |  |  |  | — |  |  |  |
| Restructuring charges |  |  | 1,717 |  |  |  |  |  |  | — |  |  |  |
| Tax adjustment |  |  | 213 |  | (c) |  |  |  |  | 340 |  | (c) |  |
| Net income (loss) | $ | (2,534 | ) |  | $ | 34,925 |  |  | $ | 32,391 |  |  | $ | 6,813 |  |  | $ | 17,265 |  |  | $ | 24,078 |  |
| Diluted net income (loss) per share | $ | (0.01 | ) |  |  |  | $ | 0.18 |  |  | $ | 0.04 |  |  |  |  | $ | 0.14 |  |
| Shares used in diluted net income per share calculations | 171,831 |  |  |  |  | 176,657 |  |  | 170,927 |  |  |  |  | 170,927 |  |

[0001262039-16-000051:8k_2_02:94]
(a) To exclude $28.1 million of stock-based compensation, $1.3 million of amortization of acquired intangible assets, $1.6 million of ERP-related expenses, $0.5 million of business acquisition-related charges, $1.6 million of inventory fair value adjustment amortization recorded pursuant to our business acquisition, and $1.7 million of restructuring charges in the three months ended December 31, 2015.

[0001262039-16-000051:8k_2_02:95]
(b) To exclude $16.7 million of stock-based compensation and $0.2 million of amortization of acquired intangible assets in the three months ended December 31, 2014.

[0001262039-16-000051:8k_2_02:96]
(c)  Non-GAAP financial information is adjusted to achieve an overall 34% percent and 35% percent effective tax rate in 2015 and 2014, respectively, on a non-GAAP basis, which differs from the GAAP effective tax rate.

[0001262039-16-000051:8k_2_02:97]
|  | Year Ended December 31, 2015 |  | Year Ended December 31, 2014 |
|  | GAAP Results |  | Adjustments |  | Non-GAAP Results |  | GAAP Results |  | Adjustments |  | Non-GAAP Results |
| Operating income | $ | 14,877 |  |  | $ | 118,447 |  | (a) | $ | 133,324 |  |  | $ | 59,324 |  |  | $ | 62,805 |  | (b) | $ | 122,129 |  |
| Operating margin | 1 | % |  |  |  | 13 | % |  | 8 | % |  |  |  | 16 | % |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | 95,088 |  |  |  |  |  |  | 58,994 |  |  |  |
| Impairment of acquired intangible assets |  |  | 1,593 |  |  |  |  |  |  | 2,404 |  |  |  |
| Amortization of acquired intangible assets |  |  | 3,126 |  |  |  |  |  |  | 1,407 |  |  |  |
| ERP-related expenses |  |  | 5,426 |  |  |  |  |  |  | — |  |  |  |
| Business acquisition-related charges |  |  | 2,732 |  |  |  |  |  |  | — |  |  |  |
| Inventory fair value adjustment amortization |  |  | 2,882 |  |  |  |  |  |  | — |  |  |  |
| Restructuring charges |  |  | 7,600 |  |  |  |  |  |  | — |  |  |  |
| Tax adjustment |  |  | (37,036 | ) | (c) |  |  |  |  | (7,318 | ) | (c) |  |
| Net income | $ | 7,987 |  |  | $ | 81,411 |  |  | $ | 89,398 |  |  | $ | 25,343 |  |  | $ | 55,487 |  |  | $ | 80,830 |  |
| Diluted net income per share | $ | 0.05 |  |  |  |  | $ | 0.51 |  |  | $ | 0.15 |  |  |  |  | $ | 0.48 |  |
| Shares used in diluted net income per share calculations | 176,141 |  |  |  |  | 176,141 |  |  | 169,289 |  |  |  |  | 169,289 |  |

[0001262039-16-000051:8k_2_02:98]
(a) To exclude $95.1 million of stock-based compensation, $1.6 million of impairment of acquired intangible assets, $3.1 million of amortization of acquired intangible assets, $5.4 million of ERP-related expenses, $2.7 million of business acquisition-related charges, $2.9 million of inventory fair value adjustment amortization recorded pursuant to our business acquisition, and $7.6 million of restructuring charges in 2015.

[0001262039-16-000051:8k_2_02:99]
(b) To exclude $59.0 million of stock-based compensation, $2.4 million of impairment of acquired intangible assets, and $1.4 million of amortization of acquired intangible assets in 2014.

[0001262039-16-000051:8k_2_02:100]
(c)  Non-GAAP financial information is adjusted to achieve an overall 34% percent and 35% percent effective tax rate in 2015 and 2014, respectively, on a non-GAAP basis, which differs from the GAAP effective tax rate.
