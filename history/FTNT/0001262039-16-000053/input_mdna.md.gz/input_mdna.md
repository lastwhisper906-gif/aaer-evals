# FTNT MD&A — 0001262039-16-000053


## mdna

[0001262039-16-000053:mdna:1]
ITEM 7.     Management’s Discussion and Analysis of Financial Condition and Results of Operations

[0001262039-16-000053:mdna:2]
| • | continued growth and market share gains; |

[0001262039-16-000053:mdna:3]
| • | variability in sales in certain product categories from year to year and between quarters; |

[0001262039-16-000053:mdna:4]
| • | expected impact of sales of certain products; |

[0001262039-16-000053:mdna:5]
| • | the proportion of our revenue that consists of our product and service and other revenue, and the mix of billings between products and services; |

[0001262039-16-000053:mdna:6]
| • | the impact of our product innovation strategy; |

[0001262039-16-000053:mdna:7]
| • | growing our sales to enterprise, service provider and government organizations, and the impact of sales to these organizations on our long-term growth, expansion, and operating results; |

[0001262039-16-000053:mdna:8]
| • | growing our channel partner relationships, especially with enterprise resellers; |

[0001262039-16-000053:mdna:9]
| • | trends in revenue, costs of revenue, and gross margin; |

[0001262039-16-000053:mdna:10]
| • | trends in our operating expenses, including research and development expense, sales and marketing expense, general and administrative expense, and expectations regarding these expenses as a percentage of revenue; |

[0001262039-16-000053:mdna:11]
| • | continued investments in research and development; |

[0001262039-16-000053:mdna:12]
| • | continued investments in sales and marketing, and the impact of those investments; |

[0001262039-16-000053:mdna:13]
| • | expectations regarding uncertain tax benefits and our effective tax rate; |

[0001262039-16-000053:mdna:14]
| • | expectations regarding spending related to capital expenditures; |

[0001262039-16-000053:mdna:15]
| • | competition in our markets; |

[0001262039-16-000053:mdna:16]
| • | integration of acquired companies and technologies; |

[0001262039-16-000053:mdna:17]
| • | implementation of a new enterprise resource planning (“ERP”) system; |

[0001262039-16-000053:mdna:18]
| • | our intentions regarding repatriation of cash, cash equivalents and investments held by our international subsidiaries and the sufficiency of our existing cash, cash equivalents and investments to meet our cash needs for at least the next 12 months; and |

[0001262039-16-000053:mdna:19]
| • | other statements regarding our future operations, financial condition and prospects and business strategies. |

[0001262039-16-000053:mdna:20]
Business Overview

[0001262039-16-000053:mdna:21]
We provide high performance cybersecurity solutions to a wide variety of enterprises, service providers and government organizations of all sizes across the globe, including a majority of the 2015 Fortune 100. Our cybersecurity

[0001262039-16-000053:mdna:22]
34

[0001262039-16-000053:mdna:23]
solutions are fast, secure and designed to provide broad, rapid protection against dynamic security threats while simplifying the IT infrastructure of our end-customers worldwide.

[0001262039-16-000053:mdna:24]
Our core product platform is the FortiGate physical and virtual appliance, which ships with a set of broad security services, including firewall, VPN, application control, intrusion prevention, web filtering and advanced threat protection (“ATP”). These security services are enabled by FortiGuard which provides extensive threat research and a global cloud network to deliver protection services to each FortiGate appliance. FortiGate also has extensive networking capability such as switching, routing, native internet protocol version 6 and different modes of deployment. FortiManager provides central management and FortiAnalyzer provides reporting and analytics. The FortiGate platform can be extended to provide enhanced capabilities. For example, it can be used as a wireless controller for access points. An external sandbox can also be attached for local ATP analysis.

[0001262039-16-000053:mdna:25]
Customers select the functions or combination of functions that best meet their specific security requirements such as a high-speed DCFW at the network core, a NGFW at the edge or a broad UTM solution at branch sites. We derive a substantial majority of product sales from our FortiGate appliances, which range from the FortiGate-20 to -100 series, designed for small businesses, FortiGate-200 to -900 series for mid-sized enterprises, to the FortiGate-1000 to -5000 series for large enterprises and service providers. Our network security platform also includes our FortiGuard security subscription services, to which end-customers can subscribe in order to obtain access to dynamic updates to application control, anti-virus, intrusion prevention, web filtering, and anti-spam functionality. End-customers can also choose to purchase FortiCare technical support services for our products. End-customers also often use FortiManager and FortiAnalyzer products in conjunction with a FortiGate deployment to provide centralized management and analysis and reporting capabilities.

[0001262039-16-000053:mdna:26]
We complement our core FortiGate product line with other appliances and software licenses that offer additional protection from security threats to other critical areas of the enterprise, such as our secure wireless and access technologies, advanced threat protection, secure email gateway, web application firewalls, application delivery controllers, databases security product, DDoS security product, and endpoint security product for employee computers and mobile devices. Sales of these complementary products have grown in recent quarters.

[0001262039-16-000053:mdna:27]
Financial Highlights

[0001262039-16-000053:mdna:28]
| • | We recorded total revenue of $1.01 billion in 2015, an increase of 31% compared to 2014. Product revenue was $476.8 million in 2015, an increase of 32% compared to 2014. Service revenue was $532.5 million in 2015, an increase of 30% compared to 2014. |

[0001262039-16-000053:mdna:29]
| • | Cash, cash equivalents and investments were $1.16 billion as of December 31, 2015, an increase of $172.6 million, or 17%, from December 31, 2014. |

[0001262039-16-000053:mdna:30]
| • | Deferred revenue was $791.3 million as of December 31, 2015, an increase of $232.5 million, or 42%, from December 31, 2014. |

[0001262039-16-000053:mdna:31]
| • | We generated cash flows from operating activities of $282.5 million in 2015, an increase of $86.0 million, or 44%, compared to 2014. |

[0001262039-16-000053:mdna:32]
| • | In July 2015, we acquired Meru, a provider of Wi-Fi networking products and services, for total consideration of $41.8 million. In connection with the business acquisition of Meru, we initiated planned cost reduction and restructuring activities to improve our cost structure and operational efficiencies, resulting in workforce reductions, consolidation of certain real estate facilities, asset write-downs, contract terminations and other charges. Restructuring charges for the year ended December 31, 2015 were $7.6 million. |

[0001262039-16-000053:mdna:33]
| • | We repurchased 1.8 million shares of common stock under our previously-announced Share Repurchase Program for an aggregate purchase price of $60.0 million in 2015. |

[0001262039-16-000053:mdna:34]
Revenue grew in 2015 as our integrated security platform products put us in a strong competitive position in a robust security market. We continue to strengthen partnerships with enterprise resellers and gain from our prior sales investments. In addition, we continue to execute our strategy of selling to enterprise customers and landing large deals with some of these customers. Enterprise customers have vast infrastructures and we believe this will provide expansion opportunities for us in the future. Our strategy has enabled us to gain market share, win new customers, and expand within existing customer accounts, especially in the large enterprise market which is key to our long-term growth and profitability strategy. Large enterprises represent significant opportunity for cross-sell and upsell as they tend to purchase more products and services over time,

[0001262039-16-000053:mdna:35]
35

[0001262039-16-000053:mdna:36]
yielding substantial lifetime value. Aside from obtaining new customers, other levers to drive long-term growth and operating leverage include adding more functionality and value in our security subscription and support service offerings to customers.

[0001262039-16-000053:mdna:37]
In 2015, sales of high-end FortiGate products (FortiGate-1000 to -5000 series) increased due to enterprise adoption of our high-end appliances such as the FortiGate-1500D, -3700D, and -5000 series. The percentage of our FortiGate related billings from high-end products increased from 38% in 2014 to 41% in 2015, while the mid-range products decreased from 26% in 2014 to 25% in 2015 and the entry-level products decreased from 36% in 2014 to 34% in 2015.

[0001262039-16-000053:mdna:38]
In 2015, operating expenses increased by $227.6 million, or 47%, as compared to 2014. The increase was primarily driven by our accelerated pace of hiring and continued investments to expand our sales coverage, grow our marketing capabilities, develop new products and scale our customer support. We also continue to invest in research and development to strengthen our technology leadership position. We believe that continued product innovation has strengthened our technology and resulted in market share gains. In addition, we incurred costs from the integration of Meru and the implementation of restructuring activities and expenses related to business design and reengineering in preparation of an ERP system implementation. Headcount increased by 41% to 4,018 employees and contractors as of December 31, 2015, up from 2,854 as of December 31, 2014.

[0001262039-16-000053:mdna:39]
Business Model

[0001262039-16-000053:mdna:40]
Our sales strategy is based on a distribution model whereby we primarily sell our products and services directly to distributors which sell to resellers and service providers, which, in turn, sell to our end-customers. In certain cases, we sell directly to government-focused resellers, large service providers and major systems integrators, which have significant purchasing power and unique customer deployment requirements. Typically, FortiGuard security subscription services and FortiCare technical support services are purchased along with our physical and virtual appliances, most frequently as part of a bundle offering that includes hardware and services. We invoice at the time of our sale for the total price of the products and subscription and technical support services, and the invoice generally becomes payable within 30 to 90 days. We generally recognize product revenue up-front and defer revenue for the sale of new, and renewal of existing, FortiGuard security subscription and FortiCare technical support services contracts. We recognize the related service revenue over the service period, which is typically one to three years, although it can be as long as five years. Sales of new and renewal services are a source of recurring revenue and increase our deferred revenue balance, which contributes significantly to our positive cash flow from operations.

[0001262039-16-000053:mdna:41]
Key Metrics

[0001262039-16-000053:mdna:42]
We monitor a number of financial and operating metrics, including the key financial metrics set forth below, in order to help us evaluate growth trends, establish budgets, measure the effectiveness of our sales and marketing efforts, and assess operational efficiencies. The following table summarizes revenue, deferred revenue, billings (non-GAAP), cash, cash equivalents and investments, net cash provided by operating activities, and free cash flow (non-GAAP). We discuss revenue below under “—Components of Operating Results,” and we discuss our cash, cash equivalents, and investments, and net cash provided by operating activities below under “—Liquidity and Capital Resources.” Deferred revenue, billings (non-GAAP), and free cash flow (non-GAAP) are discussed immediately below the following table.

[0001262039-16-000053:mdna:43]
|  | Year Ended or As of December 31, |
|  | 2015 |  | 2014 |  | 2013 |
|  | (in thousands) |
| Revenue | $ | 1,009,268 |  |  | $ | 770,364 |  |  | $ | 615,297 |  |
| Deferred revenue | $ | 791,303 |  |  | $ | 558,757 |  |  | $ | 432,628 |  |
| Billings (non-GAAP) | $ | 1,232,014 |  |  | $ | 896,493 |  |  | $ | 684,190 |  |
| Cash, cash equivalents and investments | $ | 1,164,310 |  |  | $ | 991,744 |  |  | $ | 843,045 |  |
| Net cash provided by operating activities | $ | 282,547 |  |  | $ | 196,582 |  |  | $ | 147,384 |  |
| Free cash flow (non-GAAP) | $ | 245,189 |  |  | $ | 164,385 |  |  | $ | 133,507 |  |

[0001262039-16-000053:mdna:44]
Deferred revenue. Our deferred revenue consists of amounts that have been invoiced but that have not yet been recognized as revenue. Deferred revenue is amortized as revenue ratably over the contractual service period.  The majority of our deferred revenue balance consists of the unrecognized portion of service revenue from FortiGuard security subscription and FortiCare technical support service contracts. We monitor our deferred revenue balance because it represents a significant

[0001262039-16-000053:mdna:45]
36

[0001262039-16-000053:mdna:46]
portion of revenue to be recognized in future periods. Total deferred revenue as of December 31, 2015 increased by $232.5 million or 42% compared to a year ago. Total deferred revenue as of December 31, 2015 of $791.3 million included deferred revenue relating to Meru of $14.5 million, or 2% of total deferred revenue.  Excluding Meru’s deferred revenue, our deferred revenue as of December 31, 2015 was $776.8 million, an increase of $218.0 million or 39% compared to a year ago.

[0001262039-16-000053:mdna:47]
Billings (Non-GAAP).We define billings as revenue recognized in accordance with GAAP plus the change in deferred revenue from the beginning to the end of the period less any deferred revenue balances acquired from business combination(s) during the period. We consider billings to be a useful metric for management and investors because billings drives deferred revenue, which is an important indicator of the health and viability of our business. There are a number of limitations related to the use of billings instead of GAAP revenue. First, billings include amounts that have not yet been recognized as revenue. Second, we may calculate billings in a manner that is different from peer companies that report similar financial measures. Management compensates for these limitations by providing specific information regarding GAAP revenue and evaluating billings together with GAAP revenue.

[0001262039-16-000053:mdna:48]
Total billings for the year ended December 31, 2015 increased by $335.5 million, or 37%, compared to the year ended December 31, 2014. Total billings for the year ended December 31, 2015 of $1.23 billion included Meru’s billings from July 8, 2015 to December 31, 2015 of $32.8 million, or 3% of total billings.  Excluding Meru, our billings for the year ended December 31, 2015 were $1.20 billion, an increase of 34% compared to the year ended December 31, 2014.

[0001262039-16-000053:mdna:49]
A reconciliation of billings to revenue, the most directly comparable financial measure calculated and presented in accordance with GAAP, is provided below:

[0001262039-16-000053:mdna:50]
Reconciliation of total consolidated GAAP revenue to billings

[0001262039-16-000053:mdna:51]
|  | Year Ended December 31, |
| 2015 |  | 2014 |  | 2013 |
| (in thousands) |
| Billings: |  |  |  |  |  |
| Revenue | $ | 1,009,268 |  |  | $ | 770,364 |  |  | $ | 615,297 |  |
| Add increase in deferred revenue | 232,546 |  |  | 126,129 |  |  | 69,443 |  |
| Less deferred revenue balance acquired in business combination | (9,800 | ) |  | — |  |  | (550 | ) |
| Total billings (Non-GAAP) | $ | 1,232,014 |  |  | $ | 896,493 |  |  | $ | 684,190 |  |

[0001262039-16-000053:mdna:52]
Reconciliation of Meru’s GAAP revenue to billings

[0001262039-16-000053:mdna:53]
|  | For the period |
| July 8, 2015 through December 31, 2015 |
| (in thousands) |
| Billings: |  |
| Revenue | $ | 28,050 |  |
| Add increase in deferred revenue | 4,706 |  |
| Total billings (Non-GAAP) | $ | 32,756 |  |

[0001262039-16-000053:mdna:54]
Free cash flow (Non-GAAP). We define free cash flow as net cash provided by operating activities minus capital expenditures such as purchases of property and equipment. We consider free cash flow to be a liquidity measure that provides useful information to management and investors about the amount of cash generated by the business that, after the acquisition of property and equipment, can be used for strategic opportunities, including investing in our business, making strategic acquisitions, repurchasing outstanding common stock and strengthening the balance sheet. Analysis of free cash flow facilitates management’s comparison of our operating results to those of our peer companies. A limitation of using free cash flow rather than the GAAP measure of net cash provided by operating activities as a means for evaluating liquidity is that free cash flow does not represent the total increase or decrease in the cash, cash equivalents and investments balance for the period because it excludes cash provided by or used for other investing and financing activities. Management accounts for this limitation by providing information about our capital expenditures and other investing and financing activities on the face of the cash flow statement and under “—Liquidity and Capital Resources.”  A reconciliation of free cash flow to net cash provided by operating

[0001262039-16-000053:mdna:55]
activities, the most directly comparable financial measure calculated and presented in accordance with GAAP, is provided below:

[0001262039-16-000053:mdna:56]
|  | Year Ended December 31, |
| 2015 |  | 2014 |  | 2013 |
| (in thousands) |
| Free Cash Flow: |  |  |  |  |  |
| Net cash provided by operating activities | $ | 282,547 |  |  | $ | 196,582 |  |  | $ | 147,384 |  |
| Less purchases of property and equipment | (37,358 | ) |  | (32,197 | ) |  | (13,877 | ) |
| Free cash flow (Non-GAAP) | $ | 245,189 |  |  | $ | 164,385 |  |  | $ | 133,507 |  |

[0001262039-16-000053:mdna:57]
Components of Operating Results

[0001262039-16-000053:mdna:58]
Revenue

[0001262039-16-000053:mdna:59]
We generate the majority of our revenue from sales of our products and amortization of amounts included in deferred revenue related to previous sales of FortiGuard security subscription and FortiCare technical support services. Revenue is recognized when persuasive evidence of an arrangement exists, delivery has occurred or services have been rendered, the sales price is fixed or determinable and collectability is reasonably assured.

[0001262039-16-000053:mdna:60]
Our total revenue is comprised of the following:

[0001262039-16-000053:mdna:61]
| • | Product revenue. Product revenue is generated from sales of our appliances. The substantial majority of our product revenue has been generated by our FortiGate line of appliances, and we do not expect this to change in the foreseeable future. Product revenue also includes revenue derived from sales of appliances, as well as from sales of our FortiClient and VDOM software. As a percentage of total revenue, we expect that our product revenue may vary from quarter-to-quarter based on seasonal and cyclical factors, as discussed below under “—Quarterly Results of Operations” but will remain at a relatively comparable level in 2016. |

[0001262039-16-000053:mdna:62]
| • | Service revenue. Service revenue is generated primarily from FortiGuard security subscription services related to application control, antivirus, intrusion prevention, web filtering, anti-spam, ATP and vulnerability management updates, and from FortiCare technical support services for software updates, maintenance releases and patches, Internet access to technical content, telephone and Internet access to technical support personnel and hardware support. We recognize revenue from FortiGuard security subscription and FortiCare technical support services over the contractual service period. Our typical contractual support and subscription term is one to three years. We also generate a small portion of our revenue from professional services and training services, and we recognize this revenue as the services are provided. As a percentage of total revenue, we expect our service revenue to remain at a relatively comparable level in 2016. Our service revenue growth rate depends significantly on the growth of our customer base, the expansion and introduction of new service offerings, and the renewal of service contracts by our customers. |

[0001262039-16-000053:mdna:63]
Our total cost of revenue is comprised of the following:

[0001262039-16-000053:mdna:64]
| • | Cost of product revenue. A substantial majority of the cost of product revenue consists of third-party contract manufacturers' costs, as well as other costs of materials used in production. Our cost of product revenue also includes supplies, shipping costs, personnel costs associated with logistics and quality control, facility-related costs, excess and obsolete inventory costs, warranty costs, and amortization and impairment of intangible assets, if applicable. Personnel costs include salaries, benefits and bonuses, as well as stock-based compensation. |

[0001262039-16-000053:mdna:65]
| • | Cost of service revenue. Cost of service revenue is primarily comprised of salaries, benefits and bonuses, as well as stock-based compensation. Cost of service revenue also includes supplies and facility-related costs. |

[0001262039-16-000053:mdna:66]
Gross margin. Gross profit as a percentage of revenue, or gross margin, has been and will continue to be affected by a variety of factors, including the average sales price of our products, any excess inventory write-offs, product costs, the mix of products sold and the mix of revenue between products and services. In 2015, service revenue had a positive effect on our total

[0001262039-16-000053:mdna:67]
gross margin given the higher service gross margins compared to product gross margins. During 2015, service gross margins increased compared to 2014. We believe our overall gross margin will remain at a relatively comparable level in 2016.

[0001262039-16-000053:mdna:68]
Operating expenses. Our operating expenses consist of research and development, sales and marketing, general and administrative expenses, and restructuring charges. Personnel costs are the most significant component of operating expenses and consist primarily of salaries, benefits, bonuses, stock-based compensation, and sales commissions, as applicable. We expect personnel costs to continue to increase in absolute dollars as we expand our workforce.

[0001262039-16-000053:mdna:69]
| • | Research and development. Research and development expense consists primarily of personnel costs. Additional research and development expenses include ASIC and system prototypes and certification-related expenses, depreciation of capital equipment and facility-related expenses. The majority of our research and development is focused on both software development and the ongoing development of our hardware platform. We record all research and development expenses as incurred. Our research and development teams are primarily located in Canada and the United States. |

[0001262039-16-000053:mdna:70]
| • | Sales and marketing. Sales and marketing expense is the largest component of our operating expenses and primarily consists of personnel costs. Additional sales and marketing expenses include promotional lead generation and other marketing expenses, travel, depreciation of capital equipment and facility-related expenses. We intend to hire additional personnel focused on sales and marketing and expand our sales and marketing efforts worldwide in order to capture additional market share in the high-return enterprise market, where customers tend to provide a higher lifetime value. |

[0001262039-16-000053:mdna:71]
| • | General and administrative. General and administrative expense consists of personnel costs, as well as professional fees, depreciation of capital equipment and software, facility-related expenses, charges associated with the ERP system implementation, and in 2015, business acquisition costs relating to Meru. General and administrative personnel include our executive, finance, human resources, information technology and legal organizations. Our professional fees principally consist of outside legal, auditing, accounting, tax, information technology and other consulting costs. |

[0001262039-16-000053:mdna:72]
| • | Restructuring charges. Restructuring charges relate to the alignment activities in connection with the Meru acquisition to reduce our cost structure and improve operational efficiencies. We initiated planned cost reduction and restructuring activities to improve our cost structure and operational efficiencies, resulting in workforce reductions, contract terminations and other charges. |

[0001262039-16-000053:mdna:73]
Interest income. Interest income consists of income earned on our cash, cash equivalents and investments. We have historically invested our cash in money market funds, commercial paper, corporate debt securities, municipal bonds, certificates of deposit and term deposits, and U.S. government and agency securities.

[0001262039-16-000053:mdna:74]
Other expense, net. Other expense, net consists primarily of foreign exchange and related hedging gains and losses. Foreign exchange gains and losses relate to foreign currency exchange re-measurement. The hedging gains and losses are related to our settled balance sheet hedges.

[0001262039-16-000053:mdna:75]
Provision for income taxes. We are subject to tax in the United States as well as other tax jurisdictions or countries in which we conduct business. Earnings from our non-U.S. activities are subject to income taxes in the local country which are generally lower than U.S. tax rates, and may be subject to U.S. income taxes. Our effective tax rate differs from the U.S. statutory rate primarily due to foreign income subject to different tax rates than the U.S., research and development tax credits, withholding taxes, nondeductible stock-based compensation expense and adjustments related to our intercompany transfer pricing.

[0001262039-16-000053:mdna:76]
The income tax provision for 2015 was comprised of domestic income taxes, foreign income taxes and foreign withholding taxes. Our effective tax rate approximates the U.S. federal statutory tax rates plus the impact of state taxes, research and development tax credits, foreign withholding tax, nondeductible stock-based compensation expense, and foreign income subject to lower tax rates than income earned in the United States.

[0001262039-16-000053:mdna:77]
Critical Accounting Policies and Estimates

[0001262039-16-000053:mdna:78]
Our discussion and analysis of our financial condition and results of operations are based upon our financial statements, which have been prepared in accordance with GAAP. These principles require us to make estimates and judgments that affect the reported amounts of assets, liabilities, revenue, cost of revenue and expenses, and related disclosures. We base

[0001262039-16-000053:mdna:79]
our estimates on historical experience and on various other assumptions that we believe to be reasonable under the circumstances. To the extent that there are material differences between these estimates and our actual results, our future financial statements will be affected.

[0001262039-16-000053:mdna:80]
We believe that, of the significant accounting policies described in Note 1 to our consolidated financial statements included in Part II, Item 8 of this Annual Report on Form 10-K, the following accounting policies involve a greater degree of judgment and complexity. Accordingly, we believe these are the most critical to fully understand and evaluate our financial condition and results of operations.

[0001262039-16-000053:mdna:81]
Revenue Recognition

[0001262039-16-000053:mdna:82]
We derive the majority of our revenue from sales of our hardware, software, FortiGuard security subscription and FortiCare technical support services, and other services through our channel partners and a direct sales force.

[0001262039-16-000053:mdna:83]
Revenue is recognized when all of the following criteria have been met:

[0001262039-16-000053:mdna:84]
| • | Persuasive evidence of an arrangement exists. Binding contracts or purchase orders are generally used to determine the existence of an arrangement. |

[0001262039-16-000053:mdna:85]
| • | Delivery has occurred or services have been rendered. Delivery occurs when we fulfill an order and title and risk of loss has been transferred. Service revenue is deferred and recognized ratably over the contractual service period, which is typically from one to three years and is generally recognized upon delivery or completion of service. |

[0001262039-16-000053:mdna:86]
| • | Sales price is fixed or determinable. We assess whether the sales price is fixed or determinable based on the payment terms associated with the transaction and when the sales price is deemed final. |

[0001262039-16-000053:mdna:87]
| • | Collectability is reasonably assured. We assess collectability based primarily on creditworthiness as determined by credit checks, analysis, and payment history. |

[0001262039-16-000053:mdna:88]
We recognize product revenue for sales to distributors that have no general right of return and direct sales to end-customers upon shipment, based on general revenue recognition accounting guidance once all other revenue recognition criteria have been met. Certain distributors are granted stock rotation rights, limited rights of return and rebates for sales of our products. The arrangement fee for this group of distributors is not typically fixed or determinable when products are shipped and revenue is therefore deferred and recognized upon sell-through. For sales that include end-customer acceptance criteria, revenue is recognized upon acceptance.

[0001262039-16-000053:mdna:89]
Substantially all of our products have been sold in combination with services, which consist of security subscriptions and technical support services. Security services provide access to our antivirus, intrusion prevention, web filtering, and anti-spam functionality. Support services include rights to unspecified software upgrades, maintenance releases and patches, telephone and Internet access to technical support personnel, and hardware support.  We recognize revenue from these services ratably over the contractual service period.  Revenue related to subsequent renewals of these services is recognized over the term of the renewal agreement.

[0001262039-16-000053:mdna:90]
We reduce revenue for estimates of sales returns and allowances and record reductions to revenue for rebates and estimated commitments related to price protection and other customer incentive programs. Additionally, in limited circumstances, we may permit end-customers, distributors and resellers to return our products, subject to varying limitations, for a refund within a reasonably short period from the date of purchase. We estimate and record reserves for sales incentives and sales returns based on historical experience.

[0001262039-16-000053:mdna:91]
Our sales arrangements typically contain multiple elements, such as hardware, security subscription, technical support services and other services. The majority of our hardware appliance products contain our operating system software that together function to deliver the essential functionality of the product. Our products and services generally qualify as separate units of accounting. We allocate revenue to each unit of accounting based on an estimated selling price using vendor-specific objective evidence (“VSOE”) of selling price, if it exists, or third-party evidence (“TPE”) of selling price. If neither VSOE nor TPE of selling price exist for a deliverable, we use our best estimate of selling price (“BESP”) for that deliverable. Revenue allocated to each element is then recognized when the basic revenue recognition criteria are met for each element.

[0001262039-16-000053:mdna:92]
40

[0001262039-16-000053:mdna:93]
For our hardware appliances, we use BESP as our selling price estimate. For our support and other services, we generally use VSOE as our selling price estimate. We determine VSOE of fair value for elements of an arrangement based on the historical pricing and discounting practices for those services when sold separately. In establishing VSOE, we require that a substantial majority of the selling prices for a service fall within a reasonably narrow pricing range, generally evidenced by a substantial majority of such historical stand-alone transactions falling within a reasonably narrow range as a percentage of list price. When we are unable to establish a selling price using VSOE for our support and other services, we use BESP in our allocation of arrangement consideration. We determine BESP for a product or service by considering multiple historical factors including, but not limited to, cost of products, gross margin objectives, pricing practices, geographies, customer classes and distribution channels that fall within a reasonably narrow range as a percentage of list price.

[0001262039-16-000053:mdna:94]
For multiple-element arrangements where software deliverables are included, revenue is allocated to the non-software deliverables and to the software deliverables as a group using the relative estimated selling prices of each of the deliverables in the arrangement based on the estimated selling price hierarchy. The amount allocated to the software deliverables is then allocated to each software deliverable using the residual method when VSOE of fair value exists. If evidence of VSOE of fair value of one or more undelivered elements does not exist, all software allocated revenue is deferred and recognized when delivery of those elements occurs or when fair value can be established. When the undelivered element for which we do not have VSOE of fair value is support, revenue for the entire arrangement is recognized ratably over the support period. The same residual method and VSOE of fair value principles apply for our multiple element arrangements that contain only software elements.

[0001262039-16-000053:mdna:95]
Stock-Based Compensation

[0001262039-16-000053:mdna:96]
Employee Stock Options.  We estimate the fair value of employee stock options awarded to our employees using the Black-Scholes-Merton (“Black-Scholes”) pricing model. For all employee stock options, we recognize expense, net of estimated forfeitures, over the requisite service period using the straight-line method. Our option pricing model requires the input of subjective assumptions, including the expected stock price volatility, expected term, risk-free interest rates, expected dividend yield of our common stock and forfeiture rate. The assumptions used in our option pricing model represent management’s best estimates. These estimates involve inherent uncertainties and the application of management’s judgment. A 10% change in any of these assumptions would not have a significant impact on our stock-based compensation expense.

[0001262039-16-000053:mdna:97]
Employee Stock Purchase Plan. We estimate the fair value of the rights to acquire stock under our employee stock purchase plan (“ESPP”) using the Black-Scholes pricing model and we recognize expense over the requisite service period using the straight-line method. The pricing model requires the input of the fair value of our common stock and subjective assumptions, including the expected term of the award, the expected volatility of the price of our common stock, risk-free interest rates and the expected dividend yield of our common stock. Our ESPP provides for consecutive six-month offering periods and we use our own historical volatility data in the valuation of ESPP shares. A 10% change in any of these assumptions would not have a significant impact on our stock-based compensation expense.

[0001262039-16-000053:mdna:98]
Restricted Stock Units. We account for the fair value of restricted stock units (“RSUs”) awarded to employees and members of our board of directors using the closing market price of our common stock on the date of grant. RSUs are payable in shares of our common stock as the periodic vesting requirements are satisfied. RSUs generally vest over a four-year period if the employees, contractors, or directors, as applicable, remain with us for the duration of the vesting period. For all RSUs, we recognize expense, net of estimated forfeitures, over the requisite service period using the straight-line method.

[0001262039-16-000053:mdna:99]
Performance Stock Units. We grant performance stock units (“PSUs”) to certain of our executive officers. RSUs granted to executive officers contain both service-based and market-based vesting conditions. PSUs vest over a specified service period upon the satisfaction of certain market-based vesting conditions, and settle into shares of our common stock upon vesting over a two- or three-year period.  The fair value of a PSU is calculated using the Monte Carlo simulation model on the date of grant and is based on the market price of our common stock on the date of grant modified to reflect the impact of the market-based vesting condition, including the estimated payout level based on that condition. We do not adjust compensation cost for subsequent changes in the expected outcome of the market-based vesting conditions.

[0001262039-16-000053:mdna:100]
Valuation of Inventory

[0001262039-16-000053:mdna:101]
Inventory is recorded at the lower of cost (using the first-in, first-out method) or market, after we give appropriate consideration to obsolescence and inventory in excess of anticipated future demand. In assessing the ultimate recoverability of inventory, we make estimates regarding future customer demand, the timing of new product introductions, economic trends and market conditions. If the actual product demand is significantly lower than forecasted, we could be required to record

[0001262039-16-000053:mdna:102]
41

[0001262039-16-000053:mdna:103]
additional inventory write-downs which would be charged to cost of product revenue. Any write-downs could have an adverse impact on our gross margins and profitability.

[0001262039-16-000053:mdna:104]
Business Combinations

[0001262039-16-000053:mdna:105]
We include the results of operations of the businesses that we acquire as of the respective dates of acquisition. We allocate the fair value of the purchase price of our business acquisitions to the tangible assets acquired, liabilities assumed, and intangible assets acquired, based on their estimated fair values. The excess of the purchase price over the fair values of these identifiable assets and liabilities is recorded as goodwill. Additional information existing as of the acquisition date, but unknown to us at that time, may become known during the remainder of the measurement period, not to exceed 12 months from the acquisition date, which may result in changes to the amounts and allocations recorded.

[0001262039-16-000053:mdna:106]
Restructuring Charges

[0001262039-16-000053:mdna:107]
We recognize liability for exit and disposal activities when the liability is incurred. Our restructuring charges consist of severance and other one-time benefits, contract terminations and other charges. Liabilities for costs associated with a restructuring activity are measured at fair value and are recognized when the liability is incurred. One-time termination benefits are expensed at the date we notify the employee, unless the employee must provide future service, in which case the benefits are expensed ratably over the future service period. A liability for contract-termination costs represents a liability for costs to terminate a contract before the end of its term and is recognized at fair value when we terminate the contract in accordance with the contract terms, which is usually done by giving written notice to the counterparty within the notification period specified by the contract or by otherwise negotiating a termination with the counterparty. A liability for costs that will continue to be incurred under a contract for its remaining term without economic benefit to the entity is recognized at the cease-use date. Costs to terminate a lease before the end of its term are recognized when the property is vacated. Other costs primarily consist of asset write-offs, which are expensed when incurred.

[0001262039-16-000053:mdna:108]
We continually evaluate the adequacy of the remaining liabilities under our restructuring initiatives. Although we believe that these estimates accurately reflect the costs of our restructuring plan, actual results may differ and thereby require us to record an additional provision or reverse a portion of such a provision.

[0001262039-16-000053:mdna:109]
Accounting for Income Taxes

[0001262039-16-000053:mdna:110]
We record income taxes using the asset and liability method, which requires the recognition of deferred tax assets and liabilities for the expected future tax consequences of events that have been recognized in our financial statements or tax returns. In addition, deferred tax assets are recorded for the future benefit of utilizing net operating losses and research and development credit carryforwards. Deferred tax assets and liabilities are measured using the currently enacted tax rates that apply to taxable income in effect for the years in which those tax assets and liabilities are expected to be realized or settled. Valuation allowances are provided when necessary to reduce deferred tax assets to the amount expected to be realized.

[0001262039-16-000053:mdna:111]
We recognize tax benefits from an uncertain tax position only if it is more likely than not, based on the technical merits of the position that the tax position will be sustained on examination by the taxing authorities. The tax benefits recognized in the financial statements from such positions are then measured based on the largest benefit that has a greater than 50% likelihood of being realized upon ultimate settlement.

[0001262039-16-000053:mdna:112]
As part of the process of preparing our consolidated financial statements, we are required to estimate our taxes in each of the jurisdictions in which we operate. We estimate actual current tax exposure together with assessing temporary differences resulting from differing treatment of items, such as accruals and allowances not currently deductible for tax purposes. These differences result in deferred tax assets, which are included in our consolidated balance sheets. In general, deferred tax assets represent future tax benefits to be received when certain expenses previously recognized in our consolidated statements of operations become deductible expenses under applicable income tax laws, or loss or credit carryforwards are utilized.

[0001262039-16-000053:mdna:113]
In assessing the realizability of deferred tax assets, management considers whether it is more likely than not that some portion or all of the deferred tax assets will be realized. The ultimate realization of deferred tax assets is dependent upon the generation of future taxable income during the periods in which those temporary differences become deductible. We continue to assess the need for a valuation allowance on the deferred tax assets by evaluating both positive and negative evidence that may exist. Any adjustment to the net deferred tax asset valuation allowance would be recorded in the consolidated statements of operations for the period that the adjustment is determined to be required.

[0001262039-16-000053:mdna:114]
42

[0001262039-16-000053:mdna:115]
We make estimates and judgments about our future taxable income that are based on assumptions that are consistent with our plans and estimates. Should the actual amounts differ from our estimates, the amount of our tax expense and liabilities could be materially impacted.

[0001262039-16-000053:mdna:116]
43

[0001262039-16-000053:mdna:117]
Results of Operations

[0001262039-16-000053:mdna:118]
The following tables set forth our results of operations for the periods presented and as a percentage of our total revenue for those periods. The period-to-period comparison of financial results is not necessarily indicative of financial results to be achieved in future periods.

[0001262039-16-000053:mdna:119]
|  | Year Ended December 31, |
|  | 2015 |  | 2014 |  | 2013 |
|  | (in thousands) |
| Consolidated Statement of Operations Data: |  |  |  |  |  |
| Revenue: |  |  |  |  |  |
| Product | $ | 476,782 |  |  | $ | 360,558 |  |  | $ | 278,046 |  |
| Service | 532,486 |  |  | 409,806 |  |  | 337,251 |  |
| Total revenue | 1,009,268 |  |  | 770,364 |  |  | 615,297 |  |
| Cost of revenue: |  |  |  |  |  |
| Product | 190,398 |  |  | 151,300 |  |  | 114,611 |  |
| Service | 96,379 |  |  | 79,709 |  |  | 66,032 |  |
| Total cost of revenue | 286,777 |  |  | 231,009 |  |  | 180,643 |  |
| Gross profit: |  |  |  |  |  |
| Product | 286,384 |  |  | 209,258 |  |  | 163,435 |  |
| Service | 436,107 |  |  | 330,097 |  |  | 271,219 |  |
| Total gross profit | 722,491 |  |  | 539,355 |  |  | 434,654 |  |
| Operating expenses: |  |  |  |  |  |
| Research and development | 158,129 |  |  | 122,880 |  |  | 102,660 |  |
| Sales and marketing | 470,371 |  |  | 315,804 |  |  | 224,991 |  |
| General and administrative | 71,514 |  |  | 41,347 |  |  | 34,913 |  |
| Restructuring charges | 7,600 |  |  | — |  |  | — |  |
| Total operating expenses | 707,614 |  |  | 480,031 |  |  | 362,564 |  |
| Operating income | 14,877 |  |  | 59,324 |  |  | 72,090 |  |
| Interest income | 5,295 |  |  | 5,393 |  |  | 5,306 |  |
| Other expense—net | (3,167 | ) |  | (3,168 | ) |  | (1,455 | ) |
| Income before income taxes | 17,005 |  |  | 61,549 |  |  | 75,941 |  |
| Provision for income taxes | 9,018 |  |  | 36,206 |  |  | 31,668 |  |
| Net income | $ | 7,987 |  |  | $ | 25,343 |  |  | $ | 44,273 |  |

[0001262039-16-000053:mdna:120]
44

[0001262039-16-000053:mdna:121]
|  | Year Ended December 31, |
| 2015 |  | 2014 |  | 2013 |
| (as percentage of total revenue) |
| Revenue: |  |  |  |  |  |
| Product | 47 | % |  | 47 | % |  | 45 | % |
| Service | 53 |  |  | 53 |  |  | 55 |  |
| Total revenue | 100 |  |  | 100 |  |  | 100 |  |
| Cost of revenue: |  |  |  |  |  |
| Product | 19 |  |  | 20 |  |  | 19 |  |
| Service | 10 |  |  | 10 |  |  | 11 |  |
| Total cost of revenue | 28 |  |  | 30 |  |  | 29 |  |
| Gross profit: |  |  |  |  |  |
| Product | 60 |  |  | 58 |  |  | 59 |  |
| Service | 82 |  |  | 81 |  |  | 80 |  |
| Total gross profit | 72 |  |  | 70 |  |  | 71 |  |
| Operating expenses: |  |  |  |  |  |
| Research and development | 16 |  |  | 16 |  |  | 17 |  |
| Sales and marketing | 47 |  |  | 41 |  |  | 36 |  |
| General and administrative | 7 |  |  | 5 |  |  | 6 |  |
| Restructuring charges | 1 |  |  | — |  |  | — |  |
| Total operating expenses | 70 |  |  | 62 |  |  | 59 |  |
| Operating income | 1 |  |  | 8 |  |  | 12 |  |
| Interest income | 1 |  |  | 1 |  |  | — |  |
| Other expense—net | — |  |  | — |  |  | — |  |
| Income before income taxes | 2 |  |  | 8 |  |  | 12 |  |
| Provision for income taxes | 1 |  |  | 5 |  |  | 5 |  |
| Net income | 1 | % |  | 3 | % |  | 7 | % |

[0001262039-16-000053:mdna:122]
2015 and 2014

[0001262039-16-000053:mdna:123]
Revenue

[0001262039-16-000053:mdna:124]
|  | Year Ended December 31, |  |  |  |  |
| 2015 |  | 2014 |  |  |  |  |
| Amount |  | % ofRevenue |  | Amount |  | % ofRevenue |  | Change |  | % Change |
| (in thousands, except percentages) |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 476,782 |  |  | 47 | % |  | $ | 360,558 |  |  | 47 | % |  | $ | 116,224 |  |  | 32 | % |
| Service | 532,486 |  |  | 53 |  |  | 409,806 |  |  | 53 |  |  | 122,680 |  |  | 30 |  |
| Total revenue | $ | 1,009,268 |  |  | 100 | % |  | $ | 770,364 |  |  | 100 | % |  | $ | 238,904 |  |  | 31 | % |
| Revenue by geography: |  |  |  |  |  |  |  |  |  |  |  |
| Americas | $ | 435,282 |  |  | 43 | % |  | $ | 324,659 |  |  | 42 | % |  | $ | 110,623 |  |  | 34 | % |
| Europe, Middle East and Africa (“EMEA”) | 366,018 |  |  | 36 |  |  | 270,537 |  |  | 35 |  |  | 95,481 |  |  | 35 |  |
| Asia Pacific (“APAC”) | 207,968 |  |  | 21 |  |  | 175,168 |  |  | 23 |  |  | 32,800 |  |  | 19 |  |
| Total revenue | $ | 1,009,268 |  |  | 100 | % |  | $ | 770,364 |  |  | 100 | % |  | $ | 238,904 |  |  | 31 | % |

[0001262039-16-000053:mdna:125]
Total revenue increased by $238.9 million, or 31%, in 2015 compared to 2014. Total revenue in 2015 of $1.01 billion included Meru’s revenue from July 8, 2015 to December 31, 2015 of $28.1 million, or 3% of total revenue.  Excluding Meru’s revenue, our revenue was $981.2 million, an increase of 27% compared to the same period last year. We experienced continued

[0001262039-16-000053:mdna:126]
45

[0001262039-16-000053:mdna:127]
global diversification of revenue in 2015. The Americas region contributed the largest portion of our revenue growth on an absolute dollar basis and all three regions showed growth on a percentage basis. Product revenue increased by $116.2 million, or 32%, in 2015 compared to 2014. Product revenue in 2015 included revenue from Meru of $22.2 million. The increase in product revenue was primarily driven by greater sales volume in our FortiGate product family across all product categories and in particular for our high-end products for large enterprise customers. Service revenue increased by $122.7 million, or 30%, in 2015 compared to 2014. The increase in service revenue was primarily due to the recognition of revenue from our growing deferred revenue balance consisting of FortiGuard security subscription and FortiCare technical support contracts sold to a larger customer base as well as the renewals of similar contracts sold in earlier periods. Service revenue in 2015 included revenue from Meru of $5.8 million.

[0001262039-16-000053:mdna:128]
Cost of revenue and gross margin

[0001262039-16-000053:mdna:129]
|  | Year Ended December 31, |  |  |  |  |
| 2015 |  | 2014 |  | Change |  | % Change |
| (in thousands, except percentages) |
| Cost of revenue: |  |  |  |  |  |  |  |
| Product | $ | 190,398 |  |  | $ | 151,300 |  |  | $ | 39,098 |  |  | 26 | % |
| Service | 96,379 |  |  | 79,709 |  |  | 16,670 |  |  | 21 |  |
| Total cost of revenue | $ | 286,777 |  |  | $ | 231,009 |  |  | $ | 55,768 |  |  | 24 | % |
| Gross margin: |  |  |  |  |  |  |  |
| Product | 60.1 | % |  | 58.0 | % |  | 2.1 | % |  |  |
| Service | 81.9 |  |  | 80.5 |  |  | 1.4 |  |  |  |
| Total gross margin | 71.6 | % |  | 70.0 | % |  | 1.6 | % |  |  |

[0001262039-16-000053:mdna:130]
Total gross margin increased by 1.6 percentage points in 2015 compared to 2014, as both product and service gross margins increased. Product gross margin increased by 2.1 percentage points in 2015 compared to 2014 primarily due to a greater mix of high-end FortiGate product sales compared to the same period last year, such as our FortiGate-5000 series. In addition, product gross margin was positively impacted by higher sales of software products such as certain of our virtualized security solutions, as well as inventory management efficiencies.

[0001262039-16-000053:mdna:131]
Service gross margin increased during 2015 as compared to 2014 as we scaled efficiencies resulting from our ability to add and charge for more functionality and value to our FortiGuard security subscription and FortiCare technical support offerings, which yielded more value to our customers and which translated into improved service margins. Cost of service revenue increased by $16.7 million primarily due to an $11.6 million increase in personnel costs related to headcount increases.

[0001262039-16-000053:mdna:132]
Operating expenses

[0001262039-16-000053:mdna:133]
|  | Year Ended December 31, |  | Change |  | % Change |
| 2015 |  | 2014 |  |
| Amount |  | % ofRevenue |  | Amount |  | % ofRevenue |  |
| (in thousands, except percentages) |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | $ | 158,129 |  |  | 16 | % |  | $ | 122,880 |  |  | 16 | % |  | $ | 35,249 |  |  | 29 | % |
| Sales and marketing | 470,371 |  |  | 47 |  |  | 315,804 |  |  | 41 |  |  | 154,567 |  |  | 49 |  |
| General and administrative | 71,514 |  |  | 7 |  |  | 41,347 |  |  | 5 |  |  | 30,167 |  |  | 73 |  |
| Restructuring charges | 7,600 |  |  | 1 |  |  | — |  |  | — |  |  | 7,600 |  |  | 100 |  |
| Total operating expenses | $ | 707,614 |  |  | 70 | % |  | $ | 480,031 |  |  | 62 | % |  | $ | 227,583 |  |  | 47 | % |

[0001262039-16-000053:mdna:134]
Research and development

[0001262039-16-000053:mdna:135]
Research and development expense increased by $35.2 million, or 29%, in 2015 compared to 2014 primarily due to an increase of $25.8 million in personnel costs as a result of increased headcount to support the development of new products and continued enhancements of our existing products. Depreciation and other occupancy-related costs increased by $3.6 million. In

[0001262039-16-000053:mdna:136]
addition, during 2014, we had a reversal of $3.0 million related to a previously recorded liability for estimated contingent consideration. We intend to continue to invest in our research and development organization and integrate personnel from our acquisition of Meru, but expect research and development expense as a percentage of total revenue to remain at a relatively comparable level in 2016.

[0001262039-16-000053:mdna:137]
Sales and marketing

[0001262039-16-000053:mdna:138]
Sales and marketing expense increased by $154.6 million, or 49%, in 2015 compared to 2014, primarily due to an increase of $108.0 million in personnel costs as we continued to increase our sales and marketing headcount. Marketing-related expenses increased by $16.9 million as we invested significantly in marketing investments to drive broader market awareness, create a global marketing engine, build broad market lead generation and nurture programs and accelerate pipeline. In addition, we incurred increases in travel expenses of $9.1 million, and depreciation and occupancy-related costs of $9.3 million. As a percentage of total revenue, sales and marketing expense increased as we accelerated the investment in our sales force and marketing programs to drive future growth. We intend to continue to make investments in our sales resources and infrastructure and marketing strategy, which are critical to support growth, but expect sales and marketing expense as a percentage of total revenue to remain at a relatively comparable level in 2016.

[0001262039-16-000053:mdna:139]
General and administrative

[0001262039-16-000053:mdna:140]
General and administrative expense increased by $30.2 million, or 73%, in 2015 compared to 2014. Personnel costs increased by $14.6 million as we continued to increase headcount in order to support our expanding business. In addition, professional fees increased by $6.9 million, primarily due to legal services related to the assertion of our intellectual property and other rights. In 2015, we also incurred $5.4 million in expenses related to business process design and reengineering in preparation of an ERP system implementation and $1.7 million of costs related to the Meru acquisition. As a percentage of total revenue, we expect general and administrative expense to remain at a relatively comparable level in 2016.

[0001262039-16-000053:mdna:141]
Restructuring charges

[0001262039-16-000053:mdna:142]
Restructuring charges of $7.6 million in 2015 primarily relate to the restructuring activities in connection with the Meru acquisition to reduce our cost structure and improve operational efficiencies. See Note 9 to the consolidated financial statements for additional details, including types of expenses incurred and the timing of future expenses and cash payments. See also the “Liquidity and Capital Resources” section of this Part II, Item 7, “Management’s Discussion and Analysis of Financial Condition and Results of Operations.”

[0001262039-16-000053:mdna:143]
Interest income and other expense—net

[0001262039-16-000053:mdna:144]
|  | Year Ended December 31, |  |  |  |  |
| 2015 |  | 2014 |  | Change |  | % Change |
| (in thousands, except percentages) |
| Interest income | $ | 5,295 |  |  | $ | 5,393 |  |  | $ | (98 | ) |  | (2 | )% |
| Other expense—net | (3,167 | ) |  | (3,168 | ) |  | 1 |  |  | — |  |

[0001262039-16-000053:mdna:145]
Interest income and other expense—net remained relatively consistent in 2015 compared to 2014. Interest income varies depending on our average investment balances during the period, types and mix of investments, and market interest rates.  Other expense—net consisted primarily of foreign exchange and related hedging gains and losses.

[0001262039-16-000053:mdna:146]
Provision for income taxes

[0001262039-16-000053:mdna:147]
|  | Year Ended December 31, |  | Change |  | % Change |
| 2015 |  | 2014 |  |
| (in thousands, except percentages) |
| Provision for income taxes | $ | 9,018 |  |  | $ | 36,206 |  |  | $ | (27,188 | ) |  | (75 | )% |
| Effective tax rate (%) | 53 | % |  | 59 | % |  | (6 | )% |  | — |  |

[0001262039-16-000053:mdna:148]
Our effective tax rate was 53% for 2015, compared with an effective tax rate of 59% for 2014. The provision for income taxes for 2015 was comprised primarily of U.S. federal and state taxes, other foreign income taxes, foreign withholding

[0001262039-16-000053:mdna:149]
47

[0001262039-16-000053:mdna:150]
taxes, an increase in tax reserves, as well as the inclusion of stock-based compensation benefits and transfer pricing allocations which impact jurisdictional income taxed at various tax rates. The decrease in the effective tax rate in 2015 was primarily due to higher research and development credits, additional tax benefits related to stock-based compensation expense and lower foreign withholding taxes.

[0001262039-16-000053:mdna:151]
It is our policy to classify accrued interest and penalties related to unrecognized tax benefits in the provision for income taxes. As of December 31, 2015, we had accrued $5.5 million for estimated interest related to uncertain tax provisions compared to an accrual of $1.7 million as of December 31, 2014.

[0001262039-16-000053:mdna:152]
Within the next twelve months, we do not believe there will be a decrease in uncertain tax benefits that could significantly impact our effective tax rate.

[0001262039-16-000053:mdna:153]
2014 and 2013

[0001262039-16-000053:mdna:154]
Revenue

[0001262039-16-000053:mdna:155]
|  | Year Ended December 31, |  | Change |  | % Change |
| 2014 |  | 2013 |  |
| Amount |  | % ofRevenue |  | Amount |  | % ofRevenue |  |
| (in thousands, except percentages) |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 360,558 |  |  | 47 | % |  | $ | 278,046 |  |  | 45 | % |  | $ | 82,512 |  |  | 30 | % |
| Service | 409,806 |  |  | 53 |  |  | 337,251 |  |  | 55 |  |  | 72,555 |  |  | 22 |  |
| Total revenue | $ | 770,364 |  |  | 100 | % |  | $ | 615,297 |  |  | 100 | % |  | $ | 155,067 |  |  | 25 | % |
| Revenue by geography: |  |  |  |  |  |  |  |  |  |  |  |
| Americas | $ | 324,659 |  |  | 42 | % |  | $ | 252,786 |  |  | 41 | % |  | $ | 71,873 |  |  | 28 | % |
| EMEA | 270,537 |  |  | 35 |  |  | 208,979 |  |  | 34 |  |  | 61,558 |  |  | 29 |  |
| APAC | 175,168 |  |  | 23 |  |  | 153,532 |  |  | 25 |  |  | 21,636 |  |  | 14 |  |
| Total revenue | $ | 770,364 |  |  | 100 | % |  | $ | 615,297 |  |  | 100 | % |  | $ | 155,067 |  |  | 25 | % |

[0001262039-16-000053:mdna:156]
Total revenue increased by $155.1 million, or 25%, in 2014 compared to 2013. The Americas region contributed the largest portion of our revenue growth on an absolute dollar basis and all three regions showed growth on a percentage basis. Product revenue increased by $82.5 million, or 30%, compared to 2013. The increase in product revenue was primarily driven by greater sales volume in our FortiGate product due to increased demand for our high-end products from large enterprise and service provider customers.

[0001262039-16-000053:mdna:157]
Service revenue increased by $72.6 million, or 22%, in 2014 compared to 2013 due to the recognition of revenue from our growing deferred revenue balance consisting of FortiGuard security subscription and FortiCare technical support contracts sold to a larger customer base as well as the renewals of similar contracts sold in earlier periods.

[0001262039-16-000053:mdna:158]
Cost of revenue and gross margin

[0001262039-16-000053:mdna:159]
|  | Year Ended December 31, |  | Change |  | % Change |
| 2014 |  | 2013 |  |
| (in thousands, except percentages) |
| Cost of revenue: |  |  |  |  |  |  |  |
| Product | $ | 151,300 |  |  | $ | 114,611 |  |  | $ | 36,689 |  |  | 32 | % |
| Service | 79,709 |  |  | 66,032 |  |  | 13,677 |  |  | 21 |  |
| Total cost of revenue | $ | 231,009 |  |  | $ | 180,643 |  |  | $ | 50,366 |  |  | 28 | % |
| Gross margin (%): |  |  |  |  |  |  |  |
| Product | 58.0 | % |  | 58.8 | % |  | (0.8 | )% |  |  |
| Service | 80.5 |  |  | 80.4 |  |  | 0.1 |  |  |  |
| Total gross margin | 70.0 | % |  | 70.6 | % |  | (0.6 | )% |  |  |

[0001262039-16-000053:mdna:160]
Total gross margin decreased by 0.6 percentage points in 2014 compared to 2013, as product gross margins declined. Product gross margin decreased by 0.8 percentage points in 2014 compared to 2013 due to an increase in warranty-related costs of $3.2 million and impairment charges related to certain intangible assets of $2.4 million. We also experienced increased freight costs of $2.0 million, higher excess inventory write-offs of $1.4 million, increased personnel-related costs of $0.9 million, and increased occupancy-related costs of $0.8 million.

[0001262039-16-000053:mdna:161]
Service gross margin remained relatively consistent during 2014 as compared to 2013. Cost of service revenue increased by $13.7 million primarily due to a $9.5 million increase in personnel costs, including stock-based compensation, related to headcount increases, a $1.4 million increase in depreciation, a $1.1 million increase in occupancy-related costs, and a $0.8 million increase in professional services.

[0001262039-16-000053:mdna:162]
Operating expenses

[0001262039-16-000053:mdna:163]
|  | Year Ended December 31, |  | Change |  | % Change |
| 2014 |  | 2013 |  |
| Amount |  | % ofRevenue |  | Amount |  | % ofRevenue |  |
| (in thousands, except percentages) |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | $ | 122,880 |  |  | 16 | % |  | $ | 102,660 |  |  | 17 | % |  | $ | 20,220 |  |  | 20 | % |
| Sales and marketing | 315,804 |  |  | 41 |  |  | 224,991 |  |  | 36 |  |  | 90,813 |  |  | 40 |  |
| General and administrative | 41,347 |  |  | 5 |  |  | 34,913 |  |  | 6 |  |  | 6,434 |  |  | 18 |  |
| Total operating expenses | $ | 480,031 |  |  | 62 | % |  | $ | 362,564 |  |  | 59 | % |  | $ | 117,467 |  |  | 32 | % |

[0001262039-16-000053:mdna:164]
Research and development

[0001262039-16-000053:mdna:165]
Research and development expense increased by $20.2 million, or 20%, in 2014 compared to 2013 primarily due to an increase of $12.0 million in personnel costs as a result of increased headcount to support the development of new products and continued enhancements of our existing products. In addition, stock-based compensation increased by $4.0 million, product development expenses, such as supplies and third-party testing and prototypes, increased by $3.4 million, occupancy-related costs and depreciation expense increased by $2.8 million, and professional services costs increased by $1.0 million. These increases were partially offset by a $3.0 million decrease in estimated contingent consideration.

[0001262039-16-000053:mdna:166]
Sales and marketing

[0001262039-16-000053:mdna:167]
Sales and marketing expense increased by $90.8 million, or 40%, in 2014 compared to 2013, primarily due to an increase of $58.8 million in personnel costs as we continued to increase our sales headcount in order to drive continued market share gains globally. Marketing-related expenses increased by $12.9 million as we invested significantly in marketing to capture market share, particularly in the enterprise market, including costs related to tradeshows and lead generation campaigns. In addition, we incurred increases in stock-based compensation expense of $7.2 million, depreciation and other expenses of $4.4 million, travel expenses of $4.2 million, supplies of $2.2 million and occupancy-related cost of $1.0 million.

[0001262039-16-000053:mdna:168]
49

[0001262039-16-000053:mdna:169]
As a percentage of total revenue, sales and marketing expenses increased as we accelerated the investment in our sales force and marketing campaigns to drive future growth.

[0001262039-16-000053:mdna:170]
General and administrative

[0001262039-16-000053:mdna:171]
General and administrative expense increased by $6.4 million, or 18%, in 2014 compared to 2013. Personnel costs, including stock-based compensation, increased by $6.8 million, as we continued to increase our headcount in order to support our expanding business. In addition, professional services fees increased $0.8 million, partially offset by a decrease of $1.3 million in occupancy-related costs including depreciation and supplies.

[0001262039-16-000053:mdna:172]
Interest income and other expense—net

[0001262039-16-000053:mdna:173]
|  | Year Ended December 31, |  | Change |  | % Change |
| 2014 |  | 2013 |  |
| (in thousands, except percentages) |
| Interest income | $ | 5,393 |  |  | $ | 5,306 |  |  | $ | 87 |  |  | 2 | % |
| Other expense—net | (3,168 | ) |  | (1,455 | ) |  | (1,713 | ) |  | 118 |  |

[0001262039-16-000053:mdna:174]
The $0.1 million increase in interest income in 2014 compared to 2013 was primarily due to interest earned on higher invested balances of cash, cash equivalents and investments. The change in other expense—net, for 2014 when compared to 2013, was the result of higher foreign exchange losses and the impact of a reevaluation of the functional currency selection of certain of our international subsidiaries.

[0001262039-16-000053:mdna:175]
Provision for income taxes

[0001262039-16-000053:mdna:176]
|  | Year Ended December 31, |  | Change |  | % Change |
| 2014 |  | 2013 |  |
| (in thousands, except percentages) |
| Provision for income taxes | $ | 36,206 |  |  | $ | 31,668 |  |  | $ | 4,538 |  |  | 14 | % |
| Effective tax rate (%) | 59 | % |  | 42 | % |  | 17 | % |  | — |  |

[0001262039-16-000053:mdna:177]
Our effective tax rate was 59% for 2014, compared with an effective tax rate of 42% for 2013. The provision for income taxes for 2014 was comprised primarily of U.S. federal and state taxes, other foreign income taxes, foreign withholding taxes, discrete events resulting from an increase in tax reserves, as well as the inclusion of stock-based compensation benefits and transfer pricing allocations which impact jurisdictional income taxed at various tax rates. The increase in the effective tax rate in 2014 was primarily due to an increase in estimated tax liability related to foreign operations, an increase in tax reserves, an increase in non-tax deductible stock-based compensation expense, and limitations on utilizing foreign withholding tax credits.

[0001262039-16-000053:mdna:178]
As of December 31, 2014, we had accrued $1.7 million for estimated interest related to uncertain tax provisions compared to an accrual of $1.0 million as of December 31, 2013.

[0001262039-16-000053:mdna:179]
Quarterly Results of Operations

[0001262039-16-000053:mdna:180]
The following table sets forth our unaudited quarterly statements of operations data for the last eight quarters. The information for each of these quarters has been prepared on the same basis as the audited annual financial statements included elsewhere in this Annual Report and, in the opinion of management, includes all adjustments, which includes only normal recurring adjustments, necessary for the fair presentation of the results of operations for these periods. This data should be read in conjunction with our audited consolidated financial statements and related notes included elsewhere in this annual report. These quarterly operating results are not necessarily indicative of our operating results for any future period.

[0001262039-16-000053:mdna:181]
|  | Three Months Ended |
|  | Dec 31,2015 |  | Sept 30,2015 |  | Jun 30,2015 |  | Mar 31,2015 |  | Dec 31,2014 |  | Sept 30,2014 |  | Jun 30,2014 |  | Mar 31,2014 |
|  | (in thousands, except per share amounts) |
| Consolidated Statements of Operations Data: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 144,759 |  |  | $ | 119,737 |  |  | $ | 114,777 |  |  | $ | 97,509 |  |  | $ | 110,678 |  |  | $ | 87,731 |  |  | $ | 85,384 |  |  | $ | 76,765 |  |
| Service | 151,770 |  |  | 140,331 |  |  | 125,008 |  |  | 115,377 |  |  | 113,291 |  |  | 105,617 |  |  | 98,714 |  |  | 92,184 |  |
| Total revenue | 296,529 |  |  | 260,068 |  |  | 239,785 |  |  | 212,886 |  |  | 223,969 |  |  | 193,348 |  |  | 184,098 |  |  | 168,949 |  |
| Cost of revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product (1)(2) | 55,466 |  |  | 46,167 |  |  | 47,397 |  |  | 41,368 |  |  | 46,070 |  |  | 35,636 |  |  | 37,455 |  |  | 32,139 |  |
| Service (1) | 26,510 |  |  | 25,534 |  |  | 22,101 |  |  | 22,234 |  |  | 19,554 |  |  | 21,249 |  |  | 20,302 |  |  | 18,604 |  |
| Total cost of revenue | 81,976 |  |  | 71,701 |  |  | 69,498 |  |  | 63,602 |  |  | 65,624 |  |  | 56,885 |  |  | 57,757 |  |  | 50,743 |  |
| Total gross profit | 214,553 |  |  | 188,367 |  |  | 170,287 |  |  | 149,284 |  |  | 158,345 |  |  | 136,463 |  |  | 126,341 |  |  | 118,206 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development (1) | 42,814 |  |  | 42,110 |  |  | 37,389 |  |  | 35,816 |  |  | 33,097 |  |  | 30,790 |  |  | 29,938 |  |  | 29,055 |  |
| Sales and marketing (1)(2) | 136,840 |  |  | 120,994 |  |  | 111,928 |  |  | 100,609 |  |  | 93,228 |  |  | 80,433 |  |  | 74,817 |  |  | 67,326 |  |
| General and administrative (1) | 20,315 |  |  | 21,220 |  |  | 18,018 |  |  | 11,961 |  |  | 12,104 |  |  | 9,789 |  |  | 10,444 |  |  | 9,010 |  |
| Restructuring charges | 1,717 |  |  | 5,883 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Total operating expenses | 201,686 |  |  | 190,207 |  |  | 167,335 |  |  | 148,386 |  |  | 138,429 |  |  | 121,012 |  |  | 115,199 |  |  | 105,391 |  |
| Operating income (loss) | 12,867 |  |  | (1,840 | ) |  | 2,952 |  |  | 898 |  |  | 19,916 |  |  | 15,451 |  |  | 11,142 |  |  | 12,815 |  |
| Interest income | 1,176 |  |  | 1,333 |  |  | 1,364 |  |  | 1,422 |  |  | 1,402 |  |  | 1,339 |  |  | 1,319 |  |  | 1,333 |  |
| Other expense—net | (1,007 | ) |  | (653 | ) |  | (830 | ) |  | (677 | ) |  | (1,200 | ) |  | (1,005 | ) |  | (574 | ) |  | (389 | ) |
| Income (loss) before income taxes | 13,036 |  |  | (1,160 | ) |  | 3,486 |  |  | 1,643 |  |  | 20,118 |  |  | 15,785 |  |  | 11,887 |  |  | 13,759 |  |
| Provision for (benefit from) income taxes | 15,570 |  |  | (9,329 | ) |  | 2,694 |  |  | 83 |  |  | 13,305 |  |  | 11,729 |  |  | 5,806 |  |  | 5,366 |  |
| Net income (loss) | $ | (2,534 | ) |  | $ | 8,169 |  |  | $ | 792 |  |  | $ | 1,560 |  |  | $ | 6,813 |  |  | $ | 4,056 |  |  | $ | 6,081 |  |  | $ | 8,393 |  |
| Net income (loss) per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic | $ | (0.01 | ) |  | $ | 0.05 |  |  | $ | — |  |  | 0.01 |  |  | $ | 0.04 |  |  | $ | 0.02 |  |  | $ | 0.04 |  |  | $ | 0.05 |  |
| Diluted | $ | (0.01 | ) |  | $ | 0.05 |  |  | $ | — |  |  | $ | 0.01 |  |  | $ | 0.04 |  |  | $ | 0.02 |  |  | $ | 0.04 |  |  | $ | 0.05 |  |

[0001262039-16-000053:mdna:182]
__________________________

[0001262039-16-000053:mdna:183]
51

[0001262039-16-000053:mdna:184]
| (1) | Includes stock-based compensation as follows: |

[0001262039-16-000053:mdna:185]
|  | Three Months Ended |
|  | Dec 31,2015 |  | Sept 30,2015 |  | Jun 30,2015 |  | Mar 31,2015 |  | Dec 31,2014 |  | Sept 30,2014 |  | Jun 30,2014 |  | Mar 31,2014 |
|  | (in thousands) |
| Cost of product revenue | $ | 332 |  |  | $ | 291 |  |  | $ | 210 |  |  | $ | 140 |  |  | $ | 132 |  |  | $ | 60 |  |  | $ | 178 |  |  | $ | 113 |  |
| Cost of service revenue | 1,980 |  |  | 1,849 |  |  | 1,660 |  |  | 1,632 |  |  | 1,612 |  |  | 1,522 |  |  | 1,363 |  |  | 1,329 |  |
| Research and development | 7,194 |  |  | 6,663 |  |  | 5,541 |  |  | 5,157 |  |  | 4,706 |  |  | 4,505 |  |  | 4,171 |  |  | 3,882 |  |
| Sales and marketing | 14,954 |  |  | 13,904 |  |  | 11,271 |  |  | 9,307 |  |  | 7,854 |  |  | 7,397 |  |  | 5,747 |  |  | 5,746 |  |
| General and administrative | 3,627 |  |  | 3,612 |  |  | 3,078 |  |  | 2,686 |  |  | 2,377 |  |  | 1,183 |  |  | 3,257 |  |  | 1,860 |  |
| Total stock-based compensation expense | $ | 28,087 |  |  | $ | 26,319 |  |  | $ | 21,760 |  |  | $ | 18,922 |  |  | $ | 16,681 |  |  | $ | 14,667 |  |  | $ | 14,716 |  |  | $ | 12,930 |  |

[0001262039-16-000053:mdna:186]
_______________________________________________

[0001262039-16-000053:mdna:187]
| (2) | Includes amortization and impairment of intangible assets as follows: |

[0001262039-16-000053:mdna:188]
|  | Three Months Ended |
|  | Dec 31,2015 |  | Sept 30,2015 |  | Jun 30,2015 |  | Mar 31,2015 |  | Dec 31,2014 |  | Sept 30,2014 |  | Jun 30,2014 |  | Mar 31,2014 |
|  | (in thousands) |
| Amortization of intangible assets | $ | 1,319 |  |  | $ | 1,319 |  |  | $ | 244 |  |  | $ | 244 |  |  | $ | 244 |  |  | $ | 244 |  |  | $ | 408 |  |  | $ | 511 |  |
| Impairment of intangible assets | — |  |  | — |  |  | 1,593 |  |  | — |  |  | — |  |  | — |  |  | 2,404 |  |  | — |  |
| Total amortization and impairment of intangible assets | $ | 1,319 |  |  | $ | 1,319 |  |  | $ | 1,837 |  |  | $ | 244 |  |  | $ | 244 |  |  | $ | 244 |  |  | $ | 2,812 |  |  | $ | 511 |  |

[0001262039-16-000053:mdna:189]
Seasonality, Cyclicality and Quarterly Revenue Trends

[0001262039-16-000053:mdna:190]
Our quarterly results reflect a pattern of increased customer buying at year-end, which has positively impacted billings and product revenue activity in the fourth quarter. In the first quarter, we generally experience lower sequential customer buying, which results in lower billings and product revenue. Although these seasonal factors are common in the technology sector, historical patterns should not be considered a reliable indicator of our future sales activity or performance. On a quarterly basis, we have usually generated the majority of our product revenue in the final month of each quarter and a significant amount in the last two weeks of each quarter. We believe this is due to customer buying patterns typical in this industry.

[0001262039-16-000053:mdna:191]
Our total quarterly revenue over the past eight quarters has generally increased sequentially in each quarter, except in the first quarter of 2015. Product revenue in all of the quarters of 2015 was higher as compared to the same quarters in 2014, which we believe was due in part to the investments made in our sales and marketing organizations, to a robust security market and to continued product innovation.

[0001262039-16-000053:mdna:192]
Total gross margin has fluctuated on a quarterly basis primarily due to shifts in the mix of sales between products and services and between products.  Product gross margins, on average throughout the year, increased in 2015 primarily due to a greater mix of high-end FortiGate product sales compared to 2014. Product gross margin varies based on the types of products sold and the average selling prices of our products. In addition, product gross margin was positively impacted by higher sales of software products such as certain of our virtualized security solutions, as well as inventory management efficiencies. Service gross margins, on average throughout the year, increased in 2015 compared to 2014 as we scaled efficiencies resulting from our ability to add and charge for more functionality and value to our FortiGuard security subscription and FortiCare technical support offerings, which yielded more value to our customers and which translated into improved service margins.

[0001262039-16-000053:mdna:193]
Liquidity and Capital Resources

[0001262039-16-000053:mdna:194]
|  | As of December 31, |
|  | 2015 |  | 2014 |  | 2013 |
|  | (in thousands) |
| Cash and cash equivalents | $ | 543,277 |  |  | $ | 283,254 |  |  | $ | 115,873 |  |
| Investments | 621,033 |  |  | 708,490 |  |  | 727,172 |  |
| Total cash, cash equivalents and investments | $ | 1,164,310 |  |  | $ | 991,744 |  |  | $ | 843,045 |  |
| Working capital | $ | 591,873 |  |  | $ | 508,925 |  |  | $ | 271,505 |  |
|  | Year Ended December 31, |
|  | 2015 |  | 2014 |  | 2013 |
|  | (in thousands) |
| Cash provided by operating activities | $ | 282,547 |  |  | $ | 196,582 |  |  | $ | 147,384 |  |
| Cash used in investing activities | (967 | ) |  | (29,350 | ) |  | (146,734 | ) |
| Cash provided by (used in) financing activities | (21,557 | ) |  | 749 |  |  | (6,423 | ) |
| Effect of exchange rates on cash and cash equivalents | — |  |  | (600 | ) |  | (1,329 | ) |
| Net increase (decrease) in cash and cash equivalents | $ | 260,023 |  |  | $ | 167,381 |  |  | $ | (7,102 | ) |

[0001262039-16-000053:mdna:195]
Liquidity and capital resources may be impacted by our operating activities, as well as by our business acquisitions, capital expenditures, stock repurchases, proceeds associated with stock option exercises and issuances of common stock under the employee stock purchase plan (“ESPP”), payment of taxes in connection with the net settlement of equity awards, and investments in strategic relationships that we have made or may make in the future. Our previous stock repurchase program expired on December 31, 2015 with an unused balance under the Program of $62.5 million. In January 2016, our board of directors approved a new share repurchase program, which authorizes the repurchase of up to $200.0 million of our outstanding common stock through December 31, 2017. In recent years we have received significant capital resources as a result of the exercise of stock options and purchases under our ESPP. We expect proceeds in future years to be impacted by our share price and the mix of stock options and RSUs granted.  We expect to spend $35.0 million to $45.0 million in capital expenditures primarily related to expansion of our offices to support worldwide growth and the implementation of our ERP system.

[0001262039-16-000053:mdna:196]
In December 2015, we received $9.0 million from a third-party for a release of claims. In addition, we agreed to a three-year covenant-not-to-sue. Of the $9.0 million of consideration received, $2.0 million was used to offset contingent legal fees incurred in connection with the litigation and the remaining $7.0 million was deferred, with the short-term portion recorded as accrued liabilities and the long-term portion recorded as other liabilities in the consolidated balance sheet. The deferral will be recognized ratably through 2018 as an offset to general and administrative expenses in the consolidated statement of operations.

[0001262039-16-000053:mdna:197]
As of December 31, 2015, our cash, cash equivalents, and investments of $1.16 billion were invested primarily in corporate debt securities, commercial paper, municipal bonds, certificates of deposit and term deposits, money market funds, and U.S. government and agency securities. It is our investment policy to invest excess cash in a manner that preserves capital, provides liquidity and maximizes return without significantly increasing risk.

[0001262039-16-000053:mdna:198]
As of December 31, 2015, $375.7 million of our cash and investments were held by our international subsidiaries and are therefore not immediately available to fund domestic operations unless the cash is repatriated. While we do not intend to do so, should this amount be repatriated, most of it would be subject to U.S. federal income tax that would be partially offset by foreign tax credits. We do not enter into investments for trading or speculative purposes. We believe that our existing cash and cash equivalents will be sufficient to meet our anticipated cash needs for at least the next 12 months. Our future capital requirements will depend on many factors, including our growth rate, the timing and extent of spending to support development efforts, the expansion of sales and marketing activities, the introduction of new and enhanced products and services offerings, the costs to ensure access to adequate manufacturing capacity and the continuing market acceptance of our products. Historically, we have required capital principally to fund our working capital needs, capital expenditures, share repurchases and acquisition activities. In the event that additional financing is required from outside sources, we may not be able to raise it on terms acceptable to us or at all. If we are unable to raise additional capital when desired, our business, operating results and financial condition would be adversely affected.

[0001262039-16-000053:mdna:199]
53

[0001262039-16-000053:mdna:200]
Operating Activities

[0001262039-16-000053:mdna:201]
Cash generated by operating activities is our primary source of liquidity. It is primarily comprised of net income, as adjusted for non-cash items, and changes in operating assets and liabilities. Non-cash adjustments consist primarily of stock-based compensation, depreciation of property and equipment, amortization of intangible assets, excess tax benefit from stock-based compensation, and amortization of investment premiums.

[0001262039-16-000053:mdna:202]
Our operating activities during 2015 provided $282.5 million in cash as a result of our continued growth in billings and the ability to successfully manage our working capital. Additionally, in 2015, we received $9.0 million related to a mutual three-year covenant-not-to-sue agreement. Changes in operating assets and liabilities primarily resulted from an increase in payments received from customers, partially offset by an increase in payments to vendors.

[0001262039-16-000053:mdna:203]
Our operating activities during 2014 provided $196.6 million in cash as a result of profitability, timing of billings and collections, and the ability to successfully manage our working capital. The primary sources of cash from operating activities during 2014 consisted of net income of $25.3 million, increased by non-cash adjustments of $93.9 million and changes in operating assets and liabilities of $77.4 million. In 2014, we received $20.0 million pursuant to a six-year mutual covenant-not-to-sue and release agreement with Palo Alto Networks, Inc. Changes in operating assets and liabilities primarily included an increase in payments received from customers and a receipt of cash related to the mutual covenant-not-to-sue and release agreement, partially offset by payments for inventory purchases, prepayment of certain expenses and payments of income taxes during the period.

[0001262039-16-000053:mdna:204]
Our operating activities during 2013 provided $147.4 million in cash as a result of profitability, timing of billings and collections, and the ability to successfully manage our working capital. The primary sources of cash from operating activities during 2013 consisted of net income of $44.3 million increased by non-cash adjustments of $69.2 million and changes in operating assets and liabilities of $33.9 million. Changes in operating assets and liabilities primarily included an increase in payments received from customers, partially offset by payments for inventory purchases.

[0001262039-16-000053:mdna:205]
Investing Activities

[0001262039-16-000053:mdna:206]
The changes in cash flows from investing activities primarily relate to timing of purchases, maturities and sales of investments, purchases of property and equipment, and payments made in connection with business acquisitions.

[0001262039-16-000053:mdna:207]
During 2015, cash used for investing activities was primarily due to $38.0 million used for the acquisition of Meru, In addition we spent $37.4 million on capital expenditures, including our purchases of certain real properties in Sunnyvale, California and Sophia, France for total cash of $13.9 million. The outflow of cash was partially offset by positive cash flow due to maturities, net of purchases, from our investments of $74.4 million.

[0001262039-16-000053:mdna:208]
During 2014, cash used for investing activities was primarily due to $32.2 million spent on capital expenditures, partially offset by positive cash flow due to maturities, net of purchases, from our investments of $2.9 million.

[0001262039-16-000053:mdna:209]
During 2013, cash used for investing activities was primarily due to $125.2 million of net purchases of investments, $13.9 million for the purchases of property and equipment, and $7.6 million for acquisitions.

[0001262039-16-000053:mdna:210]
Financing Activities

[0001262039-16-000053:mdna:211]
The changes in cash flows from financing activities primarily relate to proceeds from the issuance of common stock under our equity incentive plan and ESPP, taxes paid related to net share settlement of equity awards, excess tax benefit from stock-based compensation, and repurchase and retirement of common stock.

[0001262039-16-000053:mdna:212]
During 2015, cash used for financing activities was $21.6 million primarily due to $60.0 million used to repurchase our common stock. This was partially offset by $38.4 million of proceeds from the issuance of common stock, net of taxes paid related to withholding upon issuance of RSUs.

[0001262039-16-000053:mdna:213]
During 2014, cash provided by financing activities was $0.7 million as a result of proceeds of $55.3 million from the issuance of common stock under our stock plans. This cash inflow was partially offset by $44.0 million used to repurchase our common stock and $10.6 million of taxes payment related to withholding upon the issuance of RSUs.

[0001262039-16-000053:mdna:214]
During 2013, cash used in financing activities was $6.4 million as a result of our repurchase of $33.5 million of common stock and our net-share settlement of RSUs of $1.5 million. This was offset by receiving proceeds of $12.9 million

[0001262039-16-000053:mdna:215]
and $12.7 million from the issuance of common stock under our stock option plans and ESPP, respectively, and an excess tax benefit from employee stock option exercises of $3.0 million.

[0001262039-16-000053:mdna:216]
Contractual Obligations and Commitments

[0001262039-16-000053:mdna:217]
The following summarizes our contractual obligations as of December 31, 2015:

[0001262039-16-000053:mdna:218]
|  | Payments Due by Period |
|  | Total |  | Less than 1 year |  | 1 - 3 years |  | 3 - 5 years |  | More than 5 years |
|  | (in thousands) |
| Operating lease commitments (1) | $ | 61,013 |  |  | $ | 17,052 |  |  | $ | 30,046 |  |  | $ | 7,527 |  |  | $ | 6,388 |  |
| Inventory purchase commitments (2) | 70,018 |  |  | 70,018 |  |  | — |  |  | — |  |  | — |  |
| Other contractual commitments and open purchase orders (3) | 37,346 |  |  | 33,375 |  |  | 3,578 |  |  | 393 |  |  | — |  |
| Total | $ | 168,377 |  |  | $ | 120,445 |  |  | $ | 33,624 |  |  | $ | 7,920 |  |  | $ | 6,388 |  |

[0001262039-16-000053:mdna:219]
________________________

[0001262039-16-000053:mdna:220]
| (1) | Consists of contractual obligations from non-cancelable office space under operating leases. |

[0001262039-16-000053:mdna:221]
| (2) | Consists of minimum purchase commitments with independent contract manufacturers. |

[0001262039-16-000053:mdna:222]
| (3) | Consists of an estimate of open purchase orders and contractual obligations in the ordinary course of business, other than commitments with contract manufacturers and suppliers, for which we have not received the goods or services. No tax liabilities related to uncertain tax positions have been included in the table. As of December 31, 2015, we had $60.6 million of long-term tax liabilities, including interest, related to uncertain tax positions. Because of the high degree of uncertainty regarding the settlement of these liabilities, we are unable to estimate the years in which future cash outflows may occur. |

[0001262039-16-000053:mdna:223]
Off-Balance Sheet Arrangements

[0001262039-16-000053:mdna:224]
During 2015, 2014 and 2013, we did not have any relationships with unconsolidated organizations or financial partnerships, such as structured finance or special purpose entities that would have been established for the purpose of facilitating off-balance sheet arrangements or other contractually narrow or limited purposes.

[0001262039-16-000053:mdna:225]
Recent Accounting Pronouncement

[0001262039-16-000053:mdna:226]
See Note 1 of the notes to our consolidated financial statements in Part II, Item 8 of this Annual Report on Form 10-K for a full description of recently adopted accounting pronouncements.
