# FTNT MD&A — 0001262039-24-000014


## mdna

[0001262039-24-000014:mdna:1]
ITEM 7.     Management’s Discussion and Analysis of Financial Condition and Results of Operations

[0001262039-24-000014:mdna:2]
•continued growth and market share gains;

[0001262039-24-000014:mdna:3]
•variability in sales in certain product and service categories from year to year and between quarters;

[0001262039-24-000014:mdna:4]
•expected impact of sales from certain products and services;

[0001262039-24-000014:mdna:5]
•increasing or decreasing inflation or stagflation, and changing interest rates in many geographies and changes in currency exchange rates and currency regulations;

[0001262039-24-000014:mdna:6]
•competition in our markets;

[0001262039-24-000014:mdna:7]
•macroeconomic, geopolitical factors and other disruption on our manufacturing or sales, including public health issues, wars and natural disasters;

[0001262039-24-000014:mdna:8]
•real estate investments, management of future growth including expansions and enhancements of current properties;

[0001262039-24-000014:mdna:9]
•government regulation, tariffs and other policies;

[0001262039-24-000014:mdna:10]
•drivers of long-term growth and operating leverage, such as pricing of our products and services, sales productivity, pipeline and capacity, functionality, value and technology improvements in our service offerings;

[0001262039-24-000014:mdna:11]
•growing our solution sales through channel partners to businesses, service providers and government organizations, our ability to execute these sales and the complexity of providing solutions to all segments (including the increased competition and unpredictability of timing associated with sales to larger enterprises), the impact of sales to these organizations on our long-term growth, expansion and operating results, and the effectiveness of our sales organization;

[0001262039-24-000014:mdna:12]
•our ability to successfully anticipate market changes related to cloud-based solutions and to sell, support and meet service level agreements related to cloud-based solutions;

[0001262039-24-000014:mdna:13]
•growth expectations for the secure networking market;

[0001262039-24-000014:mdna:14]
•supply chain constraints, component availability and other factors affecting our manufacturing capacity, delivery, cost and inventory management;

[0001262039-24-000014:mdna:15]
•forecasts of future demand and targeted inventory levels, including changing market drivers and demands;

[0001262039-24-000014:mdna:16]
•the effect of backlog from prior quarters, including its effect on growth of in-quarter billings and revenue;

[0001262039-24-000014:mdna:17]
•instability in the global banking system;

[0001262039-24-000014:mdna:18]
•our ability to hire properly qualified and effective sales, support and engineering employees;

[0001262039-24-000014:mdna:19]
•risks and expectations related to acquisitions and equity interests in private and public companies, including integration issues related to go-to-market plans, product plans, employees of such companies, controls and processes and the acquired technology, and risks of negative impact by such acquisitions and equity investments on our financial results;

[0001262039-24-000014:mdna:20]
•trends in revenue, cost of revenue and gross margin, including expectations regarding product revenue and service revenue growth;

[0001262039-24-000014:mdna:21]
•trends in our operating expenses, including sales and marketing expense, research and development expense, general and administrative expense, and expectations regarding these expenses;

[0001262039-24-000014:mdna:22]
•expected impact of plans and strategy for the acceleration of our points of presence (“PoP”) deployment;

[0001262039-24-000014:mdna:23]
•expectations that our operating expenses will increase year over year in absolute dollars during 2024;

[0001262039-24-000014:mdna:24]
•expectations that proceeds from the exercise of stock options in future years will be adversely impacted by the increased mix of restricted stock units and performance stock units versus stock options granted or a decline in our stock price;

[0001262039-24-000014:mdna:25]
•expectations regarding uncertain tax benefits and our effective domestic and global tax rates, the impact of interpretations of or changes to tax law, and the timing of tax payments;

[0001262039-24-000014:mdna:26]
•expectations regarding spending related to real estate acquisitions and development, including data center, office building and warehouse investments, as well as other capital expenditures and to the impact on free cash flow and expenses;

[0001262039-24-000014:mdna:27]
•estimates of a range of 2024 spending on capital expenditures;

[0001262039-24-000014:mdna:28]
•expected outcomes and liabilities in litigation;

[0001262039-24-000014:mdna:29]
•our intentions regarding share repurchases and the sufficiency of our existing cash, cash equivalents and investments to meet our cash needs, including our debt servicing requirements, for at least the next 12 months;

[0001262039-24-000014:mdna:30]
•other statements regarding our future operations, financial condition and prospects and business strategies; and

[0001262039-24-000014:mdna:31]
•adoption and impact of new accounting standards.

[0001262039-24-000014:mdna:32]
Business Overview

[0001262039-24-000014:mdna:33]
Fortinet is a leader in cybersecurity and the convergence of networking and security. Our mission is to secure people, devices and data everywhere. Our integrated platform, the Fortinet Security Fabric, spans secure networking, unified SASE and AI-driven security operations to deliver cybersecurity where our customers need it. As of December 31, 2023, over a half million customers trusted our solutions, including enterprises such as in the financial services, retail and operational technology market verticals, communication and security service providers, government organizations and small and medium-sized businesses. As a global company headquartered in Sunnyvale, California with a large international customer base, the majority of our research and development is in the United States and Canada with a global footprint of support and centers of excellence around the world. As of December 31, 2023, we held 957 U.S. patents and 1,299 global patents and we are recognized in over 80 enterprise analyst reports demonstrating both our vision and execution across networking and security products.

[0001262039-24-000014:mdna:34]
•Secure Networking—Our Secure Networking solutions focus on the convergence of networking and security via our network firewall and our switches, access points and other secure connectivity solutions. FortiOS is our networking and security operating system that is consistent across our firewalls and secure connectivity solutions and supports over 30 functions that can be delivered via a physical, virtual, cloud or SaaS solution. When delivered via our network firewall appliances, functionality is accelerated through our proprietary ASIC technology. These proprietary ASICs, combined with off-the-shelf CPUs and ASICs, allow our systems to scale, run multiple applications at higher performance, lower power consumption and perform more processor-intensive operations, such as inspecting encrypted traffic, including streaming video. The Network Firewall solution consists of FortiGate data centers, hyperscale and distributed firewalls, as well as encrypted applications (SSL inspection, Virtual Private Network and

[0001262039-24-000014:mdna:35]
IPsec connectivity). Our ability to converge networking and security also enables the ethernet to become an extension of a company’s security infrastructure through FortiSwitch and FortiLink. Our wireless LAN solution leverages secure networking to provide secure wireless access for the enterprise LAN edge. FortiExtender secures 5G/LTE and remote ethernet extenders to connect and secure any branch environment. The Secure Connectivity solution includes FortiSwitch Secure Ethernet Switches, FortiAP Wireless Local Area Network Access Points and FortiExtender 5G Connectivity Gateways, among other products.

[0001262039-24-000014:mdna:36]
•Unified Secure Access Service Edge (SASE)—As applications move to the cloud and work from anywhere becomes established, cloud delivery is needed to enable secure access to applications on any cloud. The Fortinet Unified SASE solution is a single-vendor SASE solution that includes Firewall, SD-WAN, Secure Web Gateway, Cloud Access Services Broker, Data Loss Prevention, Zero Trust Network Access and cloud security, including Web Application Firewalls, Virtualized Firewalls and Cloud-Native Firewalls, among other products. These functions are delivered through our FortiOS operating systems, which can deploy the full SASE stack through the cloud or on our ASIC-driven appliances. All functions can be managed through a unified management console.

[0001262039-24-000014:mdna:37]
•Security Operations (SecOps)—Fortinet’s Security Operations solutions comply with the NIST cybersecurity framework of identify, protect, detect, respond and recover, and are delivered as a platform that automates detection and response to accelerate discovery and remediation. The SecOps solution includes FortiAI generative AI assistant, FortiSIEM Security Information and Event Management, FortiSOAR Security Orchestration, Automation and Response, FortiEDR Endpoint Detection and Response, FortiXDR Extended Detection and Response, FortiMDR Managed Detection and Response Service, FortiNDR Network Detection and Response, FortiRecon Digital Risk Protection, FortiDeceptor Deception technology, FortiGuard SoCaaS, FortiSandbox Sandboxing Services and FortiGuard Incident Response Services, among other products.

[0001262039-24-000014:mdna:38]
FortiGuard Labs is our cybersecurity threat intelligence and research organization comprised of experienced threat hunters, researchers, analysts, engineers and data scientists who develop and utilize machine learning and AI technologies to provide timely protection updates and actionable threat intelligence for the benefit of our customers. FortiGuard Security Services are a suite of AI-powered security capabilities that are natively integrated as part of the Fortinet Security Fabric to deliver coordinated detection and enforcement across the entire attack surface. The portfolio consists of FortiGuard application security services, content security services, device security services, NOC/SOC security services and web security services.

[0001262039-24-000014:mdna:39]
FortiCare Technical Support Service is a per-device support service, which provides customers access to experts to ensure efficient and effective operations and maintenance of their Fortinet capabilities. Global technical support is offered 24x7 with flexible add-ons, including enhanced SLAs and premium hardware replacement through in-country depots. Organizations have the flexibility to procure different levels of service for different devices based on their availability needs. We offer three per-device support options tailored to the needs of our enterprise customers: FortiCare Premium, FortiCare Elite and FortiCare Essential. The FortiCare Elite service aims to provide 15-minute response times for key product families.

[0001262039-24-000014:mdna:40]
We also offer training services to our end-customers and channel partners through our training team and authorized training partners. We have also implemented a training certification program, NSE, to help ensure an understanding of our products and services. Since 2020, Fortinet has also offered a number of free online training courses to help address prevalent industry-wide cybersecurity skills gaps and shortages.

[0001262039-24-000014:mdna:41]
Financial Highlights

[0001262039-24-000014:mdna:42]
•Total revenue was $5.30 billion in 2023, an increase of 20% compared to $4.42 billion in 2022.

[0001262039-24-000014:mdna:43]
•Product revenue was $1.93 billion in 2023, an increase of 8% compared to $1.78 billion in 2022.

[0001262039-24-000014:mdna:44]
•Service revenue was $3.38 billion in 2023, an increase of 28% compared to $2.64 billion in 2022.

[0001262039-24-000014:mdna:45]
•Total gross profit was $4.07 billion in 2023, an increase of 22% compared to $3.33 billion in 2022.

[0001262039-24-000014:mdna:46]
•Operating income was $1.24 billion in 2023, an increase of 28% compared to $969.6 million in 2022.

[0001262039-24-000014:mdna:47]
•Cash, cash equivalents, investments and marketable equity securities were $2.44 billion as of December 31, 2023, an increase of $183.9 million, or 8%, from December 31, 2022.

[0001262039-24-000014:mdna:48]
•Long-term debt, net of unamortized discount and debt issuance costs, was $992.3 million and $990.4 million as of December 31, 2023 and 2022, respectively.

[0001262039-24-000014:mdna:49]
•In 2023, we repurchased 27.2 million shares of common stock under the Repurchase Program for an aggregate purchase price of $1.50 billion, which excludes a $10.9 million accrual related to the 1% excise tax imposed by the Inflation Reduction Act of 2022. In 2022, we repurchased 36.0 million shares of common stock for a total purchase price of $1.99 billion.

[0001262039-24-000014:mdna:50]
•Deferred revenue was $5.74 billion as of December 31, 2023, an increase of $1.09 billion, or 24%, from December 31, 2022. Short-term deferred revenue was $2.85 billion as of December 31, 2023, an increase of $499.4 million, or 21%, from December 31, 2022.

[0001262039-24-000014:mdna:51]
•Cash flows from operating activities were $1.94 billion in 2023, an increase of $204.9 million, or 12%, compared to 2022.

[0001262039-24-000014:mdna:52]
Our revenue growth was driven primarily by service revenue. On a geographic basis, revenue continues to be diversified globally, which remains a key strength of our business.

[0001262039-24-000014:mdna:53]
In 2023, the Americas region, the Europe, Middle East and Africa (“EMEA”) region and the Asia Pacific (“APAC”) region contributed 41%, 39% and 20% of our total revenue, respectively, and increased 22%, 23% and 12% compared to 2022, respectively.

[0001262039-24-000014:mdna:54]
Product revenue growth was impacted by an elevated cyber threat landscape, the convergence of security and networking, the impact of certain historical pricing actions, improving supply chain dynamics and changes in the backlog balance. Product revenue growth rates decreased from 42% in 2022 to 8% in 2023 partially due to overall softening macroeconomic conditions. We expect that product revenue growth rates will continue to be impacted by overall macroeconomic conditions in 2024.

[0001262039-24-000014:mdna:55]
Service revenue growth has accelerated over the past three years from 24% in 2021, to 26% in 2022, to 28% in 2023. Service revenue growth of 28% in 2023 was primarily driven by the strength of our security subscription revenue, which grew 33%. The increase was primarily due to the recognition of revenue from our growing deferred revenue balance related to FortiGuard and other security subscriptions delivered to on-premise and cloud-based environments. Security subscriptions outpaced technical support growth due to strength in secure networking subscriptions, SecOps and SASE. We expect our service revenue to continue to grow in 2024, with growth opportunities coming from our SecOps and SASE offerings. While service revenue is expected to grow, we anticipate that the growth rates will be impacted by overall macroeconomic conditions in 2024.

[0001262039-24-000014:mdna:56]
Our billings were diversified on a geographic basis. In 2023, seven countries represented approximately 50% of our billings and the remaining 50% in the aggregate were from over 100 countries that individually contributed less than 3% of our billings.

[0001262039-24-000014:mdna:57]
Operating expenses as a percentage of revenue decreased approximately 0.2 percentage points in 2023 compared to 2022. Headcount increased 8% to 13,568 employees as of December 31, 2023, up from 12,595 as of December 31, 2022.

[0001262039-24-000014:mdna:58]
Impact of Macroeconomic Developments

[0001262039-24-000014:mdna:59]
Our overall performance depends in part on worldwide economic and geopolitical conditions, such as the war in Ukraine and the Israel-Hamas war or tensions between China and Taiwan, and their impact on customer behavior. Worsening economic conditions, including inflation, higher interest rates, slower growth, any recession, fluctuations in foreign exchange rates, instability in the global banking industry and other changes in economic conditions, may result in decreased sales productivity and growth and adversely affect our results of operations and financial performance. We have seen certain impacts on our business, results of operations, financial condition, cash flows, liquidity and capital and financial resources such as longer sales cycles, delayed purchases and increased commitments with certain suppliers and increased inventory and inventory purchase commitment reserves.

[0001262039-24-000014:mdna:60]
Our days sales outstanding remained flat at 89 days for the years ended December 31, 2023 and 2022, primarily due to the sales linearity and certain geographies where extended payment terms are more prevalent. The accounts receivable allowance for credit losses was $8.2 million as of December 31, 2023, an increase of $4.6 million compared to $3.6 million as of December 31, 2022, primarily due to an increase in past due invoices over 60 and 90 days.

[0001262039-24-000014:mdna:61]
Worsening economic conditions may have a material negative impact on our results in future periods and may negatively impact our billings, revenue and costs, and may decrease growth and profitability. The extent of the impact of economic conditions on our operational and financial performance will depend on ongoing developments, including those

[0001262039-24-000014:mdna:62]
discussed above and others identified in Part I, Item 1A “Risk Factors” in this Form 10-K. Given the dynamic nature of these circumstances, the full impact of worsening economic conditions on our business and operations, results of operations, financial condition, cash flows, liquidity and capital and financial resources cannot be reasonably estimated at this time.

[0001262039-24-000014:mdna:63]
Business Model

[0001262039-24-000014:mdna:64]
We typically sell our security solutions to distributors that sell to networking security focused resellers and to certain service providers and managed security service providers (“MSSPs”), who, in turn, sell to end-customers or use our products and services to provide hosted solutions to other enterprises. At times, we also sell directly to certain large enterprise customers, large service providers and major systems integrators. In addition, we sell our software licenses and services via different cloud service provider platforms, both directly and through our channel partners. Our end-customers are located in over 100 countries and include small, medium and large enterprises and government organizations across a wide range of industries, including financial services, government, healthcare, manufacturing, retail, technology and telecommunications. An end-customer deployment may involve as few as one or as many as thousands of secure networking, unified SASE and security operations technology products, depending on the end-customer’s size and security requirements.

[0001262039-24-000014:mdna:65]
Our customers purchase our hardware products, software licenses and cloud-delivered solutions, as well as our FortiGuard and other security subscription and FortiCare technical support services. We generally invoice network security at the time of our sale for the total price of the products and services. Standard payment terms are generally no more than 60 days, though we may offer extended payment terms to certain distributors or related to certain transactions.

[0001262039-24-000014:mdna:66]
We also offer our products hosted in our own data centers, PoPs and through co-locations and major cloud service providers, including Amazon Web Services, Microsoft Azure and Google Cloud. We have also recognized revenue from customers who deploy our products in a bring-your-own-license (“BYOL”) arrangements at cloud service providers or at private clouds. In a BYOL arrangement, a customer purchases a software license through our channel partners and deploys the software in a cloud provider’s environment, in third-party clouds or in their private cloud.

[0001262039-24-000014:mdna:67]
Key Metrics

[0001262039-24-000014:mdna:68]
We monitor several key metrics, including the key financial metrics set forth below, in order to help us evaluate growth trends, establish budgets, measure the effectiveness of our sales and marketing efforts, and assess operational efficiencies. The following table summarizes revenue, deferred revenue, billings (non-GAAP), net cash provided by operating activities, and free cash flow (non-GAAP). We discuss revenue below under “—Components of Operating Results,” and we discuss net cash provided by operating activities below under “—Liquidity and Capital Resources.” Deferred revenue, billings (non-GAAP), and free cash flow (non-GAAP) are discussed immediately below the following table.

[0001262039-24-000014:mdna:69]
|  | Year Ended or As of December 31, |
|  | 2023 |  | 2022 |  | 2021 |
|  | (in millions) |
| Revenue | $ | 5,304.8 |  |  | $ | 4,417.4 |  |  | $ | 3,342.2 |  |
| Deferred revenue | $ | 5,735.0 |  |  | $ | 4,640.3 |  |  | $ | 3,452.9 |  |
| Billings (non-GAAP) | $ | 6,399.5 |  |  | $ | 5,594.0 |  |  | $ | 4,181.4 |  |
| Net cash provided by operating activities | $ | 1,935.5 |  |  | $ | 1,730.6 |  |  | $ | 1,499.7 |  |
| Free cash flow (non-GAAP) | $ | 1,731.4 |  |  | $ | 1,449.4 |  |  | $ | 1,203.8 |  |

[0001262039-24-000014:mdna:70]
Deferred revenue. Our deferred revenue consists of amounts that have been invoiced but that have not yet been recognized as revenue. The majority of our deferred revenue balance consists of the unrecognized portion of service revenue from FortiGuard and other security subscriptions and FortiCare technical support service contracts, which is recognized as revenue ratably over the service term. We monitor our deferred revenue balance, short term and total deferred revenue growth and the mix of short-term and long-term deferred revenue because deferred revenue represents a significant portion of free cash flow and of revenue to be recognized in future periods. Deferred revenue was $5.74 billion as of December 31, 2023, an increase of $1.09 billion, or 24%, from December 31, 2022. Short term deferred revenue was $2.85 billion as of December 31, 2023, an increase of $499.4 million, or 21%, from December 31, 2022.

[0001262039-24-000014:mdna:71]
Billings (non-GAAP). We define billings as revenue recognized in accordance with generally accepted accounting principles in the United States (“GAAP”) plus the change in deferred revenue from the beginning to the end of the period, less any deferred revenue balances acquired from business combination(s) and adjustment due to adoption of new accounting standard during the period. We consider billings to be a useful metric for management and investors because billings drive current and future revenue, which is an important indicator of the health and viability of our business. There are several

[0001262039-24-000014:mdna:72]
53

[0001262039-24-000014:mdna:73]
limitations related to the use of billings instead of GAAP revenue. First, billings include amounts that have not yet been recognized as revenue and are impacted by the term of FortiGuard security subscription and FortiCare and other support agreements. Second, we may calculate billings in a manner that is different from peer companies that report similar financial measures. Management accounts for these limitations by providing specific information regarding GAAP revenue and evaluating billings together with GAAP revenue. Total billings were $6.40 billion in 2023, an increase of 14% compared to $5.59 billion in 2022.

[0001262039-24-000014:mdna:74]
During 2023, our billings and product revenue fell below our expectations due to a slowdown in secure networking growth, along with challenges in sales execution and marketing programs. In addition, we believe secure networking growth in the near term may be below historical growth rates. In response to the slowdown in the secure networking market, we plan to shift our marketing and sales teams’ focus towards the faster growing SecOps and Unified SASE markets over the next several quarters, while maintaining our continued focus on leading innovation in secure networking and the convergence of security and networking.

[0001262039-24-000014:mdna:75]
We anticipate limited near-term growth in the secure networking market and shifting sales and marketing focus may result in certain risks, including go-to-market challenges, increased sales turnover and other execution challenges.

[0001262039-24-000014:mdna:76]
Our backlog has fluctuated over past quarters and any decrease in growth or negative growth of in-quarter billings and revenue may not be reflected by our aggregate billings and revenue. As we have fulfilled, shipped and billed during a quarter to satisfy backlog, this has increased our aggregate billings and revenue during any particular quarter, and as the supply chain challenges normalize, the growth comparisons versus prior quarters where backlog contributed more to billings have become more challenging.

[0001262039-24-000014:mdna:77]
A reconciliation of revenue, the most directly comparable financial measure calculated and presented in accordance with GAAP, to billings is provided below:

[0001262039-24-000014:mdna:78]
|  | Year Ended December 31, |
| 2023 |  | 2022 |  | 2021 |
| (in millions) |
| Billings: |  |  |  |  |  |
| Revenue | $ | 5,304.8 |  |  | $ | 4,417.4 |  |  | $ | 3,342.2 |  |
| Add: Change in deferred revenue | 1,094.7 |  |  | 1,187.4 |  |  | 847.6 |  |
| Less: Deferred revenue balance acquired in business combinations | — |  |  | (10.8) |  |  | (4.1) |  |
| Less: Adjustment due to adoption of ASU 2021-08 | — |  |  | — |  |  | (4.3) |  |
| Total billings (non-GAAP) | $ | 6,399.5 |  |  | $ | 5,594.0 |  |  | $ | 4,181.4 |  |

[0001262039-24-000014:mdna:79]
Free cash flow (non-GAAP). We define free cash flow as net cash provided by operating activities minus purchases of property and equipment and excluding any significant non-recurring items. We believe free cash flow to be a liquidity measure that provides useful information to management and investors about the amount of cash generated by the business that, after capital expenditures, can be used for strategic opportunities, including repurchasing outstanding common stock, investing in our business, making strategic acquisitions, and strengthening the balance sheet. A limitation of using free cash flow rather than the GAAP measures of cash provided by or used in operating activities, investing activities, and financing activities is that free cash flow does not represent the total increase or decrease in the cash and cash equivalents balance for the period because it excludes cash flows from investing activities other than capital expenditures and cash flows from financing activities. Management accounts for this limitation by providing information about our capital expenditures and other investing and financing activities on the consolidated statements of cash flows and under “—Liquidity and Capital Resources” and by presenting cash flows from investing and financing activities in our reconciliation of free cash flow. In addition, it is important to note that other companies, including companies in our industry, may not use free cash flow, may calculate free cash flow in a different manner than we do or may use other financial measures to evaluate their performance, all of which could reduce the usefulness of free cash flow as a comparative measure. A reconciliation of net cash provided by operating activities, the most directly comparable financial measure calculated and presented in accordance with GAAP, to free cash flow is provided below:

[0001262039-24-000014:mdna:80]
|  | Year Ended December 31, |
| 2023 |  | 2022 |  | 2021 |
| (in millions) |
| Free Cash Flow: |  |  |  |  |  |
| Net cash provided by operating activities | $ | 1,935.5 |  |  | $ | 1,730.6 |  |  | $ | 1,499.7 |  |
| Less: Purchases of property and equipment | (204.1) |  |  | (281.2) |  |  | (295.9) |  |
| Free cash flow (non-GAAP) | $ | 1,731.4 |  |  | $ | 1,449.4 |  |  | $ | 1,203.8 |  |
| Net cash provided by (used in) investing activities | $ | (649.3) |  |  | $ | 763.9 |  |  | $ | (1,325.1) |  |
| Net cash provided by (used in) financing activities | $ | (1,570.4) |  |  | $ | (2,130.3) |  |  | $ | 82.8 |  |

[0001262039-24-000014:mdna:81]
Components of Operating Results

[0001262039-24-000014:mdna:82]
Revenue. We generate the majority of our revenue from sales of our hardware and software products and amortization of amounts included in deferred revenue related to previous sales of FortiGuard security subscription and FortiCare technical support services. We also recognize revenue from cloud security solutions, professional services, and training.

[0001262039-24-000014:mdna:83]
Our total revenue is comprised of:

[0001262039-24-000014:mdna:84]
•Product revenue. Product revenue is primarily generated from sales of our physical and virtual machine appliances. The majority of our product revenue continues to be generated by our secure networking product lines. Product revenue also includes revenue from sales of unified SASE and SecOps technologies. As a percentage of total revenue, our product revenue has varied from quarter to quarter.

[0001262039-24-000014:mdna:85]
•Service revenue. Service revenue is generated primarily from FortiGuard security subscription services and FortiCare technical support services. We recognize revenue from FortiGuard security subscription and FortiCare technical support services ratably over the service term. Our typical contractual support and subscription term is one to five years. We also generate our revenue from other services, for which we recognize revenue as the services are provided, and cloud-based services, for which we recognize revenue as the services are delivered or on a monthly usage basis. As a percentage of total revenue, we continue to expect service revenue to be higher than product revenue. Our service revenue growth rate depends significantly on the growth of our customer base, the expansion of our service bundle offerings, the mix of our product revenue, pricing actions, the expansion and introduction of new service offerings, the attach rate of service contracts to new product sales, and the renewal of service contracts by our existing customers.

[0001262039-24-000014:mdna:86]
Our total cost of revenue is comprised of:

[0001262039-24-000014:mdna:87]
•Cost of product revenue. The majority of the cost of product revenue consists of third-party contract manufacturers’ costs and the costs of materials used in production. Our cost of product revenue also includes supplies, shipping costs, personnel costs associated with logistics and quality control, facility-related costs, excess and obsolete inventory costs, warranty costs and amortization of intangible assets. Personnel costs include compensation benefits and stock-based compensation.

[0001262039-24-000014:mdna:88]
•Cost of service revenue. Cost of service revenue is primarily comprised of personnel costs, third-party repair and contract fulfillment, data center costs, colocation expenses and cloud provider fees, supplies, facility-related costs and amortization of intangible assets.

[0001262039-24-000014:mdna:89]
Gross margin. Gross profit as a percentage of revenue, or gross margin, has been and will continue to be affected by a variety of factors, including the average sales price of our products, product costs, the mix of products sold and the mix of revenue between hardware products, software licenses and services and any excess inventory or other charges. Service revenue and software licenses have higher gross margins compared to hardware products. Overall gross margin in 2024 will be impacted by service and product revenue mix.

[0001262039-24-000014:mdna:90]
Operating expenses. Our operating expenses consist of research and development, sales and marketing and general and administrative expenses. Personnel costs are the most significant component of operating expenses and consist primarily of salaries, benefits, bonuses, sales commissions and stock-based compensation. We expect personnel costs to continue to increase in absolute dollars as we expand our workforce.

[0001262039-24-000014:mdna:91]
•Research and development. Research and development expense consists primarily of personnel costs. Additional research and development expenses include ASIC and system prototypes and certification-related

[0001262039-24-000014:mdna:92]
expenses, depreciation of property and equipment and facility-related expenses. The majority of our research and development is focused on software and hardware development. We record research and development expenses as incurred. As of December 31, 2023, approximately 80%, 8%, 4%, 3% and 3% of our research and development teams were located in North America, India, Japan, Taiwan and Israel, respectively. As of December 31, 2023, approximately two-thirds of our engineers worked on software development while the remainder worked on hardware development.

[0001262039-24-000014:mdna:93]
•Sales and marketing. Sales and marketing expense is the largest component of our operating expenses and primarily consists of personnel costs. Additional sales and marketing expenses include product marketing, public relations, field marketing and events and channel marketing programs (e.g., partner cooperative marketing arrangements), as well as travel, depreciation of property and equipment and facility-related expenses. We intend to hire additional personnel focused on sales and marketing and expand our sales and marketing efforts worldwide in order to capture market share.

[0001262039-24-000014:mdna:94]
•General and administrative. General and administrative expense consists of personnel costs, as well as professional fees, depreciation of property and equipment and software and facility-related expenses. General and administrative personnel include our executive, finance, human resources, information technology and legal organizations. Our professional fees principally consist of outside legal, auditing, tax, information technology and other consulting costs.

[0001262039-24-000014:mdna:95]
Interest income. Interest income consists primarily of interest earned on our cash equivalents and investments. Historically, our interest-bearing investments include corporate debt securities, certificates of deposit and term deposits, commercial paper, money market funds, U.S. government and agency securities and municipal bonds.

[0001262039-24-000014:mdna:96]
Interest expense. Interest expense consists of interest expense due to the senior notes and other miscellaneous interest expense.

[0001262039-24-000014:mdna:97]
Other expense—net. Other expense—net consists primarily of foreign exchange gains and losses related to foreign currency remeasurement, gains or losses due to the changes in fair value of our marketable equity securities, realized gains and losses of available-for-sale investments, net rental income from real estate, as well as the gain on the sale or the impairment of investments in privately held companies without readily determinable fair values, which are not accounted for under the equity method.

[0001262039-24-000014:mdna:98]
Provision for income taxes. We are subject to income taxes in the United States, as well as other tax jurisdictions or countries in which we conduct business. Earnings from our non-U.S. activities are subject to income taxes in local countries and may be subject to U.S. income taxes. Our effective tax rate differs from the U.S. statutory rate primarily due to foreign income subject to different tax rates than in the U.S., federal research and development tax credit, state income taxes, withholding taxes, excess tax benefits related to stock-based compensation expense and the tax impacts of the foreign-derived intangible income (“FDII”) deduction.

[0001262039-24-000014:mdna:99]
Loss from equity method investments. Loss from equity method investments consists of our proportionate share of the investees’ net loss, the amortization of any basis differences, as well as any other-than-temporary impairment (“OTTI”) when events or circumstances suggest that the carrying amount of the investment may be impaired.

[0001262039-24-000014:mdna:100]
Critical Accounting Policies and Estimates

[0001262039-24-000014:mdna:101]
Our discussion and analysis of our financial condition and results of operations are based upon our financial statements, which have been prepared in accordance with GAAP. These principles require us to make estimates and judgments that affect the reported amounts of assets, liabilities, revenue, cost of revenue and expenses, and related disclosures. We base our estimates on historical experience and on various other assumptions that we believe to be reasonable under the circumstances. To the extent that there are material differences between these estimates and our actual results, our future financial statements will be affected.

[0001262039-24-000014:mdna:102]
We believe that, of the significant accounting policies described in Note 1 to our consolidated financial statements included in Part II, Item 8 of this Annual Report on Form 10-K, the following accounting policies involve a greater degree of judgment and complexity. Accordingly, we believe these are the most critical to fully understand and evaluate our financial condition and results of operations.

[0001262039-24-000014:mdna:103]
Revenue Recognition

[0001262039-24-000014:mdna:104]
Revenues are recognized when control of goods or services is transferred to our customers, in an amount that reflects the consideration we expect to be entitled to in exchange for those goods or services.

[0001262039-24-000014:mdna:105]
We determine revenue recognition through the following steps:

[0001262039-24-000014:mdna:106]
•identification of a contract or contracts with a customer;

[0001262039-24-000014:mdna:107]
•identification of the performance obligations in a contract, including evaluation of performance obligations as to being distinct goods or services in a contract;

[0001262039-24-000014:mdna:108]
•determination of a transaction price;

[0001262039-24-000014:mdna:109]
•allocation of a transaction price to the performance obligations in a contract; and

[0001262039-24-000014:mdna:110]
•recognition of revenue when, or as, we satisfy a performance obligation.

[0001262039-24-000014:mdna:111]
Our sales contracts typically contain multiple deliverables, such as hardware, software license, security subscription, technical support services and other services, which are generally capable of being distinct and accounted for as separate performance obligations. Our hardware and software licenses have significant standalone functionalities and capabilities. Accordingly, the hardware and software licenses are distinct from the security subscription and technical support services, as a customer can benefit from the product without the services and the services are separately identifiable within a contract. We allocate a transaction price to each performance obligation based on relative standalone selling price. We establish standalone selling price using the prices charged for a deliverable when sold separately. If not observable through past transactions, we determine standalone selling price by considering multiple historical factors including, but not limited to, cost of products, gross margin objectives, pricing practices, geographies and the term of a service contract.

[0001262039-24-000014:mdna:112]
Deferred Contract Costs and Commission Expense

[0001262039-24-000014:mdna:113]
We defer contract costs that are recoverable and incremental to obtaining customer sales contracts. Contract costs, which primarily consist of sales commissions, are amortized on a systematic basis that is consistent with the transfer to the customer of the goods or services to which the asset relates. Costs for initial contracts that are not commensurate with commissions on renewal contracts are amortized on a straight-line basis over the period of benefit of five years. Estimates, assumptions, and judgments in accounting for deferred contract costs include, but are not limited to, identification of contract costs, anticipated billings and the expected period of benefit.

[0001262039-24-000014:mdna:114]
Business Combinations

[0001262039-24-000014:mdna:115]
We include the results of operations of the businesses that we acquire as of the respective dates of acquisition. We allocate the fair value of the purchase price of our business acquisitions to the tangible and intangible assets acquired and liabilities assumed based on their estimated fair values. The excess of the purchase price over the fair values of these identifiable assets and liabilities is recorded as goodwill. We often continue to gather additional information throughout the measurement period, and if we make changes to the amounts recorded, such changes are recorded in the period in which they are identified.

[0001262039-24-000014:mdna:116]
Contingent Liabilities

[0001262039-24-000014:mdna:117]
From time to time, we are involved in disputes, litigation and other legal actions. However, there are many uncertainties associated with any litigation, and these actions or other third-party claims against us may cause us to incur substantial settlement charges, which are inherently difficult to estimate and could adversely affect our results of operations. We periodically review significant claims and litigation matters for the probability of an adverse outcome. We accrue for a loss contingency if a loss is probable and the amount of the loss can be reasonably estimated. These accruals are generally based on a range of possible outcomes that require significant judgement. Estimates can change as individual claims develop. The actual liability in any such matters may be materially different from our estimates, which could result in the need to adjust our liability and record additional expenses.

[0001262039-24-000014:mdna:118]
Accounting for Income Taxes

[0001262039-24-000014:mdna:119]
We record income taxes using the asset and liability method, which requires the recognition of deferred tax assets and liabilities for the expected future tax consequences of events that have been recognized in our financial statements or tax returns. In addition, deferred tax assets are recorded for the future benefit of utilizing net operating losses and research and development credit carryforwards. Deferred tax assets and liabilities are measured using the currently enacted tax rates that

[0001262039-24-000014:mdna:120]
57

[0001262039-24-000014:mdna:121]
apply to taxable income in effect for the years in which those tax assets and liabilities are expected to be realized or settled. Valuation allowances are provided when necessary to reduce deferred tax assets to the amount expected to be realized.

[0001262039-24-000014:mdna:122]
As part of the process of preparing our consolidated financial statements, we are required to estimate our taxes in each of the jurisdictions in which we operate. We estimate actual current tax exposure together with assessing temporary differences resulting from differing treatment of items, such as accruals and allowances not currently deductible for tax purposes. These differences result in deferred tax assets, which are included in our consolidated balance sheets. In general, deferred tax assets represent future tax benefits to be received when certain expenses previously recognized in our consolidated statements of income become deductible expenses under applicable income tax laws, or loss or credit carryforwards are utilized.

[0001262039-24-000014:mdna:123]
In assessing the realizability of deferred tax assets, management considers whether it is more likely than not that some portion or all of the deferred tax assets will be realized. The ultimate realization of deferred tax assets is dependent upon the generation of future taxable income during the periods in which those temporary differences become deductible. We continue to assess the need for a valuation allowance on the deferred tax assets by evaluating both positive and negative evidence that may exist. Any adjustment to the valuation allowance on deferred tax assets would be recorded in the consolidated statements of income for the period that the adjustment is determined to be required.

[0001262039-24-000014:mdna:124]
We recognize tax benefits from an uncertain tax position only if it is more likely than not, based on the technical merits of the position that the tax position will be sustained on examination by the tax authorities. The tax benefits recognized in the financial statements from such positions are then measured based on the largest benefit that has a greater than 50% likelihood of being realized upon ultimate settlement.

[0001262039-24-000014:mdna:125]
We have elected to account for the tax effect of the Global Intangible Low-Taxed Income (“GILTI”) as a current period expense.

[0001262039-24-000014:mdna:126]
58

[0001262039-24-000014:mdna:127]
Results of Operations

[0001262039-24-000014:mdna:128]
The following tables set forth our results of operations for the periods presented and as a percentage of our total revenue for those periods. The period-to-period comparison of financial results is not necessarily indicative of financial results to be achieved in future periods.

[0001262039-24-000014:mdna:129]
|  | Year Ended December 31, |
|  | 2023 |  | 2022 |  | 2021 |
|  | (in millions) |
| Consolidated Statements of Income Data: |  |  |  |  |  |
| Revenue: |  |  |  |  |  |
| Product | $ | 1,927.3 |  |  | $ | 1,780.5 |  |  | $ | 1,255.0 |  |
| Service | 3,377.5 |  |  | 2,636.9 |  |  | 2,087.2 |  |
| Total revenue | 5,304.8 |  |  | 4,417.4 |  |  | 3,342.2 |  |
| Cost of revenue: |  |  |  |  |  |
| Product | 763.6 |  |  | 691.3 |  |  | 487.7 |  |
| Service | 473.6 |  |  | 393.6 |  |  | 295.3 |  |
| Total cost of revenue | 1,237.2 |  |  | 1,084.9 |  |  | 783.0 |  |
| Gross profit: |  |  |  |  |  |
| Product | 1,163.7 |  |  | 1,089.2 |  |  | 767.3 |  |
| Service | 2,903.9 |  |  | 2,243.3 |  |  | 1,791.9 |  |
| Total gross profit | 4,067.6 |  |  | 3,332.5 |  |  | 2,559.2 |  |
| Operating expenses: |  |  |  |  |  |
| Research and development | 613.8 |  |  | 512.4 |  |  | 424.2 |  |
| Sales and marketing | 2,006.0 |  |  | 1,686.1 |  |  | 1,345.7 |  |
| General and administrative | 211.3 |  |  | 169.0 |  |  | 143.5 |  |
| Gain on intellectual property matter | (4.6) |  |  | (4.6) |  |  | (4.6) |  |
| Total operating expenses | 2,826.5 |  |  | 2,362.9 |  |  | 1,908.8 |  |
| Operating income | 1,241.1 |  |  | 969.6 |  |  | 650.4 |  |
| Interest income | 119.7 |  |  | 17.4 |  |  | 4.5 |  |
| Interest expense | (21.0) |  |  | (18.0) |  |  | (14.9) |  |
| Other expense—net | (6.1) |  |  | (13.5) |  |  | (11.6) |  |
| Income before income taxes and loss from equity method investments | 1,333.7 |  |  | 955.5 |  |  | 628.4 |  |
| Provision for income taxes | 143.8 |  |  | 30.8 |  |  | 14.1 |  |
| Loss from equity method investments | (42.1) |  |  | (68.1) |  |  | (7.6) |  |
| Net income including non-controlling interests | 1,147.8 |  |  | 856.6 |  |  | 606.7 |  |
| Less: net loss attributable to non-controlling interests, net of tax | — |  |  | (0.7) |  |  | (0.1) |  |
| Net income attributable to Fortinet, Inc. | $ | 1,147.8 |  |  | $ | 857.3 |  |  | $ | 606.8 |  |

[0001262039-24-000014:mdna:130]
|  | Year Ended December 31, |
| 2023 |  | 2022 |  | 2021 |
| (as percentage of revenue) |
| Revenue: |  |  |  |  |  |
| Product | 36 | % |  | 40 | % |  | 38 | % |
| Service | 64 |  |  | 60 |  |  | 62 |  |
| Total revenue | 100 |  |  | 100 |  |  | 100 |  |
| Cost of revenue: |  |  |  |  |  |
| Product | 14 |  |  | 16 |  |  | 15 |  |
| Service | 9 |  |  | 9 |  |  | 9 |  |
| Total cost of revenue | 23 |  |  | 25 |  |  | 23 |  |
| Gross margin: |  |  |  |  |  |
| Product | 60 |  |  | 61 |  |  | 61 |  |
| Service | 86 |  |  | 85 |  |  | 86 |  |
| Total gross margin | 77 |  |  | 75 |  |  | 77 |  |
| Operating expenses: |  |  |  |  |  |
| Research and development | 12 |  |  | 12 |  |  | 13 |  |
| Sales and marketing | 38 |  |  | 38 |  |  | 40 |  |
| General and administrative | 4 |  |  | 4 |  |  | 4 |  |
| Gain on intellectual property matter | — |  |  | — |  |  | — |  |
| Total operating expenses | 53 |  |  | 53 |  |  | 57 |  |
| Operating margin | 23 |  |  | 22 |  |  | 19 |  |
| Interest income | 2 |  |  | — |  |  | — |  |
| Interest expense | — |  |  | — |  |  | — |  |
| Other expense—net | — |  |  | — |  |  | — |  |
| Income before income taxes and loss from equity method investments | 25 |  |  | 22 |  |  | 19 |  |
| Provision for income taxes | 3 |  |  | 1 |  |  | — |  |
| Loss from equity method investments | (1) |  |  | (2) |  |  | — |  |
| Net income including non-controlling interests | 22 |  |  | 19 |  |  | 18 |  |
| Less: net loss attributable to non-controlling interests, net of tax | — |  |  | — |  |  | — |  |
| Net income attributable to Fortinet, Inc. | 22 | % |  | 19 | % |  | 18 | % |
| Percentages have been rounded for presentation purposes and may differ from unrounded results. |

[0001262039-24-000014:mdna:131]
Discussion regarding our financial condition and results of operations for 2022 as compared to 2021 can be found in Item 7 of our Annual Report on Form 10-K for the fiscal year ended December 31, 2022, filed with the SEC on February 24, 2023.

[0001262039-24-000014:mdna:132]
60

[0001262039-24-000014:mdna:133]
2023 and 2022

[0001262039-24-000014:mdna:134]
Revenue

[0001262039-24-000014:mdna:135]
|  | Year Ended December 31, |  |  |  |  |
| 2023 |  | 2022 |  |  |  |  |
| Amount |  | % ofRevenue |  | Amount |  | % ofRevenue |  | Change |  | % Change |
| (in millions, except percentages) |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 1,927.3 |  |  | 36 | % |  | $ | 1,780.5 |  |  | 40 | % |  | $ | 146.8 |  |  | 8 | % |
| Service | 3,377.5 |  |  | 64 |  |  | 2,636.9 |  |  | 60 |  |  | 740.6 |  |  | 28 |  |
| Total revenue | $ | 5,304.8 |  |  | 100 | % |  | $ | 4,417.4 |  |  | 100 | % |  | $ | 887.4 |  |  | 20 | % |
| Revenue by geography: |  |  |  |  |  |  |  |  |  |  |  |
| Americas | $ | 2,175.2 |  |  | 41 | % |  | $ | 1,785.0 |  |  | 41 | % |  | $ | 390.2 |  |  | 22 | % |
| EMEA | 2,072.9 |  |  | 39 |  |  | 1,691.8 |  |  | 38 |  |  | 381.1 |  |  | 23 |  |
| APAC | 1,056.7 |  |  | 20 |  |  | 940.6 |  |  | 21 |  |  | 116.1 |  |  | 12 |  |
| Total revenue | $ | 5,304.8 |  |  | 100 | % |  | $ | 4,417.4 |  |  | 100 | % |  | $ | 887.4 |  |  | 20 | % |

[0001262039-24-000014:mdna:136]
Total revenue increased $887.4 million, or 20%, in 2023 compared to 2022. We continued to experience large organic revenue growth (i.e., revenue growth excluding attribution from recent acquisitions) with diversification of revenue geographically, and across both customer and industry segments. Revenue from all regions grew, with the Americas contributing the largest portion of the increase on an absolute dollar basis and EMEA, contributing the largest portion of the increase on a percentage basis.

[0001262039-24-000014:mdna:137]
Product revenue increased $146.8 million, or 8%, in 2023 compared to 2022. Product revenue growth was impacted by an elevated cyber threat landscape, the convergence of security and networking, the impact of certain historical pricing actions, improving supply chain dynamics, and changes in the backlog balance. Product revenue growth rates decreased from 42% in 2022 to 8% in 2023 partially due to overall softening macroeconomic conditions.

[0001262039-24-000014:mdna:138]
Service revenue increased $740.6 million, or 28%, in 2023 compared to 2022. Service revenue growth has accelerated over the past three years from 24% in 2021, to 26% in 2022 to 28% in 2023. Compared to 2022, FortiGuard security subscription revenue and other security subscription revenue increased $471.1 million, or 33% and FortiCare, other technical support and other revenues increased $269.5 million, or 22%, in 2023. The increases in service revenue were primarily due to the recognition of revenue from our growing deferred revenue balance related to FortiGuard and other security subscriptions delivered to on-premise and cloud-based environments. Security subscriptions outpaced technical support growth due to strength in secure networking subscriptions, SecOps and SASE.

[0001262039-24-000014:mdna:139]
Of the service revenue recognized in 2023, 67% was included in the deferred revenue balance as of December 31, 2022. Of the service revenue recognized in 2022, 66% was included in the deferred revenue balance as of December 31, 2021.

[0001262039-24-000014:mdna:140]
Of the service revenue recognized in each quarter of 2023, from 88% to 89% was included in deferred revenue as of the beginning of the respective quarter.

[0001262039-24-000014:mdna:141]
61

[0001262039-24-000014:mdna:142]
Cost of revenue and gross margin

[0001262039-24-000014:mdna:143]
|  | Year Ended December 31, |  |  |  |  |  |  |  |  |
| 2023 |  | 2022 |  | Change |  | % Change |  |  |  |  |
| (in millions, except percentages) |  |  |  |  |
| Cost of revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 763.6 |  |  | $ | 691.3 |  |  | $ | 72.3 |  |  | 11 | % |  |  |  |  |
| Service | 473.6 |  |  | 393.6 |  |  | 80.0 |  |  | 20 |  |  |  |  |  |
| Total cost of revenue | $ | 1,237.2 |  |  | $ | 1,084.9 |  |  | $ | 152.3 |  |  | 14 | % |  |  |  |  |
| Gross margin (%): |  |  |  |  |  |  |  |  |  |  |  |
| Product | 60.4 | % |  | 61.2 | % |  |  |  |  |  |  |  |  |
| Service | 86.0 | % |  | 85.1 | % |  |  |  |  |  |  |  |  |
| Total gross margin | 76.7 | % |  | 75.4 | % |  |  |  |  |  |  |  |  |
| Percentages have been rounded for presentation purposes and may differ from unrounded results. |

[0001262039-24-000014:mdna:144]
Total gross margin increased 1.3 percentage points in 2023 compared to 2022, primarily driven by a shift in the revenue mix and increased service gross margin, partially offset by decreased product gross margin. Revenue mix shifted by 4.0 percentage points from product revenue to service revenue, as a percentage of total revenue.

[0001262039-24-000014:mdna:145]
Product gross margin decreased 0.8 percentage points in 2023 compared to 2022, primarily due to inventory related reserves expense, partially offset by lower expedite fees and freight costs and a shift in revenue mix from hardware to software. Cost of product revenue was comprised primarily of third-party contract manufacturers’ costs, costs of materials used in production and inventory reserves.

[0001262039-24-000014:mdna:146]
Service gross margin increased 0.9 percentage points in 2023 compared to 2022, primarily driven by pricing actions in earlier periods and benefited from the mix shift towards higher margin security subscription services. Cost of service revenue was comprised primarily of personnel costs, third-party repair and contract fulfillment, data center costs, colocation expenses and cloud hosting, supplies and facility-related costs.

[0001262039-24-000014:mdna:147]
Operating expenses

[0001262039-24-000014:mdna:148]
|  | Year Ended December 31, |  | Change |  | % Change |
| 2023 |  | 2022 |  |
| Amount |  | % ofRevenue |  | Amount |  | % ofRevenue |  |
| (in millions, except percentages) |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | $ | 613.8 |  |  | 12 | % |  | $ | 512.4 |  |  | 12 | % |  | $ | 101.4 |  |  | 20 | % |
| Sales and marketing | 2,006.0 |  |  | 38 |  |  | 1,686.1 |  |  | 38 |  |  | 319.9 |  |  | 19 |  |
| General and administrative | 211.3 |  |  | 4 |  |  | 169.0 |  |  | 4 |  |  | 42.3 |  |  | 25 |  |
| Gain on intellectual property matter | (4.6) |  |  | — |  |  | (4.6) |  |  | — |  |  | — |  |  | — |  |
| Total operating expenses | $ | 2,826.5 |  |  | 53 | % |  | $ | 2,362.9 |  |  | 53 | % |  | $ | 463.6 |  |  | 20 | % |
| Percentages have been rounded for presentation purposes and may differ from unrounded results. |

[0001262039-24-000014:mdna:149]
Research and development

[0001262039-24-000014:mdna:150]
Research and development expense increased $101.4 million, or 20%, in 2023 compared to 2022, primarily due to an increase of $74.3 million in personnel-related costs as a result of increased headcount and compensation rates to support the development of new products and continued enhancements to our existing products. In addition, non-personnel-related product development costs increased $13.8 million and depreciation expense and other occupancy-related expense increased $11.4 million. We currently intend to continue to invest in our research and development organization, and expect research and development expense to increase in absolute dollars in 2024.

[0001262039-24-000014:mdna:151]
62

[0001262039-24-000014:mdna:152]
Sales and marketing

[0001262039-24-000014:mdna:153]
Sales and marketing expense increased $319.9 million, or 19%, in 2023 compared to 2022, primarily due to an increase of $244.3 million in personnel-related costs. We increased our sales and pipeline generation capacity. The increase in headcount is expected to help drive global market revenue increases. In addition, marketing-related expenses increased $23.5 million, travel expense increased $20.7 million and depreciation expense and other occupancy-related expense increased $18.4 million. We currently intend to continue to make investments in sales and marketing resources, which are critical to support our future growth, and expect sales and marketing expense to increase in absolute dollars in 2024.

[0001262039-24-000014:mdna:154]
General and administrative

[0001262039-24-000014:mdna:155]
General and administrative expense increased $42.3 million, or 25%, in 2023 compared to 2022, primarily due to an increase of $19.2 million in professional services fees, an increase of $14.6 million in personnel-related costs and an increase of $3.4 million in provision for expected credit losses. We currently expect general and administrative expense to increase in absolute dollars in 2024.

[0001262039-24-000014:mdna:156]
Operating income and margin

[0001262039-24-000014:mdna:157]
We generated operating income of $1.24 billion in 2023, an increase of $271.5 million, or 28%, compared to $969.6 million in 2022. Operating income as a percentage of revenue increased to 23.4% in 2023 compared to 21.9% in 2022. The increase in our operating margin primarily benefits from a 1.3 percentage points increase in gross margin and 0.4 percentage points decrease in sales and marketing expense as a percentage of revenue, partially offset by 0.2 percentage points increase in general and administrative expense as percentage of revenue.

[0001262039-24-000014:mdna:158]
Interest income, interest expense and other expense—net

[0001262039-24-000014:mdna:159]
|  | Year Ended December 31, |  |  |  |  |
| 2023 |  | 2022 |  | Change |  | % Change |
| (in millions, except percentages) |
| Interest income | $ | 119.7 |  |  | $ | 17.4 |  |  | $ | 102.3 |  |  | 588 | % |
| Interest expense | (21.0) |  |  | (18.0) |  |  | (3.0) |  |  | 17 | % |
| Other expense—net | (6.1) |  |  | (13.5) |  |  | 7.4 |  |  | (55) | % |

[0001262039-24-000014:mdna:160]
Interest income increased $102.3 million in 2023 as compared to 2022, primarily as a result of higher interest rates and investment balances. Interest income varies depending on our average investment balances during the period, types and mix of investments, and market interest rates. Interest expense increased $3.0 million in 2023 as compared to 2022. Other expense—net decreased $7.4 million in 2023 as compared to 2022 due to an $8.7 million lower loss on marketable equity securities and a $1.0 million increase of net rental income from real estate, partially offset by a $2.4 million increase of foreign exchange losses.

[0001262039-24-000014:mdna:161]
Provision for income taxes

[0001262039-24-000014:mdna:162]
|  | Year Ended December 31, |  | Change |  | % Change |
| 2023 |  | 2022 |  |
| (in millions, except percentages) |
| Provision for income taxes | $ | 143.8 |  |  | $ | 30.8 |  |  | $ | 113.0 |  |  | 367 | % |
| Effective tax rate (%) | 11 | % |  | 3 | % |  |  |  |  |

[0001262039-24-000014:mdna:163]
Our provision for income taxes for 2023 reflects an effective tax rate of 11%, compared to an effective tax rate of 3% for 2022. The provision for income taxes for 2023 was comprised primarily of a $302.4 million tax expense related to U.S. federal and state income taxes, other foreign income taxes, foreign withholding taxes and unrecognized tax benefits. The provision was partially offset by excess tax benefits of $55.1 million from stock-based compensation expense, a tax benefit of $89.5 million from the FDII deduction, and a tax benefit of $14.0 million from federal research and development tax credits.

[0001262039-24-000014:mdna:164]
Our provision for income taxes for 2022 reflects an effective tax rate of 3%, compared to an effective tax rate of 2% for 2021. The provision for income taxes for 2022 was comprised primarily of a $233.4 million tax expense related to U.S. federal and state income taxes, other foreign income taxes, foreign withholding taxes and unrecognized tax benefits. The provision was partially offset by excess tax benefits of $75.8 million from stock-based compensation expense, a tax benefit of $115.2 million from the FDII deduction, and a tax benefit of $11.6 million from federal research and development tax credits.

[0001262039-24-000014:mdna:165]
Loss from Equity Method Investments

[0001262039-24-000014:mdna:166]
|  | Year Ended December 31, |  | Change |  | % Change |
| 2023 |  | 2022 |  |
| (in millions, except percentages) |
| Loss from equity method investments | $ | (42.1) |  |  | $ | (68.1) |  |  | $ | 26.0 |  |  | (38) | % |

[0001262039-24-000014:mdna:167]
Loss from equity method investments decreased $26.0 million in 2023 as compared to 2022, as our proportionate share of Linksys’ financial results including our share of the amortization of the basis differences improved over the same period last year. Our loss related to Linksys in fiscal 2022 totaled $68.1 million, comprised our proportionate share of Linksys’ financial results as well as the amortization of the basis differences of $45.9 million, which included a $17.5 million charge in connection with a valuation allowance established on deferred tax assets at Linksys, and the OTTI charge of $22.2 million recorded during the three months ended December 31,2022.

[0001262039-24-000014:mdna:168]
Seasonality, Cyclicality and Quarterly Revenue Trends

[0001262039-24-000014:mdna:169]
Our quarterly results reflect a pattern of increased customer buying at year-end, which has positively impacted billings and product revenue activity in the fourth quarter. In the first quarter, we generally experience lower sequential customer product buying, followed by an increase in buying in the second and third quarters. Although these seasonal factors may be common in the technology sector, historical patterns should not be considered a reliable indicator of our future sales activity or performance. On a quarterly basis, we have usually generated the majority of our product revenue in the final month of each quarter and a significant amount in the last two weeks of each quarter. We believe this is due to customer buying patterns typical in this industry.

[0001262039-24-000014:mdna:170]
Our quarterly revenue over the past two years has increased sequentially each quarter within the year.

[0001262039-24-000014:mdna:171]
Total gross margin has fluctuated on a quarterly basis primarily due to the relative product and service mix. Product gross margin varies based on the types of products sold, their cost profile and their average selling prices. Service gross margin is impacted by revenue growth and our personnel-related costs, third-party repair and contract fulfillment, data center, colocation fees, cloud hosting, supplies, facility-related costs and foreign currency fluctuations.

[0001262039-24-000014:mdna:172]
Liquidity and Capital Resources

[0001262039-24-000014:mdna:173]
|  | As of December 31, |
|  | 2023 |  | 2022 |  | 2021 |
|  | (in millions) |
| Cash and cash equivalents | $ | 1,397.9 |  |  | $ | 1,682.9 |  |  | $ | 1,319.1 |  |
| Short-term and long-term investments | 1,021.5 |  |  | 548.1 |  |  | 1,634.8 |  |
| Marketable equity securities | 21.0 |  |  | 25.5 |  | 38.6 |  |
| Total cash, cash equivalents, investments and marketable equity securities | $ | 2,440.4 |  |  | $ | 2,256.5 |  |  | $ | 2,992.5 |  |
| Working capital | $ | 709.3 |  |  | $ | 732.0 |  |  | $ | 1,282.5 |  |
|  | Year Ended December 31, |
|  | 2023 |  | 2022 |  | 2021 |
|  | (in millions) |
| Net cash provided by operating activities | $ | 1,935.5 |  |  | $ | 1,730.6 |  |  | $ | 1,499.7 |  |
| Net cash provided by (used in) investing activities | (649.3) |  |  | 763.9 |  |  | (1,325.1) |  |
| Net cash provided by (used in) financing activities | (1,570.4) |  |  | (2,130.3) |  |  | 82.8 |  |
| Effect of exchange rate changes on cash and cash equivalents | (0.8) |  |  | (0.4) |  |  | (0.1) |  |
| Net increase (decrease) in cash and cash equivalents | $ | (285.0) |  |  | $ | 363.8 |  |  | $ | 257.3 |  |

[0001262039-24-000014:mdna:174]
Liquidity and capital resources are primarily impacted by our operating activities, proceeds from issuance of our investment grade debt, as well as cash used on stock repurchases, real estate purchases and other capital expenditures, investments in various companies and business acquisitions.

[0001262039-24-000014:mdna:175]
64

[0001262039-24-000014:mdna:176]
In recent years, we have received significant capital resources from our billings to customers, issuance of investment grade debt and, to some extent, from the exercise of stock options by our employees. Additional increases in billings may depend on a number of factors, including demand for and availability of our products and services, competition, pricing actions, market or industry changes, macroeconomic events such as rising inflation and interest rates, economic strength, supply chain capacity and disruptions, international conflicts, including the war in Ukraine and the Israel-Hamas war, and our ability to execute. We expect proceeds from the exercise of stock options in future years to be impacted by the increased mix of restricted stock units and performance stock units versus stock options granted to our employees and to vary based on our share price. We expect our cash tax payments to increase as a result of a provision in the Tax Cuts and Jobs Act of 2017 requiring taxpayers to capitalize and amortize research and development expenses for tax purposes, other tax law changes and our expected growth.

[0001262039-24-000014:mdna:177]
In February 2023, our board of directors approved an extension of the Repurchase Program to February 29, 2024. In April 2023 and July 2023, our board of directors approved $1.0 billion and $500.0 million increases in the authorized stock repurchase amount under the Repurchase Program, respectively, bringing the aggregate amount authorized to be repurchased to $6.75 billion. In 2023, we repurchased 27.2 million shares of common stock under the Repurchase Program for an aggregate purchase price of $1.50 billion. As of December 31, 2023, $529.1 million remained available for future share repurchases under the Repurchase Program. In January 2024, our board of directors approved a $500.0 million increase in the authorized stock repurchase amount under the Repurchase Program, bringing the aggregate amount authorized to be repurchased to $7.25 billion of our outstanding common stock. In February 2024, our board of directors approved an extension of the Repurchase Program to February 28, 2025. As of February 23, 2024, approximately $1.03 billion remained available for future share repurchases.

[0001262039-24-000014:mdna:178]
In March 2021, we issued $1.0 billion aggregate principal amount of senior notes, consisting of $500.0 million aggregate principal amount of 1.0% notes due March 15, 2026 and $500.0 million aggregate principal amount of 2.2% notes due March 15, 2031, in an underwritten registered public offering. We do not currently intend to retire these senior notes early. Refer to Note 11. Debt in Part II, Item 8 of this Annual Report on Form 10-K for information on the senior notes.

[0001262039-24-000014:mdna:179]
We expect to continue to increase our data centers, PoPs, office and warehouse capacity to support growth and the expansion of existing services or introduction of new services. As we purchase new properties, we will work to incorporate these properties into the environmental goals we have established. We estimate 2024 capital expenditures to be between $370.0 million and $420.0 million.

[0001262039-24-000014:mdna:180]
Our principal commitments consist of obligations under our senior notes, inventory purchase and other contractual commitments. As of December 31, 2023, the long-term debt, net of unamortized discount and debt issuance costs, was $992.3 million. $500.0 million in aggregate principal amount of senior notes is due on March 15, 2026 and $500.0 million in aggregate principal amount of senior notes is due on March 15, 2031. In addition, we enter into non-cancellable agreements with contract manufacturers to procure inventory based on our requirements in order to reduce manufacturing lead times, plan for adequate component supply or incentivize suppliers to deliver. In certain instances, these agreements allow us the option to reschedule and adjust our requirements based on our business needs prior to firm orders being placed. In 2023, we have seen supply chain constraints gradually improve as we continued to work with contract manufacturers and component suppliers to decrease and optimize our non-cancellable inventory purchase commitments. Inventory purchase commitments as of December 31, 2023, were $637.3 million, a decrease of $697.7 million compared to $1.34 billion as of December 31, 2022. We estimate payments of $381.5 million due on or before December 31, 2024 related to these commitments. We also have open purchase orders and contractual obligations in the ordinary course of business for which we have not received goods or services. As of December 31, 2023, we had $66.9 million in other contractual commitments having a remaining term in excess of one year that are non-cancelable.

[0001262039-24-000014:mdna:181]
As of December 31, 2023, our cash, cash equivalents and short-term and long-term investments of $2.44 billion were invested primarily in deposit accounts, commercial paper, corporate debt securities, U.S. government and agency securities, certificates of deposit and term deposits, money market funds, municipal bonds. It is our investment policy to invest excess cash in a manner that preserves capital, provides liquidity and generates return without significantly increasing risk. We do not enter into investments for trading or speculative purposes.

[0001262039-24-000014:mdna:182]
The amount of cash, cash equivalents and investments held by our international subsidiaries was $199.9 million and $218.1 million as of December 31, 2023 and 2022, respectively.

[0001262039-24-000014:mdna:183]
We believe that our existing cash and cash equivalents and cash flow from operations will be sufficient for at least the next 12 months to meet our requirements and plans for cash, including meeting our working capital requirements and capital expenditure requirements. In the long term, our ability to support our requirements and plans for cash, including our working capital and capital expenditure requirements will depend on many factors, including our growth rate; the timing and amount of our share repurchases; the expansion of sales and marketing activities, pricing actions, the introduction of new and enhanced products and services offerings; the continuing market acceptance of our products; the timing and extent of spending to support development efforts; our investments in purchasing, developing or leasing real estate; cash tax payments and macroeconomic impacts such as rising inflation and interest rates; the war in Ukraine and the Israel-Hamas war; and instability in the global

[0001262039-24-000014:mdna:184]
banking system. Historically, we have required capital principally to fund our working capital needs, share repurchases, capital expenditures and acquisition activities. In the event that additional financing is required from outside sources, we may not be able to raise it on terms acceptable to us or at all.

[0001262039-24-000014:mdna:185]
During 2023, 2022 and 2021, we did not have any relationships with unconsolidated organizations or financial partnerships, such as structured finance or special purpose entities that would have been established for the purpose of facilitating off-balance sheet arrangements or other contractually narrow or limited purposes.

[0001262039-24-000014:mdna:186]
Operating Activities

[0001262039-24-000014:mdna:187]
Cash generated by operating activities is our primary source of liquidity. It is primarily comprised of net income, as adjusted for non-cash items and changes in operating assets and liabilities. Non-cash adjustments consist primarily of amortization of deferred contract costs, stock-based compensation and depreciation and amortization. Changes in operating assets and liabilities consist primarily of changes in deferred revenue, deferred contract costs, deferred tax assets, inventory and accounts receivable—net.

[0001262039-24-000014:mdna:188]
Our operating activities during 2023 provided cash flows of $1.94 billion as a result of the continued growth of our business, improved profitability and our ability to successfully manage our working capital. Changes in operating assets and liabilities primarily resulted from an increase in sales of our security subscription services and technical support services to new and existing customers, as reflected by an increase of $1.10 billion in our deferred revenue during 2023. In addition, changes in operating assets and liabilities were driven by an increase of $353.5 million in deferred contract costs, an increase of $301.9 million in deferred tax assets, an increase of $253.5 million in inventory and an increase of $146.4 million in accounts receivable—net.

[0001262039-24-000014:mdna:189]
Investing Activities

[0001262039-24-000014:mdna:190]
The changes in cash flows from investing activities primarily relate to timing of purchases, maturities and sales of investments, purchases of property and equipment, investments in various companies and business acquisitions. Historically, in making a lease-versus-ownership decision related to warehouse, office or data center space, we have considered various factors including financial metrics, expected long-term growth rates, time to market and changes in asset values. In certain cases, we have elected to own a facility if we believe that purchasing or developing buildings rather than leasing is more closely aligned with our long-term strategy. We expect to make similar decisions in the future. We may also make cash payments in connection with future business combinations.

[0001262039-24-000014:mdna:191]
During 2023, cash used in investing activities was $649.3 million, primarily driven by $437.0 million spent for purchases of investments, net of maturities and sales of investments, $204.1 million used for the purchases of property and equipment, and $8.5 million investment in a privately held company.

[0001262039-24-000014:mdna:192]
Financing Activities

[0001262039-24-000014:mdna:193]
The changes in cash flows from financing activities primarily relate to repurchase and retirement of common stock, and taxes paid related to net share settlement of equity awards, net of proceeds from the issuance of common stock under our Amended and Restated 2009 Equity Incentive Plan (the “2009 EIP”).

[0001262039-24-000014:mdna:194]
During 2023, cash used in financing activities was $1.57 billion, primarily driven by $1.50 billion used to repurchase shares of our common stock and $68.7 million used to pay tax withholding, net of proceeds from the issuance of common stock.

[0001262039-24-000014:mdna:195]
Recent Accounting Pronouncements

[0001262039-24-000014:mdna:196]
Refer to Note 1 of the notes to our consolidated financial statements in Part II, Item 8 of this Annual Report on Form 10-K for a full description of recently adopted accounting pronouncements.
