# FTNT 10-K controls and the auditor's report


## auditors_report

[0001262039-24-000014:auditors_report:1]
REPORT OF INDEPENDENT REGISTERED PUBLIC ACCOUNTING FIRM

[0001262039-24-000014:auditors_report:2]
To the stockholders and the Board of Directors of Fortinet, Inc.

[0001262039-24-000014:auditors_report:3]
Opinion on the Financial Statements

[0001262039-24-000014:auditors_report:4]
We have audited the accompanying consolidated balance sheets of Fortinet, Inc. and subsidiaries (the “Company”) as of December 31, 2023 and 2022, the related consolidated statements of income, comprehensive income, equity (deficit), and cash flows, for each of the three years in the period ended December 31, 2023, and the related notes (collectively referred to as the “financial statements”). In our opinion, the financial statements present fairly, in all material respects, the financial position of the Company as of December 31, 2023 and 2022, and the results of its operations and its cash flows for each of the three years in the period ended December 31, 2023, in conformity with accounting principles generally accepted in the United States of America.

[0001262039-24-000014:auditors_report:5]
We have also audited, in accordance with the standards of the Public Company Accounting Oversight Board (United States) (PCAOB), the Company’s internal control over financial reporting as of December 31, 2023, based on criteria established in Internal Control – Integrated Framework (2013) issued by the Committee of Sponsoring Organizations of the Treadway Commission and our report dated February 23, 2024, expressed an unqualified opinion on the Company’s internal control over financial reporting.

[0001262039-24-000014:auditors_report:6]
Basis for Opinion

[0001262039-24-000014:auditors_report:7]
These financial statements are the responsibility of the Company’s management. Our responsibility is to express an opinion on the Company’s financial statements based on our audits. We are a public accounting firm registered with the PCAOB and are required to be independent with respect to the Company in accordance with the U.S. federal securities laws and the applicable rules and regulations of the Securities and Exchange Commission and the PCAOB.

[0001262039-24-000014:auditors_report:8]
We conducted our audits in accordance with the standards of the PCAOB. Those standards require that we plan and perform the audit to obtain reasonable assurance about whether the financial statements are free of material misstatement, whether due to error or fraud. Our audits included performing procedures to assess the risks of material misstatement of the financial statements, whether due to error or fraud, and performing procedures that respond to those risks. Such procedures included examining, on a test basis, evidence regarding the amounts and disclosures in the financial statements. Our audits also included evaluating the accounting principles used and significant estimates made by management, as well as evaluating the overall presentation of the financial statements. We believe that our audits provide a reasonable basis for our opinion.

[0001262039-24-000014:auditors_report:9]
Critical Audit Matter

[0001262039-24-000014:auditors_report:10]
The critical audit matter communicated below is a matter arising from the current-period audit of the financial statements that was communicated or required to be communicated to the audit committee and that (1) relates to accounts or disclosures that are material to the financial statements and (2) involved our especially challenging, subjective, or complex judgments. The communication of critical audit matters does not alter in any way our opinion on the financial statements, taken as a whole, and we are not, by communicating the critical audit matter below, providing a separate opinion on the critical audit matter or on the accounts or disclosures to which it relates.

[0001262039-24-000014:auditors_report:11]
Litigation – Refer to Notes 1 and 12 to the financial statements

[0001262039-24-000014:auditors_report:12]
Critical Audit Matter Description

[0001262039-24-000014:auditors_report:13]
The Company is involved in disputes, litigation, and other legal actions in the normal course of business. Claims from third parties may result in a requirement to pay substantial damages. The Company accrues for a loss contingency if a loss is probable, and the amount of the loss can be reasonably estimated. These accruals are generally based on a range of possible outcomes that require significant management judgement.

[0001262039-24-000014:auditors_report:14]
Given the inherent uncertainty of the outcome of current matters, auditing litigation contingencies required a high degree of auditor judgment and an increased extent of effort when performing audit procedures.

[0001262039-24-000014:auditors_report:15]
How the Critical Audit Matter Was Addressed in the Audit

[0001262039-24-000014:auditors_report:16]
Our audit procedures related to litigation contingencies included the following, among others:

[0001262039-24-000014:auditors_report:17]
•We tested the effectiveness of controls over management’s litigation contingency accrual analysis and assessment of matters

[0001262039-24-000014:auditors_report:18]
69

[0001262039-24-000014:auditors_report:19]
with potential impact.

[0001262039-24-000014:auditors_report:20]
•We obtained and evaluated legal letters from internal and external legal counsel, and we discussed the pending litigation matters with internal legal counsel.

[0001262039-24-000014:auditors_report:21]
•We made inquiries with management to obtain an understanding of litigation matters that the Company is currently undergoing.

[0001262039-24-000014:auditors_report:22]
•We read available court documents for litigation matters to search for contradictory information.

[0001262039-24-000014:auditors_report:23]
•We read Board of Directors meeting minutes to search for contradictory information.

[0001262039-24-000014:auditors_report:24]
•We evaluated the assumptions used by the Company to estimate the litigation contingency, including corroborating the assumptions with internal legal counsel.

[0001262039-24-000014:auditors_report:25]
/s/ DELOITTE & TOUCHE LLP

[0001262039-24-000014:auditors_report:26]
San Jose, California

[0001262039-24-000014:auditors_report:27]
February 23, 2024

[0001262039-24-000014:auditors_report:28]
We have served as the Company’s auditor since 2002.

[0001262039-24-000014:auditors_report:29]
70

[0001262039-24-000014:auditors_report:30]
FORTINET, INC.


## item_9a

[0001262039-24-000014:item_9a:1]
ITEM 9A.     Controls and Procedures

[0001262039-24-000014:item_9a:2]
Evaluation of Disclosure Controls and Procedures

[0001262039-24-000014:item_9a:3]
Our management, with the participation of our chief executive officer and chief financial officer, evaluated the effectiveness of our disclosure controls and procedures (as defined in Rule 13a-15(e) or 15d-15(e) under the Securities Exchange Act of 1934 (the “Exchange Act”)) as of the end of the period covered by this Annual Report on Form 10-K. In designing and evaluating the disclosure controls and procedures, management recognized that any controls and procedures, no matter how well designed and operated, can provide only reasonable assurance of achieving the desired control objectives. In addition, the design of disclosure controls and procedures must reflect the fact that there are resource constraints and that management is required to apply its judgment in evaluating the benefits of possible controls and procedures relative to their costs.

[0001262039-24-000014:item_9a:4]
Based on that evaluation, our chief executive officer and chief financial officer concluded that our disclosure controls and procedures were effective as of December 31, 2023 to provide reasonable assurance that information we are required to disclose in reports that we file or submit under the Exchange Act is recorded, processed, summarized and reported within the time periods specified in SEC rules and forms, and that such information is accumulated and communicated to our management, including our Chief Executive Officer and Chief Financial Officer, as appropriate, to allow timely decisions regarding required disclosure.

[0001262039-24-000014:item_9a:5]
Management’s Report on Internal Control over Financial Reporting

[0001262039-24-000014:item_9a:6]
Our management is responsible for establishing and maintaining adequate internal control over financial reporting, as defined in Rule 13a-15(f) and 15d-15(f) under the Exchange Act. Management conducted an evaluation of the effectiveness of our internal control over financial reporting based on the framework in Internal Control—Integrated Framework (2013) set forth by the Committee of Sponsoring Organizations of the Treadway Commission.

[0001262039-24-000014:item_9a:7]
Based on this evaluation, management concluded that our internal control over financial reporting was effective as of December 31, 2023. Management reviewed the results of its assessment with our Audit Committee. The effectiveness of our internal control over financial reporting as of December 31, 2023 has been audited by Deloitte & Touche LLP, an independent registered public accounting firm, as stated in its report, which appears in this Item under the heading “Report of Independent Registered Public Accounting Firm.”

[0001262039-24-000014:item_9a:8]
Changes in Internal Control over Financial Reporting

[0001262039-24-000014:item_9a:9]
There were no changes in our internal controls over financial reporting (as defined in Rules 13a-15(f) or 15d-15(f) under the Exchange Act) during 2023 that have materially affected, or are reasonably likely to materially affect, our internal controls over financial reporting.

[0001262039-24-000014:item_9a:10]
107

[0001262039-24-000014:item_9a:11]
REPORT OF INDEPENDENT REGISTERED PUBLIC ACCOUNTING FIRM

[0001262039-24-000014:item_9a:12]
To the stockholders and the Board of Directors of Fortinet, Inc.

[0001262039-24-000014:item_9a:13]
Opinion on Internal Control over Financial Reporting

[0001262039-24-000014:item_9a:14]
We have audited the internal control over financial reporting of Fortinet, Inc. and subsidiaries (the “Company”) as of December 31, 2023, based on criteria established in Internal Control – Integrated Framework (2013) issued by the Committee of Sponsoring Organizations of the Treadway Commission (COSO). In our opinion, the Company maintained, in all material respects, effective internal control over financial reporting as of December 31, 2023, based on criteria established in Internal Control – Integrated Framework (2013) issued by COSO.

[0001262039-24-000014:item_9a:15]
We have also audited, in accordance with the standards of the Public Company Accounting Oversight Board (United States) (PCAOB), the consolidated financial statements as of and for the year ended December 31, 2023, of the Company and our report dated February 23, 2024 expressed an unqualified opinion on those financial statements.

[0001262039-24-000014:item_9a:16]
Basis for Opinion

[0001262039-24-000014:item_9a:17]
The Company’s management is responsible for maintaining effective internal control over financial reporting and for its assessment of the effectiveness of internal control over financial reporting, included in the accompanying Management’s Report on Internal Control over Financial Reporting. Our responsibility is to express an opinion on the Company’s internal control over financial reporting based on our audit. We are a public accounting firm registered with the PCAOB and are required to be independent with respect to the Company in accordance with the U.S. federal securities laws and the applicable rules and regulations of the Securities and Exchange Commission and the PCAOB.

[0001262039-24-000014:item_9a:18]
We conducted our audit in accordance with the standards of the PCAOB. Those standards require that we plan and perform the audit to obtain reasonable assurance about whether effective internal control over financial reporting was maintained in all material respects. Our audit included obtaining an understanding of internal control over financial reporting, assessing the risk that a material weakness exists, testing and evaluating the design and operating effectiveness of internal control based on the assessed risk, and performing such other procedures as we considered necessary in the circumstances. We believe that our audit provides a reasonable basis for our opinion.

[0001262039-24-000014:item_9a:19]
Definition and Limitations of Internal Control over Financial Reporting

[0001262039-24-000014:item_9a:20]
A company’s internal control over financial reporting is a process designed to provide reasonable assurance regarding the reliability of financial reporting and the preparation of financial statements for external purposes in accordance with generally accepted accounting principles. A company’s internal control over financial reporting includes those policies and procedures that (1) pertain to the maintenance of records that, in reasonable detail, accurately and fairly reflect the transactions and dispositions of the assets of the company; (2) provide reasonable assurance that transactions are recorded as necessary to permit preparation of financial statements in accordance with generally accepted accounting principles, and that receipts and expenditures of the company are being made only in accordance with authorizations of management and directors of the company; and (3) provide reasonable assurance regarding prevention or timely detection of unauthorized acquisition, use, or disposition of the company’s assets that could have a material effect on the financial statements.

[0001262039-24-000014:item_9a:21]
Because of its inherent limitations, internal control over financial reporting may not prevent or detect misstatements. Also, projections of any evaluation of effectiveness to future periods are subject to the risk that controls may become inadequate because of changes in conditions, or that the degree of compliance with the policies or procedures may deteriorate.

[0001262039-24-000014:item_9a:22]
/s/ DELOITTE & TOUCHE LLP

[0001262039-24-000014:item_9a:23]
San Jose, California

[0001262039-24-000014:item_9a:24]
February 23, 2024

[0001262039-24-000014:item_9a:25]
108
