# FTNT notes — 0001262039-24-000014


## dei:DocumentsIncorporatedByReferenceTextBlock

[0001262039-24-000014:notes:1]
Portions of the registrant’s definitive Proxy Statement relating to its 2024 Annual Meeting of Stockholders (“Proxy Statement”) are incorporated by reference into Part III of this Annual Report on Form 10-K where indicated. Such Proxy Statement will be filed with the United States Securities and Exchange Commission within 120 days after the end of the fiscal year to which this report relates


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001262039-24-000014:notes:2]
THE COMPANY AND SUMMARY OF SIGNIFICANT ACCOUNTING POLICIES
Business—Fortinet, Inc. (“Fortinet”) was incorporated in Delaware in 2000 and is a global leader in broad, integrated and automated cybersecurity solutions. Fortinet provides high performance cybersecurity solutions to a wide variety of businesses, such as large enterprises, communication service providers, government organizations and small to medium-sized enterprises. Fortinet’s cybersecurity solutions are designed to provide broad visibility and segmentation of the digital attack surface, through our integrated cybersecurity platform (the “Fortinet Security Fabric”) with automated protection, detection and response.

[0001262039-24-000014:notes:3]
The amounts previously reported as Income tax liabilities are included in Other liabilities. Prior periods have been reclassified to conform with current period presentation.

[0001262039-24-000014:notes:4]
Basis of Presentation and Preparation—The consolidated financial statements of Fortinet and its subsidiaries (collectively, “we,” “us”, or “our”) have been prepared in accordance with generally accepted accounting principles in the United States (“GAAP”). We consolidate all legal entities in which we have an absolute controlling financial interest. All intercompany transactions and balances have been eliminated in consolidation.

[0001262039-24-000014:notes:5]
Use of Estimates—The preparation of consolidated financial statements in accordance with GAAP requires management to make estimates and assumptions that affect the amounts reported in the consolidated financial statements and accompanying notes. Such management estimates include, but are not limited to, the determination of contingent liabilities, the determination of our ability to exercise control or significant influence over our investees, the evaluation of the equity method investments for OTTI, the standalone selling price for our products and services, the period of benefit for deferred contract costs for commissions, stock-based compensation, inventory valuation and liability for non-cancellable inventory purchase commitments with contract manufacturers and component suppliers, the fair value of tangible and intangible assets acquired and liabilities assumed in business combinations, the measurement of liabilities for uncertain tax positions and deferred tax assets and liabilities, the assessment of recoverability of our goodwill and other long-lived assets, measurement of non-marketable equity securities and the determination of sales returns reserves. We base our estimates on historical experience and also on assumptions that we believe are reasonable. Actual results could differ materially from those estimates.

[0001262039-24-000014:notes:6]
Concentration Risk—Financial instruments that subject us to concentrations of credit risk consist primarily of cash, cash equivalents, short-term and long-term investments, marketable equity securities and accounts receivable. Our cash balances are maintained as deposits with various large financial institutions in the United States and around the world. Balances in the United States typically exceed the amount of insurance provided on such deposits. We maintain our cash equivalents and investments in money market funds, corporate debt securities, U.S. government and agency securities, commercial paper, certificates of deposit and term deposits and municipal bonds with major financial institutions that our management believes are financially sound.

[0001262039-24-000014:notes:7]
Our accounts receivable are derived from our customers in various geographic locations. We perform ongoing credit evaluations of our customers. We generally do not require collateral on accounts receivable, and we maintain reserves for estimated credit losses. See Note 16. Segment Information for distributor customers that accounted for 10% or more of our revenue or net accounts receivable.

[0001262039-24-000014:notes:8]
We rely on a small number of manufacturing partners, with over 95% of manufacturing in Taiwan and U.S., to manufacture our products, and some of the chips and other components of our products used by the contract manufacturers are available from limited or sole sources of supply. Our proprietary Application-Specific Integrated Circuits are built by contract manufacturers located in Japan and Taiwan; other integrated circuits are provided by other chip manufacturers.

[0001262039-24-000014:notes:9]
Financial Instruments and Fair Value—We define fair value as the price that would be received from selling an asset, or paid to transfer a liability, in an orderly transaction between market participants at the measurement date. When determining the fair value measurements for assets and liabilities which are required to be recorded at fair value, we consider the principal or most advantageous market in which to transact and the market-based risk. We apply fair value accounting for all financial assets and liabilities and non-financial assets and liabilities that are recognized or disclosed at fair value in the financial statements on a recurring basis. Due to their short-term nature, the carrying amounts reported in the consolidated financial statements approximate the fair value for cash and cash equivalents, accounts receivable, accounts payable, accrued liabilities, and accrued payroll and compensation.

[0001262039-24-000014:notes:10]
Comprehensive Income—Comprehensive income includes certain changes in equity from non-owner sources that are excluded from net income, specifically, cumulative foreign currency translation adjustments, unrealized gains and losses on available-for-sale investments and the related tax impacts.

[0001262039-24-000014:notes:11]
Foreign Currency and Transaction Gains and Losses—The functional currency for most of our foreign subsidiaries is the U.S. dollar. For our international subsidiary whose functional currency is the local currency, we translate the financial statements of this subsidiary to U.S. dollars using the exchange rates in effect at the balance sheet dates for assets and liabilities, and average monthly exchange rates for revenues, costs, and expenses. We record translation gains and losses in accumulated other comprehensive income as a component of equity (deficit). We reflect net foreign exchange transaction gains and losses resulting from the conversion of the transaction currency to functional currency as a component of foreign currency exchange gain (loss) in other expense—net. We recognized a foreign currency loss of $7.0 million, $4.6 million and $8.2 million in other expense—net, for 2023, 2022, and 2021, respectively.

[0001262039-24-000014:notes:12]
Cash and Cash Equivalents—We consider all highly liquid investments, purchased with original maturities of three months or less, to be cash equivalents. Cash and cash equivalents consist of balances with banks and highly liquid investments in commercial paper, corporate debt, U.S. government and agency securities, term deposits and money market funds.

[0001262039-24-000014:notes:13]
Available-for-Sale Investments—We hold investment grade securities consisting of corporate debt securities, U.S. government and agency securities, commercial paper, certificates of deposit and term deposits and municipal bonds that our management believes are financially sound. We classify our investments as available-for-sale (“AFS”) at the time of purchase, since it is our intent that these investments are available for current operations. Investments with original maturities greater than three months with a remaining maturity of less than one year from the consolidated balance sheet date are classified as short-term investments. Investments with remaining maturities greater than one year from the consolidated balance sheet date are classified as long-term investments.

[0001262039-24-000014:notes:14]
Our AFS investments in debt securities are carried at estimated fair value with any unrealized gains and losses, net of taxes, included in accumulated other comprehensive income (loss) in the consolidated statements of equity (deficit). AFS debt securities with an amortized cost basis in excess of estimated fair value are assessed to determine what amount of that difference, if any, is caused by expected credit losses. An investment is impaired if the fair value of the investment is less than its cost. If the fair value of an investment is less than its amortized cost basis at the balance sheet date and if we do not intend to sell the investment, we consider available evidence to assess whether it is more likely than not that we will be required to sell the investment before the recovery of its amortized cost basis. We consult with our investment managers and consider available quantitative and qualitative evidence in evaluating, among other factors, general market conditions, the duration and extent to which the fair value is less than cost, and our ability to hold the investment. Once an impairment is determined to be attributable to credit-related factors, allowance for credit losses (i.e., the credit loss component) on AFS debt securities is recognized as credit loss expense, a charge in other expense—net, on our consolidated statements of income, and any remaining unrealized losses (i.e., the non-credit loss component), net of taxes, are included in accumulated other comprehensive income (loss) on our consolidated statements of equity (deficit).

[0001262039-24-000014:notes:15]
We consider whether unrealized losses have resulted from a credit loss or other factors. The unrealized losses on our AFS debt securities as of December 31, 2023, 2022 and 2021 were caused by fluctuations in market value and interest rates as a result of the market conditions. We concluded that an allowance for credit losses was unnecessary as of December 31, 2023, 2022 and 2021 because (i) the decline in market value was attributable to changes in market conditions and not credit quality, and (ii) we concluded that neither do we intend to sell nor is it more likely than not that we will be required to sell these investments prior to recovery of their amortized cost basis. As a result, we had no credit losses recorded for the years ended December 31, 2023, 2022 and 2021.

[0001262039-24-000014:notes:16]
We determine realized gains or losses on sale of AFS debt securities using the specific identification method to determine the cost basis of investments sold and record such gains or losses as other expense—net on the consolidated statements of income. We have elected to not record an allowance for credit losses for accrued interest for AFS investments in debt securities and will reverse the accrued interest against interest income in the period in which we determine the accrued interest to be uncollectible.

[0001262039-24-000014:notes:17]
Marketable Equity Securities—Our marketable equity investments with readily determinable fair values are accounted for at fair value through net income. Realized gains and losses as well as changes in fair value of these securities are recognized and reported in other expense—net, and are determined using the specific identification method.

[0001262039-24-000014:notes:18]
Investments in privately held companies—Our investments in privately held companies consist of investments in common stock or in-substance common stock. Our equity method investments provide us with the ability to exercise significant influence over the investees, but not an absolute controlling financial interest. These investments are accounted for under the equity method of accounting and were initially recorded at cost. Subsequently, we recognize our proportionate share of the entity’s net loss, the amortization of any basis differences, as well as any OTTI as gain or loss from these equity method investments in the consolidated statements of income and as an adjustment to the investment balance. We record our proportionate share of the results of these equity method investments on a three-month lag basis. We evaluate if there are material transactions or events that occur during the intervening period that materially affect the financial position or results of operations. As of December 31, 2023, we had two equity method investments, including our investment in Linksys. As of December 31, 2022, our investment in Linksys was our only equity method investment. As of December 31, 2023 and 2022, our equity method investments were recorded in other assets. Our remaining investments in privately held companies are recorded at cost and as of December 31, 2023 and 2022 were not material.

[0001262039-24-000014:notes:19]
We evaluate our equity method investments at the end of each reporting period to determine whether events or changes in business circumstances indicate that the carrying value of the investments may not be recoverable. Evidence of a loss in value might include, but would not necessarily be limited to, absence of an ability to recover the carrying amount of the investments or inability of the investee to sustain an earnings capacity that would justify the carrying amount of the investments. This evaluation consists of several qualitative and quantitative factors including recent financial results, projected financial results and operating trends of the investees and other publicly available information that may affect the value of our investments.

[0001262039-24-000014:notes:20]
Accounts receivable—Trade accounts receivable are recorded at the invoiced amount. Our accounts receivable balance is reduced by an allowance for expected credit losses. We measure expected credit losses of accounts receivable on a collective (pooled) basis, aggregating accounts receivable that are either current or no more than 60 days past due, and aggregating accounts receivable that are more than 60 days past due. We apply a credit-loss percentage to each of the pools that is based on our historical credit losses. We review whether each of our significant accounts receivable that is more than 60 days past due continues to exhibit similar risk characteristics with the other accounts receivable in the pool. If we determine that it does not, we evaluate it for expected credit losses on an individual basis.

[0001262039-24-000014:notes:21]
We further consider collectability trends for the allowance for credit losses based on our assessment of various factors, including credit quality of our customers, current economic conditions, reasonable and supportable forecasts of future economic conditions, and other factors that may affect our ability to collect from our customers. Expected credit losses are recorded as general and administrative expenses on our consolidated statements of income. The allowance for credit losses was $8.2 million and $3.6 million as of December 31, 2023 and 2022, respectively. Provisions, write-offs and recoveries were not material during the years ended December 31, 2023, 2022 and 2021.

[0001262039-24-000014:notes:22]
Inventory—Inventory is recorded at the lower of cost or net realizable value. Cost is computed using the first-in, first-out method. Inventory costs comprise primarily of the cost of materials and other component parts as well as capitalized overhead. In assessing the ultimate recoverability of inventory, we make estimates regarding future customer demand, the timing of new product introductions, economic trends and market conditions. A write-down of inventory and a corresponding charge to cost of product revenue is recorded when inventory is determined to be in excess of anticipated demand or considered obsolete. At the point of the write-down loss recognition, a new, lower cost basis for that inventory is established, and subsequent changes in facts and circumstances do not result in the restoration or increase in that newly established cost basis. In addition, we record a liability for non-cancelable inventory purchase commitments with contract manufacturers and suppliers for quantities in excess of our future estimated demand forecasts. The expense related to such accrued liability for inventory purchase commitments is recorded in cost of product revenue on the consolidated statements of income.

[0001262039-24-000014:notes:23]
Property and Equipment—Property and equipment are stated at cost less accumulated depreciation. We do not depreciate the allocated cost of land. Depreciation is computed using the straight-line method over the estimated useful lives of the assets:

[0001262039-24-000014:notes:24]
|  | Estimated Useful Lives |
| Building and building improvements | 2 to 40 years |
| Computer equipment and software | 1 to 7 years |
| Evaluation units | 1 year |
| Furniture and fixtures | 3 to 8 years |
| Leasehold improvements | Shorter of useful life or lease term |

[0001262039-24-000014:notes:25]
Business Combinations—We include the results of operations of the businesses that we acquire as of the respective dates of acquisition. We allocate the fair value of the purchase price of our business acquisitions to the tangible and intangible assets acquired and liabilities assumed, based on their estimated fair values. The excess of the purchase price over the fair values of these identifiable assets and liabilities is recorded as goodwill. Our estimates and assumptions are subject to change based on information existing at acquisition date but unknown to us, which may become known during the remainder of the measurement period, not to exceed 12 months from the acquisition date, and if we make changes to the amounts recorded, such amounts are recorded in the period in which they are identified.

[0001262039-24-000014:notes:26]
Impairment of Long-Lived Assets—We evaluate events and changes in circumstances that could indicate carrying amounts of long-lived assets, including intangible assets, may not be recoverable. When such events or changes in circumstances occur, we assess the recoverability of long-lived assets by determining whether the carrying value of such assets will be recovered through undiscounted expected future cash flows. If the total of the future undiscounted cash flows is less than the carrying amount of those assets, we record an impairment charge in the period in which we make the determination. If such assets are considered to be impaired, the impairment to be recognized is measured by the amount by which the carrying amount of the assets exceeds the fair value of the assets. There were no impairments of long-lived assets in 2023, 2022 and 2021.

[0001262039-24-000014:notes:27]
Goodwill—Goodwill represents the excess of purchase consideration over the estimated fair value of net assets of businesses acquired in a business combination. Goodwill acquired in a business combination is not amortized, but instead tested for impairment at least annually during the fourth quarter, or sooner when circumstances indicate an impairment may exist. We perform a qualitative assessment in the fourth quarter of each year, or more frequently if indicators of potential impairment exist, to determine if any events or circumstances exist, such as an adverse change in business climate or a decline in the overall industry that would indicate that it would more likely than not reduce the fair value of a reporting unit below its carrying amount, including goodwill. If such evaluation indicates that it is more likely than not that the fair value of a reporting unit is less that its carrying amount, then the quantitative impairment test will be performed. Under the quantitative impairment test, if the carrying amount of a reporting unit exceeds its fair value, any excess is recognized as an impairment loss in goodwill, limited to the total amount of goodwill allocated to that reporting unit.

[0001262039-24-000014:notes:28]
We performed our annual goodwill impairment assessment and did not identify any impairment indicators as a result of the review. As of December 31, 2023 and 2022, we had one reporting unit.

[0001262039-24-000014:notes:29]
Other Intangible Assets—Intangible assets with finite lives are carried at cost, less accumulated amortization. Amortization is computed using the straight-line or accelerated method over the estimated economic lives of the assets, which range from one to ten years.

[0001262039-24-000014:notes:30]
Income Taxes—We record income taxes using the asset and liability method, which requires the recognition of deferred tax assets and liabilities for the expected future tax consequences of events that have been recognized in our financial statements or tax returns. In addition, deferred tax assets are recorded for the future benefit of utilizing net operating losses and research and development credit carryforwards. Deferred tax assets and liabilities are measured using the currently enacted tax rates that apply to taxable income in effect for the years in which those tax assets and liabilities are expected to be realized or settled. Valuation allowances are provided when necessary to reduce deferred tax assets to the amount expected to be realized.

[0001262039-24-000014:notes:31]
As part of the process of preparing our consolidated financial statements, we are required to estimate our taxes in each of the jurisdictions in which we operate. We estimate actual current tax exposure together with assessing temporary differences resulting from differing treatment of items, such as accruals and allowances not currently deductible for tax purposes. These

[0001262039-24-000014:notes:32]
differences result in deferred tax assets, which are included in our consolidated balance sheets. In general, deferred tax assets represent future tax benefits to be received when certain expenses previously recognized in our consolidated statements of income become deductible expenses under applicable income tax laws, or loss or credit carryforwards are utilized.

[0001262039-24-000014:notes:33]
In assessing the realizability of deferred tax assets, management considers whether it is more likely than not that some portion or all of the deferred tax assets will be realized. The ultimate realization of deferred tax assets is dependent upon the generation of future taxable income during the periods in which those temporary differences become deductible. We continue to assess the need for a valuation allowance on the deferred tax assets by evaluating both positive and negative evidence that may exist. Any adjustment to the valuation allowance on deferred tax assets would be recorded in the consolidated statements of income for the period that the adjustment is determined to be required.

[0001262039-24-000014:notes:34]
We recognize tax benefits from an uncertain tax position only if it is more likely than not, based on the technical merits of the position, that the tax position will be sustained on examination by the tax authorities. The tax benefits recognized in the financial statements from such positions are then measured based on the largest benefit that has a greater than 50% likelihood of being realized upon ultimate settlement.

[0001262039-24-000014:notes:35]
We have elected to account for the tax effect of the GILTI as a current period expense.

[0001262039-24-000014:notes:36]
Stock-Based Compensation—The fair value of restricted stock units (“RSUs”) is based on the closing market price of our common stock on the date of grant. We have elected to use the Black-Scholes-Merton (“Black-Scholes”) pricing model to determine the fair value of our employee stock options and the Monte Carlo simulation pricing model to determine the fair value of our performance stock units (“PSUs”). Stock-based compensation expense of our RSUs and options is amortized on a straight-line basis over the service period and stock-based compensation expense of our PSUs is amortized using a graded vesting method over the vesting period. We account for forfeitures of all stock-based payment awards when they occur.

[0001262039-24-000014:notes:37]
Leases—We determine if an arrangement is a lease at inception. We evaluate the classification of leases at commencement and, as necessary, at modification. The right-of-use (“ROU”) assets and the short- and long-term lease liabilities from our operating leases are included in other assets, accrued liabilities and other liabilities in our consolidated balance sheets, respectively. The corresponding assets and, the short- and long-term lease liabilities from our finance leases are included in property and equipment, accrued liabilities and other liabilities in our consolidated balance sheets, respectively.

[0001262039-24-000014:notes:38]
The ROU assets represent our right to use an underlying asset for the lease term. Lease liabilities represent our obligation to make lease payments under the lease. Operating lease ROU assets and liabilities are recognized at the lease commencement date based on the present value of lease payments over the lease term. The implicit rate within our operating leases is generally not determinable and therefore we use our incremental borrowing rate at the lease commencement date to determine the present value of lease payments. The determination of our incremental borrowing rate requires judgment. We determine our incremental borrowing rate for each lease using indicative bank borrowing rates, adjusted for various factors including level of collateralization, term and currency to align with the terms of a lease. The operating lease ROU asset also includes any lease prepayments and initial direct costs, net of lease incentives. Certain leases include options to extend or terminate the lease. An option to extend the lease is considered in connection with determining the ROU asset and lease liability when it is reasonably certain we will exercise that option. An option to terminate is considered unless it is reasonably certain we will not exercise the option.

[0001262039-24-000014:notes:39]
We do not recognize lease liabilities or ROU assets for short-term leases (leases that, at the commencement date, have a lease term of 12 months or less and do not include an option to purchase the underlying asset that we are reasonably certain to exercise). We do not allocate the contract consideration for operating lease contracts with lease and non-lease components, and account for the lease and non-lease components as a single lease component.

[0001262039-24-000014:notes:40]
Payments under our lease arrangements are primarily fixed; however, certain lease agreements contain variable payments, which are expensed as incurred and not included in the operating lease ROU assets and liabilities. Variable lease payments primarily include common area maintenance charges, real estate taxes, certain parking expense, utilities based on actual usage, and insurance costs. Lease expense for lease payments for our operating leases is recognized on a straight-line basis over the term of the lease. We begin recognizing rent expense on the date that a lessor makes an underlying asset that is subject to the lease available for our use. For our finance leases, we recognize amortization expense from the amortization of the corresponding assets and interest expense on the related lease liabilities.

[0001262039-24-000014:notes:41]
Advertising Expense—Advertising costs are expensed when incurred and are included in operating expenses in the accompanying consolidated statements of income. Our advertising expenses were not material for any periods presented.

[0001262039-24-000014:notes:42]
Research and Development Costs—Research and development costs are expensed as incurred.

[0001262039-24-000014:notes:43]
Software Development Costs—The costs to develop software that is marketed have not been capitalized as we believe our current software development process is essentially completed concurrently with the establishment of technological feasibility. Such costs are expensed as incurred and included in research and development in our consolidated statements of income.

[0001262039-24-000014:notes:44]
The costs to develop software for internal use are capitalized based on qualifying criteria. These costs consist of internal compensation related costs and external direct costs incurred during the application development stage. Such costs are amortized over the software’s estimated useful life. Internal use software development costs capitalized were not material for any periods presented.

[0001262039-24-000014:notes:45]
Deferred Contract Costs and Commission Expense—Sales commissions earned by our sales force are considered incremental and recoverable costs of obtaining a contract with a customer. We recognize sales commissions expenses related to product sales upfront while sales commissions expenses for service contracts are deferred as deferred contract costs in the consolidated balance sheets and amortized over the applicable amortization period. Commission costs for initial contracts that are not commensurate with commissions on renewal contracts are amortized on a straight-line basis over the period of benefit, which we have determined to be five years and which is typically longer than the initial contract term. The amortization of deferred contract costs is included in sales and marketing expense in our consolidated statements of income. Amortization of deferred contract costs during 2023, 2022 and 2021 was $266.3 million, $223.3 million and $175.9 million, respectively. No impairment loss of deferred contract costs asset was recognized during 2023, 2022 and 2021.

[0001262039-24-000014:notes:46]
Deferred Revenue—Deferred revenue consists of amounts that have been invoiced but that have not yet been recognized as revenue. Deferred revenue that will be recognized during the succeeding 12-month period is recorded as current deferred revenue and the remaining portion is recorded as non-current deferred revenue. The majority of deferred revenue is comprised of security subscription and technical support services which are invoiced upfront and delivered over 12 months or longer.

[0001262039-24-000014:notes:47]
Revenue Recognition—Our revenue consists of product and service revenue. Revenues are recognized when control of these goods or services is transferred to our customers, in an amount that reflects the consideration we expect to be entitled to in exchange for those goods or services. We determine revenue recognition through the following steps:

[0001262039-24-000014:notes:48]
•identification of a contract or contracts with a customer;

[0001262039-24-000014:notes:49]
•identification of the performance obligations in a contract, including evaluation of performance obligations and evaluating the distinct goods or services in a contract;

[0001262039-24-000014:notes:50]
•determination of a transaction price;

[0001262039-24-000014:notes:51]
•allocation of a transaction price to the performance obligations in a contract; and

[0001262039-24-000014:notes:52]
•recognition of revenue when, or as, we satisfy a performance obligation.

[0001262039-24-000014:notes:53]
We derive a majority of product sales from Secure Networking hardware and associated security services which include a broad set of built-in security and networking features and functionalities, including firewall, next-generation firewall, secure web gateway, secure sockets layer (“SSL”) inspection, software-defined wide-area network, intrusion prevention, SSL data leak prevention, virtual private network, switch and wireless controller and wide area network edge.

[0001262039-24-000014:notes:54]
We recognize product revenue upon shipment when control of the promised goods is transferred to the customer. Our term software licenses represent multiple performance obligations, which include software licenses and software support services where the term licenses are recognized upfront upon transfer of control, with the associated software support services recognized ratably over the service term as services and software updates are provided.

[0001262039-24-000014:notes:55]
Service revenue relates to sales of our FortiGuard security subscription, FortiCare technical support services and other services. Our typical subscription and support term is one to five years. We generally recognize revenue from these services ratably over the service term because of continuous transfer of control to the customer. We also generate a portion of our revenue from other services consisting of professional services, training and software-as-a-service (“SaaS”) which is either hosted by us or provided through cloud-providers. We recognize revenue from professional and training services as the services

[0001262039-24-000014:notes:56]
are provided. We recognize revenue from SaaS as the subscription service is delivered over the term, which is typically one year, or on a monthly usage basis. To date, SaaS revenue has not represented a significant percentage of our total revenue.

[0001262039-24-000014:notes:57]
Our sales contracts typically contain multiple deliverables, such as hardware, software license, security subscription, technical support services and other services, which are generally capable of being distinct and accounted for as separate performance obligations. Our hardware and software licenses have significant standalone functionalities and capabilities. Accordingly, the hardware and software licenses are distinct from the security subscription and technical support services, as a customer can benefit from the product without the services and the services are separately identifiable within a contract. We allocate a transaction price to each performance obligation based on relative standalone selling price. We establish standalone selling price using the prices charged for a deliverable when sold separately. If not observable through past transactions, we determine standalone selling price by considering multiple historical factors including, but not limited to, cost of products, gross margin objectives, pricing practices, geographies and the term of a service contract. Revenue is reported net of sales tax.

[0001262039-24-000014:notes:58]
In certain circumstances, our contracts include provisions for sales rebates and other customer incentive programs. Additionally, in limited circumstances, we may permit end-customers, distributors and resellers to return our products, subject to varying limitations, for a refund within a reasonably short period from the date of purchase. These amounts are accounted for as variable consideration that can decrease the transaction price. We estimate variable consideration using the expected-value method based on the most likely amounts to which we expect our customers to be entitled. We include estimated amounts in the transaction price to the extent that it is probable that a significant reversal of cumulative revenue recognized will not occur when the uncertainty associated with the variable consideration is resolved. Our estimate for refund liabilities, which include sales returns reserve and customer rebates, was $92.7 million and $92.0 million as of December 31, 2023 and 2022, respectively, and is included in current liabilities in our consolidated balance sheet.

[0001262039-24-000014:notes:59]
We generally invoice at the time of our sale for the total price of the hardware, software licenses, security subscription and technical support and other services. Standard payment terms are generally no more than 60 days, though we continue to offer extended payment terms to certain distributors. Amounts billed and due from our customers are classified as receivables on the balance sheet and do not bear interest.

[0001262039-24-000014:notes:60]
Shipping and handling fees charged to our customers are recognized as revenue in the period shipped and the related costs for providing these services are recorded in cost of revenue. Shipping and handling fees recognized were not material during 2023, 2022 and 2021.

[0001262039-24-000014:notes:61]
Warranties—We generally provide a one-year warranty for most hardware products and a 90-day warranty for software. We also provide extended warranties under the terms of our support agreements. A provision for estimated future costs related to warranty activities in the first year after product sale is recorded as a component of cost of product revenues when the product revenue is recognized, based upon historical product failure rates and historical costs incurred in correcting product failures. Warranty costs related to extended warranties sold under support agreements are recognized as cost of service revenue as incurred. In the event we change our warranty reserve estimates, the resulting charge against future cost of revenue or reversal of previously recorded charges may materially affect our gross margins and operating results. Accrued warranty liability was not material as of December 31, 2023 and 2022.

[0001262039-24-000014:notes:62]
Contingent Liabilities—From time to time, we are involved in disputes, litigation, and other legal actions. There are many uncertainties associated with any disputes, litigation and other legal actions, and these actions or other third-party claims against us may cause us to incur costly litigation fees, costs and substantial settlement charges, and possibly subject us to damages and other penalties, which are inherently difficult to estimate and could adversely affect our results of operations. In addition, the resolution of any IP litigation may require us to make royalty payments, which could adversely affect our gross margins in future periods. We periodically review significant claims and litigation matters for the probability of an adverse outcome. Estimates can change as individual claims develop. The actual liability in any such matters may be materially different from our estimates, which could result in the need to adjust our liability and record additional expenses, which may be material.

[0001262039-24-000014:notes:63]
Recent Accounting Standards Not Yet Effective

[0001262039-24-000014:notes:64]
Segment Reporting

[0001262039-24-000014:notes:65]
In November 2023, the Financial Accounting Standards Board (the “FASB”) issued Accounting Standards Update (“ASU”) 2023-07, Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures, which is intended to

[0001262039-24-000014:notes:66]
improve reportable segment disclosure requirements, primarily through enhanced disclosures about significant expenses. ASU 2023-07 was effective for us beginning on January 1, 2024 and will be applied on a retrospective basis to all periods presented. We are currently evaluating the ASU to determine its impact on our disclosures.

[0001262039-24-000014:notes:67]
Income Taxes

[0001262039-24-000014:notes:68]
In December 2023, the FASB issued ASU 2023-09, Income Taxes (Topic 740): Improvements to Income Tax Disclosures, which includes amendments that further enhance income tax disclosures, primarily through standardization and disaggregation of rate reconciliation categories and income taxes paid by jurisdiction. The amendments are effective for our annual periods beginning January 1, 2025, with early adoption permitted, and should be applied prospectively. We are currently evaluating the ASU to determine its impact on our disclosures.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001262039-24-000014:notes:69]
REVENUE RECOGNITION
Disaggregation of Revenue

[0001262039-24-000014:notes:70]
The following table presents our revenue disaggregated by major product and service lines (in millions):

[0001262039-24-000014:notes:71]
|  | Year Ended December 31, |
|  | 2023 |  | 2022 |  | 2021 |
| Product | $ | 1,927.3 |  |  | $ | 1,780.5 |  |  | $ | 1,255.0 |  |
| Service: |  |  |  |  |  |
| Security subscription | 1,898.1 |  |  | 1,427.0 |  |  | 1,125.0 |  |
| Technical support and other | 1,479.4 |  |  | 1,209.9 |  |  | 962.2 |  |
| Total service revenue | 3,377.5 |  |  | 2,636.9 |  |  | 2,087.2 |  |
| Total revenue | $ | 5,304.8 |  |  | $ | 4,417.4 |  |  | $ | 3,342.2 |  |

[0001262039-24-000014:notes:72]
Deferred Revenue

[0001262039-24-000014:notes:73]
During 2023 and 2022, we recognized $2.27 billion and $1.73 billion in revenue that was included in the deferred revenue balance as of December 31, 2022 and 2021, respectively.

[0001262039-24-000014:notes:74]
Transaction Price Allocated to the Remaining Performance Obligations

[0001262039-24-000014:notes:75]
As of December 31, 2023, the aggregate amount of the transaction price allocated to remaining performance obligations was $5.75 billion, which was substantially comprised of deferred security subscription and technical support services revenue as well as unbilled contract revenue from non-cancellable contracts that will be recognized in future periods. We expect to recognize approximately $2.86 billion as revenue over the next 12 months and the remainder thereafter.


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0001262039-24-000014:notes:76]
FINANCIAL INSTRUMENTS AND FAIR VALUE
Available-for-Sale Investments

[0001262039-24-000014:notes:77]
The following tables summarize our available-for-sale investments (in millions):

[0001262039-24-000014:notes:78]
|  | December 31, 2023 |
|  | AmortizedCost |  | UnrealizedGains |  | UnrealizedLosses |  | FairValue |
| U.S. government and agency securities | $ | 461.5 |  |  | $ | 0.2 |  |  | $ | (0.3) |  |  | $ | 461.4 |  |
| Commercial paper | 401.7 |  |  | 0.2 |  |  | (0.1) |  |  | 401.8 |  |
| Certificates of deposit and term deposits | 88.2 |  |  | 0.1 |  |  | — |  |  | 88.3 |  |
| Corporate debt securities | 70.0 |  |  | 0.1 |  |  | (0.1) |  |  | 70.0 |  |
| Total available-for-sale investments | $ | 1,021.4 |  |  | $ | 0.6 |  |  | $ | (0.5) |  |  | $ | 1,021.5 |  |
|  | December 31, 2022 |
|  | AmortizedCost |  | UnrealizedGains |  | UnrealizedLosses |  | FairValue |
| U.S. government and agency securities | $ | 198.0 |  |  | $ | — |  |  | $ | (4.4) |  |  | $ | 193.6 |  |
| Commercial paper | 26.5 |  |  | — |  |  | (0.1) |  |  | 26.4 |  |
| Certificates of deposit and term deposits | 34.2 |  |  | — |  |  | — |  |  | 34.2 |  |
| Corporate debt securities | 293.0 |  |  | — |  |  | (4.1) |  |  | 288.9 |  |
| Municipal Bonds | 5.1 |  |  | — |  |  | (0.1) |  |  | 5.0 |  |
| Total available-for-sale investments | $ | 556.8 |  |  | $ | — |  |  | $ | (8.7) |  |  | $ | 548.1 |  |

[0001262039-24-000014:notes:79]
The following tables show the gross unrealized losses and the related fair values of our available-for-sale investments that have been in a continuous unrealized loss position (in millions):

[0001262039-24-000014:notes:80]
|  | December 31, 2023 |
|  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
|  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |
| U.S. government and agency securities | $ | 47.1 |  |  | $ | — |  |  | $ | 11.7 |  |  | $ | (0.3) |  |  | $ | 58.8 |  |  | $ | (0.3) |  |
| Commercial paper | 200.8 |  |  | (0.1) |  |  | — |  |  | — |  |  | 200.8 |  |  | (0.1) |  |
| Corporate debt securities | 21.8 |  |  | — |  |  | 26.9 |  |  | (0.1) |  |  | 48.7 |  |  | (0.1) |  |
| Total available-for-sale investments | $ | 269.7 |  |  | $ | (0.1) |  |  | $ | 38.6 |  |  | $ | (0.4) |  |  | $ | 308.3 |  |  | $ | (0.5) |  |

[0001262039-24-000014:notes:81]
|  | December 31, 2022 |
|  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
|  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |
| U.S. government and agency securities | $ | 3.9 |  |  | $ | (0.1) |  |  | $ | 189.8 |  |  | $ | (4.3) |  |  | $ | 193.7 |  |  | $ | (4.4) |  |
| Commercial paper | 26.4 |  |  | (0.1) |  |  | — |  |  | — |  |  | 26.4 |  |  | (0.1) |  |
| Corporate debt securities | 90.5 |  |  | (0.8) |  |  | 190.0 |  |  | (3.3) |  |  | 280.5 |  |  | (4.1) |  |
| Municipal Bonds | 5.0 |  |  | (0.1) |  |  | — |  |  | — |  |  | 5.0 |  |  | (0.1) |  |
| Total available-for-sale investments | $ | 125.8 |  |  | $ | (1.1) |  |  | $ | 379.8 |  |  | $ | (7.6) |  |  | $ | 505.6 |  |  | $ | (8.7) |  |

[0001262039-24-000014:notes:82]
The contractual maturities of our investments were (in millions):

[0001262039-24-000014:notes:83]
|  | December 31,2023 |  | December 31,2022 |
| Due within one year | $ | 1,021.5 |  |  | $ | 502.6 |  |
| Due within one to three years | — |  |  | 45.5 |  |
| Total | $ | 1,021.5 |  |  | $ | 548.1 |  |

[0001262039-24-000014:notes:84]
Available-for-sale investments are reported at fair value, with unrealized gains and losses and the related tax impact included as a separate component of equity (deficit) and in comprehensive income. We do not intend to sell any of the securities in an unrealized loss position and it is not more likely than not that we would be required to sell these securities before recovery of their amortized cost basis, which may be at maturity.

[0001262039-24-000014:notes:85]
Realized gains and losses on available-for-sale investments were insignificant in the periods presented.

[0001262039-24-000014:notes:86]
Marketable Equity Securities

[0001262039-24-000014:notes:87]
Our marketable equity securities were $21.0 million and $25.5 million as of December 31, 2023 and December 31, 2022, respectively. The changes in fair value of our marketable equity securities are recorded in other expense—net on the consolidated statements of income. We recognized $4.4 million and $13.1 million of losses in 2023 and 2022, respectively.

[0001262039-24-000014:notes:88]
Fair Value of Financial Instruments

[0001262039-24-000014:notes:89]
Fair Value Accounting—We apply the following fair value hierarchy for disclosure of the inputs used to measure fair value. This hierarchy prioritizes the inputs into three broad levels:

[0001262039-24-000014:notes:90]
Level 1—Inputs are unadjusted quoted prices in active markets for identical assets or liabilities.

[0001262039-24-000014:notes:91]
Level 2—Inputs are quoted prices for similar assets and liabilities in active markets or inputs that are observable for the assets or liabilities, either directly or indirectly through market corroboration, for substantially the full term of the financial instruments.

[0001262039-24-000014:notes:92]
Level 3—Unobservable inputs based on our own assumptions used to measure assets and liabilities at fair value. The inputs require significant management judgment or estimation.

[0001262039-24-000014:notes:93]
We measure the fair value of money market funds, certain U.S. government and agency securities and marketable equity securities using quoted prices in active markets for identical assets. The fair value of all other financial instruments was based on quoted prices for similar assets in active markets, or model-driven valuations using significant inputs derived from or corroborated by observable market data.

[0001262039-24-000014:notes:94]
We classify investments within Level 1 if quoted prices are available in active markets for identical securities.

[0001262039-24-000014:notes:95]
We classify items within Level 2 if the investments are valued using model-driven valuations using observable inputs such as quoted market prices, benchmark yields, reported trades, broker/dealer quotes or alternative pricing sources with reasonable levels of price transparency. Investments are held by custodians who obtain investment prices from a third-party pricing provider that incorporates standard inputs in various asset price models.

[0001262039-24-000014:notes:96]
Assets Measured at Fair Value on a Recurring Basis

[0001262039-24-000014:notes:97]
The following tables present the fair value of our financial assets measured at fair value on a recurring basis (in millions):

[0001262039-24-000014:notes:98]
|  | December 31, 2023 |  | December 31, 2022 |
|  | AggregateFairValue |  | QuotedPrices inActiveMarkets ForIdenticalAssets |  | SignificantOtherObservableRemainingInputs |  | SignificantOtherUnobservableRemainingInputs |  | AggregateFairValue |  | QuotedPrices inActiveMarkets ForIdenticalAssets |  | SignificantOtherObservableRemainingInputs |  | SignificantOtherUnobservableRemainingInputs |
|  |  |  | (Level 1) |  | (Level 2) |  | (Level 3) |  |  |  | (Level 1) |  | (Level 2) |  | (Level 3) |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. government and agency securities | $ | 501.4 |  |  | $ | 433.3 |  |  | $ | 68.1 |  |  | $ | — |  |  | $ | 268.6 |  |  | $ | 259.3 |  |  | $ | 9.3 |  |  | $ | — |  |
| Commercial paper | 472.2 |  |  | — |  |  | 472.2 |  |  | — |  |  | 115.8 |  |  | — |  |  | 115.8 |  |  | — |  |
| Certificates of deposit and term deposits | 104.8 |  |  | — |  |  | 104.8 |  |  | — |  |  | 50.4 |  |  | — |  |  | 50.4 |  |  | — |  |
| Corporate debt securities | 73.0 |  |  | — |  |  | 73.0 |  |  | — |  |  | 288.9 |  |  | — |  |  | 288.9 |  |  | — |  |
| Money market funds | 277.1 |  |  | 277.1 |  |  | — |  |  | — |  |  | 593.9 |  |  | 593.9 |  |  | — |  |  | — |  |
| Municipal bonds | — |  |  | — |  |  | — |  |  | — |  |  | 5.0 |  |  | — |  |  | 5.0 |  |  | — |  |
| Marketable equity securities | 21.0 |  |  | 21.0 |  |  | — |  |  | — |  |  | 25.5 |  |  | 25.5 |  |  | — |  |  | — |  |
| Total | $ | 1,449.5 |  |  | $ | 731.4 |  |  | $ | 718.1 |  |  | $ | — |  |  | $ | 1,348.1 |  |  | $ | 878.7 |  |  | $ | 469.4 |  |  | $ | — |  |
| Reported as: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents | $ | 407.0 |  |  |  |  |  |  |  |  | $ | 774.5 |  |  |  |  |  |  |  |
| Marketable equity securities | 21.0 |  |  |  |  |  |  |  |  | 25.5 |  |  |  |  |  |  |  |
| Short-term investments | 1,021.5 |  |  |  |  |  |  |  |  | 502.6 |  |  |  |  |  |  |  |
| Long-term investments | — |  |  |  |  |  |  |  |  | 45.5 |  |  |  |  |  |  |  |
| Total | $ | 1,449.5 |  |  |  |  |  |  |  |  | $ | 1,348.1 |  |  |  |  |  |  |  |

[0001262039-24-000014:notes:99]
There were no transfers between Level 1 and Level 2 of the fair value hierarchy during the years ended December 31, 2023 and December 31, 2022.


## us-gaap:InventoryDisclosureTextBlock

[0001262039-24-000014:notes:100]
INVENTORY
Inventory consisted of (in millions):

[0001262039-24-000014:notes:101]
|  | December 31,2023 |  | December 31,2022 |
| Raw materials | $ | 92.1 |  |  | $ | 46.3 |  |
| Work in process | 7.7 |  |  | 12.0 |  |
| Finished goods | 385.0 |  |  | 206.3 |  |
| Inventory | $ | 484.8 |  |  | $ | 264.6 |  |

[0001262039-24-000014:notes:102]
The excess and obsolete inventory reserve was $89.2 million and $52.5 million as of December 31, 2023 and 2022, respectively. Inventory write-downs related to excess and obsolete inventory were $35.8 million for the year ended December 31, 2023, and not material for the years ended December 31, 2022 and 2021. They were recorded in cost of product revenue on the consolidated statements of income.


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001262039-24-000014:notes:103]
PROPERTY AND EQUIPMENT—Net
Property and equipment—net consisted of (in millions):

[0001262039-24-000014:notes:104]
|  | December 31,2023 |  | December 31,2022 |
| Land | $ | 351.7 |  |  | $ | 310.0 |  |
| Buildings and improvements | 595.5 |  |  | 490.3 |  |
| Computer equipment and software | 261.1 |  |  | 222.7 |  |
| Leasehold improvements | 61.4 |  |  | 53.5 |  |
| Evaluation units | 30.8 |  |  | 19.2 |  |
| Furniture and fixtures | 33.6 |  |  | 31.3 |  |
| Construction-in-progress | 63.3 |  |  | 51.7 |  |
| Total property and equipment | 1,397.4 |  |  | 1,178.7 |  |
| Less: accumulated depreciation | (353.0) |  |  | (280.2) |  |
| Property and equipment—net | $ | 1,044.4 |  |  | $ | 898.5 |  |

[0001262039-24-000014:notes:105]
During 2023, we purchased certain real estate in the United States, Spain, and Australia totaling $109.3 million. The purchases were accounted for under the asset acquisition method. The costs of the assets allocated to land, buildings and improvements and construction-in-progress were $41.7 million, $46.0 million and $21.6 million, respectively, based on their relative fair values.

[0001262039-24-000014:notes:106]
Depreciation expense was $94.5 million, $81.0 million and $65.9 million in 2023, 2022 and 2021, respectively.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001262039-24-000014:notes:107]
INVESTMENTS IN PRIVATELY HELD COMPANIES
Linksys Holdings, Inc.

[0001262039-24-000014:notes:108]
During 2021, we invested $160.0 million in cash for shares of the Series A Preferred Stock of Linksys for a 50.8% ownership interest in this privately held company. As of December 31, 2023 and 2022, our ownership interest remained the same. Linksys provides router connectivity solutions to the consumer and small business markets.

[0001262039-24-000014:notes:109]
We have concluded that our investment in Linksys is an in-substance common stock investment and that we do not hold an absolute controlling financial interest in Linksys, but that we have the ability to exercise significant influence over the operating and financial policies of Linksys. Determining that we have significant influence but not control over the operating and financial policies of Linksys required significant judgement of many factors, including but not limited to the ownership interest in Linksys, board representation, participation in policy-making processes and participation rights in certain significant financial and operating decisions of Linksys in the ordinary course of business. Therefore, we determined to account for this investment using the equity method of accounting. We record our share of Linksys’ financial results on a three-month lag basis, with the exception of material transactions or events that occur during the intervening period that materially affect the financial position or results of operations. We determined that there was a basis difference between the cost of our investment in Linksys and the amount of underlying equity in net assets of Linksys.

[0001262039-24-000014:notes:110]
Our share of loss of Linksys’ financial results, as well as our share of the amortization of the basis differences, totaled $42.1 million in 2023. Our loss related to Linksys in 2022 totaled $68.1 million, which comprised of our proportionate share of Linksys’ financial results as well as the amortization of the basis differences of $45.9 million, which included a $17.5 million charge in connection with a valuation allowance established on deferred tax assets at Linksys, and the other-than-temporary impairment (“OTTI”) charge of $22.2 million recorded during the three months ended December 31, 2022. Our share of loss of Linksys’ financial results as well as our share of the amortization of the basis differences in total was $7.6 million in 2021. The loss related to Linksys is recorded in loss from equity method investments on the consolidated statements of income.

[0001262039-24-000014:notes:111]
Due to the presence of impairment indicators, such as a series of operating losses, current expected performance relative to expected performance when we initially invested, performance relative to peers, changes in net working capital and cash available for business operations, and the results of a discounted cash flows analysis, we evaluated our equity method investment for an OTTI during 2023 and 2022. We considered various factors in determining whether an OTTI has occurred, including Linksys financial results and operating history, our ability and intent to hold the investment until its fair value recovers, the implied revenue valuation multiples compared to guideline public companies, Linksys’ ability to achieve

[0001262039-24-000014:notes:112]
milestones and any notable operational and strategic changes. In connection with our evaluation as of December 31, 2022, we noted that certain factors were present that indicated that the equity method investment’s decline in value was OTTI, primarily driven by Linksys’ continuous losses, decrease in revenue and operating results, then current forecasted results for the foreseeable future as compared to the expected performance at the time of the investments, and the results of a discounted cash flows analysis. To determine the fair value of our investment in Linksys, we utilized a market approach referencing revenue multiples from publicly traded peer companies and concluded that the estimated fair value of the investment was lower than its carrying value. During the three months ended December 31, 2022, we recorded a non-cash impairment charge of $22.2 million on our equity method investment in Linksys. In connection with our evaluation as of December 31, 2023, we determined that an additional OTTI has not occurred. However, we may be required to recognize an impairment loss in future reporting periods if and when our evaluation of the aforementioned factors indicates that the investment in Linksys is determined to be other than temporarily impaired. Such determination will be based on the prevailing facts and circumstances at that time.

[0001262039-24-000014:notes:113]
The carrying amount of our Linksys investment was $42.2 million and $84.3 million as of December 31, 2023 and 2022, respectively, and the investment was included in other assets on our consolidated balance sheets.

[0001262039-24-000014:notes:114]
Other investment

[0001262039-24-000014:notes:115]
On August 1, 2023, we invested $8.5 million in cash for a 19.5% ownership interest in the outstanding common stock of a privately held company that provides rugged ethernet switches, 4G/5G industrial routers and media converters for critical infrastructure customers. We accounted for this investment as an equity method investment since we have the ability to exercise significant influence, but not control, over the operating and financial policies of the privately held company. Determining that we have significant influence but not control over the operating and financial policies of the privately held company required significant judgement of many factors, including but not limited to the ownership interest, board representation, participation in policy-making processes and participation rights in certain significant financial and operating decisions in the ordinary course of business. Therefore, we determined to account for this investment using the equity method of accounting.

[0001262039-24-000014:notes:116]
We recorded our proportionate share of the privately held company’s financial results on a three-month lag basis and presented it in loss from equity method investments on the consolidated statements of income. Our share of income of the privately held company’s financial results, as well as our share of the amortization of the basis differences, were immaterial during 2023. The carrying amount of the investment was $8.5 million as of December 31, 2023, and the investment was included in other assets on our consolidated balance sheets.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001262039-24-000014:notes:117]
BUSINESS COMBINATIONS
2022 Acquisitions

[0001262039-24-000014:notes:118]
Network Detection and Response Business

[0001262039-24-000014:notes:119]
On December 22, 2022, we closed an acquisition of certain assets and liabilities of a business specializing in network detection and response for $18.0 million in cash. This acquisition was accounted for as a business combination using the acquisition method of accounting. Of the purchase price, $5.8 million was allocated to goodwill, $10.5 million was allocated to developed technology intangible asset, $10.0 million was allocated to customer relationships intangible asset and $8.3 million was allocated to other net liabilities assumed, which predominantly include deferred revenue. Goodwill recorded in connection with this acquisition is primarily attributable to the assembled workforce acquired and the anticipated operational synergies. All acquired goodwill is expected to be deductible for tax purposes. Acquisition-related costs related to this acquisition were not material and were recorded as general and administrative expense.

[0001262039-24-000014:notes:120]
Alaxala Networks Corporation

[0001262039-24-000014:notes:121]
On October 3, 2022, we acquired the remaining 25% of equity interests in Alaxala for $13.5 million in cash, and Alaxala became a wholly owned subsidiary.

[0001262039-24-000014:notes:122]
2021 Acquisition

[0001262039-24-000014:notes:123]
On August 31, 2021, we closed an acquisition of 75% of equity interests as controlling interests in Alaxala Networks Corporation (“Alaxala”), a privately held network hardware equipment company in Japan, for $64.2 million in cash. We

[0001262039-24-000014:notes:124]
acquired the equity interests in Alaxala to broaden our offering of secure switches integrated with our secure networking solutions.

[0001262039-24-000014:notes:125]
Under the acquisition method of accounting in accordance with ASC 805, the total purchase price was allocated to Alaxala’s identifiable tangible and intangible assets acquired and liabilities assumed based on their estimated fair values using management’s best estimates and assumptions to assign fair value as of the acquisition date. The following table provides the assets acquired and liabilities assumed as of the date of acquisition:

[0001262039-24-000014:notes:126]
| (in millions) | Estimated Fair Value |
| ASSETS |  |
| Cash | $ | 1.1 |  |
| Accounts receivable—net | 15.6 |  |
| Inventory | 33.4 |  |
| Prepaid expenses and other current assets | 2.9 |  |
| Property and equipment | 5.3 |  |
| Goodwill | 25.5 |  |
| Other intangible assets | 48.0 |  |
| Other long-term assets | 5.2 |  |
| TOTAL ASSETS | $ | 137.0 |  |
| LIABILITIES |  |
| Accounts payable | $ | 11.0 |  |
| Current portion of long-term debt | 20.2 |  |
| Accrued and other current liabilities | 17.1 |  |
| Other long-term liabilities | 6.7 |  |
| TOTAL LIABILITIES | $ | 55.0 |  |
| NON-CONTROLLING INTERESTS | $ | 17.8 |  |
| Net purchase consideration | $ | 64.2 |  |

[0001262039-24-000014:notes:127]
The excess of the purchase consideration and the fair value of non-controlling interests over the fair value of net tangible and identified intangible assets acquired was recorded as goodwill, which is not deductible for tax purposes. Goodwill is primarily attributable to the assembled workforce of Alaxala and the anticipated operational synergies.

[0001262039-24-000014:notes:128]
The fair value of the non-controlling interests of $17.8 million was estimated based on the non-controlling interests’ respective share of the fair value of Alaxala.

[0001262039-24-000014:notes:129]
Identified intangible assets acquired and their estimated useful lives as of August 31, 2021, were (in millions, except years):

[0001262039-24-000014:notes:130]
|  | Fair Value |  | Estimated Useful Life (in years) |
| Developed technology | $ | 26.6 |  |  | 4 |
| Customer relationships | 10.0 |  |  | 10 |
| Trade name | 6.4 |  |  | 10 |
| Backlog | 5.0 |  |  | 1 |
| Total identified intangible assets: | $ | 48.0 |  |  |  |

[0001262039-24-000014:notes:131]
Developed technology relates to Alaxala’s network equipment. We valued the developed technology using the relief-from-royalty method under the income approach. This method reflects the present value of the projected cost savings that are expected to be realized by avoiding the royalty that otherwise would be granted in exchange for the use of the asset. The

[0001262039-24-000014:notes:132]
economic useful life was determined based on the technology cycle related to each developed technology, as well as the cash flows over the forecast period.

[0001262039-24-000014:notes:133]
Customer relationships represent the fair value of future projected revenue that will be derived from sales to existing customers of Alaxala. Customer contracts and related relationships were valued using the multi-period excess earnings method. This method reflects the present value of the projected cash flows that are expected to be generated by the customer contracts and relationships less charges representing the contribution of other assets to those cash flows. The economic useful life was determined based on historical customer turnover rates.

[0001262039-24-000014:notes:134]
Trade name relates to the “Alaxala” trade name. The fair value was determined by applying the relief-from-royalty method under the income approach. This method is based on the application of a royalty rate to forecasted revenue under the trade name. The economic useful life was determined based on the expected life of the trade name and the cash flows anticipated over the forecast period.

[0001262039-24-000014:notes:135]
Customer backlog relates to the unfulfilled customer contract orders. Backlog was valued using the multi-period excess earnings method. This method reflects the present value of the projected cash flows that are expected to be generated by the execution of the unfulfilled customer contract orders less charges representing the contribution of other assets to those cash flows. The economic useful life was determined based on the anticipated contract orders’ execution timeframe.

[0001262039-24-000014:notes:136]
In connection with our acquisition of Alaxala, we assumed certain current debt liabilities of $20.2 million as of August 31, 2021. We concluded that the fair value of this debt approximated its book value as of the acquisition date. We repaid this debt in full in September and October 2021. During the post-acquisition period from September 1, 2021 through the repayment dates, interest expense related to Alaxala debt was not material.

[0001262039-24-000014:notes:137]
The following unaudited pro forma financial information presents the combined results of operations of Fortinet, Inc. and Alaxala, as if Alaxala had been acquired as of the beginning of business on January 1, 2020. The unaudited pro forma financial information is presented for informational purposes only and is not necessarily indicative of our consolidated results of operations of the combined business that would have been achieved if the acquisition had taken place at the beginning of business on January 1, 2020, or of the results of our future operations of the combined business. The following unaudited pro forma financial information for all periods presented includes purchase accounting adjustments for amortization of acquired intangible assets, depreciation of acquired property and equipment, the purchase accounting effect on inventory acquired and related tax effects (in millions):

[0001262039-24-000014:notes:138]
|  | Year Ended December 31, |
|  | 2021 |  | 2020 |  |  |
| Pro forma revenue | $ | 3,424.3 |  |  | $ | 2,714.7 |  |  |  |
| Pro forma net income attributable to Fortinet, Inc. | $ | 608.2 |  |  | $ | 480.0 |  |  |  |

[0001262039-24-000014:notes:139]
Additional acquisition-related information

[0001262039-24-000014:notes:140]
The operating results of the acquired companies are included in our consolidated statements of income from the respective dates of acquisition. Acquisition-related costs related to each acquisition were not material. Pro forma information has not been presented, except for Alaxala as disclosed above, as the impact of these acquisitions, individually and in the aggregate, in each year were not material to our consolidated financial statements.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001262039-24-000014:notes:141]
GOODWILL AND OTHER INTANGIBLE ASSETS—Net
Goodwill

[0001262039-24-000014:notes:142]
The following table presents the changes in the carrying amount of goodwill (in millions):

[0001262039-24-000014:notes:143]
|  | Amount |
| Balance—December 31, 2022 | $ | 128.0 |  |
| Foreign currency translation adjustments | (1.5) |  |
| Balance—December 31, 2023 | $ | 126.5 |  |

[0001262039-24-000014:notes:144]
There were no impairments to goodwill during 2023, 2022 and 2021 or any previous periods.

[0001262039-24-000014:notes:145]
Other Intangible Assets—Net

[0001262039-24-000014:notes:146]
The following tables present other intangible assets—net (in millions, except years):

[0001262039-24-000014:notes:147]
|  | December 31, 2023 |
|  | Weighted-Average Useful Life (in Years) |  | Gross |  | Accumulated Amortization |  | Net |
| Other intangible assets—net: |  |  |  |  |  |  |  |
| Finite-lived intangible assets: |  |  |  |  |  |  |  |
| Developed technologies | 4.4 |  | $ | 79.4 |  |  | $ | 60.6 |  |  | $ | 18.8 |  |
| Customer relationships | 7.1 |  | 30.4 |  |  | 17.7 |  |  | 12.7 |  |
| Trade name | 10.0 |  | 5.0 |  |  | 1.2 |  |  | 3.8 |  |
| Backlog | 1.0 |  | 3.9 |  |  | 3.9 |  |  | — |  |
| Total other intangible assets—net |  |  | $ | 118.7 |  |  | $ | 83.4 |  |  | $ | 35.3 |  |

[0001262039-24-000014:notes:148]
|  | December 31, 2022 |
|  | Weighted-Average Useful Life (in Years) |  | Gross |  | Accumulated Amortization |  | Net |
| Other intangible assets—net: |  |  |  |  |  |  |  |
| Finite-lived intangible assets: |  |  |  |  |  |  |  |
| Developed technologies | 4.1 |  | $ | 85.1 |  |  | $ | 50.3 |  |  | $ | 34.8 |  |
| Customer relationships | 7.1 |  | 31.0 |  |  | 14.4 |  |  | 16.6 |  |
| Trade name | 10.0 |  | 5.3 |  |  | 0.7 |  |  | 4.6 |  |
| Backlog | 1.0 |  | 4.2 |  |  | 4.2 |  |  | — |  |
| Total other intangible assets—net |  |  | $ | 125.6 |  |  | $ | 69.6 |  |  | $ | 56.0 |  |

[0001262039-24-000014:notes:149]
Amortization expense of finite-lived intangible assets was $18.9 million, $23.3 million and $18.5 million in 2023, 2022, and 2021, respectively.

[0001262039-24-000014:notes:150]
The following table summarizes estimated future amortization expense of finite-lived intangible assets (in millions):

[0001262039-24-000014:notes:151]
| Year Ending December 31, | Amount |
| 2024 | $ | 12.0 |  |
| 2025 | 8.2 |  |
| 2026 | 4.2 |  |
| 2027 | 3.9 |  |
| 2028 | 1.5 |  |
| Thereafter | 5.5 |  |
| Total | $ | 35.3 |  |


## us-gaap:EarningsPerShareTextBlock

[0001262039-24-000014:notes:152]
NET INCOME PER SHARE
Basic net income per share is computed by dividing net income attributable to Fortinet, Inc., by the weighted-average number of shares of common stock outstanding during the period. Diluted net income per share is computed by dividing net income attributable to Fortinet, Inc. by the weighted-average number of shares of common stock outstanding during the period, plus the dilutive effects of restricted stock units RSUs, stock options and PSUs. Dilutive shares of common stock are determined by applying the treasury stock method.

[0001262039-24-000014:notes:153]
A reconciliation of the numerator and denominator used in the calculation of basic and diluted net income per share attributable to Fortinet, Inc. is (in millions, except per share amounts):

[0001262039-24-000014:notes:154]
|  | Year Ended December 31, |
|  | 2023 |  | 2022 |  | 2021 |
| Numerator: |  |  |  |  |  |
| Net income including non-controlling interests | $ | 1,147.8 |  |  | $ | 856.6 |  |  | $ | 606.7 |  |
| Net loss attributable to non-controlling interests | — |  |  | (0.7) |  |  | (0.1) |  |
| Net income attributable to Fortinet, Inc. | $ | 1,147.8 |  |  | $ | 857.3 |  |  | $ | 606.8 |  |
| Denominator: |  |  |  |  |  |
| Basic shares: |  |  |  |  |  |
| Weighted-average common stock outstanding-basic | 778.6 |  |  | 791.4 |  |  | 816.1 |  |
| Diluted shares: |  |  |  |  |  |
| Weighted-average common stock outstanding-basic | 778.6 |  |  | 791.4 |  |  | 816.1 |  |
| Effect of potentially dilutive securities: |  |  |  |  |  |
| RSUs | 3.3 |  |  | 6.0 |  |  | 10.9 |  |
| Stock options | 6.2 |  |  | 7.9 |  |  | 8.3 |  |
| PSUs | 0.1 |  |  | — |  |  | — |  |
| Weighted-average shares used to compute diluted net income per share attributable to Fortinet, Inc. | 788.2 |  |  | 805.3 |  |  | 835.3 |  |
| Net income per share attributable to Fortinet, Inc.: |  |  |  |  |  |
| Basic | $ | 1.47 |  |  | $ | 1.08 |  |  | $ | 0.74 |  |
| Diluted | $ | 1.46 |  |  | $ | 1.06 |  |  | $ | 0.73 |  |

[0001262039-24-000014:notes:155]
The following weighted-average shares of common stock were excluded from the computation of diluted net income per share attributable to Fortinet, Inc. for the periods presented, as their effect would have been antidilutive (in millions):

[0001262039-24-000014:notes:156]
|  | Year Ended December 31, |
|  | 2023 |  | 2022 |  | 2021 |
| RSUs | 0.7 |  |  | 1.0 |  |  | 0.7 |  |
| Stock options | 2.8 |  |  | 1.5 |  |  | 1.1 |  |
| PSUs | 0.1 |  |  | — |  |  | — |  |
| Total | 3.6 |  |  | 2.5 |  |  | 1.8 |  |


## us-gaap:LesseeOperatingLeasesTextBlock

[0001262039-24-000014:notes:157]
LEASES
We have operating leases for offices, research and development facilities and data centers. Our leases have remaining terms that range from less than one year to approximately six years, some of which include one or more options to renew, with renewal terms of up to seven years. Unless and until we are reasonably certain we will exercise these renewal options, we do not include renewal options in our lease terms for calculating our lease liability, as the renewal options allow us to maintain operational flexibility. Our finance leases were not material to our consolidated financial statements.

[0001262039-24-000014:notes:158]
The components of lease expense were (in millions):

[0001262039-24-000014:notes:159]
|  | Year Ended December 31, |
|  | 2023 |  | 2022 |  | 2021 |
| Operating lease expense | $ | 43.0 |  |  | $ | 37.1 |  |  | $ | 26.5 |  |
| Variable lease expense (1) | 5.8 |  |  | 3.7 |  |  | 3.1 |  |
| Short-term lease expense | 9.3 |  |  | 5.6 |  |  | 3.7 |  |
| Total lease expense | $ | 58.1 |  |  | $ | 46.4 |  |  | $ | 33.3 |  |
| (1) Variable lease expense for the years ended December 31, 2023, 2022 and 2021 predominantly included common area maintenance charges, real estate taxes, certain parking expense, utilities based on actual usage and insurance costs. |

[0001262039-24-000014:notes:160]
Supplemental balance sheet information related to our operating leases was (in millions, except lease term and discount rate):

[0001262039-24-000014:notes:161]
|  | Classification |  | December 31,2023 |  | December 31,2022 |
| Operating lease ROU assets – non-current | Other assets |  | $ | 76.0 |  |  | $ | 96.3 |  |
| Operating lease liabilities – current | Accrued liabilities |  | $ | 33.4 |  |  | $ | 33.2 |  |
| Operating lease liabilities – non-current | Other liabilities |  | 45.7 |  |  | 62.5 |  |
| Total operating lease liabilities |  |  | $ | 79.1 |  |  | $ | 95.7 |  |
| Weighted average remaining lease term in years – operating leases |  |  | 3.1 |  | 3.5 |
| Weighted average discount rate – operating leases |  |  | 4.5 | % |  | 3.5 | % |

[0001262039-24-000014:notes:162]
Supplemental cash flow information related to leases was (in millions):

[0001262039-24-000014:notes:163]
|  | Year Ended December 31, |
|  | 2023 |  | 2022 |  | 2021 |
| Cash paid for amounts included in the measurement of lease liabilities |  |  |  |  |  |
| Operating cash flows used for operating leases | $ | 40.0 |  |  | $ | 33.8 |  |  | $ | 25.8 |  |

[0001262039-24-000014:notes:164]
Maturities of operating lease liabilities as of December 31, 2023 were (in millions):

[0001262039-24-000014:notes:165]
| Year Ending December 31, | Amount |
| 2024 | $ | 33.0 |  |
| 2025 | 20.4 |  |
| 2026 | 11.5 |  |
| 2027 | 8.0 |  |
| 2028 | 10.2 |  |
| Thereafter | 3.3 |  |
| Total lease payments | $ | 86.4 |  |
| Less imputed interest | (7.3) |  |
| Total | $ | 79.1 |  |

[0001262039-24-000014:notes:166]
As of December 31, 2023, our operating leases that had been signed but had not yet commenced were not material.


## us-gaap:DebtDisclosureTextBlock

[0001262039-24-000014:notes:167]
DEBT
2026 and 2031 Senior Notes

[0001262039-24-000014:notes:168]
On March 5, 2021, we issued $1.0 billion aggregate principal amount of senior notes (collectively, the “Senior Notes”), consisting of $500.0 million aggregate principal amount of 1.0% notes due March 15, 2026 (the “2026 Senior Notes”) and $500.0 million aggregate principal amount of 2.2% notes due March 15, 2031 (the “2031 Senior Notes”), in an underwritten registered public offering. The Senior Notes are senior unsecured obligations and rank equally with each other in right of payment and with our other outstanding obligations. We may redeem the Senior Notes at any time in whole or in part for cash, at specified redemption prices that include accrued and unpaid interest, if any, and a make-whole premium. However, no make-whole premium will be paid for redemptions of the 2026 Senior Notes on or after February 15, 2026, or the 2031 Senior Notes on or after December 15, 2030. Interest on the Senior Notes is payable on March 15 and September 15 of each year, beginning on September 15, 2021. As of December 31, 2023, the Senior Notes were recorded as long-term debt, net of discount and issuance costs, which are amortized to interest expense over the respective contractual terms of these notes using the effective interest method.

[0001262039-24-000014:notes:169]
The total outstanding debt is summarized below (in millions, except percentages):

[0001262039-24-000014:notes:170]
|  | Maturity |  | Coupon Rate |  | Effective Interest Rate |  | December 31,2023 |
| Debt |  |  |  |  |  |  |  |
| 2026 Senior Notes | March 2026 |  | 1.0 | % |  | 1.3 | % |  | $ | 500.0 |  |
| 2031 Senior Notes | March 2031 |  | 2.2 | % |  | 2.3 | % |  | 500.0 |  |
| Total debt |  |  |  |  |  |  | 1,000.0 |  |
| Less: Unamortized discount and debt issuance costs |  |  |  |  |  |  | 7.7 |  |
| Total long-term debt |  |  |  |  |  |  | $ | 992.3 |  |

[0001262039-24-000014:notes:171]
As of December 31, 2023 and 2022, we accrued interest payable of $4.7 million, and there are no financial covenants with which we must comply. In 2023, 2022 and 2021 we recorded $17.9 million, $17.9 million and $14.7 million of total interest expense in relation to these Senior Notes and repaid $16.0 million, $16.0 million and $8.4 million of interest in cash, respectively. No interest costs were capitalized in 2023, 2022 and 2021, as the costs that qualified for capitalization were not material.

[0001262039-24-000014:notes:172]
The total estimated fair value of the outstanding Senior Notes was approximately $882.6 million, including accrued and unpaid interest, as of December 31, 2023. The fair value was determined based on observable market prices of identical instruments in less active markets. The estimated fair values are based on Level 2 inputs.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001262039-24-000014:notes:173]
COMMITMENTS AND CONTINGENCIES
The following table summarizes our inventory purchase commitments as of December 31, 2023 (in millions):

[0001262039-24-000014:notes:174]
|  | Total |  | 2024 |  | Thereafter |
| Inventory purchase commitments | $ | 637.3 |  |  | $ | 381.5 |  |  | $ | 255.8 |  |

[0001262039-24-000014:notes:175]
Inventory Purchase Commitments—Our independent contract manufacturers and certain component suppliers procure components and build our products based on our forecasts, the availability of various components and their capacity. These forecasts are based on estimates of future demand for our products, which are in turn based on historical trends and an analysis from our sales and marketing organizations, adjusted for lead times, changes in supplier delivery commitments and other supply chain matters and market conditions. In order to manage manufacturing lead times, plan for adequate component supply and incentivize suppliers to deliver, we may issue purchase orders to some of our independent contract manufacturers which are non-cancelable. As of December 31, 2023, we had $637.3 million of open purchase orders with our independent contract manufacturers that consist of non-cancelable commitments. In certain instances, these agreements allow us the option to reschedule and adjust our requirements based on our business needs prior to firm orders being placed. We record a liability for non-cancelable inventory purchase commitments for quantities in excess of our future estimated demand forecasts, consistent with the valuation of our excess and obsolete inventory. As of December 31, 2023, the liability for these inventory purchase commitments was $84.7 million and was included in accrued liabilities. The expense related to such accrued liability

[0001262039-24-000014:notes:176]
for inventory purchase commitments was $85.9 million for the year ended December 31, 2023, and not material for the years ended December 31, 2022 and 2021, and was recorded in cost of product revenue on the consolidated statements of income.

[0001262039-24-000014:notes:177]
Other Contractual Commitments and Open Purchase Orders—In addition to commitments with contract manufacturers and certain component suppliers, we have open purchase orders and contractual obligations in the ordinary course of business for which we have not received goods or services. A significant portion of our reported purchase commitments consist of firm and non-cancelable commitments. In certain instances, contractual commitments allow us the option to cancel, reschedule, and adjust our requirements based on our business needs prior to firm orders being placed. As of December 31, 2023, we had $66.9 million in other contractual commitments having a remaining term in excess of one year that are non-cancelable.

[0001262039-24-000014:notes:178]
Litigation—We are involved in disputes, litigation, and other legal actions. For lawsuits where we are the defendant, we are in the process of defending these litigation matters, and while there can be no assurances and the outcome of certain of these matters is currently not determinable and not predictable, we currently are unaware of any existing claims or proceedings that we believe are likely to have a material adverse effect on our financial position. There are many uncertainties associated with any litigation and these actions or other third-party claims against us may cause us to incur costly litigation fees, costs and substantial settlement charges, and possibly subject us to damages and other penalties. In addition, the resolution of any intellectual property (“IP”) litigation may require us to make royalty payments, which could adversely affect our gross margins in future periods. If any of those events were to occur, our business, financial condition, results of operations, and cash flows could be adversely affected. Litigation is unpredictable and the actual liability in any such matters may be materially different from our current estimates, which could result in the need to adjust any accrued liability and record additional expenses. We accrue for contingencies when we believe that a loss is probable and that we can reasonably estimate the amount of any such loss. These accruals are generally based on a range of possible outcomes that require significant management judgement. If no amount within a range is a better estimate than any other, we accrue the minimum amount. Litigation loss contingency accruals associated with outstanding cases were not material as of December 31, 2023 and 2022.

[0001262039-24-000014:notes:179]
On March 21, 2019, we were sued by Alorica Inc. (“Alorica”) in Santa Clara County Superior Court in California. Alorica has alleged breach of warranty and misrepresentation claims, which we deny. Fact discovery closed during the quarter ended June 30, 2023. Trial is set for May 2024. Although we believe that the ultimate outcome of this matter will not materially impact our financial position, results of operations or cash flows, legal proceedings are subject to inherent uncertainties, and an unfavorable ruling could occur, which may result in a material adverse impact on our business, financial position, results of operations and cash flows. No loss accrual had been recorded as of December 31, 2023 related to this litigation.

[0001262039-24-000014:notes:180]
Indemnification and Other Matters—Under the indemnification provisions of our standard sales contracts, we agree to defend our customers against third-party claims asserting various allegations such as product defects and infringement of certain IP rights, which may include patents, copyrights, trademarks or trade secrets, and to pay judgments entered on such claims. In some contracts, our exposure under these indemnification provisions is limited by the terms of the contracts to certain defined limits, such as the total amount paid by our customer under the agreement. However, certain agreements include covenants, penalties and indemnification provisions including and beyond indemnification for third-party claims of IP infringement that could potentially expose us to losses in excess of the amount received under the agreement, and in some instances to potential liability that is not contractually limited. Although from time to time there are indemnification claims asserted against us and currently there are pending indemnification claims, to date there have been no material awards under such indemnification provisions.

[0001262039-24-000014:notes:181]
Similar to other security companies and companies in other industries, we have experienced and may experience in the future, cybersecurity threats, malicious activity directed against our information technology infrastructure or unauthorized attempts to gain access to our and our customers’ sensitive information and systems. We currently are unaware of any existing claims or proceedings related to these types of matters, including any that we believe are likely to have a material adverse effect on our financial position.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001262039-24-000014:notes:182]
EQUITY PLANS AND SHARE REPURCHASE PROGRAM
Stock-Based Compensation Plans

[0001262039-24-000014:notes:183]
We have one primary stock incentive plan, the 2009 EIP, under which we have granted RSUs, stock options and PSUs.

[0001262039-24-000014:notes:184]
Our board of directors approved the 2009 EIP in 2009 and amended the plan in 2019. The maximum aggregate number of shares that may be issued under the 2009 EIP is 239,367,655 shares; provided, however, that only 67,500,000 shares may be

[0001262039-24-000014:notes:185]
issued or transferred pursuant to new awards granted on or following the effective date of the 2009 EIP. We may grant awards to employees, directors and other service providers. In the case of an incentive stock option granted to an employee who, at the time of the grant, owns stock representing more than 10% of the voting power of all classes of stock, the exercise price shall be no less than 110% of the fair market value per share on the date of grant and expire no more than five years from the date of grant, and options granted to any other employee, the per share exercise price shall be no less than 100% of the closing stock price on the date of grant. In the case of a non-statutory stock option and options granted to other service providers, the per share exercise price shall be no less than 100% of the fair market value per share on the date of grant. Options granted to individuals owning less than 10% of the total combined voting power of all classes of stock generally have a contractual term of no more than ten years and options generally vest over four years.

[0001262039-24-000014:notes:186]
As of December 31, 2023, there were a total of 53.6 million shares of common stock available for grant under the 2009 EIP.

[0001262039-24-000014:notes:187]
Restricted Stock Units

[0001262039-24-000014:notes:188]
The following table summarizes the activity and related information for RSUs for the periods presented below (in millions, except per share amounts):

[0001262039-24-000014:notes:189]
|  | Restricted Stock Units Outstanding |
|  | Number of Shares |  | Weighted-Average Grant Date Fair Value per Share |
| Balance—December 31, 2020 | 23.4 |  |  | $ | 18.09 |  |
| Granted | 5.8 |  |  | 40.53 |  |
| Forfeited | (1.8) |  |  | 22.99 |  |
| Vested | (11.7) |  |  | 16.30 |  |
| Balance—December 31, 2021 | 15.7 |  |  | 27.06 |  |
| Granted | 4.1 |  |  | 58.09 |  |
| Forfeited | (1.1) |  |  | 34.94 |  |
| Vested | (8.2) |  |  | 23.69 |  |
| Balance—December 31, 2022 | 10.5 |  |  | 40.94 |  |
| Granted | 4.8 |  |  | 60.14 |  |
| Forfeited | (0.8) |  |  | 49.85 |  |
| Vested | (5.4) |  |  | 35.47 |  |
| Balance—December 31, 2023 | 9.1 |  |  | $ | 53.61 |  |

[0001262039-24-000014:notes:190]
Stock compensation expense is recognized on a straight-line basis over the vesting period of each RSU. As of December 31, 2023, total compensation expense related to unvested RSUs granted to employees and non-employees under the 2009 EIP, but not yet recognized, was $413.8 million, with a weighted-average remaining vesting period of 2.6 years.

[0001262039-24-000014:notes:191]
RSUs settle into shares of common stock upon vesting. Upon the vesting of the RSUs, we net-settle the RSUs and withhold a portion of the shares to satisfy employee withholding tax requirements. The payment of the withheld taxes to the tax authorities is reflected as a financing activity within the consolidated statements of cash flows.

[0001262039-24-000014:notes:192]
The following summarizes the number and value of the shares withheld for employee taxes (in millions):

[0001262039-24-000014:notes:193]
|  | Year Ended December 31, |
|  | 2023 |  | 2022 |  | 2021 |
| Shares withheld for taxes | 1.8 |  |  | 2.7 |  |  | 3.8 |  |
| Amount withheld for taxes | $ | 112.5 |  |  | $ | 160.4 |  |  | $ | 167.9 |  |

[0001262039-24-000014:notes:194]
Employee Stock Options

[0001262039-24-000014:notes:195]
In determining the fair value of our employee stock options, we use the Black-Scholes model, which employs the following assumptions.

[0001262039-24-000014:notes:196]
Expected Term—The expected term represents the period that our stock-based awards are expected to be outstanding. We believe that we have sufficient historical experience for determining the expected term of the stock option award, and therefore, we calculated our expected term based on historical experience instead of using the simplified method.

[0001262039-24-000014:notes:197]
Expected Volatility—The expected volatility of our common stock is based on our weighted-average implied and historical volatility.

[0001262039-24-000014:notes:198]
Fair Value of Common Stock—The fair value of our common stock is the closing sales price of the common stock effective on the date of grant.

[0001262039-24-000014:notes:199]
Risk-Free Interest Rate—We base the risk-free interest rate on the implied yield available on U.S. Treasury zero-coupon issues with an equivalent remaining term.

[0001262039-24-000014:notes:200]
Expected Dividend—The expected dividend weighted-average assumption is zero.

[0001262039-24-000014:notes:201]
The following table summarizes the weighted-average assumptions relating to our employee stock options:

[0001262039-24-000014:notes:202]
|  | Year Ended December 31, |
|  | 2023 |  | 2022 |  | 2021 |
| Expected term in years | 4.4 |  | 4.4 |  | 4.4 |
| Volatility | 42.0 | % |  | 41.6 | % |  | 39.1 | % |
| Risk-free interest rate | 4.2 | % |  | 2.2 | % |  | 0.5 | % |
| Dividend rate | — | % |  | — | % |  | — | % |

[0001262039-24-000014:notes:203]
The following table summarizes the stock option activity and related information for the periods presented below (in millions, except exercise prices and contractual life):

[0001262039-24-000014:notes:204]
|  | Options Outstanding |
|  | Numberof Shares |  | Weighted-AverageExercisePrice |  | Weighted-AverageRemainingContractualLife (Years) |  | AggregateIntrinsicValue |
| Balance—December 31, 2020 | 13.6 |  |  | $ | 13.51 |  |  | 4.2 |  | 220.4 |  |
| Granted | 2.9 |  |  | 37.26 |  |  |  |  |  |
| Forfeited | (0.4) |  |  | 24.53 |  |  |  |  |  |
| Exercised | (2.4) |  |  | 11.01 |  |  |  |  |  |
| Balance—December 31, 2021 | 13.7 |  |  | 18.57 |  |  | 4.0 |  | 729.9 |  |
| Granted | 1.7 |  |  | 60.26 |  |  |  |  |  |
| Forfeited | (0.2) |  |  | 37.03 |  |  |  |  |  |
| Exercised | (2.0) |  |  | 13.10 |  |  |  |  |  |
| Balance—December 31, 2022 | 13.2 |  |  | 24.37 |  |  | 3.5 |  | 344.8 |  |
| Granted | 1.3 |  |  | 60.16 |  |  |  |  |  |
| Forfeited | (0.2) |  |  | 49.13 |  |  |  |  |  |
| Exercised | (3.1) |  |  | 14.11 |  |  |  |  |  |
| Balance—December 31, 2023 | 11.2 |  |  | $ | 31.14 |  |  |  |  |  |
| Options vested and expected to vest—December 31, 2023 | 11.2 |  |  | $ | 31.14 |  |  | 3.3 |  | $ | 315.8 |  |
| Options exercisable—December 31, 2023 | 8.2 |  |  | $ | 23.02 |  |  | 2.6 |  | $ | 293.2 |  |

[0001262039-24-000014:notes:205]
The aggregate intrinsic value represents the difference between the exercise price of stock options and the quoted market price of our common stock at the date of balance sheet for all in-the-money stock options. Stock compensation expense is recognized on a straight-line basis over the vesting period of each stock option. As of December 31, 2023, total compensation expense related to unvested stock options granted to employees but not yet recognized was $54.6 million, with a weighted-average remaining vesting period of 2.5 years.

[0001262039-24-000014:notes:206]
Additional information related to our stock options is summarized below (in millions, except per share amounts):

[0001262039-24-000014:notes:207]
|  | Year Ended December 31, |
|  | 2023 |  | 2022 |  | 2021 |
| Weighted-average fair value per share granted | $ | 24.20 |  |  | $ | 22.18 |  |  | $ | 12.15 |  |
| Intrinsic value of options exercised | $ | 140.7 |  |  | $ | 88.4 |  |  | $ | 83.5 |  |
| Fair value of options vested | $ | 30.1 |  |  | $ | 24.9 |  |  | $ | 17.2 |  |

[0001262039-24-000014:notes:208]
The following table summarizes information about outstanding and exercisable stock options as of December 31, 2023, (in millions, except exercise prices and contractual life):

[0001262039-24-000014:notes:209]
|  |  | Options Outstanding |  | Options Exercisable |
| Range of Exercise Prices |  | NumberOutstanding |  | Weighted-AverageRemainingContractualLife (Years) |  | Weighted-AverageExercisePrice |  | NumberExercisable |  | Weighted-AverageExercisePrice |
| $7.34-$16.65 |  | 2.6 |  |  | 1.0 |  | $ | 9.66 |  |  | 2.6 |  |  | $ | 9.66 |  |
| $16.90-$22.90 |  | 3.5 |  |  | 2.6 |  | 19.90 |  |  | 3.4 |  |  | 19.81 |  |
| $26.72-$60.21 |  | 3.6 |  |  | 4.9 |  | 44.24 |  |  | 1.5 |  |  | 35.63 |  |
| $61.13-$68.70 |  | 1.5 |  |  | 5.1 |  | 62.76 |  |  | 0.7 |  |  | 62.49 |  |
|  |  | 11.2 |  |  |  |  |  |  | 8.2 |  |  |  |

[0001262039-24-000014:notes:210]
Market/Performance-Based PSUs

[0001262039-24-000014:notes:211]
In 2023, we granted market/performance-based PSUs under the 2009 EIP to certain of our executives. Based on the achievement of the market/performance-based vesting conditions during the performance period, the final settlement of the PSUs will range between 0% and 200% of the target shares underlying the PSUs based on the percentile ranking of our total stockholder return over one-, two-, three- and four-year periods among companies included in the S&P 500 Index. 20%, 20%, 20% and 40% of the PSUs vest over one-, two-, three- and four-year service periods, respectively.

[0001262039-24-000014:notes:212]
We granted approximately 0.3 million shares of PSU awards with a grant date fair value of $90.96 per share to certain of our executives during the first quarter of 2023. The grant date fair value of these awards was determined using a Monte Carlo simulation pricing model. The following table summarizes the weighted-average assumptions relating to our PSUs for the three months ended March 31, 2023:

[0001262039-24-000014:notes:213]
|  | Three Months Ended |
|  | March 31,2023 |
| Expected term in years | 2.7 |
| Volatility | 47.5 | % |
| Risk-free interest rate | 4.6 | % |
| Dividend rate | — | % |

[0001262039-24-000014:notes:214]
None of these PSU awards were vested and PSU awards forfeited were immaterial during the year ended December 31, 2023.

[0001262039-24-000014:notes:215]
As of December 31, 2023, total compensation expense related to unvested PSUs that were granted to certain of our executives, but not yet recognized, was $16.1 million. This expense is expected to be amortized on a graded vesting method over a weighted-average vesting period of 2.4 years.

[0001262039-24-000014:notes:216]
Shares Reserved for Future Issuances

[0001262039-24-000014:notes:217]
The following table presents the common stock reserved for future issuance (in millions):

[0001262039-24-000014:notes:218]
|  | December 31,2023 |
| Reserved for future equity award grants | 53.6 |  |
| Outstanding stock options, RSUs and PSUs | 20.6 |  |
| Total common stock reserved for future issuances | 74.2 |  |

[0001262039-24-000014:notes:219]
Stock-Based Compensation Expense

[0001262039-24-000014:notes:220]
Stock-based compensation expense, including stock-based compensation expense related to awards classified as liabilities, is included in costs and expenses (in millions):

[0001262039-24-000014:notes:221]
|  | Year Ended December 31, |
|  | 2023 |  | 2022 |  | 2021 |
| Cost of product revenue | $ | 1.8 |  |  | $ | 1.7 |  |  | $ | 1.7 |  |
| Cost of service revenue | 23.3 |  |  | 18.8 |  |  | 15.7 |  |
| Research and development | 76.8 |  |  | 64.2 |  |  | 56.7 |  |
| Sales and marketing | 111.8 |  |  | 105.0 |  |  | 110.0 |  |
| General and administrative | 37.9 |  |  | 30.1 |  |  | 27.1 |  |
| Total stock-based compensation expense | $ | 251.6 |  |  | $ | 219.8 |  |  | $ | 211.2 |  |

[0001262039-24-000014:notes:222]
The following table summarizes stock-based compensation expense, including stock-based compensation expense related to awards classified as liabilities, by award type (in millions):

[0001262039-24-000014:notes:223]
|  | Year Ended December 31, |
|  | 2023 |  | 2022 |  | 2021 |
| RSUs | $ | 211.8 |  |  | $ | 195.0 |  |  | $ | 191.8 |  |
| Stock options | 28.8 |  |  | 24.8 |  |  | 19.4 |  |
| PSUs | $ | 11.0 |  |  | $ | — |  |  | $ | — |  |
| Total stock-based compensation expense | $ | 251.6 |  |  | $ | 219.8 |  |  | $ | 211.2 |  |

[0001262039-24-000014:notes:224]
Total income tax benefit associated with stock-based compensation that is recognized in the consolidated statements of income is (in millions):

[0001262039-24-000014:notes:225]
|  | Year Ended December 31, |
|  | 2023 |  | 2022 |  | 2021 |
| Income tax benefit associated with stock-based compensation | $ | 55.5 |  |  | $ | 48.6 |  |  | $ | 45.4 |  |

[0001262039-24-000014:notes:226]
Share Repurchase Program

[0001262039-24-000014:notes:227]
In January 2016, our board of directors approved the Repurchase Program, which authorized the repurchase of up to $200.0 million of our outstanding common stock through December 31, 2017. From 2016 through 2022, our board of directors approved increases to our Repurchase Program by various amounts and extended the term to February 28, 2023, bringing the aggregated amount authorized to $5.25 billion. In February 2023, our board of directors approved an extension of the Repurchase Program to February 29, 2024. In April 2023 and July 2023, our board of directors approved $1.0 billion and $500.0 million increases in the authorized stock repurchase amount under the Repurchase Program, bringing the aggregate amount authorized to be repurchased to $6.75 billion. Under the Repurchase Program, share repurchases may be made by us from time to time in privately negotiated transactions or in open market transactions. The Repurchase Program does not require us to purchase a minimum number of shares, and may be suspended, modified or discontinued at any time without prior notice. In 2023, we repurchased 27.2 million shares of common stock under the Repurchase Program in open market transactions for an aggregate purchase price of $1.50 billion, which excludes a $10.9 million accrual related to the 1% excise tax imposed by the Inflation Reduction Act of 2022. As of December 31, 2023, $529.1 million remained available for future share repurchases under the Repurchase Program. Refer to Note 17, Subsequent Events, for information regarding the approved $500.0 million increase in the authorized stock repurchase amount under the Repurchase Program in January 2024 and the extension of the Repurchase Program to February 28, 2025 in February 2024.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001262039-24-000014:notes:228]
INCOME TAXES 
Income before income taxes and loss from equity method investments consisted of (in millions):

[0001262039-24-000014:notes:229]
|  | Year Ended December 31, |
|  | 2023 |  | 2022 |  | 2021 |
| Domestic | $ | 1,195.0 |  |  | $ | 873.8 |  |  | $ | 567.7 |  |
| Foreign | 138.7 |  |  | 81.7 |  |  | 60.7 |  |
| Total income before income taxes and loss from equity method investments | $ | 1,333.7 |  |  | $ | 955.5 |  |  | $ | 628.4 |  |

[0001262039-24-000014:notes:230]
The provision for (benefit from) income taxes consisted of (in millions):

[0001262039-24-000014:notes:231]
|  | Year Ended December 31, |
|  | 2023 |  | 2022 |  | 2021 |
| Current: |  |  |  |  |  |
| Federal | $ | 398.5 |  |  | $ | 218.5 |  |  | $ | 80.7 |  |
| State | 27.7 |  |  | 19.1 |  |  | 2.5 |  |
| Foreign | 24.3 |  |  | 18.8 |  |  | 23.3 |  |
| Total current | $ | 450.5 |  |  | $ | 256.4 |  |  | $ | 106.5 |  |
| Deferred: |  |  |  |  |  |
| Federal | $ | (281.1) |  |  | $ | (208.3) |  |  | $ | (90.2) |  |
| State | (18.9) |  |  | (14.9) |  |  | (1.1) |  |
| Foreign | (6.7) |  |  | (2.4) |  |  | (1.1) |  |
| Total deferred | (306.7) |  |  | (225.6) |  |  | (92.4) |  |
| Provision for income taxes | $ | 143.8 |  |  | $ | 30.8 |  |  | $ | 14.1 |  |

[0001262039-24-000014:notes:232]
The foreign tax provision included the tax impacts from U.S. GAAP to local tax return book to tax differences that create a permanent addback including but not limited to stock compensation, meals and entertainment, and settlement of prior year tax audits with foreign jurisdiction adjustments.

[0001262039-24-000014:notes:233]
The provision for income taxes differs from the amount computed by applying the statutory federal income tax rate (in millions):

[0001262039-24-000014:notes:234]
|  | Year Ended December 31, |
|  | 2023 |  | 2022 |  | 2021 |
| Tax at federal statutory tax rate | $ | 280.1 |  |  | $ | 200.6 |  |  | $ | 132.0 |  |
| Foreign income taxed at different rates | 27.0 |  |  | 15.7 |  |  | 2.9 |  |
| Foreign withholding taxes | 35.1 |  |  | 31.0 |  |  | 37.4 |  |
| Stock-based compensation expense | (54.3) |  |  | (81.1) |  |  | (74.8) |  |
| Foreign tax credit | (72.6) |  |  | (26.2) |  |  | (53.2) |  |
| State taxes—net of federal benefit | 5.0 |  |  | (3.2) |  |  | (4.6) |  |
| Research and development credit | (14.0) |  |  | (11.6) |  |  | (11.1) |  |
| Valuation allowance | (67.7) |  |  | 25.9 |  |  | 20.0 |  |
| Impact of the 2017 Tax Cuts and Jobs Act: |  |  |  |  |  |
| One-time transition tax | — |  |  | — |  |  | 5.8 |  |
| Tax effect of a law change | (20.8) |  |  | — |  |  | — |  |
| Foreign-Derived Intangible Income ("FDII") | (89.5) |  |  | (115.2) |  |  | (33.6) |  |
| Adjustment to prior year’s FDII | 92.8 |  |  | — |  |  | — |  |
| Other | 22.7 |  |  | (5.1) |  |  | (6.7) |  |
| Total provision for income taxes | $ | 143.8 |  |  | $ | 30.8 |  |  | $ | 14.1 |  |

[0001262039-24-000014:notes:235]
Effective January 1, 2022, research and development expenses are required to be capitalized and amortized for U.S. tax purposes, which delays the deductibility of these expenses, and increases our current provision.

[0001262039-24-000014:notes:236]
During 2023, we changed our position regarding the allocation and apportionment of expenses for income tax purposes. This change in approach affected the amount of our FDII benefit and our ability to utilize certain foreign tax credits. As a result, our FDII benefits recorded in prior years decreased by $92.8 million, partially offset by an increased benefit for the utilization of foreign tax credits of $63.1 million. These foreign tax credit carryforwards were previously expected to have expired unutilized resulting in the recording of a full valuation allowance thereon. Accordingly, the benefit recognized as a result of their utilization is included in the benefit from the release of a valuation allowance of $67.7 million.

[0001262039-24-000014:notes:237]
On January 4, 2022, the U.S. Treasury published another tranche of final regulations regarding the foreign tax credit. These final regulations impose new requirements that a foreign tax must meet in order to be creditable against U.S. income taxes, and generally apply to tax years beginning on or after December 28, 2021. On July 26, 2022, the U.S. Treasury released corrections to the final regulations. On July 21, 2023, the IRS released a notice that suspended the application of significant portions of the final regulations regarding the foreign tax credit for tax years 2022 and 2023. The notice released in July 2023 favorably impacted our ability to claim foreign tax credits in the United States for certain taxes imposed by certain foreign jurisdictions. On December 11, 2023, the IRS released a notice that extended the suspension of significant portions of the final regulations beyond December 31, 2023, until further guidance is issued.

[0001262039-24-000014:notes:238]
On August 16, 2022, the United States enacted the Inflation Reduction Act of 2022 that provides for certain changes to the U.S. corporate income tax system, including a 15% minimum tax based on financial statement income for companies with three-year average annual adjusted financial statement income exceeding $1 billion, and a 1% excise tax on net repurchases of stock after December 31, 2022, if any. The applicable tax law changes have had no impact to our tax provision for the year ended December 31, 2023. We will continue to evaluate the impact of these tax law changes on future periods.

[0001262039-24-000014:notes:239]
In December 2021, the Organisation for Economic Co-operation and Development (the “OECD”) enacted model rules for a new global minimum tax framework (“BEPS Pillar Two”), and various governments around the world have enacted, or are in the process of enacting, legislation on this. We are in the process of assessing the tax impact of Pillar Two legislation becoming applicable to us beginning January 1, 2024, and believe these rules will not have a material impact on our provision for income taxes.

[0001262039-24-000014:notes:240]
The tax effects of temporary differences that give rise to significant portions of the deferred tax assets as of the years ended are presented below (in millions):

[0001262039-24-000014:notes:241]
|  | December 31,2023 |  | December 31,2022 |
| Deferred tax assets: |  |  |  |
| General business credit carryforward | $ | 29.5 |  |  | $ | 95.0 |  |
| Deferred revenue | 528.0 |  |  | 380.1 |  |
| Reserves and accruals | 134.1 |  |  | 90.1 |  |
| Net operating loss carryforward | 19.2 |  |  | 21.2 |  |
| Stock-based compensation expense | 25.1 |  |  | 19.8 |  |
| Depreciation and amortization | 8.1 |  |  | 5.6 |  |
| Capitalized research expenditures | 295.0 |  |  | 176.7 |  |
| Operating lease liabilities | 17.4 |  |  | 20.8 |  |
| Total deferred tax assets | 1,056.4 |  |  | 809.3 |  |
| Less: Valuation allowance | (33.2) |  |  | (100.8) |  |
| Deferred tax assets, net of valuation allowance | 1,023.2 |  |  | 708.5 |  |
| Deferred tax liabilities: |  |  |  |
| Deferred contract costs | (136.9) |  |  | (117.5) |  |
| Operating lease ROU assets | (16.7) |  |  | (20.9) |  |
| Acquired intangibles | (3.7) |  |  | (8.8) |  |
| Total deferred tax liabilities | (157.3) |  |  | (147.2) |  |
| Net deferred tax assets | $ | 865.9 |  |  | $ | 561.3 |  |

[0001262039-24-000014:notes:242]
In assessing the realizability of deferred tax assets, we considered whether it is more likely than not that some portion or all of our deferred tax assets will be realized. This realization is dependent upon the generation of future taxable income during the periods in which those temporary differences become deductible. We concluded that it is more likely than not that we will be able to realize the benefits of our deferred tax assets in the future except for our California research and development credits carryforward, certain impairment losses in business investments and certain tax attributes from business acquisitions. As of December 31, 2023, we had a valuation allowance of $33.2 million against those items.

[0001262039-24-000014:notes:243]
As of December 31, 2023, our federal and California net operating loss carryforwards for income tax purposes were $67.0 million and $20.8 million, respectively. All the net operating loss carryforwards were from acquisitions which were limited by Section 382 of the Internal Revenue Code. If not utilized, the federal net operating loss carryforwards will begin to expire in 2024, and California net operating loss carryforwards will begin to expire in 2034.

[0001262039-24-000014:notes:244]
As of December 31, 2023, we had state tax credit carryforwards of $45.3 million. The state credits can be carried forward indefinitely.

[0001262039-24-000014:notes:245]
The aggregate changes in the balance of unrecognized tax benefits are (in millions):

[0001262039-24-000014:notes:246]
|  | Year Ended December 31, |
|  | 2023 |  | 2022 |  | 2021 |
| Unrecognized tax benefits, beginning of year | $ | 67.4 |  |  | $ | 73.3 |  |  | $ | 77.3 |  |
| Gross increases for tax positions related to the current year | 11.4 |  |  | 13.6 |  |  | 7.6 |  |
| Gross decreases for tax positions related to the current year | — |  |  | — |  |  | — |  |
| Gross increases for tax positions related to the prior year | 1.0 |  |  | 0.9 |  |  | 8.7 |  |
| Gross decreases for tax positions related to prior year | (4.0) |  |  | (2.0) |  |  | (0.7) |  |
| Gross decreases for tax positions related to prior year audit settlements | — |  |  | — |  |  | — |  |
| Gross decreases for tax positions related to expiration of statute of limitations | (10.0) |  |  | (18.4) |  |  | (19.6) |  |
| Unrecognized tax benefits, end of year | $ | 65.8 |  |  | $ | 67.4 |  |  | $ | 73.3 |  |

[0001262039-24-000014:notes:247]
As of December 31, 2023, we had $65.8 million of unrecognized tax benefits, of which, if recognized, $55.5 million would favorably affect our effective tax rate. Our gross unrecognized tax benefits decreased approximately $1.6 million during the year ended December 31, 2023. The net decrease was primarily due to the reversal of gross unrecognized tax benefits in connection with the lapse of statutes of limitations. Our policy is to include accrued interest and penalties related to uncertain tax benefits in income tax expense. As of December 31, 2023, 2022 and 2021, accrued interest and penalties were $6.4 million, $9.3 million and $13.3 million, respectively.

[0001262039-24-000014:notes:248]
It is reasonably possible that our gross unrecognized tax benefits will decrease up to $3.9 million in the next 12 months, primarily due to the lapse of the statute of limitations. These adjustments, if recognized, would favorably impact our effective tax rate, and would be recognized as additional tax benefits.

[0001262039-24-000014:notes:249]
We file income tax returns in the U.S. federal jurisdiction and in various U.S. state and foreign jurisdictions. Generally, we are no longer subject to examination by U.S. federal income tax authorities for tax years prior to 2015. We are no longer subject to U.S. state and foreign income tax examinations by tax authorities for tax years prior to 2010. We currently have ongoing tax audits in the United Kingdom, Canada, Germany and several other foreign jurisdictions. The focus of these audits is the inter-company profit allocation.


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0001262039-24-000014:notes:250]
DEFINED CONTRIBUTION PLANS
Our tax-deferred savings plan under our 401(k) Plan permits participating U.S. employees to contribute a portion of their pre-tax or after-tax earnings. In Canada, we have a Group Registered Retirement Savings Plan Program (the “RRSP”), which permits participants to make pre-tax contributions. Our board of directors approved 50% matching contributions on employee contributions up to 4% of each employee’s eligible earnings. Our matching contributions to our 401(k) Plan and the RRSP for 2023, 2022 and 2021 were $17.1 million, $12.6 million and $10.0 million, respectively.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001262039-24-000014:notes:251]
SEGMENT INFORMATION
Operating segments are defined as components of an enterprise about which separate financial information is available that is evaluated regularly by the chief operating decision maker in deciding how to allocate resources and in assessing performance. Our chief operating decision maker is our chief executive officer. Our chief executive officer reviews financial information presented on a consolidated basis, accompanied by information about revenue by geographic region for purposes of allocating resources and evaluating financial performance. We have one business activity, and there are no segment managers who are held accountable for operations, operating results and plans for levels or components below the consolidated unit level. Accordingly, we have determined that we have one operating segment, and therefore, one reportable segment.

[0001262039-24-000014:notes:252]
Revenue by geographic region is based on the billing address of our customers. The following tables set forth revenue and property and equipment—net by geographic region (in millions):

[0001262039-24-000014:notes:253]
|  | Year Ended December 31, |
| Revenue | 2023 |  | 2022 |  | 2021 |
| Americas: |  |  |  |  |  |
| United States | $ | 1,605.9 |  |  | $ | 1,325.0 |  |  | $ | 1,006.8 |  |
| Other Americas | 569.3 |  |  | 460.0 |  |  | 352.0 |  |
| Total Americas | 2,175.2 |  |  | 1,785.0 |  |  | 1,358.8 |  |
| Europe, Middle East and Africa (“EMEA”) | 2,072.9 |  |  | 1,691.8 |  |  | 1,275.9 |  |
| Asia Pacific (“APAC”) | 1,056.7 |  |  | 940.6 |  |  | 707.5 |  |
| Total revenue | $ | 5,304.8 |  |  | $ | 4,417.4 |  |  | $ | 3,342.2 |  |

[0001262039-24-000014:notes:254]
| Property and Equipment—net | December 31,2023 |  | December 31,2022 |
| Americas: |  |  |  |
| United States | $ | 701.6 |  |  | $ | 638.1 |  |
| Canada | 212.8 |  |  | 204.4 |  |
| Latin America | 2.3 |  |  | 1.1 |  |
| Total Americas | 916.7 |  |  | 843.6 |  |
| EMEA | 65.5 |  |  | 35.9 |  |
| APAC | 62.2 |  |  | 19.0 |  |
| Total property and equipment—net | $ | 1,044.4 |  |  | $ | 898.5 |  |

[0001262039-24-000014:notes:255]
The following distributors accounted for 10% or more of our revenue:

[0001262039-24-000014:notes:256]
|  | Year Ended December 31, |
|  | 2023 |  | 2022 |  | 2021 |
| Distributor A | 28 | % |  | 29 | % |  | 31 | % |
| Distributor B | 15 | % |  | 14 | % |  | 12 | % |
| Distributor C | 13 | % |  | 14 | % |  | * |

[0001262039-24-000014:notes:257]
* Represents less than 10%

[0001262039-24-000014:notes:258]
The following distributors accounted for 10% or more of net accounts receivable:

[0001262039-24-000014:notes:259]
|  | 2023 |  | 2022 |
| Distributor A | 33 | % |  | 32 | % |
| Distributor B | 14 | % |  | 12 | % |
| Distributor C | 10 | % |  | 13 | % |


## us-gaap:SubsequentEventsTextBlock

[0001262039-24-000014:notes:260]
SUBSEQUENT EVENTS
Real Property Purchases

[0001262039-24-000014:notes:261]
In January 2024, we purchased real property in Santa Clara, CA, and Union City, CA, totaling approximately 480,000 square feet and 54,300 square feet, respectively, for $192.0 million and $14.8 million in cash, respectively.

[0001262039-24-000014:notes:262]
Share Repurchase Program
In January 2024, our board of directors approved a $500.0 million increase in the authorized stock repurchase amount under the Repurchase Program, bringing the aggregate amount authorized to be repurchased to $7.25 billion of our outstanding common stock. In February 2024, our board of directors approved an extension of the Repurchase Program to February 28, 2025. As of February 23, 2024, approximately $1.03 billion remained available for future share repurchases.


## ecd:MtrlTermsOfTrdArrTextBlock

[0001262039-24-000014:notes:263]
Rule 10b5-1 Trading Plans

[0001262039-24-000014:notes:264]
On November 13, 2023, Patrice Perche, our Chief Revenue Officer and Executive Vice President of Support, entered into a pre-arranged written stock sale plan in accordance with Rule 10b5-1 (the “Perche Plan”) under the Exchange Act for the sale of shares of our common stock. The Perche Plan was entered into during an open trading window in accordance with our insider trading policy and is intended to satisfy the affirmative defense of Rule 10b5-1(c) under the Exchange Act. The Perche Plan provides for the potential sale by Patrice Perche of up to (a) 141,981 shares of our common stock, including upon the vesting and settlement of RSUs and PSUs for shares of our common stock, and (b) the net shares (which are not yet determinable) after shares are withheld to satisfy tax obligations upon such vesting and settlement, in each case, at the market price, all between March 4, 2024 and June 1, 2025.

[0001262039-24-000014:notes:265]
On December 6, 2023, Judith Sim, one of directors, entered into a pre-arranged written stock sale plan in accordance with Rule 10b5-1 (the “Sim Plan”) under the Exchange Act for the sale of shares of our common stock. The Sim Plan was entered into during an open trading window in accordance with our insider trading policy and is intended to satisfy the affirmative defense of Rule 10b5-1(c) under the Exchange Act. The Sim Plan provides for the potential sale by Judith Sim of up to 20,637 shares of our common stock between March 6, 2024 and March 8, 2025.

[0001262039-24-000014:notes:266]
Each of the Perche Plan and the Sim Plan (together, the “10b5-1 Plans”) includes a representation from Patrice Perche and Judith Sim (as applicable) to the broker administering the plan that none of them were in possession of any material nonpublic information regarding us or the securities subject to the 10b5-1 Plans at the time the 10b5-1 Plans were entered into. A similar representation was made to us in connection with the adoption of the 10b5-1 Plans under our insider trading policy. Those representations for each 10b5-1 Plan were made as of the respective date of adoption of the applicable 10b5-1 Plan, and speak only as of that date. In making those representations, there is no assurance with respect to any material nonpublic information of which Patrice Perche and Judith Sim were unaware, or with respect to any material nonpublic information acquired by Patrice Perche and Judith Sim or us after the date of each such representation.

[0001262039-24-000014:notes:267]
Once executed, transactions under the Sim Plan will be disclosed publicly through Form 4 and/or Form 144 filings with the SEC in accordance with applicable securities laws, rules and regulations. Except as may be required by law, we do not undertake any obligation to update or report any modification, termination, or other activity under current or future Rule 10b5-1 plans that may be adopted by Patrice Perche or Judith Sim or our other officers or directors, or their affiliated entities.
