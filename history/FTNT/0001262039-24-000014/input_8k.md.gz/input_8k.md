# FTNT 8-K — 0001262039-24-000006 filed 2024-02-06

## item codes, every 8-K on or before 2024-02-26

- 2024-02-23 0001262039-24-000011 — 5.02, 9.01
- 2024-02-06 0001262039-24-000006 — 2.02, 9.01
- 2024-01-18 0001262039-24-000003 — 5.02
- 2023-12-01 0001262039-23-000041 — 5.02
- 2023-11-02 0001262039-23-000035 — 2.02, 9.01
- 2023-08-03 0001262039-23-000027 — 2.02, 9.01
- 2023-06-23 0001262039-23-000024 — 5.03, 5.07, 9.01
- 2023-05-04 0001262039-23-000013 — 2.02, 9.01
- 2023-02-08 0001262039-23-000006 — 5.03, 9.01
- 2023-02-07 0001262039-23-000003 — 2.02, 9.01
- 2022-11-02 0001262039-22-000035 — 2.02, 9.01
- 2022-08-03 0001262039-22-000026 — 2.02, 9.01
- 2022-06-22 0001262039-22-000023 — 5.03, 9.01
- 2022-06-21 0001262039-22-000021 — 5.07
- 2022-05-04 0001262039-22-000015 — 2.02, 9.01
- 2022-05-02 0001262039-22-000012 — 5.02
- 2022-04-22 0001262039-22-000010 — 8.01
- 2022-02-03 0001262039-22-000005 — 2.02, 9.01
- 2022-01-26 0001262039-22-000002 — 5.02, 9.01 — amendment, the index does not say of what
- 2021-11-04 0001262039-21-000027 — 2.02, 9.01
- 2021-10-06 0001262039-21-000024 — 5.02, 9.01
- 2021-07-29 0001262039-21-000019 — 2.02, 9.01
- 2021-06-23 0001262039-21-000016 — 5.07
- 2021-04-30 0001104659-21-059008 — 5.03 — amendment, the index does not say of what
- 2021-04-29 0001262039-21-000011 — 2.02, 9.01
- 2021-04-28 0001104659-21-056360 — 5.02, 5.03, 9.01
- 2021-03-05 0001193125-21-071498 — 1.01, 9.01
- 2021-02-25 0001193125-21-057281 — 1.01, 9.01
- 2021-02-04 0001262039-21-000005 — 2.02, 9.01
- 2020-12-08 0001262039-20-000070 — 8.01
- 2020-10-29 0001262039-20-000063 — 2.02, 9.01
- 2020-10-20 0001262039-20-000060 — 5.02 — amendment, the index does not say of what
- 2020-08-26 0001262039-20-000056 — 5.02, 9.01
- 2020-08-06 0001262039-20-000051 — 2.02, 9.01
- 2020-07-21 0001262039-20-000044 — 5.03, 8.01, 9.01
- 2020-06-24 0001262039-20-000038 — 5.07
- 2020-05-06 0001262039-20-000029 — 2.02, 9.01
- 2020-04-23 0001262039-20-000025 — 5.03, 9.01
- 2020-04-23 0001262039-20-000024 — 5.02 — amendment of 0001262039-20-000025
- 2020-02-28 0001262039-20-000015 — 5.02, 9.01
- 2020-02-06 0001262039-20-000004 — 2.02, 9.01
- 2019-12-12 0001262039-19-000038 — 8.01
- 2019-10-31 0001262039-19-000032 — 2.02, 9.01
- 2019-10-28 0001262039-19-000027 — 8.01
- 2019-10-23 0001262039-19-000025 — 5.02, 9.01
- 2019-08-01 0001262039-19-000021 — 2.02, 9.01
- 2019-06-26 0001262039-19-000018 — 5.07
- 2019-05-02 0001262039-19-000010 — 2.02, 9.01
- 2019-02-06 0001262039-19-000002 — 2.02, 9.01
- 2018-11-01 0001262039-18-000037 — 2.02, 9.01
- 2018-10-23 0001262039-18-000035 — 8.01
- 2018-08-01 0001262039-18-000025 — 2.02, 9.01
- 2018-06-28 0001262039-18-000023 — 5.03, 5.07, 9.01
- 2018-06-04 0001262039-18-000021 — 8.01
- 2018-05-03 0001262039-18-000017 — 2.02, 5.02, 9.01
- 2018-02-05 0001262039-18-000004 — 2.02, 5.02, 9.01
- 2017-10-26 0001262039-17-000031 — 2.02, 9.01
- 2017-10-19 0001262039-17-000029 — 5.02 — amendment, the index does not say of what
- 2017-07-26 0001262039-17-000025 — 2.02, 9.01
- 2017-06-27 0001262039-17-000023 — 5.07
- 2017-05-31 0001262039-17-000021 — 5.02 — amendment of 0001262039-17-000019
- 2017-05-30 0001262039-17-000019 — 5.02, 9.01
- 2017-04-27 0001262039-17-000013 — 2.02, 9.01
- 2017-02-02 0001262039-17-000003 — 2.02, 9.01
- 2016-10-27 0001262039-16-000085 — 2.02, 9.01
- 2016-10-11 0001262039-16-000082 — 2.02, 9.01
- 2016-07-28 0001262039-16-000076 — 2.02, 9.01
- 2016-07-22 0001262039-16-000073 — 8.01, 9.01
- 2016-06-20 0001262039-16-000068 — 5.07
- 2016-06-07 0001193125-16-614788 — 8.01
- 2016-04-26 0001262039-16-000061 — 2.02, 9.01
- 2016-01-28 0001262039-16-000051 — 2.02, 9.01
- 2015-10-27 0001262039-15-000045 — 2.02
- 2015-10-22 0001262039-15-000042 — 5.02 — amendment, the index does not say of what
- 2015-10-22 0001262039-15-000041 — 5.02 — amendment, the index does not say of what
- 2015-10-22 0001262039-15-000039 — 2.02, 9.01
- 2015-09-28 0001262039-15-000034 — 5.02, 9.01
- 2015-09-22 0001262039-15-000031 — 9.01 — amendment of 0001193125-15-248065
- 2015-08-28 0001262039-15-000027 — 3.01, 5.02
- 2015-07-23 0001262039-15-000021 — 5.02
- 2015-07-22 0001262039-15-000019 — 2.02, 9.01
- 2015-07-08 0001193125-15-248065 — 2.01, 8.01, 9.01
- 2015-06-22 0001193125-15-229099 — 5.07
- 2015-06-19 0001193125-15-228428 — 5.02, 9.01
- 2015-04-20 0001262039-15-000014 — 2.02, 9.01
- 2015-01-28 0001262039-15-000005 — 2.02, 9.01
- 2014-10-22 0001262039-14-000036 — 2.02, 9.01
- 2014-07-23 0001262039-14-000030 — 2.02, 9.01
- 2014-06-24 0001262039-14-000027 — 5.07
- 2014-04-23 0001262039-14-000021 — 2.02, 9.01
- 2014-04-21 0001262039-14-000018 — 5.03, 9.01
- 2014-01-29 0001262039-14-000004 — 2.02, 9.01
- 2013-12-20 0001262039-13-000061 — 5.02, 9.01
- 2013-11-27 0001262039-13-000057 — 5.02, 7.01, 9.01
- 2013-11-12 0001445305-13-002993 — 5.02
- 2013-10-23 0001262039-13-000051 — 2.02, 9.01
- 2013-07-30 0001262039-13-000039 — 2.02, 9.01
- 2013-06-25 0001262039-13-000030 — 5.07
- 2013-04-30 0001262039-13-000023 — 2.02, 9.01
- 2013-04-19 0001262039-13-000020 — 5.02, 9.01
- 2013-04-19 0001262039-13-000018 — 5.02 — amendment of 0001262039-13-000020
- 2013-04-10 0001262039-13-000016 — 2.02, 9.01
- 2013-03-26 0001262039-13-000013 — 5.02
- 2013-01-30 0001262039-13-000005 — 2.02, 9.01
- 2013-01-24 0001262039-13-000002 — 5.02, 9.01
- 2012-10-16 0001262039-12-000048 — 2.02, 9.01
- 2012-10-01 0001262039-12-000045 — 5.02
- 2012-09-26 0001262039-12-000043 — 5.01
- 2012-07-25 0001262039-12-000038 — 2.02, 9.01
- 2012-07-19 0001262039-12-000034 — 5.02
- 2012-06-20 0001193125-12-275869 — 5.07
- 2012-04-27 0001262039-12-000029 — 5.02
- 2012-04-24 0001262039-12-000025 — 2.02, 9.01
- 2012-01-31 0001262039-12-000006 — 2.02, 9.01
- 2012-01-25 0001262039-12-000003 — 5.03
- 2011-10-24 0001262039-11-000036 — 2.02
- 2011-07-19 0001262039-11-000014 — 2.02, 9.01
- 2011-06-27 0001193125-11-174474 — 5.02, 5.07, 9.01
- 2011-04-27 0001193125-11-111938 — 2.02, 9.01
- 2011-01-25 0001193125-11-013914 — 2.02, 9.01
- 2010-10-21 0001193125-10-233676 — 2.02, 9.01
- 2010-09-02 0001193125-10-203099 — 8.01
- 2010-07-22 0001193125-10-163844 — 2.02, 9.01
- 2010-06-24 0001193125-10-146082 — 5.07
- 2010-04-28 0001193125-10-096698 — 2.02, 9.01
- 2010-02-09 0001193125-10-024614 — 8.01
- 2010-01-27 0001193125-10-014292 — 2.02, 9.01
- 2010-01-26 0001193125-10-013031 — 5.02, 9.01

## late-filing notifications on or before 2024-02-26

- none on or before 2024-02-26

## item 2.02 — earnings release, exhibit 99.1

[0001262039-24-000006:8k_2_02:1]
EX-99.1
2
ftntq4-2023ex991.htm
PRESS RELEASE

[0001262039-24-000006:8k_2_02:2]
Document

[0001262039-24-000006:8k_2_02:3]
Press Release

[0001262039-24-000006:8k_2_02:4]
Fortinet Reports Fourth Quarter and Full Year 2023 Financial Results

[0001262039-24-000006:8k_2_02:5]
Fourth Quarter 2023 Highlights

[0001262039-24-000006:8k_2_02:6]
•Total revenue of $1.42 billion, up 10.3% year over year

[0001262039-24-000006:8k_2_02:7]
•Billings of $1.86 billion, up 8.5% year over year1

[0001262039-24-000006:8k_2_02:8]
•GAAP operating income of $385 million

[0001262039-24-000006:8k_2_02:9]
•Non-GAAP operating income of $454 million1

[0001262039-24-000006:8k_2_02:10]
•GAAP operating margin of 27.2%

[0001262039-24-000006:8k_2_02:11]
•Non-GAAP operating margin of 32.0%1

[0001262039-24-000006:8k_2_02:12]
•Cash paid for share repurchases of $896 million

[0001262039-24-000006:8k_2_02:13]
Full Year 2023 Highlights

[0001262039-24-000006:8k_2_02:14]
•Total revenue of $5.30 billion, up 20% year over year

[0001262039-24-000006:8k_2_02:15]
•Service revenue of $3.38 billion, up 28% year over year

[0001262039-24-000006:8k_2_02:16]
•Billings of $6.40 billion, up 14% year over year1

[0001262039-24-000006:8k_2_02:17]
•Deferred revenue of $5.74 billion, up 24% year over year

[0001262039-24-000006:8k_2_02:18]
•GAAP operating income of $1.24 billion, up 28% year over year

[0001262039-24-000006:8k_2_02:19]
•Non-GAAP operating income of $1.51 billion, up 25% year over year1

[0001262039-24-000006:8k_2_02:20]
•GAAP operating margin of 23.4%

[0001262039-24-000006:8k_2_02:21]
•Non-GAAP operating margin of 28.4%1

[0001262039-24-000006:8k_2_02:22]
•GAAP diluted net income per share attributable to Fortinet, Inc. of $1.46, up 38% year over year

[0001262039-24-000006:8k_2_02:23]
•Non-GAAP diluted net income per share attributable to Fortinet, Inc. of $1.63, up 37% year over year1

[0001262039-24-000006:8k_2_02:24]
•Cash flow from operations of $1.94 billion

[0001262039-24-000006:8k_2_02:25]
•Free cash flow of $1.73 billion1

[0001262039-24-000006:8k_2_02:26]
•Cash paid for share repurchases of $1.50 billion

[0001262039-24-000006:8k_2_02:27]
SUNNYVALE, Calif. - February 6, 2024 - Fortinet® (Nasdaq: FTNT), a global cybersecurity leader driving the convergence of networking and security, today announced financial results for the fourth quarter of 2023 and full year ended December 31, 2023.

[0001262039-24-000006:8k_2_02:28]
“In the fourth quarter of 2023, Security Operations billings grew 44% year over year and SASE billings increased 19% year over year, driven by our successful sales strategy shift and the improved execution of our sales teams,” said Ken Xie, Founder, Chairman and Chief Executive Officer of Fortinet. “Our platform strategy is resonating with enterprises worldwide as we are a leader in Secure Networking and are the #1 firewall vendor for units shipped with FortiGates accounting for over half of the global deployment. Fortinet is well-positioned to consolidate the security capabilities of our over half a million customers onto our integrated FortiOS operating system, which encompasses over 30 networking and security functions spanning on-premises and cloud environments.”

[0001262039-24-000006:8k_2_02:29]
Financial Highlights for the Fourth Quarter of 2023

[0001262039-24-000006:8k_2_02:30]
•Revenue: Total revenue was $1.42 billion for the fourth quarter of 2023, an increase of 10.3% compared to $1.28 billion for the same quarter of 2022.

[0001262039-24-000006:8k_2_02:31]
•Service Revenue: Service revenue was $927.0 million for the fourth quarter of 2023, an increase of 24.8% compared to $742.9 million for the same quarter of 2022.

[0001262039-24-000006:8k_2_02:32]
•Product Revenue: Product revenue was $488.1 million for the fourth quarter of 2023, a decrease of 9.6% compared to $540.1 million for the same quarter of 2022.

[0001262039-24-000006:8k_2_02:33]
•Billings1: Total billings were $1.86 billion for the fourth quarter of 2023, an increase of 8.5% compared to $1.72 billion for the same quarter of 2022.

[0001262039-24-000006:8k_2_02:34]
•GAAP Operating Income and Margin: GAAP operating income was $385.4 million for the fourth quarter of 2023, representing a GAAP operating margin of 27.2%. GAAP operating income was $357.8 million for the same quarter of 2022, representing a GAAP operating margin of 27.9%.

[0001262039-24-000006:8k_2_02:35]
•Non-GAAP Operating Income and Margin1: Non-GAAP operating income was $453.5 million for the fourth quarter of 2023, representing a non-GAAP operating margin of 32.0%. Non-GAAP operating income was $417.6 million for the same quarter of 2022, representing a non-GAAP operating margin of 32.5%.

[0001262039-24-000006:8k_2_02:36]
•GAAP Net Income and Diluted Net Income Per Share Attributable to Fortinet, Inc.: GAAP net income was $310.9 million for the fourth quarter of 2023, compared to GAAP net income of $313.8 million for the same quarter of 2022. GAAP diluted net income per share was $0.40 for the fourth quarter of 2023, based on 772.3 million diluted weighted-average shares outstanding, compared to GAAP diluted net income per share of $0.40 for the same quarter of 2022, based on 791.8 million diluted weighted-average shares outstanding.

[0001262039-24-000006:8k_2_02:37]
•Non-GAAP Net Income and Diluted Net Income Per Share Attributable to Fortinet, Inc.1: Non-GAAP net income was $392.0 million for the fourth quarter of 2023, compared to non-GAAP net income of $349.7 million for the same quarter of 2022. Non-GAAP diluted net income per share was $0.51 for the fourth quarter of 2023, based on 772.3 million diluted weighted-average shares outstanding, compared to $0.44 for the same quarter of 2022, based on 791.8 million diluted weighted-average shares outstanding.

[0001262039-24-000006:8k_2_02:38]
•Cash Flow: Cash flow from operations was $191.7 million for the fourth quarter of 2023, compared to $528.1 million for the same quarter of 2022.

[0001262039-24-000006:8k_2_02:39]
•Free Cash Flow1: Free cash flow was $164.8 million for the fourth quarter of 2023, compared to $497.2 million for the same quarter of 2022.

[0001262039-24-000006:8k_2_02:40]
•Share Repurchase Program: During the three months ended December 31, 2023, Fortinet repurchased 16.8 million shares of its common stock at an average price of $53.29 per share and for an aggregate purchase price of $895.3 million. In January 2024, Fortinet’s board of directors authorized a $500.0 million increase in the authorized share repurchase amount under our share repurchase program. As of February 6, 2024,

[0001262039-24-000006:8k_2_02:41]
approximately $1.03 billion remained available for future share repurchases under our share repurchase program.

[0001262039-24-000006:8k_2_02:42]
Financial Highlights for the Full Year 2023

[0001262039-24-000006:8k_2_02:43]
•Revenue: Total revenue was $5.30 billion for 2023, an increase of 20.1% compared to $4.42 billion in 2022.

[0001262039-24-000006:8k_2_02:44]
•Service Revenue: Service revenue was $3.38 billion for 2023, an increase of 28.1% compared to $2.64 billion in 2022.

[0001262039-24-000006:8k_2_02:45]
•Product Revenue: Product revenue was $1.93 billion for 2023, an increase of 8.2% compared to $1.78 billion in 2022.

[0001262039-24-000006:8k_2_02:46]
•Billings1: Total billings were $6.40 billion for 2023, an increase of 14.4% compared to $5.59 billion in 2022.

[0001262039-24-000006:8k_2_02:47]
•Deferred Revenue: Total deferred revenue was $5.74 billion as of December 31, 2023, an increase of 23.6% compared to $4.64 billion as of December 31, 2022.

[0001262039-24-000006:8k_2_02:48]
•GAAP Operating Income and Margin: GAAP operating income was $1.24 billion for 2023, representing a GAAP operating margin of 23.4%. GAAP operating income was $969.6 million for 2022, representing a GAAP operating margin of 21.9%.

[0001262039-24-000006:8k_2_02:49]
•Non-GAAP Operating Income and Margin1: Non-GAAP operating income was $1.51 billion for 2023, representing a non-GAAP operating margin of 28.4%. Non-GAAP operating income was $1.21 billion for 2022, representing a non-GAAP operating margin of 27.3%.

[0001262039-24-000006:8k_2_02:50]
•GAAP Net Income and Diluted Net Income Per Share Attributable to Fortinet, Inc.: GAAP net income was $1.15 billion for 2023, compared to GAAP net income of $857.3 million for 2022. GAAP diluted net income per share was $1.46 for 2023, based on 788.2 million diluted weighted-average shares outstanding, compared to GAAP diluted net income per share of $1.06 for 2022, based on 805.3 million diluted weighted-average shares outstanding.

[0001262039-24-000006:8k_2_02:51]
•Non-GAAP Net Income and Diluted Net Income Per Share Attributable to Fortinet, Inc.1: Non-GAAP net income was $1.29 billion for 2023, compared to non-GAAP net income of $961.6 million for 2022. Non-GAAP diluted net income per share was $1.63 for 2023, based on 788.2 million diluted weighted-average shares outstanding, compared to $1.19 for 2022, based on 805.3 million diluted weighted-average shares outstanding.

[0001262039-24-000006:8k_2_02:52]
•Cash Flow: Cash flow from operations was $1.94 billion in 2023 compared to $1.73 billion in 2022.

[0001262039-24-000006:8k_2_02:53]
•Free Cash Flow1: Free cash flow was $1.73 billion in 2023, compared to $1.45 billion in 2022.

[0001262039-24-000006:8k_2_02:54]
•Share Repurchase Program: During the years ended December 31, 2023 and 2022, Fortinet repurchased 27.2 million and 36.0 million shares of its common stock at an average price of $55.25 and $55.37 per share, respectively, and for an aggregate purchase price of $1.50 billion and $1.99 billion, respectively. Since the beginning of

[0001262039-24-000006:8k_2_02:55]
2020, Fortinet repurchased 134.6 million shares of its common stock at an average price of $39.47 per share for an aggregate purchase price of $5.31 billion.

[0001262039-24-000006:8k_2_02:56]
Guidance

[0001262039-24-000006:8k_2_02:57]
For the first quarter of 2024, Fortinet currently expects:

[0001262039-24-000006:8k_2_02:58]
•Revenue in the range of $1.300 billion to $1.360 billion

[0001262039-24-000006:8k_2_02:59]
•Billings in the range of $1.390 billion to $1.450 billion

[0001262039-24-000006:8k_2_02:60]
•Non-GAAP gross margin in the range of 76.5% to 77.5%

[0001262039-24-000006:8k_2_02:61]
•Non-GAAP operating margin in the range of 25.5% to 26.5%

[0001262039-24-000006:8k_2_02:62]
•Diluted non-GAAP net income per share attributable to Fortinet, Inc. in the range of $0.37 to $0.39, assuming a non-GAAP effective tax rate of 17%. This assumes a diluted share count of 775 million to 785 million.

[0001262039-24-000006:8k_2_02:63]
For the fiscal year 2024, Fortinet currently expects:

[0001262039-24-000006:8k_2_02:64]
•Revenue in the range of $5.715 billion to $5.815 billion

[0001262039-24-000006:8k_2_02:65]
•Service revenue in the range of $3.920 billion to $3.970 billion

[0001262039-24-000006:8k_2_02:66]
•Billings in the range of $6.400 billion to $6.600 billion

[0001262039-24-000006:8k_2_02:67]
•Non-GAAP gross margin in the range of 76.0% to 78.0%

[0001262039-24-000006:8k_2_02:68]
•Non-GAAP operating margin in the range of 25.5% to 27.5%

[0001262039-24-000006:8k_2_02:69]
•Diluted non-GAAP net income per share attributable to Fortinet, Inc. in the range of $1.65 to $1.70, assuming a non-GAAP effective tax rate of 17%. This assumes a diluted share count of 785 million to 795 million.

[0001262039-24-000006:8k_2_02:70]
Our guidance with respect to non-GAAP financial measures excludes stock-based compensation, amortization of acquired intangible assets and gain on intellectual property matters. We have not reconciled our guidance with respect to non-GAAP financial measures to the corresponding GAAP measures because certain items that impact these measures are uncertain or out of our control, or cannot be reasonably predicted. Accordingly, a reconciliation of these non-GAAP financial measures to the corresponding GAAP measures is not available without unreasonable effort.

[0001262039-24-000006:8k_2_02:71]
1 A reconciliation of GAAP to non-GAAP measures has been provided in the financial statement tables included in this press release. An explanation of these measures is also included below under the heading “Non-GAAP Financial Measures”.

[0001262039-24-000006:8k_2_02:72]
Conference Call Details

[0001262039-24-000006:8k_2_02:73]
Fortinet will host a conference call today at 1:30 p.m. Pacific Time (4:30 p.m. Eastern Time) to discuss the earnings results. A live webcast of the conference call and supplemental slides will be accessible from the Investor Relations page of Fortinet’s website at https://investor.fortinet.com and a replay will be archived and accessible at https://investor.fortinet.com/events-and-presentations.

[0001262039-24-000006:8k_2_02:74]
First Quarter 2024 Conference Participation Schedule:

[0001262039-24-000006:8k_2_02:75]
•Morgan Stanley Technology, Media & Telecom Conference

[0001262039-24-000006:8k_2_02:76]
March 5, 2024

[0001262039-24-000006:8k_2_02:77]
Members of Fortinet’s management team are expected to present at this conference and discuss the latest company strategies and initiatives. Fortinet’s conference presentations are expected to be available via webcast on the company’s web site. To access the most updated information, pre-register and listen to the webcast of each event, please visit the Investor Presentation & Events page of Fortinet’s website at https://investor.fortinet.com/events-and-presentations. The schedule is subject to change.

[0001262039-24-000006:8k_2_02:78]
About Fortinet (www.fortinet.com)

[0001262039-24-000006:8k_2_02:79]
Fortinet (Nasdaq: FTNT) is a driving force in the evolution of cybersecurity and the convergence of networking and security. Our mission is to secure people, devices and data everywhere, and today we deliver cybersecurity everywhere our customers need it with the largest integrated portfolio of over 50 enterprise-grade products. Over half a million customers trust Fortinet’s solutions, which are among the most deployed, most patented and most validated in the industry. The Fortinet Training Institute, one of the largest and broadest training programs in the industry, is dedicated to making cybersecurity training and new career opportunities available to everyone. FortiGuard Labs, Fortinet’s elite threat intelligence and research organization, develops and utilizes leading-edge machine learning and AI technologies to provide customers with timely and consistently top-rated protection and actionable threat intelligence. Learn more at https://www.fortinet.com, the Fortinet Blog or FortiGuard Labs.

[0001262039-24-000006:8k_2_02:80]
#          #          #

[0001262039-24-000006:8k_2_02:81]
Copyright © 2024 Fortinet, Inc. All rights reserved. The symbols ® and ™ denote respectively federally registered trademarks and common law trademarks of Fortinet, Inc., its subsidiaries and affiliates. Fortinet’s trademarks include, but are not limited to, the following: Fortinet, the Fortinet logo, FortiGate, FortiOS, FortiGuard, FortiCare, FortiAnalyzer, FortiManager, FortiASIC, FortiClient, FortiCloud, FortiMail, FortiSandbox, FortiADC, FortiAIOps, FortiAntenna, FortiAP, FortiAPCam, FortiAuthenticator, FortiCache, FortiCam, FortiCamera, FortiCarrier, FortiCASB, FortiCentral, FortiCNP, FortiConnect, FortiController, FortiConverter, FortiCWP, FortiDAST, FortiDB, FortiDDoS, FortiDeceptor, FortiDeploy, FortiDevSec, FortiEDR, FortiExplorer, FortiExtender, FortiFirewall, FortiFlex, FortiFone, FortiGSLB, FortiGuest, FortiHypervisor, FortiInsight, FortiIsolator, FortiLAN, FortiLink, FortiMonitor, FortiNAC, FortiNDR, FortiPAM, FortiPenTest, FortiPhish, FortiPoint, FortiPolicy, FortiPortal, FortiPresence, FortiProxy, FortiRecon, FortiRecorder, FortiSASE, FortiSDNConnector, FortiSIEM, FortiSMS, FortiSOAR, FortiSRA, FortiStack, FortiSwitch, FortiTester, FortiToken, FortiTrust, FortiVoice, FortiWAN, FortiWeb, FortiWiFi, FortiWLC, FortiWLM and FortiXDR. Other trademarks belong to their respective owners. Fortinet has not independently verified statements or certifications herein attributed to third parties and Fortinet does not independently endorse such statements. Notwithstanding anything to the contrary herein, nothing herein constitutes a warranty, guarantee, contract, binding specification or other binding commitment by Fortinet or any indication of intent related to a binding commitment, and performance and other specification information herein may be unique to certain environments.

[0001262039-24-000006:8k_2_02:82]
FTNT-F

[0001262039-24-000006:8k_2_02:83]
Forward-Looking Statements

[0001262039-24-000006:8k_2_02:84]
This press release contains forward-looking statements that involve risks and uncertainties. These forward-looking statements include statements regarding any indications related to future growth and market share gains, our strategy going forward, and guidance and expectations around future financial results, including guidance and expectations for the first quarter of 2024 and full year 2024, and any statements regarding our market opportunity and market size, and business momentum. Although we attempt to be accurate in making forward-looking statements,

[0001262039-24-000006:8k_2_02:85]
Non-GAAP Financial Measures

[0001262039-24-000006:8k_2_02:86]
We have provided in this release financial information that has not been prepared in accordance with U.S. Generally Accepted Accounting Principles (GAAP). These non-GAAP financial and liquidity measures are not based on any standardized methodology prescribed by GAAP and are not necessarily comparable to similar measures presented by other companies. We use these non-GAAP financial measures internally in analyzing our financial results and believe they are useful to investors, as a supplement to GAAP measures, in evaluating our ongoing

[0001262039-24-000006:8k_2_02:87]
operational performance. We believe that the use of these non-GAAP financial measures provides an additional tool for investors to use in evaluating ongoing operating results and trends and in comparing our financial results with peer companies, many of which present similar non-GAAP financial measures to investors.

[0001262039-24-000006:8k_2_02:88]
Non-GAAP financial measures should not be considered in isolation from, or as a substitute for, financial information prepared in accordance with GAAP. Investors are encouraged to review the reconciliation of these non-GAAP financial measures to their most directly comparable GAAP financial measures provided in the financial statement tables below.

[0001262039-24-000006:8k_2_02:89]
Billings (non-GAAP). We define billings as revenue recognized in accordance with GAAP plus the change in deferred revenue from the beginning to the end of the period less any deferred revenue balances acquired from business combination(s) during the period. We consider billings to be a useful metric for management and investors because billings drive current and future revenue, which is an important indicator of the health and viability of our business. There are a number of limitations related to the use of billings instead of GAAP revenue. First, billings include amounts that have not yet been recognized as revenue and are impacted by the term of security and support agreements. Second, we may calculate billings in a manner that is different from peer companies that report similar financial measures. Management accounts for these limitations by providing specific information regarding GAAP revenue and evaluating billings together with GAAP revenue.

[0001262039-24-000006:8k_2_02:90]
Free cash flow (non-GAAP). We define free cash flow as net cash provided by operating activities minus purchases of property and equipment and excluding any significant non-recurring items. We believe free cash flow to be a liquidity measure that provides useful information to management and investors about the amount of cash generated by the business that, after capital expenditures, can be used for strategic opportunities, including repurchasing outstanding common stock, investing in our business, making strategic acquisitions and strengthening the balance sheet. A limitation of using free cash flow rather than the GAAP measures of cash provided by or used in operating activities, investing activities, and financing activities is that free cash flow does not represent the total increase or decrease in the cash and cash equivalents balance for the period because it excludes cash flows from significant non-recurring items, investing activities other than capital expenditures and cash flows from financing activities. Management accounts for this limitation by providing information about our capital expenditures and other investing and financing activities on the face of the cash flow statement and under the caption “Management’s Discussion and Analysis of Financial Condition and Results of Operations—Liquidity and Capital Resources” in our most recent Quarterly Report on Form 10-Q and Annual Report on Form 10-K and by presenting cash flows from investing and financing activities in our reconciliation of free cash flow. In addition, it is important to note that other companies, including companies in our industry, may not use free cash flow, may calculate free cash flow in a different manner than we do or may use other financial measures to evaluate their performance, all of which could reduce the usefulness of free cash flow as a comparative measure.

[0001262039-24-000006:8k_2_02:91]
Non-GAAP operating income and operating margin. We define non-GAAP operating income as operating income plus stock-based compensation, amortization of acquired intangible assets, less gain on intellectual property matter and, when applicable, other significant non-recurring items in a given quarter. Non-GAAP operating margin is defined as non-GAAP operating income divided by GAAP revenue. We consider these non-GAAP financial measures to be useful metrics for management and investors because they exclude the items noted above so that our management and investors can compare our recurring core business operating results over multiple periods. There are a number of limitations related to the use of non-GAAP operating income instead of operating income calculated in accordance with GAAP. First, non-GAAP operating income excludes the items noted above. Second, the components of the costs that we exclude from our calculation of non-GAAP operating income may differ from the components

[0001262039-24-000006:8k_2_02:92]
that peer companies exclude when they report their non-GAAP results of operations. Management accounts for these limitations by providing specific information regarding the GAAP amounts excluded from non-GAAP operating income and evaluating non-GAAP operating income together with operating income calculated in accordance with GAAP.

[0001262039-24-000006:8k_2_02:93]
Non-GAAP net income and diluted net income per share attributable to Fortinet, Inc. We define non-GAAP net income as net income plus the items noted above under non-GAAP operating income and operating margin. In addition, we adjust non-GAAP net income and diluted net income per share for a tax adjustment required for an effective tax rate on a non-GAAP basis and adjustments attributable to non-controlling interests, which differs from the GAAP effective tax rate. We define non-GAAP diluted net income per share as non-GAAP net income divided by the non-GAAP diluted weighted-average shares outstanding. We consider these non-GAAP financial measures to be useful metrics for management and investors for the same reasons that we use non-GAAP operating income and non-GAAP operating margin. However, in order to provide a more complete picture of our recurring core business operating results, we include in non-GAAP net income and non-GAAP diluted net income per share, the tax adjustment required resulting in an effective tax rate on a non-GAAP basis, which often differs from the GAAP tax rate. We believe the non-GAAP effective tax rates we use are reasonable estimates of normalized tax rates for our current and prior fiscal years under our global operating structure. The same limitations described above regarding our use of non-GAAP operating income and non-GAAP operating margin apply to our use of non-GAAP net income and non-GAAP diluted net income per share. We account for these limitations by providing specific information regarding the GAAP amounts excluded from non-GAAP net income and non-GAAP diluted net income per share and evaluating non-GAAP net income and non-GAAP diluted net income per share together with net income and diluted net income per share calculated in accordance with GAAP.

[0001262039-24-000006:8k_2_02:94]
FORTINET, INC.

[0001262039-24-000006:8k_2_02:95]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001262039-24-000006:8k_2_02:96]
(Unaudited, in millions)

[0001262039-24-000006:8k_2_02:97]
|  | December 31,2023 |  | December 31,2022 |
| ASSETS |  |  |  |
| CURRENT ASSETS: |  |  |  |
| Cash and cash equivalents | $ | 1,397.9 |  |  | $ | 1,682.9 |  |
| Short-term investments | 1,021.5 |  |  | 502.6 |  |
| Marketable equity securities | 21.0 |  |  | 25.5 |  |
| Accounts receivable—net | 1,402.0 |  |  | 1,261.7 |  |
| Inventory | 484.8 |  |  | 264.6 |  |
| Prepaid expenses and other current assets | 101.1 |  |  | 73.1 |  |
| Total current assets | 4,428.3 |  |  | 3,810.4 |  |
| LONG-TERM INVESTMENTS | — |  |  | 45.5 |  |
| PROPERTY AND EQUIPMENT—NET | 1,044.4 |  |  | 898.5 |  |
| DEFERRED CONTRACT COSTS | 605.6 |  |  | 518.2 |  |
| DEFERRED TAX ASSETS | 868.8 |  |  | 569.4 |  |
| GOODWILL AND OTHER INTANGIBLE ASSETS—NET | 161.8 |  |  | 184.0 |  |
| OTHER ASSETS | 150.0 |  |  | 202.0 |  |
| TOTAL ASSETS | $ | 7,258.9 |  |  | $ | 6,228.0 |  |
| LIABILITIES AND STOCKHOLDERS’ DEFICIT |  |  |  |
| CURRENT LIABILITIES: |  |  |  |
| Accounts payable | $ | 204.3 |  |  | $ | 243.4 |  |
| Accrued liabilities | 360.1 |  |  | 248.7 |  |
| Accrued payroll and compensation | 242.3 |  |  | 219.4 |  |
| Income taxes payable | 63.6 |  |  | 17.6 |  |
| Deferred revenue | 2,848.7 |  |  | 2,349.3 |  |
| Total current liabilities | 3,719.0 |  |  | 3,078.4 |  |
| DEFERRED REVENUE | 2,886.3 |  |  | 2,291.0 |  |
| INCOME TAX LIABILITIES | 61.9 |  |  | 67.8 |  |
| LONG-TERM DEBT | 992.3 |  |  | 990.4 |  |
| OTHER LIABILITIES | 62.8 |  |  | 82.0 |  |
| Total liabilities | 7,722.3 |  |  | 6,509.6 |  |
| COMMITMENTS AND CONTINGENCIES |  |  |  |
| STOCKHOLDERS’ DEFICIT: |  |  |  |
| Common stock | 0.8 |  |  | 0.8 |  |
| Additional paid-in capital | 1,416.4 |  |  | 1,284.2 |  |
| Accumulated other comprehensive loss | (18.9) |  |  | (20.2) |  |
| Accumulated deficit | (1,861.7) |  |  | (1,546.4) |  |
| Total stockholders’ deficit | (463.4) |  |  | (281.6) |  |
| TOTAL LIABILITIES AND STOCKHOLDERS’ DEFICIT | $ | 7,258.9 |  |  | $ | 6,228.0 |  |

[0001262039-24-000006:8k_2_02:98]
FORTINET, INC.

[0001262039-24-000006:8k_2_02:99]
CONDENSED CONSOLIDATED STATEMENTS OF INCOME

[0001262039-24-000006:8k_2_02:100]
(Unaudited, in millions, except per share amounts)

[0001262039-24-000006:8k_2_02:101]
|  | Three Months Ended |  | Year Ended |
|  | December 31,2023 |  | December 31,2022 |  | December 31,2023 |  | December 31,2022 |
| REVENUE: |  |  |  |  |  |  |  |
| Product | $ | 488.1 |  |  | $ | 540.1 |  |  | $ | 1,927.3 |  |  | $ | 1,780.5 |  |
| Service | 927.0 |  |  | 742.9 |  |  | 3,377.5 |  |  | 2,636.9 |  |
| Total revenue | 1,415.1 |  |  | 1,283.0 |  |  | 5,304.8 |  |  | 4,417.4 |  |
| COST OF REVENUE: |  |  |  |  |  |  |  |
| Product | 197.2 |  |  | 189.9 |  |  | 763.6 |  |  | 691.3 |  |
| Service | 118.7 |  |  | 107.4 |  |  | 473.6 |  |  | 393.6 |  |
| Total cost of revenue | 315.9 |  |  | 297.3 |  |  | 1,237.2 |  |  | 1,084.9 |  |
| GROSS PROFIT: |  |  |  |  |  |  |  |
| Product | 290.9 |  |  | 350.2 |  |  | 1,163.7 |  |  | 1,089.2 |  |
| Service | 808.3 |  |  | 635.5 |  |  | 2,903.9 |  |  | 2,243.3 |  |
| Total gross profit | 1,099.2 |  |  | 985.7 |  |  | 4,067.6 |  |  | 3,332.5 |  |
| OPERATING EXPENSES: |  |  |  |  |  |  |  |
| Research and development | 152.5 |  |  | 128.9 |  |  | 613.8 |  |  | 512.4 |  |
| Sales and marketing | 507.4 |  |  | 455.9 |  |  | 2,006.0 |  |  | 1,686.1 |  |
| General and administrative | 55.1 |  |  | 44.3 |  |  | 211.3 |  |  | 169.0 |  |
| Gain on intellectual property matter | (1.2) |  |  | (1.2) |  |  | (4.6) |  |  | (4.6) |  |
| Total operating expenses | 713.8 |  |  | 627.9 |  |  | 2,826.5 |  |  | 2,362.9 |  |
| OPERATING INCOME | 385.4 |  |  | 357.8 |  |  | 1,241.1 |  |  | 969.6 |  |
| INTEREST INCOME | 30.5 |  |  | 9.1 |  |  | 119.7 |  |  | 17.4 |  |
| INTEREST EXPENSE | (5.4) |  |  | (4.5) |  |  | (21.0) |  |  | (18.0) |  |
| OTHER INCOME (EXPENSE)—NET | 5.1 |  |  | 5.8 |  |  | (6.1) |  |  | (13.5) |  |
| INCOME BEFORE INCOME TAXES AND LOSS FROM EQUITY METHOD INVESTMENTS | 415.6 |  |  | 368.2 |  |  | 1,333.7 |  |  | 955.5 |  |
| PROVISION FOR INCOME TAXES | 95.2 |  |  | 9.2 |  |  | 143.8 |  |  | 30.8 |  |
| LOSS FROM EQUITY METHOD INVESTMENTS | (9.5) |  |  | (45.2) |  |  | (42.1) |  |  | (68.1) |  |
| NET INCOME INCLUDING NON-CONTROLLING INTERESTS | 310.9 |  |  | 313.8 |  |  | 1,147.8 |  |  | 856.6 |  |
| Less: NET LOSS ATTRIBUTABLE TO NON-CONTROLLING INTERESTS, NET OF TAX | — |  |  | — |  |  | — |  |  | (0.7) |  |
| NET INCOME ATTRIBUTABLE TO FORTINET, INC. | $ | 310.9 |  |  | $ | 313.8 |  |  | $ | 1,147.8 |  |  | $ | 857.3 |  |
| Net income per share attributable to Fortinet, Inc.: |  |  |  |  |  |  |  |
| Basic | $ | 0.41 |  |  | $ | 0.40 |  |  | $ | 1.47 |  |  | $ | 1.08 |  |
| Diluted | $ | 0.40 |  |  | $ | 0.40 |  |  | $ | 1.46 |  |  | $ | 1.06 |  |
| Weighted-average shares used to compute net income per share attributable to Fortinet, Inc.: |  |  |  |  |  |  |  |
| Basic | 764.9 |  |  | 780.9 |  |  | 778.6 |  |  | 791.4 |  |
| Diluted | 772.3 |  |  | 791.8 |  |  | 788.2 |  |  | 805.3 |  |

[0001262039-24-000006:8k_2_02:102]
FORTINET, INC.

[0001262039-24-000006:8k_2_02:103]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001262039-24-000006:8k_2_02:104]
(Unaudited, in millions)

[0001262039-24-000006:8k_2_02:105]
|  | Year Ended |
|  | December 31,2023 |  | December 31,2022 |
| CASH FLOWS FROM OPERATING ACTIVITIES: |  |  |  |
| Net income including non-controlling interests | $ | 1,147.8 |  |  | $ | 856.6 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |
| Stock-based compensation | 249.0 |  |  | 217.3 |  |
| Amortization of deferred contract costs | 266.3 |  |  | 223.3 |  |
| Depreciation and amortization | 113.4 |  |  | 104.3 |  |
| Amortization of investment premiums (discounts) | (27.7) |  |  | 4.4 |  |
| Loss from equity method investments | 42.1 |  |  | 68.1 |  |
| Other | 18.5 |  |  | 23.6 |  |
| Changes in operating assets and liabilities, net of impact of business combinations: |  |  |  |
| Accounts receivable—net | (146.4) |  |  | (456.7) |  |
| Inventory | (253.5) |  |  | (109.1) |  |
| Prepaid expenses and other current assets | (27.6) |  |  | (7.7) |  |
| Deferred contract costs | (353.5) |  |  | (318.2) |  |
| Deferred tax assets | (301.9) |  |  | (226.4) |  |
| Other assets | 17.7 |  |  | (35.3) |  |
| Accounts payable | (43.1) |  |  | 105.2 |  |
| Accrued liabilities | 97.1 |  |  | 55.4 |  |
| Accrued payroll and compensation | 23.4 |  |  | 25.0 |  |
| Income taxes payable | 40.3 |  |  | (0.2) |  |
| Other liabilities | (21.7) |  |  | 23.5 |  |
| Deferred revenue | 1,095.3 |  |  | 1,177.5 |  |
| Net cash provided by operating activities | 1,935.5 |  |  | 1,730.6 |  |
| CASH FLOWS FROM INVESTING ACTIVITIES: |  |  |  |
| Purchases of investments | (1,855.8) |  |  | (389.1) |  |
| Sales of investments | 4.0 |  |  | 3.0 |  |
| Maturities of investments | 1,414.8 |  |  | 1,462.0 |  |
| Purchases of property and equipment | (204.1) |  |  | (281.2) |  |
| Purchase of investment in privately held company | (8.5) |  |  | — |  |
| Payments made in connection with business combinations, net of cash acquired | — |  |  | (30.8) |  |
| Other | 0.3 |  |  | — |  |
| Net cash provided by (used in) investing activities | (649.3) |  |  | 763.9 |  |
| CASH FLOWS FROM FINANCING ACTIVITIES: |  |  |  |
| Repurchase and retirement of common stock | (1,500.5) |  |  | (1,991.2) |  |
| Proceeds from issuance of common stock | 43.8 |  |  | 26.1 |  |
| Taxes paid related to net share settlement of equity awards | (112.5) |  |  | (160.4) |  |
| Other | (1.2) |  |  | (4.8) |  |
| Net cash used in financing activities | (1,570.4) |  |  | (2,130.3) |  |
| EFFECT OF EXCHANGE RATE CHANGES ON CASH AND CASH EQUIVALENTS | (0.8) |  |  | (0.4) |  |
| NET INCREASE (DECREASE) IN CASH AND CASH EQUIVALENTS | (285.0) |  |  | 363.8 |  |
| CASH AND CASH EQUIVALENTS—Beginning of year | 1,682.9 |  |  | 1,319.1 |  |
| CASH AND CASH EQUIVALENTS—End of year | $ | 1,397.9 |  |  | $ | 1,682.9 |  |

[0001262039-24-000006:8k_2_02:106]
Reconciliations of non-GAAP results of operations measures to the nearest comparable GAAP measures

[0001262039-24-000006:8k_2_02:107]
(Unaudited, in millions, except per share amounts)

[0001262039-24-000006:8k_2_02:108]
Reconciliation of GAAP operating income to non-GAAP operating income, operating margin, net income attributable to Fortinet, Inc. and diluted net income per share attributable to Fortinet, Inc.

[0001262039-24-000006:8k_2_02:109]
|  | Three Months Ended |  | Year Ended |
|  | December 31,2023 |  | December 31,2022 |  | December 31,2023 |  | December 31,2022 |
| Reconciliation of non-GAAP operating income: |  |  |  |  |  |  |  |
| GAAP operating income | $ | 385.4 |  |  | $ | 357.8 |  |  | $ | 1,241.1 |  |  | $ | 969.6 |  |
| GAAP operating margin | 27.2 | % |  | 27.9 | % |  | 23.4 | % |  | 21.9 | % |
| Add back: |  |  |  |  |  |  |  |
| Stock‐based compensation | 64.0 |  |  | 55.3 |  |  | 251.6 |  |  | 219.8 |  |
| Amortization of acquired intangible assets | 5.3 |  |  | 5.7 |  |  | 18.9 |  |  | 23.3 |  |
| Gain on intellectual property matter | (1.2) |  |  | (1.2) |  |  | (4.6) |  |  | (4.6) |  |
| Non‐GAAP operating income | $ | 453.5 |  |  | $ | 417.6 |  |  | $ | 1,507.0 |  |  | $ | 1,208.1 |  |
| Non‐GAAP operating margin | 32.0 | % |  | 32.5 | % |  | 28.4 | % |  | 27.3 | % |
| Reconciliation of non-GAAP net income attributable to Fortinet, Inc.: |  |  |  |  |  |  |  |
| GAAP net income attributable to Fortinet, Inc. | $ | 310.9 |  |  | $ | 313.8 |  |  | $ | 1,147.8 |  |  | $ | 857.3 |  |
| Add back: |  |  |  |  |  |  |  |
| Stock‐based compensation | 64.0 |  |  | 55.3 |  |  | 251.6 |  |  | 219.8 |  |
| Amortization of acquired intangible assets | 5.3 |  |  | 5.7 |  |  | 18.9 |  |  | 23.3 |  |
| Gain on intellectual property matter | (1.2) |  |  | (1.2) |  |  | (4.6) |  |  | (4.6) |  |
| Tax adjustment (a) | 13.0 |  |  | (63.6) |  |  | (128.1) |  |  | (172.2) |  |
| Non-cash charge on equity method investment | — |  |  | 39.7 |  |  | — |  |  | 39.7 |  |
| Adjustments attributable non-controlling interests (b) | — |  |  | — |  |  | — |  |  | (1.7) |  |
| Non-GAAP net income attributable to Fortinet, Inc. | $ | 392.0 |  |  | $ | 349.7 |  |  | $ | 1,285.6 |  |  | $ | 961.6 |  |
| Non-GAAP net income per share attributable to Fortinet, Inc., diluted |  |  |  |  |  |  |  |
| Non-GAAP net income attributable to Fortinet, Inc. | $ | 392.0 |  |  | $ | 349.7 |  |  | $ | 1,285.6 |  |  | $ | 961.6 |  |
| Non-GAAP shares used in diluted net income per share attributable to Fortinet, Inc. calculations | 772.3 |  |  | 791.8 |  |  | 788.2 |  |  | 805.3 |  |
| Non-GAAP net income per share attributable to Fortinet, Inc., diluted | $ | 0.51 |  |  | $ | 0.44 |  |  | $ | 1.63 |  |  | $ | 1.19 |  |
| Reconciliation of non-GAAP net income per share attributable to Fortinet, Inc., diluted |  |  |  |  |  |  |  |
| GAAP net income per share attributable to Fortinet, Inc., diluted | $ | 0.40 |  |  | $ | 0.40 |  |  | $ | 1.46 |  |  | $ | 1.06 |  |
| Add back: |  |  |  |  |  |  |  |
| Non-GAAP adjustments to net income per share attributable to Fortinet, Inc. | 0.11 |  |  | 0.04 |  |  | 0.17 |  |  | 0.13 |  |
| Non-GAAP net income per share attributable to Fortinet, Inc., diluted | $ | 0.51 |  |  | $ | 0.44 |  |  | $ | 1.63 |  |  | $ | 1.19 |  |

[0001262039-24-000006:8k_2_02:110]
(a) Non-GAAP financial information is adjusted to an effective tax rate of 17% in the three months and year ended December 31, 2023 and 2022, respectively, on a non-GAAP basis, which differs from the GAAP effective tax rate.

[0001262039-24-000006:8k_2_02:111]
(b) Adjustments related to the non-GAAP results attributable to non-controlling interests, which were adjusted to an effective tax rate of 31% for the subsidiary of Alaxala Networks Corporation in 2022.

[0001262039-24-000006:8k_2_02:112]
Reconciliation of net cash provided by operating activities to free cash flow

[0001262039-24-000006:8k_2_02:113]
|  | Three Months Ended |  | Year Ended |
|  | December 31,2023 |  | December 31,2022 |  | December 31,2023 |  | December 31,2022 |
| Net cash provided by operating activities | $ | 191.7 |  |  | $ | 528.1 |  |  | $ | 1,935.5 |  |  | $ | 1,730.6 |  |
| Less: Purchases of property and equipment | (26.9) |  |  | (30.9) |  |  | (204.1) |  |  | (281.2) |  |
| Free cash flow | $ | 164.8 |  |  | $ | 497.2 |  |  | $ | 1,731.4 |  |  | $ | 1,449.4 |  |
| Net cash provided by (used in) investing activities | $ | (71.6) |  |  | $ | 217.4 |  |  | $ | (649.3) |  |  | $ | 763.9 |  |
| Net cash used in financing activities | $ | (910.1) |  |  | $ | (27.4) |  |  | $ | (1,570.4) |  |  | $ | (2,130.3) |  |

[0001262039-24-000006:8k_2_02:114]
Reconciliation of total revenue to total billings

[0001262039-24-000006:8k_2_02:115]
|  | Three Months Ended |  | Year Ended |
|  | December 31,2023 |  | December 31,2022 |  | December 31,2023 |  | December 31,2022 |
| Total revenue | $ | 1,415.1 |  |  | $ | 1,283.0 |  |  | $ | 5,304.8 |  |  | $ | 4,417.4 |  |
| Add: Change in deferred revenue | 449.7 |  |  | 446.8 |  |  | 1,094.7 |  |  | 1,187.4 |  |
| Less: Deferred revenue balance acquired in business acquisitions | — |  |  | (10.8) |  |  | — |  |  | (10.8) |  |
| Total billings | $ | 1,864.8 |  |  | $ | 1,719.0 |  |  | $ | 6,399.5 |  |  | $ | 5,594.0 |  |

[0001262039-24-000006:8k_2_02:116]
| Investor Contact: |  | Media Contact: |
| Peter Salkowski |  | Michelle Zimmermann |
| Fortinet, Inc. |  | Fortinet, Inc. |
| 408-331-4595 |  | 408-235-7700 |
| psalkowski@fortinet.com |  | pr@fortinet.com |
