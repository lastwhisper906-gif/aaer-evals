# FTNT note change history — 0001262039-22-000038 → 0001262039-23-000021


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2023-05-08):
[0001262039-23-000021:note_history:1]
COMMITMENTS AND CONTINGENCIESThe following table summarizes our inventory purchase commitments as of March 31, 2023 (in millions):
  (was, 2022-11-07, similarity 0.9569):
[0001262039-22-000038:note_history:1]
COMMITMENTS AND CONTINGENCIES
The following table summarizes our inventory purchase commitments as of September 30, 2022 (in millions):

- changed (2023-05-08):
[0001262039-23-000021:note_history:2]
Inventory Purchase Commitments—Our independent contract manufacturers and certain component suppliers procure components and build our products based on our forecasts, the availability of various components and their capacity. These forecasts are based on estimates of future demand for our products, which are in turn based on historical trends and an analysis from our sales and marketing organizations, adjusted for extended lead times, changes in supplier delivery commitments and other supply chain matters and market conditions. In order to manage manufacturing lead times, plan for adequate component supply and incentivize suppliers to deliver, we may issue purchase orders to some of our independent contract manufacturers, which are non-cancelable. As of March 31, 2023, we had $1.20 billion of open purchase orders with our independent contract manufacturers that consist of non-cancelable commitments. In certain instances, these agreements allow us the option to reschedule and adjust our requirements based on our business needs prior to firm orders being placed.
  (was, 2022-11-07, similarity 0.9721):
[0001262039-22-000038:note_history:2]
Inventory Purchase Commitments—Our independent contract manufacturers and certain component suppliers procure components and build our products based on our forecasts, the availability of various components and their capacity. These forecasts are based on estimates of future demand for our products, which are in turn based on historical trends and an analysis from our sales and marketing organizations, adjusted for extended lead times, changes in supplier delivery commitments and other supply chain matters and market conditions. In order to manage manufacturing lead times, plan for adequate component supply and incentivize suppliers to deliver, we may issue purchase orders to some of our independent contract manufacturers, which are non-cancelable. As of September 30, 2022 and December 31, 2021, we had $1.46 billion and $1.14 billion, respectively, of open purchase orders with our independent contract manufacturers that consist of non-cancelable commitments. In certain instances, these agreements allow us the option to reschedule and adjust our requirements based on our business needs prior to firm orders being placed.

- changed (2023-05-08):
[0001262039-23-000021:note_history:3]
Other Contractual Commitments and Open Purchase Orders—In addition to commitments with contract manufacturers, we have open purchase orders and contractual obligations in the ordinary course of business for which we have not received goods or services. A significant portion of our reported purchase commitments consist of non-cancelable commitments. In certain instances, contractual commitments allow us the option to cancel, reschedule and adjust our requirements based on our business needs prior to firm orders being placed. As of March 31, 2023, we had $100.1 million in other contractual commitments having a remaining term in excess of one year that are non-cancelable and an additional $100.7 million, in contractual commitments for operating lease liabilities.
  (was, 2022-11-07, similarity 0.7462):
[0001262039-22-000038:note_history:3]
Other Contractual Commitments and Open Purchase Orders—In addition to commitments with contract manufacturers, we have open purchase orders and contractual obligations in the ordinary course of business for which we have not received goods or services. A significant portion of our reported purchase commitments consist of non-cancelable commitments. In certain instances, contractual commitments allow us the option to cancel, reschedule and adjust our requirements based on our business needs prior to firm orders being placed. As of September 30, 2022 and December 31, 2021, we had $111.7 million and $126.7 million, respectively, in other contractual commitments having a remaining term in excess of one year that are non-cancelable and an additional $73.5 million and $68.9 million, respectively, in contractual commitments for operating lease liabilities.

- changed (2023-05-08):
[0001262039-23-000021:note_history:4]
Litigation loss contingency accruals associated with outstanding cases were not material as of March 31, 2023 and December 31, 2022.
  (was, 2022-11-07, similarity 0.9593):
[0001262039-22-000038:note_history:4]
Litigation loss contingency accruals associated with outstanding cases were not material as of September 30, 2022 and December 31, 2021.

- changed (2023-05-08):
[0001262039-23-000021:note_history:5]
Similar to other security companies and companies in other industries, we have experienced and may experience in the future, cybersecurity threats, malicious activity directed against our information technology infrastructure or unauthorized attempts to gain access to our and our customers’ sensitive information and systems. We currently are unaware of any existing claims or proceedings related to these types of matters, including any that we believe are likely to have a material adverse effect on our financial position.
  (was, 2022-11-07, similarity 0.9438):
[0001262039-22-000038:note_history:5]
Similar to other security companies and companies in other industries, we have in the past experienced, and we may in the future experience, cybersecurity threats, malicious activity directed against our information technology infrastructure or unauthorized attempts to gain access to our and our customers’ sensitive information and systems. We currently are unaware of 
any existing claims or proceedings related to these types of matters, including any that we believe are likely to have a material adverse effect on our financial position.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2023-05-08):
[0001262039-23-000021:note_history:6]
SUMMARY OF SIGNIFICANT ACCOUNTING POLICIES
Basis of Presentation and Preparation—The unaudited condensed consolidated financial statements of Fortinet, Inc. and its subsidiaries (collectively, “we,” “us” or “our”) have been prepared in accordance with generally accepted accounting principles in the United States (“GAAP”) for interim financial information, as well as the instructions to Form 10-Q pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (the “SEC”). Accordingly, they do not include all of the information and footnotes required by GAAP for complete financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the year ended December 31, 2022, contained in our Annual Report on Form 10-K filed with the SEC on February 24, 2023. In the opinion of management, all adjustments, which include normal recurring adjustments, considered necessary for a fair presentation, have been included. The results of operations for the three months ended March 31, 2023 are not necessarily indicative of the results to be expected for the full year or for any future periods. The condensed consolidated balance sheet as of December 31, 2022 is derived from the audited consolidated financial statements for the year ended December 31, 2022.
  (was, 2022-11-07, similarity 0.9813):
[0001262039-22-000038:note_history:6]
SUMMARY OF SIGNIFICANT ACCOUNTING POLICIES
Basis of Presentation and Preparation—The unaudited condensed consolidated financial statements of Fortinet, Inc. and its subsidiaries (collectively, “we,” “us” or “our”) have been prepared in accordance with generally accepted accounting principles in the United States (“GAAP”) for interim financial information, as well as the instructions to Form 10-Q pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (the “SEC”). Accordingly, they do not include all of the information and footnotes required by GAAP for complete financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the year ended December 31, 2021, contained in our Annual Report on Form 10-K filed with the SEC on February 25, 2022. In the opinion of management, all adjustments, which include normal recurring adjustments, considered necessary for a fair presentation, have been included. The results of operations for the three and nine months ended September 30, 2022 are not necessarily indicative of the results to be expected for the full year or for any future periods. The condensed consolidated balance sheet as of December 31, 2021 is derived from the audited consolidated financial statements for the year ended December 31, 2021.

- changed (2023-05-08):
[0001262039-23-000021:note_history:7]
On April 14, 2022, our board of directors approved a five-for-one forward stock split of our common stock (the “Forward Stock Split”), which was conditioned upon obtaining stockholder approval for the Forward Stock Split, and to increase the number of our authorized shares of common stock. On June 17, 2022, at our 2022 Annual Meeting of Stockholders, our stockholders approved the Forward Stock Split and the amendment and restatement of our amended and restated certificate of incorporation to increase the number of authorized shares of common stock from 300.0 million to 1.5 billion. The par value of our common stock was not adjusted as a result of the Forward Stock Split. Effective June 22, 2022, we filed our amended and restated certification of incorporation and completed the Forward Stock Split. All share and per share amounts and related equity (deficit) balances presented herein have been retroactively adjusted to reflect the Forward Stock Split.
  (was, 2022-11-07, similarity 0.9703):
[0001262039-22-000038:note_history:7]
On April 14, 2022, our Board of Directors approved a five-for-one forward stock split of our common stock (the "Forward Stock Split"), which was conditioned upon obtaining stockholder approval for the Forward Stock Split, and to increase the number of our authorized shares of common stock. On June 17, 2022, at our 2022 Annual Meeting of Stockholders, our stockholders approved the Forward Stock Split and the amendment and restatement of our amended and restated certificate of incorporation to increase the number of authorized shares of common stock from 300 million to 1.5 billion. The par value of our common stock was not adjusted as a result of the Forward Stock Split. Effective June 22, 2022, we filed our amended and restated certification of incorporation and completed the Forward Stock Split. All share and per share amounts and related stockholders’ equity (deficit) balances presented herein have been retroactively adjusted to reflect the Forward Stock Split.

- changed (2023-05-08):
[0001262039-23-000021:note_history:8]
There have been no material changes to our significant accounting policies as of and for the three months ended March 31, 2023, as compared to the significant accounting policies described in the Form 10-K.
  (was, 2022-11-07, similarity 0.7087):
[0001262039-22-000038:note_history:8]
There have been no material changes to our significant accounting policies as of and for the three and nine months ended September 30, 2022.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-05-08):
[0001262039-23-000021:note_history:9]
On March 5, 2021, we issued $1.0 billion aggregate principal amount of senior notes (collectively, the “Senior Notes”), consisting of $500.0 million aggregate principal amount of 1.0% notes due March 15, 2026 (the “2026 Senior Notes”) and $500.0 million aggregate principal amount of 2.2% notes due March 15, 2031 (the “2031 Senior Notes”), in an underwritten registered public offering. The Senior Notes are senior unsecured obligations and rank equally with each other in right of payment and with our other outstanding obligations. We may redeem the Senior Notes at any time in whole or in part for cash, at specified redemption prices that include accrued and unpaid interest, if any, and a make-whole premium. However, no make-whole premium will be paid for redemptions of the 2026 Senior Notes on or after February 15, 2026, or the 2031 Senior Notes on or after December 15, 2030. Interest on the Senior Notes is payable on March 15 and September 15 of each year, beginning on September 15, 2021. As of March 31, 2023 and December 31, 2022, the Senior Notes were recorded as long-term debt, net of discount and issuance costs, which are amortized to interest expense over the respective contractual terms of these notes using the effective interest method.
  (was, 2022-11-07, similarity 0.9941):
[0001262039-22-000038:note_history:9]
On March 5, 2021, we issued $1.0 billion aggregate principal amount of senior notes (collectively, the “Senior Notes”), consisting of $500.0 million aggregate principal amount of 1.0% notes due March 15, 2026 (the “2026 Senior Notes”) and $500.0 million aggregate principal amount of 2.2% notes due March 15, 2031 (the “2031 Senior Notes”), in an underwritten registered public offering. The Senior Notes are senior unsecured obligations and rank equally with each other in right of payment and with our other outstanding obligations. We may redeem the Senior Notes at any time in whole or in part for cash, at specified redemption prices that include accrued and unpaid interest, if any, and a make-whole premium. However, no make-whole premium will be paid for redemptions of the 2026 Senior Notes on or after February 15, 2026, or the 2031 Senior Notes on or after December 15, 2030. Interest on the Senior Notes is payable on March 15 and September 15 of each year, beginning on September 15, 2021. As of September 30, 2022 and December 31, 2021, the Senior Notes were recorded as long-term debt, net of discount and issuance costs, which are amortized to interest expense over the respective contractual terms of these notes using the effective interest method.

- changed (2023-05-08):
[0001262039-23-000021:note_history:10]
|  | Maturity |  | Coupon Rate |  | Effective Interest Rate |  | March 31,2023 |  | December 31,2022 |
| Debt |  |  |  |  |  |  |  |  |  |
| 2026 Senior Notes | March 2026 |  | 1.0% |  | 1.3% |  | $ | 500.0 |  |  | $ | 500.0 |  |
| 2031 Senior Notes | March 2031 |  | 2.2% |  | 2.3% |  | 500.0 |  |  | 500.0 |  |
| Total debt |  |  |  |  |  |  | 1,000.0 |  |  | 1,000.0 |  |
| Less: Unamortized discount and debt issuance costs |  |  |  |  |  |  | 9.1 |  |  | 9.6 |  |
| Total long-term debt |  |  |  |  |  |  | $ | 990.9 |  |  | $ | 990.4 |  |
  (was, 2022-11-07, similarity 0.9834):
[0001262039-22-000038:note_history:10]
|  | Maturity |  | Coupon Rate |  | Effective Interest Rate |  | September 30,2022 |  | December 31,2021 |
| Debt |  |  |  |  |  |  |  |  |  |
| 2026 Senior Notes | March 2026 |  | 1.0% |  | 1.3% |  | $ | 500.0 |  |  | $ | 500.0 |  |
| 2031 Senior Notes | March 2031 |  | 2.2% |  | 2.3% |  | 500.0 |  |  | 500.0 |  |
| Total debt |  |  |  |  |  |  | 1,000.0 |  |  | 1,000.0 |  |
| Less: Unamortized discount and debt issuance costs |  |  |  |  |  |  | 10.1 |  |  | 11.6 |  |
| Total long-term debt |  |  |  |  |  |  | $ | 989.9 |  |  | $ | 988.4 |  |

- changed (2023-05-08):
[0001262039-23-000021:note_history:11]
As of March 31, 2023 and December 31, 2022, we accrued interest payable of $0.7 million and $4.7 million, respectively, and there are no financial covenants with which we must comply. During the three months ended March 31, 2023 and 2022, we recorded $4.5 million of total interest expense in relation to these Senior Notes and repaid $8.0 million of interest in cash in each quarter. No interest costs were capitalized for the three months ended March 31, 2023 and 2022, as the costs that qualified for capitalization were not material.
  (was, 2022-11-07, similarity 0.7694):
[0001262039-22-000038:note_history:11]
As of September 30, 2022 and December 31, 2021, we accrued interest payable of $0.7 million and $4.7 million, respectively, and there are no financial covenants with which we must comply. During the three months ended September 30, 2022 and 2021, we recorded $4.4 million of total interest expense in relation to these Senior Notes in each quarter. During the nine months ended September 30, 2022 and 2021, total interest expense in relation to these Senior Notes was $13.4 million and $10.2 million, respectively. No interest costs were capitalized for the three months or nine months ended September 30, 2022 and 2021, as the costs that qualified for capitalization were not material.

- added (2023-05-08):
[0001262039-23-000021:note_history:12]
The total estimated fair value of the outstanding Senior Notes was approximately $867.7 million, including accrued and unpaid interest, as of March 31, 2023. The fair value was determined based on observable market prices of identical instruments in less active markets. The estimated fair values are based on Level 2 inputs.

- removed (2023-05-08):
[0001262039-22-000038:note_history:13]
The total estimated fair value of the outstanding Senior Notes was approximately $808.9 million, including accrued and unpaid interest, as of September 30, 2022. The fair value was determined based on observable market prices of identical instruments in less active markets. The estimated fair values are based on Level 2 inputs.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-05-08):
[0001262039-23-000021:note_history:14]
|  | Maturity |  | Coupon Rate |  | Effective Interest Rate |  | March 31,2023 |  | December 31,2022 |
| Debt |  |  |  |  |  |  |  |  |  |
| 2026 Senior Notes | March 2026 |  | 1.0% |  | 1.3% |  | $ | 500.0 |  |  | $ | 500.0 |  |
| 2031 Senior Notes | March 2031 |  | 2.2% |  | 2.3% |  | 500.0 |  |  | 500.0 |  |
| Total debt |  |  |  |  |  |  | 1,000.0 |  |  | 1,000.0 |  |
| Less: Unamortized discount and debt issuance costs |  |  |  |  |  |  | 9.1 |  |  | 9.6 |  |
| Total long-term debt |  |  |  |  |  |  | $ | 990.9 |  |  | $ | 990.4 |  |
  (was, 2022-11-07, similarity 0.9834):
[0001262039-22-000038:note_history:14]
|  | Maturity |  | Coupon Rate |  | Effective Interest Rate |  | September 30,2022 |  | December 31,2021 |
| Debt |  |  |  |  |  |  |  |  |  |
| 2026 Senior Notes | March 2026 |  | 1.0% |  | 1.3% |  | $ | 500.0 |  |  | $ | 500.0 |  |
| 2031 Senior Notes | March 2031 |  | 2.2% |  | 2.3% |  | 500.0 |  |  | 500.0 |  |
| Total debt |  |  |  |  |  |  | 1,000.0 |  |  | 1,000.0 |  |
| Less: Unamortized discount and debt issuance costs |  |  |  |  |  |  | 10.1 |  |  | 11.6 |  |
| Total long-term debt |  |  |  |  |  |  | $ | 989.9 |  |  | $ | 988.4 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2023-05-08):
[0001262039-23-000021:note_history:15]
|  | Three Months Ended |  |  |
|  | March 31,2023 |  | March 31,2022 |  |  |  |  |
| Product | $ | 500.7 |  |  | $ | 371.0 |  |  |  |  |  |
| Service: |  |  |  |  |  |  |  |
| Security subscription | 421.7 |  |  | 312.9 |  |  |  |  |  |
| Technical support and other | 339.9 |  |  | 270.9 |  |  |  |  |  |
| Total service revenue | 761.6 |  |  | 583.8 |  |  |  |  |  |
| Total revenue | $ | 1,262.3 |  |  | $ | 954.8 |  |  |  |  |  |
  (was, 2022-11-07, similarity 0.6518):
[0001262039-22-000038:note_history:15]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30,2022 |  | September 30,2021 |  | September 30,2022 |  | September 30,2021 |
| Product | $ | 468.7 |  |  | $ | 337.1 |  |  | $ | 1,240.4 |  |  | $ | 876.1 |  |
| Service: |  |  |  |  |  |  |  |
| Security subscription | 369.8 |  |  | 287.4 |  |  | 1,023.1 |  |  | 815.6 |  |
| Technical support and other | 311.0 |  |  | 242.7 |  |  | 870.9 |  |  | 686.9 |  |
| Total service revenue | 680.8 |  |  | 530.1 |  |  | 1,894.0 |  |  | 1,502.5 |  |
| Total revenue | $ | 1,149.5 |  |  | $ | 867.2 |  |  | $ | 3,134.4 |  |  | $ | 2,378.6 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2023-05-08):
[0001262039-23-000021:note_history:16]
REVENUE RECOGNITION
Disaggregation of Revenue

- changed (2023-05-08):
[0001262039-23-000021:note_history:17]
|  | Three Months Ended |  |  |
|  | March 31,2023 |  | March 31,2022 |  |  |  |  |
| Product | $ | 500.7 |  |  | $ | 371.0 |  |  |  |  |  |
| Service: |  |  |  |  |  |  |  |
| Security subscription | 421.7 |  |  | 312.9 |  |  |  |  |  |
| Technical support and other | 339.9 |  |  | 270.9 |  |  |  |  |  |
| Total service revenue | 761.6 |  |  | 583.8 |  |  |  |  |  |
| Total revenue | $ | 1,262.3 |  |  | $ | 954.8 |  |  |  |  |  |
  (was, 2022-11-07, similarity 0.6518):
[0001262039-22-000038:note_history:17]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30,2022 |  | September 30,2021 |  | September 30,2022 |  | September 30,2021 |
| Product | $ | 468.7 |  |  | $ | 337.1 |  |  | $ | 1,240.4 |  |  | $ | 876.1 |  |
| Service: |  |  |  |  |  |  |  |
| Security subscription | 369.8 |  |  | 287.4 |  |  | 1,023.1 |  |  | 815.6 |  |
| Technical support and other | 311.0 |  |  | 242.7 |  |  | 870.9 |  |  | 686.9 |  |
| Total service revenue | 680.8 |  |  | 530.1 |  |  | 1,894.0 |  |  | 1,502.5 |  |
| Total revenue | $ | 1,149.5 |  |  | $ | 867.2 |  |  | $ | 3,134.4 |  |  | $ | 2,378.6 |  |

- added (2023-05-08):
[0001262039-23-000021:note_history:18]
During the three months ended March 31, 2023 and 2022, we recognized $675.9 million and $507.3 million in service revenue that was included in the deferred revenue balance as of December 31, 2022 and 2021, respectively.

- changed (2023-05-08):
[0001262039-23-000021:note_history:19]
As of March 31, 2023, the aggregate amount of the transaction price allocated to remaining performance obligations was $4.91 billion, which was substantially comprised of deferred security subscription, technical support services revenue and unbilled contract revenue from non-cancellable contracts that will be recognized in future periods. We expect to recognize approximately $2.49 billion as revenue over the next 12 months and the remainder thereafter.
  (was, 2022-11-07, similarity 0.9843):
[0001262039-22-000038:note_history:19]
As of September 30, 2022, the aggregate amount of the transaction price allocated to remaining performance obligations was $4.21 billion, which was substantially comprised of deferred security subscription, technical support services revenue and unbilled contract revenue from non-cancellable contracts that will be recognized in future periods. We expect to recognize approximately $2.15 billion as revenue over the next 12 months and the remainder thereafter.

- added (2023-05-08):
[0001262039-23-000021:note_history:20]
Trade accounts receivable are recorded at the invoiced amount, net of an allowance for expected credit losses. We measure expected credit losses of accounts receivable on a collective (pooled) basis, aggregating accounts receivable that are either current or no more than 60 days past due, and aggregating accounts receivable that are more than 60 days past due. We apply a credit-loss percentage to each of the pools that is based on our historical credit losses. We review whether each of our significant accounts receivable that is more than 60 days past due continues to exhibit similar risk characteristics with the other accounts receivable in the pool. If we determine that it does not, we evaluate it for expected credit losses on an individual basis. Expected credit losses are recorded as general and administrative expenses on our consolidated statements of income.

- changed (2023-05-08):
[0001262039-23-000021:note_history:21]
The allowance for credit losses was $6.7 million and $3.6 million as of March 31, 2023 and December 31, 2022, respectively. Provisions, write-offs and recoveries were not material during the three months ended March 31, 2023 and 2022.
  (was, 2022-11-07, similarity 0.8103):
[0001262039-22-000038:note_history:21]
The allowance for credit losses was $3.7 million and $2.4 million as of September 30, 2022 and December 31, 2021, respectively. Provisions, write-offs and recoveries were not material during the nine months ended September 30, 2022 and 2021.

- changed (2023-05-08):
[0001262039-23-000021:note_history:22]
Amortization of deferred contract costs during the three months ended March 31, 2023 and 2022 were $62.5 million and $52.5 million, respectively.
  (was, 2022-11-07, similarity 0.6284):
[0001262039-22-000038:note_history:22]
Amortization of deferred contract costs during the three months ended September 30, 2022 and 2021 were $56.7 million and $45.1 million, respectively. Amortization of deferred contract costs during the nine months ended September 30, 2022 and 2021 were $163.8 million and $126.9 million, respectively.

- removed (2023-05-08):
[0001262039-22-000038:note_history:23]
REVENUE RECOGNITIONWe sell cybersecurity solutions to channel partners who in turn sell such solutions to a variety of organizations, such as large-, medium- and small-sized enterprises, communication service providers and government organizations. Our revenue consists of product and service revenue. Product revenue is generated by our Core Platform (previously referred to as FortiGate network security and other products) and our Enhanced Platform Technologies (previously referred to as Platform Extension). Service revenue relates to sales of our security subscription services, which mainly consists of our FortiGuard security subscriptions, as well as our FortiCare technical support services and other services.
Disaggregation of Revenue

- removed (2023-05-08):
[0001262039-22-000038:note_history:24]
During the three and nine months ended September 30, 2022, we recognized $401.9 million and $1.37 billion in service revenue that was included in the deferred revenue balance as of December 31, 2021, respectively. During the three and nine months ended September 30, 2021, we recognized $309.2 million and $1.10 billion in service revenue that was included in the deferred revenue balance as of December 31, 2020, respectively.

- removed (2023-05-08):
[0001262039-22-000038:note_history:25]
Trade accounts receivable are recorded at the invoiced amount. Our accounts receivable balance is reduced by an allowance for expected credit losses. We measure expected credit losses of accounts receivable on a collective (pooled) basis, aggregating accounts receivable that are either current or no more than 60 days past due, and aggregating accounts receivable that are more than 60 days past due. We apply a credit-loss percentage to each of the pools that is based on our historical credit losses. We review whether each of our significant accounts receivable that is more than 60 days past due continues to exhibit similar risk characteristics with the other accounts receivable in the pool. If we determine that it does not, we evaluate it for expected credit losses on an individual basis. Expected credit losses are recorded as general and administrative expenses on our consolidated statements of income.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- added (2023-05-08):
[0001262039-23-000021:note_history:26]
SUBSEQUENT EVENTS
Share Repurchase Program

- added (2023-05-08):
[0001262039-23-000021:note_history:27]
In April 2023, our board of directors approved a $1.0 billion increase in the authorized stock repurchase amount under the Repurchase Program, bringing the aggregate amount authorized to be repurchased to $6.25 billion of our outstanding common stock through February 29, 2024. As of May 8, 2023, approximately $1.53 billion remained available for future share repurchases.

- added (2023-05-08):
[0001262039-23-000021:note_history:28]
Real property purchase

- added (2023-05-08):
[0001262039-23-000021:note_history:29]
In April 2023, we purchased real property in Plano, Texas, totaling approximately 43,400 square feet, for $19.3 million in cash.

- removed (2023-05-08):
[0001262039-22-000038:note_history:30]
SUBSEQUENT EVENTS
Acquisition of Non-Controlling Interests in Alaxala

- removed (2023-05-08):
[0001262039-22-000038:note_history:31]
On October 3, 2022, we completed our acquisition of the remaining 25% equity interests in Alaxala for $13.5 million. Refer to Note 7. Business Combinations for information in connection with our acquisition of Alaxala.
