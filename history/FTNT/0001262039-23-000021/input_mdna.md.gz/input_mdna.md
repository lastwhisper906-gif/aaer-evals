# FTNT MD&A — 0001262039-23-000021


## mdna

[0001262039-23-000021:mdna:1]
[same as prior period, unchanged from 0001262039-22-000038:mdna:1]

[0001262039-23-000021:mdna:2]
•supply chain constraints, component availability and other factors affecting our manufacturing capacity, delivery, cost and inventory management, as well as improving supply chain dynamics;

[0001262039-23-000021:mdna:3]
•increasing or decreasing inflation or stagflation, and rising interest rates in many geographies and changes in currency exchange rates and currency regulations;

[0001262039-23-000021:mdna:4]
•the duration and impact of the COVID-19 pandemic, including various COVID-19 variants and “return to office” plans;

[0001262039-23-000021:mdna:5]
[same as prior period, unchanged from 0001262039-22-000038:mdna:6]

[0001262039-23-000021:mdna:6]
•variability in sales in certain product and service categories from year to year and between quarters;

[0001262039-23-000021:mdna:7]
•expected impact of sales from certain products and services;

[0001262039-23-000021:mdna:8]
•instability in the global banking system;

[0001262039-23-000021:mdna:9]
•macroeconomic, geopolitical factors and other disruption on our manufacturing or sales, including public health issues, wars and natural disasters;

[0001262039-23-000021:mdna:10]
•real estate investments and expansions of current properties;

[0001262039-23-000021:mdna:11]
•government regulation, tariffs and other policies;

[0001262039-23-000021:mdna:12]
•drivers of long-term growth and operating leverage, such as pricing of our products and services, sales productivity and capacity, functionality and value in our service offerings;

[0001262039-23-000021:mdna:13]
[same as prior period, unchanged from 0001262039-22-000038:mdna:12]

[0001262039-23-000021:mdna:14]
•forecasts of future demand and targeted inventory levels;

[0001262039-23-000021:mdna:15]
•the effect of backlog from prior quarters, including its effect on growth of in-quarter billings and revenue;

[0001262039-23-000021:mdna:16]
[same as prior period, unchanged from 0001262039-22-000038:mdna:13]

[0001262039-23-000021:mdna:17]
•risks and expectations related to acquisitions and equity interests in private and public companies, including integration issues related to go-to-market plans, product plans, employees of such companies, controls and processes and the acquired technology, and risks of negative impact by such acquisitions and equity investments on our financial results;

[0001262039-23-000021:mdna:18]
[same as prior period, unchanged from 0001262039-22-000038:mdna:15]

[0001262039-23-000021:mdna:19]
[same as prior period, unchanged from 0001262039-22-000038:mdna:16]

[0001262039-23-000021:mdna:20]
•expectations that our operating expenses will increase in absolute dollars during 2023;

[0001262039-23-000021:mdna:21]
24

[0001262039-23-000021:mdna:22]
•expectations that proceeds from the exercise of stock options in future years will be adversely impacted by the increased mix of restricted stock units and performance stock units versus stock options granted;

[0001262039-23-000021:mdna:23]
•expectations regarding uncertain tax benefits and our effective domestic and global tax rates, and the impact of interpretations of or changes to tax laws;

[0001262039-23-000021:mdna:24]
•expectations regarding spending related to real estate acquisitions and development, data center investments, as well as other capital expenditures and to the impact on free cash flow and expenses;

[0001262039-23-000021:mdna:25]
•estimates of a range of 2023 spending on capital expenditures;

[0001262039-23-000021:mdna:26]
[same as prior period, unchanged from 0001262039-22-000038:mdna:23]

[0001262039-23-000021:mdna:27]
•statements regarding expected outcomes and liabilities in litigation;

[0001262039-23-000021:mdna:28]
[same as prior period, unchanged from 0001262039-22-000038:mdna:25]

[0001262039-23-000021:mdna:29]
[same as prior period, unchanged from 0001262039-22-000038:mdna:26]

[0001262039-23-000021:mdna:30]
[same as prior period, unchanged from 0001262039-22-000038:mdna:27]

[0001262039-23-000021:mdna:31]
[same as prior period, unchanged from 0001262039-22-000038:mdna:28]

[0001262039-23-000021:mdna:32]
Fortinet is a global leader in cybersecurity and secure networking solutions. Our mission is to secure people, devices and data everywhere. We deliver cybersecurity everywhere our customers need it with an integrated portfolio of over 50 enterprise-grade products. As of March 31, 2023, over half a million customers, including enterprises, communication service providers and security service providers, government organizations and small and medium-sized businesses, trusted our solutions.

[0001262039-23-000021:mdna:33]
Our product offerings are designed to converge networking and security into a single solution, consolidate point products into an integrated platform and deliver operational-technology (“OT”) aware features to secure OT environments. This allows customers to realize automated protection, detection and response along with consolidated visibility across both Fortinet-developed solutions and a broad ecosystem of over 500 third-party solutions and technologies. As a U.S.-based company, over 80% of Fortinet’s research and development is based in North America, with a global footprint of support and centers of excellence across time zones from North America to Europe to Asia. We held 1,285 U.S. and foreign-issued patents as of March 31, 2023, a testament to our dedication to organic innovation that delivers leading cybersecurity and networking solutions.

[0001262039-23-000021:mdna:34]
As a cybersecurity leader, Fortinet believes it is our duty to help make the world a safer and more sustainable place. That is why, beyond our commitment to cybersecurity and networking technology innovation, we strive to:

[0001262039-23-000021:mdna:35]
•Reduce the environmental footprint of our technology with a commitment to ensure each generation of our products consumes less energy;

[0001262039-23-000021:mdna:36]
•Eliminate the global cyber skills shortage by maintaining one of the largest and broadest training programs in the industry; and

[0001262039-23-000021:mdna:37]
•Foster cooperation against cybercrime through partnerships that help shape the future of cyber threat

[0001262039-23-000021:mdna:38]
mitigation and by sharing actionable threat intelligence between public and private organizations.

[0001262039-23-000021:mdna:39]
[same as prior period, unchanged from 0001262039-22-000038:mdna:39]

[0001262039-23-000021:mdna:40]
•Secure Networking

[0001262039-23-000021:mdna:41]
•Cybersecurity Platform

[0001262039-23-000021:mdna:42]
•OT Security

[0001262039-23-000021:mdna:43]
Secure Networking—Our Secure Networking solutions enable the convergence of networking and security by integrating multiple markets and use cases into a single operating system: the Fortinet Operating System (“FortiOS”). It can be delivered to customers through an application-specific integrated circuit (“ASIC”) accelerated hardware appliance, virtual machine, as-a-Service, cloud native and container. When delivered via our appliances, functionality is accelerated with the use of our proprietary ASIC technology, which consists of three processors. First, a seventh generation network processor, FortiNP7, accelerates the processing of firewall traffic and offloads this function from the central processing unit (“CPU”). Second, a ninth generation content processor, FortiCP9, helps the CPU with deep packet inspection functions such as intrusion prevention and antivirus. Multiple CPUs, NP7s and CP9s can be placed in larger firewalls to provide more scale. Third, the CPU, network processor and content processor functions are all brought together in a single ASIC, our fifth generation Security Processor, FortiSP5. These proprietary ASICs, along with off the shelf CPU and ASICs, allow our systems to scale from the smallest branch to a hyperscale cloud and run multiple applications at higher performance and lower power consumption.

[0001262039-23-000021:mdna:44]
The following markets and use cases are supported by the FortiOS converged operating system:

[0001262039-23-000021:mdna:45]
•Network Firewall, including Hybrid Mesh Firewall

[0001262039-23-000021:mdna:46]
•Software-Defined Wide Area Network (“SD-WAN”)

[0001262039-23-000021:mdna:47]
•Local Area Network/Wireless Local Area Network (Wi-Fi and Switch)

[0001262039-23-000021:mdna:48]
•Secure Access Service Edge

[0001262039-23-000021:mdna:49]
•Universal Zero Trust Network Access

[0001262039-23-000021:mdna:50]
•Encryption Applications (SSL Inspection, Virtual Private Network and IPsec Connectivity)

[0001262039-23-000021:mdna:51]
Cybersecurity Platform—Many enterprises are looking to consolidate point products into a cybersecurity platform to improve the efficiency and efficacy of their security. This platform approach is also known as a Cybersecurity Mesh Security Architecture or a Security Fabric. Fortinet builds its security products with automation and integration in mind to support customers in building a cybersecurity platform. The major cybersecurity markets of our business include:

[0001262039-23-000021:mdna:52]
•Endpoint Protection Platforms

[0001262039-23-000021:mdna:53]
•Next-Generation Firewall

[0001262039-23-000021:mdna:54]
•Secure Web Gateway

[0001262039-23-000021:mdna:55]
•Identity and Access Management

[0001262039-23-000021:mdna:56]
•Cloud Access Security Broker

[0001262039-23-000021:mdna:57]
•Security Information and Event Management

[0001262039-23-000021:mdna:58]
•Security Orchestration and Automated Response

[0001262039-23-000021:mdna:59]
•Secure Email Gateway

[0001262039-23-000021:mdna:60]
•Web Application Firewalls

[0001262039-23-000021:mdna:61]
•Network Detection and Response

[0001262039-23-000021:mdna:62]
•External Attack Surface Monitoring

[0001262039-23-000021:mdna:63]
•Intrusion Prevention Systems (“IPS”)

[0001262039-23-000021:mdna:64]
•Network Access and Control

[0001262039-23-000021:mdna:65]
To support our broad portfolio of cybersecurity products, we deliver the following Threat Intelligence Services:

[0001262039-23-000021:mdna:66]
•Content Security, including Antivirus, In-Line Sandboxing and Credential Stuffing

[0001262039-23-000021:mdna:67]
•Web Security, including URL Filtering, DNS Security and IP Reputation

[0001262039-23-000021:mdna:68]
•Device Security, including IPS, OT Security, Internet of Things (“IoT”) Security and Botnet protection

[0001262039-23-000021:mdna:69]
•Application Security, including Anti-Spam and Web Application protection

[0001262039-23-000021:mdna:70]
•Security Operations Center Services, including Outbreak Protection, Attack Service Monitoring, Threat Hunting, Indicators of Compromise, MITRE ATT&CK and Incident Response

[0001262039-23-000021:mdna:71]
Operational Technology Security—OT uses hardware and software to detect or cause a change through the direct monitoring and/or control of industrial equipment, assets, processes and events. The security of such environments is sometimes described as Cyber-Physical Systems. The increased connectivity of OT environments and the need for supply chain access has increased the risk across OT industries such as manufacturing, energy, utilities, medical, transport, and critical infrastructure. While the basic concepts of Secure Networking and Cybersecurity Platform apply, OT systems are very different from a traditional information technology system. To secure OT environments, Fortinet delivers the following products and services:

[0001262039-23-000021:mdna:72]
•Secure Network and Connectivity

[0001262039-23-000021:mdna:73]
•Secure Remote Access

[0001262039-23-000021:mdna:74]
•OT-Specific InfoSec Tools

[0001262039-23-000021:mdna:75]
•OT-Specific Threat Intelligence

[0001262039-23-000021:mdna:76]
•Integration with third-party OT solutions

[0001262039-23-000021:mdna:77]
[same as prior period, unchanged from 0001262039-22-000038:mdna:47]

[0001262039-23-000021:mdna:78]
•Total revenue was $1.26 billion during the three months ended March 31, 2023, an increase of 32%, compared to $954.8 million in the same period last year. Product revenue was $500.7 million during the three months ended March 31, 2023, an increase of 35%, compared to $371.0 million in the same period last year. Service revenue was $761.6 million during the three months ended March 31, 2023, an increase of 30%, compared to $583.8 million in the same period last year.

[0001262039-23-000021:mdna:79]
•Total gross profit was $954.5 million during the three months ended March 31, 2023, an increase of 36%, compared to $701.0 million in the same period last year.

[0001262039-23-000021:mdna:80]
•Operating income was $273.5 million during the three months ended March 31, 2023, an increase of 81% compared to $151.0 million in the same period last year.

[0001262039-23-000021:mdna:81]
•Cash, cash equivalents, short-term and long-term investments and marketable equity securities were $2.89 billion as of March 31, 2023.

[0001262039-23-000021:mdna:82]
•Deferred revenue was $4.88 billion as of March 31, 2023, an increase of $240.6 million, or 5%, compared to $4.64 billion as of December 31, 2022 and an increase of $1.22 billion, or 33%, compared to $3.66 billion as of March 31, 2022. Deferred revenue was $3.66 billion as of March 31, 2022, an increase of $205.0 million, or 6%, compared to

[0001262039-23-000021:mdna:83]
$3.45 billion as of December 31, 2021 and an increase of $912.3 million, or 33%, compared to $2.75 billion as of March 31, 2021.

[0001262039-23-000021:mdna:84]
•Short-term deferred revenue was $2.46 billion as of March 31, 2023, an increase of $114.0 million, or 5%, compared to $2.35 billion as of December 31, 2022 and an increase of $570.0 million, or 30%, compared to $1.89 billion as of March 31, 2022. Short-term deferred revenue was $1.89 billion as of March 31, 2022, as increase of $115.9 million, or 7%, compared to $1.78 billion as of December 31, 2021 and an increase of $428.2 million, or 29%, compared to $1.47 billion as of March 31, 2021.

[0001262039-23-000021:mdna:85]
•We generated cash flows from operating activities of $677.5 million during the three months ended March 31, 2023, an increase of $281.4 million, or 71%, compared to the same period last year.

[0001262039-23-000021:mdna:86]
On a geographic basis, revenue continues to be diversified, which remains a key strength of our business. During the three months ended March 31, 2023, the Americas region, the Europe, Middle East and Africa (“EMEA”) region and the Asia Pacific (“APAC”) region contributed 41%, 38% and 21% of our total revenue, respectively, and increased 37%, 38% and 15% compared to the same period last year, respectively.

[0001262039-23-000021:mdna:87]
Our revenue growth was driven by strong product revenue performance. Product revenue grew 35% during the three months ended March 31, 2023, compared to the same period last year. Product revenue growth was consistent with an elevated cyber threat landscape, the convergence of security and networking and included the benefit of certain pricing actions, improving supply chain dynamics and changes in our backlog balance. The product revenue growth was primarily due to strong growth across many of our Enhanced Platform Technology products, including our secure access products. In addition, our product revenue growth was driven by a strong demand for the wide range of operating system capabilities embedded in our Core Platform products, including Secure SD-WAN and OT solutions. Service revenue growth of 30% during the three months ended March 31, 2023, compared to the same period last year, was primarily driven by the strength of our FortiGuard and other security subscription revenue, which grew 35%.

[0001262039-23-000021:mdna:88]
Our billings were diversified on a geographic basis. During the three months ended March 31, 2023, approximately 50% of our billings in the aggregate were from over 100 countries that each individually contributed less than 3% of our billings.

[0001262039-23-000021:mdna:89]
Operating expenses as a percentage of revenue benefited from the favorable impact of foreign currency fluctuations and decreased 3.7 percentage points during the three months ended March 31, 2023, compared to the same period last year. Headcount increased to 13,202 employees and contractors as of March 31, 2023, a 5% increase compared to 12,595 as of December 31, 2022.

[0001262039-23-000021:mdna:90]
Impact of Macroeconomic Developments and COVID-19 Pandemic Update

[0001262039-23-000021:mdna:91]
Our overall performance depends in part on worldwide economic and geopolitical conditions and their impact on customer behavior. Worsening economic conditions, including inflation, higher interest rates, slower growth, any recession, fluctuations in foreign exchange rates, instability in the global banking industry, and other changes in economic conditions, may result in decreased sales productivity and growth and adversely affect our results of operations and financial performance.

[0001262039-23-000021:mdna:92]
We continue to monitor and respond to developments relating to the COVID-19 pandemic. We have seen certain impacts on our business, results of operations, financial condition, cash flows, liquidity and capital and financial resources such as: supply chain challenges, including chip and other component shortages; increased commitments with certain suppliers; increased costs for certain chips, other components and shipping; and insufficient inventory to promptly meet all demand for all products.

[0001262039-23-000021:mdna:93]
In response to the COVID-19 pandemic, we undertook a number of actions to protect our employees, including restricting travel and directing many of our employees to work from home. In certain geographies, we have transitioned back to an in-person working mode, allowing increasing numbers of employees to work from our offices with reasonable precautions and, in all cases, subject to abiding by local legal restrictions. As certain country’s restrictions have eased, during the first quarter of 2023 we saw an increase in expenses related to travel and marketing events as compared to the same period last year.

[0001262039-23-000021:mdna:94]
Our days sales outstanding increased to 78 days in the first quarter of 2023, compared to 75 days in the same period last year, primarily due to the sales linearity. The accounts receivable allowance for credit losses was $6.7 million as of March 31, 2023, an increase of $3.1 million compared to $3.6 million as of December 31, 2022, primarily due to an increase in past due invoices over 60 and 90 days.

[0001262039-23-000021:mdna:95]
Worsening economic conditions and impacts from the COVID-19 pandemic may have a material negative impact on our results in future periods and may negatively impact our billings, revenue and costs, and may decrease growth and profitability. The extent of the impact of economic conditions and the COVID-19 pandemic on our operational and financial performance will depend on ongoing developments, including those discussed above and others identified in Part II, Item 1A “Risk Factors” in this Form 10-Q. Given the dynamic nature of these circumstances, the full impact of worsening economic conditions and the COVID-19 pandemic on our business and operations, results of operations, financial condition, cash flows, liquidity and capital and financial resources cannot be reasonably estimated at this time.

[0001262039-23-000021:mdna:96]
[same as prior period, unchanged from 0001262039-22-000038:mdna:74]

[0001262039-23-000021:mdna:97]
We typically sell our security solutions to distributors that sell to networking security focused resellers and to certain service providers and managed security service providers (“MSSPs”), who, in turn, sell to end-customers or use our products and services to provide hosted solutions to other enterprises. At times, we also sell directly to certain large enterprise customers, large service providers and major systems integrators. Our end-customers are located in over 100 countries and include small, medium and large enterprises and government organizations across a wide range of industries, including financial services, government, healthcare, manufacturing, retail, technology and telecommunications. An end-customer deployment may involve as few as one or as many as thousands of Core Platform products as well as Enhanced Platform Technology products, depending on the end-customer’s size and security requirements.

[0001262039-23-000021:mdna:98]
Our customers purchase our hardware products and software licenses, as well as our FortiGuard and other security subscription and FortiCare technical support services. We generally invoice at the time of our sale for the total price of the products and services. Standard payment terms are generally no more than 60 days, though we may offer extended payment terms to certain distributors or related to certain transactions.

[0001262039-23-000021:mdna:99]
We also offer our products hosted in our own data centers and through co-locations and major cloud providers, including Amazon Web Services, Microsoft Azure and Google Cloud. We have also recognized revenue from customers who deploy our products in a bring-your-own-license (“BYOL”) arrangements at cloud providers or at private clouds. In a BYOL arrangement, a customer purchases a software license through our channel partners and deploys the software in a cloud provider’s environment, in third-party clouds or in their private cloud.

[0001262039-23-000021:mdna:100]
[same as prior period, unchanged from 0001262039-22-000038:mdna:78]

[0001262039-23-000021:mdna:101]
We monitor several key metrics, including the key financial metrics set forth below, to evaluate growth trends, establish budgets, measure the effectiveness of our sales and marketing efforts, and assess operational efficiencies. The following table summarizes revenue, deferred revenue, billings (non-GAAP), net cash provided by operating activities, and free cash flow (non-GAAP). We discuss revenue below under “Results of Operations,” and we discuss net cash provided by operating activities below under “—Liquidity and Capital Resources.” Deferred revenue, billings (non-GAAP), and free cash flow (non-GAAP) are discussed immediately below the following table:

[0001262039-23-000021:mdna:102]
|  | Three Months Ended Or As Of |
|  | March 31, 2023 |  | March 31, 2022 |
|  | (in millions) |
| Revenue | $ | 1,262.3 |  |  | $ | 954.8 |  |
| Deferred revenue | $ | 4,880.9 |  |  | $ | 3,657.9 |  |
| Billings (non-GAAP) | $ | 1,502.9 |  |  | $ | 1,159.8 |  |
| Net cash provided by operating activities | $ | 677.5 |  |  | $ | 396.1 |  |
| Free cash flow (non-GAAP) | $ | 647.2 |  |  | $ | 273.5 |  |

[0001262039-23-000021:mdna:103]
Deferred revenue. Our deferred revenue consists of amounts that have been invoiced but that have not yet been recognized as revenue. The majority of our deferred revenue balance consists of the unrecognized portion of service revenue from FortiGuard and other security subscription and FortiCare technical support service contracts, which is recognized as revenue ratably over the service term. We monitor our deferred revenue balance, short term and total deferred revenue growth and the mix of short-term and long-term deferred revenue because deferred revenue represents a significant portion of free cash flow and of revenue to be recognized in future periods. Deferred revenue was $4.88 billion as of March 31, 2023, an increase of $240.6 million, or 5%, from December 31, 2022. Short term deferred revenue was $2.46 billion as of March 31, 2023, an increase of $114.0 million, or 5%, from December 31, 2022.

[0001262039-23-000021:mdna:104]
Billings (non-GAAP). We define billings as revenue recognized in accordance with GAAP plus the change in deferred revenue from the beginning to the end of the period. We consider billings to be a useful metric for management and investors because billings drive current and future revenue, which is an important indicator of the health and viability of our business.

[0001262039-23-000021:mdna:105]
There are several limitations related to the use of billings instead of GAAP revenue. First, billings include amounts that have not yet been recognized as revenue and are impacted by the term of FortiGuard security subscription and FortiCare technical support agreements. Second, we may calculate billings in a manner that is different from peer companies that report similar financial measures. Management accounts for these limitations by providing specific information regarding GAAP revenue and evaluating billings together with GAAP revenue. Total billings were $1.50 billion for the three months ended March 31, 2023, an increase of 30% compared to $1.16 billion in the same period last year.

[0001262039-23-000021:mdna:106]
Our backlog increased during past quarters and, now that supply chain shortages are lessening to some extent, as we fulfill, ship and bill during a quarter based in part on backlog from sales in earlier quarters, this may increase our aggregate billings and revenue during any particular quarter such that any decrease in growth or negative growth of in-quarter billings and revenue may not be reflected by our aggregate billings and revenue.

[0001262039-23-000021:mdna:107]
[same as prior period, unchanged from 0001262039-22-000038:mdna:85]

[0001262039-23-000021:mdna:108]
|  | Three Months Ended |
|  | March 31, 2023 |  | March 31, 2022 |
|  | (in millions) |
| Billings: |  |  |  |
| Revenue | $ | 1,262.3 |  |  | $ | 954.8 |  |
| Add: Change in deferred revenue | 240.6 |  |  | 205.0 |  |
| Total billings (non-GAAP) | $ | 1,502.9 |  |  | $ | 1,159.8 |  |

[0001262039-23-000021:mdna:109]
Free cash flow (non-GAAP). We define free cash flow as net cash provided by operating activities minus purchases of property and equipment and excluding any significant non-recurring items. We believe free cash flow to be a liquidity measure that provides useful information to management and investors about the amount of cash generated by the business that, after capital expenditures, can be used for strategic opportunities, including repurchasing outstanding common stock, investing in our business, making strategic acquisitions, and strengthening the balance sheet. A limitation of using free cash flow rather than the GAAP measures of cash provided by or used in operating activities, investing activities, and financing activities is that free cash flow does not represent the total increase or decrease in the cash and cash equivalents balance for the period because it excludes cash flows from investing activities other than capital expenditures and cash flows from financing activities. Management accounts for this limitation by providing information about our capital expenditures and other investing and financing activities on the consolidated statements of cash flows and under “—Liquidity and Capital Resources” and by presenting cash flows from investing and financing activities in our reconciliation of free cash flow. In addition, it is important to note that other companies, including companies in our industry, may not use free cash flow, may calculate free cash flow in a different manner than we do or may use other financial measures to evaluate their performance, all of which could reduce the usefulness of free cash flow as a comparative measure. A reconciliation of net cash provided by operating activities, the most directly comparable financial measure calculated and presented in accordance with GAAP, to free cash flow is provided below:

[0001262039-23-000021:mdna:110]
|  | Three Months Ended |
|  | March 31, 2023 |  | March 31, 2022 |
|  | (in millions) |
| Free Cash Flow: |  |  |  |
| Net cash provided by operating activities | $ | 677.5 |  |  | $ | 396.1 |  |
| Less: Purchases of property and equipment | (30.3) |  |  | (122.6) |  |
| Free cash flow (non-GAAP) | $ | 647.2 |  |  | $ | 273.5 |  |
| Net cash used in investing activities | $ | (42.4) |  |  | $ | (45.4) |  |
| Net cash used in financing activities | $ | (13.7) |  |  | $ | (746.0) |  |

[0001262039-23-000021:mdna:111]
[same as prior period, unchanged from 0001262039-22-000038:mdna:91]

[0001262039-23-000021:mdna:112]
Our discussion and analysis of our financial condition and results of operations are based upon our financial statements, which have been prepared in accordance with GAAP. These principles require us to make estimates and judgments that affect the reported amounts of assets, liabilities, revenue, cost of revenue and expenses, and related disclosures. We base our estimates on historical experience and on various other assumptions that we believe to be reasonable under the

[0001262039-23-000021:mdna:113]
[same as prior period, unchanged from 0001262039-22-000038:mdna:57]

[0001262039-23-000021:mdna:114]
circumstances. To the extent that there are material differences between these estimates and our actual results, our future financial statements will be affected.

[0001262039-23-000021:mdna:115]
There were no material changes to our critical accounting policies and estimates as of and for the three ended March 31, 2023, as compared to the critical accounting policies and estimates described in our Annual Report on Form 10-K filed with the SEC on February 24, 2023 (the “Form 10-K”).

[0001262039-23-000021:mdna:116]
[same as prior period, unchanged from 0001262039-22-000038:mdna:94]

[0001262039-23-000021:mdna:117]
[same as prior period, unchanged from 0001262039-22-000038:mdna:98]

[0001262039-23-000021:mdna:118]
Three Months Ended March 31, 2023 and 2022

[0001262039-23-000021:mdna:119]
[same as prior period, unchanged from 0001262039-22-000038:mdna:100]

[0001262039-23-000021:mdna:120]
|  | Three Months Ended |  |  |  |  |
| March 31,2023 |  | March 31,2022 |  |  |  |  |
| Amount |  | % ofRevenue |  | Amount |  | % ofRevenue |  | Change |  | % Change |
| (in millions, except percentages) |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 500.7 |  |  | 40 | % |  | $ | 371.0 |  |  | 39 | % |  | $ | 129.7 |  |  | 35 | % |
| Service | 761.6 |  |  | 60 |  |  | 583.8 |  |  | 61 |  |  | 177.8 |  |  | 30 |  |
| Total revenue | $ | 1,262.3 |  |  | 100 | % |  | $ | 954.8 |  |  | 100 | % |  | $ | 307.5 |  |  | 32 | % |
| Revenue by geography: |  |  |  |  |  |  |  |  |  |  |  |
| Americas | $ | 523.5 |  |  | 41 | % |  | $ | 382.6 |  |  | 40 | % |  | $ | 140.9 |  |  | 37 | % |
| EMEA | 478.2 |  |  | 38 |  |  | 346.0 |  |  | 36 |  |  | 132.2 |  |  | 38 |  |
| APAC | 260.6 |  |  | 21 |  |  | 226.2 |  |  | 24 |  |  | 34.4 |  |  | 15 |  |
| Total revenue | $ | 1,262.3 |  |  | 100 | % |  | $ | 954.8 |  |  | 100 | % |  | $ | 307.5 |  |  | 32 | % |

[0001262039-23-000021:mdna:121]
Total revenue increased $307.5 million, or 32%, during the three months ended March 31, 2023 compared to the same period last year. We continued to experience significant organic revenue growth (i.e., revenue growth excluding attribution from recent acquisitions) with diversification of revenue geographically, and across both customers and industries. Revenue from all regions grew, with the Americas contributing the largest portion of the increase on an absolute dollar basis and EMEA contributing the largest portion of the increase on a percentage basis.

[0001262039-23-000021:mdna:122]
Product revenue increased $129.7 million, or 35%, during the three months ended March 31, 2023 compared to the same period last year. Product revenue growth was consistent with an elevated cyber threat landscape, the convergence of security and networking and included the benefit of certain pricing actions, improving supply chain dynamics and changes in the backlog balance. The product revenue growth was primarily due to strong growth across many of our Enhanced Platform Technology products, including our secure access products. In addition, our product revenue growth was driven by a strong demand for the wide range of operating system capabilities embedded in our Core Platform products, including Secure SD-WAN and OT solutions.

[0001262039-23-000021:mdna:123]
Service revenue increased $177.8 million, or 30%, during the three months ended March 31, 2023 compared to the same period last year. FortiGuard and other security subscription revenue increased $108.8 million, or 35%, and FortiCare technical support and other services revenue increased $69.0 million, or 25%, during the three months ended March 31, 2023 compared to the same period last year. The increases were primarily due to pricing actions in prior periods and the recognition of revenue from our growing deferred revenue balance related to FortiGuard and other security subscriptions delivered to on-premise and cloud-based environments as well as FortiCare technical support and other services. FortiGuard outpaced FortiCare’s growth due to expansion of security subscription service offerings and FortiCare was impacted by decelerating service revenue contribution of Alaxala.

[0001262039-23-000021:mdna:124]
Of the service revenue recognized during the three months ended March 31, 2023 and 2022, 89% and 87% were included in the deferred revenue balance as of December 31, 2022 and 2021, respectively. We expect service revenue growth will continue to benefit from previous pricing actions. However, there are risks to service revenue growth rates, including customers reducing their spending, pricing actions, supply chain constraints, customers taking longer to buy their service, or other reasons.

[0001262039-23-000021:mdna:125]
[same as prior period, unchanged from 0001262039-22-000038:mdna:106]

[0001262039-23-000021:mdna:126]
|  | Three Months Ended |  |  |  |  |
| March 31,2023 |  | March 31,2022 |  | Change |  | % Change |
| (in millions, except percentages) |
| Cost of revenue: |  |  |  |  |  |  |  |
| Product | $ | 193.6 |  |  | $ | 161.0 |  |  | $ | 32.6 |  |  | 20 | % |
| Service | 114.2 |  |  | 92.8 |  |  | 21.4 |  |  | 23 |  |
| Total cost of revenue | $ | 307.8 |  |  | $ | 253.8 |  |  | $ | 54.0 |  |  | 21 | % |
| Gross margin (%): |  |  |  |  |  |  |  |
| Product | 61.3 | % |  | 56.6 | % |  |  |  |  |
| Service | 85.0 |  |  | 84.1 |  |  |  |  |  |
| Total gross margin | 75.6 | % |  | 73.4 | % |  |  |  |  |

[0001262039-23-000021:mdna:127]
Total gross margin increased 2.2 percentage points during the three months ended March 31, 2023 compared to the same period last year, primarily driven by increased product gross margin and increased service gross margin. Revenue mix shifted 0.8 percentage points from service revenue to product revenue, as a percentage of total revenue.

[0001262039-23-000021:mdna:128]
Product gross margin increased 4.7 percentage points during the three months ended March 31, 2023 compared to the same period last year. The increase in product margin was primarily driven by higher average selling prices, improved discounting, lower freight costs, expedite fees and other product costs and partially offset by higher inventory related cost. Cost of product revenue was comprised primarily of third-party contract manufacturers’ costs and the costs of materials used in production.

[0001262039-23-000021:mdna:129]
Service gross margin increased 0.9 percentage points during the three months ended March 31, 2023 compared to the same period last year. Cost of service revenue was comprised primarily of personnel and data center costs. The increase in service gross margin was primarily driven by pricing actions in earlier periods and the favorable impact of foreign currency fluctuations, partially offset by our data center and points-of-presence expansion and increased labor cost.

[0001262039-23-000021:mdna:130]
[same as prior period, unchanged from 0001262039-22-000038:mdna:80]

[0001262039-23-000021:mdna:131]
[same as prior period, unchanged from 0001262039-22-000038:mdna:111]

[0001262039-23-000021:mdna:132]
|  | Three Months Ended |  | Change |  | % Change |
| March 31,2023 |  | March 31,2022 |  |
| Amount |  | % ofRevenue |  | Amount |  | % ofRevenue |  |
| (in millions, except percentages) |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | $ | 151.1 |  |  | 12 | % |  | $ | 124.9 |  |  | 13 | % |  | $ | 26.2 |  |  | 21 | % |
| Sales and marketing | 478.3 |  |  | 38 |  |  | 387.6 |  |  | 41 |  |  | 90.7 |  |  | 23 |  |
| General and administrative | 52.8 |  |  | 4 |  |  | 38.6 |  |  | 4 |  |  | 14.2 |  |  | 37 |  |
| Gain on IP matter | (1.2) |  |  | — |  |  | (1.1) |  |  | — |  |  | (0.1) |  |  | 9 |  |
| Total operating expenses | $ | 681.0 |  |  | 54 | % |  | $ | 550.0 |  |  | 58 | % |  | $ | 131.0 |  |  | 24 | % |

[0001262039-23-000021:mdna:133]
[same as prior period, unchanged from 0001262039-22-000038:mdna:113]

[0001262039-23-000021:mdna:134]
Research and development expense increased $26.2 million, or 21%, during the three months ended March 31, 2023 compared to the same period last year, primarily due to a $19.6 million increase in personnel-related costs as a result of increased headcount to support the development of new products and continued enhancements to our existing products. In addition, we incurred an increase of $5.4 million of product development costs, such as third-party testing and prototypes, partially offset by the favorable impact of foreign currency fluctuations. We currently intend to continue to invest in our research and development organization, and expect research and development expense to increase in absolute dollars during the remainder of 2023.

[0001262039-23-000021:mdna:135]
[same as prior period, unchanged from 0001262039-22-000038:mdna:115]

[0001262039-23-000021:mdna:136]
Sales and marketing expense increased $90.7 million, or 23%, during the three months ended March 31, 2023 compared to the same period last year, primarily due to a $66.8 million increase in personnel-related costs as we increased our sales capacity. The increase in headcount is expected to help drive global market revenue increases. In addition, we incurred increases in travel expense of $8.3 million, marketing-related expense of $8.0 million and depreciation and other occupancy expense of $4.9 million, partially offset by the favorable impact of foreign currency fluctuations. We currently intend to continue to make investments in sales and marketing resources, which are critical to support our future growth, and expect sales and marketing expense to increase in absolute dollars during the remainder of 2023.

[0001262039-23-000021:mdna:137]
[same as prior period, unchanged from 0001262039-22-000038:mdna:117]

[0001262039-23-000021:mdna:138]
General and administrative expense increased $14.2 million, or 37%, during the three months ended March 31, 2023 compared to the same period last year, primarily due to an increase of $5.4 million in legal and other professional service fees, $4.3 million in personnel-related costs and an increase of $2.9 million in provision for expected credit losses. We currently expect general and administrative expense to increase in absolute dollars during the remainder of 2023.

[0001262039-23-000021:mdna:139]
[same as prior period, unchanged from 0001262039-22-000038:mdna:119]

[0001262039-23-000021:mdna:140]
We generated operating income of $273.5 million during the three months ended March 31, 2023, an increase of $122.5 million, or 81%, compared to $151.0 million in the same period last year. Operating income as a percentage of revenue was 21.7% during the three months ended March 31, 2023, compared to 15.8% in the same period last year. The increase in operating margin primarily benefits from 2.2 percentage points increase in gross margin, 2.7 percentage points and 1.1 percentage points decreases in sales and marketing expense and research and development expense as a percentage of revenue, respectively.

[0001262039-23-000021:mdna:141]
Interest income, interest expense and other income (expense)—net

[0001262039-23-000021:mdna:142]
|  | Three Months Ended |  |  |  |  |
| March 31,2023 |  | March 31,2022 |  | Change |  | % Change |
| (in millions, except percentages) |
| Interest income | $ | 20.6 |  |  | $ | 1.3 |  |  | $ | 19.3 |  |  | 1,485 | % |
| Interest expense | $ | (5.0) |  |  | $ | (4.5) |  |  | $ | (0.5) |  |  | 11 | % |
| Other income (expense)—net | $ | 2.0 |  |  | $ | (9.1) |  |  | $ | 11.1 |  |  | (122) | % |

[0001262039-23-000021:mdna:143]
Interest income increased $19.3 million during the three months ended March 31, 2023 compared to the same period last year, as a result of higher interest rates. Interest income varies depending on our average investment balances during the period, types and mix of investments, and market interest rates. Interest expense remained comparatively flat during the three months ended March 31, 2023 compared to the same period last year. The $11.1 million increase in Other income (expense)—net during the three months ended March 31, 2023 compared to the same period last year, was primarily due to an increase of $6.8 million gain on marketable equity securities and a $4.9 million increase in foreign currency exchange gains.

[0001262039-23-000021:mdna:144]
[same as prior period, unchanged from 0001262039-22-000038:mdna:124]

[0001262039-23-000021:mdna:145]
|  | Three Months Ended |  | Change |  | % Change |
| March 31,2023 |  | March 31,2022 |  |
| (in millions, except percentages) |
| Provision for (benefit from) income taxes | $ | 21.3 |  |  | $ | (8.1) |  |  | $ | 29.4 |  |  | (363) | % |
| Effective tax rate (%) | 7 | % |  | (6) | % |  |  |  |  |

[0001262039-23-000021:mdna:146]
Our effective tax rate was 7% for the three months ended March 31, 2023 compared to an effective tax rate of negative 6% for the same period last year. The provision for income taxes for the three months ended March 31, 2023 was primarily comprised of U.S. federal and state taxes, withholding taxes and foreign taxes totaling $85.8 million, which were favorably affected by a tax benefit of $38.2 million from the foreign-derived intangible income deduction (the “FDII deduction”) and excess tax benefits from stock-based compensation expense of $26.3 million.

[0001262039-23-000021:mdna:147]
The benefit from income taxes for the three months ended March 31, 2022 was comprised of U.S. federal and state taxes, withholding taxes, and foreign taxes totaling $38.5 million, more than offset by a tax benefit of $14.4 million from the FDII deduction and excess tax benefits from stock-based compensation expense of $32.2 million.

[0001262039-23-000021:mdna:148]
Loss from Equity Method Investment

[0001262039-23-000021:mdna:149]
|  | Three Months Ended |  | Change |  | % Change |
| March 31,2023 |  | March 31,2022 |  |
| (in millions, except percentages) |
| Loss from equity method investment | $ | (22.1) |  |  | $ | (8.5) |  |  | $ | (13.6) |  |  | 160 | % |

[0001262039-23-000021:mdna:150]
Loss from equity method investment increased by $13.6 million during the three months ended March 31, 2023 compared to the same period last year, due to the increase in our proportionate share of loss of Linksys’ financial results as well as our share of the amortization of the basis differences.

[0001262039-23-000021:mdna:151]
[same as prior period, unchanged from 0001262039-22-000038:mdna:162]

[0001262039-23-000021:mdna:152]
|  | As of |
|  | March 31,2023 |  | December 31,2022 |
|  | (in millions) |
| Cash and cash equivalents | $ | 2,304.2 |  |  | $ | 1,682.9 |  |
| Short-term and long-term investments | 564.4 |  |  | 548.1 |  |
| Marketable equity securities | 26.1 |  |  | 25.5 |  |
| Total cash, cash equivalents, investments and marketable equity securities | $ | 2,894.7 |  |  | $ | 2,256.5 |  |
| Working capital | $ | 1,096.9 |  |  | $ | 732.0 |  |
|  | Three Months Ended |
|  | March 31,2023 |  | March 31,2022 |
|  | (in millions) |
| Net cash provided by operating activities | $ | 677.5 |  |  | $ | 396.1 |  |
| Net cash used in investing activities | (42.4) |  |  | (45.4) |  |
| Net cash used in financing activities | (13.7) |  |  | (746.0) |  |
| Effect of exchange rate changes on cash and cash equivalents | (0.1) |  |  | (0.3) |  |
| Net increase (decrease) in cash and cash equivalents | $ | 621.3 |  |  | $ | (395.6) |  |

[0001262039-23-000021:mdna:153]
Liquidity and capital resources are primarily impacted by our operating activities, as well as payment of taxes in connection with the net settlement of equity awards, real estate and other capital expenditures, proceeds from the issuance of common stock and cash used for stock repurchases.

[0001262039-23-000021:mdna:154]
In recent years, we have received significant capital resources from our billings to customers, issuance of investment grade debt and, to some extent, from the exercise of stock options by our employees. Additional increases in billings may depend on a number of factors, including demand for and availability of our products and services, competition, pricing actions, market or industry changes, macroeconomic events such as rising inflation and interest rates, economic strength, supply chain capacity and disruptions, international conflicts, including the war in Ukraine, and our ability to execute. We expect proceeds from the exercise of stock options in future years to be impacted by the increased mix of restricted stock units and performance stock units versus stock options granted to our employees and to vary based on our share price.

[0001262039-23-000021:mdna:155]
In February 2023, our board of directors approved an extension of the Repurchase Program to February 29, 2024. Under the Repurchase Program, the aggregate amount authorized to repurchase our outstanding common stock was $5.25 billion. There were no shares repurchased under the Repurchase Program during the three months ended March 31, 2023. In April 2023, our board of directors approved a $1.00 billion increase in the authorized stock repurchase amount under the Repurchase Program, bringing the aggregate amount authorized to be repurchased to $6.25 billion through February 29, 2024. As of May 8, 2023, approximately $1.53 billion remained available for future share repurchases.

[0001262039-23-000021:mdna:156]
We expect to continue to increase our data center, office and warehouse capacity to support growth and the expansion of existing services or introduction of new services. As we purchase new properties, we will work to incorporate these properties into the environmental goals we have established. We estimate capital expenditures to be between approximately $400 million and $450 million in 2023.

[0001262039-23-000021:mdna:157]
We believe that our cash provided by operating activities, together with our existing cash, cash equivalents and investments will be sufficient to meet our anticipated cash needs and do not currently intend to retire our Senior Notes early. Refer to Note 10, Debt, in Part I, Item 1 of this Quarterly Report on Form 10-Q for information on the Senior Notes. As of March 31, 2023, the long-term debt, net of unamortized discount and debt issuance costs, was $990.9 million.

[0001262039-23-000021:mdna:158]
We enter into non-cancellable agreements with contract manufacturers and certain component suppliers to procure inventory based on our requirements in order to negotiate manufacturing lead times and encourage and incentivize vendors to deliver components and finished goods. In certain instances, these agreements allow us the option to reschedule and adjust our requirements based on our business needs prior to firm orders being placed. These purchase commitments as of March 31, 2023 totaled $1.20 billion, a decrease of $133.0 million compared to $1.34 billion as of December 31, 2022 due to fulfillment of customer demand as our supply availability improved and our continued efforts to work with contract manufacturers and suppliers to optimize our inventory and purchase commitment position. We increased our purchase commitments in prior years

[0001262039-23-000021:mdna:159]
35

[0001262039-23-000021:mdna:160]
to address significant supply constraints seen industry-wide due to component shortages. Our agreements secured supply and pricing for certain product components commitments with contract manufacturers to meet customer demand and to address extended lead times. We also have open purchase orders and contractual obligations in the ordinary course of business for which we have not received goods or services. As of March 31, 2023, we had $100.1 million in other contractual commitments having a remaining term in excess of one year that are non-cancelable.

[0001262039-23-000021:mdna:161]
There have been no significant changes to our leases as disclosed in our Annual Report on Form 10-K for the year ended December 31, 2022.

[0001262039-23-000021:mdna:162]
As of March 31, 2023, our cash, cash equivalents, short-term and long-term investments of $2.87 billion were invested primarily in deposit accounts, money market funds, corporate debt securities, commercial paper, certificates of deposit and term deposits, U.S. government and agency securities and municipal bonds. It is our investment policy to invest excess cash in a manner that preserves capital, provides liquidity and generates return without significantly increasing risk. We do not enter into investments for trading or speculative purposes.

[0001262039-23-000021:mdna:163]
The amount of cash, cash equivalents and investments held by our international subsidiaries was $206.7 million as of March 31, 2023 and $218.1 million as of December 31, 2022.

[0001262039-23-000021:mdna:164]
We believe that our existing cash and cash equivalents and cash flow from operations will be sufficient for at least the next 12 months to meet our requirements and plans for cash, including meeting our working capital requirements and capital expenditure requirements. In the long term, our ability to support our requirements and plans for cash, including our working capital and capital expenditure requirements will depend on many factors, including our growth rate; the timing and amount of our share repurchases; the expansion of sales and marketing activities, pricing actions, the introduction of new and enhanced products and services offerings; the continuing market acceptance of our products; the timing and extent of spending to support development efforts; our investments in purchasing, developing or leasing real estate; cash tax payments and macroeconomic impacts such as rising inflation and interest rates; the war in Ukraine; instability in the global banking system and the COVID-19 pandemic. Historically, we have required capital principally to fund our working capital needs, share repurchases, capital expenditures and acquisition activities. In the event that additional financing is required from outside sources, we may not be able to raise it on terms acceptable to us or at all.

[0001262039-23-000021:mdna:165]
As of March 31, 2023, we did not have any relationships with unconsolidated organizations or financial partnerships, such as structured finance or special purpose entities that would have been established for the purpose of facilitating off-balance sheet arrangements or other contractually narrow or limited purposes.

[0001262039-23-000021:mdna:166]
[same as prior period, unchanged from 0001262039-22-000038:mdna:178]

[0001262039-23-000021:mdna:167]
Cash generated by operating activities is our primary source of liquidity. It is primarily comprised of net income, as adjusted for non-cash items and changes in operating assets and liabilities. Non-cash adjustments consist primarily of amortization of deferred contract costs, stock-based compensation and depreciation and amortization. Changes in operating assets and liabilities consist primarily of changes in deferred revenue, accounts receivable, net, deferred contract costs and deferred tax assets.

[0001262039-23-000021:mdna:168]
Our operating activities during the three months ended March 31, 2023 provided cash flows of $677.5 million, an increase of $281.4 million compared to the same period last year, as a result of the continued growth of our business, improved profitability and our ability to successfully manage our working capital. Changes in operating assets and liabilities primarily resulted from an increase in sales of our FortiGuard and other security subscription services and FortiCare technical support services to new and existing customers, as reflected by an increase of $240.7 million in our deferred revenue during the three months ended March 31, 2023.

[0001262039-23-000021:mdna:169]
[same as prior period, unchanged from 0001262039-22-000038:mdna:181]

[0001262039-23-000021:mdna:170]
The changes in cash flows from investing activities primarily relate to timing of purchases, maturities and sales of investments and purchases of property and equipment. Historically, in making a lease-versus-ownership decision related to warehouse, office or data space, we have considered various factors including financial metrics, expected long-term growth rates and changes in asset values. In certain cases, we have elected to own a facility if we believe that purchasing or developing buildings rather than leasing is more closely aligned with our long-term strategy. We expect to make similar decisions in the future. We may also make cash payments in connection with future business combinations.

[0001262039-23-000021:mdna:171]
36

[0001262039-23-000021:mdna:172]
During the three months ended March 31, 2023, cash used in investing activities was $42.4 million, driven by $30.3 million of purchases of property and equipment and $12.2 million spent for purchases of investment, net of maturities and sales of investments.

[0001262039-23-000021:mdna:173]
[same as prior period, unchanged from 0001262039-22-000038:mdna:185]

[0001262039-23-000021:mdna:174]
The changes in cash flows from financing activities primarily relate to repurchase and retirement of common stock, and taxes paid related to net share settlement of equity awards, net of proceeds from the issuance of common stock under the Amended and Restated Fortinet, Inc. 2009 Equity Incentive Plan.

[0001262039-23-000021:mdna:175]
During the three months ended March 31, 2023, cash used in financing activities was $13.7 million, primarily driven by $13.3 million used to pay tax withholding, net of proceeds from the issuance of common stock.
