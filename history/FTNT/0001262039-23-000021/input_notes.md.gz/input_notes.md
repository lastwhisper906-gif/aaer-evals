# FTNT notes — 0001262039-23-000021


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001262039-23-000021:notes:1]
SUMMARY OF SIGNIFICANT ACCOUNTING POLICIES
Basis of Presentation and Preparation—The unaudited condensed consolidated financial statements of Fortinet, Inc. and its subsidiaries (collectively, “we,” “us” or “our”) have been prepared in accordance with generally accepted accounting principles in the United States (“GAAP”) for interim financial information, as well as the instructions to Form 10-Q pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (the “SEC”). Accordingly, they do not include all of the information and footnotes required by GAAP for complete financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the year ended December 31, 2022, contained in our Annual Report on Form 10-K filed with the SEC on February 24, 2023. In the opinion of management, all adjustments, which include normal recurring adjustments, considered necessary for a fair presentation, have been included. The results of operations for the three months ended March 31, 2023 are not necessarily indicative of the results to be expected for the full year or for any future periods. The condensed consolidated balance sheet as of December 31, 2022 is derived from the audited consolidated financial statements for the year ended December 31, 2022.

[0001262039-23-000021:notes:2]
[same as prior period, unchanged from 0001262039-22-000038:notes:2]

[0001262039-23-000021:notes:3]
[same as prior period, unchanged from 0001262039-22-000038:notes:3]

[0001262039-23-000021:notes:4]
On April 14, 2022, our board of directors approved a five-for-one forward stock split of our common stock (the “Forward Stock Split”), which was conditioned upon obtaining stockholder approval for the Forward Stock Split, and to increase the number of our authorized shares of common stock. On June 17, 2022, at our 2022 Annual Meeting of Stockholders, our stockholders approved the Forward Stock Split and the amendment and restatement of our amended and restated certificate of incorporation to increase the number of authorized shares of common stock from 300.0 million to 1.5 billion. The par value of our common stock was not adjusted as a result of the Forward Stock Split. Effective June 22, 2022, we filed our amended and restated certification of incorporation and completed the Forward Stock Split. All share and per share amounts and related equity (deficit) balances presented herein have been retroactively adjusted to reflect the Forward Stock Split.

[0001262039-23-000021:notes:5]
There have been no material changes to our significant accounting policies as of and for the three months ended March 31, 2023, as compared to the significant accounting policies described in the Form 10-K.

[0001262039-23-000021:notes:6]
Recently Adopted and Recently Issued Accounting Standards

[0001262039-23-000021:notes:7]
There were no recently adopted accounting standards which would have a material effect on our condensed consolidated financial statements and accompanying disclosures, and no recently issued accounting standards that are expected to have a material impact on our condensed consolidated financial statements and accompanying disclosures.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001262039-23-000021:notes:8]
REVENUE RECOGNITION
Disaggregation of Revenue

[0001262039-23-000021:notes:9]
[same as prior period, unchanged from 0001262039-22-000038:notes:9]

[0001262039-23-000021:notes:10]
|  | Three Months Ended |  |  |
|  | March 31,2023 |  | March 31,2022 |  |  |  |  |
| Product | $ | 500.7 |  |  | $ | 371.0 |  |  |  |  |  |
| Service: |  |  |  |  |  |  |  |
| Security subscription | 421.7 |  |  | 312.9 |  |  |  |  |  |
| Technical support and other | 339.9 |  |  | 270.9 |  |  |  |  |  |
| Total service revenue | 761.6 |  |  | 583.8 |  |  |  |  |  |
| Total revenue | $ | 1,262.3 |  |  | $ | 954.8 |  |  |  |  |  |

[0001262039-23-000021:notes:11]
[same as prior period, unchanged from 0001262039-22-000038:notes:11]

[0001262039-23-000021:notes:12]
During the three months ended March 31, 2023 and 2022, we recognized $675.9 million and $507.3 million in service revenue that was included in the deferred revenue balance as of December 31, 2022 and 2021, respectively.

[0001262039-23-000021:notes:13]
[same as prior period, unchanged from 0001262039-22-000038:notes:13]

[0001262039-23-000021:notes:14]
As of March 31, 2023, the aggregate amount of the transaction price allocated to remaining performance obligations was $4.91 billion, which was substantially comprised of deferred security subscription, technical support services revenue and unbilled contract revenue from non-cancellable contracts that will be recognized in future periods. We expect to recognize approximately $2.49 billion as revenue over the next 12 months and the remainder thereafter.

[0001262039-23-000021:notes:15]
[same as prior period, unchanged from 0001262039-22-000038:notes:15]

[0001262039-23-000021:notes:16]
Trade accounts receivable are recorded at the invoiced amount, net of an allowance for expected credit losses. We measure expected credit losses of accounts receivable on a collective (pooled) basis, aggregating accounts receivable that are either current or no more than 60 days past due, and aggregating accounts receivable that are more than 60 days past due. We apply a credit-loss percentage to each of the pools that is based on our historical credit losses. We review whether each of our significant accounts receivable that is more than 60 days past due continues to exhibit similar risk characteristics with the other accounts receivable in the pool. If we determine that it does not, we evaluate it for expected credit losses on an individual basis. Expected credit losses are recorded as general and administrative expenses on our consolidated statements of income.

[0001262039-23-000021:notes:17]
The allowance for credit losses was $6.7 million and $3.6 million as of March 31, 2023 and December 31, 2022, respectively. Provisions, write-offs and recoveries were not material during the three months ended March 31, 2023 and 2022.

[0001262039-23-000021:notes:18]
[same as prior period, unchanged from 0001262039-22-000038:notes:18]

[0001262039-23-000021:notes:19]
Amortization of deferred contract costs during the three months ended March 31, 2023 and 2022 were $62.5 million and $52.5 million, respectively.


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0001262039-23-000021:notes:20]
[same as prior period, unchanged from 0001262039-22-000038:notes:20]

[0001262039-23-000021:notes:21]
[same as prior period, unchanged from 0001262039-22-000038:notes:21]

[0001262039-23-000021:notes:22]
|  | March 31, 2023 |
|  | AmortizedCost |  | UnrealizedGains |  | UnrealizedLosses |  | FairValue |
| U.S. government and agency securities | $ | 209.3 |  |  | $ | — |  |  | $ | (2.3) |  |  | $ | 207.0 |  |
| Corporate debt securities | 184.3 |  |  | — |  |  | (2.4) |  |  | 181.9 |  |
| Commercial paper | 165.2 |  |  | — |  |  | (0.1) |  |  | 165.1 |  |
| Certificates of deposit and term deposits | 5.4 |  |  | — |  |  | — |  |  | 5.4 |  |
| Municipal bonds | 5.1 |  |  | — |  |  | (0.1) |  |  | 5.0 |  |
| Total available-for-sale securities | $ | 569.3 |  |  | $ | — |  |  | $ | (4.9) |  |  | $ | 564.4 |  |

[0001262039-23-000021:notes:23]
|  | December 31, 2022 |
|  | AmortizedCost |  | UnrealizedGains |  | UnrealizedLosses |  | FairValue |
| U.S. government and agency securities | $ | 198.0 |  |  | $ | — |  |  | $ | (4.4) |  |  | $ | 193.6 |  |
| Corporate debt securities | 293.0 |  |  | — |  |  | (4.1) |  |  | 288.9 |  |
| Commercial paper | 26.5 |  |  | — |  |  | (0.1) |  |  | 26.4 |  |
| Certificates of deposit and term deposits | 34.2 |  |  | — |  |  | — |  |  | 34.2 |  |
| Municipal bonds | 5.1 |  |  | — |  |  | (0.1) |  |  | 5.0 |  |
| Total available-for-sale securities | $ | 556.8 |  |  | $ | — |  |  | $ | (8.7) |  |  | $ | 548.1 |  |

[0001262039-23-000021:notes:24]
[same as prior period, unchanged from 0001262039-22-000038:notes:24]

[0001262039-23-000021:notes:25]
|  | March 31, 2023 |
|  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
|  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |
| U.S. government and agency securities | $ | 13.9 |  |  | $ | (0.1) |  |  | $ | 148.8 |  |  | $ | (2.2) |  |  | $ | 162.7 |  |  | $ | (2.3) |  |
| Corporate debt securities | 13.4 |  |  | (0.1) |  |  | 161.6 |  |  | (2.3) |  |  | 175.0 |  |  | (2.4) |  |
| Commercial paper | 165.0 |  |  | (0.1) |  |  | — |  |  | — |  |  | 165.0 |  |  | (0.1) |  |
| Municipal bonds | 5.0 |  |  | (0.1) |  |  | — |  |  | — |  |  | 5.0 |  |  | (0.1) |  |
| Total available-for-sale securities | $ | 197.3 |  |  | $ | (0.4) |  |  | $ | 310.4 |  |  | $ | (4.5) |  |  | $ | 507.7 |  |  | $ | (4.9) |  |

[0001262039-23-000021:notes:26]
|  | December 31, 2022 |
|  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
|  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |
| U.S. government and agency securities | $ | 3.9 |  |  | $ | (0.1) |  |  | $ | 189.8 |  |  | $ | (4.3) |  |  | $ | 193.7 |  |  | $ | (4.4) |  |
| Corporate debt securities | 90.5 |  |  | (0.8) |  |  | 190.0 |  |  | (3.3) |  |  | 280.5 |  |  | (4.1) |  |
| Commercial paper | 26.4 |  |  | (0.1) |  |  | — |  |  | — |  |  | 26.4 |  |  | (0.1) |  |
| Municipal bonds | 5.0 |  |  | (0.1) |  |  | — |  |  | — |  |  | 5.0 |  |  | (0.1) |  |
| Total available-for-sale securities | $ | 125.8 |  |  | $ | (1.1) |  |  | $ | 379.8 |  |  | $ | (7.6) |  |  | $ | 505.6 |  |  | $ | (8.7) |  |

[0001262039-23-000021:notes:27]
The contractual maturities of our investments were (in millions):

[0001262039-23-000021:notes:28]
|  | March 31,2023 |  | December 31,2022 |
| Due within one year | $ | 548.8 |  |  | $ | 502.6 |  |
| Due within one to three years | 15.6 |  |  | 45.5 |  |
| Total | $ | 564.4 |  |  | $ | 548.1 |  |

[0001262039-23-000021:notes:29]
[same as prior period, unchanged from 0001262039-22-000038:notes:29]

[0001262039-23-000021:notes:30]
[same as prior period, unchanged from 0001262039-22-000038:notes:30]

[0001262039-23-000021:notes:31]
[same as prior period, unchanged from 0001262039-22-000038:notes:31]

[0001262039-23-000021:notes:32]
Our marketable equity securities were $26.1 million and $25.5 million as of March 31, 2023 and December 31, 2022. The changes in fair value of our marketable equity securities are recorded in other expense—net on the condensed consolidated statements of income. We recognized a $0.6 million gain and $6.2 million loss during the three months ended March 31, 2023 and 2022, respectively.

[0001262039-23-000021:notes:33]
[same as prior period, unchanged from 0001262039-22-000038:notes:33]

[0001262039-23-000021:notes:34]
Fair Value Accounting—We apply the following fair value hierarchy for disclosure of the inputs used to measure fair value. This hierarchy prioritizes the inputs into three broad levels:

[0001262039-23-000021:notes:35]
[same as prior period, unchanged from 0001262039-22-000038:notes:35]

[0001262039-23-000021:notes:36]
[same as prior period, unchanged from 0001262039-22-000038:notes:36]

[0001262039-23-000021:notes:37]
[same as prior period, unchanged from 0001262039-22-000038:notes:37]

[0001262039-23-000021:notes:38]
[same as prior period, unchanged from 0001262039-22-000038:notes:38]

[0001262039-23-000021:notes:39]
[same as prior period, unchanged from 0001262039-22-000038:notes:39]

[0001262039-23-000021:notes:40]
[same as prior period, unchanged from 0001262039-22-000038:notes:40]

[0001262039-23-000021:notes:41]
[same as prior period, unchanged from 0001262039-22-000038:notes:41]

[0001262039-23-000021:notes:42]
[same as prior period, unchanged from 0001262039-22-000038:notes:42]

[0001262039-23-000021:notes:43]
|  | March 31, 2023 |  | December 31, 2022 |
|  | AggregateFairValue |  | QuotedPrices inActiveMarkets ForIdenticalAssets |  | SignificantOtherObservableRemainingInputs |  | SignificantOtherUnobservableRemainingInputs |  | AggregateFairValue |  | QuotedPrices inActiveMarkets ForIdenticalAssets |  | SignificantOtherObservableRemainingInputs |  | SignificantOtherUnobservableRemainingInputs |
|  |  |  | (Level 1) |  | (Level 2) |  | (Level 3) |  |  |  | (Level 1) |  | (Level 2) |  | (Level 3) |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. government and agency securities | $ | 396.1 |  |  | $ | 351.8 |  |  | $ | 44.3 |  |  | $ | — |  |  | $ | 268.6 |  |  | $ | 259.3 |  |  | $ | 9.3 |  |  | $ | — |  |
| Corporate debt securities | 181.9 |  |  | — |  |  | 181.9 |  |  | — |  |  | 288.9 |  |  | — |  |  | 288.9 |  |  | — |  |
| Commercial paper | 320.8 |  |  | — |  |  | 320.8 |  |  | — |  |  | 115.8 |  |  | — |  |  | 115.8 |  |  | — |  |
| Certificates of deposit and term deposits | 45.3 |  |  | — |  |  | 45.3 |  |  | — |  |  | 50.4 |  |  | — |  |  | 50.4 |  |  | — |  |
| Money market funds | 447.4 |  |  | 447.4 |  |  | — |  |  | — |  |  | 593.9 |  |  | 593.9 |  |  | — |  |  | — |  |
| Municipal bonds | 5.0 |  |  | — |  |  | 5.0 |  |  | — |  |  | 5.0 |  |  | — |  |  | 5.0 |  |  | — |  |
| Marketable equity securities | 26.1 |  |  | 26.1 |  |  | — |  |  | — |  |  | 25.5 |  |  | 25.5 |  |  | — |  |  | — |  |
| Total | $ | 1,422.6 |  |  | $ | 825.3 |  |  | $ | 597.3 |  |  | $ | — |  |  | $ | 1,348.1 |  |  | $ | 878.7 |  |  | $ | 469.4 |  |  | $ | — |  |
| Reported as: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents | $ | 832.1 |  |  |  |  |  |  |  |  | $ | 774.5 |  |  |  |  |  |  |  |
| Marketable equity securities | 26.1 |  |  |  |  |  |  |  |  | 25.5 |  |  |  |  |  |  |  |
| Short-term investments | 548.8 |  |  |  |  |  |  |  |  | 502.6 |  |  |  |  |  |  |  |
| Long-term investments | 15.6 |  |  |  |  |  |  |  |  | 45.5 |  |  |  |  |  |  |  |
| Total | $ | 1,422.6 |  |  |  |  |  |  |  |  | $ | 1,348.1 |  |  |  |  |  |  |  |

[0001262039-23-000021:notes:44]
There were no transfers between Level 1 and Level 2 of the fair value hierarchy during the three months ended March 31, 2023 and year ended December 31, 2022.


## us-gaap:InventoryDisclosureTextBlock

[0001262039-23-000021:notes:45]
INVENTORY
Inventory consisted of (in millions):

[0001262039-23-000021:notes:46]
|  | March 31,2023 |  | December 31,2022 |
| Raw materials | $ | 54.6 |  |  | $ | 46.3 |  |
| Work in process | 10.9 |  |  | 12.0 |  |
| Finished goods | 237.2 |  |  | 206.3 |  |
| Inventory | $ | 302.7 |  |  | $ | 264.6 |  |


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001262039-23-000021:notes:47]
PROPERTY AND EQUIPMENT—Net
Property and equipment—net consisted of (in millions):

[0001262039-23-000021:notes:48]
|  | March 31,2023 |  | December 31,2022 |
| Land | $ | 323.6 |  |  | $ | 310.0 |  |
| Buildings and improvements | 506.3 |  |  | 490.3 |  |
| Computer equipment and software | 230.2 |  |  | 222.7 |  |
| Leasehold improvements | 55.4 |  |  | 53.5 |  |
| Evaluation units | 23.6 |  |  | 19.2 |  |
| Furniture and fixtures | 32.0 |  |  | 31.3 |  |
| Construction-in-progress | 46.9 |  |  | 51.7 |  |
| Total property and equipment | 1,218.0 |  |  | 1,178.7 |  |
| Less: accumulated depreciation | (300.6) |  |  | (280.2) |  |
| Property and equipment—net | $ | 917.4 |  |  | $ | 898.5 |  |

[0001262039-23-000021:notes:49]
Depreciation expense was $22.8 million and $19.1 million during the three months ended March 31, 2023 and 2022, respectively.


## us-gaap:InvestmentTextBlock

[0001262039-23-000021:notes:50]
[same as prior period, unchanged from 0001262039-22-000038:notes:51]

[0001262039-23-000021:notes:51]
During 2021, we invested $160 million in cash for shares of the Series A Preferred Stock of privately held Linksys Holdings, Inc. (“Linksys”), representing a 50.8% ownership interest in the outstanding common stock (on an as-converted basis). Linksys provides router connectivity solutions to the consumer and small business markets.

[0001262039-23-000021:notes:52]
We have concluded that our investment in Linksys is an in-substance common stock investment and that we do not hold an absolute controlling financial interest in Linksys, but that we have the ability to exercise significant influence over the operating and financial policies of Linksys. Determining that we have significant influence but not control over the operating and financial policies of Linksys required significant judgement of many factors, including but not limited to the ownership interest in Linksys, board representation, participation in policy-making processes and participation rights in certain significant financial and operating decisions of Linksys in the ordinary course of business. Therefore, we determined to account for this investment using the equity method of accounting. We record our share of Linksys’ financial results on a three-month lag basis. We determined that there was a basis difference between the cost of our investment in Linksys and the amount of underlying equity in net assets of Linksys. Our share of loss of Linksys’ financial results, as well as our share of the amortization of the basis differences, in total was $22.1 million and $8.5 million for the three months ended March 31, 2023 and 2022, respectively, and has been recorded in loss from equity method investment on the condensed consolidated statements of income. As of March 31, 2023 and December 31, 2022, the investment was included in other assets on our condensed consolidated balance sheets. 
In the fourth quarter of 2022, we recorded a non-cash charge of $22.2 million related to other-than-temporary impairment (“OTTI”) recognized on our equity method investment in Linksys and our proportionate share of Linksys' financial results included a $17.5 million charge in connection with a valuation allowance established on deferred tax assets at Linksys. Due to the presence of impairment indicators, such as a series of operating losses, we evaluated our equity method investment for an OTTI during the three months ended March 31, 2023. We considered various factors in determining whether an OTTI has occurred, including the limited operating history available, our ability and intent to hold the investment until its fair value recovers, the implied revenue valuation multiples compared to guideline public companies, Linksys’ ability to achieve milestones and any notable operational and strategic changes. After the evaluation, we determined that an additional OTTI has not occurred as of March 31, 2023. However, we may be required to recognize an impairment loss in future reporting periods if and when our evaluation of the aforementioned factors indicates that the investment in Linksys is determined to be other than temporarily impaired. Such determination will be based on the prevailing facts and circumstances at that time, including the results and disclosures of Linksys.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001262039-23-000021:notes:53]
BUSINESS COMBINATIONSAlaxala Networks Corporation On August 31, 2021, we closed an acquisition of 75% of equity interests as controlling interests in Alaxala Networks Corporation (“Alaxala”), a privately held network hardware equipment company in Japan, for $64.2 million in cash. On October 3, 2022, we acquired the remaining 25% of equity interests in Alaxala for $13.5 million in cash, and Alaxala became our wholly owned subsidiary. We acquired the equity interests in Alaxala to broaden our offering of secure switches integrated with our Core Platform and Enhanced Platform Technology functionality, and over time, to innovate and rebrand certain of Alaxala’s switches to offer a broader suite of secure switches globally.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001262039-23-000021:notes:54]
[same as prior period, unchanged from 0001262039-22-000038:notes:71]

[0001262039-23-000021:notes:55]
[same as prior period, unchanged from 0001262039-22-000038:notes:72]

[0001262039-23-000021:notes:56]
|  | Amount |
| Balance—December 31, 2022 | $ | 128.0 |  |
| Foreign currency translation adjustments | (0.2) |  |
| Balance—March 31, 2023 | $ | 127.8 |  |

[0001262039-23-000021:notes:57]
There were no impairments to goodwill during the three months ended March 31, 2023 or during prior periods.

[0001262039-23-000021:notes:58]
[same as prior period, unchanged from 0001262039-22-000038:notes:75]

[0001262039-23-000021:notes:59]
[same as prior period, unchanged from 0001262039-22-000038:notes:76]

[0001262039-23-000021:notes:60]
|  | March 31, 2023 |
|  | Weighted-Average Useful Life (in Years) |  | Gross |  | Accumulated Amortization |  | Net |
| Other intangible assets—net: |  |  |  |  |  |  |  |
| Finite-lived intangible assets: |  |  |  |  |  |  |  |
| Developed technologies | 4.3 |  | $ | 84.8 |  |  | $ | 53.8 |  |  | $ | 31.0 |  |
| Customer relationships | 7.1 |  | 30.9 |  |  | 15.3 |  |  | 15.6 |  |
| Trade name | 10.0 |  | 5.3 |  |  | 0.8 |  |  | 4.5 |  |
| Backlog | 1.0 |  | 4.2 |  |  | 4.2 |  |  | — |  |
| Total other intangible assets—net |  |  | $ | 125.2 |  |  | $ | 74.1 |  |  | $ | 51.1 |  |

[0001262039-23-000021:notes:61]
|  | December 31, 2022 |
|  | Weighted-Average Useful Life (in Years) |  | Gross |  | Accumulated Amortization |  | Net |
| Other intangible assets—net: |  |  |  |  |  |  |  |
| Finite-lived intangible assets: |  |  |  |  |  |  |  |
| Developed technologies | 4.1 |  | $ | 85.1 |  |  | $ | 50.3 |  |  | $ | 34.8 |  |
| Customer relationships | 7.1 |  | 31.0 |  |  | 14.4 |  |  | 16.6 |  |
| Trade name | 10.0 |  | 5.3 |  |  | 0.7 |  |  | 4.6 |  |
| Backlog | 1.0 |  | 4.2 |  |  | 4.2 |  |  | — |  |
| Total other intangible assets—net |  |  | $ | 125.6 |  |  | $ | 69.6 |  |  | $ | 56.0 |  |

[0001262039-23-000021:notes:62]
Amortization expense was $4.7 million and $6.4 million during the three months ended March 31, 2023 and 2022, respectively.

[0001262039-23-000021:notes:63]
[same as prior period, unchanged from 0001262039-22-000038:notes:80]

[0001262039-23-000021:notes:64]
|  | Amount |
| Years: |  |
| 2023 (the remainder of 2023) | $ | 13.4 |  |
| 2024 | 13.5 |  |
| 2025 | 8.8 |  |
| 2026 | 4.3 |  |
| 2027 | 3.9 |  |
| Thereafter | 7.2 |  |
| Total | $ | 51.1 |  |


## us-gaap:EarningsPerShareTextBlock

[0001262039-23-000021:notes:65]
NET INCOME PER SHARE
Basic net income per share is computed by dividing net income attributable to Fortinet, Inc., by the weighted-average number of shares of common stock outstanding during the period. Diluted net income per share is computed by dividing net income attributable to Fortinet, Inc. by the weighted-average number of shares of common stock outstanding during the period, plus the dilutive effects of restricted stock units (“RSUs”), stock options and performance stock units (“PSUs”). Dilutive shares of common stock are determined by applying the treasury stock method.

[0001262039-23-000021:notes:66]
A reconciliation of the numerator and denominator used in the calculation of basic and diluted net income per share attributable to Fortinet, Inc. is (in millions, except per share amounts):

[0001262039-23-000021:notes:67]
|  | Three Months Ended |  |  |
|  | March 31,2023 |  | March 31,2022 |  |  |  |  |
| Numerator: |  |  |  |  |  |  |  |
| Net income including non-controlling interests | $ | 247.7 |  |  | $ | 138.3 |  |  |  |  |  |
| Net loss attributable to non-controlling interests | — |  |  | (0.1) |  |  |  |  |  |
| Net income attributable to Fortinet, Inc. | $ | 247.7 |  |  | $ | 138.4 |  |  |  |  |  |
| Denominator: |  |  |  |  |  |  |  |
| Basic shares: |  |  |  |  |  |  |  |
| Weighted-average common stock outstanding-basic | 783.2 |  |  | 803.4 |  |  |  |  |  |
| Diluted shares: |  |  |  |  |  |  |  |
| Weighted-average common stock outstanding-basic | 783.2 |  |  | 803.4 |  |  |  |  |  |
| Effect of potentially dilutive securities: |  |  |  |  |  |  |  |
| RSUs | 3.6 |  |  | 8.6 |  |  |  |  |  |
| Stock options | 6.6 |  |  | 8.8 |  |  |  |  |  |
| Weighted-average shares used to compute diluted net income per share attributable to Fortinet, Inc. | 793.4 |  |  | 820.8 |  |  |  |  |  |
| Net income per share attributable to Fortinet, Inc.: |  |  |  |  |  |  |  |
| Basic | $ | 0.32 |  |  | $ | 0.17 |  |  |  |  |  |
| Diluted | $ | 0.31 |  |  | $ | 0.17 |  |  |  |  |  |

[0001262039-23-000021:notes:68]
[same as prior period, unchanged from 0001262039-22-000038:notes:85]

[0001262039-23-000021:notes:69]
|  | Three Months Ended |  |  |
|  | March 31,2023 |  | March 31,2022 |  |  |  |  |
| RSUs | 1.8 |  |  | 0.4 |  |  |  |  |  |
| Stock options | 2.3 |  |  | 0.9 |  |  |  |  |  |
| Total | 4.1 |  |  | 1.3 |  |  |  |  |  |


## us-gaap:DebtDisclosureTextBlock

[0001262039-23-000021:notes:70]
DEBT
2026 and 2031 Senior Notes

[0001262039-23-000021:notes:71]
On March 5, 2021, we issued $1.0 billion aggregate principal amount of senior notes (collectively, the “Senior Notes”), consisting of $500.0 million aggregate principal amount of 1.0% notes due March 15, 2026 (the “2026 Senior Notes”) and $500.0 million aggregate principal amount of 2.2% notes due March 15, 2031 (the “2031 Senior Notes”), in an underwritten registered public offering. The Senior Notes are senior unsecured obligations and rank equally with each other in right of payment and with our other outstanding obligations. We may redeem the Senior Notes at any time in whole or in part for cash, at specified redemption prices that include accrued and unpaid interest, if any, and a make-whole premium. However, no make-whole premium will be paid for redemptions of the 2026 Senior Notes on or after February 15, 2026, or the 2031 Senior Notes on or after December 15, 2030. Interest on the Senior Notes is payable on March 15 and September 15 of each year, beginning on September 15, 2021. As of March 31, 2023 and December 31, 2022, the Senior Notes were recorded as long-term debt, net of discount and issuance costs, which are amortized to interest expense over the respective contractual terms of these notes using the effective interest method.

[0001262039-23-000021:notes:72]
The total outstanding debt is summarized below (in millions, except percentages):

[0001262039-23-000021:notes:73]
|  | Maturity |  | Coupon Rate |  | Effective Interest Rate |  | March 31,2023 |  | December 31,2022 |
| Debt |  |  |  |  |  |  |  |  |  |
| 2026 Senior Notes | March 2026 |  | 1.0% |  | 1.3% |  | $ | 500.0 |  |  | $ | 500.0 |  |
| 2031 Senior Notes | March 2031 |  | 2.2% |  | 2.3% |  | 500.0 |  |  | 500.0 |  |
| Total debt |  |  |  |  |  |  | 1,000.0 |  |  | 1,000.0 |  |
| Less: Unamortized discount and debt issuance costs |  |  |  |  |  |  | 9.1 |  |  | 9.6 |  |
| Total long-term debt |  |  |  |  |  |  | $ | 990.9 |  |  | $ | 990.4 |  |

[0001262039-23-000021:notes:74]
As of March 31, 2023 and December 31, 2022, we accrued interest payable of $0.7 million and $4.7 million, respectively, and there are no financial covenants with which we must comply. During the three months ended March 31, 2023 and 2022, we recorded $4.5 million of total interest expense in relation to these Senior Notes and repaid $8.0 million of interest in cash in each quarter. No interest costs were capitalized for the three months ended March 31, 2023 and 2022, as the costs that qualified for capitalization were not material.

[0001262039-23-000021:notes:75]
The total estimated fair value of the outstanding Senior Notes was approximately $867.7 million, including accrued and unpaid interest, as of March 31, 2023. The fair value was determined based on observable market prices of identical instruments in less active markets. The estimated fair values are based on Level 2 inputs.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001262039-23-000021:notes:76]
COMMITMENTS AND CONTINGENCIESThe following table summarizes our inventory purchase commitments as of March 31, 2023 (in millions):

[0001262039-23-000021:notes:77]
|  | Total |  | 2023 |  | Thereafter |
| Inventory purchase commitments | $ | 1,202.0 |  |  | $ | 1,135.7 |  |  | $ | 66.3 |  |

[0001262039-23-000021:notes:78]
Inventory Purchase Commitments—Our independent contract manufacturers and certain component suppliers procure components and build our products based on our forecasts, the availability of various components and their capacity. These forecasts are based on estimates of future demand for our products, which are in turn based on historical trends and an analysis from our sales and marketing organizations, adjusted for extended lead times, changes in supplier delivery commitments and other supply chain matters and market conditions. In order to manage manufacturing lead times, plan for adequate component supply and incentivize suppliers to deliver, we may issue purchase orders to some of our independent contract manufacturers, which are non-cancelable. As of March 31, 2023, we had $1.20 billion of open purchase orders with our independent contract manufacturers that consist of non-cancelable commitments. In certain instances, these agreements allow us the option to reschedule and adjust our requirements based on our business needs prior to firm orders being placed.

[0001262039-23-000021:notes:79]
Other Contractual Commitments and Open Purchase Orders—In addition to commitments with contract manufacturers, we have open purchase orders and contractual obligations in the ordinary course of business for which we have not received goods or services. A significant portion of our reported purchase commitments consist of non-cancelable commitments. In certain instances, contractual commitments allow us the option to cancel, reschedule and adjust our requirements based on our business needs prior to firm orders being placed. As of March 31, 2023, we had $100.1 million in other contractual commitments having a remaining term in excess of one year that are non-cancelable and an additional $100.7 million, in contractual commitments for operating lease liabilities.

[0001262039-23-000021:notes:80]
Litigation—We are involved in disputes, litigation, and other legal actions. For lawsuits where we are the defendant, we are in the process of defending these litigation matters, and while there can be no assurances and the outcome of certain of these matters is currently not determinable and not predictable, we currently are unaware of any existing claims or proceedings that we believe are likely to have a material adverse effect on our financial position. There are many uncertainties associated with any litigation and these actions or other third-party claims against us may cause us to incur costly litigation fees, costs and substantial settlement charges, and possibly subject us to damages and other penalties. In addition, the resolution of any intellectual property (“IP”) litigation may require us to make royalty payments, which could adversely affect our gross margins in future periods. If any of those events were to occur, our business, financial condition, results of operations, and cash flows could be adversely affected. Litigation is unpredictable and the actual liability in any such matters may be materially different from our current estimates, which could result in the need to adjust any accrued liability and record additional expenses. We accrue for contingencies when we believe that a loss is probable and that we can reasonably estimate the amount of any such loss. These accruals are generally based on a range of possible outcomes that require significant management judgement. If no amount within a range is a better estimate than any other, we accrue the minimum amount.

[0001262039-23-000021:notes:81]
Litigation loss contingency accruals associated with outstanding cases were not material as of March 31, 2023 and December 31, 2022.

[0001262039-23-000021:notes:82]
Indemnification and Other Matters—Under the indemnification provisions of our standard sales contracts, we agree to defend our customers against third-party claims asserting various allegations such as product defects and infringement of certain IP rights, which may include patents, copyrights, trademarks or trade secrets, and to pay judgments entered on such claims. In some contracts, our exposure under these indemnification provisions is limited by the terms of the contracts to certain defined limits, such as the total amount paid by our customer under the agreement. However, certain agreements include covenants, penalties and indemnification provisions including and beyond indemnification for third-party claims of IP infringement that could potentially expose us to losses in excess of the amount received under the agreement, and in some instances to potential liability that is not contractually limited. Although from time to time there are indemnification claims asserted against us and currently there are pending indemnification claims, to date there have been no material awards under such indemnification provisions.

[0001262039-23-000021:notes:83]
Similar to other security companies and companies in other industries, we have experienced and may experience in the future, cybersecurity threats, malicious activity directed against our information technology infrastructure or unauthorized attempts to gain access to our and our customers’ sensitive information and systems. We currently are unaware of any existing claims or proceedings related to these types of matters, including any that we believe are likely to have a material adverse effect on our financial position.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001262039-23-000021:notes:84]
[same as prior period, unchanged from 0001262039-22-000038:notes:101]

[0001262039-23-000021:notes:85]
We maintain the Amended and Restated Fortinet, Inc. 2009 Equity Incentive Plan (the “Amended Plan”) pursuant to which we have granted RSUs, stock options and PSUs. As of March 31, 2023, there were a total of 53.1 million shares of common stock available for grant under the Amended Plan.

[0001262039-23-000021:notes:86]
[same as prior period, unchanged from 0001262039-22-000038:notes:103]

[0001262039-23-000021:notes:87]
[same as prior period, unchanged from 0001262039-22-000038:notes:104]

[0001262039-23-000021:notes:88]
|  | Restricted Stock Units Outstanding |
|  | Number of Shares |  | Weighted-Average Grant Date Fair Value per Share |
| Balance—December 31, 2022 | 10.5 |  |  | $ | 40.94 |  |
| Granted | 3.6 |  |  | 60.16 |  |
| Forfeited | (0.1) |  |  | 42.41 |  |
| Vested | (1.9) |  |  | 34.86 |  |
| Balance—March 31, 2023 | 12.1 |  |  | $ | 47.59 |  |

[0001262039-23-000021:notes:89]
Stock compensation expense is recognized on a straight-line basis over the vesting period of each RSU. As of March 31, 2023, total compensation expense related to unvested RSUs granted to employees and non-employees under the Amended Plan, but not yet recognized, was $535.8 million, with a weighted-average remaining vesting period of 3.0 years.

[0001262039-23-000021:notes:90]
[same as prior period, unchanged from 0001262039-22-000038:notes:107]

[0001262039-23-000021:notes:91]
[same as prior period, unchanged from 0001262039-22-000038:notes:108]

[0001262039-23-000021:notes:92]
|  | Three Months Ended |  |  |
|  | March 31,2023 |  | March 31,2022 |  |  |  |  |
| Shares withheld for taxes | 0.7 |  |  | 1.1 |  |  |  |  |  |
| Amount withheld for taxes | $ | 34.6 |  |  | $ | 64.8 |  |  |  |  |  |

[0001262039-23-000021:notes:93]
[same as prior period, unchanged from 0001262039-22-000038:notes:110]

[0001262039-23-000021:notes:94]
[same as prior period, unchanged from 0001262039-22-000038:notes:111]

[0001262039-23-000021:notes:95]
|  | Three Months Ended |  |  |
|  | March 31,2023 |  | March 31,2022 |  |  |  |  |
| Expected term in years | 4.4 |  | 4.4 |  |  |  |  |
| Volatility | 42.0 | % |  | 41.0 | % |  |  |  |  |
| Risk-free interest rate | 4.2 | % |  | 1.8 | % |  |  |  |  |
| Dividend rate | — | % |  | — | % |  |  |  |  |

[0001262039-23-000021:notes:96]
[same as prior period, unchanged from 0001262039-22-000038:notes:113]

[0001262039-23-000021:notes:97]
|  | Options Outstanding |
|  | Numberof Shares |  | Weighted-AverageExercisePrice |  | Weighted-AverageRemainingContractualLife (Years) |  | AggregateIntrinsicValue |
| Balance—December 31, 2022 | 13.2 |  |  | $ | 24.37 |  |  | 3.5 |  | $ | 344.8 |  |
| Granted | 1.1 |  |  | 60.21 |  |  |  |  |  |
| Forfeited | — |  |  | 39.42 |  |  |  |  |  |
| Exercised | (1.7) |  |  | 12.99 |  |  |  |  |  |
| Balance—March 31, 2023 | 12.6 |  |  | $ | 28.99 |  |  |  |  |  |
| Options vested and expected to vest—March 31, 2023 | 12.6 |  |  | $ | 28.99 |  |  | 3.8 |  | $ | 472.0 |  |
| Options exercisable—March 31, 2023 | 8.3 |  |  | $ | 19.23 |  |  | 2.9 |  | $ | 390.2 |  |

[0001262039-23-000021:notes:98]
The aggregate intrinsic value represents the difference between the exercise price of stock options and the quoted market price of our common stock for all in-the-money stock options. Stock compensation expense is recognized on a straight-line basis over the vesting period of each stock option. As of March 31, 2023, total compensation expense related to unvested stock options granted to employees but not yet recognized was $73.4 million, with a weighted-average remaining vesting period of 3.0 years.

[0001262039-23-000021:notes:99]
[same as prior period, unchanged from 0001262039-22-000038:notes:116]

[0001262039-23-000021:notes:100]
|  | Three Months Ended |  |  |
|  | March 31,2023 |  | March 31,2022 |  |  |  |  |
| Weighted-average fair value per share granted | $ | 24.24 |  |  | $ | 22.32 |  |  |  |  |  |
| Intrinsic value of options exercised | $ | 72.7 |  |  | $ | 29.9 |  |  |  |  |  |
| Fair value of options vested | $ | 11.7 |  |  | $ | 10.2 |  |  |  |  |  |

[0001262039-23-000021:notes:101]
Market/Performance-Based PSUs

[0001262039-23-000021:notes:102]
We granted market/performance-based PSUs under the Amended Plan to certain of our executives. Based on the achievement of the market/performance-based vesting conditions during the performance period, the final settlement of the PSUs will range between 0% and 200% of the target shares underlying the PSUs based on the percentile ranking of our total stockholder return over one-, two-, three- and four-year periods among companies included in the S&P 500 Index. 20%, 20%, 20% and 40% of the PSUs vest over one-, two-, three- and four-year service periods, respectively.

[0001262039-23-000021:notes:103]
The following table summarizes the weighted-average assumptions relating to our PSUs for the three months ended March 31, 2023:

[0001262039-23-000021:notes:104]
|  | Three Months Ended |
|  | March 31,2023 |
| Expected term in years | 2.7 |
| Volatility | 47.5 | % |
| Risk-free interest rate | 4.6 | % |
| Dividend rate | — | % |

[0001262039-23-000021:notes:105]
We granted approximately 0.3 million shares of PSU awards with a grant date fair value of $90.96 per share to certain of our executives during the three months ended March 31, 2023. The grant date fair value of these awards is determined using

[0001262039-23-000021:notes:106]
a Monte Carlo simulation pricing model. None of these PSU awards were vested or forfeited during the three months ended March 31, 2023.

[0001262039-23-000021:notes:107]
As of March 31, 2023, total compensation expense related to unvested PSUs that were granted to certain of our executives, but not yet recognized, was $26.5 million. This expense is expected to be amortized on a graded vesting method over a weighted-average vesting period of 2.7 years.

[0001262039-23-000021:notes:108]
[same as prior period, unchanged from 0001262039-22-000038:notes:118]

[0001262039-23-000021:notes:109]
Stock-based compensation expense, including stock-based compensation expense related to awards classified as liabilities, is included in costs and expenses (in millions):

[0001262039-23-000021:notes:110]
|  | Three Months Ended |  |  |
|  | March 31,2023 |  | March 31,2022 |  |  |  |  |
| Cost of product revenue | $ | 0.4 |  |  | $ | 0.4 |  |  |  |  |  |
| Cost of service revenue | 5.1 |  |  | 4.5 |  |  |  |  |  |
| Research and development | 17.0 |  |  | 15.1 |  |  |  |  |  |
| Sales and marketing | 26.3 |  |  | 26.7 |  |  |  |  |  |
| General and administrative | 8.2 |  |  | 7.2 |  |  |  |  |  |
| Total stock-based compensation expense | $ | 57.0 |  |  | $ | 53.9 |  |  |  |  |  |

[0001262039-23-000021:notes:111]
[same as prior period, unchanged from 0001262039-22-000038:notes:121]

[0001262039-23-000021:notes:112]
|  | Three Months Ended |  |  |
|  | March 31,2023 |  | March 31,2022 |  |  |  |  |
| RSUs | $ | 49.1 |  |  | $ | 48.3 |  |  |  |  |  |
| Stock options | 6.7 |  |  | 5.6 |  |  |  |  |  |
| PSUs | $ | 1.2 |  |  | $ | — |  |  |  |  |  |
| Total stock-based compensation expense | $ | 57.0 |  |  | $ | 53.9 |  |  |  |  |  |

[0001262039-23-000021:notes:113]
[same as prior period, unchanged from 0001262039-22-000038:notes:123]

[0001262039-23-000021:notes:114]
|  | Three Months Ended |  |  |
|  | March 31,2023 |  | March 31,2022 |  |  |  |  |
| Income tax benefit associated with stock-based compensation | $ | 12.6 |  |  | $ | 11.8 |  |  |  |  |  |

[0001262039-23-000021:notes:115]
[same as prior period, unchanged from 0001262039-22-000038:notes:125]

[0001262039-23-000021:notes:116]
In February 2023, our board of directors approved an extension of the Repurchase Program originally approved by our board of directors in January 2016 to February 29, 2024. Under the Repurchase Program, the aggregate amount authorized to repurchase our outstanding common stock was $5.25 billion. Share repurchases may be made by us from time to time in privately negotiated transactions or in open-market transactions. The Repurchase Program does not require us to purchase a minimum number of shares, and may be suspended, modified or discontinued at any time without prior notice. Refer to Note 16, Subsequent Events, for information regarding the approved $1.0 billion increase in the authorized stock repurchase under the Repurchase Program in April 2023.

[0001262039-23-000021:notes:117]
There were no shares repurchased under the Repurchase Program during the three months ended March 31, 2023. As of March 31, 2023, $529.6 million remained available for future share repurchases under the Repurchase Program.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001262039-23-000021:notes:118]
INCOME TAXES
Our effective tax rate was 7% for the three months ended March 31, 2023, compared to an effective tax rate of negative 6% for the same period last year. The tax rates for the three months ended March 31, 2023 and 2022 were composed of U.S. federal and state taxes, withholding taxes and foreign taxes that amounted to $85.8 million and $38.5 million, respectively. The tax rate for the three months ended March 31, 2023 was impacted by a tax benefit of $38.2 million from the FDII deduction and excess tax benefits from stock-based compensation expense of $26.3 million. The tax rate for the three months ended March 31, 2022 was impacted by a tax benefit of $14.4 million from the FDII deduction and excess tax benefits from stock-based compensation expense of $32.2 million.

[0001262039-23-000021:notes:119]
As of March 31, 2023 and December 31, 2022, unrecognized tax benefits were $70.4 million and $67.4 million, respectively. If recognized, $61.2 million of the unrecognized tax benefits as of March 31, 2023 would favorably affect our effective tax rate. It is our policy to include accrued interest and penalties related to unrecognized tax benefits in income tax expense. As of both March 31, 2023 and December 31, 2022, accrued interest and penalties totaled $9.3 million. It is reasonably possible that our gross unrecognized tax benefits will decrease by up to $15.2 million in the next 12 months, due to the lapse of statutes of limitation in various jurisdictions. This decrease, if recognized, would favorably impact our effective tax rate, and would be recognized as additional tax benefits.

[0001262039-23-000021:notes:120]
[same as prior period, unchanged from 0001262039-22-000038:notes:132]

[0001262039-23-000021:notes:121]
On January 4, 2022, the U.S. Treasury published another tranche of final regulations regarding the foreign tax credit. These final regulations impose new requirements that a foreign tax must meet in order to be creditable against U.S. income taxes, and generally apply to tax years beginning on or after December 28, 2021. On July 26, 2022, the U.S. Treasury released corrections to the final regulations. These final regulations adversely impact our ability to claim foreign tax credits in the United States for certain taxes imposed by certain foreign jurisdictions.

[0001262039-23-000021:notes:122]
On August 16, 2022, the United States enacted the Inflation Reduction Act of 2022 that, among other changes, provides for changes to the U.S. corporate income tax system, including a 15% minimum tax based on financial statement income for companies with three-year average annual adjusted financial statement income exceeding $1 billion, and a 1% excise tax on net repurchases of stock after December 31, 2022, if any. We considered the applicable tax law changes, and there is no impact to our tax provision for the three months ended March 31, 2023. We will continue to evaluate the impact of these tax law changes on future periods.


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0001262039-23-000021:notes:123]
DEFINED CONTRIBUTION PLANSOur tax-deferred savings plan under our 401(k) Plan permits participating U.S. employees to contribute a portion of their pre-tax or after-tax earnings. In Canada, we have a Group Registered Retirement Savings Plan Program (the “RRSP”), which permits participants to make pre-tax contributions. Our board of directors approved 50% matching contributions on employee contributions up to 4% of each employee’s eligible earnings. Our matching contributions to our 401(k) Plan and the RRSP for the three months ended March 31, 2023 and 2022 were $4.4 million and $3.4 million, respectively.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001262039-23-000021:notes:124]
[same as prior period, unchanged from 0001262039-22-000038:notes:136]

[0001262039-23-000021:notes:125]
|  | Three Months Ended |  |  |
| Revenue | March 31,2023 |  | March 31,2022 |  |  |  |  |
| Americas: |  |  |  |  |  |  |  |
| United States | $ | 384.1 |  |  | $ | 285.8 |  |  |  |  |  |
| Other Americas | 139.4 |  |  | 96.8 |  |  |  |  |  |
| Total Americas | 523.5 |  |  | 382.6 |  |  |  |  |  |
| Europe, Middle East and Africa (“EMEA”) | 478.2 |  |  | 346.0 |  |  |  |  |  |
| Asia Pacific (“APAC”) | 260.6 |  |  | 226.2 |  |  |  |  |  |
| Total revenue | $ | 1,262.3 |  |  | $ | 954.8 |  |  |  |  |  |

[0001262039-23-000021:notes:126]
| Property and Equipment—net | March 31,2023 |  | December 31,2022 |
| Americas: |  |  |  |
| United States | $ | 660.4 |  |  | $ | 638.1 |  |
| Canada | 203.0 |  |  | 204.4 |  |
| Latin America | 1.0 |  |  | 1.1 |  |
| Total Americas | 864.4 |  |  | 843.6 |  |
| EMEA | 35.4 |  |  | 35.9 |  |
| APAC | 17.6 |  |  | 19.0 |  |
| Total property and equipment—net | $ | 917.4 |  |  | $ | 898.5 |  |

[0001262039-23-000021:notes:127]
[same as prior period, unchanged from 0001262039-22-000038:notes:139]

[0001262039-23-000021:notes:128]
|  | Three Months Ended |  |  |
|  | March 31,2023 |  | March 31,2022 |  |  |  |  |
| Distributor A | 28 | % |  | 29 | % |  |  |  |  |
| Distributor B | 14 | % |  | 13 | % |  |  |  |  |
| Distributor C | 14 | % |  | 14 | % |  |  |  |  |

[0001262039-23-000021:notes:129]
[same as prior period, unchanged from 0001262039-22-000038:notes:142]

[0001262039-23-000021:notes:130]
|  | March 31,2023 |  | December 31,2022 |
| Distributor A | 28 | % |  | 32 | % |
| Distributor B | 14 | % |  | 12 | % |
| Distributor C | 12 | % |  | 13 | % |


## us-gaap:SubsequentEventsTextBlock

[0001262039-23-000021:notes:131]
SUBSEQUENT EVENTS
Share Repurchase Program

[0001262039-23-000021:notes:132]
In April 2023, our board of directors approved a $1.0 billion increase in the authorized stock repurchase amount under the Repurchase Program, bringing the aggregate amount authorized to be repurchased to $6.25 billion of our outstanding common stock through February 29, 2024. As of May 8, 2023, approximately $1.53 billion remained available for future share repurchases.

[0001262039-23-000021:notes:133]
Real property purchase

[0001262039-23-000021:notes:134]
In April 2023, we purchased real property in Plano, Texas, totaling approximately 43,400 square feet, for $19.3 million in cash.
