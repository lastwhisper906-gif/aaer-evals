# FTNT 8-K — 0001262039-23-000013 filed 2023-05-04

## item codes, every 8-K on or before 2023-05-08

- 2023-05-04 0001262039-23-000013 — 2.02, 9.01
- 2023-02-08 0001262039-23-000006 — 5.03, 9.01
- 2023-02-07 0001262039-23-000003 — 2.02, 9.01
- 2022-11-02 0001262039-22-000035 — 2.02, 9.01
- 2022-08-03 0001262039-22-000026 — 2.02, 9.01
- 2022-06-22 0001262039-22-000023 — 5.03, 9.01
- 2022-06-21 0001262039-22-000021 — 5.07
- 2022-05-04 0001262039-22-000015 — 2.02, 9.01
- 2022-05-02 0001262039-22-000012 — 5.02
- 2022-04-22 0001262039-22-000010 — 8.01
- 2022-02-03 0001262039-22-000005 — 2.02, 9.01
- 2022-01-26 0001262039-22-000002 — 5.02, 9.01 — amendment, the index does not say of what
- 2021-11-04 0001262039-21-000027 — 2.02, 9.01
- 2021-10-06 0001262039-21-000024 — 5.02, 9.01
- 2021-07-29 0001262039-21-000019 — 2.02, 9.01
- 2021-06-23 0001262039-21-000016 — 5.07
- 2021-04-30 0001104659-21-059008 — 5.03 — amendment, the index does not say of what
- 2021-04-29 0001262039-21-000011 — 2.02, 9.01
- 2021-04-28 0001104659-21-056360 — 5.02, 5.03, 9.01
- 2021-03-05 0001193125-21-071498 — 1.01, 9.01
- 2021-02-25 0001193125-21-057281 — 1.01, 9.01
- 2021-02-04 0001262039-21-000005 — 2.02, 9.01
- 2020-12-08 0001262039-20-000070 — 8.01
- 2020-10-29 0001262039-20-000063 — 2.02, 9.01
- 2020-10-20 0001262039-20-000060 — 5.02 — amendment, the index does not say of what
- 2020-08-26 0001262039-20-000056 — 5.02, 9.01
- 2020-08-06 0001262039-20-000051 — 2.02, 9.01
- 2020-07-21 0001262039-20-000044 — 5.03, 8.01, 9.01
- 2020-06-24 0001262039-20-000038 — 5.07
- 2020-05-06 0001262039-20-000029 — 2.02, 9.01
- 2020-04-23 0001262039-20-000025 — 5.03, 9.01
- 2020-04-23 0001262039-20-000024 — 5.02 — amendment of 0001262039-20-000025
- 2020-02-28 0001262039-20-000015 — 5.02, 9.01
- 2020-02-06 0001262039-20-000004 — 2.02, 9.01
- 2019-12-12 0001262039-19-000038 — 8.01
- 2019-10-31 0001262039-19-000032 — 2.02, 9.01
- 2019-10-28 0001262039-19-000027 — 8.01
- 2019-10-23 0001262039-19-000025 — 5.02, 9.01
- 2019-08-01 0001262039-19-000021 — 2.02, 9.01
- 2019-06-26 0001262039-19-000018 — 5.07
- 2019-05-02 0001262039-19-000010 — 2.02, 9.01
- 2019-02-06 0001262039-19-000002 — 2.02, 9.01
- 2018-11-01 0001262039-18-000037 — 2.02, 9.01
- 2018-10-23 0001262039-18-000035 — 8.01
- 2018-08-01 0001262039-18-000025 — 2.02, 9.01
- 2018-06-28 0001262039-18-000023 — 5.03, 5.07, 9.01
- 2018-06-04 0001262039-18-000021 — 8.01
- 2018-05-03 0001262039-18-000017 — 2.02, 5.02, 9.01
- 2018-02-05 0001262039-18-000004 — 2.02, 5.02, 9.01
- 2017-10-26 0001262039-17-000031 — 2.02, 9.01
- 2017-10-19 0001262039-17-000029 — 5.02 — amendment, the index does not say of what
- 2017-07-26 0001262039-17-000025 — 2.02, 9.01
- 2017-06-27 0001262039-17-000023 — 5.07
- 2017-05-31 0001262039-17-000021 — 5.02 — amendment of 0001262039-17-000019
- 2017-05-30 0001262039-17-000019 — 5.02, 9.01
- 2017-04-27 0001262039-17-000013 — 2.02, 9.01
- 2017-02-02 0001262039-17-000003 — 2.02, 9.01
- 2016-10-27 0001262039-16-000085 — 2.02, 9.01
- 2016-10-11 0001262039-16-000082 — 2.02, 9.01
- 2016-07-28 0001262039-16-000076 — 2.02, 9.01
- 2016-07-22 0001262039-16-000073 — 8.01, 9.01
- 2016-06-20 0001262039-16-000068 — 5.07
- 2016-06-07 0001193125-16-614788 — 8.01
- 2016-04-26 0001262039-16-000061 — 2.02, 9.01
- 2016-01-28 0001262039-16-000051 — 2.02, 9.01
- 2015-10-27 0001262039-15-000045 — 2.02
- 2015-10-22 0001262039-15-000042 — 5.02 — amendment, the index does not say of what
- 2015-10-22 0001262039-15-000041 — 5.02 — amendment, the index does not say of what
- 2015-10-22 0001262039-15-000039 — 2.02, 9.01
- 2015-09-28 0001262039-15-000034 — 5.02, 9.01
- 2015-09-22 0001262039-15-000031 — 9.01 — amendment of 0001193125-15-248065
- 2015-08-28 0001262039-15-000027 — 3.01, 5.02
- 2015-07-23 0001262039-15-000021 — 5.02
- 2015-07-22 0001262039-15-000019 — 2.02, 9.01
- 2015-07-08 0001193125-15-248065 — 2.01, 8.01, 9.01
- 2015-06-22 0001193125-15-229099 — 5.07
- 2015-06-19 0001193125-15-228428 — 5.02, 9.01
- 2015-04-20 0001262039-15-000014 — 2.02, 9.01
- 2015-01-28 0001262039-15-000005 — 2.02, 9.01
- 2014-10-22 0001262039-14-000036 — 2.02, 9.01
- 2014-07-23 0001262039-14-000030 — 2.02, 9.01
- 2014-06-24 0001262039-14-000027 — 5.07
- 2014-04-23 0001262039-14-000021 — 2.02, 9.01
- 2014-04-21 0001262039-14-000018 — 5.03, 9.01
- 2014-01-29 0001262039-14-000004 — 2.02, 9.01
- 2013-12-20 0001262039-13-000061 — 5.02, 9.01
- 2013-11-27 0001262039-13-000057 — 5.02, 7.01, 9.01
- 2013-11-12 0001445305-13-002993 — 5.02
- 2013-10-23 0001262039-13-000051 — 2.02, 9.01
- 2013-07-30 0001262039-13-000039 — 2.02, 9.01
- 2013-06-25 0001262039-13-000030 — 5.07
- 2013-04-30 0001262039-13-000023 — 2.02, 9.01
- 2013-04-19 0001262039-13-000020 — 5.02, 9.01
- 2013-04-19 0001262039-13-000018 — 5.02 — amendment of 0001262039-13-000020
- 2013-04-10 0001262039-13-000016 — 2.02, 9.01
- 2013-03-26 0001262039-13-000013 — 5.02
- 2013-01-30 0001262039-13-000005 — 2.02, 9.01
- 2013-01-24 0001262039-13-000002 — 5.02, 9.01
- 2012-10-16 0001262039-12-000048 — 2.02, 9.01
- 2012-10-01 0001262039-12-000045 — 5.02
- 2012-09-26 0001262039-12-000043 — 5.01
- 2012-07-25 0001262039-12-000038 — 2.02, 9.01
- 2012-07-19 0001262039-12-000034 — 5.02
- 2012-06-20 0001193125-12-275869 — 5.07
- 2012-04-27 0001262039-12-000029 — 5.02
- 2012-04-24 0001262039-12-000025 — 2.02, 9.01
- 2012-01-31 0001262039-12-000006 — 2.02, 9.01
- 2012-01-25 0001262039-12-000003 — 5.03
- 2011-10-24 0001262039-11-000036 — 2.02
- 2011-07-19 0001262039-11-000014 — 2.02, 9.01
- 2011-06-27 0001193125-11-174474 — 5.02, 5.07, 9.01
- 2011-04-27 0001193125-11-111938 — 2.02, 9.01
- 2011-01-25 0001193125-11-013914 — 2.02, 9.01
- 2010-10-21 0001193125-10-233676 — 2.02, 9.01
- 2010-09-02 0001193125-10-203099 — 8.01
- 2010-07-22 0001193125-10-163844 — 2.02, 9.01
- 2010-06-24 0001193125-10-146082 — 5.07
- 2010-04-28 0001193125-10-096698 — 2.02, 9.01
- 2010-02-09 0001193125-10-024614 — 8.01
- 2010-01-27 0001193125-10-014292 — 2.02, 9.01
- 2010-01-26 0001193125-10-013031 — 5.02, 9.01

## late-filing notifications on or before 2023-05-08

- none on or before 2023-05-08

## item 2.02 — earnings release, exhibit 99.1

[0001262039-23-000013:8k_2_02:1]
EX-99.1
2
ftntq1-2023ex991.htm
PRESS RELEASE

[0001262039-23-000013:8k_2_02:2]
Document

[0001262039-23-000013:8k_2_02:3]
Press Release

[0001262039-23-000013:8k_2_02:4]
Fortinet Reports First Quarter 2023 Financial Results

[0001262039-23-000013:8k_2_02:5]
First Quarter 2023 Highlights

[0001262039-23-000013:8k_2_02:6]
•Product revenue of $500.7 million, up 35% year over year

[0001262039-23-000013:8k_2_02:7]
•Service revenue of $761.6 million, up 30% year over year

[0001262039-23-000013:8k_2_02:8]
•Total revenue of $1.26 billion, up 32% year over year

[0001262039-23-000013:8k_2_02:9]
•Billings of $1.50 billion, up 30% year over year1

[0001262039-23-000013:8k_2_02:10]
•Deferred revenue of $4.88 billion, up 33% year over year

[0001262039-23-000013:8k_2_02:11]
•GAAP operating income of $273.5 million, up 81% year over year

[0001262039-23-000013:8k_2_02:12]
•Non-GAAP operating income of $334.0 million, up 59% year over year1

[0001262039-23-000013:8k_2_02:13]
•GAAP operating margin of 21.7%

[0001262039-23-000013:8k_2_02:14]
•Non-GAAP operating margin of 26.5%1

[0001262039-23-000013:8k_2_02:15]
•GAAP diluted net income per share attributable to Fortinet, Inc. of $0.31, up 82% year over year2

[0001262039-23-000013:8k_2_02:16]
•Non-GAAP diluted net income per share attributable to Fortinet, Inc. of $0.34, up 79% year over year1,2

[0001262039-23-000013:8k_2_02:17]
•Cash flow from operations of $677.5 million

[0001262039-23-000013:8k_2_02:18]
•Free cash flow of $647.2 million1

[0001262039-23-000013:8k_2_02:19]
SUNNYVALE, Calif. - May 4, 2023 - Fortinet® (Nasdaq: FTNT), a global leader in broad, integrated and automated cybersecurity solutions, today announced financial results for the first quarter ended March 31, 2023.

[0001262039-23-000013:8k_2_02:20]
“Revenue growth in the first quarter was 32% due to strong growth in both product and service revenue. With 35% product revenue growth, we continue to gain market share while being a leading product revenue company in the cybersecurity industry. Service revenue grew over 30% for the first time in a quarter in six years. We believe we have a significant opportunity to continue to grow service revenue by upselling value-added security services to our large installed base of customers,” said Ken Xie, Founder, Chairman and Chief Executive Officer. “Companies of all sizes are increasingly recognizing that Fortinet's integrated FortiOS and custom ASIC technology can deliver a lower total cost of ownership while improving the efficiency and efficacy of their security.”

[0001262039-23-000013:8k_2_02:21]
Financial Highlights for the First Quarter of 2023

[0001262039-23-000013:8k_2_02:22]
•Product Revenue: Product revenue was $500.7 million for the first quarter of 2023, an increase of 35.0% compared to $371.0 million for the same quarter of 2022.

[0001262039-23-000013:8k_2_02:23]
•Service Revenue: Service revenue was $761.6 million for the first quarter of 2023, an increase of 30.5% compared to $583.8 million for the same quarter of 2022.

[0001262039-23-000013:8k_2_02:24]
•Revenue: Total revenue was $1.26 billion for the first quarter of 2023, an increase of 32.2% compared to $954.8 million for the same quarter of 2022.

[0001262039-23-000013:8k_2_02:25]
•Billings1: Total billings were $1.50 billion for the first quarter of 2023, an increase of 29.6% compared to $1.16 billion for the same quarter of 2022.

[0001262039-23-000013:8k_2_02:26]
•Deferred Revenue: Total deferred revenue was $4.88 billion as of March 31, 2023, an increase of 33.4% compared to $3.66 billion as of March 31, 2022.

[0001262039-23-000013:8k_2_02:27]
•GAAP Operating Income and Margin: GAAP operating income was $273.5 million for the first quarter of 2023, representing a GAAP operating margin of 21.7%. GAAP operating income was $151.0 million for the same quarter of 2022, representing a GAAP operating margin of 15.8%.

[0001262039-23-000013:8k_2_02:28]
•Non-GAAP Operating Income and Margin1: Non-GAAP operating income was $334.0 million for the first quarter of 2023, representing a non-GAAP operating margin of 26.5%. Non-GAAP operating income was $210.2 million for the same quarter of 2022, representing a non-GAAP operating margin of 22.0%.

[0001262039-23-000013:8k_2_02:29]
•GAAP Net Income and Diluted Net Income Per Share Attributable to Fortinet, Inc.2: GAAP net income was $247.7 million for the first quarter of 2023, compared to GAAP net income of $138.4 million for the same quarter of 2022. GAAP diluted net income per share was $0.31 for the first quarter of 2023, based on 793.4 million diluted weighted-average shares outstanding, compared to GAAP diluted net income per share of $0.17 for the same quarter of 2022, based on 820.8 million diluted weighted-average shares outstanding.

[0001262039-23-000013:8k_2_02:30]
•Non-GAAP Net Income and Diluted Net Income Per Share Attributable to Fortinet, Inc.1,2: Non-GAAP net income was $269.7 million for the first quarter of 2023, compared to non-GAAP net income of $155.1 million for the same quarter of 2022. Non-GAAP diluted net income per share was $0.34 for the first quarter of 2023, based on 793.4 million diluted weighted-average shares outstanding, compared to $0.19 for the same quarter of 2022, based on 820.8 million diluted weighted-average shares outstanding.

[0001262039-23-000013:8k_2_02:31]
•Cash Flow: Cash flow from operations was $677.5 million for the first quarter of 2023, compared to $396.1 million for the same quarter of 2022.

[0001262039-23-000013:8k_2_02:32]
•Free Cash Flow1: Free cash flow was $647.2 million for the first quarter of 2023, compared to $273.5 million for the same quarter of 2022.

[0001262039-23-000013:8k_2_02:33]
•Share Repurchase Program: In April 2023, Fortinet’s board of directors authorized a $1.0 billion increase in the authorized stock repurchase under our share repurchase program. As of May 4, 2023, approximately $1.53 billion remained available for future share repurchases.

[0001262039-23-000013:8k_2_02:34]
Guidance

[0001262039-23-000013:8k_2_02:35]
For the second quarter of 2023, Fortinet currently expects:

[0001262039-23-000013:8k_2_02:36]
•Revenue in the range of $1.280 billion to $1.320 billion

[0001262039-23-000013:8k_2_02:37]
•Billings in the range of $1.560 billion to $1.600 billion

[0001262039-23-000013:8k_2_02:38]
•Non-GAAP gross margin in the range of 75.5% to 76.5%

[0001262039-23-000013:8k_2_02:39]
•Non-GAAP operating margin in the range of 24.5% to 25.5%

[0001262039-23-000013:8k_2_02:40]
•Diluted non-GAAP net income per share attributable to Fortinet, Inc. in the range of $0.33 to $0.35, assuming a non-GAAP effective tax rate of 17%. This assumes a diluted share count of 790 million to 800 million.

[0001262039-23-000013:8k_2_02:41]
For the fiscal year 2023, Fortinet currently expects:

[0001262039-23-000013:8k_2_02:42]
•Revenue in the range of $5.425 billion to $5.485 billion

[0001262039-23-000013:8k_2_02:43]
•Service revenue in the range of $3.370 billion to $3.400 billion

[0001262039-23-000013:8k_2_02:44]
•Billings in the range of $6.750 billion to $6.810 billion

[0001262039-23-000013:8k_2_02:45]
•Non-GAAP gross margin in the range of 75.0% to 76.0%

[0001262039-23-000013:8k_2_02:46]
•Non-GAAP operating margin in the range of 25.0% to 26.0%

[0001262039-23-000013:8k_2_02:47]
•Diluted non-GAAP net income per share attributable to Fortinet, Inc. in the range of $1.44 to $1.48, assuming a non-GAAP effective tax rate of 17%. This assumes a diluted share count of 795 million to 805 million.

[0001262039-23-000013:8k_2_02:48]
Our guidance with respect to non-GAAP financial measures excludes stock-based compensation, amortization of acquired intangible assets and gain on intellectual property matters. We have not reconciled our guidance with respect to non-GAAP financial measures to the corresponding GAAP measures because certain items that impact these measures are uncertain or out of our control, or cannot be reasonably predicted. Accordingly, a reconciliation of these non-GAAP financial measures to the corresponding GAAP measures is not available without unreasonable effort.

[0001262039-23-000013:8k_2_02:49]
1 A reconciliation of GAAP to non-GAAP measures has been provided in the financial statement tables included in this press release. An explanation of these measures is also included below under the heading “Non-GAAP Financial Measures”.

[0001262039-23-000013:8k_2_02:50]
2 All share and per share amounts presented herein have been retroactively adjusted to reflect the five-for-one forward stock split which was effective June 22, 2022.

[0001262039-23-000013:8k_2_02:51]
Conference Call Details

[0001262039-23-000013:8k_2_02:52]
Fortinet will host a conference call today at 1:30 p.m. Pacific Time (4:30 p.m. Eastern Time) to discuss the earnings results. A live webcast of the conference call and supplemental slides will be accessible from the Investor Relations page of Fortinet’s website at https://investor.fortinet.com and a replay will be archived and accessible at https://investor.fortinet.com/events-and-presentations.

[0001262039-23-000013:8k_2_02:53]
Second Quarter 2023 Conference Participation Schedule:

[0001262039-23-000013:8k_2_02:54]
•J.P. Morgan Global Technology, Media and Communications Conference

[0001262039-23-000013:8k_2_02:55]
May 23, 2023

[0001262039-23-000013:8k_2_02:56]
•Bank of America Global Technology Conference

[0001262039-23-000013:8k_2_02:57]
June 6, 2023

[0001262039-23-000013:8k_2_02:58]
Members of Fortinet’s management team are expected to present at these conferences and discuss the latest company strategies and initiatives. Fortinet’s conference presentations are expected to be available via webcast on the company’s web site. To access the most updated information, pre-register and listen to the webcast of each event, please visit the Investor Presentation & Events page of Fortinet’s website at https://investor.fortinet.com/events-and-presentations. The schedule is subject to change.

[0001262039-23-000013:8k_2_02:59]
About Fortinet (www.fortinet.com)

[0001262039-23-000013:8k_2_02:60]
Fortinet (NASDAQ: FTNT) is a driving force in the evolution of cybersecurity and the convergence of networking and security. Our mission is to secure people, devices and data everywhere, and today we deliver cybersecurity everywhere our customers need it with the largest integrated portfolio of over 50 enterprise-grade products. Over half a million customers trust Fortinet's solutions, which are among the most deployed, most patented and most validated in the industry. The Fortinet Training Institute, one of the largest and broadest training programs in the industry, is dedicated to making cybersecurity training and new career opportunities available to everyone. FortiGuard Labs, Fortinet’s elite threat intelligence and research organization, develops and utilizes leading-edge machine learning and AI technologies to provide customers with timely and consistently top-rated protection and actionable threat intelligence. Learn more at https://www.fortinet.com, the Fortinet Blog or FortiGuard Labs.

[0001262039-23-000013:8k_2_02:61]
#          #          #

[0001262039-23-000013:8k_2_02:62]
Copyright © 2023 Fortinet, Inc. All rights reserved. The symbols ® and ™ denote respectively federally registered trademarks and common law trademarks of Fortinet, Inc., its subsidiaries and affiliates. Fortinet’s trademarks include, but are not limited to, the following: Fortinet, the Fortinet logo, FortiGate, FortiOS, FortiGuard, FortiCare, FortiAnalyzer, FortiManager, FortiASIC, FortiClient, FortiCloud, FortiMail, FortiSandbox, FortiADC, FortiAI, FortiAIOps, FortiAntenna, FortiAP, FortiAPCam, FortiAuthenticator, FortiCache, FortiCall, FortiCam, FortiCamera, FortiCarrier, FortiCASB, FortiCentral, FortiCNP, FortiConnect, FortiController, FortiConverter, FortiCWP, FortiDAST, FortiDB, FortiDDoS, FortiDeceptor, FortiDeploy, FortiDevSec, FortiEDR, FortiExplorer, FortiExtender, FortiFirewall, FortiFone, FortiGSLB, FortiGuest, FortiHypervisor, FortiInsight, FortiIsolator, FortiLAN, FortiLink, FortiMonitor, FortiNAC, FortiNDR, FortiPAM, FortiPenTest, FortiPhish, FortiPolicy, FortiPortal, FortiPresence, FortiProxy, FortiRecon, FortiRecorder, FortiSASE, FortiSDNConnector, FortiSIEM, FortiSMS, FortiSOAR, FortiSwitch, FortiTester, FortiToken, FortiTrust, FortiVoice, FortiWAN, FortiWeb, FortiWiFi, FortiWLC, FortiWLM and FortiXDR. Other trademarks belong to their respective owners. Fortinet has not independently verified statements or certifications herein attributed to third parties and Fortinet does not independently endorse such statements. Notwithstanding anything to the contrary herein, nothing herein constitutes a warranty, guarantee, contract, binding specification or other binding commitment by Fortinet or any indication of intent related to a binding commitment, and performance and other specification information herein may be unique to certain environments.

[0001262039-23-000013:8k_2_02:63]
FTNT-F

[0001262039-23-000013:8k_2_02:64]
Forward-Looking Statements

[0001262039-23-000013:8k_2_02:65]
This press release contains forward-looking statements that involve risks and uncertainties. These forward-looking statements include statements regarding any indications related to future market share gains, guidance and expectations around future financial results, including guidance and expectations for the second quarter and full year 2023, statements regarding the momentum in our business and future growth expectations, statements regarding the opportunity to grow service revenue, and any statements regarding our market opportunity and market size, and business momentum. Although we attempt to be accurate in making forward-

[0001262039-23-000013:8k_2_02:66]
Non-GAAP Financial Measures

[0001262039-23-000013:8k_2_02:67]
We have provided in this release financial information that has not been prepared in accordance with U.S. Generally Accepted Accounting Principles (GAAP). These non-GAAP financial and liquidity measures are not based on any standardized methodology prescribed by GAAP and are not necessarily comparable to similar measures presented by other companies. We use

[0001262039-23-000013:8k_2_02:68]
these non-GAAP financial measures internally in analyzing our financial results and believe they are useful to investors, as a supplement to GAAP measures, in evaluating our ongoing operational performance. We believe that the use of these non-GAAP financial measures provides an additional tool for investors to use in evaluating ongoing operating results and trends and in comparing our financial results with peer companies, many of which present similar non-GAAP financial measures to investors.

[0001262039-23-000013:8k_2_02:69]
Non-GAAP financial measures should not be considered in isolation from, or as a substitute for, financial information prepared in accordance with GAAP. Investors are encouraged to review the reconciliation of these non-GAAP financial measures to their most directly comparable GAAP financial measures provided in the financial statement tables below.

[0001262039-23-000013:8k_2_02:70]
Billings (non-GAAP). We define billings as revenue recognized in accordance with GAAP plus the change in deferred revenue from the beginning to the end of the period less any deferred revenue balances acquired from business combination(s) during the period. We consider billings to be a useful metric for management and investors because billings drive current and future revenue, which is an important indicator of the health and viability of our business. There are a number of limitations related to the use of billings instead of GAAP revenue. First, billings include amounts that have not yet been recognized as revenue and are impacted by the term of security and support agreements. Second, we may calculate billings in a manner that is different from peer companies that report similar financial measures. Management accounts for these limitations by providing specific information regarding GAAP revenue and evaluating billings together with GAAP revenue.

[0001262039-23-000013:8k_2_02:71]
Free cash flow (non-GAAP). We define free cash flow as net cash provided by operating activities minus purchases of property and equipment and excluding any significant non-recurring items. We believe free cash flow to be a liquidity measure that provides useful information to management and investors about the amount of cash generated by the business that, after capital expenditures and net of proceeds from intellectual property matter, can be used for strategic opportunities, including repurchasing outstanding common stock, investing in our business, making strategic acquisitions and strengthening the balance sheet. A limitation of using free cash flow rather than the GAAP measures of cash provided by or used in operating activities, investing activities, and financing activities is that free cash flow does not represent the total increase or decrease in the cash and cash equivalents balance for the period because it excludes cash flows from significant non-recurring items, investing activities other than capital expenditures and cash flows from financing activities. Management accounts for this limitation by providing information about our capital expenditures and other investing and financing activities on the face of the cash flow statement and under the caption “Management’s Discussion and Analysis of Financial Condition and Results of Operations—Liquidity and Capital Resources” in our most recent Quarterly Report on Form 10-Q and Annual Report on Form 10-K and by presenting cash flows from investing and financing activities in our reconciliation of free cash flow. In addition, it is important to note that other companies, including companies in our industry, may not use free cash flow, may calculate free cash flow in a different manner than we do or may use other financial measures to evaluate their performance, all of which could reduce the usefulness of free cash flow as a comparative measure.

[0001262039-23-000013:8k_2_02:72]
Non-GAAP operating income and operating margin. We define non-GAAP operating income as operating income plus stock-based compensation, impairment and amortization of acquired intangible assets, less gain on intellectual property matter and, when applicable, other significant non-recurring items in a given quarter. Non-GAAP operating margin is defined as non-GAAP operating income divided by GAAP revenue. We consider these non-GAAP financial measures to be useful metrics for management and investors because they exclude the items noted above so that our management and investors can compare our recurring core business operating results over multiple periods. There are a number of limitations related to the use of non-GAAP operating income instead of operating income calculated in accordance with GAAP.

[0001262039-23-000013:8k_2_02:73]
First, non-GAAP operating income excludes the items noted above. Second, the components of the costs that we exclude from our calculation of non-GAAP operating income may differ from the components that peer companies exclude when they report their non-GAAP results of operations. Management accounts for these limitations by providing specific information regarding the GAAP amounts excluded from non-GAAP operating income and evaluating non-GAAP operating income together with operating income calculated in accordance with GAAP.

[0001262039-23-000013:8k_2_02:74]
Non-GAAP net income and diluted net income per share attributable to Fortinet, Inc. We define non-GAAP net income as net income plus the items noted above under non-GAAP operating income and operating margin. In addition, we adjust non-GAAP net income and diluted net income per share for a tax adjustment required for an effective tax rate on a non-GAAP basis and adjustments attributable to non-controlling interests, which differs from the GAAP effective tax rate. We define non-GAAP diluted net income per share as non-GAAP net income divided by the non-GAAP diluted weighted-average shares outstanding. We consider these non-GAAP financial measures to be useful metrics for management and investors for the same reasons that we use non-GAAP operating income and non-GAAP operating margin. However, in order to provide a more complete picture of our recurring core business operating results, we include in non-GAAP net income and non-GAAP diluted net income per share, the tax adjustment required resulting in an effective tax rate on a non-GAAP basis, which often differs from the GAAP tax rate. We believe the non-GAAP effective tax rates we use are reasonable estimates of normalized tax rates for our current and prior fiscal years under our global operating structure. The same limitations described above regarding our use of non-GAAP operating income and non-GAAP operating margin apply to our use of non-GAAP net income and non-GAAP diluted net income per share. We account for these limitations by providing specific information regarding the GAAP amounts excluded from non-GAAP net income and non-GAAP diluted net income per share and evaluating non-GAAP net income and non-GAAP diluted net income per share together with net income and diluted net income per share calculated in accordance with GAAP.

[0001262039-23-000013:8k_2_02:75]
FORTINET, INC.

[0001262039-23-000013:8k_2_02:76]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001262039-23-000013:8k_2_02:77]
(Unaudited, in millions)

[0001262039-23-000013:8k_2_02:78]
|  | March 31,2023 |  | December 31,2022 |
| ASSETS |  |  |  |
| CURRENT ASSETS: |  |  |  |
| Cash and cash equivalents | $ | 2,304.2 |  |  | $ | 1,682.9 |  |
| Short-term investments | 548.8 |  |  | 502.6 |  |
| Marketable equity securities | 26.1 |  |  | 25.5 |  |
| Accounts receivable—net | 1,087.2 |  |  | 1,261.7 |  |
| Inventory | 302.7 |  |  | 264.6 |  |
| Prepaid expenses and other current assets | 89.7 |  |  | 73.1 |  |
| Total current assets | 4,358.7 |  |  | 3,810.4 |  |
| LONG-TERM INVESTMENTS | 15.6 |  |  | 45.5 |  |
| PROPERTY AND EQUIPMENT—NET | 917.4 |  |  | 898.5 |  |
| DEFERRED CONTRACT COSTS | 536.9 |  |  | 518.2 |  |
| DEFERRED TAX ASSETS | 649.6 |  |  | 569.4 |  |
| GOODWILL AND OTHER INTANGIBLE ASSETS—NET | 178.9 |  |  | 184.0 |  |
| OTHER ASSETS | 175.2 |  |  | 202.0 |  |
| TOTAL ASSETS | $ | 6,832.3 |  |  | $ | 6,228.0 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY (DEFICIT) |  |  |  |
| CURRENT LIABILITIES: |  |  |  |
| Accounts payable | $ | 238.4 |  |  | $ | 243.4 |  |
| Accrued liabilities | 346.7 |  |  | 266.3 |  |
| Accrued payroll and compensation | 213.4 |  |  | 219.4 |  |
| Deferred revenue | 2,463.3 |  |  | 2,349.3 |  |
| Total current liabilities | 3,261.8 |  |  | 3,078.4 |  |
| DEFERRED REVENUE | 2,417.6 |  |  | 2,291.0 |  |
| INCOME TAX LIABILITIES | 70.5 |  |  | 67.8 |  |
| LONG-TERM DEBT | 990.9 |  |  | 990.4 |  |
| OTHER LIABILITIES | 80.1 |  |  | 82.0 |  |
| Total liabilities | 6,820.9 |  |  | 6,509.6 |  |
| COMMITMENTS AND CONTINGENCIES |  |  |  |
| STOCKHOLDERS’ EQUITY (DEFICIT): |  |  |  |
| Common stock | 0.8 |  |  | 0.8 |  |
| Additional paid-in capital | 1,327.4 |  |  | 1,284.2 |  |
| Accumulated other comprehensive loss | (18.1) |  |  | (20.2) |  |
| Accumulated deficit | (1,298.7) |  |  | (1,546.4) |  |
| Total stockholders’ equity (deficit) | 11.4 |  |  | (281.6) |  |
| TOTAL LIABILITIES AND STOCKHOLDERS’ EQUITY (DEFICIT) | $ | 6,832.3 |  |  | $ | 6,228.0 |  |

[0001262039-23-000013:8k_2_02:79]
FORTINET, INC.

[0001262039-23-000013:8k_2_02:80]
CONDENSED CONSOLIDATED STATEMENTS OF INCOME

[0001262039-23-000013:8k_2_02:81]
(Unaudited, in millions, except per share amounts)

[0001262039-23-000013:8k_2_02:82]
|  | Three Months Ended |  |  |
|  | March 31,2023 |  | March 31,2022 |  |  |  |  |
| REVENUE: |  |  |  |  |  |  |  |
| Product | $ | 500.7 |  |  | $ | 371.0 |  |  |  |  |  |
| Service | 761.6 |  |  | 583.8 |  |  |  |  |  |
| Total revenue | 1,262.3 |  |  | 954.8 |  |  |  |  |  |
| COST OF REVENUE: |  |  |  |  |  |  |  |
| Product | 193.6 |  |  | 161.0 |  |  |  |  |  |
| Service | 114.2 |  |  | 92.8 |  |  |  |  |  |
| Total cost of revenue | 307.8 |  |  | 253.8 |  |  |  |  |  |
| GROSS PROFIT: |  |  |  |  |  |  |  |
| Product | 307.1 |  |  | 210.0 |  |  |  |  |  |
| Service | 647.4 |  |  | 491.0 |  |  |  |  |  |
| Total gross profit | 954.5 |  |  | 701.0 |  |  |  |  |  |
| OPERATING EXPENSES: |  |  |  |  |  |  |  |
| Research and development | 151.1 |  |  | 124.9 |  |  |  |  |  |
| Sales and marketing | 478.3 |  |  | 387.6 |  |  |  |  |  |
| General and administrative | 52.8 |  |  | 38.6 |  |  |  |  |  |
| Gain on intellectual property matter | (1.2) |  |  | (1.1) |  |  |  |  |  |
| Total operating expenses | 681.0 |  |  | 550.0 |  |  |  |  |  |
| OPERATING INCOME | 273.5 |  |  | 151.0 |  |  |  |  |  |
| INTEREST INCOME | 20.6 |  |  | 1.3 |  |  |  |  |  |
| INTEREST EXPENSE | (5.0) |  |  | (4.5) |  |  |  |  |  |
| OTHER INCOME (EXPENSE)—NET | 2.0 |  |  | (9.1) |  |  |  |  |  |
| INCOME BEFORE INCOME TAXES AND LOSS FROM EQUITY METHOD INVESTMENT | 291.1 |  |  | 138.7 |  |  |  |  |  |
| PROVISION FOR (BENEFIT FROM) INCOME TAXES | 21.3 |  |  | (8.1) |  |  |  |  |  |
| LOSS FROM EQUITY METHOD INVESTMENT | (22.1) |  |  | (8.5) |  |  |  |  |  |
| NET INCOME INCLUDING NON-CONTROLLING INTERESTS | 247.7 |  |  | 138.3 |  |  |  |  |  |
| Less: NET LOSS ATTRIBUTABLE TO NON-CONTROLLING INTERESTS, NET OF TAX | — |  |  | (0.1) |  |  |  |  |  |
| NET INCOME ATTRIBUTABLE TO FORTINET, INC. | $ | 247.7 |  |  | $ | 138.4 |  |  |  |  |  |
| Net income per share attributable to Fortinet, Inc. (a): |  |  |  |  |  |  |  |
| Basic | $ | 0.32 |  |  | $ | 0.17 |  |  |  |  |  |
| Diluted | $ | 0.31 |  |  | $ | 0.17 |  |  |  |  |  |
| Weighted-average shares used to compute net income per share attributable to Fortinet, Inc. (a): |  |  |  |  |  |  |  |
| Basic | 783.2 |  |  | 803.4 |  |  |  |  |  |
| Diluted | 793.4 |  |  | 820.8 |  |  |  |  |  |

[0001262039-23-000013:8k_2_02:83]
(a) All share and per share amounts presented herein have been retroactively adjusted to reflect the five-for-one forward stock split which was effective June 22, 2022.

[0001262039-23-000013:8k_2_02:84]
FORTINET, INC.

[0001262039-23-000013:8k_2_02:85]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001262039-23-000013:8k_2_02:86]
(Unaudited, in millions)

[0001262039-23-000013:8k_2_02:87]
|  | Three Months Ended |
|  | March 31,2023 |  | March 31,2022 |
| CASH FLOWS FROM OPERATING ACTIVITIES: |  |  |  |
| Net income including non-controlling interests | $ | 247.7 |  |  | $ | 138.3 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |
| Stock-based compensation | 56.3 |  |  | 53.2 |  |
| Amortization of deferred contract costs | 62.5 |  |  | 52.5 |  |
| Depreciation and amortization | 27.5 |  |  | 25.5 |  |
| Amortization of investment premiums (discounts) | (0.3) |  |  | 1.7 |  |
| Loss from equity method investment | 22.1 |  |  | 8.5 |  |
| Other | 3.8 |  |  | 8.4 |  |
| Changes in operating assets and liabilities, net of impact of business combinations: |  |  |  |
| Accounts receivable—net | 171.1 |  |  | 15.4 |  |
| Inventory | (45.3) |  |  | (13.5) |  |
| Prepaid expenses and other current assets | (16.0) |  |  | (26.0) |  |
| Deferred contract costs | (81.2) |  |  | (66.6) |  |
| Deferred tax assets | (81.1) |  |  | (87.6) |  |
| Other assets | 4.5 |  |  | (20.6) |  |
| Accounts payable | (4.1) |  |  | 35.5 |  |
| Accrued liabilities | 80.0 |  |  | 68.2 |  |
| Accrued payroll and compensation | (6.0) |  |  | (13.6) |  |
| Other liabilities | (4.7) |  |  | 11.3 |  |
| Deferred revenue | 240.7 |  |  | 205.5 |  |
| Net cash provided by operating activities | 677.5 |  |  | 396.1 |  |
| CASH FLOWS FROM INVESTING ACTIVITIES: |  |  |  |
| Purchases of investments | (207.2) |  |  | (385.2) |  |
| Sales of investments | — |  |  | 3.0 |  |
| Maturities of investments | 195.0 |  |  | 459.4 |  |
| Purchases of property and equipment | (30.3) |  |  | (122.6) |  |
| Other | 0.1 |  |  | — |  |
| Net cash used in investing activities | (42.4) |  |  | (45.4) |  |
| CASH FLOWS FROM FINANCING ACTIVITIES: |  |  |  |
| Repurchase and retirement of common stock | — |  |  | (691.2) |  |
| Proceeds from issuance of common stock | 21.2 |  |  | 11.0 |  |
| Taxes paid related to net share settlement of equity awards | (34.5) |  |  | (64.8) |  |
| Other | (0.4) |  |  | (1.0) |  |
| Net cash used in financing activities | (13.7) |  |  | (746.0) |  |
| EFFECT OF EXCHANGE RATE CHANGES ON CASH AND CASH EQUIVALENTS | (0.1) |  |  | (0.3) |  |
| NET INCREASE (DECREASE) IN CASH AND CASH EQUIVALENTS | 621.3 |  |  | (395.6) |  |
| CASH AND CASH EQUIVALENTS—Beginning of period | 1,682.9 |  |  | 1,319.1 |  |
| CASH AND CASH EQUIVALENTS—End of period | $ | 2,304.2 |  |  | $ | 923.5 |  |

[0001262039-23-000013:8k_2_02:88]
Reconciliations of non-GAAP results of operations measures to the nearest comparable GAAP measures

[0001262039-23-000013:8k_2_02:89]
(Unaudited, in millions, except per share amounts)

[0001262039-23-000013:8k_2_02:90]
Reconciliation of GAAP operating income to non-GAAP operating income, operating margin, net income attributable to Fortinet, Inc. and diluted net income per share attributable to Fortinet, Inc.

[0001262039-23-000013:8k_2_02:91]
|  | Three Months Ended |  |  |
|  | March 31,2023 |  | March 31,2022 |  |  |  |  |
| Reconciliation of non-GAAP operating income: |  |  |  |  |  |  |  |
| GAAP operating income | $ | 273.5 |  |  | $ | 151.0 |  |  |  |  |  |
| GAAP operating margin | 21.7 | % |  | 15.8 | % |  |  |  |  |
| Add back: |  |  |  |  |  |  |  |
| Stock‐based compensation | 57.0 |  |  | 53.9 |  |  |  |  |  |
| Amortization of acquired intangible assets | 4.7 |  |  | 6.4 |  |  |  |  |  |
| Gain on intellectual property matter | (1.2) |  |  | (1.1) |  |  |  |  |  |
| Non‐GAAP operating income | $ | 334.0 |  |  | $ | 210.2 |  |  |  |  |  |
| Non‐GAAP operating margin | 26.5 | % |  | 22.0 | % |  |  |  |  |
| Reconciliation of non-GAAP net income attributable to Fortinet, Inc.: |  |  |  |  |  |  |  |
| GAAP net income attributable to Fortinet, Inc. | $ | 247.7 |  |  | $ | 138.4 |  |  |  |  |  |
| Add back: |  |  |  |  |  |  |  |
| Stock‐based compensation | 57.0 |  |  | 53.9 |  |  |  |  |  |
| Amortization of acquired intangible assets | 4.7 |  |  | 6.4 |  |  |  |  |  |
| Gain on intellectual property matter | (1.2) |  |  | (1.1) |  |  |  |  |  |
| Tax adjustment (a) | (38.5) |  |  | (41.7) |  |  |  |  |  |
| Adjustments attributable non-controlling interests (b) | — |  |  | (0.8) |  |  |  |  |  |
| Non-GAAP net income attributable to Fortinet, Inc. | $ | 269.7 |  |  | $ | 155.1 |  |  |  |  |  |
| Non-GAAP net income per share attributable to Fortinet, Inc., diluted |  |  |  |  |  |  |  |
| Non-GAAP net income attributable to Fortinet, Inc. | $ | 269.7 |  |  | $ | 155.1 |  |  |  |  |  |
| Non-GAAP shares used in diluted net income per share attributable to Fortinet, Inc. calculations (c) | 793.4 |  |  | 820.8 |  |  |  |  |  |
| Non-GAAP net income per share attributable to Fortinet, Inc., diluted (c) | $ | 0.34 |  |  | $ | 0.19 |  |  |  |  |  |
| Reconciliation of non-GAAP net income per share attributable to Fortinet, Inc., diluted |  |  |  |  |  |  |  |
| GAAP net income per share attributable to Fortinet, Inc., diluted (c) | $ | 0.31 |  |  | $ | 0.17 |  |  |  |  |  |
| Add back: |  |  |  |  |  |  |  |
| Non-GAAP adjustments to net income per share attributable to Fortinet, Inc. (c) | 0.03 |  |  | 0.02 |  |  |  |  |  |
| Non-GAAP net income per share attributable to Fortinet, Inc., diluted (c) | $ | 0.34 |  |  | $ | 0.19 |  |  |  |  |  |

[0001262039-23-000013:8k_2_02:92]
(a) Non-GAAP financial information is adjusted to an effective tax rate of 17% in the three months ended March 31, 2023 and 2022, respectively, on a non-GAAP basis, which differs from the GAAP effective tax rate.

[0001262039-23-000013:8k_2_02:93]
(b) Adjustments related to the non-GAAP results attributable to non-controlling interests, which were adjusted to an effective tax rate of 31% for the subsidiary of Alaxala Networks Corporation in the three months ended March 31, 2022.

[0001262039-23-000013:8k_2_02:94]
(c) All share and per share amounts presented herein have been retroactively adjusted to reflect the five-for-one forward stock split which was effective June 22, 2022.

[0001262039-23-000013:8k_2_02:95]
Reconciliation of net cash provided by operating activities to free cash flow

[0001262039-23-000013:8k_2_02:96]
|  | Three Months Ended |
|  | March 31,2023 |  | March 31,2022 |
| Net cash provided by operating activities | $ | 677.5 |  |  | $ | 396.1 |  |
| Less: Purchases of property and equipment | (30.3) |  |  | (122.6) |  |
| Free cash flow | $ | 647.2 |  |  | $ | 273.5 |  |
| Net cash used in investing activities | $ | (42.4) |  |  | $ | (45.4) |  |
| Net cash used in financing activities | $ | (13.7) |  |  | $ | (746.0) |  |

[0001262039-23-000013:8k_2_02:97]
Reconciliation of total revenue to total billings

[0001262039-23-000013:8k_2_02:98]
|  | Three Months Ended |
|  | March 31,2023 |  | March 31,2022 |
| Total revenue | $ | 1,262.3 |  |  | $ | 954.8 |  |
| Add: Change in deferred revenue | 240.6 |  |  | 205.0 |  |
| Total billings | $ | 1,502.9 |  |  | $ | 1,159.8 |  |

[0001262039-23-000013:8k_2_02:99]
| Investor Contact: |  | Media Contact: |
| Peter Salkowski |  | Michelle Zimmermann |
| Fortinet, Inc. |  | Fortinet, Inc. |
| 408-331-4595 |  | 408-235-7700 |
| psalkowski@fortinet.com |  | pr@fortinet.com |
