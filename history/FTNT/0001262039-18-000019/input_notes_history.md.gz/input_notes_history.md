# FTNT note change history — 0001262039-17-000034 → 0001262039-18-000019


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2018-05-08):
[0001262039-18-000019:note_history:1]
The following table summarizes our future principal contractual obligations as of March 31, 2018 (in millions):
  (was, 2017-11-02, similarity 0.9032):
[0001262039-17-000034:note_history:1]
The following table summarizes our future principal contractual obligations as of September 30, 2017 (in thousands):

- changed (2018-05-08):
[0001262039-18-000019:note_history:2]
|  | Total |  | 2018 (remainder) |  | 2019 |  | 2020 |  | 2021 |  | 2022 |  | Thereafter |
| Operating lease commitments | $ | 55.4 |  |  | $ | 12.6 |  |  | $ | 13.9 |  |  | $ | 10.7 |  |  | $ | 6.8 |  |  | $ | 4.2 |  |  | $ | 7.2 |  |
| Inventory purchase commitments | 106.1 |  |  | 101.9 |  |  | — |  |  | 4.2 |  |  | — |  |  | — |  |  | — |  |
| Total | $ | 161.5 |  |  | $ | 114.5 |  |  | $ | 13.9 |  |  | $ | 14.9 |  |  | $ | 6.8 |  |  | $ | 4.2 |  |  | $ | 7.2 |  |
  (was, 2017-11-02, similarity 0.6412):
[0001262039-17-000034:note_history:2]
|  | Total |  | 2017 (remainder) |  | 2018 |  | 2019 |  | 2020 |  | 2021 |  | Thereafter |
| Operating lease commitments | $ | 50,510 |  |  | $ | 3,953 |  |  | $ | 14,022 |  |  | $ | 10,732 |  |  | $ | 8,535 |  |  | $ | 4,557 |  |  | $ | 8,711 |  |
| Inventory purchase commitments | 93,664 |  |  | 89,417 |  |  | 4,247 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Other contractual commitments and open purchase orders | 67,253 |  |  | 40,854 |  |  | 19,651 |  |  | 4,311 |  |  | 2,132 |  |  | 302 |  |  | 3 |  |
| Total | $ | 211,427 |  |  | $ | 134,224 |  |  | $ | 37,920 |  |  | $ | 15,043 |  |  | $ | 10,667 |  |  | $ | 4,859 |  |  | $ | 8,714 |  |

- changed (2018-05-08):
[0001262039-18-000019:note_history:3]
Operating Leases—We lease certain facilities under various non-cancelable operating leases, which expire through 2026. Certain leases require us to pay variable costs such as taxes, maintenance, and insurance. The terms of certain operating leases also provide for renewal options and escalation clauses. Rent expense was $4.1 million and $4.5 million during the three months ended March 31, 2018 and March 31, 2017, respectively. Rent expense is recognized using the straight-line method over the term of the lease.
  (was, 2017-11-02, similarity 0.8536):
[0001262039-17-000034:note_history:3]
Operating Leases—We lease certain facilities under various non-cancelable operating leases, which expire through 2026. Certain leases require us to pay variable costs such as taxes, maintenance, and insurance. The terms of certain operating leases also provide for renewal options and escalation clauses. Rent expense was $4.1 million and $6.1 million during the three months ended September 30, 2017 and September 30, 2016, respectively. Rent expense was $12.5 million and $14.7 million during the nine months ended September 30, 2017 and September 30, 2016, respectively. Rent expense is recognized using the straight-line method over the term of the lease.

- changed (2018-05-08):
[0001262039-18-000019:note_history:4]
Inventory Purchase Commitments—Our independent contract manufacturers procure components and build our products based on our forecasts. These forecasts are based on estimates of future demand for our products, which are in turn based on historical trends and an analysis from our sales and marketing organizations, adjusted for overall market conditions. In order to reduce manufacturing lead times and plan for adequate component supply, we may issue purchase orders to some of our independent contract manufacturers which may not be cancelable. As of March 31, 2018, we had $106.1 million of open purchase orders with our independent contract manufacturers that may not be cancelable.
  (was, 2017-11-02, similarity 0.9897):
[0001262039-17-000034:note_history:4]
Inventory Purchase Commitments—Our independent contract manufacturers procure components and build our products based on our forecasts. These forecasts are based on estimates of future demand for our products, which are in turn based on historical trends and an analysis from our sales and marketing organizations, adjusted for overall market conditions. In order to reduce manufacturing lead times and plan for adequate component supply, we may issue purchase orders to some of our independent contract manufacturers which may not be cancelable. As of September 30, 2017, we had $93.7 million of open purchase orders with our independent contract manufacturers that may not be cancelable.

- changed (2018-05-08):
[0001262039-18-000019:note_history:5]
Other Contractual Commitments and Open Purchase Orders—In addition to commitments with contract manufacturers, we have open purchase orders and contractual obligations in the ordinary course of business for which we have not received goods or services. As of March 31, 2018, we had $10.0 million in other contractual commitments having a remaining term in excess of one year that may not be cancelable.
  (was, 2017-11-02, similarity 0.7215):
[0001262039-17-000034:note_history:5]
Other Contractual Commitments and Open Purchase Orders—In addition to commitments with contract manufacturers, we have open purchase orders and contractual obligations in the ordinary course of business for which we have not received goods or services. As of September 30, 2017, we had $67.3 million in other contractual commitments that may not be cancelable.  Included in other contractual commitments is $8.8 million related to the purchase of certain real estate adjacent to our corporate headquarters.

- changed (2018-05-08):
[0001262039-18-000019:note_history:6]
In October 2016, we received a letter from the United States Attorney’s Office for the Northern District of California requesting information relating to our compliance with the Trade Agreements Act. We have been fully cooperating with this ongoing inquiry and have periodically met and spoken with the United States Attorney’s Office in connection with this matter.
  (was, 2017-11-02, similarity 0.7409):
[0001262039-17-000034:note_history:6]
In October 2016, we received a letter from the United States Attorney’s Office for the Northern District of California requesting information relating to our compliance with the Trade Agreements Act. This inquiry is ongoing and we are fully cooperating with this inquiry.

- changed (2018-05-08):
[0001262039-18-000019:note_history:7]
Indemnification—Under the indemnification provisions of our standard sales contracts, we agree to defend our customers against third-party claims asserting various allegations such as product defects and infringement of certain intellectual property rights, which may include patents, copyrights, trademarks or trade secrets, and to pay judgments entered on such claims. In some contracts, our exposure under these indemnification provisions is limited by the terms of the contracts to certain defined limits, such as the total amount paid by our customer under the agreement. However, certain agreements include covenants, penalties and indemnification provisions including and beyond indemnification for third-party claims of intellectual property infringement, that could potentially expose us to losses in excess of the amount received under the agreement, and in some instances to potential liability that is not contractually limited. To date, there have been no material awards under such indemnification provisions.
  (was, 2017-11-02, similarity 0.9995):
[0001262039-17-000034:note_history:7]
Indemnification—Under the indemnification provisions of our standard sales contracts, we agree to defend our customers against third-party claims asserting various allegations such as product defects and infringement of certain intellectual property rights, which may include patents, copyrights, trademarks or trade secrets, and to pay judgments entered on such claims. In some contracts, our exposure under these indemnification provisions is limited by the terms of the contracts to certain defined limits, such as the total amount paid by our customer under the agreement. However, certain agreements include covenants, penalties and indemnification provisions, including and beyond indemnification for third-party claims of intellectual property infringement, that could potentially expose us to losses in excess of the amount received under the agreement, and in some instances to potential liability that is not contractually limited. To date, there have been no material awards under such indemnification provisions.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2018-05-08):
[0001262039-18-000019:note_history:8]
Basis of Presentation and Preparation—The unaudited condensed consolidated financial statements of Fortinet, Inc. and its wholly owned subsidiaries (collectively, “we,” “us” or “our”) have been prepared in accordance with generally accepted accounting principles in the United States (“GAAP”) for interim financial information, as well as the instructions to Form 10-Q pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (the “SEC”). Accordingly, they do not include all of the information and footnotes required by GAAP for complete financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the year ended December 31, 2017, contained in our Annual Report on Form 10-K filed with the SEC on February 26, 2018. In the opinion of management, all adjustments, which includes normal recurring adjustments, considered necessary for a fair presentation have been included. All intercompany balances, transactions and cash flows have been eliminated. The results of operations for the three months ended March 31, 2018 are not necessarily indicative of the results for the full year or for any future periods. The condensed consolidated balance sheet as of December 31, 2017 is derived from the audited consolidated financial statements for the year ended December 31, 2017.

- changed (2018-05-08):
[0001262039-18-000019:note_history:9]
The preparation of financial statements in accordance with GAAP requires management to make estimates and assumptions that affect the amounts reported in the condensed consolidated financial statements and accompanying notes. Actual results could differ materially from those estimates.
  (was, 2017-11-02, similarity 0.8499):
[0001262039-17-000034:note_history:9]
The preparation of financial statements in accordance with GAAP requires management to make estimates and assumptions that affect the amounts reported in the condensed consolidated financial statements and accompanying notes. Actual results could differ materially from those estimates. Certain amounts in prior periods have been reclassified to conform with current period presentation.

- added (2018-05-08):
[0001262039-18-000019:note_history:10]
There have been no material changes to our significant accounting policies as of and for the three months ended March 31, 2018, except for the accounting policies for revenue recognition, trade receivables and deferred contract costs that were updated as a result of adopting Accounting Standards Update 2014-09, Revenue from Contracts with Customers (Topic 606) (“ASU 2014-09”). For more information, refer to the “Recently Adopted Accounting Standards” and Note 2.

- changed (2018-05-08):
[0001262039-18-000019:note_history:11]
In January 2016, the FASB issued ASU 2016-01—Financial Instruments—Overall: Recognition and Measurement of Financial Assets and Financial Liabilities, which requires most equity investments to be measured at fair value, with subsequent changes in fair value recognized in net income. A practicality exception applies to those equity investments that do not have a readily determinable fair value. These investments may be measured at cost, adjusted for changes in observable prices minus impairment. ASU 2016-01 was effective prospectively for us beginning on January 1, 2018 for our equity investments, which were previously accounted for under the cost-method. We adopted ASU 2016-01 on January 1, 2018. There was no material impact on our condensed consolidated financial statements as of the adoption date.
  (was, 2017-11-02, similarity 0.6511):
[0001262039-17-000034:note_history:11]
In January 2016, the FASB issued ASU 2016-01—Financial Instruments—Overall: Recognition and Measurement of Financial Assets and Financial Liabilities, which requires most equity investments to be measured at fair value, with subsequent changes in fair value recognized in net income. A practicality exception will apply to those equity investments that do not have a readily determinable fair value. These investments may be measured at cost, adjusted for changes in observable prices minus impairment. ASU 2016-01 is effective for our cost-method investments beginning on January 1, 2018 on a prospective basis. The adoption of ASU 2016-01 will result in the adjustment to the carrying amount when the cost-method investees complete a financing round subsequent to adoption date.

- added (2018-05-08):
[0001262039-18-000019:note_history:12]
In May 2014, the FASB issued ASU 2014-09—Revenue from Contracts with Customers (Topic 606), which supersedes the revenue recognition requirements in Topic 605, Revenue Recognition, and requires entities to recognize revenue when control of the promised goods or services is transferred to customers at an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services. We adopted ASU 2014-09 and its related amendments (collectively known as Topic 606) as of January 1, 2018 using the modified retrospective transition method. The comparative information has not been restated and continues to be reported under the accounting standards in effect for those periods.

- added (2018-05-08):
[0001262039-18-000019:note_history:13]
We recorded a net reduction to our accumulated deficit as of January 1, 2018 of $117.3 million due to the cumulative impact of adopting Topic 606. The primary impact of adopting Topic 606 relates to the deferral of our incremental contract costs, which are comprised of sales commissions. Prior to January 1, 2018, we expensed all sales commissions upfront. Beginning on January 1, 2018, we continue to expense sales commissions related to product sales upfront, but will capitalize and then amortize certain sales commissions on service contracts over the applicable amortization period. The capitalized sales commissions for initial service contracts are deferred and then amortized as expense on a straight-line basis over the period of benefit which we have determined to be five years. Sales commissions for renewal contracts are deferred and then amortized on a straight line basis over the contractual period of the underlying contracts. The deferral of sales commissions generated deferred tax liability of $23.8 million, of which $18.0 million was recorded against deferred tax assets and the remaining $5.8 million was recorded in other long-term liabilities on our consolidated balance sheet. The impact on deferred revenue as of January 1, 2018 was $4.1 million, which primarily relates to certain changes in revenue recognition on software license sales and the acceleration of revenue from U.S.-based channel partners which were previously deferred until the product was sold through. Beginning on January 1, 2018, our sales returns reserve is now included on the balance sheet in accrued liabilities and no longer as a reduction to our accounts receivable. See Note 2 for further details.

- added (2018-05-08):
[0001262039-18-000019:note_history:14]
The cumulative effects of the changes made to our January 1, 2018 consolidated balance sheet for the adoption of Topic 606 were as follows (in millions):

- added (2018-05-08):
[0001262039-18-000019:note_history:15]
|  | Balance at December 31, 2017 |  | Adjustments due to Topic 606 |  | Balance at January 1, 2018 |
| Assets: |  |  |  |  |  |
| Accounts receivable, net | $ | 348.2 |  |  | $ | 13.6 |  |  | $ | 361.8 |  |
| Inventory | $ | 77.3 |  |  | $ | (0.1 | ) |  | $ | 77.2 |  |
| Deferred tax assets | $ | 146.9 |  |  | $ | (18.0 | ) |  | $ | 128.9 |  |
| Deferred contract costs | $ | — |  |  | $ | 137.1 |  |  | $ | 137.1 |  |
| Liabilities: |  |  |  |  |  |
| Accrued liabilities | $ | 50.0 |  |  | $ | 13.6 |  |  | $ | 63.6 |  |
| Deferred revenue, current | $ | 793.8 |  |  | $ | 0.3 |  |  | $ | 794.1 |  |
| Deferred revenue, non-current | $ | 542.5 |  |  | $ | (4.4 | ) |  | $ | 538.1 |  |
| Other liabilities, non-current | $ | 8.6 |  |  | $ | 5.8 |  |  | $ | 14.4 |  |
| Stockholders’ equity: |  |  |  |  |  |
| Accumulated deficit | $ | (319.6 | ) |  | $ | 117.3 |  |  | $ | (202.3 | ) |

- added (2018-05-08):
[0001262039-18-000019:note_history:16]
In February 2016, the FASB issued ASU 2016-02—Leases, which requires the recognition of right-of-use assets and lease liabilities on the consolidated balance sheet for substantially all leases. ASU 2016-02 includes a number of optional practical expedients that entities may elect to apply. ASU 2016-02 will also require significant additional disclosures about the amount, timing and uncertainty of cash flows from leases. ASU 2016-02 will be effective for us beginning on January 1, 2019, using a modified retrospective approach. Based on our current lease portfolio, we currently estimate the value of leased assets and liabilities that may be recognized on the consolidated balance sheet to be at least $45.0 million. We are continuing to evaluate the impact of ASU 2016-02 and our estimate is subject to change. We do not believe that ASU 2016-02 will have a material impact on our consolidated statements of operations and cash flows. We expect to expand our disclosures in the notes to consolidated financial statements to include more details on our leases, significant judgments and lease-related amounts recognized in the consolidated financial statements.

- removed (2018-05-08):
[0001262039-17-000034:note_history:17]
Basis of Presentation and Preparation—The unaudited condensed consolidated financial statements of Fortinet, Inc. and its wholly owned subsidiaries (collectively, “we,” “us” or “our”) have been prepared in accordance with generally accepted accounting principles in the United States (“GAAP”) for interim financial information, as well as the instructions to Form 10-Q pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (the “SEC”). Accordingly, they do not include all of the information and footnotes required by GAAP for complete financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the year ended December 31, 2016, contained in our Annual Report on Form 10-K filed with the SEC on March 1, 2017. In the opinion of management, all adjustments, which includes normal recurring adjustments, considered necessary for a fair presentation have been included. All intercompany balances, transactions and cash flows have been eliminated. The results of operations for the three and nine months ended September 30, 2017 are not necessarily indicative of the results for the full year or for any future periods. The condensed consolidated balance sheet as of December 31, 2016 is derived from the audited consolidated financial statements for the year ended December 31, 2016.

- removed (2018-05-08):
[0001262039-17-000034:note_history:18]
There have been no material changes to our significant accounting policies as of and for the three and nine months ended September 30, 2017, except for changes to our policies related to business combinations. For more information, refer to the “Recently Adopted Accounting Standards.”

- removed (2018-05-08):
[0001262039-17-000034:note_history:19]
Business Combinations – Definition of a Business

- removed (2018-05-08):
[0001262039-17-000034:note_history:20]
In January 2017, the Financial Accounting Standards Board (the “FASB”) issued Accounting Standards Update (“ASU”) ASU 2017-01—Business Combinations: Clarifying the Definition of a Business, which clarifies the definition of a business to assist organizations with evaluating whether transactions should be accounted for as acquisitions (or disposals) of assets or businesses. The definition of a business affects many areas of accounting including acquisitions, disposals, goodwill and consolidation. We elected to early adopt ASU 2017-01 on a prospective basis beginning on January 1, 2017. The adoption of ASU 2017-01 did not have a material impact on our consolidated financial statements.

- removed (2018-05-08):
[0001262039-17-000034:note_history:21]
Share-Based Payment Accounting

- removed (2018-05-08):
[0001262039-17-000034:note_history:22]
In May 2017, the FASB issued ASU 2017-09—Compensation—Stock Compensation to clarify when to account for a change to the terms or conditions of a share-based payment award as a modification. Under ASU 2017-09, modification accounting is required only if the fair value, the vesting conditions or the classification of the award (as equity or liability) changes as a result of the change in terms or conditions. ASU 2017-09 is effective prospectively for us beginning on January 1, 2018. We do not believe ASU 2017-09 will have a material impact on our consolidated financial statements.

- removed (2018-05-08):
[0001262039-17-000034:note_history:23]
Goodwill Impairment

- removed (2018-05-08):
[0001262039-17-000034:note_history:24]
In January 2017, the FASB issued ASU 2017-04—Intangibles—Goodwill and Other: Simplifying the Test for Goodwill Impairment. ASU 2017-04 eliminates Step 2 from the goodwill impairment test which measures a goodwill impairment loss by comparing the implied fair value of a reporting unit’s goodwill with the carrying amount of that goodwill. Under ASU 2017-04, an entity should perform its annual or interim goodwill impairment test by comparing the fair value of the reporting unit with its carrying amount, and should recognize an impairment loss for the amount by which the carrying amount exceeds the reporting unit’s fair value, with the loss not exceeding the total amount of goodwill allocated to that reporting unit. ASU 2017-04 will be effective for us beginning on January 1, 2020. Early adoption is permitted for interim or annual goodwill impairment tests performed after January 1, 2017. At adoption, this update will require a prospective approach. We early adopted ASU 2017-04 on October 1, 2017. The adoption did not have a material impact on our consolidated financial statements.

- removed (2018-05-08):
[0001262039-17-000034:note_history:25]
Income Taxes – Intra-Entity Asset Transfers

- removed (2018-05-08):
[0001262039-17-000034:note_history:26]
In October 2016, the FASB issued ASU 2016-16—Income Taxes: Intra-Entity Transfer of Assets Other Than Inventory, which requires the recognition of the income tax consequences of an intra-entity transfer of an asset, other than inventory, when the transfer occurs. ASU 2016-16 will be effective for us beginning on January 1, 2018. We are currently evaluating the impact of ASU 2016-16 on our consolidated financial statements.

- removed (2018-05-08):
[0001262039-17-000034:note_history:27]
Financial Instruments – Credit Losses

- removed (2018-05-08):
[0001262039-17-000034:note_history:28]
In June 2016, the FASB issued ASU 2016-13—Financial Instruments—Credit Losses—Measurement of Credit Losses on Financial Instruments, which requires measurement and recognition of expected credit losses for financial assets held. ASU 2016-13 is effective for us beginning on January 1, 2020, with the option to adopt early on January 1, 2019. Based on our current accounts receivable portfolio, we do not believe ASU 2016-13 will have a material impact on our consolidated financial statements.

- removed (2018-05-08):
[0001262039-17-000034:note_history:29]
In February 2016, the FASB issued ASU 2016-02—Leases, which requires the recognition of right-of-use assets and lease liabilities on the consolidated balance sheet for substantially all leases. The new guidance includes a number of optional practical expedients that entities may elect to apply. The new guidance will also require significant additional disclosures about the amount, timing and uncertainty of cash flows from leases. This new guidance will be effective for us beginning on January 1, 2019, using a modified retrospective approach. Based on our current lease portfolio, we currently estimate that the value of leased assets and liabilities that may be recognized to be at least $40.0 million. We are continuing to evaluate the impact of ASU 2016-02 and our estimate is subject to change. We do not believe that ASU 2016-02 will have a material impact on our consolidated statements of operations. We expect to expand our disclosures in the notes to consolidated financial statements include more details on our leases, significant judgments and lease-related amounts recognized in the consolidated financial statements.

- removed (2018-05-08):
[0001262039-17-000034:note_history:30]
In May 2014, the FASB issued ASU 2014-09—Revenue from Contracts with Customers, which outlines a single, comprehensive model for entities to use in accounting for revenue arising from contracts with customers. The core principle of ASU 2014-09 is to recognize revenue when promised goods or services are transferred to customers in an amount that reflects the consideration that is expected to be received for those goods or services. ASU 2014-09 defines a five-step process to achieve this core principle and, accordingly, we expect more judgment and estimates may be required within the revenue recognition process than is required under existing U.S. GAAP, including identifying performance obligations in the contract, estimating the amount of variable consideration to include in the transaction price and allocating the transaction price to each separate performance obligation. ASU 2014-09 will be effective for us beginning January 1, 2018. ASU 2014-09 permits two methods of adoption: retrospectively to each prior reporting period presented (the full retrospective method), or retrospectively with the cumulative effect of initially applying the guidance recognized at the date of initial application (the modified retrospective method). We will adopt the standard using the modified retrospective method and apply the standard to contracts that are not completed as of January 1, 2018, and recognize the cumulative effect of initially applying the standard as an adjustment to the opening balance of retained earnings.

- removed (2018-05-08):
[0001262039-17-000034:note_history:31]
We have substantially completed our analysis of historical contracts and believe that the quantitative impact on revenue in our consolidated financial statements is not material. We expect the pattern of revenue recognition from the sales of our FortiGate and other appliances and FortiGuard and FortiCare subscription services to be substantially unchanged on an ongoing basis. We believe that the acceleration of revenue and associated cost of sales to certain channel partners which are currently accounted for only once the product is sold through to the end-customer, and the allocation of revenue related to software due to the removal of the residual method will not have a significant impact on our financial statements.

- removed (2018-05-08):
[0001262039-17-000034:note_history:32]
Under ASU 2014-09, we will be required to capitalize and amortize incremental costs related to obtaining customer contracts, such as sales commission costs related to service contracts. Under current U.S. GAAP, we expense all sales commissions when incurred. Our quantitative analysis of the impact of the change in accounting for sales commissions, including the various components of our current and future compensation plans and the key assumptions associated with the amortization term, is in progress. We believe that the amortization of incremental commission costs of obtaining customer contracts is likely to have a material impact on our financial statements.

- removed (2018-05-08):
[0001262039-17-000034:note_history:33]
We expect to expand our financial statement disclosures, which may include more details on our disaggregation of revenue, performance obligations, contract balances and costs to obtain a contract, as well as any significant judgments. We are in the process of documenting process changes, implementing required changes in our systems and developing new controls to support recognition and disclosure under ASU 2014-09. Reviews are ongoing, which may alter our conclusions and the anticipated financial impact. We will continue to assess the impact of ASU 2014-09, along with industry trends until the adoption date.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: no_current_note, score: 0.0

- removed (2018-05-08):
[0001262039-17-000034:note_history:34]
RELATED PARTY TRANSACTIONS

- removed (2018-05-08):
[0001262039-17-000034:note_history:35]
The son of one member of our board of directors is a partner of an outside law firm that we utilize for certain complex litigation matters. Expenses for legal services provided by the law firm were $0.4 million and $0.1 million during the three months ended September 30, 2017 and September 30, 2016, respectively. Expenses for legal services provided by the law firm were $0.9 million and $0.3 million during the nine months ended September 30, 2017 and September 30, 2016, respectively. Amounts due and payable to the law firm were $0.5 million and $0.1 million as of September 30, 2017 and December 31, 2016, respectively.


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: no_prior_note, score: 0.0

- added (2018-05-08):
[0001262039-18-000019:note_history:36]
Disaggregation of Revenue

- added (2018-05-08):
[0001262039-18-000019:note_history:37]
The following table presents our revenue disaggregated by major product and service lines (in millions):

- added (2018-05-08):
[0001262039-18-000019:note_history:38]
|  | Three Months Ended |
|  | March 31, 2018 |  | March 31, 2017 (1) |
| Product | $ | 142.8 |  |  | $ | 135.3 |  |
| Service: |  |  |  |
| Security subscription | 136.6 |  |  | 113.5 |  |
| Technical support | 109.6 |  |  | 81.1 |  |
| Professional services and training | 10.0 |  |  | 10.7 |  |
| Total service revenue | 256.2 |  |  | 205.3 |  |
| Total revenue | $ | 399.0 |  |  | $ | 340.6 |  |
| (1) As noted above, prior period amounts have not been adjusted under the modified retrospective method. |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: no_prior_note, score: 0.0

- added (2018-05-08):
[0001262039-18-000019:note_history:39]
REVENUE RECOGNITION

- added (2018-05-08):
[0001262039-18-000019:note_history:40]
Revenue recognition

- added (2018-05-08):
[0001262039-18-000019:note_history:41]
On January 1, 2018 we adopted Topic 606 using the modified retrospective method applied to those contracts which were not completed as of January 1, 2018. Results for reporting periods beginning after January 1, 2018 are presented under Topic 606, while prior period amounts are not adjusted and continue to be reported under Topic 605. The details of significant changes and quantitative impact of the changes are discussed below.

- added (2018-05-08):
[0001262039-18-000019:note_history:42]
We derive the majority of our revenue from sales of our products, FortiGuard security subscription and FortiCare technical support services, and other services. Beginning in 2018, revenues are recognized when control of these goods or services is transferred to our customers, in an amount that reflects the consideration we expect to be entitled to in exchange for those goods or services. Prior to 2018, revenue was recognized under Topic 605 when all of the following criteria were met: (i) persuasive evidence of an arrangement existed, (ii) delivery has occurred or services have been rendered, (iii) sales price was fixed or determinable and (iv) collectability was reasonably assured.

- added (2018-05-08):
[0001262039-18-000019:note_history:43]
Under Topic 606, we determine revenue recognition through the following steps:

- added (2018-05-08):
[0001262039-18-000019:note_history:44]
•identification of the contract, or contracts, with the customer,

- added (2018-05-08):
[0001262039-18-000019:note_history:45]
•identification of the performance obligations in the contract,

- added (2018-05-08):
[0001262039-18-000019:note_history:46]
•determination of the transaction price,

- added (2018-05-08):
[0001262039-18-000019:note_history:47]
•allocation of the transaction price to the performance obligations in the contract, and

- added (2018-05-08):
[0001262039-18-000019:note_history:48]
•recognition of revenue when, or as, we satisfy a performance obligation.

- added (2018-05-08):
[0001262039-18-000019:note_history:49]
Product revenue primarily consists of sales of hardware and software licenses of our FortiGate, FortiSandbox, FortiManager, FortiAnalyzer and other complimentary products. We derive a substantial majority of product sales from our FortiGate products. We previously recognized product revenue for sales to distributors that had no general right of return and direct sales to end-customers upon shipment, based on general revenue recognition accounting guidance once all other revenue recognition criteria were met. Certain distributors are granted stock rotation rights, limited rights of return or rebates for sales of our products. The arrangement fee for this group of distributors was not fixed or determinable when products were shipped and revenue was therefore deferred and recognized upon sell-through. For sales that included end-customer acceptance criteria, revenue was recognized upon acceptance. Under Topic 606, we recognize product revenue upon shipment when control of the promised goods is transferred to the customer. We recognize revenue from time-based software licenses upon electronic transfer of the license key to the customer. Previously time-based software licenses were recognized over the license term.

- added (2018-05-08):
[0001262039-18-000019:note_history:50]
We generally provide a 1-year warranty on hardware products and a 90-day warranty on software that provides assurance that our hardware or software products conform to published specifications. Such assurance-type warranties are not deemed to be separate performance obligations from the hardware or software product and costs associated with providing the warranties are accrued in accordance with ASC 460-10.

- added (2018-05-08):
[0001262039-18-000019:note_history:51]
Service revenue relates to sales of our FortiGuard security subscription, FortiCare technical support services, and other services. Our FortiGuard security subscription services provide access to our antivirus, intrusion prevention, web filtering and anti-spam functionality. Our FortiCare support services include rights to unspecified software upgrades, maintenance releases and patches, telephone and internet access to technical support personnel. Our typical subscription and contractual support term is one to three years, and to a lesser extent, five years. Our revenue recognition for service arrangements did not change under Topic 606. We continue to recognize revenue from these arrangements ratably over the contractual service period because of continuous transfer of control to the customer. Revenue related to subsequent renewals of these services are recognized over the term of the renewal agreement. We also generate a small portion of our revenue from other services consisting of professional services, training and software-as-a-service (“SaaS”) which is either hosted or cloud-based services. We recognize revenue from professional and training services as the services are provided. We recognize revenue from SaaS as the subscription service is delivered over the term, which is typically one year, or on a monthly usage basis. Our revenue recognition for other services did not change under Topic 606. To date, SaaS revenue has not represented a significant percentage of our total revenue.

- added (2018-05-08):
[0001262039-18-000019:note_history:52]
Our sales arrangements typically contain multiple performance obligations, such as hardware, software license, security subscription, technical support services and other services, which are generally capable of being distinct and accounted for as separate performance obligations. We allocate the transaction price to each performance obligation based on relative standalone selling price. We determine standalone selling price based on the historical pricing and discounting practices for those services when sold separately. We determine standalone selling price for a product or service by considering multiple historical factors including, but not limited to, cost of products, gross margin objectives, pricing practices, geographies and the term of the service contract that fall within a reasonably range as a percentage of list price. Revenue is reported net of sales taxes.

- added (2018-05-08):
[0001262039-18-000019:note_history:53]
Under Topic 605, our products and services in a multiple-element arrangement generally qualified as separate units of accounting. We allocated revenue to each unit of accounting based on an estimated selling price using vendor-specific objective evidence (“VSOE”) of selling price, if it existed, or third-party evidence (“TPE”) of selling price. If neither VSOE nor TPE of selling price existed for a deliverable, we used our best estimate of selling price for that deliverable. For multiple-element arrangements where software deliverables were included, revenue was allocated to the non-software deliverables and to the software deliverables as a group using the relative estimated selling prices of each of the deliverables in the arrangement based on the estimated selling price hierarchy. The amount allocated to the software deliverables was then allocated to each software deliverable using the residual method when VSOE of fair value existed. If evidence of VSOE of fair value of one or more undelivered elements did not exist, all software allocated revenue was deferred and recognized when delivery of those elements occurred or when fair value was established. When the undelivered element for which we did not have VSOE of fair value was support, revenue for the entire arrangement was recognized ratably over the support period. The same residual method and VSOE of fair value principles applied for our multiple element arrangements that contained only software elements.

- added (2018-05-08):
[0001262039-18-000019:note_history:54]
In certain circumstances, our contracts include provisions for sales rebates and other customer incentive programs.  Additionally, in limited circumstances, we may permit end-customers, distributors and resellers to return our products, subject to varying limitations, for a refund within a reasonably short period from the date of purchase. These amounts are accounted for as variable consideration that can decrease the transaction price. We estimate variable consideration at the most likely amounts to which we expect our customers to be entitled. We include estimated amounts in the transaction price to the extent that it is probable that a significant reversal of cumulative revenue recognized will not occur when the uncertainty associated with the variable consideration is resolved. Our estimate for sales return reserve was $12.9 million as of March 31, 2018 and is included in current liabilities in our condensed consolidated balance sheet. Under Topic 605, a sales return reserve of $13.6 million was presented as a reduction to accounts receivable as of December 31, 2017.

- added (2018-05-08):
[0001262039-18-000019:note_history:55]
We generally invoice at the time of our sale for the total price of the products and security and technical support and other services, and the invoice is payable within 30 to 90 days. We also invoice certain software licenses and services on a monthly basis. Amounts billed and due from our customers are classified as receivables on the balance sheet and do not bear interest. We record deferred revenue when cash payments are received or due in advance of our performance.

- added (2018-05-08):
[0001262039-18-000019:note_history:56]
During the three months ended March 31, 2018, we recognized $239.1 million in revenue that was included in the deferred revenue balance as of December 31, 2017.

- added (2018-05-08):
[0001262039-18-000019:note_history:57]
Shipping and handling fees charged to our customers are recognized as product revenue in the period shipped and the related costs for providing these services are recorded as a cost of sale. Shipping and handling fees recognized as product revenue were not significant during the three months ended March 31, 2018 and 2017.

- added (2018-05-08):
[0001262039-18-000019:note_history:58]
Disaggregation of Revenue

- added (2018-05-08):
[0001262039-18-000019:note_history:59]
The following table presents our revenue disaggregated by major product and service lines (in millions):

- added (2018-05-08):
[0001262039-18-000019:note_history:60]
|  | Three Months Ended |
|  | March 31, 2018 |  | March 31, 2017 (1) |
| Product | $ | 142.8 |  |  | $ | 135.3 |  |
| Service: |  |  |  |
| Security subscription | 136.6 |  |  | 113.5 |  |
| Technical support | 109.6 |  |  | 81.1 |  |
| Professional services and training | 10.0 |  |  | 10.7 |  |
| Total service revenue | 256.2 |  |  | 205.3 |  |
| Total revenue | $ | 399.0 |  |  | $ | 340.6 |  |
| (1) As noted above, prior period amounts have not been adjusted under the modified retrospective method. |

- added (2018-05-08):
[0001262039-18-000019:note_history:61]
Transaction Price Allocated to the Remaining Performance Obligations

- added (2018-05-08):
[0001262039-18-000019:note_history:62]
As of March 31, 2018, we had $1.40 billion in remaining performance obligations, which is substantially comprised of deferred security subscription and technical support services not yet delivered. We expect to recognize revenue on approximately 75% of these remaining performance obligations over the next one to two years, with the remaining balance to be recognized in three to five years.

- added (2018-05-08):
[0001262039-18-000019:note_history:63]
Accounts Receivable

- added (2018-05-08):
[0001262039-18-000019:note_history:64]
Trade accounts receivable are recorded at the invoiced amount. Trade accounts receivable is reduced by allowance for doubtful accounts which is determined based on our assessment of the collectability of customer accounts. The allowance for doubtful accounts was $0.7 million and $0.9 million as of March 31, 2018 and December 31, 2017, respectively. As of December 31, 2017, accounts receivable was also reduced by sales return reserve of $13.6 million which we reclassified to accrued liabilities account as of January 1, 2018 in accordance with the adoption of Topic 606.

- added (2018-05-08):
[0001262039-18-000019:note_history:65]
Contract Assets

- added (2018-05-08):
[0001262039-18-000019:note_history:66]
Contract assets represent amounts that have been recognized as revenue but for which we did not have the unconditional right to invoice the customer. We did not have contract assets as of March 31, 2018 and January 1, 2018.

- added (2018-05-08):
[0001262039-18-000019:note_history:67]
Deferred Contract Costs

- added (2018-05-08):
[0001262039-18-000019:note_history:68]
Sales commissions earned by our sales force are considered incremental and recoverable costs of obtaining a contract with a customer. Sales commissions for the sale of products are recognized at the time of sale. Sales commissions for initial service contracts are deferred and then amortized as an expense on a straight-line basis over the period of benefit which we have determined to be five years. We determined the period of benefit taking into consideration our customer contracts, our technology and other factors. Sales commissions for renewal contracts are deferred and then amortized on a straight line basis over the contractual period of the underlying contracts which ranges from one to three years and, to a lesser extent, five years. The amortization of deferred commissions is included in sales and marketing expense in our condensed consolidated statement of operations. Amortization of deferred contract costs during the three months ended March 31, 2018 was $20.8 million. No impairment loss was recognized during the three months ended March 31, 2018.

- added (2018-05-08):
[0001262039-18-000019:note_history:69]
Practical Expedient

- added (2018-05-08):
[0001262039-18-000019:note_history:70]
We elected to use the contract modification practical expedient. This practical expedient allows for all contract modifications before January 1, 2018 to be aggregated and evaluated at adoption date.

- added (2018-05-08):
[0001262039-18-000019:note_history:71]
Impact on Condensed Consolidated Financial Statements

- added (2018-05-08):
[0001262039-18-000019:note_history:72]
The following tables summarize the impact of adopting Topic 606 on our condensed consolidated financial statements as of and for the three months ended March 31, 2018 (in millions). These tables do not represent the full condensed consolidated financial statements as they only reflect the accounts impacted by the adoption of Topic 606.

- added (2018-05-08):
[0001262039-18-000019:note_history:73]
Condensed Consolidated Balance Sheet

- added (2018-05-08):
[0001262039-18-000019:note_history:74]
|  | As of March 31, 2018 |
|  | As Reported |  | Balances Without Adoption of Topic 606 |  | Effect of ChangeIncrease (Decrease) |
| Assets: |  |  |  |  |  |
| Accounts receivable | $ | 313.1 |  |  | $ | 300.2 |  |  | $ | 12.9 |  |
| Inventory | $ | 80.0 |  |  | $ | 81.5 |  |  | $ | (1.5 | ) |
| Deferred contract costs | $ | 148.7 |  |  | $ | — |  |  | $ | 148.7 |  |
| Deferred tax assets | $ | 138.7 |  |  | $ | 160.6 |  |  | $ | (21.9 | ) |
| Liabilities: |  |  |  |  |  |
| Accrued liabilities | $ | 55.6 |  |  | $ | 40.6 |  |  | $ | 15.0 |  |
| Deferred revenue, current | $ | 817.1 |  |  | $ | 828.8 |  |  | $ | (11.7 | ) |
| Deferred revenue, non-current | $ | 579.3 |  |  | $ | 580.2 |  |  | $ | (0.9 | ) |
| Other liabilities, non-current | $ | 13.4 |  |  | $ | 7.6 |  |  | $ | 5.8 |  |
| Stockholders’ Equity |  |  |  |  |  |
| Accumulated deficit | $ | (262.6 | ) |  | $ | (392.6 | ) |  | $ | 130.0 |  |

- added (2018-05-08):
[0001262039-18-000019:note_history:75]
Condensed Consolidated Statement of Operations

- added (2018-05-08):
[0001262039-18-000019:note_history:76]
|  | Three Months Ended March 31, 2018 |
|  | As Reported |  | Balances Without Adoption of Topic 606 |  | Effect of ChangeIncrease (Decrease) |
| REVENUE: |  |  |  |  |  |
| Product | $ | 142.8 |  |  | $ | 137.1 |  |  | $ | 5.7 |  |
| Service | 256.2 |  |  | 255.5 |  |  | 0.7 |  |
| Total revenue | 399.0 |  |  | 392.6 |  |  | 6.4 |  |
| COSTS OF REVENUE: |  |  |  |  |  |
| Product | 58.2 |  |  | 56.7 |  |  | 1.5 |  |
| GROSS PROFIT: |  |  |  |  |  |
| Product | 84.6 |  |  | 80.4 |  |  | 4.2 |  |
| Service | 217.2 |  |  | 216.5 |  |  | 0.7 |  |
| Total gross profit | 301.8 |  |  | 296.9 |  |  | 4.9 |  |
| OPERATING EXPENSES: |  |  |  |  |  |
| Sales and marketing expenses | 185.3 |  |  | 197.0 |  |  | (11.7 | ) |
| OPERATING INCOME | 32.4 |  |  | 15.8 |  |  | 16.6 |  |
| INCOME BEFORE INCOME TAXES | 36.7 |  |  | 20.1 |  |  | 16.6 |  |
| BENEFIT FROM INCOME TAXES | (4.9 | ) |  | (8.7 | ) |  | 3.8 |  |
| NET INCOME | $ | 41.6 |  |  | $ | 28.8 |  |  | $ | 12.8 |  |
| Net income per share: |  |  |  |  |  |
| Basic | $ | 0.25 |  |  | $ | 0.17 |  |  | $ | 0.08 |  |
| Diluted | $ | 0.24 |  |  | $ | 0.17 |  |  | $ | 0.07 |  |

- added (2018-05-08):
[0001262039-18-000019:note_history:77]
Condensed Consolidated Statement of Cash Flows

- added (2018-05-08):
[0001262039-18-000019:note_history:78]
|  | Three Months Ended March 31, 2018 |
|  | As Reported |  | Balances Without Adoption of Topic 606 |  | Effect of ChangeIncrease (Decrease) |
| Cash flows from operating activities: |  |  |  |  |  |
| Net income | $ | 41.6 |  |  | $ | 28.8 |  |  | $ | 12.8 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |
| Amortization of deferred contract costs | 20.8 |  |  | — |  |  | 20.8 |  |
| Other non-cash | 0.3 |  |  | 0.9 |  |  | (0.6 | ) |
| Changes in operating assets and liabilities: |  |  |  |  |  |  |
| Inventory | (7.3 | ) |  | (8.7 | ) |  | 1.4 |  |
| Deferred contract costs | (32.5 | ) |  | — |  |  | (32.5 | ) |
| Deferred tax assets | (9.6 | ) |  | (13.6 | ) |  | 4.0 |  |
| Accrued liabilities | (4.7 | ) |  | (6.1 | ) |  | 1.4 |  |
| Deferred revenue | 64.1 |  |  | 71.4 |  |  | (7.3 | ) |
| Net cash provided by operating activities | $ | 139.7 |  |  | $ | 139.7 |  |  | $ | — |  |


## us-gaap:RevenueRecognitionPolicyTextBlock (revenue_recognition_policy) — matched_by: no_prior_note, score: 0.0

- added (2018-05-08):
[0001262039-18-000019:note_history:79]
Revenue recognition

- added (2018-05-08):
[0001262039-18-000019:note_history:80]
On January 1, 2018 we adopted Topic 606 using the modified retrospective method applied to those contracts which were not completed as of January 1, 2018. Results for reporting periods beginning after January 1, 2018 are presented under Topic 606, while prior period amounts are not adjusted and continue to be reported under Topic 605. The details of significant changes and quantitative impact of the changes are discussed below.

- added (2018-05-08):
[0001262039-18-000019:note_history:81]
We derive the majority of our revenue from sales of our products, FortiGuard security subscription and FortiCare technical support services, and other services. Beginning in 2018, revenues are recognized when control of these goods or services is transferred to our customers, in an amount that reflects the consideration we expect to be entitled to in exchange for those goods or services. Prior to 2018, revenue was recognized under Topic 605 when all of the following criteria were met: (i) persuasive evidence of an arrangement existed, (ii) delivery has occurred or services have been rendered, (iii) sales price was fixed or determinable and (iv) collectability was reasonably assured.

- added (2018-05-08):
[0001262039-18-000019:note_history:82]
Under Topic 606, we determine revenue recognition through the following steps:

- added (2018-05-08):
[0001262039-18-000019:note_history:83]
•identification of the contract, or contracts, with the customer,

- added (2018-05-08):
[0001262039-18-000019:note_history:84]
•identification of the performance obligations in the contract,

- added (2018-05-08):
[0001262039-18-000019:note_history:85]
•determination of the transaction price,

- added (2018-05-08):
[0001262039-18-000019:note_history:86]
•allocation of the transaction price to the performance obligations in the contract, and

- added (2018-05-08):
[0001262039-18-000019:note_history:87]
•recognition of revenue when, or as, we satisfy a performance obligation.

- added (2018-05-08):
[0001262039-18-000019:note_history:88]
Product revenue primarily consists of sales of hardware and software licenses of our FortiGate, FortiSandbox, FortiManager, FortiAnalyzer and other complimentary products. We derive a substantial majority of product sales from our FortiGate products. We previously recognized product revenue for sales to distributors that had no general right of return and direct sales to end-customers upon shipment, based on general revenue recognition accounting guidance once all other revenue recognition criteria were met. Certain distributors are granted stock rotation rights, limited rights of return or rebates for sales of our products. The arrangement fee for this group of distributors was not fixed or determinable when products were shipped and revenue was therefore deferred and recognized upon sell-through. For sales that included end-customer acceptance criteria, revenue was recognized upon acceptance. Under Topic 606, we recognize product revenue upon shipment when control of the promised goods is transferred to the customer. We recognize revenue from time-based software licenses upon electronic transfer of the license key to the customer. Previously time-based software licenses were recognized over the license term.

- added (2018-05-08):
[0001262039-18-000019:note_history:89]
We generally provide a 1-year warranty on hardware products and a 90-day warranty on software that provides assurance that our hardware or software products conform to published specifications. Such assurance-type warranties are not deemed to be separate performance obligations from the hardware or software product and costs associated with providing the warranties are accrued in accordance with ASC 460-10.

- added (2018-05-08):
[0001262039-18-000019:note_history:90]
Service revenue relates to sales of our FortiGuard security subscription, FortiCare technical support services, and other services. Our FortiGuard security subscription services provide access to our antivirus, intrusion prevention, web filtering and anti-spam functionality. Our FortiCare support services include rights to unspecified software upgrades, maintenance releases and patches, telephone and internet access to technical support personnel. Our typical subscription and contractual support term is one to three years, and to a lesser extent, five years. Our revenue recognition for service arrangements did not change under Topic 606. We continue to recognize revenue from these arrangements ratably over the contractual service period because of continuous transfer of control to the customer. Revenue related to subsequent renewals of these services are recognized over the term of the renewal agreement. We also generate a small portion of our revenue from other services consisting of professional services, training and software-as-a-service (“SaaS”) which is either hosted or cloud-based services. We recognize revenue from professional and training services as the services are provided. We recognize revenue from SaaS as the subscription service is delivered over the term, which is typically one year, or on a monthly usage basis. Our revenue recognition for other services did not change under Topic 606. To date, SaaS revenue has not represented a significant percentage of our total revenue.

- added (2018-05-08):
[0001262039-18-000019:note_history:91]
Our sales arrangements typically contain multiple performance obligations, such as hardware, software license, security subscription, technical support services and other services, which are generally capable of being distinct and accounted for as separate performance obligations. We allocate the transaction price to each performance obligation based on relative standalone selling price. We determine standalone selling price based on the historical pricing and discounting practices for those services when sold separately. We determine standalone selling price for a product or service by considering multiple historical factors including, but not limited to, cost of products, gross margin objectives, pricing practices, geographies and the term of the service contract that fall within a reasonably range as a percentage of list price. Revenue is reported net of sales taxes.

- added (2018-05-08):
[0001262039-18-000019:note_history:92]
Under Topic 605, our products and services in a multiple-element arrangement generally qualified as separate units of accounting. We allocated revenue to each unit of accounting based on an estimated selling price using vendor-specific objective evidence (“VSOE”) of selling price, if it existed, or third-party evidence (“TPE”) of selling price. If neither VSOE nor TPE of selling price existed for a deliverable, we used our best estimate of selling price for that deliverable. For multiple-element arrangements where software deliverables were included, revenue was allocated to the non-software deliverables and to the software deliverables as a group using the relative estimated selling prices of each of the deliverables in the arrangement based on the estimated selling price hierarchy. The amount allocated to the software deliverables was then allocated to each software deliverable using the residual method when VSOE of fair value existed. If evidence of VSOE of fair value of one or more undelivered elements did not exist, all software allocated revenue was deferred and recognized when delivery of those elements occurred or when fair value was established. When the undelivered element for which we did not have VSOE of fair value was support, revenue for the entire arrangement was recognized ratably over the support period. The same residual method and VSOE of fair value principles applied for our multiple element arrangements that contained only software elements.

- added (2018-05-08):
[0001262039-18-000019:note_history:93]
In certain circumstances, our contracts include provisions for sales rebates and other customer incentive programs.  Additionally, in limited circumstances, we may permit end-customers, distributors and resellers to return our products, subject to varying limitations, for a refund within a reasonably short period from the date of purchase. These amounts are accounted for as variable consideration that can decrease the transaction price. We estimate variable consideration at the most likely amounts to which we expect our customers to be entitled. We include estimated amounts in the transaction price to the extent that it is probable that a significant reversal of cumulative revenue recognized will not occur when the uncertainty associated with the variable consideration is resolved. Our estimate for sales return reserve was $12.9 million as of March 31, 2018 and is included in current liabilities in our condensed consolidated balance sheet. Under Topic 605, a sales return reserve of $13.6 million was presented as a reduction to accounts receivable as of December 31, 2017.

- added (2018-05-08):
[0001262039-18-000019:note_history:94]
We generally invoice at the time of our sale for the total price of the products and security and technical support and other services, and the invoice is payable within 30 to 90 days. We also invoice certain software licenses and services on a monthly basis. Amounts billed and due from our customers are classified as receivables on the balance sheet and do not bear interest. We record deferred revenue when cash payments are received or due in advance of our performance.

- added (2018-05-08):
[0001262039-18-000019:note_history:95]
During the three months ended March 31, 2018, we recognized $239.1 million in revenue that was included in the deferred revenue balance as of December 31, 2017.

- added (2018-05-08):
[0001262039-18-000019:note_history:96]
Shipping and handling fees charged to our customers are recognized as product revenue in the period shipped and the related costs for providing these services are recorded as a cost of sale. Shipping and handling fees recognized as product revenue were not significant during the three months ended March 31, 2018 and 2017.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_current_note, score: 0.0

- removed (2018-05-08):
[0001262039-17-000034:note_history:97]
SUBSEQUENT EVENT

- removed (2018-05-08):
[0001262039-17-000034:note_history:98]
In October 2017, our board of directors approved a $400.0 million increase to authorized stock repurchases under the Repurchase Program, bringing the aggregate amount authorized to be repurchased to $1.0 billion.
