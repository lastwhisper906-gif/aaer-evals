# FTNT 8-K — 0001262039-18-000017 filed 2018-05-03

## item codes, every 8-K on or before 2018-05-08

- 2018-05-03 0001262039-18-000017 — 2.02, 5.02, 9.01
- 2018-02-05 0001262039-18-000004 — 2.02, 5.02, 9.01
- 2017-10-26 0001262039-17-000031 — 2.02, 9.01
- 2017-10-19 0001262039-17-000029 — 5.02 — amendment, the index does not say of what
- 2017-07-26 0001262039-17-000025 — 2.02, 9.01
- 2017-06-27 0001262039-17-000023 — 5.07
- 2017-05-31 0001262039-17-000021 — 5.02 — amendment of 0001262039-17-000019
- 2017-05-30 0001262039-17-000019 — 5.02, 9.01
- 2017-04-27 0001262039-17-000013 — 2.02, 9.01
- 2017-02-02 0001262039-17-000003 — 2.02, 9.01
- 2016-10-27 0001262039-16-000085 — 2.02, 9.01
- 2016-10-11 0001262039-16-000082 — 2.02, 9.01
- 2016-07-28 0001262039-16-000076 — 2.02, 9.01
- 2016-07-22 0001262039-16-000073 — 8.01, 9.01
- 2016-06-20 0001262039-16-000068 — 5.07
- 2016-06-07 0001193125-16-614788 — 8.01
- 2016-04-26 0001262039-16-000061 — 2.02, 9.01
- 2016-01-28 0001262039-16-000051 — 2.02, 9.01
- 2015-10-27 0001262039-15-000045 — 2.02
- 2015-10-22 0001262039-15-000042 — 5.02 — amendment, the index does not say of what
- 2015-10-22 0001262039-15-000041 — 5.02 — amendment, the index does not say of what
- 2015-10-22 0001262039-15-000039 — 2.02, 9.01
- 2015-09-28 0001262039-15-000034 — 5.02, 9.01
- 2015-09-22 0001262039-15-000031 — 9.01 — amendment of 0001193125-15-248065
- 2015-08-28 0001262039-15-000027 — 3.01, 5.02
- 2015-07-23 0001262039-15-000021 — 5.02
- 2015-07-22 0001262039-15-000019 — 2.02, 9.01
- 2015-07-08 0001193125-15-248065 — 2.01, 8.01, 9.01
- 2015-06-22 0001193125-15-229099 — 5.07
- 2015-06-19 0001193125-15-228428 — 5.02, 9.01
- 2015-04-20 0001262039-15-000014 — 2.02, 9.01
- 2015-01-28 0001262039-15-000005 — 2.02, 9.01
- 2014-10-22 0001262039-14-000036 — 2.02, 9.01
- 2014-07-23 0001262039-14-000030 — 2.02, 9.01
- 2014-06-24 0001262039-14-000027 — 5.07
- 2014-04-23 0001262039-14-000021 — 2.02, 9.01
- 2014-04-21 0001262039-14-000018 — 5.03, 9.01
- 2014-01-29 0001262039-14-000004 — 2.02, 9.01
- 2013-12-20 0001262039-13-000061 — 5.02, 9.01
- 2013-11-27 0001262039-13-000057 — 5.02, 7.01, 9.01
- 2013-11-12 0001445305-13-002993 — 5.02
- 2013-10-23 0001262039-13-000051 — 2.02, 9.01
- 2013-07-30 0001262039-13-000039 — 2.02, 9.01
- 2013-06-25 0001262039-13-000030 — 5.07
- 2013-04-30 0001262039-13-000023 — 2.02, 9.01
- 2013-04-19 0001262039-13-000020 — 5.02, 9.01
- 2013-04-19 0001262039-13-000018 — 5.02 — amendment of 0001262039-13-000020
- 2013-04-10 0001262039-13-000016 — 2.02, 9.01
- 2013-03-26 0001262039-13-000013 — 5.02
- 2013-01-30 0001262039-13-000005 — 2.02, 9.01
- 2013-01-24 0001262039-13-000002 — 5.02, 9.01
- 2012-10-16 0001262039-12-000048 — 2.02, 9.01
- 2012-10-01 0001262039-12-000045 — 5.02
- 2012-09-26 0001262039-12-000043 — 5.01
- 2012-07-25 0001262039-12-000038 — 2.02, 9.01
- 2012-07-19 0001262039-12-000034 — 5.02
- 2012-06-20 0001193125-12-275869 — 5.07
- 2012-04-27 0001262039-12-000029 — 5.02
- 2012-04-24 0001262039-12-000025 — 2.02, 9.01
- 2012-01-31 0001262039-12-000006 — 2.02, 9.01
- 2012-01-25 0001262039-12-000003 — 5.03
- 2011-10-24 0001262039-11-000036 — 2.02
- 2011-07-19 0001262039-11-000014 — 2.02, 9.01
- 2011-06-27 0001193125-11-174474 — 5.02, 5.07, 9.01
- 2011-04-27 0001193125-11-111938 — 2.02, 9.01
- 2011-01-25 0001193125-11-013914 — 2.02, 9.01
- 2010-10-21 0001193125-10-233676 — 2.02, 9.01
- 2010-09-02 0001193125-10-203099 — 8.01
- 2010-07-22 0001193125-10-163844 — 2.02, 9.01
- 2010-06-24 0001193125-10-146082 — 5.07
- 2010-04-28 0001193125-10-096698 — 2.02, 9.01
- 2010-02-09 0001193125-10-024614 — 8.01
- 2010-01-27 0001193125-10-014292 — 2.02, 9.01
- 2010-01-26 0001193125-10-013031 — 5.02, 9.01

## late-filing notifications on or before 2018-05-08

- none on or before 2018-05-08

## item 2.02 — earnings release, exhibit 99.1

[0001262039-18-000017:8k_2_02:1]
EX-99.1
2
ftntq1-2018ex991.htm
PRESS RELEASE

[0001262039-18-000017:8k_2_02:2]
Exhibit

[0001262039-18-000017:8k_2_02:3]
Press Release

[0001262039-18-000017:8k_2_02:4]
Fortinet Reports First Quarter 2018 Financial Results

[0001262039-18-000017:8k_2_02:5]
Fortinet Reports Revenue Growth of 17% and Billings Growth 15%

[0001262039-18-000017:8k_2_02:6]
First Quarter 2018 Highlights

[0001262039-18-000017:8k_2_02:7]
| • | Revenue of $399.0 million, up 17% year over year |

[0001262039-18-000017:8k_2_02:8]
| • | Billings of $463.2 million, up 15% year over year1 |

[0001262039-18-000017:8k_2_02:9]
| • | Deferred revenue of $1.40 billion, up 27% year over year |

[0001262039-18-000017:8k_2_02:10]
| • | GAAP diluted net income per share of $0.24 |

[0001262039-18-000017:8k_2_02:11]
| • | Non-GAAP diluted net income per share of $0.331 |

[0001262039-18-000017:8k_2_02:12]
| • | Cash flow from operations of $139.7 million |

[0001262039-18-000017:8k_2_02:13]
| • | Free cash flow of $128.1 million1 |

[0001262039-18-000017:8k_2_02:14]
| • | Cash, cash equivalents and investments of $1.39 billion |

[0001262039-18-000017:8k_2_02:15]
| • | $115.5 million in share repurchases |

[0001262039-18-000017:8k_2_02:16]
SUNNYVALE, Calif. - May 3, 2018 - Fortinet® (NASDAQ: FTNT), a global leader in broad, integrated and automated cybersecurity solutions, today announced financial results for the first quarter ended March 31, 2018.

[0001262039-18-000017:8k_2_02:17]
“Our market leadership was once again demonstrated by strong first quarter revenue and billings growth,” said Ken Xie, Founder, Chairman and Chief Executive Officer. “As more organizations move towards consolidation, Fortinet’s Security Fabric architecture and broad end-to-end portfolio of security solutions provides the integration and automation required to protect enterprises at every point across their IT infrastructure. Fortinet is in the best position to empower our customers with the latest evolution in network security whether on-premise or in multi-cloud environments.”

[0001262039-18-000017:8k_2_02:18]
Financial Details for the First Quarter of 2018

[0001262039-18-000017:8k_2_02:19]
| • | Revenue: Total revenue was $399.0 million for the first quarter of 2018, an increase of 17% compared to $340.6 million in the same quarter of 2017. |

[0001262039-18-000017:8k_2_02:20]
| • | Product revenue was $142.8 million for the first quarter of 2018, an increase of 6% compared to $135.3 million in the same quarter of 2017. Service revenue was $256.2 million for the first quarter of 2018, an increase of 25% compared to $205.3 million in the same quarter of 2017. |

[0001262039-18-000017:8k_2_02:21]
| • | Billings1: Total billings were $463.2 million for the first quarter of 2018, an increase of 15% compared to $403.3 million in the same quarter of 2017. |

[0001262039-18-000017:8k_2_02:22]
| • | Deferred Revenue: Total deferred revenue was $1.40 billion as of March 31, 2018, an increase of 27% compared to $1.10 billion as of March 31, 2017. |

[0001262039-18-000017:8k_2_02:23]
| • | GAAP Operating Income and Margin: GAAP operating income was $32.4 million for the first quarter of 2018, representing a GAAP operating margin of 8%. GAAP operating income was $5.4 million for the same quarter of 2017, representing a GAAP operating margin of 2%. |

[0001262039-18-000017:8k_2_02:24]
| • | Non-GAAP Operating Income1 and Margin1: Non-GAAP operating income was $70.7 million for the first quarter of 2018, representing a non-GAAP operating margin of 18%. Non-GAAP operating income was $43.0 million for the first quarter of 2017, representing a non-GAAP operating margin of 13%. |

[0001262039-18-000017:8k_2_02:25]
| • | GAAP Net Income and Diluted Net Income Per Share: GAAP net income was $41.6 million for the first quarter of 2018, compared to GAAP net income of $10.7 million for the same quarter of 2017. GAAP diluted net income per share was $0.24 for the first quarter of 2018, based on 171.8 million diluted weighted-average shares outstanding, compared to GAAP diluted net income per share of $0.06 for the same quarter of 2017, based on 178.3 million diluted weighted-average shares outstanding. |

[0001262039-18-000017:8k_2_02:26]
| • | Non-GAAP Net Income1 and Diluted Net Income Per Share1: Non-GAAP net income was $57.0 million for the first quarter of 2018, compared to non-GAAP net income of $31.0 million for the same quarter of 2017. Non-GAAP diluted net income per share was $0.33 for the first quarter of 2018, based on 171.8 million diluted weighted-average shares outstanding, compared to $0.17 for the same quarter of 2017, based on 178.3 million diluted weighted-average shares outstanding. Non-GAAP effective tax rate was 24% in the first quarter of 2018, compared to 32% for the same quarter in 2017. |

[0001262039-18-000017:8k_2_02:27]
| • | Cash, Cash Flow and Free Cash Flow1: As of March 31, 2018, cash, cash equivalents and investments were $1.39 billion, compared to $1.35 billion as of December 31, 2017. In the first quarter of 2018, cash flow from operations was $139.7 million compared to $129.7 million in the same quarter of 2017. Free cash flow1 was $128.1 million during the first quarter of 2018 compared to $116.2 million in the same quarter of 2017. |

[0001262039-18-000017:8k_2_02:28]
| • | Share Repurchase: During the first quarter of 2018, Fortinet repurchased 2.5 million shares of its common stock for a total purchase price of $115.5 million. There were no shares repurchased during the first quarter of 2017. |

[0001262039-18-000017:8k_2_02:29]
Guidance

[0001262039-18-000017:8k_2_02:30]
For the second quarter of 2018, Fortinet expects:

[0001262039-18-000017:8k_2_02:31]
| • | Revenue in the range of $420 million to $430 million |

[0001262039-18-000017:8k_2_02:32]
| • | Billings in the range of $485 million to $495 million |

[0001262039-18-000017:8k_2_02:33]
| • | Non-GAAP gross margin in the range of 75% to 76% |

[0001262039-18-000017:8k_2_02:34]
| • | Non-GAAP operating margin in the range of 18.5% to 19.0%, including a benefit associated with the adoption of ASC 606 of approximately 250 basis points |

[0001262039-18-000017:8k_2_02:35]
| • | Diluted non-GAAP earnings per share in the range of $0.34 to $0.36, assuming a non-GAAP tax rate of 24%, and including an earnings per share benefit associated with the adoption of ASC 606 of approximately $0.05. This assumes a share count of 173 million to 175 million |

[0001262039-18-000017:8k_2_02:36]
For the fiscal year of 2018, Fortinet expects:

[0001262039-18-000017:8k_2_02:37]
| • | Revenue in the range of $1.715 billion to $1.735 billion |

[0001262039-18-000017:8k_2_02:38]
| • | Billings in the range of $2.040 billion to $2.065 billion |

[0001262039-18-000017:8k_2_02:39]
| • | Non-GAAP gross margin in the range of 75% to 76% |

[0001262039-18-000017:8k_2_02:40]
| • | Non-GAAP operating margin in the range of 20.2% to 20.7%, including a benefit associated with the adoption of ASC 606 of approximately 250 basis points |

[0001262039-18-000017:8k_2_02:41]
| • | Diluted non-GAAP earnings per share in the range of $1.51 to $1.55, assuming a non-GAAP tax rate of 24%, and including an earnings per share benefit associated with the adoption of ASC 606 of approximately $0.19. This assumes a share count of 175 million to 177 million |

[0001262039-18-000017:8k_2_02:42]
The above guidance for the second quarter and full year of 2018 includes the transition impact of ASC 606 adoption, which was effective January 1, 2018. Our guidance with respect to non-GAAP financial measures excludes stock-based compensation and amortization of acquired intangible assets. We have not reconciled our guidance with respect to non-GAAP financial measures to the corresponding GAAP measures because certain items that impact these measures are uncertain or out of our control, or cannot be reasonably predicted. Accordingly, a reconciliation of these non-GAAP financial measures to the corresponding GAAP measures is not available without unreasonable effort.

[0001262039-18-000017:8k_2_02:43]
1 A reconciliation of GAAP to non-GAAP measures has been provided in the financial statement tables included in this press release. An explanation of these measures is also included below under the heading “Non-GAAP Financial Measures.”

[0001262039-18-000017:8k_2_02:44]
Keith Jensen Named Chief Financial Officer

[0001262039-18-000017:8k_2_02:45]
Keith Jensen, who has served as Fortinet's interim CFO since February 16, 2018, has been appointed CFO by the company’s board of directors. In addition to serving as Fortinet’s interim CFO, Keith served as Fortinet’s chief accounting officer since May 2014. “I want to thank the board of directors for their support and I look forward to working with Ken and the entire Fortinet team to continue to grow the company,” said Keith Jensen. “Keith is a valued member of the executive team, and I look forward to continuing to work closely with him on our mission to provide the best security for our customers,” said Ken Xie.

[0001262039-18-000017:8k_2_02:46]
Conference Call Details

[0001262039-18-000017:8k_2_02:47]
Fortinet will host a conference call today at 1:30 p.m. Pacific Time (4:30 p.m. Eastern Time) to discuss the earnings results. The call can be accessed by dialing (877) 303-6913 (domestic) or (224) 357-2188 (international) with conference ID # 4349108. A live webcast of the conference call and supplemental slides will be accessible from the Investor Relations page of Fortinet’s website at http://investor.fortinet.com and a replay will be archived and accessible at http://investor.fortinet.com/events.cfm. A replay of this conference call can also be accessed through May 10, 2018, by dialing (855) 859-2056 (domestic) or (404) 537-3406 (international) with conference ID #4349108. Fortinet will no longer be hosting an additional question-and-answer session following the earnings call.

[0001262039-18-000017:8k_2_02:48]
Second Quarter 2018 Investor Conference Participation Schedule:

[0001262039-18-000017:8k_2_02:49]
| • | 46th Annual J.P. Morgan Global Technology, Media and Communications Conference |

[0001262039-18-000017:8k_2_02:50]
May 16, 2018 - Boston, MA

[0001262039-18-000017:8k_2_02:51]
| • | Bank of America Merrill Lynch 2018 Global Technology Conference |

[0001262039-18-000017:8k_2_02:52]
June 5, 2018 - San Francisco, CA

[0001262039-18-000017:8k_2_02:53]
| • | William Blair 38th Annual Growth Stock Conference |

[0001262039-18-000017:8k_2_02:54]
June 14, 2018 - Chicago, IL

[0001262039-18-000017:8k_2_02:55]
Members of Fortinet’s management team are expected to present at these events and discuss the latest company strategies and initiatives. To access the most updated information and listen to the webcast of each event, please visit the Investor Relations page of Fortinet’s website at http://investor.fortinet.com. The schedule is subject to change.

[0001262039-18-000017:8k_2_02:56]
About Fortinet (www.fortinet.com)

[0001262039-18-000017:8k_2_02:57]
Fortinet (NASDAQ: FTNT) secures the largest enterprise, service provider and government organizations around the world. Fortinet empowers its customers with intelligent, seamless protection across the expanding attack surface and the power to take on ever-increasing performance requirements of the borderless network -- today and into the future. Fortinet Security Fabric architecture can deliver security without compromise to address the most critical security challenges, whether in networked, application, cloud or mobile environments. Learn more at http://www.fortinet.com, the Fortinet Blog or FortiGuard Labs.

[0001262039-18-000017:8k_2_02:58]
#          #          #

[0001262039-18-000017:8k_2_02:59]
Copyright © 2018 Fortinet, Inc. All rights reserved. The symbols ® and ™ denote respectively federally registered trademarks and unregistered trademarks of Fortinet, Inc., its subsidiaries and affiliates. Fortinet’s trademarks include, but are not limited to, the following: Fortinet, FortiGate, FortiGuard, FortiManager, FortiMail, FortiClient, FortiCloud, FortiCare, FortiAnalyzer, FortiReporter, FortiOS, FortiASIC, FortiWiFi, FortiSwitch, FortiVoIP, FortiBIOS, FortiLog, FortiResponse, FortiCarrier, FortiScan, FortiAP, FortiDB, FortiVoice, FortiWeb and FortiCASB. Other trademarks belong to their respective owners.

[0001262039-18-000017:8k_2_02:60]
FTNT-F

[0001262039-18-000017:8k_2_02:61]
Forward-looking Statements

[0001262039-18-000017:8k_2_02:62]
This press release contains forward-looking statements that involve risks and uncertainties. These forward-looking statements include statements regarding our position for future growth, position to provide our customers the best network security, ability to continue to grow our market position and address our market opportunity, and guidance and future financial results. Although we attempt to be accurate in making forward-looking statements, it is possible that future circumstances might differ from the assumptions on which such statements are based such that actual results are materially different from our forward-looking statements in this release. Important factors that could cause results to differ materially from the statements herein include the following: general economic risks; global economic conditions, country-specific economic conditions, and foreign currency risks; competitiveness in the security market; the dynamic nature of the security market and its product and services; specific economic risks worldwide and in different geographies, and among different customer segments; uncertainty regarding increased business and renewals from existing customers; uncertainties around continued success in sales growth and market share gains; longer sales cycles, particularly for larger enterprise, service providers, government and other large organization customers; failure to convert sales pipeline into final sales; risks associated with successful implementation of

[0001262039-18-000017:8k_2_02:63]
Non-GAAP Financial Measures

[0001262039-18-000017:8k_2_02:64]
We have provided in this release financial information that has not been prepared in accordance with Generally Accepted Accounting Principles (GAAP). These non-GAAP financial and liquidity measures are not based on any standardized methodology prescribed by GAAP and are not necessarily comparable to similar measures presented by other companies. We use these non-GAAP financial measures internally in analyzing our financial results and believe they are useful to investors, as a supplement to GAAP measures, in evaluating our ongoing operational performance. We believe that the use of these non-GAAP financial measures provides an additional tool for investors to use in evaluating ongoing operating results and trends and in comparing our financial results with peer companies, many of which present similar non-GAAP financial measures to investors.

[0001262039-18-000017:8k_2_02:65]
Non-GAAP financial measures should not be considered in isolation from, or as a substitute for, financial information prepared in accordance with GAAP. Investors are encouraged to review the reconciliation of these non-GAAP financial measures to their most directly comparable GAAP financial measures provided in the financial statement tables below.

[0001262039-18-000017:8k_2_02:66]
Billings (non-GAAP). We define billings as revenue recognized in accordance with GAAP plus the change in deferred revenue from the beginning to the end of the period and adjustment to the deferred revenue balance due to adoption of the new revenue recognition standard less any deferred revenue balances acquired from business combination(s) during the period. We consider billings to be a useful metric for management and investors because billings drive future revenue, which is an important indicator of the health and viability of our business. There are a number of limitations related to the use of billings instead of GAAP revenue. First, billings include amounts that have not yet been recognized as revenue and are impacted by the term of security and support agreements. Second, we may calculate billings in a manner that is different from peer companies that report similar financial measures. Management accounts for these limitations by providing specific information regarding GAAP revenue and evaluating billings together with GAAP revenue.

[0001262039-18-000017:8k_2_02:67]
Free cash flow (non-GAAP). We define free cash flow as net cash provided by operating activities minus capital expenditures such as purchases of real estate and other property and equipment. We believe free cash flow to be a liquidity measure that provides useful information to management and investors about the amount of cash generated by the business that, after capital expenditures, can be used for strategic opportunities, including repurchasing outstanding common stock, investing in our business, making strategic acquisitions and strengthening the

[0001262039-18-000017:8k_2_02:68]
balance sheet. A limitation of using free cash flow rather than the GAAP measure of net cash provided by operating activities is that free cash flow does not represent the total increase or decrease in the cash, cash equivalents and investments balance for the period because it excludes cash provided by or used for other investing and financing activities. Management accounts for this limitation by providing information about our capital expenditures and other investing and financing activities on the face of the cash flow statement and under the caption “Management’s Discussion and Analysis of Financial Condition and Results of Operations—Liquidity and Capital Resources” in our most recent Quarterly Report on Form 10-Q and Annual Report on Form 10-K and by presenting cash flows from investing and financing activities in our reconciliation of free cash flows. In addition, it is important to note that other companies, including companies in our industry, may not use free cash flow, may calculate free cash flow in a different manner than we do or may use other financial measures to evaluate their performance, all of which could reduce the usefulness of free cash flows as a comparative measure.

[0001262039-18-000017:8k_2_02:69]
Non-GAAP operating income and operating margin. We define non-GAAP operating income as operating income or loss plus stock-based compensation, business acquisition-related charges, purchase accounting adjustments, impairment and amortization of acquired intangible assets, restructuring charges, expenses associated with the implementation of a new Enterprise Resource Planning (ERP) system, litigation settlement expenses and, when applicable, other significant non-recurring items in a given quarter. Non-GAAP operating margin is defined as non-GAAP operating income divided by GAAP revenue. We consider these non-GAAP financial measures to be useful metrics for management and investors because they exclude the items noted above so that our management and investors can compare our recurring core business operating results over multiple periods. There are a number of limitations related to the use of non-GAAP operating income instead of operating income or loss calculated in accordance with GAAP. First, non-GAAP operating income excludes the items noted above. Second, the components of the costs that we exclude from our calculation of non-GAAP operating income may differ from the components that peer companies exclude when they report their non-GAAP results of operations. Management accounts for these limitations by providing specific information regarding the GAAP amounts excluded from non-GAAP operating income and evaluating non-GAAP operating income together with operating income calculated in accordance with GAAP.

[0001262039-18-000017:8k_2_02:70]
Non-GAAP net income and diluted net income per share. We define non-GAAP net income as net income or loss plus the items noted above under non-GAAP operating income and operating margin, including a tax adjustment to achieve our effective tax rate on a non-GAAP basis, which often differs from the GAAP effective tax rate. We define non-GAAP diluted net income per share as non-GAAP net income divided by the non-GAAP diluted weighted-average shares outstanding. We consider these non-GAAP financial measures to be useful metrics for management and investors for the same reasons that we use non-GAAP operating income and non-GAAP operating margin. However, in order to provide a more complete picture of our recurring core business operating results, we include in non-GAAP net income and non-GAAP diluted net income per share, the tax adjustment required resulting in an effective tax rate on a non-GAAP basis, which often differs from the GAAP tax rate. We believe the non-GAAP effective tax rates we use are reasonable estimates of normalized tax rates for our current and prior fiscal years under our global operating structure. The same limitations described above regarding our use of non-GAAP operating income and non-GAAP operating margin apply to our use of non-GAAP net income and non-GAAP diluted net income per share. We account for these limitations by providing specific information regarding the GAAP amounts excluded from non-GAAP net income and non-GAAP diluted net income per share and evaluating non-GAAP net income and non-GAAP diluted net income per share together with net income or loss and diluted net income per share calculated in accordance with GAAP.

[0001262039-18-000017:8k_2_02:71]
FORTINET, INC.

[0001262039-18-000017:8k_2_02:72]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001262039-18-000017:8k_2_02:73]
(Unaudited, in millions)

[0001262039-18-000017:8k_2_02:74]
|  | March 31, 2018 |  | December 31, 2017 |
| ASSETS |  |  |  |
| CURRENT ASSETS: |  |  |  |
| Cash and cash equivalents | $ | 835.6 |  |  | $ | 811.0 |  |
| Short-term investments | 468.3 |  |  | 440.3 |  |
| Accounts receivable—net | 313.1 |  |  | 348.2 |  |
| Inventory | 80.0 |  |  | 77.3 |  |
| Prepaid expenses and other current assets | 38.8 |  |  | 40.0 |  |
| Total current assets | 1,735.8 |  |  | 1,716.8 |  |
| LONG-TERM INVESTMENTS | 82.5 |  |  | 98.0 |  |
| PROPERTY AND EQUIPMENT—NET | 245.1 |  |  | 245.4 |  |
| DEFERRED CONTRACT COSTS | 148.7 |  |  | — |  |
| DEFERRED TAX ASSETS | 138.7 |  |  | 146.9 |  |
| OTHER INTANGIBLE ASSETS—NET | 14.5 |  |  | 16.3 |  |
| GOODWILL | 14.6 |  |  | 14.6 |  |
| OTHER ASSETS | 20.8 |  |  | 19.9 |  |
| TOTAL ASSETS | $ | 2,400.7 |  |  | $ | 2,257.9 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |
| CURRENT LIABILITIES: |  |  |  |
| Accounts payable | $ | 55.7 |  |  | $ | 70.0 |  |
| Accrued liabilities | 55.6 |  |  | 50.0 |  |
| Accrued payroll and compensation | 82.3 |  |  | 92.0 |  |
| Income taxes payable | 19.0 |  |  | 21.4 |  |
| Deferred revenue | 817.1 |  |  | 793.8 |  |
| Total current liabilities | 1,029.7 |  |  | 1,027.2 |  |
| DEFERRED REVENUE | 579.3 |  |  | 542.5 |  |
| INCOME TAX LIABILITIES | 84.8 |  |  | 90.2 |  |
| OTHER LIABILITIES | 13.4 |  |  | 8.6 |  |
| Total liabilities | 1,707.2 |  |  | 1,668.5 |  |
| COMMITMENTS AND CONTINGENCIES |  |  |  |
| STOCKHOLDERS’ EQUITY: |  |  |  |
| Common stock | 0.2 |  |  | 0.2 |  |
| Additional paid-in capital | 957.9 |  |  | 909.6 |  |
| Accumulated other comprehensive loss | (2.0 | ) |  | (0.8 | ) |
| Accumulated deficit | (262.6 | ) |  | (319.6 | ) |
| Total stockholders’ equity | 693.5 |  |  | 589.4 |  |
| TOTAL LIABILITIES AND STOCKHOLDERS’ EQUITY | $ | 2,400.7 |  |  | $ | 2,257.9 |  |

[0001262039-18-000017:8k_2_02:75]
FORTINET, INC.

[0001262039-18-000017:8k_2_02:76]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001262039-18-000017:8k_2_02:77]
(Unaudited, in millions, except per share amounts)

[0001262039-18-000017:8k_2_02:78]
|  | Three Months Ended |
|  | March 31, 2018 |  | March 31, 2017 |
| REVENUE: |  |  |  |
| Product | $ | 142.8 |  |  | $ | 135.3 |  |
| Service | 256.2 |  |  | 205.3 |  |
| Total revenue | 399.0 |  |  | 340.6 |  |
| COST OF REVENUE: |  |  |  |
| Product 1 | 58.2 |  |  | 55.3 |  |
| Service 1 | 39.0 |  |  | 35.3 |  |
| Total cost of revenue | 97.2 |  |  | 90.6 |  |
| GROSS PROFIT: |  |  |  |
| Product | 84.6 |  |  | 80.0 |  |
| Service | 217.2 |  |  | 170.0 |  |
| Total gross profit | 301.8 |  |  | 250.0 |  |
| OPERATING EXPENSES: |  |  |  |
| Research and development 1 | 59.1 |  |  | 51.2 |  |
| Sales and marketing 1 | 185.3 |  |  | 170.4 |  |
| General and administrative 1 | 25.0 |  |  | 22.6 |  |
| Restructuring charges | — |  |  | 0.4 |  |
| Total operating expenses | 269.4 |  |  | 244.6 |  |
| OPERATING INCOME | 32.4 |  |  | 5.4 |  |
| INTEREST INCOME | 4.5 |  |  | 2.4 |  |
| OTHER INCOME (EXPENSE)—NET | (0.2 | ) |  | 0.3 |  |
| INCOME BEFORE INCOME TAXES | 36.7 |  |  | 8.1 |  |
| BENEFIT FROM INCOME TAXES | (4.9 | ) |  | (2.6 | ) |
| NET INCOME | $ | 41.6 |  |  | $ | 10.7 |  |
| Net income per share: |  |  |  |
| Basic | $ | 0.25 |  |  | $ | 0.06 |  |
| Diluted | $ | 0.24 |  |  | $ | 0.06 |  |
| Weighted-average shares outstanding: |  |  |  |
| Basic | 167.7 |  |  | 174.5 |  |
| Diluted | 171.8 |  |  | 178.3 |  |
| 1 Includes stock-based compensation as follows: |  |  |  |
| Cost of product revenue | $ | 0.4 |  |  | $ | 0.3 |  |
| Cost of service revenue | 2.5 |  |  | 2.3 |  |
| Research and development | 8.4 |  |  | 7.9 |  |
| Sales and marketing | 20.9 |  |  | 19.0 |  |
| General and administrative | 4.3 |  |  | 3.8 |  |
|  | $ | 36.5 |  |  | $ | 33.3 |  |

[0001262039-18-000017:8k_2_02:79]
FORTINET, INC.

[0001262039-18-000017:8k_2_02:80]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001262039-18-000017:8k_2_02:81]
(Unaudited, in millions)

[0001262039-18-000017:8k_2_02:82]
|  | Three Months Ended |
|  | March 31, 2018 |  | March 31, 2017 |
| CASH FLOWS FROM OPERATING ACTIVITIES: |  |  |  |
| Net income | $ | 41.6 |  |  | $ | 10.7 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |
| Stock-based compensation | 36.5 |  |  | 33.3 |  |
| Amortization of deferred contract costs | 20.8 |  |  | — |  |
| Depreciation and amortization | 13.2 |  |  | 13.5 |  |
| Other non-cash items—net | 0.3 |  |  | 1.5 |  |
| Amortization of investment premiums | 0.1 |  |  | 1.0 |  |
| Changes in operating assets and liabilities: |  |  |  |
| Accounts receivable—net | 48.9 |  |  | 42.4 |  |
| Inventory | (7.3 | ) |  | (3.5 | ) |
| Prepaid expenses and other current assets | 1.2 |  |  | (8.3 | ) |
| Deferred contract costs | (32.5 | ) |  | — |  |
| Deferred tax assets | (9.6 | ) |  | (16.6 | ) |
| Other assets | (0.9 | ) |  | 0.7 |  |
| Accounts payable | (13.6 | ) |  | (8.3 | ) |
| Accrued liabilities | (4.7 | ) |  | 2.9 |  |
| Accrued payroll and compensation | (10.0 | ) |  | (5.3 | ) |
| Other liabilities | (0.6 | ) |  | (1.1 | ) |
| Deferred revenue | 64.1 |  |  | 61.8 |  |
| Income taxes payable | (7.8 | ) |  | 5.0 |  |
| Net cash provided by operating activities | 139.7 |  |  | 129.7 |  |
| CASH FLOWS FROM INVESTING ACTIVITIES: |  |  |  |
| Purchases of investments | (134.9 | ) |  | (133.0 | ) |
| Sales of investments | 16.3 |  |  | 6.0 |  |
| Maturities of investments | 104.7 |  |  | 109.2 |  |
| Purchases of property and equipment | (11.6 | ) |  | (13.5 | ) |
| Net cash used in investing activities | (25.5 | ) |  | (31.3 | ) |
| CASH FLOWS FROM FINANCING ACTIVITIES: |  |  |  |
| Repurchase and retirement of common stock | (115.5 | ) |  | — |  |
| Proceeds from issuance of common stock | 45.1 |  |  | 29.5 |  |
| Taxes paid related to net share settlement of equity awards | (19.2 | ) |  | (13.7 | ) |
| Net cash provided by (used in) financing activities | (89.6 | ) |  | 15.8 |  |
| NET INCREASE IN CASH AND CASH EQUIVALENTS | 24.6 |  |  | 114.2 |  |
| CASH AND CASH EQUIVALENTS—Beginning of period | 811.0 |  |  | 709.0 |  |
| CASH AND CASH EQUIVALENTS—End of period | $ | 835.6 |  |  | $ | 823.2 |  |

[0001262039-18-000017:8k_2_02:83]
New Revenue Recognition Standard (ASC 606) Adoption Financial Impact1

[0001262039-18-000017:8k_2_02:84]
(Unaudited, in millions, except per share amounts)

[0001262039-18-000017:8k_2_02:85]
|  | Three Months Ended March 31, 2018 |
|  | As Reported |  | Balances Without Adoption of ASC 606 |  | Effect of ChangeIncrease (Decrease) |
| REVENUE: |  |  |  |  |  |
| Product | $ | 142.8 |  |  | $ | 137.1 |  |  | $ | 5.7 |  |
| Service | 256.2 |  |  | 255.5 |  |  | 0.7 |  |
| Total revenue | 399.0 |  |  | 392.6 |  |  | 6.4 |  |
| COST OF REVENUE: |  |  |  |  |  |
| Product | 58.2 |  |  | 56.7 |  |  | 1.5 |  |
| GROSS PROFIT: |  |  |  |  |  |
| Product | 84.6 |  |  | 80.4 |  |  | 4.2 |  |
| Service | 217.2 |  |  | 216.5 |  |  | 0.7 |  |
| Total gross profit | 301.8 |  |  | 296.9 |  |  | 4.9 |  |
| OPERATING EXPENSES: |  |  |  |  |  |
| Sales and marketing expenses | 185.3 |  |  | 197.0 |  |  | (11.7 | ) |
| OPERATING INCOME | 32.4 |  |  | 15.8 |  |  | 16.6 |  |
| INCOME BEFORE INCOME TAXES | 36.7 |  |  | 20.1 |  |  | 16.6 |  |
| BENEFIT FROM INCOME TAXES | (4.9 | ) |  | (8.7 | ) |  | 3.8 |  |
| NET INCOME | $ | 41.6 |  |  | $ | 28.8 |  |  | $ | 12.8 |  |
| Net income per share: |  |  |  |  |  |
| Basic | $ | 0.25 |  |  | $ | 0.17 |  |  | $ | 0.08 |  |
| Diluted | $ | 0.24 |  |  | $ | 0.17 |  |  | $ | 0.07 |  |
| 1 The table above does not represent the full condensed consolidated statement of operations as it only reflects the accounts impacted by the adoption of ASC 606. |

[0001262039-18-000017:8k_2_02:86]
Reconciliations of non-GAAP results of operations measures to the nearest comparable GAAP measures

[0001262039-18-000017:8k_2_02:87]
(Unaudited, in millions, except per share amounts)

[0001262039-18-000017:8k_2_02:88]
Reconciliation of net cash provided by operating activities to free cash flow

[0001262039-18-000017:8k_2_02:89]
|  | Three Months Ended |
|  | March 31, 2018 |  | March 31, 2017 |
| Net cash provided by operating activities | $ | 139.7 |  |  | $ | 129.7 |  |
| Less purchases of property and equipment | (11.6 | ) |  | (13.5 | ) |
| Free cash flow | $ | 128.1 |  |  | $ | 116.2 |  |
| Net cash used in investing activities | $ | (25.5 | ) |  | $ | (31.3 | ) |
| Net cash provided by (used) in financing activities | $ | (89.6 | ) |  | $ | 15.8 |  |

[0001262039-18-000017:8k_2_02:90]
Reconciliation of GAAP operating income to non-GAAP operating income, operating margin, net income and diluted net income per share

[0001262039-18-000017:8k_2_02:91]
|  | Three Months Ended March 31, 2018 |  | Three Months Ended March 31, 2017 |
|  | GAAP Results |  | Adjustments |  | Non-GAAP Results |  | GAAP Results |  | Adjustments |  | Non-GAAP Results |
| Operating income | $ | 32.4 |  |  | $ | 38.3 |  | (a) | $ | 70.7 |  |  | $ | 5.4 |  |  | $ | 37.6 |  | (b) | $ | 43.0 |  |
| Operating margin | 8 | % |  |  |  | 18 | % |  | 2 | % |  |  |  | 13 | % |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | 36.5 |  |  |  |  |  |  | 33.3 |  |  |  |
| Amortization of acquired intangible assets |  |  | 1.8 |  |  |  |  |  |  | 2.3 |  |  |  |
| Litigation settlement expenses |  |  | — |  |  |  |  |  |  | 1.5 |  |  |  |
| Restructuring charges |  |  | — |  |  |  |  |  |  | 0.4 |  |  |  |
| Tax adjustment |  |  | (22.9 | ) | (c) |  |  |  |  | (17.2 | ) | (c) |  |
| Net income | $ | 41.6 |  |  | $ | 15.4 |  |  | $ | 57.0 |  |  | $ | 10.7 |  |  | $ | 20.3 |  |  | $ | 31.0 |  |
| Diluted net income per share | $ | 0.24 |  |  |  |  | $ | 0.33 |  |  | $ | 0.06 |  |  |  |  | $ | 0.17 |  |
| Shares used in diluted net income per share calculations | 171.8 |  |  |  |  | 171.8 |  |  | 178.3 |  |  |  |  | 178.3 |  |

[0001262039-18-000017:8k_2_02:92]
(a) To exclude $36.5 million of stock-based compensation and $1.8 million of amortization of acquired intangible assets in the three months ended March 31, 2018.

[0001262039-18-000017:8k_2_02:93]
(b) To exclude $33.3 million of stock-based compensation, $2.3 million of amortization of acquired intangible assets, $1.5 million of litigation settlement expenses, and $0.4 million of restructuring charges in the three months ended March 31, 2017.

[0001262039-18-000017:8k_2_02:94]
(c)  Non-GAAP financial information is adjusted to achieve an overall 24% and 32% effective tax rate in 2018 and 2017, respectively, on a non-GAAP basis, which differs from the GAAP effective tax rate.

[0001262039-18-000017:8k_2_02:95]
Billings Reconciliation

[0001262039-18-000017:8k_2_02:96]
|  | Three Months Ended |
|  | March 31, 2018 |  | March 31, 2017 |
| Total revenue | $ | 399.0 |  |  | $ | 340.6 |  |
| Add: Change in deferred revenue | 60.1 |  |  | 62.7 |  |
| Deferred revenue adjustment due to adoption of the new revenue recognition standard | 4.1 |  |  | — |  |
| Total billings | $ | 463.2 |  |  | $ | 403.3 |  |

[0001262039-18-000017:8k_2_02:97]
| Investor Contact: |  | Media Contact: |
| Peter Salkowski |  | Sandra Wheatley |
| Fortinet, Inc. |  | Fortinet, Inc. |
| 408-331-4595 |  | 408-391-9408 |
| psalkowski@fortinet.com |  | swheatley@fortinet.com |

## item 5.02 — body, verbatim

[0001262039-18-000017:8k_body:1]
Item 5.02 Departure of Directors or Certain Officers; Election of Directors; Appointment of Certain Officers; Compensatory Arrangements of Certain Officers.

[0001262039-18-000017:8k_body:2]
On April 30, 2018, Fortinet’s board of directors appointed Keith Jensen as Chief Financial Officer, effective May 1, 2018.

[0001262039-18-000017:8k_body:3]
Mr. Jensen had previously served as Fortinet’s Interim Chief Financial Officer since February 2018 and has served as Fortinet’s Chief Accounting Officer since July 2015.

[0001262039-18-000017:8k_body:4]
In connection with Mr. Jensen’s appointment as Chief Financial Officer, Fortinet’s board of directors has approved an annual base salary of $400,000 for Mr. Jensen and a target bonus of 60% of his annual base salary, which bonus shall supersede the bonus previously approved for Mr. Jensen in connection with his appointment as Interim Chief Financial Officer. Fortinet previously entered into a change of control severance agreement with Mr. Jensen, dated as of February 4, 2016, which was filed as Exhibit 10.23 to Fortinet’s Annual Report on Form 10-K filed with the Securities and Exchange Commission (the “SEC”) on February 26, 2018, as amended (File No. 001-34511), which agreement is incorporated herein by reference, and previously entered into its standard form of indemnification agreement with Mr. Jensen, in substantially the same form filed as Exhibit 10.1 to Fortinet’s Registration Statement on Form S-1, as amended (File No. 333-161190), filed with the Securities and Exchange Commission on August 10, 2009, which form of agreement is incorporated herein by reference.

[0001262039-18-000017:8k_body:5]
There are no arrangements or understandings between Mr. Jensen and any other persons, pursuant to which he was appointed as Chief Financial Officer, no family relationships among any of the Company’s directors or executive officers and Mr. Jensen and he has no direct or indirect material interest in any transaction required to be disclosed pursuant to Item 404(a) of Regulation S-K.
