# FTNT notes — 0001262039-18-000019


## ftnt:IncomeTaxBenefitFromStockOptionPlansTableTextBlock

[0001262039-18-000019:notes:1]
Total income tax benefit associated with stock-based compensation that is recognized in the consolidated statements of operations is as follows (in millions):

[0001262039-18-000019:notes:2]
|  | Three Months Ended |
|  | March 31, 2018 |  | March 31, 2017 |
| Income tax benefit associated with stock-based compensation | $ | 6.0 |  |  | $ | 6.6 |  |


## ftnt:PresentationAndPreparationOfConsolidatedFinancialStatementsPolicyTextBlock

[0001262039-18-000019:notes:3]
Basis of Presentation and Preparation—The unaudited condensed consolidated financial statements of Fortinet, Inc. and its wholly owned subsidiaries (collectively, “we,” “us” or “our”) have been prepared in accordance with generally accepted accounting principles in the United States (“GAAP”) for interim financial information, as well as the instructions to Form 10-Q pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (the “SEC”). Accordingly, they do not include all of the information and footnotes required by GAAP for complete financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the year ended December 31, 2017, contained in our Annual Report on Form 10-K filed with the SEC on February 26, 2018. In the opinion of management, all adjustments, which includes normal recurring adjustments, considered necessary for a fair presentation have been included. All intercompany balances, transactions and cash flows have been eliminated. The results of operations for the three months ended March 31, 2018 are not necessarily indicative of the results for the full year or for any future periods. The condensed consolidated balance sheet as of December 31, 2017 is derived from the audited consolidated financial statements for the year ended December 31, 2017.

[0001262039-18-000019:notes:4]
The preparation of financial statements in accordance with GAAP requires management to make estimates and assumptions that affect the amounts reported in the condensed consolidated financial statements and accompanying notes. Actual results could differ materially from those estimates.

[0001262039-18-000019:notes:5]
There have been no material changes to our significant accounting policies as of and for the three months ended March 31, 2018, except for the accounting policies for revenue recognition, trade receivables and deferred contract costs that were updated as a result of adopting Accounting Standards Update 2014-09, Revenue from Contracts with Customers (Topic 606) (“ASU 2014-09”). For more information, refer to the “Recently Adopted Accounting Standards” and Note 2.


## ftnt:ScheduleOfAmortizedCostsUnrealizedGainsAndLossesAndFairValueOfAvailableForSaleSecuritiesTableTextBlock

[0001262039-18-000019:notes:6]
The following tables summarize our investments (in millions):

[0001262039-18-000019:notes:7]
|  | March 31, 2018 |
|  | AmortizedCost |  | UnrealizedGains |  | UnrealizedLosses |  | FairValue |
| Corporate debt securities | $ | 372.6 |  |  | $ | — |  |  | $ | (2.3 | ) |  | $ | 370.3 |  |
| Certificates of deposit and term deposits (1) | 86.2 |  |  | — |  |  | (0.1 | ) |  | 86.1 |  |
| Commercial paper | 71.0 |  |  | — |  |  | — |  |  | 71.0 |  |
| U.S. government and agency securities | 23.5 |  |  | — |  |  | (0.1 | ) |  | 23.4 |  |
| Total available-for-sale securities | $ | 553.3 |  |  | $ | — |  |  | $ | (2.5 | ) |  | $ | 550.8 |  |
|  | December 31, 2017 |
|  | AmortizedCost |  | UnrealizedGains |  | UnrealizedLosses |  | FairValue |
| Corporate debt securities | $ | 391.0 |  |  | $ | — |  |  | $ | (1.2 | ) |  | $ | 389.8 |  |
| Commercial paper | 74.2 |  |  | — |  |  | — |  |  | 74.2 |  |
| Certificates of deposit and term deposits (1) | 45.9 |  |  | — |  |  | — |  |  | 45.9 |  |
| U.S. government and agency securities | 28.5 |  |  | — |  |  | (0.1 | ) |  | 28.4 |  |
| Total available-for-sale securities | $ | 539.6 |  |  | $ | — |  |  | $ | (1.3 | ) |  | $ | 538.3 |  |
| (1) The majority of our certificates of deposit and term deposits are foreign deposits. |


## ftnt:ScheduleOfShareBasedPaymentAwardStockOptionsValuationAssumptionsAndAllocationOfRecognizedPeriodCostsTableTextBlock

[0001262039-18-000019:notes:8]
[same as prior period, unchanged from 0001262039-17-000034:notes:8]

[0001262039-18-000019:notes:9]
|  | Three Months Ended |
|  | March 31, 2018 |  | March 31, 2017 |
| Expected term in years | 4.4 |  |  | 4.4 |  |
| Volatility | 32 | % |  | 36 | % |
| Risk-free interest rate | 2.6 | % |  | 1.9 | % |
| Dividend rate | — | % |  | — | % |


## ftnt:ScheduleofEmployeeServiceSharebasedCompensationAllocationofRecognizedPeriodCostsbyAwardTypeTableTextBlock

[0001262039-18-000019:notes:10]
The following table summarizes stock-based compensation expense by award type (in millions):

[0001262039-18-000019:notes:11]
|  | Three Months Ended |
|  | March 31, 2018 |  | March 31, 2017 |
| RSUs | $ | 32.0 |  |  | $ | 29.0 |  |
| Stock options | 2.0 |  |  | 1.8 |  |
| ESPP | 2.5 |  |  | 2.5 |  |
| Total stock-based compensation expense | $ | 36.5 |  |  | $ | 33.3 |  |


## ftnt:ScheduleofSharebasedCompensationSharesWithheldforTaxesTableTextBlock

[0001262039-18-000019:notes:12]
The following summarizes the number and value of the shares withheld for employee taxes (in millions):

[0001262039-18-000019:notes:13]
|  | Three Months Ended |
|  | March 31, 2018 |  | March 31, 2017 |
| Shares withheld for taxes | 0.4 |  |  | 0.4 |  |
| Amount withheld for taxes | $ | 19.2 |  |  | $ | 13.7 |  |


## ftnt:ScheduleofSharebasedCompensationStockOptionsActivityAdditionalInformationTableTextBlock

[0001262039-18-000019:notes:14]
Additional information related to our stock options is summarized below (in millions, except per share amounts):

[0001262039-18-000019:notes:15]
|  | Three Months Ended |
|  | March 31, 2018 |  | March 31, 2017 |
| Weighted-average fair value per share granted | $ | 15.02 |  |  | $ | 12.22 |  |
| Intrinsic value of options exercised | 23.7 |  |  | 17.9 |  |
| Fair value of options vested | 2.8 |  |  | 3.4 |  |


## ftnt:ScheduleofSharebasedPaymentAwardEmployeeStockPurchasePlanAdditionalInformationTableTextBlock

[0001262039-18-000019:notes:16]
Additional information related to the ESPP is provided below (in millions, except per share amounts):

[0001262039-18-000019:notes:17]
|  | Three Months Ended |
|  | March 31, 2018 |  | March 31, 2017 |
| Weighted-average fair value per share granted | $ | 11.27 |  |  | $ | 9.28 |  |
| Shares issued under the ESPP | 0.7 |  |  | 0.6 |  |
| Weighted-average price per share issued | $ | 31.29 |  |  | $ | 27.97 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001262039-18-000019:notes:18]
COMMITMENTS AND CONTINGENCIES

[0001262039-18-000019:notes:19]
The following table summarizes our future principal contractual obligations as of March 31, 2018 (in millions):

[0001262039-18-000019:notes:20]
|  | Total |  | 2018 (remainder) |  | 2019 |  | 2020 |  | 2021 |  | 2022 |  | Thereafter |
| Operating lease commitments | $ | 55.4 |  |  | $ | 12.6 |  |  | $ | 13.9 |  |  | $ | 10.7 |  |  | $ | 6.8 |  |  | $ | 4.2 |  |  | $ | 7.2 |  |
| Inventory purchase commitments | 106.1 |  |  | 101.9 |  |  | — |  |  | 4.2 |  |  | — |  |  | — |  |  | — |  |
| Total | $ | 161.5 |  |  | $ | 114.5 |  |  | $ | 13.9 |  |  | $ | 14.9 |  |  | $ | 6.8 |  |  | $ | 4.2 |  |  | $ | 7.2 |  |

[0001262039-18-000019:notes:21]
Operating Leases—We lease certain facilities under various non-cancelable operating leases, which expire through 2026. Certain leases require us to pay variable costs such as taxes, maintenance, and insurance. The terms of certain operating leases also provide for renewal options and escalation clauses. Rent expense was $4.1 million and $4.5 million during the three months ended March 31, 2018 and March 31, 2017, respectively. Rent expense is recognized using the straight-line method over the term of the lease.

[0001262039-18-000019:notes:22]
Inventory Purchase Commitments—Our independent contract manufacturers procure components and build our products based on our forecasts. These forecasts are based on estimates of future demand for our products, which are in turn based on historical trends and an analysis from our sales and marketing organizations, adjusted for overall market conditions. In order to reduce manufacturing lead times and plan for adequate component supply, we may issue purchase orders to some of our independent contract manufacturers which may not be cancelable. As of March 31, 2018, we had $106.1 million of open purchase orders with our independent contract manufacturers that may not be cancelable.

[0001262039-18-000019:notes:23]
Other Contractual Commitments and Open Purchase Orders—In addition to commitments with contract manufacturers, we have open purchase orders and contractual obligations in the ordinary course of business for which we have not received goods or services. As of March 31, 2018, we had $10.0 million in other contractual commitments having a remaining term in excess of one year that may not be cancelable.

[0001262039-18-000019:notes:24]
Litigation—We are involved in disputes, litigation, and other legal actions. For lawsuits where we are the defendant, we are in the process of defending these litigation matters, and while there can be no assurances and the outcome of these matters is currently not determinable, we currently believe that there are no existing claims or proceedings that are likely to have a material adverse effect on our financial position. There are many uncertainties associated with any litigation and these actions or other third-party claims against us may cause us to incur costly litigation fees, including contingent legal fees with related parties, costs and substantial settlement charges, and possibly subject us to damages and other penalties. In addition, the resolution of any intellectual property litigation may require us to make royalty payments, which could adversely affect our gross margins in future periods. If any of those events were to occur, our business, financial condition, results of operations, and cash flows could be adversely affected. The actual liability in any such matters may be materially different from our estimates, if any, which could result in the need to adjust the liability and record additional expenses. As required under ASC 450, Contingencies, issued by the FASB, we accrue for contingencies when we believe that a loss is probable and that we can reasonably estimate the amount of any such loss.

[0001262039-18-000019:notes:25]
In October 2016, we received a letter from the United States Attorney’s Office for the Northern District of California requesting information relating to our compliance with the Trade Agreements Act. We have been fully cooperating with this ongoing inquiry and have periodically met and spoken with the United States Attorney’s Office in connection with this matter.

[0001262039-18-000019:notes:26]
Indemnification—Under the indemnification provisions of our standard sales contracts, we agree to defend our customers against third-party claims asserting various allegations such as product defects and infringement of certain intellectual property rights, which may include patents, copyrights, trademarks or trade secrets, and to pay judgments entered on such claims. In some contracts, our exposure under these indemnification provisions is limited by the terms of the contracts to certain defined limits, such as the total amount paid by our customer under the agreement. However, certain agreements include covenants, penalties and indemnification provisions including and beyond indemnification for third-party claims of intellectual property infringement, that could potentially expose us to losses in excess of the amount received under the agreement, and in some instances to potential liability that is not contractually limited. To date, there have been no material awards under such indemnification provisions.


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0001262039-18-000019:notes:27]
[same as prior period, unchanged from 0001262039-17-000034:notes:38]

[0001262039-18-000019:notes:28]
Our tax-deferred savings plan under our 401(k) Plan, permits participating employees to defer a portion of their pre-tax earnings. In Canada, we have a Group Registered Retirement Savings Plan Program (the “RRSP”), which permits participants to make tax deductible contributions. Our board of directors approved 50% matching contributions on employee contributions up to 4% of each employee’s eligible earnings. Our matching contributions to our 401(k) Plan and the RRSP for the three months ended March 31, 2018 and March 31, 2017 were $1.5 million and $1.3 million, respectively.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001262039-18-000019:notes:29]
[same as prior period, unchanged from 0001262039-17-000034:notes:40]

[0001262039-18-000019:notes:30]
The following table summarizes the changes in accumulated balances of other comprehensive loss (in millions):

[0001262039-18-000019:notes:31]
|  | March 31, 2018 |
|  | Unrealized Losses on Investments |  | Tax provision related to unrealized gains or losses on investments |  | Total |
| Beginning balance | $ | (1.3 | ) |  | $ | 0.5 |  |  | $ | (0.8 | ) |
| Other comprehensive loss before reclassifications | (1.2 | ) |  | — |  |  | (1.2 | ) |
| Amounts reclassified from accumulated other comprehensive loss | — |  |  | — |  |  | — |  |
| Net current-period other comprehensive loss | (1.2 | ) |  | — |  |  | (1.2 | ) |
| Ending balance | $ | (2.5 | ) |  | $ | 0.5 |  |  | $ | (2.0 | ) |

[0001262039-18-000019:notes:32]
Amounts reclassified from accumulated other comprehensive loss for unrealized losses on investments and tax provision related to unrealized gains or losses on investments are recorded in other income (expense)—net and in benefit from income taxes, respectively.


## us-gaap:CostMethodInvestmentsDescriptionTextBlock

[0001262039-18-000019:notes:33]
[same as prior period, unchanged from 0001262039-17-000034:notes:44]

[0001262039-18-000019:notes:34]
Our investments in the equity securities of privately held companies totaled $12.1 million as of March 31, 2018 and December 31, 2017. These investments, which were previously accounted for at cost, are now accounted for at cost, adjusted for changes in observable prices minus impairment. We own less than 20% of the voting securities in each of these investments and do not have the ability to exercise significant influence over operating and financial policies of the respective entities. These investments are carried at historical cost and are recorded as other assets on our condensed consolidated balance sheets and would be measured at fair value if indicators of impairment existed. As of March 31, 2018, no events have occurred that would adversely affect the carrying value of these investments.

[0001262039-18-000019:notes:35]
As of March 31, 2018, we determined that we had a variable interest in these privately held companies. However, we determined that we were not the primary beneficiary as we did not have the power to direct their activities that most significantly affect their economic performance. The VIEs are not required to be consolidated in our condensed consolidated financial statements.


## us-gaap:DisaggregationOfRevenueTableTextBlock

[0001262039-18-000019:notes:36]
Disaggregation of Revenue

[0001262039-18-000019:notes:37]
The following table presents our revenue disaggregated by major product and service lines (in millions):

[0001262039-18-000019:notes:38]
|  | Three Months Ended |
|  | March 31, 2018 |  | March 31, 2017 (1) |
| Product | $ | 142.8 |  |  | $ | 135.3 |  |
| Service: |  |  |  |
| Security subscription | 136.6 |  |  | 113.5 |  |
| Technical support | 109.6 |  |  | 81.1 |  |
| Professional services and training | 10.0 |  |  | 10.7 |  |
| Total service revenue | 256.2 |  |  | 205.3 |  |
| Total revenue | $ | 399.0 |  |  | $ | 340.6 |  |
| (1) As noted above, prior period amounts have not been adjusted under the modified retrospective method. |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001262039-18-000019:notes:39]
[same as prior period, unchanged from 0001262039-17-000034:notes:52]

[0001262039-18-000019:notes:40]
[same as prior period, unchanged from 0001262039-17-000034:notes:53]

[0001262039-18-000019:notes:41]
We have stock-based compensation plans pursuant to which we have granted RSUs and stock options. We also have an ESPP for eligible employees. As of March 31, 2018, there were a total of 55.2 million shares of common stock available for grant under our stock-based compensation plans.

[0001262039-18-000019:notes:42]
[same as prior period, unchanged from 0001262039-17-000034:notes:55]

[0001262039-18-000019:notes:43]
The following table summarizes the activity and related information for RSUs for the periods presented below (in millions, except per share amounts):

[0001262039-18-000019:notes:44]
|  | Restricted Stock Units Outstanding |
|  | Number of Shares |  | Weighted-Average Grant Date Fair Value per Share |
| Balance—December 31, 2017 | 8.5 |  |  | $ | 34.79 |  |
| Granted | 2.5 |  |  | 49.05 |  |
| Forfeited | (0.3 | ) |  | 35.63 |  |
| Vested | (1.4 | ) |  | 34.15 |  |
| Balance—March 31, 2018 | 9.3 |  |  | $ | 38.86 |  |

[0001262039-18-000019:notes:45]
As of March 31, 2018, total compensation expense related to unvested RSUs granted to employees and non-employees under the 2009 Plan, but not yet recognized, was $333.3 million. This expense is expected to be amortized on a straight-line basis over a weighted-average vesting period of 2.91 years.

[0001262039-18-000019:notes:46]
[same as prior period, unchanged from 0001262039-17-000034:notes:59]

[0001262039-18-000019:notes:47]
[same as prior period, unchanged from 0001262039-17-000034:notes:60]

[0001262039-18-000019:notes:48]
The following table summarizes the stock option activity and related information for the periods presented below (in millions, except exercise prices and contractual life):

[0001262039-18-000019:notes:49]
|  | Options Outstanding |
|  | Numberof Shares |  | Weighted-AverageExercisePrice |  | Weighted-AverageRemainingContractualLife (Years) |  | AggregateIntrinsicValue |
| Balance—December 31, 2017 | 4.3 |  |  | $ | 27.50 |  |  |  |  |  |  |
| Granted | 0.7 |  |  | 49.06 |  |  |  |  |  |
| Forfeited | (0.1 | ) |  | 30.02 |  |  |  |  |  |
| Exercised | (1.0 | ) |  | 23.94 |  |  |  |  |  |
| Balance—March 31, 2018 | 3.9 |  |  | $ | 32.16 |  |  |  |  |  |
| Options vested and expected to vest—March 31, 2018 | 3.9 |  |  | $ | 32.16 |  |  | 4.03 |  | $ | 83.4 |  |
| Options exercisable—March 31, 2018 | 2.1 |  |  | $ | 27.12 |  |  | 2.52 |  | $ | 56.3 |  |

[0001262039-18-000019:notes:50]
The aggregate intrinsic value represents the difference between the exercise price of stock options and the quoted market price of our common stock on March 31, 2018, for all in-the-money stock options. As of March 31, 2018, total compensation expense related to unvested stock options granted to employees but not yet recognized was $20.8 million. This expense is expected to be amortized on a straight-line basis over a weighted-average period of 3.0 years.

[0001262039-18-000019:notes:51]
[same as prior period, unchanged from 0001262039-17-000034:notes:64]

[0001262039-18-000019:notes:52]
[same as prior period, unchanged from 0001262039-17-000034:notes:65]

[0001262039-18-000019:notes:53]
|  | Three Months Ended |
|  | March 31, 2018 |  | March 31, 2017 |
| Expected term in years | 0.5 |  |  | 0.5 |  |
| Volatility | 27 | % |  | 33 | % |
| Risk-free interest rate | 1.8 | % |  | 0.7 | % |
| Dividend rate | — | % |  | — | % |

[0001262039-18-000019:notes:54]
[same as prior period, unchanged from 0001262039-17-000034:notes:67]

[0001262039-18-000019:notes:55]
Stock-based compensation expense is included in costs and expenses as follows (in millions):

[0001262039-18-000019:notes:56]
|  | Three Months Ended |
|  | March 31, 2018 |  | March 31, 2017 |
| Cost of product revenue | $ | 0.4 |  |  | $ | 0.3 |  |
| Cost of service revenue | 2.5 |  |  | 2.3 |  |
| Research and development | 8.4 |  |  | 7.9 |  |
| Sales and marketing | 20.9 |  |  | 19.0 |  |
| General and administrative | 4.3 |  |  | 3.8 |  |
| Total stock-based compensation expense | $ | 36.5 |  |  | $ | 33.3 |  |

[0001262039-18-000019:notes:57]
[same as prior period, unchanged from 0001262039-17-000034:notes:70]

[0001262039-18-000019:notes:58]
In January 2016, our board of directors approved the Share Repurchase Program (the “Repurchase Program”), which authorized the repurchase of up to $200.0 million of our outstanding common stock through December 31, 2017. In 2016 and 2017, our board of directors approved the increases in the aggregate authorized repurchase amount under the Repurchase Program by $100.0 million and $700.0 million, respectively, to a total of $1.0 billion. Under the Repurchase Program, share repurchases may be made by us from time to time in privately negotiated transactions or in open market transactions. The Repurchase Program does not require us to purchase a minimum number of shares, and may be suspended, modified or discontinued at any time without prior notice.

[0001262039-18-000019:notes:59]
During the three months ended March 31, 2018, we repurchased 2.5 million shares of common stock under the Repurchase Program in open market transactions at an average price of $45.96 per share, for an aggregate purchase price of $115.5 million. As of March 31, 2018, $327.3 million remained available for future share repurchases under the Repurchase Program.


## us-gaap:EarningsPerShareTextBlock

[0001262039-18-000019:notes:60]
[same as prior period, unchanged from 0001262039-17-000034:notes:73]

[0001262039-18-000019:notes:61]
Basic net income per share is computed by dividing net income by the weighted-average number of shares of common stock outstanding during the period. Diluted net income per share is computed by dividing net income by the weighted-average number of shares of common stock outstanding during the period, plus the dilutive effects of RSUs, stock options and the ESPP. Dilutive shares of common stock are determined by applying the treasury stock method.

[0001262039-18-000019:notes:62]
A reconciliation of the numerator and denominator used in the calculation of basic and diluted net income per share is as follows (in millions, except per share amounts):

[0001262039-18-000019:notes:63]
|  | Three Months Ended |
|  | March 31, 2018 |  | March 31, 2017 |
| Numerator: |  |  |  |
| Net income | $ | 41.6 |  |  | $ | 10.7 |  |
| Denominator: |  |  |  |
| Basic shares: |  |  |  |
| Weighted-average common stock outstanding-basic | 167.7 |  |  | 174.5 |  |
| Diluted shares: |  |  |  |
| Weighted-average common stock outstanding-basic | 167.7 |  |  | 174.5 |  |
| Effect of potentially dilutive securities: |  |  |  |
| RSUs | 2.7 |  |  | 2.2 |  |
| Stock options | 1.3 |  |  | 1.5 |  |
| ESPP | 0.1 |  |  | 0.1 |  |
| Weighted-average shares used to compute diluted net income per share | 171.8 |  |  | 178.3 |  |
| Net income per share: |  |  |  |
| Basic | $ | 0.25 |  |  | $ | 0.06 |  |
| Diluted | $ | 0.24 |  |  | $ | 0.06 |  |

[0001262039-18-000019:notes:64]
The following weighted-average shares of common stock were excluded from the computation of diluted net income per share for the periods presented, as their effect would have been antidilutive (in millions):

[0001262039-18-000019:notes:65]
|  | Three Months Ended |
|  | March 31, 2018 |  | March 31, 2017 |
| RSUs | 1.1 |  |  | 2.5 |  |
| Stock options | 0.5 |  |  | 1.1 |  |
| ESPP | 0.2 |  |  | 0.3 |  |
|  | 1.8 |  |  | 3.9 |  |


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0001262039-18-000019:notes:66]
[same as prior period, unchanged from 0001262039-17-000034:notes:79]

[0001262039-18-000019:notes:67]
The following tables show the gross unrealized losses and the related fair values of our investments that have been in a continuous unrealized loss position (in millions):

[0001262039-18-000019:notes:68]
|  | March 31, 2018 |
|  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
|  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |
| Corporate debt securities | $ | 317.7 |  |  | $ | (1.8 | ) |  | $ | 51.9 |  |  | $ | (0.5 | ) |  | $ | 369.6 |  |  | $ | (2.3 | ) |
| Certificates of deposit and term deposits | 56.3 |  |  | (0.1 | ) |  | — |  |  | — |  |  | 56.3 |  |  | (0.1 | ) |
| U.S. government and agency securities | 15.0 |  |  | — |  |  | 8.4 |  |  | (0.1 | ) |  | 23.4 |  |  | (0.1 | ) |
| Total available-for-sale securities | $ | 389.0 |  |  | $ | (1.9 | ) |  | $ | 60.3 |  |  | $ | (0.6 | ) |  | $ | 449.3 |  |  | $ | (2.5 | ) |

[0001262039-18-000019:notes:69]
|  | December 31, 2017 |
|  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
|  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |
| Corporate debt securities | $ | 317.4 |  |  | $ | (0.9 | ) |  | $ | 58.2 |  |  | $ | (0.3 | ) |  | $ | 375.6 |  |  | $ | (1.2 | ) |
| Certificates of deposit and term deposits | 37.2 |  |  | — |  |  | — |  |  | — |  |  | 37.2 |  |  | — |  |
| Commercial paper | 29.0 |  |  | — |  |  | — |  |  | — |  |  | 29.0 |  |  | — |  |
| U.S. government and agency securities | 17.0 |  |  | — |  |  | 11.4 |  |  | (0.1 | ) |  | 28.4 |  |  | (0.1 | ) |
| Total available-for-sale securities | $ | 400.7 |  |  | $ | (0.9 | ) |  | $ | 69.6 |  |  | $ | (0.4 | ) |  | $ | 470.3 |  |  | $ | (1.3 | ) |

[0001262039-18-000019:notes:70]
The contractual maturities of our investments were as follows (in millions):

[0001262039-18-000019:notes:71]
|  | March 31, 2018 |  | December 31, 2017 |
| Due within one year | $ | 468.3 |  |  | $ | 440.3 |  |
| Due within one to three years | 82.5 |  |  | 98.0 |  |
| Total | $ | 550.8 |  |  | $ | 538.3 |  |

[0001262039-18-000019:notes:72]
Available-for-sale securities are reported at fair value, with unrealized gains and losses and the related tax impact included as a separate component of stockholders’ equity and in comprehensive income. Realized losses on available-for-sale securities were insignificant in the periods presented and are included in other income (expense)—net in our condensed consolidated statements of operations. We use the specific identification method to determine the cost basis of investments sold.

[0001262039-18-000019:notes:73]
The unrealized losses on our available-for-sale securities were caused by fluctuations in market value and interest rates as a result of the economic environment. As the decline in market value are attributable to changes in market conditions and not credit quality, and because we have concluded currently that we neither intend to sell nor is it more likely than not that we will be required to sell these investments prior to a recovery of par value, we do not consider these investments to be other-than temporarily impaired as of March 31, 2018.

[0001262039-18-000019:notes:74]
[same as prior period, unchanged from 0001262039-17-000034:notes:87]

[0001262039-18-000019:notes:75]
[same as prior period, unchanged from 0001262039-17-000034:notes:88]

[0001262039-18-000019:notes:76]
[same as prior period, unchanged from 0001262039-17-000034:notes:89]

[0001262039-18-000019:notes:77]
[same as prior period, unchanged from 0001262039-17-000034:notes:90]

[0001262039-18-000019:notes:78]
[same as prior period, unchanged from 0001262039-17-000034:notes:91]

[0001262039-18-000019:notes:79]
[same as prior period, unchanged from 0001262039-17-000034:notes:92]

[0001262039-18-000019:notes:80]
[same as prior period, unchanged from 0001262039-17-000034:notes:93]

[0001262039-18-000019:notes:81]
[same as prior period, unchanged from 0001262039-17-000034:notes:94]

[0001262039-18-000019:notes:82]
[same as prior period, unchanged from 0001262039-17-000034:notes:95]

[0001262039-18-000019:notes:83]
The following tables present the fair value of our financial assets measured at fair value on a recurring basis as of March 31, 2018 and December 31, 2017 (in millions):

[0001262039-18-000019:notes:84]
|  | March 31, 2018 |  | December 31, 2017 |
|  | AggregateFairValue |  | QuotedPrices inActiveMarkets ForIdenticalAssets |  | SignificantOtherObservableRemainingInputs |  | SignificantOtherUnobservableRemainingInputs |  | AggregateFairValue |  | QuotedPrices inActiveMarkets ForIdenticalAssets |  | SignificantOtherObservableRemainingInputs |  | SignificantOtherUnobservableRemainingInputs |
|  |  |  | (Level 1) |  | (Level 2) |  | (Level 3) |  |  |  | (Level 1) |  | (Level 2) |  | (Level 3) |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate debt securities | $ | 371.5 |  |  | $ | — |  |  | $ | 371.5 |  |  | $ | — |  |  | $ | 411.1 |  |  | $ | — |  |  | $ | 411.1 |  |  | $ | — |  |
| Money market funds | 108.0 |  |  | 108.0 |  |  | — |  |  | — |  |  | 195.6 |  |  | 195.6 |  |  | — |  |  | — |  |
| Certificates of deposit and term deposits | 143.8 |  |  | — |  |  | 143.8 |  |  | — |  |  | 132.1 |  |  | — |  |  | 132.1 |  |  | — |  |
| Commercial paper | 93.0 |  |  | — |  |  | 93.0 |  |  | — |  |  | 128.9 |  |  | — |  |  | 128.9 |  |  | — |  |
| U.S. government and agency securities | 23.4 |  |  | 20.0 |  |  | 3.4 |  |  | — |  |  | 28.4 |  |  | 24.9 |  |  | 3.5 |  |  | — |  |
| Total | $ | 739.7 |  |  | $ | 128.0 |  |  | $ | 611.7 |  |  | $ | — |  |  | $ | 896.1 |  |  | $ | 220.5 |  |  | $ | 675.6 |  |  | $ | — |  |
| Reported as: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents | $ | 188.9 |  |  |  |  |  |  |  |  | $ | 357.8 |  |  |  |  |  |  |  |
| Short-term investments | 468.3 |  |  |  |  |  |  |  |  | 440.3 |  |  |  |  |  |  |  |
| Long-term investments | 82.5 |  |  |  |  |  |  |  |  | 98.0 |  |  |  |  |  |  |  |
| Total | $ | 739.7 |  |  |  |  |  |  |  |  | $ | 896.1 |  |  |  |  |  |  |  |

[0001262039-18-000019:notes:85]
There were no transfers between Level 1 and Level 2 of the fair value hierarchy during the three months ended March 31, 2018 and year ended December 31, 2017.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001262039-18-000019:notes:86]
GOODWILL AND OTHER INTANGIBLE ASSETS—Net

[0001262039-18-000019:notes:87]
[same as prior period, unchanged from 0001262039-17-000034:notes:101]

[0001262039-18-000019:notes:88]
As of March 31, 2018, we had goodwill of $14.6 million. There were no impairments to goodwill during the three months ended March 31, 2018 or during prior periods.

[0001262039-18-000019:notes:89]
[same as prior period, unchanged from 0001262039-17-000034:notes:103]

[0001262039-18-000019:notes:90]
The following tables present other intangible assets—net as of March 31, 2018 and December 31, 2017 (in millions, except years):

[0001262039-18-000019:notes:91]
|  | March 31, 2018 |
|  | Weighted-Average Useful Life (in Years) |  | Gross |  | Accumulated Amortization |  | Net |
| Other intangible assets—net: |  |  |  |  |  |  |  |
| Finite-lived intangible assets: |  |  |  |  |  |  |  |
| Developed technologies and other | 3.8 |  | $ | 25.6 |  |  | $ | 15.0 |  |  | $ | 10.6 |  |
| Customer relationships | 4.7 |  | 14.5 |  |  | 10.6 |  |  | 3.9 |  |
|  |  |  | $ | 40.1 |  |  | $ | 25.6 |  |  | $ | 14.5 |  |

[0001262039-18-000019:notes:92]
|  | December 31, 2017 |
|  | Weighted-Average Useful Life (in Years) |  | Gross |  | Accumulated Amortization |  | Net |
| Other intangible assets—net: |  |  |  |  |  |  |  |
| Finite-lived intangible assets: |  |  |  |  |  |  |  |
| Developed technologies and other | 3.8 |  | $ | 24.0 |  |  | $ | 13.7 |  |  | $ | 10.3 |  |
| Customer relationships | 4.7 |  | 14.5 |  |  | 10.1 |  |  | 4.4 |  |
|  |  |  | 38.5 |  |  | 23.8 |  |  | 14.7 |  |
| Indefinite-lived intangible assets: |  |  |  |  |  |  |  |
| In-process research and development |  |  | 1.6 |  |  | — |  |  | 1.6 |  |
| Total other intangible assets—net |  |  | $ | 40.1 |  |  | $ | 23.8 |  |  | $ | 16.3 |  |

[0001262039-18-000019:notes:93]
The in-process research and development intangible asset of $1.6 million was completed in the first quarter of 2018. Upon completion, the cost was transferred to developed technology and is amortized over the estimated useful life of four years.

[0001262039-18-000019:notes:94]
Amortization expense was $1.8 million and $2.3 million, during the three months ended March 31, 2018 and March 31, 2017, respectively. The following table summarizes estimated future amortization expense of finite-lived intangible assets—net (in millions):

[0001262039-18-000019:notes:95]
|  | Amount |
| Years: |  |
| 2018 | $ | 5.4 |  |
| 2019 | 5.8 |  |
| 2020 | 2.8 |  |
| 2021 and thereafter | 0.5 |  |
| Total | $ | 14.5 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001262039-18-000019:notes:96]
[same as prior period, unchanged from 0001262039-17-000034:notes:110]

[0001262039-18-000019:notes:97]
Our effective tax rate was a tax benefit of 13% for the three months ended March 31, 2018, compared to a tax benefit of 32% for the same period last year, with the primary difference being the change in the federal tax rate to 21% in 2018 from 35% in the prior year. The effective tax rates for the periods presented are comprised of U.S. federal and state taxes, withholding taxes and foreign taxes of $8.5 million, which are offset by a tax provision benefit of $5.6 million for stock-based compensation and release of reserve on uncertain tax position including interests of $7.8 million. The tax rate for the three months ended March 31, 2017 was comprised of the U.S. federal and state taxes, withholding taxes and foreign taxes of $2.9 million, which were offset by a tax provision benefit of $5.5 million for stock compensation.

[0001262039-18-000019:notes:98]
As of March 31, 2018 and December 31, 2017, unrecognized tax benefits were $77.6 million and $72.5 million, respectively. The amount of $76.2 million in unrecognized tax benefits, if recognized, would favorably affect our effective tax rate. It is our policy is to include accrued interest and penalties related to uncertain tax benefits in income tax expense. As of March 31, 2018 and December 31, 2017, accrued interest and penalties were $13.4 million and $13.5 million, respectively. It is reasonably possible that our gross unrecognized tax benefits will decrease by up to $7.0 million in the next 12 months, primarily due to the lapse of the statute of limitations and an audit settlement. These adjustments, if recognized, would positively impact our effective tax rate, and would be recognized as additional tax benefits.

[0001262039-18-000019:notes:99]
We file income tax returns in the U.S. federal jurisdiction and in various U.S. state and foreign jurisdictions. Generally, we are no longer subject to U.S. state and non-U.S. income tax examinations by tax authorities for tax years prior to 2008. We are no longer subject to examination by U.S federal income tax authorities for tax years prior to 2015. We have closed the Internal Revenue Service audit for tax years 2012, 2013 and 2014. In March 2018, we received a refund of $6.8 million for a carry-back claim approved in this audit. The tax authorities in France are examining the intercompany relationship between Fortinet, Inc., Fortinet France and Fortinet Singapore. In May 2017, we received a notice from the French tax authorities that an audit was officially opened for tax years from 2007 to 2015. The tax authorities in Israel have notified us that we will be audited for tax years from 2008 to 2014.


## us-gaap:InventoryDisclosureTextBlock

[0001262039-18-000019:notes:100]
[same as prior period, unchanged from 0001262039-17-000034:notes:114]

[0001262039-18-000019:notes:101]
Inventory consisted of the following (in millions):

[0001262039-18-000019:notes:102]
|  | March 31, 2018 |  | December 31, 2017 |
| Raw materials | $ | 12.0 |  |  | $ | 13.0 |  |
| Finished goods | 68.0 |  |  | 64.3 |  |
| Inventory | $ | 80.0 |  |  | $ | 77.3 |  |

[0001262039-18-000019:notes:103]
Inventory includes materials at contract manufacturers of $2.0 million and $2.6 million as of March 31, 2018 and December 31, 2017, respectively. Inventory also includes finished goods held by distributors where revenue is recognized on a sell-through basis of $0.1 million as of December 31, 2017.


## us-gaap:LongLivedAssetsByGeographicAreasTableTextBlock

[0001262039-18-000019:notes:104]
| Property and Equipment—net | March 31, 2018 |  | December 31, 2017 |
| Americas: |  |  |  |
| United States | $ | 115.3 |  |  | $ | 115.6 |  |
| Canada | 103.2 |  |  | 103.8 |  |
| LATAM | 0.4 |  |  | 0.3 |  |
| Total Americas | 218.9 |  |  | 219.7 |  |
| EMEA: |  |  |  |
| France | 13.1 |  |  | 11.9 |  |
| Other EMEA | 3.9 |  |  | 5.8 |  |
| Total EMEA | 17.0 |  |  | 17.7 |  |
| APAC | 9.2 |  |  | 8.0 |  |
| Total property and equipment—net | $ | 245.1 |  |  | $ | 245.4 |  |


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001262039-18-000019:notes:105]
Recently Adopted Accounting Standards

[0001262039-18-000019:notes:106]
Financial Instruments – Recognition and Measurement

[0001262039-18-000019:notes:107]
In January 2016, the FASB issued ASU 2016-01—Financial Instruments—Overall: Recognition and Measurement of Financial Assets and Financial Liabilities, which requires most equity investments to be measured at fair value, with subsequent changes in fair value recognized in net income. A practicality exception applies to those equity investments that do not have a readily determinable fair value. These investments may be measured at cost, adjusted for changes in observable prices minus impairment. ASU 2016-01 was effective prospectively for us beginning on January 1, 2018 for our equity investments, which were previously accounted for under the cost-method. We adopted ASU 2016-01 on January 1, 2018. There was no material impact on our condensed consolidated financial statements as of the adoption date.

[0001262039-18-000019:notes:108]
Revenue Recognition

[0001262039-18-000019:notes:109]
In May 2014, the FASB issued ASU 2014-09—Revenue from Contracts with Customers (Topic 606), which supersedes the revenue recognition requirements in Topic 605, Revenue Recognition, and requires entities to recognize revenue when control of the promised goods or services is transferred to customers at an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services. We adopted ASU 2014-09 and its related amendments (collectively known as Topic 606) as of January 1, 2018 using the modified retrospective transition method. The comparative information has not been restated and continues to be reported under the accounting standards in effect for those periods.

[0001262039-18-000019:notes:110]
We recorded a net reduction to our accumulated deficit as of January 1, 2018 of $117.3 million due to the cumulative impact of adopting Topic 606. The primary impact of adopting Topic 606 relates to the deferral of our incremental contract costs, which are comprised of sales commissions. Prior to January 1, 2018, we expensed all sales commissions upfront. Beginning on January 1, 2018, we continue to expense sales commissions related to product sales upfront, but will capitalize and then amortize certain sales commissions on service contracts over the applicable amortization period. The capitalized sales commissions for initial service contracts are deferred and then amortized as expense on a straight-line basis over the period of benefit which we have determined to be five years. Sales commissions for renewal contracts are deferred and then amortized on a straight line basis over the contractual period of the underlying contracts. The deferral of sales commissions generated deferred tax liability of $23.8 million, of which $18.0 million was recorded against deferred tax assets and the remaining $5.8 million was recorded in other long-term liabilities on our consolidated balance sheet. The impact on deferred revenue as of January 1, 2018 was $4.1 million, which primarily relates to certain changes in revenue recognition on software license sales and the acceleration of revenue from U.S.-based channel partners which were previously deferred until the product was sold through. Beginning on January 1, 2018, our sales returns reserve is now included on the balance sheet in accrued liabilities and no longer as a reduction to our accounts receivable. See Note 2 for further details.

[0001262039-18-000019:notes:111]
The cumulative effects of the changes made to our January 1, 2018 consolidated balance sheet for the adoption of Topic 606 were as follows (in millions):

[0001262039-18-000019:notes:112]
|  | Balance at December 31, 2017 |  | Adjustments due to Topic 606 |  | Balance at January 1, 2018 |
| Assets: |  |  |  |  |  |
| Accounts receivable, net | $ | 348.2 |  |  | $ | 13.6 |  |  | $ | 361.8 |  |
| Inventory | $ | 77.3 |  |  | $ | (0.1 | ) |  | $ | 77.2 |  |
| Deferred tax assets | $ | 146.9 |  |  | $ | (18.0 | ) |  | $ | 128.9 |  |
| Deferred contract costs | $ | — |  |  | $ | 137.1 |  |  | $ | 137.1 |  |
| Liabilities: |  |  |  |  |  |
| Accrued liabilities | $ | 50.0 |  |  | $ | 13.6 |  |  | $ | 63.6 |  |
| Deferred revenue, current | $ | 793.8 |  |  | $ | 0.3 |  |  | $ | 794.1 |  |
| Deferred revenue, non-current | $ | 542.5 |  |  | $ | (4.4 | ) |  | $ | 538.1 |  |
| Other liabilities, non-current | $ | 8.6 |  |  | $ | 5.8 |  |  | $ | 14.4 |  |
| Stockholders’ equity: |  |  |  |  |  |
| Accumulated deficit | $ | (319.6 | ) |  | $ | 117.3 |  |  | $ | (202.3 | ) |

[0001262039-18-000019:notes:113]
Recent Accounting Standards Not Yet Effective

[0001262039-18-000019:notes:114]
Leases

[0001262039-18-000019:notes:115]
In February 2016, the FASB issued ASU 2016-02—Leases, which requires the recognition of right-of-use assets and lease liabilities on the consolidated balance sheet for substantially all leases. ASU 2016-02 includes a number of optional practical expedients that entities may elect to apply. ASU 2016-02 will also require significant additional disclosures about the amount, timing and uncertainty of cash flows from leases. ASU 2016-02 will be effective for us beginning on January 1, 2019, using a modified retrospective approach. Based on our current lease portfolio, we currently estimate the value of leased assets and liabilities that may be recognized on the consolidated balance sheet to be at least $45.0 million. We are continuing to evaluate the impact of ASU 2016-02 and our estimate is subject to change. We do not believe that ASU 2016-02 will have a material impact on our consolidated statements of operations and cash flows. We expect to expand our disclosures in the notes to consolidated financial statements to include more details on our leases, significant judgments and lease-related amounts recognized in the consolidated financial statements.


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001262039-18-000019:notes:116]
PROPERTY AND EQUIPMENT—Net

[0001262039-18-000019:notes:117]
Property and equipment—net consisted of the following (in millions):

[0001262039-18-000019:notes:118]
|  | March 31, 2018 |  | December 31, 2017 |
| Building and building improvements | $ | 135.2 |  |  | $ | 133.2 |  |
| Computer equipment and software | 86.9 |  |  | 79.9 |  |
| Land | 65.6 |  |  | 65.6 |  |
| Leasehold improvements | 21.5 |  |  | 20.8 |  |
| Evaluation units | 19.2 |  |  | 20.1 |  |
| Furniture and fixtures | 15.4 |  |  | 14.7 |  |
| Construction-in-progress | 2.9 |  |  | 6.3 |  |
| Total property and equipment | 346.7 |  |  | 340.6 |  |
| Less: accumulated depreciation | (101.6 | ) |  | (95.2 | ) |
| Property and equipment—net | $ | 245.1 |  |  | $ | 245.4 |  |

[0001262039-18-000019:notes:119]
Depreciation expense was $11.4 million and $11.2 million during the three months ended March 31, 2018 and March 31, 2017, respectively.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001262039-18-000019:notes:120]
REVENUE RECOGNITION

[0001262039-18-000019:notes:121]
Revenue recognition

[0001262039-18-000019:notes:122]
On January 1, 2018 we adopted Topic 606 using the modified retrospective method applied to those contracts which were not completed as of January 1, 2018. Results for reporting periods beginning after January 1, 2018 are presented under Topic 606, while prior period amounts are not adjusted and continue to be reported under Topic 605. The details of significant changes and quantitative impact of the changes are discussed below.

[0001262039-18-000019:notes:123]
We derive the majority of our revenue from sales of our products, FortiGuard security subscription and FortiCare technical support services, and other services. Beginning in 2018, revenues are recognized when control of these goods or services is transferred to our customers, in an amount that reflects the consideration we expect to be entitled to in exchange for those goods or services. Prior to 2018, revenue was recognized under Topic 605 when all of the following criteria were met: (i) persuasive evidence of an arrangement existed, (ii) delivery has occurred or services have been rendered, (iii) sales price was fixed or determinable and (iv) collectability was reasonably assured.

[0001262039-18-000019:notes:124]
Under Topic 606, we determine revenue recognition through the following steps:

[0001262039-18-000019:notes:125]
•identification of the contract, or contracts, with the customer,

[0001262039-18-000019:notes:126]
•identification of the performance obligations in the contract,

[0001262039-18-000019:notes:127]
•determination of the transaction price,

[0001262039-18-000019:notes:128]
•allocation of the transaction price to the performance obligations in the contract, and

[0001262039-18-000019:notes:129]
•recognition of revenue when, or as, we satisfy a performance obligation.

[0001262039-18-000019:notes:130]
Product revenue primarily consists of sales of hardware and software licenses of our FortiGate, FortiSandbox, FortiManager, FortiAnalyzer and other complimentary products. We derive a substantial majority of product sales from our FortiGate products. We previously recognized product revenue for sales to distributors that had no general right of return and direct sales to end-customers upon shipment, based on general revenue recognition accounting guidance once all other revenue recognition criteria were met. Certain distributors are granted stock rotation rights, limited rights of return or rebates for sales of our products. The arrangement fee for this group of distributors was not fixed or determinable when products were shipped and revenue was therefore deferred and recognized upon sell-through. For sales that included end-customer acceptance criteria, revenue was recognized upon acceptance. Under Topic 606, we recognize product revenue upon shipment when control of the promised goods is transferred to the customer. We recognize revenue from time-based software licenses upon electronic transfer of the license key to the customer. Previously time-based software licenses were recognized over the license term.

[0001262039-18-000019:notes:131]
We generally provide a 1-year warranty on hardware products and a 90-day warranty on software that provides assurance that our hardware or software products conform to published specifications. Such assurance-type warranties are not deemed to be separate performance obligations from the hardware or software product and costs associated with providing the warranties are accrued in accordance with ASC 460-10.

[0001262039-18-000019:notes:132]
Service revenue relates to sales of our FortiGuard security subscription, FortiCare technical support services, and other services. Our FortiGuard security subscription services provide access to our antivirus, intrusion prevention, web filtering and anti-spam functionality. Our FortiCare support services include rights to unspecified software upgrades, maintenance releases and patches, telephone and internet access to technical support personnel. Our typical subscription and contractual support term is one to three years, and to a lesser extent, five years. Our revenue recognition for service arrangements did not change under Topic 606. We continue to recognize revenue from these arrangements ratably over the contractual service period because of continuous transfer of control to the customer. Revenue related to subsequent renewals of these services are recognized over the term of the renewal agreement. We also generate a small portion of our revenue from other services consisting of professional services, training and software-as-a-service (“SaaS”) which is either hosted or cloud-based services. We recognize revenue from professional and training services as the services are provided. We recognize revenue from SaaS as the subscription service is delivered over the term, which is typically one year, or on a monthly usage basis. Our revenue recognition for other services did not change under Topic 606. To date, SaaS revenue has not represented a significant percentage of our total revenue.

[0001262039-18-000019:notes:133]
Our sales arrangements typically contain multiple performance obligations, such as hardware, software license, security subscription, technical support services and other services, which are generally capable of being distinct and accounted for as separate performance obligations. We allocate the transaction price to each performance obligation based on relative standalone selling price. We determine standalone selling price based on the historical pricing and discounting practices for those services when sold separately. We determine standalone selling price for a product or service by considering multiple historical factors including, but not limited to, cost of products, gross margin objectives, pricing practices, geographies and the term of the service contract that fall within a reasonably range as a percentage of list price. Revenue is reported net of sales taxes.

[0001262039-18-000019:notes:134]
Under Topic 605, our products and services in a multiple-element arrangement generally qualified as separate units of accounting. We allocated revenue to each unit of accounting based on an estimated selling price using vendor-specific objective evidence (“VSOE”) of selling price, if it existed, or third-party evidence (“TPE”) of selling price. If neither VSOE nor TPE of selling price existed for a deliverable, we used our best estimate of selling price for that deliverable. For multiple-element arrangements where software deliverables were included, revenue was allocated to the non-software deliverables and to the software deliverables as a group using the relative estimated selling prices of each of the deliverables in the arrangement based on the estimated selling price hierarchy. The amount allocated to the software deliverables was then allocated to each software deliverable using the residual method when VSOE of fair value existed. If evidence of VSOE of fair value of one or more undelivered elements did not exist, all software allocated revenue was deferred and recognized when delivery of those elements occurred or when fair value was established. When the undelivered element for which we did not have VSOE of fair value was support, revenue for the entire arrangement was recognized ratably over the support period. The same residual method and VSOE of fair value principles applied for our multiple element arrangements that contained only software elements.

[0001262039-18-000019:notes:135]
In certain circumstances, our contracts include provisions for sales rebates and other customer incentive programs.  Additionally, in limited circumstances, we may permit end-customers, distributors and resellers to return our products, subject to varying limitations, for a refund within a reasonably short period from the date of purchase. These amounts are accounted for as variable consideration that can decrease the transaction price. We estimate variable consideration at the most likely amounts to which we expect our customers to be entitled. We include estimated amounts in the transaction price to the extent that it is probable that a significant reversal of cumulative revenue recognized will not occur when the uncertainty associated with the variable consideration is resolved. Our estimate for sales return reserve was $12.9 million as of March 31, 2018 and is included in current liabilities in our condensed consolidated balance sheet. Under Topic 605, a sales return reserve of $13.6 million was presented as a reduction to accounts receivable as of December 31, 2017.

[0001262039-18-000019:notes:136]
We generally invoice at the time of our sale for the total price of the products and security and technical support and other services, and the invoice is payable within 30 to 90 days. We also invoice certain software licenses and services on a monthly basis. Amounts billed and due from our customers are classified as receivables on the balance sheet and do not bear interest. We record deferred revenue when cash payments are received or due in advance of our performance.

[0001262039-18-000019:notes:137]
During the three months ended March 31, 2018, we recognized $239.1 million in revenue that was included in the deferred revenue balance as of December 31, 2017.

[0001262039-18-000019:notes:138]
Shipping and handling fees charged to our customers are recognized as product revenue in the period shipped and the related costs for providing these services are recorded as a cost of sale. Shipping and handling fees recognized as product revenue were not significant during the three months ended March 31, 2018 and 2017.

[0001262039-18-000019:notes:139]
Transaction Price Allocated to the Remaining Performance Obligations

[0001262039-18-000019:notes:140]
As of March 31, 2018, we had $1.40 billion in remaining performance obligations, which is substantially comprised of deferred security subscription and technical support services not yet delivered. We expect to recognize revenue on approximately 75% of these remaining performance obligations over the next one to two years, with the remaining balance to be recognized in three to five years.

[0001262039-18-000019:notes:141]
Accounts Receivable

[0001262039-18-000019:notes:142]
Trade accounts receivable are recorded at the invoiced amount. Trade accounts receivable is reduced by allowance for doubtful accounts which is determined based on our assessment of the collectability of customer accounts. The allowance for doubtful accounts was $0.7 million and $0.9 million as of March 31, 2018 and December 31, 2017, respectively. As of December 31, 2017, accounts receivable was also reduced by sales return reserve of $13.6 million which we reclassified to accrued liabilities account as of January 1, 2018 in accordance with the adoption of Topic 606.

[0001262039-18-000019:notes:143]
Contract Assets

[0001262039-18-000019:notes:144]
Contract assets represent amounts that have been recognized as revenue but for which we did not have the unconditional right to invoice the customer. We did not have contract assets as of March 31, 2018 and January 1, 2018.

[0001262039-18-000019:notes:145]
Deferred Contract Costs

[0001262039-18-000019:notes:146]
Sales commissions earned by our sales force are considered incremental and recoverable costs of obtaining a contract with a customer. Sales commissions for the sale of products are recognized at the time of sale. Sales commissions for initial service contracts are deferred and then amortized as an expense on a straight-line basis over the period of benefit which we have determined to be five years. We determined the period of benefit taking into consideration our customer contracts, our technology and other factors. Sales commissions for renewal contracts are deferred and then amortized on a straight line basis over the contractual period of the underlying contracts which ranges from one to three years and, to a lesser extent, five years. The amortization of deferred commissions is included in sales and marketing expense in our condensed consolidated statement of operations. Amortization of deferred contract costs during the three months ended March 31, 2018 was $20.8 million. No impairment loss was recognized during the three months ended March 31, 2018.

[0001262039-18-000019:notes:147]
Practical Expedient

[0001262039-18-000019:notes:148]
We elected to use the contract modification practical expedient. This practical expedient allows for all contract modifications before January 1, 2018 to be aggregated and evaluated at adoption date.

[0001262039-18-000019:notes:149]
Impact on Condensed Consolidated Financial Statements

[0001262039-18-000019:notes:150]
The following tables summarize the impact of adopting Topic 606 on our condensed consolidated financial statements as of and for the three months ended March 31, 2018 (in millions). These tables do not represent the full condensed consolidated financial statements as they only reflect the accounts impacted by the adoption of Topic 606.

[0001262039-18-000019:notes:151]
Condensed Consolidated Balance Sheet

[0001262039-18-000019:notes:152]
|  | As of March 31, 2018 |
|  | As Reported |  | Balances Without Adoption of Topic 606 |  | Effect of ChangeIncrease (Decrease) |
| Assets: |  |  |  |  |  |
| Accounts receivable | $ | 313.1 |  |  | $ | 300.2 |  |  | $ | 12.9 |  |
| Inventory | $ | 80.0 |  |  | $ | 81.5 |  |  | $ | (1.5 | ) |
| Deferred contract costs | $ | 148.7 |  |  | $ | — |  |  | $ | 148.7 |  |
| Deferred tax assets | $ | 138.7 |  |  | $ | 160.6 |  |  | $ | (21.9 | ) |
| Liabilities: |  |  |  |  |  |
| Accrued liabilities | $ | 55.6 |  |  | $ | 40.6 |  |  | $ | 15.0 |  |
| Deferred revenue, current | $ | 817.1 |  |  | $ | 828.8 |  |  | $ | (11.7 | ) |
| Deferred revenue, non-current | $ | 579.3 |  |  | $ | 580.2 |  |  | $ | (0.9 | ) |
| Other liabilities, non-current | $ | 13.4 |  |  | $ | 7.6 |  |  | $ | 5.8 |  |
| Stockholders’ Equity |  |  |  |  |  |
| Accumulated deficit | $ | (262.6 | ) |  | $ | (392.6 | ) |  | $ | 130.0 |  |

[0001262039-18-000019:notes:153]
Condensed Consolidated Statement of Operations

[0001262039-18-000019:notes:154]
|  | Three Months Ended March 31, 2018 |
|  | As Reported |  | Balances Without Adoption of Topic 606 |  | Effect of ChangeIncrease (Decrease) |
| REVENUE: |  |  |  |  |  |
| Product | $ | 142.8 |  |  | $ | 137.1 |  |  | $ | 5.7 |  |
| Service | 256.2 |  |  | 255.5 |  |  | 0.7 |  |
| Total revenue | 399.0 |  |  | 392.6 |  |  | 6.4 |  |
| COSTS OF REVENUE: |  |  |  |  |  |
| Product | 58.2 |  |  | 56.7 |  |  | 1.5 |  |
| GROSS PROFIT: |  |  |  |  |  |
| Product | 84.6 |  |  | 80.4 |  |  | 4.2 |  |
| Service | 217.2 |  |  | 216.5 |  |  | 0.7 |  |
| Total gross profit | 301.8 |  |  | 296.9 |  |  | 4.9 |  |
| OPERATING EXPENSES: |  |  |  |  |  |
| Sales and marketing expenses | 185.3 |  |  | 197.0 |  |  | (11.7 | ) |
| OPERATING INCOME | 32.4 |  |  | 15.8 |  |  | 16.6 |  |
| INCOME BEFORE INCOME TAXES | 36.7 |  |  | 20.1 |  |  | 16.6 |  |
| BENEFIT FROM INCOME TAXES | (4.9 | ) |  | (8.7 | ) |  | 3.8 |  |
| NET INCOME | $ | 41.6 |  |  | $ | 28.8 |  |  | $ | 12.8 |  |
| Net income per share: |  |  |  |  |  |
| Basic | $ | 0.25 |  |  | $ | 0.17 |  |  | $ | 0.08 |  |
| Diluted | $ | 0.24 |  |  | $ | 0.17 |  |  | $ | 0.07 |  |

[0001262039-18-000019:notes:155]
Condensed Consolidated Statement of Cash Flows

[0001262039-18-000019:notes:156]
|  | Three Months Ended March 31, 2018 |
|  | As Reported |  | Balances Without Adoption of Topic 606 |  | Effect of ChangeIncrease (Decrease) |
| Cash flows from operating activities: |  |  |  |  |  |
| Net income | $ | 41.6 |  |  | $ | 28.8 |  |  | $ | 12.8 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |
| Amortization of deferred contract costs | 20.8 |  |  | — |  |  | 20.8 |  |
| Other non-cash | 0.3 |  |  | 0.9 |  |  | (0.6 | ) |
| Changes in operating assets and liabilities: |  |  |  |  |  |  |
| Inventory | (7.3 | ) |  | (8.7 | ) |  | 1.4 |  |
| Deferred contract costs | (32.5 | ) |  | — |  |  | (32.5 | ) |
| Deferred tax assets | (9.6 | ) |  | (13.6 | ) |  | 4.0 |  |
| Accrued liabilities | (4.7 | ) |  | (6.1 | ) |  | 1.4 |  |
| Deferred revenue | 64.1 |  |  | 71.4 |  |  | (7.3 | ) |
| Net cash provided by operating activities | $ | 139.7 |  |  | $ | 139.7 |  |  | $ | — |  |


## us-gaap:RevenueFromExternalCustomersByGeographicAreasTableTextBlock

[0001262039-18-000019:notes:157]
|  | Three Months Ended |
| Revenue | March 31, 2018 |  | March 31, 2017 |
| Americas: |  |  |  |
| United States | $ | 133.9 |  |  | $ | 116.0 |  |
| Latin America (“LATAM”) | 26.5 |  |  | 18.2 |  |
| Canada | 15.4 |  |  | 12.2 |  |
| Total Americas | 175.8 |  |  | 146.4 |  |
| Europe, Middle East and Africa (“EMEA”) | 144.5 |  |  | 126.1 |  |
| Asia Pacific (“APAC”) | 78.7 |  |  | 68.1 |  |
| Total revenue | $ | 399.0 |  |  | $ | 340.6 |  |


## us-gaap:ScheduleOfFiniteLivedIntangibleAssetsTableTextBlock

[0001262039-18-000019:notes:158]
ears):


## us-gaap:SchedulesOfConcentrationOfRiskByRiskFactorTextBlock

[0001262039-18-000019:notes:159]
The following customers, each of which is a distributor, accounted for 10% or more of our revenue:

[0001262039-18-000019:notes:160]
|  | Three Months Ended |
|  | March 31, 2018 (1) |  | March 31, 2017 |
| Exclusive Networks Group | 29 | % |  | 20 | % |
| Fine Tec Computers | * |  |  | 12 | % |
| * Represents less than 10% |
| (1) Due to the acquisition by Exclusive Networks Group of the U.S. division of Fine Tec Computers (“Fine Tec U.S.”) in July 2017, Fine Tec U.S.’s revenue and accounts receivable have been combined with Exclusive Networks Group. |

[0001262039-18-000019:notes:161]
The following customer, which is a distributor, accounted for 10% or more of net accounts receivable:

[0001262039-18-000019:notes:162]
|  | March 31, 2018 |  | December 31, 2017 |
| Exclusive Networks Group | 34 | % |  | 35 | % |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001262039-18-000019:notes:163]
SEGMENT INFORMATION

[0001262039-18-000019:notes:164]
[same as prior period, unchanged from 0001262039-17-000034:notes:156]

[0001262039-18-000019:notes:165]
Revenue by geographic region is based on the billing address of the customer. The following tables set forth revenue and property and equipment—net by geographic region (in millions):


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001262039-18-000019:notes:166]
[same as prior period, unchanged from 0001262039-17-000034:notes:158]
