# FTNT MD&A — 0001262039-18-000019


## mdna

[0001262039-18-000019:mdna:1]
[same as prior period, unchanged from 0001262039-17-000034:mdna:1]

[0001262039-18-000019:mdna:2]
[same as prior period, unchanged from 0001262039-17-000034:mdna:2]

[0001262039-18-000019:mdna:3]
[same as prior period, unchanged from 0001262039-17-000034:mdna:3]

[0001262039-18-000019:mdna:4]
[same as prior period, unchanged from 0001262039-17-000034:mdna:4]

[0001262039-18-000019:mdna:5]
[same as prior period, unchanged from 0001262039-17-000034:mdna:5]

[0001262039-18-000019:mdna:6]
[same as prior period, unchanged from 0001262039-17-000034:mdna:6]

[0001262039-18-000019:mdna:7]
[same as prior period, unchanged from 0001262039-17-000034:mdna:7]

[0001262039-18-000019:mdna:8]
| • | drivers of long-term growth and operating leverage, such as increased sales productivity, functionality and value in our standalone and bundled subscription service offerings; |

[0001262039-18-000019:mdna:9]
[same as prior period, unchanged from 0001262039-17-000034:mdna:9]

[0001262039-18-000019:mdna:10]
| • | trends in revenue, cost of revenue and gross margin; |

[0001262039-18-000019:mdna:11]
[same as prior period, unchanged from 0001262039-17-000034:mdna:11]

[0001262039-18-000019:mdna:12]
[same as prior period, unchanged from 0001262039-17-000034:mdna:12]

[0001262039-18-000019:mdna:13]
[same as prior period, unchanged from 0001262039-17-000034:mdna:13]

[0001262039-18-000019:mdna:14]
[same as prior period, unchanged from 0001262039-17-000034:mdna:14]

[0001262039-18-000019:mdna:15]
| • | the impact of the Tax Cuts and Jobs Act of 2017 (the “2017 Tax Act”); |

[0001262039-18-000019:mdna:16]
| • | expectations regarding spending related to real estate and other capital expenditures and to the impact on free cash flows; |

[0001262039-18-000019:mdna:17]
[same as prior period, unchanged from 0001262039-17-000034:mdna:16]

[0001262039-18-000019:mdna:18]
[same as prior period, unchanged from 0001262039-17-000034:mdna:17]

[0001262039-18-000019:mdna:19]
[same as prior period, unchanged from 0001262039-17-000034:mdna:18]

[0001262039-18-000019:mdna:20]
[same as prior period, unchanged from 0001262039-17-000034:mdna:19]

[0001262039-18-000019:mdna:21]
[same as prior period, unchanged from 0001262039-17-000034:mdna:26]

[0001262039-18-000019:mdna:22]
[same as prior period, unchanged from 0001262039-17-000034:mdna:21]

[0001262039-18-000019:mdna:23]
Fortinet is a global leader in broad, integrated and automated cybersecurity solutions to a wide variety of businesses, such as enterprises, data centers and distributed offices, including a majority of the Fortune 100 companies. Our cybersecurity solutions are designed to provide broad, automated and integrated protection against dynamic and sophisticated security threats, while simplifying the information technology and security infrastructure of our end-customers.

[0001262039-18-000019:mdna:24]
We have four current focus areas for our business. First, we derive a majority of product sales from our FortiGate network security appliances. We continue to develop and improve our offerings, which provide opportunities for market share gains. Second, the Fortinet Security Fabric has been developed to provide unified security across the entire digital attack surface, including network core, endpoints, applications, data centers, access and private and public cloud, and is designed to enable traditionally disparate security devices to work together as an integrated and collaborative whole. The Fortinet Security Fabric benefits from customers’ recognition of its value, performance and security coverage and is growing faster than network security. Third, cloud security provides opportunity for growth. We help customers secure their cloud implementations by offering integration, visibility and automation across multi-cloud and hybrid deployments. Our FortiCASB extends the core capabilities of our security fabric architecture to provide businesses the same level of cybersecurity and threat intelligence in cloud environments as they do on their physical networks. While cloud billings are still not significant as compared to the rest of our business, we experienced significant growth in both on-demand cloud consumption and bring-your-own-license (“BYOL”). The Fortinet cloud security is available across all major cloud providers, including Microsoft Azure, Amazon Web Services, Google Cloud, Oracle Cloud and IBM Cloud. Fourth, the emergence of the internet of things (“IoT”) is a new opportunity for us to grow our business and has created an environment where data move freely between devices across locations, network environments, remote offices, mobile workers and public cloud environments, making it difficult to consistently track and secure.

[0001262039-18-000019:mdna:25]
[same as prior period, unchanged from 0001262039-17-000034:mdna:28]

[0001262039-18-000019:mdna:26]
| • | We recorded total revenue of $399.0 million in the three months ended March 31, 2018, an increase of 17% compared to $340.6 million in the same period last year. Product revenue was $142.8 million in the three months ended March 31, 2018, an increase of 6% compared to $135.3 million in the same period last year. Service revenue was $256.2 million in the three months ended March 31, 2018, an increase of 25% compared to $205.3 million in the same period last year. |

[0001262039-18-000019:mdna:27]
| • | We generated operating income of $32.4 million in the three months ended March 31, 2018, an increase of 500% compared to $5.4 million in the same period last year. |

[0001262039-18-000019:mdna:28]
| • | Cash, cash equivalents and investments were $1.39 billion as of March 31, 2018, an increase of $37.1 million, or 3%, from December 31, 2017. |

[0001262039-18-000019:mdna:29]
| • | Deferred revenue was $1.40 billion as of March 31, 2018, an increase of $60.1 million, or 4%, from December 31, 2017. |

[0001262039-18-000019:mdna:30]
| • | We generated cash flows from operating activities of $139.7 million in the three months ended March 31, 2018, an increase of $10.0 million, or 8%, compared to the same period last year. |

[0001262039-18-000019:mdna:31]
| • | During the three months ended March 31, 2018, we repurchased 2.5 million shares of common stock under our Share Repurchase Program (“Repurchase Program”) for an aggregate purchase price of $115.5 million. |

[0001262039-18-000019:mdna:32]
During the three months ended March 31, 2018, our revenue growth was primarily driven by growth in service revenue due to the strength of our FortiCare technical support and FortiGuard security subscription revenue growing 35% and 20%, respectively, year-over-year.

[0001262039-18-000019:mdna:33]
The percentage of our FortiGate-related billings from entry-level products increased from 33% in the three months ended March 31, 2017 to 36% in the three months ended March 31, 2018. The percentage of our FortiGate-related billings from mid-range products was 31% during the three months ended March 31, 2018 and March 31, 2017. The percentage of our FortiGate-related billings from high-end products decreased to 33% in the three months ended March 31, 2018 from 36% in the same period last year. Billings related to non-FortiGate products also grew during the three months ended March 31, 2018, with higher than average growth in the Cloud and Fabric. On a geographic basis, revenue continues to be diversified globally, which remains a key strength of our business.

[0001262039-18-000019:mdna:34]
During the three months ended March 31, 2018, operating expenses as a percentage of revenue decreased by 4 percentage points compared to the same period last year. The decrease was primarily driven by a reduction in sales and marketing expenses as a percentage of revenue, as a result of the adoption of Topic 606 for deferred contract costs, which reduced our commissions expense in absolute dollars and as a percentage of total revenue. Our sales and marketing expenses included a benefit of $11.7 million from the adoption of Topic 606 related to deferred contract costs. Under Topic 606, we capitalized certain commissions on service contracts and amortize the amount over a certain period. Prior to the adoption of Topic 606, we expensed the commission related to these service contracts upfront. Excluding this benefit, sales and marketing expense as a percentage of revenue would have been comparable to the same period last year. Refer to Note 1 and Note 2 in our notes to the condensed consolidated financial statement for more information. Headcount increased by 4% to 5,275 employees and contractors as of March 31, 2018, up from 5,066 as of December 31, 2017.

[0001262039-18-000019:mdna:35]
[same as prior period, unchanged from 0001262039-17-000034:mdna:38]

[0001262039-18-000019:mdna:36]
Our sales strategy is based on a distribution model whereby we primarily sell our products, software licenses and services directly to distributors which sell to resellers and service providers, which, in turn, sell to our end-customers. In certain cases, we sell directly to large service providers and major systems integrators. We also offer our products across all major cloud providers, and have recognized on demand revenue and BYOL revenue from Amazon Web Services, Microsoft Azure, Google Cloud, Oracle Cloud and IBM Cloud. In a BYOL arrangement, a customer purchases a perpetual license from us and deploys the software in a cloud provider’s hardware. While the revenue from such sales are still relatively insignificant, they have increased significantly in recent periods on a percentage basis.

[0001262039-18-000019:mdna:37]
Typically, FortiGuard security subscription and FortiCare technical support services are purchased along with our hardware products and software licenses, most frequently as part of a bundle offering that includes hardware and services functionality. We generally invoice at the time of our sale for the total price of the products and security and technical support services. The invoice is payable within 30 to 90 days. We also invoice certain licenses and services on a monthly basis.

[0001262039-18-000019:mdna:38]
Our approach to network security is defined by our Security Processing Unit (“SPU”) hardware architecture. The SPU includes three lines of proprietary ASICs, content processor, network processor and the system on a chip. The ASICs are designed for highly efficient execution of computationally intensive tasks, including policy enforcement, threat detection and encryption. As such, ASIC-based solutions can run many security applications simultaneously without a significant reduction in performance.

[0001262039-18-000019:mdna:39]
[same as prior period, unchanged from 0001262039-17-000034:mdna:43]

[0001262039-18-000019:mdna:40]
We monitor a number of key metrics, including the key financial metrics set forth below, in order to help us evaluate growth trends, establish budgets, measure the effectiveness of our sales and marketing efforts, and assess operational efficiencies. The following table summarizes revenue, deferred revenue, billings (non-GAAP), cash, cash equivalents and investments, net cash provided by operating activities, and free cash flow (non-GAAP). We discuss revenue below under “Results of Operations,” and we discuss our cash, cash equivalents and investments, and net cash provided by operating activities below under “—Liquidity and Capital Resources.” Deferred revenue, billings (non-GAAP), and free cash flow (non-GAAP) are discussed immediately below the following table (in millions):

[0001262039-18-000019:mdna:41]
|  | Three Months Ended Or As Of |
|  | March 31, 2018 |  | March 31, 2017 |
| Revenue | $ | 399.0 |  |  | $ | 340.6 |  |
| Deferred revenue | $ | 1,396.4 |  |  | $ | 1,098.1 |  |
| Billings (non-GAAP) | $ | 463.2 |  |  | $ | 403.3 |  |
| Cash, cash equivalents and investments | $ | 1,386.4 |  |  | $ | 1,441.0 |  |
| Net cash provided by operating activities | $ | 139.7 |  |  | $ | 129.7 |  |
| Free cash flow (non-GAAP) | $ | 128.1 |  |  | $ | 116.2 |  |

[0001262039-18-000019:mdna:42]
Deferred revenue. Our deferred revenue consists of amounts that have been invoiced but that have not yet been recognized as revenue. The majority of our deferred revenue balance consists of the unrecognized portion of service revenue from FortiGuard security subscription and FortiCare technical support service contracts, which is recognized as revenue ratably over the contractual service period. We monitor our deferred revenue balance, growth and the mix of short-term and long-term deferred revenue because it represents a significant portion of revenue and free cash flow to be recognized in future periods. Deferred revenue was $1.40 billion as of March 31, 2018, an increase of $60.1 million, or 4%, from December 31, 2017. The adoption of Topic 606 did not have a material impact on the deferred revenue balance.

[0001262039-18-000019:mdna:43]
Billings (non-GAAP). We define billings as revenue recognized in accordance with generally accepted accounting principles in the United States (“GAAP”) plus the change in deferred revenue from the beginning to the end of the period and adjustments to the deferred revenue balance due to adoption of the new revenue recognition standard less any deferred revenue balances acquired from business combination(s) during the period. We consider billings to be a useful metric for management and investors because billings drive future revenue, which is an important indicator of the health and viability of our business. There are a number of limitations related to the use of billings instead of GAAP revenue. First, billings include amounts that have not yet been recognized as revenue and are impacted by the term of security and support agreements. Second, we may calculate billings in a manner that is different from peer companies that report similar financial measures. Management accounts for these limitations by providing specific information regarding GAAP revenue and evaluating billings together with GAAP revenue. Total billings were $463.2 million for March 31, 2018, an increase of 15% compared to $403.3 million in the same period last year.

[0001262039-18-000019:mdna:44]
A reconciliation of billings to revenue, the most directly comparable financial measure calculated and presented in accordance with GAAP, is provided below (in millions):

[0001262039-18-000019:mdna:45]
|  | Three Months Ended |
|  | March 31, 2018 |  | March 31, 2017 |
| Billings: |  |  |  |
| Revenue | $ | 399.0 |  |  | $ | 340.6 |  |
| Add: Change in deferred revenue | 60.1 |  |  | 62.7 |  |
| Deferred revenue adjustment due to adoption of the new revenue recognition standard | 4.1 |  |  | — |  |
| Total billings (non-GAAP) | $ | 463.2 |  |  | $ | 403.3 |  |

[0001262039-18-000019:mdna:46]
[same as prior period, unchanged from 0001262039-17-000034:mdna:53]

[0001262039-18-000019:mdna:47]
Free cash flow (non-GAAP). We define free cash flow as net cash provided by operating activities minus capital expenditures such as purchases of real estate and other property and equipment. We believe free cash flow to be a liquidity measure that provides useful information to management and investors about the amount of cash generated by the business that, after capital expenditures, can be used for strategic opportunities, including repurchasing outstanding common stock, investing in our business, making strategic acquisitions and strengthening the balance sheet. A limitation of using free cash flow rather than the GAAP measure of net cash provided by operating activities is that free cash flow does not represent the total increase or decrease in the cash, cash equivalents and investments balance for the period because it excludes cash provided by or used for other investing and financing activities. Management accounts for this limitation by providing information about our capital expenditures and other investing and financing activities on the face of the cash flow statement and under “—Liquidity and Capital Resources” and by presenting cash flows from investing and financing activities in our reconciliation of free cash flows. In addition, it is important to note that other companies, including companies in our industry, may not use free cash flow, may calculate free cash flow in a different manner than we do or may use other financial measures to evaluate their performance, all of which could reduce the usefulness of free cash flows as a comparative measure. A reconciliation of free cash flow to net cash provided by operating activities, the most directly comparable financial measure calculated and presented in accordance with GAAP, is provided below (in millions):

[0001262039-18-000019:mdna:48]
|  | Three Months Ended |
|  | March 31, 2018 |  | March 31, 2017 |
| Free Cash Flow: |  |  |  |
| Net cash provided by operating activities | $ | 139.7 |  |  | $ | 129.7 |  |
| Less purchases of property and equipment | (11.6 | ) |  | (13.5 | ) |
| Free cash flow (non-GAAP) | $ | 128.1 |  |  | $ | 116.2 |  |
| Net cash used in investing activities | $ | (25.5 | ) |  | $ | (31.3 | ) |
| Net cash provided by (used in) financing activities | $ | (89.6 | ) |  | $ | 15.8 |  |

[0001262039-18-000019:mdna:49]
[same as prior period, unchanged from 0001262039-17-000034:mdna:54]

[0001262039-18-000019:mdna:50]
[same as prior period, unchanged from 0001262039-17-000034:mdna:55]

[0001262039-18-000019:mdna:51]
We adopted Topic 606 on January 1, 2018 using the modified retrospective method. Refer to Note 2 in the notes to our condensed consolidated financial statements included in this Quarterly Report on Form 10-Q for a discussion of the impact. Other than the adoption of Topic 606, there were no material changes to our critical accounting policies and estimates as of and for the three months ended March 31, 2018, as compared to the critical accounting policies and estimates described in our Annual Report on Form 10-K filed with the SEC on February 26, 2018 (the “Form 10-K”).

[0001262039-18-000019:mdna:52]
[same as prior period, unchanged from 0001262039-17-000034:mdna:57]

[0001262039-18-000019:mdna:53]
[same as prior period, unchanged from 0001262039-17-000034:mdna:58]

[0001262039-18-000019:mdna:54]
[same as prior period, unchanged from 0001262039-17-000034:mdna:59]

[0001262039-18-000019:mdna:55]
Three Months Ended March 31, 2018 and March 31, 2017

[0001262039-18-000019:mdna:56]
[same as prior period, unchanged from 0001262039-17-000034:mdna:61]

[0001262039-18-000019:mdna:57]
|  | Three Months Ended |  |  |  |  |
| March 31, 2018 (1) |  | March 31, 2017 |  |  |  |  |
| Amount |  | % ofRevenue |  | Amount |  | % ofRevenue |  | Change |  | % Change |
| (in millions, except percentages) |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 142.8 |  |  | 36 | % |  | $ | 135.3 |  |  | 40 | % |  | $ | 7.5 |  |  | 6 | % |
| Service | 256.2 |  |  | 64 |  |  | 205.3 |  |  | 60 |  |  | 50.9 |  |  | 25 |  |
| Total revenue | $ | 399.0 |  |  | 100 | % |  | $ | 340.6 |  |  | 100 | % |  | $ | 58.4 |  |  | 17 | % |
| Revenue by geography: |  |  |  |  |  |  |  |  |  |  |  |
| Americas | $ | 175.8 |  |  | 44 | % |  | $ | 146.4 |  |  | 43 | % |  | $ | 29.4 |  |  | 20 | % |
| Europe, Middle East and Africa (“EMEA”) | 144.5 |  |  | 36 |  |  | 126.1 |  |  | 37 |  |  | 18.4 |  |  | 15 |  |
| Asia Pacific (“APAC”) | 78.7 |  |  | 20 |  |  | 68.1 |  |  | 20 |  |  | 10.6 |  |  | 16 |  |
| Total revenue | $ | 399.0 |  |  | 100 | % |  | $ | 340.6 |  |  | 100 | % |  | $ | 58.4 |  |  | 17 | % |

[0001262039-18-000019:mdna:58]
(1) Revenue during the three months ended March 31, 2018 under Topic 606 (As Reported) and 605 (Balances Without Adoption of Topic 606) were as follows (in millions):

[0001262039-18-000019:mdna:59]
|  | As Reported |  | Balances Without Adoption of Topic 606 |  | Effect of ChangeIncrease (Decrease) |
| Revenue: |  |  |  |  |  |
| Product | $ | 142.8 |  |  | $ | 137.1 |  |  | $ | 5.7 |  |
| Service | 256.2 |  |  | 255.5 |  |  | 0.7 |  |
| Total revenue | $ | 399.0 |  |  | $ | 392.6 |  |  | $ | 6.4 |  |
| Revenue by geography: |  |  |  |  |  |
| Americas | $ | 175.8 |  |  | $ | 169.1 |  |  | $ | 6.7 |  |
| EMEA | 144.5 |  |  | 143.9 |  |  | 0.6 |  |
| APAC | 78.7 |  |  | 79.6 |  |  | (0.9 | ) |
| Total revenue | $ | 399.0 |  |  | $ | 392.6 |  |  | $ | 6.4 |  |

[0001262039-18-000019:mdna:60]
Total revenue increased by $58.4 million, or 17%, during the three months ended March 31, 2018 compared to the same period last year. We continued to experience diversification of revenue globally. Revenue from all our regions grew, with the Americas contributing the largest portion of our revenue growth both on an absolute dollar and on a percentage basis. Product revenue increased by $7.5 million, or 6%, during the three months ended March 31, 2018 compared to the same period last year. Product revenue in the first quarter of 2018 included a $5.7 million benefit from the adoption of Topic 606, which primarily relates to sell through of our U.S. channel inventory. FortiGate unit shipments increased year-over-year. Sales of non-FortiGate products, such as the Fortinet Security Fabric and cloud products, also grew significantly. Service revenue increased by $50.9 million, or 25%, during the three months ended March 31, 2018 compared to the same period last year. The increase in service revenue was primarily due to the recognition of revenue from our growing deferred revenue balance consisting of FortiGuard security subscription and FortiCare technical support contracts sold to a larger customer base, as well as the renewals of similar contracts sold in earlier periods. The impact of the adoption of Topic 606 on service revenue is not significant.

[0001262039-18-000019:mdna:61]
[same as prior period, unchanged from 0001262039-17-000034:mdna:66]

[0001262039-18-000019:mdna:62]
[same as prior period, unchanged from 0001262039-17-000034:mdna:64]

[0001262039-18-000019:mdna:63]
|  | Three Months Ended |  |  |  |  |
| March 31, 2018 (1) |  | March 31, 2017 |  | Change |  | % Change |
| (in millions, except percentages) |
| Cost of revenue: |  |  |  |  |  |  |  |
| Product | $ | 58.2 |  |  | $ | 55.3 |  |  | $ | 2.9 |  |  | 5 | % |
| Service | 39.0 |  |  | 35.3 |  |  | 3.7 |  |  | 11 |  |
| Total cost of revenue | $ | 97.2 |  |  | $ | 90.6 |  |  | $ | 6.6 |  |  | 7 | % |
| Gross margin (%): |  |  |  |  |  |  |  |
| Product | 59.2 | % |  | 59.1 | % |  | 0.1 | % |  |  |
| Service | 84.8 |  |  | 82.8 |  |  | 2.0 |  |  |  |
| Total gross margin | 75.6 | % |  | 73.4 | % |  | 2.2 | % |  |  |

[0001262039-18-000019:mdna:64]
(1) Cost of revenue and gross margin during the three months ended March 31, 2018 under Topic 606 (As Reported) and 605 (Balances Without Adoption of Topic 606) were as follows (in millions):

[0001262039-18-000019:mdna:65]
|  | As Reported |  | Balances Without Adoption of Topic 606 |  | Effect of ChangeIncrease (Decrease) |
| Cost of revenue: |  |  |  |  |  |
| Product | $ | 58.2 |  |  | $ | 56.7 |  |  | $ | 1.5 |  |
| Service | 39.0 |  |  | 39.0 |  |  | — |  |
| Total cost of revenue | $ | 97.2 |  |  | $ | 95.7 |  |  | $ | 1.5 |  |
| Gross margin (%): |  |  |  |  |  |
| Product | 59.2 | % |  | 58.6 | % |  | 0.6 | % |
| Service | 84.8 |  |  | 84.7 | % |  | 0.1 | % |
| Total gross margin | 75.6 | % |  | 75.6 | % |  | — | % |

[0001262039-18-000019:mdna:66]
Total gross margin increased by 2.2 percentage points during the three months ended March 31, 2018 compared to the same period last year, driven by higher margin on service revenue. Service gross margin increased by 2.0 percentage points during the three months ended March 31, 2018 as compared to the same period last year due to the strength of our FortiCare technical support and FortiGuard security subscription revenue growing 35% and 20%, respectively, during the three months ended March 31, 2018 compared to the same period last year. Product gross margin increased by 0.1 percentage point during the three months ended March 31, 2018 compared to the same period last year. Total cost of product revenue was comprised primarily of direct and indirect cost of products sold, inventory reserves and other charges. Cost of service revenue was comprised primarily of personnel costs. The impact of Topic 606 on our gross margin is not significant.

[0001262039-18-000019:mdna:67]
[same as prior period, unchanged from 0001262039-17-000034:mdna:68]

[0001262039-18-000019:mdna:68]
|  | Three Months Ended |  | Change |  | % Change |
| March 31, 2018 (1) |  | March 31, 2017 |  |
| Amount |  | % ofRevenue |  | Amount |  | % ofRevenue |  |
| (in millions, except percentages) |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | $ | 59.1 |  |  | 15% |  | $ | 51.2 |  |  | 15 | % |  | $ | 7.9 |  |  | 15 | % |
| Sales and marketing | 185.3 |  |  | 46 |  | 170.4 |  |  | 50 |  |  | 14.9 |  |  | 9 |  |
| General and administrative | 25.0 |  |  | 6 |  | 22.6 |  |  | 7 |  |  | 2.4 |  |  | 11 |  |
| Restructuring charges | — |  |  | — |  | 0.4 |  |  | — |  |  | (0.4 | ) |  | (100 | ) |
| Total operating expenses | $ | 269.4 |  |  | 68% |  | $ | 244.6 |  |  | 72 | % |  | $ | 24.8 |  |  | 10 | % |

[0001262039-18-000019:mdna:69]
(1) Operating expenses during the three months ended March 31, 2018 under Topic 606 (As Reported) and 605 (Balances Without Adoption of Topic 606) were as follows (in millions):

[0001262039-18-000019:mdna:70]
|  | As Reported |  | Balances Without Adoption of Topic 606 |  | Effect of ChangeIncrease (Decrease) |
| Operating expenses: |  |  |  |  |  |
| Research and development | $ | 59.1 |  |  | $ | 59.1 |  |  | $ | — |  |
| Sales and marketing expenses | 185.3 |  |  | 197.0 |  |  | (11.7 | ) |
| General and administrative | 25.0 |  |  | 25.0 |  |  | — |  |
| Total operating expenses | $ | 269.4 |  |  | $ | 281.1 |  |  | $ | (11.7 | ) |

[0001262039-18-000019:mdna:71]
[same as prior period, unchanged from 0001262039-17-000034:mdna:70]

[0001262039-18-000019:mdna:72]
Research and development expense increased by $7.9 million, or 15%, during the three months ended March 31, 2018 compared to the same period last year, primarily due to an increase of $7.1 million in personnel-related costs as a result of increased headcount to support the development of new products and continued enhancements of our existing products. In addition, depreciation and other occupancy-related costs increased by $0.9 million. We intend to continue to invest in our research and development organization, and expect research and development expense to increase in absolute dollars in 2018.

[0001262039-18-000019:mdna:73]
[same as prior period, unchanged from 0001262039-17-000034:mdna:72]

[0001262039-18-000019:mdna:74]
Sales and marketing expense increased by $14.9 million, or 9%, during the three months ended March 31, 2018 compared to the same period last year, primarily due to an increase of $12.0 million in personnel-related costs as sales and marketing headcount increased in order to drive market share gains globally. These increases in personnel costs included a benefit of $11.7 million from the adoption of the new accounting standard related to deferred contract costs. Under this new standard, we capitalized certain commissions on service contracts and amortize the amount over a certain period. Prior to the adoption of this new standard, we expensed the commission related to these service contracts. Our sales and marketing expense would have increased by $26.6 million or 16% under the old accounting standard. Refer to Note 2 in our notes to the condensed consolidated financial statement for more information. Travel and entertainment expense increased by $2.2 million. In addition, depreciation expense and other occupancy-related expense increased by $1.3 million. As a percentage of total revenue, sales and marketing expense decreased primarily due to the benefit from the new accounting standard on deferred contract costs. Excluding this benefit, sales and marketing expense as a percentage of revenue would have been 49% of revenue. We intend to continue to make investments in our sales resources and infrastructure and marketing strategy, which are critical to support growth, and expect sales and marketing expense to increase in absolute dollars in 2018.

[0001262039-18-000019:mdna:75]
[same as prior period, unchanged from 0001262039-17-000034:mdna:74]

[0001262039-18-000019:mdna:76]
General and administrative expense increased by $2.4 million, or 11%, during the three months ended March 31, 2018 compared to the same period last year. Personnel costs increased by $3.5 million as we continued to increase headcount in order to support our expanding business. Professional fees increased by $0.9 million, primarily due to the implementation of a new revenue recognition system to support the new accounting rules. The increase in expense was partially offset by a decrease in depreciation and other occupancy-related costs of $1.5 million. We expect general and administrative expense to increase in absolute dollars in 2018.

[0001262039-18-000019:mdna:77]
Operating income

[0001262039-18-000019:mdna:78]
We generated operating income of $32.4 million during the three months ended March 31, 2018, an increase of $27.0 million, or 500%, compared to $5.4 million in the same period last year. The improvement in operating income generated was primarily due to the benefit from the adoption of the new accounting standard. As a percentage of total revenue, sales and marketing expenses decreased to 46% in the three months ended March 31, 2018 from 50% in the same period last year. Excluding the benefit from the adoption of Topic 606, sales and marketing expense as a percentage of revenue would have been 49% of revenue. The adoption of this new standard resulted in an improvement of 4.1 percentage points in our operating margin.

[0001262039-18-000019:mdna:79]
[same as prior period, unchanged from 0001262039-17-000034:mdna:78]

[0001262039-18-000019:mdna:80]
|  | Three Months Ended |  |  |  |  |
| March 31, 2018 |  | March 31, 2017 |  | Change |  | % Change |
| (in millions, except percentages) |
| Interest income | $ | 4.5 |  |  | $ | 2.4 |  |  | $ | 2.1 |  |  | 88 | % |
| Other income (expense)—net | (0.2 | ) |  | 0.3 |  |  | (0.5 | ) |  | (167 | ) |

[0001262039-18-000019:mdna:81]
Interest income increased during the three months ended March 31, 2018 as compared to the same period last year, primarily due to higher interest rates and higher invested balances of cash, cash equivalents and investments. Interest income varies depending on our average investment balances during the period, types and mix of investments, and market interest rates. The change in other income (expense)—net during the three months ended March 31, 2018 as compared to the same period last year was primarily due to higher foreign currency exchange losses.

[0001262039-18-000019:mdna:82]
Benefit from income taxes

[0001262039-18-000019:mdna:83]
|  | Three Months Ended |  | Change |  | % Change |
| March 31, 2018 (1) |  | March 31, 2017 |  |
| (in millions, except percentages) |
| Benefit from income taxes | $ | (4.9 | ) |  | $ | (2.6 | ) |  | $ | (2.3 | ) |  | 88 | % |
| Effective tax rate (%) | (13 | )% |  | (32 | )% |  | 19 | % |  | — |  |

[0001262039-18-000019:mdna:84]
(1) Benefit from income taxes during the three months ended March 31, 2018 under Topic 606 (As Reported) and 605 (Balances Without Adoption of Topic 606) were as follows (in millions):

[0001262039-18-000019:mdna:85]
|  | As Reported |  | Balances Without Adoption of Topic 606 |  | Increase (Decrease) |
| Benefit from income taxes | $ | (4.9 | ) |  | $ | (8.7 | ) |  | $ | 3.8 |  |
| Effective tax rate (%) | (13 | )% |  | (43 | )% |  | 30 | % |

[0001262039-18-000019:mdna:86]
Our effective tax rate was a tax benefit of 13% for the three months ended March 31, 2018 compared to a tax benefit of 32% for the same period last year, with the primary difference being the change in the federal tax rate to 21% in 2018 from 35% in the prior year. The effective tax rate for the periods presented are comprised of the U.S. federal and state taxes, withholding taxes, and foreign taxes of $8.5 million, which are offset by a tax provision benefit of $5.6 million for stock-based compensation and release of reserve on uncertain tax position including interests of $7.8 million. The tax rate for the three months ended March 31, 2017 was comprised of the U.S. federal and state taxes, withholding taxes and foreign taxes of $2.9 million which were offset by a tax provision benefit of $5.5 million for stock-based compensation.

[0001262039-18-000019:mdna:87]
In December 2017, the U.S. federal government enacted the 2017 Tax Act. The 2017 Tax Act reduced the federal corporate income tax rate from 35% to 21% effective January 1, 2018 and created a territorial tax system with a one-time mandatory tax on foreign earnings of U.S. subsidiaries not previously subject to U.S. income tax. Under GAAP, changes in tax rates and tax law are accounted for in the period of enactment and deferred tax assets and liabilities are measured at the enacted tax rate.

[0001262039-18-000019:mdna:88]
The SEC staff has issued Staff Accounting Bulletin No. 118 (“SAB 118”), which provides guidance on accounting for the tax effects of the 2017 Tax Act. SAB 118 provides a measurement period that should not extend beyond one year from the 2017 Tax Act enactment date for companies to complete the accounting under ASC 740. In accordance with SAB 118, a company must reflect the income tax effects of those aspects of the 2017 Tax Act for which the accounting under ASC 740 is complete. To the extent that a company’s accounting for certain income tax effects of the 2017 Tax Act is incomplete but it is able to determine a reasonable estimate, it must record a provisional estimate in the financial statements. If a company cannot determine a provisional estimate to be included in the financial statements, it should continue to apply ASC 740 on the basis of

[0001262039-18-000019:mdna:89]
the provisions of the tax laws that were in effect immediately before the enactment of the 2017 Tax Act. At this time, our income tax reporting for these effects is provisional using reasonable estimates.

[0001262039-18-000019:mdna:90]
The 2017 Tax Act creates a new requirement that global intangible low-taxed income (“GILTI”) earned by controlled foreign corporations (“CFCs”) be included currently in the gross income of the CFCs’ U.S. shareholder. Because of the complexity of the new GILTI tax rules, we are continuing to evaluate this provision of the 2017 Tax Act and the application of ASC 740. Under U.S. GAAP, we are allowed to make an accounting policy choice of either (1) treating taxes due on U.S. inclusions in taxable income related to GILTI as a current-period expense when incurred (the “period cost method”) or (2) factoring such amounts into a company’s measurement of its deferred taxes. Our selection of an accounting policy for the first quarter of 2018 with respect to the GILTI tax rules was to treat GILTI tax as a current-period expense under the period cost method.

[0001262039-18-000019:mdna:91]
The IRS issued Notice 2018-26 on April 2, 2018, which included allowing a deduction for foreign taxes during 2017 to be allocated to earning and profits calculated as of November 2, 2017. This deduction resulted in a decrease of our transition tax by $3.2 million. We also released unrecognized tax benefits in the first quarter of 2018, which had previously reduced our transition tax. This increased our transition tax by $2.7 million. The net tax provision benefit due to changes in the transition tax calculation was $0.5 million in the first quarter of 2018.

[0001262039-18-000019:mdna:92]
It is our policy is to include accrued interest and penalties related to uncertain tax benefits in income tax expense. As of March 31, 2018 and December 31, 2017, accrued interest and penalties were $13.4 million and $13.5 million, respectively. It is reasonably possible that our gross unrecognized tax benefits will decrease by up to $7.0 million in the next 12 months, primarily due to the lapse of the statute of limitations and audit settlement. These adjustments, if recognized, would positively impact our effective tax rate, and would be recognized as additional tax benefits.

[0001262039-18-000019:mdna:93]
34

[0001262039-18-000019:mdna:94]
[same as prior period, unchanged from 0001262039-17-000034:mdna:111]

[0001262039-18-000019:mdna:95]
|  | As of |
|  | March 31, 2018 |  | December 31, 2017 |
|  | (in millions) |
| Cash and cash equivalents | $ | 835.6 |  |  | $ | 811.0 |  |
| Investments | 550.8 |  |  | 538.3 |  |
| Total cash, cash equivalents and investments | $ | 1,386.4 |  |  | $ | 1,349.3 |  |
| Working capital | $ | 706.1 |  |  | $ | 689.6 |  |
|  | Three Months Ended |
|  | March 31, 2018 |  | March 31, 2017 |
|  | (in millions) |
| Cash provided by operating activities | $ | 139.7 |  |  | $ | 129.7 |  |
| Cash used in investing activities | (25.5 | ) |  | (31.3 | ) |
| Cash provided by (used in) financing activities | (89.6 | ) |  | 15.8 |  |
| Net increase in cash and cash equivalents | $ | 24.6 |  |  | $ | 114.2 |  |

[0001262039-18-000019:mdna:96]
Liquidity and capital resources may be impacted by our operating activities, as well as by our stock repurchases, real estate and other capital expenditures, proceeds associated with stock option exercises and issuances of common stock under our ESPP, payment of taxes in connection with the net settlement of equity awards and business acquisitions. In recent years, we have received significant capital resources as a result of increases in our deferred revenue and the proceeds from exercise of stock options and purchases under our ESPP. Additional increases in deferred revenue may depend on a number of factors including our billing growth rate, service contract renewal rates and length of initial and renewals service contracts. We expect proceeds from the issuance of stock options in future years to be impacted by the increased mix of restricted stock units granted versus stock options and also to vary based on our share price. As of March 31, 2018, $327.3 million remained available for future share repurchase under the Repurchase Program.

[0001262039-18-000019:mdna:97]
Construction on the new headquarters building is expected to start in the second half of 2018. We estimate 2018 spending for this project to be approximately $20 million to $30 million.

[0001262039-18-000019:mdna:98]
As of March 31, 2018, our cash, cash equivalents and investments of $1.39 billion were invested primarily in corporate debt securities, money market funds, certificate of deposits, commercial paper and U.S. government and agency securities. It is our investment policy to invest excess cash in a manner that preserves capital, provides liquidity and maximizes return without significantly increasing risk.

[0001262039-18-000019:mdna:99]
As of March 31, 2018, $807.7 million of our cash and investments were held by our international subsidiaries. Under the 2017 Tax Act signed into law in December 2017, starting on January 1, 2018, we are no longer subject to federal income tax on earnings remitted from our foreign subsidiaries. We have analyzed our global working capital and cash requirements and the potential tax liabilities attributable to repatriation, and have determined that we will be repatriating certain unremitted foreign earnings which were previously deemed indefinitely reinvested. We expect to be able to repatriate an additional $150.0 million over the remainder of 2018. For those investments from which we were able to make a reasonable estimate of the tax effects of such repatriation, we have recorded a provisional estimate for withholding and state taxes. Most of our off-shore cash is located in Singapore. Corporate law in Singapore only allows dividends to be paid to the extent we have retained earnings in Singapore. In Singapore our retained earnings are lower than our current cash balance. We do not enter into investments for trading or speculative purposes. We believe that our existing cash and cash equivalents will be sufficient to meet our anticipated cash needs for at least the next 12 months. Our future capital requirements will depend on many factors, including our growth rate, the timing and amount of our planned share repurchases, the timing and extent of spending to support development efforts, the expansion of sales and marketing activities, the introduction of new and enhanced products and services offerings, the costs to ensure access to adequate manufacturing capacity, the continuing market acceptance of our products and our investments in real estate through purchases or long-term leases. Historically, we have required capital principally to fund our working capital needs, share repurchases, capital expenditures, and acquisition activities. In the event that additional financing is required from outside sources, we may not be able to raise it on terms acceptable to us or at all.

[0001262039-18-000019:mdna:100]
[same as prior period, unchanged from 0001262039-17-000034:mdna:118]

[0001262039-18-000019:mdna:101]
Cash generated by operating activities is our primary source of liquidity. It is primarily comprised of net income, as adjusted for non-cash items, and changes in operating assets and liabilities, including deferred revenue. Non-cash adjustments consist primarily of stock-based compensation, amortization of deferred contract costs in connection with the adoption of Topic 606, depreciation of property and equipment, amortization of intangible assets and amortization of investment premiums.

[0001262039-18-000019:mdna:102]
Our operating activities during the three months ended March 31, 2018 provided $139.7 million in cash as a result of our continued growth of our business and our ability to successfully manage our working capital. Changes in operating assets and liabilities primarily resulted from an increase in sales of our FortiGuard security subscription and FortiCare technical support services to new and existing customers, as reflected by an increase in our deferred revenue, which was partially offset by an increase in accounts receivable. Our total deferred revenue balance grew 27% during the three months ended March 31, 2018 compared to the same period last year.

[0001262039-18-000019:mdna:103]
Our operating activities during the three months ended March 31, 2017 provided $129.7 million in cash as a result of our continued growth in the sales of FortiGuard security subscriptions and FortiCare support contracts, as well as product sales, and the ability to successfully manage our working capital. The increase in sales of our FortiGuard security subscription and FortiCare technical supports to new and existing customers was reflected in the increase in our deferred revenue. Our total deferred revenue balance grew 31% during the three months ended March 31, 2017 compared to the same period last year.

[0001262039-18-000019:mdna:104]
[same as prior period, unchanged from 0001262039-17-000034:mdna:122]

[0001262039-18-000019:mdna:105]
The changes in cash flows from investing activities primarily relate to timing of purchases, maturities and sales of investments and purchases of property and equipment. Historically, in making a lease versus purchase decision related to our larger facilities, we have considered various factors including financial metrics and the impact on our employees. In certain cases, we have elected to purchase the facility if we believe that purchasing rather than leasing is more in line with our long-term strategy. We expect to make similar decisions in the future.

[0001262039-18-000019:mdna:106]
During the three months ended March 31, 2018, cash used for investing activities was primarily due to the $11.6 million we spent on capital expenditures and $13.9 million due to purchases of investments, net of maturities, of our investments.

[0001262039-18-000019:mdna:107]
During the three months ended March 31, 2017, cash used for investing activities was primarily due to the $13.5 million we spent on capital expenditures and $17.8 million due to purchases, net of maturities, of our investments.

[0001262039-18-000019:mdna:108]
[same as prior period, unchanged from 0001262039-17-000034:mdna:126]

[0001262039-18-000019:mdna:109]
The changes in cash flows from financing activities primarily relate to proceeds from the issuance of common stock under our equity incentive plan and the ESPP, taxes paid related to net share settlement of equity awards and repurchase and retirement of common stock.

[0001262039-18-000019:mdna:110]
During the three months ended March 31, 2018, cash used for financing activities was $89.6 million, primarily due to $115.5 million used to repurchase our common stock. This was partially offset by $25.9 million of proceeds from the issuance of common stock, net of tax withholding.

[0001262039-18-000019:mdna:111]
During the three months ended March 31, 2017, cash provided by financing activities was $15.8 million, representing proceeds from the issuance of common stock, net of tax withholding.

[0001262039-18-000019:mdna:112]
[same as prior period, unchanged from 0001262039-17-000034:mdna:130]

[0001262039-18-000019:mdna:113]
There were no material changes outside the ordinary course of business during the three months ended March 31, 2018 to the contractual obligations and commitments disclosed in Management’s Discussion and Analysis of Financial Condition and Results of Operations, set forth in Part II, Item 7, of the Form 10-K. See Note 9 to the notes to the condensed consolidated financial statements included in Part I, Item 1 of this Quarterly Report on Form 10-Q for additional information regarding contractual obligations and commitments.

[0001262039-18-000019:mdna:114]
36

[0001262039-18-000019:mdna:115]
[same as prior period, unchanged from 0001262039-17-000034:mdna:133]

[0001262039-18-000019:mdna:116]
As of March 31, 2018, we did not have any relationships with unconsolidated organizations or financial partnerships, such as structured finance or special purpose entities that would have been established for the purpose of facilitating off-balance sheet arrangements or other contractually narrow or limited purposes.
