# FTNT note change history — 0001262039-24-000037 → 0001262039-24-000043


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2024-11-08):
[0001262039-24-000043:note_history:1]
COMMITMENTS AND CONTINGENCIES
The following table summarizes our inventory purchase commitments as of September 30, 2024 (in millions):
  (was, 2024-08-08, similarity 0.9569):
[0001262039-24-000037:note_history:1]
COMMITMENTS AND CONTINGENCIES
The following table summarizes our inventory purchase commitments as of June 30, 2024 (in millions):

- added (2024-11-08):
[0001262039-24-000043:note_history:2]
As of September 30, 2024, we had $550.0 million of non-cancelable inventory purchase commitments with our independent contract manufacturers. We recorded a liability for these purchase commitments for quantities in excess of our future estimated demand forecasts, consistent with the valuation of our excess and obsolete inventory. As of September 30, 2024 and December 31, 2023, the liability for these inventory purchase commitments was $76.3 million and $84.7 million, respectively, and was recorded in accrued liabilities on our condensed consolidated balance sheets. The cost of product revenue related to such liabilities was a $27.4 million benefit and a $36.9 million cost during the three months ended September 30, 2024 and 2023, respectively. The cost of product revenue related to such accrued liability for inventory purchase commitments was $11.2 million and $59.3 million during the nine months ended September 30, 2024 and 2023, respectively.

- changed (2024-11-08):
[0001262039-24-000043:note_history:3]
Other Contractual Commitments and Open Purchase Orders—In addition to commitments with contract manufacturers, we have open purchase orders and contractual obligations in the ordinary course of business for which we have not received goods or services. A significant portion of our reported purchase commitments consist of non-cancelable commitments. In certain instances, contractual commitments allow us the option to cancel, reschedule and adjust our requirements based on our business needs prior to firm orders being placed. As of September 30, 2024, we had $116.5 million in other contractual commitments having a remaining term in excess of one year that are non-cancelable.
  (was, 2024-08-08, similarity 0.9903):
[0001262039-24-000037:note_history:3]
Other Contractual Commitments and Open Purchase Orders—In addition to commitments with contract manufacturers, we have open purchase orders and contractual obligations in the ordinary course of business for which we have not received goods or services. A significant portion of our reported purchase commitments consist of non-cancelable commitments. In certain instances, contractual commitments allow us the option to cancel, reschedule and adjust our requirements based on our business needs prior to firm orders being placed. As of June 30, 2024, we had $40.4 million in other contractual commitments having a remaining term in excess of one year that are non-cancelable.

- changed (2024-11-08):
[0001262039-24-000043:note_history:4]
As of September 30, 2024, we had $83.1 million in contractual commitments related to payments for operating leases.
  (was, 2024-08-08, similarity 0.9469):
[0001262039-24-000037:note_history:4]
As of June 30, 2024, we had $82.9 million in contractual commitments related to payments for operating leases.

- changed (2024-11-08):
[0001262039-24-000043:note_history:5]
Litigation—We are involved in disputes, litigation, and other legal actions. For lawsuits where we are the defendant, we are in the process of defending these litigation matters, and while there can be no assurances and the outcome of certain of these matters is currently not determinable and not predictable, we currently are unaware of any existing claims or proceedings that we believe are likely to have a material adverse effect on our financial position. There are many uncertainties associated with any litigation and these actions or other third-party claims against us may cause us to incur costly litigation fees, costs and substantial settlement charges, and possibly subject us to damages and other penalties. In addition, the resolution of any intellectual property (“IP”) litigation may require us to make royalty payments, which could adversely affect our gross margins in future periods. If any of those events were to occur, our business, financial condition, results of operations, and cash flows could be adversely affected. Litigation is unpredictable and the actual liability in any such matters may be materially different from our current estimates, which could result in the need to adjust any accrued liability and record additional expenses. We accrue for contingencies when we believe that a loss is probable and that we can reasonably estimate the amount of any such loss. These accruals are generally based on a range of possible outcomes that require significant management judgement. If no amount within a range is a better estimate than any other, we accrue the minimum amount. Litigation loss contingency accruals associated with outstanding cases were not material as of September 30, 2024, and December 31, 2023.
  (was, 2024-08-08, similarity 0.9963):
[0001262039-24-000037:note_history:5]
Litigation—We are involved in disputes, litigation, and other legal actions. For lawsuits where we are the defendant, we are in the process of defending these litigation matters, and while there can be no assurances and the outcome of certain of these matters is currently not determinable and not predictable, we currently are unaware of any existing claims or proceedings that we believe are likely to have a material adverse effect on our financial position. There are many uncertainties associated with any litigation and these actions or other third-party claims against us may cause us to incur costly litigation fees, costs and substantial settlement charges, and possibly subject us to damages and other penalties. In addition, the resolution of any intellectual property (“IP”) litigation may require us to make royalty payments, which could adversely affect our gross margins in future periods. If any of those events were to occur, our business, financial condition, results of operations, and cash flows could be adversely affected. Litigation is unpredictable and the actual liability in any such matters may be materially different from our current estimates, which could result in the need to adjust any accrued liability and record additional expenses. We accrue for contingencies when we believe that a loss is probable and that we can reasonably estimate the amount of any such loss. These accruals are generally based on a range of possible outcomes that require significant management judgement. If no amount within a range is a better estimate than any other, we accrue the minimum amount. Litigation loss contingency accruals associated with outstanding cases were not material as of June 30, 2024, and December 31, 2023.

- added (2024-11-08):
[0001262039-24-000043:note_history:6]
On March 21, 2019, we were sued by Alorica Inc. (“Alorica”) in Santa Clara County Superior Court in California. Alorica alleged breach of warranty and misrepresentation claims, which we denied. After trial, a jury returned a verdict fully in favor of us and against Alorica on October 4, 2024. The time for Alorica to appeal the verdict has not yet expired. We believe that the ultimate outcome of this matter will not materially impact our financial position, results of operations or cash flows. However, if Alorica appeals, any legal proceedings would be subject to inherent uncertainties, and a future unfavorable ruling could occur. No loss accrual had been recorded as of September 30, 2024 or December 31, 2023 related to this litigation.

- added (2024-11-08):
[0001262039-24-000043:note_history:7]
Indemnification and Other Matters—We enter into indemnification provisions in the ordinary course of business with other companies such as partners, customers, and vendors, where we agree to indemnify, hold harmless, and reimburse the

- changed (2024-11-08):
[0001262039-24-000043:note_history:8]
indemnified party for certain losses suffered or incurred by the indemnified party as a result of our activities, including defending against third-party claims asserting various allegations such as product defects, breach of representations or covenants, and infringement of certain IP rights, which may include patents, copyrights, trademarks or trade secrets, and to pay judgments entered on such claims. In some contracts, our exposure under these indemnification provisions is limited by the terms of the contracts to certain defined limits, such as the total amount paid by our customer under the agreement. However, certain agreements include covenants, penalties and indemnification provisions including and beyond indemnification for third-party claims of IP infringement that could potentially expose us to losses in excess of the amount received under the agreement, and in some instances to potential liability that is not contractually limited. Although from time to time there are indemnification claims asserted against us and currently there are pending indemnification claims, to date there have been no material awards under such indemnification provisions.
  (was, 2024-08-08, similarity 0.8356):
[0001262039-24-000037:note_history:8]
Indemnification and Other Matters—We enter into indemnification provisions in the ordinary course of business with other companies such as partners, customers, and vendors, where we agree to indemnify, hold harmless, and reimburse the indemnified party for certain losses suffered or incurred by the indemnified party as a result of our activities, including defending against third-party claims asserting various allegations such as product defects, breach of representations or covenants, and infringement of certain IP rights, which may include patents, copyrights, trademarks or trade secrets, and to pay judgments entered on such claims. In some contracts, our exposure under these indemnification provisions is limited by the terms of the contracts to certain defined limits, such as the total amount paid by our customer under the agreement. However, certain agreements include covenants, penalties and indemnification provisions including and beyond indemnification for third-party claims of IP infringement that could potentially expose us to losses in excess of the amount received under the agreement, and in some instances to potential liability that is not contractually limited. Although from time to time there are indemnification claims asserted against us and currently there are pending indemnification claims, to date there have been no material awards under such indemnification provisions.

- added (2024-11-08):
[0001262039-24-000043:note_history:9]
Periodically we, like other security companies and companies in other industries, have experienced, and may experience in the future, cybersecurity threats, malicious activity directed against our information technology infrastructure and unauthorized attempts to gain access to our and our customers’ sensitive information and systems. For example, in the third quarter of 2024, we discovered that an individual gained unauthorized access to a limited number of files stored on Fortinet’s instance of a third-party cloud-based shared file drive, which included limited data related to a small number of Fortinet customers. We have completed our investigation of this incident and we do not currently believe that it had a material impact on our business or that of any of our customers. We are currently not aware of any significant claims arising from this matter.

- removed (2024-11-08):
[0001262039-24-000037:note_history:10]
As of June 30, 2024, we had $566.7 million of non-cancelable inventory purchase commitments with our independent contract manufacturers. We recorded a liability for these purchase commitments for quantities in excess of our future estimated demand forecasts, consistent with the valuation of our excess and obsolete inventory. As of June 30, 2024 and December 31, 2023, the liability for these inventory purchase commitments was $105.2 million and $84.7 million, respectively, and was recorded in accrued liabilities on our condensed consolidated balance sheets. The expense related to such accrued liability for inventory purchase commitments was $7.0 million and $12.0 million during the three months ended June 30, 2024 and 2023, respectively, and was recorded in cost of product revenue on the condensed consolidated statements of income. The expense related to such accrued liability for inventory purchase commitments was $38.6 million and $22.4 million during the six months ended June 30, 2024 and 2023, respectively, and was recorded in cost of product revenue on the condensed consolidated statements of income.

- removed (2024-11-08):
[0001262039-24-000037:note_history:11]
On March 21, 2019, we were sued by Alorica Inc. (“Alorica”) in Santa Clara County Superior Court in California. Alorica has alleged breach of warranty and misrepresentation claims, which we deny. Fact discovery closed during the quarter ended June 30, 2023 and trial is currently set for September 2024. Although we believe that the ultimate outcome of this matter will not materially impact our financial position, results of operations or cash flows, legal proceedings are subject to inherent uncertainties, and an unfavorable ruling could occur, which may result in a material adverse impact on our business, financial position, results of operations and cash flows. No loss accrual had been recorded as of June 30, 2024 or December 31, 2023 related to this litigation.

- removed (2024-11-08):
[0001262039-24-000037:note_history:12]
Similar to other security companies and companies in other industries, we have experienced and may experience in the future, cybersecurity threats, malicious activity directed against our information technology infrastructure or unauthorized attempts to gain access to our and our customers’ sensitive information and systems. We currently are unaware of any existing claims or proceedings related to these types of matters, including any that we believe are likely to have a material adverse effect on our financial position.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2024-11-08):
[0001262039-24-000043:note_history:13]
SUMMARY OF SIGNIFICANT ACCOUNTING POLICIES
Basis of Presentation and Preparation—The unaudited condensed consolidated financial statements of Fortinet, Inc. and its subsidiaries (collectively, “we,” “us” or “our”) have been prepared in accordance with generally accepted accounting principles in the United States (“GAAP”) for interim financial information, as well as the instructions to Form 10-Q pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (the “SEC”). Accordingly, they do not include all of the information and footnotes required by GAAP for complete financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the year ended December 31, 2023, contained in our Annual Report on Form 10-K filed with the SEC on February 26, 2024. In the opinion of management, all adjustments, which include normal recurring adjustments, considered necessary for a fair presentation, have been included. The results of operations for the three and nine months ended September 30, 2024 are not necessarily indicative of the results to be expected for the full year or for any future periods. The condensed consolidated balance sheet as of December 31, 2023 is derived from the audited consolidated financial statements for the year ended December 31, 2023.
  (was, 2024-08-08, similarity 0.7927):
[0001262039-24-000037:note_history:13]
SUMMARY OF SIGNIFICANT ACCOUNTING POLICIES
Basis of Presentation and Preparation—The unaudited condensed consolidated financial statements of Fortinet, Inc. and its subsidiaries (collectively, “we,” “us” or “our”) have been prepared in accordance with generally accepted accounting principles in the United States (“GAAP”) for interim financial information, as well as the instructions to Form 10-Q pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (the “SEC”). Accordingly, they do not include all of the information and footnotes required by GAAP for complete financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the year ended December 31, 2023, contained in our Annual Report on Form 10-K filed with the SEC on February 26, 2024. In the opinion of management, all adjustments, which include normal recurring adjustments, considered necessary for a fair presentation, have been included. The results of operations for the three and six months ended June 30, 2024 are not necessarily indicative of the results to be expected for the full year or for any future periods. The condensed consolidated balance sheet as of December 31, 2023 is derived from the audited consolidated financial statements for the year ended December 31, 2023.

- changed (2024-11-08):
[0001262039-24-000043:note_history:14]
There have been no material changes to our significant accounting policies as of and for the three and nine months ended September 30, 2024, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended December 31, 2023 filed with the SEC.
  (was, 2024-08-08, similarity 0.9155):
[0001262039-24-000037:note_history:14]
There have been no material changes to our significant accounting policies as of and for the three and six months ended June 30, 2024, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended December 31, 2023 filed with the SEC.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-11-08):
[0001262039-24-000043:note_history:15]
On March 5, 2021, we issued $1.0 billion aggregate principal amount of senior notes (collectively, the “Senior Notes”), consisting of $500.0 million aggregate principal amount of 1.0% notes due March 15, 2026 (the “2026 Senior Notes”) and $500.0 million aggregate principal amount of 2.2% notes due March 15, 2031 (the “2031 Senior Notes”), in an underwritten registered public offering. The Senior Notes are senior unsecured obligations and rank equally with each other in right of payment and with our other outstanding obligations. We may redeem the Senior Notes at any time in whole or in part for cash, at specified redemption prices that include accrued and unpaid interest, if any, and a make-whole premium. However, no make-whole premium will be paid for redemptions of the 2026 Senior Notes on or after February 15, 2026, or the 2031 Senior Notes on or after December 15, 2030. Interest on the Senior Notes is payable on March 15 and September 15 of each year, beginning on September 15, 2021. As of September 30, 2024 and December 31, 2023, the Senior Notes were recorded as long-term debt, net of discount and issuance costs, which are amortized to interest expense over the respective contractual terms of these notes using the effective interest method.
  (was, 2024-08-08, similarity 0.9945):
[0001262039-24-000037:note_history:15]
On March 5, 2021, we issued $1.0 billion aggregate principal amount of senior notes (collectively, the “Senior Notes”), consisting of $500.0 million aggregate principal amount of 1.0% notes due March 15, 2026 (the “2026 Senior Notes”) and $500.0 million aggregate principal amount of 2.2% notes due March 15, 2031 (the “2031 Senior Notes”), in an underwritten registered public offering. The Senior Notes are senior unsecured obligations and rank equally with each other in right of payment and with our other outstanding obligations. We may redeem the Senior Notes at any time in whole or in part for cash, at specified redemption prices that include accrued and unpaid interest, if any, and a make-whole premium. However, no make-whole premium will be paid for redemptions of the 2026 Senior Notes on or after February 15, 2026, or the 2031 Senior Notes on or after December 15, 2030. Interest on the Senior Notes is payable on March 15 and September 15 of each year, beginning on September 15, 2021. As of June 30, 2024 and December 31, 2023, the Senior Notes were recorded as long-term debt, net of discount and issuance costs, which are amortized to interest expense over the respective contractual terms of these notes using the effective interest method.

- changed (2024-11-08):
[0001262039-24-000043:note_history:16]
|  | Maturity |  | Coupon Rate |  | Effective Interest Rate |  | September 30,2024 |  | December 31,2023 |
| Debt |  |  |  |  |  |  |  |  |  |
| 2026 Senior Notes | March 2026 |  | 1.0% |  | 1.3% |  | $ | 500.0 |  |  | $ | 500.0 |  |
| 2031 Senior Notes | March 2031 |  | 2.2% |  | 2.3% |  | 500.0 |  |  | 500.0 |  |
| Total debt |  |  |  |  |  |  | 1,000.0 |  |  | 1,000.0 |  |
| Less: Unamortized discount and debt issuance costs |  |  |  |  |  |  | 6.2 |  |  | 7.7 |  |
| Total long-term debt |  |  |  |  |  |  | $ | 993.8 |  |  | $ | 992.3 |  |
  (was, 2024-08-08, similarity 0.9845):
[0001262039-24-000037:note_history:16]
|  | Maturity |  | Coupon Rate |  | Effective Interest Rate |  | June 30,2024 |  | December 31,2023 |
| Debt |  |  |  |  |  |  |  |  |  |
| 2026 Senior Notes | March 2026 |  | 1.0% |  | 1.3% |  | $ | 500.0 |  |  | $ | 500.0 |  |
| 2031 Senior Notes | March 2031 |  | 2.2% |  | 2.3% |  | 500.0 |  |  | 500.0 |  |
| Total debt |  |  |  |  |  |  | 1,000.0 |  |  | 1,000.0 |  |
| Less: Unamortized discount and debt issuance costs |  |  |  |  |  |  | 6.7 |  |  | 7.7 |  |
| Total long-term debt |  |  |  |  |  |  | $ | 993.3 |  |  | $ | 992.3 |  |

- changed (2024-11-08):
[0001262039-24-000043:note_history:17]
As of September 30, 2024 and December 31, 2023, we accrued interest payable of $0.7 million and $4.7 million, respectively, and there are no financial covenants with which we must comply. During the three months ended September 30, 2024 and 2023, we recorded $4.5 million of total interest expense in relation to these Senior Notes in each period. During the nine months ended September 30, 2024 and 2023, we recorded $13.5 million of total interest expense in relation to these Senior Notes in each period. No interest costs were capitalized for the nine months ended September 30, 2024 and 2023, as the costs that qualified for capitalization were not material.
  (was, 2024-08-08, similarity 0.8112):
[0001262039-24-000037:note_history:17]
As of June 30, 2024 and December 31, 2023, we accrued interest payable of $4.7 million, and there are no financial covenants with which we must comply. During the three months ended June 30, 2024 and 2023, we recorded $4.5 million of total interest expense in relation to these Senior Notes in each period. During the six months ended June 30, 2024 and 2023, we recorded $9.0 million of total interest expense in relation to these Senior Notes in each period. No interest costs were capitalized for the six months ended June 30, 2024 and 2023, as the costs that qualified for capitalization were not material.

- added (2024-11-08):
[0001262039-24-000043:note_history:18]
The total estimated fair value of the outstanding Senior Notes was approximately $912.8 million, including accrued and unpaid interest, as of September 30, 2024. The fair value was determined based on observable market prices of identical instruments in less active markets. The estimated fair values are based on Level 2 inputs.

- removed (2024-11-08):
[0001262039-24-000037:note_history:19]
The total estimated fair value of the outstanding Senior Notes was approximately $880.6 million, including accrued and unpaid interest, as of June 30, 2024. The fair value was determined based on observable market prices of identical instruments in less active markets. The estimated fair values are based on Level 2 inputs.


## us-gaap:DebtSecuritiesAvailableForSaleUnrealizedLossPositionFairValueTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2024-11-08):
[0001262039-24-000043:note_history:20]
|  | September 30, 2024 |
|  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
|  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |
| U.S. government and agency securities | $ | 40.2 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 40.2 |  |  | $ | — |  |
| Commercial paper | 60.8 |  |  | — |  |  | — |  |  | — |  |  | 60.8 |  |  | — |  |
| Corporate debt securities | 15.8 |  |  | — |  |  | — |  |  | — |  |  | 15.8 |  |  | — |  |
| Total available-for-sale investments | $ | 116.8 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 116.8 |  |  | $ | — |  |

- changed (2024-11-08):
[0001262039-24-000043:note_history:21]
|  | December 31, 2023 |
|  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
|  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |
| U.S. government and agency securities | $ | 47.1 |  |  | $ | — |  |  | $ | 11.7 |  |  | $ | (0.3) |  |  | $ | 58.8 |  |  | $ | (0.3) |  |
| Commercial paper | 200.8 |  |  | (0.1) |  |  | — |  |  | — |  |  | 200.8 |  |  | (0.1) |  |
| Corporate debt securities | 21.8 |  |  | — |  |  | 26.9 |  |  | (0.1) |  |  | 48.7 |  |  | (0.1) |  |
| Total available-for-sale investments | $ | 269.7 |  |  | $ | (0.1) |  |  | $ | 38.6 |  |  | $ | (0.4) |  |  | $ | 308.3 |  |  | $ | (0.5) |  |
  (was, 2024-08-08, similarity 0.8046):
[0001262039-24-000037:note_history:21]
|  | December 31, 2023 |
|  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
|  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |
| Commercial paper | $ | 200.8 |  |  | $ | (0.1) |  |  | $ | — |  |  | $ | — |  |  | $ | 200.8 |  |  | $ | (0.1) |  |
| U.S. government and agency securities | 47.1 |  |  | — |  |  | 11.7 |  |  | (0.3) |  |  | 58.8 |  |  | (0.3) |  |
| Corporate debt securities | 21.8 |  |  | — |  |  | 26.9 |  |  | (0.1) |  |  | 48.7 |  |  | (0.1) |  |
| Total available-for-sale investments | $ | 269.7 |  |  | $ | (0.1) |  |  | $ | 38.6 |  |  | $ | (0.4) |  |  | $ | 308.3 |  |  | $ | (0.5) |  |

- removed (2024-11-08):
[0001262039-24-000037:note_history:22]
|  | June 30, 2024 |
|  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
|  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |
| Commercial paper | $ | 455.2 |  |  | $ | (0.4) |  |  | $ | — |  |  | $ | — |  |  | $ | 455.2 |  |  | $ | (0.4) |  |
| U.S. government and agency securities | 456.0 |  |  | (0.3) |  |  | — |  |  | — |  |  | 456.0 |  |  | (0.3) |  |
| Corporate debt securities | 88.5 |  |  | (0.1) |  |  | — |  |  | — |  |  | 88.5 |  |  | (0.1) |  |
| Total available-for-sale investments | $ | 999.7 |  |  | $ | (0.8) |  |  | $ | — |  |  | $ | — |  |  | $ | 999.7 |  |  | $ | (0.8) |  |


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-11-08):
[0001262039-24-000043:note_history:23]
|  | Maturity |  | Coupon Rate |  | Effective Interest Rate |  | September 30,2024 |  | December 31,2023 |
| Debt |  |  |  |  |  |  |  |  |  |
| 2026 Senior Notes | March 2026 |  | 1.0% |  | 1.3% |  | $ | 500.0 |  |  | $ | 500.0 |  |
| 2031 Senior Notes | March 2031 |  | 2.2% |  | 2.3% |  | 500.0 |  |  | 500.0 |  |
| Total debt |  |  |  |  |  |  | 1,000.0 |  |  | 1,000.0 |  |
| Less: Unamortized discount and debt issuance costs |  |  |  |  |  |  | 6.2 |  |  | 7.7 |  |
| Total long-term debt |  |  |  |  |  |  | $ | 993.8 |  |  | $ | 992.3 |  |
  (was, 2024-08-08, similarity 0.9845):
[0001262039-24-000037:note_history:23]
|  | Maturity |  | Coupon Rate |  | Effective Interest Rate |  | June 30,2024 |  | December 31,2023 |
| Debt |  |  |  |  |  |  |  |  |  |
| 2026 Senior Notes | March 2026 |  | 1.0% |  | 1.3% |  | $ | 500.0 |  |  | $ | 500.0 |  |
| 2031 Senior Notes | March 2031 |  | 2.2% |  | 2.3% |  | 500.0 |  |  | 500.0 |  |
| Total debt |  |  |  |  |  |  | 1,000.0 |  |  | 1,000.0 |  |
| Less: Unamortized discount and debt issuance costs |  |  |  |  |  |  | 6.7 |  |  | 7.7 |  |
| Total long-term debt |  |  |  |  |  |  | $ | 993.3 |  |  | $ | 992.3 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2024-11-08):
[0001262039-24-000043:note_history:24]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30,2024 |  | September 30,2023 |  | September 30,2024 |  | September 30,2023 |
| Product | $ | 473.9 |  |  | $ | 465.9 |  |  | $ | 1,334.7 |  |  | $ | 1,439.2 |  |
| Service: |  |  |  |  |  |  |  |
| Security subscription | 595.8 |  |  | 494.6 |  |  | 1,691.4 |  |  | 1,373.6 |  |
| Technical support and other | 438.4 |  |  | 374.1 |  |  | 1,269.6 |  |  | 1,076.9 |  |
| Total service revenue | 1,034.2 |  |  | 868.7 |  |  | 2,961.0 |  |  | 2,450.5 |  |
| Total revenue | $ | 1,508.1 |  |  | $ | 1,334.6 |  |  | $ | 4,295.7 |  |  | $ | 3,889.7 |  |
  (was, 2024-08-08, similarity 0.881):
[0001262039-24-000037:note_history:24]
|  | Three Months Ended |  | Six Months Ended |
|  | June 30,2024 |  | June 30,2023 |  | June 30,2024 |  | June 30,2023 |
| Product | $ | 451.9 |  |  | $ | 472.6 |  |  | $ | 860.8 |  |  | $ | 973.3 |  |
| Service: |  |  |  |  |  |  |  |
| Security subscription | 558.7 |  |  | 457.3 |  |  | 1,095.6 |  |  | 879.0 |  |
| Technical support and other | 423.7 |  |  | 362.9 |  |  | 831.2 |  |  | 702.8 |  |
| Total service revenue | 982.4 |  |  | 820.2 |  |  | 1,926.8 |  |  | 1,581.8 |  |
| Total revenue | $ | 1,434.3 |  |  | $ | 1,292.8 |  |  | $ | 2,787.6 |  |  | $ | 2,555.1 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2024-11-08):
[0001262039-24-000043:note_history:25]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30,2024 |  | September 30,2023 |  | September 30,2024 |  | September 30,2023 |
| Product | $ | 473.9 |  |  | $ | 465.9 |  |  | $ | 1,334.7 |  |  | $ | 1,439.2 |  |
| Service: |  |  |  |  |  |  |  |
| Security subscription | 595.8 |  |  | 494.6 |  |  | 1,691.4 |  |  | 1,373.6 |  |
| Technical support and other | 438.4 |  |  | 374.1 |  |  | 1,269.6 |  |  | 1,076.9 |  |
| Total service revenue | 1,034.2 |  |  | 868.7 |  |  | 2,961.0 |  |  | 2,450.5 |  |
| Total revenue | $ | 1,508.1 |  |  | $ | 1,334.6 |  |  | $ | 4,295.7 |  |  | $ | 3,889.7 |  |
  (was, 2024-08-08, similarity 0.881):
[0001262039-24-000037:note_history:25]
|  | Three Months Ended |  | Six Months Ended |
|  | June 30,2024 |  | June 30,2023 |  | June 30,2024 |  | June 30,2023 |
| Product | $ | 451.9 |  |  | $ | 472.6 |  |  | $ | 860.8 |  |  | $ | 973.3 |  |
| Service: |  |  |  |  |  |  |  |
| Security subscription | 558.7 |  |  | 457.3 |  |  | 1,095.6 |  |  | 879.0 |  |
| Technical support and other | 423.7 |  |  | 362.9 |  |  | 831.2 |  |  | 702.8 |  |
| Total service revenue | 982.4 |  |  | 820.2 |  |  | 1,926.8 |  |  | 1,581.8 |  |
| Total revenue | $ | 1,434.3 |  |  | $ | 1,292.8 |  |  | $ | 2,787.6 |  |  | $ | 2,555.1 |  |

- changed (2024-11-08):
[0001262039-24-000043:note_history:26]
During the three and nine months ended September 30, 2024, we recognized $660.3 million and $2.28 billion in revenue that was included in the deferred revenue balance as of December 31, 2023, respectively. During the three and nine months ended September 30, 2023, we recognized $514.3 million and $1.80 billion in revenue that was included in the deferred revenue balance as of December 31, 2022, respectively.
  (was, 2024-08-08, similarity 0.8692):
[0001262039-24-000037:note_history:26]
During the three and six months ended June 30, 2024, we recognized $764.3 million and $1.62 billion in revenue that was included in the deferred revenue balance as of December 31, 2023, respectively. During the three and six months ended June 30, 2023, we recognized $609.8 million and $1.29 billion in revenue that was included in the deferred revenue balance as of December 31, 2022, respectively.

- changed (2024-11-08):
[0001262039-24-000043:note_history:27]
As of September 30, 2024, the aggregate amount of the transaction price allocated to remaining performance obligations was $6.08 billion, which was substantially comprised of deferred security subscription and technical support services revenue that will be recognized in future periods. We expect to recognize approximately $3.12 billion as revenue over the next 12 months and the remainder thereafter.
  (was, 2024-08-08, similarity 0.9832):
[0001262039-24-000037:note_history:27]
As of June 30, 2024, the aggregate amount of the transaction price allocated to remaining performance obligations was $5.92 billion, which was substantially comprised of deferred security subscription and technical support services revenue that will be recognized in future periods. We expect to recognize approximately $2.99 billion as revenue over the next 12 months and the remainder thereafter.

- changed (2024-11-08):
[0001262039-24-000043:note_history:28]
The allowance for credit losses was $4.7 million and $8.2 million as of September 30, 2024 and December 31, 2023, respectively. Provisions, write-offs and recoveries were not material during the nine months ended September 30, 2024 and 2023.
  (was, 2024-08-08, similarity 0.8747):
[0001262039-24-000037:note_history:28]
The allowance for credit losses was $5.7 million and $8.2 million as of June 30, 2024 and December 31, 2023, respectively. Provisions, write-offs and recoveries were not material during the six months ended June 30, 2024 and 2023.

- changed (2024-11-08):
[0001262039-24-000043:note_history:29]
Amortization of deferred contract costs during the three months ended September 30, 2024 and 2023 were $73.6 million and $68.0 million, respectively. Amortization of deferred contract costs during the nine months ended September 30, 2024 and 2023 were $218.3 million and $195.9 million, respectively.
  (was, 2024-08-08, similarity 0.8847):
[0001262039-24-000037:note_history:29]
Amortization of deferred contract costs during the three months ended June 30, 2024 and 2023 were $72.7 million and $65.4 million, respectively. Amortization of deferred contract costs during the six months ended June 30, 2024 and 2023 were $144.7 million and $127.9 million, respectively.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- changed (2024-11-08):
[0001262039-24-000043:note_history:30]
SUBSEQUENT EVENTS
Real Property Purchase
  (was, 2024-08-08, similarity 0.6984):
[0001262039-24-000037:note_history:30]
Real Property Purchases

- added (2024-11-08):
[0001262039-24-000043:note_history:31]
In November 2024, we purchased real property in Atlanta, Georgia, for $15.8 million in cash.

- added (2024-11-08):
[0001262039-24-000043:note_history:32]
Share Repurchase Program

- added (2024-11-08):
[0001262039-24-000043:note_history:33]
In October 2024, our board of directors approved a $1.0 billion increase in the authorized stock repurchase amount under the Repurchase Program and extended the term of the Repurchase Program to February 28, 2026, bringing the aggregate amount authorized to be repurchased to $8.25 billion of our outstanding common stock through February 28, 2026. As of November 8, 2024, approximately $2.03 billion remained available for future share repurchases.

- removed (2024-11-08):
[0001262039-24-000037:note_history:34]
SUBSEQUENT EVENTS 
Acquisition of Lacework, Inc.

- removed (2024-11-08):
[0001262039-24-000037:note_history:35]
On August 1, 2024 (“Lacework Acquisition Date”), we completed the acquisition of Lacework, Inc. (“Lacework”), a privately held data-driven cloud security company, for approximately $149 million in cash, net of cash acquired. We intend to integrate Lacework’s Cloud-Native Application Protection Platform solution into our existing portfolio. Given the short period of time between the Lacework Acquisition Date and the condensed consolidated financial statements in this Quarterly Report on Form 10-Q, the preliminary allocation of the cash purchase price to the fair value of assets acquired and liabilities assumed has not yet been completed.

- removed (2024-11-08):
[0001262039-24-000037:note_history:36]
Acquisition of Next DLP Holdings Limited

- removed (2024-11-08):
[0001262039-24-000037:note_history:37]
On August 5, 2024 (“Next DLP Acquisition Date”), we completed the acquisition of Next DLP Holdings Limited (“Next DLP”), a privately-held company that focuses on insider risk and data loss protection (“DLP”), for approximately $96 million in cash, net of cash acquired. With this acquisition, we will improve our position in the standalone enterprise DLP market and strengthen our leadership in integrated DLP markets within endpoint and SASE in alignment with our business strategy. Given the short period of time between the Next DLP Acquisition Date and the issuance of the condensed consolidated financial statements in this Quarterly Report on Form 10-Q, the preliminary allocation of the cash purchase price to the fair value of assets acquired and liabilities assumed has not yet been completed.

- removed (2024-11-08):
[0001262039-24-000037:note_history:38]
In July and August 2024, we signed definitive agreements to purchase real property in Calgary, Canada, and Union City, California, for $6.5 million and $16.2 million in cash, respectively.
