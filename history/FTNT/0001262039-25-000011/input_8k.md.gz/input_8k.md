# FTNT 8-K — 0001262039-25-000007 filed 2025-02-06

## item codes, every 8-K on or before 2025-02-21

- 2025-02-06 0001262039-25-000007 — 2.02, 5.02, 9.01
- 2025-01-22 0001262039-25-000003 — 5.02 — amendment, the index does not say of what
- 2024-11-12 0001262039-24-000045 — 5.02, 9.01
- 2024-11-07 0001262039-24-000040 — 2.02, 9.01
- 2024-08-07 0001262039-24-000034 — 2.02, 9.01 — amendment of 0001262039-24-000032
- 2024-08-06 0001262039-24-000032 — 2.02, 9.01
- 2024-07-24 0001262039-24-000028 — 5.02 — amendment, the index does not say of what
- 2024-06-20 0001262039-24-000025 — 5.07
- 2024-05-02 0001262039-24-000017 — 2.02, 9.01
- 2024-02-23 0001262039-24-000011 — 5.02, 9.01
- 2024-02-06 0001262039-24-000006 — 2.02, 9.01
- 2024-01-18 0001262039-24-000003 — 5.02
- 2023-12-01 0001262039-23-000041 — 5.02
- 2023-11-02 0001262039-23-000035 — 2.02, 9.01
- 2023-08-03 0001262039-23-000027 — 2.02, 9.01
- 2023-06-23 0001262039-23-000024 — 5.03, 5.07, 9.01
- 2023-05-04 0001262039-23-000013 — 2.02, 9.01
- 2023-02-08 0001262039-23-000006 — 5.03, 9.01
- 2023-02-07 0001262039-23-000003 — 2.02, 9.01
- 2022-11-02 0001262039-22-000035 — 2.02, 9.01
- 2022-08-03 0001262039-22-000026 — 2.02, 9.01
- 2022-06-22 0001262039-22-000023 — 5.03, 9.01
- 2022-06-21 0001262039-22-000021 — 5.07
- 2022-05-04 0001262039-22-000015 — 2.02, 9.01
- 2022-05-02 0001262039-22-000012 — 5.02
- 2022-04-22 0001262039-22-000010 — 8.01
- 2022-02-03 0001262039-22-000005 — 2.02, 9.01
- 2022-01-26 0001262039-22-000002 — 5.02, 9.01 — amendment, the index does not say of what
- 2021-11-04 0001262039-21-000027 — 2.02, 9.01
- 2021-10-06 0001262039-21-000024 — 5.02, 9.01
- 2021-07-29 0001262039-21-000019 — 2.02, 9.01
- 2021-06-23 0001262039-21-000016 — 5.07
- 2021-04-30 0001104659-21-059008 — 5.03 — amendment, the index does not say of what
- 2021-04-29 0001262039-21-000011 — 2.02, 9.01
- 2021-04-28 0001104659-21-056360 — 5.02, 5.03, 9.01
- 2021-03-05 0001193125-21-071498 — 1.01, 9.01
- 2021-02-25 0001193125-21-057281 — 1.01, 9.01
- 2021-02-04 0001262039-21-000005 — 2.02, 9.01
- 2020-12-08 0001262039-20-000070 — 8.01
- 2020-10-29 0001262039-20-000063 — 2.02, 9.01
- 2020-10-20 0001262039-20-000060 — 5.02 — amendment, the index does not say of what
- 2020-08-26 0001262039-20-000056 — 5.02, 9.01
- 2020-08-06 0001262039-20-000051 — 2.02, 9.01
- 2020-07-21 0001262039-20-000044 — 5.03, 8.01, 9.01
- 2020-06-24 0001262039-20-000038 — 5.07
- 2020-05-06 0001262039-20-000029 — 2.02, 9.01
- 2020-04-23 0001262039-20-000025 — 5.03, 9.01
- 2020-04-23 0001262039-20-000024 — 5.02 — amendment of 0001262039-20-000025
- 2020-02-28 0001262039-20-000015 — 5.02, 9.01
- 2020-02-06 0001262039-20-000004 — 2.02, 9.01
- 2019-12-12 0001262039-19-000038 — 8.01
- 2019-10-31 0001262039-19-000032 — 2.02, 9.01
- 2019-10-28 0001262039-19-000027 — 8.01
- 2019-10-23 0001262039-19-000025 — 5.02, 9.01
- 2019-08-01 0001262039-19-000021 — 2.02, 9.01
- 2019-06-26 0001262039-19-000018 — 5.07
- 2019-05-02 0001262039-19-000010 — 2.02, 9.01
- 2019-02-06 0001262039-19-000002 — 2.02, 9.01
- 2018-11-01 0001262039-18-000037 — 2.02, 9.01
- 2018-10-23 0001262039-18-000035 — 8.01
- 2018-08-01 0001262039-18-000025 — 2.02, 9.01
- 2018-06-28 0001262039-18-000023 — 5.03, 5.07, 9.01
- 2018-06-04 0001262039-18-000021 — 8.01
- 2018-05-03 0001262039-18-000017 — 2.02, 5.02, 9.01
- 2018-02-05 0001262039-18-000004 — 2.02, 5.02, 9.01
- 2017-10-26 0001262039-17-000031 — 2.02, 9.01
- 2017-10-19 0001262039-17-000029 — 5.02 — amendment, the index does not say of what
- 2017-07-26 0001262039-17-000025 — 2.02, 9.01
- 2017-06-27 0001262039-17-000023 — 5.07
- 2017-05-31 0001262039-17-000021 — 5.02 — amendment of 0001262039-17-000019
- 2017-05-30 0001262039-17-000019 — 5.02, 9.01
- 2017-04-27 0001262039-17-000013 — 2.02, 9.01
- 2017-02-02 0001262039-17-000003 — 2.02, 9.01
- 2016-10-27 0001262039-16-000085 — 2.02, 9.01
- 2016-10-11 0001262039-16-000082 — 2.02, 9.01
- 2016-07-28 0001262039-16-000076 — 2.02, 9.01
- 2016-07-22 0001262039-16-000073 — 8.01, 9.01
- 2016-06-20 0001262039-16-000068 — 5.07
- 2016-06-07 0001193125-16-614788 — 8.01
- 2016-04-26 0001262039-16-000061 — 2.02, 9.01
- 2016-01-28 0001262039-16-000051 — 2.02, 9.01
- 2015-10-27 0001262039-15-000045 — 2.02
- 2015-10-22 0001262039-15-000042 — 5.02 — amendment, the index does not say of what
- 2015-10-22 0001262039-15-000041 — 5.02 — amendment, the index does not say of what
- 2015-10-22 0001262039-15-000039 — 2.02, 9.01
- 2015-09-28 0001262039-15-000034 — 5.02, 9.01
- 2015-09-22 0001262039-15-000031 — 9.01 — amendment of 0001193125-15-248065
- 2015-08-28 0001262039-15-000027 — 3.01, 5.02
- 2015-07-23 0001262039-15-000021 — 5.02
- 2015-07-22 0001262039-15-000019 — 2.02, 9.01
- 2015-07-08 0001193125-15-248065 — 2.01, 8.01, 9.01
- 2015-06-22 0001193125-15-229099 — 5.07
- 2015-06-19 0001193125-15-228428 — 5.02, 9.01
- 2015-04-20 0001262039-15-000014 — 2.02, 9.01
- 2015-01-28 0001262039-15-000005 — 2.02, 9.01
- 2014-10-22 0001262039-14-000036 — 2.02, 9.01
- 2014-07-23 0001262039-14-000030 — 2.02, 9.01
- 2014-06-24 0001262039-14-000027 — 5.07
- 2014-04-23 0001262039-14-000021 — 2.02, 9.01
- 2014-04-21 0001262039-14-000018 — 5.03, 9.01
- 2014-01-29 0001262039-14-000004 — 2.02, 9.01
- 2013-12-20 0001262039-13-000061 — 5.02, 9.01
- 2013-11-27 0001262039-13-000057 — 5.02, 7.01, 9.01
- 2013-11-12 0001445305-13-002993 — 5.02
- 2013-10-23 0001262039-13-000051 — 2.02, 9.01
- 2013-07-30 0001262039-13-000039 — 2.02, 9.01
- 2013-06-25 0001262039-13-000030 — 5.07
- 2013-04-30 0001262039-13-000023 — 2.02, 9.01
- 2013-04-19 0001262039-13-000020 — 5.02, 9.01
- 2013-04-19 0001262039-13-000018 — 5.02 — amendment of 0001262039-13-000020
- 2013-04-10 0001262039-13-000016 — 2.02, 9.01
- 2013-03-26 0001262039-13-000013 — 5.02
- 2013-01-30 0001262039-13-000005 — 2.02, 9.01
- 2013-01-24 0001262039-13-000002 — 5.02, 9.01
- 2012-10-16 0001262039-12-000048 — 2.02, 9.01
- 2012-10-01 0001262039-12-000045 — 5.02
- 2012-09-26 0001262039-12-000043 — 5.01
- 2012-07-25 0001262039-12-000038 — 2.02, 9.01
- 2012-07-19 0001262039-12-000034 — 5.02
- 2012-06-20 0001193125-12-275869 — 5.07
- 2012-04-27 0001262039-12-000029 — 5.02
- 2012-04-24 0001262039-12-000025 — 2.02, 9.01
- 2012-01-31 0001262039-12-000006 — 2.02, 9.01
- 2012-01-25 0001262039-12-000003 — 5.03
- 2011-10-24 0001262039-11-000036 — 2.02
- 2011-07-19 0001262039-11-000014 — 2.02, 9.01
- 2011-06-27 0001193125-11-174474 — 5.02, 5.07, 9.01
- 2011-04-27 0001193125-11-111938 — 2.02, 9.01
- 2011-01-25 0001193125-11-013914 — 2.02, 9.01
- 2010-10-21 0001193125-10-233676 — 2.02, 9.01
- 2010-09-02 0001193125-10-203099 — 8.01
- 2010-07-22 0001193125-10-163844 — 2.02, 9.01
- 2010-06-24 0001193125-10-146082 — 5.07
- 2010-04-28 0001193125-10-096698 — 2.02, 9.01
- 2010-02-09 0001193125-10-024614 — 8.01
- 2010-01-27 0001193125-10-014292 — 2.02, 9.01
- 2010-01-26 0001193125-10-013031 — 5.02, 9.01

## late-filing notifications on or before 2025-02-21

- none on or before 2025-02-21

## item 2.02 — earnings release, exhibit 99.1

[0001262039-25-000007:8k_2_02:1]
EX-99.1
2
ftntq4-2024ex991.htm
PRESS RELEASE

[0001262039-25-000007:8k_2_02:2]
Document

[0001262039-25-000007:8k_2_02:3]
Press Release

[0001262039-25-000007:8k_2_02:4]
Fortinet Reports Fourth Quarter and Full Year 2024 Financial Results

[0001262039-25-000007:8k_2_02:5]
Fourth Quarter 2024 Highlights

[0001262039-25-000007:8k_2_02:6]
•Total revenue of $1.66 billion, up 17% year over year

[0001262039-25-000007:8k_2_02:7]
•Product revenue of $574 million, up 18% year over year

[0001262039-25-000007:8k_2_02:8]
•Billings of $2.00 billion, up 7% year over year1

[0001262039-25-000007:8k_2_02:9]
•Record GAAP operating margin of 35%

[0001262039-25-000007:8k_2_02:10]
•Record Non-GAAP operating margin of 39%1

[0001262039-25-000007:8k_2_02:11]
•Unified SASE ARR2 up 28% and Security Operations ARR2 up 32%, year over year

[0001262039-25-000007:8k_2_02:12]
•Ranked #7 on the Forbes Most Trusted Companies in America 2025 list, the only cybersecurity company in the top 50

[0001262039-25-000007:8k_2_02:13]
Full Year 2024 Highlights

[0001262039-25-000007:8k_2_02:14]
•Total revenue of $5.96 billion, up 12% year over year

[0001262039-25-000007:8k_2_02:15]
•Service revenue of $4.05 billion, up 20% year over year

[0001262039-25-000007:8k_2_02:16]
•Record GAAP operating margin of 30%

[0001262039-25-000007:8k_2_02:17]
•Record Non-GAAP operating margin of 35%1

[0001262039-25-000007:8k_2_02:18]
•Remaining performance obligations of $6.42 billion, up 12% year over year

[0001262039-25-000007:8k_2_02:19]
•Cash flow from operations of $2.26 billion

[0001262039-25-000007:8k_2_02:20]
•Free cash flow of $1.88 billion1

[0001262039-25-000007:8k_2_02:21]
•Exceeded the ‘Rule of 45’ for the fifth consecutive year

[0001262039-25-000007:8k_2_02:22]
SUNNYVALE, Calif. - February 6, 2025 - Fortinet® (Nasdaq: FTNT), a global cybersecurity leader driving the convergence of networking and security, today announced financial results for the fourth quarter of 2024 and full year ended December 31, 2024.

[0001262039-25-000007:8k_2_02:23]
“In the fourth quarter, we successfully balanced growth and profitability as our non-GAAP operating margin increased 720 basis points year-over-year to a company record of 39%, while revenue grew 17%,” said Ken Xie, Founder, Chairman and Chief Executive Officer of Fortinet. “We continue to execute our strategy of investing in the high-growth Unified SASE and Security Operations markets, while strengthening our position in Secure Networking. Our customers are increasingly recognizing the benefits of a single-vendor approach to SASE, and we expect to emerge as a leader in this space, being the only company to natively develop all SASE functions within a unified operating system, FortiOS, which seamlessly integrates networking and security capabilities.”

[0001262039-25-000007:8k_2_02:24]
Financial Summary for the Fourth Quarter of 2024

[0001262039-25-000007:8k_2_02:25]
•Revenue: Total revenue was $1.66 billion for the fourth quarter of 2024, an increase of 17.3% compared to $1.42 billion for the same quarter of 2023.

[0001262039-25-000007:8k_2_02:26]
•Service Revenue: Service revenue was $1.09 billion for the fourth quarter of 2024, an increase of 17.2% compared to $927.0 million for the same quarter of 2023.

[0001262039-25-000007:8k_2_02:27]
•Product Revenue: Product revenue was $574.0 million for the fourth quarter of 2024, an increase of 17.6% compared to $488.1 million for the same quarter of 2023.

[0001262039-25-000007:8k_2_02:28]
•Billings1: Total billings were $2.00 billion for the fourth quarter of 2024, an increase of 7.4% compared to $1.86 billion for the same quarter of 2023.

[0001262039-25-000007:8k_2_02:29]
•Unified SASE ARR2: Unified SASE ARR was $1.12 billion for the fourth quarter of 2024, an increase of 27.9% compared to $875.3 million for the same quarter of 2023.

[0001262039-25-000007:8k_2_02:30]
•Security Operations ARR2: Security Operations ARR was $422.4 million for the fourth quarter of 2024, an increase of 32.2% compared to $319.6 million for the same quarter of 2023.

[0001262039-25-000007:8k_2_02:31]
•GAAP Operating Income and Margin: GAAP operating income was $574.1 million for the fourth quarter of 2024, representing a GAAP operating margin of 34.6%. GAAP operating income was $385.4 million for the same quarter of 2023, representing a GAAP operating margin of 27.2%.

[0001262039-25-000007:8k_2_02:32]
•Non-GAAP Operating Income and Margin1: Non-GAAP operating income was $650.9 million for the fourth quarter of 2024, representing a non-GAAP operating margin of 39.2%. Non-GAAP operating income was $453.5 million for the same quarter of 2023, representing a non-GAAP operating margin of 32.0%.

[0001262039-25-000007:8k_2_02:33]
•GAAP Net Income and Diluted Net Income Per Share: GAAP net income was $526.2 million for the fourth quarter of 2024, compared to GAAP net income of $310.9 million for the same quarter of 2023. GAAP diluted net income per share was $0.68 for the fourth quarter of 2024, based on 775.2 million diluted weighted-average shares outstanding, compared to GAAP diluted net income per share of $0.40 for the same quarter of 2023, based on 772.3 million diluted weighted-average shares outstanding.

[0001262039-25-000007:8k_2_02:34]
•Non-GAAP Net Income and Diluted Net Income Per Share1: Non-GAAP net income was $571.5 million for the fourth quarter of 2024, compared to non-GAAP net income of $392.0 million for the same quarter of 2023. Non-GAAP diluted net income per share was $0.74 for the fourth quarter of 2024, based on 775.2 million diluted weighted-average shares outstanding, compared to $0.51 for the same quarter of 2023, based on 772.3 million diluted weighted-average shares outstanding.

[0001262039-25-000007:8k_2_02:35]
•Cash Flow: Cash flow from operations was $477.6 million for the fourth quarter of 2024, compared to $191.7 million for the same quarter of 2023.

[0001262039-25-000007:8k_2_02:36]
•Free Cash Flow1: Free cash flow was $380.0 million for the fourth quarter of 2024, compared to $164.8 million for the same quarter of 2023.

[0001262039-25-000007:8k_2_02:37]
Financial Summary for the Full Year 2024

[0001262039-25-000007:8k_2_02:38]
•Revenue: Total revenue was $5.96 billion for 2024, an increase of 12.3% compared to $5.30 billion in 2023.

[0001262039-25-000007:8k_2_02:39]
•Service Revenue: Service revenue was $4.05 billion for 2024, an increase of 19.8% compared to $3.38 billion in 2023.

[0001262039-25-000007:8k_2_02:40]
•Product Revenue: Product revenue was $1.91 billion for 2024, a decrease of 1.0% compared to $1.93 billion in 2023.

[0001262039-25-000007:8k_2_02:41]
•Billings1: Total billings were $6.53 billion for 2024, an increase of 2.1% compared to $6.40 billion in 2023.

[0001262039-25-000007:8k_2_02:42]
•Remaining performance obligations: Remaining performance obligations were $6.42 billion as of December 31, 2024, an increase of 11.7% compared to $5.75 billion as of December 31, 2023.

[0001262039-25-000007:8k_2_02:43]
•Deferred Revenue: Total deferred revenue was $6.36 billion as of December 31, 2024, an increase of 10.9% compared to $5.74 billion as of December 31, 2023.

[0001262039-25-000007:8k_2_02:44]
•GAAP Operating Income and Margin: GAAP operating income was $1.80 billion for 2024, representing a GAAP operating margin of 30.3%. GAAP operating income was $1.24 billion for 2023, representing a GAAP operating margin of 23.4%.

[0001262039-25-000007:8k_2_02:45]
•Non-GAAP Operating Income and Margin1: Non-GAAP operating income was $2.09 billion for 2024, representing a non-GAAP operating margin of 35.0%. Non-GAAP operating income was $1.51 billion for 2023, representing a non-GAAP operating margin of 28.4%.

[0001262039-25-000007:8k_2_02:46]
•GAAP Net Income and Diluted Net Income Per Share: GAAP net income was $1.75 billion for 2024, compared to GAAP net income of $1.15 billion for 2023. GAAP diluted net income per share was $2.26 for 2024, based on 771.9 million diluted weighted-average shares outstanding, compared to GAAP diluted net income per share of $1.46 for 2023, based on 788.2 million diluted weighted-average shares outstanding.

[0001262039-25-000007:8k_2_02:47]
•Non-GAAP Net Income and Diluted Net Income Per Share1: Non-GAAP net income was $1.83 billion for 2024, compared to non-GAAP net income of $1.29 billion for 2023. Non-GAAP diluted net income per share was $2.37 for 2024, based on 771.9 million diluted weighted-average shares outstanding, compared to $1.63 for 2023, based on 788.2 million diluted weighted-average shares outstanding.

[0001262039-25-000007:8k_2_02:48]
•Cash Flow: Cash flow from operations was $2.26 billion in 2024 compared to $1.94 billion in 2023.

[0001262039-25-000007:8k_2_02:49]
•Free Cash Flow1: Free cash flow was $1.88 billion in 2024, compared to $1.73 billion in 2023.

[0001262039-25-000007:8k_2_02:50]
Guidance

[0001262039-25-000007:8k_2_02:51]
For the first quarter of 2025, Fortinet currently expects:

[0001262039-25-000007:8k_2_02:52]
•Revenue in the range of $1.500 billion to $1.560 billion

[0001262039-25-000007:8k_2_02:53]
•Billings in the range of $1.520 billion to $1.600 billion

[0001262039-25-000007:8k_2_02:54]
•Non-GAAP gross margin in the range of 80.0% to 81.0%

[0001262039-25-000007:8k_2_02:55]
•Non-GAAP operating margin in the range of 30.0% to 31.0%

[0001262039-25-000007:8k_2_02:56]
•Diluted non-GAAP net income per share in the range of $0.52 to $0.54, assuming a non-GAAP effective tax rate of 18%. This assumes a diluted share count of 774 million to 780 million.

[0001262039-25-000007:8k_2_02:57]
For the fiscal year 2025, Fortinet currently expects:

[0001262039-25-000007:8k_2_02:58]
•Revenue in the range of $6.650 billion to $6.850 billion

[0001262039-25-000007:8k_2_02:59]
•Service revenue in the range of $4.575 billion to $4.725 billion

[0001262039-25-000007:8k_2_02:60]
•Billings in the range of $7.200 billion to $7.400 billion

[0001262039-25-000007:8k_2_02:61]
•Non-GAAP gross margin in the range of 79.0% to 81.0%

[0001262039-25-000007:8k_2_02:62]
•Non-GAAP operating margin in the range of 31.0% to 33.0%

[0001262039-25-000007:8k_2_02:63]
•Diluted non-GAAP net income per share in the range of $2.41 to $2.47, assuming a non-GAAP effective tax rate of 18%. This assumes a diluted share count of 773 million to 783 million.

[0001262039-25-000007:8k_2_02:64]
Our guidance with respect to non-GAAP financial measures excludes stock-based compensation, amortization of acquired intangible assets, charges in connection with litigation settlement, gain on intellectual property matters, gain on bargain purchase related to acquisition,  non-cash charge of impairment on an equity method investment and a tax adjustment required for an effective tax rate on a non-GAAP basis, which differs from the GAAP effective tax rate. We have not reconciled our guidance with respect to non-GAAP financial measures to the corresponding GAAP measures because certain items that impact these measures are uncertain or out of our control, or cannot be reasonably predicted. Accordingly, a reconciliation of these non-GAAP financial measures to the corresponding GAAP measures is not available without unreasonable effort.

[0001262039-25-000007:8k_2_02:65]
1 A reconciliation of GAAP to non-GAAP measures has been provided in the financial statement tables included in this press release. An explanation of these measures is also included below under the heading “Non-GAAP Financial Measures”.

[0001262039-25-000007:8k_2_02:66]
2 ARR is defined as the annualized value of renewable / recurring customer agreements as of the measurement date, assuming any contract that expires during the next 12 months is renewed at its existing value.

[0001262039-25-000007:8k_2_02:67]
Conference Call Details

[0001262039-25-000007:8k_2_02:68]
Fortinet will host a conference call today at 1:30 p.m. Pacific Time (4:30 p.m. Eastern Time) to discuss the earnings results. A live webcast of the conference call and supplemental slides will be accessible from the Investor Relations page of Fortinet’s website at https://investor.fortinet.com and a replay will be archived and accessible at https://investor.fortinet.com/events-and-presentations.

[0001262039-25-000007:8k_2_02:69]
First Quarter 2025 Conference Participation Schedule:

[0001262039-25-000007:8k_2_02:70]
•Morgan Stanley Technology, Media & Telecom Conference

[0001262039-25-000007:8k_2_02:71]
March 4, 2025

[0001262039-25-000007:8k_2_02:72]
Members of Fortinet’s management team are expected to present at this conference and discuss the latest company strategies and initiatives. Fortinet’s conference presentations are expected to be available via webcast on the company’s website. To access the most updated information, pre-register and listen to the webcast of each event, please visit the Investor Presentation & Events page of Fortinet’s website at https://investor.fortinet.com/events-and-presentations. The schedule is subject to change.

[0001262039-25-000007:8k_2_02:73]
About Fortinet (www.fortinet.com)

[0001262039-25-000007:8k_2_02:74]
Fortinet (Nasdaq: FTNT) is a driving force in the evolution of cybersecurity and the convergence of networking and security. Our mission is to secure people, devices and data everywhere, and today we deliver cybersecurity everywhere our customers need it with the largest integrated portfolio of over 50 enterprise-grade products. Well over half a million customers trust Fortinet’s solutions, which are among the most deployed, most patented and most validated in the industry. The Fortinet Training Institute, one of the largest and broadest training programs in the industry, is dedicated to making cybersecurity training and new career opportunities available to everyone. Collaboration with esteemed organizations from both the public and private sectors, including Computer Emergency Response Teams (“CERTs”), government entities, and academia, is a fundamental aspect of Fortinet’s commitment to enhance cyber resilience globally. FortiGuard Labs, Fortinet’s elite threat intelligence and research organization, develops and utilizes leading-edge machine learning and AI technologies to provide customers with timely and consistently top-rated protection and actionable threat intelligence. Learn more at https://www.fortinet.com, the Fortinet Blog or FortiGuard Labs.

[0001262039-25-000007:8k_2_02:75]
#          #          #

[0001262039-25-000007:8k_2_02:76]
Copyright © 2025 Fortinet, Inc. All rights reserved. The symbols ® and ™ denote respectively federally registered trademarks and common law trademarks of Fortinet, Inc., its subsidiaries and affiliates. Fortinet’s trademarks include, but are not limited to, the following: Fortinet, the Fortinet logo, FortiGate, FortiOS, FortiGuard, FortiCare, FortiAnalyzer, FortiManager, FortiASIC, FortiClient, FortiCloud, FortiMail, FortiSandbox, FortiADC, FortiAgent, FortiAI, FortiAIOps, FortiAntenna, FortiAP, FortiAPCam, FortiAppSec, FortiAuthenticator, FortiCache, FortiCall, FortiCam, FortiCamera, FortiCarrier, FortiCART, FortiCASB, FortiCentral, FortiCNP, FortiConnect, FortiController, FortiConverter, FortiCSPM, FortiCWP, FortiDAST, FortiDATA, FortiDB, FortiDDoS, FortiDeceptor, FortiDeploy, FortiDevice, FortiDevSec, FortiDLP, FortiEdge, FortiEDR, FortiEndpoint, FortiExplorer, FortiExtender, FortiFirewall, FortiFlex, FortiFone, FortiGSLB, FortiGuest, FortiHypervisor, FortiInsight, FortiIsolator, FortiLAN, FortiLink, FortiMonitor, FortiNAC, FortiNDR, FortiPAM, FortiPenTest, FortiPhish, FortiPoint, FortiPolicy, FortiPortal, FortiPresence, FortiProxy, FortiRecon, FortiRecorder, FortiSASE, FortiScanner, FortiSDNConnector, FortiSEC, FortiSIEM, FortiSMS, FortiSOAR, FortiSRA, FortiStack, FortiSwitch, FortiTester, FortiTIP, FortiToken, FortiTrust, FortiVoice, FortiWAN, FortiWeb, FortiWiFi, FortiWLC, FortiWLM, FortiXDR and Lacework FortiCNAPP. Other trademarks belong to their respective owners. Fortinet has not independently verified statements or certifications herein attributed to third parties and Fortinet does not independently endorse such statements. Notwithstanding anything to the contrary herein, nothing herein constitutes a warranty, guarantee, contract, binding specification or other binding commitment by Fortinet or any indication of intent related to a binding commitment, and performance and other specification information herein may be unique to certain environments.

[0001262039-25-000007:8k_2_02:77]
FTNT-F

[0001262039-25-000007:8k_2_02:78]
Forward-Looking Statements

[0001262039-25-000007:8k_2_02:79]
This press release contains forward-looking statements that involve risks and uncertainties. These forward-looking statements include statements regarding any indications related to future growth and market share gains, our strategy going forward, and guidance and expectations around future financial results, including guidance and expectations for the first quarter of 2025 and full year 2025, and any statements regarding our market opportunity and market size, and business momentum. Although we attempt to be accurate in making forward-looking statements, it is possible that future circumstances might differ from the assumptions on which such statements are based such that actual results are materially different from our forward-looking statements in this release. Important factors that could cause results to differ materially from the statements herein include the following: general economic risks, including those caused by economic challenges, a possible economic downturn or recession and the effects of inflation or

[0001262039-25-000007:8k_2_02:80]
Non-GAAP Financial Measures

[0001262039-25-000007:8k_2_02:81]
We have provided in this release financial information that has not been prepared in accordance with U.S. Generally Accepted Accounting Principles (“GAAP”). These non-GAAP financial and liquidity measures are not based on any standardized methodology prescribed by GAAP and are not necessarily comparable to similar measures presented by other companies. We use these non-GAAP financial measures internally in analyzing our financial results and believe they are useful to investors, as a supplement to GAAP measures, in evaluating our ongoing operational performance. We believe that the use of these non-GAAP financial measures provides an additional tool for investors to use in evaluating ongoing operating results and trends and in comparing our financial results with peer companies, many of which present similar non-GAAP financial measures to investors.

[0001262039-25-000007:8k_2_02:82]
Non-GAAP financial measures should not be considered in isolation from, or as a substitute for, financial information prepared in accordance with GAAP. Investors are encouraged to review the reconciliation of these non-GAAP financial measures to their most directly comparable GAAP financial measures provided in the financial statement tables below.

[0001262039-25-000007:8k_2_02:83]
Billings (non-GAAP). We define billings as revenue recognized in accordance with GAAP plus the change in deferred revenue from the beginning to the end of the period less any deferred revenue balances acquired from business combination(s) during the period. We consider billings to be a useful metric for management and investors because billings drive current and future revenue, which is an important indicator of the health and viability of our business. There are a number of limitations related to the use of billings instead of GAAP revenue. First, billings include amounts that have not yet been recognized as revenue and are impacted by the term of security and support agreements. Second, we may calculate billings in a manner that is different from peer companies that report similar financial measures. Management accounts for these limitations by providing specific information regarding GAAP revenue and evaluating billings together with GAAP revenue.

[0001262039-25-000007:8k_2_02:84]
Free cash flow (non-GAAP). We define free cash flow as net cash provided by operating activities minus purchases of property and equipment. We believe free cash flow to be a liquidity measure that provides useful information to management and investors about the amount of cash generated by the business that, after capital expenditures, can be used for strategic opportunities, including repurchasing outstanding common stock, investing in our business, making strategic acquisitions and strengthening the balance sheet. A limitation of using free cash flow rather than the GAAP measures of cash provided by or used in operating activities, investing activities, and financing activities is that free cash flow does not represent the total increase or decrease in the cash and cash equivalents balance for the period because it excludes investing activities other than capital expenditures and cash flows from financing activities. Management accounts for this limitation by providing information about our capital expenditures and other investing and financing activities on the face of the cash flow statement and under the caption “Management’s Discussion and Analysis of Financial Condition and Results of Operations—Liquidity and Capital Resources” in our most recent Quarterly Report on Form 10-Q and Annual Report on Form 10-K and by presenting cash flows from investing and financing activities in our reconciliation of free cash flow. In addition, it is important to note that other companies, including companies in our industry, may not use free cash flow, may calculate free cash flow in a different manner than we do or may use other financial measures to evaluate their performance, all of which could reduce the usefulness of free cash flow as a comparative measure.

[0001262039-25-000007:8k_2_02:85]
Non-GAAP operating income and operating margin. We define non-GAAP operating income as operating income plus stock-based compensation, amortization of acquired intangible assets and charges in connection with litigation settlement, less gain on intellectual property matter and, when applicable, other significant non-recurring items in a given quarter. Non-GAAP operating margin is defined as non-GAAP operating income divided by GAAP revenue. We consider these non-GAAP financial measures to be useful metrics for management and investors because they exclude the items noted above so that our management and investors can compare our recurring core business operating results over multiple periods. There are a number of limitations related to the use of non-GAAP operating income instead of operating income calculated in accordance with GAAP. First, non-GAAP operating income excludes the items noted above. Second, the components of the costs that we exclude from our calculation of non-GAAP operating income may differ from the components that peer companies exclude when they report their non-GAAP results of operations. Management accounts for these limitations by providing specific information regarding the GAAP amounts excluded from non-GAAP operating income and evaluating non-GAAP operating income together with operating income calculated in accordance with GAAP.

[0001262039-25-000007:8k_2_02:86]
Non-GAAP net income and diluted net income per share. We define non-GAAP net income as net income plus the items noted above under non-GAAP operating income and operating margin. In addition, we adjust non-GAAP net income and diluted net income per share for a gain on bargain purchase related to acquisition, a non-cash charge of impairment on an equity method investment and a tax adjustment required for an effective tax rate on a non-GAAP basis, which differs from the GAAP effective tax rate. We define non-GAAP diluted net income per share as non-GAAP net income divided by the non-GAAP diluted weighted-average shares outstanding. We consider these non-GAAP financial measures to be useful metrics for management and investors for the same reasons that we use non-GAAP operating income and non-GAAP operating margin. However, in order to provide a more complete picture of our recurring core business operating results, we include in non-GAAP net income and non-GAAP diluted net income per share, the tax adjustment required resulting in an effective tax rate on a non-GAAP basis, which often differs from the GAAP tax rate. We believe the non-GAAP effective tax rates we use are reasonable estimates of normalized tax rates for our current and prior fiscal years under our global operating structure. The same limitations described above regarding our use of non-GAAP operating income and non-GAAP operating margin apply to our use of non-GAAP net income and non-GAAP diluted net income per share. We account for these limitations by providing specific information regarding the GAAP amounts excluded from non-GAAP net income and non-GAAP diluted net income per share and evaluating non-GAAP net income and non-GAAP diluted net income per share together with net income and diluted net income per share calculated in accordance with GAAP.

[0001262039-25-000007:8k_2_02:87]
FORTINET, INC.

[0001262039-25-000007:8k_2_02:88]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001262039-25-000007:8k_2_02:89]
(Unaudited, in millions)

[0001262039-25-000007:8k_2_02:90]
|  | December 31,2024 |  | December 31,2023 |
| ASSETS |  |  |  |
| CURRENT ASSETS: |  |  |  |
| Cash and cash equivalents | $ | 2,875.9 |  |  | $ | 1,397.9 |  |
| Short-term investments | 1,126.4 |  |  | 1,021.5 |  |
| Marketable equity securities | 64.2 |  |  | 21.0 |  |
| Accounts receivable—net | 1,463.4 |  |  | 1,402.0 |  |
| Inventory | 315.5 |  |  | 484.8 |  |
| Prepaid expenses and other current assets | 126.1 |  |  | 101.1 |  |
| Total current assets | 5,971.5 |  |  | 4,428.3 |  |
| PROPERTY AND EQUIPMENT—NET | 1,349.5 |  |  | 1,044.4 |  |
| DEFERRED CONTRACT COSTS | 622.9 |  |  | 605.6 |  |
| DEFERRED TAX ASSETS | 1,335.6 |  |  | 868.8 |  |
| GOODWILL AND OTHER INTANGIBLE ASSETS—NET | 350.4 |  |  | 161.8 |  |
| OTHER ASSETS | 133.2 |  |  | 150.0 |  |
| TOTAL ASSETS | $ | 9,763.1 |  |  | $ | 7,258.9 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY (DEFICIT) |  |  |  |
| CURRENT LIABILITIES: |  |  |  |
| Accounts payable | $ | 190.9 |  |  | $ | 204.3 |  |
| Accrued liabilities | 337.9 |  |  | 423.7 |  |
| Accrued payroll and compensation | 255.7 |  |  | 242.3 |  |
| Deferred revenue | 3,276.2 |  |  | 2,848.7 |  |
| Total current liabilities | 4,060.7 |  |  | 3,719.0 |  |
| DEFERRED REVENUE | 3,084.7 |  |  | 2,886.3 |  |
| LONG-TERM DEBT | 994.3 |  |  | 992.3 |  |
| OTHER LIABILITIES | 129.6 |  |  | 124.7 |  |
| Total liabilities | 8,269.3 |  |  | 7,722.3 |  |
| COMMITMENTS AND CONTINGENCIES |  |  |  |
| STOCKHOLDERS’ EQUITY (DEFICIT): |  |  |  |
| Common stock | 0.8 |  |  | 0.8 |  |
| Additional paid-in capital | 1,636.2 |  |  | 1,416.4 |  |
| Accumulated other comprehensive loss | (26.1) |  |  | (18.9) |  |
| Accumulated deficit | (117.1) |  |  | (1,861.7) |  |
| Total stockholders’ equity (deficit) | 1,493.8 |  |  | (463.4) |  |
| TOTAL LIABILITIES AND STOCKHOLDERS’ EQUITY (DEFICIT) | $ | 9,763.1 |  |  | $ | 7,258.9 |  |

[0001262039-25-000007:8k_2_02:91]
FORTINET, INC.

[0001262039-25-000007:8k_2_02:92]
CONDENSED CONSOLIDATED STATEMENTS OF INCOME

[0001262039-25-000007:8k_2_02:93]
(Unaudited, in millions, except per share amounts)

[0001262039-25-000007:8k_2_02:94]
|  | Three Months Ended |  | Year Ended |
|  | December 31,2024 |  | December 31,2023 |  | December 31,2024 |  | December 31,2023 |
| REVENUE: |  |  |  |  |  |  |  |
| Product | $ | 574.0 |  |  | $ | 488.1 |  |  | $ | 1,908.7 |  |  | $ | 1,927.3 |  |
| Service | 1,086.1 |  |  | 927.0 |  |  | 4,047.1 |  |  | 3,377.5 |  |
| Total revenue | 1,660.1 |  |  | 1,415.1 |  |  | 5,955.8 |  |  | 5,304.8 |  |
| COST OF REVENUE: |  |  |  |  |  |  |  |
| Product | 178.0 |  |  | 197.2 |  |  | 652.0 |  |  | 763.6 |  |
| Service | 136.5 |  |  | 118.7 |  |  | 505.6 |  |  | 473.6 |  |
| Total cost of revenue | 314.5 |  |  | 315.9 |  |  | 1,157.6 |  |  | 1,237.2 |  |
| GROSS PROFIT: |  |  |  |  |  |  |  |
| Product | 396.0 |  |  | 290.9 |  |  | 1,256.7 |  |  | 1,163.7 |  |
| Service | 949.6 |  |  | 808.3 |  |  | 3,541.5 |  |  | 2,903.9 |  |
| Total gross profit | 1,345.6 |  |  | 1,099.2 |  |  | 4,798.2 |  |  | 4,067.6 |  |
| OPERATING EXPENSES: |  |  |  |  |  |  |  |
| Research and development | 191.1 |  |  | 152.5 |  |  | 716.8 |  |  | 613.8 |  |
| Sales and marketing | 526.5 |  |  | 507.4 |  |  | 2,044.8 |  |  | 2,006.0 |  |
| General and administrative | 55.1 |  |  | 55.1 |  |  | 237.8 |  |  | 211.3 |  |
| Gain on intellectual property matter | (1.2) |  |  | (1.2) |  |  | (4.6) |  |  | (4.6) |  |
| Total operating expenses | 771.5 |  |  | 713.8 |  |  | 2,994.8 |  |  | 2,826.5 |  |
| OPERATING INCOME | 574.1 |  |  | 385.4 |  |  | 1,803.4 |  |  | 1,241.1 |  |
| INTEREST INCOME | 42.3 |  |  | 30.5 |  |  | 155.2 |  |  | 119.7 |  |
| INTEREST EXPENSE | (4.9) |  |  | (5.4) |  |  | (20.0) |  |  | (21.0) |  |
| GAIN ON BARGAIN PURCHASE | — |  |  | — |  |  | 106.3 |  |  | — |  |
| OTHER INCOME (EXPENSE)—NET | 6.9 |  |  | 5.1 |  |  | 13.6 |  |  | (6.1) |  |
| INCOME BEFORE INCOME TAXES AND LOSS FROM EQUITY METHOD INVESTMENTS | 618.4 |  |  | 415.6 |  |  | 2,058.5 |  |  | 1,333.7 |  |
| PROVISION FOR INCOME TAXES | 86.7 |  |  | 95.2 |  |  | 283.9 |  |  | 143.8 |  |
| LOSS FROM EQUITY METHOD INVESTMENTS | (5.5) |  |  | (9.5) |  |  | (29.4) |  |  | (42.1) |  |
| NET INCOME | $ | 526.2 |  |  | $ | 310.9 |  |  | $ | 1,745.2 |  |  | $ | 1,147.8 |  |
| Net income per share: |  |  |  |  |  |  |  |
| Basic | $ | 0.69 |  |  | $ | 0.41 |  |  | $ | 2.28 |  |  | $ | 1.47 |  |
| Diluted | $ | 0.68 |  |  | $ | 0.40 |  |  | $ | 2.26 |  |  | $ | 1.46 |  |
| Weighted-average shares outstanding: |  |  |  |  |  |  |  |
| Basic | 766.5 |  |  | 764.9 |  |  | 764.4 |  |  | 778.6 |  |
| Diluted | 775.2 |  |  | 772.3 |  |  | 771.9 |  |  | 788.2 |  |

[0001262039-25-000007:8k_2_02:95]
FORTINET, INC.

[0001262039-25-000007:8k_2_02:96]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001262039-25-000007:8k_2_02:97]
(Unaudited, in millions)

[0001262039-25-000007:8k_2_02:98]
|  | Year Ended |
|  | December 31,2024 |  | December 31,2023 |
| CASH FLOWS FROM OPERATING ACTIVITIES: |  |  |  |
| Net income | $ | 1,745.2 |  |  | $ | 1,147.8 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |
| Stock-based compensation | 257.9 |  |  | 249.0 |  |
| Amortization of deferred contract costs | 293.7 |  |  | 266.3 |  |
| Depreciation and amortization | 122.8 |  |  | 113.4 |  |
| Amortization of investment discounts | (48.8) |  |  | (27.7) |  |
| Loss from equity method investments | 29.4 |  |  | 42.1 |  |
| Gain on bargain purchase | (106.3) |  |  | — |  |
| Other | (15.2) |  |  | 18.5 |  |
| Changes in operating assets and liabilities, net of impact of business combinations: |  |  |  |
| Accounts receivable—net | (45.4) |  |  | (146.4) |  |
| Inventory | 131.2 |  |  | (253.5) |  |
| Prepaid expenses and other current assets | (13.7) |  |  | (27.6) |  |
| Deferred contract costs | (311.1) |  |  | (353.5) |  |
| Deferred tax assets | (223.2) |  |  | (301.9) |  |
| Other assets | (11.0) |  |  | 17.7 |  |
| Accounts payable | (10.2) |  |  | (43.1) |  |
| Accrued liabilities | (106.7) |  |  | 137.4 |  |
| Accrued payroll and compensation | — |  |  | 23.4 |  |
| Other liabilities | (8.3) |  |  | (21.7) |  |
| Deferred revenue | 577.8 |  |  | 1,095.3 |  |
| Net cash provided by operating activities | 2,258.1 |  |  | 1,935.5 |  |
| CASH FLOWS FROM INVESTING ACTIVITIES: |  |  |  |
| Purchases of investments | (1,948.6) |  |  | (1,855.8) |  |
| Sales of investments | 0.5 |  |  | 4.0 |  |
| Maturities of investments | 1,891.7 |  |  | 1,414.8 |  |
| Purchases of property and equipment | (378.9) |  |  | (204.1) |  |
| Purchase of investment in privately held company | — |  |  | (8.5) |  |
| Payments made in connection with business combinations, net of cash acquired | (275.5) |  |  | — |  |
| Purchases of marketable equity securities | (16.7) |  |  | — |  |
| Other | 0.1 |  |  | 0.3 |  |
| Net cash used in investing activities | (727.4) |  |  | (649.3) |  |
| CASH FLOWS FROM FINANCING ACTIVITIES: |  |  |  |
| Repurchase and retirement of common stock | (0.6) |  |  | (1,500.5) |  |
| Proceeds from issuance of common stock | 63.1 |  |  | 43.8 |  |
| Taxes paid related to net share settlement of equity awards | (100.9) |  |  | (112.5) |  |
| Other | (11.7) |  |  | (1.2) |  |
| Net cash used in financing activities | (50.1) |  |  | (1,570.4) |  |
| EFFECT OF EXCHANGE RATE CHANGES ON CASH AND CASH EQUIVALENTS | (2.6) |  |  | (0.8) |  |
| NET INCREASE (DECREASE) IN CASH AND CASH EQUIVALENTS | 1,478.0 |  |  | (285.0) |  |
| CASH AND CASH EQUIVALENTS—Beginning of year | 1,397.9 |  |  | 1,682.9 |  |
| CASH AND CASH EQUIVALENTS—End of year | $ | 2,875.9 |  |  | $ | 1,397.9 |  |

[0001262039-25-000007:8k_2_02:99]
Reconciliations of non-GAAP results of operations measures to the nearest comparable GAAP measures

[0001262039-25-000007:8k_2_02:100]
(Unaudited, in millions, except per share amounts)

[0001262039-25-000007:8k_2_02:101]
Reconciliation of GAAP operating income to non-GAAP operating income, operating margin, net income and diluted net income per share

[0001262039-25-000007:8k_2_02:102]
|  | Three Months Ended |  | Year Ended |
|  | December 31,2024 |  | December 31,2023 |  | December 31,2024 |  | December 31,2023 |
| Reconciliation of non-GAAP operating income: |  |  |  |  |  |  |  |
| GAAP operating income | $ | 574.1 |  |  | $ | 385.4 |  |  | $ | 1,803.4 |  |  | $ | 1,241.1 |  |
| GAAP operating margin | 34.6 | % |  | 27.2 | % |  | 30.3 | % |  | 23.4 | % |
| Add back: |  |  |  |  |  |  |  |
| Stock‐based compensation | 66.5 |  |  | 64.0 |  |  | 260.2 |  |  | 251.6 |  |
| Amortization of acquired intangible assets | 11.5 |  |  | 5.3 |  |  | 23.1 |  |  | 18.9 |  |
| Litigation-related matter (a) | — |  |  | — |  |  | 3.2 |  |  | — |  |
| Gain on intellectual property matter | (1.2) |  |  | (1.2) |  |  | (4.6) |  |  | (4.6) |  |
| Non‐GAAP operating income | $ | 650.9 |  |  | $ | 453.5 |  |  | $ | 2,085.3 |  |  | $ | 1,507.0 |  |
| Non‐GAAP operating margin | 39.2 | % |  | 32.0 | % |  | 35.0 | % |  | 28.4 | % |
| Reconciliation of non-GAAP net income: |  |  |  |  |  |  |  |
| GAAP net income | $ | 526.2 |  |  | $ | 310.9 |  |  | $ | 1,745.2 |  |  | $ | 1,147.8 |  |
| Add back: |  |  |  |  |  |  |  |
| Stock‐based compensation | 66.5 |  |  | 64.0 |  |  | 260.2 |  |  | 251.6 |  |
| Amortization of acquired intangible assets | 11.5 |  |  | 5.3 |  |  | 23.1 |  |  | 18.9 |  |
| Litigation-related matter (a) | — |  |  | — |  |  | 3.2 |  |  | — |  |
| Gain on intellectual property matter | (1.2) |  |  | (1.2) |  |  | (4.6) |  |  | (4.6) |  |
| Gain on bargain purchase (b) | — |  |  | — |  |  | (106.3) |  |  | — |  |
| Tax adjustment (c) | (31.5) |  |  | 13.0 |  |  | (95.9) |  |  | (128.1) |  |
| Non-cash charge on equity method investment (d) | — |  |  | — |  |  | 8.0 |  |  | — |  |
| Non-GAAP net income | $ | 571.5 |  |  | $ | 392.0 |  |  | $ | 1,832.9 |  |  | $ | 1,285.6 |  |
| Non-GAAP net income per share, diluted |  |  |  |  |  |  |  |
| Non-GAAP net income | $ | 571.5 |  |  | $ | 392.0 |  |  | $ | 1,832.9 |  |  | $ | 1,285.6 |  |
| Non-GAAP shares used in diluted net income per share calculations | 775.2 |  |  | 772.3 |  |  | 771.9 |  |  | 788.2 |  |
| Non-GAAP net income per share, diluted | $ | 0.74 |  |  | $ | 0.51 |  |  | $ | 2.37 |  |  | $ | 1.63 |  |
| Reconciliation of non-GAAP net income per share, diluted |  |  |  |  |  |  |  |
| GAAP net income per share, diluted | $ | 0.68 |  |  | $ | 0.40 |  |  | $ | 2.26 |  |  | $ | 1.46 |  |
| Add back: |  |  |  |  |  |  |  |
| Non-GAAP adjustments to net income per share | 0.06 |  |  | 0.11 |  |  | 0.11 |  |  | 0.17 |  |
| Non-GAAP net income per share, diluted | $ | 0.74 |  |  | $ | 0.51 |  |  | $ | 2.37 |  |  | $ | 1.63 |  |

[0001262039-25-000007:8k_2_02:103]
(a) To exclude a $3.2 million adjustment for a litigation settlement in the three months ended September 30, 2024.

[0001262039-25-000007:8k_2_02:104]
(b) To exclude a $106.3 million gain on bargain purchase related to our acquisition of Lacework Inc in the three months ended September 30, 2024.

[0001262039-25-000007:8k_2_02:105]
(c) Non-GAAP financial information is adjusted to an effective tax rate of 17% in the three months and year ended December 31, 2024 and 2023, respectively, on a non-GAAP basis, which differs from the GAAP effective tax rate.

[0001262039-25-000007:8k_2_02:106]
(d) To exclude an $8.0 million non-cash charge of impairment on our equity method investment in Linksys.

[0001262039-25-000007:8k_2_02:107]
Reconciliation of net cash provided by operating activities to free cash flow

[0001262039-25-000007:8k_2_02:108]
|  | Three Months Ended |  | Year Ended |
|  | December 31,2024 |  | December 31,2023 |  | December 31,2024 |  | December 31,2023 |
| Net cash provided by operating activities | $ | 477.6 |  |  | $ | 191.7 |  |  | $ | 2,258.1 |  |  | $ | 1,935.5 |  |
| Less: Purchases of property and equipment | (97.6) |  |  | (26.9) |  |  | (378.9) |  |  | (204.1) |  |
| Free cash flow | $ | 380.0 |  |  | $ | 164.8 |  |  | $ | 1,879.2 |  |  | $ | 1,731.4 |  |
| Net cash used in investing activities | $ | (79.9) |  |  | $ | (71.6) |  |  | $ | (727.4) |  |  | $ | (649.3) |  |
| Net cash used in financing activities | $ | (8.8) |  |  | $ | (910.1) |  |  | $ | (50.1) |  |  | $ | (1,570.4) |  |

[0001262039-25-000007:8k_2_02:109]
Reconciliation of total revenue to total billings

[0001262039-25-000007:8k_2_02:110]
|  | Three Months Ended |  | Year Ended |
|  | December 31,2024 |  | December 31,2023 |  | December 31,2024 |  | December 31,2023 |
| Total revenue | $ | 1,660.1 |  |  | $ | 1,415.1 |  |  | $ | 5,955.8 |  |  | $ | 5,304.8 |  |
| Add: Change in deferred revenue | 349.2 |  |  | 449.7 |  |  | 625.9 |  |  | 1,094.7 |  |
| Less: Deferred revenue balance acquired in business acquisitions | (6.8) |  |  | — |  |  | (49.2) |  |  | — |  |
| Total billings | $ | 2,002.5 |  |  | $ | 1,864.8 |  |  | $ | 6,532.5 |  |  | $ | 6,399.5 |  |

[0001262039-25-000007:8k_2_02:111]
| Investor Contact: |  | Media Contact: |
| Aaron Ovadia |  | Michelle Zimmermann |
| Fortinet, Inc. |  | Fortinet, Inc. |
| 408-235-7700 |  | 408-235-7700 |
| investors@fortinet.com |  | pr@fortinet.com |

## item 5.02 — body, verbatim

[0001262039-25-000007:8k_body:1]
Item 5.02 Departure of Directors or Certain Officers; Election of Directors; Appointment of Certain Officers; Compensatory Arrangements of Certain Officers.

[0001262039-25-000007:8k_body:2]
On February 4, 2025, Keith Jensen, Fortinet’s Chief Financial Officer, age 66, notified the Company that he intends to retire on May 15, 2025 after approximately 11 years of service in various roles at the Company (the “Retirement”). Following the Retirement, Mr. Jensen will continue to provide service to the Company through June 30, 2025 to support a smooth transition. The Company extends its gratitude to Mr. Jensen for his years of service on behalf of the Company. Mr. Jensen’s decision to retire was not the result of any disagreement with the Company.

[0001262039-25-000007:8k_body:3]
Effective as of and contingent upon the Retirement, the Company intends to appoint Christiane Ohlgart, age 57, to serve as Chief Financial Officer of the Company (including as its Principal Financial Officer). Ms. Ohlgart will remain as the Company’s Principal Accounting Officer.

[0001262039-25-000007:8k_body:4]
Ms. Ohlgart has served as Chief Accounting Officer of the Company since March 2024. From September 2021 to March 2024, Ms. Ohlgart served as Chief Financial Officer at IGEL Technology (“IGEL”), a secure access operating system developer. Prior to IGEL, from November 2016 to September 2021, Ms. Ohlgart served as VP Finance at the Company. Ms. Ohlgart has also previously served as SVP Finance and Treasurer at Syapse, Inc., a digital health company that delivers drug lifecycle, medical practice and medical society insights, from May 2016 to October 2016. Prior to Syapse, from August 2014 to April 2016, Ms. Ohlgart served as VP Finance of Intermedia.net, Inc., a cloud-based communication platform. Ms. Ohlgart also previously held the position of Chief Financial Officer at SAP SuccessFactors, a global provider of cloud-based human experience management software, from August 2013 to July 2014. Ms. Ohlgart holds a Master’s Degree in Computer Science and Business Administration from the Technical University of Karlsruhe.

[0001262039-25-000007:8k_body:5]
Changes to Ms. Ohlgart’s compensation, if any, as a result of her appointment as Chief Financial Officer have not yet been determined. If Ms. Ohlgart’s compensation is changed as a result of her appointment as Chief Financial Officer, the Company will file an amendment to this Form 8-K to disclose any such changes after they are determined.

[0001262039-25-000007:8k_body:6]
There are no arrangements or understandings between Ms. Ohlgart and any other persons, pursuant to which she is expected to be appointed as Chief Financial Officer, no family relationships among any of the Company’s directors or executive officers and Ms. Ohlgart, and she has no direct or indirect material interest in any transaction required to be disclosed pursuant to Item 404(a) of Regulation S-K.
