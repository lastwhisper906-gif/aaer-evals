# FTNT MD&A — 0001262039-25-000011


## mdna

[0001262039-25-000011:mdna:1]
ITEM 7.     Management’s Discussion and Analysis of Financial Condition and Results of Operations

[0001262039-25-000011:mdna:2]
•continued growth and market share gains;

[0001262039-25-000011:mdna:3]
•variability in sales in certain product and service categories from year to year and between quarters;

[0001262039-25-000011:mdna:4]
•expected impact of sales from certain products and services;

[0001262039-25-000011:mdna:5]
•increasing or decreasing inflation or stagflation, and changing interest rates in many geographies and changes in currency exchange rates and currency regulations;

[0001262039-25-000011:mdna:6]
•competition in our markets;

[0001262039-25-000011:mdna:7]
•macroeconomic, geopolitical factors and other disruption on our manufacturing or sales, including the transition in administrations, tariffs or other trade disruptions, public health issues, wars, natural disasters and economic growth;

[0001262039-25-000011:mdna:8]
•government regulation, tariffs and other policies;

[0001262039-25-000011:mdna:9]
•drivers of long-term growth and operating leverage, such as pricing of our products and services, sales productivity, pipeline and capacity, functionality, value and technology improvements in our service offerings;

[0001262039-25-000011:mdna:10]
•growing our solution sales through channel partners to businesses, service providers and government organizations, our ability to execute these sales and the complexity of providing solutions to all segments (including the increased competition and unpredictability of timing associated with sales to larger enterprises), the impact of sales to these organizations on our long-term growth, expansion and operating results, and the effectiveness of our sales organization;

[0001262039-25-000011:mdna:11]
•our ability to successfully anticipate market changes, including those related to cloud-based solutions and to sell, support and meet service level agreements related to cloud-based solutions;

[0001262039-25-000011:mdna:12]
•growth expectations for the secure networking market;

[0001262039-25-000011:mdna:13]
•supply chain constraints, component availability and other factors affecting our manufacturing capacity, delivery, cost and inventory management;

[0001262039-25-000011:mdna:14]
•forecasts of future demand and targeted inventory levels, including changing market drivers and demands;

[0001262039-25-000011:mdna:15]
•the effect of backlog from current or prior quarters, including its effect on growth of in-quarter billings and revenue;

[0001262039-25-000011:mdna:16]
•our ability to hire properly qualified and effective sales, support and engineering employees;

[0001262039-25-000011:mdna:17]
•risks and expectations related to acquisitions and equity interests in private and public companies, including integration issues related to go-to-market plans, product plans, employees of such companies, controls and processes and the acquired technology, and risks of negative impact by such acquisitions and equity investments on our financial results;

[0001262039-25-000011:mdna:18]
•trends in revenue, cost of revenue and gross margin, including expectations regarding product revenue, service revenue and inventory related charges;

[0001262039-25-000011:mdna:19]
•trends in our operating expense, including sales and marketing expense, research and development expense, general and administrative expense, and expectations regarding these expenses;

[0001262039-25-000011:mdna:20]
53

[0001262039-25-000011:mdna:21]
•expected impact of plans and strategy for the acceleration of our data center footprint and our points of presence deployment;

[0001262039-25-000011:mdna:22]
•expectations that our operating expense will increase year over year in absolute dollars during 2025;

[0001262039-25-000011:mdna:23]
•expectations that proceeds from the exercise of stock options in future years will be adversely impacted by the increased mix of restricted stock units and performance stock units versus stock options granted or a decline in our stock price;

[0001262039-25-000011:mdna:24]
•uncertain tax benefits and our effective domestic and global tax rates, the impact of interpretations of or changes to tax law, and the timing of tax payments;

[0001262039-25-000011:mdna:25]
•expectations regarding spending related to real estate assets, acquisitions and development, including data centers and points of presence, office building and warehouse investments, as well as other capital expenditures and to the impact on free cash flow and expenses;

[0001262039-25-000011:mdna:26]
•estimates of a range of 2025 spending on capital expenditures;

[0001262039-25-000011:mdna:27]
•expansions and other changes to our real property holdings and development;

[0001262039-25-000011:mdna:28]
•expected outcomes and liabilities in litigation;

[0001262039-25-000011:mdna:29]
•our intentions regarding share repurchases and the sufficiency of our existing cash, cash equivalents and investments to meet our cash needs, including our debt servicing requirements, for at least the next 12 months;

[0001262039-25-000011:mdna:30]
•other statements regarding our future operations, financial condition and prospects and business strategies; and

[0001262039-25-000011:mdna:31]
•adoption and impact of new accounting standards.

[0001262039-25-000011:mdna:32]
Business Overview

[0001262039-25-000011:mdna:33]
Fortinet is a leader in cybersecurity, driving the convergence of networking and security. Our mission is to secure people, devices and data everywhere. Our integrated platform, the Fortinet Security Fabric, spans secure networking, unified SASE and AI-driven security operations. As of December 31, 2024, our end-customers were located in over 100 countries and included enterprises across a wide variety of market verticals, including financial services, retail, healthcare and operational technology market verticals, communication and security service providers, and government organizations. As of December 31, 2024, our customers included approximately 80% of the Fortune 100 companies and approximately 72% of the Global 2000 companies. We were also ranked #7 in the Forbes Most Trusted Companies list in 2024. As a global company headquartered in Sunnyvale, California, our research and development is centered in the United States and Canada with a global footprint of support and centers of excellence around the world. As of December 31, 2024, we held 1,034 U.S. patents and 1,378 global patents and we have been recognized in over 140 enterprise analyst reports demonstrating both our vision and execution across security and networking products.

[0001262039-25-000011:mdna:34]
Our competitive differentiation lies in our core technologies, which together provide performance, security, flexibility and integration across diverse environments.

[0001262039-25-000011:mdna:35]
•FortiOS—FortiOS enables the convergence of security and networking to enforce consistent security policies across form factors and edges. As the foundation of the Fortinet Security Fabric, FortiOS empowers organizations to unify management and analytics for comprehensive network visibility and control at scale. To further validate our strategy,

[0001262039-25-000011:mdna:36]
FortiOS has been recognized across five Gartner Magic Quadrants, including Firewall, SD-WAN, SSE, SASE Platforms and Wired and Wireless LAN.

[0001262039-25-000011:mdna:37]
•FortiASIC—Our ASIC-based SPUs increase the speed, scale, efficiency and value of our solutions while improving user experience, reducing footprint and power requirements. From branch and campus to data center solutions, SPU-powered Fortinet appliances deliver superior Security Compute Ratings versus industry alternatives.

[0001262039-25-000011:mdna:38]
•FortiCloud—Our organically built global cloud infrastructure, powered by FortiStack, which is our SaaS platform operating as a private cloud service provider and leveraging software and hardware to optimize and secure all layers, provides customers with global reach, flexible connectivity, and cost savings.

[0001262039-25-000011:mdna:39]
•FortiAI—Our AI innovations encompass generative AI, big data AI for threat intelligence to process and analyze trillions of events using AI/ML, network operations AI for self-healing networks and automated network orchestration, automation and response, and AI for LLM leakage to protection against data leakage into LLMs. Our GenAI assists security teams to make better decisions, rapidly respond to threats and save time on even the most complex tasks. FortiAI is seamlessly integrated into the user experience of several of our products, including FortiAnalyzer, FortiSIEM and FortiSOAR, to help optimize threat investigation and response, SIEM queries, SOAR playbook creation, among other functions.

[0001262039-25-000011:mdna:40]
•FortiEndpoint—FortiEndpoint converges secure connectivity, endpoint protection and advanced capabilities like endpoint detection and response and XDR, into a single agent. It simplifies management and enhances visibility while reducing costs and complexity. The solution gives IT teams the visibility and control they need, while security teams benefit from automated threat detection and response. This minimizes the need for manual intervention and provides faster remediation of threats across all environments.

[0001262039-25-000011:mdna:41]
•OT Security—The Fortinet Security Fabric enables security for converged IT/OT ecosystems. It also provides an OT Security Platform with features and products to extend Security Fabric capabilities to OT networks in factories, plants, remote locations and ships. To help alleviate security risks across the organization, we have continued to enhance our OT Security Platform offerings. These innovations range from edge products to NOC and SOC tools and services to provide effective and efficient networking and cybersecurity performance and operation.

[0001262039-25-000011:mdna:42]
These competitive differentiators allow us to provide CIOs, CISOs, CTOs, and their organizations with an integrated AI-driven cybersecurity platform with over 50 products across three solution pillars.

[0001262039-25-000011:mdna:43]
•Secure Networking—Our Secure Networking solutions focus on the convergence of networking and security via FortiOS, our networking and security operating system that is the foundation of our Fortinet Security Fabric platform and supports over 30 functions that can be delivered via a physical, virtual, cloud or SaaS solution. When delivered through our network firewall appliances, functionality is accelerated through our proprietary ASIC technology. These proprietary ASICs, allow our systems to scale, run multiple applications at higher performance, lower power consumption and perform more processor-intensive operations, such as inspecting encrypted traffic, including streaming video. Our network firewall offerings consist of a FortiGate data center, hyperscale and distributed firewalls, as well as encrypted applications (SSL inspection, virtual private network and IPsec connectivity). Our ability to converge networking and security also enables the ethernet to become an extension of our customers’ security infrastructure through FortiSwitch and FortiLink. Our wireless LAN solution leverages secure networking to provide secure wireless access for the enterprise LAN edge. FortiExtender secures 5G/LTE and remote ethernet extenders to connect and secure any branch environment. Our Secure Connectivity solution includes FortiSwitch secure ethernet switches, FortiAP wireless local area network access points and FortiExtender 5G connectivity gateways.

[0001262039-25-000011:mdna:44]
•Unified Secure Access Service Edge (SASE)—As applications move to the cloud and hybrid workforce is now the norm, enabling secure access for users with zero trust framework becomes important. The Fortinet Unified SASE solution includes a single-vendor SASE solution that includes firewall, SD-WAN, secure web gateway, cloud access services broker, DLP and zero trust network access to deliver flexible secure access for all users. We are one of the few vendors to deliver consistent convergence and AI-powered security across Secure SD-WAN and SSE to enable a single-vendor SASE framework with a cloud-centric architecture powered by FortiOS. Our global and scalable cloud network includes 150+ points of presence to deliver the seamless secure access experience. Given this, we are well positioned to support customers expanding from SD-WAN to a single-vendor SASE platform. Additionally, we offer a full suite of comprehensive, integrated cloud security solutions that enable customers to secure their applications from code to cloud. Our solutions include application security that includes our web application firewalls, cloud network security with virtualized firewalls and cloud-native firewalls, cloud-native application protection and code security. We deliver a holistic approach to cloud security, offering a single unified platform for cloud security and secure CI/CD application development needs, consolidating protection across multiple disparate tools, including coding, deploying, and running applications across hybrid and multi-clouds, and delivering AI-driven security across integrated solutions

[0001262039-25-000011:mdna:45]
with visibility and context across hybrid and multi-cloud. Additionally, we also offer flexible consumption licensing programs that enable organizations to dynamically optimize their cloud security needs and investments as well as readily meet their cloud minimum spend commitment obligations with Cloud Service Providers.

[0001262039-25-000011:mdna:46]
•AI-Driven Security Operations (SecOps)—Our AI-Driven SecOps portfolio provides a comprehensive suite of cybersecurity solutions that identify, protect, detect, respond and recover from threats, all integrated within the Fortinet Security Fabric. At the core is FortiAnalyzer, which serves as the central SOC platform with its unified data lake that provides built-in SIEM, SOAR, XDR and threat intelligence, enabling centralized visibility, analytics and automation with complete control. FortiSIEM delivers robust security information and event management for more advanced SOC requirements, while FortiSOAR enables automated orchestration and playbook-driven response. This solution set also includes FortiEDR, FortiXDR, FortiNDR, FortiSandbox, FortiDeceptor, FortiDLP and FortiRecon, helping organizations achieve defense in depth, ensuring attackers face multiple layers of detection and mitigation across endpoints, networks, and applications. To bolster their security posture, organizations contending with staff shortages can tap into FortiGuard services, including SOCaaS, MDR, Security Posture Assessment and Incident Response. Finally, FortiAI generative AI assistance streamlines operations, helping security teams stay ahead of an ever-evolving threat landscape.

[0001262039-25-000011:mdna:47]
FortiGuard Labs is our cybersecurity threat intelligence and research organization comprised of experienced threat hunters, researchers, analysts, engineers and data scientists who develop and utilize machine learning and AI technologies to provide timely protection updates and actionable threat intelligence for the benefit of our customers. Using millions of global network sensors, FortiGuard Labs monitors the worldwide attack surface and employs AI to mine that data for new threats.

[0001262039-25-000011:mdna:48]
FortiGuard and Other Security Services are a suite of AI-powered security capabilities that are natively integrated as part of the Fortinet Security Fabric to deliver coordinated detection and enforcement across the entire attack surface. The portfolio consists of FortiGuard application security services, content security services, device security services, NOC/SOC security services and web security services.

[0001262039-25-000011:mdna:49]
FortiCare Technical Support Service is a per-device technical support service, which provides customers access to experts to ensure efficient and effective operations and maintenance of their Fortinet capabilities. Global technical support is offered 24x7 with flexible add-ons, including enhanced SLAs and priority hardware replacement through in-country and local depots. Organizations have the flexibility to procure different levels of service for different devices based on their availability needs. We offer three per-device support options tailored to the needs of our enterprise customers: FortiCare Elite, FortiCare Premium and FortiCare Essential. The FortiCare Elite service aims to provide a 15-minute response time for key product families.

[0001262039-25-000011:mdna:50]
In addition to FortiCare device level services, Advanced Support service options are available per account. These services are available for regional account support in three options: Core, Pro and Pro Plus, and can be globalized at the Pro and Pro Plus levels. Advanced Support brings support directly to each account, helping account holders to make their operations more effective and to plan and manage their solution lifecycle.

[0001262039-25-000011:mdna:51]
Additionally, we are committed to addressing the cybersecurity skills shortage through training and certification programs for customers, partners and employees. The Fortinet Training Institute’s ecosystem of public and private partnerships around the world extend to industry, academia, government and nonprofits to ensure we are reaching and increasing access of our cybersecurity certifications and training to all populations. The Fortinet Training Institute has issued over one million certifications to date.

[0001262039-25-000011:mdna:52]
Financial Summary

[0001262039-25-000011:mdna:53]
•Total revenue was $5.96 billion in 2024, an increase of 12% compared to $5.30 billion in 2023.

[0001262039-25-000011:mdna:54]
•Product revenue was $1.91 billion in 2024, a decrease of 1% compared to $1.93 billion in 2023.

[0001262039-25-000011:mdna:55]
•Service revenue was $4.05 billion in 2024, an increase of 20% compared to $3.38 billion in 2023.

[0001262039-25-000011:mdna:56]
•Total gross profit was $4.80 billion in 2024, an increase of 18% compared to $4.07 billion in 2023.

[0001262039-25-000011:mdna:57]
•Total gross margin was 80.6% in 2024, an increase of 3.9 percentage points compared to 76.7% in 2023.

[0001262039-25-000011:mdna:58]
•Operating income was $1.80 billion in 2024, an increase of 45% compared to $1.24 billion in 2023.

[0001262039-25-000011:mdna:59]
•Operating margin was 30.3% in 2024, an increase of 6.9 percentage points compared to 23.4% in 2023.

[0001262039-25-000011:mdna:60]
•Cash, cash equivalents, short-term and long-term investments and marketable equity securities were $4.07 billion as of December 31, 2024, an increase of $1.63 billion, or 67%, from December 31, 2023.

[0001262039-25-000011:mdna:61]
•Deferred revenue was $6.36 billion as of December 31, 2024, an increase of $625.9 million, or 11%, from December 31, 2023. Short-term deferred revenue was $3.28 billion as of December 31, 2024, an increase of $427.5 million, or 15%, from December 31, 2023.

[0001262039-25-000011:mdna:62]
•Cash flows from operating activities were $2.26 billion in 2024, an increase of $322.6 million, or 17%, compared to 2023.

[0001262039-25-000011:mdna:63]
•On August 1, 2024, we closed our acquisition of Lacework, a privately held data-driven cloud security company. On August 5, 2024, we completed the acquisition of Next DLP, a privately held insider risk and DLP company. From August 2024 to December 2024, revenue from these two acquired companies was $33.5 million, or 0.6% of total revenue in 2024.

[0001262039-25-000011:mdna:64]
On a geographic basis, revenue continues to be diversified globally, which remains a key strength of our business. In 2024, the Americas region, the Europe, Middle East and Africa (“EMEA”) region and the Asia Pacific (“APAC”) region contributed 41%, 40% and 19% of our total revenue, respectively, and increased 12%, 16% and 6% compared to 2023, respectively.

[0001262039-25-000011:mdna:65]
Product revenue remained comparatively flat in 2024 compared to 2023. We expect product revenue growth rates to be higher in 2025 compared to 2024 which had a challenging comparison to a 2023 year benefiting from the greater backlog contribution to billings.

[0001262039-25-000011:mdna:66]
Service revenue grew 20% in 2024 compared to 2023, primarily driven by the strength of our security subscription revenue, which grew 22% in 2024 compared to 2023. The increase was primarily due to the recognition of service revenue from our growing deferred revenue balance related to FortiGuard and other security subscriptions delivered to on-premise and cloud-based environments and strength in unified SASE and SecOps. We expect our service revenue to continue to grow in 2025, with growth opportunities that include unified SASE and SecOps offerings as well as the year over year increase in current deferred revenue. While service revenue is expected to grow in 2025, we anticipate that the growth rates will continue to slow down in 2025 due to slowing short term deferred revenue growth over the past several quarters.

[0001262039-25-000011:mdna:67]
Our billings were diversified on a geographic basis. In 2024, seven countries represented approximately 50% of our billings and the remaining approximately 50% were from over 100 countries that each individually contributed less than 3% of our billings.

[0001262039-25-000011:mdna:68]
Total gross margin increased 3.9 percentage points in 2024 compared to 2023, primarily driven by increased product and service gross margin and a shift in the revenue mix to higher margin service revenue. Our overall gross margin in 2025 will be impacted by service and product revenue mix and their respective gross margins. We expect our service gross margin to decrease for full year 2025 compared to full year 2024, as we expand our data center footprint and colocation and cloud hosting capacity to support the growth in our unified SASE and SecOps offerings.

[0001262039-25-000011:mdna:69]
Operating expenses as a percentage of revenue decreased approximately 3.0 percentage points in 2024 compared to 2023, mainly because our revenue growth outpaced personnel costs. Headcount increased 4% to 14,138 employees as of December 31, 2024, up from 13,568 as of December 31, 2023. We expect our operating expenses as a percentage of revenue to increase for full year 2025 compared to full year 2024 as we expand our workforce organically and through acquisitions.

[0001262039-25-000011:mdna:70]
Operating margin increased 6.9 percentage points in 2024 as a result of improvement in gross margin and decrease in operating expenses as a percentage of revenue. We expect our operating margin to decrease for full year 2025 compared to full year 2024 as we grow our sales and marketing, and research and development workforce organically and through acquisitions, increase our product development investments, and expand our data center footprint and our colocation and cloud hosting capacity to support business growth.

[0001262039-25-000011:mdna:71]
Impact of Macroeconomic and Geopolitical Developments

[0001262039-25-000011:mdna:72]
Our overall performance depends in part on worldwide economic and geopolitical conditions, such as GDP growth, the war in Ukraine or tensions between China and Taiwan, and their impact on customer behavior. Worsening economic conditions, including inflation, changing interest rates, tariffs and other trade disruptions, slower growth, any recession, fluctuations in foreign exchange rates and other changes in economic conditions, may result in decreased sales productivity and

[0001262039-25-000011:mdna:73]
growth and adversely affect our results of operations and financial performance. We have seen certain impacts on our business, results of operations, financial condition, cash flows, liquidity and capital and financial resources such as longer sales cycles, delayed purchases and increased commitments with certain suppliers and increased inventory and inventory purchase commitment reserves.

[0001262039-25-000011:mdna:74]
Worsening economic conditions may have a material negative impact on our results in future periods and may negatively impact our billings, revenue and costs, and may decrease growth and profitability. The extent of the impact of economic conditions on our operational and financial performance will depend on ongoing developments, including those discussed above and others identified in Part I, Item 1A “Risk Factors” in this Form 10-K. Given the dynamic nature of these circumstances, the full impact of worsening economic conditions on our business and operations, results of operations, financial condition, cash flows, liquidity and capital and financial resources cannot be reasonably estimated at this time.

[0001262039-25-000011:mdna:75]
Business Model

[0001262039-25-000011:mdna:76]
We typically sell our security solutions to distributors that sell to networking security focused resellers and to certain service providers and managed security service providers, who, in turn, sell to end-customers or use our products and services to provide hosted solutions to other enterprises. At times, we also sell directly to enterprise customers, service providers, systems integrators and large enterprises. We also sell our software licenses and cloud delivered services via different cloud service provider platforms, both directly and through our channel partners. Our end-customers are located in over 100 countries and include small, medium and large enterprises and government organizations across a wide range of industries, including financial services, government, healthcare, manufacturing, retail, technology and telecommunications. An end-customer deployment may involve as few as one or as many as thousands of secure networking, unified SASE and security operations technology products or users, depending on the end-customer’s size and security requirements.

[0001262039-25-000011:mdna:77]
Our customers purchase our hardware products, software licenses and cloud-delivered solutions, including our FortiGuard and other security subscriptions, FortiCare technical support services, certain unified SASE and SecOps services. We generally invoice at the time of our sale for the total price of the products and services. Standard payment terms are generally no more than 60 days, though we may offer extended payment terms to certain distributors or large enterprises.

[0001262039-25-000011:mdna:78]
We offer our products hosted in our own data centers, PoPs and through colocations and major cloud service providers, including Amazon Web Services, Microsoft Azure and Google Cloud.

[0001262039-25-000011:mdna:79]
Key Metrics

[0001262039-25-000011:mdna:80]
We monitor several key metrics, including the key financial metrics set forth below, in order to help us evaluate growth trends, establish budgets, measure the effectiveness of our sales and marketing efforts, and assess operational efficiencies. The following table summarizes revenue, deferred revenue, billings (non-GAAP), net cash provided by operating activities, and free cash flow (non-GAAP). We discuss revenue below under “—Components of Operating Results,” and we discuss net cash provided by operating activities below under “—Liquidity and Capital Resources.” Deferred revenue, billings (non-GAAP), and free cash flow (non-GAAP) are discussed immediately below the following table.

[0001262039-25-000011:mdna:81]
|  | Year Ended or As of December 31, |
|  | 2024 |  | 2023 |  | 2022 |
|  | (in millions) |
| Revenue | $ | 5,955.8 |  |  | $ | 5,304.8 |  |  | $ | 4,417.4 |  |
| Deferred revenue | $ | 6,360.9 |  |  | $ | 5,735.0 |  |  | $ | 4,640.3 |  |
| Billings (non-GAAP) | $ | 6,532.5 |  |  | $ | 6,399.5 |  |  | $ | 5,594.0 |  |
| Net cash provided by operating activities | $ | 2,258.1 |  |  | $ | 1,935.5 |  |  | $ | 1,730.6 |  |
| Free cash flow (non-GAAP) | $ | 1,879.2 |  |  | $ | 1,731.4 |  |  | $ | 1,449.4 |  |

[0001262039-25-000011:mdna:82]
Deferred revenue. Our deferred revenue consists of amounts that have been invoiced but that have not yet been recognized as revenue. The majority of our deferred revenue balance consists of the unrecognized portion of service revenue from FortiGuard and other security subscriptions and FortiCare technical support service contracts, which is recognized as revenue ratably over the service term. We monitor our deferred revenue balance, short term and total deferred revenue growth and the mix of short-term and long-term deferred revenue because deferred revenue represents a significant portion of free cash flow and of revenue to be recognized in future periods. Deferred revenue was $6.36 billion as of December 31, 2024, an increase of $625.9 million, or 11%, from December 31, 2023. Short term deferred revenue was $3.28 billion as of December 31, 2024, an increase of $427.5 million, or 15%, from December 31, 2023.

[0001262039-25-000011:mdna:83]
Billings (non-GAAP). We define billings as revenue recognized in accordance with generally accepted accounting principles in the United States (“GAAP”) plus the change in deferred revenue from the beginning to the end of the period less any deferred revenue balances acquired from business combination(s) during the period. We consider billings to be a useful metric for management and investors because billings drive current and future revenue, which is an important indicator of the health and viability of our business and cash flows. There are a number of limitations related to the use of billings instead of GAAP revenue. First, billings include amounts that have not yet been recognized as revenue and are impacted by the term of security and support agreements. Second, we may calculate billings in a manner that is different from peer companies that report similar financial measures. Management accounts for these limitations by providing specific information regarding GAAP revenue and evaluating billings together with GAAP revenue. Total billings were $6.53 billion in 2024, an increase of 2% compared to $6.40 billion in 2023.

[0001262039-25-000011:mdna:84]
Our backlog may fluctuate over quarters. A reduction to backlog increases our aggregate billings and revenue during the quarter when delivered. If we experience supply chain shortages and cannot fulfill orders or if customers cancel or delay delivery of orders, our backlog may be affected, which will negatively impact our aggregate backlog to billings conversion and revenue in such quarter, and as the supply chain challenges normalized, our product revenue growth rate may be lower versus prior quarters where delivery from backlog contributed more to billings.

[0001262039-25-000011:mdna:85]
A reconciliation of revenue, the most directly comparable financial measure calculated and presented in accordance with GAAP, to billings is provided below:

[0001262039-25-000011:mdna:86]
|  | Year Ended December 31, |
| 2024 |  | 2023 |  | 2022 |
| (in millions) |
| Billings: |  |  |  |  |  |
| Revenue | $ | 5,955.8 |  |  | $ | 5,304.8 |  |  | $ | 4,417.4 |  |
| Add: Change in deferred revenue | 625.9 |  |  | 1,094.7 |  |  | 1,187.4 |  |
| Less: Deferred revenue balance acquired in business combinations | (49.2) |  |  | — |  |  | (10.8) |  |
| Total billings (non-GAAP) | $ | 6,532.5 |  |  | $ | 6,399.5 |  |  | $ | 5,594.0 |  |

[0001262039-25-000011:mdna:87]
Free cash flow (non-GAAP). We define free cash flow as net cash provided by operating activities minus purchases of property and equipment. We believe free cash flow to be a liquidity measure that provides useful information to management and investors about the amount of cash generated by the business that, after capital expenditures, can be used for strategic opportunities, including repurchasing outstanding common stock, investing in our business, making strategic acquisitions and strengthening the balance sheet. A limitation of using free cash flow rather than the GAAP measures of cash provided by or used in operating activities, investing activities, and financing activities is that free cash flow does not represent the total increase or decrease in the cash and cash equivalents balance for the period because it excludes investing activities other than capital expenditures and cash flows from financing activities. Management accounts for this limitation by providing information about our capital expenditures and other investing and financing activities on the consolidated statements of cash flows and under “—Liquidity and Capital Resources” and by presenting cash flows from investing and financing activities in our reconciliation of free cash flow. In addition, it is important to note that other companies, including companies in our industry, may not use free cash flow, may calculate free cash flow in a different manner than we do or may use other financial measures to evaluate their performance, all of which could reduce the usefulness of free cash flow as a comparative measure. A reconciliation of net cash provided by operating activities, the most directly comparable financial measure calculated and presented in accordance with GAAP, to free cash flow is provided below:

[0001262039-25-000011:mdna:88]
|  | Year Ended December 31, |
| 2024 |  | 2023 |  | 2022 |
| (in millions) |
| Free Cash Flow: |  |  |  |  |  |
| Net cash provided by operating activities | $ | 2,258.1 |  |  | $ | 1,935.5 |  |  | $ | 1,730.6 |  |
| Less: Purchases of property and equipment | (378.9) |  |  | (204.1) |  |  | (281.2) |  |
| Free cash flow (non-GAAP) | $ | 1,879.2 |  |  | $ | 1,731.4 |  |  | $ | 1,449.4 |  |
| Net cash provided by (used in) investing activities | $ | (727.4) |  |  | $ | (649.3) |  |  | $ | 763.9 |  |
| Net cash used in financing activities | $ | (50.1) |  |  | $ | (1,570.4) |  |  | $ | (2,130.3) |  |

[0001262039-25-000011:mdna:89]
59

[0001262039-25-000011:mdna:90]
Components of Operating Results

[0001262039-25-000011:mdna:91]
Revenue. We generate the majority of our revenue from sales of our hardware and software products and amortization of amounts included in deferred revenue related to previous sales of FortiGuard and other security subscriptions and FortiCare technical support services. We also recognize revenue from cloud security solutions, professional services, and training.

[0001262039-25-000011:mdna:92]
Our total revenue is comprised of:

[0001262039-25-000011:mdna:93]
•Product revenue. Product revenue is primarily generated from sales of our physical and virtual machine appliances. The majority of our product revenue continues to be generated by our secure networking product lines. Product revenue also includes revenue from sales of unified SASE and SecOps software technologies. As a percentage of total revenue, our product revenue has varied from quarter to quarter.

[0001262039-25-000011:mdna:94]
•Service revenue. Service revenue is generated primarily from FortiGuard and other security subscription services and FortiCare technical support services. We recognize revenue from FortiGuard and other security subscriptions and FortiCare technical support services ratably over the service term. Our typical contractual support and subscription term is one to five years. We also generate our revenue from other services, for which we recognize revenue as the services are provided, and cloud-based services, for which we recognize revenue as the services are delivered or on a monthly usage basis. As a percentage of total revenue, we continue to expect service revenue to be higher than product revenue. Our service revenue growth rate depends significantly on the growth of our customer base, the expansion of our service bundle offerings, the mix of our product revenue, pricing actions, the expansion and introduction of new service offerings, the attach rate of service contracts to new product sales, and the renewal of service contracts by our existing customers.

[0001262039-25-000011:mdna:95]
Our total cost of revenue is comprised of:

[0001262039-25-000011:mdna:96]
•Cost of product revenue. Cost of product revenue is primarily comprised of third-party contract manufacturers’ costs and the costs of materials used in production. Our cost of product revenue also includes supplies, shipping costs, personnel costs associated with logistics and quality control, facility-related costs, excess and obsolete inventory costs, charges related to excess inventory commitments and amortization of intangible assets. Personnel costs include compensation benefits and stock-based compensation.

[0001262039-25-000011:mdna:97]
•Cost of service revenue. Cost of service revenue is primarily comprised of personnel costs, replacement cost, data center infrastructure, software and delivery costs, colocation and cloud provider fees, facility-related costs and amortization of intangible assets.

[0001262039-25-000011:mdna:98]
Gross margin. Gross profit as a percentage of revenue, or gross margin, has been and will continue to be affected by a variety of factors, including the average sales price of our products, product costs, the mix of products sold and the mix of revenue between hardware products, software licenses and services and any excess inventory or other charges. Generally, service revenue and software licenses have higher gross margins compared to hardware products. Overall gross margin in 2025 will be impacted by service and product revenue mix and their respective gross margins.

[0001262039-25-000011:mdna:99]
Operating expenses. Our operating expenses consist of research and development, sales and marketing and general and administrative expenses. Personnel costs are the most significant component of operating expenses and consist primarily of salaries, benefits, bonuses, sales commissions and stock-based compensation. We expect personnel costs to continue to increase in absolute dollars as we expand our workforce.

[0001262039-25-000011:mdna:100]
•Research and development. Research and development expense consists primarily of personnel costs. Additional research and development expenses include ASIC and system prototypes and certification-related expenses, depreciation of property and equipment and facility-related expenses. The majority of our research and development is focused on software and hardware development. We record research and development expenses as incurred. As of December 31, 2024, approximately 79%, 7%, 5%, 3% and 3% of our research and development teams were located in North America, India, Israel, Japan and Taiwan, respectively. We do not own research and development team located in China. As of December 31, 2024, approximately two-thirds of our engineers worked on software development while the remainder worked on hardware development.

[0001262039-25-000011:mdna:101]
•Sales and marketing. Sales and marketing expense is the largest component of our operating expenses and primarily consists of personnel costs. Additional sales and marketing expenses include product marketing, public relations, field marketing and events and channel marketing programs (e.g., partner cooperative marketing arrangements), as well as travel, depreciation of property and equipment and facility-related

[0001262039-25-000011:mdna:102]
60

[0001262039-25-000011:mdna:103]
expenses. We intend to hire additional personnel focused on sales and marketing and expand our sales and marketing efforts worldwide in order to capture market share.

[0001262039-25-000011:mdna:104]
•General and administrative. General and administrative expense consists of personnel costs, as well as professional fees, depreciation of property and equipment and internal-use software and facility-related expenses. General and administrative personnel include our executive, finance, human resources, information technology and legal organizations. Our professional fees principally consist of outside legal, auditing, tax, information technology and other consulting costs.

[0001262039-25-000011:mdna:105]
Interest income. Interest income consists primarily of interest earned on our cash equivalents and investments. Historically, our interest-bearing investments include corporate debt securities, certificates of deposit and term deposits, commercial paper, money market funds, U.S. government and agency securities and municipal bonds.

[0001262039-25-000011:mdna:106]
Interest expense. Interest expense consists of interest expense due to the senior notes and other miscellaneous interest expense.

[0001262039-25-000011:mdna:107]
Other income (expense)—net. Other income (expense)—net consists primarily of foreign exchange gains and losses related to foreign currency remeasurement, gains or losses due to the changes in fair value of our marketable equity securities, realized gains and losses of available-for-sale investments, net rental income from real estate, as well as the gain on the sale or the impairment of investments in privately held companies without readily determinable fair values, which are not accounted for under the equity method.

[0001262039-25-000011:mdna:108]
Provision for income taxes. We are subject to income taxes in the United States, as well as other tax jurisdictions or countries in which we conduct business. Earnings from our non-U.S. activities are subject to income taxes in local countries and may be subject to U.S. income taxes. Our effective tax rate differs from the U.S. statutory rate primarily due to foreign income subject to different tax rates than in the U.S., federal research and development tax credit, state income taxes, withholding taxes, excess tax benefits related to stock-based compensation expense and the tax impacts of the foreign-derived intangible income (“FDII”) deduction.

[0001262039-25-000011:mdna:109]
Loss from equity method investments. Loss from equity method investments consists of our proportionate share of the investees’ net loss, the amortization of any basis differences, as well as any other-than-temporary impairment (“OTTI”) when events or circumstances suggest that the carrying amount of the investment may be impaired.

[0001262039-25-000011:mdna:110]
Critical Accounting Policies and Estimates

[0001262039-25-000011:mdna:111]
Our discussion and analysis of our financial condition and results of operations are based upon our financial statements, which have been prepared in accordance with GAAP. These principles require us to make estimates and judgments that affect the reported amounts of assets, liabilities, revenue, cost of revenue and expenses, and related disclosures. We base our estimates on historical experience and on various other assumptions that we believe to be reasonable under the circumstances. To the extent that there are material differences between these estimates and our actual results, our future financial statements will be affected.

[0001262039-25-000011:mdna:112]
We believe that, of the significant accounting policies described in Note 1 to our consolidated financial statements included in Part II, Item 8 of this Annual Report on Form 10-K, the following accounting policies involve a greater degree of judgment and complexity. Accordingly, we believe these are the most critical to fully understand and evaluate our financial condition and results of operations.

[0001262039-25-000011:mdna:113]
Revenue Recognition

[0001262039-25-000011:mdna:114]
Revenues are recognized when control of goods or services is transferred to our customers, in an amount that reflects the consideration we expect to be entitled to in exchange for those goods or services.

[0001262039-25-000011:mdna:115]
We determine revenue recognition through the following steps:

[0001262039-25-000011:mdna:116]
•identification of a contract or contracts with a customer;

[0001262039-25-000011:mdna:117]
•identification of the performance obligations in a contract, including evaluation of performance obligations as to being distinct goods or services in a contract;

[0001262039-25-000011:mdna:118]
•determination of a transaction price;

[0001262039-25-000011:mdna:119]
61

[0001262039-25-000011:mdna:120]
•allocation of a transaction price to the performance obligations in a contract; and

[0001262039-25-000011:mdna:121]
•recognition of revenue when, or as, we satisfy a performance obligation.

[0001262039-25-000011:mdna:122]
Our sales contracts typically contain multiple performance obligations, such as hardware, software license, security subscription, technical support services, cloud and other services, which are generally capable of being distinct and accounted for as separate performance obligations. Our hardware and software licenses have significant standalone functionalities and capabilities. Accordingly, the hardware and software licenses are distinct from the security subscription and technical support services, as a customer can benefit from the product without the services and the services are separately identifiable within a contract. We allocate a transaction price to each performance obligation based on relative standalone selling price. We establish standalone selling price using the prices charged for a deliverable when sold separately. If not observable through past transactions, we determine standalone selling price by considering multiple historical factors including, but not limited to, cost of products, gross margin objectives, pricing practices, geographies and the term of a service contract.

[0001262039-25-000011:mdna:123]
Deferred Contract Costs and Commission Expense

[0001262039-25-000011:mdna:124]
We defer contract costs that are recoverable and incremental to obtaining customer sales contracts. Contract costs, which primarily consist of sales commissions, are amortized on a systematic basis that is consistent with the transfer to the customer of the goods or services to which the asset relates. Costs for initial contracts that are not commensurate with commissions on renewal contracts are amortized on a straight-line basis over the period of benefit of five years. Estimates, assumptions, and judgments in accounting for deferred contract costs include, but are not limited to, identification of contract costs, anticipated billings and the expected period of benefit.

[0001262039-25-000011:mdna:125]
Business Combinations

[0001262039-25-000011:mdna:126]
We include the results of operations of the businesses that we acquire as of the respective dates of acquisition. We allocate the fair value of the purchase price of our business acquisitions to the tangible and intangible assets acquired and liabilities assumed based on their estimated fair values. The excess of the purchase price over the fair values of these identifiable assets and liabilities is recorded as goodwill. The excess of the fair values of the net assets acquired over the net purchase consideration is recorded as a gain on bargain purchase within other income, net on the consolidated statements of income. We often continue to gather additional information throughout the measurement period, and if we make changes to the amounts recorded, such changes are recorded in the period in which they are identified.

[0001262039-25-000011:mdna:127]
Contingent Liabilities

[0001262039-25-000011:mdna:128]
From time to time, we are involved in disputes, litigation and other legal actions. However, there are many uncertainties associated with any litigation, and these actions or other third-party claims against us may cause us to incur substantial settlement charges, which are inherently difficult to estimate and could adversely affect our results of operations. We periodically review significant claims and litigation matters for the probability of an adverse outcome. We accrue for a loss contingency if a loss is probable and the amount of the loss can be reasonably estimated. These accruals are generally based on a range of possible outcomes that require significant judgement. Estimates can change as individual claims develop. The actual liability in any such matters may be materially different from our estimates, which could result in the need to adjust our liability and record additional expenses.

[0001262039-25-000011:mdna:129]
Accounting for Income Taxes

[0001262039-25-000011:mdna:130]
We record income taxes using the asset and liability method, which requires the recognition of deferred tax assets and liabilities for the expected future tax consequences of events that have been recognized in our financial statements or tax returns. In addition, deferred tax assets are recorded for the future benefit of utilizing net operating losses and research and development credit carryforwards. Deferred tax assets and liabilities are measured using the currently enacted tax rates that apply to taxable income in effect for the years in which those tax assets and liabilities are expected to be realized or settled. Valuation allowances are provided when necessary to reduce deferred tax assets to the amount expected to be realized.

[0001262039-25-000011:mdna:131]
As part of the process of preparing our consolidated financial statements, we are required to estimate our taxes in each of the jurisdictions in which we operate. We estimate actual current tax exposure together with assessing temporary differences resulting from differing treatment of items, such as accruals and allowances not currently deductible for tax purposes. These differences result in deferred tax assets, which are included in our consolidated balance sheets. In general, deferred tax assets

[0001262039-25-000011:mdna:132]
represent future tax benefits to be received when certain expenses previously recognized in our consolidated statements of income become deductible expenses under applicable income tax laws, or loss or credit carryforwards are utilized.

[0001262039-25-000011:mdna:133]
In assessing the realizability of deferred tax assets, management considers whether it is more likely than not that some portion or all of the deferred tax assets will be realized. The ultimate realization of deferred tax assets is dependent upon the generation of future taxable income during the periods in which those temporary differences become deductible. We continue to assess the need for a valuation allowance on the deferred tax assets by evaluating both positive and negative evidence that may exist. Any adjustment to the valuation allowance on deferred tax assets would be recorded in the consolidated statements of income for the period that the adjustment is determined to be required.

[0001262039-25-000011:mdna:134]
We recognize tax benefits from an uncertain tax position only if it is more likely than not, based on the technical merits of the position that the tax position will be sustained on examination by the tax authorities. The tax benefits recognized in the financial statements from such positions are then measured based on the largest benefit that has a greater than 50% likelihood of being realized upon ultimate settlement.

[0001262039-25-000011:mdna:135]
We have elected to account for the tax effect of the Global Intangible Low-Taxed Income (“GILTI”) as a current period expense.

[0001262039-25-000011:mdna:136]
63

[0001262039-25-000011:mdna:137]
Results of Operations

[0001262039-25-000011:mdna:138]
The following tables set forth our results of operations for the periods presented and as a percentage of our total revenue for those periods. The period-to-period comparison of financial results is not necessarily indicative of financial results to be achieved in future periods.

[0001262039-25-000011:mdna:139]
|  | Year Ended December 31, |
|  | 2024 |  | 2023 |  | 2022 |
|  | (in millions) |
| Consolidated Statements of Income Data: |  |  |  |  |  |
| Revenue: |  |  |  |  |  |
| Product | $ | 1,908.7 |  |  | $ | 1,927.3 |  |  | $ | 1,780.5 |  |
| Service | 4,047.1 |  |  | 3,377.5 |  |  | 2,636.9 |  |
| Total revenue | 5,955.8 |  |  | 5,304.8 |  |  | 4,417.4 |  |
| Cost of revenue: |  |  |  |  |  |
| Product | 652.0 |  |  | 763.6 |  |  | 691.3 |  |
| Service | 505.6 |  |  | 473.6 |  |  | 393.6 |  |
| Total cost of revenue | 1,157.6 |  |  | 1,237.2 |  |  | 1,084.9 |  |
| Gross profit: |  |  |  |  |  |
| Product | 1,256.7 |  |  | 1,163.7 |  |  | 1,089.2 |  |
| Service | 3,541.5 |  |  | 2,903.9 |  |  | 2,243.3 |  |
| Total gross profit | 4,798.2 |  |  | 4,067.6 |  |  | 3,332.5 |  |
| Operating expenses: |  |  |  |  |  |
| Research and development | 716.8 |  |  | 613.8 |  |  | 512.4 |  |
| Sales and marketing | 2,044.8 |  |  | 2,006.0 |  |  | 1,686.1 |  |
| General and administrative | 237.8 |  |  | 211.3 |  |  | 169.0 |  |
| Gain on intellectual property matter | (4.6) |  |  | (4.6) |  |  | (4.6) |  |
| Total operating expenses | 2,994.8 |  |  | 2,826.5 |  |  | 2,362.9 |  |
| Operating income | 1,803.4 |  |  | 1,241.1 |  |  | 969.6 |  |
| Interest income | 155.2 |  |  | 119.7 |  |  | 17.4 |  |
| Interest expense | (20.0) |  |  | (21.0) |  |  | (18.0) |  |
| Gain on bargain purchase | 106.3 |  |  | — |  |  | — |  |
| Other income (expense)—net | 13.6 |  |  | (6.1) |  |  | (13.5) |  |
| Income before income taxes and loss from equity method investments | 2,058.5 |  |  | 1,333.7 |  |  | 955.5 |  |
| Provision for income taxes | 283.9 |  |  | 143.8 |  |  | 30.8 |  |
| Loss from equity method investments | (29.4) |  |  | (42.1) |  |  | (68.1) |  |
| Net income including non-controlling interests | 1,745.2 |  |  | 1,147.8 |  |  | 856.6 |  |
| Less: net loss attributable to non-controlling interests, net of tax | — |  |  | — |  |  | (0.7) |  |
| Net income attributable to Fortinet, Inc. | $ | 1,745.2 |  |  | $ | 1,147.8 |  |  | $ | 857.3 |  |

[0001262039-25-000011:mdna:140]
64

[0001262039-25-000011:mdna:141]
|  | Year Ended December 31, |
| 2024 |  | 2023 |  | 2022 |
| (as percentage of revenue) |
| Revenue: |  |  |  |  |  |
| Product | 32 | % |  | 36 | % |  | 40 | % |
| Service | 68 |  |  | 64 |  |  | 60 |  |
| Total revenue | 100 |  |  | 100 |  |  | 100 |  |
| Cost of revenue: |  |  |  |  |  |
| Product | 11 |  |  | 14 |  |  | 16 |  |
| Service | 8 |  |  | 9 |  |  | 9 |  |
| Total cost of revenue | 19 |  |  | 23 |  |  | 25 |  |
| Gross margin: |  |  |  |  |  |
| Product | 66 |  |  | 60 |  |  | 61 |  |
| Service | 88 |  |  | 86 |  |  | 85 |  |
| Total gross margin | 81 |  |  | 77 |  |  | 75 |  |
| Operating expenses: |  |  |  |  |  |
| Research and development | 12 |  |  | 12 |  |  | 12 |  |
| Sales and marketing | 34 |  |  | 38 |  |  | 38 |  |
| General and administrative | 4 |  |  | 4 |  |  | 4 |  |
| Gain on intellectual property matter | — |  |  | — |  |  | — |  |
| Total operating expenses | 50 |  |  | 53 |  |  | 53 |  |
| Operating margin | 30 |  |  | 23 |  |  | 22 |  |
| Interest income | 3 |  |  | 2 |  |  | — |  |
| Interest expense | — |  |  | — |  |  | — |  |
| Gain on bargain purchase | 2 |  |  | — |  |  | — |  |
| Other income (expense)—net | — |  |  | — |  |  | — |  |
| Income before income taxes and loss from equity method investments | 35 |  |  | 25 |  |  | 22 |  |
| Provision for income taxes | 5 |  |  | 3 |  |  | 1 |  |
| Loss from equity method investments | — |  |  | (1) |  |  | (2) |  |
| Net income including non-controlling interests | 29 |  |  | 22 |  |  | 19 |  |
| Less: net loss attributable to non-controlling interests, net of tax | — |  |  | — |  |  | — |  |
| Net income attributable to Fortinet, Inc. | 29 | % |  | 22 | % |  | 19 | % |
| Percentages have been rounded for presentation purposes and may differ from unrounded results. |

[0001262039-25-000011:mdna:142]
Discussion regarding our financial condition and results of operations for 2023 as compared to 2022 can be found in Item 7 of our Annual Report on Form 10-K for the fiscal year ended December 31, 2023, filed with the SEC on February 26, 2024.

[0001262039-25-000011:mdna:143]
65

[0001262039-25-000011:mdna:144]
2024 and 2023

[0001262039-25-000011:mdna:145]
Revenue

[0001262039-25-000011:mdna:146]
|  | Year Ended December 31, |  |  |  |  |
| 2024 |  | 2023 |  |  |  |  |
| Amount |  | % ofRevenue |  | Amount |  | % ofRevenue |  | Change |  | % Change |
| (in millions, except percentages) |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 1,908.7 |  |  | 32 | % |  | $ | 1,927.3 |  |  | 36 | % |  | $ | (18.6) |  |  | (1) | % |
| Service | 4,047.1 |  |  | 68 |  |  | 3,377.5 |  |  | 64 |  |  | 669.6 |  |  | 20 |  |
| Total revenue | $ | 5,955.8 |  |  | 100 | % |  | $ | 5,304.8 |  |  | 100 | % |  | $ | 651.0 |  |  | 12 | % |
| Revenue by geography: |  |  |  |  |  |  |  |  |  |  |  |
| Americas | $ | 2,442.2 |  |  | 41 | % |  | $ | 2,175.2 |  |  | 41 | % |  | $ | 267.0 |  |  | 12 | % |
| EMEA | 2,396.2 |  |  | 40 |  |  | 2,072.9 |  |  | 39 |  |  | 323.3 |  |  | 16 |  |
| APAC | 1,117.4 |  |  | 19 |  |  | 1,056.7 |  |  | 20 |  |  | 60.7 |  |  | 6 |  |
| Total revenue | $ | 5,955.8 |  |  | 100 | % |  | $ | 5,304.8 |  |  | 100 | % |  | $ | 651.0 |  |  | 12 | % |

[0001262039-25-000011:mdna:147]
Total revenue increased $651.0 million, or 12%, in 2024 compared to 2023. We continued to experience diversification of revenue geographically, and across customer and industry verticals. Revenue from all regions grew, with EMEA contributing the largest portion of the increase on an absolute dollar basis and on a percentage basis.

[0001262039-25-000011:mdna:148]
Product revenue remained comparatively flat in 2024 compared to 2023.

[0001262039-25-000011:mdna:149]
Service revenue increased $669.6 million, or 20%, in 2024 compared to 2023. Security subscription revenue increased $418.6 million, or 22%, and technical support and other services revenue increased $251.0 million, or 17%, in 2024 compared to 2023. The increase was primarily due to the recognition of revenue from our growing deferred revenue balance related to FortiGuard and other security subscriptions delivered to on-premise and cloud-based environments and growth in SaaS solutions, including unified SASE and SecOps.

[0001262039-25-000011:mdna:150]
Of the service revenue recognized in 2024, 70% was included in the deferred revenue balance as of December 31, 2023. Of the service revenue recognized in 2023, 67% was included in the deferred revenue balance as of December 31, 2022.

[0001262039-25-000011:mdna:151]
Of the service revenue recognized in each quarter of 2024, from 88% to 90% was included in deferred revenue as of the beginning of the respective quarter. We expect service revenue growth rates to continue to slow down in 2025 due to slowing short term deferred revenue growth over the past several quarters, partially offset by increases in SaaS revenue.

[0001262039-25-000011:mdna:152]
66

[0001262039-25-000011:mdna:153]
Cost of revenue and gross margin

[0001262039-25-000011:mdna:154]
|  | Year Ended December 31, |  |  |  |  |  |  |  |  |
| 2024 |  | 2023 |  | Change |  | % Change |  |  |  |  |
| (in millions, except percentages) |  |  |  |  |
| Cost of revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 652.0 |  |  | $ | 763.6 |  |  | $ | (111.6) |  |  | (15) | % |  |  |  |  |
| Service | 505.6 |  |  | 473.6 |  |  | 32.0 |  |  | 7 |  |  |  |  |  |
| Total cost of revenue | $ | 1,157.6 |  |  | $ | 1,237.2 |  |  | $ | (79.6) |  |  | (6) | % |  |  |  |  |
| Gross margin (%): |  |  |  |  |  |  |  |  |  |  |  |
| Product | 65.8 | % |  | 60.4 | % |  |  |  |  |  |  |  |  |
| Service | 87.5 | % |  | 86.0 | % |  |  |  |  |  |  |  |  |
| Total gross margin | 80.6 | % |  | 76.7 | % |  |  |  |  |  |  |  |  |
| Percentages have been rounded for presentation purposes and may differ from unrounded results. |

[0001262039-25-000011:mdna:155]
Total gross margin increased 3.9 percentage points in 2024 compared to 2023, primarily driven by a shift in the revenue mix to higher margin service revenue and increased product and service gross margin. Revenue mix shifted by 4.3 percentage points from product revenue to service revenue, as a percentage of total revenue.

[0001262039-25-000011:mdna:156]
Product gross margin increased 5.4 percentage points in 2024 compared to 2023, primarily due to decrease in inventory related reserves expense, lower expedite fees, a shift in revenue mix from hardware to software and lower freight costs, partially offset by reduced prices on certain products. During the first quarter of 2024, we lowered list prices on select products. Cost of product revenue was comprised primarily of third-party contract manufacturers’ costs, costs of materials used in production and inventory reserves related to excess inventory and contractual delivery commitments.

[0001262039-25-000011:mdna:157]
Service gross margin increased 1.5 percentage points in 2024 compared to 2023, primarily driven by service revenue growth outpacing labor and replacement costs increase, partially offset by an increase in cloud service costs. Cost of service revenue was comprised primarily of personnel-related costs, replacement cost, data center infrastructure, software and delivery costs, colocation and cloud provider fees, as well as facility-related costs.

[0001262039-25-000011:mdna:158]
Operating expenses

[0001262039-25-000011:mdna:159]
|  | Year Ended December 31, |  | Change |  | % Change |
| 2024 |  | 2023 |  |
| Amount |  | % ofRevenue |  | Amount |  | % ofRevenue |  |
| (in millions, except percentages) |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | $ | 716.8 |  |  | 12 | % |  | $ | 613.8 |  |  | 12 | % |  | $ | 103.0 |  |  | 17 | % |
| Sales and marketing | 2,044.8 |  |  | 34 |  |  | 2,006.0 |  |  | 38 |  |  | 38.8 |  |  | 2 |  |
| General and administrative | 237.8 |  |  | 4 |  |  | 211.3 |  |  | 4 |  |  | 26.5 |  |  | 13 |  |
| Gain on intellectual property matter | (4.6) |  |  | — |  |  | (4.6) |  |  | — |  |  | — |  |  | — |  |
| Total operating expenses | $ | 2,994.8 |  |  | 50 | % |  | $ | 2,826.5 |  |  | 53 | % |  | $ | 168.3 |  |  | 6 | % |

[0001262039-25-000011:mdna:160]
Research and development

[0001262039-25-000011:mdna:161]
Research and development expense increased $103.0 million, or 17%, in 2024 compared to 2023, primarily due to an increase of $81.8 million in personnel-related costs as a result of increased headcount and compensation rates to support the development of new products and continued enhancements to our existing products. In addition, non-personnel-related product development costs increased $14.1 million and depreciation expense and other occupancy-related expense increased $6.8 million. We currently intend to continue to invest in our research and development organization, and expect research and development expense to increase in absolute dollars in 2025.

[0001262039-25-000011:mdna:162]
Sales and marketing

[0001262039-25-000011:mdna:163]
Sales and marketing expense increased $38.8 million, or 2%, in 2024 compared to 2023, primarily due to an increase of $44.0 million in personnel-related costs. In addition, travel expense increased $7.3 million and cloud hosting services costs related to sales demonstrations increased $4.5 million. The increases were partially offset by a decrease of $21.8 million in marketing program and related expenses. We currently intend to continue to make investments in sales and marketing resources, which are critical to support our future growth, and expect sales and marketing expense to increase in absolute dollars in 2025.

[0001262039-25-000011:mdna:164]
General and administrative

[0001262039-25-000011:mdna:165]
General and administrative expense increased $26.5 million, or 13%, in 2024 compared to 2023, primarily due to an increase of $21.7 million in legal related fees and other professional service fees and an increase of $6.6 million in personnel-related costs. The increases were partially offset by a decrease of $6.0 million in provision for expected credit losses. We currently expect general and administrative expense to increase in absolute dollars in 2025.

[0001262039-25-000011:mdna:166]
Operating income and margin

[0001262039-25-000011:mdna:167]
We generated operating income of $1.80 billion in 2024, an increase of $562.3 million, or 45%, compared to $1.24 billion in 2023. Operating income as a percentage of revenue increased to 30.3% in 2024 compared to 23.4% in 2023. The increase in our operating margin primarily benefits from 3.9 percentage points increase in gross margin and 3.5 percentage points decrease in sales and marketing expense as a percentage of revenue, partially offset by 0.5 percentage points increase in research and development expense as percentage of revenue.

[0001262039-25-000011:mdna:168]
Interest income, interest expense, gain on bargain purchase and other income (expense)—net

[0001262039-25-000011:mdna:169]
|  | Year Ended December 31, |  |  |  |  |
| 2024 |  | 2023 |  | Change |  | % Change |
| (in millions, except percentages) |
| Interest income | $ | 155.2 |  |  | $ | 119.7 |  |  | $ | 35.5 |  |  | 30 | % |
| Interest expense | (20.0) |  |  | (21.0) |  |  | 1.0 |  |  | (5) | % |
| Gain on bargain purchase | 106.3 |  |  | — |  |  | 106.3 |  |  | 100 | % |
| Other income (expense)—net | 13.6 |  |  | (6.1) |  |  | 19.7 |  |  | (323) | % |

[0001262039-25-000011:mdna:170]
Interest income increased $35.5 million in 2024 as compared to 2023, primarily as a result of higher investment balances. Interest income varies depending on our average investment balances during the period, types and mix of investments, and market interest rates. Interest expense decreased $1.0 million in 2024 as compared to 2023. Gain on bargain purchase was $106.3 million in 2024 and is related to our acquisition of Lacework. The $19.7 million change in other income (expense)—net in 2024 as compared to 2023 was primarily due to an increase of $30.9 million gain on marketable equity securities, partially offset by a $10.0 million increase of foreign currency exchange losses.

[0001262039-25-000011:mdna:171]
Provision for income taxes

[0001262039-25-000011:mdna:172]
|  | Year Ended December 31, |  | Change |  | % Change |
| 2024 |  | 2023 |  |
| (in millions, except percentages) |
| Provision for income taxes | $ | 283.9 |  |  | $ | 143.8 |  |  | $ | 140.1 |  |  | 97 | % |
| Effective tax rate (%) | 14 | % |  | 11 | % |  |  |  |  |

[0001262039-25-000011:mdna:173]
Our provision for income taxes for 2024 reflects an effective tax rate of 14%, compared to an effective tax rate of 11% for 2023. The provision for income taxes for 2024 was comprised primarily of a $454.6 million tax expense related to U.S. federal and state income taxes, other foreign income taxes, foreign withholding taxes and unrecognized tax benefits. The provision was partially offset by excess tax benefits of $45.3 million from stock-based compensation expense, a tax benefit of $111.5 million from the FDII deduction, and a tax benefit of $13.9 million from federal research and development tax credits.

[0001262039-25-000011:mdna:174]
Our provision for income taxes for 2023 reflects an effective tax rate of 11%, compared to an effective tax rate of 3% for 2022. The provision for income taxes for 2023 was comprised primarily of a $302.4 million tax expense related to U.S. federal and state income taxes, other foreign income taxes, foreign withholding taxes and unrecognized tax benefits. The

[0001262039-25-000011:mdna:175]
68

[0001262039-25-000011:mdna:176]
provision was partially offset by excess tax benefits of $55.1 million from stock-based compensation expense, a tax benefit of $89.5 million from the FDII deduction, and a tax benefit of $14.0 million from federal research and development tax credits.

[0001262039-25-000011:mdna:177]
Loss from Equity Method Investments

[0001262039-25-000011:mdna:178]
|  | Year Ended December 31, |  | Change |  | % Change |
| 2024 |  | 2023 |  |
| (in millions, except percentages) |
| Loss from equity method investments | $ | (29.4) |  |  | $ | (42.1) |  |  | $ | 12.7 |  |  | (30) | % |

[0001262039-25-000011:mdna:179]
Loss from equity method investments decreased $12.7 million in 2024 as compared to 2023, primarily driven by our proportionate share of Linksys’ financial results, partially offset by the OTTI charge of $8.0 million recorded in the second quarter of 2024.

[0001262039-25-000011:mdna:180]
Seasonality, Cyclicality and Quarterly Revenue Trends

[0001262039-25-000011:mdna:181]
Our quarterly results reflect a pattern of increased customer buying at year-end, which has positively impacted billings and product revenue activity in the fourth quarter. In the first quarter, we generally experience lower sequential customer product buying, followed by an increase in buying in the second and third quarters. Although these seasonal factors may be common in the technology sector, historical patterns should not be considered a reliable indicator of our future sales activity or performance. On a quarterly basis, we have usually generated the majority of our product revenue in the final month of each quarter and a significant amount in the last two weeks of each quarter. We believe this is due to customer buying patterns typical in this industry.

[0001262039-25-000011:mdna:182]
Our quarterly revenue over the past three years has increased sequentially each quarter within the year.

[0001262039-25-000011:mdna:183]
Total gross margin has fluctuated on a quarterly basis primarily due to the relative product and service mix. Product gross margin varies based on the types of products sold, their cost profile and their average selling prices. Service gross margin is impacted by revenue growth and our personnel-related costs, replacement cost, data center infrastructure, software and delivery costs, colocation and cloud provider fees, facility-related costs and foreign currency fluctuations.

[0001262039-25-000011:mdna:184]
Liquidity and Capital Resources

[0001262039-25-000011:mdna:185]
|  | As of December 31, |
|  | 2024 |  | 2023 |  | 2022 |
|  | (in millions) |
| Cash and cash equivalents | $ | 2,875.9 |  |  | $ | 1,397.9 |  |  | $ | 1,682.9 |  |
| Short-term and long-term investments | 1,126.4 |  |  | 1,021.5 |  |  | 548.1 |  |
| Marketable equity securities | 64.2 |  |  | 21.0 |  | 25.5 |  |
| Total cash, cash equivalents, investments and marketable equity securities | $ | 4,066.5 |  |  | $ | 2,440.4 |  |  | $ | 2,256.5 |  |
| Working capital | $ | 1,910.8 |  |  | $ | 709.3 |  |  | $ | 732.0 |  |
|  | Year Ended December 31, |
|  | 2024 |  | 2023 |  | 2022 |
|  | (in millions) |
| Net cash provided by operating activities | $ | 2,258.1 |  |  | $ | 1,935.5 |  |  | $ | 1,730.6 |  |
| Net cash provided by (used in) investing activities | (727.4) |  |  | (649.3) |  |  | 763.9 |  |
| Net cash used in financing activities | (50.1) |  |  | (1,570.4) |  |  | (2,130.3) |  |
| Effect of exchange rate changes on cash and cash equivalents | (2.6) |  |  | (0.8) |  |  | (0.4) |  |
| Net increase (decrease) in cash and cash equivalents | $ | 1,478.0 |  |  | $ | (285.0) |  |  | $ | 363.8 |  |

[0001262039-25-000011:mdna:186]
Liquidity and capital resources are primarily impacted by our operating activities, as well as real estate purchases, other capital expenditures, and business acquisitions, payment of taxes in connection with the net settlement of equity awards and proceeds from the issuance of common stock and investment grade debt and repurchases of our common stock.

[0001262039-25-000011:mdna:187]
In recent years, we have received significant capital resources from our billings to customers, issuance of investment grade debt and, to some extent, from the exercise of stock options by our employees. Additional increases in billings may depend on a number of factors, including demand for and availability of our products and services, competition, pricing actions, market or industry changes, macroeconomic events such as rising inflation and changing interest rates, economic strength, supply chain capacity and disruptions, tariffs and other trade restrictions, international conflicts, including the war in Ukraine, an increase in installment billing, and our ability to execute. We expect proceeds from the exercise of stock options in future years to continue to be impacted by the increased mix of restricted stock units and performance stock units versus stock options granted to our employees and to vary based on our share price.

[0001262039-25-000011:mdna:188]
In January 2024, our board of directors approved a $500.0 million increase in the authorized stock repurchase amount under the Repurchase Program, bringing the aggregate amount authorized to be repurchased to $7.25 billion of our outstanding common stock. In February 2024, our board of directors approved an extension of the Repurchase Program to February 28, 2025. In October 2024, our board of directors approved a $1.0 billion increase in the authorized stock repurchase amount under the Repurchase Program and extended the term of the Repurchase Program to February 28, 2026, bringing the aggregate amount authorized to be repurchased to $8.25 billion of our outstanding common stock through February 28, 2026. In 2024, we repurchased less than 0.1 million shares of common stock under the Repurchase Program for an aggregate purchase price of $0.6 million. As of December 31, 2024, approximately $2.03 billion remained available for future share repurchases under the Repurchase Program.

[0001262039-25-000011:mdna:189]
We expect to continue to increase our data centers, PoPs, office and warehouse capacity to support growth and the expansion of existing services or introduction of new services. As we purchase new properties, we will work to incorporate these properties into the environmental goals we have established. We estimate 2025 capital expenditures to be between approximately $380.0 million and $430.0 million.

[0001262039-25-000011:mdna:190]
Our principal commitments consist of obligations under our senior notes, inventory purchase and other contractual commitments. As of December 31, 2024, the long-term debt, net of unamortized discount and debt issuance costs, was $994.3 million. $500.0 million in aggregate principal amount of senior notes is due on March 15, 2026 and $500.0 million in aggregate principal amount of senior notes is due on March 15, 2031. In addition, we purchase components of our inventory from certain suppliers and use several independent contract manufacturers to provide manufacturing services for our products. During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, we enter into agreements with contract manufacturers and suppliers that allow them to procure inventory based upon criteria as defined by us or establish the parameters defining our requirements. A significant portion of our reported purchase commitments arising from these agreements consists of firm, non-cancelable and unconditional commitments. Certain of these inventory purchase commitments with contract manufacturers and suppliers relate to arrangements to secure supply and pricing for certain product components for multi-year periods. In certain instances, these agreements allow us the option to reschedule and adjust our requirements based on our business needs prior to firm orders being placed.

[0001262039-25-000011:mdna:191]
These inventory purchase commitments as of December 31, 2024 totaled $591.1 million, a decrease of $46.2 million compared to $637.3 million as of December 31, 2023 due to fulfillment of customer demand as our supply availability improved and our continued efforts to work with contract manufacturers and suppliers to optimize our inventory and purchase commitments position. We record a liability for inventory purchase commitments in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. We estimate payments of $588.9 million due on or before December 31, 2025 related to these commitments.

[0001262039-25-000011:mdna:192]
We increased our purchase commitments in prior years to address significant supply constraints seen industry-wide due to component shortages and have reduced the purchase commitments in 2024. Our agreements secured supply and pricing for certain product components with contract manufacturers to meet customer demand and to address extended lead times.

[0001262039-25-000011:mdna:193]
Inventory and supply chain management remain areas of focus as we balance the need to maintain supply chain flexibility to help ensure competitive lead times with the risk of inventory obsolescence because of supply constraints, rapidly changing technology, and customer requirements. We believe the amount of our inventory and purchase commitments is appropriate for our current and expected customer demand and revenue levels.

[0001262039-25-000011:mdna:194]
We also have open purchase orders and contractual obligations in the ordinary course of business for which we have not received goods or services. As of December 31, 2024, we had $101.2 million in other contractual commitments having a remaining term in excess of one year that are non-cancelable.

[0001262039-25-000011:mdna:195]
As of December 31, 2024, our cash, cash equivalents and short-term and long-term investments of $4.07 billion were invested primarily in deposit accounts, commercial paper, corporate debt securities, U.S. government and agency securities, certificates of deposit and term deposits and money market funds. It is our investment policy to invest excess cash in a manner that preserves capital, provides liquidity, and generates return without significantly increasing risk. We do not enter into investments for trading or speculative purposes.

[0001262039-25-000011:mdna:196]
The amount of cash, cash equivalents and investments held by our international subsidiaries was $207.8 million and $199.9 million as of December 31, 2024 and 2023, respectively.

[0001262039-25-000011:mdna:197]
We believe that our existing cash and cash equivalents and cash flow from operations will be sufficient for at least the next 12 months to meet our requirements and plans for cash, including meeting our working capital requirements and capital expenditure requirements. In the long term, our ability to support our requirements and plans for cash, including our working capital and capital expenditure requirements will depend on many factors, including our growth rate; the timing and amount of our share repurchases and debt retirement; the expansion of sales and marketing activities, pricing actions, the introduction of new and enhanced products and services offerings; the continuing market acceptance of our products; the timing and extent of spending to support development efforts; our investments in purchasing, developing or leasing real estate; cash paid for taxes and macroeconomic impacts such as rising inflation and changing interest rates; and the war in Ukraine. Historically, we have required capital principally to fund our working capital needs, share repurchases, capital expenditures and acquisition activities. In the event that additional financing is required from outside sources, we may not be able to raise it on terms acceptable to us or at all.

[0001262039-25-000011:mdna:198]
During 2024, 2023 and 2022, we did not have any relationships with unconsolidated organizations or financial partnerships, such as structured finance or special purpose entities that would have been established for the purpose of facilitating off-balance sheet arrangements or other contractually narrow or limited purposes.

[0001262039-25-000011:mdna:199]
Operating Activities

[0001262039-25-000011:mdna:200]
Cash generated by operating activities is our primary source of liquidity. It is primarily comprised of net income, as adjusted for non-cash items and changes in operating assets and liabilities. Non-cash adjustments consist primarily of amortization of deferred contract costs, stock-based compensation and depreciation and amortization. Changes in operating assets and liabilities consist primarily of changes in deferred revenue, deferred contract costs, accrued liabilities, deferred tax assets, inventory and accounts receivable—net.

[0001262039-25-000011:mdna:201]
Our operating activities during 2024 provided cash flows of $2.26 billion as a result of the continued growth of our business, improved profitability and our ability to successfully manage our working capital. Changes in operating assets and liabilities primarily resulted from an increase in sales of our security subscription services and technical support services to new and existing customers, as reflected by an increase of $577.8 million in our deferred revenue during 2024. In addition, changes in operating assets and liabilities were driven by an increase of $311.1 million in deferred contract costs, an increase of $223.2 million in deferred tax assets, a decrease of $131.2 million in inventory, a decrease of $106.7 million in accrued liabilities, and an increase of $45.4 million in accounts receivable—net.

[0001262039-25-000011:mdna:202]
Investing Activities

[0001262039-25-000011:mdna:203]
The changes in cash flows from investing activities primarily relate to timing of purchases, maturities and sales of investments, purchases of property and equipment, investments in various companies and business acquisitions. Historically, in making a lease-versus-ownership decision related to warehouse, office or data center space, we have considered various factors including financial metrics, expected long-term growth rates, time to market, operating costs and changes in asset values. In certain cases, we have elected to own a facility if we believe that purchasing or developing buildings rather than leasing is more closely aligned with our long-term strategy. We expect to make similar decisions in the future. We may also make cash payments in connection with future business combinations.

[0001262039-25-000011:mdna:204]
During 2024, cash used in investing activities was $727.4 million, primarily driven by $378.9 million used for the purchases of property and equipment, $275.5 million used for the acquisitions of Lacework, Next DLP and Perception Point, net of cash and $56.4 million spent for purchases of investments, net of maturities and sales of investments.

[0001262039-25-000011:mdna:205]
Financing Activities

[0001262039-25-000011:mdna:206]
The changes in cash flows from financing activities primarily relate to repurchase and retirement of common stock, and taxes paid related to net share settlement of equity awards, net of proceeds from the issuance of common stock under our Amended and Restated 2009 Equity Incentive Plan (the “2009 EIP”).

[0001262039-25-000011:mdna:207]
During 2024, cash used in financing activities was $50.1 million, primarily driven by $37.8 million used to pay tax withholding, net of proceeds from the issuance of common stock.

[0001262039-25-000011:mdna:208]
Recent Accounting Pronouncements

[0001262039-25-000011:mdna:209]
Refer to Note 1 of the notes to our consolidated financial statements in Part II, Item 8 of this Annual Report on Form 10-K for a full description of recently adopted accounting pronouncements.
