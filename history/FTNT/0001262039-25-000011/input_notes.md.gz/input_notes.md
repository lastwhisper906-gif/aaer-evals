# FTNT notes — 0001262039-25-000011


## dei:DocumentsIncorporatedByReferenceTextBlock

[0001262039-25-000011:notes:1]
Portions of the registrant’s definitive Proxy Statement relating to its 2025 Annual Meeting of Stockholders (“Proxy Statement”) are incorporated by reference into Part III of this Annual Report on Form 10-K where indicated. Such Proxy Statement will be filed with the United States Securities and Exchange Commission within 120 days after the end of the fiscal year to which this report relates


## cyd:CybersecurityRiskManagementProcessesIntegratedTextBlock

[0001262039-25-000011:notes:2]
In general, we seek to address cybersecurity risks through a broad, cross-functional approach that is focused on preserving the confidentiality, security and availability of the information that we collect and store by identifying, preventing and mitigating cybersecurity threats and effectively responding to cybersecurity incidents when they occur.


## cyd:CybersecurityRiskBoardOfDirectorsOversightTextBlock

[0001262039-25-000011:notes:3]
Governance

[0001262039-25-000011:notes:4]
As a global cybersecurity provider, cybersecurity risk management is integral to our company. Historically, the Audit Committee of our board of directors (the “Audit Committee”) was responsible for reviewing with management our cybersecurity and other information technology risks, controls and processes, including the processes used to prevent or mitigate cybersecurity risks and respond to cybersecurity events. However, due to the importance of cybersecurity to our company, in July 2024, our board of directors formed Cybersecurity Committee of our board of directors (the “Cybersecurity

[0001262039-25-000011:notes:5]
Committee”), which is solely dedicated to cybersecurity risk management. Our executives with responsibility over cybersecurity, including our Chief Information Security Officer, provide quarterly reports to the Cybersecurity Committee as well as to the Chief Executive Officer and other members of our senior management as appropriate. Each member of our board of directors is invited to attend all meetings of the committees of our board of directors, including the Cybersecurity Committee, and thus all of the members of our board of directors are apprised of cybersecurity developments. The quarterly reports to the Cybersecurity Committee include updates on cyber risks and threats, the status of projects to strengthen our information security systems, assessments of the information security program and the emerging threat landscape. Our cybersecurity program is regularly evaluated by internal and external experts with the results of those reviews reported to senior management and the Cybersecurity Committee. We also actively engage with key vendors and intelligence and law enforcement communities as part of our continuing efforts to evaluate and enhance the effectiveness of our information security policies and procedures. The Cybersecurity Committee also receives prompt and timely information regarding any cybersecurity threat or incident that meets established reporting thresholds, as well as ongoing updates regarding any such threat or incident until it has been mitigated, resolved or otherwise addressed.

[0001262039-25-000011:notes:6]
We believe our systems and processes with respect to the management of risks associated with cybersecurity threats are adequate. We have experienced, and may in the future experience, adverse impacts to our operations as a result of cybersecurity incidents. However, to date, cybersecurity threats, including as a result of any previous cybersecurity incidents, have not materially affected our business strategy, operating results, and/or financial condition. If we were to experience a material cybersecurity incident in the future, such incident may have a material effect, including on our business strategy, operating results or financial condition. For more information regarding cybersecurity risks that we face and potential impacts on our business related thereto, see our risk factors, including our risk factor titled “If our internal enterprise IT networks, on which we conduct internal business and interface externally, our operational networks, through which we connect to customers, vendors and partners systems and provide services, or our research and development networks, our back-end labs and cloud stacks hosted in our data centers or PoPs, colocation vendors or public cloud providers, through which we research, develop and host products and services, are compromised, public perception of our products and services may be harmed, our customers may be breached and harmed, we may become subject to liability, and our business, operating results and stock price may be adversely impacted.”


## cyd:CybersecurityRiskManagementProcessesForAssessingIdentifyingAndManagingThreatsTextBlock

[0001262039-25-000011:notes:7]
Risk Management and Strategy

[0001262039-25-000011:notes:8]
As one of the critical elements of our overall ERM approach, our cybersecurity program is focused on the following key areas:

[0001262039-25-000011:notes:9]
Governance: As discussed in more detail above under the heading, “Governance,” our board of directors’ oversight of cybersecurity risk management is supported by the Cybersecurity Committee, which regularly interacts with executives with responsibility for cybersecurity, our Chief Executive Officer, Chief Technology Officer and President, Chief Financial Officer, Chief Operating Officer/General Counsel, our CISO, and other members of management. Our CISO is primarily responsible for our cybersecurity risk management program and partners with our legal team on data privacy matters at the management level. Our CISO, Dr. Carl Windsor, has over 25 years of experience in various technology and cybersecurity leadership positions, including over 18 years at our company driving product security and strategy and reports to the board Cybersecurity Committee. The CISO’s leadership team members are all seasoned information security professionals, covering a wide range of security disciplines, who have worked at some of the largest well-known brand names and are experts in their fields. Our CISO monitors, and participates in, our various cybersecurity policies and procedures, and our cybersecurity team regularly updates our CISO on the current status.

[0001262039-25-000011:notes:10]
Management is promptly updated regarding any significant security events and the Cybersecurity Committee regularly reviews updates from our CISO, information security and product security leaders about cyber threat response preparedness, security controls and procedures, security program maturity milestones, risk and approaches to risk mitigation and the current and emerging threat landscape. In addition, all members of our board of directors receive management’s cybersecurity updates to the Cybersecurity Committee as part of their regular attendance at meetings of our board of directors.

[0001262039-25-000011:notes:11]
Collaborative Approach: We have implemented a broad, cross-functional approach to identifying, preventing and mitigating cybersecurity threats and incidents, while also implementing controls and procedures that provide for the prompt escalation of certain cybersecurity incidents so that decisions regarding the public disclosure and reporting of such incidents can be made by management in a timely manner. In addition, we manage a cross-functional program across our engineering, manufacturing and technical services teams, together with our suppliers and channel partners, designed to ensure the proper security of our products from design through manufacture and shipment.

[0001262039-25-000011:notes:12]
Information Security: We implement organizational, administrative and technical measures based on commercially reasonable procedures using: (i) industry standard information security measures prescribed for use by NIST; (ii) security measures aligned with the ISO/IEC 27000 series of standards, (iii) Sarbanes-Oxley and SSAE 18/ISAE 3402; (iv) privacy regulations such as the GDPR and the CCPA; (v) business continuity management measures aligned with the ISO/IEC 22301 standard; and (vi) other generally recognized industry standards, in each case, designed to safeguard the confidentiality, integrity, and availability of our infrastructure and data and the resiliency of our operations.

[0001262039-25-000011:notes:13]
Technical Safeguards: We deploy technical safeguards that are designed to protect our information systems from cybersecurity threats, including firewalls, intrusion prevention and detection systems, anti-malware functionality and access controls, which are evaluated and improved through vulnerability assessments and cybersecurity threat intelligence.

[0001262039-25-000011:notes:14]
Incident Response and Recovery Planning: We have established and maintain broad incident response and recovery plans that help enable its effective and orderly management of, and response to, any identified security incidents, including escalation and internal and external-notification steps, allowing the incident response team to respond in a timely manner and enlist appropriate personnel and third-party experts. We maintain a process to promptly assess and assign severity levels to any identified security incidents in order to prioritize their importance and promptly direct resources to those issues of potentially greater impact. The notification plan establishes steps to alert external stakeholders as appropriate, including law enforcement, regulatory bodies, investors, customers and other business partners.

[0001262039-25-000011:notes:15]
Third-Party Risk Management: We maintain a broad, risk-based approach to identifying and overseeing cybersecurity risks presented by third parties, including vendors, service providers and other external users of our systems, as well as the systems of third parties that could adversely impact our business in the event of a cybersecurity incident affecting those third-party systems. In addition, our Trusted Supplier Program is designed to ensure manufacturing partners undergo a selection and qualification process that adheres to NIST 800-161.

[0001262039-25-000011:notes:16]
Education and Awareness: We provide regular, mandatory training for personnel and contractors regarding cybersecurity threats as a means to equip our personnel with effective tools to address cybersecurity threats and to communicate our evolving information security policies, standards, processes and practices.

[0001262039-25-000011:notes:17]
Risk and Readiness Assessments: We engage in the periodic assessment and testing of our policies, standards, processes and practices that are designed to identify vulnerabilities and weaknesses, address cybersecurity threats and test its readiness to respond to cyber security incidents. These efforts include a wide range of activities, including threat modeling, a variety of vulnerability and configuration scans, penetration testing, audits, tabletop exercises and other exercises focused on evaluating the effectiveness of our cybersecurity measures and planning. We regularly engage third parties to perform assessments on our cybersecurity measures, including information security maturity assessments, audits and independent reviews of our information security control environment and operating effectiveness and penetration tests. The results of such assessments, audits and reviews are reported to the Cybersecurity Committee and our board of directors and to our management, and we adjust its cybersecurity policies, standards, processes and practices as necessary based on the information provided by these assessments, audits and reviews.

[0001262039-25-000011:notes:18]
Insurance: We maintain information security risk insurance coverage.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001262039-25-000011:notes:19]
THE COMPANY AND SUMMARY OF SIGNIFICANT ACCOUNTING POLICIES
Business—Fortinet, Inc. (“Fortinet”) was incorporated in Delaware in 2000 and is a global leader in broad, integrated and automated cybersecurity solutions. Fortinet provides high performance cybersecurity solutions to a wide variety of businesses, such as large enterprises, communication service providers, government organizations and small to medium-sized enterprises. Fortinet’s cybersecurity solutions are designed to provide broad visibility and segmentation of the digital attack surface, through our integrated cybersecurity platform (the “Fortinet Security Fabric”) with automated protection, detection and response.

[0001262039-25-000011:notes:20]
Basis of Presentation and Preparation—The consolidated financial statements of Fortinet and its subsidiaries (collectively, “we,” “us”, or “our”) have been prepared in accordance with generally accepted accounting principles in the United States (“GAAP”). We consolidate all legal entities in which we have an absolute controlling financial interest. All intercompany transactions and balances have been eliminated in consolidation.

[0001262039-25-000011:notes:21]
Use of Estimates—The preparation of consolidated financial statements in accordance with GAAP requires management to make estimates and assumptions that affect the amounts reported in the consolidated financial statements and accompanying notes. Such management estimates include, but are not limited to, the determination of contingent liabilities, the standalone selling price for our products and services, the period of benefit for deferred contract costs for commissions, stock-based compensation, inventory valuation and liability for non-cancellable inventory purchase commitments with contract manufacturers and component suppliers, the fair value of tangible and intangible assets acquired and liabilities assumed in business combinations, the measurement of liabilities for uncertain tax positions and deferred tax assets and liabilities, the assessment of recoverability of our goodwill and other long-lived assets. We base our estimates on historical experience and also on assumptions that we believe are reasonable. Actual results could differ materially from those estimates.

[0001262039-25-000011:notes:22]
Concentration Risk—Financial instruments that subject us to concentrations of credit risk consist primarily of cash, cash equivalents, short-term and long-term investments, marketable equity securities and accounts receivable. Our cash balances are maintained as deposits with various large financial institutions in the United States and around the world. Balances in the United States typically exceed the amount of insurance provided on such deposits. We maintain our cash equivalents and investments in money market funds, corporate debt securities, U.S. government and agency securities, commercial paper, certificates of deposit and term deposits and municipal bonds with major financial institutions that our management believes are financially sound.

[0001262039-25-000011:notes:23]
Our accounts receivable are derived from our customers in various geographic locations. We perform ongoing credit evaluations of our customers. We generally do not require collateral on accounts receivable, and we maintain reserves for estimated credit losses. See Note 16. Segment Information for distributor customers accounted for 10% or more of our revenue or net accounts receivable.

[0001262039-25-000011:notes:24]
We rely on a small number of manufacturing partners, with approximately 88% of manufacturing in Taiwan and U.S., to manufacture our products, and some of the chips and other components of our products used by the contract manufacturers are available from limited or sole sources of supply. We do not own manufacturing activities in China. Our proprietary Application-Specific Integrated Circuits are built by contract manufacturers located in Japan and Taiwan; other integrated circuits are provided by other chip manufacturers.

[0001262039-25-000011:notes:25]
Financial Instruments and Fair Value—We define fair value as the price that would be received from selling an asset, or paid to transfer a liability, in an orderly transaction between market participants at the measurement date. When determining the fair value measurements for assets and liabilities which are required to be recorded at fair value, we consider the principal or most advantageous market in which to transact and the market-based risk. We apply fair value accounting for all financial assets and liabilities and non-financial assets and liabilities that are recognized or disclosed at fair value in the financial statements on a recurring basis. Due to their short-term nature, the carrying amounts reported in the consolidated financial statements approximate the fair value for cash and cash equivalents, accounts receivable, accounts payable, accrued liabilities, and accrued payroll and compensation.

[0001262039-25-000011:notes:26]
Comprehensive Income—Comprehensive income includes certain changes in equity from non-owner sources that are excluded from net income, specifically, cumulative foreign currency translation adjustments, unrealized gains and losses on available-for-sale investments and the related tax impacts.

[0001262039-25-000011:notes:27]
Foreign Currency and Transaction Gains and Losses—The functional currency for most of our foreign subsidiaries is the U.S. dollar. For our international subsidiary whose functional currency is the local currency, we translate the financial statements of this subsidiary to U.S. dollars using the exchange rates in effect at the balance sheet dates for assets and liabilities, and average monthly exchange rates for revenues, costs, and expenses. We record translation gains and losses in accumulated other comprehensive income as a component of equity (deficit). We reflect net foreign exchange transaction gains and losses resulting from the conversion of the transaction currency to functional currency as a component of foreign currency exchange gain (loss) in other income (expense)—net. We recognized a foreign currency loss of $16.9 million, $7.0 million and $4.6 million in other income (expense)—net, for 2024, 2023, and 2022, respectively.

[0001262039-25-000011:notes:28]
Cash and Cash Equivalents—We consider all highly liquid investments, purchased with original maturities of three months or less, to be cash equivalents. Cash and cash equivalents consist of balances with banks and highly liquid investments in commercial paper, corporate debt, U.S. government and agency securities, term deposits and money market funds.

[0001262039-25-000011:notes:29]
Available-for-Sale Investments—We hold investment grade securities consisting of corporate debt securities, U.S. government and agency securities, commercial paper, certificates of deposit and term deposits and municipal bonds that our management believes are financially sound. We classify our investments as available-for-sale (“AFS”) at the time of purchase, since it is our intent that these investments are available for current operations. Investments with original maturities greater than three months with a remaining maturity of less than one year from the consolidated balance sheet date are classified as short-term investments. Investments with remaining maturities greater than one year from the consolidated balance sheet date are classified as long-term investments.

[0001262039-25-000011:notes:30]
Our AFS investments in debt securities are carried at estimated fair value with any unrealized gains and losses, net of taxes, included in accumulated other comprehensive income (loss) in the consolidated statements of equity (deficit). AFS debt securities with an amortized cost basis in excess of estimated fair value are assessed to determine what amount of that difference, if any, is caused by expected credit losses. An investment is impaired if the fair value of the investment is less than its cost. If the fair value of an investment is less than its amortized cost basis at the balance sheet date and if we do not intend to sell the investment, we consider available evidence to assess whether it is more likely than not that we will be required to sell the investment before the recovery of its amortized cost basis. We consult with our investment managers and consider available quantitative and qualitative evidence in evaluating, among other factors, general market conditions, the duration and extent to which the fair value is less than cost, and our ability to hold the investment. Once an impairment is determined to be attributable to credit-related factors, allowance for credit losses (i.e., the credit loss component) on AFS debt securities is recognized as credit loss expense, a charge in other income (expense)—net, on our consolidated statements of income, and any remaining unrealized losses (i.e., the non-credit loss component), net of taxes, are included in accumulated other comprehensive income (loss) on our consolidated statements of equity (deficit).

[0001262039-25-000011:notes:31]
We consider whether unrealized losses have resulted from a credit loss or other factors. The unrealized losses on our AFS debt securities as of December 31, 2024, 2023 and 2022 were caused by fluctuations in market value and interest rates as a result of the market conditions. We concluded that an allowance for credit losses was unnecessary as of December 31, 2024, 2023 and 2022 because (i) the decline in market value was attributable to changes in market conditions and not credit quality, and (ii) we concluded that neither do we intend to sell nor is it more likely than not that we will be required to sell these investments prior to recovery of their amortized cost basis. As a result, we had no credit losses recorded for the years ended December 31, 2024, 2023 and 2022.

[0001262039-25-000011:notes:32]
We determine realized gains or losses on sale of AFS debt securities using the specific identification method to determine the cost basis of investments sold and record such gains or losses as other income (expense)—net on the consolidated statements of income. We have elected to not record an allowance for credit losses for accrued interest for AFS investments in debt securities and will reverse the accrued interest against interest income in the period in which we determine the accrued interest to be uncollectible.

[0001262039-25-000011:notes:33]
Marketable Equity Securities—Our marketable equity investments with readily determinable fair values are accounted for at fair value through net income. Realized gains and losses as well as changes in fair value of these securities are recognized and reported in other income (expense)—net, and are determined using the specific identification method.

[0001262039-25-000011:notes:34]
Investments in privately held companies—Our investments in privately held companies consist of investments in common stock or in-substance common stock. Our equity method investments provide us with the ability to exercise significant influence over the investees, but not an absolute controlling financial interest. These investments are accounted for under the equity method of accounting and were initially recorded at cost. Subsequently, we recognize our proportionate share of the

[0001262039-25-000011:notes:35]
entity’s net profit or loss, the amortization of any basis differences, as well as any OTTI as gain or loss from these equity method investments in the consolidated statements of income and as an adjustment to the investment balance. We record our proportionate share of the results of these equity method investments on a three-month lag basis. We evaluate whether there are material transactions or events that occur during the intervening period that materially affect the financial position or results of operations. As of December 31, 2024 and 2023, we had two equity method investments, including our investment in Linksys Holdings, Inc. (“Linksys”). As of December 31, 2024 and 2023, our equity method investments were recorded in other assets. Our remaining investments in privately held companies are recorded at cost and as of December 31, 2024 and 2023 were not material.

[0001262039-25-000011:notes:36]
We evaluate our equity method investments at the end of each reporting period to determine whether events or changes in business circumstances indicate that the carrying value of the investments may not be recoverable. Evidence of a loss in value might include, but would not necessarily be limited to, absence of an ability to recover the carrying amount of the investments or inability of the investee to sustain an earnings capacity that would justify the carrying amount of the investments. This evaluation consists of several qualitative and quantitative factors including recent financial results, projected financial results and operating trends of the investees and other publicly available information that may affect the value of our investments.

[0001262039-25-000011:notes:37]
Accounts receivable—Trade accounts receivable are recorded at the invoiced amount. Our accounts receivable balance is reduced by an allowance for expected credit losses. We measure expected credit losses of accounts receivable on a collective (pooled) basis, aggregating accounts receivable that are either current or no more than 60 days past due, and aggregating accounts receivable that are more than 60 days past due. We apply a credit-loss percentage to each of the pools that is based on our historical credit losses. We review whether each of our significant accounts receivable that is more than 60 days past due continues to exhibit similar risk characteristics with the other accounts receivable in the pool. If we determine that it does not, we evaluate it for expected credit losses on an individual basis.

[0001262039-25-000011:notes:38]
We further consider collectability trends for the allowance for credit losses based on our assessment of various factors, including credit quality of our customers, current economic conditions, reasonable and supportable forecasts of future economic conditions, and other factors that may affect our ability to collect from our customers. Expected credit losses are recorded as general and administrative expenses on our consolidated statements of income. The allowance for credit losses was $5.9 million and $8.2 million as of December 31, 2024 and 2023, respectively. Provisions, write-offs and recoveries were not material during the years ended December 31, 2024, 2023 and 2022.

[0001262039-25-000011:notes:39]
Inventory—Inventory is recorded at the lower of cost or net realizable value. Cost is computed using the first-in, first-out method. Inventory costs comprise primarily of the cost of materials and other component parts, as well as overhead costs. In assessing the ultimate recoverability of inventory, we make estimates regarding future customer demand, the timing of new product introductions, economic trends and market conditions. A write-down of inventory and a corresponding charge to cost of product revenue is recorded when inventory is determined to be in excess of anticipated demand or considered obsolete. At the point of the write-down loss recognition, a new, lower cost basis for that inventory is established, and subsequent changes in facts and circumstances do not result in the restoration or increase in that newly established cost basis. In addition, we record a liability for non-cancelable inventory purchase commitments with contract manufacturers and suppliers for quantities in excess of our future estimated demand forecasts. The expense related to such accrued liability for inventory purchase commitments is recorded in cost of product revenue on the consolidated statements of income.

[0001262039-25-000011:notes:40]
Property and Equipment—Property and equipment are stated at cost less accumulated depreciation. We do not depreciate the allocated cost of land. Depreciation is computed using the straight-line method over the estimated useful lives of the assets:

[0001262039-25-000011:notes:41]
|  | Estimated Useful Lives |
| Building and building improvements | 2 to 40 years |
| Computer equipment and software | 1 to 7 years |
| Evaluation units | 1 year |
| Furniture and fixtures | 3 to 8 years |
| Leasehold improvements | Shorter of useful life or lease term |

[0001262039-25-000011:notes:42]
Business Combinations—We include the results of operations of the businesses that we acquire as of the respective dates of acquisition. We allocate the fair value of the purchase price of our business acquisitions to the tangible and intangible assets acquired and liabilities assumed, based on their estimated fair values. The excess of the purchase price over the fair

[0001262039-25-000011:notes:43]
values of these identifiable assets and liabilities is recorded as goodwill. Our estimates and assumptions are subject to change based on information existing at acquisition date but unknown to us, which may become known during the remainder of the measurement period, not to exceed 12 months from the acquisition date, and if we make changes to the amounts recorded, such amounts are recorded in the period in which they are identified.

[0001262039-25-000011:notes:44]
Impairment of Long-Lived Assets—We evaluate events and changes in circumstances that could indicate carrying amounts of long-lived assets, including intangible assets, may not be recoverable. When such events or changes in circumstances occur, we assess the recoverability of long-lived assets by determining whether the carrying value of such assets will be recovered through undiscounted expected future cash flows. If the total of the future undiscounted cash flows is less than the carrying amount of those assets, we record an impairment charge in the period in which we make the determination. If such assets are considered to be impaired, the impairment to be recognized is measured by the amount by which the carrying amount of the assets exceeds the fair value of the assets. There were no impairments of long-lived assets in 2024, 2023 and 2022.

[0001262039-25-000011:notes:45]
Goodwill—Goodwill represents the excess of purchase consideration over the estimated fair value of net assets of businesses acquired in a business combination. Goodwill acquired in a business combination is not amortized, but instead tested for impairment at least annually during the fourth quarter, or sooner when circumstances indicate an impairment may exist. We perform a qualitative assessment in the fourth quarter of each year, or more frequently if indicators of potential impairment exist, to determine if any events or circumstances exist, such as an adverse change in business climate or a decline in the overall industry that would indicate that it would more likely than not reduce the fair value of a reporting unit below its carrying amount, including goodwill. If such evaluation indicates that it is more likely than not that the fair value of a reporting unit is less that its carrying amount, then the quantitative impairment test will be performed. Under the quantitative impairment test, if the carrying amount of a reporting unit exceeds its fair value, any excess is recognized as an impairment loss in goodwill, limited to the total amount of goodwill allocated to that reporting unit.

[0001262039-25-000011:notes:46]
We performed our annual goodwill impairment assessment and did not identify any impairment indicators as a result of the review. As of December 31, 2024 and 2023, we had one reporting unit.

[0001262039-25-000011:notes:47]
Other Intangible Assets—Intangible assets with finite lives are carried at cost, less accumulated amortization. Amortization is computed using the straight-line or accelerated method over the estimated economic lives of the assets, which range from one to ten years.

[0001262039-25-000011:notes:48]
Income Taxes—We record income taxes using the asset and liability method, which requires the recognition of deferred tax assets and liabilities for the expected future tax consequences of events that have been recognized in our financial statements or tax returns. In addition, deferred tax assets are recorded for the future benefit of utilizing net operating losses and research and development credit carryforwards. Deferred tax assets and liabilities are measured using the currently enacted tax rates that apply to taxable income in effect for the years in which those tax assets and liabilities are expected to be realized or settled. Valuation allowances are provided when necessary to reduce deferred tax assets to the amount expected to be realized.

[0001262039-25-000011:notes:49]
As part of the process of preparing our consolidated financial statements, we are required to estimate our taxes in each of the jurisdictions in which we operate. We estimate actual current tax exposure together with assessing temporary differences resulting from differing treatment of items, such as accruals and allowances not currently deductible for tax purposes. These differences result in deferred tax assets, which are included in our consolidated balance sheets. In general, deferred tax assets represent future tax benefits to be received when certain expenses previously recognized in our consolidated statements of income become deductible expenses under applicable income tax laws, or loss or credit carryforwards are utilized.

[0001262039-25-000011:notes:50]
In assessing the realizability of deferred tax assets, management considers whether it is more likely than not that some portion or all of the deferred tax assets will be realized. The ultimate realization of deferred tax assets is dependent upon the generation of future taxable income during the periods in which those temporary differences become deductible. We continue to assess the need for a valuation allowance on the deferred tax assets by evaluating both positive and negative evidence that may exist. Any adjustment to the valuation allowance on deferred tax assets would be recorded in the consolidated statements of income for the period that the adjustment is determined to be required.

[0001262039-25-000011:notes:51]
We recognize tax benefits from an uncertain tax position only if it is more likely than not, based on the technical merits of the position, that the tax position will be sustained on examination by the tax authorities. The tax benefits recognized

[0001262039-25-000011:notes:52]
in the financial statements from such positions are then measured based on the largest benefit that has a greater than 50% likelihood of being realized upon ultimate settlement.

[0001262039-25-000011:notes:53]
We have elected to account for the tax effect of the GILTI as a current period expense.

[0001262039-25-000011:notes:54]
Stock-Based Compensation—The fair value of restricted stock units (“RSUs”) is based on the closing market price of our common stock on the date of grant. We have elected to use the Black-Scholes-Merton (“Black-Scholes”) pricing model to determine the fair value of our employee stock options and the Monte Carlo simulation pricing model to determine the fair value of our performance stock units (“PSUs”). Stock-based compensation expense of our RSUs and options is amortized on a straight-line basis over the service period and stock-based compensation expense of our PSUs is amortized using a graded vesting method over the vesting period. We account for forfeitures of all stock-based payment awards when they occur.

[0001262039-25-000011:notes:55]
Leases—We determine if an arrangement is a lease at inception. We evaluate the classification of leases at commencement and, as necessary, at modification. The right-of-use (“ROU”) assets and the short- and long-term lease liabilities from our operating leases are included in other assets, accrued liabilities and other liabilities in our consolidated balance sheets, respectively. The corresponding assets and, the short- and long-term lease liabilities from our finance leases are included in property and equipment, accrued liabilities and other liabilities in our consolidated balance sheets, respectively.

[0001262039-25-000011:notes:56]
The ROU assets represent our right to use an underlying asset for the lease term. Lease liabilities represent our obligation to make lease payments under the lease. Operating lease ROU assets and liabilities are recognized at the lease commencement date based on the present value of lease payments over the lease term. The implicit rate within our operating leases is generally not determinable and therefore we use our incremental borrowing rate at the lease commencement date to determine the present value of lease payments. The determination of our incremental borrowing rate requires judgment. We determine our incremental borrowing rate for each lease using indicative bank borrowing rates, adjusted for various factors including level of collateralization, term and currency to align with the terms of a lease. The operating lease ROU asset also includes any lease prepayments and initial direct costs, net of lease incentives. Certain leases include options to extend or terminate the lease. An option to extend the lease is considered in connection with determining the ROU asset and lease liability when it is reasonably certain we will exercise that option. An option to terminate is considered unless it is reasonably certain we will not exercise the option.

[0001262039-25-000011:notes:57]
We do not recognize lease liabilities or ROU assets for short-term leases (leases that, at the commencement date, have a lease term of 12 months or less and do not include an option to purchase the underlying asset that we are reasonably certain to exercise). We do not allocate the contract consideration for operating lease contracts with lease and non-lease components, and account for the lease and non-lease components as a single lease component.

[0001262039-25-000011:notes:58]
Payments under our lease arrangements are primarily fixed; however, certain lease agreements contain variable payments, which are expensed as incurred and not included in the operating lease ROU assets and liabilities. Variable lease payments primarily include common area maintenance charges, real estate taxes, certain parking expense, utilities based on actual usage, and insurance costs. Lease expense for lease payments for our operating leases is recognized on a straight-line basis over the term of the lease. We begin recognizing rent expense on the date that a lessor makes an underlying asset that is subject to the lease available for our use. For our finance leases, we recognize amortization expense from the amortization of the corresponding assets and interest expense on the related lease liabilities.

[0001262039-25-000011:notes:59]
Advertising Expense—Advertising costs are expensed when incurred and are included in operating expenses in the accompanying consolidated statements of income. Our advertising expenses were not material for any periods presented.

[0001262039-25-000011:notes:60]
Research and Development Costs—Research and development costs are expensed as incurred.

[0001262039-25-000011:notes:61]
Software Development Costs—The costs to develop software that is marketed have not been capitalized as we believe our current software development process is essentially completed concurrently with the establishment of technological feasibility. Such costs are expensed as incurred and included in research and development in our consolidated statements of income.

[0001262039-25-000011:notes:62]
The costs to develop software for internal use are capitalized based on qualifying criteria. These costs consist of internal compensation related costs and external direct costs incurred during the application development stage. Such costs are amortized over the software’s estimated useful life. Internal use software development costs capitalized were not material for any periods presented.

[0001262039-25-000011:notes:63]
Deferred Contract Costs and Commission Expense—Sales commissions earned by our sales force are considered incremental and recoverable costs of obtaining a contract with a customer. We recognize sales commissions expenses related to product sales upfront while sales commissions expenses for service contracts are deferred as deferred contract costs in the consolidated balance sheets and amortized over the applicable amortization period. Commission costs for initial contracts that are not commensurate with commissions on renewal contracts are amortized on a straight-line basis over the period of benefit, which we have determined to be five years and which is typically longer than the initial contract term. The amortization of deferred contract costs is included in sales and marketing expense in our consolidated statements of income. Amortization of deferred contract costs during 2024, 2023 and 2022 was $293.7 million, $266.3 million and $223.3 million, respectively. No impairment loss of deferred contract costs asset was recognized during 2024, 2023 and 2022.

[0001262039-25-000011:notes:64]
Deferred Revenue—Deferred revenue consists of amounts that have been invoiced but that have not yet been recognized as revenue. Deferred revenue that will be recognized during the succeeding 12-month period is recorded as current deferred revenue and the remaining portion is recorded as non-current deferred revenue. The majority of deferred revenue is comprised of security subscription and technical support services which are invoiced upfront and delivered over 12 months or longer.

[0001262039-25-000011:notes:65]
Revenue Recognition—Our revenue consists of product and service revenue. Revenues are recognized when control of these goods or services is transferred to our customers, in an amount that reflects the consideration we expect to be entitled to in exchange for those goods or services. We determine revenue recognition through the following steps:

[0001262039-25-000011:notes:66]
•identification of a contract or contracts with a customer;

[0001262039-25-000011:notes:67]
•identification of the performance obligations in a contract, including evaluation of performance obligations and evaluating the distinct goods or services in a contract;

[0001262039-25-000011:notes:68]
•determination of a transaction price;

[0001262039-25-000011:notes:69]
•allocation of a transaction price to the performance obligations in a contract; and

[0001262039-25-000011:notes:70]
•recognition of revenue when, or as, we satisfy a performance obligation.

[0001262039-25-000011:notes:71]
We derive a majority of product sales from FortiGate, other secure networking hardware which include a broad set of built-in security and networking features and functionalities, including firewall, next-generation firewall, secure web gateway, SSL inspection, software-defined wide-area network, intrusion prevention, SSL data leak prevention, virtual private network, switch and wireless controller and wide area network edge.

[0001262039-25-000011:notes:72]
We recognize product revenue upon shipment when control of the promised goods is transferred to the customer. Our term-based software licenses represent multiple performance obligations, which include software licenses and software support services where the software licenses are recognized upfront within product revenue upon transfer of control, and the associated software support services are recognized ratably over the service term as service revenue.

[0001262039-25-000011:notes:73]
Service revenue relates to sales of our FortiGuard and other security subscriptions, FortiCare technical support services and other services. Our typical subscription and support term is one to five years. We generally recognize revenue from these services ratably over the service term because of continuous transfer of control to the customer. We also generate a portion of our revenue from other services consisting of professional services, training and SaaS which is either hosted by us or provided through cloud providers. We recognize revenue from professional and training services as the services are provided. We recognize revenue from SaaS as the subscription service is delivered over the term, which is typically one year, or on a monthly usage basis. To date, SaaS revenue has not represented a significant percentage of our total revenue.

[0001262039-25-000011:notes:74]
Our sales contracts typically contain performance obligations, such as hardware, software license, security subscription, technical support services, cloud and other services, which are generally capable of being distinct and accounted for as separate performance obligations. Our hardware and software licenses have significant standalone functionalities and capabilities. Accordingly, the hardware and software licenses are distinct from the security subscription and technical support services, as a customer can benefit from the product without the services and the services are separately identifiable within a contract. We allocate a transaction price to each performance obligation based on relative standalone selling price. We establish standalone selling price using the prices charged for a deliverable when sold separately. If not observable through past transactions, we determine standalone selling price by considering multiple historical factors including, but not limited to, cost

[0001262039-25-000011:notes:75]
of products, gross margin objectives, pricing practices, geographies and the term of a service contract. Revenue is reported net of sales tax.

[0001262039-25-000011:notes:76]
In certain circumstances, our contracts include provisions for sales rebates and other customer incentive programs. Additionally, in limited circumstances, we may permit end-customers, distributors and resellers to return our products, subject to varying limitations, for a refund within a reasonably short period from the date of purchase. These amounts are accounted for as variable consideration that can decrease the transaction price. We estimate variable consideration using the expected-value method based on the most likely amounts to which we expect our customers to be entitled. We include estimated amounts in the transaction price to the extent that it is probable that a significant reversal of cumulative revenue recognized will not occur when the uncertainty associated with the variable consideration is resolved. Our estimate for refund liabilities, which include sales returns reserve and customer rebates, was $71.8 million and $92.7 million as of December 31, 2024 and 2023, respectively, and is included in current liabilities in our consolidated balance sheet.

[0001262039-25-000011:notes:77]
We generally invoice at the time of our sale for the total price of the hardware, software licenses, security subscription and technical support and other services. Standard payment terms are generally no more than 60 days, though we continue to offer extended payment terms to certain distributors. Amounts billed and due from our customers are classified as receivables on the balance sheet and do not bear interest.

[0001262039-25-000011:notes:78]
Shipping and handling fees charged to our customers are recognized as revenue in the period shipped and the related costs for providing these services are recorded in cost of revenue. Shipping and handling fees recognized were not material during 2024, 2023 and 2022.

[0001262039-25-000011:notes:79]
Warranties—We generally provide a one-year warranty for most hardware products and a 90-day warranty for software. We also provide extended warranties under the terms of our support agreements. A provision for estimated future costs related to warranty activities in the first year after product sale is recorded as a component of cost of product revenues when the product revenue is recognized, based upon historical product failure rates and historical costs incurred in correcting product failures. Warranty costs related to extended warranties sold under support agreements are recognized as cost of service revenue as incurred. In the event we change our warranty reserve estimates, the resulting charge against future cost of revenue or reversal of previously recorded charges may materially affect our gross margins and operating results. Accrued warranty liability was not material as of December 31, 2024 and 2023.

[0001262039-25-000011:notes:80]
Contingent Liabilities—From time to time, we are involved in disputes, litigation, and other legal actions. There are many uncertainties associated with any disputes, litigation and other legal actions, and these actions or other third-party claims against us may cause us to incur costly litigation fees, costs and substantial settlement charges, and possibly subject us to damages and other penalties, which are inherently difficult to estimate and could adversely affect our results of operations. In addition, the resolution of any IP litigation may require us to make royalty payments, which could adversely affect our gross margins in future periods. We periodically review significant claims and litigation matters for the probability of an adverse outcome. Estimates can change as individual claims develop. The actual liability in any such matters may be materially different from our estimates, which could result in the need to adjust our liability and record additional expenses, which may be material.

[0001262039-25-000011:notes:81]
Recently Adopted Accounting Standards

[0001262039-25-000011:notes:82]
Segment Reporting

[0001262039-25-000011:notes:83]
In November 2023, the Financial Accounting Standards Board (the “FASB”) issued Accounting Standards Update (“ASU”) 2023-07, Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures, which is intended to improve reportable segment disclosure requirements, primarily through enhanced disclosures about significant expenses. We adopted ASU 2023-07 for our annual period beginning fiscal year 2024 on a retrospective basis to all periods presented. Refer to Note 16. Segment Information.

[0001262039-25-000011:notes:84]
Recent Accounting Standards Not Yet Effective

[0001262039-25-000011:notes:85]
Income Taxes

[0001262039-25-000011:notes:86]
In December 2023, the FASB issued ASU 2023-09, Income Taxes (Topic 740): Improvements to Income Tax Disclosures, which includes amendments that further enhance income tax disclosures, primarily through standardization and

[0001262039-25-000011:notes:87]
disaggregation of rate reconciliation categories and income taxes paid by jurisdiction. The amendments are effective for our annual period beginning fiscal year 2025, with early adoption permitted, and should be applied prospectively. We are currently evaluating the ASU to determine its impact on our disclosures.

[0001262039-25-000011:notes:88]
Income Statement

[0001262039-25-000011:notes:89]
In November 2024, the FASB issued ASU 2024-03, Income Statement—Reporting Comprehensive Income—Expense Disaggregation Disclosures (Subtopic 220-40): Disaggregation of Income Statement Expenses (ASU 2024-03), and in January 2025, the FASB issued ASU No. 2025-01, Income Statement—Reporting Comprehensive Income—Expense Disaggregation Disclosures (Subtopic 220-40): Clarifying the Effective Date, which clarified the effective date of ASU 2024-03. ASU 2024-03 enhances the disclosures required for expense disaggregation in our annual and interim consolidated financial statements. The amendments are effective for our annual reporting period beginning fiscal 2027, with early adoption permitted, and can be applied prospectively or retrospectively. We are currently evaluating the ASU to determine its impact on our disclosures.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001262039-25-000011:notes:90]
REVENUE RECOGNITION
Disaggregation of Revenue

[0001262039-25-000011:notes:91]
The following table presents our revenue disaggregated by major product and service lines (in millions):

[0001262039-25-000011:notes:92]
|  | Year Ended December 31, |
|  | 2024 |  | 2023 |  | 2022 |
| Product | $ | 1,908.7 |  |  | $ | 1,927.3 |  |  | $ | 1,780.5 |  |
| Service: |  |  |  |  |  |
| Security subscription | 2,316.7 |  |  | 1,898.1 |  |  | 1,427.0 |  |
| Technical support and other | 1,730.4 |  |  | 1,479.4 |  |  | 1,209.9 |  |
| Total service revenue | 4,047.1 |  |  | 3,377.5 |  |  | 2,636.9 |  |
| Total revenue | $ | 5,955.8 |  |  | $ | 5,304.8 |  |  | $ | 4,417.4 |  |

[0001262039-25-000011:notes:93]
Deferred Revenue

[0001262039-25-000011:notes:94]
During 2024 and 2023, we recognized $2.84 billion and $2.27 billion in revenue that was included in the deferred revenue balance as of December 31, 2023 and 2022, respectively.

[0001262039-25-000011:notes:95]
Transaction Price Allocated to the Remaining Performance Obligations

[0001262039-25-000011:notes:96]
As of December 31, 2024, the aggregate amount of the transaction price allocated to remaining performance obligations was $6.42 billion, which was substantially comprised of deferred security subscription and technical support services revenue as well as unbilled contract revenue from non-cancellable contracts that will be recognized in future periods. We expect to recognize approximately $3.31 billion as revenue over the next 12 months and the remainder thereafter.


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0001262039-25-000011:notes:97]
FINANCIAL INSTRUMENTS AND FAIR VALUE
Available-for-Sale Investments

[0001262039-25-000011:notes:98]
The following tables summarize our available-for-sale investments (in millions):

[0001262039-25-000011:notes:99]
|  | December 31, 2024 |
|  | AmortizedCost |  | UnrealizedGains |  | UnrealizedLosses |  | FairValue |
| U.S. government and agency securities | $ | 469.1 |  |  | $ | 0.4 |  |  | $ | — |  |  | $ | 469.5 |  |
| Commercial paper | 428.7 |  |  | 0.2 |  |  | (0.2) |  |  | 428.7 |  |
| Corporate debt securities | 166.4 |  |  | 0.1 |  |  | (0.1) |  |  | 166.4 |  |
| Certificates of deposit and term deposits | 61.8 |  |  | — |  |  | — |  |  | 61.8 |  |
| Total available-for-sale investments | $ | 1,126.0 |  |  | $ | 0.7 |  |  | $ | (0.3) |  |  | $ | 1,126.4 |  |
|  | December 31, 2023 |
|  | AmortizedCost |  | UnrealizedGains |  | UnrealizedLosses |  | FairValue |
| U.S. government and agency securities | $ | 461.5 |  |  | $ | 0.2 |  |  | $ | (0.3) |  |  | $ | 461.4 |  |
| Commercial paper | 401.7 |  |  | 0.2 |  |  | (0.1) |  |  | 401.8 |  |
| Corporate debt securities | 70.0 |  |  | 0.1 |  |  | (0.1) |  |  | 70.0 |  |
| Certificates of deposit and term deposits | 88.2 |  |  | 0.1 |  |  | — |  |  | 88.3 |  |
| Total available-for-sale investments | $ | 1,021.4 |  |  | $ | 0.6 |  |  | $ | (0.5) |  |  | $ | 1,021.5 |  |

[0001262039-25-000011:notes:100]
The following tables show the gross unrealized losses and the related fair values of our available-for-sale investments that have been in a continuous unrealized loss position (in millions):

[0001262039-25-000011:notes:101]
|  | December 31, 2024 |
|  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
|  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |
| U.S. government and agency securities | $ | 27.8 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 27.8 |  |  | $ | — |  |
| Commercial paper | 149.4 |  |  | (0.2) |  |  | — |  |  | — |  |  | 149.4 |  |  | (0.2) |  |
| Corporate debt securities | 63.5 |  |  | (0.1) |  |  | — |  |  | — |  |  | 63.5 |  |  | (0.1) |  |
| Certificates of deposit and term deposits | 10.9 |  |  | — |  |  | — |  |  | — |  |  | 10.9 |  |  | — |  |
| Total available-for-sale investments | $ | 251.6 |  |  | $ | (0.3) |  |  | $ | — |  |  | $ | — |  |  | $ | 251.6 |  |  | $ | (0.3) |  |

[0001262039-25-000011:notes:102]
|  | December 31, 2023 |
|  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
|  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |
| U.S. government and agency securities | $ | 47.1 |  |  | $ | — |  |  | $ | 11.7 |  |  | $ | (0.3) |  |  | $ | 58.8 |  |  | $ | (0.3) |  |
| Commercial paper | 200.8 |  |  | (0.1) |  |  | — |  |  | — |  |  | 200.8 |  |  | (0.1) |  |
| Corporate debt securities | 21.8 |  |  | — |  |  | 26.9 |  |  | (0.1) |  |  | 48.7 |  |  | (0.1) |  |
| Total available-for-sale investments | $ | 269.7 |  |  | $ | (0.1) |  |  | $ | 38.6 |  |  | $ | (0.4) |  |  | $ | 308.3 |  |  | $ | (0.5) |  |

[0001262039-25-000011:notes:103]
The contractual maturities of our investments were (in millions):

[0001262039-25-000011:notes:104]
|  | December 31,2024 |  | December 31,2023 |
| Due within one year | $ | 1,126.4 |  |  | $ | 1,021.5 |  |
| Due within one to three years | — |  |  | — |  |
| Total | $ | 1,126.4 |  |  | $ | 1,021.5 |  |

[0001262039-25-000011:notes:105]
Available-for-sale investments are reported at fair value, with unrealized gains and losses and the related tax impact included as a separate component of stockholders’ equity (deficit) and in comprehensive income. We do not intend to sell any of the securities in an unrealized loss position and it is not more likely than not that we would be required to sell these securities before recovery of their amortized cost basis, which may be at maturity.

[0001262039-25-000011:notes:106]
Realized gains and losses on available-for-sale investments were insignificant in the periods presented.

[0001262039-25-000011:notes:107]
Marketable Equity Securities

[0001262039-25-000011:notes:108]
Our marketable equity securities were $64.2 million and $21.0 million as of December 31, 2024 and December 31, 2023, respectively. The changes in fair value of our marketable equity securities are recorded in other income (expense)—net on the consolidated statements of income. We recognized $26.4 million gain, $4.4 million and $13.1 million of losses in 2024, 2023 and 2022, respectively.

[0001262039-25-000011:notes:109]
Fair Value of Financial Instruments

[0001262039-25-000011:notes:110]
Fair Value Accounting—We apply the following fair value hierarchy for disclosure of the inputs used to measure fair value. This hierarchy prioritizes the inputs into three broad levels:

[0001262039-25-000011:notes:111]
Level 1—Inputs are unadjusted quoted prices in active markets for identical assets or liabilities.

[0001262039-25-000011:notes:112]
Level 2—Inputs are quoted prices for similar assets and liabilities in active markets or inputs that are observable for the assets or liabilities, either directly or indirectly through market corroboration, for substantially the full term of the financial instruments.

[0001262039-25-000011:notes:113]
Level 3—Unobservable inputs based on our own assumptions used to measure assets and liabilities at fair value. The inputs require significant management judgment or estimation.

[0001262039-25-000011:notes:114]
We measure the fair value of money market funds, certain U.S. government and agency securities and marketable equity securities using quoted prices in active markets for identical assets. The fair value of all other financial instruments was based on quoted prices for similar assets in active markets, or model-driven valuations using significant inputs derived from or corroborated by observable market data.

[0001262039-25-000011:notes:115]
We classify investments within Level 1 if quoted prices are available in active markets for identical securities.

[0001262039-25-000011:notes:116]
We classify items within Level 2 if the investments are valued using model-driven valuations using observable inputs such as quoted market prices, benchmark yields, reported trades, broker/dealer quotes or alternative pricing sources with reasonable levels of price transparency. Investments are held by custodians who obtain investment prices from a third-party pricing provider that incorporates standard inputs in various asset price models.

[0001262039-25-000011:notes:117]
Assets Measured at Fair Value on a Recurring Basis

[0001262039-25-000011:notes:118]
The following tables present the fair value of our financial assets measured at fair value on a recurring basis (in millions):

[0001262039-25-000011:notes:119]
|  | December 31, 2024 |  | December 31, 2023 |
|  | AggregateFairValue |  | QuotedPrices inActiveMarkets ForIdenticalAssets |  | SignificantOtherObservableRemainingInputs |  | SignificantOtherUnobservableRemainingInputs |  | AggregateFairValue |  | QuotedPrices inActiveMarkets ForIdenticalAssets |  | SignificantOtherObservableRemainingInputs |  | SignificantOtherUnobservableRemainingInputs |
|  |  |  | (Level 1) |  | (Level 2) |  | (Level 3) |  |  |  | (Level 1) |  | (Level 2) |  | (Level 3) |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. government and agency securities | $ | 469.5 |  |  | $ | 464.5 |  |  | $ | 5.0 |  |  | $ | — |  |  | $ | 501.4 |  |  | $ | 433.3 |  |  | $ | 68.1 |  |  | $ | — |  |
| Commercial paper | 488.4 |  |  | — |  |  | 488.4 |  |  | — |  |  | 472.2 |  |  | — |  |  | 472.2 |  |  | — |  |
| Corporate debt securities | 166.4 |  |  | — |  |  | 166.4 |  |  | — |  |  | 73.0 |  |  | — |  |  | 73.0 |  |  | — |  |
| Certificates of deposit and term deposits | 61.8 |  |  | — |  |  | 61.8 |  |  | — |  |  | 104.8 |  |  | — |  |  | 104.8 |  |  | — |  |
| Money market funds | 296.1 |  |  | 296.1 |  |  | — |  |  | — |  |  | 277.1 |  |  | 277.1 |  |  | — |  |  | — |  |
| Marketable equity securities | 64.2 |  |  | 64.2 |  |  | — |  |  | — |  |  | 21.0 |  |  | 21.0 |  |  | — |  |  | — |  |
| Total | $ | 1,546.4 |  |  | $ | 824.8 |  |  | $ | 721.6 |  |  | $ | — |  |  | $ | 1,449.5 |  |  | $ | 731.4 |  |  | $ | 718.1 |  |  | $ | — |  |
| Reported as: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents | $ | 355.8 |  |  |  |  |  |  |  |  | $ | 407.0 |  |  |  |  |  |  |  |
| Marketable equity securities | 64.2 |  |  |  |  |  |  |  |  | 21.0 |  |  |  |  |  |  |  |
| Short-term investments | 1,126.4 |  |  |  |  |  |  |  |  | 1,021.5 |  |  |  |  |  |  |  |
| Total | $ | 1,546.4 |  |  |  |  |  |  |  |  | $ | 1,449.5 |  |  |  |  |  |  |  |

[0001262039-25-000011:notes:120]
There were no transfers between Level 1 and Level 2 of the fair value hierarchy during the years ended December 31, 2024 and December 31, 2023.


## us-gaap:InventoryDisclosureTextBlock

[0001262039-25-000011:notes:121]
INVENTORY
Inventory, net of reserves, consisted of (in millions):

[0001262039-25-000011:notes:122]
|  | December 31,2024 |  | December 31,2023 |
| Raw materials | $ | 90.9 |  |  | $ | 92.1 |  |
| Work in process | 4.1 |  |  | 7.7 |  |
| Finished goods | 220.5 |  |  | 385.0 |  |
| Inventory | $ | 315.5 |  |  | $ | 484.8 |  |

[0001262039-25-000011:notes:123]
The excess and obsolete inventory reserve was $144.8 million and $89.2 million as of December 31, 2024 and 2023, respectively. Inventory write-downs related to excess and obsolete inventory were $37.1 million and $35.8 million for the year ended December 31, 2024 and 2023, respectively, and not material for the year ended December 31, 2022. They were recorded in cost of product revenue on the consolidated statements of income.


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001262039-25-000011:notes:124]
PROPERTY AND EQUIPMENT—Net
Property and equipment—net consisted of (in millions):

[0001262039-25-000011:notes:125]
|  | December 31,2024 |  | December 31,2023 |
| Land | $ | 500.6 |  |  | $ | 351.7 |  |
| Buildings and improvements | 801.4 |  |  | 595.5 |  |
| Computer equipment and software | 279.1 |  |  | 261.1 |  |
| Leasehold improvements | 64.3 |  |  | 61.4 |  |
| Evaluation units | 31.8 |  |  | 30.8 |  |
| Furniture and fixtures | 36.4 |  |  | 33.6 |  |
| Construction-in-progress | 52.0 |  |  | 63.3 |  |
| Total property and equipment | 1,765.6 |  |  | 1,397.4 |  |
| Less: accumulated depreciation | (416.1) |  |  | (353.0) |  |
| Property and equipment—net | $ | 1,349.5 |  |  | $ | 1,044.4 |  |

[0001262039-25-000011:notes:126]
During 2024, we purchased certain real estate in California, Georgia and New York, United States, and Alberta, Canada, totaling $295.8 million. The purchases were accounted for under the asset acquisition method. The costs of the assets allocated to land, buildings and improvements and furniture and fixtures were $149.0 million, $145.7 million and $1.1 million, respectively, based on their relative fair values.

[0001262039-25-000011:notes:127]
Depreciation expense was $99.7 million, $94.5 million and $81.0 million in 2024, 2023 and 2022, respectively.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001262039-25-000011:notes:128]
INVESTMENTS IN PRIVATELY HELD COMPANIES
Linksys Holdings, Inc.

[0001262039-25-000011:notes:129]
During 2021, we invested $160.0 million in cash for shares of the Series A Preferred Stock of Linksys for a 50.8% ownership interest in outstanding equity of Linksys. As of December 31, 2024 and 2023, our ownership interest remained the same. Linksys provides router connectivity solutions to the consumer and small business markets.

[0001262039-25-000011:notes:130]
We have concluded that our investment in Linksys is an in-substance common stock investment and that we do not hold an absolute controlling financial interest in Linksys, but that we have the ability to exercise significant influence over the operating and financial policies of Linksys. Therefore, we determined to account for this investment using the equity method of accounting. We record our share of Linksys’ financial results on a three-month lag basis, with the exception of material transactions or events that occur during the intervening period that materially affect the financial position or results of operations. We determined that there was a basis difference between the cost of our investment in Linksys and the amount of underlying equity in net assets of Linksys.

[0001262039-25-000011:notes:131]
Our share of loss of Linksys’ financial results, as well as our share of the amortization of the basis differences, totaled $29.0 million in 2024, which comprised of our proportionate share of Linksys’ financial results and the amortization of the basis differences of $21.0 million, as well as an OTTI charge of $8.0 million recognized in the second quarter of 2024. Our share of loss of Linksys’ financial results and our share of the amortization of the basis differences totaled $42.1 million in 2023. Our loss related to Linksys in 2022 totaled $68.1 million, which comprised of our proportionate share of Linksys’ financial results as well as the amortization of the basis differences of $45.9 million, which included a $17.5 million charge in connection with a valuation allowance established on deferred tax assets at Linksys, and the OTTI charge of $22.2 million recorded during the three months ended December 31, 2022. The loss related to Linksys is recorded in loss from equity method investments on the consolidated statements of income.

[0001262039-25-000011:notes:132]
Due to the presence of impairment indicators, such as a series of operating losses, we evaluated our equity method investment for an OTTI during 2024, 2023 and 2022. We considered various factors in determining whether an OTTI has occurred, including Linksys’ financial results, operating history, our ability and intent to hold the investment until its fair value recovers, the implied revenue valuation multiples compared to guideline public companies, the discounted cash flows analysis, Linksys’ ability to achieve milestones and any notable operational and strategic changes. In connection with our evaluation as of June 30, 2024 and December 31, 2022, we noted that certain factors were present that indicated that the equity method investment’s decline in value was OTTI, primarily driven by Linksys’ continuous losses, decrease in revenue and operating

[0001262039-25-000011:notes:133]
results, then current forecasted results for the foreseeable future as compared to the expected performance at the time of the investments, and the results of a discounted cash flows analysis. To determine the fair value of our investment in Linksys, we utilized a market approach referencing revenue multiples from publicly traded peer companies and concluded that the estimated fair value of the investment was lower than its carrying value. During the three months ended June 30, 2024 and December 31, 2022, we recorded non-cash impairment charge of $8.0 million and $22.2 million, respectively, on our equity method investment in Linksys. In connection with our evaluation as of December 31, 2024 and 2023, we determined that an additional OTTI has not occurred.

[0001262039-25-000011:notes:134]
The carrying amount of our Linksys investment was $13.2 million and $42.2 million as of December 31, 2024 and 2023, respectively, and the investment was included in other assets on our consolidated balance sheets.

[0001262039-25-000011:notes:135]
Refer to Note 17. Subsequent Events, for additional information on our acquisition of Linksys.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001262039-25-000011:notes:136]
BUSINESS COMBINATIONS
2024 Acquisitions

[0001262039-25-000011:notes:137]
Lacework Inc.

[0001262039-25-000011:notes:138]
On August 1, 2024, we closed an acquisition of Lacework Inc. (“Lacework”), a privately held data-driven cloud security company, for $152.3 million in cash. We acquired Lacework with a goal of offering its Cloud-Native Application Protection Platform solution separately as well as integrated with our existing portfolio, forming a comprehensive, AI-driven cloud security platform available from a single vendor, which will help customers identify, prioritize and remediate risks and threats in complex cloud-native infrastructure from code to cloud.

[0001262039-25-000011:notes:139]
Under the acquisition method of accounting in accordance with ASC 805, the total preliminary purchase price was allocated to Lacework’s identifiable tangible and intangible assets acquired and liabilities assumed based on their estimated fair values using management’s best estimates and assumptions to assign fair value as of the acquisition date. The following table provides the assets acquired and liabilities assumed as of the date of acquisition:

[0001262039-25-000011:notes:140]
| (in millions) | Estimated Fair Value |
| ASSETS |  |
| Cash | $ | 6.2 |  |
| Accounts receivable—net | 14.8 |  |
| Prepaid expenses and other current assets | 9.6 |  |
| Deferred tax assets | 244.4 |  |
| Other intangible assets | 61.3 |  |
| TOTAL ASSETS | $ | 336.3 |  |
| LIABILITIES |  |
| Accounts payable | $ | 2.5 |  |
| Deferred revenue | 37.5 |  |
| Accrued payroll and compensation | 12.0 |  |
| Accrued and other current liabilities | 25.5 |  |
| Other liabilities | 0.2 |  |
| TOTAL LIABILITIES | $ | 77.7 |  |
| Gain on bargain purchase | $ | 106.3 |  |
| Net purchase consideration | $ | 152.3 |  |

[0001262039-25-000011:notes:141]
The excess of the fair values of the net assets acquired over the net purchase consideration was recorded as a gain on bargain purchase within other income, net on the consolidated statements of income. The gain on bargain purchase occurred primarily due to the recognition of the deferred tax assets. The deferred tax assets were comprised primarily of pre-acquisition federal net operating loss carryforwards with an indefinite carryforward period.

[0001262039-25-000011:notes:142]
Identified intangible assets acquired and their estimated useful lives (in years) as of August 1, 2024, were as follows (in millions, except years):

[0001262039-25-000011:notes:143]
|  | Fair Value |  | Estimated Useful Life (in years) |
| Developed technology (1) | $ | 39.5 |  |  | 5.0 |
| Customer relationships | 7.5 |  |  | 5.0 |
| Trade name | 4.3 |  |  | 5.0 |
| Backlog | 10.0 |  |  | 3.0 |
| Total identified intangible assets: | $ | 61.3 |  |  |  |
| (1) Developed technology is Lacework’s CNAPP solution. We valued the developed technology using the relief-from-royalty method under the income approach. This method reflects the present value of the projected cash flows that are expected to be generated by the developed technology. The economic useful life was determined based on the technology cycle as well as the cash flows over the forecast period. |

[0001262039-25-000011:notes:144]
Our estimates and assumptions are subject to change within the measurement period, which is up to 12 months after the acquisition date. The allocation of the purchase price for this acquisition has been prepared on a preliminary basis and changes to the allocation of certain assets and liabilities may occur as additional information becomes available. The primary area of the purchase price that is not yet finalized is related to income taxes.

[0001262039-25-000011:notes:145]
The operating results of the acquired company were included in our consolidated financial statements from the date of acquisition, which was August 1, 2024. For the period from August 2, 2024 through December 31, 2024, Lacework contributed $31.1 million of revenue and $45.8 million of a net loss. Acquisition-related costs for this acquisition were not material and were recorded as general and administrative expense.

[0001262039-25-000011:notes:146]
Next DLP Holdings Limited

[0001262039-25-000011:notes:147]
On August 5, 2024, we completed the acquisition of Next DLP Holdings Limited (“Next DLP”), a privately held insider risk and data loss prevention company, for approximately $105.0 million in cash. We acquired Next DLP to improve our position in the standalone enterprise DLP market and strengthen our leadership in integrated DLP markets within endpoint and SASE.

[0001262039-25-000011:notes:148]
This acquisition was accounted for as a business combination using the acquisition method of accounting. The total preliminary purchase price was allocated to Next DLP’s identifiable tangible and intangible assets acquired and liabilities assumed based on their estimated fair values using management’s best estimates and assumptions to assign fair value as of the acquisition date. Of the total preliminary purchase price, $82.6 million was allocated to goodwill, $13.5 million was allocated to developed technology intangible asset, $10.5 million was allocated to customer relationships intangible asset, offset by $1.6 million of net liabilities assumed, which predominantly included deferred revenue and deferred tax liabilities. Goodwill recorded in connection with this acquisition represents the value we expect to be created through expansion into markets within our existing business, and the anticipated operational synergies, and goodwill is not expected to be deductible for tax purposes. Acquisition-related costs related to this acquisition were not material and were recorded as general and administrative expense.

[0001262039-25-000011:notes:149]
Our estimates and assumptions are subject to change within the measurement period, which is up to 12 months after the acquisition date. The allocation of the purchase price for this acquisition has been prepared on a preliminary basis and changes to the allocation of certain assets and liabilities may occur as additional information becomes available. The primary areas of the purchase price that are not yet finalized are related to income taxes and the valuation of acquired assets and assumed liabilities.

[0001262039-25-000011:notes:150]
Pro Forma Financial Information

[0001262039-25-000011:notes:151]
The following unaudited pro forma financial information presents the combined results of operations of Fortinet, Inc., Lacework and Next DLP, as if Lacework and Next DLP had been acquired as of the beginning of business on January 1, 2023. The unaudited pro forma financial information is presented for informational purposes only and is not necessarily indicative of our consolidated results of operations of the combined business that would have been achieved if the acquisitions had taken place at the beginning of business on January 1, 2023, or of the results of our future operations of the combined business. The following unaudited pro forma financial information for all periods presented includes purchase accounting adjustments for amortization of acquired intangible assets, the gain on bargain purchase, and various related tax impacts (in millions):

[0001262039-25-000011:notes:152]
|  | Year Ended December 31, |
|  | 2024 |  | 2023 |  |  |
| Pro forma revenue | $ | 6,016.8 |  |  | $ | 5,404.3 |  |  |  |
| Pro forma net income | $ | 1,468.2 |  |  | $ | 1,017.5 |  |  |  |

[0001262039-25-000011:notes:153]
Perception Point Ltd.

[0001262039-25-000011:notes:154]
On December 5, 2024, we closed an acquisition of certain assets and liabilities of Perception Point Ltd., a business specializing in advanced collaboration and email security, for $33.7 million in cash. This acquisition was accounted for as a business combination using the acquisition method of accounting. Of the purchase price, $24.5 million was allocated to goodwill, $9.5 million was allocated to developed technology intangible asset, $6.5 million was allocated to customer relationships intangible asset, and $6.8 million was allocated to other net liabilities assumed, which predominantly include deferred revenue. Goodwill recorded in connection with this acquisition is primarily attributable to the assembled workforce acquired and the anticipated operational synergies. All acquired goodwill is expected to be deductible for tax purposes. Acquisition-related costs related to this acquisition were not material and were recorded as general and administrative expense.

[0001262039-25-000011:notes:155]
2022 Acquisitions

[0001262039-25-000011:notes:156]
Network Detection and Response Business

[0001262039-25-000011:notes:157]
On December 22, 2022, we closed an acquisition of certain assets and liabilities of a business specializing in network detection and response for $18.0 million in cash. This acquisition was accounted for as a business combination using the acquisition method of accounting. Of the purchase price, $5.8 million was allocated to goodwill, $10.5 million was allocated to developed technology intangible asset, $10.0 million was allocated to customer relationships intangible asset and $8.3 million was allocated to other net liabilities assumed, which predominantly include deferred revenue. Goodwill recorded in connection with this acquisition is primarily attributable to the assembled workforce acquired and the anticipated operational synergies. All acquired goodwill is expected to be deductible for tax purposes. Acquisition-related costs related to this acquisition were not material and were recorded as general and administrative expense.

[0001262039-25-000011:notes:158]
Additional acquisition-related information

[0001262039-25-000011:notes:159]
The operating results of the acquired companies are included in our consolidated statements of income from the respective dates of acquisition. Acquisition-related costs related to each acquisition were not material. Pro forma information has not been presented, except for Lacework and Next DLP as disclosed above, as the impact of these acquisitions, individually and in the aggregate, in each year were not material to our consolidated financial statements.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001262039-25-000011:notes:160]
GOODWILL AND OTHER INTANGIBLE ASSETS—Net
Goodwill

[0001262039-25-000011:notes:161]
The following table presents the changes in the carrying amount of goodwill (in millions):

[0001262039-25-000011:notes:162]
|  | Amount |
| Balance—December 31, 2023 | $ | 126.5 |  |
| Additions due to business combinations | 110.9 |  |
| Foreign currency translation adjustments | (2.0) |  |
| Balance—December 31, 2024 | $ | 235.4 |  |

[0001262039-25-000011:notes:163]
There were no impairments to goodwill during 2024, 2023 and 2022 or any previous periods.

[0001262039-25-000011:notes:164]
Other Intangible Assets—Net

[0001262039-25-000011:notes:165]
The following tables present other intangible assets—net (in millions, except years):

[0001262039-25-000011:notes:166]
|  | December 31, 2024 |
|  | Weighted-Average Useful Life (in Years) |  | Gross |  | Accumulated Amortization |  | Net |
| Other intangible assets—net: |  |  |  |  |  |  |  |
| Finite-lived intangible assets: |  |  |  |  |  |  |  |
| Developed technologies | 4.4 |  | $ | 141.9 |  |  | $ | 73.7 |  |  | $ | 68.2 |  |
| Customer relationships | 5.5 |  | 53.9 |  |  | 23.0 |  |  | 30.9 |  |
| Trade name | 7.5 |  | 8.8 |  |  | 1.8 |  |  | 7.0 |  |
| Backlog | 2.5 |  | 13.5 |  |  | 4.6 |  |  | 8.9 |  |
| Total other intangible assets—net |  |  | $ | 218.1 |  |  | $ | 103.1 |  |  | $ | 115.0 |  |

[0001262039-25-000011:notes:167]
|  | December 31, 2023 |
|  | Weighted-Average Useful Life (in Years) |  | Gross |  | Accumulated Amortization |  | Net |
| Other intangible assets—net: |  |  |  |  |  |  |  |
| Finite-lived intangible assets: |  |  |  |  |  |  |  |
| Developed technologies | 4.4 |  | $ | 79.4 |  |  | $ | 60.6 |  |  | $ | 18.8 |  |
| Customer relationships | 7.1 |  | 30.4 |  |  | 17.7 |  |  | 12.7 |  |
| Trade name | 10.0 |  | 5.0 |  |  | 1.2 |  |  | 3.8 |  |
| Backlog | 1.0 |  | 3.9 |  |  | 3.9 |  |  | — |  |
| Total other intangible assets—net |  |  | $ | 118.7 |  |  | $ | 83.4 |  |  | $ | 35.3 |  |

[0001262039-25-000011:notes:168]
Amortization expense of finite-lived intangible assets was $23.1 million, $18.9 million and $23.3 million in 2024, 2023, and 2022, respectively.

[0001262039-25-000011:notes:169]
The following table summarizes estimated future amortization expense of finite-lived intangible assets—net (in millions):

[0001262039-25-000011:notes:170]
| Year Ending December 31, | Amount |
| 2025 | $ | 39.7 |  |
| 2026 | 26.7 |  |
| 2027 | 21.4 |  |
| 2028 | 15.6 |  |
| 2029 | 7.7 |  |
| Thereafter | 3.9 |  |
| Total | $ | 115.0 |  |


## us-gaap:EarningsPerShareTextBlock

[0001262039-25-000011:notes:171]
NET INCOME PER SHARE
Basic net income per share is computed by dividing net income attributable to Fortinet, Inc., by the weighted-average number of shares of common stock outstanding during the period. Diluted net income per share is computed by dividing net income attributable to Fortinet, Inc. by the weighted-average number of shares of common stock outstanding during the period, plus the dilutive effects of restricted stock units RSUs, stock options and PSUs. Dilutive shares of common stock are determined by applying the treasury stock method.

[0001262039-25-000011:notes:172]
A reconciliation of the numerator and denominator used in the calculation of basic and diluted net income per share attributable to Fortinet, Inc. is (in millions, except per share amounts):

[0001262039-25-000011:notes:173]
|  | Year Ended December 31, |
|  | 2024 |  | 2023 |  | 2022 |
| Numerator: |  |  |  |  |  |
| Net income including non-controlling interests | $ | 1,745.2 |  |  | $ | 1,147.8 |  |  | $ | 856.6 |  |
| Net loss attributable to non-controlling interests | — |  |  | — |  |  | (0.7) |  |
| Net income attributable to Fortinet, Inc. | $ | 1,745.2 |  |  | $ | 1,147.8 |  |  | $ | 857.3 |  |
| Denominator: |  |  |  |  |  |
| Basic shares: |  |  |  |  |  |
| Weighted-average common stock outstanding-basic | 764.4 |  |  | 778.6 |  |  | 791.4 |  |
| Diluted shares: |  |  |  |  |  |
| Weighted-average common stock outstanding-basic | 764.4 |  |  | 778.6 |  |  | 791.4 |  |
| Effect of potentially dilutive securities: |  |  |  |  |  |
| RSUs | 2.4 |  |  | 3.3 |  |  | 6.0 |  |
| Stock options | 4.7 |  |  | 6.2 |  |  | 7.9 |  |
| PSUs | 0.4 |  |  | 0.1 |  |  | — |  |
| Weighted-average shares used to compute diluted net income per share attributable to Fortinet, Inc. | 771.9 |  |  | 788.2 |  |  | 805.3 |  |
| Net income per share attributable to Fortinet, Inc.: |  |  |  |  |  |
| Basic | $ | 2.28 |  |  | $ | 1.47 |  |  | $ | 1.08 |  |
| Diluted | $ | 2.26 |  |  | $ | 1.46 |  |  | $ | 1.06 |  |

[0001262039-25-000011:notes:174]
The following weighted-average shares of common stock were excluded from the computation of diluted net income per share attributable to Fortinet, Inc. for the periods presented, as their effect would have been antidilutive (in millions):

[0001262039-25-000011:notes:175]
|  | Year Ended December 31, |
|  | 2024 |  | 2023 |  | 2022 |
| RSUs | 0.2 |  |  | 0.7 |  |  | 1.0 |  |
| Stock options | 2.5 |  |  | 2.8 |  |  | 1.5 |  |
| PSUs | 0.1 |  |  | 0.1 |  |  | — |  |
| Total | 2.8 |  |  | 3.6 |  |  | 2.5 |  |


## us-gaap:LesseeOperatingLeasesTextBlock

[0001262039-25-000011:notes:176]
LEASES
We have operating leases for offices, research and development facilities and data centers. Our leases have remaining terms that range from less than one year to approximately five years, some of which include one or more options to renew, with renewal terms of up to seven years. Unless and until we are reasonably certain we will exercise these renewal options, we do not include renewal options in our lease terms for calculating our lease liability, as the renewal options allow us to maintain operational flexibility. Our finance leases were not material to our consolidated financial statements.

[0001262039-25-000011:notes:177]
The components of lease expense were (in millions):

[0001262039-25-000011:notes:178]
|  | Year Ended December 31, |
|  | 2024 |  | 2023 |  | 2022 |
| Operating lease expense | $ | 44.5 |  |  | $ | 43.0 |  |  | $ | 37.1 |  |
| Variable lease expense (1) | 7.4 |  |  | 5.8 |  |  | 3.7 |  |
| Short-term lease expense | 10.2 |  |  | 9.3 |  |  | 5.6 |  |
| Total lease expense | $ | 62.1 |  |  | $ | 58.1 |  |  | $ | 46.4 |  |
| (1) Variable lease expense for the years ended December 31, 2024, 2023 and 2022 predominantly included common area maintenance charges, real estate taxes, certain parking expense, utilities based on actual usage and insurance costs. |

[0001262039-25-000011:notes:179]
Supplemental balance sheet information related to our operating leases was (in millions, except lease term and discount rate):

[0001262039-25-000011:notes:180]
|  | Classification |  | December 31,2024 |  | December 31,2023 |
| Operating lease ROU assets – non-current | Other assets |  | $ | 72.2 |  |  | $ | 76.0 |  |
| Operating lease liabilities – current | Accrued liabilities |  | $ | 32.7 |  |  | $ | 33.4 |  |
| Operating lease liabilities – non-current | Other liabilities |  | 46.4 |  |  | 45.7 |  |
| Total operating lease liabilities |  |  | $ | 79.1 |  |  | $ | 79.1 |  |
| Weighted average remaining lease term in years – operating leases |  |  | 3.0 |  | 3.1 |
| Weighted average discount rate – operating leases |  |  | 4.2 | % |  | 4.5 | % |

[0001262039-25-000011:notes:181]
Supplemental cash flow information related to leases was (in millions):

[0001262039-25-000011:notes:182]
|  | Year Ended December 31, |
|  | 2024 |  | 2023 |  | 2022 |
| Cash paid for amounts included in the measurement of lease liabilities |  |  |  |  |  |
| Operating cash flows used for operating leases | $ | 38.6 |  |  | $ | 40.0 |  |  | $ | 33.8 |  |

[0001262039-25-000011:notes:183]
Maturities of operating lease liabilities as of December 31, 2024 were (in millions):

[0001262039-25-000011:notes:184]
| Year Ending December 31, | Amount |
| 2025 | $ | 34.9 |  |
| 2026 | 20.4 |  |
| 2027 | 13.7 |  |
| 2028 | 11.0 |  |
| 2029 | 4.3 |  |
| Thereafter | — |  |
| Total lease payments | $ | 84.3 |  |
| Less imputed interest | (5.2) |  |
| Total | $ | 79.1 |  |

[0001262039-25-000011:notes:185]
As of December 31, 2024, our operating leases that had been signed but had not yet commenced were not material.


## us-gaap:DebtDisclosureTextBlock

[0001262039-25-000011:notes:186]
DEBT
2026 and 2031 Senior Notes

[0001262039-25-000011:notes:187]
On March 5, 2021, we issued $1.0 billion aggregate principal amount of senior notes (collectively, the “Senior Notes”), consisting of $500.0 million aggregate principal amount of 1.0% notes due March 15, 2026 (the “2026 Senior Notes”) and $500.0 million aggregate principal amount of 2.2% notes due March 15, 2031 (the “2031 Senior Notes”), in an underwritten registered public offering. The Senior Notes are senior unsecured obligations and rank equally with each other in right of payment and with our other outstanding obligations. We may redeem the Senior Notes at any time in whole or in part for cash, at specified redemption prices that include accrued and unpaid interest, if any, and a make-whole premium. However, no make-whole premium will be paid for redemptions of the 2026 Senior Notes on or after February 15, 2026, or the 2031 Senior Notes on or after December 15, 2030. Interest on the Senior Notes is payable on March 15 and September 15 of each year, beginning on September 15, 2021. As of December 31, 2024, the Senior Notes were recorded as long-term debt, net of discount and issuance costs, which are amortized to interest expense over the respective contractual terms of these notes using the effective interest method.

[0001262039-25-000011:notes:188]
The total outstanding debt is summarized below (in millions, except percentages):

[0001262039-25-000011:notes:189]
|  | Maturity |  | Coupon Rate |  | Effective Interest Rate |  | December 31,2024 |
| Debt |  |  |  |  |  |  |  |
| 2026 Senior Notes | March 2026 |  | 1.0 | % |  | 1.3 | % |  | $ | 500.0 |  |
| 2031 Senior Notes | March 2031 |  | 2.2 | % |  | 2.3 | % |  | 500.0 |  |
| Total debt |  |  |  |  |  |  | 1,000.0 |  |
| Less: Unamortized discount and debt issuance costs |  |  |  |  |  |  | 5.7 |  |
| Total long-term debt |  |  |  |  |  |  | $ | 994.3 |  |

[0001262039-25-000011:notes:190]
As of December 31, 2024 and 2023, we accrued interest payable of $4.7 million, and there are no financial covenants with which we must comply. In 2024, 2023 and 2022 we recorded $18.0 million, $17.9 million and $17.9 million of total interest expense in relation to these Senior Notes and repaid $16.0 million of interest in cash, respectively. No interest costs were capitalized in 2024, 2023 and 2022, as the costs that qualified for capitalization were not material.

[0001262039-25-000011:notes:191]
The total estimated fair value of the outstanding Senior Notes was approximately $908.5 million, including accrued and unpaid interest, as of December 31, 2024. The fair value was determined based on observable market prices of identical instruments in less active markets. The estimated fair values are based on Level 2 inputs.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001262039-25-000011:notes:192]
COMMITMENTS AND CONTINGENCIES
The following table summarizes our inventory purchase commitments as of December 31, 2024 (in millions):

[0001262039-25-000011:notes:193]
|  | Total |  | 2025 |  | Thereafter |
| Inventory purchase commitments | $ | 591.1 |  |  | $ | 588.9 |  |  | $ | 2.2 |  |

[0001262039-25-000011:notes:194]
Inventory Purchase Commitments—We purchase components of our inventory from certain suppliers and use several independent contract manufacturers to provide manufacturing services for our products. During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, we enter into agreements with contract manufacturers and suppliers that allow them to procure inventory based upon criteria as defined by us or establish the parameters defining our requirements. A significant portion of our reported purchase commitments arising from these agreements consists of firm, non-cancelable and unconditional commitments. Certain of these inventory purchase commitments with contract manufacturers and suppliers relate to arrangements to secure supply and pricing for certain product components for multi-year periods. In certain instances, these agreements allow us the option to reschedule and adjust our requirements based on our business needs prior to firm orders being placed.

[0001262039-25-000011:notes:195]
As of December 31, 2024, we had $591.1 million of non-cancelable inventory purchase commitments with our independent contract manufacturers. We recorded a liability for these purchase commitments for quantities in excess of our future estimated demand forecasts, consistent with the valuation of our excess and obsolete inventory. As of December 31, 2024 and December 31, 2023, the liability for these inventory purchase commitments was $54.0 million and $84.7 million,

[0001262039-25-000011:notes:196]
respectively, and was recorded in accrued liabilities on our consolidated balance sheets. The expense related to such accrued liability for inventory purchase commitments was $3.5 million and $85.9 million for the year ended December 31, 2024 and 2023, and not material for the year ended December 31, 2022, and was recorded in cost of product revenue on the consolidated statements of income.

[0001262039-25-000011:notes:197]
Other Contractual Commitments and Open Purchase Orders—In addition to commitments with contract manufacturers, we have open purchase orders and contractual obligations in the ordinary course of business for which we have not received goods or services. A significant portion of our reported purchase commitments consist of non-cancelable commitments. In certain instances, contractual commitments allow us the option to cancel, reschedule and adjust our requirements based on our business needs prior to firm orders being placed. As of December 31, 2024, we had $101.2 million in other contractual commitments having a remaining term in excess of one year that are non-cancelable.

[0001262039-25-000011:notes:198]
Litigation—We are involved in disputes, litigation, and other legal actions. For lawsuits where we are the defendant, we are in the process of defending these litigation matters, and while there can be no assurances and the outcome of certain of these matters is currently not determinable and not predictable, we currently are unaware of any existing claims or proceedings that we believe are likely to have a material adverse effect on our financial position. There are many uncertainties associated with any litigation and these actions or other third-party claims against us may cause us to incur costly litigation fees, costs and substantial settlement charges, and possibly subject us to damages and other penalties. In addition, the resolution of any intellectual property litigation may require us to make royalty payments, which could adversely affect our gross margins in future periods. If any of those events were to occur, our business, financial condition, results of operations, and cash flows could be adversely affected. Litigation is unpredictable and the actual liability in any such matters may be materially different from our current estimates, which could result in the need to adjust any accrued liability and record additional expenses. We accrue for contingencies when we believe that a loss is probable and that we can reasonably estimate the amount of any such loss. These accruals are generally based on a range of possible outcomes that require significant management judgement. If no amount within a range is a better estimate than any other, we accrue the minimum amount. Litigation loss contingency accruals associated with outstanding cases were not material as of December 31, 2024 and 2023.

[0001262039-25-000011:notes:199]
On March 21, 2019, we were sued by Alorica Inc. in Santa Clara County Superior Court in California. Alorica alleged breach of warranty and misrepresentation claims, which we denied. After trial, a jury returned a verdict fully in favor of us and against Alorica on October 4, 2024. Alorica has filed a notice of appeal. We believe that the ultimate outcome of this matter will not materially impact our financial position, results of operations or cash flows. However, any further legal proceedings, including Alorica’s appeal, would be subject to inherent uncertainties, and a future unfavorable ruling could occur. No loss accrual had been recorded as of December 31, 2024 related to this litigation.

[0001262039-25-000011:notes:200]
Indemnification and Other Matters—We enter into indemnification provisions in the ordinary course of business with other companies such as partners, customers, and vendors, where we agree to indemnify, hold harmless, and reimburse the indemnified party for certain losses suffered or incurred by the indemnified party as a result of our activities, including defending against third-party claims asserting various allegations such as product defects, breach of representations or covenants, and infringement of certain IP rights, which may include patents, copyrights, trademarks or trade secrets, and to pay judgments entered on such claims. In some contracts, our exposure under these indemnification provisions is limited by the terms of the contracts to certain defined limits, such as the total amount paid by our customer under the agreement. However, certain agreements include covenants, penalties and indemnification provisions including and beyond indemnification for third-party claims of IP infringement that could potentially expose us to losses in excess of the amount received under the agreement, and in some instances to potential liability that is not contractually limited. Although from time to time there are indemnification claims asserted against us and currently there are pending indemnification claims, to date there have been no material awards under such indemnification provisions.

[0001262039-25-000011:notes:201]
Periodically we, like other security companies and companies in other industries, have experienced, and may experience in the future, cybersecurity threats, malicious activity directed against our information technology infrastructure and unauthorized attempts to gain access to our and our customers’ sensitive information and systems. For example, in the third quarter of 2024, we discovered that an individual gained unauthorized access to a limited number of files stored on Fortinet’s instance of a third-party cloud-based shared file drive, which included limited data related to a small number of Fortinet customers. We have completed our investigation of this incident and we do not currently believe that it had a material impact on our business or that of any of our customers. We are currently not aware of any significant claims arising from this matter.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001262039-25-000011:notes:202]
EQUITY PLANS AND SHARE REPURCHASE PROGRAM
Stock-Based Compensation Plans

[0001262039-25-000011:notes:203]
We have one primary stock incentive plan, the 2009 EIP, under which we have granted RSUs, stock options and PSUs.

[0001262039-25-000011:notes:204]
Our board of directors approved the 2009 EIP in 2009 and amended the plan in 2019. The maximum aggregate number of shares that may be issued under the 2009 EIP is 239,367,655 shares; provided, however, that only 67,500,000 shares may be issued or transferred pursuant to new awards granted on or following the effective date of the 2009 EIP. We may grant awards to employees, directors and other service providers. In the case of an incentive stock option granted to an employee who, at the time of the grant, owns stock representing more than 10% of the voting power of all classes of stock, the exercise price shall be no less than 110% of the fair market value per share on the date of grant and expire no more than five years from the date of grant, and options granted to any other employee, the per share exercise price shall be no less than 100% of the closing stock price on the date of grant. In the case of a non-statutory stock option and options granted to other service providers, the per share exercise price shall be no less than 100% of the fair market value per share on the date of grant. Options granted to individuals owning less than 10% of the total combined voting power of all classes of stock generally have a contractual term of no more than ten years and options generally vest over four years.

[0001262039-25-000011:notes:205]
As of December 31, 2024, there were a total of 50.7 million shares of common stock available for grant under the 2009 EIP.

[0001262039-25-000011:notes:206]
Restricted Stock Units

[0001262039-25-000011:notes:207]
The following table summarizes the activity and related information for RSUs for the periods presented below (in millions, except per share amounts):

[0001262039-25-000011:notes:208]
|  | Restricted Stock Units Outstanding |
|  | Number of Shares |  | Weighted-Average Grant Date Fair Value per Share |
| Balance—December 31, 2021 | 15.7 |  |  | $ | 27.06 |  |
| Granted | 4.1 |  |  | 58.09 |  |
| Forfeited | (1.1) |  |  | 34.94 |  |
| Vested | (8.2) |  |  | 23.69 |  |
| Balance—December 31, 2022 | 10.5 |  |  | 40.94 |  |
| Granted | 4.8 |  |  | 60.14 |  |
| Forfeited | (0.8) |  |  | 49.85 |  |
| Vested | (5.4) |  |  | 35.47 |  |
| Balance—December 31, 2023 | 9.1 |  |  | 53.61 |  |
| Granted | 4.7 |  |  | 71.25 |  |
| Forfeited | (1.0) |  |  | 61.98 |  |
| Vested | (4.4) |  |  | 49.50 |  |
| Balance—December 31, 2024 | 8.4 |  |  | $ | 64.70 |  |

[0001262039-25-000011:notes:209]
Stock compensation expense is recognized on a straight-line basis over the vesting period of each RSU. As of December 31, 2024, total compensation expense related to unvested RSUs granted to employees and non-employees under the 2009 EIP, but not yet recognized, was $467.2 million, with a weighted-average remaining vesting period of 2.7 years.

[0001262039-25-000011:notes:210]
RSUs settle into shares of common stock upon vesting. Upon the vesting of the RSUs, we net-settle the RSUs and withhold a portion of the shares to satisfy employee withholding tax requirements. The payment of the withheld taxes to the tax authorities is reflected as a financing activity within the consolidated statements of cash flows.

[0001262039-25-000011:notes:211]
The following summarizes the number and value of the shares withheld for employee taxes (in millions):

[0001262039-25-000011:notes:212]
|  | Year Ended December 31, |
|  | 2024 |  | 2023 |  | 2022 |
| Shares withheld for taxes | 1.5 |  |  | 1.8 |  |  | 2.7 |  |
| Amount withheld for taxes | $ | 101.0 |  |  | $ | 112.5 |  |  | $ | 160.4 |  |

[0001262039-25-000011:notes:213]
Employee Stock Options

[0001262039-25-000011:notes:214]
In determining the fair value of our employee stock options, we use the Black-Scholes model, which employs the following assumptions.

[0001262039-25-000011:notes:215]
Expected Term—The expected term represents the period that our stock-based awards are expected to be outstanding. We believe that we have sufficient historical experience for determining the expected term of the stock option award, and therefore, we calculated our expected term based on historical experience instead of using the simplified method.

[0001262039-25-000011:notes:216]
Expected Volatility—The expected volatility of our common stock is based on our weighted-average implied and historical volatility.

[0001262039-25-000011:notes:217]
Fair Value of Common Stock—The fair value of our common stock is the closing sales price of the common stock effective on the date of grant.

[0001262039-25-000011:notes:218]
Risk-Free Interest Rate—We base the risk-free interest rate on the implied yield available on U.S. Treasury zero-coupon issues with an equivalent remaining term.

[0001262039-25-000011:notes:219]
Expected Dividend—The expected dividend weighted-average assumption is zero.

[0001262039-25-000011:notes:220]
The following table summarizes the weighted-average assumptions relating to our employee stock options:

[0001262039-25-000011:notes:221]
|  | Year Ended December 31, |
|  | 2024 |  | 2023 |  | 2022 |
| Expected term in years | 4.5 |  | 4.4 |  | 4.4 |
| Volatility | 42.6 | % |  | 42.0 | % |  | 41.6 | % |
| Risk-free interest rate | 4.3 | % |  | 4.2 | % |  | 2.2 | % |
| Dividend rate | — | % |  | — | % |  | — | % |

[0001262039-25-000011:notes:222]
The following table summarizes the stock option activity and related information for the periods presented below (in millions, except exercise prices and contractual life):

[0001262039-25-000011:notes:223]
|  | Options Outstanding |
|  | Numberof Shares |  | Weighted-AverageExercisePrice |  | Weighted-AverageRemainingContractualLife (Years) |  | AggregateIntrinsicValue |
| Balance—December 31, 2021 | 13.7 |  |  | $ | 18.57 |  |  | 4.0 |  | 729.9 |  |
| Granted | 1.7 |  |  | 60.26 |  |  |  |  |  |
| Forfeited | (0.2) |  |  | 37.03 |  |  |  |  |  |
| Exercised | (2.0) |  |  | 13.10 |  |  |  |  |  |
| Balance—December 31, 2022 | 13.2 |  |  | 24.37 |  |  | 3.5 |  | 344.8 |  |
| Granted | 1.3 |  |  | 60.16 |  |  |  |  |  |
| Forfeited | (0.2) |  |  | 49.13 |  |  |  |  |  |
| Exercised | (3.1) |  |  | 14.11 |  |  |  |  |  |
| Balance—December 31, 2023 | 11.2 |  |  | 31.14 |  |  | 3.3 |  | 315.8 |  |
| Granted | 0.8 |  |  | 68.21 |  |  |  |  |  |
| Forfeited | (0.2) |  |  | 54.74 |  |  |  |  |  |
| Exercised | (3.1) |  |  | 20.30 |  |  |  |  |  |
| Balance—December 31, 2024 | 8.7 |  |  | $ | 37.81 |  |  |  |  |  |
| Options vested and expected to vest—December 31, 2024 | 8.7 |  |  | $ | 37.81 |  |  | 3.1 |  | $ | 493.8 |  |
| Options exercisable—December 31, 2024 | 6.7 |  |  | $ | 30.62 |  |  | 2.4 |  | $ | 429.8 |  |

[0001262039-25-000011:notes:224]
The aggregate intrinsic value represents the difference between the exercise price of stock options and the quoted market price of our common stock at the date of balance sheet for all in-the-money stock options. Stock compensation expense is recognized on a straight-line basis over the vesting period of each stock option. As of December 31, 2024, total compensation expense related to unvested stock options granted to employees but not yet recognized was $44.6 million, with a weighted-average remaining vesting period of 2.4 years.

[0001262039-25-000011:notes:225]
Additional information related to our stock options is summarized below (in millions, except per share amounts):

[0001262039-25-000011:notes:226]
|  | Year Ended December 31, |
|  | 2024 |  | 2023 |  | 2022 |
| Weighted-average fair value per share granted | $ | 27.87 |  |  | $ | 24.20 |  |  | $ | 22.18 |  |
| Intrinsic value of options exercised | $ | 166.9 |  |  | $ | 140.7 |  |  | $ | 88.4 |  |
| Fair value of options vested | $ | 31.3 |  |  | $ | 30.1 |  |  | $ | 24.9 |  |

[0001262039-25-000011:notes:227]
The following table summarizes information about outstanding and exercisable stock options as of December 31, 2024, (in millions, except exercise prices and contractual life):

[0001262039-25-000011:notes:228]
|  |  | Options Outstanding |  | Options Exercisable |
| Range of Exercise Prices |  | NumberOutstanding |  | Weighted-AverageRemainingContractualLife (Years) |  | Weighted-AverageExercisePrice |  | NumberExercisable |  | Weighted-AverageExercisePrice |
| $9.81-$22.72 |  | 2.3 |  |  | 0.8 |  | $ | 14.66 |  |  | 2.3 |  |  | $ | 14.66 |  |
| $22.90-$34.39 |  | 3.1 |  |  | 2.6 |  | 28.85 |  |  | 3.0 |  |  | 28.71 |  |
| $39.68-$61.24 |  | 1.5 |  |  | 5.0 |  | 58.18 |  |  | 0.7 |  |  | 57.58 |  |
| $62.11-$94.02 |  | 1.8 |  |  | 5.0 |  | 65.21 |  |  | 0.7 |  |  | 62.80 |  |
|  |  | 8.7 |  |  |  |  |  |  | 6.7 |  |  |  |

[0001262039-25-000011:notes:229]
Market/Performance-Based PSUs

[0001262039-25-000011:notes:230]
In 2023, we granted market/performance-based PSUs under the 2009 EIP to certain of our executives. Based on the achievement of the market/performance-based vesting conditions during the performance period, the final settlement of the PSUs will range between 0% and 200% of the target shares underlying the PSUs based on the percentile ranking of our total stockholder return over one-, two-, three- and four-year periods among companies included in the S&P 500 Index. 20%, 20%, 20% and 40% of the PSUs vest over one-, two-, three- and four-year service periods, respectively.

[0001262039-25-000011:notes:231]
The following table summarizes the weighted-average assumptions relating to our PSUs for the year ended December 31, 2024 and 2023:

[0001262039-25-000011:notes:232]
|  | Year Ended December 31, |
|  | 2024 |  | 2023 |
| Expected term in years | 2.7 |  | 2.7 |
| Volatility | 45.4 | % |  | 47.5 | % |
| Risk-free interest rate | 4.5 | % |  | 4.6 | % |
| Dividend rate | — | % |  | — | % |

[0001262039-25-000011:notes:233]
We granted approximately 0.3 million shares of PSU awards with a weighted-average grant date fair value of $97.40 per share and $90.96 per share to certain of our executives during the year ended December 31, 2024 and December 31, 2023, respectively. The grant date fair value of these awards was determined using a Monte Carlo simulation pricing model. Approximately 0.1 million shares of PSU awards were vested and approximately 0.1 million shares of PSU awards were forfeited during the year ended December 31, 2024. None of these PSU awards were vested and PSU awards forfeited were immaterial during the year ended December 31, 2023.

[0001262039-25-000011:notes:234]
As of December 31, 2024, total compensation expense related to unvested PSUs that were granted to certain of our executives, but not yet recognized, was $20.9 million. This expense is expected to be amortized on a graded vesting method over a weighted-average vesting period of 2.2 years.

[0001262039-25-000011:notes:235]
Shares Reserved for Future Issuances

[0001262039-25-000011:notes:236]
The following table presents the common stock reserved for future issuance (in millions):

[0001262039-25-000011:notes:237]
|  | December 31,2024 |
| Reserved for future equity award grants | 50.7 |  |
| Outstanding stock options, RSUs and PSUs | 17.5 |  |
| Total common stock reserved for future issuances | 68.2 |  |

[0001262039-25-000011:notes:238]
Stock-Based Compensation Expense

[0001262039-25-000011:notes:239]
Stock-based compensation expense, including stock-based compensation expense related to awards classified as liabilities, is included in costs and expenses (in millions):

[0001262039-25-000011:notes:240]
|  | Year Ended December 31, |
|  | 2024 |  | 2023 |  | 2022 |
| Cost of product revenue | $ | 1.9 |  |  | $ | 1.8 |  |  | $ | 1.7 |  |
| Cost of service revenue | 25.4 |  |  | 23.3 |  |  | 18.8 |  |
| Research and development | 85.9 |  |  | 76.8 |  |  | 64.2 |  |
| Sales and marketing | 105.3 |  |  | 111.8 |  |  | 105.0 |  |
| General and administrative | 41.7 |  |  | 37.9 |  |  | 30.1 |  |
| Total stock-based compensation expense | $ | 260.2 |  |  | $ | 251.6 |  |  | $ | 219.8 |  |

[0001262039-25-000011:notes:241]
The following table summarizes stock-based compensation expense, including stock-based compensation expense related to awards classified as liabilities, by award type (in millions):

[0001262039-25-000011:notes:242]
|  | Year Ended December 31, |
|  | 2024 |  | 2023 |  | 2022 |
| RSUs | $ | 217.2 |  |  | $ | 211.8 |  |  | $ | 195.0 |  |
| Stock options | 28.2 |  |  | 28.8 |  |  | 24.8 |  |
| PSUs | 14.8 |  |  | 11.0 |  |  | — |  |
| Total stock-based compensation expense | $ | 260.2 |  |  | $ | 251.6 |  |  | $ | 219.8 |  |

[0001262039-25-000011:notes:243]
Total income tax benefit associated with stock-based compensation that is recognized in the consolidated statements of income is (in millions):

[0001262039-25-000011:notes:244]
|  | Year Ended December 31, |
|  | 2024 |  | 2023 |  | 2022 |
| Income tax benefit associated with stock-based compensation | $ | 57.3 |  |  | $ | 55.5 |  |  | $ | 48.6 |  |

[0001262039-25-000011:notes:245]
Share Repurchase Program

[0001262039-25-000011:notes:246]
In January 2016, our board of directors approved the Repurchase Program, which authorized the repurchase of up to $200.0 million of our outstanding common stock through December 31, 2017. From 2016 through 2022, our board of directors approved increases to our Repurchase Program by various amounts and extended the term to February 28, 2023, bringing the aggregated amount authorized to $5.25 billion. In February 2023, our board of directors approved an extension of the Repurchase Program to February 29, 2024. In April 2023 and July 2023, our board of directors approved $1.0 billion and $500.0 million increases in the authorized stock repurchase amount under the Repurchase Program, bringing the aggregate amount authorized to be repurchased to $6.75 billion. In January 2024, our board of directors approved a $500.0 million increase in the authorized stock repurchase amount under the Repurchase Program, bringing the aggregate amount authorized to be repurchased to $7.25 billion of our outstanding common stock. In February 2024, our board of directors approved an extension of the Repurchase Program to February 28, 2025. In October 2024, our board of directors approved a $1.0 billion increase in the authorized stock repurchase amount under the Repurchase Program and extended the term of the Repurchase Program to February 28, 2026, bringing the aggregate amount authorized to be repurchased to $8.25 billion of our outstanding common stock through February 28, 2026. Under the Repurchase Program, share repurchases may be made by us from time to 
time in privately negotiated transactions or in open market transactions. The Repurchase Program does not require us to purchase a minimum number of shares, and may be suspended, modified or discontinued at any time without prior notice. In 2024, we repurchased less than 0.1 million shares of common stock under the Repurchase Program in open market transactions for an aggregate purchase price of $0.6 million. As of December 31, 2024, $2.03 billion remained available for future share repurchases under the Repurchase Program.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001262039-25-000011:notes:247]
INCOME TAXES 
Income before income taxes and loss from equity method investments consisted of (in millions):

[0001262039-25-000011:notes:248]
|  | Year Ended December 31, |
|  | 2024 |  | 2023 |  | 2022 |
| Domestic | $ | 1,929.2 |  |  | $ | 1,195.0 |  |  | $ | 873.8 |  |
| Foreign | 129.3 |  |  | 138.7 |  |  | 81.7 |  |
| Total income before income taxes and loss from equity method investments | $ | 2,058.5 |  |  | $ | 1,333.7 |  |  | $ | 955.5 |  |

[0001262039-25-000011:notes:249]
The provision for (benefit from) income taxes consisted of (in millions):

[0001262039-25-000011:notes:250]
|  | Year Ended December 31, |
|  | 2024 |  | 2023 |  | 2022 |
| Current: |  |  |  |  |  |
| Federal | $ | 444.2 |  |  | $ | 398.5 |  |  | $ | 218.5 |  |
| State | 25.8 |  |  | 27.7 |  |  | 19.1 |  |
| Foreign | 36.8 |  |  | 24.3 |  |  | 18.8 |  |
| Total current | $ | 506.8 |  |  | $ | 450.5 |  |  | $ | 256.4 |  |
| Deferred: |  |  |  |  |  |
| Federal | $ | (210.7) |  |  | $ | (281.1) |  |  | $ | (208.3) |  |
| State | (12.4) |  |  | (18.9) |  |  | (14.9) |  |
| Foreign | 0.2 |  |  | (6.7) |  |  | (2.4) |  |
| Total deferred | (222.9) |  |  | (306.7) |  |  | (225.6) |  |
| Provision for income taxes | $ | 283.9 |  |  | $ | 143.8 |  |  | $ | 30.8 |  |

[0001262039-25-000011:notes:251]
The foreign tax provision included the tax impacts from U.S. GAAP to local tax return book to tax differences that create a permanent addback including but not limited to stock compensation, meals and entertainment, and settlement of prior year tax audits with foreign jurisdiction adjustments.

[0001262039-25-000011:notes:252]
The provision for income taxes differs from the amount computed by applying the statutory federal income tax rate (in millions):

[0001262039-25-000011:notes:253]
|  | Year Ended December 31, |
|  | 2024 |  | 2023 |  | 2022 |
| Tax at federal statutory tax rate | $ | 432.3 |  |  | $ | 280.1 |  |  | $ | 200.6 |  |
| Foreign income taxed at different rates | 29.8 |  |  | 27.0 |  |  | 15.7 |  |
| Foreign withholding taxes | 58.0 |  |  | 35.1 |  |  | 31.0 |  |
| Stock-based compensation expense | (23.6) |  |  | (54.3) |  |  | (81.1) |  |
| Foreign tax credit | (79.5) |  |  | (72.6) |  |  | (26.2) |  |
| State taxes—net of federal benefit | 1.1 |  |  | 5.0 |  |  | (3.2) |  |
| Research and development credit | (13.9) |  |  | (14.0) |  |  | (11.6) |  |
| Valuation allowance | 7.5 |  |  | (67.7) |  |  | 25.9 |  |
| Impact of the 2017 Tax Cuts and Jobs Act: |  |  |  |  |  |
| Tax effect of a law change | — |  |  | (20.8) |  |  | — |  |
| Foreign-Derived Intangible Income | (111.5) |  |  | (89.5) |  |  | (115.2) |  |
| Adjustment to prior year’s FDII | — |  |  | 92.8 |  |  | — |  |
| Other | (16.3) |  |  | 22.7 |  |  | (5.1) |  |
| Total provision for income taxes | $ | 283.9 |  |  | $ | 143.8 |  |  | $ | 30.8 |  |

[0001262039-25-000011:notes:254]
On January 4, 2022, the U.S. Treasury published another tranche of final regulations regarding the foreign tax credit. These final regulations impose new requirements that a foreign tax must meet in order to be creditable against U.S. income taxes, and generally apply to tax years beginning on or after December 28, 2021. On July 26, 2022, the U.S. Treasury released corrections to the final regulations. On July 21, 2023, the IRS released a notice that suspended the application of significant portions of the final regulations regarding the foreign tax credit for tax years 2022 and 2023. The notice released in July 2023 favorably impacted our ability to claim foreign tax credits in the United States for certain taxes imposed by certain foreign jurisdictions. On December 11, 2023, the IRS released a notice that extended the suspension of significant portions of the final regulations beyond December 31, 2023, until further guidance is issued.

[0001262039-25-000011:notes:255]
In December 2021, the Organisation for Economic Co-operation and Development enacted model rules for a new global minimum tax framework (“BEPS Pillar Two”), and various governments around the world have enacted, or are in the process of enacting, legislation on this. For the tax year 2024, all of our foreign jurisdictions have either not implemented BEPS Pillar Two or satisfied the transitional Country-by Country Reporting safe harbor requirements, and as such, are not subject to top-up tax. We do not expect any material tax impact for 2024 and will continue to evaluate the impact of these tax law changes for future periods.

[0001262039-25-000011:notes:256]
The tax effects of temporary differences that give rise to significant portions of the deferred tax assets as of the years ended are presented below (in millions):

[0001262039-25-000011:notes:257]
|  | December 31,2024 |  | December 31,2023 |
| Deferred tax assets: |  |  |  |
| General business credit carryforward | $ | 31.7 |  |  | $ | 29.5 |  |
| Deferred revenue | 650.8 |  |  | 528.0 |  |
| Reserves and accruals | 139.0 |  |  | 134.1 |  |
| Net operating loss and capital loss carryforwards | 227.7 |  |  | 19.2 |  |
| Stock-based compensation expense | 27.0 |  |  | 25.1 |  |
| Depreciation and amortization | 12.0 |  |  | 8.1 |  |
| Capitalized research expenditures | 437.7 |  |  | 295.0 |  |
| Operating lease liabilities | 17.4 |  |  | 17.4 |  |
| Total deferred tax assets | 1,543.3 |  |  | 1,056.4 |  |
| Less: Valuation allowance | (40.7) |  |  | (33.2) |  |
| Deferred tax assets, net of valuation allowance | 1,502.6 |  |  | 1,023.2 |  |
| Deferred tax liabilities: |  |  |  |
| Deferred contract costs | (140.2) |  |  | (136.9) |  |
| Operating lease ROU assets | (15.8) |  |  | (16.7) |  |
| Acquired intangibles | (14.6) |  |  | (3.7) |  |
| Total deferred tax liabilities | (170.6) |  |  | (157.3) |  |
| Net deferred tax assets | $ | 1,332.0 |  |  | $ | 865.9 |  |

[0001262039-25-000011:notes:258]
In assessing the realizability of deferred tax assets, we considered whether it is more likely than not that some portion or all of our deferred tax assets will be realized. This realization is dependent upon the generation of future taxable income during the periods in which those temporary differences become deductible. We concluded that it is more likely than not that we will be able to realize the benefits of our deferred tax assets in the future except for our California research and development credits carryforward, certain impairment losses in business investments and certain tax attributes from business acquisitions. As of December 31, 2024, we had a valuation allowance of $40.7 million against those items.

[0001262039-25-000011:notes:259]
As of December 31, 2024, our federal and California net operating loss carryforwards for income tax purposes were $1.03 billion and $76.7 million, respectively. All the net operating loss carryforwards were from acquisitions which were limited by Section 382 of the Internal Revenue Code. If not utilized, the federal net operating loss carryforwards will begin to expire in 2028, and California net operating loss carryforwards will begin to expire in 2034.

[0001262039-25-000011:notes:260]
As of December 31, 2024, we had state tax credit carryforwards of $53.9 million. The state credits can be carried forward indefinitely.

[0001262039-25-000011:notes:261]
The aggregate changes in the balance of unrecognized tax benefits are (in millions):

[0001262039-25-000011:notes:262]
|  | Year Ended December 31, |
|  | 2024 |  | 2023 |  | 2022 |
| Unrecognized tax benefits, beginning of year | $ | 65.8 |  |  | $ | 67.4 |  |  | $ | 73.3 |  |
| Gross increases for tax positions related to the current year | 14.7 |  |  | 11.4 |  |  | 13.6 |  |
| Gross decreases for tax positions related to the current year | — |  |  | — |  |  | — |  |
| Gross increases for tax positions related to the prior year | 0.2 |  |  | 1.0 |  |  | 0.9 |  |
| Gross decreases for tax positions related to prior year | (2.3) |  |  | (4.0) |  |  | (2.0) |  |
| Gross decreases for tax positions related to prior year audit settlements | (1.8) |  |  | — |  |  | — |  |
| Gross decreases for tax positions related to expiration of statute of limitations | (0.7) |  |  | (10.0) |  |  | (18.4) |  |
| Unrecognized tax benefits, end of year | $ | 75.9 |  |  | $ | 65.8 |  |  | $ | 67.4 |  |

[0001262039-25-000011:notes:263]
As of December 31, 2024, we had $75.9 million of unrecognized tax benefits, of which, if recognized, $61.2 million would favorably affect our effective tax rate. Our gross unrecognized tax benefits increased approximately $10.1 million during the year ended December 31, 2024. The net increase was primarily due to the normal buildup of reserves related to the Federal R&D credit and transfer pricing. Our policy is to include accrued interest and penalties related to uncertain tax benefits in income tax expense. As of December 31, 2024, 2023 and 2022, accrued interest and penalties were $8.8 million, $6.4 million and $9.3 million, respectively.

[0001262039-25-000011:notes:264]
It is reasonably possible that our gross unrecognized tax benefits will decrease up to $0.9 million in the next 12 months, primarily due to the lapse of the statute of limitations. These adjustments, if recognized, would favorably impact our effective tax rate, and would be recognized as additional tax benefits.

[0001262039-25-000011:notes:265]
We file income tax returns in the U.S. federal jurisdiction and in various U.S. state and foreign jurisdictions. Generally, we are no longer subject to examination by U.S. federal income tax authorities for tax years prior to 2020 and by U.S. state and foreign tax authorities in our significant jurisdictions for tax years prior to 2016. We currently have ongoing tax audits in the United Kingdom, Canada, Germany and several other foreign jurisdictions. The focus of these audits is the inter-company profit allocation.


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0001262039-25-000011:notes:266]
DEFINED CONTRIBUTION PLANS
Our tax-deferred savings plan under our 401(k) Plan permits participating U.S. employees to contribute a portion of their pre-tax or after-tax earnings. In Canada, we have a Group Registered Retirement Savings Plan Program (the “RRSP”), which permits participants to make pre-tax contributions. Our board of directors approved 50% matching contributions on employee contributions up to 4% of each employee’s eligible earnings. Our matching contributions to our 401(k) Plan and the RRSP for 2024, 2023 and 2022 were $19.3 million, $17.1 million and $12.6 million, respectively.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001262039-25-000011:notes:267]
SEGMENT INFORMATION
Operating segments are defined as components of an enterprise about which separate financial information is available that is evaluated regularly by the chief operating decision maker in deciding how to allocate resources and in assessing performance. Our chief operating decision maker is our chief executive officer. Our chief executive officer reviews financial information including revenue, expenses and net income presented on a consolidated basis, accompanied by information about revenue by geographic region for purposes of allocating resources and evaluating financial performance. We have one business activity, and there are no segment managers who are held accountable for operations, operating results and plans for levels or components below the consolidated unit level. Accordingly, we have determined that we have one operating segment, and therefore, one reportable segment. Our chief executive officer assesses financial performance of the reportable segment and decides how to allocate resources based on net income that also is reported as net income attributable to Fortinet, Inc. on the consolidated statements of income. Net income is also used by our chief operating decision maker to monitor actual results versus budget and prior periods amounts of our reportable segment and decide whether to reinvest net income into the reportable segment or to expand business through business combinations or to return value to shareholders. The measure of the segment assets is reported on the balance sheet as total assets.

[0001262039-25-000011:notes:268]
The following table reflects certain financial data for our reportable segment (in millions):

[0001262039-25-000011:notes:269]
|  | Year Ended December 31, |
| 2024 |  | 2023 |  | 2022 |
| Total revenue | $ | 5,955.8 |  |  | $ | 5,304.8 |  |  | $ | 4,417.4 |  |
| Less: |  |  |  |  |  |
| Cost of product revenue | 652.0 |  |  | 763.6 |  |  | 691.3 |  |
| Cost of service revenue | 505.6 |  |  | 473.6 |  |  | 393.6 |  |
| Research and development expense | 716.8 |  |  | 613.8 |  |  | 512.4 |  |
| Other sales and marketing expense (1) | 1,654.9 |  |  | 1,635.3 |  |  | 1,366.4 |  |
| Commission expense | 389.9 |  |  | 370.7 |  |  | 319.7 |  |
| General and administrative expense | 237.8 |  |  | 211.3 |  |  | 169.0 |  |
| Other segment items (2) | 230.3 |  |  | 55.1 |  |  | (76.9) |  |
| Provision for income taxes | 283.9 |  |  | 143.8 |  |  | 30.8 |  |
| Net income | $ | 1,745.2 |  |  | $ | 1,147.8 |  |  | $ | 857.3 |  |

[0001262039-25-000011:notes:270]
(1) Excludes commission expense.

[0001262039-25-000011:notes:271]
(2) The following table presents other segment items (in millions):

[0001262039-25-000011:notes:272]
|  | Year Ended December 31, |
| 2024 |  | 2023 |  | 2022 |
| Gain on intellectual property matter | $ | 4.6 |  |  | $ | 4.6 |  |  | $ | 4.6 |  |
| Interest income | 155.2 |  |  | 119.7 |  |  | 17.4 |  |
| Interest expense | (20.0) |  |  | (21.0) |  |  | (18.0) |  |
| Gain on bargain purchase | 106.3 |  |  | — |  |  | — |  |
| Other income (expense)—net | 13.6 |  | (6.1) |  |  | (13.5) |  |
| Loss from equity method investments | (29.4) |  |  | (42.1) |  |  | (68.1) |  |
| Net loss attributable to non-controlling interests, net of tax | — |  |  | — |  |  | 0.7 |  |
| Total other segment items | $ | 230.3 |  |  | $ | 55.1 |  |  | $ | (76.9) |  |

[0001262039-25-000011:notes:273]
The following table presents other segment information (in millions):

[0001262039-25-000011:notes:274]
|  | Year Ended December 31, |
| 2024 |  | 2023 |  | 2022 |
| Significant non-cash items: |  |  |  |  |  |
| Stock‐based compensation expense | $ | 260.2 |  |  | $ | 251.6 |  |  | $ | 219.8 |  |
| Depreciation and amortization expense | 122.8 |  |  | 113.4 |  |  | 104.3 |  |
| Total assets | $ | 9,763.1 |  |  | $ | 7,258.9 |  |  | $ | 6,228.0 |  |
| Purchases of property and equipment | $ | 378.9 |  |  | $ | 204.1 |  |  | $ | 281.2 |  |

[0001262039-25-000011:notes:275]
Revenue by geographic region is based on the billing address of our customers. The following tables set forth revenue and property and equipment—net by geographic region (in millions):

[0001262039-25-000011:notes:276]
|  | Year Ended December 31, |
| Revenue | 2024 |  | 2023 |  | 2022 |
| Americas: |  |  |  |  |  |
| United States | $ | 1,778.9 |  |  | $ | 1,605.9 |  |  | $ | 1,325.0 |  |
| Other Americas | 663.3 |  |  | 569.3 |  |  | 460.0 |  |
| Total Americas | 2,442.2 |  |  | 2,175.2 |  |  | 1,785.0 |  |
| EMEA | 2,396.2 |  |  | 2,072.9 |  |  | 1,691.8 |  |
| APAC | 1,117.4 |  |  | 1,056.7 |  |  | 940.6 |  |
| Total revenue | $ | 5,955.8 |  |  | $ | 5,304.8 |  |  | $ | 4,417.4 |  |

[0001262039-25-000011:notes:277]
| Property and Equipment—net | December 31,2024 |  | December 31,2023 |
| Americas: |  |  |  |
| United States | $ | 993.5 |  |  | $ | 701.6 |  |
| Canada | 216.8 |  |  | 212.8 |  |
| Latin America | 4.4 |  |  | 2.3 |  |
| Total Americas | 1,214.7 |  |  | 916.7 |  |
| EMEA | 73.3 |  |  | 65.5 |  |
| APAC | 61.5 |  |  | 62.2 |  |
| Total property and equipment—net | $ | 1,349.5 |  |  | $ | 1,044.4 |  |

[0001262039-25-000011:notes:278]
The following distributor customers accounted for 10% or more of our revenue:

[0001262039-25-000011:notes:279]
|  | Year Ended December 31, |
|  | 2024 |  | 2023 |  | 2022 |
| Distributor A | 29 | % |  | 28 | % |  | 29 | % |
| Distributor B | 15 | % |  | 15 | % |  | 14 | % |
| Distributor C | 13 | % |  | 13 | % |  | 14 | % |

[0001262039-25-000011:notes:280]
The following distributor customers accounted for 10% or more of net accounts receivable:

[0001262039-25-000011:notes:281]
|  | 2024 |  | 2023 |
| Distributor A | 31 | % |  | 33 | % |
| Distributor B | 14 | % |  | 14 | % |
| Distributor C | 10 | % |  | 10 | % |


## us-gaap:SubsequentEventsTextBlock

[0001262039-25-000011:notes:282]
SUBSEQUENT EVENTS
Real Property Purchase

[0001262039-25-000011:notes:283]
In February 2025, we signed a definitive agreement subject to regulatory approval to purchase real property in Frankfurt, Germany, totaling approximately 540,000 square feet for $49.1 million in cash, excluding acquisition costs.

[0001262039-25-000011:notes:284]
Acquisition
On January 31, 2025, we acquired all of the remaining outstanding Series A Preferred Stock of Linksys for $22.0 million in initial consideration and now own 100% of the outstanding equity of Linksys.


## ecd:MtrlTermsOfTrdArrTextBlock

[0001262039-25-000011:notes:285]
On December 9, 2024, William H. Neukom, one of our directors, entered into a pre-arranged written stock sale plan in accordance with Rule 10b5-1 under the Exchange Act for the purchase of shares of our common stock (the “Neukom Plan”) during an open trading window in accordance with our insider trading policy. The Neukom Plan is intended to satisfy the affirmative defense of Rule 10b5-1(c) under the Exchange Act. The Neukom Plan provides for the potential purchase by Mr. Neukom of up to $35,000 worth of shares of our common stock per at the market price, on five dates between March 6, 2025 and March 6, 2026, as specified in the Neukom Plan.

[0001262039-25-000011:notes:286]
On December 9, 2024, Kenneth A. Goldman, one of our directors, entered into a pre-arranged written stock sale plan in accordance with Rule 10b5-1 under the Exchange Act for the sale of shares of our common stock (the “Goldman Plan”) during an open trading window in accordance with our insider trading policy. The Goldman Plan is intended to satisfy the affirmative defense of Rule 10b5-1(c) under the Exchange Act. The Goldman Plan provides for the potential sale by Mr. Goldman of up to 3,000 shares of our common stock, issued upon the exercise of vested options to purchase shares of our common stock, at the market price, so long as the market price is equal to or greater than $95.00 per share, between March 10, 2025 and March 10, 2026.

[0001262039-25-000011:notes:287]
On December 9, 2024, Ken Xie, our Chief Executive Officer and one of our directors, entered into a pre-arranged written stock sale plan in accordance with Rule 10b5-1 under the Exchange Act for the sale of shares of our common stock (the “Ken Xie Plan”) during an open trading window in accordance with our insider trading policy. The Ken Xie Plan is intended to satisfy the affirmative defense of Rule 10b5-1(c) under the Exchange Act. The Ken Xie Plan provides for the potential sale by Mr. Xie of up to (a) 734,880 shares of our common stock, issued upon the vesting and settlement of RSUs and PSUs for shares of our common stock and the exercise of vested options to purchase shares of our common stock and (b) the net shares (which are not yet determinable) after shares are withheld to satisfy tax obligations upon such vesting and settlement of RSUs and PSUs, in each case, at the market price, all between March 10, 2025 and May 6, 2026.

[0001262039-25-000011:notes:288]
On December 10, 2024, Michael Xie, our Chief Technology Officer and one of our directors, entered into a pre-arranged written stock sale plan in accordance with Rule 10b5-1 under the Exchange Act for the sale of shares of our common stock (the “Michael Xie Plan”) during an open trading window in accordance with our insider trading policy. The Michael Xie Plan is intended to satisfy the affirmative defense of Rule 10b5-1(c) under the Exchange Act. The Michael Xie Plan provides for the potential sale by Mr. Xie of up to (a) 624,285 shares of our common stock, issued upon the vesting and settlement of RSUs for shares of our common stock and the exercise of vested options to purchase shares of our common stock and (b) the net shares (which are not yet determinable) after shares are withheld to satisfy tax obligations upon such vesting and settlement of RSUs and PSUs, in each case, at the market price, all between March 11, 2025 and May 6, 2026.
