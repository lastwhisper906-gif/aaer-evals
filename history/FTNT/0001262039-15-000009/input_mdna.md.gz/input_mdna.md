# FTNT MD&A — 0001262039-15-000009


## mdna

[0001262039-15-000009:mdna:1]
ITEM 7.     Management’s Discussion and Analysis of Financial Condition and Results of Operations

[0001262039-15-000009:mdna:2]
| • | variability in sales in certain product categories from year to year and between quarters; |

[0001262039-15-000009:mdna:3]
| • | expected impact of sales of certain products; |

[0001262039-15-000009:mdna:4]
| • | the proportion of our revenue that consists of our product and service and other revenue, and the mix of billings between products and services; |

[0001262039-15-000009:mdna:5]
| • | the impact of our product innovation strategy; |

[0001262039-15-000009:mdna:6]
| • | growing our sales to large enterprises, service providers, and government organizations; |

[0001262039-15-000009:mdna:7]
| • | trends in revenue, costs of revenue, and gross margin; |

[0001262039-15-000009:mdna:8]
| • | trends in our operating expenses, including personnel costs, research and development expense, sales and marketing expense and general and administrative expense, and expectations regarding these expenses as a percentage of revenue; |

[0001262039-15-000009:mdna:9]
| • | continued investments in research and development to strengthen our technology leadership position and the impact of those investments; |

[0001262039-15-000009:mdna:10]
| • | continued investments in sales and marketing to drive market share gains and the impact of those investments; |

[0001262039-15-000009:mdna:11]
| • | expectations regarding uncertain tax benefits and our effective tax rate; |

[0001262039-15-000009:mdna:12]
| • | expectations regarding spending related to capital expenditures; |

[0001262039-15-000009:mdna:13]
| • | competition in our markets; |

[0001262039-15-000009:mdna:14]
| • | the sufficiency of our existing cash, cash equivalents and investments to meet our cash needs for at least the next 12 months; |

[0001262039-15-000009:mdna:15]
| • | as well as other statements regarding our future operations, financial condition and prospects and business strategies. |

[0001262039-15-000009:mdna:16]
Business Overview

[0001262039-15-000009:mdna:17]
We provide high performance cyber security solutions to some of the largest enterprises, service providers and government organizations across the globe, including a majority of the 2014 Fortune 100. Our cyber security solutions are fast and secure and designed to provide broad, high-performance protection against dynamic security threats while simplifying the IT infrastructure of our end-customers worldwide.

[0001262039-15-000009:mdna:18]
Our core product platform is the FortiGate physical and virtual appliance, which ships with a set of broad security services, including firewall, VPN, application control, intrusion prevention, web filtering and advanced threat protection (“ATP”). These security services are enabled by FortiGuard which provides extensive threat research and a global cloud

[0001262039-15-000009:mdna:19]
33

[0001262039-15-000009:mdna:20]
network to deliver protection services to each FortiGate appliance. FortiGate also has extensive networking capability such as switching, routing, native internet protocol version 6 (“IPv6”) and different modes of deployment. FortiManager provides central management and FortiAnalyzer provides reporting and analytics. The FortiGate platform can be extended to provide enhanced capabilities. For example, it can be used as a wireless controller for access points. An external sandbox can also be attached for local ATP analysis.

[0001262039-15-000009:mdna:21]
Customers select the functions or combination of functions that best meet their specific security requirements such as a high-speed DCFW at the network core, a NGFW at the edge, or a broad UTM solution at branch sites. We derive a substantial majority of product sales from our FortiGate appliances, which range from the FortiGate-20 to -100 series, designed for small businesses, FortiGate-200 to -800 series for mid-sized enterprises, to the FortiGate-1000 to -5000 series for large enterprises and service providers. Our network security platform also includes our FortiGuard security subscription services, which end-customers can subscribe to in order to obtain access to dynamic updates to application control, anti-virus, intrusion prevention, web filtering, and anti-spam functionality. End-customers can also choose to purchase FortiCare technical support services for our products. End-customers also often use FortiManager and FortiAnalyzer products in conjunction with a FortiGate deployment to provide centralized management and analysis and reporting capabilities.

[0001262039-15-000009:mdna:22]
We complement our core FortiGate product line with other appliances and software that offer additional protection from security threats to other critical areas of the enterprise, such as our wireless access point, advanced threat protection, secure email gateway, web application firewalls, application delivery controllers, databases security product, DDoS security product, and endpoint security product for employee computers and mobile devices. Sales of these complementary products have grown in recent quarters, although these products still represented less than 10% of our total revenue in fiscal 2014.

[0001262039-15-000009:mdna:23]
Financial Highlights

[0001262039-15-000009:mdna:24]
| • | We recorded total revenue of $770.4 million in fiscal 2014, an increase of 25% compared to fiscal 2013. Product revenue was $360.6 million, an increase of 30% compared to fiscal 2013. Services and other revenue was $409.8 million in fiscal 2014, an increase of 22% compared to fiscal 2013. |

[0001262039-15-000009:mdna:25]
| • | Cash, cash equivalents and investments were $991.7 million as of December 31, 2014, an increase of $148.7 million, or 18%, from December 31, 2013. |

[0001262039-15-000009:mdna:26]
| • | Deferred revenue was $558.8 million as of December 31, 2014, an increase of $126.1 million, or 29%, from December 31, 2013. |

[0001262039-15-000009:mdna:27]
| • | We generated cash flows from operating activities of $196.6 million in fiscal 2014, an increase of $49.2 million, or 33%, compared to fiscal 2013. |

[0001262039-15-000009:mdna:28]
| • | We received $20.0 million pursuant to a six-year mutual covenant-not-to-sue and release agreement with Palo Alto Networks, Inc. in January 2014. |

[0001262039-15-000009:mdna:29]
| • | We repurchased 1.6 million shares of common stock under our previously-announced Share Repurchase Program for an aggregate purchase price of $38.6 million in fiscal 2014. |

[0001262039-15-000009:mdna:30]
Revenue grew as a result of our focus on growth and our strategy to increase sales capacity and invest in our marketing activities during fiscal 2014. We also continued to gain traction with several recently introduced FortiGate products, including demand for certain of our high speed, low latency next-generation enterprise data center security products.

[0001262039-15-000009:mdna:31]
During fiscal 2014, we made significant investments in sales and marketing to increase brand awareness and grow our global sales force and distribution channels to expand our global presence both geographically and by industry segment. We continue to focus on selling to large customers, such as enterprise, service providers and government organizations worldwide. As a result, we had increased sales from large enterprises and enterprise data center deployments, with particular strength in the telecommunication, technology, government, and financial sectors.

[0001262039-15-000009:mdna:32]
In fiscal 2014, sales of high-end FortiGate products (FortiGate-1000 to -5000 series) increased due to enterprise adoption of our high-end appliances such as the FortiGate-1500D and 3700D. The percentage of our FortiGate related billings from high-end products increased from 34% in fiscal 2013 to 38% in fiscal 2014, while the mid-range products decreased from 29% in fiscal 2013 to 26% in fiscal 2014 and the entry-level products decreased from 38% in fiscal 2013 to 36% in fiscal 2014.

[0001262039-15-000009:mdna:33]
34

[0001262039-15-000009:mdna:34]
We also continue to invest in research and development to strengthen our technology leadership position. We believe that continued product innovation has strengthened our technology and resulted in market share gains, as evidenced by our introduction of the FortiGate-1500D and -3700D enterprise security appliances.

[0001262039-15-000009:mdna:35]
In fiscal 2014, operating expenses increased 32% compared to fiscal 2013. The increase was primarily driven by our accelerated pace of hiring and marketing investments to support our growth as we continued to invest in expanding our sales coverage, marketing capabilities, developing new products and scaling our customer support organization to meet the needs of our customer base. Headcount, including full time equivalent employees, increased to 2,854 as of December 31, 2014 from 2,308 as of December 31, 2013.

[0001262039-15-000009:mdna:36]
Business Model

[0001262039-15-000009:mdna:37]
Our sales strategy is based on a distribution model whereby we primarily sell our products and services directly to distributors who sell to resellers and service providers, who, in turn, sell to our end-customers. In certain cases, we sell directly to government-focused resellers, large service providers and major systems integrators, who have significant purchasing power and unique customer deployment requirements. Typically, FortiGuard security subscription services and FortiCare technical support services are purchased along with our physical and virtual appliances. We invoice at the time of our sale for the total price of the products and subscription and technical support services, and the invoice generally becomes payable within 30 to 90 days. We generally recognize product revenue up-front based on the allocated revenue value and defer revenue for the sale of new, and renewal of existing, FortiGuard security subscription and FortiCare technical support services contracts. We recognize the related services revenue over the service period, which is typically one to three years from the date the end-customer registers for these services (the date on which the services can first be used by the customer), although it can be as long as five years. Sales of new and renewal services increase our deferred revenue balance, which contributes significantly to our positive cash flow from operations.

[0001262039-15-000009:mdna:38]
Key Metrics

[0001262039-15-000009:mdna:39]
We monitor the key financial metrics set forth below to help us evaluate growth trends, establish budgets, measure the effectiveness of our sales and marketing efforts, and assess operational efficiencies. The following table summarizes revenue, deferred revenue, billings (non-GAAP), cash, cash equivalents and investments, net cash provided by operating activities, and free cash flow (non-GAAP). We discuss revenue below under “—Components of Operating Results,” and we discuss our cash, cash equivalents, and investments, and net cash provided by operating activities below under “—Liquidity and Capital Resources.” Deferred revenue, billings (non-GAAP), and free cash flow (non-GAAP) are discussed immediately below the following table.

[0001262039-15-000009:mdna:40]
|  | Year Ended or As of December 31, |
|  | 2014 |  | 2013 |  | 2012 |
|  | (in thousands) |
| Revenue | $ | 770,364 |  |  | $ | 615,297 |  |  | $ | 533,639 |  |
| Deferred revenue | $ | 558,757 |  |  | $ | 432,628 |  |  | $ | 363,185 |  |
| Increase in deferred revenue | $ | 126,129 |  |  | $ | 69,443 |  |  | $ | 68,352 |  |
| Billings (non-GAAP) | $ | 896,493 |  |  | $ | 684,190 |  |  | $ | 601,991 |  |
| Cash, cash equivalents and investments | $ | 991,744 |  |  | $ | 843,045 |  |  | $ | 739,586 |  |
| Net cash provided by operating activities | $ | 196,582 |  |  | $ | 147,384 |  |  | $ | 183,866 |  |
| Free cash flow (non-GAAP) | $ | 164,385 |  |  | $ | 133,507 |  |  | $ | 161,783 |  |

[0001262039-15-000009:mdna:41]
Deferred revenue. Our deferred revenue consists of amounts that have been invoiced but that have not yet been recognized as revenue. The majority of our deferred revenue balance consists of the unamortized portion of services revenue from FortiGuard security subscription and FortiCare support service contracts. We monitor our deferred revenue balance because it represents a significant portion of revenue to be recognized in future periods.

[0001262039-15-000009:mdna:42]
Billings (Non-GAAP).We define billings as revenue recognized during a period plus the change in deferred revenue from the beginning to the end of the period less any deferred revenue balances acquired from business combinations during the period. We consider billings to be a useful metric for management and investors because deferred revenue, which is impacted by billings, is an important indicator of the health and visibility of our business, and revenue from previously deferred amounts has historically represented a majority of the revenue that we recognize in any particular period. There are a number of

[0001262039-15-000009:mdna:43]
35

[0001262039-15-000009:mdna:44]
limitations related to the use of billings as opposed to revenue calculated in accordance with GAAP. First, billings include amounts that have not yet been recognized as revenue. Second, we may calculate billings in a manner that is different from peer companies that report similar financial measures. Management compensates for these limitations by providing specific information regarding GAAP revenue and evaluating billings together with revenue calculated in accordance with GAAP. A reconciliation of billings to revenue, the most directly comparable financial measure calculated and presented in accordance with GAAP, is provided below:

[0001262039-15-000009:mdna:45]
|  | Year Ended December 31, |
| 2014 |  | 2013 |  | 2012 |
| (in thousands) |
| Billings: |  |  |  |  |  |
| Revenue | $ | 770,364 |  |  | $ | 615,297 |  |  | $ | 533,639 |  |
| Increase in deferred revenue | 126,129 |  |  | 69,443 |  |  | 68,352 |  |
| Less deferred revenue balance acquired in business combination | — |  |  | (550 | ) |  | — |  |
| Total billings (Non-GAAP) | $ | 896,493 |  |  | $ | 684,190 |  |  | $ | 601,991 |  |

[0001262039-15-000009:mdna:46]
Free cash flow (Non-GAAP). We define free cash flow as net cash provided by operating activities less capital expenditures. We consider free cash flow to be a liquidity measure that provides useful information to management and investors about the amount of cash generated by the business that, after the acquisition of property and equipment, can be used for strategic opportunities, including investing in our business, making strategic acquisitions, repurchasing outstanding common stock, and strengthening the balance sheet. Analysis of free cash flow facilitates comparisons of our operating results to competitors’ operating results. A limitation of using free cash flow as opposed to the GAAP measure of net cash provided by operating activities as a means for evaluating liquidity is that free cash flow does not represent the total increase or decrease in the cash, cash equivalents and investments balances for the period because it excludes cash used for capital expenditures and cash provided by or used for other investing and financing activities. We compensate for this limitation by providing information about our capital expenditures and other investing and financing activities on the face of the cash flow statement and under “—Liquidity and Capital Resources.”  A reconciliation of free cash flow to net cash provided by operating activities, the most directly comparable financial measure calculated and presented in accordance with GAAP, is provided below:

[0001262039-15-000009:mdna:47]
|  | Year Ended December 31, |
| 2014 |  | 2013 |  | 2012 |
| (in thousands) |
| Free Cash Flow: |  |  |  |  |  |
| Net cash provided by operating activities | $ | 196,582 |  |  | $ | 147,384 |  |  | $ | 183,866 |  |
| Less purchases of property and equipment | (32,197 | ) |  | (13,877 | ) |  | (22,083 | ) |
| Free cash flow (Non-GAAP) | $ | 164,385 |  |  | $ | 133,507 |  |  | $ | 161,783 |  |

[0001262039-15-000009:mdna:48]
Components of Operating Results

[0001262039-15-000009:mdna:49]
Revenue

[0001262039-15-000009:mdna:50]
We generate the majority of our revenue from sales of our products and FortiGuard security subscription and FortiCare technical support services. Revenue is recognized when persuasive evidence of an arrangement exists, delivery has occurred or services have been rendered, the sales price is fixed or determinable and collectability is reasonably assured.

[0001262039-15-000009:mdna:51]
Our total revenue is comprised of the following:

[0001262039-15-000009:mdna:52]
| • | Product revenue. Product revenue is generated from sales of our appliances. The substantial majority of our product revenue has been generated by our FortiGate line of appliances, and we do not expect this to change in the foreseeable future. Product revenue also includes revenue derived from sales of FortiManager, FortiAnalyzer, FortiSwitch, FortiMail, FortiDB, FortiWeb, FortiAP, FortiScan, FortiCarrier, FortiBalancer, FortiCache, FortiVoice, FortiBridge, FortiDDoS, FortiDNS, FortiSandbox, FortiADC, and FortiAuthenticator appliances, and our FortiClient and virtual domain, or VDOM, software. For arrangements which include end-customer acceptance criteria, revenue is recognized upon acceptance. We recognize product revenue on sales to distributors that have no general right of return and direct sales to end-customers upon shipment, once all other revenue recognition criteria have been met. Certain distributors that stock our products are |

[0001262039-15-000009:mdna:53]
36

[0001262039-15-000009:mdna:54]
granted stock rotation rights, limited rights of return, as well as rebates for sales of our products. The arrangement fee for this group of distributors is not fixed and determinable when products are shipped and revenue is therefore deferred and recognized upon sell-through.  As a percentage of total revenue, we expect our product revenue may vary from quarter-to-quarter based on seasonal and cyclical factors discussed below under “—Quarterly Results of Operations” but generally may remain at relatively comparable levels , as services revenue becomes a larger portion of our business as our customers renew existing services contracts and we expand our customer base.

[0001262039-15-000009:mdna:55]
| • | Services revenue. Services revenue is generated primarily from FortiGuard security subscription and FortiCare technical support services for software updates, maintenance releases and patches, Internet access to technical content, telephone and Internet access to technical support personnel and hardware support, and FortiGuard security subscription services related to application control, antivirus, intrusion prevention, web filtering, anti-spam and vulnerability management updates. We recognize revenue from FortiGuard security subscription and FortiCare technical support services over the service performance period. Our typical contractual support and subscription term is one to three years. We also generate a small portion of our revenue from professional services and training services, and we recognize this revenue as the services are provided. As a percentage of total revenue, we expect our services revenue to remain at comparable levels or increase as our customers renew existing service contracts and we expand our customer base. Our services revenue growth rate depends significantly on the growth of our customer base and the renewal of service contracts by our customers. |

[0001262039-15-000009:mdna:56]
Beginning in fiscal 2014, we combined ratable and other revenue with services revenue to present the combined amounts as services and other revenue in the consolidated statements of operations. The related cost of revenue and gross profit have also been combined to conform to the current period presentation. Ratable and other revenue is not material and is not expected to become material in the future.

[0001262039-15-000009:mdna:57]
Our total cost of revenue is comprised of the following:

[0001262039-15-000009:mdna:58]
| • | Cost of product revenue. A substantial majority of the cost of product revenue consists of costs of materials used in production, as well as costs paid to our third-party contract manufacturers. Our cost of product revenue also includes supplies, shipping costs, personnel costs associated with logistics and quality control, warranty costs, facility-related costs, excess and obsolete inventory costs, and impairment of intangible assets, if applicable. Personnel costs include salaries, benefits and bonuses, as well as stock-based compensation. |

[0001262039-15-000009:mdna:59]
| • | Cost of services revenue. Cost of services revenue is primarily comprised of salaries, benefits and bonuses, as well as stock-based compensation associated with our FortiGuard Labs and our FortiCare technical support teams. Cost of service revenue also includes replacement products and supplies, facility-related costs, including depreciation expense, and professional services and training teams. We expect our cost of services revenue will increase slightly as a percentage of revenue as we continue to invest in FortiGuard security subscription and FortiCare technical support services to meet the needs of our customer base and service levels expected by our enterprise customers. |

[0001262039-15-000009:mdna:60]
Gross profit. Gross profit as a percentage of revenue, or gross margin, has been and will continue to be affected by a variety of factors, including the average sales price of our products, any excess inventory write-offs, product costs, the mix of products sold and the mix of revenue between products and services. We believe our overall gross margin for the near term will remain at levels comparable or slightly lower to that achieved in fiscal 2014.

[0001262039-15-000009:mdna:61]
Services revenue has a positive effect on our total gross margin given the higher services gross margins compared to product gross margins. During fiscal 2014 service margins remained relatively consistent compared to fiscal 2013.

[0001262039-15-000009:mdna:62]
Operating expenses. Our operating expenses consist of research and development, sales and marketing and general and administrative expenses. Personnel costs are the most significant component of operating expenses and consist of salaries, benefits, bonuses, sales commissions, and stock-based compensation. We expect personnel costs to continue to increase in absolute dollars as we hire new employees.

[0001262039-15-000009:mdna:63]
| • | Research and development. Research and development expense consists primarily of salaries, benefits and bonuses, as well as stock-based compensation. Additional research and development expenses include ASIC and system prototypes and certification-related expenses, depreciation of capital equipment and facility- |

[0001262039-15-000009:mdna:64]
37

[0001262039-15-000009:mdna:65]
related expenses. The majority of our research and development is focused on both software development and the ongoing development of our hardware platform. We record all research and development expenses as incurred. Our development teams are primarily located in Canada and the United States.

[0001262039-15-000009:mdna:66]
| • | Sales and marketing. Sales and marketing expense is the largest component of our operating expenses and primarily consists of salaries, benefits, bonuses and commissions, as well as stock-based compensation. Additional sales and marketing expenses include promotional and other marketing expenses, travel, depreciation of capital equipment and facility-related expenses. We intend to hire additional personnel focused on sales and marketing and expand our sales and marketing efforts worldwide in order to capture additional market share in the high-return enterprise market, where customers tend to provide a higher lifetime value. |

[0001262039-15-000009:mdna:67]
| • | General and administrative. General and administrative expense consists of salaries, benefits and bonuses, as well as stock-based compensation, as well as professional fees, depreciation of capital equipment and software, and facility-related expenses. General and administrative personnel include our executive, finance, human resources, information technology and legal organizations. Our professional fees principally consist of outside legal, auditing, accounting, tax, information technology and other consulting costs. |

[0001262039-15-000009:mdna:68]
Interest income. Interest income consists of income earned on our cash, cash equivalents and investments. We have historically invested our cash in money market funds, commercial paper, corporate debt securities, municipal bonds, certificates of deposit and term deposits, and U.S. government and agency debt securities.

[0001262039-15-000009:mdna:69]
Other expense, net. Other expense, net consists primarily of foreign exchange and related hedging gains and losses. Foreign exchange gains and losses relate to foreign currency exchange re-measurement. The hedging gains and losses are related to our settled balance sheet hedges.

[0001262039-15-000009:mdna:70]
Provision for income taxes. We are subject to tax in the United States as well as other tax jurisdictions or countries in which we conduct business. Earnings from our non-U.S. activities are subject to income taxes in the local country which are generally lower than U.S. tax rates, and may be subject to U.S. income taxes. Our effective tax rate differs from the U.S. statutory rate primarily due to foreign income subject to different tax rates than the U.S., research and development tax credits, withholding taxes, nondeductible stock-based compensation expense and adjustments related to our intercompany transfer pricing.

[0001262039-15-000009:mdna:71]
The income tax provision for fiscal 2014 was comprised primarily of domestic income taxes, foreign income taxes, foreign withholding taxes, and income tax reserves. Our effective tax rate approximates the U.S. federal statutory tax rates plus the impact of state taxes, research and development tax credits (when applicable), foreign withholding tax, nondeductible stock-based compensation expense, foreign income subject to lower tax than the U.S., and adjustments related to intercompany transfer pricing.

[0001262039-15-000009:mdna:72]
Critical Accounting Policies and Estimates

[0001262039-15-000009:mdna:73]
Our discussion and analysis of our financial condition and results of operations are based upon our financial statements, which have been prepared in accordance with GAAP. These principles require us to make estimates and judgments that affect the reported amounts of assets, liabilities, revenue, cost of revenue, expenses, and related disclosures. Our estimates include those related to revenue recognition, stock-based compensation expense, valuation of inventory, warranty liabilities, investments, goodwill and other long-lived assets and accounting for income taxes. We base our estimates on historical experience and on various other assumptions that we believe to be reasonable under the circumstances. To the extent that there are material differences between these estimates and our actual results, our future financial statements will be affected.

[0001262039-15-000009:mdna:74]
We believe that of our significant accounting policies, which are described in Note 1 to our consolidated financial statements included in Part II, Item 8 of this Annual Report on Form 10-K, the following accounting policies involve a greater degree of judgment and complexity. Accordingly, we believe these are the most critical to fully understand and evaluate our financial condition and results of operations.

[0001262039-15-000009:mdna:75]
Revenue Recognition

[0001262039-15-000009:mdna:76]
We derive the majority of our revenue from sales of our hardware, software, FortiGuard security subscription services and FortiCare technical support services, and other services through our channel partners and a direct sales force.

[0001262039-15-000009:mdna:77]
Revenue is recognized when all of the following criteria have been met:

[0001262039-15-000009:mdna:78]
| • | Persuasive evidence of an arrangement exists. Binding contracts or purchase orders are generally used to determine the existence of an arrangement. |

[0001262039-15-000009:mdna:79]
| • | Delivery has occurred or services have been rendered. Delivery occurs when we fulfill an order and title and risk of loss has been transferred. Services revenue is deferred and recognized ratably over the contract service period, which is typically from one to three years and is generally recognized upon delivery or completion of service. |

[0001262039-15-000009:mdna:80]
| • | Sales price is fixed or determinable. We assess whether the sales price is fixed or determinable based on the payment terms associated with the transaction and when the sales price is deemed final. |

[0001262039-15-000009:mdna:81]
| • | Collectability is reasonably assured. We assess collectability based primarily on creditworthiness as determined by credit checks, analysis, and payment history. |

[0001262039-15-000009:mdna:82]
We recognize product revenue for sales to distributors that have no general right of return and direct sales to end-customers upon shipment, based on general revenue recognition accounting guidance once all other revenue recognition criteria have been met. Certain distributors are granted stock rotation rights, limited rights of return, as well as rebates for sales of our products. The arrangement fee for this group of distributors is not typically fixed or determinable when products are shipped and revenue is therefore deferred and recognized upon sell-through. For sales that include end-customer acceptance criteria, revenue is recognized upon acceptance.

[0001262039-15-000009:mdna:83]
Substantially all of our products have been sold in combination with services, which consist of security subscriptions and technical support services. Security services provide access to our antivirus, intrusion prevention, web filtering, and anti-spam functionality. Support services include rights to unspecified software upgrades, maintenance releases and patches, telephone and Internet access to technical support personnel, and hardware support.  We recognize revenue from these services ratably over the contractual service period.  Revenue related to subsequent renewals of these services are recognized over the term of the renewal agreement.

[0001262039-15-000009:mdna:84]
We offer certain sales incentives to channel partners. We reduce revenue for estimates of sales returns and allowances and record reductions to revenue for rebates and estimated commitments related to price protection and other customer incentive programs. Additionally, in limited circumstances, we may permit end-customers, distributors and resellers to return our products, subject to varying limitations, for a refund within a reasonably short period from the date of purchase. We estimate and record reserves for sales incentives and sales returns based on historical experience.

[0001262039-15-000009:mdna:85]
Our sales arrangements typically contain multiple elements, such as hardware, subscription, technical support and other services. The majority of our hardware appliance products contain our operating system software that together function to deliver the essential functionality of the product. Our products and services generally qualify as separate units of accounting. We allocate revenue to each unit of accounting based on an estimated selling price using vendor-specific objective evidence (“VSOE”) of selling price, if it exists, or third-party evidence (“TPE”) of selling price. If neither VSOE nor TPE of selling price exist for a deliverable, we use our best estimate of selling price (“BESP”) for that deliverable. Revenue allocated to each element is then recognized when the basic revenue recognition criteria are met for each element.

[0001262039-15-000009:mdna:86]
We determine VSOE of fair value for elements of an arrangement based on the historical pricing and discounting practices for those services when sold separately. In establishing VSOE, we require that a substantial majority of the selling prices for a service fall within a reasonably narrow pricing range, generally evidenced by a substantial majority of such historical stand-alone transactions falling within a reasonably narrow range as a percentage of list price. We are typically not able to determine TPE for our products or services. TPE is determined based on competitor prices for similar deliverables when sold separately, which is generally unavailable. For our hardware appliances, we use BESP as our selling price. For our support and other services, we generally use VSOE as our selling price estimate. When we are unable to establish a selling price using VSOE for our support and other services, we use BESP in our allocation of arrangement consideration. We determine BESP for a product or service by considering multiple historical factors including, but not limited to, cost of products, gross margin objectives, pricing practices, geographies, customer classes and distribution channels that fall within a reasonably narrow range as a percentage of list price.

[0001262039-15-000009:mdna:87]
For multiple-element arrangements where software deliverables are included, revenue is allocated to the non-software deliverables and to the software deliverables as a group using the relative estimated selling prices of each of the deliverables in

[0001262039-15-000009:mdna:88]
the arrangement based on the estimated selling price hierarchy. The amount allocated to the software deliverables is then allocated to each software deliverable using the residual method when VSOE of fair value exists. If evidence of VSOE of fair value of one or more undelivered elements does not exist, all software allocated revenue is deferred and recognized when delivery of those elements occurs or when fair value can be established. When the undelivered element for which we do not have VSOE of fair value is support, revenue for the entire arrangement is recognized ratably over the support period. The same residual method and VSOE of fair value principles apply for our multiple element arrangements that contain only software elements.

[0001262039-15-000009:mdna:89]
Stock-Based Compensation Expense

[0001262039-15-000009:mdna:90]
Employees Stock Options.  We estimate the fair value of employee stock options awarded to our employees using the Black-Scholes-Merton (“Black-Scholes”) pricing model. For all employee stock options, we recognize expense, net of estimated forfeitures, over the requisite service period using the straight-line method. Our option pricing model requires the input of subjective assumptions, including the expected stock price volatility, expected term, and forfeiture rate. The assumptions used in our option pricing model represent management’s best estimates. These estimates involve inherent uncertainties and the application of management’s judgment. During fiscal 2014, stock options granted to employees were not significant. A 10% change in any of these assumptions would not have a significant impact on our stock-based compensation expense.

[0001262039-15-000009:mdna:91]
Employee Stock Purchase Plan. We estimate the fair value of the rights to acquire stock under our employee stock purchase plan (“ESPP”) using the Black-Scholes pricing model and is amortize the fair value over the requisite service period using the straight-line method. The pricing model requires the input of the fair value of our common stock and subjective assumptions, including the expected term of the award, the expected volatility of the price of our common stock, risk-free interest rates, and the expected dividend yield of our common stock. Our ESPP provides for consecutive six-month offering periods and we use our own historical volatility data in the valuation of ESPP shares. A 10% change in any of these assumptions would not have a material impact on our stock-based compensation expense.

[0001262039-15-000009:mdna:92]
Restricted Stock Units. We account for the fair value of restricted stock units (“RSUs”) awarded to employees and members of our board of directors using the closing market price of our common stock on the date of grant. RSUs are payable in shares of our common stock as the periodic vesting requirements are satisfied. RSUs generally vest over a four-year period if the employees, contractors, or directors, as applicable, remain with us for the duration of the vesting period. For all RSUs, we recognize expense, net of estimated forfeitures, over the requisite service period using the straight-line method.

[0001262039-15-000009:mdna:93]
Performance Stock Units. Performance Stock Units (“PSUs”) are RSUs that contain both service-based and market-based vesting conditions. PSUs vest over a specified service period upon the satisfaction of certain market-based vesting conditions, and settle into shares of our common stock upon vesting over a two- or three-year period.  The fair value of a PSU is calculated using the Monte Carlo simulation model on the date of grant and is based on the market price of our common stock on the date of grant modified to reflect the impact of the market-based vesting condition, including the estimated payout level based on that condition. We do not adjust compensation cost for subsequent changes in the expected outcome of the market-based vesting conditions.

[0001262039-15-000009:mdna:94]
Valuation of Inventory

[0001262039-15-000009:mdna:95]
Inventory is recorded at the lower of cost (using the first-in, first-out method) or market, after we give appropriate consideration to obsolescence and inventory in excess of anticipated future demand. In assessing the ultimate recoverability of inventory, we make estimates regarding future customer demand, the timing of new product introductions, economic trends and market conditions. If the actual product demand is significantly lower than forecasted, we could be required to record additional inventory write-downs which would be charged to cost of product revenue. Any write-downs could have an adverse impact on our gross margins and profitability.

[0001262039-15-000009:mdna:96]
Accounting for Income Taxes

[0001262039-15-000009:mdna:97]
We record income taxes using the asset and liability method, which requires the recognition of deferred tax assets and liabilities for the expected future tax consequences of events that have been recognized in our financial statements or tax returns. In estimating future tax consequences, generally all expected future events other than enactments or changes in the tax law or rates are considered. Valuation allowances are provided when necessary to reduce deferred tax assets to the amount expected to be realized.

[0001262039-15-000009:mdna:98]
40

[0001262039-15-000009:mdna:99]
We operate in various tax jurisdictions and are subject to audit by various tax authorities. We provide for tax contingencies whenever it is deemed more likely than not that a tax asset has been impaired or a tax liability has been incurred for events such as tax claims or changes in tax laws. Tax contingencies are based upon their technical merits, relevant tax law and the specific facts and circumstances as of each reporting period. Changes in facts and circumstances could result in material changes to the amounts recorded for such tax contingencies.

[0001262039-15-000009:mdna:100]
We account for uncertain tax positions in accordance with GAAP, which defines the confidence level that a tax position must meet in order to be recognized in the financial statements. The tax effects of a position are recognized only if it is “more likely than not” to be sustained based solely on its technical merits as of the reporting date. We consider many factors when evaluating and estimating our tax positions and tax benefits, which may require periodic adjustments and which may not accurately anticipate actual outcomes.

[0001262039-15-000009:mdna:101]
As part of the process of preparing our consolidated financial statements, we are required to estimate our taxes in each of the jurisdictions in which we operate. We estimate actual current tax exposure together with assessing temporary differences resulting from differing treatment of items, such as accruals and allowances not currently deductible for tax purposes. These differences result in deferred tax assets, which are included in our consolidated balance sheets. In general, deferred tax assets represent future tax benefits to be received when certain expenses previously recognized in our consolidated statements of operations become deductible expenses under applicable income tax laws, or loss or credit carryforwards are utilized.

[0001262039-15-000009:mdna:102]
In assessing the realizability of deferred tax assets, management considers whether it is more likely than not that some portion or all of the deferred tax assets will be realized. The ultimate realization of deferred tax assets is dependent upon the generation of future taxable income during the periods in which those temporary differences become deductible. We continue to assess the need for a valuation allowance on the deferred tax assets by evaluating both positive and negative evidence that may exist. Any adjustment to the net deferred tax asset valuation allowance would be recorded in the income statement for the period that the adjustment is determined to be required.

[0001262039-15-000009:mdna:103]
We make estimates and judgments about our future taxable income that are based on assumptions that are consistent with our plans and estimates. Should the actual amounts differ from our estimates, the amount of our tax expense and liabilities could be materially impacted.

[0001262039-15-000009:mdna:104]
41

[0001262039-15-000009:mdna:105]
Results of Operations

[0001262039-15-000009:mdna:106]
The following tables set forth our results of operations for the periods presented and as a percentage of our total revenue for those periods. The period-to-period comparison of financial results is not necessarily indicative of financial results to be achieved in future periods.

[0001262039-15-000009:mdna:107]
|  | Year Ended December 31, |
|  | 2014 |  | 2013 |  | 2012 |
|  | (in thousands) |
| Consolidated Statement of Operations Data: |  |  |  |  |  |
| Revenue: |  |  |  |  |  |
| Product | $ | 360,558 |  |  | $ | 278,046 |  |  | $ | 248,948 |  |
| Services and other | 409,806 |  |  | 337,251 |  |  | 284,691 |  |
| Total revenue | 770,364 |  |  | 615,297 |  |  | 533,639 |  |
| Cost of revenue: |  |  |  |  |  |
| Product | 151,300 |  |  | 114,611 |  |  | 93,971 |  |
| Services and other | 79,709 |  |  | 66,032 |  |  | 53,449 |  |
| Total cost of revenue | 231,009 |  |  | 180,643 |  |  | 147,420 |  |
| Gross profit: |  |  |  |  |  |
| Product | 209,258 |  |  | 163,435 |  |  | 154,977 |  |
| Services and other | 330,097 |  |  | 271,219 |  |  | 231,242 |  |
| Total gross profit | 539,355 |  |  | 434,654 |  |  | 386,219 |  |
| Operating expenses: |  |  |  |  |  |
| Research and development | 122,880 |  |  | 102,660 |  |  | 81,078 |  |
| Sales and marketing | 315,804 |  |  | 224,991 |  |  | 179,155 |  |
| General and administrative | 41,347 |  |  | 34,913 |  |  | 25,511 |  |
| Total operating expenses | 480,031 |  |  | 362,564 |  |  | 285,744 |  |
| Operating income | 59,324 |  |  | 72,090 |  |  | 100,475 |  |
| Interest income | 5,393 |  |  | 5,306 |  |  | 5,006 |  |
| Other expense—net | (3,168 | ) |  | (1,455 | ) |  | (485 | ) |
| Income before income taxes | 61,549 |  |  | 75,941 |  |  | 104,996 |  |
| Provision for income taxes | 36,206 |  |  | 31,668 |  |  | 38,160 |  |
| Net income | $ | 25,343 |  |  | $ | 44,273 |  |  | $ | 66,836 |  |

[0001262039-15-000009:mdna:108]
42

[0001262039-15-000009:mdna:109]
|  | Year Ended December 31, |
| 2014 |  | 2013 |  | 2012 |
| (as percentage of total revenue) |
| Revenue: |  |  |  |  |  |
| Product | 47 | % |  | 45 | % |  | 47 | % |
| Services and other | 53 |  |  | 55 |  |  | 53 |  |
| Total revenue | 100 |  |  | 100 |  |  | 100 |  |
| Cost of revenue: |  |  |  |  |  |
| Product | 20 |  |  | 19 |  |  | 18 |  |
| Services and other | 10 |  |  | 11 |  |  | 10 |  |
| Total cost of revenue | 30 |  |  | 29 |  |  | 28 |  |
| Gross profit: |  |  |  |  |  |
| Product | 58 |  |  | 59 |  |  | 62 |  |
| Services and other | 81 |  |  | 80 |  |  | 81 |  |
| Total gross profit | 70 |  |  | 71 |  |  | 72 |  |
| Operating expenses: |  |  |  |  |  |
| Research and development | 16 |  |  | 17 |  |  | 15 |  |
| Sales and marketing | 41 |  |  | 36 |  |  | 33 |  |
| General and administrative | 5 |  |  | 6 |  |  | 5 |  |
| Total operating expenses | 62 |  |  | 59 |  |  | 53 |  |
| Operating income | 8 |  |  | 12 |  |  | 19 |  |
| Interest income | 1 |  |  | — |  |  | 1 |  |
| Other expense—net | — |  |  | — |  |  | — |  |
| Income before income taxes | 8 |  |  | 12 |  |  | 20 |  |
| Provision for income taxes | 5 |  |  | 5 |  |  | 7 |  |
| Net income | 3 | % |  | 7 | % |  | 13 | % |

[0001262039-15-000009:mdna:110]
Fiscal Years 2014 and 2013

[0001262039-15-000009:mdna:111]
Revenue

[0001262039-15-000009:mdna:112]
|  | Year Ended December 31, |  |  |  |  |
| 2014 |  | 2013 |  |  |  |  |
| Amount |  | % ofRevenue |  | Amount |  | % ofRevenue |  | Change |  | % Change |
| (in thousands, except percentages) |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 360,558 |  |  | 47 | % |  | $ | 278,046 |  |  | 45 | % |  | $ | 82,512 |  |  | 30 | % |
| Services and other | 409,806 |  |  | 53 |  |  | 337,251 |  |  | 55 |  |  | 72,555 |  |  | 22 |  |
| Total revenue | $ | 770,364 |  |  | 100 | % |  | 615,297 |  |  | 100 | % |  | $ | 155,067 |  |  | 25 | % |
| Revenue by geography: |  |  |  |  |  |  |  |  |  |  |  |
| Americas | $ | 324,659 |  |  | 42 | % |  | $ | 252,786 |  |  | 41 | % |  | $ | 71,873 |  |  | 28 | % |
| Europe, Middle East and Africa (“EMEA”) | 270,537 |  |  | 35 |  |  | 208,979 |  |  | 34 |  |  | 61,558 |  |  | 29 |  |
| Asia Pacific and Japan (“APAC”) | 175,168 |  |  | 23 |  |  | 153,532 |  |  | 25 |  |  | 21,636 |  |  | 14 |  |
| Total revenue | $ | 770,364 |  |  | 100 | % |  | $ | 615,297 |  |  | 100 | % |  | $ | 155,067 |  |  | 25 | % |

[0001262039-15-000009:mdna:113]
Total revenue increased by $155.1 million, or 25%, in fiscal 2014 compared to fiscal 2013.  The Americas region contributed the largest portion of our revenue growth on an absolute dollar basis and all three regions showed growth on a percentage basis. Product revenue increased by $82.5 million, or 30%, compared to fiscal 2013. The increase in product

[0001262039-15-000009:mdna:114]
43

[0001262039-15-000009:mdna:115]
revenue was primarily driven by greater sales volume in our FortiGate product due to increased demand for our high-end products from large enterprise and service provider customers.

[0001262039-15-000009:mdna:116]
Services and other revenue increased by $72.6 million, or 22%, in fiscal 2014 compared to fiscal 2013 due to the recognition of revenue from our growing deferred revenue balance consisting of FortiGuard security subscription and FortiCare technical support contracts sold to a larger customer base as well as the renewals of similar contracts sold in earlier periods.

[0001262039-15-000009:mdna:117]
Cost of revenue and gross margin

[0001262039-15-000009:mdna:118]
|  | Year Ended December 31, |  |  |  |  |
| 2014 |  | 2013 |  | Change |  | % Change |
| (in thousands, except percentages) |
| Cost of revenue: |  |  |  |  |  |  |  |
| Product | $ | 151,300 |  |  | $ | 114,611 |  |  | $ | 36,689 |  |  | 32 | % |
| Services and other | 79,709 |  |  | 66,032 |  |  | 13,677 |  |  | 21 |  |
| Total cost of revenue | $ | 231,009 |  |  | $ | 180,643 |  |  | $ | 50,366 |  |  | 28 | % |
| Gross margin (%): |  |  |  |  |  |  |  |
| Product | 58.0 | % |  | 58.8 | % |  | (0.8 | )% |  |  |
| Services and other | 80.5 |  |  | 80.4 |  |  | 0.1 |  |  |  |
| Total gross margin | 70.0 | % |  | 70.6 | % |  | (0.6 | )% |  |  |

[0001262039-15-000009:mdna:119]
Total gross margin decreased by 0.6 percentage points in fiscal 2014 compared to fiscal 2013, as product gross margins declined. Product gross margin decreased by 0.8 percentage points in fiscal 2014 compared to fiscal 2013 due to an increase in warranty-related costs of $3.2 million and impairment charges related to certain intangible assets of $2.4 million. We also experienced increased freight costs of $2.0 million, higher excess inventory write-offs of $1.4 million, increased personnel-related costs of $0.9 million, and increased occupancy-related costs of $0.8 million.

[0001262039-15-000009:mdna:120]
Services and other gross margin remained relatively consistent during fiscal 2014 as compared to fiscal 2013. Cost of services and other revenue increased by $13.7 million primarily due to a $9.5 million increase in personnel costs, including stock-based compensation, related to headcount increases, a $1.4 million increase in depreciation, a $1.1 million increase in occupancy-related costs, and a $0.8 million increase in professional services.

[0001262039-15-000009:mdna:121]
Operating expenses

[0001262039-15-000009:mdna:122]
|  | Year Ended December 31, |  | Change |  | % Change |
| 2014 |  | 2013 |  |
| Amount |  | % ofRevenue |  | Amount |  | % ofRevenue |  |
| (in thousands, except percentages) |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | $ | 122,880 |  |  | 16 | % |  | $ | 102,660 |  |  | 17 | % |  | $ | 20,220 |  |  | 20 | % |
| Sales and marketing | 315,804 |  |  | 41 |  |  | 224,991 |  |  | 36 |  |  | 90,813 |  |  | 40 |  |
| General and administrative | 41,347 |  |  | 5 |  |  | 34,913 |  |  | 6 |  |  | 6,434 |  |  | 18 |  |
| Total operating expenses | $ | 480,031 |  |  | 62 | % |  | $ | 362,564 |  |  | 59 | % |  | $ | 117,467 |  |  | 32 | % |

[0001262039-15-000009:mdna:123]
Research and development

[0001262039-15-000009:mdna:124]
Research and development expense increased by $20.2 million, or 20%, in fiscal 2014 compared to fiscal 2013 primarily due to an increase of $12.0 million in personnel costs as a result of increased headcount to support the development of new products and continued enhancements of our existing products. In addition, stock-based compensation increased by $4.0 million, product development expenses, such as supplies and third-party testing and prototypes, increased by $3.4 million, occupancy-related costs and depreciation expense increased by $2.8 million, and professional services costs increased by $1.0 million. These increases were partially offset by a $3.0 million decrease in estimated contingent consideration. For discussion of the contingent consideration, see Note 2 of the notes to our consolidated financial statements in Part II, Item 8 of this Annual

[0001262039-15-000009:mdna:125]
Report on Form 10-K. We intend to continue to invest in our research and development organization but expect research and development expense as a percentage of total revenue to remain at comparable levels in fiscal 2015.

[0001262039-15-000009:mdna:126]
Sales and marketing

[0001262039-15-000009:mdna:127]
Sales and marketing expense increased by $90.8 million, or 40%, in fiscal 2014 compared to fiscal 2013, primarily due to an increase of $58.8 million in personnel costs as we continued to increase our sales headcount in order to drive continued market share gains globally. Marketing-related expenses increased by $12.9 million as we invested significantly in marketing to capture market share, particularly in the enterprise market, including costs related to tradeshows and lead generation campaigns. In addition, we incurred increases in stock-based compensation expense of $7.2 million, depreciation and other expenses of $4.4 million, travel expenses of $4.2 million, supplies of $2.2 million and occupancy-related cost of $1.0 million. As a percentage of total revenue, sales and marketing expenses increased as we accelerated the investment in our sales force and marketing campaigns to drive future growth. We intend to continue to make investments in our sales resources and infrastructure and marketing, which are critical to support growth and expect sales and marketing expense as a percentage of total revenue to increase in fiscal 2015.

[0001262039-15-000009:mdna:128]
General and administrative

[0001262039-15-000009:mdna:129]
General and administrative expense increased by $6.4 million, or 18%, in fiscal 2014 compared to fiscal 2013. Personnel costs, including stock-based compensation, increased by $6.8 million, as we continued to increase our headcount in order to support our expanding business. In addition, professional services fees increased $0.8 million, partially offset by a decrease of $1.3 million in occupancy-related costs including depreciation and supplies. We expect general and administrative expense to increase slightly as a percentage of total revenue in fiscal 2015.

[0001262039-15-000009:mdna:130]
Interest income and other expense—net

[0001262039-15-000009:mdna:131]
|  | Year Ended December 31, |  |  |  |  |
| 2014 |  | 2013 |  | Change |  | % Change |
| (in thousands, except percentages) |
| Interest income | $ | 5,393 |  |  | $ | 5,306 |  |  | $ | 87 |  |  | 2 | % |
| Other expense—net | (3,168 | ) |  | (1,455 | ) |  | (1,713 | ) |  | 118 |  |

[0001262039-15-000009:mdna:132]
The $0.1 million increase in interest income in fiscal 2014 compared to fiscal 2013 was primarily due to interest earned on higher invested balances of cash, cash equivalents and investments. The change in other expense—net, for fiscal 2014 when compared to fiscal 2013, was the result of higher foreign exchange losses and the impact of a reevaluation of the functional currency selection of certain of our international subsidiaries.

[0001262039-15-000009:mdna:133]
Provision for income taxes

[0001262039-15-000009:mdna:134]
|  | Year Ended December 31, |  | Change |  | % Change |
| 2014 |  | 2013 |  |
| (in thousands, except percentages) |
| Provision for income taxes | $ | 36,206 |  |  | $ | 31,668 |  |  | $ | 4,538 |  |  | 14 | % |
| Effective tax rate (%) | 59 | % |  | 42 | % |  | 17 | % |  | — |  |

[0001262039-15-000009:mdna:135]
Our effective tax rate was 59% for fiscal 2014, compared with an effective tax rate of 42% for fiscal 2013. The provision for income taxes for fiscal 2014 was comprised primarily of U.S. federal and state taxes, other foreign income taxes, foreign withholding taxes, discrete events resulting from an increase in tax reserves, as well as the inclusion of stock-based compensation benefits and transfer pricing allocations which impact jurisdictional income taxed at various tax rates. The increase in the effective tax rate in fiscal 2014 was primarily due to an increase in estimated tax liability related to foreign operations, an increase in tax reserves, an increase in non-tax deductible stock-based compensation expense, and limitations on utilizing foreign withholding tax credits.

[0001262039-15-000009:mdna:136]
It is our policy to classify accrued interest and penalties related to unrecognized tax benefits in the provision for income taxes. As of December 31, 2014, we had accrued $1.7 million for estimated interest related to uncertain tax provisions compared to an accrual of $1.0 million as of December 31, 2013.

[0001262039-15-000009:mdna:137]
45

[0001262039-15-000009:mdna:138]
Within the next twelve months, we do not believe there will be a decrease in uncertain tax benefits that could significantly impact our effective tax rate.

[0001262039-15-000009:mdna:139]
Fiscal Years 2013 and 2012

[0001262039-15-000009:mdna:140]
Revenue

[0001262039-15-000009:mdna:141]
|  | Year Ended December 31, |  | Change |  | % Change |
| 2013 |  | 2012 |  |
| Amount |  | % ofRevenue |  | Amount |  | % ofRevenue |  |
| (in thousands, except percentages) |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 278,046 |  |  | 45 | % |  | $ | 248,948 |  |  | 47 | % |  | $ | 29,098 |  |  | 12 | % |
| Services and other | 337,251 |  |  | 55 |  |  | 284,691 |  |  | 53 |  |  | 52,560 |  |  | 18 |  |
| Total revenue | $ | 615,297 |  |  | 100 | % |  | $ | 533,639 |  |  | 100 | % |  | $ | 81,658 |  |  | 15 | % |
| Revenue by Geography: |  |  |  |  |  |  |  |  |  |  |  |
| Americas | $ | 252,786 |  |  | 41 | % |  | $ | 217,056 |  |  | 41 | % |  | $ | 35,730 |  |  | 16 | % |
| EMEA | 208,979 |  |  | 34 |  |  | 184,175 |  |  | 35 |  |  | 24,804 |  |  | 13 |  |
| APAC | 153,532 |  |  | 25 |  |  | 132,408 |  |  | 24 |  |  | 21,124 |  |  | 16 |  |
| Total revenue | $ | 615,297 |  |  | 100 | % |  | $ | 533,639 |  |  | 100 | % |  | $ | 81,658 |  |  | 15 | % |

[0001262039-15-000009:mdna:142]
Total revenue increased by $81.7 million, or 15%, in fiscal 2013 compared to fiscal 2012. The Americas region contributed the largest portion of our revenue growth on an absolute dollar basis and all three regions showed growth on a percentage basis. The growth in EMEA was slightly lower due to a slowdown in the macroeconomic environment in that area. Product revenue increased by $29.1 million, or 12%, compared to fiscal 2012. The increase in product revenue was primarily driven by greater sales volume in our FortiGate product due to increased demand across all product categories from our entry-level and mid-range products for smaller enterprises and branch deployments to our high-end products for large enterprise and service provider customers. Services and other revenue increased by $52.6 million, or 18%, in fiscal 2013 compared to fiscal 2012 due to the recognition of revenue from our growing deferred revenue balance consisting of FortiGuard security subscription and FortiCare technical support contracts sold to a larger customer base as well as renewals of similar contracts sold in earlier periods.

[0001262039-15-000009:mdna:143]
Cost of revenue and gross margin

[0001262039-15-000009:mdna:144]
|  | Year Ended December 31, |  | Change |  | % Change |
| 2013 |  | 2012 |  |
| (in thousands, except percentages) |
| Cost of revenue: |  |  |  |  |  |  |  |
| Product | $ | 114,611 |  |  | $ | 93,971 |  |  | $ | 20,640 |  |  | 22 | % |
| Services and other | 66,032 |  |  | 53,449 |  |  | 12,583 |  |  | 24 |  |
| Total cost of revenue | $ | 180,643 |  |  | $ | 147,420 |  |  | $ | 33,223 |  |  | 23 | % |
| Gross margin (%): |  |  |  |  |  |  |  |
| Product | 58.8 | % |  | 62.3 | % |  | (3.5 | )% |  |  |
| Services and other | 80.4 |  |  | 81.2 |  |  | (0.8 | ) |  |  |
| Total gross margin | 70.6 | % |  | 72.4 | % |  | (1.8 | )% |  |  |

[0001262039-15-000009:mdna:145]
Total gross margin decreased by 1.8 percentage points in fiscal 2013 compared to fiscal 2012, as both product and services and other gross margins declined. Product gross margin decreased by 3.5 percentage points in fiscal 2013 compared to fiscal 2012 primarily due to a slightly higher mix of sales of entry-level products, particularly several high-volume distributed enterprise, retail and education deals sold in the fourth quarter of fiscal 2013. We also experienced higher warranty-related costs of $2.5 million, increased freight costs of $1.5 million, increased occupancy-related costs of $1.1 million and higher

[0001262039-15-000009:mdna:146]
excess inventory write-offs of $0.7 million. Services and other gross margin decreased by 0.8 percentage points during fiscal 2013 primarily due to our continued investments in our technical support organization to accommodate our expanding customer base and higher service level expectations from our enterprise customers. In addition, we experienced growth in our professional consulting services which have lower gross margins than our support and subscription businesses. Cost of services and other revenue increased by $12.6 million primarily due to a $9.9 million increase in personnel costs related to headcount increases, a $1.1 million increase in stock-based compensation expense, and a $2.4 million increase in depreciation and other expenses.

[0001262039-15-000009:mdna:147]
Operating expenses

[0001262039-15-000009:mdna:148]
|  | Year Ended December 31, |  | Change |  | % Change |
| 2013 |  | 2012 |  |
| Amount |  | % ofRevenue |  | Amount |  | % ofRevenue |  |
| (in thousands, except percentages) |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | $ | 102,660 |  |  | 17 | % |  | $ | 81,078 |  |  | 15 | % |  | $ | 21,582 |  |  | 27 | % |
| Sales and marketing | 224,991 |  |  | 36 |  |  | 179,155 |  |  | 33 |  |  | 45,836 |  |  | 26 |  |
| General and administrative | 34,913 |  |  | 6 |  |  | 25,511 |  |  | 5 |  |  | 9,402 |  |  | 37 |  |
| Total operating expenses | $ | 362,564 |  |  | 59 | % |  | $ | 285,744 |  |  | 53 | % |  | $ | 76,820 |  |  | 27 | % |

[0001262039-15-000009:mdna:149]
Research and development expense

[0001262039-15-000009:mdna:150]
Research and development expense increased by $21.6 million, or 27%, in fiscal 2013 compared to fiscal 2012 primarily due to an increase of $11.7 million in personnel costs as a result of increased headcount to support the development of new products and continued enhancements of our existing products. In addition, stock-based compensation expense increased by $4.0 million, product development expenses, such as third-party testing and prototypes, increased by $2.0 million, acquisition-related costs increased by $1.9 million, and depreciation and other expenses increased by $2.1 million.

[0001262039-15-000009:mdna:151]
Sales and marketing expense

[0001262039-15-000009:mdna:152]
Sales and marketing expense increased by $45.8 million, or 26%, in fiscal 2013 compared to fiscal 2012, primarily due to an increase of $25.6 million in personnel costs as we continued to increase our sales headcount in order to expand our global footprint. In addition, stock-based compensation expense increased by $6.7 million, marketing-related expenses increased by $5.4 million, travel expenses increased by $3.9 million, depreciation expenses increased by $2.1 million, and other expenses increased by $2.1 million. As a percentage of total revenue, sales and marketing expenses increased as we accelerated the investment in our sales force during fiscal 2013 to support future growth.

[0001262039-15-000009:mdna:153]
General and administrative expense

[0001262039-15-000009:mdna:154]
General and administrative expense increased by $9.4 million, or 37%, in fiscal 2013 compared to fiscal 2012. Personnel costs increased by $3.4 million and stock-based compensation expense increased by $1.8 million, as we continued to increase our headcount in order to support our expanding business. In addition, we incurred an additional $3.9 million of legal and accounting fees and $0.3 million in higher depreciation expense.

[0001262039-15-000009:mdna:155]
Interest income and other expense—net

[0001262039-15-000009:mdna:156]
|  | Year Ended December 31, |  | Change |  | % Change |
| 2013 |  | 2012 |  |
| (in thousands, except percentages) |
| Interest income | $ | 5,306 |  |  | $ | 5,006 |  |  | $ | 300 |  |  | 6 | % |
| Other expense—net | (1,455 | ) |  | (485 | ) |  | (970 | ) |  | 200 |  |

[0001262039-15-000009:mdna:157]
The $0.3 million increase in interest income in fiscal 2013 compared to fiscal 2012 was primarily due to interest earned on higher invested balances of cash, cash equivalents and investments. The change in other expense—net, for fiscal 2013 when compared to fiscal 2012, was the result of higher foreign exchange losses.

[0001262039-15-000009:mdna:158]
47

[0001262039-15-000009:mdna:159]
Provision for income taxes

[0001262039-15-000009:mdna:160]
|  | Year Ended December 31, |  | Change |  | % Change |
| 2013 |  | 2012 |  |
| (in thousands, except percentages) |
| Provision for income taxes | $ | 31,668 |  |  | $ | 38,160 |  |  | $ | (6,492 | ) |  | (17 | )% |
| Effective tax rate (%) | 42 | % |  | 36 | % |  | 6 | % |  | — |  |

[0001262039-15-000009:mdna:161]
Our effective tax rate was 42% for fiscal 2013, compared with an effective tax rate of 36% for fiscal 2012. The provision for income taxes for fiscal 2013 was comprised primarily of federal, state and foreign income taxes as well as the inclusion of stock-based compensation benefits and cost allocations, which affected the transfer pricing calculations among the United States and some of our foreign subsidiaries. The increase in the effective tax rate for fiscal 2013 as compared to fiscal 2012 was primarily due to an increase in profits subject to U.S. tax, a decrease in stock-based compensation benefits, and their corresponding impact on the transfer pricing calculations among the United States and some of our foreign subsidiaries

[0001262039-15-000009:mdna:162]
During January 2013, the U.S. Federal Research and Development Tax Credit was reinstated retroactively to fiscal 2012. The U.S. Federal Research and Development Tax Credit benefit was recorded in the first quarter of fiscal 2013, which was the period of enactment.

[0001262039-15-000009:mdna:163]
Beginning with fiscal 2013, we operate under a tax incentive agreement in Singapore, which is effective through December 31, 2023, and may be extended if certain additional requirements are satisfied. The tax incentive agreement is conditional upon our meeting certain employment and investment thresholds.

[0001262039-15-000009:mdna:164]
It is our policy to classify accrued interest and penalties related to unrecognized tax benefits in the provision for income taxes. As of December 31, 2013, we had accrued approximately $1.0 million for estimated interest related to uncertain tax provisions compared to an accrual of $1.5 million as of December 31, 2012.

[0001262039-15-000009:mdna:165]
48

[0001262039-15-000009:mdna:166]
Quarterly Results of Operations

[0001262039-15-000009:mdna:167]
The following table sets forth our unaudited quarterly statements of operations data for the last eight fiscal quarters. The information for each of these quarters has been prepared on the same basis as the audited annual financial statements included elsewhere in this Annual Report and, in the opinion of management, includes all adjustments, which includes only normal recurring adjustments, necessary for the fair presentation of the results of operations for these periods. This data should be read in conjunction with our audited consolidated financial statements and related notes included elsewhere in this annual report. These quarterly operating results are not necessarily indicative of our operating results for any future period.

[0001262039-15-000009:mdna:168]
|  | Three Months Ended |
|  | Dec 31,2014 |  | Sept 30,2014 |  | Jun 30,2014 |  | Mar 31,2014 |  | Dec 31,2013 |  | Sept 30,2013 |  | Jun 30,2013 |  | Mar 31,2013 |
|  | (in thousands, except per share amounts) |
| Consolidated Statements of Operations Data: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 110,678 |  |  | $ | 87,731 |  |  | $ | 85,384 |  |  | $ | 76,765 |  |  | $ | 83,884 |  |  | $ | 69,687 |  |  | $ | 66,525 |  |  | $ | 57,950 |  |
| Services and other | 113,291 |  |  | 105,617 |  |  | 98,714 |  |  | 92,184 |  |  | 93,466 |  |  | 85,012 |  |  | 80,903 |  |  | 77,870 |  |
| Total revenue | 223,969 |  |  | 193,348 |  |  | 184,098 |  |  | 168,949 |  |  | 177,350 |  |  | 154,699 |  |  | 147,428 |  |  | 135,820 |  |
| Cost of revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product (1)(2) | 46,070 |  |  | 35,636 |  |  | 37,455 |  |  | 32,139 |  |  | 37,579 |  |  | 27,126 |  |  | 26,948 |  |  | 22,958 |  |
| Services and other (1) | 19,554 |  |  | 21,249 |  |  | 20,302 |  |  | 18,604 |  |  | 16,298 |  |  | 16,804 |  |  | 16,760 |  |  | 16,170 |  |
| Total cost of revenue | 65,624 |  |  | 56,885 |  |  | 57,757 |  |  | 50,743 |  |  | 53,877 |  |  | 43,930 |  |  | 43,708 |  |  | 39,128 |  |
| Total gross profit | 158,345 |  |  | 136,463 |  |  | 126,341 |  |  | 118,206 |  |  | 123,473 |  |  | 110,769 |  |  | 103,720 |  |  | 96,692 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development (1) | 33,097 |  |  | 30,790 |  |  | 29,938 |  |  | 29,055 |  |  | 27,747 |  |  | 26,421 |  |  | 25,158 |  |  | 23,334 |  |
| Sales and marketing (1) | 93,228 |  |  | 80,433 |  |  | 74,817 |  |  | 67,326 |  |  | 62,331 |  |  | 56,687 |  |  | 55,997 |  |  | 49,976 |  |
| General and administrative (1) | 12,104 |  |  | 9,789 |  |  | 10,444 |  |  | 9,010 |  |  | 8,752 |  |  | 9,382 |  |  | 8,788 |  |  | 7,991 |  |
| Total operating expenses | 138,429 |  |  | 121,012 |  |  | 115,199 |  |  | 105,391 |  |  | 98,830 |  |  | 92,490 |  |  | 89,943 |  |  | 81,301 |  |
| Operating income | 19,916 |  |  | 15,451 |  |  | 11,142 |  |  | 12,815 |  |  | 24,643 |  |  | 18,279 |  |  | 13,777 |  |  | 15,391 |  |
| Interest income | 1,402 |  |  | 1,339 |  |  | 1,319 |  |  | 1,333 |  |  | 1,318 |  |  | 1,282 |  |  | 1,337 |  |  | 1,369 |  |
| Other (expense) income—net | (1,200 | ) |  | (1,005 | ) |  | (574 | ) |  | (389 | ) |  | (419 | ) |  | (1,151 | ) |  | (100 | ) |  | 215 |  |
| Income before income taxes | 20,118 |  |  | 15,785 |  |  | 11,887 |  |  | 13,759 |  |  | 25,542 |  |  | 18,410 |  |  | 15,014 |  |  | 16,975 |  |
| Provision for income taxes | 13,305 |  |  | 11,729 |  |  | 5,806 |  |  | 5,366 |  |  | 13,526 |  |  | 7,381 |  |  | 6,035 |  |  | 4,726 |  |
| Net income | $ | 6,813 |  |  | $ | 4,056 |  |  | $ | 6,081 |  |  | $ | 8,393 |  |  | $ | 12,016 |  |  | $ | 11,029 |  |  | $ | 8,979 |  |  | $ | 12,249 |  |
| Net income per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic | $ | 0.04 |  |  | $ | 0.02 |  |  | $ | 0.04 |  |  | 0.05 |  |  | $ | 0.07 |  |  | $ | 0.07 |  |  | $ | 0.06 |  |  | $ | 0.08 |  |
| Diluted | $ | 0.04 |  |  | $ | 0.02 |  |  | $ | 0.04 |  |  | $ | 0.05 |  |  | $ | 0.07 |  |  | $ | 0.07 |  |  | $ | 0.05 |  |  | $ | 0.07 |  |

[0001262039-15-000009:mdna:169]
__________________________

[0001262039-15-000009:mdna:170]
| (1) | Includes stock-based compensation expense as follows: |

[0001262039-15-000009:mdna:171]
|  | Three Months Ended |
|  | Dec 31,2014 |  | Sept 30,2014 |  | Jun 30,2014 |  | Mar 31,2014 |  | Dec 31,2013 |  | Sept 30,2013 |  | Jun 30,2013 |  | Mar 31,2013 |
|  | (in thousands) |
| Cost of product revenue | $ | 132 |  |  | $ | 60 |  |  | $ | 178 |  |  | $ | 113 |  |  | $ | 106 |  |  | $ | 91 |  |  | $ | 96 |  |  | $ | 90 |  |
| Cost of services revenue | 1,612 |  |  | 1,522 |  |  | 1,363 |  |  | 1,329 |  |  | 1,298 |  |  | 1,297 |  |  | 1,226 |  |  | 1,020 |  |
| Research and development | 4,706 |  |  | 4,505 |  |  | 4,171 |  |  | 3,882 |  |  | 3,666 |  |  | 3,548 |  |  | 3,291 |  |  | 2,766 |  |
| Sales and marketing | 7,854 |  |  | 7,397 |  |  | 5,747 |  |  | 5,746 |  |  | 5,599 |  |  | 5,215 |  |  | 4,594 |  |  | 4,118 |  |
| General and administrative | 2,377 |  |  | 1,183 |  |  | 3,257 |  |  | 1,860 |  |  | 2,018 |  |  | 1,627 |  |  | 1,500 |  |  | 1,305 |  |
| Total stock-based compensation expense | $ | 16,681 |  |  | $ | 14,667 |  |  | $ | 14,716 |  |  | $ | 12,930 |  |  | $ | 12,687 |  |  | $ | 11,778 |  |  | $ | 10,707 |  |  | $ | 9,299 |  |

[0001262039-15-000009:mdna:172]
_______________________________________________

[0001262039-15-000009:mdna:173]
| (2) | Includes amortization expense and impairment charges related to certain intangible assets as follows: |

[0001262039-15-000009:mdna:174]
|  | Three Months Ended |
|  | Dec 31,2014 |  | Sept 30,2014 |  | Jun 30,2014 |  | Mar 31,2014 |  | Dec 31,2013 |  | Sept 30,2013 |  | Jun 30,2013 |  | Mar 31,2013 |
|  | (in thousands) |
| Amortization expense of certain intangible assets | $ | 244 |  |  | $ | 244 |  |  | $ | 408 |  |  | $ | 511 |  |  | $ | 508 |  |  | $ | 423 |  |  | $ | 354 |  |  | $ | 266 |  |
| Impairment charges related to certain intangible assets |  |  | — |  |  | 2,404 |  |  | — |  |  | 469 |  |  | — |  |  | — |  |  | — |  |
| Total amortization expense and impairment charges related to certain intangible assets | $ | 244 |  |  | $ | 244 |  |  | $ | 2,812 |  |  | $ | 511 |  |  | $ | 977 |  |  | $ | 423 |  |  | $ | 354 |  |  | $ | 266 |  |

[0001262039-15-000009:mdna:175]
Seasonality, Cyclicality and Quarterly Revenue Trends

[0001262039-15-000009:mdna:176]
Our quarterly results reflect a pattern of increased customer buying at year-end, which has positively impacted sales activity in the fourth quarter. In the first quarter we generally experience lower sequential billings and product revenue, which results in lower revenue. In the third quarter, we generally experience lower sequential billings and revenue in Europe due to reduced economic activity in Europe during the summer months, but this may not always be the case. Similarly, our operating income has been affected by these historical trends because operating expenses are relatively fixed in the near-term. Although these seasonal factors are common in the technology sector, historical patterns should not be considered a reliable indicator of our future sales activity or performance. On a quarterly basis, we have usually generated the majority of our product revenue in the final month of each quarter and a significant amount in the last two weeks of each quarter. We believe this is due to customer buying patterns typical in this industry.

[0001262039-15-000009:mdna:177]
Our total quarterly revenue over the past eight quarters has generally increased sequentially in each quarter, except in the first quarter of 2014. Product revenue in all of the quarters of fiscal 2014 was higher as compared to the same periods in fiscal 2013, which we believe was due in part to the investments made in our sales and marketing organizations and continued product innovation.

[0001262039-15-000009:mdna:178]
Total gross margin has fluctuated on a quarterly basis primarily due to shifts in the mix of sales between products and services.  Product gross margins, on average throughout the fiscal year, slightly decreased in fiscal 2014 compared to the same quarter of fiscal 2013 due to product mix. Product gross margin varies based on the types of products sold and the average selling prices of our products. Service gross margins, on average throughout the fiscal year, remained relatively consistent in fiscal 2014 compared to fiscal 2013.

[0001262039-15-000009:mdna:179]
50

[0001262039-15-000009:mdna:180]
Liquidity and Capital Resources

[0001262039-15-000009:mdna:181]
|  | December 31 |
|  | 2014 |  | 2013 |  | 2012 |
|  | (in thousands) |
| Cash and cash equivalents | $ | 283,254 |  |  | $ | 115,873 |  |  | $ | 122,975 |  |
| Investments | 708,490 |  |  | 727,172 |  |  | 616,611 |  |
| Total cash, cash equivalents and investments | $ | 991,744 |  |  | $ | 843,045 |  |  | $ | 739,586 |  |
| Working capital | $ | 550,409 |  |  | $ | 322,485 |  |  | $ | 249,970 |  |
|  | Year Ended December 31, |
|  | 2014 |  | 2013 |  | 2012 |
|  | (in thousands) |
| Cash provided by operating activities | $ | 196,582 |  |  | $ | 147,384 |  |  | $ | 183,866 |  |
| Cash used in investing activities | (29,350 | ) |  | (146,734 | ) |  | (182,711 | ) |
| Cash (used in) provided by financing activities | 749 |  |  | (6,423 | ) |  | 50,156 |  |
| Effect of exchange rates on cash and cash equivalents | (600 | ) |  | (1,329 | ) |  | (326 | ) |
| Net (decrease) increase in cash and cash equivalents | $ | 167,381 |  |  | $ | (7,102 | ) |  | $ | 50,985 |  |

[0001262039-15-000009:mdna:182]
Liquidity and capital resources may be impacted by our operating activities, as well as acquisitions, capital expenditures, stock repurchases, proceeds associated with stock option exercises and issuances of common stock, and investments in strategic relationships that we have made or may make in the future. In January 2014, we received a cash payment of $20.0 million pursuant to a six year mutual covenant-not-to-sue and release agreement with Palo Alto Networks, Inc. As of December 31, 2014, $122.5 million remains available for future share repurchases under our stock repurchase program, which will be financed through our available working capital.  In recent years we have received significant capital resources related to the exercise of stock options and purchases under our ESPP.  We expect proceeds in future years to be impacted by our share price and the mix of stock options and RSUs issued.  We expect to spend approximately $42.0 million related to our capital expenditures, primarily related to purchase of computer equipment, expansion of our offices, as well as the implementation of our enterprise resource planning system in fiscal 2015.

[0001262039-15-000009:mdna:183]
As of December 31, 2014, our cash, cash equivalents, and investments of $991.7 million were held for working-capital purposes and were invested primarily in corporate debt securities, commercial paper,  municipal bonds, certificates of deposit and term deposits, money market funds, and U.S. government and agency debt securities. It is our investment policy to invest excess cash in a manner that preserves capital, provides liquidity and maximizes return without significantly increasing risk.

[0001262039-15-000009:mdna:184]
As of December 31, 2014, $265.6 million of our cash and investments was held by our international subsidiaries and is therefore not immediately available to fund domestic operations unless the cash is repatriated. While we do not intend to do so, should this amount be repatriated, it would be subject to U.S. federal income tax which would be partially offset by foreign tax credits. We do not enter into investments for trading or speculative purposes. We believe that our existing cash and cash equivalents will be sufficient to meet our anticipated cash needs for at least the next 12 months. Our future capital requirements will depend on many factors including our growth rate, the timing and extent of spending to support development efforts, the expansion of sales and marketing activities, the introduction of new and enhanced products and services offerings, the costs to ensure access to adequate manufacturing capacity and the continuing market acceptance of our products. Historically, we have required capital principally to fund our working capital needs, capital expenditures, share repurchases, and acquisition activities. In the event that additional financing is required from outside sources, we may not be able to raise it on terms acceptable to us or at all. If we are unable to raise additional capital when desired, our business, operating results and financial condition would be adversely affected.

[0001262039-15-000009:mdna:185]
Operating Activities

[0001262039-15-000009:mdna:186]
Cash generated by operating activities is our primary source of liquidity. It is primarily comprised of net income, adjusted for non-cash items, and changes in operating assets and liabilities. Non-cash adjustments consist primarily of stock-based compensation, depreciation of property and equipment, amortization of intangible assets, excess tax benefit from stock-based compensation, and amortization of investment premiums.

[0001262039-15-000009:mdna:187]
Our operating activities during fiscal 2014 provided $196.6 million in cash as a result of profitability, timing of billings and collections, and the ability to successfully manage our working capital. The primary sources of cash from operating activities during fiscal 2014 consisted of net income of $25.3 million increased by non-cash adjustments of $93.9 million and changes in operating assets and liabilities of $77.4 million. In January 2014, we received $20.0 million pursuant to a six-year mutual covenant-not-to-sue and release agreement with Palo Alto Networks, Inc. Changes in operating assets and liabilities primarily included an increase in payments received from customers and a receipt of cash related to the mutual covenant-not-to-sue and release agreement, partially offset by payments for inventory purchases, prepayment of certain expenses, and payments of income taxes during the period.

[0001262039-15-000009:mdna:188]
Our operating activities during fiscal 2013 provided $147.4 million in cash as a result of profitability, timing of billings and collections, and the ability to successfully manage our working capital. The primary sources of cash from operating activities during fiscal 2013 consisted of net income of $44.3 million increased by non-cash adjustments of $69.2 million and changes in operating assets and liabilities of $33.9 million. Changes in operating assets and liabilities primarily included an increase in payments received from customers, partially offset by payments for inventory purchases.

[0001262039-15-000009:mdna:189]
Our operating activities during fiscal 2012 provided $183.9 million in cash as a result of profitability, timing of billings and collections, and the ability to successfully manage our working capital. The primary sources of cash from operating activities during fiscal 2012 consisted of net income of $66.8 million increased by non-cash adjustments of $44.0 million and changes in operating assets and liabilities of $73.0 million. Changes in operating assets and liabilities primarily included an increase in payments received from customers, partially offset by payments for inventory purchases.

[0001262039-15-000009:mdna:190]
Investing Activities

[0001262039-15-000009:mdna:191]
The changes in cash flows from investing activities primarily relate to timing of purchases, maturities, and sales of investments, purchases of property and equipment, and payments made in connection with acquisitions.

[0001262039-15-000009:mdna:192]
During fiscal 2014, cash used for investing activities was primarily due to $32.2 million spent on capital expenditures, partially offset by positive cash flow due to maturities, net of purchases, from our investments of $2.9 million.

[0001262039-15-000009:mdna:193]
During fiscal 2013, cash used for investing activities was primarily due to $125.2 million of net purchases of investments, $13.9 million for the purchases of property and equipment, and $7.6 million for acquisitions.

[0001262039-15-000009:mdna:194]
During fiscal 2012, cash used for investing activities was primarily due to $159.4 million of net purchases of investments, $22.1 million for the purchases of property and equipment, and $1.2 million for acquisitions.

[0001262039-15-000009:mdna:195]
Financing Activities

[0001262039-15-000009:mdna:196]
The changes in cash flows from financing activities primarily relate to proceeds from the issuance of common stock, taxes paid related to net share settlement of equity awards, excess tax benefit from stock-based compensation, and repurchase and retirement of common stock.

[0001262039-15-000009:mdna:197]
During fiscal 2014, cash provided by financing activities was $0.7 million as a result of proceeds of $55.3 million from the issuance of common stock under our stock plans. This cash inflow was partially offset by $44.0 million of common stock repurchases and $10.6 million of taxes payment related to withholding upon the issuance of RSUs.

[0001262039-15-000009:mdna:198]
During fiscal 2013, cash used in financing activities was $6.4 million as a result of our repurchase and retirement of $33.5 million of common stock and our net-share settlement of RSUs of $1.5 million. This was offset by receiving proceeds of $12.9 million and $12.7 million from the issuance of common stock under our stock option plans and ESPP, respectively, and an excess tax benefit from employee stock option exercises of $3.0 million.

[0001262039-15-000009:mdna:199]
During fiscal 2012, cash provided by financing activities was $50.2 million as a result of proceeds of $38.1 million from the issuance of common stock under our equity-based incentive plans and an excess tax benefit of $12.1 million

[0001262039-15-000009:mdna:200]
Contractual Obligations and Commitments

[0001262039-15-000009:mdna:201]
The following summarizes our contractual obligations as of December 31, 2014:

[0001262039-15-000009:mdna:202]
|  | Payments Due by Period |
|  | Total |  | Less than 1 year |  | 1 - 3 years |  | 3 - 5 years |  | More than 5 years |
|  | (in thousands) |
| Operating leases (1) | $ | 42,624 |  |  | $ | 11,535 |  |  | $ | 23,365 |  |  | $ | 7,274 |  |  | $ | 450 |  |
| Purchase commitments (2) | 62,804 |  |  | 62,804 |  |  | — |  |  | — |  |  | — |  |
| Other contracts (3) | 21,006 |  |  | 18,169 |  |  | 2,837 |  |  | — |  |  | — |  |
| Total | $ | 126,434 |  |  | $ | 92,508 |  |  | $ | 26,202 |  |  | $ | 7,274 |  |  | $ | 450 |  |

[0001262039-15-000009:mdna:203]
________________________

[0001262039-15-000009:mdna:204]
| (1) | Consists of contractual obligations from non-cancelable office space under operating leases. |

[0001262039-15-000009:mdna:205]
| (2) | Consists of minimum purchase commitments with independent contract manufacturers. |

[0001262039-15-000009:mdna:206]
| (3) | Consists of an estimate of all open purchase orders and contractual obligations in the ordinary course of business, other than commitments with contract manufacturers and suppliers, for which we have not received the goods or services. Purchase obligations do not include contracts that may be cancelled without penalty. Although open purchase orders are considered enforceable and legally binding, the terms generally allow us the option to cancel, reschedule, and adjust our requirements based on our business needs prior to the delivery of goods or performance of services. No tax liabilities related to uncertain tax positions have been included in the table. As of December 31, 2014, we had $45.1 million of long-term tax liabilities, including interest, related to uncertain tax positions. Because of the high degree of uncertainty regarding the settlement of these liabilities, we are unable to estimate the years in which future cash outflows may occur. |

[0001262039-15-000009:mdna:207]
Off-Balance Sheet Arrangements

[0001262039-15-000009:mdna:208]
During fiscal 2014, fiscal 2013 and fiscal 2012, we did not have any relationships with unconsolidated organizations or financial partnerships, such as structured finance or special purpose entities that would have been established for the purpose of facilitating off-balance sheet arrangements or other contractually narrow or limited purposes.

[0001262039-15-000009:mdna:209]
Recent Accounting Pronouncement

[0001262039-15-000009:mdna:210]
See Note 1 of the notes to our consolidated financial statements in Part II, Item 8 of this Annual Report on Form 10-K for a full description of recently adopted accounting pronouncements.
