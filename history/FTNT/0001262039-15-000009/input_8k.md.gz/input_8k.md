# FTNT 8-K — 0001262039-15-000005 filed 2015-01-28

## item codes, every 8-K on or before 2015-03-02

- 2015-01-28 0001262039-15-000005 — 2.02, 9.01
- 2014-10-22 0001262039-14-000036 — 2.02, 9.01
- 2014-07-23 0001262039-14-000030 — 2.02, 9.01
- 2014-06-24 0001262039-14-000027 — 5.07
- 2014-04-23 0001262039-14-000021 — 2.02, 9.01
- 2014-04-21 0001262039-14-000018 — 5.03, 9.01
- 2014-01-29 0001262039-14-000004 — 2.02, 9.01
- 2013-12-20 0001262039-13-000061 — 5.02, 9.01
- 2013-11-27 0001262039-13-000057 — 5.02, 7.01, 9.01
- 2013-11-12 0001445305-13-002993 — 5.02
- 2013-10-23 0001262039-13-000051 — 2.02, 9.01
- 2013-07-30 0001262039-13-000039 — 2.02, 9.01
- 2013-06-25 0001262039-13-000030 — 5.07
- 2013-04-30 0001262039-13-000023 — 2.02, 9.01
- 2013-04-19 0001262039-13-000020 — 5.02, 9.01
- 2013-04-19 0001262039-13-000018 — 5.02 — amendment of 0001262039-13-000020
- 2013-04-10 0001262039-13-000016 — 2.02, 9.01
- 2013-03-26 0001262039-13-000013 — 5.02
- 2013-01-30 0001262039-13-000005 — 2.02, 9.01
- 2013-01-24 0001262039-13-000002 — 5.02, 9.01
- 2012-10-16 0001262039-12-000048 — 2.02, 9.01
- 2012-10-01 0001262039-12-000045 — 5.02
- 2012-09-26 0001262039-12-000043 — 5.01
- 2012-07-25 0001262039-12-000038 — 2.02, 9.01
- 2012-07-19 0001262039-12-000034 — 5.02
- 2012-06-20 0001193125-12-275869 — 5.07
- 2012-04-27 0001262039-12-000029 — 5.02
- 2012-04-24 0001262039-12-000025 — 2.02, 9.01
- 2012-01-31 0001262039-12-000006 — 2.02, 9.01
- 2012-01-25 0001262039-12-000003 — 5.03
- 2011-10-24 0001262039-11-000036 — 2.02
- 2011-07-19 0001262039-11-000014 — 2.02, 9.01
- 2011-06-27 0001193125-11-174474 — 5.02, 5.07, 9.01
- 2011-04-27 0001193125-11-111938 — 2.02, 9.01
- 2011-01-25 0001193125-11-013914 — 2.02, 9.01
- 2010-10-21 0001193125-10-233676 — 2.02, 9.01
- 2010-09-02 0001193125-10-203099 — 8.01
- 2010-07-22 0001193125-10-163844 — 2.02, 9.01
- 2010-06-24 0001193125-10-146082 — 5.07
- 2010-04-28 0001193125-10-096698 — 2.02, 9.01
- 2010-02-09 0001193125-10-024614 — 8.01
- 2010-01-27 0001193125-10-014292 — 2.02, 9.01
- 2010-01-26 0001193125-10-013031 — 5.02, 9.01

## late-filing notifications on or before 2015-03-02

- none on or before 2015-03-02

## item 2.02 — earnings release, exhibit 99.1

[0001262039-15-000005:8k_2_02:1]
EX-99.1
2
ftntq4-2014ex991.htm
PRESS RELEASE

[0001262039-15-000005:8k_2_02:2]
FTNT Q4-2014 EX 99.1

[0001262039-15-000005:8k_2_02:3]
Press Release

[0001262039-15-000005:8k_2_02:4]
| Investor Contact: |  | Media Contact: |
| Michelle Spolver |  | Andrea Cousens |
| Fortinet, Inc. |  | Fortinet, Inc. |
| 408-486-7837 |  | 310-270-8903 |
| mspolver@fortinet.com |  | acousens@fortinet.com |

[0001262039-15-000005:8k_2_02:5]
Fortinet Reports Strong Fourth Quarter and Full Year 2014 Financial Results

[0001262039-15-000005:8k_2_02:6]
Investment Strategy Paying Off: Q4 Billings Rise 35% year over year and FY14 Billings Grow 31% year over year

[0001262039-15-000005:8k_2_02:7]
Fourth Quarter 2014 Highlights

[0001262039-15-000005:8k_2_02:8]
•Billings of $282.7 million, up 35% year over year1

[0001262039-15-000005:8k_2_02:9]
•Revenues of $224.0 million, up 26% year over year

[0001262039-15-000005:8k_2_02:10]
•Non-GAAP diluted net income per share of $0.141

[0001262039-15-000005:8k_2_02:11]
•Cash flow from operations of $35.4 million

[0001262039-15-000005:8k_2_02:12]
•Free cash flow of $30.0 million1

[0001262039-15-000005:8k_2_02:13]
| • | Cash, cash equivalents and investments of $991.7 million |

[0001262039-15-000005:8k_2_02:14]
| • | Deferred revenue of $558.8 million, up 29% year over year |

[0001262039-15-000005:8k_2_02:15]
Full Year 2014 Highlights

[0001262039-15-000005:8k_2_02:16]
•Billings of $896.5 million, up 31% year over year1

[0001262039-15-000005:8k_2_02:17]
•Revenues of $770.4 million, up 25% year over year

[0001262039-15-000005:8k_2_02:18]
•Non-GAAP diluted net income per share of $0.481

[0001262039-15-000005:8k_2_02:19]
•Cash flow from operations of $196.6 million

[0001262039-15-000005:8k_2_02:20]
•Free cash flow of $164.4 million1

[0001262039-15-000005:8k_2_02:21]
SUNNYVALE, Calif. - January 28, 2015 - Fortinet® (NASDAQ: FTNT), a global leader in high performance cyber security solutions, today announced financial results for the fourth quarter and full year ended December 31, 2014.

[0001262039-15-000005:8k_2_02:22]
“Fortinet had an excellent fourth quarter, exceeding or meeting our expectations across all key metrics,” said Ken Xie, founder, chairman and chief executive officer of Fortinet. “We are a growth-oriented company, we've been investing for growth, and that strategy is paying off. Our Q4 billings growth was the highest in sixteen quarters and we saw a continued increase in new enterprise customer wins and the number of large deals closed. Cyber security remains at the forefront of enterprise IT priorities and Fortinet has a proven platform of competitively-differentiated products and threat research to address these complex threats.  Entering 2015,

[0001262039-15-000005:8k_2_02:23]
we are confident in our direction and opportunity and thus are continuing to invest for future growth and market share gains.”

[0001262039-15-000005:8k_2_02:24]
Financial Highlights for the Fourth Quarter of 2014

[0001262039-15-000005:8k_2_02:25]
| • | Billings1: Total billings were $282.7 million for the fourth quarter of 2014, an increase of 35% compared to $209.8 million in the same quarter of 2013. |

[0001262039-15-000005:8k_2_02:26]
| • | Revenue4: Total revenue was $224.0 million for the fourth quarter of 2014, an increase of 26% compared to $177.4 million in the same quarter of 2013. Within total revenue, product revenue was $110.7 million, an increase of 32% compared to the same quarter of 2013. Services and other revenue was $113.3 million, an increase of 21% compared to the same quarter of 2013. |

[0001262039-15-000005:8k_2_02:27]
| • | Deferred Revenue: Total deferred revenue was $558.8 million as of December 31, 2014, an increase of $58.7 million from $500.0 million as of September 30, 2014. |

[0001262039-15-000005:8k_2_02:28]
| • | Cash and Cash Flow2: As of December 31, 2014, cash, cash equivalents and investments were $991.7 million, compared to $963.8 million as of September 30, 2014. In the fourth quarter of 2014, cash flow from operations was $35.4 million and free cash flow1 was $30.0 million. |

[0001262039-15-000005:8k_2_02:29]
| • | GAAP Operating Income: GAAP operating income was $19.9 million for the fourth quarter of 2014, representing a GAAP operating margin of 9%. GAAP operating income was $24.6 million for the same quarter of 2013, representing a GAAP operating margin of 14%. |

[0001262039-15-000005:8k_2_02:30]
| • | GAAP Net Income and Diluted Net Income Per Share: GAAP net income was $6.8 million for the fourth quarter of 2014, compared to GAAP net income of $12.0 million for the same quarter of 2013. GAAP diluted net income per share was $0.04 for the fourth quarter of 2014, compared to $0.07 for the same quarter of 2013. |

[0001262039-15-000005:8k_2_02:31]
| • | Non-GAAP Operating Income1: Non-GAAP operating income was $36.8 million for the fourth quarter of 2014, representing a non-GAAP operating margin of 16%. Non-GAAP operating income was $38.3 million for the same quarter of 2013, representing a non-GAAP operating margin of 22%. |

[0001262039-15-000005:8k_2_02:32]
| • | Non-GAAP Net Income and Diluted Net Income Per Share1: Non-GAAP net income was $24.1 million for the fourth quarter of 2014, compared to non-GAAP net income of $26.3 million for the same quarter of 2013. Non-GAAP diluted net income per share was $0.14 for the fourth quarter of 2014, compared to $0.16 for the same quarter of 2013. |

[0001262039-15-000005:8k_2_02:33]
Financial Highlights for the Full Year 2014

[0001262039-15-000005:8k_2_02:34]
| • | Billings1: Total billings were $896.5 million for fiscal 2014, an increase of 31% compared to $684.2 million in fiscal 2013. |

[0001262039-15-000005:8k_2_02:35]
| • | Revenue4: Total revenue was $770.4 million for fiscal 2014, an increase of 25% compared to $615.3 million in fiscal 2013. Within total revenue, product revenue was $360.6 million, an increase of 30% compared to fiscal 2013. Services and other revenue was $409.8 million, an increase of 22% compared to fiscal 2013. |

[0001262039-15-000005:8k_2_02:36]
| • | Deferred Revenue: Total deferred revenue was $558.8 million as of December 31, 2014, an increase of 29% compared to deferred revenue of $432.6 million as of December 31, 2013. |

[0001262039-15-000005:8k_2_02:37]
| • | Cash and Cash Flow3: As of December 31, 2014, cash, cash equivalents and investments were $991.7 million, compared to $843.0 million as of December 31, 2013. In fiscal 2014, cash flow from operations was $196.6 million and free cash flow1 was $164.4 million. |

[0001262039-15-000005:8k_2_02:38]
| • | GAAP Operating Income: GAAP operating income was $59.3 million for fiscal 2014, representing a GAAP operating margin of 8%. GAAP operating income was $72.1 million for fiscal 2013, representing a GAAP operating margin of 12%. |

[0001262039-15-000005:8k_2_02:39]
| • | GAAP Net Income and Diluted Net Income Per Share: GAAP net income was $25.3 million for fiscal 2014, compared to GAAP net income of $44.3 million for fiscal 2013. GAAP diluted net income per share was $0.15 for fiscal 2014, compared to $0.26 for fiscal 2013. |

[0001262039-15-000005:8k_2_02:40]
| • | Non-GAAP Operating Income1: Non-GAAP operating income was $122.1 million for fiscal 2014, representing a non-GAAP operating margin of 16%. Non-GAAP operating income was $118.6 million for fiscal 2013, representing a non-GAAP operating margin of 19%. |

[0001262039-15-000005:8k_2_02:41]
| • | Non-GAAP Net Income and Diluted Net Income Per Share1: Non-GAAP net income was $80.8 million for fiscal 2014, compared to non-GAAP net income of $82.0 million for fiscal 2013. Non-GAAP diluted net income per share was $0.48 for fiscal 2014, compared to $0.49 for fiscal 2013. |

[0001262039-15-000005:8k_2_02:42]
1 A reconciliation of GAAP to non-GAAP financial measures has been provided in the financial statement tables included in this press release. An explanation of these measures is also included below under the heading “Non-GAAP Financial Measures.”

[0001262039-15-000005:8k_2_02:43]
2 During the fourth quarter of fiscal 2014, we repurchased $5.4 million of our common stock under our share repurchase program.

[0001262039-15-000005:8k_2_02:44]
3 During fiscal 2014, we repurchased $38.6 million of our common stock under our share repurchase program.

[0001262039-15-000005:8k_2_02:45]
4 Beginning in the first quarter of 2014, we combined ratable and other revenue with services revenue to present the combined amounts as services and other revenue in the consolidated statements of operations. The related cost of revenue and gross profit, including prior period amounts, have also been combined to conform to the current period presentation. We believe the ratable and other revenue amounts, including the related cost of revenue and gross profit amounts, are not material.

[0001262039-15-000005:8k_2_02:46]
Conference Call Details

[0001262039-15-000005:8k_2_02:47]
Fortinet will host a conference call today, January 28, 2015, at 1:30 p.m. Pacific Time (4:30 p.m. Eastern Time) to discuss its financial results.  To access this call, dial (877) 303-6913 (domestic) or (224) 357-2188 (international) with conference ID # 62498213. A live webcast of the conference call and supplemental slides will be accessible from the Investor Relations page of Fortinet's website at http://investor.fortinet.com and a replay will be archived and accessible at http://investor.fortinet.com/events.cfm.  A replay of this conference call can also be accessed through February 4, 2015, by dialing (855) 859-2056 (domestic) or (404) 537-3406 (international) with conference ID# 62498213.

[0001262039-15-000005:8k_2_02:48]
Following Fortinet's financial results conference call, the Company will host an additional question-and-answer session at 3:30 p.m. Pacific Time (6:30 p.m. Eastern Time) to provide an opportunity for financial analysts and investors to ask more detailed questions. To access this call, dial (877) 303-6913 (domestic) or (224) 357-2188 (international) with conference ID # 62499586. This follow-up call will be webcast live and accessible at http://investor.fortinet.com, and a replay will be archived and available after the call at http://investor.fortinet.com/events.cfm. A replay of this conference call will also be available through February 4, 2015 by dialing (855) 859-2056 (domestic) or (404) 537-3406 (international) with conference ID # 62499586.

[0001262039-15-000005:8k_2_02:49]
Fortinet (NASDAQ: FTNT) protects the most valuable assets of some of the largest enterprise, service provider and government organizations across the globe. The company's fast, secure and global cyber security solutions provide broad, high-performance protection against dynamic security threats while simplifying the IT infrastructure. They are strengthened by the industry's highest level of threat research, intelligence and analytics. Unlike pure-play network security providers, Fortinet can solve organizations' most important security challenges, whether in networked, application or mobile environments - be it virtualized/cloud or physical. More than 200,000 customers worldwide, including some of the largest and most complex organizations, trust Fortinet to protect their brands. Learn more at http://www.fortinet.com, the Fortinet Blog or FortiGuard Labs.

[0001262039-15-000005:8k_2_02:50]
#          #          #

[0001262039-15-000005:8k_2_02:51]
Copyright © 2015 Fortinet, Inc. All rights reserved. The symbols ® and ™ denote respectively federally registered trademarks and unregistered trademarks of Fortinet, Inc., its subsidiaries and affiliates. Fortinet's trademarks include, but are not limited to, the following: Fortinet, FortiGate, FortiGuard, FortiManager, FortiMail, FortiClient, FortiCare, FortiAnalyzer, FortiReporter, FortiOS, FortiASIC, FortiWiFi, FortiSwitch, FortiVoIP, FortiBIOS, FortiLog, FortiResponse, FortiCarrier, FortiScan, FortiAP, FortiDB, FortiVoice and FortiWeb. Other trademarks belong to their respective owners.

[0001262039-15-000005:8k_2_02:52]
FTNT-F

[0001262039-15-000005:8k_2_02:53]
Forward-looking Statements

[0001262039-15-000005:8k_2_02:54]
This press release contains forward-looking statements that involve risks and uncertainties. These forward-looking statements include statements regarding confidence in our business and current expectations regarding business momentum, growth and market share gains. Although we attempt to be accurate in making forward-looking statements, it is possible that future circumstances might differ from the assumptions on which such statements are based. Important factors that could cause results to differ materially from the statements herein include the following: general economic risks; increasing competitiveness in the security market; the dynamic nature of the security market; specific economic risks in different geographies, and among different customer segments; uncertainty regarding increased business and renewals from existing customers; uncertainties around continued success in sales growth and market share gains; the risk that our investments in sales and marketing will not continue to generate additional sales; failure to convert sales pipeline into final sales; risks associated with successful implementation of multiple integrated software products and other product functionality risks; execution risks around new product development and introductions and innovation; litigation and disputes and the potential cost, distraction and damage to sales and reputation caused thereby; market acceptance of new products and services; the ability to attract and retain

[0001262039-15-000005:8k_2_02:55]
Non-GAAP Financial Measures

[0001262039-15-000005:8k_2_02:56]
We have provided in this release financial information that has not been prepared in accordance with Generally Accepted Accounting Principles (GAAP). These non-GAAP financial measures are not based on any standardized methodology prescribed by GAAP and are not necessarily comparable to similar measures presented by other companies. We use these non-GAAP financial measures internally in analyzing our financial results and believe they are useful to investors, as a supplement to GAAP measures, in evaluating our ongoing operational performance. We believe that the use of these non-GAAP financial measures provides an additional tool for investors to use in evaluating ongoing operating results and trends and in comparing our financial results with other companies in our industry, many of which present similar non-GAAP financial measures to investors.

[0001262039-15-000005:8k_2_02:57]
Non-GAAP financial measures should not be considered in isolation from, or as a substitute for, financial information prepared in accordance with GAAP. Investors are encouraged to review the reconciliation of these non-GAAP financial measures to their most directly comparable GAAP financial measures below. As previously mentioned, a reconciliation of our non-GAAP financial measures to their most directly comparable GAAP measures has been provided in the financial statement tables included below in this press release.

[0001262039-15-000005:8k_2_02:58]
Billings. We define billings as revenue recognized plus the change in deferred revenue from the beginning to the end of the period less any deferred revenue balances acquired from business combination(s) during the period. We consider billings to be a useful metric for management and investors because billings drive deferred revenue, which is an important indicator of the health and visibility of our business, and has historically represented a majority of the quarterly revenue that we recognize. There are a number of limitations related to the use of billings versus revenue calculated in accordance with GAAP. First, billings include amounts that have not yet been recognized as revenue. Second, we may calculate billings in a manner that is different from peer companies that report similar financial measures. Management compensates for these limitations by providing specific information regarding GAAP revenue and evaluating billings together with revenues calculated in accordance with GAAP.

[0001262039-15-000005:8k_2_02:59]
Free cash flow. We define free cash flow as net cash provided by operating activities minus capital expenditures. We consider free cash flow to be a liquidity measure that provides useful information to management and investors about the amount of cash generated by the business that, after the acquisition of property and equipment, can be used for strategic opportunities, including investing in our business, making strategic acquisitions, repurchasing outstanding common stock, and strengthening the balance sheet. Analysis of free cash flow facilitates management's comparisons of our operating results to competitors' operating results. A limitation of using free cash flow versus the GAAP measure of net cash provided by operating activities as a means for evaluating liquidity is that free cash flow does not represent the total

[0001262039-15-000005:8k_2_02:60]
increase or decrease in the cash, cash equivalents and investments balance for the period because it excludes cash used for capital expenditures and cash provided by or used for other investing and financing activities. Management compensates for this limitation by providing information about our capital expenditures and other investing and financing activities on the face of the cash flow statement and under the caption “Management's Discussion and Analysis of Financial Condition and Results of Operations - Liquidity and Capital Resources” in our most recent Quarterly Report on Form 10-Q and Annual Report on Form 10-K.

[0001262039-15-000005:8k_2_02:61]
Non-GAAP operating income and operating margin. Beginning the first quarter of fiscal 2014, we define non-GAAP operating income as operating income plus stock-based compensation expense, acquisition-related charges, including amortization, impairments and other purchase accounting adjustments, and, when applicable, any other significant non-recurring items in a given quarter. Prior period amounts have been adjusted to conform to the current period presentation. Non-GAAP operating margin is defined as non-GAAP operating income divided by revenue. We consider these non-GAAP financial measures to be useful metrics for management and investors because they exclude the effect of stock-based compensation expense, acquisition-related charges, including amortization, impairments and other purchase accounting adjustments, and, when applicable, any other significant non-recurring items  so that our management and investors can compare our recurring core business operating results over multiple periods. There are a number of limitations related to the use of non-GAAP operating income versus operating income calculated in accordance with GAAP. First non-GAAP operating income excludes stock-based compensation expense and acquisition-related charges and any other significant non-recurring items. Stock-based compensation expense has been and will continue to be, for the foreseeable future, a significant recurring expense in our business. Second, stock-based compensation expense is an important part of our employees' compensation and impacts their performance. Third, the components of the costs that we exclude in our calculation of non-GAAP operating income may differ from the components that other companies exclude when they report their non-GAAP results of operations. Management compensates for these limitations by providing specific information regarding the GAAP amounts excluded from non-GAAP operating income and evaluating non-GAAP operating income together with operating income calculated in accordance with GAAP.

[0001262039-15-000005:8k_2_02:62]
Non-GAAP net income and diluted net income per share. We define non-GAAP net income as net income plus stock-based compensation expense, acquisition-related charges, including amortization, impairments and other purchase accounting adjustments, and, when applicable, any other significant non-recurring items, adjusted for the impact of the tax adjustment, if any, required to achieve the effective tax rate on a non-GAAP basis, which could differ from the GAAP effective tax rate. We define non-GAAP diluted net income per share as non-GAAP net income divided by the weighted-average diluted shares outstanding. We consider these non-GAAP financial measures to be useful metrics for management and investors for the same reasons that we use non-GAAP operating income and non-GAAP operating margin. However, in order to provide a complete picture of our recurring core business operating results, we include in non-GAAP net income and non-GAAP diluted net income per share, the tax adjustment required to achieve the effective tax rate on a non-GAAP basis, which could differ from the GAAP tax rate. We believe the effective tax rates we used are reasonable estimates of normalized tax rates for our current and prior fiscal years under our global operating structure. Our estimated tax rate on non-GAAP income is determined annually and may be adjusted during the year to take into account events or trends that we believe materially impact the estimated annual rate, including, but not limited to, significant changes resulting from tax legislation, material changes in the geographic mix of revenues and expenses and other significant events.  The same limitations described above regarding our use of non-GAAP operating income and non-GAAP operating margin apply to our use of non-GAAP net income and non-GAAP diluted net income per share. We compensate for these limitations by providing

[0001262039-15-000005:8k_2_02:63]
specific information regarding the GAAP amounts excluded from non-GAAP net income and non-GAAP diluted net income per share and evaluating non-GAAP net income and non-GAAP diluted net income per share together with net income and diluted net income per share calculated in accordance with GAAP.

[0001262039-15-000005:8k_2_02:64]
Changes to non-GAAP financial measures.  Beginning the first quarter of 2014, we will no longer adjust our GAAP results for insignificant non-recurring items. As a result, insignificant patent sale, license or settlement income amounts are no longer being excluded from our non-GAAP financial measures. All prior amounts reported in our earnings release have been adjusted to conform to the current period presentation.

[0001262039-15-000005:8k_2_02:65]
FORTINET, INC.

[0001262039-15-000005:8k_2_02:66]
CONSOLIDATED BALANCE SHEETS

[0001262039-15-000005:8k_2_02:67]
(Unaudited, in thousands)

[0001262039-15-000005:8k_2_02:68]
|  | December 31, 2014 |  | December 31, 2013 |
| ASSETS |  |  |  |
| CURRENT ASSETS: |  |  |  |
| Cash and cash equivalents | $ | 283,254 |  |  | $ | 115,873 |  |
| Short-term investments | 436,766 |  |  | 375,497 |  |
| Accounts receivable—Net | 184,741 |  |  | 130,471 |  |
| Inventory | 69,477 |  |  | 48,672 |  |
| Deferred tax assets | 41,484 |  |  | 50,980 |  |
| Prepaid expenses and other current assets | 31,143 |  |  | 14,053 |  |
| Total current assets | 1,046,865 |  |  | 735,546 |  |
| LONG-TERM INVESTMENTS | 271,724 |  |  | 351,675 |  |
| PROPERTY AND EQUIPMENT—Net | 58,919 |  |  | 36,652 |  |
| DEFERRED TAX ASSETS | 31,080 |  |  | 30,058 |  |
| GOODWILL | 2,824 |  |  | 2,872 |  |
| OTHER INTANGIBLE ASSETS—Net | 2,832 |  |  | 6,841 |  |
| OTHER ASSETS | 10,530 |  |  | 4,820 |  |
| TOTAL ASSETS | $ | 1,424,774 |  |  | $ | 1,168,464 |  |
| LIABILITIES AND STOCKHOLDERS' EQUITY |  |  |  |  |
| CURRENT LIABILITIES: |  |  |  |  |
| Accounts payable | $ | 49,947 |  |  | $ | 35,599 |  |
| Accrued liabilities | 29,016 |  |  | 27,380 |  |
| Accrued payroll and compensation | 45,875 |  |  | 34,997 |  |
| Income taxes payable | 2,689 |  |  | 21,421 |  |
| Deferred revenue | 368,929 |  |  | 293,664 |  |
| Total current liabilities | 496,456 |  |  | 413,061 |  |
| DEFERRED REVENUE | 189,828 |  |  | 138,964 |  |
| INCOME TAXES PAYABLE | 45,139 |  |  | 30,208 |  |
| OTHER LIABILITIES | 17,385 |  |  | 471 |  |
| Total liabilities | 748,808 |  |  | 582,704 |  |
| STOCKHOLDERS' EQUITY: |  |  |  |  |
| Common stock | 166 |  |  | 161 |  |
| Additional paid-in capital | 562,504 |  |  | 462,644 |  |
| Accumulated other comprehensive (loss) income | (349 | ) |  | 1,092 |  |
| Retained earnings | 113,645 |  |  | 121,863 |  |
| Total stockholders’ equity | 675,966 |  |  | 585,760 |  |
| TOTAL LIABILITIES AND STOCKHOLDERS’ EQUITY | $ | 1,424,774 |  |  | $ | 1,168,464 |  |

[0001262039-15-000005:8k_2_02:69]
FORTINET, INC.

[0001262039-15-000005:8k_2_02:70]
CONSOLIDATED STATEMENTS OF OPERATIONS

[0001262039-15-000005:8k_2_02:71]
(Unaudited, in thousands, except per share amounts)

[0001262039-15-000005:8k_2_02:72]
|  | Three Months Ended |  | Year Ended |
|  | December 31, 2014 |  | December 31, 2013 |  | December 31, 2014 |  | December 31, 2013 |
| REVENUE: |  |  |  |  |  |  |  |
| Product | $ | 110,678 |  |  | $ | 83,884 |  |  | $ | 360,558 |  |  | $ | 278,046 |  |
| Services and other | 113,291 |  |  | 93,466 |  |  | 409,806 |  |  | 337,251 |  |
| Total revenue | 223,969 |  |  | 177,350 |  |  | 770,364 |  |  | 615,297 |  |
| COST OF REVENUE: |  |  |  |  |  |  |  |
| Product 1 | 46,070 |  |  | 37,579 |  |  | 151,300 |  |  | 114,611 |  |
| Services and other 1 | 19,554 |  |  | 16,298 |  |  | 79,709 |  |  | 66,032 |  |
| Total cost of revenue | 65,624 |  |  | 53,877 |  |  | 231,009 |  |  | 180,643 |  |
| GROSS PROFIT: |  |  |  |  |  |  |  |
| Product | 64,608 |  |  | 46,305 |  |  | 209,258 |  |  | 163,435 |  |
| Services and other | 93,737 |  |  | 77,168 |  |  | 330,097 |  |  | 271,219 |  |
| Total gross profit | 158,345 |  |  | 123,473 |  |  | 539,355 |  |  | 434,654 |  |
| OPERATING EXPENSES: |  |  |  |  |  |  |  |
| Research and development 1 | 33,097 |  |  | 27,747 |  |  | 122,880 |  |  | 102,660 |  |
| Sales and marketing 1 | 93,228 |  |  | 62,331 |  |  | 315,804 |  |  | 224,991 |  |
| General and administrative 1 | 12,104 |  |  | 8,752 |  |  | 41,347 |  |  | 34,913 |  |
| Total operating expenses | 138,429 |  |  | 98,830 |  |  | 480,031 |  |  | 362,564 |  |
| OPERATING INCOME | 19,916 |  |  | 24,643 |  |  | 59,324 |  |  | 72,090 |  |
| INTEREST INCOME | 1,402 |  |  | 1,318 |  |  | 5,393 |  |  | 5,306 |  |
| OTHER EXPENSE—Net | (1,200 | ) |  | (419 | ) |  | (3,168 | ) |  | (1,455 | ) |
| INCOME BEFORE INCOME TAXES | 20,118 |  |  | 25,542 |  |  | 61,549 |  |  | 75,941 |  |
| PROVISION FOR INCOME TAXES | 13,305 |  |  | 13,526 |  |  | 36,206 |  |  | 31,668 |  |
| NET INCOME | $ | 6,813 |  |  | $ | 12,016 |  |  | $ | 25,343 |  |  | $ | 44,273 |  |
| Net income per share: |  |  |  |  |  |  |  |
| Basic | $ | 0.04 |  |  | $ | 0.07 |  |  | $ | 0.15 |  |  | $ | 0.27 |  |
| Diluted | $ | 0.04 |  |  | $ | 0.07 |  |  | $ | 0.15 |  |  | $ | 0.26 |  |
| Weighted-average shares outstanding: |  |  |  |  |  |  |  |
| Basic | 165,439 |  |  | 163,281 |  |  | 163,831 |  |  | 162,435 |  |
| Diluted | 170,927 |  |  | 168,873 |  |  | 169,289 |  |  | 168,183 |  |
| 1 Includes stock-based compensation expense as follows: |  |  |  |  |  |  |  |
| Cost of product revenue | $ | 132 |  |  | $ | 106 |  |  | $ | 483 |  |  | $ | 383 |  |
| Cost of services and other revenue | 1,612 |  |  | 1,298 |  |  | 5,826 |  |  | 4,841 |  |
| Research and development | 4,706 |  |  | 3,666 |  |  | 17,264 |  |  | 13,271 |  |
| Sales and marketing | 7,854 |  |  | 5,599 |  |  | 26,744 |  |  | 19,526 |  |
| General and administrative | 2,377 |  |  | 2,018 |  |  | 8,677 |  |  | 6,450 |  |
|  | $ | 16,681 |  |  | $ | 12,687 |  |  | $ | 58,994 |  |  | $ | 44,471 |  |

[0001262039-15-000005:8k_2_02:73]
FORTINET, INC.

[0001262039-15-000005:8k_2_02:74]
CONSOLIDATED STATEMENTS OF COMPREHENSIVE INCOME

[0001262039-15-000005:8k_2_02:75]
(Unaudited, in thousands)

[0001262039-15-000005:8k_2_02:76]
|  | Three Months Ended |  | Year Ended |
|  | December 31, 2014 |  | December 31, 2013 |  | December 31, 2014 |  | December 31, 2013 |
| Net income | $ | 6,813 |  |  | $ | 12,016 |  |  | $ | 25,343 |  |  | $ | 44,273 |  |
| Other comprehensive loss, net of taxes: |  |  |  |  |  |  |  |
| Foreign currency translation losses | — |  |  | (716 | ) |  | (333 | ) |  | (1,617 | ) |
| Unrealized (losses) gains on investments | (715 | ) |  | 239 |  |  | (1,708 | ) |  | (587 | ) |
| Tax benefit (provision) related to items of other comprehensive income or loss | 252 |  |  | (84 | ) |  | 600 |  |  | 205 |  |
| Other comprehensive loss, net of taxes | (463 | ) |  | (561 | ) |  | (1,441 | ) |  | (1,999 | ) |
| Comprehensive income | $ | 6,350 |  |  | $ | 11,455 |  |  | $ | 23,902 |  |  | $ | 42,274 |  |

[0001262039-15-000005:8k_2_02:77]
FORTINET, INC.

[0001262039-15-000005:8k_2_02:78]
CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001262039-15-000005:8k_2_02:79]
(Unaudited, in thousands)

[0001262039-15-000005:8k_2_02:80]
|  | Three Months Ended |  | Year Ended |
|  | December 31, 2014 |  | December 31, 2013 |  | December 31, 2014 |  | December 31, 2013 |
| CASH FLOWS FROM OPERATING ACTIVITIES: |  |  |  |  |  |  |  |
| Net income | $ | 6,813 |  |  | $ | 12,016 |  |  | $ | 25,343 |  |  | $ | 44,273 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |
| Depreciation and amortization | 5,509 |  |  | 4,112 |  |  | 22,028 |  |  | 15,623 |  |
| Amortization of investment premiums | 2,023 |  |  | 2,734 |  |  | 8,703 |  |  | 11,634 |  |
| Stock-based compensation | 16,681 |  |  | 12,125 |  |  | 58,994 |  |  | 43,909 |  |
| Excess tax benefit from stock-based compensation | 4,325 |  |  | (470 | ) |  | — |  |  | (2,974 | ) |
| Other non-cash items—net | 339 |  |  | 441 |  |  | 4,140 |  |  | 961 |  |
| Changes in operating assets and liabilities: |  |  |  |  |  |  |  |
| Accounts receivable—Net | (69,028 | ) |  | (22,669 | ) |  | (55,888 | ) |  | (22,080 | ) |
| Inventory | (21,364 | ) |  | (3,749 | ) |  | (32,459 | ) |  | (35,093 | ) |
| Deferred tax assets | 21,258 |  |  | (3,944 | ) |  | 9,072 |  |  | (18,750 | ) |
| Prepaid expenses and other current assets | (13,219 | ) |  | (1,111 | ) |  | (16,000 | ) |  | (907 | ) |
| Other assets | (1,143 | ) |  | 350 |  |  | (1,302 | ) |  | 1,243 |  |
| Accounts payable | 14,227 |  |  | (569 | ) |  | 18,033 |  |  | 10,485 |  |
| Accrued liabilities | 4,302 |  |  | (28 | ) |  | 7,120 |  |  | 3,602 |  |
| Other liabilities | (32 | ) |  | (949 | ) |  | 14,318 |  |  | (1,948 | ) |
| Accrued payroll and compensation | 5,184 |  |  | 4,613 |  |  | 10,835 |  |  | 6,013 |  |
| Deferred revenue | 59,410 |  |  | 32,446 |  |  | 127,416 |  |  | 68,871 |  |
| Income taxes payable | 79 |  |  | 11,320 |  |  | (3,771 | ) |  | 22,522 |  |
| Net cash provided by operating activities | 35,364 |  |  | 46,668 |  |  | 196,582 |  |  | 147,384 |  |
| CASH FLOWS FROM INVESTING ACTIVITIES: |  |  |  |  |  |  |  |
| Purchases of investments | (108,276 | ) |  | (133,654 | ) |  | (497,084 | ) |  | (552,778 | ) |
| Sales of investments | 14,473 |  |  | 32,409 |  |  | 41,755 |  |  | 57,897 |  |
| Maturities of investments | 86,356 |  |  | 65,807 |  |  | 458,193 |  |  | 369,659 |  |
| Purchases of property and equipment | (5,395 | ) |  | (7,148 | ) |  | (32,197 | ) |  | (13,877 | ) |
| Payments made in connection with business acquisitions—net of cash acquired | — |  |  | — |  |  | (17 | ) |  | (7,635 | ) |
| Net cash used in investing activities | (12,842 | ) |  | (42,586 | ) |  | (29,350 | ) |  | (146,734 | ) |
| CASH FLOWS FROM FINANCING ACTIVITIES: |  |  |  |  |  |  |  |
| Proceeds from issuance of common stock | 14,795 |  |  | 1,114 |  |  | 55,324 |  |  | 25,584 |  |
| Taxes paid related to net share settlement of equity awards | (2,092 | ) |  | (486 | ) |  | (10,598 | ) |  | (1,452 | ) |
| Excess tax benefit from stock-based compensation | (4,325 | ) |  | 470 |  |  | — |  |  | 2,974 |  |
| Repurchase and retirement of common stock | (5,742 | ) |  | (33,529 | ) |  | (43,977 | ) |  | (33,529 | ) |
| Net cash provided by (used in) financing activities | 2,636 |  |  | (32,431 | ) |  | 749 |  |  | (6,423 | ) |
| EFFECT OF EXCHANGE RATES ON CASH AND CASH EQUIVALENTS | — |  |  | (324 | ) |  | (600 | ) |  | (1,329 | ) |
| NET INCREASE (DECREASE) IN CASH AND CASH EQUIVALENTS | 25,158 |  |  | (28,673 | ) |  | 167,381 |  |  | (7,102 | ) |
| CASH AND CASH EQUIVALENTS—Beginning of period | 258,096 |  |  | 144,546 |  |  | 115,873 |  |  | 122,975 |  |
| CASH AND CASH EQUIVALENTS—End of period | $ | 283,254 |  |  | $ | 115,873 |  |  | $ | 283,254 |  |  | $ | 115,873 |  |

[0001262039-15-000005:8k_2_02:81]
Reconciliations of non-GAAP results of operations measures to the nearest comparable GAAP measures

[0001262039-15-000005:8k_2_02:82]
(Unaudited, in thousands)

[0001262039-15-000005:8k_2_02:83]
Reconciliation of GAAP revenue to billings

[0001262039-15-000005:8k_2_02:84]
|  | Three Months Ended |  | Year Ended |
|  | December 31, 2014 |  | December 31, 2013 |  | December 31, 2014 |  | December 31, 2013 |
| Total revenue | $ | 223,969 |  |  | $ | 177,350 |  |  | $ | 770,364 |  |  | $ | 615,297 |  |
| Add increase in deferred revenue | 58,745 |  |  | 32,455 |  |  | 126,129 |  |  | 69,443 |  |
| Less deferred revenue balance acquired in business combination | — |  |  | — |  |  | — |  |  | (550 | ) |
| Total billings (Non-GAAP) | $ | 282,714 |  |  | $ | 209,805 |  |  | $ | 896,493 |  |  | $ | 684,190 |  |

[0001262039-15-000005:8k_2_02:85]
Reconciliation of net cash provided by operating activities to free cash flow

[0001262039-15-000005:8k_2_02:86]
|  | Three Months Ended |  | Year Ended |
|  | December 31, 2014 |  | December 31, 2013 |  | December 31, 2014 |  | December 31, 2013 |
| Net cash provided by operating activities | $ | 35,364 |  |  | $ | 46,668 |  |  | $ | 196,582 |  |  | $ | 147,384 |  |
| Less purchases of property and equipment | (5,395 | ) |  | (7,148 | ) |  | (32,197 | ) |  | (13,877 | ) |
| Free cash flow (Non-GAAP) | $ | 29,969 |  |  | $ | 39,520 |  |  | $ | 164,385 |  |  | $ | 133,507 |  |

[0001262039-15-000005:8k_2_02:87]
Reconciliation of non-GAAP results of operations to the nearest comparable GAAP measures

[0001262039-15-000005:8k_2_02:88]
(Unaudited, in thousands, except per share amounts)

[0001262039-15-000005:8k_2_02:89]
Reconciliation of GAAP to Non-GAAP operating income, operating margin, net income and diluted net income per share

[0001262039-15-000005:8k_2_02:90]
|  | Three Months Ended December 31, 2014 |  | Three Months Ended December 31, 2013 |
|  | GAAP Results |  | Adjustments |  | Non-GAAP Results |  | GAAP Results |  | Adjustments |  | Non-GAAP Results |
| Operating income | $ | 19,917 |  |  | $ | 16,925 |  | (a) | $ | 36,842 |  |  | $ | 24,643 |  |  | $ | 13,664 |  | (b) | $ | 38,307 |  |
| Operating margin | 9 | % |  |  |  | 16 | % |  | 14 | % |  |  |  | 22 | % |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation expense |  |  | 16,681 |  |  |  |  |  |  | 12,687 |  |  |  |
| Amortization expense of certain intangible assets |  |  | 244 |  |  |  |  |  |  | 508 |  |  |  |
| Impairment charges of certain intangible assets |  |  | — |  |  |  |  |  |  | 469 |  |  |  |
| Tax adjustment |  |  | 340 |  | (c) |  |  |  |  | 588 |  | (c) |  |
| Net income | $ | 6,813 |  |  | $ | 17,265 |  |  | $ | 24,078 |  |  | $ | 12,016 |  |  | $ | 14,252 |  |  | $ | 26,268 |  |
| Diluted net income per share | $ | 0.04 |  |  |  |  | $ | 0.14 |  |  | $ | 0.07 |  |  |  |  | $ | 0.16 |  |
| Shares used in diluted net income per share calculations | 170,927 |  |  |  |  | 170,927 |  |  | 168,873 |  |  |  |  | 168,873 |  |

[0001262039-15-000005:8k_2_02:91]
(a) To exclude $16.7 million of stock-based compensation expense and $0.2 million of amortization expense of certain intangible assets in the three months ended December 31, 2014.

[0001262039-15-000005:8k_2_02:92]
(b) To exclude $12.7 million of stock-based compensation expense, $0.5 million of amortization expense of certain intangible assets, and $0.5 million of impairment charges of certain intangible assets in the three months ended December 31, 2013.

[0001262039-15-000005:8k_2_02:93]
(c)  Non-GAAP financial information is adjusted to achieve an overall 35 percent and 33 percent effective tax rate on a non-GAAP basis, which differs from the GAAP effective tax rate, in fiscal 2014 and 2013, respectively.

[0001262039-15-000005:8k_2_02:94]
|  | Year Ended December 31, 2014 |  | Year Ended December 31, 2013 |
|  | GAAP Results |  | Adjustments |  | Non-GAAP Results |  | GAAP Results |  | Adjustments |  | Non-GAAP Results |
| Operating income | $ | 59,325 |  |  | $ | 62,805 |  | (a) | $ | 122,130 |  |  | $ | 72,090 |  |  | $ | 46,491 |  | (b) | $ | 118,581 |  |
| Operating margin | 8 | % |  |  |  | 16 | % |  | 12 | % |  |  |  | 19 | % |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation expense |  |  | 58,994 |  |  |  |  |  |  | 44,471 |  |  |  |
| Amortization expense of certain intangible assets |  |  | 1,407 |  |  |  |  |  |  | 1,551 |  |  |  |
| Impairment charges of certain intangible assets |  |  | 2,404 |  |  |  |  |  |  | 469 |  |  |  |
| Tax adjustment |  |  | (7,318 | ) | (c) |  |  |  |  | (8,735 | ) | (c) |  |
| Net income | $ | 25,343 |  |  | $ | 55,487 |  |  | $ | 80,830 |  |  | $ | 44,273 |  |  | $ | 37,756 |  |  | $ | 82,029 |  |
| Diluted net income per share | $ | 0.15 |  |  |  |  | $ | 0.48 |  |  | $ | 0.26 |  |  |  |  | $ | 0.49 |  |
| Shares used in diluted net income per share calculations | 169,289 |  |  |  |  | 169,289 |  |  | 168,183 |  |  |  |  | 168,183 |  |

[0001262039-15-000005:8k_2_02:95]
(a) To exclude $59.0 million of stock-based compensation expense, $1.4 million of amortization expense of certain intangible assets, and $2.4 million of impairment charges of certain intangible assets in fiscal 2014.

[0001262039-15-000005:8k_2_02:96]
(b) To exclude $44.5 million of stock-based compensation expense, $1.6 million of amortization expense of certain intangible assets, and $0.5 million of impairment charges of certain intangible assets in 2013.

[0001262039-15-000005:8k_2_02:97]
(c)  Non-GAAP financial information is adjusted to achieve an overall 35 percent and 33 percent effective tax rate on a non-GAAP basis, which differs from the GAAP effective tax rate, in fiscal 2014 and 2013, respectively.
