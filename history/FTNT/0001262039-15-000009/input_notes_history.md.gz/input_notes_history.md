# FTNT note change history — 0001262039-14-000033 → 0001262039-14-000039


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2014-11-06):
[0001262039-14-000039:note_history:1]
The following table summarizes our future principal contractual obligations as of September 30, 2014 (in thousands):
  (was, 2014-08-05, similarity 0.9493):
[0001262039-14-000033:note_history:1]
The following table summarizes our future principal contractual obligations as of June 30, 2014 (in thousands):

- changed (2014-11-06):
[0001262039-14-000039:note_history:2]
|  | Total |  | 2014 (remainder) |  | 2015 |  | 2016 |  | 2017 |  | 2018 |  | Thereafter |
| Operating lease commitments | $ | 39,575 |  |  | $ | 2,495 |  |  | $ | 9,411 |  |  | $ | 7,590 |  |  | $ | 6,649 |  |  | $ | 5,467 |  |  | $ | 7,963 |  |
| Less: Sublease rental income | 642 |  |  | 193 |  |  | 449 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Operating lease commitments—net | 38,933 |  |  | 2,302 |  |  | 8,962 |  |  | 7,590 |  |  | 6,649 |  |  | 5,467 |  |  | 7,963 |  |
| Purchase commitments | 76,355 |  |  | 53,006 |  |  | 23,349 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Other contractual commitments | 24,176 |  |  | 19,530 |  |  | 3,592 |  |  | 813 |  |  | 241 |  |  | — |  |  | — |  |
| Total | $ | 139,464 |  |  | $ | 74,838 |  |  | $ | 35,903 |  |  | $ | 8,403 |  |  | $ | 6,890 |  |  | $ | 5,467 |  |  | $ | 7,963 |  |
  (was, 2014-08-05, similarity 0.9984):
[0001262039-14-000033:note_history:2]
|  | Total |  | 2014 (remainder) |  | 2015 |  | 2016 |  | 2017 |  | 2018 |  | Thereafter |
| Operating lease commitments | $ | 34,431 |  |  | $ | 4,905 |  |  | $ | 7,814 |  |  | $ | 6,120 |  |  | $ | 5,190 |  |  | $ | 3,966 |  |  | $ | 6,436 |  |
| Less: Sublease rental income | 876 |  |  | 404 |  |  | 472 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Operating lease commitments—net | 33,555 |  |  | 4,501 |  |  | 7,342 |  |  | 6,120 |  |  | 5,190 |  |  | 3,966 |  |  | 6,436 |  |
| Purchase commitments | 46,379 |  |  | 46,379 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Other contractual commitments | 15,987 |  |  | 12,131 |  |  | 2,717 |  |  | 743 |  |  | 396 |  |  | — |  |  | — |  |
| Total | $ | 95,921 |  |  | $ | 63,011 |  |  | $ | 10,059 |  |  | $ | 6,863 |  |  | $ | 5,586 |  |  | $ | 3,966 |  |  | $ | 6,436 |  |

- changed (2014-11-06):
[0001262039-14-000039:note_history:3]
Operating Leases—We lease certain facilities under various non-cancelable operating leases, which expire through 2024. The terms of certain operating leases provide for renewal options. Rent expense is recognized using the straight-line method over the term of the lease. Rent expense was $2.6 million and $2.4 million during the three months ended September 30, 2014 and September 30, 2013, respectively. Rent expense was $7.7 million and $7.1 million during the nine months ended September 30, 2014 and September 30, 2013, respectively.
  (was, 2014-08-05, similarity 0.6806):
[0001262039-14-000033:note_history:3]
Operating Leases—We lease certain facilities under various non-cancelable operating leases, which expire through 2020. The terms of certain operating leases provide for renewal options. Rent expense is recognized using the straight-line method over the term of the lease. Rent expense was $2.4 million during the three months ended June 30, 2014 and June 30, 2013. Rent expense was $5.1 million and $4.7 million during the six months ended June 30, 2014 and June 30, 2013, respectively.

- changed (2014-11-06):
[0001262039-14-000039:note_history:4]
Purchase Commitments and Other Contractual Commitments—In order to reduce manufacturing lead times and plan for adequate component supply, we may issue purchase orders to some of our independent contract manufacturers which may not be cancelable. As of September 30, 2014, we had $76.4 million of open purchase orders with our independent contract manufacturers that may not be cancelable.
  (was, 2014-08-05, similarity 0.6877):
[0001262039-14-000033:note_history:4]
Purchase Commitments and Other Contractual Commitments—Our independent contract manufacturers procure components and build our products based on our forecasts. These forecasts are based on estimates of future demand for our products, which are in turn based on historical trends and an analysis from our sales and marketing organizations, adjusted for overall market conditions. In order to reduce manufacturing lead times and plan for adequate component supply, we may issue purchase orders to some of our independent contract manufacturers which may not be cancelable. As of June 30, 2014, we had $46.4 million of open purchase orders with our independent contract manufacturers that may not be cancelable.

- changed (2014-11-06):
[0001262039-14-000039:note_history:5]
In addition to commitments with contract manufacturers, we have open purchase orders and contractual obligations in the ordinary course of business for which we have not received goods or services. As of September 30, 2014, we had $24.2 million in other purchase commitments.
  (was, 2014-08-05, similarity 0.9753):
[0001262039-14-000033:note_history:5]
In addition to commitments with contract manufacturers, we have open purchase orders and contractual obligations in the ordinary course of business for which we have not received goods or services. As of June 30, 2014, we had $16.0 million in other purchase commitments.

- changed (2014-11-06):
[0001262039-14-000039:note_history:6]
|  | Nine Months Ended |
|  | September 30, 2014 |  | September 30, 2013 |
| Accrued warranty balance—beginning of the period | $ | 3,037 |  |  | $ | 2,309 |  |
| Warranty costs incurred | (2,597 | ) |  | (2,670 | ) |
| Provision for warranty for the period | 3,786 |  |  | 3,134 |  |
| Adjustment related to pre-existing warranties | (540 | ) |  | 274 |  |
| Accrued warranty balance—end of the period | $ | 3,686 |  |  | $ | 3,047 |  |
  (was, 2014-08-05, similarity 0.9312):
[0001262039-14-000033:note_history:6]
|  | Six Months Ended |
|  | June 30, 2014 |  | June 30, 2013 |
| Accrued warranty balance—beginning of the period | $ | 3,037 |  |  | $ | 2,309 |  |
| Warranty costs incurred | (1,728 | ) |  | (1,744 | ) |
| Provision for warranty for the period | 2,560 |  |  | 2,204 |  |
| Adjustment related to pre-existing warranties | (415 | ) |  | 208 |  |
| Accrued warranty balance—end of the period | $ | 3,454 |  |  | $ | 2,977 |  |

- changed (2014-11-06):
[0001262039-14-000039:note_history:7]
Litigation—We are involved in disputes, litigation, and other legal actions. For lawsuits where we are the defendant, we are in the process of defending these litigation matters, and while there can be no assurances and the outcome of these matters is currently not determinable, we currently believe that there are no existing claims or proceedings that are likely to have a material adverse effect on our financial position. There are many uncertainties associated with any litigation and these actions or other third-party claims against us may cause us to incur costly litigation or substantial settlement charges. In addition, the resolution of any intellectual property litigation may require us to make royalty payments, which could adversely affect our gross margins in future periods. If any of those events were to occur, our business, financial condition, results of operations, and cash flows could be adversely affected. The actual liability in any such matters may be materially different from our estimates, if any, which could result in the need to adjust the liability and record additional expenses. We have not recorded any accrual for loss contingencies associated with such legal proceedings; determined that an unfavorable outcome is probable or reasonably possible; or determined that the amount or range of any possible loss is reasonably estimable.
  (was, 2014-08-05, similarity 0.9967):
[0001262039-14-000033:note_history:7]
Litigation—We are involved in disputes, litigation, and other legal actions. For lawsuits where we are the defendant, we are in the process of defending these litigation matters, and while there can be no assurances and the outcome of these matters is currently not determinable, we currently believe that there are no existing claims or proceedings that are likely to have a material adverse effect on our financial position. There are many uncertainties associated with any litigation and these actions or other third-party claims against us may cause us to incur costly litigation or substantial settlement charges. In addition, the resolution of any intellectual property litigation may require us to make royalty payments, which could adversely affect our gross margins in future periods. If any of those events were to occur, our business, financial condition, results of operations, and cash flows could be adversely affected. The actual liability in any such matters may be materially different from our estimates, if any, which could result in the need to adjust the liability and record additional expenses. We have not recorded any material accrual for loss contingencies associated with such legal proceedings; determined that an unfavorable outcome is probable or reasonably possible; or determined that the amount or range of any possible loss is reasonably estimable.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2014-11-06):
[0001262039-14-000039:note_history:8]
Basis of Presentation and Preparation—The unaudited condensed consolidated financial statements of Fortinet, Inc. and its wholly owned subsidiaries (collectively, “we,” “us,” or “our”) have been prepared in accordance with generally accepted accounting principles (“GAAP”) in the United States (“U.S.”) for interim financial information as well as the instructions to Form 10-Q pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (“SEC”). Accordingly, they do not include all of the information and footnotes required by GAAP for complete financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the fiscal year ended December 31, 2013, contained in our Annual Report on Form 10-K (“Form 10-K”) filed with the SEC on March 3, 2014. In the opinion of management, all adjustments, which includes normal recurring adjustments, considered necessary for a fair presentation have been included. All intercompany balances, transactions and cash flows have been eliminated. The results of operations for the three and nine months ended September 30, 2014 are not necessarily indicative of the operating results for the full year or for any future periods. The condensed consolidated balance sheets as of December 31, 2013 are derived from the audited consolidated financial statements for the year ended December 31, 2013.
  (was, 2014-08-05, similarity 0.7996):
[0001262039-14-000033:note_history:8]
Basis of Presentation and Preparation—The unaudited condensed consolidated financial statements of Fortinet, Inc. and its wholly owned subsidiaries (collectively, “we,” “us,” or “our”) have been prepared in accordance with generally accepted accounting principles (“GAAP”) in the United States (“U.S.”) for interim financial information as well as the instructions to Form 10-Q pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (“SEC”). Accordingly, they do not include all of the information and footnotes required by GAAP for complete financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the fiscal year ended December 31, 2013, contained in our Annual Report on Form 10-K (“Form 10-K”) filed with the SEC on March 3, 2014. In the opinion of management, all adjustments, which includes normal recurring adjustments, considered necessary for a fair presentation have been included. All intercompany balances, transactions and cash flows have been eliminated. The results of operations for the three and six months ended June 30, 2014 are not necessarily indicative of the operating results for any subsequent quarter, for the full year or for any future periods. The condensed consolidated balance sheets as of December 31, 2013 are derived from the audited consolidated financial statements for the year ended December 31, 2013.

- changed (2014-11-06):
[0001262039-14-000039:note_history:9]
There have been no material changes to our significant accounting policies as of and for the three and nine months ended September 30, 2014.  During the first quarter of fiscal 2014, we prospectively modified the expected term calculation used in accounting for stock-based compensation expense and the estimated useful lives of building improvements, and furniture and fixtures. During the third quarter of fiscal 2014, we reevaluated the functional currency selection for certain of our international subsidiaries and prospectively applied the U.S. dollar.
  (was, 2014-08-05, similarity 0.7536):
[0001262039-14-000033:note_history:9]
There have been no material changes to our significant accounting policies as of and for the three and six months ended June 30, 2014.  During the first quarter of fiscal 2014, we prospectively modified the expected term calculation used in accounting for stock-based compensation expense and the estimated useful lives of building improvements, and furniture and fixtures.

- changed (2014-11-06):
[0001262039-14-000039:note_history:10]
Stock-Based Compensation Expense—Beginning in the first quarter of fiscal 2014, we changed the methodology of calculating the expected term, which is one of the assumptions used in determining the fair value of our employee stock options under the Black Scholes option pricing model. The expected term represents the period that our stock-based awards are estimated to be outstanding. We believe that we have sufficient historical experience since becoming a publicly-traded company for estimating the expected term of the stock option awards, and therefore, we calculated our expected term based on historical experience instead of using the simplified method.
  (was, 2014-08-05, similarity 0.7714):
[0001262039-14-000033:note_history:10]
Stock-Based Compensation Expense—Beginning in the first quarter of fiscal 2014, we changed the methodology of calculating the expected term, which is one of the assumptions used in determining the fair value of our employee stock options under the Black Scholes option pricing model. The expected term represents the period that our stock-based awards are estimated to be outstanding. We believe that we have sufficient historical experience for determining the expected term of the stock option award, and therefore, we calculated our expected term based on historical experience instead of using the simplified method.

- added (2014-11-06):
[0001262039-14-000039:note_history:11]
Currency Translation Adjustment—Prior to the third quarter of fiscal 2014, the assets and liabilities of our international subsidiaries were translated into U.S. dollars using the applicable exchange rates. The resulting foreign translation adjustments were included in the consolidated balance sheets as a component of accumulated other comprehensive income (loss) and in the consolidated statements of comprehensive income.

- added (2014-11-06):
[0001262039-14-000039:note_history:12]
We reevaluated the selected functional currency of our international subsidiaries due to the nature of our business operations. We recorded the cumulative impact of the reevaluation of the functional currency in the condensed consolidated statement of operations for the three months ended September 30, 2014.  The remeasurement of the assets and liabilities of all international subsidiaries will be recorded in the consolidated statement of operations prospectively. The impact of this reevaluation is not material for any of our previously issued financial statements.

- added (2014-11-06):
[0001262039-14-000039:note_history:13]
In March 2014, we moved into our new corporate headquarters and estimated the useful life of the building and related improvements to be 20 years. The useful life of furniture and fixtures placed in service in the new building is estimated to be 3 to 5 years.

- removed (2014-11-06):
[0001262039-14-000033:note_history:14]
Effective March 2014, we moved into our new corporate headquarters. The useful life of building improvements placed into service during the three months ended March 31, 2014, in association with our new corporate headquarters is estimated to be 20 years. The useful life of furniture and fixtures now ranges from 3 to 5 years as we placed new furniture and fixtures into service at the new corporate headquarters.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_prior_note, score: 0.0

- added (2014-11-06):
[0001262039-14-000039:note_history:15]
SUBSEQUENT EVENT

- added (2014-11-06):
[0001262039-14-000039:note_history:16]
On October 17, 2014, our Board extended the share repurchase authorization under the Program through December 31, 2015. As of October 17, 2014, $124.9 million remained authorized for future share repurchases under the Program.
