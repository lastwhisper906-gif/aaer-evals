# FTNT notes — 0001262039-15-000009


## ftnt:CashandCashEquivalentsandAvailableforSaleInvestmentsPolicyTextBlock

[0001262039-15-000009:notes:1]
Cash, Cash Equivalents and Available-for-sale Investments—We consider all highly liquid investments, purchased with original maturities of three months or less, to be cash equivalents. Cash and cash equivalents consist of balances with banks and highly liquid investments in money market funds, commercial paper, and certificates of deposit and term deposits.

[0001262039-15-000009:notes:2]
We classify our investments as available-for-sale at the time of purchase since it is our intent that these investments are available for current operations. Investments with original maturities greater than three months that mature less than one year from the consolidated balance sheet date are classified as short-term investments. Investments with maturities greater than one year from the consolidated balance sheet date are classified as long-term investments.

[0001262039-15-000009:notes:3]
Investments are considered to be impaired when a decline in fair value is judged to be other-than-temporary. We consult with our investment managers and consider available quantitative and qualitative evidence in evaluating potential impairment of our investments on a quarterly basis. If the cost of an individual investment exceeds its fair value, we evaluate, among other factors, general market conditions, the duration and extent to which the fair value is less than cost, and our intent and ability to hold the investment. Once a decline in fair value is determined to be other-than-temporary, an impairment charge is recorded and a new cost basis in the investment is established.

[0001262039-15-000009:notes:4]
For debt securities in an unrealized loss position which is deemed to be other-than-temporary, the difference between the security’s then-current amortized cost basis and fair value is separated into (i) the amount of the impairment related to the credit loss (i.e., the credit loss component) and (ii) the amount of the impairment related to all other factors (i.e., the non-credit loss component). The credit loss component is recognized in earnings. The non-credit loss component is recognized in accumulated other comprehensive loss.


## ftnt:CertainSignificantRisksAndUncertaintiesPolicyTextBlock

[0001262039-15-000009:notes:5]
Certain Significant Risks and Uncertainties—We are subject to certain risks and uncertainties that could have a material adverse effect on our future financial position or results of operations, such as the following: changes in level of demand for our products and services, the timing and success of new product and service introductions by us or our competitors, price and sales competition and our ability to adapt to changing market conditions and dynamics such as changes in end-customer, distributor or reseller requirements or market needs, changes in expenses caused, for example, by fluctuations in foreign currency exchange rates, management of inventory, internal control over financial reporting, market acceptance of our new products and services, demand for products and services in general, seasonality, failure of our channel partners to perform or other disruption in our channel, the quality of our products and services and the market perception of our response to new viruses or security breaches, general economic conditions, challenges in doing business outside of the United States, changes in customer relationships, litigation, or claims against us based on intellectual property, patent, product regulatory or other factors, product obsolescence, and our ability to attract and retain qualified employees.

[0001262039-15-000009:notes:6]
We utilize suppliers and independent contract manufacturers for certain of our components and a third-party logistics company for distribution of certain of our products, which is located outside of United States. The inability of any of these parties to fulfill our supply and logistics requirements could negatively impact our future operating results.


## ftnt:ComprehensiveIncomeLossPolicyTextBlock

[0001262039-15-000009:notes:7]
Comprehensive Income—Comprehensive income includes certain changes in equity from non-owner sources that are excluded from net income, specifically, unrealized gains and losses on available-for-sale investments.


## ftnt:ConcentrationRiskPolicyTextBlock

[0001262039-15-000009:notes:8]
Concentration of Credit Risk—Financial instruments that subject us to concentrations of credit risk consist primarily of cash, cash equivalents, short-term and long-term investments, and accounts receivable. We maintain our cash, cash equivalents, and investments in fixed income securities with major financial institutions in order to limit the exposure of each investment. Deposits held with banks may exceed the amount of insurance provided on such deposits.

[0001262039-15-000009:notes:9]
Our accounts receivables are primarily derived from our channel partners in various geographical locations. We perform ongoing credit evaluations of our customers. We generally do not require collateral on accounts receivable and we maintain reserves for estimated potential credit losses.


## ftnt:IncomeTaxBenefitFromStockOptionPlansTableTextBlock

[0001262039-15-000009:notes:10]
Total income tax benefit associated with stock-based compensation that is recognized in the consolidated statements of operations is as follows (in thousands):

[0001262039-15-000009:notes:11]
|  | Year Ended December 31, |
|  | 2014 |  | 2013 |  | 2012 |
| Income tax benefit associated with stock-based compensation | $ | 11,086 |  |  | $ | 8,331 |  |  | $ | 5,870 |  |


## ftnt:PresentationAndPreparationOfConsolidatedFinancialStatementsPolicyTextBlock

[0001262039-15-000009:notes:12]
Basis of Presentation and Preparation—The consolidated financial statements of Fortinet and its wholly owned subsidiaries (collectively, the “Company,” “we,” “us” or “our”) have been prepared in accordance with generally accepted accounting principles in the United States (“GAAP”). All intercompany transactions and balances have been eliminated in consolidation.


## ftnt:ScheduleOfAmortizedCostsUnrealizedGainsAndLossesAndFairValueOfAvailableForSaleSecuritiesTableTextBlock

[0001262039-15-000009:notes:13]
The following table summarizes our investments (in thousands):

[0001262039-15-000009:notes:14]
|  | December 31, 2014 |
|  | AmortizedCost |  | UnrealizedGains |  | UnrealizedLosses |  | FairValue |
| Corporate debt securities | $ | 589,526 |  |  | $ | 365 |  |  | $ | (875 | ) |  | $ | 589,016 |  |
| Commercial paper | 51,156 |  |  | 3 |  |  | (4 | ) |  | 51,155 |  |
| Municipal bonds | 39,745 |  |  | 15 |  |  | (39 | ) |  | 39,721 |  |
| Certificates of deposit and term deposits (1) | 22,854 |  |  | — |  |  | — |  |  | 22,854 |  |
| U.S. government and agency securities | 5,749 |  |  | 1 |  |  | (6 | ) |  | 5,744 |  |
| Total available-for-sale securities | $ | 709,030 |  |  | $ | 384 |  |  | $ | (924 | ) |  | $ | 708,490 |  |
|  | December 31, 2013 |
|  | AmortizedCost |  | UnrealizedGains |  | UnrealizedLosses |  | FairValue |
| Corporate debt securities | $ | 603,185 |  |  | $ | 1,506 |  |  | $ | (374 | ) |  | $ | 604,317 |  |
| Commercial paper | 69,356 |  |  | 7 |  |  | — |  |  | 69,363 |  |
| Municipal bonds | 38,815 |  |  | 48 |  |  | (20 | ) |  | 38,843 |  |
| Certificates of deposit and term deposits (1) | 12,645 |  |  | 3 |  |  | — |  |  | 12,648 |  |
| U.S. government and agency securities | 2,000 |  |  | 1 |  |  | — |  |  | 2,001 |  |
| Total available-for-sale securities | $ | 726,001 |  |  | $ | 1,565 |  |  | $ | (394 | ) |  | $ | 727,172 |  |
| (1) The majority of our certificates of deposit and term deposits are foreign deposits. |


## ftnt:ScheduleOfShareBasedPaymentAwardStockOptionsValuationAssumptionsAndAllocationOfRecognizedPeriodCostsTableTextBlock

[0001262039-15-000009:notes:15]
The following table summarizes the weighted-average assumptions relating to our employee stock options:

[0001262039-15-000009:notes:16]
|  | Year Ended December 31, |
|  | 2014 |  | 2013 |  | 2012 |
| Expected term in years | 4.8 |  |  | 4.6 |  |  | 4.6 |  |
| Volatility | 41% – 45% |  |  | 45% – 48% |  |  | 46% – 52% |  |
| Risk-free interest rate | 1.6% – 1.7% |  |  | 1.2 | % |  | 0.7% – 0.9% |  |
| Dividend rate | — | % |  | — | % |  | — | % |


## ftnt:ScheduleOfSharesReservedForFutureIssuanceTableTextBlock

[0001262039-15-000009:notes:17]
The following table presents the common stock reserved for future issuance (in thousands):

[0001262039-15-000009:notes:18]
|  | December 31, 2014 |
| Outstanding stock options and RSUs | 16,993 |  |
| Reserved for future stock option, RSU and other equity award grants | 32,431 |  |
| Reserved for future ESPP issuances | 5,981 |  |
| Total common stock reserved for future issuances | 55,405 |  |


## ftnt:ScheduleofEmployeeServiceSharebasedCompensationAllocationofRecognizedPeriodCostsbyAwardTypeTableTextBlock

[0001262039-15-000009:notes:19]
The following table summarizes stock-based compensation expense by award type (in thousands):

[0001262039-15-000009:notes:20]
|  | Year Ended December 31, |
|  | 2014 |  | 2013 |  | 2012 |
| Stock options | $ | 17,555 |  |  | $ | 20,806 |  |  | $ | 24,506 |  |
| RSUs | 37,068 |  |  | 18,968 |  |  | 1,714 |  |
| ESPP | 4,371 |  |  | 4,697 |  |  | 4,470 |  |
| Total stock-based compensation expense | $ | 58,994 |  |  | $ | 44,471 |  |  | $ | 30,690 |  |


## ftnt:ScheduleofSharebasedCompensationSharesWithheldforTaxesTableTextBlock

[0001262039-15-000009:notes:21]
The following summarizes the number and value of the shares withheld for employee taxes (in thousands):

[0001262039-15-000009:notes:22]
|  | Year Ended December 31, |
|  | 2014 |  | 2013 |  | 2012 |
| Shares withheld for taxes | 461 |  |  | 70 |  |  | — |  |
| Amount withheld for taxes | $ | 10,598 |  |  | $ | 1,452 |  |  | $ | — |  |


## ftnt:ScheduleofSharebasedPaymentAwardEmployeeStockPurchasePlanAdditionalInformationTableTextBlock

[0001262039-15-000009:notes:23]
Additional information related to the ESPP is provided below (in thousands, except per share amounts):

[0001262039-15-000009:notes:24]
|  | Year Ended December 31, |
|  | 2014 |  | 2013 |  | 2012 |
| Weighted-average fair value per share granted | $ | 5.91 |  |  | $ | 6.11 |  |  | $ | 7.06 |  |
| Shares issued under the ESPP | 770 |  |  | 672 |  |  | 577 |  |
| Weighted-average price per share issued | $ | 18.17 |  |  | $ | 18.88 |  |  | $ | 18.90 |  |


## ftnt:ScheduleofSharebasedPaymentAwardEquityInstrumentsOtherthanOptionsValuationAssumptionsTableTextBlock

[0001262039-15-000009:notes:25]
The following table summarizes the weighted-average assumptions relating to our PSUs:

[0001262039-15-000009:notes:26]
|  | Year Ended December 31, |
|  | 2014 |  | 2013 |
| Expected term in years | 3.0 |  |  | 3.0 |  |
| Volatility | 46.3 | % |  | 50.1 | % |
| Risk-free interest rate | 0.9 | % |  | 0.7 | % |
| Dividend rate | — | % |  | — | % |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001262039-15-000009:notes:27]
BUSINESS COMBINATIONS

[0001262039-15-000009:notes:28]
Coyote Point Systems

[0001262039-15-000009:notes:29]
On March 21, 2013, we acquired all of the outstanding equity securities of Coyote, a provider of application delivery, load balancing and acceleration solutions, for $6.0 million in cash. The acquisition also included a contingent obligation for up to $5.5 million in future earn-out payments to former stockholders of Coyote, if specified future operational objectives, service conditions and financial results were met within two years of the acquisition date. As the future earn-out payments were contingent upon one of Coyote’s former stockholder’s employment during the earn-out period, the estimated fair value of these contingent obligations was recorded as compensation expense ratably over the earn-out periods. During fiscal 2014, we determined that the contingent earn-out payment thresholds will not be met due to decreases in the projected revenue of Coyote following the acquisition, and reversed the entire $1.9 million carrying amount of the previously recorded liability for contingent consideration.

[0001262039-15-000009:notes:30]
We accounted for this acquisition as a purchase of a business and, accordingly, the total purchase price was allocated to Coyote’s identifiable tangible and intangible assets acquired and liabilities assumed based on their estimated fair values as of the acquisition date.  The fair value assigned to the intangible assets acquired was determined using the income approach which discounts expected cash flows to present value using our estimates and assumptions.

[0001262039-15-000009:notes:31]
The following table summarizes the fair value of assets acquired and liabilities assumed (in thousands):

[0001262039-15-000009:notes:32]
| Cash and cash equivalents | $ | 206 |  |
| Other current assets | 501 |  |
| Finite-lived intangible assets | 2,800 |  |
| Indefinite-lived intangible assets | 2,600 |  |
| Goodwill | 2,824 |  |
| Other assets | 88 |  |
| Total assets acquired | 9,019 |  |
| Current liabilities | 1,030 |  |
| Long-term liabilities | 2,004 |  |
| Total liabilities assumed | 3,034 |  |
| Total purchase price | $ | 5,985 |  |

[0001262039-15-000009:notes:33]
Of the total acquired finite intangible assets, we allocated $2.3 million to developed technology, $0.5 million to customer relationships, and $2.6 million to in-process research and development (“IPR&D”) as of the acquisition date.  Developed technology and customer relationships are being amortized on a straight-line basis, each over an initial estimated useful life of six years, as cost of revenue and sales and marketing expense, respectively. During the three months ended September 30, 2013, we completed the development of technology associated with the IPR&D projects, and started amortizing this developed technology as Cost of product revenue ratably on a straight-line basis over an estimated useful life of five years. During fiscal 2014, we recorded an impairment charge of $2.4 million related to the finite-lived intangible assets as Cost of product revenue in the consolidated statements of operations.

[0001262039-15-000009:notes:34]
The goodwill of $2.8 million represents the premium we paid over the fair value of the net tangible liabilities assumed and identified intangible assets acquired, due primarily to acquire developed and in-process technology. None of the goodwill recognized as a result of the acquisition is deductible for income tax purposes. The financial results of this acquisition were considered immaterial for purposes of pro-forma financial disclosures.

[0001262039-15-000009:notes:35]
Other Fiscal 2013 Acquisition

[0001262039-15-000009:notes:36]
In September 2013, we acquired certain assets of Xtera Communications, Inc. (“Xtera”), including certain load balancing solutions and certain patents, for a total consideration of $1.8 million, of which $1.7 million was paid in cash on the acquisition date and $0.1 million in cash was contingent upon attainment of revenue milestones. In connection with this acquisition, we acquired net tangible assets of $0.2 million, intangible assets of $1.5 million, and recognized an estimated contingent obligation of $0.1 million payable upon attainment of revenue milestones.

[0001262039-15-000009:notes:37]
The results of operations of our fiscal 2013 acquisitions have been included in our consolidated statements of operations from their respective acquisition dates.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001262039-15-000009:notes:38]
COMMITMENTS AND CONTINGENCIES

[0001262039-15-000009:notes:39]
The following table summarizes our future principal contractual obligations as of December 31, 2014 (in thousands):

[0001262039-15-000009:notes:40]
|  | Total |  | 2015 |  | 2016 |  | 2017 |  | 2018 |  | 2019 |  | Thereafter |
| Operating lease commitments | $ | 42,624 |  |  | $ | 11,535 |  |  | $ | 9,265 |  |  | $ | 7,368 |  |  | $ | 6,732 |  |  | $ | 4,726 |  |  | $ | 2,998 |  |
| Less: Sublease rental income | 431 |  |  | 431 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Operating lease commitments—net | 42,193 |  |  | 11,104 |  |  | 9,265 |  |  | 7,368 |  |  | 6,732 |  |  | 4,726 |  |  | 2,998 |  |
| Inventory purchase commitments | 62,804 |  |  | 62,804 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Other contractual commitments | 21,006 |  |  | 18,169 |  |  | 1,861 |  |  | 976 |  |  | — |  |  | — |  |  | — |  |
| Total | $ | 126,003 |  |  | $ | 92,077 |  |  | $ | 11,126 |  |  | $ | 8,344 |  |  | $ | 6,732 |  |  | $ | 4,726 |  |  | $ | 2,998 |  |

[0001262039-15-000009:notes:41]
Operating Leases—We lease certain facilities under various non-cancelable operating leases, which expire through 2024. Certain leases require us to pay variable costs such as taxes, maintenance, and insurance. The terms of certain operating leases also provide for renewal options and escalation clauses. Rent expense was $10.6 million, $9.8 million and $8.7 million for fiscal 2014, fiscal 2013, and fiscal 2012, respectively. Rent expense is recognized using the straight-line method over the term of the lease.

[0001262039-15-000009:notes:42]
Contract Manufacturer and Other Commitments—Our independent contract manufacturers procure components and build our products based on our forecasts. These forecasts are based on estimates of future demand for our products, which are in turn based on historical trends and an analysis from our sales and marketing organizations, adjusted for overall market conditions. In order to reduce manufacturing lead times and plan for adequate component supply, we may issue purchase orders to some of our independent contract manufacturers which may not be cancelable. As of December 31, 2014, we had $62.8 million of open purchase orders with our independent contract manufacturers that may not be cancelable.

[0001262039-15-000009:notes:43]
In addition to commitments with contract manufacturers, we have open purchase orders and contractual obligations in the ordinary course of business for which we have not received goods or services. As of December 31, 2014, we had $21.0 million in other contractual commitments.

[0001262039-15-000009:notes:44]
Litigation—We are involved in disputes, litigation, and other legal actions. For lawsuits where we are the defendant, we are in the process of defending these litigation matters, and while there can be no assurances and the outcome of these matters is currently not determinable, we currently believe that there are no existing claims or proceedings that are likely to have a material adverse effect on our financial position. There are many uncertainties associated with any litigation and these actions or other third-party claims against us may cause us to incur costly litigation or substantial settlement charges. In addition, the resolution of any intellectual property litigation may require us to make royalty payments, which could adversely affect our gross margins in future periods. If any of those events were to occur, our business, financial condition, results of operations, and cash flows could be adversely affected. The actual liability in any such matters may be materially different from our estimates, if any, which could result in the need to adjust the liability and record additional expenses. We have not recorded any significant accrual for loss contingencies associated with such legal proceedings; determined that an unfavorable outcome is probable or reasonably possible; or determined that the amount or range of any possible loss is reasonably estimable.

[0001262039-15-000009:notes:45]
Indemnification—Under the indemnification provisions of our standard sales contracts, we agree to defend our customers against third-party claims asserting infringement of certain intellectual property rights, which may include patents, copyrights, trademarks, or trade secrets, and to pay judgments entered on such claims. Our exposure under these indemnification provisions is generally limited by the terms of our contracts to the total amount paid by our customer under the agreement. However, certain agreements include indemnification provisions beyond indemnification for third-party claims of intellectual property infringement and that could potentially expose us to losses in excess of the amount received under the agreement and in some instances to potential liability that is not contractually limited. To date, there have been no awards under such indemnification provisions.


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0001262039-15-000009:notes:46]
DEFINED CONTRIBUTION PLANS

[0001262039-15-000009:notes:47]
Our tax-deferred savings plan under our 401(k) Plan, permits participating employees to defer a portion of their pre-tax earnings. In Canada, we have a Group Registered Retirement Savings Plan program (the “RRSP”) which permits participants to make tax deductible contributions. Our board of directors approved 50% matching contributions on employee contributions up to 4% of each employee’s eligible earnings. Our matching contributions to the 401(k) Plans and RRSP for fiscal 2014, fiscal 2013, and fiscal 2012 were $2.5 million, $2.1 million, and $1.8 million, respectively.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001262039-15-000009:notes:48]
ACCUMULATED OTHER COMPREHENSIVE (LOSS) INCOME

[0001262039-15-000009:notes:49]
The following table summarizes the changes in accumulated balances of other comprehensive income for fiscal 2014 and fiscal 2013 (in thousands):

[0001262039-15-000009:notes:50]
|  | December 31, 2014 |
|  | Foreign Currency Translation Gains and Losses |  | Unrealized Gains and Losses on Investments |  | Tax benefit or provision related to items of other comprehensive income or loss |  | Total |
| Beginning balance | $ | 333 |  |  | $ | 1,168 |  |  | $ | (409 | ) |  | $ | 1,092 |  |
| Other comprehensive loss before reclassifications |  |  | (1,694 | ) |  | 595 |  |  | (1,099 | ) |
| Amounts reclassified from accumulated other comprehensive (loss) income | (333 | ) |  | (14 | ) |  | 5 |  |  | (342 | ) |
| Net current-period other comprehensive loss | (333 | ) |  | (1,708 | ) |  | 600 |  |  | (1,441 | ) |
| Ending balance | $ | — |  |  | $ | (540 | ) |  | $ | 191 |  |  | $ | (349 | ) |

[0001262039-15-000009:notes:51]
|  | December 31, 2013 |
|  | Foreign Currency Translation Gains and Losses |  | Unrealized Gains and Losses on Investments |  | Tax benefit or provision related to items of other comprehensive income or loss |  | Total |
| Beginning balance | $ | 1,950 |  |  | $ | 1,755 |  |  | $ | (614 | ) |  | $ | 3,091 |  |
| Other comprehensive loss before reclassifications | (1,617 | ) |  | (573 | ) |  | 200 |  |  | (1,990 | ) |
| Amounts reclassified from accumulated other comprehensive (loss) income | — |  |  | (14 | ) |  | 5 |  |  | (9 | ) |
| Net current-period other comprehensive loss | (1,617 | ) |  | (587 | ) |  | 205 |  |  | (1,999 | ) |
| Ending balance | $ | 333 |  |  | $ | 1,168 |  |  | $ | (409 | ) |  | $ | 1,092 |  |

[0001262039-15-000009:notes:52]
The following table provides details about the reclassification out of accumulated other comprehensive (loss) income for fiscal 2014 and fiscal 2013 (in thousands):

[0001262039-15-000009:notes:53]
| December 31, 2014 |
| Details about Accumulated Other Comprehensive Income Components |  | Amount Reclassified from Accumulated Other Comprehensive Income |  | Affected Line Item in the Statement Where Net Income is Presented |
| Foreign currency translation losses |  | $ | (333 | ) |  | Other expense—net |
| Unrealized gains on investments |  | $ | (14 | ) |  | Other expense—net |
| Tax provision related to items of other comprehensive income or loss |  | 5 |  |  | Provision for income taxes |
| Total reclassification for the period |  | $ | (342 | ) |  |  |

[0001262039-15-000009:notes:54]
| December 31, 2013 |
| Details about Accumulated Other Comprehensive Income Components |  | Amount Reclassified from Accumulated Other Comprehensive Income |  | Affected Line Item in the Statement Where Net Income is Presented |
| Unrealized gains on investments |  | $ | (14 | ) |  | Other expense—net |
| Tax provision related to items of other comprehensive income or loss |  | 5 |  |  | Provision for income taxes |
| Total reclassification for the period |  | $ | (9 | ) |  |  |


## us-gaap:CostMethodInvestmentsDescriptionTextBlock

[0001262039-15-000009:notes:55]
INVESTMENTS IN PRIVATELY-HELD COMPANIES

[0001262039-15-000009:notes:56]
In fiscal 2014, we invested a total of $4.4 million in the equity securities of two privately-held companies. In fiscal 2013, we invested a total of $2.0 million in the equity securities of a privately-held company. Each of these investments are accounted for as cost-basis investments, as we own less than 20% of the voting securities and do not have the ability to exercise significant influence over operating and financial policies of the respective entities. These investments are carried at historical cost and are recorded as Other assets on our consolidated balance sheet and would be measured at fair value if indicators of impairment exist.

[0001262039-15-000009:notes:57]
As of December 31, 2014, no events have occurred that would adversely affect the carrying value of these investments.


## us-gaap:DeferredRevenueByArrangementDisclosureTextBlock

[0001262039-15-000009:notes:58]
Deferred revenue consisted of the following (in thousands):

[0001262039-15-000009:notes:59]
|  | December 31, 2014 |  | December 31, 2013 |
| Product | $ | 4,642 |  |  | $ | 2,915 |  |
| Services and other | 554,115 |  |  | 429,713 |  |
| Total deferred revenue | $ | 558,757 |  |  | $ | 432,628 |  |
| Reported As: |  |  |  |
| Current | $ | 368,929 |  |  | $ | 293,664 |  |
| Non-current | 189,828 |  |  | 138,964 |  |
| Total deferred revenue | $ | 558,757 |  |  | $ | 432,628 |  |


## us-gaap:DeferredRevenueDisclosureTextBlock

[0001262039-15-000009:notes:60]
DEFERRED REVENUE


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001262039-15-000009:notes:61]
STOCKHOLDERS’ EQUITY

[0001262039-15-000009:notes:62]
Stock-Based Compensation Plans

[0001262039-15-000009:notes:63]
Our stock-based compensation plans include the 2000 Stock Plan (the “2000 Plan”), the 2008 Stock Plan (the “2008 Plan”), the 2009 Equity Incentive Plan (the “2009 Plan”), and the 2011 Employee Stock Purchase Plan (the “ESPP”).

[0001262039-15-000009:notes:64]
2000 Stock Plan—In 2000, we adopted the 2000 Plan, which includes both incentive and non-statutory stock options. Under the 2000 Plan, we may grant options to purchase up to 21.5 million shares of common stock to employees, directors and other service providers at prices not less than the fair market value at date of grant for incentive stock options and not less than 85% of fair market value for non-statutory options. Options granted to a person who, at the time of the grant, owns more than 10% of the voting power of all classes of stock shall be at no less than 110% of the fair market value and expire five years from the date of grant. All other options generally have a contractual term of 10 years. Options generally vest over four years.

[0001262039-15-000009:notes:65]
2008 Stock Plan—In 2008, our board of directors approved the 2008 Plan, which includes both incentive and non-statutory stock options. The maximum aggregate number of shares which may be subject to options and sold under the 2008 Plan is 5.0 million shares, plus any shares that, as of the date of stockholder approval of the 2008 Plan, have been reserved but not issued under the 2000 Plan or shares subject to stock options or similar awards granted under the 2000 Plan that expire or otherwise terminate without having been exercised in full or that are forfeited to or repurchased by us.

[0001262039-15-000009:notes:66]
Under the 2008 Plan, we may grant options to employees, directors and other service providers. In the case of an incentive stock option granted to an employee, who at the time of grant, owns stock representing more than 10% of the total combined voting power of all classes of stock, the exercise price shall be no less than 110% of the fair market value per share on the date of grant and expire five years from the date of grant, and options granted to any other employee, the per share exercise price shall be no less than 100% of the fair market value per share on the date of grant. In the case of a nonstatutory stock option and options granted to other service providers, the per share exercise price shall be no less than 100% of the fair market value per share on the date of grant.

[0001262039-15-000009:notes:67]
2009 Equity Incentive Plan—In 2009, our board of directors approved the 2009 Plan, which includes awards of stock options, stock appreciation rights, restricted stock, RSUs, and Performance Stock Units (“PSUs”). The maximum aggregate number of shares that may be issued under the 2009 Plan is 9.0 million shares, plus any shares subject to stock options or similar awards granted under the 2008 Plan and the 2000 Plan that expire or otherwise terminate without having been exercised in full and shares issued pursuant to awards granted under the 2008 Plan and the 2000 Plan that are forfeited to or repurchased by us, with the maximum number of shares to be added to the 2009 Plan pursuant to such terminations, forfeitures and repurchases not to exceed 21.0 million shares. The shares may be authorized, but unissued or reacquired common stock. The number of shares available for issuance under the 2009 Plan will be increased on the first day of each fiscal year beginning with fiscal 2011, in an amount equal to the lesser of (i) 7.0 million shares, (ii) five percent (5%) of the outstanding shares on the last day of the immediately preceding fiscal year, or (iii) such number of shares determined by our board of directors. Under the 2009 Plan, we may grant awards to employees, directors and other service providers. In the case of an incentive stock option granted to an employee who, at the time of the grant, owns stock representing more than 10% of the voting power of all classes of stock, the exercise price shall be no less than 110% of the fair market value per share on the date of grant and expire five years from the date of grant, and options granted to any other employee, the per share exercise price shall be no less than 100% of the fair market value per share on the date of grant. In the case of a non-statutory stock option and options granted to other service providers, the per share exercise price shall be no less than 100% of the fair market value per share on the date of grant. Options granted to individuals owning less than 10% of the total combined voting power of all classes of stock generally have a contractual term of seven years and options generally vest over four years.

[0001262039-15-000009:notes:68]
As of December 31, 2014, a total of 49.4 million shares were authorized and available for issuance under the 2000 Plan, 2008 Plan and 2009 Plan.

[0001262039-15-000009:notes:69]
2011 Employee Stock Purchase Plan—In June 2011, our stockholders approved the ESPP. The ESPP permits eligible employees to purchase common stock through regular, systematic payroll deductions, up to a maximum of 15% of employees’ compensation for each purchase period at purchase prices equal to 85% of the lesser of the fair market value of our common stock at the first trading date of the applicable offering period or the purchase date. As of December 31, 2014, 6.0 million shares were authorized and available for future issuance under the ESPP.

[0001262039-15-000009:notes:70]
Employee Stock Options

[0001262039-15-000009:notes:71]
In determining the fair value of our employee stock options, we use the Black-Scholes option pricing model, which employs the following assumptions.

[0001262039-15-000009:notes:72]
Valuation method—We estimate the fair value of stock options granted.

[0001262039-15-000009:notes:73]
Expected Term—The expected term represents the period that our stock-based awards are expected to be outstanding. Beginning in the first quarter of fiscal 2014, we changed the methodology of calculating the expected term. We believe that we have sufficient historical experience for determining the expected term of the stock option award, and therefore, we calculated our expected term based on historical experience instead of using the simplified method.

[0001262039-15-000009:notes:74]
Expected Volatility—The expected volatility of our common stock has been historically based on the weighted-average implied and historical volatility of our and our peer group. The peer group is comprised of comparable companies in the same industry sector. As we gained more historical volatility data, the weighting of our own data in the expected volatility calculation associated with options gradually increased to 100% by the fourth quarter of fiscal 2014.

[0001262039-15-000009:notes:75]
Fair Value of Common Stock—The fair value of our common stock is the closing sales price of the common stock (or the closing bid, if no sales were reported) on the effective on the date of grant.

[0001262039-15-000009:notes:76]
Risk-Free Interest Rate—We base the risk-free interest rate used in the Black-Scholes valuation model on the implied yield available on U.S. Treasury zero-coupon issues with an equivalent remaining term.

[0001262039-15-000009:notes:77]
Expected Dividend—The expected dividend weighted-average assumption is zero.

[0001262039-15-000009:notes:78]
The following table summarizes the stock option activity and related information for the periods presented below (in thousands, except exercise prices and contractual life):

[0001262039-15-000009:notes:79]
|  | Options Outstanding |
|  | Numberof Shares |  | Weighted-AverageExercisePrice |  | Weighted-AverageRemainingContractualLife (Years) |  | AggregateIntrinsicValue |
| Balance—December 31, 2011 | 21,389 |  |  | $ | 9.14 |  |  |  |  |  |
| Granted | 3,401 |  |  | 26.38 |  |  |  |  |  |
| Forfeited | (1,441 | ) |  | 19.31 |  |  |  |  |  |
| Exercised | (4,778 | ) |  | 5.69 |  |  |  |  |  |
| Balance—December 31, 2012 | 18,571 |  |  | 12.40 |  |  |  |  |  |
| Granted | 258 |  |  | 20.89 |  |  |  |  |  |
| Forfeited | (820 | ) |  | 22.14 |  |  |  |  |  |
| Exercised | (2,488 | ) |  | 5.18 |  |  |  |  |  |
| Balance—December 31, 2013 | 15,521 |  |  | 13.18 |  |  |  |  |  |  |
| Granted | 387 |  |  | 23.08 |  |  |  |  |  |
| Forfeited | (443 | ) |  | 24.21 |  |  |  |  |  |
| Exercised | (4,763 | ) |  | 8.91 |  |  |  |  |  |
| Balance—December 31, 2014 | 10,702 |  |  | $ | 14.98 |  |  |  |  |  |
| Options vested and expected to vest—December 31, 2014 | 10,668 |  |  | $ | 14.96 |  |  | 2.71 |  | $ | 167,477 |  |
| Options exercisable—December 31, 2014 | 9,125 |  |  | $ | 13.45 |  |  | 2.38 |  | $ | 157,027 |  |

[0001262039-15-000009:notes:80]
The aggregate intrinsic value represents the pre-tax difference between the exercise price of stock options and the quoted market price of our common stock on December 31, 2014, for all in-the-money options. As of December 31, 2014, total compensation expense related to unvested stock options granted to employees but not yet recognized was $17.6 million, net of estimated forfeitures. This expense is expected to be amortized on a straight-line basis over a weighted-average period of 1.5 years.

[0001262039-15-000009:notes:81]
Additional information related to our stock options is summarized below (in thousands, except per share amounts):

[0001262039-15-000009:notes:82]
|  | Year Ended December 31, |
|  | 2014 |  | 2013 |  | 2012 |
| Weighted-average fair value per share granted | $ | 8.90 |  |  | $ | 8.42 |  |  | $ | 11.13 |  |
| Intrinsic value of options exercised | 76,731 |  |  | 41,484 |  |  | 92,323 |  |
| Fair value of options vested | 17,098 |  |  | 26,411 |  |  | 25,350 |  |

[0001262039-15-000009:notes:83]
The following table summarizes information about outstanding and exercisable stock options as of December 31, 2014, as follows (in thousands, except exercise prices and contractual life):

[0001262039-15-000009:notes:84]
|  |  | Options Outstanding |  | Options Exercisable |
| Range of Exercise Prices |  | NumberOutstanding |  | Weighted-AverageRemainingContractualLife (Years) |  | Weighted-AverageExercisePrice |  | NumberExercisable |  | Weighted-AverageExercisePrice |
| $0.98–$1.20 |  | 646 |  |  | 1.17 |  | $ | 1.04 |  |  | 642 |  |  | $ | 1.04 |  |
| 3.74–4.65 |  | 2,844 |  |  | 0.80 |  | 3.75 |  |  | 2,844 |  |  | 3.75 |  |
| 5.50–6.25 |  | 83 |  |  | 1.82 |  | 5.66 |  |  | 83 |  |  | 5.66 |  |
| 8.43–8.99 |  | 1,050 |  |  | 2.19 |  | 8.53 |  |  | 1,049 |  |  | 8.53 |  |
| 15.28–19.94 |  | 177 |  |  | 3.52 |  | 16.33 |  |  | 143 |  |  | 15.52 |  |
| 20.13–24.92 |  | 3,884 |  |  | 3.75 |  | 21.32 |  |  | 2,988 |  |  | 21.10 |  |
| 26.49–26.70 |  | 2,018 |  |  | 4.18 |  | 26.69 |  |  | 1,376 |  |  | 26.70 |  |
|  |  | 10,702 |  |  |  |  |  |  | 9,125 |  |  |  |  |

[0001262039-15-000009:notes:85]
Restricted Stock Units

[0001262039-15-000009:notes:86]
The following table summarizes the activity and related information for RSUs for the periods presented below (in thousands, except per share amounts):

[0001262039-15-000009:notes:87]
|  | Restricted Stock Units Outstanding |
|  | Number of Shares |  | Weighted-Average Grant-Date-Fair Value per Share |
| Balance—December 31, 2011 | — |  |  | $ | — |  |
| Granted | 873 |  |  | 23.79 |  |
| Forfeited | (43 | ) |  | 24.76 |  |
| Vested | — |  |  | — |  |
| Balance—December 31, 2012 | 830 |  |  | 23.73 |  |
| Granted | 4,104 |  |  | 21.75 |  |
| Forfeited | (507 | ) |  | 21.48 |  |
| Vested | (228 | ) |  | 23.89 |  |
| Balance—December 31, 2013 | 4,199 |  |  | 22.00 |  |
| Granted | 4,047 |  |  | 23.13 |  |
| Forfeited | (472 | ) |  | 21.92 |  |
| Vested | (1,483 | ) |  | 22.23 |  |
| Balance—December 31, 2014 | 6,291 |  |  | $ | 22.93 |  |
| RSUs expected to vest—December 31, 2014 | 5,933 |  |  | $ | 22.90 |  |

[0001262039-15-000009:notes:88]
As of December 31, 2014, total compensation expense related to unvested RSUs that were granted to employees and non-employees under the 2009 Plan, but not yet recognized, was $136.4 million, net of estimated forfeitures. This expense is expected to be amortized on a straight-line basis over a weighted-average vesting period of 2.92 years.

[0001262039-15-000009:notes:89]
RSUs settle into shares of common stock upon vesting. Upon the vesting of the RSUs, we net-settle the RSUs and withhold a portion of the shares to satisfy minimum statutory employee withholding taxes. Total payment for the employees’ tax obligations to the taxing authorities is reflected as a financing activity within the consolidated statements of cash flows.

[0001262039-15-000009:notes:90]
Performance Stock Units

[0001262039-15-000009:notes:91]
During fiscal 2014, we granted PSUs to certain of our executive officers. Based on the achievement of the market-based vesting conditions during the performance period, the final settlement of the PSUs will range between 0% and 150% of the target shares underlying the PSUs based on a specified objective formula approved by our Compensation Committee. The PSUs entitle our executive officers to receive a number of shares of our common stock based on the performance of our stock price over a two- or three-year period as compared to the NASDAQ Composite index for the same periods.

[0001262039-15-000009:notes:92]
We granted 0.1 million PSUs during fiscal 2014 to our executive officers. The PSUs had a grant date fair value of $21.05 per share, and are included in the aforementioned activity for RSUs. We granted 0.2 million PSUs during fiscal 2013, of which 0.1 million shares were forfeited during fiscal 2013. The PSUs had a grant date fair value of $22.06 per share. No PSUs were granted in fiscal 2012.

[0001262039-15-000009:notes:93]
As of December 31, 2014, total compensation expense related to unvested PSUs that were granted to certain of our executive officers, but not yet recognized, was $3.2 million, net of estimated forfeitures. This expense is expected to be amortized on a straight-line basis over a weighted-average vesting period of 2.00 years.

[0001262039-15-000009:notes:94]
Shares Reserved for Future Issuances

[0001262039-15-000009:notes:95]
Employee Stock Purchase Plan

[0001262039-15-000009:notes:96]
In determining the fair value of our ESPP, we use the Black-Scholes option pricing model that employs the following weighted-average assumptions:

[0001262039-15-000009:notes:97]
|  | Year Ended December 31, |
|  | 2014 |  | 2013 |  | 2012 |
| Expected term in years | 0.5 |  |  | 0.5 |  |  | 0.5 |  |
| Volatility | 34.1 | % |  | 44.0 | % |  | 53.7 | % |
| Risk-free interest rate | 0.1 | % |  | 0.1 | % |  | 0.1 | % |
| Dividend rate | — | % |  | — | % |  | — | % |

[0001262039-15-000009:notes:98]
Stock-based Compensation Expense

[0001262039-15-000009:notes:99]
Stock-based compensation expense is included in costs and expenses as follows (in thousands):

[0001262039-15-000009:notes:100]
|  | Year Ended December 31, |
|  | 2014 |  | 2013 |  | 2012 |
| Cost of product revenue | $ | 483 |  |  | $ | 383 |  |  | $ | 333 |  |
| Cost of services and other revenue | 5,826 |  |  | 4,841 |  |  | 3,736 |  |
| Research and development | 17,264 |  |  | 13,271 |  |  | 9,226 |  |
| Sales and marketing | 26,744 |  |  | 19,526 |  |  | 12,793 |  |
| General and administrative | 8,677 |  |  | 6,450 |  |  | 4,602 |  |
| Total stock-based compensation expense | $ | 58,994 |  |  | $ | 44,471 |  |  | $ | 30,690 |  |

[0001262039-15-000009:notes:101]
Share Repurchase Program

[0001262039-15-000009:notes:102]
On December 6, 2013, our Board of Directors authorized a Share Repurchase Program (“the Program”) to repurchase up to $200.0 million of our outstanding common stock through December 31, 2014. Under the Program, share repurchases may be made by us from time to time in privately negotiated transactions or in open market transactions. The Program does not require us to purchase a minimum number of shares, and may be suspended, modified or discontinued at any time without prior notice.  On October 17, 2014, our board of directors extended the share repurchase authorization under the Program through December 31, 2015. In fiscal 2014, we repurchased 1.6 million shares of common stock under the Program in open market transactions for an aggregate purchase price of $38.6 million. As of December 31, 2014, $122.5 million remains available for future share repurchases under the Program.


## us-gaap:EarningsPerShareTextBlock

[0001262039-15-000009:notes:103]
NET INCOME PER SHARE

[0001262039-15-000009:notes:104]
Basic net income per share is computed by dividing net income by the weighted-average number of shares of common stock outstanding during the period. Diluted net income per share is computed by dividing net income by the weighted-average number of shares of common stock outstanding, plus the dilutive effects of stock options, RSUs, and ESPP. Dilutive shares of common stock are determined by applying the treasury stock method.

[0001262039-15-000009:notes:105]
A reconciliation of the numerator and denominator used in the calculation of basic and diluted net income per share is as follows (in thousands, except per share amounts):

[0001262039-15-000009:notes:106]
|  | Year Ended December 31, |
|  | 2014 |  | 2013 |  | 2012 |
| Numerator: |  |  |  |  |  |
| Net income | $ | 25,343 |  |  | $ | 44,273 |  |  | $ | 66,836 |  |
| Denominator: |  |  |  |  |  |
| Basic shares: |  |  |  |  |  |
| Weighted-average common stock outstanding-basic | 163,831 |  |  | 162,435 |  |  | 158,074 |  |
| Diluted shares: |  |  |  |  |  |
| Weighted-average common stock outstanding-basic | 163,831 |  |  | 162,435 |  |  | 158,074 |  |
| Effect of potentially dilutive securities: |  |  |  |  |  |
| Stock options | 4,583 |  |  | 5,685 |  |  | 8,214 |  |
| RSUs | 844 |  |  | 35 |  |  | — |  |
| ESPP | 31 |  |  | 28 |  |  | 41 |  |
| Weighted-average shares used to compute diluted net income per share | 169,289 |  |  | 168,183 |  |  | 166,329 |  |
| Net income per share: |  |  |  |  |  |
| Basic | $ | 0.15 |  |  | $ | 0.27 |  |  | $ | 0.42 |  |
| Diluted | $ | 0.15 |  |  | $ | 0.26 |  |  | $ | 0.40 |  |

[0001262039-15-000009:notes:107]
The following weighted-average shares of common stock were excluded from the computation of diluted net income per share for the periods presented, as their effect would have been antidilutive (in thousands):

[0001262039-15-000009:notes:108]
|  | Year Ended December 31, |
|  | 2014 |  | 2013 |  | 2012 |
| Stock options | 3,469 |  |  | 7,397 |  |  | 7,183 |  |
| RSUs | 768 |  |  | 2,774 |  |  | 291 |  |
| ESPP | 99 |  |  | 419 |  |  | 321 |  |
|  | 4,336 |  |  | 10,590 |  |  | 7,795 |  |


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0001262039-15-000009:notes:109]
FINANCIAL INSTRUMENTS AND FAIR VALUE

[0001262039-15-000009:notes:110]
The following table shows the gross unrealized losses and the related fair values of our investments that have been in a continuous unrealized loss position (in thousands):

[0001262039-15-000009:notes:111]
|  | December 31, 2014 |
|  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
|  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |
| Corporate debt securities | $ | 317,011 |  |  | $ | (858 | ) |  | $ | 6,011 |  |  | $ | (17 | ) |  | $ | 323,022 |  |  | $ | (875 | ) |
| Commercial paper | 8,185 |  |  | (4 | ) |  | — |  |  | — |  |  | 8,185 |  |  | (4 | ) |
| Municipal bonds | 26,684 |  |  | (39 | ) |  | — |  |  | — |  |  | 26,684 |  |  | (39 | ) |
| U.S. government and agency securities | 4,745 |  |  | (6 | ) |  | — |  |  | — |  |  | 4,745 |  |  | (6 | ) |
| Total available-for-sale securities | $ | 356,625 |  |  | $ | (907 | ) |  | $ | 6,011 |  |  | $ | (17 | ) |  | $ | 362,636 |  |  | $ | (924 | ) |

[0001262039-15-000009:notes:112]
|  | December 31, 2013 |
|  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
|  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |
| Corporate debt securities | $ | 182,795 |  |  | $ | (374 | ) |  | $ | 500 |  |  | $ | — |  |  | $ | 183,295 |  |  | $ | (374 | ) |
| Commercial paper | 7,897 |  |  | — |  |  | — |  |  | — |  |  | 7,897 |  |  | — |  |
| Municipal bonds | 14,736 |  |  | (20 | ) |  | — |  |  | — |  |  | 14,736 |  |  | (20 | ) |
| Total available-for-sale securities | $ | 205,428 |  |  | $ | (394 | ) |  | $ | 500 |  |  | $ | — |  |  | $ | 205,928 |  |  | $ | (394 | ) |

[0001262039-15-000009:notes:113]
The contractual maturities of our investments are as follows (in thousands):

[0001262039-15-000009:notes:114]
|  | December 31, 2014 |  | December 31, 2013 |
| Due within one year | $ | 436,766 |  |  | $ | 375,497 |  |
| Due within one to three years | 271,724 |  |  | 351,675 |  |
| Total | $ | 708,490 |  |  | $ | 727,172 |  |

[0001262039-15-000009:notes:115]
Available-for-sale securities are reported at fair value, with unrealized gains and losses, net of tax, included as a separate component of stockholders’ equity and in total comprehensive income. Realized gains and losses on available-for-sale securities are included in Other expense—net in our consolidated statements of operations.

[0001262039-15-000009:notes:116]
The unrealized losses on our available-for-sale securities were caused by fluctuations in market value and interest rates as a result of the economic environment. As the decline in market value are attributable to changes in market conditions and not credit quality, and because we have concluded currently that we neither intend to sell nor is it more likely than not that we will be required to sell these investments prior to a recovery of par value, we do not consider these investments to be other-than temporarily impaired as of December 31, 2014.

[0001262039-15-000009:notes:117]
Realized gains and losses from the sale of available-for-sale securities were not significant in any period presented.

[0001262039-15-000009:notes:118]
Fair Value Accounting—We apply the following fair value hierarchy for disclosure of the inputs used to measure fair value. This hierarchy prioritizes the inputs into three broad levels as follows:

[0001262039-15-000009:notes:119]
Level 1—Inputs are unadjusted quoted prices in active markets for identical assets or liabilities.

[0001262039-15-000009:notes:120]
Level 2—Inputs are quoted prices for similar assets and liabilities in active markets or inputs that are observable for the assets or liabilities, either directly or indirectly through market corroboration, for substantially the full term of the financial instruments.

[0001262039-15-000009:notes:121]
Level 3—Unobservable inputs based on our own assumptions used to measure assets and liabilities at fair value. The inputs require significant management judgment or estimation.

[0001262039-15-000009:notes:122]
We measure the fair value of money market funds and certain U.S. government and agency securities using quoted prices in active markets for identical assets. The fair value of all other financial instruments was based on quoted prices for similar asserts in active markets, or model driven valuations using significant inputs derived from or corroborated by observable market data.

[0001262039-15-000009:notes:123]
We classify investments within Level 1 if quoted prices are available in active markets for identical securities.

[0001262039-15-000009:notes:124]
We classify items within Level 2 if the investments are valued using model driven valuations using observable inputs such as quoted market prices, benchmark yields, reported trades, broker/dealer quotes or alternative pricing sources with reasonable levels of price transparency. Investments are held by custodians who obtain investment prices from a third-party pricing provider that incorporates standard inputs in various asset price models.

[0001262039-15-000009:notes:125]
Fair Value of Financial Instruments

[0001262039-15-000009:notes:126]
Assets and Liabilities Measured at Fair Value on a Recurring Basis

[0001262039-15-000009:notes:127]
The following table presents the fair value of our financial assets and liabilities measured at fair value on a recurring basis as of December 31, 2014 and December 31, 2013 (in thousands):

[0001262039-15-000009:notes:128]
|  | December 31, 2014 |  |  |  | December 31, 2013 |  |  |
|  | AggregateFairValue |  | QuotedPrices inActiveMarkets ForIdenticalAssets |  | SignificantOtherObservableRemainingInputs |  | SignificantOtherUnobservableRemainingInputs |  | AggregateFairValue |  | QuotedPrices inActiveMarkets ForIdenticalAssets |  | SignificantOtherObservableRemainingInputs |  | SignificantOtherUnobservableRemainingInputs |
|  |  |  | (Level 1) |  | (Level 2) |  | (Level 3) |  |  |  | (Level 1) |  | (Level 2) |  | (Level 3) |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate debt securities | $ | 589,016 |  |  | $ | — |  |  | $ | 589,016 |  |  | $ | — |  |  | $ | 604,317 |  |  | $ | — |  |  | $ | 604,317 |  |  | $ | — |  |
| Commercial paper | 51,155 |  |  | — |  |  | 51,155 |  |  | — |  |  | 71,363 |  |  | — |  |  | 71,363 |  |  | — |  |
| Municipal bonds | 39,721 |  |  | — |  |  | 39,721 |  |  | — |  |  | 38,843 |  |  | — |  |  | 38,843 |  |  | — |  |
| Certificates of deposit and term deposits | 22,854 |  |  | — |  |  | 22,854 |  |  | — |  |  | 12,648 |  |  | — |  |  | 12,648 |  |  | — |  |
| Money market funds | 13,311 |  |  | 13,311 |  |  | — |  |  | — |  |  | 5,724 |  |  | 5,724 |  |  | — |  |  | — |  |
| U.S. government and agency securities | 5,744 |  |  | 1,998 |  |  | 3,746 |  |  | — |  |  | 2,001 |  |  | — |  |  | 2,001 |  |  | — |  |
| Total | $ | 721,801 |  |  | $ | 15,309 |  |  | $ | 706,492 |  |  | $ | — |  |  | $ | 734,896 |  |  | $ | 5,724 |  |  | $ | 729,172 |  |  | $ | — |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Contingent consideration | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1,850 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,850 |  |
| Total | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1,850 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,850 |  |
| Reported as: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents | $ | 13,311 |  |  |  |  |  |  |  |  | $ | 7,724 |  |  |  |  |  |  |  |
| Short-term investments | 436,766 |  |  |  |  |  |  |  |  | 375,497 |  |  |  |  |  |  |  |
| Long-term investments | 271,724 |  |  |  |  |  |  |  |  | 351,675 |  |  |  |  |  |  |  |
| Total | $ | 721,801 |  |  |  |  |  |  |  |  | $ | 734,896 |  |  |  |  |  |  |  |

[0001262039-15-000009:notes:129]
There were no transfers between Level 1 and Level 2 of the fair value hierarchy during the year ended December 31, 2014 and December 31, 2013.

[0001262039-15-000009:notes:130]
We classified the fair value of contingent consideration arising from the acquisition of Coyote Point Systems, Inc. (“Coyote”) (see Note 6), as a Level 3 liability since it is based on a probability-based income approach that includes significant unobservable inputs. Significant inputs used in the determination of fair value based on the probability-weighted income approach primarily include internal cash flow projections, percentage probability of occurrence and discount rates.

[0001262039-15-000009:notes:131]
The change in the fair value of our contingent consideration liability was as follows (in thousands):

[0001262039-15-000009:notes:132]
| As of December 31, 2013 | $1,850 |
| Less change in fair value of contingent consideration | (1,850) |
| As of December 31, 2014 | $— |

[0001262039-15-000009:notes:133]
Decreases in the projected revenues of Coyote following the acquisition resulted in reductions to the fair value of the contingent consideration and the changes are included in Research and development expense in the consolidated statements of operations.

[0001262039-15-000009:notes:134]
Assets and Liabilities Measured at Fair Value on a Nonrecurring Basis

[0001262039-15-000009:notes:135]
We measure certain assets, including Goodwill, Other intangible assets—net, and investments in privately-held companies at fair value on a nonrecurring basis when there are identifiable events or changes in circumstances that may have a significant adverse impact on the fair value of these assets.

[0001262039-15-000009:notes:136]
During fiscal 2014, a decrease in the projected cash flow of the other intangible assets acquired from Coyote resulted in an impairment charge of $2.4 million to adjust the total fair value of the other intangible assets acquired from Coyote to $2.0 million. The impairment charge is included within Cost of product revenue in the consolidated statements of operations.

[0001262039-15-000009:notes:137]
As of December 31, 2013, we did not have any assets or liabilities measured at fair value on a nonrecurring basis.


## us-gaap:ForeignCurrencyTransactionsAndTranslationsPolicyTextBlock

[0001262039-15-000009:notes:138]
Foreign Currency Translation and Transaction Gains and Losses—Prior to the third quarter of fiscal 2014, the assets and liabilities of our international subsidiaries were translated into U.S. dollars using the applicable exchange rates. The resulting foreign translation adjustments were included in the consolidated balance sheets as a component of accumulated other comprehensive income (loss) and in the consolidated statements of comprehensive income.

[0001262039-15-000009:notes:139]
In the third quarter of fiscal 2014, we reevaluated the selected functional currency of our international subsidiaries due to the nature of our business operations and recorded the cumulative impact of the reevaluation of the functional currency in the consolidated statement of operations. Subsequently, the remeasurement of the assets and liabilities of all international subsidiaries has been recorded in the consolidated statement of operations prospectively. The impact of this reevaluation is not material for our fiscal 2014 or any of our previously issued financial statements.

[0001262039-15-000009:notes:140]
As of December 31, 2014, the functional currency of our foreign subsidiaries is the U.S. dollar. Monetary assets and liabilities denominated in foreign currencies have been remeasured into U.S. dollars using the exchange rates in effect at the balance sheet dates. Foreign currency denominated income and expenses have been remeasured using the average exchange rates in effect during each period.


## us-gaap:ImpairmentOrDisposalOfLongLivedAssetsPolicyTextBlock

[0001262039-15-000009:notes:141]
Impairment of Long-Lived Assets—We evaluate events and changes in circumstances that could indicate carrying amounts of long-lived assets, including intangible assets, may not be recoverable. When such events or changes in circumstances occur, we assess the recoverability of long-lived assets by determining whether the carrying value of such assets will be recovered through undiscounted expected future cash flows. If the total of the future undiscounted cash flows is less than the carrying amount of those assets, we record an impairment charge in the period in which we make the determination. If such assets are considered to be impaired, the impairment to be recognized is measured by the amount by which the carrying amount of the assets exceeds the fair value of the assets.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001262039-15-000009:notes:142]
INCOME TAXES

[0001262039-15-000009:notes:143]
Income before income taxes consisted of the following (in thousands):

[0001262039-15-000009:notes:144]
|  | Year Ended December 31, |
|  | 2014 |  | 2013 |  | 2012 |
| Domestic | $ | 35,778 |  |  | $ | 83,076 |  |  | $ | 95,730 |  |
| Foreign | 25,771 |  |  | (7,135 | ) |  | 9,266 |  |
| Total income before income taxes | $ | 61,549 |  |  | $ | 75,941 |  |  | $ | 104,996 |  |

[0001262039-15-000009:notes:145]
The provision for income taxes consisted of the following (in thousands):

[0001262039-15-000009:notes:146]
|  | Year Ended December 31, |
|  | 2014 |  | 2013 |  | 2012 |
| Current: |  |  |  |  |  |
| Federal | $ | 17,717 |  |  | $ | 43,384 |  |  | $ | 43,765 |  |
| State | 1,110 |  |  | 2,490 |  |  | 1,992 |  |
| Foreign | 8,921 |  |  | 4,175 |  |  | 2,266 |  |
| Total current | $ | 27,748 |  |  | $ | 50,049 |  |  | $ | 48,023 |  |
| Deferred: |  |  |  |  |  |
| Federal | $ | 6,742 |  |  | $ | (17,149 | ) |  | $ | (9,677 | ) |
| State | (36 | ) |  | (1,232 | ) |  | (186 | ) |
| Foreign | 1,752 |  |  | — |  |  | — |  |
| Total deferred | 8,458 |  |  | (18,381 | ) |  | (9,863 | ) |
| Provision for income taxes | $ | 36,206 |  |  | $ | 31,668 |  |  | $ | 38,160 |  |

[0001262039-15-000009:notes:147]
The provision for income taxes differs from the amount computed by applying the statutory federal income tax rate as follows (in thousands):

[0001262039-15-000009:notes:148]
|  | Year Ended December 31, |
|  | 2014 |  | 2013 |  | 2012 |
| Tax at federal statutory tax rate | $ | 21,542 |  |  | $ | 26,579 |  |  | $ | 36,749 |  |
| Stock-based compensation expense | 7,367 |  |  | 4,571 |  |  | 1,570 |  |
| State taxes—net of federal benefit | 975 |  |  | 419 |  |  | 1,186 |  |
| Domestic production activities deduction | — |  |  | (3,256 | ) |  | (1,813 | ) |
| Foreign tax credit | (4,433 | ) |  | (2,853 | ) |  | (2,348 | ) |
| Research and development credit | (880 | ) |  | (1,650 | ) |  | (144 | ) |
| Foreign income taxed at different rates | (406 | ) |  | 2,927 |  |  | (1,626 | ) |
| Foreign withholding taxes | 9,085 |  |  | 6,622 |  |  | 2,185 |  |
| Other | 2,956 |  |  | (1,691 | ) |  | 2,401 |  |
| Total provision for income taxes | $ | 36,206 |  |  | $ | 31,668 |  |  | $ | 38,160 |  |

[0001262039-15-000009:notes:149]
Significant permanent differences arise from the portion of stock-based compensation expense that is not expected to generate a tax deduction, such as stock-based compensation expense on stock option grants to certain foreign employees, offset by the actual tax benefits in the current periods from disqualifying dispositions of shares held by our U.S. employees. For stock options exercised by our U.S. employees, we receive an income tax benefit calculated as the difference between the fair market value of the stock issued at the time of the exercise and the option price, tax effected. For fiscal 2014, income tax payable was not reduced by excess tax benefits from the exercise or vesting of stock-based awards, therefore we did not recognize a significant benefit in additional paid-in-capital. The income tax benefits for fiscal 2013 and fiscal 2012 associated with dispositions from employee stock transactions of $3.5 million, and $14.3 million, respectively, were recognized as additional paid-in capital because it reduced income taxes payable.

[0001262039-15-000009:notes:150]
As of December 31, 2014, we did not recognize federal and California deferred tax assets related to stock-based compensation excess tax benefits of $6.5 million and $3.3 million, respectively. Unrecognized excess tax benefits will be accounted for as a credit to additional paid-in capital when realized through a reduction in income taxes payable.

[0001262039-15-000009:notes:151]
The tax effects of temporary differences that give rise to significant portions of the deferred tax assets as of the years ended are presented below (in thousands):

[0001262039-15-000009:notes:152]
|  | December 31, 2014 |  | December 31, 2013 |
| Deferred tax assets: |  |  |  |
| Net operating loss carryforward | $ | 1,293 |  |  | $ | 2,183 |  |
| Deferred revenue | 31,545 |  |  | 47,341 |  |
| Nondeductible reserves and accruals | 20,904 |  |  | 16,055 |  |
| Depreciation and amortization | 193 |  |  | (465 | ) |
| General business credit carryforward | 2,155 |  |  | 439 |  |
| Stock-based compensation expense | 16,463 |  |  | 15,468 |  |
| Other | 11 |  |  | 17 |  |
| Total deferred tax assets | $ | 72,564 |  |  | $ | 81,038 |  |

[0001262039-15-000009:notes:153]
In assessing the realizability of deferred tax assets, we considered whether it is more likely than not that some portion or all of our deferred tax assets will be realized. This realization is dependent upon the generation of future taxable income during the periods in which those temporary differences become deductible. We concluded that it is more likely than not that we would be able to realize the benefits of our deferred tax assets in the future.

[0001262039-15-000009:notes:154]
As of December 31, 2014, we had $22.9 million in federal net operating loss carryforwards to offset future income that will not expire until 2034. We also had federal tax credits of $5.5 million available to carryback and claim federal tax refunds from prior year. As of December 31, 2014, we had $6.9 million in California net operating loss carryforwards to offset future income that will not expire until 2030. We also had state tax credit carryforwards of $5.2 million available to offset our future state taxes. The state credits carry forward indefinitely.

[0001262039-15-000009:notes:155]
Our policy with respect to undistributed foreign subsidiaries’ earnings is to consider those earnings to be indefinitely reinvested and, accordingly, no related provision of U.S. federal and state income taxes has been provided on such earnings. Upon distribution of those earnings in the form of dividends or otherwise, we would be subject to both U.S. income taxes (subject to an adjustment for foreign tax credits) and withholding taxes in the various foreign countries. As of December 31, 2014, we have not recorded U.S. income tax on $21.3 million of foreign earnings that are deemed to be permanently reinvested overseas.

[0001262039-15-000009:notes:156]
We operate under a tax incentive agreement in Singapore, which is effective through December 31, 2023, and may be extended if certain additional requirements are satisfied. The tax incentive agreement is conditional upon our meeting certain employment and investment thresholds. We did not realize any tax savings from the Singapore tax incentives in fiscal 2014 because of net tax losses generated in fiscal 2013 for that jurisdiction.

[0001262039-15-000009:notes:157]
As of December 31, 2014, we had $44.2 million of unrecognized tax benefits, of which, if recognized, $43.4 million would favorably affect our effective tax rate. Our policy is to include accrued interest and penalties related to uncertain tax benefits in income tax expense. As of December 31, 2014, 2013 and 2012, accrued interest and penalties were $1.7 million, $1.0 million, and $1.5 million, respectively.

[0001262039-15-000009:notes:158]
The aggregate changes in the balance of unrecognized tax benefits are as follows (in thousands):

[0001262039-15-000009:notes:159]
|  | Year Ended December 31, |
|  | 2014 |  | 2013 |  | 2012 |
| Unrecognized tax benefits, beginning of year | $ | 29,604 |  |  | $ | 27,808 |  |  | $ | 19,269 |  |
| Gross increases for tax positions related to the current year | 14,547 |  |  | 4,713 |  |  | 7,550 |  |
| Gross increases for tax positions related to the prior year | — |  |  | 405 |  |  | 1,479 |  |
| Gross decreases for tax positions related to the prior year | — |  |  | (3,322 | ) |  | (490 | ) |
| Unrecognized tax benefits, end of year | $ | 44,151 |  |  | $ | 29,604 |  |  | $ | 27,808 |  |

[0001262039-15-000009:notes:160]
As of December 31, 2014, 2013 and 2012, $45.1 million, $30.2 million, and $28.8 million, respectively, of the amounts reflected above were recorded as Income taxes payable—non-current in our consolidated balance sheet.

[0001262039-15-000009:notes:161]
As of December 31, 2014, there was no unrecognized tax benefits that we expect would change significantly over the next 12 months.

[0001262039-15-000009:notes:162]
We file income tax returns in the U.S. federal jurisdiction, and various U.S. state and foreign jurisdictions. The statute of limitations is open for years that generated state net operating loss carryforwards and after 2009 for state jurisdictions. Additionally, we have foreign net operating losses that have an indefinite life. Generally, we are no longer subject to non-U.S. income tax examinations by tax authorities for tax years prior to 2008.  We are no longer subject to examination by U.S federal income tax authorities for tax years prior to 2010.


## us-gaap:IncomeTaxPolicyTextBlock

[0001262039-15-000009:notes:163]
Income Taxes—We record income taxes using the asset and liability method, which requires the recognition of deferred tax assets and liabilities for the expected future tax consequences of events that have been recognized in our financial statements or tax returns. In estimating future tax consequences, generally all expected future events other than enactments or changes in the tax law or rates are considered. We assess the likelihood that some portion or all of our deferred tax assets will be recovered from future taxable income within the respective jurisdictions, and to the extent we believe that recovery does not meet the “more-likely-than-not” standard, based solely on its technical merits as of the reporting date, we establish a valuation allowance.

[0001262039-15-000009:notes:164]
We account for uncertain tax positions in accordance with GAAP, which defines the confidence level that a tax position must meet in order to be recognized in the financial statements. The tax effects of a position are recognized only if it is “more likely than not” to be sustained based solely on its technical merits as of the reporting date. We consider many factors when evaluating and estimating our tax positions and tax benefits, which may require periodic adjustments and which may not accurately anticipate actual outcomes.

[0001262039-15-000009:notes:165]
We operate in various tax jurisdictions and are subject to audit by various tax authorities. We provide for tax contingencies whenever it is deemed more likely than not that a tax asset has been impaired or a tax liability has been incurred for events such as tax claims or changes in tax laws. Tax contingencies are based upon their technical merits, relevant tax law and the specific facts and circumstances as of each reporting period. Changes in facts and circumstances could result in material changes to the amounts recorded for such tax contingencies.


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0001262039-15-000009:notes:166]
GOODWILL AND OTHER INTANGIBLE ASSETS—Net

[0001262039-15-000009:notes:167]
We recorded $2.8 million of goodwill from the acquisition of Coyote. There were no impairments to goodwill during fiscal 2014.

[0001262039-15-000009:notes:168]
During fiscal 2014, we reassessed the fair value and the remaining useful life of the developed technologies and customer relationships acquired from Coyote. Based on this reassessment, we recorded an impairment charge of $2.4 million to adjust the total fair value of the other intangible assets to $2.0 million. The impairment charge is included within Cost of product revenue in the consolidated statements of operations.

[0001262039-15-000009:notes:169]
The following tables present other intangible assets—net (in thousands):

[0001262039-15-000009:notes:170]
|  | December 31, 2014 |
|  | Weighted-Average Useful Life (in Years) |  | Gross |  | Accumulated Amortization |  | Net |
| Other intangible assets—net: |  |  |  |  |  |  |  |
| Developed technology | 3.6 |  | $ | 5,606 |  |  | $ | 3,128 |  |  | $ | 2,478 |  |
| Customer relationships | 6.0 |  | 500 |  |  | 146 |  |  | 354 |  |
| Total other intangible assets—net |  |  | $ | 6,106 |  |  | $ | 3,274 |  |  | $ | 2,832 |  |

[0001262039-15-000009:notes:171]
|  | December 31, 2013 |
|  | Weighted-Average Useful Life (in Years) |  | Gross |  | Accumulated Amortization |  | Net |
| Other intangible assets—net: |  |  |  |  |  |  |  |
| Developed technology | 4.6 |  | $ | 8,971 |  |  | $ | 2,568 |  |  | $ | 6,403 |  |
| Customer relationships | 6.0 |  | 500 |  |  | 62 |  |  | 438 |  |
| Total other intangible assets—net |  |  | $ | 9,471 |  |  | $ | 2,630 |  |  | $ | 6,841 |  |

[0001262039-15-000009:notes:172]
Amortization expense was $1.5 million, $1.7 million, and $1.0 million in fiscal 2014, fiscal 2013 and fiscal 2012, respectively. The following table summarizes estimated future amortization expense of Other intangible assets—net for future fiscal years (in thousands):

[0001262039-15-000009:notes:173]
|  | Amount |
| Fiscal Years: |  |
| 2015 | $ | 1,091 |  |
| 2016 | 785 |  |
| 2017 | 425 |  |
| 2018 | 425 |  |
| 2019 | 106 |  |
| Total | $ | 2,832 |  |


## us-gaap:InventoryDisclosureTextBlock

[0001262039-15-000009:notes:174]
INVENTORY

[0001262039-15-000009:notes:175]
Inventory consisted of the following (in thousands):

[0001262039-15-000009:notes:176]
|  | December 31, 2014 |  | December 31, 2013 |
| Raw materials | $ | 10,617 |  |  | $ | 8,355 |  |
| Finished goods | 58,860 |  |  | 40,317 |  |
| Inventory | $ | 69,477 |  |  | $ | 48,672 |  |

[0001262039-15-000009:notes:177]
Inventory includes finished goods held by distributors where revenue is recognized on a sell-through basis of $1.2 million and $0.9 million as of December 31, 2014 and 2013, respectively. Inventory also includes materials at contract manufacturers to be used in production of $4.8 million and $4.3 million as of December 31, 2014 and 2013, respectively.


## us-gaap:InventoryPolicyTextBlock

[0001262039-15-000009:notes:178]
Inventory—Inventory is recorded at the lower of cost (using the first-in, first-out method) or market, after we give appropriate consideration to obsolescence and inventory in excess of anticipated future demand. In assessing the ultimate recoverability of inventory, we are required to make estimates regarding future customer demand, the timing of new product introductions, economic trends and market conditions. If the actual product demand is significantly lower than forecasted, we could be required to record additional inventory write-downs, which could have an adverse impact on our gross margins and profitability.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001262039-15-000009:notes:179]
Recent Accounting Pronouncement

[0001262039-15-000009:notes:180]
In May 2014, the Financial Accounting Standards Board issued Accounting Standards Update No. 2014-09 (Topic 606) - Revenue from Contracts with Customers (“ASU 2014-09”) to create a single, joint revenue standard that is consistent across all industries and markets for companies that prepare their financial statements in accordance with GAAP. Under ASU 2014-09, an entity is required to recognize revenue upon the transfer of promised goods or services to customers in an amount that reflects the consideration the entity expects to be entitled to receive in exchange for those goods or services. ASU 2014-09 is effective for us beginning on January 1, 2017. We are currently evaluating the impact ASU 2014-09 will have on our consolidated financial statements.


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001262039-15-000009:notes:181]
PROPERTY AND EQUIPMENT—Net

[0001262039-15-000009:notes:182]
Property and equipment—net consisted of the following (in thousands):

[0001262039-15-000009:notes:183]
|  | December 31, 2014 |  | December 31, 2013 |
| Land | $ | 13,895 |  |  | $ | 13,895 |  |
| Building and building improvements | 20,166 |  |  | 610 |  |
| Evaluation units | 31,474 |  |  | 23,442 |  |
| Computer equipment and software | 31,821 |  |  | 22,442 |  |
| Furniture and fixtures | 5,096 |  |  | 1,697 |  |
| Construction-in-progress | 3,902 |  |  | 10,947 |  |
| Leasehold improvements | 7,998 |  |  | 5,417 |  |
| Total property and equipment | 114,352 |  |  | 78,450 |  |
| Less: accumulated depreciation | (55,433 | ) |  | (41,798 | ) |
| Property and equipment—net | $ | 58,919 |  |  | $ | 36,652 |  |

[0001262039-15-000009:notes:184]
In March 2014, we moved into our new corporate headquarters and estimated the useful life of the building and related improvements to be 20 years.

[0001262039-15-000009:notes:185]
Depreciation expense was $20.5 million, $13.9 million and $10.5 million in fiscal 2014, fiscal 2013 and fiscal 2012, respectively.


## us-gaap:PropertyPlantAndEquipmentPolicyTextBlock

[0001262039-15-000009:notes:186]
Property and Equipment—Property and equipment are stated at cost less accumulated depreciation. Depreciation is computed using the straight-line method over the estimated useful lives of the assets as follows:

[0001262039-15-000009:notes:187]
|  | Estimated Useful Lives |
| Building and building improvements | 20 years |
| Evaluation units | 1 year |
| Computer equipment and software | 1 - 2 years |
| Furniture and fixtures | 3 - 5 years |
| Leasehold improvements | Shorter of useful life or lease term |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001262039-15-000009:notes:188]
RELATED PARTY TRANSACTIONS

[0001262039-15-000009:notes:189]
The son of one member of our Board of Directors is a partner of an outside law firm that we utilize for certain complex litigation matters. Expenses for legal services provided by the law firm related to matters that arose subsequent to the member joining our Board of Directors were $1.7 million and $0.1 million in fiscal 2014 and fiscal 2013, respectively. There were no such legal services in fiscal 2012. Amounts due and payable to the law firm were $1.3 million and $0.3 million as of December 31, 2014 and December 31, 2013, respectively.


## us-gaap:RevenueRecognitionPolicyTextBlock

[0001262039-15-000009:notes:190]
Revenue Recognition—We derive the majority of our revenue from sales of our hardware, software, FortiGuard security subscription services and FortiCare technical support services, and other services through our channel partners and a direct sales force.

[0001262039-15-000009:notes:191]
Revenue is recognized when all of the following criteria have been met:

[0001262039-15-000009:notes:192]
| • | Persuasive evidence of an arrangement exists. Binding contracts or purchase orders are generally used to determine the existence of an arrangement. |

[0001262039-15-000009:notes:193]
| • | Delivery has occurred or services have been rendered. Delivery occurs when we fulfill an order and title and risk of loss has been transferred. Services revenue is deferred and recognized ratably over the contract service period, which is typically from one to three years and is generally recognized upon delivery or completion of service. |

[0001262039-15-000009:notes:194]
| • | Sales price is fixed or determinable. We assess whether the sales price is fixed or determinable based on the payment terms associated with the transaction and when the sales price is deemed final. |

[0001262039-15-000009:notes:195]
| • | Collectability is reasonably assured. We assess collectability based primarily on creditworthiness as determined by credit checks, analysis, and payment history. |

[0001262039-15-000009:notes:196]
We recognize product revenue for sales to distributors that have no general right of return and direct sales to end-customers upon shipment, based on general revenue recognition accounting guidance once all other revenue recognition criteria have been met. Certain distributors are granted stock rotation rights, limited rights of return, as well as rebates for sales of our products. The arrangement fee for this group of distributors is not typically fixed or determinable when products are shipped and revenue is therefore deferred and recognized upon sell-through. For sales that include end-customer acceptance criteria, revenue is recognized upon acceptance.

[0001262039-15-000009:notes:197]
Substantially all of our products have been sold in combination with services, which consist of security subscriptions and technical support services. Security services provide access to our antivirus, intrusion prevention, web filtering, and anti-spam functionality. Support services include rights to unspecified software upgrades, maintenance releases and patches, telephone and Internet access to technical support personnel, and hardware support.  We recognize revenue from these services ratably over the contractual service period.  Revenue related to subsequent renewals of these services are recognized over the term of the renewal agreement.

[0001262039-15-000009:notes:198]
We offer certain sales incentives to channel partners. We reduce revenue for estimates of sales returns and allowances and record reductions to revenue for rebates and estimated commitments related to price protection and other customer incentive programs.   Additionally, in limited circumstances, we may permit end-customers, distributors and resellers to return our products, subject to varying limitations, for a refund within a reasonably short period from the date of purchase. We estimate and record reserves for sales incentives and sales returns based on historical experience.

[0001262039-15-000009:notes:199]
Our sales arrangements typically contain multiple elements, such as hardware, subscription, technical support and other services. The majority of our hardware appliance products contain our operating system software that together function to deliver the essential functionality of the product. Our products and services generally qualify as separate units of accounting. We allocate revenue to each unit of accounting based on an estimated selling price using vendor-specific objective evidence (“VSOE”) of selling price, if it exists, or third-party evidence (“TPE”) of selling price. If neither VSOE nor TPE of selling price exist for a deliverable, we use our best estimate of selling price (“BESP”) for that deliverable. Revenue allocated to each element is then recognized when the basic revenue recognition criteria are met for each element.

[0001262039-15-000009:notes:200]
We determine VSOE of fair value for elements of an arrangement based on the historical pricing and discounting practices for those services when sold separately. In establishing VSOE, we require that a substantial majority of the selling prices for a service fall within a reasonably narrow pricing range, generally evidenced by a substantial majority of such historical stand-alone transactions falling within a reasonably narrow range as a percentage of list price. We are typically not able to determine TPE for our products or services. TPE is determined based on competitor prices for similar deliverables when sold separately, which is generally unavailable. For our hardware appliances, we use BESP as our selling price. For our support and other services, we generally use VSOE as our selling price estimate. When we are unable to establish a selling price using VSOE for our support and other services, we use BESP in our allocation of arrangement consideration. We determine BESP for a product or service by considering multiple historical factors including, but not limited to, cost of products, gross margin objectives, pricing practices, geographies, customer classes and distribution channels that fall within a reasonably narrow range as a percentage of list price.

[0001262039-15-000009:notes:201]
For multiple-element arrangements where software deliverables are included, revenue is allocated to the non-software deliverables and to the software deliverables as a group using the relative estimated selling prices of each of the deliverables in the arrangement based on the estimated selling price hierarchy. The amount allocated to the software deliverables is then allocated to each software deliverable using the residual method when VSOE of fair value exists. If evidence of VSOE of fair value of one or more undelivered elements does not exist, all software allocated revenue is deferred and recognized when delivery of those elements occurs or when fair value can be established. When the undelivered element for which we do not have VSOE of fair value is support, revenue for the entire arrangement is recognized ratably over the support period. The same residual method and VSOE of fair value principles apply for our multiple element arrangements that contain only software elements.

[0001262039-15-000009:notes:202]
Deferred Revenue—Deferred revenue consists of amounts that have been invoiced but that have not yet been recognized as revenue. This generally includes security subscription and technical support services which are invoiced upfront and delivered over twelve months or longer.


## us-gaap:ScheduleOfNotionalAmountsOfOutstandingDerivativePositionsTableTextBlock

[0001262039-15-000009:notes:203]
The notional amount of forward exchange contracts to hedge balance sheet accounts as of December 31, 2014 and 2013 were (in thousands):

[0001262039-15-000009:notes:204]
|  | Buy/Sell |  | Notional |
| Balance Sheet Contracts: |  |  |  |
| Currency—As of December 31, 2014 |  |  |  |
| CAD | Buy |  | $ | 6,879 |  |
| Currency—As of December 31, 2013 |  |  |  |
| CAD | Buy |  | $ | 21,867 |  |


## us-gaap:ScheduleOfProductWarrantyLiabilityTableTextBlock

[0001262039-15-000009:notes:205]
Accrued warranty activities are summarized as follows (in thousands):

[0001262039-15-000009:notes:206]
|  | Year Ended December 31, |
|  | 2014 |  | 2013 |  | 2012 |
| Accrued warranty balance—beginning of the period | $ | 3,037 |  |  | $ | 2,309 |  |  | $ | 2,582 |  |
| Warranty costs incurred | (3,653 | ) |  | (3,444 | ) |  | (2,669 | ) |
| Provision for warranty for the year, including warranty liabilities assumed in connection with an acquisition | 5,209 |  |  | 3,965 |  |  | 2,639 |  |
| Adjustment related to pre-existing warranties | (324 | ) |  | 207 |  |  | (243 | ) |
| Accrued warranty balance—end of the period | $ | 4,269 |  |  | $ | 3,037 |  |  | $ | 2,309 |  |


## us-gaap:ScheduleOfRevenuesFromExternalCustomersAndLongLivedAssetsByGeographicalAreasTableTextBlock

[0001262039-15-000009:notes:207]
The following tables set forth revenue and property and equipment by geographic region (in thousands):

[0001262039-15-000009:notes:208]
|  | Year Ended December 31, |
| Revenue | 2014 |  | 2013 |  | 2012 |
| Americas: |  |  |  |  |  |
| United States | $ | 200,294 |  |  | $ | 162,327 |  |  | $ | 145,369 |  |
| Other Americas | 124,365 |  |  | 90,459 |  |  | 71,687 |  |
| Total Americas | 324,659 |  |  | 252,786 |  |  | 217,056 |  |
| Europe, Middle East, and Africa (“EMEA”) | 270,537 |  |  | 208,979 |  |  | 184,175 |  |
| Asia Pacific and Japan (“APAC”) | 175,168 |  |  | 153,532 |  |  | 132,408 |  |
| Total revenue | $ | 770,364 |  |  | $ | 615,297 |  |  | $ | 533,639 |  |

[0001262039-15-000009:notes:209]
| Property and Equipment—net | December 31, 2014 |  | December 31, 2013 |
| Americas: |  |  |  |
| United States | $ | 46,116 |  |  | $ | 29,334 |  |
| Canada | 6,054 |  |  | 4,372 |  |
| Other Americas | 875 |  |  | 45 |  |
| Total Americas | 53,045 |  |  | 33,751 |  |
| EMEA | 3,256 |  |  | 1,273 |  |
| APAC | 2,618 |  |  | 1,628 |  |
| Total property and equipment—net | $ | 58,919 |  |  | $ | 36,652 |  |


## us-gaap:ScheduleOfValuationAndQualifyingAccountsDisclosureTextBlock

[0001262039-15-000009:notes:210]
SCHEDULE II—VALUATION AND QUALIFYING ACCOUNTS

[0001262039-15-000009:notes:211]
|  | Year Ended December 31, |
|  | 2014 |  | 2013 |  | 2012 |
|  | (in thousands) |
| Sales Returns Reserve: |  |  |  |  |  |
| Beginning balance | $ | 4,573 |  |  | $ | 2,267 |  |  | $ | 2,351 |  |
| Charged (credited) to costs and expenses, net of deductions | 1,269 |  |  | 2,306 |  |  | (84 | ) |
| Ending balance | $ | 5,842 |  |  | $ | 4,573 |  |  | $ | 2,267 |  |
| Allowance for Doubtful Accounts: |  |  |  |  |  |
| Beginning balance | $ | 32 |  |  | $ | 115 |  |  | $ | 336 |  |
| Charged (credited) to costs and expenses, net of write-offs | 330 |  |  | (83 | ) |  | (221 | ) |
| Ending balance | $ | 362 |  |  | $ | 32 |  |  | $ | 115 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001262039-15-000009:notes:212]
SEGMENT INFORMATION

[0001262039-15-000009:notes:213]
Operating segments are defined as components of an enterprise about which separate financial information is available that is evaluated regularly by the chief operating decision maker in deciding how to allocate resources and in assessing performance. Our chief operating decision maker is our chief executive officer. Our chief executive officer reviews financial information presented on a consolidated basis, accompanied by information about revenue by geographic region for purposes of allocating resources and evaluating financial performance. We have one business activity, and there are no segment managers who are held accountable for operations, operating results and plans for levels or components below the consolidated unit level. Accordingly, we have determined that we have one operating segment, and therefore, one reportable segment.

[0001262039-15-000009:notes:214]
Revenue by geographic region is based on the billing address of the customer. The following tables set forth revenue and property and equipment by geographic region (in thousands):


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001262039-15-000009:notes:215]
SUMMARY OF SIGNIFICANT ACCOUNTING POLICIES

[0001262039-15-000009:notes:216]
Business—Fortinet, Inc. (“Fortinet”) was incorporated in Delaware in November 2000 and is a leading provider of network security appliances to enterprises, service providers and government organizations worldwide. Fortinet’s solutions are designed to integrate multiple levels of security protection, including firewall, virtual private networking, application control, anti-malware, intrusion prevention, web filtering, vulnerability management, anti-spam, wireless controller, and WAN acceleration. Our security solutions are fast and secure and designed to provide broad, high-performance protection against dynamic security threats while simplifying the IT infrastructure of our end-customers worldwide.

[0001262039-15-000009:notes:217]
Use of Estimates—The preparation of consolidated financial statements in accordance with GAAP requires management to make estimates and assumptions that affect the amounts reported in the consolidated financial statements and accompanying notes. Such management estimates include implicit service periods for revenue recognition, litigation and settlement costs and other loss contingencies, sales returns reserve and allowance for doubtful accounts, inventory valuation, warranty reserve, goodwill and other long-lived assets, investments, stock-based compensation,  accounting for income taxes related to deferred tax asset balances and reserves, and accounting for business combinations. We base our estimates on historical experience and also on assumptions that we believe are reasonable. Actual results could differ from those estimates.

[0001262039-15-000009:notes:218]
As of December 31, 2014 and December 31, 2013, one distributor, Exclusive Networks Group accounted for 18% and 13% of total accounts receivable, respectively.

[0001262039-15-000009:notes:219]
During fiscal 2014, fiscal 2013 and fiscal 2012, one distributor, Exclusive Networks Group accounted for 15%, 12% and 11% of total revenue, respectively.

[0001262039-15-000009:notes:220]
Financial Instruments and Fair Value—We apply fair value accounting for all financial assets and liabilities and non-financial assets and liabilities that are recognized or disclosed at fair value in the financial statements on a recurring basis. Due to their short-term nature, the carrying amounts reported in the consolidated financial statements approximate the fair value for accounts receivable, accounts payable, accrued liabilities, and accrued payroll and compensation.

[0001262039-15-000009:notes:221]
As of December 31, 2014, the functional currency of our foreign subsidiaries is the U.S. dollar. Monetary assets and liabilities denominated in foreign currencies have been remeasured into U.S. dollars using the exchange rates in effect at the balance sheet dates. Foreign currency denominated income and expenses have been remeasured using the average exchange rates in effect during each period. Foreign currency remeasurement losses of $3.2 million, $1.5 million and $0.5 million, are included in Other expense—net for fiscal 2014, fiscal 2013 and fiscal 2012, respectively.

[0001262039-15-000009:notes:222]
Other Investments—Investments in privately held companies where we own less than 20% of the voting stock and have no indicators of significant influence over operating and financial policies of those companies are included in other assets in the consolidated balance sheets and are accounted for under the cost method. For these non-quoted investments, we regularly review the assumptions underlying the operating performance and cash flow forecasts based on information provided by these privately held companies. If it is determined that an other-than-temporary decline exists in an equity security, we write down the investment to its fair value and record the related impairment as an investment loss in our consolidated statements of operations.

[0001262039-15-000009:notes:223]
Goodwill —Goodwill represents the excess of purchase consideration over the estimated fair value of net assets of businesses acquired in a business combination. Goodwill acquired in a business combination are not amortized, but instead tested for impairment at least annually during the fourth quarter. We perform our annual goodwill impairment analysis at the reporting unit level. As of December 31, 2014, we had one reporting unit.

[0001262039-15-000009:notes:224]
In reviewing goodwill for impairment we have the option to (i) assess qualitative factors to determine whether it is more-likely-than-not that the fair value of the reporting unit is less than its carrying amount or (ii) bypass the qualitative assessment and proceed directly to a quantitative assessment. If we opt to perform a qualitative assessment, the factors we may review include, but are not limited to (a) macroeconomic conditions; (b) industry and market considerations; (c) cost factors; (d) overall financial performance; (e) other relevant entity-specific events such as changes in management, strategy, customers, or litigation; (f) events affecting the reporting unit; or (g) or sustained decrease in share price. If we believe, as a result of the qualitative assessment, that it is more-likely-than-not that the fair value of the reporting unit is less than its carrying amount, the quantitative impairment test will be required. Otherwise, no further testing will be required. A quantitative assessment utilizes a two-step process. In the first step, the fair value of the reporting unit is determined, and is compared against its carrying amount, including goodwill. We consider a combination of an income-based approach using projected discounted cash flows and a market-based approach using multiples of comparable companies to determine the fair value. The fair value of the reporting unit is estimated using significant judgment based on a combination of the income and the market approaches. Under the income approach, we estimate fair value of the reporting unit based on the present value of forecasted future cash flows that the reporting unit is expected to generate over its remaining life. Under the market approach, we estimate fair value of our reporting unit based on an analysis that compares the value of the reporting unit to values of other companies in similar lines of business. If the fair value of the reporting unit is less than its carrying value, then we perform the second step to measure the amount of impairment loss. The amount of impairment is determined by comparing the implied fair value of reporting unit goodwill to the carrying value of the goodwill. When the carrying value of the reporting unit's goodwill exceeds its implied fair value, we record an impairment loss equal to the difference. We have not been required to perform this second step of the process because the fair value of our reporting unit exceeded the net book value as of December 31, 2014.

[0001262039-15-000009:notes:225]
Determining the fair value of the reporting unit requires us to make judgments and involves the use of significant estimates and assumptions. These estimates and assumptions include revenue growth rates and operating margins used to calculate projected future cash flows, operating trends, risk-adjusted discount rates, future economic and market conditions and determination of appropriate market comparables. We base our fair value estimates on assumptions we believe to be reasonable but that are unpredictable and inherently uncertain. Actual future results may differ from those estimates. We may also test goodwill for impairment between annual tests in the presence of impairment indicators.

[0001262039-15-000009:notes:226]
Other Intangible Assets—Intangible assets with finite lives are carried at cost, less accumulated amortization. Amortization is computed using the straight-line method over the estimated economic lives of the assets, which range from one to five years.

[0001262039-15-000009:notes:227]
Stock-Based Compensation Expense—We have elected to use the Black-Scholes option pricing model to determine the fair value of our employee stock options and ESPP. The fair value of RSUs is based on the closing market price of our common stock on the date of grant. Stock-based compensation expense, net of estimated forfeitures, is amortized on a straight-line basis. PSUs are RSUs that contain both service-based and market-based vesting conditions. PSUs vest over a specified service period upon the satisfaction of certain market-based vesting conditions, and settle into shares of our common stock upon vesting over a two- or three-year period.  The fair value of a PSU is calculated using the Monte Carlo simulation model on the date of grant and is based on the market price of our common stock on the date of grant modified to reflect the impact of the market-based vesting condition, including the estimated payout level based on that condition. We do not adjust compensation cost for subsequent changes in the expected outcome of the market-based vesting conditions.

[0001262039-15-000009:notes:228]
Advertising Expense—Advertising costs are expensed when incurred and are included in operating expenses in the accompanying consolidated statements of operations. Our advertising expenses were not significant for any periods presented.

[0001262039-15-000009:notes:229]
Research and Development Costs—Research and development costs are expensed as incurred.

[0001262039-15-000009:notes:230]
Software Development Costs—The costs to develop software have not been capitalized as we believe our current software development process is essentially completed concurrent with the establishment of technological feasibility.

[0001262039-15-000009:notes:231]
Accounts Receivable—Trade accounts receivable are recorded at the invoiced amount, net of sales returns reserve and allowances for doubtful accounts. The sales returns reserve is determined based on specific criteria including agreements to provide rebates and other factors known at the time, as well as estimates of the amount of goods shipped that will be returned. To determine the adequacy of the sales returns reserve, we analyze historical experience of actual rebates and returns as well as current product return information. The sales returns reserves was $5.8 million and $4.6 million as of December 31, 2014 and 2013, respectively. The allowance for doubtful accounts is determined based on our assessment of the collectability of customer accounts. The allowance for doubtful accounts was $0.4 million as of December 31, 2014. The allowance for doubtful accounts is not material as of December 31, 2013.

[0001262039-15-000009:notes:232]
Warranties—We generally provide a 1-year warranty on hardware products and a 90-day warranty on software. A provision for estimated future costs related to warranty activities is recorded as a component of cost of product revenues when the product revenue is recognized, based upon historical product failure rates and historical costs incurred in correcting product failures. In the event we change our warranty reserve estimates, the resulting charge against future cost of sales or reversal of previously recorded charges may materially affect our gross margins and operating results.

[0001262039-15-000009:notes:233]
Foreign Currency Derivatives—Our sales contracts are primarily denominated in U.S. dollars and therefore substantially all of our revenue is not subject to foreign currency translation risk. However, a substantial portion of our operating expenses incurred outside the U.S. are denominated in foreign currencies and are subject to fluctuations due to changes in foreign currency exchange rates, particularly changes in the Canadian dollar (“CAD”). To help protect against significant fluctuations in value and the volatility of future cash flows caused by changes in currency exchange rates, we engage in foreign currency risk management activities to hedge balance sheet items denominated in CAD. We do not use these contracts for speculative or trading purposes. All of the derivative instruments are with high quality financial institutions and we monitor the creditworthiness of these parties. These contracts typically have maturities between one and three months. We record changes in the fair value of forward exchange contracts related to balance sheet accounts as Other expense—net in the consolidated statement of operations.

[0001262039-15-000009:notes:234]
Additionally, independent of any hedging activities, fluctuations in foreign currency exchange rates may cause us to recognize transaction gains and losses in our consolidated statements of operations. Our hedging activities are intended to reduce, but not eliminate, the impact of currency exchange rate movements. As our hedging activities are relatively short-term in nature and are focused on CAD, long-term material changes in the value of the U.S. dollar against other foreign currencies, such as the EUR, GBP and CNY could adversely impact our operating expenses in the future.

[0001262039-15-000009:notes:235]
Reclassification

[0001262039-15-000009:notes:236]
Beginning in fiscal 2014, the amounts previously reported as Ratable and other revenue have been combined with the amounts previously reported as Services revenue in the consolidated statements of operations. The combined amounts are now being presented as Services and other revenue in the consolidated statements of operations. The related Cost of revenue and Gross profit have also been combined to conform to the current period presentation. The Ratable and other revenue amounts are not material, and the reclassification did not have any impact on our gross margin or net income.
