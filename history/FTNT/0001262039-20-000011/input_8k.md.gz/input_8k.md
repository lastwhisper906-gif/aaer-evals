# FTNT 8-K — 0001262039-20-000004 filed 2020-02-06

## item codes, every 8-K on or before 2020-02-26

- 2020-02-06 0001262039-20-000004 — 2.02, 9.01
- 2019-12-12 0001262039-19-000038 — 8.01
- 2019-10-31 0001262039-19-000032 — 2.02, 9.01
- 2019-10-28 0001262039-19-000027 — 8.01
- 2019-10-23 0001262039-19-000025 — 5.02, 9.01
- 2019-08-01 0001262039-19-000021 — 2.02, 9.01
- 2019-06-26 0001262039-19-000018 — 5.07
- 2019-05-02 0001262039-19-000010 — 2.02, 9.01
- 2019-02-06 0001262039-19-000002 — 2.02, 9.01
- 2018-11-01 0001262039-18-000037 — 2.02, 9.01
- 2018-10-23 0001262039-18-000035 — 8.01
- 2018-08-01 0001262039-18-000025 — 2.02, 9.01
- 2018-06-28 0001262039-18-000023 — 5.03, 5.07, 9.01
- 2018-06-04 0001262039-18-000021 — 8.01
- 2018-05-03 0001262039-18-000017 — 2.02, 5.02, 9.01
- 2018-02-05 0001262039-18-000004 — 2.02, 5.02, 9.01
- 2017-10-26 0001262039-17-000031 — 2.02, 9.01
- 2017-10-19 0001262039-17-000029 — 5.02 — amendment, the index does not say of what
- 2017-07-26 0001262039-17-000025 — 2.02, 9.01
- 2017-06-27 0001262039-17-000023 — 5.07
- 2017-05-31 0001262039-17-000021 — 5.02 — amendment of 0001262039-17-000019
- 2017-05-30 0001262039-17-000019 — 5.02, 9.01
- 2017-04-27 0001262039-17-000013 — 2.02, 9.01
- 2017-02-02 0001262039-17-000003 — 2.02, 9.01
- 2016-10-27 0001262039-16-000085 — 2.02, 9.01
- 2016-10-11 0001262039-16-000082 — 2.02, 9.01
- 2016-07-28 0001262039-16-000076 — 2.02, 9.01
- 2016-07-22 0001262039-16-000073 — 8.01, 9.01
- 2016-06-20 0001262039-16-000068 — 5.07
- 2016-06-07 0001193125-16-614788 — 8.01
- 2016-04-26 0001262039-16-000061 — 2.02, 9.01
- 2016-01-28 0001262039-16-000051 — 2.02, 9.01
- 2015-10-27 0001262039-15-000045 — 2.02
- 2015-10-22 0001262039-15-000042 — 5.02 — amendment, the index does not say of what
- 2015-10-22 0001262039-15-000041 — 5.02 — amendment, the index does not say of what
- 2015-10-22 0001262039-15-000039 — 2.02, 9.01
- 2015-09-28 0001262039-15-000034 — 5.02, 9.01
- 2015-09-22 0001262039-15-000031 — 9.01 — amendment of 0001193125-15-248065
- 2015-08-28 0001262039-15-000027 — 3.01, 5.02
- 2015-07-23 0001262039-15-000021 — 5.02
- 2015-07-22 0001262039-15-000019 — 2.02, 9.01
- 2015-07-08 0001193125-15-248065 — 2.01, 8.01, 9.01
- 2015-06-22 0001193125-15-229099 — 5.07
- 2015-06-19 0001193125-15-228428 — 5.02, 9.01
- 2015-04-20 0001262039-15-000014 — 2.02, 9.01
- 2015-01-28 0001262039-15-000005 — 2.02, 9.01
- 2014-10-22 0001262039-14-000036 — 2.02, 9.01
- 2014-07-23 0001262039-14-000030 — 2.02, 9.01
- 2014-06-24 0001262039-14-000027 — 5.07
- 2014-04-23 0001262039-14-000021 — 2.02, 9.01
- 2014-04-21 0001262039-14-000018 — 5.03, 9.01
- 2014-01-29 0001262039-14-000004 — 2.02, 9.01
- 2013-12-20 0001262039-13-000061 — 5.02, 9.01
- 2013-11-27 0001262039-13-000057 — 5.02, 7.01, 9.01
- 2013-11-12 0001445305-13-002993 — 5.02
- 2013-10-23 0001262039-13-000051 — 2.02, 9.01
- 2013-07-30 0001262039-13-000039 — 2.02, 9.01
- 2013-06-25 0001262039-13-000030 — 5.07
- 2013-04-30 0001262039-13-000023 — 2.02, 9.01
- 2013-04-19 0001262039-13-000020 — 5.02, 9.01
- 2013-04-19 0001262039-13-000018 — 5.02 — amendment of 0001262039-13-000020
- 2013-04-10 0001262039-13-000016 — 2.02, 9.01
- 2013-03-26 0001262039-13-000013 — 5.02
- 2013-01-30 0001262039-13-000005 — 2.02, 9.01
- 2013-01-24 0001262039-13-000002 — 5.02, 9.01
- 2012-10-16 0001262039-12-000048 — 2.02, 9.01
- 2012-10-01 0001262039-12-000045 — 5.02
- 2012-09-26 0001262039-12-000043 — 5.01
- 2012-07-25 0001262039-12-000038 — 2.02, 9.01
- 2012-07-19 0001262039-12-000034 — 5.02
- 2012-06-20 0001193125-12-275869 — 5.07
- 2012-04-27 0001262039-12-000029 — 5.02
- 2012-04-24 0001262039-12-000025 — 2.02, 9.01
- 2012-01-31 0001262039-12-000006 — 2.02, 9.01
- 2012-01-25 0001262039-12-000003 — 5.03
- 2011-10-24 0001262039-11-000036 — 2.02
- 2011-07-19 0001262039-11-000014 — 2.02, 9.01
- 2011-06-27 0001193125-11-174474 — 5.02, 5.07, 9.01
- 2011-04-27 0001193125-11-111938 — 2.02, 9.01
- 2011-01-25 0001193125-11-013914 — 2.02, 9.01
- 2010-10-21 0001193125-10-233676 — 2.02, 9.01
- 2010-09-02 0001193125-10-203099 — 8.01
- 2010-07-22 0001193125-10-163844 — 2.02, 9.01
- 2010-06-24 0001193125-10-146082 — 5.07
- 2010-04-28 0001193125-10-096698 — 2.02, 9.01
- 2010-02-09 0001193125-10-024614 — 8.01
- 2010-01-27 0001193125-10-014292 — 2.02, 9.01
- 2010-01-26 0001193125-10-013031 — 5.02, 9.01

## late-filing notifications on or before 2020-02-26

- none on or before 2020-02-26

## item 2.02 — earnings release, exhibit 99.1

[0001262039-20-000004:8k_2_02:1]
EX-99.1
2
ftntq4-2019ex991.htm
PRESS RELEASE

[0001262039-20-000004:8k_2_02:2]
Exhibit

[0001262039-20-000004:8k_2_02:3]
Press Release

[0001262039-20-000004:8k_2_02:4]
Fortinet Reports Fourth Quarter and Full Year 2019 Financial Results

[0001262039-20-000004:8k_2_02:5]
Fourth Quarter 2019 Highlights

[0001262039-20-000004:8k_2_02:6]
| • | Total revenue of $614.4 million, up 21% year over year |

[0001262039-20-000004:8k_2_02:7]
| • | Product revenue of $238.8 million, up 19% year over year |

[0001262039-20-000004:8k_2_02:8]
| • | Billings of $802.3 million, up 24% year over year1 |

[0001262039-20-000004:8k_2_02:9]
| • | GAAP operating margin of 19%, up 250 basis points year over year |

[0001262039-20-000004:8k_2_02:10]
| • | Non-GAAP operating margin of 27%, up 110 basis points year over year1 |

[0001262039-20-000004:8k_2_02:11]
| • | GAAP diluted net income per share of $0.66 |

[0001262039-20-000004:8k_2_02:12]
| • | Non-GAAP diluted net income per share of $0.761 |

[0001262039-20-000004:8k_2_02:13]
| • | Cash flow from operations of $190.4 million |

[0001262039-20-000004:8k_2_02:14]
| • | Free cash flow of $143.2 million1 |

[0001262039-20-000004:8k_2_02:15]
Full Year 2019 Highlights

[0001262039-20-000004:8k_2_02:16]
| • | Total revenue of $2.16 billion, up 20% year over year |

[0001262039-20-000004:8k_2_02:17]
| • | Product revenue of $788.5 million, up 17% year over year |

[0001262039-20-000004:8k_2_02:18]
| • | Billings of $2.60 billion, up 21% year over year1 |

[0001262039-20-000004:8k_2_02:19]
| • | Deferred revenue of $2.14 billion, up 27% year over year |

[0001262039-20-000004:8k_2_02:20]
| • | GAAP operating margin of 16%, up 310 basis points year over year |

[0001262039-20-000004:8k_2_02:21]
| • | Non-GAAP operating margin of 25%, up 220 basis points year over year1 |

[0001262039-20-000004:8k_2_02:22]
| • | GAAP diluted net income per share of $1.87 |

[0001262039-20-000004:8k_2_02:23]
| • | Non-GAAP diluted net income per share of $2.471 |

[0001262039-20-000004:8k_2_02:24]
| • | Cash flow from operations of $808.0 million |

[0001262039-20-000004:8k_2_02:25]
| • | Free cash flow of $715.8 million1 |

[0001262039-20-000004:8k_2_02:26]
SUNNYVALE, Calif. - February 6, 2020 - Fortinet® (Nasdaq: FTNT), a global leader in broad, integrated and automated cybersecurity solutions, today announced financial results for the fourth quarter and full year ended December 31, 2019.

[0001262039-20-000004:8k_2_02:27]
“Our advanced architecture with proprietary SPU technology gives us a significant capacity advantage over our competition as indicated by our security compute ratings and enables us to add additional functionality into our products. Our strong fourth quarter product revenue growth was driven by our ability to include cutting-edge security and networking functionality, including SD-WAN, in our products,” said Ken Xie, Founder, Chairman, and Chief Executive Officer. “We are focused on continuing to gain market share by investing in network security, the build out of our Security Fabric platform, and innovations in the areas of 5G, IoT, edge and cloud security.”

[0001262039-20-000004:8k_2_02:28]
Financial Highlights for the Fourth Quarter of 2019

[0001262039-20-000004:8k_2_02:29]
| • | Revenue: Total revenue was $614.4 million for the fourth quarter of 2019, an increase of 21% compared to $507.0 million for the same quarter of 2018. |

[0001262039-20-000004:8k_2_02:30]
| • | Product Revenue: Product revenue was $238.8 million for the fourth quarter of 2019, an increase of 19% compared to $200.8 million for the same quarter of 2018. |

[0001262039-20-000004:8k_2_02:31]
| • | Service Revenue: Service revenue was $375.6 million for the fourth quarter of 2019, an increase of 23% compared to $306.2 million for the same quarter of 2018. |

[0001262039-20-000004:8k_2_02:32]
| • | Billings1: Total billings were $802.3 million for the fourth quarter of 2019, an increase of 24% compared to $649.2 million for the same quarter of 2018. |

[0001262039-20-000004:8k_2_02:33]
| • | GAAP Operating Income and Margin: GAAP operating income was $118.4 million for the fourth quarter of 2019, representing a GAAP operating margin of 19%. GAAP operating income was $85.1 million for the same quarter of 2018, representing a GAAP operating margin of 17%. |

[0001262039-20-000004:8k_2_02:34]
| • | Non-GAAP Operating Income and Margin1: Non-GAAP operating income was $164.9 million for the fourth quarter of 2019, representing a non-GAAP operating margin of 27%. Non-GAAP operating income was $130.6 million for the fourth quarter of 2018, representing a non-GAAP operating margin of 26%. |

[0001262039-20-000004:8k_2_02:35]
| • | GAAP Net Income and Diluted Net Income Per Share: GAAP net income was $115.2 million for the fourth quarter of 2019, compared to GAAP net income of $182.6 million for the same quarter of 2018. GAAP diluted net income per share was $0.66 for the fourth quarter of 2019, based on 175.2 million diluted weighted-average shares outstanding, compared to GAAP diluted net income per share of $1.04 for the same quarter of 2018, based on 175.8 million diluted weighted-average shares outstanding. |

[0001262039-20-000004:8k_2_02:36]
| • | Non-GAAP Net Income and Diluted Net Income Per Share1: Non-GAAP net income was $132.4 million for the fourth quarter of 2019, compared to non-GAAP net income of $104.6 million for the same quarter of 2018. Non-GAAP diluted net income per share was $0.76 for the fourth quarter of 2019, based on 175.2 million diluted weighted-average shares outstanding, compared to $0.59 for the same quarter of 2018, based on 175.8 million diluted weighted-average shares outstanding. |

[0001262039-20-000004:8k_2_02:37]
| • | Cash Flow and Free Cash Flow1: In the fourth quarter of 2019, cash flow from operations was $190.4 million compared to $180.2 million in the same quarter of 2018. Free cash flow was $143.2 million during the fourth quarter of 2019, compared to $168.6 million for the same quarter of 2018. |

[0001262039-20-000004:8k_2_02:38]
Financial Highlights for the Full Year 2019

[0001262039-20-000004:8k_2_02:39]
| • | Revenue: Total revenue was $2.16 billion for 2019, an increase of 20% compared to $1.80 billion in 2018. |

[0001262039-20-000004:8k_2_02:40]
| • | Product Revenue: Product revenue was $788.5 million for 2019, an increase of 17% compared to $674.4 million in 2018. |

[0001262039-20-000004:8k_2_02:41]
| • | Service Revenue: Service revenue was $1.37 billion for 2019, an increase of 21% compared to $1.13 billion in 2018. |

[0001262039-20-000004:8k_2_02:42]
| • | Billings1: Total billings were $2.60 billion for 2019, an increase of 21% compared to $2.15 billion in 2018. |

[0001262039-20-000004:8k_2_02:43]
| • | Deferred Revenue: Total deferred revenue was $2.14 billion as of December 31, 2019, an increase of 27% compared to $1.69 billion as of December 31, 2018. |

[0001262039-20-000004:8k_2_02:44]
| • | GAAP Operating Income and Margin: GAAP operating income was $344.2 million for 2019, representing a GAAP operating margin of 16%. GAAP operating income was $231.0 million for 2018, representing a GAAP operating margin of 13%. |

[0001262039-20-000004:8k_2_02:45]
| • | Non-GAAP Operating Income and Margin1: Non-GAAP operating income was $529.2 million for 2019, representing a non-GAAP operating margin of 25%. Non-GAAP operating income was $402.9 million for 2018, representing a non-GAAP operating margin of 22%. |

[0001262039-20-000004:8k_2_02:46]
| • | GAAP Net Income and Diluted Net Income Per Share: GAAP net income was $326.5 million for 2019, compared to GAAP net income of $332.2 million for 2018. GAAP diluted net income per share was $1.87 for 2019, based on 175.0 million diluted weighted-average shares outstanding, compared to GAAP diluted net income per share of $1.91 for 2018, based on 174.2 million diluted weighted-average shares outstanding. |

[0001262039-20-000004:8k_2_02:47]
| • | Non-GAAP Net Income and Diluted Net Income Per Share1: Non-GAAP net income was $431.7 million for 2019, compared to non-GAAP net income of $319.7 million for 2018. Non-GAAP diluted net income per share was $2.47 for 2019, based on 175.0 million diluted weighted-average shares outstanding, compared to Non-GAAP diluted net income per share of $1.84 for 2018, based on 174.2 million diluted weighted-average shares outstanding. |

[0001262039-20-000004:8k_2_02:48]
| • | Cash Flow and Free Cash Flow1: In 2019, cash flow from operations was $808.0 million, compared to $638.9 million in 2018. Free cash flow was $715.8 million in 2019, compared to $585.9 million in 2018. |

[0001262039-20-000004:8k_2_02:49]
Guidance

[0001262039-20-000004:8k_2_02:50]
For the first quarter of 2020, Fortinet currently expects:

[0001262039-20-000004:8k_2_02:51]
| • | Revenue in the range of $555 million to $565 million |

[0001262039-20-000004:8k_2_02:52]
| • | Billings in the range of $635 million to $655 million |

[0001262039-20-000004:8k_2_02:53]
| • | Non-GAAP gross margin in the range of 77.5% to 78.5% |

[0001262039-20-000004:8k_2_02:54]
| • | Non-GAAP operating margin in the range of 19.0% to 20.0% |

[0001262039-20-000004:8k_2_02:55]
| • | Diluted non-GAAP net income per share in the range of $0.50 to $0.52, assuming a non-GAAP effective tax rate of 24%. This assumes a diluted share count of 175 million to 177 million. |

[0001262039-20-000004:8k_2_02:56]
For the fiscal year 2020, Fortinet currently expects:

[0001262039-20-000004:8k_2_02:57]
| • | Revenue in the range of $2.525 billion to $2.555 billion |

[0001262039-20-000004:8k_2_02:58]
| • | Service revenue in the range of $1.635 billion to $1.655 billion |

[0001262039-20-000004:8k_2_02:59]
| • | Billings in the range of $3.025 billion to $3.075 billion |

[0001262039-20-000004:8k_2_02:60]
| • | Non-GAAP gross margin in the range of 77.5% to 78.5% |

[0001262039-20-000004:8k_2_02:61]
| • | Non-GAAP operating margin in the range of 23.5% to 24.5% |

[0001262039-20-000004:8k_2_02:62]
| • | Diluted non-GAAP net income per share in the range of $2.70 to $2.73, assuming a non-GAAP effective tax rate of 24%. This assumes a diluted share count of 180 million to 182 million. |

[0001262039-20-000004:8k_2_02:63]
Our guidance with respect to non-GAAP financial measures excludes stock-based compensation and amortization of acquired intangible assets. We have not reconciled our guidance with respect to non-GAAP financial measures to the corresponding GAAP measures because certain items that impact these measures are uncertain or out of our control, or cannot

[0001262039-20-000004:8k_2_02:64]
be reasonably predicted. Accordingly, a reconciliation of these non-GAAP financial measures to the corresponding GAAP measures is not available without unreasonable effort.

[0001262039-20-000004:8k_2_02:65]
1 A reconciliation of GAAP to non-GAAP measures has been provided in the financial statement tables included in this press release. An explanation of these measures is also included below under the heading “Non-GAAP Financial Measures.”

[0001262039-20-000004:8k_2_02:66]
Conference Call Details

[0001262039-20-000004:8k_2_02:67]
Fortinet will host a conference call today at 1:30 p.m. Pacific Time (4:30 p.m. Eastern Time) to discuss the earnings results. The call can be accessed by dialing (877) 303-6913 (domestic) or (224) 357-2188 (international) with conference ID # 6479557. A live webcast of the conference call and supplemental slides will be accessible from the Investor Relations page of Fortinet’s website at https://investor.fortinet.com and a replay will be archived and accessible at https://investor.fortinet.com/events-and-presentations. A replay of this conference call can also be accessed through February 13, 2020, by dialing (855) 859-2056 (domestic) or (404) 537-3406 (international) with conference ID #6479557.

[0001262039-20-000004:8k_2_02:68]
First Quarter 2020 Conference Participation Schedule:

[0001262039-20-000004:8k_2_02:69]
| • | Goldman Sachs Technology & Internet Conference 2020 |

[0001262039-20-000004:8k_2_02:70]
February 11, 2020 – San Francisco, CA

[0001262039-20-000004:8k_2_02:71]
| • | Morgan Stanley Technology, Media & Telecom Conference |

[0001262039-20-000004:8k_2_02:72]
March 3, 2020 – San Francisco, CA

[0001262039-20-000004:8k_2_02:73]
| • | Credit Suisse – Software Investor Day (Meetings Only) |

[0001262039-20-000004:8k_2_02:74]
March 12, 2020 – New York, NY

[0001262039-20-000004:8k_2_02:75]
Members of Fortinet’s management team are expected to present at these conferences and discuss the latest company strategies and initiatives. Fortinet’s conference presentations are expected to be available via webcast on the company’s web site. To listen to these presentations and access the most updated information and listen to the webcast of each event, please visit the Investor Relations page of Fortinet’s website at https://investor.fortinet.com. The schedule is subject to change.

[0001262039-20-000004:8k_2_02:76]
About Fortinet (www.fortinet.com)

[0001262039-20-000004:8k_2_02:77]
Fortinet (Nasdaq: FTNT) secures the largest enterprise, service provider and government organizations around the world. Fortinet empowers its customers with intelligent, seamless protection across the expanding attack surface and the power to take on ever-increasing performance requirements of the borderless network -- today and into the future. The Fortinet Security Fabric architecture can deliver security without compromise to address the most critical security challenges, whether in networked, application, cloud or mobile environments. Learn more at https://www.fortinet.com, the Fortinet Blog or FortiGuard Labs.

[0001262039-20-000004:8k_2_02:78]
#          #          #

[0001262039-20-000004:8k_2_02:79]
Copyright © 2020 Fortinet, Inc. All rights reserved. The symbols ® and ™ denote respectively federally registered trademarks and common law trademarks of Fortinet, Inc., its subsidiaries and affiliates. Fortinet’s trademarks include, but are not limited to, the following: Fortinet, the Fortinet logo, FortiGate, FortiOS, FortiGuard, FortiCare, FortiAnalyzer, FortiManager, FortiASIC, FortiClient, FortiCloud, FortiCore, FortiMail, FortiSandbox, FortiADC, FortiAI, FortiAP, FortiAppEngine, FortiAppMonitor, FortiAuthenticator, FortiBalancer, FortiBIOS, FortiBridge, FortiCache, FortiCam, FortiCamera, FortiCarrier, FortiCASB, FortiCenter, FortiCentral,

[0001262039-20-000004:8k_2_02:80]
FortiConnect, FortiController, FortiConverter, FortiCWP, FortiDB, FortiDDoS, FortiDeceptor, FortiDirector, FortiDNS, FortiEDR, FortiExplorer, FortiExtender, FortiFone, FortiHypervisor, FortiInsight, FortiIsolator, FortiLocator, FortiLog, FortiMeter, FortiMoM, FortiMonitor, FortiNAC, FortiPartner, FortiPortal, FortiPresence , FortiProtect, FortiProxy, FortiRecorder, FortiReporter, FortiScan, FortiSDNConnector, FortiSIEM, FortiSDWAN, FortiSMS, FortiSOAR, FortiSwitch, FortiTester, FortiToken, FortiTrust, FortiVoice, FortiVoIP, FortiWAN, FortiWeb, FortiWiFi, FortiWLC, FortiWLCOS and FortiWLM. Other trademarks belong to their respective owners. Fortinet has not independently verified statements or certifications herein attributed to third parties and Fortinet does not independently endorse such statements. Notwithstanding anything to the contrary herein, nothing herein constitutes a warranty, guarantee, contract, binding specification or other binding commitment by Fortinet or any indication of intent related to a binding commitment, and performance and other specification information herein may be unique to certain environments.

[0001262039-20-000004:8k_2_02:81]
FTNT-F

[0001262039-20-000004:8k_2_02:82]
Forward-looking Statements

[0001262039-20-000004:8k_2_02:83]
This press release contains forward-looking statements that involve risks and uncertainties. These forward-looking statements include statements regarding demand for our products and services, guidance and expectations around future financial results, including guidance and expectations for the first quarter and full year 2020, statements regarding market share gains and innovation and investment areas, and statements regarding the momentum in our business and future growth expectations and objectives. Although we attempt to be accurate in making forward-looking statements, it is possible that future circumstances might differ from the assumptions on which such statements are based such that actual results are materially different from our forward-looking statements in this release. Important factors that could cause results to differ materially from the statements herein include the following: general economic risks; global economic conditions, country-specific economic conditions, and foreign currency risks; competitiveness in the security market; the dynamic nature of the security market and its products and services; specific economic risks worldwide and in different geographies, and among different customer segments; uncertainty regarding demand and increased business and renewals from existing customers; uncertainties around continued success in sales growth and market share gains; actual or perceived vulnerabilities in our products or services, and any actual or perceived breach of our network or our customers’ networks; longer sales cycles, particularly for larger enterprise, service providers, government and other large organization customers; the effectiveness of our salesforce and failure to convert sales pipeline into final sales; risks associated with successful implementation of multiple integrated software products and other product functionality risks; risks associated with integrating acquisitions and changes in circumstances and plans associated therewith; sales and marketing execution risks; execution risks around new product development and introductions and innovation; litigation and disputes and the potential cost, distraction and damage to sales and reputation caused thereby or by other factors; cybersecurity threats, breaches and other disruptions; market acceptance of new products and services; the ability to attract and retain personnel; changes in strategy; risks associated with management of growth; lengthy sales and implementation cycles, particularly in larger organizations; technological changes that make our products and services less competitive; risks associated with the adoption of, and demand for, our products and services in general and by specific customer segments; competition and pricing pressure; product inventory shortages for any reason; risks associated with business disruption caused by natural disasters and health emergencies such as earthquakes, fires, power outages, typhoons, floods, health epidemics and viruses such as the coronavirus, and by manmade events such as civil unrest, labor disruption, international trade disputes, international conflicts, terrorism, wars, and critical infrastructure attacks; tariffs and other trade barriers; any political and government

[0001262039-20-000004:8k_2_02:84]
Non-GAAP Financial Measures

[0001262039-20-000004:8k_2_02:85]
We have provided in this release financial information that has not been prepared in accordance with U.S. Generally Accepted Accounting Principles (GAAP). These non-GAAP financial and liquidity measures are not based on any standardized methodology prescribed by GAAP and are not necessarily comparable to similar measures presented by other companies. We use these non-GAAP financial measures internally in analyzing our financial results and believe they are useful to investors, as a supplement to GAAP measures, in evaluating our ongoing operational performance. We believe that the use of these non-GAAP financial measures provides an additional tool for investors to use in evaluating ongoing operating results and trends and in comparing our financial results with peer companies, many of which present similar non-GAAP financial measures to investors.

[0001262039-20-000004:8k_2_02:86]
Non-GAAP financial measures should not be considered in isolation from, or as a substitute for, financial information prepared in accordance with GAAP. Investors are encouraged to review the reconciliation of these non-GAAP financial measures to their most directly comparable GAAP financial measures provided in the financial statement tables below.

[0001262039-20-000004:8k_2_02:87]
Billings (non-GAAP). We define billings as revenue recognized in accordance with GAAP plus the change in deferred revenue from the beginning to the end of the period and adjustments to the deferred revenue balance due to adoption of the new revenue recognition standard less any deferred revenue balances acquired from business combination(s) during the period. We consider billings to be a useful metric for management and investors because billings drive current and future revenue, which is an important indicator of the health and viability of our business. There are a number of limitations related to the use of billings instead of GAAP revenue. First, billings include amounts that have not yet been recognized as revenue and are impacted by the term of security and support agreements. Second, we may calculate billings in a manner that is different from peer companies that report similar financial measures. Management accounts for these limitations by providing specific information regarding GAAP revenue and evaluating billings together with GAAP revenue.

[0001262039-20-000004:8k_2_02:88]
Free cash flow (non-GAAP). We define free cash flow as net cash provided by operating activities minus purchases of property and equipment. We believe free cash flow to be a liquidity measure that provides useful information to management and investors about the amount of cash generated by the business that, after capital expenditures, can be used for strategic opportunities, including repurchasing outstanding common stock, investing in our business, making strategic acquisitions and strengthening the balance sheet. A limitation of using free cash flow rather than the GAAP measures of cash provided by or used in operating activities, investing activities, and financing activities is that free cash flow does not represent the total increase or decrease in the cash and cash equivalents balance for the period because it excludes cash flows from investing activities other than capital expenditures and cash flows from financing activities. Management accounts for this limitation by providing information about our capital expenditures and other investing and financing activities on the face of the cash flow statement and under the caption “Management’s Discussion and Analysis of Financial Condition

[0001262039-20-000004:8k_2_02:89]
and Results of Operations—Liquidity and Capital Resources” in our most recent Quarterly Report on Form 10-Q and Annual Report on Form 10-K and by presenting cash flows from investing and financing activities in our reconciliation of free cash flow. In addition, it is important to note that other companies, including companies in our industry, may not use free cash flow, may calculate free cash flow in a different manner than we do or may use other financial measures to evaluate their performance, all of which could reduce the usefulness of free cash flow as a comparative measure.

[0001262039-20-000004:8k_2_02:90]
Non-GAAP operating income and operating margin. We define non-GAAP operating income as operating income plus stock-based compensation, business acquisition-related charges, purchase accounting adjustments, impairment and amortization of acquired intangible assets, restructuring charges, litigation settlement expenses and, when applicable, other significant non-recurring items in a given quarter. Non-GAAP operating margin is defined as non-GAAP operating income divided by GAAP revenue. We consider these non-GAAP financial measures to be useful metrics for management and investors because they exclude the items noted above so that our management and investors can compare our recurring core business operating results over multiple periods. There are a number of limitations related to the use of non-GAAP operating income instead of operating income or loss calculated in accordance with GAAP. First, non-GAAP operating income excludes the items noted above. Second, the components of the costs that we exclude from our calculation of non-GAAP operating income may differ from the components that peer companies exclude when they report their non-GAAP results of operations. Management accounts for these limitations by providing specific information regarding the GAAP amounts excluded from non-GAAP operating income and evaluating non-GAAP operating income together with operating income calculated in accordance with GAAP.

[0001262039-20-000004:8k_2_02:91]
Non-GAAP net income and diluted net income per share. We define non-GAAP net income as net income or loss plus the items noted above under non-GAAP operating income and operating margin. In addition, we adjust non-GAAP net income and diluted net income per share for gains or losses on investments in privately held companies and a tax adjustment required for an effective tax rate on a non-GAAP basis, which differs from the GAAP effective tax rate. We define non-GAAP diluted net income per share as non-GAAP net income divided by the non-GAAP diluted weighted-average shares outstanding. We consider these non-GAAP financial measures to be useful metrics for management and investors for the same reasons that we use non-GAAP operating income and non-GAAP operating margin. However, in order to provide a more complete picture of our recurring core business operating results, we include in non-GAAP net income and non-GAAP diluted net income per share, the tax adjustment required resulting in an effective tax rate on a non-GAAP basis, which often differs from the GAAP tax rate. We believe the non-GAAP effective tax rates we use are reasonable estimates of normalized tax rates for our current and prior fiscal years under our global operating structure. The same limitations described above regarding our use of non-GAAP operating income and non-GAAP operating margin apply to our use of non-GAAP net income and non-GAAP diluted net income per share. We account for these limitations by providing specific information regarding the GAAP amounts excluded from non-GAAP net income and non-GAAP diluted net income per share and evaluating non-GAAP net income and non-GAAP diluted net income per share together with net income or loss and diluted net income per share calculated in accordance with GAAP.

[0001262039-20-000004:8k_2_02:92]
FORTINET, INC.

[0001262039-20-000004:8k_2_02:93]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001262039-20-000004:8k_2_02:94]
(Unaudited, in millions)

[0001262039-20-000004:8k_2_02:95]
|  | December 31, 2019 |  | December 31, 2018 |
| ASSETS |  |  |  |
| CURRENT ASSETS: |  |  |  |
| Cash and cash equivalents | $ | 1,222.5 |  |  | $ | 1,112.4 |  |
| Short-term investments | 843.1 |  |  | 537.2 |  |
| Accounts receivable—net | 544.3 |  |  | 444.5 |  |
| Inventory | 117.9 |  |  | 90.0 |  |
| Prepaid expenses and other current assets | 41.2 |  |  | 36.8 |  |
| Total current assets | 2,769.0 |  |  | 2,220.9 |  |
| LONG-TERM INVESTMENTS | 144.3 |  |  | 67.0 |  |
| PROPERTY AND EQUIPMENT—NET | 344.3 |  |  | 271.4 |  |
| DEFERRED CONTRACT COSTS | 237.0 |  |  | 182.6 |  |
| DEFERRED TAX ASSETS | 232.6 |  |  | 255.0 |  |
| GOODWILL AND OTHER INTANGIBLE ASSETS—NET | 98.3 |  |  | 60.3 |  |
| OTHER ASSETS | 60.0 |  |  | 20.8 |  |
| TOTAL ASSETS | $ | 3,885.5 |  |  | $ | 3,078.0 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |
| CURRENT LIABILITIES: |  |  |  |
| Accounts payable | $ | 96.4 |  |  | $ | 86.4 |  |
| Accrued liabilities | 97.7 |  |  | 77.5 |  |
| Accrued payroll and compensation | 101.8 |  |  | 98.4 |  |
| Income taxes payable | 4.1 |  |  | 28.2 |  |
| Deferred revenue | 1,173.6 |  |  | 965.9 |  |
| Total current liabilities | 1,473.6 |  |  | 1,256.4 |  |
| DEFERRED REVENUE | 962.3 |  |  | 720.9 |  |
| INCOME TAX LIABILITIES | 82.8 |  |  | 77.5 |  |
| OTHER LIABILITIES | 44.9 |  |  | 13.0 |  |
| Total liabilities | 2,563.6 |  |  | 2,067.8 |  |
| COMMITMENTS AND CONTINGENCIES |  |  |  |
| STOCKHOLDERS’ EQUITY: |  |  |  |
| Common stock | 0.2 |  |  | 0.2 |  |
| Additional paid-in capital | 1,180.3 |  |  | 1,068.3 |  |
| Accumulated other comprehensive income (loss) | 1.1 |  |  | (0.8 | ) |
| Retained earnings (accumulated deficit) | 140.3 |  |  | (57.5 | ) |
| Total stockholders’ equity | 1,321.9 |  |  | 1,010.2 |  |
| TOTAL LIABILITIES AND STOCKHOLDERS’ EQUITY | $ | 3,885.5 |  |  | $ | 3,078.0 |  |

[0001262039-20-000004:8k_2_02:96]
FORTINET, INC.

[0001262039-20-000004:8k_2_02:97]
CONDENSED CONSOLIDATED STATEMENTS OF INCOME

[0001262039-20-000004:8k_2_02:98]
(Unaudited, in millions, except per share amounts)

[0001262039-20-000004:8k_2_02:99]
|  | Three Months Ended |  | Year Ended |
|  | December 31, 2019 |  | December 31, 2018 |  | December 31, 2019 |  | December 31, 2018 |
| REVENUE: |  |  |  |  |  |  |  |
| Product | $ | 238.8 |  |  | $ | 200.8 |  |  | $ | 788.5 |  |  | $ | 674.4 |  |
| Service | 375.6 |  |  | 306.2 |  |  | 1,367.7 |  |  | 1,126.8 |  |
| Total revenue | 614.4 |  |  | 507.0 |  |  | 2,156.2 |  |  | 1,801.2 |  |
| COST OF REVENUE: |  |  |  |  |  |  |  |
| Product | 92.7 |  |  | 86.9 |  |  | 324.6 |  |  | 291.0 |  |
| Service | 47.8 |  |  | 41.6 |  |  | 181.3 |  |  | 159.4 |  |
| Total cost of revenue | 140.5 |  |  | 128.5 |  |  | 505.9 |  |  | 450.4 |  |
| GROSS PROFIT: |  |  |  |  |  |  |  |
| Product | 146.1 |  |  | 113.9 |  |  | 463.9 |  |  | 383.4 |  |
| Service | 327.8 |  |  | 264.6 |  |  | 1,186.4 |  |  | 967.4 |  |
| Total gross profit | 473.9 |  |  | 378.5 |  |  | 1,650.3 |  |  | 1,350.8 |  |
| OPERATING EXPENSES: |  |  |  |  |  |  |  |
| Research and development | 71.2 |  |  | 65.5 |  |  | 277.1 |  |  | 244.5 |  |
| Sales and marketing | 257.1 |  |  | 205.9 |  |  | 926.9 |  |  | 782.3 |  |
| General and administrative | 27.2 |  |  | 22.0 |  |  | 102.1 |  |  | 93.0 |  |
| Total operating expenses | 355.5 |  |  | 293.4 |  |  | 1,306.1 |  |  | 1,119.8 |  |
| OPERATING INCOME | 118.4 |  |  | 85.1 |  |  | 344.2 |  |  | 231.0 |  |
| INTEREST INCOME—NET | 9.9 |  |  | 9.3 |  |  | 42.5 |  |  | 26.5 |  |
| OTHER EXPENSE—NET | (0.6 | ) |  | (2.3 | ) |  | (7.5 | ) |  | (6.6 | ) |
| INCOME BEFORE INCOME TAXES | 127.7 |  |  | 92.1 |  |  | 379.2 |  |  | 250.9 |  |
| PROVISION FOR (BENEFIT FROM) INCOME TAXES | 12.5 |  |  | (90.5 | ) |  | 52.7 |  |  | (81.3 | ) |
| NET INCOME | $ | 115.2 |  |  | $ | 182.6 |  |  | $ | 326.5 |  |  | $ | 332.2 |  |
| Net income per share: |  |  |  |  |  |  |  |
| Basic | $ | 0.67 |  |  | $ | 1.07 |  |  | $ | 1.91 |  |  | $ | 1.96 |  |
| Diluted | $ | 0.66 |  |  | $ | 1.04 |  |  | $ | 1.87 |  |  | $ | 1.91 |  |
| Weighted-average shares outstanding: |  |  |  |  |  |  |  |
| Basic | 171.5 |  |  | 170.4 |  |  | 171.0 |  |  | 169.1 |  |
| Diluted | 175.2 |  |  | 175.8 |  |  | 175.0 |  |  | 174.2 |  |

[0001262039-20-000004:8k_2_02:100]
FORTINET, INC.

[0001262039-20-000004:8k_2_02:101]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001262039-20-000004:8k_2_02:102]
(Unaudited, in millions)

[0001262039-20-000004:8k_2_02:103]
|  | Year Ended |
|  | December 31, 2019 |  | December 31, 2018 |
| CASH FLOWS FROM OPERATING ACTIVITIES: |  |  |  |
| Net income | $ | 326.5 |  |  | $ | 332.2 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |
| Stock-based compensation | 174.1 |  |  | 162.9 |  |
| Amortization of deferred contract costs | 107.9 |  |  | 90.9 |  |
| Depreciation and amortization | 61.6 |  |  | 55.7 |  |
| Amortization of investment premiums (discounts) | (6.0 | ) |  | (0.6 | ) |
| Other | 5.7 |  |  | (0.9 | ) |
| Changes in operating assets and liabilities: |  |  |  |
| Accounts receivable—net | (96.7 | ) |  | (82.0 | ) |
| Inventory | (48.5 | ) |  | (33.4 | ) |
| Prepaid expenses and other current assets | (2.1 | ) |  | 4.2 |  |
| Deferred contract costs | (162.3 | ) |  | (136.4 | ) |
| Deferred tax assets | 17.8 |  |  | (127.8 | ) |
| Other assets | (1.3 | ) |  | (3.8 | ) |
| Accounts payable | 7.7 |  |  | 14.6 |  |
| Accrued liabilities | (1.4 | ) |  | 14.5 |  |
| Accrued payroll and compensation | (2.7 | ) |  | 3.5 |  |
| Other liabilities | (0.2 | ) |  | (0.8 | ) |
| Deferred revenue | 446.7 |  |  | 352.1 |  |
| Income taxes payable | (18.8 | ) |  | (6.0 | ) |
| Net cash provided by operating activities | 808.0 |  |  | 638.9 |  |
| CASH FLOWS FROM INVESTING ACTIVITIES: |  |  |  |
| Purchases of investments | (1,332.3 | ) |  | (681.8 | ) |
| Sales of investments | 31.3 |  |  | 42.8 |  |
| Maturities of investments | 925.5 |  |  | 578.8 |  |
| Purchases of property and equipment | (92.2 | ) |  | (53.0 | ) |
| Payments made in connection with business combination, net of cash acquired | (34.6 | ) |  | (21.7 | ) |
| Net cash used in investing activities | (502.3 | ) |  | (134.9 | ) |
| CASH FLOWS FROM FINANCING ACTIVITIES: |  |  |  |
| Repurchase and retirement of common stock | (145.1 | ) |  | (211.8 | ) |
| Proceeds from issuance of common stock | 49.5 |  |  | 86.5 |  |
| Taxes paid related to net share settlement of equity awards | (96.0 | ) |  | (67.2 | ) |
| Payments of debt assumed in connection with business combination | (3.7 | ) |  | (10.1 | ) |
| Other | (0.3 | ) |  | — |  |
| Net cash used in financing activities | (195.6 | ) |  | (202.6 | ) |
| NET INCREASE IN CASH AND CASH EQUIVALENTS | 110.1 |  |  | 301.4 |  |
| CASH AND CASH EQUIVALENTS—Beginning of period | 1,112.4 |  |  | 811.0 |  |
| CASH AND CASH EQUIVALENTS—End of period | $ | 1,222.5 |  |  | $ | 1,112.4 |  |

[0001262039-20-000004:8k_2_02:104]
Reconciliations of non-GAAP results of operations measures to the nearest comparable GAAP measures

[0001262039-20-000004:8k_2_02:105]
(Unaudited, in millions, except per share amounts)

[0001262039-20-000004:8k_2_02:106]
Reconciliation of net cash provided by operating activities to free cash flow

[0001262039-20-000004:8k_2_02:107]
|  | Three Months Ended |  | Year Ended |
|  | December 31, 2019 |  | December 31, 2018 |  | December 31, 2019 |  | December 31, 2018 |
| Net cash provided by operating activities | $ | 190.4 |  |  | $ | 180.2 |  |  | $ | 808.0 |  |  | $ | 638.9 |  |
| Less: Purchases of property and equipment | (47.2 | ) |  | (11.6 | ) |  | (92.2 | ) |  | (53.0 | ) |
| Free cash flow | $ | 143.2 |  |  | $ | 168.6 |  |  | $ | 715.8 |  |  | $ | 585.9 |  |
| Net cash used in investing activities | $ | (99.6 | ) |  | $ | (127.5 | ) |  | $ | (502.3 | ) |  | $ | (134.9 | ) |
| Net cash used in financing activities | $ | (43.8 | ) |  | $ | (109.7 | ) |  | $ | (195.6 | ) |  | $ | (202.6 | ) |

[0001262039-20-000004:8k_2_02:108]
Reconciliation of GAAP operating income to non-GAAP operating income, operating margin, net income and diluted net income per share

[0001262039-20-000004:8k_2_02:109]
|  | Three Months Ended December 31, 2019 |  | Three Months Ended December 31, 2018 |
|  | GAAP Results |  | Adjustments |  | Non-GAAP Results |  | GAAP Results |  | Adjustments |  | Non-GAAP Results |
| Operating income | $ | 118.4 |  |  | $ | 46.5 |  | (a) | $ | 164.9 |  |  | $ | 85.1 |  |  | $ | 45.5 |  | (b) | $ | 130.6 |  |
| Operating margin | 19 | % |  |  |  | 27 | % |  | 17 | % |  |  |  | 26 | % |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | 43.7 |  |  |  |  |  |  | 42.6 |  |  |  |
| Amortization of acquired intangible assets |  |  | 2.8 |  |  |  |  |  |  | 2.9 |  |  |  |
| Tax adjustment |  |  | (29.3 | ) | (c) |  |  |  |  | (123.5 | ) | (c) |  |
| Net income | $ | 115.2 |  |  | $ | 17.2 |  |  | $ | 132.4 |  |  | $ | 182.6 |  |  | $ | (78.0 | ) |  | $ | 104.6 |  |
| Diluted net income per share | $ | 0.66 |  |  |  |  | $ | 0.76 |  |  | $ | 1.04 |  |  |  |  | $ | 0.59 |  |
| Shares used in diluted net income per share calculations | 175.2 |  |  |  |  | 175.2 |  |  | 175.8 |  |  |  |  | 175.8 |  |

[0001262039-20-000004:8k_2_02:110]
(a) To exclude $43.7 million of stock-based compensation and $2.8 million of amortization of acquired intangible assets in the three months ended December 31, 2019.

[0001262039-20-000004:8k_2_02:111]
(b) To exclude $42.6 million of stock-based compensation and $2.9 million of amortization of acquired intangible assets in the three months ended December 31, 2018.

[0001262039-20-000004:8k_2_02:112]
(c) Non-GAAP financial information is adjusted to an overall effective tax rate of 24% in 2019 and 2018, on a non-GAAP basis, which differs from the GAAP effective tax rate.

[0001262039-20-000004:8k_2_02:113]
|  | Year Ended December 31, 2019 |  | Year Ended December 31, 2018 |
|  | GAAP Results |  | Adjustments |  | Non-GAAP Results |  | GAAP Results |  | Adjustments |  | Non-GAAP Results |
| Operating income | $ | 344.2 |  |  | $ | 185.0 |  | (a) | $ | 529.2 |  |  | $ | 231.0 |  |  | $ | 171.9 |  | (b) | $ | 402.9 |  |
| Operating margin | 16 | % |  |  |  | 25 | % |  | 13 | % |  |  |  | 22 | % |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | 174.1 |  |  |  |  |  |  | 162.9 |  |  |  |
| Amortization of acquired intangible assets |  |  | 10.9 |  |  |  |  |  |  | 9.0 |  |  |  |
| Operating income |  |  | 185.0 |  |  |  |  |  |  | 171.9 |  |  |  |
| (Gain) loss on investments in privately-held companies |  |  | 3.8 |  | (c) |  |  |  |  | (2.2 | ) | (d) |  |
| Tax adjustment |  |  | (83.6 | ) | (e) |  |  |  |  | (182.2 | ) | (e) |  |
| Net income | $ | 326.5 |  |  | $ | 105.2 |  |  | $ | 431.7 |  |  | $ | 332.2 |  |  | $ | (12.5 | ) |  | $ | 319.7 |  |
| Diluted net income per share | $ | 1.87 |  |  |  |  | $ | 2.47 |  |  | $ | 1.91 |  |  |  |  | $ | 1.84 |  |
| Shares used in diluted net income per share calculations | 175.0 |  |  |  |  | 175.0 |  |  | 174.2 |  |  |  |  | 174.2 |  |

[0001262039-20-000004:8k_2_02:114]
(a) To exclude $174.1 million of stock-based compensation and $10.9 million of amortization of acquired intangible assets in 2019.

[0001262039-20-000004:8k_2_02:115]
(b) To exclude $162.9 million of stock-based compensation and $9.0 million of amortization of acquired intangible assets in 2018.

[0001262039-20-000004:8k_2_02:116]
(c) To exclude a $3.8 million impairment charge on an investment in a privately held company.

[0001262039-20-000004:8k_2_02:117]
(d) To exclude a $2.2 million gain on the sale of an investment in a privately held company.

[0001262039-20-000004:8k_2_02:118]
(e) Non-GAAP financial information is adjusted to an overall effective tax rate of 24% in 2019 and 2018, on a non-GAAP basis, which differs from the GAAP effective tax rate.

[0001262039-20-000004:8k_2_02:119]
Reconciliation of total revenue to total billings

[0001262039-20-000004:8k_2_02:120]
|  | Three Months Ended |  | Year Ended |
|  | December 31, 2019 |  | December 31, 2018 |  | December 31, 2019 |  | December 31, 2018 |
| Total revenue | $ | 614.4 |  |  | $ | 507.0 |  |  | $ | 2,156.2 |  |  | $ | 1,801.2 |  |
| Add: Change in deferred revenue | 190.3 |  |  | 142.4 |  |  | 449.1 |  |  | 350.5 |  |
| Add: Deferred revenue adjustment due to adoption of the new revenue recognition standard | — |  |  | — |  |  | — |  |  | 4.1 |  |
| Less: Deferred revenue balance acquired in business acquisitions | (2.4 | ) |  | (0.2 | ) |  | (2.4 | ) |  | (2.5 | ) |
| Total billings | $ | 802.3 |  |  | $ | 649.2 |  |  | $ | 2,602.9 |  |  | $ | 2,153.3 |  |

[0001262039-20-000004:8k_2_02:121]
| Investor Contact: |  | Media Contact: |
| Peter Salkowski |  | Sandra Wheatley |
| Fortinet, Inc. |  | Fortinet, Inc. |
| 408-331-4595 |  | 408-391-9408 |
| psalkowski@fortinet.com |  | swheatley@fortinet.com |
