# FTNT MD&A — 0001262039-20-000011


## mdna

[0001262039-20-000011:mdna:1]
ITEM 7.     Management’s Discussion and Analysis of Financial Condition and Results of Operations

[0001262039-20-000011:mdna:2]
| • | continued growth and market share gains; |

[0001262039-20-000011:mdna:3]
| • | variability in sales in certain product categories from year to year and between quarters; |

[0001262039-20-000011:mdna:4]
| • | expected impact of sales of certain products and services; |

[0001262039-20-000011:mdna:5]
| • | the impact of macro-economic, geopolitical factors and other disruption on our manufacturing or sales, including the impact of the coronavirus and other public health issues and natural disasters; |

[0001262039-20-000011:mdna:6]
| • | the proportion of our revenue that consists of our product and service revenue, and the mix of billings between products and services, and the duration of service contracts; |

[0001262039-20-000011:mdna:7]
| • | the impact of our product innovation strategy; |

[0001262039-20-000011:mdna:8]
| • | the effects of government regulation, tariffs and other related policies; |

[0001262039-20-000011:mdna:9]
| • | drivers of long-term growth and operating leverage, such as increased sales productivity, functionality and value in our standalone and bundled subscription service offerings; |

[0001262039-20-000011:mdna:10]
| • | growing our sales to businesses, service providers and government organizations, our ability to execute these sales and of the complexity of selling to all segments (including the increased competition and unpredictability of timing associated with sales to larger enterprises), the impact of sales to these organizations on our long-term growth, expansion and operating results, and the effectiveness of our internal sales organization; |

[0001262039-20-000011:mdna:11]
| • | our ability to hire properly qualified and effective sales, support and engineering employees; |

[0001262039-20-000011:mdna:12]
| • | trends in revenue, cost of revenue and gross margin; |

[0001262039-20-000011:mdna:13]
| • | trends in our operating expenses, including sales and marketing expense, research and development expense, general and administrative expense, and expectations regarding these expenses; |

[0001262039-20-000011:mdna:14]
| • | risks and expectations related to acquisitions or sales of assets, including integration issues related to product plans and products, including the acquired technology; |

[0001262039-20-000011:mdna:15]
| • | continued investments in research and development, and expectations that our research and development expense will increase in absolute dollars during 2020; |

[0001262039-20-000011:mdna:16]
| • | continued investments in our sales resources and infrastructure and marketing strategy, and expectations that our sales and marketing expense will increase in absolute dollars during 2020; |

[0001262039-20-000011:mdna:17]
| • | expectations that our general and administrative expense will increase in absolute dollars during 2020; |

[0001262039-20-000011:mdna:18]
| • | expectations that proceeds from the exercise of stock options in future years will be adversely impacted by the increased mix of restricted stock units versus stock options granted; |

[0001262039-20-000011:mdna:19]
| • | estimates of a range of 2020 spending on our headquarters expansion project; |

[0001262039-20-000011:mdna:20]
| • | expectations regarding uncertain tax benefits and our effective domestic and global tax rates, and the impact of the Tax Cuts and Jobs Act (the “2017 Tax Act”) and the Ninth Circuit’s Altera decision regarding stock-based compensation in cost sharing arrangements; |

[0001262039-20-000011:mdna:21]
43

[0001262039-20-000011:mdna:22]
| • | expectations regarding spending related to real estate and other capital expenditures and to the impact on free cash flows; |

[0001262039-20-000011:mdna:23]
| • | competition in our markets; |

[0001262039-20-000011:mdna:24]
| • | statements regarding expected outcomes and liabilities in litigation; |

[0001262039-20-000011:mdna:25]
| • | our intentions regarding share repurchases and the sufficiency of our existing cash, cash equivalents and investments to meet our cash needs for at least the next 12 months; |

[0001262039-20-000011:mdna:26]
| • | other statements regarding our future operations, financial condition and prospects and business strategies; and |

[0001262039-20-000011:mdna:27]
| • | adoption and impact of new accounting standards. |

[0001262039-20-000011:mdna:28]
Business Overview

[0001262039-20-000011:mdna:29]
Fortinet is a global leader in cybersecurity solutions provided to a wide variety of organizations, such as enterprises, communication service providers, government organizations and small businesses. Our cybersecurity solutions are designed to provide broad visibility and segmentation of the digital attack surface through our integrated Fortinet Security Fabric platform, which features automated protection, detection and response.

[0001262039-20-000011:mdna:30]
The focus areas of our business consist of:

[0001262039-20-000011:mdna:31]
| • | Network Security—We derive a majority of product sales from our FortiGate network security appliances. Our FortiGate network security appliances include a broad set of built-in security and networking features and functionalities, including firewall, next-generation firewall, secure web gateway, SSL inspection, SD-WAN, intrusion prevention, SSL data leak prevention, VPN, switch and wireless controller and wide area network edge. Our network security appliances are managed by our FortiOS network operating system, which provides the foundation for FortiGate security functions. We enhance the performance of our network security appliances from branch to data center by designing and implementing SPU technology within our appliances, enabling us to add security and network functionality with minimal impact to network throughput performance. |

[0001262039-20-000011:mdna:32]
| • | Infrastructure Security—The Fortinet Security Fabric platform is a broad, automated and integrated security platform that extends beyond the network to cover other attack vectors. Other infrastructure solutions covered include Secure Access (Wi-Fi and switch). |

[0001262039-20-000011:mdna:33]
| • | Cloud Security—We help customers connect securely to and across their hybrid, public and private cloud environments by offering security through our virtual firewall and other software products in public and private cloud environments. Our cloud security solutions, including virtual appliances and hosted solutions, extend the core capabilities of the Fortinet Security Fabric platform to provide businesses with the same level of cybersecurity and threat intelligence in and across cloud environments that they receive on their physical networks. Fortinet cloud security offerings are available across all major cloud providers, including Amazon Web Services, Microsoft Azure, Google Cloud, Oracle Cloud, Alibaba Cloud and IBM Cloud. Our Cloud Security portfolio also includes securing applications, including email and web. |

[0001262039-20-000011:mdna:34]
44

[0001262039-20-000011:mdna:35]
| • | Endpoint Protection, Internet of Things and Operational Technology Security—We protect end-customers from advanced threats that target their devices and the data that reside on them through our advanced endpoint solutions that provide core endpoint protection, advanced threat protection, incident monitoring, and response. Additionally, the proliferation of IoT and the digitization of OT devices has generated new opportunities for us to grow our business. We offer network access control solutions that provide visibility, control and automated event responses in order to secure IoT devices. |

[0001262039-20-000011:mdna:36]
We also develop and provide AI-driven security operations solutions, including FortiGuard security services that can be applied across the entire Fortinet Security Fabric platform. These solutions help customers better secure their environments by delivering deeper intelligence and insights and by narrowing the gaps in security skills and resources that are present in many organizations.

[0001262039-20-000011:mdna:37]
In addition to our security solutions, our customers, channel partners and end-customers may purchase FortiGuard and other security subscription services to receive threat intelligence updates, FortiCare technical support services across all of our products and the support of Technical Account Managers, Resident Engineers and professional service consultants for implementations or training services.

[0001262039-20-000011:mdna:38]
Financial Highlights

[0001262039-20-000011:mdna:39]
| • | Total revenue was $2.16 billion in 2019, an increase of 20% compared to $1.80 billion in 2018. Product revenue was $788.5 million in 2019, an increase of 17% compared to $674.4 million in 2018. Service revenue was $1.37 billion in 2019, an increase of 21% compared to $1.13 billion in 2018. |

[0001262039-20-000011:mdna:40]
| • | We generated operating income of $344.2 million in 2019, an increase of 49% compared to $231.0 million in 2018. |

[0001262039-20-000011:mdna:41]
| • | Cash, cash equivalents and investments were $2.21 billion as of December 31, 2019, an increase of $493.3 million, or 29%, from December 31, 2018. |

[0001262039-20-000011:mdna:42]
| • | Deferred revenue was $2.14 billion as of December 31, 2019, an increase of $449.1 million, or 27%, from December 31, 2018. |

[0001262039-20-000011:mdna:43]
| • | We generated cash flows from operating activities of $808.0 million in 2019, an increase of $169.1 million, or 26%, compared to 2018. |

[0001262039-20-000011:mdna:44]
| • | In 2019, we repurchased 1.9 million shares of common stock under the Repurchase Program for an aggregate purchase price of $140.9 million. In 2018, we repurchased 3.8 million shares of common stock for a total purchase price of $209.1 million. |

[0001262039-20-000011:mdna:45]
Our revenue growth was driven by both product and service revenue. On a geographic basis, revenue continues to be diversified globally, which remains a key strength of our business. Product revenue grew 17% in 2019. We experienced revenue growth across several of our hardware and software products, including FortiGate enabled with SD-WAN features. Service revenue growth of 21% in 2019 was driven by the strength of our FortiGuard and other security subscription revenue, which grew 24%.

[0001262039-20-000011:mdna:46]
During the second quarter of 2019, we reclassified the 100 series of our FortiGate product from an entry-level product to a mid-range product. Prior periods have been reclassified to conform with current period presentation. Including this reclassification, we saw a mix shift from high-end to mid-range products in 2019.

[0001262039-20-000011:mdna:47]
During the fourth quarter of 2019, we acquired enSilo Limited (“enSilo”) and CyberSponse Inc. (“CyberSponse”) to further strengthen our Fortinet Security Fabric platform by providing real-time automated endpoint detection and response capability (enSilo) and security orchestration, automation and response products and services (CyberSponse). The impact of these acquisitions, individually and in the aggregate, were not material to our consolidated financial statements.

[0001262039-20-000011:mdna:48]
In 2019, our revenue growth outpaced our growth in operating expenses. As a result, operating expenses as a percentage of revenue decreased by two percentage points compared to 2018. Headcount increased by 21% to 7,082 employees and contractors as of December 31, 2019, up from 5,845 as of December 31, 2018. The acquisition of enSilo and CyberSponse increased headcount by 135 employees. Excluding these two acquisitions, headcount would have increased 19% year over year.

[0001262039-20-000011:mdna:49]
The impact of the coronavirus outbreak on our business remains uncertain, and, though the majority of our products are manufactured outside of China, certain components for our products and certain of our products are manufactured in China and Taiwan and we have international shipping and logistics centers in Taiwan. While any significant impact is uncertain at this point, if the coronavirus outbreak continues to spread, the business disruption caused thereby could have a material negative impact on our billings, revenue, gross margin, operating margin, cash flows and other financial results for the first quarter of 2020 and certain periods thereafter.

[0001262039-20-000011:mdna:50]
Business Model

[0001262039-20-000011:mdna:51]
We primarily sell our products and services through a two-tier distribution model. We sell to distributors that sell to networking security and enterprise-focused resellers and to service providers and MSSPs, who, in turn, sell to our end-customers. In certain cases, we sell directly to large service providers and major systems integrators. In certain cases, we sell directly to large service providers and major systems integrators. We also offer our products across major cloud providers, and have recognized on-demand revenue from Amazon Web Services, Microsoft Azure, IBM Cloud, Google Cloud and Oracle Cloud. We have also recognized revenue from customers who deploy our products in a bring-your-own-license (“BYOL”) arrangement at a cloud provider such as Amazon Web Services, Microsoft Azure, Google Cloud, Oracle Cloud and Alibaba Cloud. In a BYOL arrangement, a customer purchases a software license from us through our channel partners and deploys the software in a cloud provider’s environment. Similarly, customers may purchase such a license from us and deploy in their private cloud.

[0001262039-20-000011:mdna:52]
Typically, our customers purchase our hardware products and software licenses, as well as our FortiGuard security subscription and FortiCare technical support services. We generally invoice at the time of our sale for the total price of the products and security and technical support services. The invoice is typically payable within 30 to 45 days. We also invoice certain services on a monthly basis.

[0001262039-20-000011:mdna:53]
Key Metrics

[0001262039-20-000011:mdna:54]
We monitor a number of key metrics, including the key financial metrics set forth below, in order to help us evaluate growth trends, establish budgets, measure the effectiveness of our sales and marketing efforts, and assess operational efficiencies. The following table summarizes revenue, deferred revenue, billings (non-GAAP), net cash provided by operating activities, and free cash flow (non-GAAP). We discuss revenue below under “—Components of Operating Results,” and we discuss net cash provided by operating activities below under “—Liquidity and Capital Resources.” Deferred revenue, billings (non-GAAP), and free cash flow (non-GAAP) are discussed immediately below the following table.

[0001262039-20-000011:mdna:55]
|  | Year Ended or As of December 31, |
|  | 2019 |  | 2018 |  | 2017 |
|  | (in millions) |
| Revenue | $ | 2,156.2 |  |  | $ | 1,801.2 |  |  | $ | 1,494.9 |  |
| Deferred revenue | $ | 2,135.9 |  |  | $ | 1,686.8 |  |  | $ | 1,336.3 |  |
| Billings (non-GAAP) | $ | 2,602.9 |  |  | $ | 2,153.3 |  |  | $ | 1,795.9 |  |
| Net cash provided by operating activities | $ | 808.0 |  |  | $ | 638.9 |  |  | $ | 594.4 |  |
| Free cash flow (non-GAAP) | $ | 715.8 |  |  | $ | 585.9 |  |  | $ | 459.1 |  |

[0001262039-20-000011:mdna:56]
Deferred revenue. Our deferred revenue consists of amounts that have been invoiced but that have not yet been recognized as revenue. The majority of our deferred revenue balance consists of the unrecognized portion of service revenue from FortiGuard security subscription and FortiCare technical support service contracts, which is recognized as revenue ratably over the contractual service period. We monitor our deferred revenue balance, deferred revenue growth and the mix of short-term and long-term deferred revenue because deferred revenue represents a significant portion of free cash flow and of revenue to be recognized in future periods. Deferred revenue was $2.14 billion as of December 31, 2019, an increase of $449.1 million, or 27%, from December 31, 2018.

[0001262039-20-000011:mdna:57]
Billings (non-GAAP). We define billings as revenue recognized in accordance with generally accepted accounting principles in the United States (“GAAP”) plus the change in deferred revenue from the beginning to the end of the period and adjustments to the deferred revenue balance due to adoption of Financial Accounting Standards Board (“FASB”) Topic 606, Revenue from Contracts with Customers (“Topic 606”), less any deferred revenue balances acquired from business combination(s) during the period. We consider billings to be a useful metric for management and investors because billings

[0001262039-20-000011:mdna:58]
drive current and future revenue, which is an important indicator of the health and viability of our business. There are a number of limitations related to the use of billings instead of GAAP revenue. First, billings include amounts that have not yet been recognized as revenue and are impacted by the security and support contractual service period agreements. Second, we may calculate billings in a manner that is different from peer companies that report similar financial measures. Management accounts for these limitations by providing specific information regarding GAAP revenue and evaluating billings together with GAAP revenue. Total billings were $2.60 billion for 2019, an increase of 21% compared to $2.15 billion in 2018.

[0001262039-20-000011:mdna:59]
A reconciliation of revenue, the most directly comparable financial measure calculated and presented in accordance with GAAP, to billings is provided below:

[0001262039-20-000011:mdna:60]
|  | Year Ended December 31, |
| 2019 |  | 2018 |  | 2017 |
| (in millions) |
| Billings: |  |  |  |  |  |
| Revenue | $ | 2,156.2 |  |  | $ | 1,801.2 |  |  | $ | 1,494.9 |  |
| Add: Change in deferred revenue | 449.1 |  |  | 350.5 |  |  | 301.0 |  |
| Add: Deferred revenue adjustment due to adoption of Topic 606 | — |  |  | 4.1 |  |  | — |  |
| Less: Deferred revenue balance acquired in business combinations | (2.4 | ) |  | (2.5 | ) |  | — |  |
| Total billings (non-GAAP) | $ | 2,602.9 |  |  | $ | 2,153.3 |  |  | $ | 1,795.9 |  |

[0001262039-20-000011:mdna:61]
Free cash flow (non-GAAP). We define free cash flow as net cash provided by operating activities minus purchases of property and equipment. We believe free cash flow to be a liquidity measure that provides useful information to management and investors about the amount of cash generated by the business that, after capital expenditures, can be used for strategic opportunities, including repurchasing outstanding common stock, investing in our business, making strategic acquisitions and strengthening the balance sheet. A limitation of using free cash flow rather than the GAAP measures of cash provided by or used in operating activities, investing activities, and financing activities is that free cash flow does not represent the total increase or decrease in the cash and cash equivalents balance for the period because it excludes cash flows from investing activities other than capital expenditures and cash flows from financing activities. Management accounts for this limitation by providing information about our capital expenditures and other investing and financing activities on the face of the consolidated statements of cash flows and under “—Liquidity and Capital Resources” and by presenting cash flows from investing and financing activities in our reconciliation of free cash flow. In addition, it is important to note that other companies, including companies in our industry, may not use free cash flow, may calculate free cash flow in a different manner than we do or may use other financial measures to evaluate their performance, all of which could reduce the usefulness of free cash flow as a comparative measure. A reconciliation of net cash provided by operating activities, the most directly comparable financial measure calculated and presented in accordance with GAAP, to free cash flow is provided below:

[0001262039-20-000011:mdna:62]
|  | Year Ended December 31, |
| 2019 |  | 2018 |  | 2017 |
| (in millions) |
| Free Cash Flow: |  |  |  |  |  |
| Net cash provided by operating activities | $ | 808.0 |  |  | $ | 638.9 |  |  | $ | 594.4 |  |
| Less: Purchases of property and equipment | (92.2 | ) |  | (53.0 | ) |  | (135.3 | ) |
| Free cash flow (non-GAAP) | $ | 715.8 |  |  | $ | 585.9 |  |  | $ | 459.1 |  |
| Net cash used in investing activities | $ | (502.3 | ) |  | $ | (134.9 | ) |  | $ | (76.8 | ) |
| Net cash used in financing activities | $ | (195.6 | ) |  | $ | (202.6 | ) |  | $ | (415.6 | ) |

[0001262039-20-000011:mdna:63]
Components of Operating Results

[0001262039-20-000011:mdna:64]
Revenue. We generate the majority of our revenue from sales of our hardware and software products and amortization of amounts included in deferred revenue related to previous sales of FortiGuard security subscription and FortiCare technical support services. We also recognize revenue from cloud security solutions, professional services and training.

[0001262039-20-000011:mdna:65]
47

[0001262039-20-000011:mdna:66]
Our total revenue is comprised of the following:

[0001262039-20-000011:mdna:67]
| • | Product revenue. Product revenue is primarily generated from sales of our appliances. The majority of our product revenue has been generated by our FortiGate product line, and we do not expect this to change in the foreseeable future. Product revenue also includes revenue derived from sales of fabric hardware and software products, including FortiGate software licenses. As a percentage of total revenue, we expect that our product revenue may vary from quarter-to-quarter based on certain factors, as discussed below under “—Quarterly Results of Operations,” and we expect the trend to continue in 2020. |

[0001262039-20-000011:mdna:68]
| • | Service revenue. Service revenue is generated primarily from FortiGuard security subscription services and FortiCare technical support services. We recognize revenue from FortiGuard security subscription and FortiCare technical support services over the contractual service period. Our typical contractual support and subscription term is one to three years and, to a lesser extent, five years. We also generate a small portion of our revenue from professional services and training services, for which we recognize revenue as the services are provided, and cloud-based services, for which we recognize revenue as the services are delivered or on a monthly usage basis. As a percentage of total revenue, we continue to expect service revenue to be higher than product revenue. Our service revenue growth rate depends significantly on the growth of our customer base, the expansion of our service bundle offerings, the expansion and introduction of new service offerings and the renewal of service contracts by our existing customers. |

[0001262039-20-000011:mdna:69]
Our total cost of revenue is comprised of the following:

[0001262039-20-000011:mdna:70]
| • | Cost of product revenue. The majority of the cost of product revenue consists of third-party contract manufacturers’ costs and the costs of materials used in production. Our cost of product revenue also includes supplies, shipping costs, personnel costs associated with logistics and quality control, facility-related costs, excess and obsolete inventory costs, warranty costs and amortization of intangible assets. Personnel costs include direct compensation and benefits. |

[0001262039-20-000011:mdna:71]
| • | Cost of service revenue. Cost of service revenue is primarily comprised of salaries, benefits and bonuses, as well as stock-based compensation. Cost of service revenue also includes third-party repair and contract fulfillment, data center and cloud hosting, supplies and facility-related costs. |

[0001262039-20-000011:mdna:72]
Gross margin. Gross profit as a percentage of revenue, or gross margin, has been and will continue to be affected by a variety of factors, including the average sales price of our products, product costs, the mix of products sold and the mix of revenue between hardware products, software licenses and services and any excess inventory write-offs. Service revenue and software licenses have had a positive effect on our total gross margin given the higher gross margins compared to hardware product gross margins. During 2019, service gross margin benefited from renewals and continued sales of services and subscriptions, growing faster than related expenses. Product gross margin benefited from gains in average selling price, as well as lower direct and indirect product costs as a percentage of product revenue. It also benefited from deal mix, software revenue growth and a stable product transition environment. Cost of product revenue was comprised of direct product costs and indirect costs, including inventory reserves and other manufacturing overhead. Overall gross margin in 2020 will be impacted by service and product revenue mix, but we expect it to be comparable to overall gross margin in 2019.

[0001262039-20-000011:mdna:73]
Operating expenses. Our operating expenses consist of research and development, sales and marketing and general and administrative expenses. Personnel costs are the most significant component of operating expenses and consist primarily of salaries, benefits, bonuses, stock-based compensation, and sales commissions, as applicable. We expect personnel costs to continue to increase in absolute dollars as we expand our workforce.

[0001262039-20-000011:mdna:74]
| • | Research and development. Research and development expense consists primarily of personnel costs. Additional research and development expenses include ASIC and system prototypes and certification-related expenses, depreciation of property and equipment and facility-related expenses. The majority of our research and development is focused on both software development and the ongoing development of our hardware platform. We record all research and development expenses as incurred. Our research and development teams are primarily located in Canada and the United States. |

[0001262039-20-000011:mdna:75]
| • | Sales and marketing. Sales and marketing expense is the largest component of our operating expenses and primarily consists of personnel costs. Additional sales and marketing expenses include product marketing, public relations, field marketing and channel marketing programs (e.g. partner cooperative marketing arrangements), as well as travel, depreciation of property and equipment and facility-related expenses. We |

[0001262039-20-000011:mdna:76]
intend to hire additional personnel focused on sales and marketing and expand our sales and marketing efforts worldwide in order to capture market share in the enterprise market.

[0001262039-20-000011:mdna:77]
| • | General and administrative. General and administrative expense consists of personnel costs, as well as professional fees, depreciation of property and equipment and software and facility-related expenses. General and administrative personnel include our executive, finance, human resources, information technology and legal organizations. Our professional fees principally consist of outside legal, auditing, accounting, tax, information technology and other consulting costs. |

[0001262039-20-000011:mdna:78]
Interest income—net. Interest income—net consists of interest earned on our cash, cash equivalents and investments. We have historically invested our cash in corporate debt securities, certificates of deposit and term deposits, commercial paper, money market funds, and U.S. government and agency securities.

[0001262039-20-000011:mdna:79]
Other income (expense)—net. Other income (expense)—net consists primarily of foreign exchange gains and losses related to foreign currency remeasurement, as well as the gain on the sale of an investment in a privately held company and the impairment charge on an investment in a privately held company.

[0001262039-20-000011:mdna:80]
Provision for (benefit from) income taxes. We are subject to income taxes in the United States, as well as other tax jurisdictions or countries in which we conduct business. Earnings from our non-U.S. activities are subject to income taxes in local countries and may be subject to U.S. income taxes. Our effective tax rate differs from the U.S. statutory rate primarily due to foreign income subject to different tax rates than in the U.S., nondeductible stock-based compensation expense, federal research and development tax credit, state taxes, withholding taxes, excess tax benefits related to stock-based compensation expense and the tax impacts of the 2017 Tax Act.

[0001262039-20-000011:mdna:81]
Critical Accounting Policies and Estimates

[0001262039-20-000011:mdna:82]
Our discussion and analysis of our financial condition and results of operations are based upon our financial statements, which have been prepared in accordance with GAAP. These principles require us to make estimates and judgments that affect the reported amounts of assets, liabilities, revenue, cost of revenue and expenses, and related disclosures. We base our estimates on historical experience and on various other assumptions that we believe to be reasonable under the circumstances. To the extent that there are material differences between these estimates and our actual results, our future financial statements will be affected.

[0001262039-20-000011:mdna:83]
We believe that, of the significant accounting policies described in Note 1 to our consolidated financial statements included in Part II, Item 8 of this Annual Report on Form 10-K, the following accounting policies involve a greater degree of judgment and complexity. Accordingly, we believe these are the most critical to fully understand and evaluate our financial condition and results of operations.

[0001262039-20-000011:mdna:84]
Revenue Recognition

[0001262039-20-000011:mdna:85]
On January 1, 2018, we adopted Topic 606, Revenue from Contracts with Customers, using the modified retrospective method applied to those contracts which were not completed as of January 1, 2018. Results for reporting periods beginning after January 1, 2018 are presented under Topic 606, while prior period amounts are not adjusted and continue to be reported under ASC Topic 605 (“Topic 605”), Revenue Recognition.

[0001262039-20-000011:mdna:86]
Beginning in 2018, revenues are recognized when control of goods or services is transferred to our customers, in an amount that reflects the consideration we expect to be entitled to in exchange for those goods or services. Prior to 2018, revenue was recognized under Topic 605 when all of the following criteria were met: (i) persuasive evidence of an arrangement existed, (ii) delivery has occurred or services have been rendered, (iii) sales price was fixed or determinable and (iv) collectability was reasonably assured.

[0001262039-20-000011:mdna:87]
Under Topic 606, we determine revenue recognition through the following steps:

[0001262039-20-000011:mdna:88]
| • | identification of a contract or contracts with a customer; |

[0001262039-20-000011:mdna:89]
| • | identification of the performance obligations in a contract, including evaluation of performance obligations as to being distinct goods or services in a contract; |

[0001262039-20-000011:mdna:90]
| • | determination of a transaction price; |

[0001262039-20-000011:mdna:91]
| • | allocation of a transaction price to the performance obligations in a contract; and |

[0001262039-20-000011:mdna:92]
| • | recognition of revenue when, or as, we satisfy a performance obligation. |

[0001262039-20-000011:mdna:93]
Our sales contracts typically contain multiple deliverables, such as hardware, software license, security subscription, technical support services and other services, which are generally capable of being distinct and accounted for as separate performance obligations. We evaluated the criteria to be distinct under Topic 606 and concluded that the hardware and software licenses were distinct and distinct in the context of a contract from the security subscription and technical support services, as a customer can benefit from the hardware and software licenses without the services and the services are separately identifiable within a contract. We allocate a transaction price to each performance obligation based on relative standalone selling price. If not observable through past transactions, we determine standalone selling price based on the historical pricing and discounting practices for those services when sold separately. We determine standalone selling price for a product or service by considering multiple historical factors including, but not limited to, cost of products, gross margin objectives, pricing practices, geographies and the term of a service contract that fall within a reasonably range as a percentage of list price.

[0001262039-20-000011:mdna:94]
Under the previous standard, Topic 605, revenue from contracts that contain products and services is allocated to each unit of accounting based on an estimated selling price using vendor-specific objective evidence (“VSOE”) of selling price, if it existed, or third-party evidence (“TPE”) of selling price. If neither VSOE nor TPE of selling price existed for a deliverable, we used our best estimate of selling price for that deliverable. For multiple-element arrangements where software deliverables were included, revenue was allocated to the non-software deliverables and to the software deliverables as a group using the relative estimated selling prices of each of the deliverables in an arrangement based on the estimated selling price hierarchy. The amount allocated to the software deliverables was then allocated to each software deliverable using the residual method when VSOE of fair value existed. If evidence of VSOE of fair value of one or more undelivered elements did not exist, all software allocated revenue was deferred and recognized when delivery of those elements occurred or when fair value was established. When the undelivered element for which we did not have VSOE of fair value was support, revenue for the entire arrangement was recognized ratably over the support period. The same residual method and VSOE of fair value principles applied for our multiple element arrangements that contained only software elements.

[0001262039-20-000011:mdna:95]
Deferred Contract Costs and Commission Expense

[0001262039-20-000011:mdna:96]
Beginning in 2018, we recognized commission expense based on Topic 606’s guidance for contract costs. Under this new guidance, we recognize sales commissions related to product sales upfront while sales commissions for service contracts are deferred as deferred contract costs in the consolidated balance sheets and amortized over the applicable amortization period. Costs for initial contracts that are not commensurate with renewal commissions are amortized on a straight-line basis over the period of benefit, which we have determined to be five years and which is typically longer than the initial contract term. Significant estimates, assumptions, and judgments in accounting for deferred contract costs include, but are not limited to, identification of contract costs, anticipated billings and the expected period of benefit.

[0001262039-20-000011:mdna:97]
Valuation of Inventory

[0001262039-20-000011:mdna:98]
Inventory is recorded at the lower of cost or net realizable value. Cost is computed using the first-in, first-out method. In assessing the ultimate recoverability of inventory, we make estimates regarding future customer demand, the timing of new product introductions, economic trends and market conditions. If the actual product demand is significantly lower than forecasted, we could be required to record inventory write-downs which would be charged to cost of product revenue. Any write-downs could have an adverse impact on our gross margins and profitability.

[0001262039-20-000011:mdna:99]
Business Combinations

[0001262039-20-000011:mdna:100]
We include the results of operations of the businesses that we acquire as of the respective dates of acquisition. We allocate the fair value of the purchase price of our business acquisitions to the tangible and intangible assets acquired and liabilities assumed based on their estimated fair values. The excess of the purchase price over the fair values of these identifiable assets and liabilities is recorded as goodwill. We often continue to gather additional information throughout the measurement period, and if we make changes to the amounts recorded, such changes are recorded in the period in which they are identified.

[0001262039-20-000011:mdna:101]
Contingent Liabilities

[0001262039-20-000011:mdna:102]
From time to time, we are involved in disputes, litigation and other legal actions. However, there are many uncertainties associated with any litigation, and these actions or other third-party claims against us may cause us to incur substantial settlement charges, which are inherently difficult to estimate and could adversely affect our results of operations. We review significant new claims and litigation for the probability of an adverse outcome. Estimates can change as individual

[0001262039-20-000011:mdna:103]
claims develop. The actual liability in any such matters may be materially different from our estimates, which could result in the need to adjust our liability and record additional expenses.

[0001262039-20-000011:mdna:104]
Accounting for Income Taxes

[0001262039-20-000011:mdna:105]
We record income taxes using the asset and liability method, which requires the recognition of deferred tax assets and liabilities for the expected future tax consequences of events that have been recognized in our financial statements or tax returns. In addition, deferred tax assets are recorded for the future benefit of utilizing net operating losses and research and development credit carryforwards. Deferred tax assets and liabilities are measured using the currently enacted tax rates that apply to taxable income in effect for the years in which those tax assets and liabilities are expected to be realized or settled. Valuation allowances are provided when necessary to reduce deferred tax assets to the amount expected to be realized.

[0001262039-20-000011:mdna:106]
We recognize tax benefits from an uncertain tax position only if it is more likely than not, based on the technical merits of the position that the tax position will be sustained on examination by the tax authorities. The tax benefits recognized in the financial statements from such positions are then measured based on the largest benefit that has a greater than 50% likelihood of being realized upon ultimate settlement.

[0001262039-20-000011:mdna:107]
Effective January 1, 2018, the 2017 Tax Act reduced the federal corporate income tax rate from 35% to 21% and created a territorial tax system with a one-time transition tax on foreign earnings of U.S. subsidiaries not previously subject to U.S. income tax. Our selection of an accounting policy for 2018 with respect to the Global Intangible Low-Taxed Income (“GILTI”) tax rules was to treat GILTI tax as a current period expense under the period cost method. For 2019, we were not subject to GILTI. We will continue to monitor and assess the impact of the 2017 Tax Act and ongoing guidance and accounting interpretations issued in response to the 2017 Tax Act.

[0001262039-20-000011:mdna:108]
As part of the process of preparing our consolidated financial statements, we are required to estimate our taxes in each of the jurisdictions in which we operate. We estimate actual current tax exposure together with assessing temporary differences resulting from differing treatment of items, such as accruals and allowances not currently deductible for tax purposes. These differences result in deferred tax assets, which are included in our consolidated balance sheets. In general, deferred tax assets represent future tax benefits to be received when certain expenses previously recognized in our consolidated statements of income become deductible expenses under applicable income tax laws, or loss or credit carryforwards are utilized.

[0001262039-20-000011:mdna:109]
In assessing the realizability of deferred tax assets, management considers whether it is more likely than not that some portion or all of the deferred tax assets will be realized. The ultimate realization of deferred tax assets is dependent upon the generation of future taxable income during the periods in which those temporary differences become deductible. We continue to assess the need for a valuation allowance on the deferred tax assets by evaluating both positive and negative evidence that may exist. Any adjustment to the valuation allowance on deferred tax assets would be recorded in the consolidated statements of income for the period that the adjustment is determined to be required.

[0001262039-20-000011:mdna:110]
Results of Operations

[0001262039-20-000011:mdna:111]
The following tables set forth our results of operations for the periods presented and as a percentage of our total revenue for those periods. The period-to-period comparison of financial results is not necessarily indicative of financial results to be achieved in future periods.

[0001262039-20-000011:mdna:112]
|  | Year Ended December 31, |
|  | 2019 |  | 2018 |  | 2017 |
|  | (in millions) |
| Consolidated Statements of Income Data: |  |  |  |  |  |
| Revenue: |  |  |  |  |  |
| Product | $ | 788.5 |  |  | $ | 674.4 |  |  | $ | 577.2 |  |
| Service | 1,367.7 |  |  | 1,126.8 |  |  | 917.7 |  |
| Total revenue | 2,156.2 |  |  | 1,801.2 |  |  | 1,494.9 |  |
| Cost of revenue: |  |  |  |  |  |
| Product | 324.6 |  |  | 291.0 |  |  | 243.8 |  |
| Service | 181.3 |  |  | 159.4 |  |  | 141.5 |  |
| Total cost of revenue | 505.9 |  |  | 450.4 |  |  | 385.3 |  |
| Gross profit: |  |  |  |  |  |
| Product | 463.9 |  |  | 383.4 |  |  | 333.4 |  |
| Service | 1,186.4 |  |  | 967.4 |  |  | 776.2 |  |
| Total gross profit | 1,650.3 |  |  | 1,350.8 |  |  | 1,109.6 |  |
| Operating expenses: |  |  |  |  |  |
| Research and development | 277.1 |  |  | 244.5 |  |  | 210.6 |  |
| Sales and marketing | 926.9 |  |  | 782.3 |  |  | 701.0 |  |
| General and administrative | 102.1 |  |  | 93.0 |  |  | 87.9 |  |
| Restructuring charges | — |  |  | — |  |  | 0.3 |  |
| Total operating expenses | 1,306.1 |  |  | 1,119.8 |  |  | 999.8 |  |
| Operating income | 344.2 |  |  | 231.0 |  |  | 109.8 |  |
| Interest income—net | 42.5 |  |  | 26.5 |  |  | 13.5 |  |
| Other income (expense)—net | (7.5 | ) |  | (6.6 | ) |  | 0.7 |  |
| Income before income taxes | 379.2 |  |  | 250.9 |  |  | 124.0 |  |
| Provision for (benefit from) income taxes | 52.7 |  |  | (81.3 | ) |  | 92.6 |  |
| Net income | $ | 326.5 |  |  | $ | 332.2 |  |  | $ | 31.4 |  |

[0001262039-20-000011:mdna:113]
52

[0001262039-20-000011:mdna:114]
|  | Year Ended December 31, |
| 2019 |  | 2018 |  | 2017 |
| (as percentage of revenue) |
| Revenue: |  |  |  |  |  |
| Product | 37 | % |  | 37 | % |  | 39 | % |
| Service | 63 |  |  | 63 |  |  | 61 |  |
| Total revenue | 100 |  |  | 100 |  |  | 100 |  |
| Cost of revenue: |  |  |  |  |  |
| Product | 15 |  |  | 16 |  |  | 16 |  |
| Service | 8 |  |  | 9 |  |  | 9 |  |
| Total cost of revenue | 23 |  |  | 25 |  |  | 26 |  |
| Gross margin: |  |  |  |  |  |
| Product | 59 |  |  | 57 |  |  | 58 |  |
| Service | 87 |  |  | 86 |  |  | 85 |  |
| Total gross margin | 77 |  |  | 75 |  |  | 74 |  |
| Operating expenses: |  |  |  |  |  |
| Research and development | 13 |  |  | 14 |  |  | 14 |  |
| Sales and marketing | 43 |  |  | 43 |  |  | 47 |  |
| General and administrative | 5 |  |  | 5 |  |  | 6 |  |
| Restructuring charges | — |  |  | — |  |  | — |  |
| Total operating expenses | 61 |  |  | 62 |  |  | 67 |  |
| Operating margin | 16 |  |  | 13 |  |  | 7 |  |
| Interest income—net | 2 |  |  | 1 |  |  | 1 |  |
| Other income (expense)—net | — |  |  | — |  |  | — |  |
| Income before income taxes | 18 |  |  | 14 |  |  | 8 |  |
| Provision for (benefit from) income taxes | 2 |  |  | (5 | ) |  | 6 |  |
| Net income | 15 | % |  | 18 | % |  | 2 | % |

[0001262039-20-000011:mdna:115]
Percentages have been rounded for presentation purposes and may differ from unrounded results.

[0001262039-20-000011:mdna:116]
Discussion regarding our financial condition and results of operations for 2018 as compared to 2017 can be found in Item 7 of our Annual Report on Form 10-K for the fiscal year ended December 31, 2018, filed with the SEC on February 27, 2019.

[0001262039-20-000011:mdna:117]
2019 and 2018

[0001262039-20-000011:mdna:118]
Revenue

[0001262039-20-000011:mdna:119]
|  | Year Ended December 31, |  |  |  |  |
| 2019 |  | 2018 |  |  |  |  |
| Amount |  | % ofRevenue |  | Amount |  | % ofRevenue |  | Change |  | % Change |
| (in millions, except percentages) |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 788.5 |  |  | 37 | % |  | $ | 674.4 |  |  | 37 | % |  | $ | 114.1 |  |  | 17 | % |
| Service | 1,367.7 |  |  | 63 |  |  | 1,126.8 |  |  | 63 |  |  | 240.9 |  |  | 21 |  |
| Total revenue | $ | 2,156.2 |  |  | 100 | % |  | $ | 1,801.2 |  |  | 100 | % |  | $ | 355.0 |  |  | 20 | % |
| Revenue by geography: |  |  |  |  |  |  |  |  |  |  |  |
| Americas | $ | 917.3 |  |  | 42 | % |  | $ | 762.9 |  |  | 42 | % |  | $ | 154.4 |  |  | 20 | % |
| Europe, Middle East and Africa (“EMEA”) | 813.9 |  |  | 38 |  |  | 678.0 |  |  | 38 |  |  | 135.9 |  |  | 20 |  |
| Asia Pacific (“APAC”) | 425.0 |  |  | 20 |  |  | 360.3 |  |  | 20 |  |  | 64.7 |  |  | 18 |  |
| Total revenue | $ | 2,156.2 |  |  | 100 | % |  | $ | 1,801.2 |  |  | 100 | % |  | $ | 355.0 |  |  | 20 | % |

[0001262039-20-000011:mdna:120]
Total revenue increased by $355.0 million, or 20%, in 2019 compared to 2018. We continued to experience diversification of revenue globally, and across both customer and industry segments. Revenue from all regions grew, with the Americas contributing the largest portion of our revenue growth on an absolute dollar basis.

[0001262039-20-000011:mdna:121]
Product revenue increased by $114.1 million, or 17%, in 2019 compared to 2018. We experienced revenue growth across many of our hardware and software products due to an increase in product revenue from our SD-WAN FortiGate solutions and growth in sales of our Infrastructure Security solutions.

[0001262039-20-000011:mdna:122]
Service revenue increased by $240.9 million, or 21%, in 2019 compared to 2018. FortiGuard security subscription and FortiCare technical support and other revenues increased by $144.8 million, or 24%, and by $96.1 million, or 18%, respectively, in 2019 compared to 2018. The increases were primarily due to the recognition of revenue from our growing deferred revenue balance related to FortiGuard and other security subscriptions and FortiCare technical support and other contracts. Of the service revenue recognized in 2019, 68% was included in the deferred revenue balance as of December 31, 2018. Of the service revenue recognized in 2018, 67% was included in the deferred revenue balance as of December 31, 2017.

[0001262039-20-000011:mdna:123]
Cost of revenue and gross margin

[0001262039-20-000011:mdna:124]
|  | Year Ended December 31, |  |  |  |  |
| 2019 |  | 2018 |  | Change |  | % Change |
| (in millions, except percentages) |
| Cost of revenue: |  |  |  |  |  |  |  |
| Product | $ | 324.6 |  |  | $ | 291.0 |  |  | $ | 33.6 |  |  | 12 | % |
| Service | 181.3 |  |  | 159.4 |  |  | 21.9 |  |  | 14 |  |
| Total cost of revenue | $ | 505.9 |  |  | $ | 450.4 |  |  | $ | 55.5 |  |  | 12 | % |
| Gross margin (%): |  |  |  |  |  |  |  |
| Product | 58.8 | % |  | 56.9 | % |  |  |  |  |  |
| Service | 86.7 |  |  | 85.9 |  |  |  |  |  |  |
| Total gross margin | 76.5 | % |  | 75.0 | % |  |  |  |  |  |

[0001262039-20-000011:mdna:125]
Total gross margin increased by 1.5 percentage points in 2019 compared to 2018, driven by improvements to both product and service gross margins. Product gross margin increased by 1.9 percentage points in 2019 compared to 2018. Product gross margin benefited from gains in average selling price, as well as lower direct and indirect product costs as a percentage of product revenue. It also benefited from deal mix, software revenue growth and a stable product transition environment. Cost of

[0001262039-20-000011:mdna:126]
product revenue was comprised primarily of third-party contract manufacturers’ costs and the costs of materials used in production. Service gross margin increased by 0.8 percentage points in 2019 compared to 2018, as our service revenue growth outpaced our growth in related personnel costs. Cost of service revenue was comprised primarily of personnel costs.

[0001262039-20-000011:mdna:127]
Operating expenses

[0001262039-20-000011:mdna:128]
|  | Year Ended December 31, |  | Change |  | % Change |
| 2019 |  | 2018 |  |
| Amount |  | % ofRevenue |  | Amount |  | % ofRevenue |  |
| (in millions, except percentages) |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | $ | 277.1 |  |  | 13 | % |  | $ | 244.5 |  |  | 14 | % |  | $ | 32.6 |  |  | 13 | % |
| Sales and marketing | 926.9 |  |  | 43 |  |  | 782.3 |  |  | 43 |  |  | 144.6 |  |  | 18 |  |
| General and administrative | 102.1 |  |  | 5 |  |  | 93.0 |  |  | 5 |  |  | 9.1 |  |  | 10 |  |
| Total operating expenses | $ | 1,306.1 |  |  | 61 | % |  | $ | 1,119.8 |  |  | 62 | % |  | $ | 186.3 |  |  | 17 | % |

[0001262039-20-000011:mdna:129]
Research and development

[0001262039-20-000011:mdna:130]
Research and development expense increased by $32.6 million, or 13%, in 2019 compared to 2018, primarily due to an increase in personnel-related costs of $29.9 million as a result of increased headcount to support the development of new products and continued enhancements to our existing products. We intend to continue to invest in our research and development organization, and expect research and development expense to increase in absolute dollars in 2020.

[0001262039-20-000011:mdna:131]
Sales and marketing

[0001262039-20-000011:mdna:132]
Sales and marketing expense increased by $144.6 million, or 18%, in 2019 compared to 2018, primarily due to an increase in personnel-related costs of $103.9 million as a result of increases to sales and marketing headcount in order to drive global market share gains. In addition, marketing expenses increased by $16.8 million. We intend to continue to make investments in our sales resources and infrastructure and marketing strategy, which are critical to support growth, and expect sales and marketing expense to increase in absolute dollars in 2020.

[0001262039-20-000011:mdna:133]
General and administrative

[0001262039-20-000011:mdna:134]
General and administrative expense increased by $9.1 million, or 10%, in 2019 compared to 2018, primarily due to an increase in personnel-related costs of $6.1 million and an increase in litigation costs of $3.1 million. Certain facilities, depreciation, and information technology costs are allocated to other organizations based on headcount. We expect general and administrative expense to increase in absolute dollars in 2020.

[0001262039-20-000011:mdna:135]
Operating income and margin

[0001262039-20-000011:mdna:136]
We generated operating income of $344.2 million in 2019, an increase of $113.2 million, or 49%, compared to $231.0 million in 2018. Operating income as a percentage of revenue increased to 16% in 2019 compared to 13% in 2018. The increase in operating margin is primarily due to the improvement in gross margin by 1.5 percentage points. In addition, as a percent of total revenue, research and development expense decreased by 0.7 percentage points, sales and marketing expense decreased by 0.4 percentage points and general and administrative expense decreased by 0.4 percentage points.

[0001262039-20-000011:mdna:137]
Interest income—net and other expense—net

[0001262039-20-000011:mdna:138]
|  | Year Ended December 31, |  |  |  |  |
| 2019 |  | 2018 |  | Change |  | % Change |
| (in millions, except percentages) |
| Interest income—net | $ | 42.5 |  |  | $ | 26.5 |  |  | $ | 16.0 |  |  | 60 | % |
| Other expense—net | $ | (7.5 | ) |  | $ | (6.6 | ) |  | $ | (0.9 | ) |  | 14 | % |

[0001262039-20-000011:mdna:139]
Interest income—net increased in 2019 as compared to 2018, primarily due to higher interest rates and, to a lesser extent, higher invested balances of cash, cash equivalents and investments. Interest income—net varies depending on our average investment balances during the period, types and mix of investments, and market interest rates. The change in other expense—net in 2019 as compared to 2018 was the result of a $3.8 million impairment charge on an investment in a privately held company during 2019 compared to a $2.2 million gain on the sale of an investment in a privately held company in the same period last year, partially offset by $3.5 million decrease in foreign currency exchange losses.

[0001262039-20-000011:mdna:140]
Provision for (benefit from) income taxes

[0001262039-20-000011:mdna:141]
|  | Year Ended December 31, |  | Change |  | % Change |
| 2019 |  | 2018 |  |
| (in millions, except percentages) |
| Provision for (benefit from) income taxes | $ | 52.7 |  |  | $ | (81.3 | ) |  | $ | 134.0 |  |  | (165 | )% |
| Effective tax rate | 14 | % |  | (32 | )% |  |  |  |  |  |  |

[0001262039-20-000011:mdna:142]
Our provision for income taxes for 2019 reflects an effective tax rate of 14%, compared to an effective tax rate benefit of 32% for 2018. The provision for income taxes for 2019 was comprised primarily of an $88.8 million tax expense related to U.S. federal and state taxes, other foreign income taxes and foreign withholding taxes and a $10.1 million tax expense for an unrecognized tax benefit related to the Ninth Circuit’s opinion in Altera Corporation and Subsidiaries vs. Commissioner of Internal Revenue (“Altera”). The provision was partially offset by excess tax benefits of $39.3 million from stock-based compensation expense and tax benefits of $6.8 million from federal research and development tax credits.

[0001262039-20-000011:mdna:143]
In 2018, our effective tax rate benefit of 32% was comprised primarily of impacts related to the 2017 Tax Act, including a benefit of $164.0 million from the realignment of our tax structure and operations that resulted in a book-to-tax basis difference from previously taxed off-shore deferred revenue. These benefits were partially offset by a $32.6 million increase in the transition tax for finalization of the provisional estimates under Staff Accounting Bulletin No. 118, Income Tax Accounting Implications of the Tax Cuts and Jobs Act, $20.5 million of tax expense for the impact of the GILTI and $29.6 million of tax expense related to U.S. federal and state taxes, other foreign income taxes, foreign withholding taxes and a decrease in tax reserves.

[0001262039-20-000011:mdna:144]
Quarterly Results of Operations

[0001262039-20-000011:mdna:145]
The following table sets forth our unaudited quarterly statements of income data for the last eight quarters. The information for each of these quarters has been prepared on the same basis as the audited annual financial statements included elsewhere in this Annual Report and, in the opinion of management, includes all adjustments, which includes only normal recurring adjustments, necessary for the fair presentation of the results of operations for these periods. This data should be read in conjunction with our audited consolidated financial statements and related notes included elsewhere in this annual report. These quarterly operating results are not necessarily indicative of our operating results for any future period.

[0001262039-20-000011:mdna:146]
|  | Three Months Ended |
|  | Dec 31,2019 |  | Sept 30,2019 |  | Jun 30,2019 |  | Mar 31,2019 |  | Dec 31,2018 |  | Sept 30,2018 |  | Jun 30,2018 |  | Mar 31,2018 |
|  | (in millions, except per share amounts) |
| Consolidated Statements of Income Data: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 238.8 |  |  | $ | 197.1 |  |  | $ | 189.9 |  |  | $ | 162.7 |  |  | $ | 200.8 |  |  | $ | 164.5 |  |  | $ | 166.3 |  |  | $ | 142.8 |  |
| Service | 375.6 |  |  | 350.4 |  |  | 331.8 |  |  | 309.9 |  |  | 306.2 |  |  | 289.4 |  |  | 275.0 |  |  | 256.2 |  |
| Total revenue | 614.4 |  |  | 547.5 |  |  | 521.7 |  |  | 472.6 |  |  | 507.0 |  |  | 453.9 |  |  | 441.3 |  |  | 399.0 |  |
| Cost of revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product (1)(2) | 92.7 |  |  | 79.0 |  |  | 82.7 |  |  | 70.2 |  |  | 86.9 |  |  | 72.0 |  |  | 73.9 |  |  | 58.2 |  |
| Service (1)(2) | 47.8 |  |  | 45.1 |  |  | 45.6 |  |  | 42.8 |  |  | 41.6 |  |  | 39.6 |  |  | 39.2 |  |  | 39.0 |  |
| Total cost of revenue | 140.5 |  |  | 124.1 |  |  | 128.3 |  |  | 113.0 |  |  | 128.5 |  |  | 111.6 |  |  | 113.1 |  |  | 97.2 |  |
| Total gross profit | 473.9 |  |  | 423.4 |  |  | 393.4 |  |  | 359.6 |  |  | 378.5 |  |  | 342.3 |  |  | 328.2 |  |  | 301.8 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development (1) | 71.2 |  |  | 69.9 |  |  | 67.4 |  |  | 68.6 |  |  | 65.5 |  |  | 58.7 |  |  | 61.2 |  |  | 59.1 |  |
| Sales and marketing (1)(2) | 257.1 |  |  | 227.4 |  |  | 226.5 |  |  | 215.9 |  |  | 205.9 |  |  | 198.3 |  |  | 192.8 |  |  | 185.3 |  |
| General and administrative (1) | 27.2 |  |  | 26.1 |  |  | 24.3 |  |  | 24.5 |  |  | 22.0 |  |  | 22.5 |  |  | 23.5 |  |  | 25.0 |  |
| Total operating expenses | 355.5 |  |  | 323.4 |  |  | 318.2 |  |  | 309.0 |  |  | 293.4 |  |  | 279.5 |  |  | 277.5 |  |  | 269.4 |  |
| Operating income | 118.4 |  |  | 100.0 |  |  | 75.2 |  |  | 50.6 |  |  | 85.1 |  |  | 62.8 |  |  | 50.7 |  |  | 32.4 |  |
| Interest income—net | 9.9 |  |  | 11.4 |  |  | 11.0 |  |  | 10.2 |  |  | 9.3 |  |  | 6.9 |  |  | 5.8 |  |  | 4.5 |  |
| Other income (expense)—net | (0.6 | ) |  | (6.0 | ) |  | (0.4 | ) |  | (0.5 | ) |  | (2.3 | ) |  | 0.9 |  |  | (5.0 | ) |  | (0.2 | ) |
| Income before income taxes | 127.7 |  |  | 105.4 |  |  | 85.8 |  |  | 60.3 |  |  | 92.1 |  |  | 70.6 |  |  | 51.5 |  |  | 36.7 |  |
| Provision for (benefit from) income taxes | 12.5 |  |  | 25.6 |  |  | 13.1 |  |  | 1.5 |  |  | (90.5 | ) |  | 11.9 |  |  | 2.2 |  |  | (4.9 | ) |
| Net income | $ | 115.2 |  |  | $ | 79.8 |  |  | $ | 72.7 |  |  | $ | 58.8 |  |  | $ | 182.6 |  |  | $ | 58.7 |  |  | $ | 49.3 |  |  | $ | 41.6 |  |
| Net income per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic | $ | 0.67 |  |  | $ | 0.47 |  |  | $ | 0.42 |  |  | $ | 0.35 |  |  | $ | 1.07 |  |  | $ | 0.35 |  |  | $ | 0.29 |  |  | $ | 0.25 |  |
| Diluted | $ | 0.66 |  |  | $ | 0.46 |  |  | $ | 0.42 |  |  | $ | 0.34 |  |  | $ | 1.04 |  |  | $ | 0.33 |  |  | $ | 0.28 |  |  | $ | 0.24 |  |

[0001262039-20-000011:mdna:147]
(1) Includes stock-based compensation as follows:

[0001262039-20-000011:mdna:148]
|  | Three Months Ended |
|  | Dec 31,2019 |  | Sept 30,2019 |  | Jun 30,2019 |  | Mar 31,2019 |  | Dec 31,2018 |  | Sept 30,2018 |  | Jun 30,2018 |  | Mar 31,2018 |
|  | (in millions) |
| Cost of product revenue | $ | 0.3 |  |  | $ | 0.4 |  |  | $ | 0.4 |  |  | $ | 0.4 |  |  | $ | 0.4 |  |  | $ | 0.3 |  |  | $ | 0.4 |  |  | $ | 0.4 |  |
| Cost of service revenue | 2.9 |  |  | 2.7 |  |  | 2.9 |  |  | 2.8 |  |  | 2.8 |  |  | 2.8 |  |  | 2.7 |  |  | 2.5 |  |
| Research and development | 10.0 |  |  | 9.3 |  |  | 10.0 |  |  | 9.4 |  |  | 9.5 |  |  | 9.3 |  |  | 9.2 |  |  | 8.4 |  |
| Sales and marketing | 25.1 |  |  | 24.9 |  |  | 26.3 |  |  | 25.4 |  |  | 25.1 |  |  | 26.0 |  |  | 23.6 |  |  | 20.9 |  |
| General and administrative | 5.4 |  |  | 5.1 |  |  | 5.4 |  |  | 5.0 |  |  | 4.8 |  |  | 4.8 |  |  | 4.7 |  |  | 4.3 |  |
| Total stock-based compensation expense | $ | 43.7 |  |  | $ | 42.4 |  |  | $ | 45.0 |  |  | $ | 43.0 |  |  | $ | 42.6 |  |  | $ | 43.2 |  |  | $ | 40.6 |  |  | $ | 36.5 |  |

[0001262039-20-000011:mdna:149]
57

[0001262039-20-000011:mdna:150]
(2) Total amortization included in product costs, service costs, and sales and marketing expense are as follows:

[0001262039-20-000011:mdna:151]
|  | Three Months Ended |
|  | Dec 31,2019 |  | Sept 30,2019 |  | Jun 30,2019 |  | Mar 31,2019 |  | Dec 31,2018 |  | Sept 30,2018 |  | Jun 30,2018 |  | Mar 31,2018 |
|  | (in millions) |
| Amortization of intangible assets | $ | 2.8 |  |  | $ | 2.2 |  |  | $ | 2.9 |  |  | $ | 3.0 |  |  | $ | 2.9 |  |  | $ | 2.5 |  |  | $ | 1.8 |  |  | $ | 1.8 |  |

[0001262039-20-000011:mdna:152]
Seasonality, Cyclicality and Quarterly Revenue Trends

[0001262039-20-000011:mdna:153]
Our quarterly results reflect a pattern of increased customer buying at year-end, which has positively impacted billings and product revenue activity in the fourth quarter. In the first quarter, we generally experience lower sequential customer buying, followed by an increase in buying in the second quarter. The third quarter is often consistent with the second quarter. Although these seasonal factors are common in the technology sector, historical patterns should not be considered a reliable indicator of our future sales activity or performance. On a quarterly basis, we have usually generated the majority of our product revenue in the final month of each quarter and a significant amount in the last two weeks of each quarter. We believe this is due to customer buying patterns typical in this industry.

[0001262039-20-000011:mdna:154]
Consistent with the seasonality note above, our total quarterly revenue over the past eight quarters has generally increased sequentially in each quarter, except in the first quarter of 2019 and 2018. Product revenue, in each quarter in 2019, increased as compared to the same quarter in 2018, which we believe was due to investments we made in our sales and marketing organizations, continued product innovation and a robust security market. We continue to see a shift from product revenue to higher-margin, recurring service revenue.

[0001262039-20-000011:mdna:155]
Total gross margin has fluctuated on a quarterly basis primarily due to seasonality of product sales and seasonality of cost increases. Product gross margin varies based on the types of products sold and the average selling prices of our products. In 2019, product gross margin was impacted by new product introductions and the mix of high-end, mid-range and entry-level products. Service gross margin benefited from the growth of our customer base and renewals.

[0001262039-20-000011:mdna:156]
Liquidity and Capital Resources

[0001262039-20-000011:mdna:157]
|  | As of December 31, |
|  | 2019 |  | 2018 |  | 2017 |
|  | (in millions) |
| Cash and cash equivalents | $ | 1,222.5 |  |  | $ | 1,112.4 |  |  | $ | 811.0 |  |
| Investments | 987.4 |  |  | 604.2 |  |  | 538.3 |  |
| Total cash, cash equivalents and investments | $ | 2,209.9 |  |  | $ | 1,716.6 |  |  | $ | 1,349.3 |  |
| Working capital | $ | 1,295.4 |  |  | $ | 964.5 |  |  | $ | 689.6 |  |
|  | Year Ended December 31, |
|  | 2019 |  | 2018 |  | 2017 |
|  | (in millions) |
| Net cash provided by operating activities | $ | 808.0 |  |  | $ | 638.9 |  |  | $ | 594.4 |  |
| Net cash used in investing activities | (502.3 | ) |  | (134.9 | ) |  | (76.8 | ) |
| Net cash used in financing activities | (195.6 | ) |  | (202.6 | ) |  | (415.6 | ) |
| Net increase in cash and cash equivalents | $ | 110.1 |  |  | $ | 301.4 |  |  | $ | 102.0 |  |

[0001262039-20-000011:mdna:158]
Liquidity and capital resources may be impacted by our operating activities, as well as by our stock repurchases, proceeds associated with stock option exercises, issuances of common stock under our equity incentive plans and payment of taxes in connection with the net settlement of equity awards, real estate and other capital expenditures and business acquisitions.

[0001262039-20-000011:mdna:159]
In recent years, we have received significant capital resources from billings, the exercise of stock options and our Employee Stock Purchase Plan (“ESPP”) purchases. Additional increases in billings may depend on a number of factors, including demand for our products and services, competition, market or industry changes, and our ability to execute. We expect

[0001262039-20-000011:mdna:160]
58

[0001262039-20-000011:mdna:161]
proceeds from the exercise of stock options in future years to be impacted by the increased mix of restricted stock units versus stock options granted and also to vary based on our share price. There will not be future proceeds from purchases under our ESPP, which was terminated in February 2019. As of December 31, 2019, $1.6 billion remained available for future share repurchases under the Repurchase Program.

[0001262039-20-000011:mdna:162]
Construction of a second building at our headquarters campus started in the fourth quarter of 2018 and related spending will continue in 2020 and until project completion. We estimate 2020 real estate spending, including the headquarters campus project, to be between $150.0 million and $160.0 million dollars.

[0001262039-20-000011:mdna:163]
As of December 31, 2019, our cash, cash equivalents and investments of $2.21 billion were invested primarily in deposit accounts, money market funds, corporate debt securities, commercial paper, certificates of deposit and term deposits and U.S. government and agency securities. It is our investment policy to invest excess cash in a manner that preserves capital, provides liquidity and generates return without significantly increasing risk. We do not enter into investments for trading or speculative purposes.

[0001262039-20-000011:mdna:164]
The amount of cash, cash equivalents and investments held by our international subsidiaries was $109.3 million as of December 31, 2019 and $956.6 million as of December 31, 2018. The decrease in cash, cash equivalents and investments held by our international subsidiaries related to changes in our international tax structure.

[0001262039-20-000011:mdna:165]
We believe that our existing cash and cash equivalents will be sufficient to meet our anticipated cash needs for at least the next 12 months. Our future capital requirements will depend on many factors, including our growth rate, the timing and amount of our share repurchases, the timing and extent of spending to support development efforts, the expansion of sales and marketing activities, the introduction of new and enhanced products and services offerings, the continuing market acceptance of our products and our investments in purchasing or leasing real estate. Historically, we have required capital principally to fund our working capital needs, share repurchases, capital expenditures and acquisition activities. In the event that additional financing is required from outside sources, we may not be able to raise it on terms acceptable to us or at all.

[0001262039-20-000011:mdna:166]
Operating Activities

[0001262039-20-000011:mdna:167]
Cash generated by operating activities is our primary source of liquidity. It is primarily comprised of net income, as adjusted for non-cash items and changes in operating assets and liabilities. Non-cash adjustments consist primarily of stock-based compensation, amortization of deferred contract costs and depreciation and amortization. Changes in operating assets and liabilities consist primarily of changes in deferred revenue, deferred contract costs, accounts receivable and inventory.

[0001262039-20-000011:mdna:168]
Our operating activities during 2019 provided $808.0 million in cash as a result of the continued growth of our business and our ability to successfully manage our working capital. Changes in operating assets and liabilities primarily resulted from an increase in sales of our FortiGuard security subscription and FortiCare technical support services to new and existing customers, as reflected by an increase in our deferred revenue. Our total deferred revenue balance grew $449.1 million, or 27%, during 2019.

[0001262039-20-000011:mdna:169]
Our operating activities during 2018 provided $638.9 million in cash as a result of the continued growth of our business and our ability to successfully manage our working capital. Changes in operating assets and liabilities primarily resulted from an increase in sales of our FortiGuard security subscription and FortiCare technical support services to new and existing customers, as reflected by an increase in our deferred revenue. Our total deferred revenue balance as of December 31, 2018 of $1.69 billion represented a 26% increase year over year.

[0001262039-20-000011:mdna:170]
Investing Activities

[0001262039-20-000011:mdna:171]
The changes in cash flows from investing activities primarily relate to timing of purchases, maturities and sales of investments and purchases of property and equipment. Historically, in making a lease versus purchase decision related to our larger facilities, we have considered various factors including financial metrics and the impact on our employees. In certain cases, we have elected to purchase the facility if we believed that purchasing rather than leasing is more in line with our long-term strategy. We expect to make similar decisions in the future. We may also make cash payments in connection with future business combinations.

[0001262039-20-000011:mdna:172]
During 2019, cash used in investing activities was primarily driven by $375.5 million expended on purchases of investments, net of maturities and sales of investments, $92.2 million spent on purchases of property and equipment and $34.6 million used for the acquisitions of enSilo and CyberSponse, net of cash acquired.

[0001262039-20-000011:mdna:173]
59

[0001262039-20-000011:mdna:174]
During 2018, cash used in investing activities was primarily due to $60.2 million spent for purchases of our investments, net of maturities and sales of investments, $53.0 million spent on capital expenditures and $21.7 million used for the acquisitions of Bradford Networks, Inc. and ZoneFox Limited, net of cash acquired.

[0001262039-20-000011:mdna:175]
Financing Activities

[0001262039-20-000011:mdna:176]
The changes in cash flows from financing activities primarily relate to repurchase and retirement of common stock, proceeds from the issuance of common stock under our equity incentive plans, taxes paid related to net share settlement of equity awards and payments of debt assumed in business combinations.

[0001262039-20-000011:mdna:177]
During 2019, cash used in financing activities was $195.6 million, primarily due to $145.1 million used to repurchase shares of our common stock, $46.5 million used to pay tax withholding, net of proceeds, from the issuance of common stock and $3.7 million of payments of the debt assumed in business combinations.

[0001262039-20-000011:mdna:178]
During 2018, cash used in financing activities was $202.6 million, primarily due to $211.8 million used to repurchase shares of our common stock and $10.1 million of payments of the debt assumed in business combinations. This was partially offset by $19.3 million of proceeds from the issuance of common stock, net of tax withholding.

[0001262039-20-000011:mdna:179]
Contractual Obligations and Commitments

[0001262039-20-000011:mdna:180]
The following summarizes our inventory purchase commitments as of December 31, 2019:

[0001262039-20-000011:mdna:181]
|  | Payments Due by Period |
|  | Total |  | Less than 1 year |  | 1 - 3 years |  | 3 - 5 years |  | More than 5 years |
|  | (in millions) |
| Inventory purchase commitments (1) | $ | 231.9 |  |  | $ | 231.9 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |

[0001262039-20-000011:mdna:182]
| (1) | Consists of minimum purchase commitments with independent contract manufacturers. |

[0001262039-20-000011:mdna:183]
In addition to commitments with contract manufacturers, we have open purchase orders and contractual obligations in the ordinary course of business for which we have not received goods or services. As of December 31, 2019, we had $12.8 million in other contractual commitments having a remaining term in excess of one year that may not be cancelable.

[0001262039-20-000011:mdna:184]
As of December 31, 2019, we had $82.8 million of long-term income tax liabilities, including interest, related to uncertain tax positions. Because of the high degree of uncertainty regarding the settlement of these liabilities, we are unable to estimate the years in which future cash outflows may occur.

[0001262039-20-000011:mdna:185]
Off-Balance Sheet Arrangements

[0001262039-20-000011:mdna:186]
During 2019, 2018 and 2017, we did not have any relationships with unconsolidated organizations or financial partnerships, such as structured finance or special purpose entities that would have been established for the purpose of facilitating off-balance sheet arrangements or other contractually narrow or limited purposes.

[0001262039-20-000011:mdna:187]
Recent Accounting Pronouncements

[0001262039-20-000011:mdna:188]
See Note 1 of the notes to our consolidated financial statements in Part II, Item 8 of this Annual Report on Form 10-K for a full description of recently adopted accounting pronouncements.
