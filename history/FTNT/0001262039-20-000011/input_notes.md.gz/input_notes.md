# FTNT notes — 0001262039-20-000011


## dei:DocumentsIncorporatedByReferenceTextBlock

[0001262039-20-000011:notes:1]
Portions of the registrant’s definitive Proxy Statement relating to its 2020 Annual Meeting of Stockholders are incorporated by reference into Part III of this Annual Report on Form 10-K where indicated. Such Proxy Statement will be filed with the United States Securities and Exchange Commission within 120 days after the end of the fiscal year to which this report relates


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001262039-20-000011:notes:2]
SUMMARY OF SIGNIFICANT ACCOUNTING POLICIES

[0001262039-20-000011:notes:3]
Business—Fortinet, Inc. (“Fortinet”) was incorporated in Delaware in November 2000 and is a global leader in broad, integrated and automated cybersecurity solutions. Fortinet provides high performance cybersecurity solutions to a wide variety of businesses, such as enterprises, communication service providers and small businesses. Fortinet’s cybersecurity solutions are designed to provide broad visibility and segmentation of the digital attack surface, through our integrated Security Fabric Platform with automated protection, detection and responses.

[0001262039-20-000011:notes:4]
Basis of Presentation and Preparation—The consolidated financial statements of Fortinet and its wholly owned subsidiaries (collectively, the “Company,” “we,” “us” or “our”) have been prepared in accordance with generally accepted accounting principles in the United States (“GAAP”). All intercompany transactions and balances have been eliminated in consolidation.

[0001262039-20-000011:notes:5]
Use of Estimates—The preparation of consolidated financial statements in accordance with GAAP requires management to make estimates and assumptions that affect the amounts reported in the consolidated financial statements and accompanying notes. Such management estimates include, but are not limited to, the standalone selling price for each distinct performance obligation included in customer contracts with multiple performance obligations, the period of benefit for deferred contract costs for commissions, stock-based compensation, inventory valuation, the fair value of assets acquired and liabilities assumed in business combinations, the measurement of liabilities for uncertain tax positions and deferred tax assets and liabilities, the assessment of recoverability of our goodwill and other long-lived assets, the determination of sales returns reserves and contingent liabilities. We base our estimates on historical experience and also on assumptions that we believe are reasonable. Actual results could differ from those estimates.

[0001262039-20-000011:notes:6]
Concentration Risk—Financial instruments that subject us to concentrations of credit risk consist primarily of cash, cash equivalents, short-term and long-term investments and accounts receivable. Our cash balances are maintained as deposits with various large financial institutions in the United States and around the world. Balances in the United States typically exceed the amount of insurance provided on such deposits. We maintain our cash equivalents and investments in money market funds, commercial paper and fixed income securities with major financial institutions that our management believes are financially sound.

[0001262039-20-000011:notes:7]
Our accounts receivables are primarily derived from our channel partners in various geographic locations. We perform ongoing credit evaluations of our customers. We generally do not require collateral on accounts receivable, and we maintain reserves for estimated potential credit losses. As of December 31, 2019 and 2018, Exclusive Networks Group (“Exclusive”) accounted for 36% and 38% of total net accounts receivable, respectively. As of December 31, 2019, Ingram Micro Inc. (“Ingram Micro”) accounted for 10% of total net accounts receivable.

[0001262039-20-000011:notes:8]
During 2019, Exclusive and Ingram Micro accounted for 31% and 11% of total revenue, respectively. During 2018, Exclusive and Ingram Micro accounted for 30% and 10% of total revenue, respectively. During 2017, Exclusive accounted for 25% of total revenue.

[0001262039-20-000011:notes:9]
We rely on a small number of manufacturing partners, primarily in Taiwan but also in China and the United States, to manufacture our products, and some of the components of our products are available from limited or sole sources of supply. Each of our proprietary Application-Specific Integrated Circuits is built by a sole contract manufacturer.

[0001262039-20-000011:notes:10]
Financial Instruments and Fair Value—We define fair value as the price that would be received from selling an asset, or paid to transfer a liability, in an orderly transaction between market participants at the measurement date. When determining the fair value measurements for assets and liabilities which are required to be recorded at fair value, we consider the principal or most advantageous market in which to transact and the market-based risk. We apply fair value accounting for all financial assets and liabilities and non-financial assets and liabilities that are recognized or disclosed at fair value in the financial statements on a recurring basis. Due to their short-term nature, the carrying amounts reported in the consolidated financial statements approximate the fair value for cash and cash equivalents, accounts receivable, accounts payable, accrued liabilities, and accrued payroll and compensation.

[0001262039-20-000011:notes:11]
Comprehensive Income—Comprehensive income includes certain changes in equity from non-owner sources that are excluded from net income, specifically, unrealized gains and losses on available-for-sale investments and the related tax impact.

[0001262039-20-000011:notes:12]
Foreign Currency and Transaction Gains and Losses—The functional currency of our foreign subsidiaries is the U.S. dollar. Accordingly, monetary assets and liabilities denominated in foreign currencies have been remeasured into U.S. dollars using the exchange rates in effect at the balance sheet dates. Foreign currency denominated income and expenses have been remeasured using the exchange rates in effect during each period. Foreign currency remeasurement gains (losses) of $(4.7) million, $(8.2) million and $1.0 million are included in other income (expense)—net for 2019, 2018 and 2017, respectively.

[0001262039-20-000011:notes:13]
Cash, Cash Equivalents and Available-for-Sale Investments—We consider all highly liquid investments, purchased with original maturities of three months or less, to be cash equivalents. Cash and cash equivalents consist of balances with banks and highly liquid investments in money market funds, commercial paper, term deposits and corporate debt.

[0001262039-20-000011:notes:14]
We classify our investments as available-for-sale at the time of purchase, since it is our intent that these investments are available for current operations. Investments with original maturities greater than three months that mature less than one year from the consolidated balance sheet date are classified as short-term investments. Investments with maturities greater than one year from the consolidated balance sheet date are classified as long-term investments.

[0001262039-20-000011:notes:15]
An investment is impaired if the fair value of the investment is less than its cost. If the fair value of an investment is less than its amortized cost basis at the balance sheet date and if we do not intend to sell the investment, we consider available evidence to assess whether it more likely than not that we will be required to sell the investment before the recovery of its amortized cost basis. We consult with our investment managers and consider available quantitative and qualitative evidence in evaluating, among other factors, general market conditions, the duration and extent to which the fair value is less than cost, and our ability to hold the investment.

[0001262039-20-000011:notes:16]
Once an impairment is determined to be other-than-temporary, an impairment charge is recorded and a new cost basis in the investment is established. The difference between the investment’s then-current amortized cost basis and fair value is separated into (i) the amount of the impairment related to the credit loss (i.e., the credit loss component) and (ii) the amount of the impairment related to all other factors (i.e., the non-credit loss component). The credit loss component is recognized in earnings. The non-credit loss component is recognized in accumulated other comprehensive income (loss).

[0001262039-20-000011:notes:17]
Inventory—Inventory is recorded at the lower of cost or net realizable value. Cost is computed using the first-in, first-out method. In assessing the ultimate recoverability of inventory, we make estimates regarding future customer demand, the timing of new product introductions, economic trends and market conditions. If the actual product demand is significantly lower than forecasted, we could be required to record inventory write-downs which would be charged to cost of product revenue.

[0001262039-20-000011:notes:18]
Property and Equipment—Property and equipment are stated at cost less accumulated depreciation. Depreciation is computed using the straight-line method over the estimated useful lives of the assets as follows:

[0001262039-20-000011:notes:19]
|  | Estimated Useful Lives |
| Building and building improvements | 2 to 30 years |
| Computer equipment and software | 1 to 7 years |
| Evaluation units | 1 year |
| Furniture and fixtures | 3 to 5 years |
| Leasehold improvements | Shorter of useful life or lease term |

[0001262039-20-000011:notes:20]
Other Investments—Investments in privately held companies where we own less than 20% of the voting stock and have no indicators of significant influence over operating and financial policies of those companies are included in other assets in the consolidated balance sheets. As of December 31, 2017, these investments were accounted for under the cost method. As of December 31, 2018, with the adoption of the Accounting Standards Update (“ASU”) 2016-01—Financial Instruments—Overall (Subtopic 825-10): Recognition and Measurement of Financial Assets and Financial Liabilities, these investments are accounted for at cost, adjusted for changes in observable prices minus impairment. Adoption of ASU 2016-01 did not have an impact on our consolidated financial statements. For these non-quoted investments, we regularly review the assumptions underlying the operating performance and cash flow forecasts as well as current fundraising activities and valuations based on information provided by these privately held companies. If it is determined that an other-than-temporary decline or increase in

[0001262039-20-000011:notes:21]
value exists in an investment without readily determinable value, we adjust the value of the investment to its fair value and record the related impairment or increase in value as an investment loss or gain in our consolidated statements of income.

[0001262039-20-000011:notes:22]
Business Combinations—We include the results of operations of the businesses that we acquire as of the respective dates of acquisition. We allocate the fair value of the purchase price of our business acquisitions to the tangible and intangible assets acquired and liabilities assumed, based on their estimated fair values. The excess of the purchase price over the fair values of these identifiable assets and liabilities is recorded as goodwill. We often continue to gather additional information throughout the measurement period, and if we make changes to the amounts recorded, such amounts are recorded in the period in which they are identified.

[0001262039-20-000011:notes:23]
Impairment of Long-Lived Assets—We evaluate events and changes in circumstances that could indicate carrying amounts of long-lived assets, including intangible assets, may not be recoverable. When such events or changes in circumstances occur, we assess the recoverability of long-lived assets by determining whether the carrying value of such assets will be recovered through undiscounted expected future cash flows. If the total of the future undiscounted cash flows is less than the carrying amount of those assets, we record an impairment charge in the period in which we make the determination. If such assets are considered to be impaired, the impairment to be recognized is measured by the amount by which the carrying amount of the assets exceeds the fair value of the assets.

[0001262039-20-000011:notes:24]
Goodwill—Goodwill represents the excess of purchase consideration over the estimated fair value of net assets of businesses acquired in a business combination. Goodwill acquired in a business combination is not amortized, but instead tested for impairment at least annually during the fourth quarter, or sooner when circumstances indicate an impairment may exist. We perform a qualitative assessment in the fourth quarter of each year, or more frequently if indicators of potential impairment exist, to determine if any events or circumstances exist, such as an adverse change in business climate or a decline in the overall industry that would indicate that it would more likely than not reduce the fair value of a reporting unit below its carrying amount, including goodwill. Then we perform a quantitative impairment test by comparing the fair value of a reporting unit with its carrying amount. Any excess in the carrying value of a reporting unit’s goodwill over its fair value is recognized as an impairment loss, limited to the total amount of goodwill allocated to that reporting unit.

[0001262039-20-000011:notes:25]
We performed our annual goodwill impairment analysis and did not identify any impairment indicators as a result of the review. As of December 31, 2019, we had one reporting unit.

[0001262039-20-000011:notes:26]
Other Intangible Assets—Intangible assets with finite lives are carried at cost, less accumulated amortization. Amortization is computed using the straight-line or accelerated method over the estimated economic lives of the assets, which range from three to five years.

[0001262039-20-000011:notes:27]
Deferred Revenue—Deferred revenue consists of amounts that have been invoiced but that have not yet been recognized as revenue. The majority of deferred revenue is comprised of security subscription and technical support services which are invoiced upfront and delivered over 12 months or longer.

[0001262039-20-000011:notes:28]
Income Taxes—We record income taxes using the asset and liability method, which requires the recognition of deferred tax assets and liabilities for the expected future tax consequences of events that have been recognized in our financial statements or tax returns. In addition, deferred tax assets are recorded for the future benefit of utilizing net operating losses and research and development credit carryforwards. Deferred tax assets and liabilities are measured using the currently enacted tax rates that apply to taxable income in effect for the years in which those tax assets and liabilities are expected to be realized or settled. Valuation allowances are provided when necessary to reduce deferred tax assets to the amount expected to be realized.

[0001262039-20-000011:notes:29]
We recognize tax benefits from an uncertain tax position only if it is more likely than not, based on the technical merits of the position, that the tax position will be sustained on examination by the tax authorities. The tax benefits recognized in the financial statements from such positions are then measured based on the largest benefit that has a greater than 50% likelihood of being realized upon ultimate settlement.

[0001262039-20-000011:notes:30]
Stock-Based Compensation—The fair value of restricted stock units (“RSUs”) is based on the closing market price of our common stock on the date of grant. We have elected to use the Black-Scholes-Merton (“Black-Scholes”) pricing model to determine the fair value of our employee stock options and our equity incentive plans. Stock-based compensation expense is amortized on a straight-line basis over the service period. We account for forfeitures of all stock-based payment awards when they occur.

[0001262039-20-000011:notes:31]
Leases—We rent certain facilities under operating lease agreements. On January 1, 2019, we adopted Financial Accounting Standards Board (“FASB”) Topic 842, Leases (“Topic 842”), which requires the recognition of right-of-use (“ROU”) assets and lease liabilities for operating leases on the consolidated balance sheet. Under Topic 842, we determine if an arrangement is a lease at inception. The ROU assets and the short and long-term lease liabilities from our operating leases are included in other assets, accrued liabilities and other liabilities in our consolidated balance sheets, respectively. The corresponding assets, the short and long-term lease liabilities from our finance leases are included in property and equipment, accrued liabilities and other liabilities in our consolidated balance sheets, respectively.

[0001262039-20-000011:notes:32]
The ROU assets represent our right to use an underlying asset for the lease term. Lease liabilities represent our obligation to make lease payments under the lease. Operating lease ROU assets and liabilities are recognized at the lease commencement date based on the present value of lease payments over the lease term. The implicit rate within our operating leases is generally not determinable and therefore we use our incremental borrowing rate at the lease commencement date to determine the present value of lease payments. The determination of our incremental borrowing rate requires judgment. We determine our incremental borrowing rate for each lease using indicative bank borrowing rates, adjusted for various factors including level of collateralization, term and currency to align with the terms of a lease. The operating lease ROU asset also includes any lease prepayments, net of lease incentives. Certain leases include options to extend or terminate the lease. An option to extend the lease is considered in connection with determining the ROU asset and lease liability when it is reasonably certain we will exercise that option. An option to terminate is considered unless it is reasonably certain we will not exercise the option.

[0001262039-20-000011:notes:33]
Lease expense for lease payments for our operating leases is recognized on a straight-line basis over the term of the lease. We begin recognizing rent expense on the date that a lessor makes an underlying asset that is subject to the lease available for our use. For our finance leases, we recognize amortization expense from the amortization of the corresponding assets and interest expense on the related lease liabilities.

[0001262039-20-000011:notes:34]
Prior to 2019, leases were recognized under FASB Topic 840, Leases (“Topic 840”). Under Topic 840, related rent expense was recognized on a straight-line basis over the term of the lease. Rent holidays and scheduled rent increases were included in the determination of rent expense to be recorded over the lease term. Lease incentives were recognized as a reduction of rent expense on a straight-line basis over the term of the lease. Renewals were not assumed in the determination of the lease term unless they were deemed to be reasonably assured at the inception of the lease. We began recognizing rent expense on the date that we obtained the legal right to use and control the leased space.

[0001262039-20-000011:notes:35]
Advertising Expense—Advertising costs are expensed when incurred and are included in operating expenses in the accompanying consolidated statements of income. Our advertising expenses were not significant for any periods presented.

[0001262039-20-000011:notes:36]
Research and Development Costs—Research and development costs are expensed as incurred.

[0001262039-20-000011:notes:37]
Deferred Contract Costs and Commission Expense—In 2017, we recognized commission expense on both product sales and service contracts at the time of sale. Beginning on January 1, 2018, we recognize sales commissions related to product sales upfront while sales commissions for service contracts are deferred as Deferred contract costs in the consolidated balance sheets and amortized over the applicable amortization period. Costs for initial contracts that are not commensurate with renewal commissions are amortized on a straight-line basis over the period of benefit, which we have determined to be five years and which is typically longer than the initial contract term.

[0001262039-20-000011:notes:38]
Software Development Costs—The costs to develop software that is marketed have not been capitalized as we believe our current software development process is essentially completed concurrently with the establishment of technological feasibility. Such costs are expensed as incurred and included in research and development in our consolidated statements of income.

[0001262039-20-000011:notes:39]
The costs to obtain or develop software for internal use are capitalized based on qualifying criteria, which includes a determination of whether such costs are incurred during the application development stage. Such costs are amortized over the software’s estimated useful life.

[0001262039-20-000011:notes:40]
Revenue Recognition—On January 1, 2018 we adopted ASU 2014-09, Revenue from Contracts with Customers (Topic 606) (“Topic 606”) using the modified retrospective method applied to those contracts which were not completed as of

[0001262039-20-000011:notes:41]
January 1, 2018. Results for reporting periods beginning after January 1, 2018 are presented under Topic 606, while prior period amounts are not adjusted and continue to be reported under ASU 2009-13, Revenue Recognition (Topic 605) (“Topic 605”). The details of significant changes and quantitative impact of the changes are discussed below.

[0001262039-20-000011:notes:42]
Beginning in 2018, revenues are recognized when control of these goods or services is transferred to our customers, in an amount that reflects the consideration we expect to be entitled to in exchange for those goods or services. Prior to 2018, revenue was recognized under Topic 605 when all of the following criteria were met: (i) persuasive evidence of an arrangement existed, (ii) delivery has occurred or services have been rendered, (iii) sales price was fixed or determinable and (iv) collectability was reasonably assured.

[0001262039-20-000011:notes:43]
Under Topic 606, we determine revenue recognition through the following steps:

[0001262039-20-000011:notes:44]
•identification of a contract or contracts with a customer,

[0001262039-20-000011:notes:45]
| • | identification of the performance obligations in a contract, including evaluation of performance obligations and evaluating the distinct goods or services in a contract, |

[0001262039-20-000011:notes:46]
•determination of a transaction price,

[0001262039-20-000011:notes:47]
•allocation of a transaction price to the performance obligations in a contract, and

[0001262039-20-000011:notes:48]
•recognition of revenue when, or as, we satisfy a performance obligation.

[0001262039-20-000011:notes:49]
We derive a majority of product sales from our FortiGate products which include a broad set of built-in security and networking features and functionalities, including firewall, next-generation firewall, secure web gateway, secure sockets layer (“SSL”) inspection, software-defined wide-area network, intrusion prevention, SSL data leak prevention, virtual private network, switch and wireless controller and wide area network edge.

[0001262039-20-000011:notes:50]
We previously recognized product revenue for sales to distributors that had no general right of return and direct sales to end-customers upon shipment, based on general revenue recognition accounting guidance once all other revenue recognition criteria were met. Certain distributors are granted stock rotation rights, limited rights of return or rebates for sales of our products. The arrangement fee for this group of distributors was not fixed or determinable when products were shipped and revenue was therefore deferred and recognized upon sell-through. Under Topic 606, we recognize product revenue upon shipment when control of the promised goods is transferred to the customer. Our term software licenses represent multiple performance obligations, which include software licenses and software support services where the term licenses are recognized upfront upon transfer of control, with the associated software support services recognized ratably over the contract term as services and software updates are provided. Previously, term licenses were recognized over the license period.

[0001262039-20-000011:notes:51]
Service revenue relates to sales of our FortiGuard security subscription, FortiCare technical support services and other services. Our typical subscription and contractual support term is one to three years, and to a lesser extent, five years. Our revenue recognition for service arrangements did not significantly change under Topic 606. We continue to recognize revenue from these services ratably over the contractual service period because of continuous transfer of control to the customer over the support period. Revenue related to subsequent renewals of these services are recognized over the support term of the renewal agreement. We also generate a small portion of our revenue from other services consisting of professional services, training and software-as-a-service (“SaaS”) which is either hosted or cloud-based services. We recognize revenue from professional and training services as the services are provided. We recognize revenue from SaaS as the subscription service is delivered over the term, which is typically one year, or on a monthly usage basis. To date, SaaS revenue has not represented a significant percentage of our total revenue.

[0001262039-20-000011:notes:52]
Our sales contracts typically contain multiple performance obligations, such as hardware, software license, security subscription, technical support services and other services. These are distinct from our security subscriptions, technical support services and other services in that the customer can benefit from the product without these services and such services are separately identifiable within the contract. We allocate the transaction price to each performance obligation based on relative standalone selling price. We determine standalone selling price based on the historical pricing and discounting practices for those services when sold separately. If not observable through past transactions, we may require judgment to determine the standalone selling price for distinct performance obligations by considering multiple historical factors including, but not limited to, cost of products, gross margin objectives, pricing practices, geographies and the term of the service contract that fall within a reasonably range as a percentage of list price. Revenue is reported net of sales tax.

[0001262039-20-000011:notes:53]
Under Topic 605, revenue from contracts that contain our products and services were allocated to each unit of accounting based on an estimated selling price using vendor-specific objective evidence (“VSOE”) of selling price, if it existed, or third-party evidence (“TPE”) of selling price. If neither VSOE nor TPE of selling price existed for a deliverable, we used our best estimate of selling price for that deliverable. For multiple-element arrangements where software deliverables were included, revenue was allocated to the non-software deliverables and to the software deliverables as a group using the relative estimated selling prices of each of the deliverables in the arrangement based on the estimated selling price hierarchy. The amount allocated to the software deliverables was then allocated to each software deliverable using the residual method when VSOE of fair value existed. If evidence of VSOE of fair value of one or more undelivered elements did not exist, all software allocated revenue was deferred and recognized when delivery of those elements occurred or when fair value was established. When the undelivered element for which we did not have VSOE of fair value was support, revenue for the entire arrangement was recognized ratably over the support period. The same residual method and VSOE of fair value principles applied for our multiple element arrangements that contained only software elements.

[0001262039-20-000011:notes:54]
In certain circumstances, our contracts include provisions for sales rebates and other customer incentive programs. Additionally, in limited circumstances, we may permit end-customers, distributors and resellers to return our products, subject to varying limitations, for a refund within a reasonably short period from the date of purchase. These amounts are accounted for as variable consideration that can decrease the transaction price. We estimate variable consideration using the expected-value method based on the most likely amounts to which we expect our customers to be entitled. We include estimated amounts in the transaction price to the extent that it is probable that a significant reversal of cumulative revenue recognized will not occur when the uncertainty associated with the variable consideration is resolved. Our estimate for refund liabilities, which include sales returns reserve and customer rebates, was $27.6 million and $24.1 million as of December 31, 2019 and 2018, respectively, and is included in current liabilities in our consolidated balance sheet.

[0001262039-20-000011:notes:55]
We generally invoice at the time of our sale for the total price of the hardware, software licenses, security and technical support and other services, and the invoice is payable within 30 to 45 days. We also invoice certain services on a monthly basis. Amounts billed and due from our customers are classified as receivables on the balance sheet and do not bear interest. Our deferred revenue primarily consists of amounts that have been invoiced but have not been recognized as revenue as of period end.

[0001262039-20-000011:notes:56]
Shipping and handling fees charged to our customers are recognized as revenue in the period shipped and the related costs for providing these services are recorded in cost of revenue. Shipping and handling fees recognized were not significant during 2019, 2018 and 2017.

[0001262039-20-000011:notes:57]
Warranties—We generally provide a one-year warranty on most hardware products and a 90-day warranty on software. We also provide extended warranties under the terms of our support agreements. A provision for estimated future costs related to warranty activities in the first year after product sale is recorded as a component of cost of product revenues when the product revenue is recognized, based upon historical product failure rates and historical costs incurred in correcting product failures. Warranty costs related to extended warranties sold under support agreements are recognized as cost of service revenue as incurred. In the event we change our warranty reserve estimates, the resulting charge against future cost of revenue or reversal of previously recorded charges may materially affect our gross margins and operating results. Accrued warranty was not significant as of December 31, 2019 and 2018.

[0001262039-20-000011:notes:58]
Contingent Liabilities—From time to time, we are involved in disputes, litigation, and other legal actions. There are many uncertainties associated with any disputes, litigation and other legal actions, and these actions or other third-party claims against us may cause us to incur costly litigation fees, costs and substantial settlement charges, and possibly subject us to damages and other penalties, which are inherently difficult to estimate and could adversely affect our results of operations. In addition, the resolution of any intellectual property litigation may require us to make royalty payments, which could adversely affect our gross margins in future periods. We review significant new claims and litigation for the probability of an adverse outcome. Estimates can change as individual claims develop. The actual liability in any such matters may be materially different from our estimates, which could result in the need to adjust our liability and record additional expenses, which may be material.

[0001262039-20-000011:notes:59]
Recently Adopted Accounting Standards

[0001262039-20-000011:notes:60]
Leases

[0001262039-20-000011:notes:61]
In February 2016, the FASB issued Topic 842, which requires the recognition of ROU assets and lease liabilities for operating leases on the consolidated balance sheet. We adopted Topic 842 and its related amendments as of January 1, 2019 using a modified retrospective transition approach by applying the new standard to all leases existing at the date of initial application and not restating comparative periods. We elected the package of practical expedients permitted under the transition guidance, which allowed us to waive reassessing the lease classification for any expired or existing leases, the initial direct costs for any existing leases and whether any expired or existing contracts contained leases.

[0001262039-20-000011:notes:62]
Under the new guidance, we determine if an arrangement contains a lease and the classification of that lease, if applicable, at inception or upon modification of a contract. We have elected to not recognize a lease liability or ROU asset for short-term leases (leases that, at the commencement date, have a lease term of 12 months or less and do not include an option to purchase the underlying asset that we are reasonably certain to exercise). We have elected to not allocate the contract consideration for operating lease contracts with lease and non-lease components, and account for the lease and non-lease components as a single lease component.

[0001262039-20-000011:notes:63]
The primary impact of adopting Topic 842 was the recognition of ROU assets and lease liabilities for operating leases of $39.1 million and $40.6 million, respectively, on January 1, 2019, which included reclassifying prepaid rent and deferred rent as a component of the ROU asset. Topic 842 did not have a material impact on our consolidated statements of income and cash flows.

[0001262039-20-000011:notes:64]
Our accounting for finance leases (formerly referred to as capital leases prior to the adoption of Topic 842) remained substantially unchanged. Finance leases are not material to our consolidated financial statements.

[0001262039-20-000011:notes:65]
Comprehensive Income

[0001262039-20-000011:notes:66]
In February 2018, the FASB issued ASU 2018-02—Income Statement—Reporting Comprehensive Income (Topic 220): Reclassification of Certain Tax Effects from Accumulated Other Comprehensive Income, which allows companies to reclassify stranded tax effects resulting from the Tax Cuts and Jobs Act (the “2017 Tax Act”) from accumulated other comprehensive income to retained earnings. We adopted ASU 2018-02 on January 1, 2019 and elected to reclassify $0.1 million of stranded tax effects as of that date.

[0001262039-20-000011:notes:67]
Stock Compensation

[0001262039-20-000011:notes:68]
In June 2018, the FASB issued ASU 2018-07—Compensation—Stock Compensation (Topic 718): Improvements to Nonemployee Share-Based Payment Accounting, which simplifies the accounting for share-based payments to nonemployees by aligning it with the accounting for share-based payments to employees subject to certain exceptions. ASU 2018-07 expands the scope of Accounting Standards Codification (“ASC”) Topic 718, Compensation—Stock Compensation (“ASC 718”), to include share-based payments granted to nonemployees in exchange for goods or services used or consumed in an entity’s own operations and supersedes the guidance in ASC 505, Equity, by moving it to ASC 718. We adopted ASU 2018-07 on January 1, 2019. ASU 2018-07 did not have a material impact on our consolidated financial statements.

[0001262039-20-000011:notes:69]
Recent Accounting Standards Not Yet Effective

[0001262039-20-000011:notes:70]
Income Taxes

[0001262039-20-000011:notes:71]
In December 2019, the FASB issued ASU 2019-12—Income Taxes (Topic 740): Simplifying the Accounting for Income Taxes. The amendments in ASU 2019-12 simplify the accounting for income taxes by removing certain exceptions to the general principles in Topic 740. The amendments also improve consistent application of and simplify GAAP for other areas of Topic 740 by clarifying and amending existing guidance. ASU 2019-12 is effective for us beginning on January 1, 2021. Early adoption of the amendments is permitted. We are currently evaluating the impact of ASU 2019-12 on our consolidated financial statements.

[0001262039-20-000011:notes:72]
Cloud Computing

[0001262039-20-000011:notes:73]
In August 2018, the FASB issued ASU 2018-15—Intangibles-Goodwill and Other—Internal-Use Software (Subtopic 350-40): Customer’s Accounting for Implementation Costs Incurred in a Cloud Computing Arrangement That Is a Service Contract, which requires a customer in a cloud computing arrangement that is a service contract to follow the internal-use software guidance in ASC Topic 350, Intangibles—Goodwill and Other, to determine which implementation costs to capitalize as assets or expense as incurred. Companies can choose to adopt the ASU 2018-15 prospectively or retrospectively. ASU 2018-15 is effective for us beginning January 1, 2020. The adoption of this standard will not have a material impact on our consolidated financial statements.

[0001262039-20-000011:notes:74]
Fair Value Measurements

[0001262039-20-000011:notes:75]
In August 2018, the FASB issued ASU 2018-13—Fair Value Measurement (Topic 820): Disclosure Framework—Changes to the Disclosure Requirements for Fair Value Measurement, which eliminates, adds and modifies certain disclosure requirements for fair value measurements in ASC 820, Fair Value Measurement, as part of its disclosure framework project. ASU 2018-13 is effective for us beginning January 1, 2020. The amendments in ASU 2018-13 that relate to changes in unrealized gains and losses, the range and weighted average of significant unobservable inputs used to develop Level 3 fair value measurements and the narrative description of measurement uncertainty should be applied prospectively for only the most recent interim or annual period presented in the initial fiscal year of adoption. All other amendments in ASU 2018-13 should be applied retrospectively to all periods presented upon their effective date. The adoption of this standard will not have a material impact on our disclosures.

[0001262039-20-000011:notes:76]
Financial Instruments

[0001262039-20-000011:notes:77]
In June 2016, the FASB issued ASU 2016-13—Financial Instruments—Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments and in November 2018, the FASB issued ASU 2018-19—Codification Improvements to Topic 326, Financial Instruments—Credit Losses, as a subsequent amendment to the initial guidance (collectively, Topic 326). In April 2019, the FASB issued ASU 2019-04—Codification Improvements to Topic 326: Financial Instruments—Credit Losses, Topic 815, Derivatives and Hedging, and Topic 825, Financial Instruments, in May 2019, the FASB issued ASU 2019-05—Financial Instruments—Credit Losses (Topic 326): Targeted Transition Relief, and in November 2019, the FASB issued ASU 2019-11—Codification Improvements to Topic 326 to clarify and address certain items related to the amendments in ASU 2016-13. Topic 326 requires a financial asset (or a group of financial assets) measured at an amortized cost basis to be presented at the net amount expected to be collected. The new approach to estimating credit losses (referred to as the current expected credit losses model) generally accelerates recognition of credit losses. The new guidance is effective for us beginning on January 1, 2020. The adoption of this standard will not have a material impact on our consolidated financial statements.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001262039-20-000011:notes:78]
REVENUE RECOGNITION

[0001262039-20-000011:notes:79]
Our revenue consists of product and service revenue. Product revenue is generated by sales of our FortiGate products and other hardware and software solutions. Service revenue relates to sales of our FortiGuard security subscription, FortiCare technical support services and other services.

[0001262039-20-000011:notes:80]
Disaggregation of Revenue

[0001262039-20-000011:notes:81]
The following table presents our revenue disaggregated by major product and service lines (in millions):

[0001262039-20-000011:notes:82]
|  | Years Ended |
|  | December 31, 2019 |  | December 31, 2018 | December 31, 2017 (1) |
| Product | $ | 788.5 |  |  | $ | 674.4 |  | $ | 577.2 |  |
| Service: |  |  |  |  |
| Security subscription | 750.9 |  |  | 606.1 |  | 504.8 |  |
| Technical support and other | 616.8 |  |  | 520.7 |  | 412.9 |  |
| Total service revenue | 1,367.7 |  |  | 1,126.8 |  | 917.7 |  |
| Total revenue | $ | 2,156.2 |  |  | $ | 1,801.2 |  | $ | 1,494.9 |  |
| (1) December 31, 2017 amounts have not been adjusted under the modified retrospective method. |

[0001262039-20-000011:notes:83]
Deferred Revenue

[0001262039-20-000011:notes:84]
Our deferred revenue consists of amounts that have been invoiced but have not been recognized as revenue as of period end. During 2019, we recognized $930.4 million in revenue that was included in the deferred revenue balance as of December 31, 2018. During 2018, we recognized $753.3 million in revenue that was included in the deferred revenue balance as of January 1, 2018.

[0001262039-20-000011:notes:85]
Transaction Price Allocated to the Remaining Performance Obligations

[0001262039-20-000011:notes:86]
As of December 31, 2019, the aggregate amount of the transaction price allocated to remaining performance obligations was $2.14 billion, which was substantially comprised of deferred security subscription and technical support services. We expect to recognize approximately $1.17 billion as revenue over the next 12 months and the remainder thereafter.

[0001262039-20-000011:notes:87]
Accounts Receivable

[0001262039-20-000011:notes:88]
Trade accounts receivable are recorded at the invoiced amount. Trade accounts receivable are reduced by an allowance for doubtful accounts which is determined based on our assessment of the collectability of customer accounts. The allowance for doubtful accounts was $1.2 million as of December 31, 2019 and $0.9 million as of December 31, 2018.

[0001262039-20-000011:notes:89]
Contract Assets

[0001262039-20-000011:notes:90]
Contract assets represent amounts that have been recognized as revenue but for which we did not have the unconditional right to invoice the customer. Our contract assets as of December 31, 2019 and December 31, 2018 were immaterial.

[0001262039-20-000011:notes:91]
Deferred Contract Costs

[0001262039-20-000011:notes:92]
Sales commissions earned by our sales force are considered incremental and recoverable costs of obtaining a contract with a customer. Sales commissions for the sale of products and software licenses are recognized at the time of sale. Sales commissions for initial service contracts are deferred and then amortized as an expense on a straight-line basis over the period of benefit which we have determined to be five years. We determined the period of benefit taking into consideration our customer contracts, our technology and other factors. Sales commissions for renewal contracts are deferred and then amortized on a straight-line basis over the contractual period of the underlying contracts which ranges from one to three years and, to a lesser extent, five years. The amortization of deferred contract costs is included in sales and marketing expense in our consolidated statements of income. Amortization of deferred contract costs during 2019 and 2018 was $107.9 million and $90.9 million, respectively. No impairment loss was recognized during 2019 and 2018.


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0001262039-20-000011:notes:93]
FINANCIAL INSTRUMENTS AND FAIR VALUE

[0001262039-20-000011:notes:94]
The following tables summarize our investments (in millions):

[0001262039-20-000011:notes:95]
|  | December 31, 2019 |
|  | AmortizedCost |  | UnrealizedGains |  | UnrealizedLosses |  | FairValue |
| Corporate debt securities | $ | 576.1 |  |  | $ | 1.0 |  |  | $ | (0.1 | ) |  | $ | 577.0 |  |
| Commercial paper | 148.7 |  |  | 0.1 |  |  | — |  |  | 148.8 |  |
| Certificates of deposit and term deposits (1) | 66.4 |  |  | — |  |  | — |  |  | 66.4 |  |
| U.S. government and agency securities | 195.0 |  |  | 0.2 |  |  | — |  |  | 195.2 |  |
| Total available-for-sale securities | $ | 986.2 |  |  | $ | 1.3 |  |  | $ | (0.1 | ) |  | $ | 987.4 |  |
|  | December 31, 2018 |
|  | AmortizedCost |  | UnrealizedGains |  | UnrealizedLosses |  | FairValue |
| Corporate debt securities | $ | 299.5 |  |  | $ | — |  |  | $ | (1.2 | ) |  | $ | 298.3 |  |
| Commercial paper | 102.5 |  |  | — |  |  | — |  |  | 102.5 |  |
| Certificates of deposit and term deposits (1) | 145.8 |  |  | — |  |  | — |  |  | 145.8 |  |
| U.S. government and agency securities | 57.7 |  |  | — |  |  | (0.1 | ) |  | 57.6 |  |
| Total available-for-sale securities | $ | 605.5 |  |  | $ | — |  |  | $ | (1.3 | ) |  | $ | 604.2 |  |
| (1) The majority of our certificates of deposit and term deposits are foreign deposits. |

[0001262039-20-000011:notes:96]
The following tables show the gross unrealized losses and the related fair values of our investments that have been in a continuous unrealized loss position (in millions):

[0001262039-20-000011:notes:97]
|  | December 31, 2019 |
|  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
|  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |
| Corporate debt securities | $ | 117.3 |  |  | $ | (0.1 | ) |  | $ | 16.1 |  |  | $ | — |  |  | $ | 133.4 |  |  | $ | (0.1 | ) |
| Certificates of deposit and term deposits | 13.0 |  |  | — |  |  | — |  |  | — |  |  | 13.0 |  |  | — |  |
| Commercial paper | 26.0 |  |  | — |  |  | — |  |  | — |  |  | 26.0 |  |  | — |  |
| U.S. government and agency securities | 47.1 |  |  | — |  |  | — |  |  | — |  |  | 47.1 |  |  | — |  |
| Total available-for-sale securities | $ | 203.4 |  |  | $ | (0.1 | ) |  | $ | 16.1 |  |  | $ | — |  |  | $ | 219.5 |  |  | $ | (0.1 | ) |

[0001262039-20-000011:notes:98]
|  | December 31, 2018 |
|  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
|  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |
| Corporate debt securities | $ | 150.1 |  |  | $ | (0.2 | ) |  | $ | 93.5 |  |  | $ | (1.0 | ) |  | $ | 243.6 |  |  | $ | (1.2 | ) |
| Commercial paper | 75.6 |  |  | (0.1 | ) |  | — |  |  | — |  |  | 75.6 |  |  | (0.1 | ) |
| Certificates of deposit and term deposits | 51.7 |  |  | — |  |  | — |  |  | — |  |  | 51.7 |  |  | — |  |
| U.S. government and agency securities | 39.0 |  |  | — |  |  | 3.5 |  |  | — |  |  | 42.5 |  |  | — |  |
| Total available-for-sale securities | $ | 316.4 |  |  | $ | (0.3 | ) |  | $ | 97.0 |  |  | $ | (1.0 | ) |  | $ | 413.4 |  |  | $ | (1.3 | ) |

[0001262039-20-000011:notes:99]
The contractual maturities of our investments were as follows (in millions):

[0001262039-20-000011:notes:100]
|  | December 31, 2019 |  | December 31, 2018 |
| Due within one year | $ | 843.1 |  |  | $ | 537.2 |  |
| Due within one to three years | 144.3 |  |  | 67.0 |  |
| Total | $ | 987.4 |  |  | $ | 604.2 |  |

[0001262039-20-000011:notes:101]
Available-for-sale securities are reported at fair value, with unrealized gains and losses and the related tax impact included as a separate component of stockholders’ equity and in comprehensive income. Realized losses on available-for-sale securities were insignificant in the periods presented and are included in Other income (expense)—net in our consolidated statements of income. We use the specific identification method to determine the cost basis of investments sold.

[0001262039-20-000011:notes:102]
The unrealized losses on our available-for-sale securities were caused by fluctuations in market value and interest rates as a result of the economic environment. We consider these investments to be temporarily impaired as of December 31, 2019 because (i) the decline in market value was attributable to changes in market conditions and not credit quality, and (ii) we have concluded currently that neither do we intend to sell nor is it more likely than not that we will be required to sell these investments prior to recovery of their amortized cost basis.

[0001262039-20-000011:notes:103]
Fair Value Accounting—We apply the following fair value hierarchy for disclosure of the inputs used to measure fair value. This hierarchy prioritizes the inputs into three broad levels as follows:

[0001262039-20-000011:notes:104]
Level 1—Inputs are unadjusted quoted prices in active markets for identical assets or liabilities.

[0001262039-20-000011:notes:105]
Level 2—Inputs are quoted prices for similar assets and liabilities in active markets or inputs that are observable for the assets or liabilities, either directly or indirectly through market corroboration, for substantially the full term of the financial instruments.

[0001262039-20-000011:notes:106]
Level 3—Unobservable inputs based on our own assumptions used to measure assets and liabilities at fair value. The inputs require significant management judgment or estimation.

[0001262039-20-000011:notes:107]
We measure the fair value of money market funds and certain U.S. government and agency securities using quoted prices in active markets for identical assets. The fair value of all other financial instruments was based on quoted prices for similar assets in active markets, or model-driven valuations using significant inputs derived from or corroborated by observable market data.

[0001262039-20-000011:notes:108]
We classify investments within Level 1 if quoted prices are available in active markets for identical securities.

[0001262039-20-000011:notes:109]
We classify items within Level 2 if the investments are valued using model-driven valuations using observable inputs such as quoted market prices, benchmark yields, reported trades, broker/dealer quotes or alternative pricing sources with reasonable levels of price transparency. Investments are held by custodians who obtain investment prices from a third-party pricing provider that incorporates standard inputs in various asset price models.

[0001262039-20-000011:notes:110]
Fair Value of Financial Instruments

[0001262039-20-000011:notes:111]
Assets Measured at Fair Value on a Recurring Basis

[0001262039-20-000011:notes:112]
The following tables present the fair value of our financial assets measured at fair value on a recurring basis (in millions):

[0001262039-20-000011:notes:113]
|  | December 31, 2019 |  | December 31, 2018 |
|  | AggregateFairValue |  | QuotedPrices inActiveMarkets ForIdenticalAssets |  | SignificantOtherObservableRemainingInputs |  | SignificantOtherUnobservableRemainingInputs |  | AggregateFairValue |  | QuotedPrices inActiveMarkets ForIdenticalAssets |  | SignificantOtherObservableRemainingInputs |  | SignificantOtherUnobservableRemainingInputs |
|  |  |  | (Level 1) |  | (Level 2) |  | (Level 3) |  |  |  | (Level 1) |  | (Level 2) |  | (Level 3) |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate debt securities | $ | 577.0 |  |  | $ | — |  |  | $ | 577.0 |  |  | $ | — |  |  | $ | 299.3 |  |  | $ | — |  |  | $ | 299.3 |  |  | $ | — |  |
| Certificates of deposit and term deposits | 66.4 |  |  | — |  |  | 66.4 |  |  | — |  |  | 217.4 |  |  | — |  |  | 217.4 |  |  | — |  |
| Money market funds | 15.0 |  |  | 15.0 |  |  |  |  |  | — |  |  | 58.6 |  |  | 58.6 |  |  | — |  |  | — |  |
| Commercial paper | 165.8 |  |  | — |  |  | 165.8 |  |  | — |  |  | 184.7 |  |  | — |  |  | 184.7 |  |  | — |  |
| U.S. government and agency securities | 195.2 |  |  | 195.2 |  |  | — |  |  | — |  |  | 57.6 |  |  | 45.3 |  |  | 12.3 |  |  | — |  |
| Total | $ | 1,019.4 |  |  | $ | 210.2 |  |  | $ | 809.2 |  |  | $ | — |  |  | $ | 817.6 |  |  | $ | 103.9 |  |  | $ | 713.7 |  |  | $ | — |  |
| Reported as: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents | $ | 32.0 |  |  |  |  |  |  |  |  | $ | 213.4 |  |  |  |  |  |  |  |
| Short-term investments | 843.1 |  |  |  |  |  |  |  |  | 537.2 |  |  |  |  |  |  |  |
| Long-term investments | 144.3 |  |  |  |  |  |  |  |  | 67.0 |  |  |  |  |  |  |  |
| Total | $ | 1,019.4 |  |  |  |  |  |  |  |  | $ | 817.6 |  |  |  |  |  |  |  |

[0001262039-20-000011:notes:114]
There were no transfers between Level 1 and Level 2 of the fair value hierarchy during the years ended December 31, 2019 and December 31, 2018.


## us-gaap:InventoryDisclosureTextBlock

[0001262039-20-000011:notes:115]
INVENTORY

[0001262039-20-000011:notes:116]
Inventory consisted of the following (in millions):

[0001262039-20-000011:notes:117]
|  | December 31, 2019 |  | December 31, 2018 |
| Raw materials | $ | 9.7 |  |  | $ | 13.3 |  |
| Finished goods | 108.2 |  |  | 76.7 |  |
| Inventory | $ | 117.9 |  |  | $ | 90.0 |  |


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001262039-20-000011:notes:118]
PROPERTY AND EQUIPMENT—Net

[0001262039-20-000011:notes:119]
Property and equipment—net consisted of the following (in millions):

[0001262039-20-000011:notes:120]
|  | December 31, 2019 |  | December 31, 2018 |
| Building and building improvements | $ | 147.4 |  |  | $ | 144.2 |  |
| Computer equipment and software | 116.7 |  |  | 95.9 |  |
| Land | 93.3 |  |  | 75.7 |  |
| Leasehold improvements | 25.5 |  |  | 17.9 |  |
| Evaluation units | 19.9 |  |  | 20.5 |  |
| Furniture and fixtures | 17.3 |  |  | 15.7 |  |
| Construction-in-progress | 61.2 |  |  | 12.3 |  |
| Total property and equipment | 481.3 |  |  | 382.2 |  |
| Less: accumulated depreciation | (137.0 | ) |  | (110.8 | ) |
| Property and equipment—net | $ | 344.3 |  |  | $ | 271.4 |  |

[0001262039-20-000011:notes:121]
Depreciation expense was $50.7 million, $46.7 million and $46.9 million in 2019, 2018 and 2017, respectively.


## us-gaap:CostMethodInvestmentsDescriptionTextBlock

[0001262039-20-000011:notes:122]
INVESTMENTS IN PRIVATELY HELD COMPANIES

[0001262039-20-000011:notes:123]
Our investments in the equity securities of privately held companies totaled $5.3 million and $9.1 million as of December 31, 2019 and 2018, respectively. These investments are accounted for at cost, adjusted for changes in observable prices minus impairment. We own less than 20% of the voting securities in each of these investments and do not have the ability to exercise significant influence over operating and financial policies of the respective entities. These investments are recorded as Other assets in our consolidated balance sheets and would be measured at fair value if indicators of an increase in value or impairment existed. During the third quarter of 2019, we determined that one of our investments was other-than-temporarily impaired. As a result, we recognized a non-cash impairment charge of $3.8 million to Other income (expense)—net in our consolidated statements of income. During the third quarter of 2018, we sold equity securities of a privately held company for $5.2 million and recognized a gain of $2.2 million to Other income (expense)—net in our consolidated statements of income. As of December 31, 2019, no other events have occurred that would affect the carrying value of these investments.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001262039-20-000011:notes:124]
BUSINESS COMBINATIONS

[0001262039-20-000011:notes:125]
2019 Acquisitions

[0001262039-20-000011:notes:126]
CyberSponse, Inc.

[0001262039-20-000011:notes:127]
On December 12, 2019, we acquired all outstanding shares of CyberSponse, Inc. (“CyberSponse”), a provider of security orchestration, automation and response products and services. We expect that the CyberSponse acquisition will further extend the automation and incident response capabilities of our FortiAnalyzer, FortiSIEM and FortiGate solutions.

[0001262039-20-000011:notes:128]
Under the business combination method of accounting in accordance with ASC Topic 805, Business Combinations (“ASC 805”), the total preliminary purchase price was allocated to CyberSponse’s identifiable tangible and intangible assets acquired and liabilities assumed based on their estimated fair values using management’s best estimates and assumptions to assign fair value as of the acquisition date. The preliminary purchase price for CyberSponse was $26.1 million, of which $18.6 million was allocated to goodwill that was non-deductible for tax purposes and $9.1 million was allocated to identifiable intangible assets, the majority of which was developed technology, offset by $1.6 million of net liabilities assumed, which predominantly included cash, accounts receivable, accrued payroll and compensation liabilities and deferred tax liabilities. We incurred a $4.1 million liability in connection with this business combination, the majority of which related to the settlement of CyberSponse’s equity awards in cash, which we included in accrued liabilities in our consolidated balance sheet as of December 31, 2019. The preliminary purchase price included $3.0 million of this liability and the remaining $1.1 million was recognized as compensation cost in the consolidated statement of income for the year ended December 31, 2019. The preliminary purchase price also included $3.8 million held in indemnity escrow, of which $2.8 million will be held for 12 months and the remaining $1.0 million will be held for 36 months after the transaction closing date. The amount recognized for acquired indemnification assets as of the acquisition date was not material. Goodwill recorded in connection with this acquisition represents the value we expect to be created through expansion into markets within our existing business, and potential cost savings and synergies.

[0001262039-20-000011:notes:129]
Our estimates and assumptions are subject to change within the measurement period. The allocation of the purchase price for this acquisition has been prepared on a preliminary basis and changes to the allocation of certain assets and liabilities may occur as additional information becomes available. The primary areas of the purchase price that are not yet finalized are related to income taxes and the valuation of acquired assets and assumed liabilities.

[0001262039-20-000011:notes:130]
enSilo Limited

[0001262039-20-000011:notes:131]
On October 28, 2019, we acquired all outstanding shares of enSilo Limited (“enSilo”), a provider of endpoint detection and response products and services. We expect that the enSilo acquisition will further enhance the Fortinet Security Fabric platform and strengthen endpoint and network security solutions by providing customers with advanced endpoint security.

[0001262039-20-000011:notes:132]
Under the business combination method of accounting in accordance with ASC 805, the total preliminary purchase price was allocated to enSilo’s identifiable tangible and intangible assets acquired and liabilities assumed based on their estimated fair values using management’s best estimates and assumptions to assign fair value as of the acquisition date. The preliminary purchase price for enSilo was $15.8 million, of which $10.4 million was allocated to goodwill, $10.8 million was

[0001262039-20-000011:notes:133]
allocated to identifiable intangible assets, the majority of which was developed technology, offset by $5.4 million of net liabilities assumed, which predominantly included cash, accounts receivable, operating lease right-of-use asset and liability, deferred revenue, accrued payroll and compensation liabilities, assumed debt and deferred tax liabilities. The preliminary purchase price included $2.0 million held in indemnity escrow for 12 months after the transaction closing date. The amount recognized for acquired indemnification assets as of the acquisition date was not material. Goodwill recorded in connection with this acquisition represents the value we expect to be created through expansion into markets within our existing business, and potential cost savings and synergies and goodwill is non-deductible for tax purposes.

[0001262039-20-000011:notes:134]
2018 Acquisitions

[0001262039-20-000011:notes:135]
ZoneFox Holdings Limited

[0001262039-20-000011:notes:136]
On October 22, 2018, we acquired all outstanding shares of ZoneFox Holdings Limited (“ZoneFox”), a privately held cloud-based company providing insider threat detection and response. The purchase price for ZoneFox was $16.1 million, of which $12.5 million was allocated to goodwill that was non-deductible for tax purposes and $6.8 million was allocated to identifiable intangible assets, the majority of which was developed technology, offset by $3.2 million of net liabilities assumed.

[0001262039-20-000011:notes:137]
The acquisition included a $2.0 million cash earn-out that was subject in full to satisfaction of certain performance conditions. The performance conditions were not met and the cash earn-out will not be paid.

[0001262039-20-000011:notes:138]
Bradford Networks, Inc.

[0001262039-20-000011:notes:139]
On June 4, 2018, we acquired all outstanding shares of Bradford Networks, Inc. (“Bradford”), a provider of network access control security products and services. The purchase price for Bradford was $6.8 million, of which $11.1 million was allocated to goodwill that was non-deductible for tax purposes and $8.0 million was allocated to identifiable intangible assets, the majority of which was developed technology, offset by $12.3 million of net liabilities assumed.

[0001262039-20-000011:notes:140]
Additional Acquisition-Related Information

[0001262039-20-000011:notes:141]
The operating results of the acquired companies are included in our consolidated statements of income from the respective dates of acquisition. Acquisition-related costs related to each acquisition were not material. Pro forma information has not been presented as the impact of these acquisitions, individually and in the aggregate, were not material to our consolidated financial statements.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001262039-20-000011:notes:142]
GOODWILL AND OTHER INTANGIBLE ASSETS—Net

[0001262039-20-000011:notes:143]
Goodwill

[0001262039-20-000011:notes:144]
The following table presents the changes in the carrying amount of goodwill (in millions):

[0001262039-20-000011:notes:145]
|  | Amount |
| Balance—December 31, 2018 | $ | 38.2 |  |
| Additions due to business combinations | 29.0 |  |
| Balance—December 31, 2019 | $ | 67.2 |  |

[0001262039-20-000011:notes:146]
There were no impairments to goodwill during 2019, 2018, 2017 or any previous years.

[0001262039-20-000011:notes:147]
Other Intangible Assets—net

[0001262039-20-000011:notes:148]
The following tables present other intangible assets—net (in millions, except years):

[0001262039-20-000011:notes:149]
|  | December 31, 2019 |
|  | Weighted-Average Useful Life (in Years) |  | Gross |  | Accumulated Amortization |  | Net |
| Other intangible assets—net: |  |  |  |  |  |  |  |
| Finite-lived intangible assets: |  |  |  |  |  |  |  |
| Developed technologies | 4.0 |  | $ | 50.2 |  |  | $ | 24.6 |  |  | $ | 25.6 |  |
| Customer relationships | 4.1 |  | 21.6 |  |  | 16.1 |  |  | 5.5 |  |
| Total other intangible assets—net |  |  | $ | 71.8 |  |  | $ | 40.7 |  |  | $ | 31.1 |  |

[0001262039-20-000011:notes:150]
|  | December 31, 2018 |
|  | Weighted-Average Useful Life (in Years) |  | Gross |  | Accumulated Amortization |  | Net |
| Other intangible assets—net: |  |  |  |  |  |  |  |
| Finite-lived intangible assets: |  |  |  |  |  |  |  |
| Developed technologies and other | 4.0 |  | $ | 34.4 |  |  | $ | 17.0 |  |  | $ | 17.4 |  |
| Customer relationships | 4.4 |  | 17.5 |  |  | 12.8 |  |  | 4.7 |  |
| Total other intangible assets—net |  |  | $ | 51.9 |  |  | $ | 29.8 |  |  | $ | 22.1 |  |

[0001262039-20-000011:notes:151]
Amortization expense of finite-lived intangible assets was $10.9 million, $9.0 million and $8.6 million in 2019, 2018, and 2017, respectively. The following table summarizes estimated future amortization expense of finite-lived intangible assets (in millions):

[0001262039-20-000011:notes:152]
|  | Amount |
| Years: |  |
| 2020 | $ | 12.7 |  |
| 2021 | 8.3 |  |
| 2022 | 6.4 |  |
| 2023 | 3.7 |  |
| Total | $ | 31.1 |  |


## us-gaap:EarningsPerShareTextBlock

[0001262039-20-000011:notes:153]
NET INCOME PER SHARE

[0001262039-20-000011:notes:154]
Basic net income per share is computed by dividing net income by the weighted-average number of shares of common stock outstanding during the period. Diluted net income per share is computed by dividing net income by the weighted-average number of shares of common stock outstanding during the period, plus the dilutive effects of restricted stock units (“RSUs”), stock options and our Employee Stock Purchase Plan (“ESPP”), which was terminated in February 2019 at the completion of the prior offering period. Dilutive shares of common stock are determined by applying the treasury stock method.

[0001262039-20-000011:notes:155]
A reconciliation of the numerator and denominator used in the calculation of basic and diluted net income per share is as follows (in millions, except per share amounts):

[0001262039-20-000011:notes:156]
|  | Year Ended December 31, |
|  | 2019 |  | 2018 |  | 2017 |
| Numerator: |  |  |  |  |  |
| Net income | $ | 326.5 |  |  | $ | 332.2 |  |  | $ | 31.4 |  |
| Denominator: |  |  |  |  |  |
| Basic shares: |  |  |  |  |  |
| Weighted-average common stock outstanding-basic | 171.0 |  |  | 169.1 |  |  | 174.3 |  |
| Diluted shares: |  |  |  |  |  |
| Weighted-average common stock outstanding-basic | 171.0 |  |  | 169.1 |  |  | 174.3 |  |
| Effect of potentially dilutive securities: |  |  |  |  |  |
| RSUs | 2.8 |  |  | 3.6 |  |  | 2.3 |  |
| Stock options | 1.2 |  |  | 1.4 |  |  | 1.4 |  |
| ESPP | — |  |  | 0.1 |  |  | 0.1 |  |
| Weighted-average shares used to compute diluted net income per share | 175.0 |  |  | 174.2 |  |  | 178.1 |  |
| Net income per share: |  |  |  |  |  |
| Basic | $ | 1.91 |  |  | $ | 1.96 |  |  | $ | 0.18 |  |
| Diluted | $ | 1.87 |  |  | $ | 1.91 |  |  | $ | 0.18 |  |

[0001262039-20-000011:notes:157]
The following weighted-average shares of common stock were excluded from the computation of diluted net income per share for the periods presented, as their effect would have been antidilutive (in millions):

[0001262039-20-000011:notes:158]
|  | Year Ended December 31, |
|  | 2019 |  | 2018 |  | 2017 |
| RSUs | 0.3 |  |  | 0.5 |  |  | 1.4 |  |
| Stock options | 0.6 |  |  | 0.3 |  |  | 1.0 |  |
| ESPP | — |  |  | 0.1 |  |  | 0.2 |  |
| Total | 0.9 |  |  | 0.9 |  |  | 2.6 |  |


## us-gaap:LesseeOperatingLeasesTextBlock

[0001262039-20-000011:notes:159]
LEASES

[0001262039-20-000011:notes:160]
We have operating leases for offices, research and development facilities and data centers. Our leases have remaining terms that range from less than one year to approximately seven years, some of which include one or more options to renew, with renewal terms of up to five years. We do not include renewal options in our lease terms for calculating our lease liability, as the renewal options allow us to maintain operational flexibility and we are not reasonably certain we will exercise these renewal options at the time of the lease commencement.

[0001262039-20-000011:notes:161]
During the year ended December 31, 2019 we entered into a finance lease with $3.6 million lease liabilities arising from obtaining right-of-use assets with a lease term of approximately two years. Our remaining finance leases were not material to our consolidated financial statements. The related assumptions and further disclosures for finance leases are not material.

[0001262039-20-000011:notes:162]
The components of operating lease expense were as follows (in millions):

[0001262039-20-000011:notes:163]
|  | Year Ended |
|  | December 31,2019 |
| Operating lease expense | $ | 15.3 |  |
| Variable lease expense (1) | 2.6 |  |
| Short-term lease expense | 3.2 |  |
| Total lease expense | $ | 21.1 |  |

[0001262039-20-000011:notes:164]
(1) Variable lease expense for the year ended December 31, 2019 predominantly included common area maintenance charges and parking expense.

[0001262039-20-000011:notes:165]
Rent expense was $17.1 million and $16.7 million for 2018 and 2017, respectively. Rent expense was recognized in accordance with Topic 840 using the straight-line method over the term of a lease.

[0001262039-20-000011:notes:166]
Supplemental balance sheet information related to our operating leases was as follows (in millions, except lease term and discount rate):

[0001262039-20-000011:notes:167]
|  | Classification | December 31, 2019 |
| Operating lease ROU assets – non-current | Other assets | $ | 44.3 |  |
| Operating lease liabilities – current | Accrued liabilities | $ | 15.5 |  |
| Operating lease liabilities – non-current | Other liabilities | 30.6 |  |
| Total operating lease liabilities |  | $ | 46.1 |  |
| Weighted average remaining lease term in years – operating leases |  | 3.7 |  |
| Weighted average discount rate – operating leases |  | 2.8 | % |

[0001262039-20-000011:notes:168]
Supplemental cash flow information related to leases was as follows (in millions):

[0001262039-20-000011:notes:169]
|  | Year Ended |
|  | December 31,2019 |
| Cash paid for amounts included in the measurement of lease liabilities |  |
| Operating cash flows used for operating leases | $ | 16.2 |  |
| Lease liabilities arising from obtaining right-of-use assets |  |
| Operating leases | $ | 20.4 |  |

[0001262039-20-000011:notes:170]
Maturities of operating lease liabilities as of December 31, 2019 were as follows (in millions):

[0001262039-20-000011:notes:171]
| Year ending December 31, | Amount |
| 2020 | $ | 16.4 |  |
| 2021 | 13.0 |  |
| 2022 | 8.4 |  |
| 2023 | 5.2 |  |
| 2024 | 3.8 |  |
| Thereafter | 1.8 |  |
| Total lease payments | $ | 48.6 |  |
| Less imputed interest | (2.5 | ) |
| Total | $ | 46.1 |  |

[0001262039-20-000011:notes:172]
As of December 31, 2019, we had additional minimum lease payments of $4.4 million relating to the operating leases that had been signed but had not yet commenced and therefore were excluded from the table above. These leases will commence during 2020 and will have lease term of approximately five to seven years.

[0001262039-20-000011:notes:173]
The following table summarizes our future principal contractual obligations for operating lease commitments as of December 31, 2018 (in millions):

[0001262039-20-000011:notes:174]
| Year ending December 31, | Amount |
| 2019 | $ | 17.1 |  |
| 2020 | 12.2 |  |
| 2021 | 8.5 |  |
| 2022 | 5.0 |  |
| 2023 | 3.6 |  |
| Thereafter | 3.7 |  |
| Total | $ | 50.1 |  |

[0001262039-20-000011:notes:175]
Total future principal contractual obligations for operating lease commitments as of December 31, 2018 exceeded our undiscounted lease liability as of the Topic 842 adoption date, primarily because the lease liability excluded short-term lease payments (due to the adoption of the short-term lease exemption) and excluded minimum lease payments relating to an operating lease that had been signed but had not yet commenced.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001262039-20-000011:notes:176]
COMMITMENTS AND CONTINGENCIES

[0001262039-20-000011:notes:177]
The following table summarizes our inventory purchase commitments as of December 31, 2019 (in millions):

[0001262039-20-000011:notes:178]
|  | Total |  | 2020 |  | 2021 |  | 2022 |  | 2023 |  | 2024 |  | Thereafter |
| Inventory purchase commitments | $ | 231.9 |  |  | $ | 231.9 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |

[0001262039-20-000011:notes:179]
Inventory Purchase Commitments—Our independent contract manufacturers procure components and build our products based on our forecasts. These forecasts are based on estimates of future demand for our products, which are in turn based on historical trends and an analysis from our sales and marketing organizations, adjusted for overall market conditions. In order to reduce manufacturing lead times and plan for adequate component supply, we may issue purchase orders to some of our independent contract manufacturers which may not be cancelable. As of December 31, 2019, we had $231.9 million of open purchase orders with our independent contract manufacturers that may not be cancelable.

[0001262039-20-000011:notes:180]
Other Contractual Commitments and Open Purchase Orders—In addition to commitments with contract manufacturers, we have open purchase orders and contractual obligations in the ordinary course of business for which we have not received goods or services. As of December 31, 2019, we had $12.8 million in other contractual commitments having a remaining term in excess of one year that may not be cancelable.

[0001262039-20-000011:notes:181]
Litigation—We are involved in disputes, litigation, and other legal actions. For lawsuits where we are the defendant, we are in the process of defending these litigation matters, and while there can be no assurances and the outcome of certain of these matters is currently not determinable and not predictable, we currently are unaware of any existing claims or proceedings that we believe are likely to have a material adverse effect on our financial position. There are many uncertainties associated with any litigation and these actions or other third-party claims against us may cause us to incur costly litigation fees, costs and substantial settlement charges, and possibly subject us to damages and other penalties. In addition, the resolution of any intellectual property litigation may require us to make royalty payments, which could adversely affect our gross margins in future periods. If any of those events were to occur, our business, financial condition, results of operations, and cash flows could be adversely affected. Litigation is unpredictable and the actual liability in any such matters may be materially different from our current estimates, which could result in the need to adjust any accrued liability and record additional expenses. We accrue for contingencies when we believe that a loss is probable and that we can reasonably estimate the amount of any such loss.

[0001262039-20-000011:notes:182]
Indemnification and Other Matters—Under the indemnification provisions of our standard sales contracts, we agree to defend our customers against third-party claims asserting various allegations such as product defects and infringement of certain intellectual property rights, which may include patents, copyrights, trademarks or trade secrets, and to pay judgments entered on such claims. In some contracts, our exposure under these indemnification provisions is limited by the terms of the contracts to certain defined limits, such as the total amount paid by our customer under the agreement. However, certain agreements include covenants, penalties and indemnification provisions including and beyond indemnification for third-party claims of intellectual property infringement, that could potentially expose us to losses in excess of the amount received under the agreement, and in some instances to potential liability that is not contractually limited. To date, although from time to time there are indemnification claims asserted against us and currently there are pending indemnification claims, there have been no material awards under such indemnification provisions.

[0001262039-20-000011:notes:183]
Periodically we, like other security companies and companies in other industries, may experience cybersecurity threats, malicious activity directed against our information technology infrastructure and unauthorized attempts to gain access to our and our customers’ sensitive information and systems. For example, as previously disclosed, in the second quarter of 2019, we discovered that an unauthorized party illegally targeted us using sophisticated techniques, such as stealing technical data in order to both impersonate our firewall update servers and possibly attempt other attack methodologies, in an effort to try to gain access to certain of our customers’ systems. We have completed our investigation of this incident and we do not believe that it had a material impact on our or our customers’ businesses. We are currently not aware of any claims arising from this matter.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001262039-20-000011:notes:184]
STOCKHOLDERS’ EQUITY

[0001262039-20-000011:notes:185]
Stock-Based Compensation Plans

[0001262039-20-000011:notes:186]
We have one primary stock incentive plan, the 2009 Equity Incentive Plan, under which we have granted RSUs and stock options. We also previously had an ESPP for eligible employees, which was terminated in February 2019.

[0001262039-20-000011:notes:187]
2009 Equity Incentive Plan—Our board of directors approved the 2009 Equity Incentive Plan in 2009. On June 21, 2019, our stockholders approved the Amended and Restated Fortinet, Inc. 2009 Equity Incentive Plan (the “Amended Plan”). Among other things, the Amended Plan provided for a net decrease in the number of shares of common stock that were authorized and available for issuance pursuant to future awards granted on or following the effective date of the Amended Plan. On June 28, 2019, we deregistered from various registration statements on Form S-8 an aggregate of 46.2 million shares of common stock that were originally registered for issuance under our 2009 Equity Incentive Plan.

[0001262039-20-000011:notes:188]
The maximum aggregate number of shares that may be issued under the Amended Plan is 47,873,531 shares; provided, however, that only 13,500,000 shares may be issued or transferred pursuant to new awards granted on or following the effective date of the Amended Plan. We may grant awards to employees, directors and other service providers. In the case of an incentive stock option granted to an employee who, at the time of the grant, owns stock representing more than 10% of the voting power of all classes of stock, the exercise price shall be no less than 110% of the fair market value per share on the date of grant and expire no more than five years from the date of grant, and options granted to any other employee, the per share exercise price shall be no less than 100% of the closing stock price on the date of grant. In the case of a non-statutory stock option and options granted to other service providers, the per share exercise price shall be no less than 100% of the fair market value per share on the date of grant. Options granted to individuals owning less than 10% of the total combined voting power of all classes of stock generally have a contractual term of no more than ten years and options generally vest over four years.

[0001262039-20-000011:notes:189]
As of December 31, 2019, there were a total of 13.4 million shares of common stock available for grant under the Amended Plan.

[0001262039-20-000011:notes:190]
2011 Employee Stock Purchase Plan—In June 2011, our stockholders approved the ESPP. The ESPP permitted eligible employees to purchase common stock through regular, systematic payroll deductions, up to a maximum of 15% of employees’ compensation for each purchase period at purchase prices equal to 85% of the lesser of the fair market value of our common stock at the first trading date of the applicable offering period or the purchase date, subject to purchase limits of 4,000 shares for each purchase period or $25,000 worth of stock for each calendar year. Our board of directors voluntarily determined to terminate the ESPP, effective February 2019 at the completion of the prior offering period.

[0001262039-20-000011:notes:191]
Restricted Stock Units

[0001262039-20-000011:notes:192]
The following table summarizes the activity and related information for RSUs for the periods presented below (in millions, except per share amounts):

[0001262039-20-000011:notes:193]
|  | Restricted Stock Units Outstanding |
|  | Number of Shares |  | Weighted-Average Grant Date Fair Value per Share |
| Balance—December 31, 2016 | 9.5 |  |  | $ | 31.01 |  |
| Granted | 4.2 |  |  | 37.60 |  |
| Forfeited | (1.3 | ) |  | 34.12 |  |
| Vested | (3.9 | ) |  | 29.42 |  |
| Balance—December 31, 2017 | 8.5 |  |  | 34.79 |  |
| Granted | 4.1 |  |  | 57.37 |  |
| Forfeited | (0.9 | ) |  | 39.29 |  |
| Vested | (3.9 | ) |  | 34.67 |  |
| Balance—December 31, 2018 | 7.8 |  |  | 46.07 |  |
| Granted | 2.7 |  |  | 87.09 |  |
| Forfeited | (0.7 | ) |  | 55.13 |  |
| Vested | (3.7 | ) |  | 43.31 |  |
| Balance—December 31, 2019 | 6.1 |  |  | $ | 64.56 |  |

[0001262039-20-000011:notes:194]
As of December 31, 2019, total compensation expense related to unvested RSUs granted to employees and non-employees under the 2009 Plan, but not yet recognized, was $341.1 million. This expense is expected to be amortized on a straight-line basis over a weighted-average vesting period of 2.7 years.

[0001262039-20-000011:notes:195]
RSUs settle into shares of common stock upon vesting. Upon the vesting of the RSUs, we net-settle the RSUs and withhold a portion of the shares to satisfy minimum statutory employee withholding tax requirements. Total payment of the employees’ tax obligations to the tax authorities is reflected as a financing activity within the consolidated statements of cash flows.

[0001262039-20-000011:notes:196]
The following summarizes the number and value of the shares withheld for employee taxes (in millions):

[0001262039-20-000011:notes:197]
|  | Year Ended December 31, |
|  | 2019 |  | 2018 |  | 2017 |
| Shares withheld for taxes | 1.1 |  |  | 1.2 |  |  | 1.2 |  |
| Amount withheld for taxes | $ | 96.0 |  |  | $ | 67.2 |  |  | $ | 45.1 |  |

[0001262039-20-000011:notes:198]
Employee Stock Options

[0001262039-20-000011:notes:199]
In determining the fair value of our employee stock options, we use the Black-Scholes option pricing model, which employs the following assumptions.

[0001262039-20-000011:notes:200]
Expected Term—The expected term represents the period that our stock-based awards are expected to be outstanding. We believe that we have sufficient historical experience for determining the expected term of the stock option award, and therefore, we calculated our expected term based on historical experience instead of using the simplified method.

[0001262039-20-000011:notes:201]
Expected Volatility—The expected volatility of our common stock is based on our weighted-average implied and historical volatility.

[0001262039-20-000011:notes:202]
Fair Value of Common Stock—The fair value of our common stock is the closing sales price of the common stock effective on the date of grant.

[0001262039-20-000011:notes:203]
Risk-Free Interest Rate—We base the risk-free interest rate on the implied yield available on U.S. Treasury zero-coupon issues with an equivalent remaining term.

[0001262039-20-000011:notes:204]
Expected Dividend—The expected dividend weighted-average assumption is zero.

[0001262039-20-000011:notes:205]
The following table summarizes the weighted-average assumptions relating to our employee stock options:

[0001262039-20-000011:notes:206]
|  | Year Ended December 31, |
|  | 2019 |  | 2018 |  | 2017 |
| Expected term in years | 4.4 |  |  | 4.4 |  |  | 4.4 |  |
| Volatility | 34.3 | % |  | 31.8 | % |  | 36.0 | % |
| Risk-free interest rate | 2.4 | % |  | 2.7 | % |  | 1.9 | % |
| Dividend rate | — | % |  | — | % |  | — | % |

[0001262039-20-000011:notes:207]
The following table summarizes the stock option activity and related information for the periods presented below (in millions, except exercise prices and contractual life):

[0001262039-20-000011:notes:208]
|  | Options Outstanding |
|  | Numberof Shares |  | Weighted-AverageExercisePrice |  | Weighted-AverageRemainingContractualLife (Years) |  | AggregateIntrinsicValue |
| Balance—December 31, 2016 | 6.2 |  |  | $ | 23.79 |  |  |  |  |  |
| Granted | 0.5 |  |  | 37.34 |  |  |  |  |  |
| Forfeited | (0.2 | ) |  | 31.75 |  |  |  |  |  |
| Exercised | (2.2 | ) |  | 19.19 |  |  |  |  |  |
| Balance—December 31, 2017 | 4.3 |  |  | 27.50 |  |  |  |  |  |
| Granted | 0.8 |  |  | 52.09 |  |  |  |  |  |
| Forfeited | (0.2 | ) |  | 32.24 |  |  |  |  |  |
| Exercised | (1.9 | ) |  | 24.96 |  |  |  |  |  |
| Balance—December 31, 2018 | 3.0 |  |  | 35.53 |  |  |  |  |  |  |
| Granted | 0.7 |  |  | 85.02 |  |  |  |  |  |
| Forfeited | (0.1 | ) |  | 62.93 |  |  |  |  |  |
| Exercised | (0.9 | ) |  | 30.21 |  |  |  |  |  |
| Balance—December 31, 2019 | 2.7 |  |  | $ | 50.37 |  |  |  |  |  |
| Options vested and expected to vest—December 31, 2019 | 2.7 |  |  | $ | 50.37 |  |  | 4.5 |  | $ | 150.3 |  |
| Options exercisable—December 31, 2019 | 1.4 |  |  | $ | 34.20 |  |  | 3.4 |  | $ | 99.3 |  |

[0001262039-20-000011:notes:209]
The aggregate intrinsic value represents the difference between the exercise price of stock options and the quoted market price of our common stock on December 31, 2019 for all in-the-money stock options. As of December 31, 2019, total compensation expense related to unvested stock options granted to employees but not yet recognized was $23.9 million. This expense is expected to be amortized on a straight-line basis over a weighted-average period of 2.7 years.

[0001262039-20-000011:notes:210]
Additional information related to our stock options is summarized below (in millions, except per share amounts):

[0001262039-20-000011:notes:211]
|  | Year Ended December 31, |
|  | 2019 |  | 2018 |  | 2017 |
| Weighted-average fair value per share granted | $ | 27.19 |  |  | $ | 16.03 |  |  | $ | 12.15 |  |
| Intrinsic value of options exercised | $ | 54.6 |  |  | $ | 62.2 |  |  | $ | 42.7 |  |
| Fair value of options vested | 10.1 |  |  | 7.2 |  |  | $ | 8.1 |  |

[0001262039-20-000011:notes:212]
The following table summarizes information about outstanding and exercisable stock options as of December 31, 2019, as follows (in millions, except exercise prices and contractual life):

[0001262039-20-000011:notes:213]
|  |  | Options Outstanding |  | Options Exercisable |
| Range of Exercise Prices |  | NumberOutstanding |  | Weighted-AverageRemainingContractualLife (Years) |  | Weighted-AverageExercisePrice |  | NumberExercisable |  | Weighted-AverageExercisePrice |
| $19.94-$24.51 |  | 0.7 |  |  | 2.7 |  | $ | 23.48 |  |  | 0.6 |  |  | $ | 23.46 |  |
| $26.49-$39.49 |  | 0.6 |  |  | 3.7 |  | 35.90 |  |  | 0.4 |  |  | 35.92 |  |
| $48.83-$72.75 |  | 0.7 |  |  | 4.9 |  | 47.25 |  |  | 0.4 |  |  | 50.44 |  |
| $76.22-$100.12 |  | 0.7 |  |  | 6.2 |  | 84.66 |  |  | — |  |  | 78.93 |  |
|  |  | 2.7 |  |  |  |  |  |  | 1.4 |  |  |  |

[0001262039-20-000011:notes:214]
Employee Stock Purchase Plan

[0001262039-20-000011:notes:215]
There were no grants under the ESPP during the year ended December 31, 2019. In determining the grant date fair value of the ESPP, we used the Black-Scholes option pricing model. The following table summarizes the assumptions used and the resulting grant-date fair values of our ESPP:

[0001262039-20-000011:notes:216]
|  | Year Ended December 31, |
|  | 2018 |  | 2017 |
| Expected term in years | 0.5 |  |  | 0.5 |  |
| Volatility | 28.9 | % |  | 29.5 | % |
| Risk-free interest rate | 2.0 | % |  | 0.9 | % |
| Dividend rate | — | % |  | — | % |
| Weighted-average fair value per share granted | $ | 14.14 |  |  | $ | 8.73 |  |

[0001262039-20-000011:notes:217]
Additional information related to the ESPP is provided below (in millions, except per share amounts):

[0001262039-20-000011:notes:218]
|  | Year Ended December 31, |
|  | 2019 |  | 2018 |  | 2017 |
| Shares issued under the ESPP | 0.3 |  |  | 1.1 |  |  | 1.1 |  |
| Weighted-average price per share issued | $ | 64.79 |  |  | $ | 35.32 |  |  | $ | 29.52 |  |

[0001262039-20-000011:notes:219]
Shares Reserved for Future Issuances

[0001262039-20-000011:notes:220]
The following table presents the common stock reserved for future issuance (in millions):

[0001262039-20-000011:notes:221]
|  | December 31, 2019 |
| Reserved for future equity award grants | 13.4 |  |
| Outstanding stock options and RSUs | 8.8 |  |
| Total common stock reserved for future issuances | 22.2 |  |

[0001262039-20-000011:notes:222]
Stock-based Compensation Expense

[0001262039-20-000011:notes:223]
Stock-based compensation expense is included in costs and expenses as follows (in millions):

[0001262039-20-000011:notes:224]
|  | Year Ended December 31, |
|  | 2019 |  | 2018 |  | 2017 |
| Cost of product revenue | $ | 1.5 |  |  | $ | 1.5 |  |  | $ | 1.4 |  |
| Cost of service revenue | 11.3 |  |  | 10.8 |  |  | 9.5 |  |
| Research and development | 38.7 |  |  | 36.4 |  |  | 32.2 |  |
| Sales and marketing | 101.7 |  |  | 95.6 |  |  | 78.0 |  |
| General and administrative | 20.9 |  |  | 18.6 |  |  | 16.1 |  |
| Total stock-based compensation expense | $ | 174.1 |  |  | $ | 162.9 |  |  | $ | 137.2 |  |

[0001262039-20-000011:notes:225]
The following table summarizes stock-based compensation expense by award type (in millions):

[0001262039-20-000011:notes:226]
|  | Year Ended December 31, |
|  | 2019 |  | 2018 |  | 2017 |
| RSUs | $ | 160.2 |  |  | $ | 143.9 |  |  | $ | 119.8 |  |
| Stock options | 12.6 |  |  | 8.8 |  |  | 7.3 |  |
| ESPP | 1.3 |  |  | 10.2 |  |  | 10.1 |  |
| Total stock-based compensation expense | $ | 174.1 |  |  | $ | 162.9 |  |  | $ | 137.2 |  |

[0001262039-20-000011:notes:227]
Total income tax benefit associated with stock-based compensation that is recognized in the consolidated statements of income is as follows (in millions):

[0001262039-20-000011:notes:228]
|  | Year Ended December 31, |
|  | 2019 |  | 2018 |  | 2017 |
| Income tax benefit associated with stock-based compensation | $ | 38.3 |  |  | $ | 24.9 |  |  | $ | 30.9 |  |

[0001262039-20-000011:notes:229]
Share Repurchase Program

[0001262039-20-000011:notes:230]
In January 2016, our board of directors approved the Share Repurchase Program (the “Repurchase Program”), which authorized the repurchase of up to $200.0 million of our outstanding common stock through December 31, 2017. In 2016 and 2017, our board of directors approved the increases in the aggregate authorized repurchase amount under the Repurchase Program by $100.0 million and $700.0 million, respectively, to a total of $1.0 billion. In July 2018, our board of directors approved a $500.0 million increase in the authorized stock repurchase under the Repurchase program and extended the term of the Repurchase Program to December 31, 2019, bringing the aggregate amount authorized to be repurchased to $1.5 billion of our outstanding common stock through December 31, 2019. In November 2019, our board of directors approved a $1 billion increase in the authorized stock repurchase under the Repurchase program and extended the term of the Repurchase Program to

[0001262039-20-000011:notes:231]
February 28, 2021, bringing the aggregate amount authorized to be repurchased to $2.5 billion of our outstanding common stock through February 28, 2021.Under the Repurchase Program, share repurchases may be made by us from time to time in privately negotiated transactions or in open market transactions. The Repurchase Program does not require us to purchase a minimum number of shares, and may be suspended, modified or discontinued at any time without prior notice. In 2019, we repurchased 1.9 million shares of common stock under the Repurchase Program in open market transactions for an aggregate purchase price of $140.9 million. As of December 31, 2019, $1.6 billion remained available for future share repurchases under the Repurchase Program.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001262039-20-000011:notes:232]
INCOME TAXES

[0001262039-20-000011:notes:233]
Income before income taxes consisted of the following (in millions):

[0001262039-20-000011:notes:234]
|  | Year Ended December 31, |
|  | 2019 |  | 2018 |  | 2017 |
| Domestic | $ | 364.9 |  |  | $ | 0.3 |  |  | $ | (40.7 | ) |
| Foreign | 14.3 |  |  | 250.6 |  |  | 164.7 |  |
| Total income before income taxes | $ | 379.2 |  |  | $ | 250.9 |  |  | $ | 124.0 |  |

[0001262039-20-000011:notes:235]
Due to the realignment of our tax structure, income before income taxes moved from foreign jurisdictions to domestic jurisdiction in the year ended December 31, 2019.

[0001262039-20-000011:notes:236]
The provision for (benefit from) income taxes consisted of the following (in millions):

[0001262039-20-000011:notes:237]
|  | Year Ended December 31, |
|  | 2019 |  | 2018 |  | 2017 |
| Current: |  |  |  |  |  |
| Federal | $ | 11.0 |  |  | $ | (12.6 | ) |  | $ | 34.7 |  |
| State | 0.1 |  |  | 2.0 |  |  | 0.8 |  |
| Foreign | 11.4 |  |  | 36.9 |  |  | 27.7 |  |
| Total current | $ | 22.5 |  |  | $ | 26.3 |  |  | $ | 63.2 |  |
| Deferred: |  |  |  |  |  |
| Federal | $ | 39.0 |  |  | $ | (125.5 | ) |  | $ | 39.1 |  |
| State | (6.0 | ) |  | 14.4 |  |  | (9.3 | ) |
| Foreign | (2.8 | ) |  | 3.5 |  |  | (0.4 | ) |
| Total deferred | 30.2 |  |  | (107.6 | ) |  | 29.4 |  |
| Provision for (benefit from) income taxes | $ | 52.7 |  |  | $ | (81.3 | ) |  | $ | 92.6 |  |

[0001262039-20-000011:notes:238]
The foreign tax provision included the tax impacts from U.S. GAAP to local tax return book to tax differences and return to provision adjustments that create a permanent addback including but not limited to stock compensation, meals and entertainment, and settlement of prior year tax audits with foreign jurisdiction adjustments.

[0001262039-20-000011:notes:239]
The provision for (benefit from) income taxes differs from the amount computed by applying the statutory federal income tax rate as follows (in millions):

[0001262039-20-000011:notes:240]
|  | Year Ended December 31, |
|  | 2019 |  | 2018 |  | 2017 |
| Tax at federal statutory tax rate | $ | 79.6 |  |  | $ | 52.7 |  |  | $ | 43.4 |  |
| Foreign income taxed at different rates | 12.3 |  |  | (21.5 | ) |  | (19.5 | ) |
| Foreign withholding taxes | 16.0 |  |  | 20.1 |  |  | 17.4 |  |
| Stock-based compensation expense | (30.6 | ) |  | (14.3 | ) |  | 9.5 |  |
| Foreign tax credit | (30.4 | ) |  | (15.8 | ) |  | (12.8 | ) |
| State taxes—net of federal benefit | (11.3 | ) |  | 1.2 |  |  | (3.5 | ) |
| Research and development credit | (6.8 | ) |  | (5.0 | ) |  | (4.0 | ) |
| Valuation allowance | 22.0 |  |  | 14.9 |  |  | — |  |
| Dividend distribution | — |  |  | (3.8 | ) |  | — |  |
| Impact of the 2017 Tax Act: |  |  |  |  |  |
| Deferred tax asset remeasurement due to reduction in the federal corporate income tax rate | — |  |  | — |  |  | 47.9 |  |
| One-time transition tax | (2.1 | ) |  | 32.6 |  |  | 15.2 |  |
| Global Intangible Low-Taxed Income | — |  |  | 20.5 |  |  | — |  |
| Book-to-Tax Basis differences | — |  |  | (164.0 | ) |  | — |  |
| Other | 4.0 |  |  | 1.1 |  |  | (1.0 | ) |
| Total provision for (benefit from) income taxes | $ | 52.7 |  |  | $ | (81.3 | ) |  | $ | 92.6 |  |

[0001262039-20-000011:notes:241]
There are permanent differences that arise from the portion of stock-based compensation expense that is not expected to generate a tax deduction, such as stock-based compensation expense on stock grants to certain foreign employees. This is offset by the actual tax benefits in the current periods from shares held by our U.S. and certain foreign employees. In 2019 and 2018, this excess tax benefit was greater than the non-deductible stock-based compensation expense.

[0001262039-20-000011:notes:242]
We have realigned our tax structure in order to maximize the tax efficiency of our group structure and better align with our business operations as a result of the 2017 Tax Act. This realignment resulted in a book-to-tax basis difference for previously taxed off-shore deferred revenue as well as other book-to-tax difference. The basis differences resulted in a $164.0 million benefit to the 2018 tax provision.

[0001262039-20-000011:notes:243]
In the fourth quarter of 2018, we completed our analysis to determine the effect of the 2017 Tax Act within the measurement period under the SEC guidance, and reflected an additional $32.6 million increase related to the transition tax in the 2018 income tax expense. In the fourth quarter of 2019, we recorded a $2.1 million tax benefit related to the transition tax due to the adjustments on prior 2018 foreign tax amounts. The 2017 Tax Act also created a new requirement that Global Intangible Low-Taxed Income (“GILTI”) earned by controlled foreign corporations (“CFCs”) must be included currently in the gross income of a CFC’s U.S. shareholder. In 2018, there was also a $20.5 million expense for the GILTI tax regime that was introduced by the 2017 Tax Act. In 2019, we were not subject to GILTI. We will continue to monitor and assess the impact of the 2017 Tax Act and ongoing guidance and accounting interpretations issued in response to the 2017 Tax Act.

[0001262039-20-000011:notes:244]
On June 7, 2019, the Ninth Circuit overturned the U.S. Tax Court’s decision on Altera Corporation and Subsidiaries vs. Commissioner of Internal Revenue and ruled in favor of the Commissioner, validating the regulations requiring stock-based compensation to be included in a cost sharing arrangement. A rehearing of the case was requested, but the rehearing request was denied by the Ninth Circuit on November 12, 2019. A petition for Writ of Certiorari was filed with the U.S. Supreme Court on February 10, 2020. Due to the uncertainty surrounding the status of the current regulations and questions related to the scope of potential benefits or obligations, we incurred an unrecognized tax benefit of $10.1 million related to the Ninth Circuit’s Altera decision regarding stock-based compensation in cost sharing arrangements. We continue to monitor developments in this case and any impact it could have on our tax provision.

[0001262039-20-000011:notes:245]
The tax effects of temporary differences that give rise to significant portions of the deferred tax assets as of the years ended are presented below (in millions):

[0001262039-20-000011:notes:246]
|  | December 31, 2019 |  | December 31, 2018 |
| Deferred tax assets: |  |  |  |
| General business credit carryforward | $ | 73.2 |  |  | $ | 29.5 |  |
| Deferred revenue | 152.1 |  |  | 223.9 |  |
| Reserves and accruals | 30.7 |  |  | 26.6 |  |
| Net operating loss carryforward | 57.9 |  |  | 13.5 |  |
| Stock-based compensation expense | 14.8 |  |  | 16.2 |  |
| Depreciation and amortization | 0.7 |  |  | 3.3 |  |
| Operating lease liabilities | 10.6 |  |  | — |  |
| Total deferred tax assets | 340.0 |  |  | 313.0 |  |
| Less: Valuation allowance | (43.0 | ) |  | (14.9 | ) |
| Deferred tax assets, net of valuation allowance | 297.0 |  |  | 298.1 |  |
| Deferred tax liabilities: |  |  |  |
| Deferred contract costs | (59.9 | ) |  | (52.1 | ) |
| Operating lease ROU assets | (9.5 | ) |  | — |  |
| Total deferred tax liabilities | (69.4 | ) |  | (52.1 | ) |
| Net deferred tax assets | $ | 227.6 |  |  | $ | 246.0 |  |

[0001262039-20-000011:notes:247]
As of December 31, 2019, we recorded a deferred tax asset of $232.6 million and a deferred tax liability of $5.0 million. In assessing the realizability of deferred tax assets, we considered whether it is more likely than not that some portion or all of our deferred tax assets will be realized. This realization is dependent upon the generation of future taxable income during the periods in which those temporary differences become deductible. We concluded that it is more likely than not that we will be able to realize the benefits of our deferred tax assets in the future except for our California research and development (“R&D”) credits carryforward, certain impairment losses in business investments, certain foreign tax credits from foreign disregarded entities and certain tax attributes from business acquisitions. We anticipate having sufficient current year generated California R&D credits to cover the same year California tax liability for tax year 2019 and subsequent years. We also believe that it is more likely than not that the deferred tax assets for impairment losses, foreign tax credits from foreign disregarded entities and acquired foreign tax attributes will not be realized. As a result, we recorded a valuation allowance of $43.0 million against deferred tax assets for California R&D credits carryforwards (net of the unrecognized tax benefits), impairment losses, certain foreign tax credits and certain acquired tax attributes.

[0001262039-20-000011:notes:248]
As of December 31, 2019, we had $46.7 million in federal net operating loss carryforwards to offset future income, which are limited by Section 382 of the Internal Revenue Code (“Section 382”) due to the acquisition of Meru, AccelOps and Bradford. With the acquisition of Meru, we had $22.6 million in federal net operating loss carryforwards which are limited by Section 382 available from year 2020. With the acquisition of AccelOps, we had $16.3 million in federal net operating loss carryforwards from 2016 that are limited by Section 382. With the acquisition of Bradford, we had $7.8 million in federal net operating loss carryforwards from 2018 that are limited by Section 382 available from July 2018. In 2019, it is estimated that a federal net operating loss of $169.4 million will be generated. We had $14.7 million in federal tax credits to offset future federal taxes. As of December 31, 2019, we had $35.5 million in California net operating loss carryforwards including $10.7 million from Meru and $13.4 million from AccelOps, both of which are limited by Section 382. In 2019, it is estimated that a California net operating loss of $11.3 million will be generated. We had state tax credit carryforwards of $30.6 million available to offset our future state taxes. The state credits carry forward indefinitely.

[0001262039-20-000011:notes:249]
Under the 2017 Tax Act, starting on January 1, 2018, we are no longer subject to federal income tax on earnings remitted from our foreign subsidiaries. We have analyzed our global working capital and cash requirements and the potential tax liabilities attributable to repatriation, and have determined that we will be repatriating certain unremitted foreign earnings which was previously deemed indefinitely reinvested. For those investments from which we were able to make a reasonable estimate of the tax effects of such repatriation, we have recorded a provisional estimate for withholding and state taxes. For those investments from which we were not able to make a reasonable estimate, we have not recorded any deferred taxes.

[0001262039-20-000011:notes:250]
We operate under a tax incentive agreement in Singapore, which is effective through December 31, 2020. The tax incentive agreement is conditional upon our meeting certain employment and investment thresholds.

[0001262039-20-000011:notes:251]
As of December 31, 2019, we had $67.5 million of unrecognized tax benefits, of which, if recognized, $62.4 million would favorably affect our effective tax rate. Our policy is to include accrued interest and penalties related to uncertain tax benefits in income tax expense. As of December 31, 2019, 2018 and 2017, accrued interest and penalties were $14.1 million, $11.6 million and $13.5 million, respectively.

[0001262039-20-000011:notes:252]
The aggregate changes in the balance of unrecognized tax benefits are as follows (in millions):

[0001262039-20-000011:notes:253]
|  | Year Ended December 31, |
|  | 2019 |  | 2018 |  | 2017 |
| Unrecognized tax benefits, beginning of year | $ | 63.5 |  |  | $ | 72.5 |  |  | $ | 65.5 |  |
| Gross increases for tax positions related to the current year | 11.4 |  |  | 8.6 |  |  | 13.2 |  |
| Gross decreases for tax positions related to the current year | — |  |  | — |  |  | (10.7 | ) |
| Gross increases for tax positions related to the prior year | 3.0 |  |  | 6.0 |  |  | 7.0 |  |
| Gross decreases for tax positions related to prior year | (0.3 | ) |  | (9.5 | ) |  | (0.9 | ) |
| Gross decreases for tax positions related to prior year audit settlements | (1.7 | ) |  | (6.4 | ) |  | (1.6 | ) |
| Gross decreases for tax positions related to expiration of statute of limitations | (8.4 | ) |  | (7.7 | ) |  | — |  |
| Unrecognized tax benefits, end of year | $ | 67.5 |  |  | $ | 63.5 |  |  | $ | 72.5 |  |

[0001262039-20-000011:notes:254]
As of December 31, 2019, 2018 and 2017, $82.8 million, $77.5 million and $90.2 million, respectively, of the amounts reflected above were recorded as Income tax liabilities—non-current in our consolidated balance sheets.

[0001262039-20-000011:notes:255]
We recorded a net increase of gross unrecognized tax benefits of approximately $4.0 million during the year ended December 31, 2019. The net increase was primarily due to the increase in gross unrecognized tax benefits related to the Altera case, offset by the reversal of gross unrecognized tax benefits in connection with the lapse of statutes of limitations and the settlement of tax audits in foreign jurisdictions.

[0001262039-20-000011:notes:256]
It is reasonably possible that our gross unrecognized tax benefits will decrease by up to $11.6 million in the next 12 months, primarily due to the lapse of the statute of limitations. These adjustments, if recognized, would positively impact our effective tax rate, and would be recognized as additional tax benefits.

[0001262039-20-000011:notes:257]
We file income tax returns in the U.S. federal jurisdiction and in various U.S. state and foreign jurisdictions. Generally, we are no longer subject to U.S. state and non-U.S. income tax examinations by tax authorities for tax years prior to 2009. We are no longer subject to examination by U.S federal income tax authorities for tax years prior to 2015. We currently have ongoing tax audits in the United Kingdom, Canada and several other foreign jurisdictions. The focus of these audits is the inter-company profit allocation.


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0001262039-20-000011:notes:258]
DEFINED CONTRIBUTION PLANS

[0001262039-20-000011:notes:259]
Our tax-deferred savings plan under our 401(k) Plan permits participating U.S. employees to contribute a portion of their pre-tax or after-tax earnings. In Canada, we have a Group Registered Retirement Savings Plan Program (the “RRSP”), which permits participants to make tax deductible contributions. Our board of directors approved 50% matching contributions on employee contributions up to 4% of each employee’s eligible earnings. Our matching contributions to our 401(k) Plan and the RRSP for 2019, 2018 and 2017 were $6.6 million, $5.7 million and $4.7 million, respectively.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001262039-20-000011:notes:260]
SEGMENT INFORMATION

[0001262039-20-000011:notes:261]
Operating segments are defined as components of an enterprise about which separate financial information is available that is evaluated regularly by the chief operating decision maker in deciding how to allocate resources and in assessing

[0001262039-20-000011:notes:262]
performance. Our chief operating decision maker is our chief executive officer. Our chief executive officer reviews financial information presented on a consolidated basis, accompanied by information about revenue by geographic region for purposes of allocating resources and evaluating financial performance. We have one business activity, and there are no segment managers who are held accountable for operations, operating results and plans for levels or components below the consolidated unit level. Accordingly, we have determined that we have one operating segment, and therefore, one reportable segment.

[0001262039-20-000011:notes:263]
Revenue by geographic region is based on the billing address of our customers. The following tables set forth revenue and property and equipment—net by geographic region (in millions):

[0001262039-20-000011:notes:264]
|  | Year Ended December 31, |
| Revenue | 2019 |  | 2018 |  | 2017 |
| Americas: |  |  |  |  |  |
| United States | $ | 693.3 |  |  | $ | 577.2 |  |  | $ | 496.9 |  |
| Other Americas (1) | 224.0 |  |  | 185.7 |  |  | 145.4 |  |
| Total Americas | 917.3 |  |  | 762.9 |  |  | 642.3 |  |
| Europe, Middle East and Africa (“EMEA”) | 813.9 |  |  | 678.0 |  |  | 554.6 |  |
| Asia Pacific (“APAC”) | 425.0 |  |  | 360.3 |  |  | 298.0 |  |
| Total revenue | $ | 2,156.2 |  |  | $ | 1,801.2 |  |  | $ | 1,494.9 |  |
| (1) In 2019, Canada and Latin America revenue were combined and presented as Other Americas. Prior periods have been reclassified to conform with current period presentation. |

[0001262039-20-000011:notes:265]
| Property and Equipment—net | December 31, 2019 |  | December 31, 2018 |
| Americas: |  |  |  |
| United States | $ | 197.4 |  |  | $ | 132.1 |  |
| Canada | 120.5 |  |  | 113.5 |  |
| Latin America | 5.5 |  |  | 0.4 |  |
| Total Americas | 323.4 |  |  | 246.0 |  |
| EMEA | 15.2 |  |  | 16.2 |  |
| APAC | 5.7 |  |  | 9.2 |  |
| Total property and equipment—net | $ | 344.3 |  |  | $ | 271.4 |  |


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001262039-20-000011:notes:266]
ACCUMULATED OTHER COMPREHENSIVE INCOME (LOSS)

[0001262039-20-000011:notes:267]
The following table summarizes the changes in accumulated balances of other comprehensive income (loss) (in millions):

[0001262039-20-000011:notes:268]
|  | Year Ended December 31, 2019 |
|  | Unrealized Gains (Losses) on Investments |  | Tax provision (benefit) related to unrealized gains or losses on investments |  | Total |
| Beginning balance | $ | (1.3 | ) |  | $ | (0.5 | ) |  | $ | (0.8 | ) |
| Other comprehensive income before reclassifications | 2.5 |  |  | 0.5 |  |  | 2.0 |  |
| Amounts reclassified from accumulated other comprehensive income (loss) | — |  |  | 0.1 |  |  | (0.1 | ) |
| Net current-period other comprehensive income | 2.5 |  |  | 0.6 |  |  | 1.9 |  |
| Ending balance | $ | 1.2 |  |  | $ | 0.1 |  |  | $ | 1.1 |  |

[0001262039-20-000011:notes:269]
We adopted ASU 2018-02 on January 1, 2019, and elected to reclassify the income tax effects of the 2017 Tax Act to retained earnings at the beginning of the period. Other amounts reclassified from accumulated other comprehensive income (loss) for unrealized losses on investments and tax provision related to unrealized gains or losses on investments are recorded in other income (expense)—net and in provision for (benefit from) income taxes, respectively. We did not have any material changes to accumulated other comprehensive income (loss) during 2018.


## us-gaap:SubsequentEventsTextBlock

[0001262039-20-000011:notes:270]
SUBSEQUENT EVENT

[0001262039-20-000011:notes:271]
In January 2020, we entered into an agreement with a competitor in the network security industry, whereby, in February 2020, this party paid us a lump sum of $50.0 million for a seven-year mutual covenant-not-to-sue for patent claims. Pursuant to this agreement, at the end of this first seven-year period, either party may extend the agreement for an additional seven-year mutual covenant-not-to-sue in return for this competitor paying us an additional $50.0 million, for an aggregate payment of $100.0 million by the competitor to us. This agreement arose after expiration of previous agreements between the parties whereby the competitor had paid us additional sums for a limited term license to certain of our intellectual property and a limited term mutual covenant-not-to-sue.


## srt:ScheduleOfValuationAndQualifyingAccountsDisclosureTextBlock

[0001262039-20-000011:notes:272]
SCHEDULE II—VALUATION AND QUALIFYING ACCOUNTS

[0001262039-20-000011:notes:273]
|  | Year Ended December 31, |
|  | 2019 (1) |  | 2018 (1) |  | 2017 |
|  | (in millions) |
| Sales Returns Reserve and Allowance for Doubtful Accounts: |  |  |  |  |  |
| Beginning balance | $ | 0.9 |  |  | $ | 14.5 |  |  | $ | 11.2 |  |
| Charged to costs and expenses, net of deductions | 0.3 |  |  | — |  |  | 3.3 |  |
| Reclassification due to adoption of Topic 606 (1) | — |  |  | (13.6 | ) |  | — |  |
| Ending balance | $ | 1.2 |  |  | $ | 0.9 |  |  | $ | 14.5 |  |
| (1) Effective January 1, 2018, we reclassified our sales returns reserve in the amount of $13.6 million from accounts receivable to accrued liabilities, in connection with the adoption of Topic 606. The ending balances for the years ended December 31, 2019 and 2018 consist only of the allowance for doubtful accounts. |

[0001262039-20-000011:notes:274]
Schedules not listed above have been omitted because they are not applicable or are not required or the information required to be set forth therein is included in the consolidated financial statements or notes thereto.

[0001262039-20-000011:notes:275]
| 3. | Exhibits: See Item 15(b) below. We have filed, or incorporated into this Annual Report on Form 10-K by reference, the exhibits listed on the accompanying Exhibit Index immediately preceding the signature page of this Annual Report on Form 10-K. |

[0001262039-20-000011:notes:276]
(b) Exhibits:

[0001262039-20-000011:notes:277]
The exhibit list in the Exhibit Index immediately preceding the signature page of this Annual Report on Form 10-K is incorporated herein by reference as the list of exhibits required by this Item 15(b).

[0001262039-20-000011:notes:278]
(c) Financial Statement Schedules: See Item 15(a) above.
