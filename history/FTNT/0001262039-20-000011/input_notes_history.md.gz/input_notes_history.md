# FTNT note change history — 0001262039-19-000023 → 0001262039-19-000033


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2019-10-31):
[0001262039-19-000033:note_history:1]
The following table summarizes our future principal contractual obligations as of September 30, 2019 (in millions):
  (was, 2019-08-01, similarity 0.9488):
[0001262039-19-000023:note_history:1]
The following table summarizes our future principal contractual obligations as of June 30, 2019 (in millions):

- changed (2019-10-31):
[0001262039-19-000033:note_history:2]
Inventory Purchase Commitments—Our independent contract manufacturers procure components and build our products based on our forecasts. These forecasts are based on estimates of future demand for our products, which are in turn based on historical trends and an analysis from our sales and marketing organizations, adjusted for overall market conditions. In order to reduce manufacturing lead times and plan for adequate component supply, we may issue purchase orders to some of our independent contract manufacturers which may not be cancelable. As of September 30, 2019, we had $241.4 million of open purchase orders with our independent contract manufacturers that may not be cancelable.
  (was, 2019-08-01, similarity 0.9904):
[0001262039-19-000023:note_history:2]
Inventory Purchase Commitments—Our independent contract manufacturers procure components and build our products based on our forecasts. These forecasts are based on estimates of future demand for our products, which are in turn based on historical trends and an analysis from our sales and marketing organizations, adjusted for overall market conditions. In order to reduce manufacturing lead times and plan for adequate component supply, we may issue purchase orders to some of our independent contract manufacturers which may not be cancelable. As of June 30, 2019, we had $218.9 million of open purchase orders with our independent contract manufacturers that may not be cancelable.

- changed (2019-10-31):
[0001262039-19-000033:note_history:3]
Other Contractual Commitments and Open Purchase Orders—In addition to commitments with contract manufacturers, we have open purchase orders and contractual obligations in the ordinary course of business for which we have not received goods or services. As of September 30, 2019, we had $12.6 million in other contractual commitments having a remaining term in excess of one year that may not be cancelable.
  (was, 2019-08-01, similarity 0.9835):
[0001262039-19-000023:note_history:3]
Other Contractual Commitments and Open Purchase Orders—In addition to commitments with contract manufacturers, we have open purchase orders and contractual obligations in the ordinary course of business for which we have not received goods or services. As of June 30, 2019, we had $22.8 million in other contractual commitments having a remaining term in excess of one year that may not be cancelable.

- added (2019-10-31):
[0001262039-19-000033:note_history:4]
Periodically we, like other security companies and companies in other industries, may experience cybersecurity threats, malicious activity directed against our information technology infrastructure and unauthorized attempts to gain access to our and our customers’ sensitive information and systems. For example, as previously disclosed, in the second quarter of 2019, we discovered that an unauthorized party illegally targeted us using sophisticated techniques, such as stealing technical data in order to both impersonate our firewall update servers and possibly attempt other attack methodologies, in an effort to try to gain access to certain of our customers’ systems. We have substantially completed our investigation of this incident and we do not currently believe that it had a material impact on our business, including our customers. We are currently not aware of any claims arising from this matter.

- removed (2019-10-31):
[0001262039-19-000023:note_history:5]
Periodically we, like other security companies and companies in other industries, may experience cybersecurity threats, threats to our information technology infrastructure and unauthorized attempts to gain access to our and our customers’ sensitive information and systems. For example, in the second quarter of 2019, we discovered that an unauthorized party illegally targeted us using sophisticated techniques, such as stealing technical data in order to both impersonate our firewall update servers and possibly attempt other attack methodologies, in an effort to try to gain access to certain of our customers’ systems. We are in the process of investigating and evaluating this matter, and, although at this time there can be no assurances as to the outcome and impact of this matter, which are currently not determinable and not predictable, we currently are unaware of any existing claims or proceedings related to this matter, including any that we believe are likely to have a material adverse effect on our financial position. There are many uncertainties associated with these types of incidents and possible impacts associated with a cybersecurity attack or other events may include remediation costs related to lost, stolen or compromised

- removed (2019-10-31):
[0001262039-19-000023:note_history:6]
data, repairs to data processing systems, increased cybersecurity protection costs, adverse effects on our compliance with laws and regulations, litigation and reputational damage.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2019-10-31):
[0001262039-19-000033:note_history:7]
Basis of Presentation and Preparation—The unaudited condensed consolidated financial statements of Fortinet, Inc. and its wholly owned subsidiaries (collectively, “we,” “us” or “our”) have been prepared in accordance with generally accepted accounting principles in the United States (“GAAP”) for interim financial information, as well as the instructions to Form 10-Q pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (the “SEC”). Accordingly, they do not include all of the information and footnotes required by GAAP for complete financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the year ended December 31, 2018, contained in our Annual Report on Form 10-K filed with the SEC on February 27, 2019. In the opinion of management, all adjustments, which includes normal recurring adjustments, considered necessary for a fair presentation have been included. All intercompany balances, transactions and cash flows have been eliminated. The results of operations for the three and nine months ended September 30, 2019 are not necessarily indicative of the results for the full year or for any future periods. The condensed consolidated balance sheet as of December 31, 2018 is derived from the audited consolidated financial statements for the year ended December 31, 2018.
  (was, 2019-08-01, similarity 0.8088):
[0001262039-19-000023:note_history:7]
Basis of Presentation and Preparation—The unaudited condensed consolidated financial statements of Fortinet, Inc. and its wholly owned subsidiaries (collectively, “we,” “us” or “our”) have been prepared in accordance with generally accepted accounting principles in the United States (“GAAP”) for interim financial information, as well as the instructions to Form 10-Q pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (the “SEC”). Accordingly, they do not include all of the information and footnotes required by GAAP for complete financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the year ended December 31, 2018, contained in our Annual Report on Form 10-K filed with the SEC on February 27, 2019. In the opinion of management, all adjustments, which includes normal recurring adjustments, considered necessary for a fair presentation have been included. All intercompany balances, transactions and cash flows have been eliminated. The results of operations for the three and six months ended June 30, 2019 are not necessarily indicative of the results for the full year or for any future periods. The condensed consolidated balance sheet as of December 31, 2018 is derived from the audited consolidated financial statements for the year ended December 31, 2018.

- changed (2019-10-31):
[0001262039-19-000033:note_history:8]
There have been no material changes to our significant accounting policies as of and for the three and nine months ended September 30, 2019, except for the accounting policies for leases that were updated as a result of adopting Accounting Standards Update (“ASU”) 2016-02—Leases (Topic 842) (“Topic 842”). For more information, refer to the “Recently Adopted Accounting Standards” and Note 10.
  (was, 2019-08-01, similarity 0.9733):
[0001262039-19-000023:note_history:8]
There have been no material changes to our significant accounting policies as of and for the three and six months ended June 30, 2019, except for the accounting policies for leases that were updated as a result of adopting Accounting Standards Update (“ASU”) 2016-02—Leases (Topic 842) (“Topic 842”). For more information, refer to the “Recently Adopted Accounting Standards” and Note 10.

- changed (2019-10-31):
[0001262039-19-000033:note_history:9]
Under the new guidance, we determine if an arrangement contains a lease and the classification of that lease, if applicable, at inception or upon modification of a contract. We have elected to not recognize a lease liability or ROU asset for short-term leases (leases that, at the commencement date, have a lease term of twelve months or less and do not include an option to purchase the underlying asset that the Company is reasonably certain to exercise). We have elected to not allocate the contract consideration for operating lease contracts with lease and non-lease components, and account for the lease and non-lease components as a single lease component. ROU assets represent our right to use an underlying asset for the lease term. Lease liabilities represent our obligation to make lease payments under the lease. Operating lease ROU assets and liabilities are recognized at the lease commencement date based on the present value of lease payments over the lease term. The implicit rate within our operating leases is generally not determinable and therefore we use our incremental borrowing rate at the lease commencement date to determine the present value of lease payments. The determination of our incremental borrowing rate requires judgment. We determine our incremental borrowing rate for each lease using indicative bank borrowing rates, adjusted for various factors including level of collateralization, term and currency to align with the terms of a lease. The operating lease ROU asset also includes any lease prepayments, net of lease incentives. Certain leases include options to extend or terminate the lease. An option to extend the lease is considered in connection with determining the ROU asset and lease liability when it is reasonably certain we will exercise that option. An option to terminate is considered unless it is reasonably certain we will not exercise the option.
  (was, 2019-08-01, similarity 0.9982):
[0001262039-19-000023:note_history:9]
Under the new guidance, we determine if an arrangement contains a lease and the classification of that lease, if applicable, at inception or upon modification of a contract. We have elected to not recognize a lease liability or ROU asset for short-term leases (leases that, at the commencement date, have a lease term of twelve months or less and do not include an option to purchase the underlying asset that the Company is reasonably certain to exercise). We have elected to not allocate the contract consideration for operating lease contracts with lease and non-lease components, and account for the lease and non-lease components as a single lease component. ROU assets represent our right to use an underlying asset for the lease term. Lease liabilities represent our obligation to make lease payments under the lease. Operating lease ROU assets and liabilities are recognized at the lease commencement date based on the present value of lease payments over the lease term. The implicit rate within our operating leases is generally not determinable and therefore we use our incremental borrowing rate at the lease commencement date to determine the present value of lease payments. The determination of our incremental borrowing rate requires judgment. We determine our incremental borrowing rate for each lease using indicative bank borrowing rates, adjusted for various factors including level of collateralization, term and currency to align with the terms of a lease. The operating lease ROU asset also includes any lease prepayments, net of lease incentives. Certain of our leases include options to extend or terminate the lease. An option to extend the lease is considered in connection with determining the ROU asset and lease liability when it is reasonably certain we will exercise that option. An option to terminate is considered unless it is reasonably certain we will not exercise the option.


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2019-10-31):
[0001262039-19-000033:note_history:10]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30, 2019 |  | September 30, 2018 |  | September 30, 2019 |  | September 30, 2018 |
| Product | $ | 197.1 |  |  | $ | 164.5 |  |  | $ | 549.7 |  |  | $ | 473.6 |  |
| Service: |  |  |  |  |  |  |  |
| Security subscription | 192.8 |  |  | 157.0 |  |  | 545.5 |  |  | 440.7 |  |
| Technical support and other | 157.6 |  |  | 132.4 |  |  | 446.6 |  |  | 379.9 |  |
| Total service revenue | 350.4 |  |  | 289.4 |  |  | 992.1 |  |  | 820.6 |  |
| Total revenue | $ | 547.5 |  |  | $ | 453.9 |  |  | $ | 1,541.8 |  |  | $ | 1,294.2 |  |
  (was, 2019-08-01, similarity 0.8694):
[0001262039-19-000023:note_history:10]
|  | Three Months Ended |  | Six Months Ended |
|  | June 30, 2019 |  | June 30, 2018 |  | June 30, 2019 |  | June 30, 2018 |
| Product | $ | 189.9 |  |  | $ | 166.3 |  |  | $ | 352.6 |  |  | $ | 309.1 |  |
| Service: |  |  |  |  |  |  |  |
| Security subscription | 183.1 |  |  | 147.1 |  |  | 352.7 |  |  | 283.8 |  |
| Technical support and other | 148.7 |  |  | 127.9 |  |  | 289.0 |  |  | 247.4 |  |
| Total service revenue | 331.8 |  |  | 275.0 |  |  | 641.7 |  |  | 531.2 |  |
| Total revenue | $ | 521.7 |  |  | $ | 441.3 |  |  | $ | 994.3 |  |  | $ | 840.3 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2019-10-31):
[0001262039-19-000033:note_history:11]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30, 2019 |  | September 30, 2018 |  | September 30, 2019 |  | September 30, 2018 |
| Product | $ | 197.1 |  |  | $ | 164.5 |  |  | $ | 549.7 |  |  | $ | 473.6 |  |
| Service: |  |  |  |  |  |  |  |
| Security subscription | 192.8 |  |  | 157.0 |  |  | 545.5 |  |  | 440.7 |  |
| Technical support and other | 157.6 |  |  | 132.4 |  |  | 446.6 |  |  | 379.9 |  |
| Total service revenue | 350.4 |  |  | 289.4 |  |  | 992.1 |  |  | 820.6 |  |
| Total revenue | $ | 547.5 |  |  | $ | 453.9 |  |  | $ | 1,541.8 |  |  | $ | 1,294.2 |  |
  (was, 2019-08-01, similarity 0.8694):
[0001262039-19-000023:note_history:11]
|  | Three Months Ended |  | Six Months Ended |
|  | June 30, 2019 |  | June 30, 2018 |  | June 30, 2019 |  | June 30, 2018 |
| Product | $ | 189.9 |  |  | $ | 166.3 |  |  | $ | 352.6 |  |  | $ | 309.1 |  |
| Service: |  |  |  |  |  |  |  |
| Security subscription | 183.1 |  |  | 147.1 |  |  | 352.7 |  |  | 283.8 |  |
| Technical support and other | 148.7 |  |  | 127.9 |  |  | 289.0 |  |  | 247.4 |  |
| Total service revenue | 331.8 |  |  | 275.0 |  |  | 641.7 |  |  | 531.2 |  |
| Total revenue | $ | 521.7 |  |  | $ | 441.3 |  |  | $ | 994.3 |  |  | $ | 840.3 |  |

- changed (2019-10-31):
[0001262039-19-000033:note_history:12]
During the three months ended September 30, 2019 and September 30, 2018, we recognized $211.6 million and $173.0 million in revenue that was included in the deferred revenue balance as of December 31, 2018 and December 31, 2017, respectively. During the nine months ended September 30, 2019 and September 30, 2018, we recognized $752.2 million and $615.3 million in revenue that was included in the deferred revenue balance as of December 31, 2018 and December 31, 2017, respectively.
  (was, 2019-08-01, similarity 0.8513):
[0001262039-19-000023:note_history:12]
During the three months ended June 30, 2019 and June 30, 2018, we recognized $252.0 million and $203.3 million in revenue that was included in the deferred revenue balance as of December 31, 2018 and December 31, 2017, respectively. During the six months ended June 30, 2019 and June 30, 2018, we recognized $540.6 million and $442.3 million in revenue that was included in the deferred revenue balance as of December 31, 2018 and December 31, 2017, respectively.

- changed (2019-10-31):
[0001262039-19-000033:note_history:13]
As of September 30, 2019, the aggregate amount of the transaction price allocated to remaining performance obligations was $1.95 billion, which was substantially comprised of deferred security subscription and technical support services revenue. We expect to recognize approximately $1.06 billion as revenue over the next 12 months and the remainder thereafter.
  (was, 2019-08-01, similarity 0.6628):
[0001262039-19-000023:note_history:13]
As of June 30, 2019, the aggregate amount of the transaction price allocated to remaining performance obligations was $1.87 billion, which was substantially comprised of deferred security subscription and technical support services. We expect to recognize approximately $1.03 billion into revenue over the next 12 months and the remainder thereafter.

- changed (2019-10-31):
[0001262039-19-000033:note_history:14]
Trade accounts receivable are recorded at the invoiced amount. Trade accounts receivable are reduced by an allowance for doubtful accounts which is determined based on our assessment of the collectability of customer accounts. The allowance for doubtful accounts was $0.8 million and $0.9 million as of September 30, 2019 and December 31, 2018, respectively.
  (was, 2019-08-01, similarity 0.9735):
[0001262039-19-000023:note_history:14]
Trade accounts receivable are recorded at the invoiced amount. Trade accounts receivable is reduced by an allowance for doubtful accounts which is determined based on our assessment of the collectability of customer accounts. The allowance for doubtful accounts was $0.8 million and $0.9 million as of June 30, 2019 and December 31, 2018, respectively.

- changed (2019-10-31):
[0001262039-19-000033:note_history:15]
Sales commissions earned by our sales force are considered incremental and recoverable costs of obtaining a contract with a customer. The amortization of deferred contract costs is included in sales and marketing expense in our condensed consolidated statements of income. Amortization of deferred contract costs during the three months ended September 30, 2019 and September 30, 2018 were $27.5 million and $23.2 million, respectively.  Amortization of deferred contract costs during the nine months ended September 30, 2019 and September 30, 2018 were $78.5 million and $66.3 million, respectively.
  (was, 2019-08-01, similarity 0.8895):
[0001262039-19-000023:note_history:15]
Sales commissions earned by our sales force are considered incremental and recoverable costs of obtaining a contract with a customer. The amortization of deferred contract costs is included in sales and marketing expense in our condensed consolidated statements of income. Amortization of deferred contract costs during the three months ended June 30, 2019 and June 30, 2018 were $25.9 million and $22.4 million, respectively.  Amortization of deferred contract costs during the six months ended June 30, 2019 and June 30, 2018 were $51.0 million and $43.2 million, respectively.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_prior_note, score: 0.0

- added (2019-10-31):
[0001262039-19-000033:note_history:16]
SUBSEQUENT EVENTS

- added (2019-10-31):
[0001262039-19-000033:note_history:17]
Business combination

- added (2019-10-31):
[0001262039-19-000033:note_history:18]
On October 28, 2019, we acquired enSilo Ltd. (“enSilo”), a privately held company that provides endpoint detection and response products and services. We acquired enSilo for approximately $20.0 million in initial consideration, subject to certain adjustments.

- added (2019-10-31):
[0001262039-19-000033:note_history:19]
We are currently in the process of evaluating the business combination accounting, including the consideration transferred and the initial purchase price allocation.

- added (2019-10-31):
[0001262039-19-000033:note_history:20]
Share repurchase

- added (2019-10-31):
[0001262039-19-000033:note_history:21]
Subsequent to September 30, 2019 through the filing of this Quarterly Report on Form 10-Q, we repurchased 0.3 million shares of our common stock, for an aggregate purchase price of $23.5 million at an average price of $77.39 per share, under the Repurchase Program.
