# FTNT 8-K — 0001262039-26-000003 filed 2026-02-05

## item codes, every 8-K on or before 2026-02-25

- 2026-02-05 0001262039-26-000003 — 2.02, 9.01
- 2025-11-05 0001262039-25-000036 — 2.02, 9.01
- 2025-08-22 0001262039-25-000033 — 8.01
- 2025-08-06 0001262039-25-000025 — 2.02, 9.01
- 2025-06-18 0001262039-25-000022 — 5.07
- 2025-05-15 0001262039-25-000020 — 5.02 — amendment, the index does not say of what
- 2025-05-07 0001262039-25-000014 — 2.02, 9.01
- 2025-02-06 0001262039-25-000007 — 2.02, 5.02, 9.01
- 2025-01-22 0001262039-25-000003 — 5.02 — amendment, the index does not say of what
- 2024-11-12 0001262039-24-000045 — 5.02, 9.01
- 2024-11-07 0001262039-24-000040 — 2.02, 9.01
- 2024-08-07 0001262039-24-000034 — 2.02, 9.01 — amendment of 0001262039-24-000032
- 2024-08-06 0001262039-24-000032 — 2.02, 9.01
- 2024-07-24 0001262039-24-000028 — 5.02 — amendment, the index does not say of what
- 2024-06-20 0001262039-24-000025 — 5.07
- 2024-05-02 0001262039-24-000017 — 2.02, 9.01
- 2024-02-23 0001262039-24-000011 — 5.02, 9.01
- 2024-02-06 0001262039-24-000006 — 2.02, 9.01
- 2024-01-18 0001262039-24-000003 — 5.02
- 2023-12-01 0001262039-23-000041 — 5.02
- 2023-11-02 0001262039-23-000035 — 2.02, 9.01
- 2023-08-03 0001262039-23-000027 — 2.02, 9.01
- 2023-06-23 0001262039-23-000024 — 5.03, 5.07, 9.01
- 2023-05-04 0001262039-23-000013 — 2.02, 9.01
- 2023-02-08 0001262039-23-000006 — 5.03, 9.01
- 2023-02-07 0001262039-23-000003 — 2.02, 9.01
- 2022-11-02 0001262039-22-000035 — 2.02, 9.01
- 2022-08-03 0001262039-22-000026 — 2.02, 9.01
- 2022-06-22 0001262039-22-000023 — 5.03, 9.01
- 2022-06-21 0001262039-22-000021 — 5.07
- 2022-05-04 0001262039-22-000015 — 2.02, 9.01
- 2022-05-02 0001262039-22-000012 — 5.02
- 2022-04-22 0001262039-22-000010 — 8.01
- 2022-02-03 0001262039-22-000005 — 2.02, 9.01
- 2022-01-26 0001262039-22-000002 — 5.02, 9.01 — amendment, the index does not say of what
- 2021-11-04 0001262039-21-000027 — 2.02, 9.01
- 2021-10-06 0001262039-21-000024 — 5.02, 9.01
- 2021-07-29 0001262039-21-000019 — 2.02, 9.01
- 2021-06-23 0001262039-21-000016 — 5.07
- 2021-04-30 0001104659-21-059008 — 5.03 — amendment, the index does not say of what
- 2021-04-29 0001262039-21-000011 — 2.02, 9.01
- 2021-04-28 0001104659-21-056360 — 5.02, 5.03, 9.01
- 2021-03-05 0001193125-21-071498 — 1.01, 9.01
- 2021-02-25 0001193125-21-057281 — 1.01, 9.01
- 2021-02-04 0001262039-21-000005 — 2.02, 9.01
- 2020-12-08 0001262039-20-000070 — 8.01
- 2020-10-29 0001262039-20-000063 — 2.02, 9.01
- 2020-10-20 0001262039-20-000060 — 5.02 — amendment, the index does not say of what
- 2020-08-26 0001262039-20-000056 — 5.02, 9.01
- 2020-08-06 0001262039-20-000051 — 2.02, 9.01
- 2020-07-21 0001262039-20-000044 — 5.03, 8.01, 9.01
- 2020-06-24 0001262039-20-000038 — 5.07
- 2020-05-06 0001262039-20-000029 — 2.02, 9.01
- 2020-04-23 0001262039-20-000025 — 5.03, 9.01
- 2020-04-23 0001262039-20-000024 — 5.02 — amendment of 0001262039-20-000025
- 2020-02-28 0001262039-20-000015 — 5.02, 9.01
- 2020-02-06 0001262039-20-000004 — 2.02, 9.01
- 2019-12-12 0001262039-19-000038 — 8.01
- 2019-10-31 0001262039-19-000032 — 2.02, 9.01
- 2019-10-28 0001262039-19-000027 — 8.01
- 2019-10-23 0001262039-19-000025 — 5.02, 9.01
- 2019-08-01 0001262039-19-000021 — 2.02, 9.01
- 2019-06-26 0001262039-19-000018 — 5.07
- 2019-05-02 0001262039-19-000010 — 2.02, 9.01
- 2019-02-06 0001262039-19-000002 — 2.02, 9.01
- 2018-11-01 0001262039-18-000037 — 2.02, 9.01
- 2018-10-23 0001262039-18-000035 — 8.01
- 2018-08-01 0001262039-18-000025 — 2.02, 9.01
- 2018-06-28 0001262039-18-000023 — 5.03, 5.07, 9.01
- 2018-06-04 0001262039-18-000021 — 8.01
- 2018-05-03 0001262039-18-000017 — 2.02, 5.02, 9.01
- 2018-02-05 0001262039-18-000004 — 2.02, 5.02, 9.01
- 2017-10-26 0001262039-17-000031 — 2.02, 9.01
- 2017-10-19 0001262039-17-000029 — 5.02 — amendment, the index does not say of what
- 2017-07-26 0001262039-17-000025 — 2.02, 9.01
- 2017-06-27 0001262039-17-000023 — 5.07
- 2017-05-31 0001262039-17-000021 — 5.02 — amendment of 0001262039-17-000019
- 2017-05-30 0001262039-17-000019 — 5.02, 9.01
- 2017-04-27 0001262039-17-000013 — 2.02, 9.01
- 2017-02-02 0001262039-17-000003 — 2.02, 9.01
- 2016-10-27 0001262039-16-000085 — 2.02, 9.01
- 2016-10-11 0001262039-16-000082 — 2.02, 9.01
- 2016-07-28 0001262039-16-000076 — 2.02, 9.01
- 2016-07-22 0001262039-16-000073 — 8.01, 9.01
- 2016-06-20 0001262039-16-000068 — 5.07
- 2016-06-07 0001193125-16-614788 — 8.01
- 2016-04-26 0001262039-16-000061 — 2.02, 9.01
- 2016-01-28 0001262039-16-000051 — 2.02, 9.01
- 2015-10-27 0001262039-15-000045 — 2.02
- 2015-10-22 0001262039-15-000042 — 5.02 — amendment, the index does not say of what
- 2015-10-22 0001262039-15-000041 — 5.02 — amendment, the index does not say of what
- 2015-10-22 0001262039-15-000039 — 2.02, 9.01
- 2015-09-28 0001262039-15-000034 — 5.02, 9.01
- 2015-09-22 0001262039-15-000031 — 9.01 — amendment of 0001193125-15-248065
- 2015-08-28 0001262039-15-000027 — 3.01, 5.02
- 2015-07-23 0001262039-15-000021 — 5.02
- 2015-07-22 0001262039-15-000019 — 2.02, 9.01
- 2015-07-08 0001193125-15-248065 — 2.01, 8.01, 9.01
- 2015-06-22 0001193125-15-229099 — 5.07
- 2015-06-19 0001193125-15-228428 — 5.02, 9.01
- 2015-04-20 0001262039-15-000014 — 2.02, 9.01
- 2015-01-28 0001262039-15-000005 — 2.02, 9.01
- 2014-10-22 0001262039-14-000036 — 2.02, 9.01
- 2014-07-23 0001262039-14-000030 — 2.02, 9.01
- 2014-06-24 0001262039-14-000027 — 5.07
- 2014-04-23 0001262039-14-000021 — 2.02, 9.01
- 2014-04-21 0001262039-14-000018 — 5.03, 9.01
- 2014-01-29 0001262039-14-000004 — 2.02, 9.01
- 2013-12-20 0001262039-13-000061 — 5.02, 9.01
- 2013-11-27 0001262039-13-000057 — 5.02, 7.01, 9.01
- 2013-11-12 0001445305-13-002993 — 5.02
- 2013-10-23 0001262039-13-000051 — 2.02, 9.01
- 2013-07-30 0001262039-13-000039 — 2.02, 9.01
- 2013-06-25 0001262039-13-000030 — 5.07
- 2013-04-30 0001262039-13-000023 — 2.02, 9.01
- 2013-04-19 0001262039-13-000020 — 5.02, 9.01
- 2013-04-19 0001262039-13-000018 — 5.02 — amendment of 0001262039-13-000020
- 2013-04-10 0001262039-13-000016 — 2.02, 9.01
- 2013-03-26 0001262039-13-000013 — 5.02
- 2013-01-30 0001262039-13-000005 — 2.02, 9.01
- 2013-01-24 0001262039-13-000002 — 5.02, 9.01
- 2012-10-16 0001262039-12-000048 — 2.02, 9.01
- 2012-10-01 0001262039-12-000045 — 5.02
- 2012-09-26 0001262039-12-000043 — 5.01
- 2012-07-25 0001262039-12-000038 — 2.02, 9.01
- 2012-07-19 0001262039-12-000034 — 5.02
- 2012-06-20 0001193125-12-275869 — 5.07
- 2012-04-27 0001262039-12-000029 — 5.02
- 2012-04-24 0001262039-12-000025 — 2.02, 9.01
- 2012-01-31 0001262039-12-000006 — 2.02, 9.01
- 2012-01-25 0001262039-12-000003 — 5.03
- 2011-10-24 0001262039-11-000036 — 2.02
- 2011-07-19 0001262039-11-000014 — 2.02, 9.01
- 2011-06-27 0001193125-11-174474 — 5.02, 5.07, 9.01
- 2011-04-27 0001193125-11-111938 — 2.02, 9.01
- 2011-01-25 0001193125-11-013914 — 2.02, 9.01
- 2010-10-21 0001193125-10-233676 — 2.02, 9.01
- 2010-09-02 0001193125-10-203099 — 8.01
- 2010-07-22 0001193125-10-163844 — 2.02, 9.01
- 2010-06-24 0001193125-10-146082 — 5.07
- 2010-04-28 0001193125-10-096698 — 2.02, 9.01
- 2010-02-09 0001193125-10-024614 — 8.01
- 2010-01-27 0001193125-10-014292 — 2.02, 9.01
- 2010-01-26 0001193125-10-013031 — 5.02, 9.01

## late-filing notifications on or before 2026-02-25

- none on or before 2026-02-25

## item 2.02 — earnings release, exhibit 99.1

[0001262039-26-000003:8k_2_02:1]
EX-99.1
2
ftntq4-2025ex991.htm
PRESS RELEASE

[0001262039-26-000003:8k_2_02:2]
Document

[0001262039-26-000003:8k_2_02:3]
Press Release

[0001262039-26-000003:8k_2_02:4]
Fortinet Reports Strong Fourth Quarter and Full Year 2025 Financial Results

[0001262039-26-000003:8k_2_02:5]
Fourth Quarter 2025 Highlights

[0001262039-26-000003:8k_2_02:6]
•Revenue grew 15% year over year to $1.91 billion

[0001262039-26-000003:8k_2_02:7]
•Product revenue grew 20% year over year to $691 million

[0001262039-26-000003:8k_2_02:8]
•Billings grew 18% to $2.37 billion1

[0001262039-26-000003:8k_2_02:9]
•Unified SASE billings grew 40%

[0001262039-26-000003:8k_2_02:10]
•GAAP operating margin of 33%

[0001262039-26-000003:8k_2_02:11]
•Non-GAAP operating margin of 37%1

[0001262039-26-000003:8k_2_02:12]
Full Year 2025 Highlights

[0001262039-26-000003:8k_2_02:13]
•Revenue grew 14% year over year to $6.80 billion

[0001262039-26-000003:8k_2_02:14]
•Product revenue grew 16% year over year to $2.22 billion

[0001262039-26-000003:8k_2_02:15]
•Billings grew 16% to $7.55 billion1

[0001262039-26-000003:8k_2_02:16]
•Unified SASE & SecOps billings grew 24%

[0001262039-26-000003:8k_2_02:17]
•GAAP operating margin of 31%

[0001262039-26-000003:8k_2_02:18]
•Non-GAAP operating margin of 35%1

[0001262039-26-000003:8k_2_02:19]
•Free cash flow of $2.21 billion1

[0001262039-26-000003:8k_2_02:20]
•Exceeded the ‘Rule of 45’ for the sixth consecutive year2

[0001262039-26-000003:8k_2_02:21]
SUNNYVALE, Calif. - February 5, 2026 - Fortinet® (Nasdaq: FTNT), a global cybersecurity leader driving the convergence of networking and security, today announced financial results for the fourth quarter of 2025 and full year ended December 31, 2025.

[0001262039-26-000003:8k_2_02:22]
“We are pleased with our strong finish to the year, highlighted by an excellent fourth quarter driven by broad-based demand across our portfolio, which drove billings above the high end of our guidance,” said Ken Xie, Founder, Chairman and Chief Executive Officer of Fortinet. “We continue to execute our strategy by accelerating our investments in high-growth Unified SASE and Security Operations markets, delivering strong momentum while further strengthening our Secure Networking leadership. As the #1 firewall leader with a 55% unit market share, Fortinet is well-positioned to extend that leadership into SASE, driven by our rapidly expanding SASE adoption and growing customer demand. Our easy-to-adopt FortiSASE solution, powered by our single FortiOS operating system, supports both sovereign and public deployments, delivering high performance with significantly lower total cost of ownership than the competition.”

[0001262039-26-000003:8k_2_02:23]
Recent Business Highlights

[0001262039-26-000003:8k_2_02:24]
•Announced an integrated solution with NVIDIA that delivers isolated infrastructure acceleration for the AI Factory, embedding FortiGate VM on BlueField-3 DPUs to provide firewalling, segmentation and policy enforcement directly in the infrastructure for higher performance, stronger isolation and simpler operations.

[0001262039-26-000003:8k_2_02:25]
•Recognized as a Gartner Peer Insights™ Customers’ Choice for Security Service Edge for the third consecutive year, making Fortinet the only cybersecurity vendor to receive this distinction.

[0001262039-26-000003:8k_2_02:26]
•Named the inaugural Google Unified Security Recommended partner for network protection, recognizing FortiSASE and FortiGate NGFW for delivering converged networking and security natively on Google Cloud.

[0001262039-26-000003:8k_2_02:27]
•Won the 2025 Red Dot Product Design Award for the FortiGate Rugged series, Fortinet’s second consecutive win, recognizing design excellence, reliability and performance at the industrial edge.

[0001262039-26-000003:8k_2_02:28]
Fortinet Expands Share Repurchase Authorization by $1.0 Billion

[0001262039-26-000003:8k_2_02:29]
Fortinet today announced that its Board of Directors has authorized an increase of its share repurchase program by $1.0 billion worth of shares of common stock, for an aggregate authorized repurchase amount of up to $10.25 billion through February 28, 2027. As of February 4, 2026 approximately $1.38 billion remained available under the share repurchase program, including the $1.0 billion increase. Repurchases under Fortinet’s share repurchase program may be made through privately negotiated transactions or open market transactions, including pursuant to a trading plan in accordance with Rule 10b5-1 and/or Rule 10b-18 under the Securities Exchange Act of 1934, as amended. Fortinet’s share repurchase program does not obligate Fortinet to acquire any particular amount of its common stock, and it may be suspended at any time at Fortinet’s discretion. The timing and actual number of shares repurchased may depend on a variety of factors, including price, general business and market conditions, and alternative investment opportunities.

[0001262039-26-000003:8k_2_02:30]
Guidance

[0001262039-26-000003:8k_2_02:31]
For the first quarter of 2026, Fortinet currently expects:

[0001262039-26-000003:8k_2_02:32]
•Revenue in the range of $1.700 billion to $1.760 billion

[0001262039-26-000003:8k_2_02:33]
•Billings in the range of $1.770 billion to $1.870 billion

[0001262039-26-000003:8k_2_02:34]
•Non-GAAP gross margin in the range of 80.0% to 81.0%

[0001262039-26-000003:8k_2_02:35]
•Non-GAAP operating margin in the range of 30.0% to 32.0%

[0001262039-26-000003:8k_2_02:36]
•Diluted non-GAAP net income per share in the range of $0.59 to $0.63, assuming a non-GAAP effective tax rate of 18%. This assumes a diluted share count of 746 million to 750 million.

[0001262039-26-000003:8k_2_02:37]
For the fiscal year 2026, Fortinet currently expects:

[0001262039-26-000003:8k_2_02:38]
•Revenue in the range of $7.500 billion to $7.700 billion

[0001262039-26-000003:8k_2_02:39]
•Service revenue in the range of $5.050 billion to $5.150 billion

[0001262039-26-000003:8k_2_02:40]
•Billings in the range of $8.400 billion to $8.600 billion

[0001262039-26-000003:8k_2_02:41]
•Non-GAAP gross margin in the range of 79.0% to 81.0%

[0001262039-26-000003:8k_2_02:42]
•Non-GAAP operating margin in the range of 33.0% to 36.0%

[0001262039-26-000003:8k_2_02:43]
•Diluted non-GAAP net income per share in the range of $2.94 to $3.00, assuming a non-GAAP effective tax rate of 18%. This assumes a diluted share count of 747 million to 753 million.

[0001262039-26-000003:8k_2_02:44]
Our guidance with respect to non-GAAP financial measures excludes stock-based compensation, amortization of acquired intangible assets, gain on intellectual property matters and a tax adjustment required for an effective tax rate on a non-GAAP basis, which differs from the GAAP effective tax rate. We have not reconciled our guidance with respect to non-GAAP financial measures to the corresponding GAAP measures because certain items that impact these measures are uncertain or out of our control or cannot be reasonably predicted. Accordingly, a reconciliation of these non-GAAP financial measures to the corresponding GAAP measures is not available without unreasonable effort.

[0001262039-26-000003:8k_2_02:45]
Conference Call Details

[0001262039-26-000003:8k_2_02:46]
Fortinet will host a conference call today at 1:30 p.m. Pacific Time (4:30 p.m. Eastern Time) to discuss the earnings results. A live webcast of the conference call and supplemental slides will be accessible from the Investor Relations page of Fortinet’s website at https://investor.fortinet.com and a replay will be archived and accessible at https://investor.fortinet.com/events-and-presentations.

[0001262039-26-000003:8k_2_02:47]
First Quarter 2026 Conference Participation Schedule:

[0001262039-26-000003:8k_2_02:48]
•Bernstein TMT Forum

[0001262039-26-000003:8k_2_02:49]
February 26, 2026

[0001262039-26-000003:8k_2_02:50]
•Morgan Stanley Technology, Media & Telecom Conference

[0001262039-26-000003:8k_2_02:51]
March 3, 2026

[0001262039-26-000003:8k_2_02:52]
Members of Fortinet’s management team are expected to present at these conferences and discuss the latest company strategies and initiatives. Fortinet’s conference presentations are expected to be available via webcast on the company’s website. To access the most updated information, pre-register and listen to the webcast of each event, please visit the Investor Presentation & Events page of Fortinet’s website at https://investor.fortinet.com/events-and-presentations. The schedule is subject to change.

[0001262039-26-000003:8k_2_02:53]
About Fortinet (www.fortinet.com)

[0001262039-26-000003:8k_2_02:54]
Fortinet (Nasdaq: FTNT) is a driving force in the evolution of cybersecurity and the convergence of networking and security. Our mission is to secure people, devices and data everywhere, and today we deliver cybersecurity everywhere our customers need it with the largest integrated portfolio of over 50 enterprise-grade products. Well over half a million customers trust Fortinet’s solutions, which are among the most deployed, most patented and most validated in the industry. The Fortinet Training Institute, one of the largest and broadest training programs in the industry, is dedicated to making cybersecurity training and new career opportunities available to everyone. Collaboration with esteemed organizations from both the public and private sectors, including Computer Emergency Response Teams (“CERTs”), government entities, and academia, is a fundamental aspect of Fortinet’s commitment to enhance cyber resilience globally. FortiGuard Labs, Fortinet’s elite threat intelligence and research organization, develops and utilizes leading-edge machine learning and AI technologies to provide customers with timely and consistently top-rated protection and actionable threat intelligence. Learn more at https://www.fortinet.com, the Fortinet Blog or FortiGuard Labs.

[0001262039-26-000003:8k_2_02:55]
Forward-Looking Statements

[0001262039-26-000003:8k_2_02:56]
This press release contains forward-looking statements that involve risks and uncertainties. These forward-looking statements include statements regarding any indications related to future

[0001262039-26-000003:8k_2_02:57]
Use of Non-GAAP Financial Measures

[0001262039-26-000003:8k_2_02:58]
We believe that the presentation of non-GAAP financial information provides important supplemental information to management and investors regarding financial and business trends relating to our financial condition and results of operations. For further information regarding why we believe that these non-GAAP measures provide useful information to investors, the specific

[0001262039-26-000003:8k_2_02:59]
manner in which management uses these measures, and some of the limitations associated with the use of these measures, please refer to the “Explanation of Non-GAAP Financial Measures” section of this press release.

[0001262039-26-000003:8k_2_02:60]
FORTINET, INC.

[0001262039-26-000003:8k_2_02:61]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001262039-26-000003:8k_2_02:62]
(Unaudited, in millions)

[0001262039-26-000003:8k_2_02:63]
|  | December 31,2025 |  | December 31,2024 |
| ASSETS |  |  |  |
| CURRENT ASSETS: |  |  |  |
| Cash and cash equivalents | $ | 2,495.3 |  |  | $ | 2,875.9 |  |
| Short-term investments | 1,087.2 |  |  | 1,190.6 |  |
| Accounts receivable—net | 1,691.2 |  |  | 1,463.4 |  |
| Inventory | 399.5 |  |  | 315.5 |  |
| Prepaid expenses and other current assets | 227.0 |  |  | 126.1 |  |
| Total current assets | 5,900.2 |  |  | 5,971.5 |  |
| LONG-TERM INVESTMENTS | 339.7 |  |  | — |  |
| PROPERTY AND EQUIPMENT—NET | 1,619.0 |  |  | 1,349.5 |  |
| DEFERRED CONTRACT COSTS | 735.5 |  |  | 622.9 |  |
| DEFERRED TAX ASSETS | 1,314.9 |  |  | 1,335.6 |  |
| GOODWILL AND OTHER INTANGIBLE ASSETS—NET | 354.7 |  |  | 350.4 |  |
| OTHER ASSETS | 125.2 |  |  | 133.2 |  |
| TOTAL ASSETS | $ | 10,389.2 |  |  | $ | 9,763.1 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |
| CURRENT LIABILITIES: |  |  |  |
| Accounts payable | $ | 230.8 |  |  | $ | 190.9 |  |
| Accrued liabilities | 354.6 |  |  | 337.9 |  |
| Accrued payroll and compensation | 312.9 |  |  | 255.7 |  |
| Current portion of long-term debt | 499.7 |  |  | — |  |
| Deferred revenue | 3,636.0 |  |  | 3,276.2 |  |
| Total current liabilities | 5,034.0 |  |  | 4,060.7 |  |
| DEFERRED REVENUE | 3,479.8 |  |  | 3,084.7 |  |
| LONG-TERM DEBT | 496.6 |  |  | 994.3 |  |
| OTHER LIABILITIES | 141.3 |  |  | 129.6 |  |
| Total liabilities | 9,151.7 |  |  | 8,269.3 |  |
| COMMITMENTS AND CONTINGENCIES |  |  |  |
| STOCKHOLDERS’ EQUITY: |  |  |  |
| Common stock | 0.7 |  |  | 0.8 |  |
| Additional paid-in capital | 1,770.1 |  |  | 1,636.2 |  |
| Accumulated other comprehensive loss | (25.4) |  |  | (26.1) |  |
| Accumulated deficit | (507.9) |  |  | (117.1) |  |
| Total stockholders’ equity | 1,237.5 |  |  | 1,493.8 |  |
| TOTAL LIABILITIES AND STOCKHOLDERS’ EQUITY | $ | 10,389.2 |  |  | $ | 9,763.1 |  |

[0001262039-26-000003:8k_2_02:64]
FORTINET, INC.

[0001262039-26-000003:8k_2_02:65]
CONDENSED CONSOLIDATED STATEMENTS OF INCOME

[0001262039-26-000003:8k_2_02:66]
(Unaudited, in millions, except per share amounts)

[0001262039-26-000003:8k_2_02:67]
|  | Three Months Ended |  | Year Ended |
|  | December 31,2025 |  | December 31,2024 |  | December 31,2025 |  | December 31,2024 |
| REVENUE: |  |  |  |  |  |  |  |
| Product | $ | 691.1 |  |  | $ | 574.0 |  |  | $ | 2,218.4 |  |  | $ | 1,908.7 |  |
| Service | 1,213.9 |  |  | 1,086.1 |  |  | 4,581.2 |  |  | 4,047.1 |  |
| Total revenue | 1,905.0 |  |  | 1,660.1 |  |  | 6,799.6 |  |  | 5,955.8 |  |
| COST OF REVENUE: |  |  |  |  |  |  |  |
| Product | 228.9 |  |  | 178.0 |  |  | 725.4 |  |  | 652.0 |  |
| Service | 160.3 |  |  | 136.5 |  |  | 603.5 |  |  | 505.6 |  |
| Total cost of revenue | 389.2 |  |  | 314.5 |  |  | 1,328.9 |  |  | 1,157.6 |  |
| GROSS PROFIT: |  |  |  |  |  |  |  |
| Product | 462.2 |  |  | 396.0 |  |  | 1,493.0 |  |  | 1,256.7 |  |
| Service | 1,053.6 |  |  | 949.6 |  |  | 3,977.7 |  |  | 3,541.5 |  |
| Total gross profit | 1,515.8 |  |  | 1,345.6 |  |  | 5,470.7 |  |  | 4,798.2 |  |
| OPERATING EXPENSES: |  |  |  |  |  |  |  |
| Research and development | 205.0 |  |  | 191.1 |  |  | 815.5 |  |  | 716.8 |  |
| Sales and marketing | 629.3 |  |  | 526.5 |  |  | 2,347.5 |  |  | 2,044.8 |  |
| General and administrative | 57.3 |  |  | 55.1 |  |  | 233.4 |  |  | 237.8 |  |
| Gain on intellectual property matters | (1.4) |  |  | (1.2) |  |  | (10.4) |  |  | (4.6) |  |
| Total operating expenses | 890.2 |  |  | 771.5 |  |  | 3,386.0 |  |  | 2,994.8 |  |
| OPERATING INCOME | 625.6 |  |  | 574.1 |  |  | 2,084.7 |  |  | 1,803.4 |  |
| INTEREST INCOME | 32.3 |  |  | 42.3 |  |  | 162.3 |  |  | 155.2 |  |
| INTEREST EXPENSE | (4.4) |  |  | (4.9) |  |  | (20.1) |  |  | (20.0) |  |
| OTHER INCOME (EXPENSE)—NET | (2.7) |  |  | 6.9 |  |  | 55.3 |  |  | 119.9 |  |
| INCOME BEFORE INCOME TAXES AND LOSS FROM EQUITY METHOD INVESTMENTS | 650.8 |  |  | 618.4 |  |  | 2,282.2 |  |  | 2,058.5 |  |
| PROVISION FOR INCOME TAXES | 144.8 |  |  | 86.7 |  |  | 439.1 |  |  | 283.9 |  |
| GAIN (LOSS) FROM EQUITY METHOD INVESTMENTS | — |  |  | (5.5) |  |  | 10.3 |  |  | (29.4) |  |
| NET INCOME | $ | 506.0 |  |  | $ | 526.2 |  |  | $ | 1,853.4 |  |  | $ | 1,745.2 |  |
| Net income per share: |  |  |  |  |  |  |  |
| Basic | $ | 0.68 |  |  | $ | 0.69 |  |  | $ | 2.45 |  |  | $ | 2.28 |  |
| Diluted | $ | 0.68 |  |  | $ | 0.68 |  |  | $ | 2.42 |  |  | $ | 2.26 |  |
| Weighted-average shares outstanding: |  |  |  |  |  |  |  |
| Basic | 743.1 |  |  | 766.5 |  |  | 758.0 |  |  | 764.4 |  |
| Diluted | 748.0 |  |  | 775.2 |  |  | 764.6 |  |  | 771.9 |  |

[0001262039-26-000003:8k_2_02:68]
FORTINET, INC.

[0001262039-26-000003:8k_2_02:69]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001262039-26-000003:8k_2_02:70]
(Unaudited, in millions)

[0001262039-26-000003:8k_2_02:71]
|  | Year Ended |
|  | December 31,2025 |  | December 31,2024 |
| CASH FLOWS FROM OPERATING ACTIVITIES: |  |  |  |
| Net income | $ | 1,853.4 |  |  | $ | 1,745.2 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |
| Stock-based compensation | 279.5 |  |  | 257.9 |  |
| Amortization of deferred contract costs | 336.3 |  |  | 293.7 |  |
| Depreciation and amortization | 152.0 |  |  | 122.8 |  |
| Amortization of investment discounts | (33.7) |  |  | (48.8) |  |
| Other | (52.7) |  |  | (92.1) |  |
| Changes in operating assets and liabilities, net of impact of business combinations: |  |  |  |
| Accounts receivable—net | (215.9) |  |  | (45.4) |  |
| Inventory | (90.6) |  |  | 131.2 |  |
| Prepaid expenses and other current assets | (95.9) |  |  | (13.7) |  |
| Deferred contract costs | (449.0) |  |  | (311.1) |  |
| Deferred tax assets | 66.2 |  |  | (223.2) |  |
| Other assets | (16.2) |  |  | (11.0) |  |
| Accounts payable | 27.9 |  |  | (10.2) |  |
| Accrued liabilities | 13.3 |  |  | (106.7) |  |
| Accrued payroll and compensation | 55.0 |  |  | — |  |
| Deferred revenue | 754.2 |  |  | 577.8 |  |
| Other liabilities | 6.8 |  |  | (8.3) |  |
| Net cash provided by operating activities | 2,590.6 |  |  | 2,258.1 |  |
| CASH FLOWS FROM INVESTING ACTIVITIES: |  |  |  |
| Purchases of investments | (1,996.1) |  |  | (1,948.6) |  |
| Sales of investments | 10.6 |  |  | 0.5 |  |
| Maturities of investments | 1,792.7 |  |  | 1,891.7 |  |
| Purchases of property and equipment | (364.8) |  |  | (378.9) |  |
| Payments made in connection with business combinations, net of cash acquired | (41.6) |  |  | (275.5) |  |
| Purchases of marketable equity securities | — |  |  | (16.7) |  |
| Other | 0.1 |  |  | 0.1 |  |
| Net cash used in investing activities | (599.1) |  |  | (727.4) |  |
| CASH FLOWS FROM FINANCING ACTIVITIES: |  |  |  |
| Repurchase and retirement of common stock | (2,289.8) |  |  | (0.6) |  |
| Proceeds from issuance of common stock | 44.7 |  |  | 63.1 |  |
| Taxes paid related to net share settlement of equity awards | (126.3) |  |  | (100.9) |  |
| Other | (0.1) |  |  | (11.7) |  |
| Net cash used in financing activities | (2,371.5) |  |  | (50.1) |  |
| EFFECT OF EXCHANGE RATE CHANGES ON CASH AND CASH EQUIVALENTS | (0.6) |  |  | (2.6) |  |
| NET INCREASE (DECREASE) IN CASH AND CASH EQUIVALENTS | (380.6) |  |  | 1,478.0 |  |
| CASH AND CASH EQUIVALENTS—Beginning of year | 2,875.9 |  |  | 1,397.9 |  |
| CASH AND CASH EQUIVALENTS—End of year | $ | 2,495.3 |  |  | $ | 2,875.9 |  |

[0001262039-26-000003:8k_2_02:72]
Reconciliations of non-GAAP results of operations measures to the nearest comparable GAAP measures

[0001262039-26-000003:8k_2_02:73]
(Unaudited, in millions, except per share amounts)

[0001262039-26-000003:8k_2_02:74]
Reconciliation of GAAP operating income to non-GAAP operating income, operating margin, net income and diluted net income per share

[0001262039-26-000003:8k_2_02:75]
|  | Three Months Ended |  | Year Ended |
|  | December 31,2025 |  | December 31,2024 |  | December 31,2025 |  | December 31,2024 |
| Reconciliation of non-GAAP operating income: |  |  |  |  |  |  |  |
| GAAP operating income | $ | 625.6 |  |  | $ | 574.1 |  |  | $ | 2,084.7 |  |  | $ | 1,803.4 |  |
| GAAP operating margin | 32.8 | % |  | 34.6 | % |  | 30.7 | % |  | 30.3 | % |
| Add back: |  |  |  |  |  |  |  |
| Stock‐based compensation | 73.1 |  |  | 66.5 |  |  | 282.1 |  |  | 260.2 |  |
| Amortization of acquired intangible assets | 12.6 |  |  | 11.5 |  |  | 50.7 |  |  | 23.1 |  |
| Litigation-related matters | — |  |  | — |  |  | 5.6 |  |  | 3.2 |  |
| Gain on intellectual property matters | (1.4) |  |  | (1.2) |  |  | (10.4) |  |  | (4.6) |  |
| Non‐GAAP operating income | $ | 709.9 |  |  | $ | 650.9 |  |  | $ | 2,412.7 |  |  | $ | 2,085.3 |  |
| Non‐GAAP operating margin | 37.3 | % |  | 39.2 | % |  | 35.5 | % |  | 35.0 | % |
| Reconciliation of non-GAAP net income: |  |  |  |  |  |  |  |
| GAAP net income | $ | 506.0 |  |  | $ | 526.2 |  |  | $ | 1,853.4 |  |  | $ | 1,745.2 |  |
| Add back: |  |  |  |  |  |  |  |
| Stock‐based compensation | 73.1 |  |  | 66.5 |  |  | 282.1 |  |  | 260.2 |  |
| Amortization of acquired intangible assets | 12.6 |  |  | 11.5 |  |  | 50.7 |  |  | 23.1 |  |
| Litigation-related matters | — |  |  | — |  |  | 5.6 |  |  | 3.2 |  |
| Gain on intellectual property matters | (1.4) |  |  | (1.2) |  |  | (10.4) |  |  | (4.6) |  |
| Gain on bargain purchase | — |  |  | — |  |  | (39.9) |  |  | (106.3) |  |
| Tax adjustment (a) | 12.4 |  |  | (31.5) |  |  | (23.6) |  |  | (95.9) |  |
| Gain from equity method investment | — |  |  | — |  |  | (10.8) |  |  | — |  |
| Non-cash charge on equity method investment | — |  |  | — |  |  | — |  |  | 8.0 |  |
| Non-GAAP net income | $ | 602.7 |  |  | $ | 571.5 |  |  | $ | 2,107.1 |  |  | $ | 1,832.9 |  |
| Non-GAAP net income per share, diluted |  |  |  |  |  |  |  |
| Non-GAAP net income | $ | 602.7 |  |  | $ | 571.5 |  |  | $ | 2,107.1 |  |  | $ | 1,832.9 |  |
| Non-GAAP shares used in diluted net income per share calculations | 748.0 |  |  | 775.2 |  |  | 764.6 |  |  | 771.9 |  |
| Non-GAAP net income per share, diluted | $ | 0.81 |  |  | $ | 0.74 |  |  | $ | 2.76 |  |  | $ | 2.37 |  |
| Reconciliation of non-GAAP net income per share, diluted |  |  |  |  |  |  |  |
| GAAP net income per share, diluted | $ | 0.68 |  |  | $ | 0.68 |  |  | $ | 2.42 |  |  | $ | 2.26 |  |
| Add back: |  |  |  |  |  |  |  |
| Non-GAAP adjustments to net income per share | 0.13 |  |  | 0.06 |  |  | 0.34 |  |  | 0.11 |  |
| Non-GAAP net income per share, diluted | $ | 0.81 |  |  | $ | 0.74 |  |  | $ | 2.76 |  |  | $ | 2.37 |  |

[0001262039-26-000003:8k_2_02:76]
(a) Non-GAAP financial information is adjusted to an effective tax rate of 18% in the three months and year ended December 31, 2025 and 17% in the three months and year ended 2024 on a non-GAAP basis, which differs from the GAAP effective tax rate.

[0001262039-26-000003:8k_2_02:77]
Reconciliation of net cash provided by operating activities to adjusted free cash flow

[0001262039-26-000003:8k_2_02:78]
|  | Three Months Ended |  | Year Ended |
|  | December 31,2025 |  | December 31,2024 |  | December 31,2025 |  | December 31,2024 |
| Net cash provided by operating activities | $ | 620.2 |  |  | $ | 477.6 |  |  | $ | 2,590.6 |  |  | $ | 2,258.1 |  |
| Less: Purchases of property and equipment | (42.8) |  |  | (97.6) |  |  | (364.8) |  |  | (378.9) |  |
| Less: Proceeds from intellectual property matter | — |  |  | — |  |  | (14.0) |  |  | — |  |
| Free cash flow | $ | 577.4 |  |  | $ | 380.0 |  |  | $ | 2,211.8 |  |  | $ | 1,879.2 |  |
| Add: Real estate related add backs | 11.3 |  |  | 78.5 |  |  | 289.7 |  |  | 328.7 |  |
| Adjusted free cash flow | $ | 588.7 |  |  | $ | 458.5 |  |  | $ | 2,501.5 |  |  | $ | 2,207.9 |  |
| Free cash flow margin | 30.3 | % |  | 22.9 | % |  | 32.5 | % |  | 31.6 | % |
| Adjusted free cash flow margin | 30.9 | % |  | 27.6 | % |  | 36.8 | % |  | 37.1 | % |
| Net cash used in investing activities | $ | (46.3) |  |  | $ | (79.9) |  |  | $ | (599.1) |  |  | $ | (727.4) |  |
| Net cash used in financing activities | $ | (72.7) |  |  | $ | (8.8) |  |  | $ | (2,371.5) |  |  | $ | (50.1) |  |

[0001262039-26-000003:8k_2_02:79]
Reconciliation of total revenue to total billings

[0001262039-26-000003:8k_2_02:80]
|  | Three Months Ended |  | Year Ended |
|  | December 31,2025 |  | December 31,2024 |  | December 31,2025 |  | December 31,2024 |
| Total revenue | $ | 1,905.0 |  |  | $ | 1,660.1 |  |  | $ | 6,799.6 |  |  | $ | 5,955.8 |  |
| Add: Change in deferred revenue | 465.4 |  |  | 349.2 |  |  | 754.9 |  |  | 625.9 |  |
| Less: Deferred revenue balance acquired in business acquisitions | — |  |  | (6.8) |  |  | (0.8) |  |  | (49.2) |  |
| Total billings | $ | 2,370.4 |  |  | $ | 2,002.5 |  |  | $ | 7,553.7 |  |  | $ | 6,532.5 |  |

[0001262039-26-000003:8k_2_02:81]
1 A reconciliation of GAAP to non-GAAP measures has been provided in the financial statement tables included in this press release. An explanation of these measures is also included below under the heading “Explanation of Non-GAAP Financial Measures”.

[0001262039-26-000003:8k_2_02:82]
2 Fortinet defines the Rule of 45 as GAAP revenue year over year growth plus non-GAAP operating margin.

[0001262039-26-000003:8k_2_02:83]
Explanation of Non-GAAP Financial Measures

[0001262039-26-000003:8k_2_02:84]
We have provided in this release financial information that has not been prepared in accordance with U.S. Generally Accepted Accounting Principles (“GAAP”). These non-GAAP financial and liquidity measures are not based on any standardized methodology prescribed by GAAP and are not necessarily comparable to similar measures presented by other companies. We use these non-GAAP financial measures internally in analyzing our financial results and believe they are useful to investors, as a supplement to GAAP measures, in evaluating our ongoing operational performance. We believe that the use of these non-GAAP financial measures provides an additional tool for investors to use in evaluating ongoing operating results and trends and in comparing our financial results with peer companies, many of which present similar non-GAAP financial measures to investors.

[0001262039-26-000003:8k_2_02:85]
Non-GAAP financial measures should not be considered in isolation from, or as a substitute for, financial information prepared in accordance with GAAP. Investors are encouraged to review the reconciliation of these non-GAAP financial measures to their most directly comparable GAAP financial measures provided in the financial statement tables below.

[0001262039-26-000003:8k_2_02:86]
Billings (non-GAAP). We define billings as revenue recognized in accordance with GAAP plus the change in deferred revenue from the beginning to the end of the period less any deferred revenue balances acquired from business combination(s) during the period. We consider billings to be a useful metric for management and investors because billings drive current and future revenue as well as cash flows. There are a number of limitations related to the use of billings instead of GAAP revenue. First, billings are impacted by the term of security subscription and support agreements and do not provide an indication as to the timing of revenue being recognized from these service contracts. Second, we may calculate billings in a manner that is different from peer companies that report similar financial measures. Management accounts for these limitations by providing specific information regarding GAAP revenue and evaluating billings together with GAAP revenue.

[0001262039-26-000003:8k_2_02:87]
Free cash flow (non-GAAP). We define free cash flow as net cash provided by operating activities minus purchases of property and equipment and excluding any significant non-recurring items, such as proceeds from intellectual property matters. Free cash flow margin is defined as free cash flow divided by GAAP revenue. We believe free cash flow to be a liquidity measure that provides useful information to management and investors about the amount of cash generated by the business that, after capital expenditures and net of proceeds from intellectual property matters, can be used for strategic opportunities, including repurchasing outstanding common stock, investing in our business, making strategic acquisitions and strengthening the balance sheet. A limitation of using free cash flow rather than the GAAP measures of cash provided by or used in operating activities, investing activities, and financing activities is that free cash flow does not represent the total increase or decrease in the cash and cash equivalents balance for the period because it excludes cash flows from significant non-recurring items, such as proceeds from intellectual property matters, investing activities other than capital expenditures and cash flows from financing activities. Management accounts for this limitation by providing information about our proceeds from intellectual property matters, our capital expenditures and other investing and financing activities on the face of the cash flow statement and under the caption “Management’s Discussion and Analysis of Financial Condition and Results of Operations—Liquidity and Capital Resources” in our most recent Quarterly Report on Form 10-Q and Annual Report on Form 10-K and by presenting cash flows from investing and financing activities in our reconciliation of free cash flow. In addition, it is important to note that other companies, including companies in our industry, may not use free cash flow, may calculate free cash flow in a different manner than we do or may use other financial measures to evaluate their performance, all of which could reduce the usefulness of free cash flow as a comparative measure.

[0001262039-26-000003:8k_2_02:88]
Adjusted free cash flow (non-GAAP). We define adjusted free cash flow as free cash flow plus cash payments associated with real estate purchases. Adjusted free cash flow margin is defined as adjusted free cash flow divided by GAAP revenue.

[0001262039-26-000003:8k_2_02:89]
Non-GAAP operating income and operating margin. We define non-GAAP operating income as operating income plus stock-based compensation, amortization of acquired intangible assets and charges in connection with litigation settlements, less gain on intellectual property matters and, when applicable, other significant non-recurring items in a given quarter. Non-GAAP operating margin is defined as non-GAAP operating income divided by GAAP revenue. We consider these non-GAAP financial measures to be useful metrics for management and investors because they exclude the items noted above so that our management and investors can compare our recurring core business operating results over multiple periods. There are a number of limitations related to the use of non-GAAP operating income instead of operating income calculated in accordance with GAAP. First, non-GAAP operating income excludes the items noted above. Second, the components of the costs that we exclude from our calculation of non-GAAP operating income may differ from the components that peer companies exclude when they report their non-GAAP results of operations. Management accounts for these limitations by providing specific information regarding the GAAP amounts excluded from non-GAAP operating income and evaluating non-GAAP operating income together with operating income calculated in accordance with GAAP.

[0001262039-26-000003:8k_2_02:90]
Non-GAAP net income and diluted net income per share. We define non-GAAP net income as net income plus the items noted above under non-GAAP operating income and operating margin. In addition, we adjust non-GAAP net income and diluted net income per share for a gain on bargain purchase related to acquisition, a gain from an equity method investment related to acquisition, a non-cash charge of impairment on an equity method investment and a tax adjustment required for an effective tax rate on a non-GAAP basis, which differs from the GAAP effective tax rate. We define non-GAAP diluted net income per share as non-GAAP net income divided by the non-GAAP diluted weighted-average shares outstanding. We consider these non-GAAP financial measures to be useful metrics for management and investors for the same reasons that we use non-GAAP operating income and non-GAAP operating margin. However, in order to provide a more complete picture of our recurring core business operating results, we include in non-GAAP net income and non-GAAP diluted net income per share, the tax adjustment required resulting in an effective tax rate on a non-GAAP basis, which often differs from the GAAP tax rate. We believe the non-GAAP effective tax rates we use are reasonable estimates of normalized tax rates for our current and prior fiscal years under our global operating structure. The same limitations described above regarding our use of non-GAAP operating income and non-GAAP operating margin apply to our use of non-GAAP net income and non-GAAP diluted net income per share. We account for these limitations by providing specific information regarding the GAAP amounts excluded from non-GAAP net income and non-GAAP diluted net income per share and evaluating non-GAAP net income and non-GAAP diluted net income per share together with net income and diluted net income per share calculated in accordance with GAAP.

[0001262039-26-000003:8k_2_02:91]
#          #          #

[0001262039-26-000003:8k_2_02:92]
Copyright © 2026 Fortinet, Inc. All rights reserved. The symbols ® and ™ denote respectively federally registered trademarks and common law trademarks of Fortinet, Inc., its subsidiaries and affiliates. Fortinet’s trademarks include, but are not limited to, the following: Fortinet, the Fortinet logo, FortiGate, FortiOS, FortiGuard, FortiCare, FortiAnalyzer, FortiManager, FortiASIC, FortiClient, FortiCloud, FortiCore, FortiMail, FortiSandbox, FortiADC, FortiAgent, FortiAI, FortiAIOps, FortiAntenna, FortiAP, FortiAPCam, FortiAppSec, FortiAuthenticator, FortiBranchSASE, FortiCall, FortiCam, FortiCamera, FortiCarrier, FortiCART, FortiCASB, FortiCentral, FortiCNP, FortiConnect, FortiController, FortiConverter, FortiCWP, FortiDAST, FortiDATA, FortiDB, FortiDevice, FortiDDoS, FortiDeceptor, FortiDeploy, FortiDevice, FortiDevSec, FortiDLP, FortiEdge, FortiEDR, FortiEndpoint, FortiExplorer, FortiExtender, FortiFirewall, FortiFlex, FortiFone, FortiGSLB, FortiGuest, FortiHypervisor, FortiIdentity, FortiInsight, FortiIsolator, FortiLAN, FortiLink, FortiMonitor, FortiNAC, FortiNDR, FortiPAM, FortiPhish, FortiPoint, FortiPoints, FortiPortal, FortiPresence, FortiProxy, FortiRecon, FortiRecorder, FortiSASE, FortiSEC, FortiSIEM, FortiSMS, FortiSOAR, FortiSRA, FortiSwitch, FortiTelemetry, FortiTester, FortiTIP, FortiToken, FortiTrust, FortiVoice, FortiWAN, FortiWeb, FortiWiFi, FortiWLC, FortiWLM, FortiXDR, Lacework FortiCNAPP, Linksys, Intelligent Mesh, Velop, Max-Stream, Performance Perfected and SECURITY FABRIC. Other trademarks belong to their respective owners. Fortinet has not independently verified statements or certifications herein attributed to third parties and Fortinet does not independently endorse such statements. Notwithstanding anything to the contrary herein, nothing herein constitutes a warranty, guarantee, contract, binding specification or other binding commitment by Fortinet or any indication of intent related to a binding commitment, and performance and other specification information herein may be unique to certain environments.

[0001262039-26-000003:8k_2_02:93]
FTNT-F

[0001262039-26-000003:8k_2_02:94]
Firewall research data provided by 650 Group as of Q3 2025.

[0001262039-26-000003:8k_2_02:95]
GARTNER is a registered trademark and service mark of Gartner, Inc. and/or its affiliates in the U.S. and internationally. All rights reserved.

[0001262039-26-000003:8k_2_02:96]
Gartner does not endorse any vendor, product, or service depicted in its research publications, and does not advise technology users to select only those vendors with the highest ratings or other designation. Gartner research publications consist of the opinions of Gartner’s research organization and should not be construed as statements of fact. Gartner disclaims all warranties, expressed or implied, with respect to this research, including any warranties of merchantability or fitness for a particular purpose.

[0001262039-26-000003:8k_2_02:97]
Note for Gartner Peer Insights™: Reviews from vendor partners or end users of companies with less than $50 million in revenue are excluded from this methodology. See the full “Voice of the Customer” methodology.

[0001262039-26-000003:8k_2_02:98]
Gartner and Peer Insights are trademarks of Gartner, Inc. and/or its affiliates. All rights reserved. Gartner Peer Insights content consists of the opinions of individual end users based on their own experiences, and should not be construed as statements of fact, nor do they represent the views of Gartner or its affiliates. Gartner does not endorse any vendor, product or service depicted in this content nor makes any warranties, expressed or implied, with respect to this content, about its accuracy or completeness, including any warranties of merchantability or fitness for a particular purpose.

[0001262039-26-000003:8k_2_02:99]
Gartner, Gartner Peer Insights ‘Voice of the Customer’ for Security Service Edge (SSE), Peer Contributors, 30 October 2025.

[0001262039-26-000003:8k_2_02:100]
Gartner, Gartner Peer Insights ‘Voice of the Customer’ for Security Service Edge (SSE), Peer Contributors, 27 September 2024.

[0001262039-26-000003:8k_2_02:101]
Gartner, Gartner Peer Insights ‘Voice of the Customer’ for Security Service Edge (SSE), Peer Contributors, 29 September 2023.

[0001262039-26-000003:8k_2_02:102]
| Investor Contact: |  | Media Contact: |
| Anthony Luscri |  | Stephanie Lira |
| Fortinet, Inc. |  | Fortinet, Inc. |
| 408-235-7700 |  | 408-235-7700 |
| investors@fortinet.com |  | pr@fortinet.com |
