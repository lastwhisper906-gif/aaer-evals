# FTNT notes — 0001262039-26-000007


## dei:DocumentsIncorporatedByReferenceTextBlock

[0001262039-26-000007:notes:1]
Portions of the registrant’s definitive Proxy Statement relating to its 2026 Annual Meeting of Stockholders (“Proxy Statement”) are incorporated by reference into Part III of this Annual Report on Form 10-K where indicated. Such Proxy Statement will be filed with the United States Securities and Exchange Commission within 120 days after the end of the fiscal year to which this report relates


## cyd:CybersecurityRiskManagementProcessesIntegratedTextBlock

[0001262039-26-000007:notes:2]
In general, we seek to address cybersecurity risks through a broad, cross-functional approach that is focused on preserving the confidentiality, security and availability of the information that we collect and store by identifying, preventing and mitigating cybersecurity threats and effectively responding to cybersecurity incidents when they occur.


## cyd:CybersecurityRiskBoardOfDirectorsOversightTextBlock

[0001262039-26-000007:notes:3]
Governance

[0001262039-26-000007:notes:4]
As a global cybersecurity provider, cybersecurity risk management is integral to our company. Historically, the Audit Committee of our board of directors (the “Audit Committee”) was responsible for reviewing with management our cybersecurity and other information technology risks, controls and processes, including the processes used to prevent or mitigate cybersecurity risks and respond to cybersecurity events. However, due to the importance of cybersecurity to our company, in July 2024, our board of directors formed Cybersecurity Committee of our board of directors (the “Cybersecurity Committee”), which is solely dedicated to cybersecurity risk management. Our executives with responsibility over cybersecurity, including our Chief Information Security Officer, provide quarterly reports to the Cybersecurity Committee as well as to the Chief Executive Officer and other members of our senior management as appropriate. Each member of our board of directors is invited to attend all meetings of the committees of our board of directors, including the Cybersecurity Committee, and thus all of the members of our board of directors are apprised of cybersecurity developments. The quarterly reports to the Cybersecurity Committee include updates on cyber risks and threats, the status of projects to strengthen our information security systems, assessments of the information security program and the emerging threat landscape. Our cybersecurity program is regularly evaluated by internal and external experts with the results of those reviews reported to senior management and the Cybersecurity Committee. We also actively engage with key vendors and intelligence and law enforcement communities as part of our continuing efforts to evaluate and enhance the effectiveness of our information security policies and procedures. The Cybersecurity Committee also receives prompt and timely information regarding any cybersecurity threat or incident that meets established reporting thresholds, as well as ongoing updates regarding any such threat or incident until it has been mitigated, resolved or otherwise addressed.

[0001262039-26-000007:notes:5]
We believe our systems and processes with respect to the management of risks associated with cybersecurity threats are adequate. We have experienced, and may in the future experience, adverse impacts to our operations as a result of cybersecurity incidents. However, to date, cybersecurity threats, including as a result of any previous cybersecurity incidents, have not materially affected our business strategy, operating results, and/or financial condition. If we were to experience a material cybersecurity incident in the future, such incident may have a material effect, including on our business strategy, operating results or financial condition. For more information regarding cybersecurity risks that we face and potential impacts on our business related thereto, see our risk factors, including our risk factor titled “If our internal enterprise IT networks, on which we conduct internal business and interface externally, our operational networks, through which we connect to customers, vendors and partners systems and provide services, or our research and development networks, our back-end labs and cloud stacks hosted in our data centers or PoPs, colocation vendors or public cloud providers, through which we research, develop and host products and services, are compromised, public perception of our products and services may be harmed, our customers may be breached and harmed, we may become subject to liability, and our business, operating results and stock price may be adversely impacted.”


## cyd:CybersecurityRiskManagementProcessesForAssessingIdentifyingAndManagingThreatsTextBlock

[0001262039-26-000007:notes:6]
Risk Management and Strategy

[0001262039-26-000007:notes:7]
As one of the critical elements of our overall ERM approach, our cybersecurity program is focused on the following key areas:

[0001262039-26-000007:notes:8]
Governance: As discussed in more detail above under the heading, “Governance,” our board of directors’ oversight of cybersecurity risk management is supported by the Cybersecurity Committee, which regularly interacts with executives with responsibility for cybersecurity, our Chief Executive Officer, Chief Technology Officer and President, Chief Financial Officer, Chief Operating Officer/General Counsel, our CISO, and other members of management. Our CISO is primarily responsible for our cybersecurity risk management program and partners with our legal team on data privacy matters at the management level. Our CISO, Dr. Carl Windsor, has over 26 years of experience in various technology and cybersecurity leadership positions, including over 19 years at our company driving product security and strategy and reports to the board Cybersecurity Committee. The CISO’s leadership team members are all seasoned information security professionals, covering a wide range of security disciplines, who have worked at some of the largest well-known brand names and are experts in their fields. Our CISO

[0001262039-26-000007:notes:9]
monitors, and participates in, our various cybersecurity policies and procedures, and our cybersecurity team regularly updates our CISO on the current status.

[0001262039-26-000007:notes:10]
Management is promptly updated regarding any significant security events and the Cybersecurity Committee regularly reviews updates from our CISO, information security and product security leaders about cyber threat response preparedness, security controls and procedures, security program maturity milestones, risk and approaches to risk mitigation and the current and emerging threat landscape. In addition, all members of our board of directors receive management’s cybersecurity updates to the Cybersecurity Committee as part of their regular attendance at meetings of our board of directors.

[0001262039-26-000007:notes:11]
Collaborative Approach: We have implemented a broad, cross-functional approach to identifying, preventing and mitigating cybersecurity threats and incidents, while also implementing controls and procedures that provide for the prompt escalation of certain cybersecurity incidents so that decisions regarding the public disclosure and reporting of such incidents can be made by management in a timely manner. In addition, we manage a cross-functional program across our engineering, manufacturing and technical services teams, together with our suppliers and channel partners, designed to ensure the proper security of our products from design through manufacture and shipment.

[0001262039-26-000007:notes:12]
Information Security: We implement organizational, administrative and technical measures based on commercially reasonable procedures using: (i) industry standard information security measures prescribed for use by NIST; (ii) security measures aligned with the ISO/IEC 27000 series of standards, (iii) Sarbanes-Oxley and SSAE 18/ISAE 3402; (iv) privacy regulations such as the GDPR and the CCPA; (v) business continuity management measures aligned with the ISO/IEC 22301 standard; and (vi) other generally recognized industry standards, in each case, designed to safeguard the confidentiality, integrity, and availability of our infrastructure and data and the resiliency of our operations.

[0001262039-26-000007:notes:13]
Technical Safeguards: We deploy technical safeguards that are designed to protect our information systems from cybersecurity threats, including firewalls, intrusion prevention and detection systems, anti-malware functionality and access controls, which are evaluated and improved through vulnerability assessments and cybersecurity threat intelligence.

[0001262039-26-000007:notes:14]
Incident Response and Recovery Planning: We have established and maintain broad incident response and recovery plans that help enable its effective and orderly management of, and response to, any identified security incidents, including escalation and internal and external-notification steps, allowing the incident response team to respond in a timely manner and enlist appropriate personnel and third-party experts. We maintain a process to promptly assess and assign severity levels to any identified security incidents in order to prioritize their importance and promptly direct resources to those issues of potentially greater impact. The notification plan establishes steps to alert external stakeholders as appropriate, including law enforcement, regulatory bodies, investors, customers and other business partners.

[0001262039-26-000007:notes:15]
Third-Party Risk Management: We maintain a broad, risk-based approach to identifying and overseeing cybersecurity risks presented by third parties, including vendors, service providers and other external users of our systems, as well as the systems of third parties that could adversely impact our business in the event of a cybersecurity incident affecting those third-party systems. In addition, our Trusted Supplier Program is designed to ensure manufacturing partners undergo a selection and qualification process that adheres to NIST 800-161.

[0001262039-26-000007:notes:16]
Education and Awareness: We provide regular, mandatory training for personnel and contractors regarding cybersecurity threats as a means to equip our personnel with effective tools to address cybersecurity threats and to communicate our evolving information security policies, standards, processes and practices.

[0001262039-26-000007:notes:17]
Risk and Readiness Assessments: We engage in the periodic assessment and testing of our policies, standards, processes and practices that are designed to identify vulnerabilities and weaknesses, address cybersecurity threats and test its readiness to respond to cyber security incidents. These efforts include a wide range of activities, including threat modeling, a variety of vulnerability and configuration scans, penetration testing, audits, tabletop exercises and other exercises focused on evaluating the effectiveness of our cybersecurity measures and planning. We regularly engage third parties to perform assessments on our cybersecurity measures, including information security maturity assessments, audits and independent reviews of our information security control environment and operating effectiveness and penetration tests. The results of such assessments, audits and reviews are reported to the Cybersecurity Committee and our board of directors and to our management, and we adjust its cybersecurity policies, standards, processes and practices as necessary based on the information provided by these assessments, audits and reviews.

[0001262039-26-000007:notes:18]
Insurance: We maintain information security risk insurance coverage.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001262039-26-000007:notes:19]
THE COMPANY AND SUMMARY OF SIGNIFICANT ACCOUNTING POLICIES
Business—Fortinet, Inc. (“Fortinet”) was incorporated in Delaware in 2000 and is a global leader in broad, integrated and automated cybersecurity solutions. Fortinet provides high performance cybersecurity solutions to a wide variety of businesses, such as large enterprises, communication service providers, government organizations and small to medium-sized enterprises. Fortinet’s cybersecurity solutions are designed to provide broad visibility and segmentation of the digital attack surface, through our integrated cybersecurity platform (the “Fortinet Security Fabric”) with automated protection, detection and response.

[0001262039-26-000007:notes:20]
Basis of Presentation and Preparation—The consolidated financial statements of Fortinet and its subsidiaries (collectively, “we,” “us”, or “our”) have been prepared in accordance with generally accepted accounting principles in the United States (“GAAP”). We consolidate all legal entities in which we have an absolute controlling financial interest. All intercompany transactions and balances have been eliminated in consolidation.

[0001262039-26-000007:notes:21]
Amounts previously reported as marketable equity securities are included in short-term investments in prior periods to conform with current period presentation in our consolidated balance sheets. Amounts previously reported as gain on bargain purchase are included in other income (expense)—net in prior periods to conform with current period presentation in our consolidated statements of income. Amounts previously reported as loss from equity method investments and gain on bargain purchase are included in other in prior periods to conform with current period presentation in section of net cash provided by operating activities in our consolidated statements of cash flows. The reclassification had no impact on our previously reported total assets, net income or cash flows from operating or investing activities and did not result in a restatement of prior period consolidated financial statements.

[0001262039-26-000007:notes:22]
Use of Estimates—The preparation of consolidated financial statements in accordance with GAAP requires management to make estimates and assumptions that affect the amounts reported in the consolidated financial statements and accompanying notes. Such management estimates include, but are not limited to, the determination of contingent liabilities, the standalone selling price for our products and services, the period of benefit for deferred contract costs for commissions, stock-based compensation, inventory valuation and liability for non-cancellable inventory purchase commitments with contract manufacturers and component suppliers, the fair value of tangible and intangible assets acquired and liabilities assumed in business combinations, the measurement of liabilities for uncertain tax positions and deferred tax assets and liabilities, the assessment of recoverability of our goodwill and other long-lived assets. We base our estimates on historical experience and also on assumptions that we believe are reasonable. Actual results could differ materially from those estimates.

[0001262039-26-000007:notes:23]
Concentration Risk—Financial instruments that subject us to concentrations of credit risk consist primarily of cash, cash equivalents, short-term and long-term investments, marketable equity securities and accounts receivable. Our cash balances are maintained as deposits with various large financial institutions in the United States and around the world. Balances in the United States typically exceed the amount of insurance provided on such deposits. We maintain our cash equivalents and investments in money market funds, corporate debt securities, U.S. government and agency securities, commercial paper and certificates of deposit and term deposits with major financial institutions that our management believes are financially sound.

[0001262039-26-000007:notes:24]
Our accounts receivable are derived from our customers in various geographic locations. We perform ongoing credit evaluations of our customers. We generally do not require collateral on accounts receivable, and we maintain reserves for estimated credit losses. See Note 15. Segment Information for distributor customers accounted for 10% or more of our revenue or net accounts receivable.

[0001262039-26-000007:notes:25]
We rely on a small number of manufacturing partners, with the majority of manufacturing in Taiwan and U.S., to manufacture our products, and some of the chips and other components of our products used by the contract manufacturers are available from limited or sole sources of supply. We do not own manufacturing activities in China. Our proprietary Application-Specific Integrated Circuits are built by contract manufacturers located in Japan and Taiwan; other integrated circuits are provided by other chip manufacturers.

[0001262039-26-000007:notes:26]
Financial Instruments and Fair Value—We define fair value as the price that would be received from selling an asset, or paid to transfer a liability, in an orderly transaction between market participants at the measurement date. When determining the fair value measurements for assets and liabilities which are required to be recorded at fair value, we consider the principal or most advantageous market in which to transact and the market-based risk. We apply fair value accounting for all financial assets and liabilities and non-financial assets and liabilities that are recognized or disclosed at fair value in the

[0001262039-26-000007:notes:27]
financial statements on a recurring basis. Due to their short-term nature, the carrying amounts reported in the consolidated financial statements approximate the fair value for cash and cash equivalents, accounts receivable, accounts payable, accrued liabilities, and accrued payroll and compensation.

[0001262039-26-000007:notes:28]
Comprehensive Income—Comprehensive income includes certain changes in equity from non-owner sources that are excluded from net income, specifically, cumulative foreign currency translation adjustments, unrealized gains and losses on available-for-sale investments and the related tax impacts.

[0001262039-26-000007:notes:29]
Foreign Currency and Transaction Gains and Losses—The functional currency for most of our foreign subsidiaries is the U.S. dollar. For our international subsidiary whose functional currency is the local currency, we translate the financial statements of this subsidiary to U.S. dollars using the exchange rates in effect at the balance sheet dates for assets and liabilities, and average monthly exchange rates for revenues, costs, and expenses. We record translation gains and losses in accumulated other comprehensive income as a component of stockholders’ equity (deficit). We reflect net foreign exchange transaction gains and losses resulting from the conversion of the transaction currency to functional currency as a component of foreign currency exchange gain (loss) in other income (expense)—net. We recognized a foreign currency loss of $4.9 million, $16.9 million and $7.0 million in other income (expense)—net, for 2025, 2024, and 2023, respectively.

[0001262039-26-000007:notes:30]
Cash and Cash Equivalents—We consider all highly liquid investments, purchased with original maturities of three months or less, to be cash equivalents. Cash and cash equivalents consist of balances with banks and highly liquid investments in commercial paper, corporate debt, U.S. government and agency securities, term deposits and money market funds.

[0001262039-26-000007:notes:31]
Available-for-Sale Investments—We hold investment grade securities consisting of corporate debt securities, U.S. government and agency securities, commercial paper and certificates of deposit and term deposits. We classify our investments as available-for-sale (“AFS”) at the time of purchase, since it is our intent that these investments are available for current operations. Investments with original maturities greater than three months with a remaining maturity of less than one year from the consolidated balance sheet date are classified as short-term investments. Investments with remaining maturities greater than one year from the consolidated balance sheet date are classified as long-term investments.

[0001262039-26-000007:notes:32]
Our AFS investments in debt securities are carried at estimated fair value with any unrealized gains and losses, net of taxes, included in accumulated other comprehensive income (loss) in the consolidated statements of stockholders’ equity (deficit). AFS debt securities with an amortized cost basis in excess of estimated fair value are assessed to determine what amount of that difference, if any, is caused by expected credit losses. An investment is impaired if the fair value of the investment is less than its cost. If the fair value of an investment is less than its amortized cost basis at the balance sheet date and if we do not intend to sell the investment, we consider available evidence to assess whether it is more likely than not that we will be required to sell the investment before the recovery of its amortized cost basis. We consider relevant quantitative and qualitative information, including general market conditions and the duration of the unrealized loss, in assessing whether a decline in fair value below amortized cost is attributable to credit related factors and whether we intend to sell, or will be required to sell, the security before recovery of its amortized cost basis. Once an impairment is determined to be attributable to credit-related factors, allowance for credit losses (i.e., the credit loss component) on AFS debt securities is recognized as credit loss expense, a charge in other income (expense)—net, on our consolidated statements of income, and any remaining unrealized losses (i.e., the non-credit loss component), net of taxes, are included in accumulated other comprehensive income (loss) on our consolidated statements of stockholders’ equity (deficit).

[0001262039-26-000007:notes:33]
We consider whether unrealized losses have resulted from a credit loss or other factors. The unrealized losses on our AFS debt securities as of December 31, 2025, 2024 and 2023 were caused by fluctuations in market value and interest rates as a result of the market conditions. We concluded that an allowance for credit losses was unnecessary as of December 31, 2025, 2024 and 2023 because (i) the decline in market value was attributable to changes in market conditions and not credit quality, and (ii) we concluded that neither do we intend to sell nor is it more likely than not that we will be required to sell these investments prior to recovery of their amortized cost basis. As a result, we had no credit losses recorded for the years ended December 31, 2025, 2024 and 2023.

[0001262039-26-000007:notes:34]
We determine realized gains or losses on sale of AFS debt securities using the specific identification method to determine the cost basis of investments sold and record such gains or losses as other income (expense)—net on the consolidated statements of income. We have elected to not record an allowance for credit losses for accrued interest for AFS investments in debt securities and will reverse the accrued interest against interest income in the period in which we determine the accrued interest to be uncollectible.

[0001262039-26-000007:notes:35]
Marketable Equity Securities—Our marketable equity investments with readily determinable fair values are accounted for at fair value through net income. Realized gains and losses as well as changes in fair value of these securities are recognized and reported in other income (expense)—net, and are determined using the specific identification method.

[0001262039-26-000007:notes:36]
Investments in privately held companies—Our investments in privately held companies consist of investments in common stock or in-substance common stock. Our equity method investments provide us with the ability to exercise significant influence over the investees, but not an absolute controlling financial interest. These investments are accounted for under the equity method of accounting and were initially recorded at cost. Subsequently, we recognize our proportionate share of the entity’s net profit or loss, the amortization of any basis differences, as well as any other-than-temporary impairment (“OTTI”) as gain or loss from these equity method investments in the consolidated statements of income and as an adjustment to the investment balance. We record our proportionate share of the results of these equity method investments on a three-month lag basis. We evaluate whether there are material transactions or events that occur during the intervening period that materially affect the financial position or results of operations. As of December 31, 2025, we had one equity method investment, and as of December 31, 2024, we had two equity method investments, including the investment in Linksys Holdings, Inc. (“Linksys”). As of December 31, 2025 and 2024, our equity method investments were recorded in other assets. Our remaining investments in privately held companies are recorded at cost and as of December 31, 2025 and 2024 were not material.

[0001262039-26-000007:notes:37]
We evaluate our equity method investments at the end of each reporting period to determine whether events or changes in business circumstances indicate that the carrying value of the investments may not be recoverable. Evidence of a loss in value might include, but would not necessarily be limited to, absence of an ability to recover the carrying amount of the investments or inability of the investee to sustain an earnings capacity that would justify the carrying amount of the investments. This evaluation consists of several qualitative and quantitative factors including recent financial results, projected financial results and operating trends of the investees and other publicly available information that may affect the value of our investments.

[0001262039-26-000007:notes:38]
Accounts receivable—Trade accounts receivable are recorded at the invoiced amount. Our accounts receivable balance is reduced by an allowance for expected credit losses. We measure expected credit losses of accounts receivable on a collective (pooled) basis, aggregating accounts receivable that are either current or no more than 60 days past due, and aggregating accounts receivable that are more than 60 days past due. We apply a credit-loss percentage to each of the pools that is based on our historical credit losses. We review whether each of our significant accounts receivable that is more than 60 days past due continues to exhibit similar risk characteristics with the other accounts receivable in the pool. If we determine that it does not, we evaluate it for expected credit losses on an individual basis.

[0001262039-26-000007:notes:39]
We further consider collectability trends for the allowance for credit losses based on our assessment of various factors, including credit quality of our customers, current economic conditions, reasonable and supportable forecasts of future economic conditions, and other factors that may affect our ability to collect from our customers. Expected credit losses are recorded as general and administrative expenses on our consolidated statements of income. The allowance for credit losses was $7.4 million and $5.9 million as of December 31, 2025 and 2024, respectively. Provisions, write-offs and recoveries were not material during the years ended December 31, 2025, 2024 and 2023.

[0001262039-26-000007:notes:40]
Inventory—Inventory is recorded at the lower of cost or net realizable value. Cost is computed using the first-in, first-out method. Inventory costs comprise primarily of the cost of materials and other component parts, as well as overhead costs. In assessing the ultimate recoverability of inventory, we make estimates regarding future customer demand, the timing of new product introductions, economic trends and market conditions. A write-down of inventory and a corresponding charge to cost of product revenue is recorded when inventory is determined to be in excess of anticipated demand or considered obsolete. At the point of the write-down loss recognition, a new, lower cost basis for that inventory is established, and subsequent changes in facts and circumstances do not result in the restoration or increase in that newly established cost basis. In addition, we record a liability for non-cancelable inventory purchase commitments with contract manufacturers and suppliers for quantities in excess of our future estimated demand forecasts. The expense related to such accrued liability for inventory purchase commitments is recorded in cost of product revenue on the consolidated statements of income.

[0001262039-26-000007:notes:41]
Property and Equipment—Property and equipment are stated at cost less accumulated depreciation. We do not depreciate the allocated cost of land. Depreciation is computed using the straight-line method over the estimated useful lives of the assets:

[0001262039-26-000007:notes:42]
|  | Estimated Useful Lives |
| Building and building improvements | 2 to 40 years |
| Computer equipment and software | 1 to 7 years |
| Evaluation units | 1 year |
| Furniture and fixtures | 3 to 8 years |
| Leasehold improvements | Shorter of useful life or lease term |

[0001262039-26-000007:notes:43]
Business Combinations—We include the results of operations of the businesses that we acquire as of the respective dates of acquisition. We allocate the fair value of the purchase price of our business acquisitions to the tangible and intangible assets acquired and liabilities assumed based on their estimated fair values. The excess of the purchase price over the fair values of these identifiable assets and liabilities is recorded as goodwill. The excess of the fair values of the net assets acquired over the net purchase consideration is recorded as a gain on bargain purchase within other income (expense)—net on the consolidated statements of income. We often continue to gather additional information throughout the measurement period, not to exceed one year from the acquisition date. Measurement period adjustments that relate to facts and circumstances that existed as of the acquisition date are generally recorded with a corresponding adjustment to goodwill, as if the accounting had been completed at the acquisition date. Adjustments identified after the measurement period are recognized in the consolidated statements of income in the period identified.

[0001262039-26-000007:notes:44]
Impairment of Long-Lived Assets—We evaluate events and changes in circumstances that could indicate carrying amounts of long-lived assets, including intangible assets, may not be recoverable. When such events or changes in circumstances occur, we assess the recoverability of long-lived assets by determining whether the carrying value of such assets will be recovered through undiscounted expected future cash flows. If the total of the future undiscounted cash flows is less than the carrying amount of those assets, we record an impairment charge in the period in which we make the determination. If such assets are considered to be impaired, the impairment to be recognized is measured by the amount by which the carrying amount of the assets exceeds the fair value of the assets. There were no impairments of long-lived assets in 2025, 2024 and 2023.

[0001262039-26-000007:notes:45]
Goodwill—Goodwill represents the excess of purchase consideration over the estimated fair value of net assets of businesses acquired in a business combination. Goodwill acquired in a business combination is not amortized, but instead tested for impairment at least annually during the fourth quarter, or sooner when circumstances indicate an impairment may exist. We perform a qualitative assessment in the fourth quarter of each year, or more frequently if indicators of potential impairment exist, to determine if any events or circumstances exist, such as an adverse change in business climate or a decline in the overall industry that would indicate that it would more likely than not reduce the fair value of a reporting unit below its carrying amount, including goodwill. If such evaluation indicates that it is more likely than not that the fair value of a reporting unit is less that its carrying amount, then the quantitative impairment test will be performed. Under the quantitative impairment test, if the carrying amount of a reporting unit exceeds its fair value, any excess is recognized as an impairment loss in goodwill, limited to the total amount of goodwill allocated to that reporting unit.

[0001262039-26-000007:notes:46]
We performed our annual goodwill impairment assessment and did not identify any impairment indicators as a result of the review. As of December 31, 2025 and 2024, we had one reporting unit.

[0001262039-26-000007:notes:47]
Other Intangible Assets—Intangible assets with finite lives are carried at cost, less accumulated amortization. Amortization is computed using the straight-line or accelerated method over the estimated economic lives of the assets, which range from one to ten years.

[0001262039-26-000007:notes:48]
Income Taxes—We record income taxes using the asset and liability method, which requires the recognition of deferred tax assets and liabilities for the expected future tax consequences of events that have been recognized in our financial statements or tax returns. In addition, deferred tax assets are recorded for the future benefit of utilizing net operating losses and research and development credit carryforwards. Deferred tax assets and liabilities are measured using the currently enacted tax rates that apply to taxable income in effect for the years in which those tax assets and liabilities are expected to be realized or settled. Valuation allowances are provided when necessary to reduce deferred tax assets to the amount expected to be realized.

[0001262039-26-000007:notes:49]
As part of the process of preparing our consolidated financial statements, we are required to estimate our taxes in each of the jurisdictions in which we operate. We estimate actual current tax exposure together with assessing temporary differences resulting from differing treatment of items, such as accruals and allowances not currently deductible for tax purposes. These differences result in deferred tax assets, which are included in our consolidated balance sheets. In general, deferred tax assets represent future tax benefits to be received when certain expenses previously recognized in our consolidated statements of income become deductible expenses under applicable income tax laws, or loss or credit carryforwards are utilized.

[0001262039-26-000007:notes:50]
In assessing the realizability of deferred tax assets, management considers whether it is more likely than not that some portion or all of the deferred tax assets will be realized. The ultimate realization of deferred tax assets is dependent upon the generation of future taxable income during the periods in which those temporary differences become deductible. We continue to assess the need for a valuation allowance on the deferred tax assets by evaluating both positive and negative evidence that may exist. Any adjustment to the valuation allowance on deferred tax assets would be recorded in the consolidated statements of income for the period that the adjustment is determined to be required.

[0001262039-26-000007:notes:51]
We recognize tax benefits from an uncertain tax position only if it is more likely than not, based on the technical merits of the position, that the tax position will be sustained on examination by the tax authorities. The tax benefits recognized in the financial statements from such positions are then measured based on the largest benefit that has a greater than 50% likelihood of being realized upon ultimate settlement.

[0001262039-26-000007:notes:52]
We have elected to account for the tax effect of the GILTI as a current period expense.

[0001262039-26-000007:notes:53]
On July 4, 2025, H.R. 1, an Act to Provide for Reconciliation Pursuant to Title II of House Concurrent Resolution 14 (the “Act”) commonly referred to as the One Big Beautiful Bill Act, was enacted. The Act makes permanent certain elements of the Tax Cuts and Jobs Act, including immediate expensing of U.S. research and development expenditures, immediate expensing of certain eligible assets, and various modifications to the international tax framework. As a result of the Act, our income tax liability in 2025 decreased by $120.0 million and our GAAP effective tax rate for 2025 increased by one percentage point.

[0001262039-26-000007:notes:54]
Stock-Based Compensation—The fair value of restricted stock units (“RSUs”) is based on the closing market price of our common stock on the date of grant. We have elected to use the Black-Scholes-Merton (“Black-Scholes”) pricing model to determine the fair value of our stock options and the Monte Carlo simulation pricing model to determine the fair value of our performance stock units (“PSUs”). Stock-based compensation expense of our RSUs and options is amortized on a straight-line basis over the service period and stock-based compensation expense of our PSUs is amortized using a graded vesting method over the vesting period. We account for forfeitures of all stock-based payment awards when they occur.

[0001262039-26-000007:notes:55]
Leases—We determine if an arrangement is a lease at inception. We evaluate the classification of leases at commencement and, as necessary, at modification. The right-of-use (“ROU”) assets and the short- and long-term lease liabilities from our operating leases are included in other assets, accrued liabilities and other liabilities in our consolidated balance sheets, respectively. The corresponding assets and, the short- and long-term lease liabilities from our finance leases are included in property and equipment, accrued liabilities and other liabilities in our consolidated balance sheets, respectively.

[0001262039-26-000007:notes:56]
The ROU assets represent our right to use an underlying asset for the lease term. Lease liabilities represent our obligation to make lease payments under the lease. Operating lease ROU assets and liabilities are recognized at the lease commencement date based on the present value of lease payments over the lease term. The implicit rate within our operating leases is generally not determinable and therefore we use our incremental borrowing rate at the lease commencement date to determine the present value of lease payments. The determination of our incremental borrowing rate requires judgment. We determine our incremental borrowing rate for each lease using indicative bank borrowing rates, adjusted for various factors including level of collateralization, term and currency to align with the terms of a lease. The operating lease ROU asset also includes any lease prepayments and initial direct costs, net of lease incentives. Certain leases include options to extend or terminate the lease. An option to extend the lease is considered in connection with determining the ROU asset and lease liability when it is reasonably certain we will exercise that option. An option to terminate is considered unless it is reasonably certain we will not exercise the option.

[0001262039-26-000007:notes:57]
We do not recognize lease liabilities or ROU assets for short-term leases (leases that, at the commencement date, have a lease term of 12 months or less and do not include an option to purchase the underlying asset that we are reasonably certain to exercise). We do not allocate the contract consideration for operating lease contracts with lease and non-lease components, and account for the lease and non-lease components as a single lease component.

[0001262039-26-000007:notes:58]
Payments under our lease arrangements are primarily fixed; however, certain lease agreements contain variable payments, which are expensed as incurred and not included in the operating lease ROU assets and liabilities. Variable lease payments primarily include common area maintenance charges, real estate taxes, certain parking expense, utilities based on actual usage, and insurance costs. Lease expense for lease payments for our operating leases is recognized on a straight-line basis over the term of the lease. We begin recognizing rent expense on the date that a lessor makes an underlying asset that is subject to the lease available for our use. For our finance leases, we recognize amortization expense from the amortization of the corresponding assets and interest expense on the related lease liabilities.

[0001262039-26-000007:notes:59]
Advertising Expense—Advertising costs are expensed when incurred and are included in operating expenses in the accompanying consolidated statements of income. Our advertising expenses were not material for any periods presented.

[0001262039-26-000007:notes:60]
Research and Development Costs—Research and development costs are expensed as incurred, and primarily consist of personnel costs. Research and development costs also include ASIC and system prototype and certification-related expenses, depreciation of property and equipment and facility-related expenses. The majority of our research and development is focused on software and hardware development.

[0001262039-26-000007:notes:61]
Software Development Costs—The costs to develop software that is marketed have not been capitalized as we believe our current software development process is essentially completed concurrently with the establishment of technological feasibility. Such costs are expensed as incurred and included in research and development in our consolidated statements of income.

[0001262039-26-000007:notes:62]
The costs to develop software for internal use are capitalized based on qualifying criteria. These costs consist of internal compensation related costs and external direct costs incurred during the application development stage. Such costs are amortized over the software’s estimated useful life. Internal use software development costs capitalized were not material for any periods presented.

[0001262039-26-000007:notes:63]
Deferred Contract Costs and Commission Expense—Sales commissions earned by our sales force are considered incremental and recoverable costs of obtaining a contract with a customer. We recognize sales commissions expenses related to product sales upfront while sales commissions expenses for service contracts are deferred as deferred contract costs in the consolidated balance sheets and amortized over the applicable amortization period. Commission costs for initial contracts that are not commensurate with commissions on renewal contracts are amortized on a straight-line basis over the period of benefit, which we have determined to be five years and which is typically longer than the initial contract term. The amortization of deferred contract costs is included in sales and marketing expenses in our consolidated statements of income. Amortization of deferred contract costs during 2025, 2024 and 2023 was $336.3 million, $293.7 million and $266.3 million, respectively. No impairment loss of deferred contract costs asset was recognized during 2025, 2024 and 2023.

[0001262039-26-000007:notes:64]
Deferred Revenue—Deferred revenue consists of amounts that have been invoiced but that have not yet been recognized as revenue. Deferred revenue that will be recognized during the succeeding 12-month period is recorded as current deferred revenue and the remaining portion is recorded as non-current deferred revenue. The majority of deferred revenue is comprised of security subscription and technical support services which are invoiced upfront and delivered over 12 months or longer.

[0001262039-26-000007:notes:65]
Revenue Recognition—Our revenue consists of product and service revenue. Revenues are recognized when control of these goods or services is transferred to our customers, in an amount that reflects the consideration we expect to be entitled to in exchange for those goods or services. We determine revenue recognition through the following steps:

[0001262039-26-000007:notes:66]
•identification of a contract or contracts with a customer;

[0001262039-26-000007:notes:67]
•identification of the performance obligations in a contract, including evaluation of performance obligations and evaluating the distinct goods or services in a contract;

[0001262039-26-000007:notes:68]
•determination of a transaction price;

[0001262039-26-000007:notes:69]
•allocation of a transaction price to the performance obligations in a contract; and

[0001262039-26-000007:notes:70]
•recognition of revenue when, or as, we satisfy a performance obligation.

[0001262039-26-000007:notes:71]
We derive a significant amount of product sales from FortiGate, a secure networking hardware which include a broad set of built-in security and networking features and functionalities, including firewall, next-generation firewall, secure web gateway, SSL inspection, software-defined wide-area network, intrusion prevention, SSL data leak prevention, virtual private network, switch and wireless controller and wide area network edge.

[0001262039-26-000007:notes:72]
We recognize product revenue upon shipment when control of the promised goods is transferred to the customer. Our term-based software licenses represent multiple performance obligations, which include software licenses and software support services where the software licenses are recognized upfront within product revenue upon transfer of control, and the associated software support services are recognized ratably over the service term as service revenue.

[0001262039-26-000007:notes:73]
Service revenue relates to sales of our FortiGuard and other security subscriptions, FortiCare technical support services and other services. Our typical subscription and support term is one to five years. We generally recognize revenue from these services ratably over the service term because of continuous transfer of control to the customer. We also generate a portion of our revenue from other services consisting of professional services and training. Security subscription include SaaS which is either hosted by us or provided through cloud providers. We recognize revenue from professional and training services as the services are provided. We recognize revenue from SaaS as the subscription service is delivered over the term, or on a monthly usage basis.

[0001262039-26-000007:notes:74]
Our sales contracts typically contain performance obligations, such as hardware, software license, security subscription, technical support services, SaaS and other services, which are generally capable of being distinct and accounted for as separate performance obligations. Our hardware and software licenses have significant standalone functionalities and capabilities. Accordingly, the hardware and software licenses are distinct from the security subscription and technical support services, as a customer can benefit from the product without the services and the services are separately identifiable within a contract. We allocate the transaction price to each performance obligation based on relative standalone selling price. We establish standalone selling price using the prices charged for a deliverable when sold separately. If not observable through past transactions, we determine standalone selling price by considering multiple historical factors including, but not limited to, cost of products, gross margin objectives, pricing practices, geographies and the term of a service contract. Revenue is reported net of sales tax.

[0001262039-26-000007:notes:75]
In certain circumstances, our contracts include provisions for sales rebates and other customer incentive programs. Additionally, in limited circumstances, we may permit end-customers, distributors and resellers to return our products, subject to varying limitations, for a refund within a reasonably short period from the date of purchase. These amounts are accounted for as variable consideration that can decrease the transaction price. We estimate variable consideration using the expected-value method based on the most likely amounts to which we expect our customers to be entitled. We include estimated amounts in the transaction price to the extent that it is probable that a significant reversal of cumulative revenue recognized will not occur when the uncertainty associated with the variable consideration is resolved. Our estimate for refund liabilities, which include sales returns reserve and customer rebates, was $52.0 million and $71.8 million as of December 31, 2025 and 2024, respectively, and is included in accrued liabilities in our consolidated balance sheet.

[0001262039-26-000007:notes:76]
We generally invoice at the time of our sale for the total price of the hardware, software licenses, security subscription and technical support and other services. Standard payment terms are generally no more than 60 days, though we continue to offer extended payment terms to certain distributors. Amounts billed and due from our customers are classified as receivables on the balance sheet and do not bear interest.

[0001262039-26-000007:notes:77]
Shipping and handling fees charged to our customers are recognized as revenue in the period shipped and the related costs for providing these services are recorded in cost of revenue. Shipping and handling fees recognized were not material during 2025, 2024 and 2023.

[0001262039-26-000007:notes:78]
Warranties—We generally provide a one-year warranty for most hardware products and a 90-day warranty for software. We also provide extended warranties under the terms of our support agreements. A provision for estimated future costs related to warranty activities in the first year after product sale is recorded as a component of cost of product revenues when the product revenue is recognized, based upon historical product failure rates and historical costs incurred in correcting product failures. Warranty costs related to extended warranties sold under support agreements are recognized as cost of service revenue as incurred. Accrued warranty liability was not material as of December 31, 2025 and 2024.

[0001262039-26-000007:notes:79]
Contingent Liabilities—From time to time, we are involved in disputes, litigation, and other legal actions. There are many uncertainties associated with any disputes, litigation and other legal actions, and these actions or other third-party claims

[0001262039-26-000007:notes:80]
against us may cause us to incur costly litigation fees, costs and substantial settlement charges, and possibly subject us to damages and other penalties, which are inherently difficult to estimate and could adversely affect our results of operations. In addition, the resolution of any IP litigation may require us to make royalty payments, which could adversely affect our gross margins in future periods. We periodically review significant claims and litigation matters for the probability of an adverse outcome. Estimates can change as individual claims develop. The actual liability in any such matters may be materially different from our estimates, which could result in the need to adjust our liability and record additional expenses, which may be material.

[0001262039-26-000007:notes:81]
Recently Adopted Accounting Standards

[0001262039-26-000007:notes:82]
Income Taxes

[0001262039-26-000007:notes:83]
In December 2023, the Financial Accounting Standards Board (the “FASB”) issued Accounting Standards Update (“ASU”) 2023-09, Income Taxes (Topic 740): Improvements to Income Tax Disclosures, which includes amendments that further enhance income tax disclosures, primarily through standardization and disaggregation of rate reconciliation categories and income taxes paid by jurisdiction. We adopted ASU 2023-09 for our annual period beginning fiscal year 2025 on a prospective basis. Refer to Note 13. Income Taxes.

[0001262039-26-000007:notes:84]
Recent Accounting Standards Not Yet Effective

[0001262039-26-000007:notes:85]
Expense Disaggregation Disclosures

[0001262039-26-000007:notes:86]
In November 2024, the FASB issued ASU 2024-03, Income Statement—Reporting Comprehensive Income—Expense Disaggregation Disclosures (Subtopic 220-40): Disaggregation of Income Statement Expenses (“ASU 2024-03”), and in January 2025, the FASB issued ASU No. 2025-01, Income Statement—Reporting Comprehensive Income—Expense Disaggregation Disclosures (Subtopic 220-40): Clarifying the Effective Date, which clarified the effective date of ASU 2024-03. ASU 2024-03 enhances the disclosures required for expense disaggregation in our annual and interim consolidated financial statements. The amendments are effective for our annual reporting period beginning fiscal 2027, with early adoption permitted, and can be applied prospectively or retrospectively. We are currently evaluating the ASU to determine its impact on our disclosures.

[0001262039-26-000007:notes:87]
Credit Losses

[0001262039-26-000007:notes:88]
In July 2025, the FASB issued ASU 2025-05—Financial Instruments—Credit Losses (Topic 326): Measurement of Credit Losses for Accounts Receivable and Contract Assets (“ASU 2025-05”), which provides a practical expedient for estimating expected credit losses for current accounts receivable and current contract assets that arise from transactions accounted for under Revenue from Contracts with Customers (Topic 606). The amendments are effective for our annual reporting period beginning with fiscal year 2026 and interim reporting periods within those annual reporting periods on a prospective basis, with early adoption permitted. We are currently evaluating ASU 2025-05 to determine its impact on our consolidated financial statements and related disclosures.

[0001262039-26-000007:notes:89]
Internal-Use Software

[0001262039-26-000007:notes:90]
In September 2025, the FASB issued ASU 2025-06, Intangibles—Goodwill and Other—Internal-Use Software (Subtopic 350-40): Targeted Improvements to the Accounting for Internal-Use Software (“ASU 2025-06”), which amends the cost capitalization criteria for internal-use software development costs by removing all references to prescriptive and sequential software project development stages and providing new guidance on how to evaluate whether the probable-to-complete recognition threshold has been met. The amendments are effective for our annual period beginning fiscal year 2028 and interim reporting periods within those annual reporting periods and can be applied prospectively, retrospectively, or via a modified prospective transition method, with early adoption permitted. We are currently assessing adoption timing and the method of adoption.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001262039-26-000007:notes:91]
REVENUE RECOGNITION
Disaggregation of Revenue

[0001262039-26-000007:notes:92]
The following table presents our revenue disaggregated by major product and service lines (in millions):

[0001262039-26-000007:notes:93]
|  | Year Ended December 31, |
|  | 2025 |  | 2024 |  | 2023 |
| Product | $ | 2,218.4 |  |  | $ | 1,908.7 |  |  | $ | 1,927.3 |  |
| Service: |  |  |  |  |  |
| Security subscription | 2,633.2 |  |  | 2,316.7 |  |  | 1,898.1 |  |
| Technical support and other | 1,948.0 |  |  | 1,730.4 |  |  | 1,479.4 |  |
| Total service revenue | 4,581.2 |  |  | 4,047.1 |  |  | 3,377.5 |  |
| Total revenue | $ | 6,799.6 |  |  | $ | 5,955.8 |  |  | $ | 5,304.8 |  |

[0001262039-26-000007:notes:94]
Deferred Revenue

[0001262039-26-000007:notes:95]
During 2025 and 2024, we recognized $3.26 billion and $2.84 billion in revenue that was included in the deferred revenue balance as of December 31, 2024 and 2023, respectively.

[0001262039-26-000007:notes:96]
Transaction Price Allocated to the Remaining Performance Obligations

[0001262039-26-000007:notes:97]
As of December 31, 2025, the aggregate amount of the transaction price allocated to remaining performance obligations was $7.18 billion, which was substantially comprised of deferred security subscription and technical support services revenue as well as unbilled contract revenue from non-cancellable contracts that will be recognized in future periods. We expect to recognize approximately $3.66 billion as revenue over the next 12 months, $2.80 billion in years two and three, and the remainder thereafter.


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0001262039-26-000007:notes:98]
FINANCIAL INSTRUMENTS AND FAIR VALUE
Short-Term and Long-Term Investments

[0001262039-26-000007:notes:99]
Our short-term and long-term investments comprised of available-for-sale investments and marketable equity securities. The following tables summarize our short-term and long-term investments (in millions):

[0001262039-26-000007:notes:100]
|  | December 31, 2025 |
|  | AmortizedCost |  | UnrealizedGains |  | UnrealizedLosses |  | FairValue |
| U.S. government and agency securities | $ | 513.7 |  |  | $ | 0.9 |  |  | $ | — |  |  | $ | 514.6 |  |
| Corporate debt securities | 368.5 |  |  | 0.4 |  |  | (0.1) |  |  | 368.8 |  |
| Commercial paper | 354.8 |  |  | 0.1 |  |  | — |  |  | 354.9 |  |
| Certificates of deposit and term deposits | 90.3 |  |  | 0.1 |  |  | — |  |  | 90.4 |  |
| Total available-for-sale investments | 1,327.3 |  |  | 1.5 |  |  | (0.1) |  |  | 1,328.7 |  |
| Marketable equity securities |  |  |  |  |  |  | 98.2 |  |
| Total short-term and long-term investments | $ | 1,327.3 |  |  | $ | 1.5 |  |  | $ | (0.1) |  |  | $ | 1,426.9 |  |
|  | December 31, 2024 |
|  | AmortizedCost |  | UnrealizedGains |  | UnrealizedLosses |  | FairValue |
| U.S. government and agency securities | $ | 469.1 |  |  | $ | 0.4 |  |  | $ | — |  |  | $ | 469.5 |  |
| Corporate debt securities | 166.4 |  |  | 0.1 |  |  | (0.1) |  |  | 166.4 |  |
| Commercial paper | 428.7 |  |  | 0.2 |  |  | (0.2) |  |  | 428.7 |  |
| Certificates of deposit and term deposits | 61.8 |  |  | — |  |  | — |  |  | 61.8 |  |
| Total available-for-sale investments | 1,126.0 |  |  | 0.7 |  |  | (0.3) |  |  | 1,126.4 |  |
| Marketable equity securities |  |  |  |  |  |  | 64.2 |  |
| Total short-term and long-term investments | $ | 1,126.0 |  |  | $ | 0.7 |  |  | $ | (0.3) |  |  | $ | 1,190.6 |  |

[0001262039-26-000007:notes:101]
The following tables show the gross unrealized losses and the related fair values of our available-for-sale investments that have been in a continuous unrealized loss position (in millions):

[0001262039-26-000007:notes:102]
|  | December 31, 2025 |
|  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
|  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |
| U.S. government and agency securities | $ | 514.5 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 514.5 |  |  | $ | — |  |
| Corporate debt securities | 368.9 |  |  | (0.1) |  |  | — |  |  | — |  |  | 368.9 |  |  | (0.1) |  |
| Commercial paper | 354.9 |  |  | — |  |  | — |  |  | — |  |  | 354.9 |  |  | — |  |
| Certificates of deposit and term deposits | 90.4 |  |  | — |  |  | — |  |  | — |  |  | 90.4 |  |  | — |  |
| Total available-for-sale investments | $ | 1,328.7 |  |  | $ | (0.1) |  |  | $ | — |  |  | $ | — |  |  | $ | 1,328.7 |  |  | $ | (0.1) |  |

[0001262039-26-000007:notes:103]
|  | December 31, 2024 |
|  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
|  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |
| U.S. government and agency securities | $ | 27.8 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 27.8 |  |  | $ | — |  |
| Corporate debt securities | 63.5 |  |  | (0.1) |  |  | — |  |  | — |  |  | 63.5 |  |  | (0.1) |  |
| Commercial paper | 149.4 |  |  | (0.2) |  |  | — |  |  | — |  |  | 149.4 |  |  | (0.2) |  |
| Certificates of deposit and term deposits | 10.9 |  |  | — |  |  | — |  |  | — |  |  | 10.9 |  |  | — |  |
| Total available-for-sale investments | $ | 251.6 |  |  | $ | (0.3) |  |  | $ | — |  |  | $ | — |  |  | $ | 251.6 |  |  | $ | (0.3) |  |

[0001262039-26-000007:notes:104]
The contractual maturities of our available-for-sale investments were (in millions):

[0001262039-26-000007:notes:105]
|  | December 31,2025 |  | December 31,2024 |
| Due within one year | $ | 989.0 |  |  | $ | 1,126.4 |  |
| Due within one to three years | 339.7 |  |  | — |  |
| Total | $ | 1,328.7 |  |  | $ | 1,126.4 |  |

[0001262039-26-000007:notes:106]
We do not intend to sell any of the securities in an unrealized loss position and it is not more likely than not that we would be required to sell these securities before recovery of their amortized cost basis, which may be at maturity.

[0001262039-26-000007:notes:107]
Realized gains and losses on available-for-sale investments were insignificant in the periods presented.

[0001262039-26-000007:notes:108]
The changes in fair value of our marketable equity securities are recorded in other income (expense)—net on the consolidated statements of income. We recognized $10.8 million and $26.4 million gain and $4.4 million loss in 2025, 2024 and 2023, respectively.

[0001262039-26-000007:notes:109]
Fair Value of Financial Instruments

[0001262039-26-000007:notes:110]
Fair Value Accounting—We apply the following fair value hierarchy for disclosure of the inputs used to measure fair value. This hierarchy prioritizes the inputs into three broad levels:

[0001262039-26-000007:notes:111]
Level 1—Inputs are unadjusted quoted prices in active markets for identical assets or liabilities.

[0001262039-26-000007:notes:112]
Level 2—Inputs are quoted prices for similar assets and liabilities in active markets or inputs that are observable for the assets or liabilities, either directly or indirectly through market corroboration, for substantially the full term of the financial instruments.

[0001262039-26-000007:notes:113]
Level 3—Unobservable inputs based on our own assumptions used to measure assets and liabilities at fair value. The inputs require significant management judgment or estimation.

[0001262039-26-000007:notes:114]
We measure the fair value of money market funds, certain U.S. government and agency securities and marketable equity securities using quoted prices in active markets for identical assets. The fair value of all other financial instruments was based on quoted prices for similar assets in active markets, or model-driven valuations using significant inputs derived from or corroborated by observable market data.

[0001262039-26-000007:notes:115]
Assets Measured at Fair Value on a Recurring Basis

[0001262039-26-000007:notes:116]
The following table presents the fair value of our financial assets measured at fair value on a recurring basis (in millions):

[0001262039-26-000007:notes:117]
|  | December 31, 2025 |  | December 31, 2024 |
|  | AggregateFairValue |  | QuotedPrices inActiveMarkets ForIdenticalAssets |  | SignificantOtherObservableRemainingInputs |  | SignificantOtherUnobservableRemainingInputs |  | AggregateFairValue |  | QuotedPrices inActiveMarkets ForIdenticalAssets |  | SignificantOtherObservableRemainingInputs |  | SignificantOtherUnobservableRemainingInputs |
|  |  |  | (Level 1) |  | (Level 2) |  | (Level 3) |  |  |  | (Level 1) |  | (Level 2) |  | (Level 3) |
| Cash equivalents: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | $ | 174.4 |  |  | $ | 174.4 |  |  | $ | — |  |  | $ | — |  |  | $ | 296.1 |  |  | $ | 296.1 |  |  | $ | — |  |  | $ | — |  |
| Corporate debt securities | 1.1 |  |  | — |  |  | 1.1 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Commercial paper | 38.1 |  |  | — |  |  | 38.1 |  |  | — |  |  | 59.7 |  |  | — |  |  | 59.7 |  | — |  |
| Total cash equivalents | 213.6 |  |  | 174.4 |  |  | 39.2 |  |  | — |  |  | 355.8 |  |  | 296.1 |  |  | 59.7 |  |  | — |  |
| Short-term investments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. government and agency securities | 383.5 |  |  | 381.5 |  |  | 2.0 |  |  | — |  |  | 469.5 |  |  | 464.5 |  |  | 5.0 |  |  | — |  |
| Corporate debt securities | 160.2 |  |  | — |  |  | 160.2 |  |  | — |  |  | 166.4 |  |  | — |  |  | 166.4 |  |  | — |  |
| Commercial paper | 354.9 |  |  | — |  |  | 354.9 |  |  | — |  |  | 428.7 |  |  | — |  |  | 428.7 |  |  | — |  |
| Certificates of deposit and term deposits | 90.4 |  |  | — |  |  | 90.4 |  |  | — |  |  | 61.8 |  |  | — |  |  | 61.8 |  |  | — |  |
| Marketable equity securities | 98.2 |  |  | 98.2 |  |  | — |  |  | — |  |  | 64.2 |  |  | 64.2 |  |  | — |  |  | — |  |
| Total short-term investments | 1,087.2 |  |  | 479.7 |  |  | 607.5 |  |  | — |  |  | 1,190.6 |  |  | 528.7 |  |  | 661.9 |  |  | — |  |
| Long-term investments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. government and agency securities | 131.1 |  |  | 121.8 |  |  | 9.3 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Corporate debt securities | 208.6 |  |  | — |  |  | 208.6 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Total long-term investments | 339.7 |  |  | 121.8 |  |  | 217.9 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Total | $ | 1,640.5 |  |  | $ | 775.9 |  |  | $ | 864.6 |  |  | $ | — |  |  | $ | 1,546.4 |  |  | $ | 824.8 |  |  | $ | 721.6 |  |  | $ | — |  |

[0001262039-26-000007:notes:118]
There were no transfers between Level 1 and Level 2 of the fair value hierarchy during the years ended December 31, 2025 and December 31, 2024.


## us-gaap:InventoryDisclosureTextBlock

[0001262039-26-000007:notes:119]
INVENTORY
Inventory, net of reserves, consisted of (in millions):

[0001262039-26-000007:notes:120]
|  | December 31,2025 |  | December 31,2024 |
| Raw materials | $ | 61.9 |  |  | $ | 90.9 |  |
| Work in process | 3.0 |  |  | 4.1 |  |
| Finished goods | 334.6 |  |  | 220.5 |  |
| Inventory | $ | 399.5 |  |  | $ | 315.5 |  |

[0001262039-26-000007:notes:121]
The excess and obsolete inventory reserve was $137.5 million and $144.8 million as of December 31, 2025 and 2024, respectively. Inventory write-downs related to excess and obsolete inventory were not material for the year ended December 31, 2025, and were $37.1 million and $35.8 million for the years ended December 31, 2024 and 2023 respectively. These were recorded in cost of product revenue on the consolidated statements of income.


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001262039-26-000007:notes:122]
PROPERTY AND EQUIPMENT—Net
Property and equipment—net consisted of (in millions):

[0001262039-26-000007:notes:123]
|  | December 31,2025 |  | December 31,2024 |
| Land | $ | 592.4 |  |  | $ | 500.6 |  |
| Buildings and improvements | 974.0 |  |  | 801.4 |  |
| Computer equipment and software | 341.0 |  |  | 279.1 |  |
| Leasehold improvements | 58.5 |  |  | 64.3 |  |
| Evaluation units | 24.1 |  |  | 31.8 |  |
| Furniture and fixtures | 36.3 |  |  | 36.4 |  |
| Construction-in-progress | 74.6 |  |  | 52.0 |  |
| Total property and equipment | 2,100.9 |  |  | 1,765.6 |  |
| Less: accumulated depreciation | (481.9) |  |  | (416.1) |  |
| Property and equipment—net | $ | 1,619.0 |  |  | $ | 1,349.5 |  |

[0001262039-26-000007:notes:124]
During 2025, we purchased certain real estate properties in California, United States; Burnaby, Canada; Frankfurt, Germany; Almere, the Netherlands; and London, the United Kingdom, totaling $255.8 million. The purchases were accounted for under the asset acquisition method. The costs of the assets allocated to land and buildings and improvements were $97.3 million and $158.5 million, respectively, based on their relative fair values.

[0001262039-26-000007:notes:125]
During 2024, we purchased certain real estate in California, Georgia and New York, United States, and Alberta, Canada, totaling $295.8 million. The purchases were accounted for under the asset acquisition method. The costs of the assets allocated to land, buildings and improvements and furniture and fixtures were $149.0 million, $145.7 million and $1.1 million, respectively, based on their relative fair values.

[0001262039-26-000007:notes:126]
Depreciation expense was $101.3 million, $99.7 million and $94.5 million in 2025, 2024 and 2023, respectively.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001262039-26-000007:notes:127]
BUSINESS COMBINATIONS
2025 Acquisitions

[0001262039-26-000007:notes:128]
Linksys Holdings, Inc.

[0001262039-26-000007:notes:129]
In 2021, we invested $160.0 million in cash for shares of the Series A Preferred Stock of Linksys for a 50.8% ownership interest in the outstanding equity of Linksys. On January 31, 2025 (“Linksys Acquisition Date”), we acquired all of the remaining outstanding Series A Preferred Stock of Linksys for $20.8 million in cash and now own 100% of the outstanding equity of Linksys. Our pre-existing equity method investment in Linksys of 50.8% ownership interest was remeasured to the fair value of $21.5 million at the Linksys Acquisition Date, which resulted in a $10.8 million gain recorded in gain (loss) from equity method investments on the consolidated statements of income. Therefore, the aggregate purchase consideration for Linksys’ equity equaling the fair value of the previously owned stock and the purchase price for the remaining stock acquired was $42.3 million.

[0001262039-26-000007:notes:130]
This acquisition was accounted for as a business combination using the acquisition method of accounting. Of the aggregate purchase price, $17.5 million was allocated to identifiable intangible assets acquired and $64.7 million was allocated to other net assets acquired which predominantly included deferred tax asset of $45.8 million, inventory of $21.4 million and cash of $8.8 million, offset by $11.3 million of net other assets and liabilities assumed. The excess of the fair values of the net assets acquired over the net purchase consideration was recorded as a gain on bargain purchase of $39.9 million within other income (expense)—net on the consolidated statements of income. The gain on bargain purchase occurred primarily due to the recognition of the deferred tax assets, which were comprised primarily of pre-acquisition federal net operating loss carryforwards with an indefinite carryforward period. In addition, we had previously recorded a deferred tax asset of $30.6 million for an outside basis difference in our investment in Linksys when it was accounted for under the equity method. As a result of the acquisition of the remaining shares, we now account for our investment in Linksys under the consolidation method, and therefore we have derecognized this deferred tax asset. The charge is included in the provision for income taxes on the consolidated statements of income. Acquisition-related costs related to this acquisition were not material and were recorded as general and administrative expenses.

[0001262039-26-000007:notes:131]
Other Acquisitions

[0001262039-26-000007:notes:132]
In 2025, we completed other acquisitions for total purchase consideration of $38.3 million in cash. We have accounted for the transactions as business combinations and recorded goodwill of $21.9 million, among which $8.6 million of goodwill is expected to be deductible and $13.3 million of goodwill is not deductible for income tax purposes. Acquisition-related costs were not material and were recorded as general and administrative expenses.

[0001262039-26-000007:notes:133]
2024 Acquisitions

[0001262039-26-000007:notes:134]
Perception Point Ltd.

[0001262039-26-000007:notes:135]
On December 5, 2024, we acquired certain assets and liabilities of Perception Point Ltd., a business specializing in advanced collaboration and email security, for which we paid in cash. This acquisition was accounted for as a business combination using the acquisition method of accounting. Of the $33.7 million purchase price, $24.5 million was allocated to goodwill, $9.5 million was allocated to developed technology intangible asset, $6.5 million was allocated to customer relationships intangible asset and $6.8 million was allocated to other net liabilities assumed, which predominantly include deferred revenue. Goodwill recorded in connection with this acquisition is primarily attributable to the assembled workforce acquired and the anticipated operational synergies. All acquired goodwill is deductible for U.S. tax purposes. Acquisition-related costs were not material and were recorded as general and administrative expenses.

[0001262039-26-000007:notes:136]
Next DLP Holdings Limited

[0001262039-26-000007:notes:137]
On August 5, 2024, we acquired Next DLP Holdings Limited (“Next DLP”), a privately held insider risk and data loss prevention (“DLP”) company, for approximately $105.0 million in cash. We acquired Next DLP in an effort to improve our position in the standalone enterprise DLP market and strengthen our leadership in integrated DLP markets within endpoint and unified Secure Access Service Edge (“SASE”).

[0001262039-26-000007:notes:138]
This acquisition was accounted for as a business combination using the acquisition method of accounting. The total purchase price was allocated to Next DLP’s identifiable tangible and intangible assets acquired and liabilities assumed based on their estimated fair values using management’s best estimates and assumptions to assign fair value as of the acquisition date. Of the total purchase price, $82.6 million was allocated to goodwill, $13.5 million was allocated to developed technology intangible asset, $10.5 million was allocated to customer relationships intangible asset, offset by $1.6 million of net liabilities assumed, which predominantly included deferred revenue and deferred tax liabilities. Goodwill recorded in connection with this acquisition represents the value we expect to be created through expansion into markets within our existing business and the anticipated operational synergies. The goodwill is deductible for U.S. tax purposes. Acquisition-related costs related to this acquisition were not material and were recorded as general and administrative expenses.

[0001262039-26-000007:notes:139]
Lacework Inc.

[0001262039-26-000007:notes:140]
On August 1, 2024 (“Lacework Acquisition Date”), we acquired Lacework Inc. (“Lacework”), a privately held data-driven cloud security company, for $152.3 million in cash. We acquired Lacework with a goal of offering its Cloud-Native Application Protection Platform solution separately as well as integrated with our existing portfolio, forming a comprehensive, AI-driven cloud security platform available from a single vendor, which will help customers identify, prioritize and remediate risks and threats in complex cloud-native infrastructure from code to cloud.

[0001262039-26-000007:notes:141]
This acquisition was accounted for as a business combination using the acquisition method of accounting. The total purchase price was allocated to Lacework’s identifiable tangible and intangible assets acquired and liabilities assumed based on their estimated fair values using management’s best estimates and assumptions to assign fair value as of the acquisition date. Of the total purchase price, $244.4 million was allocated to deferred tax assets, $61.3 million allocation to identifiable intangible assets, and $6.2 million cash, offset by net other assets and liabilities assumed of $53.3 million, which predominantly included deferred revenue and other current liabilities. The excess of the fair values of the net assets acquired over the net purchase consideration was recorded as a gain on bargain purchase of $106.3 million within other income (expense)—net on the consolidated statements of income. The gain on bargain purchase occurred primarily due to the recognition of the deferred tax assets. The deferred tax assets were comprised primarily of pre-acquisition federal net operating loss carryforwards with an indefinite carryforward period.

[0001262039-26-000007:notes:142]
Of the total identified intangible assets acquired $39.5 million was developed technology, $10.0 million was backlog, $7.5 million was customer relationships and $4.3 million was trade name.

[0001262039-26-000007:notes:143]
The operating results of the acquired company were included in our consolidated financial statements from the date of acquisition, which was August 1, 2024. For the period from August 2, 2024 through December 31, 2024, Lacework contributed $31.1 million of revenue and $45.8 million of a net loss. Acquisition-related costs related to this acquisition were not material and were recorded as general and administrative expenses.

[0001262039-26-000007:notes:144]
Pro Forma Financial Information

[0001262039-26-000007:notes:145]
The following unaudited pro forma financial information presents the combined results of operations of Fortinet, Inc., Lacework and Next DLP, as if Lacework and Next DLP had been acquired as of the beginning of business on January 1, 2023. The unaudited pro forma financial information is presented for informational purposes only and is not necessarily indicative of our consolidated results of operations of the combined business that would have been achieved if the acquisitions had taken place at the beginning of business on January 1, 2023, or of the results of our future operations of the combined business. The following unaudited pro forma financial information for all periods presented includes purchase accounting adjustments for amortization of acquired intangible assets, the gain on bargain purchase, and various related tax impacts (in millions):

[0001262039-26-000007:notes:146]
|  | Year Ended December 31, |
|  | 2024 |  | 2023 |  |  |
| Pro forma revenue | $ | 6,016.8 |  |  | $ | 5,404.3 |  |  |  |
| Pro forma net income | $ | 1,468.2 |  |  | $ | 1,017.5 |  |  |  |

[0001262039-26-000007:notes:147]
Additional Acquisition-Related Information

[0001262039-26-000007:notes:148]
The operating results of the acquired companies are included in our consolidated statements of income from the respective dates of acquisition. Acquisition-related costs related to each acquisition were not material. The operating results of the acquired companies were not material in the years of acquisition, except for Lacework as disclosed above. Pro forma information has not been presented, except for Lacework and Next DLP as disclosed above, as the impact of these acquisitions, individually and in the aggregate, in each year were not material to our consolidated financial statements.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001262039-26-000007:notes:149]
GOODWILL AND OTHER INTANGIBLE ASSETS—Net
Goodwill

[0001262039-26-000007:notes:150]
The following table presents the changes in the carrying amount of goodwill (in millions):

[0001262039-26-000007:notes:151]
|  | Amount |
| Balance—December 31, 2024 | $ | 235.4 |  |
| Additions due to business combinations | 21.9 |  |
| Foreign currency translation adjustments | 0.1 |  |
| Balance—December 31, 2025 | $ | 257.4 |  |

[0001262039-26-000007:notes:152]
There were no impairments to goodwill during 2025, 2024 and 2023 or any previous periods.

[0001262039-26-000007:notes:153]
Other Intangible Assets—Net

[0001262039-26-000007:notes:154]
The following tables present other intangible assets—net (in millions, except years):

[0001262039-26-000007:notes:155]
|  | December 31, 2025 |
|  | Weighted-Average Useful Life (in Years) |  | Gross |  | Accumulated Amortization |  | Net |
| Other intangible assets—net: |  |  |  |  |  |  |  |
| Finite-lived intangible assets: |  |  |  |  |  |  |  |
| Developed technologies | 4.3 |  | $ | 159.1 |  |  | $ | 96.0 |  |  | $ | 63.1 |  |
| Customer relationships | 5.3 |  | 66.9 |  |  | 42.4 |  |  | 24.5 |  |
| Trade names | 4.2 |  | 11.3 |  |  | 5.4 |  |  | 5.9 |  |
| Backlog | 2.5 |  | 13.5 |  |  | 9.7 |  |  | 3.8 |  |
| Total other intangible assets—net |  |  | $ | 250.8 |  |  | $ | 153.5 |  |  | $ | 97.3 |  |

[0001262039-26-000007:notes:156]
|  | December 31, 2024 |
|  | Weighted-Average Useful Life (in Years) |  | Gross |  | Accumulated Amortization |  | Net |
| Other intangible assets—net: |  |  |  |  |  |  |  |
| Finite-lived intangible assets: |  |  |  |  |  |  |  |
| Developed technologies | 4.4 |  | $ | 141.9 |  |  | $ | 73.7 |  |  | $ | 68.2 |  |
| Customer relationships | 5.5 |  | 53.9 |  |  | 23.0 |  |  | 30.9 |  |
| Trade names | 7.5 |  | 8.8 |  |  | 1.8 |  |  | 7.0 |  |
| Backlog | 2.5 |  | 13.5 |  |  | 4.6 |  |  | 8.9 |  |
| Total other intangible assets—net |  |  | $ | 218.1 |  |  | $ | 103.1 |  |  | $ | 115.0 |  |

[0001262039-26-000007:notes:157]
Amortization expense of finite-lived intangible assets was $50.7 million, $23.1 million and $18.9 million in 2025, 2024, and 2023, respectively.

[0001262039-26-000007:notes:158]
The following table summarizes estimated future amortization expense of finite-lived intangible assets—net (in millions):

[0001262039-26-000007:notes:159]
| Year Ending December 31, | Amount |
| 2026 | $ | 37.2 |  |
| 2027 | 27.5 |  |
| 2028 | 20.0 |  |
| 2029 | 9.3 |  |
| 2030 | 1.0 |  |
| Thereafter | 2.3 |  |
| Total | $ | 97.3 |  |


## us-gaap:EarningsPerShareTextBlock

[0001262039-26-000007:notes:160]
NET INCOME PER SHARE
Basic net income per share is computed by dividing net income by the weighted-average number of shares of common stock outstanding during the period. Diluted net income per share is computed by dividing net income by the weighted-average number of shares of common stock outstanding during the period, plus the dilutive effects of restricted stock units RSUs, stock options and PSUs. Dilutive shares of common stock are determined by applying the treasury stock method.

[0001262039-26-000007:notes:161]
A reconciliation of the numerator and denominator used in the calculation of basic and diluted net income per share is (in millions, except per share amounts):

[0001262039-26-000007:notes:162]
|  | Year Ended December 31, |
|  | 2025 |  | 2024 |  | 2023 |
| Numerator: |  |  |  |  |  |
| Net income | $ | 1,853.4 |  |  | $ | 1,745.2 |  |  | $ | 1,147.8 |  |
| Denominator: |  |  |  |  |  |
| Basic shares: |  |  |  |  |  |
| Weighted-average common stock outstanding-basic | 758.0 |  |  | 764.4 |  |  | 778.6 |  |
| Diluted shares: |  |  |  |  |  |
| Weighted-average common stock outstanding-basic | 758.0 |  |  | 764.4 |  |  | 778.6 |  |
| Effect of potentially dilutive securities: |  |  |  |  |  |
| RSUs | 2.3 |  |  | 2.4 |  |  | 3.3 |  |
| Stock options | 3.8 |  |  | 4.7 |  |  | 6.2 |  |
| PSUs | 0.5 |  |  | 0.4 |  |  | 0.1 |  |
| Weighted-average shares used to compute diluted net income per share | 764.6 |  |  | 771.9 |  |  | 788.2 |  |
| Net income per share: |  |  |  |  |  |
| Basic | $ | 2.45 |  |  | $ | 2.28 |  |  | $ | 1.47 |  |
| Diluted | $ | 2.42 |  |  | $ | 2.26 |  |  | $ | 1.46 |  |

[0001262039-26-000007:notes:163]
The following weighted-average shares of common stock were excluded from the computation of diluted net income per share for the periods presented, as their effect would have been antidilutive (in millions):

[0001262039-26-000007:notes:164]
|  | Year Ended December 31, |
|  | 2025 |  | 2024 |  | 2023 |
| RSUs | 1.9 |  |  | 0.2 |  |  | 0.7 |  |
| Stock options | 0.7 |  |  | 2.5 |  |  | 2.8 |  |
| PSUs | — |  |  | 0.1 |  |  | 0.1 |  |
| Total | 2.6 |  |  | 2.8 |  |  | 3.6 |  |


## us-gaap:LesseeOperatingLeasesTextBlock

[0001262039-26-000007:notes:165]
LEASES
We have operating leases for offices, research and development facilities and data centers. Our leases have remaining terms that range from less than one year to approximately four years, some of which include one or more options to renew, with renewal terms of up to six years. Unless and until we are reasonably certain we will exercise these renewal options, we do not include renewal options in our lease terms for calculating our lease liability, as the renewal options allow us to maintain operational flexibility. Our finance leases were not material to our consolidated financial statements.

[0001262039-26-000007:notes:166]
The components of lease expense were (in millions):

[0001262039-26-000007:notes:167]
|  | Year Ended December 31, |
|  | 2025 |  | 2024 |  | 2023 |
| Operating lease expense | $ | 51.7 |  |  | $ | 44.5 |  |  | $ | 43.0 |  |
| Variable lease expense (1) | 7.0 |  |  | 7.4 |  |  | 5.8 |  |
| Short-term lease expense | 13.7 |  |  | 10.2 |  |  | 9.3 |  |
| Total lease expense | $ | 72.4 |  |  | $ | 62.1 |  |  | $ | 58.1 |  |
| (1) Variable lease expense for the years ended December 31, 2025, 2024 and 2023 predominantly included common area maintenance charges, real estate taxes, certain parking expense, utilities based on actual usage and insurance costs. |

[0001262039-26-000007:notes:168]
Supplemental balance sheet information related to our operating leases was (in millions, except lease term and discount rate):

[0001262039-26-000007:notes:169]
|  | Classification |  | December 31,2025 |  | December 31,2024 |
| Operating lease ROU assets – non-current | Other assets |  | $ | 64.4 |  |  | $ | 72.2 |  |
| Operating lease liabilities – current | Accrued liabilities |  | $ | 36.1 |  |  | $ | 32.7 |  |
| Operating lease liabilities – non-current | Other liabilities |  | 29.4 |  |  | 46.4 |  |
| Total operating lease liabilities |  |  | $ | 65.5 |  |  | $ | 79.1 |  |
| Weighted average remaining lease term in years – operating leases |  |  | 2.1 |  | 3.0 |
| Weighted average discount rate – operating leases |  |  | 4.1 | % |  | 4.2 | % |

[0001262039-26-000007:notes:170]
Supplemental cash flow information related to leases was (in millions):

[0001262039-26-000007:notes:171]
|  | Year Ended December 31, |
|  | 2025 |  | 2024 |  | 2023 |
| Cash paid for amounts included in the measurement of lease liabilities |  |  |  |  |  |
| Operating cash flows used for operating leases | $ | 51.3 |  |  | $ | 38.6 |  |  | $ | 40.0 |  |

[0001262039-26-000007:notes:172]
Maturities of operating lease liabilities as of December 31, 2025 were (in millions):

[0001262039-26-000007:notes:173]
| Year Ending December 31, | Amount |
| 2026 | $ | 37.6 |  |
| 2027 | 21.3 |  |
| 2028 | 7.9 |  |
| 2029 | 1.2 |  |
| 2030 | 0.1 |  |
| Thereafter | — |  |
| Total lease payments | $ | 68.1 |  |
| Less imputed interest | (2.6) |  |
| Total | $ | 65.5 |  |

[0001262039-26-000007:notes:174]
As of December 31, 2025, our operating leases that had been signed but had not yet commenced were not material.


## us-gaap:DebtDisclosureTextBlock

[0001262039-26-000007:notes:175]
DEBT
2026 and 2031 Senior Notes

[0001262039-26-000007:notes:176]
On March 5, 2021, we issued $1.0 billion aggregate principal amount of senior notes (collectively, the “Senior Notes”), consisting of $500.0 million aggregate principal amount of 1.0% notes due March 15, 2026 (the “2026 Senior Notes”) and $500.0 million aggregate principal amount of 2.2% notes due March 15, 2031 (the “2031 Senior Notes”), in an underwritten registered public offering. The Senior Notes are senior unsecured obligations and rank equally with each other in right of payment and with our other outstanding obligations. We may redeem the Senior Notes at any time in whole or in part for cash, at specified redemption prices that include accrued and unpaid interest, if any, and a make-whole premium. However, no make-whole premium will be paid for redemptions of the 2026 Senior Notes on or after February 15, 2026, or the 2031 Senior Notes on or after December 15, 2030. Interest on the Senior Notes is payable on March 15 and September 15 of each year, beginning on September 15, 2021. The 2026 Senior Notes were recorded as current portion of long-term debt and the 2031 Senior Notes were recorded as long-term debt as of December 31, 2025 and both of the Senior Notes were recorded as long-term debt as of December 31, 2024, net of discount and issuance costs, which are amortized to interest expense over the respective contractual terms of these notes using the effective interest method.

[0001262039-26-000007:notes:177]
The total outstanding debt is summarized below (in millions, except percentages):

[0001262039-26-000007:notes:178]
|  | Maturity |  | Coupon Rate |  | Effective Interest Rate |  | December 31,2025 |  | December 31,2024 |
| Debt |  |  |  |  |  |  |  |  |  |
| 2026 Senior Notes | March 2026 |  | 1.0 | % |  | 1.3 | % |  | $ | 500.0 |  |  | $ | 500.0 |  |
| 2031 Senior Notes | March 2031 |  | 2.2 | % |  | 2.3 | % |  | 500.0 |  |  | 500.0 |  |
| Total debt |  |  |  |  |  |  | 1,000.0 |  |  | 1,000.0 |  |
| Less: Unamortized discount and debt issuance costs |  |  |  |  |  |  | 3.7 |  |  | 5.7 |  |
| Less: Current portion of long-term debt |  |  |  |  |  |  | $ | 499.7 |  |  | $ | — |  |
| Total long-term debt |  |  |  |  |  |  | $ | 496.6 |  |  | $ | 994.3 |  |

[0001262039-26-000007:notes:179]
As of December 31, 2025 and 2024, we accrued interest payable of $4.7 million, and there are no financial covenants with which we must comply. In 2025, 2024 and 2023 we recorded $18.0 million, $18.0 million and $17.9 million of total interest expense in relation to these Senior Notes and repaid $16.0 million of interest in cash, respectively. No interest costs were capitalized in 2025, 2024 and 2023, as the costs that qualified for capitalization were not material.

[0001262039-26-000007:notes:180]
The total estimated fair value of the outstanding Senior Notes was approximately $950.1 million, including accrued and unpaid interest, as of December 31, 2025. The fair value was determined based on observable market prices of identical instruments in less active markets. The estimated fair values are based on Level 2 inputs.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001262039-26-000007:notes:181]
COMMITMENTS AND CONTINGENCIES
The following table summarizes our inventory purchase commitments as of December 31, 2025 (in millions):

[0001262039-26-000007:notes:182]
|  | Total |  | 2026 |  | Thereafter |
| Inventory purchase commitments | $ | 810.6 |  |  | $ | 720.9 |  |  | $ | 89.7 |  |

[0001262039-26-000007:notes:183]
Inventory Purchase Commitments—We purchase components of our inventory from certain suppliers and use several independent contract manufacturers to provide manufacturing services for our products. During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, we enter into agreements with contract manufacturers and suppliers that allow them to procure inventory based upon criteria as defined by us or establish the parameters defining our requirements. A significant portion of our reported purchase commitments arising from these agreements consists of firm, non-cancelable and unconditional commitments. Certain of these inventory purchase commitments with contract manufacturers and suppliers relate to arrangements to secure supply and pricing for certain product components for multi-year periods. In certain instances, these agreements allow us the option to reschedule and adjust our requirements based on our business needs prior to firm orders being placed.

[0001262039-26-000007:notes:184]
As of December 31, 2025, we had $810.6 million of non-cancelable inventory purchase commitments with our independent contract manufacturers. We recorded a liability for these purchase commitments for quantities in excess of our future estimated demand forecasts, consistent with the valuation of our excess and obsolete inventory. As of December 31, 2025 and December 31, 2024, the liability for these inventory purchase commitments was $26.7 million and $54.0 million, respectively, and was recorded in accrued liabilities on our consolidated balance sheets. The expense related to such accrued liability for inventory purchase commitments were not material for the year ended December 31, 2025 and 2024, respectively, and $85.9 million for the year ended December 31, 2023, and was recorded in cost of product revenue on the consolidated statements of income.

[0001262039-26-000007:notes:185]
Other Contractual Commitments and Open Purchase Orders—In addition to commitments with contract manufacturers, we have open purchase orders and contractual obligations in the ordinary course of business for which we have not received goods or services. A significant portion of our reported purchase commitments consist of non-cancelable commitments. In certain instances, contractual commitments allow us the option to cancel, reschedule and adjust our requirements based on our business needs prior to firm orders being placed. As of December 31, 2025, we had $118.3 million in other contractual commitments having a remaining term in excess of one year that are non-cancelable.

[0001262039-26-000007:notes:186]
Litigation—We are subject to legal proceedings arising in the ordinary course of business. We record accruals for litigation contingencies when a loss is probable and reasonably estimable, based on management’s assessment of the expected outcome and currently available information. As of December 31, 2025 and 2024, litigation loss contingency accruals associated with outstanding matters were not material.

[0001262039-26-000007:notes:187]
On September 22, 2025, a securities class action was filed against us, our chief executive officer, our chief technology officer, our current chief financial officer and our former chief financial officer in the United States District Court, Northern District of California, captioned Oklahoma Firefighters Pension and Retirement System v. Fortinet, Inc., et al., Case No. 5:25-cv-08037. On October 16, 2025, a securities class action was filed against us, our chief executive Officer, our current chief financial officer and our former chief financial officer in the same court, captioned State of Rhode Island Office of the General Treasurer v. Fortinet, Inc., et al., Case No. 3:25-cv-08888. These suits are brought on behalf of an alleged class of stockholders who purchased or acquired shares of our common stock between November 8, 2024 through August 6, 2025. The complaints allege that defendants made false or misleading statements about our business, operations and prospects, including regarding the 2026 firewall refresh cycle, and purport to assert claims under Sections 10(b) and 20(a) of the Exchange Act. These suits seek damages, attorneys fees and costs, and other relief that the court may deem appropriate. The time to respond to the complaints has not yet passed. We believe these cases are without merit and defendants intend to defend the suits vigorously. Based on the preliminary nature of the proceedings in these cases, the outcome of these matters remains uncertain and we cannot estimate the potential impact, if any, on its business or financial statements at this time. Accordingly, no loss accrual was recorded as of December 31, 2025 related to these litigations.

[0001262039-26-000007:notes:188]
On October 8, 2025, Plaintiff Jack Pittrof filed a stockholder derivative complaint against us as a nominal defendant and certain of our current and former directors and officers in the United States District Court for the Northern District of California, captioned Pittrof v. Xie, et al., Case No. 3:2025-cv-08592 (“Pittrof”). The complaint alleges claims based on events similar to those in the securities class action and asserts causes of action against the individual defendants for breach of fiduciary duty, aiding and abetting breach of fiduciary duty, unjust enrichment, waste of corporate assets, and for violations of Section 10(b) of the Exchange Act. The time to respond to the complaint has not yet passed. On November 5, 2025, Plaintiff Michael J. Marrinan filed a stockholder derivative complaint against us as a nominal defendant and certain of our current and former directors and officers in the United States District Court for the Northern District of California, captioned Marrinan v. Xie, et al., Case No. 3:25-cv-09546 (“Marrinan”). The complaint alleges claims based on events similar to those in the securities class action and asserts causes of action against the individual defendants for breach of fiduciary duty, unjust enrichment, insider trading, gross mismanagement, waste of corporate assets, violations of California Corporations Code §§ 24400, 25500, et. seq., and violations of Section 10(b) of the Exchange Act. The time to respond to the complaint has not yet passed. On November 6, 2025, Plaintiff Bryan Foster filed a stockholder derivative complaint against us as a nominal defendant and certain of our current and former directors and officers in the United States District Court for the Northern District of California, captioned Foster v. Xie, et al., Case No. 3:25-cv-09611 (“Foster”). The complaint alleges claims based on events similar to those in the securities class action and asserts causes of action against the individual defendants for breach of fiduciary duty, unjust enrichment, abuse of control, gross mismanagement, waste of corporate assets, for violations of Section 10(b), 14(a), and 20(a) of the Exchange Act, and for contribution under Section 21D of the Exchange Act. The time to respond to the complaint has not yet passed. On December 2, 2025, Plaintiff LR Trust filed a stockholder derivative complaint against us as a nominal defendant and certain of our current and former directors and officers in the United States District Court for the Northern District of California, captioned LR Trust v. Xie, et al., Case No. 3:25-cv-10350 (“LR Trust,” together with Pittrof, Marrinan, and Foster, the “Derivative Actions”). The complaint alleges claims based on events similar to those in the securities class action and asserts causes of action against the individual defendants for breach of fiduciary duty, unjust enrichment, insider trading, aiding and abetting, violations of Sections 10(b) and 14(a) of the Exchange Act, and for contribution under

[0001262039-26-000007:notes:189]
Section 21D of the Exchange Act. The time to respond to the complaint has not yet passed. On behalf of the Company, the Derivative Actions seek damages, disgorgement, remedial actions, restitution, and attorneys’ fees and costs.

[0001262039-26-000007:notes:190]
On March 21, 2019, we were sued by Alorica Inc. (“Alorica”) in Santa Clara County Superior Court in California. Alorica alleged breach of warranty and misrepresentation claims, which we denied. After trial, a jury returned a verdict fully in favor of us and against Alorica on October 4, 2024. Alorica has filed a notice of appeal. We believe that the ultimate outcome of this matter will not materially impact our financial position, results of operations or cash flows. However, any further legal proceedings, including Alorica’s appeal, would be subject to inherent uncertainties, and a future unfavorable ruling could occur. No loss accrual had been recorded as of December 31, 2025 related to this litigation.

[0001262039-26-000007:notes:191]
Indemnification and Other Matters—We enter into indemnification provisions in the ordinary course of business with other companies such as partners, customers, and vendors, where we agree to indemnify, hold harmless, and reimburse the indemnified party for certain losses suffered or incurred by the indemnified party as a result of our activities, including defending against third-party claims asserting various allegations such as product defects, breach of representations or covenants, and infringement of certain IP rights, which may include patents, copyrights, trademarks or trade secrets, and to pay judgments entered on such claims. In some contracts, our exposure under these indemnification provisions is limited by the terms of the contracts to certain defined limits, such as the total amount paid by our customer under the agreement. However, certain agreements include covenants, penalties and indemnification provisions including and beyond indemnification for third-party claims of IP infringement that could potentially expose us to losses in excess of the amount received under the agreement, and in some instances to potential liability that is not contractually limited. Although from time to time there are indemnification claims asserted against us and currently there are pending indemnification claims, to date there have been no material awards under such indemnification provisions.
Similar to other security companies and companies in other industries, we have experienced and may experience in the future, cybersecurity threats, malicious activity directed against our information technology infrastructure or unauthorized attempts to gain access to our and our customers’ sensitive information and systems. We currently are unaware of any claims or proceedings related to these types of matters that we believe are likely to have a material adverse effect on our financial position.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001262039-26-000007:notes:192]
EQUITY PLANS AND SHARE REPURCHASE PROGRAM
Stock-Based Compensation Plans

[0001262039-26-000007:notes:193]
We have one primary stock incentive plan, the 2009 EIP, under which we have granted RSUs, stock options and PSUs.

[0001262039-26-000007:notes:194]
Our board of directors approved the 2009 EIP in 2009 and amended the plan in 2019. The maximum aggregate number of shares that may be issued under the 2009 EIP is 239,367,655 shares; provided, however, that only 67,500,000 shares may be issued or transferred pursuant to new awards granted on or following the effective date of the 2009 EIP. We may grant awards to employees, directors and other service providers. In the case of an incentive stock option granted to an employee who, at the time of the grant, owns stock representing more than 10% of the voting power of all classes of stock, the exercise price shall be no less than 110% of the fair market value per share on the date of grant and expire no more than five years from the date of grant, and options granted to any other employee, the per share exercise price shall be no less than 100% of the closing stock price on the date of grant. In the case of a non-statutory stock option and options granted to other service providers, the per share exercise price shall be no less than 100% of the fair market value per share on the date of grant. Options granted to individuals owning less than 10% of the total combined voting power of all classes of stock generally have a contractual term of no more than ten years and options generally vest over four years.

[0001262039-26-000007:notes:195]
As of December 31, 2025, there were a total of 48.1 million shares of common stock available for grant under the 2009 EIP.

[0001262039-26-000007:notes:196]
Restricted Stock Units

[0001262039-26-000007:notes:197]
The following table summarizes the activity and related information for RSUs for the periods presented below (in millions, except per share amounts):

[0001262039-26-000007:notes:198]
|  | Restricted Stock Units Outstanding |
|  | Number of Shares |  | Weighted-Average Grant Date Fair Value per Share |
| Balance—December 31, 2022 | 10.5 |  |  | $ | 40.94 |  |
| Granted | 4.8 |  |  | 60.14 |  |
| Forfeited | (0.8) |  |  | 49.85 |  |
| Vested | (5.4) |  |  | 35.47 |  |
| Balance—December 31, 2023 | 9.1 |  |  | 53.61 |  |
| Granted | 4.7 |  |  | 71.25 |  |
| Forfeited | (1.0) |  |  | 61.98 |  |
| Vested | (4.4) |  |  | 49.50 |  |
| Balance—December 31, 2024 | 8.4 |  |  | 64.70 |  |
| Granted | 3.8 |  |  | 97.88 |  |
| Forfeited | (0.8) |  |  | 76.00 |  |
| Vested | (3.8) |  |  | 62.01 |  |
| Balance—December 31, 2025 | 7.6 |  |  | $ | 81.51 |  |

[0001262039-26-000007:notes:199]
Stock compensation expense is recognized on a straight-line basis over the vesting period of each RSU. As of December 31, 2025, total compensation expense related to unvested RSUs granted to employees and non-employees under the 2009 EIP, but not yet recognized, was $537.2 million, with a weighted-average remaining vesting period of 2.7 years.

[0001262039-26-000007:notes:200]
Market/Performance-Based PSUs

[0001262039-26-000007:notes:201]
We grant market/performance-based PSUs under the 2009 EIP to certain of our executives. Based on the achievement of the market/performance-based vesting conditions during the performance period, the final settlement of the PSUs will range between 0% and 200% of the target shares underlying the PSUs based on the percentile ranking of our total stockholder return over one-, two-, three- and four-year periods among companies included in the S&P 500 Index. 20%, 20%, 20% and 40% of the PSUs vest over one-, two-, three- and four-year service periods, respectively.

[0001262039-26-000007:notes:202]
The following table summarizes the weighted-average assumptions relating to our PSUs:

[0001262039-26-000007:notes:203]
|  | Year Ended December 31, |
|  | 2025 |  | 2024 |  | 2023 |
| Expected term in years | 2.7 |  | 2.7 |  | 2.7 |
| Volatility | 41.7 | % |  | 45.4 | % |  | 47.5 | % |
| Risk-free interest rate | 4.1 | % |  | 4.5 | % |  | 4.6 | % |
| Dividend rate | — | % |  | — | % |  | — | % |

[0001262039-26-000007:notes:204]
The following table summarizes the activity and related information for PSUs for the periods presented below (in millions, except per share amounts):

[0001262039-26-000007:notes:205]
|  | Performance Stock Units Outstanding |  |  |
|  | Number of Shares |  | Weighted-Average Grant Date Fair Value per Share |  |  |
| Balance—December 31, 2022 | — |  |  | $ | — |  |  |  |
| Granted | 0.3 |  |  | 90.96 |  |  |  |
| Forfeited | — |  |  | — |  |  |  |
| Vested | — |  |  | — |  |  |  |
| Balance—December 31, 2023 | 0.3 |  |  | 90.96 |  |  |  |
| Granted | 0.3 |  |  | 97.40 |  |  |  |
| Forfeited | (0.1) |  |  | 93.84 |  |  |  |
| Vested | (0.1) |  |  | 88.10 |  |  |  |
| Balance—December 31, 2024 | 0.4 |  |  | 94.93 |  |  |  |
| Granted | 0.2 |  |  | 163.23 |  |  |  |
| Forfeited | (0.1) |  |  | 116.82 |  |  |  |
| Vested | (0.1) |  |  | 91.19 |  |  |  |
| Balance—December 31, 2025 | 0.4 |  |  | $ | 117.17 |  |  |  |

[0001262039-26-000007:notes:206]
As of December 31, 2025, total compensation expense related to unvested PSUs that were granted to certain of our executives, but not yet recognized, was $21.2 million. This expense is expected to be amortized on a graded vesting method over a weighted-average vesting period of 2.1 years.

[0001262039-26-000007:notes:207]
RSUs and PSUs settle into shares of common stock upon vesting. Upon the vesting of the RSUs and PSUs, we net-settle the RSUs and PSUs and withhold a portion of the shares to satisfy employee withholding tax requirements. The payment of the withheld taxes to the tax authorities is reflected as a financing activity within the consolidated statements of cash flows.

[0001262039-26-000007:notes:208]
The following summarizes the number and value of the shares withheld for employee taxes (in millions):

[0001262039-26-000007:notes:209]
|  | Year Ended December 31, |
|  | 2025 |  | 2024 |  | 2023 |
| Shares withheld for taxes | 1.3 |  |  | 1.5 |  |  | 1.8 |  |
| Amount withheld for taxes | $ | 126.5 |  |  | $ | 101.0 |  |  | $ | 112.5 |  |

[0001262039-26-000007:notes:210]
Stock Options

[0001262039-26-000007:notes:211]
In determining the fair value of our stock options, we use the Black-Scholes model, which employs the following assumptions.

[0001262039-26-000007:notes:212]
Expected Term—The expected term represents the period that our stock-based awards are expected to be outstanding. We believe that we have sufficient historical experience for determining the expected term of the stock option award, and therefore, we calculated our expected term based on historical experience instead of using the simplified method.

[0001262039-26-000007:notes:213]
Expected Volatility—The expected volatility of our common stock is based on our weighted-average implied and historical volatility.

[0001262039-26-000007:notes:214]
Fair Value of Common Stock—The fair value of our common stock is the closing sales price of the common stock effective on the date of grant.

[0001262039-26-000007:notes:215]
Risk-Free Interest Rate—We base the risk-free interest rate on the implied yield available on U.S. Treasury zero-coupon issues with an equivalent remaining term.

[0001262039-26-000007:notes:216]
Expected Dividend—The expected dividend weighted-average assumption is zero.

[0001262039-26-000007:notes:217]
The following table summarizes the weighted-average assumptions relating to our stock options:

[0001262039-26-000007:notes:218]
|  | Year Ended December 31, |
|  | 2025 |  | 2024 |  | 2023 |
| Expected term in years | 4.5 |  | 4.5 |  | 4.4 |
| Volatility | 41.8 | % |  | 42.6 | % |  | 42.0 | % |
| Risk-free interest rate | 4.1 | % |  | 4.3 | % |  | 4.2 | % |
| Dividend rate | — | % |  | — | % |  | — | % |

[0001262039-26-000007:notes:219]
The following table summarizes the stock option activity and related information for the periods presented below (in millions, except exercise prices and contractual life):

[0001262039-26-000007:notes:220]
|  | Options Outstanding |
|  | Numberof Shares |  | Weighted-AverageExercisePrice |  | Weighted-AverageRemainingContractualLife (Years) |  | AggregateIntrinsicValue |
| Balance—December 31, 2022 | 13.2 |  |  | $ | 24.37 |  |  | 3.5 |  | 344.8 |  |
| Granted | 1.3 |  |  | 60.16 |  |  |  |  |  |
| Forfeited | (0.2) |  |  | 49.13 |  |  |  |  |  |
| Exercised | (3.1) |  |  | 14.11 |  |  |  |  |  |
| Balance—December 31, 2023 | 11.2 |  |  | 31.14 |  |  | 3.3 |  | 315.8 |  |
| Granted | 0.8 |  |  | 68.21 |  |  |  |  |  |
| Forfeited | (0.2) |  |  | 54.74 |  |  |  |  |  |
| Exercised | (3.1) |  |  | 20.30 |  |  |  |  |  |
| Balance—December 31, 2024 | 8.7 |  |  | 37.81 |  |  | 3.1 |  | 493.8 |  |
| Granted | 0.9 |  |  | 100.08 |  |  |  |  |  |
| Forfeited | (0.1) |  |  | 74.07 |  |  |  |  |  |
| Exercised | (2.1) |  |  | 21.59 |  |  |  |  |  |
| Balance—December 31, 2025 | 7.4 |  |  | $ | 49.39 |  |  |  |  |  |
| Options vested and expected to vest—December 31, 2025 | 7.4 |  |  | $ | 49.39 |  |  | 3.0 |  | $ | 241.7 |  |
| Options exercisable—December 31, 2025 | 5.7 |  |  | $ | 39.53 |  |  | 2.3 |  | $ | 228.6 |  |

[0001262039-26-000007:notes:221]
The aggregate intrinsic value represents the difference between the exercise price of stock options and the quoted market price of our common stock at the date of the balance sheet for all in-the-money stock options. Stock compensation expense is recognized on a straight-line basis over the vesting period of each stock option. As of December 31, 2025, total compensation expense related to unvested stock options granted to employees but not yet recognized was $50.6 million, with a weighted-average remaining vesting period of 2.6 years.

[0001262039-26-000007:notes:222]
Additional information related to our stock options is summarized below (in millions, except per share amounts):

[0001262039-26-000007:notes:223]
|  | Year Ended December 31, |
|  | 2025 |  | 2024 |  | 2023 |
| Weighted-average fair value per share granted | $ | 40.21 |  |  | $ | 27.87 |  |  | $ | 24.20 |  |
| Intrinsic value of options exercised | $ | 166.3 |  |  | $ | 166.9 |  |  | $ | 140.7 |  |
| Fair value of options vested | $ | 26.8 |  |  | $ | 31.3 |  |  | $ | 30.1 |  |

[0001262039-26-000007:notes:224]
The following table summarizes information about outstanding and exercisable stock options as of December 31, 2025, (in millions, except exercise prices and contractual life):

[0001262039-26-000007:notes:225]
|  |  | Options Outstanding |  | Options Exercisable |
| Range of Exercise Prices |  | NumberOutstanding |  | Weighted-AverageRemainingContractualLife (Years) |  | Weighted-AverageExercisePrice |  | NumberExercisable |  | Weighted-AverageExercisePrice |
| $16.02-$29.12 |  | 2.1 |  |  | 0.9 |  | $ | 21.26 |  |  | 2.1 |  |  | $ | 21.26 |  |
| $34.39-$60.21 |  | 2.6 |  |  | 3.0 |  | 45.12 |  |  | 2.3 |  |  | 42.97 |  |
| $61.13-$79.61 |  | 1.8 |  |  | 4.0 |  | 64.61 |  |  | 1.3 |  |  | 63.21 |  |
| $79.73-$110.02 |  | 0.9 |  |  | 6.3 |  | 101.44 |  |  | — |  |  | 100.88 |  |
|  |  | 7.4 |  |  |  |  |  |  | 5.7 |  |  |  |

[0001262039-26-000007:notes:226]
Shares Reserved for Future Issuances

[0001262039-26-000007:notes:227]
The following table presents the common stock reserved for future issuance (in millions):

[0001262039-26-000007:notes:228]
|  | December 31,2025 |
| Reserved for future equity award grants | 48.1 |  |
| Outstanding stock options, RSUs and PSUs | 15.4 |  |
| Total common stock reserved for future issuances | 63.5 |  |

[0001262039-26-000007:notes:229]
Stock-Based Compensation Expense

[0001262039-26-000007:notes:230]
Stock-based compensation expense, including stock-based compensation expense related to awards classified as liabilities, is included in costs and expenses (in millions):

[0001262039-26-000007:notes:231]
|  | Year Ended December 31, |
|  | 2025 |  | 2024 |  | 2023 |
| Cost of product revenue | $ | 2.2 |  |  | $ | 1.9 |  |  | $ | 1.8 |  |
| Cost of service revenue | 27.1 |  |  | 25.4 |  |  | 23.3 |  |
| Research and development | 98.7 |  |  | 85.9 |  |  | 76.8 |  |
| Sales and marketing | 117.2 |  |  | 105.3 |  |  | 111.8 |  |
| General and administrative | 36.9 |  |  | 41.7 |  |  | 37.9 |  |
| Total stock-based compensation expense | $ | 282.1 |  |  | $ | 260.2 |  |  | $ | 251.6 |  |

[0001262039-26-000007:notes:232]
The following table summarizes stock-based compensation expense, including stock-based compensation expense related to awards classified as liabilities, by award type (in millions):

[0001262039-26-000007:notes:233]
|  | Year Ended December 31, |
|  | 2025 |  | 2024 |  | 2023 |
| RSUs | $ | 239.8 |  |  | $ | 217.2 |  |  | $ | 211.8 |  |
| Stock options | 26.9 |  |  | 28.2 |  |  | 28.8 |  |
| PSUs | 15.4 |  |  | 14.8 |  |  | 11.0 |  |
| Total stock-based compensation expense | $ | 282.1 |  |  | $ | 260.2 |  |  | $ | 251.6 |  |

[0001262039-26-000007:notes:234]
Total income tax benefit associated with stock-based compensation that is recognized in the consolidated statements of income is (in millions):

[0001262039-26-000007:notes:235]
|  | Year Ended December 31, |
|  | 2025 |  | 2024 |  | 2023 |
| Income tax benefit associated with stock-based compensation | $ | 61.7 |  |  | $ | 57.3 |  |  | $ | 55.5 |  |

[0001262039-26-000007:notes:236]
Share Repurchase Program

[0001262039-26-000007:notes:237]
In January 2016, our board of directors approved the Repurchase Program, which authorized the repurchase of up to $200.0 million of our outstanding common stock through December 31, 2017. From 2016 through 2024, our board of directors approved increases to our Repurchase Program by various amounts and extended the term of the Repurchase Program to February 28, 2026. In August 2025, our board of directors approved a $1.0 billion increase in the authorized stock repurchase amount under the Repurchase Program and extended the term of the Repurchase Program to February 28, 2027, bringing the aggregate amount authorized for repurchases to $9.25 billion of our outstanding common stock through February 28, 2027. Under the Repurchase Program, we may repurchase common stock from time to time in privately negotiated transactions or in open market transactions. The Repurchase Program does not require us to purchase a minimum number of shares, and may be suspended, modified or discontinued at any time without prior notice. Refer to Note 16, Subsequent Events, for information regarding the approved $1.0 billion increase in the authorized stock repurchase amount under the Repurchase Program in January 2026. 
In 2025, we repurchased 28.7 million shares of common stock under the Repurchase Program in open market transactions for an aggregate purchase price of $2.29 billion, which excludes an $18.3 million accrual related to the 1% excise tax imposed by the Inflation Reduction Act of 2022. As of December 31, 2025, $738.6 million remained available for future share repurchases under the Repurchase Program.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001262039-26-000007:notes:238]
INCOME TAXES 
Income before income taxes and loss from equity method investments consisted of (in millions):

[0001262039-26-000007:notes:239]
|  | Year Ended December 31, |
|  | 2025 |  | 2024 |  | 2023 |
| Domestic | $ | 2,106.8 |  |  | $ | 1,929.2 |  |  | $ | 1,195.0 |  |
| Foreign | 175.4 |  |  | 129.3 |  |  | 138.7 |  |
| Total income before income taxes and loss from equity method investments | $ | 2,282.2 |  |  | $ | 2,058.5 |  |  | $ | 1,333.7 |  |

[0001262039-26-000007:notes:240]
The provision for (benefit from) income taxes consisted of (in millions):

[0001262039-26-000007:notes:241]
|  | Year Ended December 31, |
|  | 2025 |  | 2024 |  | 2023 |
| Current: |  |  |  |  |  |
| Federal | $ | 294.6 |  |  | $ | 444.2 |  |  | $ | 398.5 |  |
| State | 21.9 |  |  | 25.8 |  |  | 27.7 |  |
| Foreign | 54.3 |  |  | 36.8 |  |  | 24.3 |  |
| Total current | $ | 370.8 |  |  | $ | 506.8 |  |  | $ | 450.5 |  |
| Deferred: |  |  |  |  |  |
| Federal | $ | 56.8 |  |  | $ | (210.7) |  |  | $ | (281.1) |  |
| State | 11.9 |  |  | (12.4) |  |  | (18.9) |  |
| Foreign | (0.4) |  |  | 0.2 |  |  | (6.7) |  |
| Total deferred | 68.3 |  |  | (222.9) |  |  | (306.7) |  |
| Provision for income taxes | $ | 439.1 |  |  | $ | 283.9 |  |  | $ | 143.8 |  |

[0001262039-26-000007:notes:242]
The foreign tax provision included the tax impacts from U.S. GAAP to local tax return book to tax differences that create a permanent addback including but not limited to stock compensation, meals and entertainment, and settlement of prior year tax audits with foreign jurisdiction adjustments.

[0001262039-26-000007:notes:243]
We adopted ASU 2023-09 “Income Taxes (Topic 740): Improvements to Income Tax Disclosures” on a prospective basis beginning with the year ended December 31, 2025. The following table reconciles the U.S. federal statutory tax amount and rate to our actual global effective amount and rate for the year ended December 31, 2025 (in millions, except percentages):

[0001262039-26-000007:notes:244]
|  | Year Ended December 31, 2025 |
|  | Amount |  | % |
| U.S. Federal Statutory Tax Rate | $ | 479.3 |  |  | 21.0 | % |
| State and Local Income Taxes, Net of Federal Income Tax Effect (1) | 26.4 |  |  | 1.2 | % |
| Foreign Tax Effects (2) | 82.0 |  |  | 3.6 | % |
| Effect of Changes in Tax Laws or Rates Enacted in the Current Period | — |  |  | — | % |
| Effect of Cross-Border Tax Laws |  |  |  |
| Foreign-Derived Intangible Income deduction | (84.3) |  |  | (3.7) | % |
| Branch income | 37.8 |  |  | 1.7 | % |
| Other | 1.5 |  |  | 0.1 | % |
| Tax Credits |  |  |  |
| Foreign tax credit | (101.8) |  |  | (4.5) | % |
| Other | (15.4) |  |  | (0.7) | % |
| Changes in Valuation Allowances | — |  |  | — | % |
| Nontaxable or Nondeductible Items |  |  |  |
| Stock-based compensation expense | 32.5 |  |  | 1.4 | % |
| Excess tax benefit from stock-based compensation | (60.9) |  |  | (2.7) | % |
| Other | (4.4) |  |  | (0.2) | % |
| Changes in Unrecognized Tax Benefits | 16.5 |  |  | 0.7 | % |
| Other Adjustments |  |  |  |
| Acquisition-related effects | 31.2 |  |  | 1.4 | % |
| Other | (1.3) |  |  | (0.1) | % |
| Effective Tax Rate | $ | 439.1 |  |  | 19.2 | % |
| (1) In 2025, State and local income taxes in California, Illinois, New Jersey, New York and Pennsylvania made up the majority (greater than 50%) of the tax effect in this category. |
| (2) Presented on an aggregated basis as no individual foreign jurisdiction and no individual reconciling item by nature within any jurisdiction met the disaggregation threshold. |

[0001262039-26-000007:notes:245]
The following represents the required disclosures prior to our adoption of ASU 2023-09 and reconciles the U.S. federal statutory income tax rate to the actual global effective tax rate for the years ended December 31, 2024 and 2023 (in millions):

[0001262039-26-000007:notes:246]
|  |  |  | Year Ended December 31, |
|  |  |  | 2024 |  | 2023 |
| Tax at federal statutory tax rate |  |  | $ | 432.3 |  |  | $ | 280.1 |  |
| Foreign income taxed at different rates |  |  | 29.8 |  |  | 27.0 |  |
| Foreign withholding taxes |  |  | 58.0 |  |  | 35.1 |  |
| Stock-based compensation expense |  |  | (23.6) |  |  | (54.3) |  |
| Foreign tax credit |  |  | (79.5) |  |  | (72.6) |  |
| State taxes—net of federal benefit |  |  | 1.1 |  |  | 5.0 |  |
| Research and development credit |  |  | (13.9) |  |  | (14.0) |  |
| Valuation allowance |  |  | 7.5 |  |  | (67.7) |  |
| Impact of the 2017 Tax Cuts and Jobs Act: |  |  |  |  |  |
| Tax effect of a law change |  |  | — |  |  | (20.8) |  |
| Foreign-Derived Intangible Income |  |  | (111.5) |  |  | (89.5) |  |
| Adjustment to prior year’s FDII |  |  | — |  |  | 92.8 |  |
| Other |  |  | (16.3) |  |  | 22.7 |  |
| Total provision for income taxes |  |  | $ | 283.9 |  |  | $ | 143.8 |  |

[0001262039-26-000007:notes:247]
On January 4, 2022, the U.S. Treasury published another tranche of final regulations regarding the foreign tax credit. These final regulations impose new requirements that a foreign tax must meet in order to be creditable against U.S. income taxes, and generally apply to tax years beginning on or after December 28, 2021. On July 26, 2022, the U.S. Treasury released corrections to the final regulations. On July 21, 2023, the IRS released a notice that suspended the application of significant portions of the final regulations regarding the foreign tax credit for tax years 2022 and 2023. The notice released in July 2023 favorably impacted our ability to claim foreign tax credits in the United States for certain taxes imposed by certain foreign jurisdictions. On December 11, 2023, the IRS released a notice that extended the suspension of significant portions of the final regulations beyond December 31, 2023, until further guidance is issued.

[0001262039-26-000007:notes:248]
In December 2021, the Organisation for Economic Co-operation and Development enacted model rules for a new global minimum tax framework (“BEPS Pillar Two”), and various governments around the world have enacted, or are in the process of enacting, legislation on this. For the tax year 2025, BEPS Pillar Two has no impact to our effective tax rate or cash flows. We will continue to evaluate the impact of these tax law changes for future periods.

[0001262039-26-000007:notes:249]
The tax effects of temporary differences that give rise to significant portions of the deferred tax assets as of the years ended are presented below (in millions):

[0001262039-26-000007:notes:250]
|  | December 31,2025 |  | December 31,2024 |
| Deferred tax assets: |  |  |  |
| General business credit carryforward | $ | 31.6 |  |  | $ | 31.7 |  |
| Deferred revenue | 694.0 |  |  | 650.8 |  |
| Reserves and accruals | 101.7 |  |  | 139.0 |  |
| Net operating loss and capital loss carryforwards | 291.9 |  |  | 227.7 |  |
| Stock-based compensation expense | 33.1 |  |  | 27.0 |  |
| Depreciation and amortization | 9.4 |  |  | 12.0 |  |
| Capitalized research expenditures | 394.5 |  |  | 437.7 |  |
| Operating lease liabilities | 14.3 |  |  | 17.4 |  |
| Total deferred tax assets | 1,570.5 |  |  | 1,543.3 |  |
| Less: Valuation allowance | (71.8) |  |  | (40.7) |  |
| Deferred tax assets, net of valuation allowance | 1,498.7 |  |  | 1,502.6 |  |
| Deferred tax liabilities: |  |  |  |
| Deferred contract costs | (162.3) |  |  | (140.2) |  |
| Operating lease ROU assets | (14.0) |  |  | (15.8) |  |
| Acquired intangibles | (13.2) |  |  | (14.6) |  |
| Total deferred tax liabilities | (189.5) |  |  | (170.6) |  |
| Net deferred tax assets | $ | 1,309.2 |  |  | $ | 1,332.0 |  |

[0001262039-26-000007:notes:251]
In assessing the realizability of deferred tax assets, we considered whether it is more likely than not that some portion or all of our deferred tax assets will be realized. This realization is dependent upon the generation of future taxable income during the periods in which those temporary differences become deductible. We concluded that it is more likely than not that we will be able to realize the benefits of our deferred tax assets in the future except for our California research and development credits carryforward, certain impairment losses in business investments and certain tax attributes from business acquisitions. As of December 31, 2025, we had a valuation allowance of $71.8 million against those items.

[0001262039-26-000007:notes:252]
As of December 31, 2025, our federal and California net operating loss carryforwards for income tax purposes were $1.22 billion and $32.7 million, respectively. All the net operating loss carryforwards were from acquisitions which were limited by Section 382 of the Internal Revenue Code. If not utilized, the federal net operating loss carryforwards will begin to expire in 2028, and California net operating loss carryforwards will begin to expire in 2034.

[0001262039-26-000007:notes:253]
As of December 31, 2025, we had state tax credit carryforwards of $60.0 million. The state credits can be carried forward indefinitely.

[0001262039-26-000007:notes:254]
The aggregate changes in the balance of unrecognized tax benefits are (in millions):

[0001262039-26-000007:notes:255]
|  | Year Ended December 31, |
|  | 2025 |  | 2024 |  | 2023 |
| Unrecognized tax benefits, beginning of year | $ | 75.9 |  |  | $ | 65.8 |  |  | $ | 67.4 |  |
| Gross increases for tax positions related to the current year | 13.2 |  |  | 14.7 |  |  | 11.4 |  |
| Gross decreases for tax positions related to the current year | — |  |  | — |  |  | — |  |
| Gross increases for tax positions related to the prior year | 3.1 |  |  | 0.2 |  |  | 1.0 |  |
| Gross decreases for tax positions related to prior year | — |  |  | (2.3) |  |  | (4.0) |  |
| Gross decreases for tax positions related to prior year audit settlements | (1.1) |  |  | (1.8) |  |  | — |  |
| Gross decreases for tax positions related to expiration of statute of limitations | (0.7) |  |  | (0.7) |  |  | (10.0) |  |
| Unrecognized tax benefits, end of year | $ | 90.4 |  |  | $ | 75.9 |  |  | $ | 65.8 |  |

[0001262039-26-000007:notes:256]
As of December 31, 2025, we had $90.4 million of unrecognized tax benefits, of which, if recognized, $74.1 million would favorably affect our effective tax rate. Our gross unrecognized tax benefits increased approximately $14.5 million during the year ended December 31, 2025. The net increase was primarily due to the normal buildup of reserves related to the Federal Research & Development credit and transfer pricing. Our policy is to include accrued interest and penalties related to uncertain tax benefits in income tax expense. As of December 31, 2025, 2024 and 2023, accrued interest and penalties were $12.5 million, $8.8 million and $6.4 million, respectively.

[0001262039-26-000007:notes:257]
We file income tax returns in the U.S. federal jurisdiction and in various U.S. state and foreign jurisdictions. Generally, we are no longer subject to examination by U.S. federal income tax authorities for tax years prior to 2020 and by U.S. state and foreign tax authorities in our significant jurisdictions for tax years prior to 2016. We currently have ongoing tax audits in the United Kingdom, Canada, Germany and several other foreign jurisdictions. The focus of these audits is the inter-company profit allocation.

[0001262039-26-000007:notes:258]
The Act makes permanent certain elements of the Tax Cuts and Jobs Act, including immediate expensing of U.S. research and development expenditures, immediate expensing of certain eligible assets, and various modifications to the international tax framework. The income tax effects of the Act have been recognized in our provision for income taxes as of December 31, 2025. As a result of the Act, our income tax liability in 2025 decreased by $120.0 million and our GAAP effective tax rate for 2025 increased by one percentage point.

[0001262039-26-000007:notes:259]
We adopted ASU 2023-09 on a prospective basis for the year ended December 31, 2025 and have included the following table as a result of our adoption, which presents income taxes paid (net of refunds received) for the year ended December 31, 2025 (in millions):

[0001262039-26-000007:notes:260]
|  | Year Ended December 31, 2025 |  |
| US federal | $ | 294.8 |  |  |
| US state and local (1) | 34.5 |  |  |
| Foreign (1) | 122.2 |  |  |
| Total | $ | 451.5 |  |  |
| (1) Jurisdiction below the disaggregation threshold |  |


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0001262039-26-000007:notes:261]
DEFINED CONTRIBUTION PLANS
Our tax-deferred savings plan under our 401(k) Plan permits participating U.S. employees to contribute a portion of their pre-tax or after-tax earnings. In Canada, we have a Group Registered Retirement Savings Plan Program (the “RRSP”), which permits participants to make pre-tax contributions. Our board of directors approved 50% matching contributions on employee contributions up to 4% of each employee’s eligible earnings. Our matching contributions to our 401(k) Plan and the RRSP for 2025, 2024 and 2023 were $20.6 million, $19.3 million and $17.1 million, respectively.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001262039-26-000007:notes:262]
SEGMENT INFORMATION
Operating segments are determined based on the financial information that is regularly reviewed by the Chief Operating Decision Maker (“CODM”) to allocate resources and assess performance. The Company’s Chief Operating Decision Maker is our Chief Executive Officer, who reviews financial information presented on a consolidated basis, accompanied by information about revenue by geographic region. We have one operating and reportable segment. Our CODM uses consolidated net income as a measure to monitor actual results versus budget and historical performance of our reportable segment. The measure of the segment assets is reported on the consolidated balance sheets as total consolidated assets.

[0001262039-26-000007:notes:263]
The following table reflects certain financial data for our reportable segment (in millions):

[0001262039-26-000007:notes:264]
|  | Year Ended December 31, |
| 2025 |  | 2024 |  | 2023 |
| Total revenue | $ | 6,799.6 |  |  | $ | 5,955.8 |  |  | $ | 5,304.8 |  |
| Less: |  |  |  |  |  |
| Cost of product revenue | 725.4 |  |  | 652.0 |  |  | 763.6 |  |
| Cost of service revenue | 603.5 |  |  | 505.6 |  |  | 473.6 |  |
| Research and development expenses | 815.5 |  |  | 716.8 |  |  | 613.8 |  |
| Adjusted sales and marketing expenses (1) | 1,900.9 |  |  | 1,654.9 |  |  | 1,635.3 |  |
| Commission expense | 446.6 |  |  | 389.9 |  |  | 370.7 |  |
| General and administrative expenses | 233.4 |  |  | 237.8 |  |  | 211.3 |  |
| Provision for income taxes | 439.1 |  |  | 283.9 |  |  | 143.8 |  |
| Add: Other segment items (2) | 218.2 |  |  | 230.3 |  |  | 55.1 |  |
| Net income | $ | 1,853.4 |  |  | $ | 1,745.2 |  |  | $ | 1,147.8 |  |
| (1) Excludes commission expense.(2) The following table presents other segment items (in millions): |

[0001262039-26-000007:notes:265]
|  | Year Ended December 31, |
| 2025 |  | 2024 |  | 2023 |
| Gain on intellectual property matters | $ | 10.4 |  |  | $ | 4.6 |  |  | $ | 4.6 |  |
| Interest income | 162.3 |  |  | 155.2 |  |  | 119.7 |  |
| Interest expense | (20.1) |  |  | (20.0) |  |  | (21.0) |  |
| Other income (expense)—net | 55.3 |  |  | 119.9 |  |  | (6.1) |  |
| Gain (loss) from equity method investments | 10.3 |  |  | (29.4) |  |  | (42.1) |  |
| Total other segment items | $ | 218.2 |  |  | $ | 230.3 |  |  | $ | 55.1 |  |

[0001262039-26-000007:notes:266]
The following table presents other segment information (in millions):

[0001262039-26-000007:notes:267]
|  | Year Ended December 31, |
| 2025 |  | 2024 |  | 2023 |
| Significant non-cash items: |  |  |  |  |  |
| Stock‐based compensation expense | $ | 279.5 |  |  | $ | 257.9 |  |  | $ | 249.0 |  |
| Depreciation and amortization expense | 152.0 |  |  | 122.8 |  |  | 113.4 |  |
| Total assets | $ | 10,389.2 |  |  | $ | 9,763.1 |  |  | $ | 7,258.9 |  |
| Purchases of property and equipment | $ | 364.8 |  |  | $ | 378.9 |  |  | $ | 204.1 |  |

[0001262039-26-000007:notes:268]
Revenue by geographic region is based on the billing address of our customers. The following tables set forth revenue and property and equipment—net by geographic region (in millions):

[0001262039-26-000007:notes:269]
|  | Year Ended December 31, |
| Revenue | 2025 |  | 2024 |  | 2023 |
| Americas: |  |  |  |  |  |
| United States | $ | 1,929.5 |  |  | $ | 1,778.9 |  |  | $ | 1,605.9 |  |
| Other Americas | 770.9 |  |  | 663.3 |  |  | 569.3 |  |
| Total Americas | 2,700.4 |  |  | 2,442.2 |  |  | 2,175.2 |  |
| EMEA | 2,834.3 |  |  | 2,396.2 |  |  | 2,072.9 |  |
| APAC | 1,264.9 |  |  | 1,117.4 |  |  | 1,056.7 |  |
| Total revenue | $ | 6,799.6 |  |  | $ | 5,955.8 |  |  | $ | 5,304.8 |  |

[0001262039-26-000007:notes:270]
| Property and Equipment—net | December 31,2025 |  | December 31,2024 |
| Americas: |  |  |  |
| United States | $ | 1,000.8 |  |  | $ | 993.5 |  |
| Canada | 329.2 |  |  | 216.8 |  |
| Latin America | 4.9 |  |  | 4.4 |  |
| Total Americas | 1,334.9 |  |  | 1,214.7 |  |
| EMEA | 211.3 |  |  | 73.3 |  |
| APAC | 72.8 |  |  | 61.5 |  |
| Total property and equipment—net | $ | 1,619.0 |  |  | $ | 1,349.5 |  |

[0001262039-26-000007:notes:271]
The following distributor customers accounted for 10% or more of our revenue:

[0001262039-26-000007:notes:272]
|  | Year Ended December 31, |
|  | 2025 |  | 2024 |  | 2023 |
| Distributor A | 28 | % |  | 29 | % |  | 28 | % |
| Distributor B | 15 | % |  | 15 | % |  | 15 | % |
| Distributor C | 12 | % |  | 13 | % |  | 13 | % |

[0001262039-26-000007:notes:273]
The following distributor customers accounted for 10% or more of net accounts receivable:

[0001262039-26-000007:notes:274]
|  | 2025 |  | 2024 |
| Distributor A | 32 | % |  | 31 | % |
| Distributor B | 12 | % |  | 14 | % |
| Distributor C | 9 | % |  | 10 | % |


## us-gaap:SubsequentEventsTextBlock

[0001262039-26-000007:notes:275]
SUBSEQUENT EVENTS
Share repurchase program

[0001262039-26-000007:notes:276]
In January 2026, our board of directors approved a $1.0 billion increase in the authorized stock repurchase amount under the Repurchase Program, bringing the aggregate amount authorized to be repurchased to $10.25 billion of our outstanding common stock through February 28, 2027.

[0001262039-26-000007:notes:277]
Subsequent to December 31, 2025 and through the filing of this Annual Report on Form 10-K, we repurchased 6.1 million shares of our common stock at an average price of $76.68 per share, for an aggregate purchase price of

[0001262039-26-000007:notes:278]
$470.5 million, under the Repurchase Program. As of the filing of this Annual Report on Form 10-K, approximately $1.27 billion remained available for future share repurchases through February 28, 2027 under the Repurchase Program.

[0001262039-26-000007:notes:279]
Real Property Purchases

[0001262039-26-000007:notes:280]
In January 2026, we signed a definitive agreement to purchase real property in Sunnyvale, California, totaling approximately 5.3 acres for $47.0 million in cash, excluding acquisition costs.
