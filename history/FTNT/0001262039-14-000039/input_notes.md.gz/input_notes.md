# FTNT notes — 0001262039-14-000039


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001262039-14-000039:notes:1]
[same as prior period, unchanged from 0001262039-14-000033:notes:1]

[0001262039-14-000039:notes:2]
[same as prior period, unchanged from 0001262039-14-000033:notes:2]

[0001262039-14-000039:notes:3]
On March 21, 2013, we acquired all of the outstanding equity securities of Coyote, a provider of application delivery, load balancing and acceleration solutions, for $6.0 million in cash. The acquisition also included a contingent obligation for up to $5.5 million in future earn-out payments to former stockholders of Coyote, if specified future operational objectives, service conditions and financial results are met within two years of the acquisition date.  As of September 30, 2014, we have estimated that no contingent earn-out payment thresholds will be met.

[0001262039-14-000039:notes:4]
[same as prior period, unchanged from 0001262039-14-000033:notes:4]

[0001262039-14-000039:notes:5]
[same as prior period, unchanged from 0001262039-14-000033:notes:5]

[0001262039-14-000039:notes:6]
[same as prior period, unchanged from 0001262039-14-000033:notes:6]

[0001262039-14-000039:notes:7]
[same as prior period, unchanged from 0001262039-14-000033:notes:7]


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001262039-14-000039:notes:8]
COMMITMENTS AND CONTINGENCIES

[0001262039-14-000039:notes:9]
The following table summarizes our future principal contractual obligations as of September 30, 2014 (in thousands):

[0001262039-14-000039:notes:10]
|  | Total |  | 2014 (remainder) |  | 2015 |  | 2016 |  | 2017 |  | 2018 |  | Thereafter |
| Operating lease commitments | $ | 39,575 |  |  | $ | 2,495 |  |  | $ | 9,411 |  |  | $ | 7,590 |  |  | $ | 6,649 |  |  | $ | 5,467 |  |  | $ | 7,963 |  |
| Less: Sublease rental income | 642 |  |  | 193 |  |  | 449 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Operating lease commitments—net | 38,933 |  |  | 2,302 |  |  | 8,962 |  |  | 7,590 |  |  | 6,649 |  |  | 5,467 |  |  | 7,963 |  |
| Purchase commitments | 76,355 |  |  | 53,006 |  |  | 23,349 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Other contractual commitments | 24,176 |  |  | 19,530 |  |  | 3,592 |  |  | 813 |  |  | 241 |  |  | — |  |  | — |  |
| Total | $ | 139,464 |  |  | $ | 74,838 |  |  | $ | 35,903 |  |  | $ | 8,403 |  |  | $ | 6,890 |  |  | $ | 5,467 |  |  | $ | 7,963 |  |

[0001262039-14-000039:notes:11]
Operating Leases—We lease certain facilities under various non-cancelable operating leases, which expire through 2024. The terms of certain operating leases provide for renewal options. Rent expense is recognized using the straight-line method over the term of the lease. Rent expense was $2.6 million and $2.4 million during the three months ended September 30, 2014 and September 30, 2013, respectively. Rent expense was $7.7 million and $7.1 million during the nine months ended September 30, 2014 and September 30, 2013, respectively.

[0001262039-14-000039:notes:12]
Purchase Commitments and Other Contractual Commitments—In order to reduce manufacturing lead times and plan for adequate component supply, we may issue purchase orders to some of our independent contract manufacturers which may not be cancelable. As of September 30, 2014, we had $76.4 million of open purchase orders with our independent contract manufacturers that may not be cancelable.

[0001262039-14-000039:notes:13]
In addition to commitments with contract manufacturers, we have open purchase orders and contractual obligations in the ordinary course of business for which we have not received goods or services. As of September 30, 2014, we had $24.2 million in other purchase commitments.

[0001262039-14-000039:notes:14]
Warranties—Accrued warranty activities are summarized as follows (in thousands):

[0001262039-14-000039:notes:15]
|  | Nine Months Ended |
|  | September 30, 2014 |  | September 30, 2013 |
| Accrued warranty balance—beginning of the period | $ | 3,037 |  |  | $ | 2,309 |  |
| Warranty costs incurred | (2,597 | ) |  | (2,670 | ) |
| Provision for warranty for the period | 3,786 |  |  | 3,134 |  |
| Adjustment related to pre-existing warranties | (540 | ) |  | 274 |  |
| Accrued warranty balance—end of the period | $ | 3,686 |  |  | $ | 3,047 |  |

[0001262039-14-000039:notes:16]
Litigation—We are involved in disputes, litigation, and other legal actions. For lawsuits where we are the defendant, we are in the process of defending these litigation matters, and while there can be no assurances and the outcome of these matters is currently not determinable, we currently believe that there are no existing claims or proceedings that are likely to have a material adverse effect on our financial position. There are many uncertainties associated with any litigation and these actions or other third-party claims against us may cause us to incur costly litigation or substantial settlement charges. In addition, the resolution of any intellectual property litigation may require us to make royalty payments, which could adversely affect our gross margins in future periods. If any of those events were to occur, our business, financial condition, results of operations, and cash flows could be adversely affected. The actual liability in any such matters may be materially different from our estimates, if any, which could result in the need to adjust the liability and record additional expenses. We have not recorded any accrual for loss contingencies associated with such legal proceedings; determined that an unfavorable outcome is probable or reasonably possible; or determined that the amount or range of any possible loss is reasonably estimable.

[0001262039-14-000039:notes:17]
Indemnification—Under the indemnification provisions of our standard sales contracts, we agree to defend our customers against third-party claims asserting infringement of certain intellectual property rights, which may include patents, copyrights, trademarks, or trade secrets, and to pay judgments entered on such claims. Our exposure under these indemnification provisions is generally limited by the terms of our contracts to the total amount paid by our customer under the agreement. However, certain agreements include indemnification provisions beyond indemnification for third-party claims of intellectual property infringement and that could potentially expose us to losses in excess of the amount received under the agreement. To date, there have been no awards under such indemnification provisions.


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0001262039-14-000039:notes:18]
DEFINED CONTRIBUTION PLANS

[0001262039-14-000039:notes:19]
Our tax-deferred savings plan, under the 401(k) Plan, allows participating employees to defer a portion of their pre-tax earnings, up to the IRS annual contribution limit. In Canada, we have a Group Registered Retirement Savings Plan program (the “RRSP”) which permits participants to make tax deductible contributions up to the maximum contribution limits under the Income Tax Act. Our Board approved 50% matching contributions on employee contributions up to 4% of each employee’s eligible earnings. Our matching contributions to the 401(k) Plans and RRSP for the three months ended September 30, 2014 and September 30, 2013 were $0.7 million and $0.6 million, respectively. Our matching contributions to the 401(k) Plans and RRSP for the nine months ended September 30, 2014 and September 30, 2013 were $1.9 million and $1.6 million, respectively.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001262039-14-000039:notes:20]
[same as prior period, unchanged from 0001262039-14-000033:notes:20]

[0001262039-14-000039:notes:21]
The following table summarizes the changes in accumulated balances of other comprehensive income for the nine months ended September 30, 2014 (in thousands):

[0001262039-14-000039:notes:22]
|  | September 30, 2014 |
|  | Foreign Currency Translation Gains And Losses |  | Unrealized Gains And Losses On Investments |  | Tax Benefit Or Provision Related To Items Of Other Comprehensive Income Or Loss |  | Total |
| Balance as of December 31, 2013 | $ | 333 |  |  | $ | 1,168 |  |  | $ | (409 | ) |  | $ | 1,092 |  |
| Other comprehensive income before reclassifications | (333 | ) |  | (984 | ) |  | 345 |  |  | (972 | ) |
| Amounts reclassified from accumulated other comprehensive income | — |  |  | (9 | ) |  | 3 |  |  | (6 | ) |
| Net current-period other comprehensive income | (333 | ) |  | (993 | ) |  | 348 |  |  | (978 | ) |
| Balance as of September 30, 2014 | $ | — |  |  | $ | 175 |  |  | $ | (61 | ) |  | $ | 114 |  |

[0001262039-14-000039:notes:23]
The following table provides details about the reclassification out of accumulated other comprehensive income for the nine months ended September 30, 2014 (in thousands):

[0001262039-14-000039:notes:24]
| September 30, 2014 |
| Details About Accumulated Other Comprehensive Income Components |  | Amount Reclassified From Accumulated Other Comprehensive Income |  | Affected Line Item In The Statement Where Net Income Is Presented |
| Unrealized gains on investments |  | $ | (9 | ) |  | Other expense—net |
| Tax provision related to items of other comprehensive income or loss |  | 3 |  |  | Provision for income taxes |
| Total reclassification for the period |  | $ | (6 | ) |  |  |


## us-gaap:DeferredRevenueByArrangementDisclosureTextBlock

[0001262039-14-000039:notes:25]
[same as prior period, unchanged from 0001262039-14-000033:notes:25]

[0001262039-14-000039:notes:26]
|  | September 30, 2014 |  | December 31, 2013 |
| Product | $ | 2,685 |  |  | $ | 2,915 |  |
| Services and other | 497,327 |  |  | 429,713 |  |
| Total deferred revenue | $ | 500,012 |  |  | $ | 432,628 |  |
| Reported As: |  |  |  |
| Current | $ | 329,132 |  |  | $ | 293,664 |  |
| Non-current | 170,880 |  |  | 138,964 |  |
| Total deferred revenue | $ | 500,012 |  |  | $ | 432,628 |  |


## us-gaap:DeferredRevenueDisclosureTextBlock

[0001262039-14-000039:notes:27]
[same as prior period, unchanged from 0001262039-14-000033:notes:27]


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001262039-14-000039:notes:28]
[same as prior period, unchanged from 0001262039-14-000033:notes:28]

[0001262039-14-000039:notes:29]
Foreign Currency Derivatives—Our sales contracts are primarily denominated in U.S. dollars and therefore substantially all of our revenue is not subject to foreign currency translation risk. However, a substantial portion of our operating expenses incurred outside the U.S. are denominated in foreign currencies and are subject to fluctuations due to changes in foreign currency exchange rates, particularly changes in the Canadian dollar (“CAD”). To help protect against significant fluctuations in value and the volatility of future cash flows caused by changes in currency exchange rates, we engage in foreign currency risk management activities, including forward contracts, to hedge balance sheet items denominated in CAD. We do not use these contracts for speculative or trading purposes. All of the derivative instruments are with high quality financial institutions and we monitor the creditworthiness of these parties. These contracts typically have maturities of one month. We record changes in the fair value of forward exchange contracts related to balance sheet accounts as Other (expense) income—net in the consolidated statement of operations.

[0001262039-14-000039:notes:30]
Additionally, independent of any hedging activities, fluctuations in foreign currency exchange rates may cause us to recognize transaction gains and losses in Other (expense) income—net in our condensed consolidated statements of operations. Our hedging activities are intended to reduce, but not eliminate, the impact of currency exchange rate movements. As our hedging activities are relatively short-term in nature and are focused on CAD, long-term material changes in the value of the U.S. dollar against other foreign currencies, such as the GBP and EUR could adversely impact our operating expenses in the future.

[0001262039-14-000039:notes:31]
The notional amount of forward exchange contracts to hedge balance sheet accounts as of September 30, 2014 and December 31, 2013 were (in thousands):

[0001262039-14-000039:notes:32]
|  | Buy/Sell |  | Notional |
| Currency—As of September 30, 2014 |  |  |  |
| CAD | Buy |  | $ | 13,242 |  |
| Currency—As of December 31, 2013 |  |  |  |
| CAD | Buy |  | $ | 21,867 |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001262039-14-000039:notes:33]
[same as prior period, unchanged from 0001262039-14-000033:notes:33]

[0001262039-14-000039:notes:34]
[same as prior period, unchanged from 0001262039-14-000033:notes:35]

[0001262039-14-000039:notes:35]
[same as prior period, unchanged from 0001262039-14-000033:notes:36]

[0001262039-14-000039:notes:36]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30, 2014 |  | September 30, 2013 |  | September 30, 2014 |  | September 30, 2013 |
| Expected term in years | 4.9 |  |  | 4.6 |  |  | 4.9 |  |  | 4.6 |  |
| Volatility | 40.7 | % |  | 47.8 | % |  | 43.1 | % |  | 47.8 | % |
| Risk-free interest rate | 1.6 | % |  | 1.2 | % |  | 1.7 | % |  | 1.2 | % |
| Dividend rate | — |  |  | — |  |  | — |  |  | — |  |

[0001262039-14-000039:notes:37]
[same as prior period, unchanged from 0001262039-14-000033:notes:39]

[0001262039-14-000039:notes:38]
|  | Options Outstanding |
|  | Numberof Shares |  | Weighted-AverageExercisePrice |  | Weighted-AverageRemainingContractualLife (Years) |  | AggregateIntrinsicValue |
| Balance—December 31, 2013 | 15,521 |  |  | $ | 13.18 |  |  |  |  |  |  |
| Granted | 320 |  |  | 22.36 |  |  |  |  |  |
| Forfeited | (390 | ) |  | 24.15 |  |  |  |  |  |
| Exercised | (3,216 | ) |  | 8.25 |  |  |  |  |  |
| Balance—September 30, 2014 | 12,235 |  |  | 14.37 |  |  |  |  |  |
| Options vested and expected to vest—September 30, 2014 | 12,205 |  |  | $ | 14.35 |  |  | 2.82 |  | $ | 136,230 |  |
| Options exercisable—September 30, 2014 | 10,244 |  |  | $ | 12.59 |  |  | 2.48 |  | $ | 131,847 |  |

[0001262039-14-000039:notes:39]
The aggregate intrinsic value represents the pre-tax difference between the exercise price of stock options and the quoted market price of our common stock on September 30, 2014, for all in-the-money options. As of September 30, 2014, total compensation expense related to unvested stock options granted to employees but not yet recognized was $22.9 million, net of estimated forfeitures. This expense is expected to be amortized on a straight-line basis over a weighted-average period of 1.47 years.

[0001262039-14-000039:notes:40]
[same as prior period, unchanged from 0001262039-14-000033:notes:42]

[0001262039-14-000039:notes:41]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30, 2014 |  | September 30, 2013 |  | September 30, 2014 |  | September 30, 2013 |
| Weighted-average fair value per share granted | $ | 9.13 |  |  | $ | 8.61 |  |  | $ | 8.76 |  |  | $ | 8.61 |  |
| Intrinsic value of options exercised | $ | 17,728 |  |  | $ | 7,880 |  |  | $ | 49,490 |  |  | $ | 36,997 |  |
| Fair value of options vested | $ | 4,393 |  |  | $ | 5,063 |  |  | $ | 13,163 |  |  | $ | 21,553 |  |

[0001262039-14-000039:notes:42]
[same as prior period, unchanged from 0001262039-14-000033:notes:44]

[0001262039-14-000039:notes:43]
[same as prior period, unchanged from 0001262039-14-000033:notes:45]

[0001262039-14-000039:notes:44]
|  | Restricted Stock Units Outstanding |
|  | Number of Shares |  | Weighted-Average Grant-Date-Fair Value per Share |
| Balance—December 31, 2013 | 4,199 |  |  | $ | 22.00 |  |
| Granted | 3,359 |  |  | 22.44 |  |
| Forfeited | (342 | ) |  | 21.85 |  |
| Vested | (1,197 | ) |  | 22.31 |  |
| Balance—September 30, 2014 | 6,019 |  |  | $ | 22.27 |  |
| RSUs expected to vest—September 30, 2014 | 5,699 |  |  | $ | 22.27 |  |

[0001262039-14-000039:notes:45]
As of September 30, 2014, total compensation expense related to unvested RSUs that were granted to employees and non-employees under our 2009 Equity Incentive Plan, but not yet recognized, was $128.3 million, net of estimated forfeitures. This expense is expected to be amortized on a straight-line basis over a weighted-average vesting period of 3.02 years.

[0001262039-14-000039:notes:46]
[same as prior period, unchanged from 0001262039-14-000033:notes:48]

[0001262039-14-000039:notes:47]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30, 2014 |  | September 30, 2013 |  | September 30, 2014 |  | September 30, 2013 |
| Shares withheld for taxes | 124 |  |  | 45 |  |  | 381 |  |  | 45 |  |
| Amount withheld for taxes | $ | 2,985 |  |  | $ | 966 |  |  | $ | 8,506 |  |  | $ | 966 |  |

[0001262039-14-000039:notes:48]
[same as prior period, unchanged from 0001262039-14-000033:notes:51]

[0001262039-14-000039:notes:49]
[same as prior period, unchanged from 0001262039-14-000033:notes:52]

[0001262039-14-000039:notes:50]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30, 2014 |  | September 30, 2013 |  | September 30, 2014 |  | September 30, 2013 |
| Expected term in years | 0.5 |  |  | 0.5 |  |  | 0.5 |  |  | 0.5 |  |
| Volatility | 31.9 | % |  | 35.1 | % |  | 34.1 | % |  | 44.0 | % |
| Risk-free interest rate | 0.1 | % |  | 0.1 | % |  | 0.1 | % |  | 0.1 | % |
| Dividend rate | — |  |  | — |  |  | — |  |  | — |  |

[0001262039-14-000039:notes:51]
[same as prior period, unchanged from 0001262039-14-000033:notes:54]

[0001262039-14-000039:notes:52]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30, 2014 |  | September 30, 2013 |  | September 30, 2014 |  | September 30, 2013 |
| Weighted-average fair value per share granted | $ | 6.03 |  |  | $ | 5.04 |  |  | $ | 5.91 |  |  | $ | 6.11 |  |
| Shares issued under the ESPP | 346 |  |  | 344 |  |  | 770 |  |  | 672 |  |
| Weighted-average price per share issued | $ | 19.38 |  |  | $ | 17.90 |  |  | $ | 18.17 |  |  | $ | 18.88 |  |

[0001262039-14-000039:notes:53]
[same as prior period, unchanged from 0001262039-14-000033:notes:57]

[0001262039-14-000039:notes:54]
[same as prior period, unchanged from 0001262039-14-000033:notes:58]

[0001262039-14-000039:notes:55]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30, 2014 |  | September 30, 2013 |  | September 30, 2014 |  | September 30, 2013 |
| Cost of product revenue | $ | 60 |  |  | $ | 91 |  |  | $ | 351 |  |  | $ | 277 |  |
| Cost of services and other revenue | 1,522 |  |  | 1,297 |  |  | 4,214 |  |  | 3,543 |  |
| Research and development | 4,505 |  |  | 3,548 |  |  | 12,558 |  |  | 9,605 |  |
| Sales and marketing | 7,397 |  |  | 5,215 |  |  | 18,890 |  |  | 13,927 |  |
| General and administrative | 1,183 |  |  | 1,627 |  |  | 6,300 |  |  | 4,432 |  |
| Total stock-based compensation expense | $ | 14,667 |  |  | $ | 11,778 |  |  | $ | 42,313 |  |  | $ | 31,784 |  |

[0001262039-14-000039:notes:56]
[same as prior period, unchanged from 0001262039-14-000033:notes:60]

[0001262039-14-000039:notes:57]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30, 2014 |  | September 30, 2013 |  | September 30, 2014 |  | September 30, 2013 |
| Stock options | $ | 4,282 |  |  | $ | 5,180 |  |  | $ | 13,395 |  |  | $ | 15,801 |  |
| RSUs | 9,275 |  |  | 5,408 |  |  | 25,886 |  |  | 12,439 |  |
| ESPP | 1,110 |  |  | 1,190 |  |  | 3,032 |  |  | 3,544 |  |
| Total stock-based compensation expense | $ | 14,667 |  |  | $ | 11,778 |  |  | $ | 42,313 |  |  | $ | 31,784 |  |

[0001262039-14-000039:notes:58]
[same as prior period, unchanged from 0001262039-14-000033:notes:62]

[0001262039-14-000039:notes:59]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30, 2014 |  | September 30, 2013 |  | September 30, 2014 |  | September 30, 2013 |
| Income tax benefit associated with stock-based compensation | $ | 4,225 |  |  | $ | 3,176 |  |  | $ | 11,821 |  |  | $ | 9,557 |  |

[0001262039-14-000039:notes:60]
[same as prior period, unchanged from 0001262039-14-000033:notes:64]

[0001262039-14-000039:notes:61]
On December 6, 2013, our Board of Directors (“Board”) authorized a Share Repurchase Program (“Program”) to repurchase up to $200.0 million of our outstanding common stock through December 31, 2014. Under the Program, share repurchases may be made by us from time to time in privately negotiated transactions or in open market transactions. The Program may be suspended, modified or discontinued at any time without prior notice.  During the three and nine months ended September 30, 2014, we repurchased 0.4 million and 1.4 million shares of common stock under the Program in open market transactions for an aggregate purchase price of $10.7 million and $33.2 million, respectively. As of September 30, 2014, $127.9 million remained authorized for future share repurchases under the Program.


## us-gaap:EarningsPerShareTextBlock

[0001262039-14-000039:notes:62]
[same as prior period, unchanged from 0001262039-14-000033:notes:66]

[0001262039-14-000039:notes:63]
Basic net income per share is computed by dividing net income by the weighted-average number of shares of common stock outstanding during the period. Diluted net income per share is computed by dividing net income by the weighted-average number of shares of common stock outstanding, plus the dilutive effects of stock options, restricted stock units (“RSUs”), and the employee stock purchase plan (“ESPP”). Dilutive shares of common stock are determined by applying the treasury stock method.

[0001262039-14-000039:notes:64]
[same as prior period, unchanged from 0001262039-14-000033:notes:68]

[0001262039-14-000039:notes:65]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30, 2014 |  | September 30, 2013 |  | September 30, 2014 |  | September 30, 2013 |
| Numerator: |  |  |  |  |  |  |  |
| Net income | $ | 4,056 |  |  | $ | 11,029 |  |  | $ | 18,530 |  |  | $ | 32,257 |  |
| Denominator: |  |  |  |  |  |  |  |
| Basic shares: |  |  |  |  |  |  |  |
| Weighted-average common stock outstanding-basic | 164,294 |  |  | 162,906 |  |  | 163,289 |  |  | 162,150 |  |
| Diluted shares: |  |  |  |  |  |  |  |
| Weighted-average common stock outstanding-basic | 164,294 |  |  | 162,906 |  |  | 163,289 |  |  | 162,150 |  |
| Effect of potentially dilutive securities: |  |  |  |  |  |  |  |
| Stock options | 4,405 |  |  | 5,525 |  |  | 4,728 |  |  | 5,844 |  |
| RSUs | 993 |  |  | 213 |  |  | 692 |  |  | 50 |  |
| ESPP | 35 |  |  | 22 |  |  | 26 |  |  | 10 |  |
| Weighted-average shares used to compute diluted net income per share | 169,727 |  |  | 168,666 |  |  | 168,735 |  |  | 168,054 |  |
| Net income per share: |  |  |  |  |  |  |  |
| Basic | $ | 0.02 |  |  | $ | 0.07 |  |  | $ | 0.11 |  |  | $ | 0.20 |  |
| Diluted | $ | 0.02 |  |  | $ | 0.07 |  |  | $ | 0.11 |  |  | $ | 0.19 |  |

[0001262039-14-000039:notes:66]
[same as prior period, unchanged from 0001262039-14-000033:notes:70]

[0001262039-14-000039:notes:67]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30, 2014 |  | September 30, 2013 |  | September 30, 2014 |  | September 30, 2013 |
| Stock options | 3,023 |  |  | 6,640 |  |  | 4,101 |  |  | 7,364 |  |
| RSUs | 696 |  |  | 1,416 |  |  | 879 |  |  | 2,383 |  |
| ESPP | 226 |  |  | 407 |  |  | 133 |  |  | 399 |  |
|  | 3,945 |  |  | 8,463 |  |  | 5,113 |  |  | 10,146 |  |


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0001262039-14-000039:notes:68]
[same as prior period, unchanged from 0001262039-14-000033:notes:72]

[0001262039-14-000039:notes:69]
The following table summarizes our investments as of September 30, 2014 and December 31, 2013 (in thousands):

[0001262039-14-000039:notes:70]
|  | September 30, 2014 |
|  | AmortizedCost |  | UnrealizedGains |  | UnrealizedLosses |  | FairValue |
| Corporate debt securities | $ | 587,087 |  |  | $ | 763 |  |  | $ | (606 | ) |  | $ | 587,244 |  |
| Commercial paper | 58,250 |  |  | 4 |  |  | (1 | ) |  | 58,253 |  |
| Municipal bonds | 33,260 |  |  | 42 |  |  | (25 | ) |  | 33,277 |  |
| Certificates of deposit and term deposits | 21,143 |  |  | 1 |  |  | — |  |  | 21,144 |  |
| U.S. government and agency securities | 5,748 |  |  | 2 |  |  | (5 | ) |  | 5,745 |  |
| Total available-for-sale securities | $ | 705,488 |  |  | $ | 812 |  |  | $ | (637 | ) |  | $ | 705,663 |  |

[0001262039-14-000039:notes:71]
[same as prior period, unchanged from 0001262039-14-000033:notes:75]

[0001262039-14-000039:notes:72]
The following table shows the gross unrealized losses and the related fair values of our investments that have been in a continuous unrealized loss position as of September 30, 2014 and December 31, 2013 (in thousands):

[0001262039-14-000039:notes:73]
|  | September 30, 2014 |
|  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
|  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |
| Corporate debt securities | $ | 244,554 |  |  | $ | (605 | ) |  | $ | 1,017 |  |  | $ | (1 | ) |  | $ | 245,571 |  |  | $ | (606 | ) |
| Commercial paper | 2,396 |  |  | (1 | ) |  | — |  |  | — |  |  | 2,396 |  |  | (1 | ) |
| Municipal bonds | 12,201 |  |  | (25 | ) |  | 2,000 |  |  | — |  |  | 14,201 |  |  | (25 | ) |
| U.S. government and agency securities | 4,745 |  |  | (5 | ) |  | — |  |  | — |  |  | 4,745 |  |  | (5 | ) |
| Total available-for-sale securities | $ | 263,896 |  |  | $ | (636 | ) |  | $ | 3,017 |  |  | $ | (1 | ) |  | $ | 266,913 |  |  | $ | (637 | ) |

[0001262039-14-000039:notes:74]
[same as prior period, unchanged from 0001262039-14-000033:notes:78]

[0001262039-14-000039:notes:75]
[same as prior period, unchanged from 0001262039-14-000033:notes:79]

[0001262039-14-000039:notes:76]
|  | September 30, 2014 |  | December 31, 2013 |
| Due within one year | $ | 402,495 |  |  | $ | 375,497 |  |
| Due within one to three years | 303,168 |  |  | 351,675 |  |
| Total | $ | 705,663 |  |  | $ | 727,172 |  |

[0001262039-14-000039:notes:77]
Available-for-sale securities are reported at fair value, with unrealized gains and losses, net of tax, included as a separate component of stockholders’ equity and in total comprehensive income. Realized gains and losses on available-for-sale securities are included in Other expense—net in our condensed consolidated statements of operations.

[0001262039-14-000039:notes:78]
The unrealized losses on our available-for-sale securities were caused by fluctuations in market value and interest rates as a result of the economic environment. As the declines in market value are attributable to changes in market conditions and not credit quality, and because we have concluded currently that we neither intend to sell nor it is more likely than not that we will be required to sell these investments prior to a recovery of par value, we do not consider these investments to be other-than temporarily impaired as of September 30, 2014.

[0001262039-14-000039:notes:79]
[same as prior period, unchanged from 0001262039-14-000033:notes:83]

[0001262039-14-000039:notes:80]
[same as prior period, unchanged from 0001262039-14-000033:notes:84]

[0001262039-14-000039:notes:81]
[same as prior period, unchanged from 0001262039-14-000033:notes:85]

[0001262039-14-000039:notes:82]
The following table presents the fair value of our financial assets and liabilities measured at fair value on a recurring basis as of September 30, 2014 and December 31, 2013 (in thousands):

[0001262039-14-000039:notes:83]
|  | September 30, 2014 |  |  |  | December 31, 2013 |  |  |
|  | AggregateFairValue |  | QuotedPrices inActiveMarkets ForIdenticalAssets |  | SignificantOtherObservableRemainingInputs |  | SignificantOtherUnobservableRemainingInputs |  | AggregateFairValue |  | QuotedPrices inActiveMarkets ForIdenticalAssets |  | SignificantOtherObservableRemainingInputs |  | SignificantOtherUnobservableRemainingInputs |
|  |  |  | (Level 1) |  | (Level 2) |  | (Level 3) |  |  |  | (Level 1) |  | (Level 2) |  | (Level 3) |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate debt securities | $ | 587,244 |  |  | $ | — |  |  | $ | 587,244 |  |  | $ | — |  |  | $ | 604,317 |  |  | $ | — |  |  | $ | 604,317 |  |  | $ | — |  |
| Commercial paper | 58,253 |  |  | — |  |  | 58,253 |  |  | — |  |  | 71,363 |  |  | — |  |  | 71,363 |  |  | — |  |
| Municipal bonds | 33,277 |  |  | — |  |  | 33,277 |  |  | — |  |  | 38,843 |  |  | — |  |  | 38,843 |  |  | — |  |
| Certificates of deposit and term deposits | 21,144 |  |  | — |  |  | 21,144 |  |  | — |  |  | 12,648 |  |  | — |  |  | 12,648 |  |  | — |  |
| Money market funds | 20,125 |  |  | 20,125 |  |  | — |  |  | — |  |  | 5,724 |  |  | 5,724 |  |  | — |  |  | — |  |
| U.S. government and agency securities | 5,745 |  |  | 1,998 |  |  | 3,747 |  |  | — |  |  | 2,001 |  |  | — |  |  | 2,001 |  |  | — |  |
| Total | $ | 725,788 |  |  | $ | 22,123 |  |  | $ | 703,665 |  |  | $ | — |  |  | $ | 734,896 |  |  | $ | 5,724 |  |  | $ | 729,172 |  |  | $ | — |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Contingent consideration | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1,850 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,850 |  |
| Total | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1,850 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,850 |  |
| Reported as: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents | $ | 20,125 |  |  |  |  |  |  |  |  | $ | 7,724 |  |  |  |  |  |  |  |
| Short-term investments | 402,495 |  |  |  |  |  |  |  |  | 375,497 |  |  |  |  |  |  |  |
| Long-term investments | 303,168 |  |  |  |  |  |  |  |  | 351,675 |  |  |  |  |  |  |  |
| Total | $ | 725,788 |  |  |  |  |  |  |  |  | $ | 734,896 |  |  |  |  |  |  |  |

[0001262039-14-000039:notes:84]
[same as prior period, unchanged from 0001262039-14-000033:notes:88]

[0001262039-14-000039:notes:85]
[same as prior period, unchanged from 0001262039-14-000033:notes:89]

[0001262039-14-000039:notes:86]
There were no transfers between Level 1 and Level 2 of the fair value hierarchy during the three and nine months ended September 30, 2014.

[0001262039-14-000039:notes:87]
We classified the fair value of contingent consideration arising from the acquisition of Coyote Point Systems, Inc. (“Coyote”) (see Note 5), as a Level 3 liability since it is based on a probability-based income approach that includes significant unobservable inputs. The significant unobservable inputs include projected revenues and the percentage probability of occurrence to determine the fair value of the payment.

[0001262039-14-000039:notes:88]
[same as prior period, unchanged from 0001262039-14-000033:notes:92]

[0001262039-14-000039:notes:89]
| As of December 31, 2013 | $1,850 |
| Less change in fair value of contingent consideration | (1,143) |
| As of March 31, 2014 | 707 |
| Less change in fair value of contingent consideration | (707) |
| As of September 30, 2014 | $— |

[0001262039-14-000039:notes:90]
Decreases in the projected revenues of Coyote following the acquisition resulted in reductions to the fair value of the contingent consideration and the changes are included in research and development expense in the condensed consolidated statements of operations.

[0001262039-14-000039:notes:91]
[same as prior period, unchanged from 0001262039-14-000033:notes:95]

[0001262039-14-000039:notes:92]
[same as prior period, unchanged from 0001262039-14-000033:notes:96]

[0001262039-14-000039:notes:93]
During the nine months ended September 30, 2014, a decrease in the projected cash flow from Coyote resulted in an impairment charge of $2.4 million to adjust the total fair value of the other intangible assets acquired from Coyote to $2.0 million. The impairment charge is included within Cost of product revenue in the condensed consolidated statements of operations.

[0001262039-14-000039:notes:94]
We classified the intangible assets acquired from Coyote as Level 3 assets due to the lack of observable inputs to determine fair value. Significant inputs used in the determination of fair value based on the probability-weighted income approach primarily include internal cash flow projections and discount rates.

[0001262039-14-000039:notes:95]
[same as prior period, unchanged from 0001262039-14-000033:notes:99]


## us-gaap:ForeignCurrencyTransactionsAndTranslationsPolicyTextBlock

[0001262039-14-000039:notes:96]
Currency Translation Adjustment—Prior to the third quarter of fiscal 2014, the assets and liabilities of our international subsidiaries were translated into U.S. dollars using the applicable exchange rates. The resulting foreign translation adjustments were included in the consolidated balance sheets as a component of accumulated other comprehensive income (loss) and in the consolidated statements of comprehensive income.

[0001262039-14-000039:notes:97]
We reevaluated the selected functional currency of our international subsidiaries due to the nature of our business operations. We recorded the cumulative impact of the reevaluation of the functional currency in the condensed consolidated statement of operations for the three months ended September 30, 2014.  The remeasurement of the assets and liabilities of all international subsidiaries will be recorded in the consolidated statement of operations prospectively. The impact of this reevaluation is not material for any of our previously issued financial statements.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001262039-14-000039:notes:98]
[same as prior period, unchanged from 0001262039-14-000033:notes:100]

[0001262039-14-000039:notes:99]
The effective tax rate was 74% for the three months ended September 30, 2014, compared to an effective tax rate of 40% for the three months ended September 30, 2013. The effective tax rate was 55% for the nine months ended September 30, 2014, compared to an effective tax of 36% for the nine months ended September 30, 2013. The provision for income taxes for the periods presented is comprised of U.S. federal and state taxes, Singapore and other foreign income taxes, withholding tax, discrete taxes resulting from an increase in tax reserves, as well as the inclusion of stock compensation benefits and transfer pricing allocations which impact jurisdictional income taxed at various tax rates.

[0001262039-14-000039:notes:100]
As of September 30, 2014 and December 31, 2013, unrecognized tax benefits were $39.4 million and $30.2 million, respectively. The total amount of $39.4 million in unrecognized tax benefits, if recognized, would favorably impact the effective tax rate.

[0001262039-14-000039:notes:101]
It is our policy to classify accrued interest and penalties related to unrecognized tax benefits in the provision for income taxes. As of September 30, 2014, we had accrued approximately $1.6 million for estimated interest related to uncertain tax positions.


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0001262039-14-000039:notes:102]
[same as prior period, unchanged from 0001262039-14-000033:notes:104]

[0001262039-14-000039:notes:103]
We recorded $2.8 million of goodwill from the acquisition of Coyote. There were no impairments to goodwill during the three and nine months ended September 30, 2014.

[0001262039-14-000039:notes:104]
During the nine months ended September 30, 2014, we reassessed the fair value and the remaining useful life of the developed technologies acquired from Coyote. Based on this reassessment, we recorded an impairment charge of $2.4 million to adjust the total fair value of the other intangible assets acquired from Coyote to $2.0 million. The impairment charge is included within Cost of product revenue in the condensed consolidated statements of operations. Subsequent to the impairment, the remaining carrying value of the Coyote developed technologies will be amortized on a straight-line basis over an estimated remaining useful life of approximately five years.

[0001262039-14-000039:notes:105]
The following tables present other intangible assets—net (in thousands):

[0001262039-14-000039:notes:106]
|  | September 30, 2014 |
|  | Gross |  | Accumulated Amortization |  | Net |
| Other intangible assets—net: |  |  |  |  |  |
| Developed technology | $ | 5,606 |  |  | $ | 2,877 |  |  | $ | 2,729 |  |
| Customer relationships | 500 |  |  | 125 |  |  | 375 |  |
| Total other intangible assets—net | $ | 6,106 |  |  | $ | 3,002 |  |  | $ | 3,104 |  |

[0001262039-14-000039:notes:107]
[same as prior period, unchanged from 0001262039-14-000033:notes:109]

[0001262039-14-000039:notes:108]
Amortization expense was $0.2 million and $0.4 million during the three months ended September 30, 2014 and September 30, 2013, respectively. Amortization expense was $1.2 million and $1.1 million for the nine months ended September 30, 2014 and September 30, 2013, respectively. The following table summarizes estimated future amortization expense of Other intangible assets—net (in thousands):

[0001262039-14-000039:notes:109]
|  | Amount |
| Years Ending December 31: |  |
| 2014 (remainder) | $ | 273 |  |
| 2015 | 1,091 |  |
| 2016 | 785 |  |
| 2017 | 425 |  |
| 2018 | 425 |  |
| Thereafter | 105 |  |
| Total | $ | 3,104 |  |


## us-gaap:InventoryDisclosureTextBlock

[0001262039-14-000039:notes:110]
[same as prior period, unchanged from 0001262039-14-000033:notes:112]

[0001262039-14-000039:notes:111]
[same as prior period, unchanged from 0001262039-14-000033:notes:113]

[0001262039-14-000039:notes:112]
|  | September 30, 2014 |  | December 31, 2013 |
| Raw materials | $ | 5,922 |  |  | $ | 4,319 |  |
| Finished goods | 40,370 |  |  | 40,093 |  |
| Consigned inventory | 5,052 |  |  | 4,260 |  |
| Inventory | $ | 51,344 |  |  | $ | 48,672 |  |


## us-gaap:LongLivedAssetsByGeographicAreasTableTextBlock

[0001262039-14-000039:notes:113]
[same as prior period, unchanged from 0001262039-14-000033:notes:115]

[0001262039-14-000039:notes:114]
| Property and Equipment—Net | September 30, 2014 |  | December 31, 2013 |
| Americas: |  |  |  |
| United States | $ | 45,234 |  |  | $ | 29,334 |  |
| Canada | 5,884 |  |  | 4,372 |  |
| Other Americas | 411 |  |  | 45 |  |
| Total Americas | 51,529 |  |  | 33,751 |  |
| EMEA | 2,221 |  |  | 1,273 |  |
| APAC | 3,062 |  |  | 1,628 |  |
| Total property and equipment—net | $ | 56,812 |  |  | $ | 36,652 |  |


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001262039-14-000039:notes:115]
[same as prior period, unchanged from 0001262039-14-000033:notes:117]

[0001262039-14-000039:notes:116]
[same as prior period, unchanged from 0001262039-14-000033:notes:118]

[0001262039-14-000039:notes:117]
|  | September 30, 2014 |  | December 31, 2013 |
| Land | $ | 13,895 |  |  | $ | 13,895 |  |
| Building and building improvements | 17,546 |  |  | 610 |  |
| Evaluation units | 29,181 |  |  | 23,442 |  |
| Computer equipment and software | 31,010 |  |  | 23,556 |  |
| Furniture and fixtures | 4,655 |  |  | 1,697 |  |
| Construction-in-progress | 5,326 |  |  | 10,947 |  |
| Leasehold improvements | 7,595 |  |  | 4,303 |  |
| Total property and equipment | 109,208 |  |  | 78,450 |  |
| Less: accumulated depreciation | (52,396 | ) |  | (41,798 | ) |
| Property and equipment—net | $ | 56,812 |  |  | $ | 36,652 |  |

[0001262039-14-000039:notes:118]
Beginning in the first quarter of 2014, we reclassified certain fixed assets between categories in the table above to better reflect the nature of these fixed assets. Prior period amounts have also been reclassified to conform to the current period presentation. The impact of the reclassification is not material.

[0001262039-14-000039:notes:119]
Depreciation expense was $5.4 million and $3.8 million during the three months ended September 30, 2014 and September 30, 2013, respectively. Depreciation expense was $15.3 million and $10.4 million during the nine months ended September 30, 2014 and September 30, 2013, respectively.


## us-gaap:PropertyPlantAndEquipmentPolicyTextBlock

[0001262039-14-000039:notes:120]
[same as prior period, unchanged from 0001262039-14-000033:notes:122]

[0001262039-14-000039:notes:121]
[same as prior period, unchanged from 0001262039-14-000033:notes:123]

[0001262039-14-000039:notes:122]
In March 2014, we moved into our new corporate headquarters and estimated the useful life of the building and related improvements to be 20 years. The useful life of furniture and fixtures placed in service in the new building is estimated to be 3 to 5 years.


## us-gaap:RevenueFromExternalCustomersByGeographicAreasTableTextBlock

[0001262039-14-000039:notes:123]
[same as prior period, unchanged from 0001262039-14-000033:notes:125]

[0001262039-14-000039:notes:124]
|  | Three Months Ended |  | Nine Months Ended |
| Revenue | September 30, 2014 |  | September 30, 2013 |  | September 30, 2014 |  | September 30, 2013 |
| Americas: |  |  |  |  |  |  |  |
| United States | $ | 50,329 |  |  | $ | 40,654 |  |  | $ | 144,794 |  |  | $ | 114,257 |  |
| Other Americas | 31,889 |  |  | 24,794 |  |  | 88,241 |  |  | 63,844 |  |
| Total Americas | 82,218 |  |  | 65,448 |  |  | 233,035 |  |  | 178,101 |  |
| Europe, Middle East, and Africa (“EMEA”) | 66,157 |  |  | 51,373 |  |  | 185,354 |  |  | 149,500 |  |
| Asia Pacific and Japan (“APAC”) | 44,973 |  |  | 37,878 |  |  | 128,006 |  |  | 110,346 |  |
| Total revenue | $ | 193,348 |  |  | $ | 154,699 |  |  | $ | 546,395 |  |  | $ | 437,947 |  |


## us-gaap:SchedulesOfConcentrationOfRiskByRiskFactorTextBlock

[0001262039-14-000039:notes:125]
The following customers, each of which is a distributor, accounted for 10% or more of our net revenues:

[0001262039-14-000039:notes:126]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30, 2014 |  | September 30, 2013 |  | September 30, 2014 |  | September 30, 2013 |
| Exclusive Networks Group | 15 | % |  | 11 | % |  | 14 | % |  | 11 | % |
| Fine Tec Computer | 11 | % |  | — |  |  | — |  |  | — |  |

[0001262039-14-000039:notes:127]
The following customers, each of which is a distributor, accounted for 10% or more of net accounts receivable:

[0001262039-14-000039:notes:128]
|  | September 30, 2014 |  | December 31, 2013 |
| Exclusive Networks Group | 13 | % |  | 13 | % |
| Fine Tec Computer | 15 | % |  | — |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001262039-14-000039:notes:129]
SEGMENT AND SIGNIFICANT CUSTOMER INFORMATION


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001262039-14-000039:notes:130]
[same as prior period, unchanged from 0001262039-14-000033:notes:129]

[0001262039-14-000039:notes:131]
Basis of Presentation and Preparation—The unaudited condensed consolidated financial statements of Fortinet, Inc. and its wholly owned subsidiaries (collectively, “we,” “us,” or “our”) have been prepared in accordance with generally accepted accounting principles (“GAAP”) in the United States (“U.S.”) for interim financial information as well as the instructions to Form 10-Q pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (“SEC”). Accordingly, they do not include all of the information and footnotes required by GAAP for complete financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the fiscal year ended December 31, 2013, contained in our Annual Report on Form 10-K (“Form 10-K”) filed with the SEC on March 3, 2014. In the opinion of management, all adjustments, which includes normal recurring adjustments, considered necessary for a fair presentation have been included. All intercompany balances, transactions and cash flows have been eliminated. The results of operations for the three and nine months ended September 30, 2014 are not necessarily indicative of the operating results for the full year or for any future periods. The condensed consolidated balance sheets as of December 31, 2013 are derived from the audited consolidated financial statements for the year ended December 31, 2013.

[0001262039-14-000039:notes:132]
[same as prior period, unchanged from 0001262039-14-000033:notes:131]

[0001262039-14-000039:notes:133]
There have been no material changes to our significant accounting policies as of and for the three and nine months ended September 30, 2014.  During the first quarter of fiscal 2014, we prospectively modified the expected term calculation used in accounting for stock-based compensation expense and the estimated useful lives of building improvements, and furniture and fixtures. During the third quarter of fiscal 2014, we reevaluated the functional currency selection for certain of our international subsidiaries and prospectively applied the U.S. dollar.

[0001262039-14-000039:notes:134]
Stock-Based Compensation Expense—Beginning in the first quarter of fiscal 2014, we changed the methodology of calculating the expected term, which is one of the assumptions used in determining the fair value of our employee stock options under the Black Scholes option pricing model. The expected term represents the period that our stock-based awards are estimated to be outstanding. We believe that we have sufficient historical experience since becoming a publicly-traded company for estimating the expected term of the stock option awards, and therefore, we calculated our expected term based on historical experience instead of using the simplified method.

[0001262039-14-000039:notes:135]
[same as prior period, unchanged from 0001262039-14-000033:notes:134]

[0001262039-14-000039:notes:136]
Recent Accounting Pronouncement—In May 2014, the Financial Accounting Standards Board issued Accounting Standards Update No. 2014-09 (Topic 606) - Revenue from Contracts with Customers (“ASU 2014-09”) to create a single, joint revenue standard that is consistent across all industries and markets for companies that prepare their financial statements in accordance with U.S. GAAP. Under ASU 2014-09, an entity is required to recognize revenue upon the transfer of promised goods or services to customers in an amount that reflects the consideration the entity expects to be entitled to receive in exchange for those goods or services. ASU 2014-09 is effective for us beginning on January 1, 2017. We are currently evaluating the impact of ASU 2014-09 on our consolidated financial statements.


## us-gaap:SubsequentEventsTextBlock

[0001262039-14-000039:notes:137]
SUBSEQUENT EVENT

[0001262039-14-000039:notes:138]
On October 17, 2014, our Board extended the share repurchase authorization under the Program through December 31, 2015. As of October 17, 2014, $124.9 million remained authorized for future share repurchases under the Program.
