# FTNT MD&A — 0001262039-14-000039


## mdna

[0001262039-14-000039:mdna:1]
[same as prior period, unchanged from 0001262039-14-000033:mdna:1]

[0001262039-14-000039:mdna:2]
[same as prior period, unchanged from 0001262039-14-000033:mdna:2]

[0001262039-14-000039:mdna:3]
[same as prior period, unchanged from 0001262039-14-000033:mdna:3]

[0001262039-14-000039:mdna:4]
[same as prior period, unchanged from 0001262039-14-000033:mdna:4]

[0001262039-14-000039:mdna:5]
[same as prior period, unchanged from 0001262039-14-000033:mdna:5]

[0001262039-14-000039:mdna:6]
[same as prior period, unchanged from 0001262039-14-000033:mdna:6]

[0001262039-14-000039:mdna:7]
[same as prior period, unchanged from 0001262039-14-000033:mdna:7]

[0001262039-14-000039:mdna:8]
[same as prior period, unchanged from 0001262039-14-000033:mdna:8]

[0001262039-14-000039:mdna:9]
[same as prior period, unchanged from 0001262039-14-000033:mdna:9]

[0001262039-14-000039:mdna:10]
| • | trends in our operating expenses, including personnel costs, research and development expense, sales and marketing expense and general and administrative expense, and expectations regarding these expenses as a percentage of total revenue; |

[0001262039-14-000039:mdna:11]
[same as prior period, unchanged from 0001262039-14-000033:mdna:11]

[0001262039-14-000039:mdna:12]
[same as prior period, unchanged from 0001262039-14-000033:mdna:12]

[0001262039-14-000039:mdna:13]
| • | expectations regarding spending related to capital expenditures; |

[0001262039-14-000039:mdna:14]
| • | competition in our markets; |

[0001262039-14-000039:mdna:15]
[same as prior period, unchanged from 0001262039-14-000033:mdna:15]

[0001262039-14-000039:mdna:16]
[same as prior period, unchanged from 0001262039-14-000033:mdna:16]

[0001262039-14-000039:mdna:17]
[same as prior period, unchanged from 0001262039-14-000033:mdna:17]

[0001262039-14-000039:mdna:18]
We provide high performance network security solutions, which enable broad, integrated and high performance protection against advanced security threats while simplifying the IT security infrastructure for enterprises, service providers and governmental entities worldwide, including the majority of the Fortune Global 100.

[0001262039-14-000039:mdna:19]
Our core product platform is the FortiGate physical and virtual appliance, which ships with a set of broad security services, including firewall, virtual private network (VPN), application control, intrusion prevention, Web filtering and advanced threat protection (ATP). These security services are enabled by FortiGuard which provides extensive threat research and a global cloud network to deliver protection services to each FortiGate. FortiGate also has extensive networking capability

[0001262039-14-000039:mdna:20]
[same as prior period, unchanged from 0001262039-14-000033:mdna:31]

[0001262039-14-000039:mdna:21]
such as switching, routing, native internet protocol version 6 (IPv6) and different modes of deployment. FortiManager provides central management and the FortiAnalyzer provides reporting and analytics. The FortiGate platform can be extended to provide enhanced capabilities. For example, it can be used as a Wireless Controller for Access Points. An external sandbox can also be attached for local ATP analysis.

[0001262039-14-000039:mdna:22]
Customers select the functions or combination of functions that best meet their specific security requirements such as a high-speed data center firewall (DCFW) at the network core, a next-generation firewall (NGFW) at the edge, or a broad unified threat management (UTM) solution at branch sites. We derive a substantial majority of product sales from our FortiGate appliances, which range from the FortiGate-20 to -100 series, designed for small businesses, FortiGate-200 to -800 series for mid-sized enterprises, to the FortiGate-1000 to -5000 series for large enterprises, telecommunications carriers, and service providers. Our network security platform also includes our FortiGuard security subscription services, which end-customers can subscribe to in order to obtain access to dynamic updates to intrusion prevention, application control, anti-malware, Web filtering, and anti-spam functionality. End-customers can also choose to purchase FortiCare technical support services for our products. End-customers also often use FortiManager and FortiAnalyzer products in conjunction with a FortiGate deployment to provide centralized management, analysis and reporting capabilities.

[0001262039-14-000039:mdna:23]
We complement our core FortiGate product line with other appliances and software that offer additional protection from security threats to other critical areas of the enterprise, such as our FortiSandbox ATP messaging security product, Web application firewalls, databases security product, distributed denial of service attack (DDoS) security product, and endpoint security product for employee computers and mobile devices. Sales of these complementary products and related services represent less than 10% of our total revenue.

[0001262039-14-000039:mdna:24]
[same as prior period, unchanged from 0001262039-14-000033:mdna:21]

[0001262039-14-000039:mdna:25]
| • | We recorded total revenue of $193.3 million and $546.4 million during the three and nine months ended September 30, 2014, respectively, an increase of 25% during each of these periods compared to the same periods last year. Product revenue was $87.7 million and $249.9 million during the three and nine months ended September 30, 2014, respectively, an increase of 26% and 29%, respectively, compared to the same periods last year. Services and other revenue was $105.6 million and $296.5 million during the three and nine months ended September 30, 2014, respectively, an increase of 24% and 22%, respectively, compared to the same periods last year. |

[0001262039-14-000039:mdna:26]
| • | Cash, cash equivalents and investments were $963.8 million as of September 30, 2014, an increase of $120.7 million from December 31, 2013. |

[0001262039-14-000039:mdna:27]
| • | Deferred revenue was $500.0 million as of September 30, 2014, an increase of $67.4 million from December 31, 2013. |

[0001262039-14-000039:mdna:28]
| • | We generated cash flows from operating activities of $161.2 million during the nine months ended September 30, 2014, an increase of 60% compared to the same period last year. |

[0001262039-14-000039:mdna:29]
| • | We received $20.0 million pursuant to a six year mutual covenant-not-to-sue and release agreement with Palo Alto Networks, Inc. in January 2014. |

[0001262039-14-000039:mdna:30]
| • | We repurchased 1.4 million shares of common stock under our previously-announced Share Repurchase Program for an aggregate purchase price of $33.2 million during the nine months ended September 30, 2014. |

[0001262039-14-000039:mdna:31]
Revenue grew as a result of our focus on growth and our strategy to invest in our marketing and increase sales capacity during the three and nine months ended September 30, 2014. We also continued to gain traction with several recently introduced FortiGate products, including demand for certain of our high speed, low latency next-generation enterprise data center security products.

[0001262039-14-000039:mdna:32]
We continue to invest in sales and marketing to expand brand awareness and our global sales team and distribution channels to expand our global reach and sales capacity. We continue to focus on selling to large customers, such as enterprise and service providers. As a result, we experienced increased deal volumes driven by traction in enterprise data center deployments and large enterprise deals.

[0001262039-14-000039:mdna:33]
During the three months ended September 30, 2014, our revenue growth was primarily driven by greater sales volume in our FortiGate product family due to increased demand across all product categories, particularly from our entry-level and mid-range products, including our recently introduced FortiGate 300D and 500D enterprise security appliances. Sales of entry-level products (FortiGate-20 to -100 series) and mid-range products (FortiGate-200 to -800 series) increased compared to the

[0001262039-14-000039:mdna:34]
[same as prior period, unchanged from 0001262039-14-000033:mdna:40]

[0001262039-14-000039:mdna:35]
same period last year. During the nine months ended September 30, 2014, our revenue growth was primarily driven by an increase in the sale of our high-end products, including our recently introduced FortiGate 1500D and 3700D enterprise security appliances.

[0001262039-14-000039:mdna:36]
During the three and nine months ended September 30, 2014, operating expenses increased by 31% and 30%, respectively, compared to the same periods last year. The increase was primarily driven by our accelerated pace of hiring and marketing investments to support our growth as we continued to invest in expanding our sales coverage, marketing capabilities, developing new products and scaling our customer support organization to meet the needs of our growing customer base. Headcount increased to 2,721 as of September 30, 2014 from 2,238 as of September 30, 2013.

[0001262039-14-000039:mdna:37]
[same as prior period, unchanged from 0001262039-14-000033:mdna:47]

[0001262039-14-000039:mdna:38]
[same as prior period, unchanged from 0001262039-14-000033:mdna:33]

[0001262039-14-000039:mdna:39]
[same as prior period, unchanged from 0001262039-14-000033:mdna:34]

[0001262039-14-000039:mdna:40]
|  | Three Months Ended Or As Of |
|  | September 30, 2014 |  | September 30, 2013 |
|  | (in thousands) |
| Revenue | $ | 193,348 |  |  | $ | 154,699 |  |
| Deferred revenue | $ | 500,012 |  |  | $ | 400,173 |  |
| Increase in deferred revenue | $ | 19,810 |  |  | $ | 10,491 |  |
| Billings (non-GAAP) | $ | 213,158 |  |  | $ | 165,190 |  |
| Cash, cash equivalents and investments | $ | 963,759 |  |  | $ | 841,005 |  |
| Net cash provided by operating activities | $ | 56,518 |  |  | $ | 25,384 |  |
| Free cash flow (non-GAAP) | $ | 50,738 |  |  | $ | 22,224 |  |

[0001262039-14-000039:mdna:41]
Deferred revenue. Our deferred revenue consists of amounts that have been invoiced but that have not yet been recognized as revenue. The majority of our deferred revenue balance consists of the unamortized portion of services revenue from FortiGuard subscription and FortiCare support service contracts. We monitor our deferred revenue balance because it represents a significant portion of revenue to be recognized in future periods.

[0001262039-14-000039:mdna:42]
Billings (Non-GAAP). We define billings as revenue recognized plus the change in deferred revenue from the beginning to the end of the period less any deferred revenue balances acquired from business combination(s) during the period. We consider billings to be a useful metric for management and investors because billings drive deferred revenue, which is an important indicator of the health and visibility of our business, and has historically, represented a majority of the quarterly revenue that we recognize. There are a number of limitations related to the use of billings versus revenue calculated in accordance with GAAP. First, billings include amounts that have not yet been recognized as revenue. Second, we may calculate billings in a manner that is different from peer companies that report similar financial measures. Management compensates for these limitations by providing specific information regarding GAAP revenue and evaluating billings together with revenue calculated in accordance with GAAP. A reconciliation of billings to revenue, the most directly comparable financial measure calculated and presented in accordance with GAAP, is provided below:

[0001262039-14-000039:mdna:43]
|  | Three Months Ended |
| September 30, 2014 |  | September 30, 2013 |
| (in thousands) |
| Billings: |  |  |  |
| Revenue | $ | 193,348 |  |  | $ | 154,699 |  |
| Add increase in deferred revenue | 19,810 |  |  | 10,491 |  |
| Total billings (Non-GAAP) | $ | 213,158 |  |  | $ | 165,190 |  |

[0001262039-14-000039:mdna:44]
Free cash flow (Non-GAAP). We define free cash flow as net cash provided by operating activities less capital expenditures. We consider free cash flow to be a liquidity measure that provides useful information to management and investors about the amount of cash generated by the business that, after the acquisition of property and equipment, can be used for strategic opportunities, including investing in our business, making strategic acquisitions, repurchasing outstanding common stock, and strengthening the balance sheet. Analysis of free cash flow facilitates comparisons of our operating results to competitors’ operating results. A limitation of using free cash flow versus the GAAP measure of net cash provided by operating activities as a means for evaluating liquidity is that free cash flow does not represent the total increase or decrease in the cash, cash equivalents and investments balances for the period because it excludes cash used for capital expenditures and cash provided by or used for other investing and financing activities. We compensate for this limitation by providing

[0001262039-14-000039:mdna:45]
information about our capital expenditures and other investing and financing activities on the face of the cash flow statement and under “—Liquidity and Capital Resources.”  A reconciliation of free cash flow to net cash provided by operating activities, the most directly comparable financial measure calculated and presented in accordance with GAAP, is provided below:

[0001262039-14-000039:mdna:46]
|  | Three Months Ended |
| September 30, 2014 |  | September 30, 2013 |
| (in thousands) |
| Free Cash Flow: |  |  |  |
| Net cash provided by operating activities | $ | 56,518 |  |  | $ | 25,384 |  |
| Less purchases of property and equipment | (5,780 | ) |  | (3,160 | ) |
| Free cash flow (Non-GAAP) | $ | 50,738 |  |  | $ | 22,224 |  |

[0001262039-14-000039:mdna:47]
Critical Accounting Policies and Estimates—Our discussion and analysis of our financial condition and results of operations are based upon our financial statements, which have been prepared in accordance with GAAP. These principles require us to make estimates and judgments that affect the reported amounts of assets, liabilities, revenue and expenses, cash flow and related disclosure of contingent assets and liabilities. Our estimates include those related to revenue recognition, stock-based compensation expense, valuation of inventory, warranty liabilities, and accounting for income taxes. We base our estimates on historical experience and on various other assumptions that we believe to be reasonable under the circumstances. Actual results may differ from these estimates. To the extent that there are material differences between these estimates and our actual results, our future financial statements will be affected.

[0001262039-14-000039:mdna:48]
There have been no material changes to our critical accounting policies and estimates as of and for the three and nine months ended September 30, 2014, as compared to the critical accounting policies and estimates described in the Form 10-K.

[0001262039-14-000039:mdna:49]
[same as prior period, unchanged from 0001262039-14-000033:mdna:45]

[0001262039-14-000039:mdna:50]
Recent Accounting Pronouncement—In May 2014, the Financial Accounting Standards Board issued Accounting Standards Update No. 2014-09 (Topic 606) - Revenue from Contracts with Customers (“ASU 2014-09”) to create a single, joint revenue standard that is consistent across all industries and markets for companies that prepare their financial statements in accordance with U.S. GAAP. Under ASU 2014-09, an entity is required to recognize revenue upon the transfer of promised goods or services to customers, in an amount that reflects the consideration the entity expects to be entitled to in exchange for those goods or services. ASU 2014-09 is effective for us beginning on January 1, 2017. We are currently evaluating the impact of ASU 2014-09 on our consolidated financial statements.

[0001262039-14-000039:mdna:51]
[same as prior period, unchanged from 0001262039-14-000033:mdna:66]

[0001262039-14-000039:mdna:52]
[same as prior period, unchanged from 0001262039-14-000033:mdna:48]

[0001262039-14-000039:mdna:53]
Three Months Ended September 30, 2014 and September 30, 2013

[0001262039-14-000039:mdna:54]
[same as prior period, unchanged from 0001262039-14-000033:mdna:50]

[0001262039-14-000039:mdna:55]
|  | Three Months Ended |  |  |  |  |
| September 30, 2014 |  | September 30, 2013 |  |  |  |  |
| Amount |  | % ofRevenue |  | Amount |  | % ofRevenue |  | Change |  | % Change |
| (in thousands except percentages) |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 87,731 |  |  | 45 | % |  | $ | 69,687 |  |  | 45 | % |  | $ | 18,044 |  |  | 26 | % |
| Services and other | 105,617 |  |  | 55 |  |  | 85,012 |  |  | 55 |  |  | 20,605 |  |  | 24 |  |
| Total revenue | $ | 193,348 |  |  | 100 | % |  | $ | 154,699 |  |  | 100 | % |  | $ | 38,649 |  |  | 25 | % |
| Revenue by geography: |  |  |  |  |  |  |  |  |  |  |  |
| Americas | $ | 82,218 |  |  | 43 | % |  | $ | 65,448 |  |  | 42 | % |  | $ | 16,770 |  |  | 26 | % |
| Europe, Middle East and Africa (“EMEA”) | 66,157 |  |  | 34 |  |  | 51,373 |  |  | 33 |  |  | 14,784 |  |  | 29 |  |
| Asia Pacific and Japan (“APAC”) | 44,973 |  |  | 23 |  |  | 37,878 |  |  | 25 |  |  | 7,095 |  |  | 19 |  |
| Total revenue | $ | 193,348 |  |  | 100 | % |  | $ | 154,699 |  |  | 100 | % |  | $ | 38,649 |  |  | 25 | % |

[0001262039-14-000039:mdna:56]
Total revenue increased by $38.6 million, or 25%, in the three months ended September 30, 2014 compared to the same period last year. The Americas region contributed the largest portion of our revenue growth on an absolute dollar basis and all three regions experienced revenue growth compared to the same period last year. Product revenue increased by $18.0 million, or 26%, in the three months ended September 30, 2014, compared to the same period last year. The increase in product revenue was primarily driven by greater sales volume in our FortiGate product family due to increased demand across all product categories, particularly from our entry-level and mid-range products including our recently introduced FortiGate 300D and 500D enterprise security appliances.

[0001262039-14-000039:mdna:57]
Services and other revenue increased by $20.6 million, or 24%, in the three months ended September 30, 2014 compared to the same period last year due to the recognition of revenue from our growing deferred revenue balance consisting of FortiGuard subscription and FortiCare support contracts sold to a larger customer base.

[0001262039-14-000039:mdna:58]
[same as prior period, unchanged from 0001262039-14-000033:mdna:54]

[0001262039-14-000039:mdna:59]
|  | Three Months Ended |  |  |  |  |
| September 30, 2014 |  | September 30, 2013 |  | Change |  | % Change |
| (in thousands except percentages) |
| Cost of revenue: |  |  |  |  |  |  |  |
| Product | $ | 35,636 |  |  | $ | 27,126 |  |  | $ | 8,510 |  |  | 31 | % |
| Services and other | 21,249 |  |  | 16,804 |  |  | 4,445 |  |  | 26 |  |
| Total cost of revenue | $ | 56,885 |  |  | $ | 43,930 |  |  | $ | 12,955 |  |  | 29 | % |
| Gross margin: |  |  |  |  |  |  |  |
| Product | 59.4 | % |  | 61.1 | % |  | (1.7 | )% |  |  |
| Services and other | 79.9 |  |  | 80.2 |  |  | (0.3 | ) |  |  |
| Total gross margin | 70.6 | % |  | 71.6 | % |  | (1.0 | )% |  |  |

[0001262039-14-000039:mdna:60]
Total gross margin decreased by 1.0 percentage point in the three months ended September 30, 2014 compared to the same period last year, as product gross margin declined. Product gross margin decreased by 1.7 percentage points in the three months ended September 30, 2014 compared to the same period last year primarily as a result of the sale of a higher mix of

[0001262039-14-000039:mdna:61]
[same as prior period, unchanged from 0001262039-14-000033:mdna:75]

[0001262039-14-000039:mdna:62]
entry-level and mid-range products and higher overhead costs. In addition, warranty-related costs increased by $1.4 million. Services and other gross margin decreased by 0.3 percentage points during the three months ended September 30, 2014 as our continued investments in our technical support and global threat research organizations were relatively in line with our rate of growth of services and other revenue. Cost of services and other revenue increased by $4.4 million in the three months ended September 30, 2014 compared to the same period last year, primarily due to a $2.6 million increase in personnel costs related to headcount increases, a $0.8 million increase in professional services and a $0.8 million increase in depreciation and occupancy-related costs.

[0001262039-14-000039:mdna:63]
[same as prior period, unchanged from 0001262039-14-000033:mdna:58]

[0001262039-14-000039:mdna:64]
|  | Three Months Ended |  | Change |  | % Change |
| September 30, 2014 |  | September 30, 2013 |  |
| Amount |  | % ofRevenue |  | Amount |  | % ofRevenue |  |
| (in thousands except percentages) |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | $ | 30,790 |  |  | 16 | % |  | $ | 26,421 |  |  | 17 | % |  | $ | 4,369 |  |  | 17 | % |
| Sales and marketing | 80,433 |  |  | 42 |  |  | 56,687 |  |  | 37 |  |  | 23,746 |  |  | 42 |  |
| General and administrative | 9,789 |  |  | 5 |  |  | 9,382 |  |  | 6 |  |  | 407 |  |  | 4 |  |
| Total operating expenses | $ | 121,012 |  |  | 63 | % |  | $ | 92,490 |  |  | 60 | % |  | $ | 28,522 |  |  | 31 | % |

[0001262039-14-000039:mdna:65]
[same as prior period, unchanged from 0001262039-14-000033:mdna:60]

[0001262039-14-000039:mdna:66]
Research and development expense increased by $4.4 million, or 17%, in the three months ended September 30, 2014 compared to the same period last year, primarily due to an increase of $3.4 million in personnel costs as a result of increased headcount to support the development of new products and continued enhancements of our existing products. In addition, we incurred higher stock-based compensation expense of $1.0 million, higher occupancy-related costs of $0.6 million, and higher consulting service costs of $0.3 million. This increase was partially offset by lower product development expenses, such as third-party testing and prototypes costs of $0.5 million and depreciation and other costs of $0.3 million. We intend to continue to invest in our research and development organization but expect research and development expense as a percentage of total revenue to remain at similar levels during the remainder of fiscal 2014.

[0001262039-14-000039:mdna:67]
[same as prior period, unchanged from 0001262039-14-000033:mdna:62]

[0001262039-14-000039:mdna:68]
Sales and marketing expense increased by $23.7 million, or 42%, in the three months ended September 30, 2014 compared to the same period last year, primarily due to an increase of $15.3 million in personnel costs as we continued to increase our headcount in order to drive continued market share gains globally. In addition, we increased our investments in marketing, including increasing expenditure on tradeshows, lead generation campaigns and other marketing-related expenses of $3.6 million. Our stock-based compensation expense increased by $2.2 million, depreciation expense, occupancy-related and other costs increased by $1.3 million and travel expense increased by $0.7 million. As a percentage of total revenue, sales and marketing expenses increased as we accelerated the investment in our sales force and marketing campaigns to drive future growth. We intend to continue to make investments in sales and marketing and expect sales and marketing expense as a percentage of total revenue to remain at similar levels or increase during the remainder of fiscal 2014.

[0001262039-14-000039:mdna:69]
[same as prior period, unchanged from 0001262039-14-000033:mdna:64]

[0001262039-14-000039:mdna:70]
General and administrative expense increased by $0.4 million, or 4%, in the three months ended September 30, 2014 compared to the same period last year. Personnel costs increased by $1.2 million as we continued to increase our headcount in order to support our expanding business. The increase was partially offset by lower stock-based compensation expense of $0.4 million and other costs of $0.4 million. We expect general and administrative expense as a percentage of total revenue to remain at similar levels during the remainder of fiscal 2014.

[0001262039-14-000039:mdna:71]
[same as prior period, unchanged from 0001262039-14-000033:mdna:84]

[0001262039-14-000039:mdna:72]
[same as prior period, unchanged from 0001262039-14-000033:mdna:67]

[0001262039-14-000039:mdna:73]
|  | Three Months Ended |  |  |  |  |
| September 30, 2014 |  | September 30, 2013 |  | Change |  | % Change |
| (in thousands except percentages) |
| Interest income | $ | 1,339 |  |  | $ | 1,282 |  |  | $ | 57 |  |  | 4 | % |
| Other expense—net | (1,005 | ) |  | (1,151 | ) |  | 146 |  |  | (13 | ) |

[0001262039-14-000039:mdna:74]
Interest income increased in the three months ended September 30, 2014 compared to the same period last year due to interest earned on higher invested balances of cash, cash equivalents and investments. The change in other expense—net, for the three months ended September 30, 2014 when compared to the same period last year, was the result of lower foreign exchange losses.

[0001262039-14-000039:mdna:75]
[same as prior period, unchanged from 0001262039-14-000033:mdna:70]

[0001262039-14-000039:mdna:76]
|  | Three Months Ended |  | Change |  | % Change |
| September 30, 2014 |  | September 30, 2013 |  |
| (in thousands except percentages) |
| Provision for income taxes | $ | 11,729 |  |  | $ | 7,381 |  |  | $ | 4,348 |  |  | 59 | % |
| Effective tax rate | 74 | % |  | 40 | % |  | 34 | % |  | — |  |

[0001262039-14-000039:mdna:77]
Our effective tax rate was 74% for the three months ended September 30, 2014, compared to 40% for the same period last year. The provision for income taxes for the three months ended September 30, 2014 was comprised primarily of U.S. federal and state taxes, Singapore and other foreign income taxes, withholding tax, discrete taxes resulting from an increase in tax reserves, as well as the inclusion of stock compensation benefits and transfer pricing allocations which impact jurisdictional income taxed at various tax rates. The increase in the effective tax rate for the three months ended September 30, 2014 as compared to the same period last year was primarily due to a change in the mix of profitability between jurisdictions, an increase in estimated tax liability related to foreign operations, an increase in tax reserves, an increase in non-tax deductible stock-based compensation expense, limitations on utilizing foreign tax credits, and expiration of the U.S. federal research and development credit effective December 31, 2013. The U.S. Congress has not extended the research and development tax credit as of September 30, 2014.

[0001262039-14-000039:mdna:78]
It is our policy to classify accrued interest and penalties related to unrecognized tax benefits in the provision for income taxes. As of September 30, 2014, we had accrued approximately $1.6 million for estimated interest related to uncertain tax positions.

[0001262039-14-000039:mdna:79]
[same as prior period, unchanged from 0001262039-14-000033:mdna:74]

[0001262039-14-000039:mdna:80]
[same as prior period, unchanged from 0001262039-14-000033:mdna:97]

[0001262039-14-000039:mdna:81]
Nine Months Ended September 30, 2014 and September 30, 2013

[0001262039-14-000039:mdna:82]
[same as prior period, unchanged from 0001262039-14-000033:mdna:77]

[0001262039-14-000039:mdna:83]
|  | Nine Months Ended |  |  |  |  |
| September 30, 2014 |  | September 30, 2013 |  |  |  |  |
| Amount |  | % ofRevenue |  | Amount |  | % ofRevenue |  | Change |  | % Change |
| (in thousands except percentages) |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 249,880 |  |  | 46 | % |  | $ | 194,162 |  |  | 44 | % |  | $ | 55,718 |  |  | 29 | % |
| Services and other | 296,515 |  |  | 54 |  |  | 243,785 |  |  | 56 |  |  | 52,730 |  |  | 22 |  |
| Total revenue | $ | 546,395 |  |  | 100 | % |  | $ | 437,947 |  |  | 100 | % |  | $ | 108,448 |  |  | 25 | % |
| Revenue by geography: |  |  |  |  |  |  |  |  |  |  |  |
| Americas | $ | 233,035 |  |  | 43 | % |  | $ | 178,101 |  |  | 41 | % |  | $ | 54,934 |  |  | 31 | % |
| EMEA | 185,354 |  |  | 34 |  |  | 149,500 |  |  | 34 |  |  | 35,854 |  |  | 24 |  |
| APAC | 128,006 |  |  | 23 |  |  | 110,346 |  |  | 25 |  |  | 17,660 |  |  | 16 |  |
| Total revenue | $ | 546,395 |  |  | 100 |  |  | $ | 437,947 |  |  | 100 | % |  | $ | 108,448 |  |  | 25 | % |

[0001262039-14-000039:mdna:84]
Total revenue increased by $108.4 million, or 25%, in the nine months ended September 30, 2014 compared to the same period last year. The Americas region contributed the largest portion of our revenue growth on both an absolute dollar basis and percentage basis. Product revenue increased by $55.7 million, or 29%, in the nine months ended September 30, 2014, compared to the same period last year. The increase in product revenue was primarily driven by greater sales volume in our FortiGate product family due to increased demand across all product categories, particularly in our high-end products including our recently introduced FortiGate 1500D and 3700D enterprise security appliances.

[0001262039-14-000039:mdna:85]
Services and other revenue increased by $52.7 million, or 22%, in the nine months ended September 30, 2014 compared to the same period last year due to the recognition of revenue from our increased deferred revenue balance consisting of FortiGuard subscription and FortiCare support contracts sold to a larger customer base.

[0001262039-14-000039:mdna:86]
[same as prior period, unchanged from 0001262039-14-000033:mdna:81]

[0001262039-14-000039:mdna:87]
|  | Nine Months Ended |  |  |  |  |
| September 30, 2014 |  | September 30, 2013 |  | Change |  | % Change |
| (in thousands except percentages) |
| Cost of revenue: |  |  |  |  |  |  |  |
| Product | $ | 105,230 |  |  | $ | 77,032 |  |  | $ | 28,198 |  |  | 37 | % |
| Services and other | 60,155 |  |  | 49,734 |  |  | 10,421 |  |  | 21 |  |
| Total cost of revenue | $ | 165,385 |  |  | $ | 126,766 |  |  | $ | 38,619 |  |  | 30 | % |
| Gross margin: |  |  |  |  |  |  |  |
| Product | 57.9 | % |  | 60.3 | % |  | (2.4 | )% |  |  |
| Services and other | 79.7 |  |  | 79.6 |  |  | 0.1 |  |  |  |
| Total gross margin | 69.7 | % |  | 71.1 | % |  | (1.4 | )% |  |  |

[0001262039-14-000039:mdna:88]
Total gross margin decreased by 1.4 percentage points in the nine months ended September 30, 2014 compared to the same period last year, as product gross margin declined. Product gross margin decreased by 2.4 percentage points in the nine months ended September 30, 2014 compared to the same period last year, primarily due to a $2.4 million impairment charge related to certain intangible assets. In addition, warranty-related costs increased by $2.7 million, excess inventory write-offs increased by $1.1 million, and personnel costs increased by $0.6 million. Services and other gross margin increased by 0.1 percentage points during the nine months ended September 30, 2014 as our continued investments in our technical support and global threat research organizations were relatively in line with our rate of growth of services and other revenue. Cost of services and other revenue increased by $10.4 million primarily due to a $6.1 million increase in personnel costs related to

[0001262039-14-000039:mdna:89]
headcount increases, a $1.3 million increase in depreciation, a $1.0 million increase in occupancy-related costs, and a $0.7 million increase in stock-based compensation expense.

[0001262039-14-000039:mdna:90]
[same as prior period, unchanged from 0001262039-14-000033:mdna:86]

[0001262039-14-000039:mdna:91]
|  | Nine Months Ended |  | Change |  | % Change |
| September 30, 2014 |  | September 30, 2013 |  |
| Amount |  | % ofRevenue |  | Amount |  | % ofRevenue |  |
| (in thousands except percentages) |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | $ | 89,783 |  |  | 16 | % |  | $ | 74,913 |  |  | 17 | % |  | $ | 14,870 |  |  | 20 | % |
| Sales and marketing | 222,576 |  |  | 41 |  |  | 162,660 |  |  | 37 |  |  | 59,916 |  |  | 37 |  |
| General and administrative | 29,243 |  |  | 5 |  |  | 26,161 |  |  | 6 |  |  | 3,082 |  |  | 12 |  |
| Total operating expenses | $ | 341,602 |  |  | 63 | % |  | $ | 263,734 |  |  | 60 | % |  | $ | 77,868 |  |  | 30 | % |

[0001262039-14-000039:mdna:92]
[same as prior period, unchanged from 0001262039-14-000033:mdna:88]

[0001262039-14-000039:mdna:93]
Research and development expense increased by $14.9 million, or 20%, in the nine months ended September 30, 2014 compared to the same period last year, primarily due to an increase of $8.7 million in personnel costs as a result of increased headcount to support the development of new products and continued enhancements of our existing products. In addition, we incurred higher product development expenses, such as third-party testing, prototypes and supplies, of $3.7 million, higher stock-based compensation expense of $3.0 million, and higher depreciation and occupancy-related costs of $2.2 million. These increases were partially offset by a $3.0 million reversal of estimated contingent consideration.

[0001262039-14-000039:mdna:94]
[same as prior period, unchanged from 0001262039-14-000033:mdna:90]

[0001262039-14-000039:mdna:95]
Sales and marketing expense increased by $59.9 million, or 37%, in the nine months ended September 30, 2014 compared to the same period last year, primarily due to an increase of $39.3 million in personnel costs as we continued to increase our headcount in order to drive continued market share gains globally. We also significantly increased marketing-related expenses by $9.2 million as we invested in tradeshows and lead generation campaigns. In addition, we incurred increases in stock-based compensation of $5.0 million, depreciation expense of $2.1 million, travel expense of $1.8 million and other costs of $2.6 million. As a percentage of total revenue, sales and marketing expenses increased as we are accelerating the investment in our sales force and marketing campaigns to drive future growth.

[0001262039-14-000039:mdna:96]
[same as prior period, unchanged from 0001262039-14-000033:mdna:92]

[0001262039-14-000039:mdna:97]
General and administrative expense increased by $3.1 million, or 12%, in the nine months ended September 30, 2014 compared to the same period last year. Personnel costs increased by $2.9 million and stock-based compensation expense increased by $1.9 million as we continued to increase our headcount in order to support our expanding business. The increase in expense was partially offset by a decrease of $0.8 million in professional services fees and $0.9 million in occupancy-related costs including depreciation and supplies.

[0001262039-14-000039:mdna:98]
Interest income and Other expense—net

[0001262039-14-000039:mdna:99]
|  | Nine Months Ended |  |  |  |  |
| September 30, 2014 |  | September 30, 2013 |  | Change |  | % Change |
| (in thousands except percentages) |
| Interest income | $ | 3,991 |  |  | $ | 3,988 |  |  | $ | 3 |  |  | — |
| Other expense—net | (1,968 | ) |  | (1,036 | ) |  | (932 | ) |  | 90 |

[0001262039-14-000039:mdna:100]
The change in other expense—net, for the nine months ended September 30, 2014 when compared to the same period last year, was the result of higher foreign exchange losses and the impact of a reevaluation of the functional currency selection of certain of our international subsidiaries.

[0001262039-14-000039:mdna:101]
33

[0001262039-14-000039:mdna:102]
.

[0001262039-14-000039:mdna:103]
[same as prior period, unchanged from 0001262039-14-000033:mdna:98]

[0001262039-14-000039:mdna:104]
|  | Nine Months Ended |  | Change |  | % Change |
| September 30, 2014 |  | September 30, 2013 |  |
| (in thousands except percentages) |
| Provision for income taxes | $ | 22,901 |  |  | $ | 18,142 |  |  | $ | 4,759 |  |  | 26 | % |
| Effective tax rate | 55 | % |  | 36 | % |  | 19 | % |  | — |  |

[0001262039-14-000039:mdna:105]
Our effective tax rate was 55% for the nine months ended September 30, 2014, compared to 36% for the same period last year. The provision for income taxes for the nine months ended September 30, 2014 was comprised primarily of U.S. federal and state taxes, Singapore and other foreign income taxes, withholding tax, as well as the inclusion of stock compensation benefits and transfer pricing allocations which impact jurisdictional income taxed at various tax rates. The increase in the effective tax rate for the nine months ended September 30, 2014 as compared to the same period last year was primarily due to a change in the mix of profitability between jurisdictions, an increase in estimated tax liability related to foreign operations, an increase in tax reserves, an increase in non-tax deductible stock-based compensation expense, limitations on utilizing foreign tax credits, and expiration of the U.S. federal research and development credit effective December 31, 2013. The U.S. Congress has not extended the research and development tax credit as of September 30, 2014.

[0001262039-14-000039:mdna:106]
[same as prior period, unchanged from 0001262039-14-000033:mdna:101]

[0001262039-14-000039:mdna:107]
|  | September 30, 2014 |  | December 31, 2013 |
|  | (in thousands) |
| Cash and cash equivalents | $ | 258,096 |  |  | $ | 115,873 |  |
| Investments | 705,663 |  |  | 727,172 |  |
| Total cash, cash equivalents and investments | $ | 963,759 |  |  | $ | 843,045 |  |
| Working capital | $ | 461,944 |  |  | $ | 322,485 |  |
|  | Nine Months Ended |
|  | September 30, 2014 |  | September 30, 2013 |
|  | (in thousands) |
| Net cash provided by operating activities | $ | 161,218 |  |  | $ | 100,716 |  |
| Net cash used in investing activities | (16,508 | ) |  | (104,148 | ) |
| Net cash (used in) provided by financing activities | (1,887 | ) |  | 26,008 |  |
| Effect of exchange rates on cash and cash equivalents | (600 | ) |  | (1,005 | ) |
| Net increase in cash and cash equivalents | $ | 142,223 |  |  | $ | 21,571 |  |

[0001262039-14-000039:mdna:108]
Liquidity and capital resources may be impacted by our operating activities, as well as acquisitions, capital expenditures, stock repurchases, and investments in strategic relationships that we have made or may make in the future. In January 2014, we received a cash payment of $20.0 million pursuant to a six year mutual covenant-not-to-sue and release agreement with Palo Alto Networks, Inc. We expect to spend up to $7.0 million related to our capital expenditures, primarily related to purchase of computer equipment, expansion of our offices, as well as the implementation of our enterprise resource planning system during the remainder of fiscal 2014. As of September 30, 2014, $127.9 million remained available for future share repurchases under our Share Repurchase Program (“Program”), which will be financed through our available working capital. On October 17, 2014, our board of directors extended the share repurchase authorization under the Program through December 31, 2015. As of October 17, 2014, $124.9 million remained authorized for future share repurchases under the Program.

[0001262039-14-000039:mdna:109]
34

[0001262039-14-000039:mdna:110]
As of September 30, 2014, our cash, cash equivalents and investments of $963.8 million were held for working-capital purposes and were invested primarily in corporate debt securities, commercial paper, municipal bonds, certificates of deposit and term deposits, money market funds, and U.S. government and agency securities. It is our investment policy to invest excess cash in a manner that preserves capital, provides liquidity and maximizes return.

[0001262039-14-000039:mdna:111]
As of September 30, 2014, $233.4 million of our cash and investments was held by our international subsidiaries and is therefore not immediately available to fund domestic operations unless the cash is repatriated. While we do not intend to do so, should this amount be repatriated, it would be subject to U.S. federal income tax which would be partially offset by foreign tax credits. We do not enter into investments for trading or speculative purposes. We believe that our existing cash and cash equivalents will be sufficient to meet our anticipated cash needs for at least the next 12 months. Our future capital requirements will depend on many factors including our growth rate, the timing and extent of spending to support development efforts, the expansion of sales and marketing activities, the introduction of new and enhanced products and services offerings, the costs to ensure access to adequate manufacturing capacity, the continuing market acceptance of our products, share repurchases, and future capital expenditures related to real estate and infrastructure. Historically, we have required capital principally to fund our working capital needs, capital expenditures, share repurchases, and acquisition activities. In the event that additional financing is required from outside sources, we may not be able to raise it on terms acceptable to us or at all. If we are unable to raise additional capital when desired, our business, operating results and financial condition would be adversely affected.

[0001262039-14-000039:mdna:112]
[same as prior period, unchanged from 0001262039-14-000033:mdna:107]

[0001262039-14-000039:mdna:113]
[same as prior period, unchanged from 0001262039-14-000033:mdna:108]

[0001262039-14-000039:mdna:114]
Our operating activities during the nine months ended September 30, 2014 provided $161.2 million in cash as a result of profitability, timing of billings and collections, and the ability to successfully manage our working capital. The primary sources of cash from operating activities during the nine months ended September 30, 2014 consisted of net income of $18.5 million increased by non-cash adjustments of $65.0 million and changes in operating assets and liabilities of $77.7 million. In January 2014, we received $20.0 million pursuant to a six year mutual covenant-not-to-sue and release agreement with Palo Alto Networks, Inc. Changes in operating assets and liabilities primarily included an increase in payments received from customers and a receipt of cash related to the mutual covenant-not-to-sue and release agreement, partially offset by payments for inventory purchases and payment of income taxes during the period.

[0001262039-14-000039:mdna:115]
Our operating activities during the nine months ended September 30, 2013 provided $100.7 million in cash. The primary sources of cash from operating activities during the nine months ended September 30, 2013 consisted of net income of $32.3 million increased by non-cash adjustments of $50.2 million and changes in operating assets and liabilities of $18.2 million. Changes in operating assets and liabilities primarily included an increase in payments received from customers, partially offset by payment for inventory purchases.

[0001262039-14-000039:mdna:116]
[same as prior period, unchanged from 0001262039-14-000033:mdna:111]

[0001262039-14-000039:mdna:117]
[same as prior period, unchanged from 0001262039-14-000033:mdna:112]

[0001262039-14-000039:mdna:118]
During the nine months ended September 30, 2014, cash used was primarily due to $26.8 million for our capital expenditures, partially offset by positive cash flow due to maturities, net of purchases, from our investments of $10.3 million.

[0001262039-14-000039:mdna:119]
During the nine months ended September 30, 2013, cash used was primarily due to $89.8 million net purchases of investments, $7.6 million for acquisitions, and $6.7 million for the purchases of property and equipment.

[0001262039-14-000039:mdna:120]
[same as prior period, unchanged from 0001262039-14-000033:mdna:115]

[0001262039-14-000039:mdna:121]
[same as prior period, unchanged from 0001262039-14-000033:mdna:116]

[0001262039-14-000039:mdna:122]
During the nine months ended September 30, 2014, we used $38.2 million and $8.5 million of our cash to repurchase and retire our common stock and pay taxes related to withholding upon the issuance of restricted stock units, respectively.  This cash outflow was partially offset by proceeds of $40.5 million from the issuance of common stock under our stock plans, as well as excess tax benefit from employee stock-based compensation of $4.3 million.

[0001262039-14-000039:mdna:123]
During the nine months ended September 30, 2013, we had positive cash flow of $26.0 million from financing activities as a result of proceeds of $24.5 million from the issuance of common stock under our stock plans and an excess tax benefit from employee stock option exercises of $2.5 million.

[0001262039-14-000039:mdna:124]
[same as prior period, unchanged from 0001262039-14-000033:mdna:119]

[0001262039-14-000039:mdna:125]
There have been no material changes outside the ordinary course of business during the nine months ended September 30, 2014, to the contractual obligations and commitments disclosed in Management’s Discussion and Analysis of Financial Condition and Results of Operations, set forth in Part II, Item 7, of the Form 10-K. See Note 9 to the notes to the condensed consolidated financial statements included in Part I, Item 1 of this Form 10-Q for additional information regarding contractual obligations and commitments.

[0001262039-14-000039:mdna:126]
[same as prior period, unchanged from 0001262039-14-000033:mdna:121]

[0001262039-14-000039:mdna:127]
As of September 30, 2014, we did not have any relationships with unconsolidated organizations or financial partnerships, such as structured finance or special purpose entities that would have been established for the purpose of facilitating off-balance sheet arrangements or other contractually narrow or limited purposes.
