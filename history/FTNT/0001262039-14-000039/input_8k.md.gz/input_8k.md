# FTNT 8-K — 0001262039-14-000036 filed 2014-10-22

## item codes, every 8-K on or before 2014-11-06

- 2014-10-22 0001262039-14-000036 — 2.02, 9.01
- 2014-07-23 0001262039-14-000030 — 2.02, 9.01
- 2014-06-24 0001262039-14-000027 — 5.07
- 2014-04-23 0001262039-14-000021 — 2.02, 9.01
- 2014-04-21 0001262039-14-000018 — 5.03, 9.01
- 2014-01-29 0001262039-14-000004 — 2.02, 9.01
- 2013-12-20 0001262039-13-000061 — 5.02, 9.01
- 2013-11-27 0001262039-13-000057 — 5.02, 7.01, 9.01
- 2013-11-12 0001445305-13-002993 — 5.02
- 2013-10-23 0001262039-13-000051 — 2.02, 9.01
- 2013-07-30 0001262039-13-000039 — 2.02, 9.01
- 2013-06-25 0001262039-13-000030 — 5.07
- 2013-04-30 0001262039-13-000023 — 2.02, 9.01
- 2013-04-19 0001262039-13-000020 — 5.02, 9.01
- 2013-04-19 0001262039-13-000018 — 5.02 — amendment of 0001262039-13-000020
- 2013-04-10 0001262039-13-000016 — 2.02, 9.01
- 2013-03-26 0001262039-13-000013 — 5.02
- 2013-01-30 0001262039-13-000005 — 2.02, 9.01
- 2013-01-24 0001262039-13-000002 — 5.02, 9.01
- 2012-10-16 0001262039-12-000048 — 2.02, 9.01
- 2012-10-01 0001262039-12-000045 — 5.02
- 2012-09-26 0001262039-12-000043 — 5.01
- 2012-07-25 0001262039-12-000038 — 2.02, 9.01
- 2012-07-19 0001262039-12-000034 — 5.02
- 2012-06-20 0001193125-12-275869 — 5.07
- 2012-04-27 0001262039-12-000029 — 5.02
- 2012-04-24 0001262039-12-000025 — 2.02, 9.01
- 2012-01-31 0001262039-12-000006 — 2.02, 9.01
- 2012-01-25 0001262039-12-000003 — 5.03
- 2011-10-24 0001262039-11-000036 — 2.02
- 2011-07-19 0001262039-11-000014 — 2.02, 9.01
- 2011-06-27 0001193125-11-174474 — 5.02, 5.07, 9.01
- 2011-04-27 0001193125-11-111938 — 2.02, 9.01
- 2011-01-25 0001193125-11-013914 — 2.02, 9.01
- 2010-10-21 0001193125-10-233676 — 2.02, 9.01
- 2010-09-02 0001193125-10-203099 — 8.01
- 2010-07-22 0001193125-10-163844 — 2.02, 9.01
- 2010-06-24 0001193125-10-146082 — 5.07
- 2010-04-28 0001193125-10-096698 — 2.02, 9.01
- 2010-02-09 0001193125-10-024614 — 8.01
- 2010-01-27 0001193125-10-014292 — 2.02, 9.01
- 2010-01-26 0001193125-10-013031 — 5.02, 9.01

## late-filing notifications on or before 2014-11-06

- none on or before 2014-11-06

## item 2.02 — earnings release, exhibit 99.1

[0001262039-14-000036:8k_2_02:1]
EX-99.1
2
ftntq3-2014ex991.htm
PRESS RELEASE

[0001262039-14-000036:8k_2_02:2]
FTNT Q3-2014 EX 99.1

[0001262039-14-000036:8k_2_02:3]
Press Release

[0001262039-14-000036:8k_2_02:4]
| Investor Contact: |  | Media Contact: |
| Michelle Spolver |  | Chris McKie |
| Fortinet, Inc. |  | Fortinet, Inc. |
| 408-486-7837 |  | 408-486-5406 |
| mspolver@fortinet.com |  | cmckie@fortinet.com |

[0001262039-14-000036:8k_2_02:5]
Fortinet Reports Strong Third Quarter 2014 Financial Results

[0001262039-14-000036:8k_2_02:6]
Strong Growth Continues:  Billings Rise 29% and Revenues Rise 25% Year Over Year

[0001262039-14-000036:8k_2_02:7]
•Billings of $213.2 million, up 29% year over year1

[0001262039-14-000036:8k_2_02:8]
•Revenues of $193.3 million, up 25% year over year

[0001262039-14-000036:8k_2_02:9]
•Non-GAAP diluted net income per share of $0.121

[0001262039-14-000036:8k_2_02:10]
•Free cash flow of $50.7 million1

[0001262039-14-000036:8k_2_02:11]
| • | Cash, cash equivalents and investments of $963.8 million2, with no debt |

[0001262039-14-000036:8k_2_02:12]
| • | Deferred revenue of $500.0 million, up 25% year over year |

[0001262039-14-000036:8k_2_02:13]
SUNNYVALE, Calif. - October 22, 2014 - Fortinet® (NASDAQ: FTNT), a global leader in high-performance network security, today announced financial results for the third quarter ended September 30, 2014.

[0001262039-14-000036:8k_2_02:14]
“We are pleased to report another strong quarter that exceeded expectations, as we continued to execute well against our growth strategy and benefit from security market demand and customer adoption of new Fortinet products,” said Ken Xie, founder, chairman and chief executive officer.  “Our investments in sales and marketing have continued to pay off evidenced by another quarter of traction in both new customer wins, as well as expansion within our existing large and growing global customer base.  We currently believe that Fortinet remains well positioned for the remainder of the year and into 2015.”

[0001262039-14-000036:8k_2_02:15]
Financial Highlights for the Third Quarter of 2014

[0001262039-14-000036:8k_2_02:16]
| • | Billings1: Total billings were $213.2 million for the third quarter of 2014, an increase of 29% compared to $165.2 million in the same quarter of 2013. |

[0001262039-14-000036:8k_2_02:17]
| • | Revenue3: Total revenue was $193.3 million for the third quarter of 2014, an increase of 25% compared to $154.7 million in the same quarter of 2013. Within total revenue, product revenue was $87.7 million, an increase of 26% compared to the same quarter of |

[0001262039-14-000036:8k_2_02:18]
2013.  Services and other revenue was $105.6 million, an increase of 24% compared to the same quarter of 2013.

[0001262039-14-000036:8k_2_02:19]
| • | Deferred Revenue: Total deferred revenue was $500.0 million as of September 30, 2014, an increase of 25% compared to deferred revenue of $400.2 million as of September 30, 2013, and an increase of $19.8 million from $480.2 million as of June 30, 2014. |

[0001262039-14-000036:8k_2_02:20]
| • | Cash and Cash Flow2: As of September 30, 2014, cash, cash equivalents and investments were $963.8 million, compared to $910.6 million as of June 30, 2014. In the third quarter of 2014, cash flow from operations was $56.5 million and free cash flow1 was $50.7 million. |

[0001262039-14-000036:8k_2_02:21]
| • | GAAP Operating Income: GAAP operating income was $15.5 million for the third quarter of 2014, representing a GAAP operating margin of 8%. GAAP operating income was $18.3 million for the same quarter of 2013, representing a GAAP operating margin of 12%. |

[0001262039-14-000036:8k_2_02:22]
| • | GAAP Net Income and Diluted Net Income Per Share: GAAP net income was $4.1 million for the third quarter of 2014, compared to GAAP net income of $11.0 million for the same quarter of 2013. GAAP diluted net income per share was $0.02 for the third quarter of 2014, compared to $0.07 for the same quarter of 2013. |

[0001262039-14-000036:8k_2_02:23]
| • | Non-GAAP Operating Income1: Non-GAAP operating income was $30.4 million for the third quarter of 2014, representing a non-GAAP operating margin of 16%. Non-GAAP operating income was $30.5 million for the same quarter of 2013, representing a non-GAAP operating margin of 20%. |

[0001262039-14-000036:8k_2_02:24]
| • | Non-GAAP Net Income and Diluted Net Income Per Share1: Non-GAAP net income was $20.0 million for the third quarter of 2014, compared to non-GAAP net income of $20.5 million for the same quarter of 2013. Non-GAAP diluted net income per share was $0.12 for the third quarter of 2014, consistent with the same quarter of 2013. |

[0001262039-14-000036:8k_2_02:25]
1 A reconciliation of GAAP to non-GAAP financial measures has been provided in the financial statement tables included in this press release. An explanation of these measures is also included below under the heading “Non-GAAP Financial Measures.”

[0001262039-14-000036:8k_2_02:26]
2 During the third quarter of fiscal 2014, we repurchased $10.7 million of our common stock under our share repurchase program.

[0001262039-14-000036:8k_2_02:27]
3 Beginning in the first quarter of 2014, we combined ratable and other revenue with services revenue to present the combined amounts as services and other revenue in the condensed consolidated statements of operations. The related cost of revenue and gross profit, including prior period amounts, have also been combined to conform to the current period presentation. We believe the ratable and other revenue amounts, including the related cost of revenue and gross profit amounts, are not material.

[0001262039-14-000036:8k_2_02:28]
Conference Call Details

[0001262039-14-000036:8k_2_02:29]
Fortinet will host a conference call today, October 22, 2014, at 1:30 p.m. Pacific Time (4:30 p.m. Eastern Time) to discuss its financial results.  To access this call, dial (877) 303-6913 (domestic) or (224) 357-2188 (international) with conference ID # 14959718. A live webcast of the conference call and supplemental slides will be accessible from the Investor Relations page of

[0001262039-14-000036:8k_2_02:30]
Fortinet's website at http://investor.fortinet.com and a replay will be archived and accessible at http://investor.fortinet.com/events.cfm.  A replay of this conference call can also be accessed through October 29, 2014, by dialing (855) 859-2056 (domestic) or (404) 537-3406 (international) with conference ID# 14959718.

[0001262039-14-000036:8k_2_02:31]
Following Fortinet's financial results conference call, the Company will host an additional question-and-answer session at 3:30 p.m. Pacific Time (6:30 p.m. Eastern Time) to provide an opportunity for financial analysts and investors to ask more detailed questions. To access this call, dial (877) 303-6913 (domestic) or (224) 357-2188 (international) with conference ID # 14961850. This follow-up call will be webcast live and accessible at http://investor.fortinet.com, and a replay will be archived and available after the call at http://investor.fortinet.com/events.cfm. A replay of this conference call will also be available through October 29, 2014 by dialing (855) 859-2056 (domestic) or (404) 537-3406 (international) with conference ID # 14961850.

[0001262039-14-000036:8k_2_02:32]
About Fortinet (www.fortinet.com)

[0001262039-14-000036:8k_2_02:33]
Fortinet (NASDAQ: FTNT) helps protect networks, users and data from continually evolving threats. As a global leader in high-performance network security, we enable businesses and governments to consolidate and integrate stand-alone technologies without suffering performance penalties. Unlike costly, inflexible and low-performance alternatives, Fortinet solutions empower customers to embrace new technologies and business opportunities while protecting essential systems and content. Learn more at www.fortinet.com.

[0001262039-14-000036:8k_2_02:34]
#          #          #

[0001262039-14-000036:8k_2_02:35]
Copyright © 2014 Fortinet, Inc. All rights reserved. The symbols ® and ™ denote respectively federally registered trademarks and unregistered trademarks of Fortinet, Inc., its subsidiaries and affiliates. Fortinet's trademarks include, but are not limited to, the following: Fortinet, FortiGate, FortiGuard, FortiManager, FortiMail, FortiClient, FortiCare, FortiAnalyzer, FortiReporter, FortiOS, FortiASIC, FortiWiFi, FortiSwitch, FortiVoIP, FortiBIOS, FortiLog, FortiResponse, FortiCarrier, FortiScan, FortiAP, FortiDB, FortiVoice and FortiWeb. Other trademarks belong to their respective owners.

[0001262039-14-000036:8k_2_02:36]
FTNT-F

[0001262039-14-000036:8k_2_02:37]
Forward-looking Statements

[0001262039-14-000036:8k_2_02:38]
This press release contains forward-looking statements that involve risks and uncertainties. These forward-looking statements include statements regarding the position of our business and current expectations regarding business momentum and growth. Although we attempt to be accurate in making forward-looking statements, it is possible that future circumstances might differ from the assumptions on which such statements are based. Important factors that could cause results to differ materially from the statements herein include the following: general economic risks; increasing competitiveness in the security market; the dynamic nature of the security market; specific economic risks in different geographies and among different customer segments; uncertainty regarding increased business and renewals from existing customers; uncertainties around continued success in sales growth and market share gains; failure to convert sales pipeline into final sales; risks associated with successful implementation of multiple integrated software products and other product functionality risks; execution risks around new product development and introductions and innovation; litigation and disputes and the potential cost, distraction and damage to sales and reputation caused thereby; market acceptance of new products and services; the ability to attract and retain personnel; changes in strategy; lengthy sales and implementation cycles, particularly in larger organizations;

[0001262039-14-000036:8k_2_02:39]
Non-GAAP Financial Measures

[0001262039-14-000036:8k_2_02:40]
We have provided in this release financial information that has not been prepared in accordance with Generally Accepted Accounting Principles (GAAP). These non-GAAP financial measures are not based on any standardized methodology prescribed by GAAP and are not necessarily comparable to similar measures presented by other companies. We use these non-GAAP financial measures internally in analyzing our financial results and believe they are useful to investors, as a supplement to GAAP measures, in evaluating our ongoing operational performance. We believe that the use of these non-GAAP financial measures provides an additional tool for investors to use in evaluating ongoing operating results and trends and in comparing our financial results with other companies in our industry, many of which present similar non-GAAP financial measures to investors.

[0001262039-14-000036:8k_2_02:41]
Non-GAAP financial measures should not be considered in isolation from, or as a substitute for, financial information prepared in accordance with GAAP. Investors are encouraged to review the reconciliation of these non-GAAP financial measures to their most directly comparable GAAP financial measures below. As previously mentioned, a reconciliation of our non-GAAP financial measures to their most directly comparable GAAP measures has been provided in the financial statement tables included below in this press release.

[0001262039-14-000036:8k_2_02:42]
Billings. We define billings as revenue recognized plus the change in deferred revenue from the beginning to the end of the period less any deferred revenue balances acquired from business combination(s) during the period. We consider billings to be a useful metric for management and investors because billings drive deferred revenue, which is an important indicator of the health and visibility of our business, and has historically represented a majority of the quarterly revenue that we recognize. There are a number of limitations related to the use of billings versus revenue calculated in accordance with GAAP. First, billings include amounts that have not yet been recognized as revenue. Second, we may calculate billings in a manner that is different from peer companies that report similar financial measures. Management compensates for these limitations by providing specific information regarding GAAP revenue and evaluating billings together with revenues calculated in accordance with GAAP.

[0001262039-14-000036:8k_2_02:43]
Free cash flow. We define free cash flow as net cash provided by operating activities minus capital expenditures. We consider free cash flow to be a liquidity measure that provides useful information to management and investors about the amount of cash generated by the business that, after the acquisition of property and equipment, can be used for strategic opportunities, including investing in our business, making strategic acquisitions, repurchasing outstanding common stock, and strengthening the balance sheet. Analysis of free cash flow facilitates management's comparisons of our operating results to competitors' operating results. A limitation of using free cash flow versus the GAAP measure of net cash provided by operating activities as a means for evaluating liquidity is that free cash flow does not represent the total increase or decrease in the cash, cash equivalents and investments balance for the period because it excludes cash used for capital expenditures and cash provided by or used for other

[0001262039-14-000036:8k_2_02:44]
investing and financing activities. Management compensates for this limitation by providing information about our capital expenditures and other investing and financing activities on the face of the cash flow statement and under the caption “Management's Discussion and Analysis of Financial Condition and Results of Operations - Liquidity and Capital Resources” in our most recent Quarterly Report on Form 10-Q and Annual Report on Form 10-K.

[0001262039-14-000036:8k_2_02:45]
Non-GAAP operating income and operating margin. Beginning the first quarter of fiscal 2014, we define non-GAAP operating income as operating income plus stock-based compensation expense, acquisition-related charges, including amortization, impairments and other purchase accounting adjustments, and, when applicable, any other significant non-recurring items in a given quarter. Prior period amounts have been adjusted to conform to the current period presentation. Non-GAAP operating margin is defined as non-GAAP operating income divided by revenue. We consider these non-GAAP financial measures to be useful metrics for management and investors because they exclude the effect of stock-based compensation expense, acquisition-related charges, including amortization, impairments and other purchase accounting adjustments, and, when applicable, any other significant non-recurring items  so that our management and investors can compare our recurring core business operating results over multiple periods. There are a number of limitations related to the use of non-GAAP operating income versus operating income calculated in accordance with GAAP. First non-GAAP operating income excludes stock-based compensation expense and acquisition-related charges and any other significant non-recurring items. Stock-based compensation expense has been and will continue to be, for the foreseeable future, a significant recurring expense in our business. Second, stock-based compensation expense is an important part of our employees' compensation and impacts their performance. Third, the components of the costs that we exclude in our calculation of non-GAAP operating income may differ from the components that other companies exclude when they report their non-GAAP results of operations. Management compensates for these limitations by providing specific information regarding the GAAP amounts excluded from non-GAAP operating income and evaluating non-GAAP operating income together with operating income calculated in accordance with GAAP.

[0001262039-14-000036:8k_2_02:46]
Non-GAAP net income and diluted net income per share. We define non-GAAP net income as net income plus stock-based compensation expense, acquisition-related charges, including amortization, impairments and other purchase accounting adjustments, and, when applicable, any other significant non-recurring items, adjusted for the impact of the tax adjustment, if any, required to achieve the effective tax rate on a non-GAAP basis, which could differ from the GAAP effective tax rate. We define non-GAAP diluted net income per share as non-GAAP net income divided by the weighted-average diluted shares outstanding. We consider these non-GAAP financial measures to be useful metrics for management and investors for the same reasons that we use non-GAAP operating income and non-GAAP operating margin. However, in order to provide a complete picture of our recurring core business operating results, we include in non-GAAP net income and non-GAAP diluted net income per share, the tax adjustment required to achieve the effective tax rate on a non-GAAP basis, which could differ from the GAAP tax rate. We believe the effective tax rates we used are reasonable estimates of normalized tax rates for our current and prior fiscal years under our global operating structure. Our estimated tax rate on non-GAAP income is determined annually and may be adjusted during the year to take into account events or trends that we believe materially impact the estimated annual rate, including, but not limited to, significant changes resulting from tax legislation, material changes in the geographic mix of revenues and expenses and other significant events.  The same limitations described above regarding our use of non-GAAP operating income and non-GAAP operating margin apply to our use of non-GAAP net income and non-GAAP diluted net income per share. We compensate for these limitations by providing specific information regarding the GAAP amounts excluded from non-GAAP net income and non-GAAP diluted net income per share and evaluating non-GAAP net income and non-GAAP

[0001262039-14-000036:8k_2_02:47]
diluted net income per share together with net income and diluted net income per share calculated in accordance with GAAP.

[0001262039-14-000036:8k_2_02:48]
Changes to non-GAAP financial measures.  Beginning the first quarter of 2014, we will no longer adjust our GAAP results for insignificant non-recurring items. As a result, insignificant patent sale, license or settlement income amounts are no longer being excluded from our non-GAAP financial measures. All prior amounts reported in our earnings release have been adjusted to conform to the current period presentation.

[0001262039-14-000036:8k_2_02:49]
FORTINET, INC.

[0001262039-14-000036:8k_2_02:50]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001262039-14-000036:8k_2_02:51]
(Unaudited, in thousands)

[0001262039-14-000036:8k_2_02:52]
|  | September 30, 2014 |  | December 31, 2013 |
| ASSETS |  |  |  |
| CURRENT ASSETS: |  |  |  |
| Cash and cash equivalents | $ | 258,096 |  |  | $ | 115,873 |  |
| Short-term investments | 402,495 |  |  | 375,497 |  |
| Accounts receivable—Net | 116,382 |  |  | 130,471 |  |
| Inventory | 51,344 |  |  | 48,672 |  |
| Deferred tax assets | 51,297 |  |  | 50,980 |  |
| Prepaid expenses and other current assets | 16,826 |  |  | 14,053 |  |
| Total current assets | 896,440 |  |  | 735,546 |  |
| LONG-TERM INVESTMENTS | 303,168 |  |  | 351,675 |  |
| PROPERTY AND EQUIPMENT—Net | 56,812 |  |  | 36,652 |  |
| DEFERRED TAX ASSETS | 42,276 |  |  | 30,058 |  |
| GOODWILL | 2,824 |  |  | 2,872 |  |
| OTHER INTANGIBLE ASSETS—Net | 3,104 |  |  | 6,841 |  |
| OTHER ASSETS | 7,977 |  |  | 4,820 |  |
| TOTAL ASSETS | $ | 1,312,601 |  |  | $ | 1,168,464 |  |
| LIABILITIES AND STOCKHOLDERS' EQUITY |  |  |  |  |
| CURRENT LIABILITIES: |  |  |  |  |
| Accounts payable | $ | 36,520 |  |  | $ | 35,599 |  |
| Accrued liabilities | 25,662 |  |  | 27,380 |  |
| Accrued payroll and compensation | 40,692 |  |  | 34,997 |  |
| Income taxes payable | 2,490 |  |  | 21,421 |  |
| Deferred revenue | 329,132 |  |  | 293,664 |  |
| Total current liabilities | 434,496 |  |  | 413,061 |  |
| DEFERRED REVENUE | 170,880 |  |  | 138,964 |  |
| INCOME TAXES PAYABLE | 40,532 |  |  | 30,208 |  |
| OTHER LIABILITIES | 17,467 |  |  | 471 |  |
| Total liabilities | 663,375 |  |  | 582,704 |  |
| STOCKHOLDERS' EQUITY: |  |  |  |  |
| Common stock | 165 |  |  | 161 |  |
| Additional paid-in capital | 537,450 |  |  | 462,644 |  |
| Accumulated other comprehensive income | 114 |  |  | 1,092 |  |
| Retained earnings | 111,497 |  |  | 121,863 |  |
| Total stockholders’ equity | 649,226 |  |  | 585,760 |  |
| TOTAL LIABILITIES AND STOCKHOLDERS’ EQUITY | $ | 1,312,601 |  |  | $ | 1,168,464 |  |

[0001262039-14-000036:8k_2_02:53]
FORTINET, INC.

[0001262039-14-000036:8k_2_02:54]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001262039-14-000036:8k_2_02:55]
(Unaudited, in thousands, except per share amounts)

[0001262039-14-000036:8k_2_02:56]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30, 2014 |  | September 30, 2013 |  | September 30, 2014 |  | September 30, 2013 |
| REVENUE: |  |  |  |  |  |  |  |
| Product | $ | 87,731 |  |  | $ | 69,687 |  |  | $ | 249,880 |  |  | $ | 194,162 |  |
| Services and other | 105,617 |  |  | 85,012 |  |  | 296,515 |  |  | 243,785 |  |
| Total revenue | 193,348 |  |  | 154,699 |  |  | 546,395 |  |  | 437,947 |  |
| COST OF REVENUE: |  |  |  |  |  |  |  |
| Product 1 | 35,636 |  |  | 27,126 |  |  | 105,230 |  |  | 77,032 |  |
| Services and other 1 | 21,249 |  |  | 16,804 |  |  | 60,155 |  |  | 49,734 |  |
| Total cost of revenue | 56,885 |  |  | 43,930 |  |  | 165,385 |  |  | 126,766 |  |
| GROSS PROFIT: |  |  |  |  |  |  |  |
| Product | 52,095 |  |  | 42,561 |  |  | 144,650 |  |  | 117,130 |  |
| Services and other | 84,368 |  |  | 68,208 |  |  | 236,360 |  |  | 194,051 |  |
| Total gross profit | 136,463 |  |  | 110,769 |  |  | 381,010 |  |  | 311,181 |  |
| OPERATING EXPENSES: |  |  |  |  |  |  |  |
| Research and development 1 | 30,790 |  |  | 26,421 |  |  | 89,783 |  |  | 74,913 |  |
| Sales and marketing 1 | 80,433 |  |  | 56,687 |  |  | 222,576 |  |  | 162,660 |  |
| General and administrative 1 | 9,789 |  |  | 9,382 |  |  | 29,243 |  |  | 26,161 |  |
| Total operating expenses | 121,012 |  |  | 92,490 |  |  | 341,602 |  |  | 263,734 |  |
| OPERATING INCOME | 15,451 |  |  | 18,279 |  |  | 39,408 |  |  | 47,447 |  |
| INTEREST INCOME | 1,339 |  |  | 1,282 |  |  | 3,991 |  |  | 3,988 |  |
| OTHER EXPENSE—Net | (1,005 | ) |  | (1,151 | ) |  | (1,968 | ) |  | (1,036 | ) |
| INCOME BEFORE INCOME TAXES | 15,785 |  |  | 18,410 |  |  | 41,431 |  |  | 50,399 |  |
| PROVISION FOR INCOME TAXES | 11,729 |  |  | 7,381 |  |  | 22,901 |  |  | 18,142 |  |
| NET INCOME | $ | 4,056 |  |  | $ | 11,029 |  |  | $ | 18,530 |  |  | $ | 32,257 |  |
| Net income per share: |  |  |  |  |  |  |  |
| Basic | $ | 0.02 |  |  | $ | 0.07 |  |  | $ | 0.11 |  |  | $ | 0.20 |  |
| Diluted | $ | 0.02 |  |  | $ | 0.07 |  |  | $ | 0.11 |  |  | $ | 0.19 |  |
| Weighted-average shares outstanding: |  |  |  |  |  |  |  |
| Basic | 164,294 |  |  | 162,906 |  |  | 163,289 |  |  | 162,150 |  |
| Diluted | 169,727 |  |  | 168,666 |  |  | 168,735 |  |  | 168,054 |  |
| 1 Includes stock-based compensation expense as follows: |  |  |  |  |  |  |  |
| Cost of product revenue | $ | 60 |  |  | $ | 91 |  |  | $ | 351 |  |  | $ | 277 |  |
| Cost of services and other revenue | 1,522 |  |  | 1,297 |  |  | 4,214 |  |  | 3,543 |  |
| Research and development | 4,505 |  |  | 3,548 |  |  | 12,558 |  |  | 9,605 |  |
| Sales and marketing | 7,397 |  |  | 5,215 |  |  | 18,890 |  |  | 13,927 |  |
| General and administrative | 1,183 |  |  | 1,627 |  |  | 6,300 |  |  | 4,432 |  |
|  | $ | 14,667 |  |  | $ | 11,778 |  |  | $ | 42,313 |  |  | $ | 31,784 |  |

[0001262039-14-000036:8k_2_02:57]
FORTINET, INC.

[0001262039-14-000036:8k_2_02:58]
CONDENSED CONSOLIDATED STATEMENTS OF COMPREHENSIVE INCOME

[0001262039-14-000036:8k_2_02:59]
(Unaudited, in thousands)

[0001262039-14-000036:8k_2_02:60]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30, 2014 |  | September 30, 2013 |  | September 30, 2014 |  | September 30, 2013 |
| Net income | $ | 4,056 |  |  | $ | 11,029 |  |  | $ | 18,530 |  |  | $ | 32,257 |  |
| Other comprehensive (loss) income, net of taxes: |  |  |  |  |  |  |  |
| Foreign currency translation (losses) gains | (432 | ) |  | 912 |  |  | (333 | ) |  | (901 | ) |
| Unrealized (losses) gains on investments | (977 | ) |  | 600 |  |  | (993 | ) |  | (826 | ) |
| Tax benefit (provision) related to items of other comprehensive income or loss | 342 |  |  | (209 | ) |  | 348 |  |  | 289 |  |
| Other comprehensive (loss) income, net of taxes | (1,067 | ) |  | 1,303 |  |  | (978 | ) |  | (1,438 | ) |
| Comprehensive income | $ | 2,989 |  |  | $ | 12,332 |  |  | $ | 17,552 |  |  | $ | 30,819 |  |

[0001262039-14-000036:8k_2_02:61]
FORTINET, INC.

[0001262039-14-000036:8k_2_02:62]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001262039-14-000036:8k_2_02:63]
(Unaudited, in thousands)

[0001262039-14-000036:8k_2_02:64]
|  | Nine Months Ended |
|  | September 30, 2014 |  | September 30, 2013 |
| CASH FLOWS FROM OPERATING ACTIVITIES: |  |  |  |
| Net income | $ | 18,530 |  |  | $ | 32,257 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |
| Depreciation and amortization | 16,519 |  |  | 11,511 |  |
| Amortization of investment premiums | 6,680 |  |  | 8,900 |  |
| Stock-based compensation | 42,313 |  |  | 31,784 |  |
| Excess tax benefit from stock-based compensation | (4,325 | ) |  | (2,504 | ) |
| Other non-cash items—net | 3,801 |  |  | 520 |  |
| Changes in operating assets and liabilities: |  |  |  |
| Accounts receivable—Net | 13,140 |  |  | 589 |  |
| Inventory | (11,095 | ) |  | (31,344 | ) |
| Deferred tax assets | (12,186 | ) |  | (14,806 | ) |
| Prepaid expenses and other current assets | (2,781 | ) |  | 204 |  |
| Other assets | (159 | ) |  | 893 |  |
| Accounts payable | 3,806 |  |  | 11,054 |  |
| Accrued liabilities | 2,818 |  |  | 3,630 |  |
| Other liabilities | 14,350 |  |  | (999 | ) |
| Accrued payroll and compensation | 5,651 |  |  | 1,400 |  |
| Deferred revenue | 68,006 |  |  | 36,425 |  |
| Income taxes payable | (3,850 | ) |  | 11,202 |  |
| Net cash provided by operating activities | 161,218 |  |  | 100,716 |  |
| CASH FLOWS FROM INVESTING ACTIVITIES: |  |  |  |
| Purchases of investments | (388,808 | ) |  | (419,124 | ) |
| Sales of investments | 27,282 |  |  | 25,488 |  |
| Maturities of investments | 371,837 |  |  | 303,852 |  |
| Purchases of property and equipment | (26,802 | ) |  | (6,729 | ) |
| Payments made in connection with business acquisitions—net of cash acquired | (17 | ) |  | (7,635 | ) |
| Net cash used in investing activities | (16,508 | ) |  | (104,148 | ) |
| CASH FLOWS FROM FINANCING ACTIVITIES: |  |  |  |
| Proceeds from issuance of common stock | 40,529 |  |  | 24,470 |  |
| Taxes paid related to net share settlement of equity awards | (8,506 | ) |  | (966 | ) |
| Excess tax benefit from stock-based compensation | 4,325 |  |  | 2,504 |  |
| Repurchase and retirement of common stock | (38,235 | ) |  | — |  |
| Net cash (used in) provided by financing activities | (1,887 | ) |  | 26,008 |  |
| EFFECT OF EXCHANGE RATES ON CASH AND CASH EQUIVALENTS | (600 | ) |  | (1,005 | ) |
| NET INCREASE IN CASH AND CASH EQUIVALENTS | 142,223 |  |  | 21,571 |  |
| CASH AND CASH EQUIVALENTS—Beginning of period | 115,873 |  |  | 122,975 |  |
| CASH AND CASH EQUIVALENTS—End of period | $ | 258,096 |  |  | $ | 144,546 |  |

[0001262039-14-000036:8k_2_02:65]
Reconciliations of non-GAAP results of operations measures to the nearest comparable GAAP measures

[0001262039-14-000036:8k_2_02:66]
(Unaudited, in thousands)

[0001262039-14-000036:8k_2_02:67]
Reconciliation of GAAP revenue to billings

[0001262039-14-000036:8k_2_02:68]
|  | Three Months Ended |
|  | September 30, 2014 |  | September 30, 2013 |
| Total revenue | $ | 193,348 |  |  | $ | 154,699 |  |
| Add increase in deferred revenue | 19,810 |  |  | 10,491 |  |
| Total billings (Non-GAAP) | $ | 213,158 |  |  | $ | 165,190 |  |

[0001262039-14-000036:8k_2_02:69]
Reconciliation of net cash provided by operating activities to free cash flow

[0001262039-14-000036:8k_2_02:70]
|  | Three Months Ended |
|  | September 30, 2014 |  | September 30, 2013 |
| Net cash provided by operating activities | $ | 56,518 |  |  | $ | 25,384 |  |
| Less purchases of property and equipment | (5,780 | ) |  | (3,160 | ) |
| Free cash flow (Non-GAAP) | $ | 50,738 |  |  | $ | 22,224 |  |

[0001262039-14-000036:8k_2_02:71]
Reconciliation of non-GAAP results of operations to the nearest comparable GAAP measures

[0001262039-14-000036:8k_2_02:72]
(Unaudited, in thousands, except per share amounts)

[0001262039-14-000036:8k_2_02:73]
Reconciliation of GAAP to Non-GAAP operating income, operating margin, net income and diluted net income per share

[0001262039-14-000036:8k_2_02:74]
|  | Three Months Ended September 30, 2014 |  | Three Months Ended September 30, 2013 |
|  | GAAP Results |  | Adjustments |  | Non-GAAP Results |  | GAAP Results |  | Adjustments |  | Non-GAAP Results |
| Operating income | $ | 15,451 |  |  | $ | 14,911 |  | (a) | $ | 30,362 |  |  | $ | 18,279 |  |  | $ | 12,201 |  | (b) | $ | 30,480 |  |
| Operating margin | 8 | % |  |  |  | 16 | % |  | 12 | % |  |  |  | 20 | % |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation expense |  |  | 14,667 |  |  |  |  |  |  | 11,778 |  |  |  |
| Amortization expense of certain intangible assets |  |  | 244 |  |  |  |  |  |  | 423 |  |  |  |
| Tax adjustment |  |  | 985 |  | (c) |  |  |  |  | (2,721 | ) | (c) |  |
| Net income | $ | 4,056 |  |  | $ | 15,896 |  |  | $ | 19,952 |  |  | $ | 11,029 |  |  | $ | 9,480 |  |  | $ | 20,509 |  |
| Diluted net income per share | $ | 0.02 |  |  |  |  | $ | 0.12 |  |  | $ | 0.07 |  |  |  |  | $ | 0.12 |  |
| Shares used in diluted net income per share calculations | 169,727 |  |  |  |  | 169,727 |  |  | 168,666 |  |  |  |  | 168,666 |  |

[0001262039-14-000036:8k_2_02:75]
(a) To exclude $14.7 million of stock-based compensation expense and $0.2 million of amortization expense of certain intangible assets in the three months ended September 30, 2014.

[0001262039-14-000036:8k_2_02:76]
(b) To exclude $11.8 million of stock-based compensation expense and $0.4 million of amortization expense of certain intangible assets in the three months ended September 30, 2013.

[0001262039-14-000036:8k_2_02:77]
(c)  Non-GAAP financial information is adjusted to achieve an overall 35 percent and 33 percent effective tax rate on a non-GAAP basis, which differs from the GAAP effective tax rate, in fiscal 2014 and 2013, respectively.
