# FTNT MD&A — 0001262039-22-000038


## mdna

[0001262039-22-000038:mdna:1]
[same as prior period, unchanged from 0001262039-22-000029:mdna:1]

[0001262039-22-000038:mdna:2]
[same as prior period, unchanged from 0001262039-22-000029:mdna:2]

[0001262039-22-000038:mdna:3]
•the duration and impact of the COVID-19 pandemic, including various COVID-19 variants and the implementation of “return to office” plans;

[0001262039-22-000038:mdna:4]
[same as prior period, unchanged from 0001262039-22-000029:mdna:4]

[0001262039-22-000038:mdna:5]
•effects of increased inflation and rising interest rates in many geographies and changes in currency exchange rates and currency regulations;

[0001262039-22-000038:mdna:6]
[same as prior period, unchanged from 0001262039-22-000029:mdna:6]

[0001262039-22-000038:mdna:7]
[same as prior period, unchanged from 0001262039-22-000029:mdna:7]

[0001262039-22-000038:mdna:8]
[same as prior period, unchanged from 0001262039-22-000029:mdna:8]

[0001262039-22-000038:mdna:9]
•the impact of macro-economic, geopolitical factors and other disruption on our manufacturing or sales, including the impact of the COVID-19 pandemic and other public health issues, wars and natural disasters;

[0001262039-22-000038:mdna:10]
[same as prior period, unchanged from 0001262039-22-000029:mdna:12]

[0001262039-22-000038:mdna:11]
[same as prior period, unchanged from 0001262039-22-000029:mdna:13]

[0001262039-22-000038:mdna:12]
•growing our solution sales through channel partners to businesses, service providers and government organizations, our ability to execute these sales and the complexity of providing solutions to all segments (including the increased competition and unpredictability of timing associated with sales to larger enterprises), the impact of sales to these organizations on our long-term growth, expansion and operating results, and the effectiveness of our sales organization;

[0001262039-22-000038:mdna:13]
[same as prior period, unchanged from 0001262039-22-000029:mdna:15]

[0001262039-22-000038:mdna:14]
[same as prior period, unchanged from 0001262039-22-000029:mdna:16]

[0001262039-22-000038:mdna:15]
[same as prior period, unchanged from 0001262039-22-000029:mdna:17]

[0001262039-22-000038:mdna:16]
[same as prior period, unchanged from 0001262039-22-000029:mdna:18]

[0001262039-22-000038:mdna:17]
[same as prior period, unchanged from 0001262039-22-000029:mdna:19]

[0001262039-22-000038:mdna:18]
[same as prior period, unchanged from 0001262039-22-000029:mdna:20]

[0001262039-22-000038:mdna:19]
•expectations regarding uncertain tax benefits and our effective domestic and global tax rates, and the impact of the Tax Cuts and Jobs Act of 2017, the Coronavirus Aid, Relief, and Economic Security Act (the “CARES Act”) of 2020 and the Inflation Reduction Act of 2022;

[0001262039-22-000038:mdna:20]
[same as prior period, unchanged from 0001262039-22-000029:mdna:21]

[0001262039-22-000038:mdna:21]
[same as prior period, unchanged from 0001262039-22-000029:mdna:23]

[0001262039-22-000038:mdna:22]
[same as prior period, unchanged from 0001262039-22-000029:mdna:24]

[0001262039-22-000038:mdna:23]
[same as prior period, unchanged from 0001262039-22-000029:mdna:25]

[0001262039-22-000038:mdna:24]
•statements regarding expected outcomes and liabilities in litigation;

[0001262039-22-000038:mdna:25]
[same as prior period, unchanged from 0001262039-22-000029:mdna:27]

[0001262039-22-000038:mdna:26]
[same as prior period, unchanged from 0001262039-22-000029:mdna:28]

[0001262039-22-000038:mdna:27]
[same as prior period, unchanged from 0001262039-22-000029:mdna:29]

[0001262039-22-000038:mdna:28]
[same as prior period, unchanged from 0001262039-22-000029:mdna:30]

[0001262039-22-000038:mdna:29]
[same as prior period, unchanged from 0001262039-22-000029:mdna:31]

[0001262039-22-000038:mdna:30]
Our product offerings consist of our Core Platform (previously referred to as FortiGate network security physical and virtual products) and our Enhanced Platform Technologies (previously referred to as Platform Extension). The extended platform includes Secure Networking (Secure Switching, Access Points, 5G and Network Access Control), Network and Security Operations (Management, Analytics, Security Information and Event Management, Security Operations, Orchestration and Response and Email Security), Endpoint Security (Enhanced Detection and Response and Identity) and Cloud Security (Web Application Firewall).

[0001262039-22-000038:mdna:31]
Our cloud- and hosted- Enhanced Platform Technology products and services include sandboxing, endpoint detection and response (“EDR”), email security, web application and application programming interface (“API”) security, cloud networking security and cloud-native protection as well as management and analytics.

[0001262039-22-000038:mdna:32]
Our FortiGuard security subscription services are enabled by FortiGuard Labs, which provides threat research and artificial intelligence capabilities from a cloud network to deliver coordinated protection for the ever-expanding attack surface through Core Platform appliance and virtual machine as well as all Enhanced Platform Technology products that are registered by the end-customer.

[0001262039-22-000038:mdna:33]
Our FortiCare support services provide both technical support and professional services to help our customers deploy, maintain, and operationalize Fortinet’s Core Platform and Enhanced Platform Technology products and services.

[0001262039-22-000038:mdna:34]
[same as prior period, unchanged from 0001262039-22-000029:mdna:36]

[0001262039-22-000038:mdna:35]
[same as prior period, unchanged from 0001262039-22-000029:mdna:37]

[0001262039-22-000038:mdna:36]
[same as prior period, unchanged from 0001262039-22-000029:mdna:38]

[0001262039-22-000038:mdna:37]
Our FortiOS operating system provides the foundation for the operation of all Core Platform and Enhanced Platform Technology products, whether physical, virtual, private- or public-cloud based. FortiOS directs the operations of processors and SPUs and provides system management functions. We make regular updates to FortiOS available through our FortiCare support services.

[0001262039-22-000038:mdna:38]
Networking functionality and security capabilities are integrated into the FortiOS operating system to run both the Core Platform and Enhanced Platform Technology capabilities of Fortinet’s cybersecurity mesh architecture (“Fortinet Security Fabric”). This approach to security combines discrete security solutions together into an integrated operating system which provides centralized management, visibility, automation and intelligence sharing to simplify operations and respond rapidly to threats.

[0001262039-22-000038:mdna:39]
[same as prior period, unchanged from 0001262039-22-000029:mdna:41]

[0001262039-22-000038:mdna:40]
•Secure Networking—Our Security-Driven Networking solutions enables the convergence of networking and security across all edges to provide next-generation firewall (“NGFW”), SD-WAN, LAN Edge (Wi-Fi and switch) and secure access service edge (“SASE”). We derive a majority of product sales from our Core Platform network security appliances. Core Platform network security appliances include a broad set of built-in security and networking features and functionalities, including firewall, next-generation firewall, secure web gateway, secure sockets layer (“SSL”) inspection, SD-WAN, Intrusion Prevention system (“IPS”), sandboxing, data leak prevention, virtual private network (“VPN”), switch and wireless controller and wide area network (“WAN”) edge. Our network security appliances are managed by our FortiOS network operating system, which provides the foundation for Core Platform security functions. We enhance the performance of our network security appliances from branch to data center by designing and implementing SPUs technology within our appliances, enabling us to add security and network functionality with minimal impact to network throughput performance. Along with our secure Wi-Fi access points and switches, Fortinet helps organizations secure their networks across campuses, branches and work-from-home deployments.

[0001262039-22-000038:mdna:41]
•Zero Trust Access—Fortinet’s Enhanced Platform Technology products and services extend beyond the network to create a cybersecurity mesh architecture to cover other attack vectors. Our Zero Trust Access solutions enable customers to know and control who and what is on their network, in addition to providing security for work from anywhere (“WFA”). Zero Trust Access solutions include FortiNAC, FortiAuthenticator, FortiClient and FortiToken. Additionally, the proliferation of operational technology (“OT”) and internet of things (“IoT”) devices has generated new opportunities for us to grow our business. Our network access control solutions provide visibility, control and automated event responses in order to secure OT and IoT devices.

[0001262039-22-000038:mdna:42]
•Cloud Security—We help customers connect securely to and across their individual, hybrid cloud, multi-cloud and virtualized data center environments by offering security through our virtual firewall and other software products and through integrated cloud-native capabilities with major cloud platforms. Our public and private cloud security solutions, including virtual appliances and hosted solutions, bring our Enhanced Platform Technology products and services into and across cloud environments, delivering security that follows their applications and data. Our Secure SD-WAN for Multi-Cloud solution automates deployment of an overlay network across different cloud networks and offers visibility, control and centralized management that integrates functionality across multiple cloud environments. Our Cloud Security portfolio also secures applications, including email and web applications and APIs and helps organizations better operationalize their cloud security with cloud-native protection. Fortinet cloud security offerings are available for deployment in major public and private cloud environments, including Alibaba Cloud, Amazon Web Services, Google Cloud, IBM Cloud, Microsoft Azure, Oracle Cloud and VMWare Cloud. We also offer managed IPS and web application firewall (“WAF”) rules delivered by FortiGuard Labs as an overlay service to native security offerings offered by Amazon Web Services.

[0001262039-22-000038:mdna:43]
[same as prior period, unchanged from 0001262039-22-000029:mdna:45]

[0001262039-22-000038:mdna:44]
[same as prior period, unchanged from 0001262039-22-000029:mdna:46]

[0001262039-22-000038:mdna:45]
•Security as a Service—Our customers purchase our natively integrated FortiGuard security subscription services as an add-on to products and solutions across the Enhanced Platform Technology products and services with the goal of receiving real-time threat intelligence and protection updates. The rich set of FortiGuard security subscription services is built from the ground up to provide comprehensive protection for users and applications, including market leading offerings for IPS, Web, video and DNS filtering, AV and cloud sandbox as well as OT and IoT Security. The FortiGuard security subscription services are provided from our FortiGuard Labs and cloud-delivered to provide real-time unified protection across network endpoint and cloud.

[0001262039-22-000038:mdna:46]
•Support and Professional Services—Fortinet offers technical support, FortiOS updates and extended product warranty through our FortiCare support services. In addition to our technical support services, we offer a range of advanced services, including premium support, professional services and expedited warranty replacement. Our advanced support service offerings include technical account managers that act as a single point of contact and customer advocate within Fortinet. Our professional service offerings include resident engineers and professional service consultants for implementations or trainings.

[0001262039-22-000038:mdna:47]
[same as prior period, unchanged from 0001262039-22-000029:mdna:49]

[0001262039-22-000038:mdna:48]
•Total revenue was $1.15 billion and $3.13 billion during the three and nine months ended September 30, 2022, an increase of 33% and 32%, respectively, compared to $867.2 million and $2.38 billion in the same periods last year. Product revenue was $468.7 million and $1.24 billion during the three and nine months ended September 30, 2022, an increase of 39% and 42%, respectively, compared to $337.1 million and $876.1 million in the same periods last year. Service revenue was $680.8 million and $1.89 billion during the three and nine months ended September 30, 2022, an increase of 28% and 26%, respectively, compared to $530.1 million and $1.50 billion in the same periods last year.

[0001262039-22-000038:mdna:49]
•Total gross profit was $866.5 million and $2.35 billion during the three and nine months ended September 30, 2022, an increase of 32% and 29%, respectively, compared to $656.0 million and $1.82 billion in the same periods last year.

[0001262039-22-000038:mdna:50]
•Cash, cash equivalents, short-term and long-term investments and marketable equity securities were $1.81 billion as of September 30, 2022.

[0001262039-22-000038:mdna:51]
•During the nine months ended September 30, 2022, we repurchased 36.0 million shares of common stock under our Share Repurchase Program (the “Repurchase Program”), for a total purchase price of $1.99 billion.

[0001262039-22-000038:mdna:52]
•Deferred revenue was $4.19 billion as of September 30, 2022, an increase of $740.6 million, or 21%, compared to $3.45 billion as of December 31, 2021 and an increase of $1.09 billion, or 35%, compared to $3.11 billion as of September 30, 2021. Deferred revenue was $3.11 billion as of September 30, 2021, an increase of $501.1 million, or 19%, compared to $2.61 billion as of December 31, 2020 and an increase of $714.4 million, or 30%, compared to $2.39 billion as of September 30, 2020.

[0001262039-22-000038:mdna:53]
•Short-term deferred revenue was $2.13 billion as of September 30, 2022, an increase of $351.6 million, or 20%, compared to $1.78 billion as of December 31, 2021 and an increase of $512.9 million, or 32%, compared to $1.62 billion as of September 30, 2021. Short-term deferred revenue was $1.62 billion as of September 30, 2021, as increase of $223.3 million, or 16%, compared to $1.39 billion as of December 31, 2020 and an increase of $316.1 million, or 24%, compared to $1.30 billion as of September 30, 2020.

[0001262039-22-000038:mdna:54]
•We generated cash flows from operating activities of $1.20 billion during the nine months ended September 30, 2022, an increase of $69.6 million, or 6%, compared to the same period last year.

[0001262039-22-000038:mdna:55]
On a geographic basis, revenue continues to be diversified, which remains a key strength of our business. During the three months ended September 30, 2022, the Americas region, the Europe, Middle East and Africa (“EMEA”) region and the Asia Pacific (“APAC”) region contributed 41%, 38% and 21% of our total revenue, respectively, and increased by 34%, 37% and 23% compared to the same period last year, respectively. During the nine months ended September 30, 2022, the Americas region, the EMEA region and the APAC region contributed 40%, 38% and 22% of our total revenue, respectively, and increased by 29%, 31% and 39% compared to the same period last year, respectively.

[0001262039-22-000038:mdna:56]
Our revenue growth was driven by strong product revenue performance. Product revenue grew 39% and 42% during the three and nine months ended September 30, 2022, respectively, compared to the same periods last year. Product revenue growth was consistent with an elevated cyber threat landscape and changes in our pricing model. Core Platform products

[0001262039-22-000038:mdna:57]
30

[0001262039-22-000038:mdna:58]
accounted for more than 40% of the product revenue growth during the three months ended September 30, 2022. While Secure SD-WAN contributed to product revenue growth, a main driver was the strong demand for the wide range of other operating system capabilities embedded in the Core Platform products. We experienced strong product revenue growth across many of our Enhanced Platform Technology products, including our OT solutions, secure access products and software licenses. Service revenue growth of 28% and 26% during the three and nine months ended September 30, 2022, respectively, compared to the same periods last year, was driven by the strength of our FortiCare technical support and other service revenue which grew 28% and 27%, respectively, and of FortiGuard and other security subscription revenue, which grew 29% and 25%, respectively.

[0001262039-22-000038:mdna:59]
Our billings were diversified on a geographic basis. During the three months ended September 30, 2022, approximately 45% of our billings in the aggregate were from over 100 countries that each individually contributed less than 3% of our billings.

[0001262039-22-000038:mdna:60]
Operating expenses as a percentage of revenue decreased by 4 and 3 percentage points during the three and nine months ended September 30, 2022, respectively, compared to the same periods last year. Headcount increased to 12,091 employees and contractors as of September 30, 2022, a 19% increase compared to 10,195 as of December 31, 2021.

[0001262039-22-000038:mdna:61]
[same as prior period, unchanged from 0001262039-22-000029:mdna:62]

[0001262039-22-000038:mdna:62]
The United States and the global community we serve have faced unprecedented challenges posed by the COVID-19 pandemic, including the various COVID-19 variants. In response to the pandemic, we undertook a number of actions to protect our employees, including restricting travel and directing many of our employees to work from home. In certain geographies, we have started to transition back to an in-person working mode, allowing increasing numbers of employees to work from our offices with reasonable precautions and, in all cases, subject to abiding by local legal restrictions. We intend to continue to monitor and abide by local employee health and safety protocols and other regulations as applicable to each local office.

[0001262039-22-000038:mdna:63]
While the broader implications of the COVID-19 pandemic on our employees and overall financial performance continue to evolve, we have seen certain impacts on our business and operations, results of operations, financial condition, cash flows, liquidity and capital and financial resources as of and during the three and nine months ended September 30, 2022. Conversely, some aspects of our business do not appear to have been significantly affected. During the three and nine months ended September 30, 2022, we have observed the following:

[0001262039-22-000038:mdna:64]
[same as prior period, unchanged from 0001262039-22-000029:mdna:65]

[0001262039-22-000038:mdna:65]
•In many countries, our employees’ ability to travel has been reduced and certain in-person sales and marketing events or meetings that would normally have been held were canceled, postponed or converted into virtual events. However, as certain country’s restrictions continued to ease, we have started to see an increase in expenses related to travel and marketing events. Although we cannot predict if or when such expenses will return to pre-pandemic levels, as of September 30, 2022, we have started to see an increase in such expenses as compared to the same period last year.

[0001262039-22-000038:mdna:66]
[same as prior period, unchanged from 0001262039-22-000029:mdna:67]

[0001262039-22-000038:mdna:67]
•Our days sales outstanding increased to 75 days in the third quarter of 2022, compared to 63 days in the same period last year, primarily due to the sales linearity. The accounts receivable allowance for credit losses was $3.7 million as of September 30, 2022, increased by $1.3 million compared to $2.4 million as of December 31, 2021, primarily due to an increase in past due invoices over 60 and 90 days.

[0001262039-22-000038:mdna:68]
Going forward, the situation remains uncertain, rapidly changing and hard to predict, and the COVID-19 pandemic may have a material negative impact on our future periods. If we experience component, shipping, inventory challenges or customer payment, it will negatively impact billings and product revenue in the current quarter and FortiGuard and FortiCare service revenues in subsequent quarters, as we sell annual and multi-year service contracts that are recognized ratably over the contractual service term, generally starting on the contract registration date. In addition, the broader implications of the pandemic on our business and operations and our financial results, including the extent to which the effects of the pandemic will impact future results and growth in the cybersecurity industry, remain uncertain. The extent of the impact of the COVID-19 pandemic on our operational and financial performance will depend on ongoing developments, including the duration and spread of the virus and its variants, the impact on our end-customers’ spending, the volume of sales and length of our sales

[0001262039-22-000038:mdna:69]
[same as prior period, unchanged from 0001262039-22-000029:mdna:70]

[0001262039-22-000038:mdna:70]
cycles, the impact on our partners, suppliers, and employees, actions that may be taken by governmental authorities and other factors identified in Part II, Item 1A “Risk Factors” in this Form 10-Q. Given the dynamic nature of these circumstances, the full impact of the COVID-19 pandemic on our business and operations, results of operations, financial condition, cash flows, liquidity and capital and financial resources cannot be reasonably estimated at this time.

[0001262039-22-000038:mdna:71]
War in Ukraine

[0001262039-22-000038:mdna:72]
Due to the war in Ukraine and the resulting sanctions and other actions against Russia and Belarus and due to inflation and the economic downturn and possible recession, there has been uncertainty and disruption in the global economy. On March 7, 2022, we announced that we were suspending sales, support, security updates and other operations in Russia.

[0001262039-22-000038:mdna:73]
Although the Russian war against Ukraine did not have a material adverse impact on our revenue or other financial results for the three and nine months ended September 30, 2022, at this time we are unable to fully assess the aggregate impact it will have on our business in future periods due to various uncertainties, which include, but are not limited to, the duration of the war, its effect on the economy, its impact to the businesses of our customers and distributors, actions that may be taken by governmental authorities related to the war, and other factors identified in Part II, Item 1A, “Risk Factors” in this Quarterly Report, including the risk factor titled “The war in Ukraine and our suspension of operations in Russia have affected and may continue to affect our business.”

[0001262039-22-000038:mdna:74]
[same as prior period, unchanged from 0001262039-22-000029:mdna:75]

[0001262039-22-000038:mdna:75]
We typically sell our security solutions to distributors that sell to networking security focused resellers and to service providers and managed security service providers (“MSSPs”), who, in turn, sell to end-customers or use our products and services to provide hosted solutions to other enterprises. At times, we also sell directly to large service providers and major systems integrators. Our end-customers are located in over 100 countries and include small, medium and large enterprises and government organizations across a wide range of industries, including education, financial services, government, healthcare, manufacturing, retail, technology and telecommunications. An end-customer deployment may involve as few as one or as many as thousands of Core Platform products as well as Enhanced Platform Technology products, depending on the end-customer’s size and security requirements.

[0001262039-22-000038:mdna:76]
We also offer our products hosted in our own data centers and through co-locations and major cloud providers, and have recognized revenue on a usage basis from our data centers as well as Alibaba Cloud, Amazon Web Services, Google Cloud, IBM Cloud, Microsoft Azure and Oracle Cloud. We have also recognized revenue from customers who deploy our products in a bring-your-own-license (“BYOL”) arrangement in private clouds or at cloud providers. In a BYOL arrangement, a customer purchases a software license from us through our channel partners and deploys the software in a cloud provider’s environment. Similarly, customers may purchase such a license from us and deploy it in third-party clouds or in their private cloud.

[0001262039-22-000038:mdna:77]
[same as prior period, unchanged from 0001262039-22-000029:mdna:78]

[0001262039-22-000038:mdna:78]
[same as prior period, unchanged from 0001262039-22-000029:mdna:79]

[0001262039-22-000038:mdna:79]
[same as prior period, unchanged from 0001262039-22-000029:mdna:80]

[0001262039-22-000038:mdna:80]
[same as prior period, unchanged from 0001262039-22-000029:mdna:81]

[0001262039-22-000038:mdna:81]
[same as prior period, unchanged from 0001262039-22-000029:mdna:82]

[0001262039-22-000038:mdna:82]
|  | Three Months Ended Or As Of |
|  | September 30, 2022 |  | September 30, 2021 |
|  | (in millions) |
| Revenue | $ | 1,149.5 |  |  | $ | 867.2 |  |
| Deferred revenue | $ | 4,193.5 |  |  | $ | 3,106.4 |  |
| Billings (non-GAAP) | $ | 1,411.0 |  |  | $ | 1,064.1 |  |
| Net cash provided by operating activities | $ | 483.0 |  |  | $ | 398.8 |  |
| Free cash flow (non-GAAP) | $ | 395.2 |  |  | $ | 329.8 |  |

[0001262039-22-000038:mdna:83]
Deferred revenue. Our deferred revenue consists of amounts that have been invoiced but that have not yet been recognized as revenue. The majority of our deferred revenue balance consists of the unrecognized portion of service revenue from FortiGuard and other security subscription and FortiCare technical support service contracts, which is recognized as revenue ratably over the contractual service period. We monitor our deferred revenue balance, short term and total deferred revenue growth and the mix of short-term and long-term deferred revenue because deferred revenue represents a significant portion of free cash flow and of revenue to be recognized in future periods. Deferred revenue was $4.19 billion as of September 30, 2022, an increase of $740.6 million, or 21%, from December 31, 2021. Short term deferred revenue was $2.13 billion as of September 30, 2022, an increase of $351.6 million, or 20%, from December 31, 2021.

[0001262039-22-000038:mdna:84]
Billings (non-GAAP). We define billings as revenue recognized in accordance with GAAP plus the change in deferred revenue from the beginning to the end of the period, less any deferred revenue balances acquired from business combination(s) during the period. We consider billings to be a useful metric for management and investors because billings drive current and future revenue, which is an important indicator of the health and viability of our business. There are several limitations related to the use of billings instead of GAAP revenue. First, billings include amounts that have not yet been recognized as revenue and are impacted by the term of FortiGuard security and FortiCare and other support agreements. Second, we may calculate billings in a manner that is different from peer companies that report similar financial measures. Management accounts for these limitations by providing specific information regarding GAAP revenue and evaluating billings together with GAAP revenue. Total billings were $1.41 billion for the three months ended September 30, 2022, an increase of 33% compared to $1.06 billion in the same period last year.

[0001262039-22-000038:mdna:85]
[same as prior period, unchanged from 0001262039-22-000029:mdna:86]

[0001262039-22-000038:mdna:86]
|  | Three Months Ended |
|  | September 30, 2022 |  | September 30, 2021 |
|  | (in millions) |
| Billings: |  |  |  |
| Revenue | $ | 1,149.5 |  |  | $ | 867.2 |  |
| Add: Change in deferred revenue | 261.5 |  |  | 201.0 |  |
| Less: Deferred revenue balance acquired in business combination | — |  |  | (4.1) |  |
| Total billings (non-GAAP) | $ | 1,411.0 |  |  | $ | 1,064.1 |  |

[0001262039-22-000038:mdna:87]
[same as prior period, unchanged from 0001262039-22-000029:mdna:88]

[0001262039-22-000038:mdna:88]
[same as prior period, unchanged from 0001262039-22-000029:mdna:89]

[0001262039-22-000038:mdna:89]
[same as prior period, unchanged from 0001262039-22-000029:mdna:90]

[0001262039-22-000038:mdna:90]
|  | Three Months Ended |
|  | September 30, 2022 |  | September 30, 2021 |
|  | (in millions) |
| Free Cash Flow: |  |  |  |
| Net cash provided by operating activities | $ | 483.0 |  |  | $ | 398.8 |  |
| Less: Purchases of property and equipment | (87.8) |  |  | (69.0) |  |
| Free cash flow (non-GAAP) | $ | 395.2 |  |  | $ | 329.8 |  |
| Net cash provided (used) in investing activities | $ | 297.8 |  |  | $ | (307.5) |  |
| Net cash used in financing activities | $ | (526.6) |  |  | $ | (118.7) |  |

[0001262039-22-000038:mdna:91]
[same as prior period, unchanged from 0001262039-22-000029:mdna:92]

[0001262039-22-000038:mdna:92]
[same as prior period, unchanged from 0001262039-22-000029:mdna:93]

[0001262039-22-000038:mdna:93]
Except as noted below, there were no material changes to our critical accounting policies and estimates as of and for the three and nine months ended September 30, 2022, as compared to the critical accounting policies and estimates described in our Annual Report on Form 10-K filed with the SEC on February 25, 2022 (the “Form 10-K”).

[0001262039-22-000038:mdna:94]
[same as prior period, unchanged from 0001262039-22-000029:mdna:95]

[0001262039-22-000038:mdna:95]
[same as prior period, unchanged from 0001262039-22-000029:mdna:96]

[0001262039-22-000038:mdna:96]
[same as prior period, unchanged from 0001262039-22-000029:mdna:97]

[0001262039-22-000038:mdna:97]
[same as prior period, unchanged from 0001262039-22-000029:mdna:98]

[0001262039-22-000038:mdna:98]
[same as prior period, unchanged from 0001262039-22-000029:mdna:99]

[0001262039-22-000038:mdna:99]
Three Months Ended September 30, 2022 and 2021

[0001262039-22-000038:mdna:100]
[same as prior period, unchanged from 0001262039-22-000029:mdna:101]

[0001262039-22-000038:mdna:101]
|  | Three Months Ended |  |  |  |  |
| September 30,2022 |  | September 30,2021 |  |  |  |  |
| Amount |  | % ofRevenue |  | Amount |  | % ofRevenue |  | Change |  | % Change |
| (in millions, except percentages) |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 468.7 |  |  | 41 | % |  | $ | 337.1 |  |  | 39 | % |  | $ | 131.6 |  |  | 39 | % |
| Service | 680.8 |  |  | 59 |  |  | 530.1 |  |  | 61 |  |  | 150.7 |  |  | 28 |  |
| Total revenue | $ | 1,149.5 |  |  | 100 | % |  | $ | 867.2 |  |  | 100 | % |  | $ | 282.3 |  |  | 33 | % |
| Revenue by geography: |  |  |  |  |  |  |  |  |  |  |  |
| Americas | $ | 467.6 |  |  | 41 | % |  | $ | 350.1 |  |  | 41 | % |  | $ | 117.5 |  |  | 34 | % |
| EMEA | 443.9 |  |  | 38 |  |  | 323.2 |  |  | 37 |  |  | 120.7 |  |  | 37 |  |
| APAC | 238.0 |  |  | 21 |  |  | 193.9 |  |  | 22 |  |  | 44.1 |  |  | 23 |  |
| Total revenue | $ | 1,149.5 |  |  | 100 | % |  | $ | 867.2 |  |  | 100 | % |  | $ | 282.3 |  |  | 33 | % |

[0001262039-22-000038:mdna:102]
Total revenue increased by $282.3 million, or 33%, during the three months ended September 30, 2022 compared to the same period last year. We continued to experience significant organic revenue growth (i.e., revenue growth excluding attribution from recent acquisitions) with diversification of revenue geographically, and across both customers and industries. Revenue from all regions grew, with EMEA contributing the largest portion of the increase on an absolute dollar basis and on a percentage basis.

[0001262039-22-000038:mdna:103]
Product revenue increased by $131.6 million, or 39%, during the three months ended September 30, 2022 compared to the same period last year. Product revenue growth was consistent with an elevated cyber threat landscape and included the benefit of certain pricing actions. Core Platform products accounted for more than 40% of the product revenue growth in the three months ended September 30, 2022. While Secure SD-WAN and OT contributed significantly to product revenue growth, the main driver was the strong demand for the wide range of other operating system capabilities embedded in the Core Platform products. We also experienced strong revenue growth across many Enhanced Platform Technology products.

[0001262039-22-000038:mdna:104]
Service revenue increased by $150.7 million, or 28%, during the three months ended September 30, 2022 compared to the same period last year. FortiGuard security subscription and FortiCare and other technical support and other revenues increased by $82.4 million, or 29%, and by $68.3 million, or 28%, respectively, during the three months ended September 30, 2022 compared to the same period last year. The increases were primarily due to the recognition of revenue from our growing deferred revenue balance related to FortiGuard and other security subscriptions delivered to on-premise and cloud-based environments as well as FortiCare and other technical support, including our customers moving to higher-tier support offerings and the early effects of certain pricing actions.

[0001262039-22-000038:mdna:105]
Of the service revenue recognized during the three months ended September 30, 2022, 88% was included in the deferred revenue balance as of June 30, 2022. Of the service revenue recognized during the three months ended September 30, 2021, 89% was included in the deferred revenue balance as of June 30, 2021. We expect service revenue growth will continue to increase through the remainder of 2022, as our business is expected to grow and as service revenue benefits from previous pricing actions. However, there are risks to service revenue growth rates, including customers reducing their spending, supply chain constraints, customers taking longer to buy their service, or other reasons.

[0001262039-22-000038:mdna:106]
[same as prior period, unchanged from 0001262039-22-000029:mdna:107]

[0001262039-22-000038:mdna:107]
|  | Three Months Ended |  |  |  |  |
| September 30,2022 |  | September 30,2021 |  | Change |  | % Change |
| (in millions, except percentages) |
| Cost of revenue: |  |  |  |  |  |  |  |
| Product | $ | 185.2 |  |  | $ | 134.3 |  |  | $ | 50.9 |  |  | 38 | % |
| Service | 97.8 |  |  | 76.9 |  |  | 20.9 |  |  | 27 |  |
| Total cost of revenue | $ | 283.0 |  |  | $ | 211.2 |  |  | $ | 71.8 |  |  | 34 | % |
| Gross margin (%): |  |  |  |  |  |  |  |
| Product | 60.5 | % |  | 60.2 | % |  |  |  |  |
| Service | 85.6 |  |  | 85.5 |  |  |  |  |  |
| Total gross margin | 75.4 | % |  | 75.6 | % |  |  |  |  |

[0001262039-22-000038:mdna:108]
Total gross margin decreased by 0.2 percentage points during the three months ended September 30, 2022 compared to the same period last year, primarily driven by a change in revenue mix to lower margin product revenue from higher margin service revenue and the consolidation of Alaxala, partially offset by favorable impact of foreign currency fluctuations. Revenue mix shifted by 2 percentage points from service revenue to product revenue, as a percentage of total revenue.

[0001262039-22-000038:mdna:109]
Product gross margin increased by 0.3 percentage points during the three months ended September 30, 2022 compared to the same period last year. The increase in product margin is driven by higher average selling prices, partially offset by higher expedite fees and other product costs due to supply chain constraints and the consolidation of Alaxala. Cost of product revenue was comprised primarily of third-party contract manufacturers’ costs and the costs of materials used in production.

[0001262039-22-000038:mdna:110]
Service gross margin increased by 0.1 percentage points during the three months ended September 30, 2022 compared to the same period last year. Cost of service revenue was comprised primarily of personnel and data center costs. The increase in service gross margin was primarily impacted by favorable impact of foreign currency fluctuations and higher average selling prices, partially offset by our data center expansion, increased labor cost and our consolidation of Alaxala.

[0001262039-22-000038:mdna:111]
[same as prior period, unchanged from 0001262039-22-000029:mdna:112]

[0001262039-22-000038:mdna:112]
|  | Three Months Ended |  | Change |  | % Change |
| September 30,2022 |  | September 30,2021 |  |
| Amount |  | % ofRevenue |  | Amount |  | % ofRevenue |  |
| (in millions, except percentages) |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | $ | 134.3 |  |  | 12 | % |  | $ | 107.8 |  |  | 12 | % |  | $ | 26.5 |  |  | 25 | % |
| Sales and marketing | 427.1 |  |  | 37 |  |  | 347.1 |  |  | 40 |  |  | 80.0 |  |  | 23 |  |
| General and administrative | 40.7 |  |  | 4 |  |  | 35.8 |  |  | 4 |  |  | 4.9 |  |  | 14 |  |
| Gain on IP matter | (1.1) |  |  | — |  |  | (1.1) |  |  | — |  |  | — |  |  | — |  |
| Total operating expenses | $ | 601.0 |  |  | 52 | % |  | $ | 489.6 |  |  | 56 | % |  | $ | 111.4 |  |  | 23 | % |
| Percentages have been rounded for presentation purposes and may differ from unrounded results. |

[0001262039-22-000038:mdna:113]
[same as prior period, unchanged from 0001262039-22-000029:mdna:114]

[0001262039-22-000038:mdna:114]
Research and development expense increased by $26.5 million, or 25%, during the three months ended September 30, 2022 compared to the same period last year, primarily due to an increase of $15.8 million in personnel-related costs as a result of increased headcount to support the development of new products and continued enhancements to our existing products. In addition, we incurred increases in depreciation and other occupancy costs of $6.1 million, and an increase of $3.2 million of product development costs, such as third-party testing and prototypes, partially offset by the favorable impact of foreign currency fluctuations. We currently intend to continue to invest in our research and development organization, and expect research and development expense to increase in absolute dollars during the remainder of 2022.

[0001262039-22-000038:mdna:115]
[same as prior period, unchanged from 0001262039-22-000029:mdna:117]

[0001262039-22-000038:mdna:116]
Sales and marketing expense increased by $80.0 million, or 23%, during the three months ended September 30, 2022 compared to the same period last year, primarily due to an increase of $46.4 million in personnel-related costs. We  significantly increased our sales capacity, including newer non-tenured sales people. The increase in headcount is expected to help drive global market revenue increases. In addition, we incurred increases in marketing-related expense of $13.8 million, travel expense of $11.4 million and depreciation and other occupancy expense of $5.5 million, partially offset by the favorable impact of foreign currency fluctuations. We currently intend to continue to make investments in sales and marketing resources, which are critical to support our future growth, and expect sales and marketing expense to increase in absolute dollars during the remainder of 2022.

[0001262039-22-000038:mdna:117]
[same as prior period, unchanged from 0001262039-22-000029:mdna:119]

[0001262039-22-000038:mdna:118]
General and administrative expense increased by $4.9 million, or 14%, during the three months ended September 30, 2022 compared to the same period last year, primarily due to an increase of $4.3 million in personnel-related costs and an increase of $1.3 million in depreciation and other occupancy-relate costs, partially offset by a decrease of $1.7 million in provision for expected credit losses, and the favorable impact of foreign currency fluctuations. We currently expect general and administrative expense to increase in absolute dollars during the remainder of 2022.

[0001262039-22-000038:mdna:119]
[same as prior period, unchanged from 0001262039-22-000029:mdna:123]

[0001262039-22-000038:mdna:120]
We generated operating income of $265.5 million during the three months ended September 30, 2022, an increase of $99.1 million, or 60%, compared to $166.4 million in the same period last year. Operating income as a percentage of revenue was 23% during the three months ended September 30, 2022, compared to 19% in the same period last year. The increase in operating margin primarily benefits from 2.8 percentage points, 0.7 percentage points and 0.6 percentage points decreases in sales and marketing expense, research and development expense and general and administrative expense as percentage of revenue, respectively.

[0001262039-22-000038:mdna:121]
[same as prior period, unchanged from 0001262039-22-000029:mdna:158]

[0001262039-22-000038:mdna:122]
|  | Three Months Ended |  |  |  |  |
| September 30,2022 |  | September 30,2021 |  | Change |  | % Change |
| (in millions, except percentages) |
| Interest income | $ | 4.6 |  |  | $ | 1.2 |  |  | $ | 3.4 |  |  | 283 | % |
| Interest expense | $ | (4.5) |  |  | $ | (4.6) |  |  | $ | 0.1 |  |  | (2) | % |
| Other expense—net | $ | (0.9) |  |  | $ | (6.3) |  |  | $ | 5.4 |  |  | (86) | % |

[0001262039-22-000038:mdna:123]
Interest income increased by $3.4 million during the three months ended September 30, 2022 compared to the same period last year, as a result of higher interest rates. Interest income varies depending on our average investment balances during the period, types and mix of investments, and market interest rates. Interest expense remained comparatively flat during the three months ended September 30, 2022 compared to the same period last year. The $5.4 million decrease of Other expense—net during the three months ended September 30, 2022 compared to the same period last year, was primarily due to an increase of $6.3 million gain on marketable equity securities and an increase of $0.9 million net rental income from real estate, partially offset by $2.3 million of foreign currency exchange loss.

[0001262039-22-000038:mdna:124]
[same as prior period, unchanged from 0001262039-22-000029:mdna:161]

[0001262039-22-000038:mdna:125]
|  | Three Months Ended |  | Change |  | % Change |
| September 30,2022 |  | September 30,2021 |  |
| (in millions, except percentages) |
| Provision for (benefit from) income taxes | $ | 27.3 |  |  | $ | (9.3) |  |  | $ | 36.6 |  |  | (394) | % |
| Effective tax rate (%) | 10 | % |  | (6) | % |  |  |  |  |

[0001262039-22-000038:mdna:126]
[same as prior period, unchanged from 0001262039-22-000029:mdna:130]

[0001262039-22-000038:mdna:127]
Our effective tax rate was 10% for the three months ended September 30, 2022 compared to an effective tax rate of negative 6% for the same period last year. The provision for income taxes for the three months ended September 30, 2022 was primarily comprised of U.S. federal and state taxes, withholding taxes and foreign taxes that were $75.5 million, which were favorably affected by a tax benefit of $28.9 million from the foreign-derived intangible income deduction (the “FDII deduction”) and excess tax benefits from stock-based compensation expense of $19.3 million.

[0001262039-22-000038:mdna:128]
The benefit from income taxes for the three months ended September 30, 2021 was comprised of U.S. federal and state taxes, withholding taxes, and foreign taxes that were $40.1 million, which were offset by a tax benefit of $8.7 million from the FDII deduction and excess tax benefits from stock-based compensation expense of $25.0 million. The provision for income taxes was further impacted by a tax benefit of $15.7 million for a change in tax accounting positions in finalization of the prior year's tax return.

[0001262039-22-000038:mdna:129]
Nine Months Ended September 30, 2022 and 2021

[0001262039-22-000038:mdna:130]
[same as prior period, unchanged from 0001262039-22-000029:mdna:134]

[0001262039-22-000038:mdna:131]
|  | Nine Months Ended |  |  |  |  |
| September 30,2022 |  | September 30,2021 |  |  |  |  |
| Amount |  | % ofRevenue |  | Amount |  | % ofRevenue |  | Change |  | % Change |
| (in millions, except percentages) |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 1,240.4 |  |  | 40 | % |  | $ | 876.1 |  |  | 37 | % |  | $ | 364.3 |  |  | 42 | % |
| Service | 1,894.0 |  |  | 60 |  |  | 1,502.5 |  |  | 63 |  |  | 391.5 |  |  | 26 |  |
| Total revenue | $ | 3,134.4 |  |  | 100 | % |  | $ | 2,378.6 |  |  | 100 | % |  | $ | 755.8 |  |  | 32 | % |
| Revenue by geography: |  |  |  |  |  |  |  |  |  |  |  |
| Americas | $ | 1,263.8 |  |  | 40 | % |  | $ | 978.0 |  |  | 41 | % |  | $ | 285.8 |  |  | 29 | % |
| EMEA | 1,181.7 |  |  | 38 |  |  | 905.1 |  |  | 38 |  |  | 276.6 |  |  | 31 |  |
| APAC | 688.9 |  |  | 22 |  |  | 495.5 |  |  | 21 |  |  | 193.4 |  |  | 39 |  |
| Total revenue | $ | 3,134.4 |  |  | 100 | % |  | $ | 2,378.6 |  |  | 100 | % |  | $ | 755.8 |  |  | 32 | % |

[0001262039-22-000038:mdna:132]
Total revenue increased by $755.8 million, or 32%, during the nine months ended September 30, 2022 compared to the same period last year. We continue to experience significant organic revenue growth (i.e., revenue growth excluding attribution from acquisitions) with diversification of revenue geographically, and across both customer and industry segments. Revenue from all regions grew, with Americas contributing the largest portion of the increase on an absolute dollar basis and APAC, which included Alaxala, contributing the largest portion of the increase on a percentage basis.

[0001262039-22-000038:mdna:133]
Product revenue increased by $364.3 million, or 42%, during the nine months ended September 30, 2022 compared to the same period last year. Product revenue growth was consistent with an elevated cyber threat landscape and included the benefit of certain pricing actions. Core Platform products accounted for approximately half of the product revenue growth in the nine months ended September 30, 2022. While Secure SD-WAN and OT contributed significantly to product revenue growth, the main driver was the strong demand for the wide range of other operating system capabilities embedded in the Core Platform products. We also experienced strong revenue growth across many Enhanced Platform Technology products.

[0001262039-22-000038:mdna:134]
Service revenue increased by $391.5 million, or 26%, during the nine months ended September 30, 2022 compared to the same period last year. FortiGuard security subscription and FortiCare technical support and other revenues increased by $207.5 million, or 25%, and by $184.0 million, or 27%, respectively, during the nine months ended September 30, 2022 compared to the same period last year. The increases were primarily due to the recognition of revenue from our growing deferred revenue balance related to FortiGuard and other security subscriptions delivered to on-premise and cloud-based environments, as well as FortiCare and other technical support, including our customers moving to higher-tier support offerings and the early effects of certain pricing actions.

[0001262039-22-000038:mdna:135]
[same as prior period, unchanged from 0001262039-22-000029:mdna:140]

[0001262039-22-000038:mdna:136]
Of the service revenue recognized during the nine months ended September 30, 2022, 72% was included in the deferred revenue balance as of December 31, 2021. Of the service revenue recognized during the nine months ended September 30, 2021, 73% was included in the deferred revenue balance as of December 31, 2020. We expect service revenue growth will continue to increase through the remainder of 2022, as our business is expected to grow and as service revenue benefits from previous pricing actions. However, there are risks to service revenue growth rates, including customers reducing their spending, supply chain constraints, customers taking longer to buy their service, or other reasons.

[0001262039-22-000038:mdna:137]
[same as prior period, unchanged from 0001262039-22-000029:mdna:141]

[0001262039-22-000038:mdna:138]
|  | Nine Months Ended |  |  |  |  |
| September 30,2022 |  | September 30,2021 |  | Change |  | % Change |
| (in millions, except percentages) |
| Cost of revenue: |  |  |  |  |  |  |  |
| Product | $ | 501.4 |  |  | $ | 341.2 |  |  | $ | 160.2 |  |  | 47 | % |
| Service | 286.2 |  |  | 213.5 |  |  | 72.7 |  |  | 34 | % |
| Total cost of revenue | $ | 787.6 |  |  | $ | 554.7 |  |  | $ | 232.9 |  |  | 42 | % |
| Gross margin (%): |  |  |  |  |  |  |  |
| Product | 59.6 | % |  | 61.1 | % |  |  |  |  |
| Service | 84.9 |  |  | 85.8 |  |  |  |  |  |
| Total gross margin | 74.9 | % |  | 76.7 | % |  |  |  |  |

[0001262039-22-000038:mdna:139]
Total gross margin decreased by 1.8 percentage points during the nine months ended September 30, 2022 compared to the same period last year, driven by the consolidation of Alaxala, costs increases and a change in revenue mix to lower margin product revenue from higher margin service revenue. Revenue mix shifted by 3 percentage points from service revenue to product revenue, as a percentage of total revenue. Total gross margin also reflected a decline in product gross margin and services gross margin.

[0001262039-22-000038:mdna:140]
Product gross margin decreased by 1.5 percentage points during the nine months ended September 30, 2022 compared to the same period last year. The decrease in product margin is driven by higher expedite fees, freight fees and other product costs due to supply chain constraints and the consolidation of Alaxala, partially offset by higher average selling prices and a mix shift to higher margin high end appliances. Cost of product revenue was comprised primarily of third-party contract manufacturers’ costs and the costs of materials used in production.

[0001262039-22-000038:mdna:141]
Service gross margin decreased by 0.9 percentage points during the nine months ended September 30, 2022 compared to the same period last year. Cost of service revenue was comprised primarily of personnel and data center costs. The decrease in service gross margin was primarily impacted by our consolidation of Alaxala and our data center expansion, partially offset by favorable impact of foreign currency fluctuations.

[0001262039-22-000038:mdna:142]
[same as prior period, unchanged from 0001262039-22-000029:mdna:146]

[0001262039-22-000038:mdna:143]
[same as prior period, unchanged from 0001262039-22-000029:mdna:147]

[0001262039-22-000038:mdna:144]
|  | Nine Months Ended |  | Change |  | % Change |
| September 30,2022 |  | September 30,2021 |  |
| Amount |  | % ofRevenue |  | Amount |  | % ofRevenue |  |
| (in millions, except percentages) |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | $ | 383.5 |  |  | 12 | % |  | $ | 311.6 |  |  | 13 | % |  | $ | 71.9 |  |  | 23 | % |
| Sales and marketing | 1,230.2 |  |  | 39 |  |  | 978.0 |  |  | 41 |  |  | 252.2 |  |  | 26 |  |
| General and administrative | 124.7 |  |  | 4 |  |  | 102.2 |  |  | 4 |  |  | 22.5 |  |  | 22 |  |
| Gain on IP matter | (3.4) |  |  | — |  |  | (3.4) |  |  | — |  |  | — |  |  | — |  |
| Total operating expenses | $ | 1,735.0 |  |  | 55 | % |  | $ | 1,388.4 |  |  | 58 | % |  | $ | 346.6 |  |  | 25 | % |

[0001262039-22-000038:mdna:145]
[same as prior period, unchanged from 0001262039-22-000029:mdna:149]

[0001262039-22-000038:mdna:146]
Research and development expense increased by $71.9 million, or 23%, during the nine months ended September 30, 2022 compared to the same period last year, primarily due to an increase of $47.7 million in personnel-related costs as a result of increased headcount to support the development of new products and continued enhancements to our existing products. In addition, we incurred increases in depreciation and other occupancy costs of $19.4 million, partially offset by the favorable impact of foreign currency fluctuations. We currently intend to continue to invest in our research and development organization, and expect research and development expense to increase sequentially in absolute dollars during the remainder of 2022.

[0001262039-22-000038:mdna:147]
[same as prior period, unchanged from 0001262039-22-000029:mdna:151]

[0001262039-22-000038:mdna:148]
Sales and marketing expense increased by $252.2 million, or 26%, during the nine months ended September 30, 2022 compared to the same period last year, primarily due to an increase of $152.7 million in personnel-related costs. We significantly increased our sales capacity, including newer non-tenured sales people. The increase in headcount is expected to help drive global market revenue increases. In addition, marketing-related expense increased by $38.0 million, travel expense increased by $29.4 million and depreciation expense and other occupancy-related expense increased by $14.7 million, partially offset by the favorable impact of foreign currency fluctuations. We currently intend to continue to make investments in sales and marketing resources, which are critical to support our future growth, and expect sales and marketing expense to increase sequentially in absolute dollars during the remainder of 2022.

[0001262039-22-000038:mdna:149]
[same as prior period, unchanged from 0001262039-22-000029:mdna:153]

[0001262039-22-000038:mdna:150]
General and administrative expense increased by $22.5 million, or 22%, during the nine months ended September 30, 2022 compared to the same period last year, primarily due to an increase of $12.8 million in personnel-related costs, an increase of $3.3 million in depreciation and other occupancy costs, an increase of $2.1 million in supplies expense and an increase of $1.3 million in provision for expected credit losses, partially offset by the favorable impact of foreign currency fluctuations. We currently expect general and administrative expense to increase sequentially in absolute dollars during the remainder of 2022.

[0001262039-22-000038:mdna:151]
[same as prior period, unchanged from 0001262039-22-000029:mdna:155]

[0001262039-22-000038:mdna:152]
We generated operating income of $611.8 million during the nine months ended September 30, 2022, an increase of $176.3 million, or 40%, compared to $435.5 million in the same period last year. Operating income as a percentage of revenue increased to 20% during the nine months ended September 30, 2022 compared to 18% in the same period last year. The increase in our operating margin was primarily due to 1.9 percentage points, 0.9 percentage points and 0.3 percentage points decreases in sales and marketing expense, research and development expense and general and administrative expense as percentage of revenue, respectively, partially offset by a 1.8 percentage points decrease in gross margin.

[0001262039-22-000038:mdna:153]
[same as prior period, unchanged from 0001262039-22-000029:mdna:157]

[0001262039-22-000038:mdna:154]
Interest income, interest expense and other expense—net

[0001262039-22-000038:mdna:155]
|  | Nine Months Ended |  |  |  |  |
| September 30,2022 |  | September 30,2021 |  | Change |  | % Change |
| (in millions, except percentages) |
| Interest income | $ | 8.3 |  |  | $ | 3.5 |  |  | $ | 4.8 |  |  | 137 | % |
| Interest expense | $ | (13.5) |  |  | $ | (10.4) |  |  | $ | (3.1) |  |  | 30 | % |
| Other expense—net | $ | (19.3) |  |  | $ | (7.5) |  |  | $ | (11.8) |  |  | 157 | % |

[0001262039-22-000038:mdna:156]
Interest income increased by $4.8 million during the nine months ended September 30, 2022 compared to the same period last year, primarily as a result of higher interest rates. Interest income varies depending on our average investment balances during the period, types and mix of investments, and market interest rates. Interest expense increased by $3.1 million during the nine months ended September 30, 2022 compared to the same period last year, primarily due to the Senior Notes, issued in the first quarter of 2021. Other expense—net increased by $11.8 million during the nine months ended September 30, 2022 compared to the same period last year due to a $8.8 million increase of loss on marketable equity securities and a $6.3 million increase of foreign currency exchange loss, partially offset by a $2.9 million increase in net rental income from real estate.

[0001262039-22-000038:mdna:157]
[same as prior period, unchanged from 0001262039-22-000029:mdna:128]

[0001262039-22-000038:mdna:158]
|  | Nine Months Ended |  | Change |  | % Change |
| September 30,2022 |  | September 30,2021 |  |
| (in millions, except percentages) |
| Provision for income taxes | $ | 21.6 |  |  | $ | 10.4 |  |  | $ | 11.2 |  |  | 108 | % |
| Effective tax rate (%) | 4 | % |  | 2 | % |  |  |  |  |

[0001262039-22-000038:mdna:159]
Our effective tax rate was 4% for the nine months ended September 30, 2022 compared to an effective tax rate of 2% for the same period last year. The provision for income taxes for the nine months ended September 30, 2022 was primarily comprised of U.S. federal and state taxes, withholding taxes and foreign taxes that were $169.2 million. This provision for income taxes was favorably affected by a tax benefit of $62.6 million from the FDII deduction, excess tax benefits from stock-based compensation expense of $68.7 million and release of reserves of $16.3 million on uncertain tax positions and the accrued interest thereon due to the expiration of the statute of limitations.

[0001262039-22-000038:mdna:160]
The provision for income taxes for the nine months ended September 30, 2021 was comprised of U.S. federal and state taxes, withholding taxes, and foreign taxes that were $115.8 million, which were offset by a tax benefit of $23.9 million from the FDII deduction, excess tax benefits from stock-based compensation expense of $60.3 million and release of reserves of $5.5 million on uncertain tax positions and the accrued interest thereon due to the expiration of the statute of limitations. The provision for income taxes was further impacted by a tax benefit of $15.7 million for a change in tax accounting positions in finalization of the prior year's tax return.

[0001262039-22-000038:mdna:161]
[same as prior period, unchanged from 0001262039-22-000029:mdna:165]

[0001262039-22-000038:mdna:162]
[same as prior period, unchanged from 0001262039-22-000029:mdna:166]

[0001262039-22-000038:mdna:163]
|  | As of |
|  | September 30,2022 |  | December 31,2021 |
|  | (in millions) |
| Cash and cash equivalents | $ | 964.0 |  |  | $ | 1,319.1 |  |
| Short-term and long-term investments | 823.5 |  |  | 1,634.8 |  |
| Marketable equity securities | 26.9 |  |  | 38.6 |  |
| Total cash, cash equivalents, investments and marketable equity securities | $ | 1,814.4 |  |  | $ | 2,992.5 |  |
| Working capital | $ | 202.6 |  |  | $ | 1,282.5 |  |
|  | Nine Months Ended |
|  | September 30,2022 |  | September 30,2021 |
|  | (in millions) |
| Net cash provided by operating activities | $ | 1,202.5 |  |  | $ | 1,132.9 |  |
| Net cash provided by (used in) investing activities | 546.5 |  |  | (1,059.2) |  |
| Net cash provided by (used in) financing activities | (2,102.9) |  |  | 716.4 |  |
| Effect of exchange rate changes on cash and cash equivalents | (1.2) |  |  | 0.2 |  |
| Net increase (decrease) in cash and cash equivalents | $ | (355.1) |  |  | $ | 790.3 |  |

[0001262039-22-000038:mdna:164]
[same as prior period, unchanged from 0001262039-22-000029:mdna:168]

[0001262039-22-000038:mdna:165]
[same as prior period, unchanged from 0001262039-22-000029:mdna:169]

[0001262039-22-000038:mdna:166]
In July 2022, our board of directors authorized a $1.0 billion increase in the authorized stock repurchase under the Repurchase Program, bringing the aggregate amount of authorized to be repurchased to $5.25 billion of our outstanding common stock through February 28, 2023. During the nine months ended September 30, 2022, we repurchased 36.0 million shares of common stock under the Repurchase Program for an aggregate purchase price of $1.99 billion. As of September 30, 2022, $529.6 million remained available for future share repurchases under the Repurchase Program.

[0001262039-22-000038:mdna:167]
In March 2021, we issued $1.0 billion aggregate principal amount of Senior Notes, consisting of $500.0 million aggregate principal amount of 1.0% notes due March 15, 2026 and $500.0 million aggregate principal amount of 2.2% notes due March 15, 2031, in an underwritten registered public offering.

[0001262039-22-000038:mdna:168]
We expect to continue to increase our office and warehouse capacity to support growth. As we purchase new properties, we will work to incorporate these properties into the environmental goals we have established. We estimate capital expenditures to be between approximately $75 million and $85 million for the fourth quarter of 2022.

[0001262039-22-000038:mdna:169]
We believe that our cash provided by operating activities, together with our existing cash, cash equivalents and investments will be sufficient to meet our anticipated cash needs and do not currently intend to retire these Senior Notes early. Refer to Note 10. Debt in Part I, Item 1 of this Quarterly Report on Form 10-Q for information on the Senior Notes. As of September 30, 2022, the long-term debt, net of unamortized discount and debt issuance costs, was $989.9 million.

[0001262039-22-000038:mdna:170]
We enter into non-cancellable agreements with contract manufacturers and certain component suppliers to procure inventory based on our requirements in order to negotiate manufacturing lead times and encourage and incentivize vendors to deliver components and finished goods. In certain instances, these agreements allow us the option to reschedule and adjust our

[0001262039-22-000038:mdna:171]
[same as prior period, unchanged from 0001262039-22-000029:mdna:174]

[0001262039-22-000038:mdna:172]
requirements based on our business needs prior to firm orders being placed. These purchase commitments as of September 30, 2022 totaled $1.46 billion, an increase of $315.9 million compared to $1.14 billion as of December 31, 2021 as we increased our commitments in order to address significant supply constraints seen industry-wide due to component shortages caused, in part, by the COVID-19 pandemic, and for which the duration of such constraints is uncertain. Our agreements secured supply and pricing for certain product components and commitments with contract manufacturers to meet customer demand and to address extended lead times. We also have open purchase orders and contractual obligations in the ordinary course of business for which we have not received goods or services. As of September 30, 2022, we had $111.7 million in other contractual commitments having a remaining term in excess of one year that are non-cancelable.

[0001262039-22-000038:mdna:173]
There have been no significant changes to our leases as disclosed in our Annual Report on Form 10-K for the year ended December 31, 2021 other than as of September 30, 2022 we had additional minimum lease payments of $35.7 million relating to operating leases that had been signed but had not yet commenced. These leases will commence during 2022 and will have lease terms of approximately one to six years.

[0001262039-22-000038:mdna:174]
As of September 30, 2022, our cash, cash equivalents, short-term and long-term investments and marketable equity securities of $1.81 billion were invested primarily in deposit accounts, money market funds, corporate debt securities, commercial paper, certificates of deposit and term deposits, U.S. government and agency securities, municipal bonds and marketable equity securities. It is our investment policy to invest excess cash in a manner that preserves capital, provides liquidity and generates return without significantly increasing risk. We do not enter into investments for trading or speculative purposes.

[0001262039-22-000038:mdna:175]
The amount of cash, cash equivalents and investments held by our international subsidiaries was $140.9 million as of September 30, 2022 and $132.4 million as of December 31, 2021.

[0001262039-22-000038:mdna:176]
[same as prior period, unchanged from 0001262039-22-000029:mdna:179]

[0001262039-22-000038:mdna:177]
As of September 30, 2022, we did not have any relationships with unconsolidated organizations or financial partnerships, such as structured finance or special purpose entities that would have been established for the purpose of facilitating off-balance sheet arrangements or other contractually narrow or limited purposes.

[0001262039-22-000038:mdna:178]
[same as prior period, unchanged from 0001262039-22-000029:mdna:181]

[0001262039-22-000038:mdna:179]
Cash generated by operating activities is our primary source of liquidity. It is primarily comprised of net income, as adjusted for non-cash items and changes in operating assets and liabilities. Non-cash adjustments consist primarily of amortization of deferred contract costs, stock-based compensation and depreciation and amortization. Changes in operating assets and liabilities consist primarily of changes in deferred revenue, deferred contract costs, deferred tax assets and accounts receivable, net.

[0001262039-22-000038:mdna:180]
Our operating activities during the nine months ended September 30, 2022 provided cash flows of $1.20 billion as a result of the continued growth of our business and our ability to successfully manage our working capital. Changes in operating assets and liabilities primarily resulted from an increase in sales of our FortiGuard and other security subscription services and FortiCare technical support services to new and existing customers, as reflected by an increase of $742.8 million in our deferred revenue during the nine months ended September 30, 2022.

[0001262039-22-000038:mdna:181]
[same as prior period, unchanged from 0001262039-22-000029:mdna:184]

[0001262039-22-000038:mdna:182]
[same as prior period, unchanged from 0001262039-22-000029:mdna:185]

[0001262039-22-000038:mdna:183]
[same as prior period, unchanged from 0001262039-22-000029:mdna:187]

[0001262039-22-000038:mdna:184]
During the nine months ended September 30, 2022, cash provided by investing activities was $546.5 million, driven by $796.8 million in cash proceeds from maturities and sales of investments, net of purchases of investments and partially offset by $250.3 million of purchases of property and equipment.

[0001262039-22-000038:mdna:185]
[same as prior period, unchanged from 0001262039-22-000029:mdna:189]

[0001262039-22-000038:mdna:186]
[same as prior period, unchanged from 0001262039-22-000029:mdna:190]

[0001262039-22-000038:mdna:187]
During the nine months ended September 30, 2022, cash used in financing activities was $2.10 billion, primarily driven by $1.99 billion used to repurchase shares of our common stock and $110.4 million used to pay tax withholding, net of proceeds from the issuance of common stock.
