# FTNT 8-K — 0001262039-22-000035 filed 2022-11-02

## item codes, every 8-K on or before 2022-11-07

- 2022-11-02 0001262039-22-000035 — 2.02, 9.01
- 2022-08-03 0001262039-22-000026 — 2.02, 9.01
- 2022-06-22 0001262039-22-000023 — 5.03, 9.01
- 2022-06-21 0001262039-22-000021 — 5.07
- 2022-05-04 0001262039-22-000015 — 2.02, 9.01
- 2022-05-02 0001262039-22-000012 — 5.02
- 2022-04-22 0001262039-22-000010 — 8.01
- 2022-02-03 0001262039-22-000005 — 2.02, 9.01
- 2022-01-26 0001262039-22-000002 — 5.02, 9.01 — amendment, the index does not say of what
- 2021-11-04 0001262039-21-000027 — 2.02, 9.01
- 2021-10-06 0001262039-21-000024 — 5.02, 9.01
- 2021-07-29 0001262039-21-000019 — 2.02, 9.01
- 2021-06-23 0001262039-21-000016 — 5.07
- 2021-04-30 0001104659-21-059008 — 5.03 — amendment, the index does not say of what
- 2021-04-29 0001262039-21-000011 — 2.02, 9.01
- 2021-04-28 0001104659-21-056360 — 5.02, 5.03, 9.01
- 2021-03-05 0001193125-21-071498 — 1.01, 9.01
- 2021-02-25 0001193125-21-057281 — 1.01, 9.01
- 2021-02-04 0001262039-21-000005 — 2.02, 9.01
- 2020-12-08 0001262039-20-000070 — 8.01
- 2020-10-29 0001262039-20-000063 — 2.02, 9.01
- 2020-10-20 0001262039-20-000060 — 5.02 — amendment, the index does not say of what
- 2020-08-26 0001262039-20-000056 — 5.02, 9.01
- 2020-08-06 0001262039-20-000051 — 2.02, 9.01
- 2020-07-21 0001262039-20-000044 — 5.03, 8.01, 9.01
- 2020-06-24 0001262039-20-000038 — 5.07
- 2020-05-06 0001262039-20-000029 — 2.02, 9.01
- 2020-04-23 0001262039-20-000025 — 5.03, 9.01
- 2020-04-23 0001262039-20-000024 — 5.02 — amendment of 0001262039-20-000025
- 2020-02-28 0001262039-20-000015 — 5.02, 9.01
- 2020-02-06 0001262039-20-000004 — 2.02, 9.01
- 2019-12-12 0001262039-19-000038 — 8.01
- 2019-10-31 0001262039-19-000032 — 2.02, 9.01
- 2019-10-28 0001262039-19-000027 — 8.01
- 2019-10-23 0001262039-19-000025 — 5.02, 9.01
- 2019-08-01 0001262039-19-000021 — 2.02, 9.01
- 2019-06-26 0001262039-19-000018 — 5.07
- 2019-05-02 0001262039-19-000010 — 2.02, 9.01
- 2019-02-06 0001262039-19-000002 — 2.02, 9.01
- 2018-11-01 0001262039-18-000037 — 2.02, 9.01
- 2018-10-23 0001262039-18-000035 — 8.01
- 2018-08-01 0001262039-18-000025 — 2.02, 9.01
- 2018-06-28 0001262039-18-000023 — 5.03, 5.07, 9.01
- 2018-06-04 0001262039-18-000021 — 8.01
- 2018-05-03 0001262039-18-000017 — 2.02, 5.02, 9.01
- 2018-02-05 0001262039-18-000004 — 2.02, 5.02, 9.01
- 2017-10-26 0001262039-17-000031 — 2.02, 9.01
- 2017-10-19 0001262039-17-000029 — 5.02 — amendment, the index does not say of what
- 2017-07-26 0001262039-17-000025 — 2.02, 9.01
- 2017-06-27 0001262039-17-000023 — 5.07
- 2017-05-31 0001262039-17-000021 — 5.02 — amendment of 0001262039-17-000019
- 2017-05-30 0001262039-17-000019 — 5.02, 9.01
- 2017-04-27 0001262039-17-000013 — 2.02, 9.01
- 2017-02-02 0001262039-17-000003 — 2.02, 9.01
- 2016-10-27 0001262039-16-000085 — 2.02, 9.01
- 2016-10-11 0001262039-16-000082 — 2.02, 9.01
- 2016-07-28 0001262039-16-000076 — 2.02, 9.01
- 2016-07-22 0001262039-16-000073 — 8.01, 9.01
- 2016-06-20 0001262039-16-000068 — 5.07
- 2016-06-07 0001193125-16-614788 — 8.01
- 2016-04-26 0001262039-16-000061 — 2.02, 9.01
- 2016-01-28 0001262039-16-000051 — 2.02, 9.01
- 2015-10-27 0001262039-15-000045 — 2.02
- 2015-10-22 0001262039-15-000042 — 5.02 — amendment, the index does not say of what
- 2015-10-22 0001262039-15-000041 — 5.02 — amendment, the index does not say of what
- 2015-10-22 0001262039-15-000039 — 2.02, 9.01
- 2015-09-28 0001262039-15-000034 — 5.02, 9.01
- 2015-09-22 0001262039-15-000031 — 9.01 — amendment of 0001193125-15-248065
- 2015-08-28 0001262039-15-000027 — 3.01, 5.02
- 2015-07-23 0001262039-15-000021 — 5.02
- 2015-07-22 0001262039-15-000019 — 2.02, 9.01
- 2015-07-08 0001193125-15-248065 — 2.01, 8.01, 9.01
- 2015-06-22 0001193125-15-229099 — 5.07
- 2015-06-19 0001193125-15-228428 — 5.02, 9.01
- 2015-04-20 0001262039-15-000014 — 2.02, 9.01
- 2015-01-28 0001262039-15-000005 — 2.02, 9.01
- 2014-10-22 0001262039-14-000036 — 2.02, 9.01
- 2014-07-23 0001262039-14-000030 — 2.02, 9.01
- 2014-06-24 0001262039-14-000027 — 5.07
- 2014-04-23 0001262039-14-000021 — 2.02, 9.01
- 2014-04-21 0001262039-14-000018 — 5.03, 9.01
- 2014-01-29 0001262039-14-000004 — 2.02, 9.01
- 2013-12-20 0001262039-13-000061 — 5.02, 9.01
- 2013-11-27 0001262039-13-000057 — 5.02, 7.01, 9.01
- 2013-11-12 0001445305-13-002993 — 5.02
- 2013-10-23 0001262039-13-000051 — 2.02, 9.01
- 2013-07-30 0001262039-13-000039 — 2.02, 9.01
- 2013-06-25 0001262039-13-000030 — 5.07
- 2013-04-30 0001262039-13-000023 — 2.02, 9.01
- 2013-04-19 0001262039-13-000020 — 5.02, 9.01
- 2013-04-19 0001262039-13-000018 — 5.02 — amendment of 0001262039-13-000020
- 2013-04-10 0001262039-13-000016 — 2.02, 9.01
- 2013-03-26 0001262039-13-000013 — 5.02
- 2013-01-30 0001262039-13-000005 — 2.02, 9.01
- 2013-01-24 0001262039-13-000002 — 5.02, 9.01
- 2012-10-16 0001262039-12-000048 — 2.02, 9.01
- 2012-10-01 0001262039-12-000045 — 5.02
- 2012-09-26 0001262039-12-000043 — 5.01
- 2012-07-25 0001262039-12-000038 — 2.02, 9.01
- 2012-07-19 0001262039-12-000034 — 5.02
- 2012-06-20 0001193125-12-275869 — 5.07
- 2012-04-27 0001262039-12-000029 — 5.02
- 2012-04-24 0001262039-12-000025 — 2.02, 9.01
- 2012-01-31 0001262039-12-000006 — 2.02, 9.01
- 2012-01-25 0001262039-12-000003 — 5.03
- 2011-10-24 0001262039-11-000036 — 2.02
- 2011-07-19 0001262039-11-000014 — 2.02, 9.01
- 2011-06-27 0001193125-11-174474 — 5.02, 5.07, 9.01
- 2011-04-27 0001193125-11-111938 — 2.02, 9.01
- 2011-01-25 0001193125-11-013914 — 2.02, 9.01
- 2010-10-21 0001193125-10-233676 — 2.02, 9.01
- 2010-09-02 0001193125-10-203099 — 8.01
- 2010-07-22 0001193125-10-163844 — 2.02, 9.01
- 2010-06-24 0001193125-10-146082 — 5.07
- 2010-04-28 0001193125-10-096698 — 2.02, 9.01
- 2010-02-09 0001193125-10-024614 — 8.01
- 2010-01-27 0001193125-10-014292 — 2.02, 9.01
- 2010-01-26 0001193125-10-013031 — 5.02, 9.01

## late-filing notifications on or before 2022-11-07

- none on or before 2022-11-07

## item 2.02 — earnings release, exhibit 99.1

[0001262039-22-000035:8k_2_02:1]
EX-99.1
2
ftntq3-2022ex991.htm
PRESS RELEASE

[0001262039-22-000035:8k_2_02:2]
Document

[0001262039-22-000035:8k_2_02:3]
Press Release

[0001262039-22-000035:8k_2_02:4]
Fortinet Reports Third Quarter 2022 Financial Results

[0001262039-22-000035:8k_2_02:5]
Third Quarter 2022 Highlights

[0001262039-22-000035:8k_2_02:6]
•Product revenue of $468.7 million, up 39% year over year

[0001262039-22-000035:8k_2_02:7]
•Service revenue of $680.8 million, up 28% year over year

[0001262039-22-000035:8k_2_02:8]
•Total revenue of $1.15 billion, up 33% year over year

[0001262039-22-000035:8k_2_02:9]
•Billings of $1.41 billion, up 33% year over year1

[0001262039-22-000035:8k_2_02:10]
•Deferred revenue of $4.19 billion, up 35% year over year

[0001262039-22-000035:8k_2_02:11]
•GAAP operating margin of 23.1%

[0001262039-22-000035:8k_2_02:12]
•Non-GAAP operating margin of 28.3%1

[0001262039-22-000035:8k_2_02:13]
•GAAP diluted net income per share attributable to Fortinet, Inc. of $0.292

[0001262039-22-000035:8k_2_02:14]
•Non-GAAP diluted net income per share attributable to Fortinet, Inc. of $0.331,2

[0001262039-22-000035:8k_2_02:15]
•Cash flow from operations of $483.0 million

[0001262039-22-000035:8k_2_02:16]
•Free cash flow of $395.2 million1

[0001262039-22-000035:8k_2_02:17]
•Cash paid for share repurchases of $500.0 million

[0001262039-22-000035:8k_2_02:18]
SUNNYVALE, Calif. - November 2, 2022 - Fortinet® (Nasdaq: FTNT), a global leader in broad, integrated and automated cybersecurity solutions, today announced financial results for the third quarter ended September 30, 2022.

[0001262039-22-000035:8k_2_02:19]
“We continued to gain market share in the large addressable and fast-growing cybersecurity industry. Revenue and billings growth of over 30% in the third quarter significantly outpaced industry growth rates,” said Ken Xie, Founder, Chairman, and Chief Executive Officer. “Fortinet’s future growth will be driven by the convergence of security and networking, the industry trend of vendor and product consolidation, the elevated threat environment, and a greater focus on offering services for existing and new customers.”

[0001262039-22-000035:8k_2_02:20]
Financial Highlights for the Third Quarter of 2022

[0001262039-22-000035:8k_2_02:21]
•Revenue: Total revenue was $1.15 billion for the third quarter of 2022, an increase of 32.6% compared to $867.2 million for the same quarter of 2021.

[0001262039-22-000035:8k_2_02:22]
•Product Revenue: Product revenue was $468.7 million for the third quarter of 2022, an increase of 39.0% compared to $337.1 million for the same quarter of 2021.

[0001262039-22-000035:8k_2_02:23]
•Service Revenue: Service revenue was $680.8 million for the third quarter of 2022, an increase of 28.4% compared to $530.1 million for the same quarter of 2021.

[0001262039-22-000035:8k_2_02:24]
•Billings1: Total billings were $1.41 billion for the third quarter of 2022, an increase of 32.6% compared to $1.06 billion for the same quarter of 2021.

[0001262039-22-000035:8k_2_02:25]
•Deferred Revenue: Total deferred revenue was $4.19 billion as of September 30, 2022, an increase of 35.0% compared to $3.11 billion as of September 30, 2021.

[0001262039-22-000035:8k_2_02:26]
•GAAP Operating Income and Margin: GAAP operating income was $265.5 million for the third quarter of 2022, representing a GAAP operating margin of 23.1%. GAAP

[0001262039-22-000035:8k_2_02:27]
operating income was $166.4 million for the same quarter of 2021, representing a GAAP operating margin of 19.2%.

[0001262039-22-000035:8k_2_02:28]
•Non-GAAP Operating Income and Margin1: Non-GAAP operating income was $324.9 million for the third quarter of 2022, representing a non-GAAP operating margin of 28.3%. Non-GAAP operating income was $223.6 million for the same quarter of 2021, representing a non-GAAP operating margin of 25.8%.

[0001262039-22-000035:8k_2_02:29]
•GAAP Net Income and Diluted Net Income Per Share Attributable to Fortinet, Inc.2: GAAP net income was $231.6 million for the third quarter of 2022, compared to GAAP net income of $163.1 million for the same quarter of 2021. GAAP diluted net income per share was $0.29 for the third quarter of 2022, based on 798.6 million diluted weighted-average shares outstanding, compared to GAAP diluted net income per share of $0.19 for the same quarter of 2021, based on 838.6 million diluted weighted-average shares outstanding.

[0001262039-22-000035:8k_2_02:30]
•Non-GAAP Net Income and Diluted Net Income Per Share Attributable to Fortinet, Inc.1,2: Non-GAAP net income was $262.7 million for the third quarter of 2022, compared to non-GAAP net income of $165.9 million for the same quarter of 2021. Non-GAAP diluted net income per share was $0.33 for the third quarter of 2022, based on 798.6 million diluted weighted-average shares outstanding, compared to $0.20 for the same quarter of 2021, based on 838.6 million diluted weighted-average shares outstanding.

[0001262039-22-000035:8k_2_02:31]
•Cash Flow: Cash flow from operations was $483.0 million for the third quarter of 2022, compared to $398.8 million for the same quarter of 2021.

[0001262039-22-000035:8k_2_02:32]
•Free Cash Flow1: Free cash flow was $395.2 million for the third quarter of 2022, compared to $329.8 million for the same quarter of 2021.

[0001262039-22-000035:8k_2_02:33]
•Share Repurchase Program2: During the three and nine months ended September 30, 2022, Fortinet repurchased 10.2 million and 36.0 million shares of its common stock, respectively, at an average price of $49.15 and $55.37 per share, respectively, and for an aggregate purchase price of  $500.0 million and $1.99 billion, respectively. During the three and nine months ended September 30, 2021, Fortinet repurchased 1.8 million and 4.1 million shares of its common stock, respectively, at an average price of $58.81 and $48.59 per share, respectively, and for an aggregate purchase price of $108.8 million and $200.4 million.

[0001262039-22-000035:8k_2_02:34]
Guidance

[0001262039-22-000035:8k_2_02:35]
For the fourth quarter of 2022, Fortinet currently expects:

[0001262039-22-000035:8k_2_02:36]
•Revenue in the range of $1.275 billion to $1.315 billion

[0001262039-22-000035:8k_2_02:37]
•Billings in the range of $1.665 billion to $1.720 billion

[0001262039-22-000035:8k_2_02:38]
•Non-GAAP gross margin in the range of 75.0% to 76.0%

[0001262039-22-000035:8k_2_02:39]
•Non-GAAP operating margin in the range of 30.0% to 31.0%

[0001262039-22-000035:8k_2_02:40]
•Diluted non-GAAP net income per share attributable to Fortinet, Inc. in the range of $0.38 to $0.40, assuming a non-GAAP effective tax rate of 17%. This assumes a diluted share count of 795 million to 805 million.

[0001262039-22-000035:8k_2_02:41]
For the fiscal year 2022, Fortinet currently expects:

[0001262039-22-000035:8k_2_02:42]
•Revenue in the range of $4.410 billion to $4.450 billion

[0001262039-22-000035:8k_2_02:43]
•Service revenue in the range of $2.645 billion to $2.655 billion

[0001262039-22-000035:8k_2_02:44]
•Billings in the range of $5.540 billion to $5.595 billion

[0001262039-22-000035:8k_2_02:45]
•Non-GAAP gross margin in the range of 75.0% to 76.0%

[0001262039-22-000035:8k_2_02:46]
•Non-GAAP operating margin in the range of 26.0% to 27.0%

[0001262039-22-000035:8k_2_02:47]
•Diluted non-GAAP net income per share attributable to Fortinet, Inc. in the range of $1.13 to $1.15, assuming a non-GAAP effective tax rate of 17%. This assumes a diluted share count of 800 million to 810 million.

[0001262039-22-000035:8k_2_02:48]
Our guidance with respect to non-GAAP financial measures excludes stock-based compensation, amortization of acquired intangible assets and gain on intellectual property matters. We have not reconciled our guidance with respect to non-GAAP financial measures to the corresponding GAAP measures because certain items that impact these measures are uncertain or out of our control, or cannot be reasonably predicted. Accordingly, a reconciliation of these non-GAAP financial measures to the corresponding GAAP measures is not available without unreasonable effort.

[0001262039-22-000035:8k_2_02:49]
1 A reconciliation of GAAP to non-GAAP measures has been provided in the financial statement tables included in this press release. An explanation of these measures is also included below under the heading “Non-GAAP Financial Measures”.

[0001262039-22-000035:8k_2_02:50]
2 All share and per share amounts presented herein have been retroactively adjusted to reflect the five-for-one forward stock split which was effective June 22, 2022.

[0001262039-22-000035:8k_2_02:51]
Conference Call Details

[0001262039-22-000035:8k_2_02:52]
Fortinet will host a conference call today at 1:30 p.m. Pacific Time (4:30 p.m. Eastern Time) to discuss the earnings results. A live webcast of the conference call and supplemental slides will be accessible from the Investor Relations page of Fortinet’s website at https://investor.fortinet.com and a replay will be archived and accessible at https://investor.fortinet.com/events-and-presentations.

[0001262039-22-000035:8k_2_02:53]
Fourth Quarter 2022 Conference Participation Schedule:

[0001262039-22-000035:8k_2_02:54]
•Stifel Midwest One-on-One Growth Conference

[0001262039-22-000035:8k_2_02:55]
November 10, 2022

[0001262039-22-000035:8k_2_02:56]
•Wells Fargo TMT Summit

[0001262039-22-000035:8k_2_02:57]
November 29, 2022

[0001262039-22-000035:8k_2_02:58]
•Barclays Global Technology, Media & Telecommunications Conference

[0001262039-22-000035:8k_2_02:59]
December 7, 2022

[0001262039-22-000035:8k_2_02:60]
Members of Fortinet’s management team are expected to present at these conferences and discuss the latest company strategies and initiatives. Fortinet’s conference presentations are expected to be available via webcast on the company’s web site. To access the most updated information, pre-register and listen to the webcast of each event, please visit the Investor Presentation & Events page of Fortinet’s website at https://investor.fortinet.com/events-and-presentations. The schedule is subject to change.

[0001262039-22-000035:8k_2_02:61]
About Fortinet (www.fortinet.com)

[0001262039-22-000035:8k_2_02:62]
Fortinet (NASDAQ: FTNT) makes possible a digital world that we can trust through its mission to protect people, devices and data everywhere. This is why many of the world’s largest enterprises, service providers and government organizations choose Fortinet to securely accelerate their digital journey. The Fortinet Core Platform and Platform Extension products deliver broad, integrated and automated protections across the entire digital attack surface, securing critical devices, data, applications, and connections from the data center to the cloud to the home office. The Fortinet NSE Training Institute, an initiative of Fortinet’s Training Advancement Agenda, provides one of the largest and broadest training programs in the industry to make cyber training and new career opportunities available to everyone. Learn more at https://www.fortinet.com, the Fortinet Blog or FortiGuard Labs.

[0001262039-22-000035:8k_2_02:63]
#          #          #

[0001262039-22-000035:8k_2_02:64]
Copyright © 2022 Fortinet, Inc. All rights reserved. The symbols ® and ™ denote respectively federally registered trademarks and common law trademarks of Fortinet, Inc., its subsidiaries and affiliates. Fortinet’s trademarks include, but are not limited to, the following: Fortinet, the Fortinet logo, FortiGate, FortiOS, FortiGuard, FortiCare, FortiAnalyzer, FortiManager, FortiASIC, FortiClient, FortiCloud, FortiMail, FortiSandbox, FortiADC, FortiAI, FortiAIOps, FortiAntenna, FortiAP, FortiAPCam, FortiAuthenticator, FortiCache, FortiCall, FortiCam, FortiCamera, FortiCarrier, FortiCASB, FortiCentral, FortiCNP, FortiConnect, FortiController, FortiConverter, FortiCWP, FortiDB, FortiDDoS, FortiDeceptor, FortiDeploy, FortiDevSec, FortiEdge, FortiEDR, FortiExplorer, FortiExtender, FortiFirewall, FortiFone, FortiGSLB, FortiGuest, FortiHypervisor, FortiInsight, FortiIsolator, FortiLAN, FortiLink, FortiMoM, FortiMonitor, FortiNAC, FortiNDR, FortiPenTest, FortiPhish, FortiPolicy, FortiPortal, FortiPresence, FortiProxy, FortiRecon, FortiRecorder, FortiSASE, FortiSDNConnector, FortiSIEM, FortiSMS, FortiSOAR, FortiSwitch, FortiTester, FortiToken, FortiTrust, FortiVoice, FortiWAN, FortiWeb, FortiWiFi, FortiWLC, FortiWLM and FortiXDR. Other trademarks belong to their respective owners. Fortinet has not independently verified statements or certifications herein attributed to third parties and Fortinet does not independently endorse such statements. Notwithstanding anything to the contrary herein, nothing herein constitutes a warranty, guarantee, contract, binding specification or other binding commitment by Fortinet or any indication of intent related to a binding commitment, and performance and other specification information herein may be unique to certain environments.

[0001262039-22-000035:8k_2_02:65]
FTNT-F

[0001262039-22-000035:8k_2_02:66]
Forward-Looking Statements

[0001262039-22-000035:8k_2_02:67]
This press release contains forward-looking statements that involve risks and uncertainties. These forward-looking statements include statements regarding any indications related to future market share gains, guidance and expectations around future financial results, including guidance and expectations for the fourth quarter and full year 2022, statements regarding the momentum in our business and future growth expectations, and any statements regarding our market opportunity and market size, and business momentum. Although we attempt to be accurate in making forward-looking statements, it is possible that future circumstances might differ from the assumptions on which such statements are based such that actual results are materially different from our forward-looking statements in this release. Important factors that could cause results to differ materially from the statements herein include the following: general economic risks, including those caused by the COVID-19 pandemic, the war in Ukraine, economic challenges, expectations of a recession or any actual recession, and the effects of increased inflation in certain geographies; significantly heightened supply chain challenges due to the current global environment; negative impacts from the COVID-19 pandemic on sales, billings, revenue, demand and buying patterns, component supply and ability to manufacture products to meet demand in a timely fashion, and costs such as possible increased costs for shipping and components; global economic conditions, country-specific economic conditions, and foreign currency risks; competitiveness in the security market; the dynamic nature of the security market and its products and services; specific economic risks worldwide and in different geographies, and among different customer segments; uncertainty regarding demand and

[0001262039-22-000035:8k_2_02:68]
COVID-19 Impact

[0001262039-22-000035:8k_2_02:69]
While the broader implications of the COVID-19 pandemic on our employees and overall financial performance remain uncertain, we have seen certain impacts on our business and operations, results of operations, financial condition, cash flows, liquidity and capital and financial resources. Going forward, the situation is uncertain, rapidly changing and hard to predict, and the COVID-19 pandemic may have a material negative impact on our future periods, including our results for the three months ending December 31, 2022, our annual results for 2022, and beyond. To highlight the uncertainty remaining for the three-month period ending December 31, 2022, it should be noted that, due to customer buying patterns and the efforts of our sales force and channel partners to meet or exceed quarterly quotas, we have historically received a substantial portion of each quarter’s sales orders and generated a substantial portion of each quarter’s billings and revenue during the last two weeks of the quarter. Additionally, significantly heightened supply chain challenges are impacting businesses around the globe. If we experience significant changes in our billings growth rates or if we are unable to supply product to meet demand, it will impact product revenue in the current quarter and FortiGuard and FortiCare service revenues in subsequent quarters, as we sell annual and multi-year service contracts that are recognized ratably over the contractual service term. In addition, the broader implications of the pandemic on our business and operations and our financial results, including the extent to which the effects of the pandemic will impact future results and growth in the cybersecurity industry, remain uncertain. The duration and severity of

[0001262039-22-000035:8k_2_02:70]
the economic downturn from the pandemic may negatively impact our business and operations, results of operations, financial condition, cash flows, liquidity and capital and financial resources in a material way. As a result, the effects of the pandemic may not be fully reflected in our results of operations until future periods.

[0001262039-22-000035:8k_2_02:71]
Non-GAAP Financial Measures

[0001262039-22-000035:8k_2_02:72]
We have provided in this release financial information that has not been prepared in accordance with U.S. Generally Accepted Accounting Principles (GAAP). These non-GAAP financial and liquidity measures are not based on any standardized methodology prescribed by GAAP and are not necessarily comparable to similar measures presented by other companies. We use these non-GAAP financial measures internally in analyzing our financial results and believe they are useful to investors, as a supplement to GAAP measures, in evaluating our ongoing operational performance. We believe that the use of these non-GAAP financial measures provides an additional tool for investors to use in evaluating ongoing operating results and trends and in comparing our financial results with peer companies, many of which present similar non-GAAP financial measures to investors.

[0001262039-22-000035:8k_2_02:73]
Non-GAAP financial measures should not be considered in isolation from, or as a substitute for, financial information prepared in accordance with GAAP. Investors are encouraged to review the reconciliation of these non-GAAP financial measures to their most directly comparable GAAP financial measures provided in the financial statement tables below.

[0001262039-22-000035:8k_2_02:74]
Billings (non-GAAP). We define billings as revenue recognized in accordance with GAAP plus the change in deferred revenue from the beginning to the end of the period, less any deferred revenue balances acquired from business combination(s) and adjustment due to adoption of new accounting standard during the period. We consider billings to be a useful metric for management and investors because billings drive current and future revenue, which is an important indicator of the health and viability of our business. There are a number of limitations related to the use of billings instead of GAAP revenue. First, billings include amounts that have not yet been recognized as revenue and are impacted by the term of security and support agreements. Second, we may calculate billings in a manner that is different from peer companies that report similar financial measures. Management accounts for these limitations by providing specific information regarding GAAP revenue and evaluating billings together with GAAP revenue.

[0001262039-22-000035:8k_2_02:75]
Free cash flow (non-GAAP). We define free cash flow as net cash provided by operating activities minus purchases of property and equipment and excluding any significant non-recurring items, such as proceeds from intellectual property matter. We believe free cash flow to be a liquidity measure that provides useful information to management and investors about the amount of cash generated by the business that, after capital expenditures and net of proceeds from intellectual property matter, can be used for strategic opportunities, including repurchasing outstanding common stock, investing in our business, making strategic acquisitions and strengthening the balance sheet. A limitation of using free cash flow rather than the GAAP measures of cash provided by or used in operating activities, investing activities, and financing activities is that free cash flow does not represent the total increase or decrease in the cash and cash equivalents balance for the period because it excludes cash flows from significant non-recurring items, such as proceeds from intellectual property matter, investing activities other than capital expenditures and cash flows from financing activities. Management accounts for this limitation by providing information about our capital expenditures and other investing and financing activities on the face of the cash flow statement and under the caption “Management’s Discussion and Analysis of Financial Condition and Results of Operations—Liquidity and Capital Resources” in our most recent Quarterly Report on Form 10-Q and Annual Report on Form 10-K and by presenting cash flows from investing and financing activities in our reconciliation of free cash flow. In addition, it is important to note that other companies, including companies in our

[0001262039-22-000035:8k_2_02:76]
industry, may not use free cash flow, may calculate free cash flow in a different manner than we do or may use other financial measures to evaluate their performance, all of which could reduce the usefulness of free cash flow as a comparative measure.

[0001262039-22-000035:8k_2_02:77]
Non-GAAP operating income and operating margin. We define non-GAAP operating income as operating income plus stock-based compensation, impairment and amortization of acquired intangible assets, less gain on intellectual property matter and, when applicable, other significant non-recurring items in a given quarter, such as non-recurring gains or losses on litigation-related matters. Non-GAAP operating margin is defined as non-GAAP operating income divided by GAAP revenue. We consider these non-GAAP financial measures to be useful metrics for management and investors because they exclude the items noted above so that our management and investors can compare our recurring core business operating results over multiple periods. There are a number of limitations related to the use of non-GAAP operating income instead of operating income calculated in accordance with GAAP. First, non-GAAP operating income excludes the items noted above. Second, the components of the costs that we exclude from our calculation of non-GAAP operating income may differ from the components that peer companies exclude when they report their non-GAAP results of operations. Management accounts for these limitations by providing specific information regarding the GAAP amounts excluded from non-GAAP operating income and evaluating non-GAAP operating income together with operating income calculated in accordance with GAAP.

[0001262039-22-000035:8k_2_02:78]
Non-GAAP net income and diluted net income per share attributable to Fortinet, Inc. We define non-GAAP net income as net income plus the items noted above under non-GAAP operating income and operating margin. In addition, we adjust non-GAAP net income and diluted net income per share for gains or losses on investments in privately held companies, a tax adjustment required for an effective tax rate on a non-GAAP basis and adjustments attributable to non-controlling interests, which differs from the GAAP effective tax rate. We define non-GAAP diluted net income per share as non-GAAP net income divided by the non-GAAP diluted weighted-average shares outstanding. We consider these non-GAAP financial measures to be useful metrics for management and investors for the same reasons that we use non-GAAP operating income and non-GAAP operating margin. However, in order to provide a more complete picture of our recurring core business operating results, we include in non-GAAP net income and non-GAAP diluted net income per share, the tax adjustment required resulting in an effective tax rate on a non-GAAP basis, which often differs from the GAAP tax rate. We believe the non-GAAP effective tax rates we use are reasonable estimates of normalized tax rates for our current and prior fiscal years under our global operating structure. The same limitations described above regarding our use of non-GAAP operating income and non-GAAP operating margin apply to our use of non-GAAP net income and non-GAAP diluted net income per share. We account for these limitations by providing specific information regarding the GAAP amounts excluded from non-GAAP net income and non-GAAP diluted net income per share and evaluating non-GAAP net income and non-GAAP diluted net income per share together with net income and diluted net income per share calculated in accordance with GAAP.

[0001262039-22-000035:8k_2_02:79]
FORTINET, INC.

[0001262039-22-000035:8k_2_02:80]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001262039-22-000035:8k_2_02:81]
(Unaudited, in millions)

[0001262039-22-000035:8k_2_02:82]
|  | September 30,2022 |  | December 31,2021 |
| ASSETS |  |  |  |
| CURRENT ASSETS: |  |  |  |
| Cash and cash equivalents | $ | 964.0 |  |  | $ | 1,319.1 |  |
| Short-term investments | 739.5 |  |  | 1,194.0 |  |
| Marketable equity securities | 26.9 |  |  | 38.6 |  |
| Accounts receivable—net | 963.2 |  |  | 807.7 |  |
| Inventory | 215.8 |  |  | 175.8 |  |
| Prepaid expenses and other current assets | 72.8 |  |  | 65.4 |  |
| Total current assets | 2,982.2 |  |  | 3,600.6 |  |
| LONG-TERM INVESTMENTS | 84.0 |  |  | 440.8 |  |
| PROPERTY AND EQUIPMENT—NET | 889.5 |  |  | 687.6 |  |
| DEFERRED CONTRACT COSTS | 480.5 |  |  | 423.3 |  |
| DEFERRED TAX ASSETS | 515.5 |  |  | 342.3 |  |
| GOODWILL AND OTHER INTANGIBLE ASSETS—NET | 159.0 |  |  | 188.7 |  |
| OTHER ASSETS | 225.2 |  |  | 235.8 |  |
| TOTAL ASSETS | $ | 5,335.9 |  |  | $ | 5,919.1 |  |
| LIABILITIES AND EQUITY (DEFICIT) |  |  |  |
| CURRENT LIABILITIES: |  |  |  |
| Accounts payable | $ | 215.1 |  |  | $ | 148.4 |  |
| Accrued liabilities | 244.8 |  |  | 197.3 |  |
| Accrued payroll and compensation | 190.7 |  |  | 195.0 |  |
| Deferred revenue | 2,129.0 |  |  | 1,777.4 |  |
| Total current liabilities | 2,779.6 |  |  | 2,318.1 |  |
| DEFERRED REVENUE | 2,064.5 |  |  | 1,675.5 |  |
| INCOME TAX LIABILITIES | 67.8 |  |  | 79.5 |  |
| LONG-TERM DEBT | 989.9 |  |  | 988.4 |  |
| OTHER LIABILITIES | 56.9 |  |  | 59.2 |  |
| Total liabilities | 5,958.7 |  |  | 5,120.7 |  |
| COMMITMENTS AND CONTINGENCIES |  |  |  |
| EQUITY (DEFICIT): |  |  |  |
| Common stock | 0.8 |  |  | 0.8 |  |
| Additional paid-in capital | 1,250.2 |  |  | 1,253.6 |  |
| Accumulated other comprehensive loss | (25.5) |  |  | (4.8) |  |
| Accumulated deficit | (1,860.2) |  |  | (467.9) |  |
| Total Fortinet, Inc. stockholders’ equity (deficit) | (634.7) |  |  | 781.7 |  |
| Non-controlling interests | 11.9 |  |  | 16.7 |  |
| Total equity (deficit) | (622.8) |  |  | 798.4 |  |
| TOTAL LIABILITIES AND EQUITY (DEFICIT) | $ | 5,335.9 |  |  | $ | 5,919.1 |  |

[0001262039-22-000035:8k_2_02:83]
FORTINET, INC.

[0001262039-22-000035:8k_2_02:84]
CONDENSED CONSOLIDATED STATEMENTS OF INCOME

[0001262039-22-000035:8k_2_02:85]
(Unaudited, in millions, except per share amounts)

[0001262039-22-000035:8k_2_02:86]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30,2022 |  | September 30,2021 |  | September 30,2022 |  | September 30,2021 |
| REVENUE: |  |  |  |  |  |  |  |
| Product | $ | 468.7 |  |  | $ | 337.1 |  |  | $ | 1,240.4 |  |  | $ | 876.1 |  |
| Service | 680.8 |  |  | 530.1 |  |  | 1,894.0 |  |  | 1,502.5 |  |
| Total revenue | 1,149.5 |  |  | 867.2 |  |  | 3,134.4 |  |  | 2,378.6 |  |
| COST OF REVENUE: |  |  |  |  |  |  |  |
| Product | 185.2 |  |  | 134.3 |  |  | 501.4 |  |  | 341.2 |  |
| Service | 97.8 |  |  | 76.9 |  |  | 286.2 |  |  | 213.5 |  |
| Total cost of revenue | 283.0 |  |  | 211.2 |  |  | 787.6 |  |  | 554.7 |  |
| GROSS PROFIT: |  |  |  |  |  |  |  |
| Product | 283.5 |  |  | 202.8 |  |  | 739.0 |  |  | 534.9 |  |
| Service | 583.0 |  |  | 453.2 |  |  | 1,607.8 |  |  | 1,289.0 |  |
| Total gross profit | 866.5 |  |  | 656.0 |  |  | 2,346.8 |  |  | 1,823.9 |  |
| OPERATING EXPENSES: |  |  |  |  |  |  |  |
| Research and development | 134.3 |  |  | 107.8 |  |  | 383.5 |  |  | 311.6 |  |
| Sales and marketing | 427.1 |  |  | 347.1 |  |  | 1,230.2 |  |  | 978.0 |  |
| General and administrative | 40.7 |  |  | 35.8 |  |  | 124.7 |  |  | 102.2 |  |
| Gain on intellectual property matter | (1.1) |  |  | (1.1) |  |  | (3.4) |  |  | (3.4) |  |
| Total operating expenses | 601.0 |  |  | 489.6 |  |  | 1,735.0 |  |  | 1,388.4 |  |
| OPERATING INCOME | 265.5 |  |  | 166.4 |  |  | 611.8 |  |  | 435.5 |  |
| INTEREST INCOME | 4.6 |  |  | 1.2 |  |  | 8.3 |  |  | 3.5 |  |
| INTEREST EXPENSE | (4.5) |  |  | (4.6) |  |  | (13.5) |  |  | (10.4) |  |
| OTHER EXPENSE—NET | (0.9) |  |  | (6.3) |  |  | (19.3) |  |  | (7.5) |  |
| INCOME BEFORE INCOME TAXES AND LOSS FROM EQUITY METHOD INVESTMENT | 264.7 |  |  | 156.7 |  |  | 587.3 |  |  | 421.1 |  |
| PROVISION FOR (BENEFIT FROM) INCOME TAXES | 27.3 |  |  | (9.3) |  |  | 21.6 |  |  | 10.4 |  |
| LOSS FROM EQUITY METHOD INVESTMENT | (6.3) |  |  | (2.8) |  |  | (22.9) |  |  | (2.8) |  |
| NET INCOME INCLUDING NON-CONTROLLING INTERESTS | 231.1 |  |  | 163.2 |  |  | 542.8 |  |  | 407.9 |  |
| Less: NET INCOME (LOSS) ATTRIBUTABLE TO NON-CONTROLLING INTERESTS, NET OF TAX | (0.5) |  |  | 0.1 |  |  | (0.7) |  |  | 0.1 |  |
| NET INCOME ATTRIBUTABLE TO FORTINET, INC. | $ | 231.6 |  |  | $ | 163.1 |  |  | $ | 543.5 |  |  | $ | 407.8 |  |
| Net income per share attributable to Fortinet, Inc. (a): |  |  |  |  |  |  |  |
| Basic | $ | 0.29 |  |  | $ | 0.20 |  |  | $ | 0.68 |  |  | $ | 0.50 |  |
| Diluted | $ | 0.29 |  |  | $ | 0.19 |  |  | $ | 0.67 |  |  | $ | 0.49 |  |
| Weighted-average shares used to compute net income per share attributable to Fortinet, Inc. (a): |  |  |  |  |  |  |  |
| Basic | 786.2 |  |  | 817.7 |  |  | 795.0 |  |  | 816.5 |  |
| Diluted | 798.6 |  |  | 838.6 |  |  | 809.8 |  |  | 835.4 |  |

[0001262039-22-000035:8k_2_02:87]
(a) All share and per share amounts presented herein have been retroactively adjusted to reflect the five-for-one forward stock split which was effective June 22, 2022.

[0001262039-22-000035:8k_2_02:88]
FORTINET, INC.

[0001262039-22-000035:8k_2_02:89]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001262039-22-000035:8k_2_02:90]
(Unaudited, in millions)

[0001262039-22-000035:8k_2_02:91]
|  | Nine Months Ended |
|  | September 30,2022 |  | September 30,2021 |
| CASH FLOWS FROM OPERATING ACTIVITIES: |  |  |  |
| Net income including non-controlling interests | $ | 542.8 |  |  | $ | 407.9 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |
| Stock-based compensation | 162.6 |  |  | 154.8 |  |
| Amortization of deferred contract costs | 163.8 |  |  | 126.9 |  |
| Depreciation and amortization | 77.0 |  |  | 59.1 |  |
| Amortization of investment premiums | 3.6 |  |  | 4.8 |  |
| Loss from equity method investment | 22.9 |  |  | 2.8 |  |
| Other | 21.2 |  |  | 4.4 |  |
| Changes in operating assets and liabilities, net of impact of business combinations: |  |  |  |
| Accounts receivable—net | (162.7) |  |  | 130.6 |  |
| Inventory | (59.7) |  |  | (19.5) |  |
| Prepaid expenses and other current assets | (7.6) |  |  | (12.5) |  |
| Deferred contract costs | (221.0) |  |  | (201.0) |  |
| Deferred tax assets | (172.0) |  |  | (91.9) |  |
| Other assets | (13.9) |  |  | (15.7) |  |
| Accounts payable | 78.6 |  |  | (11.8) |  |
| Accrued liabilities | 27.8 |  |  | 77.0 |  |
| Accrued payroll and compensation | (3.2) |  |  | 23.1 |  |
| Other liabilities | (0.5) |  |  | (3.2) |  |
| Deferred revenue | 742.8 |  |  | 497.1 |  |
| Net cash provided by operating activities | 1,202.5 |  |  | 1,132.9 |  |
| CASH FLOWS FROM INVESTING ACTIVITIES: |  |  |  |
| Purchases of investments | (389.1) |  |  | (1,749.9) |  |
| Sales of investments | 3.0 |  |  | 82.2 |  |
| Maturities of investments | 1,182.9 |  |  | 1,029.0 |  |
| Purchases of property and equipment | (250.3) |  |  | (144.6) |  |
| Purchases of investment in privately held company | — |  |  | (160.0) |  |
| Payments made in connection with business combinations, net of cash acquired | — |  |  | (73.4) |  |
| Purchases of marketable equity securities | — |  |  | (42.5) |  |
| Net cash provided by (used in) investing activities | 546.5 |  |  | (1,059.2) |  |
| CASH FLOWS FROM FINANCING ACTIVITIES: |  |  |  |
| Proceeds from long-term borrowings, net of discount and underwriting fees | — |  |  | 989.4 |  |
| Payments for debt issuance costs | — |  |  | (2.4) |  |
| Payments of debt assumed in connection with business combination | — |  |  | (2.2) |  |
| Repurchase and retirement of common stock | (1,991.2) |  |  | (170.0) |  |
| Proceeds from issuance of common stock | 21.7 |  |  | 20.7 |  |
| Taxes paid related to net share settlement of equity awards | (132.1) |  |  | (118.9) |  |
| Other | (1.3) |  |  | (0.2) |  |
| Net cash provided by (used in) financing activities | (2,102.9) |  |  | 716.4 |  |
| EFFECT OF EXCHANGE RATE CHANGES ON CASH AND CASH EQUIVALENTS | (1.2) |  |  | 0.2 |  |
| NET INCREASE (DECREASE) IN CASH AND CASH EQUIVALENTS | (355.1) |  |  | 790.3 |  |
| CASH AND CASH EQUIVALENTS—Beginning of period | 1,319.1 |  |  | 1,061.8 |  |
| CASH AND CASH EQUIVALENTS—End of period | $ | 964.0 |  |  | $ | 1,852.1 |  |

[0001262039-22-000035:8k_2_02:92]
Reconciliations of non-GAAP results of operations measures to the nearest comparable GAAP measures

[0001262039-22-000035:8k_2_02:93]
(Unaudited, in millions, except per share amounts)

[0001262039-22-000035:8k_2_02:94]
Reconciliation of net cash provided by operating activities to free cash flow

[0001262039-22-000035:8k_2_02:95]
|  | Three Months Ended |
|  | September 30,2022 |  | September 30,2021 |
| Net cash provided by operating activities | $ | 483.0 |  |  | $ | 398.8 |  |
| Less: Purchases of property and equipment | (87.8) |  |  | (69.0) |  |
| Free cash flow | $ | 395.2 |  |  | $ | 329.8 |  |
| Net cash provided by (used in) investing activities | $ | 297.8 |  |  | $ | (307.5) |  |
| Net cash used in financing activities | $ | (526.6) |  |  | $ | (118.7) |  |

[0001262039-22-000035:8k_2_02:96]
Reconciliation of GAAP operating income to non-GAAP operating income, operating margin, net income attributable to Fortinet, Inc. and diluted net income per share attributable to Fortinet, Inc.

[0001262039-22-000035:8k_2_02:97]
|  | Three Months Ended September 30, 2022 |  | Three Months Ended September 30, 2021 |
|  | GAAP Results |  | Adjustments |  | Non-GAAP Results |  | GAAP Results |  | Adjustments |  | Non-GAAP Results |
| Operating income | $ | 265.5 |  |  | $ | 59.4 |  | (a) | $ | 324.9 |  |  | $ | 166.4 |  |  | $ | 57.2 |  | (b) | $ | 223.6 |  |
| Operating margin | 23.1 | % |  |  |  | 28.3 | % |  | 19.2 | % |  |  |  | 25.8 | % |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | 55.3 |  |  |  |  |  |  | 53.5 |  |  |  |
| Amortization of acquired intangible assets |  |  | 5.2 |  |  |  |  |  |  | 4.8 |  |  |  |
| Gain on intellectual property matter |  |  | (1.1) |  |  |  |  |  |  | (1.1) |  |  |  |
| Tax adjustment |  |  | (27.8) |  | (c) |  |  |  |  | (54.2) |  | (c) |  |
| Adjustments attributable non-controlling interests |  |  | (0.5) |  | (d) |  |  |  |  | (0.2) |  | (d) |  |
| Net income attributable to Fortinet, Inc. | $ | 231.6 |  |  | $ | 31.1 |  |  | $ | 262.7 |  |  | $ | 163.1 |  |  | $ | 2.8 |  |  | $ | 165.9 |  |
| Diluted net income per share attributable to Fortinet, Inc.(e) | $ | 0.29 |  |  |  |  | $ | 0.33 |  |  | $ | 0.19 |  |  |  |  | $ | 0.20 |  |
| Shares used in diluted net income per share attributable to Fortinet, Inc. calculations (e) | 798.6 |  |  |  |  | 798.6 |  |  | 838.6 |  |  |  |  | 838.6 |  |

[0001262039-22-000035:8k_2_02:98]
(a) To exclude $55.3 million of stock-based compensation and $5.2 million of amortization of acquired intangible assets, offset by a $1.1 million gain on intellectual property matter in the three months ended September 30, 2022.

[0001262039-22-000035:8k_2_02:99]
(b) To exclude $53.5 million of stock-based compensation and $4.8 million of amortization of acquired intangible assets, offset by a $1.1 million gain on intellectual property matter in the three months ended September 30, 2021.

[0001262039-22-000035:8k_2_02:100]
(c) Non-GAAP financial information is adjusted to an effective tax rate of 17% and 21% in the three months ended September 30, 2022 and 2021, respectively, on a non-GAAP basis, which differs from the GAAP effective tax rate.

[0001262039-22-000035:8k_2_02:101]
(d) Adjustments related to the non-GAAP results attributable to non-controlling interests, which were adjusted to an effective tax rate of 31% for the subsidiary of Alaxala Networks Corporation in the three months ended September 30, 2022 and 2021.

[0001262039-22-000035:8k_2_02:102]
(e) All share and per share amounts presented herein have been retroactively adjusted to reflect the five-for-one forward stock split which was effective June 22, 2022.

[0001262039-22-000035:8k_2_02:103]
Reconciliation of total revenue to total billings

[0001262039-22-000035:8k_2_02:104]
|  | Three Months Ended |
|  | September 30,2022 |  | September 30,2021 |
| Total revenue | $ | 1,149.5 |  |  | $ | 867.2 |  |
| Add: Change in deferred revenue | 261.5 |  |  | 201.0 |  |
| Less: Deferred revenue balance acquired in business combination | — |  |  | (4.1) |  |
| Total billings | $ | 1,411.0 |  |  | $ | 1,064.1 |  |

[0001262039-22-000035:8k_2_02:105]
| Investor Contact: |  | Media Contact: |
| Peter Salkowski |  | John Welton |
| Fortinet, Inc. |  | Fortinet, Inc. |
| 408-331-4595 |  | 408-235-7700 |
| psalkowski@fortinet.com |  | pr@fortinet.com |
