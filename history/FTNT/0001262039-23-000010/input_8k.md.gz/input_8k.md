# FTNT 8-K — 0001262039-23-000003 filed 2023-02-07

## item codes, every 8-K on or before 2023-02-24

- 2023-02-08 0001262039-23-000006 — 5.03, 9.01
- 2023-02-07 0001262039-23-000003 — 2.02, 9.01
- 2022-11-02 0001262039-22-000035 — 2.02, 9.01
- 2022-08-03 0001262039-22-000026 — 2.02, 9.01
- 2022-06-22 0001262039-22-000023 — 5.03, 9.01
- 2022-06-21 0001262039-22-000021 — 5.07
- 2022-05-04 0001262039-22-000015 — 2.02, 9.01
- 2022-05-02 0001262039-22-000012 — 5.02
- 2022-04-22 0001262039-22-000010 — 8.01
- 2022-02-03 0001262039-22-000005 — 2.02, 9.01
- 2022-01-26 0001262039-22-000002 — 5.02, 9.01 — amendment, the index does not say of what
- 2021-11-04 0001262039-21-000027 — 2.02, 9.01
- 2021-10-06 0001262039-21-000024 — 5.02, 9.01
- 2021-07-29 0001262039-21-000019 — 2.02, 9.01
- 2021-06-23 0001262039-21-000016 — 5.07
- 2021-04-30 0001104659-21-059008 — 5.03 — amendment, the index does not say of what
- 2021-04-29 0001262039-21-000011 — 2.02, 9.01
- 2021-04-28 0001104659-21-056360 — 5.02, 5.03, 9.01
- 2021-03-05 0001193125-21-071498 — 1.01, 9.01
- 2021-02-25 0001193125-21-057281 — 1.01, 9.01
- 2021-02-04 0001262039-21-000005 — 2.02, 9.01
- 2020-12-08 0001262039-20-000070 — 8.01
- 2020-10-29 0001262039-20-000063 — 2.02, 9.01
- 2020-10-20 0001262039-20-000060 — 5.02 — amendment, the index does not say of what
- 2020-08-26 0001262039-20-000056 — 5.02, 9.01
- 2020-08-06 0001262039-20-000051 — 2.02, 9.01
- 2020-07-21 0001262039-20-000044 — 5.03, 8.01, 9.01
- 2020-06-24 0001262039-20-000038 — 5.07
- 2020-05-06 0001262039-20-000029 — 2.02, 9.01
- 2020-04-23 0001262039-20-000025 — 5.03, 9.01
- 2020-04-23 0001262039-20-000024 — 5.02 — amendment of 0001262039-20-000025
- 2020-02-28 0001262039-20-000015 — 5.02, 9.01
- 2020-02-06 0001262039-20-000004 — 2.02, 9.01
- 2019-12-12 0001262039-19-000038 — 8.01
- 2019-10-31 0001262039-19-000032 — 2.02, 9.01
- 2019-10-28 0001262039-19-000027 — 8.01
- 2019-10-23 0001262039-19-000025 — 5.02, 9.01
- 2019-08-01 0001262039-19-000021 — 2.02, 9.01
- 2019-06-26 0001262039-19-000018 — 5.07
- 2019-05-02 0001262039-19-000010 — 2.02, 9.01
- 2019-02-06 0001262039-19-000002 — 2.02, 9.01
- 2018-11-01 0001262039-18-000037 — 2.02, 9.01
- 2018-10-23 0001262039-18-000035 — 8.01
- 2018-08-01 0001262039-18-000025 — 2.02, 9.01
- 2018-06-28 0001262039-18-000023 — 5.03, 5.07, 9.01
- 2018-06-04 0001262039-18-000021 — 8.01
- 2018-05-03 0001262039-18-000017 — 2.02, 5.02, 9.01
- 2018-02-05 0001262039-18-000004 — 2.02, 5.02, 9.01
- 2017-10-26 0001262039-17-000031 — 2.02, 9.01
- 2017-10-19 0001262039-17-000029 — 5.02 — amendment, the index does not say of what
- 2017-07-26 0001262039-17-000025 — 2.02, 9.01
- 2017-06-27 0001262039-17-000023 — 5.07
- 2017-05-31 0001262039-17-000021 — 5.02 — amendment of 0001262039-17-000019
- 2017-05-30 0001262039-17-000019 — 5.02, 9.01
- 2017-04-27 0001262039-17-000013 — 2.02, 9.01
- 2017-02-02 0001262039-17-000003 — 2.02, 9.01
- 2016-10-27 0001262039-16-000085 — 2.02, 9.01
- 2016-10-11 0001262039-16-000082 — 2.02, 9.01
- 2016-07-28 0001262039-16-000076 — 2.02, 9.01
- 2016-07-22 0001262039-16-000073 — 8.01, 9.01
- 2016-06-20 0001262039-16-000068 — 5.07
- 2016-06-07 0001193125-16-614788 — 8.01
- 2016-04-26 0001262039-16-000061 — 2.02, 9.01
- 2016-01-28 0001262039-16-000051 — 2.02, 9.01
- 2015-10-27 0001262039-15-000045 — 2.02
- 2015-10-22 0001262039-15-000042 — 5.02 — amendment, the index does not say of what
- 2015-10-22 0001262039-15-000041 — 5.02 — amendment, the index does not say of what
- 2015-10-22 0001262039-15-000039 — 2.02, 9.01
- 2015-09-28 0001262039-15-000034 — 5.02, 9.01
- 2015-09-22 0001262039-15-000031 — 9.01 — amendment of 0001193125-15-248065
- 2015-08-28 0001262039-15-000027 — 3.01, 5.02
- 2015-07-23 0001262039-15-000021 — 5.02
- 2015-07-22 0001262039-15-000019 — 2.02, 9.01
- 2015-07-08 0001193125-15-248065 — 2.01, 8.01, 9.01
- 2015-06-22 0001193125-15-229099 — 5.07
- 2015-06-19 0001193125-15-228428 — 5.02, 9.01
- 2015-04-20 0001262039-15-000014 — 2.02, 9.01
- 2015-01-28 0001262039-15-000005 — 2.02, 9.01
- 2014-10-22 0001262039-14-000036 — 2.02, 9.01
- 2014-07-23 0001262039-14-000030 — 2.02, 9.01
- 2014-06-24 0001262039-14-000027 — 5.07
- 2014-04-23 0001262039-14-000021 — 2.02, 9.01
- 2014-04-21 0001262039-14-000018 — 5.03, 9.01
- 2014-01-29 0001262039-14-000004 — 2.02, 9.01
- 2013-12-20 0001262039-13-000061 — 5.02, 9.01
- 2013-11-27 0001262039-13-000057 — 5.02, 7.01, 9.01
- 2013-11-12 0001445305-13-002993 — 5.02
- 2013-10-23 0001262039-13-000051 — 2.02, 9.01
- 2013-07-30 0001262039-13-000039 — 2.02, 9.01
- 2013-06-25 0001262039-13-000030 — 5.07
- 2013-04-30 0001262039-13-000023 — 2.02, 9.01
- 2013-04-19 0001262039-13-000020 — 5.02, 9.01
- 2013-04-19 0001262039-13-000018 — 5.02 — amendment of 0001262039-13-000020
- 2013-04-10 0001262039-13-000016 — 2.02, 9.01
- 2013-03-26 0001262039-13-000013 — 5.02
- 2013-01-30 0001262039-13-000005 — 2.02, 9.01
- 2013-01-24 0001262039-13-000002 — 5.02, 9.01
- 2012-10-16 0001262039-12-000048 — 2.02, 9.01
- 2012-10-01 0001262039-12-000045 — 5.02
- 2012-09-26 0001262039-12-000043 — 5.01
- 2012-07-25 0001262039-12-000038 — 2.02, 9.01
- 2012-07-19 0001262039-12-000034 — 5.02
- 2012-06-20 0001193125-12-275869 — 5.07
- 2012-04-27 0001262039-12-000029 — 5.02
- 2012-04-24 0001262039-12-000025 — 2.02, 9.01
- 2012-01-31 0001262039-12-000006 — 2.02, 9.01
- 2012-01-25 0001262039-12-000003 — 5.03
- 2011-10-24 0001262039-11-000036 — 2.02
- 2011-07-19 0001262039-11-000014 — 2.02, 9.01
- 2011-06-27 0001193125-11-174474 — 5.02, 5.07, 9.01
- 2011-04-27 0001193125-11-111938 — 2.02, 9.01
- 2011-01-25 0001193125-11-013914 — 2.02, 9.01
- 2010-10-21 0001193125-10-233676 — 2.02, 9.01
- 2010-09-02 0001193125-10-203099 — 8.01
- 2010-07-22 0001193125-10-163844 — 2.02, 9.01
- 2010-06-24 0001193125-10-146082 — 5.07
- 2010-04-28 0001193125-10-096698 — 2.02, 9.01
- 2010-02-09 0001193125-10-024614 — 8.01
- 2010-01-27 0001193125-10-014292 — 2.02, 9.01
- 2010-01-26 0001193125-10-013031 — 5.02, 9.01

## late-filing notifications on or before 2023-02-24

- none on or before 2023-02-24

## item 2.02 — earnings release, exhibit 99.1

[0001262039-23-000003:8k_2_02:1]
EX-99.1
2
ftntq4-2022ex991.htm
PRESS RELEASE

[0001262039-23-000003:8k_2_02:2]
Document

[0001262039-23-000003:8k_2_02:3]
Press Release

[0001262039-23-000003:8k_2_02:4]
Fortinet Reports Fourth Quarter and Full Year 2022 Financial Results

[0001262039-23-000003:8k_2_02:5]
Fourth Quarter 2022 Highlights

[0001262039-23-000003:8k_2_02:6]
•Product revenue of $540.1 million, up 43% year over year

[0001262039-23-000003:8k_2_02:7]
•Service revenue of $742.9 million, up 27% year over year

[0001262039-23-000003:8k_2_02:8]
•Total revenue of $1.28 billion, up 33% year over year

[0001262039-23-000003:8k_2_02:9]
•Billings of $1.72 billion, up 32% year over year1

[0001262039-23-000003:8k_2_02:10]
•GAAP operating income of $357.8 million, up 66% year over year

[0001262039-23-000003:8k_2_02:11]
•Non-GAAP operating income of $417.6 million, up 52% year over year1

[0001262039-23-000003:8k_2_02:12]
•GAAP operating margin of 27.9%

[0001262039-23-000003:8k_2_02:13]
•Non-GAAP operating margin of 32.5%1

[0001262039-23-000003:8k_2_02:14]
•GAAP diluted net income per share attributable to Fortinet, Inc. of $0.40, up 67% year over year2

[0001262039-23-000003:8k_2_02:15]
•Non-GAAP diluted net income per share attributable to Fortinet, Inc. of $0.44, up 76% year over year1 2

[0001262039-23-000003:8k_2_02:16]
•Cash flow from operations of $528.1 million

[0001262039-23-000003:8k_2_02:17]
•Free cash flow of $497.2 million1

[0001262039-23-000003:8k_2_02:18]
Full Year 2022 Highlights

[0001262039-23-000003:8k_2_02:19]
•Product revenue of $1.78 billion, up 42% year over year

[0001262039-23-000003:8k_2_02:20]
•Service revenue of $2.64 billion, up 26% year over year

[0001262039-23-000003:8k_2_02:21]
•Total revenue of $4.42 billion, up 32% year over year

[0001262039-23-000003:8k_2_02:22]
•Billings of $5.59 billion, up 34% year over year1

[0001262039-23-000003:8k_2_02:23]
•Deferred revenue of $4.64 billion, up 34% year over year

[0001262039-23-000003:8k_2_02:24]
•GAAP operating income of $969.6 million, up 49% year over year

[0001262039-23-000003:8k_2_02:25]
•Non-GAAP operating income of $1.21 billion, up 38% year over year1

[0001262039-23-000003:8k_2_02:26]
•GAAP operating margin of 21.9%

[0001262039-23-000003:8k_2_02:27]
•Non-GAAP operating margin of 27.3%1

[0001262039-23-000003:8k_2_02:28]
•GAAP diluted net income per share attributable to Fortinet, Inc. of $1.06, up 45% year over year2

[0001262039-23-000003:8k_2_02:29]
•Non-GAAP diluted net income per share attributable to Fortinet, Inc. of $1.19, up 49% year over year1 2

[0001262039-23-000003:8k_2_02:30]
•Cash flow from operations of $1.73 billion

[0001262039-23-000003:8k_2_02:31]
•Free cash flow of $1.45 billion1

[0001262039-23-000003:8k_2_02:32]
•Cash paid for share repurchases of $1.99 billion

[0001262039-23-000003:8k_2_02:33]
SUNNYVALE, Calif. - February 7, 2023 - Fortinet® (Nasdaq: FTNT), a global leader in broad, integrated and automated cybersecurity solutions, today announced financial results for the fourth quarter and full year ended December 31, 2022.

[0001262039-23-000003:8k_2_02:34]
“Total revenue grew 32% in 2022 and year-over-year to $4.42 billion, and we generated GAAP net income of $857.3 million. This marks the 14th consecutive year that we have been GAAP profitable, including every year since our 2009 IPO. Cash flow from operations was $1.73 billion

[0001262039-23-000003:8k_2_02:35]
and free cash flow was a Fortinet record of $1.45 billion for the year,” said Ken Xie, Founder, Chairman and Chief Executive Officer. “Our market share gains are being driven by Fortinet's integrated and single platform approach to cybersecurity combined with FortiASIC technology, which lowers the management costs and the total cost of ownership for organizations. Given our cost-for-performance advantage, the convergence of security and networking, and the consolidation of products and vendors, we expect to continue our solid growth trajectory.”

[0001262039-23-000003:8k_2_02:36]
Financial Highlights for the Fourth Quarter of 2022

[0001262039-23-000003:8k_2_02:37]
•Product Revenue: Product revenue was $540.1 million for the fourth quarter of 2022, an increase of 42.5% compared to $378.9 million for the same quarter of 2021.

[0001262039-23-000003:8k_2_02:38]
•Service Revenue: Service revenue was $742.9 million for the fourth quarter of 2022, an increase of 27.1% compared to $584.7 million for the same quarter of 2021.

[0001262039-23-000003:8k_2_02:39]
•Revenue: Total revenue was $1.28 billion for the fourth quarter of 2022, an increase of 33.1% compared to $963.6 million for the same quarter of 2021.

[0001262039-23-000003:8k_2_02:40]
•Billings1: Total billings were $1.72 billion for the fourth quarter of 2022, an increase of 31.6% compared to $1.31 billion for the same quarter of 2021.

[0001262039-23-000003:8k_2_02:41]
•GAAP Operating Income and Margin: GAAP operating income was $357.8 million for the fourth quarter of 2022, representing a GAAP operating margin of 27.9%. GAAP operating income was $214.9 million for the same quarter of 2021, representing a GAAP operating margin of 22.3%.

[0001262039-23-000003:8k_2_02:42]
•Non-GAAP Operating Income and Margin1: Non-GAAP operating income was $417.6 million for the fourth quarter of 2022, representing a non-GAAP operating margin of 32.5%. Non-GAAP operating income was $274.7 million for the same quarter of 2021, representing a non-GAAP operating margin of 28.5%.

[0001262039-23-000003:8k_2_02:43]
•GAAP Net Income and Diluted Net Income Per Share Attributable to Fortinet, Inc.2: GAAP net income was $313.8 million for the fourth quarter of 2022, compared to GAAP net income of $199.0 million for the same quarter of 2021. GAAP diluted net income per share was $0.40 for the fourth quarter of 2022, based on 791.8 million diluted weighted-average shares outstanding, compared to GAAP diluted net income per share of $0.24 for the same quarter of 2021, based on 835.0 million diluted weighted-average shares outstanding.

[0001262039-23-000003:8k_2_02:44]
•Non-GAAP Net Income and Diluted Net Income Per Share Attributable to Fortinet, Inc.1 2: Non-GAAP net income was $349.7 million for the fourth quarter of 2022, compared to non-GAAP net income of $205.8 million for the same quarter of 2021. Non-GAAP diluted net income per share was $0.44 for the fourth quarter of 2022, based on 791.8 million diluted weighted-average shares outstanding, compared to $0.25 for the same quarter of 2021, based on 835.0 million diluted weighted-average shares outstanding.

[0001262039-23-000003:8k_2_02:45]
•Cash Flow: Cash flow from operations was $528.1 million for the fourth quarter of 2022, compared to $366.8 million for the same quarter of 2021.

[0001262039-23-000003:8k_2_02:46]
•Free Cash Flow1: Free cash flow was $497.2 million for the fourth quarter of 2022, compared to $215.5 million for the same quarter of 2021.

[0001262039-23-000003:8k_2_02:47]
Financial Highlights for the Full Year 2022

[0001262039-23-000003:8k_2_02:48]
•Product Revenue: Product revenue was $1.78 billion for 2022, an increase of 41.9% compared to $1.26 billion in 2021.

[0001262039-23-000003:8k_2_02:49]
•Service Revenue: Service revenue was $2.64 billion for 2022, an increase of 26.3% compared to $2.09 billion in 2021.

[0001262039-23-000003:8k_2_02:50]
•Revenue: Total revenue was $4.42 billion for 2022, an increase of 32.2% compared to $3.34 billion in 2021.

[0001262039-23-000003:8k_2_02:51]
•Billings1: Total billings were $5.59 billion for 2022, an increase of 33.8% compared to $4.18 billion in 2021.

[0001262039-23-000003:8k_2_02:52]
•Deferred Revenue: Total deferred revenue was $4.64 billion as of December 31, 2022, an increase of 34.4% compared to $3.45 billion as of December 31, 2021.

[0001262039-23-000003:8k_2_02:53]
•GAAP Operating Income and Margin: GAAP operating income was $969.6 million for  2022, representing a GAAP operating margin of 21.9%. GAAP operating income was $650.4 million for 2021, representing a GAAP operating margin of 19.5%.

[0001262039-23-000003:8k_2_02:54]
•Non-GAAP Operating Income and Margin1: Non-GAAP operating income was $1.21 billion for 2022, representing a non-GAAP operating margin of 27.3%. Non-GAAP operating income was $875.5 million for 2021, representing a non-GAAP operating margin of 26.2%.

[0001262039-23-000003:8k_2_02:55]
•GAAP Net Income and Diluted Net Income Per Share Attributable to Fortinet, Inc.2: GAAP net income was $857.3 million for 2022, compared to GAAP net income of $606.8 million for 2021. GAAP diluted net income per share was $1.06 for 2022, based on 805.3 million diluted weighted-average shares outstanding, compared to GAAP diluted net income per share of $0.73 for 2021, based on 835.3 million diluted weighted-average shares outstanding.

[0001262039-23-000003:8k_2_02:56]
•Non-GAAP Net Income and Diluted Net Income Per Share Attributable to Fortinet, Inc.1 2: Non-GAAP net income was $961.6 million for 2022, compared to non-GAAP net income of $666.0 million for 2021. Non-GAAP diluted net income per share was $1.19 for 2022, based on 805.3 million diluted weighted-average shares outstanding, compared to $0.80 for 2021, based on 835.3 million diluted weighted-average shares outstanding.

[0001262039-23-000003:8k_2_02:57]
•Cash Flow: Cash flow from operations was $1.73 billion in 2022 compared to $1.50 billion in 2021.

[0001262039-23-000003:8k_2_02:58]
•Free Cash Flow1: Free cash flow was $1.45 billion in 2022, compared to $1.20 billion in 2021.

[0001262039-23-000003:8k_2_02:59]
•Share Repurchase Program2: During the year ended December 31, 2022 and 2021, Fortinet repurchased 36.0 million and 12.9 million shares of its common stock at an average price of $55.37 and $57.45 per share, respectively, and for an aggregate purchase price of  $1.99 billion and $741.8 million, respectively.

[0001262039-23-000003:8k_2_02:60]
Guidance

[0001262039-23-000003:8k_2_02:61]
For the first quarter of 2023, Fortinet currently expects:

[0001262039-23-000003:8k_2_02:62]
•Revenue in the range of $1.180 billion to $1.220 billion

[0001262039-23-000003:8k_2_02:63]
•Billings in the range of $1.415 billion to $1.465 billion

[0001262039-23-000003:8k_2_02:64]
•Non-GAAP gross margin in the range of 75.0% to 76.0%

[0001262039-23-000003:8k_2_02:65]
•Non-GAAP operating margin in the range of 23.0% to 24.0%

[0001262039-23-000003:8k_2_02:66]
•Diluted non-GAAP net income per share attributable to Fortinet, Inc. in the range of $0.27 to $0.29, assuming a non-GAAP effective tax rate of 17%. This assumes a diluted share count of 795 million to 805 million.

[0001262039-23-000003:8k_2_02:67]
For the fiscal year 2023, Fortinet currently expects:

[0001262039-23-000003:8k_2_02:68]
•Revenue in the range of $5.370 billion to $5.430 billion

[0001262039-23-000003:8k_2_02:69]
•Service revenue in the range of $3.335 billion to $3.365 billion

[0001262039-23-000003:8k_2_02:70]
•Billings in the range of $6.710 billion to $6.790 billion

[0001262039-23-000003:8k_2_02:71]
•Non-GAAP gross margin in the range of 75.0% to 76.0%

[0001262039-23-000003:8k_2_02:72]
•Non-GAAP operating margin in the range of 25.0% to 26.0%

[0001262039-23-000003:8k_2_02:73]
•Diluted non-GAAP net income per share attributable to Fortinet, Inc. in the range of $1.39 to $1.41, assuming a non-GAAP effective tax rate of 17%. This assumes a diluted share count of 805 million to 815 million.

[0001262039-23-000003:8k_2_02:74]
Our guidance with respect to non-GAAP financial measures excludes stock-based compensation, amortization of acquired intangible assets and gain on intellectual property matters. We have not reconciled our guidance with respect to non-GAAP financial measures to the corresponding GAAP measures because certain items that impact these measures are uncertain or out of our control, or cannot be reasonably predicted. Accordingly, a reconciliation of these non-GAAP financial measures to the corresponding GAAP measures is not available without unreasonable effort.

[0001262039-23-000003:8k_2_02:75]
1 A reconciliation of GAAP to non-GAAP measures has been provided in the financial statement tables included in this press release. An explanation of these measures is also included below under the heading “Non-GAAP Financial Measures”.

[0001262039-23-000003:8k_2_02:76]
2 All share and per share amounts presented herein have been retroactively adjusted to reflect the five-for-one forward stock split which was effective June 22, 2022.

[0001262039-23-000003:8k_2_02:77]
Conference Call Details

[0001262039-23-000003:8k_2_02:78]
Fortinet will host a conference call today at 1:30 p.m. Pacific Time (4:30 p.m. Eastern Time) to discuss the earnings results. A live webcast of the conference call and supplemental slides will be accessible from the Investor Relations page of Fortinet’s website at https://investor.fortinet.com and a replay will be archived and accessible at https://investor.fortinet.com/events-and-presentations.

[0001262039-23-000003:8k_2_02:79]
First Quarter 2023 Conference Participation Schedule:

[0001262039-23-000003:8k_2_02:80]
•Baird’s Silicon Slopes Event

[0001262039-23-000003:8k_2_02:81]
March 2, 2023

[0001262039-23-000003:8k_2_02:82]
•Morgan Stanley Technology, Media & Telecom Conference

[0001262039-23-000003:8k_2_02:83]
March 7, 2023

[0001262039-23-000003:8k_2_02:84]
Members of Fortinet’s management team are expected to present at these conferences and discuss the latest company strategies and initiatives. Fortinet’s conference presentations are expected to be available via webcast on the company’s web site. To access the most updated information, pre-register and listen to the webcast of each event, please visit the Investor Presentation & Events page of Fortinet’s website at https://investor.fortinet.com/events-and-presentations. The schedule is subject to change.

[0001262039-23-000003:8k_2_02:85]
About Fortinet (www.fortinet.com)

[0001262039-23-000003:8k_2_02:86]
Fortinet (NASDAQ: FTNT) makes possible a digital world that we can trust through its mission to protect people, devices and data everywhere. This is why many of the world’s largest enterprises, service providers and government organizations choose Fortinet to securely accelerate their digital journey. The Fortinet Core Platform and Platform Extension products deliver broad, integrated and automated protections across the entire digital attack surface, securing critical devices, data, applications, and connections from the data center to the cloud to the home office. The Fortinet NSE Training Institute, an initiative of Fortinet’s Training Advancement Agenda, provides one of the largest and broadest training programs in the industry to make cyber training and new career opportunities available to everyone. Learn more at https://www.fortinet.com, the Fortinet Blog or FortiGuard Labs.

[0001262039-23-000003:8k_2_02:87]
#          #          #

[0001262039-23-000003:8k_2_02:88]
Copyright © 2022 Fortinet, Inc. All rights reserved. The symbols ® and ™ denote respectively federally registered trademarks and common law trademarks of Fortinet, Inc., its subsidiaries and affiliates. Fortinet’s trademarks include, but are not limited to, the following: Fortinet, the Fortinet logo, FortiGate, FortiOS, FortiGuard, FortiCare, FortiAnalyzer, FortiManager, FortiASIC, FortiClient, FortiCloud, FortiMail, FortiSandbox, FortiADC, FortiAI, FortiAIOps, FortiAntenna, FortiAP, FortiAPCam, FortiAuthenticator, FortiCache, FortiCall, FortiCam, FortiCamera, FortiCarrier, FortiCASB, FortiCentral, FortiCNP, FortiConnect, FortiController, FortiConverter, FortiCWP, FortiDB, FortiDDoS, FortiDeceptor, FortiDeploy, FortiDevSec, FortiEDR, FortiExplorer, FortiExtender, FortiFirewall, FortiFone, FortiGSLB, FortiGuest, FortiHypervisor, FortiInsight, FortiIsolator, FortiLAN, FortiLink, FortiMonitor, FortiNAC, FortiNDR, FortiPenTest, FortiPhish, FortiPolicy, FortiPortal, FortiPresence, FortiProxy, FortiRecon, FortiRecorder, FortiSASE, FortiSDNConnector, FortiSIEM, FortiSMS, FortiSOAR, FortiSwitch, FortiTester, FortiToken, FortiTrust, FortiVoice, FortiWAN, FortiWeb, FortiWiFi, FortiWLC, FortiWLM and FortiXDR. Other trademarks belong to their respective owners. Fortinet has not independently verified statements or certifications herein attributed to third parties and Fortinet does not independently endorse such statements. Notwithstanding anything to the contrary herein, nothing herein constitutes a warranty, guarantee, contract, binding specification or other binding commitment by Fortinet or any indication of intent related to a binding commitment, and performance and other specification information herein may be unique to certain environments.

[0001262039-23-000003:8k_2_02:89]
FTNT-F

[0001262039-23-000003:8k_2_02:90]
Forward-Looking Statements

[0001262039-23-000003:8k_2_02:91]
This press release contains forward-looking statements that involve risks and uncertainties. These forward-looking statements include statements regarding any indications related to future market share gains, guidance and expectations around future financial results, including guidance and expectations for the first quarter and full year 2023, statements regarding the momentum in our business and future growth expectations, and any statements regarding our market opportunity and market size, and business momentum. Although we attempt to be

[0001262039-23-000003:8k_2_02:92]
Non-GAAP Financial Measures

[0001262039-23-000003:8k_2_02:93]
We have provided in this release financial information that has not been prepared in accordance with U.S. Generally Accepted Accounting Principles (GAAP). These non-GAAP financial and liquidity measures are not based on any standardized methodology prescribed by GAAP and are not necessarily comparable to similar measures presented by other companies. We use

[0001262039-23-000003:8k_2_02:94]
these non-GAAP financial measures internally in analyzing our financial results and believe they are useful to investors, as a supplement to GAAP measures, in evaluating our ongoing operational performance. We believe that the use of these non-GAAP financial measures provides an additional tool for investors to use in evaluating ongoing operating results and trends and in comparing our financial results with peer companies, many of which present similar non-GAAP financial measures to investors.

[0001262039-23-000003:8k_2_02:95]
Non-GAAP financial measures should not be considered in isolation from, or as a substitute for, financial information prepared in accordance with GAAP. Investors are encouraged to review the reconciliation of these non-GAAP financial measures to their most directly comparable GAAP financial measures provided in the financial statement tables below.

[0001262039-23-000003:8k_2_02:96]
Billings (non-GAAP). We define billings as revenue recognized in accordance with GAAP plus the change in deferred revenue from the beginning to the end of the period, less any deferred revenue balances acquired from business combination(s) and adjustment due to adoption of new accounting standard during the period. We consider billings to be a useful metric for management and investors because billings drive current and future revenue, which is an important indicator of the health and viability of our business. There are a number of limitations related to the use of billings instead of GAAP revenue. First, billings include amounts that have not yet been recognized as revenue and are impacted by the term of security and support agreements. Second, we may calculate billings in a manner that is different from peer companies that report similar financial measures. Management accounts for these limitations by providing specific information regarding GAAP revenue and evaluating billings together with GAAP revenue.

[0001262039-23-000003:8k_2_02:97]
Free cash flow (non-GAAP). We define free cash flow as net cash provided by operating activities minus purchases of property and equipment and excluding any significant non-recurring items. We believe free cash flow to be a liquidity measure that provides useful information to management and investors about the amount of cash generated by the business that, after capital expenditures and net of proceeds from intellectual property matter, can be used for strategic opportunities, including repurchasing outstanding common stock, investing in our business, making strategic acquisitions and strengthening the balance sheet. A limitation of using free cash flow rather than the GAAP measures of cash provided by or used in operating activities, investing activities, and financing activities is that free cash flow does not represent the total increase or decrease in the cash and cash equivalents balance for the period because it excludes cash flows from significant non-recurring items, investing activities other than capital expenditures and cash flows from financing activities. Management accounts for this limitation by providing information about our capital expenditures and other investing and financing activities on the face of the cash flow statement and under the caption “Management’s Discussion and Analysis of Financial Condition and Results of Operations—Liquidity and Capital Resources” in our most recent Quarterly Report on Form 10-Q and Annual Report on Form 10-K and by presenting cash flows from investing and financing activities in our reconciliation of free cash flow. In addition, it is important to note that other companies, including companies in our industry, may not use free cash flow, may calculate free cash flow in a different manner than we do or may use other financial measures to evaluate their performance, all of which could reduce the usefulness of free cash flow as a comparative measure.

[0001262039-23-000003:8k_2_02:98]
Non-GAAP operating income and operating margin. We define non-GAAP operating income as operating income plus stock-based compensation, impairment and amortization of acquired intangible assets, less gain on intellectual property matter and, when applicable, other significant non-recurring items in a given quarter. Non-GAAP operating margin is defined as non-GAAP operating income divided by GAAP revenue. We consider these non-GAAP financial measures to be useful metrics for management and investors because they exclude the items noted above so that our management and investors can compare our recurring core business operating results over multiple periods. There are a number of limitations related to the use of

[0001262039-23-000003:8k_2_02:99]
non-GAAP operating income instead of operating income calculated in accordance with GAAP. First, non-GAAP operating income excludes the items noted above. Second, the components of the costs that we exclude from our calculation of non-GAAP operating income may differ from the components that peer companies exclude when they report their non-GAAP results of operations. Management accounts for these limitations by providing specific information regarding the GAAP amounts excluded from non-GAAP operating income and evaluating non-GAAP operating income together with operating income calculated in accordance with GAAP.

[0001262039-23-000003:8k_2_02:100]
Non-GAAP net income and diluted net income per share attributable to Fortinet, Inc. We define non-GAAP net income as net income plus the items noted above under non-GAAP operating income and operating margin. In addition, we adjust non-GAAP net income and diluted net income per share for a non-cash charge on equity method investment comprised of impairment and other intervening events, a tax adjustment required for an effective tax rate on a non-GAAP basis and adjustments attributable to non-controlling interests, which differs from the GAAP effective tax rate. We define non-GAAP diluted net income per share as non-GAAP net income divided by the non-GAAP diluted weighted-average shares outstanding. We consider these non-GAAP financial measures to be useful metrics for management and investors for the same reasons that we use non-GAAP operating income and non-GAAP operating margin. However, in order to provide a more complete picture of our recurring core business operating results, we include in non-GAAP net income and non-GAAP diluted net income per share, the tax adjustment required resulting in an effective tax rate on a non-GAAP basis, which often differs from the GAAP tax rate. We believe the non-GAAP effective tax rates we use are reasonable estimates of normalized tax rates for our current and prior fiscal years under our global operating structure. The same limitations described above regarding our use of non-GAAP operating income and non-GAAP operating margin apply to our use of non-GAAP net income and non-GAAP diluted net income per share. We account for these limitations by providing specific information regarding the GAAP amounts excluded from non-GAAP net income and non-GAAP diluted net income per share and evaluating non-GAAP net income and non-GAAP diluted net income per share together with net income and diluted net income per share calculated in accordance with GAAP.

[0001262039-23-000003:8k_2_02:101]
FORTINET, INC.

[0001262039-23-000003:8k_2_02:102]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001262039-23-000003:8k_2_02:103]
(Unaudited, in millions)

[0001262039-23-000003:8k_2_02:104]
|  | December 31,2022 |  | December 31,2021 |
| ASSETS |  |  |  |
| CURRENT ASSETS: |  |  |  |
| Cash and cash equivalents | $ | 1,682.9 |  |  | $ | 1,319.1 |  |
| Short-term investments | 502.6 |  |  | 1,194.0 |  |
| Marketable equity securities | 25.5 |  |  | 38.6 |  |
| Accounts receivable—net | 1,261.7 |  |  | 807.7 |  |
| Inventory | 264.6 |  |  | 175.8 |  |
| Prepaid expenses and other current assets | 73.1 |  |  | 65.4 |  |
| Total current assets | 3,810.4 |  |  | 3,600.6 |  |
| LONG-TERM INVESTMENTS | 45.5 |  |  | 440.8 |  |
| PROPERTY AND EQUIPMENT—NET | 898.5 |  |  | 687.6 |  |
| DEFERRED CONTRACT COSTS | 518.2 |  |  | 423.3 |  |
| DEFERRED TAX ASSETS | 569.4 |  |  | 342.3 |  |
| GOODWILL AND OTHER INTANGIBLE ASSETS—NET | 184.0 |  |  | 188.7 |  |
| OTHER ASSETS | 202.0 |  |  | 235.8 |  |
| TOTAL ASSETS | $ | 6,228.0 |  |  | $ | 5,919.1 |  |
| LIABILITIES AND EQUITY (DEFICIT) |  |  |  |
| CURRENT LIABILITIES: |  |  |  |
| Accounts payable | $ | 243.4 |  |  | $ | 148.4 |  |
| Accrued liabilities | 266.3 |  |  | 197.3 |  |
| Accrued payroll and compensation | 219.4 |  |  | 195.0 |  |
| Deferred revenue | 2,349.3 |  |  | 1,777.4 |  |
| Total current liabilities | 3,078.4 |  |  | 2,318.1 |  |
| DEFERRED REVENUE | 2,291.0 |  |  | 1,675.5 |  |
| INCOME TAX LIABILITIES | 67.8 |  |  | 79.5 |  |
| LONG-TERM DEBT | 990.4 |  |  | 988.4 |  |
| OTHER LIABILITIES | 82.0 |  |  | 59.2 |  |
| Total liabilities | 6,509.6 |  |  | 5,120.7 |  |
| COMMITMENTS AND CONTINGENCIES |  |  |  |
| EQUITY (DEFICIT): |  |  |  |
| Common stock | 0.8 |  |  | 0.8 |  |
| Additional paid-in capital | 1,284.2 |  |  | 1,253.6 |  |
| Accumulated other comprehensive loss | (20.2) |  |  | (4.8) |  |
| Accumulated deficit | (1,546.4) |  |  | (467.9) |  |
| Total Fortinet, Inc. stockholders’ equity (deficit) | (281.6) |  |  | 781.7 |  |
| Non-controlling interests | — |  |  | 16.7 |  |
| Total equity (deficit) | (281.6) |  |  | 798.4 |  |
| TOTAL LIABILITIES AND EQUITY (DEFICIT) | $ | 6,228.0 |  |  | $ | 5,919.1 |  |

[0001262039-23-000003:8k_2_02:105]
FORTINET, INC.

[0001262039-23-000003:8k_2_02:106]
CONDENSED CONSOLIDATED STATEMENTS OF INCOME

[0001262039-23-000003:8k_2_02:107]
(Unaudited, in millions, except per share amounts)

[0001262039-23-000003:8k_2_02:108]
|  | Three Months Ended |  | Year Ended |
|  | December 31,2022 |  | December 31,2021 |  | December 31,2022 |  | December 31,2021 |
| REVENUE: |  |  |  |  |  |  |  |
| Product | $ | 540.1 |  |  | $ | 378.9 |  |  | $ | 1,780.5 |  |  | $ | 1,255.0 |  |
| Service | 742.9 |  |  | 584.7 |  |  | 2,636.9 |  |  | 2,087.2 |  |
| Total revenue | 1,283.0 |  |  | 963.6 |  |  | 4,417.4 |  |  | 3,342.2 |  |
| COST OF REVENUE: |  |  |  |  |  |  |  |
| Product | 189.9 |  |  | 146.5 |  |  | 691.3 |  |  | 487.7 |  |
| Service | 107.4 |  |  | 81.8 |  |  | 393.6 |  |  | 295.3 |  |
| Total cost of revenue | 297.3 |  |  | 228.3 |  |  | 1,084.9 |  |  | 783.0 |  |
| GROSS PROFIT: |  |  |  |  |  |  |  |
| Product | 350.2 |  |  | 232.4 |  |  | 1,089.2 |  |  | 767.3 |  |
| Service | 635.5 |  |  | 502.9 |  |  | 2,243.3 |  |  | 1,791.9 |  |
| Total gross profit | 985.7 |  |  | 735.3 |  |  | 3,332.5 |  |  | 2,559.2 |  |
| OPERATING EXPENSES: |  |  |  |  |  |  |  |
| Research and development | 128.9 |  |  | 112.6 |  |  | 512.4 |  |  | 424.2 |  |
| Sales and marketing | 455.9 |  |  | 367.7 |  |  | 1,686.1 |  |  | 1,345.7 |  |
| General and administrative | 44.3 |  |  | 41.3 |  |  | 169.0 |  |  | 143.5 |  |
| Gain on intellectual property matter | (1.2) |  |  | (1.2) |  |  | (4.6) |  |  | (4.6) |  |
| Total operating expenses | 627.9 |  |  | 520.4 |  |  | 2,362.9 |  |  | 1,908.8 |  |
| OPERATING INCOME | 357.8 |  |  | 214.9 |  |  | 969.6 |  |  | 650.4 |  |
| INTEREST INCOME | 9.1 |  |  | 1.0 |  |  | 17.4 |  |  | 4.5 |  |
| INTEREST EXPENSE | (4.5) |  |  | (4.5) |  |  | (18.0) |  |  | (14.9) |  |
| OTHER INCOME (EXPENSE)—NET | 5.8 |  |  | (4.1) |  |  | (13.5) |  |  | (11.6) |  |
| INCOME BEFORE INCOME TAXES AND LOSS FROM EQUITY METHOD INVESTMENT | 368.2 |  |  | 207.3 |  |  | 955.5 |  |  | 628.4 |  |
| PROVISION FOR INCOME TAXES | 9.2 |  |  | 3.7 |  |  | 30.8 |  |  | 14.1 |  |
| LOSS FROM EQUITY METHOD INVESTMENT | (45.2) |  |  | (4.8) |  |  | (68.1) |  |  | (7.6) |  |
| NET INCOME INCLUDING NON-CONTROLLING INTERESTS | 313.8 |  |  | 198.8 |  |  | 856.6 |  |  | 606.7 |  |
| Less: NET LOSS ATTRIBUTABLE TO NON-CONTROLLING INTERESTS, NET OF TAX | — |  |  | (0.2) |  |  | (0.7) |  |  | (0.1) |  |
| NET INCOME ATTRIBUTABLE TO FORTINET, INC. | $ | 313.8 |  |  | $ | 199.0 |  |  | $ | 857.3 |  |  | $ | 606.8 |  |
| Net income per share attributable to Fortinet, Inc.(a): |  |  |  |  |  |  |  |
| Basic | $ | 0.40 |  |  | $ | 0.24 |  |  | $ | 1.08 |  |  | $ | 0.74 |  |
| Diluted | $ | 0.40 |  |  | $ | 0.24 |  |  | $ | 1.06 |  |  | $ | 0.73 |  |
| Weighted-average shares used to compute net income per share attributable to Fortinet, Inc.(a): |  |  |  |  |  |  |  |
| Basic | 780.9 |  |  | 814.9 |  |  | 791.4 |  |  | 816.1 |  |
| Diluted | 791.8 |  |  | 835.0 |  |  | 805.3 |  |  | 835.3 |  |

[0001262039-23-000003:8k_2_02:109]
(a) All share and per share amounts presented herein have been retroactively adjusted to reflect the five-for-one forward stock split which was effective June 22, 2022.

[0001262039-23-000003:8k_2_02:110]
FORTINET, INC.

[0001262039-23-000003:8k_2_02:111]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001262039-23-000003:8k_2_02:112]
(Unaudited, in millions)

[0001262039-23-000003:8k_2_02:113]
|  | Year Ended |
|  | December 31,2022 |  | December 31,2021 |
| CASH FLOWS FROM OPERATING ACTIVITIES: |  |  |  |
| Net income including non-controlling interests | $ | 856.6 |  |  | $ | 606.7 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |
| Stock-based compensation | 217.3 |  |  | 207.9 |  |
| Amortization of deferred contract costs | 223.3 |  |  | 175.9 |  |
| Depreciation and amortization | 104.3 |  |  | 84.4 |  |
| Amortization of investment premiums | 4.4 |  |  | 6.9 |  |
| Loss from equity method investment | 68.1 |  |  | 7.6 |  |
| Other | 23.6 |  |  | 7.9 |  |
| Changes in operating assets and liabilities, net of impact of business combinations: |  |  |  |
| Accounts receivable—net | (456.7) |  |  | (72.5) |  |
| Inventory | (109.1) |  |  | (19.4) |  |
| Prepaid expenses and other current assets | (7.7) |  |  | (17.7) |  |
| Deferred contract costs | (318.2) |  |  | (294.5) |  |
| Deferred tax assets | (226.4) |  |  | (94.0) |  |
| Other assets | (35.3) |  |  | (19.0) |  |
| Accounts payable | 105.2 |  |  | (13.1) |  |
| Accrued liabilities | 55.2 |  |  | 49.9 |  |
| Accrued payroll and compensation | 25.0 |  |  | 44.0 |  |
| Other liabilities | 23.5 |  |  | (0.7) |  |
| Deferred revenue | 1,177.5 |  |  | 839.4 |  |
| Net cash provided by operating activities | 1,730.6 |  |  | 1,499.7 |  |
| CASH FLOWS FROM INVESTING ACTIVITIES: |  |  |  |
| Purchases of investments | (389.1) |  |  | (2,308.0) |  |
| Sales of investments | 3.0 |  |  | 85.5 |  |
| Maturities of investments | 1,462.0 |  |  | 1,470.3 |  |
| Purchases of property and equipment | (281.2) |  |  | (295.9) |  |
| Purchases of investment in privately held company | — |  |  | (160.0) |  |
| Payments made in connection with business combinations, net of cash acquired | (30.8) |  |  | (74.9) |  |
| Purchases of marketable equity securities | — |  |  | (42.5) |  |
| Other | — |  |  | 0.4 |  |
| Net cash provided by (used in) investing activities | 763.9 |  |  | (1,325.1) |  |
| CASH FLOWS FROM FINANCING ACTIVITIES: |  |  |  |
| Proceeds from long-term borrowings, net of discount and underwriting fees | — |  |  | 989.4 |  |
| Payments for debt issuance costs | — |  |  | (2.4) |  |
| Repurchase and retirement of common stock | (1,991.2) |  |  | (741.8) |  |
| Proceeds from issuance of common stock | 26.1 |  |  | 26.0 |  |
| Taxes paid related to net share settlement of equity awards | (160.4) |  |  | (167.9) |  |
| Payments of debt assumed in connection with business combinations | — |  |  | (19.5) |  |
| Other | (4.8) |  |  | (1.0) |  |
| Net cash provided by (used in) financing activities | (2,130.3) |  |  | 82.8 |  |
| EFFECT OF EXCHANGE RATE CHANGES ON CASH AND CASH EQUIVALENTS | (0.4) |  |  | (0.1) |  |
| NET INCREASE IN CASH AND CASH EQUIVALENTS | 363.8 |  |  | 257.3 |  |
| CASH AND CASH EQUIVALENTS—Beginning of year | 1,319.1 |  |  | 1,061.8 |  |
| CASH AND CASH EQUIVALENTS—End of year | $ | 1,682.9 |  |  | $ | 1,319.1 |  |

[0001262039-23-000003:8k_2_02:114]
Reconciliations of non-GAAP results of operations measures to the nearest comparable GAAP measures

[0001262039-23-000003:8k_2_02:115]
(Unaudited, in millions, except per share amounts)

[0001262039-23-000003:8k_2_02:116]
Reconciliation of net cash provided by operating activities to free cash flow

[0001262039-23-000003:8k_2_02:117]
|  | Three Months Ended |  | Year Ended |
|  | December 31,2022 |  | December 31,2021 |  | December 31,2022 |  | December 31,2021 |
| Net cash provided by operating activities | $ | 528.1 |  |  | $ | 366.8 |  |  | $ | 1,730.6 |  |  | $ | 1,499.7 |  |
| Less: Purchases of property and equipment | (30.9) |  |  | (151.3) |  |  | (281.2) |  |  | (295.9) |  |
| Free cash flow | $ | 497.2 |  |  | $ | 215.5 |  |  | $ | 1,449.4 |  |  | $ | 1,203.8 |  |
| Net cash provided by (used in) investing activities | $ | 217.4 |  |  | $ | (265.9) |  |  | $ | 763.9 |  |  | $ | (1,325.1) |  |
| Net cash provided by (used in) financing activities | $ | (27.4) |  |  | $ | (633.6) |  |  | $ | (2,130.3) |  |  | $ | 82.8 |  |

[0001262039-23-000003:8k_2_02:118]
Reconciliation of GAAP operating income to non-GAAP operating income, operating margin, net income attributable to Fortinet, Inc. and diluted net income per share attributable to Fortinet, Inc.

[0001262039-23-000003:8k_2_02:119]
|  | Three Months Ended December 31, 2022 |  | Three Months Ended December 31, 2021 |
|  | GAAP Results |  | Adjustments |  | Non-GAAP Results |  | GAAP Results |  | Adjustments |  | Non-GAAP Results |
| Operating income | $ | 357.8 |  |  | $ | 59.8 |  | (a) | $ | 417.6 |  |  | $ | 214.9 |  |  | $ | 59.8 |  | (b) | $ | 274.7 |  |
| Operating margin | 27.9 | % |  |  |  | 32.5 | % |  | 22.3 | % |  |  |  | 28.5 | % |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | 55.3 |  |  |  |  |  |  | 54.2 |  |  |  |
| Amortization of acquired intangible assets |  |  | 5.7 |  |  |  |  |  |  | 6.8 |  |  |  |
| Gain on intellectual property matter |  |  | (1.2) |  |  |  |  |  |  | (1.2) |  |  |  |
| Tax adjustment |  |  | (63.6) |  | (c) |  |  |  |  | (52.4) |  | (c) |  |
| Non-cash charge on equity method investment |  |  | 39.7 |  | (d) |  |  |  |  | — |  |  |  |
| Adjustments attributable non-controlling interests |  |  | — |  |  |  |  |  |  | (0.6) |  | (e) |  |
| Net income attributable to Fortinet, Inc. | $ | 313.8 |  |  | $ | 35.9 |  |  | $ | 349.7 |  |  | $ | 199.0 |  |  | $ | 6.8 |  |  | $ | 205.8 |  |
| Diluted net income per share attributable to Fortinet, Inc.(f) | $ | 0.40 |  |  |  |  | $ | 0.44 |  |  | $ | 0.24 |  |  |  |  | $ | 0.25 |  |
| Shares used in diluted net income per share attributable to Fortinet, Inc. calculations(f) | 791.8 |  |  |  |  | 791.8 |  |  | 835.0 |  |  |  |  | 835.0 |  |

[0001262039-23-000003:8k_2_02:120]
(a) To exclude $55.3 million of stock-based compensation and $5.7 million of amortization of acquired intangible assets, offset by a $1.2 million gain on intellectual property matter in the three months ended December 31, 2022.

[0001262039-23-000003:8k_2_02:121]
(b) To exclude $54.2 million of stock-based compensation and $6.8 million of amortization of acquired intangible assets, offset by a $1.2 million gain on intellectual property matter in the three months ended December 31, 2021.

[0001262039-23-000003:8k_2_02:122]
(c) Non-GAAP financial information is adjusted to an overall effective tax rate of 17% and 21% in the three months ended December 31, 2022 and 2021, respectively, on a non-GAAP basis, which differs from the GAAP effective tax rate.

[0001262039-23-000003:8k_2_02:123]
(d)  To exclude a $39.7 million non-cash charge, primarily comprised of the impairment charge on our equity method investment in Linksys Holdings Inc. (“Linksys”) and other intervening events related to the establishment of a valuation allowance against Linksys deferred tax assets.

[0001262039-23-000003:8k_2_02:124]
(e) Adjustments related to the non-GAAP results attributable to non-controlling interests, which were adjusted to an effective tax rate of 31% for the subsidiary of Alaxala Networks Corporation (“Alaxala”) in the three months ended December 31, 2021.

[0001262039-23-000003:8k_2_02:125]
(f) All share and per share amounts presented herein have been retroactively adjusted to reflect the five-for-one forward stock split which was effective June 22, 2022.

[0001262039-23-000003:8k_2_02:126]
|  | Year Ended December 31, 2022 |  | Year Ended December 31, 2021 |
|  | GAAP Results |  | Adjustments |  | Non-GAAP Results |  | GAAP Results |  | Adjustments |  | Non-GAAP Results |
| Operating income | $ | 969.6 |  |  | $ | 238.5 |  | (a) | $ | 1,208.1 |  |  | $ | 650.4 |  |  | $ | 225.1 |  | (b) | $ | 875.5 |  |
| Operating margin | 21.9 | % |  |  |  | 27.3 | % |  | 19.5 | % |  |  |  | 26.2 | % |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | 219.8 |  |  |  |  |  |  | 211.2 |  |  |  |
| Amortization of acquired intangible assets |  |  | 23.3 |  |  |  |  |  |  | 18.5 |  |  |  |
| Gain on intellectual property matter |  |  | (4.6) |  |  |  |  |  |  | (4.6) |  |  |  |
| Tax adjustment |  |  | (172.2) |  | (c) |  |  |  |  | (165.1) |  | (c) |  |
| Non-cash charge on equity method investment |  |  | 39.7 |  | (d) |  |  |  |  | — |  |  |  |
| Adjustments attributable non-controlling interests |  |  | (1.7) |  | (e) |  |  |  |  | (0.8) |  | (e) |  |
| Net income attributable to Fortinet, Inc. | $ | 857.3 |  |  | $ | 104.3 |  |  | $ | 961.6 |  |  | $ | 606.8 |  |  | $ | 59.2 |  |  | $ | 666.0 |  |
| Diluted net income per share attributable to Fortinet, Inc.(f) | $ | 1.06 |  |  |  |  | $ | 1.19 |  |  | $ | 0.73 |  |  |  |  | $ | 0.80 |  |
| Shares used in diluted net income per share calculations(f) | 805.3 |  |  |  |  | 805.3 |  |  | 835.3 |  |  |  |  | 835.3 |  |

[0001262039-23-000003:8k_2_02:127]
(a) To exclude $219.8 million of stock-based compensation and $23.3 million of amortization of acquired intangible assets, offset by a $4.6 million gain on intellectual property matter in 2022.

[0001262039-23-000003:8k_2_02:128]
(b) To exclude $211.2 million of stock-based compensation and $18.5 million of amortization of acquired intangible assets, offset by a $4.6 million gain on intellectual property matter in 2021.

[0001262039-23-000003:8k_2_02:129]
(c) Non-GAAP financial information is adjusted to an overall effective tax rate of 17% and 21% in 2022 and 2021, respectively, on a non-GAAP basis, which differs from the GAAP effective tax rate.

[0001262039-23-000003:8k_2_02:130]
(d)  To exclude a $39.7 million non-cash charge, primarily comprised of the impairment charge on our equity method investment in Linksys and other intervening events related to the establishment of a valuation allowance against Linksys deferred tax assets.

[0001262039-23-000003:8k_2_02:131]
(e) Adjustments related to the non-GAAP results attributable to non-controlling interests, which were adjusted to an effective tax rate of 31% for the subsidiary of Alaxala in 2022 and 2021.

[0001262039-23-000003:8k_2_02:132]
(f) All share and per share amounts presented herein have been retroactively adjusted to reflect the five-for-one forward stock split which was effective June 22, 2022.

[0001262039-23-000003:8k_2_02:133]
Reconciliation of total revenue to total billings

[0001262039-23-000003:8k_2_02:134]
|  | Three Months Ended |  | Year Ended |
|  | December 31,2022 |  | December 31,2021 |  | December 31,2022 |  | December 31,2021 |
| Total revenue | $ | 1,283.0 |  |  | $ | 963.6 |  |  | $ | 4,417.4 |  |  | $ | 3,342.2 |  |
| Add: Change in deferred revenue | 446.8 |  |  | 346.5 |  |  | 1,187.4 |  |  | 847.6 |  |
| Less: Deferred revenue balance acquired in business acquisitions | (10.8) |  |  | — |  |  | (10.8) |  |  | (4.1) |  |
| Less: Adjustment due to adoption of ASU 2021-083 | — |  |  | (4.3) |  |  | — |  |  | (4.3) |  |
| Total billings | $ | 1,719.0 |  |  | $ | 1,305.8 |  |  | $ | 5,594.0 |  |  | $ | 4,181.4 |  |

[0001262039-23-000003:8k_2_02:135]
3 We early adopted ASU 2021-08 on a retrospective basis and effective for us beginning on January 1, 2021. The adoption of ASU 2021-08 resulted in a $4.3 million adjustment attributable to the acquisition of Alaxala in 2021, as a result of the revised measurement of deferred revenue for acquisition.

[0001262039-23-000003:8k_2_02:136]
| Investor Contact: |  | Media Contact: |
| Peter Salkowski |  | John Welton |
| Fortinet, Inc. |  | Fortinet, Inc. |
| 408-331-4595 |  | 408-235-7700 |
| psalkowski@fortinet.com |  | pr@fortinet.com |
