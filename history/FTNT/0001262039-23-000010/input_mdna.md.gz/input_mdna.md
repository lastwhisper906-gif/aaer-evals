# FTNT MD&A — 0001262039-23-000010


## mdna

[0001262039-23-000010:mdna:1]
ITEM 7.     Management’s Discussion and Analysis of Financial Condition and Results of Operations

[0001262039-23-000010:mdna:2]
•supply chain constraints, the global chip and component shortages, and other factors affecting our manufacturing capacity, delivery, cost and inventory management;

[0001262039-23-000010:mdna:3]
•increased inflation or stagflation, and rising interest rates in many geographies and changes in currency exchange rates and currency regulations;

[0001262039-23-000010:mdna:4]
•the duration and impact of the COVID-19 pandemic, including various COVID-19 variants and “return to office” plans;

[0001262039-23-000010:mdna:5]
•continued growth and market share gains;

[0001262039-23-000010:mdna:6]
•variability in sales in certain product and service categories from year to year and between quarters;

[0001262039-23-000010:mdna:7]
•expected impact of sales of certain products and services;

[0001262039-23-000010:mdna:8]
•macroeconomic, geopolitical factors and other disruption on our manufacturing or sales, including the impact of the COVID-19 pandemic and other public health issues, wars and natural disasters;

[0001262039-23-000010:mdna:9]
•government regulation, tariffs and other policies;

[0001262039-23-000010:mdna:10]
•drivers of long-term growth and operating leverage, such as sales productivity and capacity, functionality and value in our service offerings;

[0001262039-23-000010:mdna:11]
•growing our solution sales through channel partners to businesses, service providers and government organizations, our ability to execute these sales and the complexity of providing solutions to all segments (including the increased competition and unpredictability of timing associated with sales to larger enterprises), the impact of sales to these organizations on our long-term growth, expansion and operating results, and the effectiveness of our sales organization;

[0001262039-23-000010:mdna:12]
•our ability to hire properly qualified and effective sales, support and engineering employees;

[0001262039-23-000010:mdna:13]
•risks and expectations related to acquisitions and equity interests in private and public companies, including integration issues related to go-to-market plans, product plans, employees of such companies, controls and processes and the acquired technology, and risks of negative impact by such acquisitions and equity investments on our financial results;

[0001262039-23-000010:mdna:14]
•trends in revenue, cost of revenue and gross margin;

[0001262039-23-000010:mdna:15]
•trends in our operating expenses, including sales and marketing expense, research and development expense, general and administrative expense, and expectations regarding these expenses;

[0001262039-23-000010:mdna:16]
•expectations that our operating expense will increase in absolute dollars during 2023;

[0001262039-23-000010:mdna:17]
•expectations that proceeds from the exercise of stock options in future years will be adversely impacted by the increased mix of restricted stock units versus stock options granted;

[0001262039-23-000010:mdna:18]
•expectations regarding uncertain tax benefits and our effective domestic and global tax rates, and the impact of the Tax Cuts and Jobs Act of 2017 (“TCJA”), the Coronavirus Aid, Relief, and Economic Security Act of 2020 and the Inflation Reduction Act of 2022 (“IRA”);

[0001262039-23-000010:mdna:19]
•expectations regarding spending related to real estate acquisitions and development, data center investments, as well as other capital expenditures and to the impact on free cash flow;

[0001262039-23-000010:mdna:20]
•estimates of a range of 2023 spending on capital expenditures;

[0001262039-23-000010:mdna:21]
•competition in our markets;

[0001262039-23-000010:mdna:22]
•statements regarding expected outcomes and liabilities in litigation;

[0001262039-23-000010:mdna:23]
•our intentions regarding share repurchases and the sufficiency of our existing cash, cash equivalents and investments to meet our cash needs, including our debt servicing requirements, for at least the next 12 months;

[0001262039-23-000010:mdna:24]
•other statements regarding our future operations, financial condition and prospects and business strategies; and

[0001262039-23-000010:mdna:25]
•adoption and impact of new accounting standards.

[0001262039-23-000010:mdna:26]
Business Overview

[0001262039-23-000010:mdna:27]
Fortinet is a global leader in cybersecurity solutions provided to a wide variety of organizations, including enterprises, communication service providers and security service providers, government organizations and small businesses. Our cybersecurity solutions are designed to provide broad visibility and segmentation of the digital attack surface through our integrated cybersecurity platform products and services providing a mesh architecture, which feature automated protection, detection and response along with consolidated visibility across both Fortinet-developed solutions and a broad ecosystem of third-party solutions and technologies. Our cybersecurity platform portfolio leverages a common operating system or integration to this operating system across our product offerings and helps organizations better secure their environments and reduce their security and network complexities. The Fortinet operating system has an open architecture designed to integrate Fortinet solutions with third-party solutions in a single ecosystem, enabling automated detection and response across the attack surface.

[0001262039-23-000010:mdna:28]
Our product offerings consist of our Core Platform (previously referred to as FortiGate network security) and our Enhanced Platform Technologies (previously referred to as Platform Extension). The Enhanced Platform includes Secure Networking (Secure Switching, Access Points, 5G and Network Access Control), Network and Security Operations (Management, Analytics, Security Information and Event Management, Security Operations, Orchestration and Response and Email Security), Endpoint Security (Enhanced Detection and Response and Identity) and Cloud Security (Web Application Firewall, Cloud Network Security and Cloud-native Application Protection).

[0001262039-23-000010:mdna:29]
Our cloud- and hosted- Enhanced Platform Technology products and services include sandboxing, endpoint detection and response (“EDR”), email security, web application and application programming interface (“API”) security, cloud networking security and cloud-native protection as well as management and analytics.

[0001262039-23-000010:mdna:30]
Our FortiGuard security subscription services are enabled by FortiGuard Labs, which provides threat research and artificial intelligence capabilities from a cloud network to deliver coordinated protection for the ever-expanding attack surface through Core Platform appliance and virtual machine as well as all Enhanced Platform Technology products that are registered by the end-customer.

[0001262039-23-000010:mdna:31]
Our FortiCare support services provide both technical support and professional services to help our customers deploy, maintain, and operationalize our Core Platform and Enhanced Platform Technology products and services.

[0001262039-23-000010:mdna:32]
Our proprietary Application-Specific Integrated Circuits (“ASIC”) are implemented in our physical Core Platform appliances and are designed to enhance the security processing capabilities implemented in software by accelerating computationally intensive tasks such as firewall policy enforcement, software-defined wide-area network (“SD-WAN”), network address translation, Intrusion Prevention Systems (“IPS”), threat detection and encryption. We also provide Fortinet

[0001262039-23-000010:mdna:33]
virtualized Application-Specific Integrated Circuits (“vASICs”) across our Core Platform virtual appliances to deliver similar accelerated capabilities when run in virtualized environments.

[0001262039-23-000010:mdna:34]
Our FortiOS operating system provides the foundation for the operation of Core Platform and Enhanced Platform Technology products, whether physical, virtual, private- or public-cloud based. FortiOS directs the operations of processors and ASICs and provides system management functions. We make regular updates to FortiOS available through our FortiCare support services.

[0001262039-23-000010:mdna:35]
Networking functionality and security capabilities are integrated into the FortiOS operating system to run both the Core Platform and Enhanced Platform Technology capabilities of our cybersecurity mesh architecture (“Fortinet Security Fabric”). This approach to security combines discrete security solutions together into an integrated operating system which provides centralized management, visibility, automation and intelligence sharing to simplify operations and respond rapidly to threats.

[0001262039-23-000010:mdna:36]
The focus areas of our business consist of:

[0001262039-23-000010:mdna:37]
•Secure Networking—Our Security-Driven Networking solutions enables the convergence of networking and security across all edges to provide next-generation firewall (“NGFW”), SD-WAN, LAN Edge (Wi-Fi and switch) and secure access service edge (“SASE”). We derive a majority of product sales from our Core Platform network security appliances. Core Platform network security appliances include a broad set of built-in security and networking features and functionalities, including firewall, next-generation firewall, secure web gateway, secure sockets layer (“SSL”) inspection, SD-WAN, Intrusion Prevention system (“IPS”), sandboxing, data leak prevention, virtual private network (“VPN”), switch and wireless controller and wide area network (“WAN”) edge. Our network security appliances are managed by our FortiOS network operating system, which provides the foundation for Core Platform security functions. We enhance the performance of our network security appliances from branch to data center by designing and implementing ASICs technology within our appliances, enabling us to add security and network functionality with minimal impact to network throughput performance. Along with our secure Wi-Fi access points and switches, we help organizations secure their networks across campuses, branches and work from anywhere (“WFA”) deployments. For the Japanese market, we also offer high performance network switches marketed under Alaxala for data center switching.

[0001262039-23-000010:mdna:38]
FortiOS supports many more secure networking markets and applications than just Firewall. These include:

[0001262039-23-000010:mdna:39]
•Network Firewall (“NFW”)

[0001262039-23-000010:mdna:40]
•Software-Defined Wide Area Network (“SD-WAN”)

[0001262039-23-000010:mdna:41]
•Secure LAN/WLAN (Wi-Fi and Switch) (SD-Branch/Campus)

[0001262039-23-000010:mdna:42]
•Secure Access Service Edge (“SASE”)

[0001262039-23-000010:mdna:43]
•Universal Zero Trust Network Access (“ZTNA”)

[0001262039-23-000010:mdna:44]
•Encryption Applications (SSL Inspection, Virtual Private Network (“VPN”), and IPsec Connectivity)

[0001262039-23-000010:mdna:45]
Further each security application has number of customer use cases. For example, Network Firewall has the following use cases:

[0001262039-23-000010:mdna:46]
•Data Center Perimeter NGFW

[0001262039-23-000010:mdna:47]
•North–South Internal Segmentation Firewall

[0001262039-23-000010:mdna:48]
•Distributed Network Edge Firewall

[0001262039-23-000010:mdna:49]
•East–West Micro Segmentation Firewall

[0001262039-23-000010:mdna:50]
•Virtual Firewall (“VM”)

[0001262039-23-000010:mdna:51]
•Cloud Native Firewall (“CNF”)

[0001262039-23-000010:mdna:52]
•Firewall as a Service (“FWaaS”)

[0001262039-23-000010:mdna:53]
•Containerized Firewall

[0001262039-23-000010:mdna:54]
•Endpoint Firewall

[0001262039-23-000010:mdna:55]
•SMB Firewall

[0001262039-23-000010:mdna:56]
•Home Firewall

[0001262039-23-000010:mdna:57]
•Zero Trust Access—Fortinet’s Enhanced Platform Technology products and services extend beyond the network to create a cybersecurity mesh architecture to cover other attack vectors. Our Zero Trust Access solutions enable

[0001262039-23-000010:mdna:58]
53

[0001262039-23-000010:mdna:59]
customers to know and control who and what is on their network, in addition to providing security for WFA. Zero Trust Access solutions include FortiNAC, FortiAuthenticator, FortiClient and FortiToken. Additionally, the proliferation of OT and internet of things (“IoT”) devices has generated new opportunities for us to grow our business. Our network access control solutions provide visibility, control and automated event responses in order to secure OT and IoT devices.

[0001262039-23-000010:mdna:60]
•Cloud Security—We help customers connect securely to and across their individual, hybrid cloud, multi-cloud and virtualized data center environments by offering security through our virtual firewall and other software products and through integrated cloud-native capabilities with major cloud platforms. Our public and private cloud security solutions, including virtual appliances and hosted solutions, bring our Enhanced Platform Technology products and services into and across cloud environments, delivering security that follows their applications and data. Our solutions include network security, web application firewall and API protection, cloud-native security and workload protection. Our Secure SD-WAN for multi-Cloud solution automates deployment of an overlay network across different cloud networks and offers visibility, control and centralized management that integrates functionality across multiple cloud environments. Our cloud security portfolio also includes securing applications in all environments in which they can be deployed, including physical and virtual data centers, clouds, and edge compute instances. Fortinet cloud security offerings are available for deployment in major public and private cloud environments, including  Amazon Web Services, Google Cloud, IBM Cloud, Microsoft Azure, Oracle Cloud and VMWare Cloud. We also offer managed web application firewall (“WAF”) rules delivered by FortiGuard Labs as an overlay service to native security offerings offered by Amazon Web Services.

[0001262039-23-000010:mdna:61]
•Security Operations—We develop and provide a range of products and services that enable the security operations center (“SOC”) teams to identify, investigate and remediate potential incidents in which cybercriminals bypass prevention-oriented controls. Given the breadth of the attack surface to monitor, as well as the volume and sophistication of cyber threats, artificial intelligence is a key part of these offerings, which include: FortiGuard and other security subscription services, modern endpoint security with EDR, a range of breach-protection technologies plus our security information and event management (“SIEM”) and security orchestration, automation and response (“SOAR”), all of which can be applied across the entire set of Platform Extension products and services. These solutions automatically deliver security intelligence and insights that enable organizations to protect against and respond to threats faster through integration with Fortinet and third-party controls.

[0001262039-23-000010:mdna:62]
•Security as a Service—Our customers purchase our natively integrated FortiGuard security subscription services as an add-on to products and solutions across many of the Enhanced Platform Technology products and services with the goal of receiving real-time threat intelligence and protection updates. The rich set of FortiGuard security subscription services is built from the ground up to provide comprehensive protection for users and applications, including market leading offerings for IPS, Web, video and DNS filtering, AV and cloud sandbox as well as OT and IoT Security. The FortiGuard security subscription services are provided from our FortiGuard Labs and cloud-delivered to provide real-time unified protection across network endpoint and cloud.

[0001262039-23-000010:mdna:63]
•Support and Professional Services—We offer technical support, FortiOS updates and extended product warranty through our FortiCare support services. In addition to our technical support services, we offer a range of advanced services, including premium support, professional services and expedited warranty replacement. Our advanced support service offerings include technical account managers that act as a single point of contact and customer advocate within Fortinet. Our professional service offerings include resident engineers and professional service consultants for implementations or trainings.

[0001262039-23-000010:mdna:64]
Financial Highlights

[0001262039-23-000010:mdna:65]
•Total revenue was $4.42 billion in 2022, an increase of 32% compared to $3.34 billion in 2021.

[0001262039-23-000010:mdna:66]
•Product revenue was $1.78 billion in 2022, an increase of 42% compared to $1.26 billion in 2021.

[0001262039-23-000010:mdna:67]
•Service revenue was $2.64 billion in 2022, an increase of 26% compared to $2.09 billion in 2021.

[0001262039-23-000010:mdna:68]
•Total gross profit was $3.33 billion in 2022, an increase of 30% compared to $2.56 billion in 2021.

[0001262039-23-000010:mdna:69]
•Operating income was $969.6 million in 2022, an increase of 49% compared to $650.4 million in 2021.

[0001262039-23-000010:mdna:70]
•Cash, cash equivalents, investments and marketable equity securities were $2.26 billion as of December 31, 2022, a decrease of $736.0 million, or 25%, from December 31, 2021.

[0001262039-23-000010:mdna:71]
•Long-term debt, net of unamortized discount and debt issuance costs, was $990.4 million and $988.4 million as of December 31, 2022 and 2021, respectively.

[0001262039-23-000010:mdna:72]
•In 2022, we repurchased 36.0 million shares of common stock under the Repurchase Program for an aggregate purchase price of $1.99 billion. In 2021, we repurchased 12.9 million shares of common stock for a total purchase price of $741.8 million.

[0001262039-23-000010:mdna:73]
•Deferred revenue was $4.64 billion as of December 31, 2022, an increase of $1.19 billion, or 34%, from December 31, 2021. Short-term deferred revenue was $2.35 billion as of December 31, 2022, an increase of $571.9 million, or 32%, from December 31, 2021.

[0001262039-23-000010:mdna:74]
•Cash flows from operating activities were $1.73 billion in 2022, an increase of $230.9 million, or 15%, compared to 2021.

[0001262039-23-000010:mdna:75]
•In October 2022, we acquired the remaining 25% of equity interests in Alaxala for $13.5 million in cash, and Alaxala became a wholly owned subsidiary.

[0001262039-23-000010:mdna:76]
•Our loss related to our equity method investment in Linksys Holdings, Inc. (“Linksys”) in fiscal 2022 totaled $68.1 million, which comprised of our proportionate share of Linksys’ financial results as well as the amortization of the basis differences of $45.9 million, which included a $17.5 million charge in connection with a valuation allowance established on deferred tax assets at Linksys, and the other-than-temporary impairment (“OTTI”) charge of $22.2 million.

[0001262039-23-000010:mdna:77]
Our revenue growth was driven by both product and service revenue. On a geographic basis, revenue continues to be diversified globally, which remains a key strength of our business.

[0001262039-23-000010:mdna:78]
In 2022, the Americas region, the Europe, Middle East and Africa (“EMEA”) region and the Asia Pacific (“APAC”) region contributed 41%, 38% and 21% of our total revenue, respectively, and increased by 31%, 33% and 33% compared to 2021, respectively.

[0001262039-23-000010:mdna:79]
Product revenue grew 42% in 2022. Product revenue growth was consistent with an elevated cyber threat landscape and changes in our pricing model. The product revenue growth was primarily due to strong growth across many of our Enhanced Platform Technology products, including our secure access products and software licenses. In addition, our product revenue growth was driven by a strong demand for the wide range operating system capabilities embedded in our Core Platform products.

[0001262039-23-000010:mdna:80]
Service revenue growth has accelerated over the past three years from 22% in 2020, to 24% in 2021, to 26% in 2022. Service revenue growth of 26% in 2022 was driven by the strength of our FortiGuard and other security subscription revenue and FortiCare technical support and other service revenue, which grew 27% and 26%, respectively. The increases were primarily due to the recognition of revenue from our growing deferred revenue balance related to FortiGuard and other security subscriptions delivered to on-premise and cloud-based environments, as well as FortiCare and other technical support, including our customers moving to higher-tier support offerings and the early effects of certain pricing actions.

[0001262039-23-000010:mdna:81]
Our billings were diversified on a geographic basis. In 2022, six countries represented approximately 50% of our billings and the remaining 50% in the aggregate were from over 100 countries that individually contributed less than 4% of our billings.

[0001262039-23-000010:mdna:82]
Operating expenses as a percentage of revenue decreased by approximately 3.6 percentage points in 2022 compared to 2021, which benefited from the favorable impact of foreign currency fluctuations. Headcount increased by 24% to 12,595 employees as of December 31, 2022, up from 10,195 as of December 31, 2021.

[0001262039-23-000010:mdna:83]
Impact of Macroeconomic Developments and COVID-19 Pandemic Update

[0001262039-23-000010:mdna:84]
Our overall performance depends in part on worldwide economic and geopolitical conditions and their impact on customer behavior. Worsening economic conditions, including inflation, higher interest rates, slower growth, fluctuations in foreign exchange rates and other changes in economic conditions, may adversely affect our results of operations and financial performance.

[0001262039-23-000010:mdna:85]
We continue to monitor and respond to developments relating to the COVID-19 pandemic. In response to the COVID-19 pandemic, we undertook a number of actions to protect our employees, including restricting travel and directing

[0001262039-23-000010:mdna:86]
many of our employees to work from home. In certain geographies, we have transitioned back to an in-person working mode, allowing increasing numbers of employees to work from our offices with reasonable precautions and, in all cases, subject to abiding by local legal restrictions. We intend to continue to monitor and abide by local employee health and safety protocols and other regulations as applicable to each local office.

[0001262039-23-000010:mdna:87]
We have seen certain impacts on our business and operations, results of operations, financial condition, cash flows, liquidity and capital and financial resources as of and during the year ended December 31, 2022. Conversely, some aspects of our business do not appear to have been significantly affected. During the year ended December 31, 2022, we observed the following:

[0001262039-23-000010:mdna:88]
•We saw continued supply chain challenges, including chip and other component shortages and increased costs for certain chips and other components and shipping, and we did not have enough inventory to promptly meet all demand for all products.

[0001262039-23-000010:mdna:89]
•In many countries, our employees’ ability to travel was reduced and certain in-person sales and marketing events or meetings that would normally have been held were canceled, postponed or converted into virtual events. However, as certain country’s restrictions continued to ease, we have started to see an increase in expenses related to travel and marketing events. Although we cannot predict if or when such expenses will return to pre-pandemic levels, as of December 31, 2022, we had started to see an increase in such expenses as compared to the same period last year.

[0001262039-23-000010:mdna:90]
•In order to mitigate supply chain disruptions and other supply chain risks and in anticipation of future demand, we increased our commitments with certain suppliers to secure capacity and are meeting regularly with our contract manufacturers and component suppliers to manage future commitments, address component shortages and monitor delivery. We have also transitioned primarily to air shipping to avoid port congestion and extended ocean freight time.

[0001262039-23-000010:mdna:91]
•Our days sales outstanding increased to 89 days for the year ended December 31, 2022, compared to 75 days for the year ended December 31, 2021, primarily due to the sales linearity. The accounts receivable allowance for credit losses was $3.6 million as of December 31, 2022, an increase of $1.2 million compared to $2.4 million as of December 31, 2021, primarily due to an increase in past due invoices over 60 and 90 days.

[0001262039-23-000010:mdna:92]
The COVID-19 pandemic may have a material negative impact on our future periods. If we experience component, shipping, inventory or customer payment challenges, it will negatively impact billings and product revenue in the current quarter and FortiGuard and FortiCare service revenues in subsequent quarters, as we sell annual and multi-year service contracts that are recognized ratably over the service term, generally starting on the contract registration date. In addition, the broader implications of the pandemic on our business and operations and our financial results, including the extent to which the effects of the pandemic may impact future results and growth in the cybersecurity industry, remain uncertain. The extent of the impact of the COVID-19 pandemic on our operational and financial performance will depend on ongoing developments, including the duration and spread of the virus and its variants, the impact on our end-customers’ spending, the volume of sales and length of our sales cycles, the impact on our partners, suppliers, and employees, actions that may be taken by governmental authorities and other factors identified in Part I, Item 1A “Risk Factors” in this Form 10-K. Given the dynamic nature of these circumstances, the full impact of the COVID-19 pandemic on our business and operations, results of operations, financial condition, cash flows, liquidity and capital and financial resources cannot be reasonably estimated at this time.

[0001262039-23-000010:mdna:93]
Business Model

[0001262039-23-000010:mdna:94]
We typically sell our security solutions to distributors that sell to networking security focused resellers and to certain service providers, who, in turn, sell to end-customers or use our products and services to provide hosted solutions to other enterprises. At times, we also sell directly to certain large enterprise customers, large service providers and major systems integrators. Our end-customers are located in over 100 countries and include small, medium and large enterprises and government organizations across a wide range of industries, including education, financial services, government, healthcare, manufacturing, retail, technology and telecommunications. An end-customer deployment may involve as few as one or as many as thousands of Core Platform products as well as Enhanced Platform Technology products, depending on the end-customer’s size and security requirements.

[0001262039-23-000010:mdna:95]
We also offer our products hosted in our own data centers and through co-locations and major cloud providers, including Amazon Web Services, Google Cloud, IBM Cloud, Microsoft Azure and Oracle Cloud. We have also recognized revenue from customers who deploy our products in a bring-your-own-license (“BYOL”) arrangements at cloud providers or at private clouds. In a BYOL arrangement, a customer purchases a software license through our channel partners and deploys the software in a cloud provider’s environment in third-party clouds or in their private cloud.

[0001262039-23-000010:mdna:96]
Our customers purchase our hardware products and software licenses, as well as our FortiGuard and other security subscription and FortiCare technical support services. We generally invoice at the time of our sale for the total price of the products and services. Standard payment terms are generally no more than 60 days, though we may offer extended payment terms to certain distributors or related to certain transactions.

[0001262039-23-000010:mdna:97]
Key Metrics

[0001262039-23-000010:mdna:98]
We monitor several key metrics, including the key financial metrics set forth below, in order to help us evaluate growth trends, establish budgets, measure the effectiveness of our sales and marketing efforts, and assess operational efficiencies. The following table summarizes revenue, deferred revenue, billings (non-GAAP), net cash provided by operating activities, and free cash flow (non-GAAP). We discuss revenue below under “—Components of Operating Results,” and we discuss net cash provided by operating activities below under “—Liquidity and Capital Resources.” Deferred revenue, billings (non-GAAP), and free cash flow (non-GAAP) are discussed immediately below the following table.

[0001262039-23-000010:mdna:99]
|  | Year Ended or As of December 31, |
|  | 2022 |  | 2021 |  | 2020 |
|  | (in millions) |
| Revenue | $ | 4,417.4 |  |  | $ | 3,342.2 |  |  | $ | 2,594.4 |  |
| Deferred revenue | $ | 4,640.3 |  |  | $ | 3,452.9 |  |  | $ | 2,605.3 |  |
| Billings (non-GAAP) | $ | 5,594.0 |  |  | $ | 4,181.4 |  |  | $ | 3,090.0 |  |
| Net cash provided by operating activities | $ | 1,730.6 |  |  | $ | 1,499.7 |  |  | $ | 1,083.7 |  |
| Free cash flow (non-GAAP) | $ | 1,449.4 |  |  | $ | 1,203.8 |  |  | $ | 907.8 |  |

[0001262039-23-000010:mdna:100]
Deferred revenue. Our deferred revenue consists of amounts that have been invoiced but that have not yet been recognized as revenue. The majority of our deferred revenue balance consists of the unrecognized portion of service revenue from FortiGuard and other security subscription and FortiCare technical support service contracts, which is recognized as revenue ratably over the service term. We monitor our deferred revenue balance, short term and total deferred revenue growth and the mix of short-term and long-term deferred revenue because deferred revenue represents a significant portion of free cash flow and of revenue to be recognized in future periods. Deferred revenue was $4.64 billion as of December 31, 2022, an increase of $1.19 billion, or 34%, from December 31, 2021. Short term deferred revenue was $2.35 billion as of December 31, 2022, and increase of $571.9 million, or 32%, from December 31, 2021.

[0001262039-23-000010:mdna:101]
Billings (non-GAAP). We define billings as revenue recognized in accordance with generally accepted accounting principles in the United States (“GAAP”) plus the change in deferred revenue from the beginning to the end of the period, less any deferred revenue balances acquired from business combination(s) and adjustment due to adoption of new accounting standard during the period. We consider billings to be a useful metric for management and investors because billings drive current and future revenue, which is an important indicator of the health and viability of our business. There are several limitations related to the use of billings instead of GAAP revenue. First, billings include amounts that have not yet been recognized as revenue and are impacted by the term of FortiGuard security subscription and FortiCare and other support agreements. Second, we may calculate billings in a manner that is different from peer companies that report similar financial measures. Management accounts for these limitations by providing specific information regarding GAAP revenue and evaluating billings together with GAAP revenue. Total billings were $5.59 billion in 2022, an increase of 34% compared to $4.18 billion in 2021.

[0001262039-23-000010:mdna:102]
57

[0001262039-23-000010:mdna:103]
A reconciliation of revenue, the most directly comparable financial measure calculated and presented in accordance with GAAP, to billings is provided below:

[0001262039-23-000010:mdna:104]
|  | Year Ended December 31, |
| 2022 |  | 2021 |  | 2020 |
| (in millions) |
| Billings: |  |  |  |  |  |
| Revenue | $ | 4,417.4 |  |  | $ | 3,342.2 |  |  | $ | 2,594.4 |  |
| Add: Change in deferred revenue | 1,187.4 |  |  | 847.6 |  |  | 496.2 |  |
| Less: Deferred revenue balance acquired in business combinations | (10.8) |  |  | (4.1) |  |  | (0.6) |  |
| Less: Adjustment due to adoption of ASU 2021-08 | — |  |  | (4.3) |  |  | — |  |
| Total billings (non-GAAP) | $ | 5,594.0 |  |  | $ | 4,181.4 |  |  | $ | 3,090.0 |  |

[0001262039-23-000010:mdna:105]
Free cash flow (non-GAAP). We define free cash flow as net cash provided by operating activities minus purchases of property and equipment and excluding any significant non-recurring items. We believe free cash flow to be a liquidity measure that provides useful information to management and investors about the amount of cash generated by the business that, after capital expenditures, can be used for strategic opportunities, including repurchasing outstanding common stock, investing in our business, making strategic acquisitions, and strengthening the balance sheet. A limitation of using free cash flow rather than the GAAP measures of cash provided by or used in operating activities, investing activities, and financing activities is that free cash flow does not represent the total increase or decrease in the cash and cash equivalents balance for the period because it excludes cash flows from investing activities other than capital expenditures and cash flows from financing activities. Management accounts for this limitation by providing information about our capital expenditures and other investing and financing activities on the consolidated statements of cash flows and under “—Liquidity and Capital Resources” and by presenting cash flows from investing and financing activities in our reconciliation of free cash flow. In addition, it is important to note that other companies, including companies in our industry, may not use free cash flow, may calculate free cash flow in a different manner than we do or may use other financial measures to evaluate their performance, all of which could reduce the usefulness of free cash flow as a comparative measure. A reconciliation of net cash provided by operating activities, the most directly comparable financial measure calculated and presented in accordance with GAAP, to free cash flow is provided below:

[0001262039-23-000010:mdna:106]
|  | Year Ended December 31, |
| 2022 |  | 2021 |  | 2020 |
| (in millions) |
| Free Cash Flow: |  |  |  |  |  |
| Net cash provided by operating activities | $ | 1,730.6 |  |  | $ | 1,499.7 |  |  | $ | 1,083.7 |  |
| Less: Purchases of property and equipment | (281.2) |  |  | (295.9) |  |  | (125.9) |  |
| Less: Proceeds from intellectual property matter | — |  |  | — |  |  | (50.0) |  |
| Free cash flow (non-GAAP) | $ | 1,449.4 |  |  | $ | 1,203.8 |  |  | $ | 907.8 |  |
| Net cash provided by (used in) investing activities | $ | 763.9 |  |  | $ | (1,325.1) |  |  | $ | (72.8) |  |
| Net cash provided by (used in) financing activities | $ | (2,130.3) |  |  | $ | 82.8 |  |  | $ | (1,171.6) |  |

[0001262039-23-000010:mdna:107]
58

[0001262039-23-000010:mdna:108]
Components of Operating Results

[0001262039-23-000010:mdna:109]
Revenue. We generate the majority of our revenue from sales of our hardware and software products and amortization of amounts included in deferred revenue related to previous sales of FortiGuard security subscription and FortiCare technical support services. We also recognize revenue from cloud security solutions, professional services, and training.

[0001262039-23-000010:mdna:110]
Our total revenue is comprised of:

[0001262039-23-000010:mdna:111]
•Product revenue. Product revenue is primarily generated from sales of our physical and virtual machine appliances. The majority of our product revenue continues to be generated by our Core Platform product line. Product revenue also includes revenue from sales of Enhanced Platform Technologies. As a percentage of total revenue, our product revenue has varied from quarter to quarter.

[0001262039-23-000010:mdna:112]
•Service revenue. Service revenue is generated primarily from FortiGuard security subscription services and FortiCare technical support services. We recognize revenue from FortiGuard security subscription and FortiCare technical support services ratably over the service term. Our typical contractual support and subscription term is one to five years. We also generate a small portion of our revenue from other services, for which we recognize revenue as the services are provided, and cloud-based services, for which we recognize revenue as the services are delivered or on a monthly usage basis. As a percentage of total revenue, we continue to expect service revenue to be higher than product revenue. Our service revenue growth rate depends significantly on the growth of our customer base, the expansion of our service bundle offerings, the mix of our product revenue, pricing actions, the expansion and introduction of new service offerings, the attach rate of service contracts to new product sales, and the renewal of service contracts by our existing customers.

[0001262039-23-000010:mdna:113]
Our total cost of revenue is comprised of:

[0001262039-23-000010:mdna:114]
•Cost of product revenue. The majority of the cost of product revenue consists of third-party contract manufacturers’ costs and the costs of materials used in production. Our cost of product revenue also includes supplies, shipping costs, personnel costs associated with logistics and quality control, facility-related costs, excess and obsolete inventory costs, warranty costs and amortization of intangible assets. Personnel costs include compensation benefits and stock-based compensation.

[0001262039-23-000010:mdna:115]
•Cost of service revenue. Cost of service revenue is primarily comprised of personnel costs, third-party repair and contract fulfillment, data center costs, colocation expenses and cloud hosting, supplies, facility-related costs and amortization of intangible assets.

[0001262039-23-000010:mdna:116]
Gross margin. Gross profit as a percentage of revenue, or gross margin, has been and will continue to be affected by a variety of factors, including the average sales price of our products, product costs, the mix of products sold and the mix of revenue between hardware products, software licenses and services and any excess inventory or other charges. Service revenue and software licenses have higher gross margins compared to hardware products. During 2022, product gross margin benefited from gains in average selling price, partially offset by higher component costs due to supply chain constraints and the consolidation of Alaxala Networks Corporation (“Alaxala”) starting from August 31, 2021. It also benefited from software revenue growth. Service gross margin decreased due to data center expansion, increased labor cost and our consolidation of Alaxala, partially offset by favorable impact of foreign currency exchange rates and higher average selling prices. Overall gross margin in 2023 will be impacted by service and product revenue mix.

[0001262039-23-000010:mdna:117]
Operating expenses. Our operating expenses consist of research and development, sales and marketing and general and administrative expenses. Personnel costs are the most significant component of operating expenses and consist primarily of salaries, benefits, bonuses, sales commissions and stock-based compensation. We expect personnel costs to continue to increase in absolute dollars as we expand our workforce.

[0001262039-23-000010:mdna:118]
•Research and development. Research and development expense consists primarily of personnel costs. Additional research and development expenses include ASIC and system prototypes and certification-related expenses, depreciation of property and equipment and facility-related expenses. The majority of our research and development is focused on software development and the ongoing development of our hardware products. We record research and development expenses as incurred. As of December 31, 2022, approximately 89% of our research and development teams were located in Canada, the United States and India. As of December 31, 2022, approximately two-thirds of our engineers worked on software development while the remainder worked on hardware development.

[0001262039-23-000010:mdna:119]
•Sales and marketing. Sales and marketing expense is the largest component of our operating expenses and primarily consists of personnel costs. Additional sales and marketing expenses include product marketing, public relations, field marketing and events and channel marketing programs (e.g., partner cooperative marketing arrangements), as well as travel, depreciation of property and equipment and facility-related expenses. We intend to hire additional personnel focused on sales and marketing and expand our sales and marketing efforts worldwide in order to capture market share.

[0001262039-23-000010:mdna:120]
•General and administrative. General and administrative expense consists of personnel costs, as well as professional fees, depreciation of property and equipment and software and facility-related expenses. General and administrative personnel include our executive, finance, human resources, information technology and legal organizations. Our professional fees principally consist of outside legal, auditing, tax, information technology and other consulting costs.

[0001262039-23-000010:mdna:121]
•Gain on intellectual property matter. Gain on intellectual property matter consists of the amortization of the deferred component of an agreement with a competitor in the network security industry, whereby, the competitor party paid us a lump sum of $50.0 million for a seven-year mutual covenant-not-to-sue for patent claims.

[0001262039-23-000010:mdna:122]
Interest income. Interest income consists primarily of interest earned on our cash equivalents and investments. Historically, our investments include corporate debt securities, certificates of deposit and term deposits, commercial paper, money market funds, U.S. government and agency securities and municipal bonds.

[0001262039-23-000010:mdna:123]
Interest expense. Interest expense consists primarily of interest expense due to the senior notes and other miscellaneous interest expense.

[0001262039-23-000010:mdna:124]
Other expense—net. Other expense—net consists primarily of foreign exchange gains and losses related to foreign currency remeasurement, gains or losses due to the changes in fair value of our marketable equity securities, realized gains and losses of available-for-sale securities, net rental income from real estate, as well as the gain on the sale or the impairment charges of our investments in privately held companies without readily determinable fair values, which are not accounted for under the equity method.

[0001262039-23-000010:mdna:125]
Provision for income taxes. We are subject to income taxes in the United States, as well as other tax jurisdictions or countries in which we conduct business. Earnings from our non-U.S. activities are subject to income taxes in local countries and may be subject to U.S. income taxes. Our effective tax rate differs from the U.S. statutory rate primarily due to foreign income subject to different tax rates than in the U.S., federal research and development tax credit, state income taxes, withholding taxes, excess tax benefits related to stock-based compensation expense and the tax impacts of the foreign-derived intangible income (“FDII”) deduction.

[0001262039-23-000010:mdna:126]
Critical Accounting Policies and Estimates

[0001262039-23-000010:mdna:127]
Our discussion and analysis of our financial condition and results of operations are based upon our financial statements, which have been prepared in accordance with GAAP. These principles require us to make estimates and judgments that affect the reported amounts of assets, liabilities, revenue, cost of revenue and expenses, and related disclosures. We base our estimates on historical experience and on various other assumptions that we believe to be reasonable under the circumstances. To the extent that there are material differences between these estimates and our actual results, our future financial statements will be affected.

[0001262039-23-000010:mdna:128]
We believe that, of the significant accounting policies described in Note 1 to our consolidated financial statements included in Part II, Item 8 of this Annual Report on Form 10-K, the following accounting policies involve a greater degree of judgment and complexity. Accordingly, we believe these are the most critical to fully understand and evaluate our financial condition and results of operations.

[0001262039-23-000010:mdna:129]
Revenue Recognition

[0001262039-23-000010:mdna:130]
Revenues are recognized when control of goods or services is transferred to our customers, in an amount that reflects the consideration we expect to be entitled to in exchange for those goods or services.

[0001262039-23-000010:mdna:131]
We determine revenue recognition through the following steps:

[0001262039-23-000010:mdna:132]
•identification of a contract or contracts with a customer;

[0001262039-23-000010:mdna:133]
60

[0001262039-23-000010:mdna:134]
•identification of the performance obligations in a contract, including evaluation of performance obligations as to being distinct goods or services in a contract;

[0001262039-23-000010:mdna:135]
•determination of a transaction price;

[0001262039-23-000010:mdna:136]
•allocation of a transaction price to the performance obligations in a contract; and

[0001262039-23-000010:mdna:137]
•recognition of revenue when, or as, we satisfy a performance obligation.

[0001262039-23-000010:mdna:138]
Our sales contracts typically contain multiple deliverables, such as hardware, software license, security subscription, technical support services and other services, which are generally capable of being distinct and accounted for as separate performance obligations. Our hardware and software licenses have significant standalone functionalities and capabilities. Accordingly, the hardware and software licenses are distinct from the security subscription and technical support services, as a customer can benefit from the product without the services and the services are separately identifiable within a contract. We allocate a transaction price to each performance obligation based on relative standalone selling price. We establish standalone selling price using the prices charged for a deliverable when sold separately. If not observable through past transactions, we determine standalone selling price by considering multiple historical factors including, but not limited to, cost of products, gross margin objectives, pricing practices, geographies and the term of a service contract.

[0001262039-23-000010:mdna:139]
Deferred Contract Costs and Commission Expense

[0001262039-23-000010:mdna:140]
We defer contract costs that are recoverable and incremental to obtaining customer sales contracts. Contract costs, which primarily consist of sales commissions, are amortized on a systematic basis that is consistent with the transfer to the customer of the goods or services to which the asset relates. Costs for initial contracts that are not commensurate with commissions on renewal contracts are amortized on a straight-line basis over the period of benefit of five years. Estimates, assumptions, and judgments in accounting for deferred contract costs include, but are not limited to, identification of contract costs, anticipated billings and the expected period of benefit.

[0001262039-23-000010:mdna:141]
Business Combinations

[0001262039-23-000010:mdna:142]
We include the results of operations of the businesses that we acquire as of the respective dates of acquisition. We allocate the fair value of the purchase price of our business acquisitions to the tangible and intangible assets acquired and liabilities assumed based on their estimated fair values. The excess of the purchase price over the fair values of these identifiable assets and liabilities is recorded as goodwill. We often continue to gather additional information throughout the measurement period, and if we make changes to the amounts recorded, such changes are recorded in the period in which they are identified.

[0001262039-23-000010:mdna:143]
Contingent Liabilities

[0001262039-23-000010:mdna:144]
From time to time, we are involved in disputes, litigation and other legal actions. However, there are many uncertainties associated with any litigation, and these actions or other third-party claims against us may cause us to incur substantial settlement charges, which are inherently difficult to estimate and could adversely affect our results of operations. We periodically review significant claims and litigation matters for the probability of an adverse outcome. We accrue for a loss contingency if a loss is probable and the amount of the loss can be reasonably estimated. These accruals are generally based on a range of possible outcomes that require significant judgement. Estimates can change as individual claims develop. The actual liability in any such matters may be materially different from our estimates, which could result in the need to adjust our liability and record additional expenses.

[0001262039-23-000010:mdna:145]
Accounting for Income Taxes

[0001262039-23-000010:mdna:146]
We record income taxes using the asset and liability method, which requires the recognition of deferred tax assets and liabilities for the expected future tax consequences of events that have been recognized in our financial statements or tax returns. In addition, deferred tax assets are recorded for the future benefit of utilizing net operating losses and research and development credit carryforwards. Deferred tax assets and liabilities are measured using the currently enacted tax rates that apply to taxable income in effect for the years in which those tax assets and liabilities are expected to be realized or settled. Valuation allowances are provided when necessary to reduce deferred tax assets to the amount expected to be realized.

[0001262039-23-000010:mdna:147]
As part of the process of preparing our consolidated financial statements, we are required to estimate our taxes in each of the jurisdictions in which we operate. We estimate actual current tax exposure together with assessing temporary differences resulting from differing treatment of items, such as accruals and allowances not currently deductible for tax purposes. These differences result in deferred tax assets, which are included in our consolidated balance sheets. In general, deferred tax assets

[0001262039-23-000010:mdna:148]
61

[0001262039-23-000010:mdna:149]
represent future tax benefits to be received when certain expenses previously recognized in our consolidated statements of income become deductible expenses under applicable income tax laws, or loss or credit carryforwards are utilized.

[0001262039-23-000010:mdna:150]
In assessing the realizability of deferred tax assets, management considers whether it is more likely than not that some portion or all of the deferred tax assets will be realized. The ultimate realization of deferred tax assets is dependent upon the generation of future taxable income during the periods in which those temporary differences become deductible. We continue to assess the need for a valuation allowance on the deferred tax assets by evaluating both positive and negative evidence that may exist. Any adjustment to the valuation allowance on deferred tax assets would be recorded in the consolidated statements of income for the period that the adjustment is determined to be required.

[0001262039-23-000010:mdna:151]
We recognize tax benefits from an uncertain tax position only if it is more likely than not, based on the technical merits of the position that the tax position will be sustained on examination by the tax authorities. The tax benefits recognized in the financial statements from such positions are then measured based on the largest benefit that has a greater than 50% likelihood of being realized upon ultimate settlement.

[0001262039-23-000010:mdna:152]
Investments in privately held companies

[0001262039-23-000010:mdna:153]
Our investments in privately held companies consist of investments in common stock or in-substance common stock. One of these investments provides us with the ability to exercise significant influence over the investee, but not an absolute controlling financial interest. The investment is accounted for under the equity method of accounting. Determining that we do not control but exercise significant influence over the operating and financial policies of the investee requires significant judgement when considering many factors, including but not limited to, the ownership interest in the investee, board representation, participation in policy-making processes, and participation rights in certain significant financial and operating decisions of the investee in the ordinary course of business. Our investment in Linksys is our only equity method investment. We record our proportionate share of the net earnings or losses of Linksys based on the most recently available financial statements of Linksys, which are provided to us on a three-month lag. We evaluate if there are material transactions or events that occur during the intervening period that materially affect the financial position or results of operations. We also record our share of the amortization of any basis differences, as well as any OTTI as gain or loss from equity method investment in our consolidated statements of income and as an adjustment to the investment balance.

[0001262039-23-000010:mdna:154]
We evaluate our equity method investment at the end of each reporting period to determine whether events or changes in business circumstances indicate that the carrying value of the investment may not be recoverable. Evidence of a loss in value might include, but would not necessarily be limited to, series of operating losses, current expected performance relative to expected performance when we initially invested, performance relative to peers and the results of a discounted cash flow analysis. We consider various factors in determining whether an OTTI has occurred, including Linksys financial results and operating history, our ability and intent to hold the investment until its fair value recovers, the implied revenue valuation multiples compared to guideline public companies, Linksys’ ability to achieve milestones and any notable operational and strategic changes.

[0001262039-23-000010:mdna:155]
62

[0001262039-23-000010:mdna:156]
Results of Operations

[0001262039-23-000010:mdna:157]
The following tables set forth our results of operations for the periods presented and as a percentage of our total revenue for those periods. The period-to-period comparison of financial results is not necessarily indicative of financial results to be achieved in future periods.

[0001262039-23-000010:mdna:158]
|  | Year Ended December 31, |
|  | 2022 |  | 2021 |  | 2020 |
|  | (in millions) |
| Consolidated Statements of Income Data: |  |  |  |  |  |
| Revenue: |  |  |  |  |  |
| Product | $ | 1,780.5 |  |  | $ | 1,255.0 |  |  | $ | 916.4 |  |
| Service | 2,636.9 |  |  | 2,087.2 |  |  | 1,678.0 |  |
| Total revenue | 4,417.4 |  |  | 3,342.2 |  |  | 2,594.4 |  |
| Cost of revenue: |  |  |  |  |  |
| Product | 691.3 |  |  | 487.7 |  |  | 352.4 |  |
| Service | 393.6 |  |  | 295.3 |  |  | 217.6 |  |
| Total cost of revenue | 1,084.9 |  |  | 783.0 |  |  | 570.0 |  |
| Gross profit: |  |  |  |  |  |
| Product | 1,089.2 |  |  | 767.3 |  |  | 564.0 |  |
| Service | 2,243.3 |  |  | 1,791.9 |  |  | 1,460.4 |  |
| Total gross profit | 3,332.5 |  |  | 2,559.2 |  |  | 2,024.4 |  |
| Operating expenses: |  |  |  |  |  |
| Research and development | 512.4 |  |  | 424.2 |  |  | 341.4 |  |
| Sales and marketing | 1,686.1 |  |  | 1,345.7 |  |  | 1,071.9 |  |
| General and administrative | 169.0 |  |  | 143.5 |  |  | 119.5 |  |
| Gain on intellectual property matter | (4.6) |  |  | (4.6) |  |  | (40.2) |  |
| Total operating expenses | 2,362.9 |  |  | 1,908.8 |  |  | 1,492.6 |  |
| Operating income | 969.6 |  |  | 650.4 |  |  | 531.8 |  |
| Interest income | 17.4 |  |  | 4.5 |  |  | 17.7 |  |
| Interest expense | (18.0) |  |  | (14.9) |  |  | — |  |
| Other expense—net | (13.5) |  |  | (11.6) |  |  | (7.8) |  |
| Income before income taxes and loss from equity method investment | 955.5 |  |  | 628.4 |  |  | 541.7 |  |
| Provision for income taxes | 30.8 |  |  | 14.1 |  |  | 53.2 |  |
| Loss from equity method investment | (68.1) |  |  | (7.6) |  |  | — |  |
| Net income including non-controlling interests | 856.6 |  |  | 606.7 |  |  | 488.5 |  |
| Less: net loss attributable to non-controlling interests, net of tax | (0.7) |  |  | (0.1) |  |  | — |  |
| Net income attributable to Fortinet, Inc. | $ | 857.3 |  |  | $ | 606.8 |  |  | $ | 488.5 |  |

[0001262039-23-000010:mdna:159]
63

[0001262039-23-000010:mdna:160]
|  | Year Ended December 31, |
| 2022 |  | 2021 |  | 2020 |
| (as percentage of revenue) |
| Revenue: |  |  |  |  |  |
| Product | 40 | % |  | 38 | % |  | 35 | % |
| Service | 60 |  |  | 62 |  |  | 65 |  |
| Total revenue | 100 |  |  | 100 |  |  | 100 |  |
| Cost of revenue: |  |  |  |  |  |
| Product | 16 |  |  | 15 |  |  | 14 |  |
| Service | 9 |  |  | 9 |  |  | 8 |  |
| Total cost of revenue | 25 |  |  | 23 |  |  | 22 |  |
| Gross margin: |  |  |  |  |  |
| Product | 61 |  |  | 61 |  |  | 62 |  |
| Service | 85 |  |  | 86 |  |  | 87 |  |
| Total gross margin | 75 |  |  | 77 |  |  | 78 |  |
| Operating expenses: |  |  |  |  |  |
| Research and development | 12 |  |  | 13 |  |  | 13 |  |
| Sales and marketing | 38 |  |  | 40 |  |  | 41 |  |
| General and administrative | 4 |  |  | 4 |  |  | 5 |  |
| Gain on intellectual property matter | — |  |  | — |  |  | (2) |  |
| Total operating expenses | 53 |  |  | 57 |  |  | 58 |  |
| Operating margin | 22 |  |  | 19 |  |  | 20 |  |
| Interest income | — |  |  | — |  |  | 1 |  |
| Interest expense | — |  |  | — |  |  | — |  |
| Other expense—net | — |  |  | — |  |  | — |  |
| Income before income taxes and loss from equity method investment | 22 |  |  | 19 |  |  | 21 |  |
| Provision for income taxes | 1 |  |  | — |  |  | 2 |  |
| Loss from equity method investment | (2) |  |  | — |  |  | — |  |
| Net income including non-controlling interests | 19 |  |  | 18 |  |  | 19 |  |
| Less: net loss attributable to non-controlling interests, net of tax | — |  |  | — |  |  | — |  |
| Net income attributable to Fortinet, Inc. | 19 | % |  | 18 | % |  | 19 | % |
| Percentages have been rounded for presentation purposes and may differ from unrounded results. |

[0001262039-23-000010:mdna:161]
Discussion regarding our financial condition and results of operations for 2021 as compared to 2020 can be found in Item 7 of our Annual Report on Form 10-K for the fiscal year ended December 31, 2021, filed with the SEC on February 25, 2022.

[0001262039-23-000010:mdna:162]
64

[0001262039-23-000010:mdna:163]
2022 and 2021

[0001262039-23-000010:mdna:164]
Revenue

[0001262039-23-000010:mdna:165]
|  | Year Ended December 31, |  |  |  |  |
| 2022 |  | 2021 |  |  |  |  |
| Amount |  | % ofRevenue |  | Amount |  | % ofRevenue |  | Change |  | % Change |
| (in millions, except percentages) |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 1,780.5 |  |  | 40 | % |  | $ | 1,255.0 |  |  | 38 | % |  | $ | 525.5 |  |  | 42 | % |
| Service | 2,636.9 |  |  | 60 |  |  | 2,087.2 |  |  | 62 |  |  | 549.7 |  |  | 26 |  |
| Total revenue | $ | 4,417.4 |  |  | 100 | % |  | $ | 3,342.2 |  |  | 100 | % |  | $ | 1,075.2 |  |  | 32 | % |
| Revenue by geography: |  |  |  |  |  |  |  |  |  |  |  |
| Americas | $ | 1,785.0 |  |  | 41 | % |  | $ | 1,358.8 |  |  | 41 | % |  | $ | 426.2 |  |  | 31 | % |
| EMEA | 1,691.8 |  |  | 38 |  |  | 1,275.9 |  |  | 38 |  |  | 415.9 |  |  | 33 |  |
| APAC | 940.6 |  |  | 21 |  |  | 707.5 |  |  | 21 |  |  | 233.1 |  |  | 33 |  |
| Total revenue | $ | 4,417.4 |  |  | 100 | % |  | $ | 3,342.2 |  |  | 100 | % |  | $ | 1,075.2 |  |  | 32 | % |

[0001262039-23-000010:mdna:166]
Total revenue increased by $1.08 billion, or 32%, in 2022 compared to 2021. We continued to experience significant organic revenue growth (i.e., revenue growth excluding attribution from recent acquisitions) with diversification of revenue geographically, and across both customer and industry segments. Revenue from all regions grew, with the Americas contributing the largest portion of the increase on an absolute dollar basis and APAC, which included Alaxala, contributing the largest portion of the increase on a percentage basis.

[0001262039-23-000010:mdna:167]
Product revenue increased by $525.5 million, or 42%, in 2022 compared to 2021. Product revenue growth was consistent with an elevated cyber threat landscape, the convergence of security and networking and included the benefit of certain pricing actions. The product revenue growth was primarily due to strong growth across many of our Enhanced Platform Technology products, including our secure access products and software licenses. In addition, our product revenue growth was driven by a strong demand for the wide range operating system capabilities embedded in our Core Platform products.

[0001262039-23-000010:mdna:168]
Service revenue increased by $549.7 million, or 26%, in 2022 compared to 2021. Service revenue growth has accelerated over the past three years from 22% in 2020, to 24% in 2021 to 26% in 2022. Compared to 2021, FortiGuard security subscription revenue increased by $302.0 million, or 27% and FortiCare, other technical support and other revenues increased by $247.7 million, or 26%, in 2022. The increases were primarily due to the recognition of revenue from our growing deferred revenue balance related to FortiGuard and other security subscriptions delivered to on-premise and cloud-based environments as well as FortiCare and other technical support. Our growing deferred revenue balance was primarily due to our growth in customer base, expansion of our service offerings, and impact of pricing actions.

[0001262039-23-000010:mdna:169]
Of the service revenue recognized in 2022, 66% was included in the deferred revenue balance as of December 31, 2021. Of the service revenue recognized in 2021, 65% was included in the deferred revenue balance as of December 31, 2020.

[0001262039-23-000010:mdna:170]
Of the service revenue recognized in each quarter of 2022, from 87% to 88% was included in deferred revenue as of the beginning of the respective quarter.

[0001262039-23-000010:mdna:171]
65

[0001262039-23-000010:mdna:172]
Cost of revenue and gross margin

[0001262039-23-000010:mdna:173]
|  | Year Ended December 31, |  |  |  |  |
| 2022 |  | 2021 |  | Change |  | % Change |
| (in millions, except percentages) |
| Cost of revenue: |  |  |  |  |  |  |  |
| Product | $ | 691.3 |  |  | $ | 487.7 |  |  | $ | 203.6 |  |  | 42 | % |
| Service | 393.6 |  |  | 295.3 |  |  | 98.3 |  |  | 33 |  |
| Total cost of revenue | $ | 1,084.9 |  |  | $ | 783.0 |  |  | $ | 301.9 |  |  | 39 | % |
| Gross margin (%): |  |  |  |  |  |  |  |
| Product | 61.2 | % |  | 61.1 | % |  |  |  |  |
| Service | 85.1 | % |  | 85.9 | % |  |  |  |  |
| Total gross margin | 75.4 | % |  | 76.6 | % |  |  |  |  |

[0001262039-23-000010:mdna:174]
Total gross margin decreased by 1.2 percentage points in 2022 compared to 2021, primarily driven by a change in revenue mix to lower margin product revenue from higher margin service revenue and the consolidation of Alaxala starting from August 31, 2021 and partially offset by favorable impact of foreign currency fluctuations. Revenue mix shifted by 2.0 percentage points from service revenue to product revenue, as a percentage of total revenue.

[0001262039-23-000010:mdna:175]
Product gross margin increased by 0.1 percentage points in 2022 compared to 2021, primarily driven by higher average selling prices and partially offset by higher expedite fees and other component costs due to supply chain constraints and the consolidation of Alaxala. Cost of product revenue was comprised primarily of third-party contract manufacturers’ costs and the costs of materials used in production.

[0001262039-23-000010:mdna:176]
Service gross margin decreased by 0.8 percentage points in 2022 compared to 2021, primarily driven by data center expansion, increased labor cost and our consolidation of Alaxala and partially offset by favorable impact of foreign currency fluctuation and higher average selling prices. Cost of service revenue was comprised primarily of personnel costs, third-party repair and contract fulfillment, data center costs, colocation expenses and cloud hosting, supplies and facility-related costs.

[0001262039-23-000010:mdna:177]
Operating expenses

[0001262039-23-000010:mdna:178]
|  | Year Ended December 31, |  | Change |  | % Change |
| 2022 |  | 2021 |  |
| Amount |  | % ofRevenue |  | Amount |  | % ofRevenue |  |
| (in millions, except percentages) |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | $ | 512.4 |  |  | 12 | % |  | $ | 424.2 |  |  | 13 | % |  | $ | 88.2 |  |  | 21 | % |
| Sales and marketing | 1,686.1 |  |  | 38 |  |  | 1,345.7 |  |  | 40 |  |  | 340.4 |  |  | 25 |  |
| General and administrative | 169.0 |  |  | 4 |  |  | 143.5 |  |  | 4 |  |  | 25.5 |  |  | 18 |  |
| Gain on intellectual property matter | (4.6) |  |  | — |  |  | (4.6) |  |  | — |  |  | — |  |  | — |  |
| Total operating expenses | $ | 2,362.9 |  |  | 53 | % |  | $ | 1,908.8 |  |  | 57 | % |  | $ | 454.1 |  |  | 24 | % |
| Percentages have been rounded for presentation purposes and may differ from unrounded results. |

[0001262039-23-000010:mdna:179]
Research and development

[0001262039-23-000010:mdna:180]
Research and development expense increased by $88.2 million, or 21%, in 2022 compared to 2021, primarily due to an increase of $63.1 million in personnel-related costs as a result of increased compensation rates and headcount to support the development of new products and continued enhancements to our existing products. In addition, we incurred increases in depreciation and other occupancy costs of $16.6 million and product development costs of $4.9 million, partially offset by the favorable impact of foreign currency fluctuations. We currently intend to continue to invest in our research and development organization, and expect research and development expense to increase in absolute dollars in 2023.

[0001262039-23-000010:mdna:181]
Sales and marketing

[0001262039-23-000010:mdna:182]
Sales and marketing expense increased by $340.4 million, or 25%, in 2022 compared to 2021, primarily due to an increase of $208.5 million in personnel-related costs. We significantly increased our sales capacity, including newer non-tenured salespeople. The increase in headcount is expected to help drive global revenue increases. In addition, we incurred increases in marketing-related expenses of $52.6 million, travel expense of $38.8 million, depreciation and other occupancy-related expense of $17.8 million and supplies expense of $10.6 million, partially offset by the favorable impact of foreign currency fluctuations. We currently intend to continue to make investments in sales and marketing resources, which are critical to support our future growth, and expect sales and marketing expense to increase in absolute dollars in 2023.

[0001262039-23-000010:mdna:183]
General and administrative

[0001262039-23-000010:mdna:184]
General and administrative expense increased by $25.5 million, or 18%, in 2022 compared to 2021, primarily due to an increase in personnel-related costs of $17.3 million. In addition, we incurred increases in depreciation and other occupancy costs of $3.5 million, subscriptions and other expense of $3.2 million, professional services fee of $2.9 million and provision for expected credit losses of $1.4 million, partially offset by a decrease in legal-related costs of $6.1 million and the favorable impact of foreign currency fluctuations. We currently expect general and administrative expense to increase in absolute dollars in 2023.

[0001262039-23-000010:mdna:185]
Operating income and margin

[0001262039-23-000010:mdna:186]
We generated operating income of $969.6 million in 2022, an increase of $319.2 million, or 49%, compared to $650.4 million in 2021. Operating income as a percentage of revenue increased to 22% in 2022 compared to 19% in 2021. The increase in our operating margin primarily benefits from a 2.1 percentage point decrease in sales and marketing expense as a percentage of revenue, primarily due to the favorable impact of foreign currency fluctuations, as well as improvement in sales productivity compared to prior year. In addition, research and development expense and general and administrative expense decreased 1.1 percentage points and 0.5 percentage points, respectively, as percentage of revenue. The benefit from lower operating expense as a percentage of revenue was partially offset by a 1.2 percentage point decrease in gross margin.

[0001262039-23-000010:mdna:187]
Interest income, interest expense and other expense—net

[0001262039-23-000010:mdna:188]
|  | Year Ended December 31, |  |  |  |  |
| 2022 |  | 2021 |  | Change |  | % Change |
| (in millions, except percentages) |
| Interest income | $ | 17.4 |  |  | $ | 4.5 |  |  | $ | 12.9 |  |  | 287 | % |
| Interest expense | (18.0) |  |  | (14.9) |  |  | (3.1) |  |  | 21 | % |
| Other expense—net | (13.5) |  |  | (11.6) |  |  | (1.9) |  |  | 16 | % |

[0001262039-23-000010:mdna:189]
Interest income increased by $12.9 million in 2022 as compared to 2021, primarily as a result of higher interest rates, partially offset by lower investment balances. Interest income varies depending on our average investment balances during the period, types and mix of investments, and market interest rates. Interest expense increased by $3.1 million in 2022 as compared to 2021, primarily due to our senior notes issued in the first quarter of 2021. Other expense—net increased by $1.9 million in 2022 as compared to 2021 due to an $8.0 million increase in loss on marketable equity securities, partially offset by a $3.6 million decrease in foreign exchange losses and a $2.5 million increase in net rental income from real estate.

[0001262039-23-000010:mdna:190]
Provision for income taxes

[0001262039-23-000010:mdna:191]
|  | Year Ended December 31, |  | Change |  | % Change |
| 2022 |  | 2021 |  |
| (in millions, except percentages) |
| Provision for income taxes | $ | 30.8 |  |  | $ | 14.1 |  |  | $ | 16.7 |  |  | 118 | % |
| Effective tax rate (%) | 3 | % |  | 2 | % |  |  |  |  |

[0001262039-23-000010:mdna:192]
Our provision for income taxes for 2022 reflects an effective tax rate of 3%, compared to an effective tax rate of 2% for 2021. The provision for income taxes for 2022 was comprised primarily of a $233.4 million tax expense related to U.S. federal and state income taxes, other foreign income taxes, foreign withholding taxes and unrecognized tax benefits. The provision was partially offset by excess tax benefits of $75.8 million from stock-based compensation expense, a tax benefit of $115.2 million from the FDII deduction, and a tax benefit of $11.6 million from federal research and development tax credits.

[0001262039-23-000010:mdna:193]
Our provision for income taxes for 2021 reflects an effective tax rate of 2%, compared to an effective tax rate of 10% for 2020. The provision for income taxes for 2021 was comprised primarily of a $140.8 million tax expense related to U.S. federal and state income taxes, other foreign income taxes, foreign withholding taxes and unrecognized tax benefits. The provision was partially offset by excess tax benefits of $82.0 million from stock-based compensation expense, a tax benefit of $33.6 million from the FDII deduction, and a tax benefit of $11.1 million from federal research and development tax credits.

[0001262039-23-000010:mdna:194]
Loss from Equity Method Investment

[0001262039-23-000010:mdna:195]
|  | Year Ended December 31, |  | Change |  | % Change |
| 2022 |  | 2021 |  |
| (in millions, except percentages) |
| Loss from equity method investment | $ | (68.1) |  |  | $ | (7.6) |  |  | $ | (60.5) |  |  | 796 | % |

[0001262039-23-000010:mdna:196]
Loss from equity method investment increased by $60.5 million in 2022 as compared to 2021, due to $38.3 million increase in our proportionate share of Linksys’ financial results as well as the amortization of the basis differences, which included a $17.5 million charge in connection with a valuation allowance established on deferred tax assets at Linksys, and the OTTI charge of $22.2 million recorded in the three months ended December 31, 2022.

[0001262039-23-000010:mdna:197]
Seasonality, Cyclicality and Quarterly Revenue Trends

[0001262039-23-000010:mdna:198]
Our quarterly results reflect a pattern of increased customer buying at year-end, which has positively impacted billings and product revenue activity in the fourth quarter. In the first quarter, we generally experience lower sequential customer product buying, followed by an increase in buying in the second and third quarters. Although these seasonal factors may be common in the technology sector, historical patterns should not be considered a reliable indicator of our future sales activity or performance. On a quarterly basis, we have usually generated the majority of our product revenue in the final month of each quarter and a significant amount in the last two weeks of each quarter. We believe this is due to customer buying patterns typical in this industry.

[0001262039-23-000010:mdna:199]
Consistent with the seasonality note above, our quarterly revenue over the past two years has increased sequentially each year. Product revenue increased year-over-year as compared to 2021, as we have continued product innovation and launched new product models, expanded our solution sales, including SD-WAN and OT solutions and increased our investments in our sales and marketing organizations.

[0001262039-23-000010:mdna:200]
Total gross margin has fluctuated on a quarterly basis primarily due to the relative product and service mix as well as the timing of supplier cost increases and our own price increases. Product gross margin varies based on the types of products sold, their cost profile and their average selling prices. In 2022, product gross margin was impacted by new product introductions, the mix of high-end, mid-range and entry-level Core Platform products and the mix of other Enhanced Platform Technologies products, software sales and the timing and impact of supplier cost increases and our own price list increases. In 2022, we experienced an unusual level of component suppliers charging new expedite fees and increases in freight costs. Historically, we have been able to improve our direct cost of appliances and our product gross margin. Service gross margin is impacted by revenue growth and our personnel-related costs, third-party repair and contract fulfillment, data center, colocation fees, cloud hosting, supplies, facility-related costs and foreign currency fluctuations.

[0001262039-23-000010:mdna:201]
Liquidity and Capital Resources

[0001262039-23-000010:mdna:202]
|  | As of December 31, |
|  | 2022 |  | 2021 |  | 2020 |
|  | (in millions) |
| Cash and cash equivalents | $ | 1,682.9 |  |  | $ | 1,319.1 |  |  | $ | 1,061.8 |  |
| Short-term and long-term investments | 548.1 |  |  | 1,634.8 |  |  | 893.8 |  |
| Marketable equity securities | 25.5 |  |  | 38.6 |  | — |  |
| Total cash, cash equivalents, investments and marketable equity securities | $ | 2,256.5 |  |  | $ | 2,992.5 |  |  | $ | 1,955.6 |  |
| Working capital | $ | 732.0 |  |  | $ | 1,282.5 |  |  | $ | 910.9 |  |
|  | Year Ended December 31, |
|  | 2022 |  | 2021 |  | 2020 |
|  | (in millions) |
| Net cash provided by operating activities | $ | 1,730.6 |  |  | $ | 1,499.7 |  |  | $ | 1,083.7 |  |
| Net cash provided by (used in) investing activities | 763.9 |  |  | (1,325.1) |  |  | (72.8) |  |
| Net cash provided by (used in) financing activities | (2,130.3) |  |  | 82.8 |  |  | (1,171.6) |  |
| Effect of exchange rate changes on cash and cash equivalents | (0.4) |  |  | (0.1) |  |  | — |  |
| Net increase (decrease) in cash and cash equivalents | $ | 363.8 |  |  | $ | 257.3 |  |  | $ | (160.7) |  |

[0001262039-23-000010:mdna:203]
69

[0001262039-23-000010:mdna:204]
Liquidity and capital resources are primarily impacted by our operating activities, including cash tax payments, proceeds from issuance of our investment grade debt, as well as cash used on stock repurchases, real estate purchases and other capital expenditures, investments in various companies and business acquisitions.

[0001262039-23-000010:mdna:205]
In recent years, we have received significant capital resources from our billings to customers, issuance of investment grade debt and, to some extent, from the exercise of stock options by our employees. Additional increases in billings may depend on a number of factors, including demand for and availability of our products and services, competition, market or industry changes, macroeconomic events such as rising inflation and interest rates, the COVID-19 pandemic, supply chain capacity and disruptions, international conflicts, including the war in Ukraine, and our ability to execute. We expect proceeds from the exercise of stock options in future years to be impacted by the increased mix of restricted stock units versus stock options granted to our employees and to vary based on our share price. We expect our cash tax payments to increase as a result of a provision in the TCJA requiring taxpayers to capitalize and amortize research and development expenses for tax purposes, other tax law changes and our expected growth.

[0001262039-23-000010:mdna:206]
In July 2022, our board of directors authorized a $1.0 billion increase in the authorized stock repurchase under the Repurchase Program, bringing the aggregate amount of authorized to be repurchased to $5.25 billion of our outstanding common stock through February 28, 2023. In 2022, we repurchased 36.0 million shares of common stock under the Repurchase Program for an aggregate purchase price of $1.99 billion. As of December 31, 2022, $529.6 million remained available for future share repurchases under the Repurchase Program. In February 2023, our board of directors approved an extension of the Repurchase Program to February 29, 2024.

[0001262039-23-000010:mdna:207]
In March 2021, we issued $1.0 billion aggregate principal amount of senior notes, consisting of $500.0 million aggregate principal amount of 1.0% notes due March 15, 2026 and $500.0 million aggregate principal amount of 2.2% notes due March 15, 2031, in an underwritten registered public offering. We do not currently intend to retire these senior notes early. Refer to Note 11. Debt in Part II, Item 8 of this Annual Report on Form 10-K for information on the senior notes.

[0001262039-23-000010:mdna:208]
We expect to continue to increase our data center, office and warehouse capacity to support growth and the expansion of existing services or introduction of new services. As we purchase new properties, we will work to incorporate these properties into the environmental goals we have established. We estimate 2023 capital expenditures to be between $400.0 million and $450.0 million.

[0001262039-23-000010:mdna:209]
Our principal commitments consist of obligations under our senior notes, inventory purchase and other contractual commitments. As of December 31, 2022, the long-term debt, net of unamortized discount and debt issuance costs, was $990.4 million. $500.0 million in aggregate principal amount of senior notes is due on March 15, 2026 and $500.0 million in aggregate principal amount of senior notes is due on March 15, 2031. In addition, we enter into non-cancellable agreements with contract manufacturers to procure inventory based on our requirements in order to reduce manufacturing lead times, plan for adequate component supply or incentivize suppliers to deliver. In certain instances, these agreements allow us the option to reschedule and adjust our requirements based on our business needs prior to firm orders being placed. In 2022, we significantly increased these commitments as contract manufacturers and component suppliers significantly increased their pricing and lead times. Inventory purchase commitments as of December 31, 2022, were $1.34 billion, an increase of $194.5 million compared to $1.14 billion as of December 31, 2021. We estimate payments of $1.27 billion due on or before December 31, 2023 related to these commitments. We also have open purchase orders and contractual obligations in the ordinary course of business for which we have not received goods or services. As of December 31, 2022, we had $108.1 million in other contractual commitments having a remaining term in excess of one year that are non-cancelable.

[0001262039-23-000010:mdna:210]
As of December 31, 2022, our cash, cash equivalents, investments and marketable equity securities of $2.26 billion were invested primarily in deposit accounts, commercial paper, corporate debt securities, U.S. government and agency securities, certificates of deposit and term deposits, money market funds, municipal bonds and marketable equity securities. It is our investment policy to invest excess cash in a manner that preserves capital, provides liquidity and generates return without significantly increasing risk. We do not enter into investments for trading or speculative purposes.

[0001262039-23-000010:mdna:211]
The amount of cash, cash equivalents and investments held by our international subsidiaries was $218.1 million and $132.4 million as of December 31, 2022 and 2021, respectively.

[0001262039-23-000010:mdna:212]
We believe that our existing cash and cash equivalents and cash flow from operations will be sufficient for at least the next 12 months to meet our requirements and plans for cash, including meeting our working capital requirements and capital expenditure requirements. In the long term, our ability to support our requirements and plans for cash, including our working capital and capital expenditure requirements will depend on many factors, including our growth rate, the timing and amount of our share repurchases, the expansion of sales and marketing activities, the introduction of new and enhanced products and services offerings, the continuing market acceptance of our products, the timing and extent of spending to support development efforts, our investments in purchasing or leasing real estate, cash tax payments and macroeconomic impacts such as rising inflation and interest rates, the war in Ukraine and the COVID-19 pandemic. Historically, we have required capital principally

[0001262039-23-000010:mdna:213]
to fund our working capital needs, share repurchases, capital expenditures and acquisition activities. In the event that additional financing is required from outside sources, we may not be able to raise it on terms acceptable to us or at all.

[0001262039-23-000010:mdna:214]
During 2022, 2021 and 2020, we did not have any relationships with unconsolidated organizations or financial partnerships, such as structured finance or special purpose entities that would have been established for the purpose of facilitating off-balance sheet arrangements or other contractually narrow or limited purposes.

[0001262039-23-000010:mdna:215]
Operating Activities

[0001262039-23-000010:mdna:216]
Cash generated by operating activities is our primary source of liquidity. It is primarily comprised of net income, as adjusted for non-cash items and changes in operating assets and liabilities. Non-cash adjustments consist primarily of amortization of deferred contract costs, stock-based compensation and depreciation and amortization. Changes in operating assets and liabilities consist primarily of changes in deferred revenue, accounts receivable, net, deferred contract costs and deferred tax assets.

[0001262039-23-000010:mdna:217]
Our operating activities during 2022 provided cash flows of $1.73 billion as a result of the continued growth of our business and our ability to successfully manage our working capital. Changes in operating assets and liabilities primarily resulted from an increase in sales of our FortiGuard and other security subscription services and FortiCare technical support services to new and existing customers, as reflected by an increase of $1.18 billion in our deferred revenue during 2022.

[0001262039-23-000010:mdna:218]
Investing Activities

[0001262039-23-000010:mdna:219]
The changes in cash flows from investing activities primarily relate to timing of purchases, maturities and sales of investments, purchases of property and equipment, investments in various companies and business acquisitions. Historically, in making a lease-versus-ownership decision related to warehouse, office or data center space, we have considered various factors including financial metrics and expected long-term growth rates. In certain cases, we have elected to own the facility if we believed that purchasing or developing buildings rather than leasing is more in line with our long-term strategy. We may make similar decisions in the future. We may also make cash payments in connection with future business combinations.

[0001262039-23-000010:mdna:220]
During 2022, cash provided by investing activities was primarily driven by $1.08 billion cash proceeds from maturities and sales of investments, net of purchases of investments, $281.2 million of purchases of property and equipment, and $30.8 million used for the acquisitions of certain assets and liabilities in a network detection and response business and the remaining 25% equity interests in Alaxala, net of cash.

[0001262039-23-000010:mdna:221]
Financing Activities

[0001262039-23-000010:mdna:222]
The changes in cash flows from financing activities primarily relate to repurchase and retirement of common stock, and taxes paid related to net share settlement of equity awards, net of proceeds from the issuance of common stock under our Amended and Restated 2009 Equity Incentive Plan (the “2009 EIP”).

[0001262039-23-000010:mdna:223]
During 2022, cash used in financing activities was $2.13 billion, primarily driven by $1.99 billion used to repurchase shares of our common stock and $134.3 million used to pay tax withholding, net of proceeds from the issuance of common stock.

[0001262039-23-000010:mdna:224]
Recent Accounting Pronouncements

[0001262039-23-000010:mdna:225]
Refer to Note 1 of the notes to our consolidated financial statements in Part II, Item 8 of this Annual Report on Form 10-K for a full description of recently adopted accounting pronouncements.
