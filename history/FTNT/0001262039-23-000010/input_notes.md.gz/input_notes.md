# FTNT notes — 0001262039-23-000010


## dei:DocumentsIncorporatedByReferenceTextBlock

[0001262039-23-000010:notes:1]
Portions of the registrant’s definitive Proxy Statement relating to its 2023 Annual Meeting of Stockholders (“Proxy Statement”) are incorporated by reference into Part III of this Annual Report on Form 10-K where indicated. Such Proxy Statement will be filed with the United States Securities and Exchange Commission within 120 days after the end of the fiscal year to which this report relates


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001262039-23-000010:notes:2]
THE COMPANY AND SUMMARY OF SIGNIFICANT ACCOUNTING POLICIES
Business—Fortinet, Inc. (“Fortinet”) was incorporated in Delaware in 2000 and is a global leader in broad, integrated and automated cybersecurity solutions. Fortinet provides high performance cybersecurity solutions to a wide variety of businesses, such as large enterprises, communication service providers, government organizations and small to medium-sized enterprises. Fortinet’s cybersecurity solutions are designed to provide broad visibility and segmentation of the digital attack surface, through our integrated cybersecurity mesh architecture (the “Fortinet Security Fabric”) with automated protection, detection and responses.

[0001262039-23-000010:notes:3]
Basis of Presentation and Preparation—The consolidated financial statements of Fortinet and its subsidiaries (collectively, “we,” “us” or “our”) have been prepared in accordance with generally accepted accounting principles in the United States (“GAAP”). We consolidate all legal entities in which we have an absolute controlling financial interest. All intercompany transactions and balances have been eliminated in consolidation.

[0001262039-23-000010:notes:4]
On April 14, 2022, our board of directors approved a five-for-one forward stock split of our common stock (the “Forward Stock Split”), which was conditioned upon obtaining stockholder approval for the Forward Stock Split, and to increase the number of our authorized shares of common stock. On June 17, 2022, at our 2022 Annual Meeting of Stockholders, our stockholders approved the Forward Stock Split and the amendment and restatement of our amended and restated certificate of incorporation to increase the number of authorized shares of common stock from 300.0 million to 1.5 billion. The par value of our common stock was not adjusted as a result of the Forward Stock Split. Effective June 22, 2022, we filed our amended and restated certification of incorporation and completed the Forward Stock Split. All share and per share amounts and related stockholders’ equity (deficit) balances presented herein have been retroactively adjusted to reflect the Forward Stock Split.

[0001262039-23-000010:notes:5]
Use of Estimates—The preparation of consolidated financial statements in accordance with GAAP requires management to make estimates and assumptions that affect the amounts reported in the consolidated financial statements and accompanying notes. Such management estimates include, but are not limited to, the determination of contingent liabilities, the determination of our ability to exercise control or significant influence over our investee, the evaluation of the equity method investments for OTTI, the standalone selling price for our products and services, the period of benefit for deferred contract costs for commissions, stock-based compensation, inventory valuation, the fair value of tangible and intangible assets acquired and liabilities assumed in business combinations, the measurement of liabilities for uncertain tax positions and deferred tax assets and liabilities, the assessment of recoverability of our goodwill and other long-lived assets, measurement of non-marketable equity securities and the determination of sales returns reserves. We base our estimates on historical experience and also on assumptions that we believe are reasonable. Actual results could differ materially from those estimates.

[0001262039-23-000010:notes:6]
Concentration Risk—Financial instruments that subject us to concentrations of credit risk consist primarily of cash, cash equivalents, short-term and long-term investments, marketable equity securities and accounts receivable. Our cash balances are maintained as deposits with various large financial institutions in the United States and around the world. Balances in the United States typically exceed the amount of insurance provided on such deposits. We maintain our cash equivalents and investments in money market funds, corporate debt securities, U.S. government and agency securities, commercial paper, certificates of deposit and term deposits and municipal bonds with major financial institutions that our management believes are financially sound.

[0001262039-23-000010:notes:7]
Our accounts receivable are derived from our customers in various geographic locations. We perform ongoing credit evaluations of our customers. We generally do not require collateral on accounts receivable, and we maintain reserves for estimated credit losses. See Note 16. Segment Information for distributor customers that accounted for 10% or more of our revenue or net accounts receivable.

[0001262039-23-000010:notes:8]
We rely on a small number of manufacturing partners, primarily in Taiwan, to manufacture our products, and some of the chips and other components of our products used by the contract manufacturers are available from limited or sole sources of supply. Our proprietary Application-Specific Integrated Circuits are built by contract manufacturers located in Japan and Taiwan; other integrated circuits are provided by other chip manufacturers and are currently in short supply.

[0001262039-23-000010:notes:9]
Financial Instruments and Fair Value—We define fair value as the price that would be received from selling an asset, or paid to transfer a liability, in an orderly transaction between market participants at the measurement date. When determining the fair value measurements for assets and liabilities which are required to be recorded at fair value, we consider the principal or most advantageous market in which to transact and the market-based risk. We apply fair value accounting for

[0001262039-23-000010:notes:10]
all financial assets and liabilities and non-financial assets and liabilities that are recognized or disclosed at fair value in the financial statements on a recurring basis. Due to their short-term nature, the carrying amounts reported in the consolidated financial statements approximate the fair value for cash and cash equivalents, accounts receivable, accounts payable, accrued liabilities, and accrued payroll and compensation.

[0001262039-23-000010:notes:11]
Comprehensive Income—Comprehensive income includes certain changes in equity from non-owner sources that are excluded from net income, specifically, cumulative foreign currency translation adjustments, unrealized gains and losses on available-for-sale investments and the related tax impacts.

[0001262039-23-000010:notes:12]
Foreign Currency and Transaction Gains and Losses—The functional currency for most of our foreign subsidiaries is the U.S. dollar. For our international subsidiary whose functional currency is the local currency, we translate the financial statements of this subsidiary to U.S. dollars using the exchange rates in effect at the balance sheet dates for assets and liabilities, and average monthly rates of exchange for revenues, costs, and expenses. We record translation gains and losses in accumulated other comprehensive income as a component of equity (deficit). We reflect net foreign exchange transaction gains and losses resulting from the conversion of the transaction currency to functional currency as a component of foreign currency exchange gain (loss) in other expense, net. We recognized a foreign currency loss of $4.6 million, $8.2 million and $5.5 million in other expense, net, for 2022, 2021, and 2020, respectively.

[0001262039-23-000010:notes:13]
Cash and Cash Equivalents—We consider all highly liquid investments, purchased with original maturities of three months or less, to be cash equivalents. Cash and cash equivalents consist of balances with banks and highly liquid investments in commercial paper, corporate debt, U.S. government and agency securities, term deposits and money market funds.

[0001262039-23-000010:notes:14]
Available-for-Sale Investments—We hold investment grade securities consisting of commercial paper, corporate debt securities, U.S. government and agency securities, certificates of deposit and term deposits, money market funds and municipal bonds that our management believes are financially sound. We classify our investments as available-for-sale (“AFS”) at the time of purchase, since it is our intent that these investments are available for current operations. Investments with original maturities greater than three months with a remaining maturity of less than one year from the consolidated balance sheet date are classified as short-term investments. Investments with remaining maturities greater than one year from the consolidated balance sheet date are classified as long-term investments.

[0001262039-23-000010:notes:15]
Our AFS investments in debt securities are carried at estimated fair value with any unrealized gains and losses, net of taxes, included in accumulated other comprehensive income (loss) in consolidated statements of equity (deficit). AFS debt securities with an amortized cost basis in excess of estimated fair value are assessed to determine what amount of that difference, if any, is caused by expected credit losses. An investment is impaired if the fair value of the investment is less than its cost. If the fair value of an investment is less than its amortized cost basis at the balance sheet date and if we do not intend to sell the investment, we consider available evidence to assess whether it is more likely than not that we will be required to sell the investment before the recovery of its amortized cost basis. We consult with our investment managers and consider available quantitative and qualitative evidence in evaluating, among other factors, general market conditions, the duration and extent to which the fair value is less than cost, and our ability to hold the investment. Once an impairment is determined to be attributable to credit-related factors, allowance for credit losses (i.e., the credit loss component) on AFS debt securities is recognized as credit loss expense, a charge in other expense—net, on our consolidated statements of income, and any remaining unrealized losses (i.e., the non-credit loss component), net of taxes, are included in accumulated other comprehensive income (loss) on our consolidated statements of equity (deficit).

[0001262039-23-000010:notes:16]
We consider whether unrealized losses have resulted from a credit loss or other factors. The unrealized losses on our AFS debt securities as of December 31, 2022, 2021 and 2020 were caused by fluctuations in market value and interest rates as a result of the market conditions. We concluded that an allowance for credit losses was unnecessary as of December 31, 2022, 2021 and 2020 because (i) the decline in market value was attributable to changes in market conditions and not credit quality, and (ii) we concluded that neither do we intend to sell nor is it more likely than not that we will be required to sell these investments prior to recovery of their amortized cost basis. As a result, we had no credit losses recorded for the year ended December 31, 2022, 2021 and 2020.

[0001262039-23-000010:notes:17]
We determine realized gains or losses on sale of AFS debt securities using the specific identification method to determine the cost basis of investments sold and record such gains or losses as other expense—net on the consolidated statements of income. We have elected to not record an allowance for credit losses for accrued interest for AFS investments in debt securities and will reverse the accrued interest against interest income in the period in which we determine the accrued interest to be uncollectible.

[0001262039-23-000010:notes:18]
Marketable Equity Securities—Our marketable equity investments with readily determinable fair values are accounted for at fair value through net income. Realized gains and losses as well as changes in fair value of these securities are recognized and reported in other expense—net, and are determined using the specific identification method.

[0001262039-23-000010:notes:19]
Investments in privately held companies—Our investments in privately held companies consist of investments in common stock or in-substance common stock. One of these investments provide us with the ability to exercise significant influence over the investee, but not an absolute controlling financial interest. The investment is accounted for under the equity method of accounting and was initially recorded at cost. Subsequently, we recognize our proportionate share of the entity’s net loss, the amortization of any basis differences, as well as any OTTI as gain or loss from this equity method investment in the consolidated statements of income and as an adjustment to the investment balance. We record our proportionate share of the results of this equity method investment on a three-month lag basis. We evaluate if there are material transactions or events that occur during the intervening period that materially affect the financial position or results of operations. As of December 31, 2022 and 2021, our investment in Linksys was our only equity method investment and was recorded in other assets. Our remaining investments in privately held companies are recorded at cost and as of December 31, 2022 and 2021 were not material.

[0001262039-23-000010:notes:20]
We evaluate our equity method investment at the end of each reporting period to determine whether events or changes in business circumstances indicate that the carrying value of the investment may not be recoverable. Evidence of a loss in value might include, but would not necessarily be limited to, absence of an ability to recover the carrying amount of the investment or inability of the investee to sustain an earnings capacity that would justify the carrying amount of the investment. This evaluation consists of several qualitative and quantitative factors including recent financial results, projected financial results and operating trends of the investee and other publicly available information that may affect the value of our investment.

[0001262039-23-000010:notes:21]
Accounts receivable—Trade accounts receivable are recorded at the invoiced amount. Our accounts receivable balance is reduced by an allowance for expected credit losses. We measure expected credit losses of accounts receivable on a collective (pooled) basis, aggregating accounts receivable that are either current or no more than 60 days past due, and aggregating accounts receivable that are more than 60 days past due. We apply a credit-loss percentage to each of the pools that is based on our historical credit losses. We review whether each of our significant accounts receivable that is more than 60 days past due continues to exhibit similar risk characteristics with the other accounts receivable in the pool. If we determine that it does not, we evaluate it for expected credit losses on an individual basis.

[0001262039-23-000010:notes:22]
We further consider collectability trends for the allowance for credit losses based on our assessment of various factors, including credit quality of our customers, current economic conditions, reasonable and supportable forecasts of future economic conditions, and other factors that may affect our ability to collect from our customers. Expected credit losses are recorded as general and administrative expenses on our consolidated statements of income. The allowance for credit losses was $3.6 million and $2.4 million as of December 31, 2022 and 2021, respectively. Provisions, write-offs and recoveries were not material during the years ended December 31, 2022, 2021 and 2020.

[0001262039-23-000010:notes:23]
Inventory—Inventory is recorded at the lower of cost or net realizable value. Cost is computed using the first-in, first-out method. In assessing the ultimate recoverability of inventory, we make estimates regarding future customer demand, the timing of new product introductions, economic trends and market conditions. If the actual product demand is significantly lower than forecasted, we could be required to record inventory write-downs which would be charged to cost of product revenue.

[0001262039-23-000010:notes:24]
Property and Equipment—Property and equipment are stated at cost less accumulated depreciation. We do not depreciate the allocated cost of land. Depreciation is computed using the straight-line method over the estimated useful lives of the assets:

[0001262039-23-000010:notes:25]
|  | Estimated Useful Lives |
| Building and building improvements | 2 to 40 years |
| Computer equipment and software | 1 to 7 years |
| Evaluation units | 1 year |
| Furniture and fixtures | 3 to 8 years |
| Leasehold improvements | Shorter of useful life or lease term |

[0001262039-23-000010:notes:26]
Business Combinations—We include the results of operations of the businesses that we acquire as of the respective dates of acquisition. We allocate the fair value of the purchase price of our business acquisitions to the tangible and intangible assets acquired and liabilities assumed, based on their estimated fair values. The excess of the purchase price over the fair values of these identifiable assets and liabilities is recorded as goodwill. Our estimates and assumptions are subject to change and we often continue to gather additional information throughout the measurement period, which is up to 12 months after the acquisition date, and if we make changes to the amounts recorded, such amounts are recorded in the period in which they are identified.

[0001262039-23-000010:notes:27]
Impairment of Long-Lived Assets—We evaluate events and changes in circumstances that could indicate carrying amounts of long-lived assets, including intangible assets, may not be recoverable. When such events or changes in circumstances occur, we assess the recoverability of long-lived assets by determining whether the carrying value of such assets will be recovered through undiscounted expected future cash flows. If the total of the future undiscounted cash flows is less than the carrying amount of those assets, we record an impairment charge in the period in which we make the determination. If such assets are considered to be impaired, the impairment to be recognized is measured by the amount by which the carrying amount of the assets exceeds the fair value of the assets. There were no impairments to long-lived assets in 2022, 2021 and 2020.

[0001262039-23-000010:notes:28]
Goodwill—Goodwill represents the excess of purchase consideration over the estimated fair value of net assets of businesses acquired in a business combination. Goodwill acquired in a business combination is not amortized, but instead tested for impairment at least annually during the fourth quarter, or sooner when circumstances indicate an impairment may exist. We perform a qualitative assessment in the fourth quarter of each year, or more frequently if indicators of potential impairment exist, to determine if any events or circumstances exist, such as an adverse change in business climate or a decline in the overall industry that would indicate that it would more likely than not reduce the fair value of a reporting unit below its carrying amount, including goodwill. Then we perform a quantitative impairment test by comparing the fair value of a reporting unit with its carrying amount. Any excess in the carrying value of a reporting unit over its fair value is recognized as an impairment loss in goodwill, limited to the total amount of goodwill allocated to that reporting unit.

[0001262039-23-000010:notes:29]
We performed our annual goodwill impairment analysis and did not identify any impairment indicators as a result of the review. As of December 31, 2022 and 2021, we had one reporting unit.

[0001262039-23-000010:notes:30]
Other Intangible Assets—Intangible assets with finite lives are carried at cost, less accumulated amortization. Amortization is computed using the straight-line or accelerated method over the estimated economic lives of the assets, which range from one to ten years.

[0001262039-23-000010:notes:31]
Income Taxes—We record income taxes using the asset and liability method, which requires the recognition of deferred tax assets and liabilities for the expected future tax consequences of events that have been recognized in our financial statements or tax returns. In addition, deferred tax assets are recorded for the future benefit of utilizing net operating losses and research and development credit carryforwards. Deferred tax assets and liabilities are measured using the currently enacted tax rates that apply to taxable income in effect for the years in which those tax assets and liabilities are expected to be realized or settled. Valuation allowances are provided when necessary to reduce deferred tax assets to the amount expected to be realized.

[0001262039-23-000010:notes:32]
As part of the process of preparing our consolidated financial statements, we are required to estimate our taxes in each of the jurisdictions in which we operate. We estimate actual current tax exposure together with assessing temporary differences resulting from differing treatment of items, such as accruals and allowances not currently deductible for tax purposes. These differences result in deferred tax assets, which are included in our consolidated balance sheets. In general, deferred tax assets represent future tax benefits to be received when certain expenses previously recognized in our consolidated statements of income become deductible expenses under applicable income tax laws, or loss or credit carryforwards are utilized.

[0001262039-23-000010:notes:33]
In assessing the realizability of deferred tax assets, management considers whether it is more likely than not that some portion or all of the deferred tax assets will be realized. The ultimate realization of deferred tax assets is dependent upon the generation of future taxable income during the periods in which those temporary differences become deductible. We continue to assess the need for a valuation allowance on the deferred tax assets by evaluating both positive and negative evidence that may exist. Any adjustment to the valuation allowance on deferred tax assets would be recorded in the consolidated statements of income for the period that the adjustment is determined to be required.

[0001262039-23-000010:notes:34]
We recognize tax benefits from an uncertain tax position only if it is more likely than not, based on the technical merits of the position, that the tax position will be sustained on examination by the tax authorities. The tax benefits recognized in the financial statements from such positions are then measured based on the largest benefit that has a greater than 50% likelihood of being realized upon ultimate settlement.

[0001262039-23-000010:notes:35]
Stock-Based Compensation—The fair value of restricted stock units (“RSUs”) is based on the closing market price of our common stock on the date of grant. We have elected to use the Black-Scholes-Merton (“Black-Scholes”) pricing model to determine the fair value of our employee stock options and our equity incentive plans. Stock-based compensation expense is amortized on a straight-line basis over the service period. We account for forfeitures of all stock-based payment awards when they occur.

[0001262039-23-000010:notes:36]
Leases—We determine if an arrangement is a lease at inception. We evaluate the classification of leases at commencement and, as necessary, at modification. The right-of-use (“ROU”) assets and the short and long-term lease liabilities from our operating leases are included in other assets, accrued liabilities and other liabilities in our consolidated balance sheets, respectively. The corresponding assets and, the short- and long-term lease liabilities from our finance leases are included in property and equipment, accrued liabilities and other liabilities in our consolidated balance sheets, respectively.

[0001262039-23-000010:notes:37]
The ROU assets represent our right to use an underlying asset for the lease term. Lease liabilities represent our obligation to make lease payments under the lease. Operating lease ROU assets and liabilities are recognized at the lease commencement date based on the present value of lease payments over the lease term. The implicit rate within our operating leases is generally not determinable and therefore we use our incremental borrowing rate at the lease commencement date to determine the present value of lease payments. The determination of our incremental borrowing rate requires judgment. We determine our incremental borrowing rate for each lease using indicative bank borrowing rates, adjusted for various factors including level of collateralization, term and currency to align with the terms of a lease. The operating lease ROU asset also includes any lease prepayments and initial direct costs, net of lease incentives. Certain leases include options to extend or terminate the lease. An option to extend the lease is considered in connection with determining the ROU asset and lease liability when it is reasonably certain we will exercise that option. An option to terminate is considered unless it is reasonably certain we will not exercise the option.

[0001262039-23-000010:notes:38]
We do not recognize lease liabilities or ROU assets for short-term leases (leases that, at the commencement date, have a lease term of 12 months or less and do not include an option to purchase the underlying asset that we are reasonably certain to exercise). We do not allocate the contract consideration for operating lease contracts with lease and non-lease components, and account for the lease and non-lease components as a single lease component.

[0001262039-23-000010:notes:39]
Payments under our lease arrangements are primarily fixed; however, certain lease agreements contain variable payments, which are expensed as incurred and not included in the operating lease ROU assets and liabilities. Variable lease payments primarily include common area maintenance charges, real estate taxes, certain parking expense and insurance costs. Lease expense for lease payments for our operating leases is recognized on a straight-line basis over the term of the lease. We begin recognizing rent expense on the date that a lessor makes an underlying asset that is subject to the lease available for our use. For our finance leases, we recognize amortization expense from the amortization of the corresponding assets and interest expense on the related lease liabilities.

[0001262039-23-000010:notes:40]
Advertising Expense—Advertising costs are expensed when incurred and are included in operating expenses in the accompanying consolidated statements of income. Our advertising expenses were not material for any periods presented.

[0001262039-23-000010:notes:41]
Research and Development Costs—Research and development costs are expensed as incurred.

[0001262039-23-000010:notes:42]
Software Development Costs—The costs to develop software that is marketed have not been capitalized as we believe our current software development process is essentially completed concurrently with the establishment of technological feasibility. Such costs are expensed as incurred and included in research and development in our consolidated statements of income.

[0001262039-23-000010:notes:43]
The costs to develop software for internal use are capitalized based on qualifying criteria. These costs consist of internal compensation related costs and external direct costs incurred during the application development stage. Such costs are amortized over the software’s estimated useful life.

[0001262039-23-000010:notes:44]
Deferred Contract Costs and Commission Expense—Sales commissions earned by our sales force are considered incremental and recoverable costs of obtaining a contract with a customer. We recognize sales commissions expenses related to product sales upfront while sales commissions expenses for service contracts are deferred as deferred contract costs in the consolidated balance sheets and amortized over the applicable amortization period. Commission costs for initial contracts that are not commensurate with commissions on renewal contracts are amortized on a straight-line basis over the period of benefit, which we have determined to be five years and which is typically longer than the initial contract term. The amortization of deferred contract costs is included in sales and marketing expense in our consolidated statements of income. Amortization of deferred contract costs during 2022, 2021 and 2020 was $223.3 million, $175.9 million and $137.4 million, respectively. No impairment loss was recognized during 2022, 2021 and 2020.

[0001262039-23-000010:notes:45]
Deferred Revenue—Deferred revenue consists of amounts that have been invoiced but that have not yet been recognized as revenue. Deferred revenue that will be recognized during the succeeding 12-month period is recorded as current deferred revenue and the remaining portion is recorded as non-current deferred revenue. The majority of deferred revenue is comprised of security subscription and technical support services which are invoiced upfront and delivered over 12 months or longer.

[0001262039-23-000010:notes:46]
Revenue Recognition—Our revenue consists of product and service revenue. Revenues are recognized when control of these goods or services is transferred to our customers, in an amount that reflects the consideration we expect to be entitled to in exchange for those goods or services. We determine revenue recognition through the following steps:

[0001262039-23-000010:notes:47]
•identification of a contract or contracts with a customer;

[0001262039-23-000010:notes:48]
•identification of the performance obligations in a contract, including evaluation of performance obligations and evaluating the distinct goods or services in a contract;

[0001262039-23-000010:notes:49]
•determination of a transaction price;

[0001262039-23-000010:notes:50]
•allocation of a transaction price to the performance obligations in a contract; and

[0001262039-23-000010:notes:51]
•recognition of revenue when, or as, we satisfy a performance obligation.

[0001262039-23-000010:notes:52]
We derive a majority of product sales from our Core Platform (previously referred to as FortiGate) hardware and virtual machine products which include a broad set of built-in security and networking features and functionalities, including firewall, next-generation firewall, secure web gateway, secure sockets layer (“SSL”) inspection, software-defined wide-area network, intrusion prevention, SSL data leak prevention, virtual private network, switch and wireless controller and wide area network edge.

[0001262039-23-000010:notes:53]
We recognize product revenue upon shipment when control of the promised goods is transferred to the customer. Our term software licenses represent multiple performance obligations, which include software licenses and software support services where the term licenses are recognized upfront upon transfer of control, with the associated software support services recognized ratably over the service term as services and software updates are provided.

[0001262039-23-000010:notes:54]
Service revenue relates to sales of our FortiGuard security subscription, FortiCare technical support services and other services. Our typical subscription and support term is one to five years. We generally recognize revenue from these services ratably over the service term because of continuous transfer of control to the customer. We also generate a small portion of our revenue from other services consisting of professional services, training and software-as-a-service (“SaaS”) which is either hosted by us or provided through cloud-providers. We recognize revenue from professional and training services as the services are provided. We recognize revenue from SaaS as the subscription service is delivered over the term, which is typically one year, or on a monthly usage basis. To date, SaaS revenue has not represented a significant percentage of our total revenue.

[0001262039-23-000010:notes:55]
Our sales contracts typically contain multiple deliverables, such as hardware, software license, security subscription, technical support services and other services, which are generally capable of being distinct and accounted for as separate performance obligations. Our hardware and software licenses have significant standalone functionalities and capabilities. Accordingly, the hardware and software licenses are distinct from the security subscription and technical support services, as a customer can benefit from the product without the services and the services are separately identifiable within a contract. We allocate a transaction price to each performance obligation based on relative standalone selling price. We establish standalone selling price using the prices charged for a deliverable when sold separately. If not observable through past transactions, we determine standalone selling price by considering multiple historical factors including, but not limited to, cost of products, gross margin objectives, pricing practices, geographies and the term of a service contract. Revenue is reported net of sales tax.

[0001262039-23-000010:notes:56]
In certain circumstances, our contracts include provisions for sales rebates and other customer incentive programs. Additionally, in limited circumstances, we may permit end-customers, distributors and resellers to return our products, subject

[0001262039-23-000010:notes:57]
to varying limitations, for a refund within a reasonably short period from the date of purchase. These amounts are accounted for as variable consideration that can decrease the transaction price. We estimate variable consideration using the expected-value method based on the most likely amounts to which we expect our customers to be entitled. We include estimated amounts in the transaction price to the extent that it is probable that a significant reversal of cumulative revenue recognized will not occur when the uncertainty associated with the variable consideration is resolved. Our estimate for refund liabilities, which include sales returns reserve and customer rebates, was $92.0 million and $49.2 million as of December 31, 2022 and 2021, respectively, and is included in current liabilities in our consolidated balance sheet.

[0001262039-23-000010:notes:58]
We generally invoice at the time of our sale for the total price of the hardware, software licenses, security subscription and technical support and other services. Standard payment terms are generally no more than 60 days, though we continue to offer extended payment terms to certain distributors. We also invoice certain services on a monthly basis. Amounts billed and due from our customers are classified as receivables on the balance sheet and do not bear interest. Our deferred revenue primarily consists of amounts that have been invoiced but have not been recognized as revenue as of period end.

[0001262039-23-000010:notes:59]
Shipping and handling fees charged to our customers are recognized as revenue in the period shipped and the related costs for providing these services are recorded in cost of revenue. Shipping and handling fees recognized were not material during 2022, 2021 and 2020.

[0001262039-23-000010:notes:60]
Warranties—We generally provide a one-year warranty for most hardware products and a 90-day warranty for software. We also provide extended warranties under the terms of our support agreements. A provision for estimated future costs related to warranty activities in the first year after product sale is recorded as a component of cost of product revenues when the product revenue is recognized, based upon historical product failure rates and historical costs incurred in correcting product failures. Warranty costs related to extended warranties sold under support agreements are recognized as cost of service revenue as incurred. In the event we change our warranty reserve estimates, the resulting charge against future cost of revenue or reversal of previously recorded charges may materially affect our gross margins and operating results. Accrued warranty liability was not material as of December 31, 2022 and 2021.

[0001262039-23-000010:notes:61]
Contingent Liabilities—From time to time, we are involved in disputes, litigation, and other legal actions. There are many uncertainties associated with any disputes, litigation and other legal actions, and these actions or other third-party claims against us may cause us to incur costly litigation fees, costs and substantial settlement charges, and possibly subject us to damages and other penalties, which are inherently difficult to estimate and could adversely affect our results of operations. In addition, the resolution of any IP litigation may require us to make royalty payments, which could adversely affect our gross margins in future periods. We periodically review significant claims and litigation matters for the probability of an adverse outcome. Estimates can change as individual claims develop. The actual liability in any such matters may be materially different from our estimates, which could result in the need to adjust our liability and record additional expenses, which may be material.

[0001262039-23-000010:notes:62]
Recently Adopted and Recently Issued Accounting Standards

[0001262039-23-000010:notes:63]
There were no recently adopted accounting standards which would have a material effect on our consolidated financial statements and accompanying disclosures, and no recently issued accounting standards that are expected to have a material impact on our consolidated financial statements and accompanying disclosures.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001262039-23-000010:notes:64]
REVENUE RECOGNITION
Disaggregation of Revenue

[0001262039-23-000010:notes:65]
The following table presents our revenue disaggregated by major product and service lines (in millions):

[0001262039-23-000010:notes:66]
|  | Year Ended December 31, |
|  | 2022 |  | 2021 |  | 2020 |
| Product | $ | 1,780.5 |  |  | $ | 1,255.0 |  |  | $ | 916.4 |  |
| Service: |  |  |  |  |  |
| Security subscription | 1,427.0 |  |  | 1,125.0 |  |  | 918.7 |  |
| Technical support and other | 1,209.9 |  |  | 962.2 |  |  | 759.3 |  |
| Total service revenue | 2,636.9 |  |  | 2,087.2 |  |  | 1,678.0 |  |
| Total revenue | $ | 4,417.4 |  |  | $ | 3,342.2 |  |  | $ | 2,594.4 |  |

[0001262039-23-000010:notes:67]
Deferred Revenue

[0001262039-23-000010:notes:68]
Our deferred revenue consists of amounts that have been invoiced but have not been recognized as revenue as of period end. During 2022 and 2021, we recognized $1.73 billion and $1.37 billion in revenue that was included in the deferred revenue balance as of December 31, 2021 and 2020, respectively.

[0001262039-23-000010:notes:69]
Transaction Price Allocated to the Remaining Performance Obligations

[0001262039-23-000010:notes:70]
As of December 31, 2022, the aggregate amount of the transaction price allocated to remaining performance obligations was $4.65 billion, which was substantially comprised of deferred security subscription and technical support services revenue as well as unbilled contract revenue from non-cancellable contracts that will be recognized in future periods. We expect to recognize approximately $2.36 billion as revenue over the next 12 months and the remainder thereafter.


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0001262039-23-000010:notes:71]
FINANCIAL INSTRUMENTS AND FAIR VALUE
Available-for-Sale Securities

[0001262039-23-000010:notes:72]
The following tables summarize our available-for-sale securities (in millions):

[0001262039-23-000010:notes:73]
|  | December 31, 2022 |
|  | AmortizedCost |  | UnrealizedGains |  | UnrealizedLosses |  | FairValue |
| Corporate debt securities | $ | 293.0 |  |  | $ | — |  |  | $ | (4.1) |  |  | $ | 288.9 |  |
| U.S. government and agency securities | 198.0 |  |  | — |  |  | (4.4) |  |  | 193.6 |  |
| Certificates of deposit and term deposits | 34.2 |  |  | — |  |  | — |  |  | 34.2 |  |
| Commercial paper | 26.5 |  |  | — |  |  | (0.1) |  |  | 26.4 |  |
| Municipal Bonds | 5.1 |  |  | — |  |  | (0.1) |  |  | 5.0 |  |
| Total available-for-sale securities | $ | 556.8 |  |  | $ | — |  |  | $ | (8.7) |  |  | $ | 548.1 |  |
|  | December 31, 2021 |
|  | AmortizedCost |  | UnrealizedGains |  | UnrealizedLosses |  | FairValue |
| Corporate debt securities | $ | 540.7 |  |  | $ | — |  |  | $ | (1.2) |  |  | $ | 539.5 |  |
| U.S. government and agency securities | 356.1 |  |  | — |  |  | (1.0) |  |  | 355.1 |  |
| Certificates of deposit and term deposits | 169.1 |  |  | — |  |  | (0.1) |  |  | 169.0 |  |
| Commercial paper | 566.0 |  |  | — |  |  | (0.2) |  |  | 565.8 |  |
| Municipal Bonds | 5.4 |  |  | — |  |  | — |  |  | 5.4 |  |
| Total available-for-sale securities | $ | 1,637.3 |  |  | $ | — |  |  | $ | (2.5) |  |  | $ | 1,634.8 |  |

[0001262039-23-000010:notes:74]
The following tables show the gross unrealized losses and the related fair values of our available-for-sale securities that have been in a continuous unrealized loss position (in millions):

[0001262039-23-000010:notes:75]
|  | December 31, 2022 |
|  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
|  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |
| Corporate debt securities | $ | 90.5 |  |  | $ | (0.8) |  |  | $ | 190.0 |  |  | $ | (3.3) |  |  | $ | 280.5 |  |  | $ | (4.1) |  |
| U.S. government and agency securities | 3.9 |  |  | (0.1) |  |  | 189.8 |  |  | (4.3) |  |  | 193.7 |  |  | (4.4) |  |
| Commercial paper | 26.4 |  |  | (0.1) |  |  | — |  |  | — |  |  | 26.4 |  |  | (0.1) |  |
| Municipal Bonds | 5.0 |  |  | (0.1) |  |  | — |  |  | — |  |  | 5.0 |  |  | (0.1) |  |
| Total available-for-sale securities | $ | 125.8 |  |  | $ | (1.1) |  |  | $ | 379.8 |  |  | $ | (7.6) |  |  | $ | 505.6 |  |  | $ | (8.7) |  |

[0001262039-23-000010:notes:76]
|  | December 31, 2021 |
|  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
|  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |
| Corporate debt securities | $ | 494.4 |  |  | $ | (1.2) |  |  | $ | — |  |  | $ | — |  |  | $ | 494.4 |  |  | $ | (1.2) |  |
| U.S. government and agency securities | 334.2 |  |  | (1.0) |  |  | — |  |  | — |  |  | 334.2 |  |  | (1.0) |  |
| Certificates of deposit and term deposits | 93.1 |  |  | (0.1) |  |  | — |  |  | — |  |  | 93.1 |  |  | (0.1) |  |
| Commercial paper | 288.0 |  |  | (0.2) |  |  | — |  |  | — |  |  | 288.0 |  |  | (0.2) |  |
| Municipal Bonds | 5.3 |  |  | — |  |  | — |  |  | — |  |  | 5.3 |  |  | — |  |
| Total available-for-sale securities | $ | 1,215.0 |  |  | $ | (2.5) |  |  | $ | — |  |  | $ | — |  |  | $ | 1,215.0 |  |  | $ | (2.5) |  |

[0001262039-23-000010:notes:77]
The contractual maturities of our investments were (in millions):

[0001262039-23-000010:notes:78]
|  | December 31,2022 |  | December 31,2021 |
| Due within one year | $ | 502.6 |  |  | $ | 1,194.0 |  |
| Due within one to three years | 45.5 |  |  | 440.8 |  |
| Total | $ | 548.1 |  |  | $ | 1,634.8 |  |

[0001262039-23-000010:notes:79]
Available-for-sale securities are reported at fair value, with unrealized gains and losses and the related tax impact included as a separate component of equity (deficit) and in comprehensive income. We do not intend to sell any of the securities in an unrealized loss position and it is not more likely than not that we would be required to sell these securities before recovery of their amortized cost basis, which may be at maturity.

[0001262039-23-000010:notes:80]
Realized gains and losses on available-for-sale securities were insignificant in the periods presented.

[0001262039-23-000010:notes:81]
Marketable Equity Securities

[0001262039-23-000010:notes:82]
Our marketable equity securities were $25.5 million and $38.6 million as of December 31, 2022 and December 31, 2021, respectively. The changes in fair value of our marketable equity securities are recorded in other expense, net on the consolidated statements of income. We recognized $13.1 million and $5.1 million of losses in 2022 and 2021, respectively.

[0001262039-23-000010:notes:83]
Fair Value of Financial Instruments

[0001262039-23-000010:notes:84]
Fair Value Accounting—We apply the following fair value hierarchy for disclosure of the inputs used to measure fair value. This hierarchy prioritizes the inputs into three broad levels:

[0001262039-23-000010:notes:85]
Level 1—Inputs are unadjusted quoted prices in active markets for identical assets or liabilities.

[0001262039-23-000010:notes:86]
Level 2—Inputs are quoted prices for similar assets and liabilities in active markets or inputs that are observable for the assets or liabilities, either directly or indirectly through market corroboration, for substantially the full term of the financial instruments.

[0001262039-23-000010:notes:87]
Level 3—Unobservable inputs based on our own assumptions used to measure assets and liabilities at fair value. The inputs require significant management judgment or estimation.

[0001262039-23-000010:notes:88]
We measure the fair value of money market funds, certain U.S. government and agency securities and marketable equity securities using quoted prices in active markets for identical assets. The fair value of all other financial instruments was based on quoted prices for similar assets in active markets, or model-driven valuations using significant inputs derived from or corroborated by observable market data.

[0001262039-23-000010:notes:89]
We classify investments within Level 1 if quoted prices are available in active markets for identical securities.

[0001262039-23-000010:notes:90]
We classify items within Level 2 if the investments are valued using model-driven valuations using observable inputs such as quoted market prices, benchmark yields, reported trades, broker/dealer quotes or alternative pricing sources with

[0001262039-23-000010:notes:91]
reasonable levels of price transparency. Investments are held by custodians who obtain investment prices from a third-party pricing provider that incorporates standard inputs in various asset price models.

[0001262039-23-000010:notes:92]
Assets Measured at Fair Value on a Recurring Basis

[0001262039-23-000010:notes:93]
The following tables present the fair value of our financial assets measured at fair value on a recurring basis (in millions):

[0001262039-23-000010:notes:94]
|  | December 31, 2022 |  | December 31, 2021 |
|  | AggregateFairValue |  | QuotedPrices inActiveMarkets ForIdenticalAssets |  | SignificantOtherObservableRemainingInputs |  | SignificantOtherUnobservableRemainingInputs |  | AggregateFairValue |  | QuotedPrices inActiveMarkets ForIdenticalAssets |  | SignificantOtherObservableRemainingInputs |  | SignificantOtherUnobservableRemainingInputs |
|  |  |  | (Level 1) |  | (Level 2) |  | (Level 3) |  |  |  | (Level 1) |  | (Level 2) |  | (Level 3) |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate debt securities | $ | 288.9 |  |  | $ | — |  |  | $ | 288.9 |  |  | $ | — |  |  | $ | 542.5 |  |  | $ | — |  |  | $ | 542.5 |  |  | $ | — |  |
| U.S. government and agency securities | 268.6 |  |  | 259.3 |  |  | 9.3 |  |  | — |  |  | 355.1 |  |  | 345.2 |  |  | 9.9 |  |  | — |  |
| Certificates of deposit and term deposits | 50.4 |  |  | — |  |  | 50.4 |  |  | — |  |  | 259.0 |  |  | — |  |  | 259.0 |  |  | — |  |
| Commercial paper | 115.8 |  |  | — |  |  | 115.8 |  |  | — |  |  | 580.3 |  |  | — |  |  | 580.3 |  |  | — |  |
| Money market funds | 593.9 |  |  | 593.9 |  |  | — |  |  | — |  |  | 57.5 |  |  | 57.5 |  |  | — |  |  | — |  |
| Municipal bonds | 5.0 |  |  | — |  |  | 5.0 |  |  | — |  |  | 5.4 |  |  | — |  |  | 5.4 |  |  | — |  |
| Marketable equity securities | 25.5 |  |  | 25.5 |  |  | — |  |  | — |  |  | 38.6 |  |  | 38.6 |  |  | — |  |  | — |  |
| Total | $ | 1,348.1 |  |  | $ | 878.7 |  |  | $ | 469.4 |  |  | $ | — |  |  | $ | 1,838.4 |  |  | $ | 441.3 |  |  | $ | 1,397.1 |  |  | $ | — |  |
| Reported as: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents | $ | 774.5 |  |  |  |  |  |  |  |  | $ | 165.0 |  |  |  |  |  |  |  |
| Marketable equity securities | 25.5 |  |  |  |  |  |  |  |  | 38.6 |  |  |  |  |  |  |  |
| Short-term investments | 502.6 |  |  |  |  |  |  |  |  | 1,194.0 |  |  |  |  |  |  |  |
| Long-term investments | 45.5 |  |  |  |  |  |  |  |  | 440.8 |  |  |  |  |  |  |  |
| Total | $ | 1,348.1 |  |  |  |  |  |  |  |  | $ | 1,838.4 |  |  |  |  |  |  |  |

[0001262039-23-000010:notes:95]
There were no transfers between Level 1 and Level 2 of the fair value hierarchy during the years ended December 31, 2022 and December 31, 2021.


## us-gaap:InventoryDisclosureTextBlock

[0001262039-23-000010:notes:96]
INVENTORY
Inventory consisted of (in millions):

[0001262039-23-000010:notes:97]
|  | December 31,2022 |  | December 31,2021 |
| Raw materials | $ | 46.3 |  |  | $ | 40.2 |  |
| Work in process | 12.0 |  |  | 9.8 |  |
| Finished goods | 206.3 |  |  | 125.8 |  |
| Inventory | $ | 264.6 |  |  | $ | 175.8 |  |


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001262039-23-000010:notes:98]
PROPERTY AND EQUIPMENT—Net
Property and equipment—net consisted of (in millions):

[0001262039-23-000010:notes:99]
|  | December 31,2022 |  | December 31,2021 |
| Land | $ | 310.0 |  |  | $ | 204.5 |  |
| Buildings and improvements | 490.3 |  |  | 416.2 |  |
| Computer equipment and software | 222.7 |  |  | 176.1 |  |
| Leasehold improvements | 53.5 |  |  | 40.1 |  |
| Evaluation units | 19.2 |  |  | 15.6 |  |
| Furniture and fixtures | 31.3 |  |  | 26.9 |  |
| Construction-in-progress | 51.7 |  |  | 19.9 |  |
| Total property and equipment | 1,178.7 |  |  | 899.3 |  |
| Less: accumulated depreciation | (280.2) |  |  | (211.7) |  |
| Property and equipment—net | $ | 898.5 |  |  | $ | 687.6 |  |

[0001262039-23-000010:notes:100]
We completed construction of a second building at our headquarters campus and it was placed in service on June 30, 2021. In conjunction with the completion of the building, we evaluated the range of useful lives of our property and equipment. The range of useful lives for buildings and improvements is now two to forty years, an increase from two to thirty years, and for furniture and fixtures the range is now three to eight years, an increase from three to five years.

[0001262039-23-000010:notes:101]
During 2022, we purchased certain real estate in the United States and Canada totaling $174.0 million. The purchases were accounted for under the asset acquisition method. The cost of the assets acquired was allocated to land, buildings, and furniture and fixtures based on their relative fair values. The amounts allocated to land, buildings, and furniture and fixtures were $105.5 million, $67.7 million, and $0.8 million, respectively.

[0001262039-23-000010:notes:102]
Depreciation expense was $81.0 million, $65.9 million and $55.5 million in 2022, 2021 and 2020, respectively.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001262039-23-000010:notes:103]
INVESTMENTS IN PRIVATELY HELD COMPANIES
Linksys Holdings, Inc.

[0001262039-23-000010:notes:104]
On March 19, 2021, we invested $75.0 million in cash for shares of the Series A Preferred Stock of Linksys for a 32.6% ownership interest in this privately held company. On September 24, 2021, we invested an additional $85.0 million in cash for shares of Series A Preferred Stock of Linksys, and as of December 31, 2022 and December 31, 2021, we held 50.8% of the outstanding common stock (on an as-converted basis) of Linksys. Linksys provides router connectivity solutions to the consumer and small business markets.

[0001262039-23-000010:notes:105]
We have concluded that our investment in Linksys is an in-substance common stock investment and that we do not hold an absolute controlling financial interest in Linksys, but that we have the ability to exercise significant influence over the operating and financial policies of Linksys. Determining that we have significant influence but not control over the operating and financial policies of Linksys required significant judgement of many factors, including but not limited to the ownership interest in Linksys, board representation, participation in policy-making processes and participation rights in certain significant financial and operating decisions of Linksys in the ordinary course of business. Therefore, we determined to account for this investment using the equity method of accounting. We record our share of Linksys’ financial results on a three-month lag basis, with the exception of material transactions or events that occur during the intervening period that materially affect the financial position or results of operations. We determined that there was a basis difference between the cost of our investment in Linksys and the amount of underlying equity in net assets of Linksys.

[0001262039-23-000010:notes:106]
Due to the presence of impairment indicators, such as a series of operating losses, current expected performance relative to expected performance when we initially invested, performance relative to peers, and the results of a discounted cash flows analysis, we evaluated our equity method investment for an OTTI during 2022. We considered various factors in determining whether an OTTI has occurred, including Linksys financial results and operating history, our ability and intent to hold the investment until its fair value recovers, the implied revenue valuation multiples compared to guideline public companies, Linksys’ ability to achieve milestones and any notable operational and strategic changes. After the evaluation, we noted that certain factors were present that indicate that the equity method investment’s decline in value is other-than-

[0001262039-23-000010:notes:107]
temporary, primarily driven by Linksys’ continuous losses, decrease in revenue and operating results, current forecasted results for the foreseeable future as compared to the expected performance at the time of the investments, and the results of a discounted cash flows analysis. To determine the fair value of our investment in Linksys, we utilized a market approach referencing revenue multiples from publicly traded peer companies and concluded that the estimated fair value of the investment was lower than its carrying value. During the three months ended December 31, 2022, we recorded a non-cash charge of $22.2 million related to impairment recognized on our equity method investment in Linksys.

[0001262039-23-000010:notes:108]
Our loss related to Linksys in fiscal 2022 totaled $68.1 million, which comprised of our proportionate share of Linksys’ financial results as well as the amortization of the basis differences of $45.9 million, which included a $17.5 million charge in connection with a valuation allowance established on deferred tax assets at Linksys, and the OTTI charge of $22.2 million recorded during the three months ended December 31,2022. This amount has been recorded in loss from equity method investment on the consolidated statements of income. Our share of loss of Linksys’ financial results as well as our share of the amortization of the basis differences in total was $7.6 million in 2021, recorded in the same financial statement line item.

[0001262039-23-000010:notes:109]
As of December 31, 2022 and 2021, our investment in Linksys was our only equity method investment and was recorded in other assets on our consolidated balance sheets.

[0001262039-23-000010:notes:110]
Other investments

[0001262039-23-000010:notes:111]
Our investments in the equity securities of privately held companies without readily determinable fair values totaled $1.0 million as of December 31, 2022 and 2021.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001262039-23-000010:notes:112]
BUSINESS COMBINATIONS
2022 Acquisitions

[0001262039-23-000010:notes:113]
Network Detection and Response Business

[0001262039-23-000010:notes:114]
On December 22, 2022, we closed an acquisition of certain assets and liabilities of a business specializing in network detection and response for $18.0 million in cash. This acquisition was accounted for as a business combination using the acquisition method of accounting. Of the purchase price, $5.8 million was allocated to goodwill, $10.5 million was allocated to developed technology intangible asset, $10.0 million was allocated to customer relationships intangible asset and $8.3 million was allocated to other net liabilities assumed, which predominantly include deferred revenue. Goodwill recorded in connection with this acquisition is primarily attributable to the assembled workforce acquired and the anticipated operational synergies. All acquired goodwill is expected to be deductible for tax purposes. Acquisition-related costs related to this acquisition were not material and were recorded as general and administrative expense.

[0001262039-23-000010:notes:115]
Alaxala Networks Corporation

[0001262039-23-000010:notes:116]
On October 3, 2022, we acquired the remaining 25% of equity interests in Alaxala for $13.5 million in cash, and Alaxala became our wholly owned subsidiary.

[0001262039-23-000010:notes:117]
2021 Acquisitions

[0001262039-23-000010:notes:118]
On August 31, 2021, we closed an acquisition of 75% of equity interests as controlling interests in Alaxala, a privately held network hardware equipment company in Japan, for $64.2 million in cash. We acquired the equity interests in Alaxala to broaden our offering of secure switches integrated with our Core Platform and Enhanced Platform Technology (previously referred to as Platform Extension) functionality, and, over time, to innovate and rebrand certain of Alaxala’s switches to offer a broader suite of secure switches globally.

[0001262039-23-000010:notes:119]
Under the acquisition method of accounting in accordance with ASC 805, the total purchase price was allocated to Alaxala’s identifiable tangible and intangible assets acquired and liabilities assumed based on their estimated fair values using management’s best estimates and assumptions to assign fair value as of the acquisition date. The following table provides the assets acquired and liabilities assumed as of the date of acquisition:

[0001262039-23-000010:notes:120]
| (in millions) | Estimated Fair Value |
| ASSETS |  |
| Cash | $ | 1.1 |  |
| Accounts receivable—net | 15.6 |  |
| Inventory | 33.4 |  |
| Prepaid expenses and other current assets | 2.9 |  |
| Property and equipment | 5.3 |  |
| Goodwill | 25.5 |  |
| Other intangible assets | 48.0 |  |
| Other long-term assets | 5.2 |  |
| TOTAL ASSETS | $ | 137.0 |  |
| LIABILITIES |  |
| Accounts payable | $ | 11.0 |  |
| Current portion of long-term debt | 20.2 |  |
| Accrued and other current liabilities | 17.1 |  |
| Other long-term liabilities | 6.7 |  |
| TOTAL LIABILITIES | $ | 55.0 |  |
| NON-CONTROLLING INTERESTS | $ | 17.8 |  |
| Net purchase consideration | $ | 64.2 |  |

[0001262039-23-000010:notes:121]
The excess of the purchase consideration and the fair value of non-controlling interests over the fair value of net tangible and identified intangible assets acquired was recorded as goodwill, which is not deductible for tax purposes. Goodwill is primarily attributable to the assembled workforce of Alaxala and the anticipated operational synergies.

[0001262039-23-000010:notes:122]
The fair value of the non-controlling interests of $17.8 million was estimated based on the non-controlling interests’ respective share of the fair value of Alaxala.

[0001262039-23-000010:notes:123]
Identified intangible assets acquired and their estimated useful lives as of August 31, 2021, were (in millions, except years):

[0001262039-23-000010:notes:124]
|  | Fair Value |  | Estimated Useful Life (in years) |
| Developed technology | $ | 26.6 |  |  | 4 |
| Customer relationships | 10.0 |  |  | 10 |
| Trade name | 6.4 |  |  | 10 |
| Backlog | 5.0 |  |  | 1 |
| Total identified intangible assets: | $ | 48.0 |  |  |  |

[0001262039-23-000010:notes:125]
Developed technology relates to Alaxala’s network equipment. We valued the developed technology using the relief-from-royalty method under the income approach. This method reflects the present value of the projected cost savings that are expected to be realized by avoiding the royalty that otherwise would be granted in exchange for the use of the asset. The economic useful life was determined based on the technology cycle related to each developed technology, as well as the cash flows over the forecast period.

[0001262039-23-000010:notes:126]
Customer relationships represent the fair value of future projected revenue that will be derived from sales to existing customers of Alaxala. Customer contracts and related relationships were valued using the multi-period excess earnings method. This method reflects the present value of the projected cash flows that are expected to be generated by the customer contracts and relationships less charges representing the contribution of other assets to those cash flows. The economic useful life was determined based on historical customer turnover rates.

[0001262039-23-000010:notes:127]
Trade name relates to the “Alaxala” trade name. The fair value was determined by applying the relief-from-royalty method under the income approach. This method is based on the application of a royalty rate to forecasted revenue under the trade name. The economic useful life was determined based on the expected life of the trade name and the cash flows anticipated over the forecast period.

[0001262039-23-000010:notes:128]
Customer backlog relates to the unfulfilled customer contract orders. Backlog was valued using the multi-period excess earnings method. This method reflects the present value of the projected cash flows that are expected to be generated by the execution of the unfulfilled customer contract orders less charges representing the contribution of other assets to those cash flows. The economic useful life was determined based on the anticipated contract orders’ execution timeframe.

[0001262039-23-000010:notes:129]
In connection with our acquisition of Alaxala, we assumed certain current debt liabilities of $20.2 million as of August 31, 2021. We concluded that the fair value of this debt approximated its book value as of the acquisition date. We repaid this debt in full in September and October 2021. During the post-acquisition period from September 1, 2021 through the repayment dates, interest expense related to Alaxala debt was not material.

[0001262039-23-000010:notes:130]
The following unaudited pro forma financial information presents the combined results of operations of Fortinet, Inc. and Alaxala, as if Alaxala had been acquired as of the beginning of business on January 1, 2020. The unaudited pro forma financial information is presented for informational purposes only and is not necessarily indicative of our consolidated results of operations of the combined business that would have been achieved if the acquisition had taken place at the beginning of business on January 1, 2020, or of the results of our future operations of the combined business. The following unaudited pro forma financial information for all periods presented includes purchase accounting adjustments for amortization of acquired intangible assets, depreciation of acquired property and equipment, the purchase accounting effect on inventory acquired and related tax effects (in millions):

[0001262039-23-000010:notes:131]
|  | Year Ended December 31, |
|  | 2021 |  | 2020 |  |  |
| Pro forma revenue | $ | 3,424.3 |  |  | $ | 2,714.7 |  |  |  |
| Pro forma net income attributable to Fortinet, Inc. | $ | 608.2 |  |  | $ | 480.0 |  |  |  |

[0001262039-23-000010:notes:132]
2020 Acquisitions

[0001262039-23-000010:notes:133]
Panopta Holdings LLC

[0001262039-23-000010:notes:134]
On December 9, 2020, we acquired all outstanding shares of Panopta Holdings LLC (“Panopta”), a privately held SaaS platform innovator that provides visibility, automated management and alerting, and remediation for enterprise networks and infrastructure. The purchase price for Panopta was $31.9 million in cash, of which $24.8 million was allocated to goodwill and $9.0 million was allocated to identifiable intangible assets, the majority of which was developed technology, offset by $1.9 million of net liabilities assumed, which predominantly included cash and accounts payable. $15.8 million of goodwill is expected to be deductible for tax purposes.

[0001262039-23-000010:notes:135]
Additional Acquisition-Related Information

[0001262039-23-000010:notes:136]
The operating results of the acquired companies are included in our consolidated statements of income from the respective dates of acquisition. Acquisition-related costs related to each acquisition were not material. Pro forma information has not been presented, except for Alaxala as disclosed above, as the impact of these acquisitions, individually and in the aggregate, in each year were not material to our consolidated financial statements.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001262039-23-000010:notes:137]
GOODWILL AND OTHER INTANGIBLE ASSETS—Net
Goodwill

[0001262039-23-000010:notes:138]
The following table presents the changes in the carrying amount of goodwill (in millions):

[0001262039-23-000010:notes:139]
|  | Amount |
| Balance—December 31, 2021 | $ | 125.1 |  |
| Additions due to business combinations | 5.8 |  |
| Foreign currency translation adjustments | (2.9) |  |
| Balance—December 31, 2022 | $ | 128.0 |  |

[0001262039-23-000010:notes:140]
There were no impairments to goodwill during 2022, 2021 and 2020, or any previous years.

[0001262039-23-000010:notes:141]
Other Intangible Assets—Net

[0001262039-23-000010:notes:142]
The following tables present other intangible assets—net (in millions, except years):

[0001262039-23-000010:notes:143]
|  | December 31, 2022 |
|  | Weighted-Average Useful Life (in Years) |  | Gross |  | Accumulated Amortization |  | Net |
| Other intangible assets—net: |  |  |  |  |  |  |  |
| Finite-lived intangible assets: |  |  |  |  |  |  |  |
| Developed technologies | 4.1 |  | $ | 85.1 |  |  | $ | 50.3 |  |  | $ | 34.8 |  |
| Customer relationships | 7.1 |  | 31.0 |  |  | 14.4 |  |  | 16.6 |  |
| Trade name | 10.0 |  | 5.3 |  |  | 0.7 |  |  | 4.6 |  |
| Backlog | 1.0 |  | 4.2 |  |  | 4.2 |  |  | — |  |
| Total other intangible assets—net |  |  | $ | 125.6 |  |  | $ | 69.6 |  |  | $ | 56.0 |  |

[0001262039-23-000010:notes:144]
|  | December 31, 2021 |
|  | Weighted-Average Useful Life (in Years) |  | Gross |  | Accumulated Amortization |  | Net |
| Other intangible assets—net: |  |  |  |  |  |  |  |
| Finite-lived intangible assets: |  |  |  |  |  |  |  |
| Developed technologies | 4.0 |  | $ | 82.2 |  |  | $ | 38.0 |  |  | $ | 44.2 |  |
| Customer relationships | 6.0 |  | 22.2 |  |  | 11.9 |  |  | 10.3 |  |
| Trade name | 10.0 |  | 6.1 |  |  | 0.2 |  |  | 5.9 |  |
| Backlog | 1.0 |  | 4.8 |  |  | 1.6 |  |  | 3.2 |  |
| Total other intangible assets—net |  |  | $ | 115.3 |  |  | $ | 51.7 |  |  | $ | 63.6 |  |

[0001262039-23-000010:notes:145]
Amortization expense of finite-lived intangible assets was $23.3 million, $18.5 million and $13.3 million in 2022, 2021, and 2020, respectively.

[0001262039-23-000010:notes:146]
The following table summarizes estimated future amortization expense of finite-lived intangible assets (in millions):

[0001262039-23-000010:notes:147]
| Year Ending December 31, | Amount |
| 2023 | $ | 18.1 |  |
| 2024 | 13.5 |  |
| 2025 | 8.8 |  |
| 2026 | 4.3 |  |
| 2027 | 4.0 |  |
| Thereafter | 7.3 |  |
| Total | $ | 56.0 |  |


## us-gaap:EarningsPerShareTextBlock

[0001262039-23-000010:notes:148]
NET INCOME PER SHARE
Basic net income per share is computed by dividing net income attributable to Fortinet, Inc., by the weighted-average number of shares of common stock outstanding during the period. Diluted net income per share is computed by dividing net income attributable to Fortinet, Inc. by the weighted-average number of shares of common stock outstanding during the period, plus the dilutive effects of restricted stock units (“RSUs”) and stock options. Dilutive shares of common stock are determined by applying the treasury stock method.

[0001262039-23-000010:notes:149]
A reconciliation of the numerator and denominator used in the calculation of basic and diluted net income per share attributable to Fortinet, Inc. is (in millions, except per share amounts):

[0001262039-23-000010:notes:150]
|  | Year Ended December 31, |
|  | 2022 |  | 2021 |  | 2020 |
| Numerator: |  |  |  |  |  |
| Net income including non-controlling interests | $ | 856.6 |  |  | $ | 606.7 |  |  | $ | 488.5 |  |
| Net loss attributable to non-controlling interests | (0.7) |  |  | (0.1) |  |  | — |  |
| Net income attributable to Fortinet, Inc. | $ | 857.3 |  |  | $ | 606.8 |  |  | $ | 488.5 |  |
| Denominator: |  |  |  |  |  |
| Basic shares: |  |  |  |  |  |
| Weighted-average common stock outstanding-basic | 791.4 |  |  | 816.1 |  |  | 821.0 |  |
| Diluted shares: |  |  |  |  |  |
| Weighted-average common stock outstanding-basic | 791.4 |  |  | 816.1 |  |  | 821.0 |  |
| Effect of potentially dilutive securities: |  |  |  |  |  |
| RSUs | 6.0 |  |  | 10.9 |  |  | 11.4 |  |
| Stock options | 7.9 |  |  | 8.3 |  |  | 5.9 |  |
| Weighted-average shares used to compute diluted net income per share attributable to Fortinet, Inc. | 805.3 |  |  | 835.3 |  |  | 838.3 |  |
| Net income per share attributable to Fortinet, Inc.: |  |  |  |  |  |
| Basic | $ | 1.08 |  |  | $ | 0.74 |  |  | $ | 0.60 |  |
| Diluted | $ | 1.06 |  |  | $ | 0.73 |  |  | $ | 0.58 |  |

[0001262039-23-000010:notes:151]
The following weighted-average shares of common stock were excluded from the computation of diluted net income per share attributable to Fortinet, Inc. for the periods presented, as their effect would have been antidilutive (in millions):

[0001262039-23-000010:notes:152]
|  | Year Ended December 31, |
|  | 2022 |  | 2021 |  | 2020 |
| RSUs | 1.0 |  |  | 0.7 |  |  | 1.7 |  |
| Stock options | 1.5 |  |  | 1.1 |  |  | 2.7 |  |
| Total | 2.5 |  |  | 1.8 |  |  | 4.4 |  |


## us-gaap:LesseeOperatingLeasesTextBlock

[0001262039-23-000010:notes:153]
LEASES
We have operating leases for offices, research and development facilities and data centers. Our leases have remaining terms that range from less than one year to approximately seven years, some of which include one or more options to renew, with renewal terms of up to seven years. Unless and until we are reasonably certain we will exercise these renewal options, we do not include renewal options in our lease terms for calculating our lease liability, as the renewal options allow us to maintain operational flexibility. Our finance leases were not material to our consolidated financial statements.

[0001262039-23-000010:notes:154]
The components of lease expense were (in millions):

[0001262039-23-000010:notes:155]
|  | Year Ended December 31, |
|  | 2022 |  | 2021 |  | 2020 |
| Operating lease expense | $ | 37.1 |  |  | $ | 26.5 |  |  | $ | 18.5 |  |
| Variable lease expense (1) | 3.7 |  |  | 3.1 |  |  | 2.3 |  |
| Short-term lease expense | 5.6 |  |  | 3.7 |  |  | 3.8 |  |
| Total lease expense | $ | 46.4 |  |  | $ | 33.3 |  |  | $ | 24.6 |  |
| (1) Variable lease expense for the year ended December 31, 2022, 2021 and 2020 predominantly included common area maintenance charges, real estate taxes, certain parking expense and insurance costs. |

[0001262039-23-000010:notes:156]
Supplemental balance sheet information related to our operating leases was (in millions, except lease term and discount rate):

[0001262039-23-000010:notes:157]
|  | Classification |  | December 31,2022 |  | December 31,2021 |
| Operating lease ROU assets – non-current | Other assets |  | $ | 96.3 |  |  | $ | 65.1 |  |
| Operating lease liabilities – current | Accrued liabilities |  | $ | 33.2 |  |  | $ | 26.3 |  |
| Operating lease liabilities – non-current | Other liabilities |  | 62.5 |  |  | 40.5 |  |
| Total operating lease liabilities |  |  | $ | 95.7 |  |  | $ | 66.8 |  |
| Weighted average remaining lease term in years – operating leases |  |  | 3.5 |  | 3.0 |
| Weighted average discount rate – operating leases |  |  | 3.5 | % |  | 2.1 | % |

[0001262039-23-000010:notes:158]
Supplemental cash flow information related to leases was (in millions):

[0001262039-23-000010:notes:159]
|  | Year Ended December 31, |
|  | 2022 |  | 2021 |  | 2020 |
| Cash paid for amounts included in the measurement of lease liabilities |  |  |  |  |  |
| Operating cash flows used for operating leases | $ | 33.8 |  |  | $ | 25.8 |  |  | $ | 18.9 |  |

[0001262039-23-000010:notes:160]
Maturities of operating lease liabilities as of December 31, 2022 were (in millions):

[0001262039-23-000010:notes:161]
| Year Ending December 31, | Amount |
| 2023 | $ | 30.1 |  |
| 2024 | 32.1 |  |
| 2025 | 15.9 |  |
| 2026 | 7.5 |  |
| 2027 | 6.6 |  |
| Thereafter | 12.1 |  |
| Total lease payments | $ | 104.3 |  |
| Less imputed interest | (8.6) |  |
| Total | $ | 95.7 |  |

[0001262039-23-000010:notes:162]
As of December 31, 2022, we had additional minimum lease payments of $2.1 million relating to operating leases that had been signed but had not yet commenced. These leases will commence during 2023 and will have lease terms of approximately two to six years.


## us-gaap:DebtDisclosureTextBlock

[0001262039-23-000010:notes:163]
DEBT
2026 and 2031 Senior Notes

[0001262039-23-000010:notes:164]
On March 5, 2021, we issued $1.0 billion aggregate principal amount of senior notes (collectively, the “Senior Notes”), consisting of $500.0 million aggregate principal amount of 1.0% notes due March 15, 2026 (the “2026 Senior Notes”) and $500.0 million aggregate principal amount of 2.2% notes due March 15, 2031 (the “2031 Senior Notes”), in an underwritten registered public offering. The Senior Notes are senior unsecured obligations and rank equally with each other in right of payment and with our other outstanding obligations. We may redeem the Senior Notes at any time in whole or in part for cash, at specified redemption prices that include accrued and unpaid interest, if any, and a make-whole premium. However, no make-whole premium will be paid for redemptions of the 2026 Senior Notes on or after February 15, 2026, or the 2031 Senior Notes on or after December 15, 2030. Interest on the Senior Notes is payable on March 15 and September 15 of each year, beginning on September 15, 2021. As of December 31, 2022, the Senior Notes were recorded as long-term debt, net of discount and issuance costs, which are amortized to interest expense over the respective contractual terms of these notes using the effective interest method.

[0001262039-23-000010:notes:165]
The total outstanding debt is summarized below (in millions, except percentages):

[0001262039-23-000010:notes:166]
|  | Maturity |  | Coupon Rate |  | Effective Interest Rate |  | December 31,2022 |
| Debt |  |  |  |  |  |  |  |
| 2026 Senior Notes | March 2026 |  | 1.0 | % |  | 1.3 | % |  | $ | 500.0 |  |
| 2031 Senior Notes | March 2031 |  | 2.2 | % |  | 2.3 | % |  | 500.0 |  |
| Total debt |  |  |  |  |  |  | 1,000.0 |  |
| Less: Unamortized discount and debt issuance costs |  |  |  |  |  |  | 9.6 |  |
| Total long-term debt |  |  |  |  |  |  | $ | 990.4 |  |

[0001262039-23-000010:notes:167]
As of December 31, 2022 and 2021, we accrued interest payable of $4.7 million, and there are no financial covenants with which we must comply. In 2022 and 2021, we recorded $17.9 million and $14.7 million of total interest expense in relation to these Senior Notes and repaid $16.0 million and $8.4 million of interest in cash, respectively. No interest costs were capitalized in 2022 and 2021, as the costs that qualified for capitalization were not material.

[0001262039-23-000010:notes:168]
The total estimated fair value of the outstanding Senior Notes was approximately $829.5 million, including accrued and unpaid interest, as of December 31, 2022. The fair value was determined based on observable market prices of identical instruments in less active markets. The estimated fair values are based on Level 2 inputs.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001262039-23-000010:notes:169]
COMMITMENTS AND CONTINGENCIES
The following table summarizes our inventory purchase commitments as of December 31, 2022 (in millions):

[0001262039-23-000010:notes:170]
|  | Total |  | 2023 |  | Thereafter |
| Inventory purchase commitments | $ | 1,335.0 |  |  | $ | 1,270.7 |  |  | $ | 64.3 |  |

[0001262039-23-000010:notes:171]
Inventory Purchase Commitments—Our independent contract manufacturers and certain component suppliers procure components and build our products based on our forecasts, the availability of various components and their capacity. These forecasts are based on estimates of future demand for our products, which are in turn based on historical trends and an analysis from our sales and marketing organizations, adjusted for extended lead times, changes in supplier delivery commitments and other supply chain matters and other market conditions. In order to manage manufacturing lead times, plan for adequate component supply and incentivize suppliers to deliver, we may issue purchase orders to some of our independent contract manufacturers which are non-cancelable. As of December 31, 2022, we had $1.34 billion of open purchase orders with our independent contract manufacturers that consisted of non-cancelable commitments. In certain instances, these agreements allow us the option to reschedule and adjust our requirements based on our business needs prior to firm orders being placed.

[0001262039-23-000010:notes:172]
Other Contractual Commitments and Open Purchase Orders—In addition to commitments with contract manufacturers and certain component suppliers, we have open purchase orders and contractual obligations in the ordinary course of business for which we have not received goods or services. A significant portion of our reported purchase commitments consist of firm and non-cancelable commitments. In certain instances, contractual commitments allow us the option to cancel, reschedule, and adjust our requirements based on our business needs prior to firm orders being placed. As of December 31, 2022, we had $108.1 million in other contractual commitments having a remaining term in excess of one year that are non-cancelable.

[0001262039-23-000010:notes:173]
Litigation—We are involved in disputes, litigation, and other legal actions. For lawsuits where we are the defendant, we are in the process of defending these litigation matters, and while there can be no assurances and the outcome of certain of these matters is currently not determinable and not predictable, we currently are unaware of any existing claims or proceedings that we believe are likely to have a material adverse effect on our financial position. There are many uncertainties associated with any litigation and these actions or other third-party claims against us may cause us to incur costly litigation fees, costs and substantial settlement charges, and possibly subject us to damages and other penalties. In addition, the resolution of any intellectual property (“IP”) litigation may require us to make royalty payments, which could adversely affect our gross margins in future periods. If any of those events were to occur, our business, financial condition, results of operations, and cash flows could be adversely affected. Litigation is unpredictable and the actual liability in any such matters may be materially different from our current estimates, which could result in the need to adjust any accrued liability and record additional expenses. We accrue for contingencies when we believe that a loss is probable and that we can reasonably estimate the amount of any such loss. These accruals are generally based on a range of possible outcomes that require significant management judgement. If no amount within a range is a better estimate than any other, we accrue the minimum amount.

[0001262039-23-000010:notes:174]
Litigation loss contingency accruals associated with outstanding cases were not material as of December 31, 2022 and 2021.

[0001262039-23-000010:notes:175]
Indemnification and Other Matters—Under the indemnification provisions of our standard sales contracts, we agree to defend our customers against third-party claims asserting various allegations such as product defects and infringement of certain IP rights, which may include patents, copyrights, trademarks or trade secrets, and to pay judgments entered on such claims. In some contracts, our exposure under these indemnification provisions is limited by the terms of the contracts to certain defined limits, such as the total amount paid by our customer under the agreement. However, certain agreements include covenants, penalties and indemnification provisions including and beyond indemnification for third-party claims of IP infringement that could potentially expose us to losses in excess of the amount received under the agreement, and in some instances to potential liability that is not contractually limited. Although from time to time there are indemnification claims asserted against us and currently there are pending indemnification claims, to date there have been no material awards under such indemnification provisions.

[0001262039-23-000010:notes:176]
Similar to other security companies and companies in other industries, we have in the past experienced, and we may in the future experience, cybersecurity threats, malicious activity directed against our information technology infrastructure or unauthorized attempts to gain access to our and our customers’ sensitive information and systems. We currently are unaware of 
any existing claims or proceedings related to these types of matters, including any that we believe are likely to have a material adverse effect on our financial position.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001262039-23-000010:notes:177]
EQUITY PLANS AND SHARE REPURCHASE PROGRAM
Stock-Based Compensation Plans

[0001262039-23-000010:notes:178]
We have one primary stock incentive plan, the 2009 EIP, under which we have granted RSUs and stock options.

[0001262039-23-000010:notes:179]
Our board of directors approved the 2009 EIP in 2009 and amended the plan in 2019. The maximum aggregate number of shares that may be issued under the 2009 EIP is 239,367,655 shares; provided, however, that only 67,500,000 shares may be issued or transferred pursuant to new awards granted on or following the effective date of the 2009 EIP. We may grant awards to employees, directors and other service providers. In the case of an incentive stock option granted to an employee who, at the time of the grant, owns stock representing more than 10% of the voting power of all classes of stock, the exercise price shall be no less than 110% of the fair market value per share on the date of grant and expire no more than five years from the date of grant, and options granted to any other employee, the per share exercise price shall be no less than 100% of the closing stock price on the date of grant. In the case of a non-statutory stock option and options granted to other service providers, the per share exercise price shall be no less than 100% of the fair market value per share on the date of grant. Options granted to individuals owning less than 10% of the total combined voting power of all classes of stock generally have a contractual term of no more than ten years and options generally vest over four years.

[0001262039-23-000010:notes:180]
As of December 31, 2022, there were a total of 57.2 million shares of common stock available for grant under the 2009 EIP.

[0001262039-23-000010:notes:181]
Restricted Stock Units

[0001262039-23-000010:notes:182]
The following table summarizes the activity and related information for RSUs for the periods presented below (in millions, except per share amounts):

[0001262039-23-000010:notes:183]
|  | Restricted Stock Units Outstanding |
|  | Number of Shares |  | Weighted-Average Grant Date Fair Value per Share |
| Balance—December 31, 2019 | 30.7 |  |  | $ | 12.91 |  |
| Granted | 9.6 |  |  | 24.23 |  |
| Forfeited | (2.2) |  |  | 15.97 |  |
| Vested | (14.7) |  |  | 11.64 |  |
| Balance—December 31, 2020 | 23.4 |  |  | 18.09 |  |
| Granted | 5.8 |  |  | 40.53 |  |
| Forfeited | (1.8) |  |  | 22.99 |  |
| Vested | (11.7) |  |  | 16.30 |  |
| Balance—December 31, 2021 | 15.7 |  |  | 27.06 |  |
| Granted | 4.1 |  |  | 58.09 |  |
| Forfeited | (1.1) |  |  | 34.94 |  |
| Vested | (8.2) |  |  | 23.69 |  |
| Balance—December 31, 2022 | 10.5 |  |  | $ | 40.94 |  |

[0001262039-23-000010:notes:184]
Stock compensation expense is recognized on a straight-line basis over the vesting period of each RSU. As of December 31, 2022, total compensation expense related to unvested RSUs granted to employees and non-employees under the 2009 EIP, but not yet recognized, was $374.4 million, with a weighted-average remaining vesting period of 2.6 years.

[0001262039-23-000010:notes:185]
RSUs settle into shares of common stock upon vesting. Upon the vesting of the RSUs, we net-settle the RSUs and withhold a portion of the shares to satisfy employee withholding tax requirements. The payment of the withheld taxes to the tax authorities is reflected as a financing activity within the consolidated statements of cash flows.

[0001262039-23-000010:notes:186]
The following summarizes the number and value of the shares withheld for employee taxes (in millions):

[0001262039-23-000010:notes:187]
|  | Year Ended December 31, |
|  | 2022 |  | 2021 |  | 2020 |
| Shares withheld for taxes | 2.7 |  |  | 3.8 |  |  | 4.6 |  |
| Amount withheld for taxes | $ | 160.4 |  |  | $ | 167.9 |  |  | $ | 108.2 |  |

[0001262039-23-000010:notes:188]
Employee Stock Options

[0001262039-23-000010:notes:189]
In determining the fair value of our employee stock options, we use the Black-Scholes model, which employs the following assumptions.

[0001262039-23-000010:notes:190]
Expected Term—The expected term represents the period that our stock-based awards are expected to be outstanding. We believe that we have sufficient historical experience for determining the expected term of the stock option award, and therefore, we calculated our expected term based on historical experience instead of using the simplified method.

[0001262039-23-000010:notes:191]
Expected Volatility—The expected volatility of our common stock is based on our weighted-average implied and historical volatility.

[0001262039-23-000010:notes:192]
Fair Value of Common Stock—The fair value of our common stock is the closing sales price of the common stock effective on the date of grant.

[0001262039-23-000010:notes:193]
Risk-Free Interest Rate—We base the risk-free interest rate on the implied yield available on U.S. Treasury zero-coupon issues with an equivalent remaining term.

[0001262039-23-000010:notes:194]
Expected Dividend—The expected dividend weighted-average assumption is zero.

[0001262039-23-000010:notes:195]
The following table summarizes the weighted-average assumptions relating to our employee stock options:

[0001262039-23-000010:notes:196]
|  | Year Ended December 31, |
|  | 2022 |  | 2021 |  | 2020 |
| Expected term in years | 4.4 |  | 4.4 |  | 4.4 |
| Volatility | 41.6 | % |  | 39.1 | % |  | 34.8 | % |
| Risk-free interest rate | 2.2 | % |  | 0.5 | % |  | 1.1 | % |
| Dividend rate | — | % |  | — | % |  | — | % |

[0001262039-23-000010:notes:197]
The following table summarizes the stock option activity and related information for the periods presented below (in millions, except exercise prices and contractual life):

[0001262039-23-000010:notes:198]
|  | Options Outstanding |
|  | Numberof Shares |  | Weighted-AverageExercisePrice |  | Weighted-AverageRemainingContractualLife (Years) |  | AggregateIntrinsicValue |
| Balance—December 31, 2019 | 13.3 |  |  | $ | 10.07 |  |  | 4.5 |  | $ | 150.3 |  |
| Granted | 3.3 |  |  | 23.76 |  |  |  |  |  |
| Forfeited | (0.3) |  |  | 18.30 |  |  |  |  |  |
| Exercised | (2.7) |  |  | 8.30 |  |  |  |  |  |
| Balance—December 31, 2020 | 13.6 |  |  | 13.51 |  |  | 4.2 |  | 220.4 |  |
| Granted | 2.9 |  |  | 37.26 |  |  |  |  |  |
| Forfeited | (0.4) |  |  | 24.53 |  |  |  |  |  |
| Exercised | (2.4) |  |  | 11.01 |  |  |  |  |  |
| Balance—December 31, 2021 | 13.7 |  |  | 18.57 |  |  | 4.0 |  | 729.9 |  |
| Granted | 1.7 |  |  | 60.26 |  |  |  |  |  |
| Forfeited | (0.2) |  |  | 37.03 |  |  |  |  |  |
| Exercised | (2.0) |  |  | 13.10 |  |  |  |  |  |
| Balance—December 31, 2022 | 13.2 |  |  | $ | 24.37 |  |  |  |  |  |
| Options vested and expected to vest—December 31, 2022 | 13.2 |  |  | $ | 24.37 |  |  | 3.5 |  | $ | 344.8 |  |
| Options exercisable—December 31, 2022 | 9.1 |  |  | $ | 16.10 |  |  | 2.7 |  | $ | 300.0 |  |

[0001262039-23-000010:notes:199]
The aggregate intrinsic value represents the difference between the exercise price of stock options and the quoted market price of our common stock at the date of balance sheet for all in-the-money stock options. Stock compensation expense is recognized on a straight-line basis over the vesting period of each stock option. As of December 31, 2022, total compensation expense related to unvested stock options granted to employees but not yet recognized was $53.7 million, with a weighted-average remaining vesting period of 2.6 years.

[0001262039-23-000010:notes:200]
Additional information related to our stock options is summarized below (in millions, except per share amounts):

[0001262039-23-000010:notes:201]
|  | Year Ended December 31, |
|  | 2022 |  | 2021 |  | 2020 |
| Weighted-average fair value per share granted | $ | 22.18 |  |  | $ | 12.15 |  |  | $ | 7.16 |  |
| Intrinsic value of options exercised | $ | 88.4 |  |  | $ | 83.5 |  |  | $ | 43.5 |  |
| Fair value of options vested | $ | 24.9 |  |  | $ | 17.2 |  |  | $ | 13.5 |  |

[0001262039-23-000010:notes:202]
The following table summarizes information about outstanding and exercisable stock options as of December 31, 2022, (in millions, except exercise prices and contractual life):

[0001262039-23-000010:notes:203]
|  |  | Options Outstanding |  | Options Exercisable |
| Range of Exercise Prices |  | NumberOutstanding |  | Weighted-AverageRemainingContractualLife (Years) |  | Weighted-AverageExercisePrice |  | NumberExercisable |  | Weighted-AverageExercisePrice |
| $4.77-$9.81 |  | 4.3 |  |  | 1.4 |  | $ | 8.08 |  |  | 4.3 |  |  | $ | 8.08 |  |
| $11.66-$22.72 |  | 2.5 |  |  | 3.2 |  | 16.91 |  |  | 2.3 |  |  | 16.81 |  |
| $22.90-$34.89 |  | 4.5 |  |  | 4.6 |  | 28.82 |  |  | 2.4 |  |  | 27.61 |  |
| $39.68-$68.70 |  | 1.9 |  |  | 6.1 |  | 59.79 |  |  | 0.1 |  |  | 56.72 |  |
|  |  | 13.2 |  |  |  |  |  |  | 9.1 |  |  |  |

[0001262039-23-000010:notes:204]
Shares Reserved for Future Issuances

[0001262039-23-000010:notes:205]
The following table presents the common stock reserved for future issuance (in millions):

[0001262039-23-000010:notes:206]
|  | December 31,2022 |
| Reserved for future equity award grants | 57.2 |  |
| Outstanding stock options and RSUs | 23.7 |  |
| Total common stock reserved for future issuances | 80.9 |  |

[0001262039-23-000010:notes:207]
Stock-Based Compensation Expense

[0001262039-23-000010:notes:208]
Stock-based compensation expense, including stock-based compensation expense related to awards classified as liabilities, is included in costs and expenses (in millions):

[0001262039-23-000010:notes:209]
|  | Year Ended December 31, |
|  | 2022 |  | 2021 |  | 2020 |
| Cost of product revenue | $ | 1.7 |  |  | $ | 1.7 |  |  | $ | 1.6 |  |
| Cost of service revenue | 18.8 |  |  | 15.7 |  |  | 12.9 |  |
| Research and development | 64.2 |  |  | 56.7 |  |  | 47.6 |  |
| Sales and marketing | 105.0 |  |  | 110.0 |  |  | 108.4 |  |
| General and administrative | 30.1 |  |  | 27.1 |  |  | 23.3 |  |
| Total stock-based compensation expense | $ | 219.8 |  |  | $ | 211.2 |  |  | $ | 193.8 |  |

[0001262039-23-000010:notes:210]
The following table summarizes stock-based compensation expense, including stock-based compensation expense related to awards classified as liabilities, by award type (in millions):

[0001262039-23-000010:notes:211]
|  | Year Ended December 31, |
|  | 2022 |  | 2021 |  | 2020 |
| RSUs | $ | 195.0 |  |  | $ | 191.8 |  |  | $ | 179.7 |  |
| Stock options | 24.8 |  |  | 19.4 |  |  | 14.1 |  |
| Total stock-based compensation expense | $ | 219.8 |  |  | $ | 211.2 |  |  | $ | 193.8 |  |

[0001262039-23-000010:notes:212]
Total income tax benefit associated with stock-based compensation that is recognized in the consolidated statements of income is (in millions):

[0001262039-23-000010:notes:213]
|  | Year Ended December 31, |
|  | 2022 |  | 2021 |  | 2020 |
| Income tax benefit associated with stock-based compensation | $ | 48.6 |  |  | $ | 45.4 |  |  | $ | 42.1 |  |

[0001262039-23-000010:notes:214]
Share Repurchase Program

[0001262039-23-000010:notes:215]
In January 2016, our board of directors approved the Repurchase Program, which authorized the repurchase of up to $200.0 million of our outstanding common stock through December 31, 2017. From 2016 through 2021, our board of directors approved increases to our Repurchase Program by various amounts and extended the term to February 28, 2023, bringing the aggregated amount authorized to $4.25 billion. In July 2022, our board of directors approved a $1.0 billion increase, bringing the aggregate amount authorized to be repurchased to $5.25 billion. Under the Repurchase Program, share repurchases may be made by us from time to time in privately negotiated transactions or in open market transactions. The Repurchase Program does not require us to purchase a minimum number of shares, and may be suspended, modified or discontinued at any time without prior notice. In 2022, we repurchased 36.0 million shares of common stock under the Repurchase Program in open market transactions for an aggregate purchase price of $1.99 billion. As of December 31, 2022, $529.6 million remained available for future share repurchases under the Repurchase Program. In February 2023, our board of directors approved an extension of the Repurchase Program to February 29, 2024.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001262039-23-000010:notes:216]
INCOME TAXES 
Income before income taxes and loss from equity method investment consisted of (in millions):

[0001262039-23-000010:notes:217]
|  | Year Ended December 31, |
|  | 2022 |  | 2021 |  | 2020 |
| Domestic | $ | 873.8 |  |  | $ | 567.7 |  |  | $ | 490.6 |  |
| Foreign | 81.7 |  |  | 60.7 |  |  | 51.1 |  |
| Total income before income taxes and loss from equity method investment | $ | 955.5 |  |  | $ | 628.4 |  |  | $ | 541.7 |  |

[0001262039-23-000010:notes:218]
The provision for (benefit from) income taxes consisted of (in millions):

[0001262039-23-000010:notes:219]
|  | Year Ended December 31, |
|  | 2022 |  | 2021 |  | 2020 |
| Current: |  |  |  |  |  |
| Federal | $ | 218.5 |  |  | $ | 80.7 |  |  | $ | 38.6 |  |
| State | 19.1 |  |  | 2.5 |  |  | 8.1 |  |
| Foreign | 18.8 |  |  | 23.3 |  |  | 13.6 |  |
| Total current | $ | 256.4 |  |  | $ | 106.5 |  |  | $ | 60.3 |  |
| Deferred: |  |  |  |  |  |
| Federal | $ | (208.3) |  |  | $ | (90.2) |  |  | $ | (8.1) |  |
| State | (14.9) |  |  | (1.1) |  |  | (0.8) |  |
| Foreign | (2.4) |  |  | (1.1) |  |  | 1.8 |  |
| Total deferred | (225.6) |  |  | (92.4) |  |  | (7.1) |  |
| Provision for income taxes | $ | 30.8 |  |  | $ | 14.1 |  |  | $ | 53.2 |  |

[0001262039-23-000010:notes:220]
The foreign tax provision included the tax impacts from U.S. GAAP to local tax return book to tax differences that create a permanent addback including but not limited to stock compensation, meals and entertainment, and settlement of prior year tax audits with foreign jurisdiction adjustments.

[0001262039-23-000010:notes:221]
The provision for income taxes differs from the amount computed by applying the statutory federal income tax rate (in millions):

[0001262039-23-000010:notes:222]
|  | Year Ended December 31, |
|  | 2022 |  | 2021 |  | 2020 |
| Tax at federal statutory tax rate | $ | 200.6 |  |  | $ | 132.0 |  |  | $ | 113.8 |  |
| Foreign income taxed at different rates | 15.7 |  |  | 2.9 |  |  | 16.4 |  |
| Foreign withholding taxes | 31.0 |  |  | 37.4 |  |  | 18.8 |  |
| Stock-based compensation expense | (81.1) |  |  | (74.8) |  |  | (39.6) |  |
| Foreign tax credit | (26.2) |  |  | (53.2) |  |  | (30.1) |  |
| State taxes—net of federal benefit | (3.2) |  |  | (4.6) |  |  | 4.9 |  |
| Research and development credit | (11.6) |  |  | (11.1) |  |  | (7.5) |  |
| Valuation allowance | 25.9 |  |  | 20.0 |  |  | 11.9 |  |
| Impact of the 2017 Tax Cuts and Jobs Act: |  |  |  |  |  |
| One-time transition tax | — |  |  | 5.8 |  |  | 2.6 |  |
| Foreign-Derived Intangible Income | (115.2) |  |  | (33.6) |  |  | (44.3) |  |
| Other | (5.1) |  |  | (6.7) |  |  | 6.3 |  |
| Total provision for income taxes | $ | 30.8 |  |  | $ | 14.1 |  |  | $ | 53.2 |  |

[0001262039-23-000010:notes:223]
On January 4, 2022, the U.S. Treasury published another tranche of final regulations regarding the foreign tax credit. These final regulations impose new requirements that a foreign tax must meet in order to be creditable against U.S. income taxes, and generally apply to tax years beginning on or after December 28, 2021. On July 26, 2022, the U.S. Treasury released corrections to the final regulations. These final regulations adversely impact our ability to claim foreign tax credits in the United States for certain taxes imposed by certain foreign jurisdictions. These final regulations increased our tax expense by approximately $27.5 million on our consolidated financial statements as of December 31, 2022.

[0001262039-23-000010:notes:224]
On August 16, 2022, the United States enacted the IRA that, among other changes, provides for changes to the U.S. corporate income tax system, including a 15% minimum tax based on financial statement income for companies with three-year average annual adjusted financial statement income exceeding $1 billion, and a 1% excise tax on net repurchases of stock after December 31, 2022, if any. We considered the applicable tax law changes, and there is no impact to our tax provision for the year ended December 31, 2022. We will continue to evaluate the impact of these tax law changes on future periods.

[0001262039-23-000010:notes:225]
The tax effects of temporary differences that give rise to significant portions of the deferred tax assets as of the years ended are presented below (in millions):

[0001262039-23-000010:notes:226]
|  | December 31,2022 |  | December 31,2021 |
| Deferred tax assets: |  |  |  |
| General business credit carryforward | $ | 95.0 |  |  | $ | 63.5 |  |
| Deferred revenue | 380.1 |  |  | 276.5 |  |
| Reserves and accruals | 90.1 |  |  | 59.5 |  |
| Net operating loss carryforward | 21.2 |  |  | 22.2 |  |
| Stock-based compensation expense | 19.8 |  |  | 18.3 |  |
| Depreciation and amortization | 5.6 |  |  | 17.0 |  |
| Capitalized research expenditures | 176.7 |  |  | 64.2 |  |
| Operating lease liabilities | 20.8 |  |  | 13.1 |  |
| Total deferred tax assets | 809.3 |  |  | 534.3 |  |
| Less: Valuation allowance | (100.8) |  |  | (75.0) |  |
| Deferred tax assets, net of valuation allowance | 708.5 |  |  | 459.3 |  |
| Deferred tax liabilities: |  |  |  |
| Deferred contract costs | (117.5) |  |  | (97.4) |  |
| Operating lease ROU assets | (20.9) |  |  | (11.9) |  |
| Acquired intangibles | (8.8) |  |  | (15.7) |  |
| Total deferred tax liabilities | (147.2) |  |  | (125.0) |  |
| Net deferred tax assets | $ | 561.3 |  |  | $ | 334.3 |  |

[0001262039-23-000010:notes:227]
In assessing the realizability of deferred tax assets, we considered whether it is more likely than not that some portion or all of our deferred tax assets will be realized. This realization is dependent upon the generation of future taxable income during the periods in which those temporary differences become deductible. We concluded that it is more likely than not that we will be able to realize the benefits of our deferred tax assets in the future except for our California research and development credits carryforward, certain impairment losses in business investments, certain foreign tax credits from foreign disregarded entities and certain tax attributes from business acquisitions. As of December 31, 2022, we had a valuation allowance of $100.8 million against those items.

[0001262039-23-000010:notes:228]
As of December 31, 2022, our federal and California net operating loss carryforwards for income tax purposes were $70.4 million and $20.8 million, respectively. All the net operating loss carryforwards were from acquisitions which were limited by Section 382 of the Internal Revenue Code. If not utilized, the federal net operating loss carryforwards will begin to expire in 2023, and California net operating loss carryforwards will begin to expire in 2034.

[0001262039-23-000010:notes:229]
As of December 31, 2022, we had state tax credit carryforwards of $46.4 million. The state credits can be carried forward indefinitely.

[0001262039-23-000010:notes:230]
The aggregate changes in the balance of unrecognized tax benefits are (in millions):

[0001262039-23-000010:notes:231]
|  | Year Ended December 31, |
|  | 2022 |  | 2021 |  | 2020 |
| Unrecognized tax benefits, beginning of year | $ | 73.3 |  |  | $ | 77.3 |  |  | $ | 67.5 |  |
| Gross increases for tax positions related to the current year | 13.6 |  |  | 7.6 |  |  | 13.1 |  |
| Gross decreases for tax positions related to the current year | — |  |  | — |  |  | — |  |
| Gross increases for tax positions related to the prior year | 0.9 |  |  | 8.7 |  |  | 6.1 |  |
| Gross decreases for tax positions related to prior year | (2.0) |  |  | (0.7) |  |  | (1.3) |  |
| Gross decreases for tax positions related to prior year audit settlements | — |  |  | — |  |  | (1.4) |  |
| Gross decreases for tax positions related to expiration of statute of limitations | (18.4) |  |  | (19.6) |  |  | (6.7) |  |
| Unrecognized tax benefits, end of year | $ | 67.4 |  |  | $ | 73.3 |  |  | $ | 77.3 |  |

[0001262039-23-000010:notes:232]
As of December 31, 2022, we had $67.4 million of unrecognized tax benefits, of which, if recognized, $58.5 million would favorably affect our effective tax rate. Our gross unrecognized tax benefits decreased by approximately $5.9 million during the year ended December 31, 2022. The net decrease was primarily due to the reversal of gross unrecognized tax benefits in connection with the lapse of statutes of limitations. Our policy is to include accrued interest and penalties related to uncertain tax benefits in income tax expense. As of December 31, 2022, 2021 and 2020, accrued interest and penalties were $9.3 million, $13.3 million and $14.5 million, respectively.

[0001262039-23-000010:notes:233]
It is reasonably possible that our gross unrecognized tax benefits will decrease by up to $15.1 million in the next 12 months, primarily due to the lapse of the statute of limitations. These adjustments, if recognized, would favorably impact our effective tax rate, and would be recognized as additional tax benefits.

[0001262039-23-000010:notes:234]
We file income tax returns in the U.S. federal jurisdiction and in various U.S. state and foreign jurisdictions. Generally, we are no longer subject to examination by U.S. federal income tax authorities for tax years prior to 2016. We are no longer subject to U.S. state and foreign income tax examinations by tax authorities for tax years prior to 2010. We currently have ongoing tax audits in the United Kingdom, Canada, Germany and several other foreign jurisdictions. The focus of these audits is the inter-company profit allocation.


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0001262039-23-000010:notes:235]
DEFINED CONTRIBUTION PLANSOur tax-deferred savings plan under our 401(k) Plan permits participating U.S. employees to contribute a portion of their pre-tax or after-tax earnings. In Canada, we have a Group Registered Retirement Savings Plan Program (the “RRSP”), which permits participants to make pre-tax contributions. Our board of directors approved 50% matching contributions on employee contributions up to 4% of each employee’s eligible earnings. Our matching contributions to our 401(k) Plan and the RRSP for 2022, 2021 and 2020 were $12.6 million, $10.0 million and $8.3 million, respectively.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001262039-23-000010:notes:236]
SEGMENT INFORMATIONOperating segments are defined as components of an enterprise about which separate financial information is available that is evaluated regularly by the chief operating decision maker in deciding how to allocate resources and in assessing performance. Our chief operating decision maker is our chief executive officer. Our chief executive officer reviews financial information presented on a consolidated basis, accompanied by information about revenue by geographic region for purposes of allocating resources and evaluating financial performance. We have one business activity, and there are no segment managers who are held accountable for operations, operating results and plans for levels or components below the consolidated unit level. Accordingly, we have determined that we have one operating segment, and therefore, one reportable segment.
Revenue by geographic region is based on the billing address of our customers. The following tables set forth revenue and property and equipment—net by geographic region (in millions):

[0001262039-23-000010:notes:237]
|  | Year Ended December 31, |
| Revenue | 2022 |  | 2021 |  | 2020 |
| Americas: |  |  |  |  |  |
| United States | $ | 1,325.0 |  |  | $ | 1,006.8 |  |  | $ | 813.3 |  |
| Other Americas | 460.0 |  |  | 352.0 |  |  | 263.9 |  |
| Total Americas | 1,785.0 |  |  | 1,358.8 |  |  | 1,077.2 |  |
| Europe, Middle East and Africa (“EMEA”) | 1,691.8 |  |  | 1,275.9 |  |  | 991.9 |  |
| Asia Pacific (“APAC”) | 940.6 |  |  | 707.5 |  |  | 525.3 |  |
| Total revenue | $ | 4,417.4 |  |  | $ | 3,342.2 |  |  | $ | 2,594.4 |  |

[0001262039-23-000010:notes:238]
| Property and Equipment—net | December 31,2022 |  | December 31,2021 |
| Americas: |  |  |  |
| United States | $ | 638.1 |  |  | $ | 472.4 |  |
| Canada | 204.4 |  |  | 170.9 |  |
| Latin America | 1.1 |  |  | 1.6 |  |
| Total Americas | 843.6 |  |  | 644.9 |  |
| EMEA | 35.9 |  |  | 31.0 |  |
| APAC | 19.0 |  |  | 11.7 |  |
| Total property and equipment—net | $ | 898.5 |  |  | $ | 687.6 |  |

[0001262039-23-000010:notes:239]
The following distributors accounted for 10% or more of our revenue:

[0001262039-23-000010:notes:240]
|  | Year Ended December 31, |
|  | 2022 |  | 2021 |  | 2020 |
| Distributor A | 29 | % |  | 31 | % |  | 30 | % |
| Distributor B | 14 | % |  | * |  | * |
| Distributor C | 14 | % |  | 12 | % |  | 10 | % |

[0001262039-23-000010:notes:241]
* Represents less than 10%

[0001262039-23-000010:notes:242]
The following distributors accounted for 10% or more of net accounts receivable:

[0001262039-23-000010:notes:243]
|  | 2022 |  | 2021 |
| Distributor A | 32 | % |  | 33 | % |
| Distributor B | 13 | % |  | 13 | % |
| Distributor C | 12 | % |  | 13 | % |


## us-gaap:SubsequentEventsTextBlock

[0001262039-23-000010:notes:244]
SUBSEQUENT EVENTShare Repurchase ProgramIn February 2023, our board of directors approved an extension of the Repurchase Program to February 29, 2024.
