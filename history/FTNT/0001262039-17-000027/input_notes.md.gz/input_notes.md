# FTNT notes — 0001262039-17-000027


## ftnt:IncomeTaxBenefitFromStockOptionPlansTableTextBlock

[0001262039-17-000027:notes:1]
[same as prior period, unchanged from 0001262039-17-000017:notes:1]

[0001262039-17-000027:notes:2]
|  | Three Months Ended |  | Six Months Ended |
|  | June 30, 2017 |  | June 30, 2016 |  | June 30, 2017 |  | June 30, 2016 |
| Income tax benefit associated with stock-based compensation | $ | 7,743 |  |  | $ | 7,416 |  |  | $ | 14,389 |  |  | $ | 14,737 |  |


## ftnt:PresentationAndPreparationOfConsolidatedFinancialStatementsPolicyTextBlock

[0001262039-17-000027:notes:3]
Basis of Presentation and Preparation—The unaudited condensed consolidated financial statements of Fortinet, Inc. and its wholly owned subsidiaries (collectively, “we,” “us” or “our”) have been prepared in accordance with generally accepted accounting principles in the United States (“GAAP”) for interim financial information, as well as the instructions to Form 10-Q pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (the “SEC”). Accordingly, they do not include all of the information and footnotes required by GAAP for complete financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the year ended December 31, 2016, contained in our Annual Report on Form 10-K filed with the SEC on March 1, 2017. In the opinion of management, all adjustments, which includes normal recurring adjustments, considered necessary for a fair presentation have been included. All intercompany balances, transactions and cash flows have been eliminated. The results of operations for the three and six months ended June 30, 2017 are not necessarily indicative of the results for the full year or for any future periods. The condensed consolidated balance sheet as of December 31, 2016 is derived from the audited consolidated financial statements for the year ended December 31, 2016.

[0001262039-17-000027:notes:4]
The preparation of financial statements in accordance with GAAP requires management to make estimates and assumptions that affect the amounts reported in the condensed consolidated financial statements and accompanying notes. Actual results could differ materially from those estimates. Certain amounts in prior periods have been reclassified to conform with current period presentation.

[0001262039-17-000027:notes:5]
There have been no material changes to our significant accounting policies as of and for the three and six months ended June 30, 2017, except for changes to our policies related to business combinations. For more information, refer to the “Recently Adopted Accounting Standards.”


## ftnt:ScheduleOfAmortizedCostsUnrealizedGainsAndLossesAndFairValueOfAvailableForSaleSecuritiesTableTextBlock

[0001262039-17-000027:notes:6]
[same as prior period, unchanged from 0001262039-17-000017:notes:6]

[0001262039-17-000027:notes:7]
|  | June 30, 2017 |
|  | AmortizedCost |  | UnrealizedGains |  | UnrealizedLosses |  | FairValue |
| Corporate debt securities | $ | 429,112 |  |  | $ | 78 |  |  | $ | (736 | ) |  | $ | 428,454 |  |
| Commercial paper | 87,464 |  |  | 1 |  |  | (26 | ) |  | 87,439 |  |
| U.S. government and agency securities | 50,283 |  |  | — |  |  | (127 | ) |  | 50,156 |  |
| Municipal bonds | 45,390 |  |  | 21 |  |  | (56 | ) |  | 45,355 |  |
| Term deposit (1) | 405 |  |  | — |  |  | — |  |  | 405 |  |
| Total available-for-sale securities | $ | 612,654 |  |  | $ | 100 |  |  | $ | (945 | ) |  | $ | 611,809 |  |
|  | December 31, 2016 |
|  | AmortizedCost |  | UnrealizedGains |  | UnrealizedLosses |  | FairValue |
| Corporate debt securities | $ | 379,494 |  |  | $ | 43 |  |  | $ | (925 | ) |  | $ | 378,612 |  |
| Commercial paper | 95,110 |  |  | 23 |  |  | (25 | ) |  | 95,108 |  |
| U.S. government and agency securities | 64,604 |  |  | 16 |  |  | (79 | ) |  | 64,541 |  |
| Municipal bonds | 59,257 |  |  | 3 |  |  | (235 | ) |  | 59,025 |  |
| Certificates of deposit and term deposits (1) | 4,219 |  |  | — |  |  | — |  |  | 4,219 |  |
| Total available-for-sale securities | $ | 602,684 |  |  | $ | 85 |  |  | $ | (1,264 | ) |  | $ | 601,505 |  |
| (1) The majority of our certificates of deposit and term deposits are foreign deposits. |


## ftnt:ScheduleOfShareBasedPaymentAwardStockOptionsValuationAssumptionsAndAllocationOfRecognizedPeriodCostsTableTextBlock

[0001262039-17-000027:notes:8]
[same as prior period, unchanged from 0001262039-17-000017:notes:8]

[0001262039-17-000027:notes:9]
|  | Three months Ended |  | Six Months Ended |
|  | June 30, 2017 |  | June 30, 2016 |  | June 30, 2017 |  | June 30, 2016 |
| Expected term in years | 4.4 |  |  | 4.3 |  |  | 4.4 |  |  | 4.3 |  |
| Volatility | 34 | % |  | 39 | % |  | 36 | % |  | 43 | % |
| Risk-free interest rate | 1.9 | % |  | 1.2 | % |  | 1.9 | % |  | 1.1 | % |
| Dividend rate | — | % |  | — | % |  | — | % |  | — | % |


## ftnt:ScheduleofEmployeeServiceSharebasedCompensationAllocationofRecognizedPeriodCostsbyAwardTypeTableTextBlock

[0001262039-17-000027:notes:10]
[same as prior period, unchanged from 0001262039-17-000017:notes:10]

[0001262039-17-000027:notes:11]
|  | Three Months Ended |  | Six Months Ended |
|  | June 30, 2017 |  | June 30, 2016 |  | June 30, 2017 |  | June 30, 2016 |
| RSUs | $ | 30,862 |  |  | $ | 26,799 |  |  | $ | 59,903 |  |  | $ | 51,902 |  |
| Stock options | 1,925 |  |  | 1,592 |  |  | 3,770 |  |  | 3,546 |  |
| ESPP | 2,304 |  |  | 1,956 |  |  | 4,749 |  |  | 3,801 |  |
| Total stock-based compensation expense | $ | 35,091 |  |  | $ | 30,347 |  |  | $ | 68,422 |  |  | $ | 59,249 |  |


## ftnt:ScheduleofSharebasedCompensationSharesWithheldforTaxesTableTextBlock

[0001262039-17-000027:notes:12]
[same as prior period, unchanged from 0001262039-17-000017:notes:12]

[0001262039-17-000027:notes:13]
|  |  |  | Six Months Ended |
|  |  |  |  |  | June 30, 2017 |  | June 30, 2016 |
| Shares withheld for taxes |  |  |  |  | 725 |  |  | 590 |  |
| Amount withheld for taxes |  |  |  |  | $ | 25,895 |  |  | $ | 17,358 |  |


## ftnt:ScheduleofSharebasedCompensationStockOptionsActivityAdditionalInformationTableTextBlock

[0001262039-17-000027:notes:14]
[same as prior period, unchanged from 0001262039-17-000017:notes:14]

[0001262039-17-000027:notes:15]
|  | Three Months Ended |  | Six Months Ended |
|  | June 30, 2017 |  | June 30, 2016 |  | June 30, 2017 |  | June 30, 2016 |
| Weighted-average fair value per share granted | $ | 12.18 |  |  | $ | 10.92 |  |  | $ | 12.22 |  |  | $ | 8.90 |  |
| Intrinsic value of options exercised | 9,003 |  |  | 6,829 |  |  | 26,901 |  |  | 26,253 |  |
| Fair value of options vested | 1,733 |  |  | 793 |  |  | 5,128 |  |  | 2,876 |  |


## ftnt:ScheduleofSharebasedPaymentAwardEmployeeStockPurchasePlanAdditionalInformationTableTextBlock

[0001262039-17-000027:notes:16]
[same as prior period, unchanged from 0001262039-17-000017:notes:16]

[0001262039-17-000027:notes:17]
|  | Six Months Ended |
|  | June 30, 2017 |  | June 30, 2016 |
| Weighted-average fair value per share granted | $ | 9.28 |  |  | $ | 7.19 |  |
| Shares issued under the ESPP | 634 |  |  | 614 |  |
| Weighted-average price per share issued | $ | 27.97 |  |  | $ | 20.49 |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001262039-17-000027:notes:18]
BUSINESS COMBINATION

[0001262039-17-000027:notes:19]
On June 7, 2016, we completed our acquisition of AccelOps, Inc. (“AccelOps”), a provider of network security monitoring and analytics solutions, for total cash consideration of $22.1 million, net of cash received. This acquisition extended the Fortinet Security Fabric by enhancing our network security visibility, security data analytics and threat intelligence across multi-vendor solutions.

[0001262039-17-000027:notes:20]
The acquisition of AccelOps was accounted as a business combination in accordance with ASC Topic 805 “Business Combinations” issued by the FASB, and we used our best estimates and assumptions to assign fair value to the tangible and intangible assets acquired and liabilities assumed at the acquisition date. We included acquisition-related costs of $0.3 million in general and administrative expenses. The total purchase price was allocated to AccelOps’ identifiable tangible and intangible assets acquired and liabilities assumed based on their estimated fair values as of the acquisition date. The acquisition also included a contingent obligation for up to $4.0 million in future earn out payments to certain former stockholders of AccelOps if specified future financial targets are met, none of which were met.

[0001262039-17-000027:notes:21]
Total allocation of the purchase price was (in thousands):

[0001262039-17-000027:notes:22]
| Cash and cash equivalents | $ | 171 |  |
| Accounts receivable | 1,126 |  |
| Prepaid expenses and other assets | 430 |  |
| Property and equipment | 203 |  |
| Deferred tax assets | 3,435 |  |
| Finite-lived intangible assets | 14,900 |  |
| Indefinite-lived intangible assets in process research and development | 1,600 |  |
| Goodwill | 9,861 |  |
| Total assets acquired | 31,726 |  |
| Deferred revenue | 4,400 |  |
| Accounts payable and accrued liabilities | 3,348 |  |
| Other liabilities | 1,694 |  |
| Total liabilities assumed | 9,442 |  |
| Total purchase price allocation | $ | 22,284 |  |

[0001262039-17-000027:notes:23]
Finite-lived intangible assets consist of developed technology, customer relationships and other intangible assets. AccelOps’ technology provides a software solution to manage security, performance and compliance from a single platform. The acquired developed technologies include software patents, know-how, process and designs. The value of customer relationships is attributable to the generation of a consistent income source and the avoidance of costs associated with creating new customer relationships.

[0001262039-17-000027:notes:24]
The estimated useful life and fair values of the acquired finite-lived intangible assets were as follows (in thousands, except for estimated useful life):

[0001262039-17-000027:notes:25]
|  | Estimated Useful Life (in years) |  | Fair Values |
| Developed technologies | 4 |  | $ | 12,400 |  |
| Customer relationships | 3 |  | 2,300 |  |
| Other | 2 |  | 200 |  |
| Total |  |  | $ | 14,900 |  |

[0001262039-17-000027:notes:26]
The developed technologies and other are amortized on a straight-line basis. The amortization expense of developed technologies and other intangibles are recorded in cost of revenue. The amortization expense of customer relationships is amortized on an accelerated basis and is recorded in sales and marketing expenses.

[0001262039-17-000027:notes:27]
Indefinite-lived intangible assets consist of in-process research and development, which will begin to be amortized upon completion of development.

[0001262039-17-000027:notes:28]
The goodwill of $9.9 million represents the amount of the purchase price in excess of the fair value of the net tangible liabilities assumed and intangible assets acquired, including AccelOps’ assembled workforce. The goodwill recorded as part of the AccelOps acquisition is not deductible for U.S. federal income tax purposes.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001262039-17-000027:notes:29]
COMMITMENTS AND CONTINGENCIES

[0001262039-17-000027:notes:30]
The following table summarizes our future principal contractual obligations as of June 30, 2017 (in thousands):

[0001262039-17-000027:notes:31]
|  | Total |  | 2017 (remainder) |  | 2018 |  | 2019 |  | 2020 |  | 2021 |  | Thereafter |
| Operating lease commitments | $ | 46,907 |  |  | $ | 7,099 |  |  | $ | 11,296 |  |  | $ | 8,668 |  |  | $ | 7,283 |  |  | $ | 4,122 |  |  | $ | 8,439 |  |
| Inventory purchase commitments | 67,237 |  |  | 65,905 |  |  | 1,332 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Other contractual commitments and open purchase orders | 63,228 |  |  | 53,250 |  |  | 7,057 |  |  | 2,278 |  |  | 533 |  |  | 110 |  |  | — |  |
| Total | $ | 177,372 |  |  | $ | 126,254 |  |  | $ | 19,685 |  |  | $ | 10,946 |  |  | $ | 7,816 |  |  | $ | 4,232 |  |  | $ | 8,439 |  |

[0001262039-17-000027:notes:32]
Operating Leases—We lease certain facilities under various non-cancelable operating leases, which expire through 2026. Certain leases require us to pay variable costs such as taxes, maintenance, and insurance. The terms of certain operating leases also provide for renewal options and escalation clauses. Rent expense was $3.9 million and $4.6 million during the three months ended June 30, 2017 and June 30, 2016, respectively. Rent expense was $8.4 million and $8.5 million during the six months ended June 30, 2017 and June 30, 2016, respectively. Rent expense is recognized using the straight-line method over the term of the lease.

[0001262039-17-000027:notes:33]
Inventory Purchase Commitments—Our independent contract manufacturers procure components and build our products based on our forecasts. These forecasts are based on estimates of future demand for our products, which are in turn based on historical trends and an analysis from our sales and marketing organizations, adjusted for overall market conditions. In order to reduce manufacturing lead times and plan for adequate component supply, we may issue purchase orders to some of our independent contract manufacturers which may not be cancelable. As of June 30, 2017, we had $67.2 million of open purchase orders with our independent contract manufacturers that may not be cancelable.

[0001262039-17-000027:notes:34]
Other Contractual Commitments and Open Purchase Orders—In addition to commitments with contract manufacturers, we have open purchase orders and contractual obligations in the ordinary course of business for which we have not received goods or services. As of June 30, 2017, we had $63.2 million in other contractual commitments that may not be cancelable. We also had other contractual commitments for the purchase of certain real estate adjacent to our corporate headquarters amounting to $12.1 million, which we capitalized as part of property and equipment.

[0001262039-17-000027:notes:35]
Litigation—We are involved in disputes, litigation, and other legal actions. For lawsuits where we are the defendant, we are in the process of defending these litigation matters, and while there can be no assurances and the outcome of these matters is currently not determinable, we currently believe that there are no existing claims or proceedings that are likely to have a material adverse effect on our financial position. There are many uncertainties associated with any litigation and these actions or other third-party claims against us may cause us to incur costly litigation fees, including contingent legal fees with related parties, costs and substantial settlement charges, and possibly subject us to damages and other penalties. In addition, the resolution of any intellectual property litigation may require us to make royalty payments, which could adversely affect our gross margins in future periods. If any of those events were to occur, our business, financial condition, results of operations, and cash flows could be adversely affected. The actual liability in any such matters may be materially different from our estimates, if any, which could result in the need to adjust the liability and record additional expenses. As required under ASC 450, Contingencies, issued by the FASB, we accrue for contingencies when we believe that a loss is probable and that we can reasonably estimate the amount of any such loss.

[0001262039-17-000027:notes:36]
In October 2016, we received a letter from the United States Attorney’s Office for the Northern District of California requesting information relating to our compliance with the Trade Agreements Act. This inquiry is ongoing and we are fully cooperating with this inquiry.

[0001262039-17-000027:notes:37]
Indemnification—Under the indemnification provisions of our standard sales contracts, we agree to defend our customers against third-party claims asserting various allegations such as product defects and infringement of certain intellectual property rights, which may include patents, copyrights, trademarks or trade secrets, and to pay judgments entered on such claims. In some contracts, our exposure under these indemnification provisions is limited by the terms of the contracts to certain defined limits, such as the total amount paid by our customer under the agreement. However, certain agreements include covenants, penalties and indemnification provisions including and beyond indemnification for third-party claims of intellectual property infringement and that could potentially expose us to losses in excess of the amount received under the agreement, and in some instances to potential liability that is not contractually limited. To date, there have been no material awards under such indemnification provisions.


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0001262039-17-000027:notes:38]
[same as prior period, unchanged from 0001262039-17-000017:notes:27]

[0001262039-17-000027:notes:39]
Our tax-deferred savings plan under our 401(k) Plan, permits participating employees to defer a portion of their pre-tax earnings. In Canada, we have a Group Registered Retirement Savings Plan Program (the “RRSP”), which permits participants to make tax deductible contributions. Our board of directors approved 50% matching contributions on employee contributions up to 4% of each employee’s eligible earnings. Our matching contributions to our 401(k) Plan and the RRSP for the three months ended June 30, 2017 and June 30, 2016 were $1.3 million and $1.2 million, respectively. Our matching contributions to our 401(k) Plan and the RRSP for the six months ended June 30, 2017 and June 30, 2016 were $2.6 million and $2.2 million, respectively.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001262039-17-000027:notes:40]
[same as prior period, unchanged from 0001262039-17-000017:notes:29]

[0001262039-17-000027:notes:41]
[same as prior period, unchanged from 0001262039-17-000017:notes:30]

[0001262039-17-000027:notes:42]
|  | June 30, 2017 |
|  | Unrealized losses on investments |  | Tax provision related to unrealized gains or losses on investments |  | Total |
| Beginning balance | $ | (1,179 | ) |  | $ | 414 |  |  | $ | (765 | ) |
| Other comprehensive income before reclassifications | 332 |  |  | (91 | ) |  | 241 |  |
| Amounts reclassified from accumulated other comprehensive loss | 2 |  |  | (1 | ) |  | 1 |  |
| Net current-period other comprehensive income | 334 |  |  | (92 | ) |  | 242 |  |
| Ending balance | $ | (845 | ) |  | $ | 322 |  |  | $ | (523 | ) |

[0001262039-17-000027:notes:43]
Amounts reclassified from accumulated other comprehensive loss for unrealized losses on investments and tax provision related to unrealized gains or losses on investments are recorded in Other income (expense)—net and in Provision for (benefit from) income taxes, respectively.


## us-gaap:CostMethodInvestmentsDescriptionTextBlock

[0001262039-17-000027:notes:44]
[same as prior period, unchanged from 0001262039-17-000017:notes:33]

[0001262039-17-000027:notes:45]
Our investments in the equity securities of privately held companies totaled $12.1 million and $10.3 million as of June 30, 2017 and December 31, 2016, respectively. These investments are accounted for as cost-basis investments, as we own less than 20% of the voting securities in each of these investments and do not have the ability to exercise significant influence over operating and financial policies of the respective entities. These investments are carried at historical cost and are recorded as other assets on our condensed consolidated balance sheets and would be measured at fair value if indicators of impairment existed. As of June 30, 2017, no events have occurred that would adversely affect the carrying value of these investments.

[0001262039-17-000027:notes:46]
As of June 30, 2017, we determined that we had a variable interest in these privately held companies. However, we determined that we were not the primary beneficiary as we did not have the power to direct their activities that most significantly affect their economic performance. The variable interest entities are not required to be consolidated in our condensed consolidated financial statements.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001262039-17-000027:notes:47]
FOREIGN CURRENCY DERIVATIVES

[0001262039-17-000027:notes:48]
Our sales contracts are primarily denominated in U.S. dollars and therefore substantially all of our revenue is not subject to foreign currency translation risk. However, a substantial portion of our operating expenses incurred outside the United States are denominated in foreign currencies and are subject to fluctuations due to changes in foreign currency exchange rates, particularly changes in the Canadian dollar (“CAD”), the Euro (“EUR”) and the British pound (“GBP”). To help protect against significant fluctuations in the value and the volatility of future cash flows caused by changes in currency exchange rates, we engage in foreign currency risk management activities to minimize the impact of balance sheet items denominated in CAD. We do not use these contracts for speculative or trading purposes. All of the derivative instruments are with high quality financial institutions and we monitor the creditworthiness of these parties. These contracts typically have a maturity of one month. Changes in the fair value of forward exchange contracts related to balance sheet accounts are insignificant and are included in Other income (expense)—net in the consolidated statement of operations. As of June 30, 2017, the fair value of the forward exchange contracts was not material.

[0001262039-17-000027:notes:49]
Additionally, independent of our use of foreign currency risk management activities, fluctuations in foreign currency exchange rates may cause us to recognize transaction gains and losses in our consolidated statements of operations. Our hedging activities are intended to reduce, but not eliminate, the impact of currency exchange rate movements. As our hedging activities are relatively short-term in nature and are focused on CAD, long-term material changes in the value of the U.S. dollar against other foreign currencies, such as the EUR and GBP could adversely impact our operating expenses in the future.

[0001262039-17-000027:notes:50]
The notional amount of forward exchange contracts to hedge balance sheet accounts as of June 30, 2017 and December 31, 2016 were (in thousands):

[0001262039-17-000027:notes:51]
|  | Buy/Sell |  | Notional |
| Balance Sheet Contracts: |  |  |  |
| Currency—As of June 30, 2017 |  |  |  |
| CAD | Buy |  | $ | 12,866 |  |
| Currency—As of December 31, 2016 |  |  |  |
| CAD | Sell |  | $ | 2,615 |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001262039-17-000027:notes:52]
[same as prior period, unchanged from 0001262039-17-000017:notes:36]

[0001262039-17-000027:notes:53]
[same as prior period, unchanged from 0001262039-17-000017:notes:37]

[0001262039-17-000027:notes:54]
We have stock-based compensation plans pursuant to which we have granted stock options and RSUs. We also have an ESPP for all eligible employees. As of June 30, 2017, there were a total of 50,222,634 shares of common stock available for grant under our stock-based compensation plans.

[0001262039-17-000027:notes:55]
[same as prior period, unchanged from 0001262039-17-000017:notes:39]

[0001262039-17-000027:notes:56]
[same as prior period, unchanged from 0001262039-17-000017:notes:40]

[0001262039-17-000027:notes:57]
|  | Restricted Stock Units Outstanding |
|  | Number of Shares |  | Weighted-Average Grant Date Fair Value per Share |
| Balance—December 31, 2016 | 9,509 |  |  | $ | 31.01 |  |
| Granted | 3,132 |  |  | 37.38 |  |
| Forfeited | (645 | ) |  | 33.73 |  |
| Vested | (2,246 | ) |  | 28.24 |  |
| Balance—June 30, 2017 | 9,750 |  |  | $ | 33.63 |  |

[0001262039-17-000027:notes:58]
As of June 30, 2017, total compensation expense related to unvested RSUs granted to employees and non-employees under the 2009 Plan, but not yet recognized, was $288.2 million. This expense is expected to be amortized on a straight-line basis over a weighted-average vesting period of 2.8 years.

[0001262039-17-000027:notes:59]
[same as prior period, unchanged from 0001262039-17-000017:notes:43]

[0001262039-17-000027:notes:60]
[same as prior period, unchanged from 0001262039-17-000017:notes:44]

[0001262039-17-000027:notes:61]
[same as prior period, unchanged from 0001262039-17-000017:notes:45]

[0001262039-17-000027:notes:62]
|  | Options Outstanding |
|  | Numberof Shares |  | Weighted-AverageExercisePrice |  | Weighted-AverageRemainingContractualLife (Years) |  | AggregateIntrinsicValue |
| Balance—December 31, 2016 | 6,187 |  |  | $ | 23.79 |  |  |  |  |  |  |
| Granted | 512 |  |  | 37.29 |  |  |  |  |  |
| Forfeited | (82 | ) |  | 29.88 |  |  |  |  |  |
| Exercised | (1,368 | ) |  | 17.52 |  |  |  |  |  |
| Balance—June 30, 2017 | 5,249 |  |  | $ | 26.65 |  |  |  |  |  |
| Options vested and expected to vest—June 30, 2017 | 5,249 |  |  | $ | 26.65 |  |  | 3.4 |  | $ | 58,943 |  |
| Options exercisable—June 30, 2017 | 3,478 |  |  | $ | 24.38 |  |  | 2.1 |  | $ | 46,541 |  |

[0001262039-17-000027:notes:63]
The aggregate intrinsic value represents the pre-tax difference between the exercise price of stock options and the quoted market price of our common stock on June 30, 2017, for all in-the-money stock options. As of June 30, 2017, total compensation expense related to unvested stock options granted to employees but not yet recognized was $17.5 million. This expense is expected to be amortized on a straight-line basis over a weighted-average period of 2.8 years.

[0001262039-17-000027:notes:64]
[same as prior period, unchanged from 0001262039-17-000017:notes:48]

[0001262039-17-000027:notes:65]
[same as prior period, unchanged from 0001262039-17-000017:notes:49]

[0001262039-17-000027:notes:66]
|  | Six Months Ended |
|  | June 30, 2017 |  | June 30, 2016 |
| Expected term in years | 0.5 |  |  | 0.5 |  |
| Volatility | 33 | % |  | 48 | % |
| Risk-free interest rate | 0.7 | % |  | 0.4 | % |
| Dividend rate | — | % |  | — | % |

[0001262039-17-000027:notes:67]
[same as prior period, unchanged from 0001262039-17-000017:notes:51]

[0001262039-17-000027:notes:68]
[same as prior period, unchanged from 0001262039-17-000017:notes:52]

[0001262039-17-000027:notes:69]
|  | Three Months Ended |  | Six Months Ended |
|  | June 30, 2017 |  | June 30, 2016 |  | June 30, 2017 |  | June 30, 2016 |
| Cost of product revenue | $ | 383 |  |  | $ | 298 |  |  | $ | 725 |  |  | $ | 578 |  |
| Cost of service revenue | 2,473 |  |  | 2,123 |  |  | 4,783 |  |  | 4,257 |  |
| Research and development | 8,253 |  |  | 7,458 |  |  | 16,151 |  |  | 14,601 |  |
| Sales and marketing | 19,745 |  |  | 16,990 |  |  | 38,771 |  |  | 32,805 |  |
| General and administrative | 4,237 |  |  | 3,478 |  |  | 7,992 |  |  | 7,008 |  |
| Total stock-based compensation expense | $ | 35,091 |  |  | $ | 30,347 |  |  | $ | 68,422 |  |  | $ | 59,249 |  |

[0001262039-17-000027:notes:70]
2016 Share Repurchase Program

[0001262039-17-000027:notes:71]
In January 2016, our board of directors approved the 2016 Share Repurchase Program (the “2016 Repurchase Program”), which authorizes the repurchase of up to $200.0 million of our outstanding common stock through December 31, 2017. In October 2016, our board of directors authorized the purchase of an additional $100.0 million of shares of our common stock under the 2016 Repurchase Program, increasing our current authorization to $300.0 million through December 31, 2017. Under the 2016 Repurchase Program, share repurchases may be made by us from time to time in privately negotiated transactions or in open market transactions. The 2016 Repurchase Program does not require us to purchase a minimum number of shares, and may be suspended, modified or discontinued at any time without prior notice.

[0001262039-17-000027:notes:72]
During the three months ended June 30, 2017, we repurchased 0.8 million shares of common stock under the 2016 Repurchase Program in open market transactions at an average price of $39.07 per share, for an aggregate purchase price of $33.2 million. As of June 30, 2017, $156.0 million remained available for future share repurchases under the 2016 Repurchase Program.


## us-gaap:EarningsPerShareTextBlock

[0001262039-17-000027:notes:73]
NET INCOME (LOSS) PER SHARE

[0001262039-17-000027:notes:74]
Basic net income (loss) per share is computed by dividing net income (loss) by the weighted-average number of shares of common stock outstanding during the period. Diluted net income (loss) per share is computed by dividing net income (loss) by the weighted-average number of shares of common stock outstanding, plus the dilutive effects of restricted stock units (“RSUs”), stock options and the employee stock purchase plan (“ESPP”). Dilutive shares of common stock are determined by applying the treasury stock method. For the three months ended June 30, 2016, we incurred a net loss and, therefore, the effect of dilutive shares were not included in the computation of dilutive net loss per share as the effect was antidilutive.

[0001262039-17-000027:notes:75]
A reconciliation of the numerator and denominator used in the calculation of basic and diluted net income (loss) per share is as follows (in thousands, except per share amounts):

[0001262039-17-000027:notes:76]
|  | Three Months Ended |  | Six Months Ended |
|  | June 30, 2017 |  | June 30, 2016 |  | June 30, 2017 |  | June 30, 2016 |
| Numerator: |  |  |  |  |  |  |  |
| Net income (loss) | $ | 23,033 |  |  | $ | (1,388 | ) |  | $ | 33,750 |  |  | $ | 730 |  |
| Denominator: |  |  |  |  |  |  |  |
| Basic shares: |  |  |  |  |  |  |  |
| Weighted-average common stock outstanding-basic | 175,741 |  |  | 172,075 |  |  | 175,118 |  |  | 171,910 |  |
| Diluted shares: |  |  |  |  |  |  |  |
| Weighted-average common stock outstanding-basic | 175,741 |  |  | 172,075 |  |  | 175,118 |  |  | 171,910 |  |
| Effect of potentially dilutive securities: |  |  |  |  |  |  |  |
| RSUs | 2,441 |  |  | — |  |  | 2,328 |  |  | 1,580 |  |
| Stock options | 1,488 |  |  | — |  |  | 1,506 |  |  | 1,796 |  |
| ESPP | 31 |  |  | — |  |  | 41 |  |  | 74 |  |
| Weighted-average shares used to compute diluted net income (loss) per share | 179,701 |  |  | 172,075 |  |  | 178,993 |  |  | 175,360 |  |
| Net income (loss) per share: |  |  |  |  |  |  |  |
| Basic | $ | 0.13 |  |  | $ | (0.01 | ) |  | $ | 0.19 |  |  | $ | — |  |
| Diluted | $ | 0.13 |  |  | $ | (0.01 | ) |  | $ | 0.19 |  |  | $ | — |  |

[0001262039-17-000027:notes:77]
The following weighted-average shares of common stock were excluded from the computation of diluted net income (loss) per share for the periods presented, as their effect would have been antidilutive (in thousands):

[0001262039-17-000027:notes:78]
|  | Three Months Ended |  | Six Months Ended |
|  | June 30, 2017 |  | June 30, 2016 |  | June 30, 2017 |  | June 30, 2016 |
| RSUs | 1,158 |  |  | 10,577 |  |  | 1,831 |  |  | 4,715 |  |
| Stock options | 1,124 |  |  | 7,058 |  |  | 1,121 |  |  | 1,182 |  |
| ESPP | — |  |  | 554 |  |  | 131 |  |  | 141 |  |
|  | 2,282 |  |  | 18,189 |  |  | 3,083 |  |  | 6,038 |  |


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0001262039-17-000027:notes:79]
[same as prior period, unchanged from 0001262039-17-000017:notes:62]

[0001262039-17-000027:notes:80]
[same as prior period, unchanged from 0001262039-17-000017:notes:63]

[0001262039-17-000027:notes:81]
|  | June 30, 2017 |
|  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
|  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |
| Corporate debt securities | $ | 346,768 |  |  | $ | (708 | ) |  | $ | 14,738 |  |  | $ | (28 | ) |  | $ | 361,506 |  |  | $ | (736 | ) |
| U.S. government and agency securities | 47,668 |  |  | (127 | ) |  | — |  |  | — |  |  | 47,668 |  |  | (127 | ) |
| Municipal bonds | 24,032 |  |  | (56 | ) |  | — |  |  | — |  |  | 24,032 |  |  | (56 | ) |
| Commercial paper | 42,050 |  |  | (26 | ) |  | — |  |  | — |  |  | 42,050 |  |  | (26 | ) |
| Total available-for-sale securities | $ | 460,518 |  |  | $ | (917 | ) |  | $ | 14,738 |  |  | $ | (28 | ) |  | $ | 475,256 |  |  | $ | (945 | ) |

[0001262039-17-000027:notes:82]
[same as prior period, unchanged from 0001262039-17-000017:notes:65]

[0001262039-17-000027:notes:83]
[same as prior period, unchanged from 0001262039-17-000017:notes:66]

[0001262039-17-000027:notes:84]
|  | June 30, 2017 |  | December 31, 2016 |
| Due within one year | $ | 354,187 |  |  | $ | 376,522 |  |
| Due between one and three years | 257,622 |  |  | 224,983 |  |
| Total | $ | 611,809 |  |  | $ | 601,505 |  |

[0001262039-17-000027:notes:85]
Available-for-sale securities are reported at fair value, with unrealized gains and losses and the related tax impact included as a separate component of stockholders’ equity and in comprehensive income (loss). Realized gains and losses on available-for-sale securities are insignificant in the periods presented and are included in Other income (expense)—net in our condensed consolidated statements of operations. We use the specific identification method to determine the cost basis of investments sold.

[0001262039-17-000027:notes:86]
The unrealized losses on our available-for-sale securities were caused by fluctuations in market value and interest rates as a result of the economic environment. As the decline in market value are attributable to changes in market conditions and not credit quality, and because we have concluded currently that we neither intend to sell nor is it more likely than not that we will be required to sell these investments prior to a recovery of par value, we do not consider these investments to be other-than temporarily impaired as of June 30, 2017.

[0001262039-17-000027:notes:87]
[same as prior period, unchanged from 0001262039-17-000017:notes:70]

[0001262039-17-000027:notes:88]
[same as prior period, unchanged from 0001262039-17-000017:notes:71]

[0001262039-17-000027:notes:89]
[same as prior period, unchanged from 0001262039-17-000017:notes:72]

[0001262039-17-000027:notes:90]
[same as prior period, unchanged from 0001262039-17-000017:notes:73]

[0001262039-17-000027:notes:91]
[same as prior period, unchanged from 0001262039-17-000017:notes:74]

[0001262039-17-000027:notes:92]
[same as prior period, unchanged from 0001262039-17-000017:notes:75]

[0001262039-17-000027:notes:93]
[same as prior period, unchanged from 0001262039-17-000017:notes:76]

[0001262039-17-000027:notes:94]
[same as prior period, unchanged from 0001262039-17-000017:notes:77]

[0001262039-17-000027:notes:95]
[same as prior period, unchanged from 0001262039-17-000017:notes:78]

[0001262039-17-000027:notes:96]
The following tables present the fair value of our financial assets measured at fair value on a recurring basis as of June 30, 2017 and December 31, 2016 (in thousands):

[0001262039-17-000027:notes:97]
|  | June 30, 2017 |  | December 31, 2016 |
|  | AggregateFairValue |  | QuotedPrices inActiveMarkets ForIdenticalAssets |  | SignificantOtherObservableRemainingInputs |  | SignificantOtherUnobservableRemainingInputs |  | AggregateFairValue |  | QuotedPrices inActiveMarkets ForIdenticalAssets |  | SignificantOtherObservableRemainingInputs |  | SignificantOtherUnobservableRemainingInputs |
|  |  |  | (Level 1) |  | (Level 2) |  | (Level 3) |  |  |  | (Level 1) |  | (Level 2) |  | (Level 3) |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate debt securities | $ | 428,454 |  |  | $ | — |  |  | $ | 428,454 |  |  | $ | — |  |  | $ | 378,612 |  |  | $ | — |  |  | $ | 378,612 |  |  | $ | — |  |
| Commercial paper | 106,915 |  |  | — |  |  | 106,915 |  |  | — |  |  | 105,097 |  |  | — |  |  | 105,097 |  |  | — |  |
| U.S. government and agency securities | 50,156 |  |  | 44,706 |  |  | 5,450 |  |  | — |  |  | 64,541 |  |  | 52,082 |  |  | 12,459 |  |  | — |  |
| Municipal bonds | 45,355 |  |  | — |  |  | 45,355 |  |  | — |  |  | 59,025 |  |  | — |  |  | 59,025 |  |  | — |  |
| Money market funds | 18,997 |  |  | 18,997 |  |  | — |  |  | — |  |  | 38,649 |  |  | 38,649 |  |  | — |  |  | — |  |
| Certificates of deposit and term deposits (1) | 55,758 |  |  | — |  |  | 55,758 |  |  | — |  |  | 59,479 |  |  | — |  |  | 59,479 |  |  | — |  |
| Total | $ | 705,635 |  |  | $ | 63,703 |  |  | $ | 641,932 |  |  | $ | — |  |  | $ | 705,403 |  |  | $ | 90,731 |  |  | $ | 614,672 |  |  | $ | — |  |
| Reported as: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents | $ | 93,826 |  |  |  |  |  |  |  |  | $ | 103,898 |  |  |  |  |  |  |  |
| Short-term investments | 354,187 |  |  |  |  |  |  |  |  | 376,522 |  |  |  |  |  |  |  |
| Long-term investments | 257,622 |  |  |  |  |  |  |  |  | 224,983 |  |  |  |  |  |  |  |
| Total | $ | 705,635 |  |  |  |  |  |  |  |  | $ | 705,403 |  |  |  |  |  |  |  |

[0001262039-17-000027:notes:98]
(1) Subsequent to the issuance of our consolidated financial statements as of and for the year ended December 31, 2016, we determined that $55.3 million in 30-day term deposits, included within cash and cash equivalents in the consolidated balance sheet as of December 31, 2016, should have also been included as Level 2 investments in the fair value hierarchy table for financial assets and financial liabilities measured at fair value on a recurring basis. Accordingly, we have corrected the above table as of December 31, 2016, the effect of which is immaterial to the financial statements as a whole.

[0001262039-17-000027:notes:99]
There were no transfers between Level 1 and Level 2 of the fair value hierarchy during the six months ended June 30, 2017.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001262039-17-000027:notes:100]
[same as prior period, unchanged from 0001262039-17-000017:notes:82]

[0001262039-17-000027:notes:101]
[same as prior period, unchanged from 0001262039-17-000017:notes:83]

[0001262039-17-000027:notes:102]
As of June 30, 2017, we had goodwill of $14.6 million. There were no impairments to goodwill during the three and six months ended June 30, 2017 or during prior periods.

[0001262039-17-000027:notes:103]
[same as prior period, unchanged from 0001262039-17-000017:notes:85]

[0001262039-17-000027:notes:104]
The following tables present other intangible assets—net as of June 30, 2017 and December 31, 2016 (in thousands, except years):

[0001262039-17-000027:notes:105]
|  | June 30, 2017 |
|  | Weighted-Average Useful Life (in Years) |  | Gross |  | Accumulated Amortization |  | Net |
| Other intangible assets—net: |  |  |  |  |  |  |  |
| Finite-lived intangible assets: |  |  |  |  |  |  |  |
| Developed technologies and other | 3.8 |  | $ | 23,984 |  |  | $ | 11,250 |  |  | $ | 12,734 |  |
| Customer relationships | 4.7 |  | 14,500 |  |  | 8,506 |  |  | 5,994 |  |
|  |  |  | 38,484 |  |  | 19,756 |  |  | 18,728 |  |
| Indefinite-lived intangible assets: |  |  |  |  |  |  |  |
| In-process research and development |  |  | 1,600 |  |  | — |  |  | 1,600 |  |
| Total other intangible assets—net |  |  | $ | 40,084 |  |  | $ | 19,756 |  |  | $ | 20,328 |  |

[0001262039-17-000027:notes:106]
[same as prior period, unchanged from 0001262039-17-000017:notes:88]

[0001262039-17-000027:notes:107]
Amortization expense was $2.2 million and $2.3 million during the three months ended June 30, 2017 and June 30, 2016, respectively. Amortization expense was $4.5 million and $3.5 million during the six months ended June 30, 2017 and June 30, 2016, respectively. The following table summarizes estimated future amortization expense of finite-lived intangible assets—net (in thousands):

[0001262039-17-000027:notes:108]
|  | Amount |
| Years: |  |
| 2017 (remainder) | $ | 4,074 |  |
| 2018 | 6,885 |  |
| 2019 | 5,406 |  |
| 2020 | 2,363 |  |
| Total | $ | 18,728 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001262039-17-000027:notes:109]
[same as prior period, unchanged from 0001262039-17-000017:notes:91]

[0001262039-17-000027:notes:110]
Our effective tax rate was 30% for the three months ended June 30, 2017, compared to an effective tax rate of 62% for the same period last year. Our effective tax rate was 18% for the six months ended June 30, 2017, compared to an effective tax rate of 111% for the same period last year. The effective tax rates for the periods presented are comprised of U.S. federal and state taxes, excess tax benefits from stock-based compensation, withholding taxes and foreign income taxes. The tax rates for the three months ended June 30, 2017 and June 30, 2016 were impacted by excess tax benefits of $4.1 million and $2.6 million, respectively, from stock-based compensation. The tax rates for the six months ended June 30, 2017 and June 30, 2016 were impacted by excess tax benefits of $9.6 million and $6.2 million, respectively, from stock-based compensation. Our effective tax rates fluctuate based on the amount of pre-tax income or loss. The impact of discrete items, such as excess tax benefits from stock-based compensation, on our effective tax rate is greater when our pre-tax income is lower.

[0001262039-17-000027:notes:111]
As of June 30, 2017 and December 31, 2016, unrecognized tax benefits were $76.9 million and $65.5 million, respectively. The total amount of $75.2 million in unrecognized tax benefits, if recognized, would favorably affect our effective tax rate.

[0001262039-17-000027:notes:112]
It is our policy to classify accrued interest and penalties related to uncertain tax benefits in the provision for income taxes. As of June 30, 2017 and December 31, 2016, accrued interest and penalties were $11.5 million and $9.5 million, respectively.

[0001262039-17-000027:notes:113]
It is reasonably possible that our gross unrecognized tax benefits will decrease by up to $7.0 million in the next twelve months, primarily due to the lapse of the statute of limitations. These adjustments, if recognized, would positively impact our effective tax rate, and would be recognized as additional tax benefits.

[0001262039-17-000027:notes:114]
We file income tax returns in the U.S. federal jurisdiction and in various U.S. state and foreign jurisdictions. Generally, we are no longer subject to U.S. state and non-U.S. income tax examinations by tax authorities for tax years prior to 2009. We are no longer subject to examination by U.S federal income tax authorities for tax years prior to 2012. We are currently under examination by U.S federal income tax authorities for tax years 2012, 2013 and 2014. We have filed a waiver extending the statute of limitations to September 15, 2018 for U.S. federal income tax returns for tax years 2012 and 2013. In addition, the tax authorities in France are examining the inter-company relationship between Fortinet, Inc., Fortinet France and Fortinet Singapore. In May 2017, we received a notice from the French tax authorities that an audit was officially opened for tax years from 2007 to 2015. Our Japan tax audit for tax years 2013, 2014 and 2015 was closed with no material adjustment.


## us-gaap:InventoryDisclosureTextBlock

[0001262039-17-000027:notes:115]
[same as prior period, unchanged from 0001262039-17-000017:notes:97]

[0001262039-17-000027:notes:116]
[same as prior period, unchanged from 0001262039-17-000017:notes:98]

[0001262039-17-000027:notes:117]
|  | June 30, 2017 |  | December 31, 2016 |
| Raw materials | $ | 13,265 |  |  | $ | 18,924 |  |
| Finished goods | 73,174 |  |  | 87,963 |  |
| Inventory | $ | 86,439 |  |  | $ | 106,887 |  |


## us-gaap:LongLivedAssetsByGeographicAreasTableTextBlock

[0001262039-17-000027:notes:118]
| Property and Equipment—net | June 30, 2017 |  | December 31, 2016 |
| Americas: |  |  |  |
| U.S. | $ | 110,044 |  |  | $ | 96,414 |  |
| Canada | 101,302 |  |  | 12,881 |  |
| LATAM | 406 |  |  | 607 |  |
| Total Americas | 211,752 |  |  | 109,902 |  |
| EMEA: |  |  |  |
| France | 12,656 |  |  | 13,241 |  |
| Other EMEA | 6,255 |  |  | 6,391 |  |
| Total EMEA | 18,911 |  |  | 19,632 |  |
| APAC | 7,850 |  |  | 7,715 |  |
| Total property and equipment—net | $ | 238,513 |  |  | $ | 137,249 |  |


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001262039-17-000027:notes:119]
Recently Adopted Accounting Standards

[0001262039-17-000027:notes:120]
In January 2017, the Financial Accounting Standards Board (the “FASB”) issued Accounting Standards Update (“ASU”) ASU 2017-01—Business Combinations: Clarifying the Definition of a Business, which clarifies the definition of a business to assist organizations with evaluating whether transactions should be accounted for as acquisitions (or disposals) of assets or businesses. The definition of a business affects many areas of accounting including acquisitions, disposals, goodwill and consolidation. We elected to early adopt ASU 2017-01 on a prospective basis beginning on January 1, 2017. The adoption of ASU 2017-01 did not have a material impact on our consolidated financial statements.

[0001262039-17-000027:notes:121]
Recent Accounting Standards Not Yet Effective

[0001262039-17-000027:notes:122]
In May 2017, the FASB issued ASU 2017-09—Compensation - Stock Compensation to clarify when to account for a change to the terms or conditions of a share-based payment award as a modification. Under ASU 2017-09, modifications accounting is required only if the fair value, the vesting conditions or the classification of the award (as equity or liability) changes as a result of the change in terms or conditions. ASU 2017-09 is effective prospectively for us beginning on January 1, 2018. We do not believe ASU 2017-09 will have a material impact on our consolidated financial statements.

[0001262039-17-000027:notes:123]
In January 2017, the FASB issued ASU 2017-04—Intangibles - Goodwill and Other: Simplifying the Test for Goodwill Impairment. ASU 2017-04 eliminates Step 2 from the goodwill impairment test which measures a goodwill impairment loss by comparing the implied fair value of a reporting unit’s goodwill with the carrying amount of that goodwill. Under ASU 2017-04, an entity should perform its annual or interim goodwill impairment test by comparing the fair value of the reporting unit with its carrying amount, and should recognize an impairment loss for the amount by which the carrying amount exceeds the reporting unit’s fair value, with the loss not exceeding the total amount of goodwill allocated to that reporting unit. ASU 2017-04 will be effective for us beginning on January 1, 2020. Early adoption is permitted for interim or annual goodwill impairment tests performed after January 1, 2017. At adoption, this update will require a prospective approach. We intend to adopt ASU 2017-04 in the fourth quarter of 2017. We do not believe that ASU 2017-04 will have a material impact on our consolidated financial statements.

[0001262039-17-000027:notes:124]
In October 2016, the FASB issued ASU 2016-16—Income Taxes: —Intra-Entity Transfer of Assets Other Than Inventory, which requires the recognition of the income tax consequences of an intra-entity transfer of an asset, other than inventory, when the transfer occurs. ASU 2016-16 will be effective for us beginning on January 1, 2018. We are currently evaluating the impact of adopting ASU 2016-16 on our consolidated financial statements.

[0001262039-17-000027:notes:125]
In June 2016, the FASB issued ASU 2016-13—Financial Instruments—Credit Losses—Measurement of Credit Losses on Financial Instruments, which requires measurement and recognition of expected credit losses for financial assets held. ASU 2016-13 is effective for us beginning on January 1, 2020, with the option to adopt early on January 1, 2019. We are currently evaluating the impact of adopting ASU 2016-13 on our consolidated financial statements.

[0001262039-17-000027:notes:126]
In February 2016, the FASB issued ASU 2016-02—Leases, which requires the recognition of right-of-use assets and lease liabilities on the consolidated balance sheet for substantially all leases. The new guidance includes a number of optional practical expedients that entities may elect to apply. The new guidance will also require significant additional disclosures about the amount, timing and uncertainty of cash flows from leases. This new guidance will be effective for us beginning on January 1, 2019, using a modified retrospective approach. We currently anticipate to early adopt ASU 2016-02 on January 1, 2018. Our ability to early adopt is dependent on system readiness, including software procured from third-party providers, if any, and the completion of our analysis of information necessary to quantify the impact on the prior period financial statements. Based on our current lease portfolio, we currently estimate that the value of leased assets and liabilities that may be recognized to be at least $40.0 million. Previously, we had estimated the amount could be at least $50.0 million. We are continuing to evaluate the impact of ASU 2016-02 and our estimate is subject to change. We do not believe that ASU 2016-02 will have a material impact on our consolidated statements of operations. We expect to expand our disclosures in the footnotes to include more details on our leases, significant judgments and lease-related amounts recognized in the financial statements.

[0001262039-17-000027:notes:127]
In May 2014, the FASB issued ASU 2014-09—Revenue from Contracts with Customers, which outlines a single, comprehensive model for entities to use in accounting for revenue arising from contracts with customers. The core principle of ASU 2014-09 is to recognize revenue when promised goods or services are transferred to customers in an amount that reflects the consideration that is expected to be received for those goods or services. ASU 2014-09 defines a five step process to achieve this core principle and, accordingly, it is possible more judgment and estimates may be required within the revenue recognition process than is required under existing U.S. GAAP, including identifying performance obligations in the contract, estimating the amount of variable consideration to include in the transaction price and allocating the transaction price to each separate performance obligation. The FASB has recently issued several amendments to ASU 2014-09, including clarification on accounting for licenses of intellectual property and identifying performance obligations. ASU 2014-09 will be effective for us beginning January 1, 2018.

[0001262039-17-000027:notes:128]
The two permitted transition methods under ASU 2014-09 are the full retrospective method, in which case ASU 2014-09 would be applied to each prior reporting period presented and the cumulative effect of applying ASU 2014-09 would be recognized at the earliest period shown, or the modified retrospective method, in which case the cumulative effect of applying ASU 2014-09 would be recognized at the date of initial application. We have substantially completed our analysis of historical contracts and believe that the quantitative impact on revenue in our consolidated financial statements is not material. We expect the pattern of revenue recognition from the sales of our FortiGate and other appliances, FortiGuard security subscription services and FortiCare technical support services to be substantially unchanged on an ongoing basis. Further, we do not expect that the acceleration of revenue and associated cost of sales to certain channel partners, which are currently accounted for only once the product is sold through to the end-customer, to have a significant impact upon adoption. We expect to select the transition method for adoption in the third quarter of 2017.

[0001262039-17-000027:notes:129]
Under ASU 2014-09, we will be required to capitalize and amortize incremental costs related to obtaining customer contracts, such as sales commission costs related to service contracts. Under current U.S. GAAP, we expense all sales commissions when incurred. Our quantitative analysis of the impact of the change in accounting for sales commissions, including the various components of our current and future compensation plans and the key assumptions associated with the amortization term, is in progress. We believe that the amortization of incremental commission costs of obtaining customer contracts is likely to have a material impact on our financial statements.

[0001262039-17-000027:notes:130]
We expect to expand our financial statement disclosures which may include more details on our disaggregation of revenue, performance obligations, contract balances, costs to obtain a contract, as well as any significant judgments. We are in the process of assessing the appropriate changes to our business processes, upgrading our systems and developing new controls to support recognition and disclosure under ASU 2014-09. Reviews are ongoing which may alter our conclusions and the anticipated financial impact. We will continue to assess the impact of ASU 2014-09 until the adoption date.


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001262039-17-000027:notes:131]
[same as prior period, unchanged from 0001262039-17-000017:notes:111]

[0001262039-17-000027:notes:132]
[same as prior period, unchanged from 0001262039-17-000017:notes:112]

[0001262039-17-000027:notes:133]
|  | June 30, 2017 |  | December 31, 2016 |
| Building and building improvements | $ | 133,641 |  |  | $ | 49,783 |  |
| Computer equipment and software | 72,131 |  |  | 65,323 |  |
| Land | 59,203 |  |  | 35,079 |  |
| Leasehold improvements | 20,169 |  |  | 18,699 |  |
| Evaluation units | 19,600 |  |  | 20,173 |  |
| Furniture and fixtures | 14,531 |  |  | 13,995 |  |
| Construction-in-progress | 1,077 |  |  | 4,669 |  |
| Total property and equipment | 320,352 |  |  | 207,721 |  |
| Less: accumulated depreciation | (81,839 | ) |  | (70,472 | ) |
| Property and equipment—net | $ | 238,513 |  |  | $ | 137,249 |  |

[0001262039-17-000027:notes:134]
In April 2017, we purchased certain real estate in Burnaby, Canada for $84.8 million. The purchase was accounted for under the asset acquisition method. The cost of the assets acquired was allocated to land and buildings based on their relative fair values. The amounts allocated to land and buildings were $12.7 million and $72.1 million, respectively.

[0001262039-17-000027:notes:135]
Depreciation expense was $11.8 million and $9.0 million during the three months ended June 30, 2017 and June 30, 2016, respectively. Depreciation expense was $23.0 million and $18.4 million during the six months ended June 30, 2017 and June 30, 2016, respectively.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001262039-17-000027:notes:136]
RELATED PARTY TRANSACTIONS

[0001262039-17-000027:notes:137]
The son of one member of our board of directors is a partner of an outside law firm that we utilize for certain complex litigation matters. Expenses for legal services provided by the law firm were $0.4 million and $0.1 million during the three months ended June 30, 2017 and June 30, 2016, respectively. No contingent fees were incurred in the three months ended June 30, 2017 and 2016. Expenses for legal services provided by the law firm were $0.5 million and $0.4 million during the six months ended June 30, 2017 and June 30, 2016, respectively. No contingent fees were incurred in the six months ended June 30, 2017. Of the $0.4 million legal expenses incurred in the six months ended June 30, 2016, $0.2 million were incurred under contingent fee arrangements. Amounts due and payable to the law firm were $0.5 million and $0.1 million as of June 30, 2017 and December 31, 2016, respectively.


## us-gaap:RevenueFromExternalCustomersByGeographicAreasTableTextBlock

[0001262039-17-000027:notes:138]
|  | Three Months Ended |  | Six Months Ended |
| Revenue | June 30, 2017 |  | June 30, 2016 |  | June 30, 2017 |  | June 30, 2016 |
| Americas: |  |  |  |  |  |  |  |
| U.S. | $ | 97,905 |  |  | $ | 80,811 |  |  | $ | 188,677 |  |  | $ | 156,369 |  |
| Canada | 40,859 |  |  | 33,782 |  |  | 78,204 |  |  | 65,087 |  |
| Latin America (“LATAM”) | 21,949 |  |  | 18,053 |  |  | 40,195 |  |  | 31,236 |  |
| Total Americas | 160,713 |  |  | 132,646 |  |  | 307,076 |  |  | 252,692 |  |
| Europe, Middle East and Africa (“EMEA”) | 129,730 |  |  | 114,453 |  |  | 255,879 |  |  | 219,944 |  |
| Asia Pacific (“APAC”) | 73,026 |  |  | 64,292 |  |  | 141,090 |  |  | 123,331 |  |
| Total revenue | $ | 363,469 |  |  | $ | 311,391 |  |  | $ | 704,045 |  |  | $ | 595,967 |  |

[0001262039-17-000027:notes:139]
[same as prior period, unchanged from 0001262039-17-000017:notes:122]

[0001262039-17-000027:notes:140]
|  | Three Months Ended |  | Six Months Ended |
|  | June 30, 2017 |  | June 30, 2016 |  | June 30, 2017 |  | June 30, 2016 |
| Exclusive Networks Group | 20 | % |  | 20 | % |  | 20 | % |  | 20 | % |
| Fine Tec Computers | 12 | % |  | * |  |  | 12 | % |  | * |  |
| Ingram Micro | 10 | % |  | 10 | % |  | * |  |  | * |  |

[0001262039-17-000027:notes:141]
[same as prior period, unchanged from 0001262039-17-000017:notes:125]

[0001262039-17-000027:notes:142]
|  | June 30, 2017 |  | December 31, 2016 |
| Exclusive Networks Group | 25 | % |  | 26 | % |
| Fine Tec Computers | 11 | % |  | 10 | % |
| Arrow Electronics | 11 | % |  | * |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001262039-17-000027:notes:143]
[same as prior period, unchanged from 0001262039-17-000017:notes:127]

[0001262039-17-000027:notes:144]
[same as prior period, unchanged from 0001262039-17-000017:notes:128]

[0001262039-17-000027:notes:145]
[same as prior period, unchanged from 0001262039-17-000017:notes:129]

[0001262039-17-000027:notes:146]
* Represents less than 10%


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001262039-17-000027:notes:147]
[same as prior period, unchanged from 0001262039-17-000017:notes:130]


## us-gaap:SubsequentEventsTextBlock

[0001262039-17-000027:notes:148]
SUBSEQUENT EVENT

[0001262039-17-000027:notes:149]
In July 2017, our Board of Directors authorized a $300.0 million increase to the 2016 Repurchase Program, bringing the amount authorized to be repurchased to $600.0 million, and extended the 2016 Repurchase Program until January 31, 2019.
