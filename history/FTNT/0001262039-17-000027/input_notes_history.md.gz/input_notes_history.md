# FTNT note change history — 0001262039-17-000017 → 0001262039-17-000027


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2017-08-02):
[0001262039-17-000027:note_history:1]
The following table summarizes our future principal contractual obligations as of June 30, 2017 (in thousands):
  (was, 2017-05-03, similarity 0.9577):
[0001262039-17-000017:note_history:1]
The following table summarizes our future principal contractual obligations as of March 31, 2017 (in thousands):

- changed (2017-08-02):
[0001262039-17-000027:note_history:2]
|  | Total |  | 2017 (remainder) |  | 2018 |  | 2019 |  | 2020 |  | 2021 |  | Thereafter |
| Operating lease commitments | $ | 46,907 |  |  | $ | 7,099 |  |  | $ | 11,296 |  |  | $ | 8,668 |  |  | $ | 7,283 |  |  | $ | 4,122 |  |  | $ | 8,439 |  |
| Inventory purchase commitments | 67,237 |  |  | 65,905 |  |  | 1,332 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Other contractual commitments and open purchase orders | 63,228 |  |  | 53,250 |  |  | 7,057 |  |  | 2,278 |  |  | 533 |  |  | 110 |  |  | — |  |
| Total | $ | 177,372 |  |  | $ | 126,254 |  |  | $ | 19,685 |  |  | $ | 10,946 |  |  | $ | 7,816 |  |  | $ | 4,232 |  |  | $ | 8,439 |  |
  (was, 2017-05-03, similarity 0.9979):
[0001262039-17-000017:note_history:2]
|  | Total |  | 2017 (remainder) |  | 2018 |  | 2019 |  | 2020 |  | 2021 |  | Thereafter |
| Operating lease commitments | $ | 61,354 |  |  | $ | 13,083 |  |  | $ | 14,401 |  |  | $ | 11,972 |  |  | $ | 9,497 |  |  | $ | 4,088 |  |  | $ | 8,313 |  |
| Inventory purchase commitments | 68,846 |  |  | 68,846 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Other contractual commitments and open purchase orders | 71,534 |  |  | 60,959 |  |  | 8,402 |  |  | 1,522 |  |  | 560 |  |  | 91 |  |  | — |  |
| Total | $ | 201,734 |  |  | $ | 142,888 |  |  | $ | 22,803 |  |  | $ | 13,494 |  |  | $ | 10,057 |  |  | $ | 4,179 |  |  | $ | 8,313 |  |

- changed (2017-08-02):
[0001262039-17-000027:note_history:3]
Operating Leases—We lease certain facilities under various non-cancelable operating leases, which expire through 2026. Certain leases require us to pay variable costs such as taxes, maintenance, and insurance. The terms of certain operating leases also provide for renewal options and escalation clauses. Rent expense was $3.9 million and $4.6 million during the three months ended June 30, 2017 and June 30, 2016, respectively. Rent expense was $8.4 million and $8.5 million during the six months ended June 30, 2017 and June 30, 2016, respectively. Rent expense is recognized using the straight-line method over the term of the lease.
  (was, 2017-05-03, similarity 0.7443):
[0001262039-17-000017:note_history:3]
Operating Leases—We lease certain facilities under various non-cancelable operating leases, which expire through 2024. Certain leases require us to pay variable costs such as taxes, maintenance, and insurance. The terms of certain operating leases also provide for renewal options and escalation clauses. Rent expense was $4.5 million and $4.6 million during the three months ended March 31, 2017 and March 31, 2016, respectively. Rent expense is recognized using the straight-line method over the term of the lease.

- changed (2017-08-02):
[0001262039-17-000027:note_history:4]
Inventory Purchase Commitments—Our independent contract manufacturers procure components and build our products based on our forecasts. These forecasts are based on estimates of future demand for our products, which are in turn based on historical trends and an analysis from our sales and marketing organizations, adjusted for overall market conditions. In order to reduce manufacturing lead times and plan for adequate component supply, we may issue purchase orders to some of our independent contract manufacturers which may not be cancelable. As of June 30, 2017, we had $67.2 million of open purchase orders with our independent contract manufacturers that may not be cancelable.
  (was, 2017-05-03, similarity 0.9933):
[0001262039-17-000017:note_history:4]
Inventory Purchase Commitments—Our independent contract manufacturers procure components and build our products based on our forecasts. These forecasts are based on estimates of future demand for our products, which are in turn based on historical trends and an analysis from our sales and marketing organizations, adjusted for overall market conditions. In order to reduce manufacturing lead times and plan for adequate component supply, we may issue purchase orders to some of our independent contract manufacturers which may not be cancelable. As of March 31, 2017, we had $68.8 million of open purchase orders with our independent contract manufacturers that may not be cancelable.

- changed (2017-08-02):
[0001262039-17-000027:note_history:5]
Other Contractual Commitments and Open Purchase Orders—In addition to commitments with contract manufacturers, we have open purchase orders and contractual obligations in the ordinary course of business for which we have not received goods or services. As of June 30, 2017, we had $63.2 million in other contractual commitments that may not be cancelable. We also had other contractual commitments for the purchase of certain real estate adjacent to our corporate headquarters amounting to $12.1 million, which we capitalized as part of property and equipment.
  (was, 2017-05-03, similarity 0.9819):
[0001262039-17-000017:note_history:5]
Other Contractual Commitments and Open Purchase Orders—In addition to commitments with contract manufacturers, we have open purchase orders and contractual obligations in the ordinary course of business for which we have not received goods or services. As of March 31, 2017, we had $71.5 million in other contractual commitments that may not be cancelable. We also had other contractual commitments for the purchase of certain real estate properties adjacent to our corporate headquarters amounting to $12.8 million, which we capitalized as part of property and equipment.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2017-08-02):
[0001262039-17-000027:note_history:6]
Basis of Presentation and Preparation—The unaudited condensed consolidated financial statements of Fortinet, Inc. and its wholly owned subsidiaries (collectively, “we,” “us” or “our”) have been prepared in accordance with generally accepted accounting principles in the United States (“GAAP”) for interim financial information, as well as the instructions to Form 10-Q pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (the “SEC”). Accordingly, they do not include all of the information and footnotes required by GAAP for complete financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the year ended December 31, 2016, contained in our Annual Report on Form 10-K filed with the SEC on March 1, 2017. In the opinion of management, all adjustments, which includes normal recurring adjustments, considered necessary for a fair presentation have been included. All intercompany balances, transactions and cash flows have been eliminated. The results of operations for the three and six months ended June 30, 2017 are not necessarily indicative of the results for the full year or for any future periods. The condensed consolidated balance sheet as of December 31, 2016 is derived from the audited consolidated financial statements for the year ended December 31, 2016.
  (was, 2017-05-03, similarity 0.9839):
[0001262039-17-000017:note_history:6]
Basis of Presentation and Preparation—The unaudited condensed consolidated financial statements of Fortinet, Inc. and its wholly owned subsidiaries (collectively, “we,” “us” or “our”) have been prepared in accordance with generally accepted accounting principles in the United States (“GAAP”) for interim financial information, as well as the instructions to Form 10-Q pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (the “SEC”). Accordingly, they do not include all of the information and footnotes required by GAAP for complete financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the year ended December 31, 2016, contained in our Annual Report on Form 10-K filed with the SEC on March 1, 2017. In the opinion of management, all adjustments, which includes normal recurring adjustments, considered necessary for a fair presentation have been included. All intercompany balances, transactions and cash flows have been eliminated. The results of operations for the three months ended March 31, 2017 are not necessarily indicative of the results for the full year or for any future periods. The condensed consolidated balance sheet as of December 31, 2016 is derived from the audited consolidated financial statements for the year ended December 31, 2016.

- changed (2017-08-02):
[0001262039-17-000027:note_history:7]
The preparation of financial statements in accordance with GAAP requires management to make estimates and assumptions that affect the amounts reported in the condensed consolidated financial statements and accompanying notes. Actual results could differ materially from those estimates. Certain amounts in prior periods have been reclassified to conform with current period presentation.
  (was, 2017-05-03, similarity 0.8499):
[0001262039-17-000017:note_history:7]
The preparation of financial statements in accordance with GAAP requires management to make estimates and assumptions that affect the amounts reported in the condensed consolidated financial statements and accompanying notes. Actual results could differ materially from those estimates.

- changed (2017-08-02):
[0001262039-17-000027:note_history:8]
There have been no material changes to our significant accounting policies as of and for the three and six months ended June 30, 2017, except for changes to our policies related to business combinations. For more information, refer to the “Recently Adopted Accounting Standards.”
  (was, 2017-05-03, similarity 0.7197):
[0001262039-17-000017:note_history:8]
There have been no material changes to our significant accounting policies as of and for the three months ended March 31, 2017, except for changes to our policies related to inventory and business combinations. For more information, refer to the “Recently Adopted Accounting Standards.”

- changed (2017-08-02):
[0001262039-17-000027:note_history:9]
In January 2017, the Financial Accounting Standards Board (the “FASB”) issued Accounting Standards Update (“ASU”) ASU 2017-01—Business Combinations: Clarifying the Definition of a Business, which clarifies the definition of a business to assist organizations with evaluating whether transactions should be accounted for as acquisitions (or disposals) of assets or businesses. The definition of a business affects many areas of accounting including acquisitions, disposals, goodwill and consolidation. We elected to early adopt ASU 2017-01 on a prospective basis beginning on January 1, 2017. The adoption of ASU 2017-01 did not have a material impact on our consolidated financial statements.
  (was, 2017-05-03, similarity 0.997):
[0001262039-17-000017:note_history:9]
In January 2017, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) ASU 2017-01—Business Combinations: Clarifying the Definition of a Business, which clarifies the definition of a business to assist organizations with evaluating whether transactions should be accounted for as acquisitions (or disposals) of assets or businesses. The definition of a business affects many areas of accounting including acquisitions, disposals, goodwill and consolidation. We elected to early adopt ASU 2017-01 on a prospective basis beginning on January 1, 2017. The adoption of ASU 2017-01 did not have a material impact on our consolidated financial statements.

- added (2017-08-02):
[0001262039-17-000027:note_history:10]
In May 2017, the FASB issued ASU 2017-09—Compensation - Stock Compensation to clarify when to account for a change to the terms or conditions of a share-based payment award as a modification. Under ASU 2017-09, modifications accounting is required only if the fair value, the vesting conditions or the classification of the award (as equity or liability) changes as a result of the change in terms or conditions. ASU 2017-09 is effective prospectively for us beginning on January 1, 2018. We do not believe ASU 2017-09 will have a material impact on our consolidated financial statements.

- changed (2017-08-02):
[0001262039-17-000027:note_history:11]
In February 2016, the FASB issued ASU 2016-02—Leases, which requires the recognition of right-of-use assets and lease liabilities on the consolidated balance sheet for substantially all leases. The new guidance includes a number of optional practical expedients that entities may elect to apply. The new guidance will also require significant additional disclosures about the amount, timing and uncertainty of cash flows from leases. This new guidance will be effective for us beginning on January 1, 2019, using a modified retrospective approach. We currently anticipate to early adopt ASU 2016-02 on January 1, 2018. Our ability to early adopt is dependent on system readiness, including software procured from third-party providers, if any, and the completion of our analysis of information necessary to quantify the impact on the prior period financial statements. Based on our current lease portfolio, we currently estimate that the value of leased assets and liabilities that may be recognized to be at least $40.0 million. Previously, we had estimated the amount could be at least $50.0 million. We are continuing to evaluate the impact of ASU 2016-02 and our estimate is subject to change. We do not believe that ASU 2016-02 will have a material impact on our consolidated statements of operations. We expect to expand our disclosures in the footnotes to include more details on our leases, significant judgments and lease-related amounts recognized in the financial statements.
  (was, 2017-05-03, similarity 0.7574):
[0001262039-17-000017:note_history:11]
In February 2016, the FASB issued ASU 2016-02—Leases, which requires the recognition of right-of-use assets and lease liabilities on the consolidated balance sheet for substantially all leases. The new guidance includes a number of optional practical expedients that entities may elect to apply. The new guidance will also require significant additional disclosures about the amount, timing and uncertainty of cash flows from leases. This new guidance will be effective for us beginning on January 1, 2019, using a modified retrospective approach. We currently anticipate to early adopt ASU 2016-02 on January 1, 2018. Our ability to early adopt is dependent on system readiness, including software procured from third-party providers, if any, and the completion of our analysis of information necessary to quantify the impact on the prior period financial statements. Based on our current lease portfolio, we estimate the value of leased assets and liabilities that may be recognized could be at least $50.0 million. We are continuing to evaluate the impact of ASU 2016-02 and our estimate is subject to change. We do not believe that ASU 2016-02 will have a material impact on our consolidated statements of operations.

- added (2017-08-02):
[0001262039-17-000027:note_history:12]
The two permitted transition methods under ASU 2014-09 are the full retrospective method, in which case ASU 2014-09 would be applied to each prior reporting period presented and the cumulative effect of applying ASU 2014-09 would be recognized at the earliest period shown, or the modified retrospective method, in which case the cumulative effect of applying ASU 2014-09 would be recognized at the date of initial application. We have substantially completed our analysis of historical contracts and believe that the quantitative impact on revenue in our consolidated financial statements is not material. We expect the pattern of revenue recognition from the sales of our FortiGate and other appliances, FortiGuard security subscription services and FortiCare technical support services to be substantially unchanged on an ongoing basis. Further, we do not expect that the acceleration of revenue and associated cost of sales to certain channel partners, which are currently accounted for only once the product is sold through to the end-customer, to have a significant impact upon adoption. We expect to select the transition method for adoption in the third quarter of 2017.

- added (2017-08-02):
[0001262039-17-000027:note_history:13]
Under ASU 2014-09, we will be required to capitalize and amortize incremental costs related to obtaining customer contracts, such as sales commission costs related to service contracts. Under current U.S. GAAP, we expense all sales commissions when incurred. Our quantitative analysis of the impact of the change in accounting for sales commissions, including the various components of our current and future compensation plans and the key assumptions associated with the amortization term, is in progress. We believe that the amortization of incremental commission costs of obtaining customer contracts is likely to have a material impact on our financial statements.

- added (2017-08-02):
[0001262039-17-000027:note_history:14]
We expect to expand our financial statement disclosures which may include more details on our disaggregation of revenue, performance obligations, contract balances, costs to obtain a contract, as well as any significant judgments. We are in the process of assessing the appropriate changes to our business processes, upgrading our systems and developing new controls to support recognition and disclosure under ASU 2014-09. Reviews are ongoing which may alter our conclusions and the anticipated financial impact. We will continue to assess the impact of ASU 2014-09 until the adoption date.

- removed (2017-08-02):
[0001262039-17-000017:note_history:15]
In July 2015, the FASB issued ASU 2015-11—Inventory: Simplifying the Measurement of Inventory, which requires entities to measure most inventory at the lower of cost and net realizable value, replacing the former methodology of measuring inventory at the lower of cost or market. We adopted ASU 2015-11 on a prospective basis beginning on January 1, 2017. The adoption of ASU 2015-11 did not have a significant impact on our consolidated financial statements.

- removed (2017-08-02):
[0001262039-17-000017:note_history:16]
The two permitted transition methods under ASU 2014-09 are the full retrospective method, in which case ASU 2014-09 would be applied to each prior reporting period presented and the cumulative effect of applying ASU 2014-09 would be recognized at the earliest period shown, or the modified retrospective method, in which case the cumulative effect of applying ASU 2014-09 would be recognized at the date of initial application. Currently, we are in the process of reviewing our historical contracts to quantify the impact on our consolidated financial statements. Depending on the results of our review, there could be changes to the timing of revenue recognition and certain sales commission and related costs associated with obtaining and fulfilling our customer contracts. These changes may include the acceleration of revenue and associated costs on sales to certain channel partners that are currently accounted for only once the product is sold through to the end-customer. We will be required to capitalize and amortize incremental costs related to obtaining customer contracts, such as sales commission costs. We are also in the process of assessing the appropriate changes to our business processes and upgrading our systems and controls to support recognition and disclosure under ASU 2014-09. We otherwise expect to complete our assessment process, including selecting a transition method for adoption, in the next two quarters of 2017.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- added (2017-08-02):
[0001262039-17-000027:note_history:17]
The son of one member of our board of directors is a partner of an outside law firm that we utilize for certain complex litigation matters. Expenses for legal services provided by the law firm were $0.4 million and $0.1 million during the three months ended June 30, 2017 and June 30, 2016, respectively. No contingent fees were incurred in the three months ended June 30, 2017 and 2016. Expenses for legal services provided by the law firm were $0.5 million and $0.4 million during the six months ended June 30, 2017 and June 30, 2016, respectively. No contingent fees were incurred in the six months ended June 30, 2017. Of the $0.4 million legal expenses incurred in the six months ended June 30, 2016, $0.2 million were incurred under contingent fee arrangements. Amounts due and payable to the law firm were $0.5 million and $0.1 million as of June 30, 2017 and December 31, 2016, respectively.

- removed (2017-08-02):
[0001262039-17-000017:note_history:18]
The son of one member of our board of directors is a partner of an outside law firm that we utilize for certain complex litigation matters. Expenses for legal services provided by the law firm were $0.1 million and $0.3 million during the three months ended March 31, 2017 and March 31, 2016, respectively. Of such amounts, $0.2 million was incurred under contingent fee arrangements in the three months ended March 31, 2016. There were no expenses incurred under contingent fee arrangements during the three months ended March 31, 2017. Amounts due and payable to the law firm were $0.1 million as of March 31, 2017 and December 31, 2016.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- added (2017-08-02):
[0001262039-17-000027:note_history:19]
In July 2017, our Board of Directors authorized a $300.0 million increase to the 2016 Repurchase Program, bringing the amount authorized to be repurchased to $600.0 million, and extended the 2016 Repurchase Program until January 31, 2019.

- removed (2017-08-02):
[0001262039-17-000017:note_history:20]
In April 2017, we purchased real estate property in Vancouver, Canada totaling approximately 282,000 square feet for a total cash payment of approximately $85.0 million.
