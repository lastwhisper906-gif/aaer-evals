# FTNT MD&A — 0001262039-17-000027


## mdna

[0001262039-17-000027:mdna:1]
[same as prior period, unchanged from 0001262039-17-000017:mdna:1]

[0001262039-17-000027:mdna:2]
[same as prior period, unchanged from 0001262039-17-000017:mdna:2]

[0001262039-17-000027:mdna:3]
[same as prior period, unchanged from 0001262039-17-000017:mdna:3]

[0001262039-17-000027:mdna:4]
[same as prior period, unchanged from 0001262039-17-000017:mdna:4]

[0001262039-17-000027:mdna:5]
[same as prior period, unchanged from 0001262039-17-000017:mdna:5]

[0001262039-17-000027:mdna:6]
[same as prior period, unchanged from 0001262039-17-000017:mdna:6]

[0001262039-17-000027:mdna:7]
[same as prior period, unchanged from 0001262039-17-000017:mdna:7]

[0001262039-17-000027:mdna:8]
[same as prior period, unchanged from 0001262039-17-000017:mdna:8]

[0001262039-17-000027:mdna:9]
[same as prior period, unchanged from 0001262039-17-000017:mdna:9]

[0001262039-17-000027:mdna:10]
[same as prior period, unchanged from 0001262039-17-000017:mdna:10]

[0001262039-17-000027:mdna:11]
| • | trends in our operating expenses, including sales and marketing expense, research and development expense, general and administrative expense, and expectations regarding these expenses as a percentage of total revenue; |

[0001262039-17-000027:mdna:12]
[same as prior period, unchanged from 0001262039-17-000017:mdna:12]

[0001262039-17-000027:mdna:13]
[same as prior period, unchanged from 0001262039-17-000017:mdna:13]

[0001262039-17-000027:mdna:14]
[same as prior period, unchanged from 0001262039-17-000017:mdna:14]

[0001262039-17-000027:mdna:15]
[same as prior period, unchanged from 0001262039-17-000017:mdna:15]

[0001262039-17-000027:mdna:16]
[same as prior period, unchanged from 0001262039-17-000017:mdna:16]

[0001262039-17-000027:mdna:17]
[same as prior period, unchanged from 0001262039-17-000017:mdna:17]

[0001262039-17-000027:mdna:18]
[same as prior period, unchanged from 0001262039-17-000017:mdna:18]

[0001262039-17-000027:mdna:19]
[same as prior period, unchanged from 0001262039-17-000017:mdna:19]

[0001262039-17-000027:mdna:20]
[same as prior period, unchanged from 0001262039-17-000017:mdna:20]

[0001262039-17-000027:mdna:21]
| • | adoption and impact of new accounting standards, including those related to revenue recognition and accounting for leases. |

[0001262039-17-000027:mdna:22]
[same as prior period, unchanged from 0001262039-17-000017:mdna:30]

[0001262039-17-000027:mdna:23]
[same as prior period, unchanged from 0001262039-17-000017:mdna:24]

[0001262039-17-000027:mdna:24]
[same as prior period, unchanged from 0001262039-17-000017:mdna:25]

[0001262039-17-000027:mdna:25]
The three key areas driving our business are the changing cyber threat landscape, expanding need for regulatory compliance and evolving network security infrastructure, including cloud environments. The cyber threat landscape continues to change at a rapid pace, with network attacks continually morphing into vehicles for malware, such as ransomware, and the challenge of having to comply with a variety of constantly changing regulatory requirements. Our end-customers’ infrastructures are rapidly evolving to leverage new technologies such as on-demand cloud and internet on demand, and changing web traffic patterns require end-customers to increase the bandwidth available across their network. These three drivers mean end-customers are constantly evaluating upgrades or deployments of new cybersecurity solutions.

[0001262039-17-000027:mdna:26]
The Fortinet Security Fabric has been developed to provide unified security across the entire network, including network core, endpoints, applications, data centers, access and private and public cloud, and is designed to enable traditionally disparate security devices to work together as an integrated and collaborative whole. It delivers integrated scalability, access control, awareness, security, traffic segmentation, centralized management, visibility and orchestration. It is built around an open framework to ensure interoperability and synchronization of intelligence and response, and does so across the distributed network security infrastructure, including both from the cloud and for the cloud. At the core of the Fortinet Security Fabric are our FortiGate physical products and software licenses, which ship with a broad set of security services, including firewall, virtual private network, anti-malware, anti-spam, application control, intrusion prevention, access control, web filtering, traffic and device segmentation and advanced threat protection (“ATP”). Through these security services, our FortiGuard Labs team provides updates using threat research and a global cloud network of data collection and intelligence resources to deliver subscription-based security services to FortiGate appliances and software products. We continually certify the security effectiveness of our security updates through independent test organizations, such as NSS Labs. Our FortiOS operating system provides the foundation for all FortiGate security functions. The latest enhancements to the FortiOS 5.6 offer end-customers the ability to manage security capabilities across their cloud assets’ and software-defined wireless area networks.

[0001262039-17-000027:mdna:27]
[same as prior period, unchanged from 0001262039-17-000017:mdna:28]

[0001262039-17-000027:mdna:28]
We complement our core FortiGate product line with other products and software that offer additional protection from security threats to other critical areas of the enterprise. These products include our FortiMail email security, FortiSandbox ATP, FortiWeb web application firewall and FortiDDoS security appliances, as well as our FortiClient endpoint security software, FortiSIEM software, FortiAP secure wireless access points and FortiSwitch secure switch connectivity products. Our technology also positions us to deliver security to the cloud and for the cloud. Sales of our cloud-related products and services

[0001262039-17-000027:mdna:29]
across public, private and hybrid cloud environments continue to grow faster on a percentage basis than other parts of our business.

[0001262039-17-000027:mdna:30]
[same as prior period, unchanged from 0001262039-17-000017:mdna:31]

[0001262039-17-000027:mdna:31]
| • | We recorded total revenue of $363.5 million and $704.0 million in the three and six months ended June 30, 2017, an increase of 17% and 18%, respectively, compared to the same periods last year. Product revenue was $142.7 million and $278.0 million in the three and six months ended June 30, 2017, an increase of 4% and 6%, respectively, compared to the same periods last year. Service revenue was $220.8 million and $426.1 million in the three and six months ended June 30, 2017, an increase of 26% and 27%, respectively, compared to the same period last year. |

[0001262039-17-000027:mdna:32]
| • | We generated operating income of $28.5 million and $33.9 million in the three and six months ended June 30, 2017, respectively, compared to operating loss of $4.0 million and $7.7 million in the three and six months ended June 30, 2016, respectively. |

[0001262039-17-000027:mdna:33]
| • | Cash, cash equivalents and investments were $1.46 billion as of June 30, 2017, an increase of $154.4 million, or 12%, from December 31, 2016. |

[0001262039-17-000027:mdna:34]
| • | Deferred revenue was $1.16 billion as of June 30, 2017, an increase of $126.1 million, or 12%, from December 31, 2016. |

[0001262039-17-000027:mdna:35]
| • | We generated cash flows from operating activities of $274.5 million in the six months ended June 30, 2017, an increase of $106.0 million, or 63%, compared to the same period last year. |

[0001262039-17-000027:mdna:36]
| • | We repurchased 0.8 million shares of common stock under our 2016 Share Repurchase Program (the “2016 Repurchase Program”) for an aggregate price of $33.2 million in the three months ended June 30, 2017. In July 2017, our Board of Directors authorized a $300.0 million increase to the 2016 Repurchase Program, bringing the total amount authorized to $600.0 million through January 31, 2019. |

[0001262039-17-000027:mdna:37]
During the three and six months ended June 30, 2017, our revenue growth was driven by the strength in sales of our products, including FortiGate products, our renewals of service contracts and the sale of our enterprise bundles. During the three months ended June 30, 2017, our high-end products accounted for 39% of billings, which reflected strong sales to large enterprises and an increase in large deals. Our mid-range products accounted for 29% of billings, and our entry-level products accounted for 32% of billings. In addition, we continue to see a shift to higher services growth, which reflected our success in driving higher-priced subscription bundles and metered model business. On a geographic basis, revenue continues to be diversified globally, which remains a key strength of our business.

[0001262039-17-000027:mdna:38]
During the three and six months ended June 30, 2017, operating expenses increased by 4% and 10%, respectively, as compared to the same periods last year. The increase was primarily driven by our investments made to develop new products and enhance our existing products, as we continued to invest in research and development to strengthen our technology. We believe that continued product innovation has strengthened our technology and resulted in market share gains. As a percentage of revenue, operating expenses decreased as we continued to focus on productivity and efficiency. Headcount increased by 5% to 4,792 employees and contractors as of June 30, 2017, up from 4,562 as of June 30, 2016.

[0001262039-17-000027:mdna:39]
[same as prior period, unchanged from 0001262039-17-000017:mdna:38]

[0001262039-17-000027:mdna:40]
Our sales strategy is based on a distribution model whereby we primarily sell our products, software licenses and services directly to distributors which sell to resellers and service providers, which, in turn, sell to our end-customers. In certain cases, we sell directly to large service providers and major systems integrators. We also offer our products through Amazon Web Services and Microsoft Azure. While the revenue from such sales are still relatively insignificant, they have increased significantly in recent periods on a percentage basis.

[0001262039-17-000027:mdna:41]
[same as prior period, unchanged from 0001262039-17-000017:mdna:40]

[0001262039-17-000027:mdna:42]
[same as prior period, unchanged from 0001262039-17-000017:mdna:41]

[0001262039-17-000027:mdna:43]
Our approach to network security is defined by our Security Processing Unit (“SPU”) hardware architecture. The SPU includes three lines of proprietary Applications-Specific Integrated Circuits (“ASICs”), content processor, network processor and the system on a chip. The ASICs are designed for highly efficient execution of computationally intensive tasks such as policy enforcement, threat detection and encryption. As such, ASIC-based solutions can run many security applications simultaneously without a significant reduction in performance.

[0001262039-17-000027:mdna:44]
[same as prior period, unchanged from 0001262039-17-000017:mdna:43]

[0001262039-17-000027:mdna:45]
[same as prior period, unchanged from 0001262039-17-000017:mdna:44]

[0001262039-17-000027:mdna:46]
|  | Three Months Ended Or As Of |
|  | June 30, 2017 |  | June 30, 2016 |
|  | (in thousands) |
| Revenue | $ | 363,469 |  |  | $ | 311,391 |  |
| Deferred revenue | $ | 1,161,471 |  |  | $ | 903,981 |  |
| Billings (non-GAAP) | $ | 426,889 |  |  | $ | 373,784 |  |
| Cash, cash equivalents and investments | $ | 1,464,946 |  |  | $ | 1,221,991 |  |
| Net cash provided by operating activities | $ | 144,771 |  |  | $ | 67,941 |  |
| Free cash flow (non-GAAP) | $ | 58,409 |  |  | $ | 53,498 |  |

[0001262039-17-000027:mdna:47]
Deferred revenue. Our deferred revenue consists of amounts that have been invoiced but that have not yet been recognized as revenue. The majority of our deferred revenue balance consists of the unrecognized portion of service revenue from FortiGuard security subscription and FortiCare technical support service contracts, which is recognized as revenue ratably over the contractual service period. We monitor our deferred revenue balance, growth and the mix of short-term and long-term deferred revenue because it represents a significant portion of revenue to be recognized in future periods. Deferred revenue was $1.16 billion as of June 30, 2017, an increase of $126.1 million, or 12%, from December 31, 2016.

[0001262039-17-000027:mdna:48]
Billings (non-GAAP). We define billings as revenue recognized in accordance with generally accepted accounting principles in the United States (“GAAP”) plus the change in deferred revenue from the beginning to the end of the period less any deferred revenue balances acquired from business combination(s) during the period. We consider billings to be a useful metric for management and investors because billings drive future revenue, which is an important indicator of the health and viability of our business. There are a number of limitations related to the use of billings instead of GAAP revenue. First, billings include amounts that have not yet been recognized as revenue and are impacted by the term of security and support agreements. Second, we may calculate billings in a manner that is different from peer companies that report similar financial measures. Management accounts for these limitations by providing specific information regarding GAAP revenue and evaluating billings together with GAAP revenue.

[0001262039-17-000027:mdna:49]
[same as prior period, unchanged from 0001262039-17-000017:mdna:48]

[0001262039-17-000027:mdna:50]
|  | Three Months Ended |
| June 30, 2017 |  | June 30, 2016 |  |
| (in thousands) |
| Billings: |  |  |  |
| Revenue | $ | 363,469 |  |  | $ | 311,391 |  |
| Add change in deferred revenue | 63,420 |  |  | 66,793 |  |
| Less deferred revenue balance acquired in business acquisition | — |  |  | (4,400 | ) |
| Total billings (non-GAAP) | $ | 426,889 |  |  | $ | 373,784 |  |

[0001262039-17-000027:mdna:51]
Free cash flow (non-GAAP). We define free cash flow as net cash provided by operating activities minus capital expenditures such as purchases of real estate and other property and equipment. We believe free cash flow to be a liquidity measure that provides useful information to management and investors about the amount of cash generated by the business that, after capital expenditures, can be used for strategic opportunities, including investing in our business, making strategic acquisitions, repurchasing outstanding common stock, and strengthening the balance sheet. However, free cash flow is not intended to represent our residual cash flow available for discretionary expenditures, since we may have other non-discretionary expenditures that are not deducted from the measure. A limitation of using free cash flow rather than the GAAP measure of net cash provided by operating activities is that free cash flow does not represent the total increase or decrease in the cash, cash equivalents and investments balance for the period because it excludes cash provided by or used for other investing and financing activities. Management accounts for this limitation by providing information about our capital expenditures and other investing and financing activities on the face of the cash flow statement and under “—Liquidity and Capital Resources” and by presenting cash flows from investing and financing activities in our reconciliation of free cash flows. In addition, it is important to note that other companies, including companies in our industry, may not use free cash flow, may calculate free cash flow in a different manner than we do or may use other financial measures to evaluate their performance, all of which could reduce the usefulness of free cash flows as a comparative measure. A reconciliation of free cash flow to net cash provided by operating activities, the most directly comparable financial measure calculated and presented in accordance with GAAP, is provided below:

[0001262039-17-000027:mdna:52]
|  | Three Months Ended |
| June 30, 2017 |  | June 30, 2016 |
| (in thousands) |
| Free Cash Flow: |  |  |  |
| Net cash provided by operating activities | $ | 144,771 |  |  | $ | 67,941 |  |
| Less purchases of property and equipment | (86,362 | ) |  | (14,443 | ) |
| Free cash flow (non-GAAP) | $ | 58,409 |  |  | $ | 53,498 |  |
| Net cash used in investing activities | $ | (81,844 | ) |  | $ | (35,213 | ) |
| Net cash used in financing activities | $ | (33,039 | ) |  | $ | (4,356 | ) |

[0001262039-17-000027:mdna:53]
[same as prior period, unchanged from 0001262039-17-000017:mdna:53]

[0001262039-17-000027:mdna:54]
[same as prior period, unchanged from 0001262039-17-000017:mdna:54]

[0001262039-17-000027:mdna:55]
There were no material changes to our critical accounting policies and estimates as of and for the three and six months ended June 30, 2017, as compared to the critical accounting policies and estimates described in our Annual Report on Form 10-K filed with the SEC on March 1, 2017 (the “Form 10-K”).

[0001262039-17-000027:mdna:56]
[same as prior period, unchanged from 0001262039-17-000017:mdna:56]

[0001262039-17-000027:mdna:57]
[same as prior period, unchanged from 0001262039-17-000017:mdna:57]

[0001262039-17-000027:mdna:58]
26

[0001262039-17-000027:mdna:59]
[same as prior period, unchanged from 0001262039-17-000017:mdna:59]

[0001262039-17-000027:mdna:60]
Three Months Ended June 30, 2017 and June 30, 2016

[0001262039-17-000027:mdna:61]
[same as prior period, unchanged from 0001262039-17-000017:mdna:61]

[0001262039-17-000027:mdna:62]
|  | Three Months Ended |  |  |  |  |
| June 30, 2017 |  | June 30, 2016 |  |  |  |  |
| Amount |  | % ofRevenue |  | Amount |  | % ofRevenue |  | Change |  | % Change |
| (in thousands, except percentages) |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 142,705 |  |  | 39 | % |  | $ | 136,641 |  |  | 44 | % |  | $ | 6,064 |  |  | 4 | % |
| Service | 220,764 |  |  | 61 |  |  | 174,750 |  |  | 56 |  |  | 46,014 |  |  | 26 |  |
| Total revenue | $ | 363,469 |  |  | 100 | % |  | $ | 311,391 |  |  | 100 | % |  | $ | 52,078 |  |  | 17 | % |
| Revenue by geography: |  |  |  |  |  |  |  |  |  |  |  |
| Americas | $ | 160,713 |  |  | 44 | % |  | $ | 132,646 |  |  | 43 | % |  | $ | 28,067 |  |  | 21 | % |
| Europe, Middle East and Africa | 129,730 |  |  | 36 |  |  | 114,453 |  |  | 36 |  |  | 15,277 |  |  | 13 |  |
| Asia Pacific | 73,026 |  |  | 20 |  |  | 64,292 |  |  | 21 |  |  | 8,734 |  |  | 14 |  |
| Total revenue | $ | 363,469 |  |  | 100 | % |  | $ | 311,391 |  |  | 100 | % |  | $ | 52,078 |  |  | 17 | % |

[0001262039-17-000027:mdna:63]
Total revenue increased by $52.1 million, or 17%, in the three months ended June 30, 2017 compared to the same period last year. On a geographic basis, we continued to experience global diversification. All three regions experienced revenue growth compared to the same period last year, with the Americas contributing the largest portion of our revenue growth on both an absolute dollar and a percentage basis. Product revenue increased by $6.1 million, or 4%, in the three months ended June 30, 2017 compared to the same period last year. The increase in product revenue was primarily driven by the strength in sales of our FortiGate products. Service revenue increased by $46.0 million, or 26%, in the three months ended June 30, 2017 compared to the same period last year. The increase in service revenue was primarily due to the recognition of revenue from our growing deferred revenue balance, consisting of FortiGuard security subscription and FortiCare technical support contracts sold to a larger customer base, as well as the renewals of similar contracts sold in earlier periods. We continued to see the shift from product revenue to higher-margin, recurring service revenue, which reflected our success in driving sales of subscription bundles.

[0001262039-17-000027:mdna:64]
[same as prior period, unchanged from 0001262039-17-000017:mdna:64]

[0001262039-17-000027:mdna:65]
|  | Three Months Ended |  |  |  |  |
| June 30, 2017 |  | June 30, 2016 |  | Change |  | % Change |
| (in thousands, except percentages) |
| Cost of revenue: |  |  |  |  |  |  |  |
| Product | $ | 60,787 |  |  | $ | 52,788 |  |  | $ | 7,999 |  |  | 15 | % |
| Service | 34,865 |  |  | 31,715 |  |  | 3,150 |  |  | 10 |  |
| Total cost of revenue | $ | 95,652 |  |  | $ | 84,503 |  |  | $ | 11,149 |  |  | 13 | % |
| Gross margin: |  |  |  |  |  |  |  |
| Product | 57.4 | % |  | 61.4 | % |  | (4.0 | )% |  |  |
| Service | 84.2 |  |  | 81.9 |  |  | 2.3 |  |  |  |
| Total gross margin | 73.7 | % |  | 72.9 | % |  | 0.8 | % |  |  |

[0001262039-17-000027:mdna:66]
Total gross margin increased by 0.8 percentage points in the three months ended June 30, 2017 compared to the same period last year, driven by higher margin on service revenue. Service gross margin increased by 2.3 percentage points in the three months ended June 30, 2017 as compared to the same period last year, resulting from an increased mix of higher-margin subscription bundles. Total cost of service revenue was comprised primarily of personnel costs.

[0001262039-17-000027:mdna:67]
27

[0001262039-17-000027:mdna:68]
Product gross margin decreased by 4.0 percentage points in the three months ended June 30, 2017 compared to the same period last year. The decrease in product gross margin was primarily due to higher inventory reserves as we transition to newer appliances and other charges.

[0001262039-17-000027:mdna:69]
[same as prior period, unchanged from 0001262039-17-000017:mdna:69]

[0001262039-17-000027:mdna:70]
|  | Three Months Ended |  | Change |  | % Change |
| June 30, 2017 |  | June 30, 2016 |  |
| Amount |  | % ofRevenue |  | Amount |  | % ofRevenue |  |
| (in thousands, except percentages) |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | $ | 51,159 |  |  | 14 | % |  | $ | 45,502 |  |  | 15 | % |  | $ | 5,657 |  |  | 12 | % |
| Sales and marketing | 166,337 |  |  | 46 |  |  | 162,694 |  |  | 52 |  |  | 3,643 |  |  | 2 |  |
| General and administrative | 21,911 |  |  | 6 |  |  | 22,184 |  |  | 7 |  |  | (273 | ) |  | (1 | ) |
| Restructuring charges | (90 | ) |  | — |  |  | 553 |  |  | — |  |  | (643 | ) |  | (116 | ) |
| Total operating expenses | $ | 239,317 |  |  | 66 | % |  | $ | 230,933 |  |  | 74 | % |  | $ | 8,384 |  |  | 4 | % |

[0001262039-17-000027:mdna:71]
[same as prior period, unchanged from 0001262039-17-000017:mdna:71]

[0001262039-17-000027:mdna:72]
Research and development expense increased by $5.7 million, or 12%, in the three months ended June 30, 2017 compared to the same period last year, primarily due to an increase of $4.2 million in personnel costs as a result of increased headcount to support the development of new products and continued enhancements of our existing products. In addition, depreciation and product development expenses, such as third-party testing and prototypes, increased by $0.9 million. We intend to continue to invest in our research and development organization, but expect research and development expense as a percentage of total revenue to remain at a relatively comparable level during the remainder of 2017.

[0001262039-17-000027:mdna:73]
[same as prior period, unchanged from 0001262039-17-000017:mdna:73]

[0001262039-17-000027:mdna:74]
Sales and marketing expense increased by $3.6 million, or 2%, in the three months ended June 30, 2017 compared to the same period last year, primarily due to an increase of $4.5 million in personnel costs. In addition, depreciation expense and other occupancy-related expense increased by $2.6 million. These increases were partially offset by lower marketing-related expense of $2.2 million and travel expense of $1.0 million. As a percentage of total revenue, sales and marketing expense decreased as revenue grew at a higher pace compared to personnel costs. The decrease in personnel costs as a percentage of total revenue resulted from lower sales commissions, slower hiring and attrition. We intend to continue to make investments in our sales resources and infrastructure and marketing, which are critical to support growth, and expect sales and marketing expense to increase in absolute dollars during the remainder of 2017.

[0001262039-17-000027:mdna:75]
[same as prior period, unchanged from 0001262039-17-000017:mdna:75]

[0001262039-17-000027:mdna:76]
General and administrative expense decreased by $0.3 million, or 1%, in the three months ended June 30, 2017 compared to the same period last year, primarily due to lower third-party costs of $6.3 million due to the substantial completion of our enterprise resource planning (“ERP”) system implementation in 2016. The decrease in expense was partially offset by an increase in professional fees of $3.6 million, which included expense of $1.6 million due to third-party costs related to implementing the new revenue recognition standard. In addition, personnel costs increased by $2.6 million as we continued to increase headcount.  As a percentage of total revenue, general and administrative costs decreased to 6% in the three months ended June 30, 2017 from 7% in the three months ended June 30, 2016. We expect general and administrative expense to increase in absolute dollars during the remainder of 2017 as we continue to implement the new revenue recognition standard.

[0001262039-17-000027:mdna:77]
Operating margin

[0001262039-17-000027:mdna:78]
We generated operating income of $28.5 million in the three months ended June 30, 2017, an increase of $32.5 million compared to operating loss of $4.0 million in the same period last year. The improvement in operating margin is primarily due to the decline in sales and marketing and general and administrative expenses as a percentage of total revenue. As a percentage of total revenue, sales and marketing expenses decreased to 46% in the three months ended June 30, 2017 from 52% in the

[0001262039-17-000027:mdna:79]
same period last year. In addition, as a percentage of total revenue, general and administrative expenses decreased to 6% in the three months ended June 30, 2017 from 7% in the same period last year. Significant changes in operating expenses are discussed above.

[0001262039-17-000027:mdna:80]
[same as prior period, unchanged from 0001262039-17-000017:mdna:80]

[0001262039-17-000027:mdna:81]
|  | Three Months Ended |  |  |  |  |
| June 30, 2017 |  | June 30, 2016 |  | Change |  | % Change |
| (in thousands, except percentages) |
| Interest income | $ | 3,163 |  |  | $ | 1,705 |  |  | $ | 1,458 |  |  | 86 | % |
| Other income (expense)—net | 1,243 |  |  | (1,350 | ) |  | 2,593 |  |  | (192 | ) |

[0001262039-17-000027:mdna:82]
Interest income increased by $1.5 million, or 86%, in the three months ended June 30, 2017 as compared to the same period last year due to higher interest earned on invested balances of cash, cash equivalents and investments. Interest income varies depending on our average investment balances during the period, types and mix of investments, and market interest rates. Other expense—net consisted primarily of foreign exchange and related hedging gains and losses. The increase in other income (expense)—net in the three months ended June 30, 2017 as compared to the same period last year was the result of foreign currency exchange gains in the three months ended June 30, 2017, compared to foreign currency exchange losses in the three months ended June 30, 2016.

[0001262039-17-000027:mdna:83]
Provision for (benefit from) income taxes

[0001262039-17-000027:mdna:84]
|  | Three Months Ended |  | Change |  | % Change |
| June 30, 2017 |  | June 30, 2016 |  |
| (in thousands, except percentages) |
| Provision for (benefit from) income taxes | $ | 9,873 |  |  | $ | (2,302 | ) |  | $ | 12,175 |  |  | * |
| Effective tax rate (%) | 30 | % |  | 62 | % |  | (32 | )% |  | — |

[0001262039-17-000027:mdna:85]
* not meaningful

[0001262039-17-000027:mdna:86]
Our effective tax rate was 30% in the three months ended June 30, 2017, compared to an effective tax rate of 62% in the same period last year. The effective tax rates in the periods presented are comprised of U.S. federal and state taxes, excess tax benefits from stock-based compensation, withholding taxes and foreign income taxes. The tax rate in the three months ended June 30, 2017 and 2016 were impacted by excess tax benefits of $4.1 million and $2.6 million, respectively, from stock-based compensation. Our effective tax rates fluctuate based on the amount of pre-tax income or loss. The impact of discrete items, such as the excess tax benefits from stock-based compensation, on our effective tax rate is greater when our pre-tax income is lower.

[0001262039-17-000027:mdna:87]
Six Months Ended June 30, 2017 and June 30, 2016

[0001262039-17-000027:mdna:88]
Revenue

[0001262039-17-000027:mdna:89]
|  | Six Months Ended |  |  |  |  |
| June 30, 2017 |  | June 30, 2016 |  |  |  |  |
| Amount |  | % ofRevenue |  | Amount |  | % ofRevenue |  | Change |  | % Change |
| (in thousands, except percentages) |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 277,958 |  |  | 39 | % |  | $ | 261,213 |  |  | 44 | % |  | $ | 16,745 |  |  | 6 | % |
| Service | 426,087 |  |  | 61 |  |  | 334,754 |  |  | 56 |  |  | 91,333 |  |  | 27 |  |
| Total revenue | $ | 704,045 |  |  | 100 | % |  | $ | 595,967 |  |  | 100 | % |  | $ | 108,078 |  |  | 18 | % |
| Revenue by geography: |  |  |  |  |  |  |  |  |  |  |  |
| Americas | $ | 307,076 |  |  | 44 | % |  | $ | 252,692 |  |  | 42 | % |  | $ | 54,384 |  |  | 22 | % |
| Europe, Middle East and Africa | 255,879 |  |  | 36 |  |  | 219,944 |  |  | 37 |  |  | 35,935 |  |  | 16 |  |
| Asia Pacific | 141,090 |  |  | 20 |  |  | 123,331 |  |  | 21 |  |  | 17,759 |  |  | 14 |  |
| Total revenue | $ | 704,045 |  |  | 100 | % |  | $ | 595,967 |  |  | 100 | % |  | $ | 108,078 |  |  | 18 | % |

[0001262039-17-000027:mdna:90]
Total revenue increased by $108.1 million, or 18%, in the six months ended June 30, 2017 compared to the same period last year. All three regions experienced revenue growth compared to the same period last year, with the Americas contributing the largest portion of our revenue growth on both an absolute dollar and a percentage basis. Product revenue increased by $16.7 million, or 6%, in the six months ended June 30, 2017 compared to the same period last year. The increase in product revenue was primarily driven by greater sales in our FortiGate product family, as well as growth in other product lines.

[0001262039-17-000027:mdna:91]
Service revenue increased by $91.3 million, or 27%, in the six months ended June 30, 2017 compared to the same period last year due to the recognition of revenue from our growing deferred revenue balance consisting of FortiGuard security subscription and FortiCare technical support contracts sold to a larger customer base, particularly our large enterprise customers, as well as the renewals of similar contracts sold in earlier periods. Service revenue also increased due to the recognition of revenue from our growing deferred revenue balance, consisting of FortiGuard security subscription and FortiCare technical support contracts sold to a larger customer base, as well as the renewals of similar contracts sold in earlier periods. We continued to see the shift from product revenue to higher-margin, recurring service revenue, which reflected our success in driving sales of subscription bundles.

[0001262039-17-000027:mdna:92]
Cost of revenue and gross margin

[0001262039-17-000027:mdna:93]
|  | Six Months Ended |  |  |  |  |
| June 30, 2017 |  | June 30, 2016 |  | Change |  | % Change |
| (in thousands, except percentages) |
| Cost of revenue: |  |  |  |  |  |  |  |
| Product | $ | 116,084 |  |  | $ | 102,101 |  |  | $ | 13,983 |  |  | 14 | % |
| Service | 70,132 |  |  | 60,046 |  |  | 10,086 |  |  | 17 |  |
| Total cost of revenue | $ | 186,216 |  |  | $ | 162,147 |  |  | $ | 24,069 |  |  | 15 | % |
| Gross margin (%): |  |  |  |  |  |  |  |
| Product | 58.2 | % |  | 60.9 | % |  | (2.7 | )% |  |  |
| Service | 83.5 |  |  | 82.1 |  |  | 1.4 |  |  |  |
| Total gross margin | 73.6 | % |  | 72.8 | % |  | 0.8 | % |  |  |

[0001262039-17-000027:mdna:94]
Total gross margin increased by 0.8 percentage points in the six months ended June 30, 2017 compared to the same period last year driven by higher margin on service revenue. Service gross margin increased by 1.4 percentage points in the six

[0001262039-17-000027:mdna:95]
30

[0001262039-17-000027:mdna:96]
months ended June 30, 2017 as compared to the same period last year, resulting from an increased mix of higher-margin subscription bundles. Total cost of service revenue was comprised primarily of personnel costs.

[0001262039-17-000027:mdna:97]
Product gross margin decreased by 2.7 percentage points in the six months ended June 30, 2017 compared to the same period last year. The decrease in product gross margin was primarily due to higher inventory reserves as we transition to newer appliances and other charges.

[0001262039-17-000027:mdna:98]
Operating expenses

[0001262039-17-000027:mdna:99]
|  | Six Months Ended |  | Change |  | % Change |
| June 30, 2017 |  | June 30, 2016 |  |
| Amount |  | % ofRevenue |  | Amount |  | % ofRevenue |  |
| (in thousands, except percentages) |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | $ | 102,354 |  |  | 15 | % |  | $ | 90,256 |  |  | 15 | % |  | $ | 12,098 |  |  | 13 | % |
| Sales and marketing | 336,737 |  |  | 48 |  |  | 308,797 |  |  | 52 |  |  | 27,940 |  |  | 9 |  |
| General and administrative | 44,488 |  |  | 6 |  |  | 41,623 |  |  | 7 |  |  | 2,865 |  |  | 7 |  |
| Restructuring charges | 340 |  |  | — |  |  | 881 |  |  | — |  |  | (541 | ) |  | (61 | ) |
| Total operating expenses | $ | 483,919 |  |  | 69 | % |  | $ | 441,557 |  |  | 74 | % |  | $ | 42,362 |  |  | 10 | % |

[0001262039-17-000027:mdna:100]
Research and development

[0001262039-17-000027:mdna:101]
Research and development expense increased by $12.1 million, or 13%, in the six months ended June 30, 2017 compared to the same period last year primarily due to an increase of $8.7 million in personnel costs as a result of increased headcount to support the development of new products and continued enhancements of our existing products. In addition, depreciation expense and other occupancy-related costs increased by $1.6 million and product development costs, such as third-party testing and prototypes, increased by $1.6 million.

[0001262039-17-000027:mdna:102]
Sales and marketing

[0001262039-17-000027:mdna:103]
Sales and marketing expense increased by $27.9 million, or 9%, in the six months ended June 30, 2017 compared to the same period last year, primarily due to an increase of $23.9 million in personnel costs. In addition, depreciation expense and other occupancy-related expense increased by $4.0 million. In addition, amortization expense increased by $2.1 million related to intangible assets acquired from AccelOps, Inc. (“AccelOps”). These increases were partially offset by lower marketing-related expense of $2.3 million. As a percentage of total revenue, sales and marketing expense decreased as revenue grew at a higher pace compared to personnel costs. The decrease in personnel costs as a percentage of total revenue resulted from lower sales commissions, slower hiring and attrition.

[0001262039-17-000027:mdna:104]
General and administrative

[0001262039-17-000027:mdna:105]
General and administrative expense increased by $2.9 million, or 7%, in the six months ended June 30, 2017 compared to the same period last year, primarily due to an increase of $4.2 million in personnel costs as we continued to increase headcount.  In addition, other professional fees increased by $6.5 million, which included expense of $2.7 million due to third-party costs related to implementing the new revenue recognition standard. Litigation settlement costs increased by $1.6 million. These increases were partially offset by lower third-party costs of $9.3 million primarily related to the substantial completion of our new ERP system implementation. As a percentage of total revenue, general and administrative costs decreased to 6% in the six months ended June 30, 2017 from 7% in the same period last year.

[0001262039-17-000027:mdna:106]
Operating margin

[0001262039-17-000027:mdna:107]
We generated operating income of $33.9 million in the six months ended June 30, 2017, an increase of $41.6 million, compared to operating loss of $7.7 million in the six months ended June 30, 2016, respectively. The improvement in operating margin is primarily due to the decline in sales and marketing and general and administrative expenses as a percentage of total revenue. As a percentage of total revenue, sales and marketing expenses decreased to 48% in the six months ended June 30,

[0001262039-17-000027:mdna:108]
2017 from 52% in the same period last year. As a percentage of total revenue, general and administrative costs decreased to 6% in the six months ended June 30, 2017 from 7% in the same period last year. Significant changes in operating expenses are discussed above.

[0001262039-17-000027:mdna:109]
Interest income and other expense—net

[0001262039-17-000027:mdna:110]
|  | Six Months Ended |  |  |  |  |
| June 30, 2017 |  | June 30, 2016 |  | Change |  | % Change |
| (in thousands, except percentages) |
| Interest income | $ | 5,555 |  |  | $ | 3,451 |  |  | $ | 2,104 |  |  | 61 | % |
| Other expense—net | 1,545 |  |  | (2,662 | ) |  | 4,207 |  |  | (158 | ) |

[0001262039-17-000027:mdna:111]
Interest income increased by $2.1 million, or 61%, in the six months ended June 30, 2017 compared to the same period last year due to higher interest earned on invested balances of cash, cash equivalents and investments. Interest income varies depending on our average investment balances during the period, types and mix of investments, and market interest rates. Other expense—net consisted primarily of foreign exchange and related hedging gains and losses. The increase in other expense—net in the six months ended June 30, 2017 when compared to the same period last year was the result of foreign currency exchange gains in the six months ended June 30, 2017, compared to foreign currency exchange losses in the six months ended June 30, 2016.

[0001262039-17-000027:mdna:112]
Provision for (benefit from) income taxes

[0001262039-17-000027:mdna:113]
|  | Six Months Ended |  | Change |  | % Change |
| June 30, 2017 |  | June 30, 2016 |  |
| (in thousands, except percentages) |
| Provision for (benefit from) income taxes | $ | 7,260 |  |  | $ | (7,678 | ) |  | $ | 14,938 |  |  | * |
| Effective tax rate (%) | 18 | % |  | 111 | % |  | * |  |  | * |

[0001262039-17-000027:mdna:114]
* not meaningful

[0001262039-17-000027:mdna:115]
Our effective tax rate was 18% in the six months ended June 30, 2017, compared with an effective tax rate of 111% in the same period last year. The effective tax rates in the periods presented are comprised of U.S. federal and state taxes, excess tax benefits from stock-based compensation, withholding taxes and foreign income taxes. The tax rate in the six months ended June 30, 2017 and 2016 were impacted by excess tax benefits of $9.6 million and $6.2 million, respectively, from stock-based compensation.

[0001262039-17-000027:mdna:116]
[same as prior period, unchanged from 0001262039-17-000017:mdna:88]

[0001262039-17-000027:mdna:117]
|  | As of |
|  | June 30, 2017 |  | December 31, 2016 |
|  | (in thousands) |
| Cash and cash equivalents | $ | 853,137 |  |  | $ | 709,003 |  |
| Investments | 611,809 |  |  | 601,505 |  |
| Total cash, cash equivalents and investments | $ | 1,464,946 |  |  | $ | 1,310,508 |  |
| Working capital | $ | 719,115 |  |  | $ | 709,276 |  |
|  | Six Months Ended |
|  | June 30, 2017 |  | June 30, 2016 |
|  | (in thousands) |
| Cash provided by operating activities | $ | 274,520 |  |  | $ | 168,532 |  |
| Cash used in investing activities | (113,169 | ) |  | (69,417 | ) |
| Cash used in financing activities | (17,217 | ) |  | (46,012 | ) |
| Net increase in cash and cash equivalents | $ | 144,134 |  |  | $ | 53,103 |  |

[0001262039-17-000027:mdna:118]
Liquidity and capital resources may be impacted by our operating activities, as well as by our stock repurchases, business acquisitions, real estate and other capital expenditures, proceeds associated with stock option exercises and issuances of common stock under our employee stock purchase plan (the “ESPP”) and the payment of taxes in connection with the net settlement of equity awards. In recent years we have received significant capital resources as a result of increases in our deferred revenue and the exercise of stock options. We expect proceeds from the issuance of stock options in future years to be impacted by the increased mix of restricted stock units (“RSUs”) granted versus stock options and also to vary based on our share price. As of June 30, 2017, $156.0 million remained available for future share repurchase under our 2016 Repurchase Program. In July 2017, our Board of Directors authorized a $300.0 million increase to the 2016 Repurchase Program, bringing the amount authorized to $600.0 million through January 31, 2019. We expect to repurchase a total of at least $150.0 million worth of stock in 2017, including the $33.2 million that we repurchased in the second quarter of 2017.

[0001262039-17-000027:mdna:119]
In April 2017, we purchased real estate in Burnaby, Canada for $84.8 million. For the remainder of 2017, we currently expect our capital expenditures to revert to lower levels and our free cash flows to continue to increase in the second half of 2017. The total capital expenditures for real estate purchases in 2017 is currently expected to be $120 million, including the $84.8 million we spent on the purchase of the two buildings in Burnaby, Canada. We currently expect to spend $60.0 million annually in both 2018 and 2019 to build out our headquarters in Sunnyvale, California, but the specific timing of these expenditures is yet to be determined.

[0001262039-17-000027:mdna:120]
As of June 30, 2017, our cash, cash equivalents and investments of $1.46 billion were invested primarily in corporate debt securities, commercial paper, term deposits, U.S. government and agency securities, municipal bonds and money market funds. It is our investment policy to invest excess cash in a manner that preserves capital, provides liquidity and maximizes return without significantly increasing risk.

[0001262039-17-000027:mdna:121]
As of June 30, 2017, $671.9 million of our cash and investments were held by our international subsidiaries and are therefore not immediately available to fund domestic operations unless the cash is repatriated. While we do not intend to do so, should this amount be repatriated, most of it would be subject to U.S. federal income tax that would be partially offset by foreign tax credits. We do not enter into investments for trading or speculative purposes.

[0001262039-17-000027:mdna:122]
We believe that our existing cash and cash equivalents will be sufficient to meet our anticipated cash needs for at least the next 12 months. Our future capital requirements will depend on many factors, including our growth rate, the timing and extent of spending to support development efforts, the expansion of sales and marketing activities, the introduction of new and enhanced products and services offerings, the costs to ensure access to adequate manufacturing capacity, the continuing market acceptance of our products and our investments in real estate through purchases or long-term leases. Historically, we have required capital principally to fund our working capital needs, capital expenditures, share repurchases and acquisition activities. In the event that additional financing is required from outside sources, we may not be able to raise it on terms acceptable to us

[0001262039-17-000027:mdna:123]
or at all. If we are unable to raise additional capital when desired, our business, operating results and financial condition would be adversely affected.

[0001262039-17-000027:mdna:124]
[same as prior period, unchanged from 0001262039-17-000017:mdna:94]

[0001262039-17-000027:mdna:125]
Cash generated by operating activities is our primary source of liquidity. It is primarily comprised of net income, as adjusted for non-cash items, and changes in operating assets and liabilities, including deferred revenue. Non-cash adjustments consist primarily of stock-based compensation, depreciation of property and equipment and amortization of intangible assets.

[0001262039-17-000027:mdna:126]
Our operating activities during the six months ended June 30, 2017 provided $274.5 million in cash as a result of our continued growth in the sales of FortiGuard security subscriptions and FortiCare support contracts, as well as product sales, and the ability to successfully manage our working capital. The increase in sales of our FortiGuard security subscription and FortiCare technical supports to new and existing customers was reflected in the increase in our deferred revenue. We continued to see the shift from product revenue to higher-margin, recurring service revenue.

[0001262039-17-000027:mdna:127]
Our operating activities during the six months ended June 30, 2016 provided $168.5 million in cash as a result of our continued growth in billings and our ability to successfully manage our working capital. Changes in operating assets and liabilities primarily resulted from an increase in deferred revenue, which was partially offset by an increase in payments to vendors.

[0001262039-17-000027:mdna:128]
[same as prior period, unchanged from 0001262039-17-000017:mdna:98]

[0001262039-17-000027:mdna:129]
The changes in cash flows from investing activities primarily relate to timing of purchases, maturities and sales of investments and purchases of property and equipment. Historically, in making a lease versus purchase decision related to our larger facilities, we have considered various factors including financial metrics and the impact on our employees. In certain cases, we have elected to purchase the facility if we believe that purchasing rather than leasing is more in line with our long-term strategy. We expect to make similar decisions in the future.

[0001262039-17-000027:mdna:130]
During the six months ended June 30, 2017, cash used in investing activities was primarily due to the $99.9 million we spent on capital expenditures, including the purchase of $84.8 million in real estate in Burnaby, Canada. Cash outflows due to purchases of investments, net of sales and maturities, amounted to $13.3 million.

[0001262039-17-000027:mdna:131]
During the six months ended June 30, 2016, cash used in investing activities was primarily due to the $44.4 million we spent on capital expenditures, including our purchase of a warehouse in Union City, California for total cash of $18.5 million, and a $20.7 million payment for the acquisition of AccelOps. Cash outflows due to purchases of investments, net of sales and maturities, amounted to $4.4 million.

[0001262039-17-000027:mdna:132]
[same as prior period, unchanged from 0001262039-17-000017:mdna:102]

[0001262039-17-000027:mdna:133]
The changes in cash flows from financing activities primarily relate to proceeds from the issuance of common stock under our equity incentive plan and the ESPP, taxes paid related to net share settlement of equity awards, excess tax benefit from stock-based compensation and repurchase of common stock.

[0001262039-17-000027:mdna:134]
During the six months ended June 30, 2017, cash used in financing activities was $17.2 million, primarily due to $33.2 million used to repurchase our common stock. This was partially offset by $15.9 million proceeds from the issuance of common stock, net of tax withholding.

[0001262039-17-000027:mdna:135]
During the six months ended June 30, 2016, cash used in financing activities was $46.0 million, primarily due to $50.0 million used to repurchase our common stock. This was partially offset by $5.6 million of proceeds from the issuance of common stock, net of taxes paid, related to withholding upon issuance of equity awards.

[0001262039-17-000027:mdna:136]
[same as prior period, unchanged from 0001262039-17-000017:mdna:106]

[0001262039-17-000027:mdna:137]
There were no material changes outside the ordinary course of business during the six months ended June 30, 2017 to the contractual obligations and commitments disclosed in Management’s Discussion and Analysis of Financial Condition and Results of Operations, set forth in Part II, Item 7, of the Form 10-K. See Note 9 to the notes to the condensed consolidated

[0001262039-17-000027:mdna:138]
financial statements included in Part I, Item 1 of this Quarterly Report on Form 10-Q for additional information regarding contractual obligations and commitments.

[0001262039-17-000027:mdna:139]
[same as prior period, unchanged from 0001262039-17-000017:mdna:108]

[0001262039-17-000027:mdna:140]
As of June 30, 2017, we did not have any relationships with unconsolidated organizations or financial partnerships, such as structured finance or special purpose entities that would have been established for the purpose of facilitating off-balance sheet arrangements or other contractually narrow or limited purposes.
