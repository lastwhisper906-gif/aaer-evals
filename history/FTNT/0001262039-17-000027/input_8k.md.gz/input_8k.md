# FTNT 8-K — 0001262039-17-000025 filed 2017-07-26

## item codes, every 8-K on or before 2017-08-02

- 2017-07-26 0001262039-17-000025 — 2.02, 9.01
- 2017-06-27 0001262039-17-000023 — 5.07
- 2017-05-31 0001262039-17-000021 — 5.02 — amendment of 0001262039-17-000019
- 2017-05-30 0001262039-17-000019 — 5.02, 9.01
- 2017-04-27 0001262039-17-000013 — 2.02, 9.01
- 2017-02-02 0001262039-17-000003 — 2.02, 9.01
- 2016-10-27 0001262039-16-000085 — 2.02, 9.01
- 2016-10-11 0001262039-16-000082 — 2.02, 9.01
- 2016-07-28 0001262039-16-000076 — 2.02, 9.01
- 2016-07-22 0001262039-16-000073 — 8.01, 9.01
- 2016-06-20 0001262039-16-000068 — 5.07
- 2016-06-07 0001193125-16-614788 — 8.01
- 2016-04-26 0001262039-16-000061 — 2.02, 9.01
- 2016-01-28 0001262039-16-000051 — 2.02, 9.01
- 2015-10-27 0001262039-15-000045 — 2.02
- 2015-10-22 0001262039-15-000042 — 5.02 — amendment, the index does not say of what
- 2015-10-22 0001262039-15-000041 — 5.02 — amendment, the index does not say of what
- 2015-10-22 0001262039-15-000039 — 2.02, 9.01
- 2015-09-28 0001262039-15-000034 — 5.02, 9.01
- 2015-09-22 0001262039-15-000031 — 9.01 — amendment of 0001193125-15-248065
- 2015-08-28 0001262039-15-000027 — 3.01, 5.02
- 2015-07-23 0001262039-15-000021 — 5.02
- 2015-07-22 0001262039-15-000019 — 2.02, 9.01
- 2015-07-08 0001193125-15-248065 — 2.01, 8.01, 9.01
- 2015-06-22 0001193125-15-229099 — 5.07
- 2015-06-19 0001193125-15-228428 — 5.02, 9.01
- 2015-04-20 0001262039-15-000014 — 2.02, 9.01
- 2015-01-28 0001262039-15-000005 — 2.02, 9.01
- 2014-10-22 0001262039-14-000036 — 2.02, 9.01
- 2014-07-23 0001262039-14-000030 — 2.02, 9.01
- 2014-06-24 0001262039-14-000027 — 5.07
- 2014-04-23 0001262039-14-000021 — 2.02, 9.01
- 2014-04-21 0001262039-14-000018 — 5.03, 9.01
- 2014-01-29 0001262039-14-000004 — 2.02, 9.01
- 2013-12-20 0001262039-13-000061 — 5.02, 9.01
- 2013-11-27 0001262039-13-000057 — 5.02, 7.01, 9.01
- 2013-11-12 0001445305-13-002993 — 5.02
- 2013-10-23 0001262039-13-000051 — 2.02, 9.01
- 2013-07-30 0001262039-13-000039 — 2.02, 9.01
- 2013-06-25 0001262039-13-000030 — 5.07
- 2013-04-30 0001262039-13-000023 — 2.02, 9.01
- 2013-04-19 0001262039-13-000020 — 5.02, 9.01
- 2013-04-19 0001262039-13-000018 — 5.02 — amendment of 0001262039-13-000020
- 2013-04-10 0001262039-13-000016 — 2.02, 9.01
- 2013-03-26 0001262039-13-000013 — 5.02
- 2013-01-30 0001262039-13-000005 — 2.02, 9.01
- 2013-01-24 0001262039-13-000002 — 5.02, 9.01
- 2012-10-16 0001262039-12-000048 — 2.02, 9.01
- 2012-10-01 0001262039-12-000045 — 5.02
- 2012-09-26 0001262039-12-000043 — 5.01
- 2012-07-25 0001262039-12-000038 — 2.02, 9.01
- 2012-07-19 0001262039-12-000034 — 5.02
- 2012-06-20 0001193125-12-275869 — 5.07
- 2012-04-27 0001262039-12-000029 — 5.02
- 2012-04-24 0001262039-12-000025 — 2.02, 9.01
- 2012-01-31 0001262039-12-000006 — 2.02, 9.01
- 2012-01-25 0001262039-12-000003 — 5.03
- 2011-10-24 0001262039-11-000036 — 2.02
- 2011-07-19 0001262039-11-000014 — 2.02, 9.01
- 2011-06-27 0001193125-11-174474 — 5.02, 5.07, 9.01
- 2011-04-27 0001193125-11-111938 — 2.02, 9.01
- 2011-01-25 0001193125-11-013914 — 2.02, 9.01
- 2010-10-21 0001193125-10-233676 — 2.02, 9.01
- 2010-09-02 0001193125-10-203099 — 8.01
- 2010-07-22 0001193125-10-163844 — 2.02, 9.01
- 2010-06-24 0001193125-10-146082 — 5.07
- 2010-04-28 0001193125-10-096698 — 2.02, 9.01
- 2010-02-09 0001193125-10-024614 — 8.01
- 2010-01-27 0001193125-10-014292 — 2.02, 9.01
- 2010-01-26 0001193125-10-013031 — 5.02, 9.01

## late-filing notifications on or before 2017-08-02

- none on or before 2017-08-02

## item 2.02 — earnings release, exhibit 99.1

[0001262039-17-000025:8k_2_02:1]
EX-99.1
2
ftntq2-2017ex991.htm
PRESS RELEASE

[0001262039-17-000025:8k_2_02:2]
Exhibit

[0001262039-17-000025:8k_2_02:3]
Press Release

[0001262039-17-000025:8k_2_02:4]
| Investor Contact: |  | Media Contact: |
| Kelly Blough |  | Sandra Wheatley |
| Fortinet, Inc. |  | Fortinet, Inc. |
| 408-235-7700 x 81612 |  | 408-391-9408 |
| kblough@fortinet.com |  | swheatley@fortinet.com |

[0001262039-17-000025:8k_2_02:5]
Fortinet Reports Second Quarter 2017 Financial Results

[0001262039-17-000025:8k_2_02:6]
Revenue and Billings Growth Continue to Surpass Market While Operating Margins Expand

[0001262039-17-000025:8k_2_02:7]
Second Quarter 2017 Highlights

[0001262039-17-000025:8k_2_02:8]
•Revenue of $363.5 million, up 17% year over year

[0001262039-17-000025:8k_2_02:9]
•Billings of $426.9 million, up 14% year over year1

[0001262039-17-000025:8k_2_02:10]
•GAAP diluted net income per share of $0.13

[0001262039-17-000025:8k_2_02:11]
•Non-GAAP diluted net income per share of $0.271

[0001262039-17-000025:8k_2_02:12]
•GAAP operating margin of 8%

[0001262039-17-000025:8k_2_02:13]
•Non-GAAP operating margin of 18%1

[0001262039-17-000025:8k_2_02:14]
•Cash flow from operations of $144.8 million

[0001262039-17-000025:8k_2_02:15]
•Free cash flow of $58.4 million1

[0001262039-17-000025:8k_2_02:16]
•Cash, cash equivalents and investments of $1.46 billion

[0001262039-17-000025:8k_2_02:17]
•Deferred revenue of $1.16 billion, up 28% year over year

[0001262039-17-000025:8k_2_02:18]
•$33.2 million in share repurchases

[0001262039-17-000025:8k_2_02:19]
SUNNYVALE, Calif. — July 26, 2017—Fortinet® (NASDAQ: FTNT), a global leader in high performance cyber security solutions, today announced financial results for the second quarter ended June 30, 2017.

[0001262039-17-000025:8k_2_02:20]
“Fortinet continues to exceed market growth rates, while delivering well against our margin improvement goals,” said Ken Xie, Chairman and Chief Executive Officer. “The strength of the Fortinet Security Fabric positions us well to provide industry-leading protection for our customers against the aggressive threats that they face now and in the future wherever their assets and data are deployed: on premise or in the cloud.”

[0001262039-17-000025:8k_2_02:21]
In other highlights, Fortinet was recognized as a Leader in the July 2017 Gartner Magic Quadrant for Enterprise Networks Firewalls, and retained its status as a Leader in the June 2017 Magic Quadrant for Unified Threat Management (SMB Multifunction Firewalls). IDC again named Fortinet the unit market share leader for security appliances shipped.

[0001262039-17-000025:8k_2_02:22]
[Note: Gartner does not endorse any vendor, product or service depicted in its research publications, and does not advise technology users to select only those vendors with the highest ratings or other designation. Gartner research publications consist of the opinions of Gartner's research organization and should not be construed as statements of fact. Gartner disclaims all warranties, expressed or implied, with respect to this research, including any warranties of merchantability or fitness for a particular purpose. Gartner Peer Insights reviews constitute the subjective opinions of individual end-users based on their own experiences, and do not represent the views of Gartner or its affiliates.]

[0001262039-17-000025:8k_2_02:23]
Financial Details

[0001262039-17-000025:8k_2_02:24]
| • | Revenue: Total revenue was $363.5 million for the second quarter of 2017, an increase of 17% compared to $311.4 million in the same quarter of 2016. |

[0001262039-17-000025:8k_2_02:25]
| • | Product revenue was $142.7 million, an increase of 4% compared to $136.6 million in the same quarter of 2016. Service revenue was $220.8 million, an increase of 26% compared to $174.8 million in the same quarter of 2016. |

[0001262039-17-000025:8k_2_02:26]
| • | Billings1: Total billings were $426.9 million for the second quarter of 2017, an increase of 14% compared to $373.8 million in the same quarter of 2016. |

[0001262039-17-000025:8k_2_02:27]
| • | Deferred Revenue: Total deferred revenue was $1.16 billion as of June 30, 2017, compared to $904.0 million as of June 30, 2016, and $1.10 billion as of March 31, 2017. Short-term deferred revenue was $706.7 million as of June 30, 2017, compared to $563.2 million as of June 30, 2016. Long-term deferred revenue was $454.8 million as of June 30, 2017, compared to $340.8 million as of June 30, 2016. |

[0001262039-17-000025:8k_2_02:28]
| • | Cash and Cash Flow: As of June 30, 2017, cash, cash equivalents and investments were $1.46 billion, compared to $1.44 billion as of March 31, 2017. In the second quarter of 2017, cash flow from operations was $144.8 million compared to $67.9 million in the same quarter of 2016. Free cash flow1 was $58.4 million during the second quarter of 2017 compared to $53.5 million in the same quarter of 2016, an increase of 9%. There was an $84.8 million impact on free cash flow during the second quarter of 2017 from the purchase of two office buildings in the Vancouver area. |

[0001262039-17-000025:8k_2_02:29]
| • | Share Repurchase: During the second quarter of 2017, Fortinet repurchased 0.8 million shares of its common stock for a total purchase price of $33.2 million. Additionally, Fortinet’s Board of Directors has authorized a $300.0 million increase to its existing share repurchase program, bringing the amount authorized under the current program to $600.0 million, of which $456.0 million remains for share repurchases through the end of January 2019. |

[0001262039-17-000025:8k_2_02:30]
| • | GAAP Operating Income or Loss: GAAP operating income was $28.5 million for the second quarter of 2017, representing a GAAP operating margin of 8%. GAAP operating loss was $4.0 million for the same quarter of 2016, representing a GAAP operating margin of -1%. |

[0001262039-17-000025:8k_2_02:31]
| • | Non-GAAP Operating Income1: Non-GAAP operating income was $65.7 million for the second quarter of 2017, representing a non-GAAP operating margin of 18%. Non-GAAP operating income was $36.0 million for the same quarter of 2016, representing a non-GAAP operating margin of 12%. |

[0001262039-17-000025:8k_2_02:32]
| • | GAAP Net Income or Loss and Diluted Net Income or Loss Per Share: GAAP net income was $23.0 million for the second quarter of 2017, compared to GAAP net loss of $1.4 million for the same quarter of 2016. GAAP diluted net income per share was $0.13 for the second quarter of 2017, compared to GAAP diluted net loss per share of $0.01 for the same quarter of 2016. |

[0001262039-17-000025:8k_2_02:33]
| • | Non-GAAP Net Income and Diluted Net Income Per Share1: Non-GAAP net income was $47.7 million for the second quarter of 2017, compared to non-GAAP net income of $24.0 million for the same quarter of 2016. Non-GAAP diluted net income per share was $0.27 for the second quarter of 2017, compared to $0.14 for the same quarter of 2016. |

[0001262039-17-000025:8k_2_02:34]
Guidance

[0001262039-17-000025:8k_2_02:35]
Fortinet offered the following guidance for the third quarter of 2017:

[0001262039-17-000025:8k_2_02:36]
| • | Billings in the range of $417.0 million to $427.0 million |

[0001262039-17-000025:8k_2_02:37]
| • | Revenue in the range of $367.0 million to $373.0 million |

[0001262039-17-000025:8k_2_02:38]
| • | Non-GAAP gross margin in the range of 75% |

[0001262039-17-000025:8k_2_02:39]
| • | Non-GAAP operating margin in the range of 16% to 17% |

[0001262039-17-000025:8k_2_02:40]
| • | Non-GAAP earnings per share of $0.22 to $0.23 |

[0001262039-17-000025:8k_2_02:41]
Fortinet also offered the following update to its guidance for the full year 2017:

[0001262039-17-000025:8k_2_02:42]
| • | Billings in the range of $1.775 billion to $1.795 billion |

[0001262039-17-000025:8k_2_02:43]
| • | Revenue in the range of $1.487 billion to $1.495 billion |

[0001262039-17-000025:8k_2_02:44]
| • | Non-GAAP gross margin of 74.5% to 75% |

[0001262039-17-000025:8k_2_02:45]
| • | Non-GAAP operating margin of 16.2% |

[0001262039-17-000025:8k_2_02:46]
| • | Non-GAAP earnings per share of $0.94-$0.96 |

[0001262039-17-000025:8k_2_02:47]
1 A reconciliation of GAAP to non-GAAP measures has been provided in the financial statement tables included in this press release. An explanation of these measures is also included below under the heading “Non-GAAP Financial Measures.”

[0001262039-17-000025:8k_2_02:48]
Conference Call Details

[0001262039-17-000025:8k_2_02:49]
Fortinet will host a conference call today, July 26, 2017, at 1:30 p.m. Pacific Time (4:30 p.m. Eastern Time) to discuss its financial results. To access this call, dial (877) 303-6913 (domestic) or (224) 357-2188 (international) with conference ID #47812648. A live webcast of the conference call and supplemental slides will be accessible from the Investor Relations page of Fortinet's website at http://investor.fortinet.com and a replay will be archived and accessible at http://investor.fortinet.com/events.cfm. A replay of this conference call can also be accessed through August 2, 2017, by dialing (855) 859-2056 (domestic) or (404) 537-3406 (international) with conference ID# 47812648.

[0001262039-17-000025:8k_2_02:50]
Following Fortinet's financial results conference call, the Company will host an additional question-and-answer session at 3:30 p.m. Pacific Time (6:30 p.m. Eastern Time) to provide an opportunity for financial analysts and investors to ask more detailed questions. To access this call, dial (877) 303-6913 (domestic) or (224) 357-2188 (international) with conference ID # 47812844. This follow-up call will be webcast live and accessible at http://investor.fortinet.com. A replay will be archived and available after the call at http://investor.fortinet.com/events.cfm. A replay of this conference call will also be available through August 2, 2017 by dialing (855) 859-2056 (domestic) or (404) 537-3406 (international) with conference ID # 47812844.

[0001262039-17-000025:8k_2_02:51]
About Fortinet (www.fortinet.com)

[0001262039-17-000025:8k_2_02:52]
Fortinet (NASDAQ: FTNT) secures the largest enterprise, service provider and government organizations around the world. Fortinet empowers its customers with intelligent, seamless protection across the expanding attack surface and the power to take on ever-increasing performance requirements of the borderless network -- today and into the future. Only the Fortinet Security Fabric architecture can deliver security without compromise to address the most critical security challenges, whether in networked, application, cloud or mobile environments. More than 320,000 customers worldwide trust Fortinet to protect their businesses. Learn more at http://www.fortinet.com, the Fortinet Blog, or FortiGuard Labs.

[0001262039-17-000025:8k_2_02:53]
#          #          #

[0001262039-17-000025:8k_2_02:54]
Copyright © 2017 Fortinet, Inc. All rights reserved. The symbols ® and ™ denote respectively federally registered trademarks and unregistered trademarks of Fortinet, Inc., its subsidiaries and affiliates. Fortinet's trademarks include, but are not limited to, the following: Fortinet, FortiGate, FortiGuard, FortiManager, FortiMail, FortiClient, FortiCloud, FortiCare, FortiAnalyzer, FortiReporter, FortiOS, FortiASIC, FortiWiFi, FortiSwitch, FortiVoIP, FortiBIOS, FortiLog, FortiResponse, FortiCarrier, FortiSIEM, FortiAP, FortiDB, FortiVoice, FortiWeb and FortiCASB. Other trademarks belong to their respective owners.

[0001262039-17-000025:8k_2_02:55]
FTNT-F

[0001262039-17-000025:8k_2_02:56]
Forward-looking Statements

[0001262039-17-000025:8k_2_02:57]
Non-GAAP Financial Measures

[0001262039-17-000025:8k_2_02:58]
We have provided in this release financial information that has not been prepared in accordance with Generally Accepted Accounting Principles (GAAP). These non-GAAP financial and liquidity measures are not based on any standardized methodology prescribed by GAAP and are not necessarily comparable to similar measures presented by other companies. We use these non-GAAP financial measures internally in analyzing our financial results and believe they are useful to investors, as a supplement to GAAP measures, in evaluating our ongoing operational performance. We believe that the use of these non-GAAP financial measures provides an additional tool for investors to use in evaluating ongoing operating results and trends and in comparing our financial results with peer companies, many of which present similar non-GAAP financial measures to investors.

[0001262039-17-000025:8k_2_02:59]
Non-GAAP financial measures should not be considered in isolation from, or as a substitute for, financial information prepared in accordance with GAAP. Investors are encouraged to review the reconciliation of these non-GAAP financial measures to their most directly comparable GAAP financial measures provided in the financial statement tables below.

[0001262039-17-000025:8k_2_02:60]
Billings (Non-GAAP). We define billings as revenue recognized in accordance with GAAP plus the change in deferred revenue from the beginning to the end of the period less any deferred revenue balances acquired from business combination(s) during the period. We consider billings to be a useful metric for management and investors because billings drive future revenue, which is an important indicator of the health and viability of our business. There are a number of limitations related to the use of billings instead of GAAP revenue. First, billings include amounts that have not yet been recognized as revenue and are impacted by the term of security and support agreements. Second, we may calculate billings in a manner that is different from peer companies that report similar financial measures. Management accounts for these limitations by providing specific information regarding GAAP revenue and evaluating billings together with GAAP revenue.

[0001262039-17-000025:8k_2_02:61]
Free cash flow (Non-GAAP). We define free cash flow as net cash provided by operating activities minus capital expenditures such as purchases of real estate and other property and equipment. We believe free cash flow to be a liquidity measure that provides useful information to management and investors about the amount of cash generated by the business that, after capital expenditures, can be used for strategic opportunities, including investing in our business, making strategic acquisitions, repurchasing outstanding common stock, and strengthening the balance sheet. However, free cash flow is not intended to represent our residual cash flow available for discretionary expenditures, since we may have other non-discretionary expenditures that are not deducted from the measure. A limitation of using free cash flow rather than the GAAP measure of net cash provided by operating activities is that free cash flow does not represent the total increase or decrease in the cash, cash equivalents and investments balance for the period because it excludes cash provided by or used for other investing and financing activities. Management accounts for this limitation by providing information about our capital expenditures and other investing and financing activities on the face of the cash flow statement and under the caption “Management’s Discussion and Analysis of Financial Condition and Results of Operations - Liquidity and Capital Resources” in our most recent Quarterly Report on Form 10-Q and Annual Report on Form 10-K and by presenting cash flows from investing and financing activities in our reconciliation of free cash flows. In addition, it is important to note that other companies, including companies in our industry, may not use free cash flow, may calculate free cash flow in a different manner than we do or may use other financial measure to evaluate their performance, all of which could reduce the usefulness of free cash flows as a comparative measure.

[0001262039-17-000025:8k_2_02:62]
Non-GAAP operating income and operating margin. We define non-GAAP operating income as operating income or loss plus stock-based compensation, business acquisition-related charges, purchase accounting adjustments, impairment and amortization of acquired intangible assets, restructuring charges, expenses associated with the implementation of a new Enterprise Resource Planning (ERP) system, litigation settlement expenses and, when applicable, other significant non-recurring items in a given quarter. Non-GAAP operating margin is defined as non-GAAP operating income divided by GAAP revenue. We consider these non-GAAP financial measures to be useful metrics for management and investors because they exclude the items noted above so that our management and investors can compare our recurring core business operating results over multiple periods. There are a number of limitations related to the use of non-GAAP operating income instead of operating income or loss calculated in accordance with GAAP. First, non-GAAP operating income excludes the items noted above. Second, the components of the costs that we exclude from our calculation of non-GAAP operating income may differ from the components that peer companies exclude when they report their non-GAAP results of operations. Management accounts for these limitations by providing specific information regarding the GAAP amounts excluded from non-GAAP operating income and evaluating non-GAAP operating income together with operating income calculated in accordance with GAAP.

[0001262039-17-000025:8k_2_02:63]
Non-GAAP net income and diluted net income per share. We define non-GAAP net income as net income plus the items noted above under non-GAAP operating income and operating margin, including a tax adjustment to achieve our effective tax rate on a non-GAAP basis, which often differs from the GAAP effective tax rate. We define non-GAAP diluted net income per share as non-GAAP net income divided by the non-GAAP diluted weighted-average shares outstanding. We consider these non-GAAP financial measures to be useful metrics for management and investors for the same reasons that we use non-GAAP operating income and non-GAAP operating margin. However, in order to provide a more complete picture of our recurring core business operating results, we include in non-GAAP net income and non-GAAP diluted net income per share, the tax adjustment required resulting in an effective tax rate on a non-GAAP basis, which often differs from the GAAP tax rate. We believe the non-GAAP effective tax rates we use are reasonable estimates of normalized tax rates for our current and prior fiscal years under our global operating structure. The same limitations described above regarding our use of non-GAAP operating income and non-GAAP operating margin apply to our use of non-GAAP net income and non-GAAP diluted net income per share. We account for these limitations by providing specific information regarding the GAAP amounts excluded from non-GAAP net income and non-GAAP diluted net income per share and evaluating non-GAAP net income and non-GAAP diluted net income per share together with net income and diluted net income per share calculated in accordance with GAAP.

[0001262039-17-000025:8k_2_02:64]
FORTINET, INC.

[0001262039-17-000025:8k_2_02:65]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001262039-17-000025:8k_2_02:66]
(Unaudited, in thousands)

[0001262039-17-000025:8k_2_02:67]
|  | June 30, 2017 |  | December 31, 2016 |
| ASSETS |  |  |  |
| CURRENT ASSETS: |  |  |  |
| Cash and cash equivalents | $ | 853,137 |  |  | $ | 709,003 |  |
| Short-term investments | 354,187 |  |  | 376,522 |  |
| Accounts receivable—net | 274,476 |  |  | 312,998 |  |
| Inventory | 86,439 |  |  | 106,887 |  |
| Prepaid expenses and other current assets | 36,395 |  |  | 33,306 |  |
| Total current assets | 1,604,634 |  |  | 1,538,716 |  |
| LONG-TERM INVESTMENTS | 257,622 |  |  | 224,983 |  |
| DEFERRED TAX ASSETS | 207,029 |  |  | 182,745 |  |
| PROPERTY AND EQUIPMENT—NET | 238,513 |  |  | 137,249 |  |
| OTHER INTANGIBLE ASSETS—NET | 20,328 |  |  | 24,828 |  |
| GOODWILL | 14,553 |  |  | 14,553 |  |
| OTHER ASSETS | 18,012 |  |  | 16,867 |  |
| TOTAL ASSETS | $ | 2,360,691 |  |  | $ | 2,139,941 |  |
| LIABILITIES AND STOCKHOLDERS' EQUITY |  |  |  |
| CURRENT LIABILITIES: |  |  |  |
| Accounts payable | $ | 42,171 |  |  | $ | 56,732 |  |
| Accrued liabilities | 41,185 |  |  | 35,640 |  |
| Accrued payroll and compensation | 80,307 |  |  | 78,138 |  |
| Income taxes payable | 15,184 |  |  | 13,588 |  |
| Deferred revenue | 706,672 |  |  | 645,342 |  |
| Total current liabilities | 885,519 |  |  | 829,440 |  |
| DEFERRED REVENUE | 454,799 |  |  | 390,007 |  |
| INCOME TAX LIABILITIES | 81,718 |  |  | 68,551 |  |
| OTHER LIABILITIES | 16,516 |  |  | 14,262 |  |
| Total liabilities | 1,438,552 |  |  | 1,302,260 |  |
| STOCKHOLDERS' EQUITY: |  |  |  |
| Common stock | 175 |  |  | 173 |  |
| Additional paid-in capital | 880,142 |  |  | 800,653 |  |
| Accumulated other comprehensive loss | (523 | ) |  | (765 | ) |
| Retained earnings | 42,345 |  |  | 37,620 |  |
| Total stockholders’ equity | 922,139 |  |  | 837,681 |  |
| TOTAL LIABILITIES AND STOCKHOLDERS’ EQUITY | $ | 2,360,691 |  |  | $ | 2,139,941 |  |

[0001262039-17-000025:8k_2_02:68]
FORTINET, INC.

[0001262039-17-000025:8k_2_02:69]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001262039-17-000025:8k_2_02:70]
(Unaudited, in thousands, except per share amounts)

[0001262039-17-000025:8k_2_02:71]
|  | Three Months Ended |  | Six Months Ended |
|  | June 30, 2017 |  | June 30, 2016 |  | June 30, 2017 |  | June 30, 2016 |
| REVENUE: |  |  |  |  |  |  |  |
| Product | $ | 142,705 |  |  | $ | 136,641 |  |  | $ | 277,958 |  |  | $ | 261,213 |  |
| Service | 220,764 |  |  | 174,750 |  |  | 426,087 |  |  | 334,754 |  |
| Total revenue | 363,469 |  |  | 311,391 |  |  | 704,045 |  |  | 595,967 |  |
| COST OF REVENUE: |  |  |  |  |  |  |  |
| Product 1 | 60,787 |  |  | 52,788 |  |  | 116,084 |  |  | 102,101 |  |
| Service 1 | 34,865 |  |  | 31,715 |  |  | 70,132 |  |  | 60,046 |  |
| Total cost of revenue | 95,652 |  |  | 84,503 |  |  | 186,216 |  |  | 162,147 |  |
| GROSS PROFIT: |  |  |  |  |  |  |  |
| Product | 81,918 |  |  | 83,853 |  |  | 161,874 |  |  | 159,112 |  |
| Service | 185,899 |  |  | 143,035 |  |  | 355,955 |  |  | 274,708 |  |
| Total gross profit | 267,817 |  |  | 226,888 |  |  | 517,829 |  |  | 433,820 |  |
| OPERATING EXPENSES: |  |  |  |  |  |  |  |
| Research and development 1 | 51,159 |  |  | 45,502 |  |  | 102,354 |  |  | 90,256 |  |
| Sales and marketing 1 | 166,337 |  |  | 162,694 |  |  | 336,737 |  |  | 308,797 |  |
| General and administrative 1 | 21,911 |  |  | 22,184 |  |  | 44,488 |  |  | 41,623 |  |
| Restructuring charges | (90 | ) |  | 553 |  |  | 340 |  |  | 881 |  |
| Total operating expenses | 239,317 |  |  | 230,933 |  |  | 483,919 |  |  | 441,557 |  |
| OPERATING INCOME (LOSS) | 28,500 |  |  | (4,045 | ) |  | 33,910 |  |  | (7,737 | ) |
| INTEREST INCOME | 3,163 |  |  | 1,705 |  |  | 5,555 |  |  | 3,451 |  |
| OTHER INCOME (EXPENSE)—NET | 1,243 |  |  | (1,350 | ) |  | 1,545 |  |  | (2,662 | ) |
| INCOME (LOSS) BEFORE INCOME TAXES | 32,906 |  |  | (3,690 | ) |  | 41,010 |  |  | (6,948 | ) |
| PROVISION FOR (BENEFIT FROM) INCOME TAXES | 9,873 |  |  | (2,302 | ) |  | 7,260 |  |  | (7,678 | ) |
| NET INCOME (LOSS) | $ | 23,033 |  |  | $ | (1,388 | ) |  | $ | 33,750 |  |  | $ | 730 |  |
| Net income (loss) per share: |  |  |  |  |  |  |  |
| Basic | $ | 0.13 |  |  | $ | (0.01 | ) |  | $ | 0.19 |  |  | $ | — |  |
| Diluted | $ | 0.13 |  |  | $ | (0.01 | ) |  | $ | 0.19 |  |  | $ | — |  |
| Weighted-average shares outstanding: |  |  |  |  |  |  |  |
| Basic | 175,741 |  |  | 172,075 |  |  | 175,118 |  |  | 171,910 |  |
| Diluted | 179,701 |  |  | 172,075 |  |  | 178,993 |  |  | 175,360 |  |
| 1 Includes stock-based compensation as follows: |  |  |  |  |  |  |  |
| Cost of product revenue | $ | 383 |  |  | $ | 298 |  |  | $ | 725 |  |  | $ | 578 |  |
| Cost of service revenue | 2,473 |  |  | 2,123 |  |  | 4,783 |  |  | 4,257 |  |
| Research and development | 8,253 |  |  | 7,458 |  |  | 16,151 |  |  | 14,601 |  |
| Sales and marketing | 19,745 |  |  | 16,990 |  |  | 38,771 |  |  | 32,805 |  |
| General and administrative | 4,237 |  |  | 3,478 |  |  | 7,992 |  |  | 7,008 |  |
|  | $ | 35,091 |  |  | $ | 30,347 |  |  | $ | 68,422 |  |  | $ | 59,249 |  |

[0001262039-17-000025:8k_2_02:72]
FORTINET, INC.

[0001262039-17-000025:8k_2_02:73]
CONDENSED CONSOLIDATED STATEMENTS OF COMPREHENSIVE INCOME (LOSS)

[0001262039-17-000025:8k_2_02:74]
(Unaudited, in thousands)

[0001262039-17-000025:8k_2_02:75]
|  | Three Months Ended |  | Six Months Ended |
|  | June 30, 2017 |  | June 30, 2016 |  | June 30, 2017 |  | June 30, 2016 |
| Net income (loss) | $ | 23,033 |  |  | $ | (1,388 | ) |  | $ | 33,750 |  |  | $ | 730 |  |
| Other comprehensive income: |  |  |  |  |  |  |  |
| Change in unrealized gains (losses) on investments | (91 | ) |  | 662 |  |  | 334 |  |  | 2,549 |  |
| Tax provision (benefit) related to change in unrealized gains (losses) on investments | (57 | ) |  | 232 |  |  | 92 |  |  | 892 |  |
| Other comprehensive income (loss) | (34 | ) |  | 430 |  |  | 242 |  |  | 1,657 |  |
| Comprehensive income (loss) | $ | 22,999 |  |  | $ | (958 | ) |  | $ | 33,992 |  |  | $ | 2,387 |  |

[0001262039-17-000025:8k_2_02:76]
FORTINET, INC.

[0001262039-17-000025:8k_2_02:77]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001262039-17-000025:8k_2_02:78]
(Unaudited, in thousands)

[0001262039-17-000025:8k_2_02:79]
|  | Six Months Ended |
|  | June 30, 2017 |  | June 30, 2016 |
| CASH FLOWS FROM OPERATING ACTIVITIES: |  |  |  |
| Net income | $ | 33,750 |  |  | $ | 730 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |
| Depreciation and amortization | 27,492 |  |  | 21,841 |  |
| Amortization of investment premiums | 1,447 |  |  | 2,794 |  |
| Stock-based compensation | 68,422 |  |  | 59,249 |  |
| Other non-cash items—net | 1,705 |  |  | 1,192 |  |
| Changes in operating assets and liabilities: |  |  |  |
| Accounts receivable—net | 37,902 |  |  | 2,022 |  |
| Inventory | 9,752 |  |  | (8,019 | ) |
| Deferred tax assets | (24,376 | ) |  | (27,120 | ) |
| Prepaid expenses and other current assets | (3,223 | ) |  | 2,442 |  |
| Other assets | 722 |  |  | (2,409 | ) |
| Accounts payable | (19,880 | ) |  | (130 | ) |
| Accrued liabilities | 1,755 |  |  | (6,426 | ) |
| Accrued payroll and compensation | 1,565 |  |  | 8,679 |  |
| Other liabilities | (2,677 | ) |  | (2,858 | ) |
| Deferred revenue | 125,402 |  |  | 111,082 |  |
| Income taxes payable | 14,762 |  |  | 5,463 |  |
| Net cash provided by operating activities | 274,520 |  |  | 168,532 |  |
| CASH FLOWS FROM INVESTING ACTIVITIES: |  |  |  |
| Purchases of investments | (270,463 | ) |  | (230,855 | ) |
| Sales of investments | 9,995 |  |  | 7,366 |  |
| Maturities of investments | 247,187 |  |  | 219,131 |  |
| Purchases of property and equipment | (99,888 | ) |  | (44,399 | ) |
| Payments made in connection with business acquisition, net of cash acquired | — |  |  | (20,660 | ) |
| Net cash used in investing activities | (113,169 | ) |  | (69,417 | ) |
| CASH FLOWS FROM FINANCING ACTIVITIES: |  |  |  |
| Proceeds from issuance of common stock | 41,832 |  |  | 22,972 |  |
| Taxes paid related to net share settlement of equity awards | (25,895 | ) |  | (17,358 | ) |
| Repurchase and retirement of common stock | (33,154 | ) |  | (50,000 | ) |
| Payments of debt assumed in connection with business acquisition | — |  |  | (1,626 | ) |
| Net cash used in financing activities | (17,217 | ) |  | (46,012 | ) |
| NET INCREASE IN CASH AND CASH EQUIVALENTS | 144,134 |  |  | 53,103 |  |
| CASH AND CASH EQUIVALENTS—Beginning of period | 709,003 |  |  | 543,277 |  |
| CASH AND CASH EQUIVALENTS—End of period | $ | 853,137 |  |  | $ | 596,380 |  |

[0001262039-17-000025:8k_2_02:80]
Reconciliations of non-GAAP results of operations measures to the nearest comparable GAAP measures

[0001262039-17-000025:8k_2_02:81]
(Unaudited, in thousands, except per share amounts)

[0001262039-17-000025:8k_2_02:82]
Reconciliation of net cash provided by operating activities to free cash flow

[0001262039-17-000025:8k_2_02:83]
|  | Three Months Ended |
|  | June 30, 2017 |  | June 30, 2016 |
| Net cash provided by operating activities | $ | 144,771 |  |  | $ | 67,941 |  |
| Less purchases of property and equipment | (86,362 | ) |  | (14,443 | ) |
| Free cash flow | $ | 58,409 |  |  | $ | 53,498 |  |
| Net cash used in investing activities | $ | (81,844 | ) |  | $ | (35,213 | ) |
| Net cash used in financing activities | $ | (33,039 | ) |  | $ | (4,356 | ) |

[0001262039-17-000025:8k_2_02:84]
Reconciliation of GAAP operating income or loss to Non-GAAP operating income, operating margin, net income and diluted net income per share

[0001262039-17-000025:8k_2_02:85]
|  | Three Months Ended June 30, 2017 |  | Three Months Ended June 30, 2016 |
|  | GAAP Results |  | Adjustments |  | Non-GAAP Results |  | GAAP Results |  | Adjustments |  | Non-GAAP Results |
| Operating income (loss) | $ | 28,500 |  |  | $ | 37,208 |  | (a) | $ | 65,708 |  |  | $ | (4,045 | ) |  | $ | 40,016 |  | (b) | $ | 35,971 |  |
| Operating margin | 8 | % |  |  |  | 18 | % |  | -1 | % |  |  |  | 12 | % |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | 35,091 |  |  |  |  |  |  | 30,347 |  |  |  |
| Amortization of acquired intangible assets |  |  | 2,207 |  |  |  |  |  |  | 2,269 |  |  |  |
| Restructuring charges |  |  | (90 | ) |  |  |  |  |  | 553 |  |  |  |
| ERP-related expenses |  |  | — |  |  |  |  |  |  | 6,316 |  |  |  |
| Acquisition-related charges |  |  | — |  |  |  |  |  |  | 254 |  |  |  |
| Inventory fair value adjustment amortization |  |  | — |  |  |  |  |  |  | 277 |  |  |  |
| Tax adjustment |  |  | (12,563 | ) | (c) |  |  |  |  | (14,653 | ) | (c) |  |
| Net income (loss) | $ | 23,033 |  |  | $ | 24,645 |  |  | $ | 47,678 |  |  | $ | (1,388 | ) |  | $ | 25,363 |  |  | $ | 23,975 |  |
| Diluted net income (loss) per share | $ | 0.13 |  |  |  |  | $ | 0.27 |  |  | $ | (0.01 | ) |  |  |  | $ | 0.14 |  |
| Shares used in diluted net income (loss) per share calculations | 179,701 |  |  |  |  | 179,701 |  |  | 172,075 |  |  |  |  | 176,298 |  |

[0001262039-17-000025:8k_2_02:86]
(a) To exclude $35.1 million of stock-based compensation, $2.2 million of amortization of acquired intangible assets, and $(0.1) million of restructuring charges in the three months ended June 30, 2017.

[0001262039-17-000025:8k_2_02:87]
(b) To exclude $30.3 million of stock-based compensation, $2.3 million of amortization of acquired intangible assets, $0.6 million of restructuring charges, $6.3 million of ERP-related expenses, $0.3 million of acquisition-related charges, and $0.3 million of inventory fair value adjustment amortization recorded pursuant to our business acquisition in the three months ended June 30, 2016.

[0001262039-17-000025:8k_2_02:88]
(c)  Non-GAAP financial information is adjusted to achieve an overall 32% percent and 33% percent effective tax rate in 2017 and 2016, respectively, on a non-GAAP basis, which differs from the GAAP effective tax rate.

[0001262039-17-000025:8k_2_02:89]
Reconciliation of diluted weighted average shares outstanding used in the calculation of GAAP and non-GAAP earnings per share

[0001262039-17-000025:8k_2_02:90]
|  |  | Three Months Ended |
|  |  | June 30, 2017 |  | June 30, 2016 |
| Shares used in diluted net income (loss) per share calculations - GAAP |  | 179,701 |  |  | 172,075 |  |
| Adjustment for diluted weighted average shares outstanding | (a) | — |  |  | 4,223 |  |
| Shares used in diluted net income per share calculations - Non-GAAP |  | 179,701 |  |  | 176,298 |  |

[0001262039-17-000025:8k_2_02:91]
(a) GAAP diluted weighted average shares outstanding differs from non-GAAP diluted weighted average shares outstanding in periods when we have a GAAP net loss and a non-GAAP net income. The adjustment for diluted weighted average shares outstanding represents the dilutive effect of employee equity incentive plan awards and is calculated by applying the treasury stock method.

[0001262039-17-000025:8k_2_02:92]
Billings Reconciliation

[0001262039-17-000025:8k_2_02:93]
|  | Three Months Ended |
|  | June 30, 2017 |  | June 30, 2016 |
| Total revenue | $ | 363,469 |  |  | $ | 311,391 |  |
| Add change in deferred revenue | 63,420 |  |  | 66,793 |  |
| Less deferred revenue balance acquired in business acquisition | — |  |  | (4,400 | ) |
| Total billings | $ | 426,889 |  |  | $ | 373,784 |  |
