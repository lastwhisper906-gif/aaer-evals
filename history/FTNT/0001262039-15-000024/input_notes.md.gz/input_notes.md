# FTNT notes — 0001262039-15-000024


## ftnt:IncomeTaxBenefitFromStockOptionPlansTableTextBlock

[0001262039-15-000024:notes:1]
[same as prior period, unchanged from 0001262039-15-000016:notes:1]

[0001262039-15-000024:notes:2]
|  | Three Months Ended |  | Six Months Ended |
|  | June 30, 2015 |  | June 30, 2014 |  | June 30, 2015 |  | June 30, 2014 |
| Income tax benefit associated with stock-based compensation | $ | 4,266 |  |  | $ | 4,247 |  |  | $ | 7,643 |  |  | $ | 7,813 |  |


## ftnt:PresentationAndPreparationOfConsolidatedFinancialStatementsPolicyTextBlock

[0001262039-15-000024:notes:3]
Basis of Presentation and Preparation—The unaudited condensed consolidated financial statements of Fortinet, Inc. and its wholly-owned subsidiaries (collectively, “we,” “us” or “our”) have been prepared in accordance with generally accepted accounting principles in the United States (“GAAP”) for interim financial information as well as the instructions to Form 10-Q pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (“SEC”). Accordingly, they do not include all of the information and footnotes required by GAAP for complete financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the year ended December 31, 2014, contained in our Annual Report on Form 10-K (“Form 10-K”) filed with the SEC on March 2, 2015. In the opinion of management, all adjustments, which includes normal recurring adjustments, considered necessary for a fair presentation have been included. All intercompany balances, transactions and cash flows have been eliminated. The results of operations for the three and six months ended June 30, 2015 are not necessarily indicative of the results for the full year or for any future periods. The condensed consolidated balance sheet as of December 31, 2014 is derived from the audited consolidated financial statements for the year ended December 31, 2014.


## ftnt:ScheduleOfAmortizedCostsUnrealizedGainsAndLossesAndFairValueOfAvailableForSaleSecuritiesTableTextBlock

[0001262039-15-000024:notes:4]
The following table summarizes our investments as of June 30, 2015 and December 31, 2014 (in thousands):

[0001262039-15-000024:notes:5]
|  | June 30, 2015 |
|  | AmortizedCost |  | UnrealizedGains |  | UnrealizedLosses |  | FairValue |
| Corporate debt securities | $ | 551,352 |  |  | $ | 187 |  |  | $ | (635 | ) |  | $ | 550,904 |  |
| Commercial paper | 46,639 |  |  | 2 |  |  | (4 | ) |  | 46,637 |  |
| Municipal bonds | 58,705 |  |  | 21 |  |  | (50 | ) |  | 58,676 |  |
| Certificates of deposit and term deposits (1) | 7,760 |  |  | — |  |  | — |  |  | 7,760 |  |
| U.S. government and agency securities | 2,999 |  |  | 2 |  |  | — |  |  | 3,001 |  |
| Total available-for-sale securities | $ | 667,455 |  |  | $ | 212 |  |  | $ | (689 | ) |  | $ | 666,978 |  |

[0001262039-15-000024:notes:6]
[same as prior period, unchanged from 0001262039-15-000016:notes:6]

[0001262039-15-000024:notes:7]
[same as prior period, unchanged from 0001262039-15-000016:notes:7]


## ftnt:ScheduleOfShareBasedPaymentAwardStockOptionsValuationAssumptionsAndAllocationOfRecognizedPeriodCostsTableTextBlock

[0001262039-15-000024:notes:8]
[same as prior period, unchanged from 0001262039-15-000016:notes:8]

[0001262039-15-000024:notes:9]
|  | Three Months Ended |  | Six Months Ended |
|  | June 30, 2015 |  | June 30, 2014 |  | June 30, 2015 |  | June 30, 2014 |
| Expected term in years | 4.3 |  |  | 4.9 |  |  | 4.3 |  |  | 4.9 |  |
| Volatility | 38 | % |  | 43 | % |  | 38% - 40% |  |  | 43% - 45% |  |
| Risk-free interest rate | 1.5 | % |  | 1.7 | % |  | 1.5 | % |  | 1.7 | % |
| Dividend rate | — | % |  | — | % |  | — | % |  | — | % |


## ftnt:ScheduleofEmployeeServiceSharebasedCompensationAllocationofRecognizedPeriodCostsbyAwardTypeTableTextBlock

[0001262039-15-000024:notes:10]
[same as prior period, unchanged from 0001262039-15-000016:notes:10]

[0001262039-15-000024:notes:11]
|  | Three Months Ended |  | Six Months Ended |
|  | June 30, 2015 |  | June 30, 2014 |  | June 30, 2015 |  | June 30, 2014 |
| Stock options | $ | 3,017 |  |  | $ | 4,421 |  |  | $ | 6,472 |  |  | $ | 9,113 |  |
| RSUs (including PSUs) | 17,386 |  |  | 9,248 |  |  | 31,678 |  |  | 16,611 |  |
| ESPP | 1,357 |  |  | 1,047 |  |  | 2,532 |  |  | 1,922 |  |
| Total stock-based compensation expense | $ | 21,760 |  |  | $ | 14,716 |  |  | $ | 40,682 |  |  | $ | 27,646 |  |


## ftnt:ScheduleofReceivablesbyMajorCustomersTableTextBlock

[0001262039-15-000024:notes:12]
[same as prior period, unchanged from 0001262039-15-000016:notes:12]

[0001262039-15-000024:notes:13]
|  | June 30, 2015 |  | December 31, 2014 |
| Exclusive Networks Group | 20 | % |  | 18 | % |
| Fine Tec Computer | 13 | % |  | — | % |


## ftnt:ScheduleofSharebasedCompensationSharesWithheldforTaxesTableTextBlock

[0001262039-15-000024:notes:14]
[same as prior period, unchanged from 0001262039-15-000016:notes:14]

[0001262039-15-000024:notes:15]
|  | Three Months Ended |  | Six Months Ended |
|  | June 30, 2015 |  | June 30, 2014 |  | June 30, 2015 |  | June 30, 2014 |
| Shares withheld for taxes | 124 |  |  | 86 |  |  | 345 |  |  | 257 |  |
| Amount withheld for taxes | $ | 4,762 |  |  | $ | 1,888 |  |  | $ | 11,362 |  |  | $ | 5,521 |  |


## ftnt:ScheduleofSharebasedPaymentAwardEmployeeStockPurchasePlanAdditionalInformationTableTextBlock

[0001262039-15-000024:notes:16]
[same as prior period, unchanged from 0001262039-15-000016:notes:16]

[0001262039-15-000024:notes:17]
|  | Six Months Ended |
|  | June 30, 2015 |  | June 30, 2014 |
| Weighted-average fair value per share granted | $ | 7.56 |  |  | $ | 5.35 |  |
| Shares issued under the ESPP | 427 |  |  | 424 |  |
| Weighted-average price per share issued | $ | 21.34 |  |  | $ | 17.18 |  |


## ftnt:ScheduleofSharebasedPaymentAwardEquityInstrumentsOtherthanOptionsValuationAssumptionsTableTextBlock

[0001262039-15-000024:notes:18]
[same as prior period, unchanged from 0001262039-15-000016:notes:18]

[0001262039-15-000024:notes:19]
|  | Three Months Ended |  | Six Months Ended |
|  | June 30, 2014 |  | June 30, 2015 |  | June 30, 2014 |
| Expected term in years | 3.0 |  |  | 3.0 |  |  | 3.0 |  |
| Volatility | 46 | % |  | 38 | % |  | 47 | % |
| Risk-free interest rate | 0.9 | % |  | 1.1 | % |  | 0.9 | % |
| Dividend rate | — | % |  | — | % |  | — | % |


## ftnt:ScheduleofSharebasedPaymentAwardStockOptionsAdditionalInformationTableTextBlock

[0001262039-15-000024:notes:20]
[same as prior period, unchanged from 0001262039-15-000016:notes:20]

[0001262039-15-000024:notes:21]
|  | Three Months Ended |  | Six Months Ended |
|  | June 30, 2015 |  | June 30, 2014 |  | June 30, 2015 |  | June 30, 2014 |
| Weighted-average fair value per share granted | $ | 12.75 |  |  | $ | 8.18 |  |  | $ | 11.54 |  |  | $ | 8.58 |  |
| Intrinsic value of options exercised | 22,034 |  |  | 16,441 |  |  | 63,038 |  |  | 31,762 |  |
| Fair value of options vested | 2,718 |  |  | 4,209 |  |  | 6,510 |  |  | 8,771 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001262039-15-000024:notes:22]
COMMITMENTS AND CONTINGENCIES

[0001262039-15-000024:notes:23]
The following table summarizes our future principal contractual obligations as of June 30, 2015 (in thousands):

[0001262039-15-000024:notes:24]
|  | Total |  | 2015 (remainder) |  | 2016 |  | 2017 |  | 2018 |  | 2019 |  | Thereafter |
| Operating lease commitments | $ | 50,093 |  |  | $ | 7,064 |  |  | $ | 12,054 |  |  | $ | 8,536 |  |  | $ | 6,865 |  |  | $ | 5,684 |  |  | $ | 9,890 |  |
| Less: sublease rental income | 57 |  |  | 57 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Operating lease commitments—net | 50,036 |  |  | 7,007 |  |  | 12,054 |  |  | 8,536 |  |  | 6,865 |  |  | 5,684 |  |  | 9,890 |  |
| Inventory purchase commitments | 74,322 |  |  | 74,322 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Other contractual commitments and open purchase orders | 33,944 |  |  | 28,729 |  |  | 3,675 |  |  | 978 |  |  | 305 |  |  | 193 |  |  | 64 |  |
| Total | $ | 158,302 |  |  | $ | 110,058 |  |  | $ | 15,729 |  |  | $ | 9,514 |  |  | $ | 7,170 |  |  | $ | 5,877 |  |  | $ | 9,954 |  |

[0001262039-15-000024:notes:25]
Operating Leases—We lease certain facilities under various non-cancelable operating leases, which expire through 2025. In addition to the amounts above, certain leases require us to pay variable costs such as taxes, maintenance, insurance, and asset retirement obligations. The terms of certain operating leases also provide for renewal options and escalation clauses. Rent expense was $2.9 million and $2.4 million during the three months ended June 30, 2015 and 2014, respectively. Rent expense was $6.0 million and $5.1 million during the six months ended June 30, 2015 and 2014, respectively. Rent expense is recognized using the straight-line method over the term of the lease.

[0001262039-15-000024:notes:26]
Contract Manufacturer and Other Commitments—Our independent contract manufacturers procure components and build our products based on our forecasts. These forecasts are based on estimates of future demand for our products, which are in turn based on historical trends and analysis, adjusted for overall market conditions. In order to reduce manufacturing lead times and plan for adequate component supply, we may issue purchase orders to some of our independent contract manufacturers which may not be cancelable. As of June 30, 2015, we had $74.3 million of open purchase orders with our independent contract manufacturers.

[0001262039-15-000024:notes:27]
In addition to commitments with contract manufacturers, we have other contractual commitments and open purchase orders in the ordinary course of business for which we have not received goods or services. As of June 30, 2015, we had $33.9 million in other contractual commitments and open purchase orders.

[0001262039-15-000024:notes:28]
Warranties—Accrued warranty activities are summarized as follows (in thousands):

[0001262039-15-000024:notes:29]
|  | Six Months Ended |
|  | June 30, 2015 |  | June 30, 2014 |
| Accrued warranty balance—beginning of the period | $ | 4,269 |  |  | $ | 3,037 |  |
| Warranty costs incurred | (2,059 | ) |  | (1,728 | ) |
| Provision for warranty for the period | 2,294 |  |  | 2,560 |  |
| Adjustment related to pre-existing warranties | 171 |  |  | (415 | ) |
| Accrued warranty balance—end of the period | $ | 4,675 |  |  | $ | 3,454 |  |

[0001262039-15-000024:notes:30]
Litigation—We are involved in disputes, litigation, and other legal actions. For lawsuits where we are the defendant, we are in the process of defending these litigation matters, and while there can be no assurances and the outcome of these matters is currently not determinable, we currently believe that there are no existing claims or proceedings that are likely to have a material adverse effect on our financial position. There are many uncertainties associated with any litigation and these actions or other third-party claims against us may cause us to incur costly litigation or substantial settlement charges. In addition, the resolution of any intellectual property litigation may require us to make royalty payments, which could adversely affect our gross margins in future periods. If any of those events were to occur, our business, financial condition, results of operations, and cash flows could be adversely affected. The actual liability in any such matters may be materially different from our estimates, if any, which could result in the need to adjust the liability and record additional expenses. We have not recorded any significant accrual for loss contingencies associated with such legal proceedings; determined that a significant unfavorable outcome is probable or reasonably possible; or determined that the amount or range of any possible loss is reasonably estimable.

[0001262039-15-000024:notes:31]
Indemnification—Under the indemnification provisions of our standard sales contracts, we agree to defend our customers against third-party claims asserting various allegations such as damage resulting from product defects and infringement of certain intellectual property rights, which may include patents, copyrights, trademarks, or trade secrets, and to pay judgments entered on such claims. Our exposure under these indemnification provisions is generally limited by the terms of our contracts to certain defined limits, such as the total amount paid by our customer under the agreement. However, certain agreements include covenants and indemnification provisions including and beyond indemnification for third-party claims of intellectual property infringement and that could potentially expose us to losses in excess of the amount received under the agreement and, in some instances, to potential liability that is not contractually limited. To date, there have been no awards under such indemnification provisions.


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0001262039-15-000024:notes:32]
[same as prior period, unchanged from 0001262039-15-000016:notes:32]

[0001262039-15-000024:notes:33]
Our tax-deferred savings plan under our 401(k) Plan, permits participating employees to defer a portion of their pre-tax earnings. In Canada, we have a Group Registered Retirement Savings Plan program (the “RRSP”) which permits participants to make tax deductible contributions. Our Board approved 50% matching contributions on employee contributions up to 4% of each employee’s eligible earnings. Our matching contributions to the 401(k) Plan and RRSP during the three months ended June 30, 2015 and June 30, 2014 were $0.9 million and $0.6 million, respectively. Our matching contributions to the 401(k) Plan and RRSP during the six months ended June 30, 2015 and June 30, 2014 were $1.8 million and $1.2 million, respectively.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001262039-15-000024:notes:34]
ACCUMULATED OTHER COMPREHENSIVE LOSS

[0001262039-15-000024:notes:35]
The following table summarizes the changes in accumulated balances of other comprehensive loss (in thousands):

[0001262039-15-000024:notes:36]
|  | Unrealized Gains (Losses) on Investments |  | Tax benefit (provision) related to items of other comprehensive income or loss |  | Total |
| Beginning balance as of December 31, 2014 | $ | (540 | ) |  | $ | 191 |  |  | $ | (349 | ) |
| Other comprehensive income before reclassifications | 69 |  |  | (24 | ) |  | 45 |  |
| Amounts reclassified from accumulated other comprehensive loss | (6 | ) |  | 1 |  |  | (5 | ) |
| Net current-period other comprehensive income | 63 |  |  | (23 | ) |  | 40 |  |
| Ending balance as of June 30, 2015 | $ | (477 | ) |  | $ | 168 |  |  | $ | (309 | ) |

[0001262039-15-000024:notes:37]
The following table provides details about the reclassification out of accumulated other comprehensive loss (in thousands):

[0001262039-15-000024:notes:38]
| Six Months Ended June 30, 2015 |
| Details about Accumulated Other Comprehensive Loss Components |  | Amount Reclassified from Accumulated Other Comprehensive Loss |  | Affected Line Item in the Statement Where Net Income is Presented |
| Unrealized gains on investments |  | $ | (6 | ) |  | Other expense—net |
| Tax provision related to items of other comprehensive income |  | 1 |  |  | Provision for income taxes |
| Total reclassification for the period |  | $ | (5 | ) |  |  |


## us-gaap:CostMethodInvestmentsDescriptionTextBlock

[0001262039-15-000024:notes:39]
[same as prior period, unchanged from 0001262039-15-000016:notes:39]

[0001262039-15-000024:notes:40]
As of June 30, 2015, we had invested a total of $10.3 million in the equity securities of three privately-held companies. Each of these investments is accounted for as a cost-basis investment, as we own less than 20% of the voting securities and do not have the ability to exercise significant influence over operating and financial policies of the respective entities. These investments are carried at historical cost and are recorded as Other assets on our condensed consolidated balance sheets and would be measured at fair value if indicators of impairment existed.

[0001262039-15-000024:notes:41]
During the six months ended June 30, 2015, no events have occurred that would adversely affect the carrying value of these investments.


## us-gaap:DeferredRevenueByArrangementDisclosureTextBlock

[0001262039-15-000024:notes:42]
Deferred revenue consisted of the following as of June 30, 2015 and December 31, 2014 (in thousands):

[0001262039-15-000024:notes:43]
|  | June 30, 2015 |  | December 31, 2014 |
| Product | $ | 4,461 |  |  | $ | 4,642 |  |
| Service | 653,100 |  |  | 554,115 |  |
| Total deferred revenue | $ | 657,561 |  |  | $ | 558,757 |  |
| Reported as: |  |  |  |
| Current | $ | 441,177 |  |  | $ | 368,929 |  |
| Non-current | 216,384 |  |  | 189,828 |  |
| Total deferred revenue | $ | 657,561 |  |  | $ | 558,757 |  |


## us-gaap:DeferredRevenueDisclosureTextBlock

[0001262039-15-000024:notes:44]
[same as prior period, unchanged from 0001262039-15-000016:notes:44]


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001262039-15-000024:notes:45]
[same as prior period, unchanged from 0001262039-15-000016:notes:45]

[0001262039-15-000024:notes:46]
Our sales contracts are primarily denominated in U.S. dollars and therefore substantially all of our revenue is not subject to foreign currency translation risk. However, a substantial portion of our operating expenses incurred outside the U.S. are denominated in foreign currencies and are subject to fluctuations due to changes in foreign currency exchange rates, particularly changes in the Canadian dollar (“CAD”), the Euro (“EUR”), and the British Pound (“GBP”). To help protect against significant fluctuations in value and the volatility of future cash flows caused by changes in currency exchange rates, we engage in foreign currency risk management activities, including forward contracts, to hedge balance sheet items denominated in CAD. We do not use these contracts for speculative or trading purposes. All of the derivative instruments are with high quality financial institutions and we monitor the creditworthiness of these parties. These contracts typically have maturities of one month. We record changes in the fair value of forward exchange contracts related to balance sheet accounts as Other expense—net in the condensed consolidated statement of operations.

[0001262039-15-000024:notes:47]
Additionally, independent of any hedging activities, fluctuations in foreign currency exchange rates may cause us to recognize transaction gains and losses in Other expense—net in our condensed consolidated statements of operations. Our hedging activities are intended to reduce, but not eliminate, the impact of currency exchange rate movements. As our hedging activities are relatively short-term in nature and are focused on CAD, long-term material changes in the value of the U.S. dollar against other foreign currencies, such as the EUR and GBP could adversely impact our operating expenses in the future.

[0001262039-15-000024:notes:48]
The notional amount of our forward exchange contract to hedge balance sheet accounts were (in thousands):

[0001262039-15-000024:notes:49]
|  | Buy/Sell |  | Notional |
| Currency—As of June 30, 2015 |  |  |  |
| CAD | Sell |  | $ | 6,743 |  |
| Currency—As of December 31, 2014 |  |  |  |
| CAD | Buy |  | $ | 6,879 |  |

[0001262039-15-000024:notes:50]
As of June 30, 2015, the fair value of the forward exchange contract was not material.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001262039-15-000024:notes:51]
[same as prior period, unchanged from 0001262039-15-000016:notes:50]

[0001262039-15-000024:notes:52]
[same as prior period, unchanged from 0001262039-15-000016:notes:51]

[0001262039-15-000024:notes:53]
We have stock-based compensation plans pursuant to which we have granted stock options and RSUs, including PSUs. The Company also has an ESPP for all eligible employees. As of June 30, 2015, there were a total of 43,655,799 shares of common stock available for grant under our stock-based compensation plans.

[0001262039-15-000024:notes:54]
[same as prior period, unchanged from 0001262039-15-000016:notes:53]

[0001262039-15-000024:notes:55]
[same as prior period, unchanged from 0001262039-15-000016:notes:54]

[0001262039-15-000024:notes:56]
|  | Options Outstanding |
|  | Numberof Shares |  | Weighted-AverageExercisePrice |  | Weighted-AverageRemainingContractualLife (Years) |  | AggregateIntrinsicValue |
| Balance—December 31, 2014 | 10,702 |  |  | $ | 14.98 |  |  |  |  |  |
| Granted | 349 |  |  | 34.15 |  |  |  |  |  |
| Forfeited | (88 | ) |  | 24.70 |  |  |  |  |  |
| Exercised | (2,860 | ) |  | 11.95 |  |  |  |  |  |
| Balance—June 30, 2015 | 8,103 |  |  | $ | 16.78 |  |  |  |  |  |
| Options vested and expected to vest—June 30, 2015 | 8,059 |  |  | $ | 16.70 |  |  | 2.6 |  | $ | 198,516 |  |
| Options exercisable—June 30, 2015 | 6,935 |  |  | $ | 15.03 |  |  | 2.2 |  | $ | 182,363 |  |

[0001262039-15-000024:notes:57]
The aggregate intrinsic value represents the pre-tax difference between the exercise price of stock options and the quoted market price of our common stock on June 30, 2015, for all in-the-money options. As of June 30, 2015, total compensation expense related to unvested stock options granted to employees but not yet recognized was $12.6 million. This expense is expected to be amortized on a straight-line basis over a weighted-average period of 2.0 years.

[0001262039-15-000024:notes:58]
[same as prior period, unchanged from 0001262039-15-000016:notes:57]

[0001262039-15-000024:notes:59]
[same as prior period, unchanged from 0001262039-15-000016:notes:58]

[0001262039-15-000024:notes:60]
|  | Restricted Stock Units Outstanding |
|  | Number of Shares |  | Weighted-Average Grant-Date-Fair Value per Share |
| Balance—December 31, 2014 | 6,291 |  |  | $ | 22.93 |  |
| Granted | 3,149 |  |  | 34.16 |  |
| Forfeited | (413 | ) |  | 26.01 |  |
| Vested | (1,069 | ) |  | 22.01 |  |
| Balance—June 30, 2015 | 7,958 |  |  | $ | 27.62 |  |
| RSUs expected to vest—June 30, 2015 | 7,468 |  |  | $ | 27.41 |  |

[0001262039-15-000024:notes:61]
As of June 30, 2015, total compensation expense related to unvested RSUs that were granted to employees and non-employees, but not yet recognized, was $207.6 million. This expense is expected to be amortized on a straight-line basis over a weighted-average vesting period of 3.0 years.

[0001262039-15-000024:notes:62]
[same as prior period, unchanged from 0001262039-15-000016:notes:61]

[0001262039-15-000024:notes:63]
[same as prior period, unchanged from 0001262039-15-000016:notes:62]

[0001262039-15-000024:notes:64]
We have granted PSUs to certain of our executive officers and employees. PSUs granted to executive officers are based on the achievement of the market-based vesting conditions during the performance period, the final settlement of the PSUs will range between 0% and 150% of the target shares underlying the PSUs based on a specified objective formula approved by our Compensation Committee. The PSUs entitle our executive officers to receive a number of shares of our common stock based on the performance of our stock price over a two- or three-year period as compared to the NASDAQ Composite index for the same periods. PSUs granted to our employees who are not executive officers are based on the achievement of personal- and company-based performance vesting conditions during the performance period. The final settlement of these PSUs will range between 50% to 150% of the target shares underlying the PSUs based on specified objective formula approved by our Compensation Committee. The PSUs entitle such employees to receive a number of shares of our common stock based on a one year performance period, and vest equally in the second and third years. There were no PSUs granted during the three months ended June 30, 2015.

[0001262039-15-000024:notes:65]
[same as prior period, unchanged from 0001262039-15-000016:notes:64]

[0001262039-15-000024:notes:66]
|  | Three Months Ended |  | Six Months Ended |
|  | June 30, 2014 |  | June 30, 2015 |  | June 30, 2014 |
| Shares granted to executive officers and employees | 95 |  |  | 206 |  |  | 120 |  |
| Weighted-average fair value per share granted | $ | 21.05 |  |  | $ | 34.86 |  |  | $ | 21.21 |  |

[0001262039-15-000024:notes:67]
As of June 30, 2015, total compensation expense related to unvested PSUs that were granted to certain of our executive officers and employees, but not yet recognized, was $8.0 million. This expense is expected to be amortized on a straight-line basis over a weighted-average vesting period of 2.3 years.

[0001262039-15-000024:notes:68]
[same as prior period, unchanged from 0001262039-15-000016:notes:67]

[0001262039-15-000024:notes:69]
[same as prior period, unchanged from 0001262039-15-000016:notes:68]

[0001262039-15-000024:notes:70]
|  | Six Months Ended |
|  | June 30, 2015 |  | June 30, 2014 |
| Expected term in years | 0.5 |  |  | 0.5 |  |
| Volatility | 28 | % |  | 36 | % |
| Risk-free interest rate | 0.1 | % |  | 0.1 | % |
| Dividend rate | — | % |  | — | % |

[0001262039-15-000024:notes:71]
There were no shares granted or issued under the ESPP during the three months ended June 30, 2015 and June 30, 2014.

[0001262039-15-000024:notes:72]
[same as prior period, unchanged from 0001262039-15-000016:notes:70]

[0001262039-15-000024:notes:73]
[same as prior period, unchanged from 0001262039-15-000016:notes:71]

[0001262039-15-000024:notes:74]
|  | Three Months Ended |  | Six Months Ended |
|  | June 30, 2015 |  | June 30, 2014 |  | June 30, 2015 |  | June 30, 2014 |
| Cost of product revenue | $ | 210 |  |  | $ | 178 |  |  | $ | 350 |  |  | $ | 291 |  |
| Cost of service revenue | 1,660 |  |  | 1,363 |  |  | 3,292 |  |  | 2,692 |  |
| Research and development | 5,541 |  |  | 4,171 |  |  | 10,698 |  |  | 8,053 |  |
| Sales and marketing | 11,271 |  |  | 5,747 |  |  | 20,578 |  |  | 11,493 |  |
| General and administrative | 3,078 |  |  | 3,257 |  |  | 5,764 |  |  | 5,117 |  |
| Total stock-based compensation expense | $ | 21,760 |  |  | $ | 14,716 |  |  | $ | 40,682 |  |  | $ | 27,646 |  |

[0001262039-15-000024:notes:75]
[same as prior period, unchanged from 0001262039-15-000016:notes:73]

[0001262039-15-000024:notes:76]
In December 2013, our Board of Directors (“Board”) authorized a Share Repurchase Program (“Program”) to repurchase up to $200.0 million of our outstanding common stock through December 31, 2014. Under the Program, share repurchases may be made by us from time to time in privately negotiated transactions or in open market transactions. The Program does not require us to purchase a minimum number of shares, and may be suspended, modified or discontinued at any time without prior notice. In October 2014, our Board extended the share repurchase authorization under the Program through December 31, 2015. During the three and six months ended June 30, 2015, there were no shares repurchased under the Program. As of June 30, 2015, $122.5 million remains available for future share repurchases under the Program.


## us-gaap:EarningsPerShareTextBlock

[0001262039-15-000024:notes:77]
[same as prior period, unchanged from 0001262039-15-000016:notes:75]

[0001262039-15-000024:notes:78]
[same as prior period, unchanged from 0001262039-15-000016:notes:76]

[0001262039-15-000024:notes:79]
[same as prior period, unchanged from 0001262039-15-000016:notes:77]

[0001262039-15-000024:notes:80]
|  | Three Months Ended |  | Six Months Ended |
|  | June 30, 2015 |  | June 30, 2014 |  | June 30, 2015 |  | June 30, 2014 |
| Numerator: |  |  |  |  |  |  |  |
| Net income | $ | 792 |  |  | $ | 6,081 |  |  | $ | 2,352 |  |  | $ | 14,474 |  |
| Denominator: |  |  |  |  |  |  |  |
| Basic shares: |  |  |  |  |  |  |  |
| Weighted-average common stock outstanding—basic | 169,930 |  |  | 163,161 |  |  | 169,009 |  |  | 162,778 |  |
| Diluted shares: |  |  |  |  |  |  |  |
| Weighted-average common stock outstanding—basic | 169,930 |  |  | 163,161 |  |  | 169,009 |  |  | 162,778 |  |
| Effect of potentially dilutive securities: |  |  |  |  |  |  |  |
| Stock options | 3,720 |  |  | 4,583 |  |  | 3,779 |  |  | 4,753 |  |
| RSUs (including PSUs) | 2,521 |  |  | 600 |  |  | 2,131 |  |  | 462 |  |
| ESPP | 63 |  |  | 1 |  |  | 64 |  |  | 22 |  |
| Weighted-average shares used to compute diluted net income per share | 176,234 |  |  | 168,345 |  |  | 174,983 |  |  | 168,015 |  |
| Net income per share: |  |  |  |  |  |  |  |
| Basic | $ | — |  |  | $ | 0.04 |  |  | $ | 0.01 |  |  | $ | 0.09 |  |
| Diluted | $ | — |  |  | $ | 0.04 |  |  | $ | 0.01 |  |  | $ | 0.09 |  |

[0001262039-15-000024:notes:81]
[same as prior period, unchanged from 0001262039-15-000016:notes:79]

[0001262039-15-000024:notes:82]
|  | Three Months Ended |  | Six Months Ended |
|  | June 30, 2015 |  | June 30, 2014 |  | June 30, 2015 |  | June 30, 2014 |
| Stock options | 299 |  |  | 4,201 |  |  | 274 |  |  | 4,323 |  |
| RSUs (including PSUs) | 414 |  |  | 593 |  |  | 873 |  |  | 1,871 |  |
| ESPP | — |  |  | — |  |  | 84 |  |  | 261 |  |
|  | 713 |  |  | 4,794 |  |  | 1,231 |  |  | 6,455 |  |


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0001262039-15-000024:notes:83]
[same as prior period, unchanged from 0001262039-15-000016:notes:81]

[0001262039-15-000024:notes:84]
The following table shows the gross unrealized losses and the related fair values of our investments that have been in a continuous unrealized loss position as of June 30, 2015 and December 31, 2014 (in thousands):

[0001262039-15-000024:notes:85]
|  | June 30, 2015 |
|  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
|  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |
| Corporate debt securities | $ | 283,789 |  |  | $ | (522 | ) |  | $ | 41,362 |  |  | $ | (113 | ) |  | $ | 325,151 |  |  | $ | (635 | ) |
| Commercial paper | 11,769 |  |  | (4 | ) |  | — |  |  | — |  |  | 11,769 |  |  | (4 | ) |
| Municipal bonds | 34,667 |  |  | (46 | ) |  | 1,576 |  |  | (4 | ) |  | 36,243 |  |  | (50 | ) |
| Total available-for-sale securities | $ | 330,225 |  |  | $ | (572 | ) |  | $ | 42,938 |  |  | $ | (117 | ) |  | $ | 373,163 |  |  | $ | (689 | ) |

[0001262039-15-000024:notes:86]
[same as prior period, unchanged from 0001262039-15-000016:notes:84]

[0001262039-15-000024:notes:87]
The contractual maturities of our investments as of June 30, 2015 and December 31, 2014 were as follows (in thousands):

[0001262039-15-000024:notes:88]
|  | June 30, 2015 |  | December 31, 2014 |
| Due within one year | $ | 391,634 |  |  | $ | 436,766 |  |
| Due within one to three years | 275,344 |  |  | 271,724 |  |
| Total | $ | 666,978 |  |  | $ | 708,490 |  |

[0001262039-15-000024:notes:89]
[same as prior period, unchanged from 0001262039-15-000016:notes:87]

[0001262039-15-000024:notes:90]
The unrealized losses on our available-for-sale securities were caused by fluctuations in market value and interest rates as a result of the economic environment. As the decline in market value is attributable to changes in market conditions and not credit quality, and because we have concluded currently that we neither intend to sell nor is it more likely than not that we will be required to sell these investments prior to a recovery of par value, we do not consider these investments to be other-than temporarily impaired as of June 30, 2015.

[0001262039-15-000024:notes:91]
[same as prior period, unchanged from 0001262039-15-000016:notes:89]

[0001262039-15-000024:notes:92]
[same as prior period, unchanged from 0001262039-15-000016:notes:90]

[0001262039-15-000024:notes:93]
[same as prior period, unchanged from 0001262039-15-000016:notes:91]

[0001262039-15-000024:notes:94]
[same as prior period, unchanged from 0001262039-15-000016:notes:92]

[0001262039-15-000024:notes:95]
[same as prior period, unchanged from 0001262039-15-000016:notes:93]

[0001262039-15-000024:notes:96]
[same as prior period, unchanged from 0001262039-15-000016:notes:94]

[0001262039-15-000024:notes:97]
[same as prior period, unchanged from 0001262039-15-000016:notes:95]

[0001262039-15-000024:notes:98]
[same as prior period, unchanged from 0001262039-15-000016:notes:96]

[0001262039-15-000024:notes:99]
Assets Measured at Fair Value on a Recurring Basis

[0001262039-15-000024:notes:100]
The following table presents the fair value of our financial assets measured at fair value on a recurring basis as of June 30, 2015 and December 31, 2014 (in thousands):

[0001262039-15-000024:notes:101]
|  | June 30, 2015 |  | December 31, 2014 |  |
|  | AggregateFairValue |  | QuotedPrices inActiveMarkets ForIdenticalAssets |  | SignificantOtherObservableRemainingInputs |  | AggregateFairValue |  | QuotedPrices inActiveMarkets ForIdenticalAssets |  | SignificantOtherObservableRemainingInputs |  |
|  |  |  | (Level 1) |  | (Level 2) |  |  |  | (Level 1) |  | (Level 2) |  |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate debt securities | $ | 550,904 |  |  | $ | — |  |  | $ | 550,904 |  |  | $ | 589,016 |  |  | $ | — |  |  | $ | 589,016 |  |  |
| Commercial paper | 58,634 |  |  | — |  |  | 58,634 |  |  | 51,155 |  |  | — |  |  | 51,155 |  |  |
| Municipal bonds | 58,676 |  |  | — |  |  | 58,676 |  |  | 39,721 |  |  | — |  |  | 39,721 |  |  |
| Certificates of deposit and term deposits | 7,760 |  |  | — |  |  | 7,760 |  |  | 22,854 |  |  | — |  |  | 22,854 |  |  |
| Money market funds | 31,193 |  |  | 31,193 |  |  | — |  |  | 13,311 |  |  | 13,311 |  |  | — |  |  |
| U.S. government and agency securities | 3,001 |  |  | 2,000 |  |  | 1,001 |  |  | 5,744 |  |  | 1,998 |  |  | 3,746 |  |  |
| Total | $ | 710,168 |  |  | $ | 33,193 |  |  | $ | 676,975 |  |  | $ | 721,801 |  |  | $ | 15,309 |  |  | $ | 706,492 |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents | $ | 43,190 |  |  |  |  |  |  | $ | 13,311 |  |  |  |  |  |  |
| Short-term investments | 391,634 |  |  |  |  |  |  | 436,766 |  |  |  |  |  |  |
| Long-term investments | 275,344 |  |  |  |  |  |  | 271,724 |  |  |  |  |  |  |
| Total | $ | 710,168 |  |  |  |  |  |  | $ | 721,801 |  |  |  |  |  |  |

[0001262039-15-000024:notes:102]
There were no transfers between Level 1 and Level 2 of the fair value hierarchy during the period ended June 30, 2015.


## us-gaap:ForeignCurrencyTransactionsAndTranslationsPolicyTextBlock

[0001262039-15-000024:notes:103]
In the third quarter of 2014, we reevaluated the selected functional currency of our international subsidiaries due to the nature of our business operations and recorded the cumulative impact of the reevaluation of the functional currency in the consolidated statement of operations. Subsequently, the remeasurement of the assets and liabilities of all international subsidiaries has been recorded in the consolidated statement of operations prospectively. The impact of this reevaluation was not material for 2014 or any of our previously issued financial statements.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001262039-15-000024:notes:104]
[same as prior period, unchanged from 0001262039-15-000016:notes:102]

[0001262039-15-000024:notes:105]
The effective tax rate was 77% for the three months ended June 30, 2015, compared to an effective tax rate of 49% for the same period last year.  The effective tax rate was 54% for the six months ended June 30, 2015, compared to an effective tax rate of 44% for the same period last year. The provision for income taxes for the periods presented is comprised of U.S. federal and state taxes, Singapore and other foreign income taxes, withholding tax, and transfer pricing allocations which impact jurisdictional income taxed at various tax rates. During the three and six months ended June 30, 2015, there were additional unrecognized tax benefits and non-deductible stock-based compensation expense that adversely impacted the quarterly effective tax rate.

[0001262039-15-000024:notes:106]
As of June 30, 2015 and December 31, 2014, unrecognized tax benefits were $52.4 million and $44.2 million, respectively. The total amount of $52.2 million in unrecognized tax benefits, if recognized, would favorably impact the effective tax rate. It is our policy to classify accrued interest and penalties related to unrecognized tax benefits in the provision for income taxes. As of June 30, 2015, we had accrued $5.2 million for estimated interest related to uncertain tax positions.

[0001262039-15-000024:notes:107]
[same as prior period, unchanged from 0001262039-15-000016:notes:106]


## us-gaap:InventoryDisclosureTextBlock

[0001262039-15-000024:notes:108]
[same as prior period, unchanged from 0001262039-15-000016:notes:107]

[0001262039-15-000024:notes:109]
Inventory consisted of the following as of June 30, 2015 and December 31, 2014 (in thousands):

[0001262039-15-000024:notes:110]
|  | June 30, 2015 |  | December 31, 2014 |
| Raw materials | $ | 12,235 |  |  | $ | 10,617 |  |
| Finished goods | 56,610 |  |  | 58,860 |  |
| Total inventory | $ | 68,845 |  |  | $ | 69,477 |  |

[0001262039-15-000024:notes:111]
Inventory includes finished goods held by distributors where revenue is recognized on a sell-through basis of $1.2 million as of June 30, 2015 and December 31, 2014. Inventory also includes raw materials at contract manufacturers of $4.2 million and $4.8 million as of June 30, 2015 and December 31, 2014, respectively.


## us-gaap:LongLivedAssetsByGeographicAreasTableTextBlock

[0001262039-15-000024:notes:112]
The following table sets forth property and equipment by geographic region as of June 30, 2015 and December 31, 2014 (in thousands):

[0001262039-15-000024:notes:113]
| Property and Equipment—net | June 30, 2015 |  | December 31, 2014 |
| Americas: |  |  |  |
| United States | $ | 50,328 |  |  | $ | 46,116 |  |
| Canada | 7,902 |  |  | 6,054 |  |
| Other Americas | 764 |  |  | 875 |  |
| Total Americas | 58,994 |  |  | 53,045 |  |
| EMEA | 9,062 |  |  | 3,256 |  |
| APAC | 3,409 |  |  | 2,618 |  |
| Total property and equipment—net | $ | 71,465 |  |  | $ | 58,919 |  |


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001262039-15-000024:notes:114]
Recent Accounting Pronouncements

[0001262039-15-000024:notes:115]
In July 2015, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update 2015-11—Inventory—Simplifying the Measurement of Inventory (Topic 330) (“ASU 2015-11”). ASU 2015-11 changes the measurement principle for inventory from the lower of cost or market to lower of cost and net realizable value. It applies to entities that measure inventory using a method other than last-in, first-out or the retail inventory method (e.g., first-in first-out, average cost). ASU 2015-11 will be effective for us beginning on January 1, 2017. We are currently evaluating the impact of ASU 2015-11 on our consolidated financial statements.

[0001262039-15-000024:notes:116]
In May 2014, the FASB issued Accounting Standards Update No. 2014-09—Revenue from Contracts with Customers (Topic 606) (“ASU 2014-09”) to create a single, joint revenue standard that is consistent across all industries and markets for companies that prepare their financial statements in accordance with GAAP. Under ASU 2014-09, an entity is required to recognize revenue upon the transfer of promised goods or services to customers in an amount that reflects the consideration the entity expects to be entitled to receive in exchange for those goods or services. In July 2015, the FASB decided to delay the effective date of the new revenue standard by one year. As such, ASU 2014-09 will be effective for us beginning on January 1, 2018, with the option to adopt earlier on January 1, 2017. We are currently evaluating the impact of ASU 2014-09 on our consolidated financial statements.


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001262039-15-000024:notes:117]
PROPERTY AND EQUIPMENT—net

[0001262039-15-000024:notes:118]
Property and equipment—net consisted of the following as of June 30, 2015 and December 31, 2014 (in thousands):

[0001262039-15-000024:notes:119]
|  | June 30, 2015 |  | December 31, 2014 |
| Land | $ | 14,943 |  |  | $ | 13,895 |  |
| Building and building improvements | 20,298 |  |  | 20,166 |  |
| Evaluation units | 38,140 |  |  | 31,474 |  |
| Computer equipment and software | 40,616 |  |  | 31,821 |  |
| Furniture and fixtures | 7,160 |  |  | 5,096 |  |
| Construction-in-progress | 7,923 |  |  | 3,902 |  |
| Leasehold improvements | 8,703 |  |  | 7,998 |  |
| Total property and equipment | 137,783 |  |  | 114,352 |  |
| Less: accumulated depreciation | (66,318 | ) |  | (55,433 | ) |
| Property and equipment—net | $ | 71,465 |  |  | $ | 58,919 |  |

[0001262039-15-000024:notes:120]
Depreciation expense was $6.8 million and $6.0 million during the three months ended June 30, 2015 and June 30, 2014, respectively. Depreciation expense was $12.8 million and $9.9 million during the six months ended June 30, 2015 and June 30, 2014, respectively.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001262039-15-000024:notes:121]
RELATED PARTY TRANSACTIONS

[0001262039-15-000024:notes:122]
The son of one member of our Board of Directors (“Board”) is a partner of an outside law firm that we utilize for certain complex litigation matters. Expenses for legal services provided by the law firm related to matters that arose subsequent to the member joining our Board were $0.9 million and $0.5 million for the three months ended June 30, 2015 and June 30, 2014, respectively. Expenses for legal services provided by the law firm related to matters that arose subsequent to the member joining our Board were $2.8 million and $0.7 million for the six months ended June 30, 2015 and June 30, 2014, respectively. Amounts due and payable to the law firm were $2.3 million and $1.3 million as of June 30, 2015 and December 31, 2014, respectively.


## us-gaap:RevenueFromExternalCustomersByGeographicAreasTableTextBlock

[0001262039-15-000024:notes:123]
[same as prior period, unchanged from 0001262039-15-000016:notes:121]

[0001262039-15-000024:notes:124]
|  | Three Months Ended |  | Six Months Ended |
| Revenue | June 30, 2015 |  | June 30, 2014 |  | June 30, 2015 |  | June 30, 2014 |
| Americas: |  |  |  |  |  |  |  |
| United States | $ | 71,224 |  |  | $ | 49,672 |  |  | $ | 129,725 |  |  | $ | 94,465 |  |
| Canada | 26,191 |  |  | 19,909 |  |  | 46,649 |  |  | 38,733 |  |
| Other Americas | 11,178 |  |  | 8,804 |  |  | 23,779 |  |  | 17,619 |  |
| Total Americas | 108,593 |  |  | 78,385 |  |  | 200,153 |  |  | 150,817 |  |
| Europe, Middle East, and Africa (“EMEA”) | 83,404 |  |  | 62,554 |  |  | 159,068 |  |  | 119,197 |  |
| Asia Pacific (“APAC”) | 47,788 |  |  | 43,159 |  |  | 93,450 |  |  | 83,033 |  |
| Total revenue | $ | 239,785 |  |  | $ | 184,098 |  |  | $ | 452,671 |  |  | $ | 353,047 |  |


## us-gaap:ScheduleOfRevenueByMajorCustomersByReportingSegmentsTableTextBlock

[0001262039-15-000024:notes:125]
The following customer, a distributor, accounted for 10% or more of our revenue:

[0001262039-15-000024:notes:126]
|  | Three Months Ended |  | Six Months Ended |
|  | June 30, 2015 |  | June 30, 2014 |  | June 30, 2015 |  | June 30, 2014 |
| Exclusive Networks Group | 17 | % |  | 14 | % |  | 17 | % |  | 14 | % |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001262039-15-000024:notes:127]
[same as prior period, unchanged from 0001262039-15-000016:notes:125]

[0001262039-15-000024:notes:128]
[same as prior period, unchanged from 0001262039-15-000016:notes:126]


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001262039-15-000024:notes:129]
[same as prior period, unchanged from 0001262039-15-000016:notes:127]

[0001262039-15-000024:notes:130]
[same as prior period, unchanged from 0001262039-15-000016:notes:128]

[0001262039-15-000024:notes:131]
There have been no material changes to our significant accounting policies as of and for the three and six months ended June 30, 2015.


## us-gaap:SubsequentEventsTextBlock

[0001262039-15-000024:notes:132]
SUBSEQUENT EVENT

[0001262039-15-000024:notes:133]
In July 2015, we acquired Meru Networks, Inc. (“Meru”), which offers Wi-Fi networking solutions, for a total consideration of approximately $44.0 million. The acquisition expands on our secure wireless vision and enterprise growth focus, broadens our portfolio of solutions , and expands our opportunity to address the global enterprise Wi-Fi market with integrated secure wireless solutions. We are still in the process of evaluating the business combination accounting considerations, including the consideration transferred and the initial purchase price allocation.
