# FTNT 8-K — 0001262039-15-000019 filed 2015-07-22

## item codes, every 8-K on or before 2015-08-04

- 2015-07-23 0001262039-15-000021 — 5.02
- 2015-07-22 0001262039-15-000019 — 2.02, 9.01
- 2015-07-08 0001193125-15-248065 — 2.01, 8.01, 9.01
- 2015-06-22 0001193125-15-229099 — 5.07
- 2015-06-19 0001193125-15-228428 — 5.02, 9.01
- 2015-04-20 0001262039-15-000014 — 2.02, 9.01
- 2015-01-28 0001262039-15-000005 — 2.02, 9.01
- 2014-10-22 0001262039-14-000036 — 2.02, 9.01
- 2014-07-23 0001262039-14-000030 — 2.02, 9.01
- 2014-06-24 0001262039-14-000027 — 5.07
- 2014-04-23 0001262039-14-000021 — 2.02, 9.01
- 2014-04-21 0001262039-14-000018 — 5.03, 9.01
- 2014-01-29 0001262039-14-000004 — 2.02, 9.01
- 2013-12-20 0001262039-13-000061 — 5.02, 9.01
- 2013-11-27 0001262039-13-000057 — 5.02, 7.01, 9.01
- 2013-11-12 0001445305-13-002993 — 5.02
- 2013-10-23 0001262039-13-000051 — 2.02, 9.01
- 2013-07-30 0001262039-13-000039 — 2.02, 9.01
- 2013-06-25 0001262039-13-000030 — 5.07
- 2013-04-30 0001262039-13-000023 — 2.02, 9.01
- 2013-04-19 0001262039-13-000020 — 5.02, 9.01
- 2013-04-19 0001262039-13-000018 — 5.02 — amendment of 0001262039-13-000020
- 2013-04-10 0001262039-13-000016 — 2.02, 9.01
- 2013-03-26 0001262039-13-000013 — 5.02
- 2013-01-30 0001262039-13-000005 — 2.02, 9.01
- 2013-01-24 0001262039-13-000002 — 5.02, 9.01
- 2012-10-16 0001262039-12-000048 — 2.02, 9.01
- 2012-10-01 0001262039-12-000045 — 5.02
- 2012-09-26 0001262039-12-000043 — 5.01
- 2012-07-25 0001262039-12-000038 — 2.02, 9.01
- 2012-07-19 0001262039-12-000034 — 5.02
- 2012-06-20 0001193125-12-275869 — 5.07
- 2012-04-27 0001262039-12-000029 — 5.02
- 2012-04-24 0001262039-12-000025 — 2.02, 9.01
- 2012-01-31 0001262039-12-000006 — 2.02, 9.01
- 2012-01-25 0001262039-12-000003 — 5.03
- 2011-10-24 0001262039-11-000036 — 2.02
- 2011-07-19 0001262039-11-000014 — 2.02, 9.01
- 2011-06-27 0001193125-11-174474 — 5.02, 5.07, 9.01
- 2011-04-27 0001193125-11-111938 — 2.02, 9.01
- 2011-01-25 0001193125-11-013914 — 2.02, 9.01
- 2010-10-21 0001193125-10-233676 — 2.02, 9.01
- 2010-09-02 0001193125-10-203099 — 8.01
- 2010-07-22 0001193125-10-163844 — 2.02, 9.01
- 2010-06-24 0001193125-10-146082 — 5.07
- 2010-04-28 0001193125-10-096698 — 2.02, 9.01
- 2010-02-09 0001193125-10-024614 — 8.01
- 2010-01-27 0001193125-10-014292 — 2.02, 9.01
- 2010-01-26 0001193125-10-013031 — 5.02, 9.01

## late-filing notifications on or before 2015-08-04

- none on or before 2015-08-04

## item 2.02 — earnings release, exhibit 99.1

[0001262039-15-000019:8k_2_02:1]
EX-99.1
2
ftntq2-2015ex991.htm
PRESS RELEASE

[0001262039-15-000019:8k_2_02:2]
FTNT Q2-2015 EX 99.1

[0001262039-15-000019:8k_2_02:3]
Press Release

[0001262039-15-000019:8k_2_02:4]
| Investor Contact: |  | Media Contact: |
| Michelle Spolver |  | Andrea Cousens |
| Fortinet, Inc. |  | Fortinet, Inc. |
| 408-486-7837 |  | 310-270-8903 |
| mspolver@fortinet.com |  | acousens@fortinet.com |

[0001262039-15-000019:8k_2_02:5]
Fortinet Reports Excellent Second Quarter 2015 Financial Results

[0001262039-15-000019:8k_2_02:6]
Outperforms across all key metrics and delivers record billings growth of 40% year over year

[0001262039-15-000019:8k_2_02:7]
•Billings of $297.2 million, up 40% year over year1

[0001262039-15-000019:8k_2_02:8]
•Revenue of $239.8 million, up 30% year over year

[0001262039-15-000019:8k_2_02:9]
•Non-GAAP diluted net income per share of $0.111

[0001262039-15-000019:8k_2_02:10]
•Cash flow from operations of $84.3 million

[0001262039-15-000019:8k_2_02:11]
•Free cash flow of $73.5 million1

[0001262039-15-000019:8k_2_02:12]
| • | Cash, cash equivalents and investments of $1.15 billion |

[0001262039-15-000019:8k_2_02:13]
| • | Deferred revenue of $657.6 million, up 37% year over year |

[0001262039-15-000019:8k_2_02:14]
SUNNYVALE, Calif. - July 22, 2015 - Fortinet® (NASDAQ: FTNT), a global leader in high performance cyber security solutions, today announced financial results for the second quarter ended June 30, 2015.

[0001262039-15-000019:8k_2_02:15]
“Fortinet’s record billings growth and better-than-expected revenue, profitability and cash flow during the second quarter reflect that our investment strategy continues to pay off,” said Ken Xie, founder, chairman and chief executive officer.  “Our over-performance was driven by the combination of our customer focus and strong competitive technology position, return on our sales and marketing investments, momentum with our partners, the robust security market, and our ability to land new customers as well as expand within our existing accounts.  Looking forward, Fortinet is well positioned to maintain momentum and gain market share globally due to our best-in-class integrated end-to-end network security platform.”

[0001262039-15-000019:8k_2_02:16]
Financial Highlights for the Second Quarter of 2015

[0001262039-15-000019:8k_2_02:17]
| • | Billings1: Total billings were $297.2 million for the second quarter of 2015, an increase of 40% compared to $213.0 million in the same quarter of 2014. |

[0001262039-15-000019:8k_2_02:18]
| • | Revenue: Total revenue was $239.8 million for the second quarter of 2015, an increase of 30% compared to $184.1 million in the same quarter of 2014. Within total revenue, |

[0001262039-15-000019:8k_2_02:19]
product revenue was $114.8 million, an increase of 34% compared to $85.4 million in the same quarter of 2014.  Service revenue was $125.0 million, an increase of 27% compared to $98.7 million in the same quarter of 2014.

[0001262039-15-000019:8k_2_02:20]
| • | Deferred Revenue: Total deferred revenue was $657.6 million as of June 30, 2015, an increase of $57.4 million from $600.2 million as of March 31, 2015. |

[0001262039-15-000019:8k_2_02:21]
| • | Cash and Cash Flow2: As of June 30, 2015, cash, cash equivalents and investments were $1.15 billion, compared to $1.07 billion as of March 31, 2015. In the second quarter of 2015, cash flow from operations was $84.3 million compared to $43.8 million in the same quarter of 2014. Free cash flow1 was $73.5 million during the second quarter of 2015 compared to $34.1 million in the same quarter of 2014. |

[0001262039-15-000019:8k_2_02:22]
| • | GAAP Operating Income: GAAP operating income was $3.0 million for the second quarter of 2015, representing a GAAP operating margin of 1%. GAAP operating income was $11.1 million for the same quarter of 2014, representing a GAAP operating margin of 6%. |

[0001262039-15-000019:8k_2_02:23]
| • | GAAP Net Income and Diluted Net Income Per Share: GAAP net income was $0.8 million for the second quarter of 2015, compared to GAAP net income of $6.1 million for the same quarter of 2014. GAAP diluted net income per share was break-even for the second quarter of 2015, compared to $0.04 for the same quarter of 2014. |

[0001262039-15-000019:8k_2_02:24]
| • | Non-GAAP Operating Income1: Non-GAAP operating income was $29.3 million for the second quarter of 2015, representing a non-GAAP operating margin of 12%. Non-GAAP operating income was $28.7 million for the same quarter of 2014, representing a non-GAAP operating margin of 16%. |

[0001262039-15-000019:8k_2_02:25]
| • | Non-GAAP Net Income and Diluted Net Income Per Share1: Non-GAAP net income was $19.4 million for the second quarter of 2015, compared to non-GAAP net income of $18.6 million for the same quarter of 2014. Non-GAAP diluted net income per share was $0.11 for both periods. |

[0001262039-15-000019:8k_2_02:26]
1 A reconciliation of GAAP to non-GAAP financial measures has been provided in the financial statement tables included in this press release. An explanation of these measures is also included below under the heading “Non-GAAP Financial Measures.”

[0001262039-15-000019:8k_2_02:27]
2 During the second quarter of 2015, there were no shares repurchased under our share repurchase program.

[0001262039-15-000019:8k_2_02:28]
Conference Call Details

[0001262039-15-000019:8k_2_02:29]
Fortinet will host a conference call today, July 22, 2015, at 1:30 p.m. Pacific Time (4:30 p.m. Eastern Time) to discuss its financial results. To access this call, dial (877) 303-6913 (domestic) or (224) 357-2188 (international) with conference ID # 80645551. A live webcast of the conference call and supplemental slides will be accessible from the Investor Relations page of Fortinet’s website at http://investor.fortinet.com and a replay will be archived and accessible at http://investor.fortinet.com/events.cfm. A replay of this conference call can also be accessed through July 29, 2015, by dialing (855) 859-2056 (domestic) or (404) 537-3406 (international) with conference ID# 80645551.

[0001262039-15-000019:8k_2_02:30]
Following the financial results conference call, Fortinet will host an additional question-and-answer session at 3:30 p.m. Pacific Time (6:30 p.m. Eastern Time) to provide an opportunity for financial analysts and investors to ask more detailed product and financial questions. To access

[0001262039-15-000019:8k_2_02:31]
this call, dial (877) 303-6913 (domestic) or (224) 357-2188 (international) with conference ID # 80648574. This follow-up call will be webcast live and accessible at http://investor.fortinet.com, and a replay will be archived and available after the call at http://investor.fortinet.com/events.cfm. A replay of this conference call will also be available through July 29, 2015 by dialing (855) 859-2056 (domestic) or (404) 537-3406 (international) with conference ID # 80648574.

[0001262039-15-000019:8k_2_02:32]
About Fortinet (www.fortinet.com)

[0001262039-15-000019:8k_2_02:33]
Fortinet (NASDAQ: FTNT) protects the most valuable assets of some of the largest enterprise, service provider and government organizations across the globe. The company’s fast, secure and global cyber security solutions provide broad, high-performance protection against dynamic security threats while simplifying the IT infrastructure. They are strengthened by the industry’s highest level of threat research, intelligence and analytics. Unlike pure-play network security providers, Fortinet can solve organizations’ most important security challenges, whether in networked, application or mobile environments - be it virtualized/cloud or physical. More than 200,000 customers worldwide, including some of the largest and most complex organizations, trust Fortinet to protect their brands. Learn more at www.fortinet.com, the Fortinet Blog or FortiGuard Labs.

[0001262039-15-000019:8k_2_02:34]
#          #          #

[0001262039-15-000019:8k_2_02:35]
Copyright © 2015 Fortinet, Inc. All rights reserved. The symbols ® and ™ denote respectively federally registered trademarks and unregistered trademarks of Fortinet, Inc., its subsidiaries and affiliates. Fortinet's trademarks include, but are not limited to, the following: Fortinet, FortiGate, FortiGuard, FortiManager, FortiMail, FortiClient, FortiCloud, FortiCare, FortiAnalyzer, FortiReporter, FortiOS, FortiASIC, FortiWiFi, FortiSwitch, FortiVoIP, FortiBIOS, FortiLog, FortiResponse, FortiCarrier, FortiScan, FortiAP, FortiDB, FortiVoice and FortiWeb. Other trademarks belong to their respective owners.

[0001262039-15-000019:8k_2_02:36]
FTNT-F

[0001262039-15-000019:8k_2_02:37]
Forward-looking Statements

[0001262039-15-000019:8k_2_02:38]
This press release contains forward-looking statements that involve risks and uncertainties. These forward-looking statements include statements regarding the momentum in our business, potential growth of our business and market share gains. Although we attempt to be accurate in making forward-looking statements, it is possible that future circumstances might differ from the assumptions on which such statements are based. Important factors that could cause results to differ materially from the statements herein include the following: general economic risks; increasing competitiveness in the security market; the dynamic nature of the security market; specific economic risks in different geographies, and among different customer segments; changes in foreign currency exchange rates; uncertainty regarding increased business and renewals from existing customers; uncertainties around continued success in sales growth and market share gains; failure to convert sales pipeline into final sales; risks associated with successful implementation of multiple integrated software products and other product functionality risks; execution risks around new product development and introductions and innovation; sales execution risks; product defects; security breaches; litigation and disputes and the potential cost, distraction and damage to sales and reputation caused thereby; market acceptance of new products and services; the ability to attract and retain personnel; changes in strategy; risks associated with management of growth; lengthy sales and implementation cycles, particularly in larger organizations; technological changes that make our products and services less competitive; competition and pricing pressure; and the other risk factors set forth from time to time in our most recent Annual Report on Form 10-K, our most recent Quarterly Report on

[0001262039-15-000019:8k_2_02:39]
Non-GAAP Financial Measures

[0001262039-15-000019:8k_2_02:40]
We have provided in this release financial information that has not been prepared in accordance with Generally Accepted Accounting Principles (GAAP). These non-GAAP financial measures are not based on any standardized methodology prescribed by GAAP and are not necessarily comparable to similar measures presented by other companies. We use these non-GAAP financial measures internally in analyzing our financial results and believe they are useful to investors, as a supplement to GAAP measures, in evaluating our ongoing operational performance. We believe that the use of these non-GAAP financial measures provides an additional tool for investors to use in evaluating ongoing operating results and trends and in comparing our financial results with other companies in our industry, many of which present similar non-GAAP financial measures to investors.

[0001262039-15-000019:8k_2_02:41]
Non-GAAP financial measures should not be considered in isolation from, or as a substitute for, financial information prepared in accordance with GAAP. Investors are encouraged to review the reconciliation of these non-GAAP financial measures to their most directly comparable GAAP financial measures below. As previously mentioned, a reconciliation of our non-GAAP financial measures to their most directly comparable GAAP measures has been provided in the financial statement tables included below in this press release.

[0001262039-15-000019:8k_2_02:42]
Billings. We define billings as revenue recognized plus the change in deferred revenue from the beginning to the end of the period less any deferred revenue balances acquired from business combination(s) during the period, if any. We consider billings to be a useful metric for management and investors because billings drives deferred revenue, which is an important indicator of the health and viability of our business. There are a number of limitations related to the use of billings versus revenue calculated in accordance with GAAP. First, billings include amounts that have not yet been recognized as revenue. Second, we may calculate billings in a manner that is different from peer companies that report similar financial measures. Management compensates for these limitations by providing specific information regarding GAAP revenue and evaluating billings together with revenue calculated in accordance with GAAP.

[0001262039-15-000019:8k_2_02:43]
Free cash flow. We define free cash flow as net cash provided by operating activities minus capital expenditures. We consider free cash flow to be a liquidity measure that provides useful information to management and investors about the amount of cash generated by the business that, after the acquisition of property and equipment, can be used for strategic opportunities, including investing in our business, making strategic acquisitions, repurchasing outstanding common stock, and strengthening the balance sheet. Analysis of free cash flow facilitates management’s comparisons of our operating results to competitors’ operating results. A limitation of using free cash flow versus the GAAP measure of net cash provided by operating activities as a means for evaluating liquidity is that free cash flow does not represent the total increase or decrease in the cash, cash equivalents and investments balance for the period because free cash flow excludes cash used for capital expenditures and also excludes cash provided by or used for other investing and financing activities. Management compensates for this limitation by providing information about our capital expenditures and other investing and financing activities on the face of the cash flow statement and under the caption “Management’s Discussion and Analysis of Financial Condition and Results of Operations - Liquidity and Capital

[0001262039-15-000019:8k_2_02:44]
Resources” in our most recent Quarterly Report on Form 10-Q and Annual Report on Form 10-K.

[0001262039-15-000019:8k_2_02:45]
Non-GAAP operating income and operating margin. We define non-GAAP operating income as operating income plus stock-based compensation, acquisition-related charges and other purchase accounting adjustments, impairment and amortization of intangible assets, expenses associated with the implementation of a new Enterprise Resource Planning (ERP) system, and, when applicable, any other significant non-recurring items in a given quarter. Non-GAAP operating margin is defined as non-GAAP operating income divided by revenue. We consider these non-GAAP financial measures to be useful metrics for management and investors because they exclude the effect of stock-based compensation expense, acquisition-related charges and other purchase accounting adjustments, impairment and amortization of intangible assets, expenses associated with the implementation of a new ERP system, and, when applicable, any other significant non-recurring items so that our management and investors can compare our recurring core business operating results over multiple periods. There are a number of limitations related to the use of non-GAAP operating income versus operating income calculated in accordance with GAAP. First, non-GAAP operating income excludes stock-based compensation expense, acquisition-related charges and other purchase accounting adjustments, impairment and amortization of intangible assets, expenses associated with the implementation of a new ERP system, and any other significant non-recurring items. Stock-based compensation has been and will continue to be, for the foreseeable future, a significant recurring expense in our business. Second, stock-based compensation expense is an important part of our employees’ compensation and impacts their performance. Third, the components of the costs that we exclude from our calculation of non-GAAP operating income may differ from the components that other companies exclude when they report their non-GAAP results of operations. Management compensates for these limitations by providing specific information regarding the GAAP amounts excluded from non-GAAP operating income and evaluating non-GAAP operating income together with operating income calculated in accordance with GAAP.

[0001262039-15-000019:8k_2_02:46]
Non-GAAP net income and diluted net income per share. We define non-GAAP net income as net income plus items noted above under non-GAAP operating income and operating margin, adjusted for the impact of the tax adjustment, if any required, resulting in an effective tax rate on a non-GAAP basis, which could differ from the GAAP effective tax rate. We define non-GAAP diluted net income per share as non-GAAP net income divided by the weighted-average diluted shares outstanding. We consider these non-GAAP financial measures to be useful metrics for management and investors for the same reasons that we use non-GAAP operating income and non-GAAP operating margin. However, in order to provide a complete picture of our recurring core business operating results, we include in non-GAAP net income and non-GAAP diluted net income per share, the tax adjustment required resulting in an effective tax rate on a non-GAAP basis, which could differ from the GAAP tax rate. We believe the effective tax rates we used are reasonable estimates of normalized tax rates for our current and prior fiscal years under our global operating structure. The same limitations described above regarding our use of non-GAAP operating income and non-GAAP operating margin apply to our use of non-GAAP net income and non-GAAP diluted net income per share. We compensate for these limitations by providing specific information regarding the GAAP amounts excluded from non-GAAP net income and non-GAAP diluted net income per share and evaluating non-GAAP net income and non-GAAP diluted net income per share together with net income and diluted net income per share calculated in accordance with GAAP.

[0001262039-15-000019:8k_2_02:47]
FORTINET, INC.

[0001262039-15-000019:8k_2_02:48]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001262039-15-000019:8k_2_02:49]
(Unaudited, in thousands)

[0001262039-15-000019:8k_2_02:50]
|  | June 30, 2015 |  | December 31, 2014 |
| ASSETS |  |  |  |
| CURRENT ASSETS: |  |  |  |
| Cash and cash equivalents | $ | 481,393 |  |  | $ | 283,254 |  |
| Short-term investments | 391,634 |  |  | 436,766 |  |
| Accounts receivable—net | 176,849 |  |  | 184,741 |  |
| Inventory | 68,845 |  |  | 69,477 |  |
| Deferred tax assets | 41,463 |  |  | 41,484 |  |
| Prepaid expenses and other current assets | 35,326 |  |  | 31,143 |  |
| Total current assets | 1,195,510 |  |  | 1,046,865 |  |
| LONG-TERM INVESTMENTS | 275,344 |  |  | 271,724 |  |
| PROPERTY AND EQUIPMENT—net | 71,465 |  |  | 58,919 |  |
| DEFERRED TAX ASSETS | 44,152 |  |  | 31,080 |  |
| GOODWILL | 2,824 |  |  | 2,824 |  |
| OTHER INTANGIBLE ASSETS—net | 693 |  |  | 2,832 |  |
| OTHER ASSETS | 14,888 |  |  | 10,530 |  |
| TOTAL ASSETS | $ | 1,604,876 |  |  | $ | 1,424,774 |  |
| LIABILITIES AND STOCKHOLDERS' EQUITY |  |  |  |
| CURRENT LIABILITIES: |  |  |  |
| Accounts payable | $ | 42,336 |  |  | $ | 49,947 |  |
| Accrued liabilities | 29,145 |  |  | 29,016 |  |
| Accrued payroll and compensation | 51,545 |  |  | 45,875 |  |
| Income taxes payable | 1,096 |  |  | 2,689 |  |
| Deferred revenue | 441,177 |  |  | 368,929 |  |
| Total current liabilities | 565,299 |  |  | 496,456 |  |
| DEFERRED REVENUE | 216,384 |  |  | 189,828 |  |
| INCOME TAXES PAYABLE | 56,765 |  |  | 45,139 |  |
| OTHER LIABILITIES | 15,601 |  |  | 17,385 |  |
| Total liabilities | 854,049 |  |  | 748,808 |  |
| STOCKHOLDERS' EQUITY: |  |  |  |
| Common stock | 170 |  |  | 166 |  |
| Additional paid-in capital | 634,969 |  |  | 562,504 |  |
| Accumulated other comprehensive loss | (309 | ) |  | (349 | ) |
| Retained earnings | 115,997 |  |  | 113,645 |  |
| Total stockholders’ equity | 750,827 |  |  | 675,966 |  |
| TOTAL LIABILITIES AND STOCKHOLDERS’ EQUITY | $ | 1,604,876 |  |  | $ | 1,424,774 |  |

[0001262039-15-000019:8k_2_02:51]
FORTINET, INC.

[0001262039-15-000019:8k_2_02:52]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001262039-15-000019:8k_2_02:53]
(Unaudited, in thousands, except per share amounts)

[0001262039-15-000019:8k_2_02:54]
|  | Three Months Ended |  | Six Months Ended |
|  | June 30, 2015 |  | June 30, 2014 |  | June 30, 2015 |  | June 30, 2014 |
| REVENUE: |  |  |  |  |  |  |  |
| Product | $ | 114,777 |  |  | $ | 85,384 |  |  | $ | 212,286 |  |  | $ | 162,149 |  |
| Service | 125,008 |  |  | 98,714 |  |  | 240,385 |  |  | 190,898 |  |
| Total revenue | 239,785 |  |  | 184,098 |  |  | 452,671 |  |  | 353,047 |  |
| COST OF REVENUE: |  |  |  |  |  |  |  |
| Product 1 | 47,397 |  |  | 37,455 |  |  | 88,765 |  |  | 69,594 |  |
| Service 1 | 22,101 |  |  | 20,302 |  |  | 44,335 |  |  | 38,906 |  |
| Total cost of revenue | 69,498 |  |  | 57,757 |  |  | 133,100 |  |  | 108,500 |  |
| GROSS PROFIT: |  |  |  |  |  |  |  |
| Product | 67,380 |  |  | 47,929 |  |  | 123,521 |  |  | 92,555 |  |
| Service | 102,907 |  |  | 78,412 |  |  | 196,050 |  |  | 151,992 |  |
| Total gross profit | 170,287 |  |  | 126,341 |  |  | 319,571 |  |  | 244,547 |  |
| OPERATING EXPENSES: |  |  |  |  |  |  |  |
| Research and development 1 | 37,389 |  |  | 29,938 |  |  | 73,205 |  |  | 58,993 |  |
| Sales and marketing 1 | 111,928 |  |  | 74,817 |  |  | 212,537 |  |  | 142,143 |  |
| General and administrative 1 | 18,018 |  |  | 10,444 |  |  | 29,979 |  |  | 19,454 |  |
| Total operating expenses | 167,335 |  |  | 115,199 |  |  | 315,721 |  |  | 220,590 |  |
| OPERATING INCOME | 2,952 |  |  | 11,142 |  |  | 3,850 |  |  | 23,957 |  |
| INTEREST INCOME | 1,364 |  |  | 1,319 |  |  | 2,786 |  |  | 2,652 |  |
| OTHER EXPENSE—net | (830 | ) |  | (574 | ) |  | (1,507 | ) |  | (963 | ) |
| INCOME BEFORE INCOME TAXES | 3,486 |  |  | 11,887 |  |  | 5,129 |  |  | 25,646 |  |
| PROVISION FOR INCOME TAXES | 2,694 |  |  | 5,806 |  |  | 2,777 |  |  | 11,172 |  |
| NET INCOME | $ | 792 |  |  | $ | 6,081 |  |  | $ | 2,352 |  |  | $ | 14,474 |  |
| Net income per share: |  |  |  |  |  |  |  |
| Basic | $ | — |  |  | $ | 0.04 |  |  | $ | 0.01 |  |  | $ | 0.09 |  |
| Diluted | $ | — |  |  | $ | 0.04 |  |  | $ | 0.01 |  |  | $ | 0.09 |  |
| Weighted-average shares outstanding: |  |  |  |  |  |  |  |
| Basic | 169,930 |  |  | 163,161 |  |  | 169,009 |  |  | 162,778 |  |
| Diluted | 176,234 |  |  | 168,345 |  |  | 174,983 |  |  | 168,015 |  |
| 1 Includes stock-based compensation as follows: |  |  |  |  |  |  |  |
| Cost of product revenue | $ | 210 |  |  | $ | 178 |  |  | $ | 350 |  |  | $ | 291 |  |
| Cost of service revenue | 1,660 |  |  | 1,363 |  |  | 3,292 |  |  | 2,692 |  |
| Research and development | 5,541 |  |  | 4,171 |  |  | 10,698 |  |  | 8,053 |  |
| Sales and marketing | 11,271 |  |  | 5,747 |  |  | 20,578 |  |  | 11,493 |  |
| General and administrative | 3,078 |  |  | 3,257 |  |  | 5,764 |  |  | 5,117 |  |
|  | $ | 21,760 |  |  | $ | 14,716 |  |  | $ | 40,682 |  |  | $ | 27,646 |  |

[0001262039-15-000019:8k_2_02:55]
FORTINET, INC.

[0001262039-15-000019:8k_2_02:56]
CONDENSED CONSOLIDATED STATEMENTS OF COMPREHENSIVE INCOME

[0001262039-15-000019:8k_2_02:57]
(Unaudited, in thousands)

[0001262039-15-000019:8k_2_02:58]
|  | Three Months Ended |  | Six Months Ended |
|  | June 30, 2015 |  | June 30, 2014 |  | June 30, 2015 |  | June 30, 2014 |
| Net income | $ | 792 |  |  | $ | 6,081 |  |  | $ | 2,352 |  |  | $ | 14,474 |  |
| Other comprehensive income (loss)—net of taxes: |  |  |  |  |  |  |  |
| Foreign currency translation gains | — |  |  | 1,118 |  |  | — |  |  | 101 |  |
| Unrealized gains (losses) on investments | (822 | ) |  | (21 | ) |  | 63 |  |  | (19 | ) |
| Tax provision (benefit) related to items of other comprehensive income or loss | 287 |  |  | 7 |  |  | (23 | ) |  | 7 |  |
| Other comprehensive income (loss)—net of taxes | (535 | ) |  | 1,104 |  |  | 40 |  |  | 89 |  |
| Comprehensive income | $ | 257 |  |  | $ | 7,185 |  |  | $ | 2,392 |  |  | $ | 14,563 |  |

[0001262039-15-000019:8k_2_02:59]
FORTINET, INC.

[0001262039-15-000019:8k_2_02:60]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001262039-15-000019:8k_2_02:61]
(Unaudited, in thousands)

[0001262039-15-000019:8k_2_02:62]
|  | Six Months Ended |
|  | June 30, 2015 |  | June 30, 2014 |
| CASH FLOWS FROM OPERATING ACTIVITIES: |  |  |  |
| Net income | $ | 2,352 |  |  | $ | 14,474 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |
| Depreciation and amortization | 13,382 |  |  | 10,914 |  |
| Amortization of investment premiums | 3,881 |  |  | 4,752 |  |
| Stock-based compensation | 40,525 |  |  | 27,646 |  |
| Excess tax benefit from stock-based compensation | — |  |  | (2,443 | ) |
| Other non-cash items—net | 1,891 |  |  | 3,549 |  |
| Changes in operating assets and liabilities: |  |  |  |
| Accounts receivable—net | 9,523 |  |  | 2,228 |  |
| Inventory | (7,917 | ) |  | (3,307 | ) |
| Deferred tax assets | (13,072 | ) |  | (6,470 | ) |
| Prepaid expenses and other current assets | (3,492 | ) |  | (4,523 | ) |
| Other assets | (513 | ) |  | 159 |  |
| Accounts payable | (8,383 | ) |  | 1,253 |  |
| Accrued liabilities | (228 | ) |  | 1,544 |  |
| Accrued payroll and compensation | 5,670 |  |  | 8,665 |  |
| Other liabilities | (1,884 | ) |  | 15,375 |  |
| Deferred revenue | 97,156 |  |  | 47,871 |  |
| Income taxes payable | 10,033 |  |  | (16,987 | ) |
| Net cash provided by operating activities | 148,924 |  |  | 104,700 |  |
| CASH FLOWS FROM INVESTING ACTIVITIES: |  |  |  |
| Purchases of investments | (229,479 | ) |  | (283,338 | ) |
| Sales of investments | 22,472 |  |  | 22,864 |  |
| Maturities of investments | 240,625 |  |  | 273,214 |  |
| Purchases of property and equipment | (15,688 | ) |  | (21,022 | ) |
| Other | — |  |  | (17 | ) |
| Net cash provided by (used in) investing activities | 17,930 |  |  | (8,299 | ) |
| CASH FLOWS FROM FINANCING ACTIVITIES: |  |  |  |
| Proceeds from issuance of common stock | 42,647 |  |  | 22,518 |  |
| Taxes paid related to net share settlement of equity awards | (11,362 | ) |  | (5,521 | ) |
| Excess tax benefit from stock-based compensation | — |  |  | 2,443 |  |
| Repurchase and retirement of common stock | — |  |  | (27,167 | ) |
| Net cash provided by (used in) financing activities | 31,285 |  |  | (7,727 | ) |
| EFFECT OF EXCHANGE RATES ON CASH AND CASH EQUIVALENTS | — |  |  | (600 | ) |
| NET INCREASE IN CASH AND CASH EQUIVALENTS | 198,139 |  |  | 88,074 |  |
| CASH AND CASH EQUIVALENTS—Beginning of period | 283,254 |  |  | 115,873 |  |
| CASH AND CASH EQUIVALENTS—End of period | $ | 481,393 |  |  | $ | 203,947 |  |

[0001262039-15-000019:8k_2_02:63]
Reconciliations of non-GAAP results of operations measures to the nearest comparable GAAP measures

[0001262039-15-000019:8k_2_02:64]
(Unaudited, in thousands)

[0001262039-15-000019:8k_2_02:65]
Reconciliation of GAAP revenue to billings

[0001262039-15-000019:8k_2_02:66]
|  | Three Months Ended |
|  | June 30, 2015 |  | June 30, 2014 |
| Total revenue | $ | 239,785 |  |  | $ | 184,098 |  |
| Add increase in deferred revenue | 57,390 |  |  | 28,899 |  |
| Total billings (Non-GAAP) | $ | 297,175 |  |  | $ | 212,997 |  |

[0001262039-15-000019:8k_2_02:67]
Reconciliation of net cash provided by operating activities to free cash flow

[0001262039-15-000019:8k_2_02:68]
|  | Three Months Ended |
|  | June 30, 2015 |  | June 30, 2014 |
| Net cash provided by operating activities | $ | 84,305 |  |  | $ | 43,798 |  |
| Less purchases of property and equipment | (10,761 | ) |  | (9,704 | ) |
| Free cash flow (Non-GAAP) | $ | 73,544 |  |  | $ | 34,094 |  |

[0001262039-15-000019:8k_2_02:69]
Reconciliation of non-GAAP results of operations to the nearest comparable GAAP measures

[0001262039-15-000019:8k_2_02:70]
(Unaudited, in thousands, except per share amounts)

[0001262039-15-000019:8k_2_02:71]
Reconciliation of GAAP to Non-GAAP operating income, operating margin, net income and diluted net income per share

[0001262039-15-000019:8k_2_02:72]
|  | Three Months Ended June 30, 2015 |  | Three Months Ended June 30, 2014 |
|  | GAAP Results |  | Adjustments |  | Non-GAAP Results |  | GAAP Results |  | Adjustments |  | Non-GAAP Results |
| Operating income | $ | 2,952 |  |  | $ | 26,339 |  | (a) | $ | 29,291 |  |  | $ | 11,142 |  |  | $ | 17,528 |  | (b) | $ | 28,670 |  |
| Operating margin | 1 | % |  |  |  | 12 | % |  | 6 | % |  |  |  | 16 | % |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | 21,760 |  |  |  |  |  |  | 14,716 |  |  |  |
| Impairment of intangible assets |  |  | 1,593 |  |  |  |  |  |  | 2,404 |  |  |  |
| Amortization of intangible assets |  |  | 244 |  |  |  |  |  |  | 408 |  |  |  |
| ERP-related expenses |  |  | 1,395 |  |  |  |  |  |  | — |  |  |  |
| Acquisition-related charges |  |  | 1,347 |  |  |  |  |  |  | — |  |  |  |
| Tax adjustment |  |  | (7,745 | ) | (c) |  |  |  |  | (5,033 | ) | (c) |  |
| Net income | $ | 792 |  |  | $ | 18,594 |  |  | $ | 19,386 |  |  | $ | 6,081 |  |  | $ | 12,495 |  |  | $ | 18,576 |  |
| Diluted net income per share | $ | — |  |  |  |  | $ | 0.11 |  |  | $ | 0.04 |  |  |  |  | $ | 0.11 |  |
| Shares used in diluted net income per share calculations | 176,234 |  |  |  |  | 176,234 |  |  | 168,345 |  |  |  |  | 168,345 |  |

[0001262039-15-000019:8k_2_02:73]
(a) To exclude $21.8 million of stock-based compensation, $1.6 million of impairment of intangible assets, $0.2 million of amortization of intangible assets, $1.4 million of ERP-related expenses, and $1.3 million of acquisition-related charges in the three months ended June 30, 2015.

[0001262039-15-000019:8k_2_02:74]
(b) To exclude $14.7 million of stock-based compensation, $2.4 million of impairment of intangible assets, and $0.4 million of amortization of intangible assets in the three months ended June 30, 2014.

[0001262039-15-000019:8k_2_02:75]
(c)  Non-GAAP financial information is adjusted resulting in an overall 35 percent effective tax rate on a non-GAAP basis, which differs from the GAAP effective tax rate.
