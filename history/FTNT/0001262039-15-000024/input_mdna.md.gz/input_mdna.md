# FTNT MD&A — 0001262039-15-000024


## mdna

[0001262039-15-000024:mdna:1]
[same as prior period, unchanged from 0001262039-15-000016:mdna:1]

[0001262039-15-000024:mdna:2]
[same as prior period, unchanged from 0001262039-15-000016:mdna:2]

[0001262039-15-000024:mdna:3]
[same as prior period, unchanged from 0001262039-15-000016:mdna:3]

[0001262039-15-000024:mdna:4]
[same as prior period, unchanged from 0001262039-15-000016:mdna:4]

[0001262039-15-000024:mdna:5]
[same as prior period, unchanged from 0001262039-15-000016:mdna:5]

[0001262039-15-000024:mdna:6]
[same as prior period, unchanged from 0001262039-15-000016:mdna:6]

[0001262039-15-000024:mdna:7]
| • | growing our sales to large enterprises, service providers, and government organizations and the impact of sales to these organizations on our long-term growth and operating results; |

[0001262039-15-000024:mdna:8]
[same as prior period, unchanged from 0001262039-15-000016:mdna:8]

[0001262039-15-000024:mdna:9]
| • | trends in our operating expenses, including research and development expense, sales and marketing expense and general and administrative expense, and expectations regarding these expenses as a percentage of revenue; |

[0001262039-15-000024:mdna:10]
[same as prior period, unchanged from 0001262039-15-000016:mdna:10]

[0001262039-15-000024:mdna:11]
[same as prior period, unchanged from 0001262039-15-000016:mdna:11]

[0001262039-15-000024:mdna:12]
[same as prior period, unchanged from 0001262039-15-000016:mdna:12]

[0001262039-15-000024:mdna:13]
[same as prior period, unchanged from 0001262039-15-000016:mdna:13]

[0001262039-15-000024:mdna:14]
[same as prior period, unchanged from 0001262039-15-000016:mdna:14]

[0001262039-15-000024:mdna:15]
| • | integration of acquired companies and technologies; |

[0001262039-15-000024:mdna:16]
| • | implementation of a new enterprise resource planning (“ERP”) system; |

[0001262039-15-000024:mdna:17]
[same as prior period, unchanged from 0001262039-15-000016:mdna:15]

[0001262039-15-000024:mdna:18]
[same as prior period, unchanged from 0001262039-15-000016:mdna:16]

[0001262039-15-000024:mdna:19]
[same as prior period, unchanged from 0001262039-15-000016:mdna:17]

[0001262039-15-000024:mdna:20]
We provide high performance cybersecurity solutions to some of the largest enterprises, service providers and government organizations across the globe, including a majority of the 2015 Fortune 100. Our cybersecurity solutions are fast

[0001262039-15-000024:mdna:21]
[same as prior period, unchanged from 0001262039-15-000016:mdna:40]

[0001262039-15-000024:mdna:22]
and secure and designed to provide broad, high-performance protection against dynamic security threats while simplifying the information technology (“IT”) infrastructure of our end-customers worldwide.

[0001262039-15-000024:mdna:23]
Our flagship integrated network security solution consists of our FortiGate physical and virtual appliance platforms which are deployable in large enterprise, service provider and small and medium-sized business environments, and government organizations. These platforms provide a broad array of integrated security and networking functions to help protect data, applications, and users from network- and content-level security threats. These functions, which can be integrated in a variety of ways, include firewall, intrusion prevention, anti-malware, application control, virtual private network, web-filtering, vulnerability management, anti-spam, mobile security, wireless controller, and wide area network acceleration. Our FortiGate appliance platforms may be deployed as next generation firewalls, data center firewalls, unified threat management systems, internal segmentation firewalls, virtual machine firewalls or cloud firewalls. For wireless networked environments, we offer our FortiWiFi appliances, which integrate wireless access point capabilities into the FortiGate network security platform. Each FortiWiFi appliance provides secure access to the wired and wireless local area networks, as well as various wide area network connections.

[0001262039-15-000024:mdna:24]
The FortiGate platform includes our FortiASICs, which are specifically designed for accelerated processing of security and networking functions, and our FortiOS operating system, which provides the foundation for all FortiGate security functions. Our FortiGuard security subscription and FortiCare technical support services provide end-customers with access to dynamic updates to our application control, anti-malware, intrusion prevention, web filtering, and anti-spam functionality. Our security subscription services are based in part on intelligence gathered by FortiGuard Labs, a large team of threat researchers who detect threats and help protect our customers. By combining multiple proprietary security and networking functions with our purpose-built FortiASIC and FortiOS, our FortiGate solution delivers broad protection against dynamic security threats while reducing the operational burden and costs associated with managing multiple point products.

[0001262039-15-000024:mdna:25]
We complement our FortiGate product line with the FortiManager and FortiAnalyzer product families. FortiManager provides customers with centralized management of multiple FortiGate appliances while FortiAnalyzer provides customers with a single point of network log data collection.  These products enable customers to implement security policies across large networks. The FortiGate platform can be expanded with a number of other security systems including email (FortiMail), endpoint (FortiClient), wireless access points (FortiAP), advanced threat protection (FortiSandbox), and application security (FortiWAF, FortiADC, and FortiDDoS).

[0001262039-15-000024:mdna:26]
[same as prior period, unchanged from 0001262039-15-000016:mdna:22]

[0001262039-15-000024:mdna:27]
[same as prior period, unchanged from 0001262039-15-000016:mdna:23]

[0001262039-15-000024:mdna:28]
| • | We recorded total revenue of $239.8 million and $452.7 million for the three and six months ended June 30, 2015, respectively, an increase of 30% and 28%, respectively, compared to the same periods last year. Product revenue was $114.8 million and $212.3 million during the three and six months ended June 30, 2015, respectively, an increase of 34% and 31%, respectively, compared to the same periods last year. Service revenue was $125.0 million and $240.4 million for the three and six months ended June 30, 2015, an increase of 27% and 26%, respectively, compared to the same periods last year. |

[0001262039-15-000024:mdna:29]
| • | Cash, cash equivalents and investments were $1.15 billion as of June 30, 2015, an increase of $156.6 million, or 16%, from December 31, 2014. |

[0001262039-15-000024:mdna:30]
| • | Deferred revenue was $657.6 million as of June 30, 2015, an increase of $98.8 million, or 18%, from December 31, 2014. |

[0001262039-15-000024:mdna:31]
| • | We generated cash flows from operating activities of $148.9 million during the six months ended June 30, 2015, an increase of $44.2 million, or 42%, compared to the same period last year. |

[0001262039-15-000024:mdna:32]
| • | In July 2015, we acquired Meru Networks, Inc. (“Meru”), which offers Wi-Fi networking solutions, for a total consideration of approximately $44.0 million. |

[0001262039-15-000024:mdna:33]
[same as prior period, unchanged from 0001262039-15-000016:mdna:46]

[0001262039-15-000024:mdna:34]
Revenue grew as our integrated security platform products put us in a strong competitive position in a robust security market. In addition, we continue to expand and upgrade our enterprise sales force, build out vertical-specific sales teams, strengthen partnerships with enterprise resellers, and gain from our prior sales investments. Our strategy is enabling us to gain market share, win new customers, and expand within existing customer accounts, especially in the large enterprise market. Aside from obtaining new customers, other levers to drive long-term growth and operating leverage include adding more functionality and value in our security and support service offerings to customers. We continue to grow the number of large deals with large enterprises, which is also key to our long-term growth and profitability strategy as these high-end customers tend to provide higher lifetime value and are beneficial to our business model over time.

[0001262039-15-000024:mdna:35]
During the three months ended June 30, 2015, our revenue growth was primarily driven by our growth in the U.S. large enterprise market. We also continued to see diversity of product sales in our FortiGate product family due to increased demand across all product categories. Our high-end products (FortiGate 1000 to 5000 series) accounted for 45% of billings primarily driven by continued enterprise adoption of our high-end appliances such as the FortiGate1500D and 3700D series appliances. Our mid-range products (FortiGate 200 to 800 series) accounted for 24% of billings, and our entry-level products (FortiGate 20 to 100 series) accounted for 31% of billings. During the three months ended June 30, 2014, our high-end products (FortiGate1000 to 5000 series) accounted for 40% of billings primarily due to an increase in billings from large enterprise customers. Our mid-range products (FortiGate 200 to 800 series) accounted for 26% of billings, and our entry-level products (FortiGate 20 to 100 series) accounted for 34% of billings.

[0001262039-15-000024:mdna:36]
During the three and six months ended June 30, 2015, operating expenses increased compared to the same periods last year. The increase was primarily driven by our accelerated pace of hiring and continued investments to expand our sales coverage, grow our marketing capabilities, develop new products, and scale our customer support organization to meet the needs of our expanding customer base. Headcount, including full time equivalent employees, increased to 3,336 as of June 30, 2015 from 2,532 as of June 30, 2014.

[0001262039-15-000024:mdna:37]
[same as prior period, unchanged from 0001262039-15-000016:mdna:33]

[0001262039-15-000024:mdna:38]
[same as prior period, unchanged from 0001262039-15-000016:mdna:34]

[0001262039-15-000024:mdna:39]
|  | Three Months Ended Or As Of |
|  | June 30, 2015 |  | June 30, 2014 |
|  | (in thousands) |
| Revenue | $ | 239,785 |  |  | $ | 184,098 |  |
| Deferred revenue | $ | 657,561 |  |  | $ | 480,202 |  |
| Increase in deferred revenue | $ | 57,390 |  |  | $ | 28,899 |  |
| Billings (non-GAAP) | $ | 297,175 |  |  | $ | 212,997 |  |
| Cash, cash equivalents and investments | $ | 1,148,371 |  |  | $ | 910,594 |  |
| Net cash provided by operating activities | $ | 84,305 |  |  | $ | 43,798 |  |
| Free cash flow (non-GAAP) | $ | 73,544 |  |  | $ | 34,094 |  |

[0001262039-15-000024:mdna:40]
Deferred revenue. Our deferred revenue consists of amounts that have been invoiced but that have not yet been recognized as revenue. The majority of our deferred revenue balance consists of the unamortized portion of services revenue from FortiGuard security subscription and FortiCare technical support service contracts. We monitor our deferred revenue balance because it represents a significant portion of revenue to be recognized in future periods.

[0001262039-15-000024:mdna:41]
Billings (Non-GAAP).We define billings as revenue recognized plus the change in deferred revenue from the beginning to the end of the period less any deferred revenue balances acquired from business combination(s) during the period, if any. We consider billings to be a useful metric for management and investors because billings drives deferred revenue, which is an important indicator of the health and viability of our business. There are a number of limitations related to the use of billings versus revenue calculated in accordance with GAAP. First, billings include amounts that have not yet been recognized

[0001262039-15-000024:mdna:42]
[same as prior period, unchanged from 0001262039-15-000016:mdna:55]

[0001262039-15-000024:mdna:43]
as revenue. Second, we may calculate billings in a manner that is different from peer companies that report similar financial measures. Management compensates for these limitations by providing specific information regarding GAAP revenue and evaluating billings together with revenue calculated in accordance with GAAP. A reconciliation of billings to revenue, the most directly comparable financial measure calculated and presented in accordance with GAAP, is provided below:

[0001262039-15-000024:mdna:44]
|  | Three Months Ended |
| June 30, 2015 |  | June 30, 2014 |
| (in thousands) |
| Billings: |  |  |  |
| Revenue | $ | 239,785 |  |  | $ | 184,098 |  |
| Increase in deferred revenue | 57,390 |  |  | 28,899 |  |
| Total billings (Non-GAAP) | $ | 297,175 |  |  | $ | 212,997 |  |

[0001262039-15-000024:mdna:45]
Free cash flow (Non-GAAP). We define free cash flow as net cash provided by operating activities minus capital expenditures (purchases of property and equipment). We consider free cash flow to be a liquidity measure that provides useful information to management and investors about the amount of cash generated by the business that, after the acquisition of property and equipment, can be used for strategic opportunities, including investing in our business, making strategic acquisitions, repurchasing outstanding common stock, and strengthening the balance sheet. Analysis of free cash flow facilitates management’s comparisons of our operating results to competitors’ operating results. A limitation of using free cash flow versus the GAAP measure of net cash provided by operating activities as a means for evaluating liquidity is that free cash flow does not represent the total increase or decrease in the cash, cash equivalents and investments balance for the period because free cash flow excludes cash used for capital expenditures and also excludes cash provided by or used for other investing and financing activities. Management compensates for this limitation by providing information about our capital expenditures and other investing and financing activities on the face of the cash flow statement and under “—Liquidity and Capital Resources.”  A reconciliation of free cash flow to net cash provided by operating activities, the most directly comparable financial measure calculated and presented in accordance with GAAP, is provided below:

[0001262039-15-000024:mdna:46]
|  | Three Months Ended |
| June 30, 2015 |  | June 30, 2014 |
| (in thousands) |
| Free Cash Flow: |  |  |  |
| Net cash provided by operating activities | $ | 84,305 |  |  | $ | 43,798 |  |
| Less purchases of property and equipment | (10,761 | ) |  | (9,704 | ) |
| Free cash flow (Non-GAAP) | $ | 73,544 |  |  | $ | 34,094 |  |

[0001262039-15-000024:mdna:47]
[same as prior period, unchanged from 0001262039-15-000016:mdna:43]

[0001262039-15-000024:mdna:48]
[same as prior period, unchanged from 0001262039-15-000016:mdna:44]

[0001262039-15-000024:mdna:49]
There have been no material changes to our critical accounting policies and estimates as of and for the three and six months ended June 30, 2015, as compared to the critical accounting policies and estimates described in the Form 10-K.

[0001262039-15-000024:mdna:50]
Acquisition of Meru

[0001262039-15-000024:mdna:51]
In July 2015, we acquired Meru, which offers Wi-Fi networking solutions, for a total consideration of approximately $44.0 million. The acquisition expands our secure wireless vision and enterprise growth focus, broadens our portfolio of solutions , and expands our opportunity to address the global enterprise Wi-Fi market with integrated secure wireless solutions.

[0001262039-15-000024:mdna:52]
[same as prior period, unchanged from 0001262039-15-000016:mdna:65]

[0001262039-15-000024:mdna:53]
[same as prior period, unchanged from 0001262039-15-000016:mdna:47]

[0001262039-15-000024:mdna:54]
Three Months Ended June 30, 2015 and June 30, 2014

[0001262039-15-000024:mdna:55]
[same as prior period, unchanged from 0001262039-15-000016:mdna:48]

[0001262039-15-000024:mdna:56]
|  | Three Months Ended |  |  |  |  |
| June 30, 2015 |  | June 30, 2014 |  |  |  |  |
| Amount |  | % ofRevenue |  | Amount |  | % ofRevenue |  | Change |  | % Change |
| (in thousands, except percentages) |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 114,777 |  |  | 48 | % |  | $ | 85,384 |  |  | 46 | % |  | $ | 29,393 |  |  | 34 | % |
| Service | 125,008 |  |  | 52 |  |  | 98,714 |  |  | 54 |  |  | 26,294 |  |  | 27 |  |
| Total revenue | $ | 239,785 |  |  | 100 | % |  | $ | 184,098 |  |  | 100 | % |  | $ | 55,687 |  |  | 30 | % |
| Revenue by geography: |  |  |  |  |  |  |  |  |  |  |  |
| Americas | $ | 108,593 |  |  | 45 | % |  | $ | 78,385 |  |  | 43 | % |  | $ | 30,208 |  |  | 39 | % |
| EMEA | 83,405 |  |  | 35 |  |  | 62,554 |  |  | 34 |  |  | 20,851 |  |  | 33 |  |
| APAC | 47,787 |  |  | 20 |  |  | 43,159 |  |  | 23 |  |  | 4,628 |  |  | 11 |  |
| Total revenue | $ | 239,785 |  |  | 100 | % |  | $ | 184,098 |  |  | 100 | % |  | $ | 55,687 |  |  | 30 | % |

[0001262039-15-000024:mdna:57]
Total revenue increased by $55.7 million, or 30%, during the three months ended June 30, 2015 compared to the same period last year. The Americas region grew by 39% as we saw continued strength in the U.S. enterprise market primarily driven by increased sales to large enterprise customers. The EMEA region grew by 33% due to strong sales performance across the region. The APAC region grew by 11% as we saw continued growth in certain parts of the region. Product revenue increased by $29.4 million, or 34%, during the three months ended June 30, 2015 compared to the same period last year. The increase in product revenue was primarily driven by greater sales volume in our FortiGate product family due to increased demand for each of our high-end, mid-range and entry-level product categories, and in particular for our high-end products for large enterprise customers.

[0001262039-15-000024:mdna:58]
Service revenue increased by $26.3 million, or 27%, during the three months ended June 30, 2015 compared to the same period last year due to the recognition of revenue from our deferred revenue balance consisting of FortiGuard security subscription and FortiCare technical support contracts sold to a larger customer base, particularly our large enterprise customers, as well as the renewals of similar contracts sold in earlier periods.

[0001262039-15-000024:mdna:59]
[same as prior period, unchanged from 0001262039-15-000016:mdna:52]

[0001262039-15-000024:mdna:60]
|  | Three Months Ended |  |  |  |  |
| June 30, 2015 |  | June 30, 2014 |  | Change |  | % Change |
| (in thousands, except percentages) |
| Cost of revenue: |  |  |  |  |  |  |  |
| Product | $ | 47,397 |  |  | $ | 37,455 |  |  | $ | 9,942 |  |  | 27 | % |
| Service | 22,101 |  |  | 20,302 |  |  | 1,799 |  |  | 9 |  |
| Total cost of revenue | $ | 69,498 |  |  | $ | 57,757 |  |  | $ | 11,741 |  |  | 20 | % |
| Gross margin (%): |  |  |  |  |  |  |  |
| Product | 58.7 | % |  | 56.1 | % |  | 2.6 | % |  |  |
| Service | 82.3 |  |  | 79.4 |  |  | 2.9 |  |  |  |
| Total gross margin | 71.0 | % |  | 68.6 | % |  | 2.4 | % |  |  |

[0001262039-15-000024:mdna:61]
Total gross margin increased by 2.4 percentage points during the three months ended June 30, 2015 compared to the same period last year as both product and service gross margins increased. Product gross margin increased by 2.6 percentage

[0001262039-15-000024:mdna:62]
28

[0001262039-15-000024:mdna:63]
points during the three months ended June 30, 2015 compared to the same period last year primarily due to a greater mix of high-end FortiGate product sales compared to the same period last year.

[0001262039-15-000024:mdna:64]
Service gross margin increased by 2.9 percentage points during the three months ended June 30, 2015 compared to the same period last year as we scale efficiencies resulting from our ability to add more functionality and value to our service offerings, which have translated into improved service margins. Cost of service revenue increased by $1.8 million primarily due to an increase in personnel costs, including stock-based compensation expense, as a result of increased headcount.

[0001262039-15-000024:mdna:65]
[same as prior period, unchanged from 0001262039-15-000016:mdna:57]

[0001262039-15-000024:mdna:66]
|  | Three Months Ended |  | Change |  | % Change |
| June 30, 2015 |  | June 30, 2014 |  |
| Amount |  | % ofRevenue |  | Amount |  | % ofRevenue |  |
| (in thousands, except percentages) |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | $ | 37,389 |  |  | 16 | % |  | $ | 29,938 |  |  | 16 | % |  | $ | 7,451 |  |  | 25 | % |
| Sales and marketing | 111,928 |  |  | 47 |  |  | 74,817 |  |  | 41 |  |  | 37,111 |  |  | 50 |  |
| General and administrative | 18,018 |  |  | 8 |  |  | 10,444 |  |  | 6 |  |  | 7,574 |  |  | 73 |  |
| Total operating expenses | $ | 167,335 |  |  | 70 | % |  | $ | 115,199 |  |  | 63 | % |  | $ | 52,136 |  |  | 45 | % |

[0001262039-15-000024:mdna:67]
[same as prior period, unchanged from 0001262039-15-000016:mdna:59]

[0001262039-15-000024:mdna:68]
Research and development expense increased by $7.5 million, or 25%, during the three months ended June 30, 2015 compared to the same period last year primarily due to an increase of $4.8 million in personnel costs and $1.4 million in stock-based compensation expense as a result of increased headcount to support the development of new products and continued enhancements of our existing products. In addition, during the three months ended June 30, 2014, we had a reversal of $0.7 million related to a previously recorded liability for estimated contingent consideration. We intend to continue to invest in our research and development organization and integrate personnel from our acquisition of Meru but expect research and development expense as a percentage of total revenue to remain at comparable levels during the remainder of 2015.

[0001262039-15-000024:mdna:69]
[same as prior period, unchanged from 0001262039-15-000016:mdna:61]

[0001262039-15-000024:mdna:70]
Sales and marketing expense increased by $37.1 million, or 50%, during the three months ended June 30, 2015 compared to the same period last year, primarily due to an increase of $20.2 million in personnel costs and $5.5 million in stock-based compensation expense, as we continued to increase our sales headcount in order to drive continued market share gains globally. Marketing-related expense increased by $5.0 million as we invested significantly in marketing programs to capture market share, particularly in the enterprise market, including costs related to trade-shows and lead generation. Travel expense increased by $2.3 million and depreciation and other occupancy-related costs increased by $1.8 million. As a percentage of total revenue, sales and marketing expense increased as we accelerated the investment in our sales force and marketing programs to drive future growth. We intend to continue to make investments in our sales resources and infrastructure and marketing strategy, which are critical to support growth.

[0001262039-15-000024:mdna:71]
[same as prior period, unchanged from 0001262039-15-000016:mdna:63]

[0001262039-15-000024:mdna:72]
General and administrative expense increased by $7.6 million, or 73%, during the three months ended June 30, 2015 compared to the same period last year. Personnel costs, including stock-based compensation expense, increased by $2.1 million, as we continued to increase our headcount in order to support our expanding business. In addition, legal, tax and other professional fees increased by $2.8 million. We also incurred $1.4 million in expenses related to business process design and reengineering in preparation of an ERP system implementation and $1.3 million of transaction costs related to the Meru acquisition.  As a percentage of total revenue, we expect general and administrative expense to remain at comparable levels during the remainder of 2015.

[0001262039-15-000024:mdna:73]
Interest income and Other expense—net

[0001262039-15-000024:mdna:74]
|  | Three Months Ended |  |  |  |  |
| June 30, 2015 |  | June 30, 2014 |  | Change |  | % Change |
| (in thousands, except percentages) |
| Interest income | $ | 1,364 |  |  | $ | 1,319 |  |  | $ | 45 |  |  | 3 | % |
| Other expense—net | (830 | ) |  | (574 | ) |  | (256 | ) |  | 45 |  |

[0001262039-15-000024:mdna:75]
Interest income increased during the three months ended June 30, 2015 compared to the same period last year due to interest earned on higher invested balances of cash, cash equivalents and investments. The increase in Other expense—net for the three months ended June 30, 2015 when compared to the same period last year, was the result of higher foreign currency exchange losses.

[0001262039-15-000024:mdna:76]
[same as prior period, unchanged from 0001262039-15-000016:mdna:69]

[0001262039-15-000024:mdna:77]
|  | Three Months Ended |  | Change |  | % Change |
| June 30, 2015 |  | June 30, 2014 |  |
| (in thousands, except percentages) |
| Provision for income taxes | $ | 2,694 |  |  | $ | 5,806 |  |  | $ | (3,112 | ) |  | (54 | )% |
| Effective tax rate (%) | 77 | % |  | 49 | % |  | 28 | % |  | — |  |

[0001262039-15-000024:mdna:78]
Our effective tax rate was 77% for the three months ended June 30, 2015, compared with an effective tax rate of 49% for the same period last year. The provision for income taxes for the three months ended June 30, 2015 was comprised primarily of U.S. federal and state taxes, other foreign income taxes, foreign withholding taxes, and transfer pricing allocations which impact jurisdictional income taxed at various tax rates. During the three months ended June 30, 2015, there were additional unrecognized tax benefits and non-deductible stock-based compensation expense that adversely impacted the quarterly effective tax rate.

[0001262039-15-000024:mdna:79]
It is our policy to classify accrued interest and penalties related to unrecognized tax benefits in the provision for income taxes. As of June 30, 2015, we had accrued $5.2 million for estimated interest related to uncertain tax provisions.

[0001262039-15-000024:mdna:80]
It is reasonably possible that over the next twelve-month period, we may experience increases or decreases in our unrecognized tax benefits. However, it is not possible to determine either the magnitude or the range of increases or decreases at this time.

[0001262039-15-000024:mdna:81]
30

[0001262039-15-000024:mdna:82]
Six Months Ended June 30, 2015 and June 30, 2014

[0001262039-15-000024:mdna:83]
Revenue

[0001262039-15-000024:mdna:84]
|  | Six Months Ended |  |  |  |  |
| June 30, 2015 |  | June 30, 2014 |  |  |  |  |
| Amount |  | % ofRevenue |  | Amount |  | % ofRevenue |  | Change |  | % Change |
| (in thousands, except percentages) |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 212,286 |  |  | 47 | % |  | $ | 162,149 |  |  | 46 | % |  | $ | 50,137 |  |  | 31 | % |
| Service | 240,385 |  |  | 53 |  |  | 190,898 |  |  | 54 |  |  | 49,487 |  |  | 26 |  |
| Total revenue | $ | 452,671 |  |  | 100 | % |  | $ | 353,047 |  |  | 100 | % |  | $ | 99,624 |  |  | 28 | % |
| Revenue by geography: |  |  |  |  |  |  |  |  |  |  |  |
| Americas | $ | 200,153 |  |  | 44 | % |  | $ | 150,817 |  |  | 43 | % |  | $ | 49,336 |  |  | 33 | % |
| EMEA | 159,068 |  |  | 35 |  |  | 119,197 |  |  | 34 |  |  | 39,871 |  |  | 33 |  |
| APAC | 93,450 |  |  | 21 |  |  | 83,033 |  |  | 23 |  |  | 10,417 |  |  | 13 |  |
| Total revenue | $ | 452,671 |  |  | 100 | % |  | $ | 353,047 |  |  | 100 | % |  | $ | 99,624 |  |  | 28 | % |

[0001262039-15-000024:mdna:85]
Total revenue increased by $99.6 million, or 28%, during the six months ended June 30, 2015 compared to the same period last year.  All three regions experienced revenue growth compared to the same period last year, with the Americas and EMEA contributing the largest portion of our revenue growth on a percentage basis. Product revenue increased by $50.1 million, or 31%, during the six months ended June 30, 2015 compared to the same period last year. The increase in product revenue was primarily driven by greater sales volume in our FortiGate product family due to increased demand for each of our high-end, mid-range and entry-level product categories, and in particular for our high-end products for large enterprise customers.

[0001262039-15-000024:mdna:86]
Service revenue increased by $49.5 million, or 26%, during the six months ended June 30, 2015 compared to the same period last year due to the recognition of revenue from our deferred revenue balance consisting of FortiGuard security subscription and FortiCare technical support contracts sold to a larger customer base, particularly our large enterprise customers, as well as the renewals of similar contracts sold in earlier periods.

[0001262039-15-000024:mdna:87]
Cost of revenue and gross margin

[0001262039-15-000024:mdna:88]
|  | Six Months Ended |  |  |  |  |
| June 30, 2015 |  | June 30, 2014 |  | Change |  | % Change |
| (in thousands, except percentages) |
| Cost of revenue: |  |  |  |  |  |  |  |
| Product | $ | 88,765 |  |  | $ | 69,594 |  |  | $ | 19,171 |  |  | 28 | % |
| Service | 44,335 |  |  | 38,906 |  |  | 5,429 |  |  | 14 |  |
| Total cost of revenue | $ | 133,100 |  |  | $ | 108,500 |  |  | $ | 24,600 |  |  | 23 | % |
| Gross margin (%): |  |  |  |  |  |  |  |
| Product | 58.2 | % |  | 57.1 | % |  | 1.1 | % |  |  |
| Service | 81.6 |  |  | 79.6 |  |  | 2.0 |  |  |  |
| Total gross margin | 70.6 | % |  | 69.3 | % |  | 1.3 | % |  |  |

[0001262039-15-000024:mdna:89]
Total gross margin increased by 1.3 percentage points during the six months ended June 30, 2015 compared to the same period last year, as both product and service gross margins increased. Product gross margin increased by 1.1 percentage points during the six months ended June 30, 2015 compared to the same period last year primarily due to a greater mix of high-end FortiGate product sales compared to the same period last year.

[0001262039-15-000024:mdna:90]
31

[0001262039-15-000024:mdna:91]
Service gross margin increased by 2.0 percentage points during the six months ended June 30, 2015 as compared to the same period last year as we scale efficiencies resulting from our ability to add more functionality and value to our service offerings, which have translated into improved service margins. Cost of service revenue increased by $5.4 million primarily due to a $4.8 million increase in personnel costs and a $0.6 million increase in stock-based compensation expense, as a result of increased headcount.

[0001262039-15-000024:mdna:92]
Operating expenses

[0001262039-15-000024:mdna:93]
|  | Six Months Ended |  | Change |  | % Change |
| June 30, 2015 |  | June 30, 2014 |  |
| Amount |  | % ofRevenue |  | Amount |  | % ofRevenue |  |
| (in thousands, except percentages) |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | $ | 73,205 |  |  | 16 | % |  | $ | 58,993 |  |  | 17 | % |  | $ | 14,212 |  |  | 24 | % |
| Sales and marketing | 212,537 |  |  | 47 |  |  | 142,143 |  |  | 40 |  |  | 70,394 |  |  | 50 |  |
| General and administrative | 29,979 |  |  | 7 |  |  | 19,454 |  |  | 6 |  |  | 10,525 |  |  | 54 |  |
| Total operating expenses | $ | 315,721 |  |  | 70 | % |  | $ | 220,590 |  |  | 63 | % |  | $ | 95,131 |  |  | 43 | % |

[0001262039-15-000024:mdna:94]
Research and development

[0001262039-15-000024:mdna:95]
Research and development expense increased by $14.2 million, or 24%, during the six months ended June 30, 2015 compared to the same period last year primarily due to an increase of $7.9 million in personnel costs and $2.6 million in stock-based compensation expense as a result of increased headcount to support the development of new products and continued enhancements of our existing products. Depreciation expense and other occupancy-related costs increased by $0.8 million and costs of test supplies and prototype materials used in product development increased by $0.4 million. In addition, during the six months ended June 30, 2014, we had a reversal of $1.9 million related to a previously recorded liability for estimated contingent consideration.

[0001262039-15-000024:mdna:96]
Sales and marketing

[0001262039-15-000024:mdna:97]
Sales and marketing expense increased by $70.4 million, or 50%, during the six months ended June 30, 2015 compared to the same period last year, primarily due to an increase of $40.0 million in personnel costs and $9.1 million in stock-based compensation expense as we continued to increase our sales headcount in order to drive continued market share gains globally. Marketing-related expense increased by $8.6 million as we invested significantly in marketing programs to capture market share, particularly in the large enterprise market, including costs related to trade-shows and lead generation. In addition, depreciation and other occupancy-related expense increased by $3.9 million and travel expense increased by $4.0 million.

[0001262039-15-000024:mdna:98]
General and administrative

[0001262039-15-000024:mdna:99]
General and administrative expense increased by $10.5 million, or 54%, during the six months ended June 30, 2015 compared to the same period last year. Personnel costs, including stock-based compensation expense, increased by $4.7 million, as we continued to increase our headcount in order to support our expanding business. In addition, legal, tax, and other professional fees increased by $2.9 million. We also incurred $1.4 million in expenses related to business process design and reengineering in preparation of the ERP system implementation and $1.3 million of transaction costs related to the Meru acquisition.

[0001262039-15-000024:mdna:100]
Interest income and Other expense—net

[0001262039-15-000024:mdna:101]
|  | Six Months Ended |  |  |  |  |
| June 30, 2015 |  | June 30, 2014 |  | Change |  | % Change |
| (in thousands, except percentages) |
| Interest income | $ | 2,786 |  |  | $ | 2,652 |  |  | $ | 134 |  |  | 5 | % |
| Other expense—net | (1,507 | ) |  | (963 | ) |  | (544 | ) |  | 56 |  |

[0001262039-15-000024:mdna:102]
Interest income increased during the six months ended June 30, 2015 compared to the same period last year due to interest earned on higher invested balances of cash, cash equivalents and investments. The increase in Other expense—net for the six months ended June 30, 2015 when compared to the same period last year, was the result of higher foreign currency exchange losses.

[0001262039-15-000024:mdna:103]
Provision for income taxes

[0001262039-15-000024:mdna:104]
|  | Six Months Ended |  | Change |  | % Change |
| June 30, 2015 |  | June 30, 2014 |  |
| (in thousands, except percentages) |
| Provision for income taxes | $ | 2,777 |  |  | $ | 11,172 |  |  | $ | (8,395 | ) |  | (75 | )% |
| Effective tax rate (%) | 54 | % |  | 44 | % |  | 10 | % |  | — |  |

[0001262039-15-000024:mdna:105]
Our effective tax rate was 54% for the six months ended June 30, 2015, compared with an effective tax rate of 44% for the same period last year. The provision for income taxes for the six months ended June 30, 2015 was comprised primarily of U.S. federal and state taxes, other foreign income taxes, foreign withholding taxes, and transfer pricing allocations which impact jurisdictional income taxed at various tax rates. During the six months ended June 30, 2015, there were additional unrecognized tax benefits and non-deductible stock-based compensation expense that adversely impacted the effective tax rate.

[0001262039-15-000024:mdna:106]
[same as prior period, unchanged from 0001262039-15-000016:mdna:74]

[0001262039-15-000024:mdna:107]
|  | As of |
|  | June 30, 2015 |  | December 31, 2014 |
|  | (in thousands) |
| Cash and cash equivalents | $ | 481,393 |  |  | $ | 283,254 |  |
| Investments | 666,978 |  |  | 708,490 |  |
| Total cash, cash equivalents and investments | $ | 1,148,371 |  |  | $ | 991,744 |  |
| Working capital | $ | 630,211 |  |  | $ | 550,409 |  |
|  | Six Months Ended |
|  | June 30, 2015 |  | June 30, 2014 |
|  | (in thousands) |
| Cash provided by operating activities | $ | 148,924 |  |  | $ | 104,700 |  |
| Cash provided by (used) in investing activities | 17,930 |  |  | (8,299 | ) |
| Cash provided by (used in) financing activities | 31,285 |  |  | (7,727 | ) |
| Effect of exchange rates on cash and cash equivalents | — |  |  | (600 | ) |
| Net increase in cash and cash equivalents | $ | 198,139 |  |  | $ | 88,074 |  |

[0001262039-15-000024:mdna:108]
33

[0001262039-15-000024:mdna:109]
Liquidity and capital resources may be impacted by our operating activities, as well as acquisitions, capital expenditures, stock repurchases, proceeds associated with stock option exercises and issuances of common stock under the ESPP, payment of taxes in connection with the net settlement of equity awards, and investments in strategic relationships that we have made or may make in the future. As of June 30, 2015, $122.5 million remains available for future share repurchases under our stock repurchase program (“Program”), which will be financed through our available working capital.  In recent years, we have received significant capital resources as a result of exercises of stock options and purchases under our ESPP. We expect proceeds in future years to be impacted by our share price and the changing mix of stock options and RSUs granted. We expect to spend $35.0 million to $45.0 million in capital expenditures primarily related to expansion of our offices to support worldwide growth, as well as the implementation of our ERP system.

[0001262039-15-000024:mdna:110]
As of June 30, 2015, our cash, cash equivalents, and investments of $1.15 billion were invested primarily in corporate debt securities, commercial paper, municipal bonds, certificates of deposit and term deposits, money market funds, and U.S. government and agency debt securities. It is our investment policy to invest excess cash in a manner that preserves capital, provides liquidity and maximizes return without significantly increasing risk.

[0001262039-15-000024:mdna:111]
As of June 30, 2015, $317.7 million of our cash and investments were held by our international subsidiaries and are therefore not immediately available to fund domestic operations unless the cash is repatriated. While we do not intend to do so, should this amount be repatriated, it would be subject to U.S. federal income tax which would be partially offset by foreign tax credits. We do not enter into investments for trading or speculative purposes. We believe that our existing cash and cash equivalents will be sufficient to meet our anticipated cash needs for at least the next 12 months. Our future capital requirements will depend on many factors including our growth rate, the timing and extent of spending to support development efforts, the expansion of sales and marketing activities, the introduction of new and enhanced products and services offerings, the costs to expand our offices to support growth and the continuing market acceptance of our products. Historically, we have required capital principally to fund our working capital needs, capital expenditures, share repurchases, and acquisition activities. In the event that additional financing is required from outside sources, we may not be able to raise it on terms acceptable to us or at all. If we are unable to raise additional capital when desired, our business, operating results and financial condition would be adversely affected.

[0001262039-15-000024:mdna:112]
[same as prior period, unchanged from 0001262039-15-000016:mdna:80]

[0001262039-15-000024:mdna:113]
Cash generated by operating activities is our primary source of liquidity. It is primarily comprised of net income, adjusted for non-cash items, and changes in operating assets and liabilities. Non-cash adjustments consisted primarily of stock-based compensation expense, depreciation of property and equipment, amortization of intangible assets, and amortization of investment premiums.

[0001262039-15-000024:mdna:114]
Our operating activities during the six months ended June 30, 2015 provided $148.9 million in cash as a result of our continued growth in billings, profitability, and the ability to successfully manage our working capital. The primary sources of cash from operating activities during the six months ended June 30, 2015 consisted of net income of $2.4 million increased by non-cash adjustments of $59.7 million and changes in operating assets and liabilities of $86.9 million. Changes in operating assets and liabilities primarily resulted from an increase in payments received from customers, partially offset by an increase in payments to vendors and an increase in prepayment of certain expenses.

[0001262039-15-000024:mdna:115]
Our operating activities during the six months ended June 30, 2014, provided $104.7 million in cash as a result of our growth in billings, profitability, and the ability to successfully manage our working capital. The primary sources of cash from operating activities during the six months ended June 30, 2014 consisted of net income of $14.5 million increased by non-cash adjustments of $44.4 million and changes in operating assets and liabilities of $45.8 million. During the six months ended June 30, 2014, we received $20.0 million pursuant to a six year mutual covenant-not-to-sue and release agreement with Palo Alto Networks, Inc. Changes in operating assets and liabilities primarily resulted from an increase in payments received from customers and a receipt of cash related to the mutual covenant-not-to-sue and release agreement, partially offset by payment of income taxes during the period.

[0001262039-15-000024:mdna:116]
[same as prior period, unchanged from 0001262039-15-000016:mdna:84]

[0001262039-15-000024:mdna:117]
[same as prior period, unchanged from 0001262039-15-000016:mdna:85]

[0001262039-15-000024:mdna:118]
During the six months ended June 30, 2015, cash provided by investing activities was a result of positive cash flow due to sales and maturities, net of purchases, from our investments of $33.6 million, partially offset by capital expenditures of $15.7 million.

[0001262039-15-000024:mdna:119]
34

[0001262039-15-000024:mdna:120]
During the six months ended June 30, 2014, cash used by investing activities was primarily due to capital expenditures of $21.0 million, partially offset by positive cash flow due to sales and maturities, net of purchases, from our investments of $12.7 million.

[0001262039-15-000024:mdna:121]
[same as prior period, unchanged from 0001262039-15-000016:mdna:88]

[0001262039-15-000024:mdna:122]
The changes in cash flows from financing activities primarily relate to proceeds from the issuance of common stock under our equity incentive plan and ESPP, taxes paid related to net share settlement of equity awards, and repurchase and retirement of common stock.

[0001262039-15-000024:mdna:123]
During the six months ended June 30, 2015, cash provided by financing activities was $31.3 million as a result of proceeds of $42.6 million from the issuance of common stock under our stock plans. This cash inflow was partially offset by $11.4 million related to withholding taxes paid upon the issuance of RSUs.

[0001262039-15-000024:mdna:124]
During the six months ended June 30, 2014, we used $27.2 million to repurchase and retire our common stock and $5.5 million to pay withholding taxes upon issuance of RSUs. These cash outflows were partially offset by proceeds of $22.5 million from the issuance of common stock under our stock plans, as well as excess tax benefit from employee stock-based compensation expense of $2.4 million.

[0001262039-15-000024:mdna:125]
[same as prior period, unchanged from 0001262039-15-000016:mdna:92]

[0001262039-15-000024:mdna:126]
There have been no material changes outside the ordinary course of business during the six months ended June 30, 2015 to the contractual obligations and commitments disclosed in Management’s Discussion and Analysis of Financial Condition and Results of Operations, set forth in Part II, Item 7, of the Form 10-K. See Note 8 to the notes to the condensed consolidated financial statements included in Part I, Item 1 of this Form 10-Q for additional information regarding contractual obligations and commitments.

[0001262039-15-000024:mdna:127]
[same as prior period, unchanged from 0001262039-15-000016:mdna:94]

[0001262039-15-000024:mdna:128]
As of June 30, 2015, we did not have any relationships with unconsolidated organizations or financial partnerships, such as structured finance or special purpose entities that would have been established for the purpose of facilitating off-balance sheet arrangements or other contractually narrow or limited purposes.
