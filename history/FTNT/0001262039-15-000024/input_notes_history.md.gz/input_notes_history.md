# FTNT note change history — 0001262039-15-000016 → 0001262039-15-000024


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2015-08-04):
[0001262039-15-000024:note_history:1]
The following table summarizes our future principal contractual obligations as of June 30, 2015 (in thousands):
  (was, 2015-05-01, similarity 0.9577):
[0001262039-15-000016:note_history:1]
The following table summarizes our future principal contractual obligations as of March 31, 2015 (in thousands):

- changed (2015-08-04):
[0001262039-15-000024:note_history:2]
|  | Total |  | 2015 (remainder) |  | 2016 |  | 2017 |  | 2018 |  | 2019 |  | Thereafter |
| Operating lease commitments | $ | 50,093 |  |  | $ | 7,064 |  |  | $ | 12,054 |  |  | $ | 8,536 |  |  | $ | 6,865 |  |  | $ | 5,684 |  |  | $ | 9,890 |  |
| Less: sublease rental income | 57 |  |  | 57 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Operating lease commitments—net | 50,036 |  |  | 7,007 |  |  | 12,054 |  |  | 8,536 |  |  | 6,865 |  |  | 5,684 |  |  | 9,890 |  |
| Inventory purchase commitments | 74,322 |  |  | 74,322 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Other contractual commitments and open purchase orders | 33,944 |  |  | 28,729 |  |  | 3,675 |  |  | 978 |  |  | 305 |  |  | 193 |  |  | 64 |  |
| Total | $ | 158,302 |  |  | $ | 110,058 |  |  | $ | 15,729 |  |  | $ | 9,514 |  |  | $ | 7,170 |  |  | $ | 5,877 |  |  | $ | 9,954 |  |
  (was, 2015-05-01, similarity 0.827):
[0001262039-15-000016:note_history:2]
|  | Total |  | 2015 (remainder) |  | 2016 |  | 2017 |  | 2018 |  | 2019 |  | Thereafter |
| Operating lease commitments | $ | 40,130 |  |  | $ | 9,560 |  |  | $ | 9,453 |  |  | $ | 7,252 |  |  | $ | 6,506 |  |  | $ | 4,567 |  |  | $ | 2,792 |  |
| Less: Sublease rental income | 224 |  |  | 224 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Operating lease commitments—net | 39,906 |  |  | 9,336 |  |  | 9,453 |  |  | 7,252 |  |  | 6,506 |  |  | 4,567 |  |  | 2,792 |  |
| Inventory purchase commitments | 67,715 |  |  | 67,715 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Other contractual commitments and open purchase orders | 28,108 |  |  | 26,020 |  |  | 1,518 |  |  | 570 |  |  | — |  |  | — |  |  | — |  |
| Total | $ | 135,729 |  |  | $ | 103,071 |  |  | $ | 10,971 |  |  | $ | 7,822 |  |  | $ | 6,506 |  |  | $ | 4,567 |  |  | $ | 2,792 |  |

- changed (2015-08-04):
[0001262039-15-000024:note_history:3]
Operating Leases—We lease certain facilities under various non-cancelable operating leases, which expire through 2025. In addition to the amounts above, certain leases require us to pay variable costs such as taxes, maintenance, insurance, and asset retirement obligations. The terms of certain operating leases also provide for renewal options and escalation clauses. Rent expense was $2.9 million and $2.4 million during the three months ended June 30, 2015 and 2014, respectively. Rent expense was $6.0 million and $5.1 million during the six months ended June 30, 2015 and 2014, respectively. Rent expense is recognized using the straight-line method over the term of the lease.
  (was, 2015-05-01, similarity 0.795):
[0001262039-15-000016:note_history:3]
Operating Leases—We lease certain facilities under various non-cancelable operating leases, which expire through 2024. In addition to the amounts above, certain leases require us to pay variable costs such as taxes, maintenance, insurance, and asset retirement obligations. The terms of certain operating leases also provide for renewal options and escalation clauses. Rent expense was $3.1 million and $2.7 million during the three months ended March 31, 2015 and 2014, respectively. Rent expense is recognized using the straight-line method over the term of the lease.

- changed (2015-08-04):
[0001262039-15-000024:note_history:4]
Contract Manufacturer and Other Commitments—Our independent contract manufacturers procure components and build our products based on our forecasts. These forecasts are based on estimates of future demand for our products, which are in turn based on historical trends and analysis, adjusted for overall market conditions. In order to reduce manufacturing lead times and plan for adequate component supply, we may issue purchase orders to some of our independent contract manufacturers which may not be cancelable. As of June 30, 2015, we had $74.3 million of open purchase orders with our independent contract manufacturers.
  (was, 2015-05-01, similarity 0.9927):
[0001262039-15-000016:note_history:4]
Contract Manufacturer and Other Commitments—Our independent contract manufacturers procure components and build our products based on our forecasts. These forecasts are based on estimates of future demand for our products, which are in turn based on historical trends and analysis, adjusted for overall market conditions. In order to reduce manufacturing lead times and plan for adequate component supply, we may issue purchase orders to some of our independent contract manufacturers which may not be cancelable. As of March 31, 2015, we had $67.7 million of open purchase orders with our independent contract manufacturers.

- changed (2015-08-04):
[0001262039-15-000024:note_history:5]
In addition to commitments with contract manufacturers, we have other contractual commitments and open purchase orders in the ordinary course of business for which we have not received goods or services. As of June 30, 2015, we had $33.9 million in other contractual commitments and open purchase orders.
  (was, 2015-05-01, similarity 0.9848):
[0001262039-15-000016:note_history:5]
In addition to commitments with contract manufacturers, we have other contractual commitments and open purchase orders in the ordinary course of business for which we have not received goods or services. As of March 31, 2015, we had $28.1 million in other contractual commitments and open purchase orders.

- added (2015-08-04):
[0001262039-15-000024:note_history:6]
|  | Six Months Ended |
|  | June 30, 2015 |  | June 30, 2014 |
| Accrued warranty balance—beginning of the period | $ | 4,269 |  |  | $ | 3,037 |  |
| Warranty costs incurred | (2,059 | ) |  | (1,728 | ) |
| Provision for warranty for the period | 2,294 |  |  | 2,560 |  |
| Adjustment related to pre-existing warranties | 171 |  |  | (415 | ) |
| Accrued warranty balance—end of the period | $ | 4,675 |  |  | $ | 3,454 |  |

- changed (2015-08-04):
[0001262039-15-000024:note_history:7]
Litigation—We are involved in disputes, litigation, and other legal actions. For lawsuits where we are the defendant, we are in the process of defending these litigation matters, and while there can be no assurances and the outcome of these matters is currently not determinable, we currently believe that there are no existing claims or proceedings that are likely to have a material adverse effect on our financial position. There are many uncertainties associated with any litigation and these actions or other third-party claims against us may cause us to incur costly litigation or substantial settlement charges. In addition, the resolution of any intellectual property litigation may require us to make royalty payments, which could adversely affect our gross margins in future periods. If any of those events were to occur, our business, financial condition, results of operations, and cash flows could be adversely affected. The actual liability in any such matters may be materially different from our estimates, if any, which could result in the need to adjust the liability and record additional expenses. We have not recorded any significant accrual for loss contingencies associated with such legal proceedings; determined that a significant unfavorable outcome is probable or reasonably possible; or determined that the amount or range of any possible loss is reasonably estimable.
  (was, 2015-05-01, similarity 0.9953):
[0001262039-15-000016:note_history:7]
Litigation—We are involved in disputes, litigation, and other legal actions. For lawsuits where we are the defendant, we are in the process of defending these litigation matters, and while there can be no assurances and the outcome of these matters is currently not determinable, we currently believe that there are no existing claims or proceedings that are likely to have a material adverse effect on our financial position. There are many uncertainties associated with any litigation and these actions or other third-party claims against us may cause us to incur costly litigation or substantial settlement charges. In addition, the resolution of any intellectual property litigation may require us to make royalty payments, which could adversely affect our gross margins in future periods. If any of those events were to occur, our business, financial condition, results of operations, and cash flows could be adversely affected. The actual liability in any such matters may be materially different from our estimates, if any, which could result in the need to adjust the liability and record additional expenses. We have not recorded any significant accrual for loss contingencies associated with such legal proceedings; determined that an unfavorable outcome is probable or reasonably possible; or determined that the amount or range of any possible loss is reasonably estimable.

- removed (2015-08-04):
[0001262039-15-000016:note_history:8]
|  | Three Months Ended |
|  | March 31, 2015 |  | March 31, 2014 |
| Accrued warranty balance—beginning of the period | $ | 4,269 |  |  | $ | 3,037 |  |
| Warranty costs incurred | (1,095 | ) |  | (756 | ) |
| Provision for warranty for the period | 945 |  |  | 837 |  |
| Adjustment related to pre-existing warranties | 222 |  |  | (313 | ) |
| Accrued warranty balance—end of the period | $ | 4,341 |  |  | $ | 2,805 |  |


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2015-08-04):
[0001262039-15-000024:note_history:9]
Basis of Presentation and Preparation—The unaudited condensed consolidated financial statements of Fortinet, Inc. and its wholly-owned subsidiaries (collectively, “we,” “us” or “our”) have been prepared in accordance with generally accepted accounting principles in the United States (“GAAP”) for interim financial information as well as the instructions to Form 10-Q pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (“SEC”). Accordingly, they do not include all of the information and footnotes required by GAAP for complete financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the year ended December 31, 2014, contained in our Annual Report on Form 10-K (“Form 10-K”) filed with the SEC on March 2, 2015. In the opinion of management, all adjustments, which includes normal recurring adjustments, considered necessary for a fair presentation have been included. All intercompany balances, transactions and cash flows have been eliminated. The results of operations for the three and six months ended June 30, 2015 are not necessarily indicative of the results for the full year or for any future periods. The condensed consolidated balance sheet as of December 31, 2014 is derived from the audited consolidated financial statements for the year ended December 31, 2014.
  (was, 2015-05-01, similarity 0.984):
[0001262039-15-000016:note_history:9]
Basis of Presentation and Preparation—The unaudited condensed consolidated financial statements of Fortinet, Inc. and its wholly-owned subsidiaries (collectively, “we,” “us” or “our”) have been prepared in accordance with generally accepted accounting principles in the United States (“GAAP”) for interim financial information as well as the instructions to Form 10-Q pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (“SEC”). Accordingly, they do not include all of the information and footnotes required by GAAP for complete financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the year ended December 31, 2014, contained in our Annual Report on Form 10-K (“Form 10-K”) filed with the SEC on March 2, 2015. In the opinion of management, all adjustments, which includes normal recurring adjustments, considered necessary for a fair presentation have been included. All intercompany balances, transactions and cash flows have been eliminated. The results of operations for the three months ended March 31, 2015 are not necessarily indicative of the results for the full year or for any future periods. The condensed consolidated balance sheet as of December 31, 2014 is derived from the audited consolidated financial statements for the year ended December 31, 2014.

- changed (2015-08-04):
[0001262039-15-000024:note_history:10]
There have been no material changes to our significant accounting policies as of and for the three and six months ended June 30, 2015.
  (was, 2015-05-01, similarity 0.9317):
[0001262039-15-000016:note_history:10]
There have been no material changes to our significant accounting policies as of and for the three months ended March 31, 2015.

- changed (2015-08-04):
[0001262039-15-000024:note_history:11]
In the third quarter of 2014, we reevaluated the selected functional currency of our international subsidiaries due to the nature of our business operations and recorded the cumulative impact of the reevaluation of the functional currency in the consolidated statement of operations. Subsequently, the remeasurement of the assets and liabilities of all international subsidiaries has been recorded in the consolidated statement of operations prospectively. The impact of this reevaluation was not material for 2014 or any of our previously issued financial statements.
  (was, 2015-05-01, similarity 0.9558):
[0001262039-15-000016:note_history:11]
In the third quarter of 2014, we reevaluated the selected functional currency of our international subsidiaries due to the nature of our business operations and recorded the cumulative impact of the reevaluation of the functional currency in the consolidated statement of operations. Subsequently, the remeasurement of the assets and liabilities of all international subsidiaries has been recorded in the consolidated statement of operations prospectively. The impact of this reevaluation is not material for our fiscal 2014 or any of our previously issued financial statements.

- changed (2015-08-04):
[0001262039-15-000024:note_history:12]
Recent Accounting Pronouncements
  (was, 2015-05-01, similarity 0.9841):
[0001262039-15-000016:note_history:12]
Recent Accounting Pronouncement

- added (2015-08-04):
[0001262039-15-000024:note_history:13]
In July 2015, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update 2015-11—Inventory—Simplifying the Measurement of Inventory (Topic 330) (“ASU 2015-11”). ASU 2015-11 changes the measurement principle for inventory from the lower of cost or market to lower of cost and net realizable value. It applies to entities that measure inventory using a method other than last-in, first-out or the retail inventory method (e.g., first-in first-out, average cost). ASU 2015-11 will be effective for us beginning on January 1, 2017. We are currently evaluating the impact of ASU 2015-11 on our consolidated financial statements.

- changed (2015-08-04):
[0001262039-15-000024:note_history:14]
In May 2014, the FASB issued Accounting Standards Update No. 2014-09—Revenue from Contracts with Customers (Topic 606) (“ASU 2014-09”) to create a single, joint revenue standard that is consistent across all industries and markets for companies that prepare their financial statements in accordance with GAAP. Under ASU 2014-09, an entity is required to recognize revenue upon the transfer of promised goods or services to customers in an amount that reflects the consideration the entity expects to be entitled to receive in exchange for those goods or services. In July 2015, the FASB decided to delay the effective date of the new revenue standard by one year. As such, ASU 2014-09 will be effective for us beginning on January 1, 2018, with the option to adopt earlier on January 1, 2017. We are currently evaluating the impact of ASU 2014-09 on our consolidated financial statements.
  (was, 2015-05-01, similarity 0.7066):
[0001262039-15-000016:note_history:14]
In May 2014, the Financial Accounting Standards Board issued Accounting Standards Update No. 2014-09—Revenue from Contracts with Customers (Topic 606) (“ASU 2014-09”) to create a single, joint revenue standard that is consistent across all industries and markets for companies that prepare their financial statements in accordance with GAAP. Under ASU 2014-09, an entity is required to recognize revenue upon the transfer of promised goods or services to customers in an amount that reflects the consideration the entity expects to be entitled to receive in exchange for those goods or services. ASU 2014-09 is effective for us beginning on January 1, 2017. We are currently evaluating the impact of ASU 2014-09 on our consolidated financial statements.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2015-08-04):
[0001262039-15-000024:note_history:15]
The son of one member of our Board of Directors (“Board”) is a partner of an outside law firm that we utilize for certain complex litigation matters. Expenses for legal services provided by the law firm related to matters that arose subsequent to the member joining our Board were $0.9 million and $0.5 million for the three months ended June 30, 2015 and June 30, 2014, respectively. Expenses for legal services provided by the law firm related to matters that arose subsequent to the member joining our Board were $2.8 million and $0.7 million for the six months ended June 30, 2015 and June 30, 2014, respectively. Amounts due and payable to the law firm were $2.3 million and $1.3 million as of June 30, 2015 and December 31, 2014, respectively.
  (was, 2015-05-01, similarity 0.6513):
[0001262039-15-000016:note_history:15]
The son of one member of our Board is a partner of an outside law firm that we utilize for certain complex litigation matters. Expenses for legal services provided by the law firm related to matters that arose subsequent to the member joining our Board were $1.9 million and $0.3 million for the three months ended March 31, 2015 and March 31, 2014, respectively.  Amounts due and payable to the law firm were $1.7 million and $1.3 million as of March 31, 2015 and December 31, 2014, respectively.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_prior_note, score: 0.0

- added (2015-08-04):
[0001262039-15-000024:note_history:16]
SUBSEQUENT EVENT

- added (2015-08-04):
[0001262039-15-000024:note_history:17]
In July 2015, we acquired Meru Networks, Inc. (“Meru”), which offers Wi-Fi networking solutions, for a total consideration of approximately $44.0 million. The acquisition expands on our secure wireless vision and enterprise growth focus, broadens our portfolio of solutions , and expands our opportunity to address the global enterprise Wi-Fi market with integrated secure wireless solutions. We are still in the process of evaluating the business combination accounting considerations, including the consideration transferred and the initial purchase price allocation.
