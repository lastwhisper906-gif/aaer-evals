# FTNT notes — 0001262039-23-000038


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001262039-23-000038:notes:1]
SUMMARY OF SIGNIFICANT ACCOUNTING POLICIES
Basis of Presentation and Preparation—The unaudited condensed consolidated financial statements of Fortinet, Inc. and its subsidiaries (collectively, “we,” “us” or “our”) have been prepared in accordance with generally accepted accounting principles in the United States (“GAAP”) for interim financial information, as well as the instructions to Form 10-Q pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (the “SEC”). Accordingly, they do not include all of the information and footnotes required by GAAP for complete financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the year ended December 31, 2022, contained in our Annual Report on Form 10-K filed with the SEC on February 24, 2023. In the opinion of management, all adjustments, which include normal recurring adjustments, considered necessary for a fair presentation, have been included. The results of operations for the three and nine months ended September 30, 2023 are not necessarily indicative of the results to be expected for the full year or for any future periods. The condensed consolidated balance sheet as of December 31, 2022 is derived from the audited consolidated financial statements for the year ended December 31, 2022.

[0001262039-23-000038:notes:2]
[same as prior period, unchanged from 0001262039-23-000032:notes:2]

[0001262039-23-000038:notes:3]
[same as prior period, unchanged from 0001262039-23-000032:notes:3]

[0001262039-23-000038:notes:4]
[same as prior period, unchanged from 0001262039-23-000032:notes:4]

[0001262039-23-000038:notes:5]
There have been no material changes to our significant accounting policies as of and for the three and nine months ended September 30, 2023, as compared to the significant accounting policies described in the Form 10-K.

[0001262039-23-000038:notes:6]
Recently Adopted and Recently Issued Accounting Standards

[0001262039-23-000038:notes:7]
There were no recently adopted accounting standards which would have a material effect on our condensed consolidated financial statements and accompanying disclosures, and no recently issued accounting standards that are expected to have a material impact on our condensed consolidated financial statements and accompanying disclosures.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001262039-23-000038:notes:8]
[same as prior period, unchanged from 0001262039-23-000032:notes:8]

[0001262039-23-000038:notes:9]
[same as prior period, unchanged from 0001262039-23-000032:notes:9]

[0001262039-23-000038:notes:10]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30,2023 |  | September 30,2022 |  | September 30,2023 |  | September 30,2022 |
| Product | $ | 465.9 |  |  | $ | 468.7 |  |  | $ | 1,439.2 |  |  | $ | 1,240.4 |  |
| Service: |  |  |  |  |  |  |  |
| Security subscription | 494.6 |  |  | 369.8 |  |  | 1,373.6 |  |  | 1,023.1 |  |
| Technical support and other | 374.1 |  |  | 311.0 |  |  | 1,076.9 |  |  | 870.9 |  |
| Total service revenue | 868.7 |  |  | 680.8 |  |  | 2,450.5 |  |  | 1,894.0 |  |
| Total revenue | $ | 1,334.6 |  |  | $ | 1,149.5 |  |  | $ | 3,889.7 |  |  | $ | 3,134.4 |  |

[0001262039-23-000038:notes:11]
[same as prior period, unchanged from 0001262039-23-000032:notes:11]

[0001262039-23-000038:notes:12]
During the three and nine months ended September 30, 2023, we recognized $514.3 million and $1.80 billion in service revenue that was included in the deferred revenue balance as of December 31, 2022, respectively. During the three and nine months ended September 30, 2022, we recognized $401.9 million and $1.37 billion in service revenue that was included in the deferred revenue balance as of December 31, 2021, respectively.

[0001262039-23-000038:notes:13]
[same as prior period, unchanged from 0001262039-23-000032:notes:13]

[0001262039-23-000038:notes:14]
As of September 30, 2023, the aggregate amount of the transaction price allocated to remaining performance obligations was $5.30 billion, which was substantially comprised of deferred security subscription, technical support services revenue and unbilled contract revenue from non-cancellable contracts that will be recognized in future periods. We expect to recognize approximately $2.66 billion as revenue over the next 12 months and the remainder thereafter.

[0001262039-23-000038:notes:15]
Accounts Receivable

[0001262039-23-000038:notes:16]
[same as prior period, unchanged from 0001262039-23-000032:notes:16]

[0001262039-23-000038:notes:17]
The allowance for credit losses was $5.3 million and $3.6 million as of September 30, 2023 and December 31, 2022, respectively. Provisions, write-offs and recoveries were not material during the nine months ended September 30, 2023 and 2022.

[0001262039-23-000038:notes:18]
[same as prior period, unchanged from 0001262039-23-000032:notes:18]

[0001262039-23-000038:notes:19]
Amortization of deferred contract costs during the three months ended September 30, 2023 and 2022 were $68.0 million and $56.7 million, respectively. Amortization of deferred contract costs during the nine months ended September 30, 2023 and 2022 were $195.9 million and $163.8 million, respectively.


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0001262039-23-000038:notes:20]
FINANCIAL INSTRUMENTS AND FAIR VALUE
Available-for-Sale Securities

[0001262039-23-000038:notes:21]
[same as prior period, unchanged from 0001262039-23-000032:notes:21]

[0001262039-23-000038:notes:22]
|  | September 30, 2023 |
|  | AmortizedCost |  | UnrealizedGains |  | UnrealizedLosses |  | FairValue |
| U.S. government and agency securities | $ | 423.4 |  |  | $ | 0.1 |  |  | $ | (0.5) |  |  | $ | 423.0 |  |
| Commercial paper | 400.0 |  |  | — |  |  | (0.3) |  |  | 399.7 |  |
| Certificates of deposit and term deposits | 73.5 |  |  | — |  |  | — |  |  | 73.5 |  |
| Corporate debt securities | 68.0 |  |  | — |  |  | (0.5) |  |  | 67.5 |  |
| Total available-for-sale securities | $ | 964.9 |  |  | $ | 0.1 |  |  | $ | (1.3) |  |  | $ | 963.7 |  |

[0001262039-23-000038:notes:23]
|  | December 31, 2022 |
|  | AmortizedCost |  | UnrealizedGains |  | UnrealizedLosses |  | FairValue |
| U.S. government and agency securities | $ | 198.0 |  |  | $ | — |  |  | $ | (4.4) |  |  | $ | 193.6 |  |
| Commercial paper | 26.5 |  |  | — |  |  | (0.1) |  |  | 26.4 |  |
| Certificates of deposit and term deposits | 34.2 |  |  | — |  |  | — |  |  | 34.2 |  |
| Corporate debt securities | 293.0 |  |  | — |  |  | (4.1) |  |  | 288.9 |  |
| Municipal bonds | 5.1 |  |  | — |  |  | (0.1) |  |  | 5.0 |  |
| Total available-for-sale securities | $ | 556.8 |  |  | $ | — |  |  | $ | (8.7) |  |  | $ | 548.1 |  |

[0001262039-23-000038:notes:24]
[same as prior period, unchanged from 0001262039-23-000032:notes:24]

[0001262039-23-000038:notes:25]
|  | September 30, 2023 |
|  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
|  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |
| U.S. government and agency securities | $ | 159.1 |  |  | $ | (0.1) |  |  | $ | 32.6 |  |  | $ | (0.4) |  |  | $ | 191.7 |  |  | $ | (0.5) |  |
| Commercial paper | 376.6 |  |  | (0.3) |  |  | — |  |  | — |  |  | 376.6 |  |  | (0.3) |  |
| Corporate debt securities | 15.3 |  |  | — |  |  | 46.4 |  |  | (0.5) |  |  | 61.7 |  |  | (0.5) |  |
| Total available-for-sale securities | $ | 551.0 |  |  | $ | (0.4) |  |  | $ | 79.0 |  |  | $ | (0.9) |  |  | $ | 630.0 |  |  | $ | (1.3) |  |

[0001262039-23-000038:notes:26]
[same as prior period, unchanged from 0001262039-23-000032:notes:26]

[0001262039-23-000038:notes:27]
[same as prior period, unchanged from 0001262039-23-000032:notes:27]

[0001262039-23-000038:notes:28]
|  | September 30,2023 |  | December 31,2022 |
| Due within one year | $ | 962.2 |  |  | $ | 502.6 |  |
| Due within one to three years | 1.5 |  |  | 45.5 |  |
| Total | $ | 963.7 |  |  | $ | 548.1 |  |

[0001262039-23-000038:notes:29]
[same as prior period, unchanged from 0001262039-23-000032:notes:29]

[0001262039-23-000038:notes:30]
[same as prior period, unchanged from 0001262039-23-000032:notes:30]

[0001262039-23-000038:notes:31]
[same as prior period, unchanged from 0001262039-23-000032:notes:31]

[0001262039-23-000038:notes:32]
Our marketable equity securities were $19.8 million and $25.5 million as of September 30, 2023 and December 31, 2022. The changes in fair value of our marketable equity securities are recorded in other expense—net on the condensed consolidated statements of income. We recognized a $2.3 million and $5.7 million loss during the three and nine months ended September 30, 2023, respectively. We recognized a $2.6 million gain and a $11.7 million loss during the three and nine months ended September 30, 2022, respectively.

[0001262039-23-000038:notes:33]
[same as prior period, unchanged from 0001262039-23-000032:notes:33]

[0001262039-23-000038:notes:34]
[same as prior period, unchanged from 0001262039-23-000032:notes:34]

[0001262039-23-000038:notes:35]
[same as prior period, unchanged from 0001262039-23-000032:notes:35]

[0001262039-23-000038:notes:36]
[same as prior period, unchanged from 0001262039-23-000032:notes:36]

[0001262039-23-000038:notes:37]
[same as prior period, unchanged from 0001262039-23-000032:notes:37]

[0001262039-23-000038:notes:38]
[same as prior period, unchanged from 0001262039-23-000032:notes:38]

[0001262039-23-000038:notes:39]
[same as prior period, unchanged from 0001262039-23-000032:notes:39]

[0001262039-23-000038:notes:40]
[same as prior period, unchanged from 0001262039-23-000032:notes:40]

[0001262039-23-000038:notes:41]
[same as prior period, unchanged from 0001262039-23-000032:notes:41]

[0001262039-23-000038:notes:42]
[same as prior period, unchanged from 0001262039-23-000032:notes:42]

[0001262039-23-000038:notes:43]
|  | September 30, 2023 |  | December 31, 2022 |
|  | AggregateFairValue |  | QuotedPrices inActiveMarkets ForIdenticalAssets |  | SignificantOtherObservableRemainingInputs |  | SignificantOtherUnobservableRemainingInputs |  | AggregateFairValue |  | QuotedPrices inActiveMarkets ForIdenticalAssets |  | SignificantOtherObservableRemainingInputs |  | SignificantOtherUnobservableRemainingInputs |
|  |  |  | (Level 1) |  | (Level 2) |  | (Level 3) |  |  |  | (Level 1) |  | (Level 2) |  | (Level 3) |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. government and agency securities | $ | 474.1 |  |  | $ | 402.4 |  |  | $ | 71.7 |  |  | $ | — |  |  | $ | 268.6 |  |  | $ | 259.3 |  |  | $ | 9.3 |  |  | $ | — |  |
| Commercial paper | 439.5 |  |  | — |  |  | 439.5 |  |  | — |  |  | 115.8 |  |  | — |  |  | 115.8 |  |  | — |  |
| Certificates of deposit and term deposits | 93.5 |  |  | — |  |  | 93.5 |  |  | — |  |  | 50.4 |  |  | — |  |  | 50.4 |  |  | — |  |
| Corporate debt securities | 67.5 |  |  | — |  |  | 67.5 |  |  | — |  |  | 288.9 |  |  | — |  |  | 288.9 |  |  | — |  |
| Money market funds | 325.0 |  |  | 325.0 |  |  | — |  |  | — |  |  | 593.9 |  |  | 593.9 |  |  | — |  |  | — |  |
| Municipal bonds | — |  |  | — |  |  | — |  |  | — |  |  | 5.0 |  |  | — |  |  | 5.0 |  |  | — |  |
| Marketable equity securities | 19.8 |  |  | 19.8 |  |  | — |  |  | — |  |  | 25.5 |  |  | 25.5 |  |  | — |  |  | — |  |
| Total | $ | 1,419.4 |  |  | $ | 747.2 |  |  | $ | 672.2 |  |  | $ | — |  |  | $ | 1,348.1 |  |  | $ | 878.7 |  |  | $ | 469.4 |  |  | $ | — |  |
| Reported as: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents | $ | 435.9 |  |  |  |  |  |  |  |  | $ | 774.5 |  |  |  |  |  |  |  |
| Marketable equity securities | 19.8 |  |  |  |  |  |  |  |  | 25.5 |  |  |  |  |  |  |  |
| Short-term investments | 962.2 |  |  |  |  |  |  |  |  | 502.6 |  |  |  |  |  |  |  |
| Long-term investments | 1.5 |  |  |  |  |  |  |  |  | 45.5 |  |  |  |  |  |  |  |
| Total | $ | 1,419.4 |  |  |  |  |  |  |  |  | $ | 1,348.1 |  |  |  |  |  |  |  |

[0001262039-23-000038:notes:44]
There were no transfers between Level 1 and Level 2 of the fair value hierarchy during the nine months ended September 30, 2023 and year ended December 31, 2022.


## us-gaap:InventoryDisclosureTextBlock

[0001262039-23-000038:notes:45]
[same as prior period, unchanged from 0001262039-23-000032:notes:45]

[0001262039-23-000038:notes:46]
|  | September 30,2023 |  | December 31,2022 |
| Raw materials | $ | 77.5 |  |  | $ | 46.3 |  |
| Work in process | 8.0 |  |  | 12.0 |  |
| Finished goods | 382.0 |  |  | 206.3 |  |
| Inventory | $ | 467.5 |  |  | $ | 264.6 |  |


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001262039-23-000038:notes:47]
[same as prior period, unchanged from 0001262039-23-000032:notes:47]

[0001262039-23-000038:notes:48]
|  | September 30,2023 |  | December 31,2022 |
| Land | $ | 351.7 |  |  | $ | 310.0 |  |
| Buildings and improvements | 591.7 |  |  | 490.3 |  |
| Computer equipment and software | 252.3 |  |  | 222.7 |  |
| Leasehold improvements | 60.6 |  |  | 53.5 |  |
| Evaluation units | 27.5 |  |  | 19.2 |  |
| Furniture and fixtures | 30.5 |  |  | 31.3 |  |
| Construction-in-progress | 55.8 |  |  | 51.7 |  |
| Total property and equipment | 1,370.1 |  |  | 1,178.7 |  |
| Less: accumulated depreciation | (332.1) |  |  | (280.2) |  |
| Property and equipment—net | $ | 1,038.0 |  |  | $ | 898.5 |  |

[0001262039-23-000038:notes:49]
During the three months ended June 30, 2023, we purchased certain real estate in Spain and the United States for a total purchase price of $51.9 million. The purchases were accounted for under the asset acquisition method. The cost of the assets acquired was allocated to land and buildings and improvements based on their relative fair values. The total purchase price was allocated as $6.5 million to land and $45.4 million to buildings and improvements.

[0001262039-23-000038:notes:50]
During the three months ended September 30, 2023, we purchased certain real estate in Australia for a total purchase price of $41.3 million. The purchase was accounted for under the asset acquisition method. The cost of the assets acquired was allocated to land and construction-in-progress based on their relative fair values. The total purchase price was allocated as $21.5 million to land and $19.8 million to construction-in-progress.

[0001262039-23-000038:notes:51]
Depreciation expense was $23.9 million and $21.2 million during the three months ended September 30, 2023 and 2022, respectively. Depreciation expense was $69.6 million and $59.4 million during the nine months ended September 30, 2023 and 2022, respectively.


## us-gaap:InvestmentTextBlock

[0001262039-23-000038:notes:52]
[same as prior period, unchanged from 0001262039-23-000032:notes:51]

[0001262039-23-000038:notes:53]
[same as prior period, unchanged from 0001262039-23-000032:notes:52]

[0001262039-23-000038:notes:54]
We have concluded that our investment in Linksys is an in-substance common stock investment and that we do not hold an absolute controlling financial interest in Linksys, but that we have the ability to exercise significant influence over the operating and financial policies of Linksys. Determining that we have significant influence but not control over the operating and financial policies of Linksys required significant judgement of many factors, including but not limited to the ownership interest in Linksys, board representation, participation in policy-making processes and participation rights in certain significant financial and operating decisions of Linksys in the ordinary course of business. Therefore, we determined to account for this investment using the equity method of accounting. We record our share of Linksys’ financial results on a three-month lag basis. We determined that there was a basis difference between the cost of our investment in Linksys and the amount of underlying equity in net assets of Linksys. Our share of loss of Linksys’ financial results, as well as our share of the amortization of the basis differences, totaled $5.2 million and $6.3 million for the three months ended September 30, 2023 and 2022, respectively, and has been recorded in loss from equity method investment on the condensed consolidated statements of income. Our share of loss of Linksys’ financial results, as well as our share of the amortization of the basis differences, totaled $32.6 million and $22.9 million for the nine months ended September 30, 2023 and 2022, respectively, and has been recorded in loss from equity method investment on the condensed consolidated statements of income. The carrying amount of our Linksys investment was $51.6 million and $84.3 million as of September 30, 2023 and December 31, 2022, respectively, and the investment was included in other assets on our condensed consolidated balance sheets.

[0001262039-23-000038:notes:55]
In the fourth quarter of 2022, we recorded a non-cash charge of $22.2 million related to other-than-temporary impairment (“OTTI”) recognized on our equity method investment in Linksys and our proportionate share of Linksys' financial results included a $17.5 million charge in connection with a valuation allowance established on deferred tax assets at Linksys. Due to the presence of impairment indicators, such as a series of operating losses, we evaluated our equity method investment for an OTTI during the three months ended September 30, 2023. We considered various factors in determining whether an OTTI has occurred, including the limited operating history available, our ability and intent to hold the investment until its fair value recovers, the implied revenue valuation multiples compared to guideline public companies, Linksys’ ability to achieve milestones and any notable operational and strategic changes. After the evaluation, we determined that an additional OTTI has not occurred as of September 30, 2023. However, we may be required to recognize an impairment loss in future reporting periods if and when our evaluation of the aforementioned factors indicates that the investment in Linksys is determined to be other than temporarily impaired. Such determination will be based on the prevailing facts and circumstances at that time, including the results and disclosures of Linksys.

[0001262039-23-000038:notes:56]
Other Investment

[0001262039-23-000038:notes:57]
On August 1, 2023, we invested $8.5 million in cash for a 19.5% ownership interest in the outstanding common stock of a privately held company that provides rugged ethernet switches, 4G/5G industrial routers and media converters for critical infrastructure customers. We accounted for our investment as an equity method investment since we have the ability to exercise significant influence, but not control, over the operating and financial policies of the privately-held company.

[0001262039-23-000038:notes:58]
We will record our proportionate share of the company’s financial results on a three-month lag basis and will present it in loss from equity method investments—net on the condensed consolidated statements of income.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001262039-23-000038:notes:59]
[same as prior period, unchanged from 0001262039-23-000032:notes:55]


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001262039-23-000038:notes:60]
[same as prior period, unchanged from 0001262039-23-000032:notes:56]

[0001262039-23-000038:notes:61]
[same as prior period, unchanged from 0001262039-23-000032:notes:57]

[0001262039-23-000038:notes:62]
|  | Amount |
| Balance—December 31, 2022 | $ | 128.0 |  |
| Foreign currency translation adjustments | (2.6) |  |
| Balance—September 30, 2023 | $ | 125.4 |  |

[0001262039-23-000038:notes:63]
There were no impairments to goodwill during the nine months ended September 30, 2023 or during prior periods.

[0001262039-23-000038:notes:64]
[same as prior period, unchanged from 0001262039-23-000032:notes:60]

[0001262039-23-000038:notes:65]
[same as prior period, unchanged from 0001262039-23-000032:notes:61]

[0001262039-23-000038:notes:66]
|  | September 30, 2023 |
|  | Weighted-Average Useful Life (in Years) |  | Gross |  | Accumulated Amortization |  | Net |
| Other intangible assets—net: |  |  |  |  |  |  |  |
| Finite-lived intangible assets: |  |  |  |  |  |  |  |
| Developed technologies | 4.3 |  | $ | 82.3 |  |  | $ | 59.7 |  |  | $ | 22.6 |  |
| Customer relationships | 7.0 |  | 30.0 |  |  | 16.7 |  |  | 13.3 |  |
| Trade name | 10.0 |  | 4.7 |  |  | 1.0 |  |  | 3.7 |  |
| Backlog | 1.0 |  | 3.7 |  |  | 3.7 |  |  | — |  |
| Total other intangible assets—net |  |  | $ | 120.7 |  |  | $ | 81.1 |  |  | $ | 39.6 |  |

[0001262039-23-000038:notes:67]
[same as prior period, unchanged from 0001262039-23-000032:notes:63]

[0001262039-23-000038:notes:68]
Amortization expense was $4.4 million and $5.2 million during the three months ended September 30, 2023 and 2022, respectively. Amortization expense was $13.6 million and $17.6 million during the nine months ended September 30, 2023 and 2022, respectively.

[0001262039-23-000038:notes:69]
[same as prior period, unchanged from 0001262039-23-000032:notes:65]

[0001262039-23-000038:notes:70]
|  | Amount |
| Years: |  |
| 2023 (the remainder of 2023) | $ | 4.0 |  |
| 2024 | 12.7 |  |
| 2025 | 8.2 |  |
| 2026 | 4.1 |  |
| 2027 | 3.8 |  |
| Thereafter | 6.8 |  |
| Total | $ | 39.6 |  |


## us-gaap:EarningsPerShareTextBlock

[0001262039-23-000038:notes:71]
[same as prior period, unchanged from 0001262039-23-000032:notes:67]

[0001262039-23-000038:notes:72]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30,2023 |  | September 30,2022 |  | September 30,2023 |  | September 30,2022 |
| Numerator: |  |  |  |  |  |  |  |
| Net income including non-controlling interests | $ | 322.9 |  |  | $ | 231.1 |  |  | $ | 836.9 |  |  | $ | 542.8 |  |
| Net loss attributable to non-controlling interests | — |  |  | (0.5) |  |  | — |  |  | (0.7) |  |
| Net income attributable to Fortinet, Inc. | $ | 322.9 |  |  | $ | 231.6 |  |  | $ | 836.9 |  |  | $ | 543.5 |  |
| Denominator: |  |  |  |  |  |  |  |
| Basic shares: |  |  |  |  |  |  |  |
| Weighted-average common stock outstanding-basic | 781.2 |  |  | 786.2 |  |  | 783.1 |  |  | 795.0 |  |
| Diluted shares: |  |  |  |  |  |  |  |
| Weighted-average common stock outstanding-basic | 781.2 |  |  | 786.2 |  |  | 783.1 |  |  | 795.0 |  |
| Effect of potentially dilutive securities: |  |  |  |  |  |  |  |
| RSUs | 3.5 |  |  | 4.9 |  |  | 3.8 |  |  | 6.6 |  |
| Stock options | 6.2 |  |  | 7.5 |  |  | 6.4 |  |  | 8.2 |  |
| PSUs | 0.3 |  |  | — |  |  | 0.2 |  |  | — |  |
| Weighted-average shares used to compute diluted net income per share attributable to Fortinet, Inc. | 791.2 |  |  | 798.6 |  |  | 793.5 |  |  | 809.8 |  |
| Net income per share attributable to Fortinet, Inc.: |  |  |  |  |  |  |  |
| Basic | $ | 0.41 |  |  | $ | 0.29 |  |  | $ | 1.07 |  |  | $ | 0.68 |  |
| Diluted | $ | 0.41 |  |  | $ | 0.29 |  |  | $ | 1.05 |  |  | $ | 0.67 |  |

[0001262039-23-000038:notes:73]
[same as prior period, unchanged from 0001262039-23-000032:notes:69]

[0001262039-23-000038:notes:74]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30,2023 |  | September 30,2022 |  | September 30,2023 |  | September 30,2022 |
| RSUs | — |  |  | 2.5 |  |  | 0.6 |  |  | 1.1 |  |
| Stock options | 3.0 |  |  | 1.6 |  |  | 2.8 |  |  | 1.4 |  |
| Total | 3.0 |  |  | 4.1 |  |  | 3.4 |  |  | 2.5 |  |


## us-gaap:DebtDisclosureTextBlock

[0001262039-23-000038:notes:75]
DEBT
2026 and 2031 Senior Notes

[0001262039-23-000038:notes:76]
On March 5, 2021, we issued $1.0 billion aggregate principal amount of senior notes (collectively, the “Senior Notes”), consisting of $500.0 million aggregate principal amount of 1.0% notes due March 15, 2026 (the “2026 Senior Notes”) and $500.0 million aggregate principal amount of 2.2% notes due March 15, 2031 (the “2031 Senior Notes”), in an underwritten registered public offering. The Senior Notes are senior unsecured obligations and rank equally with each other in right of payment and with our other outstanding obligations. We may redeem the Senior Notes at any time in whole or in part for cash, at specified redemption prices that include accrued and unpaid interest, if any, and a make-whole premium. However, no make-whole premium will be paid for redemptions of the 2026 Senior Notes on or after February 15, 2026, or the 2031 Senior Notes on or after December 15, 2030. Interest on the Senior Notes is payable on March 15 and September 15 of each year, beginning on September 15, 2021. As of September 30, 2023 and December 31, 2022, the Senior Notes were recorded as long-term debt, net of discount and issuance costs, which are amortized to interest expense over the respective contractual terms of these notes using the effective interest method.

[0001262039-23-000038:notes:77]
The total outstanding debt is summarized below (in millions, except percentages):

[0001262039-23-000038:notes:78]
|  | Maturity |  | Coupon Rate |  | Effective Interest Rate |  | September 30,2023 |  | December 31,2022 |
| Debt |  |  |  |  |  |  |  |  |  |
| 2026 Senior Notes | March 2026 |  | 1.0% |  | 1.3% |  | $ | 500.0 |  |  | $ | 500.0 |  |
| 2031 Senior Notes | March 2031 |  | 2.2% |  | 2.3% |  | 500.0 |  |  | 500.0 |  |
| Total debt |  |  |  |  |  |  | 1,000.0 |  |  | 1,000.0 |  |
| Less: Unamortized discount and debt issuance costs |  |  |  |  |  |  | 8.2 |  |  | 9.6 |  |
| Total long-term debt |  |  |  |  |  |  | $ | 991.8 |  |  | $ | 990.4 |  |

[0001262039-23-000038:notes:79]
As of September 30, 2023 and December 31, 2022, we accrued interest payable of $0.7 million and $4.7 million, respectively, and there are no financial covenants with which we must comply. During the three months ended September 30, 2023 and 2022, we recorded $4.5 million and $4.4 million of total interest expense in relation to these Senior Notes in each quarter, respectively. During the nine months ended September 30, 2023 and 2022, we recorded $13.5 million and $13.4 million of total interest expense in relation to the Senior Notes in each period, respectively. No interest costs were capitalized for the nine months ended September 30, 2023 and 2022, as the costs that qualified for capitalization were not material.

[0001262039-23-000038:notes:80]
The total estimated fair value of the outstanding Senior Notes was approximately $834.8 million, including accrued and unpaid interest, as of September 30, 2023. The fair value was determined based on observable market prices of identical instruments in less active markets. The estimated fair values are based on Level 2 inputs.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001262039-23-000038:notes:81]
COMMITMENTS AND CONTINGENCIES
The following table summarizes our inventory purchase commitments as of September 30, 2023 (in millions):

[0001262039-23-000038:notes:82]
|  | Total |  | 2023 |  | Thereafter |
| Inventory purchase commitments | $ | 820.6 |  |  | $ | 608.5 |  |  | $ | 212.1 |  |

[0001262039-23-000038:notes:83]
Inventory Purchase Commitments—Our independent contract manufacturers and certain component suppliers procure components and build our products based on our forecasts, the availability of various components and their capacity. These forecasts are based on estimates of future demand for our products, which are in turn based on historical trends and an analysis from our sales and marketing organizations, adjusted for lead times, changes in supplier delivery commitments and other supply chain matters and market conditions. In order to manage manufacturing lead times, plan for adequate component supply and incentivize suppliers to deliver, we may issue purchase orders to some of our independent contract manufacturers, which are non-cancelable. As of September 30, 2023, we had $820.6 million of open purchase orders with our independent contract manufacturers that consist of non-cancelable commitments. In certain instances, these agreements allow us the option to reschedule and adjust our requirements based on our business needs prior to firm orders being placed. We recorded a liability

[0001262039-23-000038:notes:84]
for non-cancelable inventory purchase commitments for quantities in excess of our future estimated demand forecasts, consistent with the valuation of our excess and obsolete inventory. As of September 30, 2023, the liability for these inventory purchase commitments was $64.6 million and was included in accrued liabilities. As of December 31, 2022, the liability for these purchase commitments was not material. The expense related to such accrued liability for inventory purchase commitments was $36.9 million and $59.3 million during the three and nine months ended September 30, 2023, respectively, and was recorded in product cost of revenue on the condensed consolidated statements of income.

[0001262039-23-000038:notes:85]
Other Contractual Commitments and Open Purchase Orders—In addition to commitments with contract manufacturers, we have open purchase orders and contractual obligations in the ordinary course of business for which we have not received goods or services. A significant portion of our reported purchase commitments consist of non-cancelable commitments. In certain instances, contractual commitments allow us the option to cancel, reschedule and adjust our requirements based on our business needs prior to firm orders being placed. As of September 30, 2023, we had $76.8 million in other contractual commitments having a remaining term in excess of one year that are non-cancelable.

[0001262039-23-000038:notes:86]
As of September 30, 2023, we had $89.5 million in contractual commitments related to payments for operating leases.

[0001262039-23-000038:notes:87]
Litigation—We are involved in disputes, litigation, and other legal actions. For lawsuits where we are the defendant, we are in the process of defending these litigation matters, and while there can be no assurances and the outcome of certain of these matters is currently not determinable and not predictable, we currently are unaware of any existing claims or proceedings that we believe are likely to have a material adverse effect on our financial position. There are many uncertainties associated with any litigation and these actions or other third-party claims against us may cause us to incur costly litigation fees, costs and substantial settlement charges, and possibly subject us to damages and other penalties. In addition, the resolution of any intellectual property (“IP”) litigation may require us to make royalty payments, which could adversely affect our gross margins in future periods. If any of those events were to occur, our business, financial condition, results of operations, and cash flows could be adversely affected. Litigation is unpredictable and the actual liability in any such matters may be materially different from our current estimates, which could result in the need to adjust any accrued liability and record additional expenses. We accrue for contingencies when we believe that a loss is probable and that we can reasonably estimate the amount of any such loss. These accruals are generally based on a range of possible outcomes that require significant management judgement. If no amount within a range is a better estimate than any other, we accrue the minimum amount. Litigation loss contingency accruals associated with outstanding cases were not material as of September 30, 2023, and December 31, 2022.

[0001262039-23-000038:notes:88]
On March 21, 2019, we were sued by Alorica Inc. (“Alorica”) in Santa Clara County Superior Court in California. Alorica has alleged breach of warranty and misrepresentation claims, which we deny. Fact discovery closed during the quarter ended June 30, 2023. Although we believe that the ultimate outcome of this matter will not materially impact our financial position, results of operations or cash flows, legal proceedings are subject to inherent uncertainties, and an unfavorable ruling could occur, which may result in a material adverse impact on our business, financial position, results of operations and cash flows. No loss accrual had been recorded as of September 30, 2023 or December 31, 2022 related to this litigation.

[0001262039-23-000038:notes:89]
Indemnification and Other Matters—Under the indemnification provisions of our standard sales contracts, we agree to defend our customers against third-party claims asserting various allegations such as product defects and infringement of certain IP rights, which may include patents, copyrights, trademarks or trade secrets, and to pay judgments entered on such claims. In some contracts, our exposure under these indemnification provisions is limited by the terms of the contracts to certain defined limits, such as the total amount paid by our customer under the agreement. However, certain agreements include covenants, penalties and indemnification provisions including and beyond indemnification for third-party claims of IP infringement that could potentially expose us to losses in excess of the amount received under the agreement, and in some instances to potential liability that is not contractually limited. Although from time to time there are indemnification claims asserted against us and currently there are pending indemnification claims, to date there have been no material awards under such indemnification provisions.

[0001262039-23-000038:notes:90]
Similar to other security companies and companies in other industries, we have experienced and may experience in the future, cybersecurity threats, malicious activity directed against our information technology infrastructure or unauthorized attempts to gain access to our and our customers’ sensitive information and systems. We currently are unaware of any existing claims or proceedings related to these types of matters, including any that we believe are likely to have a material adverse effect on our financial position.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001262039-23-000038:notes:91]
[same as prior period, unchanged from 0001262039-23-000032:notes:86]

[0001262039-23-000038:notes:92]
We maintain the Amended and Restated Fortinet, Inc. 2009 Equity Incentive Plan (the “Amended Plan”) pursuant to which we have granted RSUs, stock options and PSUs. As of September 30, 2023, there were a total of 53.3 million shares of common stock available for grant under the Amended Plan.

[0001262039-23-000038:notes:93]
[same as prior period, unchanged from 0001262039-23-000032:notes:88]

[0001262039-23-000038:notes:94]
[same as prior period, unchanged from 0001262039-23-000032:notes:89]

[0001262039-23-000038:notes:95]
|  | Restricted Stock Units Outstanding |
|  | Number of Shares |  | Weighted-Average Grant Date Fair Value per Share |
| Balance—December 31, 2022 | 10.5 |  |  | $ | 40.94 |  |
| Granted | 4.5 |  |  | 60.85 |  |
| Forfeited | (0.6) |  |  | 48.33 |  |
| Vested | (4.3) |  |  | 34.88 |  |
| Balance—September 30, 2023 | 10.1 |  |  | $ | 51.91 |  |

[0001262039-23-000038:notes:96]
Stock compensation expense is recognized on a straight-line basis over the vesting period of each RSU. As of September 30, 2023, total compensation expense related to unvested RSUs granted to employees and non-employees under the Amended Plan, but not yet recognized, was $460.9 million, with a weighted-average remaining vesting period of 2.7 years.

[0001262039-23-000038:notes:97]
[same as prior period, unchanged from 0001262039-23-000032:notes:92]

[0001262039-23-000038:notes:98]
[same as prior period, unchanged from 0001262039-23-000032:notes:93]

[0001262039-23-000038:notes:99]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30,2023 |  | September 30,2022 |  | September 30,2023 |  | September 30,2022 |
| Shares withheld for taxes | 0.4 |  |  | 0.5 |  |  | 1.5 |  |  | 2.2 |  |
| Amount withheld for taxes | $ | 31.0 |  |  | $ | 32.0 |  |  | $ | 90.7 |  |  | $ | 132.1 |  |

[0001262039-23-000038:notes:100]
[same as prior period, unchanged from 0001262039-23-000032:notes:95]

[0001262039-23-000038:notes:101]
[same as prior period, unchanged from 0001262039-23-000032:notes:96]

[0001262039-23-000038:notes:102]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30,2023 |  | September 30,2022 |  | September 30,2023 |  | September 30,2022 |
| Expected term in years | 4.4 |  | 4.4 |  | 4.4 |  | 4.4 |
| Volatility | 42.8 | % |  | 42.5 | % |  | 42.0 | % |  | 41.2 | % |
| Risk-free interest rate | 4.5 | % |  | 3.1 | % |  | 4.2 | % |  | 2.0 | % |
| Dividend rate | — | % |  | — | % |  | — | % |  | — | % |

[0001262039-23-000038:notes:103]
[same as prior period, unchanged from 0001262039-23-000032:notes:98]

[0001262039-23-000038:notes:104]
|  | Options Outstanding |
|  | Numberof Shares |  | Weighted-AverageExercisePrice |  | Weighted-AverageRemainingContractualLife (Years) |  | AggregateIntrinsicValue |
| Balance—December 31, 2022 | 13.2 |  |  | $ | 24.37 |  |  | 3.5 |  | $ | 344.8 |  |
| Granted | 1.3 |  |  | 60.59 |  |  |  |  |  |
| Forfeited | (0.1) |  |  | 47.86 |  |  |  |  |  |
| Exercised | (2.4) |  |  | 14.89 |  |  |  |  |  |
| Balance—September 30, 2023 | 12.0 |  |  | $ | 29.95 |  |  |  |  |  |
| Options vested and expected to vest—September 30, 2023 | 12.0 |  |  | $ | 29.95 |  |  | 3.4 |  | $ | 350.2 |  |
| Options exercisable—September 30, 2023 | 8.4 |  |  | $ | 21.24 |  |  | 2.6 |  | $ | 317.9 |  |

[0001262039-23-000038:notes:105]
The aggregate intrinsic value represents the difference between the exercise price of stock options and the quoted market price of our common stock for all in-the-money stock options. Stock compensation expense is recognized on a straight-line basis over the vesting period of each stock option. As of September 30, 2023, total compensation expense related to unvested stock options granted to employees but not yet recognized was $61.4 million, with a weighted-average remaining vesting period of 2.6 years.

[0001262039-23-000038:notes:106]
[same as prior period, unchanged from 0001262039-23-000032:notes:101]

[0001262039-23-000038:notes:107]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30,2023 |  | September 30,2022 |  | September 30,2023 |  | September 30,2022 |
| Weighted-average fair value per share granted | $ | 23.67 |  |  | $ | 20.22 |  |  | $ | 24.37 |  |  | $ | 22.09 |  |
| Intrinsic value of options exercised | $ | 13.9 |  |  | $ | 29.7 |  |  | $ | 110.9 |  |  | $ | 73.3 |  |
| Fair value of options vested | $ | 6.1 |  |  | $ | 4.8 |  |  | $ | 23.5 |  |  | $ | 19.8 |  |

[0001262039-23-000038:notes:108]
[same as prior period, unchanged from 0001262039-23-000032:notes:103]

[0001262039-23-000038:notes:109]
[same as prior period, unchanged from 0001262039-23-000032:notes:104]

[0001262039-23-000038:notes:110]
[same as prior period, unchanged from 0001262039-23-000032:notes:105]

[0001262039-23-000038:notes:111]
[same as prior period, unchanged from 0001262039-23-000032:notes:106]

[0001262039-23-000038:notes:112]
We granted approximately 0.3 million shares of PSU awards with a grant date fair value of $90.96 per share to certain of our executives during the first quarter of 2023. The grant date fair value of these awards was determined using a Monte Carlo simulation pricing model. None of these PSU awards were vested or forfeited during the nine months ended September 30, 2023.

[0001262039-23-000038:notes:113]
As of September 30, 2023, total compensation expense related to unvested PSUs that were granted to certain of our executives, but not yet recognized, was $19.4 million. This expense is expected to be amortized on a graded vesting method over a weighted-average vesting period of 2.4 years.

[0001262039-23-000038:notes:114]
[same as prior period, unchanged from 0001262039-23-000032:notes:109]

[0001262039-23-000038:notes:115]
[same as prior period, unchanged from 0001262039-23-000032:notes:110]

[0001262039-23-000038:notes:116]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30,2023 |  | September 30,2022 |  | September 30,2023 |  | September 30,2022 |
| Cost of product revenue | $ | 0.4 |  |  | $ | 0.5 |  |  | $ | 1.3 |  |  | $ | 1.3 |  |
| Cost of service revenue | 6.1 |  |  | 4.8 |  |  | 17.2 |  |  | 14.0 |  |
| Research and development | 20.0 |  |  | 16.7 |  |  | 57.0 |  |  | 47.9 |  |
| Sales and marketing | 28.5 |  |  | 25.9 |  |  | 84.1 |  |  | 79.0 |  |
| General and administrative | 9.9 |  |  | 7.4 |  |  | 28.0 |  |  | 22.3 |  |
| Total stock-based compensation expense | $ | 64.9 |  |  | $ | 55.3 |  |  | $ | 187.6 |  |  | $ | 164.5 |  |

[0001262039-23-000038:notes:117]
[same as prior period, unchanged from 0001262039-23-000032:notes:112]

[0001262039-23-000038:notes:118]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30,2023 |  | September 30,2022 |  | September 30,2023 |  | September 30,2022 |
| RSUs | $ | 54.2 |  |  | $ | 48.9 |  |  | $ | 158.4 |  |  | $ | 146.2 |  |
| Stock options | 7.5 |  |  | 6.4 |  |  | 21.5 |  |  | 18.3 |  |
| PSUs | 3.2 |  |  | — |  |  | 7.7 |  |  | — |  |
| Total stock-based compensation expense | $ | 64.9 |  |  | $ | 55.3 |  |  | $ | 187.6 |  |  | $ | 164.5 |  |

[0001262039-23-000038:notes:119]
[same as prior period, unchanged from 0001262039-23-000032:notes:114]

[0001262039-23-000038:notes:120]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30,2023 |  | September 30,2022 |  | September 30,2023 |  | September 30,2022 |
| Income tax benefit associated with stock-based compensation | $ | 14.3 |  |  | $ | 12.2 |  |  | $ | 41.4 |  |  | $ | 36.2 |  |

[0001262039-23-000038:notes:121]
[same as prior period, unchanged from 0001262039-23-000032:notes:116]

[0001262039-23-000038:notes:122]
In February 2023, our board of directors approved an extension of the Repurchase Program originally approved by our board of directors in January 2016 to February 29, 2024. In April 2023 and July 2023, our board of directors approved $1.0 billion and $500.0 million increases in the authorized amount under the Repurchase Program, respectively, bringing the aggregate amount authorized to be repurchased to $6.75 billion of our outstanding common stock through February 29, 2024. Share repurchases may be made by us from time to time in privately negotiated transactions or in open-market transactions. The Repurchase Program does not require us to purchase a minimum number of shares, and may be suspended, modified or discontinued at any time without prior notice.
During the three and nine months ended September 30, 2023, we repurchased 10.4 million shares of common stock under the Repurchase Program in open-market transactions at a weighted-average price of $58.43 per share, for an aggregate purchase price of $605.2 million, which excludes a $2.8 million accrual related to the 1% excise tax imposed by the Inflation Reduction Act of 2022. As of September 30, 2023, $1.42 billion remained available for future share repurchases under the Repurchase Program.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001262039-23-000038:notes:123]
INCOME TAXES
Our effective tax rate was 0% for the three months ended September 30, 2023, compared to an effective tax rate of 10% for the same period last year. Our effective tax rate was 5% for the nine months ended September 30, 2023, compared to an effective tax rate of 4% for the same period last year. The tax rates for the three months ended September 30, 2023 and 2022 were composed of U.S. federal and state taxes, withholding taxes and foreign taxes that amounted to $50.2 million and $75.5 million, respectively. The tax rate for the three months ended September 30, 2023 was impacted by a tax benefit of $41.9 million from the FDII deduction, and excess tax benefits from stock-based compensation expense of $8.6 million. The tax rate for the three months ended September 30, 2022 was impacted by a tax benefit of $28.9 million from the FDII deduction, and excess tax benefits from stock-based compensation expense of $19.3 million.

[0001262039-23-000038:notes:124]
The tax rates for the nine months ended September 30, 2023 and 2022 were composed of U.S. federal and state taxes, withholding taxes and foreign taxes that amounted to $220.9 million and $169.2 million, respectively. The tax rate for the nine months ended September 30, 2023 was impacted by a tax benefit of $105.9 million from the FDII deduction, excess tax benefits from stock-based compensation expense of $48.3 million, and the release of reserves of $18.1 million on uncertain tax positions and the accrued interest thereon due to the expiration of statutes of limitations. The tax rate for the nine months ended September 30, 2022 was impacted by a tax benefit of $62.6 million from the FDII deduction, excess tax benefits from stock-based compensation expense of $68.7 million, and the release of reserves of $16.3 million on uncertain tax positions and the accrued interest thereon due to the expiration of statutes of limitations.

[0001262039-23-000038:notes:125]
As of September 30, 2023 and December 31, 2022, unrecognized tax benefits were $65.8 million and $67.4 million, respectively. If recognized, $55.9 million of the unrecognized tax benefits as of September 30, 2023 would favorably affect our effective tax rate. It is our policy to include accrued interest and penalties related to unrecognized tax benefits in income tax expense. As of September 30, 2023 and December 31, 2022, accrued interest and penalties were $5.9 million and $9.3 million, respectively. It is reasonably possible that our gross unrecognized tax benefits will decrease by up to $1.8 million in the next 12 months, due to the lapse of statutes of limitation in various jurisdictions. This decrease, if recognized, would favorably impact our effective tax rate, and would be recognized as an additional tax benefit.

[0001262039-23-000038:notes:126]
[same as prior period, unchanged from 0001262039-23-000032:notes:122]

[0001262039-23-000038:notes:127]
[same as prior period, unchanged from 0001262039-23-000032:notes:123]

[0001262039-23-000038:notes:128]
On January 4, 2022, the U.S. Treasury published another tranche of final regulations regarding the foreign tax credit. These final regulations impose new requirements that a foreign tax must meet in order to be creditable against U.S. income taxes, and generally apply to tax years beginning on or after December 28, 2021. On July 26, 2022, the U.S. Treasury released corrections to the final regulations. On July 21, 2023, the IRS released a notice that suspended the application of significant portions of the final regulations regarding the foreign tax credit for tax years 2022 and 2023. The notice released in July 2023 favorably impacted our ability to claim foreign tax credits in the United States for certain taxes imposed by certain foreign jurisdictions. As a result, our tax provision decreased by $39.8 million for the nine months ended September 30, 2023.

[0001262039-23-000038:notes:129]
On August 16, 2022, the United States enacted the Inflation Reduction Act of 2022 that provides for certain changes to the U.S. corporate income tax system, including a 15% minimum tax based on financial statement income for companies with three-year average annual adjusted financial statement income exceeding $1 billion, and a 1% excise tax on net repurchases of stock after December 31, 2022, if any. The applicable tax law changes have had no impact to our tax provision for the nine months ended September 30, 2023. We will continue to monitor the impact, if any, of these tax law changes on future periods.


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0001262039-23-000038:notes:130]
DEFINED CONTRIBUTION PLANSOur tax-deferred savings plan under our 401(k) Plan permits participating U.S. employees to contribute a portion of their pre-tax or after-tax earnings. In Canada, we have a Group Registered Retirement Savings Plan Program (the “RRSP”), which permits participants to make pre-tax contributions. Our board of directors approved 50% matching contributions on employee contributions up to 4% of each employee’s eligible earnings. Our matching contributions to our 401(k) Plan and the RRSP for the three months ended September 30, 2023 and 2022 were $3.8 million and $3.2 million, respectively. Our matching contributions to our 401(k) Plan and the RRSP for the nine months ended September 30, 2023 and 2022 were $13.9 million and $9.8 million, respectively.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001262039-23-000038:notes:131]
[same as prior period, unchanged from 0001262039-23-000032:notes:127]

[0001262039-23-000038:notes:132]
[same as prior period, unchanged from 0001262039-23-000032:notes:128]

[0001262039-23-000038:notes:133]
|  | Three Months Ended |  | Nine Months Ended |
| Revenue | September 30,2023 |  | September 30,2022 |  | September 30,2023 |  | September 30,2022 |
| Americas: |  |  |  |  |  |  |  |
| United States | $ | 400.8 |  |  | $ | 344.1 |  |  | $ | 1,189.6 |  |  | $ | 942.8 |  |
| Other Americas | 144.8 |  |  | 123.5 |  |  | 416.5 |  |  | 321.0 |  |
| Total Americas | 545.6 |  |  | 467.6 |  |  | 1,606.1 |  |  | 1,263.8 |  |
| Europe, Middle East and Africa (“EMEA”) | 512.2 |  |  | 443.9 |  |  | 1,497.3 |  |  | 1,181.7 |  |
| Asia Pacific (“APAC”) | 276.8 |  |  | 238.0 |  |  | 786.3 |  |  | 688.9 |  |
| Total revenue | $ | 1,334.6 |  |  | $ | 1,149.5 |  |  | $ | 3,889.7 |  |  | $ | 3,134.4 |  |

[0001262039-23-000038:notes:134]
| Property and Equipment—net | September 30,2023 |  | December 31,2022 |
| Americas: |  |  |  |
| United States | $ | 696.7 |  |  | $ | 638.1 |  |
| Canada | 209.8 |  |  | 204.4 |  |
| Latin America | 1.2 |  |  | 1.1 |  |
| Total Americas | 907.7 |  |  | 843.6 |  |
| EMEA | 68.7 |  |  | 35.9 |  |
| APAC | 61.6 |  |  | 19.0 |  |
| Total property and equipment—net | $ | 1,038.0 |  |  | $ | 898.5 |  |

[0001262039-23-000038:notes:135]
[same as prior period, unchanged from 0001262039-23-000032:notes:131]

[0001262039-23-000038:notes:136]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30,2023 |  | September 30,2022 |  | September 30,2023 |  | September 30,2022 |
| Distributor A | 28 | % |  | 29 | % |  | 28 | % |  | 29 | % |
| Distributor B | 15 | % |  | 13 | % |  | 15 | % |  | 13 | % |
| Distributor C | 13 | % |  | 13 | % |  | 14 | % |  | 13 | % |

[0001262039-23-000038:notes:137]
[same as prior period, unchanged from 0001262039-23-000032:notes:133]

[0001262039-23-000038:notes:138]
|  | September 30,2023 |  | December 31,2022 |
| Distributor A | 26 | % |  | 32 | % |
| Distributor B | 13 | % |  | 12 | % |
| Distributor C | 13 | % |  | 13 | % |


## us-gaap:SubsequentEventsTextBlock

[0001262039-23-000038:notes:139]
SUBSEQUENT EVENT
Share Repurchase Program

[0001262039-23-000038:notes:140]
Subsequent to September 30, 2023 through the filing of this Quarterly Report on Form 10-Q, we repurchased 11.2 million shares of our common stock at an average price of $54.87 per share for an aggregate purchase price of $613.5 million under the Repurchase Program, which excludes a $5.7 million accrual related to the 1% excise tax imposed by the Inflation Reduction Act of 2022.


## ecd:MtrlTermsOfTrdArrTextBlock

[0001262039-23-000038:notes:141]
[same as prior period, unchanged from 0001262039-23-000032:notes:138]

[0001262039-23-000038:notes:142]
On August 16, 2023, the Xie Foundation, a non-profit entity for which Michael Xie and Ken Xie, both of which are our officers and directors, serve as co-presidents and directors, and Michael Xie entered into a pre-arranged written stock sale plan in accordance with Rule 10b5-1 (the “August Xie Plan”) under the Exchange Act for the sale of shares of our common stock. The August Xie Plan was entered into during an open trading window in accordance with our insider trading policy and is intended to satisfy the affirmative defense of Rule 10b5-1(c) under the Exchange Act. The August Xie Plan provides for (i) the potential sale by Michael Xie of up to (a) 100,000 shares of our common stock, including upon the vesting and settlement of RSUs and PSUs for shares of our common stock, and (b) the net shares (which are not yet determinable) after shares are withheld to satisfy tax obligations upon such vesting and settlement, in each case, at the market price, and (ii) the potential gifting of up to 50,000 shares of our common stock by the Xie Foundation, all between November 15, 2023 and November 29, 2024.

[0001262039-23-000038:notes:143]
On September 8, 2023, Michael Xie and the Xie Foundation amended the August Xie Plan in order to provide for sales of our common stock thereunder by Ken Xie, in addition to the sales provided for by the August Xie Plan (as so amended, the “September Xie Plan”). The September Xie Plan was entered into during an open trading window in accordance with our insider trading policy and is intended to satisfy the affirmative defense of Rule 10b5-1(c) under the Exchange Act. The September Xie Plan provides for (i) the potential sale by Michael Xie of up to (a) 100,000 shares of our common stock, including upon the vesting and settlement of RSUs and PSUs for shares of our common stock, and (b) the net shares (which are not yet determinable) after shares are withheld to satisfy tax obligations upon such vesting and settlement, in each case, at the market price, (ii) the potential sale by Ken Xie of up to (a) 150,000 shares of our common stock, including upon the exercise of vested stock options for shares of our common stock, and (b) the net shares (which are not yet determinable) after shares are sold to pay the exercise price and tax withholding obligations associated with such exercises, in each case, at the market price and (iii) the potential gifting of up to 50,000 shares of our common stock by the Xie Foundation, all between December 8, 2023 and February 14, 2025.

[0001262039-23-000038:notes:144]
Each of the August Xie Plan and the September Xie Plan (together, the “10b5-1 Plans”) includes a representation from Michael Xie, Ken Xie and the Xie Foundation (as applicable) to the broker administering the plan that none of them were in possession of any material nonpublic information regarding us or the securities subject to the 10b5-1 Plans at the time the 10b5-1 Plans were entered into. A similar representation was made to us in connection with the adoption of the 10b5-1 Plans under our insider trading policy. Those representations for each 10b5-1 Plan were made as of the respective date of adoption of the 10b5-1 Plan, and speak only as of that date. In making those representations, there is no assurance with respect to any material nonpublic information of which Michael Xie, Ken Xie and the Xie Foundation were unaware, or with respect to any material nonpublic information acquired by Michael Xie, Ken Xie and the Xie Foundation or us after the date of each such representation.

[0001262039-23-000038:notes:145]
Once executed, transactions under the September Xie Plan will be disclosed publicly through Form 4 and/or Form 144 filings with the SEC in accordance with applicable securities laws, rules and regulations. Except as may be required by law, we do not undertake any obligation to update or report any modification, termination, or other activity under current or future Rule 10b5-1 plans that may be adopted by Michael Xie, Ken Xie, the Xie Foundation or our other officers or directors, or their affiliated entities.
