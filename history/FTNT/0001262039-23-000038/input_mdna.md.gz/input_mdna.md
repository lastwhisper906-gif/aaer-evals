# FTNT MD&A — 0001262039-23-000038


## mdna

[0001262039-23-000038:mdna:1]
[same as prior period, unchanged from 0001262039-23-000032:mdna:1]

[0001262039-23-000038:mdna:2]
[same as prior period, unchanged from 0001262039-23-000032:mdna:2]

[0001262039-23-000038:mdna:3]
[same as prior period, unchanged from 0001262039-23-000032:mdna:3]

[0001262039-23-000038:mdna:4]
[same as prior period, unchanged from 0001262039-23-000032:mdna:4]

[0001262039-23-000038:mdna:5]
[same as prior period, unchanged from 0001262039-23-000032:mdna:6]

[0001262039-23-000038:mdna:6]
[same as prior period, unchanged from 0001262039-23-000032:mdna:26]

[0001262039-23-000038:mdna:7]
[same as prior period, unchanged from 0001262039-23-000032:mdna:7]

[0001262039-23-000038:mdna:8]
[same as prior period, unchanged from 0001262039-23-000032:mdna:8]

[0001262039-23-000038:mdna:9]
[same as prior period, unchanged from 0001262039-23-000032:mdna:9]

[0001262039-23-000038:mdna:10]
•drivers of long-term growth and operating leverage, such as pricing of our products and services, sales productivity, pipeline and capacity, functionality, value and technology improvements in our service offerings;

[0001262039-23-000038:mdna:11]
[same as prior period, unchanged from 0001262039-23-000032:mdna:11]

[0001262039-23-000038:mdna:12]
•our ability to successfully anticipate market changes related to cloud-based solutions and to sell, support and meet service level agreements related to cloud-based solutions;

[0001262039-23-000038:mdna:13]
•supply chain constraints, component availability and other factors affecting our manufacturing capacity, delivery, cost and inventory management;

[0001262039-23-000038:mdna:14]
•forecasts of future demand and targeted inventory levels, including changing market drivers and demands;

[0001262039-23-000038:mdna:15]
[same as prior period, unchanged from 0001262039-23-000032:mdna:14]

[0001262039-23-000038:mdna:16]
[same as prior period, unchanged from 0001262039-23-000032:mdna:5]

[0001262039-23-000038:mdna:17]
[same as prior period, unchanged from 0001262039-23-000032:mdna:15]

[0001262039-23-000038:mdna:18]
[same as prior period, unchanged from 0001262039-23-000032:mdna:16]

[0001262039-23-000038:mdna:19]
[same as prior period, unchanged from 0001262039-23-000032:mdna:17]

[0001262039-23-000038:mdna:20]
[same as prior period, unchanged from 0001262039-23-000032:mdna:18]

[0001262039-23-000038:mdna:21]
•expected impact of plans and strategy for the acceleration of our points of presence (“PoP”) deployment;

[0001262039-23-000038:mdna:22]
•expectations that our operating expenses will increase year over year in absolute dollars during the remainder of 2023;

[0001262039-23-000038:mdna:23]
•expectations that proceeds from the exercise of stock options in future years will be adversely impacted by the increased mix of restricted stock units and performance stock units versus stock options granted or a decline in our stock price;

[0001262039-23-000038:mdna:24]
[same as prior period, unchanged from 0001262039-23-000032:mdna:23]

[0001262039-23-000038:mdna:25]
•expectations regarding spending related to real estate acquisitions and development, including data center, office building and warehouse investments, as well as other capital expenditures and to the impact on free cash flow and expenses;

[0001262039-23-000038:mdna:26]
[same as prior period, unchanged from 0001262039-23-000032:mdna:25]

[0001262039-23-000038:mdna:27]
•expected outcomes and liabilities in litigation;

[0001262039-23-000038:mdna:28]
[same as prior period, unchanged from 0001262039-23-000032:mdna:28]

[0001262039-23-000038:mdna:29]
[same as prior period, unchanged from 0001262039-23-000032:mdna:29]

[0001262039-23-000038:mdna:30]
[same as prior period, unchanged from 0001262039-23-000032:mdna:30]

[0001262039-23-000038:mdna:31]
[same as prior period, unchanged from 0001262039-23-000032:mdna:31]

[0001262039-23-000038:mdna:32]
Fortinet is a global leader in cybersecurity solutions for customers, with a focus on three solution areas: secure networking, universal secure access service edge (“SASE”) and security operations (“SecOps”). Our mission is to secure people, devices and data everywhere. As of September 30, 2023, over 700,000 customers trusted our solutions, including enterprises (such as in the financial services, retail and operational technology market segments), communication and security service providers, government organizations and small and medium-sized businesses.

[0001262039-23-000038:mdna:33]
Our products and solutions are designed to converge networking and security into a single solution and consolidate cybersecurity point products into an integrated platform through the combination of our single operating system and, where applicable, ASIC compute power. This allows customers to realize automated protection, improve detection and response times, and achieve visibility across solutions.

[0001262039-23-000038:mdna:34]
We are a global company headquartered in Sunnyvale, California and the majority of our research and development is in the United States and Canada. Our North American development teams are responsible for a number of technologies, including development of our operating system, ASIC technologies and the complete suite of our platform products including firewalls, switches and access points, SASE solutions, and SecOps solutions such as Security Information and Event Management, Security Orchestration, Automation and Response, Endpoint Detection and Response, and Network Detection and Response. As a U.S. company with a large international customer base, we offer a global footprint of support and centers of excellence around the world and across time zones from North America to Europe to Asia. As of September 30, 2023, we held 1,290 patents.

[0001262039-23-000038:mdna:35]
[same as prior period, unchanged from 0001262039-23-000032:mdna:38]

[0001262039-23-000038:mdna:36]
To help secure and enable our customers, we focus on the following three solution sets:

[0001262039-23-000038:mdna:37]
•Secure Networking—Our Secure Networking solutions focus on the convergence of networking and security via our network firewall and our switches, access points and other secure connectivity solutions. FortiOS is our networking and security operating system that is consistent across our firewalls and secure connectivity solutions and supports over 30 functions that can be delivered via a physical, virtual, cloud or SaaS solution. When delivered via our network firewall appliances, functionality is accelerated through our proprietary ASIC technology, which consists of three processors. First, a seventh-generation network processor, FortiNP7, accelerates the processing of firewall traffic and offloads this function from the central processing unit (“CPU”). Second, a ninth-generation content processor, FortiCP9, helps the CPU perform deep-packet inspection functions such as intrusion prevention and antivirus. To scale further, multiple CPUs, NP7s and CP9s can be placed in larger firewalls to deliver more processing power. Third, the CPU, network processor and content processor functions are all combined in a single ASIC, our fifth-generation security processor, FortiSP5. These proprietary ASICs, combined with off-the-shelf CPUs and ASICs, allow our systems to scale, run multiple applications at higher performance, lower power consumption and perform more processor-intensive operations, such as inspecting encrypted traffic, including streaming video. The Network Firewall solution consists of FortiGate data center, hyperscale and distributed firewalls, as well as encrypted applications (SSL inspection, Virtual Private Network and IPsec connectivity). Our ability to converge networking and security also enables the ethernet to become an extension of a company’s security infrastructure through FortiSwitch and FortiLink. Our wireless LAN solution leverages secure networking to provide secure wireless access for the enterprise LAN edge. FortiExtender secures 5G/LTE and remote ethernet extenders to connect and secure any branch environment. The Secure Connectivity solution consists of FortiSwitch Local Area Network, FortiAP Wireless Local Area Network - Access Points and FortiExtender 5G Connectivity Gateways.

[0001262039-23-000038:mdna:38]
•Universal Secure Access Service Edge (SASE)—As applications move to the cloud and work from anywhere becomes established in the workplace, cloud delivery is needed to enable secure access to applications on any cloud. The Fortinet Universal SASE solution is a single-vendor SASE solution that includes Firewall, SD-WAN, Secure Web Gateway, Cloud Access Services Broker, Data Loss Prevention, Zero Trust Network Access and Cloud security, including Web Application Firewalls, Virtualized Firewalls and Cloud-Native Firewalls. These functions are delivered through our FortiOS operating systems, which can deploy the full SASE stack through the cloud or on our ASIC-driven appliances. All functions can be managed through a unified management console.

[0001262039-23-000038:mdna:39]
•Security Operations (SecOps)—Fortinet’s Security Operations solutions comply with the NIST cybersecurity framework of identify, protect, detect, respond and recover, and are delivered as a platform that automates detection and response to accelerate discovery and remediation. The Security Operations solution consists of FortiSIEM Security Information and Event Management, FortiSOAR Security Orchestration, Automation and Response, FortiEDR Endpoint Detection and Response, FortiXDR Extended Detection and Response, FortiMDR Managed Detection and Response Service, FortiNDR Network Detection and Response, FortiRecon Digital Risk Protection, FortiDeceptor Deception technology, FortiGuard SoCaaS, FortiSandbox Sandboxing Services and FortiGuard Incident Response Services.

[0001262039-23-000038:mdna:40]
Our AI-driven threat intelligence and security service, known as FortiGuard Labs, is our cybersecurity threat intelligence and research organization comprised of experienced threat hunters, researchers, analysts, engineers and data scientists, who develop and utilize machine learning and AI technologies to provide timely protection updates and actionable threat intelligence for the benefit of our customers. FortiGuard Security Services are a suite of AI-enabled security capabilities that consist of FortiGuard application security services, content security services, device security services, NOC/SOC security services and web security services.

[0001262039-23-000038:mdna:41]
[same as prior period, unchanged from 0001262039-23-000032:mdna:80]

[0001262039-23-000038:mdna:42]
•Total revenue was $1.33 billion and $3.89 billion during the three and nine months ended September 30, 2023, an increase of 16% and 24%, respectively, compared to $1.15 billion and $3.13 billion in the same periods last year. Product revenue was $465.9 million and $1.44 billion during the three and nine months ended September 30, 2023, a decrease of 1% and an increase of 16%, respectively, compared to $468.7 million and $1.24 billion in the same periods last year. Service revenue was $868.7 million and $2.45 billion during the three and nine months ended September 30, 2023, an increase of 28% and 29%, in each period respectively, compared to $680.8 million and $1.89 billion in the same periods last year.

[0001262039-23-000038:mdna:43]
•Total gross profit was $1.02 billion and $2.97 billion during the three and nine months ended September 30, 2023, an increase of 17% and 26%, respectively, compared to $866.5 million and $2.35 billion in the same periods last year.

[0001262039-23-000038:mdna:44]
28

[0001262039-23-000038:mdna:45]
•Operating income was $303.2 million and $855.7 million during the three and nine months ended September 30, 2023, an increase of 14% and 40%, respectively, compared to $265.5 million and $611.8 million in the same periods last year.

[0001262039-23-000038:mdna:46]
•Cash, cash equivalents, short-term and long-term investments and marketable equity securities were $3.17 billion as of September 30, 2023.

[0001262039-23-000038:mdna:47]
•During the nine months ended September 30, 2023, we repurchased 10.4 million shares of common stock under our Share Repurchase Program (the “Repurchase Program”), for a total purchase price of $605.2 million, which excludes a $2.8 million accrual related to the 1% excise tax imposed by the Inflation Reduction Act of 2022.

[0001262039-23-000038:mdna:48]
•Deferred revenue was $5.29 billion as of September 30, 2023, an increase of $645.0 million, or 14%, compared to $4.64 billion as of December 31, 2022 and an increase of $1.09 billion, or 26%, compared to $4.19 billion as of September 30, 2022. Deferred revenue was $4.19 billion as of September 30, 2022, an increase of $740.6 million, or 21%, compared to $3.45 billion as of December 31, 2021 and an increase of $1.09 billion, or 35%, compared to $3.11 billion as of September 30, 2021.

[0001262039-23-000038:mdna:49]
•Short-term deferred revenue was $2.65 billion as of September 30, 2023, an increase of $298.0 million, or 13%, compared to $2.35 billion as of December 31, 2022 and an increase of $518.3 million, or 24%, compared to $2.13 billion as of September 30, 2022. Short-term deferred revenue was $2.13 billion as of September 30, 2022, an increase of $351.6 million, or 20%, compared to $1.78 billion as of December 31, 2021 and an increase of $512.9 million, or 32%, compared to $1.62 billion as of September 30, 2021.

[0001262039-23-000038:mdna:50]
•We generated cash flows from operating activities of $1.74 billion during the nine months ended September 30, 2023, an increase of $541.3 million, or 45%, compared to the same period last year.

[0001262039-23-000038:mdna:51]
On a geographic basis, revenue continues to be diversified, which remains a key strength of our business. During the three months ended September 30, 2023, the Americas region, the Europe, Middle East and Africa (“EMEA”) region and the Asia Pacific (“APAC”) region contributed 41%, 38% and 21% of our total revenue, respectively, and increased 17%, 15% and 16% compared to the same period last year, respectively. During the nine months ended September 30, 2023, the Americas region, the EMEA region and the APAC region contributed 41%, 39% and 20% of our total revenue, respectively, and increased 27%, 27% and 14% compared to the same period last year, respectively.

[0001262039-23-000038:mdna:52]
Our revenue growth was driven by growth in service revenue.

[0001262039-23-000038:mdna:53]
Product revenue decreased 1% during the three months ended September 30, 2023 compared to the same period last year, reflecting product lead times and backlog aligning with historical levels and decreased demand for our network security products as product demand returns to normal levels following approximately two years of elevated growth. Product revenue increased 16%, during the nine months ended September 30, 2023 compared to the same period last year, which was consistent with an elevated cyber threat landscape, the convergence of security and networking, the impact of certain historical pricing actions, improving supply chain dynamics and changes in the backlog balance.

[0001262039-23-000038:mdna:54]
Service revenue growth of 28% and 29%, during the three and nine months ended September 30, 2023 compared to the same periods last year, respectively, was primarily driven by the strength of our security subscription revenue, which grew 34% in each period.

[0001262039-23-000038:mdna:55]
Our billings were diversified on a geographic basis. During the three months ended September 30, 2023, approximately 50% of our billings in the aggregate were from over 100 countries that each individually contributed less than 3% of our billings.

[0001262039-23-000038:mdna:56]
Operating expenses as a percentage of revenue increased 1.2 percentage points during the three months ended September 30, 2023 compared to the same period last year, mainly driven by an increase in personnel-related costs. Operating expenses as a percentage of revenue decreased 1.1 percentage points during the nine months ended September 30, 2023 compared to the same period last year, benefiting from the favorable impact of foreign currency fluctuations. Headcount increased to 13,618 employees and contractors as of September 30, 2023, an 8% increase compared to 12,595 as of December 31, 2022.

[0001262039-23-000038:mdna:57]
[same as prior period, unchanged from 0001262039-23-000032:mdna:82]

[0001262039-23-000038:mdna:58]
[same as prior period, unchanged from 0001262039-23-000032:mdna:93]

[0001262039-23-000038:mdna:59]
Our overall performance depends in part on worldwide economic and geopolitical conditions and their impact on customer behavior. Worsening economic conditions, including inflation, higher interest rates, slower growth, any recession, fluctuations in foreign exchange rates, instability in the global banking industry, and other changes in economic conditions, may result in decreased sales productivity and growth and adversely affect our results of operations and financial performance. We have seen certain impacts on our business, results of operations, financial condition, cash flows, liquidity and capital and financial resources such as longer sales cycles, delayed purchases and increased commitments with certain suppliers and increases inventory and inventory purchase commitment reserves.

[0001262039-23-000038:mdna:60]
Our days sales outstanding decreased to 68 days in the third quarter of 2023, compared to 75 days in the same period last year. The accounts receivable allowance for credit losses was $5.3 million as of September 30, 2023, an increase of $1.7 million compared to $3.6 million as of December 31, 2022, primarily due to an increase in past due invoices over 60 and 90 days.

[0001262039-23-000038:mdna:61]
[same as prior period, unchanged from 0001262039-23-000032:mdna:97]

[0001262039-23-000038:mdna:62]
[same as prior period, unchanged from 0001262039-23-000032:mdna:98]

[0001262039-23-000038:mdna:63]
We typically sell our security solutions to distributors that sell to networking security focused resellers and to certain service providers and managed security service providers (“MSSPs”), who, in turn, sell to end-customers or use our products and services to provide hosted solutions to other enterprises. At times, we also sell directly to certain large enterprise customers, large service providers and major systems integrators. In addition, we sell our software licenses and services via different cloud service provider platforms, directly and through our channel partners. Our end-customers are located in over 100 countries and include small, medium and large enterprises and government organizations across a wide range of industries, including financial services, government, healthcare, manufacturing, retail, technology and telecommunications. An end-customer deployment may involve as few as one or as many as thousands of Core Platform products as well as Enhanced Platform Technology products, depending on the end-customer’s size and security requirements.

[0001262039-23-000038:mdna:64]
[same as prior period, unchanged from 0001262039-23-000032:mdna:100]

[0001262039-23-000038:mdna:65]
We also offer our products hosted in our own data centers, PoPs and through co-locations and major cloud service providers, including Google Cloud, Amazon Web Services and Microsoft Azure. We have also recognized revenue from customers who deploy our products in a bring-your-own-license (“BYOL”) arrangements at cloud service providers or at private clouds. In a BYOL arrangement, a customer purchases a software license through our channel partners and deploys the software in a cloud provider’s environment, in third-party clouds or in their private cloud.

[0001262039-23-000038:mdna:66]
[same as prior period, unchanged from 0001262039-23-000032:mdna:102]

[0001262039-23-000038:mdna:67]
We monitor several key metrics, including the key financial metrics set forth below, to evaluate growth trends, establish budgets, measure the effectiveness of our sales and marketing efforts, and assess operational efficiencies. The following table summarizes revenue, deferred revenue, billings (non-GAAP), net cash provided by operating activities, and free cash flow (non-GAAP). We discuss revenue below under “Results of Operations,” and we discuss net cash provided by

[0001262039-23-000038:mdna:68]
operating activities below under “—Liquidity and Capital Resources.” Deferred revenue, billings (non-GAAP), and free cash flow (non-GAAP) are discussed immediately below the following table:

[0001262039-23-000038:mdna:69]
|  | Three Months Ended Or As Of |
|  | September 30, 2023 |  | September 30, 2022 |
|  | (in millions) |
| Revenue | $ | 1,334.6 |  |  | $ | 1,149.5 |  |
| Deferred revenue | $ | 5,285.3 |  |  | $ | 4,193.5 |  |
| Billings (non-GAAP) | $ | 1,491.3 |  |  | $ | 1,411.0 |  |
| Net cash provided by operating activities | $ | 551.2 |  |  | $ | 483.0 |  |
| Free cash flow (non-GAAP) | $ | 481.1 |  |  | $ | 395.2 |  |

[0001262039-23-000038:mdna:70]
Deferred revenue. Our deferred revenue consists of amounts that have been invoiced but that have not yet been recognized as revenue. The majority of our deferred revenue balance consists of the unrecognized portion of service revenue from FortiGuard and other security subscriptions and FortiCare technical support service contracts, which is recognized as revenue ratably over the service term. We monitor our deferred revenue balance, short-term and total deferred revenue growth and the mix of short-term and long-term deferred revenue because deferred revenue represents a significant portion of free cash flow and of revenue to be recognized in future periods. Deferred revenue was $5.29 billion as of September 30, 2023, an increase of $645.0 million, or 14%, from December 31, 2022. Short term deferred revenue was $2.65 billion as of September 30, 2023, an increase of $298.0 million, or 13%, from December 31, 2022.

[0001262039-23-000038:mdna:71]
Billings (non-GAAP). We define billings as revenue recognized in accordance with GAAP plus the change in deferred revenue from the beginning to the end of the period. We consider billings to be a useful metric for management and investors because billings drive current and future revenue, which is an important indicator of the health and viability of our business. There are several limitations related to the use of billings instead of GAAP revenue. First, billings include amounts that have not yet been recognized as revenue and are impacted by the term of FortiGuard security subscription and FortiCare technical support agreements. Second, we may calculate billings in a manner that is different from peer companies that report similar financial measures. Management accounts for these limitations by providing specific information regarding GAAP revenue and evaluating billings together with GAAP revenue. Total billings were $1.49 billion for the three months ended September 30, 2023, an increase of 6% compared to $1.41 billion in the same period last year.

[0001262039-23-000038:mdna:72]
During the three months ended September 30, 2023, our billings and product revenue fell below our expectations due to a slowdown in secure networking growth, along with challenges in sales execution and marketing programs. In addition, we believe secure networking growth in the near term may be below historical growth rates. In response to the slowdown in the secure networking market, we plan to shift our marketing and sales teams’ focus towards the faster growing SecOps and SASE markets over the next several quarters, while maintaining our continued focus on leading innovation in secure networking and the convergence of security and networking.

[0001262039-23-000038:mdna:73]
We anticipate limited near-term growth in the secure networking market and shifting sales and marketing focus may result in certain risks, including go-to-market challenges, increased sales turnover and other execution challenges.

[0001262039-23-000038:mdna:74]
Our backlog has fluctuated over past quarters and any decrease in growth or negative growth of in-quarter billings and revenue may not be reflected by our aggregate billings and revenue. As we have fulfilled, shipped and billed during a quarter to satisfy backlog, this has increased our aggregate billings and revenue during any particular quarter, and as the supply chain challenges normalize, the growth comparisons versus prior quarters where backlog contributed more to billings have become more challenging and may become increasingly challenging.

[0001262039-23-000038:mdna:75]
[same as prior period, unchanged from 0001262039-23-000032:mdna:108]

[0001262039-23-000038:mdna:76]
|  | Three Months Ended |
|  | September 30, 2023 |  | September 30, 2022 |
|  | (in millions) |
| Billings: |  |  |  |
| Revenue | $ | 1,334.6 |  |  | $ | 1,149.5 |  |
| Add: Change in deferred revenue | 156.7 |  |  | 261.5 |  |
| Total billings (non-GAAP) | $ | 1,491.3 |  |  | $ | 1,411.0 |  |

[0001262039-23-000038:mdna:77]
31

[0001262039-23-000038:mdna:78]
[same as prior period, unchanged from 0001262039-23-000032:mdna:110]

[0001262039-23-000038:mdna:79]
|  | Three Months Ended |
|  | September 30, 2023 |  | September 30, 2022 |
|  | (in millions) |
| Free Cash Flow: |  |  |  |
| Net cash provided by operating activities | $ | 551.2 |  |  | $ | 483.0 |  |
| Less: Purchases of property and equipment | (70.1) |  |  | (87.8) |  |
| Free cash flow (non-GAAP) | $ | 481.1 |  |  | $ | 395.2 |  |
| Net cash provided by (used in) investing activities | $ | (111.2) |  |  | $ | 297.8 |  |
| Net cash used in financing activities | $ | (628.9) |  |  | $ | (526.6) |  |

[0001262039-23-000038:mdna:80]
[same as prior period, unchanged from 0001262039-23-000032:mdna:112]

[0001262039-23-000038:mdna:81]
Our discussion and analysis of our financial condition and results of operations are based upon our financial statements, which have been prepared in accordance with GAAP. These principles require us to make estimates and judgments that affect the reported amounts of assets, liabilities, revenue, cost of revenue and expenses, and related disclosures. We base our estimates on historical experience and on various other assumptions that we believe to be reasonable under the circumstances. To the extent that there are material differences between these estimates and our actual results, our future financial statements will be affected.

[0001262039-23-000038:mdna:82]
There were no material changes to our critical accounting policies and estimates as of and for the three and nine months ended September 30, 2023, as compared to the critical accounting policies and estimates described in our Annual Report on Form 10-K filed with the SEC on February 24, 2023 (the “Form 10-K”).

[0001262039-23-000038:mdna:83]
[same as prior period, unchanged from 0001262039-23-000032:mdna:116]

[0001262039-23-000038:mdna:84]
32

[0001262039-23-000038:mdna:85]
[same as prior period, unchanged from 0001262039-23-000032:mdna:117]

[0001262039-23-000038:mdna:86]
Three Months Ended September 30, 2023 and 2022

[0001262039-23-000038:mdna:87]
[same as prior period, unchanged from 0001262039-23-000032:mdna:119]

[0001262039-23-000038:mdna:88]
|  | Three Months Ended |  |  |  |  |
| September 30,2023 |  | September 30,2022 |  |  |  |  |
| Amount |  | % ofRevenue |  | Amount |  | % ofRevenue |  | Change |  | % Change |
| (in millions, except percentages) |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 465.9 |  |  | 35 | % |  | $ | 468.7 |  |  | 41 | % |  | $ | (2.8) |  |  | (1) | % |
| Service | 868.7 |  |  | 65 |  |  | 680.8 |  |  | 59 |  |  | 187.9 |  |  | 28 |  |
| Total revenue | $ | 1,334.6 |  |  | 100 | % |  | $ | 1,149.5 |  |  | 100 | % |  | $ | 185.1 |  |  | 16 | % |
| Revenue by geography: |  |  |  |  |  |  |  |  |  |  |  |
| Americas | $ | 545.6 |  |  | 41 | % |  | $ | 467.6 |  |  | 41 | % |  | $ | 78.0 |  |  | 17 | % |
| EMEA | 512.2 |  |  | 38 |  |  | 443.9 |  |  | 38 |  |  | 68.3 |  |  | 15 |  |
| APAC | 276.8 |  |  | 21 |  |  | 238.0 |  |  | 21 |  |  | 38.8 |  |  | 16 |  |
| Total revenue | $ | 1,334.6 |  |  | 100 | % |  | $ | 1,149.5 |  |  | 100 | % |  | $ | 185.1 |  |  | 16 | % |

[0001262039-23-000038:mdna:89]
Total revenue increased $185.1 million, or 16%, during the three months ended September 30, 2023 compared to the same period last year. We continued to experience large organic revenue growth (i.e., revenue growth excluding attribution from recent acquisitions) with diversification of revenue geographically, and across both customers and industries. Revenue from all regions grew, with the Americas contributing the largest portion of the increase on an absolute dollar basis and on a percentage basis.

[0001262039-23-000038:mdna:90]
Product revenue decreased $2.8 million, or 1%, during the three months ended September 30, 2023 compared to the same period last year, reflecting product lead times and backlog aligning with historical levels, and decreased demand for our network security products as product demand returns to normal levels following approximately two years of elevated growth.

[0001262039-23-000038:mdna:91]
Service revenue increased $187.9 million, or 28%, during the three months ended September 30, 2023 compared to the same period last year. Security subscription revenue increased $124.8 million, or 34%, and technical support and other services revenue increased $63.1 million, or 20%, during the three months ended September 30, 2023 compared to the same period last year. The increases were primarily due to pricing actions in prior periods and the recognition of revenue from our growing deferred revenue balance related to security subscriptions. Security subscriptions outpaced technical support growth due to expansion of our SaaS-based security subscription service offerings. We expect that our ability to grow our service revenue will be impacted by slowing product revenue growth in recent periods and our ability to provide converged networking and security SASE solutions and to consolidate point products with our integrated SecOps platform of products to our customers.

[0001262039-23-000038:mdna:92]
Of the service revenue recognized during the three months ended September 30, 2023, 88% was included in the deferred revenue balance as of June 30, 2023. Of the service revenue recognized during the three months ended September 30, 2022, 88% was included in the deferred revenue balance as of June 30, 2022. We expect service revenue will continue to benefit from previous pricing actions. However, there are risks to service revenue growth rates, including customers reducing their spending, pricing actions, supply chain constraints, renewal rates, customers taking longer to buy their service and other risks.

[0001262039-23-000038:mdna:93]
[same as prior period, unchanged from 0001262039-23-000032:mdna:126]

[0001262039-23-000038:mdna:94]
|  | Three Months Ended |  |  |  |  |
| September 30,2023 |  | September 30,2022 |  | Change |  | % Change |
| (in millions, except percentages) |
| Cost of revenue: |  |  |  |  |  |  |  |
| Product | $ | 198.3 |  |  | $ | 185.2 |  |  | $ | 13.1 |  |  | 7 | % |
| Service | 119.4 |  |  | 97.8 |  |  | 21.6 |  |  | 22 |  |
| Total cost of revenue | $ | 317.7 |  |  | $ | 283.0 |  |  | $ | 34.7 |  |  | 12 | % |
| Gross margin (%): |  |  |  |  |  |  |  |
| Product | 57.4 | % |  | 60.5 | % |  |  |  |  |
| Service | 86.3 |  |  | 85.6 |  |  |  |  |  |
| Total gross margin | 76.2 | % |  | 75.4 | % |  |  |  |  |

[0001262039-23-000038:mdna:95]
Total gross margin increased 0.8 percentage points during the three months ended September 30, 2023 compared to the same period last year, primarily driven by a shift in the revenue mix and increased service gross margin, partially offset by decreased product gross margin. As a percentage of total revenue, the revenue mix shifted 5.9 percentage points from product revenue to service revenue.

[0001262039-23-000038:mdna:96]
Product gross margin decreased 3.1 percentage points during the three months ended September 30, 2023 compared to the same period last year, primarily due to inventory and inventory purchase commitments related reserves expense, partially offset by lower expedite fees, freight expenses and a shift in revenue mix from hardware to software. Cost of product revenue was comprised primarily of third-party contract manufacturers’ costs, costs of materials used in production and inventory reserves.

[0001262039-23-000038:mdna:97]
Service gross margin increased 0.7 percentage points during the three months ended September 30, 2023 compared to the same period last year. Cost of service revenue was comprised primarily of personnel-related costs and costs of hosted solutions. The increase in service gross margin was primarily driven by pricing actions in earlier periods. We continue to expand our hosted solutions, including SASE architectures. We consider our single vendor SASE solution opening to be a new market, and one where our SD-WAN installed base can be leveraged as a market access point. We significantly expanded our PoP deployment through our recently announced partnership with Google Cloud. We are making investments in our own PoPs as well as working with third-party service providers. In addition, we continue to expand our SecOps capabilities with AI technology, additional functions and enhanced integration.

[0001262039-23-000038:mdna:98]
[same as prior period, unchanged from 0001262039-23-000032:mdna:131]

[0001262039-23-000038:mdna:99]
[same as prior period, unchanged from 0001262039-23-000032:mdna:132]

[0001262039-23-000038:mdna:100]
|  | Three Months Ended |  | Change |  | % Change |
| September 30,2023 |  | September 30,2022 |  |
| Amount |  | % ofRevenue |  | Amount |  | % ofRevenue |  |
| (in millions, except percentages) |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | $ | 156.9 |  |  | 12 | % |  | $ | 134.3 |  |  | 12 | % |  | $ | 22.6 |  |  | 17 | % |
| Sales and marketing | 504.4 |  |  | 38 |  |  | 427.1 |  |  | 37 |  |  | 77.3 |  |  | 18 |  |
| General and administrative | 53.5 |  |  | 4 |  |  | 40.7 |  |  | 4 |  |  | 12.8 |  |  | 31 |  |
| Gain on IP matter | (1.1) |  |  | — |  |  | (1.1) |  |  | — |  |  | — |  |  | — |  |
| Total operating expenses | $ | 713.7 |  |  | 53 | % |  | $ | 601.0 |  |  | 52 | % |  | $ | 112.7 |  |  | 19 | % |
| Percentages have been rounded for presentation purposes and may differ from unrounded results. |

[0001262039-23-000038:mdna:101]
[same as prior period, unchanged from 0001262039-23-000032:mdna:134]

[0001262039-23-000038:mdna:102]
Research and development expense increased $22.6 million, or 17%, during the three months ended September 30, 2023 compared to the same period last year, primarily due to a $18.8 million increase in personnel-related costs as a result of increased headcount to support the development of new products and continued enhancements to our existing products. In addition, we incurred an increase of $2.5 million of depreciation and other occupancy costs. We currently intend to continue investing in our research and development organization and expect our research and development expense to increase in absolute dollars year over year during the remainder of 2023.

[0001262039-23-000038:mdna:103]
[same as prior period, unchanged from 0001262039-23-000032:mdna:136]

[0001262039-23-000038:mdna:104]
Sales and marketing expense increased $77.3 million, or 18%, during the three months ended September 30, 2023 compared to the same period last year, primarily due to a $62.0 million increase in personnel-related costs as we increased our sales and pipeline generation capacity. The increase in headcount is expected to help drive global market revenue increases. In addition, we incurred increases in depreciation and other occupancy expense of $3.4 million and travel expense of $3.2 million. We currently intend to continue making investments in sales and marketing resources critical to support our future growth and expect our sales and marketing expenses to increase in absolute dollars year over year during the remainder of 2023.

[0001262039-23-000038:mdna:105]
[same as prior period, unchanged from 0001262039-23-000032:mdna:138]

[0001262039-23-000038:mdna:106]
General and administrative expense increased $12.8 million, or 31%, during the three months ended September 30, 2023 compared to the same period last year, primarily due to an increase of $8.2 million in legal related fees and other professional service fees, $2.8 million in personnel-related costs and an increase of $1.5 million in provision for expected credit losses. We currently expect general and administrative expenses to increase in absolute dollars year over year during the remainder of 2023.

[0001262039-23-000038:mdna:107]
[same as prior period, unchanged from 0001262039-23-000032:mdna:140]

[0001262039-23-000038:mdna:108]
We generated operating income of $303.2 million during the three months ended September 30, 2023, an increase of $37.7 million, or 14%, compared to $265.5 million in the same period last year. Operating margin was 22.7% during the three months ended September 30, 2023, compared to 23.1% in the same period last year. The decrease in operating margin was primarily due to 0.6 percentage points increase in sales and marketing expense and 0.5 percentage points increase in general and administrative expense as a percentage of revenue, respectively, partially offset by 0.8 percentage points increase in gross margin.

[0001262039-23-000038:mdna:109]
35

[0001262039-23-000038:mdna:110]
[same as prior period, unchanged from 0001262039-23-000032:mdna:142]

[0001262039-23-000038:mdna:111]
|  | Three Months Ended |  |  |  |  |
| September 30,2023 |  | September 30,2022 |  | Change |  | % Change |
| (in millions, except percentages) |
| Interest income | $ | 37.0 |  |  | $ | 4.6 |  |  | $ | 32.4 |  |  | 704 | % |
| Interest expense | $ | (5.4) |  |  | $ | (4.5) |  |  | $ | (0.9) |  |  | 20 | % |
| Other expense—net | $ | (7.0) |  |  | $ | (0.9) |  |  | $ | (6.1) |  |  | 678 | % |

[0001262039-23-000038:mdna:112]
Interest income increased $32.4 million during the three months ended September 30, 2023 compared to the same period last year, as a result of higher interest rates and greater investment balances. Interest income varies depending on our average investment balances during the period, types and mix of investments, and market interest rates. Interest expense remained comparatively flat during the three months ended September 30, 2023 compared to the same period last year. The $6.1 million decrease in Other expense—net during the three months ended September 30, 2023 compared to the same period last year, was primarily due to a $4.9 million loss on marketable equity securities and $0.9 million increase in foreign currency exchange loss.

[0001262039-23-000038:mdna:113]
[same as prior period, unchanged from 0001262039-23-000032:mdna:179]

[0001262039-23-000038:mdna:114]
|  | Three Months Ended |  | Change |  | % Change |
| September 30,2023 |  | September 30,2022 |  |
| (in millions, except percentages) |
| Provision for (benefit from) income taxes | $ | (0.3) |  |  | $ | 27.3 |  |  | $ | (27.6) |  |  | (101) | % |
| Effective tax rate (%) | — | % |  | 10 | % |  |  |  |  |

[0001262039-23-000038:mdna:115]
Our effective tax rate was 0% for the three months ended September 30, 2023 compared to an effective tax rate of 10% for the same period last year. The benefit from income taxes for the three months ended September 30, 2023 was primarily comprised of U.S. federal and state taxes, withholding taxes and foreign taxes totaling $50.2 million, which were favorably affected by a tax benefit of $41.9 million from the foreign-derived intangible income deduction (the “FDII deduction”) and excess tax benefits from stock-based compensation expense of $8.6 million.

[0001262039-23-000038:mdna:116]
The provision for income taxes for the three months ended September 30, 2022 was comprised of U.S. federal and state taxes, withholding taxes, and foreign taxes totaling $75.5 million, which were favorably affected by a tax benefit of $28.9 million from the FDII deduction, excess tax benefits from stock-based compensation expense of $19.3 million.

[0001262039-23-000038:mdna:117]
[same as prior period, unchanged from 0001262039-23-000032:mdna:149]

[0001262039-23-000038:mdna:118]
|  | Three Months Ended |  | Change |  | % Change |
| September 30,2023 |  | September 30,2022 |  |
| (in millions, except percentages) |
| Loss from equity method investment | $ | (5.2) |  |  | $ | (6.3) |  |  | $ | 1.1 |  |  | (17) | % |

[0001262039-23-000038:mdna:119]
Loss from equity method investment decreased $1.1 million during the three months ended September 30, 2023 compared to the same period last year, as our proportionate share of Linksys’ financial results including our share of the amortization of the basis differences improved over the same period last year.

[0001262039-23-000038:mdna:120]
Nine Months Ended September 30, 2023 and 2022

[0001262039-23-000038:mdna:121]
[same as prior period, unchanged from 0001262039-23-000032:mdna:153]

[0001262039-23-000038:mdna:122]
|  | Nine Months Ended |  |  |  |  |
| September 30,2023 |  | September 30,2022 |  |  |  |  |
| Amount |  | % ofRevenue |  | Amount |  | % ofRevenue |  | Change |  | % Change |
| (in millions, except percentages) |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 1,439.2 |  |  | 37 | % |  | $ | 1,240.4 |  |  | 40 | % |  | $ | 198.8 |  |  | 16 | % |
| Service | 2,450.5 |  |  | 63 |  |  | 1,894.0 |  |  | 60 |  |  | 556.5 |  |  | 29 |  |
| Total revenue | $ | 3,889.7 |  |  | 100 | % |  | $ | 3,134.4 |  |  | 100 | % |  | $ | 755.3 |  |  | 24 | % |
| Revenue by geography: |  |  |  |  |  |  |  |  |  |  |  |
| Americas | $ | 1,606.1 |  |  | 41 | % |  | $ | 1,263.8 |  |  | 40 | % |  | $ | 342.3 |  |  | 27 | % |
| EMEA | 1,497.3 |  |  | 39 |  |  | 1,181.7 |  |  | 38 |  |  | 315.6 |  |  | 27 |  |
| APAC | 786.3 |  |  | 20 |  |  | 688.9 |  |  | 22 |  |  | 97.4 |  |  | 14 |  |
| Total revenue | $ | 3,889.7 |  |  | 100 | % |  | $ | 3,134.4 |  |  | 100 | % |  | $ | 755.3 |  |  | 24 | % |

[0001262039-23-000038:mdna:123]
Total revenue increased $755.3 million, or 24%, during the nine months ended September 30, 2023 compared to the same period last year. We continued to experience large organic revenue growth (i.e., revenue growth excluding attribution from recent acquisitions) with diversification of revenue geographically, and across both customers and industries. Revenue from all regions grew, with the Americas contributing the largest portion of the increase on an absolute dollar basis and on a percentage basis.

[0001262039-23-000038:mdna:124]
Product revenue increased $198.8 million, or 16%, during the nine months ended September 30, 2023 compared to the same period last year. Product revenue growth was consistent with an elevated cyber threat landscape, the convergence of security and networking, improving supply chain dynamics and changes in the backlog balance. The product revenue growth was primarily due to strong growth across many of our Enhanced Platform Technology products, including our secure access products.

[0001262039-23-000038:mdna:125]
Service revenue increased $556.5 million, or 29%, during the nine months ended September 30, 2023 compared to the same period last year. Security subscription revenue increased $350.5 million, or 34%, and technical support and other services revenue increased $206.0 million, or 24%, during the nine months ended September 30, 2023 compared to the same period last year. The increases were primarily due to pricing actions in prior periods and the recognition of revenue from our growing deferred revenue balance related to security subscriptions as well as technical support and other services. Security subscriptions outpaced technical support growth due to expansion of our SaaS-based security subscription service offerings.

[0001262039-23-000038:mdna:126]
Of the service revenue recognized during the nine months ended September 30, 2023, 73% was included in the deferred revenue balance as of December 31, 2022. Of the service revenue recognized during the nine months ended September 30, 2022, 72% was included in the deferred revenue balance as of December 31, 2021. We expect service revenue will continue to increase throughout the remainder of 2023, as our business is expected to grow, and as service revenue benefits from previous pricing actions. However, there are risks to service revenue growth rates, including customers reducing their spending, pricing actions, supply chain constraints, renewal rates, customers taking longer to buy their service and other risks.

[0001262039-23-000038:mdna:127]
[same as prior period, unchanged from 0001262039-23-000032:mdna:159]

[0001262039-23-000038:mdna:128]
[same as prior period, unchanged from 0001262039-23-000032:mdna:160]

[0001262039-23-000038:mdna:129]
|  | Nine Months Ended |  |  |  |  |
| September 30,2023 |  | September 30,2022 |  | Change |  | % Change |
| (in millions, except percentages) |
| Cost of revenue: |  |  |  |  |  |  |  |
| Product | $ | 566.4 |  |  | $ | 501.4 |  |  | $ | 65.0 |  |  | 13 | % |
| Service | 354.9 |  |  | 286.2 |  |  | 68.7 |  |  | 24 | % |
| Total cost of revenue | $ | 921.3 |  |  | $ | 787.6 |  |  | $ | 133.7 |  |  | 17 | % |
| Gross margin (%): |  |  |  |  |  |  |  |
| Product | 60.6 | % |  | 59.6 | % |  |  |  |  |
| Service | 85.5 |  |  | 84.9 |  |  |  |  |  |
| Total gross margin | 76.3 | % |  | 74.9 | % |  |  |  |  |

[0001262039-23-000038:mdna:130]
Total gross margin increased 1.4 percentage points during the nine months ended September 30, 2023 compared to the same period last year, primarily driven by increased product and service gross margins and a shift in the revenue mix. As a percentage of total revenue, the revenue mix shifted 2.6 percentage points from product revenue to service revenue.

[0001262039-23-000038:mdna:131]
Product gross margin increased 1.0 percentage points during the nine months ended September 30, 2023 compared to the same period last year. The product margin was primarily benefited from lower expedite fees and freight costs, partially offset by inventory and inventory purchase commitments related reserves expense. Cost of product revenue was comprised primarily of third-party contract manufacturers’ costs, costs of materials used in production and inventory reserves.

[0001262039-23-000038:mdna:132]
Service gross margin increased 0.6 percentage points during the nine months ended September 30, 2023 compared to the same period last year. Cost of service revenue was comprised primarily of personnel-related costs and costs of hosted solutions. The increase in service gross margin was primarily driven by pricing actions in earlier periods and the favorable impact of foreign currency fluctuations, partially offset by increased labor cost and our increased cloud delivery costs as we continue to expand our cloud and SASE delivery models.

[0001262039-23-000038:mdna:133]
[same as prior period, unchanged from 0001262039-23-000032:mdna:165]

[0001262039-23-000038:mdna:134]
|  | Nine Months Ended |  | Change |  | % Change |
| September 30,2023 |  | September 30,2022 |  |
| Amount |  | % ofRevenue |  | Amount |  | % ofRevenue |  |
| (in millions, except percentages) |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | $ | 461.3 |  |  | 12 | % |  | $ | 383.5 |  |  | 12 | % |  | $ | 77.8 |  |  | 20 | % |
| Sales and marketing | 1,498.6 |  |  | 39 |  |  | 1,230.2 |  |  | 39 |  |  | 268.4 |  |  | 22 |  |
| General and administrative | 156.2 |  |  | 4 |  |  | 124.7 |  |  | 4 |  |  | 31.5 |  |  | 25 |  |
| Gain on IP matter | (3.4) |  |  | — |  |  | (3.4) |  |  | — |  |  | — |  |  | — |  |
| Total operating expenses | $ | 2,112.7 |  |  | 54 | % |  | $ | 1,735.0 |  |  | 55 | % |  | $ | 377.7 |  |  | 22 | % |
| Percentages have been rounded for presentation purposes and may differ from unrounded results. |

[0001262039-23-000038:mdna:135]
[same as prior period, unchanged from 0001262039-23-000032:mdna:167]

[0001262039-23-000038:mdna:136]
Research and development expense increased $77.8 million, or 20%, during the nine months ended September 30, 2023 compared to the same period last year, primarily due to an increase of $60.1 million in personnel-related costs as a result of increased headcount to support the development of new products and continued enhancements to our existing products. In addition, non-personnel-related product development costs increased by $10.2 million and depreciation expense and other occupancy-related expense increased by $5.9 million, partially offset by the favorable impact of foreign currency fluctuations.

[0001262039-23-000038:mdna:137]
[same as prior period, unchanged from 0001262039-23-000032:mdna:169]

[0001262039-23-000038:mdna:138]
[same as prior period, unchanged from 0001262039-23-000032:mdna:170]

[0001262039-23-000038:mdna:139]
Sales and marketing expense increased $268.4 million, or 22%, during the nine months ended September 30, 2023 compared to the same period last year, primarily due to an increase of $202.7 million in personnel-related costs. We significantly increased our sales and pipeline generation capacity, including newer non-tenured sales people. The increase in headcount is expected to help drive global market revenue increases. In addition, marketing-related expense increased by $24.1 million, travel expense increased by $18.1 million and depreciation expense and other occupancy-related expense increased by $13.6 million, partially offset by the favorable impact of foreign currency fluctuations.

[0001262039-23-000038:mdna:140]
[same as prior period, unchanged from 0001262039-23-000032:mdna:172]

[0001262039-23-000038:mdna:141]
General and administrative expense increased $31.5 million, or 25%, during the nine months ended September 30, 2023 compared to the same period last year, primarily due to an increase of $16.0 million in legal related fees and other professional service fees and $12.5 million in personnel-related costs.

[0001262039-23-000038:mdna:142]
[same as prior period, unchanged from 0001262039-23-000032:mdna:174]

[0001262039-23-000038:mdna:143]
We generated operating income of $855.7 million during the nine months ended September 30, 2023, an increase of $243.9 million, or 40%, compared to $611.8 million in the same period last year. Operating margin increased to 22.0% during the nine months ended September 30, 2023 compared to 19.5% in the same period last year, mainly due to the stronger gross margin performance. The increase in operating margin was primarily due to 1.4 percentage points increase in gross margin, 0.7 percentage points decrease in sales and marketing expense and 0.3 percentage points decrease in research and development expense as a percentage of revenue, respectively.

[0001262039-23-000038:mdna:144]
[same as prior period, unchanged from 0001262039-23-000032:mdna:176]

[0001262039-23-000038:mdna:145]
|  | Nine Months Ended |  |  |  |  |
| September 30,2023 |  | September 30,2022 |  | Change |  | % Change |
| (in millions, except percentages) |
| Interest income | $ | 89.2 |  |  | $ | 8.3 |  |  | $ | 80.9 |  |  | 975 | % |
| Interest expense | $ | (15.6) |  |  | $ | (13.5) |  |  | $ | (2.1) |  |  | 16 | % |
| Other expense—net | $ | (11.2) |  |  | $ | (19.3) |  |  | $ | 8.1 |  |  | (42) | % |

[0001262039-23-000038:mdna:146]
Interest income increased $80.9 million during the nine months ended September 30, 2023 compared to the same period last year, primarily as a result of higher interest rates and greater investment balances. Interest income varies depending on our average investment balances during the period, types and mix of investments, and market interest rates. Interest expense remained comparatively flat during the nine months ended September 30, 2023 compared to the same period last year. Other expense—net decreased by $8.1 million during the nine months ended September 30, 2023 compared to the same period last year, due to a $6.0 million lower loss on marketable equity securities and a $2.1 million decrease of foreign currency exchange loss.

[0001262039-23-000038:mdna:147]
[same as prior period, unchanged from 0001262039-23-000032:mdna:145]

[0001262039-23-000038:mdna:148]
|  | Nine Months Ended |  | Change |  | % Change |
| September 30,2023 |  | September 30,2022 |  |
| (in millions, except percentages) |
| Provision for income taxes | $ | 48.6 |  |  | $ | 21.6 |  |  | $ | 27.0 |  |  | 125 | % |
| Effective tax rate (%) | 5 | % |  | 4 | % |  |  |  |  |

[0001262039-23-000038:mdna:149]
Our effective tax rate was 5% for the nine months ended September 30, 2023 compared to an effective tax rate of 4% for the same period last year. The provision for income taxes for the nine months ended September 30, 2023 was primarily comprised of U.S. federal and state taxes, withholding taxes and foreign taxes that were $220.9 million. This provision for income taxes was favorably affected by a tax benefit of $105.9 million from the FDII deduction, excess tax benefits from stock-based compensation expense of $48.3 million, and the release of reserves of $18.1 million on uncertain tax positions and the accrued interest thereon due to the expiration of statutes of limitations.

[0001262039-23-000038:mdna:150]
[same as prior period, unchanged from 0001262039-23-000032:mdna:182]

[0001262039-23-000038:mdna:151]
The provision for income taxes for the nine months ended September 30, 2022 was comprised of U.S. federal and state taxes, withholding taxes, and foreign taxes that were $169.2 million, which were offset by a tax benefit of $62.6 million from the FDII deduction, excess tax benefits from stock-based compensation expense of $68.7 million, and the release of reserves of $16.3 million on uncertain tax positions and the accrued interest thereon due to the expiration of statutes of limitations.

[0001262039-23-000038:mdna:152]
[same as prior period, unchanged from 0001262039-23-000032:mdna:184]

[0001262039-23-000038:mdna:153]
|  | Nine Months Ended |  | Change |  | % Change |
| September 30,2023 |  | September 30,2022 |  |
| (in millions, except percentages) |
| Loss from equity method investment | $ | (32.6) |  |  | $ | (22.9) |  |  | $ | (9.7) |  |  | 42 | % |

[0001262039-23-000038:mdna:154]
Loss from equity method investment increased $9.7 million during the nine months ended September 30, 2023 compared to the same period last year, as our proportionate share of Linksys’ financial results including our share of the amortization of the basis differences was higher compared to the same period last year.

[0001262039-23-000038:mdna:155]
[same as prior period, unchanged from 0001262039-23-000032:mdna:187]

[0001262039-23-000038:mdna:156]
|  | As of |
|  | September 30,2023 |  | December 31,2022 |
|  | (in millions) |
| Cash and cash equivalents | $ | 2,186.8 |  |  | $ | 1,682.9 |  |
| Short-term and long-term investments | 963.7 |  |  | 548.1 |  |
| Marketable equity securities | 19.8 |  |  | 25.5 |  |
| Total cash, cash equivalents, investments and marketable equity securities | $ | 3,170.3 |  |  | $ | 2,256.5 |  |
| Working capital | $ | 1,103.7 |  |  | $ | 732.0 |  |
|  | Nine Months Ended |
|  | September 30,2023 |  | September 30,2022 |
|  | (in millions) |
| Net cash provided by operating activities | $ | 1,743.8 |  |  | $ | 1,202.5 |  |
| Net cash provided by (used in) investing activities | (577.7) |  |  | 546.5 |  |
| Net cash used in financing activities | (660.3) |  |  | (2,102.9) |  |
| Effect of exchange rate changes on cash and cash equivalents | (1.9) |  |  | (1.2) |  |
| Net increase (decrease) in cash and cash equivalents | $ | 503.9 |  |  | $ | (355.1) |  |

[0001262039-23-000038:mdna:157]
Liquidity and capital resources are primarily impacted by our operating activities, as well as payment of taxes in connection with the net settlement of equity awards, real estate and other capital expenditures, proceeds from the issuance of common stock, cash used for stock repurchases and the timing of income tax payments. In accordance with disaster relief announced by the Internal Revenue Service, we postponed U.S. federal tax payments from the second quarter and the third quarter of 2023 to the fourth quarter of 2023. We expect that our cash payments for income taxes to be significantly higher, in the range of $340.0 million to $350.0 million in the fourth quarter of 2023.

[0001262039-23-000038:mdna:158]
In recent years, we have received significant capital resources from our billings to customers, issuance of investment grade debt and, to some extent, from the exercise of stock options by our employees. Additional increases in billings may depend on a number of factors, including demand for and availability of our products and services, competition, pricing actions, market or industry changes, macroeconomic events such as rising inflation and interest rates, economic strength, supply chain capacity and disruptions, international conflicts, including the war in Ukraine and the Israel-Hamas war, and our ability to execute. We expect proceeds from the exercise of stock options in future years to be impacted by the increased mix of restricted stock units and performance stock units versus stock options granted to our employees and to vary based on our share price.

[0001262039-23-000038:mdna:159]
In February 2023, our board of directors approved an extension of the Repurchase Program to February 29, 2024. In April 2023 and July 2023, our board of directors approved $1.0 billion and $500.0 million increases in the authorized amount under the Repurchase Program, respectively, bringing the aggregate amount authorized to be repurchased to $6.75 billion of our

[0001262039-23-000038:mdna:160]
[same as prior period, unchanged from 0001262039-23-000032:mdna:191]

[0001262039-23-000038:mdna:161]
outstanding common stock through February 29, 2024. During the nine months ended September 30, 2023, we repurchased 10.4 million shares of common stock under the Repurchase program for an aggregate purchase price of $605.2 million. As of September 30, 2023, approximately $1.42 billion remained available for future share repurchases.

[0001262039-23-000038:mdna:162]
We expect to continue to increase our data centers, PoPs, office and warehouse capacity to support growth and the expansion of existing services or introduction of new services. As we purchase new properties, we will work to incorporate these properties into the environmental goals we have established. We estimate capital expenditures to be between approximately $40.0 million and $60.0 million for the fourth quarter of 2023.

[0001262039-23-000038:mdna:163]
We believe that our cash provided by operating activities, together with our existing cash, cash equivalents and investments will be sufficient to meet our anticipated cash needs and do not currently intend to retire our Senior Notes early. Refer to Note 10, Debt, in Part I, Item 1 of this Quarterly Report on Form 10-Q for information on the Senior Notes. As of September 30, 2023, the long-term debt, net of unamortized discount and debt issuance costs, was $991.8 million.

[0001262039-23-000038:mdna:164]
We enter into non-cancellable agreements with contract manufacturers and certain component suppliers to procure inventory based on our requirements in order to negotiate manufacturing lead times and encourage and incentivize vendors to deliver components and finished goods. In certain instances, these agreements allow us the option to reschedule and adjust our requirements based on our business needs prior to firm orders being placed. These purchase commitments as of September 30, 2023 totaled $820.6 million, a decrease of $514.4 million compared to $1.34 billion as of December 31, 2022 due to fulfillment of customer demand as our supply availability improved and our continued efforts to work with contract manufacturers and suppliers to optimize our inventory and purchase commitment position. We increased our purchase commitments in prior years to address significant supply constraints seen industry-wide due to component shortages. Our agreements secured supply and pricing for certain product components commitments with contract manufacturers to meet customer demand and to address extended lead times. We record a liability for non-cancelable inventory purchase commitments for quantities in excess of our future estimated demand forecasts. As of September 30, 2023, the liability for these inventory purchase commitments was $64.6 million and was included in accrued liabilities. As of December 31, 2022, the liability for these purchase commitments was not material. We also have open purchase orders and contractual obligations in the ordinary course of business for which we have not received goods or services. As of September 30, 2023, we had $76.8 million in other contractual commitments having a remaining term in excess of one year that are non-cancelable.

[0001262039-23-000038:mdna:165]
[same as prior period, unchanged from 0001262039-23-000032:mdna:196]

[0001262039-23-000038:mdna:166]
As of September 30, 2023, our cash, cash equivalents, short-term and long-term investments of $3.15 billion were invested primarily in deposit accounts, money market funds, corporate debt securities, commercial paper, certificates of deposit and term deposits, U.S. government and agency securities and municipal bonds. It is our investment policy to invest excess cash in a manner that preserves capital, provides liquidity and generates return without significantly increasing risk. We do not enter into investments for trading or speculative purposes.

[0001262039-23-000038:mdna:167]
The amount of cash, cash equivalents and investments held by our international subsidiaries was $210.2 million as of September 30, 2023 and $218.1 million as of December 31, 2022.

[0001262039-23-000038:mdna:168]
We believe that our existing cash and cash equivalents and cash flow from operations will be sufficient for at least the next 12 months to meet our requirements and plans for cash, including meeting our working capital requirements and capital expenditure requirements. In the long term, our ability to support our requirements and plans for cash, including our working capital and capital expenditure requirements will depend on many factors, including our growth rate; the timing and amount of our share repurchases; the expansion of sales and marketing activities, pricing actions, the introduction of new and enhanced products and services offerings; the continuing market acceptance of our products; the timing and extent of spending to support development efforts; our investments in purchasing, developing or leasing real estate; cash tax payments and macroeconomic impacts such as rising inflation and interest rates; the war in Ukraine and the Israel-Hamas war; and instability in the global banking system. Historically, we have required capital principally to fund our working capital needs, share repurchases, capital expenditures and acquisition activities. In the event that additional financing is required from outside sources, we may not be able to raise it on terms acceptable to us or at all.

[0001262039-23-000038:mdna:169]
As of September 30, 2023, we did not have any relationships with unconsolidated organizations or financial partnerships, such as structured finance or special purpose entities that would have been established for the purpose of facilitating off-balance sheet arrangements or other contractually narrow or limited purposes.

[0001262039-23-000038:mdna:170]
[same as prior period, unchanged from 0001262039-23-000032:mdna:202]

[0001262039-23-000038:mdna:171]
Cash generated by operating activities is our primary source of liquidity. It is primarily comprised of net income, as adjusted for non-cash items and changes in operating assets and liabilities. Non-cash adjustments consist primarily of

[0001262039-23-000038:mdna:172]
[same as prior period, unchanged from 0001262039-23-000032:mdna:201]

[0001262039-23-000038:mdna:173]
amortization of deferred contract costs, stock-based compensation and depreciation and amortization. Changes in operating assets and liabilities consist primarily of changes in deferred revenue, deferred contract costs, accounts receivable—net, inventory, deferred tax assets and income taxes payable.

[0001262039-23-000038:mdna:174]
Our operating activities during the nine months ended September 30, 2023 provided cash flows of $1.74 billion, an increase of $541.3 million compared to the same period last year, as a result of the continued growth of our business, improved profitability and our ability to successfully manage our working capital. Changes in operating assets and liabilities primarily resulted from an increase in sales of our security subscription services and technical support services to new and existing customers, as reflected by an increase of $646.2 million in our deferred revenue during the nine months ended September 30, 2023. In addition, changes in operating assets and liabilities were driven by an increase of $247.5 million in deferred contract costs, a decrease of $243.4 million in accounts receivable—net, an increase of $231.0 million in inventory, an increase of $221.7 million in deferred tax assets and an increase of $196.8 million in income taxes payable as we deferred our U.S. federal tax payments in the second quarter and the third quarter of 2023 following the disaster relief provided by the Internal Revenue Service.

[0001262039-23-000038:mdna:175]
[same as prior period, unchanged from 0001262039-23-000032:mdna:206]

[0001262039-23-000038:mdna:176]
[same as prior period, unchanged from 0001262039-23-000032:mdna:207]

[0001262039-23-000038:mdna:177]
During the nine months ended September 30, 2023, cash used in investing activities was $577.7 million, primarily driven by $392.1 million spent for purchases of investments, net of maturities and sales of investments, $177.2 million of purchases of property and equipment and $8.5 million of purchase of investment in privately held company.

[0001262039-23-000038:mdna:178]
[same as prior period, unchanged from 0001262039-23-000032:mdna:209]

[0001262039-23-000038:mdna:179]
[same as prior period, unchanged from 0001262039-23-000032:mdna:210]

[0001262039-23-000038:mdna:180]
During the nine months ended September 30, 2023, cash used in financing activities was $660.3 million, primarily driven by $604.3 million used to repurchase shares of our common stock and $54.8 million used to pay tax withholding, net of proceeds from the issuance of common stock.
