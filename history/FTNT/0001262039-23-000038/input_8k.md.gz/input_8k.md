# FTNT 8-K — 0001262039-23-000035 filed 2023-11-02

## item codes, every 8-K on or before 2023-11-07

- 2023-11-02 0001262039-23-000035 — 2.02, 9.01
- 2023-08-03 0001262039-23-000027 — 2.02, 9.01
- 2023-06-23 0001262039-23-000024 — 5.03, 5.07, 9.01
- 2023-05-04 0001262039-23-000013 — 2.02, 9.01
- 2023-02-08 0001262039-23-000006 — 5.03, 9.01
- 2023-02-07 0001262039-23-000003 — 2.02, 9.01
- 2022-11-02 0001262039-22-000035 — 2.02, 9.01
- 2022-08-03 0001262039-22-000026 — 2.02, 9.01
- 2022-06-22 0001262039-22-000023 — 5.03, 9.01
- 2022-06-21 0001262039-22-000021 — 5.07
- 2022-05-04 0001262039-22-000015 — 2.02, 9.01
- 2022-05-02 0001262039-22-000012 — 5.02
- 2022-04-22 0001262039-22-000010 — 8.01
- 2022-02-03 0001262039-22-000005 — 2.02, 9.01
- 2022-01-26 0001262039-22-000002 — 5.02, 9.01 — amendment, the index does not say of what
- 2021-11-04 0001262039-21-000027 — 2.02, 9.01
- 2021-10-06 0001262039-21-000024 — 5.02, 9.01
- 2021-07-29 0001262039-21-000019 — 2.02, 9.01
- 2021-06-23 0001262039-21-000016 — 5.07
- 2021-04-30 0001104659-21-059008 — 5.03 — amendment, the index does not say of what
- 2021-04-29 0001262039-21-000011 — 2.02, 9.01
- 2021-04-28 0001104659-21-056360 — 5.02, 5.03, 9.01
- 2021-03-05 0001193125-21-071498 — 1.01, 9.01
- 2021-02-25 0001193125-21-057281 — 1.01, 9.01
- 2021-02-04 0001262039-21-000005 — 2.02, 9.01
- 2020-12-08 0001262039-20-000070 — 8.01
- 2020-10-29 0001262039-20-000063 — 2.02, 9.01
- 2020-10-20 0001262039-20-000060 — 5.02 — amendment, the index does not say of what
- 2020-08-26 0001262039-20-000056 — 5.02, 9.01
- 2020-08-06 0001262039-20-000051 — 2.02, 9.01
- 2020-07-21 0001262039-20-000044 — 5.03, 8.01, 9.01
- 2020-06-24 0001262039-20-000038 — 5.07
- 2020-05-06 0001262039-20-000029 — 2.02, 9.01
- 2020-04-23 0001262039-20-000025 — 5.03, 9.01
- 2020-04-23 0001262039-20-000024 — 5.02 — amendment of 0001262039-20-000025
- 2020-02-28 0001262039-20-000015 — 5.02, 9.01
- 2020-02-06 0001262039-20-000004 — 2.02, 9.01
- 2019-12-12 0001262039-19-000038 — 8.01
- 2019-10-31 0001262039-19-000032 — 2.02, 9.01
- 2019-10-28 0001262039-19-000027 — 8.01
- 2019-10-23 0001262039-19-000025 — 5.02, 9.01
- 2019-08-01 0001262039-19-000021 — 2.02, 9.01
- 2019-06-26 0001262039-19-000018 — 5.07
- 2019-05-02 0001262039-19-000010 — 2.02, 9.01
- 2019-02-06 0001262039-19-000002 — 2.02, 9.01
- 2018-11-01 0001262039-18-000037 — 2.02, 9.01
- 2018-10-23 0001262039-18-000035 — 8.01
- 2018-08-01 0001262039-18-000025 — 2.02, 9.01
- 2018-06-28 0001262039-18-000023 — 5.03, 5.07, 9.01
- 2018-06-04 0001262039-18-000021 — 8.01
- 2018-05-03 0001262039-18-000017 — 2.02, 5.02, 9.01
- 2018-02-05 0001262039-18-000004 — 2.02, 5.02, 9.01
- 2017-10-26 0001262039-17-000031 — 2.02, 9.01
- 2017-10-19 0001262039-17-000029 — 5.02 — amendment, the index does not say of what
- 2017-07-26 0001262039-17-000025 — 2.02, 9.01
- 2017-06-27 0001262039-17-000023 — 5.07
- 2017-05-31 0001262039-17-000021 — 5.02 — amendment of 0001262039-17-000019
- 2017-05-30 0001262039-17-000019 — 5.02, 9.01
- 2017-04-27 0001262039-17-000013 — 2.02, 9.01
- 2017-02-02 0001262039-17-000003 — 2.02, 9.01
- 2016-10-27 0001262039-16-000085 — 2.02, 9.01
- 2016-10-11 0001262039-16-000082 — 2.02, 9.01
- 2016-07-28 0001262039-16-000076 — 2.02, 9.01
- 2016-07-22 0001262039-16-000073 — 8.01, 9.01
- 2016-06-20 0001262039-16-000068 — 5.07
- 2016-06-07 0001193125-16-614788 — 8.01
- 2016-04-26 0001262039-16-000061 — 2.02, 9.01
- 2016-01-28 0001262039-16-000051 — 2.02, 9.01
- 2015-10-27 0001262039-15-000045 — 2.02
- 2015-10-22 0001262039-15-000042 — 5.02 — amendment, the index does not say of what
- 2015-10-22 0001262039-15-000041 — 5.02 — amendment, the index does not say of what
- 2015-10-22 0001262039-15-000039 — 2.02, 9.01
- 2015-09-28 0001262039-15-000034 — 5.02, 9.01
- 2015-09-22 0001262039-15-000031 — 9.01 — amendment of 0001193125-15-248065
- 2015-08-28 0001262039-15-000027 — 3.01, 5.02
- 2015-07-23 0001262039-15-000021 — 5.02
- 2015-07-22 0001262039-15-000019 — 2.02, 9.01
- 2015-07-08 0001193125-15-248065 — 2.01, 8.01, 9.01
- 2015-06-22 0001193125-15-229099 — 5.07
- 2015-06-19 0001193125-15-228428 — 5.02, 9.01
- 2015-04-20 0001262039-15-000014 — 2.02, 9.01
- 2015-01-28 0001262039-15-000005 — 2.02, 9.01
- 2014-10-22 0001262039-14-000036 — 2.02, 9.01
- 2014-07-23 0001262039-14-000030 — 2.02, 9.01
- 2014-06-24 0001262039-14-000027 — 5.07
- 2014-04-23 0001262039-14-000021 — 2.02, 9.01
- 2014-04-21 0001262039-14-000018 — 5.03, 9.01
- 2014-01-29 0001262039-14-000004 — 2.02, 9.01
- 2013-12-20 0001262039-13-000061 — 5.02, 9.01
- 2013-11-27 0001262039-13-000057 — 5.02, 7.01, 9.01
- 2013-11-12 0001445305-13-002993 — 5.02
- 2013-10-23 0001262039-13-000051 — 2.02, 9.01
- 2013-07-30 0001262039-13-000039 — 2.02, 9.01
- 2013-06-25 0001262039-13-000030 — 5.07
- 2013-04-30 0001262039-13-000023 — 2.02, 9.01
- 2013-04-19 0001262039-13-000020 — 5.02, 9.01
- 2013-04-19 0001262039-13-000018 — 5.02 — amendment of 0001262039-13-000020
- 2013-04-10 0001262039-13-000016 — 2.02, 9.01
- 2013-03-26 0001262039-13-000013 — 5.02
- 2013-01-30 0001262039-13-000005 — 2.02, 9.01
- 2013-01-24 0001262039-13-000002 — 5.02, 9.01
- 2012-10-16 0001262039-12-000048 — 2.02, 9.01
- 2012-10-01 0001262039-12-000045 — 5.02
- 2012-09-26 0001262039-12-000043 — 5.01
- 2012-07-25 0001262039-12-000038 — 2.02, 9.01
- 2012-07-19 0001262039-12-000034 — 5.02
- 2012-06-20 0001193125-12-275869 — 5.07
- 2012-04-27 0001262039-12-000029 — 5.02
- 2012-04-24 0001262039-12-000025 — 2.02, 9.01
- 2012-01-31 0001262039-12-000006 — 2.02, 9.01
- 2012-01-25 0001262039-12-000003 — 5.03
- 2011-10-24 0001262039-11-000036 — 2.02
- 2011-07-19 0001262039-11-000014 — 2.02, 9.01
- 2011-06-27 0001193125-11-174474 — 5.02, 5.07, 9.01
- 2011-04-27 0001193125-11-111938 — 2.02, 9.01
- 2011-01-25 0001193125-11-013914 — 2.02, 9.01
- 2010-10-21 0001193125-10-233676 — 2.02, 9.01
- 2010-09-02 0001193125-10-203099 — 8.01
- 2010-07-22 0001193125-10-163844 — 2.02, 9.01
- 2010-06-24 0001193125-10-146082 — 5.07
- 2010-04-28 0001193125-10-096698 — 2.02, 9.01
- 2010-02-09 0001193125-10-024614 — 8.01
- 2010-01-27 0001193125-10-014292 — 2.02, 9.01
- 2010-01-26 0001193125-10-013031 — 5.02, 9.01

## late-filing notifications on or before 2023-11-07

- none on or before 2023-11-07

## item 2.02 — earnings release, exhibit 99.1

[0001262039-23-000035:8k_2_02:1]
EX-99.1
2
ftntq3-2023ex991.htm
PRESS RELEASE

[0001262039-23-000035:8k_2_02:2]
Document

[0001262039-23-000035:8k_2_02:3]
Press Release

[0001262039-23-000035:8k_2_02:4]
Fortinet Reports Third Quarter 2023 Financial Results

[0001262039-23-000035:8k_2_02:5]
Third Quarter 2023 Highlights

[0001262039-23-000035:8k_2_02:6]
•Total revenue of $1.33 billion, up 16% year over year

[0001262039-23-000035:8k_2_02:7]
•Service revenue of $868.7 million, up 28% year over year

[0001262039-23-000035:8k_2_02:8]
•Billings of $1.49 billion, up 6% year over year1

[0001262039-23-000035:8k_2_02:9]
•Deferred revenue of $5.29 billion, up 26% year over year

[0001262039-23-000035:8k_2_02:10]
•GAAP operating income of $303.2 million, up 14% year over year

[0001262039-23-000035:8k_2_02:11]
•Non-GAAP operating income of $371.4 million, up 14% year over year1

[0001262039-23-000035:8k_2_02:12]
•GAAP operating margin of 22.7%

[0001262039-23-000035:8k_2_02:13]
•Non-GAAP operating margin of 27.8%1

[0001262039-23-000035:8k_2_02:14]
•GAAP diluted net income per share attributable to Fortinet, Inc. of $0.41, up 41% year over year

[0001262039-23-000035:8k_2_02:15]
•Non-GAAP diluted net income per share attributable to Fortinet, Inc. of $0.41, up 24% year over year1

[0001262039-23-000035:8k_2_02:16]
•Cash flow from operations of $551.2 million

[0001262039-23-000035:8k_2_02:17]
•Free cash flow of $481.1 million1

[0001262039-23-000035:8k_2_02:18]
SUNNYVALE, Calif. - November 2, 2023 - Fortinet® (Nasdaq: FTNT), a global cybersecurity leader driving the convergence of networking and security, today announced financial results for the third quarter ended September 30, 2023.

[0001262039-23-000035:8k_2_02:19]
“While the Secure Networking market is experiencing slower growth as product demand returns to normal levels following two years of elevated growth, we are leveraging our scale, go-to-market capabilities and engineering expertise to focus our attention on the faster growing SASE and Security Operations markets, in addition to continuing our focus on Secure Networking,” said Ken Xie, Founder, Chairman and Chief Executive Officer of Fortinet. “We are well-positioned to capitalize on these emerging growth opportunities by leveraging our integrated FortiOS operating system, industry leadership in firewall and SD-WAN, and exceptional solutions in each of the SASE and Security Operations markets.”

[0001262039-23-000035:8k_2_02:20]
Financial Highlights for the Third Quarter of 2023

[0001262039-23-000035:8k_2_02:21]
•Revenue: Total revenue was $1.33 billion for the third quarter of 2023, an increase of 16.1% compared to $1.15 billion for the same quarter of 2022.

[0001262039-23-000035:8k_2_02:22]
•Product Revenue: Product revenue was $465.9 million for the third quarter of 2023, a decrease of 0.6% compared to $468.7 million for the same quarter of 2022.

[0001262039-23-000035:8k_2_02:23]
•Service Revenue: Service revenue was $868.7 million for the third quarter of 2023, an increase of 27.6% compared to $680.8 million for the same quarter of 2022.

[0001262039-23-000035:8k_2_02:24]
•Billings1: Total billings were $1.49 billion for the third quarter of 2023, an increase of 5.7% compared to $1.41 billion for the same quarter of 2022.

[0001262039-23-000035:8k_2_02:25]
•Deferred Revenue: Total deferred revenue was $5.29 billion as of September 30, 2023, an increase of 26.0% compared to $4.19 billion as of September 30, 2022.

[0001262039-23-000035:8k_2_02:26]
•GAAP Operating Income and Margin: GAAP operating income was $303.2 million for the third quarter of 2023, representing a GAAP operating margin of 22.7%. GAAP operating income was $265.5 million for the same quarter of 2022, representing a GAAP operating margin of 23.1%.

[0001262039-23-000035:8k_2_02:27]
•Non-GAAP Operating Income and Margin1: Non-GAAP operating income was $371.4 million for the third quarter of 2023, representing a non-GAAP operating margin of 27.8%. Non-GAAP operating income was $324.9 million for the same quarter of 2022, representing a non-GAAP operating margin of 28.3%.

[0001262039-23-000035:8k_2_02:28]
•GAAP Net Income and Diluted Net Income Per Share Attributable to Fortinet, Inc.: GAAP net income was $322.9 million for the third quarter of 2023, compared to GAAP net income of $231.6 million for the same quarter of 2022. GAAP diluted net income per share was $0.41 for the third quarter of 2023, based on 791.2 million diluted weighted-average shares outstanding, compared to GAAP diluted net income per share of $0.29 for the same quarter of 2022, based on 798.6 million diluted weighted-average shares outstanding.

[0001262039-23-000035:8k_2_02:29]
•Non-GAAP Net Income and Diluted Net Income Per Share Attributable to Fortinet, Inc.1: Non-GAAP net income was $323.5 million for the third quarter of 2023, compared to non-GAAP net income of $262.7 million for the same quarter of 2022. Non-GAAP diluted net income per share was $0.41 for the third quarter of 2023, based on 791.2 million diluted weighted-average shares outstanding, compared to $0.33 for the same quarter of 2022, based on 798.6 million diluted weighted-average shares outstanding.

[0001262039-23-000035:8k_2_02:30]
•Cash Flow: Cash flow from operations was $551.2 million for the third quarter of 2023, compared to $483.0 million for the same quarter of 2022.

[0001262039-23-000035:8k_2_02:31]
•Free Cash Flow1: Free cash flow was $481.1 million for the third quarter of 2023, compared to $395.2 million for the same quarter of 2022.

[0001262039-23-000035:8k_2_02:32]
•Share Repurchase Program: During the three and nine months ended September 30, 2023, Fortinet repurchased 10.4 million shares of its common stock at an average price of $58.43 per share and for an aggregate purchase price of $605.2 million. During the three and nine months ended September 30, 2022, Fortinet repurchased 10.2 million and 36.0 million shares of its common stock, respectively, at an average price of $49.15 and $55.37 per share, respectively, and for an aggregate purchase price of  $500.0 million and $1.99 billion, respectively. Subsequent to September 30, 2023 through October 31, 2023, Fortinet repurchased 7.7 million shares of its common stock at an average price of $57.43 per share for an aggregate purchase price of $444.4 million.

[0001262039-23-000035:8k_2_02:33]
Guidance

[0001262039-23-000035:8k_2_02:34]
For the fourth quarter of 2023, Fortinet currently expects:

[0001262039-23-000035:8k_2_02:35]
•Revenue in the range of $1.380 billion to $1.440 billion

[0001262039-23-000035:8k_2_02:36]
•Billings in the range of $1.560 billion to $1.700 billion

[0001262039-23-000035:8k_2_02:37]
•Non-GAAP gross margin in the range of 75.5% to 76.5%

[0001262039-23-000035:8k_2_02:38]
•Non-GAAP operating margin in the range of 27.5% to 28.5%

[0001262039-23-000035:8k_2_02:39]
•Diluted non-GAAP net income per share attributable to Fortinet, Inc. in the range of $0.42 to $0.44, assuming a non-GAAP effective tax rate of 17%. This assumes a diluted share count of 780 million to 790 million.

[0001262039-23-000035:8k_2_02:40]
For the fiscal year 2023, Fortinet currently expects:

[0001262039-23-000035:8k_2_02:41]
•Revenue in the range of $5.270 billion to $5.330 billion

[0001262039-23-000035:8k_2_02:42]
•Service revenue in the range of $3.355 billion to $3.375 billion

[0001262039-23-000035:8k_2_02:43]
•Billings in the range of $6.095 billion to $6.235 billion

[0001262039-23-000035:8k_2_02:44]
•Non-GAAP gross margin in the range of 76.0% to 77.0%

[0001262039-23-000035:8k_2_02:45]
•Non-GAAP operating margin in the range of 26.5% to 27.5%

[0001262039-23-000035:8k_2_02:46]
•Diluted non-GAAP net income per share attributable to Fortinet, Inc. in the range of $1.54 to $1.56, assuming a non-GAAP effective tax rate of 17%. This assumes a diluted share count of 790 million to 800 million.

[0001262039-23-000035:8k_2_02:47]
Our guidance with respect to non-GAAP financial measures excludes stock-based compensation, amortization of acquired intangible assets and gain on intellectual property matters. We have not reconciled our guidance with respect to non-GAAP financial measures to the corresponding GAAP measures because certain items that impact these measures are uncertain or out of our control, or cannot be reasonably predicted. Accordingly, a reconciliation of these non-GAAP financial measures to the corresponding GAAP measures is not available without unreasonable effort.

[0001262039-23-000035:8k_2_02:48]
1 A reconciliation of GAAP to non-GAAP measures has been provided in the financial statement tables included in this press release. An explanation of these measures is also included below under the heading “Non-GAAP Financial Measures”.

[0001262039-23-000035:8k_2_02:49]
Conference Call Details

[0001262039-23-000035:8k_2_02:50]
Fortinet will host a conference call today at 1:30 p.m. Pacific Time (4:30 p.m. Eastern Time) to discuss the earnings results. A live webcast of the conference call and supplemental slides will be accessible from the Investor Relations page of Fortinet’s website at https://investor.fortinet.com and a replay will be archived and accessible at https://investor.fortinet.com/events-and-presentations.

[0001262039-23-000035:8k_2_02:51]
Fourth Quarter 2023 Conference Participation Schedule:

[0001262039-23-000035:8k_2_02:52]
•Stifel Midwest One-on-One Growth Conference

[0001262039-23-000035:8k_2_02:53]
November 9, 2023

[0001262039-23-000035:8k_2_02:54]
•Wells Fargo TMT Summit

[0001262039-23-000035:8k_2_02:55]
November 28, 2023

[0001262039-23-000035:8k_2_02:56]
•Barclays Global Technology, Media & Telecommunications Conference

[0001262039-23-000035:8k_2_02:57]
December 6, 2023

[0001262039-23-000035:8k_2_02:58]
Members of Fortinet’s management team are expected to present at these conferences and discuss the latest company strategies and initiatives. Fortinet’s conference presentations are expected to be available via webcast on the company’s web site. To access the most updated information, pre-register and listen to the webcast of each event, please visit the Investor Presentation & Events page of Fortinet’s website at https://investor.fortinet.com/events-and-presentations. The schedule is subject to change.

[0001262039-23-000035:8k_2_02:59]
About Fortinet (www.fortinet.com)

[0001262039-23-000035:8k_2_02:60]
Fortinet (Nasdaq: FTNT) is a driving force in the evolution of cybersecurity and the convergence of networking and security. Our mission is to secure people, devices and data everywhere, and today we deliver cybersecurity everywhere our customers need it with the largest integrated portfolio of over 50 enterprise-grade products. Over half a million customers trust Fortinet's solutions, which are among the most deployed, most patented and most validated in the industry. The Fortinet Training Institute, one of the largest and broadest training programs in the industry, is dedicated to making cybersecurity training and new career opportunities available to everyone. FortiGuard Labs, Fortinet’s elite threat intelligence and research organization, develops and utilizes leading-edge machine learning and AI technologies to provide customers with timely and consistently top-rated protection and actionable threat intelligence. Learn more at https://www.fortinet.com, the Fortinet Blog or FortiGuard Labs.

[0001262039-23-000035:8k_2_02:61]
#          #          #

[0001262039-23-000035:8k_2_02:62]
Copyright © 2023 Fortinet, Inc. All rights reserved. The symbols ® and ™ denote respectively federally registered trademarks and common law trademarks of Fortinet, Inc., its subsidiaries and affiliates. Fortinet’s trademarks include, but are not limited to, the following: Fortinet, the Fortinet logo, FortiGate, FortiOS, FortiGuard, FortiCare, FortiAnalyzer, FortiManager, FortiASIC, FortiClient, FortiCloud, FortiMail, FortiSandbox, FortiADC, FortiAIOps, FortiAntenna, FortiAP, FortiAPCam, FortiAuthenticator, FortiCache, FortiCall, FortiCam, FortiCamera, FortiCarrier, FortiCASB, FortiCentral, FortiCNP, FortiConnect, FortiController, FortiConverter, FortiCWP, FortiDAST, FortiDB, FortiDDoS, FortiDeceptor, FortiDeploy, FortiDevSec, FortiEDR, FortiExplorer, FortiExtender, FortiFirewall, FortiFlex, FortiFone, FortiGSLB, FortiGuest, FortiHypervisor, FortiInsight, FortiIsolator, FortiLAN, FortiLink, FortiMonitor, FortiNAC, FortiNDR, FortiPAM, FortiPenTest, FortiPhish, FortiPoint, FortiPolicy, FortiPortal, FortiPresence, FortiProxy, FortiRecon, FortiRecorder, FortiSASE, FortiSDNConnector, FortiSIEM, FortiSMS, FortiSOAR, FortiStack, FortiSwitch, FortiTester, FortiToken, FortiTrust, FortiVoice, FortiWAN, FortiWeb, FortiWiFi, FortiWLC, FortiWLM and FortiXDR. Other trademarks belong to their respective owners. Fortinet has not independently verified statements or certifications herein attributed to third parties and Fortinet does not independently endorse such statements. Notwithstanding anything to the contrary herein, nothing herein constitutes a warranty, guarantee, contract, binding specification or other binding commitment by Fortinet or any indication of intent related to a binding commitment, and performance and other specification information herein may be unique to certain environments.

[0001262039-23-000035:8k_2_02:63]
FTNT-F

[0001262039-23-000035:8k_2_02:64]
Forward-Looking Statements

[0001262039-23-000035:8k_2_02:65]
This press release contains forward-looking statements that involve risks and uncertainties. These forward-looking statements include statements regarding any indications related to future growth and market share gains, our strategy going forward, and guidance and expectations around future financial results, including guidance and expectations for the fourth quarter and

[0001262039-23-000035:8k_2_02:66]
Non-GAAP Financial Measures

[0001262039-23-000035:8k_2_02:67]
We have provided in this release financial information that has not been prepared in accordance with U.S. Generally Accepted Accounting Principles (GAAP). These non-GAAP financial and liquidity measures are not based on any standardized methodology prescribed by GAAP and are not necessarily comparable to similar measures presented by other companies. We use these non-GAAP financial measures internally in analyzing our financial results and believe they

[0001262039-23-000035:8k_2_02:68]
are useful to investors, as a supplement to GAAP measures, in evaluating our ongoing operational performance. We believe that the use of these non-GAAP financial measures provides an additional tool for investors to use in evaluating ongoing operating results and trends and in comparing our financial results with peer companies, many of which present similar non-GAAP financial measures to investors.

[0001262039-23-000035:8k_2_02:69]
Non-GAAP financial measures should not be considered in isolation from, or as a substitute for, financial information prepared in accordance with GAAP. Investors are encouraged to review the reconciliation of these non-GAAP financial measures to their most directly comparable GAAP financial measures provided in the financial statement tables below.

[0001262039-23-000035:8k_2_02:70]
Billings (non-GAAP). We define billings as revenue recognized in accordance with GAAP plus the change in deferred revenue from the beginning to the end of the period less any deferred revenue balances acquired from business combination(s) during the period. We consider billings to be a useful metric for management and investors because billings drive current and future revenue, which is an important indicator of the health and viability of our business. There are a number of limitations related to the use of billings instead of GAAP revenue. First, billings include amounts that have not yet been recognized as revenue and are impacted by the term of security and support agreements. Second, we may calculate billings in a manner that is different from peer companies that report similar financial measures. Management accounts for these limitations by providing specific information regarding GAAP revenue and evaluating billings together with GAAP revenue.

[0001262039-23-000035:8k_2_02:71]
Free cash flow (non-GAAP). We define free cash flow as net cash provided by operating activities minus purchases of property and equipment and excluding any significant non-recurring items. We believe free cash flow to be a liquidity measure that provides useful information to management and investors about the amount of cash generated by the business that, after capital expenditures, can be used for strategic opportunities, including repurchasing outstanding common stock, investing in our business, making strategic acquisitions and strengthening the balance sheet. A limitation of using free cash flow rather than the GAAP measures of cash provided by or used in operating activities, investing activities, and financing activities is that free cash flow does not represent the total increase or decrease in the cash and cash equivalents balance for the period because it excludes cash flows from significant non-recurring items, investing activities other than capital expenditures and cash flows from financing activities. Management accounts for this limitation by providing information about our capital expenditures and other investing and financing activities on the face of the cash flow statement and under the caption “Management’s Discussion and Analysis of Financial Condition and Results of Operations—Liquidity and Capital Resources” in our most recent Quarterly Report on Form 10-Q and Annual Report on Form 10-K and by presenting cash flows from investing and financing activities in our reconciliation of free cash flow. In addition, it is important to note that other companies, including companies in our industry, may not use free cash flow, may calculate free cash flow in a different manner than we do or may use other financial measures to evaluate their performance, all of which could reduce the usefulness of free cash flow as a comparative measure.

[0001262039-23-000035:8k_2_02:72]
Non-GAAP operating income and operating margin. We define non-GAAP operating income as operating income plus stock-based compensation, amortization of acquired intangible assets, less gain on intellectual property matter and, when applicable, other significant non-recurring items in a given quarter. Non-GAAP operating margin is defined as non-GAAP operating income divided by GAAP revenue. We consider these non-GAAP financial measures to be useful metrics for management and investors because they exclude the items noted above so that our management and investors can compare our recurring core business operating results over multiple periods. There are a number of limitations related to the use of non-GAAP operating income instead of operating income calculated in accordance with GAAP. First, non-GAAP operating income excludes the items noted above. Second, the components of the costs that we

[0001262039-23-000035:8k_2_02:73]
exclude from our calculation of non-GAAP operating income may differ from the components that peer companies exclude when they report their non-GAAP results of operations. Management accounts for these limitations by providing specific information regarding the GAAP amounts excluded from non-GAAP operating income and evaluating non-GAAP operating income together with operating income calculated in accordance with GAAP.

[0001262039-23-000035:8k_2_02:74]
Non-GAAP net income and diluted net income per share attributable to Fortinet, Inc. We define non-GAAP net income as net income plus the items noted above under non-GAAP operating income and operating margin. In addition, we adjust non-GAAP net income and diluted net income per share for a tax adjustment required for an effective tax rate on a non-GAAP basis and adjustments attributable to non-controlling interests, which differs from the GAAP effective tax rate. We define non-GAAP diluted net income per share as non-GAAP net income divided by the non-GAAP diluted weighted-average shares outstanding. We consider these non-GAAP financial measures to be useful metrics for management and investors for the same reasons that we use non-GAAP operating income and non-GAAP operating margin. However, in order to provide a more complete picture of our recurring core business operating results, we include in non-GAAP net income and non-GAAP diluted net income per share, the tax adjustment required resulting in an effective tax rate on a non-GAAP basis, which often differs from the GAAP tax rate. We believe the non-GAAP effective tax rates we use are reasonable estimates of normalized tax rates for our current and prior fiscal years under our global operating structure. The same limitations described above regarding our use of non-GAAP operating income and non-GAAP operating margin apply to our use of non-GAAP net income and non-GAAP diluted net income per share. We account for these limitations by providing specific information regarding the GAAP amounts excluded from non-GAAP net income and non-GAAP diluted net income per share and evaluating non-GAAP net income and non-GAAP diluted net income per share together with net income and diluted net income per share calculated in accordance with GAAP.

[0001262039-23-000035:8k_2_02:75]
FORTINET, INC.

[0001262039-23-000035:8k_2_02:76]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001262039-23-000035:8k_2_02:77]
(Unaudited, in millions)

[0001262039-23-000035:8k_2_02:78]
|  | September 30,2023 |  | December 31,2022 |
| ASSETS |  |  |  |
| CURRENT ASSETS: |  |  |  |
| Cash and cash equivalents | $ | 2,186.8 |  |  | $ | 1,682.9 |  |
| Short-term investments | 962.2 |  |  | 502.6 |  |
| Marketable equity securities | 19.8 |  |  | 25.5 |  |
| Accounts receivable—net | 1,013.8 |  |  | 1,261.7 |  |
| Inventory | 467.5 |  |  | 264.6 |  |
| Prepaid expenses and other current assets | 102.6 |  |  | 73.1 |  |
| Total current assets | 4,752.7 |  |  | 3,810.4 |  |
| LONG-TERM INVESTMENTS | 1.5 |  |  | 45.5 |  |
| PROPERTY AND EQUIPMENT—NET | 1,038.0 |  |  | 898.5 |  |
| DEFERRED CONTRACT COSTS | 569.9 |  |  | 518.2 |  |
| DEFERRED TAX ASSETS | 788.5 |  |  | 569.4 |  |
| GOODWILL AND OTHER INTANGIBLE ASSETS—NET | 165.0 |  |  | 184.0 |  |
| OTHER ASSETS | 163.7 |  |  | 202.0 |  |
| TOTAL ASSETS | $ | 7,479.3 |  |  | $ | 6,228.0 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY (DEFICIT) |  |  |  |
| CURRENT LIABILITIES: |  |  |  |
| Accounts payable | $ | 253.9 |  |  | $ | 243.4 |  |
| Accrued liabilities | 317.2 |  |  | 248.7 |  |
| Accrued payroll and compensation | 210.5 |  |  | 219.4 |  |
| Income taxes payable | 220.1 |  |  | 17.6 |  |
| Deferred revenue | 2,647.3 |  |  | 2,349.3 |  |
| Total current liabilities | 3,649.0 |  |  | 3,078.4 |  |
| DEFERRED REVENUE | 2,638.0 |  |  | 2,291.0 |  |
| INCOME TAX LIABILITIES | 61.8 |  |  | 67.8 |  |
| LONG-TERM DEBT | 991.8 |  |  | 990.4 |  |
| OTHER LIABILITIES | 64.6 |  |  | 82.0 |  |
| Total liabilities | 7,405.2 |  |  | 6,509.6 |  |
| COMMITMENTS AND CONTINGENCIES |  |  |  |
| STOCKHOLDERS’ EQUITY (DEFICIT): |  |  |  |
| Common stock | 0.8 |  |  | 0.8 |  |
| Additional paid-in capital | 1,397.0 |  |  | 1,284.2 |  |
| Accumulated other comprehensive loss | (24.3) |  |  | (20.2) |  |
| Accumulated deficit | (1,299.4) |  |  | (1,546.4) |  |
| Total stockholders’ equity (deficit) | 74.1 |  |  | (281.6) |  |
| TOTAL LIABILITIES AND STOCKHOLDERS’ EQUITY (DEFICIT) | $ | 7,479.3 |  |  | $ | 6,228.0 |  |

[0001262039-23-000035:8k_2_02:79]
FORTINET, INC.

[0001262039-23-000035:8k_2_02:80]
CONDENSED CONSOLIDATED STATEMENTS OF INCOME

[0001262039-23-000035:8k_2_02:81]
(Unaudited, in millions, except per share amounts)

[0001262039-23-000035:8k_2_02:82]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30,2023 |  | September 30,2022 |  | September 30,2023 |  | September 30,2022 |
| REVENUE: |  |  |  |  |  |  |  |
| Product | $ | 465.9 |  |  | $ | 468.7 |  |  | $ | 1,439.2 |  |  | $ | 1,240.4 |  |
| Service | 868.7 |  |  | 680.8 |  |  | 2,450.5 |  |  | 1,894.0 |  |
| Total revenue | 1,334.6 |  |  | 1,149.5 |  |  | 3,889.7 |  |  | 3,134.4 |  |
| COST OF REVENUE: |  |  |  |  |  |  |  |
| Product | 198.3 |  |  | 185.2 |  |  | 566.4 |  |  | 501.4 |  |
| Service | 119.4 |  |  | 97.8 |  |  | 354.9 |  |  | 286.2 |  |
| Total cost of revenue | 317.7 |  |  | 283.0 |  |  | 921.3 |  |  | 787.6 |  |
| GROSS PROFIT: |  |  |  |  |  |  |  |
| Product | 267.6 |  |  | 283.5 |  |  | 872.8 |  |  | 739.0 |  |
| Service | 749.3 |  |  | 583.0 |  |  | 2,095.6 |  |  | 1,607.8 |  |
| Total gross profit | 1,016.9 |  |  | 866.5 |  |  | 2,968.4 |  |  | 2,346.8 |  |
| OPERATING EXPENSES: |  |  |  |  |  |  |  |
| Research and development | 156.9 |  |  | 134.3 |  |  | 461.3 |  |  | 383.5 |  |
| Sales and marketing | 504.4 |  |  | 427.1 |  |  | 1,498.6 |  |  | 1,230.2 |  |
| General and administrative | 53.5 |  |  | 40.7 |  |  | 156.2 |  |  | 124.7 |  |
| Gain on intellectual property matter | (1.1) |  |  | (1.1) |  |  | (3.4) |  |  | (3.4) |  |
| Total operating expenses | 713.7 |  |  | 601.0 |  |  | 2,112.7 |  |  | 1,735.0 |  |
| OPERATING INCOME | 303.2 |  |  | 265.5 |  |  | 855.7 |  |  | 611.8 |  |
| INTEREST INCOME | 37.0 |  |  | 4.6 |  |  | 89.2 |  |  | 8.3 |  |
| INTEREST EXPENSE | (5.4) |  |  | (4.5) |  |  | (15.6) |  |  | (13.5) |  |
| OTHER EXPENSE—NET | (7.0) |  |  | (0.9) |  |  | (11.2) |  |  | (19.3) |  |
| INCOME BEFORE INCOME TAXES AND LOSS FROM EQUITY METHOD INVESTMENT | 327.8 |  |  | 264.7 |  |  | 918.1 |  |  | 587.3 |  |
| PROVISION FOR (BENEFIT FROM) INCOME TAXES | (0.3) |  |  | 27.3 |  |  | 48.6 |  |  | 21.6 |  |
| LOSS FROM EQUITY METHOD INVESTMENT | (5.2) |  |  | (6.3) |  |  | (32.6) |  |  | (22.9) |  |
| NET INCOME INCLUDING NON-CONTROLLING INTERESTS | 322.9 |  |  | 231.1 |  |  | 836.9 |  |  | 542.8 |  |
| Less: NET LOSS ATTRIBUTABLE TO NON-CONTROLLING INTERESTS, NET OF TAX | — |  |  | (0.5) |  |  | — |  |  | (0.7) |  |
| NET INCOME ATTRIBUTABLE TO FORTINET, INC. | $ | 322.9 |  |  | $ | 231.6 |  |  | $ | 836.9 |  |  | $ | 543.5 |  |
| Net income per share attributable to Fortinet, Inc.: |  |  |  |  |  |  |  |
| Basic | $ | 0.41 |  |  | $ | 0.29 |  |  | $ | 1.07 |  |  | $ | 0.68 |  |
| Diluted | $ | 0.41 |  |  | $ | 0.29 |  |  | $ | 1.05 |  |  | $ | 0.67 |  |
| Weighted-average shares used to compute net income per share attributable to Fortinet, Inc.: |  |  |  |  |  |  |  |
| Basic | 781.2 |  |  | 786.2 |  |  | 783.1 |  |  | 795.0 |  |
| Diluted | 791.2 |  |  | 798.6 |  |  | 793.5 |  |  | 809.8 |  |

[0001262039-23-000035:8k_2_02:83]
FORTINET, INC.

[0001262039-23-000035:8k_2_02:84]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001262039-23-000035:8k_2_02:85]
(Unaudited, in millions)

[0001262039-23-000035:8k_2_02:86]
|  | Nine Months Ended |
|  | September 30,2023 |  | September 30,2022 |
| CASH FLOWS FROM OPERATING ACTIVITIES: |  |  |  |
| Net income including non-controlling interests | $ | 836.9 |  |  | $ | 542.8 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |
| Stock-based compensation | 185.6 |  |  | 162.6 |  |
| Amortization of deferred contract costs | 195.9 |  |  | 163.8 |  |
| Depreciation and amortization | 83.2 |  |  | 77.0 |  |
| Amortization of investment premiums (discounts) | (16.1) |  |  | 3.6 |  |
| Loss from equity method investment | 32.6 |  |  | 22.9 |  |
| Other | 13.7 |  |  | 21.2 |  |
| Changes in operating assets and liabilities, net of impact of business combinations: |  |  |  |
| Accounts receivable—net | 243.4 |  |  | (162.7) |  |
| Inventory | (231.0) |  |  | (59.7) |  |
| Prepaid expenses and other current assets | (29.3) |  |  | (7.6) |  |
| Deferred contract costs | (247.5) |  |  | (221.0) |  |
| Deferred tax assets | (221.7) |  |  | (172.0) |  |
| Other assets | 13.5 |  |  | (13.9) |  |
| Accounts payable | 10.4 |  |  | 78.6 |  |
| Accrued liabilities | 56.9 |  |  | 33.7 |  |
| Accrued payroll and compensation | (8.0) |  |  | (3.2) |  |
| Income taxes payable | 196.8 |  |  | (5.9) |  |
| Other liabilities | (17.7) |  |  | (0.5) |  |
| Deferred revenue | 646.2 |  |  | 742.8 |  |
| Net cash provided by operating activities | 1,743.8 |  |  | 1,202.5 |  |
| CASH FLOWS FROM INVESTING ACTIVITIES: |  |  |  |
| Purchases of investments | (1,327.6) |  |  | (389.1) |  |
| Sales of investments | 4.0 |  |  | 3.0 |  |
| Maturities of investments | 931.5 |  |  | 1,182.9 |  |
| Purchases of property and equipment | (177.2) |  |  | (250.3) |  |
| Purchase of investment in privately held company | (8.5) |  |  | — |  |
| Other | 0.1 |  |  | — |  |
| Net cash provided by (used in) investing activities | (577.7) |  |  | 546.5 |  |
| CASH FLOWS FROM FINANCING ACTIVITIES: |  |  |  |
| Repurchase and retirement of common stock | (604.3) |  |  | (1,991.2) |  |
| Proceeds from issuance of common stock | 36.0 |  |  | 21.7 |  |
| Taxes paid related to net share settlement of equity awards | (90.8) |  |  | (132.1) |  |
| Other | (1.2) |  |  | (1.3) |  |
| Net cash used in financing activities | (660.3) |  |  | (2,102.9) |  |
| EFFECT OF EXCHANGE RATE CHANGES ON CASH AND CASH EQUIVALENTS | (1.9) |  |  | (1.2) |  |
| NET INCREASE (DECREASE) IN CASH AND CASH EQUIVALENTS | 503.9 |  |  | (355.1) |  |
| CASH AND CASH EQUIVALENTS—Beginning of period | 1,682.9 |  |  | 1,319.1 |  |
| CASH AND CASH EQUIVALENTS—End of period | $ | 2,186.8 |  |  | $ | 964.0 |  |

[0001262039-23-000035:8k_2_02:87]
Reconciliations of non-GAAP results of operations measures to the nearest comparable GAAP measures

[0001262039-23-000035:8k_2_02:88]
(Unaudited, in millions, except per share amounts)

[0001262039-23-000035:8k_2_02:89]
Reconciliation of GAAP operating income to non-GAAP operating income, operating margin, net income attributable to Fortinet, Inc. and diluted net income per share attributable to Fortinet, Inc.

[0001262039-23-000035:8k_2_02:90]
|  | Three Months Ended |  |  |
|  | September 30,2023 |  | September 30,2022 |  |  |  |  |
| Reconciliation of non-GAAP operating income: |  |  |  |  |  |  |  |
| GAAP operating income | $ | 303.2 |  |  | $ | 265.5 |  |  |  |  |  |
| GAAP operating margin | 22.7 | % |  | 23.1 | % |  |  |  |  |
| Add back: |  |  |  |  |  |  |  |
| Stock‐based compensation | 64.9 |  |  | 55.3 |  |  |  |  |  |
| Amortization of acquired intangible assets | 4.4 |  |  | 5.2 |  |  |  |  |  |
| Gain on intellectual property matter | (1.1) |  |  | (1.1) |  |  |  |  |  |
| Non‐GAAP operating income | $ | 371.4 |  |  | $ | 324.9 |  |  |  |  |  |
| Non‐GAAP operating margin | 27.8 | % |  | 28.3 | % |  |  |  |  |
| Reconciliation of non-GAAP net income attributable to Fortinet, Inc.: |  |  |  |  |  |  |  |
| GAAP net income attributable to Fortinet, Inc. | $ | 322.9 |  |  | $ | 231.6 |  |  |  |  |  |
| Add back: |  |  |  |  |  |  |  |
| Stock‐based compensation | 64.9 |  |  | 55.3 |  |  |  |  |  |
| Amortization of acquired intangible assets | 4.4 |  |  | 5.2 |  |  |  |  |  |
| Gain on intellectual property matter | (1.1) |  |  | (1.1) |  |  |  |  |  |
| Tax adjustment (a) | (67.6) |  |  | (27.8) |  |  |  |  |  |
| Adjustments attributable non-controlling interests (b) | — |  |  | (0.5) |  |  |  |  |  |
| Non-GAAP net income attributable to Fortinet, Inc. | $ | 323.5 |  |  | $ | 262.7 |  |  |  |  |  |
| Non-GAAP net income per share attributable to Fortinet, Inc., diluted |  |  |  |  |  |  |  |
| Non-GAAP net income attributable to Fortinet, Inc. | $ | 323.5 |  |  | $ | 262.7 |  |  |  |  |  |
| Non-GAAP shares used in diluted net income per share attributable to Fortinet, Inc. calculations | 791.2 |  |  | 798.6 |  |  |  |  |  |
| Non-GAAP net income per share attributable to Fortinet, Inc., diluted | $ | 0.41 |  |  | $ | 0.33 |  |  |  |  |  |
| Reconciliation of non-GAAP net income per share attributable to Fortinet, Inc., diluted |  |  |  |  |  |  |  |
| GAAP net income per share attributable to Fortinet, Inc., diluted | $ | 0.41 |  |  | $ | 0.29 |  |  |  |  |  |
| Add back: |  |  |  |  |  |  |  |
| Non-GAAP adjustments to net income per share attributable to Fortinet, Inc. | — |  |  | 0.04 |  |  |  |  |  |
| Non-GAAP net income per share attributable to Fortinet, Inc., diluted | $ | 0.41 |  |  | $ | 0.33 |  |  |  |  |  |

[0001262039-23-000035:8k_2_02:91]
(a) Non-GAAP financial information is adjusted to an effective tax rate of 17% in the three months ended September 30, 2023 and 2022, respectively, on a non-GAAP basis, which differs from the GAAP effective tax rate.

[0001262039-23-000035:8k_2_02:92]
(b) Adjustments related to the non-GAAP results attributable to non-controlling interests, which were adjusted to an effective tax rate of 31% for the subsidiary of Alaxala Networks Corporation in the three months ended September 30, 2022.

[0001262039-23-000035:8k_2_02:93]
Reconciliation of net cash provided by operating activities to free cash flow

[0001262039-23-000035:8k_2_02:94]
|  | Three Months Ended |
|  | September 30,2023 |  | September 30,2022 |
| Net cash provided by operating activities | $ | 551.2 |  |  | $ | 483.0 |  |
| Less: Purchases of property and equipment | (70.1) |  |  | (87.8) |  |
| Free cash flow | $ | 481.1 |  |  | $ | 395.2 |  |
| Net cash provided by (used in) investing activities | $ | (111.2) |  |  | $ | 297.8 |  |
| Net cash used in financing activities | $ | (628.9) |  |  | $ | (526.6) |  |

[0001262039-23-000035:8k_2_02:95]
Reconciliation of total revenue to total billings

[0001262039-23-000035:8k_2_02:96]
|  | Three Months Ended |
|  | September 30,2023 |  | September 30,2022 |
| Total revenue | $ | 1,334.6 |  |  | $ | 1,149.5 |  |
| Add: Change in deferred revenue | 156.7 |  |  | 261.5 |  |
| Total billings | $ | 1,491.3 |  |  | $ | 1,411.0 |  |

[0001262039-23-000035:8k_2_02:97]
| Investor Contact: |  | Media Contact: |
| Peter Salkowski |  | Michelle Zimmermann |
| Fortinet, Inc. |  | Fortinet, Inc. |
| 408-331-4595 |  | 408-235-7700 |
| psalkowski@fortinet.com |  | pr@fortinet.com |
