# FTNT notes — 0001262039-20-000032


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001262039-20-000032:notes:1]
[same as prior period, unchanged from 0001262039-19-000033:notes:1]

[0001262039-20-000032:notes:2]
Basis of Presentation and Preparation—The unaudited condensed consolidated financial statements of Fortinet, Inc. and its wholly owned subsidiaries (collectively, “we,” “us” or “our”) have been prepared in accordance with generally accepted accounting principles in the United States (“GAAP”) for interim financial information, as well as the instructions to Form 10-Q pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (the “SEC”). Accordingly, they do not include all of the information and footnotes required by GAAP for complete financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the year ended December 31, 2019, contained in our Annual Report on Form 10-K filed with the SEC on February 26, 2020. In the opinion of management, all adjustments, which includes normal recurring adjustments, considered necessary for a fair presentation have been included. All intercompany balances, transactions and cash flows have been eliminated. The results of operations for the three months ended March 31, 2020 are not necessarily indicative of the results for the full year or for any future periods. The condensed consolidated balance sheet as of December 31, 2019 is derived from the audited consolidated financial statements for the year ended December 31, 2019. For 2020, the amounts previously reported as Income taxes payable are included in Accrued liabilities. Prior periods have been reclassified to conform with current period presentation.

[0001262039-20-000032:notes:3]
[same as prior period, unchanged from 0001262039-19-000033:notes:3]

[0001262039-20-000032:notes:4]
There have been no material changes to our significant accounting policies as of and for the three months ended March 31, 2020.

[0001262039-20-000032:notes:5]
Recently Adopted Accounting Standards

[0001262039-20-000032:notes:6]
[same as prior period, unchanged from 0001262039-19-000033:notes:21]

[0001262039-20-000032:notes:7]
In June 2016, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) 2016-13—Financial Instruments—Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments (“Topic 326”), which provides guidance on how an entity should measure credit losses on financial instruments. The standard replaces the existing incurred loss model with an expected credit loss model for financial assets measured at amortized cost, including trade receivables, and requires that credit losses on available-for-sale debt securities be presented as an allowance rather than as a write-down. The new approach to estimating credit losses (referred to as the current expected credit losses model) generally accelerates recognition of credit losses. We adopted Topic 326 on January 1, 2020 using the modified retrospective method. The adoption of this standard did not have a material impact on our condensed consolidated financial statements.

[0001262039-20-000032:notes:8]
[same as prior period, unchanged from 0001262039-19-000033:notes:17]

[0001262039-20-000032:notes:9]
In August 2018, the FASB issued ASU 2018-15—Intangibles—Goodwill and Other—Internal-Use Software (Subtopic 350-40): Customer’s Accounting for Implementation Costs Incurred in a Cloud Computing Arrangement That Is a Service Contract, which requires a customer in a cloud computing arrangement that is a service contract to follow the internal-use software guidance in Accounting Standards Codification (“ASC”) Topic 350, Intangibles—Goodwill and Other, to determine which implementation costs to capitalize as assets or expense as incurred. We adopted ASU 2018-15 on January 1, 2020. The adoption of this standard did not have a material impact on our condensed consolidated financial statements.

[0001262039-20-000032:notes:10]
[same as prior period, unchanged from 0001262039-19-000033:notes:19]

[0001262039-20-000032:notes:11]
In August 2018, the FASB issued ASU 2018-13—Fair Value Measurement (Topic 820): Disclosure Framework—Changes to the Disclosure Requirements for Fair Value Measurement, which eliminates, adds and modifies certain disclosure requirements for fair value measurements in ASC 820, Fair Value Measurement, as part of its disclosure framework project. We adopted ASU 2018-13 on January 1, 2020. The adoption of this standard did not have a material impact on our disclosures.

[0001262039-20-000032:notes:12]
[same as prior period, unchanged from 0001262039-19-000033:notes:16]

[0001262039-20-000032:notes:13]
Income Taxes

[0001262039-20-000032:notes:14]
In December 2019, the FASB issued ASU 2019-12—Income Taxes (Topic 740): Simplifying the Accounting for Income Taxes. The amendments in ASU 2019-12 simplify the accounting for income taxes by removing certain exceptions to the general principles in Topic 740. The amendments also improve consistent application and simplification of GAAP for other areas of Topic 740 by clarifying and amending existing guidance. ASU 2019-12 is effective for us beginning on January 1, 2021. Early adoption of the amendments is permitted. We are currently evaluating the impact of ASU 2019-12 on our condensed consolidated financial statements.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001262039-20-000032:notes:15]
[same as prior period, unchanged from 0001262039-19-000033:notes:23]

[0001262039-20-000032:notes:16]
[same as prior period, unchanged from 0001262039-19-000033:notes:24]

[0001262039-20-000032:notes:17]
[same as prior period, unchanged from 0001262039-19-000033:notes:25]

[0001262039-20-000032:notes:18]
[same as prior period, unchanged from 0001262039-19-000033:notes:26]

[0001262039-20-000032:notes:19]
|  | Three Months Ended |
|  | March 31, 2020 |  | March 31, 2019 |
| Product | $ | 192.3 |  |  | $ | 162.7 |  |
| Service: |  |  |  |
| Security subscription | 211.4 |  |  | 169.6 |  |
| Technical support and other | 173.2 |  |  | 140.3 |  |
| Total service revenue | 384.6 |  |  | 309.9 |  |
| Total revenue | $ | 576.9 |  |  | $ | 472.6 |  |

[0001262039-20-000032:notes:20]
[same as prior period, unchanged from 0001262039-19-000033:notes:28]

[0001262039-20-000032:notes:21]
During the three months ended March 31, 2020 and March 31, 2019, we recognized $348.9 million and $288.6 million in service revenue that was included in the deferred revenue balance as of December 31, 2019 and December 31, 2018, respectively.

[0001262039-20-000032:notes:22]
[same as prior period, unchanged from 0001262039-19-000033:notes:30]

[0001262039-20-000032:notes:23]
As of March 31, 2020, the aggregate amount of the transaction price allocated to remaining performance obligations was $2.23 billion, which was substantially comprised of deferred security subscription and technical support services revenue. We expect to recognize approximately $1.23 billion as revenue over the next 12 months and the remainder thereafter.

[0001262039-20-000032:notes:24]
[same as prior period, unchanged from 0001262039-19-000033:notes:32]

[0001262039-20-000032:notes:25]
Trade accounts receivable are recorded at the invoiced amount. On January 1, 2020, we adopted Topic 326, which provides guidance on how to measure credit losses on financial instruments, including accounts receivable. Prior to our adoption of Topic 326, our accounts receivable balance was reduced by an allowance for doubtful accounts that we determined based on our assessment of the collectability of customer accounts. Under Topic 326, our accounts receivable balance is reduced by an allowance for credit losses. We measure expected credit losses of accounts receivable on a collective (pool) basis, aggregating accounts receivable that are either current or no more than 60 days past due, and aggregating accounts receivable that are more than 60 days past due. We apply a credit-loss percentage to each of the pools that is based on our historical credit losses. We review whether each of our significant accounts receivable that is more than 60 days past due continues to exhibit

[0001262039-20-000032:notes:26]
similar risk characteristics with the other accounts receivable in the pool. If we determine that it does not, we evaluate it for expected credit losses on an individual basis.

[0001262039-20-000032:notes:27]
The COVID-19 pandemic and the recent economic downturn prompted us to perform additional credit reviews of our existing customers, including obtaining recent credit reports and reviewing their latest available statements of financial position. After performing our additional reviews, we determined that, while there may be delays in our collections, the risk of credit loss on our trade accounts receivable as of March 31, 2020 was expected to be consistent with prior periods and that our methodology for estimating credit losses was appropriate.

[0001262039-20-000032:notes:28]
The allowance for credit losses was $1.1 million as of March 31, 2020, and the allowance for doubtful accounts was $1.2 million as of December 31, 2019. Provisions, write-offs and recoveries were not material during the three months ended March 31, 2020.

[0001262039-20-000032:notes:29]
[same as prior period, unchanged from 0001262039-19-000033:notes:34]

[0001262039-20-000032:notes:30]
Sales commissions earned by our sales force are considered incremental and recoverable costs of obtaining a contract with a customer. The amortization of deferred contract costs is included in sales and marketing expense in our condensed consolidated statements of income. Amortization of deferred contract costs during the three months ended March 31, 2020 and March 31, 2019 were $31.3 million and $25.1 million, respectively.


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0001262039-20-000032:notes:31]
[same as prior period, unchanged from 0001262039-19-000033:notes:36]

[0001262039-20-000032:notes:32]
[same as prior period, unchanged from 0001262039-19-000033:notes:37]

[0001262039-20-000032:notes:33]
|  | March 31, 2020 |
|  | AmortizedCost |  | UnrealizedGains |  | UnrealizedLosses |  | FairValue |
| Corporate debt securities | $ | 616.3 |  |  | $ | 0.3 |  |  | $ | (4.2 | ) |  | $ | 612.4 |  |
| Commercial paper | 150.6 |  |  | 0.1 |  |  | (0.1 | ) |  | 150.6 |  |
| U.S. government securities | 96.6 |  |  | 0.5 |  |  | — |  |  | 97.1 |  |
| Certificates of deposit and term deposits (1) | 87.7 |  |  | 0.1 |  |  | (0.7 | ) |  | 87.1 |  |
| Total available-for-sale securities | $ | 951.2 |  |  | $ | 1.0 |  |  | $ | (5.0 | ) |  | $ | 947.2 |  |

[0001262039-20-000032:notes:34]
|  | December 31, 2019 |
|  | AmortizedCost |  | UnrealizedGains |  | UnrealizedLosses |  | FairValue |
| Corporate debt securities | $ | 576.1 |  |  | $ | 1.0 |  |  | $ | (0.1 | ) |  | $ | 577.0 |  |
| Commercial paper | 148.7 |  |  | 0.1 |  |  | — |  |  | 148.8 |  |
| U.S. government securities | 195.0 |  |  | 0.2 |  |  | — |  |  | 195.2 |  |
| Certificates of deposit and term deposits (1) | 66.4 |  |  | — |  |  | — |  |  | 66.4 |  |
| Total available-for-sale securities | $ | 986.2 |  |  | $ | 1.3 |  |  | $ | (0.1 | ) |  | $ | 987.4 |  |
| (1) The majority of our certificates of deposit and term deposits are foreign deposits. |

[0001262039-20-000032:notes:35]
[same as prior period, unchanged from 0001262039-19-000033:notes:39]

[0001262039-20-000032:notes:36]
|  | March 31, 2020 |
|  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
|  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |
| Corporate debt securities | $ | 475.2 |  |  | $ | (4.2 | ) |  | $ | 7.1 |  |  | $ | — |  |  | $ | 482.3 |  |  | $ | (4.2 | ) |
| Commercial paper | 45.5 |  |  | (0.1 | ) |  | — |  |  | — |  |  | 45.5 |  |  | (0.1 | ) |
| Certificates of deposit and term deposits | 49.1 |  |  | (0.7 | ) |  | — |  |  | — |  |  | 49.1 |  |  | (0.7 | ) |
| Total available-for-sale securities | $ | 569.8 |  |  | $ | (5.0 | ) |  | $ | 7.1 |  |  | $ | — |  |  | $ | 576.9 |  |  | $ | (5.0 | ) |

[0001262039-20-000032:notes:37]
|  | December 31, 2019 |
|  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
|  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |
| Corporate debt securities | $ | 117.3 |  |  | $ | (0.1 | ) |  | $ | 16.1 |  |  | $ | — |  |  | $ | 133.4 |  |  | $ | (0.1 | ) |
| Commercial paper | 26.0 |  |  | — |  |  | — |  |  | — |  |  | 26.0 |  |  | — |  |
| U.S. government securities | 47.1 |  |  | — |  |  | — |  |  | — |  |  | 47.1 |  |  | — |  |
| Certificates of deposit and term deposits | 13.0 |  |  | — |  |  | — |  |  | — |  |  | 13.0 |  |  | — |  |
| Total available-for-sale securities | $ | 203.4 |  |  | $ | (0.1 | ) |  | $ | 16.1 |  |  | $ | — |  |  | $ | 219.5 |  |  | $ | (0.1 | ) |

[0001262039-20-000032:notes:38]
[same as prior period, unchanged from 0001262039-19-000033:notes:42]

[0001262039-20-000032:notes:39]
|  | March 31, 2020 |  | December 31, 2019 |
| Due within one year | $ | 775.2 |  |  | $ | 843.1 |  |
| Due within one to three years | 172.0 |  |  | 144.3 |  |
| Total | $ | 947.2 |  |  | $ | 987.4 |  |

[0001262039-20-000032:notes:40]
Available-for-sale securities are reported at fair value, with unrealized gains and losses and the related tax impact included as a separate component of stockholders’ equity and in comprehensive income. Accrued interest of $4.7 million as of March 31, 2020 is excluded from both the fair value and the amortized cost of our available-for-sale securities and is recorded in Prepaid expenses and other current assets in our condensed consolidated balance sheet. We have elected to not record an allowance for credit losses for accrued interest for available-for-sale securities and will reverse the accrued interest against interest income in the period in which we determine the accrued interest to be uncollectible.

[0001262039-20-000032:notes:41]
Prior to 2020, we followed the guidance in ASC 320 Investments—Debt and Equity Securities in determining whether unrealized losses were other than temporary. We adopted Topic 326 on January 1, 2020, and now consider whether unrealized losses have resulted from a credit loss or other factors. The unrealized losses on our available-for-sale securities as of March 31, 2020 and as of December 31, 2019 were caused by fluctuations in market value and interest rates as a result of the economic environment. We concluded that an allowance for credit losses was unnecessary as of March 31, 2020 and that the impairments as of December 31, 2019 were not other than temporary because (i) the decline in market value was attributable to changes in market conditions and not credit quality, and (ii) we concluded that neither do we intend to sell nor is it more likely than not that we will be required to sell these investments prior to recovery of their amortized cost basis.

[0001262039-20-000032:notes:42]
Realized losses on available-for-sale securities were insignificant in the periods presented and are included in Other expense—net in our consolidated statements of income. We use the specific identification method to determine the cost basis of investments sold.

[0001262039-20-000032:notes:43]
[same as prior period, unchanged from 0001262039-19-000033:notes:46]

[0001262039-20-000032:notes:44]
[same as prior period, unchanged from 0001262039-19-000033:notes:47]

[0001262039-20-000032:notes:45]
[same as prior period, unchanged from 0001262039-19-000033:notes:48]

[0001262039-20-000032:notes:46]
[same as prior period, unchanged from 0001262039-19-000033:notes:49]

[0001262039-20-000032:notes:47]
We measure the fair value of money market funds and certain U.S. government securities using quoted prices in active markets for identical assets. The fair value of all other financial instruments was based on quoted prices for similar assets in active markets, or model-driven valuations using significant inputs derived from or corroborated by observable market data.

[0001262039-20-000032:notes:48]
[same as prior period, unchanged from 0001262039-19-000033:notes:51]

[0001262039-20-000032:notes:49]
[same as prior period, unchanged from 0001262039-19-000033:notes:52]

[0001262039-20-000032:notes:50]
[same as prior period, unchanged from 0001262039-19-000033:notes:53]

[0001262039-20-000032:notes:51]
[same as prior period, unchanged from 0001262039-19-000033:notes:54]

[0001262039-20-000032:notes:52]
The following tables present the fair value of our financial assets measured at fair value on a recurring basis as of March 31, 2020 and December 31, 2019 (in millions):

[0001262039-20-000032:notes:53]
|  | March 31, 2020 |  | December 31, 2019 |
|  | AggregateFairValue |  | QuotedPrices inActiveMarkets ForIdenticalAssets |  | SignificantOtherObservableRemainingInputs |  | SignificantOtherUnobservableRemainingInputs |  | AggregateFairValue |  | QuotedPrices inActiveMarkets ForIdenticalAssets |  | SignificantOtherObservableRemainingInputs |  | SignificantOtherUnobservableRemainingInputs |
|  |  |  | (Level 1) |  | (Level 2) |  | (Level 3) |  |  |  | (Level 1) |  | (Level 2) |  | (Level 3) |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate debt securities | $ | 613.4 |  |  | $ | — |  |  | $ | 613.4 |  |  | $ | — |  |  | $ | 577.0 |  |  | $ | — |  |  | $ | 577.0 |  |  | $ | — |  |
| Commercial paper | 164.6 |  |  | — |  |  | 164.6 |  |  | — |  |  | 165.8 |  |  | — |  |  | 165.8 |  |  | — |  |
| Certificates of deposit and term deposits | 87.1 |  |  | — |  |  | 87.1 |  |  | — |  |  | 66.4 |  |  | — |  |  | 66.4 |  |  | — |  |
| U.S. government securities | 97.1 |  |  | 97.1 |  |  | — |  |  | — |  |  | 195.2 |  |  | 195.2 |  |  | — |  |  | — |  |
| Money market funds | 163.7 |  |  | 163.7 |  |  | — |  |  | — |  |  | 15.0 |  |  | 15.0 |  |  | — |  |  | — |  |
| Total | $ | 1,125.9 |  |  | $ | 260.8 |  |  | $ | 865.1 |  |  | $ | — |  |  | $ | 1,019.4 |  |  | $ | 210.2 |  |  | $ | 809.2 |  |  | $ | — |  |
| Reported as: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents | $ | 178.7 |  |  |  |  |  |  |  |  | $ | 32.0 |  |  |  |  |  |  |  |
| Short-term investments | 775.2 |  |  |  |  |  |  |  |  | 843.1 |  |  |  |  |  |  |  |
| Long-term investments | 172.0 |  |  |  |  |  |  |  |  | 144.3 |  |  |  |  |  |  |  |
| Total | $ | 1,125.9 |  |  |  |  |  |  |  |  | $ | 1,019.4 |  |  |  |  |  |  |  |

[0001262039-20-000032:notes:54]
There were no transfers between Level 1 and Level 2 of the fair value hierarchy during the three months ended March 31, 2020 and year ended December 31, 2019.


## us-gaap:InventoryDisclosureTextBlock

[0001262039-20-000032:notes:55]
[same as prior period, unchanged from 0001262039-19-000033:notes:58]

[0001262039-20-000032:notes:56]
[same as prior period, unchanged from 0001262039-19-000033:notes:59]

[0001262039-20-000032:notes:57]
|  | March 31, 2020 |  | December 31, 2019 |
| Raw materials | $ | 12.5 |  |  | $ | 9.7 |  |
| Finished goods | 92.5 |  |  | 108.2 |  |
| Inventory | $ | 105.0 |  |  | $ | 117.9 |  |


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001262039-20-000032:notes:58]
[same as prior period, unchanged from 0001262039-19-000033:notes:61]

[0001262039-20-000032:notes:59]
[same as prior period, unchanged from 0001262039-19-000033:notes:62]

[0001262039-20-000032:notes:60]
|  | March 31, 2020 |  | December 31, 2019 |
| Land | $ | 93.3 |  |  | $ | 93.3 |  |
| Building and building improvements | 148.0 |  |  | 147.4 |  |
| Computer equipment and software | 121.7 |  |  | 116.7 |  |
| Leasehold improvements | 26.8 |  |  | 25.5 |  |
| Evaluation units | 22.4 |  |  | 19.9 |  |
| Furniture and fixtures | 18.2 |  |  | 17.3 |  |
| Construction-in-progress | 90.7 |  |  | 61.2 |  |
| Total property and equipment | 521.1 |  |  | 481.3 |  |
| Less: accumulated depreciation | (146.9 | ) |  | (137.0 | ) |
| Property and equipment—net | $ | 374.2 |  |  | $ | 344.3 |  |

[0001262039-20-000032:notes:61]
Depreciation expense was $13.6 million and $12.7 million during the three months ended March 31, 2020 and March 31, 2019, respectively.


## us-gaap:InvestmentTextBlock

[0001262039-20-000032:notes:62]
[same as prior period, unchanged from 0001262039-19-000033:notes:65]

[0001262039-20-000032:notes:63]
Our investments in the equity securities of privately held companies totaled $1.0 million and $5.3 million as of March 31, 2020 and December 31, 2019, respectively. These investments are accounted for at cost, adjusted for changes in observable prices minus impairment. We own less than 20% of the voting securities in each of these investments and do not have the ability to exercise significant influence over operating and financial policies of the respective entities. These investments are recorded as Other assets in our condensed consolidated balance sheets and would be measured at fair value if indicators of an increase in value or impairment existed. During the three months ended March 31, 2020, we determined that one investment was impaired. As a result, we recognized and included a non-cash impairment charge of $4.3 million in Other expense—net in our condensed consolidated statements of income. As of March 31, 2020, no other events have occurred that would affect the carrying value of these investments.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001262039-20-000032:notes:64]
[same as prior period, unchanged from 0001262039-19-000033:notes:77]

[0001262039-20-000032:notes:65]
[same as prior period, unchanged from 0001262039-19-000033:notes:78]

[0001262039-20-000032:notes:66]
As of March 31, 2020 and December 31, 2019, we had goodwill of $67.2 million. There were no impairments to goodwill during the three months ended March 31, 2020 or during prior periods.

[0001262039-20-000032:notes:67]
[same as prior period, unchanged from 0001262039-19-000033:notes:80]

[0001262039-20-000032:notes:68]
The following tables present other intangible assets—net as of March 31, 2020 and December 31, 2019 (in millions, except years):

[0001262039-20-000032:notes:69]
|  | March 31, 2020 |
|  | Weighted-Average Useful Life (in Years) |  | Gross |  | Accumulated Amortization |  | Net |
| Other intangible assets—net: |  |  |  |  |  |  |  |
| Finite-lived intangible assets: |  |  |  |  |  |  |  |
| Developed technologies | 4.0 |  | $ | 48.8 |  |  | $ | 25.8 |  |  | $ | 23.0 |  |
| Customer relationships | 4.1 |  | 21.6 |  |  | 17.5 |  |  | 4.1 |  |
| Total other intangible assets—net |  |  | $ | 70.4 |  |  | $ | 43.3 |  |  | $ | 27.1 |  |

[0001262039-20-000032:notes:70]
|  | December 31, 2019 |
|  | Weighted-Average Useful Life (in Years) |  | Gross |  | Accumulated Amortization |  | Net |
| Other intangible assets—net: |  |  |  |  |  |  |  |
| Finite-lived intangible assets: |  |  |  |  |  |  |  |
| Developed technologies | 4.0 |  | $ | 50.2 |  |  | $ | 24.6 |  |  | $ | 25.6 |  |
| Customer relationships | 4.1 |  | 21.6 |  |  | 16.1 |  |  | 5.5 |  |
| Total other intangible assets—net |  |  | $ | 71.8 |  |  | $ | 40.7 |  |  | $ | 31.1 |  |

[0001262039-20-000032:notes:71]
Amortization expense was $4.0 million and $3.0 million during the three months ended March 31, 2020 and March 31, 2019, respectively.

[0001262039-20-000032:notes:72]
[same as prior period, unchanged from 0001262039-19-000033:notes:85]

[0001262039-20-000032:notes:73]
|  | Amount |
| Years: |  |
| 2020 (the remainder of 2020) | $ | 8.7 |  |
| 2021 | 8.3 |  |
| 2022 | 6.4 |  |
| 2023 | 3.7 |  |
| Total | $ | 27.1 |  |


## us-gaap:EarningsPerShareTextBlock

[0001262039-20-000032:notes:74]
[same as prior period, unchanged from 0001262039-19-000033:notes:87]

[0001262039-20-000032:notes:75]
Basic net income per share is computed by dividing net income by the weighted-average number of shares of common stock outstanding during the period. Diluted net income per share is computed by dividing net income by the weighted-average number of shares of common stock outstanding during the period, plus the dilutive effects of restricted stock units (“RSUs”) and stock options. Dilutive shares of common stock are determined by applying the treasury stock method.

[0001262039-20-000032:notes:76]
[same as prior period, unchanged from 0001262039-19-000033:notes:89]

[0001262039-20-000032:notes:77]
|  | Three Months Ended |
|  | March 31, 2020 |  | March 31, 2019 |
| Numerator: |  |  |  |
| Net income | $ | 104.0 |  |  | $ | 58.8 |  |
| Denominator: |  |  |  |
| Basic shares: |  |  |  |
| Weighted-average common stock outstanding-basic | 170.6 |  |  | 170.2 |  |
| Diluted shares: |  |  |  |
| Weighted-average common stock outstanding-basic | 170.6 |  |  | 170.2 |  |
| Effect of potentially dilutive securities: |  |  |  |
| RSUs | 2.4 |  |  | 3.3 |  |
| Stock options | 1.2 |  |  | 1.3 |  |
| Weighted-average shares used to compute diluted net income per share | 174.2 |  |  | 174.8 |  |
| Net income per share: |  |  |  |
| Basic | $ | 0.61 |  |  | $ | 0.35 |  |
| Diluted | $ | 0.60 |  |  | $ | 0.34 |  |

[0001262039-20-000032:notes:78]
[same as prior period, unchanged from 0001262039-19-000033:notes:91]

[0001262039-20-000032:notes:79]
|  | Three Months Ended |
|  | March 31, 2020 |  | March 31, 2019 |
| RSUs | 0.6 |  |  | 0.7 |  |
| Stock options | 0.3 |  |  | 0.3 |  |
| Total | 0.9 |  |  | 1.0 |  |


## us-gaap:LesseeFinanceLeasesTextBlock

[0001262039-20-000032:notes:80]
LEASES

[0001262039-20-000032:notes:81]
We have operating leases for offices, research and development facilities and data centers. Our leases have remaining terms that range from less than one year to approximately seven years, some of which include one or more options to renew, with renewal terms of up to five years. We do not include renewal options in our lease terms for calculating our lease liability, as the renewal options allow us to maintain operational flexibility and we are not reasonably certain we will exercise these renewal options at the time of the lease commencement.

[0001262039-20-000032:notes:82]
During the year ended December 31, 2019, we entered into a finance lease with $3.6 million lease liabilities arising from obtaining right-of-use assets with a lease term of approximately two years. Our remaining finance leases were not material to our condensed consolidated financial statements. The related assumptions and further disclosures for finance leases are not material.

[0001262039-20-000032:notes:83]
The components of lease expense were as follows (in millions):

[0001262039-20-000032:notes:84]
|  | Three Months Ended |  | Three Months Ended |
|  | March 31, 2020 |  | March 31, 2019 |
| Operating lease expense | $ | 4.3 |  |  | $ | 3.6 |  |
| Variable lease expense (1) | 0.6 |  |  | 0.6 |  |
| Short-term lease expense | 0.9 |  |  | 0.7 |  |
| Total lease expense | $ | 5.8 |  |  | $ | 4.9 |  |

[0001262039-20-000032:notes:85]
(1) Variable lease expense for the three months ended March 31, 2020 and March 31, 2019 predominantly included common area maintenance charges and parking expense.

[0001262039-20-000032:notes:86]
Supplemental balance sheet information related to our operating leases was as follows (in millions, except lease term and discount rate):

[0001262039-20-000032:notes:87]
|  | Classification | March 31, 2020 |  | December 31, 2019 |
| Operating lease ROU assets - non-current | Other assets | $ | 42.7 |  |  | $ | 44.3 |  |
| Operating lease liabilities - current | Accrued liabilities | $ | 14.8 |  |  | $ | 15.5 |  |
| Operating lease liabilities - non-current | Other liabilities | 28.3 |  |  | 30.6 |  |
| Total operating lease liabilities |  | $ | 43.1 |  |  | $ | 46.1 |  |
| Weighted average remaining lease term in years - operating leases |  | 3.6 |  |  | 3.7 |  |
| Weighted average discount rate - operating leases |  | 2.8 | % |  | 2.8 | % |

[0001262039-20-000032:notes:88]
Supplemental cash flow information related to leases was as follows (in millions):

[0001262039-20-000032:notes:89]
|  | Three Months Ended |  | Three Months Ended |
|  | March 31, 2020 |  | March 31, 2019 |
| Cash paid for amounts included in the measurement of lease liabilities |  |  |  |
| Operating cash flows used for operating leases | $ | 4.6 |  |  | $ | 4.6 |  |
| Lease liabilities arising from obtaining right-of-use assets |  |  |  |
| Operating leases | $ | 2.4 |  |  | $ | 3.5 |  |

[0001262039-20-000032:notes:90]
Maturities of operating lease liabilities as of March 31, 2020 were as follows (in millions):

[0001262039-20-000032:notes:91]
| Year ending December 31, | Amount |
| 2020 (the remainder of 2020) | $ | 11.9 |  |
| 2021 | 13.6 |  |
| 2022 | 8.7 |  |
| 2023 | 5.4 |  |
| 2024 | 3.9 |  |
| Thereafter | 1.8 |  |
| Total lease payments | 45.3 |  |
| Less imputed interest | (2.2 | ) |
| Total | $ | 43.1 |  |

[0001262039-20-000032:notes:92]
As of March 31, 2020, we had additional minimum lease payments of $5.1 million relating to operating leases that had been signed but had not yet commenced and therefore were excluded from the table above. These leases will commence during 2020 and will have lease terms of approximately five to seven years.


## ftnt:MutualCovenantNottoSueAgreementDisclosureTextBlock

[0001262039-20-000032:notes:93]
MUTUAL COVENANT-NOT-TO-SUE AND RELEASE AGREEMENT

[0001262039-20-000032:notes:94]
In January 2020, we entered into an agreement with a competitor in the network security industry whereby, in February 2020, the competitor party paid us a lump sum of $50.0 million for a seven-year mutual covenant-not-to-sue for patent claims. Pursuant to this agreement, at the end of this first seven-year period, either party may extend the agreement for an additional seven-year mutual covenant-not-to-sue in return for this competitor paying us an additional $50.0 million. This agreement arose after expiration of previous agreements between the parties whereby the competitor had paid us sums for a limited term license to certain of our intellectual property (“IP”) and a limited term mutual covenant-not-to-sue.

[0001262039-20-000032:notes:95]
We concluded that the agreement was a 14-year contract with a total transaction price of $100.0 million, and that it contained two material distinct performance obligations: (1) the right to use our existing patents, and (2) the right to use any patents that we develop over the term of the contract. We allocated $36.0 million to the functional patents, which was recognized upon commencement of the contract; the remaining $64.0 million, representing the right to utilize future patents, will be recognized over the contract term. We further concluded that our existing patents represent functional IP that should be recognized upon granting our competitor access. We also concluded that the right to receive additional functional IP that we will develop in the future represents a stand ready obligation. Therefore, the transaction price allocated to this obligation is recognized ratably over the 14-year contract term. We estimated the stand-alone selling price of each distinct performance obligation and allocated the $100.0 million transaction price.

[0001262039-20-000032:notes:96]
During the three months ended March 31, 2020, we recorded $36.8 million in Gain on IP matter in our condensed consolidated statement of income, consisting of the $36.0 million allocated to the functional patents and $0.8 million of amortization of the deferred component. We recorded $13.2 million in Accrued liabilities and Other liabilities in our condensed consolidated balance sheet as of March 31, 2020.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001262039-20-000032:notes:97]
COMMITMENTS AND CONTINGENCIES

[0001262039-20-000032:notes:98]
The following table summarizes our inventory purchase commitments as of March 31, 2020 (in millions):

[0001262039-20-000032:notes:99]
|  | Total |  | 2020 |  | 2021 |  | 2022 |  | 2023 |  | 2024 |  | Thereafter |
| Inventory purchase commitments | $ | 247.2 |  |  | $ | 247.2 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |

[0001262039-20-000032:notes:100]
Inventory Purchase Commitments—Our independent contract manufacturers procure components and build our products based on our forecasts. These forecasts are based on estimates of future demand for our products, which are in turn based on historical trends and an analysis from our sales and marketing organizations, adjusted for overall market conditions. In

[0001262039-20-000032:notes:101]
order to reduce manufacturing lead times and plan for adequate component supply, we may issue purchase orders to some of our independent contract manufacturers, which may not be cancelable. As of March 31, 2020, we had $247.2 million of open purchase orders with our independent contract manufacturers that may not be cancelable.

[0001262039-20-000032:notes:102]
Other Contractual Commitments and Open Purchase Orders—In addition to commitments with contract manufacturers, we have open purchase orders and contractual obligations in the ordinary course of business for which we have not received goods or services. As of March 31, 2020, we had $10.9 million in other contractual commitments having a remaining term in excess of one year that may not be cancelable.

[0001262039-20-000032:notes:103]
Litigation—We are involved in disputes, litigation, and other legal actions. For lawsuits where we are the defendant, we are in the process of defending these litigation matters, and while there can be no assurances and the outcome of certain of these matters is currently not determinable and not predictable, we currently are unaware of any existing claims or proceedings that we believe are likely to have a material adverse effect on our financial position. There are many uncertainties associated with any litigation and these actions or other third-party claims against us may cause us to incur costly litigation fees, costs and substantial settlement charges, and possibly subject us to damages and other penalties. In addition, the resolution of any IP litigation may require us to make royalty payments, which could adversely affect our gross margins in future periods. If any of those events were to occur, our business, financial condition, results of operations, and cash flows could be adversely affected. Litigation is unpredictable and the actual liability in any such matters may be materially different from our current estimates, which could result in the need to adjust any accrued liability and record additional expenses. We accrue for contingencies when we believe that a loss is probable and that we can reasonably estimate the amount of any such loss.

[0001262039-20-000032:notes:104]
Indemnification and Other Matters—Under the indemnification provisions of our standard sales contracts, we agree to defend our customers against third-party claims asserting various allegations such as product defects and infringement of certain IP rights, which may include patents, copyrights, trademarks or trade secrets, and to pay judgments entered on such claims. In some contracts, our exposure under these indemnification provisions is limited by the terms of the contracts to certain defined limits, such as the total amount paid by our customer under the agreement. However, certain agreements include covenants, penalties and indemnification provisions including and beyond indemnification for third-party claims of IP infringement, that could potentially expose us to losses in excess of the amount received under the agreement, and in some instances to potential liability that is not contractually limited. To date, although from time to time there are indemnification claims asserted against us and currently there are pending indemnification claims, there have been no material awards under such indemnification provisions.

[0001262039-20-000032:notes:105]
Periodically, we, like other security companies and companies in other industries, may experience cybersecurity threats, malicious activity directed against our information technology infrastructure and unauthorized attempts to gain access to our and our customers’ sensitive information and systems.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001262039-20-000032:notes:106]
[same as prior period, unchanged from 0001262039-19-000033:notes:117]

[0001262039-20-000032:notes:107]
[same as prior period, unchanged from 0001262039-19-000033:notes:118]

[0001262039-20-000032:notes:108]
We maintain the Amended and Restated Fortinet, Inc. 2009 Equity Incentive Plan (the “Amended Plan”) pursuant to which we have granted RSUs and stock options. We also previously had an Employee Stock Purchase Plan (“ESPP”) for eligible employees, which was terminated in February 2019. As of March 31, 2020, there was a total of 12.1 million shares of common stock available for grant under the Amended Plan.

[0001262039-20-000032:notes:109]
[same as prior period, unchanged from 0001262039-19-000033:notes:122]

[0001262039-20-000032:notes:110]
[same as prior period, unchanged from 0001262039-19-000033:notes:123]

[0001262039-20-000032:notes:111]
|  | Restricted Stock Units Outstanding |
|  | Number of Shares |  | Weighted-Average Grant Date Fair Value per Share |
| Balance—December 31, 2019 | 6.1 |  |  | $ | 64.56 |  |
| Granted | 1.3 |  |  | 114.33 |  |
| Forfeited | (0.1 | ) |  | 68.19 |  |
| Vested | (1.0 | ) |  | 58.17 |  |
| Balance—March 31, 2020 | 6.3 |  |  | $ | 75.96 |  |

[0001262039-20-000032:notes:112]
As of March 31, 2020, total compensation expense related to unvested RSUs granted to employees and non-employees under the 2009 Plan, but not yet recognized, was $440.8 million. This expense is expected to be amortized on a straight-line basis over a weighted-average vesting period of 2.9 years.

[0001262039-20-000032:notes:113]
RSUs settle into shares of common stock upon vesting. Upon the vesting of the RSUs, we net-settle the RSUs and withhold a portion of the shares to satisfy minimum statutory employee withholding tax requirements. Total payment of the employees’ tax obligations to the tax authorities is reflected as a financing activity within the condensed consolidated statements of cash flows.

[0001262039-20-000032:notes:114]
[same as prior period, unchanged from 0001262039-19-000033:notes:127]

[0001262039-20-000032:notes:115]
|  | Three Months Ended |
|  | March 31, 2020 |  | March 31, 2019 |
| Shares withheld for taxes | 0.3 |  |  | 0.4 |  |
| Amount withheld for taxes | $ | 37.8 |  |  | $ | 32.0 |  |

[0001262039-20-000032:notes:116]
[same as prior period, unchanged from 0001262039-19-000033:notes:129]

[0001262039-20-000032:notes:117]
[same as prior period, unchanged from 0001262039-19-000033:notes:130]

[0001262039-20-000032:notes:118]
|  | Three Months Ended |
|  | March 31, 2020 |  | March 31, 2019 |
| Expected term in years | 4.4 |  |  | 4.4 |  |
| Volatility | 33.5 | % |  | 34.2 | % |
| Risk-free interest rate | 1.3 | % |  | 2.5 | % |
| Dividend rate | — | % |  | — | % |

[0001262039-20-000032:notes:119]
[same as prior period, unchanged from 0001262039-19-000033:notes:132]

[0001262039-20-000032:notes:120]
|  | Options Outstanding |
|  | Numberof Shares |  | Weighted-AverageExercisePrice |  | Weighted-AverageRemainingContractualLife (Years) |  | AggregateIntrinsicValue |
| Balance—December 31, 2019 | 2.7 |  |  | $ | 50.37 |  |  |  |  |  |  |
| Granted | 0.5 |  |  | 114.48 |  |  |  |  |  |
| Forfeited | — |  |  | 59.28 |  |  |  |  |  |
| Exercised | (0.2 | ) |  | 40.02 |  |  |  |  |  |
| Balance—March 31, 2020 | 3.0 |  |  | $ | 62.41 |  |  |  |  |  |
| Options vested and expected to vest—March 31, 2020 | 3.0 |  |  | $ | 62.41 |  |  | 4.8 |  | $ | 123.8 |  |
| Options exercisable—March 31, 2020 | 1.5 |  |  | $ | 39.50 |  |  | 3.5 |  | $ | 90.3 |  |

[0001262039-20-000032:notes:121]
The aggregate intrinsic value represents the difference between the exercise price of stock options and the quoted market price of our common stock on March 31, 2020 for all in-the-money stock options. As of March 31, 2020, total compensation expense related to unvested stock options granted to employees but not yet recognized was $38.6 million. This expense is expected to be amortized on a straight-line basis over a weighted-average period of 3.1 years.

[0001262039-20-000032:notes:122]
[same as prior period, unchanged from 0001262039-19-000033:notes:135]

[0001262039-20-000032:notes:123]
|  | Three Months Ended |
|  | March 31, 2020 |  | March 31, 2019 |
| Weighted-average fair value per share granted | $ | 33.82 |  |  | $ | 27.12 |  |
| Intrinsic value of options exercised | $ | 13.1 |  |  | $ | 27.2 |  |
| Fair value of options vested | $ | 6.0 |  |  | $ | 4.2 |  |

[0001262039-20-000032:notes:124]
Stock-Based Compensation Expense

[0001262039-20-000032:notes:125]
Stock-based compensation expense, including stock-based compensation expense related to awards classified as liabilities, is included in costs and expenses as follows (in millions):

[0001262039-20-000032:notes:126]
|  | Three Months Ended |
|  | March 31, 2020 |  | March 31, 2019 |
| Cost of product revenue | $ | 0.4 |  |  | $ | 0.4 |  |
| Cost of service revenue | 3.0 |  |  | 2.8 |  |
| Research and development | 10.9 |  |  | 9.4 |  |
| Sales and marketing | 25.7 |  |  | 25.4 |  |
| General and administrative | 5.3 |  |  | 5.0 |  |
| Total stock-based compensation expense | $ | 45.3 |  |  | $ | 43.0 |  |

[0001262039-20-000032:notes:127]
The following table summarizes stock-based compensation expense, including stock-based compensation expense related to awards classified as liabilities, by award type (in millions):

[0001262039-20-000032:notes:128]
|  | Three Months Ended |
|  | March 31, 2020 |  | March 31, 2019 |
| RSUs | $ | 42.2 |  |  | $ | 39.2 |  |
| Stock options | 3.1 |  |  | 2.5 |  |
| ESPP | — |  |  | 1.3 |  |
| Total stock-based compensation expense | $ | 45.3 |  |  | $ | 43.0 |  |

[0001262039-20-000032:notes:129]
[same as prior period, unchanged from 0001262039-19-000033:notes:142]

[0001262039-20-000032:notes:130]
|  | Three Months Ended |
|  | March 31, 2020 |  | March 31, 2019 |
| Income tax benefit associated with stock-based compensation | $ | 10.0 |  |  | $ | 10.0 |  |

[0001262039-20-000032:notes:131]
[same as prior period, unchanged from 0001262039-19-000033:notes:144]

[0001262039-20-000032:notes:132]
Under the Share Repurchase Program originally approved by our board of directors in January 2016 (the “Repurchase Program”), our board of directors has authorized the repurchase of up to $2.5 billion of our outstanding common stock through February 28, 2021. Share repurchases may be made by us from time to time in privately negotiated transactions or in open market transactions. The Repurchase Program does not require us to purchase a minimum number of shares, and may be suspended, modified or discontinued at any time without prior notice.

[0001262039-20-000032:notes:133]
During the three months ended March 31, 2020, we repurchased 10.0 million shares of common stock under the Repurchase Program in open market transactions at an average price of $90.36 per share and for an aggregate purchase price of $899.9 million. As of March 31, 2020, $692.9 million remained available for future share repurchases under the Repurchase Program.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001262039-20-000032:notes:134]
[same as prior period, unchanged from 0001262039-19-000033:notes:147]

[0001262039-20-000032:notes:135]
Our effective tax rate was 11% for the three months ended March 31, 2020, compared to an effective tax rate of 2% for the same period last year. The effective tax rates for the periods presented are primarily comprised of U.S. federal and state taxes, withholding taxes, foreign taxes and excess tax benefits from stock-based compensation expense. The tax rates for the three months ended March 31, 2020 and March 31, 2019 were impacted by U.S. federal and state taxes, withholding taxes and foreign taxes that were $28.3 million and $17.5 million, respectively, which were offset by excess tax benefits from stock-based compensation expense of $15.2 million and $16.0 million, respectively. U.S. federal and state taxes were lowered by a tax benefit of $4.8 million from the foreign-derived intangible income deduction for the three months ended March 31, 2020.

[0001262039-20-000032:notes:136]
As of March 31, 2020 and December 31, 2019, unrecognized tax benefits were $65.6 million and $67.5 million, respectively. If recognized, $60.4 million of the unrecognized tax benefits would favorably affect our effective tax rate. It is our policy to include accrued interest and penalties related to uncertain tax benefits in income tax expense. As of March 31, 2020 and December 31, 2019, accrued interest and penalties were $14.5 million and $14.1 million, respectively. It is reasonably possible that our gross unrecognized tax benefits will decrease by up to $10.4 million in the next 12 months, due to the lapse of the statute of limitations. This decrease, if recognized, would positively impact our effective tax rate, and would be recognized as additional tax benefits.

[0001262039-20-000032:notes:137]
We file income tax returns in the U.S. federal jurisdiction and in various U.S. state and foreign jurisdictions. Generally, we are no longer subject to U.S. state and foreign income tax examinations by tax authorities for tax years prior to 2010. We are no longer subject to examination by U.S federal income tax authorities for tax years prior to 2015. We currently have ongoing tax audits in the United Kingdom, Canada and several other foreign jurisdictions. The focus of these audits is the inter-company profit allocation.

[0001262039-20-000032:notes:138]
On June 7, 2019, the Ninth Circuit overturned the U.S. Tax Court’s decision in Altera Corporation and Subsidiaries vs. Commissioner of Internal Revenue (“Altera”) and ruled in favor of the Commissioner, validating the regulations requiring stock-based compensation to be included in a cost sharing arrangement. Due to the uncertainty surrounding the status of the current regulations and questions related to the scope of potential benefits or obligations, we incurred an unrecognized tax benefit of $8.5 million as of March 31, 2020 related to the Ninth Circuit’s Altera decision regarding stock-based compensation in cost sharing arrangements. We continue to monitor developments in this case and any impact it could have on our tax provision.

[0001262039-20-000032:notes:139]
On March 27, 2020, the President signed into law the Coronavirus Aid, Relief, and Economic Security Act (the “CARES” Act). The CARES Act provides numerous tax provisions and other stimulus measures, including temporary changes regarding the prior and future utilization of net operating losses, temporary changes to the prior and future limitations on interest deductions, temporary suspension of certain payment requirements for the employer portion of Social Security taxes, technical corrections from prior tax legislation for tax depreciation of certain qualified improvement property and the creation of certain refundable employee retention credits. The Company does not expect there to be a material tax impact on its consolidated financial statements at this time and will continue to assess the implications of the CARES Act and its continuing developments and interpretations.


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0001262039-20-000032:notes:140]
[same as prior period, unchanged from 0001262039-19-000033:notes:154]

[0001262039-20-000032:notes:141]
Our tax-deferred savings plan under our 401(k) Plan permits participating U.S. employees to contribute a portion of their pre-tax or after-tax earnings. In Canada, we have a Group Registered Retirement Savings Plan Program (the “RRSP”), which permits participants to make tax-deductible contributions. Our board of directors approved 50% matching contributions on employee contributions up to 4% of each employee’s eligible earnings. Our matching contributions to our 401(k) Plan and the RRSP for the three months ended March 31, 2020 and March 31, 2019 were $2.2 million and $1.7 million, respectively.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001262039-20-000032:notes:142]
[same as prior period, unchanged from 0001262039-19-000033:notes:156]

[0001262039-20-000032:notes:143]
[same as prior period, unchanged from 0001262039-19-000033:notes:157]

[0001262039-20-000032:notes:144]
[same as prior period, unchanged from 0001262039-19-000033:notes:158]

[0001262039-20-000032:notes:145]
|  | Three Months Ended |
| Revenue | March 31, 2020 |  | March 31, 2019 |
| Americas: |  |  |  |
| United States | $ | 181.6 |  |  | $ | 150.3 |  |
| Other Americas | 60.6 |  |  | 50.2 |  |
| Total Americas | 242.2 |  |  | 200.5 |  |
| Europe, Middle East and Africa (“EMEA”) | 220.7 |  |  | 177.2 |  |
| Asia Pacific (“APAC”) | 114.0 |  |  | 94.9 |  |
| Total revenue | $ | 576.9 |  |  | $ | 472.6 |  |

[0001262039-20-000032:notes:146]
| Property and Equipment—net | March 31, 2020 |  | December 31, 2019 |
| Americas: |  |  |  |
| United States | $ | 227.4 |  |  | $ | 197.4 |  |
| Canada | 120.2 |  |  | 120.5 |  |
| Latin America | 6.1 |  |  | 5.5 |  |
| Total Americas | 353.7 |  |  | 323.4 |  |
| EMEA | 14.5 |  |  | 15.2 |  |
| APAC | 6.0 |  |  | 5.7 |  |
| Total property and equipment—net | $ | 374.2 |  |  | $ | 344.3 |  |

[0001262039-20-000032:notes:147]
[same as prior period, unchanged from 0001262039-19-000033:notes:161]

[0001262039-20-000032:notes:148]
|  | Three Months Ended |
|  | March 31, 2020 |  | March 31, 2019 |
| Exclusive Networks Group | 31 | % |  | 30 | % |
| Ingram Micro | 10 | % |  | 11 | % |

[0001262039-20-000032:notes:149]
[same as prior period, unchanged from 0001262039-19-000033:notes:163]

[0001262039-20-000032:notes:150]
|  | March 31, 2020 |  | December 31, 2019 |
| Exclusive Networks Group | 34 | % |  | 36 | % |
| Ingram Micro | * |  |  | 10 | % |
| * Represents less than 10% |


## us-gaap:SubsequentEventsTextBlock

[0001262039-20-000032:notes:151]
SUBSEQUENT EVENT

[0001262039-20-000032:notes:152]
Share repurchase

[0001262039-20-000032:notes:153]
Subsequent to March 31, 2020 through the filing of this Quarterly Report on Form 10-Q, we repurchased 1.5 million shares of our common stock under the Repurchase Program, for an aggregate purchase price of $146.1 million.
