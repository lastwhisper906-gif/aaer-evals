# FTNT note change history — 0001262039-19-000033 → 0001262039-20-000032


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2020-05-07):
[0001262039-20-000032:note_history:1]
The following table summarizes our inventory purchase commitments as of March 31, 2020 (in millions):
  (was, 2019-10-31, similarity 0.7087):
[0001262039-19-000033:note_history:1]
The following table summarizes our future principal contractual obligations as of September 30, 2019 (in millions):

- changed (2020-05-07):
[0001262039-20-000032:note_history:2]
|  | Total |  | 2020 |  | 2021 |  | 2022 |  | 2023 |  | 2024 |  | Thereafter |
| Inventory purchase commitments | $ | 247.2 |  |  | $ | 247.2 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
  (was, 2019-10-31, similarity 0.9942):
[0001262039-19-000033:note_history:2]
|  | Total |  | 2019 |  | 2020 |  | 2021 |  | 2022 |  | 2023 |  | Thereafter |
| Inventory purchase commitments | $ | 241.4 |  |  | $ | 144.5 |  |  | $ | 96.9 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |

- changed (2020-05-07):
[0001262039-20-000032:note_history:3]
Inventory Purchase Commitments—Our independent contract manufacturers procure components and build our products based on our forecasts. These forecasts are based on estimates of future demand for our products, which are in turn based on historical trends and an analysis from our sales and marketing organizations, adjusted for overall market conditions. In
  (was, 2019-10-31, similarity 0.6885):
[0001262039-19-000033:note_history:3]
Inventory Purchase Commitments—Our independent contract manufacturers procure components and build our products based on our forecasts. These forecasts are based on estimates of future demand for our products, which are in turn based on historical trends and an analysis from our sales and marketing organizations, adjusted for overall market conditions. In order to reduce manufacturing lead times and plan for adequate component supply, we may issue purchase orders to some of our independent contract manufacturers which may not be cancelable. As of September 30, 2019, we had $241.4 million of open purchase orders with our independent contract manufacturers that may not be cancelable.

- added (2020-05-07):
[0001262039-20-000032:note_history:4]
order to reduce manufacturing lead times and plan for adequate component supply, we may issue purchase orders to some of our independent contract manufacturers, which may not be cancelable. As of March 31, 2020, we had $247.2 million of open purchase orders with our independent contract manufacturers that may not be cancelable.

- changed (2020-05-07):
[0001262039-20-000032:note_history:5]
Other Contractual Commitments and Open Purchase Orders—In addition to commitments with contract manufacturers, we have open purchase orders and contractual obligations in the ordinary course of business for which we have not received goods or services. As of March 31, 2020, we had $10.9 million in other contractual commitments having a remaining term in excess of one year that may not be cancelable.
  (was, 2019-10-31, similarity 0.9823):
[0001262039-19-000033:note_history:5]
Other Contractual Commitments and Open Purchase Orders—In addition to commitments with contract manufacturers, we have open purchase orders and contractual obligations in the ordinary course of business for which we have not received goods or services. As of September 30, 2019, we had $12.6 million in other contractual commitments having a remaining term in excess of one year that may not be cancelable.

- changed (2020-05-07):
[0001262039-20-000032:note_history:6]
Litigation—We are involved in disputes, litigation, and other legal actions. For lawsuits where we are the defendant, we are in the process of defending these litigation matters, and while there can be no assurances and the outcome of certain of these matters is currently not determinable and not predictable, we currently are unaware of any existing claims or proceedings that we believe are likely to have a material adverse effect on our financial position. There are many uncertainties associated with any litigation and these actions or other third-party claims against us may cause us to incur costly litigation fees, costs and substantial settlement charges, and possibly subject us to damages and other penalties. In addition, the resolution of any IP litigation may require us to make royalty payments, which could adversely affect our gross margins in future periods. If any of those events were to occur, our business, financial condition, results of operations, and cash flows could be adversely affected. Litigation is unpredictable and the actual liability in any such matters may be materially different from our current estimates, which could result in the need to adjust any accrued liability and record additional expenses. We accrue for contingencies when we believe that a loss is probable and that we can reasonably estimate the amount of any such loss.
  (was, 2019-10-31, similarity 0.9924):
[0001262039-19-000033:note_history:6]
Litigation—We are involved in disputes, litigation, and other legal actions. For lawsuits where we are the defendant, we are in the process of defending these litigation matters, and while there can be no assurances and the outcome of certain of these matters is currently not determinable and not predictable, we currently are unaware of any existing claims or proceedings that we believe are likely to have a material adverse effect on our financial position. There are many uncertainties associated with any litigation and these actions or other third-party claims against us may cause us to incur costly litigation fees, costs and substantial settlement charges, and possibly subject us to damages and other penalties. In addition, the resolution of any intellectual property litigation may require us to make royalty payments, which could adversely affect our gross margins in future periods. If any of those events were to occur, our business, financial condition, results of operations, and cash flows could be adversely affected. Litigation is unpredictable and the actual liability in any such matters may be materially different from our current estimates, which could result in the need to adjust any accrued liability and record additional expenses. We accrue for contingencies when we believe that a loss is probable and that we can reasonably estimate the amount of any such loss.

- changed (2020-05-07):
[0001262039-20-000032:note_history:7]
Indemnification and Other Matters—Under the indemnification provisions of our standard sales contracts, we agree to defend our customers against third-party claims asserting various allegations such as product defects and infringement of certain IP rights, which may include patents, copyrights, trademarks or trade secrets, and to pay judgments entered on such claims. In some contracts, our exposure under these indemnification provisions is limited by the terms of the contracts to certain defined limits, such as the total amount paid by our customer under the agreement. However, certain agreements include covenants, penalties and indemnification provisions including and beyond indemnification for third-party claims of IP infringement, that could potentially expose us to losses in excess of the amount received under the agreement, and in some instances to potential liability that is not contractually limited. To date, although from time to time there are indemnification claims asserted against us and currently there are pending indemnification claims, there have been no material awards under such indemnification provisions.
  (was, 2019-10-31, similarity 0.9819):
[0001262039-19-000033:note_history:7]
Indemnification and Other Matters—Under the indemnification provisions of our standard sales contracts, we agree to defend our customers against third-party claims asserting various allegations such as product defects and infringement of certain intellectual property rights, which may include patents, copyrights, trademarks or trade secrets, and to pay judgments entered on such claims. In some contracts, our exposure under these indemnification provisions is limited by the terms of the contracts to certain defined limits, such as the total amount paid by our customer under the agreement. However, certain agreements include covenants, penalties and indemnification provisions including and beyond indemnification for third-party claims of intellectual property infringement, that could potentially expose us to losses in excess of the amount received under the agreement, and in some instances to potential liability that is not contractually limited. To date, although from time to time there are indemnification claims asserted against us and currently there are pending indemnification claims, there have been no material awards under such indemnification provisions.

- added (2020-05-07):
[0001262039-20-000032:note_history:8]
Periodically, we, like other security companies and companies in other industries, may experience cybersecurity threats, malicious activity directed against our information technology infrastructure and unauthorized attempts to gain access to our and our customers’ sensitive information and systems.

- removed (2020-05-07):
[0001262039-19-000033:note_history:9]
Periodically we, like other security companies and companies in other industries, may experience cybersecurity threats, malicious activity directed against our information technology infrastructure and unauthorized attempts to gain access to our and our customers’ sensitive information and systems. For example, as previously disclosed, in the second quarter of 2019, we discovered that an unauthorized party illegally targeted us using sophisticated techniques, such as stealing technical data in order to both impersonate our firewall update servers and possibly attempt other attack methodologies, in an effort to try to gain access to certain of our customers’ systems. We have substantially completed our investigation of this incident and we do not currently believe that it had a material impact on our business, including our customers. We are currently not aware of any claims arising from this matter.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2020-05-07):
[0001262039-20-000032:note_history:10]
Basis of Presentation and Preparation—The unaudited condensed consolidated financial statements of Fortinet, Inc. and its wholly owned subsidiaries (collectively, “we,” “us” or “our”) have been prepared in accordance with generally accepted accounting principles in the United States (“GAAP”) for interim financial information, as well as the instructions to Form 10-Q pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (the “SEC”). Accordingly, they do not include all of the information and footnotes required by GAAP for complete financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the year ended December 31, 2019, contained in our Annual Report on Form 10-K filed with the SEC on February 26, 2020. In the opinion of management, all adjustments, which includes normal recurring adjustments, considered necessary for a fair presentation have been included. All intercompany balances, transactions and cash flows have been eliminated. The results of operations for the three months ended March 31, 2020 are not necessarily indicative of the results for the full year or for any future periods. The condensed consolidated balance sheet as of December 31, 2019 is derived from the audited consolidated financial statements for the year ended December 31, 2019. For 2020, the amounts previously reported as Income taxes payable are included in Accrued liabilities. Prior periods have been reclassified to conform with current period presentation.
  (was, 2019-10-31, similarity 0.9196):
[0001262039-19-000033:note_history:10]
Basis of Presentation and Preparation—The unaudited condensed consolidated financial statements of Fortinet, Inc. and its wholly owned subsidiaries (collectively, “we,” “us” or “our”) have been prepared in accordance with generally accepted accounting principles in the United States (“GAAP”) for interim financial information, as well as the instructions to Form 10-Q pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (the “SEC”). Accordingly, they do not include all of the information and footnotes required by GAAP for complete financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the year ended December 31, 2018, contained in our Annual Report on Form 10-K filed with the SEC on February 27, 2019. In the opinion of management, all adjustments, which includes normal recurring adjustments, considered necessary for a fair presentation have been included. All intercompany balances, transactions and cash flows have been eliminated. The results of operations for the three and nine months ended September 30, 2019 are not necessarily indicative of the results for the full year or for any future periods. The condensed consolidated balance sheet as of December 31, 2018 is derived from the audited consolidated financial statements for the year ended December 31, 2018.

- added (2020-05-07):
[0001262039-20-000032:note_history:11]
There have been no material changes to our significant accounting policies as of and for the three months ended March 31, 2020.

- added (2020-05-07):
[0001262039-20-000032:note_history:12]
In June 2016, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) 2016-13—Financial Instruments—Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments (“Topic 326”), which provides guidance on how an entity should measure credit losses on financial instruments. The standard replaces the existing incurred loss model with an expected credit loss model for financial assets measured at amortized cost, including trade receivables, and requires that credit losses on available-for-sale debt securities be presented as an allowance rather than as a write-down. The new approach to estimating credit losses (referred to as the current expected credit losses model) generally accelerates recognition of credit losses. We adopted Topic 326 on January 1, 2020 using the modified retrospective method. The adoption of this standard did not have a material impact on our condensed consolidated financial statements.

- changed (2020-05-07):
[0001262039-20-000032:note_history:13]
In August 2018, the FASB issued ASU 2018-15—Intangibles—Goodwill and Other—Internal-Use Software (Subtopic 350-40): Customer’s Accounting for Implementation Costs Incurred in a Cloud Computing Arrangement That Is a Service Contract, which requires a customer in a cloud computing arrangement that is a service contract to follow the internal-use software guidance in Accounting Standards Codification (“ASC”) Topic 350, Intangibles—Goodwill and Other, to determine which implementation costs to capitalize as assets or expense as incurred. We adopted ASU 2018-15 on January 1, 2020. The adoption of this standard did not have a material impact on our condensed consolidated financial statements.
  (was, 2019-10-31, similarity 0.7732):
[0001262039-19-000033:note_history:13]
In August 2018, the FASB issued ASU 2018-15—Intangibles-Goodwill and Other—Internal-Use Software (Subtopic 350-40): Customer’s Accounting for Implementation Costs Incurred in a Cloud Computing Arrangement That Is a Service Contract, which requires a customer in a cloud computing arrangement that is a service contract to follow the internal-use software guidance in ASC Topic 350, Intangibles—Goodwill and Other, to determine which implementation costs to capitalize as assets or expense as incurred. Companies can choose to adopt the ASU 2018-15 prospectively or retrospectively. ASU 2018-15 is effective for us beginning January 1, 2020, and early adoption is permitted. We are currently evaluating the impact of ASU 2018-15 on our condensed consolidated financial statements.

- added (2020-05-07):
[0001262039-20-000032:note_history:14]
In August 2018, the FASB issued ASU 2018-13—Fair Value Measurement (Topic 820): Disclosure Framework—Changes to the Disclosure Requirements for Fair Value Measurement, which eliminates, adds and modifies certain disclosure requirements for fair value measurements in ASC 820, Fair Value Measurement, as part of its disclosure framework project. We adopted ASU 2018-13 on January 1, 2020. The adoption of this standard did not have a material impact on our disclosures.

- added (2020-05-07):
[0001262039-20-000032:note_history:15]
Income Taxes

- added (2020-05-07):
[0001262039-20-000032:note_history:16]
In December 2019, the FASB issued ASU 2019-12—Income Taxes (Topic 740): Simplifying the Accounting for Income Taxes. The amendments in ASU 2019-12 simplify the accounting for income taxes by removing certain exceptions to the general principles in Topic 740. The amendments also improve consistent application and simplification of GAAP for other areas of Topic 740 by clarifying and amending existing guidance. ASU 2019-12 is effective for us beginning on January 1, 2021. Early adoption of the amendments is permitted. We are currently evaluating the impact of ASU 2019-12 on our condensed consolidated financial statements.

- removed (2020-05-07):
[0001262039-19-000033:note_history:17]
There have been no material changes to our significant accounting policies as of and for the three and nine months ended September 30, 2019, except for the accounting policies for leases that were updated as a result of adopting Accounting Standards Update (“ASU”) 2016-02—Leases (Topic 842) (“Topic 842”). For more information, refer to the “Recently Adopted Accounting Standards” and Note 10.

- removed (2020-05-07):
[0001262039-19-000033:note_history:18]
Leases

- removed (2020-05-07):
[0001262039-19-000033:note_history:19]
In February 2016, the Financial Accounting Standards Board (the “FASB”) issued Topic 842, which requires the recognition of right-of-use (“ROU”) assets and lease liabilities for operating leases on the condensed consolidated balance sheet. We adopted Topic 842 and its related amendments as of January 1, 2019 using a modified retrospective transition approach by applying the new standard to all leases existing at the date of initial application and not restating comparative periods. We elected the package of practical expedients permitted under the transition guidance, which allowed us to waive reassessing the lease classification for any expired or existing leases, the initial direct costs for any existing leases and whether any expired or existing contracts contained leases.

- removed (2020-05-07):
[0001262039-19-000033:note_history:20]
Under the new guidance, we determine if an arrangement contains a lease and the classification of that lease, if applicable, at inception or upon modification of a contract. We have elected to not recognize a lease liability or ROU asset for short-term leases (leases that, at the commencement date, have a lease term of twelve months or less and do not include an option to purchase the underlying asset that the Company is reasonably certain to exercise). We have elected to not allocate the contract consideration for operating lease contracts with lease and non-lease components, and account for the lease and non-lease components as a single lease component. ROU assets represent our right to use an underlying asset for the lease term. Lease liabilities represent our obligation to make lease payments under the lease. Operating lease ROU assets and liabilities are recognized at the lease commencement date based on the present value of lease payments over the lease term. The implicit rate within our operating leases is generally not determinable and therefore we use our incremental borrowing rate at the lease commencement date to determine the present value of lease payments. The determination of our incremental borrowing rate requires judgment. We determine our incremental borrowing rate for each lease using indicative bank borrowing rates, adjusted for various factors including level of collateralization, term and currency to align with the terms of a lease. The operating lease ROU asset also includes any lease prepayments, net of lease incentives. Certain leases include options to extend or terminate the lease. An option to extend the lease is considered in connection with determining the ROU asset and lease liability when it is reasonably certain we will exercise that option. An option to terminate is considered unless it is reasonably certain we will not exercise the option.

- removed (2020-05-07):
[0001262039-19-000033:note_history:21]
The primary impact of adopting Topic 842 was the recognition of ROU assets and lease liabilities for operating leases of $39.1 million and $40.6 million, respectively, on January 1, 2019, which included reclassifying prepaid rent and deferred rent as a component of the ROU asset. Topic 842 did not have a material impact on our condensed consolidated statements of income and cash flows.

- removed (2020-05-07):
[0001262039-19-000033:note_history:22]
The ROU assets and the short-term and long-term lease liabilities from our operating leases are included in other assets, accrued liabilities and other liabilities in our condensed consolidated balance sheets, respectively. Our accounting for finance leases (formerly referred to as capital leases prior to the adoption of Topic 842) remains substantially unchanged. Finance leases are not material to our condensed consolidated financial statements.

- removed (2020-05-07):
[0001262039-19-000033:note_history:23]
Lease expense for lease payments for our operating leases is recognized on a straight-line basis over the term of the lease.

- removed (2020-05-07):
[0001262039-19-000033:note_history:24]
Comprehensive Income

- removed (2020-05-07):
[0001262039-19-000033:note_history:25]
In February 2018, the FASB issued ASU 2018-02—Income Statement—Reporting Comprehensive Income (Topic 220): Reclassification of Certain Tax Effects from Accumulated Other Comprehensive Income, which allows companies to reclassify stranded tax effects resulting from the Tax Cuts and Jobs Act (the “2017 Tax Act”) from accumulated other comprehensive income to retained earnings. We adopted ASU 2018-02 on January 1, 2019 and elected to reclassify $0.1 million of stranded tax effects as of that date.

- removed (2020-05-07):
[0001262039-19-000033:note_history:26]
Stock Compensation

- removed (2020-05-07):
[0001262039-19-000033:note_history:27]
In June 2018, the FASB issued ASU 2018-07—Compensation—Stock Compensation (Topic 718): Improvements to Nonemployee Share-Based Payment Accounting, which simplifies the accounting for share-based payments to nonemployees by aligning it with the accounting for share-based payments to employees subject to certain exceptions. ASU 2018-07 expands the scope of Accounting Standards Codification (“ASC”) Topic 718, Compensation—Stock Compensation (“ASC 718”), to include share-based payments granted to nonemployees in exchange for goods or services used or consumed in an entity’s own operations and supersedes the guidance in ASC 505, Equity, by moving it to ASC 718. We adopted ASU 2018-07 on January 1, 2019. ASU 2018-07 did not have a material impact on our condensed consolidated financial statements.

- removed (2020-05-07):
[0001262039-19-000033:note_history:28]
In August 2018, the FASB issued ASU 2018-13—Fair Value Measurement (Topic 820): Disclosure Framework—Changes to the Disclosure Requirements for Fair Value Measurement, which eliminates, adds and modifies certain disclosure requirements for fair value measurements in ASC 820, Fair Value Measurement, as part of its disclosure framework project. ASU 2018-13 is effective for us beginning January 1, 2020. The amendments in ASU 2018-13 that relate to changes in unrealized gains and losses, the range and weighted average of significant unobservable inputs used to develop Level 3 fair value measurements and the narrative description of measurement uncertainty should be applied prospectively for only the most recent interim or annual period presented in the initial fiscal year of adoption. All other amendments in ASU 2018-13 should be applied retrospectively to all periods presented upon their effective date. Early adoption is permitted upon issuance of ASU 2018-13. An entity is permitted to early adopt any removed or modified disclosures upon issuance of ASU 2018-13 and delay adoption of the additional disclosures until their effective date. We are currently assessing the impact the new guidance will have on our disclosures.

- removed (2020-05-07):
[0001262039-19-000033:note_history:29]
In June 2016, the FASB issued ASU 2016-13—Financial Instruments—Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments and in November 2018, the FASB issued ASU 2018-19—Codification Improvements to Topic 326, Financial Instruments—Credit Losses, as a subsequent amendment to the initial guidance (collectively, Topic 326). In April 2019, the FASB issued ASU 2019-04—Codification Improvements to Topic 326: Financial Instruments—Credit Losses, Topic 815, Derivatives and Hedging, and Topic 825, Financial Instruments, and in May 2019, the FASB issued ASU 2019-05—Financial Instruments—Credit Losses (Topic 326): Targeted Transition Relief. Topic 326 requires a financial asset (or a group of financial assets) measured at an amortized cost basis to be presented at the net amount expected to be collected. The new approach to estimating credit losses (referred to as the current expected credit losses model) generally accelerates recognition of credit losses. We are in the process of determining the changes needed to our valuation model for trade receivables, and we are reviewing our process to identify credit-related losses on available-for-sale investments. We also expect the new guidance to expand our related financial statement disclosures. The new guidance is effective for us beginning on January 1, 2020, and early adoption is permitted. We are currently assessing the impact of the new guidance on our condensed consolidated financial statements.


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2020-05-07):
[0001262039-20-000032:note_history:30]
|  | Three Months Ended |
|  | March 31, 2020 |  | March 31, 2019 |
| Product | $ | 192.3 |  |  | $ | 162.7 |  |
| Service: |  |  |  |
| Security subscription | 211.4 |  |  | 169.6 |  |
| Technical support and other | 173.2 |  |  | 140.3 |  |
| Total service revenue | 384.6 |  |  | 309.9 |  |
| Total revenue | $ | 576.9 |  |  | $ | 472.6 |  |
  (was, 2019-10-31, similarity 0.662):
[0001262039-19-000033:note_history:30]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30, 2019 |  | September 30, 2018 |  | September 30, 2019 |  | September 30, 2018 |
| Product | $ | 197.1 |  |  | $ | 164.5 |  |  | $ | 549.7 |  |  | $ | 473.6 |  |
| Service: |  |  |  |  |  |  |  |
| Security subscription | 192.8 |  |  | 157.0 |  |  | 545.5 |  |  | 440.7 |  |
| Technical support and other | 157.6 |  |  | 132.4 |  |  | 446.6 |  |  | 379.9 |  |
| Total service revenue | 350.4 |  |  | 289.4 |  |  | 992.1 |  |  | 820.6 |  |
| Total revenue | $ | 547.5 |  |  | $ | 453.9 |  |  | $ | 1,541.8 |  |  | $ | 1,294.2 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2020-05-07):
[0001262039-20-000032:note_history:31]
|  | Three Months Ended |
|  | March 31, 2020 |  | March 31, 2019 |
| Product | $ | 192.3 |  |  | $ | 162.7 |  |
| Service: |  |  |  |
| Security subscription | 211.4 |  |  | 169.6 |  |
| Technical support and other | 173.2 |  |  | 140.3 |  |
| Total service revenue | 384.6 |  |  | 309.9 |  |
| Total revenue | $ | 576.9 |  |  | $ | 472.6 |  |
  (was, 2019-10-31, similarity 0.662):
[0001262039-19-000033:note_history:31]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30, 2019 |  | September 30, 2018 |  | September 30, 2019 |  | September 30, 2018 |
| Product | $ | 197.1 |  |  | $ | 164.5 |  |  | $ | 549.7 |  |  | $ | 473.6 |  |
| Service: |  |  |  |  |  |  |  |
| Security subscription | 192.8 |  |  | 157.0 |  |  | 545.5 |  |  | 440.7 |  |
| Technical support and other | 157.6 |  |  | 132.4 |  |  | 446.6 |  |  | 379.9 |  |
| Total service revenue | 350.4 |  |  | 289.4 |  |  | 992.1 |  |  | 820.6 |  |
| Total revenue | $ | 547.5 |  |  | $ | 453.9 |  |  | $ | 1,541.8 |  |  | $ | 1,294.2 |  |

- added (2020-05-07):
[0001262039-20-000032:note_history:32]
During the three months ended March 31, 2020 and March 31, 2019, we recognized $348.9 million and $288.6 million in service revenue that was included in the deferred revenue balance as of December 31, 2019 and December 31, 2018, respectively.

- changed (2020-05-07):
[0001262039-20-000032:note_history:33]
As of March 31, 2020, the aggregate amount of the transaction price allocated to remaining performance obligations was $2.23 billion, which was substantially comprised of deferred security subscription and technical support services revenue. We expect to recognize approximately $1.23 billion as revenue over the next 12 months and the remainder thereafter.
  (was, 2019-10-31, similarity 0.9798):
[0001262039-19-000033:note_history:33]
As of September 30, 2019, the aggregate amount of the transaction price allocated to remaining performance obligations was $1.95 billion, which was substantially comprised of deferred security subscription and technical support services revenue. We expect to recognize approximately $1.06 billion as revenue over the next 12 months and the remainder thereafter.

- added (2020-05-07):
[0001262039-20-000032:note_history:34]
Trade accounts receivable are recorded at the invoiced amount. On January 1, 2020, we adopted Topic 326, which provides guidance on how to measure credit losses on financial instruments, including accounts receivable. Prior to our adoption of Topic 326, our accounts receivable balance was reduced by an allowance for doubtful accounts that we determined based on our assessment of the collectability of customer accounts. Under Topic 326, our accounts receivable balance is reduced by an allowance for credit losses. We measure expected credit losses of accounts receivable on a collective (pool) basis, aggregating accounts receivable that are either current or no more than 60 days past due, and aggregating accounts receivable that are more than 60 days past due. We apply a credit-loss percentage to each of the pools that is based on our historical credit losses. We review whether each of our significant accounts receivable that is more than 60 days past due continues to exhibit

- added (2020-05-07):
[0001262039-20-000032:note_history:35]
similar risk characteristics with the other accounts receivable in the pool. If we determine that it does not, we evaluate it for expected credit losses on an individual basis.

- added (2020-05-07):
[0001262039-20-000032:note_history:36]
The COVID-19 pandemic and the recent economic downturn prompted us to perform additional credit reviews of our existing customers, including obtaining recent credit reports and reviewing their latest available statements of financial position. After performing our additional reviews, we determined that, while there may be delays in our collections, the risk of credit loss on our trade accounts receivable as of March 31, 2020 was expected to be consistent with prior periods and that our methodology for estimating credit losses was appropriate.

- added (2020-05-07):
[0001262039-20-000032:note_history:37]
The allowance for credit losses was $1.1 million as of March 31, 2020, and the allowance for doubtful accounts was $1.2 million as of December 31, 2019. Provisions, write-offs and recoveries were not material during the three months ended March 31, 2020.

- changed (2020-05-07):
[0001262039-20-000032:note_history:38]
Sales commissions earned by our sales force are considered incremental and recoverable costs of obtaining a contract with a customer. The amortization of deferred contract costs is included in sales and marketing expense in our condensed consolidated statements of income. Amortization of deferred contract costs during the three months ended March 31, 2020 and March 31, 2019 were $31.3 million and $25.1 million, respectively.
  (was, 2019-10-31, similarity 0.8029):
[0001262039-19-000033:note_history:38]
Sales commissions earned by our sales force are considered incremental and recoverable costs of obtaining a contract with a customer. The amortization of deferred contract costs is included in sales and marketing expense in our condensed consolidated statements of income. Amortization of deferred contract costs during the three months ended September 30, 2019 and September 30, 2018 were $27.5 million and $23.2 million, respectively.  Amortization of deferred contract costs during the nine months ended September 30, 2019 and September 30, 2018 were $78.5 million and $66.3 million, respectively.

- removed (2020-05-07):
[0001262039-19-000033:note_history:39]
During the three months ended September 30, 2019 and September 30, 2018, we recognized $211.6 million and $173.0 million in revenue that was included in the deferred revenue balance as of December 31, 2018 and December 31, 2017, respectively. During the nine months ended September 30, 2019 and September 30, 2018, we recognized $752.2 million and $615.3 million in revenue that was included in the deferred revenue balance as of December 31, 2018 and December 31, 2017, respectively.

- removed (2020-05-07):
[0001262039-19-000033:note_history:40]
Trade accounts receivable are recorded at the invoiced amount. Trade accounts receivable are reduced by an allowance for doubtful accounts which is determined based on our assessment of the collectability of customer accounts. The allowance for doubtful accounts was $0.8 million and $0.9 million as of September 30, 2019 and December 31, 2018, respectively.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- changed (2020-05-07):
[0001262039-20-000032:note_history:41]
SUBSEQUENT EVENT
  (was, 2019-10-31, similarity 0.9697):
[0001262039-19-000033:note_history:41]
SUBSEQUENT EVENTS

- changed (2020-05-07):
[0001262039-20-000032:note_history:42]
Subsequent to March 31, 2020 through the filing of this Quarterly Report on Form 10-Q, we repurchased 1.5 million shares of our common stock under the Repurchase Program, for an aggregate purchase price of $146.1 million.
  (was, 2019-10-31, similarity 0.6841):
[0001262039-19-000033:note_history:42]
Subsequent to September 30, 2019 through the filing of this Quarterly Report on Form 10-Q, we repurchased 0.3 million shares of our common stock, for an aggregate purchase price of $23.5 million at an average price of $77.39 per share, under the Repurchase Program.

- removed (2020-05-07):
[0001262039-19-000033:note_history:43]
Business combination

- removed (2020-05-07):
[0001262039-19-000033:note_history:44]
On October 28, 2019, we acquired enSilo Ltd. (“enSilo”), a privately held company that provides endpoint detection and response products and services. We acquired enSilo for approximately $20.0 million in initial consideration, subject to certain adjustments.

- removed (2020-05-07):
[0001262039-19-000033:note_history:45]
We are currently in the process of evaluating the business combination accounting, including the consideration transferred and the initial purchase price allocation.
