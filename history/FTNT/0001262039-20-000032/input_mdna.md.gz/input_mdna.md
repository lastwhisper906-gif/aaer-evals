# FTNT MD&A — 0001262039-20-000032


## mdna

[0001262039-20-000032:mdna:1]
[same as prior period, unchanged from 0001262039-19-000033:mdna:1]

[0001262039-20-000032:mdna:2]
| • | the duration and impact of the COVID-19 pandemic; |

[0001262039-20-000032:mdna:3]
[same as prior period, unchanged from 0001262039-19-000033:mdna:2]

[0001262039-20-000032:mdna:4]
[same as prior period, unchanged from 0001262039-19-000033:mdna:3]

[0001262039-20-000032:mdna:5]
[same as prior period, unchanged from 0001262039-19-000033:mdna:4]

[0001262039-20-000032:mdna:6]
| • | the impact of macro-economic, geopolitical factors and other disruption on our manufacturing or sales, including the impact of the COVID-19 pandemic and other public health issues and natural disasters; |

[0001262039-20-000032:mdna:7]
[same as prior period, unchanged from 0001262039-19-000033:mdna:6]

[0001262039-20-000032:mdna:8]
[same as prior period, unchanged from 0001262039-19-000033:mdna:7]

[0001262039-20-000032:mdna:9]
[same as prior period, unchanged from 0001262039-19-000033:mdna:8]

[0001262039-20-000032:mdna:10]
[same as prior period, unchanged from 0001262039-19-000033:mdna:9]

[0001262039-20-000032:mdna:11]
[same as prior period, unchanged from 0001262039-19-000033:mdna:10]

[0001262039-20-000032:mdna:12]
[same as prior period, unchanged from 0001262039-19-000033:mdna:11]

[0001262039-20-000032:mdna:13]
[same as prior period, unchanged from 0001262039-19-000033:mdna:12]

[0001262039-20-000032:mdna:14]
[same as prior period, unchanged from 0001262039-19-000033:mdna:13]

[0001262039-20-000032:mdna:15]
[same as prior period, unchanged from 0001262039-19-000033:mdna:14]

[0001262039-20-000032:mdna:16]
| • | continued investments in research and development, and expectations that our research and development expense will increase in absolute dollars during 2020; |

[0001262039-20-000032:mdna:17]
| • | continued investments in our sales resources and infrastructure and marketing strategy, and expectations that our sales and marketing expense will increase in absolute dollars during 2020; |

[0001262039-20-000032:mdna:18]
| • | expectations that our general and administrative expense will increase in absolute dollars during 2020; |

[0001262039-20-000032:mdna:19]
| • | expectations that proceeds from the exercise of stock options in future years will be adversely impacted by the increased mix of restricted stock units versus stock options granted; |

[0001262039-20-000032:mdna:20]
| • | estimates of a range of 2020 spending on our headquarters expansion project; |

[0001262039-20-000032:mdna:21]
22

[0001262039-20-000032:mdna:22]
[same as prior period, unchanged from 0001262039-19-000033:mdna:20]

[0001262039-20-000032:mdna:23]
[same as prior period, unchanged from 0001262039-19-000033:mdna:21]

[0001262039-20-000032:mdna:24]
[same as prior period, unchanged from 0001262039-19-000033:mdna:22]

[0001262039-20-000032:mdna:25]
| • | statements regarding expected outcomes and liabilities in litigation; |

[0001262039-20-000032:mdna:26]
[same as prior period, unchanged from 0001262039-19-000033:mdna:24]

[0001262039-20-000032:mdna:27]
[same as prior period, unchanged from 0001262039-19-000033:mdna:25]

[0001262039-20-000032:mdna:28]
[same as prior period, unchanged from 0001262039-19-000033:mdna:26]

[0001262039-20-000032:mdna:29]
[same as prior period, unchanged from 0001262039-19-000033:mdna:27]

[0001262039-20-000032:mdna:30]
Fortinet is a global leader in cybersecurity solutions provided to a wide variety of organizations, such as enterprises, communication service providers, government organizations and small businesses. Our cybersecurity solutions are designed to provide broad visibility and segmentation of the digital attack surface through our integrated Fortinet Security Fabric platform, which features automated protection, detection and response.

[0001262039-20-000032:mdna:31]
[same as prior period, unchanged from 0001262039-19-000033:mdna:29]

[0001262039-20-000032:mdna:32]
| • | Security-Driven Networking—We derive a majority of product sales from our FortiGate network security appliances. Our FortiGate network security appliances include a broad set of built-in security and networking features and functionalities, including firewall, next-generation firewall, secure web gateway, secure sockets layer inspection, software-defined wide-area network (“SD-WAN”), intrusion prevention, data leak prevention, virtual private network (“VPN”) , switch and wireless controller and wide area network edge. Our network security appliances are managed by our FortiOS network operating system, which provides the foundation for FortiGate security functions. We enhance the performance of our network security appliances from branch to data center by designing and implementing Security Processing Unit (“SPU”) technology within our appliances, enabling us to add security and network functionality with minimal impact to network throughput performance. |

[0001262039-20-000032:mdna:33]
| • | Infrastructure Security—The Fortinet Security Fabric platform is a broad, automated and integrated security platform that extends beyond the network to cover other attack vectors. Other infrastructure solutions covered include Secure Access (Wi-Fi and switch) and teleworker and remote security solutions such as FortiAuthenticator, FortiClient and FortiToken. |

[0001262039-20-000032:mdna:34]
| • | Dynamic Cloud Security—We help customers connect securely to and across their hybrid, public and private cloud environments by offering security through our virtual firewall and other software products. Our public and private cloud security solutions, including virtual appliances and hosted solutions, extend the core capabilities of the Fortinet Security Fabric platform to provide businesses with the same level of cybersecurity and threat intelligence in and across cloud environments that they receive on their physical networks, delivering security that follows their applications and data. Fortinet cloud security offerings are available across all major cloud providers, including |

[0001262039-20-000032:mdna:35]
23

[0001262039-20-000032:mdna:36]
Amazon Web Services, Microsoft Azure, Google Cloud, Oracle Cloud, Alibaba Cloud and IBM Cloud. Our Cloud Security portfolio also includes securing applications, including email and web.

[0001262039-20-000032:mdna:37]
| • | Endpoint Protection, Internet of Things (“IoT”) and Operational Technology (“OT”) Security—We protect end-customers from advanced threats that target their devices and the data that reside on them through our advanced endpoint solutions that provide core endpoint protection, advanced threat protection, incident monitoring, and response. Additionally, the proliferation of IoT and the digitization of OT devices has generated new opportunities for us to grow our business. We offer network access control solutions that provide visibility, control and automated event responses in order to secure IoT devices. |

[0001262039-20-000032:mdna:38]
| • | AI-Driven Security Operations—We develop and provide AI-driven security operations solutions, including FortiGuard security services, that can be applied across the entire Fortinet Security Fabric platform. These solutions help customers better secure their environments by delivering deeper intelligence and insights and by narrowing the gaps in security skills and resources that are present in many organizations. |

[0001262039-20-000032:mdna:39]
In addition to our security solutions, our customers may purchase FortiGuard and other security subscription services to receive threat intelligence updates, FortiCare technical support services and the support of Technical Account Managers, Resident Engineers and professional service consultants for implementations or training services.

[0001262039-20-000032:mdna:40]
[same as prior period, unchanged from 0001262039-19-000033:mdna:36]

[0001262039-20-000032:mdna:41]
| • | Total revenue was $576.9 million during the three months ended March 31, 2020, an increase of 22% compared to $472.6 million in the same period last year. Product revenue was $192.3 million during the three months ended March 31, 2020, an increase of 18% compared to $162.7 million in the same period last year. Service revenue was $384.6 million during the three months ended March 31, 2020, an increase of 24% compared to $309.9 million in the same period last year. |

[0001262039-20-000032:mdna:42]
| • | We generated operating income of $115.9 million, which included a gain on an intellectual property (“IP”) matter of $36.8 million, during the three months ended March 31, 2020, an increase of 129% compared to $50.6 million in the same period last year. |

[0001262039-20-000032:mdna:43]
| • | Cash, cash equivalents and investments were $1.57 billion as of March 31, 2020, a decrease of $636.6 million, or 29%, from December 31, 2019. |

[0001262039-20-000032:mdna:44]
| • | During the three months ended March 31, 2020, we repurchased 10.0 million shares of common stock under our Share Repurchase Program (the “Repurchase Program”), for a total purchase price of $899.9 million. |

[0001262039-20-000032:mdna:45]
| • | Deferred revenue was $2.23 billion as of March 31, 2020, an increase of $90.9 million, or 4%, from December 31, 2019. |

[0001262039-20-000032:mdna:46]
| • | We generated cash flows from operating activities of $319.4 million, which includes $50 million proceeds from an IP matter, during the three months ended March 31, 2020, an increase of $118.1 million, or 59%, compared to the same period last year. |

[0001262039-20-000032:mdna:47]
Our revenue growth was driven by both product and service revenue. On a geographic basis, revenue continues to be diversified globally, which remains a key strength of our business. Americas, Europe, Middle East and Africa (“EMEA”) and Asia Pacific (“APAC”) comprised 42%, 38% and 20% of the total revenue, respectively, in the three months ended March 31, 2020 and 2019. Product revenue grew 18% during the three months ended March 31, 2020 compared to the same period last year. We experienced revenue growth across several of our hardware and software products, including SD-WAN and teleworker and remote security solutions. Service revenue growth of 24% during the three months ended March 31, 2020 compared to the same period last year was driven by the strength of our FortiGuard and other security subscription revenue, which grew 25% compared to the same period last year. During the three months ended March 31, 2020, FortiCare technical support and other service revenue grew 23% compared to the same period last year.

[0001262039-20-000032:mdna:48]
During the three months ended March 31, 2020, we recognized a $36.8 million gain on an IP matter in connection with a mutual covenant-not-to-sue and release agreement with a competitor in the network security industry. Excluding the gain on the IP matter, operating expenses as a percentage of revenue decreased by one percentage point compared to the same period last year. Headcount increased to 7,448 employees and contractors as of March 31, 2020, a 5% growth compared to 7,082 as of December 31, 2019 and a 24% growth compared to 6,015 as of March 31, 2019.

[0001262039-20-000032:mdna:49]
24

[0001262039-20-000032:mdna:50]
COVID-19 Update

[0001262039-20-000032:mdna:51]
The United States and the global community we serve are facing unprecedented challenges posed by the COVID-19 pandemic. In response to the pandemic, we have taken a number of actions to protect our employees, including restricting travel and directing most of our employees to work from home. We have implemented our readiness plans, which include steps to maintain critical internet infrastructure with most employees working remotely. We have not conducted any employee layoffs related to the COVID-19 pandemic, and we do not anticipate any related layoffs for the foreseeable future. We have also increased our employee charitable contributions matching program for COVID-19 related donations and will match up to $2.0 million of employee charitable contributions. In order to help address the needs of organizations securing highly distributed and remote workforces, we have opened our online, self-paced catalogue of advanced Network Security Expert training courses for free to the public. Costs incurred to date relating to COVID-19 impact mitigation efforts have not been material.

[0001262039-20-000032:mdna:52]
While we believe the pandemic has had certain impacts on our business, we do not believe there has been a material impact from the effects of the pandemic on our business and operations, results of operations, financial condition, cash flows, liquidity and capital and financial resources as of and during the three months ended March 31, 2020. While our linearity during the first quarter of 2020 was consistent with prior quarters, we saw an elevated level of buying during the middle two weeks of March. Our average service contract term remained consistent with the same period of 2019. Average customer payment terms increased by less than 15%. With respect to our supply chain, our product backlog was in line with historical averages and our suppliers delivered over 90% of their commitments to us. Our channel inventory levels were consistent with prior quarters.

[0001262039-20-000032:mdna:53]
Through the filing of this Quarterly Report on Form 10-Q, there have been no material changes to the trends described above. Going forward, however, the situation is uncertain, rapidly changing and hard to predict, and the COVID-19 pandemic may have a material negative impact on our future periods, including our results for the three months ending June 30, 2020, our annual results for 2020, and beyond. To highlight the uncertainty remaining for the three months ending June 30, 2020, it should be noted that, due to customer buying patterns and the efforts of our sales force and channel partners to meet or exceed quarterly quotas, we have historically received a substantial portion of each quarter’s sales orders and generated a substantial portion of each quarter’s billings and revenue during the last two weeks of the quarter. If we experience significant changes in our billings growth rates, it will impact current quarter product revenue and future quarters of our FortiGuard and FortiCare service revenues, as we sell annual and multi-year service contracts that are recognized ratably over the service term. In addition, the broader implications of the pandemic on our business and operations and our financial results, including the extent to which the effects of the pandemic will impact future results and growth in the cybersecurity industry, remain uncertain. The duration and severity of the economic downturn from the pandemic may negatively impact our business and operations, results of operations, financial condition, cash flows, liquidity and capital and financial resources in a material way. As a result, the effects of the pandemic may not be fully reflected in our results of operations until future periods. For further discussion, see Part II, Item 1A of this Quarterly Report on Form 10-Q.

[0001262039-20-000032:mdna:54]
[same as prior period, unchanged from 0001262039-19-000033:mdna:46]

[0001262039-20-000032:mdna:55]
We primarily sell our products and services through a two-tier distribution model. We sell to distributors that sell to networking security and enterprise-focused resellers and to service providers and managed security service providers (“MSSPs”), who, in turn, sell to our end-customers. In certain cases, we sell directly to large service providers and major systems integrators. We also offer our products through major cloud providers, and have recognized on-demand revenue from Amazon Web Services, Microsoft Azure, IBM Cloud, Google Cloud and Oracle Cloud. We have also recognized revenue from customers who deploy our products in a bring-your-own-license (“BYOL”) arrangement in private clouds or at cloud providers such as Amazon Web Services, Microsoft Azure, Google Cloud, Oracle Cloud and Alibaba Cloud. In a BYOL arrangement, a customer purchases a software license from us through our channel partners and deploys the software in a cloud provider’s environment. Similarly, customers may purchase such a license from us and deploy in their private cloud.

[0001262039-20-000032:mdna:56]
Our customers purchase our hardware products and software licenses, as well as our FortiGuard security subscription and FortiCare technical support services. We generally invoice at the time of our sale for the total price of the products and security and technical support services. The invoice is typically payable within 30 to 60 days. We also invoice certain services on a monthly basis.

[0001262039-20-000032:mdna:57]
[same as prior period, unchanged from 0001262039-19-000033:mdna:49]

[0001262039-20-000032:mdna:58]
We monitor a number of key metrics, including the key financial metrics set forth below, in order to help us evaluate growth trends, establish budgets, measure the effectiveness of our sales and marketing efforts, and assess operational

[0001262039-20-000032:mdna:59]
25

[0001262039-20-000032:mdna:60]
efficiencies. The following table summarizes revenue, deferred revenue, billings (non-GAAP), net cash provided by operating activities, and free cash flow (non-GAAP). We discuss revenue below under “Results of Operations,” and we discuss net cash provided by operating activities below under “—Liquidity and Capital Resources.” Deferred revenue, billings (non-GAAP), and free cash flow (non-GAAP) are discussed immediately below the following table:

[0001262039-20-000032:mdna:61]
|  | Three Months Ended Or As Of |
|  | March 31, 2020 |  | March 31, 2019 |
|  | (in millions) |
| Revenue | $ | 576.9 |  |  | $ | 472.6 |  |
| Deferred revenue | $ | 2,226.8 |  |  | $ | 1,765.8 |  |
| Billings (non-GAAP) | $ | 667.8 |  |  | $ | 551.6 |  |
| Net cash provided by operating activities | $ | 319.4 |  |  | $ | 201.3 |  |
| Free cash flow (non-GAAP) | $ | 241.8 |  |  | $ | 191.1 |  |

[0001262039-20-000032:mdna:62]
Deferred revenue. Our deferred revenue consists of amounts that have been invoiced but that have not yet been recognized as revenue. The majority of our deferred revenue balance consists of the unrecognized portion of service revenue from FortiGuard security subscription and FortiCare technical support service contracts, which is recognized as revenue ratably over the contractual service period. We monitor our deferred revenue balance, deferred revenue growth and the mix of short-term and long-term deferred revenue because deferred revenue represents a significant portion of free cash flow and of revenue to be recognized in future periods. Deferred revenue was $2.23 billion as of March 31, 2020, an increase of $90.9 million, or 4%, from December 31, 2019.

[0001262039-20-000032:mdna:63]
Billings (non-GAAP). We define billings as revenue recognized in accordance with GAAP plus the change in deferred revenue from the beginning to the end of the period, less any deferred revenue balances acquired from business combination(s) during the period. We consider billings to be a useful metric for management and investors because billings drive current and future revenue, which is an important indicator of the health and viability of our business. There are a number of limitations related to the use of billings instead of GAAP revenue. First, billings include amounts that have not yet been recognized as revenue and are impacted by the term of security and support agreements. Second, we may calculate billings in a manner that is different from peer companies that report similar financial measures. Management accounts for these limitations by providing specific information regarding GAAP revenue and evaluating billings together with GAAP revenue. Total billings were $667.8 million for the three months ended March 31, 2020, an increase of 21% compared to $551.6 million in the same period last year.

[0001262039-20-000032:mdna:64]
[same as prior period, unchanged from 0001262039-19-000033:mdna:54]

[0001262039-20-000032:mdna:65]
|  | Three Months Ended |
|  | March 31, 2020 |  | March 31, 2019 |
|  | (in millions) |
| Billings: |  |  |  |
| Revenue | $ | 576.9 |  |  | $ | 472.6 |  |
| Add: Change in deferred revenue | 90.9 |  |  | 79.0 |  |
| Total billings (non-GAAP) | $ | 667.8 |  |  | $ | 551.6 |  |

[0001262039-20-000032:mdna:66]
Free cash flow (non-GAAP). We define free cash flow as net cash provided by operating activities minus purchases of property and equipment and excluding any significant non-recurring items, such as proceeds from IP matter. We believe free cash flow to be a liquidity measure that provides useful information to management and investors about the amount of cash generated by the business that, after capital expenditures and net of proceeds from IP matter, can be used for strategic opportunities, including repurchasing outstanding common stock, investing in our business, making strategic acquisitions and strengthening the balance sheet. A limitation of using free cash flow rather than the GAAP measures of cash provided by or used in operating activities, investing activities, and financing activities is that free cash flow does not represent the total increase or decrease in the cash and cash equivalents balance for the period because it excludes proceeds from IP matter, cash flows from investing activities other than capital expenditures and cash flows from financing activities. Management accounts

[0001262039-20-000032:mdna:67]
[same as prior period, unchanged from 0001262039-19-000033:mdna:34]

[0001262039-20-000032:mdna:68]
for this limitation by providing information about our proceeds from IP matter, our capital expenditures and other investing and financing activities on the face of the consolidated statements of cash flows and under “—Liquidity and Capital Resources” and by presenting cash flows from investing and financing activities in our reconciliation of free cash flow. In addition, it is important to note that other companies, including companies in our industry, may not use free cash flow, may calculate free cash flow in a different manner than we do or may use other financial measures to evaluate their performance, all of which could reduce the usefulness of free cash flow as a comparative measure. A reconciliation of net cash provided by operating activities, the most directly comparable financial measure calculated and presented in accordance with GAAP, to free cash flow is provided below:

[0001262039-20-000032:mdna:69]
|  | Three Months Ended |
|  | March 31, 2020 |  | March 31, 2019 |
|  | (in millions) |
| Free Cash Flow: |  |  |  |
| Net cash provided by operating activities | $ | 319.4 |  |  | $ | 201.3 |  |
| Less: Purchases of property and equipment | (27.6 | ) |  | (10.2 | ) |
| Less: Proceeds from IP matter | (50.0 | ) |  | — |  |
| Free cash flow (non-GAAP) | $ | 241.8 |  |  | $ | 191.1 |  |
| Net cash provided by (used in) investing activities | $ | 4.6 |  |  | $ | (39.0 | ) |
| Net cash used in financing activities | $ | (920.4 | ) |  | $ | (57.8 | ) |

[0001262039-20-000032:mdna:70]
[same as prior period, unchanged from 0001262039-19-000033:mdna:59]

[0001262039-20-000032:mdna:71]
[same as prior period, unchanged from 0001262039-19-000033:mdna:60]

[0001262039-20-000032:mdna:72]
There were no material changes to our critical accounting policies and estimates as of and for the three months ended March 31, 2020, as compared to the critical accounting policies and estimates described in our Annual Report on Form 10-K filed with the SEC on February 26, 2020 (the “Form 10-K”).

[0001262039-20-000032:mdna:73]
[same as prior period, unchanged from 0001262039-19-000033:mdna:62]

[0001262039-20-000032:mdna:74]
[same as prior period, unchanged from 0001262039-19-000033:mdna:63]

[0001262039-20-000032:mdna:75]
[same as prior period, unchanged from 0001262039-19-000033:mdna:64]

[0001262039-20-000032:mdna:76]
Three Months Ended March 31, 2020 and March 31, 2019

[0001262039-20-000032:mdna:77]
[same as prior period, unchanged from 0001262039-19-000033:mdna:66]

[0001262039-20-000032:mdna:78]
|  | Three Months Ended |  |  |  |  |
| March 31, 2020 |  | March 31, 2019 |  |  |  |  |
| Amount |  | % ofRevenue |  | Amount |  | % ofRevenue |  | Change |  | % Change |
| (in millions, except percentages) |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 192.3 |  |  | 33 | % |  | $ | 162.7 |  |  | 34 | % |  | $ | 29.6 |  |  | 18 | % |
| Service | 384.6 |  |  | 67 |  |  | 309.9 |  |  | 66 |  |  | 74.7 |  |  | 24 |  |
| Total revenue | $ | 576.9 |  |  | 100 | % |  | $ | 472.6 |  |  | 100 | % |  | $ | 104.3 |  |  | 22 | % |
| Revenue by geography: |  |  |  |  |  |  |  |  |  |  |  |
| Americas | $ | 242.2 |  |  | 42 | % |  | $ | 200.5 |  |  | 42 | % |  | $ | 41.7 |  |  | 21 | % |
| Europe, Middle East and Africa (“EMEA”) | 220.7 |  |  | 38 |  |  | 177.2 |  |  | 38 |  |  | 43.5 |  |  | 25 |  |
| Asia Pacific (“APAC”) | 114.0 |  |  | 20 |  |  | 94.9 |  |  | 20 |  |  | 19.1 |  |  | 20 |  |
| Total revenue | $ | 576.9 |  |  | 100 | % |  | $ | 472.6 |  |  | 100 | % |  | $ | 104.3 |  |  | 22 | % |

[0001262039-20-000032:mdna:79]
Total revenue increased by $104.3 million, or 22%, during the three months ended March 31, 2020 compared to the same period last year. We continued to experience diversification of revenue globally and across both customer and industry segments. Revenue from all regions grew, with EMEA contributing the largest portion of our revenue growth on a percentage basis and on an absolute dollar basis.

[0001262039-20-000032:mdna:80]
Product revenue increased by $29.6 million, or 18%, during the three months ended March 31, 2020 compared to the same period last year. We experienced revenue growth across many of our hardware and software products due to an increase in product revenue from our FortiGate solutions, including SD-WAN, growth in sales of our Infrastructure Security solutions and teleworker and remote security solutions.

[0001262039-20-000032:mdna:81]
Service revenue increased by $74.7 million, or 24%, during the three months ended March 31, 2020 compared to the same period last year. FortiGuard security subscription and FortiCare technical support and other revenues increased by $41.8 million, or 25%, and by $32.9 million, or 23%, respectively, during the three months ended March 31, 2020 compared to the same period last year. The increases were primarily due to the recognition of revenue from our growing deferred revenue balance related to FortiGuard and other security subscriptions and FortiCare technical support, including our customers moving to higher-tier support offerings. Of the service revenue recognized during the three months ended March 31, 2020, 91% was included in the deferred revenue balance as of December 31, 2019.

[0001262039-20-000032:mdna:82]
[same as prior period, unchanged from 0001262039-19-000033:mdna:71]

[0001262039-20-000032:mdna:83]
|  | Three Months Ended |  |  |  |  |
| March 31, 2020 |  | March 31, 2019 |  | Change |  | % Change |
| (in millions, except percentages) |
| Cost of revenue: |  |  |  |  |  |  |  |
| Product | $ | 76.3 |  |  | $ | 70.2 |  |  | $ | 6.1 |  |  | 9 | % |
| Service | 52.4 |  |  | 42.8 |  |  | 9.6 |  |  | 22 |  |
| Total cost of revenue | $ | 128.7 |  |  | $ | 113.0 |  |  | $ | 15.7 |  |  | 14 | % |
| Gross margin (%): |  |  |  |  |  |  |  |
| Product | 60.3 | % |  | 56.9 | % |  |  |  |  |
| Service | 86.4 |  |  | 86.2 |  |  |  |  |  |
| Total gross margin | 77.7 | % |  | 76.1 | % |  |  |  |  |

[0001262039-20-000032:mdna:84]
Total gross margin increased by 1.6 percentage points during the three months ended March 31, 2020 compared to the same period last year, driven by improvements to both product and service gross margins.

[0001262039-20-000032:mdna:85]
Product gross margin increased by 3.4 percentage points during the three months ended March 31, 2020 compared to the same period last year. Product gross margin benefited from increased software sales and lower indirect costs of hardware as a percentage of product revenue. Cost of product revenue was comprised primarily of third party contract manufacturers’ costs and the costs of materials used in production.

[0001262039-20-000032:mdna:86]
Service gross margin increased by 0.2 percentage points during the three months ended March 31, 2020 compared to the same period last year, as our service revenue growth outpaced our growth in related personnel costs. Cost of service revenue was comprised primarily of personnel costs.

[0001262039-20-000032:mdna:87]
[same as prior period, unchanged from 0001262039-19-000033:mdna:76]

[0001262039-20-000032:mdna:88]
|  | Three Months Ended |  | Change |  | % Change |
| March 31, 2020 |  | March 31, 2019 |  |
| Amount |  | % ofRevenue |  | Amount |  | % ofRevenue |  |
| (in millions, except percentages) |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | $ | 80.3 |  |  | 14% |  | $ | 68.6 |  |  | 14 | % |  | $ | 11.7 |  |  | 17 | % |
| Sales and marketing | 260.0 |  |  | 45 |  | 215.9 |  |  | 46 |  |  | 44.1 |  |  | 20 |  |
| General and administrative | 28.8 |  |  | 5 |  | 24.5 |  |  | 5 |  |  | 4.3 |  |  | 18 |  |
| Gain on IP matter | (36.8 | ) |  | (6) |  | — |  |  | — |  |  | (36.8 | ) |  | * |  |
| Total operating expenses | $ | 332.3 |  |  | 58% |  | $ | 309.0 |  |  | 65 | % |  | $ | 23.3 |  |  | 8 | % |

[0001262039-20-000032:mdna:89]
Percentages have been rounded for presentation purposes and may differ from unrounded results.

[0001262039-20-000032:mdna:90]
* Not meaningful

[0001262039-20-000032:mdna:91]
[same as prior period, unchanged from 0001262039-19-000033:mdna:78]

[0001262039-20-000032:mdna:92]
Research and development expense increased by $11.7 million, or 17%, during the three months ended March 31, 2020 compared to the same period last year, primarily due to an increase of $11.6 million in personnel-related costs as a result of increased headcount to support the development of new products, continued enhancements to our existing products and patent creation. We currently intend to continue to invest in our research and development organization, and expect research and development expense to remain at or increase in absolute dollars during the remainder of 2020.

[0001262039-20-000032:mdna:93]
[same as prior period, unchanged from 0001262039-19-000033:mdna:80]

[0001262039-20-000032:mdna:94]
Sales and marketing expense increased by $44.1 million, or 20%, during the three months ended March 31, 2020 compared to the same period last year, primarily due to an increase of $37.9 million in personnel-related costs as a result of increases to sales and marketing headcount in order to drive global market share gains. This increase was offset by savings related to decreased travel in the first quarter of 2020 as a response to the COVID-19 pandemic. We currently intend to continue to make investments in our sales resources and infrastructure and marketing strategy, which are critical to support our future growth, and expect sales and marketing expense to remain at or increase in absolute dollars during the remainder of 2020.

[0001262039-20-000032:mdna:95]
[same as prior period, unchanged from 0001262039-19-000033:mdna:83]

[0001262039-20-000032:mdna:96]
General and administrative expense increased by $4.3 million, or 18%, during the three months ended March 31, 2020 compared to the same period last year, primarily due to an increase in personnel-related costs of $2.4 million and an increase in professional services costs of $1.2 million. We currently expect general and administrative expense to remain at or increase in absolute dollars during the remainder of 2020.

[0001262039-20-000032:mdna:97]
Gain on IP matter

[0001262039-20-000032:mdna:98]
In January 2020, we entered into an agreement with a competitor in the network security industry, whereby, in February 2020, the competitor party paid us a lump sum of $50.0 million for a seven-year mutual covenant-not-to-sue for patent claims. Pursuant to this agreement, at the end of this first seven-year period, either party may extend the agreement for an additional seven-year mutual covenant-not-to-sue in return for this competitor paying us an additional $50.0 million. We determined the agreement to be a 14-year contract with a total transaction price of $100.0 million. During the three months ended March 31, 2020, we recorded $36.0 million upfront and an additional $0.8 million in amortization of the deferred component as a gain on IP matter in our condensed consolidated statements of income. See Note 10 of the notes to condensed consolidated financial statements included in Part I, Item 1 of this Quarterly Report on Form 10-Q for additional information regarding the gain on IP matter.

[0001262039-20-000032:mdna:99]
Operating income and margin

[0001262039-20-000032:mdna:100]
We generated operating income of $115.9 million during the three months ended March 31, 2020, an increase of $65.3 million, or 129%, compared to $50.6 million in the same period last year. Operating income as a percentage of revenue increased to 20% during the three months ended March 31, 2020 compared to 11% in the same period last year. The increase in operating margin is primarily due to the $36.8 million gain on IP matter, combined with the improvement in gross margin of 1.6 percentage points.

[0001262039-20-000032:mdna:101]
Interest income—net and other expense—net

[0001262039-20-000032:mdna:102]
|  | Three Months Ended |  |  |  |  |
| March 31, 2020 |  | March 31, 2019 |  | Change |  | % Change |
| (in millions, except percentages) |
| Interest income—net | $ | 9.2 |  |  | $ | 10.2 |  |  | $ | (1.0 | ) |  | (10 | )% |
| Other expense—net | $ | (8.0 | ) |  | $ | (0.5 | ) |  | $ | (7.5 | ) |  | 1,500 | % |

[0001262039-20-000032:mdna:103]
Interest income—net decreased during the three months ended March 31, 2020 compared to the same period last year, primarily due to lower interest rates and, to a lesser extent, lower invested balances of cash, cash equivalents and investments. The lower cash, cash equivalents and investments were mainly due to our $889.9 million payment for repurchase and retirement of common stock under the Repurchase Program in the three months ended March 31, 2020. Interest income—net varies depending on our average investment balances during the period, types and mix of investments, and market interest rates. The change in other expense—net during the three months ended March 31, 2020 compared to the same period last year was the result of a $4.3 million impairment charge on an investment in a privately held company during the first quarter of 2020. In addition, foreign currency exchange losses increased by $3.1 million compared to the same period last year.

[0001262039-20-000032:mdna:104]
[same as prior period, unchanged from 0001262039-19-000033:mdna:88]

[0001262039-20-000032:mdna:105]
|  | Three Months Ended |  | Change |  | % Change |
| March 31, 2020 |  | March 31, 2019 |  |
| (in millions, except percentages) |
| Provision for income taxes | $ | 13.1 |  |  | $ | 1.5 |  |  | $ | 11.6 |  |  | 773 | % |
| Effective tax rate (%) | 11 | % |  | 2 | % |  |  |  |  |  |  |

[0001262039-20-000032:mdna:106]
Our effective tax rate was 11% for the three months ended March 31, 2020 compared to an effective tax rate of 2% for the same period last year. The provision for income taxes for the three months ended March 31, 2020 was primarily comprised of U.S. federal and state taxes, withholding taxes and foreign taxes that were $28.3 million, which included a tax benefit of $4.8 million from the foreign-derived intangible income deduction. This tax provision for income taxes was further offset by excess tax benefits from stock-based compensation expense of $15.2 million. The provision for income taxes for the three months ended March 31, 2019 was comprised of U.S. federal and state taxes, withholding taxes, and foreign taxes that were $17.5 million, which were offset by excess tax benefits from stock-based compensation expense of $16.0 million.

[0001262039-20-000032:mdna:107]
[same as prior period, unchanged from 0001262039-19-000033:mdna:117]

[0001262039-20-000032:mdna:108]
|  | As of |
|  | March 31, 2020 |  | December 31, 2019 |
|  | (in millions) |
| Cash and cash equivalents | $ | 626.1 |  |  | $ | 1,222.5 |  |
| Investments | 947.2 |  |  | 987.4 |  |
| Total cash, cash equivalents and investments | $ | 1,573.3 |  |  | $ | 2,209.9 |  |
| Working capital | $ | 492.3 |  |  | $ | 1,295.4 |  |
|  | Three Months Ended |
|  | March 31, 2020 |  | March 31, 2019 |
|  | (in millions) |
| Net cash provided by operating activities | $ | 319.4 |  |  | $ | 201.3 |  |
| Net cash provided by (used in) investing activities | 4.6 |  |  | (39.0 | ) |
| Net cash used in financing activities | (920.4 | ) |  | (57.8 | ) |
| Net increase in cash and cash equivalents | $ | (596.4 | ) |  | $ | 104.5 |  |

[0001262039-20-000032:mdna:109]
Liquidity and capital resources may be impacted by our operating activities, as well as by our stock repurchases, proceeds associated with stock option exercises, issuances of common stock under our the Amended and Restated Fortinet, Inc. 2009 Equity Incentive Plan (the “Amended Plan”) and payment of taxes in connection with the net settlement of equity awards, real estate and other capital expenditures and business acquisitions. During the three months ended March 31, 2020, we repurchased $899.9 million in shares of our common stock under the Repurchase Program. In February 2020, we received a cash payment of $50.0 million pursuant to a mutual covenant-not-to-sue and release agreement with a competitor in the network security industry.

[0001262039-20-000032:mdna:110]
In recent years, we have received significant capital resources from our billings to customers and, to some extent, from exercise of stock options. Additional increases in billings may depend on a number of factors, including demand for our products and services, competition, market or industry changes, macroeconomic events such as the COVID-19 pandemic and our ability to execute. We expect proceeds from the exercise of stock options in future years to be impacted by the increased mix of restricted stock units versus stock options granted and also to vary based on our share price. As of March 31, 2020, $692.9 million remained available for future share repurchases under the Repurchase Program.

[0001262039-20-000032:mdna:111]
Construction of a second building at our headquarters campus started in the fourth quarter of 2018 and related spending will continue in 2020 and until project completion. We estimate 2020 spending on the headquarters campus project to

[0001262039-20-000032:mdna:112]
be between $110.0 million and $120.0 million dollars. The COVID-19 pandemic has resulted in a delay to the project schedule. We now estimate construction to be completed in early 2021.

[0001262039-20-000032:mdna:113]
As of March 31, 2020, our cash, cash equivalents and investments of $1.57 billion were invested primarily in deposit accounts, money market funds, corporate debt securities, commercial paper, certificates of deposit and term deposits and U.S. government securities. It is our investment policy to invest excess cash in a manner that preserves capital, provides liquidity and generates return without significantly increasing risk. We do not enter into investments for trading or speculative purposes.

[0001262039-20-000032:mdna:114]
The amount of cash, cash equivalents and investments held by our international subsidiaries was $116.8 million as of March 31, 2020 and $109.3 million as of December 31, 2019.

[0001262039-20-000032:mdna:115]
We believe that our existing cash and cash equivalents will be sufficient to meet our anticipated cash needs for at least the next 12 months. Our future capital requirements will depend on many factors, including our growth rate, the timing and amount of our share repurchases, the timing and extent of spending to support development efforts, the expansion of sales and marketing activities, the introduction of new and enhanced products and services offerings, the continuing market acceptance of our products, our investments in purchasing or leasing real estate and macroeconomic impacts such as the COVID-19 pandemic. Historically, we have required capital principally to fund our working capital needs, share repurchases, capital expenditures and acquisition activities. In the event that additional financing is required from outside sources, we may not be able to raise it on terms acceptable to us or at all.

[0001262039-20-000032:mdna:116]
[same as prior period, unchanged from 0001262039-19-000033:mdna:126]

[0001262039-20-000032:mdna:117]
Cash generated by operating activities is our primary source of liquidity. It is primarily comprised of net income, as adjusted for non-cash items and changes in operating assets and liabilities. Non-cash adjustments consist primarily of stock-based compensation, amortization of deferred contract costs and depreciation and amortization. Changes in operating assets and liabilities consist primarily of changes in deferred revenue, deferred contract costs, accounts receivable, inventory and prepaid expenses and other current assets.

[0001262039-20-000032:mdna:118]
Our operating activities during the three months ended March 31, 2020 provided $319.4 million in cash as a result of the continued growth of our business and our ability to successfully manage our working capital. Changes in operating assets and liabilities primarily resulted from an increase in sales of our FortiGuard security subscription and FortiCare technical support services to new and existing customers, as reflected by an increase in our deferred revenue, and proceeds from the mutual covenant-not-to-sue and release agreement. Our total deferred revenue balance grew $90.9 million, or 4%, during the three months ended March 31, 2020.

[0001262039-20-000032:mdna:119]
[same as prior period, unchanged from 0001262039-19-000033:mdna:130]

[0001262039-20-000032:mdna:120]
The changes in cash flows from investing activities primarily relate to timing of purchases, maturities and sales of investments and purchases of property and equipment. Historically, in making a lease versus ownership decision related to our larger facilities, we have considered various factors including financial metrics and the impact on our engineers and other employees. In certain cases, we have elected to own a facility if we believed that ownership rather than leasing is more in line with our long-term strategy. We expect to make similar decisions in the future. We may also make cash payments in connection with future business combinations.

[0001262039-20-000032:mdna:121]
During the three months ended March 31, 2020, cash provided by investing activities was $4.6 million, primarily driven by $35.7 million in cash proceeds from maturities and sales of investments, net of purchases of investments, and partially offset by $27.6 million of purchases of property and equipment, a large portion of which relates to our headquarters building construction.

[0001262039-20-000032:mdna:122]
[same as prior period, unchanged from 0001262039-19-000033:mdna:135]

[0001262039-20-000032:mdna:123]
The changes in cash flows from financing activities primarily relate to repurchase and retirement of common stock and taxes paid related to net share settlement of equity awards, net of proceeds from the issuance of common stock under the Amended Plan.

[0001262039-20-000032:mdna:124]
During the three months ended March 31, 2020, cash used in financing activities was $920.4 million, primarily driven by $889.9 million used to repurchase shares of our common stock and $30.4 million used to pay tax withholding, net of proceeds from the issuance of common stock.

[0001262039-20-000032:mdna:125]
[same as prior period, unchanged from 0001262039-19-000033:mdna:139]

[0001262039-20-000032:mdna:126]
There were no material changes outside the ordinary course of business during the three months ended March 31, 2020 to the contractual obligations and commitments disclosed in Management’s Discussion and Analysis of Financial Condition and Results of Operations, set forth in Part II, Item 7, of the Form 10-K. See Note 11 of the notes to condensed consolidated financial statements included in Part I, Item 1 of this Quarterly Report on Form 10-Q for additional information regarding contractual obligations and commitments.

[0001262039-20-000032:mdna:127]
[same as prior period, unchanged from 0001262039-19-000033:mdna:141]

[0001262039-20-000032:mdna:128]
As of March 31, 2020, we did not have any relationships with unconsolidated organizations or financial partnerships, such as structured finance or special purpose entities that would have been established for the purpose of facilitating off-balance sheet arrangements or other contractually narrow or limited purposes.
