# FTNT 8-K — 0001262039-24-000040 filed 2024-11-07

## item codes, every 8-K on or before 2024-11-08

- 2024-11-07 0001262039-24-000040 — 2.02, 9.01
- 2024-08-07 0001262039-24-000034 — 2.02, 9.01 — amendment of 0001262039-24-000032
- 2024-08-06 0001262039-24-000032 — 2.02, 9.01
- 2024-07-24 0001262039-24-000028 — 5.02 — amendment, the index does not say of what
- 2024-06-20 0001262039-24-000025 — 5.07
- 2024-05-02 0001262039-24-000017 — 2.02, 9.01
- 2024-02-23 0001262039-24-000011 — 5.02, 9.01
- 2024-02-06 0001262039-24-000006 — 2.02, 9.01
- 2024-01-18 0001262039-24-000003 — 5.02
- 2023-12-01 0001262039-23-000041 — 5.02
- 2023-11-02 0001262039-23-000035 — 2.02, 9.01
- 2023-08-03 0001262039-23-000027 — 2.02, 9.01
- 2023-06-23 0001262039-23-000024 — 5.03, 5.07, 9.01
- 2023-05-04 0001262039-23-000013 — 2.02, 9.01
- 2023-02-08 0001262039-23-000006 — 5.03, 9.01
- 2023-02-07 0001262039-23-000003 — 2.02, 9.01
- 2022-11-02 0001262039-22-000035 — 2.02, 9.01
- 2022-08-03 0001262039-22-000026 — 2.02, 9.01
- 2022-06-22 0001262039-22-000023 — 5.03, 9.01
- 2022-06-21 0001262039-22-000021 — 5.07
- 2022-05-04 0001262039-22-000015 — 2.02, 9.01
- 2022-05-02 0001262039-22-000012 — 5.02
- 2022-04-22 0001262039-22-000010 — 8.01
- 2022-02-03 0001262039-22-000005 — 2.02, 9.01
- 2022-01-26 0001262039-22-000002 — 5.02, 9.01 — amendment, the index does not say of what
- 2021-11-04 0001262039-21-000027 — 2.02, 9.01
- 2021-10-06 0001262039-21-000024 — 5.02, 9.01
- 2021-07-29 0001262039-21-000019 — 2.02, 9.01
- 2021-06-23 0001262039-21-000016 — 5.07
- 2021-04-30 0001104659-21-059008 — 5.03 — amendment, the index does not say of what
- 2021-04-29 0001262039-21-000011 — 2.02, 9.01
- 2021-04-28 0001104659-21-056360 — 5.02, 5.03, 9.01
- 2021-03-05 0001193125-21-071498 — 1.01, 9.01
- 2021-02-25 0001193125-21-057281 — 1.01, 9.01
- 2021-02-04 0001262039-21-000005 — 2.02, 9.01
- 2020-12-08 0001262039-20-000070 — 8.01
- 2020-10-29 0001262039-20-000063 — 2.02, 9.01
- 2020-10-20 0001262039-20-000060 — 5.02 — amendment, the index does not say of what
- 2020-08-26 0001262039-20-000056 — 5.02, 9.01
- 2020-08-06 0001262039-20-000051 — 2.02, 9.01
- 2020-07-21 0001262039-20-000044 — 5.03, 8.01, 9.01
- 2020-06-24 0001262039-20-000038 — 5.07
- 2020-05-06 0001262039-20-000029 — 2.02, 9.01
- 2020-04-23 0001262039-20-000025 — 5.03, 9.01
- 2020-04-23 0001262039-20-000024 — 5.02 — amendment of 0001262039-20-000025
- 2020-02-28 0001262039-20-000015 — 5.02, 9.01
- 2020-02-06 0001262039-20-000004 — 2.02, 9.01
- 2019-12-12 0001262039-19-000038 — 8.01
- 2019-10-31 0001262039-19-000032 — 2.02, 9.01
- 2019-10-28 0001262039-19-000027 — 8.01
- 2019-10-23 0001262039-19-000025 — 5.02, 9.01
- 2019-08-01 0001262039-19-000021 — 2.02, 9.01
- 2019-06-26 0001262039-19-000018 — 5.07
- 2019-05-02 0001262039-19-000010 — 2.02, 9.01
- 2019-02-06 0001262039-19-000002 — 2.02, 9.01
- 2018-11-01 0001262039-18-000037 — 2.02, 9.01
- 2018-10-23 0001262039-18-000035 — 8.01
- 2018-08-01 0001262039-18-000025 — 2.02, 9.01
- 2018-06-28 0001262039-18-000023 — 5.03, 5.07, 9.01
- 2018-06-04 0001262039-18-000021 — 8.01
- 2018-05-03 0001262039-18-000017 — 2.02, 5.02, 9.01
- 2018-02-05 0001262039-18-000004 — 2.02, 5.02, 9.01
- 2017-10-26 0001262039-17-000031 — 2.02, 9.01
- 2017-10-19 0001262039-17-000029 — 5.02 — amendment, the index does not say of what
- 2017-07-26 0001262039-17-000025 — 2.02, 9.01
- 2017-06-27 0001262039-17-000023 — 5.07
- 2017-05-31 0001262039-17-000021 — 5.02 — amendment of 0001262039-17-000019
- 2017-05-30 0001262039-17-000019 — 5.02, 9.01
- 2017-04-27 0001262039-17-000013 — 2.02, 9.01
- 2017-02-02 0001262039-17-000003 — 2.02, 9.01
- 2016-10-27 0001262039-16-000085 — 2.02, 9.01
- 2016-10-11 0001262039-16-000082 — 2.02, 9.01
- 2016-07-28 0001262039-16-000076 — 2.02, 9.01
- 2016-07-22 0001262039-16-000073 — 8.01, 9.01
- 2016-06-20 0001262039-16-000068 — 5.07
- 2016-06-07 0001193125-16-614788 — 8.01
- 2016-04-26 0001262039-16-000061 — 2.02, 9.01
- 2016-01-28 0001262039-16-000051 — 2.02, 9.01
- 2015-10-27 0001262039-15-000045 — 2.02
- 2015-10-22 0001262039-15-000042 — 5.02 — amendment, the index does not say of what
- 2015-10-22 0001262039-15-000041 — 5.02 — amendment, the index does not say of what
- 2015-10-22 0001262039-15-000039 — 2.02, 9.01
- 2015-09-28 0001262039-15-000034 — 5.02, 9.01
- 2015-09-22 0001262039-15-000031 — 9.01 — amendment of 0001193125-15-248065
- 2015-08-28 0001262039-15-000027 — 3.01, 5.02
- 2015-07-23 0001262039-15-000021 — 5.02
- 2015-07-22 0001262039-15-000019 — 2.02, 9.01
- 2015-07-08 0001193125-15-248065 — 2.01, 8.01, 9.01
- 2015-06-22 0001193125-15-229099 — 5.07
- 2015-06-19 0001193125-15-228428 — 5.02, 9.01
- 2015-04-20 0001262039-15-000014 — 2.02, 9.01
- 2015-01-28 0001262039-15-000005 — 2.02, 9.01
- 2014-10-22 0001262039-14-000036 — 2.02, 9.01
- 2014-07-23 0001262039-14-000030 — 2.02, 9.01
- 2014-06-24 0001262039-14-000027 — 5.07
- 2014-04-23 0001262039-14-000021 — 2.02, 9.01
- 2014-04-21 0001262039-14-000018 — 5.03, 9.01
- 2014-01-29 0001262039-14-000004 — 2.02, 9.01
- 2013-12-20 0001262039-13-000061 — 5.02, 9.01
- 2013-11-27 0001262039-13-000057 — 5.02, 7.01, 9.01
- 2013-11-12 0001445305-13-002993 — 5.02
- 2013-10-23 0001262039-13-000051 — 2.02, 9.01
- 2013-07-30 0001262039-13-000039 — 2.02, 9.01
- 2013-06-25 0001262039-13-000030 — 5.07
- 2013-04-30 0001262039-13-000023 — 2.02, 9.01
- 2013-04-19 0001262039-13-000020 — 5.02, 9.01
- 2013-04-19 0001262039-13-000018 — 5.02 — amendment of 0001262039-13-000020
- 2013-04-10 0001262039-13-000016 — 2.02, 9.01
- 2013-03-26 0001262039-13-000013 — 5.02
- 2013-01-30 0001262039-13-000005 — 2.02, 9.01
- 2013-01-24 0001262039-13-000002 — 5.02, 9.01
- 2012-10-16 0001262039-12-000048 — 2.02, 9.01
- 2012-10-01 0001262039-12-000045 — 5.02
- 2012-09-26 0001262039-12-000043 — 5.01
- 2012-07-25 0001262039-12-000038 — 2.02, 9.01
- 2012-07-19 0001262039-12-000034 — 5.02
- 2012-06-20 0001193125-12-275869 — 5.07
- 2012-04-27 0001262039-12-000029 — 5.02
- 2012-04-24 0001262039-12-000025 — 2.02, 9.01
- 2012-01-31 0001262039-12-000006 — 2.02, 9.01
- 2012-01-25 0001262039-12-000003 — 5.03
- 2011-10-24 0001262039-11-000036 — 2.02
- 2011-07-19 0001262039-11-000014 — 2.02, 9.01
- 2011-06-27 0001193125-11-174474 — 5.02, 5.07, 9.01
- 2011-04-27 0001193125-11-111938 — 2.02, 9.01
- 2011-01-25 0001193125-11-013914 — 2.02, 9.01
- 2010-10-21 0001193125-10-233676 — 2.02, 9.01
- 2010-09-02 0001193125-10-203099 — 8.01
- 2010-07-22 0001193125-10-163844 — 2.02, 9.01
- 2010-06-24 0001193125-10-146082 — 5.07
- 2010-04-28 0001193125-10-096698 — 2.02, 9.01
- 2010-02-09 0001193125-10-024614 — 8.01
- 2010-01-27 0001193125-10-014292 — 2.02, 9.01
- 2010-01-26 0001193125-10-013031 — 5.02, 9.01

## late-filing notifications on or before 2024-11-08

- none on or before 2024-11-08

## item 2.02 — earnings release, exhibit 99.1

[0001262039-24-000040:8k_2_02:1]
EX-99.1
2
ftntq3-2024ex991.htm
PRESS RELEASE

[0001262039-24-000040:8k_2_02:2]
Document

[0001262039-24-000040:8k_2_02:3]
Press Release

[0001262039-24-000040:8k_2_02:4]
Fortinet Reports Third Quarter 2024 Financial Results

[0001262039-24-000040:8k_2_02:5]
Highlights

[0001262039-24-000040:8k_2_02:6]
•Total revenue up 13% year over year; service revenue up 19% year over year

[0001262039-24-000040:8k_2_02:7]
•Billings1 and product revenue returns to growth

[0001262039-24-000040:8k_2_02:8]
•Strong billings growth in Unified SASE and Security Operations

[0001262039-24-000040:8k_2_02:9]
•Record GAAP operating margin of 31.2%

[0001262039-24-000040:8k_2_02:10]
•Record Non-GAAP operating margin of 36.1%1

[0001262039-24-000040:8k_2_02:11]
•Cash flow from operations of $608 million; Free cash flow of $572 million1

[0001262039-24-000040:8k_2_02:12]
•Raising 2024 revenue and non-GAAP operating margin guidance

[0001262039-24-000040:8k_2_02:13]
•Share repurchase authorization increased by $1 billion; remaining authorization of $2 billion

[0001262039-24-000040:8k_2_02:14]
SUNNYVALE, Calif. - November 7, 2024 - Fortinet® (Nasdaq: FTNT), a global cybersecurity leader driving the convergence of networking and security, today announced financial results for the third quarter ended September 30, 2024.

[0001262039-24-000040:8k_2_02:15]
“We are pleased to report another strong quarter as non-GAAP operating margin increased 830 basis points year over year to a company record of 36%, while revenue exceeded the high end of our guidance range, with growth of 13% year over year,” said Ken Xie, Founder, Chairman and Chief Executive Officer of Fortinet. “Our investments in the fast-growing markets of Unified SASE and Security Operations generated strong results as we continued to gain market share in Secure Networking. With our expertise in converging networking and security, a proven track record of innovation, and seamless product integration within our FortiOS and FortiASIC, we are well-positioned to lead in our three core growth areas and drive sustained growth.”

[0001262039-24-000040:8k_2_02:16]
Financial Highlights for the Third Quarter of 2024

[0001262039-24-000040:8k_2_02:17]
•Revenue: Total revenue was $1.51 billion for the third quarter of 2024, an increase of 13.0% compared to $1.33 billion for the same quarter of 2023.

[0001262039-24-000040:8k_2_02:18]
•Product Revenue: Product revenue was $473.9 million for the third quarter of 2024, an increase of 1.7% compared to $465.9 million for the same quarter of 2023.

[0001262039-24-000040:8k_2_02:19]
•Service Revenue: Service revenue was $1.03 billion for the third quarter of 2024, an increase of 19.1% compared to $868.7 million for the same quarter of 2023.

[0001262039-24-000040:8k_2_02:20]
•Billings1: Total billings were $1.58 billion for the third quarter of 2024, an increase of 6.1% compared to $1.49 billion for the same quarter of 2023.

[0001262039-24-000040:8k_2_02:21]
•Deferred Revenue: Total deferred revenue was $6.01 billion as of September 30, 2024, an increase of 13.7% compared to $5.29 billion as of September 30, 2023.

[0001262039-24-000040:8k_2_02:22]
•GAAP Operating Income and Margin: GAAP operating income was $470.9 million for the third quarter of 2024, representing a GAAP operating margin of 31.2%. GAAP

[0001262039-24-000040:8k_2_02:23]
operating income was $303.2 million for the same quarter of 2023, representing a GAAP operating margin of 22.7%.

[0001262039-24-000040:8k_2_02:24]
•Non-GAAP Operating Income and Margin1: Non-GAAP operating income was $544.7 million for the third quarter of 2024, representing a non-GAAP operating margin of 36.1%. Non-GAAP operating income was $371.4 million for the same quarter of 2023, representing a non-GAAP operating margin of 27.8%.

[0001262039-24-000040:8k_2_02:25]
•GAAP Net Income and Diluted Net Income Per Share: GAAP net income was $539.9 million for the third quarter of 2024, compared to GAAP net income of $322.9 million for the same quarter of 2023. GAAP diluted net income per share was $0.70 for the third quarter of 2024, based on 771.9 million diluted weighted-average shares outstanding, compared to GAAP diluted net income per share of $0.41 for the same quarter of 2023, based on 791.2 million diluted weighted-average shares outstanding.

[0001262039-24-000040:8k_2_02:26]
•Non-GAAP Net Income and Diluted Net Income Per Share1: Non-GAAP net income was $487.6 million for the third quarter of 2024, compared to non-GAAP net income of $323.5 million for the same quarter of 2023. Non-GAAP diluted net income per share was $0.63 for the third quarter of 2024, based on 771.9 million diluted weighted-average shares outstanding, compared to $0.41 for the same quarter of 2023, based on 791.2 million diluted weighted-average shares outstanding.

[0001262039-24-000040:8k_2_02:27]
•Cash Flow: Cash flow from operations was $608.1 million for the third quarter of 2024, compared to $551.2 million for the same quarter of 2023.

[0001262039-24-000040:8k_2_02:28]
•Free Cash Flow1: Free cash flow was $571.8 million for the third quarter of 2024, compared to $481.1 million for the same quarter of 2023.

[0001262039-24-000040:8k_2_02:29]
•Share Repurchase Program: In October 2024, Fortinet’s board of directors authorized a $1.0 billion increase in the authorized stock repurchase under our share repurchase program. As of November 7, 2024, approximately $2.03 billion remained available for future share repurchases.

[0001262039-24-000040:8k_2_02:30]
Guidance

[0001262039-24-000040:8k_2_02:31]
For the fourth quarter of 2024, Fortinet currently expects:

[0001262039-24-000040:8k_2_02:32]
•Revenue in the range of $1.560 billion to $1.620 billion

[0001262039-24-000040:8k_2_02:33]
•Billings in the range of $1.900 billion to $2.000 billion

[0001262039-24-000040:8k_2_02:34]
•Non-GAAP gross margin in the range of 79.5% to 80.5%

[0001262039-24-000040:8k_2_02:35]
•Non-GAAP operating margin in the range of 33.0% to 34.0%

[0001262039-24-000040:8k_2_02:36]
•Diluted non-GAAP net income per share in the range of $0.58 to $0.62, assuming a non-GAAP effective tax rate of 17%. This assumes a diluted share count of 768 million to 778 million.

[0001262039-24-000040:8k_2_02:37]
For the fiscal year 2024, Fortinet currently expects:

[0001262039-24-000040:8k_2_02:38]
•Revenue in the range of $5.856 billion to $5.916 billion

[0001262039-24-000040:8k_2_02:39]
•Service revenue in the range of $4.015 billion to $4.045 billion

[0001262039-24-000040:8k_2_02:40]
•Billings in the range of $6.430 billion to $6.530 billion

[0001262039-24-000040:8k_2_02:41]
•Non-GAAP gross margin in the range of 80.3% to 81.3%

[0001262039-24-000040:8k_2_02:42]
•Non-GAAP operating margin in the range of 32.9% to 33.9%

[0001262039-24-000040:8k_2_02:43]
•Diluted non-GAAP net income per share in the range of $2.20 to $2.28, assuming a non-GAAP effective tax rate of 17%. This assumes a diluted share count of 766 million to 776 million.

[0001262039-24-000040:8k_2_02:44]
Our guidance with respect to non-GAAP financial measures excludes stock-based compensation, amortization of acquired intangible assets, charges in connection with litigation settlement, gain on intellectual property matters, gain on bargain purchase related to acquisition, and non-cash charge of impairment on an equity method investment. We have not reconciled our guidance with respect to non-GAAP financial measures to the corresponding GAAP measures because certain items that impact these measures are uncertain or out of our control, or cannot be reasonably predicted. Accordingly, a reconciliation of these non-GAAP financial measures to the corresponding GAAP measures is not available without unreasonable effort.

[0001262039-24-000040:8k_2_02:45]
1 A reconciliation of GAAP to non-GAAP measures has been provided in the financial statement tables included in this press release. An explanation of these measures is also included below under the heading “Non-GAAP Financial Measures”.

[0001262039-24-000040:8k_2_02:46]
Conference Call Details

[0001262039-24-000040:8k_2_02:47]
Fortinet will host a conference call today at 1:30 p.m. Pacific Time (4:30 p.m. Eastern Time) to discuss the earnings results. A live webcast of the conference call and supplemental slides will be accessible from the Investor Relations page of Fortinet’s website at https://investor.fortinet.com and a replay will be archived and accessible at https://investor.fortinet.com/events-and-presentations.

[0001262039-24-000040:8k_2_02:48]
Fourth Quarter 2024 Conference Participation Schedule:

[0001262039-24-000040:8k_2_02:49]
•Fortinet Analyst Day

[0001262039-24-000040:8k_2_02:50]
November 18, 2024

[0001262039-24-000040:8k_2_02:51]
•Needham Security, Networking, & Communications Conference

[0001262039-24-000040:8k_2_02:52]
November 19, 2024

[0001262039-24-000040:8k_2_02:53]
•Wells Fargo TMT Summit

[0001262039-24-000040:8k_2_02:54]
December 4, 2024

[0001262039-24-000040:8k_2_02:55]
•Scotiabank Global Technology Conference

[0001262039-24-000040:8k_2_02:56]
December 10, 2024

[0001262039-24-000040:8k_2_02:57]
•Barclays Global Technology Conference

[0001262039-24-000040:8k_2_02:58]
December 11, 2024

[0001262039-24-000040:8k_2_02:59]
Members of Fortinet’s management team are expected to present at these conferences and discuss the latest company strategies and initiatives. Fortinet’s conference presentations are expected to be available via webcast on the company’s website. To access the most updated information, pre-register and listen to the webcast of each event, please visit the Investor Presentation & Events page of Fortinet’s website at https://investor.fortinet.com/events-and-presentations. The schedule is subject to change.

[0001262039-24-000040:8k_2_02:60]
About Fortinet (www.fortinet.com)

[0001262039-24-000040:8k_2_02:61]
Fortinet (Nasdaq: FTNT) is a driving force in the evolution of cybersecurity and the convergence of networking and security. Our mission is to secure people, devices and data everywhere, and today we deliver cybersecurity everywhere our customers need it with the largest integrated portfolio of over 50 enterprise-grade products. Well over half a million customers trust Fortinet’s solutions, which are among the most deployed, most patented and most validated in the industry. The Fortinet Training Institute, one of the largest and broadest training programs in the industry, is dedicated to making cybersecurity training and new career opportunities available to everyone. Collaboration with esteemed organizations from both the public and private sectors, including Computer Emergency Response Teams (“CERTS”), government entities, and academia, is a fundamental aspect of Fortinet’s commitment to enhance cyber resilience globally. FortiGuard Labs, Fortinet’s elite threat intelligence and research organization, develops and utilizes leading-edge machine learning and AI technologies to provide customers with timely and consistently top-rated protection and actionable threat intelligence. Learn more at https://www.fortinet.com, the Fortinet Blog or FortiGuard Labs.

[0001262039-24-000040:8k_2_02:62]
#          #          #

[0001262039-24-000040:8k_2_02:63]
Copyright © 2024 Fortinet, Inc. All rights reserved. The symbols ® and ™ denote respectively federally registered trademarks and common law trademarks of Fortinet, Inc., its subsidiaries and affiliates. Fortinet’s trademarks include, but are not limited to, the following: Fortinet, the Fortinet logo, FortiGate, FortiOS, FortiGuard, FortiCare, FortiAnalyzer, FortiManager, FortiASIC, FortiClient, FortiCloud, FortiMail, FortiSandbox, FortiADC, FortiAI, FortiAIOps, FortiAgent, FortiAntenna, FortiAP, FortiAPCam, FortiAuthenticator, FortiCache, FortiCall, FortiCam, FortiCamera, FortiCarrier, FortiCASB, FortiCentral, FortiCNP, FortiConnect, FortiController, FortiConverter, FortiCSPM, FortiCWP, FortiDAST, FortiDB, FortiDDoS, FortiDeceptor, FortiDeploy, FortiDevSec, FortiDLP, FortiEdge, FortiEDR, FortiExplorer, FortiExtender, FortiFirewall, FortiFlex, FortiFone, FortiGSLB, FortiGuest, FortiHypervisor, FortiInsight, FortiIsolator, FortiLAN, FortiLink, FortiMonitor, FortiNAC, FortiNDR, FortiPAM, FortiPenTest, FortiPhish, FortiPoint, FortiPolicy, FortiPortal, FortiPresence, FortiProxy, FortiRecon, FortiRecorder, FortiSASE, FortiScanner, FortiSDNConnector, FortiSIEM, FortiSMS, FortiSOAR, FortiSRA, FortiStack, FortiSwitch, FortiTester, FortiToken, FortiTrust, FortiVoice, FortiWAN, FortiWeb, FortiWiFi, FortiWLC, FortiWLM, FortiXDR and Lacework FortiCNAPP. Other trademarks belong to their respective owners. Fortinet has not independently verified statements or certifications herein attributed to third parties and Fortinet does not independently endorse such statements. Notwithstanding anything to the contrary herein, nothing herein constitutes a warranty, guarantee, contract, binding specification or other binding commitment by Fortinet or any indication of intent related to a binding commitment, and performance and other specification information herein may be unique to certain environments.

[0001262039-24-000040:8k_2_02:64]
FTNT-F

[0001262039-24-000040:8k_2_02:65]
Forward-Looking Statements

[0001262039-24-000040:8k_2_02:66]
This press release contains forward-looking statements that involve risks and uncertainties. These forward-looking statements include statements regarding any indications related to future growth and market share gains, our strategy going forward, and guidance and expectations around future financial results, including guidance and expectations for the fourth quarter and full year 2024, and any statements regarding our market opportunity and market size, and business momentum. Although we attempt to be accurate in making forward-looking statements, it is possible that future circumstances might differ from the assumptions on which such statements are based such that actual results are materially different from our forward-looking statements in this release. Important factors that could cause results to differ materially from the statements herein include the following: general economic risks, including those caused by economic challenges, a possible economic downturn or recession and the effects of inflation or stagflation, rising interest rates or reduced information technology spending; supply chain challenges; negative impacts from the ongoing war in Ukraine and its related macroeconomic effects and our decision to reduce operations in Russia, as well as the Israel-Hamas war;

[0001262039-24-000040:8k_2_02:67]
Non-GAAP Financial Measures

[0001262039-24-000040:8k_2_02:68]
We have provided in this release financial information that has not been prepared in accordance with U.S. Generally Accepted Accounting Principles (GAAP). These non-GAAP financial and liquidity measures are not based on any standardized methodology prescribed by GAAP and are not necessarily comparable to similar measures presented by other companies. We use these non-GAAP financial measures internally in analyzing our financial results and believe they are useful to investors, as a supplement to GAAP measures, in evaluating our ongoing operational performance. We believe that the use of these non-GAAP financial measures provides an additional tool for investors to use in evaluating ongoing operating results and trends and in comparing our financial results with peer companies, many of which present similar non-GAAP financial measures to investors.

[0001262039-24-000040:8k_2_02:69]
Non-GAAP financial measures should not be considered in isolation from, or as a substitute for, financial information prepared in accordance with GAAP. Investors are encouraged to review the

[0001262039-24-000040:8k_2_02:70]
reconciliation of these non-GAAP financial measures to their most directly comparable GAAP financial measures provided in the financial statement tables below.

[0001262039-24-000040:8k_2_02:71]
Billings (non-GAAP). We define billings as revenue recognized in accordance with GAAP plus the change in deferred revenue from the beginning to the end of the period less any deferred revenue balances acquired from business combination(s) during the period. We consider billings to be a useful metric for management and investors because billings drive current and future revenue, which is an important indicator of the health and viability of our business. There are a number of limitations related to the use of billings instead of GAAP revenue. First, billings include amounts that have not yet been recognized as revenue and are impacted by the term of security and support agreements. Second, we may calculate billings in a manner that is different from peer companies that report similar financial measures. Management accounts for these limitations by providing specific information regarding GAAP revenue and evaluating billings together with GAAP revenue.

[0001262039-24-000040:8k_2_02:72]
Free cash flow (non-GAAP). We define free cash flow as net cash provided by operating activities minus purchases of property and equipment. We believe free cash flow to be a liquidity measure that provides useful information to management and investors about the amount of cash generated by the business that, after capital expenditures, can be used for strategic opportunities, including repurchasing outstanding common stock, investing in our business, making strategic acquisitions and strengthening the balance sheet. A limitation of using free cash flow rather than the GAAP measures of cash provided by or used in operating activities, investing activities, and financing activities is that free cash flow does not represent the total increase or decrease in the cash and cash equivalents balance for the period because it excludes investing activities other than capital expenditures and cash flows from financing activities. Management accounts for this limitation by providing information about our capital expenditures and other investing and financing activities on the face of the cash flow statement and under the caption “Management’s Discussion and Analysis of Financial Condition and Results of Operations—Liquidity and Capital Resources” in our most recent Quarterly Report on Form 10-Q and Annual Report on Form 10-K and by presenting cash flows from investing and financing activities in our reconciliation of free cash flow. In addition, it is important to note that other companies, including companies in our industry, may not use free cash flow, may calculate free cash flow in a different manner than we do or may use other financial measures to evaluate their performance, all of which could reduce the usefulness of free cash flow as a comparative measure.

[0001262039-24-000040:8k_2_02:73]
Non-GAAP operating income and operating margin. We define non-GAAP operating income as operating income plus stock-based compensation, amortization of acquired intangible assets and charges in connection with litigation settlement, less gain on intellectual property matter and, when applicable, other significant non-recurring items in a given quarter. Non-GAAP operating margin is defined as non-GAAP operating income divided by GAAP revenue. We consider these non-GAAP financial measures to be useful metrics for management and investors because they exclude the items noted above so that our management and investors can compare our recurring core business operating results over multiple periods. There are a number of limitations related to the use of non-GAAP operating income instead of operating income calculated in accordance with GAAP. First, non-GAAP operating income excludes the items noted above. Second, the components of the costs that we exclude from our calculation of non-GAAP operating income may differ from the components that peer companies exclude when they report their non-GAAP results of operations. Management accounts for these limitations by providing specific information regarding the GAAP amounts excluded from non-GAAP operating income and evaluating non-GAAP operating income together with operating income calculated in accordance with GAAP.

[0001262039-24-000040:8k_2_02:74]
Non-GAAP net income and diluted net income per share. We define non-GAAP net income as net income plus the items noted above under non-GAAP operating income and operating margin. In addition, we adjust non-GAAP net income and diluted net income per share for a gain

[0001262039-24-000040:8k_2_02:75]
on bargain purchase related to acquisition, a non-cash charge of impairment on an equity method investment and a tax adjustment required for an effective tax rate on a non-GAAP basis, which differs from the GAAP effective tax rate. We define non-GAAP diluted net income per share as non-GAAP net income divided by the non-GAAP diluted weighted-average shares outstanding. We consider these non-GAAP financial measures to be useful metrics for management and investors for the same reasons that we use non-GAAP operating income and non-GAAP operating margin. However, in order to provide a more complete picture of our recurring core business operating results, we include in non-GAAP net income and non-GAAP diluted net income per share, the tax adjustment required resulting in an effective tax rate on a non-GAAP basis, which often differs from the GAAP tax rate. We believe the non-GAAP effective tax rates we use are reasonable estimates of normalized tax rates for our current and prior fiscal years under our global operating structure. The same limitations described above regarding our use of non-GAAP operating income and non-GAAP operating margin apply to our use of non-GAAP net income and non-GAAP diluted net income per share. We account for these limitations by providing specific information regarding the GAAP amounts excluded from non-GAAP net income and non-GAAP diluted net income per share and evaluating non-GAAP net income and non-GAAP diluted net income per share together with net income and diluted net income per share calculated in accordance with GAAP.

[0001262039-24-000040:8k_2_02:76]
FORTINET, INC.

[0001262039-24-000040:8k_2_02:77]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001262039-24-000040:8k_2_02:78]
(Unaudited, in millions)

[0001262039-24-000040:8k_2_02:79]
|  | September 30,2024 |  | December 31,2023 |
| ASSETS |  |  |  |
| CURRENT ASSETS: |  |  |  |
| Cash and cash equivalents | $ | 2,489.3 |  |  | $ | 1,397.9 |  |
| Short-term investments | 1,162.4 |  |  | 1,021.5 |  |
| Marketable equity securities | 49.0 |  |  | 21.0 |  |
| Accounts receivable—net | 1,044.1 |  |  | 1,402.0 |  |
| Inventory | 354.3 |  |  | 484.8 |  |
| Prepaid expenses and other current assets | 121.5 |  |  | 101.1 |  |
| Total current assets | 5,220.6 |  |  | 4,428.3 |  |
| PROPERTY AND EQUIPMENT—NET | 1,273.4 |  |  | 1,044.4 |  |
| DEFERRED CONTRACT COSTS | 599.4 |  |  | 605.6 |  |
| DEFERRED TAX ASSETS | 1,300.4 |  |  | 868.8 |  |
| GOODWILL AND OTHER INTANGIBLE ASSETS—NET | 324.4 |  |  | 161.8 |  |
| OTHER ASSETS | 133.8 |  |  | 150.0 |  |
| TOTAL ASSETS | $ | 8,852.0 |  |  | $ | 7,258.9 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY (DEFICIT) |  |  |  |
| CURRENT LIABILITIES: |  |  |  |
| Accounts payable | $ | 177.9 |  |  | $ | 204.3 |  |
| Accrued liabilities | 376.6 |  |  | 423.7 |  |
| Accrued payroll and compensation | 248.2 |  |  | 242.3 |  |
| Deferred revenue | 3,081.2 |  |  | 2,848.7 |  |
| Total current liabilities | 3,883.9 |  |  | 3,719.0 |  |
| DEFERRED REVENUE | 2,930.5 |  |  | 2,886.3 |  |
| LONG-TERM DEBT | 993.8 |  |  | 992.3 |  |
| OTHER LIABILITIES | 135.7 |  |  | 124.7 |  |
| Total liabilities | 7,943.9 |  |  | 7,722.3 |  |
| COMMITMENTS AND CONTINGENCIES |  |  |  |
| STOCKHOLDERS’ EQUITY (DEFICIT): |  |  |  |
| Common stock | 0.8 |  |  | 0.8 |  |
| Additional paid-in capital | 1,568.6 |  |  | 1,416.4 |  |
| Accumulated other comprehensive loss | (18.0) |  |  | (18.9) |  |
| Accumulated deficit | (643.3) |  |  | (1,861.7) |  |
| Total stockholders’ equity (deficit) | 908.1 |  |  | (463.4) |  |
| TOTAL LIABILITIES AND STOCKHOLDERS’ EQUITY (DEFICIT) | $ | 8,852.0 |  |  | $ | 7,258.9 |  |

[0001262039-24-000040:8k_2_02:80]
FORTINET, INC.

[0001262039-24-000040:8k_2_02:81]
CONDENSED CONSOLIDATED STATEMENTS OF INCOME

[0001262039-24-000040:8k_2_02:82]
(Unaudited, in millions, except per share amounts)

[0001262039-24-000040:8k_2_02:83]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30,2024 |  | September 30,2023 |  | September 30,2024 |  | September 30,2023 |
| REVENUE: |  |  |  |  |  |  |  |
| Product | $ | 473.9 |  |  | $ | 465.9 |  |  | $ | 1,334.7 |  |  | $ | 1,439.2 |  |
| Service | 1,034.2 |  |  | 868.7 |  |  | 2,961.0 |  |  | 2,450.5 |  |
| Total revenue | 1,508.1 |  |  | 1,334.6 |  |  | 4,295.7 |  |  | 3,889.7 |  |
| COST OF REVENUE: |  |  |  |  |  |  |  |
| Product | 136.1 |  |  | 198.3 |  |  | 474.0 |  |  | 566.4 |  |
| Service | 127.3 |  |  | 119.4 |  |  | 369.1 |  |  | 354.9 |  |
| Total cost of revenue | 263.4 |  |  | 317.7 |  |  | 843.1 |  |  | 921.3 |  |
| GROSS PROFIT: |  |  |  |  |  |  |  |
| Product | 337.8 |  |  | 267.6 |  |  | 860.7 |  |  | 872.8 |  |
| Service | 906.9 |  |  | 749.3 |  |  | 2,591.9 |  |  | 2,095.6 |  |
| Total gross profit | 1,244.7 |  |  | 1,016.9 |  |  | 3,452.6 |  |  | 2,968.4 |  |
| OPERATING EXPENSES: |  |  |  |  |  |  |  |
| Research and development | 187.3 |  |  | 156.9 |  |  | 525.7 |  |  | 461.3 |  |
| Sales and marketing | 515.9 |  |  | 504.4 |  |  | 1,518.3 |  |  | 1,498.6 |  |
| General and administrative | 71.7 |  |  | 53.5 |  |  | 182.7 |  |  | 156.2 |  |
| Gain on intellectual property matter | (1.1) |  |  | (1.1) |  |  | (3.4) |  |  | (3.4) |  |
| Total operating expenses | 773.8 |  |  | 713.7 |  |  | 2,223.3 |  |  | 2,112.7 |  |
| OPERATING INCOME | 470.9 |  |  | 303.2 |  |  | 1,229.3 |  |  | 855.7 |  |
| INTEREST INCOME | 42.4 |  |  | 37.0 |  |  | 112.9 |  |  | 89.2 |  |
| INTEREST EXPENSE | (5.0) |  |  | (5.4) |  |  | (15.1) |  |  | (15.6) |  |
| GAIN ON BARGAIN PURCHASE | 106.3 |  |  | — |  |  | 106.3 |  |  | — |  |
| OTHER INCOME (EXPENSE)—NET | 11.8 |  |  | (7.0) |  |  | 6.7 |  |  | (11.2) |  |
| INCOME BEFORE INCOME TAXES AND LOSS FROM EQUITY METHOD INVESTMENTS | 626.4 |  |  | 327.8 |  |  | 1,440.1 |  |  | 918.1 |  |
| PROVISION FOR (BENEFIT FROM) INCOME TAXES | 81.2 |  |  | (0.3) |  |  | 197.2 |  |  | 48.6 |  |
| LOSS FROM EQUITY METHOD INVESTMENTS | (5.3) |  |  | (5.2) |  |  | (23.9) |  |  | (32.6) |  |
| NET INCOME | $ | 539.9 |  |  | $ | 322.9 |  |  | $ | 1,219.0 |  |  | $ | 836.9 |  |
| Net income per share: |  |  |  |  |  |  |  |
| Basic | $ | 0.71 |  |  | $ | 0.41 |  |  | $ | 1.60 |  |  | $ | 1.07 |  |
| Diluted | $ | 0.70 |  |  | $ | 0.41 |  |  | $ | 1.58 |  |  | $ | 1.05 |  |
| Weighted-average shares outstanding: |  |  |  |  |  |  |  |
| Basic | 765.0 |  |  | 781.2 |  |  | 763.7 |  |  | 783.1 |  |
| Diluted | 771.9 |  |  | 791.2 |  |  | 770.8 |  |  | 793.5 |  |

[0001262039-24-000040:8k_2_02:84]
FORTINET, INC.

[0001262039-24-000040:8k_2_02:85]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001262039-24-000040:8k_2_02:86]
(Unaudited, in millions)

[0001262039-24-000040:8k_2_02:87]
|  | Nine Months Ended |
|  | September 30,2024 |  | September 30,2023 |
| CASH FLOWS FROM OPERATING ACTIVITIES: |  |  |  |
| Net income | $ | 1,219.0 |  |  | $ | 836.9 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |
| Stock-based compensation | 192.1 |  |  | 185.6 |  |
| Amortization of deferred contract costs | 218.3 |  |  | 195.9 |  |
| Depreciation and amortization | 87.6 |  |  | 83.2 |  |
| Amortization of investment discounts | (37.3) |  |  | (16.1) |  |
| Loss from equity method investments | 23.9 |  |  | 32.6 |  |
| Gain on bargain purchase | (106.3) |  |  | — |  |
| Other | (3.3) |  |  | 13.7 |  |
| Changes in operating assets and liabilities, net of impact of business combination: |  |  |  |
| Accounts receivable—net | 376.5 |  |  | 243.4 |  |
| Inventory | 104.9 |  |  | (231.0) |  |
| Prepaid expenses and other current assets | (9.0) |  |  | (29.3) |  |
| Deferred contract costs | (212.2) |  |  | (247.5) |  |
| Deferred tax assets | (187.6) |  |  | (221.7) |  |
| Other assets | (8.8) |  |  | 13.5 |  |
| Accounts payable | (32.0) |  |  | 10.4 |  |
| Accrued liabilities | (72.3) |  |  | 253.7 |  |
| Accrued payroll and compensation | (7.9) |  |  | (8.0) |  |
| Other liabilities | 0.5 |  |  | (17.7) |  |
| Deferred revenue | 234.4 |  |  | 646.2 |  |
| Net cash provided by operating activities | 1,780.5 |  |  | 1,743.8 |  |
| CASH FLOWS FROM INVESTING ACTIVITIES: |  |  |  |
| Purchases of investments | (1,485.3) |  |  | (1,327.6) |  |
| Sales of investments | — |  |  | 4.0 |  |
| Maturities of investments | 1,382.7 |  |  | 931.5 |  |
| Purchases of property and equipment | (281.3) |  |  | (177.2) |  |
| Purchase of investment in privately held company | — |  |  | (8.5) |  |
| Payments made in connection with business combination, net of cash acquired | (247.0) |  |  | — |  |
| Purchases of marketable equity securities | (16.7) |  |  | — |  |
| Other | 0.1 |  |  | 0.1 |  |
| Net cash used in investing activities | (647.5) |  |  | (577.7) |  |
| CASH FLOWS FROM FINANCING ACTIVITIES: |  |  |  |
| Repurchase and retirement of common stock | (0.6) |  |  | (604.3) |  |
| Proceeds from issuance of common stock | 39.7 |  |  | 36.0 |  |
| Taxes paid related to net share settlement of equity awards | (79.6) |  |  | (90.8) |  |
| Other | (0.8) |  |  | (1.2) |  |
| Net cash used in financing activities | (41.3) |  |  | (660.3) |  |
| EFFECT OF EXCHANGE RATE CHANGES ON CASH AND CASH EQUIVALENTS | (0.3) |  |  | (1.9) |  |
| NET INCREASE IN CASH AND CASH EQUIVALENTS | 1,091.4 |  |  | 503.9 |  |
| CASH AND CASH EQUIVALENTS—Beginning of period | 1,397.9 |  |  | 1,682.9 |  |
| CASH AND CASH EQUIVALENTS—End of period | $ | 2,489.3 |  |  | $ | 2,186.8 |  |

[0001262039-24-000040:8k_2_02:88]
Reconciliations of non-GAAP results of operations measures to the nearest comparable GAAP measures

[0001262039-24-000040:8k_2_02:89]
(Unaudited, in millions, except per share amounts)

[0001262039-24-000040:8k_2_02:90]
Reconciliation of GAAP operating income to non-GAAP operating income, operating margin, net income and diluted net income per share

[0001262039-24-000040:8k_2_02:91]
|  | Three Months Ended |  |  |
|  | September 30,2024 |  | September 30,2023 |  |  |  |  |
| Reconciliation of non-GAAP operating income: |  |  |  |  |  |  |  |
| GAAP operating income | $ | 470.9 |  |  | $ | 303.2 |  |  |  |  |  |
| GAAP operating margin | 31.2 | % |  | 22.7 | % |  |  |  |  |
| Add back: |  |  |  |  |  |  |  |
| Stock‐based compensation | 66.4 |  |  | 64.9 |  |  |  |  |  |
| Amortization of acquired intangible assets | 5.3 |  |  | 4.4 |  |  |  |  |  |
| Litigation-related matter (a) | 3.2 |  |  | — |  |  |  |  |  |
| Gain on intellectual property matter | (1.1) |  |  | (1.1) |  |  |  |  |  |
| Non‐GAAP operating income | $ | 544.7 |  |  | $ | 371.4 |  |  |  |  |  |
| Non‐GAAP operating margin | 36.1 | % |  | 27.8 | % |  |  |  |  |
| Reconciliation of non-GAAP net income: |  |  |  |  |  |  |  |
| GAAP net income | $ | 539.9 |  |  | $ | 322.9 |  |  |  |  |  |
| Add back: |  |  |  |  |  |  |  |
| Stock‐based compensation | 66.4 |  |  | 64.9 |  |  |  |  |  |
| Amortization of acquired intangible assets | 5.3 |  |  | 4.4 |  |  |  |  |  |
| Litigation-related matter (a) | 3.2 |  |  | — |  |  |  |  |  |
| Gain on intellectual property matter | (1.1) |  |  | (1.1) |  |  |  |  |  |
| Gain on bargain purchase (b) | (106.3) |  |  | — |  |  |  |  |  |
| Tax adjustment (c) | (19.8) |  |  | (67.6) |  |  |  |  |  |
| Non-GAAP net income | $ | 487.6 |  |  | $ | 323.5 |  |  |  |  |  |
| Non-GAAP net income per share, diluted |  |  |  |  |  |  |  |
| Non-GAAP net income | $ | 487.6 |  |  | $ | 323.5 |  |  |  |  |  |
| Non-GAAP shares used in diluted net income per share calculations | 771.9 |  |  | 791.2 |  |  |  |  |  |
| Non-GAAP net income per share, diluted | $ | 0.63 |  |  | $ | 0.41 |  |  |  |  |  |
| Reconciliation of non-GAAP net income per share, diluted |  |  |  |  |  |  |  |
| GAAP net income per share | $ | 0.70 |  |  | $ | 0.41 |  |  |  |  |  |
| Add back: |  |  |  |  |  |  |  |
| Non-GAAP adjustments to net income per share | (0.07) |  |  | — |  |  |  |  |  |
| Non-GAAP net income per share, diluted | $ | 0.63 |  |  | $ | 0.41 |  |  |  |  |  |

[0001262039-24-000040:8k_2_02:92]
(a) To exclude a $3.2 million adjustment for a litigation settlement.

[0001262039-24-000040:8k_2_02:93]
(b) To exclude a $106.3 million gain on bargain purchase related to our acquisition of Lacework Inc.

[0001262039-24-000040:8k_2_02:94]
(c) Non-GAAP financial information is adjusted to an effective tax rate of 17% in the three months ended September 30, 2024 and 2023, respectively, on a non-GAAP basis, which differs from the GAAP effective tax rate.

[0001262039-24-000040:8k_2_02:95]
Reconciliation of net cash provided by operating activities to free cash flow

[0001262039-24-000040:8k_2_02:96]
|  | Three Months Ended |
|  | September 30,2024 |  | September 30,2023 |
| Net cash provided by operating activities | $ | 608.1 |  |  | $ | 551.2 |  |
| Less: Purchases of property and equipment | (36.3) |  |  | (70.1) |  |
| Free cash flow | $ | 571.8 |  |  | $ | 481.1 |  |
| Net cash used in investing activities | $ | (327.1) |  |  | $ | (111.2) |  |
| Net cash provided by (used in) financing activities | $ | 3.0 |  |  | $ | (628.9) |  |

[0001262039-24-000040:8k_2_02:97]
Reconciliation of total revenue to total billings

[0001262039-24-000040:8k_2_02:98]
|  | Three Months Ended |
|  | September 30,2024 |  | September 30,2023 |
| Total revenue | $ | 1,508.1 |  |  | $ | 1,334.6 |  |
| Add: Change in deferred revenue | 115.5 |  |  | 156.7 |  |
| Less: Deferred revenue balance acquired in business acquisitions | (41.4) |  |  | — |  |
| Total billings | $ | 1,582.2 |  |  | $ | 1,491.3 |  |

[0001262039-24-000040:8k_2_02:99]
| Investor Contact: |  | Media Contact: |
| Aaron Ovadia |  | Michelle Zimmermann |
| Fortinet, Inc. |  | Fortinet, Inc. |
| 408-235-7700 |  | 408-235-7700 |
| investors@fortinet.com |  | pr@fortinet.com |
