# FTNT notes — 0001262039-24-000043


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001262039-24-000043:notes:1]
SUMMARY OF SIGNIFICANT ACCOUNTING POLICIES
Basis of Presentation and Preparation—The unaudited condensed consolidated financial statements of Fortinet, Inc. and its subsidiaries (collectively, “we,” “us” or “our”) have been prepared in accordance with generally accepted accounting principles in the United States (“GAAP”) for interim financial information, as well as the instructions to Form 10-Q pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (the “SEC”). Accordingly, they do not include all of the information and footnotes required by GAAP for complete financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the year ended December 31, 2023, contained in our Annual Report on Form 10-K filed with the SEC on February 26, 2024. In the opinion of management, all adjustments, which include normal recurring adjustments, considered necessary for a fair presentation, have been included. The results of operations for the three and nine months ended September 30, 2024 are not necessarily indicative of the results to be expected for the full year or for any future periods. The condensed consolidated balance sheet as of December 31, 2023 is derived from the audited consolidated financial statements for the year ended December 31, 2023.

[0001262039-24-000043:notes:2]
[same as prior period, unchanged from 0001262039-24-000037:notes:2]

[0001262039-24-000043:notes:3]
[same as prior period, unchanged from 0001262039-24-000037:notes:3]

[0001262039-24-000043:notes:4]
There have been no material changes to our significant accounting policies as of and for the three and nine months ended September 30, 2024, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended December 31, 2023 filed with the SEC.

[0001262039-24-000043:notes:5]
[same as prior period, unchanged from 0001262039-24-000037:notes:5]

[0001262039-24-000043:notes:6]
[same as prior period, unchanged from 0001262039-24-000037:notes:6]

[0001262039-24-000043:notes:7]
In November 2023, the Financial Accounting Standards Board (the “FASB”) issued Accounting Standards Update (“ASU”) 2023-07, Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures, which is intended to improve reportable segment disclosure requirements, primarily through enhanced disclosures about significant expenses. The amendments are effective for our annual reporting for fiscal year 2024, and for our interim period reporting starting in fiscal year 2025 retrospectively, with early adoption permitted. We are currently evaluating the ASU to determine its impact on our disclosures.

[0001262039-24-000043:notes:8]
[same as prior period, unchanged from 0001262039-24-000037:notes:8]

[0001262039-24-000043:notes:9]
In December 2023, the FASB issued ASU 2023-09, Income Taxes (Topic 740): Improvements to Income Tax Disclosures, which includes amendments that further enhance income tax disclosures, primarily through standardization and disaggregation of rate reconciliation categories and income taxes paid by jurisdiction. The amendments are effective for our annual period beginning fiscal year 2025, with early adoption permitted, and should be applied prospectively. We are currently evaluating the ASU to determine its impact on our disclosures.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001262039-24-000043:notes:10]
[same as prior period, unchanged from 0001262039-24-000037:notes:10]

[0001262039-24-000043:notes:11]
[same as prior period, unchanged from 0001262039-24-000037:notes:11]

[0001262039-24-000043:notes:12]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30,2024 |  | September 30,2023 |  | September 30,2024 |  | September 30,2023 |
| Product | $ | 473.9 |  |  | $ | 465.9 |  |  | $ | 1,334.7 |  |  | $ | 1,439.2 |  |
| Service: |  |  |  |  |  |  |  |
| Security subscription | 595.8 |  |  | 494.6 |  |  | 1,691.4 |  |  | 1,373.6 |  |
| Technical support and other | 438.4 |  |  | 374.1 |  |  | 1,269.6 |  |  | 1,076.9 |  |
| Total service revenue | 1,034.2 |  |  | 868.7 |  |  | 2,961.0 |  |  | 2,450.5 |  |
| Total revenue | $ | 1,508.1 |  |  | $ | 1,334.6 |  |  | $ | 4,295.7 |  |  | $ | 3,889.7 |  |

[0001262039-24-000043:notes:13]
[same as prior period, unchanged from 0001262039-24-000037:notes:13]

[0001262039-24-000043:notes:14]
During the three and nine months ended September 30, 2024, we recognized $660.3 million and $2.28 billion in revenue that was included in the deferred revenue balance as of December 31, 2023, respectively. During the three and nine months ended September 30, 2023, we recognized $514.3 million and $1.80 billion in revenue that was included in the deferred revenue balance as of December 31, 2022, respectively.

[0001262039-24-000043:notes:15]
[same as prior period, unchanged from 0001262039-24-000037:notes:15]

[0001262039-24-000043:notes:16]
As of September 30, 2024, the aggregate amount of the transaction price allocated to remaining performance obligations was $6.08 billion, which was substantially comprised of deferred security subscription and technical support services revenue that will be recognized in future periods. We expect to recognize approximately $3.12 billion as revenue over the next 12 months and the remainder thereafter.

[0001262039-24-000043:notes:17]
[same as prior period, unchanged from 0001262039-24-000037:notes:17]

[0001262039-24-000043:notes:18]
[same as prior period, unchanged from 0001262039-24-000037:notes:18]

[0001262039-24-000043:notes:19]
The allowance for credit losses was $4.7 million and $8.2 million as of September 30, 2024 and December 31, 2023, respectively. Provisions, write-offs and recoveries were not material during the nine months ended September 30, 2024 and 2023.

[0001262039-24-000043:notes:20]
[same as prior period, unchanged from 0001262039-24-000037:notes:20]

[0001262039-24-000043:notes:21]
Amortization of deferred contract costs during the three months ended September 30, 2024 and 2023 were $73.6 million and $68.0 million, respectively. Amortization of deferred contract costs during the nine months ended September 30, 2024 and 2023 were $218.3 million and $195.9 million, respectively.


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0001262039-24-000043:notes:22]
[same as prior period, unchanged from 0001262039-24-000037:notes:22]

[0001262039-24-000043:notes:23]
[same as prior period, unchanged from 0001262039-24-000037:notes:23]

[0001262039-24-000043:notes:24]
|  | September 30, 2024 |
|  | AmortizedCost |  | UnrealizedGains |  | UnrealizedLosses |  | FairValue |
| U.S. government and agency securities | $ | 536.7 |  |  | $ | 0.8 |  |  | $ | — |  |  | $ | 537.5 |  |
| Commercial paper | 434.8 |  |  | 0.5 |  |  | — |  |  | 435.3 |  |
| Corporate debt securities | 123.5 |  |  | 0.3 |  |  | — |  |  | 123.8 |  |
| Certificates of deposit and term deposits | 65.7 |  |  | 0.1 |  |  | — |  |  | 65.8 |  |
| Total available-for-sale investments | $ | 1,160.7 |  |  | $ | 1.7 |  |  | $ | — |  |  | $ | 1,162.4 |  |

[0001262039-24-000043:notes:25]
|  | December 31, 2023 |
|  | AmortizedCost |  | UnrealizedGains |  | UnrealizedLosses |  | FairValue |
| U.S. government and agency securities | $ | 461.5 |  |  | $ | 0.2 |  |  | $ | (0.3) |  |  | $ | 461.4 |  |
| Commercial paper | 401.7 |  |  | 0.2 |  |  | (0.1) |  |  | 401.8 |  |
| Corporate debt securities | 70.0 |  |  | 0.1 |  |  | (0.1) |  |  | 70.0 |  |
| Certificates of deposit and term deposits | 88.2 |  |  | 0.1 |  |  | — |  |  | 88.3 |  |
| Total available-for-sale investments | $ | 1,021.4 |  |  | $ | 0.6 |  |  | $ | (0.5) |  |  | $ | 1,021.5 |  |

[0001262039-24-000043:notes:26]
[same as prior period, unchanged from 0001262039-24-000037:notes:26]

[0001262039-24-000043:notes:27]
|  | September 30, 2024 |
|  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
|  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |
| U.S. government and agency securities | $ | 40.2 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 40.2 |  |  | $ | — |  |
| Commercial paper | 60.8 |  |  | — |  |  | — |  |  | — |  |  | 60.8 |  |  | — |  |
| Corporate debt securities | 15.8 |  |  | — |  |  | — |  |  | — |  |  | 15.8 |  |  | — |  |
| Total available-for-sale investments | $ | 116.8 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 116.8 |  |  | $ | — |  |

[0001262039-24-000043:notes:28]
|  | December 31, 2023 |
|  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
|  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |
| U.S. government and agency securities | $ | 47.1 |  |  | $ | — |  |  | $ | 11.7 |  |  | $ | (0.3) |  |  | $ | 58.8 |  |  | $ | (0.3) |  |
| Commercial paper | 200.8 |  |  | (0.1) |  |  | — |  |  | — |  |  | 200.8 |  |  | (0.1) |  |
| Corporate debt securities | 21.8 |  |  | — |  |  | 26.9 |  |  | (0.1) |  |  | 48.7 |  |  | (0.1) |  |
| Total available-for-sale investments | $ | 269.7 |  |  | $ | (0.1) |  |  | $ | 38.6 |  |  | $ | (0.4) |  |  | $ | 308.3 |  |  | $ | (0.5) |  |

[0001262039-24-000043:notes:29]
[same as prior period, unchanged from 0001262039-24-000037:notes:29]

[0001262039-24-000043:notes:30]
|  | September 30,2024 |  | December 31,2023 |
| Due within one year | $ | 1,162.4 |  |  | $ | 1,021.5 |  |
| Due within one to three years | — |  |  | — |  |
| Total | $ | 1,162.4 |  |  | $ | 1,021.5 |  |

[0001262039-24-000043:notes:31]
[same as prior period, unchanged from 0001262039-24-000037:notes:31]

[0001262039-24-000043:notes:32]
[same as prior period, unchanged from 0001262039-24-000037:notes:32]

[0001262039-24-000043:notes:33]
[same as prior period, unchanged from 0001262039-24-000037:notes:33]

[0001262039-24-000043:notes:34]
Our marketable equity securities were $49.0 million and $21.0 million as of September 30, 2024 and December 31, 2023. The changes in fair value of our marketable equity securities are recorded in other income (expense)—net on the condensed consolidated statements of income. We recognized a $11.1 million and $11.2 million gain during the three and nine months ended September 30, 2024, respectively. We recognized a $2.3 million and $5.7 million loss during the three and nine months ended September 30, 2023, respectively.

[0001262039-24-000043:notes:35]
[same as prior period, unchanged from 0001262039-24-000037:notes:35]

[0001262039-24-000043:notes:36]
[same as prior period, unchanged from 0001262039-24-000037:notes:36]

[0001262039-24-000043:notes:37]
[same as prior period, unchanged from 0001262039-24-000037:notes:37]

[0001262039-24-000043:notes:38]
[same as prior period, unchanged from 0001262039-24-000037:notes:38]

[0001262039-24-000043:notes:39]
[same as prior period, unchanged from 0001262039-24-000037:notes:39]

[0001262039-24-000043:notes:40]
[same as prior period, unchanged from 0001262039-24-000037:notes:40]

[0001262039-24-000043:notes:41]
[same as prior period, unchanged from 0001262039-24-000037:notes:41]

[0001262039-24-000043:notes:42]
[same as prior period, unchanged from 0001262039-24-000037:notes:42]

[0001262039-24-000043:notes:43]
[same as prior period, unchanged from 0001262039-24-000037:notes:43]

[0001262039-24-000043:notes:44]
[same as prior period, unchanged from 0001262039-24-000037:notes:44]

[0001262039-24-000043:notes:45]
|  | September 30, 2024 |  | December 31, 2023 |
|  | AggregateFairValue |  | QuotedPrices inActiveMarkets ForIdenticalAssets |  | SignificantOtherObservableRemainingInputs |  | SignificantOtherUnobservableRemainingInputs |  | AggregateFairValue |  | QuotedPrices inActiveMarkets ForIdenticalAssets |  | SignificantOtherObservableRemainingInputs |  | SignificantOtherUnobservableRemainingInputs |
|  |  |  | (Level 1) |  | (Level 2) |  | (Level 3) |  |  |  | (Level 1) |  | (Level 2) |  | (Level 3) |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. government and agency securities | $ | 545.0 |  |  | $ | 530.2 |  |  | $ | 14.8 |  |  | $ | — |  |  | $ | 501.4 |  |  | $ | 433.3 |  |  | $ | 68.1 |  |  | $ | — |  |
| Commercial paper | 473.0 |  |  | — |  |  | 473.0 |  |  | — |  |  | 472.2 |  |  | — |  |  | 472.2 |  |  | — |  |
| Corporate debt securities | 123.8 |  |  | — |  |  | 123.8 |  |  | — |  |  | 73.0 |  |  | — |  |  | 73.0 |  |  | — |  |
| Certificates of deposit and term deposits | 67.6 |  |  | — |  |  | 67.6 |  |  | — |  |  | 104.8 |  |  | — |  |  | 104.8 |  |  | — |  |
| Money market funds | 256.0 |  |  | 256.0 |  |  | — |  |  | — |  |  | 277.1 |  |  | 277.1 |  |  | — |  |  | — |  |
| Marketable equity securities | 49.0 |  |  | 49.0 |  |  | — |  |  | — |  |  | 21.0 |  |  | 21.0 |  |  | — |  |  | — |  |
| Total | $ | 1,514.4 |  |  | $ | 835.2 |  |  | $ | 679.2 |  |  | $ | — |  |  | $ | 1,449.5 |  |  | $ | 731.4 |  |  | $ | 718.1 |  |  | $ | — |  |
| Reported as: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents | $ | 303.0 |  |  |  |  |  |  |  |  | $ | 407.0 |  |  |  |  |  |  |  |
| Marketable equity securities | 49.0 |  |  |  |  |  |  |  |  | 21.0 |  |  |  |  |  |  |  |
| Short-term investments | 1,162.4 |  |  |  |  |  |  |  |  | 1,021.5 |  |  |  |  |  |  |  |
| Total | $ | 1,514.4 |  |  |  |  |  |  |  |  | $ | 1,449.5 |  |  |  |  |  |  |  |

[0001262039-24-000043:notes:46]
There were no transfers between Level 1 and Level 2 of the fair value hierarchy during the nine months ended September 30, 2024 and year ended December 31, 2023.


## us-gaap:InventoryDisclosureTextBlock

[0001262039-24-000043:notes:47]
[same as prior period, unchanged from 0001262039-24-000037:notes:47]

[0001262039-24-000043:notes:48]
|  | September 30,2024 |  | December 31,2023 |
| Raw materials | $ | 99.2 |  |  | $ | 92.1 |  |
| Work in process | 5.4 |  |  | 7.7 |  |
| Finished goods | 249.7 |  |  | 385.0 |  |
| Inventory | $ | 354.3 |  |  | $ | 484.8 |  |

[0001262039-24-000043:notes:49]
The excess and obsolete inventory reserve was $132.8 million and $89.2 million as of September 30, 2024 and December 31, 2023, respectively. Inventory write-downs related to excess and obsolete inventory were $8.8 million and $37.6 million for the three and nine months ended September 30, 2024, respectively, and were $10.0 million and $22.3 million for the three and nine months ended September 30, 2023, respectively. These were recorded in cost of product revenue on the condensed consolidated statements of income.


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001262039-24-000043:notes:50]
[same as prior period, unchanged from 0001262039-24-000037:notes:50]

[0001262039-24-000043:notes:51]
|  | September 30,2024 |  | December 31,2023 |
| Land | $ | 462.6 |  |  | $ | 351.7 |  |
| Buildings and improvements | 738.4 |  |  | 595.5 |  |
| Computer equipment and software | 278.7 |  |  | 261.1 |  |
| Leasehold improvements | 65.5 |  |  | 61.4 |  |
| Evaluation units | 32.7 |  |  | 30.8 |  |
| Furniture and fixtures | 36.5 |  |  | 33.6 |  |
| Construction-in-progress | 72.5 |  |  | 63.3 |  |
| Total property and equipment | 1,686.9 |  |  | 1,397.4 |  |
| Less: accumulated depreciation | (413.5) |  |  | (353.0) |  |
| Property and equipment—net | $ | 1,273.4 |  |  | $ | 1,044.4 |  |

[0001262039-24-000043:notes:52]
During the first three quarters in 2024, we purchased certain real estate properties in California, United States and Alberta, Canada, for an aggregate purchase price of $229.3 million, to be used predominantly for research and development, warehousing, datacenter operations and sales and support functions. The purchases were accounted for under the asset acquisition method. The cost of the assets allocated to land, buildings and improvements, and furniture and fixtures were $111.0 million, $117.4 million, and $0.9 million , respectively, based on their relative fair values.

[0001262039-24-000043:notes:53]
Depreciation expense was $24.5 million and $23.9 million during the three months ended September 30, 2024 and 2023, respectively. Depreciation expense was $76.0 million and $69.6 million during the nine months ended September 30, 2024 and 2023, respectively.


## us-gaap:InvestmentTextBlock

[0001262039-24-000043:notes:54]
[same as prior period, unchanged from 0001262039-24-000037:notes:54]

[0001262039-24-000043:notes:55]
During 2021, we invested $160.0 million in cash for shares of the Series A Preferred Stock of privately held Linksys Holdings, Inc. (“Linksys”), for a 50.8% ownership interest in outstanding equity of Linksys. As of September 30, 2024 and December 31, 2023, our ownership interest remained the same. Linksys provides router connectivity solutions to the consumer and small business markets.

[0001262039-24-000043:notes:56]
[same as prior period, unchanged from 0001262039-24-000037:notes:56]

[0001262039-24-000043:notes:57]
Due to the presence of impairment indicators, such as a series of operating losses, we evaluated our equity method investment for an other-than-temporary impairment (“OTTI”) during the third quarter of 2024. We considered various factors in determining whether an OTTI has occurred, including Linksys’ financial results, operating history, our ability and intent to hold the investment until its fair value recovers, the implied revenue valuation multiples compared to guideline public companies, the discounted cash flows analysis, Linksys’ ability to achieve milestones and any notable operational and strategic changes. After the evaluation, we determined that an additional OTTI had not occurred as of September 30, 2024. However, we may be required to recognize an impairment loss in future reporting periods if and when our evaluation of the aforementioned factors indicates that the investment in Linksys is determined to be other than temporarily impaired. Such determination will be based on the prevailing facts and circumstances at that time, including the results and disclosures of Linksys.

[0001262039-24-000043:notes:58]
Our share of loss of Linksys’ financial results, as well as our share of the amortization of the basis differences, totaled $5.2 million for the three months ended September 30, 2024. Our loss from our Linksys investment totaled $23.4 million for the

[0001262039-24-000043:notes:59]
nine months ended September 30, 2024, which comprised of our proportionate share of Linksys’ financial results and the amortization of the basis differences of $15.4 million, as well as an OTTI charge of $8.0 million recognized in the second quarter of 2024. Our share of loss of Linksys’ financial results, as well as our share of the amortization of the basis differences, totaled $5.2 million and $32.6 million for the three and nine months ended September 30, 2023, respectively. 
These losses and the OTTI charge were recorded in loss from equity method investments on the condensed consolidated statements of income. The carrying amount of our Linksys investment was $18.8 million and $42.2 million as of September 30, 2024 and December 31, 2023, respectively, and the investment was included in other assets on our condensed consolidated balance sheets.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001262039-24-000043:notes:60]
BUSINESS COMBINATIONS
Lacework Inc.

[0001262039-24-000043:notes:61]
On August 1, 2024, we closed an acquisition of Lacework Inc. (“Lacework”), a privately held data-driven cloud security company, for $152.3 million in cash. We acquired Lacework with a goal of offering its Cloud-Native Application Protection Platform (“CNAPP”) solution separately as well as integrated with our existing portfolio, forming a comprehensive, AI-driven cloud security platform available from a single vendor, which will help customers identify, prioritize, and remediate risks and threats in complex cloud-native infrastructure from code to cloud.

[0001262039-24-000043:notes:62]
Under the acquisition method of accounting in accordance with ASC 805, the total preliminary purchase price was allocated to Lacework’s identifiable tangible and intangible assets acquired and liabilities assumed based on their estimated fair values using management’s best estimates and assumptions to assign fair value as of the acquisition date. The following table provides the assets acquired and liabilities assumed as of the date of acquisition:

[0001262039-24-000043:notes:63]
| (in millions) | Estimated Fair Value |
| ASSETS |  |
| Cash | $ | 6.2 |  |
| Accounts receivable—net | 14.8 |  |
| Prepaid expenses and other current assets | 9.6 |  |
| Deferred tax assets | 244.4 |  |
| Other intangible assets | 61.3 |  |
| TOTAL ASSETS | $ | 336.3 |  |
| LIABILITIES |  |
| Accounts payable | $ | 2.5 |  |
| Deferred revenue | 37.5 |  |
| Accrued payroll and compensation | 12.0 |  |
| Accrued and other current liabilities | 25.5 |  |
| Other liabilities | 0.2 |  |
| TOTAL LIABILITIES | $ | 77.7 |  |
| Gain on bargain purchase | $ | 106.3 |  |
| Net purchase consideration | $ | 152.3 |  |

[0001262039-24-000043:notes:64]
The excess of the fair values of the net assets acquired over the net purchase consideration was recorded as a gain on bargain purchase within other income, net on the condensed consolidated statements of income. The gain on bargain purchase occurred primarily due to the recognition of the deferred tax assets. The deferred tax assets were comprised primarily of pre-acquisition federal net operating loss carryforwards with an indefinite carryforward period.

[0001262039-24-000043:notes:65]
Identified intangible assets acquired and their estimated useful lives (in years) as of August 1, 2024, were as follows (in millions, except years):

[0001262039-24-000043:notes:66]
|  | Fair Value |  | Estimated Useful Life (in years) |
| Developed technology (1) | $ | 39.5 |  |  | 5.0 |
| Customer relationships | 7.5 |  |  | 5.0 |
| Trade name | 4.3 |  |  | 5.0 |
| Backlog | 10.0 |  |  | 3.0 |
| Total identified intangible assets: | $ | 61.3 |  |  |  |
| (1) Developed technology is Lacework’s CNAPP solution. We valued the developed technology using the relief-from-royalty method under the income approach. This method reflects the present value of the projected cash flows that are expected to be generated by the developed technology. The economic useful life was determined based on the technology cycle as well as the cash flows over the forecast period. |

[0001262039-24-000043:notes:67]
Our estimates and assumptions are subject to change within the measurement period, which is up to 12 months after the acquisition date. The allocation of the purchase price for this acquisition has been prepared on a preliminary basis and changes to the allocation of certain assets and liabilities may occur as additional information becomes available. The primary area of the purchase price that is not yet finalized is related to income taxes.

[0001262039-24-000043:notes:68]
The operating results of the acquired company were included in our condensed consolidated financial statements from the date of acquisition, which was August 1, 2024. For the period from August 2, 2024 through September 30, 2024, Lacework contributed revenue of $12.9 million and a net loss of $21.6 million. Acquisition-related costs for this acquisition were not material and were recorded as general and administrative expense.

[0001262039-24-000043:notes:69]
Next DLP Holdings Limited

[0001262039-24-000043:notes:70]
On August 5, 2024, we completed the acquisition of Next DLP Holdings Limited (“Next DLP”), a privately held insider risk and data loss prevention (“DLP”) company, for approximately $105.0 million in cash. We acquired Next DLP to improve our position in the standalone enterprise DLP market and strengthen our leadership in integrated DLP markets within endpoint and SASE.

[0001262039-24-000043:notes:71]
This acquisition was accounted for as a business combination using the acquisition method of accounting. The total preliminary purchase price was allocated to Next DLP’s identifiable tangible and intangible assets acquired and liabilities assumed based on their estimated fair values using management’s best estimates and assumptions to assign fair value as of the acquisition date. Of the total preliminary purchase price, $82.6 million was allocated to goodwill, $13.5 million was allocated to developed technology intangible asset, $10.5 million was allocated to customer relationships intangible asset, offset by $1.6 million of net liabilities assumed, which predominantly included deferred revenue and deferred tax liabilities. Goodwill recorded in connection with this acquisition represents the value we expect to be created through expansion into markets within our existing business, and the anticipated operational synergies, and goodwill is not expected to be deductible for tax purposes. Acquisition-related costs related to this acquisition were not material and were recorded as general and administrative expense.

[0001262039-24-000043:notes:72]
Our estimates and assumptions are subject to change within the measurement period, which is up to 12 months after the acquisition date. The allocation of the purchase price for this acquisition has been prepared on a preliminary basis and changes to the allocation of certain assets and liabilities may occur as additional information becomes available. The primary areas of the purchase price that are not yet finalized are related to income taxes and the valuation of acquired assets and assumed liabilities.

[0001262039-24-000043:notes:73]
Pro Forma Financial Information

[0001262039-24-000043:notes:74]
The following unaudited pro forma financial information presents the combined results of operations of Fortinet, Inc., Lacework and Next DLP, as if Lacework and Next DLP had been acquired as of the beginning of business on January 1, 2023. The unaudited pro forma financial information is presented for informational purposes only and is not necessarily indicative of our consolidated results of operations of the combined business that would have been achieved if the acquisitions had taken place at the beginning of business on January 1, 2023, or of the results of our future operations of the combined business. The

[0001262039-24-000043:notes:75]
following unaudited pro forma financial information for all periods presented includes purchase accounting adjustments for amortization of acquired intangible assets, the gain on bargain purchase, and various related tax impacts (in millions):

[0001262039-24-000043:notes:76]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30,2024 |  | September 30,2023 |  | September 30,2024 |  | September 30,2023 |
| Pro forma revenue | $ | 1,517.8 |  |  | $ | 1,358.9 |  |  | $ | 4,357.4 |  |  | $ | 3,964.2 |  |
| Pro forma net income | $ | 349.6 |  |  | $ | 267.0 |  |  | $ | 928.7 |  |  | $ | 758.3 |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001262039-24-000043:notes:77]
[same as prior period, unchanged from 0001262039-24-000037:notes:59]

[0001262039-24-000043:notes:78]
[same as prior period, unchanged from 0001262039-24-000037:notes:60]

[0001262039-24-000043:notes:79]
|  | Amount |
| Balance—December 31, 2023 | $ | 126.5 |  |
| Additions due to business combinations | 86.5 |  |
| Foreign currency translation adjustments | (0.2) |  |
| Balance—September 30, 2024 | $ | 212.8 |  |

[0001262039-24-000043:notes:80]
There were no impairments to goodwill during the nine months ended September 30, 2024 or during prior periods.

[0001262039-24-000043:notes:81]
[same as prior period, unchanged from 0001262039-24-000037:notes:63]

[0001262039-24-000043:notes:82]
[same as prior period, unchanged from 0001262039-24-000037:notes:64]

[0001262039-24-000043:notes:83]
|  | September 30, 2024 |
|  | Weighted-Average Useful Life (in Years) |  | Gross |  | Accumulated Amortization |  | Net |
| Other intangible assets—net: |  |  |  |  |  |  |  |
| Finite-lived intangible assets: |  |  |  |  |  |  |  |
| Developed technologies | 4.4 |  | $ | 134.4 |  |  | $ | 68.5 |  |  | $ | 65.9 |  |
| Customer relationships | 5.8 |  | 49.0 |  |  | 20.7 |  |  | 28.3 |  |
| Trade name | 7.7 |  | 9.2 |  |  | 1.6 |  |  | 7.6 |  |
| Backlog | 2.4 |  | 13.9 |  |  | 4.1 |  |  | 9.8 |  |
| Total other intangible assets—net |  |  | $ | 206.5 |  |  | $ | 94.9 |  |  | $ | 111.6 |  |

[0001262039-24-000043:notes:84]
[same as prior period, unchanged from 0001262039-24-000037:notes:66]

[0001262039-24-000043:notes:85]
Amortization expense was $5.3 million and $4.4 million during the three months ended September 30, 2024 and 2023, respectively. Amortization expense was $11.6 million and $13.6 million during the nine months ended September 30, 2024 and 2023, respectively.

[0001262039-24-000043:notes:86]
[same as prior period, unchanged from 0001262039-24-000037:notes:68]

[0001262039-24-000043:notes:87]
|  | Amount |
| Years: |  |
| 2024 (the remainder of 2024) | $ | 9.6 |  |
| 2025 | 34.2 |  |
| 2026 | 23.6 |  |
| 2027 | 19.0 |  |
| 2028 | 13.3 |  |
| Thereafter | 11.9 |  |
| Total | $ | 111.6 |  |


## us-gaap:EarningsPerShareTextBlock

[0001262039-24-000043:notes:88]
[same as prior period, unchanged from 0001262039-24-000037:notes:70]

[0001262039-24-000043:notes:89]
[same as prior period, unchanged from 0001262039-24-000037:notes:71]

[0001262039-24-000043:notes:90]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30,2024 |  | September 30,2023 |  | September 30,2024 |  | September 30,2023 |
| Numerator: |  |  |  |  |  |  |  |
| Net income | $ | 539.9 |  |  | $ | 322.9 |  |  | $ | 1,219.0 |  |  | $ | 836.9 |  |
| Denominator: |  |  |  |  |  |  |  |
| Basic shares: |  |  |  |  |  |  |  |
| Weighted-average common stock outstanding-basic | 765.0 |  |  | 781.2 |  |  | 763.7 |  |  | 783.1 |  |
| Diluted shares: |  |  |  |  |  |  |  |
| Weighted-average common stock outstanding-basic | 765.0 |  |  | 781.2 |  |  | 763.7 |  |  | 783.1 |  |
| Effect of potentially dilutive securities: |  |  |  |  |  |  |  |
| RSUs | 2.0 |  |  | 3.5 |  |  | 2.1 |  |  | 3.8 |  |
| Stock options | 4.4 |  |  | 6.2 |  |  | 4.7 |  |  | 6.4 |  |
| PSUs | 0.5 |  |  | 0.3 |  |  | 0.3 |  |  | 0.2 |  |
| Weighted-average shares used to compute diluted net income per share | 771.9 |  |  | 791.2 |  |  | 770.8 |  |  | 793.5 |  |
| Net income per share |  |  |  |  |  |  |  |
| Basic | $ | 0.71 |  |  | $ | 0.41 |  |  | $ | 1.60 |  |  | $ | 1.07 |  |
| Diluted | $ | 0.70 |  |  | $ | 0.41 |  |  | $ | 1.58 |  |  | $ | 1.05 |  |

[0001262039-24-000043:notes:91]
[same as prior period, unchanged from 0001262039-24-000037:notes:73]

[0001262039-24-000043:notes:92]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30,2024 |  | September 30,2023 |  | September 30,2024 |  | September 30,2023 |
| RSUs | 0.4 |  |  | — |  |  | 0.2 |  |  | 0.6 |  |
| Stock options | 3.1 |  |  | 3.0 |  |  | 3.3 |  |  | 2.8 |  |
| PSUs | — |  |  | — |  |  | 0.1 |  |  | — |  |
| Total | 3.5 |  |  | 3.0 |  |  | 3.5 |  |  | 3.4 |  |


## us-gaap:DebtDisclosureTextBlock

[0001262039-24-000043:notes:93]
DEBT
2026 and 2031 Senior Notes

[0001262039-24-000043:notes:94]
On March 5, 2021, we issued $1.0 billion aggregate principal amount of senior notes (collectively, the “Senior Notes”), consisting of $500.0 million aggregate principal amount of 1.0% notes due March 15, 2026 (the “2026 Senior Notes”) and $500.0 million aggregate principal amount of 2.2% notes due March 15, 2031 (the “2031 Senior Notes”), in an underwritten registered public offering. The Senior Notes are senior unsecured obligations and rank equally with each other in right of payment and with our other outstanding obligations. We may redeem the Senior Notes at any time in whole or in part for cash, at specified redemption prices that include accrued and unpaid interest, if any, and a make-whole premium. However, no make-whole premium will be paid for redemptions of the 2026 Senior Notes on or after February 15, 2026, or the 2031 Senior Notes on or after December 15, 2030. Interest on the Senior Notes is payable on March 15 and September 15 of each year, beginning on September 15, 2021. As of September 30, 2024 and December 31, 2023, the Senior Notes were recorded as long-term debt, net of discount and issuance costs, which are amortized to interest expense over the respective contractual terms of these notes using the effective interest method.

[0001262039-24-000043:notes:95]
The total outstanding debt is summarized below (in millions, except percentages):

[0001262039-24-000043:notes:96]
|  | Maturity |  | Coupon Rate |  | Effective Interest Rate |  | September 30,2024 |  | December 31,2023 |
| Debt |  |  |  |  |  |  |  |  |  |
| 2026 Senior Notes | March 2026 |  | 1.0% |  | 1.3% |  | $ | 500.0 |  |  | $ | 500.0 |  |
| 2031 Senior Notes | March 2031 |  | 2.2% |  | 2.3% |  | 500.0 |  |  | 500.0 |  |
| Total debt |  |  |  |  |  |  | 1,000.0 |  |  | 1,000.0 |  |
| Less: Unamortized discount and debt issuance costs |  |  |  |  |  |  | 6.2 |  |  | 7.7 |  |
| Total long-term debt |  |  |  |  |  |  | $ | 993.8 |  |  | $ | 992.3 |  |

[0001262039-24-000043:notes:97]
As of September 30, 2024 and December 31, 2023, we accrued interest payable of $0.7 million and $4.7 million, respectively, and there are no financial covenants with which we must comply. During the three months ended September 30, 2024 and 2023, we recorded $4.5 million of total interest expense in relation to these Senior Notes in each period. During the nine months ended September 30, 2024 and 2023, we recorded $13.5 million of total interest expense in relation to these Senior Notes in each period. No interest costs were capitalized for the nine months ended September 30, 2024 and 2023, as the costs that qualified for capitalization were not material.

[0001262039-24-000043:notes:98]
The total estimated fair value of the outstanding Senior Notes was approximately $912.8 million, including accrued and unpaid interest, as of September 30, 2024. The fair value was determined based on observable market prices of identical instruments in less active markets. The estimated fair values are based on Level 2 inputs.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001262039-24-000043:notes:99]
COMMITMENTS AND CONTINGENCIES
The following table summarizes our inventory purchase commitments as of September 30, 2024 (in millions):

[0001262039-24-000043:notes:100]
|  | Total |  | 2024 |  | Thereafter |
| Inventory purchase commitments | $ | 550.0 |  |  | $ | 393.7 |  |  | $ | 156.3 |  |

[0001262039-24-000043:notes:101]
Inventory Purchase Commitments—We purchase components of our inventory from certain suppliers and use several independent contract manufacturers to provide manufacturing services for our products. During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, we enter into agreements with contract manufacturers and suppliers that allow them to procure inventory based upon criteria as defined by us or establish the parameters defining our requirements. A significant portion of our reported purchase commitments arising from these agreements consists of firm, non-cancelable and unconditional commitments. Certain of these inventory purchase commitments with contract manufacturers and suppliers relate to arrangements to secure supply and pricing for certain product components for multi-year periods. In certain instances, these agreements allow us the option to reschedule and adjust our requirements based on our business needs prior to firm orders being placed.

[0001262039-24-000043:notes:102]
As of September 30, 2024, we had $550.0 million of non-cancelable inventory purchase commitments with our independent contract manufacturers. We recorded a liability for these purchase commitments for quantities in excess of our future estimated demand forecasts, consistent with the valuation of our excess and obsolete inventory. As of September 30, 2024 and December 31, 2023, the liability for these inventory purchase commitments was $76.3 million and $84.7 million, respectively, and was recorded in accrued liabilities on our condensed consolidated balance sheets. The cost of product revenue related to such liabilities was a $27.4 million benefit and a $36.9 million cost during the three months ended September 30, 2024 and 2023, respectively. The cost of product revenue related to such accrued liability for inventory purchase commitments was $11.2 million and $59.3 million during the nine months ended September 30, 2024 and 2023, respectively.

[0001262039-24-000043:notes:103]
Other Contractual Commitments and Open Purchase Orders—In addition to commitments with contract manufacturers, we have open purchase orders and contractual obligations in the ordinary course of business for which we have not received goods or services. A significant portion of our reported purchase commitments consist of non-cancelable commitments. In certain instances, contractual commitments allow us the option to cancel, reschedule and adjust our requirements based on our business needs prior to firm orders being placed. As of September 30, 2024, we had $116.5 million in other contractual commitments having a remaining term in excess of one year that are non-cancelable.

[0001262039-24-000043:notes:104]
As of September 30, 2024, we had $83.1 million in contractual commitments related to payments for operating leases.

[0001262039-24-000043:notes:105]
Litigation—We are involved in disputes, litigation, and other legal actions. For lawsuits where we are the defendant, we are in the process of defending these litigation matters, and while there can be no assurances and the outcome of certain of these matters is currently not determinable and not predictable, we currently are unaware of any existing claims or proceedings that we believe are likely to have a material adverse effect on our financial position. There are many uncertainties associated with any litigation and these actions or other third-party claims against us may cause us to incur costly litigation fees, costs and substantial settlement charges, and possibly subject us to damages and other penalties. In addition, the resolution of any intellectual property (“IP”) litigation may require us to make royalty payments, which could adversely affect our gross margins in future periods. If any of those events were to occur, our business, financial condition, results of operations, and cash flows could be adversely affected. Litigation is unpredictable and the actual liability in any such matters may be materially different from our current estimates, which could result in the need to adjust any accrued liability and record additional expenses. We accrue for contingencies when we believe that a loss is probable and that we can reasonably estimate the amount of any such loss. These accruals are generally based on a range of possible outcomes that require significant management judgement. If no amount within a range is a better estimate than any other, we accrue the minimum amount. Litigation loss contingency accruals associated with outstanding cases were not material as of September 30, 2024, and December 31, 2023.

[0001262039-24-000043:notes:106]
On March 21, 2019, we were sued by Alorica Inc. (“Alorica”) in Santa Clara County Superior Court in California. Alorica alleged breach of warranty and misrepresentation claims, which we denied. After trial, a jury returned a verdict fully in favor of us and against Alorica on October 4, 2024. The time for Alorica to appeal the verdict has not yet expired. We believe that the ultimate outcome of this matter will not materially impact our financial position, results of operations or cash flows. However, if Alorica appeals, any legal proceedings would be subject to inherent uncertainties, and a future unfavorable ruling could occur. No loss accrual had been recorded as of September 30, 2024 or December 31, 2023 related to this litigation.

[0001262039-24-000043:notes:107]
Indemnification and Other Matters—We enter into indemnification provisions in the ordinary course of business with other companies such as partners, customers, and vendors, where we agree to indemnify, hold harmless, and reimburse the

[0001262039-24-000043:notes:108]
indemnified party for certain losses suffered or incurred by the indemnified party as a result of our activities, including defending against third-party claims asserting various allegations such as product defects, breach of representations or covenants, and infringement of certain IP rights, which may include patents, copyrights, trademarks or trade secrets, and to pay judgments entered on such claims. In some contracts, our exposure under these indemnification provisions is limited by the terms of the contracts to certain defined limits, such as the total amount paid by our customer under the agreement. However, certain agreements include covenants, penalties and indemnification provisions including and beyond indemnification for third-party claims of IP infringement that could potentially expose us to losses in excess of the amount received under the agreement, and in some instances to potential liability that is not contractually limited. Although from time to time there are indemnification claims asserted against us and currently there are pending indemnification claims, to date there have been no material awards under such indemnification provisions.

[0001262039-24-000043:notes:109]
Periodically we, like other security companies and companies in other industries, have experienced, and may experience in the future, cybersecurity threats, malicious activity directed against our information technology infrastructure and unauthorized attempts to gain access to our and our customers’ sensitive information and systems. For example, in the third quarter of 2024, we discovered that an individual gained unauthorized access to a limited number of files stored on Fortinet’s instance of a third-party cloud-based shared file drive, which included limited data related to a small number of Fortinet customers. We have completed our investigation of this incident and we do not currently believe that it had a material impact on our business or that of any of our customers. We are currently not aware of any significant claims arising from this matter.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001262039-24-000043:notes:110]
[same as prior period, unchanged from 0001262039-24-000037:notes:91]

[0001262039-24-000043:notes:111]
We maintain the Amended and Restated Fortinet, Inc. 2009 Equity Incentive Plan (the “Amended Plan”) pursuant to which we have granted RSUs, stock options and PSUs. As of September 30, 2024, there were a total of 50.8 million shares of common stock available for grant under the Amended Plan.

[0001262039-24-000043:notes:112]
[same as prior period, unchanged from 0001262039-24-000037:notes:93]

[0001262039-24-000043:notes:113]
[same as prior period, unchanged from 0001262039-24-000037:notes:94]

[0001262039-24-000043:notes:114]
|  | Restricted Stock Units Outstanding |
|  | Number of Shares |  | Weighted-Average Grant Date Fair Value per Share |
| Balance—December 31, 2023 | 9.1 |  |  | $ | 53.61 |  |
| Granted | 4.0 |  |  | 67.49 |  |
| Forfeited | (0.7) |  |  | 58.64 |  |
| Vested | (3.6) |  |  | 49.14 |  |
| Balance—September 30, 2024 | 8.8 |  |  | $ | 61.38 |  |

[0001262039-24-000043:notes:115]
Stock compensation expense is recognized on a straight-line basis over the vesting period of each RSU. As of September 30, 2024, total compensation expense related to unvested RSUs granted to employees and non-employees under the Amended Plan, but not yet recognized, was $483.5 million, with a weighted-average remaining vesting period of 2.7 years.

[0001262039-24-000043:notes:116]
[same as prior period, unchanged from 0001262039-24-000037:notes:97]

[0001262039-24-000043:notes:117]
[same as prior period, unchanged from 0001262039-24-000037:notes:98]

[0001262039-24-000043:notes:118]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30,2024 |  | September 30,2023 |  | September 30,2024 |  | September 30,2023 |
| Shares withheld for taxes | 0.3 |  |  | 0.4 |  |  | 1.2 |  |  | 1.5 |  |
| Amount withheld for taxes | $ | 16.5 |  |  | $ | 31.0 |  |  | $ | 79.6 |  |  | $ | 90.7 |  |

[0001262039-24-000043:notes:119]
[same as prior period, unchanged from 0001262039-24-000037:notes:100]

[0001262039-24-000043:notes:120]
[same as prior period, unchanged from 0001262039-24-000037:notes:101]

[0001262039-24-000043:notes:121]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30,2024 |  | September 30,2023 |  | September 30,2024 |  | September 30,2023 |
| Expected term in years | 4.5 |  | 4.4 |  | 4.5 |  | 4.4 |
| Volatility | 41.7 | % |  | 42.8 | % |  | 42.8 | % |  | 42.0 | % |
| Risk-free interest rate | 3.7 | % |  | 4.5 | % |  | 4.3 | % |  | 4.2 | % |
| Dividend rate | — | % |  | — | % |  | — | % |  | — | % |

[0001262039-24-000043:notes:122]
[same as prior period, unchanged from 0001262039-24-000037:notes:103]

[0001262039-24-000043:notes:123]
|  | Options Outstanding |
|  | Numberof Shares |  | Weighted-AverageExercisePrice |  | Weighted-AverageRemainingContractualLife (Years) |  | AggregateIntrinsicValue |
| Balance—December 31, 2023 | 11.2 |  |  | $ | 31.14 |  |  | 3.3 |  | $ | 315.8 |  |
| Granted | 0.7 |  |  | 65.94 |  |  |  |  |  |
| Forfeited | (0.2) |  |  | 54.28 |  |  |  |  |  |
| Exercised | (2.2) |  |  | 17.71 |  |  |  |  |  |
| Balance—September 30, 2024 | 9.5 |  |  | $ | 36.56 |  |  |  |  |  |
| Options vested and expected to vest—September 30, 2024 | 9.5 |  |  | $ | 36.56 |  |  | 3.2 |  | $ | 391.3 |  |
| Options exercisable—September 30, 2024 | 7.3 |  |  | $ | 29.39 |  |  | 2.5 |  | $ | 350.3 |  |

[0001262039-24-000043:notes:124]
The aggregate intrinsic value represents the difference between the exercise price of stock options and the quoted market price of our common stock for all in-the-money stock options. Stock compensation expense is recognized on a straight-line basis over the vesting period of each stock option. As of September 30, 2024, total compensation expense related to unvested stock options granted to employees but not yet recognized was $49.9 million, with a weighted-average remaining vesting period of 2.4 years.

[0001262039-24-000043:notes:125]
[same as prior period, unchanged from 0001262039-24-000037:notes:106]

[0001262039-24-000043:notes:126]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30,2024 |  | September 30,2023 |  | September 30,2024 |  | September 30,2023 |
| Weighted-average fair value per share granted | $ | 29.86 |  |  | $ | 23.67 |  |  | $ | 27.05 |  |  | $ | 24.37 |  |
| Intrinsic value of options exercised | $ | 42.6 |  |  | $ | 13.9 |  |  | $ | 112.5 |  |  | $ | 110.9 |  |
| Fair value of options vested | $ | 6.4 |  |  | $ | 6.1 |  |  | $ | 25.0 |  |  | $ | 23.5 |  |

[0001262039-24-000043:notes:127]
[same as prior period, unchanged from 0001262039-24-000037:notes:108]

[0001262039-24-000043:notes:128]
[same as prior period, unchanged from 0001262039-24-000037:notes:109]

[0001262039-24-000043:notes:129]
[same as prior period, unchanged from 0001262039-24-000037:notes:110]

[0001262039-24-000043:notes:130]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30,2024 |  | September 30,2023 |  | September 30,2024 |  | September 30,2023 |
| Expected term in years | 2.7 |  | 2.7 |  | 2.7 |  | 2.7 |
| Volatility | 45.4 | % |  | 47.5 | % |  | 45.4 | % |  | 47.5 | % |
| Risk-free interest rate | 4.5 | % |  | 4.6 | % |  | 4.5 | % |  | 4.6 | % |
| Dividend rate | — | % |  | — | % |  | — | % |  | — | % |

[0001262039-24-000043:notes:131]
We granted approximately 0.3 million shares of PSU awards with a weighted-average grant date fair value of $97.40 per share to certain of our executives during the three and nine months ended September 30, 2024. We granted approximately 0.3 million shares of PSU awards with a weighted-average grant date fair value of $90.96 per share to certain of our executives during the three and nine months ended September 30, 2023. The grant date fair value of these awards was determined using a Monte Carlo simulation pricing model. Approximately 0.1 million shares of PSU awards vested during the first quarter of 2024. No shares of PSU awards vested during the second and third quarter of 2024 or the nine months ended September 30, 2023. Approximately 0.1 million shares of PSU awards were forfeited during the three and nine months ended September 30, 2024. None of these PSU awards were forfeited during the nine months ended September 30, 2023.

[0001262039-24-000043:notes:132]
As of September 30, 2024, total compensation expense related to unvested PSUs that were granted to certain of our executives, but not yet recognized, was $27.0 million. This expense is expected to be amortized on a graded vesting method over a weighted-average vesting period of 2.3 years.

[0001262039-24-000043:notes:133]
[same as prior period, unchanged from 0001262039-24-000037:notes:114]

[0001262039-24-000043:notes:134]
[same as prior period, unchanged from 0001262039-24-000037:notes:115]

[0001262039-24-000043:notes:135]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30,2024 |  | September 30,2023 |  | September 30,2024 |  | September 30,2023 |
| Cost of product revenue | $ | 0.5 |  |  | $ | 0.4 |  |  | $ | 1.4 |  |  | $ | 1.3 |  |
| Cost of service revenue | 6.3 |  |  | 6.1 |  |  | 19.0 |  |  | 17.2 |  |
| Research and development | 21.9 |  |  | 20.0 |  |  | 63.0 |  |  | 57.0 |  |
| Sales and marketing | 27.0 |  |  | 28.5 |  |  | 79.6 |  |  | 84.1 |  |
| General and administrative | 10.7 |  |  | 9.9 |  |  | 30.7 |  |  | 28.0 |  |
| Total stock-based compensation expense | $ | 66.4 |  |  | $ | 64.9 |  |  | $ | 193.7 |  |  | $ | 187.6 |  |

[0001262039-24-000043:notes:136]
[same as prior period, unchanged from 0001262039-24-000037:notes:117]

[0001262039-24-000043:notes:137]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30,2024 |  | September 30,2023 |  | September 30,2024 |  | September 30,2023 |
| RSUs | $ | 54.8 |  |  | $ | 54.2 |  |  | $ | 160.8 |  |  | $ | 158.4 |  |
| Stock options | 6.9 |  |  | 7.5 |  |  | 21.3 |  |  | 21.5 |  |
| PSUs | 4.7 |  |  | 3.2 |  |  | 11.6 |  |  | 7.7 |  |
| Total stock-based compensation expense | $ | 66.4 |  |  | $ | 64.9 |  |  | $ | 193.7 |  |  | $ | 187.6 |  |

[0001262039-24-000043:notes:138]
[same as prior period, unchanged from 0001262039-24-000037:notes:119]

[0001262039-24-000043:notes:139]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30,2024 |  | September 30,2023 |  | September 30,2024 |  | September 30,2023 |
| Income tax benefit associated with stock-based compensation | $ | 14.7 |  |  | $ | 14.3 |  |  | $ | 42.9 |  |  | $ | 41.4 |  |

[0001262039-24-000043:notes:140]
[same as prior period, unchanged from 0001262039-24-000037:notes:121]

[0001262039-24-000043:notes:141]
[same as prior period, unchanged from 0001262039-24-000037:notes:122]

[0001262039-24-000043:notes:142]
During the three and nine months ended September 30, 2024, we repurchased less than 0.1 million shares of our common stock under the Repurchase Program in open-market transactions, at a weighted-average price of $54.99 per share, for an aggregate purchase price of $0.6 million. As of September 30, 2024, $1.03 billion remained available for future share repurchases under the Repurchase Program. Refer to Note 16, Subsequent Events, for information regarding the October 2024 approval of a $1.0 billion increase in the authorized stock repurchase amount under the Repurchase Program and the extension of the Repurchase Program to February 28, 2026.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001262039-24-000043:notes:143]
INCOME TAXES
Our effective tax rate was 13% for the three months ended September 30, 2024, compared to an effective tax rate of 0% for the same period last year. Our effective tax rate was 14% for the nine months ended September 30, 2024, compared to an effective tax rate of 5% for the same period last year. The tax rates for the three months ended September 30, 2024 and 2023 were comprised of U.S. federal and state taxes, withholding taxes and foreign taxes that amounted to $123.6 million and $50.2 million, respectively. The tax rate for the three months ended September 30, 2024 was impacted by a tax benefit of $33.1 million from the foreign-derived intangible income (“FDII”) deduction, and excess tax benefits from stock-based compensation expense of $9.3 million. The tax rate for the three months ended September 30, 2023 was impacted by a tax benefit of $41.9 million from the FDII deduction, excess tax benefits from stock-based compensation expense of $8.6 million.

[0001262039-24-000043:notes:144]
The tax rates for the nine months ended September 30, 2024 and 2023 were comprised of U.S. federal and state taxes, withholding taxes and foreign taxes that amounted to $315.0 million and $220.9 million, respectively. The tax rate for the nine months ended September 30, 2024 was impacted by a tax benefit of $84.0 million from the FDII deduction, and excess tax benefits from stock-based compensation expense of $33.8 million. The tax rate for the nine months ended September 30, 2023 was impacted by a tax benefit of $105.9 million from the FDII deduction, excess tax benefits from stock-based compensation expense of $48.3 million, and the release of reserves of $18.1 million on uncertain tax positions and the accrued interest thereon due to the expiration of statutes of limitations.

[0001262039-24-000043:notes:145]
As of September 30, 2024 and December 31, 2023, unrecognized tax benefits were $72.3 million and $65.8 million, respectively. If recognized, $61.0 million of the unrecognized tax benefits as of September 30, 2024 would favorably affect our

[0001262039-24-000043:notes:146]
effective tax rate. It is our policy to include accrued interest and penalties related to unrecognized tax benefits in income tax expense. As of September 30, 2024 and December 31, 2023, accrued interest and penalties were $8.4 million and $6.4 million, respectively. It is reasonably possible that our gross unrecognized tax benefits will decrease by up to $1.4 million in the next 12 months, due to the lapse of statutes of limitation in various jurisdictions. This decrease, if recognized, would favorably impact our effective tax rate, and would be recognized as an additional tax benefit.

[0001262039-24-000043:notes:147]
As of September 30, 2024, our deferred tax assets were $1.30 billion, an increase of $301.9 million over the prior quarter. The increase was primarily due to the acquisition of Lacework, the opening balance sheet of which included deferred tax assets of $244.4 million primarily related to pre-acquisition federal net operating loss carryforwards with an indefinite carryforward period.

[0001262039-24-000043:notes:148]
[same as prior period, unchanged from 0001262039-24-000037:notes:128]

[0001262039-24-000043:notes:149]
On January 4, 2022, the U.S. Treasury published another tranche of final regulations regarding the foreign tax credit. These final regulations impose new requirements that a foreign tax must meet in order to be creditable against U.S. income taxes, and generally apply to tax years beginning on or after December 28, 2021. On July 26, 2022, the U.S. Treasury released corrections to the final regulations. On July 21, 2023, the IRS released a notice that suspended the application of significant portions of the final regulations regarding the foreign tax credit for tax years 2022 and 2023. The notice released in July 2023 favorably impacted our ability to claim foreign tax credits in the United States for certain taxes imposed by certain foreign jurisdictions. On December 11, 2023, the IRS released a notice that extended the suspension of significant portions of the final regulations beyond December 31, 2023, until further guidance is issued. 
In December 2021, the Organisation for Economic Co-operation and Development (the “OECD”) enacted model rules for a new global minimum tax framework (“BEPS Pillar Two”), and various governments around the world have enacted, or are in the process of enacting, legislation on this. The OECD continues to release additional guidance on these rules. Based on the enacted laws, BEPS Pillar Two has no impact to our effective tax rate or cash flows for the nine months ended September 30, 2024. We will continue to evaluate the impact of these tax law changes on future reporting periods.


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0001262039-24-000043:notes:150]
DEFINED CONTRIBUTION PLANS
Our tax-deferred savings plan under our 401(k) Plan permits participating U.S. employees to contribute a portion of their pre-tax or after-tax earnings. In Canada, we have a Group Registered Retirement Savings Plan Program (the “RRSP”), which permits participants to make pre-tax contributions. Our board of directors approved 50% matching contributions on employee contributions up to 4% of each employee’s eligible earnings. Our matching contributions to our 401(k) Plan and the RRSP for the three months ended September 30, 2024 and 2023 were $4.6 million and $3.8 million, respectively. Our matching contributions to our 401(k) Plan and the RRSP for the nine months ended September 30, 2024 and 2023 were $15.2 million and $13.9 million, respectively.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001262039-24-000043:notes:151]
[same as prior period, unchanged from 0001262039-24-000037:notes:131]

[0001262039-24-000043:notes:152]
[same as prior period, unchanged from 0001262039-24-000037:notes:132]

[0001262039-24-000043:notes:153]
|  | Three Months Ended |  | Nine Months Ended |
| Revenue | September 30,2024 |  | September 30,2023 |  | September 30,2024 |  | September 30,2023 |
| Americas: |  |  |  |  |  |  |  |
| United States | $ | 455.1 |  |  | $ | 400.8 |  |  | $ | 1,297.9 |  |  | $ | 1,189.6 |  |
| Other Americas | 168.9 |  |  | 144.8 |  |  | 478.4 |  |  | 416.5 |  |
| Total Americas | 624.0 |  |  | 545.6 |  |  | 1,776.3 |  |  | 1,606.1 |  |
| Europe, Middle East and Africa (“EMEA”) | 599.3 |  |  | 512.2 |  |  | 1,703.9 |  |  | 1,497.3 |  |
| Asia Pacific (“APAC”) | 284.8 |  |  | 276.8 |  |  | 815.5 |  |  | 786.3 |  |
| Total revenue | $ | 1,508.1 |  |  | $ | 1,334.6 |  |  | $ | 4,295.7 |  |  | $ | 3,889.7 |  |

[0001262039-24-000043:notes:154]
| Property and Equipment—net | September 30,2024 |  | December 31,2023 |
| Americas: |  |  |  |
| United States | $ | 921.6 |  |  | $ | 701.6 |  |
| Canada | 213.7 |  |  | 212.8 |  |
| Latin America | 4.0 |  |  | 2.3 |  |
| Total Americas | 1,139.3 |  |  | 916.7 |  |
| EMEA | 70.9 |  |  | 65.5 |  |
| APAC | 63.2 |  |  | 62.2 |  |
| Total property and equipment—net | $ | 1,273.4 |  |  | $ | 1,044.4 |  |

[0001262039-24-000043:notes:155]
[same as prior period, unchanged from 0001262039-24-000037:notes:135]

[0001262039-24-000043:notes:156]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30,2024 |  | September 30,2023 |  | September 30,2024 |  | September 30,2023 |
| Distributor A | 27 | % |  | 28 | % |  | 29 | % |  | 28 | % |
| Distributor B | 15 | % |  | 15 | % |  | 15 | % |  | 15 | % |
| Distributor C | 12 | % |  | 13 | % |  | 13 | % |  | 14 | % |

[0001262039-24-000043:notes:157]
[same as prior period, unchanged from 0001262039-24-000037:notes:137]

[0001262039-24-000043:notes:158]
|  | September 30,2024 |  | December 31,2023 |
| Distributor A | 27 | % |  | 33 | % |
| Distributor B | 13 | % |  | 14 | % |
| Distributor C | 10 | % |  | 10 | % |


## us-gaap:SubsequentEventsTextBlock

[0001262039-24-000043:notes:159]
SUBSEQUENT EVENTS
Real Property Purchase

[0001262039-24-000043:notes:160]
In November 2024, we purchased real property in Atlanta, Georgia, for $15.8 million in cash.

[0001262039-24-000043:notes:161]
In October 2024, our board of directors approved a $1.0 billion increase in the authorized stock repurchase amount under the Repurchase Program and extended the term of the Repurchase Program to February 28, 2026, bringing the aggregate amount authorized to be repurchased to $8.25 billion of our outstanding common stock through February 28, 2026. As of November 8, 2024, approximately $2.03 billion remained available for future share repurchases.
