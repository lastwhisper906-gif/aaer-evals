# FTNT MD&A — 0001262039-24-000043


## mdna

[0001262039-24-000043:mdna:1]
[same as prior period, unchanged from 0001262039-24-000037:mdna:1]

[0001262039-24-000043:mdna:2]
[same as prior period, unchanged from 0001262039-24-000037:mdna:2]

[0001262039-24-000043:mdna:3]
[same as prior period, unchanged from 0001262039-24-000037:mdna:3]

[0001262039-24-000043:mdna:4]
[same as prior period, unchanged from 0001262039-24-000037:mdna:4]

[0001262039-24-000043:mdna:5]
[same as prior period, unchanged from 0001262039-24-000037:mdna:5]

[0001262039-24-000043:mdna:6]
[same as prior period, unchanged from 0001262039-24-000037:mdna:6]

[0001262039-24-000043:mdna:7]
•macroeconomic, geopolitical factors and other disruption on our manufacturing or sales, including the transition in administrations, public health issues, wars, natural disasters and economic growth;

[0001262039-24-000043:mdna:8]
[same as prior period, unchanged from 0001262039-24-000037:mdna:8]

[0001262039-24-000043:mdna:9]
[same as prior period, unchanged from 0001262039-24-000037:mdna:9]

[0001262039-24-000043:mdna:10]
[same as prior period, unchanged from 0001262039-24-000037:mdna:10]

[0001262039-24-000043:mdna:11]
[same as prior period, unchanged from 0001262039-24-000037:mdna:11]

[0001262039-24-000043:mdna:12]
[same as prior period, unchanged from 0001262039-24-000037:mdna:12]

[0001262039-24-000043:mdna:13]
[same as prior period, unchanged from 0001262039-24-000037:mdna:13]

[0001262039-24-000043:mdna:14]
[same as prior period, unchanged from 0001262039-24-000037:mdna:14]

[0001262039-24-000043:mdna:15]
[same as prior period, unchanged from 0001262039-24-000037:mdna:15]

[0001262039-24-000043:mdna:16]
[same as prior period, unchanged from 0001262039-24-000037:mdna:16]

[0001262039-24-000043:mdna:17]
[same as prior period, unchanged from 0001262039-24-000037:mdna:17]

[0001262039-24-000043:mdna:18]
[same as prior period, unchanged from 0001262039-24-000037:mdna:18]

[0001262039-24-000043:mdna:19]
[same as prior period, unchanged from 0001262039-24-000037:mdna:19]

[0001262039-24-000043:mdna:20]
[same as prior period, unchanged from 0001262039-24-000037:mdna:20]

[0001262039-24-000043:mdna:21]
[same as prior period, unchanged from 0001262039-24-000037:mdna:21]

[0001262039-24-000043:mdna:22]
[same as prior period, unchanged from 0001262039-24-000037:mdna:22]

[0001262039-24-000043:mdna:23]
[same as prior period, unchanged from 0001262039-24-000037:mdna:23]

[0001262039-24-000043:mdna:24]
[same as prior period, unchanged from 0001262039-24-000037:mdna:24]

[0001262039-24-000043:mdna:25]
[same as prior period, unchanged from 0001262039-24-000037:mdna:25]

[0001262039-24-000043:mdna:26]
•expected outcomes and liabilities in litigation;

[0001262039-24-000043:mdna:27]
[same as prior period, unchanged from 0001262039-24-000037:mdna:27]

[0001262039-24-000043:mdna:28]
[same as prior period, unchanged from 0001262039-24-000037:mdna:28]

[0001262039-24-000043:mdna:29]
[same as prior period, unchanged from 0001262039-24-000037:mdna:29]

[0001262039-24-000043:mdna:30]
[same as prior period, unchanged from 0001262039-24-000037:mdna:30]

[0001262039-24-000043:mdna:31]
Fortinet is a leader in cybersecurity and the convergence of networking and security. Our mission is to secure people, devices and data everywhere. Our integrated platform, the Fortinet Security Fabric, spans secure networking, unified SASE and AI-driven security operations. As of September 30, 2024, our end-customers were located in over 100 countries and included enterprises such as in the financial services, retail, healthcare and operational technology market verticals, communication and security service providers, and government organizations. We currently have approximately 77% of the Fortune 100 companies and approximately 71% of the Global 2000 companies as customers. As a global company headquartered in Sunnyvale, California our research and development is centered in the United States and Canada with a global footprint of support and centers of excellence around the world. As of September 30, 2024, we held 1,027 U.S. patents and 1,371 global patents and we are recognized in over 130 enterprise analyst reports demonstrating both our vision and execution across security and networking products.

[0001262039-24-000043:mdna:32]
•Secure Networking—Our Secure Networking solutions focus on the convergence of networking and security via FortiOS, our networking and security operating system that is the foundation of our Fortinet Security Fabric platform and supports over 30 functions that can be delivered via a physical, virtual, cloud or software as a service (“SaaS”) solution. When delivered via our network firewall appliances, functionality is accelerated through our proprietary ASIC technology. These proprietary ASICs, allow our systems to scale, run multiple applications at higher performance, lower power consumption and perform more processor-intensive operations, such as inspecting encrypted traffic, including streaming video. Fortinet’s network firewall offerings consist of a FortiGate data center, hyperscale and distributed firewalls, as well as encrypted applications (SSL inspection, virtual private network and IPsec connectivity). Our ability to converge networking and security also enables the ethernet to become an extension

[0001262039-24-000043:mdna:33]
of our customers’ security infrastructure through FortiSwitch and FortiLink. Our wireless LAN solution leverages secure networking to provide secure wireless access for the enterprise LAN edge. FortiExtender secures 5G/LTE and remote ethernet extenders to connect and secure any branch environment. Fortinet’s Secure Connectivity solution includes FortiSwitch secure ethernet switches, FortiAP wireless local area network access points and FortiExtender 5G connectivity gateways.

[0001262039-24-000043:mdna:34]
•Unified Secure Access Service Edge (SASE)—As applications move to the cloud and work from anywhere is now the norm, cloud delivery enables secure access to applications on any cloud. The Fortinet Unified SASE solution includes an industry-leading single-vendor SASE solution that includes firewall, SD-WAN, secure web gateway, cloud access services broker, DLP, and zero trust network access. Fortinet is one of the few vendors to deliver consistent convergence and AI-powered security across Secure SD-WAN and SSE to enable a single-vendor SASE framework with a unique, cloud-centric architecture powered by FortiOS. Given this, Fortinet is well positioned to support customers transitioning from SD-WAN to a single-vendor SASE platform. Additionally, Fortinet offers a full suite of cloud security products that enable customers to secure their applications from code to cloud, including web application firewalls, virtualized firewalls and cloud-native firewalls, among other products.

[0001262039-24-000043:mdna:35]
•AI-Driven Security Operations (SecOps)—Fortinet’s AI-Driven Security Operations portfolio offers a broad range of cybersecurity solutions that identify, protect, detect, respond, and recover from cyberthreats, all tightly integrated within the Fortinet Security Fabric. Fortinet’s SecOps solution includes FortiAnalyzer, FortiSIEM security information and event management, FortiSOAR security orchestration, automation and response, for SOC Analytics and Automation, FortiEDR endpoint detection and response, FortiXDR extended detection and response, FortiMDR managed detection and response service, FortiNDR network detection and response, FortiSandbox sandboxing, and FortiDeceptor deception technology for behavioral detection and response, FortiRecon as digital risk protection. FortiGuard services include SOCaaS, and Incident Response to effectively address staff shortages by providing expert oversight and rapid response. To further enhance operational efficiency, the FortiAI generative AI assistance ensures that organizations are well equipped to navigate the evolving threat landscape.

[0001262039-24-000043:mdna:36]
[same as prior period, unchanged from 0001262039-24-000037:mdna:36]

[0001262039-24-000043:mdna:37]
FortiCare Technical Support Service is a per-device technical support service, which provides customers access to experts to ensure efficient and effective operations and maintenance of their Fortinet capabilities. Global technical support is offered 24x7 with flexible add-ons, including enhanced SLAs and premium hardware replacement through in-country depots. Organizations have the flexibility to procure different levels of service for different devices based on their availability needs. We offer three per-device support options tailored to the needs of our enterprise customers: FortiCare Premium, FortiCare Elite and FortiCare Essential. The FortiCare Elite service aims to provide a 15-minute response time for key product families.

[0001262039-24-000043:mdna:38]
Additionally, we are committed to addressing the cybersecurity skills shortage through training and certification programs for customers, partners and employees. The Fortinet Training Institute’s ecosystem of public and private partnerships around the world extend to industry, academia, government and nonprofits to ensure we are reaching and increasing access of our cybersecurity certifications and training to all populations. The Fortinet Training Institute has issued over 1 million certifications to date.

[0001262039-24-000043:mdna:39]
[same as prior period, unchanged from 0001262039-24-000037:mdna:39]

[0001262039-24-000043:mdna:40]
•Total revenue was $1.51 billion and $4.30 billion during the three and nine months ended September 30, 2024, an increase of 13% and 10%, respectively, compared to $1.33 billion and $3.89 billion in the same periods last year. Our revenue growth was driven by the growth in service revenue. Product revenue was $473.9 million and $1.33 billion during the three and nine months ended September 30, 2024, an increase of 2% and a decrease of 7%, respectively, compared to $465.9 million and $1.44 billion in the same periods last year. Service revenue was $1.03 billion and $2.96 billion during the three and nine months ended September 30, 2024, an increase of 19% and 21%, respectively, compared to $868.7 million and $2.45 billion in the same periods last year.

[0001262039-24-000043:mdna:41]
•Total gross profit was $1.24 billion and $3.45 billion during the three and nine months ended September 30, 2024, an increase of 22% and 16%, respectively, compared to $1.02 billion and $2.97 billion in the same periods last year.

[0001262039-24-000043:mdna:42]
•Total gross margin was 82.5% and 80.4% during the three and nine months ended September 30, 2024, an increase of 6.3 and 4.1 percentage points, respectively, compared to 76.2% and 76.3% in the same periods last year.

[0001262039-24-000043:mdna:43]
•Operating income was $470.9 million and $1.23 billion during the three and nine months ended September 30, 2024, an increase of 55% and 44%, respectively, compared to $303.2 million and $855.7 million in the same periods last year.

[0001262039-24-000043:mdna:44]
•Operating margin was 31.2% and 28.6% during the three and nine months ended September 30, 2024, an increase of 8.5 and 6.6 percentage points, respectively, compared to 22.7% and 22.0% in the same periods last year.

[0001262039-24-000043:mdna:45]
•Cash, cash equivalents, short-term and long-term investments and marketable equity securities were $3.70 billion as of September 30, 2024.

[0001262039-24-000043:mdna:46]
•Deferred revenue was $6.01 billion, including short-term deferred revenue of $3.08 billion, as of September 30, 2024.

[0001262039-24-000043:mdna:47]
•Cash flows from operating activities were $1.78 billion during the nine months ended September 30, 2024, an increase of $36.7 million, or 2%, compared to the same period last year.

[0001262039-24-000043:mdna:48]
•On August 1, 2024, we closed an acquisition of Lacework, a privately held data-driven cloud security company, with a goal of offering its CNAPP solution separately as well as integrated with our existing portfolio, forming a comprehensive, AI-driven cloud security platform available from a single vendor, which will help customers identify, prioritize, and remediate risks and threats in complex cloud-native infrastructure from code to cloud. On August 5, 2024, we completed the acquisition of Next DLP, a privately held insider risk and DLP company. From August 2024 to September 2024, revenue from these two acquired companies was $13.8 million, or 0.9% and 0.3% of total revenue during the three and nine months ended September 30, 2024, respectively.

[0001262039-24-000043:mdna:49]
On a geographic basis, revenue continues to be diversified globally, which remains a key strength of our business. During the three months ended September 30, 2024, the Americas region, the Europe, Middle East and Africa (“EMEA”) region, and the Asia Pacific (“APAC”) region contributed 41%, 40% and 19% of our total revenue, respectively and increased 14%, 17%, and 3% compared to the same period last year, respectively. During the nine months ended September 30, 2024, the Americas, EMEA, and APAC regions contributed 41%, 40% and 19% of our total revenue, respectively, and increased by 11%, 14% and 4% compared to the same period last year, respectively.

[0001262039-24-000043:mdna:50]
Product revenue increased 2% during the three months ended September 30, 2024 compared to the same period last year. Product revenue decreased 7% during the nine months ended September 30, 2024 compared to the same period last year, due to the decrease in hardware revenue, partially offset by the increase in software license revenue. The decrease in hardware revenue was impacted by the change in backlog from hardware shipped in the prior periods and macroeconomic conditions. When we fulfill, ship and bill during a quarter to satisfy backlog, this increases our aggregate billings and revenue during any particular quarter. As the supply chain challenges normalize, our product revenue growth rate may be lower versus prior quarters where delivery from backlog contributed more to billings.

[0001262039-24-000043:mdna:51]
Service revenue growth during the three and nine months ended September 30, 2024 was 19% and 21%, respectively, as compared to the same periods last year, was primarily driven by the strength of our security subscription revenue, which grew 20% and 23%, respectively. The increase was primarily due to the recognition of service revenue from our growing deferred revenue balance related to FortiGuard and other security subscriptions delivered to on-premise and cloud-based environments and strength in unified SASE and SecOps. We expect our service revenue to continue to grow for the remainder of 2024, with growth opportunities that include unified SASE and SecOps offerings. While service revenue is expected to grow, we anticipate that the growth rates will ease for the remainder of 2024 due to slowing deferred revenue over the past several quarters.

[0001262039-24-000043:mdna:52]
Our billings were diversified on a geographic basis. During the three months ended September 30, 2024, six countries represented approximately 50% of our billings and the remaining 50% in the aggregate were from over 100 countries that each individually contributed less than 3% of our billings.

[0001262039-24-000043:mdna:53]
Total gross margin increased 6.3 and 4.1 percentage points, respectively, during the three and nine months ended September 30, 2024 compared to the same periods last year, primarily driven by increased product and service gross margin and a shift in the revenue mix to higher margin service revenue. We expect our gross margin to increase for full year 2024 compared to full year 2023.

[0001262039-24-000043:mdna:54]
[same as prior period, unchanged from 0001262039-24-000037:mdna:73]

[0001262039-24-000043:mdna:55]
Operating expenses as a percentage of revenue decreased 2.2 and 2.5 percentage points, respectively, during the three and nine months ended September 30, 2024 compared to the same periods last year, mainly because our revenue growth outpaced our headcount growth. Headcount increased to 13,986 employees and contractors as of September 30, 2024, a 3% increase compared to 13,568 as of December 31, 2023. We expect our operating expenses as a percentage of revenue to decrease for full year 2024 compared to full year 2023.

[0001262039-24-000043:mdna:56]
Operating margin has improved 8.5 and 6.6 percentage points, respectively, during the three and nine months ended September 30, 2024, as a result of improvement in gross margin and decrease in operating expenses as a percentage of revenue. We expect our operating margin to increase for full year 2024 compared to full year 2023.

[0001262039-24-000043:mdna:57]
[same as prior period, unchanged from 0001262039-24-000037:mdna:53]

[0001262039-24-000043:mdna:58]
Our overall performance depends in part on worldwide economic and geopolitical conditions, such as GDP growth, the war in Ukraine and the Israel-Hamas war or tensions between China and Taiwan, and their impact on customer behavior. Worsening economic conditions, including inflation, changing interest rates, slower growth, any recession, fluctuations in foreign exchange rates and other changes in economic conditions, may result in decreased sales productivity and growth and adversely affect our results of operations and financial performance. We have seen certain impacts on our business, results of operations, financial condition, cash flows, liquidity and capital and financial resources such as longer sales cycles, delayed purchases and increased commitments with certain suppliers and increased inventory and inventory purchase commitment reserves.

[0001262039-24-000043:mdna:59]
[same as prior period, unchanged from 0001262039-24-000037:mdna:55]

[0001262039-24-000043:mdna:60]
[same as prior period, unchanged from 0001262039-24-000037:mdna:56]

[0001262039-24-000043:mdna:61]
We typically sell our security solutions to distributors that sell to networking security focused resellers and to certain service providers and managed security service providers (“MSSPs”), who, in turn, sell to end-customers or use our products and services to provide hosted solutions to other enterprises. At times, we also sell directly to enterprise customers, service providers and systems integrators. In addition, we sell our software licenses and services via different cloud service provider platforms, both directly and through our channel partners. Our end-customers are located in over 100 countries and include small, medium and large enterprises and government organizations across a wide range of industries, including financial services, government, healthcare, manufacturing, retail, technology and telecommunications. An end-customer deployment may involve as few as one or as many as thousands of secure networking, unified SASE and security operations technology products, depending on the end-customer’s size and security requirements.

[0001262039-24-000043:mdna:62]
Our customers purchase our hardware products, software licenses and cloud-delivered solutions, including our FortiGuard security subscription, FortiCare technical support services, unified SASE and SecOps services. We generally invoice at the time of our sale for the total price of the products and services. Standard payment terms are generally no more than 60 days, though we may offer extended payment terms to certain distributors or certain transactions.

[0001262039-24-000043:mdna:63]
We offer our products hosted in our own data centers, PoPs, and through co-locations and major cloud service providers, including Microsoft Azure, Amazon Web Services and Google Cloud.

[0001262039-24-000043:mdna:64]
[same as prior period, unchanged from 0001262039-24-000037:mdna:60]

[0001262039-24-000043:mdna:65]
We monitor several key metrics, including the key financial metrics set forth below, in order to help us evaluate growth trends, establish budgets, measure the effectiveness of our sales and marketing efforts, and assess operational efficiencies. The following table summarizes revenue, deferred revenue, billings (non-GAAP), net cash provided by operating activities, and free cash flow (non-GAAP). We discuss revenue below under “Results of Operations,” and we discuss net cash

[0001262039-24-000043:mdna:66]
provided by operating activities below under “—Liquidity and Capital Resources.” Deferred revenue, billings (non-GAAP), and free cash flow (non-GAAP) are discussed immediately below the following table:

[0001262039-24-000043:mdna:67]
|  | Three Months Ended Or As Of |
|  | September 30, 2024 |  | September 30, 2023 |
|  | (in millions) |
| Revenue | $ | 1,508.1 |  |  | $ | 1,334.6 |  |
| Deferred revenue | $ | 6,011.7 |  |  | $ | 5,285.3 |  |
| Billings (non-GAAP) | $ | 1,582.2 |  |  | $ | 1,491.3 |  |
| Net cash provided by operating activities | $ | 608.1 |  |  | $ | 551.2 |  |
| Free cash flow (non-GAAP) | $ | 571.8 |  |  | $ | 481.1 |  |

[0001262039-24-000043:mdna:68]
Deferred revenue. Our deferred revenue consists of amounts that have been invoiced but that have not yet been recognized as revenue. The majority of our deferred revenue balance consists of the unrecognized portion of service revenue from FortiGuard and other security subscriptions and FortiCare technical support service contracts, which is recognized as revenue ratably over the service term. We monitor our deferred revenue balance, short-term and total deferred revenue growth and the mix of short-term and long-term deferred revenue because deferred revenue represents a significant portion of free cash flow and of revenue to be recognized in future periods. Deferred revenue was $6.01 billion as of September 30, 2024, an increase of $276.7 million, or 5%, from December 31, 2023. Short term deferred revenue was $3.08 billion as of September 30, 2024, an increase of $232.5 million, or 8%, from December 31, 2023.

[0001262039-24-000043:mdna:69]
Billings (non-GAAP). We define billings as revenue recognized in accordance with GAAP plus the change in deferred revenue from the beginning to the end of the period less any deferred revenue balances acquired from business combination(s) during the period. We consider billings to be a useful metric for management and investors because billings drive current and future revenue, which is an important indicator of the health and viability of our business. There are a number of limitations related to the use of billings instead of GAAP revenue. First, billings include amounts that have not yet been recognized as revenue and are impacted by the term of security and support agreements. Second, we may calculate billings in a manner that is different from peer companies that report similar financial measures. Management accounts for these limitations by providing specific information regarding GAAP revenue and evaluating billings together with GAAP revenue. Total billings were $1.58 billion for the three months ended September 30, 2024, an increase of 6% compared to $1.49 billion in the same period last year.

[0001262039-24-000043:mdna:70]
Our backlog may fluctuate over quarters. A reduction to backlog increases our aggregate billings and revenue during the quarter when delivered. If we experience supply chain shortages and cannot fulfill orders or if customers cancel or delay delivery of orders, our backlog may be affected, which will negatively impact our aggregate backlog to billings conversion and revenue in such quarter, and as the supply chain challenges normalized, our product revenue growth rate may be lower versus prior quarters where delivery from backlog contributed more to billings.

[0001262039-24-000043:mdna:71]
[same as prior period, unchanged from 0001262039-24-000037:mdna:66]

[0001262039-24-000043:mdna:72]
|  | Three Months Ended |
|  | September 30, 2024 |  | September 30, 2023 |
|  | (in millions) |
| Billings: |  |  |  |
| Revenue | $ | 1,508.1 |  |  | $ | 1,334.6 |  |
| Add: Change in deferred revenue | 115.5 |  |  | 156.7 |  |
| Less: Deferred revenue balance acquired in business combinations | (41.4) |  |  | — |  |
| Total billings (non-GAAP) | $ | 1,582.2 |  |  | $ | 1,491.3 |  |

[0001262039-24-000043:mdna:73]
Free cash flow (non-GAAP). We define free cash flow as net cash provided by operating activities minus purchases of property and equipment. We believe free cash flow to be a liquidity measure that provides useful information to management and investors about the amount of cash generated by the business that, after capital expenditures, can be used for strategic opportunities, including repurchasing outstanding common stock, investing in our business, making strategic acquisitions and strengthening the balance sheet. A limitation of using free cash flow rather than the GAAP measures of cash provided by or used in operating activities, investing activities, and financing activities is that free cash flow does not represent the total increase or decrease in the cash and cash equivalents balance for the period because it excludes investing activities other than

[0001262039-24-000043:mdna:74]
capital expenditures and cash flows from financing activities. Management accounts for this limitation by providing information about our capital expenditures and other investing and financing activities on the condensed consolidated statements of cash flows and under “—Liquidity and Capital Resources” and by presenting cash flows from investing and financing activities in our reconciliation of free cash flow. In addition, it is important to note that other companies, including companies in our industry, may not use free cash flow, may calculate free cash flow in a different manner than we do or may use other financial measures to evaluate their performance, all of which could reduce the usefulness of free cash flow as a comparative measure. A reconciliation of net cash provided by operating activities, the most directly comparable financial measure calculated and presented in accordance with GAAP, to free cash flow is provided below:

[0001262039-24-000043:mdna:75]
|  | Three Months Ended |
|  | September 30, 2024 |  | September 30, 2023 |
|  | (in millions) |
| Free Cash Flow: |  |  |  |
| Net cash provided by operating activities | $ | 608.1 |  |  | $ | 551.2 |  |
| Less: Purchases of property and equipment | (36.3) |  |  | (70.1) |  |
| Free cash flow (non-GAAP) | $ | 571.8 |  |  | $ | 481.1 |  |
| Net cash used in investing activities | $ | (327.1) |  |  | $ | (111.2) |  |
| Net cash provided by (used in) financing activities | $ | 3.0 |  |  | $ | (628.9) |  |

[0001262039-24-000043:mdna:76]
[same as prior period, unchanged from 0001262039-24-000037:mdna:70]

[0001262039-24-000043:mdna:77]
[same as prior period, unchanged from 0001262039-24-000037:mdna:71]

[0001262039-24-000043:mdna:78]
There were no material changes to our critical accounting policies and estimates as of and for the three and nine months ended September 30, 2024, as compared to the critical accounting policies and estimates described in our Annual Report on Form 10-K filed with the SEC on February 26, 2024 (the “Form 10-K”).

[0001262039-24-000043:mdna:79]
[same as prior period, unchanged from 0001262039-24-000037:mdna:74]

[0001262039-24-000043:mdna:80]
34

[0001262039-24-000043:mdna:81]
[same as prior period, unchanged from 0001262039-24-000037:mdna:75]

[0001262039-24-000043:mdna:82]
Three Months Ended September 30, 2024 and 2023

[0001262039-24-000043:mdna:83]
[same as prior period, unchanged from 0001262039-24-000037:mdna:77]

[0001262039-24-000043:mdna:84]
|  | Three Months Ended |  |  |  |  |
| September 30,2024 |  | September 30,2023 |  |  |  |  |
| Amount |  | % ofRevenue |  | Amount |  | % ofRevenue |  | Change |  | % Change |
| (in millions, except percentages) |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 473.9 |  |  | 31 | % |  | $ | 465.9 |  |  | 35 | % |  | $ | 8.0 |  |  | 2 | % |
| Service | 1,034.2 |  |  | 69 |  |  | 868.7 |  |  | 65 |  |  | 165.5 |  |  | 19 |  |
| Total revenue | $ | 1,508.1 |  |  | 100 | % |  | $ | 1,334.6 |  |  | 100 | % |  | $ | 173.5 |  |  | 13 | % |
| Revenue by geography: |  |  |  |  |  |  |  |  |  |  |  |
| Americas | $ | 624.0 |  |  | 41 | % |  | $ | 545.6 |  |  | 41 | % |  | $ | 78.4 |  |  | 14 | % |
| EMEA | 599.3 |  |  | 40 |  |  | 512.2 |  |  | 38 |  |  | 87.1 |  |  | 17 |  |
| APAC | 284.8 |  |  | 19 |  |  | 276.8 |  |  | 21 |  |  | 8.0 |  |  | 3 |  |
| Total revenue | $ | 1,508.1 |  |  | 100 | % |  | $ | 1,334.6 |  |  | 100 | % |  | $ | 173.5 |  |  | 13 | % |

[0001262039-24-000043:mdna:85]
Total revenue increased $173.5 million, or 13%, during the three months ended September 30, 2024 compared to the same period last year. We continued to experience diversification of revenue geographically, and across customer and industry segments. Revenue from all regions grew, with EMEA contributing the largest portion of the increase on an absolute dollar basis and on a percentage basis.

[0001262039-24-000043:mdna:86]
Product revenue increased $8.0 million, or 2%, during the three months ended September 30, 2024 compared to the same period last year due to the increase in software license revenue.

[0001262039-24-000043:mdna:87]
Service revenue increased $165.5 million, or 19%, during the three months ended September 30, 2024 compared to the same period last year. Security subscription revenue increased $101.2 million, or 20%, and technical support and other services revenue increased $64.3 million, or 17%, during the three months ended September 30, 2024 compared to the same period last year. The increase was primarily due to the recognition of revenue from our growing deferred revenue balance related to FortiGuard and other security subscriptions delivered to on-premise and cloud-based environments and growth in SaaS solutions, including unified SASE and SecOps.

[0001262039-24-000043:mdna:88]
Of the service revenue recognized during the three months ended September 30, 2024, 88% was included in the deferred revenue balance as of June 30, 2024. Of the service revenue recognized during the three months ended September 30, 2023, 88% was included in the deferred revenue balance as of June 30, 2023.

[0001262039-24-000043:mdna:89]
[same as prior period, unchanged from 0001262039-24-000037:mdna:84]

[0001262039-24-000043:mdna:90]
|  | Three Months Ended |  |  |  |  |
| September 30,2024 |  | September 30,2023 |  | Change |  | % Change |
| (in millions, except percentages) |
| Cost of revenue: |  |  |  |  |  |  |  |
| Product | $ | 136.1 |  |  | $ | 198.3 |  |  | $ | (62.2) |  |  | (31) | % |
| Service | 127.3 |  |  | 119.4 |  |  | 7.9 |  |  | 7 |  |
| Total cost of revenue | $ | 263.4 |  |  | $ | 317.7 |  |  | $ | (54.3) |  |  | (17) | % |
| Gross margin (%): |  |  |  |  |  |  |  |
| Product | 71.3 | % |  | 57.4 | % |  |  |  |  |
| Service | 87.7 |  |  | 86.3 |  |  |  |  |  |
| Total gross margin | 82.5 | % |  | 76.2 | % |  |  |  |  |

[0001262039-24-000043:mdna:91]
[same as prior period, unchanged from 0001262039-24-000037:mdna:114]

[0001262039-24-000043:mdna:92]
Total gross margin increased 6.3 percentage points during the three months ended September 30, 2024 compared to the same period last year, primarily driven by increased product and service gross margin and a shift in the revenue mix to higher margin service revenue, partially offset by the impact of the acquisitions in the current quarter. Revenue mix shifted by 3.5 percentage points from product revenue to service revenue, as a percentage of total revenue.

[0001262039-24-000043:mdna:93]
Product gross margin increased 13.9 percentage points during the three months ended September 30, 2024 compared to the same period last year, primarily due to a reduction in our liability related to renegotiation of supplier contractual commitments which resulted in a reduction to cost of sales during the period, lower expedite fees, a shift in revenue mix from hardware to software and lower freight costs, partially offset by increased direct cost. Cost of product revenue was comprised primarily of third-party contract manufacturers’ costs, costs of materials used in production and inventory reserves related to excess inventory and contractual delivery commitments.

[0001262039-24-000043:mdna:94]
Service gross margin increased 1.4 percentage points during the three months ended September 30, 2024 compared to the same period last year, because service revenue growth outpaced labor cost increase and benefited from a revenue mix shift towards higher margin security subscription services, partially offset by the impact of the acquisitions in the current quarter. Cost of service revenue was comprised primarily of personnel-related costs, third-party repair and contract fulfillment, data center costs, colocation and cloud provider fees, supplies and facility-related costs.

[0001262039-24-000043:mdna:95]
[same as prior period, unchanged from 0001262039-24-000037:mdna:89]

[0001262039-24-000043:mdna:96]
|  | Three Months Ended |  | Change |  | % Change |
| September 30,2024 |  | September 30,2023 |  |
| Amount |  | % ofRevenue |  | Amount |  | % ofRevenue |  |
| (in millions, except percentages) |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | $ | 187.3 |  |  | 12 | % |  | $ | 156.9 |  |  | 12 | % |  | $ | 30.4 |  |  | 19 | % |
| Sales and marketing | 515.9 |  |  | 34 |  |  | 504.4 |  |  | 38 |  |  | 11.5 |  |  | 2 |  |
| General and administrative | 71.7 |  |  | 5 |  |  | 53.5 |  |  | 4 |  |  | 18.2 |  |  | 34 |  |
| Gain on intellectual property matter | (1.1) |  |  | — |  |  | (1.1) |  |  | — |  |  | — |  |  | — |  |
| Total operating expenses | $ | 773.8 |  |  | 51 | % |  | $ | 713.7 |  |  | 53 | % |  | $ | 60.1 |  |  | 8 | % |
| Percentages have been rounded for presentation purposes and may differ from unrounded results. |

[0001262039-24-000043:mdna:97]
[same as prior period, unchanged from 0001262039-24-000037:mdna:91]

[0001262039-24-000043:mdna:98]
Research and development expense increased $30.4 million, or 19%, during the three months ended September 30, 2024 compared to the same period last year, primarily due to an increase of $26.6 million in personnel-related costs as a result of increased headcount and compensation rates to support the development of new products and continued enhancements to our existing products and the impact of the acquisitions in the current quarter. We currently intend to continue investing in our research and development organization, and expect research and development expense to increase in absolute dollars year over year during the remainder of 2024.

[0001262039-24-000043:mdna:99]
[same as prior period, unchanged from 0001262039-24-000037:mdna:93]

[0001262039-24-000043:mdna:100]
Sales and marketing expense increased $11.5 million, or 2%, during the three months ended September 30, 2024 compared to the same period last year, primarily due to an increase of $19.9 million in personnel-related costs and $2.6 million in cloud hosting services costs related to sales demonstrations. The increases were partially offset by a decrease of $10.4 million in marketing program and related expenses. We currently intend to continue making investments in sales and marketing resources critical to support our future growth and expect our sales and marketing expense to increase in absolute dollars year over year during the remainder of 2024.

[0001262039-24-000043:mdna:101]
[same as prior period, unchanged from 0001262039-24-000037:mdna:95]

[0001262039-24-000043:mdna:102]
General and administrative expense increased $18.2 million, or 34%, during the three months ended September 30, 2024 compared to the same period last year, primarily due to an increase of $12.0 million in legal related fees and other professional services fees and $3.8 million in personnel-related costs. We currently expect general and administrative expense to increase in absolute dollars year over year during the remainder of 2024.

[0001262039-24-000043:mdna:103]
[same as prior period, unchanged from 0001262039-24-000037:mdna:97]

[0001262039-24-000043:mdna:104]
We generated operating income of $470.9 million during the three months ended September 30, 2024, an increase of $167.7 million, or 55%, compared to $303.2 million in the same period last year. Operating margin was 31.2% during the three months ended September 30, 2024, compared to 22.7% in the same period last year. The increase in operating margin was primarily due to 6.3 percentage points increase in gross margin and 3.6 percentage points decrease in sales and marketing expense as a percentage of revenue, partially offset by 0.7 percentage points and 0.7 percentage points increases in general and administrative expense and research and development expense as a percentage of revenue, respectively. Excluding the acquisitions in the current quarter, operating margin was 33.6% during the three months ended September 30, 2024.

[0001262039-24-000043:mdna:105]
Interest income, interest expense, gain on bargain purchase and other income (expense)—net

[0001262039-24-000043:mdna:106]
|  | Three Months Ended |  |  |  |  |
| September 30,2024 |  | September 30,2023 |  | Change |  | % Change |
| (in millions, except percentages) |
| Interest income | $ | 42.4 |  |  | $ | 37.0 |  |  | $ | 5.4 |  |  | 15 | % |
| Interest expense | $ | (5.0) |  |  | $ | (5.4) |  |  | $ | 0.4 |  |  | (7) | % |
| Gain on bargain purchase | $ | 106.3 |  |  | $ | — |  |  | $ | 106.3 |  |  | 100 | % |
| Other income (expense)—net | $ | 11.8 |  |  | $ | (7.0) |  |  | $ | 18.8 |  |  | (269) | % |

[0001262039-24-000043:mdna:107]
Interest income increased $5.4 million during the three months ended September 30, 2024 compared to the same period last year, primarily as a result of higher investment balances. Interest income varies depending on our average investment balances during the period, types and mix of investments, and market interest rates. Interest expense remained comparatively flat during the three months ended September 30, 2024 compared to the same period last year. Gain on bargain purchase was $106.3 million during the three months ended September 30, 2024 and is related to our acquisition of Lacework. The $18.8 million change in other income (expense)—net during the three months ended September 30, 2024 compared to the same period last year, was primarily due to an increase of $13.4 million gain on marketable equity securities and a $5.7 million decrease in foreign currency exchange losses.

[0001262039-24-000043:mdna:108]
Provision for (benefit from) income taxes

[0001262039-24-000043:mdna:109]
|  | Three Months Ended |  | Change |  | % Change |
| September 30,2024 |  | September 30,2023 |  |
| (in millions, except percentages) |
| Provision for (benefit from) income taxes | $ | 81.2 |  |  | $ | (0.3) |  |  | $ | 81.5 |  |  | (27,167) | % |
| Effective tax rate (%) | 13 | % |  | — | % |  |  |  |  |

[0001262039-24-000043:mdna:110]
Our effective tax rate was 13% for the three months ended September 30, 2024 compared to an effective tax rate of 0% for the same period last year. The provision for income taxes for the three months ended September 30, 2024 was primarily comprised of U.S. federal and state taxes, withholding taxes and foreign taxes totaling $123.6 million, which were favorably affected by a tax benefit of $33.1 million from the foreign-derived intangible income deduction (the “FDII deduction”) and excess tax benefits from stock-based compensation expense of $9.3 million.

[0001262039-24-000043:mdna:111]
The provision for income taxes for the three months ended September 30, 2023 was comprised of U.S. federal and state taxes, withholding taxes, and foreign taxes totaling $50.2 million, which were favorably affected by a tax benefit of $41.9 million from the FDII deduction, excess tax benefits from stock-based compensation expense of $8.6 million.

[0001262039-24-000043:mdna:112]
[same as prior period, unchanged from 0001262039-24-000037:mdna:106]

[0001262039-24-000043:mdna:113]
|  | Three Months Ended |  | Change |  | % Change |
| September 30,2024 |  | September 30,2023 |  |
| (in millions, except percentages) |
| Loss from equity method investments | $ | (5.3) |  |  | $ | (5.2) |  |  | $ | (0.1) |  |  | 2 | % |

[0001262039-24-000043:mdna:114]
[same as prior period, unchanged from 0001262039-24-000037:mdna:135]

[0001262039-24-000043:mdna:115]
Loss from equity method investments remained comparatively flat during the three months ended September 30, 2024 compared to the same period last year.

[0001262039-24-000043:mdna:116]
Nine Months Ended September 30, 2024 and 2023

[0001262039-24-000043:mdna:117]
[same as prior period, unchanged from 0001262039-24-000037:mdna:110]

[0001262039-24-000043:mdna:118]
|  | Nine Months Ended |  |  |  |  |
| September 30,2024 |  | September 30,2023 |  |  |  |  |
| Amount |  | % ofRevenue |  | Amount |  | % ofRevenue |  | Change |  | % Change |
| (in millions, except percentages) |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 1,334.7 |  |  | 31 | % |  | $ | 1,439.2 |  |  | 37 | % |  | $ | (104.5) |  |  | (7) | % |
| Service | 2,961.0 |  |  | 69 |  |  | 2,450.5 |  |  | 63 |  |  | 510.5 |  |  | 21 |  |
| Total revenue | $ | 4,295.7 |  |  | 100 | % |  | $ | 3,889.7 |  |  | 100 | % |  | $ | 406.0 |  |  | 10 | % |
| Revenue by geography: |  |  |  |  |  |  |  |  |  |  |  |
| Americas | $ | 1,776.3 |  |  | 41 | % |  | $ | 1,606.1 |  |  | 41 | % |  | $ | 170.2 |  |  | 11 | % |
| EMEA | 1,703.9 |  |  | 40 |  |  | 1,497.3 |  |  | 39 |  |  | 206.6 |  |  | 14 |  |
| APAC | 815.5 |  |  | 19 |  |  | 786.3 |  |  | 20 |  |  | 29.2 |  |  | 4 |  |
| Total revenue | $ | 4,295.7 |  |  | 100 | % |  | $ | 3,889.7 |  |  | 100 | % |  | $ | 406.0 |  |  | 10 | % |

[0001262039-24-000043:mdna:119]
Total revenue increased $406.0 million, or 10%, during the nine months ended September 30, 2024 compared to the same period last year. We continued to experience diversification of revenue geographically, and across customer and industry segments. Revenue from all regions grew, with EMEA contributing the largest portion of the increase on an absolute dollar basis and on a percentage basis.

[0001262039-24-000043:mdna:120]
Product revenue decreased $104.5 million, or 7%, during the nine months ended September 30, 2024 compared to the same period last year, due to the decrease in hardware revenue, partially offset by the increase in software license revenue. The decrease in hardware revenue was impacted by the change in backlog from hardware shipped in the prior periods and macroeconomic conditions. When we fulfill, ship and bill during a quarter to satisfy backlog, this increases our aggregate billings and revenue during any particular quarter. As the supply chain challenges normalize, our product revenue growth rate may be lower versus prior quarters where delivery from backlog contributed more to billings.

[0001262039-24-000043:mdna:121]
Service revenue increased $510.5 million, or 21%, during the nine months ended September 30, 2024 compared to the same period last year. Security subscription revenue increased $317.8 million, or 23%, and technical support and other services revenue increased $192.7 million, or 18%, during the nine months ended September 30, 2024 compared to the same period last year. The increase was primarily due to the recognition of revenue from our growing deferred revenue balance related to FortiGuard and other security subscriptions delivered to on-premise and cloud-based environments and growth in SaaS solutions, including unified SASE and SecOps.

[0001262039-24-000043:mdna:122]
Of the service revenue recognized during the nine months ended September 30, 2024, 77% was included in the deferred revenue balance as of December 31, 2023. Of the service revenue recognized during the nine months ended September 30, 2023, 73% was included in the deferred revenue balance as of December 31, 2022. We expect service revenue growth rates to ease for the remainder of 2024 due to slowing deferred revenue over the past several quarters, partially offset by increases in SaaS revenue.

[0001262039-24-000043:mdna:123]
[same as prior period, unchanged from 0001262039-24-000037:mdna:144]

[0001262039-24-000043:mdna:124]
[same as prior period, unchanged from 0001262039-24-000037:mdna:117]

[0001262039-24-000043:mdna:125]
|  | Nine Months Ended |  |  |  |  |
| September 30,2024 |  | September 30,2023 |  | Change |  | % Change |
| (in millions, except percentages) |
| Cost of revenue: |  |  |  |  |  |  |  |
| Product | $ | 474.0 |  |  | $ | 566.4 |  |  | $ | (92.4) |  |  | (16) | % |
| Service | 369.1 |  |  | 354.9 |  |  | 14.2 |  |  | 4 | % |
| Total cost of revenue | $ | 843.1 |  |  | $ | 921.3 |  |  | $ | (78.2) |  |  | (8) | % |
| Gross margin (%): |  |  |  |  |  |  |  |
| Product | 64.5 | % |  | 60.6 | % |  |  |  |  |
| Service | 87.5 |  |  | 85.5 |  |  |  |  |  |
| Total gross margin | 80.4 | % |  | 76.3 | % |  |  |  |  |

[0001262039-24-000043:mdna:126]
Total gross margin increased 4.1 percentage points during the nine months ended September 30, 2024 compared to the same period last year, primarily driven by a shift in the revenue mix to higher margin service revenue and increased product and service gross margin. Revenue mix shifted by 5.9 percentage points from product revenue to service revenue, as a percentage of total revenue.

[0001262039-24-000043:mdna:127]
Product gross margin increased 3.9 percentage points during the nine months ended September 30, 2024 compared to the same period last year, primarily due to decrease in inventory related reserves expense, lower expedite fees, a shift in revenue mix from hardware to software and lower freight costs, partially offset by reduced prices on certain products. During the first quarter of 2024, we lowered list prices on select products. Cost of product revenue was comprised primarily of third-party contract manufacturers’ costs, costs of materials used in production and inventory reserves related to excess inventory and contractual delivery commitments.

[0001262039-24-000043:mdna:128]
Service gross margin increased 2.0 percentage points during the nine months ended September 30, 2024 compared to the same period last year, because service revenue growth outpaced labor cost increase and benefited from pricing actions in earlier periods and a revenue mix shift towards higher margin security subscription services. Cost of service revenue was comprised primarily of personnel-related costs, third-party repair and contract fulfillment, data center costs, colocation and cloud provider fees, supplies and facility-related costs.

[0001262039-24-000043:mdna:129]
[same as prior period, unchanged from 0001262039-24-000037:mdna:123]

[0001262039-24-000043:mdna:130]
|  | Nine Months Ended |  | Change |  | % Change |
| September 30,2024 |  | September 30,2023 |  |
| Amount |  | % ofRevenue |  | Amount |  | % ofRevenue |  |
| (in millions, except percentages) |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | $ | 525.7 |  |  | 12 | % |  | $ | 461.3 |  |  | 12 | % |  | $ | 64.4 |  |  | 14 | % |
| Sales and marketing | 1,518.3 |  |  | 35 |  |  | 1,498.6 |  |  | 39 |  |  | 19.7 |  |  | 1 |  |
| General and administrative | 182.7 |  |  | 4 |  |  | 156.2 |  |  | 4 |  |  | 26.5 |  |  | 17 |  |
| Gain on intellectual property matter | (3.4) |  |  | — |  |  | (3.4) |  |  | — |  |  | — |  |  | — |  |
| Total operating expenses | $ | 2,223.3 |  |  | 52 | % |  | $ | 2,112.7 |  |  | 54 | % |  | $ | 110.6 |  |  | 5 | % |
| Percentages have been rounded for presentation purposes and may differ from unrounded results. |

[0001262039-24-000043:mdna:131]
[same as prior period, unchanged from 0001262039-24-000037:mdna:125]

[0001262039-24-000043:mdna:132]
Research and development expense increased $64.4 million, or 14%, during the nine months ended September 30, 2024 compared to the same period last year, primarily due to an increase of $51.2 million in personnel-related costs as a result of increased headcount and compensation rates to support the development of new products and continued enhancements to our existing products. In addition, depreciation expense and other occupancy-related expense increased $6.5 million.

[0001262039-24-000043:mdna:133]
[same as prior period, unchanged from 0001262039-24-000037:mdna:153]

[0001262039-24-000043:mdna:134]
[same as prior period, unchanged from 0001262039-24-000037:mdna:127]

[0001262039-24-000043:mdna:135]
Sales and marketing expense increased $19.7 million, or 1%, during the nine months ended September 30, 2024 compared to the same period last year, primarily due to an increase of $30.2 million in personnel-related costs. In addition, travel expense increased $4.4 million and depreciation expense and other occupancy-related expense increased $2.4 million. The increases were partially offset by a decrease of $21.3 million in marketing program and related expenses.

[0001262039-24-000043:mdna:136]
[same as prior period, unchanged from 0001262039-24-000037:mdna:129]

[0001262039-24-000043:mdna:137]
General and administrative expense increased $26.5 million, or 17%, during the nine months ended September 30, 2024 compared to the same period last year, primarily due to an increase of $22.1 million in legal related fees and other professional services fees.

[0001262039-24-000043:mdna:138]
[same as prior period, unchanged from 0001262039-24-000037:mdna:131]

[0001262039-24-000043:mdna:139]
We generated operating income of $1.23 billion during the nine months ended September 30, 2024, an increase of $373.6 million, or 44%, compared to $855.7 million in the same period last year. Operating margin was 28.6% during the nine months ended September 30, 2024, compared to 22.0% in the same period last year. The increase in operating margin was primarily due to 4.1 percentage points increase in gross margin and 3.2 percentage points decrease in sales and marketing expense as a percentage of revenue, partially offset by 0.4 percentage points and 0.3 percentage points increases in research and development expense and general and administrative expense as a percentage of revenue, respectively.

[0001262039-24-000043:mdna:140]
Interest income, interest expense, gain on bargain purchase and other income (expense)—net

[0001262039-24-000043:mdna:141]
|  | Nine Months Ended |  |  |  |  |
| September 30,2024 |  | September 30,2023 |  | Change |  | % Change |
| (in millions, except percentages) |
| Interest income | $ | 112.9 |  |  | $ | 89.2 |  |  | $ | 23.7 |  |  | 27 | % |
| Interest expense | $ | (15.1) |  |  | $ | (15.6) |  |  | $ | 0.5 |  |  | (3) | % |
| Gain on bargain purchase | $ | 106.3 |  |  | $ | — |  |  | $ | 106.3 |  |  | 100 | % |
| Other income (expense)—net | $ | 6.7 |  |  | $ | (11.2) |  |  | $ | 17.9 |  |  | (160) | % |

[0001262039-24-000043:mdna:142]
Interest income increased $23.7 million during the nine months ended September 30, 2024 compared to the same period last year, primarily as a result of higher interest rates and investment balances. Interest income varies depending on our average investment balances during the period, types and mix of investments, and market interest rates. Interest expense remained comparatively flat during the nine months ended September 30, 2024 compared to the same period last year. Gain on bargain purchase was $106.3 million during the nine months ended September 30, 2024 and is related to our acquisition of Lacework. The $17.9 million change in other income (expense)—net during the nine months ended September 30, 2024 compared to the same period last year, was primarily due to an increase of $16.9 million gain on marketable equity securities and a $1.7 million decrease in foreign currency exchange losses.

[0001262039-24-000043:mdna:143]
[same as prior period, unchanged from 0001262039-24-000037:mdna:102]

[0001262039-24-000043:mdna:144]
|  | Nine Months Ended |  | Change |  | % Change |
| September 30,2024 |  | September 30,2023 |  |
| (in millions, except percentages) |
| Provision for income taxes | $ | 197.2 |  |  | $ | 48.6 |  |  | $ | 148.6 |  |  | 306 | % |
| Effective tax rate (%) | 14 | % |  | 5 | % |  |  |  |  |

[0001262039-24-000043:mdna:145]
Our effective tax rate was 14% for the nine months ended September 30, 2024 compared to an effective tax rate of 5% for the same period last year. The provision for income taxes for the nine months ended September 30, 2024 was primarily comprised of U.S. federal and state taxes, withholding taxes and foreign taxes that were $315.0 million. This provision for income taxes was favorably affected by a tax benefit of $84.0 million from the FDII deduction, and excess tax benefits from stock-based compensation expense of $33.8 million.

[0001262039-24-000043:mdna:146]
[same as prior period, unchanged from 0001262039-24-000037:mdna:166]

[0001262039-24-000043:mdna:147]
The provision for income taxes for the nine months ended September 30, 2023 was comprised of U.S. federal and state taxes, withholding taxes, and foreign taxes that were $220.9 million, which were offset by a tax benefit of $105.9 million from the FDII deduction, excess tax benefits from stock-based compensation expense of $48.3 million, and the release of reserves of $18.1 million on uncertain tax positions and the accrued interest thereon due to the expiration of statutes of limitations.

[0001262039-24-000043:mdna:148]
[same as prior period, unchanged from 0001262039-24-000037:mdna:141]

[0001262039-24-000043:mdna:149]
|  | Nine Months Ended |  | Change |  | % Change |
| September 30,2024 |  | September 30,2023 |  |
| (in millions, except percentages) |
| Loss from equity method investments | $ | (23.9) |  |  | $ | (32.6) |  |  | $ | 8.7 |  |  | (27) | % |

[0001262039-24-000043:mdna:150]
Loss from equity method investments decreased $8.7 million during the nine months ended September 30, 2024 compared to the same period last year, primarily driven by our proportionate share of Linksys’ financial results including our share of the amortization of the basis differences improved over the same period last year, partially offset by the OTTI charge of $8.0 million recorded in the second quarter of 2024.

[0001262039-24-000043:mdna:151]
[same as prior period, unchanged from 0001262039-24-000037:mdna:145]

[0001262039-24-000043:mdna:152]
|  | As of |
|  | September 30,2024 |  | December 31,2023 |
|  | (in millions) |
| Cash and cash equivalents | $ | 2,489.3 |  |  | $ | 1,397.9 |  |
| Short-term and long-term investments | 1,162.4 |  |  | 1,021.5 |  |
| Marketable equity securities | 49.0 |  |  | 21.0 |  |
| Total cash, cash equivalents, investments and marketable equity securities | $ | 3,700.7 |  |  | $ | 2,440.4 |  |
| Working capital | $ | 1,336.7 |  |  | $ | 709.3 |  |
|  | Nine Months Ended |
|  | September 30,2024 |  | September 30,2023 |
|  | (in millions) |
| Net cash provided by operating activities | $ | 1,780.5 |  |  | $ | 1,743.8 |  |
| Net cash used in investing activities | (647.5) |  |  | (577.7) |  |
| Net cash used in financing activities | (41.3) |  |  | (660.3) |  |
| Effect of exchange rate changes on cash and cash equivalents | (0.3) |  |  | (1.9) |  |
| Net increase in cash and cash equivalents | $ | 1,091.4 |  |  | $ | 503.9 |  |

[0001262039-24-000043:mdna:153]
Liquidity and capital resources are primarily impacted by our operating activities, as well as real estate purchases, other capital expenditures and business acquisitions, payment of taxes in connection with the net settlement of equity awards and proceeds from the issuance of common stock and repurchases of our common stock.

[0001262039-24-000043:mdna:154]
In recent years, we have received significant capital resources from our billings to customers, issuance of investment grade debt and, to some extent, from the exercise of stock options by our employees. Additional increases in billings may depend on a number of factors, including demand for and availability of our products and services, competition, pricing actions, market or industry changes, macroeconomic events such as rising inflation and changing interest rates, economic strength, supply chain capacity and disruptions, international conflicts, including the war in Ukraine and the Israel-Hamas war, and our ability to execute. We expect proceeds from the exercise of stock options in future years to be impacted by the increased mix of restricted stock units and performance stock units versus stock options granted to our employees and to vary based on our share price.

[0001262039-24-000043:mdna:155]
In January 2024, our board of directors approved a $500.0 million increase in the authorized share repurchase amount under the Repurchase Program, bringing the aggregate amount authorized to be repurchased to $7.25 billion of our outstanding common stock. In February 2024, our board of directors approved an extension of the Repurchase Program to February 28, 2025. During the nine months ended September 30, 2024, we repurchased less than 0.1 million shares of common stock under

[0001262039-24-000043:mdna:156]
41

[0001262039-24-000043:mdna:157]
the Repurchase program for an aggregate purchase price of $0.6 million. As of September 30, 2024, approximately $1.03 billion remained available for future share repurchases. In October 2024, our board of directors approved a $1.0 billion increase in the authorized stock repurchase amount under the Repurchase Program and extended the term of the Repurchase Program to February 28, 2026, bringing the aggregate amount authorized to be repurchased to $8.25 billion of our outstanding common stock through February 28, 2026. As of November 8, 2024, approximately $2.03 billion remained available for future share repurchases.

[0001262039-24-000043:mdna:158]
We expect to continue to increase our data centers, PoPs, office and warehouse capacity to support growth and the expansion of existing services or introduction of new services. As we purchase new properties, we will work to incorporate these properties into the environmental goals we have established. We estimate capital expenditures to be between approximately $100.0 million and $120.0 million for the fourth quarter of 2024.

[0001262039-24-000043:mdna:159]
We believe that our cash provided by operating activities, together with our existing cash, cash equivalents and investments will be sufficient to meet our anticipated cash needs and do not currently intend to retire our Senior Notes early. Refer to Note 10, Debt, in Part I, Item 1 of this Quarterly Report on Form 10-Q for information on the Senior Notes. As of September 30, 2024, the long-term debt, net of unamortized discount and debt issuance costs, was $993.8 million.

[0001262039-24-000043:mdna:160]
[same as prior period, unchanged from 0001262039-24-000037:mdna:152]

[0001262039-24-000043:mdna:161]
These inventory purchase commitments as of September 30, 2024 totaled $550.0 million, a decrease of $87.3 million compared to $637.3 million as of December 31, 2023 due to fulfillment of customer demand as our supply availability improved and our continued efforts to work with contract manufacturers and suppliers to optimize our inventory and purchase commitment position. We record a liability for inventory purchase commitments in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. As of September 30, 2024 and December 31, 2023, the liability for these inventory purchase commitments was $76.3 million and $84.7 million, respectively, and was recorded in accrued liabilities on our condensed consolidated balance sheets.

[0001262039-24-000043:mdna:162]
[same as prior period, unchanged from 0001262039-24-000037:mdna:155]

[0001262039-24-000043:mdna:163]
Inventory and supply chain management remain areas of focus as we balance the need to maintain supply chain flexibility to help ensure competitive lead times with the risk of inventory obsolescence because of supply constraints, rapidly changing technology, and customer requirements. We believe the amount of our inventory and purchase commitments is appropriate for our current and expected customer demand and revenue levels.

[0001262039-24-000043:mdna:164]
We also have open purchase orders and contractual obligations in the ordinary course of business for which we have not received goods or services. As of September 30, 2024, we had $116.5 million in other contractual commitments having a remaining term in excess of one year that are non-cancelable.

[0001262039-24-000043:mdna:165]
[same as prior period, unchanged from 0001262039-24-000037:mdna:158]

[0001262039-24-000043:mdna:166]
As of September 30, 2024, our cash, cash equivalents and short-term and long-term investments of $3.65 billion were invested primarily in deposit accounts, commercial paper, corporate debt securities, U.S. government and agency securities, certificates of deposit and term deposits and money market funds. It is our investment policy to invest excess cash in a manner that preserves capital, provides liquidity, and generates return without significantly increasing risk. We do not enter into investments for trading or speculative purposes.

[0001262039-24-000043:mdna:167]
The amount of cash, cash equivalents and investments held by our international subsidiaries was $192.8 million as of September 30, 2024 and $199.9 million as of December 31, 2023.

[0001262039-24-000043:mdna:168]
We believe that our existing cash and cash equivalents and cash flow from operations will be sufficient for at least the next 12 months to meet our requirements and plans for cash, including meeting our working capital requirements and capital expenditure requirements. In the long term, our ability to support our requirements and plans for cash, including our working

[0001262039-24-000043:mdna:169]
capital and capital expenditure requirements will depend on many factors, including our growth rate; the timing and amount of our share repurchases; the expansion of sales and marketing activities, pricing actions, the introduction of new and enhanced products and services offerings; the continuing market acceptance of our products; the timing and extent of spending to support development efforts; our investments in purchasing, developing or leasing real estate; cash paid for taxes and macroeconomic impacts such as rising inflation and changing interest rates; and the war in Ukraine and the Israel-Hamas war. Historically, we have required capital principally to fund our working capital needs, share repurchases, capital expenditures and acquisition activities. In the event that additional financing is required from outside sources, we may not be able to raise it on terms acceptable to us or at all.

[0001262039-24-000043:mdna:170]
As of September 30, 2024, we did not have any relationships with unconsolidated organizations or financial partnerships, such as structured finance or special purpose entities that would have been established for the purpose of facilitating off-balance sheet arrangements or other contractually narrow or limited purposes.

[0001262039-24-000043:mdna:171]
[same as prior period, unchanged from 0001262039-24-000037:mdna:163]

[0001262039-24-000043:mdna:172]
[same as prior period, unchanged from 0001262039-24-000037:mdna:164]

[0001262039-24-000043:mdna:173]
Our operating activities during the nine months ended September 30, 2024 provided cash flows of $1.78 billion as a result of the continued growth of our business, improved profitability and our ability to successfully manage our working capital. Changes in operating assets and liabilities primarily resulted from an increase in sales of our security subscription services and technical support services to new and existing customers, as reflected by an increase of $234.4 million in our deferred revenue during the nine months ended September 30, 2024. In addition, changes in operating assets and liabilities were driven by a decrease of $376.5 million in accounts receivable—net, an increase of $212.2 million in deferred contract costs, an increase of $187.6 million in deferred tax assets, a decrease of $104.9 million in inventory, a decrease of $72.3 million in accrued liabilities and a decrease of $32.0 million in accounts payable.

[0001262039-24-000043:mdna:174]
[same as prior period, unchanged from 0001262039-24-000037:mdna:168]

[0001262039-24-000043:mdna:175]
[same as prior period, unchanged from 0001262039-24-000037:mdna:169]

[0001262039-24-000043:mdna:176]
During the nine months ended September 30, 2024, cash used in investing activities was $647.5 million, primarily driven by $281.3 million used for the purchases of property and equipment, $247.0 million used for the acquisitions of Lacework and Next DLP, net of cash and $102.6 million spent for purchases of investments, net of maturities and sales of investments.

[0001262039-24-000043:mdna:177]
[same as prior period, unchanged from 0001262039-24-000037:mdna:171]

[0001262039-24-000043:mdna:178]
[same as prior period, unchanged from 0001262039-24-000037:mdna:172]

[0001262039-24-000043:mdna:179]
During the nine months ended September 30, 2024, cash used in financing activities was $41.3 million, primarily driven by $39.9 million used to pay tax withholding, net of proceeds from the issuance of common stock.
