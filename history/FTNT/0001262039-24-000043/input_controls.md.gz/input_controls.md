# FTNT 10-Q controls and the auditor's report


## item_4_controls

[0001262039-24-000043:item_4_controls:1]
ITEM 4.     Controls and Procedures

[0001262039-24-000043:item_4_controls:2]
Evaluation of Disclosure Controls and Procedures

[0001262039-24-000043:item_4_controls:3]
Our management, with the participation of our chief executive officer and chief financial officer, evaluated the effectiveness of our disclosure controls and procedures (as defined in Rule 13a-15(e) or 15d-15(e) under the Exchange Act as of September 30, 2024. In designing and evaluating the disclosure controls and procedures, management recognized that any controls and procedures, no matter how well designed and operated, can provide only reasonable assurance of achieving the desired control objectives. In addition, the design of disclosure controls and procedures must reflect the fact that there are resource constraints and that management is required to apply its judgment in evaluating the benefits of possible controls and procedures relative to their costs.

[0001262039-24-000043:item_4_controls:4]
Based on that evaluation, our chief executive officer and chief financial officer concluded that our disclosure controls and procedures were effective as of September 30, 2024 to provide reasonable assurance that information we are required to disclose in reports that we file or submit under the Exchange Act is recorded, processed, summarized and reported within the time periods specified in SEC rules and forms, and that such information is accumulated and communicated to our management, including our chief executive officer and chief financial officer, as appropriate, to allow timely decisions regarding required disclosure.

[0001262039-24-000043:item_4_controls:5]
Changes in Internal Control over Financial Reporting

[0001262039-24-000043:item_4_controls:6]
In accordance with the Internal Controls Guidance, management has excluded Lacework, a privately held data-driven cloud security company, and Next DLP, a privately held data security company, from its assessment of internal control over financial reporting as of September 30, 2024, because Lacework and Next DLP were acquired by us in business combinations during the quarter ended September 30, 2024. Lacework and Next DLP assets represented approximately 3.5% and 1.3% of our consolidated total assets, respectively, excluding the effects of purchase accounting, as of September 30, 2024, and their revenues represented approximately 0.9% and 0.1% of our consolidated total revenue, respectively, for the quarter ended September 30, 2024.

[0001262039-24-000043:item_4_controls:7]
There were no other changes in our internal controls over financial reporting (as defined in Rules 13a-15(f) or 15d-15(f) under the Exchange Act) during the quarter ended September 30, 2024, that have materially affected, or are reasonably likely to materially affect, our internal controls over financial reporting.

[0001262039-24-000043:item_4_controls:8]
44
