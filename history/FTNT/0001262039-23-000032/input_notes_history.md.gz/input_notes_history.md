# FTNT note change history — 0001262039-23-000021 → 0001262039-23-000032


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2023-08-07):
[0001262039-23-000032:note_history:1]
COMMITMENTS AND CONTINGENCIES
The following table summarizes our inventory purchase commitments as of June 30, 2023 (in millions):
  (was, 2023-05-08, similarity 0.96):
[0001262039-23-000021:note_history:1]
COMMITMENTS AND CONTINGENCIESThe following table summarizes our inventory purchase commitments as of March 31, 2023 (in millions):

- changed (2023-08-07):
[0001262039-23-000032:note_history:2]
Inventory Purchase Commitments—Our independent contract manufacturers and certain component suppliers procure components and build our products based on our forecasts, the availability of various components and their capacity. These forecasts are based on estimates of future demand for our products, which are in turn based on historical trends and an analysis from our sales and marketing organizations, adjusted for extended lead times, changes in supplier delivery commitments and other supply chain matters and market conditions. In order to manage manufacturing lead times, plan for adequate component supply and incentivize suppliers to deliver, we may issue purchase orders to some of our independent contract manufacturers, which are non-cancelable. As of June 30, 2023, we had $1.01 billion of open purchase orders with our independent contract manufacturers that consist of non-cancelable commitments. In certain instances, these agreements allow us the option to reschedule and adjust our requirements based on our business needs prior to firm orders being placed.
  (was, 2023-05-08, similarity 0.9958):
[0001262039-23-000021:note_history:2]
Inventory Purchase Commitments—Our independent contract manufacturers and certain component suppliers procure components and build our products based on our forecasts, the availability of various components and their capacity. These forecasts are based on estimates of future demand for our products, which are in turn based on historical trends and an analysis from our sales and marketing organizations, adjusted for extended lead times, changes in supplier delivery commitments and other supply chain matters and market conditions. In order to manage manufacturing lead times, plan for adequate component supply and incentivize suppliers to deliver, we may issue purchase orders to some of our independent contract manufacturers, which are non-cancelable. As of March 31, 2023, we had $1.20 billion of open purchase orders with our independent contract manufacturers that consist of non-cancelable commitments. In certain instances, these agreements allow us the option to reschedule and adjust our requirements based on our business needs prior to firm orders being placed.

- changed (2023-08-07):
[0001262039-23-000032:note_history:3]
Other Contractual Commitments and Open Purchase Orders—In addition to commitments with contract manufacturers, we have open purchase orders and contractual obligations in the ordinary course of business for which we have not received goods or services. A significant portion of our reported purchase commitments consist of non-cancelable commitments. In certain instances, contractual commitments allow us the option to cancel, reschedule and adjust our requirements based on our business needs prior to firm orders being placed. As of June 30, 2023, we had $84.6 million in other contractual commitments having a remaining term in excess of one year that are non-cancelable.
  (was, 2023-05-08, similarity 0.9311):
[0001262039-23-000021:note_history:3]
Other Contractual Commitments and Open Purchase Orders—In addition to commitments with contract manufacturers, we have open purchase orders and contractual obligations in the ordinary course of business for which we have not received goods or services. A significant portion of our reported purchase commitments consist of non-cancelable commitments. In certain instances, contractual commitments allow us the option to cancel, reschedule and adjust our requirements based on our business needs prior to firm orders being placed. As of March 31, 2023, we had $100.1 million in other contractual commitments having a remaining term in excess of one year that are non-cancelable and an additional $100.7 million, in contractual commitments for operating lease liabilities.

- added (2023-08-07):
[0001262039-23-000032:note_history:4]
As of June 30, 2023, we had $93.9 million in contractual commitments related to payments for operating leases.

- changed (2023-08-07):
[0001262039-23-000032:note_history:5]
Litigation—We are involved in disputes, litigation, and other legal actions. For lawsuits where we are the defendant, we are in the process of defending these litigation matters, and while there can be no assurances and the outcome of certain of these matters is currently not determinable and not predictable, we currently are unaware of any existing claims or proceedings that we believe are likely to have a material adverse effect on our financial position. There are many uncertainties associated with any litigation and these actions or other third-party claims against us may cause us to incur costly litigation fees, costs and substantial settlement charges, and possibly subject us to damages and other penalties. In addition, the resolution of any intellectual property (“IP”) litigation may require us to make royalty payments, which could adversely affect our gross margins in future periods. If any of those events were to occur, our business, financial condition, results of operations, and cash flows could be adversely affected. Litigation is unpredictable and the actual liability in any such matters may be materially different from our current estimates, which could result in the need to adjust any accrued liability and record additional expenses. We accrue for contingencies when we believe that a loss is probable and that we can reasonably estimate the amount of any such loss. These accruals are generally based on a range of possible outcomes that require significant management judgement. If no amount within a range is a better estimate than any other, we accrue the minimum amount. Litigation loss contingency accruals associated with outstanding cases were not material as of June 30, 2023, and December 31, 2022.
  (was, 2023-05-08, similarity 0.9638):
[0001262039-23-000021:note_history:5]
Litigation—We are involved in disputes, litigation, and other legal actions. For lawsuits where we are the defendant, we are in the process of defending these litigation matters, and while there can be no assurances and the outcome of certain of these matters is currently not determinable and not predictable, we currently are unaware of any existing claims or proceedings that we believe are likely to have a material adverse effect on our financial position. There are many uncertainties associated with any litigation and these actions or other third-party claims against us may cause us to incur costly litigation fees, costs and substantial settlement charges, and possibly subject us to damages and other penalties. In addition, the resolution of any intellectual property (“IP”) litigation may require us to make royalty payments, which could adversely affect our gross margins in future periods. If any of those events were to occur, our business, financial condition, results of operations, and cash flows could be adversely affected. Litigation is unpredictable and the actual liability in any such matters may be materially different from our current estimates, which could result in the need to adjust any accrued liability and record additional expenses. We accrue for contingencies when we believe that a loss is probable and that we can reasonably estimate the amount of any such loss. These accruals are generally based on a range of possible outcomes that require significant management judgement. If no amount within a range is a better estimate than any other, we accrue the minimum amount.

- added (2023-08-07):
[0001262039-23-000032:note_history:6]
On March 21, 2019, we were sued by Alorica Inc. (“Alorica”) in Santa Clara County Superior Court in California. Alorica has alleged breach of warranty and misrepresentation claims, which we deny. We have counter-claimed and are seeking monetary damages. Fact discovery closed during the quarter ended June 30, 2023, and the trial is scheduled to commence in October 2023. Although we believe that the ultimate outcome of this matter will not materially impact our financial position, results of operations or cash flows, legal proceedings are subject to inherent uncertainties, and an unfavorable ruling could occur, which may result in a material adverse impact on our business, financial position, results of operations and cash flows. No loss accrual had been recorded as of June 30, 2023 or December 31, 2022 related to this litigation.

- removed (2023-08-07):
[0001262039-23-000021:note_history:7]
Litigation loss contingency accruals associated with outstanding cases were not material as of March 31, 2023 and December 31, 2022.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2023-08-07):
[0001262039-23-000032:note_history:8]
SUMMARY OF SIGNIFICANT ACCOUNTING POLICIES
Basis of Presentation and Preparation—The unaudited condensed consolidated financial statements of Fortinet, Inc. and its subsidiaries (collectively, “we,” “us” or “our”) have been prepared in accordance with generally accepted accounting principles in the United States (“GAAP”) for interim financial information, as well as the instructions to Form 10-Q pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (the “SEC”). Accordingly, they do not include all of the information and footnotes required by GAAP for complete financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the year ended December 31, 2022, contained in our Annual Report on Form 10-K filed with the SEC on February 24, 2023. In the opinion of management, all adjustments, which include normal recurring adjustments, considered necessary for a fair presentation, have been included. The results of operations for the three and six months ended June 30, 2023 are not necessarily indicative of the results to be expected for the full year or for any future periods. The condensed consolidated balance sheet as of December 31, 2022 is derived from the audited consolidated financial statements for the year ended December 31, 2022.
  (was, 2023-05-08, similarity 0.792):
[0001262039-23-000021:note_history:8]
SUMMARY OF SIGNIFICANT ACCOUNTING POLICIES
Basis of Presentation and Preparation—The unaudited condensed consolidated financial statements of Fortinet, Inc. and its subsidiaries (collectively, “we,” “us” or “our”) have been prepared in accordance with generally accepted accounting principles in the United States (“GAAP”) for interim financial information, as well as the instructions to Form 10-Q pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (the “SEC”). Accordingly, they do not include all of the information and footnotes required by GAAP for complete financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the year ended December 31, 2022, contained in our Annual Report on Form 10-K filed with the SEC on February 24, 2023. In the opinion of management, all adjustments, which include normal recurring adjustments, considered necessary for a fair presentation, have been included. The results of operations for the three months ended March 31, 2023 are not necessarily indicative of the results to be expected for the full year or for any future periods. The condensed consolidated balance sheet as of December 31, 2022 is derived from the audited consolidated financial statements for the year ended December 31, 2022.

- added (2023-08-07):
[0001262039-23-000032:note_history:9]
Amounts related to income taxes payable have been reclassified in prior periods to conform with current period presentation.

- changed (2023-08-07):
[0001262039-23-000032:note_history:10]
There have been no material changes to our significant accounting policies as of and for the three and six months ended June 30, 2023, as compared to the significant accounting policies described in the Form 10-K.
  (was, 2023-05-08, similarity 0.958):
[0001262039-23-000021:note_history:10]
There have been no material changes to our significant accounting policies as of and for the three months ended March 31, 2023, as compared to the significant accounting policies described in the Form 10-K.

- removed (2023-08-07):
[0001262039-23-000021:note_history:11]
On April 14, 2022, our board of directors approved a five-for-one forward stock split of our common stock (the “Forward Stock Split”), which was conditioned upon obtaining stockholder approval for the Forward Stock Split, and to increase the number of our authorized shares of common stock. On June 17, 2022, at our 2022 Annual Meeting of Stockholders, our stockholders approved the Forward Stock Split and the amendment and restatement of our amended and restated certificate of incorporation to increase the number of authorized shares of common stock from 300.0 million to 1.5 billion. The par value of our common stock was not adjusted as a result of the Forward Stock Split. Effective June 22, 2022, we filed our amended and restated certification of incorporation and completed the Forward Stock Split. All share and per share amounts and related equity (deficit) balances presented herein have been retroactively adjusted to reflect the Forward Stock Split.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-08-07):
[0001262039-23-000032:note_history:12]
On March 5, 2021, we issued $1.0 billion aggregate principal amount of senior notes (collectively, the “Senior Notes”), consisting of $500.0 million aggregate principal amount of 1.0% notes due March 15, 2026 (the “2026 Senior Notes”) and $500.0 million aggregate principal amount of 2.2% notes due March 15, 2031 (the “2031 Senior Notes”), in an underwritten registered public offering. The Senior Notes are senior unsecured obligations and rank equally with each other in right of payment and with our other outstanding obligations. We may redeem the Senior Notes at any time in whole or in part for cash, at specified redemption prices that include accrued and unpaid interest, if any, and a make-whole premium. However, no make-whole premium will be paid for redemptions of the 2026 Senior Notes on or after February 15, 2026, or the 2031 Senior Notes on or after December 15, 2030. Interest on the Senior Notes is payable on March 15 and September 15 of each year, beginning on September 15, 2021. As of June 30, 2023 and December 31, 2022, the Senior Notes were recorded as long-term debt, net of discount and issuance costs, which are amortized to interest expense over the respective contractual terms of these notes using the effective interest method.
  (was, 2023-05-08, similarity 0.9962):
[0001262039-23-000021:note_history:12]
On March 5, 2021, we issued $1.0 billion aggregate principal amount of senior notes (collectively, the “Senior Notes”), consisting of $500.0 million aggregate principal amount of 1.0% notes due March 15, 2026 (the “2026 Senior Notes”) and $500.0 million aggregate principal amount of 2.2% notes due March 15, 2031 (the “2031 Senior Notes”), in an underwritten registered public offering. The Senior Notes are senior unsecured obligations and rank equally with each other in right of payment and with our other outstanding obligations. We may redeem the Senior Notes at any time in whole or in part for cash, at specified redemption prices that include accrued and unpaid interest, if any, and a make-whole premium. However, no make-whole premium will be paid for redemptions of the 2026 Senior Notes on or after February 15, 2026, or the 2031 Senior Notes on or after December 15, 2030. Interest on the Senior Notes is payable on March 15 and September 15 of each year, beginning on September 15, 2021. As of March 31, 2023 and December 31, 2022, the Senior Notes were recorded as long-term debt, net of discount and issuance costs, which are amortized to interest expense over the respective contractual terms of these notes using the effective interest method.

- changed (2023-08-07):
[0001262039-23-000032:note_history:13]
|  | Maturity |  | Coupon Rate |  | Effective Interest Rate |  | June 30,2023 |  | December 31,2022 |
| Debt |  |  |  |  |  |  |  |  |  |
| 2026 Senior Notes | March 2026 |  | 1.0% |  | 1.3% |  | $ | 500.0 |  |  | $ | 500.0 |  |
| 2031 Senior Notes | March 2031 |  | 2.2% |  | 2.3% |  | 500.0 |  |  | 500.0 |  |
| Total debt |  |  |  |  |  |  | 1,000.0 |  |  | 1,000.0 |  |
| Less: Unamortized discount and debt issuance costs |  |  |  |  |  |  | 8.7 |  |  | 9.6 |  |
| Total long-term debt |  |  |  |  |  |  | $ | 991.3 |  |  | $ | 990.4 |  |
  (was, 2023-05-08, similarity 0.9892):
[0001262039-23-000021:note_history:13]
|  | Maturity |  | Coupon Rate |  | Effective Interest Rate |  | March 31,2023 |  | December 31,2022 |
| Debt |  |  |  |  |  |  |  |  |  |
| 2026 Senior Notes | March 2026 |  | 1.0% |  | 1.3% |  | $ | 500.0 |  |  | $ | 500.0 |  |
| 2031 Senior Notes | March 2031 |  | 2.2% |  | 2.3% |  | 500.0 |  |  | 500.0 |  |
| Total debt |  |  |  |  |  |  | 1,000.0 |  |  | 1,000.0 |  |
| Less: Unamortized discount and debt issuance costs |  |  |  |  |  |  | 9.1 |  |  | 9.6 |  |
| Total long-term debt |  |  |  |  |  |  | $ | 990.9 |  |  | $ | 990.4 |  |

- changed (2023-08-07):
[0001262039-23-000032:note_history:14]
As of June 30, 2023 and December 31, 2022, we accrued interest payable of $4.7 million, and there are no financial covenants with which we must comply. During the three months ended June 30, 2023 and 2022, we recorded $4.5 million of total interest expense in relation to these Senior Notes in each quarter. During the six months ended June 30, 2023 and 2022, we recorded $9.0 million of total interest expense in relation to the Senior Notes in each period. No interest costs were capitalized for the six months ended June 30, 2023 and 2022, as the costs that qualified for capitalization were not material.
  (was, 2023-05-08, similarity 0.6297):
[0001262039-23-000021:note_history:14]
As of March 31, 2023 and December 31, 2022, we accrued interest payable of $0.7 million and $4.7 million, respectively, and there are no financial covenants with which we must comply. During the three months ended March 31, 2023 and 2022, we recorded $4.5 million of total interest expense in relation to these Senior Notes and repaid $8.0 million of interest in cash in each quarter. No interest costs were capitalized for the three months ended March 31, 2023 and 2022, as the costs that qualified for capitalization were not material.

- changed (2023-08-07):
[0001262039-23-000032:note_history:15]
The total estimated fair value of the outstanding Senior Notes was approximately $856.3 million, including accrued and unpaid interest, as of June 30, 2023. The fair value was determined based on observable market prices of identical instruments in less active markets. The estimated fair values are based on Level 2 inputs.
  (was, 2023-05-08, similarity 0.9857):
[0001262039-23-000021:note_history:15]
The total estimated fair value of the outstanding Senior Notes was approximately $867.7 million, including accrued and unpaid interest, as of March 31, 2023. The fair value was determined based on observable market prices of identical instruments in less active markets. The estimated fair values are based on Level 2 inputs.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-08-07):
[0001262039-23-000032:note_history:16]
|  | Maturity |  | Coupon Rate |  | Effective Interest Rate |  | June 30,2023 |  | December 31,2022 |
| Debt |  |  |  |  |  |  |  |  |  |
| 2026 Senior Notes | March 2026 |  | 1.0% |  | 1.3% |  | $ | 500.0 |  |  | $ | 500.0 |  |
| 2031 Senior Notes | March 2031 |  | 2.2% |  | 2.3% |  | 500.0 |  |  | 500.0 |  |
| Total debt |  |  |  |  |  |  | 1,000.0 |  |  | 1,000.0 |  |
| Less: Unamortized discount and debt issuance costs |  |  |  |  |  |  | 8.7 |  |  | 9.6 |  |
| Total long-term debt |  |  |  |  |  |  | $ | 991.3 |  |  | $ | 990.4 |  |
  (was, 2023-05-08, similarity 0.9892):
[0001262039-23-000021:note_history:16]
|  | Maturity |  | Coupon Rate |  | Effective Interest Rate |  | March 31,2023 |  | December 31,2022 |
| Debt |  |  |  |  |  |  |  |  |  |
| 2026 Senior Notes | March 2026 |  | 1.0% |  | 1.3% |  | $ | 500.0 |  |  | $ | 500.0 |  |
| 2031 Senior Notes | March 2031 |  | 2.2% |  | 2.3% |  | 500.0 |  |  | 500.0 |  |
| Total debt |  |  |  |  |  |  | 1,000.0 |  |  | 1,000.0 |  |
| Less: Unamortized discount and debt issuance costs |  |  |  |  |  |  | 9.1 |  |  | 9.6 |  |
| Total long-term debt |  |  |  |  |  |  | $ | 990.9 |  |  | $ | 990.4 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2023-08-07):
[0001262039-23-000032:note_history:17]
|  | Three Months Ended |  | Six Months Ended |
|  | June 30,2023 |  | June 30,2022 |  | June 30,2023 |  | June 30,2022 |
| Product | $ | 472.6 |  |  | $ | 400.7 |  |  | $ | 973.3 |  |  | $ | 771.7 |  |
| Service: |  |  |  |  |  |  |  |
| Security subscription | 457.3 |  |  | 340.4 |  |  | 879.0 |  |  | 653.3 |  |
| Technical support and other | 362.9 |  |  | 289.0 |  |  | 702.8 |  |  | 559.9 |  |
| Total service revenue | 820.2 |  |  | 629.4 |  |  | 1,581.8 |  |  | 1,213.2 |  |
| Total revenue | $ | 1,292.8 |  |  | $ | 1,030.1 |  |  | $ | 2,555.1 |  |  | $ | 1,984.9 |  |

- removed (2023-08-07):
[0001262039-23-000021:note_history:18]
|  | Three Months Ended |  |  |
|  | March 31,2023 |  | March 31,2022 |  |  |  |  |
| Product | $ | 500.7 |  |  | $ | 371.0 |  |  |  |  |  |
| Service: |  |  |  |  |  |  |  |
| Security subscription | 421.7 |  |  | 312.9 |  |  |  |  |  |
| Technical support and other | 339.9 |  |  | 270.9 |  |  |  |  |  |
| Total service revenue | 761.6 |  |  | 583.8 |  |  |  |  |  |
| Total revenue | $ | 1,262.3 |  |  | $ | 954.8 |  |  |  |  |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2023-08-07):
[0001262039-23-000032:note_history:19]
|  | Three Months Ended |  | Six Months Ended |
|  | June 30,2023 |  | June 30,2022 |  | June 30,2023 |  | June 30,2022 |
| Product | $ | 472.6 |  |  | $ | 400.7 |  |  | $ | 973.3 |  |  | $ | 771.7 |  |
| Service: |  |  |  |  |  |  |  |
| Security subscription | 457.3 |  |  | 340.4 |  |  | 879.0 |  |  | 653.3 |  |
| Technical support and other | 362.9 |  |  | 289.0 |  |  | 702.8 |  |  | 559.9 |  |
| Total service revenue | 820.2 |  |  | 629.4 |  |  | 1,581.8 |  |  | 1,213.2 |  |
| Total revenue | $ | 1,292.8 |  |  | $ | 1,030.1 |  |  | $ | 2,555.1 |  |  | $ | 1,984.9 |  |

- changed (2023-08-07):
[0001262039-23-000032:note_history:20]
During the three and six months ended June 30, 2023, we recognized $609.8 million and $1.29 billion in service revenue that was included in the deferred revenue balance as of December 31, 2022, respectively. During the three and six months ended June 30, 2022, we recognized $457.6 million and $964.9 million in service revenue that was included in the deferred revenue balance as of December 31, 2021, respectively.
  (was, 2023-05-08, similarity 0.6386):
[0001262039-23-000021:note_history:20]
During the three months ended March 31, 2023 and 2022, we recognized $675.9 million and $507.3 million in service revenue that was included in the deferred revenue balance as of December 31, 2022 and 2021, respectively.

- changed (2023-08-07):
[0001262039-23-000032:note_history:21]
As of June 30, 2023, the aggregate amount of the transaction price allocated to remaining performance obligations was $5.15 billion, which was substantially comprised of deferred security subscription, technical support services revenue and unbilled contract revenue from non-cancellable contracts that will be recognized in future periods. We expect to recognize approximately $2.60 billion as revenue over the next 12 months and the remainder thereafter.
  (was, 2023-05-08, similarity 0.9899):
[0001262039-23-000021:note_history:21]
As of March 31, 2023, the aggregate amount of the transaction price allocated to remaining performance obligations was $4.91 billion, which was substantially comprised of deferred security subscription, technical support services revenue and unbilled contract revenue from non-cancellable contracts that will be recognized in future periods. We expect to recognize approximately $2.49 billion as revenue over the next 12 months and the remainder thereafter.

- changed (2023-08-07):
[0001262039-23-000032:note_history:22]
The allowance for credit losses was $5.3 million and $3.6 million as of June 30, 2023 and December 31, 2022, respectively. Provisions, write-offs and recoveries were not material during the six months ended June 30, 2023 and 2022.
  (was, 2023-05-08, similarity 0.8221):
[0001262039-23-000021:note_history:22]
The allowance for credit losses was $6.7 million and $3.6 million as of March 31, 2023 and December 31, 2022, respectively. Provisions, write-offs and recoveries were not material during the three months ended March 31, 2023 and 2022.

- changed (2023-08-07):
[0001262039-23-000032:note_history:23]
Amortization of deferred contract costs during the three months ended June 30, 2023 and 2022 were $65.4 million and $54.6 million, respectively. Amortization of deferred contract costs during the six months ended June 30, 2023 and 2022 were $127.9 million and $107.1 million, respectively.
  (was, 2023-05-08, similarity 0.6462):
[0001262039-23-000021:note_history:23]
Amortization of deferred contract costs during the three months ended March 31, 2023 and 2022 were $62.5 million and $52.5 million, respectively.

- removed (2023-08-07):
[0001262039-23-000021:note_history:24]
|  | Three Months Ended |  |  |
|  | March 31,2023 |  | March 31,2022 |  |  |  |  |
| Product | $ | 500.7 |  |  | $ | 371.0 |  |  |  |  |  |
| Service: |  |  |  |  |  |  |  |
| Security subscription | 421.7 |  |  | 312.9 |  |  |  |  |  |
| Technical support and other | 339.9 |  |  | 270.9 |  |  |  |  |  |
| Total service revenue | 761.6 |  |  | 583.8 |  |  |  |  |  |
| Total revenue | $ | 1,262.3 |  |  | $ | 954.8 |  |  |  |  |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- added (2023-08-07):
[0001262039-23-000032:note_history:25]
SUBSEQUENT EVENTS
Investment in Privately Held Company

- added (2023-08-07):
[0001262039-23-000032:note_history:26]
On August 1, 2023, we invested $8.5 million in cash in a privately held company.

- changed (2023-08-07):
[0001262039-23-000032:note_history:27]
Share Repurchase Program
  (was, 2023-05-08, similarity 0.7273):
[0001262039-23-000021:note_history:27]
SUBSEQUENT EVENTS
Share Repurchase Program

- added (2023-08-07):
[0001262039-23-000032:note_history:28]
In July 2023, our board of directors approved a $500.0 million increase in the authorized stock repurchase amount under the Repurchase Program, bringing the aggregate amount authorized to be repurchased to $6.75 billion of our outstanding common stock through February 29, 2024. As of August 7, 2023, approximately $1.87 billion remained available for future share repurchases. Subsequent to June 30, 2023 through the filing of this Quarterly Report on Form 10-Q, we repurchased approximately 2.8 million shares of our common stock at an average price of $57.44 per share for an aggregate purchase price of approximately $161.1 million under the Repurchase Program.

- removed (2023-08-07):
[0001262039-23-000021:note_history:29]
In April 2023, our board of directors approved a $1.0 billion increase in the authorized stock repurchase amount under the Repurchase Program, bringing the aggregate amount authorized to be repurchased to $6.25 billion of our outstanding common stock through February 29, 2024. As of May 8, 2023, approximately $1.53 billion remained available for future share repurchases.

- removed (2023-08-07):
[0001262039-23-000021:note_history:30]
Real property purchase

- removed (2023-08-07):
[0001262039-23-000021:note_history:31]
In April 2023, we purchased real property in Plano, Texas, totaling approximately 43,400 square feet, for $19.3 million in cash.
