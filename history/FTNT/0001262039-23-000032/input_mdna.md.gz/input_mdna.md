# FTNT MD&A — 0001262039-23-000032


## mdna

[0001262039-23-000032:mdna:1]
[same as prior period, unchanged from 0001262039-23-000021:mdna:1]

[0001262039-23-000032:mdna:2]
[same as prior period, unchanged from 0001262039-23-000021:mdna:5]

[0001262039-23-000032:mdna:3]
[same as prior period, unchanged from 0001262039-23-000021:mdna:6]

[0001262039-23-000032:mdna:4]
[same as prior period, unchanged from 0001262039-23-000021:mdna:7]

[0001262039-23-000032:mdna:5]
[same as prior period, unchanged from 0001262039-23-000021:mdna:8]

[0001262039-23-000032:mdna:6]
[same as prior period, unchanged from 0001262039-23-000021:mdna:3]

[0001262039-23-000032:mdna:7]
[same as prior period, unchanged from 0001262039-23-000021:mdna:9]

[0001262039-23-000032:mdna:8]
•real estate investments and management, expansions and enhancements of current properties;

[0001262039-23-000032:mdna:9]
[same as prior period, unchanged from 0001262039-23-000021:mdna:11]

[0001262039-23-000032:mdna:10]
[same as prior period, unchanged from 0001262039-23-000021:mdna:12]

[0001262039-23-000032:mdna:11]
[same as prior period, unchanged from 0001262039-23-000021:mdna:13]

[0001262039-23-000032:mdna:12]
[same as prior period, unchanged from 0001262039-23-000021:mdna:2]

[0001262039-23-000032:mdna:13]
[same as prior period, unchanged from 0001262039-23-000021:mdna:14]

[0001262039-23-000032:mdna:14]
[same as prior period, unchanged from 0001262039-23-000021:mdna:15]

[0001262039-23-000032:mdna:15]
[same as prior period, unchanged from 0001262039-23-000021:mdna:16]

[0001262039-23-000032:mdna:16]
[same as prior period, unchanged from 0001262039-23-000021:mdna:17]

[0001262039-23-000032:mdna:17]
•trends in revenue, cost of revenue and gross margin, including expectations regarding product revenue and service revenue growth;

[0001262039-23-000032:mdna:18]
[same as prior period, unchanged from 0001262039-23-000021:mdna:19]

[0001262039-23-000032:mdna:19]
•plans and strategy for the acceleration of our points of presence (“PoP”) deployment;

[0001262039-23-000032:mdna:20]
•expectations that our operating expenses will increase in absolute dollars during the remainder of 2023;

[0001262039-23-000032:mdna:21]
26

[0001262039-23-000032:mdna:22]
[same as prior period, unchanged from 0001262039-23-000021:mdna:22]

[0001262039-23-000032:mdna:23]
•expectations regarding uncertain tax benefits and our effective domestic and global tax rates, the impact of interpretations of or changes to tax law, and the timing of tax payments;

[0001262039-23-000032:mdna:24]
[same as prior period, unchanged from 0001262039-23-000021:mdna:24]

[0001262039-23-000032:mdna:25]
[same as prior period, unchanged from 0001262039-23-000021:mdna:25]

[0001262039-23-000032:mdna:26]
[same as prior period, unchanged from 0001262039-23-000021:mdna:26]

[0001262039-23-000032:mdna:27]
•expected outcomes and liabilities in litigation;

[0001262039-23-000032:mdna:28]
[same as prior period, unchanged from 0001262039-23-000021:mdna:28]

[0001262039-23-000032:mdna:29]
[same as prior period, unchanged from 0001262039-23-000021:mdna:29]

[0001262039-23-000032:mdna:30]
[same as prior period, unchanged from 0001262039-23-000021:mdna:30]

[0001262039-23-000032:mdna:31]
[same as prior period, unchanged from 0001262039-23-000021:mdna:31]

[0001262039-23-000032:mdna:32]
Fortinet is a global leader in cybersecurity and secure networking solutions. Our mission is to secure people, devices and data everywhere. We deliver cybersecurity everywhere our customers need it with an integrated portfolio of over 50 enterprise-grade products. As of June 30, 2023, over half a million customers, including enterprises, communication service providers and security service providers, government organizations and small and medium-sized businesses, trusted our solutions.

[0001262039-23-000032:mdna:33]
Our product offerings are designed to converge networking and security into a single solution, consolidate cybersecurity point products into an integrated platform and deliver operational-technology (“OT”) aware features to secure OT environments. This allows customers to realize automated protection, improve detection and response times, and provide visibility across both Fortinet-developed solutions and a broad ecosystem of over 500 third-party solutions and technologies. As a U.S.-based company, the majority of Fortinet’s research and development is based in North America, with a global footprint of support and centers of excellence across time zones from North America to Europe to Asia. We held 1,285 U.S. and foreign-issued patents as of June 30, 2023, a testament to our dedication to innovation that delivers leading cybersecurity and networking solutions.

[0001262039-23-000032:mdna:34]
[same as prior period, unchanged from 0001262039-23-000021:mdna:34]

[0001262039-23-000032:mdna:35]
[same as prior period, unchanged from 0001262039-23-000021:mdna:35]

[0001262039-23-000032:mdna:36]
[same as prior period, unchanged from 0001262039-23-000021:mdna:36]

[0001262039-23-000032:mdna:37]
[same as prior period, unchanged from 0001262039-23-000021:mdna:37]

[0001262039-23-000032:mdna:38]
27

[0001262039-23-000032:mdna:39]
[same as prior period, unchanged from 0001262039-23-000021:mdna:38]

[0001262039-23-000032:mdna:40]
[same as prior period, unchanged from 0001262039-23-000021:mdna:39]

[0001262039-23-000032:mdna:41]
[same as prior period, unchanged from 0001262039-23-000021:mdna:40]

[0001262039-23-000032:mdna:42]
[same as prior period, unchanged from 0001262039-23-000021:mdna:41]

[0001262039-23-000032:mdna:43]
[same as prior period, unchanged from 0001262039-23-000021:mdna:42]

[0001262039-23-000032:mdna:44]
Secure Networking—Our Secure Networking solutions enable the convergence of networking and security by integrating multiple markets and use cases into a single operating system: the Fortinet Operating System (“FortiOS”). It can be delivered to customers through an application-specific integrated circuit (“ASIC”)-accelerated hardware appliance, virtual machine, as-a-Service, cloud native and container. When delivered via our appliances, functionality is accelerated with the use of our proprietary ASIC technology, which consists of three processors. First, a seventh generation network processor, FortiNP7, accelerates the processing of firewall traffic and offloads this function from the central processing unit (“CPU”). Second, a ninth generation content processor, FortiCP9, helps the CPU with deep packet inspection functions such as intrusion prevention and antivirus. Multiple CPUs, NP7s and CP9s can be placed in larger firewalls to provide more scale. Third, the CPU, network processor and content processor functions are all brought together in a single ASIC, our fifth generation Security Processor, FortiSP5. These proprietary ASICs, along with off the shelf CPU and ASICs, allow our systems to scale from the smallest branch to a hyperscale cloud and run multiple applications at higher performance and lower power consumption.

[0001262039-23-000032:mdna:45]
[same as prior period, unchanged from 0001262039-23-000021:mdna:44]

[0001262039-23-000032:mdna:46]
[same as prior period, unchanged from 0001262039-23-000021:mdna:45]

[0001262039-23-000032:mdna:47]
[same as prior period, unchanged from 0001262039-23-000021:mdna:46]

[0001262039-23-000032:mdna:48]
[same as prior period, unchanged from 0001262039-23-000021:mdna:47]

[0001262039-23-000032:mdna:49]
•Universal Secure Access Service Edge

[0001262039-23-000032:mdna:50]
•Cloud Security

[0001262039-23-000032:mdna:51]
[same as prior period, unchanged from 0001262039-23-000021:mdna:49]

[0001262039-23-000032:mdna:52]
[same as prior period, unchanged from 0001262039-23-000021:mdna:50]

[0001262039-23-000032:mdna:53]
Cybersecurity Platform—Many enterprises are looking to consolidate point products into a cybersecurity platform to improve the efficiency and efficacy of their security. This platform approach is also known as a Cybersecurity Mesh Architecture, or our more expansive Fortinet Security Fabric, which includes FortiGuard AI-powered services and integrated security products engineered with automation in mind to support customers in building a cybersecurity platform. The Fortinet Security Fabric facilitates dynamic information sharing across customers’ security infrastructure as well as the automation of workflows, including response. The result is improved prevention while significantly reducing Mean-Time-to-Detect and Mean-Time-to-Respond to cyber threats. The major cybersecurity markets of our business include:

[0001262039-23-000032:mdna:54]
[same as prior period, unchanged from 0001262039-23-000021:mdna:52]

[0001262039-23-000032:mdna:55]
[same as prior period, unchanged from 0001262039-23-000021:mdna:53]

[0001262039-23-000032:mdna:56]
[same as prior period, unchanged from 0001262039-23-000021:mdna:63]

[0001262039-23-000032:mdna:57]
[same as prior period, unchanged from 0001262039-23-000021:mdna:54]

[0001262039-23-000032:mdna:58]
[same as prior period, unchanged from 0001262039-23-000021:mdna:55]

[0001262039-23-000032:mdna:59]
[same as prior period, unchanged from 0001262039-23-000021:mdna:56]

[0001262039-23-000032:mdna:60]
[same as prior period, unchanged from 0001262039-23-000021:mdna:57]

[0001262039-23-000032:mdna:61]
[same as prior period, unchanged from 0001262039-23-000021:mdna:58]

[0001262039-23-000032:mdna:62]
[same as prior period, unchanged from 0001262039-23-000021:mdna:59]

[0001262039-23-000032:mdna:63]
[same as prior period, unchanged from 0001262039-23-000021:mdna:60]

[0001262039-23-000032:mdna:64]
•Cloud Security

[0001262039-23-000032:mdna:65]
[same as prior period, unchanged from 0001262039-23-000021:mdna:61]

[0001262039-23-000032:mdna:66]
[same as prior period, unchanged from 0001262039-23-000021:mdna:62]

[0001262039-23-000032:mdna:67]
[same as prior period, unchanged from 0001262039-23-000021:mdna:64]

[0001262039-23-000032:mdna:68]
To support our broad portfolio of cybersecurity products, we deliver the following AI-powered FortiGuard Threat Intelligence Services:

[0001262039-23-000032:mdna:69]
[same as prior period, unchanged from 0001262039-23-000021:mdna:66]

[0001262039-23-000032:mdna:70]
[same as prior period, unchanged from 0001262039-23-000021:mdna:67]

[0001262039-23-000032:mdna:71]
[same as prior period, unchanged from 0001262039-23-000021:mdna:68]

[0001262039-23-000032:mdna:72]
[same as prior period, unchanged from 0001262039-23-000021:mdna:69]

[0001262039-23-000032:mdna:73]
•Security Operations Center (“SOC”) Services, including SOC-as-a-Service, Managed Detection and Response, Incident Readiness and Response (active incident and proactive services), Outbreak Protection, Attack Surface Monitoring, Threat Hunting, and Indicators of Compromise services.

[0001262039-23-000032:mdna:74]
Operational Technology Security—OT uses hardware and software to detect or cause a change through the direct monitoring and/or control of industrial equipment, assets, processes and events. The security of such environments is sometimes described as Cyber-Physical Systems. The increased connectivity of OT environments and the need for employee and vendor access has increased the risk across OT industries such as manufacturing, energy, utilities, medical, transport, and critical infrastructure. While the basic concepts of Secure Networking and Cybersecurity Platform apply, OT systems are very different from a traditional information technology system. Fortinet delivers OT-Aware security capabilities that are purpose-built for operational technology environments. These capabilities underpin our OT-Aware Security Fabric, which spans the following products and services:

[0001262039-23-000032:mdna:75]
[same as prior period, unchanged from 0001262039-23-000021:mdna:72]

[0001262039-23-000032:mdna:76]
[same as prior period, unchanged from 0001262039-23-000021:mdna:73]

[0001262039-23-000032:mdna:77]
[same as prior period, unchanged from 0001262039-23-000021:mdna:74]

[0001262039-23-000032:mdna:78]
[same as prior period, unchanged from 0001262039-23-000021:mdna:75]

[0001262039-23-000032:mdna:79]
[same as prior period, unchanged from 0001262039-23-000021:mdna:76]

[0001262039-23-000032:mdna:80]
[same as prior period, unchanged from 0001262039-23-000021:mdna:77]

[0001262039-23-000032:mdna:81]
•Total revenue was $1.29 billion and $2.56 billion during the three and six months ended June 30, 2023, an increase of 26% and 29%, respectively, compared to $1.03 billion and $1.98 billion in the same periods last year. Product revenue was $472.6 million and $973.3 million during the three and six months ended June 30, 2023, an increase of 18% and 26%, respectively, compared to $400.7 million and $771.7 million in the same periods last year. Service revenue was $820.2 million and $1.58 billion during the three and six months ended June 30, 2023, an increase of 30%, in each period respectively, compared to $629.4 million and $1.21 billion in the same periods last year.

[0001262039-23-000032:mdna:82]
29

[0001262039-23-000032:mdna:83]
•Total gross profit was $997.0 million and $1.95 billion during the three and six months ended June 30, 2023, an increase of 28% and 32%, respectively, compared to $779.3 million and $1.48 billion in the same periods last year.

[0001262039-23-000032:mdna:84]
•Operating income was $279.0 million and $552.5 million during the three and six months ended June 30, 2023, an increase of 43% and 60%, respectively, compared to $195.3 million and $346.3 million in the same periods last year.

[0001262039-23-000032:mdna:85]
•Cash, cash equivalents, short-term and long-term investments and marketable equity securities were $3.32 billion as of June 30, 2023.

[0001262039-23-000032:mdna:86]
•Deferred revenue was $5.13 billion as of June 30, 2023, an increase of $488.3 million, or 11%, compared to $4.64 billion as of December 31, 2022 and an increase of $1.20 billion, or 30%, compared to $3.93 billion as of June 30, 2022. Deferred revenue was $3.93 billion as of June 30, 2022, an increase of $479.1 million, or 14%, compared to $3.45 billion as of December 31, 2021 and an increase of $1.03 billion, or 35%, compared to $2.91 billion as of June 30, 2021.

[0001262039-23-000032:mdna:87]
•Short-term deferred revenue was $2.59 billion as of June 30, 2023, an increase of $238.4 million, or 10%, compared to $2.35 billion as of December 31, 2022 and an increase of $574.5 million, or 29%, compared to $2.01 billion as of June 30, 2022. Short-term deferred revenue was $2.01 billion as of June 30, 2022, an increase of $235.8 million, or 13%, compared to $1.78 billion as of December 31, 2021 and an increase of $480.2 million, or 31%, compared to $1.53 billion as of June 30, 2021.

[0001262039-23-000032:mdna:88]
•We generated cash flows from operating activities of $1.19 billion during the six months ended June 30, 2023, an increase of $473.1 million, or 66%, compared to the same period last year.

[0001262039-23-000032:mdna:89]
On a geographic basis, revenue continues to be diversified, which remains a key strength of our business. During the three months ended June 30, 2023, the Americas region, the Europe, Middle East and Africa (“EMEA”) region and the Asia Pacific (“APAC”) region contributed 42%, 39% and 19% of our total revenue, respectively, and increased 30%, 29% and 11% compared to the same period last year, respectively. During the six months ended June 30, 2023, the Americas region, the EMEA region and the APAC region contributed 41%, 39% and 20% of our total revenue, respectively, and increased by 33%, 34% and 13% compared to the same period last year, respectively.

[0001262039-23-000032:mdna:90]
Our revenue growth was driven by growth in service revenue and in Enhanced Platform Technology product revenue. Product revenue grew 18% and 26%, respectively, during the three and six months ended June 30, 2023, compared to the same periods last year. Product revenue growth was consistent with an elevated cyber threat landscape, the convergence of security and networking and included the benefit of certain historical pricing actions, improving supply chain dynamics and changes in the backlog balance. The product revenue growth was primarily due to strong growth in our Enhanced Platform Technology products, including our secure access products. Service revenue growth of 30% during both the three and six months ended June 30, 2023, compared to the same periods last year, was primarily driven by the strength of our FortiGuard and other security subscription revenue, which grew 34% and 35%, respectively.

[0001262039-23-000032:mdna:91]
Our billings were diversified on a geographic basis. During the three months ended June 30, 2023, approximately 50% of our billings in the aggregate were from over 100 countries that each individually contributed less than 3% of our billings.

[0001262039-23-000032:mdna:92]
Operating expenses as a percentage of revenue benefited from the favorable impact of foreign currency fluctuations and decreased 1.2 and 2.3 percentage points, respectively, during the three and six months ended June 30, 2023, compared to the same periods last year. Headcount increased to 13,677 employees and contractors as of June 30, 2023, a 9% increase compared to 12,595 as of December 31, 2022.

[0001262039-23-000032:mdna:93]
Impact of Macroeconomic Developments

[0001262039-23-000032:mdna:94]
Our overall performance depends in part on worldwide economic and geopolitical conditions and their impact on customer behavior. Worsening economic conditions, including inflation, higher interest rates, slower growth, any recession, fluctuations in foreign exchange rates, instability in the global banking industry, and other changes in economic conditions, may result in decreased sales productivity and growth and adversely affect our results of operations and financial performance. We have seen certain impacts on our business, results of operations, financial condition, cash flows, liquidity and capital and financial resources such as longer sales cycles, delayed purchases and increased commitments with certain suppliers and excess product inventory.

[0001262039-23-000032:mdna:95]
[same as prior period, unchanged from 0001262039-23-000021:mdna:113]

[0001262039-23-000032:mdna:96]
Our days sales outstanding decreased to 75 days in the second quarter of 2023, compared to 80 days in the same period last year. The accounts receivable allowance for credit losses was $5.3 million as of June 30, 2023, an increase of $1.7 million compared to $3.6 million as of December 31, 2022, primarily due to an increase in past due invoices over 60 and 90 days.

[0001262039-23-000032:mdna:97]
Worsening economic conditions may have a material negative impact on our results in future periods and may negatively impact our billings, revenue and costs, and may decrease growth and profitability. The extent of the impact of economic conditions on our operational and financial performance will depend on ongoing developments, including those discussed above and others identified in Part II, Item 1A “Risk Factors” in this Form 10-Q. Given the dynamic nature of these circumstances, the full impact of worsening economic conditions on our business and operations, results of operations, financial condition, cash flows, liquidity and capital and financial resources cannot be reasonably estimated at this time.

[0001262039-23-000032:mdna:98]
[same as prior period, unchanged from 0001262039-23-000021:mdna:96]

[0001262039-23-000032:mdna:99]
[same as prior period, unchanged from 0001262039-23-000021:mdna:97]

[0001262039-23-000032:mdna:100]
[same as prior period, unchanged from 0001262039-23-000021:mdna:98]

[0001262039-23-000032:mdna:101]
We also offer our products hosted in our own data centers, PoPs and through co-locations and major cloud providers, including Amazon Web Services, Microsoft Azure and Google Cloud. We have also recognized revenue from customers who deploy our products in a bring-your-own-license (“BYOL”) arrangements at cloud providers or at private clouds. In a BYOL arrangement, a customer purchases a software license through our channel partners and deploys the software in a cloud provider’s environment, in third-party clouds or in their private cloud.

[0001262039-23-000032:mdna:102]
[same as prior period, unchanged from 0001262039-23-000021:mdna:100]

[0001262039-23-000032:mdna:103]
[same as prior period, unchanged from 0001262039-23-000021:mdna:101]

[0001262039-23-000032:mdna:104]
|  | Three Months Ended Or As Of |
|  | June 30, 2023 |  | June 30, 2022 |
|  | (in millions) |
| Revenue | $ | 1,292.8 |  |  | $ | 1,030.1 |  |
| Deferred revenue | $ | 5,128.6 |  |  | $ | 3,932.0 |  |
| Billings (non-GAAP) | $ | 1,540.5 |  |  | $ | 1,304.2 |  |
| Net cash provided by operating activities | $ | 515.1 |  |  | $ | 323.4 |  |
| Free cash flow (non-GAAP) | $ | 438.3 |  |  | $ | 283.5 |  |

[0001262039-23-000032:mdna:105]
Deferred revenue. Our deferred revenue consists of amounts that have been invoiced but that have not yet been recognized as revenue. The majority of our deferred revenue balance consists of the unrecognized portion of service revenue from FortiGuard and other security subscriptions and FortiCare technical support service contracts, which is recognized as revenue ratably over the service term. We monitor our deferred revenue balance, short-term and total deferred revenue growth and the mix of short-term and long-term deferred revenue because deferred revenue represents a significant portion of free cash flow and of revenue to be recognized in future periods. Deferred revenue was $5.13 billion as of June 30, 2023, an increase of $488.3 million, or 11%, from December 31, 2022. Short term deferred revenue was $2.59 billion as of June 30, 2023, an increase of $238.4 million, or 10%, from December 31, 2022.

[0001262039-23-000032:mdna:106]
Billings (non-GAAP). We define billings as revenue recognized in accordance with GAAP plus the change in deferred revenue from the beginning to the end of the period. We consider billings to be a useful metric for management and investors because billings drive current and future revenue, which is an important indicator of the health and viability of our business. There are several limitations related to the use of billings instead of GAAP revenue. First, billings include amounts that have not yet been recognized as revenue and are impacted by the term of FortiGuard security subscription and FortiCare technical support agreements. Second, we may calculate billings in a manner that is different from peer companies that report similar financial measures. Management accounts for these limitations by providing specific information regarding GAAP revenue and evaluating billings together with GAAP revenue. Total billings were $1.54 billion for the three months ended June 30, 2023, an increase of 18% compared to $1.30 billion in the same period last year.

[0001262039-23-000032:mdna:107]
Our backlog has fluctuated over past quarters and any decrease in growth or negative growth of in-quarter billings and revenue may not be reflected by our aggregate billings and revenue. As we fulfill, ship and bill during a quarter to satisfy backlog, this will increase our aggregate billings and revenue during any particular quarter.

[0001262039-23-000032:mdna:108]
[same as prior period, unchanged from 0001262039-23-000021:mdna:107]

[0001262039-23-000032:mdna:109]
|  | Three Months Ended |
|  | June 30, 2023 |  | June 30, 2022 |
|  | (in millions) |
| Billings: |  |  |  |
| Revenue | $ | 1,292.8 |  |  | $ | 1,030.1 |  |
| Add: Change in deferred revenue | 247.7 |  |  | 274.1 |  |
| Total billings (non-GAAP) | $ | 1,540.5 |  |  | $ | 1,304.2 |  |

[0001262039-23-000032:mdna:110]
[same as prior period, unchanged from 0001262039-23-000021:mdna:109]

[0001262039-23-000032:mdna:111]
|  | Three Months Ended |
|  | June 30, 2023 |  | June 30, 2022 |
|  | (in millions) |
| Free Cash Flow: |  |  |  |
| Net cash provided by operating activities | $ | 515.1 |  |  | $ | 323.4 |  |
| Less: Purchases of property and equipment | (76.8) |  |  | (39.9) |  |
| Free cash flow (non-GAAP) | $ | 438.3 |  |  | $ | 283.5 |  |
| Net cash provided by (used in) investing activities | $ | (424.1) |  |  | $ | 294.1 |  |
| Net cash used in financing activities | $ | (17.7) |  |  | $ | (830.3) |  |

[0001262039-23-000032:mdna:112]
[same as prior period, unchanged from 0001262039-23-000021:mdna:111]

[0001262039-23-000032:mdna:113]
Our discussion and analysis of our financial condition and results of operations are based upon our financial statements, which have been prepared in accordance with GAAP. These principles require us to make estimates and judgments that affect the reported amounts of assets, liabilities, revenue, cost of revenue and expenses, and related disclosures. We base

[0001262039-23-000032:mdna:114]
our estimates on historical experience and on various other assumptions that we believe to be reasonable under the circumstances. To the extent that there are material differences between these estimates and our actual results, our future financial statements will be affected.

[0001262039-23-000032:mdna:115]
There were no material changes to our critical accounting policies and estimates as of and for the three and six months ended June 30, 2023, as compared to the critical accounting policies and estimates described in our Annual Report on Form 10-K filed with the SEC on February 24, 2023 (the “Form 10-K”).

[0001262039-23-000032:mdna:116]
[same as prior period, unchanged from 0001262039-23-000021:mdna:116]

[0001262039-23-000032:mdna:117]
[same as prior period, unchanged from 0001262039-23-000021:mdna:117]

[0001262039-23-000032:mdna:118]
Three Months Ended June 30, 2023 and 2022

[0001262039-23-000032:mdna:119]
[same as prior period, unchanged from 0001262039-23-000021:mdna:119]

[0001262039-23-000032:mdna:120]
|  | Three Months Ended |  |  |  |  |
| June 30,2023 |  | June 30,2022 |  |  |  |  |
| Amount |  | % ofRevenue |  | Amount |  | % ofRevenue |  | Change |  | % Change |
| (in millions, except percentages) |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 472.6 |  |  | 37 | % |  | $ | 400.7 |  |  | 39 | % |  | $ | 71.9 |  |  | 18 | % |
| Service | 820.2 |  |  | 63 |  |  | 629.4 |  |  | 61 |  |  | 190.8 |  |  | 30 |  |
| Total revenue | $ | 1,292.8 |  |  | 100 | % |  | $ | 1,030.1 |  |  | 100 | % |  | $ | 262.7 |  |  | 26 | % |
| Revenue by geography: |  |  |  |  |  |  |  |  |  |  |  |
| Americas | $ | 537.0 |  |  | 42 | % |  | $ | 413.6 |  |  | 40 | % |  | $ | 123.4 |  |  | 30 | % |
| EMEA | 506.9 |  |  | 39 |  |  | 391.8 |  |  | 38 |  |  | 115.1 |  |  | 29 |  |
| APAC | 248.9 |  |  | 19 |  |  | 224.7 |  |  | 22 |  |  | 24.2 |  |  | 11 |  |
| Total revenue | $ | 1,292.8 |  |  | 100 | % |  | $ | 1,030.1 |  |  | 100 | % |  | $ | 262.7 |  |  | 26 | % |

[0001262039-23-000032:mdna:121]
Total revenue increased $262.7 million, or 26%, during the three months ended June 30, 2023 compared to the same period last year. We continued to experience significant organic revenue growth (i.e., revenue growth excluding attribution from recent acquisitions) with diversification of revenue geographically, and across both customers and industries. Revenue from all regions grew, with the Americas contributing the largest portion of the increase on an absolute dollar basis and on a percentage basis.

[0001262039-23-000032:mdna:122]
Product revenue increased $71.9 million, or 18%, during the three months ended June 30, 2023 compared to the same period last year. Product revenue growth was consistent with an elevated cyber threat landscape, the convergence of security and networking and included the benefit of certain historical pricing actions, improving supply chain dynamics and changes in the backlog balance. The product revenue growth was primarily due to strong growth in our Enhanced Platform Technology products, including our secure access products. We expect growth in product revenue to be impacted by product lead times and backlog approaching normal levels beginning in the third quarter of 2023.

[0001262039-23-000032:mdna:123]
Service revenue increased $190.8 million, or 30%, during the three months ended June 30, 2023 compared to the same period last year. FortiGuard and other security subscription revenue increased $116.9 million, or 34%, and technical support and other services revenue increased $73.9 million, or 26%, during the three months ended June 30, 2023 compared to the same period last year. Excluding Alaxala, technical support growth increased 28% during the three months ended June 30, 2023. The increases were primarily due to pricing actions in prior periods, strength in our SaaS offerings and the recognition of revenue from our growing deferred revenue balance related to FortiGuard and other security subscriptions as well as FortiCare technical support and other services. FortiGuard outpaced technical support growth due to expansion of our SaaS-based security subscription service offerings, while technical support growth was impacted by lower service revenue of Alaxala. We expect that our ability to grow our service revenue will be impacted by our expansion to secure access service edge (“SASE”) delivery model.

[0001262039-23-000032:mdna:124]
33

[0001262039-23-000032:mdna:125]
Of the service revenue recognized during the three months ended June 30, 2023, 89% was included in the deferred revenue balance as of March 31, 2023. Of the service revenue recognized during the three months ended June 30, 2022, 87% was included in the deferred revenue balance as of March 31, 2022. We expect service revenue will continue to benefit from previous pricing actions. However, there are risks to service revenue growth rates, including customers reducing their spending, pricing actions, supply chain constraints, customers taking longer to buy their service and other risks.

[0001262039-23-000032:mdna:126]
[same as prior period, unchanged from 0001262039-23-000021:mdna:125]

[0001262039-23-000032:mdna:127]
|  | Three Months Ended |  |  |  |  |
| June 30,2023 |  | June 30,2022 |  | Change |  | % Change |
| (in millions, except percentages) |
| Cost of revenue: |  |  |  |  |  |  |  |
| Product | $ | 174.5 |  |  | $ | 155.2 |  |  | $ | 19.3 |  |  | 12 | % |
| Service | 121.3 |  |  | 95.6 |  |  | 25.7 |  |  | 27 |  |
| Total cost of revenue | $ | 295.8 |  |  | $ | 250.8 |  |  | $ | 45.0 |  |  | 18 | % |
| Gross margin (%): |  |  |  |  |  |  |  |
| Product | 63.1 | % |  | 61.3 | % |  |  |  |  |
| Service | 85.2 |  |  | 84.8 |  |  |  |  |  |
| Total gross margin | 77.1 | % |  | 75.7 | % |  |  |  |  |

[0001262039-23-000032:mdna:128]
Total gross margin increased 1.4 percentage points during the three months ended June 30, 2023 compared to the same period last year, primarily driven by increased product and service gross margins and a shift in the revenue mix. As a percentage of total revenue, the revenue mix shifted 2.3 percentage points from product revenue to service revenue.

[0001262039-23-000032:mdna:129]
Product gross margin increased 1.8 percentage points during the three months ended June 30, 2023 compared to the same period last year. The product margin primarily benefited from earlier pricing actions, lower expedite fees and freight costs and partially offset by higher inventory related reserve expense. Cost of product revenue was comprised primarily of third-party contract manufacturers’ costs and the costs of materials used in production.

[0001262039-23-000032:mdna:130]
Service gross margin increased 0.4 percentage points during the three months ended June 30, 2023 compared to the same period last year. Cost of service revenue was comprised primarily of personnel and data center costs. The increase in service gross margin was primarily driven by pricing actions in earlier periods and the favorable impact of foreign currency fluctuations, partially offset by increased labor cost and increased cloud delivery costs as we continue to expand our cloud to SASE delivery models. We consider our single vendor SASE solution opening to be a  new market, and one where our SD-WAN installed base can be leveraged as a market access point. We plan to accelerate our PoPs, or PoP deployment, with our dual strategy to invest in our own PoPs as well as working with third-party providers to accelerate our deployment.

[0001262039-23-000032:mdna:131]
34

[0001262039-23-000032:mdna:132]
[same as prior period, unchanged from 0001262039-23-000021:mdna:131]

[0001262039-23-000032:mdna:133]
|  | Three Months Ended |  | Change |  | % Change |
| June 30,2023 |  | June 30,2022 |  |
| Amount |  | % ofRevenue |  | Amount |  | % ofRevenue |  |
| (in millions, except percentages) |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | $ | 153.3 |  |  | 12 | % |  | $ | 124.3 |  |  | 12 | % |  | $ | 29.0 |  |  | 23 | % |
| Sales and marketing | 515.9 |  |  | 40 |  |  | 415.5 |  |  | 40 |  |  | 100.4 |  |  | 24 |  |
| General and administrative | 49.9 |  |  | 4 |  |  | 45.4 |  |  | 4 |  |  | 4.5 |  |  | 10 |  |
| Gain on IP matter | (1.1) |  |  | — |  |  | (1.2) |  |  | — |  |  | 0.1 |  |  | (8) |  |
| Total operating expenses | $ | 718.0 |  |  | 56 | % |  | $ | 584.0 |  |  | 57 | % |  | $ | 134.0 |  |  | 23 | % |
| Percentages have been rounded for presentation purposes and may differ from unrounded results. |

[0001262039-23-000032:mdna:134]
[same as prior period, unchanged from 0001262039-23-000021:mdna:133]

[0001262039-23-000032:mdna:135]
Research and development expense increased $29.0 million, or 23%, during the three months ended June 30, 2023 compared to the same period last year, primarily due to a $21.7 million increase in personnel-related costs as a result of increased headcount to support the development of new products and continued enhancements to our existing products. In addition, we incurred an increase of $3.5 million of depreciation and other occupancy costs and an increase of $3.3 million of product development costs, partially offset by the favorable impact of foreign currency fluctuations. We currently intend to continue investing in our research and development organization, and expect our research and development expense to increase in absolute dollars during the remainder of 2023.

[0001262039-23-000032:mdna:136]
[same as prior period, unchanged from 0001262039-23-000021:mdna:135]

[0001262039-23-000032:mdna:137]
Sales and marketing expense increased $100.4 million, or 24%, during the three months ended June 30, 2023 compared to the same period last year, primarily due to a $74.0 million increase in personnel-related costs as we increased our sales and pipeline generation capacity. The increase in headcount is expected to help drive global market revenue increases. In addition, we incurred increases in marketing-related expense of $13.1 million, travel expense of $6.5 million, and depreciation and other occupancy expense of $5.3 million. We currently intend to continue making investments in sales and marketing resources critical to support our future growth and expect our sales and marketing expense to increase in absolute dollars during the remainder of 2023.

[0001262039-23-000032:mdna:138]
[same as prior period, unchanged from 0001262039-23-000021:mdna:137]

[0001262039-23-000032:mdna:139]
General and administrative expense increased $4.5 million, or 10%, during the three months ended June 30, 2023 compared to the same period last year, primarily due to an increase of $5.4 million in personnel-related costs, $2.8 million in legal and other professional service fees, and partially offset by a decrease of $4.1 million in provision for expected credit losses. We currently expect general and administrative expense to increase in absolute dollars during the remainder of 2023.

[0001262039-23-000032:mdna:140]
[same as prior period, unchanged from 0001262039-23-000021:mdna:139]

[0001262039-23-000032:mdna:141]
We generated operating income of $279.0 million during the three months ended June 30, 2023, an increase of $83.7 million, or 43%, compared to $195.3 million in the same period last year. Operating income as a percentage of revenue was 21.6% during the three months ended June 30, 2023, compared to 19.0% in the same period last year, due to the stronger gross margin performance. The increase in operating margin primarily benefits from 1.4 percentage points increase in gross margin, and 0.5 percentage points, 0.4 percentage points and 0.2 percentage points decreases in general and administrative expense, sales and marketing expense and research and development expense as a percentage of revenue, respectively.

[0001262039-23-000032:mdna:142]
Interest income, interest expense and other expense—net

[0001262039-23-000032:mdna:143]
|  | Three Months Ended |  |  |  |  |
| June 30,2023 |  | June 30,2022 |  | Change |  | % Change |
| (in millions, except percentages) |
| Interest income | $ | 31.6 |  |  | $ | 2.4 |  |  | $ | 29.2 |  |  | 1,217 | % |
| Interest expense | $ | (5.2) |  |  | $ | (4.5) |  |  | $ | (0.7) |  |  | 16 | % |
| Other expense—net | $ | (6.2) |  |  | $ | (9.3) |  |  | $ | 3.1 |  |  | (33) | % |

[0001262039-23-000032:mdna:144]
Interest income increased $29.2 million during the three months ended June 30, 2023 compared to the same period last year, as a result of higher interest rates and greater investment balances. Interest income varies depending on our average investment balances during the period, types and mix of investments, and market interest rates. Interest expense remained comparatively flat during the three months ended June 30, 2023 compared to the same period last year. The $3.1 million decrease in Other expense—net during the three months ended June 30, 2023 compared to the same period last year, was primarily due to a $4.1 million recovery in the loss on marketable equity securities, offset by a $1.8 million increase in foreign currency exchange loss.

[0001262039-23-000032:mdna:145]
Provision for income taxes

[0001262039-23-000032:mdna:146]
|  | Three Months Ended |  | Change |  | % Change |
| June 30,2023 |  | June 30,2022 |  |
| (in millions, except percentages) |
| Provision for income taxes | $ | 27.6 |  |  | $ | 2.4 |  |  | $ | 25.2 |  |  | 1,050 | % |
| Effective tax rate (%) | 9 | % |  | 1 | % |  |  |  |  |

[0001262039-23-000032:mdna:147]
Our effective tax rate was 9% for the three months ended June 30, 2023 compared to an effective tax rate of 1% for the same period last year. The provision for income taxes for the three months ended June 30, 2023 was primarily comprised of U.S. federal and state taxes, withholding taxes and foreign taxes totaling $84.8 million, which were favorably affected by a tax benefit of $25.8 million from the foreign-derived intangible income deduction (the “FDII deduction”), excess tax benefits from stock-based compensation expense of $13.3 million, and the release of reserves of $18.1 million on uncertain tax positions and the accrued interest thereon due to the expiration of statutes of limitations.

[0001262039-23-000032:mdna:148]
The provision for income taxes for the three months ended June 30, 2022 was comprised of U.S. federal and state taxes, withholding taxes, and foreign taxes totaling $54.5 million, which were favorably affected by a tax benefit of $18.6 million from the FDII deduction, excess tax benefits from stock-based compensation expense of $17.3 million, and the release of reserves of $16.2 million on uncertain tax positions and the accrued interest thereon due to the expiration of statutes of limitations.

[0001262039-23-000032:mdna:149]
[same as prior period, unchanged from 0001262039-23-000021:mdna:148]

[0001262039-23-000032:mdna:150]
|  | Three Months Ended |  | Change |  | % Change |
| June 30,2023 |  | June 30,2022 |  |
| (in millions, except percentages) |
| Loss from equity method investment | $ | (5.3) |  |  | $ | (8.1) |  |  | $ | 2.8 |  |  | (35) | % |

[0001262039-23-000032:mdna:151]
Loss from equity method investment decreased $2.8 million during the three months ended June 30, 2023 compared to the same period last year, due to the decrease in our proportionate share of loss of Linksys’ financial results as well as our share of the amortization of the basis differences.

[0001262039-23-000032:mdna:152]
Six Months Ended June 30, 2023 and 2022

[0001262039-23-000032:mdna:153]
Revenue

[0001262039-23-000032:mdna:154]
|  | Six Months Ended |  |  |  |  |
| June 30,2023 |  | June 30,2022 |  |  |  |  |
| Amount |  | % ofRevenue |  | Amount |  | % ofRevenue |  | Change |  | % Change |
| (in millions, except percentages) |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 973.3 |  |  | 38 | % |  | $ | 771.7 |  |  | 39 | % |  | $ | 201.6 |  |  | 26 | % |
| Service | 1,581.8 |  |  | 62 |  |  | 1,213.2 |  |  | 61 |  |  | 368.6 |  |  | 30 |  |
| Total revenue | $ | 2,555.1 |  |  | 100 | % |  | $ | 1,984.9 |  |  | 100 | % |  | $ | 570.2 |  |  | 29 | % |
| Revenue by geography: |  |  |  |  |  |  |  |  |  |  |  |
| Americas | $ | 1,060.5 |  |  | 41 | % |  | $ | 796.2 |  |  | 40 | % |  | $ | 264.3 |  |  | 33 | % |
| EMEA | 985.1 |  |  | 39 |  |  | 737.8 |  |  | 37 |  |  | 247.3 |  |  | 34 |  |
| APAC | 509.5 |  |  | 20 |  |  | 450.9 |  |  | 23 |  |  | 58.6 |  |  | 13 |  |
| Total revenue | $ | 2,555.1 |  |  | 100 | % |  | $ | 1,984.9 |  |  | 100 | % |  | $ | 570.2 |  |  | 29 | % |

[0001262039-23-000032:mdna:155]
Total revenue increased $570.2 million, or 29%, during the six months ended June 30, 2023 compared to the same period last year. We continued to experience significant organic revenue growth (i.e., revenue growth excluding attribution from recent acquisitions) with diversification of revenue geographically, and across both customers and industries. Revenue from all regions grew, with the Americas contributing the largest portion of the increase on an absolute dollar basis and EMEA contributing the largest portion of the increase on a percentage basis.

[0001262039-23-000032:mdna:156]
Product revenue increased $201.6 million, or 26%, during the six months ended June 30, 2023 compared to the same period last year. Product revenue growth was consistent with an elevated cyber threat landscape, the convergence of security and networking and included the benefit of certain historical pricing actions, improving supply chain dynamics and changes in the backlog balance. The product revenue growth was primarily due to strong growth across many of our Enhanced Platform Technology products, including our secure access products.

[0001262039-23-000032:mdna:157]
Service revenue increased $368.6 million, or 30%, during the six months ended June 30, 2023 compared to the same period last year. FortiGuard and other security subscription revenue increased $225.7 million, or 35%, and technical support and other services revenue increased $142.9 million, or 26%, during the six months ended June 30, 2023 compared to the same period last year. Excluding Alaxala, technical support growth increased 27% during the six months ended June 30, 2023. The increases were primarily due to pricing actions in prior periods, strength in our SaaS offerings and the recognition of revenue from our growing deferred revenue balance related to FortiGuard and other security subscriptions as well as FortiCare technical support and other services. FortiGuard outpaced technical support growth due to expansion of our SaaS-based security subscription service offerings, while technical support growth was impacted by the lower service revenue of Alaxala.

[0001262039-23-000032:mdna:158]
Of the service revenue recognized during the six months ended June 30, 2023, 81% was included in the deferred revenue balance as of December 31, 2022. Of the service revenue recognized during the six months ended June 30, 2022, 80% was included in the deferred revenue balance as of December 31, 2021. We expect service revenue will continue to increase throughout the remainder of 2023, as our business is expected to grow, and as service revenue benefits from previous pricing actions. However, there are risks to service revenue growth rates, including customers reducing their spending, pricing actions, supply chain constraints, customers taking longer to buy their service and other risks.

[0001262039-23-000032:mdna:159]
37

[0001262039-23-000032:mdna:160]
Cost of revenue and gross margin

[0001262039-23-000032:mdna:161]
|  | Six Months Ended |  |  |  |  |
| June 30,2023 |  | June 30,2022 |  | Change |  | % Change |
| (in millions, except percentages) |
| Cost of revenue: |  |  |  |  |  |  |  |
| Product | $ | 368.1 |  |  | $ | 316.2 |  |  | $ | 51.9 |  |  | 16 | % |
| Service | 235.5 |  |  | 188.4 |  |  | 47.1 |  |  | 25 | % |
| Total cost of revenue | $ | 603.6 |  |  | $ | 504.6 |  |  | $ | 99.0 |  |  | 20 | % |
| Gross margin (%): |  |  |  |  |  |  |  |
| Product | 62.2 | % |  | 59.0 | % |  |  |  |  |
| Service | 85.1 |  |  | 84.5 |  |  |  |  |  |
| Total gross margin | 76.4 | % |  | 74.6 | % |  |  |  |  |

[0001262039-23-000032:mdna:162]
Total gross margin increased 1.8 percentage points during the six months ended June 30, 2023 compared to the same period last year, primarily driven by increased product and service gross margins and a shift in the revenue mix. As a percentage of total revenue, the revenue mix shifted 0.8 percentage points from product revenue to service revenue.

[0001262039-23-000032:mdna:163]
Product gross margin increased 3.2 percentage points during the six months ended June 30, 2023 compared to the same period last year. The product margin was primarily benefited from earlier pricing actions and lower expedite fees and freight costs, partially offset by higher inventory related reserve expense. Cost of product revenue was comprised primarily of third-party contract manufacturers’ costs and the costs of materials used in production.

[0001262039-23-000032:mdna:164]
Service gross margin increased 0.6 percentage points during the six months ended June 30, 2023 compared to the same period last year. Cost of service revenue was comprised primarily of personnel and data center costs. The increase in service gross margin was primarily driven by pricing actions in earlier periods and the favorable impact of foreign currency fluctuations, partially offset by increased labor cost and our increased cloud delivery costs as we continue to expand our cloud to SASE delivery models.

[0001262039-23-000032:mdna:165]
Operating expenses

[0001262039-23-000032:mdna:166]
|  | Six Months Ended |  | Change |  | % Change |
| June 30,2023 |  | June 30,2022 |  |
| Amount |  | % ofRevenue |  | Amount |  | % ofRevenue |  |
| (in millions, except percentages) |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | $ | 304.4 |  |  | 12 | % |  | $ | 249.2 |  |  | 13 | % |  | $ | 55.2 |  |  | 22 | % |
| Sales and marketing | 994.2 |  |  | 39 |  |  | 803.1 |  |  | 41 |  |  | 191.1 |  |  | 24 |  |
| General and administrative | 102.7 |  |  | 4 |  |  | 84.0 |  |  | 4 |  |  | 18.7 |  |  | 22 |  |
| Gain on IP matter | (2.3) |  |  | — |  |  | (2.3) |  |  | — |  |  | — |  |  | — |  |
| Total operating expenses | $ | 1,399.0 |  |  | 55 | % |  | $ | 1,134.0 |  |  | 57 | % |  | $ | 265.0 |  |  | 23 | % |
| Percentages have been rounded for presentation purposes and may differ from unrounded results. |

[0001262039-23-000032:mdna:167]
Research and development

[0001262039-23-000032:mdna:168]
Research and development expense increased $55.2 million, or 22%, during the six months ended June 30, 2023 compared to the same period last year, primarily due to an increase of $41.3 million in personnel-related costs as a result of increased headcount to support the development of new products and continued enhancements to our existing products. In addition, product development costs increased by $8.7 million and depreciation expense and other occupancy-related expense increased by $3.4 million, partially offset by the favorable impact of foreign currency fluctuations.

[0001262039-23-000032:mdna:169]
38

[0001262039-23-000032:mdna:170]
Sales and marketing

[0001262039-23-000032:mdna:171]
Sales and marketing expense increased $191.1 million, or 24%, during the six months ended June 30, 2023 compared to the same period last year, primarily due to an increase of $140.7 million in personnel-related costs. We significantly increased our sales and pipeline generation capacity, including newer non-tenured sales people. The increase in headcount is expected to help drive global market revenue increases. In addition, marketing-related expense increased by $21.1 million, travel expense increased by $14.8 million and depreciation expense and other occupancy-related expense increased by $10.2 million, partially offset by the favorable impact of foreign currency fluctuations.

[0001262039-23-000032:mdna:172]
General and administrative

[0001262039-23-000032:mdna:173]
General and administrative expense increased $18.7 million, or 22%, during the six months ended June 30, 2023 compared to the same period last year, primarily due to an increase of $9.7 million in personnel-related costs, an increase of $8.2 million in legal and other professional service fees, partially offset by a decrease of $1.2 million in provision for expected credit losses.

[0001262039-23-000032:mdna:174]
Operating income and margin

[0001262039-23-000032:mdna:175]
We generated operating income of $552.5 million during the six months ended June 30, 2023, an increase of $206.2 million, or 60%, compared to $346.3 million in the same period last year. Operating income as a percentage of revenue increased to 21.6% during the six months ended June 30, 2023 compared to 17.4% in the same period last year, due to the stronger gross margin performance. The increase in our operating margin was primarily due to 1.8 percentage points increase in gross margin, and 1.6 percentage points, 0.7 percentage points and 0.2 percentage points decreases in sales and marketing expense, research and development expense and general and administrative expense as percentage of revenue, respectively.

[0001262039-23-000032:mdna:176]
Interest income, interest expense and other expense—net

[0001262039-23-000032:mdna:177]
|  | Six Months Ended |  |  |  |  |
| June 30,2023 |  | June 30,2022 |  | Change |  | % Change |
| (in millions, except percentages) |
| Interest income | $ | 52.2 |  |  | $ | 3.7 |  |  | $ | 48.5 |  |  | 1,311 | % |
| Interest expense | $ | (10.2) |  |  | $ | (9.0) |  |  | $ | (1.2) |  |  | 13 | % |
| Other expense—net | $ | (4.2) |  |  | $ | (18.4) |  |  | $ | 14.2 |  |  | (77) | % |

[0001262039-23-000032:mdna:178]
Interest income increased $48.5 million during the six months ended June 30, 2023 compared to the same period last year, primarily as a result of higher interest rates and greater investment balances. Interest income varies depending on our average investment balances during the period, types and mix of investments, and market interest rates. Interest expense remained comparatively flat during the six months ended June 30, 2023 compared to the same period last year. Other expense—net decreased by $14.2 million during the six months ended June 30, 2023 compared to the same period last year, due to a $10.9 million recovery in the loss on marketable equity securities and a $3.0 million decrease of foreign currency exchange loss.

[0001262039-23-000032:mdna:179]
[same as prior period, unchanged from 0001262039-23-000021:mdna:144]

[0001262039-23-000032:mdna:180]
|  | Six Months Ended |  | Change |  | % Change |
| June 30,2023 |  | June 30,2022 |  |
| (in millions, except percentages) |
| Provision for (benefit from) income taxes | $ | 48.9 |  |  | $ | (5.7) |  |  | $ | 54.6 |  |  | (958) | % |
| Effective tax rate (%) | 8 | % |  | (2) | % |  |  |  |  |

[0001262039-23-000032:mdna:181]
Our effective tax rate was 8% for the six months ended June 30, 2023 compared to an effective tax rate of negative 2% for the same period last year. The provision for income taxes for the six months ended June 30, 2023 was primarily comprised of U.S. federal and state taxes, withholding taxes and foreign taxes that were $170.6 million. This provision for income taxes was favorably affected by a tax benefit of $64.0 million from the FDII deduction, excess tax benefits from stock-based compensation expense of $39.6 million, and the release of reserves of $18.1 million on uncertain tax positions and the accrued interest thereon due to the expiration of statutes of limitations.

[0001262039-23-000032:mdna:182]
39

[0001262039-23-000032:mdna:183]
The benefit from income taxes for the six months ended June 30, 2022 was comprised of U.S. federal and state taxes, withholding taxes, and foreign taxes that were $93.3 million, which were offset by a tax benefit of $33.3 million from the FDII deduction, excess tax benefits from stock-based compensation expense of $49.5 million, and the release of reserves of $16.2 million on uncertain tax positions and the accrued interest thereon due to the expiration of statutes of limitations.

[0001262039-23-000032:mdna:184]
Loss from Equity Method Investment

[0001262039-23-000032:mdna:185]
|  | Six Months Ended |  | Change |  | % Change |
| June 30,2023 |  | June 30,2022 |  |
| (in millions, except percentages) |
| Loss from equity method investment | $ | (27.4) |  |  | $ | (16.6) |  |  | $ | (10.8) |  |  | 65 | % |

[0001262039-23-000032:mdna:186]
Loss from equity method investment increased $10.8 million during the six months ended June 30, 2023 compared to the same period last year, due to the increase in our proportionate share of loss of Linksys’ financial results as well as our share of the amortization of the basis differences from prior quarter.

[0001262039-23-000032:mdna:187]
[same as prior period, unchanged from 0001262039-23-000021:mdna:151]

[0001262039-23-000032:mdna:188]
|  | As of |
|  | June 30,2023 |  | December 31,2022 |
|  | (in millions) |
| Cash and cash equivalents | $ | 2,376.3 |  |  | $ | 1,682.9 |  |
| Short-term and long-term investments | 919.3 |  |  | 548.1 |  |
| Marketable equity securities | 22.1 |  |  | 25.5 |  |
| Total cash, cash equivalents, investments and marketable equity securities | $ | 3,317.7 |  |  | $ | 2,256.5 |  |
| Working capital | $ | 1,377.5 |  |  | $ | 732.0 |  |
|  | Six Months Ended |
|  | June 30,2023 |  | June 30,2022 |
|  | (in millions) |
| Net cash provided by operating activities | $ | 1,192.6 |  |  | $ | 719.5 |  |
| Net cash provided by (used in) investing activities | (466.5) |  |  | 248.7 |  |
| Net cash used in financing activities | (31.4) |  |  | (1,576.3) |  |
| Effect of exchange rate changes on cash and cash equivalents | (1.3) |  |  | (1.0) |  |
| Net increase (decrease) in cash and cash equivalents | $ | 693.4 |  |  | $ | (609.1) |  |

[0001262039-23-000032:mdna:189]
Liquidity and capital resources are primarily impacted by our operating activities, as well as payment of taxes in connection with the net settlement of equity awards, real estate and other capital expenditures, proceeds from the issuance of common stock, cash used for stock repurchases and the timing of income tax payments. In accordance with disaster relief announced by the Internal Revenue Service, we have postponed U.S. federal tax payments from the second quarter of 2023 to the fourth quarter of 2023. We expect to postpone additional U.S. federal tax payments from the third quarter of 2023 to the fourth quarter of 2023, and we expect that our cash payments for income taxes to be significantly higher, in the range of $370.0 million to $380.0 million in the fourth quarter of 2023.

[0001262039-23-000032:mdna:190]
[same as prior period, unchanged from 0001262039-23-000021:mdna:154]

[0001262039-23-000032:mdna:191]
40

[0001262039-23-000032:mdna:192]
In February 2023, our board of directors approved an extension of the Repurchase Program to February 29, 2024. In April 2023, our board of directors approved a $1.0 billion increase in the authorized amount under the Repurchase Program, bringing the aggregate amount authorized to be repurchased to $6.25 billion of our outstanding common stock through February 29, 2024. There were no shares repurchased under the Repurchase Program during the six months ended June 30, 2023. In July 2023, our board of directors approved a $500.0 million increase in the authorized stock repurchase amount under the Repurchase Program, bringing the aggregate amount authorized for repurchase to $6.75 billion of our outstanding common stock through February 29, 2024. As of August 7, 2023, approximately $1.87 billion remained available for future share repurchases.

[0001262039-23-000032:mdna:193]
We expect to continue to increase our data centers, PoPs, office and warehouse capacity to support growth and the expansion of existing services or introduction of new services. As we purchase new properties, we will work to incorporate these properties into the environmental goals we have established. We estimate capital expenditures to be between approximately $225 million and $275 million in the second half of 2023.

[0001262039-23-000032:mdna:194]
We believe that our cash provided by operating activities, together with our existing cash, cash equivalents and investments will be sufficient to meet our anticipated cash needs and do not currently intend to retire our Senior Notes early. Refer to Note 10, Debt, in Part I, Item 1 of this Quarterly Report on Form 10-Q for information on the Senior Notes. As of June 30, 2023, the long-term debt, net of unamortized discount and debt issuance costs, was $991.3 million.

[0001262039-23-000032:mdna:195]
We enter into non-cancellable agreements with contract manufacturers and certain component suppliers to procure inventory based on our requirements in order to negotiate manufacturing lead times and encourage and incentivize vendors to deliver components and finished goods. In certain instances, these agreements allow us the option to reschedule and adjust our requirements based on our business needs prior to firm orders being placed. These purchase commitments as of June 30, 2023 totaled $1.01 billion, a decrease of $324.8 million compared to $1.34 billion as of December 31, 2022 due to fulfillment of customer demand as our supply availability improved and our continued efforts to work with contract manufacturers and suppliers to optimize our inventory and purchase commitment position. We increased our purchase commitments in prior years to address significant supply constraints seen industry-wide due to component shortages. Our agreements secured supply and pricing for certain product components commitments with contract manufacturers to meet customer demand and to address extended lead times. We also have open purchase orders and contractual obligations in the ordinary course of business for which we have not received goods or services. As of June 30, 2023, we had $84.6 million in other contractual commitments having a remaining term in excess of one year that are non-cancelable.

[0001262039-23-000032:mdna:196]
[same as prior period, unchanged from 0001262039-23-000021:mdna:161]

[0001262039-23-000032:mdna:197]
As of June 30, 2023, our cash, cash equivalents, short-term and long-term investments of $3.30 billion were invested primarily in deposit accounts, money market funds, corporate debt securities, commercial paper, certificates of deposit and term deposits, U.S. government and agency securities and municipal bonds. It is our investment policy to invest excess cash in a manner that preserves capital, provides liquidity and generates return without significantly increasing risk. We do not enter into investments for trading or speculative purposes.

[0001262039-23-000032:mdna:198]
The amount of cash, cash equivalents and investments held by our international subsidiaries was $208.0 million as of June 30, 2023 and $218.1 million as of December 31, 2022.

[0001262039-23-000032:mdna:199]
We believe that our existing cash and cash equivalents and cash flow from operations will be sufficient for at least the next 12 months to meet our requirements and plans for cash, including meeting our working capital requirements and capital expenditure requirements. In the long term, our ability to support our requirements and plans for cash, including our working capital and capital expenditure requirements will depend on many factors, including our growth rate; the timing and amount of our share repurchases; the expansion of sales and marketing activities, pricing actions, the introduction of new and enhanced products and services offerings; the continuing market acceptance of our products; the timing and extent of spending to support development efforts; our investments in purchasing, developing or leasing real estate; cash tax payments and macroeconomic impacts such as rising inflation and interest rates; the war in Ukraine; and instability in the global banking system. Historically, we have required capital principally to fund our working capital needs, share repurchases, capital expenditures and acquisition activities. In the event that additional financing is required from outside sources, we may not be able to raise it on terms acceptable to us or at all.

[0001262039-23-000032:mdna:200]
As of June 30, 2023, we did not have any relationships with unconsolidated organizations or financial partnerships, such as structured finance or special purpose entities that would have been established for the purpose of facilitating off-balance sheet arrangements or other contractually narrow or limited purposes.

[0001262039-23-000032:mdna:201]
41

[0001262039-23-000032:mdna:202]
[same as prior period, unchanged from 0001262039-23-000021:mdna:166]

[0001262039-23-000032:mdna:203]
Cash generated by operating activities is our primary source of liquidity. It is primarily comprised of net income, as adjusted for non-cash items and changes in operating assets and liabilities. Non-cash adjustments consist primarily of amortization of deferred contract costs, stock-based compensation and depreciation and amortization. Changes in operating assets and liabilities consist primarily of changes in deferred revenue, accounts receivable—net, deferred contract costs, income taxes payable, deferred tax assets and inventory.

[0001262039-23-000032:mdna:204]
Our operating activities during the six months ended June 30, 2023 provided cash flows of $1.19 billion, an increase of $473.1 million compared to the same period last year, as a result of the continued growth of our business, improved profitability and our ability to successfully manage our working capital. Changes in operating assets and liabilities primarily resulted from an increase in sales of our FortiGuard and other security subscription services and FortiCare technical support services to new and existing customers, as reflected by an increase of $489.3 million in our deferred revenue during the six months ended June 30, 2023. In addition, changes in operating assets and liabilities were driven by a decrease of $179.0 million in accounts receivable—net, an increase of $168.5 million in deferred contract costs, an increase of $161.8 million in deferred tax assets, an increase of $156.9 million in income taxes payable as we deferred our U.S. federal tax payments in the second quarter of 2023 following the disaster relief provided by the Internal Revenue Service and an increase of $130.2 million in inventory.

[0001262039-23-000032:mdna:205]
42

[0001262039-23-000032:mdna:206]
[same as prior period, unchanged from 0001262039-23-000021:mdna:169]

[0001262039-23-000032:mdna:207]
The changes in cash flows from investing activities primarily relate to timing of purchases, maturities and sales of investments and purchases of property and equipment. Historically, in making a lease-versus-ownership decision related to warehouse, office or data space, we have considered various factors including financial metrics, expected long-term growth rates, time to market and changes in asset values. In certain cases, we have elected to own a facility if we believe that purchasing or developing buildings rather than leasing is more closely aligned with our long-term strategy. We expect to make similar decisions in the future. We may also make cash payments in connection with future business combinations.

[0001262039-23-000032:mdna:208]
During the six months ended June 30, 2023, cash used in investing activities was $466.5 million, primarily driven by $359.5 million spent for purchases of investments, net of maturities and sales of investments and $107.1 million of purchases of property and equipment.

[0001262039-23-000032:mdna:209]
[same as prior period, unchanged from 0001262039-23-000021:mdna:173]

[0001262039-23-000032:mdna:210]
[same as prior period, unchanged from 0001262039-23-000021:mdna:174]

[0001262039-23-000032:mdna:211]
During the six months ended June 30, 2023, cash used in financing activities was $31.4 million, primarily driven by $30.4 million used to pay tax withholding, net of proceeds from the issuance of common stock.
