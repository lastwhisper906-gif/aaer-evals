# FTNT notes — 0001262039-23-000032


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001262039-23-000032:notes:1]
SUMMARY OF SIGNIFICANT ACCOUNTING POLICIES
Basis of Presentation and Preparation—The unaudited condensed consolidated financial statements of Fortinet, Inc. and its subsidiaries (collectively, “we,” “us” or “our”) have been prepared in accordance with generally accepted accounting principles in the United States (“GAAP”) for interim financial information, as well as the instructions to Form 10-Q pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (the “SEC”). Accordingly, they do not include all of the information and footnotes required by GAAP for complete financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the year ended December 31, 2022, contained in our Annual Report on Form 10-K filed with the SEC on February 24, 2023. In the opinion of management, all adjustments, which include normal recurring adjustments, considered necessary for a fair presentation, have been included. The results of operations for the three and six months ended June 30, 2023 are not necessarily indicative of the results to be expected for the full year or for any future periods. The condensed consolidated balance sheet as of December 31, 2022 is derived from the audited consolidated financial statements for the year ended December 31, 2022.

[0001262039-23-000032:notes:2]
Amounts related to income taxes payable have been reclassified in prior periods to conform with current period presentation.

[0001262039-23-000032:notes:3]
[same as prior period, unchanged from 0001262039-23-000021:notes:2]

[0001262039-23-000032:notes:4]
[same as prior period, unchanged from 0001262039-23-000021:notes:3]

[0001262039-23-000032:notes:5]
There have been no material changes to our significant accounting policies as of and for the three and six months ended June 30, 2023, as compared to the significant accounting policies described in the Form 10-K.

[0001262039-23-000032:notes:6]
Recently Adopted and Recently Issued Accounting Standards

[0001262039-23-000032:notes:7]
There were no recently adopted accounting standards which would have a material effect on our condensed consolidated financial statements and accompanying disclosures, and no recently issued accounting standards that are expected to have a material impact on our condensed consolidated financial statements and accompanying disclosures.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001262039-23-000032:notes:8]
[same as prior period, unchanged from 0001262039-23-000021:notes:8]

[0001262039-23-000032:notes:9]
[same as prior period, unchanged from 0001262039-23-000021:notes:9]

[0001262039-23-000032:notes:10]
|  | Three Months Ended |  | Six Months Ended |
|  | June 30,2023 |  | June 30,2022 |  | June 30,2023 |  | June 30,2022 |
| Product | $ | 472.6 |  |  | $ | 400.7 |  |  | $ | 973.3 |  |  | $ | 771.7 |  |
| Service: |  |  |  |  |  |  |  |
| Security subscription | 457.3 |  |  | 340.4 |  |  | 879.0 |  |  | 653.3 |  |
| Technical support and other | 362.9 |  |  | 289.0 |  |  | 702.8 |  |  | 559.9 |  |
| Total service revenue | 820.2 |  |  | 629.4 |  |  | 1,581.8 |  |  | 1,213.2 |  |
| Total revenue | $ | 1,292.8 |  |  | $ | 1,030.1 |  |  | $ | 2,555.1 |  |  | $ | 1,984.9 |  |

[0001262039-23-000032:notes:11]
[same as prior period, unchanged from 0001262039-23-000021:notes:11]

[0001262039-23-000032:notes:12]
During the three and six months ended June 30, 2023, we recognized $609.8 million and $1.29 billion in service revenue that was included in the deferred revenue balance as of December 31, 2022, respectively. During the three and six months ended June 30, 2022, we recognized $457.6 million and $964.9 million in service revenue that was included in the deferred revenue balance as of December 31, 2021, respectively.

[0001262039-23-000032:notes:13]
[same as prior period, unchanged from 0001262039-23-000021:notes:13]

[0001262039-23-000032:notes:14]
As of June 30, 2023, the aggregate amount of the transaction price allocated to remaining performance obligations was $5.15 billion, which was substantially comprised of deferred security subscription, technical support services revenue and unbilled contract revenue from non-cancellable contracts that will be recognized in future periods. We expect to recognize approximately $2.60 billion as revenue over the next 12 months and the remainder thereafter.

[0001262039-23-000032:notes:15]
[same as prior period, unchanged from 0001262039-23-000021:notes:15]

[0001262039-23-000032:notes:16]
[same as prior period, unchanged from 0001262039-23-000021:notes:16]

[0001262039-23-000032:notes:17]
The allowance for credit losses was $5.3 million and $3.6 million as of June 30, 2023 and December 31, 2022, respectively. Provisions, write-offs and recoveries were not material during the six months ended June 30, 2023 and 2022.

[0001262039-23-000032:notes:18]
[same as prior period, unchanged from 0001262039-23-000021:notes:18]

[0001262039-23-000032:notes:19]
Amortization of deferred contract costs during the three months ended June 30, 2023 and 2022 were $65.4 million and $54.6 million, respectively. Amortization of deferred contract costs during the six months ended June 30, 2023 and 2022 were $127.9 million and $107.1 million, respectively.


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0001262039-23-000032:notes:20]
[same as prior period, unchanged from 0001262039-23-000021:notes:20]

[0001262039-23-000032:notes:21]
[same as prior period, unchanged from 0001262039-23-000021:notes:21]

[0001262039-23-000032:notes:22]
|  | June 30, 2023 |
|  | AmortizedCost |  | UnrealizedGains |  | UnrealizedLosses |  | FairValue |
| U.S. government and agency securities | $ | 404.4 |  |  | $ | 0.1 |  |  | $ | (1.3) |  |  | $ | 403.2 |  |
| Commercial paper | 368.0 |  |  | — |  |  | (0.3) |  |  | 367.7 |  |
| Corporate debt securities | 109.5 |  |  | — |  |  | (1.3) |  |  | 108.2 |  |
| Certificates of deposit and term deposits | 35.2 |  |  | — |  |  | — |  |  | 35.2 |  |
| Municipal bonds | 5.0 |  |  | — |  |  | — |  |  | 5.0 |  |
| Total available-for-sale securities | $ | 922.1 |  |  | $ | 0.1 |  |  | $ | (2.9) |  |  | $ | 919.3 |  |

[0001262039-23-000032:notes:23]
|  | December 31, 2022 |
|  | AmortizedCost |  | UnrealizedGains |  | UnrealizedLosses |  | FairValue |
| U.S. government and agency securities | $ | 198.0 |  |  | $ | — |  |  | $ | (4.4) |  |  | $ | 193.6 |  |
| Commercial paper | 26.5 |  |  | — |  |  | (0.1) |  |  | 26.4 |  |
| Corporate debt securities | 293.0 |  |  | — |  |  | (4.1) |  |  | 288.9 |  |
| Certificates of deposit and term deposits | 34.2 |  |  | — |  |  | — |  |  | 34.2 |  |
| Municipal bonds | 5.1 |  |  | — |  |  | (0.1) |  |  | 5.0 |  |
| Total available-for-sale securities | $ | 556.8 |  |  | $ | — |  |  | $ | (8.7) |  |  | $ | 548.1 |  |

[0001262039-23-000032:notes:24]
[same as prior period, unchanged from 0001262039-23-000021:notes:24]

[0001262039-23-000032:notes:25]
|  | June 30, 2023 |
|  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
|  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |
| U.S. government and agency securities | $ | 125.9 |  |  | $ | (0.1) |  |  | $ | 83.8 |  |  | $ | (1.2) |  |  | $ | 209.7 |  |  | $ | (1.3) |  |
| Commercial paper | 349.6 |  |  | (0.3) |  |  | — |  |  | — |  |  | 349.6 |  |  | (0.3) |  |
| Corporate debt securities | 12.7 |  |  | (0.1) |  |  | 83.1 |  |  | (1.2) |  |  | 95.8 |  |  | (1.3) |  |
| Total available-for-sale securities | $ | 488.2 |  |  | $ | (0.5) |  |  | $ | 166.9 |  |  | $ | (2.4) |  |  | $ | 655.1 |  |  | $ | (2.9) |  |

[0001262039-23-000032:notes:26]
|  | December 31, 2022 |
|  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
|  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |
| U.S. government and agency securities | $ | 3.9 |  |  | $ | (0.1) |  |  | $ | 189.8 |  |  | $ | (4.3) |  |  | $ | 193.7 |  |  | $ | (4.4) |  |
| Commercial paper | 26.4 |  |  | (0.1) |  |  | — |  |  | — |  |  | 26.4 |  |  | (0.1) |  |
| Corporate debt securities | 90.5 |  |  | (0.8) |  |  | 190.0 |  |  | (3.3) |  |  | 280.5 |  |  | (4.1) |  |
| Municipal bonds | 5.0 |  |  | (0.1) |  |  | — |  |  | — |  |  | 5.0 |  |  | (0.1) |  |
| Total available-for-sale securities | $ | 125.8 |  |  | $ | (1.1) |  |  | $ | 379.8 |  |  | $ | (7.6) |  |  | $ | 505.6 |  |  | $ | (8.7) |  |

[0001262039-23-000032:notes:27]
[same as prior period, unchanged from 0001262039-23-000021:notes:27]

[0001262039-23-000032:notes:28]
|  | June 30,2023 |  | December 31,2022 |
| Due within one year | $ | 915.1 |  |  | $ | 502.6 |  |
| Due within one to three years | 4.2 |  |  | 45.5 |  |
| Total | $ | 919.3 |  |  | $ | 548.1 |  |

[0001262039-23-000032:notes:29]
[same as prior period, unchanged from 0001262039-23-000021:notes:29]

[0001262039-23-000032:notes:30]
[same as prior period, unchanged from 0001262039-23-000021:notes:30]

[0001262039-23-000032:notes:31]
[same as prior period, unchanged from 0001262039-23-000021:notes:31]

[0001262039-23-000032:notes:32]
Our marketable equity securities were $22.1 million and $25.5 million as of June 30, 2023 and December 31, 2022. The changes in fair value of our marketable equity securities are recorded in other expense—net on the condensed consolidated statements of income. We recognized a $4.0 million and $3.4 million loss during the three and six months ended June 30, 2023, respectively. We recognized a $8.1 million and $14.3 million loss during the three and six months ended June 30, 2022, respectively.

[0001262039-23-000032:notes:33]
[same as prior period, unchanged from 0001262039-23-000021:notes:33]

[0001262039-23-000032:notes:34]
[same as prior period, unchanged from 0001262039-23-000021:notes:34]

[0001262039-23-000032:notes:35]
[same as prior period, unchanged from 0001262039-23-000021:notes:35]

[0001262039-23-000032:notes:36]
[same as prior period, unchanged from 0001262039-23-000021:notes:36]

[0001262039-23-000032:notes:37]
[same as prior period, unchanged from 0001262039-23-000021:notes:37]

[0001262039-23-000032:notes:38]
[same as prior period, unchanged from 0001262039-23-000021:notes:38]

[0001262039-23-000032:notes:39]
[same as prior period, unchanged from 0001262039-23-000021:notes:39]

[0001262039-23-000032:notes:40]
[same as prior period, unchanged from 0001262039-23-000021:notes:40]

[0001262039-23-000032:notes:41]
[same as prior period, unchanged from 0001262039-23-000021:notes:41]

[0001262039-23-000032:notes:42]
[same as prior period, unchanged from 0001262039-23-000021:notes:42]

[0001262039-23-000032:notes:43]
|  | June 30, 2023 |  | December 31, 2022 |
|  | AggregateFairValue |  | QuotedPrices inActiveMarkets ForIdenticalAssets |  | SignificantOtherObservableRemainingInputs |  | SignificantOtherUnobservableRemainingInputs |  | AggregateFairValue |  | QuotedPrices inActiveMarkets ForIdenticalAssets |  | SignificantOtherObservableRemainingInputs |  | SignificantOtherUnobservableRemainingInputs |
|  |  |  | (Level 1) |  | (Level 2) |  | (Level 3) |  |  |  | (Level 1) |  | (Level 2) |  | (Level 3) |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. government and agency securities | $ | 490.8 |  |  | $ | 415.9 |  |  | $ | 74.9 |  |  | $ | — |  |  | $ | 268.6 |  |  | $ | 259.3 |  |  | $ | 9.3 |  |  | $ | — |  |
| Commercial paper | 490.8 |  |  | — |  |  | 490.8 |  |  | — |  |  | 115.8 |  |  | — |  |  | 115.8 |  |  | — |  |
| Corporate debt securities | 108.2 |  |  | — |  |  | 108.2 |  |  | — |  |  | 288.9 |  |  | — |  |  | 288.9 |  |  | — |  |
| Certificates of deposit and term deposits | 61.6 |  |  | — |  |  | 61.6 |  |  | — |  |  | 50.4 |  |  | — |  |  | 50.4 |  |  | — |  |
| Money market funds | 241.4 |  |  | 241.4 |  |  | — |  |  | — |  |  | 593.9 |  |  | 593.9 |  |  | — |  |  | — |  |
| Municipal bonds | 5.0 |  |  | — |  |  | 5.0 |  |  | — |  |  | 5.0 |  |  | — |  |  | 5.0 |  |  | — |  |
| Marketable equity securities | 22.1 |  |  | 22.1 |  |  | — |  |  | — |  |  | 25.5 |  |  | 25.5 |  |  | — |  |  | — |  |
| Total | $ | 1,419.9 |  |  | $ | 679.4 |  |  | $ | 740.5 |  |  | $ | — |  |  | $ | 1,348.1 |  |  | $ | 878.7 |  |  | $ | 469.4 |  |  | $ | — |  |
| Reported as: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents | $ | 478.5 |  |  |  |  |  |  |  |  | $ | 774.5 |  |  |  |  |  |  |  |
| Marketable equity securities | 22.1 |  |  |  |  |  |  |  |  | 25.5 |  |  |  |  |  |  |  |
| Short-term investments | 915.1 |  |  |  |  |  |  |  |  | 502.6 |  |  |  |  |  |  |  |
| Long-term investments | 4.2 |  |  |  |  |  |  |  |  | 45.5 |  |  |  |  |  |  |  |
| Total | $ | 1,419.9 |  |  |  |  |  |  |  |  | $ | 1,348.1 |  |  |  |  |  |  |  |

[0001262039-23-000032:notes:44]
There were no transfers between Level 1 and Level 2 of the fair value hierarchy during the six months ended June 30, 2023 and year ended December 31, 2022.


## us-gaap:InventoryDisclosureTextBlock

[0001262039-23-000032:notes:45]
[same as prior period, unchanged from 0001262039-23-000021:notes:45]

[0001262039-23-000032:notes:46]
|  | June 30,2023 |  | December 31,2022 |
| Raw materials | $ | 74.3 |  |  | $ | 46.3 |  |
| Work in process | 10.2 |  |  | 12.0 |  |
| Finished goods | 291.8 |  |  | 206.3 |  |
| Inventory | $ | 376.3 |  |  | $ | 264.6 |  |


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001262039-23-000032:notes:47]
[same as prior period, unchanged from 0001262039-23-000021:notes:47]

[0001262039-23-000032:notes:48]
|  | June 30,2023 |  | December 31,2022 |
| Land | $ | 330.1 |  |  | $ | 310.0 |  |
| Buildings and improvements | 553.9 |  |  | 490.3 |  |
| Computer equipment and software | 237.8 |  |  | 222.7 |  |
| Leasehold improvements | 55.6 |  |  | 53.5 |  |
| Evaluation units | 25.7 |  |  | 19.2 |  |
| Furniture and fixtures | 32.5 |  |  | 31.3 |  |
| Construction-in-progress | 64.7 |  |  | 51.7 |  |
| Total property and equipment | 1,300.3 |  |  | 1,178.7 |  |
| Less: accumulated depreciation | (318.4) |  |  | (280.2) |  |
| Property and equipment—net | $ | 981.9 |  |  | $ | 898.5 |  |

[0001262039-23-000032:notes:49]
For the three months ended June 30, 2023, we purchased certain real estate in Spain and the United States totaling $51.9 million (“the Aggregate Purchase Price”). The purchases were accounted for under the asset acquisition method. The cost of the assets acquired was allocated to land and buildings and improvements based on their relative fair values. Of the Aggregate Purchase Price, $6.5 million was allocated to land and $45.4 million was allocated to buildings and improvements.

[0001262039-23-000032:notes:50]
Depreciation expense was $22.9 million and $19.1 million during the three months ended June 30, 2023 and 2022, respectively. Depreciation expense was $45.7 million and $38.2 million during the six months ended June 30, 2023 and 2022, respectively.


## us-gaap:InvestmentTextBlock

[0001262039-23-000032:notes:51]
[same as prior period, unchanged from 0001262039-23-000021:notes:50]

[0001262039-23-000032:notes:52]
[same as prior period, unchanged from 0001262039-23-000021:notes:51]

[0001262039-23-000032:notes:53]
We have concluded that our investment in Linksys is an in-substance common stock investment and that we do not hold an absolute controlling financial interest in Linksys, but that we have the ability to exercise significant influence over the operating and financial policies of Linksys. Determining that we have significant influence but not control over the operating and financial policies of Linksys required significant judgement of many factors, including but not limited to the ownership interest in Linksys, board representation, participation in policy-making processes and participation rights in certain significant financial and operating decisions of Linksys in the ordinary course of business. Therefore, we determined to account for this investment using the equity method of accounting. We record our share of Linksys’ financial results on a three-month lag basis. We determined that there was a basis difference between the cost of our investment in Linksys and the amount of underlying equity in net assets of Linksys. Our share of loss of Linksys’ financial results, as well as our share of the amortization of the basis differences, in total was $5.3 million and $8.1 million for the three months ended June 30, 2023 and 2022, respectively, and has been recorded in loss from equity method investment on the condensed consolidated statements of income. Our share of loss of Linksys’ financial results, as well as our share of the amortization of the basis differences, in total was $27.4 million and $16.6 million for the six months ended June 30, 2023 and 2022, respectively, and has been recorded in loss from equity method investment on the condensed consolidated statements of income. As of June 30, 2023 and December 31, 2022, the investment was included in other assets on our condensed consolidated balance sheets.

[0001262039-23-000032:notes:54]
In the fourth quarter of 2022, we recorded a non-cash charge of $22.2 million related to other-than-temporary impairment (“OTTI”) recognized on our equity method investment in Linksys and our proportionate share of Linksys' financial results included a $17.5 million charge in connection with a valuation allowance established on deferred tax assets at Linksys. Due to the presence of impairment indicators, such as a series of operating losses, we evaluated our equity method investment 
for an OTTI during the three months ended June 30, 2023. We considered various factors in determining whether an OTTI has occurred, including the limited operating history available, our ability and intent to hold the investment until its fair value recovers, the implied revenue valuation multiples compared to guideline public companies, Linksys’ ability to achieve milestones and any notable operational and strategic changes. After the evaluation, we determined that an additional OTTI has not occurred as of June 30, 2023. However, we may be required to recognize an impairment loss in future reporting periods if and when our evaluation of the aforementioned factors indicates that the investment in Linksys is determined to be other than temporarily impaired. Such determination will be based on the prevailing facts and circumstances at that time, including the results and disclosures of Linksys.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001262039-23-000032:notes:55]
[same as prior period, unchanged from 0001262039-23-000021:notes:53]


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001262039-23-000032:notes:56]
[same as prior period, unchanged from 0001262039-23-000021:notes:54]

[0001262039-23-000032:notes:57]
[same as prior period, unchanged from 0001262039-23-000021:notes:55]

[0001262039-23-000032:notes:58]
|  | Amount |
| Balance—December 31, 2022 | $ | 128.0 |  |
| Foreign currency translation adjustments | (2.0) |  |
| Balance—June 30, 2023 | $ | 126.0 |  |

[0001262039-23-000032:notes:59]
There were no impairments to goodwill during the six months ended June 30, 2023 or during prior periods.

[0001262039-23-000032:notes:60]
[same as prior period, unchanged from 0001262039-23-000021:notes:58]

[0001262039-23-000032:notes:61]
[same as prior period, unchanged from 0001262039-23-000021:notes:59]

[0001262039-23-000032:notes:62]
|  | June 30, 2023 |
|  | Weighted-Average Useful Life (in Years) |  | Gross |  | Accumulated Amortization |  | Net |
| Other intangible assets—net: |  |  |  |  |  |  |  |
| Finite-lived intangible assets: |  |  |  |  |  |  |  |
| Developed technologies | 4.3 |  | $ | 83.0 |  |  | $ | 56.5 |  |  | $ | 26.5 |  |
| Customer relationships | 7.1 |  | 30.2 |  |  | 16.0 |  |  | 14.2 |  |
| Trade name | 10.0 |  | 4.8 |  |  | 0.9 |  |  | 3.9 |  |
| Backlog | 1.0 |  | 3.8 |  |  | 3.8 |  |  | — |  |
| Total other intangible assets—net |  |  | $ | 121.8 |  |  | $ | 77.2 |  |  | $ | 44.6 |  |

[0001262039-23-000032:notes:63]
[same as prior period, unchanged from 0001262039-23-000021:notes:61]

[0001262039-23-000032:notes:64]
Amortization expense was $4.5 million and $6.0 million during the three months ended June 30, 2023 and 2022, respectively. Amortization expense was $9.2 million and $12.4 million during the six months ended June 30, 2023 and 2022, respectively.

[0001262039-23-000032:notes:65]
[same as prior period, unchanged from 0001262039-23-000021:notes:63]

[0001262039-23-000032:notes:66]
|  | Amount |
| Years: |  |
| 2023 (the remainder of 2023) | $ | 8.5 |  |
| 2024 | 12.8 |  |
| 2025 | 8.3 |  |
| 2026 | 4.2 |  |
| 2027 | 3.9 |  |
| Thereafter | 6.9 |  |
| Total | $ | 44.6 |  |


## us-gaap:EarningsPerShareTextBlock

[0001262039-23-000032:notes:67]
NET INCOME PER SHAREBasic net income per share is computed by dividing net income attributable to Fortinet, Inc., by the weighted-average number of shares of common stock outstanding during the period. Diluted net income per share is computed by dividing net income attributable to Fortinet, Inc. by the weighted-average number of shares of common stock outstanding during the period, plus the dilutive effects of restricted stock units (“RSUs”), stock options and performance stock units (“PSUs”). Dilutive shares of common stock are determined by applying the treasury stock method.
A reconciliation of the numerator and denominator used in the calculation of basic and diluted net income per share attributable to Fortinet, Inc. is (in millions, except per share amounts):

[0001262039-23-000032:notes:68]
|  | Three Months Ended |  | Six Months Ended |
|  | June 30,2023 |  | June 30,2022 |  | June 30,2023 |  | June 30,2022 |
| Numerator: |  |  |  |  |  |  |  |
| Net income including non-controlling interests | $ | 266.3 |  |  | $ | 173.4 |  |  | $ | 514.0 |  |  | $ | 311.7 |  |
| Net loss attributable to non-controlling interests | — |  |  | (0.1) |  |  | — |  |  | (0.2) |  |
| Net income attributable to Fortinet, Inc. | $ | 266.3 |  |  | $ | 173.5 |  |  | $ | 514.0 |  |  | $ | 311.9 |  |
| Denominator: |  |  |  |  |  |  |  |
| Basic shares: |  |  |  |  |  |  |  |
| Weighted-average common stock outstanding-basic | 785.0 |  |  | 795.4 |  |  | 784.1 |  |  | 799.4 |  |
| Diluted shares: |  |  |  |  |  |  |  |
| Weighted-average common stock outstanding-basic | 785.0 |  |  | 795.4 |  |  | 784.1 |  |  | 799.4 |  |
| Effect of potentially dilutive securities: |  |  |  |  |  |  |  |
| RSUs | 4.1 |  |  | 6.4 |  |  | 3.9 |  |  | 7.5 |  |
| Stock options | 6.6 |  |  | 8.3 |  |  | 6.6 |  |  | 8.5 |  |
| PSUs | 0.2 |  |  | — |  |  | 0.1 |  |  | — |  |
| Weighted-average shares used to compute diluted net income per share attributable to Fortinet, Inc. | 795.9 |  |  | 810.1 |  |  | 794.7 |  |  | 815.4 |  |
| Net income per share attributable to Fortinet, Inc.: |  |  |  |  |  |  |  |
| Basic | $ | 0.34 |  |  | $ | 0.22 |  |  | $ | 0.66 |  |  | $ | 0.39 |  |
| Diluted | $ | 0.33 |  |  | $ | 0.21 |  |  | $ | 0.65 |  |  | $ | 0.38 |  |

[0001262039-23-000032:notes:69]
[same as prior period, unchanged from 0001262039-23-000021:notes:68]

[0001262039-23-000032:notes:70]
|  | Three Months Ended |  | Six Months Ended |
|  | June 30,2023 |  | June 30,2022 |  | June 30,2023 |  | June 30,2022 |
| RSUs | — |  |  | 0.4 |  |  | 0.9 |  |  | 0.4 |  |
| Stock options | 3.0 |  |  | 1.6 |  |  | 2.6 |  |  | 1.2 |  |
| Total | 3.0 |  |  | 2.0 |  |  | 3.5 |  |  | 1.6 |  |


## us-gaap:DebtDisclosureTextBlock

[0001262039-23-000032:notes:71]
DEBT
2026 and 2031 Senior Notes

[0001262039-23-000032:notes:72]
On March 5, 2021, we issued $1.0 billion aggregate principal amount of senior notes (collectively, the “Senior Notes”), consisting of $500.0 million aggregate principal amount of 1.0% notes due March 15, 2026 (the “2026 Senior Notes”) and $500.0 million aggregate principal amount of 2.2% notes due March 15, 2031 (the “2031 Senior Notes”), in an underwritten registered public offering. The Senior Notes are senior unsecured obligations and rank equally with each other in right of payment and with our other outstanding obligations. We may redeem the Senior Notes at any time in whole or in part for cash, at specified redemption prices that include accrued and unpaid interest, if any, and a make-whole premium. However, no make-whole premium will be paid for redemptions of the 2026 Senior Notes on or after February 15, 2026, or the 2031 Senior Notes on or after December 15, 2030. Interest on the Senior Notes is payable on March 15 and September 15 of each year, beginning on September 15, 2021. As of June 30, 2023 and December 31, 2022, the Senior Notes were recorded as long-term debt, net of discount and issuance costs, which are amortized to interest expense over the respective contractual terms of these notes using the effective interest method.

[0001262039-23-000032:notes:73]
The total outstanding debt is summarized below (in millions, except percentages):

[0001262039-23-000032:notes:74]
|  | Maturity |  | Coupon Rate |  | Effective Interest Rate |  | June 30,2023 |  | December 31,2022 |
| Debt |  |  |  |  |  |  |  |  |  |
| 2026 Senior Notes | March 2026 |  | 1.0% |  | 1.3% |  | $ | 500.0 |  |  | $ | 500.0 |  |
| 2031 Senior Notes | March 2031 |  | 2.2% |  | 2.3% |  | 500.0 |  |  | 500.0 |  |
| Total debt |  |  |  |  |  |  | 1,000.0 |  |  | 1,000.0 |  |
| Less: Unamortized discount and debt issuance costs |  |  |  |  |  |  | 8.7 |  |  | 9.6 |  |
| Total long-term debt |  |  |  |  |  |  | $ | 991.3 |  |  | $ | 990.4 |  |

[0001262039-23-000032:notes:75]
As of June 30, 2023 and December 31, 2022, we accrued interest payable of $4.7 million, and there are no financial covenants with which we must comply. During the three months ended June 30, 2023 and 2022, we recorded $4.5 million of total interest expense in relation to these Senior Notes in each quarter. During the six months ended June 30, 2023 and 2022, we recorded $9.0 million of total interest expense in relation to the Senior Notes in each period. No interest costs were capitalized for the six months ended June 30, 2023 and 2022, as the costs that qualified for capitalization were not material.

[0001262039-23-000032:notes:76]
The total estimated fair value of the outstanding Senior Notes was approximately $856.3 million, including accrued and unpaid interest, as of June 30, 2023. The fair value was determined based on observable market prices of identical instruments in less active markets. The estimated fair values are based on Level 2 inputs.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001262039-23-000032:notes:77]
COMMITMENTS AND CONTINGENCIES
The following table summarizes our inventory purchase commitments as of June 30, 2023 (in millions):

[0001262039-23-000032:notes:78]
|  | Total |  | 2023 |  | Thereafter |
| Inventory purchase commitments | $ | 1,010.2 |  |  | $ | 813.2 |  |  | $ | 197.0 |  |

[0001262039-23-000032:notes:79]
Inventory Purchase Commitments—Our independent contract manufacturers and certain component suppliers procure components and build our products based on our forecasts, the availability of various components and their capacity. These forecasts are based on estimates of future demand for our products, which are in turn based on historical trends and an analysis from our sales and marketing organizations, adjusted for extended lead times, changes in supplier delivery commitments and other supply chain matters and market conditions. In order to manage manufacturing lead times, plan for adequate component supply and incentivize suppliers to deliver, we may issue purchase orders to some of our independent contract manufacturers, which are non-cancelable. As of June 30, 2023, we had $1.01 billion of open purchase orders with our independent contract manufacturers that consist of non-cancelable commitments. In certain instances, these agreements allow us the option to reschedule and adjust our requirements based on our business needs prior to firm orders being placed.

[0001262039-23-000032:notes:80]
Other Contractual Commitments and Open Purchase Orders—In addition to commitments with contract manufacturers, we have open purchase orders and contractual obligations in the ordinary course of business for which we have not received goods or services. A significant portion of our reported purchase commitments consist of non-cancelable commitments. In certain instances, contractual commitments allow us the option to cancel, reschedule and adjust our requirements based on our business needs prior to firm orders being placed. As of June 30, 2023, we had $84.6 million in other contractual commitments having a remaining term in excess of one year that are non-cancelable.

[0001262039-23-000032:notes:81]
As of June 30, 2023, we had $93.9 million in contractual commitments related to payments for operating leases.

[0001262039-23-000032:notes:82]
Litigation—We are involved in disputes, litigation, and other legal actions. For lawsuits where we are the defendant, we are in the process of defending these litigation matters, and while there can be no assurances and the outcome of certain of these matters is currently not determinable and not predictable, we currently are unaware of any existing claims or proceedings that we believe are likely to have a material adverse effect on our financial position. There are many uncertainties associated with any litigation and these actions or other third-party claims against us may cause us to incur costly litigation fees, costs and substantial settlement charges, and possibly subject us to damages and other penalties. In addition, the resolution of any intellectual property (“IP”) litigation may require us to make royalty payments, which could adversely affect our gross margins in future periods. If any of those events were to occur, our business, financial condition, results of operations, and cash flows could be adversely affected. Litigation is unpredictable and the actual liability in any such matters may be materially different from our current estimates, which could result in the need to adjust any accrued liability and record additional expenses. We accrue for contingencies when we believe that a loss is probable and that we can reasonably estimate the amount of any such loss. These accruals are generally based on a range of possible outcomes that require significant management judgement. If no amount within a range is a better estimate than any other, we accrue the minimum amount. Litigation loss contingency accruals associated with outstanding cases were not material as of June 30, 2023, and December 31, 2022.

[0001262039-23-000032:notes:83]
On March 21, 2019, we were sued by Alorica Inc. (“Alorica”) in Santa Clara County Superior Court in California. Alorica has alleged breach of warranty and misrepresentation claims, which we deny. We have counter-claimed and are seeking monetary damages. Fact discovery closed during the quarter ended June 30, 2023, and the trial is scheduled to commence in October 2023. Although we believe that the ultimate outcome of this matter will not materially impact our financial position, results of operations or cash flows, legal proceedings are subject to inherent uncertainties, and an unfavorable ruling could occur, which may result in a material adverse impact on our business, financial position, results of operations and cash flows. No loss accrual had been recorded as of June 30, 2023 or December 31, 2022 related to this litigation.

[0001262039-23-000032:notes:84]
Indemnification and Other Matters—Under the indemnification provisions of our standard sales contracts, we agree to defend our customers against third-party claims asserting various allegations such as product defects and infringement of certain IP rights, which may include patents, copyrights, trademarks or trade secrets, and to pay judgments entered on such claims. In some contracts, our exposure under these indemnification provisions is limited by the terms of the contracts to certain defined limits, such as the total amount paid by our customer under the agreement. However, certain agreements include covenants, penalties and indemnification provisions including and beyond indemnification for third-party claims of IP infringement that could potentially expose us to losses in excess of the amount received under the agreement, and in some instances to potential liability that is not contractually limited. Although from time to time there are indemnification claims asserted against us and currently there are pending indemnification claims, to date there have been no material awards under such indemnification provisions.

[0001262039-23-000032:notes:85]
Similar to other security companies and companies in other industries, we have experienced and may experience in the future, cybersecurity threats, malicious activity directed against our information technology infrastructure or unauthorized attempts to gain access to our and our customers’ sensitive information and systems. We currently are unaware of any existing claims or proceedings related to these types of matters, including any that we believe are likely to have a material adverse effect on our financial position.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001262039-23-000032:notes:86]
[same as prior period, unchanged from 0001262039-23-000021:notes:84]

[0001262039-23-000032:notes:87]
We maintain the Amended and Restated Fortinet, Inc. 2009 Equity Incentive Plan (the “Amended Plan”) pursuant to which we have granted RSUs, stock options and PSUs. As of June 30, 2023, there were a total of 53.0 million shares of common stock available for grant under the Amended Plan.

[0001262039-23-000032:notes:88]
[same as prior period, unchanged from 0001262039-23-000021:notes:86]

[0001262039-23-000032:notes:89]
[same as prior period, unchanged from 0001262039-23-000021:notes:87]

[0001262039-23-000032:notes:90]
|  | Restricted Stock Units Outstanding |
|  | Number of Shares |  | Weighted-Average Grant Date Fair Value per Share |
| Balance—December 31, 2022 | 10.5 |  |  | $ | 40.94 |  |
| Granted | 4.1 |  |  | 61.17 |  |
| Forfeited | (0.2) |  |  | 45.47 |  |
| Vested | (3.1) |  |  | 34.47 |  |
| Balance—June 30, 2023 | 11.3 |  |  | $ | 49.97 |  |

[0001262039-23-000032:notes:91]
Stock compensation expense is recognized on a straight-line basis over the vesting period of each RSU. As of June 30, 2023, total compensation expense related to unvested RSUs granted to employees and non-employees under the Amended Plan, but not yet recognized, was $509.9 million, with a weighted-average remaining vesting period of 2.9 years.

[0001262039-23-000032:notes:92]
[same as prior period, unchanged from 0001262039-23-000021:notes:90]

[0001262039-23-000032:notes:93]
[same as prior period, unchanged from 0001262039-23-000021:notes:91]

[0001262039-23-000032:notes:94]
|  | Three Months Ended |  | Six Months Ended |
|  | June 30,2023 |  | June 30,2022 |  | June 30,2023 |  | June 30,2022 |
| Shares withheld for taxes | 0.4 |  |  | 0.6 |  |  | 1.1 |  |  | 1.7 |  |
| Amount withheld for taxes | $ | 25.1 |  |  | $ | 35.3 |  |  | $ | 59.7 |  |  | $ | 100.1 |  |

[0001262039-23-000032:notes:95]
[same as prior period, unchanged from 0001262039-23-000021:notes:93]

[0001262039-23-000032:notes:96]
[same as prior period, unchanged from 0001262039-23-000021:notes:94]

[0001262039-23-000032:notes:97]
|  | Three Months Ended |  | Six Months Ended |
|  | June 30,2023 |  | June 30,2022 |  | June 30,2023 |  | June 30,2022 |
| Expected term in years | 4.4 |  | 4.4 |  | 4.4 |  | 4.4 |
| Volatility | 41.0 | % |  | 43.6 | % |  | 41.9 | % |  | 41.1 | % |
| Risk-free interest rate | 3.8 | % |  | 2.9 | % |  | 4.2 | % |  | 1.9 | % |
| Dividend rate | — | % |  | — | % |  | — | % |  | — | % |

[0001262039-23-000032:notes:98]
[same as prior period, unchanged from 0001262039-23-000021:notes:96]

[0001262039-23-000032:notes:99]
|  | Options Outstanding |
|  | Numberof Shares |  | Weighted-AverageExercisePrice |  | Weighted-AverageRemainingContractualLife (Years) |  | AggregateIntrinsicValue |
| Balance—December 31, 2022 | 13.2 |  |  | $ | 24.37 |  |  | 3.5 |  | $ | 344.8 |  |
| Granted | 1.2 |  |  | 60.80 |  |  |  |  |  |
| Forfeited | (0.1) |  |  | 44.99 |  |  |  |  |  |
| Exercised | (2.1) |  |  | 14.13 |  |  |  |  |  |
| Balance—June 30, 2023 | 12.2 |  |  | $ | 29.64 |  |  |  |  |  |
| Options vested and expected to vest—June 30, 2023 | 12.2 |  |  | $ | 29.64 |  |  | 3.6 |  | $ | 559.8 |  |
| Options exercisable—June 30, 2023 | 8.2 |  |  | $ | 20.26 |  |  | 2.8 |  | $ | 456.3 |  |

[0001262039-23-000032:notes:100]
The aggregate intrinsic value represents the difference between the exercise price of stock options and the quoted market price of our common stock for all in-the-money stock options. Stock compensation expense is recognized on a straight-line basis over the vesting period of each stock option. As of June 30, 2023, total compensation expense related to unvested stock options granted to employees but not yet recognized was $68.0 million, with a weighted-average remaining vesting period of 2.8 years.

[0001262039-23-000032:notes:101]
[same as prior period, unchanged from 0001262039-23-000021:notes:99]

[0001262039-23-000032:notes:102]
|  | Three Months Ended |  | Six Months Ended |
|  | June 30,2023 |  | June 30,2022 |  | June 30,2023 |  | June 30,2022 |
| Weighted-average fair value per share granted | $ | 26.55 |  |  | $ | 21.33 |  |  | $ | 24.41 |  |  | $ | 22.28 |  |
| Intrinsic value of options exercised | $ | 24.3 |  |  | $ | 13.8 |  |  | $ | 97.0 |  |  | $ | 43.7 |  |
| Fair value of options vested | $ | 5.7 |  |  | $ | 4.8 |  |  | $ | 17.4 |  |  | $ | 15.0 |  |

[0001262039-23-000032:notes:103]
[same as prior period, unchanged from 0001262039-23-000021:notes:101]

[0001262039-23-000032:notes:104]
[same as prior period, unchanged from 0001262039-23-000021:notes:102]

[0001262039-23-000032:notes:105]
[same as prior period, unchanged from 0001262039-23-000021:notes:103]

[0001262039-23-000032:notes:106]
|  | Three Months Ended |  |  |
|  | March 31,2023 |  |  |
| Expected term in years | 2.7 |  |  |
| Volatility | 47.5 | % |  |  |
| Risk-free interest rate | 4.6 | % |  |  |
| Dividend rate | — | % |  |  |

[0001262039-23-000032:notes:107]
We granted approximately 0.3 million shares of PSU awards with a grant date fair value of $90.96 per share to certain of our executives during the first quarter of 2023. The grant date fair value of these awards was determined using a Monte Carlo simulation pricing model. None of these PSU awards were vested or forfeited during the six months ended June 30, 2023.

[0001262039-23-000032:notes:108]
As of June 30, 2023, total compensation expense related to unvested PSUs that were granted to certain of our executives, but not yet recognized, was $23.2 million. This expense is expected to be amortized on a graded vesting method over a weighted-average vesting period of 2.6 years.

[0001262039-23-000032:notes:109]
[same as prior period, unchanged from 0001262039-23-000021:notes:108]

[0001262039-23-000032:notes:110]
[same as prior period, unchanged from 0001262039-23-000021:notes:109]

[0001262039-23-000032:notes:111]
|  | Three Months Ended |  | Six Months Ended |
|  | June 30,2023 |  | June 30,2022 |  | June 30,2023 |  | June 30,2022 |
| Cost of product revenue | $ | 0.5 |  |  | $ | 0.4 |  |  | $ | 0.9 |  |  | $ | 0.8 |  |
| Cost of service revenue | 6.0 |  |  | 4.7 |  |  | 11.1 |  |  | 9.2 |  |
| Research and development | 20.0 |  |  | 16.1 |  |  | 37.0 |  |  | 31.2 |  |
| Sales and marketing | 29.3 |  |  | 26.4 |  |  | 55.6 |  |  | 53.1 |  |
| General and administrative | 9.9 |  |  | 7.7 |  |  | 18.1 |  |  | 14.9 |  |
| Total stock-based compensation expense | $ | 65.7 |  |  | $ | 55.3 |  |  | $ | 122.7 |  |  | $ | 109.2 |  |

[0001262039-23-000032:notes:112]
[same as prior period, unchanged from 0001262039-23-000021:notes:111]

[0001262039-23-000032:notes:113]
|  | Three Months Ended |  | Six Months Ended |
|  | June 30,2023 |  | June 30,2022 |  | June 30,2023 |  | June 30,2022 |
| RSUs | $ | 55.1 |  |  | $ | 49.0 |  |  | $ | 104.2 |  |  | $ | 97.3 |  |
| Stock options | 7.3 |  |  | 6.3 |  |  | 14.0 |  |  | 11.9 |  |
| PSUs | 3.3 |  |  | — |  |  | 4.5 |  |  | — |  |
| Total stock-based compensation expense | $ | 65.7 |  |  | $ | 55.3 |  |  | $ | 122.7 |  |  | $ | 109.2 |  |

[0001262039-23-000032:notes:114]
[same as prior period, unchanged from 0001262039-23-000021:notes:113]

[0001262039-23-000032:notes:115]
|  | Three Months Ended |  | Six Months Ended |
|  | June 30,2023 |  | June 30,2022 |  | June 30,2023 |  | June 30,2022 |
| Income tax benefit associated with stock-based compensation | $ | 14.5 |  |  | $ | 12.2 |  |  | $ | 27.1 |  |  | $ | 24.0 |  |

[0001262039-23-000032:notes:116]
[same as prior period, unchanged from 0001262039-23-000021:notes:115]

[0001262039-23-000032:notes:117]
In February 2023, our board of directors approved an extension of the Repurchase Program originally approved by our board of directors in January 2016 to February 29, 2024. In April 2023, our board of directors approved a $1.0 billion increase in the authorized amount under the Repurchase Program, bringing the aggregate amount authorized to be repurchased to $6.25 billion of our outstanding common stock through February 29, 2024. Share repurchases may be made by us from time to time in privately negotiated transactions or in open-market transactions. The Repurchase Program does not require us to purchase a minimum number of shares, and may be suspended, modified or discontinued at any time without prior notice. Refer to Note 16, Subsequent Events, for information regarding the approved $500.0 million increase in the authorized stock repurchase amount under the Repurchase Program in July 2023.

[0001262039-23-000032:notes:118]
There were no shares repurchased under the Repurchase Program during the six months ended June 30, 2023. As of June 30, 2023, $1.53 billion remained available for future share repurchases under the Repurchase Program.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001262039-23-000032:notes:119]
INCOME TAXES
Our effective tax rate was 9% for the three months ended June 30, 2023, compared to an effective tax rate of 1% for the same period last year. Our effective tax rate was 8% for the six months ended June 30, 2023, compared to an effective tax rate of negative 2% for the same period last year. The tax rates for the three months ended June 30, 2023 and 2022 were composed of U.S. federal and state taxes, withholding taxes and foreign taxes that amounted to $84.8 million and $54.5 million, respectively. The tax rate for the three months ended June 30, 2023 was impacted by a tax benefit of $25.8 million from the FDII deduction, excess tax benefits from stock-based compensation expense of $13.3 million, and the release of reserves of $18.1 million on uncertain tax positions and the accrued interest thereon due to the expiration of statutes of limitations. The tax rate for the three months ended June 30, 2022 was impacted by a tax benefit of $18.6 million from the FDII deduction, excess tax benefits from stock-based compensation expense of $17.3 million, and the release of reserves of $16.2 million on uncertain tax positions and the accrued interest thereon due to the expiration of statutes of limitations.

[0001262039-23-000032:notes:120]
The tax rates for the six months ended June 30, 2023 and 2022 were composed of U.S. federal and state taxes, withholding taxes and foreign taxes that amounted to $170.6 million and $93.3 million, respectively. The tax rate for the six months ended June 30, 2023 was impacted by a tax benefit of $64.0 million from the FDII deduction, excess tax benefits from stock-based compensation expense of $39.6 million, and the release of reserves of $18.1 million on uncertain tax positions and the accrued interest thereon due to the expiration of statutes of limitations. The tax rate for the six months ended June 30, 2022 was impacted by a tax benefit of $33.3 million from the FDII deduction, excess tax benefits from stock-based compensation expense of $49.5 million, and the release of reserves of $16.2 million on uncertain tax positions and the accrued interest thereon due to the expiration of statutes of limitations.

[0001262039-23-000032:notes:121]
As of June 30, 2023 and December 31, 2022, unrecognized tax benefits were $63.4 million and $67.4 million, respectively. If recognized, $53.8 million of the unrecognized tax benefits as of June 30, 2023 would favorably affect our effective tax rate. It is our policy to include accrued interest and penalties related to unrecognized tax benefits in income tax expense. As of June 30, 2023 and December 31, 2022, accrued interest and penalties were $5.3 million and $9.3 million, respectively. It is reasonably possible that our gross unrecognized tax benefits will decrease by up to $1.9 million in the next 12 months, due to the lapse of statutes of limitation in various jurisdictions. This decrease, if recognized, would favorably impact our effective tax rate, and would be recognized as an additional tax benefit.

[0001262039-23-000032:notes:122]
[same as prior period, unchanged from 0001262039-23-000021:notes:120]

[0001262039-23-000032:notes:123]
Effective January 1, 2022, research and development expenses are required to be capitalized and amortized for U.S. tax purposes, which delays the deductibility of these expenses, and increases our current provision.

[0001262039-23-000032:notes:124]
[same as prior period, unchanged from 0001262039-23-000021:notes:121]

[0001262039-23-000032:notes:125]
On August 16, 2022, the United States enacted the Inflation Reduction Act of 2022 that provides for certain changes to the U.S. corporate income tax system, including a 15% minimum tax based on financial statement income for companies with three-year average annual adjusted financial statement income exceeding $1 billion, and a 1% excise tax on net repurchases of stock after December 31, 2022, if any. The applicable tax law changes have had no impact to our tax provision for the six months ended June 30, 2023. We will continue to monitor the impact, if any, of these tax law changes on future periods.


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0001262039-23-000032:notes:126]
DEFINED CONTRIBUTION PLANSOur tax-deferred savings plan under our 401(k) Plan permits participating U.S. employees to contribute a portion of their pre-tax or after-tax earnings. In Canada, we have a Group Registered Retirement Savings Plan Program (the “RRSP”), which permits participants to make pre-tax contributions. Our board of directors approved 50% matching contributions on employee contributions up to 4% of each employee’s eligible earnings. Our matching contributions to our 401(k) Plan and the RRSP for the three months ended June 30, 2023 and 2022 were $5.7 million and $3.2 million, respectively. Our matching contributions to our 401(k) Plan and the RRSP for the six months ended June 30, 2023 and 2022 were $10.1 million and $6.6 million, respectively.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001262039-23-000032:notes:127]
SEGMENT INFORMATION
Operating segments are defined as components of an enterprise about which separate financial information is available that is evaluated regularly by the chief operating decision maker in deciding how to allocate resources and in assessing performance. Our chief operating decision maker is our chief executive officer. Our chief executive officer reviews financial information presented on a consolidated basis, accompanied by information about revenue by geographic region for purposes of allocating resources and evaluating financial performance. We have one business activity, and there are no segment managers who are held accountable for operations, operating results and plans for levels or components below the consolidated unit level. Accordingly, we have determined that we have one operating segment, and therefore, one reportable segment.

[0001262039-23-000032:notes:128]
Revenue by geographic region is based on the billing address of our customers. The following tables set forth revenue and property and equipment—net by geographic region (in millions):

[0001262039-23-000032:notes:129]
|  | Three Months Ended |  | Six Months Ended |
| Revenue | June 30,2023 |  | June 30,2022 |  | June 30,2023 |  | June 30,2022 |
| Americas: |  |  |  |  |  |  |  |
| United States | $ | 404.7 |  |  | $ | 312.9 |  |  | $ | 788.8 |  |  | $ | 598.7 |  |
| Other Americas | 132.3 |  |  | 100.7 |  |  | 271.7 |  |  | 197.5 |  |
| Total Americas | 537.0 |  |  | 413.6 |  |  | 1,060.5 |  |  | 796.2 |  |
| Europe, Middle East and Africa (“EMEA”) | 506.9 |  |  | 391.8 |  |  | 985.1 |  |  | 737.8 |  |
| Asia Pacific (“APAC”) | 248.9 |  |  | 224.7 |  |  | 509.5 |  |  | 450.9 |  |
| Total revenue | $ | 1,292.8 |  |  | $ | 1,030.1 |  |  | $ | 2,555.1 |  |  | $ | 1,984.9 |  |

[0001262039-23-000032:notes:130]
| Property and Equipment—net | June 30,2023 |  | December 31,2022 |
| Americas: |  |  |  |
| United States | $ | 686.5 |  |  | $ | 638.1 |  |
| Canada | 208.3 |  |  | 204.4 |  |
| Latin America | 0.8 |  |  | 1.1 |  |
| Total Americas | 895.6 |  |  | 843.6 |  |
| EMEA | 69.4 |  |  | 35.9 |  |
| APAC | 16.9 |  |  | 19.0 |  |
| Total property and equipment—net | $ | 981.9 |  |  | $ | 898.5 |  |

[0001262039-23-000032:notes:131]
[same as prior period, unchanged from 0001262039-23-000021:notes:127]

[0001262039-23-000032:notes:132]
|  | Three Months Ended |  | Six Months Ended |
|  | June 30,2023 |  | June 30,2022 |  | June 30,2023 |  | June 30,2022 |
| Distributor A | 27 | % |  | 29 | % |  | 28 | % |  | 29 | % |
| Distributor B | 15 | % |  | 14 | % |  | 14 | % |  | 14 | % |
| Distributor C | 14 | % |  | 13 | % |  | 14 | % |  | 14 | % |

[0001262039-23-000032:notes:133]
[same as prior period, unchanged from 0001262039-23-000021:notes:129]

[0001262039-23-000032:notes:134]
|  | June 30,2023 |  | December 31,2022 |
| Distributor A | 29 | % |  | 32 | % |
| Distributor B | 12 | % |  | 12 | % |
| Distributor C | 13 | % |  | 13 | % |


## us-gaap:SubsequentEventsTextBlock

[0001262039-23-000032:notes:135]
SUBSEQUENT EVENTS
Investment in Privately Held Company

[0001262039-23-000032:notes:136]
On August 1, 2023, we invested $8.5 million in cash in a privately held company.

[0001262039-23-000032:notes:137]
In July 2023, our board of directors approved a $500.0 million increase in the authorized stock repurchase amount under the Repurchase Program, bringing the aggregate amount authorized to be repurchased to $6.75 billion of our outstanding common stock through February 29, 2024. As of August 7, 2023, approximately $1.87 billion remained available for future share repurchases. Subsequent to June 30, 2023 through the filing of this Quarterly Report on Form 10-Q, we repurchased approximately 2.8 million shares of our common stock at an average price of $57.44 per share for an aggregate purchase price of approximately $161.1 million under the Repurchase Program.


## ecd:MtrlTermsOfTrdArrTextBlock

[0001262039-23-000032:notes:138]
Rule 10b5-1 Trading Plans

[0001262039-23-000032:notes:139]
On June 9, 2023, William Neukom, one of our directors, entered into a pre-arranged written stock purchase plan in accordance with Rule 10b5-1 (the “Rule 10b5-1 Plan”) under the Exchange Act for the purchase of shares of our common stock.

[0001262039-23-000032:notes:140]
The Rule 10b5-1 Plan was entered into during an open trading window in accordance with our insider trading policy and is intended to satisfy the affirmative defense of Rule 10b5-1(c) under the Exchange Act. Mr. Neukom’s Rule 10b5-1 Plan provides for the potential purchase of up to $35,000 worth of shares per purchase period of our common stock at its market price on six specific dates as specified in the Rule 10b5-1 Plan between September 8, 2023 and December 7, 2024.

[0001262039-23-000032:notes:141]
The Rule 10b5-1 Plan includes a representation from Mr. Neukom to the broker administering the plan that he was not in possession of any material nonpublic information regarding us or the securities subject to the Rule 10b5-1 Plan at the time the Rule 10b5-1 Plan was entered into. A similar representation was made to us in connection with the adoption of the Rule 10b5-1 Plan under our insider trading policy. Those representations were made as of the date of adoption of the Rule 10b5-1 Plan, and speak only as of that date. In making those representations, there is no assurance with respect to any material nonpublic information of which Mr. Neukom was unaware, or with respect to any material nonpublic information acquired by Mr. Neukom or us after the date of the representation.

[0001262039-23-000032:notes:142]
Once executed, transactions under the Rule 10b5-1 Plan will be disclosed publicly through Form 4 and/or Form 144 filings with the SEC in accordance with applicable securities laws, rules, and regulations. Except as may be required by law, we do not undertake any obligation to update or report any modification, termination, or other activity under current or future Rule 10b5-1 plans that may be adopted by Mr. Neukom or our other officers or directors.
