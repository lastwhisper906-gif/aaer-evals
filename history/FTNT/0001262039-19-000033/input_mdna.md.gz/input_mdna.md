# FTNT MD&A — 0001262039-19-000033


## mdna

[0001262039-19-000033:mdna:1]
[same as prior period, unchanged from 0001262039-19-000023:mdna:1]

[0001262039-19-000033:mdna:2]
[same as prior period, unchanged from 0001262039-19-000023:mdna:2]

[0001262039-19-000033:mdna:3]
[same as prior period, unchanged from 0001262039-19-000023:mdna:3]

[0001262039-19-000033:mdna:4]
[same as prior period, unchanged from 0001262039-19-000023:mdna:4]

[0001262039-19-000033:mdna:5]
[same as prior period, unchanged from 0001262039-19-000023:mdna:5]

[0001262039-19-000033:mdna:6]
[same as prior period, unchanged from 0001262039-19-000023:mdna:6]

[0001262039-19-000033:mdna:7]
[same as prior period, unchanged from 0001262039-19-000023:mdna:7]

[0001262039-19-000033:mdna:8]
[same as prior period, unchanged from 0001262039-19-000023:mdna:8]

[0001262039-19-000033:mdna:9]
[same as prior period, unchanged from 0001262039-19-000023:mdna:9]

[0001262039-19-000033:mdna:10]
[same as prior period, unchanged from 0001262039-19-000023:mdna:10]

[0001262039-19-000033:mdna:11]
[same as prior period, unchanged from 0001262039-19-000023:mdna:11]

[0001262039-19-000033:mdna:12]
[same as prior period, unchanged from 0001262039-19-000023:mdna:12]

[0001262039-19-000033:mdna:13]
[same as prior period, unchanged from 0001262039-19-000023:mdna:13]

[0001262039-19-000033:mdna:14]
[same as prior period, unchanged from 0001262039-19-000023:mdna:14]

[0001262039-19-000033:mdna:15]
[same as prior period, unchanged from 0001262039-19-000023:mdna:15]

[0001262039-19-000033:mdna:16]
[same as prior period, unchanged from 0001262039-19-000023:mdna:16]

[0001262039-19-000033:mdna:17]
[same as prior period, unchanged from 0001262039-19-000023:mdna:17]

[0001262039-19-000033:mdna:18]
[same as prior period, unchanged from 0001262039-19-000023:mdna:18]

[0001262039-19-000033:mdna:19]
[same as prior period, unchanged from 0001262039-19-000023:mdna:19]

[0001262039-19-000033:mdna:20]
[same as prior period, unchanged from 0001262039-19-000023:mdna:20]

[0001262039-19-000033:mdna:21]
[same as prior period, unchanged from 0001262039-19-000023:mdna:21]

[0001262039-19-000033:mdna:22]
[same as prior period, unchanged from 0001262039-19-000023:mdna:22]

[0001262039-19-000033:mdna:23]
| • | statements regarding expected outcomes and liabilities in litigation; |

[0001262039-19-000033:mdna:24]
[same as prior period, unchanged from 0001262039-19-000023:mdna:24]

[0001262039-19-000033:mdna:25]
[same as prior period, unchanged from 0001262039-19-000023:mdna:25]

[0001262039-19-000033:mdna:26]
[same as prior period, unchanged from 0001262039-19-000023:mdna:26]

[0001262039-19-000033:mdna:27]
[same as prior period, unchanged from 0001262039-19-000023:mdna:27]

[0001262039-19-000033:mdna:28]
Fortinet is a global leader in cybersecurity solutions provided to a wide variety of organizations, such as enterprises, communication service providers, government organizations and small businesses. Our cybersecurity solutions are designed to provide broad visibility and segmentation of the digital attack surface through our integrated Security Fabric platform, which features automated protection, detection and responses.

[0001262039-19-000033:mdna:29]
[same as prior period, unchanged from 0001262039-19-000023:mdna:29]

[0001262039-19-000033:mdna:30]
| • | Network Security—We derive a majority of product sales from our FortiGate network security appliances. Our FortiGate network security appliances include a broad set of built-in security and networking features and functionalities, including firewall, next generation firewall, secure web gateway, software-defined wide-area network (“SD-WAN”), intrusion prevention, secure sockets layer data leak prevention, virtual private network, switch and wireless controller and wide area network edge. Our network security appliances are managed by our FortiOS network operating system, which provides the foundation for FortiGate security functions. We enhance the performance of our network security appliances from branch to data center by designing and implementing Security Processing Unit (“SPU”) technology within our appliances. |

[0001262039-19-000033:mdna:31]
| • | Infrastructure Security—The Fortinet Security Fabric platform extends beyond the network to cover other attack vectors. Other infrastructure solutions covered include Secure Access (WiFi and switch) and software or hardware versions of Endpoint and Application Security, including email and web security. |

[0001262039-19-000033:mdna:32]
| • | Cloud Security—We help customers connect securely to and across their hybrid, public and private cloud environments by offering security through our virtual firewall and other software products in public and private cloud environments. Our cloud security solutions, including virtual appliances and hosted solutions, extend the core capabilities of the Fortinet Security Fabric platform to provide businesses with the same level of cybersecurity and threat intelligence in and across cloud environments that they receive on their physical networks. Fortinet cloud security offerings are available across all major cloud providers, including Amazon Web Services, Microsoft Azure, Google Cloud, IBM Cloud, Oracle Cloud and Alibaba Cloud. |

[0001262039-19-000033:mdna:33]
| • | Internet of Things and Operational Technology—The proliferation of Internet of Things (“IoT”) and the digitization of Operational Technology (“OT”) devices has generated new opportunities for us to grow our business. We offer network access control solutions that provide visibility, control and automated event responses in order to secure IoT devices. |

[0001262039-19-000033:mdna:34]
[same as prior period, unchanged from 0001262039-19-000023:mdna:33]

[0001262039-19-000033:mdna:35]
| • | Security Subscription and Support Services—Our customers, channel partners and end users may also purchase FortiGuard and other security subscription services to receive threat intelligence updates; FortiCare technical support services across all of our products; Technical Account Managers, Resident Engineers and professional service consultants for implementations or training services. |

[0001262039-19-000033:mdna:36]
[same as prior period, unchanged from 0001262039-19-000023:mdna:36]

[0001262039-19-000033:mdna:37]
| • | We recorded total revenue of $547.5 million and $1.54 billion during the three and nine months ended September 30, 2019, an increase of 21% and 19%, respectively, compared to $453.9 million and $1.29 billion in the same periods last year. Product revenue was $197.1 million and $549.7 million during the three and nine months ended September 30, 2019, an increase of 20% and 16%, respectively, compared to $164.5 million and $473.6 million in the same periods last year. Service revenue was $350.4 million and $992.1 million during the three and nine months ended September 30, 2019, an increase of 21% in both periods compared to $289.4 million and $820.6 million in the same periods last year. |

[0001262039-19-000033:mdna:38]
| • | We generated operating income of $100.0 million and $225.8 million during the three and nine months ended September 30, 2019, an increase of 59% and 55%, respectively, compared to $62.8 million and $145.9 million in the same periods last year. |

[0001262039-19-000033:mdna:39]
| • | Cash, cash equivalents and investments were $2.14 billion as of September 30, 2019, an increase of $427.9 million, or 25%, from December 31, 2018. |

[0001262039-19-000033:mdna:40]
| • | Deferred revenue was $1.95 billion as of September 30, 2019, an increase of $258.8 million, or 15%, from December 31, 2018. |

[0001262039-19-000033:mdna:41]
| • | We generated cash flows from operating activities of $617.6 million during the nine months ended September 30, 2019, an increase of $158.9 million, or 35%, compared to the same period last year. |

[0001262039-19-000033:mdna:42]
| • | During the nine months ended September 30, 2019, we repurchased 1.6 million shares of common stock under our Share Repurchase Program (the “Repurchase Program”), for an aggregate purchase price of $117.4 million. |

[0001262039-19-000033:mdna:43]
During the three and nine months ended September 30, 2019, our revenue growth was driven by both product and service revenue. On a geographic basis, revenue continues to be diversified globally, which remains a key strength of our business. Product revenue grew 20% and 16% during the three and nine months ended September 30, 2019, respectively, compared to the same periods last year. We experienced revenue growth across several of our hardware and software products, including SD-WAN solutions. Service revenue growth of 21% during the three and nine months ended September 30, 2019 compared to the same periods last year was driven by the strength of our FortiGuard and other security subscription revenue, which grew 23% and 24% in both periods, respectively, compared to the same periods last year. During the three and nine months ended September 30, 2019, FortiCare technical support and other service revenue grew 19% and 18%, respectively, compared to the same periods last year.

[0001262039-19-000033:mdna:44]
During the second quarter of 2019, we reclassified the 100 series of our FortiGate product from an entry-level product to a mid-range product. Prior periods have been reclassified to conform with current period presentation. Including this reclassification, we saw a mix shift to entry-level and mid-range products during the three and nine months ended September 30, 2019.

[0001262039-19-000033:mdna:45]
During the three and nine months ended September 30, 2019, operating expenses as a percentage of revenue decreased by three percentage points and two percentage points, respectively, compared to the same periods last year. The deferral of sales commissions for service contracts had a minimal impact to the changes in operating expenses as a percentage of revenue compared to the same periods last year. Headcount increased by 5% and 13% to 6,590 employees and contractors as of September 30, 2019, from 6,293 as of June 30, 2019 and from 5,845 as of December 31, 2018, respectively.

[0001262039-19-000033:mdna:46]
[same as prior period, unchanged from 0001262039-19-000023:mdna:46]

[0001262039-19-000033:mdna:47]
Our sales strategy is based on a two-tier distribution model. We sell to distributors that sell to networking security and enterprise-focused resellers and service providers, who in turn sell to our end-customers. In certain cases, we sell directly to large service providers and major systems integrators. We also offer our products across major cloud providers, and have recognized on-demand revenue from Amazon Web Services, Microsoft Azure, IBM Cloud, Google Cloud and Oracle Cloud. We have also recognized revenue from customers who deploy our products in a bring your own license (“BYOL”) arrangement at a cloud provider such as Amazon Web Services, Microsoft Azure, Google Cloud, Oracle Cloud and Alibaba Cloud. In a BYOL arrangement, a customer purchases a software license from us through our channel partners and deploys the software in a cloud provider’s environment. Similarly, customers may purchase such a license from us and deploy in their private cloud.

[0001262039-19-000033:mdna:48]
[same as prior period, unchanged from 0001262039-19-000023:mdna:48]

[0001262039-19-000033:mdna:49]
[same as prior period, unchanged from 0001262039-19-000023:mdna:49]

[0001262039-19-000033:mdna:50]
[same as prior period, unchanged from 0001262039-19-000023:mdna:50]

[0001262039-19-000033:mdna:51]
|  | Three Months Ended Or As Of |
|  | September 30, 2019 |  | September 30, 2018 |
|  | (in millions) |
| Revenue | $ | 547.5 |  |  | $ | 453.9 |  |
| Deferred revenue | $ | 1,945.6 |  |  | $ | 1,544.4 |  |
| Billings (non-GAAP) | $ | 626.6 |  |  | $ | 527.5 |  |
| Net cash provided by operating activities | $ | 221.2 |  |  | $ | 176.7 |  |
| Free cash flow (non-GAAP) | $ | 203.7 |  |  | $ | 158.5 |  |

[0001262039-19-000033:mdna:52]
Deferred revenue. Our deferred revenue consists of amounts that have been invoiced but that have not yet been recognized as revenue. The majority of our deferred revenue balance consists of the unrecognized portion of service revenue from FortiGuard security subscription and FortiCare technical support service contracts, which is recognized as revenue ratably over the contractual service period. We monitor our deferred revenue balance, deferred revenue growth and the mix of short-term and long-term deferred revenue because deferred revenue represents a significant portion of free cash flow and of revenue to be recognized in future periods. Deferred revenue was $1.95 billion as of September 30, 2019, an increase of $258.8 million, or 15%, from December 31, 2018.

[0001262039-19-000033:mdna:53]
Billings (non-GAAP). We define billings as revenue recognized in accordance with GAAP plus the change in deferred revenue from the beginning to the end of the period and adjustments to the deferred revenue balance due to adoption of the new revenue recognition standard less any deferred revenue balances acquired from business combination(s) during the period. We consider billings to be a useful metric for management and investors because billings drive current and future revenue, which is an important indicator of the health and viability of our business. There are a number of limitations related to the use of billings instead of GAAP revenue. First, billings include amounts that have not yet been recognized as revenue and are impacted by the security and support contractual service period agreements. Second, we may calculate billings in a manner that is different from peer companies that report similar financial measures. Management accounts for these limitations by providing specific information regarding GAAP revenue and evaluating billings together with GAAP revenue. Total billings were $626.6 million for the three months ended September 30, 2019, an increase of 19% compared to $527.5 million in the same period last year.

[0001262039-19-000033:mdna:54]
[same as prior period, unchanged from 0001262039-19-000023:mdna:54]

[0001262039-19-000033:mdna:55]
|  | Three Months Ended |
|  | September 30, 2019 |  | September 30, 2018 |
|  | (in millions) |
| Billings: |  |  |  |
| Revenue | $ | 547.5 |  |  | $ | 453.9 |  |
| Add: Change in deferred revenue | 79.1 |  |  | 73.6 |  |
| Total billings (non-GAAP) | $ | 626.6 |  |  | $ | 527.5 |  |

[0001262039-19-000033:mdna:56]
[same as prior period, unchanged from 0001262039-19-000023:mdna:56]

[0001262039-19-000033:mdna:57]
[same as prior period, unchanged from 0001262039-19-000023:mdna:57]

[0001262039-19-000033:mdna:58]
|  | Three Months Ended |
|  | September 30, 2019 |  | September 30, 2018 |
|  | (in millions) |
| Free Cash Flow: |  |  |  |
| Net cash provided by operating activities | $ | 221.2 |  |  | $ | 176.7 |  |
| Less: Purchases of property and equipment | (17.5 | ) |  | (18.2 | ) |
| Free cash flow (non-GAAP) | $ | 203.7 |  |  | $ | 158.5 |  |
| Net cash provided by (used in) investing activities | $ | (27.1 | ) |  | $ | 11.1 |  |
| Net cash provided by (used in) financing activities | $ | (40.7 | ) |  | $ | 9.4 |  |

[0001262039-19-000033:mdna:59]
[same as prior period, unchanged from 0001262039-19-000023:mdna:59]

[0001262039-19-000033:mdna:60]
[same as prior period, unchanged from 0001262039-19-000023:mdna:60]

[0001262039-19-000033:mdna:61]
There were no material changes to our critical accounting policies and estimates as of and for the three and nine months ended September 30, 2019, as compared to the critical accounting policies and estimates described in our Annual Report on Form 10-K filed with the SEC on February 27, 2019 (the “Form 10-K”).

[0001262039-19-000033:mdna:62]
[same as prior period, unchanged from 0001262039-19-000023:mdna:62]

[0001262039-19-000033:mdna:63]
[same as prior period, unchanged from 0001262039-19-000023:mdna:63]

[0001262039-19-000033:mdna:64]
[same as prior period, unchanged from 0001262039-19-000023:mdna:64]

[0001262039-19-000033:mdna:65]
Three Months Ended September 30, 2019 and September 30, 2018

[0001262039-19-000033:mdna:66]
[same as prior period, unchanged from 0001262039-19-000023:mdna:66]

[0001262039-19-000033:mdna:67]
|  | Three Months Ended |  |  |  |  |
| September 30, 2019 |  | September 30, 2018 |  |  |  |  |
| Amount |  | % ofRevenue |  | Amount |  | % ofRevenue |  | Change |  | % Change |
| (in millions, except percentages) |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 197.1 |  |  | 36 | % |  | $ | 164.5 |  |  | 36 | % |  | $ | 32.6 |  |  | 20 | % |
| Service | 350.4 |  |  | 64 |  |  | 289.4 |  |  | 64 |  |  | 61.0 |  |  | 21 |  |
| Total revenue | $ | 547.5 |  |  | 100 | % |  | $ | 453.9 |  |  | 100 | % |  | $ | 93.6 |  |  | 21 | % |
| Revenue by geography: |  |  |  |  |  |  |  |  |  |  |  |
| Americas | $ | 240.7 |  |  | 44 | % |  | $ | 194.0 |  |  | 43 | % |  | $ | 46.7 |  |  | 24 | % |
| Europe, Middle East and Africa (“EMEA”) | 200.7 |  |  | 37 |  |  | 165.4 |  |  | 36 |  |  | 35.3 |  |  | 21 |  |
| Asia Pacific (“APAC”) | 106.1 |  |  | 19 |  |  | 94.5 |  |  | 21 |  |  | 11.6 |  |  | 12 |  |
| Total revenue | $ | 547.5 |  |  | 100 | % |  | $ | 453.9 |  |  | 100 | % |  | $ | 93.6 |  |  | 21 | % |

[0001262039-19-000033:mdna:68]
Total revenue increased by $93.6 million, or 21%, during the three months ended September 30, 2019 compared to the same period last year. We continued to experience diversification of revenue globally, across both customer and industry segments. Revenue from all regions grew, with the Americas contributing the largest portion of our revenue growth on an absolute dollar basis.

[0001262039-19-000033:mdna:69]
Product revenue increased by $32.6 million, or 20%, during the three months ended September 30, 2019 compared to the same period last year. We experienced revenue growth across many of our hardware and software products due to an increase in FortiGates sold as part of SD-WAN solutions and growth in sales of our Infrastructure Security solutions, including software, Secure Access, and other hardware products.

[0001262039-19-000033:mdna:70]
Service revenue increased by $61.0 million, or 21%, during the three months ended September 30, 2019 compared to the same period last year. FortiGuard security subscription and FortiCare technical support and other revenues increased by $35.8 million, or 23%, and by $25.2 million, or 19%, respectively, during the three months ended September 30, 2019 compared to the same period last year. The increases were primarily due to the recognition of revenue from our growing deferred revenue balance related to FortiGuard and other security subscriptions and FortiCare technical support and other contracts. Of the service revenue recognized during the three months ended September 30, 2019, 93% was included in the deferred revenue balance as of June 30, 2019.

[0001262039-19-000033:mdna:71]
[same as prior period, unchanged from 0001262039-19-000023:mdna:71]

[0001262039-19-000033:mdna:72]
|  | Three Months Ended |  |  |  |  |
| September 30, 2019 |  | September 30, 2018 |  | Change |  | % Change |
| (in millions, except percentages) |
| Cost of revenue: |  |  |  |  |  |  |  |
| Product | $ | 79.0 |  |  | $ | 72.0 |  |  | $ | 7.0 |  |  | 10 | % |
| Service | 45.1 |  |  | 39.6 |  |  | 5.5 |  |  | 14 |  |
| Total cost of revenue | $ | 124.1 |  |  | $ | 111.6 |  |  | $ | 12.5 |  |  | 11 | % |
| Gross margin (%): |  |  |  |  |  |  |  |
| Product | 59.9 | % |  | 56.2 | % |  |  |  |  |
| Service | 87.1 |  |  | 86.3 |  |  |  |  |  |
| Total gross margin | 77.3 | % |  | 75.4 | % |  |  |  |  |

[0001262039-19-000033:mdna:73]
Total gross margin increased by 1.9 percentage points during the three months ended September 30, 2019 compared to the same period last year, driven by improvements to both product and service gross margins.

[0001262039-19-000033:mdna:74]
Product gross margin increased by 3.7 percentage points during the three months ended September 30, 2019 compared to the same period last year. Product gross margin benefited from lower direct and indirect product costs as a percentage of product revenue. Cost of product revenue was comprised of direct product costs and indirect costs, including inventory reserves and other manufacturing overhead.

[0001262039-19-000033:mdna:75]
Service gross margin increased by 0.8 percentage points during the three months ended September 30, 2019 compared to the same period last year, as our service revenue growth outpaced our growth in related personnel costs. Cost of service revenue was comprised primarily of personnel costs.

[0001262039-19-000033:mdna:76]
[same as prior period, unchanged from 0001262039-19-000023:mdna:76]

[0001262039-19-000033:mdna:77]
|  | Three Months Ended |  | Change |  | % Change |
| September 30, 2019 |  | September 30, 2018 |  |
| Amount |  | % ofRevenue |  | Amount |  | % ofRevenue |  |
| (in millions, except percentages) |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | $ | 69.9 |  |  | 13% |  | $ | 58.7 |  |  | 13 | % |  | $ | 11.2 |  |  | 19 | % |
| Sales and marketing | 227.4 |  |  | 42 |  | 198.3 |  |  | 44 |  |  | 29.1 |  |  | 15 |  |
| General and administrative | 26.1 |  |  | 5 |  | 22.5 |  |  | 5 |  |  | 3.6 |  |  | 16 |  |
| Total operating expenses | $ | 323.4 |  |  | 59% |  | $ | 279.5 |  |  | 62 | % |  | $ | 43.9 |  |  | 16 | % |

[0001262039-19-000033:mdna:78]
[same as prior period, unchanged from 0001262039-19-000023:mdna:78]

[0001262039-19-000033:mdna:79]
Research and development expense increased by $11.2 million, or 19%, during the three months ended September 30, 2019 compared to the same period last year, primarily due to an increase of $7.2 million in personnel-related costs as a result of increased headcount to support the development of new products and continued enhancements to our existing products. In addition, product development expenses, such as third-party testing, prototypes and supplies, increased by $2.4 million. We intend to continue to invest in our research and development organization, and expect research and development expense to increase in absolute dollars during the remainder of 2019.

[0001262039-19-000033:mdna:80]
[same as prior period, unchanged from 0001262039-19-000023:mdna:80]

[0001262039-19-000033:mdna:81]
Sales and marketing expense increased by $29.1 million, or 15%, during the three months ended September 30, 2019 compared to the same period last year, primarily due to an increase of $19.1 million in personnel-related costs as a result of

[0001262039-19-000033:mdna:82]
increased sales and marketing headcount to drive global market share gains. Marketing-related expense increased by $4.4 million. We intend to continue to make investments in our sales resources and infrastructure and marketing strategy, which are critical to support our future growth, and expect sales and marketing expense to increase in absolute dollars during the remainder of 2019.

[0001262039-19-000033:mdna:83]
[same as prior period, unchanged from 0001262039-19-000023:mdna:82]

[0001262039-19-000033:mdna:84]
General and administrative expense increased by $3.6 million, or 16%, during the three months ended September 30, 2019 compared to the same period last year, primarily due to an increase in personnel-related costs of $1.7 million and an increase in professional services costs of $1.2 million. We expect general and administrative expense to increase in absolute dollars during the remainder of 2019.

[0001262039-19-000033:mdna:85]
Interest income and other income (expense)—net

[0001262039-19-000033:mdna:86]
|  | Three Months Ended |  |  |  |  |
| September 30, 2019 |  | September 30, 2018 |  | Change |  | % Change |
| (in millions, except percentages) |
| Interest income | $ | 11.4 |  |  | $ | 6.9 |  |  | $ | 4.5 |  |  | 65 | % |
| Other income (expense)—net | $ | (6.0 | ) |  | $ | 0.9 |  |  | $ | (6.9 | ) |  | (767 | )% |

[0001262039-19-000033:mdna:87]
Interest income increased during the three months ended September 30, 2019 compared to the same period last year, primarily due to higher interest rates and, to a lesser extent, higher invested balances of cash, cash equivalents and investments. Interest income varies depending on our average investment balances during the period, types and mix of investments, and market interest rates. The change in other income (expense)—net during the three months ended September 30, 2019 compared to the same period last year was the result of a $3.8 million impairment charge on an investment in a privately held company during the third quarter of 2019 compared to a $2.2 million gain on the sale of an investment in a privately held company in the same period last year. In addition, foreign currency exchange losses increased by $1.0 million compared to the same period last year.

[0001262039-19-000033:mdna:88]
[same as prior period, unchanged from 0001262039-19-000023:mdna:87]

[0001262039-19-000033:mdna:89]
|  | Three Months Ended |  | Change |  | % Change |
| September 30, 2019 |  | September 30, 2018 |  |
| (in millions, except percentages) |
| Provision for income taxes | $ | 25.6 |  |  | $ | 11.9 |  |  | $ | 13.7 |  |  | 115 | % |
| Effective tax rate (%) | 24 | % |  | 17 | % |  |  |  |  |  |  |

[0001262039-19-000033:mdna:90]
Our effective tax rate was 24% for the three months ended September 30, 2019 compared to an effective tax rate of 17% for the same period last year. The provision for income taxes for the three months ended September 30, 2019 was primarily comprised of U.S. federal and state taxes, withholding taxes and foreign taxes of $29.6 million, which were offset by excess tax benefits from stock-based compensation expense of $6.9 million. The provision for income taxes for the three months ended September 30, 2019 included a net increase in tax expense of $2.9 million due to the settlement of foreign tax audits. The provision for income taxes for the three months ended September 30, 2018 was comprised of U.S. federal and state taxes, withholding taxes, and foreign taxes of $17.7 million, which were offset by excess tax benefits from stock-based compensation expense of $5.8 million.

[0001262039-19-000033:mdna:91]
[same as prior period, unchanged from 0001262039-19-000023:mdna:90]

[0001262039-19-000033:mdna:92]
Nine Months Ended September 30, 2019 and September 30, 2018

[0001262039-19-000033:mdna:93]
[same as prior period, unchanged from 0001262039-19-000023:mdna:92]

[0001262039-19-000033:mdna:94]
|  | Nine Months Ended |  |  |  |  |
| September 30, 2019 |  | September 30, 2018 |  |  |  |  |
| Amount |  | % ofRevenue |  | Amount |  | % ofRevenue |  | Change |  | % Change |
| (in millions, except percentages) |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 549.7 |  |  | 36 | % |  | $ | 473.6 |  |  | 37 | % |  | $ | 76.1 |  |  | 16 | % |
| Service | 992.1 |  |  | 64 |  |  | 820.6 |  |  | 63 |  |  | 171.5 |  |  | 21 |  |
| Total revenue | $ | 1,541.8 |  |  | 100 | % |  | $ | 1,294.2 |  |  | 100 | % |  | $ | 247.6 |  |  | 19 | % |
| Revenue by geography: |  |  |  |  |  |  |  |  |  |  |  |
| Americas | $ | 666.7 |  |  | 43 | % |  | $ | 559.1 |  |  | 43 | % |  | $ | 107.6 |  |  | 19 | % |
| EMEA | 569.9 |  |  | 37 |  |  | 474.3 |  |  | 37 |  |  | 95.6 |  |  | 20 |  |
| APAC | 305.2 |  |  | 20 |  |  | 260.8 |  |  | 20 |  |  | 44.4 |  |  | 17 |  |
| Total revenue | $ | 1,541.8 |  |  | 100 | % |  | $ | 1,294.2 |  |  | 100 | % |  | $ | 247.6 |  |  | 19 | % |

[0001262039-19-000033:mdna:95]
Total revenue increased by $247.6 million, or 19%, during the nine months ended September 30, 2019 compared to the same period last year. We continued to experience diversification of revenue globally, and across both customer and industry segments. Revenue from all regions grew, with the Americas contributing the largest portion of our revenue growth on an absolute dollar basis.

[0001262039-19-000033:mdna:96]
Product revenue increased by $76.1 million, or 16%, during the nine months ended September 30, 2019 compared to the same period last year. We experienced revenue growth across many of our hardware and software products due to an increase in FortiGates sold as part of SD-WAN solutions and growth in sales of our Infrastructure Security solutions.

[0001262039-19-000033:mdna:97]
Service revenue increased by $171.5 million, or 21%, during the nine months ended September 30, 2019 compared to the same period last year. FortiGuard security subscription and FortiCare technical support and other revenues increased by $104.8 million, or 24%, and by $66.7 million, or 18%, respectively, during the nine months ended September 30, 2019 compared to the same period last year. The increases were primarily due to the recognition of revenue from our growing deferred revenue balance related to FortiGuard and other security subscriptions and FortiCare technical support and other contracts. Of the service revenue recognized during the nine months ended September 30, 2019, 76% was included in the deferred revenue balance as of December 31, 2018.

[0001262039-19-000033:mdna:98]
[same as prior period, unchanged from 0001262039-19-000023:mdna:97]

[0001262039-19-000033:mdna:99]
|  | Nine Months Ended |  |  |  |  |
| September 30, 2019 |  | September 30, 2018 |  | Change |  | % Change |
| (in millions, except percentages) |
| Cost of revenue: |  |  |  |  |  |  |  |
| Product | $ | 231.9 |  |  | $ | 204.1 |  |  | $ | 27.8 |  |  | 14 | % |
| Service | 133.5 |  |  | 117.8 |  |  | 15.7 |  |  | 13 |  |
| Total cost of revenue | $ | 365.4 |  |  | $ | 321.9 |  |  | $ | 43.5 |  |  | 14 | % |
| Gross margin (%): |  |  |  |  |  |  |  |
| Product | 57.8 | % |  | 56.9 | % |  |  |  |  |
| Service | 86.5 |  |  | 85.6 |  |  |  |  |  |
| Total gross margin | 76.3 | % |  | 75.1 | % |  |  |  |  |

[0001262039-19-000033:mdna:100]
Total gross margin increased by 1.2 percentage points during the nine months ended September 30, 2019 compared to the same period last year, driven by improvements to both product and service gross margins.

[0001262039-19-000033:mdna:101]
Product gross margin increased by 0.9 percentage points during the nine months ended September 30, 2019 compared to the same period last year. Product gross margin benefited from lower direct and indirect product costs as percentage of product revenue. Cost of product revenue was comprised of direct product costs and indirect costs, including inventory reserves and other manufacturing overhead.

[0001262039-19-000033:mdna:102]
Service gross margin increased by 0.9 percentage points during the nine months ended September 30, 2019 compared to the same period last year, as our service revenue growth outpaced our growth in related personnel costs. Cost of service revenue was comprised primarily of personnel costs.

[0001262039-19-000033:mdna:103]
[same as prior period, unchanged from 0001262039-19-000023:mdna:102]

[0001262039-19-000033:mdna:104]
|  | Nine Months Ended |  | Change |  | % Change |
| September 30, 2019 |  | September 30, 2018 |  |
| Amount |  | % ofRevenue |  | Amount |  | % ofRevenue |  |
| (in millions, except percentages) |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | $ | 205.9 |  |  | 13% |  | $ | 179.0 |  |  | 14 | % |  | $ | 26.9 |  |  | 15 | % |
| Sales and marketing | 669.8 |  |  | 43 |  | 576.4 |  |  | 45 |  |  | 93.4 |  |  | 16 |  |
| General and administrative | 74.9 |  |  | 5 |  | 71.0 |  |  | 5 |  |  | 3.9 |  |  | 5 |  |
| Total operating expenses | $ | 950.6 |  |  | 62% |  | $ | 826.4 |  |  | 64 | % |  | $ | 124.2 |  |  | 15 | % |

[0001262039-19-000033:mdna:105]
[same as prior period, unchanged from 0001262039-19-000023:mdna:104]

[0001262039-19-000033:mdna:106]
Research and development expense increased by $26.9 million, or 15%, during the nine months ended September 30, 2019 compared to the same period last year, primarily due to an increase in personnel-related costs of $21.3 million as a result of increased headcount to support the development of new products and continued enhancements to our existing products.

[0001262039-19-000033:mdna:107]
[same as prior period, unchanged from 0001262039-19-000023:mdna:106]

[0001262039-19-000033:mdna:108]
Sales and marketing expense increased by $93.4 million, or 16%, during the nine months ended September 30, 2019 compared to the same period last year, primarily due to an increase in personnel-related costs of $66.2 million as a result of increased sales and marketing headcount in order to drive global market share gains. In addition, marketing-related expense increased by $10.8 million.

[0001262039-19-000033:mdna:109]
[same as prior period, unchanged from 0001262039-19-000023:mdna:108]

[0001262039-19-000033:mdna:110]
General and administrative expense increased by $3.9 million, or 5%, during the nine months ended September 30, 2019 compared to the same period last year, primarily due to an increase in personnel-related costs of $3.1 million and an increase in professional services of $0.6 million.

[0001262039-19-000033:mdna:111]
[same as prior period, unchanged from 0001262039-19-000023:mdna:84]

[0001262039-19-000033:mdna:112]
|  | Nine Months Ended |  |  |  |  |
| September 30, 2019 |  | September 30, 2018 |  | Change |  | % Change |
| (in millions, except percentages) |
| Interest income | $ | 32.6 |  |  | $ | 17.2 |  |  | $ | 15.4 |  |  | 90 | % |
| Other expense—net | $ | (6.9 | ) |  | $ | (4.3 | ) |  | $ | (2.6 | ) |  | 60 | % |

[0001262039-19-000033:mdna:113]
Interest income increased during the nine months ended September 30, 2019 compared to the same period last year, primarily due to higher interest rates and, to a lesser extent, higher invested balances of cash, cash equivalents and investments. Interest income varies depending on our average investment balances during the period, types and mix of investments, and market interest rates. The change in other expense—net during the nine months ended September 30, 2019 compared to the same period last year was the result of a $3.8 million impairment charge on an investment in a privately held company during the third quarter of 2019 compared to a $2.2 million gain on the sale of an investment in a privately held company in the same period last year, partially offset by lower foreign currency exchange losses.

[0001262039-19-000033:mdna:114]
Provision for income taxes

[0001262039-19-000033:mdna:115]
|  | Nine Months Ended |  | Change |  | % Change |
| September 30, 2019 |  | September 30, 2018 |  |
| (in millions, except percentages) |
| Provision for income taxes | $ | 40.2 |  |  | $ | 9.2 |  |  | $ | 31.0 |  |  | 337 | % |
| Effective tax rate (%) | 16 | % |  | 6 | % |  |  |  |  |  |  |

[0001262039-19-000033:mdna:116]
Our effective tax rate was 16% for the nine months ended September 30, 2019 compared to an effective tax rate benefit of 6% for the same period last year. The provision for income taxes for the nine months ended September 30, 2019 was primarily comprised of U.S. federal and state taxes, withholding taxes and foreign taxes of $71.6 million, which were offset by excess tax benefits from stock-based compensation expense of $34.6 million. The provision for income taxes for the nine months ended September 30, 2019 included an increase in tax expense of $10.3 million for an unrecognized tax benefit related to the Ninth Circuit’s Altera decision regarding stock-based compensation expense in cost sharing arrangements. The provision for income taxes for the nine months ended September 30, 2019 included a net increase in tax expense of $2.9 million due to the settlement of foreign tax audits. This expense was offset by the release of reserves of $10.0 million on uncertain tax positions and the associated interests due to the expiration of the statute of limitations. The provision for income taxes for the nine months ended September 30, 2018 was comprised of U.S. federal and state taxes, withholding taxes and foreign taxes of $43.4 million, which were offset by excess tax benefits from stock-based compensation expense of $16.2 million. The provision for income taxes for the nine month ended September 30, 2018 was also impacted by release of reserve for uncertain tax positions including interest of $18.0 million.

[0001262039-19-000033:mdna:117]
[same as prior period, unchanged from 0001262039-19-000023:mdna:117]

[0001262039-19-000033:mdna:118]
|  | As of |
|  | September 30, 2019 |  | December 31, 2018 |
|  | (in millions) |
| Cash and cash equivalents | $ | 1,175.5 |  |  | $ | 1,112.4 |  |
| Investments | 969.0 |  |  | 604.2 |  |
| Total cash, cash equivalents and investments | $ | 2,144.5 |  |  | $ | 1,716.6 |  |
| Working capital | $ | 1,124.3 |  |  | $ | 964.5 |  |
|  | Nine Months Ended |
|  | September 30, 2019 |  | September 30, 2018 |
|  | (in millions) |
| Net cash provided by operating activities | $ | 617.6 |  |  | $ | 458.7 |  |
| Net cash used in investing activities | (402.7 | ) |  | (7.4 | ) |
| Net cash used in financing activities | (151.8 | ) |  | (93.0 | ) |
| Net increase in cash and cash equivalents | $ | 63.1 |  |  | $ | 358.3 |  |

[0001262039-19-000033:mdna:119]
Liquidity and capital resources may be impacted by our operating activities, as well as by our stock repurchases, proceeds associated with stock option exercises, issuances of common stock under our equity incentive plans and payment of taxes in connection with the net settlement of equity awards, and real estate and other capital expenditures. In recent years, we have received significant capital resources from billings, the exercise of stock options and ESPP purchases. Additional

[0001262039-19-000033:mdna:120]
[same as prior period, unchanged from 0001262039-19-000023:mdna:116]

[0001262039-19-000033:mdna:121]
increases in billings may depend on a number of factors, including demand for our products and services, competition, market or industry changes, and our ability to execute. We expect proceeds from the exercise of stock options in future years to be impacted by the increased mix of restricted stock units versus stock options granted and also to vary based on our share price. We expect there to be no future proceeds from purchases under our ESPP, which was terminated in February 2019. As of September 30, 2019, $616.3 million remained available for future share repurchase under the Repurchase Program.

[0001262039-19-000033:mdna:122]
Construction of our new headquarters building started in the fourth quarter of 2018 and related spending will continue in 2019 and until project completion. We estimate 2019 spending on the project to be between $35.0 million to $45.0 million dollars.

[0001262039-19-000033:mdna:123]
As of September 30, 2019, our cash, cash equivalents and investments of $2.14 billion were invested primarily in deposit accounts, money market funds, corporate debt securities, commercial paper, certificates of deposit and term deposits and U.S. government and agency securities. It is our investment policy to invest excess cash in a manner that preserves capital, provides liquidity and generates return without significantly increasing risk. We do not enter into investments for trading or speculative purposes.

[0001262039-19-000033:mdna:124]
The amount of cash, cash equivalents and investments held by our international subsidiaries was $133.8 million as of September 30, 2019 and $956.6 million as of December 31, 2018. The decrease in cash, cash equivalents and investments held by our international subsidiaries related to changes in our international tax structure.

[0001262039-19-000033:mdna:125]
[same as prior period, unchanged from 0001262039-19-000023:mdna:123]

[0001262039-19-000033:mdna:126]
[same as prior period, unchanged from 0001262039-19-000023:mdna:125]

[0001262039-19-000033:mdna:127]
[same as prior period, unchanged from 0001262039-19-000023:mdna:126]

[0001262039-19-000033:mdna:128]
Our operating activities during the nine months ended September 30, 2019 provided $617.6 million in cash as a result of the continued growth of our business and our ability to successfully manage our working capital. Changes in operating assets and liabilities primarily resulted from an increase in sales of our FortiGuard security subscription and FortiCare technical support services to new and existing customers, as reflected by an increase in our deferred revenue. Our total deferred revenue balance grew $258.8 million, or 15%, during the nine months ended September 30, 2019.

[0001262039-19-000033:mdna:129]
Our operating activities during the nine months ended September 30, 2018 provided $458.7 million in cash as a result of the continued growth of our business and our ability to successfully manage our working capital. Changes in operating assets and liabilities primarily resulted from an increase in sales of our FortiGuard security subscription and FortiCare technical support services to new and existing customers, as reflected by an increase in our deferred revenue. Our total deferred revenue balance grew $212.2 million, or 16%, during the nine months ended September 30, 2018.

[0001262039-19-000033:mdna:130]
[same as prior period, unchanged from 0001262039-19-000023:mdna:129]

[0001262039-19-000033:mdna:131]
[same as prior period, unchanged from 0001262039-19-000023:mdna:130]

[0001262039-19-000033:mdna:132]
During the nine months ended September 30, 2019, cash used in investing activities was primarily driven by $357.7 million expended on purchases of investments, net of maturities and sales of investments, and $45.0 million spent on purchases of property and equipment.

[0001262039-19-000033:mdna:133]
[same as prior period, unchanged from 0001262039-19-000023:mdna:124]

[0001262039-19-000033:mdna:134]
During the nine months ended September 30, 2018, cash used for investing activities was primarily driven by $41.4 million expended on purchases of property and equipment and $6.0 million used for the acquisition of Bradford, net of cash acquired. This was partially offset by an increase in cash of $40.0 million due to maturities and sales of our investments, net of purchases.

[0001262039-19-000033:mdna:135]
[same as prior period, unchanged from 0001262039-19-000023:mdna:133]

[0001262039-19-000033:mdna:136]
[same as prior period, unchanged from 0001262039-19-000023:mdna:134]

[0001262039-19-000033:mdna:137]
During the nine months ended September 30, 2019, cash used in financing activities was $151.8 million, primarily driven by $117.6 million used to repurchase our common stock and $34.2 million used to pay tax withholding, net of proceeds, from the issuance of common stock.

[0001262039-19-000033:mdna:138]
During the nine months ended September 30, 2018, cash used in financing activities was $93.0 million, primarily driven by $117.1 million used to repurchase our common stock and $9.5 million of payments of the debt assumed in a business combination, partially offset by $33.6 million of proceeds from the issuance of common stock, net of tax withholding.

[0001262039-19-000033:mdna:139]
[same as prior period, unchanged from 0001262039-19-000023:mdna:137]

[0001262039-19-000033:mdna:140]
Except for presentation changes resulting from the adoption of Accounting Standards Update (“ASU”) 2016-02—Leases (Topic 842) (“Topic 842”) during the period, there were no material changes outside the ordinary course of business during the nine months ended September 30, 2019 to the contractual obligations and commitments disclosed in Management’s Discussion and Analysis of Financial Condition and Results of Operations, set forth in Part II, Item 7, of the Form 10-K. See Note 11 of the notes to condensed consolidated financial statements included in Part I, Item 1 of this Quarterly Report on Form 10-Q for additional information regarding contractual obligations and commitments.

[0001262039-19-000033:mdna:141]
[same as prior period, unchanged from 0001262039-19-000023:mdna:140]

[0001262039-19-000033:mdna:142]
As of September 30, 2019, we did not have any relationships with unconsolidated organizations or financial partnerships, such as structured finance or special purpose entities that would have been established for the purpose of facilitating off-balance sheet arrangements or other contractually narrow or limited purposes.
