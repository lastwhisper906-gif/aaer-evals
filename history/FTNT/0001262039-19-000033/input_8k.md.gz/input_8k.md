# FTNT 8-K — 0001262039-19-000032 filed 2019-10-31

## item codes, every 8-K on or before 2019-10-31

- 2019-10-31 0001262039-19-000032 — 2.02, 9.01
- 2019-10-28 0001262039-19-000027 — 8.01
- 2019-10-23 0001262039-19-000025 — 5.02, 9.01
- 2019-08-01 0001262039-19-000021 — 2.02, 9.01
- 2019-06-26 0001262039-19-000018 — 5.07
- 2019-05-02 0001262039-19-000010 — 2.02, 9.01
- 2019-02-06 0001262039-19-000002 — 2.02, 9.01
- 2018-11-01 0001262039-18-000037 — 2.02, 9.01
- 2018-10-23 0001262039-18-000035 — 8.01
- 2018-08-01 0001262039-18-000025 — 2.02, 9.01
- 2018-06-28 0001262039-18-000023 — 5.03, 5.07, 9.01
- 2018-06-04 0001262039-18-000021 — 8.01
- 2018-05-03 0001262039-18-000017 — 2.02, 5.02, 9.01
- 2018-02-05 0001262039-18-000004 — 2.02, 5.02, 9.01
- 2017-10-26 0001262039-17-000031 — 2.02, 9.01
- 2017-10-19 0001262039-17-000029 — 5.02 — amendment, the index does not say of what
- 2017-07-26 0001262039-17-000025 — 2.02, 9.01
- 2017-06-27 0001262039-17-000023 — 5.07
- 2017-05-31 0001262039-17-000021 — 5.02 — amendment of 0001262039-17-000019
- 2017-05-30 0001262039-17-000019 — 5.02, 9.01
- 2017-04-27 0001262039-17-000013 — 2.02, 9.01
- 2017-02-02 0001262039-17-000003 — 2.02, 9.01
- 2016-10-27 0001262039-16-000085 — 2.02, 9.01
- 2016-10-11 0001262039-16-000082 — 2.02, 9.01
- 2016-07-28 0001262039-16-000076 — 2.02, 9.01
- 2016-07-22 0001262039-16-000073 — 8.01, 9.01
- 2016-06-20 0001262039-16-000068 — 5.07
- 2016-06-07 0001193125-16-614788 — 8.01
- 2016-04-26 0001262039-16-000061 — 2.02, 9.01
- 2016-01-28 0001262039-16-000051 — 2.02, 9.01
- 2015-10-27 0001262039-15-000045 — 2.02
- 2015-10-22 0001262039-15-000042 — 5.02 — amendment, the index does not say of what
- 2015-10-22 0001262039-15-000041 — 5.02 — amendment, the index does not say of what
- 2015-10-22 0001262039-15-000039 — 2.02, 9.01
- 2015-09-28 0001262039-15-000034 — 5.02, 9.01
- 2015-09-22 0001262039-15-000031 — 9.01 — amendment of 0001193125-15-248065
- 2015-08-28 0001262039-15-000027 — 3.01, 5.02
- 2015-07-23 0001262039-15-000021 — 5.02
- 2015-07-22 0001262039-15-000019 — 2.02, 9.01
- 2015-07-08 0001193125-15-248065 — 2.01, 8.01, 9.01
- 2015-06-22 0001193125-15-229099 — 5.07
- 2015-06-19 0001193125-15-228428 — 5.02, 9.01
- 2015-04-20 0001262039-15-000014 — 2.02, 9.01
- 2015-01-28 0001262039-15-000005 — 2.02, 9.01
- 2014-10-22 0001262039-14-000036 — 2.02, 9.01
- 2014-07-23 0001262039-14-000030 — 2.02, 9.01
- 2014-06-24 0001262039-14-000027 — 5.07
- 2014-04-23 0001262039-14-000021 — 2.02, 9.01
- 2014-04-21 0001262039-14-000018 — 5.03, 9.01
- 2014-01-29 0001262039-14-000004 — 2.02, 9.01
- 2013-12-20 0001262039-13-000061 — 5.02, 9.01
- 2013-11-27 0001262039-13-000057 — 5.02, 7.01, 9.01
- 2013-11-12 0001445305-13-002993 — 5.02
- 2013-10-23 0001262039-13-000051 — 2.02, 9.01
- 2013-07-30 0001262039-13-000039 — 2.02, 9.01
- 2013-06-25 0001262039-13-000030 — 5.07
- 2013-04-30 0001262039-13-000023 — 2.02, 9.01
- 2013-04-19 0001262039-13-000020 — 5.02, 9.01
- 2013-04-19 0001262039-13-000018 — 5.02 — amendment of 0001262039-13-000020
- 2013-04-10 0001262039-13-000016 — 2.02, 9.01
- 2013-03-26 0001262039-13-000013 — 5.02
- 2013-01-30 0001262039-13-000005 — 2.02, 9.01
- 2013-01-24 0001262039-13-000002 — 5.02, 9.01
- 2012-10-16 0001262039-12-000048 — 2.02, 9.01
- 2012-10-01 0001262039-12-000045 — 5.02
- 2012-09-26 0001262039-12-000043 — 5.01
- 2012-07-25 0001262039-12-000038 — 2.02, 9.01
- 2012-07-19 0001262039-12-000034 — 5.02
- 2012-06-20 0001193125-12-275869 — 5.07
- 2012-04-27 0001262039-12-000029 — 5.02
- 2012-04-24 0001262039-12-000025 — 2.02, 9.01
- 2012-01-31 0001262039-12-000006 — 2.02, 9.01
- 2012-01-25 0001262039-12-000003 — 5.03
- 2011-10-24 0001262039-11-000036 — 2.02
- 2011-07-19 0001262039-11-000014 — 2.02, 9.01
- 2011-06-27 0001193125-11-174474 — 5.02, 5.07, 9.01
- 2011-04-27 0001193125-11-111938 — 2.02, 9.01
- 2011-01-25 0001193125-11-013914 — 2.02, 9.01
- 2010-10-21 0001193125-10-233676 — 2.02, 9.01
- 2010-09-02 0001193125-10-203099 — 8.01
- 2010-07-22 0001193125-10-163844 — 2.02, 9.01
- 2010-06-24 0001193125-10-146082 — 5.07
- 2010-04-28 0001193125-10-096698 — 2.02, 9.01
- 2010-02-09 0001193125-10-024614 — 8.01
- 2010-01-27 0001193125-10-014292 — 2.02, 9.01
- 2010-01-26 0001193125-10-013031 — 5.02, 9.01

## late-filing notifications on or before 2019-10-31

- none on or before 2019-10-31

## item 2.02 — earnings release, exhibit 99.1

[0001262039-19-000032:8k_2_02:1]
EX-99.1
2
ftntq3-2019ex991.htm
PRESS RELEASE

[0001262039-19-000032:8k_2_02:2]
Exhibit

[0001262039-19-000032:8k_2_02:3]
Press Release

[0001262039-19-000032:8k_2_02:4]
Fortinet Reports Third Quarter 2019 Financial Results

[0001262039-19-000032:8k_2_02:5]
Third Quarter 2019 Highlights

[0001262039-19-000032:8k_2_02:6]
| • | Total revenue of $547.5 million, up 21% year over year |

[0001262039-19-000032:8k_2_02:7]
| • | Product revenue of $197.1 million, up 20% year over year |

[0001262039-19-000032:8k_2_02:8]
| • | Billings of $626.6 million, up 19% year over year1 |

[0001262039-19-000032:8k_2_02:9]
| • | Deferred revenue of $1.95 billion, up 26% year over year |

[0001262039-19-000032:8k_2_02:10]
| • | GAAP operating margin of 18%, up 450 basis points year over year |

[0001262039-19-000032:8k_2_02:11]
| • | Non-GAAP operating margin of 26%, up 250 basis points year over year1 |

[0001262039-19-000032:8k_2_02:12]
| • | GAAP diluted net income per share of $0.46 |

[0001262039-19-000032:8k_2_02:13]
| • | Non-GAAP diluted net income per share of $0.671 |

[0001262039-19-000032:8k_2_02:14]
| • | Cash flow from operations of $221.2 million |

[0001262039-19-000032:8k_2_02:15]
| • | Free cash flow of $203.7 million, up $45.2 million year over year1 |

[0001262039-19-000032:8k_2_02:16]
SUNNYVALE, Calif. - October 31, 2019 - Fortinet® (Nasdaq: FTNT), a global leader in broad, integrated and automated cybersecurity solutions, today announced financial results for the third quarter ended September 30, 2019.

[0001262039-19-000032:8k_2_02:17]
“Strong revenue growth for Fortinet Security Fabric, cloud and SD-WAN offerings contributed to our 21% year-over-year total revenue growth in the third quarter, which we believe is stronger than the average revenue growth rate in our industry. The Americas and EMEA regions led the way with revenue growth of 24% and 21%, respectively,” said Ken Xie, Founder, Chairman and Chief Executive Officer. “As we approach the tenth anniversary of Fortinet’s initial public offering on November 18, we are focused on driving better than industry average growth for at least the next decade.”

[0001262039-19-000032:8k_2_02:18]
Financial Highlights for the Third Quarter of 2019

[0001262039-19-000032:8k_2_02:19]
| • | Revenue: Total revenue was $547.5 million for the third quarter of 2019, an increase of 21% compared to $453.9 million for the same quarter of 2018. |

[0001262039-19-000032:8k_2_02:20]
| • | Product revenue was $197.1 million for the third quarter of 2019, an increase of 20% compared to $164.5 million for the same quarter of 2018. |

[0001262039-19-000032:8k_2_02:21]
| • | Service revenue was $350.4 million for the third quarter of 2019, an increase of 21% compared to $289.4 million for the same quarter of 2018. |

[0001262039-19-000032:8k_2_02:22]
| • | Billings1: Total billings were $626.6 million for the third quarter of 2019, an increase of 19% compared to $527.5 million for the same quarter of 2018. |

[0001262039-19-000032:8k_2_02:23]
| • | Deferred Revenue: Total deferred revenue was $1.95 billion as of September 30, 2019, an increase of 26% compared to $1.54 billion as of September 30, 2018. |

[0001262039-19-000032:8k_2_02:24]
| • | GAAP Operating Income and Margin: GAAP operating income was $100.0 million for the third quarter of 2019, representing a GAAP operating margin of 18%. GAAP |

[0001262039-19-000032:8k_2_02:25]
operating income was $62.8 million for the same quarter of 2018, representing a GAAP operating margin of 14%.

[0001262039-19-000032:8k_2_02:26]
| • | Non-GAAP Operating Income and Margin1: Non-GAAP operating income was $144.6 million for the third quarter of 2019, representing a non-GAAP operating margin of 26%. Non-GAAP operating income was $108.5 million for the third quarter of 2018, representing a non-GAAP operating margin of 24%. |

[0001262039-19-000032:8k_2_02:27]
| • | GAAP Net Income and Diluted Net Income Per Share: GAAP net income was $79.8 million for the third quarter of 2019, compared to GAAP net income of $58.7 million for the same quarter of 2018. GAAP diluted net income per share was $0.46 for the third quarter of 2019, based on 174.8 million diluted weighted-average shares outstanding, compared to GAAP diluted net income per share of $0.33 for the same quarter of 2018, based on 175.7 million diluted weighted-average shares outstanding. |

[0001262039-19-000032:8k_2_02:28]
| • | Non-GAAP Net Income and Diluted Net Income Per Share1: Non-GAAP net income was $116.9 million for the third quarter of 2019, compared to non-GAAP net income of $86.7 million for the same quarter of 2018. Non-GAAP diluted net income per share was $0.67 for the third quarter of 2019, based on 174.8 million diluted weighted-average shares outstanding, compared to $0.49 for the same quarter of 2018, based on 175.7 million diluted weighted-average shares outstanding. |

[0001262039-19-000032:8k_2_02:29]
| • | Cash Flow and Free Cash Flow1: In the third quarter of 2019, cash flow from operations was $221.2 million compared to $176.7 million in the same quarter of 2018. Free cash flow was $203.7 million during the third quarter of 2019, compared to $158.5 million for the same quarter of 2018. |

[0001262039-19-000032:8k_2_02:30]
Guidance

[0001262039-19-000032:8k_2_02:31]
For the fourth quarter of 2019, Fortinet currently expects:

[0001262039-19-000032:8k_2_02:32]
| • | Revenue in the range of $595 million to $610 million |

[0001262039-19-000032:8k_2_02:33]
| • | Billings in the range of $750 million to $765 million |

[0001262039-19-000032:8k_2_02:34]
| • | Non-GAAP gross margin in the range of 75.5% to 76.5% |

[0001262039-19-000032:8k_2_02:35]
| • | Non-GAAP operating margin in the range of 25.5% to 26.0% |

[0001262039-19-000032:8k_2_02:36]
| • | Diluted non-GAAP net income per share in the range of $0.69 to $0.71, assuming a non-GAAP effective tax rate of 24%. This assumes a diluted share count of 176 million to 178 million. |

[0001262039-19-000032:8k_2_02:37]
For the fiscal year 2019, Fortinet currently expects:

[0001262039-19-000032:8k_2_02:38]
| • | Revenue in the range of $2.135 billion to $2.150 billion |

[0001262039-19-000032:8k_2_02:39]
| • | Service revenue in the range of $1.355 billion to $1.365 billion |

[0001262039-19-000032:8k_2_02:40]
| • | Billings in the range of $2.550 billion to $2.565 billion |

[0001262039-19-000032:8k_2_02:41]
| • | Non-GAAP gross margin in the range of 76.5% to 77.0% |

[0001262039-19-000032:8k_2_02:42]
| • | Non-GAAP operating margin in the range of 24.0% to 24.5% |

[0001262039-19-000032:8k_2_02:43]
| • | Diluted non-GAAP net income per share in the range of $2.39 to $2.41, assuming a non-GAAP effective tax rate of 24%. This assumes a diluted share count of 175 million to 177 million. |

[0001262039-19-000032:8k_2_02:44]
Our guidance with respect to non-GAAP financial measures excludes stock-based compensation and amortization of acquired intangible assets. We have not reconciled our guidance with respect to non-GAAP financial measures to the corresponding GAAP measures because certain items that impact these measures are uncertain or out of our control, or cannot be reasonably predicted. Accordingly, a reconciliation of these non-GAAP financial measures to the corresponding GAAP measures is not available without unreasonable effort.

[0001262039-19-000032:8k_2_02:45]
1 A reconciliation of GAAP to non-GAAP measures has been provided in the financial statement tables included in this press release. An explanation of these measures is also included below under the heading “Non-GAAP Financial Measures.”

[0001262039-19-000032:8k_2_02:46]
Conference Call Details

[0001262039-19-000032:8k_2_02:47]
Fortinet will host a conference call today at 1:30 p.m. Pacific Time (4:30 p.m. Eastern Time) to discuss the earnings results. The call can be accessed by dialing (877) 303-6913 (domestic) or (224) 357-2188 (international) with conference ID # 6981649. A live webcast of the conference call and supplemental slides will be accessible from the Investor Relations page of Fortinet’s website at https://investor.fortinet.com and a replay will be archived and accessible at https://investor.fortinet.com/events-and-presentations. A replay of this conference call can also be accessed through November 7, 2019, by dialing (855) 859-2056 (domestic) or (404) 537-3406 (international) with conference ID #6981649.

[0001262039-19-000032:8k_2_02:48]
Fourth Quarter 2019 Conference Participation Schedule:

[0001262039-19-000032:8k_2_02:49]
| • | Fortinet Investor / Analyst Day |

[0001262039-19-000032:8k_2_02:50]
November 18, 2019 - New York, NY

[0001262039-19-000032:8k_2_02:51]
| • | 2019 RBC Capital Markets Technology, Internet, Media and Telecommunications Conference |

[0001262039-19-000032:8k_2_02:52]
November 19, 2019 - New York, NY

[0001262039-19-000032:8k_2_02:53]
| • | Credit Suisse 23rd Annual Technology Conference |

[0001262039-19-000032:8k_2_02:54]
December 3, 2019 - Scottsdale, AZ

[0001262039-19-000032:8k_2_02:55]
| • | UBS Global TMT Conference |

[0001262039-19-000032:8k_2_02:56]
December 10, 2019 - New York, NY

[0001262039-19-000032:8k_2_02:57]
| • | Barclays Global Technology, Media and Telecommunications Conference |

[0001262039-19-000032:8k_2_02:58]
December 11, 2019 - San Francisco, CA

[0001262039-19-000032:8k_2_02:59]
Members of Fortinet’s management team are expected to present at Fortinet’s Investor/Analyst Day and these conferences and discuss the latest company strategies and initiatives. Fortinet’s conference presentations are expected to be available via webcast on the company’s web site. To listen to these presentations and access the most updated information and listen to the webcast of each event, please visit the Investor Relations page of Fortinet’s website at http://investor.fortinet.com. The schedule is subject to change.

[0001262039-19-000032:8k_2_02:60]
About Fortinet (www.fortinet.com)

[0001262039-19-000032:8k_2_02:61]
Fortinet (Nasdaq: FTNT) secures the largest enterprise, service provider and government organizations around the world. Fortinet empowers its customers with intelligent, seamless protection across the expanding attack surface and the power to take on ever-increasing performance requirements of the borderless network -- today and into the future. The Fortinet Security Fabric architecture can deliver security without compromise to address the most critical

[0001262039-19-000032:8k_2_02:62]
security challenges, whether in networked, application, cloud or mobile environments. Learn more at http://www.fortinet.com, the Fortinet Blog or FortiGuard Labs.

[0001262039-19-000032:8k_2_02:63]
#          #          #

[0001262039-19-000032:8k_2_02:64]
Copyright © 2019 Fortinet, Inc. All rights reserved. The symbols ® and ™ denote respectively federally registered trademarks and unregistered trademarks of Fortinet, Inc., its subsidiaries and affiliates. Fortinet’s trademarks include, but are not limited to, the following: Fortinet, FortiGate, FortiOS, FortiGuard, FortiCare, FortiAnalyzer, FortiManager, FortiASIC, FortiClient, FortiCloud, FortiCore, FortiMail, FortiSandbox, ABACAS, APSecure, FortiADC, FortiAI, FortiAntenna, FortiAP, FortiAppEngine, FortiAppMonitor, FortiAuthenticator, FortiBalancer, FortiBIOS, FortiBridge, FortiCache, FortiCam, FortiCamera, FortiCarrier, FortiCASB, FortiCenter, FortiCentral, FortiConnect, FortiController, FortiConverter, FortiCWP, FortiDB, FortiDDoS, FortiDeceptor, FortiDirector, FortiDNS, FortiExplorer, FortiExtender, FortiFone, FortiHypervisor, FortiInsight, FortiIsolator, FortiLocator, FortiLog, FortiMalwareEngine, FortiMeter, FortiMoM, FortiMonitor, FortiNAC, FortiPartner, FortiPlanner, FortiPortal, FortiPresence , FortiProtect, FortiProxy, FortiRecorder, FortiReporter, FortiRescue, FortiScan, FortiSDNConnector, FortiSIEM, FortiSDWAN, FortiSMS, FortiSwitch, FortiTester, FortiToken, FortiTrust, FortiVault, FortiVoice, FortiVoIP, FortiVS, FortiWAN, FortiWeb, FortiWiFi, FortiWLC, FortiWLCOS and FortiWLM. Other trademarks belong to their respective owners. Fortinet has not independently verified statements or certifications herein attributed to third parties and Fortinet does not independently endorse such statements. Notwithstanding anything to the contrary herein, nothing herein constitutes a warranty, guarantee, contract, binding specification or other binding commitment by Fortinet or any indication of intent related to a binding commitment, and performance and other specification information herein may be unique to certain environments.

[0001262039-19-000032:8k_2_02:65]
FTNT-F

[0001262039-19-000032:8k_2_02:66]
Forward-looking Statements

[0001262039-19-000032:8k_2_02:67]
This press release contains forward-looking statements that involve risks and uncertainties. These forward-looking statements include statements regarding demand for our products and services, our guidance for the fourth quarter and full year 2019, statements regarding the momentum in our business and future growth expectations and objectives, and all guidance and expectations of future financial results. Although we attempt to be accurate in making forward-looking statements, it is possible that future circumstances might differ from the assumptions on which such statements are based such that actual results are materially different from our forward-looking statements in this release. Important factors that could cause results to differ materially from the statements herein include the following: general economic risks; global economic conditions, country-specific economic conditions, and foreign currency risks; competitiveness in the security market; the dynamic nature of the security market and its products and services; specific economic risks worldwide and in different geographies, and among different customer segments; uncertainty regarding demand and increased business and renewals from existing customers; uncertainties around continued success in sales growth and market share gains; actual or perceived vulnerabilities in our products or services, and any actual or perceived breach of our network or our customers’ networks; longer sales cycles, particularly for larger enterprise, service providers, government and other large organization customers; the effectiveness of our salesforce and failure to convert sales pipeline into final sales; risks associated with successful implementation of multiple integrated software products and other product functionality risks; risks associated with integrating acquisitions and changes in circumstances and plans associated therewith; sales and marketing execution risks; execution risks around new product development and introductions and innovation; litigation and disputes and the potential cost, distraction and damage to sales and reputation caused thereby or by other factors; cybersecurity threats, breaches and other disruptions; market acceptance of new products and services; the ability to attract and retain personnel; changes in

[0001262039-19-000032:8k_2_02:68]
Non-GAAP Financial Measures

[0001262039-19-000032:8k_2_02:69]
We have provided in this release financial information that has not been prepared in accordance with U.S. Generally Accepted Accounting Principles (GAAP). These non-GAAP financial and liquidity measures are not based on any standardized methodology prescribed by GAAP and are not necessarily comparable to similar measures presented by other companies. We use these non-GAAP financial measures internally in analyzing our financial results and believe they are useful to investors, as a supplement to GAAP measures, in evaluating our ongoing operational performance. We believe that the use of these non-GAAP financial measures provides an additional tool for investors to use in evaluating ongoing operating results and trends and in comparing our financial results with peer companies, many of which present similar non-GAAP financial measures to investors.

[0001262039-19-000032:8k_2_02:70]
Non-GAAP financial measures should not be considered in isolation from, or as a substitute for, financial information prepared in accordance with GAAP. Investors are encouraged to review the reconciliation of these non-GAAP financial measures to their most directly comparable GAAP financial measures provided in the financial statement tables below.

[0001262039-19-000032:8k_2_02:71]
Billings (non-GAAP). We define billings as revenue recognized in accordance with GAAP plus the change in deferred revenue from the beginning to the end of the period and adjustments to the deferred revenue balance due to adoption of the new revenue recognition standard less any deferred revenue balances acquired from business combination(s) during the period. We consider billings to be a useful metric for management and investors because billings drive current and future revenue, which is an important indicator of the health and viability of our business. There are a number of limitations related to the use of billings instead of GAAP revenue. First, billings include amounts that have not yet been recognized as revenue and are impacted by the term of security and support agreements. Second, we may calculate billings in a manner that is different from peer companies that report similar financial measures. Management accounts for these limitations by providing specific information regarding GAAP revenue and evaluating billings together with GAAP revenue.

[0001262039-19-000032:8k_2_02:72]
Free cash flow (non-GAAP). We define free cash flow as net cash provided by operating activities minus purchases of property and equipment. We believe free cash flow to be a liquidity measure that provides useful information to management and investors about the amount of cash generated by the business that, after capital expenditures, can be used for strategic opportunities, including repurchasing outstanding common stock, investing in our business, making strategic acquisitions and strengthening the balance sheet. A limitation of using free cash flow rather than the GAAP measures of cash provided by or used in operating activities, investing activities, and financing activities is that free cash flow does not represent the total

[0001262039-19-000032:8k_2_02:73]
increase or decrease in the cash and cash equivalents balance for the period because it excludes cash flows from investing activities other than capital expenditures and cash flows from financing activities. Management accounts for this limitation by providing information about our capital expenditures and other investing and financing activities on the face of the cash flow statement and under the caption “Management’s Discussion and Analysis of Financial Condition and Results of Operations—Liquidity and Capital Resources” in our most recent Quarterly Report on Form 10-Q and Annual Report on Form 10-K and by presenting cash flows from investing and financing activities in our reconciliation of free cash flow. In addition, it is important to note that other companies, including companies in our industry, may not use free cash flow, may calculate free cash flow in a different manner than we do or may use other financial measures to evaluate their performance, all of which could reduce the usefulness of free cash flow as a comparative measure.

[0001262039-19-000032:8k_2_02:74]
Non-GAAP operating income and operating margin. We define non-GAAP operating income as operating income plus stock-based compensation, business acquisition-related charges, purchase accounting adjustments, impairment and amortization of acquired intangible assets, restructuring charges, litigation settlement expenses and, when applicable, other significant non-recurring items in a given quarter. Non-GAAP operating margin is defined as non-GAAP operating income divided by GAAP revenue. We consider these non-GAAP financial measures to be useful metrics for management and investors because they exclude the items noted above so that our management and investors can compare our recurring core business operating results over multiple periods. There are a number of limitations related to the use of non-GAAP operating income instead of operating income or loss calculated in accordance with GAAP. First, non-GAAP operating income excludes the items noted above. Second, the components of the costs that we exclude from our calculation of non-GAAP operating income may differ from the components that peer companies exclude when they report their non-GAAP results of operations. Management accounts for these limitations by providing specific information regarding the GAAP amounts excluded from non-GAAP operating income and evaluating non-GAAP operating income together with operating income calculated in accordance with GAAP.

[0001262039-19-000032:8k_2_02:75]
Non-GAAP net income and diluted net income per share. We define non-GAAP net income as net income or loss plus the items noted above under non-GAAP operating income and operating margin. In addition, we adjust non-GAAP net income and diluted net income per share for gains or losses on investments in privately held companies and a tax adjustment required for an effective tax rate on a non-GAAP basis, which differs from the GAAP effective tax rate. We define non-GAAP diluted net income per share as non-GAAP net income divided by the non-GAAP diluted weighted-average shares outstanding. We consider these non-GAAP financial measures to be useful metrics for management and investors for the same reasons that we use non-GAAP operating income and non-GAAP operating margin. However, in order to provide a more complete picture of our recurring core business operating results, we include in non-GAAP net income and non-GAAP diluted net income per share, the tax adjustment required resulting in an effective tax rate on a non-GAAP basis, which often differs from the GAAP tax rate. We believe the non-GAAP effective tax rates we use are reasonable estimates of normalized tax rates for our current and prior fiscal years under our global operating structure. The same limitations described above regarding our use of non-GAAP operating income and non-GAAP operating margin apply to our use of non-GAAP net income and non-GAAP diluted net income per share. We account for these limitations by providing specific information regarding the GAAP amounts excluded from non-GAAP net income and non-GAAP diluted net income per share and evaluating non-GAAP net income and non-GAAP diluted net income per share together with net income or loss and diluted net income per share calculated in accordance with GAAP.

[0001262039-19-000032:8k_2_02:76]
FORTINET, INC.

[0001262039-19-000032:8k_2_02:77]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001262039-19-000032:8k_2_02:78]
(Unaudited, in millions)

[0001262039-19-000032:8k_2_02:79]
|  | September 30, 2019 |  | December 31, 2018 |
| ASSETS |  |  |  |
| CURRENT ASSETS: |  |  |  |
| Cash and cash equivalents | $ | 1,175.5 |  |  | $ | 1,112.4 |  |
| Short-term investments | 764.8 |  |  | 537.2 |  |
| Accounts receivable—net | 384.1 |  |  | 444.5 |  |
| Inventory | 99.2 |  |  | 90.0 |  |
| Prepaid expenses and other current assets | 42.6 |  |  | 36.8 |  |
| Total current assets | 2,466.2 |  |  | 2,220.9 |  |
| LONG-TERM INVESTMENTS | 204.2 |  |  | 67.0 |  |
| PROPERTY AND EQUIPMENT—NET | 305.5 |  |  | 271.4 |  |
| DEFERRED CONTRACT COSTS | 217.4 |  |  | 182.6 |  |
| DEFERRED TAX ASSETS | 243.7 |  |  | 255.0 |  |
| GOODWILL | 38.2 |  |  | 38.2 |  |
| OTHER INTANGIBLE ASSETS—NET | 14.0 |  |  | 22.1 |  |
| OTHER ASSETS | 56.4 |  |  | 20.8 |  |
| TOTAL ASSETS | $ | 3,545.6 |  |  | $ | 3,078.0 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |
| CURRENT LIABILITIES: |  |  |  |
| Accounts payable | $ | 85.9 |  |  | $ | 86.4 |  |
| Accrued liabilities | 90.4 |  |  | 77.5 |  |
| Accrued payroll and compensation | 90.4 |  |  | 98.4 |  |
| Income taxes payable | 11.6 |  |  | 28.2 |  |
| Deferred revenue | 1,063.6 |  |  | 965.9 |  |
| Total current liabilities | 1,341.9 |  |  | 1,256.4 |  |
| DEFERRED REVENUE | 882.0 |  |  | 720.9 |  |
| INCOME TAX LIABILITIES | 83.1 |  |  | 77.5 |  |
| OTHER LIABILITIES | 38.2 |  |  | 13.0 |  |
| Total liabilities | 2,345.2 |  |  | 2,067.8 |  |
| COMMITMENTS AND CONTINGENCIES |  |  |  |
| STOCKHOLDERS’ EQUITY: |  |  |  |
| Common stock | 0.2 |  |  | 0.2 |  |
| Additional paid-in capital | 1,152.6 |  |  | 1,068.3 |  |
| Accumulated other comprehensive income (loss) | 1.1 |  |  | (0.8 | ) |
| Retained earnings (accumulated deficit) | 46.5 |  |  | (57.5 | ) |
| Total stockholders’ equity | 1,200.4 |  |  | 1,010.2 |  |
| TOTAL LIABILITIES AND STOCKHOLDERS’ EQUITY | $ | 3,545.6 |  |  | $ | 3,078.0 |  |

[0001262039-19-000032:8k_2_02:80]
FORTINET, INC.

[0001262039-19-000032:8k_2_02:81]
CONDENSED CONSOLIDATED STATEMENTS OF INCOME

[0001262039-19-000032:8k_2_02:82]
(Unaudited, in millions, except per share amounts)

[0001262039-19-000032:8k_2_02:83]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30, 2019 |  | September 30, 2018 |  | September 30, 2019 |  | September 30, 2018 |
| REVENUE: |  |  |  |  |  |  |  |
| Product | $ | 197.1 |  |  | $ | 164.5 |  |  | $ | 549.7 |  |  | $ | 473.6 |  |
| Service | 350.4 |  |  | 289.4 |  |  | 992.1 |  |  | 820.6 |  |
| Total revenue | 547.5 |  |  | 453.9 |  |  | 1,541.8 |  |  | 1,294.2 |  |
| COST OF REVENUE: |  |  |  |  |  |  |  |
| Product | 79.0 |  |  | 72.0 |  |  | 231.9 |  |  | 204.1 |  |
| Service | 45.1 |  |  | 39.6 |  |  | 133.5 |  |  | 117.8 |  |
| Total cost of revenue | 124.1 |  |  | 111.6 |  |  | 365.4 |  |  | 321.9 |  |
| GROSS PROFIT: |  |  |  |  |  |  |  |
| Product | 118.1 |  |  | 92.5 |  |  | 317.8 |  |  | 269.5 |  |
| Service | 305.3 |  |  | 249.8 |  |  | 858.6 |  |  | 702.8 |  |
| Total gross profit | 423.4 |  |  | 342.3 |  |  | 1,176.4 |  |  | 972.3 |  |
| OPERATING EXPENSES: |  |  |  |  |  |  |  |
| Research and development | 69.9 |  |  | 58.7 |  |  | 205.9 |  |  | 179.0 |  |
| Sales and marketing | 227.4 |  |  | 198.3 |  |  | 669.8 |  |  | 576.4 |  |
| General and administrative | 26.1 |  |  | 22.5 |  |  | 74.9 |  |  | 71.0 |  |
| Total operating expenses | 323.4 |  |  | 279.5 |  |  | 950.6 |  |  | 826.4 |  |
| OPERATING INCOME | 100.0 |  |  | 62.8 |  |  | 225.8 |  |  | 145.9 |  |
| INTEREST INCOME | 11.4 |  |  | 6.9 |  |  | 32.6 |  |  | 17.2 |  |
| OTHER INCOME (EXPENSE)—NET | (6.0 | ) |  | 0.9 |  |  | (6.9 | ) |  | (4.3 | ) |
| INCOME BEFORE INCOME TAXES | 105.4 |  |  | 70.6 |  |  | 251.5 |  |  | 158.8 |  |
| PROVISION FOR INCOME TAXES | 25.6 |  |  | 11.9 |  |  | 40.2 |  |  | 9.2 |  |
| NET INCOME | $ | 79.8 |  |  | $ | 58.7 |  |  | $ | 211.3 |  |  | $ | 149.6 |  |
| Net income per share: |  |  |  |  |  |  |  |
| Basic | $ | 0.47 |  |  | $ | 0.35 |  |  | $ | 1.24 |  |  | $ | 0.89 |  |
| Diluted | $ | 0.46 |  |  | $ | 0.33 |  |  | $ | 1.21 |  |  | $ | 0.86 |  |
| Weighted-average shares outstanding: |  |  |  |  |  |  |  |
| Basic | 171.3 |  |  | 169.8 |  |  | 170.9 |  |  | 168.7 |  |
| Diluted | 174.8 |  |  | 175.7 |  |  | 174.9 |  |  | 173.7 |  |

[0001262039-19-000032:8k_2_02:84]
FORTINET, INC.

[0001262039-19-000032:8k_2_02:85]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001262039-19-000032:8k_2_02:86]
(Unaudited, in millions)

[0001262039-19-000032:8k_2_02:87]
|  | Nine Months Ended |
|  | September 30, 2019 |  | September 30, 2018 |
| CASH FLOWS FROM OPERATING ACTIVITIES: |  |  |  |
| Net income | $ | 211.3 |  |  | $ | 149.6 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |
| Stock-based compensation | 130.4 |  |  | 120.3 |  |
| Amortization of deferred contract costs | 78.5 |  |  | 66.3 |  |
| Depreciation and amortization | 45.9 |  |  | 41.0 |  |
| Amortization of investment premiums, net of accretion of purchase discounts | (4.7 | ) |  | — |  |
| Other | 5.0 |  |  | (1.7 | ) |
| Changes in operating assets and liabilities: |  |  |  |
| Accounts receivable—net | 60.5 |  |  | 38.0 |  |
| Inventory | (25.2 | ) |  | (19.0 | ) |
| Prepaid expenses and other current assets | (6.3 | ) |  | 1.8 |  |
| Deferred contract costs | (113.1 | ) |  | (98.8 | ) |
| Deferred tax assets | 10.6 |  |  | (19.1 | ) |
| Other assets | (0.8 | ) |  | (3.3 | ) |
| Accounts payable | (6.2 | ) |  | (4.9 | ) |
| Accrued liabilities | (5.6 | ) |  | (2.0 | ) |
| Accrued payroll and compensation | (9.5 | ) |  | (8.6 | ) |
| Other liabilities | (1.0 | ) |  | (2.8 | ) |
| Deferred revenue | 258.8 |  |  | 209.9 |  |
| Income taxes payable | (11.0 | ) |  | (8.0 | ) |
| Net cash provided by operating activities | 617.6 |  |  | 458.7 |  |
| CASH FLOWS FROM INVESTING ACTIVITIES: |  |  |  |
| Purchases of investments | (1,072.4 | ) |  | (405.2 | ) |
| Sales of investments | 19.7 |  |  | 39.6 |  |
| Maturities of investments | 695.0 |  |  | 405.6 |  |
| Purchases of property and equipment | (45.0 | ) |  | (41.4 | ) |
| Payments made in connection with business combination, net of cash acquired | — |  |  | (6.0 | ) |
| Net cash used in investing activities | (402.7 | ) |  | (7.4 | ) |
| CASH FLOWS FROM FINANCING ACTIVITIES: |  |  |  |
| Repurchase and retirement of common stock | (117.6 | ) |  | (117.1 | ) |
| Proceeds from issuance of common stock | 41.8 |  |  | 81.6 |  |
| Taxes paid related to net share settlement of equity awards | (76.0 | ) |  | (48.0 | ) |
| Payments of debt assumed in connection with business combination | — |  |  | (9.5 | ) |
| Net cash used in financing activities | (151.8 | ) |  | (93.0 | ) |
| NET INCREASE IN CASH AND CASH EQUIVALENTS | 63.1 |  |  | 358.3 |  |
| CASH AND CASH EQUIVALENTS—Beginning of period | 1,112.4 |  |  | 811.0 |  |
| CASH AND CASH EQUIVALENTS—End of period | $ | 1,175.5 |  |  | $ | 1,169.3 |  |

[0001262039-19-000032:8k_2_02:88]
Reconciliations of non-GAAP results of operations measures to the nearest comparable GAAP measures

[0001262039-19-000032:8k_2_02:89]
(Unaudited, in millions, except per share amounts)

[0001262039-19-000032:8k_2_02:90]
Reconciliation of net cash provided by operating activities to free cash flow

[0001262039-19-000032:8k_2_02:91]
|  | Three Months Ended |
|  | September 30, 2019 |  | September 30, 2018 |
| Net cash provided by operating activities | $ | 221.2 |  |  | $ | 176.7 |  |
| Less: Purchases of property and equipment | (17.5 | ) |  | (18.2 | ) |
| Free cash flow | $ | 203.7 |  |  | $ | 158.5 |  |
| Net cash provided by (used in) investing activities | $ | (27.1 | ) |  | $ | 11.1 |  |
| Net cash provided by (used in) financing activities | $ | (40.7 | ) |  | $ | 9.4 |  |

[0001262039-19-000032:8k_2_02:92]
Reconciliation of GAAP operating income to non-GAAP operating income, operating margin, net income and diluted net income per share

[0001262039-19-000032:8k_2_02:93]
|  | Three Months Ended September 30, 2019 |  | Three Months Ended September 30, 2018 |
|  | GAAP Results |  | Adjustments |  | Non-GAAP Results |  | GAAP Results |  | Adjustments |  | Non-GAAP Results |
| Operating income | $ | 100.0 |  |  | $ | 44.6 |  | (a) | $ | 144.6 |  |  | $ | 62.8 |  |  | $ | 45.7 |  | (b) | $ | 108.5 |  |
| Operating margin | 18 | % |  |  |  | 26 | % |  | 14 | % |  |  |  | 24 | % |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | 42.4 |  |  |  |  |  |  | 43.2 |  |  |  |
| Amortization of acquired intangible assets |  |  | 2.2 |  |  |  |  |  |  | 2.5 |  |  |  |
| Operating income |  |  | 44.6 |  |  |  |  |  |  | 45.7 |  |  |  |
| (Gain) loss on investments in privately-held companies |  |  | 3.8 |  | (c) |  |  |  |  | (2.2 | ) | (d) |  |
| Tax adjustment |  |  | (11.3 | ) | (e) |  |  |  |  | (15.5 | ) | (e) |  |
| Net income | $ | 79.8 |  |  | $ | 37.1 |  |  | $ | 116.9 |  |  | $ | 58.7 |  |  | $ | 28.0 |  |  | $ | 86.7 |  |
| Diluted net income per share | $ | 0.46 |  |  |  |  | $ | 0.67 |  |  | $ | 0.33 |  |  |  |  | $ | 0.49 |  |
| Shares used in diluted net income per share calculations | 174.8 |  |  |  |  | 174.8 |  |  | 175.7 |  |  |  |  | 175.7 |  |

[0001262039-19-000032:8k_2_02:94]
(a) To exclude $42.4 million of stock-based compensation and $2.2 million of amortization of acquired intangible assets in the three months ended September 30, 2019.

[0001262039-19-000032:8k_2_02:95]
(b) To exclude $43.2 million of stock-based compensation and $2.5 million of amortization of acquired intangible assets in the three months ended September 30, 2018.

[0001262039-19-000032:8k_2_02:96]
(c) To exclude a $3.8 million impairment charge on an investment in a privately held company.

[0001262039-19-000032:8k_2_02:97]
(d) To exclude a $2.2 million gain on the sale of an investment in a privately held company.

[0001262039-19-000032:8k_2_02:98]
(e) Non-GAAP financial information is adjusted to an overall effective tax rate of 24% in 2019 and 2018, on a non-GAAP basis, which differs from the GAAP effective tax rate.

[0001262039-19-000032:8k_2_02:99]
Reconciliation of total revenue to total billings

[0001262039-19-000032:8k_2_02:100]
|  | Three Months Ended |
|  | September 30, 2019 |  | September 30, 2018 |
| Total revenue | $ | 547.5 |  |  | $ | 453.9 |  |
| Add: Change in deferred revenue | 79.1 |  |  | 73.6 |  |
| Total billings | $ | 626.6 |  |  | $ | 527.5 |  |

[0001262039-19-000032:8k_2_02:101]
| Investor Contact: |  | Media Contact: |
| Peter Salkowski |  | Sandra Wheatley |
| Fortinet, Inc. |  | Fortinet, Inc. |
| 408-331-4595 |  | 408-391-9408 |
| psalkowski@fortinet.com |  | swheatley@fortinet.com |
