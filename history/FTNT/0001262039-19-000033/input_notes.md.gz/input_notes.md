# FTNT notes — 0001262039-19-000033


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001262039-19-000033:notes:1]
[same as prior period, unchanged from 0001262039-19-000023:notes:1]

[0001262039-19-000033:notes:2]
Basis of Presentation and Preparation—The unaudited condensed consolidated financial statements of Fortinet, Inc. and its wholly owned subsidiaries (collectively, “we,” “us” or “our”) have been prepared in accordance with generally accepted accounting principles in the United States (“GAAP”) for interim financial information, as well as the instructions to Form 10-Q pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (the “SEC”). Accordingly, they do not include all of the information and footnotes required by GAAP for complete financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the year ended December 31, 2018, contained in our Annual Report on Form 10-K filed with the SEC on February 27, 2019. In the opinion of management, all adjustments, which includes normal recurring adjustments, considered necessary for a fair presentation have been included. All intercompany balances, transactions and cash flows have been eliminated. The results of operations for the three and nine months ended September 30, 2019 are not necessarily indicative of the results for the full year or for any future periods. The condensed consolidated balance sheet as of December 31, 2018 is derived from the audited consolidated financial statements for the year ended December 31, 2018.

[0001262039-19-000033:notes:3]
[same as prior period, unchanged from 0001262039-19-000023:notes:3]

[0001262039-19-000033:notes:4]
There have been no material changes to our significant accounting policies as of and for the three and nine months ended September 30, 2019, except for the accounting policies for leases that were updated as a result of adopting Accounting Standards Update (“ASU”) 2016-02—Leases (Topic 842) (“Topic 842”). For more information, refer to the “Recently Adopted Accounting Standards” and Note 10.

[0001262039-19-000033:notes:5]
Recently Adopted Accounting Standards

[0001262039-19-000033:notes:6]
[same as prior period, unchanged from 0001262039-19-000023:notes:6]

[0001262039-19-000033:notes:7]
[same as prior period, unchanged from 0001262039-19-000023:notes:7]

[0001262039-19-000033:notes:8]
Under the new guidance, we determine if an arrangement contains a lease and the classification of that lease, if applicable, at inception or upon modification of a contract. We have elected to not recognize a lease liability or ROU asset for short-term leases (leases that, at the commencement date, have a lease term of twelve months or less and do not include an option to purchase the underlying asset that the Company is reasonably certain to exercise). We have elected to not allocate the contract consideration for operating lease contracts with lease and non-lease components, and account for the lease and non-lease components as a single lease component. ROU assets represent our right to use an underlying asset for the lease term. Lease liabilities represent our obligation to make lease payments under the lease. Operating lease ROU assets and liabilities are recognized at the lease commencement date based on the present value of lease payments over the lease term. The implicit rate within our operating leases is generally not determinable and therefore we use our incremental borrowing rate at the lease commencement date to determine the present value of lease payments. The determination of our incremental borrowing rate requires judgment. We determine our incremental borrowing rate for each lease using indicative bank borrowing rates, adjusted for various factors including level of collateralization, term and currency to align with the terms of a lease. The operating lease ROU asset also includes any lease prepayments, net of lease incentives. Certain leases include options to extend or terminate the lease. An option to extend the lease is considered in connection with determining the ROU asset and lease liability when it is reasonably certain we will exercise that option. An option to terminate is considered unless it is reasonably certain we will not exercise the option.

[0001262039-19-000033:notes:9]
[same as prior period, unchanged from 0001262039-19-000023:notes:9]

[0001262039-19-000033:notes:10]
[same as prior period, unchanged from 0001262039-19-000023:notes:10]

[0001262039-19-000033:notes:11]
[same as prior period, unchanged from 0001262039-19-000023:notes:11]

[0001262039-19-000033:notes:12]
[same as prior period, unchanged from 0001262039-19-000023:notes:12]

[0001262039-19-000033:notes:13]
In February 2018, the FASB issued ASU 2018-02—Income Statement—Reporting Comprehensive Income (Topic 220): Reclassification of Certain Tax Effects from Accumulated Other Comprehensive Income, which allows companies to reclassify stranded tax effects resulting from the Tax Cuts and Jobs Act (the “2017 Tax Act”) from accumulated other comprehensive income to retained earnings. We adopted ASU 2018-02 on January 1, 2019 and elected to reclassify $0.1 million of stranded tax effects as of that date.

[0001262039-19-000033:notes:14]
[same as prior period, unchanged from 0001262039-19-000023:notes:14]

[0001262039-19-000033:notes:15]
In June 2018, the FASB issued ASU 2018-07—Compensation—Stock Compensation (Topic 718): Improvements to Nonemployee Share-Based Payment Accounting, which simplifies the accounting for share-based payments to nonemployees by aligning it with the accounting for share-based payments to employees subject to certain exceptions. ASU 2018-07 expands the scope of Accounting Standards Codification (“ASC”) Topic 718, Compensation—Stock Compensation (“ASC 718”), to include share-based payments granted to nonemployees in exchange for goods or services used or consumed in an entity’s own operations and supersedes the guidance in ASC 505, Equity, by moving it to ASC 718. We adopted ASU 2018-07 on January 1, 2019. ASU 2018-07 did not have a material impact on our condensed consolidated financial statements.

[0001262039-19-000033:notes:16]
[same as prior period, unchanged from 0001262039-19-000023:notes:16]

[0001262039-19-000033:notes:17]
[same as prior period, unchanged from 0001262039-19-000023:notes:17]

[0001262039-19-000033:notes:18]
In August 2018, the FASB issued ASU 2018-15—Intangibles-Goodwill and Other—Internal-Use Software (Subtopic 350-40): Customer’s Accounting for Implementation Costs Incurred in a Cloud Computing Arrangement That Is a Service Contract, which requires a customer in a cloud computing arrangement that is a service contract to follow the internal-use software guidance in ASC Topic 350, Intangibles—Goodwill and Other, to determine which implementation costs to capitalize as assets or expense as incurred. Companies can choose to adopt the ASU 2018-15 prospectively or retrospectively. ASU 2018-15 is effective for us beginning January 1, 2020, and early adoption is permitted. We are currently evaluating the impact of ASU 2018-15 on our condensed consolidated financial statements.

[0001262039-19-000033:notes:19]
[same as prior period, unchanged from 0001262039-19-000023:notes:19]

[0001262039-19-000033:notes:20]
In August 2018, the FASB issued ASU 2018-13—Fair Value Measurement (Topic 820): Disclosure Framework—Changes to the Disclosure Requirements for Fair Value Measurement, which eliminates, adds and modifies certain disclosure requirements for fair value measurements in ASC 820, Fair Value Measurement, as part of its disclosure framework project. ASU 2018-13 is effective for us beginning January 1, 2020. The amendments in ASU 2018-13 that relate to changes in unrealized gains and losses, the range and weighted average of significant unobservable inputs used to develop Level 3 fair value measurements and the narrative description of measurement uncertainty should be applied prospectively for only the most recent interim or annual period presented in the initial fiscal year of adoption. All other amendments in ASU 2018-13 should be applied retrospectively to all periods presented upon their effective date. Early adoption is permitted upon issuance of ASU 2018-13. An entity is permitted to early adopt any removed or modified disclosures upon issuance of ASU 2018-13 and delay adoption of the additional disclosures until their effective date. We are currently assessing the impact the new guidance will have on our disclosures.

[0001262039-19-000033:notes:21]
[same as prior period, unchanged from 0001262039-19-000023:notes:21]

[0001262039-19-000033:notes:22]
In June 2016, the FASB issued ASU 2016-13—Financial Instruments—Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments and in November 2018, the FASB issued ASU 2018-19—Codification Improvements to Topic 326, Financial Instruments—Credit Losses, as a subsequent amendment to the initial guidance (collectively, Topic 326). In April 2019, the FASB issued ASU 2019-04—Codification Improvements to Topic 326: Financial Instruments—Credit Losses, Topic 815, Derivatives and Hedging, and Topic 825, Financial Instruments, and in May 2019, the FASB issued ASU 2019-05—Financial Instruments—Credit Losses (Topic 326): Targeted Transition Relief. Topic 326 requires a financial asset (or a group of financial assets) measured at an amortized cost basis to be presented at the net amount expected to be collected. The new approach to estimating credit losses (referred to as the current expected credit losses model) generally accelerates recognition of credit losses. We are in the process of determining the changes needed to our valuation model for trade receivables, and we are reviewing our process to identify credit-related losses on available-for-sale investments. We also expect the new guidance to expand our related financial statement disclosures. The new guidance is effective for us beginning on January 1, 2020, and early adoption is permitted. We are currently assessing the impact of the new guidance on our condensed consolidated financial statements.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001262039-19-000033:notes:23]
[same as prior period, unchanged from 0001262039-19-000023:notes:23]

[0001262039-19-000033:notes:24]
[same as prior period, unchanged from 0001262039-19-000023:notes:24]

[0001262039-19-000033:notes:25]
[same as prior period, unchanged from 0001262039-19-000023:notes:25]

[0001262039-19-000033:notes:26]
[same as prior period, unchanged from 0001262039-19-000023:notes:26]

[0001262039-19-000033:notes:27]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30, 2019 |  | September 30, 2018 |  | September 30, 2019 |  | September 30, 2018 |
| Product | $ | 197.1 |  |  | $ | 164.5 |  |  | $ | 549.7 |  |  | $ | 473.6 |  |
| Service: |  |  |  |  |  |  |  |
| Security subscription | 192.8 |  |  | 157.0 |  |  | 545.5 |  |  | 440.7 |  |
| Technical support and other | 157.6 |  |  | 132.4 |  |  | 446.6 |  |  | 379.9 |  |
| Total service revenue | 350.4 |  |  | 289.4 |  |  | 992.1 |  |  | 820.6 |  |
| Total revenue | $ | 547.5 |  |  | $ | 453.9 |  |  | $ | 1,541.8 |  |  | $ | 1,294.2 |  |

[0001262039-19-000033:notes:28]
[same as prior period, unchanged from 0001262039-19-000023:notes:28]

[0001262039-19-000033:notes:29]
During the three months ended September 30, 2019 and September 30, 2018, we recognized $211.6 million and $173.0 million in revenue that was included in the deferred revenue balance as of December 31, 2018 and December 31, 2017, respectively. During the nine months ended September 30, 2019 and September 30, 2018, we recognized $752.2 million and $615.3 million in revenue that was included in the deferred revenue balance as of December 31, 2018 and December 31, 2017, respectively.

[0001262039-19-000033:notes:30]
[same as prior period, unchanged from 0001262039-19-000023:notes:30]

[0001262039-19-000033:notes:31]
As of September 30, 2019, the aggregate amount of the transaction price allocated to remaining performance obligations was $1.95 billion, which was substantially comprised of deferred security subscription and technical support services revenue. We expect to recognize approximately $1.06 billion as revenue over the next 12 months and the remainder thereafter.

[0001262039-19-000033:notes:32]
[same as prior period, unchanged from 0001262039-19-000023:notes:32]

[0001262039-19-000033:notes:33]
Trade accounts receivable are recorded at the invoiced amount. Trade accounts receivable are reduced by an allowance for doubtful accounts which is determined based on our assessment of the collectability of customer accounts. The allowance for doubtful accounts was $0.8 million and $0.9 million as of September 30, 2019 and December 31, 2018, respectively.

[0001262039-19-000033:notes:34]
[same as prior period, unchanged from 0001262039-19-000023:notes:34]

[0001262039-19-000033:notes:35]
Sales commissions earned by our sales force are considered incremental and recoverable costs of obtaining a contract with a customer. The amortization of deferred contract costs is included in sales and marketing expense in our condensed consolidated statements of income. Amortization of deferred contract costs during the three months ended September 30, 2019 and September 30, 2018 were $27.5 million and $23.2 million, respectively.  Amortization of deferred contract costs during the nine months ended September 30, 2019 and September 30, 2018 were $78.5 million and $66.3 million, respectively.


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0001262039-19-000033:notes:36]
[same as prior period, unchanged from 0001262039-19-000023:notes:36]

[0001262039-19-000033:notes:37]
[same as prior period, unchanged from 0001262039-19-000023:notes:37]

[0001262039-19-000033:notes:38]
|  | September 30, 2019 |
|  | AmortizedCost |  | UnrealizedGains |  | UnrealizedLosses |  | FairValue |
| Corporate debt securities | $ | 541.5 |  |  | $ | 1.2 |  |  | $ | (0.2 | ) |  | $ | 542.5 |  |
| Commercial paper | 132.8 |  |  | 0.1 |  |  | — |  |  | 132.9 |  |
| U.S. government and agency securities | 221.3 |  |  | 0.3 |  |  | — |  |  | 221.6 |  |
| Certificates of deposit and term deposits (1) | 72.0 |  |  | — |  |  | — |  |  | 72.0 |  |
| Total available-for-sale securities | $ | 967.6 |  |  | $ | 1.6 |  |  | $ | (0.2 | ) |  | $ | 969.0 |  |
|  | December 31, 2018 |
|  | AmortizedCost |  | UnrealizedGains |  | UnrealizedLosses |  | FairValue |
| Corporate debt securities | $ | 299.5 |  |  | $ | — |  |  | $ | (1.2 | ) |  | $ | 298.3 |  |
| Commercial paper | 102.5 |  |  | — |  |  | — |  |  | 102.5 |  |
| Certificates of deposit and term deposits (1) | 145.8 |  |  | — |  |  | — |  |  | 145.8 |  |
| U.S. government and agency securities | 57.7 |  |  | — |  |  | (0.1 | ) |  | 57.6 |  |
| Total available-for-sale securities | $ | 605.5 |  |  | $ | — |  |  | $ | (1.3 | ) |  | $ | 604.2 |  |
| (1) The majority of our certificates of deposit and term deposits are foreign deposits. |

[0001262039-19-000033:notes:39]
[same as prior period, unchanged from 0001262039-19-000023:notes:39]

[0001262039-19-000033:notes:40]
|  | September 30, 2019 |
|  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
|  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |
| Corporate debt securities | $ | 67.3 |  |  | $ | (0.1 | ) |  | $ | 35.9 |  |  | $ | (0.1 | ) |  | $ | 103.2 |  |  | $ | (0.2 | ) |

[0001262039-19-000033:notes:41]
[same as prior period, unchanged from 0001262039-19-000023:notes:41]

[0001262039-19-000033:notes:42]
[same as prior period, unchanged from 0001262039-19-000023:notes:42]

[0001262039-19-000033:notes:43]
|  | September 30, 2019 |  | December 31, 2018 |
| Due within one year | $ | 764.8 |  |  | $ | 537.2 |  |
| Due within one to three years | 204.2 |  |  | 67.0 |  |
| Total | $ | 969.0 |  |  | $ | 604.2 |  |

[0001262039-19-000033:notes:44]
Available-for-sale securities are reported at fair value, with unrealized gains and losses and the related tax impact included as a separate component of stockholders’ equity and in comprehensive income. Realized gains and losses on available-for-sale securities were insignificant in the periods presented and are included in other income (expense)—net in our condensed consolidated statements of income. We use the specific identification method to determine the cost basis of investments sold.

[0001262039-19-000033:notes:45]
The unrealized losses on our available-for-sale securities were caused by fluctuations in market value and interest rates as a result of the economic environment. We consider these investments to be temporarily impaired as of September 30, 2019 because (i) the decline in market value was attributable to changes in market conditions and not credit quality, and (ii) we have concluded currently that neither do we intend to sell nor is it more likely than not that we will be required to sell these investments prior to recovery of their amortized cost basis.

[0001262039-19-000033:notes:46]
[same as prior period, unchanged from 0001262039-19-000023:notes:46]

[0001262039-19-000033:notes:47]
[same as prior period, unchanged from 0001262039-19-000023:notes:47]

[0001262039-19-000033:notes:48]
[same as prior period, unchanged from 0001262039-19-000023:notes:48]

[0001262039-19-000033:notes:49]
[same as prior period, unchanged from 0001262039-19-000023:notes:49]

[0001262039-19-000033:notes:50]
[same as prior period, unchanged from 0001262039-19-000023:notes:50]

[0001262039-19-000033:notes:51]
[same as prior period, unchanged from 0001262039-19-000023:notes:51]

[0001262039-19-000033:notes:52]
[same as prior period, unchanged from 0001262039-19-000023:notes:52]

[0001262039-19-000033:notes:53]
[same as prior period, unchanged from 0001262039-19-000023:notes:53]

[0001262039-19-000033:notes:54]
[same as prior period, unchanged from 0001262039-19-000023:notes:54]

[0001262039-19-000033:notes:55]
The following tables present the fair value of our financial assets measured at fair value on a recurring basis as of September 30, 2019 and December 31, 2018 (in millions):

[0001262039-19-000033:notes:56]
|  | September 30, 2019 |  | December 31, 2018 |
|  | AggregateFairValue |  | QuotedPrices inActiveMarkets ForIdenticalAssets |  | SignificantOtherObservableRemainingInputs |  | SignificantOtherUnobservableRemainingInputs |  | AggregateFairValue |  | QuotedPrices inActiveMarkets ForIdenticalAssets |  | SignificantOtherObservableRemainingInputs |  | SignificantOtherUnobservableRemainingInputs |
|  |  |  | (Level 1) |  | (Level 2) |  | (Level 3) |  |  |  | (Level 1) |  | (Level 2) |  | (Level 3) |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate debt securities | $ | 542.5 |  |  | $ | — |  |  | $ | 542.5 |  |  | $ | — |  |  | $ | 299.3 |  |  | $ | — |  |  | $ | 299.3 |  |  | $ | — |  |
| Commercial paper | 144.1 |  |  | — |  |  | 144.1 |  |  | — |  |  | 184.7 |  |  | — |  |  | 184.7 |  |  | — |  |
| Certificates of deposit and term deposits | 72.0 |  |  | — |  |  | 72.0 |  |  | — |  |  | 217.4 |  |  | — |  |  | 217.4 |  |  | — |  |
| U.S. government and agency securities | 221.6 |  |  | 221.6 |  |  | — |  |  | — |  |  | 57.6 |  |  | 45.3 |  |  | 12.3 |  |  | — |  |
| Money market funds | 34.2 |  |  | 34.2 |  |  | — |  |  | — |  |  | 58.6 |  |  | 58.6 |  |  | — |  |  | — |  |
| Total | $ | 1,014.4 |  |  | $ | 255.8 |  |  | $ | 758.6 |  |  | $ | — |  |  | $ | 817.6 |  |  | $ | 103.9 |  |  | $ | 713.7 |  |  | $ | — |  |
| Reported as: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents | $ | 45.4 |  |  |  |  |  |  |  |  | $ | 213.4 |  |  |  |  |  |  |  |
| Short-term investments | 764.8 |  |  |  |  |  |  |  |  | 537.2 |  |  |  |  |  |  |  |
| Long-term investments | 204.2 |  |  |  |  |  |  |  |  | 67.0 |  |  |  |  |  |  |  |
| Total | $ | 1,014.4 |  |  |  |  |  |  |  |  | $ | 817.6 |  |  |  |  |  |  |  |

[0001262039-19-000033:notes:57]
There were no transfers between Level 1 and Level 2 of the fair value hierarchy during the nine months ended September 30, 2019 and year ended December 31, 2018.


## us-gaap:InventoryDisclosureTextBlock

[0001262039-19-000033:notes:58]
[same as prior period, unchanged from 0001262039-19-000023:notes:58]

[0001262039-19-000033:notes:59]
[same as prior period, unchanged from 0001262039-19-000023:notes:59]

[0001262039-19-000033:notes:60]
|  | September 30, 2019 |  | December 31, 2018 |
| Raw materials | $ | 7.7 |  |  | $ | 13.3 |  |
| Finished goods | 91.5 |  |  | 76.7 |  |
| Inventory | $ | 99.2 |  |  | $ | 90.0 |  |


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001262039-19-000033:notes:61]
[same as prior period, unchanged from 0001262039-19-000023:notes:61]

[0001262039-19-000033:notes:62]
[same as prior period, unchanged from 0001262039-19-000023:notes:62]

[0001262039-19-000033:notes:63]
|  | September 30, 2019 |  | December 31, 2018 |
| Land | $ | 75.7 |  |  | $ | 75.7 |  |
| Building and building improvements | 143.6 |  |  | 144.2 |  |
| Computer equipment and software | 113.6 |  |  | 95.9 |  |
| Leasehold improvements | 20.1 |  |  | 17.9 |  |
| Evaluation units | 20.5 |  |  | 20.5 |  |
| Furniture and fixtures | 16.7 |  |  | 15.7 |  |
| Construction-in-progress | 44.4 |  |  | 12.3 |  |
| Total property and equipment | 434.6 |  |  | 382.2 |  |
| Less: accumulated depreciation | (129.1 | ) |  | (110.8 | ) |
| Property and equipment—net | $ | 305.5 |  |  | $ | 271.4 |  |

[0001262039-19-000033:notes:64]
Depreciation expense was $12.8 million and $11.8 million during the three months ended September 30, 2019 and September 30, 2018, respectively. Depreciation expense was $37.8 million and $34.9 million during the nine months ended September 30, 2019 and September 30, 2018, respectively.


## us-gaap:InvestmentTextBlock

[0001262039-19-000033:notes:65]
INVESTMENTS IN PRIVATELY HELD COMPANIES

[0001262039-19-000033:notes:66]
Our investments in the equity securities of privately held companies totaled $5.3 million and $9.1 million as of September 30, 2019 and December 31, 2018, respectively. These investments are accounted for at cost, adjusted for changes in observable prices minus impairment. We own less than 20% of the voting securities in each of these investments and do not have the ability to exercise significant influence over operating and financial policies of the respective entities. These investments are recorded as other assets in our condensed consolidated balance sheets and would be measured at fair value if indicators of an increase in value or impairment existed. During the three months ended September 30, 2019, we determined that one of our investments was other-than-temporarily impaired. As a result, we recognized a non-cash impairment charge of $3.8 million to Other income (expense)—net in our condensed consolidated statements of income. During the three months ended September 30, 2018, we sold equity securities of a privately held company for $5.2 million and recognized a gain of $2.2 million to Other income (expense)—net in our condensed consolidated statements of income.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001262039-19-000033:notes:67]
[same as prior period, unchanged from 0001262039-19-000023:notes:67]

[0001262039-19-000033:notes:68]
[same as prior period, unchanged from 0001262039-19-000023:notes:68]

[0001262039-19-000033:notes:69]
[same as prior period, unchanged from 0001262039-19-000023:notes:69]

[0001262039-19-000033:notes:70]
Under the business combination method of accounting in accordance with ASC Topic 805, Business Combinations (“ASC 805”), the total purchase price was allocated to ZoneFox’s identifiable tangible and intangible assets acquired and liabilities assumed based on their estimated fair values using management’s best estimates and assumptions to assign fair value as of the acquisition date. The purchase price for ZoneFox was $16.1 million, of which $12.5 million was allocated to goodwill that was non-deductible for tax purposes, and $6.8 million was allocated to identifiable intangible assets, the majority of which was developed technology offset by $3.2 million of net liabilities assumed. Acquisition-related costs related to the ZoneFox acquisition were not material. Goodwill recorded in connection with this acquisition represents the value we expect to be created through expansion into markets within our existing business, and potential cost savings and synergies.

[0001262039-19-000033:notes:71]
We may pay an additional $2.0 million in cash consideration as an earn-out that is subject in full to satisfaction of certain performance conditions. As of September 30, 2019, no fair value was assigned to the contingent consideration based on the estimated probability of attainment of the performance conditions.

[0001262039-19-000033:notes:72]
[same as prior period, unchanged from 0001262039-19-000023:notes:72]

[0001262039-19-000033:notes:73]
[same as prior period, unchanged from 0001262039-19-000023:notes:73]

[0001262039-19-000033:notes:74]
Under the business combination method of accounting in accordance with ASC 805, the total purchase price was allocated to Bradford’s identifiable tangible and intangible assets acquired and liabilities assumed based on their estimated fair values using management's best estimates and assumptions to assign fair value as of the acquisition date. The purchase price for Bradford was $6.8 million, of which $11.1 million was allocated to goodwill that was non-deductible for tax purposes, and $8.0 million was allocated to identifiable intangible assets, the majority of which was developed technology offset by $12.3 million of net liabilities assumed. Acquisition-related costs related to the Bradford acquisition were not material. Goodwill recorded in connection with this acquisition represents the value we expect to be created through expansion into markets within our existing business, and potential cost savings and synergies.

[0001262039-19-000033:notes:75]
[same as prior period, unchanged from 0001262039-19-000023:notes:75]

[0001262039-19-000033:notes:76]
[same as prior period, unchanged from 0001262039-19-000023:notes:76]


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001262039-19-000033:notes:77]
[same as prior period, unchanged from 0001262039-19-000023:notes:77]

[0001262039-19-000033:notes:78]
[same as prior period, unchanged from 0001262039-19-000023:notes:78]

[0001262039-19-000033:notes:79]
As of September 30, 2019 and December 31, 2018, we had goodwill of $38.2 million. There were no impairments to goodwill during the nine months ended September 30, 2019 or during prior periods.

[0001262039-19-000033:notes:80]
[same as prior period, unchanged from 0001262039-19-000023:notes:80]

[0001262039-19-000033:notes:81]
The following tables present other intangible assets—net as of September 30, 2019 and December 31, 2018 (in millions, except years):

[0001262039-19-000033:notes:82]
|  | September 30, 2019 |
|  | Weighted-Average Useful Life (in Years) |  | Gross |  | Accumulated Amortization |  | Net |
| Other intangible assets—net: |  |  |  |  |  |  |  |
| Finite-lived intangible assets: |  |  |  |  |  |  |  |
| Developed technologies | 4.0 |  | $ | 34.4 |  |  | $ | 22.7 |  |  | $ | 11.7 |  |
| Customer relationships | 4.4 |  | 17.5 |  |  | 15.2 |  |  | 2.3 |  |
| Total other intangible assets—net |  |  | $ | 51.9 |  |  | $ | 37.9 |  |  | $ | 14.0 |  |

[0001262039-19-000033:notes:83]
[same as prior period, unchanged from 0001262039-19-000023:notes:83]

[0001262039-19-000033:notes:84]
Amortization expense was $2.2 million and $2.5 million during the three months ended September 30, 2019 and September 30, 2018, respectively. Amortization expense was $8.1 million and $6.1 million during the nine months ended September 30, 2019 and September 30, 2018, respectively.

[0001262039-19-000033:notes:85]
[same as prior period, unchanged from 0001262039-19-000023:notes:85]

[0001262039-19-000033:notes:86]
|  | Amount |
| Years: |  |
| 2019 (the remainder of 2019) | $ | 2.2 |  |
| 2020 | 6.2 |  |
| 2021 | 3.5 |  |
| 2022 | 2.1 |  |
| Total | $ | 14.0 |  |


## us-gaap:EarningsPerShareTextBlock

[0001262039-19-000033:notes:87]
[same as prior period, unchanged from 0001262039-19-000023:notes:87]

[0001262039-19-000033:notes:88]
[same as prior period, unchanged from 0001262039-19-000023:notes:88]

[0001262039-19-000033:notes:89]
[same as prior period, unchanged from 0001262039-19-000023:notes:89]

[0001262039-19-000033:notes:90]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30, 2019 |  | September 30, 2018 |  | September 30, 2019 |  | September 30, 2018 |
| Numerator: |  |  |  |  |  |  |  |
| Net income | $ | 79.8 |  |  | $ | 58.7 |  |  | $ | 211.3 |  |  | $ | 149.6 |  |
| Denominator: |  |  |  |  |  |  |  |
| Basic shares: |  |  |  |  |  |  |  |
| Weighted-average common stock outstanding-basic | 171.3 |  |  | 169.8 |  |  | 170.9 |  |  | 168.7 |  |
| Diluted shares: |  |  |  |  |  |  |  |
| Weighted-average common stock outstanding-basic | 171.3 |  |  | 169.8 |  |  | 170.9 |  |  | 168.7 |  |
| Effect of potentially dilutive securities: |  |  |  |  |  |  |  |
| RSUs | 2.4 |  |  | 4.2 |  |  | 2.9 |  |  | 3.5 |  |
| Stock options | 1.1 |  |  | 1.6 |  |  | 1.1 |  |  | 1.4 |  |
| ESPP | — |  |  | 0.1 |  |  | — |  |  | 0.1 |  |
| Weighted-average shares used to compute diluted net income per share | 174.8 |  |  | 175.7 |  |  | 174.9 |  |  | 173.7 |  |
| Net income per share: |  |  |  |  |  |  |  |
| Basic | $ | 0.47 |  |  | $ | 0.35 |  |  | $ | 1.24 |  |  | $ | 0.89 |  |
| Diluted | $ | 0.46 |  |  | $ | 0.33 |  |  | $ | 1.21 |  |  | $ | 0.86 |  |

[0001262039-19-000033:notes:91]
[same as prior period, unchanged from 0001262039-19-000023:notes:91]

[0001262039-19-000033:notes:92]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30, 2019 |  | September 30, 2018 |  | September 30, 2019 |  | September 30, 2018 |
| RSUs | 0.2 |  |  | 0.3 |  |  | 0.3 |  |  | 0.6 |  |
| Stock options | 0.7 |  |  | — |  |  | 0.6 |  |  | 0.4 |  |
| ESPP | — |  |  | 0.2 |  |  | — |  |  | 0.1 |  |
| Total | 0.9 |  |  | 0.5 |  |  | 0.9 |  |  | 1.1 |  |


## us-gaap:LesseeOperatingLeasesTextBlock

[0001262039-19-000033:notes:93]
[same as prior period, unchanged from 0001262039-19-000023:notes:93]

[0001262039-19-000033:notes:94]
We have operating leases for offices, research and development facilities and data centers. Our leases have remaining terms that range from less than one year to approximately seven years, some of which include one or more options to renew, with renewal terms of up to five years. We do not include renewal options in our lease terms for calculating our lease liability, as the renewal options allow us to maintain operational flexibility and we are not reasonably certain we will exercise these renewal options at the time of the lease commencement. Our finance leases are not material to our financial statements.

[0001262039-19-000033:notes:95]
[same as prior period, unchanged from 0001262039-19-000023:notes:95]

[0001262039-19-000033:notes:96]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30, 2019 |  | September 30, 2019 |
| Operating lease expense | $ | 3.8 |  |  | $ | 11.1 |  |
| Variable lease expense (1) | 0.7 |  |  | 1.9 |  |
| Short-term lease expense | 0.8 |  |  | 2.2 |  |
| Total lease expense | $ | 5.3 |  |  | $ | 15.2 |  |

[0001262039-19-000033:notes:97]
(1) Variable lease expense for the three and nine months ended September 30, 2019 predominantly included common area maintenance charges and parking expense.

[0001262039-19-000033:notes:98]
Rent expense was $4.4 million and $13.1 million during the three and nine months ended September 30, 2018, respectively. Rent expense was recognized in accordance with ASC 840, Leases, using the straight-line method over the term of a lease.

[0001262039-19-000033:notes:99]
[same as prior period, unchanged from 0001262039-19-000023:notes:99]

[0001262039-19-000033:notes:100]
|  | Classification | September 30, 2019 |
| Operating lease ROU assets - non-current | Other assets | $ | 41.0 |  |
| Operating lease liabilities - current | Accrued liabilities | $ | 13.9 |  |
| Operating lease liabilities - non-current | Other liabilities | 27.7 |  |
| Total operating lease liabilities |  | $ | 41.6 |  |
| Weighted average remaining lease term in years - operating leases |  | 3.9 |  |
| Weighted average discount rate - operating leases |  | 3.0 | % |

[0001262039-19-000033:notes:101]
[same as prior period, unchanged from 0001262039-19-000023:notes:101]

[0001262039-19-000033:notes:102]
|  | Nine Months Ended |
|  | September 30, 2019 |
| Cash paid for amounts included in the measurement of lease liabilities |  |
| Operating cash flows used for operating leases | $ | 11.9 |  |
| Lease liabilities arising from obtaining right-of-use assets |  |
| Operating leases | $ | 12.6 |  |

[0001262039-19-000033:notes:103]
Maturities of operating lease liabilities as of September 30, 2019 were as follows (in millions):

[0001262039-19-000033:notes:104]
| Year ending December 31, | Amount |
| 2019 (the remainder of 2019) | $ | 3.5 |  |
| 2020 | 14.6 |  |
| 2021 | 10.6 |  |
| 2022 | 6.2 |  |
| 2023 | 4.5 |  |
| Thereafter | 4.9 |  |
| Total lease payments | $ | 44.3 |  |
| Less imputed interest | (2.7 | ) |
| Total | $ | 41.6 |  |

[0001262039-19-000033:notes:105]
As of September 30, 2019, we had additional minimum lease payments of $1.7 million relating to operating leases that had been signed but had not yet commenced and therefore were excluded from the table above. These leases will commence during 2019 and will have lease terms of approximately two to five years.

[0001262039-19-000033:notes:106]
[same as prior period, unchanged from 0001262039-19-000023:notes:106]

[0001262039-19-000033:notes:107]
[same as prior period, unchanged from 0001262039-19-000023:notes:107]

[0001262039-19-000033:notes:108]
Total future principal contractual obligations for operating lease commitments as of December 31, 2018 exceeded our undiscounted lease liability as of the Topic 842 adoption date, primarily because the lease liability excluded short-term lease payments (due to the adoption of the short-term lease exemption) and excluded minimum lease payments relating to an operating lease that had been signed but had not yet commenced.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001262039-19-000033:notes:109]
COMMITMENTS AND CONTINGENCIES

[0001262039-19-000033:notes:110]
The following table summarizes our future principal contractual obligations as of September 30, 2019 (in millions):

[0001262039-19-000033:notes:111]
|  | Total |  | 2019 |  | 2020 |  | 2021 |  | 2022 |  | 2023 |  | Thereafter |
| Inventory purchase commitments | $ | 241.4 |  |  | $ | 144.5 |  |  | $ | 96.9 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |

[0001262039-19-000033:notes:112]
Inventory Purchase Commitments—Our independent contract manufacturers procure components and build our products based on our forecasts. These forecasts are based on estimates of future demand for our products, which are in turn based on historical trends and an analysis from our sales and marketing organizations, adjusted for overall market conditions. In order to reduce manufacturing lead times and plan for adequate component supply, we may issue purchase orders to some of our independent contract manufacturers which may not be cancelable. As of September 30, 2019, we had $241.4 million of open purchase orders with our independent contract manufacturers that may not be cancelable.

[0001262039-19-000033:notes:113]
Other Contractual Commitments and Open Purchase Orders—In addition to commitments with contract manufacturers, we have open purchase orders and contractual obligations in the ordinary course of business for which we have not received goods or services. As of September 30, 2019, we had $12.6 million in other contractual commitments having a remaining term in excess of one year that may not be cancelable.

[0001262039-19-000033:notes:114]
Litigation—We are involved in disputes, litigation, and other legal actions. For lawsuits where we are the defendant, we are in the process of defending these litigation matters, and while there can be no assurances and the outcome of certain of these matters is currently not determinable and not predictable, we currently are unaware of any existing claims or proceedings that we believe are likely to have a material adverse effect on our financial position. There are many uncertainties associated with any litigation and these actions or other third-party claims against us may cause us to incur costly litigation fees, costs and substantial settlement charges, and possibly subject us to damages and other penalties. In addition, the resolution of any intellectual property litigation may require us to make royalty payments, which could adversely affect our gross margins in future periods. If any of those events were to occur, our business, financial condition, results of operations, and cash flows could be adversely affected. Litigation is unpredictable and the actual liability in any such matters may be materially different from our current estimates, which could result in the need to adjust any accrued liability and record additional expenses. We accrue for contingencies when we believe that a loss is probable and that we can reasonably estimate the amount of any such loss.

[0001262039-19-000033:notes:115]
Indemnification and Other Matters—Under the indemnification provisions of our standard sales contracts, we agree to defend our customers against third-party claims asserting various allegations such as product defects and infringement of certain intellectual property rights, which may include patents, copyrights, trademarks or trade secrets, and to pay judgments entered on such claims. In some contracts, our exposure under these indemnification provisions is limited by the terms of the contracts to certain defined limits, such as the total amount paid by our customer under the agreement. However, certain agreements include covenants, penalties and indemnification provisions including and beyond indemnification for third-party claims of intellectual property infringement, that could potentially expose us to losses in excess of the amount received under the agreement, and in some instances to potential liability that is not contractually limited. To date, although from time to time there are indemnification claims asserted against us and currently there are pending indemnification claims, there have been no material awards under such indemnification provisions.

[0001262039-19-000033:notes:116]
Periodically we, like other security companies and companies in other industries, may experience cybersecurity threats, malicious activity directed against our information technology infrastructure and unauthorized attempts to gain access to our and our customers’ sensitive information and systems. For example, as previously disclosed, in the second quarter of 2019, we discovered that an unauthorized party illegally targeted us using sophisticated techniques, such as stealing technical data in order to both impersonate our firewall update servers and possibly attempt other attack methodologies, in an effort to try to gain access to certain of our customers’ systems. We have substantially completed our investigation of this incident and we do not currently believe that it had a material impact on our business, including our customers. We are currently not aware of any claims arising from this matter.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001262039-19-000033:notes:117]
[same as prior period, unchanged from 0001262039-19-000023:notes:118]

[0001262039-19-000033:notes:118]
[same as prior period, unchanged from 0001262039-19-000023:notes:119]

[0001262039-19-000033:notes:119]
[same as prior period, unchanged from 0001262039-19-000023:notes:120]

[0001262039-19-000033:notes:120]
[same as prior period, unchanged from 0001262039-19-000023:notes:121]

[0001262039-19-000033:notes:121]
As of September 30, 2019, there was a total of 13.6 million shares of common stock available for grant under the Amended Plan.

[0001262039-19-000033:notes:122]
[same as prior period, unchanged from 0001262039-19-000023:notes:123]

[0001262039-19-000033:notes:123]
[same as prior period, unchanged from 0001262039-19-000023:notes:124]

[0001262039-19-000033:notes:124]
|  | Restricted Stock Units Outstanding |
|  | Number of Shares |  | Weighted-Average Grant Date Fair Value per Share |
| Balance—December 31, 2018 | 7.8 |  |  | $ | 46.07 |  |
| Granted | 2.2 |  |  | 83.76 |  |
| Forfeited | (0.5 | ) |  | 53.69 |  |
| Vested | (3.0 | ) |  | 43.13 |  |
| Balance—September 30, 2019 | 6.5 |  |  | $ | 59.36 |  |

[0001262039-19-000033:notes:125]
As of September 30, 2019, total compensation expense related to unvested RSUs granted to employees and non-employees under the 2009 Plan, but not yet recognized, was $338.5 million. This expense is expected to be amortized on a straight-line basis over a weighted-average vesting period of 2.7 years.

[0001262039-19-000033:notes:126]
[same as prior period, unchanged from 0001262039-19-000023:notes:127]

[0001262039-19-000033:notes:127]
[same as prior period, unchanged from 0001262039-19-000023:notes:128]

[0001262039-19-000033:notes:128]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30, 2019 |  | September 30, 2018 |  | September 30, 2019 |  | September 30, 2018 |
| Shares withheld for taxes | 0.2 |  |  | 0.2 |  |  | 0.9 |  |  | 0.9 |  |
| Amount withheld for taxes | $ | 19.6 |  |  | $ | 15.5 |  |  | $ | 76.1 |  |  | $ | 48.0 |  |

[0001262039-19-000033:notes:129]
[same as prior period, unchanged from 0001262039-19-000023:notes:130]

[0001262039-19-000033:notes:130]
[same as prior period, unchanged from 0001262039-19-000023:notes:131]

[0001262039-19-000033:notes:131]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30, 2019 |  | September 30, 2018 |  | September 30, 2019 |  | September 30, 2018 |
| Expected term in years | 4.4 |  |  | 4.4 |  |  | 4.4 |  |  | 4.4 |  |
| Volatility | 35.3 | % |  | 30.5 | % |  | 34.2 | % |  | 31.6 | % |
| Risk-free interest rate | 1.4 | % |  | 2.7 | % |  | 2.4 | % |  | 2.7 | % |
| Dividend rate | — | % |  | — | % |  | — | % |  | — | % |

[0001262039-19-000033:notes:132]
[same as prior period, unchanged from 0001262039-19-000023:notes:133]

[0001262039-19-000033:notes:133]
|  | Options Outstanding |
|  | Numberof Shares |  | Weighted-AverageExercisePrice |  | Weighted-AverageRemainingContractualLife (Years) |  | AggregateIntrinsicValue |
| Balance—December 31, 2018 | 3.0 |  |  | $ | 35.53 |  |  |  |  |  |  |
| Granted | 0.7 |  |  | 84.19 |  |  |  |  |  |
| Forfeited | (0.1 | ) |  | 62.68 |  |  |  |  |  |
| Exercised | (0.7 | ) |  | 29.23 |  |  |  |  |  |
| Balance—September 30, 2019 | 2.9 |  |  | $ | 48.46 |  |  |  |  |  |
| Options vested and expected to vest—September 30, 2019 | 2.9 |  |  | $ | 48.46 |  |  | 4.6 |  | $ | 86.5 |  |
| Options exercisable—September 30, 2019 | 1.5 |  |  | $ | 33.64 |  |  | 3.5 |  | $ | 62.6 |  |

[0001262039-19-000033:notes:134]
The aggregate intrinsic value represents the difference between the exercise price of stock options and the quoted market price of our common stock on September 30, 2019 for all in-the-money stock options. As of September 30, 2019, total compensation expense related to unvested stock options granted to employees but not yet recognized was $26.0 million. This expense is expected to be amortized on a straight-line basis over a weighted-average period of 2.9 years.

[0001262039-19-000033:notes:135]
[same as prior period, unchanged from 0001262039-19-000023:notes:136]

[0001262039-19-000033:notes:136]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30, 2019 |  | September 30, 2018 |  | September 30, 2019 |  | September 30, 2018 |
| Weighted-average fair value per share granted | $ | 24.97 |  |  | $ | 22.75 |  |  | $ | 26.96 |  |  | $ | 15.67 |  |
| Intrinsic value of options exercised | 3.2 |  |  | 14.1 |  |  | 40.1 |  |  | 53.6 |  |
| Fair value of options vested | 2.0 |  |  | 1.4 |  |  | 8.2 |  |  | 5.7 |  |

[0001262039-19-000033:notes:137]
[same as prior period, unchanged from 0001262039-19-000023:notes:138]

[0001262039-19-000033:notes:138]
[same as prior period, unchanged from 0001262039-19-000023:notes:139]

[0001262039-19-000033:notes:139]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30, 2019 |  | September 30, 2018 |  | September 30, 2019 |  | September 30, 2018 |
| Cost of product revenue | $ | 0.4 |  |  | $ | 0.3 |  |  | $ | 1.2 |  |  | $ | 1.1 |  |
| Cost of service revenue | 2.7 |  |  | 2.8 |  |  | 8.4 |  |  | 8.0 |  |
| Research and development | 9.3 |  |  | 9.3 |  |  | 28.7 |  |  | 26.9 |  |
| Sales and marketing | 24.9 |  |  | 26.0 |  |  | 76.6 |  |  | 70.5 |  |
| General and administrative | 5.1 |  |  | 4.8 |  |  | 15.5 |  |  | 13.8 |  |
| Total stock-based compensation expense | $ | 42.4 |  |  | $ | 43.2 |  |  | $ | 130.4 |  |  | $ | 120.3 |  |

[0001262039-19-000033:notes:140]
[same as prior period, unchanged from 0001262039-19-000023:notes:141]

[0001262039-19-000033:notes:141]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30, 2019 |  | September 30, 2018 |  | September 30, 2019 |  | September 30, 2018 |
| RSUs | $ | 39.5 |  |  | $ | 38.2 |  |  | $ | 120.6 |  |  | $ | 106.1 |  |
| Stock options | 2.9 |  |  | 2.4 |  |  | 8.5 |  |  | 6.7 |  |
| ESPP | — |  |  | 2.6 |  |  | 1.3 |  |  | 7.5 |  |
| Total stock-based compensation expense | $ | 42.4 |  |  | $ | 43.2 |  |  | $ | 130.4 |  |  | $ | 120.3 |  |

[0001262039-19-000033:notes:142]
[same as prior period, unchanged from 0001262039-19-000023:notes:143]

[0001262039-19-000033:notes:143]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30, 2019 |  | September 30, 2018 |  | September 30, 2019 |  | September 30, 2018 |
| Income tax benefit associated with stock-based compensation | $ | 9.8 |  |  | $ | 6.8 |  |  | $ | 30.1 |  |  | $ | 19.0 |  |

[0001262039-19-000033:notes:144]
[same as prior period, unchanged from 0001262039-19-000023:notes:145]

[0001262039-19-000033:notes:145]
[same as prior period, unchanged from 0001262039-19-000023:notes:146]

[0001262039-19-000033:notes:146]
During the three and nine months ended September 30, 2019, we repurchased 0.3 million and 1.6 million shares of common stock, respectively, under the Repurchase Program in open market transactions at an average price of $78.67 per share and $73.94 per share, respectively, for an aggregate purchase price of $26.5 million and $117.4 million, respectively. As of September 30, 2019, $616.3 million remained available for future share repurchases under the Repurchase Program.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001262039-19-000033:notes:147]
[same as prior period, unchanged from 0001262039-19-000023:notes:148]

[0001262039-19-000033:notes:148]
Our effective tax rate was 24% for the three months ended September 30, 2019, compared to an effective tax rate of 17% for the same period last year. Our effective tax rate was 16% for the nine months ended September 30, 2019, compared to an effective tax rate of 6% for the same period last year. The effective tax rates for the periods presented are primarily comprised of U.S. federal and state taxes, withholding taxes, foreign taxes and excess tax benefits from stock-based compensation expense. The tax rates for the three months ended September 30, 2019 and September 30, 2018 were impacted by U.S. federal and state taxes, withholding taxes and foreign taxes of $29.6 million and $17.7 million, respectively, which

[0001262039-19-000033:notes:149]
were offset by excess tax benefits from stock-based compensation expense of $6.9 million and $5.8 million, respectively. The tax rate for the three months ended September 30, 2019 was impacted by a net increase in tax expense of $2.9 million due to the settlement of foreign tax audits.

[0001262039-19-000033:notes:150]
The tax rates for the nine months ended September 30, 2019 and September 30, 2018 were impacted by U.S. federal and state taxes, withholding taxes and foreign taxes of $71.6 million and $43.4 million, respectively, which were offset by excess tax benefits from stock-based compensation expense of $34.6 million and $16.2 million, respectively. The provision for income taxes for the nine months ended September 30, 2019 included an increase in tax expense of $10.3 million for an unrecognized tax benefit related to the Ninth Circuit’s opinion in Altera Corporation and Subsidiaries vs. Commissioner of Internal Revenue (“Altera”) described below, regarding stock-based compensation expense in cost sharing arrangements. The provision for income taxes for the nine months ended September 30, 2019 included a net increase in tax expense of $2.9 million due to the settlement of foreign tax audits. The net increase was offset due to the release of $10.0 million of reserves related to uncertain tax positions and interest due to the expiration of the statute of limitations. The tax rate for the nine months ended September 30, 2018 was also impacted by release of a reserve on uncertain tax position including interest of $18.0 million.

[0001262039-19-000033:notes:151]
As of September 30, 2019 and December 31, 2018, unrecognized tax benefits were $67.7 million and $63.5 million, respectively. If recognized, $62.7 million of the unrecognized tax benefits would favorably affect our effective tax rate. It is our policy to include accrued interest and penalties related to uncertain tax benefits in income tax expense. As of September 30, 2019 and December 31, 2018, accrued interest and penalties were $13.8 million and $11.6 million, respectively. It is reasonably possible that our gross unrecognized tax benefits will decrease by up to $7.1 million in the next 12 months, due to the lapse of the statute of limitations. This decrease, if recognized, would positively impact our effective tax rate, and would be recognized as additional tax benefits.

[0001262039-19-000033:notes:152]
We file income tax returns in the U.S. federal jurisdiction and in various U.S. state and foreign jurisdictions. Generally, we are no longer subject to U.S. state and foreign income tax examinations by tax authorities for tax years prior to 2010. We are no longer subject to examination by U.S federal income tax authorities for tax years prior to 2015. We currently have ongoing tax audits in the United Kingdom, Italy, Canada and several other foreign jurisdictions. The focus of these audits is the inter-company profit allocation.

[0001262039-19-000033:notes:153]
On June 7, 2019, the Ninth Circuit overturned the U.S. Tax Court’s decision on Altera and ruled in favor of the Commissioner, validating the regulations requiring stock-based compensation to be included in a cost sharing arrangement. Due to the uncertainty surrounding the status of the current regulations and questions related to the scope of potential benefits or obligations, we incurred an unrecognized tax benefit of $10.3 million related to the Ninth Circuit’s Altera decision regarding stock-based compensation in cost sharing arrangements. We continue to monitor developments in this case and any impact it could have on our tax provision.


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0001262039-19-000033:notes:154]
[same as prior period, unchanged from 0001262039-19-000023:notes:155]

[0001262039-19-000033:notes:155]
Our tax-deferred savings plan under our 401(k) Plan permits participating U.S. employees to contribute a portion of their pre-tax or after-tax earnings. In Canada, we have a Group Registered Retirement Savings Plan Program (the “RRSP”), which permits participants to make tax deductible contributions. Our board of directors approved 50% matching contributions on employee contributions up to 4% of each employee’s eligible earnings. Our matching contributions to our 401(k) Plan and the RRSP for the three months ended September 30, 2019 and September 30, 2018 were $1.8 million and $1.4 million, respectively. Our matching contributions to our 401(k) Plan and the RRSP for the nine months ended September 30, 2019 and September 30, 2018 were $5.2 million and $4.4 million, respectively.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001262039-19-000033:notes:156]
[same as prior period, unchanged from 0001262039-19-000023:notes:157]

[0001262039-19-000033:notes:157]
[same as prior period, unchanged from 0001262039-19-000023:notes:158]

[0001262039-19-000033:notes:158]
[same as prior period, unchanged from 0001262039-19-000023:notes:159]

[0001262039-19-000033:notes:159]
|  | Three Months Ended |  | Nine Months Ended |
| Revenue | September 30, 2019 |  | September 30, 2018 |  | September 30, 2019 |  | September 30, 2018 |
| Americas: |  |  |  |  |  |  |  |
| United States | $ | 182.1 |  |  | $ | 146.8 |  |  | $ | 505.9 |  |  | $ | 425.3 |  |
| Other Americas (1) | 58.6 |  |  | 47.2 |  |  | 160.8 |  |  | 133.8 |  |
| Total Americas | 240.7 |  |  | 194.0 |  |  | 666.7 |  |  | 559.1 |  |
| Europe, Middle East and Africa (“EMEA”) | 200.7 |  |  | 165.4 |  |  | 569.9 |  |  | 474.3 |  |
| Asia Pacific (“APAC”) | 106.1 |  |  | 94.5 |  |  | 305.2 |  |  | 260.8 |  |
| Total revenue | $ | 547.5 |  |  | $ | 453.9 |  |  | $ | 1,541.8 |  |  | $ | 1,294.2 |  |
| (1) In 2019, Canada and Latin America revenue were combined and presented as Other Americas. Prior periods have been reclassified to conform with current period presentation. |

[0001262039-19-000033:notes:160]
| Property and Equipment—net | September 30, 2019 |  | December 31, 2018 |
| Americas: |  |  |  |
| United States | $ | 162.7 |  |  | $ | 132.1 |  |
| Canada | 117.1 |  |  | 113.5 |  |
| Latin America | 0.5 |  |  | 0.4 |  |
| Total Americas | 280.3 |  |  | 246.0 |  |
| EMEA (1) | 16.6 |  |  | 16.2 |  |
| APAC | 8.6 |  |  | 9.2 |  |
| Total property and equipment—net | $ | 305.5 |  |  | $ | 271.4 |  |
| (1) In 2019, France and Other EMEA property and equipment were combined and presented as EMEA. Prior periods have been reclassified to conform with current period presentation. |

[0001262039-19-000033:notes:161]
The following distributors accounted for 10% or more of our revenue:

[0001262039-19-000033:notes:162]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30, 2019 |  | September 30, 2018 |  | September 30, 2019 |  | September 30, 2018 |
| Exclusive Networks Group | 30 | % |  | 29 | % |  | 31 | % |  | 29 | % |
| Ingram Micro | 11 | % |  | 11 | % |  | 11 | % |  | 10 | % |

[0001262039-19-000033:notes:163]
The following distributors accounted for 10% or more of net accounts receivable:

[0001262039-19-000033:notes:164]
|  | September 30, 2019 |  | December 31, 2018 |
| Exclusive Networks Group | 32 | % |  | 38 | % |
| Ingram Micro | 11 | % |  | * |  |
| * Represents less than 10% |


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001262039-19-000033:notes:165]
[same as prior period, unchanged from 0001262039-19-000023:notes:166]

[0001262039-19-000033:notes:166]
[same as prior period, unchanged from 0001262039-19-000023:notes:167]

[0001262039-19-000033:notes:167]
|  | Unrealized Gains (Losses) on Investments |  | Tax provision (benefit) related to unrealized gains or losses on investments |  | Total |
| Balance—December 31, 2018 | $ | (1.3 | ) |  | $ | (0.5 | ) |  | $ | (0.8 | ) |
| Other comprehensive income before reclassifications | 2.7 |  |  | 0.7 |  |  | 2.0 |  |
| Amounts reclassified from accumulated other comprehensive loss | — |  |  | 0.1 |  |  | (0.1 | ) |
| Net current-period other comprehensive income | 2.7 |  |  | 0.8 |  |  | 1.9 |  |
| Balance—September 30, 2019 | $ | 1.4 |  |  | $ | 0.3 |  |  | $ | 1.1 |  |

[0001262039-19-000033:notes:168]
We adopted ASU 2018-02 on January 1, 2019, and elected to reclassify the income tax effects of the 2017 Tax Act to retained earnings at the beginning of the period. Other amounts reclassified from accumulated other comprehensive loss for unrealized losses on investments and tax provision related to unrealized gains or losses on investments are recorded in other income (expense)—net and in provision for (benefit from) income taxes, respectively.


## us-gaap:SubsequentEventsTextBlock

[0001262039-19-000033:notes:169]
SUBSEQUENT EVENTS

[0001262039-19-000033:notes:170]
Business combination

[0001262039-19-000033:notes:171]
On October 28, 2019, we acquired enSilo Ltd. (“enSilo”), a privately held company that provides endpoint detection and response products and services. We acquired enSilo for approximately $20.0 million in initial consideration, subject to certain adjustments.

[0001262039-19-000033:notes:172]
We are currently in the process of evaluating the business combination accounting, including the consideration transferred and the initial purchase price allocation.

[0001262039-19-000033:notes:173]
Share repurchase

[0001262039-19-000033:notes:174]
Subsequent to September 30, 2019 through the filing of this Quarterly Report on Form 10-Q, we repurchased 0.3 million shares of our common stock, for an aggregate purchase price of $23.5 million at an average price of $77.39 per share, under the Repurchase Program.
