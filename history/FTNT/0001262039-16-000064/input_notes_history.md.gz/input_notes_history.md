# FTNT note change history — 0001262039-15-000048 → 0001262039-16-000064


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2016-05-06):
[0001262039-16-000064:note_history:1]
The following table summarizes our future principal contractual obligations as of March 31, 2016 (in thousands):
  (was, 2015-11-09, similarity 0.9541):
[0001262039-15-000048:note_history:1]
The following table summarizes our future principal contractual obligations as of September 30, 2015 (in thousands):

- changed (2016-05-06):
[0001262039-16-000064:note_history:2]
|  | Total |  | 2016 (remainder) |  | 2017 |  | 2018 |  | 2019 |  | 2020 |  | Thereafter |
| Operating lease commitments | $ | 60,677 |  |  | $ | 13,411 |  |  | $ | 12,897 |  |  | $ | 11,036 |  |  | $ | 8,734 |  |  | $ | 5,945 |  |  | $ | 8,654 |  |
| Inventory purchase commitments | 77,530 |  |  | 77,530 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Other contractual commitments and open purchase orders | 49,048 |  |  | 41,207 |  |  | 3,461 |  |  | 1,590 |  |  | 930 |  |  | 930 |  |  | 930 |  |
| Total | $ | 187,255 |  |  | $ | 132,148 |  |  | $ | 16,358 |  |  | $ | 12,626 |  |  | $ | 9,664 |  |  | $ | 6,875 |  |  | $ | 9,584 |  |
  (was, 2015-11-09, similarity 0.9979):
[0001262039-15-000048:note_history:2]
|  | Total |  | 2015 (remainder) |  | 2016 |  | 2017 |  | 2018 |  | 2019 |  | Thereafter |
| Operating lease commitments | $ | 56,775 |  |  | $ | 4,167 |  |  | $ | 15,679 |  |  | $ | 10,879 |  |  | $ | 8,404 |  |  | $ | 7,053 |  |  | $ | 10,593 |  |
| Inventory purchase commitments | 75,984 |  |  | 73,038 |  |  | 2,946 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Other contractual commitments and open purchase orders | 38,072 |  |  | 26,233 |  |  | 7,995 |  |  | 2,149 |  |  | 751 |  |  | 609 |  |  | 335 |  |
| Total | $ | 170,831 |  |  | $ | 103,438 |  |  | $ | 26,620 |  |  | $ | 13,028 |  |  | $ | 9,155 |  |  | $ | 7,662 |  |  | $ | 10,928 |  |

- changed (2016-05-06):
[0001262039-16-000064:note_history:3]
Operating Leases—We lease certain facilities under various non-cancelable operating leases, which expire through 2026. Certain leases require us to pay variable costs such as taxes, maintenance, and insurance. The terms of certain operating leases also provide for renewal options and escalation clauses. Rent expense was $4.6 million and $3.1 million during the three months ended March 31, 2016 and March 31, 2015, respectively. Rent expense is recognized using the straight-line method over the term of the lease.
  (was, 2015-11-09, similarity 0.7983):
[0001262039-15-000048:note_history:3]
Operating Leases—We lease certain facilities under various non-cancelable operating leases, which expire through 2025. In addition to the amounts above, certain leases require us to pay variable costs such as taxes, maintenance, insurance, and asset retirement obligations. The terms of certain operating leases also provide for renewal options and escalation clauses. Rent expense was $3.7 million and $2.6 million during the three months ended September 30, 2015 and 2014, respectively. Rent expense was $9.7 million and $7.7 million during the nine months ended September 30, 2015 and 2014, respectively. Rent expense is recognized using the straight-line method over the term of the lease.

- changed (2016-05-06):
[0001262039-16-000064:note_history:4]
Inventory Purchase Commitments—Our independent contract manufacturers procure components and build our products based on our forecasts. These forecasts are based on estimates of future demand for our products, which are in turn based on historical trends and an analysis from our sales and marketing organizations, adjusted for overall market conditions. In order to reduce manufacturing lead times and plan for adequate component supply, we may issue purchase orders to some of our independent contract manufacturers which may not be cancelable. As of March 31, 2016, we had $77.5 million of open purchase orders with our independent contract manufacturers that may not be cancelable.
  (was, 2015-11-09, similarity 0.9012):
[0001262039-15-000048:note_history:4]
Inventory Purchase —Our independent contract manufacturers procure certain inventory items and build our products based on our forecasts. These forecasts are based on estimates of future demand for our products, which are in turn based on historical trends and analysis, adjusted for overall market conditions. In order to reduce manufacturing lead times and plan for adequate component supply, we may issue purchase orders to some of our independent contract manufacturers which may not be cancelable. As of September 30, 2015, we had $76.0 million of open purchase orders with our independent contract manufacturers.

- added (2016-05-06):
[0001262039-16-000064:note_history:5]
Other Contractual Commitments and Open Purchase Orders—In addition to commitments with contract manufacturers, we have open purchase orders and contractual obligations in the ordinary course of business for which we have not received goods or services. As of March 31, 2016, we had $49.0 million in other contractual commitments that may not be cancelable.

- added (2016-05-06):
[0001262039-16-000064:note_history:6]
|  | Three Months Ended |
|  | March 31, 2016 |  | March 31, 2015 |
| Accrued warranty balance—beginning of the period | $ | 3,144 |  |  | $ | 4,269 |  |
| Warranty costs incurred | (511 | ) |  | (1,095 | ) |
| Provision for warranty for the period | 377 |  |  | 945 |  |
| Adjustment related to pre-existing warranties | (353 | ) |  | 222 |  |
| Accrued warranty balance—end of the period | $ | 2,657 |  |  | $ | 4,341 |  |

- added (2016-05-06):
[0001262039-16-000064:note_history:7]
Litigation—We are involved in disputes, litigation, and other legal actions. For lawsuits where we are the defendant, we are in the process of defending these litigation matters, and while there can be no assurances and the outcome of these matters is currently not determinable, we currently believe that there are no existing claims or proceedings that are likely to have a material adverse effect on our financial position. There are many uncertainties associated with any litigation and these actions or other third-party claims against us may cause us to incur costly litigation fees, including contingent legal fees with related parties, costs and substantial settlement charges, and possibly subject us to damages and other penalties. In addition, the resolution of any intellectual property litigation may require us to make royalty payments, which could adversely affect our gross margins in future periods. If any of those events were to occur, our business, financial condition, results of operations, and cash flows could be adversely affected. The actual liability in any such matters may be materially different from our estimates, if any, which could result in the need to adjust the liability and record additional expenses. We have not recorded any significant accrual for loss contingencies associated with such legal proceedings; determined that a significant unfavorable outcome is probable or reasonably possible; or determined that the amount or range of any possible loss is reasonably estimable.

- changed (2016-05-06):
[0001262039-16-000064:note_history:8]
Indemnification—Under the indemnification provisions of our standard sales contracts, we agree to defend our customers against third-party claims asserting various allegations such as product defects and infringement of certain intellectual property rights, which may include patents, copyrights, trademarks or trade secrets, and to pay judgments entered on such claims. In some contracts, our exposure under these indemnification provisions is limited by the terms of the contracts to certain defined limits, such as the total amount paid by our customer under the agreement. However, certain agreements include covenants, penalties and indemnification provisions including and beyond indemnification for third-party claims of intellectual property infringement and that could potentially expose us to losses in excess of the amount received under the agreement, and in some instances to potential liability that is not contractually limited. To date, there have been no awards under such indemnification provisions.
  (was, 2015-11-09, similarity 0.966):
[0001262039-15-000048:note_history:8]
Indemnification—Under the indemnification provisions of our standard sales contracts, we agree to defend our customers against third-party claims asserting various allegations such as damage resulting from product defects and infringement of certain intellectual property rights, which may include patents, copyrights, trademarks, or trade secrets, and to pay judgments entered on such claims. In some contracts, our exposure under these indemnification provisions is limited by the terms of the contracts to certain defined limits, such as the total amount paid by our customer under the agreement. However, certain agreements include covenants, penalties and indemnification provisions including and beyond indemnification for third-party claims of intellectual property infringement and that could potentially expose us to losses in excess of the amount received under the agreement and, in some instances, to potential liability that is not contractually limited. To date, there have been no awards under such indemnification provisions.

- removed (2016-05-06):
[0001262039-15-000048:note_history:9]
Other Contractual Commitments and Open Purchase Orders —In addition to commitments with contract manufacturers, we have other contractual commitments and open purchase orders in the ordinary course of business for which we have not received goods or services. As of September 30, 2015, we had $38.1 million in other contractual commitments and open purchase orders.

- removed (2016-05-06):
[0001262039-15-000048:note_history:10]
|  | Nine Months Ended |
|  | September 30, 2015 |  | September 30, 2014 |
| Accrued warranty balance—beginning of the period | $ | 4,269 |  |  | $ | 3,037 |  |
| Warranty costs incurred | (3,413 | ) |  | (2,597 | ) |
| Provision for warranty for the period, including warranty liabilities assumed in connection with a business acquisition | 3,638 |  |  | 3,786 |  |
| Adjustment related to pre-existing warranties | (94 | ) |  | (540 | ) |
| Accrued warranty balance—end of the period | $ | 4,400 |  |  | $ | 3,686 |  |

- removed (2016-05-06):
[0001262039-15-000048:note_history:11]
Litigation—We are involved in disputes, litigation, and other legal actions. For lawsuits where we are the defendant, we are in the process of defending these litigation matters, and while there can be no assurances and the outcome of these matters is currently not determinable, we currently believe that there are no existing claims or proceedings that are likely to have a material adverse effect on our financial position. There are many uncertainties associated with any litigation and these actions or other third-party claims against us may cause us to incur costly litigation or substantial settlement charges. In addition, the resolution of any intellectual property litigation may require us to make royalty payments, which could adversely affect our gross margins in future periods. If any of those events were to occur, our business, financial condition, results of operations, and cash flows could be adversely affected. The actual liability in any such matters may be materially different from our estimates, if any, which could result in the need to adjust the liability and record additional expenses. We have not recorded any significant accrual for loss contingencies associated with such legal proceedings; determined that a significant unfavorable outcome is probable or reasonably possible; or determined that the amount or range of any possible loss is reasonably estimable.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2016-05-06):
[0001262039-16-000064:note_history:12]
Basis of Presentation and Preparation—The unaudited condensed consolidated financial statements of Fortinet, Inc. and its wholly-owned subsidiaries (collectively, “we,” “us” or “our”) have been prepared in accordance with generally accepted accounting principles in the United States (“GAAP”) for interim financial information, as well as the instructions to Form 10-Q pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (“SEC”). Accordingly, they do not include all of the information and footnotes required by GAAP for complete financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the year ended December 31, 2015, contained in our Annual Report on Form 10-K (the “Form 10-K”) filed with the SEC on February 26, 2016. In the opinion of management, all adjustments, which includes normal recurring adjustments, considered necessary for a fair presentation have been included. All intercompany balances, transactions and cash flows have been eliminated. The results of operations for the three months ended March 31, 2016 are not necessarily indicative of the results for the full year or for any future periods. The condensed consolidated balance sheet as of December 31, 2015 is derived from the audited consolidated financial statements for the year ended December 31, 2015.

- added (2016-05-06):
[0001262039-16-000064:note_history:13]
There have been no material changes to our significant accounting policies as of and for the three months ended March 31, 2016.

- added (2016-05-06):
[0001262039-16-000064:note_history:14]
Recently Adopted Accounting Standards

- changed (2016-05-06):
[0001262039-16-000064:note_history:15]
In September 2015, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) 2015-16—Business Combinations—Simplifying the Accounting for Measurement-Period Adjustments, which eliminates the requirement for an acquirer in a business combination to account for measurement-period adjustments retrospectively. Instead, acquirers must recognize measurement-period adjustments during the period in which they determine the amounts, including the effect on earnings of any amounts they would have recorded in previous periods if the accounting had been completed at the acquisition date. We adopted ASU 2015-16 on January 1, 2016. The adoption of ASU 2015-16 did not have any impact on our consolidated financial statements.
  (was, 2015-11-09, similarity 0.711):
[0001262039-15-000048:note_history:15]
In September 2015, the Financial Accounting Standards Board (“FASB“) issued Accounting Standards Update 2015-16—Simplifying the Accounting for Measurement-Period Adjustments (“ASU 2015-16”).  ASU 2015-16 eliminates the requirement for an acquirer in a business combination to account for measurement-period adjustments retrospectively.  Instead, acquirers must recognize measurement-period adjustments during the period in which they determine the amounts, including the effect on earnings of any amounts they would have recorded in previous periods if the accounting had been completed at the acquisition date.  ASU 2015-16 will be effective for us beginning on January 1, 2016.

- added (2016-05-06):
[0001262039-16-000064:note_history:16]
In April 2015, the FASB issued ASU 2015-05—Intangibles—Goodwill and Other—Internal—Use Software— Customer’s Accounting for Fees Paid in a Cloud Computing Arrangement, which provides guidance on determining whether a cloud computing arrangement contains a software license. If a cloud computing arrangement includes a software license, then the customer should account for the software license element of the arrangement consistent with the acquisition of other software licenses. If a cloud computing arrangement does not include a software license, the customer should account for the arrangement as a service contract. We adopted ASU 2015-05 on a prospective basis beginning on January 1, 2016. The impact of ASU 2015-05 did not have a significant impact on our consolidated financial statements.

- added (2016-05-06):
[0001262039-16-000064:note_history:17]
In February 2015, the FASB issued ASU 2015-02—Consolidation—Amendments to the Consolidation Analysis, which updates the accounting guidance on consolidation requirements. This update changes the guidance with respect to the analysis that a reporting entity must perform to determine whether it should consolidate certain types of legal entities. ASU 2015-02 also makes several modifications to the consolidation guidance for variable interest entities (“VIEs”). We adopted ASU 2015-02 on January 1, 2016. The adoption of ASU 2015-02 did not have any impact on our consolidated financial statements.

- added (2016-05-06):
[0001262039-16-000064:note_history:18]
Recent Accounting Standards Not Yet Effective

- added (2016-05-06):
[0001262039-16-000064:note_history:19]
In March 2016, the FASB issued ASU 2016-09—Compensation—Stock Compensation—Improvements to Employee Share-Based Payment Accounting, which changes certain aspects of accounting for shared-based payments to employees. The new guidance will require all income tax effects of awards to be recognized in the income statement for the period in which the awards vest or are settled. It also allows an employer to repurchase more of an employee’s shares for tax withholding purposes without triggering liability accounting and to make a policy election to account for forfeitures as they occur. This new guidance will be effective for us beginning on January 1, 2017, and interim periods within those fiscal years. Early adoption is permitted in any annual or interim period for which financial statements have not been issued or made available for issuance, but all of the guidance must be adopted in the same period. We are currently evaluating the impact ASU 2016-09 will have on our consolidated financial statements.

- added (2016-05-06):
[0001262039-16-000064:note_history:20]
In February 2016, the FASB issued ASU 2016-02—Leases, which amends lease accounting requirements to begin recording assets and liabilities arising from leases on the balance sheet. The new guidance will also require significant additional disclosures about the amount, timing and uncertainty of cash flows from leases. This new guidance will be effective for us beginning on January 1, 2019 using a modified retrospective approach. The modified retrospective approach includes a number of optional practical expedients that entities may elect to apply. We are currently evaluating the impact ASU 2016-02 will have on our consolidated financial statements.

- added (2016-05-06):
[0001262039-16-000064:note_history:21]
In January 2016, the FASB issued ASU 2016-01—Financial Instruments—Overall—Recognition and Measurement of Financial Assets and Financial Liabilities, which modifies how entities measure equity investments and present changes in the fair value of financial liabilities. Under the new guidance, entities will have to measure equity investments that do not result in consolidation and are not accounted under the equity method at fair value and recognize any changes in fair value in net income unless the investments qualify for the new practicality exception. The practicality exception will apply to those equity investments that do not have a readily determinable fair value and do not qualify for the practical expedient to estimate fair value, and as such these investments may be measured at cost. ASU 2016-01 will be effective for us beginning on January 1, 2018. We do not expect the impact of ASU 2016-01 on our consolidated financial statements to be significant.

- changed (2016-05-06):
[0001262039-16-000064:note_history:22]
In July 2015, the FASB issued ASU 2015-11—Inventory—Simplifying the Measurement of Inventory, which changes the measurement principle for inventory from the lower of cost or market to lower of cost and net realizable value. ASU 2015-11 applies to entities that measure inventory using a method other than last-in, first-out or the retail inventory method (e.g., first-in, first-out or average cost). ASU 2015-11 will be effective for us beginning on January 1, 2017. We do not expect the impact of ASU 2015-11 on our consolidated financial statements to be significant.
  (was, 2015-11-09, similarity 0.766):
[0001262039-15-000048:note_history:22]
In July 2015, the FASB issued Accounting Standards Update 2015-11—Inventory—Simplifying the Measurement of Inventory (Topic 330) (“ASU 2015-11”). ASU 2015-11 changes the measurement principle for inventory from the lower of cost or market to lower of cost and net realizable value. It applies to entities that measure inventory using a method other than last-in, first-out or the retail inventory method (e.g., first-in first-out, average cost). ASU 2015-11 will be effective for us beginning on January 1, 2017. We do not expect the impact of ASU 2015-11 on our consolidated financial statements to be significant.

- added (2016-05-06):
[0001262039-16-000064:note_history:23]
In May 2014, the FASB issued ASU 2014-09—Revenue from Contracts with Customers, which creates a single, joint revenue standard that is consistent across all industries and markets for companies that prepare their financial statements in accordance with GAAP. Under ASU 2014-09, an entity is required to recognize revenue upon the transfer of promised goods or services to customers in an amount that reflects the consideration the entity expects to be entitled to receive in exchange for those goods or services. In July 2015, the FASB decided to delay the effective date of the new revenue standard by one year. In March 2016, the FASB issued ASU 2016-08, which clarifies the implementation guidance on principal versus agent considerations. In April 2016, the FASB issued ASU 2016-10, which clarifies the implementation guidance on identifying performance obligations and licensing. These standards will be effective for us beginning on January 1, 2018, with the option to adopt earlier on January 1, 2017. We are currently evaluating the impact of these new standards on our consolidated financial statements.

- removed (2016-05-06):
[0001262039-15-000048:note_history:24]
Basis of Presentation and Preparation—The unaudited condensed consolidated financial statements of Fortinet, Inc. and its wholly-owned subsidiaries (collectively, “we,” “us” or “our”) have been prepared in accordance with generally accepted accounting principles in the United States (“GAAP”) for interim financial information as well as the instructions to Form 10-Q pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (“SEC”). Accordingly, they do not include all of the information and footnotes required by GAAP for complete financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the year ended December 31, 2014, contained in our Annual Report on Form 10-K (“Form 10-K”) filed with the SEC on March 2, 2015. In the opinion of management, all adjustments, which includes normal recurring adjustments, considered necessary for a fair presentation have been included. All intercompany balances, transactions and cash flows have been eliminated. The results of operations for the three and nine months ended September 30, 2015 are not necessarily indicative of the results for the full year or for any future periods. The condensed consolidated balance sheet as of December 31, 2014 is derived from the audited consolidated financial statements for the year ended December 31, 2014.

- removed (2016-05-06):
[0001262039-15-000048:note_history:25]
In the third quarter of 2014, we reevaluated the selected functional currency of our international subsidiaries due to the nature of our business operations and recorded the cumulative impact of the reevaluation of the functional currency in the consolidated statement of operations. Subsequently, the remeasurement of the assets and liabilities of all international subsidiaries has been recorded in the consolidated statement of operations prospectively. The impact of this reevaluation was not material for 2014 or any of our previously issued financial statements.

- removed (2016-05-06):
[0001262039-15-000048:note_history:26]
There have been no material changes to our significant accounting policies as of and for the three and nine months ended September 30, 2015, except for the inclusion of policies related to business combinations and restructuring charges.

- removed (2016-05-06):
[0001262039-15-000048:note_history:27]
Business combinations—We include the results of operations of the businesses that we acquire as of the respective dates of acquisition. We allocate the fair value of the purchase price of our business acquisitions to the tangible assets acquired, liabilities assumed, and intangible assets acquired, based on their estimated fair values. The excess of the purchase price over the fair values of these identifiable assets and liabilities is recorded as goodwill. Additional information existing as of the acquisition date but unknown to us may become known during the remainder of the measurement period, not to exceed 12 months from the acquisition date, which may result in changes to the amounts and allocations recorded.

- removed (2016-05-06):
[0001262039-15-000048:note_history:28]
Restructuring charges—We recognize liability for exit and disposal activities when the liability is incurred. Our restructuring charges consist of one-time termination benefits related to the reduction of our workforce, contract-termination costs, such as lease exit costs, and other costs. Liabilities for costs associated with a restructuring activity are measured at fair value and are recognized when the liability is incurred. One-time termination benefits are expensed at the date we notify the employee, unless the employee must provide future service, in which case the benefits are expensed ratably over the future service period. A liability for contract-termination costs represents a liability for costs to terminate a contract before the end of its term and is recognized at fair value when we terminate the contract in accordance with the contract terms, which is usually done by giving written notice to the counterparty within the notification period specified by the contract or by otherwise negotiating a termination with the counterparty. A liability for costs that will continue to be incurred under a contract for its remaining term without economic benefit to the entity is recognized at the cease-use date. Costs to terminate a lease before the end of its term are recognized when the property is vacated. Other costs primarily consist of asset write-offs and consulting fees, which are expensed when incurred.

- removed (2016-05-06):
[0001262039-15-000048:note_history:29]
We continually evaluate the adequacy of the remaining liabilities under our restructuring initiatives. Although we believe that these estimates accurately reflect the costs of our restructuring plans, actual results may differ and thereby require us to record an additional provision or reverse a portion of such a provision.

- removed (2016-05-06):
[0001262039-15-000048:note_history:30]
Recent Accounting Pronouncements

- removed (2016-05-06):
[0001262039-15-000048:note_history:31]
In May 2014, the FASB issued Accounting Standards Update No. 2014-09—Revenue from Contracts with Customers (Topic 606) (“ASU 2014-09”) to create a single, joint revenue standard that is consistent across all industries and markets for companies that prepare their financial statements in accordance with GAAP. Under ASU 2014-09, an entity is required to recognize revenue upon the transfer of promised goods or services to customers in an amount that reflects the consideration the entity expects to be entitled to receive in exchange for those goods or services. In July 2015, the FASB decided to delay the effective date of the new revenue standard by one year. As such, ASU 2014-09 will be effective for us beginning on January 1, 2018, with the option to adopt earlier on January 1, 2017. We are currently evaluating the impact of ASU 2014-09 on our consolidated financial statements.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2016-05-06):
[0001262039-16-000064:note_history:32]
The son of one member of our board of directors is a partner of an outside law firm that we utilize for certain complex litigation matters. Expenses for legal services provided by the law firm related to matters that arose subsequent to the member joining our board of directors were $0.3 million and $1.9 million in the three months ended March 31, 2016 and March 31, 2015, respectively. Of such amounts, $0.2 million and $0.5 million were incurred under contingent fee arrangements in the three months ended March 31, 2016 and March 31, 2015, respectively. Amounts due and payable to the law firm were $0.4 million and $5.3 million as of March 31, 2016 and December 31, 2015, respectively.
  (was, 2015-11-09, similarity 0.6501):
[0001262039-15-000048:note_history:32]
The son of one member of our Board of Directors (“Board”) is a partner in an outside law firm that we utilize for certain complex litigation matters. Expenses for legal services provided by the law firm related to matters that arose subsequent to the member joining our Board were $0.9 million each for the three months ended September 30, 2015 and September 30, 2014, respectively. Expenses for legal services provided by the law firm related to matters that arose subsequent to the member joining our Board were $3.7 million and $1.7 million for the nine months ended September 30, 2015 and September 30, 2014, respectively. Amounts due and payable to the law firm were $1.4 million and $1.3 million as of September 30, 2015 and December 31, 2014, respectively.
