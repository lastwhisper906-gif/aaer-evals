# FTNT MD&A — 0001262039-16-000064


## mdna

[0001262039-16-000064:mdna:1]
[same as prior period, unchanged from 0001262039-15-000048:mdna:1]

[0001262039-16-000064:mdna:2]
[same as prior period, unchanged from 0001262039-15-000048:mdna:2]

[0001262039-16-000064:mdna:3]
[same as prior period, unchanged from 0001262039-15-000048:mdna:3]

[0001262039-16-000064:mdna:4]
[same as prior period, unchanged from 0001262039-15-000048:mdna:4]

[0001262039-16-000064:mdna:5]
| • | the proportion of our revenue that consists of our product and service and other revenue, and the mix of billings between products and services; |

[0001262039-16-000064:mdna:6]
[same as prior period, unchanged from 0001262039-15-000048:mdna:6]

[0001262039-16-000064:mdna:7]
| • | drivers of long-term growth and operating leverage, such as increased functionality and value in our security subscription and support service offerings; |

[0001262039-16-000064:mdna:8]
| • | growing our sales to enterprise, service provider and government organizations, and the impact of sales to these organizations on our long-term growth, expansion, and operating results; |

[0001262039-16-000064:mdna:9]
[same as prior period, unchanged from 0001262039-15-000048:mdna:8]

[0001262039-16-000064:mdna:10]
[same as prior period, unchanged from 0001262039-15-000048:mdna:9]

[0001262039-16-000064:mdna:11]
[same as prior period, unchanged from 0001262039-15-000048:mdna:10]

[0001262039-16-000064:mdna:12]
[same as prior period, unchanged from 0001262039-15-000048:mdna:11]

[0001262039-16-000064:mdna:13]
[same as prior period, unchanged from 0001262039-15-000048:mdna:12]

[0001262039-16-000064:mdna:14]
[same as prior period, unchanged from 0001262039-15-000048:mdna:13]

[0001262039-16-000064:mdna:15]
[same as prior period, unchanged from 0001262039-15-000048:mdna:14]

[0001262039-16-000064:mdna:16]
[same as prior period, unchanged from 0001262039-15-000048:mdna:15]

[0001262039-16-000064:mdna:17]
[same as prior period, unchanged from 0001262039-15-000048:mdna:16]

[0001262039-16-000064:mdna:18]
[same as prior period, unchanged from 0001262039-15-000048:mdna:17]

[0001262039-16-000064:mdna:19]
[same as prior period, unchanged from 0001262039-15-000048:mdna:18]

[0001262039-16-000064:mdna:20]
[same as prior period, unchanged from 0001262039-15-000048:mdna:19]

[0001262039-16-000064:mdna:21]
We provide high performance cybersecurity solutions to a wide variety of enterprises, service providers and government organizations of all sizes across the globe, including a majority of the 2015 Fortune 100. Our cybersecurity solutions are designed to provide broad, rapid protection against dynamic security threats while simplifying the IT infrastructure of our end-customers worldwide.

[0001262039-16-000064:mdna:22]
Our common operating system, centralized management and open application program interfaces allow many of the solutions in our portfolio to be combined to create an integrated security architecture (“Fortinet Security Fabric”) designed to address sophisticated threats and next-generation environments. The Fortinet Security Fabric connects our products, services and ecosystem partner solutions to provide seamless protection at all points in the network, from endpoint to data center to cloud, regardless of whether deployed in physical, virtual or hybrid environments. Our Security Fabric delivers integrated scalability, access, awareness, security and openness both from the cloud and for the cloud.  At the core of our Security Fabric is our FortiGate physical and virtual appliances, which ship with a set of broad security services, including firewall, virtual private network, application control, intrusion prevention, web filtering and advanced threat protection. These security services are enabled by our FortiGuard Labs, which provides extensive threat research and a global cloud network to deliver protection services to each FortiGate appliance. FortiGate also has extensive networking capabilities such as switching, routing, native internet protocol version 6 and different modes of deployment. FortiManager provides central management and FortiAnalyzer provides reporting and analytics. The FortiGate platform can be extended to provide enhanced capabilities.

[0001262039-16-000064:mdna:23]
Customers select the functions or combination of functions that best meet their specific security requirements such as a high-speed data center firewall at the network core, a next generation firewall at the edge or a broad unified threat management solution at branch sites. We derive a substantial majority of product sales from our FortiGate appliances, which range from the FortiGate-20 to -100 series, designed for small businesses, FortiGate-200 to -900 series for mid-sized enterprises, to the FortiGate-1000 to -6000 series for large enterprises and service providers. Our network security platform also includes our FortiGuard security subscription services, to which end-customers can subscribe in order to obtain access to dynamic updates to application control, anti-virus, intrusion prevention, web filtering, and anti-spam functionality. End-customers can also choose to purchase FortiCare technical support services for our products. End-customers also often use FortiManager and FortiAnalyzer products in conjunction with a FortiGate deployment to provide centralized management and analysis and reporting capabilities.

[0001262039-16-000064:mdna:24]
We complement our core FortiGate product line with other appliances and software licenses that offer additional protection from security threats to other critical areas of the enterprise, such as our secure wireless and access solutions, advanced threat protection, secure email gateway, web application firewalls, application delivery controllers, database security, distributed denial of service protection, and endpoint security for employee computers and mobile devices. Sales of these complementary products have grown in recent quarters.

[0001262039-16-000064:mdna:25]
[same as prior period, unchanged from 0001262039-15-000048:mdna:26]

[0001262039-16-000064:mdna:26]
| • | We recorded total revenue of $284.6 million in the three months ended March 31, 2016, an increase of 34% compared to the same period last year. Product revenue was $124.6 million in the three months ended March 31, 2016, an increase of 28% compared to the same period last year. Service revenue was $160.0 million in the three months ended March 31, 2016, an increase of 39% compared to the same period last year. |

[0001262039-16-000064:mdna:27]
| • | Cash, cash equivalents and investments were $1.19 billion as of March 31, 2016, an increase of $30.2 million, or 3%, from December 31, 2015. |

[0001262039-16-000064:mdna:28]
| • | Deferred revenue was $837.2 million as of March 31, 2016, an increase of $45.9 million, or 6%, from December 31, 2015. |

[0001262039-16-000064:mdna:29]
| • | We generated cash flows from operating activities of $100.6 million in the three months ended March 31, 2016, an increase of $36.0 million, or 56%, compared to the same period last year. |

[0001262039-16-000064:mdna:30]
| • | We repurchased 2.0 million shares of common stock under our Share Repurchase Program for an aggregate purchase price of $50.0 million in the three months ended March 31, 2016. |

[0001262039-16-000064:mdna:31]
Revenue grew in the three months ended March 31, 2016 compared to the same period last year as our Security Fabric puts us in a strong competitive position in a robust security market. Our strategy to invest in sales and marketing has enabled us to gain more enterprise customers today than we have had in the past. Large enterprises represent significant opportunity for

[0001262039-16-000064:mdna:32]
26

[0001262039-16-000064:mdna:33]
cross-sell and upsell, as they tend to purchase more products and services over time. During the three months ended March 31, 2016, our revenue growth was driven by greater sales volume in our FortiGate product family due to increased demand across all product categories. Our high-end FortiGate products (FortiGate-1000 to -6000 series) accounted for 37% of billings due to strong sales to service providers and large enterprises. Our mid-range products (FortiGate-200 to -900 series) accounted for 28% of billings, and our entry-level products (FortiGate-20 to -100 series) accounted for 35% of billings. Service revenue also increased as we continue to add to and charge more for functionality and value in our FortiGuard security subscription, FortiCare technical support and other offerings.

[0001262039-16-000064:mdna:34]
During the three months ended March 31, 2016, operating expenses increased by $64.1 million, or 43%, as compared to the same period last year. The increase was primarily driven by our accelerated pace of hiring and investments made to expand our sales coverage, grow our marketing capabilities, develop new products and scale our customer support. We also continue to invest in research and development to strengthen our technology leadership position. We believe that continued product innovation has strengthened our technology and resulted in market share gains. In addition, we incurred expenses from business design and reengineering related to the implementation of an ERP system. Headcount increased by 38% to 4,239 employees and contractors as of March 31, 2016, up from 3,076 as of March 31, 2015.

[0001262039-16-000064:mdna:35]
Business Model

[0001262039-16-000064:mdna:36]
Our sales strategy is based on a distribution model whereby we primarily sell our products and services directly to distributors which sell to resellers and service providers, which, in turn, sell to our end-customers. In certain cases, we sell directly to government-focused resellers, large service providers and major systems integrators, which have significant purchasing power and unique customer deployment requirements. Typically, FortiGuard security subscription services and FortiCare technical support services are purchased along with our physical and virtual appliances, most frequently as part of a bundle offering that includes hardware and services. We invoice at the time of our sale for the total price of the products and subscription and technical support services, and the invoice generally becomes payable within 30 to 90 days. We generally recognize product revenue up-front and defer revenue for the sale of new, and renewal of existing, FortiGuard security subscription and FortiCare technical support services contracts. We recognize the related service revenue over the service period, which is typically one to three years, although it can be as long as five years. Sales of new and renewal services are a source of recurring revenue and increase our deferred revenue balance, which contributes significantly to our positive cash flow from operations.

[0001262039-16-000064:mdna:37]
Key Metrics

[0001262039-16-000064:mdna:38]
We monitor a number of financial and operating metrics, including the key financial metrics set forth below, in order to help us evaluate growth trends, establish budgets, measure the effectiveness of our sales and marketing efforts, and assess operational efficiencies. The following table summarizes revenue, deferred revenue, billings (non-GAAP), cash, cash equivalents and investments, net cash provided by operating activities, and free cash flow (non-GAAP). We discuss revenue below under “—Results of Operations,” and we discuss our cash, cash equivalents, and investments, and net cash provided by operating activities below under “—Liquidity and Capital Resources.” Deferred revenue, billings (non-GAAP), and free cash flow (non-GAAP) are discussed immediately below the following table.

[0001262039-16-000064:mdna:39]
|  | Three Months Ended Or As Of |
|  | March 31, 2016 |  | March 31, 2015 |
|  | (in thousands) |
| Revenue | $ | 284,576 |  |  | $ | 212,886 |  |
| Deferred revenue | $ | 837,188 |  |  | $ | 600,171 |  |
| Billings (non-GAAP) | $ | 330,461 |  |  | $ | 254,300 |  |
| Cash, cash equivalents and investments | $ | 1,194,487 |  |  | $ | 1,072,565 |  |
| Net cash provided by operating activities | $ | 100,591 |  |  | $ | 64,619 |  |
| Free cash flow (non-GAAP) | $ | 70,635 |  |  | $ | 59,692 |  |

[0001262039-16-000064:mdna:40]
Deferred revenue. Our deferred revenue consists of amounts that have been invoiced but that have not yet been recognized as revenue. The majority of our deferred revenue balance consists of the unrecognized portion of service revenue from FortiGuard security subscription and FortiCare technical support service contracts, which is recognized as revenue ratably

[0001262039-16-000064:mdna:41]
over the contractual service period. We monitor our deferred revenue balance because it represents a significant portion of revenue to be recognized in future periods.

[0001262039-16-000064:mdna:42]
Billings (Non-GAAP).We define billings as revenue recognized in accordance with GAAP plus the change in deferred revenue from the beginning to the end of the period less any deferred revenue balances acquired from business combination(s) during the period. We consider billings to be a useful metric for management and investors because billings drives future revenue, which is an important indicator of the health and viability of our business. There are a number of limitations related to the use of billings instead of GAAP revenue. First, billings include amounts that have not yet been recognized as revenue. Second, we may calculate billings in a manner that is different from peer companies that report similar financial measures. Management accounts for these limitations by providing specific information regarding GAAP revenue and evaluating billings together with GAAP revenue.

[0001262039-16-000064:mdna:43]
[same as prior period, unchanged from 0001262039-15-000048:mdna:44]

[0001262039-16-000064:mdna:44]
|  | Three Months Ended |
| March 31, 2016 |  | March 31, 2015 |
| (in thousands) |
| Billings: |  |  |  |
| Revenue | $ | 284,576 |  |  | $ | 212,886 |  |
| Add increase in deferred revenue | 45,885 |  |  | 41,414 |  |
| Total billings (Non-GAAP) | $ | 330,461 |  |  | $ | 254,300 |  |

[0001262039-16-000064:mdna:45]
Free cash flow (Non-GAAP). We define free cash flow as net cash provided by operating activities minus capital expenditures such as purchases of property and equipment. We consider free cash flow to be a liquidity measure that provides useful information to management and investors about the amount of cash generated by the business that, after the acquisition of property and equipment, can be used for strategic opportunities, including investing in our business, making strategic acquisitions, repurchasing outstanding common stock and strengthening the balance sheet. Analysis of free cash flow facilitates management’s comparison of our operating results to those of our peer companies. A limitation of using free cash flow rather than the GAAP measure of net cash provided by operating activities as a means for evaluating liquidity is that free cash flow does not represent the total increase or decrease in the cash, cash equivalents and investments balance for the period because it excludes cash provided by or used for other investing and financing activities. Management accounts for this limitation by providing information about our capital expenditures and other investing and financing activities on the face of the cash flow statement and under “—Liquidity and Capital Resources.”  A reconciliation of free cash flow to net cash provided by operating activities, the most directly comparable financial measure calculated and presented in accordance with GAAP, is provided below:

[0001262039-16-000064:mdna:46]
|  | Three Months Ended |
| March 31, 2016 |  | March 31, 2015 |
| (in thousands) |
| Free Cash Flow: |  |  |  |
| Net cash provided by operating activities | $ | 100,591 |  |  | $ | 64,619 |  |
| Less purchases of property and equipment | (29,956 | ) |  | (4,927 | ) |
| Free cash flow (Non-GAAP) | $ | 70,635 |  |  | $ | 59,692 |  |

[0001262039-16-000064:mdna:47]
[same as prior period, unchanged from 0001262039-15-000048:mdna:51]

[0001262039-16-000064:mdna:48]
Our discussion and analysis of our financial condition and results of operations are based upon our financial statements, which have been prepared in accordance with GAAP. These principles require us to make estimates and judgments that affect the reported amounts of assets, liabilities, revenue, cost of revenue and expenses, and related disclosures. Our estimates include those related to revenue recognition, stock-based compensation expense, valuation of inventory, warranty liabilities, investments, business combinations, restructuring charges, goodwill and other long-lived assets, and accounting for income taxes. We base our estimates on historical experience and on various other assumptions that we believe to be reasonable

[0001262039-16-000064:mdna:49]
[same as prior period, unchanged from 0001262039-15-000048:mdna:21]

[0001262039-16-000064:mdna:50]
under the circumstances. To the extent that there are material differences between these estimates and our actual results, our future financial statements will be affected.

[0001262039-16-000064:mdna:51]
There have been no material changes to our critical accounting policies and estimates as of and for the three months ended March 31, 2016, as compared to the critical accounting policies and estimates described in the Form 10-K.

[0001262039-16-000064:mdna:52]
[same as prior period, unchanged from 0001262039-15-000048:mdna:57]

[0001262039-16-000064:mdna:53]
See Note 1 to the notes to the condensed consolidated financial statements included in Part I, Item 1 of this Quarterly Report on Form 10-Q for information regarding recent accounting pronouncements.

[0001262039-16-000064:mdna:54]
[same as prior period, unchanged from 0001262039-15-000048:mdna:32]

[0001262039-16-000064:mdna:55]
[same as prior period, unchanged from 0001262039-15-000048:mdna:59]

[0001262039-16-000064:mdna:56]
Three Months Ended March 31, 2016 and 2015

[0001262039-16-000064:mdna:57]
[same as prior period, unchanged from 0001262039-15-000048:mdna:61]

[0001262039-16-000064:mdna:58]
|  | Three Months Ended |  |  |  |  |
| March 31, 2016 |  | March 31, 2015 |  |  |  |  |
| Amount |  | % ofRevenue |  | Amount |  | % ofRevenue |  | Change |  | % Change |
| (in thousands, except percentages) |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 124,572 |  |  | 44 | % |  | $ | 97,509 |  |  | 46 | % |  | $ | 27,063 |  |  | 28 | % |
| Service | 160,004 |  |  | 56 |  |  | 115,377 |  |  | 54 |  |  | 44,627 |  |  | 39 |  |
| Total revenue | $ | 284,576 |  |  | 100 | % |  | $ | 212,886 |  |  | 100 | % |  | $ | 71,690 |  |  | 34 | % |
| Revenue by geography: |  |  |  |  |  |  |  |  |  |  |  |
| Americas | $ | 120,046 |  |  | 42 | % |  | $ | 91,560 |  |  | 43 | % |  | $ | 28,486 |  |  | 31 | % |
| EMEA | 105,491 |  |  | 37 |  |  | 75,664 |  |  | 36 |  |  | 29,827 |  |  | 39 |  |
| APAC | 59,039 |  |  | 21 |  |  | 45,662 |  |  | 21 |  |  | 13,377 |  |  | 29 |  |
| Total revenue | $ | 284,576 |  |  | 100 | % |  | $ | 212,886 |  |  | 100 | % |  | $ | 71,690 |  |  | 34 | % |

[0001262039-16-000064:mdna:59]
Total revenue increased by $71.7 million, or 34%, during the three months ended March 31, 2016 compared to the same period last year. On a geographic basis, revenue continued to diversify globally. All three regions experienced revenue growth compared to the same period last year, with the EMEA region contributing to the largest portion of our revenue growth on both an absolute dollar and percentage basis. Product revenue increased by $27.1 million, or 28%, in the three months ended March 31, 2016 compared to the same period last year. The increase in product revenue was primarily driven by greater sales volume in our FortiGate product family across all product categories and in particular for our mid-range products for service providers and large enterprise customers. Service revenue increased by $44.6 million, or 39%, in the three months ended March 31, 2016 compared to the same period last year. The increase in service revenue was primarily due to the recognition of revenue from our growing deferred revenue balance consisting of FortiGuard security subscription and FortiCare technical support contracts sold to a larger customer base, as well as the renewals of similar contracts sold in earlier periods.

[0001262039-16-000064:mdna:60]
[same as prior period, unchanged from 0001262039-15-000048:mdna:64]

[0001262039-16-000064:mdna:61]
|  | Three Months Ended |  |  |  |  |
| March 31, 2016 |  | March 31, 2015 |  | Change |  | % Change |
| (in thousands, except percentages) |
| Cost of revenue: |  |  |  |  |  |  |  |
| Product | $ | 49,359 |  |  | $ | 41,368 |  |  | $ | 7,991 |  |  | 19 | % |
| Service | 28,390 |  |  | 22,234 |  |  | 6,156 |  |  | 28 |  |
| Total cost of revenue | $ | 77,749 |  |  | $ | 63,602 |  |  | $ | 14,147 |  |  | 22 | % |
| Gross margin: |  |  |  |  |  |  |  |
| Product | 60.4 | % |  | 57.6 | % |  | 2.8 | % |  |  |
| Service | 82.3 |  |  | 80.7 |  |  | 1.6 |  |  |  |
| Total gross margin | 72.7 | % |  | 70.1 | % |  | 2.6 | % |  |  |

[0001262039-16-000064:mdna:62]
Total gross margin increased by 2.6 percentage points in the three months ended March 31, 2016 compared to the same period last year, as both product and service gross margins increased. Product gross margin increased by 2.8 percentage points in the three months ended March 31, 2016 compared to the same period last year. Product gross margin was positively impacted by higher sales of software products such as certain of our virtualized security solutions, as well as improvements in inventory management efficiencies.

[0001262039-16-000064:mdna:63]
[same as prior period, unchanged from 0001262039-15-000048:mdna:41]

[0001262039-16-000064:mdna:64]
Service gross margin increased in the three months ended March 31, 2016 as compared to the same period last year as we scaled efficiencies resulting from our ability to add to, and charge more for functionality and value in, our FortiGuard security subscription and FortiCare technical support offerings, which yielded more value to our customers and which translated into improved service margins. Cost of service revenue increased by $6.2 million primarily due to a $4.1 million increase in personnel costs related to headcount increases.

[0001262039-16-000064:mdna:65]
[same as prior period, unchanged from 0001262039-15-000048:mdna:70]

[0001262039-16-000064:mdna:66]
|  | Three Months Ended |  | Change |  | % Change |
| March 31, 2016 |  | March 31, 2015 |  |
| Amount |  | % ofRevenue |  | Amount |  | % ofRevenue |  |
| (in thousands, except percentages) |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | $ | 44,966 |  |  | 16 | % |  | $ | 35,816 |  |  | 17 | % |  | $ | 9,150 |  |  | 26 | % |
| Sales and marketing | 147,403 |  |  | 52 |  |  | 100,609 |  |  | 47 |  |  | 46,794 |  |  | 47 |  |
| General and administrative | 19,802 |  |  | 7 |  |  | 11,961 |  |  | 6 |  |  | 7,841 |  |  | 66 |  |
| Restructuring charges | 328 |  |  | — |  |  | — |  |  | — |  |  | 328 |  |  | 100 |  |
| Total operating expenses | $ | 212,499 |  |  | 75 | % |  | $ | 148,386 |  |  | 70 | % |  | $ | 64,113 |  |  | 43 | % |

[0001262039-16-000064:mdna:67]
[same as prior period, unchanged from 0001262039-15-000048:mdna:72]

[0001262039-16-000064:mdna:68]
Research and development expense increased by $9.2 million, or 26%, in the three months ended March 31, 2016 compared to the same period last year, primarily due to an increase of $6.9 million in personnel costs as a result of increased headcount to support the development of new products and continued enhancements of our existing products. Depreciation and other occupancy-related costs increased by $1.9 million. We intend to continue to invest in our research and development organization, but expect research and development expense as a percentage of total revenue to remain at a relatively comparable level during the remainder of 2016.

[0001262039-16-000064:mdna:69]
[same as prior period, unchanged from 0001262039-15-000048:mdna:74]

[0001262039-16-000064:mdna:70]
Sales and marketing expense increased by $46.8 million, or 47%, in the three months ended March 31, 2016 compared to the same period last year, primarily due to an increase of $35.2 million in personnel costs as we continued to increase our sales and marketing headcount. Marketing-related expenses increased by $5.1 million as we invested significantly in marketing to drive broader market awareness, create a global marketing engine, build broad market lead generation, nurture programs and accelerate pipeline. In addition, we incurred increases in travel expenses of $2.0 million and depreciation and occupancy-related costs of $3.5 million. We intend to continue to make investments in our sales resources and infrastructure and marketing strategy, which are critical to support growth, but expect sales and marketing expense as a percentage of total revenue to slightly decrease during the remainder of 2016.

[0001262039-16-000064:mdna:71]
[same as prior period, unchanged from 0001262039-15-000048:mdna:76]

[0001262039-16-000064:mdna:72]
General and administrative expense increased by $7.8 million, or 66%, in the three months ended March 31, 2016 compared to the same period last year. Personnel costs increased by $4.1 million due to increase in headcount in order to support our expanding business. In addition, we also incurred $3.0 million in expenses related to business process design and reengineering in preparation of implementing a new ERP system. As a percentage of total revenue, we expect general and administrative expense to remain at a relatively comparable level during the remainder of 2016.

[0001262039-16-000064:mdna:73]
[same as prior period, unchanged from 0001262039-15-000048:mdna:79]

[0001262039-16-000064:mdna:74]
Restructuring charges of $0.3 million in the three months ended March 31, 2016 primarily relate to the continued restructuring activities related to the acquisition of Meru and reducing our combined cost structure relative to Meru. See Note 9 to the condensed consolidated financial statements for additional details, including types of expenses incurred and the timing of future expenses and cash payments. See also the “Liquidity and Capital Resources” section of this Part I, Item 2, “Management’s Discussion and Analysis of Financial Condition and Results of Operations.”

[0001262039-16-000064:mdna:75]
31

[0001262039-16-000064:mdna:76]
Interest income and other expense—net

[0001262039-16-000064:mdna:77]
|  | Three Months Ended |  |  |  |  |
| March 31, 2016 |  | March 31, 2015 |  | Change |  | % Change |
| (in thousands, except percentages) |
| Interest income | $ | 1,746 |  |  | $ | 1,422 |  |  | $ | 324 |  |  | 23 | % |
| Other expense—net | (1,312 | ) |  | (677 | ) |  | (635 | ) |  | 94 |  |

[0001262039-16-000064:mdna:78]
Interest income increased in the three months ended March 31, 2016 compared to the same period last year due to interest earned on higher invested balances of cash, cash equivalents and investments. Interest income varies depending on our average investment balances during the period, types and mix of investments, and market interest rates. The increase in Other expense—net in the three months ended March 31, 2016 as compared to the same period last year was the result of higher foreign currency exchange losses. Other expense—net consisted primarily of foreign exchange and related hedging gains and losses.

[0001262039-16-000064:mdna:79]
Provision for (benefit from) income taxes

[0001262039-16-000064:mdna:80]
|  | Three Months Ended |  | Change |  | % Change |
| March 31, 2016 |  | March 31, 2015 |  |
| (in thousands, except percentages) |
| Provision for (benefit from) income taxes | $ | (1,809 | ) |  | $ | 83 |  |  | $ | (1,892 | ) |  | * |
| Effective tax rate (%) | 35 | % |  | 5 | % |  | 30 | % |  | — |

[0001262039-16-000064:mdna:81]
* not meaningful

[0001262039-16-000064:mdna:82]
Our effective tax rate was 35% for the three months ended March 31, 2016, as compared to an effective tax rate of 5% for the same period last year. The effective tax rate for the periods presented was comprised of U.S. federal and state taxes, withholding taxes and foreign income taxes. The changes in the tax provision and effective tax rate were primarily because we had a pretax loss for the three months ended March 31, 2016, as compared to having a pretax income for the same period last year. Our effective tax rate for the three months ended March 31, 2016 included the tax benefit from the U.S. federal R&D credit. The effective tax rate for the three months ended March 31, 2015 did not reflect the tax benefit of the U.S. federal R&D credit as it expired at the end of 2014 and was reinstated retroactively in December 2015.

[0001262039-16-000064:mdna:83]
Within the next twelve months, we do not believe there will be a decrease in uncertain tax benefits that could significantly impact our effective tax rate.

[0001262039-16-000064:mdna:84]
[same as prior period, unchanged from 0001262039-15-000048:mdna:119]

[0001262039-16-000064:mdna:85]
|  | As of |
|  | March 31, 2016 |  | December 31, 2015 |
|  | (in thousands) |
| Cash and cash equivalents | $ | 568,008 |  |  | $ | 543,277 |  |
| Investments | 626,479 |  |  | 621,033 |  |
| Total cash, cash equivalents and investments | $ | 1,194,487 |  |  | $ | 1,164,310 |  |
| Working capital | $ | 598,359 |  |  | $ | 591,873 |  |
|  | Three Months Ended |
|  | March 31, 2016 |  | March 31, 2015 |
|  | (in thousands) |
| Cash provided by operating activities | $ | 100,591 |  |  | $ | 64,619 |  |
| Cash provided by (used in) investing activities | (34,204 | ) |  | 16,124 |  |
| Cash provided by (used in) financing activities | (41,656 | ) |  | 22,355 |  |
| Net increase in cash and cash equivalents | $ | 24,731 |  |  | $ | 103,098 |  |

[0001262039-16-000064:mdna:86]
Liquidity and capital resources may be impacted by our operating activities, as well as by our business acquisitions, capital expenditures, stock repurchases, proceeds associated with stock option exercises and issuances of common stock under the ESPP, payment of taxes in connection with the net settlement of equity awards, and investments in strategic relationships that we have made or may make in the future. As of March 31, 2016, $150.0 million remains available for future share repurchases under our share repurchase program, which will be financed through our available working capital. In recent years we have received significant capital resources as a result of the exercise of stock options and purchases under our ESPP. We expect proceeds in future years to be impacted by our share price and the mix of stock options and RSUs granted. During 2016, we expect to spend $50.0 million to $60.0 million in capital expenditures primarily related to expansion of our offices to support worldwide growth and the implementation of our ERP system.

[0001262039-16-000064:mdna:87]
As of March 31, 2016, our cash, cash equivalents, and investments of $1.19 billion were invested primarily in corporate debt securities, commercial paper, municipal bonds, certificates of deposit and term deposits, money market funds, and U.S. government and agency securities. It is our investment policy to invest excess cash in a manner that preserves capital, provides liquidity and maximizes return without significantly increasing risk.

[0001262039-16-000064:mdna:88]
As of March 31, 2016, $419.7 million of our cash and investments were held by our international subsidiaries and are therefore not immediately available to fund domestic operations unless the cash is repatriated. While we do not intend to do so, should this amount be repatriated, most of it would be subject to U.S. federal income tax that would be partially offset by foreign tax credits. We do not enter into investments for trading or speculative purposes. We believe that our existing cash and cash equivalents will be sufficient to meet our anticipated cash needs for at least the next 12 months. Our future capital requirements will depend on many factors, including our growth rate, the timing and extent of spending to support development efforts, the expansion of sales and marketing activities, the introduction of new and enhanced products and services offerings, the costs to ensure access to adequate manufacturing capacity and the continuing market acceptance of our products. Historically, we have required capital principally to fund our working capital needs, capital expenditures, share repurchases and acquisition activities. In the event that additional financing is required from outside sources, we may not be able to raise it on terms acceptable to us or at all. If we are unable to raise additional capital when desired, our business, operating results and financial condition would be adversely affected.

[0001262039-16-000064:mdna:89]
[same as prior period, unchanged from 0001262039-15-000048:mdna:124]

[0001262039-16-000064:mdna:90]
Cash generated by operating activities is our primary source of liquidity. It is primarily comprised of net income (loss), as adjusted for non-cash items, and changes in operating assets and liabilities. Non-cash adjustments consist primarily of stock-based compensation, depreciation of property and equipment, amortization of intangible assets and amortization of investment premiums.

[0001262039-16-000064:mdna:91]
Our operating activities during the three months ended March 31, 2016 provided $100.6 million in cash as a result of our continued growth in billings and our ability to successfully manage our working capital. Changes in operating assets and liabilities primarily resulted from an increase in payments received from customers, which was partially offset by an increase in payments to vendors.

[0001262039-16-000064:mdna:92]
Our operating activities during the three months ended March 31, 2015 provided $64.6 million in cash as a result of our continued growth in billings and the ability to successfully manage our working capital. Changes in operating assets and liabilities primarily included an increase in payments received from customers, partially offset by an increase in payments to vendors for inventory-related purchases and prepayment of certain expenses.

[0001262039-16-000064:mdna:93]
[same as prior period, unchanged from 0001262039-15-000048:mdna:130]

[0001262039-16-000064:mdna:94]
The changes in cash flows from investing activities primarily relate to timing of purchases, maturities and sales of investments, and purchases of property and equipment.

[0001262039-16-000064:mdna:95]
During the three months ended March 31, 2016, cash used for investing activities was primarily due to the $30.0 million we spent on capital expenditures, including our purchase of certain real property in Union City, California for total cash of $18.5 million. Cash outflows due to sales and maturities of our investments, net of purchases, amounted to $4.2 million.

[0001262039-16-000064:mdna:96]
During the three months ended March 31, 2015, cash provided by investing activities was a result of positive cash flow due to maturities, net of purchases, from our investments of $21.1 million, partially offset by capital expenditures of $4.9 million.

[0001262039-16-000064:mdna:97]
[same as prior period, unchanged from 0001262039-15-000048:mdna:134]

[0001262039-16-000064:mdna:98]
[same as prior period, unchanged from 0001262039-15-000048:mdna:135]

[0001262039-16-000064:mdna:99]
During the three months ended March 31, 2016, cash used for financing activities was $41.7 million, primarily due to $50.0 million used to repurchase our common stock. This was partially offset by $8.3 million of proceeds from the issuance of common stock, net of taxes paid, related to withholding upon issuance of RSUs.

[0001262039-16-000064:mdna:100]
During the three months ended March 31, 2015, cash provided by financing activities was $22.4 million as a result of proceeds of $29.0 million from the issuance of common stock under our stock-based compensation plans. This cash inflow was partially offset by $6.6 million of withholding tax payments upon the settlement of RSUs.

[0001262039-16-000064:mdna:101]
Contractual Obligations and Commitments

[0001262039-16-000064:mdna:102]
There were no material changes outside the ordinary course of business during the three months ended March 31, 2016 to the contractual obligations and commitments disclosed in Management’s Discussion and Analysis of Financial Condition and Results of Operations, set forth in Part II, Item 7, of the Form 10-K. See Note 10 to the notes to the condensed consolidated financial statements included in Part I, Item 1 of this Quarterly Report on Form 10-Q for additional information regarding contractual obligations and commitments.

[0001262039-16-000064:mdna:103]
[same as prior period, unchanged from 0001262039-15-000048:mdna:140]

[0001262039-16-000064:mdna:104]
As of March 31, 2016, we did not have any relationships with unconsolidated organizations or financial partnerships, such as structured finance or special purpose entities that would have been established for the purpose of facilitating off-balance sheet arrangements or other contractually narrow or limited purposes.
