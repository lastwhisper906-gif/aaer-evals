# FTNT notes — 0001262039-16-000064


## ftnt:IncomeTaxBenefitFromStockOptionPlansTableTextBlock

[0001262039-16-000064:notes:1]
Total income tax benefit associated with stock-based compensation that is recognized in the consolidated statements of operations is as follows (in thousands):

[0001262039-16-000064:notes:2]
|  | Three Months Ended |
|  | March 31, 2016 |  | March 31, 2015 |
| Income tax benefit associated with stock-based compensation | $ | 7,834 |  |  | $ | 3,377 |  |


## ftnt:PresentationAndPreparationOfConsolidatedFinancialStatementsPolicyTextBlock

[0001262039-16-000064:notes:3]
Basis of Presentation and Preparation—The unaudited condensed consolidated financial statements of Fortinet, Inc. and its wholly-owned subsidiaries (collectively, “we,” “us” or “our”) have been prepared in accordance with generally accepted accounting principles in the United States (“GAAP”) for interim financial information, as well as the instructions to Form 10-Q pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (“SEC”). Accordingly, they do not include all of the information and footnotes required by GAAP for complete financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the year ended December 31, 2015, contained in our Annual Report on Form 10-K (the “Form 10-K”) filed with the SEC on February 26, 2016. In the opinion of management, all adjustments, which includes normal recurring adjustments, considered necessary for a fair presentation have been included. All intercompany balances, transactions and cash flows have been eliminated. The results of operations for the three months ended March 31, 2016 are not necessarily indicative of the results for the full year or for any future periods. The condensed consolidated balance sheet as of December 31, 2015 is derived from the audited consolidated financial statements for the year ended December 31, 2015.

[0001262039-16-000064:notes:4]
The preparation of financial statements in accordance with GAAP requires management to make estimates and assumptions that affect the amounts reported in the condensed consolidated financial statements and accompanying notes. Actual results could differ materially from those estimates.

[0001262039-16-000064:notes:5]
There have been no material changes to our significant accounting policies as of and for the three months ended March 31, 2016.


## ftnt:ScheduleOfAmortizedCostsUnrealizedGainsAndLossesAndFairValueOfAvailableForSaleSecuritiesTableTextBlock

[0001262039-16-000064:notes:6]
The following table summarizes our investments as of March 31, 2016 and December 31, 2015 (in thousands):

[0001262039-16-000064:notes:7]
|  | March 31, 2016 |
|  | AmortizedCost |  | UnrealizedGains |  | UnrealizedLosses |  | FairValue |
| Corporate debt securities | $ | 410,265 |  |  | $ | 574 |  |  | $ | (250 | ) |  | $ | 410,589 |  |
| Commercial paper | 75,465 |  |  | 7 |  |  | (8 | ) |  | 75,464 |  |
| Municipal bonds | 54,198 |  |  | 53 |  |  | (7 | ) |  | 54,244 |  |
| Certificates of deposit and term deposits (1) | 19,847 |  |  | — |  |  | — |  |  | 19,847 |  |
| U.S. government and agency securities | 66,253 |  |  | 82 |  |  | — |  |  | 66,335 |  |
| Total available-for-sale securities | $ | 626,028 |  |  | $ | 716 |  |  | $ | (265 | ) |  | $ | 626,479 |  |

[0001262039-16-000064:notes:8]
|  | December 31, 2015 |
|  | AmortizedCost |  | UnrealizedGains |  | UnrealizedLosses |  | FairValue |
| Corporate debt securities | $ | 438,533 |  |  | $ | 30 |  |  | $ | (1,369 | ) |  | $ | 437,194 |  |
| Commercial paper | 66,263 |  |  | 3 |  |  | (34 | ) |  | 66,232 |  |
| Municipal bonds | 61,050 |  |  | 12 |  |  | (40 | ) |  | 61,022 |  |
| Certificates of deposit and term deposits (1) | 14,897 |  |  | — |  |  | — |  |  | 14,897 |  |
| U.S. government and agency securities | 41,727 |  |  | 3 |  |  | (42 | ) |  | 41,688 |  |
| Total available-for-sale securities | $ | 622,470 |  |  | $ | 48 |  |  | $ | (1,485 | ) |  | $ | 621,033 |  |

[0001262039-16-000064:notes:9]
[same as prior period, unchanged from 0001262039-15-000048:notes:7]


## ftnt:ScheduleOfShareBasedPaymentAwardStockOptionsValuationAssumptionsAndAllocationOfRecognizedPeriodCostsTableTextBlock

[0001262039-16-000064:notes:10]
[same as prior period, unchanged from 0001262039-15-000048:notes:8]

[0001262039-16-000064:notes:11]
|  | Three Months Ended |
|  | March 31, 2016 |  | March 31, 2015 |
| Expected term in years | 4.3 |  |  | 4.3 |  |
| Volatility | 43 | % |  | 40 | % |
| Risk-free interest rate | 1.1 | % |  | 1.5 | % |
| Dividend rate | — | % |  | — | % |


## ftnt:ScheduleofEmployeeServiceSharebasedCompensationAllocationofRecognizedPeriodCostsbyAwardTypeTableTextBlock

[0001262039-16-000064:notes:12]
[same as prior period, unchanged from 0001262039-15-000048:notes:10]

[0001262039-16-000064:notes:13]
|  | Three Months Ended |
|  | March 31, 2016 |  | March 31, 2015 |
| RSUs | $ | 27,082 |  |  | $ | 14,292 |  |
| Stock options | 1,954 |  |  | 3,455 |  |
| ESPP | 1,845 |  |  | 1,175 |  |
| Total stock-based compensation expense | $ | 30,881 |  |  | $ | 18,922 |  |


## ftnt:ScheduleofMajorCustomersbyAccountsReceivableTableTextBlock

[0001262039-16-000064:notes:14]
The following customers, each of which is a distributor, accounted for 10% or more of net accounts receivable:

[0001262039-16-000064:notes:15]
|  | March 31, 2016 |  | December 31, 2015 |
| Exclusive Networks Group | 21 | % |  | 23 | % |
| Fine Tec Computers | 13 | % |  | * |  |

[0001262039-16-000064:notes:16]
* Represents less than 10%


## ftnt:ScheduleofSharebasedCompensationSharesWithheldforTaxesTableTextBlock

[0001262039-16-000064:notes:17]
[same as prior period, unchanged from 0001262039-15-000048:notes:15]

[0001262039-16-000064:notes:18]
|  | Three Months Ended |
|  | March 31, 2016 |  | March 31, 2015 |
| Shares withheld for taxes | 343 |  |  | 221 |  |
| Amount withheld for taxes | $ | 9,441 |  |  | $ | 6,600 |  |


## ftnt:ScheduleofSharebasedCompensationStockOptionsActivityAdditionalInformationTableTextBlock

[0001262039-16-000064:notes:19]
Additional information related to our stock options is summarized below (in thousands, except per share amounts):

[0001262039-16-000064:notes:20]
|  | Three Months Ended |
|  | March 31, 2016 |  | March 31, 2015 |
| Weighted-average fair value per share granted | $ | 8.68 |  |  | $ | 11.17 |  |
| Intrinsic value of options exercised | 19,424 |  |  | 41,003 |  |
| Fair value of options vested | 2,084 |  |  | 3,792 |  |


## ftnt:ScheduleofSharebasedPaymentAwardEmployeeStockPurchasePlanAdditionalInformationTableTextBlock

[0001262039-16-000064:notes:21]
[same as prior period, unchanged from 0001262039-15-000048:notes:17]

[0001262039-16-000064:notes:22]
|  | Three Months Ended |
|  | March 31, 2016 |  | March 31, 2015 |
| Weighted-average fair value per share granted | $ | 7.19 |  |  | $ | 7.56 |  |
| Shares issued under the ESPP | 614 |  |  | 427 |  |
| Weighted-average price per share issued | $ | 20.49 |  |  | $ | 21.34 |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001262039-16-000064:notes:23]
[same as prior period, unchanged from 0001262039-15-000048:notes:25]

[0001262039-16-000064:notes:24]
On July 8, 2015, we completed our acquisition of all of the outstanding shares of Meru Networks, Inc. (“Meru”), a provider of Wi-Fi networking products and services. With this acquisition, we expect to expand on our secure wireless vision and enterprise growth focus, broaden our solutions portfolio, and enhance our opportunity to address the global enterprise Wi-Fi market with integrated and intelligent secure wireless solutions.

[0001262039-16-000064:notes:25]
[same as prior period, unchanged from 0001262039-15-000048:notes:27]

[0001262039-16-000064:notes:26]
[same as prior period, unchanged from 0001262039-15-000048:notes:28]

[0001262039-16-000064:notes:27]
We accounted for this transaction as a business combination. In 2015, we expensed acquisition-related costs of $1.7 million in general and administrative expenses. The total purchase price was allocated to Meru’s identifiable tangible and intangible assets acquired and liabilities assumed based on their estimated fair values as of the acquisition date.

[0001262039-16-000064:notes:28]
[same as prior period, unchanged from 0001262039-15-000048:notes:30]

[0001262039-16-000064:notes:29]
| Cash and cash equivalents | $ | 3,268 |  |
| Accounts receivable | 8,191 |  |
| Inventory | 11,610 |  |
| Prepaid expenses and other assets | 2,409 |  |
| Property and equipment | 920 |  |
| Deferred tax assets | 18,585 |  |
| Identifiable intangible assets | 19,600 |  |
| Goodwill | 1,868 |  |
| Total assets acquired | 66,451 |  |
| Deferred revenue | 9,800 |  |
| Accounts payable and accrued liabilities | 14,887 |  |
| Total liabilities assumed | 24,687 |  |
| Total purchase price allocation | $ | 41,764 |  |

[0001262039-16-000064:notes:30]
The goodwill of $1.9 million represents the premium we paid over the fair value of the net tangible liabilities assumed and identified intangible assets acquired, due primarily to Meru’s assembled workforce. The goodwill recorded as part of the Meru acquisition is not deductible for U.S. federal income tax purposes.

[0001262039-16-000064:notes:31]
[same as prior period, unchanged from 0001262039-15-000048:notes:33]

[0001262039-16-000064:notes:32]
[same as prior period, unchanged from 0001262039-15-000048:notes:34]

[0001262039-16-000064:notes:33]
Customer relationships and trade name are amortized and the amortization expense is recorded in sales and marketing expenses in the condensed consolidated statement of operations. Developed technologies is amortized and the amortization expense is recorded in cost of product revenue in the condensed consolidated statement of operations.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001262039-16-000064:notes:34]
COMMITMENTS AND CONTINGENCIES

[0001262039-16-000064:notes:35]
The following table summarizes our future principal contractual obligations as of March 31, 2016 (in thousands):

[0001262039-16-000064:notes:36]
|  | Total |  | 2016 (remainder) |  | 2017 |  | 2018 |  | 2019 |  | 2020 |  | Thereafter |
| Operating lease commitments | $ | 60,677 |  |  | $ | 13,411 |  |  | $ | 12,897 |  |  | $ | 11,036 |  |  | $ | 8,734 |  |  | $ | 5,945 |  |  | $ | 8,654 |  |
| Inventory purchase commitments | 77,530 |  |  | 77,530 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Other contractual commitments and open purchase orders | 49,048 |  |  | 41,207 |  |  | 3,461 |  |  | 1,590 |  |  | 930 |  |  | 930 |  |  | 930 |  |
| Total | $ | 187,255 |  |  | $ | 132,148 |  |  | $ | 16,358 |  |  | $ | 12,626 |  |  | $ | 9,664 |  |  | $ | 6,875 |  |  | $ | 9,584 |  |

[0001262039-16-000064:notes:37]
Operating Leases—We lease certain facilities under various non-cancelable operating leases, which expire through 2026. Certain leases require us to pay variable costs such as taxes, maintenance, and insurance. The terms of certain operating leases also provide for renewal options and escalation clauses. Rent expense was $4.6 million and $3.1 million during the three months ended March 31, 2016 and March 31, 2015, respectively. Rent expense is recognized using the straight-line method over the term of the lease.

[0001262039-16-000064:notes:38]
Inventory Purchase Commitments—Our independent contract manufacturers procure components and build our products based on our forecasts. These forecasts are based on estimates of future demand for our products, which are in turn based on historical trends and an analysis from our sales and marketing organizations, adjusted for overall market conditions. In order to reduce manufacturing lead times and plan for adequate component supply, we may issue purchase orders to some of our independent contract manufacturers which may not be cancelable. As of March 31, 2016, we had $77.5 million of open purchase orders with our independent contract manufacturers that may not be cancelable.

[0001262039-16-000064:notes:39]
Other Contractual Commitments and Open Purchase Orders—In addition to commitments with contract manufacturers, we have open purchase orders and contractual obligations in the ordinary course of business for which we have not received goods or services. As of March 31, 2016, we had $49.0 million in other contractual commitments that may not be cancelable.

[0001262039-16-000064:notes:40]
Warranties—Accrued warranty activities are summarized as follows (in thousands):

[0001262039-16-000064:notes:41]
|  | Three Months Ended |
|  | March 31, 2016 |  | March 31, 2015 |
| Accrued warranty balance—beginning of the period | $ | 3,144 |  |  | $ | 4,269 |  |
| Warranty costs incurred | (511 | ) |  | (1,095 | ) |
| Provision for warranty for the period | 377 |  |  | 945 |  |
| Adjustment related to pre-existing warranties | (353 | ) |  | 222 |  |
| Accrued warranty balance—end of the period | $ | 2,657 |  |  | $ | 4,341 |  |

[0001262039-16-000064:notes:42]
Litigation—We are involved in disputes, litigation, and other legal actions. For lawsuits where we are the defendant, we are in the process of defending these litigation matters, and while there can be no assurances and the outcome of these matters is currently not determinable, we currently believe that there are no existing claims or proceedings that are likely to have a material adverse effect on our financial position. There are many uncertainties associated with any litigation and these actions or other third-party claims against us may cause us to incur costly litigation fees, including contingent legal fees with related parties, costs and substantial settlement charges, and possibly subject us to damages and other penalties. In addition, the resolution of any intellectual property litigation may require us to make royalty payments, which could adversely affect our gross margins in future periods. If any of those events were to occur, our business, financial condition, results of operations, and cash flows could be adversely affected. The actual liability in any such matters may be materially different from our estimates, if any, which could result in the need to adjust the liability and record additional expenses. We have not recorded any significant accrual for loss contingencies associated with such legal proceedings; determined that a significant unfavorable outcome is probable or reasonably possible; or determined that the amount or range of any possible loss is reasonably estimable.

[0001262039-16-000064:notes:43]
Indemnification—Under the indemnification provisions of our standard sales contracts, we agree to defend our customers against third-party claims asserting various allegations such as product defects and infringement of certain intellectual property rights, which may include patents, copyrights, trademarks or trade secrets, and to pay judgments entered on such claims. In some contracts, our exposure under these indemnification provisions is limited by the terms of the contracts to certain defined limits, such as the total amount paid by our customer under the agreement. However, certain agreements include covenants, penalties and indemnification provisions including and beyond indemnification for third-party claims of intellectual property infringement and that could potentially expose us to losses in excess of the amount received under the agreement, and in some instances to potential liability that is not contractually limited. To date, there have been no awards under such indemnification provisions.


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0001262039-16-000064:notes:44]
[same as prior period, unchanged from 0001262039-15-000048:notes:48]

[0001262039-16-000064:notes:45]
Our tax-deferred savings plan under our 401(k) Plan, permits participating employees to defer a portion of their pre-tax earnings. In Canada, we have a Group Registered Retirement Savings Plan program (the “RRSP”), which permits participants to make tax deductible contributions. Our board of directors approved 50% matching contributions on employee contributions up to 4% of each employee’s eligible earnings. Our matching contributions to the 401(k) Plan and RRSP for the three months ended March 31, 2016 and March 31, 2015 were $1.0 million and $0.8 million, respectively.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001262039-16-000064:notes:46]
ACCUMULATED OTHER COMPREHENSIVE INCOME (LOSS)

[0001262039-16-000064:notes:47]
The following table summarizes the changes in accumulated balances of other comprehensive income or loss (in thousands):

[0001262039-16-000064:notes:48]
|  | March 31, 2016 |
|  | Unrealized Losses on Investments |  | Tax benefit (provision) related to items of other comprehensive income or loss |  | Total |
| Beginning balance | $ | (1,437 | ) |  | $ | 504 |  |  | $ | (933 | ) |
| Other comprehensive income (loss) before reclassifications | 1,891 |  |  | (662 | ) |  | 1,229 |  |
| Amounts reclassified from accumulated other comprehensive income (loss) | (3 | ) |  | 1 |  |  | (2 | ) |
| Net current-period other comprehensive income (loss) | 1,888 |  |  | (661 | ) |  | 1,227 |  |
| Ending balance | $ | 451 |  |  | $ | (157 | ) |  | $ | 294 |  |

[0001262039-16-000064:notes:49]
The following table provides details about the reclassification out of accumulated other comprehensive income (loss) (in thousands):

[0001262039-16-000064:notes:50]
| Three Months Ended March 31, 2016 |
| Details about Accumulated Other Comprehensive Income Components |  | Amount Reclassified from Accumulated Other Comprehensive Income (Loss) |  | Affected Line Item in the Statement Where Net Income is Presented |
| Unrealized losses on investments |  | $ | (3 | ) |  | Other expense—net |
| Tax benefit related to items of other comprehensive loss |  | 1 |  |  | Provision for income taxes |
| Total reclassification for the period |  | $ | (2 | ) |  |  |


## us-gaap:CostMethodInvestmentsDescriptionTextBlock

[0001262039-16-000064:notes:51]
[same as prior period, unchanged from 0001262039-15-000048:notes:55]

[0001262039-16-000064:notes:52]
Our investments in the equity securities of three privately-held companies totaled $10.3 million as of March 31, 2016 and December 31, 2015. Each of these investments are accounted for as cost-basis investments, as we own less than 20% of the voting securities and do not have the ability to exercise significant influence over operating and financial policies of the respective entities. These investments are carried at historical cost and are recorded as Other assets on our condensed consolidated balance sheet and would be measured at fair value if indicators of impairment exist. As of March 31, 2016, no events have occurred that would adversely affect the carrying value of these investments.

[0001262039-16-000064:notes:53]
We determined that we had a variable interest in these privately-held companies. However, we determined that we were not the primary beneficiary as we did not have the power to direct their activities that most significantly affect their economic performance. The variable interest entities were not required to be consolidated in our condensed consolidated financial statements.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001262039-16-000064:notes:54]
[same as prior period, unchanged from 0001262039-15-000048:notes:67]

[0001262039-16-000064:notes:55]
[same as prior period, unchanged from 0001262039-15-000048:notes:68]

[0001262039-16-000064:notes:56]
We have stock-based compensation plans pursuant to which we have granted stock options and RSUs, including PSUs. We also have an ESPP for all eligible employees.  As of March 31, 2016, there were a total of 45,616,141 shares of common stock available for grant under our stock-based compensation plans.

[0001262039-16-000064:notes:57]
[same as prior period, unchanged from 0001262039-15-000048:notes:76]

[0001262039-16-000064:notes:58]
The following table summarizes the activity and related information for RSUs, including PSUs, for the periods presented below (in thousands, except per share amounts):

[0001262039-16-000064:notes:59]
|  | Restricted Stock Units Outstanding |
|  | Number of Shares |  | Weighted-Average Grant Date Fair Value per Share |
| Balance—December 31, 2015 | 9,257 |  |  | $ | 32.97 |  |
| Granted | 2,831 |  |  | 23.87 |  |
| Forfeited | (441 | ) |  | 31.94 |  |
| Vested | (1,014 | ) |  | 28.45 |  |
| Balance—March 31, 2016 | 10,633 |  |  | $ | 30.86 |  |
| RSUs expected to vest—March 31, 2016 | 9,959 |  |  | $ | 30.71 |  |

[0001262039-16-000064:notes:60]
As of March 31, 2016, total compensation expense related to unvested RSUs, including PSUs, that were granted to employees and non-employees, but not yet recognized, was $303.8 million. This expense is expected to be amortized on a straight-line basis over a weighted-average vesting period of 3.0 years. We did not grant any PSUs during the three months ended March 31, 2016. The stock-based compensation expense related to PSU awards is not material.

[0001262039-16-000064:notes:61]
[same as prior period, unchanged from 0001262039-15-000048:notes:80]

[0001262039-16-000064:notes:62]
[same as prior period, unchanged from 0001262039-15-000048:notes:72]

[0001262039-16-000064:notes:63]
[same as prior period, unchanged from 0001262039-15-000048:notes:73]

[0001262039-16-000064:notes:64]
|  | Options Outstanding |
|  | Numberof Shares |  | Weighted-AverageExercisePrice |  | Weighted-AverageRemainingContractualLife (Years) |  | AggregateIntrinsicValue |
| Balance—December 31, 2015 | 6,968 |  |  | $ | 20.03 |  |  |  |  |  |
| Granted | 1,161 |  |  | 23.83 |  |  |  |  |  |
| Forfeited | (49 | ) |  | 35.46 |  |  |  |  |  |
| Exercised | (906 | ) |  | 5.82 |  |  |  |  |  |
| Balance—March 31, 2016 | 7,174 |  |  | $ | 22.33 |  |  |  |  |  |
| Options vested and expected to vest—March 31, 2016 | 7,011 |  |  | $ | 22.17 |  |  | 3.37 |  | $ | 65,127 |  |
| Options exercisable—March 31, 2016 | 5,107 |  |  | $ | 19.71 |  |  | 2.24 |  | $ | 56,011 |  |

[0001262039-16-000064:notes:65]
The aggregate intrinsic value represents the pre-tax difference between the exercise price of stock options and the quoted market price of our common stock on March 31, 2016, for all in-the-money options. As of March 31, 2016, total compensation expense related to unvested stock options granted to employees but not yet recognized was $19.5 million. This expense is expected to be amortized on a straight-line basis over a weighted-average period of 3.4 years.

[0001262039-16-000064:notes:66]
[same as prior period, unchanged from 0001262039-15-000048:notes:86]

[0001262039-16-000064:notes:67]
[same as prior period, unchanged from 0001262039-15-000048:notes:87]

[0001262039-16-000064:notes:68]
|  | Three Months Ended |
|  | March 31, 2016 |  | March 31, 2015 |
| Expected term in years | 0.5 |  |  | 0.5 |  |
| Volatility | 48 | % |  | 28 | % |
| Risk-free interest rate | 0.4 | % |  | 0.1 | % |
| Dividend rate | — | % |  | — | % |

[0001262039-16-000064:notes:69]
[same as prior period, unchanged from 0001262039-15-000048:notes:89]

[0001262039-16-000064:notes:70]
[same as prior period, unchanged from 0001262039-15-000048:notes:90]

[0001262039-16-000064:notes:71]
|  | Three Months Ended |
|  | March 31, 2016 |  | March 31, 2015 |
| Cost of product revenue | $ | 326 |  |  | $ | 140 |  |
| Cost of service revenue | 2,193 |  |  | 1,632 |  |
| Research and development | 7,355 |  |  | 5,157 |  |
| Sales and marketing | 17,114 |  |  | 9,307 |  |
| General and administrative | 3,893 |  |  | 2,686 |  |
| Total stock-based compensation expense | $ | 30,881 |  |  | $ | 18,922 |  |

[0001262039-16-000064:notes:72]
[same as prior period, unchanged from 0001262039-15-000048:notes:92]

[0001262039-16-000064:notes:73]
In January 2016, our board of directors approved a new Share Repurchase Program (the “Program”), which authorizes the repurchase of up to $200.0 million of our outstanding common stock through December 31, 2017. Under the Program, share repurchases may be made by us from time to time in privately negotiated transactions or in open market transactions. The Program does not require us to purchase a minimum number of shares, and may be suspended, modified or discontinued at any time without prior notice. In the three months ended March 31, 2016, we repurchased 2.0 million shares of common stock under the Program in open market transactions at an average price of $24.97 per share, for an aggregate purchase price of $50.0 million. As of March 31, 2016, $150.0 million remains available for future share repurchases under the Program.


## us-gaap:EarningsPerShareTextBlock

[0001262039-16-000064:notes:74]
NET INCOME (LOSS) PER SHARE

[0001262039-16-000064:notes:75]
Basic net income (loss) per share is computed by dividing net income (loss) by the weighted-average number of shares of common stock outstanding during the period. Diluted net income (loss) per share is computed by dividing net income (loss) by the weighted-average number of shares of common stock outstanding, plus the dilutive effects of stock options, RSUs including performance stock units (“PSUs”), and our employee stock purchase plan (“ESPP”). Dilutive shares of common stock are determined by applying the treasury stock method.

[0001262039-16-000064:notes:76]
A reconciliation of the numerator and denominator used in the calculation of basic and diluted net income (loss) per share is as follows (in thousands, except per share amounts):

[0001262039-16-000064:notes:77]
|  | Three Months Ended |
|  | March 31, 2016 |  | March 31, 2015 |
| Numerator: |  |  |  |
| Net income (loss) | $ | (3,429 | ) |  | $ | 1,560 |  |
| Denominator: |  |  |  |
| Basic shares: |  |  |  |
| Weighted-average common stock outstanding-basic | 171,745 |  |  | 168,077 |  |
| Diluted shares: |  |  |  |
| Weighted-average common stock outstanding-basic | 171,745 |  |  | 168,077 |  |
| Effect of potentially dilutive securities: |  |  |  |
| Stock options | — |  |  | 3,837 |  |
| RSUs (including PSUs) | — |  |  | 1,741 |  |
| ESPP | — |  |  | 65 |  |
| Weighted-average shares used to compute diluted net income per share | 171,745 |  |  | 173,720 |  |
| Net income (loss) per share: |  |  |  |
| Basic | $ | (0.02 | ) |  | $ | 0.01 |  |
| Diluted | $ | (0.02 | ) |  | $ | 0.01 |  |

[0001262039-16-000064:notes:78]
The following potentially dilutive shares of common stock were excluded from the computation of diluted net income (loss) per share for the periods presented, as their effect would have been antidilutive (in thousands):

[0001262039-16-000064:notes:79]
|  | Three Months Ended |
|  | March 31, 2016 |  | March 31, 2015 |
| Stock options | 6,939 |  |  | 249 |  |
| RSUs (including PSUs) | 10,020 |  |  | 1,333 |  |
| ESPP | 282 |  |  | 169 |  |
|  | 17,241 |  |  | 1,751 |  |


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0001262039-16-000064:notes:80]
FINANCIAL INSTRUMENTS AND FAIR VALUE

[0001262039-16-000064:notes:81]
The following table shows the gross unrealized losses and the related fair values of our investments that have been in a continuous unrealized loss position as of March 31, 2016 and December 31, 2015 (in thousands):

[0001262039-16-000064:notes:82]
|  | March 31, 2016 |
|  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
|  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |
| Corporate debt securities | $ | 141,018 |  |  | $ | (159 | ) |  | $ | 50,269 |  |  | $ | (91 | ) |  | $ | 191,287 |  |  | $ | (250 | ) |
| Commercial paper | 16,754 |  |  | (8 | ) |  | — |  |  | — |  |  | 16,754 |  |  | (8 | ) |
| Municipal bonds | 12,710 |  |  | (6 | ) |  | 1,006 |  |  | (1 | ) |  | 13,716 |  |  | (7 | ) |
| Total available-for-sale securities | $ | 170,482 |  |  | $ | (173 | ) |  | $ | 51,275 |  |  | $ | (92 | ) |  | $ | 221,757 |  |  | $ | (265 | ) |

[0001262039-16-000064:notes:83]
|  | December 31, 2015 |
|  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
|  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |
| Corporate debt securities | $ | 348,534 |  |  | $ | (1,187 | ) |  | $ | 42,033 |  |  | $ | (182 | ) |  | $ | 390,567 |  |  | $ | (1,369 | ) |
| Commercial paper | 31,977 |  |  | (34 | ) |  | — |  |  | — |  |  | 31,977 |  |  | (34 | ) |
| Municipal bonds | 41,677 |  |  | (36 | ) |  | 1,008 |  |  | (4 | ) |  | 42,685 |  |  | (40 | ) |
| U.S. government and agency securities | 34,703 |  |  | (42 | ) |  | — |  |  | — |  |  | 34,703 |  |  | (42 | ) |
| Total available-for-sale securities | $ | 456,891 |  |  | $ | (1,299 | ) |  | $ | 43,041 |  |  | $ | (186 | ) |  | $ | 499,932 |  |  | $ | (1,485 | ) |

[0001262039-16-000064:notes:84]
The contractual maturities of our investments as of March 31, 2016 and December 31, 2015 were as follows (in thousands):

[0001262039-16-000064:notes:85]
|  | March 31, 2016 |  | December 31, 2015 |
| Due within one year | $ | 384,591 |  |  | $ | 348,074 |  |
| Due within one to three years | 241,888 |  |  | 272,959 |  |
| Total | $ | 626,479 |  |  | $ | 621,033 |  |

[0001262039-16-000064:notes:86]
Available-for-sale securities are reported at fair value, with unrealized gains and losses, net of tax, included as a separate component of stockholders’ equity and in total comprehensive income. Realized gains and losses on available-for-sale securities are insignificant in the periods presented and are included in Other expense—net in our condensed consolidated statements of operations. We use the specific identification method to determine the cost basis of investments sold.

[0001262039-16-000064:notes:87]
The unrealized losses on our available-for-sale securities were caused by fluctuations in market value and interest rates as a result of the economic environment. As the decline in market value are attributable to changes in market conditions and not credit quality, and because we have concluded currently that we neither intend to sell nor is it more likely than not that we will be required to sell these investments prior to a recovery of par value, we do not consider these investments to be other-than temporarily impaired as of March 31, 2016.

[0001262039-16-000064:notes:88]
[same as prior period, unchanged from 0001262039-15-000048:notes:108]

[0001262039-16-000064:notes:89]
[same as prior period, unchanged from 0001262039-15-000048:notes:109]

[0001262039-16-000064:notes:90]
[same as prior period, unchanged from 0001262039-15-000048:notes:110]

[0001262039-16-000064:notes:91]
[same as prior period, unchanged from 0001262039-15-000048:notes:111]

[0001262039-16-000064:notes:92]
[same as prior period, unchanged from 0001262039-15-000048:notes:112]

[0001262039-16-000064:notes:93]
[same as prior period, unchanged from 0001262039-15-000048:notes:113]

[0001262039-16-000064:notes:94]
[same as prior period, unchanged from 0001262039-15-000048:notes:114]

[0001262039-16-000064:notes:95]
[same as prior period, unchanged from 0001262039-15-000048:notes:115]

[0001262039-16-000064:notes:96]
[same as prior period, unchanged from 0001262039-15-000048:notes:116]

[0001262039-16-000064:notes:97]
The following table presents the fair value of our financial assets measured at fair value on a recurring basis as of March 31, 2016 and December 31, 2015 (in thousands):

[0001262039-16-000064:notes:98]
|  | March 31, 2016 |  |  |  | December 31, 2015 |  |  |
|  | AggregateFairValue |  | QuotedPrices inActiveMarkets ForIdenticalAssets |  | SignificantOtherObservableRemainingInputs |  | SignificantOtherUnobservableRemainingInputs |  | AggregateFairValue |  | QuotedPrices inActiveMarkets ForIdenticalAssets |  | SignificantOtherObservableRemainingInputs |  | SignificantOtherUnobservableRemainingInputs |
|  |  |  | (Level 1) |  | (Level 2) |  | (Level 3) |  |  |  | (Level 1) |  | (Level 2) |  | (Level 3) |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate debt securities | $ | 410,589 |  |  | $ | — |  |  | $ | 410,589 |  |  | $ | — |  |  | $ | 437,194 |  |  | $ | — |  |  | $ | 437,194 |  |  | $ | — |  |
| Commercial paper | 82,962 |  |  | — |  |  | 82,962 |  |  | — |  |  | 69,231 |  |  | — |  |  | 69,231 |  |  | — |  |
| Municipal bonds | 54,244 |  |  | — |  |  | 54,244 |  |  | — |  |  | 61,022 |  |  | — |  |  | 61,022 |  |  | — |  |
| Certificates of deposit and term deposits | 19,847 |  |  | — |  |  | 19,847 |  |  | — |  |  | 14,897 |  |  | — |  |  | 14,897 |  |  | — |  |
| Money market funds | 48,599 |  |  | 48,599 |  |  | — |  |  | — |  |  | 50,030 |  |  | 50,030 |  |  | — |  |  | — |  |
| U.S. government and agency securities | 66,335 |  |  | 50,326 |  |  | 16,009 |  |  | — |  |  | 41,688 |  |  | 25,693 |  |  | 15,995 |  |  | — |  |
| Total | $ | 682,576 |  |  | $ | 98,925 |  |  | $ | 583,651 |  |  | $ | — |  |  | $ | 674,062 |  |  | $ | 75,723 |  |  | $ | 598,339 |  |  | $ | — |  |
| Reported as: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents | $ | 56,097 |  |  |  |  |  |  |  |  | $ | 53,029 |  |  |  |  |  |  |  |
| Short-term investments | 384,591 |  |  |  |  |  |  |  |  | 348,074 |  |  |  |  |  |  |  |
| Long-term investments | 241,888 |  |  |  |  |  |  |  |  | 272,959 |  |  |  |  |  |  |  |
| Total | $ | 682,576 |  |  |  |  |  |  |  |  | $ | 674,062 |  |  |  |  |  |  |  |

[0001262039-16-000064:notes:99]
There were no transfers between Level 1 and Level 2 of the fair value hierarchy during the three months ended March 31, 2016.


## us-gaap:ForeignCurrencyDisclosureTextBlock

[0001262039-16-000064:notes:100]
FOREIGN CURRENCY DERIVATIVES

[0001262039-16-000064:notes:101]
Our sales contracts are primarily denominated in U.S. dollars and therefore substantially all of our revenue is not subject to foreign currency translation risk. However, a substantial portion of our operating expenses incurred outside the United States is denominated in foreign currencies and is subject to fluctuations due to changes in foreign currency exchange rates, particularly changes in the Canadian dollar (“CAD”) and the Euro (“EUR”). To help protect against significant fluctuations in value and the volatility of future cash flows caused by changes in currency exchange rates, we engage in foreign currency risk management activities to hedge balance sheet items denominated in CAD. We do not use these contracts for speculative or trading purposes. All of the derivative instruments are with high quality financial institutions and we monitor the creditworthiness of these parties. These contracts typically have maturities between one and three months. Changes in the fair value of forward exchange contracts related to balance sheet accounts are insignificant and are included in Other expense—net in the condensed consolidated statement of operations. As of March 31, 2016, the fair value of the forward exchange contracts was not material.

[0001262039-16-000064:notes:102]
Additionally, independent of any hedging activities, fluctuations in foreign currency exchange rates may cause us to recognize transaction gains and losses in our condensed consolidated statements of operations. Our hedging activities are intended to reduce, but not eliminate, the impact of currency exchange rate movements. As our hedging activities are relatively short-term in nature and are focused on the CAD, long-term material changes in the value of the U.S. dollar against other foreign currencies, such as the EUR, GBP and CNY could adversely impact our operating expenses in the future.

[0001262039-16-000064:notes:103]
The notional amount of forward exchange contracts to hedge balance sheet accounts as of March 31, 2016 and December 31, 2015 were (in thousands):

[0001262039-16-000064:notes:104]
|  | Buy/Sell |  | Notional |
| Balance Sheet Contracts: |  |  |  |
| Currency—As of March 31, 2016 |  |  |  |
| CAD | Sell |  | $ | 8,540 |  |
| Currency—As of December 31, 2015 |  |  |  |
| CAD | Sell |  | $ | 7,011 |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001262039-16-000064:notes:105]
[same as prior period, unchanged from 0001262039-15-000048:notes:121]

[0001262039-16-000064:notes:106]
[same as prior period, unchanged from 0001262039-15-000048:notes:122]

[0001262039-16-000064:notes:107]
As of March 31, 2016, we had goodwill of $4.7 million. There were no impairments to goodwill during the three months ended March 31, 2016.

[0001262039-16-000064:notes:108]
[same as prior period, unchanged from 0001262039-15-000048:notes:125]

[0001262039-16-000064:notes:109]
The following tables present other intangible assets—net as of March 31, 2016 and December 31, 2015 (in thousands):

[0001262039-16-000064:notes:110]
|  | March 31, 2016 |
|  | Weighted-Average Useful Life (in Years) |  | Gross |  | Accumulated Amortization |  | Net |
| Other intangible assets—net: |  |  |  |  |  |  |  |
| Customer relationships | 5.0 |  | $ | 12,200 |  |  | $ | 1,830 |  |  | $ | 10,370 |  |
| Developed technologies and other | 3.6 |  | 11,384 |  |  | 5,297 |  |  | 6,087 |  |
| Total other intangible assets—net |  |  | $ | 23,584 |  |  | $ | 7,127 |  |  | $ | 16,457 |  |

[0001262039-16-000064:notes:111]
|  | December 31, 2015 |
|  | Weighted-Average Useful Life (in Years) |  | Gross |  | Accumulated Amortization |  | Net |
| Other intangible assets—net: |  |  |  |  |  |  |  |
| Customer relationships | 5.0 |  | $ | 12,200 |  |  | $ | 1,220 |  |  | $ | 10,980 |  |
| Developed technologies and other | 3.6 |  | 11,384 |  |  | 4,724 |  |  | 6,660 |  |
| Total other intangible assets—net |  |  | $ | 23,584 |  |  | $ | 5,944 |  |  | $ | 17,640 |  |

[0001262039-16-000064:notes:112]
Amortization expense was $1.2 million and $0.3 million during the three months ended March 31, 2016 and March 31, 2015, respectively. The following table summarizes estimated future amortization expense of Other intangible assets—net (in thousands):

[0001262039-16-000064:notes:113]
|  | Amount |
| Years: |  |
| 2016 (remainder) | $ | 3,417 |  |
| 2017 | 4,240 |  |
| 2018 | 4,240 |  |
| 2019 | 3,340 |  |
| 2020 | 1,220 |  |
| Total | $ | 16,457 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001262039-16-000064:notes:114]
[same as prior period, unchanged from 0001262039-15-000048:notes:132]

[0001262039-16-000064:notes:115]
Our effective tax rate was 35% for the three months ended March 31, 2016, compared to an effective tax rate of 5% for the same period last year. The effective tax rate for the periods presented was comprised of U.S. federal and state taxes, withholding taxes and foreign income taxes. The changes in the tax provision and effective tax rate were primarily because we had a pretax loss for the three months ended March 31, 2016, as compared to having a pretax income for the same period last year. Our effective tax rate for the three months ended March 31, 2016 included the tax benefit from the U.S. federal research and development (“R&D”) credit. The effective tax rate for the three months ended March 31, 2015 did not reflect the tax benefit of the U.S. federal R&D credit as it expired at the end of 2014 and was reinstated retroactively in December 2015.

[0001262039-16-000064:notes:116]
As of March 31, 2016 and December 31, 2015, unrecognized tax benefits were $63.4 million and $59.7 million, respectively. The total amount of $62.1 million in unrecognized tax benefits, if recognized, would favorably impact the effective tax rate. It is our policy to classify accrued interest and penalties related to unrecognized tax benefits in the provision for income taxes. As of March 31, 2016, we had accrued $6.7 million for estimated interest related to uncertain tax positions.

[0001262039-16-000064:notes:117]
We file income tax returns in the U.S. federal jurisdiction, and various U.S. state and foreign jurisdictions. The statute of limitations is open for years that generated state net operating loss carryforwards and after 2009 for state jurisdictions. Additionally, we have foreign net operating losses that have an indefinite life. Generally, we are no longer subject to non-U.S. income tax examinations by tax authorities for tax years prior to 2009. We are no longer subject to examination by U.S. federal tax authorities for tax years prior to 2012. We are currently under examination by U.S federal income tax authorities for the tax years 2012, 2013, and 2014.


## us-gaap:InventoryDisclosureTextBlock

[0001262039-16-000064:notes:118]
[same as prior period, unchanged from 0001262039-15-000048:notes:136]

[0001262039-16-000064:notes:119]
Inventory consisted of the following as of March 31, 2016 and December 31, 2015 (in thousands):

[0001262039-16-000064:notes:120]
|  | March 31, 2016 |  | December 31, 2015 |
| Raw materials | $ | 15,270 |  |  | $ | 15,425 |  |
| Finished goods | 62,969 |  |  | 68,443 |  |
| Inventory | $ | 78,239 |  |  | $ | 83,868 |  |

[0001262039-16-000064:notes:121]
Inventory includes finished goods held by distributors where revenue is recognized on a sell-through basis of $0.9 million and $1.1 million as of March 31, 2016 and December 31, 2015, respectively. Inventory also includes materials at contract manufacturers of $4.9 million both as of March 31, 2016 and December 31, 2015.


## us-gaap:LongLivedAssetsByGeographicAreasTableTextBlock

[0001262039-16-000064:notes:122]
| Property and Equipment—net | March 31, 2016 |  | December 31, 2015 |
| Americas: |  |  |  |
| United States | $ | 82,885 |  |  | $ | 61,064 |  |
| Other Americas | 9,021 |  |  | 8,972 |  |
| Total Americas | 91,906 |  |  | 70,036 |  |
| EMEA: |  |  |  |
| France | 14,585 |  |  | 13,201 |  |
| Other EMEA | 5,244 |  |  | 3,977 |  |
| Total EMEA | 19,829 |  |  | 17,178 |  |
| APAC | 4,047 |  |  | 3,853 |  |
| Total property and equipment—net | $ | 115,782 |  |  | $ | 91,067 |  |


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001262039-16-000064:notes:123]
Recently Adopted Accounting Standards

[0001262039-16-000064:notes:124]
In September 2015, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) 2015-16—Business Combinations—Simplifying the Accounting for Measurement-Period Adjustments, which eliminates the requirement for an acquirer in a business combination to account for measurement-period adjustments retrospectively. Instead, acquirers must recognize measurement-period adjustments during the period in which they determine the amounts, including the effect on earnings of any amounts they would have recorded in previous periods if the accounting had been completed at the acquisition date. We adopted ASU 2015-16 on January 1, 2016. The adoption of ASU 2015-16 did not have any impact on our consolidated financial statements.

[0001262039-16-000064:notes:125]
In April 2015, the FASB issued ASU 2015-05—Intangibles—Goodwill and Other—Internal—Use Software— Customer’s Accounting for Fees Paid in a Cloud Computing Arrangement, which provides guidance on determining whether a cloud computing arrangement contains a software license. If a cloud computing arrangement includes a software license, then the customer should account for the software license element of the arrangement consistent with the acquisition of other software licenses. If a cloud computing arrangement does not include a software license, the customer should account for the arrangement as a service contract. We adopted ASU 2015-05 on a prospective basis beginning on January 1, 2016. The impact of ASU 2015-05 did not have a significant impact on our consolidated financial statements.

[0001262039-16-000064:notes:126]
In February 2015, the FASB issued ASU 2015-02—Consolidation—Amendments to the Consolidation Analysis, which updates the accounting guidance on consolidation requirements. This update changes the guidance with respect to the analysis that a reporting entity must perform to determine whether it should consolidate certain types of legal entities. ASU 2015-02 also makes several modifications to the consolidation guidance for variable interest entities (“VIEs”). We adopted ASU 2015-02 on January 1, 2016. The adoption of ASU 2015-02 did not have any impact on our consolidated financial statements.

[0001262039-16-000064:notes:127]
Recent Accounting Standards Not Yet Effective

[0001262039-16-000064:notes:128]
In March 2016, the FASB issued ASU 2016-09—Compensation—Stock Compensation—Improvements to Employee Share-Based Payment Accounting, which changes certain aspects of accounting for shared-based payments to employees. The new guidance will require all income tax effects of awards to be recognized in the income statement for the period in which the awards vest or are settled. It also allows an employer to repurchase more of an employee’s shares for tax withholding purposes without triggering liability accounting and to make a policy election to account for forfeitures as they occur. This new guidance will be effective for us beginning on January 1, 2017, and interim periods within those fiscal years. Early adoption is permitted in any annual or interim period for which financial statements have not been issued or made available for issuance, but all of the guidance must be adopted in the same period. We are currently evaluating the impact ASU 2016-09 will have on our consolidated financial statements.

[0001262039-16-000064:notes:129]
In February 2016, the FASB issued ASU 2016-02—Leases, which amends lease accounting requirements to begin recording assets and liabilities arising from leases on the balance sheet. The new guidance will also require significant additional disclosures about the amount, timing and uncertainty of cash flows from leases. This new guidance will be effective for us beginning on January 1, 2019 using a modified retrospective approach. The modified retrospective approach includes a number of optional practical expedients that entities may elect to apply. We are currently evaluating the impact ASU 2016-02 will have on our consolidated financial statements.

[0001262039-16-000064:notes:130]
In January 2016, the FASB issued ASU 2016-01—Financial Instruments—Overall—Recognition and Measurement of Financial Assets and Financial Liabilities, which modifies how entities measure equity investments and present changes in the fair value of financial liabilities. Under the new guidance, entities will have to measure equity investments that do not result in consolidation and are not accounted under the equity method at fair value and recognize any changes in fair value in net income unless the investments qualify for the new practicality exception. The practicality exception will apply to those equity investments that do not have a readily determinable fair value and do not qualify for the practical expedient to estimate fair value, and as such these investments may be measured at cost. ASU 2016-01 will be effective for us beginning on January 1, 2018. We do not expect the impact of ASU 2016-01 on our consolidated financial statements to be significant.

[0001262039-16-000064:notes:131]
In July 2015, the FASB issued ASU 2015-11—Inventory—Simplifying the Measurement of Inventory, which changes the measurement principle for inventory from the lower of cost or market to lower of cost and net realizable value. ASU 2015-11 applies to entities that measure inventory using a method other than last-in, first-out or the retail inventory method (e.g., first-in, first-out or average cost). ASU 2015-11 will be effective for us beginning on January 1, 2017. We do not expect the impact of ASU 2015-11 on our consolidated financial statements to be significant.

[0001262039-16-000064:notes:132]
In May 2014, the FASB issued ASU 2014-09—Revenue from Contracts with Customers, which creates a single, joint revenue standard that is consistent across all industries and markets for companies that prepare their financial statements in accordance with GAAP. Under ASU 2014-09, an entity is required to recognize revenue upon the transfer of promised goods or services to customers in an amount that reflects the consideration the entity expects to be entitled to receive in exchange for those goods or services. In July 2015, the FASB decided to delay the effective date of the new revenue standard by one year. In March 2016, the FASB issued ASU 2016-08, which clarifies the implementation guidance on principal versus agent considerations. In April 2016, the FASB issued ASU 2016-10, which clarifies the implementation guidance on identifying performance obligations and licensing. These standards will be effective for us beginning on January 1, 2018, with the option to adopt earlier on January 1, 2017. We are currently evaluating the impact of these new standards on our consolidated financial statements.


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001262039-16-000064:notes:133]
[same as prior period, unchanged from 0001262039-15-000048:notes:146]

[0001262039-16-000064:notes:134]
Property and equipment—net as of March 31, 2016 and December 31, 2015 consisted of the following (in thousands):

[0001262039-16-000064:notes:135]
|  | March 31, 2016 |  | December 31, 2015 |
| Land | $ | 30,321 |  |  | $ | 21,683 |  |
| Building and building improvements | 39,454 |  |  | 28,841 |  |
| Evaluation units | 18,413 |  |  | 15,784 |  |
| Computer equipment and software | 49,701 |  |  | 45,632 |  |
| Furniture and fixtures | 10,536 |  |  | 8,901 |  |
| Construction-in-progress | 8,796 |  |  | 8,106 |  |
| Leasehold improvements | 13,182 |  |  | 11,179 |  |
| Total property and equipment | 170,403 |  |  | 140,126 |  |
| Less: accumulated depreciation | (54,621 | ) |  | (49,059 | ) |
| Property and equipment—net | $ | 115,782 |  |  | $ | 91,067 |  |

[0001262039-16-000064:notes:136]
During the first quarter of 2016, we purchased certain real property in Union City, California, for cash of $18.5 million to support the growth in our business operations. Of the total cost, we allocated $8.7 million to land and $9.8 million to building.

[0001262039-16-000064:notes:137]
Depreciation expense was $9.4 million and $6.0 million during the three months ended March 31, 2016 and March 31, 2015, respectively.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001262039-16-000064:notes:138]
RELATED PARTY TRANSACTIONS

[0001262039-16-000064:notes:139]
The son of one member of our board of directors is a partner of an outside law firm that we utilize for certain complex litigation matters. Expenses for legal services provided by the law firm related to matters that arose subsequent to the member joining our board of directors were $0.3 million and $1.9 million in the three months ended March 31, 2016 and March 31, 2015, respectively. Of such amounts, $0.2 million and $0.5 million were incurred under contingent fee arrangements in the three months ended March 31, 2016 and March 31, 2015, respectively. Amounts due and payable to the law firm were $0.4 million and $5.3 million as of March 31, 2016 and December 31, 2015, respectively.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001262039-16-000064:notes:140]
[same as prior period, unchanged from 0001262039-15-000048:notes:152]

[0001262039-16-000064:notes:141]
In connection with the acquisition of Meru, we initiated planned cost reduction and restructuring activities to improve our cost structure and operational efficiencies starting in the third quarter of 2015. We estimate that we will incur $8.0 million to $8.5 million of restructuring charges, consisting of severance and other benefits, contract terminations and other charges. We incurred $0.3 million of restructuring charges during the three months ended March 31, 2016, which are included in operating expense in the condensed consolidated statements of operations. To date, we have incurred $7.9 million of charges related to this restructuring. These charges are primarily related to severance payments to be paid in cash.

[0001262039-16-000064:notes:142]
The following table provides a summary of restructuring activity as of March 31, 2016 (in thousands):

[0001262039-16-000064:notes:143]
|  | Employee Severance and Other Benefits |  | Contract Terminations and Other Charges |  | Total |
| Balance as of December 31, 2015 | $ | 3,689 |  |  | $ | 229 |  |  | $ | 3,918 |  |
| Costs incurred | 328 |  |  | — |  |  | 328 |  |
| Less cash payments | (1,282 | ) |  | (125 | ) |  | (1,407 | ) |
| Less non-cash charges | (89 | ) |  | — |  |  | (89 | ) |
| Balance as of March 31, 2016 | $ | 2,646 |  |  | $ | 104 |  |  | $ | 2,750 |  |

[0001262039-16-000064:notes:144]
Cash payments for the restructuring activities are expected to be made through 2017, primarily relating to severance payments. The short-term portion of the restructuring reserve of $2.5 million is included in accrued liabilities and the remaining long-term portion of $0.2 million is included in other liabilities on the condensed consolidated balance sheet as of March 31, 2016.


## us-gaap:RevenueFromExternalCustomersByGeographicAreasTableTextBlock

[0001262039-16-000064:notes:145]
|  | Three Months Ended |
| Revenue | March 31, 2016 |  | March 31, 2015 |
| Americas: |  |  |  |
| United States | $ | 75,558 |  |  | $ | 58,501 |  |
| Canada | 31,305 |  |  | 20,458 |  |
| Other Americas | 13,183 |  |  | 12,601 |  |
| Total Americas | 120,046 |  |  | 91,560 |  |
| Europe, Middle East, and Africa (“EMEA”) | 105,491 |  |  | 75,664 |  |
| Asia Pacific (“APAC”) | 59,039 |  |  | 45,662 |  |
| Total revenue | $ | 284,576 |  |  | $ | 212,886 |  |


## us-gaap:ScheduleOfRevenueByMajorCustomersByReportingSegmentsTableTextBlock

[0001262039-16-000064:notes:146]
The following customer, which is a distributor, accounted for 10% or more of our revenue:

[0001262039-16-000064:notes:147]
|  | Three Months Ended |
|  | March 31, 2016 |  | March 31, 2015 |
| Exclusive Networks Group | 19 | % |  | 17 | % |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001262039-16-000064:notes:148]
[same as prior period, unchanged from 0001262039-15-000048:notes:161]

[0001262039-16-000064:notes:149]
[same as prior period, unchanged from 0001262039-15-000048:notes:162]

[0001262039-16-000064:notes:150]
Revenue by geographic region is based on the billing address of the customer. The following tables set forth revenue and property and equipment—net by geographic region (in thousands):


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001262039-16-000064:notes:151]
[same as prior period, unchanged from 0001262039-15-000048:notes:163]
