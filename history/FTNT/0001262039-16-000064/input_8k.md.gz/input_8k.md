# FTNT 8-K — 0001262039-16-000061 filed 2016-04-26

## item codes, every 8-K on or before 2016-05-06

- 2016-04-26 0001262039-16-000061 — 2.02, 9.01
- 2016-01-28 0001262039-16-000051 — 2.02, 9.01
- 2015-10-27 0001262039-15-000045 — 2.02
- 2015-10-22 0001262039-15-000042 — 5.02 — amendment, the index does not say of what
- 2015-10-22 0001262039-15-000041 — 5.02 — amendment, the index does not say of what
- 2015-10-22 0001262039-15-000039 — 2.02, 9.01
- 2015-09-28 0001262039-15-000034 — 5.02, 9.01
- 2015-09-22 0001262039-15-000031 — 9.01 — amendment of 0001193125-15-248065
- 2015-08-28 0001262039-15-000027 — 3.01, 5.02
- 2015-07-23 0001262039-15-000021 — 5.02
- 2015-07-22 0001262039-15-000019 — 2.02, 9.01
- 2015-07-08 0001193125-15-248065 — 2.01, 8.01, 9.01
- 2015-06-22 0001193125-15-229099 — 5.07
- 2015-06-19 0001193125-15-228428 — 5.02, 9.01
- 2015-04-20 0001262039-15-000014 — 2.02, 9.01
- 2015-01-28 0001262039-15-000005 — 2.02, 9.01
- 2014-10-22 0001262039-14-000036 — 2.02, 9.01
- 2014-07-23 0001262039-14-000030 — 2.02, 9.01
- 2014-06-24 0001262039-14-000027 — 5.07
- 2014-04-23 0001262039-14-000021 — 2.02, 9.01
- 2014-04-21 0001262039-14-000018 — 5.03, 9.01
- 2014-01-29 0001262039-14-000004 — 2.02, 9.01
- 2013-12-20 0001262039-13-000061 — 5.02, 9.01
- 2013-11-27 0001262039-13-000057 — 5.02, 7.01, 9.01
- 2013-11-12 0001445305-13-002993 — 5.02
- 2013-10-23 0001262039-13-000051 — 2.02, 9.01
- 2013-07-30 0001262039-13-000039 — 2.02, 9.01
- 2013-06-25 0001262039-13-000030 — 5.07
- 2013-04-30 0001262039-13-000023 — 2.02, 9.01
- 2013-04-19 0001262039-13-000020 — 5.02, 9.01
- 2013-04-19 0001262039-13-000018 — 5.02 — amendment of 0001262039-13-000020
- 2013-04-10 0001262039-13-000016 — 2.02, 9.01
- 2013-03-26 0001262039-13-000013 — 5.02
- 2013-01-30 0001262039-13-000005 — 2.02, 9.01
- 2013-01-24 0001262039-13-000002 — 5.02, 9.01
- 2012-10-16 0001262039-12-000048 — 2.02, 9.01
- 2012-10-01 0001262039-12-000045 — 5.02
- 2012-09-26 0001262039-12-000043 — 5.01
- 2012-07-25 0001262039-12-000038 — 2.02, 9.01
- 2012-07-19 0001262039-12-000034 — 5.02
- 2012-06-20 0001193125-12-275869 — 5.07
- 2012-04-27 0001262039-12-000029 — 5.02
- 2012-04-24 0001262039-12-000025 — 2.02, 9.01
- 2012-01-31 0001262039-12-000006 — 2.02, 9.01
- 2012-01-25 0001262039-12-000003 — 5.03
- 2011-10-24 0001262039-11-000036 — 2.02
- 2011-07-19 0001262039-11-000014 — 2.02, 9.01
- 2011-06-27 0001193125-11-174474 — 5.02, 5.07, 9.01
- 2011-04-27 0001193125-11-111938 — 2.02, 9.01
- 2011-01-25 0001193125-11-013914 — 2.02, 9.01
- 2010-10-21 0001193125-10-233676 — 2.02, 9.01
- 2010-09-02 0001193125-10-203099 — 8.01
- 2010-07-22 0001193125-10-163844 — 2.02, 9.01
- 2010-06-24 0001193125-10-146082 — 5.07
- 2010-04-28 0001193125-10-096698 — 2.02, 9.01
- 2010-02-09 0001193125-10-024614 — 8.01
- 2010-01-27 0001193125-10-014292 — 2.02, 9.01
- 2010-01-26 0001193125-10-013031 — 5.02, 9.01

## late-filing notifications on or before 2016-05-06

- none on or before 2016-05-06

## item 2.02 — earnings release, exhibit 99.1

[0001262039-16-000061:8k_2_02:1]
EX-99.1
2
ftntq1-2016ex991.htm
PRESS RELEASE

[0001262039-16-000061:8k_2_02:2]
Exhibit

[0001262039-16-000061:8k_2_02:3]
Press Release

[0001262039-16-000061:8k_2_02:4]
| Investor Contact: |  | Media Contact: |
| Michelle Spolver |  | Sandra Wheatley |
| Fortinet, Inc. |  | Fortinet, Inc. |
| 408-486-7837 |  | 408-391-9408 |
| mspolver@fortinet.com |  | swheatley@fortinet.com |

[0001262039-16-000061:8k_2_02:5]
Fortinet Reports First Quarter 2016 Financial Results

[0001262039-16-000061:8k_2_02:6]
Fortinet’s Security Fabric Offerings and Strong Execution Drive Revenue Growth of 34% Year Over Year

[0001262039-16-000061:8k_2_02:7]
•Billings of $330.5 million, up 30% year over year1

[0001262039-16-000061:8k_2_02:8]
•Revenue of $284.6 million, up 34% year over year

[0001262039-16-000061:8k_2_02:9]
•Non-GAAP diluted net income per share of $0.121

[0001262039-16-000061:8k_2_02:10]
•Cash flow from operations of $100.6 million

[0001262039-16-000061:8k_2_02:11]
•Free cash flow of $70.6 million1

[0001262039-16-000061:8k_2_02:12]
| • | Cash, cash equivalents and investments of $1.19 billion |

[0001262039-16-000061:8k_2_02:13]
| • | Deferred revenue of $837.2 million, up 39% year over year |

[0001262039-16-000061:8k_2_02:14]
SUNNYVALE, Calif. - April 26, 2016 - Fortinet® (NASDAQ: FTNT), a global leader in high performance cyber security solutions, today announced financial results for the first quarter ended March 31, 2016.

[0001262039-16-000061:8k_2_02:15]
“During the first quarter, Fortinet executed very well and outperformed across all key metrics,” said Ken Xie, founder, chairman and chief executive officer. “The increasing complexity of the IT security landscape is driving customer adoption of broad, integrated platforms, which has been our vision from the company’s inception. Fortinet’s Security Fabric is a strategic asset, since it allows customers to protect and gain intelligence on all points in the network - from IoT to cloud - through a unified operating system and management platform.  This, along with recently announced products like our FortiGate-6000E Series of high-performance systems, strengthens our competitive position, expands our market opportunity, and helps to drive continued growth in 2016 and beyond.”

[0001262039-16-000061:8k_2_02:16]
Financial Highlights for the First Quarter of 2016

[0001262039-16-000061:8k_2_02:17]
| • | Billings1: Total billings were $330.5 million for the first quarter of 2016, an increase of 30% compared to $254.3 million in the same quarter of 2015. |

[0001262039-16-000061:8k_2_02:18]
| • | Revenue: Total revenue was $284.6 million for the first quarter of 2016, an increase of 34% compared to $212.9 million in the same quarter of 2015. Within total revenue, product revenue was $124.6 million, an increase of 28% compared to $97.5 million in |

[0001262039-16-000061:8k_2_02:19]
the same quarter of 2015. Service revenue was $160.0 million, an increase of 39% compared to $115.4 million in the same quarter of 2015.

[0001262039-16-000061:8k_2_02:20]
| • | Deferred Revenue: Total deferred revenue was $837.2 million as of March 31, 2016, an increase of $45.9 million compared to $791.3 million as of December 31, 2015. |

[0001262039-16-000061:8k_2_02:21]
| • | Cash and Cash Flow2: As of March 31, 2016, cash, cash equivalents and investments were $1.19 billion, compared to $1.16 billion as of December 31, 2015. In the first quarter of 2016, cash flow from operations was $100.6 million compared to $64.6 million in the same quarter of 2015. Free cash flow1 was $70.6 million during the first quarter of 2016 compared to $59.7 million in the same quarter of 2015. |

[0001262039-16-000061:8k_2_02:22]
| • | GAAP Operating Income or Loss: GAAP operating loss was $5.7 million for the first quarter of 2016, representing a GAAP operating margin of -2%. GAAP operating income was $0.9 million for the same quarter of 2015, representing a GAAP operating margin of 0.4%. |

[0001262039-16-000061:8k_2_02:23]
| • | Non-GAAP Operating Income1: Non-GAAP operating income was $30.1 million for the first quarter of 2016, representing a non-GAAP operating margin of 11%. Non-GAAP operating income was $20.1 million for the same quarter of 2015, representing a non-GAAP operating margin of 9%. |

[0001262039-16-000061:8k_2_02:24]
| • | GAAP Net Income or Loss and Diluted Net Income or Loss Per Share: GAAP net loss was $3.4 million for the first quarter of 2016, compared to GAAP net income of $1.6 million for the same quarter of 2015. GAAP diluted net loss per share was $0.02 for the first quarter of 2016, compared to GAAP diluted net income per share of $0.01 for the same quarter of 2015. |

[0001262039-16-000061:8k_2_02:25]
| • | Non-GAAP Net Income and Diluted Net Income Per Share1: Non-GAAP net income was $20.1 million for the first quarter of 2016, compared to non-GAAP net income of $13.5 million for the same quarter of 2015. Non-GAAP diluted net income per share was $0.12 for the first quarter of 2016, compared to $0.08 for the same quarter of 2015. |

[0001262039-16-000061:8k_2_02:26]
1 A reconciliation of GAAP to non-GAAP financial measures has been provided in the financial statement tables included in this press release. An explanation of these measures is also included below under the heading “Non-GAAP Financial Measures.”

[0001262039-16-000061:8k_2_02:27]
2 During the first quarter of 2016, we repurchased $50.0 million of our common stock under our share repurchase program. During the first quarter of 2015, there were no shares repurchased under our repurchase program.

[0001262039-16-000061:8k_2_02:28]
Conference Call Details

[0001262039-16-000061:8k_2_02:29]
Fortinet will host a conference call today, April 26, 2016, at 1:30 p.m. Pacific Time (4:30 p.m. Eastern Time) to discuss its financial results. To access this call, dial (877) 303-6913 (domestic) or (224) 357-2188 (international) with conference ID # 82225827. A live webcast of the conference call and supplemental slides will be accessible from the Investor Relations page of Fortinet's website at http://investor.fortinet.com and a replay will be archived and accessible at http://investor.fortinet.com/events.cfm.  A replay of this conference call can also be accessed through May 3, 2016, by dialing (855) 859-2056 (domestic) or (404) 537-3406 (international) with conference ID# 82225827.

[0001262039-16-000061:8k_2_02:30]
Following Fortinet's financial results conference call, the Company will host an additional question-and-answer session at 3:30 p.m. Pacific Time (6:30 p.m. Eastern Time) to provide an

[0001262039-16-000061:8k_2_02:31]
opportunity for financial analysts and investors to ask more detailed questions. To access this call, dial (877) 303-6913 (domestic) or (224) 357-2188 (international) with conference ID # 82229345. This follow-up call will be webcast live and accessible at http://investor.fortinet.com, and a replay will be archived and available after the call at http://investor.fortinet.com/events.cfm. A replay of this conference call will also be available through May 3, 2016 by dialing (855) 859-2056 (domestic) or (404) 537-3406 (international) with conference ID # 82229345.

[0001262039-16-000061:8k_2_02:32]
About Fortinet (www.fortinet.com)

[0001262039-16-000061:8k_2_02:33]
Fortinet (NASDAQ: FTNT) protects the most valuable assets of some of the largest enterprise, service provider and government organizations across the globe. The company’s fast, secure and global cyber security solutions provide broad, high-performance protection against dynamic security threats while simplifying the IT infrastructure. They are strengthened by the industry’s highest level of threat research, intelligence and analytics. Unlike pure-play network security providers, Fortinet can solve organizations’ most important security challenges, whether in networked, application or mobile environments - be it virtualized/cloud or physical. More than 270,000 customers worldwide, including some of the largest and most complex organizations, trust Fortinet to protect their brands. Learn more at www.fortinet.com, the Fortinet Blog or FortiGuard Labs.

[0001262039-16-000061:8k_2_02:34]
#          #          #

[0001262039-16-000061:8k_2_02:35]
Copyright © 2016 Fortinet, Inc. All rights reserved. The symbols ® and ™ denote respectively federally registered trademarks and unregistered trademarks of Fortinet, Inc., its subsidiaries and affiliates. Fortinet's trademarks include, but are not limited to, the following: Fortinet, FortiGate, FortiGuard, FortiManager, FortiMail, FortiClient, FortiCloud, FortiCare, FortiAnalyzer, FortiReporter, FortiOS, FortiASIC, FortiWiFi, FortiSwitch, FortiVoIP, FortiBIOS, FortiLog, FortiResponse, FortiCarrier, FortiScan, FortiAP, FortiDB, FortiVoice and FortiWeb. Other trademarks belong to their respective owners.

[0001262039-16-000061:8k_2_02:36]
FTNT-F

[0001262039-16-000061:8k_2_02:37]
Forward-looking Statements

[0001262039-16-000061:8k_2_02:38]
This press release contains forward-looking statements that involve risks and uncertainties. These forward-looking statements include statements regarding market adoption of cybersecurity and Fortinet’s future growth potential. Although we attempt to be accurate in making forward-looking statements, it is possible that future circumstances might differ from the assumptions on which such statements are based. Important factors that could cause results to differ materially from the statements herein include the following: general economic risks; global economic conditions and foreign currency risks; increasing competitiveness in the security market; the dynamic nature of the security market; specific economic risks worldwide and in different geographies, and among different customer segments; uncertainty regarding increased business and renewals from existing customers; uncertainties around continued success in sales growth and market share gains; longer sales cycles, particularly for larger enterprise customers; failure to convert sales pipeline into final sales; risks associated with successful implementation of multiple integrated software products and other product functionality risks; execution risks around new product development and introductions, and innovation and market acceptance of new products; litigation and disputes and the potential cost, distraction and damage to sales and reputation caused thereby; market acceptance of new products and services; the ability to attract and retain personnel; changes in strategy; risks associated with management of growth; lengthy sales and implementation cycles, particularly in larger organizations; technological changes that make our products and services less competitive; risks associated with the adoption of, and demand for, our products and services in general and

[0001262039-16-000061:8k_2_02:39]
Non-GAAP Financial Measures

[0001262039-16-000061:8k_2_02:40]
We have provided in this release financial information that has not been prepared in accordance with Generally Accepted Accounting Principles (GAAP). These non-GAAP financial measures are not based on any standardized methodology prescribed by GAAP and are not necessarily comparable to similar measures presented by other companies. We use these non-GAAP financial measures internally in analyzing our financial results and believe they are useful to investors, as a supplement to GAAP measures, in evaluating our ongoing operational performance. We believe that the use of these non-GAAP financial measures provides an additional tool for investors to use in evaluating ongoing operating results and trends and in comparing our financial results with peer companies, many of which present similar non-GAAP financial measures to investors.

[0001262039-16-000061:8k_2_02:41]
Non-GAAP financial measures should not be considered in isolation from, or as a substitute for, financial information prepared in accordance with GAAP. Investors are encouraged to review the reconciliation of these non-GAAP financial measures to their most directly comparable GAAP financial measures provided in the financial statement tables below.

[0001262039-16-000061:8k_2_02:42]
Billings. We define billings as revenue recognized in accordance with GAAP plus the change in deferred revenue from the beginning to the end of the period less any deferred revenue balances acquired from business combination(s) during the period. We consider billings to be a useful metric for management and investors because billings drives future revenue, which is an important indicator of the health and viability of our business. There are a number of limitations related to the use of billings instead of GAAP revenue. First, billings include amounts that have not yet been recognized as revenue. Second, we may calculate billings in a manner that is different from peer companies that report similar financial measures. Management accounts for these limitations by providing specific information regarding GAAP revenue and evaluating billings together with GAAP revenue.

[0001262039-16-000061:8k_2_02:43]
Free cash flow. We define free cash flow as net cash provided by operating activities minus capital expenditures such as purchases of property and equipment. We consider free cash flow to be a liquidity measure that provides useful information to management and investors about the amount of cash generated by the business that, after the acquisition of property and equipment, can be used for strategic opportunities, including investing in our business, making strategic acquisitions, repurchasing outstanding common stock, and strengthening the balance sheet. Analysis of free cash flow facilitates management’s comparison of our operating results to those of our peer companies. A limitation of using free cash flow rather than the GAAP measure of net cash provided by operating activities as a means for evaluating liquidity is that free cash flow does not represent the total increase or decrease in the cash, cash equivalents and investments balance for the period because it excludes cash provided by or used for other investing and financing activities. Management accounts for this limitation by providing information about our capital expenditures and other investing and financing activities on the face of the cash flow statement and under the caption “Management’s Discussion and Analysis

[0001262039-16-000061:8k_2_02:44]
of Financial Condition and Results of Operations - Liquidity and Capital Resources” in our most recent Quarterly Report on Form 10-Q and Annual Report on Form 10-K.

[0001262039-16-000061:8k_2_02:45]
Non-GAAP operating income and operating margin. We define non-GAAP operating income as operating income or loss plus stock-based compensation, business acquisition-related charges, including inventory fair value adjustment amortization and other purchase accounting adjustments, impairment and amortization of acquired intangible assets, restructuring charges, expenses associated with the implementation of a new Enterprise Resource Planning (ERP) system, and, when applicable, any other significant non-recurring items in a given quarter. Non-GAAP operating margin is defined as non-GAAP operating income divided by GAAP revenue. We consider these non-GAAP financial measures to be useful metrics for management and investors because they exclude the items noted above so that our management and investors can compare our recurring core business operating results over multiple periods. There are a number of limitations related to the use of non-GAAP operating income instead of operating income or loss calculated in accordance with GAAP. First, non-GAAP operating income excludes the items noted above. Stock-based compensation has been and will continue to be, for the foreseeable future, a significant recurring expense in our business. Second, stock-based compensation is an important part of our employees’ compensation and may impact their performance. Third, the components of the costs that we exclude from our calculation of non-GAAP operating income may differ from the components that peer companies exclude when they report their non-GAAP results of operations. Management accounts for these limitations by providing specific information regarding the GAAP amounts excluded from non-GAAP operating income and evaluating non-GAAP operating income together with operating income or loss calculated in accordance with GAAP.

[0001262039-16-000061:8k_2_02:46]
Non-GAAP net income and diluted net income per share. We define non-GAAP net income as net income or loss plus the items noted above under non-GAAP operating income and operating margin, adjusted for the impact of the tax adjustment, if any required, resulting in an effective tax rate on a non-GAAP basis, which often differs from the GAAP effective tax rate. We define non-GAAP diluted net income per share as non-GAAP net income divided by the weighted-average diluted shares outstanding. We consider these non-GAAP financial measures to be useful metrics for management and investors for the same reasons that we use non-GAAP operating income and non-GAAP operating margin. However, in order to provide a complete picture of our recurring core business operating results, we include in non-GAAP net income and non-GAAP diluted net income per share, the tax adjustment required resulting in an effective tax rate on a non-GAAP basis, which often differs from the GAAP tax rate. We believe the effective tax rates we used are reasonable estimates of normalized tax rates for our current and prior fiscal years under our global operating structure. The same limitations described above regarding our use of non-GAAP operating income and non-GAAP operating margin apply to our use of non-GAAP net income and non-GAAP diluted net income per share. We account for these limitations by providing specific information regarding the GAAP amounts excluded from non-GAAP net income and non-GAAP diluted net income per share and evaluating non-GAAP net income and non-GAAP diluted net income per share together with net income or loss and diluted net income or loss per share calculated in accordance with GAAP.

[0001262039-16-000061:8k_2_02:47]
FORTINET, INC.

[0001262039-16-000061:8k_2_02:48]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001262039-16-000061:8k_2_02:49]
(Unaudited, in thousands)

[0001262039-16-000061:8k_2_02:50]
|  | March 31, 2016 |  | December 31, 2015 |
| ASSETS |  |  |  |
| CURRENT ASSETS: |  |  |  |
| Cash and cash equivalents | $ | 568,008 |  |  | $ | 543,277 |  |
| Short-term investments | 384,591 |  |  | 348,074 |  |
| Accounts receivable—net | 220,135 |  |  | 259,563 |  |
| Inventory | 78,239 |  |  | 83,868 |  |
| Prepaid expenses and other current assets | 34,728 |  |  | 35,761 |  |
| Total current assets | 1,285,701 |  |  | 1,270,543 |  |
| LONG-TERM INVESTMENTS | 241,888 |  |  | 272,959 |  |
| DEFFERRED TAX ASSETS | 131,696 |  |  | 119,216 |  |
| PROPERTY AND EQUIPMENT—net | 115,782 |  |  | 91,067 |  |
| OTHER INTANGIBLE ASSETS—net | 16,457 |  |  | 17,640 |  |
| GOODWILL | 4,692 |  |  | 4,692 |  |
| OTHER ASSETS | 15,305 |  |  | 14,393 |  |
| TOTAL ASSETS | $ | 1,811,521 |  |  | $ | 1,790,510 |  |
| LIABILITIES AND STOCKHOLDERS' EQUITY |  |  |  |
| CURRENT LIABILITIES: |  |  |  |
| Accounts payable | $ | 47,955 |  |  | $ | 61,500 |  |
| Accrued liabilities | 33,543 |  |  | 33,028 |  |
| Accrued payroll and compensation | 58,165 |  |  | 61,111 |  |
| Income taxes payable | 9,230 |  |  | 8,379 |  |
| Deferred revenue | 538,449 |  |  | 514,652 |  |
| Total current liabilities | 687,342 |  |  | 678,670 |  |
| DEFERRED REVENUE | 298,739 |  |  | 276,651 |  |
| INCOME TAXES LIABILITIES | 65,163 |  |  | 60,624 |  |
| OTHER LIABILITIES | 17,874 |  |  | 19,188 |  |
| Total liabilities | 1,069,118 |  |  | 1,035,133 |  |
| STOCKHOLDERS' EQUITY: |  |  |  |
| Common stock | 171 |  |  | 171 |  |
| Additional paid-in capital | 718,849 |  |  | 687,658 |  |
| Accumulated other comprehensive income (loss) | 294 |  |  | (933 | ) |
| Retained earnings | 23,089 |  |  | 68,481 |  |
| Total stockholders’ equity | 742,403 |  |  | 755,377 |  |
| TOTAL LIABILITIES AND STOCKHOLDERS’ EQUITY | $ | 1,811,521 |  |  | $ | 1,790,510 |  |

[0001262039-16-000061:8k_2_02:51]
FORTINET, INC.

[0001262039-16-000061:8k_2_02:52]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001262039-16-000061:8k_2_02:53]
(Unaudited, in thousands, except per share amounts)

[0001262039-16-000061:8k_2_02:54]
|  | Three Months Ended |
|  | March 31, 2016 |  | March 31, 2015 |
| REVENUE: |  |  |  |
| Product | $ | 124,572 |  |  | $ | 97,509 |  |
| Service | 160,004 |  |  | 115,377 |  |
| Total revenue | 284,576 |  |  | 212,886 |  |
| COST OF REVENUE: |  |  |  |
| Product 1 | 49,359 |  |  | 41,368 |  |
| Service 1 | 28,390 |  |  | 22,234 |  |
| Total cost of revenue | 77,749 |  |  | 63,602 |  |
| GROSS PROFIT: |  |  |  |
| Product | 75,213 |  |  | 56,141 |  |
| Service | 131,614 |  |  | 93,143 |  |
| Total gross profit | 206,827 |  |  | 149,284 |  |
| OPERATING EXPENSES: |  |  |  |
| Research and development 1 | 44,966 |  |  | 35,816 |  |
| Sales and marketing 1 | 147,403 |  |  | 100,609 |  |
| General and administrative 1 | 19,802 |  |  | 11,961 |  |
| Restructuring charges | 328 |  |  | — |  |
| Total operating expenses | 212,499 |  |  | 148,386 |  |
| OPERATING INCOME (LOSS) | (5,672 | ) |  | 898 |  |
| INTEREST INCOME | 1,746 |  |  | 1,422 |  |
| OTHER EXPENSE—net | (1,312 | ) |  | (677 | ) |
| INCOME (LOSS) BEFORE INCOME TAXES | (5,238 | ) |  | 1,643 |  |
| PROVISION FOR (BENEFIT FROM) INCOME TAXES | (1,809 | ) |  | 83 |  |
| NET INCOME (LOSS) | $ | (3,429 | ) |  | $ | 1,560 |  |
| Net income (loss) per share: |  |  |  |
| Basic | $ | (0.02 | ) |  | $ | 0.01 |  |
| Diluted | $ | (0.02 | ) |  | $ | 0.01 |  |
| Weighted-average shares outstanding: |  |  |  |
| Basic | 171,745 |  |  | 168,077 |  |
| Diluted | 171,745 |  |  | 173,720 |  |
| 1 Includes stock-based compensation as follows: |  |  |  |
| Cost of product revenue | $ | 326 |  |  | $ | 140 |  |
| Cost of service revenue | 2,193 |  |  | 1,632 |  |
| Research and development | 7,355 |  |  | 5,157 |  |
| Sales and marketing | 17,114 |  |  | 9,307 |  |
| General and administrative | 3,893 |  |  | 2,686 |  |
|  | $ | 30,881 |  |  | $ | 18,922 |  |

[0001262039-16-000061:8k_2_02:55]
FORTINET, INC.

[0001262039-16-000061:8k_2_02:56]
CONDENSED CONSOLIDATED STATEMENTS OF COMPREHENSIVE INCOME (LOSS)

[0001262039-16-000061:8k_2_02:57]
(Unaudited, in thousands)

[0001262039-16-000061:8k_2_02:58]
|  | Three Months Ended |
|  | March 31, 2016 |  | March 31, 2015 |
| Net income (loss) | $ | (3,429 | ) |  | $ | 1,560 |  |
| Other comprehensive income—net of taxes: |  |  |  |
| Unrealized gains on investments | 1,888 |  |  | 885 |  |
| Tax provision related to items of other comprehensive income | (661 | ) |  | (310 | ) |
| Other comprehensive income—net of taxes | 1,227 |  |  | 575 |  |
| Comprehensive income (loss) | $ | (2,202 | ) |  | $ | 2,135 |  |

[0001262039-16-000061:8k_2_02:59]
FORTINET, INC.

[0001262039-16-000061:8k_2_02:60]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001262039-16-000061:8k_2_02:61]
(Unaudited, in thousands)

[0001262039-16-000061:8k_2_02:62]
|  | Three Months Ended |
|  | March 31, 2016 |  | March 31, 2015 |
| CASH FLOWS FROM OPERATING ACTIVITIES: |  |  |  |
| Net income (loss) | $ | (3,429 | ) |  | $ | 1,560 |  |
| Adjustments to reconcile net income (loss) to net cash provided by operating activities: |  |  |  |
| Depreciation and amortization | 10,550 |  |  | 6,353 |  |
| Amortization of investment premiums | 1,497 |  |  | 1,938 |  |
| Stock-based compensation | 30,881 |  |  | 18,880 |  |
| Other non-cash items—net | (372 | ) |  | 159 |  |
| Changes in operating assets and liabilities: |  |  |  |
| Accounts receivable—net | 38,920 |  |  | 23,621 |  |
| Inventory | (527 | ) |  | (6,296 | ) |
| Deferred tax assets | (13,141 | ) |  | (7,918 | ) |
| Prepaid expenses and other current assets | 1,029 |  |  | (1,203 | ) |
| Other assets | (911 | ) |  | 507 |  |
| Accounts payable | (11,426 | ) |  | (11,305 | ) |
| Accrued liabilities | 300 |  |  | (3,450 | ) |
| Accrued payroll and compensation | (2,945 | ) |  | (3,149 | ) |
| Other liabilities | (1,332 | ) |  | (1,569 | ) |
| Deferred revenue | 46,106 |  |  | 40,696 |  |
| Income taxes payable | 5,391 |  |  | 5,795 |  |
| Net cash provided by operating activities | 100,591 |  |  | 64,619 |  |
| CASH FLOWS FROM INVESTING ACTIVITIES: |  |  |  |
| Purchases of investments | (115,672 | ) |  | (120,991 | ) |
| Sales of investments | 2,867 |  |  | 6,679 |  |
| Maturities of investments | 108,557 |  |  | 135,363 |  |
| Purchases of property and equipment | (29,956 | ) |  | (4,927 | ) |
| Net cash provided by (used in) investing activities | (34,204 | ) |  | 16,124 |  |
| CASH FLOWS FROM FINANCING ACTIVITIES: |  |  |  |
| Proceeds from issuance of common stock | 17,785 |  |  | 28,955 |  |
| Taxes paid related to net share settlement of equity awards | (9,441 | ) |  | (6,600 | ) |
| Repurchase and retirement of common stock | (50,000 | ) |  | — |  |
| Net cash provided by (used in) financing activities | (41,656 | ) |  | 22,355 |  |
| NET INCREASE IN CASH AND CASH EQUIVALENTS | 24,731 |  |  | 103,098 |  |
| CASH AND CASH EQUIVALENTS—Beginning of period | 543,277 |  |  | 283,254 |  |
| CASH AND CASH EQUIVALENTS—End of period | $ | 568,008 |  |  | $ | 386,352 |  |

[0001262039-16-000061:8k_2_02:63]
Reconciliations of non-GAAP results of operations measures to the nearest comparable GAAP measures

[0001262039-16-000061:8k_2_02:64]
(Unaudited, in thousands)

[0001262039-16-000061:8k_2_02:65]
Reconciliation of GAAP revenue to billings

[0001262039-16-000061:8k_2_02:66]
|  | Three Months Ended |
|  | March 31, 2016 |  | March 31, 2015 |
| Total revenue | $ | 284,576 |  |  | $ | 212,886 |  |
| Add increase in deferred revenue | 45,885 |  |  | 41,414 |  |
| Total billings (Non-GAAP) | $ | 330,461 |  |  | $ | 254,300 |  |

[0001262039-16-000061:8k_2_02:67]
Reconciliation of net cash provided by operating activities to free cash flow

[0001262039-16-000061:8k_2_02:68]
|  | Three Months Ended |
|  | March 31, 2016 |  | March 31, 2015 |
| Net cash provided by operating activities | $ | 100,591 |  |  | $ | 64,619 |  |
| Less purchases of property and equipment | (29,956 | ) |  | (4,927 | ) |
| Free cash flow (Non-GAAP) | $ | 70,635 |  |  | $ | 59,692 |  |

[0001262039-16-000061:8k_2_02:69]
Reconciliation of non-GAAP results of operations to the nearest comparable GAAP measures

[0001262039-16-000061:8k_2_02:70]
(Unaudited, in thousands, except per share amounts)

[0001262039-16-000061:8k_2_02:71]
Reconciliation of GAAP operating income or loss to Non-GAAP operating income, operating margin, net income and diluted net income per share

[0001262039-16-000061:8k_2_02:72]
|  | Three Months Ended March 31, 2016 |  | Three Months Ended March 31, 2015 |
|  | GAAP Results |  | Adjustments |  | Non-GAAP Results |  | GAAP Results |  | Adjustments |  | Non-GAAP Results |
| Operating income (loss) | $ | (5,672 | ) |  | $ | 35,766 |  | (a) | $ | 30,094 |  |  | $ | 898 |  |  | $ | 19,166 |  | (b) | $ | 20,064 |  |
| Operating margin | -2 | % |  |  |  | 11 | % |  | 0.4 | % |  |  |  | 9 | % |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | 30,881 |  |  |  |  |  |  | 18,922 |  |  |  |
| Amortization of acquired intangible assets |  |  | 1,178 |  |  |  |  |  |  | 244 |  |  |  |
| ERP-related expenses |  |  | 2,986 |  |  |  |  |  |  | — |  |  |  |
| Inventory fair value adjustment amortization |  |  | 393 |  |  |  |  |  |  | — |  |  |  |
| Restructuring charges |  |  | 328 |  |  |  |  |  |  | — |  |  |  |
| Tax adjustment |  |  | (12,189 | ) | (c) |  |  |  |  | (7,200 | ) | (c) |  |
| Net income (loss) | $ | (3,429 | ) |  | $ | 23,577 |  |  | $ | 20,148 |  |  | $ | 1,560 |  |  | $ | 11,966 |  |  | $ | 13,526 |  |
| Diluted net income (loss) per share | $ | (0.02 | ) |  |  |  | $ | 0.12 |  |  | $ | 0.01 |  |  |  |  | $ | 0.08 |  |
| Shares used in diluted net income (loss) per share calculations | 171,745 |  |  |  |  | 174,263 |  |  | 173,720 |  |  |  |  | 173,720 |  |

[0001262039-16-000061:8k_2_02:73]
(a) To exclude $30.9 million of stock-based compensation, $1.2 million of amortization of acquired intangible assets, $3.0 million of ERP-related expenses, $0.4 million of inventory fair value adjustment amortization recorded pursuant to our business acquisition and $0.3 million of restructuring charges in the three months ended March 31, 2016.

[0001262039-16-000061:8k_2_02:74]
(b) To exclude $18.9 million of stock-based compensation and $0.2 million of amortization of acquired intangible assets in the three months ended March 31, 2015.

[0001262039-16-000061:8k_2_02:75]
(c)  Non-GAAP financial information is adjusted to achieve an overall 34% percent and 35% percent effective tax rate in the three months ended March 31, 2016 and March 31, 2015, respectively, on a non-GAAP basis, which differs from the GAAP effective tax rate.
