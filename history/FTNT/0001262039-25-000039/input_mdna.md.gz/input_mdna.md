# FTNT MD&A — 0001262039-25-000039


## mdna

[0001262039-25-000039:mdna:1]
[same as prior period, unchanged from 0001262039-25-000028:mdna:1]

[0001262039-25-000039:mdna:2]
[same as prior period, unchanged from 0001262039-25-000028:mdna:2]

[0001262039-25-000039:mdna:3]
[same as prior period, unchanged from 0001262039-25-000028:mdna:3]

[0001262039-25-000039:mdna:4]
[same as prior period, unchanged from 0001262039-25-000028:mdna:4]

[0001262039-25-000039:mdna:5]
[same as prior period, unchanged from 0001262039-25-000028:mdna:5]

[0001262039-25-000039:mdna:6]
[same as prior period, unchanged from 0001262039-25-000028:mdna:6]

[0001262039-25-000039:mdna:7]
[same as prior period, unchanged from 0001262039-25-000028:mdna:7]

[0001262039-25-000039:mdna:8]
[same as prior period, unchanged from 0001262039-25-000028:mdna:8]

[0001262039-25-000039:mdna:9]
[same as prior period, unchanged from 0001262039-25-000028:mdna:9]

[0001262039-25-000039:mdna:10]
[same as prior period, unchanged from 0001262039-25-000028:mdna:10]

[0001262039-25-000039:mdna:11]
[same as prior period, unchanged from 0001262039-25-000028:mdna:11]

[0001262039-25-000039:mdna:12]
[same as prior period, unchanged from 0001262039-25-000028:mdna:12]

[0001262039-25-000039:mdna:13]
[same as prior period, unchanged from 0001262039-25-000028:mdna:13]

[0001262039-25-000039:mdna:14]
[same as prior period, unchanged from 0001262039-25-000028:mdna:14]

[0001262039-25-000039:mdna:15]
[same as prior period, unchanged from 0001262039-25-000028:mdna:15]

[0001262039-25-000039:mdna:16]
[same as prior period, unchanged from 0001262039-25-000028:mdna:16]

[0001262039-25-000039:mdna:17]
[same as prior period, unchanged from 0001262039-25-000028:mdna:17]

[0001262039-25-000039:mdna:18]
[same as prior period, unchanged from 0001262039-25-000028:mdna:18]

[0001262039-25-000039:mdna:19]
[same as prior period, unchanged from 0001262039-25-000028:mdna:19]

[0001262039-25-000039:mdna:20]
[same as prior period, unchanged from 0001262039-25-000028:mdna:20]

[0001262039-25-000039:mdna:21]
[same as prior period, unchanged from 0001262039-25-000028:mdna:21]

[0001262039-25-000039:mdna:22]
[same as prior period, unchanged from 0001262039-25-000028:mdna:22]

[0001262039-25-000039:mdna:23]
[same as prior period, unchanged from 0001262039-25-000028:mdna:23]

[0001262039-25-000039:mdna:24]
[same as prior period, unchanged from 0001262039-25-000028:mdna:24]

[0001262039-25-000039:mdna:25]
[same as prior period, unchanged from 0001262039-25-000028:mdna:25]

[0001262039-25-000039:mdna:26]
[same as prior period, unchanged from 0001262039-25-000028:mdna:26]

[0001262039-25-000039:mdna:27]
•expected outcomes and liabilities in litigation;

[0001262039-25-000039:mdna:28]
[same as prior period, unchanged from 0001262039-25-000028:mdna:28]

[0001262039-25-000039:mdna:29]
[same as prior period, unchanged from 0001262039-25-000028:mdna:29]

[0001262039-25-000039:mdna:30]
[same as prior period, unchanged from 0001262039-25-000028:mdna:30]

[0001262039-25-000039:mdna:31]
[same as prior period, unchanged from 0001262039-25-000028:mdna:31]

[0001262039-25-000039:mdna:32]
Fortinet is a leader in cybersecurity, driving the convergence of networking and security. Our mission is to secure people, devices and data everywhere. Our integrated platform, the Fortinet Security Fabric, spans secure networking, unified SASE and AI-driven security operations (“SecOps”). As of September 30, 2025, our end-customers were located in over 100 countries and included enterprises across a wide variety of market verticals, including financial services, retail, healthcare and operational technology (“OT”) market verticals, communication and security service providers, and government organizations. As a global company headquartered in Sunnyvale, California, our research and development is centered in the United States and Canada with a global footprint of support and centers of excellence around the world. As of September 30, 2025, we held 1,027 U.S. patents and 1,360 global patents, including 307 AI-related patents. We have been recognized in over 140 enterprise analyst reports demonstrating both our vision and execution across security and networking products.

[0001262039-25-000039:mdna:33]
[same as prior period, unchanged from 0001262039-25-000028:mdna:33]

[0001262039-25-000039:mdna:34]
[same as prior period, unchanged from 0001262039-25-000028:mdna:34]

[0001262039-25-000039:mdna:35]
[same as prior period, unchanged from 0001262039-25-000028:mdna:35]

[0001262039-25-000039:mdna:36]
[same as prior period, unchanged from 0001262039-25-000028:mdna:36]

[0001262039-25-000039:mdna:37]
[same as prior period, unchanged from 0001262039-25-000028:mdna:37]

[0001262039-25-000039:mdna:38]
[same as prior period, unchanged from 0001262039-25-000028:mdna:38]

[0001262039-25-000039:mdna:39]
[same as prior period, unchanged from 0001262039-25-000028:mdna:39]

[0001262039-25-000039:mdna:40]
[same as prior period, unchanged from 0001262039-25-000028:mdna:40]

[0001262039-25-000039:mdna:41]
[same as prior period, unchanged from 0001262039-25-000028:mdna:41]

[0001262039-25-000039:mdna:42]
[same as prior period, unchanged from 0001262039-25-000028:mdna:42]

[0001262039-25-000039:mdna:43]
•Unified Secure Access Service Edge (SASE)—As applications move to the cloud and hybrid workforce is now the norm, enabling secure access for users with zero trust framework becomes important. The Fortinet Unified SASE solution includes a single-vendor SASE solution that includes firewall, SD-WAN, secure web gateway, cloud access services broker, DLP and zero trust network access (“ZTNA”) to deliver flexible secure access for all users. We are one of the few vendors to deliver consistent convergence and AI-powered security across Secure SD-WAN and SSE to enable a single-vendor SASE framework with a cloud-centric architecture powered by FortiOS. Our global and scalable cloud network includes over 170 PoPs to deliver the seamless secure access experience. Given this, we believe we are well positioned to support customers expanding from SD-WAN to a single-vendor SASE platform. Additionally, we offer a full suite of comprehensive, integrated cloud security solutions that enable customers to secure their applications from code to cloud. Our solutions include application security that includes our web application firewalls, cloud network security with virtualized firewalls and cloud-native firewalls, cloud-native application protection and code security. We deliver a holistic approach to cloud security, offering a single unified platform, consolidating protection across multiple disparate tools, including coding, deploying, and running

[0001262039-25-000039:mdna:44]
applications across hybrid and multi-clouds. Additionally, we also offer flexible consumption licensing programs that enable organizations to dynamically optimize their cloud security needs and investments as well as readily meet their cloud minimum spend commitment obligations with Cloud Service Providers. We continue to develop all the core SASE capabilities in a single operating system, FortiOS, including Next-Gen Firewall, SD-WAN, ZTNA, secure web gateway, cloud access security broker, and DLP. This native integration of our Next-Gen Firewall, SD-WAN, and SASE has become the New-Generation SASE Firewall.

[0001262039-25-000039:mdna:45]
[same as prior period, unchanged from 0001262039-25-000028:mdna:45]

[0001262039-25-000039:mdna:46]
[same as prior period, unchanged from 0001262039-25-000028:mdna:46]

[0001262039-25-000039:mdna:47]
[same as prior period, unchanged from 0001262039-25-000028:mdna:47]

[0001262039-25-000039:mdna:48]
[same as prior period, unchanged from 0001262039-25-000028:mdna:48]

[0001262039-25-000039:mdna:49]
[same as prior period, unchanged from 0001262039-25-000028:mdna:49]

[0001262039-25-000039:mdna:50]
Additionally, we are committed to addressing the cybersecurity skills shortage through training and certification programs for customers, partners and employees. The Fortinet Training Institute’s ecosystem of public and private partnerships around the world extend to industry, academia, government and nonprofits to ensure we are reaching and increasing access of our cybersecurity certifications and training to all populations. The Fortinet Training Institute has issued approximately two million certifications to date.

[0001262039-25-000039:mdna:51]
[same as prior period, unchanged from 0001262039-25-000028:mdna:51]

[0001262039-25-000039:mdna:52]
•Total revenue was $1.72 billion and $4.89 billion during the three and nine months ended September 30, 2025, an increase of 14% in each period, compared to $1.51 billion and $4.30 billion in the same periods last year. Product revenue was $559.3 million and $1.53 billion during the three and nine months ended September 30, 2025, an increase of 18% and 14%, respectively, compared to $473.9 million and $1.33 billion in the same periods last year. Service revenue was $1.17 billion and $3.37 billion during the three and nine months ended September 30, 2025, an increase of 13% and 14%, respectively, compared to $1.03 billion and $2.96 billion in the same periods last year.

[0001262039-25-000039:mdna:53]
•Total gross profit was $1.39 billion and $3.95 billion during the three and nine months ended September 30, 2025, an increase of 12% and 15%, respectively, compared to $1.24 billion and $3.45 billion in the same periods last year.

[0001262039-25-000039:mdna:54]
[same as prior period, unchanged from 0001262039-25-000028:mdna:55]

[0001262039-25-000039:mdna:55]
•Total gross margin was 80.8% during the three and nine months ended September 30, 2025, a decrease of 1.7 percentage points and an increase of 0.4 percentage points, respectively, compared to 82.5% and 80.4% in the same periods last year.

[0001262039-25-000039:mdna:56]
•Operating income was $547.3 million and $1.46 billion during the three and nine months ended September 30, 2025, an increase of 16% and 19%, respectively, compared to $470.9 million and $1.23 billion in the same periods last year.

[0001262039-25-000039:mdna:57]
•Operating margin was 31.7% and 29.8% during the three and nine months ended September 30, 2025, an increase of 0.5 percentage points and 1.2 percentage points, respectively, compared to 31.2% and 28.6% in the same periods last year.

[0001262039-25-000039:mdna:58]
•Cash, cash equivalents, short-term and long-term investments were $3.41 billion as of September 30, 2025.

[0001262039-25-000039:mdna:59]
•Deferred revenue was $6.65 billion, including short-term deferred revenue of $3.46 billion, as of September 30, 2025.

[0001262039-25-000039:mdna:60]
•Cash flows from operating activities were $1.97 billion during the nine months ended September 30, 2025, an increase of $189.9 million, or 11%, compared to the same period last year.

[0001262039-25-000039:mdna:61]
Revenue continues to be diversified globally, which remains a key strength of our business. During the three months ended September 30, 2025, the EMEA region, the Americas region and the APAC region contributed 41%, 40% and 19% of our total revenue, respectively, and revenue grew 19%, 9% and 16% in these regions compared to the same period last year, respectively. During the nine months ended September 30, 2025, EMEA, the Americas and APAC regions contributed 41%, 40% and 19% of our total revenue, respectively, and revenue grew by 18%, 11% and 12% in these regions compared to the same period last year, respectively.

[0001262039-25-000039:mdna:62]
Product revenue increased 18% and 14% during the three and nine months ended September 30, 2025, respectively, compared to the same periods last year. We experienced product revenue growth across our hardware products and software licensing, which mainly benefited from growth in secure networking hardware products and term licenses. We expect our product revenue to continue to grow for the remainder of 2025.

[0001262039-25-000039:mdna:63]
Service revenue growth during the three and nine months ended September 30, 2025 was 13% and 14%, respectively, as compared to the same periods last year, primarily driven by the strength of our security subscription revenue, which grew 13% and 15%, respectively. The increase was primarily due to the recognition of service revenue from our growing deferred revenue balance related to FortiGuard and other security subscriptions delivered to on-premise and cloud-based environments and strength in unified SASE and SecOps. We expect our service revenue to continue to grow for the remainder of 2025.

[0001262039-25-000039:mdna:64]
Our billings were diversified on a geographic basis. During the three months ended September 30, 2025, six countries represented approximately 50% of our billings and the remaining approximately 50% in the aggregate were from over 100 countries that each individually contributed less than 3% of our billings.

[0001262039-25-000039:mdna:65]
Total gross margin decreased 1.7 percentage points during the three months ended September 30, 2025 compared to the same period last year, primarily driven by reduced benefit from net release of inventory related reserves and increased cloud service costs. Total gross margin increased 0.4 percentage points during the nine months ended September 30, 2025 compared to the same period last year, primarily driven by increased product gross margin benefiting from lower impact of inventory reserves in comparison to the nine months ended September 30, 2024. Our overall gross margin for the full year of 2025 will be impacted by service and product revenue mix and their respective gross margins. We do not expect our product gross margin to significantly change for the full year 2025 as compared to 2024. We expect our service gross margin to decrease for the full year of 2025 compared to 2024, as we expand our data center footprint and colocation and cloud hosting capacity to support the growth in our unified SASE and SecOps offerings. We currently do not expect the U.S. tariffs to have a meaningful impact on our gross margin. If tariffs increase in the future, we expect any resulting impact on our gross margin to mostly be on our hardware sales to U.S. customers.

[0001262039-25-000039:mdna:66]
Operating expenses as a percentage of revenue decreased 2.3 and 0.8 percentage points during the three and nine months ended September 30, 2025, respectively, compared to the same periods last year, mainly because our revenue growth outpaced our personnel costs growth. Headcount increased to 15,015 employees as of September 30, 2025, a 7% increase compared to 13,986 as of September 30, 2024.

[0001262039-25-000039:mdna:67]
Operating margin increased 0.5 and 1.2 percentage points during the three and nine months ended September 30, 2025, respectively, driven by revenue growth exceeding expense growth, resulting in improved operating leverage. For the full year 2025, we expect operating margin to be relatively consistent to 2024. Total revenue is expected to be higher in 2025 compared

[0001262039-25-000039:mdna:68]
[same as prior period, unchanged from 0001262039-25-000028:mdna:68]

[0001262039-25-000039:mdna:69]
to the prior year, while our expenses have also increased due to headcount investments in sales and marketing, product development and the continued investments in data centers and real estate. In addition, our operating expenses have increased compared to 2024 and we expect that trend to continue in part due to a weaker U.S. dollar compared to many foreign currencies, as a portion of our expenses are incurred and paid in currencies other than the U.S. dollar.

[0001262039-25-000039:mdna:70]
[same as prior period, unchanged from 0001262039-25-000028:mdna:70]

[0001262039-25-000039:mdna:71]
[same as prior period, unchanged from 0001262039-25-000028:mdna:71]

[0001262039-25-000039:mdna:72]
[same as prior period, unchanged from 0001262039-25-000028:mdna:72]

[0001262039-25-000039:mdna:73]
[same as prior period, unchanged from 0001262039-25-000028:mdna:73]

[0001262039-25-000039:mdna:74]
[same as prior period, unchanged from 0001262039-25-000028:mdna:74]

[0001262039-25-000039:mdna:75]
[same as prior period, unchanged from 0001262039-25-000028:mdna:75]

[0001262039-25-000039:mdna:76]
[same as prior period, unchanged from 0001262039-25-000028:mdna:76]

[0001262039-25-000039:mdna:77]
[same as prior period, unchanged from 0001262039-25-000028:mdna:77]

[0001262039-25-000039:mdna:78]
[same as prior period, unchanged from 0001262039-25-000028:mdna:78]

[0001262039-25-000039:mdna:79]
33

[0001262039-25-000039:mdna:80]
[same as prior period, unchanged from 0001262039-25-000028:mdna:79]

[0001262039-25-000039:mdna:81]
|  | Three Months Ended Or As Of |
|  | September 30, 2025 |  | September 30, 2024 |
|  | (in millions) |
| Revenue | $ | 1,724.9 |  |  | $ | 1,508.1 |  |
| Deferred revenue | $ | 6,650.4 |  |  | $ | 6,011.7 |  |
| Billings (non-GAAP) | $ | 1,807.7 |  |  | $ | 1,582.2 |  |
| Net cash provided by operating activities | $ | 655.2 |  |  | $ | 608.1 |  |
| Free cash flow (non-GAAP) | $ | 567.5 |  |  | $ | 571.8 |  |

[0001262039-25-000039:mdna:82]
Deferred revenue. Our deferred revenue consists of amounts that have been invoiced but that have not yet been recognized as revenue. The majority of our deferred revenue balance consists of the unrecognized portion of service revenue from FortiGuard and other security subscriptions and FortiCare technical support service contracts, which is recognized as revenue ratably over the service term. We monitor our deferred revenue balance, short-term and total deferred revenue growth and the mix of short-term and long-term deferred revenue because deferred revenue represents a significant portion of free cash flow and of revenue to be recognized in future periods. Deferred revenue was $6.65 billion as of September 30, 2025, an increase of $289.5 million, or 5%, from December 31, 2024. Short-term deferred revenue was $3.46 billion as of September 30, 2025, an increase of $184.3 million, or 6%, from December 31, 2024.

[0001262039-25-000039:mdna:83]
Billings (non-GAAP). We define billings as revenue recognized in accordance with GAAP plus the change in deferred revenue from the beginning to the end of the period less any deferred revenue balances acquired from business combinations during the period. We consider billings to be a useful metric for management and investors because billings drive current and future revenue, which is an important indicator of the health and viability of our business and cash flows. There are a number of limitations related to the use of billings instead of GAAP revenue. First, billings include amounts that have not yet been recognized as revenue and are impacted by the term of security subscription and support agreements. Second, we may calculate billings in a manner that is different from peer companies that report similar financial measures. Management accounts for these limitations by providing specific information regarding GAAP revenue and evaluating billings together with GAAP revenue. Total billings were $1.81 billion for the three months ended September 30, 2025, an increase of 14% compared to $1.58 billion in the same period last year.

[0001262039-25-000039:mdna:84]
[same as prior period, unchanged from 0001262039-25-000028:mdna:84]

[0001262039-25-000039:mdna:85]
|  | Three Months Ended |
|  | September 30, 2025 |  | September 30, 2024 |
|  | (in millions) |
| Billings: |  |  |  |
| Revenue | $ | 1,724.9 |  |  | $ | 1,508.1 |  |
| Add: Change in deferred revenue | 82.8 |  |  | 115.5 |  |
| Less: Deferred revenue balance acquired in business combinations | — |  |  | (41.4) |  |
| Total billings (non-GAAP) | $ | 1,807.7 |  |  | $ | 1,582.2 |  |

[0001262039-25-000039:mdna:86]
Free cash flow (non-GAAP). We define free cash flow as net cash provided by operating activities minus purchases of property and equipment and excluding any significant non-recurring items. We believe free cash flow to be a liquidity measure that provides useful information to management and investors about the amount of cash generated by the business that, after capital expenditures, can be used for strategic opportunities, including repurchasing outstanding common stock, investing in our business, making strategic acquisitions and strengthening the balance sheet. A limitation of using free cash flow rather than the GAAP measures of cash provided by or used in operating activities, investing activities, and financing activities is that free cash flow does not represent the total increase or decrease in the cash and cash equivalents balance for the period because it excludes cash flows from significant non-recurring items, investing activities other than capital expenditures and cash flows from financing activities. Management accounts for this limitation by providing information about our capital expenditures and other investing and financing activities on the condensed consolidated statements of cash flows and under “Liquidity and Capital Resources” and by presenting cash flows from investing and financing activities in our reconciliation of free cash flow. In addition, it is important to note that other companies, including companies in our industry, may not use free cash flow, may calculate free cash flow in a different manner than we do or may use other financial measures to evaluate their performance, all

[0001262039-25-000039:mdna:87]
34

[0001262039-25-000039:mdna:88]
of which could reduce the usefulness of free cash flow as a comparative measure. A reconciliation of net cash provided by operating activities, the most directly comparable financial measure calculated and presented in accordance with GAAP, to free cash flow is provided below:

[0001262039-25-000039:mdna:89]
|  | Three Months Ended |
|  | September 30, 2025 |  | September 30, 2024 |
|  | (in millions) |
| Free Cash Flow: |  |  |  |
| Net cash provided by operating activities | $ | 655.2 |  |  | $ | 608.1 |  |
| Less: Purchases of property and equipment | (87.7) |  |  | (36.3) |  |
| Free cash flow (non-GAAP) | $ | 567.5 |  |  | $ | 571.8 |  |
| Net cash used in investing activities | $ | (175.8) |  |  | $ | (327.1) |  |
| Net cash provided by (used in) financing activities | $ | (1,851.9) |  |  | $ | 3.0 |  |

[0001262039-25-000039:mdna:90]
[same as prior period, unchanged from 0001262039-25-000028:mdna:89]

[0001262039-25-000039:mdna:91]
[same as prior period, unchanged from 0001262039-25-000028:mdna:90]

[0001262039-25-000039:mdna:92]
There were no material changes to our critical accounting policies and estimates as of and for the nine months ended September 30, 2025, as compared to the critical accounting policies and estimates described in our Annual Report on Form 10-K filed with the SEC on February 21, 2025 (the “Form 10-K”).

[0001262039-25-000039:mdna:93]
[same as prior period, unchanged from 0001262039-25-000028:mdna:92]

[0001262039-25-000039:mdna:94]
[same as prior period, unchanged from 0001262039-25-000028:mdna:94]

[0001262039-25-000039:mdna:95]
Three Months Ended September 30, 2025 and 2024

[0001262039-25-000039:mdna:96]
[same as prior period, unchanged from 0001262039-25-000028:mdna:96]

[0001262039-25-000039:mdna:97]
|  | Three Months Ended |  |  |  |  |
| September 30,2025 |  | September 30,2024 |  |  |  |  |
| Amount |  | % ofRevenue |  | Amount |  | % ofRevenue |  | Change |  | % Change |
| (in millions, except percentages) |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 559.3 |  |  | 32 | % |  | $ | 473.9 |  |  | 31 | % |  | $ | 85.4 |  |  | 18 | % |
| Service | 1,165.6 |  |  | 68 |  |  | 1,034.2 |  |  | 69 |  |  | 131.4 |  |  | 13 |  |
| Total revenue | $ | 1,724.9 |  |  | 100 | % |  | $ | 1,508.1 |  |  | 100 | % |  | $ | 216.8 |  |  | 14 | % |
| Revenue by geography: |  |  |  |  |  |  |  |  |  |  |  |
| Americas | $ | 680.5 |  |  | 40 | % |  | $ | 624.0 |  |  | 41 | % |  | $ | 56.5 |  |  | 9 | % |
| EMEA | 713.7 |  |  | 41 |  |  | 599.3 |  |  | 40 |  |  | 114.4 |  |  | 19 |  |
| APAC | 330.7 |  |  | 19 |  |  | 284.8 |  |  | 19 |  |  | 45.9 |  |  | 16 |  |
| Total revenue | $ | 1,724.9 |  |  | 100 | % |  | $ | 1,508.1 |  |  | 100 | % |  | $ | 216.8 |  |  | 14 | % |
| Percentages have been rounded for presentation purposes and may differ from unrounded results. |

[0001262039-25-000039:mdna:98]
[same as prior period, unchanged from 0001262039-25-000028:mdna:93]

[0001262039-25-000039:mdna:99]
Total revenue increased $216.8 million, or 14%, during the three months ended September 30, 2025 compared to the same period last year. We continued to experience diversification of revenue geographically, and across customer and industry verticals. Revenue from all regions grew, with EMEA contributing the largest portion of the increase on an absolute dollar basis and on a percentage basis.

[0001262039-25-000039:mdna:100]
Product revenue increased $85.4 million, or 18%, during the three months ended September 30, 2025 compared to the same period last year. We experienced product revenue growth across our hardware products and software licensing, mainly driven by growth in secure networking hardware products and term licenses.

[0001262039-25-000039:mdna:101]
Service revenue increased $131.4 million, or 13%, during the three months ended September 30, 2025 compared to the same period last year. Security subscription revenue increased $76.2 million, or 13%, and technical support and other services revenue increased $55.2 million, or 13%, during the three months ended September 30, 2025 compared to the same period last year. The increase was primarily due to the recognition of revenue from our growing deferred revenue balance related to FortiGuard and other security subscriptions delivered to on-premise and cloud-based environments and growth in SaaS solutions, including unified SASE and SecOps.

[0001262039-25-000039:mdna:102]
Of the service revenue recognized during the three months ended September 30, 2025, 90% was included in the deferred revenue balance as of June 30, 2025. Of the service revenue recognized during the three months ended September 30, 2024, 88% was included in the deferred revenue balance as of June 30, 2024.

[0001262039-25-000039:mdna:103]
[same as prior period, unchanged from 0001262039-25-000028:mdna:103]

[0001262039-25-000039:mdna:104]
|  | Three Months Ended |  |  |  |  |
| September 30,2025 |  | September 30,2024 |  | Change |  | % Change |
| (in millions, except percentages) |
| Cost of revenue: |  |  |  |  |  |  |  |
| Product | $ | 180.7 |  |  | $ | 136.1 |  |  | $ | 44.6 |  |  | 33 | % |
| Service | 151.0 |  |  | 127.3 |  |  | 23.7 |  |  | 19 |  |
| Total cost of revenue | $ | 331.7 |  |  | $ | 263.4 |  |  | $ | 68.3 |  |  | 26 | % |
| Gross margin (%): |  |  |  |  |  |  |  |
| Product | 67.7 | % |  | 71.3 | % |  |  |  |  |
| Service | 87.0 |  |  | 87.7 |  |  |  |  |  |
| Total gross margin | 80.8 | % |  | 82.5 | % |  |  |  |  |

[0001262039-25-000039:mdna:105]
Total gross margin decreased 1.7 percentage points during the three months ended September 30, 2025 compared to the same period last year, primarily driven by decreased product and service gross margins.

[0001262039-25-000039:mdna:106]
Product gross margin decreased 3.6 percentage points during the three months ended September 30, 2025 compared to the same period last year, primarily due to reduced benefit from net release of inventory related reserves. Cost of product revenue was comprised primarily of third-party contract manufacturers’ costs, and costs of materials used in production.

[0001262039-25-000039:mdna:107]
Service gross margin decreased 0.7 percentage points during the three months ended September 30, 2025 compared to the same period last year, primarily driven by an increase in cloud service costs as a result of our acquisitions and investment in data centers and related infrastructure, partially offset by service revenue growth outpacing labor, replacement, and repair costs increase. Cost of service revenue was comprised primarily of personnel-related costs, replacement and repair costs, cloud service costs from owned data centers, colocation providers and cloud service providers, infrastructure depreciation and related operating costs, software and delivery costs, and facility-related costs.

[0001262039-25-000039:mdna:108]
[same as prior period, unchanged from 0001262039-25-000028:mdna:108]

[0001262039-25-000039:mdna:109]
|  | Three Months Ended |  | Change |  | % Change |
| September 30,2025 |  | September 30,2024 |  |
| Amount |  | % ofRevenue |  | Amount |  | % ofRevenue |  |
| (in millions, except percentages) |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | $ | 202.4 |  |  | 12 | % |  | $ | 187.3 |  |  | 12 | % |  | $ | 15.1 |  |  | 8 | % |
| Sales and marketing | 583.5 |  |  | 34 |  |  | 515.9 |  |  | 34 |  |  | 67.6 |  |  | 13 |  |
| General and administrative | 61.4 |  |  | 4 |  |  | 71.7 |  |  | 5 |  |  | (10.3) |  |  | (14) |  |
| Gain on intellectual property matters | (1.4) |  |  | — |  |  | (1.1) |  |  | — |  |  | (0.3) |  |  | 27 |  |
| Total operating expenses | $ | 845.9 |  |  | 49 | % |  | $ | 773.8 |  |  | 51 | % |  | $ | 72.1 |  |  | 9 | % |
| Percentages have been rounded for presentation purposes and may differ from unrounded results. |

[0001262039-25-000039:mdna:110]
[same as prior period, unchanged from 0001262039-25-000028:mdna:110]

[0001262039-25-000039:mdna:111]
Research and development expense increased $15.1 million, or 8%, during the three months ended September 30, 2025 compared to the same period last year, primarily due to an increase of $12.1 million in personnel-related costs as a result of increased headcount and compensation rates to support the development of new products and continued enhancements to our existing products and the impact of the recent acquisitions. In addition, non-personnel-related product development costs increased $4.0 million. We currently intend to continue investing in our research and development organization, and expect research and development expense to increase in absolute dollars year over year during the remainder of 2025.

[0001262039-25-000039:mdna:112]
[same as prior period, unchanged from 0001262039-25-000028:mdna:112]

[0001262039-25-000039:mdna:113]
Sales and marketing expense increased $67.6 million, or 13%, during the three months ended September 30, 2025 compared to the same period last year, primarily due to an increase of $53.6 million in personnel-related costs, an increase of $5.6 million in marketing program and related expenses, an increase of $4.1 million in amortization expense of certain intangible assets and unfavorable impact of foreign currency fluctuations. We currently intend to continue to make investments in sales and marketing resources, which are critical to support our future growth, and expect our sales and marketing expense to increase in absolute dollars year over year during the remainder of 2025.

[0001262039-25-000039:mdna:114]
[same as prior period, unchanged from 0001262039-25-000028:mdna:114]

[0001262039-25-000039:mdna:115]
General and administrative expense decreased $10.3 million, or 14%, during the three months ended September 30, 2025 compared to the same period last year, primarily due to a decrease of $7.6 million in legal related fees and other professional services fees and a decrease of $1.3 million in personnel-related costs. We expect our general and administrative expense to be relatively consistent in absolute dollars year over year during the remainder of 2025.

[0001262039-25-000039:mdna:116]
[same as prior period, unchanged from 0001262039-25-000028:mdna:116]

[0001262039-25-000039:mdna:117]
We generated operating income of $547.3 million during the three months ended September 30, 2025, an increase of $76.4 million, or 16%, compared to $470.9 million in the same period last year. Operating margin was 31.7% during the three months ended September 30, 2025, compared to 31.2% in the same period last year. The 0.5 percentage points increase in operating margin was primarily due to 1.2, 0.6 and 0.4 percentage points decreases in general and administrative expense, research and development expense and sales and marketing expense as a percentage of revenue, respectively, partially offset by 1.7 percentage points decrease in gross margin.

[0001262039-25-000039:mdna:118]
Interest income, interest expense and other income—net

[0001262039-25-000039:mdna:119]
|  | Three Months Ended |  |  |  |  |
| September 30,2025 |  | September 30,2024 |  | Change |  | % Change |
| (in millions, except percentages) |
| Interest income | $ | 40.7 |  |  | $ | 42.4 |  |  | $ | (1.7) |  |  | (4) | % |
| Interest expense | $ | (6.2) |  |  | $ | (5.0) |  |  | $ | (1.2) |  |  | 24 | % |
| Other income—net | $ | 13.0 |  |  | $ | 118.1 |  |  | $ | (105.1) |  |  | (89) | % |

[0001262039-25-000039:mdna:120]
Interest income and interest expense remained comparatively flat during the three months ended September 30, 2025 compared to the same period last year. Other income—net decreased $105.1 million during the three months ended September 30, 2025 compared to the same period last year, primarily due to a gain on bargain purchase of $106.3 million during the three months ended September 30, 2024 related to our acquisition of Lacework.

[0001262039-25-000039:mdna:121]
[same as prior period, unchanged from 0001262039-25-000028:mdna:121]

[0001262039-25-000039:mdna:122]
|  | Three Months Ended |  | Change |  | % Change |
| September 30,2025 |  | September 30,2024 |  |
| (in millions, except percentages) |
| Provision for income taxes | $ | 120.7 |  |  | $ | 81.2 |  |  | $ | 39.5 |  |  | 49 | % |
| Effective tax rate (%) | 20 | % |  | 13 | % |  |  |  |  |

[0001262039-25-000039:mdna:123]
Our effective tax rate was 20% for the three months ended September 30, 2025 compared to an effective tax rate of 13% for the same period last year. The provision for income taxes for the three months ended September 30, 2025 was primarily comprised of U.S. federal and state taxes, withholding taxes and foreign taxes totaling $141.0 million, which was favorably affected by a tax benefit of $11.1 million from the foreign-derived intangible income deduction (the “FDII deduction”) and excess tax benefits from stock-based compensation expense of $9.2 million.

[0001262039-25-000039:mdna:124]
The provision for income taxes for the three months ended September 30, 2024 was comprised of U.S. federal and state taxes, withholding taxes, and foreign taxes totaling $123.6 million, which were favorably affected by a tax benefit of $33.1 million from the FDII deduction and excess tax benefits from stock-based compensation expense of $9.3 million.

[0001262039-25-000039:mdna:125]
On July 4, 2025, H.R. 1, the Act commonly referred to as the One Big Beautiful Bill Act, was enacted. The Act makes permanent certain elements of the Tax Cuts and Jobs Act, including immediate expensing of U.S. research and development expenditures, immediate expensing of certain eligible assets, and various modifications to the international tax framework. The income tax effects of the Act have been recognized in our provision for income taxes as of September 30, 2025. As a result of the Act, our cash paid for income taxes in 2025 could reduce by approximately $100 million to $150 million, while our GAAP effective tax rate for 2025 could increase by approximately one percentage point.

[0001262039-25-000039:mdna:126]
[same as prior period, unchanged from 0001262039-25-000028:mdna:126]

[0001262039-25-000039:mdna:127]
|  | Three Months Ended |  | Change |  | % Change |
| September 30,2025 |  | September 30,2024 |  |
| (in millions, except percentages) |
| Loss from equity method investments | $ | (0.2) |  |  | $ | (5.3) |  |  | $ | 5.1 |  |  | (96) | % |

[0001262039-25-000039:mdna:128]
Loss from equity method investments decreased $5.1 million during the three months ended September 30, 2025 compared to the same period last year which included a $5.2 million loss due to our proportionate share of Linksys’ financial results including our share of the amortization of the basis differences during the three months ended September 30, 2024.

[0001262039-25-000039:mdna:129]
Nine Months Ended September 30, 2025 and 2024

[0001262039-25-000039:mdna:130]
[same as prior period, unchanged from 0001262039-25-000028:mdna:130]

[0001262039-25-000039:mdna:131]
|  | Nine Months Ended |  |  |  |  |
| September 30,2025 |  | September 30,2024 |  |  |  |  |
| Amount |  | % ofRevenue |  | Amount |  | % ofRevenue |  | Change |  | % Change |
| (in millions, except percentages) |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 1,527.3 |  |  | 31 | % |  | $ | 1,334.7 |  |  | 31 | % |  | $ | 192.6 |  |  | 14 | % |
| Service | 3,367.3 |  |  | 69 |  |  | 2,961.0 |  |  | 69 |  |  | 406.3 |  |  | 14 |  |
| Total revenue | $ | 4,894.6 |  |  | 100 | % |  | $ | 4,295.7 |  |  | 100 | % |  | $ | 598.9 |  |  | 14 | % |
| Revenue by geography: |  |  |  |  |  |  |  |  |  |  |  |
| Americas | $ | 1,969.1 |  |  | 40 | % |  | $ | 1,776.3 |  |  | 41 | % |  | $ | 192.8 |  |  | 11 | % |
| EMEA | 2,009.2 |  |  | 41 |  |  | 1,703.9 |  |  | 40 |  |  | 305.3 |  |  | 18 |  |
| APAC | 916.3 |  |  | 19 |  |  | 815.5 |  |  | 19 |  |  | 100.8 |  |  | 12 |  |
| Total revenue | $ | 4,894.6 |  |  | 100 | % |  | $ | 4,295.7 |  |  | 100 | % |  | $ | 598.9 |  |  | 14 | % |

[0001262039-25-000039:mdna:132]
Total revenue increased $598.9 million, or 14%, during the nine months ended September 30, 2025 compared to the same period last year. We continued to experience diversification of revenue geographically, and across customer and industry verticals. Revenue from all regions grew, with EMEA contributing the largest portion of the increase on an absolute dollar basis and on a percentage basis.

[0001262039-25-000039:mdna:133]
Product revenue increased $192.6 million, or 14%, during the nine months ended September 30, 2025 compared to the same period last year. We experienced product revenue growth across our hardware products and software licensing, mainly driven by growth in secure networking hardware products and term licenses.

[0001262039-25-000039:mdna:134]
Service revenue increased $406.3 million, or 14%, during the nine months ended September 30, 2025 compared to the same period last year. Security subscription revenue increased $248.1 million, or 15%, and technical support and other services revenue increased $158.2 million, or 12%, during the nine months ended September 30, 2025 compared to the same period last year. The increase was primarily due to the recognition of revenue from our growing deferred revenue balance related to FortiGuard and other security subscriptions delivered to on-premise and cloud-based environments and growth in SaaS solutions, including unified SASE and SecOps.

[0001262039-25-000039:mdna:135]
Of the service revenue recognized during the nine months ended September 30, 2025 and 2024, 77% was included in the deferred revenue balance as of December 31, 2024 and 2023 in each period.

[0001262039-25-000039:mdna:136]
[same as prior period, unchanged from 0001262039-25-000028:mdna:137]

[0001262039-25-000039:mdna:137]
|  | Nine Months Ended |  |  |  |  |
| September 30,2025 |  | September 30,2024 |  | Change |  | % Change |
| (in millions, except percentages) |
| Cost of revenue: |  |  |  |  |  |  |  |
| Product | $ | 496.5 |  |  | $ | 474.0 |  |  | $ | 22.5 |  |  | 5 | % |
| Service | 443.2 |  |  | 369.1 |  |  | 74.1 |  |  | 20 |  |
| Total cost of revenue | $ | 939.7 |  |  | $ | 843.1 |  |  | $ | 96.6 |  |  | 11 | % |
| Gross margin (%): |  |  |  |  |  |  |  |
| Product | 67.5 | % |  | 64.5 | % |  |  |  |  |
| Service | 86.8 |  |  | 87.5 |  |  |  |  |  |
| Total gross margin | 80.8 | % |  | 80.4 | % |  |  |  |  |

[0001262039-25-000039:mdna:138]
Total gross margin increased 0.4 percentage points during the nine months ended September 30, 2025 compared to the same period last year, driven by increased product gross margin, partially offset by decreased service gross margin.

[0001262039-25-000039:mdna:139]
Product gross margin increased 3.0 percentage points during the nine months ended September 30, 2025 compared to the same period last year, as inventory related reserves expense decreased and normalized as compared to the elevated levels we saw in the nine months ended September 30, 2024. Cost of product revenue was comprised primarily of third-party contract manufacturers’ costs and costs of materials used in production.

[0001262039-25-000039:mdna:140]
Service gross margin decreased 0.7 percentage points during the nine months ended September 30, 2025 compared to the same period last year, primarily due to an increase in cloud service costs, partially offset by service revenue growth outpacing labor, replacement, and repair costs increase. Cost of service revenue was comprised primarily of personnel-related costs, replacement and repair costs, cloud services costs from owned data centers, colocation providers and cloud service providers, infrastructure depreciation and related operating costs, software and delivery costs, and facility-related costs.

[0001262039-25-000039:mdna:141]
[same as prior period, unchanged from 0001262039-25-000028:mdna:143]

[0001262039-25-000039:mdna:142]
|  | Nine Months Ended |  | Change |  | % Change |
| September 30,2025 |  | September 30,2024 |  |
| Amount |  | % ofRevenue |  | Amount |  | % ofRevenue |  |
| (in millions, except percentages) |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | $ | 610.5 |  |  | 13 | % |  | $ | 525.7 |  |  | 12 | % |  | $ | 84.8 |  |  | 16 | % |
| Sales and marketing | 1,718.2 |  |  | 35 |  |  | 1,518.3 |  |  | 35 |  |  | 199.9 |  |  | 13 |  |
| General and administrative | 176.1 |  |  | 4 |  |  | 182.7 |  |  | 4 |  |  | (6.6) |  |  | (4) |  |
| Gain on intellectual property matters | (9.0) |  |  | — |  |  | (3.4) |  |  | — |  |  | (5.6) |  |  | 165 |  |
| Total operating expenses | $ | 2,495.8 |  |  | 51 | % |  | $ | 2,223.3 |  |  | 52 | % |  | $ | 272.5 |  |  | 12 | % |
| Percentages have been rounded for presentation purposes and may differ from unrounded results. |

[0001262039-25-000039:mdna:143]
[same as prior period, unchanged from 0001262039-25-000028:mdna:145]

[0001262039-25-000039:mdna:144]
Research and development expense increased $84.8 million, or 16%, during the nine months ended September 30, 2025 compared to the same period last year, primarily due to an increase of $64.2 million in personnel-related costs as a result of increased headcount and compensation rates to support the development of new products and continued enhancements to our existing products and the impact of the recent acquisitions. In addition, non-personnel-related product development costs increased $23.3 million.

[0001262039-25-000039:mdna:145]
[same as prior period, unchanged from 0001262039-25-000028:mdna:147]

[0001262039-25-000039:mdna:146]
Sales and marketing expense increased $199.9 million, or 13%, during the nine months ended September 30, 2025 compared to the same period last year, primarily due to an increase of $153.9 million in personnel-related costs. In addition, marketing program and related expenses increased $18.2 million and amortization expense of certain intangible assets increased $13.3 million.

[0001262039-25-000039:mdna:147]
[same as prior period, unchanged from 0001262039-25-000028:mdna:149]

[0001262039-25-000039:mdna:148]
General and administrative expense decreased $6.6 million, or 4%, during the nine months ended September 30, 2025 compared to the same period last year, primarily due to a decrease of $7.3 million in legal related fees and other professional services fees, partially offset by an increase of $1.4 million in personnel-related costs.

[0001262039-25-000039:mdna:149]
[same as prior period, unchanged from 0001262039-25-000028:mdna:151]

[0001262039-25-000039:mdna:150]
We generated operating income of $1.46 billion during the nine months ended September 30, 2025, an increase of $229.8 million, or 19%, compared to $1.23 billion in the same period last year. Operating margin was 29.8% during the nine months ended September 30, 2025, compared to 28.6% in the same period last year. The 1.2 percentage points increase in operating margin was primarily due to 0.7 and 0.2 percentage points decrease in general and administrative expense and sales

[0001262039-25-000039:mdna:151]
[same as prior period, unchanged from 0001262039-25-000028:mdna:142]

[0001262039-25-000039:mdna:152]
and marketing expense as a percentage of revenue, respectively, and 0.4 percentage points increase in gross margin, partially offset by 0.2 percentage points increase in research and development expense as a percentage of revenue.

[0001262039-25-000039:mdna:153]
Interest income, interest expense and other income—net

[0001262039-25-000039:mdna:154]
|  | Nine Months Ended |  |  |  |  |
| September 30,2025 |  | September 30,2024 |  | Change |  | % Change |
| (in millions, except percentages) |
| Interest income | $ | 130.0 |  |  | $ | 112.9 |  |  | $ | 17.1 |  |  | 15 | % |
| Interest expense | $ | (15.7) |  |  | $ | (15.1) |  |  | $ | (0.6) |  |  | 4 | % |
| Other income—net | $ | 58.0 |  |  | $ | 113.0 |  |  | $ | (55.0) |  |  | (49) | % |

[0001262039-25-000039:mdna:155]
Interest income increased $17.1 million during the nine months ended September 30, 2025 compared to the same period last year, primarily due to higher average investment balances as we had higher purchases of investments net of sales and maturities. Interest income varies depending on our average investment balances during the period, types and mix of investments, and interest rates. Interest expense remained comparatively flat during the nine months ended September 30, 2025 compared to the same period last year. Other income—net decreased $55.0 million during the nine months ended September 30, 2025 compared to the same period last year, primarily due to a $66.4 million decrease in gains on bargain purchases – we recorded a gain on bargain purchase of $39.9 million related to our acquisition of Linksys during the first quarter of 2025 as compared to a gain on bargain purchase of $106.3 million related to our acquisition of Lacework recorded during the third quarter of 2024 – partially offset by a $7.3 million decrease in foreign currency exchange loss and a $4.8 million increase in net rental income from real estate leases.

[0001262039-25-000039:mdna:156]
[same as prior period, unchanged from 0001262039-25-000028:mdna:158]

[0001262039-25-000039:mdna:157]
|  | Nine Months Ended |  | Change |  | % Change |
| September 30,2025 |  | September 30,2024 |  |
| (in millions, except percentages) |
| Provision for income taxes | $ | 294.3 |  |  | $ | 197.2 |  |  | $ | 97.1 |  |  | 49 | % |
| Effective tax rate (%) | 18 | % |  | 14 | % |  |  |  |  |

[0001262039-25-000039:mdna:158]
Our effective tax rate was 18% for the nine months ended September 30, 2025 compared to an effective tax rate of 14% for the same period last year. The provision for income taxes for the nine months ended September 30, 2025 was primarily comprised of U.S. federal and state taxes, withholding taxes and foreign taxes that were $384.2 million and a tax provision of $30.6 million related to the derecognition of deferred tax assets from the business combination with Linksys. This provision for income taxes was favorably affected by a tax benefit of $62.0 million from the FDII deduction, and excess tax benefits from stock-based compensation expense of $58.5 million.

[0001262039-25-000039:mdna:159]
The provision for income taxes for the nine months ended September 30, 2024 was comprised of U.S. federal and state taxes, withholding taxes, and foreign taxes that were $315.0 million, which were favorably affected by a tax benefit of $84.0 million from the FDII deduction, and excess tax benefits from stock-based compensation expense of $33.8 million.

[0001262039-25-000039:mdna:160]
[same as prior period, unchanged from 0001262039-25-000028:mdna:162]

[0001262039-25-000039:mdna:161]
|  | Nine Months Ended |  | Change |  | % Change |
| September 30,2025 |  | September 30,2024 |  |
| (in millions, except percentages) |
| Gain (loss) from equity method investments | $ | 10.3 |  |  | $ | (23.9) |  |  | $ | 34.2 |  |  | * |
| * not meaningful |  |  |  |  |  |  |  |

[0001262039-25-000039:mdna:162]
The $34.2 million change in gain (loss) from equity method investments during the nine months ended September 30, 2025 compared to the same period last year was primarily driven by a $10.8 million gain related to our acquisition of Linksys in the first quarter of 2025 and a $15.4 million loss due to our proportionate share of Linksys’ financial results including our share of amortization of the basis differences and an OTTI charge of $8.0 million during the nine months ended September 30, 2024.

[0001262039-25-000039:mdna:163]
[same as prior period, unchanged from 0001262039-25-000028:mdna:156]

[0001262039-25-000039:mdna:164]
[same as prior period, unchanged from 0001262039-25-000028:mdna:166]

[0001262039-25-000039:mdna:165]
|  | As of |
|  | September 30,2025 |  | December 31,2024 |
|  | (in millions) |
| Cash and cash equivalents | $ | 1,995.7 |  |  | $ | 2,875.9 |  |
| Short-term investments | 1,127.7 |  |  | 1,190.6 |  |
| Long-term investments | 289.1 |  |  | — |  |
| Total cash, cash equivalents and investments | $ | 3,412.5 |  |  | $ | 4,066.5 |  |
| Working capital | $ | 127.4 |  |  | $ | 1,910.8 |  |
|  | Nine Months Ended |
|  | September 30,2025 |  | September 30,2024 |
|  | (in millions) |
| Net cash provided by operating activities | $ | 1,970.4 |  |  | $ | 1,780.5 |  |
| Net cash used in investing activities | (552.8) |  |  | (647.5) |  |
| Net cash used in financing activities | (2,298.8) |  |  | (41.3) |  |
| Effect of exchange rate changes on cash and cash equivalents | 1.0 |  |  | (0.3) |  |
| Net increase (decrease) in cash and cash equivalents | $ | (880.2) |  |  | $ | 1,091.4 |  |

[0001262039-25-000039:mdna:166]
Liquidity and capital resources are primarily impacted by our operating activities, as well as repurchases of our common stock, real estate purchases and other capital expenditures, investment grade debt balance, payments of taxes in connection with the net settlement of equity awards, proceeds from the issuance of common stock and business combinations.

[0001262039-25-000039:mdna:167]
In recent years, we have received significant capital resources from our billings to customers, issuance of investment grade debt and, to some extent, from the exercise of stock options by our employees. Additional increases in billings may depend on a number of factors, including demand for and availability of our products and services, competition, pricing actions, market or industry changes, macroeconomic events such as rising inflation and changing interest rates, economic strength, supply chain capacity and disruptions, tariffs and other trade restrictions, international conflicts, including the war in Ukraine or tensions between China and Taiwan, an increase in installment billings, and our ability to execute. We expect proceeds from the exercise of stock options in future years to continue to be impacted by the increased mix of restricted stock units and performance stock units versus stock options granted to our employees and to vary based on our share price.

[0001262039-25-000039:mdna:168]
In August 2025, our board of directors approved a $1.0 billion increase in the authorized stock repurchase amount under the Repurchase Program and extended the term of the Repurchase Program to February 28, 2027, bringing the aggregate amount authorized for repurchases to $9.25 billion of our outstanding common stock through February 28, 2027. During the nine months ended September 30, 2025, we repurchased 27.9 million shares of common stock under the Repurchase program for an aggregate purchase price of $2.23 billion. As of September 30, 2025, approximately $795.9 million remained available for future share repurchases. Refer to Note 11. Equity Plans and Share Repurchase Program.

[0001262039-25-000039:mdna:169]
We expect to continue to increase our data center, PoP, office and warehouse capacity to support growth and the expansion of existing services or introduction of new services. As we purchase new properties, we will work to incorporate these properties into the environmental goals we have established. We estimate capital expenditures to be between approximately $60 million and $110 million for the fourth quarter of 2025.

[0001262039-25-000039:mdna:170]
We believe that our cash provided by operating activities, together with our existing cash, cash equivalents and investments will be sufficient to meet our anticipated cash needs and do not currently intend to retire our Senior Notes early. Refer to Note 9. Debt in Part I, Item 1 of this Quarterly Report on Form 10-Q for information on the Senior Notes. As of September 30, 2025, the current portion of long-term debt and long-term debt, net of unamortized discount and debt issuance costs, were $995.9 million.

[0001262039-25-000039:mdna:171]
We purchase components of our inventory from certain suppliers and use several independent contract manufacturers to provide manufacturing services for our products. During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, we enter into agreements with contract manufacturers and suppliers that allow them to procure inventory based upon criteria as defined by us or that establish the parameters defining our requirements. A significant portion of our reported purchase commitments arising from these agreements consists of firm, non-cancelable and

[0001262039-25-000039:mdna:172]
[same as prior period, unchanged from 0001262039-25-000028:mdna:174]

[0001262039-25-000039:mdna:173]
These inventory purchase commitments as of September 30, 2025 totaled $732.5 million, an increase of $141.4 million compared to $591.1 million as of December 31, 2024, as we continued to work with contract manufacturers and suppliers to optimize our inventory and purchase commitments position based on growth trends in customer demand. We record a liability for inventory purchase commitments in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. As of September 30, 2025 and December 31, 2024, the liability for these inventory purchase commitments was $35.2 million and $54.0 million, respectively, and was recorded in accrued liabilities on our condensed consolidated balance sheets.

[0001262039-25-000039:mdna:174]
[same as prior period, unchanged from 0001262039-25-000028:mdna:176]

[0001262039-25-000039:mdna:175]
We also have open purchase orders and contractual obligations in the ordinary course of business for which we have not received goods or services. As of September 30, 2025, we had $112.7 million in other contractual commitments having a remaining term in excess of one year that are non-cancelable.

[0001262039-25-000039:mdna:176]
[same as prior period, unchanged from 0001262039-25-000028:mdna:178]

[0001262039-25-000039:mdna:177]
As of September 30, 2025, our cash, cash equivalents and short-term and long-term investments of $3.41 billion were invested primarily in deposit accounts, commercial paper, corporate debt securities, U.S. government and agency securities, certificates of deposit and term deposits, money market funds and marketable equity securities. It is our investment policy to invest excess cash in a manner that preserves capital, provides liquidity, and generates return without significantly increasing risk. We currently expect to repay the outstanding balance of the 2026 Senior Notes maturing on March 15, 2026 at the date of maturity. Based on current projections, we expect to have sufficient liquidity to fund this repayment and meet our operating requirements for at least the next 12 months and thereafter for the foreseeable future, including our foreseeable future supply obligations, capital expenditures and share repurchases.

[0001262039-25-000039:mdna:178]
The amount of cash, cash equivalents and investments held by our international subsidiaries was $250.6 million as of September 30, 2025 and $207.8 million as of December 31, 2024.

[0001262039-25-000039:mdna:179]
We believe that our existing cash and cash equivalents and cash flow from operations will be sufficient for at least the next 12 months to meet our requirements and plans for cash, including meeting our working capital requirements and capital expenditure requirements. In the long term, our ability to support our requirements and plans for cash, including our working capital and capital expenditure requirements will depend on many factors, including our growth rate, the timing and amount of our share repurchases and debt retirement, the expansion of sales and marketing activities, pricing actions, the introduction of new and enhanced products and services offerings, the continuing market acceptance of our products, the timing and extent of spending to support development efforts, our investments in purchasing, developing or leasing real estate, cash paid for taxes and macroeconomic impacts such as rising inflation and changing interest rates, changes in tariffs and other trade restrictions, impacts of international conflicts, including the war in Ukraine or tensions between China and Taiwan. Historically, we have required capital principally to fund our working capital needs, share repurchases, capital expenditures and acquisition activities. In the event that additional financing is required from outside sources, we may not be able to raise it on terms acceptable to us or at all.

[0001262039-25-000039:mdna:180]
As of September 30, 2025, we did not have any relationships with unconsolidated organizations or financial partnerships, such as structured finance or special purpose entities that would have been established for the purpose of facilitating off-balance sheet arrangements or other contractually narrow or limited purposes.

[0001262039-25-000039:mdna:181]
[same as prior period, unchanged from 0001262039-25-000028:mdna:183]

[0001262039-25-000039:mdna:182]
Cash generated by operating activities is our primary source of liquidity. It is primarily comprised of net income, as adjusted for non-cash items and changes in operating assets and liabilities. Non-cash adjustments consist primarily of amortization of deferred contract costs, stock-based compensation and depreciation and amortization. Changes in operating assets and liabilities consist primarily of changes in accounts receivable—net, deferred contract costs, deferred revenue, inventory, prepaid expenses and other current assets, accrued liabilities and accounts payable.

[0001262039-25-000039:mdna:183]
Our operating activities during the nine months ended September 30, 2025 provided cash flows of $1.97 billion as a result of the continued growth of our business, improved profitability and our ability to successfully manage our working capital. Changes in operating assets and liabilities were primarily driven by a decrease of $308.7 million in accounts receivable—net, an increase of $305.3 million in deferred contract costs and an increase of $288.1 million in our deferred revenue during nine months ended September 30, 2025. In addition, changes in operating assets and liabilities were driven by an increase of $109.1 million in inventory, an increase of $64.3 million in prepaid expenses and other current assets, a decrease of $15.5 million in accrued liabilities, and an increase of $11.5 million in accounts payable.

[0001262039-25-000039:mdna:184]
[same as prior period, unchanged from 0001262039-25-000028:mdna:187]

[0001262039-25-000039:mdna:185]
The changes in cash flows from investing activities primarily relate to timing of purchases, maturities and sales of investments, purchases of property and equipment, investments in equity securities and business combinations. Historically, we have elected to own a facility if we believe that purchasing or developing buildings rather than leasing is more closely aligned with our long-term strategy. We expect to make similar decisions in the future. We may also make cash payments in connection with future business combinations.

[0001262039-25-000039:mdna:186]
During the nine months ended September 30, 2025, cash used in investing activities was $552.8 million, primarily driven by $322.0 million used for the purchases of property and equipment, $189.3 million spent for purchases of investments, net of maturities and sales of investments, and $41.6 million used for payments made in connection with business combinations, net of cash acquired.

[0001262039-25-000039:mdna:187]
[same as prior period, unchanged from 0001262039-25-000028:mdna:190]

[0001262039-25-000039:mdna:188]
[same as prior period, unchanged from 0001262039-25-000028:mdna:191]

[0001262039-25-000039:mdna:189]
During the nine months ended September 30, 2025, cash used in financing activities was $2.30 billion, driven by $2.23 billion used to repurchase shares of our common stock and $66.1 million used to pay tax withholding related to net share settlement of equity awards, net of proceeds from the issuance of common stock.
