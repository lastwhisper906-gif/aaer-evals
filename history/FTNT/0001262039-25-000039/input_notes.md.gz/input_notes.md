# FTNT notes — 0001262039-25-000039


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001262039-25-000039:notes:1]
SUMMARY OF SIGNIFICANT ACCOUNTING POLICIES
Basis of Presentation and Preparation—The unaudited condensed consolidated financial statements of Fortinet, Inc. and its subsidiaries (collectively, “we,” “us” or “our”) have been prepared in accordance with generally accepted accounting principles in the United States (“GAAP”) for interim financial information, as well as the instructions to Form 10-Q pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (the “SEC”). Accordingly, they do not include all of the information and footnotes required by GAAP for complete financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the year ended December 31, 2024, contained in our Annual Report on Form 10-K filed with the SEC on February 21, 2025. In the opinion of management, all adjustments, which include normal recurring adjustments, considered necessary for a fair presentation, have been included. The results of operations for the three and nine months ended September 30, 2025 are not necessarily indicative of the results to be expected for the full year or for any future periods. The condensed consolidated balance sheet as of December 31, 2024 is derived from the audited consolidated financial statements for the year ended December 31, 2024.

[0001262039-25-000039:notes:2]
Amounts previously reported as gain on bargain purchase are included in other income—net in prior periods to conform with current period presentation in our condensed consolidated statements of income. Amounts previously reported as loss from equity method investments and gain on bargain purchase are included in other in prior periods to conform with current period presentation in section of net cash provided by operating activities in our condensed consolidated statements of cash flows.

[0001262039-25-000039:notes:3]
[same as prior period, unchanged from 0001262039-25-000028:notes:3]

[0001262039-25-000039:notes:4]
[same as prior period, unchanged from 0001262039-25-000028:notes:4]

[0001262039-25-000039:notes:5]
There have been no material changes to our significant accounting policies as of and for the nine months ended September 30, 2025, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended December 31, 2024 filed with the SEC.

[0001262039-25-000039:notes:6]
[same as prior period, unchanged from 0001262039-25-000028:notes:6]

[0001262039-25-000039:notes:7]
[same as prior period, unchanged from 0001262039-25-000028:notes:7]

[0001262039-25-000039:notes:8]
In December 2023, the Financial Accounting Standards Board (the “FASB”) issued Accounting Standards Update (“ASU”) 2023-09, Income Taxes (Topic 740): Improvements to Income Tax Disclosures, which includes amendments that further enhance income tax disclosures, primarily through standardization and disaggregation of rate reconciliation categories and income taxes paid by jurisdiction. The amendments are effective for our annual period beginning fiscal year 2025, with early adoption permitted, and should be applied prospectively. We are currently evaluating the ASU to determine its impact on our disclosures.

[0001262039-25-000039:notes:9]
[same as prior period, unchanged from 0001262039-25-000028:notes:9]

[0001262039-25-000039:notes:10]
In November 2024, the FASB issued ASU 2024-03, Income Statement—Reporting Comprehensive Income—Expense Disaggregation Disclosures (Subtopic 220-40): Disaggregation of Income Statement Expenses (ASU 2024-03), and in January 2025, the FASB issued ASU No. 2025-01, Income Statement—Reporting Comprehensive Income—Expense Disaggregation Disclosures (Subtopic 220-40): Clarifying the Effective Date, which clarified the effective date of ASU 2024-03. ASU 2024-03 enhances the disclosures required for expense disaggregation in our annual and interim consolidated financial statements. The amendments are effective for our annual reporting period beginning fiscal year 2027, with early adoption permitted, and can be applied prospectively or retrospectively. We are currently evaluating the ASU to determine its impact on our disclosures.

[0001262039-25-000039:notes:11]
Credit Losses

[0001262039-25-000039:notes:12]
In July 2025, the FASB issued ASU 2025-05—Financial Instruments—Credit Losses (Topic 326): Measurement of Credit Losses for Accounts Receivable and Contract Assets (“ASU 2025-05”), which provides a practical expedient for estimating expected credit losses for current accounts receivable and current contract assets that arise from transactions accounted for under Revenue from Contracts with Customers (Topic 606). The amendments are effective for our annual reporting period beginning with fiscal year 2026 and interim reporting periods within those annual reporting periods on a prospective basis, with early adoption permitted. We are currently evaluating ASU 2025-05 to determine its impact on our consolidated financial statements and related disclosures.

[0001262039-25-000039:notes:13]
Internal-Use Software

[0001262039-25-000039:notes:14]
In September 2025, the FASB issued ASU 2025-06, Intangibles—Goodwill and Other—Internal-Use Software (Subtopic 350-40): Targeted Improvements to the Accounting for Internal-Use Software (“ASU 2025-06”), which amends the cost capitalization criteria for internal-use software development costs by removing all references to prescriptive and sequential software project development stages and providing new guidance on how to evaluate whether the probable-to-complete recognition threshold has been met. The amendments are effective for our annual period beginning fiscal year 2028 and interim reporting periods within those annual reporting periods and can be applied prospectively, retrospectively, or via a modified prospective transition method, with early adoption permitted. We are currently assessing adoption timing and the method of adoption.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001262039-25-000039:notes:15]
[same as prior period, unchanged from 0001262039-25-000028:notes:11]

[0001262039-25-000039:notes:16]
[same as prior period, unchanged from 0001262039-25-000028:notes:12]

[0001262039-25-000039:notes:17]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30,2025 |  | September 30,2024 |  | September 30,2025 |  | September 30,2024 |
| Product | $ | 559.3 |  |  | $ | 473.9 |  |  | $ | 1,527.3 |  |  | $ | 1,334.7 |  |
| Service: |  |  |  |  |  |  |  |
| Security subscription | 672.0 |  |  | 595.8 |  |  | 1,939.5 |  |  | 1,691.4 |  |
| Technical support and other | 493.6 |  |  | 438.4 |  |  | 1,427.8 |  |  | 1,269.6 |  |
| Total service revenue | 1,165.6 |  |  | 1,034.2 |  |  | 3,367.3 |  |  | 2,961.0 |  |
| Total revenue | $ | 1,724.9 |  |  | $ | 1,508.1 |  |  | $ | 4,894.6 |  |  | $ | 4,295.7 |  |

[0001262039-25-000039:notes:18]
[same as prior period, unchanged from 0001262039-25-000028:notes:14]

[0001262039-25-000039:notes:19]
During the three and nine months ended September 30, 2025, we recognized $759.2 million and $2.61 billion in revenue that was included in the deferred revenue balance as of December 31, 2024, respectively. During the three and nine months ended September 30, 2024, we recognized $660.3 million and $2.28 billion in revenue that was included in the deferred revenue balance as of December 31, 2023, respectively.

[0001262039-25-000039:notes:20]
[same as prior period, unchanged from 0001262039-25-000028:notes:16]

[0001262039-25-000039:notes:21]
As of September 30, 2025, the aggregate amount of the transaction price allocated to remaining performance obligations was $6.72 billion, which was substantially comprised of deferred security subscription and technical support services revenue as well as unbilled contract revenue from non-cancellable contracts that will be recognized in future periods. We expect to recognize approximately $3.49 billion as revenue over the next 12 months, $2.62 billion in years two and three, and the remainder thereafter.

[0001262039-25-000039:notes:22]
[same as prior period, unchanged from 0001262039-25-000028:notes:18]

[0001262039-25-000039:notes:23]
Amortization of deferred contract costs, primarily consisting of sales commissions earned by our sales force, was $86.0 million and $73.6 million during the three months ended September 30, 2025 and 2024, respectively. Amortization of

[0001262039-25-000039:notes:24]
deferred contract costs was $246.0 million and $218.3 million during the nine months ended September 30, 2025 and 2024, respectively.


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0001262039-25-000039:notes:25]
[same as prior period, unchanged from 0001262039-25-000028:notes:20]

[0001262039-25-000039:notes:26]
[same as prior period, unchanged from 0001262039-25-000028:notes:21]

[0001262039-25-000039:notes:27]
|  | September 30, 2025 |
|  | AmortizedCost |  | UnrealizedGains |  | UnrealizedLosses |  | FairValue |
| U.S. government and agency securities | $ | 560.0 |  |  | $ | 0.6 |  |  | $ | (0.1) |  |  | $ | 560.5 |  |
| Commercial paper | 370.4 |  |  | 0.1 |  |  | — |  |  | 370.5 |  |
| Corporate debt securities | 285.2 |  |  | 0.3 |  |  | (0.1) |  |  | 285.4 |  |
| Certificates of deposit and term deposits | 102.2 |  |  | 0.1 |  |  | — |  |  | 102.3 |  |
| Total available-for-sale investments | 1,317.8 |  |  | 1.1 |  |  | (0.2) |  |  | 1,318.7 |  |
| Marketable equity securities |  |  |  |  |  |  | 98.1 |  |
| Total short-term and long-term investments | $ | 1,317.8 |  |  | $ | 1.1 |  |  | $ | (0.2) |  |  | $ | 1,416.8 |  |

[0001262039-25-000039:notes:28]
[same as prior period, unchanged from 0001262039-25-000028:notes:23]

[0001262039-25-000039:notes:29]
[same as prior period, unchanged from 0001262039-25-000028:notes:24]

[0001262039-25-000039:notes:30]
|  | September 30, 2025 |
|  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
|  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |
| U.S. government and agency securities | $ | 560.5 |  |  | $ | (0.1) |  |  | $ | — |  |  | $ | — |  |  | $ | 560.5 |  |  | $ | (0.1) |  |
| Commercial paper | 370.5 |  |  | — |  |  | — |  |  | — |  |  | 370.5 |  |  | — |  |
| Corporate debt securities | 285.4 |  |  | (0.1) |  |  | — |  |  | — |  |  | 285.4 |  |  | (0.1) |  |
| Certificates of deposit and term deposits | 102.3 |  |  | — |  |  | — |  |  | — |  |  | 102.3 |  |  | — |  |
| Total available-for-sale investments | $ | 1,318.7 |  |  | $ | (0.2) |  |  | $ | — |  |  | $ | — |  |  | $ | 1,318.7 |  |  | $ | (0.2) |  |

[0001262039-25-000039:notes:31]
[same as prior period, unchanged from 0001262039-25-000028:notes:26]

[0001262039-25-000039:notes:32]
[same as prior period, unchanged from 0001262039-25-000028:notes:27]

[0001262039-25-000039:notes:33]
|  | September 30,2025 |  | December 31,2024 |
| Due within one year | $ | 1,029.6 |  |  | $ | 1,126.4 |  |
| Due within one to three years | 289.1 |  |  | — |  |
| Total | $ | 1,318.7 |  |  | $ | 1,126.4 |  |

[0001262039-25-000039:notes:34]
[same as prior period, unchanged from 0001262039-25-000028:notes:29]

[0001262039-25-000039:notes:35]
[same as prior period, unchanged from 0001262039-25-000028:notes:30]

[0001262039-25-000039:notes:36]
The changes in fair value of our marketable equity securities are recorded in other income—net on the condensed consolidated statements of income. We recognized a $14.1 million and $10.7 million gain during the three and nine months ended September 30, 2025, respectively. We recognized a $11.1 million and $11.2 million gain during the three and nine months ended September 30, 2024, respectively.

[0001262039-25-000039:notes:37]
[same as prior period, unchanged from 0001262039-25-000028:notes:32]

[0001262039-25-000039:notes:38]
[same as prior period, unchanged from 0001262039-25-000028:notes:33]

[0001262039-25-000039:notes:39]
|  | September 30, 2025 |  | December 31, 2024 |
|  | AggregateFairValue |  | QuotedPrices inActiveMarkets ForIdenticalAssets |  | SignificantOtherObservableRemainingInputs |  | SignificantOtherUnobservableRemainingInputs |  | AggregateFairValue |  | QuotedPrices inActiveMarkets ForIdenticalAssets |  | SignificantOtherObservableRemainingInputs |  | SignificantOtherUnobservableRemainingInputs |
|  |  |  | (Level 1) |  | (Level 2) |  | (Level 3) |  |  |  | (Level 1) |  | (Level 2) |  | (Level 3) |
| Cash equivalents: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | $ | 170.5 |  |  | $ | 170.5 |  |  | $ | — |  |  | $ | — |  |  | $ | 296.1 |  |  | $ | 296.1 |  |  | $ | — |  |  | $ | — |  |
| Commercial paper | 34.0 |  |  | — |  |  | 34.0 |  |  | — |  |  | 59.7 |  |  | — |  |  | 59.7 |  |  | — |  |
| Certificates of deposit and term deposits | 4.5 |  |  | — |  |  | 4.5 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Total cash equivalents | 209.0 |  |  | 170.5 |  |  | 38.5 |  |  | — |  |  | 355.8 |  |  | 296.1 |  |  | 59.7 |  |  | — |  |
| Short-term investments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. government and agency securities | 437.1 |  |  | 437.1 |  |  | — |  |  | — |  |  | 469.5 |  |  | 464.5 |  |  | 5.0 |  |  | — |  |
| Commercial paper | 370.5 |  |  | — |  |  | 370.5 |  |  | — |  |  | 428.7 |  |  | — |  |  | 428.7 |  |  | — |  |
| Corporate debt securities | 119.7 |  |  | — |  |  | 119.7 |  |  | — |  |  | 166.4 |  |  | — |  |  | 166.4 |  |  | — |  |
| Certificates of deposit and term deposits | 102.3 |  |  | — |  |  | 102.3 |  |  | — |  |  | 61.8 |  |  | — |  |  | 61.8 |  |  | — |  |
| Marketable equity securities | 98.1 |  |  | 98.1 |  |  | — |  |  | — |  |  | 64.2 |  |  | 64.2 |  |  | — |  |  | — |  |
| Total short-term investments | 1,127.7 |  |  | 535.2 |  |  | 592.5 |  |  | — |  |  | 1,190.6 |  |  | 528.7 |  |  | 661.9 |  |  | — |  |
| Long-term investments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. government and agency securities | 123.4 |  |  | 113.3 |  |  | 10.1 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Corporate debt securities | 165.7 |  |  | — |  |  | 165.7 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Total long-term investments | 289.1 |  |  | 113.3 |  |  | 175.8 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Total | $ | 1,625.8 |  |  | $ | 819.0 |  |  | $ | 806.8 |  |  | $ | — |  |  | $ | 1,546.4 |  |  | $ | 824.8 |  |  | $ | 721.6 |  |  | $ | — |  |

[0001262039-25-000039:notes:40]
There were no transfers between Level 1 and Level 2 of the fair value hierarchy during the nine months ended September 30, 2025 and year ended December 31, 2024.


## us-gaap:InventoryDisclosureTextBlock

[0001262039-25-000039:notes:41]
[same as prior period, unchanged from 0001262039-25-000028:notes:36]

[0001262039-25-000039:notes:42]
|  | September 30,2025 |  | December 31,2024 |
| Raw materials | $ | 63.6 |  |  | $ | 90.9 |  |
| Work in process | 4.6 |  |  | 4.1 |  |
| Finished goods | 358.4 |  |  | 220.5 |  |
| Inventory | $ | 426.6 |  |  | $ | 315.5 |  |

[0001262039-25-000039:notes:43]
The excess and obsolete inventory reserve was $141.9 million and $144.8 million as of September 30, 2025 and December 31, 2024, respectively. Inventory write-downs related to excess and obsolete inventory were immaterial during the three and nine months ended September 30, 2025, and were $8.8 million and $37.6 million during the three and nine months

[0001262039-25-000039:notes:44]
ended September 30, 2024, respectively. These were recorded in cost of product revenue on the condensed consolidated statements of income.


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001262039-25-000039:notes:45]
[same as prior period, unchanged from 0001262039-25-000028:notes:40]

[0001262039-25-000039:notes:46]
|  | September 30,2025 |  | December 31,2024 |
| Land | $ | 592.4 |  |  | $ | 500.6 |  |
| Buildings and improvements | 974.1 |  |  | 801.4 |  |
| Computer equipment and software | 324.5 |  |  | 279.1 |  |
| Leasehold improvements | 64.4 |  |  | 64.3 |  |
| Evaluation units | 23.4 |  |  | 31.8 |  |
| Furniture and fixtures | 38.3 |  |  | 36.4 |  |
| Construction-in-progress | 50.5 |  |  | 52.0 |  |
| Total property and equipment | 2,067.6 |  |  | 1,765.6 |  |
| Less: accumulated depreciation | (462.4) |  |  | (416.1) |  |
| Property and equipment—net | $ | 1,605.2 |  |  | $ | 1,349.5 |  |

[0001262039-25-000039:notes:47]
[same as prior period, unchanged from 0001262039-25-000028:notes:42]

[0001262039-25-000039:notes:48]
During the three months ended June 30, 2025, we purchased certain real estate properties in Canada, the United States and the Netherlands for an aggregate purchase price of $130.5 million, to be used predominantly for data center operations, office space and warehouse operations. The purchases were accounted for under the asset acquisition method, with $43.0 million allocated to land and $87.5 million allocated to buildings and improvements, based on their relative fair values.

[0001262039-25-000039:notes:49]
During the three months ended September 30, 2025, we purchased certain real estate properties in Canada and the United Kingdom for an aggregate purchase price of $70.8 million, to be used predominantly for office space. The purchases were accounted for under the asset acquisition method, with $37.5 million allocated to land and $33.3 million allocated to buildings and improvements, based on their relative fair values.

[0001262039-25-000039:notes:50]
Depreciation expense was $25.3 million and $24.5 million during the three months ended September 30, 2025 and 2024, respectively. Depreciation expense was $74.4 million and $76.0 million during the nine months ended September 30, 2025 and 2024, respectively.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001262039-25-000039:notes:51]
[same as prior period, unchanged from 0001262039-25-000028:notes:45]

[0001262039-25-000039:notes:52]
[same as prior period, unchanged from 0001262039-25-000028:notes:46]

[0001262039-25-000039:notes:53]
[same as prior period, unchanged from 0001262039-25-000028:notes:47]

[0001262039-25-000039:notes:54]
This acquisition was accounted for as a business combination using the acquisition method of accounting. Of the aggregate purchase price, $17.5 million was allocated to identifiable intangible assets acquired, and $64.7 million was allocated

[0001262039-25-000039:notes:55]
to other net assets acquired which predominantly included deferred tax asset of $45.8 million, inventory of $21.4 million, and cash of $8.8 million, offset by $11.3 million of net other assets and liabilities assumed. The excess of the fair values of the net assets acquired over the net purchase consideration was recorded as a gain on bargain purchase of $39.9 million within other income—net on the condensed consolidated statements of income. The gain on bargain purchase occurred primarily due to the recognition of the deferred tax assets. The deferred tax assets were comprised primarily of pre-acquisition federal net operating loss carryforwards with an indefinite carryforward period. In addition, we had previously recorded a deferred tax asset of $30.6 million for an outside basis difference in our investment in Linksys when it was accounted for under the equity method. As a result of the acquisition of the remaining shares, we now account for our investment in Linksys under the consolidation method, and therefore we have derecognized this deferred tax asset. The charge is included in the provision for income taxes on the condensed consolidated statements of income. Acquisition-related costs related to this acquisition were not material and were recorded as general and administrative expense.

[0001262039-25-000039:notes:56]
[same as prior period, unchanged from 0001262039-25-000028:notes:50]

[0001262039-25-000039:notes:57]
During the three months ended June 30, 2025, we completed other acquisitions for total purchase consideration of $38.3 million in cash. We have accounted for the transactions as business combinations and recorded goodwill of $21.9 million, among which $8.6 million of goodwill is expected to be deductible and $13.3 million of goodwill is not deductible for income tax purposes. Acquisition-related costs were not material and were recorded as general and administrative expense.

[0001262039-25-000039:notes:58]
[same as prior period, unchanged from 0001262039-25-000028:notes:52]

[0001262039-25-000039:notes:59]
[same as prior period, unchanged from 0001262039-25-000028:notes:53]

[0001262039-25-000039:notes:60]
[same as prior period, unchanged from 0001262039-25-000028:notes:54]

[0001262039-25-000039:notes:61]
[same as prior period, unchanged from 0001262039-25-000028:notes:55]

[0001262039-25-000039:notes:62]
[same as prior period, unchanged from 0001262039-25-000028:notes:56]

[0001262039-25-000039:notes:63]
This acquisition was accounted for as a business combination using the acquisition method of accounting. The total purchase price was allocated to Next DLP’s identifiable tangible and intangible assets acquired and liabilities assumed based on their estimated fair values using management’s best estimates and assumptions to assign fair value as of the acquisition date. Of the total purchase price, $82.6 million was allocated to goodwill, $13.5 million was allocated to developed technology intangible asset, $10.5 million was allocated to customer relationships intangible asset, offset by $1.6 million of net liabilities assumed, which predominantly included deferred revenue and deferred tax liabilities. Goodwill recorded in connection with this acquisition represents the value we expect to be created through expansion into markets within our existing business, and the anticipated operational synergies, and goodwill is expected to be deductible for U.S. tax purposes. Acquisition-related costs related to this acquisition were not material and were recorded as general and administrative expense.

[0001262039-25-000039:notes:64]
[same as prior period, unchanged from 0001262039-25-000028:notes:59]

[0001262039-25-000039:notes:65]
[same as prior period, unchanged from 0001262039-25-000028:notes:60]

[0001262039-25-000039:notes:66]
This acquisition was accounted for as a business combination using the acquisition method of accounting. The total purchase price was allocated to Lacework’s identifiable tangible and intangible assets acquired and liabilities assumed based on

[0001262039-25-000039:notes:67]
their estimated fair values using management’s best estimates and assumptions to assign fair value as of the acquisition date. Of the total purchase price, $244.4 million was allocated to deferred tax assets, $61.3 million allocation to identifiable intangible assets, and $6.2 million cash, offset by net other assets and liabilities assumed of $53.3 million, which predominantly included deferred revenue and other current liabilities. The excess of the fair values of the net assets acquired over the net purchase consideration was recorded as a gain on bargain purchase of $106.3 million within other income—net on the condensed consolidated statements of income. The gain on bargain purchase occurred primarily due to the recognition of the deferred tax assets. The deferred tax assets were comprised primarily of pre-acquisition federal net operating loss carryforwards with an indefinite carryforward period. Acquisition-related costs related to this acquisition were not material and were recorded as general and administrative expense.

[0001262039-25-000039:notes:68]
[same as prior period, unchanged from 0001262039-25-000028:notes:63]

[0001262039-25-000039:notes:69]
[same as prior period, unchanged from 0001262039-25-000028:notes:65]

[0001262039-25-000039:notes:70]
[same as prior period, unchanged from 0001262039-25-000028:notes:66]


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001262039-25-000039:notes:71]
[same as prior period, unchanged from 0001262039-25-000028:notes:67]

[0001262039-25-000039:notes:72]
[same as prior period, unchanged from 0001262039-25-000028:notes:68]

[0001262039-25-000039:notes:73]
|  | Amount |
| Balance—December 31, 2024 | $ | 235.4 |  |
| Additions due to business combinations | 21.9 |  |
| Foreign currency translation adjustments | 1.0 |  |
| Balance—September 30, 2025 | $ | 258.3 |  |

[0001262039-25-000039:notes:74]
There were no impairments to goodwill during the nine months ended September 30, 2025 or during prior periods.

[0001262039-25-000039:notes:75]
[same as prior period, unchanged from 0001262039-25-000028:notes:71]

[0001262039-25-000039:notes:76]
[same as prior period, unchanged from 0001262039-25-000028:notes:72]

[0001262039-25-000039:notes:77]
|  | September 30, 2025 |
|  | Weighted-Average Useful Life (in Years) |  | Gross |  | Accumulated Amortization |  | Net |
| Other intangible assets—net: |  |  |  |  |  |  |  |
| Finite-lived intangible assets: |  |  |  |  |  |  |  |
| Developed technologies | 4.3 |  | $ | 160.1 |  |  | $ | 91.9 |  |  | $ | 68.2 |  |
| Customer relationships | 5.3 |  | 67.3 |  |  | 38.5 |  |  | 28.8 |  |
| Trade names | 4.2 |  | 11.5 |  |  | 3.4 |  |  | 8.1 |  |
| Backlog | 2.5 |  | 13.7 |  |  | 8.6 |  |  | 5.1 |  |
| Total other intangible assets—net |  |  | $ | 252.6 |  |  | $ | 142.4 |  |  | $ | 110.2 |  |

[0001262039-25-000039:notes:78]
|  | December 31, 2024 |
|  | Weighted-Average Useful Life (in Years) |  | Gross |  | Accumulated Amortization |  | Net |
| Other intangible assets—net: |  |  |  |  |  |  |  |
| Finite-lived intangible assets: |  |  |  |  |  |  |  |
| Developed technologies | 4.4 |  | $ | 141.9 |  |  | $ | 73.7 |  |  | $ | 68.2 |  |
| Customer relationships | 5.5 |  | 53.9 |  |  | 23.0 |  |  | 30.9 |  |
| Trade names | 7.5 |  | 8.8 |  |  | 1.8 |  |  | 7.0 |  |
| Backlog | 2.5 |  | 13.5 |  |  | 4.6 |  |  | 8.9 |  |
| Total other intangible assets—net |  |  | $ | 218.1 |  |  | $ | 103.1 |  |  | $ | 115.0 |  |

[0001262039-25-000039:notes:79]
Amortization expense was $13.1 million and $5.3 million during the three months ended September 30, 2025 and 2024, respectively. Amortization expense was $38.1 million and $11.6 million during the nine months ended September 30, 2025 and 2024, respectively.

[0001262039-25-000039:notes:80]
[same as prior period, unchanged from 0001262039-25-000028:notes:76]

[0001262039-25-000039:notes:81]
|  | Amount |
| Years: |  |
| 2025 (the remainder of 2025) | $ | 12.5 |  |
| 2026 | 37.3 |  |
| 2027 | 27.6 |  |
| 2028 | 20.0 |  |
| 2029 | 9.4 |  |
| Thereafter | 3.4 |  |
| Total | $ | 110.2 |  |


## us-gaap:EarningsPerShareTextBlock

[0001262039-25-000039:notes:82]
[same as prior period, unchanged from 0001262039-25-000028:notes:78]

[0001262039-25-000039:notes:83]
[same as prior period, unchanged from 0001262039-25-000028:notes:79]

[0001262039-25-000039:notes:84]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30,2025 |  | September 30,2024 |  | September 30,2025 |  | September 30,2024 |
| Numerator: |  |  |  |  |  |  |  |
| Net income | $ | 473.9 |  |  | $ | 539.9 |  |  | $ | 1,347.4 |  |  | $ | 1,219.0 |  |
| Denominator: |  |  |  |  |  |  |  |
| Basic shares: |  |  |  |  |  |  |  |
| Weighted-average common stock outstanding-basic | 755.5 |  |  | 765.0 |  |  | 763.1 |  |  | 763.7 |  |
| Diluted shares: |  |  |  |  |  |  |  |
| Weighted-average common stock outstanding-basic | 755.5 |  |  | 765.0 |  |  | 763.1 |  |  | 763.7 |  |
| Effect of potentially dilutive securities: |  |  |  |  |  |  |  |
| RSUs | 1.9 |  |  | 2.0 |  |  | 2.6 |  |  | 2.1 |  |
| Stock options | 3.4 |  |  | 4.4 |  |  | 4.0 |  |  | 4.7 |  |
| PSUs | 0.4 |  |  | 0.5 |  |  | 0.5 |  |  | 0.3 |  |
| Weighted-average shares used to compute diluted net income per share | 761.2 |  |  | 771.9 |  |  | 770.2 |  |  | 770.8 |  |
| Net income per share |  |  |  |  |  |  |  |
| Basic | $ | 0.63 |  |  | $ | 0.71 |  |  | $ | 1.77 |  |  | $ | 1.60 |  |
| Diluted | $ | 0.62 |  |  | $ | 0.70 |  |  | $ | 1.75 |  |  | $ | 1.58 |  |

[0001262039-25-000039:notes:85]
[same as prior period, unchanged from 0001262039-25-000028:notes:81]

[0001262039-25-000039:notes:86]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30,2025 |  | September 30,2024 |  | September 30,2025 |  | September 30,2024 |
| RSUs | 2.3 |  |  | 0.4 |  |  | 1.8 |  |  | 0.2 |  |
| Stock options | 0.8 |  |  | 3.1 |  |  | 0.6 |  |  | 3.3 |  |
| PSUs | — |  |  | — |  |  | — |  |  | 0.1 |  |
| Total | 3.1 |  |  | 3.5 |  |  | 2.4 |  |  | 3.6 |  |


## us-gaap:DebtDisclosureTextBlock

[0001262039-25-000039:notes:87]
DEBT
2026 and 2031 Senior Notes

[0001262039-25-000039:notes:88]
On March 5, 2021, we issued $1.0 billion aggregate principal amount of senior notes (collectively, the “Senior Notes”), consisting of $500.0 million aggregate principal amount of 1.0% notes due March 15, 2026 (the “2026 Senior Notes”) and $500.0 million aggregate principal amount of 2.2% notes due March 15, 2031 (the “2031 Senior Notes”), in an underwritten registered public offering. The Senior Notes are senior unsecured obligations and rank equally with each other in right of payment and with our other outstanding obligations. We may redeem the Senior Notes at any time in whole or in part for cash, at specified redemption prices that include accrued and unpaid interest, if any, and a make-whole premium. However, no make-whole premium will be paid for redemptions of the 2026 Senior Notes on or after February 15, 2026, or the 2031 Senior Notes on or after December 15, 2030. Interest on the Senior Notes is payable on March 15 and September 15 of each year, beginning on September 15, 2021. The 2026 Senior Notes were recorded as current portion of long-term debt and the 2031 Senior Notes were recorded as long-term debt as of September 30, 2025 and both of the Senior Notes were recorded as long-term debt as of December 31, 2024, net of discount and issuance costs, which are amortized to interest expense over the respective contractual terms of these notes using the effective interest method.

[0001262039-25-000039:notes:89]
The total outstanding debt is summarized below (in millions, except percentages):

[0001262039-25-000039:notes:90]
|  | Maturity |  | Coupon Rate |  | Effective Interest Rate |  | September 30,2025 |  | December 31,2024 |
| Debt |  |  |  |  |  |  |  |  |  |
| 2026 Senior Notes | March 2026 |  | 1.0% |  | 1.3% |  | $ | 500.0 |  |  | $ | 500.0 |  |
| 2031 Senior Notes | March 2031 |  | 2.2% |  | 2.3% |  | 500.0 |  |  | 500.0 |  |
| Total debt |  |  |  |  |  |  | 1,000.0 |  |  | 1,000.0 |  |
| Less: Unamortized discount and debt issuance costs |  |  |  |  |  |  | 4.1 |  |  | 5.7 |  |
| Less: Current portion of long-term debt |  |  |  |  |  |  | $ | 499.4 |  |  | $ | — |  |
| Total long-term debt |  |  |  |  |  |  | $ | 496.5 |  |  | $ | 994.3 |  |

[0001262039-25-000039:notes:91]
As of September 30, 2025 and December 31, 2024, we accrued interest payable of $0.7 million and $4.7 million, respectively, and there are no financial covenants with which we must comply. During the three months ended September 30, 2025 and 2024, we recorded $4.5 million of total interest expense in relation to these Senior Notes in each period. During the nine months ended September 30, 2025 and 2024, we recorded $13.5 million of total interest expense in relation to these Senior Notes in each period. No interest costs were capitalized for the nine months ended September 30, 2025 and 2024, as the costs that qualified for capitalization were not material.

[0001262039-25-000039:notes:92]
The total estimated fair value of the outstanding Senior Notes was approximately $939.4 million, including accrued and unpaid interest, as of September 30, 2025. The fair value was determined based on observable market prices of identical instruments in less active markets. The estimated fair values are based on Level 2 inputs.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001262039-25-000039:notes:93]
COMMITMENTS AND CONTINGENCIES
The following table summarizes our inventory purchase commitments as of September 30, 2025 (in millions):

[0001262039-25-000039:notes:94]
|  | Total |  | 2025 |  | Thereafter |
| Inventory purchase commitments | $ | 732.5 |  |  | $ | 359.5 |  |  | $ | 373.0 |  |

[0001262039-25-000039:notes:95]
Inventory Purchase Commitments—We purchase components of our inventory from certain suppliers and use several independent contract manufacturers to provide manufacturing services for our products. During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, we enter into agreements with contract manufacturers and suppliers that allow them to procure inventory based upon criteria as defined by us or establish the parameters defining our requirements. A significant portion of our reported purchase commitments arising from these agreements consists of firm, non-cancelable and unconditional commitments. Certain of these inventory purchase commitments with contract manufacturers and suppliers relate to arrangements to secure supply and pricing for certain product components for multi-year periods. In certain instances, these agreements allow us the option to reschedule and adjust our requirements based on our business needs prior to firm orders being placed.

[0001262039-25-000039:notes:96]
As of September 30, 2025, we had $732.5 million of non-cancelable inventory purchase commitments with our independent contract manufacturers. We recorded a liability for these purchase commitments for quantities in excess of our future estimated demand forecasts, consistent with the valuation of our excess and obsolete inventory. As of September 30, 2025 and December 31, 2024, the liability for these inventory purchase commitments was $35.2 million and $54.0 million, respectively, and was recorded in accrued liabilities on our condensed consolidated balance sheets. The expense related to such accrued liability for inventory purchase commitments is recorded in cost of product revenue on the condensed consolidated statements of income. The expense related to such accrued liability for inventory purchase commitments was immaterial during the three and nine months ended September 30, 2025, and was a $27.4 million benefit and a $11.2 million cost during the three and nine months ended September 30, 2024, respectively.

[0001262039-25-000039:notes:97]
Other Contractual Commitments and Open Purchase Orders—In addition to commitments with contract manufacturers, we have open purchase orders and contractual obligations in the ordinary course of business for which we have not received goods or services. A significant portion of our reported purchase commitments consist of non-cancelable commitments. In certain instances, contractual commitments allow us the option to cancel, reschedule and adjust our

[0001262039-25-000039:notes:98]
requirements based on our business needs prior to firm orders being placed. As of September 30, 2025, we had $112.7 million in other contractual commitments having a remaining term in excess of one year that are non-cancelable.

[0001262039-25-000039:notes:99]
As of September 30, 2025, we had $92.9 million in contractual commitments related to payments for operating leases.

[0001262039-25-000039:notes:100]
Litigation—We are involved in disputes, litigation, and other legal actions. For lawsuits where we are the defendant, we are in the process of defending these litigation matters, and while there can be no assurances and the outcome of certain of these matters is currently not determinable and not predictable, we currently are unaware of any existing claims or proceedings that we believe are likely to have a material adverse effect on our financial position. There are many uncertainties associated with any litigation and these actions or other third-party claims against us may cause us to incur costly litigation fees, costs and substantial settlement charges, and possibly subject us to damages and other penalties. In addition, the resolution of any intellectual property (“IP”) litigation may require us to make royalty payments, which could adversely affect our gross margins in future periods. If any of those events were to occur, our business, financial condition, results of operations, and cash flows could be adversely affected. Litigation is unpredictable and the actual liability in any such matters may be materially different from our current estimates, which could result in the need to adjust any accrued liability and record additional expenses. We accrue for contingencies when we believe that a loss is probable and that we can reasonably estimate the amount of any such loss. These accruals are generally based on a range of possible outcomes that require significant management judgment. If no amount within a range is a better estimate than any other, we accrue the minimum amount. Litigation loss contingency accruals associated with outstanding cases were not material as of September 30, 2025 and December 31, 2024.

[0001262039-25-000039:notes:101]
On September 22, 2025, a securities class action was filed against us, our chief executive officer, our chief technology officer, our current chief financial officer and our former chief financial officer in the United States District Court, Northern District of California, captioned Oklahoma Firefighters Pension and Retirement System v. Fortinet, Inc., et al., Case No. 5:25-cv-08037. On October 16, 2025, a securities class action was filed against us, our chief executive Officer, our current chief financial officer and our former chief financial officer in the same court, captioned State of Rhode Island Office of the General Treasurer v. Fortinet, Inc., et al., Case No. 3:25-cv-08888. These suits are brought on behalf of an alleged class of stockholders who purchased or acquired shares of our common stock between November 8, 2024 through August 6, 2025. The complaints allege that defendants made false or misleading statements about our business, operations and prospects, including regarding the 2026 firewall refresh cycle, and purport to assert claims under Sections 10(b) and 20(a) of the Exchange Act. The time to respond to the complaints has not yet passed. We believe these cases are without merit and defendants intend to defend the suits vigorously. Based on the preliminary nature of the proceedings in these cases, the outcome of these matters remains uncertain and we cannot estimate the potential impact, if any, on its business or financial statements at this time. Accordingly, no loss accrual was recorded as of September 30, 2025 related to these litigations. On October 8, 2025, Plaintiff Jack Pittrof filed a stockholder derivative complaint against us as a nominal defendant and certain of our current and former directors and officers in the United States District Court for the Northern District of California. The complaint alleges claims based on events similar to those in the securities class action and asserts causes of action against the individual defendants for breach of fiduciary duty, aiding and abetting breach of fiduciary duty, unjust enrichment, waste of corporate assets, and for making false and misleading statements about our business, operations, and prospects in violation of Section 10(b) of the Exchange Act. The time to respond to the complaint has not yet passed.

[0001262039-25-000039:notes:102]
On March 21, 2019, we were sued by Alorica Inc. (“Alorica”) in Santa Clara County Superior Court in California. Alorica alleged breach of warranty and misrepresentation claims, which we denied. After trial, a jury returned a verdict fully in favor of us and against Alorica on October 4, 2024. Alorica has filed a notice of appeal. We believe that the ultimate outcome of this matter will not materially impact our financial position, results of operations or cash flows. However, any further legal proceedings, including Alorica’s appeal, would be subject to inherent uncertainties, and a future unfavorable ruling could occur. No loss accrual had been recorded as of September 30, 2025 or December 31, 2024 related to this litigation.

[0001262039-25-000039:notes:103]
Indemnification and Other Matters—We enter into indemnification provisions in the ordinary course of business with other companies such as partners, customers, and vendors, where we agree to indemnify, hold harmless, and reimburse the indemnified party for certain losses suffered or incurred by the indemnified party as a result of our activities, including defending against third-party claims asserting various allegations such as product defects, breach of representations or covenants, and infringement of certain IP rights, which may include patents, copyrights, trademarks or trade secrets, and to pay judgments entered on such claims. In some contracts, our exposure under these indemnification provisions is limited by the terms of the contracts to certain defined limits, such as the total amount paid by our customer under the agreement. However, certain agreements include covenants, penalties and indemnification provisions including and beyond indemnification for third-party claims of IP infringement that could potentially expose us to losses in excess of the amount received under the agreement, and in some instances to potential liability that is not contractually limited. Although from time to time there are

[0001262039-25-000039:notes:104]
indemnification claims asserted against us and currently there are pending indemnification claims, to date there have been no material awards under such indemnification provisions.

[0001262039-25-000039:notes:105]
Similar to other security companies and companies in other industries, we have experienced and may experience in the future, cybersecurity threats, malicious activity directed against our information technology infrastructure or unauthorized attempts to gain access to our and our customers’ sensitive information and systems. We currently are unaware of any claims or proceedings related to these types of matters that we believe are likely to have a material adverse effect on our financial position.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001262039-25-000039:notes:106]
[same as prior period, unchanged from 0001262039-25-000028:notes:99]

[0001262039-25-000039:notes:107]
We maintain the Amended and Restated Fortinet, Inc. 2009 Equity Incentive Plan (the “Amended Plan”) pursuant to which we have granted RSUs, stock options and PSUs. As of September 30, 2025, there were a total of 48.8 million shares of common stock available for grant under the Amended Plan.

[0001262039-25-000039:notes:108]
[same as prior period, unchanged from 0001262039-25-000028:notes:101]

[0001262039-25-000039:notes:109]
[same as prior period, unchanged from 0001262039-25-000028:notes:102]

[0001262039-25-000039:notes:110]
|  | Restricted Stock Units Outstanding |
|  | Number of Shares |  | Weighted-Average Grant Date Fair Value per Share |
| Balance—December 31, 2024 | 8.4 |  |  | $ | 64.70 |  |
| Granted | 2.9 |  |  | 104.05 |  |
| Forfeited | (0.7) |  |  | 74.80 |  |
| Vested | (2.8) |  |  | 60.50 |  |
| Balance—September 30, 2025 | 7.8 |  |  | $ | 80.32 |  |

[0001262039-25-000039:notes:111]
Stock compensation expense is recognized on a straight-line basis over the vesting period of each RSU. As of September 30, 2025, total compensation expense related to unvested RSUs granted to employees and non-employees under the Amended Plan, but not yet recognized, was $535.6 million, with a weighted-average remaining vesting period of 2.7 years.

[0001262039-25-000039:notes:112]
[same as prior period, unchanged from 0001262039-25-000028:notes:105]

[0001262039-25-000039:notes:113]
[same as prior period, unchanged from 0001262039-25-000028:notes:106]

[0001262039-25-000039:notes:114]
[same as prior period, unchanged from 0001262039-25-000028:notes:107]

[0001262039-25-000039:notes:115]
|  | Performance Stock Units Outstanding |
|  | Number of Shares |  | Weighted-Average Grant Date Fair Value per Share |
| Balance—December 31, 2024 | 0.4 |  |  | $ | 94.93 |  |
| Granted | 0.1 |  |  | 165.91 |  |
| Forfeited | (0.1) |  |  | 113.36 |  |
| Vested | (0.2) |  |  | 91.19 |  |
| Balance—September 30, 2025 | 0.2 |  |  | $ | 117.94 |  |

[0001262039-25-000039:notes:116]
As of September 30, 2025, total compensation expense related to unvested PSUs that were granted to certain of our executives, but not yet recognized, was $25.6 million. This expense is expected to be amortized on a graded vesting method over a weighted-average vesting period of 2.1 years.

[0001262039-25-000039:notes:117]
[same as prior period, unchanged from 0001262039-25-000028:notes:110]

[0001262039-25-000039:notes:118]
[same as prior period, unchanged from 0001262039-25-000028:notes:111]

[0001262039-25-000039:notes:119]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30,2025 |  | September 30,2024 |  | September 30,2025 |  | September 30,2024 |
| Shares withheld for taxes | 0.3 |  |  | 0.3 |  |  | 1.0 |  |  | 1.2 |  |
| Amount withheld for taxes | $ | 26.6 |  |  | $ | 16.5 |  |  | $ | 103.8 |  |  | $ | 79.6 |  |

[0001262039-25-000039:notes:120]
[same as prior period, unchanged from 0001262039-25-000028:notes:113]

[0001262039-25-000039:notes:121]
[same as prior period, unchanged from 0001262039-25-000028:notes:114]

[0001262039-25-000039:notes:122]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30,2025 |  | September 30,2024 |  | September 30,2025 |  | September 30,2024 |
| Expected term in years | 4.5 |  | 4.5 |  | 4.5 |  | 4.5 |
| Volatility | 42.2 | % |  | 41.7 | % |  | 41.7 | % |  | 42.8 | % |
| Risk-free interest rate | 3.8 | % |  | 3.7 | % |  | 4.2 | % |  | 4.3 | % |
| Dividend rate | — | % |  | — | % |  | — | % |  | — | % |

[0001262039-25-000039:notes:123]
[same as prior period, unchanged from 0001262039-25-000028:notes:116]

[0001262039-25-000039:notes:124]
|  | Options Outstanding |
|  | Numberof Shares |  | Weighted-AverageExercisePrice |  | Weighted-AverageRemainingContractualLife (Years) |  | AggregateIntrinsicValue |
| Balance—December 31, 2024 | 8.7 |  |  | $ | 37.81 |  |  | 3.1 |  | $ | 493.8 |  |
| Granted | 0.7 |  |  | 105.38 |  |  |  |  |  |
| Forfeited | (0.1) |  |  | 72.16 |  |  |  |  |  |
| Exercised | (1.8) |  |  | 21.11 |  |  |  |  |  |
| Balance—September 30, 2025 | 7.5 |  |  | $ | 47.80 |  |  |  |  |  |
| Options vested and expected to vest—September 30, 2025 | 7.5 |  |  | $ | 47.80 |  |  | 3.1 |  | $ | 290.0 |  |
| Options exercisable—September 30, 2025 | 5.8 |  |  | $ | 37.84 |  |  | 2.4 |  | $ | 268.3 |  |

[0001262039-25-000039:notes:125]
The aggregate intrinsic value represents the difference between the exercise price of stock options and the quoted market price of our common stock at the date of the balance sheet for all in-the-money stock options. Stock compensation expense is recognized on a straight-line basis over the vesting period of each stock option. As of September 30, 2025, total compensation expense related to unvested stock options granted to employees but not yet recognized was $52.3 million, with a weighted-average remaining vesting period of 2.6 years.

[0001262039-25-000039:notes:126]
[same as prior period, unchanged from 0001262039-25-000028:notes:119]

[0001262039-25-000039:notes:127]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30,2025 |  | September 30,2024 |  | September 30,2025 |  | September 30,2024 |
| Weighted-average fair value per share granted | $ | 31.84 |  |  | $ | 29.86 |  |  | $ | 42.39 |  |  | $ | 27.05 |  |
| Intrinsic value of options exercised | $ | 17.5 |  |  | $ | 42.6 |  |  | $ | 148.7 |  |  | $ | 112.5 |  |
| Fair value of options vested | $ | 5.7 |  |  | $ | 6.4 |  |  | $ | 20.7 |  |  | $ | 25.0 |  |

[0001262039-25-000039:notes:128]
[same as prior period, unchanged from 0001262039-25-000028:notes:121]

[0001262039-25-000039:notes:129]
[same as prior period, unchanged from 0001262039-25-000028:notes:122]

[0001262039-25-000039:notes:130]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30,2025 |  | September 30,2024 |  | September 30,2025 |  | September 30,2024 |
| Cost of product revenue | $ | 0.6 |  |  | $ | 0.5 |  |  | $ | 1.6 |  |  | $ | 1.4 |  |
| Cost of service revenue | 6.9 |  |  | 6.3 |  |  | 20.4 |  |  | 19.0 |  |
| Research and development | 25.4 |  |  | 21.9 |  |  | 73.5 |  |  | 63.0 |  |
| Sales and marketing | 30.0 |  |  | 27.0 |  |  | 86.2 |  |  | 79.6 |  |
| General and administrative | 9.3 |  |  | 10.7 |  |  | 27.3 |  |  | 30.7 |  |
| Total stock-based compensation expense | $ | 72.2 |  |  | $ | 66.4 |  |  | $ | 209.0 |  |  | $ | 193.7 |  |

[0001262039-25-000039:notes:131]
[same as prior period, unchanged from 0001262039-25-000028:notes:124]

[0001262039-25-000039:notes:132]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30,2025 |  | September 30,2024 |  | September 30,2025 |  | September 30,2024 |
| RSUs | $ | 60.8 |  |  | $ | 54.8 |  |  | $ | 177.9 |  |  | $ | 160.8 |  |
| Stock options | 6.7 |  |  | 6.9 |  |  | 20.1 |  |  | 21.3 |  |
| PSUs | 4.7 |  |  | 4.7 |  |  | 11.0 |  |  | 11.6 |  |
| Total stock-based compensation expense | $ | 72.2 |  |  | $ | 66.4 |  |  | $ | 209.0 |  |  | $ | 193.7 |  |

[0001262039-25-000039:notes:133]
[same as prior period, unchanged from 0001262039-25-000028:notes:126]

[0001262039-25-000039:notes:134]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30,2025 |  | September 30,2024 |  | September 30,2025 |  | September 30,2024 |
| Income tax benefit associated with stock-based compensation | $ | 15.9 |  |  | $ | 14.7 |  |  | $ | 45.9 |  |  | $ | 42.9 |  |

[0001262039-25-000039:notes:135]
[same as prior period, unchanged from 0001262039-25-000028:notes:128]

[0001262039-25-000039:notes:136]
In August 2025, our board of directors approved a $1.0 billion increase in the authorized stock repurchase amount under the Repurchase Program and extended the term of the Repurchase Program to February 28, 2027, bringing the aggregate amount authorized for repurchases to $9.25 billion of our outstanding common stock through February 28, 2027. Share repurchases may be made by us from time to time in privately negotiated transactions or in open-market transactions. The Repurchase Program does not require us to purchase a minimum number of shares, and may be suspended, modified or discontinued at any time without prior notice.
During the three months ended September 30, 2025, we repurchased 23.3 million shares of our common stock under the Repurchase Program in open-market transactions, at a weighted-average price of $78.32 per share, for an aggregate purchase price of $1.83 billion, which excludes a $17.7 million accrual related to the 1% excise tax imposed by the Inflation Reduction Act of 2022. During the nine months ended September 30, 2025, we repurchased 27.9 million shares of our common stock under the Repurchase Program in open-market transactions, at a weighted-average price of $79.88 per share, for an aggregate purchase price of $2.23 billion, which excludes a $18.5 million accrual related to the 1% excise tax imposed by the Inflation Reduction Act of 2022. As of September 30, 2025, approximately $795.9 million remained available for future share repurchases under the Repurchase Program.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001262039-25-000039:notes:137]
INCOME TAXES
Our effective tax rate was 20% for the three months ended September 30, 2025, compared to an effective tax rate of 13% for the same period last year. Our effective tax rate was 18% for the nine months ended September 30, 2025, compared to an effective tax rate of 14% for the same period last year. The tax rates for the three months ended September 30, 2025 and 2024 were comprised of U.S. federal and state taxes, withholding taxes and foreign taxes that amounted to $141.0 million and $123.6 million, respectively. The tax rate for the three months ended September 30, 2025 included a tax benefit of $11.1 million from the foreign-derived intangible income (“FDII”) deduction, and excess tax benefits from stock-based compensation expense of $9.2 million. The tax rate for the three months ended September 30, 2024 was impacted by a tax benefit of $33.1 million from the FDII deduction, and excess tax benefits from stock-based compensation expense of $9.3 million.

[0001262039-25-000039:notes:138]
The tax rates for the nine months ended September 30, 2025 and 2024 were composed of U.S. federal and state taxes, withholding taxes and foreign taxes that amounted to $384.2 million and $315.0 million, respectively. The tax rate for the nine months ended September 30, 2025 included a tax provision of $30.6 million related to the derecognition of deferred tax assets from the business combination with Linksys, a tax benefit of $62.0 million from the FDII deduction, and excess tax benefits from stock-based compensation expense of $58.5 million. The tax rate for the nine months ended September 30, 2024 was impacted by a tax benefit of $84.0 million from the FDII deduction, and excess tax benefits from stock-based compensation expense of $33.8 million.

[0001262039-25-000039:notes:139]
On July 4, 2025, H.R. 1, an Act to Provide for Reconciliation Pursuant to Title II of House Concurrent Resolution 14 (the “Act”) commonly referred to as the One Big Beautiful Bill Act, was enacted. The Act makes permanent certain elements of the Tax Cuts and Jobs Act, including immediate expensing of U.S. research and development expenditures, immediate expensing of certain eligible assets, and various modifications to the international tax framework. The income tax effects of the Act have been recognized in our provision for income taxes as of September 30, 2025. As a result of the Act, our cash paid for income taxes in 2025 could reduce by approximately $100 million to $150 million, while our GAAP effective tax rate for 2025 could increase by approximately one percentage point.

[0001262039-25-000039:notes:140]
As of September 30, 2025 and December 31, 2024, unrecognized tax benefits were $86.6 million and $75.9 million, respectively. If recognized, $70.8 million of the unrecognized tax benefits as of September 30, 2025 would favorably affect our effective tax rate. It is our policy to include accrued interest and penalties related to unrecognized tax benefits in income tax expense. As of September 30, 2025 and December 31, 2024, accrued interest and penalties were $11.6 million and $8.8 million, respectively.

[0001262039-25-000039:notes:141]
[same as prior period, unchanged from 0001262039-25-000028:notes:134]

[0001262039-25-000039:notes:142]
On January 4, 2022, the U.S. Treasury published another tranche of final regulations regarding the foreign tax credit. These final regulations impose new requirements that a foreign tax must meet in order to be creditable against U.S. income taxes, and generally apply to tax years beginning on or after December 28, 2021. On July 26, 2022, the U.S. Treasury released corrections to the final regulations. On July 21, 2023, the Internal Revenue Service (“IRS”) released a notice that suspended the application of significant portions of the final regulations regarding the foreign tax credit for tax years 2022 and 2023. The notice released in July 2023 favorably impacted our ability to claim foreign tax credits in the United States for certain taxes imposed by certain foreign jurisdictions. On December 11, 2023, the IRS released a notice that extended the suspension of significant portions of the final regulations beyond December 31, 2023, until further guidance is issued. 
In December 2021, the Organisation for Economic Co-operation and Development (the “OECD”) enacted model rules for a new global minimum tax framework (“BEPS Pillar Two”), and various governments around the world have enacted, or are in the process of enacting, legislation on this. The OECD continues to release additional guidance on these rules. Based on the enacted laws, BEPS Pillar Two has no impact to our effective tax rate or cash flows for the nine months ended September 30, 2025. We will continue to evaluate the impact of these tax law changes on future reporting periods.


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0001262039-25-000039:notes:143]
DEFINED CONTRIBUTION PLANS
Our tax-deferred savings plan under our 401(k) Plan permits participating U.S. employees to contribute a portion of their pre-tax or after-tax earnings. In Canada, we have a Group Registered Retirement Savings Plan Program (the “RRSP”), which permits participants to make pre-tax contributions. Our board of directors approved 50% matching contributions on employee contributions up to 4% of each employee’s eligible earnings. Our matching contributions to our 401(k) Plan and the RRSP for the three months ended September 30, 2025 and 2024 were $5.0 million and $4.6 million, respectively. Our matching contributions to our 401(k) Plan and the RRSP for the nine months ended September 30, 2025 and 2024 were $15.7 million and $15.2 million, respectively.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001262039-25-000039:notes:144]
SEGMENT INFORMATION
Operating segments are defined as components of an enterprise about which separate financial information is available that is evaluated regularly by the chief operating decision maker in deciding how to allocate resources and in assessing performance. Our chief operating decision maker is our chief executive officer. Our chief executive officer reviews financial information presented on a consolidated basis, accompanied by information about revenue by geographic region for purposes of allocating resources and evaluating financial performance. We have one business activity, and there are no segment managers who are held accountable for operations, operating results and plans for levels or components below the consolidated unit level. Accordingly, we have determined that we have one operating segment, and therefore, one reportable segment.

[0001262039-25-000039:notes:145]
[same as prior period, unchanged from 0001262039-25-000028:notes:139]

[0001262039-25-000039:notes:146]
|  | Three Months Ended |  | Nine Months Ended |
| September 30, 2025 |  | September 30, 2024 |  | September 30, 2025 |  | September 30, 2024 |
| Total revenue | $ | 1,724.9 |  |  | $ | 1,508.1 |  |  | $ | 4,894.6 |  |  | $ | 4,295.7 |  |
| Less: |  |  |  |  |  |  |  |
| Cost of product revenue | 180.7 |  |  | 136.1 |  |  | 496.5 |  |  | 474.0 |  |
| Cost of service revenue | 151.0 |  |  | 127.3 |  |  | 443.2 |  |  | 369.1 |  |
| Research and development expense | 202.4 |  |  | 187.3 |  |  | 610.5 |  |  | 525.7 |  |
| Other sales and marketing expense (1) | 469.2 |  |  | 416.3 |  |  | 1,392.6 |  |  | 1,232.1 |  |
| Commission expense | 114.3 |  |  | 99.6 |  |  | 325.6 |  |  | 286.2 |  |
| General and administrative expense | 61.4 |  |  | 71.7 |  |  | 176.1 |  |  | 182.7 |  |
| Other segment items (2) | 48.7 |  |  | 151.3 |  |  | 191.6 |  |  | 190.3 |  |
| Provision for income taxes | 120.7 |  |  | 81.2 |  |  | 294.3 |  |  | 197.2 |  |
| Net income | $ | 473.9 |  |  | $ | 539.9 |  |  | $ | 1,347.4 |  |  | $ | 1,219.0 |  |

[0001262039-25-000039:notes:147]
[same as prior period, unchanged from 0001262039-25-000028:notes:141]

[0001262039-25-000039:notes:148]
[same as prior period, unchanged from 0001262039-25-000028:notes:142]

[0001262039-25-000039:notes:149]
|  | Three Months Ended |  | Nine Months Ended |
| September 30, 2025 |  | September 30, 2024 |  | September 30, 2025 |  | September 30, 2024 |
| Gain on intellectual property matters | $ | 1.4 |  |  | $ | 1.1 |  |  | $ | 9.0 |  |  | $ | 3.4 |  |
| Interest income | 40.7 |  |  | 42.4 |  |  | 130.0 |  |  | 112.9 |  |
| Interest expense | (6.2) |  |  | (5.0) |  |  | (15.7) |  |  | (15.1) |  |
| Other income—net | 13.0 |  |  | 118.1 |  |  | 58.0 |  |  | 113.0 |  |
| Gain (loss) from equity method investments | (0.2) |  |  | (5.3) |  |  | 10.3 |  |  | (23.9) |  |
| Total other segment items | $ | 48.7 |  |  | $ | 151.3 |  |  | $ | 191.6 |  |  | $ | 190.3 |  |

[0001262039-25-000039:notes:150]
[same as prior period, unchanged from 0001262039-25-000028:notes:144]

[0001262039-25-000039:notes:151]
|  | Three Months Ended |  | Nine Months Ended |
| September 30, 2025 |  | September 30, 2024 |  | September 30, 2025 |  | September 30, 2024 |
| Significant non-cash items: |  |  |  |  |  |  |  |
| Stock‐based compensation expense | $ | 71.8 |  |  | $ | 65.9 |  |  | $ | 207.0 |  |  | $ | 192.1 |  |
| Depreciation and amortization expense | 38.4 |  |  | 29.8 |  |  | 112.5 |  |  | 87.6 |  |
| Total assets | $ | 9,361.3 |  |  | $ | 8,852.0 |  |  | $ | 9,361.3 |  |  | $ | 8,852.0 |  |
| Purchases of property and equipment | $ | 87.7 |  |  | $ | 36.3 |  |  | $ | 322.0 |  |  | $ | 281.3 |  |

[0001262039-25-000039:notes:152]
[same as prior period, unchanged from 0001262039-25-000028:notes:146]

[0001262039-25-000039:notes:153]
|  | Three Months Ended |  | Nine Months Ended |
| Revenue | September 30,2025 |  | September 30,2024 |  | September 30,2025 |  | September 30,2024 |
| Americas: |  |  |  |  |  |  |  |
| United States | $ | 486.6 |  |  | $ | 455.1 |  |  | $ | 1,415.0 |  |  | $ | 1,297.9 |  |
| Other Americas | 193.9 |  |  | 168.9 |  |  | 554.1 |  |  | 478.4 |  |
| Total Americas | 680.5 |  |  | 624.0 |  |  | 1,969.1 |  |  | 1,776.3 |  |
| Europe, Middle East and Africa (“EMEA”) | 713.7 |  |  | 599.3 |  |  | 2,009.2 |  |  | 1,703.9 |  |
| Asia Pacific (“APAC”) | 330.7 |  |  | 284.8 |  |  | 916.3 |  |  | 815.5 |  |
| Total revenue | $ | 1,724.9 |  |  | $ | 1,508.1 |  |  | $ | 4,894.6 |  |  | $ | 4,295.7 |  |

[0001262039-25-000039:notes:154]
| Property and Equipment—net | September 30,2025 |  | December 31,2024 |
| Americas: |  |  |  |
| United States | $ | 996.2 |  |  | $ | 993.5 |  |
| Canada | 334.3 |  |  | 216.8 |  |
| Latin America | 5.3 |  |  | 4.4 |  |
| Total Americas | 1,335.8 |  |  | 1,214.7 |  |
| EMEA | 199.7 |  |  | 73.3 |  |
| APAC | 69.7 |  |  | 61.5 |  |
| Total property and equipment—net | $ | 1,605.2 |  |  | $ | 1,349.5 |  |

[0001262039-25-000039:notes:155]
[same as prior period, unchanged from 0001262039-25-000028:notes:149]

[0001262039-25-000039:notes:156]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30,2025 |  | September 30,2024 |  | September 30,2025 |  | September 30,2024 |
| Distributor A | 27 | % |  | 27 | % |  | 27 | % |  | 29 | % |
| Distributor B | 14 | % |  | 15 | % |  | 14 | % |  | 15 | % |
| Distributor C | 12 | % |  | 12 | % |  | 12 | % |  | 13 | % |

[0001262039-25-000039:notes:157]
[same as prior period, unchanged from 0001262039-25-000028:notes:151]

[0001262039-25-000039:notes:158]
|  | September 30,2025 |  | December 31, 2024 |
| Distributor A | 25 | % |  | 31 | % |
| Distributor B | 11 | % |  | 14 | % |
| Distributor C | 12 | % |  | 10 | % |
