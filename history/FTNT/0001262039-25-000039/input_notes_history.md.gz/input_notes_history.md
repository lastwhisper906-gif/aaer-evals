# FTNT note change history — 0001262039-25-000028 → 0001262039-25-000039


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2025-11-07):
[0001262039-25-000039:note_history:1]
COMMITMENTS AND CONTINGENCIES
The following table summarizes our inventory purchase commitments as of September 30, 2025 (in millions):
  (was, 2025-08-08, similarity 0.9569):
[0001262039-25-000028:note_history:1]
COMMITMENTS AND CONTINGENCIES
The following table summarizes our inventory purchase commitments as of June 30, 2025 (in millions):

- changed (2025-11-07):
[0001262039-25-000039:note_history:2]
As of September 30, 2025, we had $732.5 million of non-cancelable inventory purchase commitments with our independent contract manufacturers. We recorded a liability for these purchase commitments for quantities in excess of our future estimated demand forecasts, consistent with the valuation of our excess and obsolete inventory. As of September 30, 2025 and December 31, 2024, the liability for these inventory purchase commitments was $35.2 million and $54.0 million, respectively, and was recorded in accrued liabilities on our condensed consolidated balance sheets. The expense related to such accrued liability for inventory purchase commitments is recorded in cost of product revenue on the condensed consolidated statements of income. The expense related to such accrued liability for inventory purchase commitments was immaterial during the three and nine months ended September 30, 2025, and was a $27.4 million benefit and a $11.2 million cost during the three and nine months ended September 30, 2024, respectively.
  (was, 2025-08-08, similarity 0.8058):
[0001262039-25-000028:note_history:2]
As of June 30, 2025, we had $714.4 million of non-cancelable inventory purchase commitments with our independent contract manufacturers. We recorded a liability for these purchase commitments for quantities in excess of our future estimated demand forecasts, consistent with the valuation of our excess and obsolete inventory. As of June 30, 2025 and December 31, 2024, the liability for these inventory purchase commitments was $41.9 million and $54.0 million, respectively, and was recorded in accrued liabilities on our condensed consolidated balance sheets. The expense related to such accrued liability for inventory purchase commitments is recorded in cost of product revenue on the condensed consolidated statements of income. It was immaterial during the three and six months ended June 30, 2025, and was $7.0 million and $38.6 million during the three and six months ended June 30, 2024, respectively.

- changed (2025-11-07):
[0001262039-25-000039:note_history:3]
Other Contractual Commitments and Open Purchase Orders—In addition to commitments with contract manufacturers, we have open purchase orders and contractual obligations in the ordinary course of business for which we have not received goods or services. A significant portion of our reported purchase commitments consist of non-cancelable commitments. In certain instances, contractual commitments allow us the option to cancel, reschedule and adjust our
  (was, 2025-08-08, similarity 0.8097):
[0001262039-25-000028:note_history:3]
Other Contractual Commitments and Open Purchase Orders—In addition to commitments with contract manufacturers, we have open purchase orders and contractual obligations in the ordinary course of business for which we have not received goods or services. A significant portion of our reported purchase commitments consist of non-cancelable commitments. In certain instances, contractual commitments allow us the option to cancel, reschedule and adjust our requirements based on our business needs prior to firm orders being placed. As of June 30, 2025, we had $102.7 million in other contractual commitments having a remaining term in excess of one year that are non-cancelable.

- added (2025-11-07):
[0001262039-25-000039:note_history:4]
requirements based on our business needs prior to firm orders being placed. As of September 30, 2025, we had $112.7 million in other contractual commitments having a remaining term in excess of one year that are non-cancelable.

- changed (2025-11-07):
[0001262039-25-000039:note_history:5]
As of September 30, 2025, we had $92.9 million in contractual commitments related to payments for operating leases.
  (was, 2025-08-08, similarity 0.9469):
[0001262039-25-000028:note_history:5]
As of June 30, 2025, we had $93.4 million in contractual commitments related to payments for operating leases.

- changed (2025-11-07):
[0001262039-25-000039:note_history:6]
Litigation—We are involved in disputes, litigation, and other legal actions. For lawsuits where we are the defendant, we are in the process of defending these litigation matters, and while there can be no assurances and the outcome of certain of these matters is currently not determinable and not predictable, we currently are unaware of any existing claims or proceedings that we believe are likely to have a material adverse effect on our financial position. There are many uncertainties associated with any litigation and these actions or other third-party claims against us may cause us to incur costly litigation fees, costs and substantial settlement charges, and possibly subject us to damages and other penalties. In addition, the resolution of any intellectual property (“IP”) litigation may require us to make royalty payments, which could adversely affect our gross margins in future periods. If any of those events were to occur, our business, financial condition, results of operations, and cash flows could be adversely affected. Litigation is unpredictable and the actual liability in any such matters may be materially different from our current estimates, which could result in the need to adjust any accrued liability and record additional expenses. We accrue for contingencies when we believe that a loss is probable and that we can reasonably estimate the amount of any such loss. These accruals are generally based on a range of possible outcomes that require significant management judgment. If no amount within a range is a better estimate than any other, we accrue the minimum amount. Litigation loss contingency accruals associated with outstanding cases were not material as of September 30, 2025 and December 31, 2024.
  (was, 2025-08-08, similarity 0.996):
[0001262039-25-000028:note_history:6]
Litigation—We are involved in disputes, litigation, and other legal actions. For lawsuits where we are the defendant, we are in the process of defending these litigation matters, and while there can be no assurances and the outcome of certain of these matters is currently not determinable and not predictable, we currently are unaware of any existing claims or proceedings that we believe are likely to have a material adverse effect on our financial position. There are many uncertainties associated with any litigation and these actions or other third-party claims against us may cause us to incur costly litigation fees, costs and substantial settlement charges, and possibly subject us to damages and other penalties. In addition, the resolution of any intellectual property (“IP”) litigation may require us to make royalty payments, which could adversely affect our gross margins in future periods. If any of those events were to occur, our business, financial condition, results of operations, and cash flows could be adversely affected. Litigation is unpredictable and the actual liability in any such matters may be materially different from our current estimates, which could result in the need to adjust any accrued liability and record additional expenses. We accrue for contingencies when we believe that a loss is probable and that we can reasonably estimate the amount of any such loss. These accruals are generally based on a range of possible outcomes that require significant management judgement. If no amount within a range is a better estimate than any other, we accrue the minimum amount. Litigation loss contingency accruals associated with outstanding cases were not material as of June 30, 2025 and December 31, 2024.

- added (2025-11-07):
[0001262039-25-000039:note_history:7]
On September 22, 2025, a securities class action was filed against us, our chief executive officer, our chief technology officer, our current chief financial officer and our former chief financial officer in the United States District Court, Northern District of California, captioned Oklahoma Firefighters Pension and Retirement System v. Fortinet, Inc., et al., Case No. 5:25-cv-08037. On October 16, 2025, a securities class action was filed against us, our chief executive Officer, our current chief financial officer and our former chief financial officer in the same court, captioned State of Rhode Island Office of the General Treasurer v. Fortinet, Inc., et al., Case No. 3:25-cv-08888. These suits are brought on behalf of an alleged class of stockholders who purchased or acquired shares of our common stock between November 8, 2024 through August 6, 2025. The complaints allege that defendants made false or misleading statements about our business, operations and prospects, including regarding the 2026 firewall refresh cycle, and purport to assert claims under Sections 10(b) and 20(a) of the Exchange Act. The time to respond to the complaints has not yet passed. We believe these cases are without merit and defendants intend to defend the suits vigorously. Based on the preliminary nature of the proceedings in these cases, the outcome of these matters remains uncertain and we cannot estimate the potential impact, if any, on its business or financial statements at this time. Accordingly, no loss accrual was recorded as of September 30, 2025 related to these litigations. On October 8, 2025, Plaintiff Jack Pittrof filed a stockholder derivative complaint against us as a nominal defendant and certain of our current and former directors and officers in the United States District Court for the Northern District of California. The complaint alleges claims based on events similar to those in the securities class action and asserts causes of action against the individual defendants for breach of fiduciary duty, aiding and abetting breach of fiduciary duty, unjust enrichment, waste of corporate assets, and for making false and misleading statements about our business, operations, and prospects in violation of Section 10(b) of the Exchange Act. The time to respond to the complaint has not yet passed.

- changed (2025-11-07):
[0001262039-25-000039:note_history:8]
On March 21, 2019, we were sued by Alorica Inc. (“Alorica”) in Santa Clara County Superior Court in California. Alorica alleged breach of warranty and misrepresentation claims, which we denied. After trial, a jury returned a verdict fully in favor of us and against Alorica on October 4, 2024. Alorica has filed a notice of appeal. We believe that the ultimate outcome of this matter will not materially impact our financial position, results of operations or cash flows. However, any further legal proceedings, including Alorica’s appeal, would be subject to inherent uncertainties, and a future unfavorable ruling could occur. No loss accrual had been recorded as of September 30, 2025 or December 31, 2024 related to this litigation.
  (was, 2025-08-08, similarity 0.9909):
[0001262039-25-000028:note_history:8]
On March 21, 2019, we were sued by Alorica Inc. (“Alorica”) in Santa Clara County Superior Court in California. Alorica alleged breach of warranty and misrepresentation claims, which we denied. After trial, a jury returned a verdict fully in favor of us and against Alorica on October 4, 2024. Alorica has filed a notice of appeal. We believe that the ultimate outcome of this matter will not materially impact our financial position, results of operations or cash flows. However, any further legal proceedings, including Alorica’s appeal, would be subject to inherent uncertainties, and a future unfavorable ruling could occur. No loss accrual had been recorded as of June 30, 2025 or December 31, 2024 related to this litigation.

- changed (2025-11-07):
[0001262039-25-000039:note_history:9]
Indemnification and Other Matters—We enter into indemnification provisions in the ordinary course of business with other companies such as partners, customers, and vendors, where we agree to indemnify, hold harmless, and reimburse the indemnified party for certain losses suffered or incurred by the indemnified party as a result of our activities, including defending against third-party claims asserting various allegations such as product defects, breach of representations or covenants, and infringement of certain IP rights, which may include patents, copyrights, trademarks or trade secrets, and to pay judgments entered on such claims. In some contracts, our exposure under these indemnification provisions is limited by the terms of the contracts to certain defined limits, such as the total amount paid by our customer under the agreement. However, certain agreements include covenants, penalties and indemnification provisions including and beyond indemnification for third-party claims of IP infringement that could potentially expose us to losses in excess of the amount received under the agreement, and in some instances to potential liability that is not contractually limited. Although from time to time there are
  (was, 2025-08-08, similarity 0.9314):
[0001262039-25-000028:note_history:9]
Indemnification and Other Matters—We enter into indemnification provisions in the ordinary course of business with other companies such as partners, customers, and vendors, where we agree to indemnify, hold harmless, and reimburse the indemnified party for certain losses suffered or incurred by the indemnified party as a result of our activities, including defending against third-party claims asserting various allegations such as product defects, breach of representations or covenants, and infringement of certain IP rights, which may include patents, copyrights, trademarks or trade secrets, and to pay judgments entered on such claims. In some contracts, our exposure under these indemnification provisions is limited by the terms of the contracts to certain defined limits, such as the total amount paid by our customer under the agreement. However, certain agreements include covenants, penalties and indemnification provisions including and beyond indemnification for third-party claims of IP infringement that could potentially expose us to losses in excess of the amount received under the agreement, and in some instances to potential liability that is not contractually limited. Although from time to time there are indemnification claims asserted against us and currently there are pending indemnification claims, to date there have been no material awards under such indemnification provisions.

- added (2025-11-07):
[0001262039-25-000039:note_history:10]
indemnification claims asserted against us and currently there are pending indemnification claims, to date there have been no material awards under such indemnification provisions.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2025-11-07):
[0001262039-25-000039:note_history:11]
SUMMARY OF SIGNIFICANT ACCOUNTING POLICIES
Basis of Presentation and Preparation—The unaudited condensed consolidated financial statements of Fortinet, Inc. and its subsidiaries (collectively, “we,” “us” or “our”) have been prepared in accordance with generally accepted accounting principles in the United States (“GAAP”) for interim financial information, as well as the instructions to Form 10-Q pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (the “SEC”). Accordingly, they do not include all of the information and footnotes required by GAAP for complete financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the year ended December 31, 2024, contained in our Annual Report on Form 10-K filed with the SEC on February 21, 2025. In the opinion of management, all adjustments, which include normal recurring adjustments, considered necessary for a fair presentation, have been included. The results of operations for the three and nine months ended September 30, 2025 are not necessarily indicative of the results to be expected for the full year or for any future periods. The condensed consolidated balance sheet as of December 31, 2024 is derived from the audited consolidated financial statements for the year ended December 31, 2024.
  (was, 2025-08-08, similarity 0.7927):
[0001262039-25-000028:note_history:11]
SUMMARY OF SIGNIFICANT ACCOUNTING POLICIES
Basis of Presentation and Preparation—The unaudited condensed consolidated financial statements of Fortinet, Inc. and its subsidiaries (collectively, “we,” “us” or “our”) have been prepared in accordance with generally accepted accounting principles in the United States (“GAAP”) for interim financial information, as well as the instructions to Form 10-Q pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (the “SEC”). Accordingly, they do not include all of the information and footnotes required by GAAP for complete financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the year ended December 31, 2024, contained in our Annual Report on Form 10-K filed with the SEC on February 21, 2025. In the opinion of management, all adjustments, which include normal recurring adjustments, considered necessary for a fair presentation, have been included. The results of operations for the three and six months ended June 30, 2025 are not necessarily indicative of the results to be expected for the full year or for any future periods. The condensed consolidated balance sheet as of December 31, 2024 is derived from the audited consolidated financial statements for the year ended December 31, 2024.

- changed (2025-11-07):
[0001262039-25-000039:note_history:12]
Amounts previously reported as gain on bargain purchase are included in other income—net in prior periods to conform with current period presentation in our condensed consolidated statements of income. Amounts previously reported as loss from equity method investments and gain on bargain purchase are included in other in prior periods to conform with current period presentation in section of net cash provided by operating activities in our condensed consolidated statements of cash flows.
  (was, 2025-08-08, similarity 0.9899):
[0001262039-25-000028:note_history:12]
Amounts previously reported as gain on bargain purchase are included in other income (expense)—net in prior periods to conform with current period presentation in our condensed consolidated statements of income. Amounts previously reported as loss from equity method investments and gain on bargain purchase are included in other in prior periods to conform with current period presentation in section of net cash provided by operating activities in our condensed consolidated statements of cash flows.

- changed (2025-11-07):
[0001262039-25-000039:note_history:13]
There have been no material changes to our significant accounting policies as of and for the nine months ended September 30, 2025, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended December 31, 2024 filed with the SEC.
  (was, 2025-08-08, similarity 0.9124):
[0001262039-25-000028:note_history:13]
There have been no material changes to our significant accounting policies as of and for the six months ended June 30, 2025, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended December 31, 2024 filed with the SEC.

- changed (2025-11-07):
[0001262039-25-000039:note_history:14]
In December 2023, the Financial Accounting Standards Board (the “FASB”) issued Accounting Standards Update (“ASU”) 2023-09, Income Taxes (Topic 740): Improvements to Income Tax Disclosures, which includes amendments that further enhance income tax disclosures, primarily through standardization and disaggregation of rate reconciliation categories and income taxes paid by jurisdiction. The amendments are effective for our annual period beginning fiscal year 2025, with early adoption permitted, and should be applied prospectively. We are currently evaluating the ASU to determine its impact on our disclosures.
  (was, 2025-08-08, similarity 0.908):
[0001262039-25-000028:note_history:14]
In December 2023, the FASB issued ASU 2023-09, Income Taxes (Topic 740): Improvements to Income Tax Disclosures, which includes amendments that further enhance income tax disclosures, primarily through standardization and disaggregation of rate reconciliation categories and income taxes paid by jurisdiction. The amendments are effective for our annual period beginning fiscal year 2025, with early adoption permitted, and should be applied prospectively. We are currently evaluating the ASU to determine its impact on our disclosures.

- added (2025-11-07):
[0001262039-25-000039:note_history:15]
Credit Losses

- added (2025-11-07):
[0001262039-25-000039:note_history:16]
In July 2025, the FASB issued ASU 2025-05—Financial Instruments—Credit Losses (Topic 326): Measurement of Credit Losses for Accounts Receivable and Contract Assets (“ASU 2025-05”), which provides a practical expedient for estimating expected credit losses for current accounts receivable and current contract assets that arise from transactions accounted for under Revenue from Contracts with Customers (Topic 606). The amendments are effective for our annual reporting period beginning with fiscal year 2026 and interim reporting periods within those annual reporting periods on a prospective basis, with early adoption permitted. We are currently evaluating ASU 2025-05 to determine its impact on our consolidated financial statements and related disclosures.

- added (2025-11-07):
[0001262039-25-000039:note_history:17]
Internal-Use Software

- added (2025-11-07):
[0001262039-25-000039:note_history:18]
In September 2025, the FASB issued ASU 2025-06, Intangibles—Goodwill and Other—Internal-Use Software (Subtopic 350-40): Targeted Improvements to the Accounting for Internal-Use Software (“ASU 2025-06”), which amends the cost capitalization criteria for internal-use software development costs by removing all references to prescriptive and sequential software project development stages and providing new guidance on how to evaluate whether the probable-to-complete recognition threshold has been met. The amendments are effective for our annual period beginning fiscal year 2028 and interim reporting periods within those annual reporting periods and can be applied prospectively, retrospectively, or via a modified prospective transition method, with early adoption permitted. We are currently assessing adoption timing and the method of adoption.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-11-07):
[0001262039-25-000039:note_history:19]
On March 5, 2021, we issued $1.0 billion aggregate principal amount of senior notes (collectively, the “Senior Notes”), consisting of $500.0 million aggregate principal amount of 1.0% notes due March 15, 2026 (the “2026 Senior Notes”) and $500.0 million aggregate principal amount of 2.2% notes due March 15, 2031 (the “2031 Senior Notes”), in an underwritten registered public offering. The Senior Notes are senior unsecured obligations and rank equally with each other in right of payment and with our other outstanding obligations. We may redeem the Senior Notes at any time in whole or in part for cash, at specified redemption prices that include accrued and unpaid interest, if any, and a make-whole premium. However, no make-whole premium will be paid for redemptions of the 2026 Senior Notes on or after February 15, 2026, or the 2031 Senior Notes on or after December 15, 2030. Interest on the Senior Notes is payable on March 15 and September 15 of each year, beginning on September 15, 2021. The 2026 Senior Notes were recorded as current portion of long-term debt and the 2031 Senior Notes were recorded as long-term debt as of September 30, 2025 and both of the Senior Notes were recorded as long-term debt as of December 31, 2024, net of discount and issuance costs, which are amortized to interest expense over the respective contractual terms of these notes using the effective interest method.
  (was, 2025-08-08, similarity 0.9951):
[0001262039-25-000028:note_history:19]
On March 5, 2021, we issued $1.0 billion aggregate principal amount of senior notes (collectively, the “Senior Notes”), consisting of $500.0 million aggregate principal amount of 1.0% notes due March 15, 2026 (the “2026 Senior Notes”) and $500.0 million aggregate principal amount of 2.2% notes due March 15, 2031 (the “2031 Senior Notes”), in an underwritten registered public offering. The Senior Notes are senior unsecured obligations and rank equally with each other in right of payment and with our other outstanding obligations. We may redeem the Senior Notes at any time in whole or in part for cash, at specified redemption prices that include accrued and unpaid interest, if any, and a make-whole premium. However, no make-whole premium will be paid for redemptions of the 2026 Senior Notes on or after February 15, 2026, or the 2031 Senior Notes on or after December 15, 2030. Interest on the Senior Notes is payable on March 15 and September 15 of each year, beginning on September 15, 2021. The 2026 Senior Notes were recorded as current portion of long-term debt and the 2031 Senior Notes were recorded as long-term debt as of June 30, 2025 and both of the Senior Notes were recorded as long-term debt as of December 31, 2024, net of discount and issuance costs, which are amortized to interest expense over the respective contractual terms of these notes using the effective interest method.

- changed (2025-11-07):
[0001262039-25-000039:note_history:20]
|  | Maturity |  | Coupon Rate |  | Effective Interest Rate |  | September 30,2025 |  | December 31,2024 |
| Debt |  |  |  |  |  |  |  |  |  |
| 2026 Senior Notes | March 2026 |  | 1.0% |  | 1.3% |  | $ | 500.0 |  |  | $ | 500.0 |  |
| 2031 Senior Notes | March 2031 |  | 2.2% |  | 2.3% |  | 500.0 |  |  | 500.0 |  |
| Total debt |  |  |  |  |  |  | 1,000.0 |  |  | 1,000.0 |  |
| Less: Unamortized discount and debt issuance costs |  |  |  |  |  |  | 4.1 |  |  | 5.7 |  |
| Less: Current portion of long-term debt |  |  |  |  |  |  | $ | 499.4 |  |  | $ | — |  |
| Total long-term debt |  |  |  |  |  |  | $ | 496.5 |  |  | $ | 994.3 |  |
  (was, 2025-08-08, similarity 0.987):
[0001262039-25-000028:note_history:20]
|  | Maturity |  | Coupon Rate |  | Effective Interest Rate |  | June 30,2025 |  | December 31,2024 |
| Debt |  |  |  |  |  |  |  |  |  |
| 2026 Senior Notes | March 2026 |  | 1.0% |  | 1.3% |  | $ | 500.0 |  |  | $ | 500.0 |  |
| 2031 Senior Notes | March 2031 |  | 2.2% |  | 2.3% |  | 500.0 |  |  | 500.0 |  |
| Total debt |  |  |  |  |  |  | 1,000.0 |  |  | 1,000.0 |  |
| Less: Unamortized discount and debt issuance costs |  |  |  |  |  |  | 4.7 |  |  | 5.7 |  |
| Less: Current portion of long-term debt |  |  |  |  |  |  | $ | 499.0 |  |  | $ | — |  |
| Total long-term debt |  |  |  |  |  |  | $ | 496.3 |  |  | $ | 994.3 |  |

- changed (2025-11-07):
[0001262039-25-000039:note_history:21]
As of September 30, 2025 and December 31, 2024, we accrued interest payable of $0.7 million and $4.7 million, respectively, and there are no financial covenants with which we must comply. During the three months ended September 30, 2025 and 2024, we recorded $4.5 million of total interest expense in relation to these Senior Notes in each period. During the nine months ended September 30, 2025 and 2024, we recorded $13.5 million of total interest expense in relation to these Senior Notes in each period. No interest costs were capitalized for the nine months ended September 30, 2025 and 2024, as the costs that qualified for capitalization were not material.
  (was, 2025-08-08, similarity 0.8112):
[0001262039-25-000028:note_history:21]
As of June 30, 2025 and December 31, 2024, we accrued interest payable of $4.7 million, and there are no financial covenants with which we must comply. During the three months ended June 30, 2025 and 2024, we recorded $4.5 million of total interest expense in relation to these Senior Notes in each period. During the six months ended June 30, 2025 and 2024, we recorded $9.0 million of total interest expense in relation to these Senior Notes in each period. No interest costs were capitalized for the six months ended June 30, 2025 and 2024, as the costs that qualified for capitalization were not material.

- added (2025-11-07):
[0001262039-25-000039:note_history:22]
The total estimated fair value of the outstanding Senior Notes was approximately $939.4 million, including accrued and unpaid interest, as of September 30, 2025. The fair value was determined based on observable market prices of identical instruments in less active markets. The estimated fair values are based on Level 2 inputs.

- removed (2025-11-07):
[0001262039-25-000028:note_history:23]
The total estimated fair value of the outstanding Senior Notes was approximately $933.1 million, including accrued and unpaid interest, as of June 30, 2025. The fair value was determined based on observable market prices of identical instruments in less active markets. The estimated fair values are based on Level 2 inputs.


## us-gaap:DebtSecuritiesAvailableForSaleUnrealizedLossPositionFairValueTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-11-07):
[0001262039-25-000039:note_history:24]
|  | September 30, 2025 |
|  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
|  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |
| U.S. government and agency securities | $ | 560.5 |  |  | $ | (0.1) |  |  | $ | — |  |  | $ | — |  |  | $ | 560.5 |  |  | $ | (0.1) |  |
| Commercial paper | 370.5 |  |  | — |  |  | — |  |  | — |  |  | 370.5 |  |  | — |  |
| Corporate debt securities | 285.4 |  |  | (0.1) |  |  | — |  |  | — |  |  | 285.4 |  |  | (0.1) |  |
| Certificates of deposit and term deposits | 102.3 |  |  | — |  |  | — |  |  | — |  |  | 102.3 |  |  | — |  |
| Total available-for-sale investments | $ | 1,318.7 |  |  | $ | (0.2) |  |  | $ | — |  |  | $ | — |  |  | $ | 1,318.7 |  |  | $ | (0.2) |  |
  (was, 2025-08-08, similarity 0.9366):
[0001262039-25-000028:note_history:24]
|  | June 30, 2025 |
|  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
|  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |
| U.S. government and agency securities | $ | 393.7 |  |  | $ | (0.1) |  |  | $ | — |  |  | $ | — |  |  | $ | 393.7 |  |  | $ | (0.1) |  |
| Commercial paper | 355.1 |  |  | (0.1) |  |  | — |  |  | — |  |  | 355.1 |  |  | (0.1) |  |
| Corporate debt securities | 119.1 |  |  | (0.1) |  |  | — |  |  | — |  |  | 119.1 |  |  | (0.1) |  |
| Certificates of deposit and term deposits | 19.3 |  |  | — |  |  | — |  |  | — |  |  | 19.3 |  |  | — |  |
| Total available-for-sale investments | $ | 887.2 |  |  | $ | (0.3) |  |  | $ | — |  |  | $ | — |  |  | $ | 887.2 |  |  | $ | (0.3) |  |


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-11-07):
[0001262039-25-000039:note_history:25]
|  | Maturity |  | Coupon Rate |  | Effective Interest Rate |  | September 30,2025 |  | December 31,2024 |
| Debt |  |  |  |  |  |  |  |  |  |
| 2026 Senior Notes | March 2026 |  | 1.0% |  | 1.3% |  | $ | 500.0 |  |  | $ | 500.0 |  |
| 2031 Senior Notes | March 2031 |  | 2.2% |  | 2.3% |  | 500.0 |  |  | 500.0 |  |
| Total debt |  |  |  |  |  |  | 1,000.0 |  |  | 1,000.0 |  |
| Less: Unamortized discount and debt issuance costs |  |  |  |  |  |  | 4.1 |  |  | 5.7 |  |
| Less: Current portion of long-term debt |  |  |  |  |  |  | $ | 499.4 |  |  | $ | — |  |
| Total long-term debt |  |  |  |  |  |  | $ | 496.5 |  |  | $ | 994.3 |  |
  (was, 2025-08-08, similarity 0.987):
[0001262039-25-000028:note_history:25]
|  | Maturity |  | Coupon Rate |  | Effective Interest Rate |  | June 30,2025 |  | December 31,2024 |
| Debt |  |  |  |  |  |  |  |  |  |
| 2026 Senior Notes | March 2026 |  | 1.0% |  | 1.3% |  | $ | 500.0 |  |  | $ | 500.0 |  |
| 2031 Senior Notes | March 2031 |  | 2.2% |  | 2.3% |  | 500.0 |  |  | 500.0 |  |
| Total debt |  |  |  |  |  |  | 1,000.0 |  |  | 1,000.0 |  |
| Less: Unamortized discount and debt issuance costs |  |  |  |  |  |  | 4.7 |  |  | 5.7 |  |
| Less: Current portion of long-term debt |  |  |  |  |  |  | $ | 499.0 |  |  | $ | — |  |
| Total long-term debt |  |  |  |  |  |  | $ | 496.3 |  |  | $ | 994.3 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2025-11-07):
[0001262039-25-000039:note_history:26]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30,2025 |  | September 30,2024 |  | September 30,2025 |  | September 30,2024 |
| Product | $ | 559.3 |  |  | $ | 473.9 |  |  | $ | 1,527.3 |  |  | $ | 1,334.7 |  |
| Service: |  |  |  |  |  |  |  |
| Security subscription | 672.0 |  |  | 595.8 |  |  | 1,939.5 |  |  | 1,691.4 |  |
| Technical support and other | 493.6 |  |  | 438.4 |  |  | 1,427.8 |  |  | 1,269.6 |  |
| Total service revenue | 1,165.6 |  |  | 1,034.2 |  |  | 3,367.3 |  |  | 2,961.0 |  |
| Total revenue | $ | 1,724.9 |  |  | $ | 1,508.1 |  |  | $ | 4,894.6 |  |  | $ | 4,295.7 |  |
  (was, 2025-08-08, similarity 0.881):
[0001262039-25-000028:note_history:26]
|  | Three Months Ended |  | Six Months Ended |
|  | June 30,2025 |  | June 30,2024 |  | June 30,2025 |  | June 30,2024 |
| Product | $ | 508.9 |  |  | $ | 451.9 |  |  | $ | 968.0 |  |  | $ | 860.8 |  |
| Service: |  |  |  |  |  |  |  |
| Security subscription | 644.4 |  |  | 558.7 |  |  | 1,267.5 |  |  | 1,095.6 |  |
| Technical support and other | 476.7 |  |  | 423.7 |  |  | 934.2 |  |  | 831.2 |  |
| Total service revenue | 1,121.1 |  |  | 982.4 |  |  | 2,201.7 |  |  | 1,926.8 |  |
| Total revenue | $ | 1,630.0 |  |  | $ | 1,434.3 |  |  | $ | 3,169.7 |  |  | $ | 2,787.6 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2025-11-07):
[0001262039-25-000039:note_history:27]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30,2025 |  | September 30,2024 |  | September 30,2025 |  | September 30,2024 |
| Product | $ | 559.3 |  |  | $ | 473.9 |  |  | $ | 1,527.3 |  |  | $ | 1,334.7 |  |
| Service: |  |  |  |  |  |  |  |
| Security subscription | 672.0 |  |  | 595.8 |  |  | 1,939.5 |  |  | 1,691.4 |  |
| Technical support and other | 493.6 |  |  | 438.4 |  |  | 1,427.8 |  |  | 1,269.6 |  |
| Total service revenue | 1,165.6 |  |  | 1,034.2 |  |  | 3,367.3 |  |  | 2,961.0 |  |
| Total revenue | $ | 1,724.9 |  |  | $ | 1,508.1 |  |  | $ | 4,894.6 |  |  | $ | 4,295.7 |  |
  (was, 2025-08-08, similarity 0.881):
[0001262039-25-000028:note_history:27]
|  | Three Months Ended |  | Six Months Ended |
|  | June 30,2025 |  | June 30,2024 |  | June 30,2025 |  | June 30,2024 |
| Product | $ | 508.9 |  |  | $ | 451.9 |  |  | $ | 968.0 |  |  | $ | 860.8 |  |
| Service: |  |  |  |  |  |  |  |
| Security subscription | 644.4 |  |  | 558.7 |  |  | 1,267.5 |  |  | 1,095.6 |  |
| Technical support and other | 476.7 |  |  | 423.7 |  |  | 934.2 |  |  | 831.2 |  |
| Total service revenue | 1,121.1 |  |  | 982.4 |  |  | 2,201.7 |  |  | 1,926.8 |  |
| Total revenue | $ | 1,630.0 |  |  | $ | 1,434.3 |  |  | $ | 3,169.7 |  |  | $ | 2,787.6 |  |

- changed (2025-11-07):
[0001262039-25-000039:note_history:28]
During the three and nine months ended September 30, 2025, we recognized $759.2 million and $2.61 billion in revenue that was included in the deferred revenue balance as of December 31, 2024, respectively. During the three and nine months ended September 30, 2024, we recognized $660.3 million and $2.28 billion in revenue that was included in the deferred revenue balance as of December 31, 2023, respectively.
  (was, 2025-08-08, similarity 0.8692):
[0001262039-25-000028:note_history:28]
During the three and six months ended June 30, 2025, we recognized $876.8 million and $1.85 billion in revenue that was included in the deferred revenue balance as of December 31, 2024, respectively. During the three and six months ended June 30, 2024, we recognized $764.3 million and $1.62 billion in revenue that was included in the deferred revenue balance as of December 31, 2023, respectively.

- changed (2025-11-07):
[0001262039-25-000039:note_history:29]
As of September 30, 2025, the aggregate amount of the transaction price allocated to remaining performance obligations was $6.72 billion, which was substantially comprised of deferred security subscription and technical support services revenue as well as unbilled contract revenue from non-cancellable contracts that will be recognized in future periods. We expect to recognize approximately $3.49 billion as revenue over the next 12 months, $2.62 billion in years two and three, and the remainder thereafter.
  (was, 2025-08-08, similarity 0.9868):
[0001262039-25-000028:note_history:29]
As of June 30, 2025, the aggregate amount of the transaction price allocated to remaining performance obligations was $6.64 billion, which was substantially comprised of deferred security subscription and technical support services revenue as well as unbilled contract revenue from non-cancellable contracts that will be recognized in future periods. We expect to recognize approximately $3.45 billion as revenue over the next 12 months, $2.61 billion in years two and three, and the remainder thereafter.

- added (2025-11-07):
[0001262039-25-000039:note_history:30]
Amortization of deferred contract costs, primarily consisting of sales commissions earned by our sales force, was $86.0 million and $73.6 million during the three months ended September 30, 2025 and 2024, respectively. Amortization of

- added (2025-11-07):
[0001262039-25-000039:note_history:31]
deferred contract costs was $246.0 million and $218.3 million during the nine months ended September 30, 2025 and 2024, respectively.

- removed (2025-11-07):
[0001262039-25-000028:note_history:32]
Amortization of deferred contract costs during the three months ended June 30, 2025 and 2024 was $82.0 million and $72.7 million, respectively. Amortization of deferred contract costs during the six months ended June 30, 2025 and 2024 was $160.0 million and $144.7 million, respectively.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_current_note, score: 0.0

- removed (2025-11-07):
[0001262039-25-000028:note_history:33]
SUBSEQUENT EVENTS
One Big Beautiful Bill Act

- removed (2025-11-07):
[0001262039-25-000028:note_history:34]
On July 4, 2025, H.R. 1, An Act to Provide for Reconciliation Pursuant to Title II of House Concurrent Resolution 14 (the “Act”), commonly referred to as the One Big Beautiful Bill Act, was enacted. The Act makes permanent certain elements of the Tax Cuts and Jobs Act, including immediate expensing of U.S. research and development expenditures, immediate expensing of certain eligible assets, and various modifications to the international tax framework. We are evaluating the impact of the Act on our consolidated financial statements, but our preliminary analysis indicates that our cash tax payments for 2025 could be reduced by approximately $100 million to $150 million and our GAAP effective tax rate for 2025 could increase by approximately 1 point as a result of the provisions of the Act.

- removed (2025-11-07):
[0001262039-25-000028:note_history:35]
Share Repurchase Program

- removed (2025-11-07):
[0001262039-25-000028:note_history:36]
Subsequent to June 30, 2025 through the filing of this Quarterly Report on Form 10-Q, we repurchased 1.0 million shares of our common stock at an average price of $72.29 per share, for an aggregate purchase price of $71.2 million, under the Repurchase Program. As of the filing of this Quarterly Report on Form 10-Q, approximately $1.56 billion remained available for future share repurchases through February 28, 2026 under the Repurchase Program.
