# FTNT 8-K — 0001262039-25-000036 filed 2025-11-05

## item codes, every 8-K on or before 2025-11-07

- 2025-11-05 0001262039-25-000036 — 2.02, 9.01
- 2025-08-22 0001262039-25-000033 — 8.01
- 2025-08-06 0001262039-25-000025 — 2.02, 9.01
- 2025-06-18 0001262039-25-000022 — 5.07
- 2025-05-15 0001262039-25-000020 — 5.02 — amendment, the index does not say of what
- 2025-05-07 0001262039-25-000014 — 2.02, 9.01
- 2025-02-06 0001262039-25-000007 — 2.02, 5.02, 9.01
- 2025-01-22 0001262039-25-000003 — 5.02 — amendment, the index does not say of what
- 2024-11-12 0001262039-24-000045 — 5.02, 9.01
- 2024-11-07 0001262039-24-000040 — 2.02, 9.01
- 2024-08-07 0001262039-24-000034 — 2.02, 9.01 — amendment of 0001262039-24-000032
- 2024-08-06 0001262039-24-000032 — 2.02, 9.01
- 2024-07-24 0001262039-24-000028 — 5.02 — amendment, the index does not say of what
- 2024-06-20 0001262039-24-000025 — 5.07
- 2024-05-02 0001262039-24-000017 — 2.02, 9.01
- 2024-02-23 0001262039-24-000011 — 5.02, 9.01
- 2024-02-06 0001262039-24-000006 — 2.02, 9.01
- 2024-01-18 0001262039-24-000003 — 5.02
- 2023-12-01 0001262039-23-000041 — 5.02
- 2023-11-02 0001262039-23-000035 — 2.02, 9.01
- 2023-08-03 0001262039-23-000027 — 2.02, 9.01
- 2023-06-23 0001262039-23-000024 — 5.03, 5.07, 9.01
- 2023-05-04 0001262039-23-000013 — 2.02, 9.01
- 2023-02-08 0001262039-23-000006 — 5.03, 9.01
- 2023-02-07 0001262039-23-000003 — 2.02, 9.01
- 2022-11-02 0001262039-22-000035 — 2.02, 9.01
- 2022-08-03 0001262039-22-000026 — 2.02, 9.01
- 2022-06-22 0001262039-22-000023 — 5.03, 9.01
- 2022-06-21 0001262039-22-000021 — 5.07
- 2022-05-04 0001262039-22-000015 — 2.02, 9.01
- 2022-05-02 0001262039-22-000012 — 5.02
- 2022-04-22 0001262039-22-000010 — 8.01
- 2022-02-03 0001262039-22-000005 — 2.02, 9.01
- 2022-01-26 0001262039-22-000002 — 5.02, 9.01 — amendment, the index does not say of what
- 2021-11-04 0001262039-21-000027 — 2.02, 9.01
- 2021-10-06 0001262039-21-000024 — 5.02, 9.01
- 2021-07-29 0001262039-21-000019 — 2.02, 9.01
- 2021-06-23 0001262039-21-000016 — 5.07
- 2021-04-30 0001104659-21-059008 — 5.03 — amendment, the index does not say of what
- 2021-04-29 0001262039-21-000011 — 2.02, 9.01
- 2021-04-28 0001104659-21-056360 — 5.02, 5.03, 9.01
- 2021-03-05 0001193125-21-071498 — 1.01, 9.01
- 2021-02-25 0001193125-21-057281 — 1.01, 9.01
- 2021-02-04 0001262039-21-000005 — 2.02, 9.01
- 2020-12-08 0001262039-20-000070 — 8.01
- 2020-10-29 0001262039-20-000063 — 2.02, 9.01
- 2020-10-20 0001262039-20-000060 — 5.02 — amendment, the index does not say of what
- 2020-08-26 0001262039-20-000056 — 5.02, 9.01
- 2020-08-06 0001262039-20-000051 — 2.02, 9.01
- 2020-07-21 0001262039-20-000044 — 5.03, 8.01, 9.01
- 2020-06-24 0001262039-20-000038 — 5.07
- 2020-05-06 0001262039-20-000029 — 2.02, 9.01
- 2020-04-23 0001262039-20-000025 — 5.03, 9.01
- 2020-04-23 0001262039-20-000024 — 5.02 — amendment of 0001262039-20-000025
- 2020-02-28 0001262039-20-000015 — 5.02, 9.01
- 2020-02-06 0001262039-20-000004 — 2.02, 9.01
- 2019-12-12 0001262039-19-000038 — 8.01
- 2019-10-31 0001262039-19-000032 — 2.02, 9.01
- 2019-10-28 0001262039-19-000027 — 8.01
- 2019-10-23 0001262039-19-000025 — 5.02, 9.01
- 2019-08-01 0001262039-19-000021 — 2.02, 9.01
- 2019-06-26 0001262039-19-000018 — 5.07
- 2019-05-02 0001262039-19-000010 — 2.02, 9.01
- 2019-02-06 0001262039-19-000002 — 2.02, 9.01
- 2018-11-01 0001262039-18-000037 — 2.02, 9.01
- 2018-10-23 0001262039-18-000035 — 8.01
- 2018-08-01 0001262039-18-000025 — 2.02, 9.01
- 2018-06-28 0001262039-18-000023 — 5.03, 5.07, 9.01
- 2018-06-04 0001262039-18-000021 — 8.01
- 2018-05-03 0001262039-18-000017 — 2.02, 5.02, 9.01
- 2018-02-05 0001262039-18-000004 — 2.02, 5.02, 9.01
- 2017-10-26 0001262039-17-000031 — 2.02, 9.01
- 2017-10-19 0001262039-17-000029 — 5.02 — amendment, the index does not say of what
- 2017-07-26 0001262039-17-000025 — 2.02, 9.01
- 2017-06-27 0001262039-17-000023 — 5.07
- 2017-05-31 0001262039-17-000021 — 5.02 — amendment of 0001262039-17-000019
- 2017-05-30 0001262039-17-000019 — 5.02, 9.01
- 2017-04-27 0001262039-17-000013 — 2.02, 9.01
- 2017-02-02 0001262039-17-000003 — 2.02, 9.01
- 2016-10-27 0001262039-16-000085 — 2.02, 9.01
- 2016-10-11 0001262039-16-000082 — 2.02, 9.01
- 2016-07-28 0001262039-16-000076 — 2.02, 9.01
- 2016-07-22 0001262039-16-000073 — 8.01, 9.01
- 2016-06-20 0001262039-16-000068 — 5.07
- 2016-06-07 0001193125-16-614788 — 8.01
- 2016-04-26 0001262039-16-000061 — 2.02, 9.01
- 2016-01-28 0001262039-16-000051 — 2.02, 9.01
- 2015-10-27 0001262039-15-000045 — 2.02
- 2015-10-22 0001262039-15-000042 — 5.02 — amendment, the index does not say of what
- 2015-10-22 0001262039-15-000041 — 5.02 — amendment, the index does not say of what
- 2015-10-22 0001262039-15-000039 — 2.02, 9.01
- 2015-09-28 0001262039-15-000034 — 5.02, 9.01
- 2015-09-22 0001262039-15-000031 — 9.01 — amendment of 0001193125-15-248065
- 2015-08-28 0001262039-15-000027 — 3.01, 5.02
- 2015-07-23 0001262039-15-000021 — 5.02
- 2015-07-22 0001262039-15-000019 — 2.02, 9.01
- 2015-07-08 0001193125-15-248065 — 2.01, 8.01, 9.01
- 2015-06-22 0001193125-15-229099 — 5.07
- 2015-06-19 0001193125-15-228428 — 5.02, 9.01
- 2015-04-20 0001262039-15-000014 — 2.02, 9.01
- 2015-01-28 0001262039-15-000005 — 2.02, 9.01
- 2014-10-22 0001262039-14-000036 — 2.02, 9.01
- 2014-07-23 0001262039-14-000030 — 2.02, 9.01
- 2014-06-24 0001262039-14-000027 — 5.07
- 2014-04-23 0001262039-14-000021 — 2.02, 9.01
- 2014-04-21 0001262039-14-000018 — 5.03, 9.01
- 2014-01-29 0001262039-14-000004 — 2.02, 9.01
- 2013-12-20 0001262039-13-000061 — 5.02, 9.01
- 2013-11-27 0001262039-13-000057 — 5.02, 7.01, 9.01
- 2013-11-12 0001445305-13-002993 — 5.02
- 2013-10-23 0001262039-13-000051 — 2.02, 9.01
- 2013-07-30 0001262039-13-000039 — 2.02, 9.01
- 2013-06-25 0001262039-13-000030 — 5.07
- 2013-04-30 0001262039-13-000023 — 2.02, 9.01
- 2013-04-19 0001262039-13-000020 — 5.02, 9.01
- 2013-04-19 0001262039-13-000018 — 5.02 — amendment of 0001262039-13-000020
- 2013-04-10 0001262039-13-000016 — 2.02, 9.01
- 2013-03-26 0001262039-13-000013 — 5.02
- 2013-01-30 0001262039-13-000005 — 2.02, 9.01
- 2013-01-24 0001262039-13-000002 — 5.02, 9.01
- 2012-10-16 0001262039-12-000048 — 2.02, 9.01
- 2012-10-01 0001262039-12-000045 — 5.02
- 2012-09-26 0001262039-12-000043 — 5.01
- 2012-07-25 0001262039-12-000038 — 2.02, 9.01
- 2012-07-19 0001262039-12-000034 — 5.02
- 2012-06-20 0001193125-12-275869 — 5.07
- 2012-04-27 0001262039-12-000029 — 5.02
- 2012-04-24 0001262039-12-000025 — 2.02, 9.01
- 2012-01-31 0001262039-12-000006 — 2.02, 9.01
- 2012-01-25 0001262039-12-000003 — 5.03
- 2011-10-24 0001262039-11-000036 — 2.02
- 2011-07-19 0001262039-11-000014 — 2.02, 9.01
- 2011-06-27 0001193125-11-174474 — 5.02, 5.07, 9.01
- 2011-04-27 0001193125-11-111938 — 2.02, 9.01
- 2011-01-25 0001193125-11-013914 — 2.02, 9.01
- 2010-10-21 0001193125-10-233676 — 2.02, 9.01
- 2010-09-02 0001193125-10-203099 — 8.01
- 2010-07-22 0001193125-10-163844 — 2.02, 9.01
- 2010-06-24 0001193125-10-146082 — 5.07
- 2010-04-28 0001193125-10-096698 — 2.02, 9.01
- 2010-02-09 0001193125-10-024614 — 8.01
- 2010-01-27 0001193125-10-014292 — 2.02, 9.01
- 2010-01-26 0001193125-10-013031 — 5.02, 9.01

## late-filing notifications on or before 2025-11-07

- none on or before 2025-11-07

## item 2.02 — earnings release, exhibit 99.1

[0001262039-25-000036:8k_2_02:1]
EX-99.1
2
ftntq3-2025ex991.htm
PRESS RELEASE

[0001262039-25-000036:8k_2_02:2]
Document

[0001262039-25-000036:8k_2_02:3]
Press Release

[0001262039-25-000036:8k_2_02:4]
Fortinet Reports Third Quarter 2025 Financial Results

[0001262039-25-000036:8k_2_02:5]
Highlights

[0001262039-25-000036:8k_2_02:6]
•Revenue grew 14% year over year to $1.72 billion

[0001262039-25-000036:8k_2_02:7]
•Product revenue grew 18% year over year to $559.3 million

[0001262039-25-000036:8k_2_02:8]
•Billings grew 14% year over year to $1.81 billion1

[0001262039-25-000036:8k_2_02:9]
•Record third quarter GAAP operating margin of 32%

[0001262039-25-000036:8k_2_02:10]
•Record third quarter Non-GAAP operating margin of 37%1

[0001262039-25-000036:8k_2_02:11]
SUNNYVALE, Calif. - November 5, 2025 - Fortinet® (Nasdaq: FTNT), a global cybersecurity leader driving the convergence of networking and security, today announced financial results for the third quarter ended September 30, 2025.

[0001262039-25-000036:8k_2_02:12]
“We are pleased with our excellent third quarter results, driven by our leading innovation and customer-first culture resulting in broad-based demand for our solutions across organizations of all sizes,” said Ken Xie, Founder, Chairman and Chief Executive Officer of Fortinet. “Building on our leadership in Firewall and SD-WAN through our unified FortiOS operating system, FortiSASE has quickly emerged as one of the fastest growing leaders in the SASE market. Fortinet has natively developed the key SASE functions, tightly integrating Next-Generation Firewall, SD-WAN, and SASE functionality into one unified ‘New Generation SASE Firewall’ solution, providing our customers with maximum flexibility to deploy security access at the edge and giving us a sustainable competitive advantage.”

[0001262039-25-000036:8k_2_02:13]
Recent Business Highlights

[0001262039-25-000036:8k_2_02:14]
•Recognized as a Leader in the inaugural 2025 Gartner® Magic Quadrant™ for Hybrid Mesh Firewall, ranking highest in ability to execute.

[0001262039-25-000036:8k_2_02:15]
•FortiSASE is the fastest-growing SASE solution at scale, with third quarter billings increasing by over 100% year over year, driven by an easy migration path that allows existing SD-WAN customers to enable SASE in minutes.

[0001262039-25-000036:8k_2_02:16]
•Launched the Secure AI Data Center solution, the industry’s first end-to-end framework designed specifically for AI workloads, delivering high-capacity connectivity and up to 69% lower energy consumption than alternative solutions.

[0001262039-25-000036:8k_2_02:17]
•Achieved rapid adoption in AI add-on solutions, supported by continued R&D investment and more than 500 issued and pending AI patents, powering over 20 AI-driven solutions.

[0001262039-25-000036:8k_2_02:18]
•Recognized as one of Newsweek’s Most Reliable Companies, ranking #16 out of 300 companies across all industries.

[0001262039-25-000036:8k_2_02:19]
Guidance

[0001262039-25-000036:8k_2_02:20]
For the fourth quarter of 2025, Fortinet currently expects:

[0001262039-25-000036:8k_2_02:21]
•Revenue in the range of $1.825 billion to $1.885 billion

[0001262039-25-000036:8k_2_02:22]
•Billings in the range of $2.185 billion to $2.285 billion

[0001262039-25-000036:8k_2_02:23]
•Non-GAAP gross margin in the range of 79.0% to 80.0%

[0001262039-25-000036:8k_2_02:24]
•Non-GAAP operating margin in the range of 34.5% to 35.5%

[0001262039-25-000036:8k_2_02:25]
•Diluted non-GAAP net income per share in the range of $0.73 to $0.75, assuming a non-GAAP effective tax rate of 18%. This assumes a diluted share count of 751 million to 755 million.

[0001262039-25-000036:8k_2_02:26]
For the fiscal year 2025, Fortinet currently expects:

[0001262039-25-000036:8k_2_02:27]
•Revenue in the range of $6.720 billion to $6.780 billion

[0001262039-25-000036:8k_2_02:28]
•Service revenue in the range of $4.575 billion to $4.595 billion

[0001262039-25-000036:8k_2_02:29]
•Billings in the range of $7.370 billion to $7.470 billion

[0001262039-25-000036:8k_2_02:30]
•Non-GAAP gross margin in the range of 80.25% to 80.75%

[0001262039-25-000036:8k_2_02:31]
•Non-GAAP operating margin in the range of 34.5% to 35.0%

[0001262039-25-000036:8k_2_02:32]
•Diluted non-GAAP net income per share in the range of $2.66 to $2.70, assuming a non-GAAP effective tax rate of 18%. This assumes a diluted share count of 764 million to 768 million.

[0001262039-25-000036:8k_2_02:33]
Our guidance with respect to non-GAAP financial measures excludes stock-based compensation, amortization of acquired intangible assets, settlements of litigation related matters, gain on intellectual property matters, gain on bargain purchase related to acquisition, gain from an equity method investment and a tax adjustment required for an effective tax rate on a non-GAAP basis, which differs from the GAAP effective tax rate. We have not reconciled our guidance with respect to non-GAAP financial measures to the corresponding GAAP measures because certain items that impact these measures are uncertain or out of our control or cannot be reasonably predicted. Accordingly, a reconciliation of these non-GAAP financial measures to the corresponding GAAP measures is not available without unreasonable effort.

[0001262039-25-000036:8k_2_02:34]
Conference Call Details

[0001262039-25-000036:8k_2_02:35]
Fortinet will host a conference call today at 1:30 p.m. Pacific Time (4:30 p.m. Eastern Time) to discuss the earnings results. A live webcast of the conference call and supplemental slides will be accessible from the Investor Relations page of Fortinet’s website at https://investor.fortinet.com and a replay will be archived and accessible at https://investor.fortinet.com/events-and-presentations.

[0001262039-25-000036:8k_2_02:36]
Fourth Quarter 2025 Conference Participation Schedule:

[0001262039-25-000036:8k_2_02:37]
•Wells Fargo TMT Summit

[0001262039-25-000036:8k_2_02:38]
November 18, 2025

[0001262039-25-000036:8k_2_02:39]
•UBS Global Technology and AI Conference

[0001262039-25-000036:8k_2_02:40]
December 2, 2025

[0001262039-25-000036:8k_2_02:41]
•Nasdaq Investor Conference

[0001262039-25-000036:8k_2_02:42]
December 10, 2025

[0001262039-25-000036:8k_2_02:43]
•Barclays Global Technology Conference

[0001262039-25-000036:8k_2_02:44]
December 11, 2025

[0001262039-25-000036:8k_2_02:45]
Members of Fortinet’s management team are expected to present at these conferences and discuss the latest company strategies and initiatives. Fortinet’s conference presentations are expected to be available via webcast on the company’s website. To access the most updated information, pre-register and listen to the webcast of each event, please visit the Investor Presentation & Events page of Fortinet’s website at https://investor.fortinet.com/events-and-presentations. The schedule is subject to change.

[0001262039-25-000036:8k_2_02:46]
About Fortinet (www.fortinet.com)

[0001262039-25-000036:8k_2_02:47]
Fortinet (Nasdaq: FTNT) is a driving force in the evolution of cybersecurity and the convergence of networking and security. Our mission is to secure people, devices and data everywhere, and today we deliver cybersecurity everywhere our customers need it with the largest integrated portfolio of over 50 enterprise-grade products. Well over half a million customers trust Fortinet’s solutions, which are among the most deployed, most patented and most validated in the industry. The Fortinet Training Institute, one of the largest and broadest training programs in the industry, is dedicated to making cybersecurity training and new career opportunities available to everyone. Collaboration with esteemed organizations from both the public and private sectors, including Computer Emergency Response Teams (“CERTs”), government entities, and academia, is a fundamental aspect of Fortinet’s commitment to enhance cyber resilience globally. FortiGuard Labs, Fortinet’s elite threat intelligence and research organization, develops and utilizes leading-edge machine learning and AI technologies to provide customers with timely and consistently top-rated protection and actionable threat intelligence. Learn more at https://www.fortinet.com, the Fortinet Blog or FortiGuard Labs.

[0001262039-25-000036:8k_2_02:48]
Forward-Looking Statements

[0001262039-25-000036:8k_2_02:49]
This press release contains forward-looking statements that involve risks and uncertainties. These forward-looking statements include statements regarding any indications related to future growth and market share gains, our strategy going forward, and guidance and expectations around future financial results, including guidance and expectations for the fourth quarter and full year 2025, and any statements regarding our market opportunity and market size, and business momentum. Although we attempt to be accurate in making forward-looking statements, it is possible that future circumstances might differ from the assumptions on which such statements are based such that actual results are materially different from our forward-looking statements in this release. Important factors that could cause results to differ materially from the statements herein include the following: general economic risks, including those caused by economic challenges, a possible economic downturn or recession and the effects of inflation or stagflation, rising interest rates or reduced information technology spending; supply chain challenges; negative impacts from the ongoing war in Ukraine and its related macroeconomic effects and our decision to reduce operations in Russia; competitiveness in the security market; the dynamic nature of the security market and its products and services; specific economic risks worldwide and in different geographies, and among different customer segments; uncertainty regarding demand and increased business and renewals from existing customers; sales execution risks, including risks in connection with the timing and completion of large strategic deals; uncertainties around continued success in sales growth and market share gains; uncertainties in market opportunities and the market size; actual or perceived vulnerabilities in our supply chain, products or services, and any actual or perceived breach of our network or our customers’ networks; longer sales cycles, particularly for larger enterprise, service providers, government and other large organization customers; the effectiveness of our salesforce and failure to convert sales pipeline into final sales; risks associated with successful implementation

[0001262039-25-000036:8k_2_02:50]
Use of Non-GAAP Financial Measures

[0001262039-25-000036:8k_2_02:51]
We believe that the presentation of non-GAAP financial information provides important supplemental information to management and investors regarding financial and business trends relating to our financial condition and results of operations. For further information regarding why we believe that these non-GAAP measures provide useful information to investors, the specific manner in which management uses these measures, and some of the limitations associated with the use of these measures, please refer to the “Explanation of Non-GAAP Financial Measures” section of this press release.

[0001262039-25-000036:8k_2_02:52]
FORTINET, INC.

[0001262039-25-000036:8k_2_02:53]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001262039-25-000036:8k_2_02:54]
(Unaudited, in millions)

[0001262039-25-000036:8k_2_02:55]
|  | September 30,2025 |  | December 31,2024 |
| ASSETS |  |  |  |
| CURRENT ASSETS: |  |  |  |
| Cash and cash equivalents | $ | 1,995.7 |  |  | $ | 2,875.9 |  |
| Short-term investments | 1,127.7 |  |  | 1,190.6 |  |
| Accounts receivable—net | 1,168.3 |  |  | 1,463.4 |  |
| Inventory | 426.6 |  |  | 315.5 |  |
| Prepaid expenses and other current assets | 195.2 |  |  | 126.1 |  |
| Total current assets | 4,913.5 |  |  | 5,971.5 |  |
| LONG-TERM INVESTMENTS | 289.1 |  |  | — |  |
| PROPERTY AND EQUIPMENT—NET | 1,605.2 |  |  | 1,349.5 |  |
| DEFERRED CONTRACT COSTS | 682.2 |  |  | 622.9 |  |
| DEFERRED TAX ASSETS | 1,367.8 |  |  | 1,335.6 |  |
| GOODWILL AND OTHER INTANGIBLE ASSETS—NET | 368.5 |  |  | 350.4 |  |
| OTHER ASSETS | 135.0 |  |  | 133.2 |  |
| TOTAL ASSETS | $ | 9,361.3 |  |  | $ | 9,763.1 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |
| CURRENT LIABILITIES: |  |  |  |
| Accounts payable | $ | 221.3 |  |  | $ | 190.9 |  |
| Accrued liabilities | 330.6 |  |  | 337.9 |  |
| Accrued payroll and compensation | 274.3 |  |  | 255.7 |  |
| Current portion of long-term debt | 499.4 |  |  | — |  |
| Deferred revenue | 3,460.5 |  |  | 3,276.2 |  |
| Total current liabilities | 4,786.1 |  |  | 4,060.7 |  |
| DEFERRED REVENUE | 3,189.9 |  |  | 3,084.7 |  |
| LONG-TERM DEBT | 496.5 |  |  | 994.3 |  |
| OTHER LIABILITIES | 153.7 |  |  | 129.6 |  |
| Total liabilities | 8,626.2 |  |  | 8,269.3 |  |
| COMMITMENTS AND CONTINGENCIES |  |  |  |
| STOCKHOLDERS’ EQUITY: |  |  |  |
| Common stock | 0.7 |  |  | 0.8 |  |
| Additional paid-in capital | 1,714.7 |  |  | 1,636.2 |  |
| Accumulated other comprehensive loss | (21.8) |  |  | (26.1) |  |
| Accumulated deficit | (958.5) |  |  | (117.1) |  |
| Total stockholders’ equity | 735.1 |  |  | 1,493.8 |  |
| TOTAL LIABILITIES AND STOCKHOLDERS’ EQUITY | $ | 9,361.3 |  |  | $ | 9,763.1 |  |

[0001262039-25-000036:8k_2_02:56]
FORTINET, INC.

[0001262039-25-000036:8k_2_02:57]
CONDENSED CONSOLIDATED STATEMENTS OF INCOME

[0001262039-25-000036:8k_2_02:58]
(Unaudited, in millions, except per share amounts)

[0001262039-25-000036:8k_2_02:59]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30,2025 |  | September 30,2024 |  | September 30,2025 |  | September 30,2024 |
| REVENUE: |  |  |  |  |  |  |  |
| Product | $ | 559.3 |  |  | $ | 473.9 |  |  | $ | 1,527.3 |  |  | $ | 1,334.7 |  |
| Service | 1,165.6 |  |  | 1,034.2 |  |  | 3,367.3 |  |  | 2,961.0 |  |
| Total revenue | 1,724.9 |  |  | 1,508.1 |  |  | 4,894.6 |  |  | 4,295.7 |  |
| COST OF REVENUE: |  |  |  |  |  |  |  |
| Product | 180.7 |  |  | 136.1 |  |  | 496.5 |  |  | 474.0 |  |
| Service | 151.0 |  |  | 127.3 |  |  | 443.2 |  |  | 369.1 |  |
| Total cost of revenue | 331.7 |  |  | 263.4 |  |  | 939.7 |  |  | 843.1 |  |
| GROSS PROFIT: |  |  |  |  |  |  |  |
| Product | 378.6 |  |  | 337.8 |  |  | 1,030.8 |  |  | 860.7 |  |
| Service | 1,014.6 |  |  | 906.9 |  |  | 2,924.1 |  |  | 2,591.9 |  |
| Total gross profit | 1,393.2 |  |  | 1,244.7 |  |  | 3,954.9 |  |  | 3,452.6 |  |
| OPERATING EXPENSES: |  |  |  |  |  |  |  |
| Research and development | 202.4 |  |  | 187.3 |  |  | 610.5 |  |  | 525.7 |  |
| Sales and marketing | 583.5 |  |  | 515.9 |  |  | 1,718.2 |  |  | 1,518.3 |  |
| General and administrative | 61.4 |  |  | 71.7 |  |  | 176.1 |  |  | 182.7 |  |
| Gain on intellectual property matters | (1.4) |  |  | (1.1) |  |  | (9.0) |  |  | (3.4) |  |
| Total operating expenses | 845.9 |  |  | 773.8 |  |  | 2,495.8 |  |  | 2,223.3 |  |
| OPERATING INCOME | 547.3 |  |  | 470.9 |  |  | 1,459.1 |  |  | 1,229.3 |  |
| INTEREST INCOME | 40.7 |  |  | 42.4 |  |  | 130.0 |  |  | 112.9 |  |
| INTEREST EXPENSE | (6.2) |  |  | (5.0) |  |  | (15.7) |  |  | (15.1) |  |
| OTHER INCOME—NET | 13.0 |  |  | 118.1 |  |  | 58.0 |  |  | 113.0 |  |
| INCOME BEFORE INCOME TAXES AND GAIN (LOSS) FROM EQUITY METHOD INVESTMENTS | 594.8 |  |  | 626.4 |  |  | 1,631.4 |  |  | 1,440.1 |  |
| PROVISION FOR INCOME TAXES | 120.7 |  |  | 81.2 |  |  | 294.3 |  |  | 197.2 |  |
| GAIN (LOSS) FROM EQUITY METHOD INVESTMENTS | (0.2) |  |  | (5.3) |  |  | 10.3 |  |  | (23.9) |  |
| NET INCOME | $ | 473.9 |  |  | $ | 539.9 |  |  | $ | 1,347.4 |  |  | $ | 1,219.0 |  |
| Net income per share: |  |  |  |  |  |  |  |
| Basic | $ | 0.63 |  |  | $ | 0.71 |  |  | $ | 1.77 |  |  | $ | 1.60 |  |
| Diluted | $ | 0.62 |  |  | $ | 0.70 |  |  | $ | 1.75 |  |  | $ | 1.58 |  |
| Weighted-average shares outstanding: |  |  |  |  |  |  |  |
| Basic | 755.5 |  |  | 765.0 |  |  | 763.1 |  |  | 763.7 |  |
| Diluted | 761.2 |  |  | 771.9 |  |  | 770.2 |  |  | 770.8 |  |

[0001262039-25-000036:8k_2_02:60]
FORTINET, INC.

[0001262039-25-000036:8k_2_02:61]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001262039-25-000036:8k_2_02:62]
(Unaudited, in millions)

[0001262039-25-000036:8k_2_02:63]
|  | Nine Months Ended |
|  | September 30,2025 |  | September 30,2024 |
| CASH FLOWS FROM OPERATING ACTIVITIES: |  |  |  |
| Net income | $ | 1,347.4 |  |  | $ | 1,219.0 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |
| Stock-based compensation | 207.0 |  |  | 192.1 |  |
| Amortization of deferred contract costs | 246.0 |  |  | 218.3 |  |
| Depreciation and amortization | 112.5 |  |  | 87.6 |  |
| Amortization of investment discounts | (27.3) |  |  | (37.3) |  |
| Other | (53.1) |  |  | (85.7) |  |
| Changes in operating assets and liabilities, net of impact of business combinations: |  |  |  |
| Accounts receivable—net | 308.7 |  |  | 376.5 |  |
| Inventory | (109.1) |  |  | 104.9 |  |
| Prepaid expenses and other current assets | (64.3) |  |  | (9.0) |  |
| Deferred contract costs | (305.3) |  |  | (212.2) |  |
| Deferred tax assets | 13.7 |  |  | (187.6) |  |
| Other assets | (13.6) |  |  | (8.8) |  |
| Accounts payable | 11.5 |  |  | (32.0) |  |
| Accrued liabilities | (15.5) |  |  | (72.3) |  |
| Accrued payroll and compensation | 16.3 |  |  | (7.9) |  |
| Deferred revenue | 288.1 |  |  | 234.4 |  |
| Other liabilities | 7.4 |  |  | 0.5 |  |
| Net cash provided by operating activities | 1,970.4 |  |  | 1,780.5 |  |
| CASH FLOWS FROM INVESTING ACTIVITIES: |  |  |  |
| Purchases of investments | (1,512.6) |  |  | (1,485.3) |  |
| Sales of investments | 5.7 |  |  | — |  |
| Maturities of investments | 1,317.6 |  |  | 1,382.7 |  |
| Purchases of property and equipment | (322.0) |  |  | (281.3) |  |
| Payments made in connection with business combinations, net of cash acquired | (41.6) |  |  | (247.0) |  |
| Purchases of marketable equity securities | — |  |  | (16.7) |  |
| Other | 0.1 |  |  | 0.1 |  |
| Net cash used in investing activities | (552.8) |  |  | (647.5) |  |
| CASH FLOWS FROM FINANCING ACTIVITIES: |  |  |  |
| Repurchase and retirement of common stock | (2,232.6) |  |  | (0.6) |  |
| Proceeds from issuance of common stock | 37.6 |  |  | 39.7 |  |
| Taxes paid related to net share settlement of equity awards | (103.7) |  |  | (79.6) |  |
| Other | (0.1) |  |  | (0.8) |  |
| Net cash used in financing activities | (2,298.8) |  |  | (41.3) |  |
| EFFECT OF EXCHANGE RATE CHANGES ON CASH AND CASH EQUIVALENTS | 1.0 |  |  | (0.3) |  |
| NET INCREASE (DECREASE) IN CASH AND CASH EQUIVALENTS | (880.2) |  |  | 1,091.4 |  |
| CASH AND CASH EQUIVALENTS—Beginning of period | 2,875.9 |  |  | 1,397.9 |  |
| CASH AND CASH EQUIVALENTS—End of period | $ | 1,995.7 |  |  | $ | 2,489.3 |  |

[0001262039-25-000036:8k_2_02:64]
Reconciliations of non-GAAP results of operations measures to the nearest comparable GAAP measures

[0001262039-25-000036:8k_2_02:65]
(Unaudited, in millions, except per share amounts)

[0001262039-25-000036:8k_2_02:66]
Reconciliation of GAAP operating income to non-GAAP operating income, operating margin, net income and diluted net income per share

[0001262039-25-000036:8k_2_02:67]
|  | Three Months Ended |  |  |
|  | September 30,2025 |  | September 30,2024 |  |  |  |  |
| Reconciliation of non-GAAP operating income: |  |  |  |  |  |  |  |
| GAAP operating income | $ | 547.3 |  |  | $ | 470.9 |  |  |  |  |  |
| GAAP operating margin | 31.7 | % |  | 31.2 | % |  |  |  |  |
| Add back: |  |  |  |  |  |  |  |
| Stock‐based compensation | 72.2 |  |  | 66.4 |  |  |  |  |  |
| Amortization of acquired intangible assets | 13.1 |  |  | 5.3 |  |  |  |  |  |
| Litigation related matters | 5.6 |  |  | 3.2 |  |  |  |  |  |
| Gain on intellectual property matters | (1.4) |  |  | (1.1) |  |  |  |  |  |
| Non‐GAAP operating income | $ | 636.8 |  |  | $ | 544.7 |  |  |  |  |  |
| Non‐GAAP operating margin | 36.9 | % |  | 36.1 | % |  |  |  |  |
| Reconciliation of non-GAAP net income: |  |  |  |  |  |  |  |
| GAAP net income | $ | 473.9 |  |  | $ | 539.9 |  |  |  |  |  |
| Add back: |  |  |  |  |  |  |  |
| Stock‐based compensation | 72.2 |  |  | 66.4 |  |  |  |  |  |
| Amortization of acquired intangible assets | 13.1 |  |  | 5.3 |  |  |  |  |  |
| Litigation related matters | 5.6 |  |  | 3.2 |  |  |  |  |  |
| Gain on intellectual property matters | (1.4) |  |  | (1.1) |  |  |  |  |  |
| Gain on bargain purchase | — |  |  | (106.3) |  |  |  |  |  |
| Tax adjustment (a) | (2.4) |  |  | (19.8) |  |  |  |  |  |
| Non-GAAP net income | $ | 561.0 |  |  | $ | 487.6 |  |  |  |  |  |
| Non-GAAP net income per share, diluted |  |  |  |  |  |  |  |
| Non-GAAP net income | $ | 561.0 |  |  | $ | 487.6 |  |  |  |  |  |
| Non-GAAP shares used in diluted net income per share calculations | 761.2 |  |  | 771.9 |  |  |  |  |  |
| Non-GAAP net income per share, diluted | $ | 0.74 |  |  | $ | 0.63 |  |  |  |  |  |
| Reconciliation of non-GAAP net income per share, diluted |  |  |  |  |  |  |  |
| GAAP net income per share, diluted | $ | 0.62 |  |  | $ | 0.70 |  |  |  |  |  |
| Add back: |  |  |  |  |  |  |  |
| Non-GAAP adjustments to net income per share | 0.12 |  |  | (0.07) |  |  |  |  |  |
| Non-GAAP net income per share, diluted | $ | 0.74 |  |  | $ | 0.63 |  |  |  |  |  |

[0001262039-25-000036:8k_2_02:68]
(a) Non-GAAP financial information is adjusted to an effective tax rate of 18% and 17% in the three months ended September 30, 2025 and 2024, respectively, on a non-GAAP basis, which differs from the GAAP effective tax rate.

[0001262039-25-000036:8k_2_02:69]
Reconciliation of net cash provided by operating activities to free cash flow

[0001262039-25-000036:8k_2_02:70]
|  | Three Months Ended |
|  | September 30,2025 |  | September 30,2024 |
| Net cash provided by operating activities | $ | 655.2 |  |  | $ | 608.1 |  |
| Less: Purchases of property and equipment | (87.7) |  |  | (36.3) |  |
| Free cash flow | $ | 567.5 |  |  | $ | 571.8 |  |
| Net cash used in investing activities | $ | (175.8) |  |  | $ | (327.1) |  |
| Net cash provided by (used in) financing activities | $ | (1,851.9) |  |  | $ | 3.0 |  |

[0001262039-25-000036:8k_2_02:71]
Reconciliation of total revenue to total billings

[0001262039-25-000036:8k_2_02:72]
|  | Three Months Ended |
|  | September 30,2025 |  | September 30,2024 |
| Total revenue | $ | 1,724.9 |  |  | $ | 1,508.1 |  |
| Add: Change in deferred revenue | 82.8 |  |  | 115.5 |  |
| Less: Deferred revenue balance acquired in business acquisitions | — |  |  | (41.4) |  |
| Total billings | $ | 1,807.7 |  |  | $ | 1,582.2 |  |

[0001262039-25-000036:8k_2_02:73]
1 A reconciliation of GAAP to non-GAAP measures has been provided in the financial statement tables included in this press release. An explanation of these measures is also included below under the heading “Explanation of Non-GAAP Financial Measures”.

[0001262039-25-000036:8k_2_02:74]
Explanation of Non-GAAP Financial Measures

[0001262039-25-000036:8k_2_02:75]
We have provided in this release financial information that has not been prepared in accordance with U.S. Generally Accepted Accounting Principles (“GAAP”). These non-GAAP financial and liquidity measures are not based on any standardized methodology prescribed by GAAP and are not necessarily comparable to similar measures presented by other companies. We use these non-GAAP financial measures internally in analyzing our financial results and believe they are useful to investors, as a supplement to GAAP measures, in evaluating our ongoing operational performance. We believe that the use of these non-GAAP financial measures provides an additional tool for investors to use in evaluating ongoing operating results and trends and in comparing our financial results with peer companies, many of which present similar non-GAAP financial measures to investors.

[0001262039-25-000036:8k_2_02:76]
Non-GAAP financial measures should not be considered in isolation from, or as a substitute for, financial information prepared in accordance with GAAP. Investors are encouraged to review the reconciliation of these non-GAAP financial measures to their most directly comparable GAAP financial measures provided in the financial statement tables below.

[0001262039-25-000036:8k_2_02:77]
Billings (non-GAAP). We define billings as revenue recognized in accordance with GAAP plus the change in deferred revenue from the beginning to the end of the period less any deferred revenue balances acquired from business combination(s) during the period. We consider billings to be a useful metric for management and investors because billings drive current and future revenue, which is an important indicator of the health and viability of our business and cash flows. There are a number of limitations related to the use of billings instead of GAAP revenue. First, billings include amounts that have not yet been recognized as revenue and are impacted by the term of security and support agreements. Second, we may calculate billings in a manner that is different from peer companies that report similar financial measures. Management accounts for these limitations by providing specific information regarding GAAP revenue and evaluating billings together with GAAP revenue.

[0001262039-25-000036:8k_2_02:78]
Free cash flow (non-GAAP). We define free cash flow as net cash provided by operating activities minus purchases of property and equipment. We believe free cash flow to be a liquidity measure that provides useful information to management and investors about the amount of cash generated by the business that, after capital expenditures, can be used for strategic opportunities, including repurchasing outstanding common stock, investing in our business, making strategic acquisitions and strengthening the balance sheet. A limitation of using free cash flow rather than the GAAP measures of cash provided by or used in operating activities, investing activities, and financing activities is that free cash flow does not represent the total increase or decrease in the cash and cash equivalents balance for the period because it excludes investing activities other than capital expenditures and cash flows from financing activities. Management accounts for this limitation by providing information about our capital expenditures and other investing and financing activities on the face of the cash flow statement and under the caption “Management’s Discussion and Analysis of Financial Condition and Results of Operations—Liquidity and Capital Resources” in our most recent Quarterly Report on Form 10-Q and Annual Report on Form 10-K and by presenting cash flows from investing and financing activities in our reconciliation of free cash flow. In addition, it is important to note that other companies, including companies in our industry, may not use free cash flow, may calculate free cash flow in a different manner than we do or may use other financial measures to evaluate their performance, all of which could reduce the usefulness of free cash flow as a comparative measure.

[0001262039-25-000036:8k_2_02:79]
Non-GAAP operating income and operating margin. We define non-GAAP operating income as operating income plus stock-based compensation, amortization of acquired intangible assets, and charges in connection with litigation settlements, less gain on intellectual property matters and, when applicable, other significant non-recurring items in a given quarter. Non-GAAP operating margin is defined as non-GAAP operating income divided by GAAP revenue. We consider these non-GAAP financial measures to be useful metrics for management and investors because they exclude the items noted above so that our management and investors can compare our recurring core business operating

[0001262039-25-000036:8k_2_02:80]
results over multiple periods. There are a number of limitations related to the use of non-GAAP operating income instead of operating income calculated in accordance with GAAP. First, non-GAAP operating income excludes the items noted above. Second, the components of the costs that we exclude from our calculation of non-GAAP operating income may differ from the components that peer companies exclude when they report their non-GAAP results of operations. Management accounts for these limitations by providing specific information regarding the GAAP amounts excluded from non-GAAP operating income and evaluating non-GAAP operating income together with operating income calculated in accordance with GAAP.

[0001262039-25-000036:8k_2_02:81]
Non-GAAP net income and diluted net income per share. We define non-GAAP net income as net income plus the items noted above under non-GAAP operating income and operating margin. In addition, we adjust non-GAAP net income and diluted net income per share for a gain on bargain purchase related to acquisition and a tax adjustment required for an effective tax rate on a non-GAAP basis, which differs from the GAAP effective tax rate. We define non-GAAP diluted net income per share as non-GAAP net income divided by the non-GAAP diluted weighted-average shares outstanding. We consider these non-GAAP financial measures to be useful metrics for management and investors for the same reasons that we use non-GAAP operating income and non-GAAP operating margin. However, in order to provide a more complete picture of our recurring core business operating results, we include in non-GAAP net income and non-GAAP diluted net income per share, the tax adjustment required resulting in an effective tax rate on a non-GAAP basis, which often differs from the GAAP tax rate. We believe the non-GAAP effective tax rates we use are reasonable estimates of normalized tax rates for our current and prior fiscal years under our global operating structure. The same limitations described above regarding our use of non-GAAP operating income and non-GAAP operating margin apply to our use of non-GAAP net income and non-GAAP diluted net income per share. We account for these limitations by providing specific information regarding the GAAP amounts excluded from non-GAAP net income and non-GAAP diluted net income per share and evaluating non-GAAP net income and non-GAAP diluted net income per share together with net income and diluted net income per share calculated in accordance with GAAP.

[0001262039-25-000036:8k_2_02:82]
#          #          #

[0001262039-25-000036:8k_2_02:83]
Copyright © 2025 Fortinet, Inc. All rights reserved. The symbols ® and ™ denote respectively federally registered trademarks and common law trademarks of Fortinet, Inc., its subsidiaries and affiliates. Fortinet’s trademarks include, but are not limited to, the following: Fortinet, the Fortinet logo, FortiGate, FortiOS, FortiGuard, FortiCare, FortiAnalyzer, FortiManager, FortiASIC, FortiClient, FortiCloud, FortiCore, FortiMail, FortiSandbox, FortiADC, FortiAgent, FortiAI, FortiAIOps, FortiAntenna, FortiAP, FortiAPCam, FortiAppSec, FortiAuthenticator, FortiBranchSASE, FortiCall, FortiCam, FortiCamera, FortiCarrier, FortiCART, FortiCASB, FortiCentral, FortiCNP, FortiConnect, FortiController, FortiConverter, FortiCSPM, FortiCWP, FortiDAST, FortiDATA, FortiDB, FortiDDoS, FortiDeceptor, FortiDeploy, FortiDevice, FortiDevSec, FortiDLP, FortiEdge, FortiEDR, FortiEndpoint, FortiExplorer, FortiExtender, FortiFirewall, FortiFlex, FortiFone, FortiGSLB, FortiGuest, FortiHypervisor, FortiIdentity, FortiInsight, FortiIsolator, FortiLAN, FortiLink, FortiMonitor, FortiNAC, FortiNDR, FortiPAM, FortiPenTest, FortiPhish, FortiPoint, FortiPoints, FortiPortal, FortiPresence, FortiProxy, FortiRecon, FortiRecorder, FortiSASE, FortiScanner, FortiSDNConnector, FortiSEC, FortiSIEM, FortiSMS, FortiSOAR, FortiSRA, FortiSwitch, FortiTelemetry, FortiTester, FortiToken, FortiTrust, FortiVoice, FortiWAN, FortiWeb, FortiWiFi, FortiWLC, FortiWLM, FortiXDR, Lacework FortiCNAPP, Linksys, Intelligent Mesh, Velop, Max-Stream, Performance Perfected and SECURITY FABRIC. Other trademarks belong to their respective owners. Fortinet has not independently verified statements or certifications herein attributed to third parties and Fortinet does not independently endorse such statements. Notwithstanding anything to the contrary herein, nothing herein constitutes a warranty, guarantee, contract, binding specification or other binding commitment by Fortinet or any indication of intent related to a binding commitment, and performance and other specification information herein may be unique to certain environments.

[0001262039-25-000036:8k_2_02:84]
FTNT-F

[0001262039-25-000036:8k_2_02:85]
GARTNER is a registered trademark and service mark of Gartner, Inc. and/or its affiliates in the U.S. and internationally, Magic Quadrant is a registered trademark of Gartner, Inc. and/or its affiliates and is used herein with permission. All rights reserved.

[0001262039-25-000036:8k_2_02:86]
Gartner does not endorse any vendor, product, or service depicted in its research publications, and does not advise technology users to select only those vendors with the highest ratings or other designation. Gartner research publications consist of the opinions of Gartner’s research organization and should not be construed as statements of fact. Gartner disclaims all warranties, expressed or implied, with respect to this research, including any warranties of merchantability or fitness for a particular purpose.

[0001262039-25-000036:8k_2_02:87]
Note for Gartner Peer Insights™: Reviews from vendor partners or end users of companies with less than $50 million in revenue are excluded from this methodology. See the full “Voice of the Customer” methodology.

[0001262039-25-000036:8k_2_02:88]
Gartner and Peer Insights are trademarks of Gartner, Inc. and/or its affiliates. All rights reserved. Gartner Peer Insights content consists of the opinions of individual end users based on their own experiences, and should not be construed as statements of fact, nor do they represent the views of Gartner or its affiliates. Gartner does not endorse any vendor, product or service depicted in this content nor makes any warranties, expressed or implied, with respect to this content, about its accuracy or completeness, including any warranties of merchantability or fitness for a particular purpose.

[0001262039-25-000036:8k_2_02:89]
Gartner, Magic Quadrant for Hybrid Mesh Firewall, By Rajpreet Kaur, Adam Hils, Charanpal Bhogal, Esraa ElTahawy, Feng Gao, Tiffany Taylor, 25 August 2025

[0001262039-25-000036:8k_2_02:90]
| Investor Contact: |  | Media Contact: |
| Anthony Luscri |  | Stephanie Lira |
| Fortinet, Inc. |  | Fortinet, Inc. |
| 408-235-7700 |  | 408-235-7700 |
| investors@fortinet.com |  | pr@fortinet.com |
