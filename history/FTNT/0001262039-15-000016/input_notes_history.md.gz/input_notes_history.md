# FTNT note change history — 0001262039-14-000039 → 0001262039-15-000016


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2015-05-01):
[0001262039-15-000016:note_history:1]
The following table summarizes our future principal contractual obligations as of March 31, 2015 (in thousands):
  (was, 2014-11-06, similarity 0.9541):
[0001262039-14-000039:note_history:1]
The following table summarizes our future principal contractual obligations as of September 30, 2014 (in thousands):

- changed (2015-05-01):
[0001262039-15-000016:note_history:2]
|  | Total |  | 2015 (remainder) |  | 2016 |  | 2017 |  | 2018 |  | 2019 |  | Thereafter |
| Operating lease commitments | $ | 40,130 |  |  | $ | 9,560 |  |  | $ | 9,453 |  |  | $ | 7,252 |  |  | $ | 6,506 |  |  | $ | 4,567 |  |  | $ | 2,792 |  |
| Less: Sublease rental income | 224 |  |  | 224 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Operating lease commitments—net | 39,906 |  |  | 9,336 |  |  | 9,453 |  |  | 7,252 |  |  | 6,506 |  |  | 4,567 |  |  | 2,792 |  |
| Inventory purchase commitments | 67,715 |  |  | 67,715 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Other contractual commitments and open purchase orders | 28,108 |  |  | 26,020 |  |  | 1,518 |  |  | 570 |  |  | — |  |  | — |  |  | — |  |
| Total | $ | 135,729 |  |  | $ | 103,071 |  |  | $ | 10,971 |  |  | $ | 7,822 |  |  | $ | 6,506 |  |  | $ | 4,567 |  |  | $ | 2,792 |  |
  (was, 2014-11-06, similarity 0.738):
[0001262039-14-000039:note_history:2]
|  | Total |  | 2014 (remainder) |  | 2015 |  | 2016 |  | 2017 |  | 2018 |  | Thereafter |
| Operating lease commitments | $ | 39,575 |  |  | $ | 2,495 |  |  | $ | 9,411 |  |  | $ | 7,590 |  |  | $ | 6,649 |  |  | $ | 5,467 |  |  | $ | 7,963 |  |
| Less: Sublease rental income | 642 |  |  | 193 |  |  | 449 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Operating lease commitments—net | 38,933 |  |  | 2,302 |  |  | 8,962 |  |  | 7,590 |  |  | 6,649 |  |  | 5,467 |  |  | 7,963 |  |
| Purchase commitments | 76,355 |  |  | 53,006 |  |  | 23,349 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Other contractual commitments | 24,176 |  |  | 19,530 |  |  | 3,592 |  |  | 813 |  |  | 241 |  |  | — |  |  | — |  |
| Total | $ | 139,464 |  |  | $ | 74,838 |  |  | $ | 35,903 |  |  | $ | 8,403 |  |  | $ | 6,890 |  |  | $ | 5,467 |  |  | $ | 7,963 |  |

- added (2015-05-01):
[0001262039-15-000016:note_history:3]
Operating Leases—We lease certain facilities under various non-cancelable operating leases, which expire through 2024. In addition to the amounts above, certain leases require us to pay variable costs such as taxes, maintenance, insurance, and asset retirement obligations. The terms of certain operating leases also provide for renewal options and escalation clauses. Rent expense was $3.1 million and $2.7 million during the three months ended March 31, 2015 and 2014, respectively. Rent expense is recognized using the straight-line method over the term of the lease.

- changed (2015-05-01):
[0001262039-15-000016:note_history:4]
Contract Manufacturer and Other Commitments—Our independent contract manufacturers procure components and build our products based on our forecasts. These forecasts are based on estimates of future demand for our products, which are in turn based on historical trends and analysis, adjusted for overall market conditions. In order to reduce manufacturing lead times and plan for adequate component supply, we may issue purchase orders to some of our independent contract manufacturers which may not be cancelable. As of March 31, 2015, we had $67.7 million of open purchase orders with our independent contract manufacturers.
  (was, 2014-11-06, similarity 0.6064):
[0001262039-14-000039:note_history:4]
Purchase Commitments and Other Contractual Commitments—In order to reduce manufacturing lead times and plan for adequate component supply, we may issue purchase orders to some of our independent contract manufacturers which may not be cancelable. As of September 30, 2014, we had $76.4 million of open purchase orders with our independent contract manufacturers that may not be cancelable.

- changed (2015-05-01):
[0001262039-15-000016:note_history:5]
In addition to commitments with contract manufacturers, we have other contractual commitments and open purchase orders in the ordinary course of business for which we have not received goods or services. As of March 31, 2015, we had $28.1 million in other contractual commitments and open purchase orders.
  (was, 2014-11-06, similarity 0.6833):
[0001262039-14-000039:note_history:5]
In addition to commitments with contract manufacturers, we have open purchase orders and contractual obligations in the ordinary course of business for which we have not received goods or services. As of September 30, 2014, we had $24.2 million in other purchase commitments.

- changed (2015-05-01):
[0001262039-15-000016:note_history:6]
|  | Three Months Ended |
|  | March 31, 2015 |  | March 31, 2014 |
| Accrued warranty balance—beginning of the period | $ | 4,269 |  |  | $ | 3,037 |  |
| Warranty costs incurred | (1,095 | ) |  | (756 | ) |
| Provision for warranty for the period | 945 |  |  | 837 |  |
| Adjustment related to pre-existing warranties | 222 |  |  | (313 | ) |
| Accrued warranty balance—end of the period | $ | 4,341 |  |  | $ | 2,805 |  |
  (was, 2014-11-06, similarity 0.8617):
[0001262039-14-000039:note_history:6]
|  | Nine Months Ended |
|  | September 30, 2014 |  | September 30, 2013 |
| Accrued warranty balance—beginning of the period | $ | 3,037 |  |  | $ | 2,309 |  |
| Warranty costs incurred | (2,597 | ) |  | (2,670 | ) |
| Provision for warranty for the period | 3,786 |  |  | 3,134 |  |
| Adjustment related to pre-existing warranties | (540 | ) |  | 274 |  |
| Accrued warranty balance—end of the period | $ | 3,686 |  |  | $ | 3,047 |  |

- changed (2015-05-01):
[0001262039-15-000016:note_history:7]
Litigation—We are involved in disputes, litigation, and other legal actions. For lawsuits where we are the defendant, we are in the process of defending these litigation matters, and while there can be no assurances and the outcome of these matters is currently not determinable, we currently believe that there are no existing claims or proceedings that are likely to have a material adverse effect on our financial position. There are many uncertainties associated with any litigation and these actions or other third-party claims against us may cause us to incur costly litigation or substantial settlement charges. In addition, the resolution of any intellectual property litigation may require us to make royalty payments, which could adversely affect our gross margins in future periods. If any of those events were to occur, our business, financial condition, results of operations, and cash flows could be adversely affected. The actual liability in any such matters may be materially different from our estimates, if any, which could result in the need to adjust the liability and record additional expenses. We have not recorded any significant accrual for loss contingencies associated with such legal proceedings; determined that an unfavorable outcome is probable or reasonably possible; or determined that the amount or range of any possible loss is reasonably estimable.
  (was, 2014-11-06, similarity 0.9956):
[0001262039-14-000039:note_history:7]
Litigation—We are involved in disputes, litigation, and other legal actions. For lawsuits where we are the defendant, we are in the process of defending these litigation matters, and while there can be no assurances and the outcome of these matters is currently not determinable, we currently believe that there are no existing claims or proceedings that are likely to have a material adverse effect on our financial position. There are many uncertainties associated with any litigation and these actions or other third-party claims against us may cause us to incur costly litigation or substantial settlement charges. In addition, the resolution of any intellectual property litigation may require us to make royalty payments, which could adversely affect our gross margins in future periods. If any of those events were to occur, our business, financial condition, results of operations, and cash flows could be adversely affected. The actual liability in any such matters may be materially different from our estimates, if any, which could result in the need to adjust the liability and record additional expenses. We have not recorded any accrual for loss contingencies associated with such legal proceedings; determined that an unfavorable outcome is probable or reasonably possible; or determined that the amount or range of any possible loss is reasonably estimable.

- added (2015-05-01):
[0001262039-15-000016:note_history:8]
Indemnification—Under the indemnification provisions of our standard sales contracts, we agree to defend our customers against third-party claims asserting various allegations such as damage resulting from product defects and infringement of certain intellectual property rights, which may include patents, copyrights, trademarks, or trade secrets, and to pay judgments entered on such claims. Our exposure under these indemnification provisions is generally limited by the terms of our contracts to certain defined limits, such as the total amount paid by our customer under the agreement. However, certain agreements include covenants and indemnification provisions including and beyond indemnification for third-party claims of intellectual property infringement and that could potentially expose us to losses in excess of the amount received under the agreement and, in some instances, to potential liability that is not contractually limited. To date, there have been no awards under such indemnification provisions.

- removed (2015-05-01):
[0001262039-14-000039:note_history:9]
Operating Leases—We lease certain facilities under various non-cancelable operating leases, which expire through 2024. The terms of certain operating leases provide for renewal options. Rent expense is recognized using the straight-line method over the term of the lease. Rent expense was $2.6 million and $2.4 million during the three months ended September 30, 2014 and September 30, 2013, respectively. Rent expense was $7.7 million and $7.1 million during the nine months ended September 30, 2014 and September 30, 2013, respectively.

- removed (2015-05-01):
[0001262039-14-000039:note_history:10]
Indemnification—Under the indemnification provisions of our standard sales contracts, we agree to defend our customers against third-party claims asserting infringement of certain intellectual property rights, which may include patents, copyrights, trademarks, or trade secrets, and to pay judgments entered on such claims. Our exposure under these indemnification provisions is generally limited by the terms of our contracts to the total amount paid by our customer under the agreement. However, certain agreements include indemnification provisions beyond indemnification for third-party claims of intellectual property infringement and that could potentially expose us to losses in excess of the amount received under the agreement. To date, there have been no awards under such indemnification provisions.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2015-05-01):
[0001262039-15-000016:note_history:11]
Basis of Presentation and Preparation—The unaudited condensed consolidated financial statements of Fortinet, Inc. and its wholly-owned subsidiaries (collectively, “we,” “us” or “our”) have been prepared in accordance with generally accepted accounting principles in the United States (“GAAP”) for interim financial information as well as the instructions to Form 10-Q pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (“SEC”). Accordingly, they do not include all of the information and footnotes required by GAAP for complete financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the year ended December 31, 2014, contained in our Annual Report on Form 10-K (“Form 10-K”) filed with the SEC on March 2, 2015. In the opinion of management, all adjustments, which includes normal recurring adjustments, considered necessary for a fair presentation have been included. All intercompany balances, transactions and cash flows have been eliminated. The results of operations for the three months ended March 31, 2015 are not necessarily indicative of the results for the full year or for any future periods. The condensed consolidated balance sheet as of December 31, 2014 is derived from the audited consolidated financial statements for the year ended December 31, 2014.
  (was, 2014-11-06, similarity 0.9537):
[0001262039-14-000039:note_history:11]
Basis of Presentation and Preparation—The unaudited condensed consolidated financial statements of Fortinet, Inc. and its wholly owned subsidiaries (collectively, “we,” “us,” or “our”) have been prepared in accordance with generally accepted accounting principles (“GAAP”) in the United States (“U.S.”) for interim financial information as well as the instructions to Form 10-Q pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (“SEC”). Accordingly, they do not include all of the information and footnotes required by GAAP for complete financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the fiscal year ended December 31, 2013, contained in our Annual Report on Form 10-K (“Form 10-K”) filed with the SEC on March 3, 2014. In the opinion of management, all adjustments, which includes normal recurring adjustments, considered necessary for a fair presentation have been included. All intercompany balances, transactions and cash flows have been eliminated. The results of operations for the three and nine months ended September 30, 2014 are not necessarily indicative of the operating results for the full year or for any future periods. The condensed consolidated balance sheets as of December 31, 2013 are derived from the audited consolidated financial statements for the year ended December 31, 2013.

- added (2015-05-01):
[0001262039-15-000016:note_history:12]
There have been no material changes to our significant accounting policies as of and for the three months ended March 31, 2015.

- added (2015-05-01):
[0001262039-15-000016:note_history:13]
In the third quarter of 2014, we reevaluated the selected functional currency of our international subsidiaries due to the nature of our business operations and recorded the cumulative impact of the reevaluation of the functional currency in the consolidated statement of operations. Subsequently, the remeasurement of the assets and liabilities of all international subsidiaries has been recorded in the consolidated statement of operations prospectively. The impact of this reevaluation is not material for our fiscal 2014 or any of our previously issued financial statements.

- added (2015-05-01):
[0001262039-15-000016:note_history:14]
Recent Accounting Pronouncement

- changed (2015-05-01):
[0001262039-15-000016:note_history:15]
In May 2014, the Financial Accounting Standards Board issued Accounting Standards Update No. 2014-09—Revenue from Contracts with Customers (Topic 606) (“ASU 2014-09”) to create a single, joint revenue standard that is consistent across all industries and markets for companies that prepare their financial statements in accordance with GAAP. Under ASU 2014-09, an entity is required to recognize revenue upon the transfer of promised goods or services to customers in an amount that reflects the consideration the entity expects to be entitled to receive in exchange for those goods or services. ASU 2014-09 is effective for us beginning on January 1, 2017. We are currently evaluating the impact of ASU 2014-09 on our consolidated financial statements.
  (was, 2014-11-06, similarity 0.9534):
[0001262039-14-000039:note_history:15]
Recent Accounting Pronouncement—In May 2014, the Financial Accounting Standards Board issued Accounting Standards Update No. 2014-09 (Topic 606) - Revenue from Contracts with Customers (“ASU 2014-09”) to create a single, joint revenue standard that is consistent across all industries and markets for companies that prepare their financial statements in accordance with U.S. GAAP. Under ASU 2014-09, an entity is required to recognize revenue upon the transfer of promised goods or services to customers in an amount that reflects the consideration the entity expects to be entitled to receive in exchange for those goods or services. ASU 2014-09 is effective for us beginning on January 1, 2017. We are currently evaluating the impact of ASU 2014-09 on our consolidated financial statements.

- removed (2015-05-01):
[0001262039-14-000039:note_history:16]
There have been no material changes to our significant accounting policies as of and for the three and nine months ended September 30, 2014.  During the first quarter of fiscal 2014, we prospectively modified the expected term calculation used in accounting for stock-based compensation expense and the estimated useful lives of building improvements, and furniture and fixtures. During the third quarter of fiscal 2014, we reevaluated the functional currency selection for certain of our international subsidiaries and prospectively applied the U.S. dollar.

- removed (2015-05-01):
[0001262039-14-000039:note_history:17]
Stock-Based Compensation Expense—Beginning in the first quarter of fiscal 2014, we changed the methodology of calculating the expected term, which is one of the assumptions used in determining the fair value of our employee stock options under the Black Scholes option pricing model. The expected term represents the period that our stock-based awards are estimated to be outstanding. We believe that we have sufficient historical experience since becoming a publicly-traded company for estimating the expected term of the stock option awards, and therefore, we calculated our expected term based on historical experience instead of using the simplified method.

- removed (2015-05-01):
[0001262039-14-000039:note_history:18]
Currency Translation Adjustment—Prior to the third quarter of fiscal 2014, the assets and liabilities of our international subsidiaries were translated into U.S. dollars using the applicable exchange rates. The resulting foreign translation adjustments were included in the consolidated balance sheets as a component of accumulated other comprehensive income (loss) and in the consolidated statements of comprehensive income.

- removed (2015-05-01):
[0001262039-14-000039:note_history:19]
We reevaluated the selected functional currency of our international subsidiaries due to the nature of our business operations. We recorded the cumulative impact of the reevaluation of the functional currency in the condensed consolidated statement of operations for the three months ended September 30, 2014.  The remeasurement of the assets and liabilities of all international subsidiaries will be recorded in the consolidated statement of operations prospectively. The impact of this reevaluation is not material for any of our previously issued financial statements.

- removed (2015-05-01):
[0001262039-14-000039:note_history:20]
Property and Equipment—Property and equipment—net is stated at cost less accumulated depreciation. Depreciation is computed using the straight-line method over the estimated useful lives of the assets as follows:

- removed (2015-05-01):
[0001262039-14-000039:note_history:21]
|  | Estimated Useful Lives |
| Building and building improvements | 20 years |
| Evaluation units | 1 year |
| Computer equipment and software | 1-2 years |
| Furniture and fixtures | 3 - 5 years |
| Leasehold improvements | Shorter of useful life or lease term |

- removed (2015-05-01):
[0001262039-14-000039:note_history:22]
In March 2014, we moved into our new corporate headquarters and estimated the useful life of the building and related improvements to be 20 years. The useful life of furniture and fixtures placed in service in the new building is estimated to be 3 to 5 years.

- removed (2015-05-01):
[0001262039-14-000039:note_history:23]
Reclassification—Beginning in the first quarter of 2014, the amounts previously reported as Ratable and other revenue have been combined with the amounts previously reported as Services revenue in the condensed consolidated statements of operations. The combined amounts are now being presented as Services and other revenue in the condensed consolidated statements of operations. The related Cost of revenue and Gross profit, including prior period amounts, have also been combined to conform to the current period presentation.  The Ratable and other revenue amounts, including the related Cost of revenue and Gross profit amounts, are not material, and the reclassification did not have any impact on our gross margin or net income.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: no_prior_note, score: 0.0

- added (2015-05-01):
[0001262039-15-000016:note_history:24]
RELATED PARTY TRANSACTIONS

- added (2015-05-01):
[0001262039-15-000016:note_history:25]
The son of one member of our Board is a partner of an outside law firm that we utilize for certain complex litigation matters. Expenses for legal services provided by the law firm related to matters that arose subsequent to the member joining our Board were $1.9 million and $0.3 million for the three months ended March 31, 2015 and March 31, 2014, respectively.  Amounts due and payable to the law firm were $1.7 million and $1.3 million as of March 31, 2015 and December 31, 2014, respectively.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_current_note, score: 0.0

- removed (2015-05-01):
[0001262039-14-000039:note_history:26]
SUBSEQUENT EVENT

- removed (2015-05-01):
[0001262039-14-000039:note_history:27]
On October 17, 2014, our Board extended the share repurchase authorization under the Program through December 31, 2015. As of October 17, 2014, $124.9 million remained authorized for future share repurchases under the Program.
