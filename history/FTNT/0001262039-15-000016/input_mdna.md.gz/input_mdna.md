# FTNT MD&A — 0001262039-15-000016


## mdna

[0001262039-15-000016:mdna:1]
[same as prior period, unchanged from 0001262039-14-000039:mdna:1]

[0001262039-15-000016:mdna:2]
| • | continued growth and market share gains; |

[0001262039-15-000016:mdna:3]
[same as prior period, unchanged from 0001262039-14-000039:mdna:2]

[0001262039-15-000016:mdna:4]
[same as prior period, unchanged from 0001262039-14-000039:mdna:4]

[0001262039-15-000016:mdna:5]
| • | the proportion of our revenue that consists of our product and service revenue, and the mix of billings between products and services; |

[0001262039-15-000016:mdna:6]
[same as prior period, unchanged from 0001262039-14-000039:mdna:6]

[0001262039-15-000016:mdna:7]
| • | growing our sales to large enterprises, service providers, and government organizations; |

[0001262039-15-000016:mdna:8]
[same as prior period, unchanged from 0001262039-14-000039:mdna:9]

[0001262039-15-000016:mdna:9]
| • | trends in our operating expenses, including research and development expenses, sales and marketing expenses and general and administrative expenses, and expectations regarding these expenses as a percentage of revenue; |

[0001262039-15-000016:mdna:10]
| • | continued investments in research and development; |

[0001262039-15-000016:mdna:11]
| • | continued investments in sales and marketing and the impact of those investments; |

[0001262039-15-000016:mdna:12]
[same as prior period, unchanged from 0001262039-14-000039:mdna:12]

[0001262039-15-000016:mdna:13]
[same as prior period, unchanged from 0001262039-14-000039:mdna:13]

[0001262039-15-000016:mdna:14]
[same as prior period, unchanged from 0001262039-14-000039:mdna:14]

[0001262039-15-000016:mdna:15]
| • | our intentions regarding repatriation of cash, cash equivalents and investments held by our international subsidiaries and the sufficiency of our existing cash, cash equivalents and investments to meet our cash needs for at least the next 12 months; and |

[0001262039-15-000016:mdna:16]
| • | other statements regarding our future operations, financial condition and prospects and business strategies. |

[0001262039-15-000016:mdna:17]
[same as prior period, unchanged from 0001262039-14-000039:mdna:17]

[0001262039-15-000016:mdna:18]
We provide high performance cyber security solutions to some of the largest enterprise, service providers and government organizations across the globe, including a majority of the 2014 Fortune 100. Our cyber security solutions are fast and secure and designed to provide broad, high-performance protection against dynamic security threats while simplifying the information technology (“IT”) infrastructure of our end-customers worldwide.

[0001262039-15-000016:mdna:19]
Our flagship integrated network security solution consists of our FortiGate physical and virtual appliance products that provide a broad array of integrated security and networking functions to protect data, applications, and users from network- and

[0001262039-15-000016:mdna:20]
content-level security threats. These functions, which can be integrated in a variety of ways, include firewall, intrusion prevention, anti-malware, application control, virtual private network, web-filtering, vulnerability management, anti-spam, wireless controller, and wide area network  acceleration. Our FortiGate appliances may be deployed as Next Generation Firewalls, Data Center Firewalls, Unified Threat Management systems, Internal Network Firewall, Virtual Machine Firewalls or Cloud Firewalls. Our FortiGate appliances range from the FortiGate-20 series for small businesses and branch offices to the FortiGate-5000 series for large enterprises and service providers, and are based on our proprietary technology platform. This platform includes our FortiASICs, which are specifically designed for accelerated processing of security and networking functions, and our FortiOS operating system, which provides the foundation for all FortiGate security functions. Our FortiGuard security subscription services provide end-customers with access to dynamic updates to our application control, anti-malware, intrusion prevention, web filtering, and anti-spam functionality. Our security services are based on intelligence gathered by our FortiGuard Labs team, which is comprised of a large team of threat researchers who detect threats and help protect our customers. By combining multiple proprietary security and networking functions with our purpose-built FortiASIC and FortiOS, our FortiGate solution delivers broad protection against dynamic security threats while reducing the operational burden and costs associated with managing multiple point products.

[0001262039-15-000016:mdna:21]
We complement our FortiGate product line with the FortiManager product family, which enables end-customers to manage the system configuration and security functions of multiple FortiGate devices from a centralized console, as well as the FortiAnalyzer product family, which enables collection, analysis and archiving of content and log data generated by our products.

[0001262039-15-000016:mdna:22]
We offer virtual appliances for the FortiGate, FortiManager, FortiAnalyzer, FortiWeb, FortiMail, FortiCache, and FortiADC product lines that can be used in conjunction with traditional Fortinet physical appliances, such as FortiGate, FortiManager, and FortiAnalyzer, to help ensure the visibility, management, and protection of physical and virtual environments. We also offer on-demand cloud-based versions of FortiGate and FortiWeb.

[0001262039-15-000016:mdna:23]
[same as prior period, unchanged from 0001262039-14-000039:mdna:24]

[0001262039-15-000016:mdna:24]
| • | We recorded total revenue of $212.9 million for the three months ended March 31, 2015, an increase of 26% compared to the same period last year. Product revenue was $97.5 million during the three months ended March 31, 2015, an increase of 27% compared to the same period last year. Service revenue was $115.4 million for the three months ended March 31, 2015, an increase of 25% compared to the same period last year. |

[0001262039-15-000016:mdna:25]
| • | Cash, cash equivalents and investments were $1.07 billion as of March 31, 2015, an increase of $80.8 million, or 8%, from December 31, 2014. |

[0001262039-15-000016:mdna:26]
| • | Deferred revenue was $600.2 million as of March 31, 2015, an increase of $41.4 million, or 7%, from December 31, 2014. |

[0001262039-15-000016:mdna:27]
| • | We generated cash flows from operating activities of $64.6 million during the three months ended March 31, 2015, an increase of $3.7 million, or 6%, compared to the same period last year. |

[0001262039-15-000016:mdna:28]
Revenue grew as a result of our focus on growth and our strategy to increase sales capacity and invest in our marketing activities. We continue to grow and strengthen our enterprise sales force. Our marketing investments are also beginning to yield returns, with improvement in lead quality and conversion rates. Our strategy is enabling us to gain market share, win new customers, and expand within existing customer accounts, especially in the enterprise market.  We continue to grow the number of large deals with enterprises and service providers, which is key to our long-term growth strategy as these high-end customers tend to provide higher lifetime value and are beneficial to our business model over time.

[0001262039-15-000016:mdna:29]
During the three months ended March 31, 2015, our revenue growth was primarily driven by greater sales volume in our FortiGate product family due to increased demand across all product categories. Our high-end FortiGate products (FortiGate-1000 to -5000 series) accounted for 37% of billings primarily driven by continued enterprise adoption of our high-end appliances such as the FortiGate-1500D and 3700D series appliances. Our mid-range products (FortiGate-200 to -800 series) accounted for 26% of billings, and our entry-level products (FortiGate-20 to -100 series) accounted for 37% of billings.

[0001262039-15-000016:mdna:30]
During the three months ended March 31, 2015, while our operating expenses benefited from favorable foreign exchange rates, operating expenses increased compared to the same period last year. The increase was primarily driven by our accelerated pace of hiring and marketing investments to support our growth as we continued to invest in expanding our sales coverage, marketing capabilities, developing new products and scaling our customer support organization to meet the needs of

[0001262039-15-000016:mdna:31]
23

[0001262039-15-000016:mdna:32]
our customer base. Headcount, including full time equivalent employees, increased to 3,076 as of March 31, 2015 from 2,389 as of March 31, 2014.

[0001262039-15-000016:mdna:33]
[same as prior period, unchanged from 0001262039-14-000039:mdna:38]

[0001262039-15-000016:mdna:34]
[same as prior period, unchanged from 0001262039-14-000039:mdna:39]

[0001262039-15-000016:mdna:35]
|  | Three Months Ended Or As Of |
|  | March 31, 2015 |  | March 31, 2014 |
|  | (in thousands) |
| Revenue | $ | 212,886 |  |  | $ | 168,949 |  |
| Deferred revenue | $ | 600,171 |  |  | $ | 451,303 |  |
| Increase in deferred revenue | $ | 41,414 |  |  | $ | 18,675 |  |
| Billings (non-GAAP) | $ | 254,300 |  |  | $ | 187,624 |  |
| Cash, cash equivalents and investments | $ | 1,072,565 |  |  | $ | 888,314 |  |
| Net cash provided by operating activities | $ | 64,619 |  |  | $ | 60,902 |  |
| Free cash flow (non-GAAP) | $ | 59,692 |  |  | $ | 49,584 |  |

[0001262039-15-000016:mdna:36]
Deferred revenue. Our deferred revenue consists of amounts that have been invoiced but that have not yet been recognized as revenue. The majority of our deferred revenue balance consists of the unamortized portion of services revenue from FortiGuard security subscription and FortiCare support service contracts. We monitor our deferred revenue balance because it represents a significant portion of revenue to be recognized in future periods.

[0001262039-15-000016:mdna:37]
Billings (Non-GAAP).We define billings as revenue recognized plus the change in deferred revenue from the beginning to the end of the period less any deferred revenue balances acquired from business combination(s) during the period, if any. We consider billings to be a useful metric for management and investors because billings drives deferred revenue, which is an important indicator of the health and viability of our business, and historically the recognition of previously deferred revenue represented a majority of the quarterly revenue that we recognize. There are a number of limitations related to the use of billings versus revenue calculated in accordance with GAAP. First, billings include amounts that have not yet been recognized as revenue. Second, we may calculate billings in a manner that is different from peer companies that report similar financial measures. Management compensates for these limitations by providing specific information regarding GAAP revenue and evaluating billings together with revenue calculated in accordance with GAAP. A reconciliation of billings to revenue, the most directly comparable financial measure calculated and presented in accordance with GAAP, is provided below:

[0001262039-15-000016:mdna:38]
|  | Three Months Ended |
| March 31, 2015 |  | March 31, 2014 |
| (in thousands) |
| Billings: |  |  |  |
| Revenue | $ | 212,886 |  |  | $ | 168,949 |  |
| Increase in deferred revenue | 41,414 |  |  | 18,675 |  |
| Total billings (Non-GAAP) | $ | 254,300 |  |  | $ | 187,624 |  |

[0001262039-15-000016:mdna:39]
Free cash flow (Non-GAAP). We define free cash flow as net cash provided by operating activities minus capital expenditures. We consider free cash flow to be a liquidity measure that provides useful information to management and investors about the amount of cash generated by the business that, after the acquisition of property and equipment, can be used for strategic opportunities, including investing in our business, making strategic acquisitions, repurchasing outstanding common stock, and strengthening the balance sheet. Analysis of free cash flow facilitates management’s comparisons of our operating results to competitors’ operating results. A limitation of using free cash flow versus the GAAP measure of net cash

[0001262039-15-000016:mdna:40]
[same as prior period, unchanged from 0001262039-14-000039:mdna:20]

[0001262039-15-000016:mdna:41]
provided by operating activities as a means for evaluating liquidity is that free cash flow does not represent the total increase or decrease in the cash, cash equivalents and investments balance for the period because free cash flow excludes cash used for capital expenditures and also excludes cash provided by or used for other investing and financing activities. Management compensates for this limitation by providing information about our capital expenditures and other investing and financing activities on the face of the cash flow statement and under “—Liquidity and Capital Resources.”  A reconciliation of free cash flow to net cash provided by operating activities, the most directly comparable financial measure calculated and presented in accordance with GAAP, is provided below:

[0001262039-15-000016:mdna:42]
|  | Three Months Ended |
| March 31, 2015 |  | March 31, 2014 |
| (in thousands) |
| Free Cash Flow: |  |  |  |
| Net cash provided by operating activities | $ | 64,619 |  |  | $ | 60,902 |  |
| Less purchases of property and equipment | (4,927 | ) |  | (11,318 | ) |
| Free cash flow (Non-GAAP) | $ | 59,692 |  |  | $ | 49,584 |  |

[0001262039-15-000016:mdna:43]
Critical Accounting Policies and Estimates

[0001262039-15-000016:mdna:44]
Our discussion and analysis of our financial condition and results of operations are based upon our financial statements, which have been prepared in accordance with GAAP. These principles require us to make estimates and judgments that affect the reported amounts of assets, liabilities, revenue, cost of revenue, expenses, and related disclosures. Our estimates include those related to revenue recognition, stock-based compensation expense, valuation of inventory, warranty liabilities, investments, goodwill and other long-lived assets and accounting for income taxes. We base our estimates on historical experience and on various other assumptions that we believe to be reasonable under the circumstances. To the extent that there are material differences between these estimates and our actual results, our future financial statements will be affected.

[0001262039-15-000016:mdna:45]
There have been no material changes to our critical accounting policies and estimates as of and for the three months ended March 31, 2015, as compared to the critical accounting policies and estimates described in the Form 10-K.

[0001262039-15-000016:mdna:46]
[same as prior period, unchanged from 0001262039-14-000039:mdna:34]

[0001262039-15-000016:mdna:47]
[same as prior period, unchanged from 0001262039-14-000039:mdna:52]

[0001262039-15-000016:mdna:48]
[same as prior period, unchanged from 0001262039-14-000039:mdna:54]

[0001262039-15-000016:mdna:49]
|  | Three Months Ended |  |  |  |  |
| March 31, 2015 |  | March 31, 2014 |  |  |  |  |
| Amount |  | % ofRevenue |  | Amount |  | % ofRevenue |  | Change |  | % Change |
| (in thousands, except percentages) |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 97,509 |  |  | 46 | % |  | $ | 76,765 |  |  | 45 | % |  | $ | 20,744 |  |  | 27 | % |
| Service | 115,377 |  |  | 54 |  |  | 92,184 |  |  | 55 |  |  | 23,193 |  |  | 25 |  |
| Total revenue | $ | 212,886 |  |  | 100 | % |  | $ | 168,949 |  |  | 100 | % |  | $ | 43,937 |  |  | 26 | % |
| Revenue by geography: |  |  |  |  |  |  |  |  |  |  |  |
| Americas | $ | 91,560 |  |  | 43 | % |  | $ | 72,432 |  |  | 43 | % |  | $ | 19,128 |  |  | 26 | % |
| EMEA | 75,664 |  |  | 36 |  |  | 56,643 |  |  | 33 |  |  | 19,021 |  |  | 34 |  |
| APAC | 45,662 |  |  | 21 |  |  | 39,874 |  |  | 24 |  |  | 5,788 |  |  | 15 |  |
| Total revenue | $ | 212,886 |  |  | 100 | % |  | $ | 168,949 |  |  | 100 | % |  | $ | 43,937 |  |  | 26 | % |

[0001262039-15-000016:mdna:50]
Total revenue increased by $43.9 million, or 26%, during the three months ended March 31, 2015 compared to the same period last year.  The EMEA region grew by 34% due to strong sales performance across the region. The Americas region grew by 26% as we saw continued strength in the U.S. enterprise market driven by increased sales to large enterprises. The APAC region grew by 15% as we saw continued growth in certain parts of the region. Product revenue increased by $20.7 million, or 27%, during the three months ended March 31, 2015 compared to the same period last year. The increase in product revenue was primarily driven by greater sales volume in our FortiGate product family due to increased demand across all product categories for our entry-level products for smaller enterprises, our mid-range products for mid-to-large enterprises and branch deployments, and our high-end products for large enterprise and service provider customers.

[0001262039-15-000016:mdna:51]
Service revenue increased by $23.2 million, or 25%, during the three months ended March 31, 2015 compared to the same period last year due to the recognition of revenue from our deferred revenue balance consisting of FortiGuard security subscription and FortiCare technical support contracts sold to a larger customer base as well as the renewals of similar contracts sold in earlier periods.

[0001262039-15-000016:mdna:52]
Cost of revenue and gross margin

[0001262039-15-000016:mdna:53]
|  | Three Months Ended |  |  |  |  |
| March 31, 2015 |  | March 31, 2014 |  | Change |  | % Change |
| (in thousands, except percentages) |
| Cost of revenue: |  |  |  |  |  |  |  |
| Product | $ | 41,368 |  |  | $ | 32,139 |  |  | $ | 9,229 |  |  | 29 | % |
| Service | 22,234 |  |  | 18,604 |  |  | 3,630 |  |  | 20 |  |
| Total cost of revenue | $ | 63,602 |  |  | $ | 50,743 |  |  | $ | 12,859 |  |  | 25 | % |
| Gross margin (%): |  |  |  |  |  |  |  |
| Product | 57.6 | % |  | 58.1 | % |  | (0.5 | )% |  |  |
| Service | 80.7 |  |  | 79.8 |  |  | 0.9 |  |  |  |
| Total gross margin | 70.1 | % |  | 70.0 | % |  | 0.1 | % |  |  |

[0001262039-15-000016:mdna:54]
Total gross margin remained relatively consistent during the three months ended March 31, 2015 compared to the same period last year. Product gross margin decreased by 0.5 percentage points during the three months ended March 31, 2015 compared to the same period last year primarily due to an increase in freight costs of $1.3 million and warranty costs of $1.0 million.

[0001262039-15-000016:mdna:55]
[same as prior period, unchanged from 0001262039-14-000039:mdna:37]

[0001262039-15-000016:mdna:56]
Service gross margin increased by 0.9 percentage points during the three months ended March 31, 2015 as compared to the same period last year. Cost of service revenue increased by $3.6 million primarily due to a $2.9 million increase in personnel costs, including stock-based compensation, related to headcount increases, and a $0.7 million increase in depreciation and other costs.

[0001262039-15-000016:mdna:57]
[same as prior period, unchanged from 0001262039-14-000039:mdna:63]

[0001262039-15-000016:mdna:58]
|  | Three Months Ended |  | Change |  | % Change |
| March 31, 2015 |  | March 31, 2014 |  |
| Amount |  | % ofRevenue |  | Amount |  | % ofRevenue |  |
| (in thousands, except percentages) |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | $ | 35,816 |  |  | 17 | % |  | $ | 29,055 |  |  | 17 | % |  | $ | 6,761 |  |  | 23 | % |
| Sales and marketing | 100,609 |  |  | 47 |  |  | 67,326 |  |  | 40 |  |  | 33,283 |  |  | 49 |  |
| General and administrative | 11,961 |  |  | 6 |  |  | 9,010 |  |  | 5 |  |  | 2,951 |  |  | 33 |  |
| Total operating expenses | $ | 148,386 |  |  | 70 | % |  | $ | 105,391 |  |  | 62 | % |  | $ | 42,995 |  |  | 41 | % |

[0001262039-15-000016:mdna:59]
[same as prior period, unchanged from 0001262039-14-000039:mdna:65]

[0001262039-15-000016:mdna:60]
Research and development expense increased by $6.8 million, or 23%, during the three months ended March 31, 2015 compared to the same period last year primarily due to an increase of $3.2 million in personnel costs and $1.3 million in stock-based compensation as a result of increased headcount to support the development of new products and continued enhancements of our existing products. Occupancy-related and other costs increased by $0.7 million and depreciation expense increased by $0.5 million. During the three months ended March 31, 2014, expenses were also lower by $1.1 million due to the reversal of a previously recorded liability for estimated contingent consideration. We intend to continue to invest in our research and development organization but expect research and development expense as a percentage of total revenue to remain at comparable levels during the remainder of 2015.

[0001262039-15-000016:mdna:61]
[same as prior period, unchanged from 0001262039-14-000039:mdna:67]

[0001262039-15-000016:mdna:62]
Sales and marketing expense increased by $33.3 million, or 49%, during the three months ended March 31, 2015 compared to the same period last year, primarily due to an increase of $19.9 million in personnel costs as we continued to increase our sales headcount in order to drive continued market share gains globally. Marketing-related expenses increased by $3.6 million as we invested significantly in marketing to capture market share, particularly in the enterprise market, including costs related to trade-shows and lead generation campaigns. In addition, stock-based compensation expense increased by $3.6 million, depreciation and other expenses increased by $2.8 million, travel expenses increased by $1.7 million, and supplies increased by $1.6 million. As a percentage of total revenue, sales and marketing expenses increased as we accelerated the investment in our sales force and marketing campaigns to drive future growth. We intend to continue to make investments in our sales resources and infrastructure and marketing, which are critical to support growth, and expect sales and marketing expense as a percentage of total revenue to decrease during the remainder of 2015.

[0001262039-15-000016:mdna:63]
[same as prior period, unchanged from 0001262039-14-000039:mdna:69]

[0001262039-15-000016:mdna:64]
General and administrative expense increased by $3.0 million, or 33%, during the three months ended March 31, 2015 compared to the same period last year. Personnel costs, including stock-based compensation, increased by $2.6 million, as we continued to increase our headcount in order to support our expanding business. In addition, depreciation and other expenses increased by $0.3 million.  We expect general and administrative expense to increase as a percentage of total revenue during the remainder of 2015.

[0001262039-15-000016:mdna:65]
27

[0001262039-15-000016:mdna:66]
Interest income and other expense—net

[0001262039-15-000016:mdna:67]
|  | Three Months Ended |  |  |  |  |
| March 31, 2015 |  | March 31, 2014 |  | Change |  | % Change |
| (in thousands, except percentages) |
| Interest income | $ | 1,422 |  |  | $ | 1,333 |  |  | $ | 89 |  |  | 7 | % |
| Other expense—net | (677 | ) |  | (389 | ) |  | (288 | ) |  | 74 |  |

[0001262039-15-000016:mdna:68]
Interest income increased in the three months ended March 31, 2015 compared to the same period last year due to interest earned on higher invested balances of cash, cash equivalents and investments. The increase in other expense—net for the three months ended March 31, 2015 when compared to the same period last year, was the result of higher foreign exchange losses.

[0001262039-15-000016:mdna:69]
[same as prior period, unchanged from 0001262039-14-000039:mdna:75]

[0001262039-15-000016:mdna:70]
|  | Three Months Ended |  | Change |  | % Change |
| March 31, 2015 |  | March 31, 2014 |  |
| (in thousands, except percentages) |
| Provision for income taxes | $ | 83 |  |  | $ | 5,366 |  |  | $ | (5,283 | ) |  | (98 | )% |
| Effective tax rate (%) | 5 | % |  | 39 | % |  | (34 | )% |  | — |  |

[0001262039-15-000016:mdna:71]
Our effective tax rate was 5% for the three months ended March 31, 2015, compared with an effective tax rate of 39% for the same period last year. The provision for income taxes for the three months ended March 31, 2015 was comprised primarily of U.S. federal and state taxes, other foreign income taxes, foreign withholding taxes, and transfer pricing allocations which impact jurisdictional income taxed at various tax rates. During the three months ended March 31, 2015, discrete items included a higher tax benefit from stock-based compensation expense and foreign exchange impact relating to uncertain tax benefit for developments in international tax that impacted the quarterly effective tax rate.

[0001262039-15-000016:mdna:72]
It is our policy to classify accrued interest and penalties related to unrecognized tax benefits in the provision for income taxes. As of March 31, 2015, we had accrued $4.5 million for estimated interest related to uncertain tax provisions.

[0001262039-15-000016:mdna:73]
Within the next twelve months, we do not believe there will be a decrease in uncertain tax benefits that could significantly impact our effective tax rate.

[0001262039-15-000016:mdna:74]
[same as prior period, unchanged from 0001262039-14-000039:mdna:106]

[0001262039-15-000016:mdna:75]
|  | As of |
|  | March 31, 2015 |  | December 31, 2014 |
|  | (in thousands) |
| Cash and cash equivalents | $ | 386,352 |  |  | $ | 283,254 |  |
| Investments | 686,213 |  |  | 708,490 |  |
| Total cash, cash equivalents and investments | $ | 1,072,565 |  |  | $ | 991,744 |  |
| Working capital | $ | 593,170 |  |  | $ | 550,409 |  |
|  | Three Months Ended |
|  | March 31, 2015 |  | March 31, 2014 |
|  | (in thousands) |
| Cash provided by operating activities | $ | 64,619 |  |  | $ | 60,902 |  |
| Cash provided by (used) in investing activities | 16,124 |  |  | (2,364 | ) |
| Cash provided by (used in) financing activities | 22,355 |  |  | (888 | ) |
| Effect of exchange rates on cash and cash equivalents | — |  |  | (555 | ) |
| Net increase in cash and cash equivalents | $ | 103,098 |  |  | $ | 57,095 |  |

[0001262039-15-000016:mdna:76]
Liquidity and capital resources may be impacted by our operating activities, as well as acquisitions, capital expenditures, stock repurchases, proceeds associated with stock option exercises and issuances of common stock under the ESPP, payment of taxes in connection with the net settlement of RSUs, and investments in strategic relationships that we have made or may make in the future. As of March 31, 2015, $122.5 million remains available for future share repurchases under our stock repurchase program (“Program”), which will be financed through our available working capital.  In recent years, we have received significant capital resources as a result of exercises of stock options and purchases under our ESPP.  We expect proceeds in future years to be impacted by our share price and the changing mix of stock options and RSUs granted.  We expect to spend approximately $30.0 million to $35.0 million primarily related to expansion of our offices to support worldwide growth, as well as the implementation of our enterprise resource planning system.

[0001262039-15-000016:mdna:77]
As of March 31, 2015, our cash, cash equivalents, and investments of $1.07 billion were invested primarily in corporate debt securities, commercial paper, municipal bonds, certificates of deposit and term deposits, money market funds, and U.S. government and agency debt securities. It is our investment policy to invest excess cash in a manner that preserves capital, provides liquidity and maximizes return without significantly increasing risk.

[0001262039-15-000016:mdna:78]
As of March 31, 2015, $326.2 million of our cash and investments were held by our international subsidiaries and are therefore not immediately available to fund domestic operations unless the cash is repatriated. While we do not intend to do so, should this amount be repatriated, it would be subject to U.S. federal income tax which would be partially offset by foreign tax credits. We do not enter into investments for trading or speculative purposes. We believe that our existing cash and cash equivalents will be sufficient to meet our anticipated cash needs for at least the next 12 months. Our future capital requirements will depend on many factors including our growth rate, the timing and extent of spending to support development efforts, the expansion of sales and marketing activities, the introduction of new and enhanced products and services offerings, the costs to ensure access to adequate manufacturing capacity and the continuing market acceptance of our products. Historically, we have required capital principally to fund our working capital needs, capital expenditures, share repurchases, and acquisition activities. In the event that additional financing is required from outside sources, we may not be able to raise it on terms acceptable to us or at all. If we are unable to raise additional capital when desired, our business, operating results and financial condition would be adversely affected.

[0001262039-15-000016:mdna:79]
[same as prior period, unchanged from 0001262039-14-000039:mdna:61]

[0001262039-15-000016:mdna:80]
[same as prior period, unchanged from 0001262039-14-000039:mdna:112]

[0001262039-15-000016:mdna:81]
Cash generated by operating activities is our primary source of liquidity. It is primarily comprised of net income, adjusted for non-cash items, and changes in operating assets and liabilities. Non-cash adjustments consisted primarily of stock-based compensation, depreciation of property and equipment, amortization of intangible assets, excess tax benefit from stock-based compensation, and amortization of investment premiums.

[0001262039-15-000016:mdna:82]
Our operating activities during the three months ended March 31, 2015 provided $64.6 million in cash as a result of profitability, timing of billings and collections, and the ability to successfully manage our working capital. The primary sources of cash from operating activities during the three months ended March 31, 2015 consisted of net income of $1.6 million increased by non-cash adjustments of $27.3 million and changes in operating assets and liabilities of $35.7 million. Changes in operating assets and liabilities primarily included an increase in payments received from customers, partially offset by an increase in payments to vendors for inventory-related purchases and prepayment of certain expenses.

[0001262039-15-000016:mdna:83]
Our operating activities during the three months ended March 31, 2014, provided $60.9 million in cash as a result of our growth in billings, profitability, and the ability to successfully manage our working capital. The primary sources of cash from operating activities during the three months ended March 31, 2014 consisted of net income of $8.4 million increased by non-cash adjustments of $19.2 million and changes in operating assets and liabilities of $33.3 million. During the three months ended March 31, 2014, we received $20.0 million pursuant to a six year mutual covenant-not-to-sue and release agreement with Palo Alto Networks, Inc. Changes in operating assets and liabilities primarily included an increase in payments received from customers and a receipt of cash related to the mutual covenant-not-to-sue and release agreement, partially offset by payment of income taxes during the period.

[0001262039-15-000016:mdna:84]
[same as prior period, unchanged from 0001262039-14-000039:mdna:116]

[0001262039-15-000016:mdna:85]
[same as prior period, unchanged from 0001262039-14-000039:mdna:117]

[0001262039-15-000016:mdna:86]
During the three months ended March 31, 2015, cash provided by investing activities was a result of positive cash flow due to maturities, net of purchases, from our investments of $21.1 million, partially offset by capital expenditures of $4.9 million.

[0001262039-15-000016:mdna:87]
During the three months ended March 31, 2014, cash used by investing activities was primarily due to capital expenditures of $11.3 million, partially offset by positive cash flow due to maturities, net of purchases, from our investments of $9.0 million.

[0001262039-15-000016:mdna:88]
[same as prior period, unchanged from 0001262039-14-000039:mdna:120]

[0001262039-15-000016:mdna:89]
The changes in cash flows from financing activities primarily relate to proceeds from the issuance of common stock under our equity incentive plan and ESPP, taxes paid related to net share settlement of equity awards, excess tax benefit from stock-based compensation, and repurchase and retirement of common stock.

[0001262039-15-000016:mdna:90]
During the three months ended March 31, 2015, cash provided by financing activities was $22.4 million as a result of proceeds of $29.0 million from the issuance of common stock under our stock plans. This cash inflow was partially offset by $6.6 million of tax payments related to withholding upon the issuance of RSUs.

[0001262039-15-000016:mdna:91]
During the three months ended March 31, 2014, we used $12.3 million to repurchase and retire our common stock and $3.6 million to pay taxes related to withholding upon issuance of RSUs. These cash outflows were partially offset by proceeds of $14.5 million from the issuance of common stock under our stock plans, as well as excess tax benefit from employee stock-based compensation of $0.6 million.

[0001262039-15-000016:mdna:92]
[same as prior period, unchanged from 0001262039-14-000039:mdna:124]

[0001262039-15-000016:mdna:93]
There have been no material changes outside the ordinary course of business during the three months ended March 31, 2015 to the contractual obligations and commitments disclosed in Management’s Discussion and Analysis of Financial Condition and Results of Operations, set forth in Part II, Item 7, of the Form 10-K. See Note 8 to the notes to the condensed consolidated financial statements included in Part I, Item 1 of this Form 10-Q for additional information regarding contractual obligations and commitments.

[0001262039-15-000016:mdna:94]
[same as prior period, unchanged from 0001262039-14-000039:mdna:126]

[0001262039-15-000016:mdna:95]
As of March 31, 2015, we did not have any relationships with unconsolidated organizations or financial partnerships, such as structured finance or special purpose entities that would have been established for the purpose of facilitating off-balance sheet arrangements or other contractually narrow or limited purposes.
