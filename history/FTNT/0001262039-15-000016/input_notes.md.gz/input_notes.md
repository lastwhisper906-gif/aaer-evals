# FTNT notes — 0001262039-15-000016


## ftnt:IncomeTaxBenefitFromStockOptionPlansTableTextBlock

[0001262039-15-000016:notes:1]
Total income tax benefit associated with stock-based compensation that is recognized in the condensed consolidated statements of operations is as follows (in thousands):

[0001262039-15-000016:notes:2]
|  | Three Months Ended |
|  | March 31, 2015 |  | March 31, 2014 |
| Income tax benefit associated with stock-based compensation | $ | 3,377 |  |  | $ | 3,349 |  |


## ftnt:PresentationAndPreparationOfConsolidatedFinancialStatementsPolicyTextBlock

[0001262039-15-000016:notes:3]
Basis of Presentation and Preparation—The unaudited condensed consolidated financial statements of Fortinet, Inc. and its wholly-owned subsidiaries (collectively, “we,” “us” or “our”) have been prepared in accordance with generally accepted accounting principles in the United States (“GAAP”) for interim financial information as well as the instructions to Form 10-Q pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (“SEC”). Accordingly, they do not include all of the information and footnotes required by GAAP for complete financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the year ended December 31, 2014, contained in our Annual Report on Form 10-K (“Form 10-K”) filed with the SEC on March 2, 2015. In the opinion of management, all adjustments, which includes normal recurring adjustments, considered necessary for a fair presentation have been included. All intercompany balances, transactions and cash flows have been eliminated. The results of operations for the three months ended March 31, 2015 are not necessarily indicative of the results for the full year or for any future periods. The condensed consolidated balance sheet as of December 31, 2014 is derived from the audited consolidated financial statements for the year ended December 31, 2014.


## ftnt:ScheduleOfAmortizedCostsUnrealizedGainsAndLossesAndFairValueOfAvailableForSaleSecuritiesTableTextBlock

[0001262039-15-000016:notes:4]
The following table summarizes our investments as of March 31, 2015 and December 31, 2014 (in thousands):

[0001262039-15-000016:notes:5]
|  | March 31, 2015 |
|  | AmortizedCost |  | UnrealizedGains |  | UnrealizedLosses |  | FairValue |
| Corporate debt securities | $ | 568,456 |  |  | $ | 593 |  |  | $ | (243 | ) |  | $ | 568,806 |  |
| Commercial paper | 43,758 |  |  | 1 |  |  | (9 | ) |  | 43,750 |  |
| Municipal bonds | 49,825 |  |  | 21 |  |  | (26 | ) |  | 49,820 |  |
| Certificates of deposit and term deposits (1) | 13,080 |  |  | — |  |  | — |  |  | 13,080 |  |
| U.S. government and agency securities | 10,749 |  |  | 8 |  |  | — |  |  | 10,757 |  |
| Total available-for-sale securities | $ | 685,868 |  |  | $ | 623 |  |  | $ | (278 | ) |  | $ | 686,213 |  |

[0001262039-15-000016:notes:6]
|  | December 31, 2014 |
|  | AmortizedCost |  | UnrealizedGains |  | UnrealizedLosses |  | FairValue |
| Corporate debt securities | $ | 589,526 |  |  | $ | 365 |  |  | $ | (875 | ) |  | $ | 589,016 |  |
| Commercial paper | 51,156 |  |  | 3 |  |  | (4 | ) |  | 51,155 |  |
| Municipal bonds | 39,745 |  |  | 15 |  |  | (39 | ) |  | 39,721 |  |
| Certificates of deposit and term deposits (1) | 22,854 |  |  | — |  |  | — |  |  | 22,854 |  |
| U.S. government and agency securities | 5,749 |  |  | 1 |  |  | (6 | ) |  | 5,744 |  |
| Total available-for-sale securities | $ | 709,030 |  |  | $ | 384 |  |  | $ | (924 | ) |  | $ | 708,490 |  |

[0001262039-15-000016:notes:7]
(1) The majority of our certificates of deposit and term deposits are foreign deposits.


## ftnt:ScheduleOfShareBasedPaymentAwardStockOptionsValuationAssumptionsAndAllocationOfRecognizedPeriodCostsTableTextBlock

[0001262039-15-000016:notes:8]
The following table summarizes the weighted-average assumptions relating to our employee stock options:

[0001262039-15-000016:notes:9]
|  | Three Months Ended |
|  | March 31, 2015 |  | March 31, 2014 |
| Expected term in years | 4.3 |  |  | 4.9 |  |
| Volatility | 40 | % |  | 45 | % |
| Risk-free interest rate | 1.5 | % |  | 1.7 | % |
| Dividend rate | — | % |  | — | % |


## ftnt:ScheduleofEmployeeServiceSharebasedCompensationAllocationofRecognizedPeriodCostsbyAwardTypeTableTextBlock

[0001262039-15-000016:notes:10]
The following table summarizes stock-based compensation expense by award type (in thousands):

[0001262039-15-000016:notes:11]
|  | Three Months Ended |
|  | March 31, 2015 |  | March 31, 2014 |
| Stock options | $ | 3,455 |  |  | $ | 4,692 |  |
| RSUs (including PSUs) | 14,292 |  |  | 7,363 |  |
| ESPP | 1,175 |  |  | 875 |  |
| Total stock-based compensation expense | $ | 18,922 |  |  | $ | 12,930 |  |


## ftnt:ScheduleofReceivablesbyMajorCustomersTableTextBlock

[0001262039-15-000016:notes:12]
The following customers, each of which is a distributor, accounted for 10% or more of net accounts receivable:

[0001262039-15-000016:notes:13]
|  | March 31, 2015 |  | December 31, 2014 |
| Exclusive Networks Group | 19 | % |  | 18 | % |
| Fine Tec Computer | 12 | % |  | — | % |


## ftnt:ScheduleofSharebasedCompensationSharesWithheldforTaxesTableTextBlock

[0001262039-15-000016:notes:14]
The following summarizes the number and value of the shares withheld for employee taxes (in thousands):

[0001262039-15-000016:notes:15]
|  | Three Months Ended |
|  | March 31, 2015 |  | March 31, 2014 |
| Shares withheld for taxes | 221 |  |  | 171 |  |
| Amount withheld for taxes | $ | 6,600 |  |  | $ | 3,633 |  |


## ftnt:ScheduleofSharebasedPaymentAwardEmployeeStockPurchasePlanAdditionalInformationTableTextBlock

[0001262039-15-000016:notes:16]
Additional information related to the ESPP is provided below (in thousands, except per share amounts):

[0001262039-15-000016:notes:17]
|  | Three Months Ended |
|  | March 31, 2015 |  | March 31, 2014 |
| Weighted-average fair value per share granted | $ | 7.56 |  |  | $ | 5.76 |  |
| Shares issued under the ESPP | 427 |  |  | 424 |  |
| Weighted-average price per share issued | $ | 21.34 |  |  | $ | 17.18 |  |


## ftnt:ScheduleofSharebasedPaymentAwardEquityInstrumentsOtherthanOptionsValuationAssumptionsTableTextBlock

[0001262039-15-000016:notes:18]
The following table summarizes the weighted-average assumptions relating to our PSUs granted to our executive officers:

[0001262039-15-000016:notes:19]
|  | Three Months Ended |
|  | March 31, 2015 |  | March 31, 2014 |
| Expected term in years | 3.0 |  |  | 3.0 |  |
| Volatility | 38 | % |  | 48 | % |
| Risk-free interest rate | 1.1 | % |  | 0.7 | % |
| Dividend rate | — | % |  | — | % |


## ftnt:ScheduleofSharebasedPaymentAwardStockOptionsAdditionalInformationTableTextBlock

[0001262039-15-000016:notes:20]
Additional information related to our stock options is summarized below (in thousands, except per share amounts):

[0001262039-15-000016:notes:21]
|  | Three Months Ended |
|  | March 31, 2015 |  | March 31, 2014 |
| Weighted-average fair value per share granted | $ | 11.17 |  |  | $ | 8.65 |  |
| Intrinsic value of options exercised | 41,003 |  |  | 15,321 |  |
| Fair value of options vested | 3,792 |  |  | 4,562 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001262039-15-000016:notes:22]
COMMITMENTS AND CONTINGENCIES

[0001262039-15-000016:notes:23]
The following table summarizes our future principal contractual obligations as of March 31, 2015 (in thousands):

[0001262039-15-000016:notes:24]
|  | Total |  | 2015 (remainder) |  | 2016 |  | 2017 |  | 2018 |  | 2019 |  | Thereafter |
| Operating lease commitments | $ | 40,130 |  |  | $ | 9,560 |  |  | $ | 9,453 |  |  | $ | 7,252 |  |  | $ | 6,506 |  |  | $ | 4,567 |  |  | $ | 2,792 |  |
| Less: Sublease rental income | 224 |  |  | 224 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Operating lease commitments—net | 39,906 |  |  | 9,336 |  |  | 9,453 |  |  | 7,252 |  |  | 6,506 |  |  | 4,567 |  |  | 2,792 |  |
| Inventory purchase commitments | 67,715 |  |  | 67,715 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Other contractual commitments and open purchase orders | 28,108 |  |  | 26,020 |  |  | 1,518 |  |  | 570 |  |  | — |  |  | — |  |  | — |  |
| Total | $ | 135,729 |  |  | $ | 103,071 |  |  | $ | 10,971 |  |  | $ | 7,822 |  |  | $ | 6,506 |  |  | $ | 4,567 |  |  | $ | 2,792 |  |

[0001262039-15-000016:notes:25]
Operating Leases—We lease certain facilities under various non-cancelable operating leases, which expire through 2024. In addition to the amounts above, certain leases require us to pay variable costs such as taxes, maintenance, insurance, and asset retirement obligations. The terms of certain operating leases also provide for renewal options and escalation clauses. Rent expense was $3.1 million and $2.7 million during the three months ended March 31, 2015 and 2014, respectively. Rent expense is recognized using the straight-line method over the term of the lease.

[0001262039-15-000016:notes:26]
Contract Manufacturer and Other Commitments—Our independent contract manufacturers procure components and build our products based on our forecasts. These forecasts are based on estimates of future demand for our products, which are in turn based on historical trends and analysis, adjusted for overall market conditions. In order to reduce manufacturing lead times and plan for adequate component supply, we may issue purchase orders to some of our independent contract manufacturers which may not be cancelable. As of March 31, 2015, we had $67.7 million of open purchase orders with our independent contract manufacturers.

[0001262039-15-000016:notes:27]
In addition to commitments with contract manufacturers, we have other contractual commitments and open purchase orders in the ordinary course of business for which we have not received goods or services. As of March 31, 2015, we had $28.1 million in other contractual commitments and open purchase orders.

[0001262039-15-000016:notes:28]
Warranties—Accrued warranty activities are summarized as follows (in thousands):

[0001262039-15-000016:notes:29]
|  | Three Months Ended |
|  | March 31, 2015 |  | March 31, 2014 |
| Accrued warranty balance—beginning of the period | $ | 4,269 |  |  | $ | 3,037 |  |
| Warranty costs incurred | (1,095 | ) |  | (756 | ) |
| Provision for warranty for the period | 945 |  |  | 837 |  |
| Adjustment related to pre-existing warranties | 222 |  |  | (313 | ) |
| Accrued warranty balance—end of the period | $ | 4,341 |  |  | $ | 2,805 |  |

[0001262039-15-000016:notes:30]
Litigation—We are involved in disputes, litigation, and other legal actions. For lawsuits where we are the defendant, we are in the process of defending these litigation matters, and while there can be no assurances and the outcome of these matters is currently not determinable, we currently believe that there are no existing claims or proceedings that are likely to have a material adverse effect on our financial position. There are many uncertainties associated with any litigation and these actions or other third-party claims against us may cause us to incur costly litigation or substantial settlement charges. In addition, the resolution of any intellectual property litigation may require us to make royalty payments, which could adversely affect our gross margins in future periods. If any of those events were to occur, our business, financial condition, results of operations, and cash flows could be adversely affected. The actual liability in any such matters may be materially different from our estimates, if any, which could result in the need to adjust the liability and record additional expenses. We have not recorded any significant accrual for loss contingencies associated with such legal proceedings; determined that an unfavorable outcome is probable or reasonably possible; or determined that the amount or range of any possible loss is reasonably estimable.

[0001262039-15-000016:notes:31]
Indemnification—Under the indemnification provisions of our standard sales contracts, we agree to defend our customers against third-party claims asserting various allegations such as damage resulting from product defects and infringement of certain intellectual property rights, which may include patents, copyrights, trademarks, or trade secrets, and to pay judgments entered on such claims. Our exposure under these indemnification provisions is generally limited by the terms of our contracts to certain defined limits, such as the total amount paid by our customer under the agreement. However, certain agreements include covenants and indemnification provisions including and beyond indemnification for third-party claims of intellectual property infringement and that could potentially expose us to losses in excess of the amount received under the agreement and, in some instances, to potential liability that is not contractually limited. To date, there have been no awards under such indemnification provisions.


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0001262039-15-000016:notes:32]
[same as prior period, unchanged from 0001262039-14-000039:notes:18]

[0001262039-15-000016:notes:33]
Our tax-deferred savings plan under our 401(k) Plan, permits participating employees to defer a portion of their pre-tax earnings. In Canada, we have a Group Registered Retirement Savings Plan program (the “RRSP”) which permits participants to make tax deductible contributions. Our Board approved 50% matching contributions on employee contributions up to 4% of each employee’s eligible earnings. Our matching contributions to the 401(k) Plans and RRSP during the three months ended March 31, 2015 and March 31, 2014 were $0.8 million and $0.6 million, respectively.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001262039-15-000016:notes:34]
ACCUMULATED OTHER COMPREHENSIVE INCOME (LOSS)

[0001262039-15-000016:notes:35]
The following table summarizes the changes in accumulated balances of other comprehensive income (loss) (in thousands):

[0001262039-15-000016:notes:36]
|  | Unrealized Gains (Losses) on Investments |  | Tax benefit (provision) related to items of other comprehensive income (loss) |  | Total |
| Beginning balance as of December 31, 2014 | $ | (540 | ) |  | $ | 191 |  |  | $ | (349 | ) |
| Other comprehensive income before reclassifications | 889 |  |  | (311 | ) |  | 578 |  |
| Amounts reclassified from accumulated other comprehensive income (loss) | (4 | ) |  | 1 |  |  | (3 | ) |
| Net current-period other comprehensive income | 885 |  |  | (310 | ) |  | 575 |  |
| Ending balance as of March 31, 2015 | $ | 345 |  |  | $ | (119 | ) |  | $ | 226 |  |

[0001262039-15-000016:notes:37]
The following table provides details about the reclassification out of accumulated other comprehensive income (loss) (in thousands):

[0001262039-15-000016:notes:38]
| Three Months Ended March 31, 2015 |
| Details about Accumulated Other Comprehensive Income Components |  | Amount Reclassified from Accumulated Other Comprehensive Income |  | Affected Line Item in the Statement Where Net Income is Presented |
| Unrealized gains on investments |  | $ | (4 | ) |  | Other expense—net |
| Tax provision related to items of other comprehensive income |  | 1 |  |  | Provision for income taxes |
| Total reclassification for the period |  | $ | (3 | ) |  |  |


## us-gaap:CostMethodInvestmentsDescriptionTextBlock

[0001262039-15-000016:notes:39]
INVESTMENTS IN PRIVATELY-HELD COMPANIES

[0001262039-15-000016:notes:40]
As of March 31, 2015, we have invested a total of $6.4 million in the equity securities of three privately-held companies. Each of these investments are accounted for as cost-basis investments, as we own less than 20% of the voting securities and do not have the ability to exercise significant influence over operating and financial policies of the respective entities. These investments are carried at historical cost and are recorded as Other assets on our condensed consolidated balance sheets and would be measured at fair value if indicators of impairment exist.

[0001262039-15-000016:notes:41]
During the three months ended March 31, 2015, no events have occurred that would adversely affect the carrying value of these investments.


## us-gaap:DeferredRevenueByArrangementDisclosureTextBlock

[0001262039-15-000016:notes:42]
Deferred revenue consisted of the following as of March 31, 2015 and December 31, 2014 (in thousands):

[0001262039-15-000016:notes:43]
|  | March 31, 2015 |  | December 31, 2014 |
| Product | $ | 4,255 |  |  | $ | 4,642 |  |
| Service | 595,916 |  |  | 554,115 |  |
| Total deferred revenue | $ | 600,171 |  |  | $ | 558,757 |  |
| Reported As: |  |  |  |
| Current | $ | 406,526 |  |  | $ | 368,929 |  |
| Non-current | 193,645 |  |  | 189,828 |  |
| Total deferred revenue | $ | 600,171 |  |  | $ | 558,757 |  |


## us-gaap:DeferredRevenueDisclosureTextBlock

[0001262039-15-000016:notes:44]
[same as prior period, unchanged from 0001262039-14-000039:notes:27]


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001262039-15-000016:notes:45]
[same as prior period, unchanged from 0001262039-14-000039:notes:28]

[0001262039-15-000016:notes:46]
Our sales contracts are primarily denominated in U.S. dollars and therefore substantially all of our revenue is not subject to foreign currency translation risk. However, a substantial portion of our operating expenses incurred outside the U.S. are denominated in foreign currencies and are subject to fluctuations due to changes in foreign currency exchange rates, particularly changes in the Canadian dollar (“CAD”) and the Euro (“EUR”). To help protect against significant fluctuations in value and the volatility of future cash flows caused by changes in currency exchange rates, we engage in foreign currency risk management activities, including forward contracts, to hedge balance sheet items denominated in CAD. We do not use these contracts for speculative or trading purposes. All of the derivative instruments are with high quality financial institutions and we monitor the creditworthiness of these parties. These contracts typically have maturities of one month. We record changes in the fair value of forward exchange contracts related to balance sheet accounts as Other expense—net in the condensed consolidated statement of operations.

[0001262039-15-000016:notes:47]
Additionally, independent of any hedging activities, fluctuations in foreign currency exchange rates may cause us to recognize transaction gains and losses in Other expense—net in our condensed consolidated statements of operations. Our hedging activities are intended to reduce, but not eliminate, the impact of currency exchange rate movements. As our hedging activities are relatively short-term in nature and are focused on CAD, long-term material changes in the value of the U.S. dollar against other foreign currencies, such as the GBP and EUR could adversely impact our operating expenses in the future.

[0001262039-15-000016:notes:48]
The notional amount of forward exchange contracts to hedge balance sheet accounts were (in thousands):

[0001262039-15-000016:notes:49]
|  | Buy/Sell |  | Notional |
| Currency—As of March 31, 2015 |  |  |  |
| CAD | Sell |  | $ | 9,093 |  |
| Currency—As of December 31, 2014 |  |  |  |
| CAD | Buy |  | $ | 6,879 |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001262039-15-000016:notes:50]
[same as prior period, unchanged from 0001262039-14-000039:notes:33]

[0001262039-15-000016:notes:51]
Stock-Based Compensation Plans

[0001262039-15-000016:notes:52]
We have stock-based compensation plans pursuant to which we have granted stock options and RSUs, including PSUs. The Company also has an ESPP for all eligible employees. As of March 31, 2015, there were a total of 44,040,580 shares of common stock available for grant under our stock-based compensation plans.

[0001262039-15-000016:notes:53]
[same as prior period, unchanged from 0001262039-14-000039:notes:34]

[0001262039-15-000016:notes:54]
[same as prior period, unchanged from 0001262039-14-000039:notes:37]

[0001262039-15-000016:notes:55]
|  | Options Outstanding |
|  | Numberof Shares |  | Weighted-AverageExercisePrice |  | Weighted-AverageRemainingContractualLife (Years) |  | AggregateIntrinsicValue |
| Balance—December 31, 2014 | 10,702 |  |  | $ | 14.98 |  |  |  |  |  |
| Granted | 269 |  |  | 32.79 |  |  |  |  |  |
| Forfeited | (73 | ) |  | 24.59 |  |  |  |  |  |
| Exercised | (1,931 | ) |  | 10.49 |  |  |  |  |  |
| Balance—March 31, 2015 | 8,967 |  |  | $ | 16.41 |  |  |  |  |  |
| Options vested and expected to vest—March 31, 2015 | 8,924 |  |  | $ | 16.35 |  |  | 2.8 |  | $ | 165,975 |  |
| Options exercisable—March 31, 2015 | 7,589 |  |  | $ | 14.71 |  |  | 2.4 |  | $ | 153,634 |  |

[0001262039-15-000016:notes:56]
The aggregate intrinsic value represents the pre-tax difference between the exercise price of stock options and the quoted market price of our common stock on March 31, 2015, for all in-the-money options. As of March 31, 2015, total compensation expense related to unvested stock options granted to employees but not yet recognized was $15.6 million, net of estimated forfeitures. This expense is expected to be amortized on a straight-line basis over a weighted-average period of 1.8 years.

[0001262039-15-000016:notes:57]
[same as prior period, unchanged from 0001262039-14-000039:notes:42]

[0001262039-15-000016:notes:58]
[same as prior period, unchanged from 0001262039-14-000039:notes:43]

[0001262039-15-000016:notes:59]
|  | Restricted Stock Units Outstanding |
|  | Number of Shares |  | Weighted-Average Grant-Date-Fair Value per Share |
| Balance—December 31, 2014 | 6,291 |  |  | $ | 22.93 |  |
| Granted | 2,492 |  |  | 32.96 |  |
| Forfeited | (198 | ) |  | 26.36 |  |
| Vested | (670 | ) |  | 22.01 |  |
| Balance—March 31, 2015 | 7,915 |  |  | $ | 26.18 |  |
| RSUs expected to vest—March 31, 2015 | 7,450 |  |  | $ | 26.02 |  |

[0001262039-15-000016:notes:60]
As of March 31, 2015, total compensation expense related to unvested RSUs that were granted to employees and non-employees, but not yet recognized, was $197.8 million, net of estimated forfeitures. This expense is expected to be amortized on a straight-line basis over a weighted-average vesting period of 3.1 years.

[0001262039-15-000016:notes:61]
RSUs settle into shares of common stock upon vesting. Upon the vesting of the RSUs, we net-settle the RSUs and withhold a portion of the shares to satisfy minimum statutory employee withholding taxes. Total payment for the employees’ tax obligations to the taxing authorities is reflected as a financing activity within the condensed consolidated statements of cash flows.

[0001262039-15-000016:notes:62]
Performance Stock Units

[0001262039-15-000016:notes:63]
We have granted PSUs to certain of our executive officers and employees. PSUs granted to executive officers are based on the achievement of the market-based vesting conditions during the performance period, the final settlement of the PSUs will range between 0% and 150% of the target shares underlying the PSUs based on a specified objective formula approved by our Compensation Committee. The PSUs entitle our executive officers to receive a number of shares of our common stock based on the performance of our stock price over a two- or three-year period as compared to the NASDAQ Composite index for the same periods. PSUs granted to certain employees are based on the achievement of personal- and company-based performance vesting conditions during the performance period. The final settlement of these PSUs will range between 50% to 150% of the target shares underlying the PSUs based on specified objective formula approved by our Compensation Committee.  The PSUs entitle the employees to receive a number of shares of our common stock based on a one year performance period, and vest equally in the second and third years.

[0001262039-15-000016:notes:64]
The following table summarizes the activity and related information for PSUs for the periods presented below (in thousands, except per share amounts):

[0001262039-15-000016:notes:65]
|  | Three Months Ended |
|  | March 31, 2015 |  | March 31, 2014 |
| Shares granted to executive officers and employees | 206 |  |  | 25 |  |
| Weighted-average fair value per share granted | $ | 34.86 |  |  | $ | 22.44 |  |

[0001262039-15-000016:notes:66]
As of March 31, 2015, total compensation expense related to unvested PSUs that were granted to certain of our executive officers and employees, but not yet recognized, was $9.5 million, net of estimated forfeitures. This expense is expected to be amortized on a straight-line basis over a weighted-average vesting period of 2.5 years.

[0001262039-15-000016:notes:67]
[same as prior period, unchanged from 0001262039-14-000039:notes:48]

[0001262039-15-000016:notes:68]
[same as prior period, unchanged from 0001262039-14-000039:notes:49]

[0001262039-15-000016:notes:69]
|  | Three Months Ended |
|  | March 31, 2015 |  | March 31, 2014 |
| Expected term in years | 0.5 |  |  | 0.5 |  |
| Volatility | 28 | % |  | 37 | % |
| Risk-free interest rate | 0.1 | % |  | 0.1 | % |
| Dividend rate | — | % |  | — | % |

[0001262039-15-000016:notes:70]
[same as prior period, unchanged from 0001262039-14-000039:notes:53]

[0001262039-15-000016:notes:71]
[same as prior period, unchanged from 0001262039-14-000039:notes:54]

[0001262039-15-000016:notes:72]
|  | Three Months Ended |
|  | March 31, 2015 |  | March 31, 2014 |
| Cost of product revenue | $ | 140 |  |  | $ | 113 |  |
| Cost of service revenue | 1,632 |  |  | 1,329 |  |
| Research and development | 5,157 |  |  | 3,882 |  |
| Sales and marketing | 9,307 |  |  | 5,746 |  |
| General and administrative | 2,686 |  |  | 1,860 |  |
| Total stock-based compensation expense | $ | 18,922 |  |  | $ | 12,930 |  |

[0001262039-15-000016:notes:73]
[same as prior period, unchanged from 0001262039-14-000039:notes:60]

[0001262039-15-000016:notes:74]
In December 2013, our Board of Directors (“Board”) authorized a Share Repurchase Program (“Program”) to repurchase up to $200.0 million of our outstanding common stock through December 31, 2014. Under the Program, share repurchases may be made by us from time to time in privately negotiated transactions or in open market transactions. The Program does not require us to purchase a minimum number of shares, and may be suspended, modified or discontinued at any time without prior notice. In October 2014, our Board extended the share repurchase authorization under the Program through December 31, 2015. During the three months ended March 31, 2015, there were no shares repurchased under the Program. As of March 31, 2015, $122.5 million remains available for future share repurchases under the Program.


## us-gaap:EarningsPerShareTextBlock

[0001262039-15-000016:notes:75]
[same as prior period, unchanged from 0001262039-14-000039:notes:62]

[0001262039-15-000016:notes:76]
Basic net income per share is computed by dividing net income by the weighted-average number of shares of common stock outstanding during the period. Diluted net income per share is computed by dividing net income by the weighted-average number of shares of common stock outstanding, plus the dilutive effects of stock options, restricted stock units (“RSUs”) including performance stock units (“PSUs”), and the employee stock purchase plan (“ESPP”). Dilutive shares of common stock are determined by applying the treasury stock method.

[0001262039-15-000016:notes:77]
[same as prior period, unchanged from 0001262039-14-000039:notes:64]

[0001262039-15-000016:notes:78]
|  | Three Months Ended |
|  | March 31, 2015 |  | March 31, 2014 |
| Numerator: |  |  |  |
| Net income | $ | 1,560 |  |  | $ | 8,393 |  |
| Denominator: |  |  |  |
| Basic shares: |  |  |  |
| Weighted-average common stock outstanding—basic | 168,077 |  |  | 162,391 |  |
| Diluted shares: |  |  |  |
| Weighted-average common stock outstanding—basic | 168,077 |  |  | 162,391 |  |
| Effect of potentially dilutive securities: |  |  |  |
| Stock options | 3,837 |  |  | 5,196 |  |
| RSUs (including PSUs) | 1,741 |  |  | 484 |  |
| ESPP | 65 |  |  | 43 |  |
| Weighted-average shares used to compute diluted net income per share | 173,720 |  |  | 168,114 |  |
| Net income per share: |  |  |  |
| Basic | $ | 0.01 |  |  | $ | 0.05 |  |
| Diluted | $ | 0.01 |  |  | $ | 0.05 |  |

[0001262039-15-000016:notes:79]
The following weighted-average shares of common stock were excluded from the computation of diluted net income per share for the periods presented, as their effect would have been anti-dilutive (in thousands):

[0001262039-15-000016:notes:80]
|  | Three Months Ended |
|  | March 31, 2015 |  | March 31, 2014 |
| Stock options | 249 |  |  | 5,079 |  |
| RSUs (including PSUs) | 1,333 |  |  | 1,348 |  |
| ESPP | 169 |  |  | 358 |  |
|  | 1,751 |  |  | 6,785 |  |


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0001262039-15-000016:notes:81]
[same as prior period, unchanged from 0001262039-14-000039:notes:68]

[0001262039-15-000016:notes:82]
The following table shows the gross unrealized losses and the related fair values of our investments that have been in a continuous unrealized loss position as of March 31, 2015 and December 31, 2014 (in thousands):

[0001262039-15-000016:notes:83]
|  | March 31, 2015 |
|  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
|  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |
| Corporate debt securities | $ | 177,364 |  |  | $ | (214 | ) |  | $ | 13,142 |  |  | $ | (29 | ) |  | $ | 190,506 |  |  | $ | (243 | ) |
| Commercial paper | 8,375 |  |  | (9 | ) |  | — |  |  | — |  |  | 8,375 |  |  | (9 | ) |
| Municipal bonds | 32,205 |  |  | (26 | ) |  | — |  |  | — |  |  | 32,205 |  |  | (26 | ) |
| Total available-for-sale securities | $ | 217,944 |  |  | $ | (249 | ) |  | $ | 13,142 |  |  | $ | (29 | ) |  | $ | 231,086 |  |  | $ | (278 | ) |

[0001262039-15-000016:notes:84]
|  | December 31, 2014 |
|  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
|  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |
| Corporate debt securities | $ | 317,011 |  |  | $ | (858 | ) |  | $ | 6,011 |  |  | $ | (17 | ) |  | $ | 323,022 |  |  | $ | (875 | ) |
| Commercial paper | 8,185 |  |  | (4 | ) |  | — |  |  | — |  |  | 8,185 |  |  | (4 | ) |
| Municipal bonds | 26,684 |  |  | (39 | ) |  | — |  |  | — |  |  | 26,684 |  |  | (39 | ) |
| U.S. government and agency securities | 4,745 |  |  | (6 | ) |  | — |  |  | — |  |  | 4,745 |  |  | (6 | ) |
| Total available-for-sale securities | $ | 356,625 |  |  | $ | (907 | ) |  | $ | 6,011 |  |  | $ | (17 | ) |  | $ | 362,636 |  |  | $ | (924 | ) |

[0001262039-15-000016:notes:85]
The contractual maturities of our investments as of March 31, 2015 and December 31, 2014 were as follows (in thousands):

[0001262039-15-000016:notes:86]
|  | March 31, 2015 |  | December 31, 2014 |
| Due within one year | $ | 417,605 |  |  | $ | 436,766 |  |
| Due within one to three years | 268,608 |  |  | 271,724 |  |
| Total | $ | 686,213 |  |  | $ | 708,490 |  |

[0001262039-15-000016:notes:87]
Available-for-sale securities are reported at fair value, with unrealized gains and losses, net of tax, included as a separate component of stockholders’ equity and in total comprehensive income. Realized gains and losses on available-for-sale securities are included in Other expense—net in our condensed consolidated statements of operations. Realized gains and losses from the sale of available-for-sale securities were not significant in any period presented.

[0001262039-15-000016:notes:88]
The unrealized losses on our available-for-sale securities were caused by fluctuations in market value and interest rates as a result of the economic environment. As the decline in market value is attributable to changes in market conditions and not credit quality, and because we have concluded currently that we neither intend to sell nor is it more likely than not that we will be required to sell these investments prior to a recovery of par value, we do not consider these investments to be other-than temporarily impaired as of March 31, 2015.

[0001262039-15-000016:notes:89]
Fair Value Accounting—We apply the following fair value hierarchy for disclosure of the inputs used to measure fair value. This hierarchy prioritizes the inputs into three broad levels as follows:

[0001262039-15-000016:notes:90]
Level 1—Inputs are unadjusted quoted prices in active markets for identical assets or liabilities.

[0001262039-15-000016:notes:91]
Level 2—Inputs are quoted prices for similar assets and liabilities in active markets or inputs that are observable for the assets or liabilities, either directly or indirectly through market corroboration, for substantially the full term of the financial instruments.

[0001262039-15-000016:notes:92]
Level 3—Unobservable inputs based on our own assumptions used to measure assets and liabilities at fair value. The inputs require significant management judgment or estimation.

[0001262039-15-000016:notes:93]
We measure the fair value of money market funds and certain U.S. government and agency securities using quoted prices in active markets for identical assets. The fair value of all other financial instruments was based on quoted prices for similar assets in active markets, or model driven valuations using significant inputs derived from or corroborated by observable market data.

[0001262039-15-000016:notes:94]
[same as prior period, unchanged from 0001262039-14-000039:notes:84]

[0001262039-15-000016:notes:95]
[same as prior period, unchanged from 0001262039-14-000039:notes:85]

[0001262039-15-000016:notes:96]
[same as prior period, unchanged from 0001262039-14-000039:notes:80]

[0001262039-15-000016:notes:97]
[same as prior period, unchanged from 0001262039-14-000039:notes:81]

[0001262039-15-000016:notes:98]
The following table presents the fair value of our financial assets and liabilities measured at fair value on a recurring basis as of March 31, 2015 and December 31, 2014 (in thousands):

[0001262039-15-000016:notes:99]
|  | March 31, 2015 |  | December 31, 2014 |  |
|  | AggregateFairValue |  | QuotedPrices inActiveMarkets ForIdenticalAssets |  | SignificantOtherObservableRemainingInputs |  | AggregateFairValue |  | QuotedPrices inActiveMarkets ForIdenticalAssets |  | SignificantOtherObservableRemainingInputs |  |
|  |  |  | (Level 1) |  | (Level 2) |  |  |  | (Level 1) |  | (Level 2) |  |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate debt securities | $ | 568,806 |  |  | $ | — |  |  | $ | 568,806 |  |  | $ | 589,016 |  |  | $ | — |  |  | $ | 589,016 |  |  |
| Commercial paper | 43,750 |  |  | — |  |  | 43,750 |  |  | 51,155 |  |  | — |  |  | 51,155 |  |  |
| Municipal bonds | 49,820 |  |  | — |  |  | 49,820 |  |  | 39,721 |  |  | — |  |  | 39,721 |  |  |
| Certificates of deposit and term deposits | 13,080 |  |  | — |  |  | 13,080 |  |  | 22,854 |  |  | — |  |  | 22,854 |  |  |
| Money market funds | 29,154 |  |  | 29,154 |  |  | — |  |  | 13,311 |  |  | 13,311 |  |  | — |  |  |
| U.S. government and agency securities | 10,757 |  |  | 2,001 |  |  | 8,756 |  |  | 5,744 |  |  | 1,998 |  |  | 3,746 |  |  |
| Total | $ | 715,367 |  |  | $ | 31,155 |  |  | $ | 684,212 |  |  | $ | 721,801 |  |  | $ | 15,309 |  |  | $ | 706,492 |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents | $ | 29,154 |  |  |  |  |  |  | $ | 13,311 |  |  |  |  |  |  |
| Short-term investments | 417,605 |  |  |  |  |  |  | 436,766 |  |  |  |  |  |  |
| Long-term investments | 268,608 |  |  |  |  |  |  | 271,724 |  |  |  |  |  |  |
| Total | $ | 715,367 |  |  |  |  |  |  | $ | 721,801 |  |  |  |  |  |  |

[0001262039-15-000016:notes:100]
There were no transfers between Level 1 and Level 2 of the fair value hierarchy during the period ended March 31, 2015.


## us-gaap:ForeignCurrencyTransactionsAndTranslationsPolicyTextBlock

[0001262039-15-000016:notes:101]
In the third quarter of 2014, we reevaluated the selected functional currency of our international subsidiaries due to the nature of our business operations and recorded the cumulative impact of the reevaluation of the functional currency in the consolidated statement of operations. Subsequently, the remeasurement of the assets and liabilities of all international subsidiaries has been recorded in the consolidated statement of operations prospectively. The impact of this reevaluation is not material for our fiscal 2014 or any of our previously issued financial statements.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001262039-15-000016:notes:102]
[same as prior period, unchanged from 0001262039-14-000039:notes:98]

[0001262039-15-000016:notes:103]
The effective tax rate was 5% for the three months ended March 31, 2015, compared to an effective tax rate of 39% for the same period last year. The provision for income taxes for the periods presented is comprised of U.S. federal and state taxes, Singapore and other foreign income taxes, withholding tax, and transfer pricing allocations which impact jurisdictional income taxed at various tax rates. During the three months ended March 31, 2015, discrete items included a higher tax benefit from stock-based compensation expense and foreign exchange impact relating to uncertain tax benefit for developments in international tax that impacted the quarterly effective tax rate.

[0001262039-15-000016:notes:104]
As of March 31, 2015 and December 31, 2014, unrecognized tax benefits were $46.6 million and $44.2 million, respectively. The total amount of $46.6 million in unrecognized tax benefits, if recognized, would favorably impact the effective tax rate.

[0001262039-15-000016:notes:105]
It is our policy to classify accrued interest and penalties related to unrecognized tax benefits in the provision for income taxes. As of March 31, 2015, we had accrued approximately $4.5 million for estimated interest related to uncertain tax positions.

[0001262039-15-000016:notes:106]
We file income tax returns in the U.S. federal jurisdiction, and various U.S. state and foreign jurisdictions. The statute of limitations is open for years that generated state net operating loss carryforwards and after 2009 for state jurisdictions. Additionally, we have foreign net operating losses that have an indefinite life. Generally, we are no longer subject to non-U.S. income tax examinations by tax authorities for tax years prior to 2008. We are no longer subject to examination by U.S federal income tax authorities for tax years prior to 2010.


## us-gaap:InventoryDisclosureTextBlock

[0001262039-15-000016:notes:107]
[same as prior period, unchanged from 0001262039-14-000039:notes:110]

[0001262039-15-000016:notes:108]
Inventory consisted of the following as of March 31, 2015 and December 31, 2014 (in thousands):

[0001262039-15-000016:notes:109]
|  | March 31, 2015 |  | December 31, 2014 |
| Raw materials | $ | 12,077 |  |  | $ | 10,617 |  |
| Finished goods | 59,983 |  |  | 58,860 |  |
| Inventory | $ | 72,060 |  |  | $ | 69,477 |  |

[0001262039-15-000016:notes:110]
Inventory includes finished goods held by distributors where revenue is recognized on a sell-through basis of $1.0 million and $1.2 million as of March 31, 2015 and December 31, 2014, respectively. Inventory also includes materials at contract manufacturers of $4.6 million and $4.8 million as of March 31, 2015 and December 31, 2014, respectively.


## us-gaap:LongLivedAssetsByGeographicAreasTableTextBlock

[0001262039-15-000016:notes:111]
The following table sets forth property and equipment by geographic region as of March 31, 2015 and December 31, 2014 (in thousands):

[0001262039-15-000016:notes:112]
| Property and Equipment—net | March 31, 2015 |  | December 31, 2014 |
| Americas: |  |  |  |
| United States | $ | 49,471 |  |  | $ | 46,116 |  |
| Canada | 6,356 |  |  | 6,054 |  |
| Other Americas | 924 |  |  | 875 |  |
| Total Americas | 56,751 |  |  | 53,045 |  |
| EMEA | 3,723 |  |  | 3,256 |  |
| APAC | 3,013 |  |  | 2,618 |  |
| Total property and equipment—net | $ | 63,487 |  |  | $ | 58,919 |  |


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001262039-15-000016:notes:113]
Recent Accounting Pronouncement

[0001262039-15-000016:notes:114]
In May 2014, the Financial Accounting Standards Board issued Accounting Standards Update No. 2014-09—Revenue from Contracts with Customers (Topic 606) (“ASU 2014-09”) to create a single, joint revenue standard that is consistent across all industries and markets for companies that prepare their financial statements in accordance with GAAP. Under ASU 2014-09, an entity is required to recognize revenue upon the transfer of promised goods or services to customers in an amount that reflects the consideration the entity expects to be entitled to receive in exchange for those goods or services. ASU 2014-09 is effective for us beginning on January 1, 2017. We are currently evaluating the impact of ASU 2014-09 on our consolidated financial statements.


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001262039-15-000016:notes:115]
[same as prior period, unchanged from 0001262039-14-000039:notes:115]

[0001262039-15-000016:notes:116]
Property and equipment—net consisted of the following as of March 31, 2015 and December 31, 2014 (in thousands):

[0001262039-15-000016:notes:117]
|  | March 31, 2015 |  | December 31, 2014 |
| Land | $ | 13,895 |  |  | $ | 13,895 |  |
| Building and building improvements | 20,224 |  |  | 20,166 |  |
| Evaluation units | 34,053 |  |  | 31,474 |  |
| Computer equipment and software | 38,306 |  |  | 31,821 |  |
| Furniture and fixtures | 5,469 |  |  | 5,096 |  |
| Construction-in-progress | 3,157 |  |  | 3,902 |  |
| Leasehold improvements | 8,711 |  |  | 7,998 |  |
| Total property and equipment | 123,815 |  |  | 114,352 |  |
| Less: accumulated depreciation | (60,328 | ) |  | (55,433 | ) |
| Property and equipment—net | $ | 63,487 |  |  | $ | 58,919 |  |

[0001262039-15-000016:notes:118]
Depreciation expense was $6.0 million and $3.9 million during the three months ended March 31, 2015 and March 31, 2014, respectively.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001262039-15-000016:notes:119]
RELATED PARTY TRANSACTIONS

[0001262039-15-000016:notes:120]
The son of one member of our Board is a partner of an outside law firm that we utilize for certain complex litigation matters. Expenses for legal services provided by the law firm related to matters that arose subsequent to the member joining our Board were $1.9 million and $0.3 million for the three months ended March 31, 2015 and March 31, 2014, respectively.  Amounts due and payable to the law firm were $1.7 million and $1.3 million as of March 31, 2015 and December 31, 2014, respectively.


## us-gaap:RevenueFromExternalCustomersByGeographicAreasTableTextBlock

[0001262039-15-000016:notes:121]
Revenue by geographic region is based on the billing address of the customer. The following table sets forth revenue (in thousands):

[0001262039-15-000016:notes:122]
|  | Three Months Ended |
| Revenue | March 31, 2015 |  | March 31, 2014 |
| Americas: |  |  |  |
| United States | $ | 58,501 |  |  | $ | 44,793 |  |
| Other Americas | 33,059 |  |  | 27,639 |  |
| Total Americas | 91,560 |  |  | 72,432 |  |
| Europe, Middle East, and Africa (“EMEA”) | 75,664 |  |  | 56,643 |  |
| Asia Pacific and Japan (“APAC”) | 45,662 |  |  | 39,874 |  |
| Total revenue | $ | 212,886 |  |  | $ | 168,949 |  |


## us-gaap:ScheduleOfRevenueByMajorCustomersByReportingSegmentsTableTextBlock

[0001262039-15-000016:notes:123]
The following customers, each of which is a distributor, accounted for 10% or more of our revenue:

[0001262039-15-000016:notes:124]
|  | Three Months Ended |
|  | March 31, 2015 |  | March 31, 2014 |
| Exclusive Networks Group | 17 | % |  | 14 | % |
| Ingram Micro | — | % |  | 10 | % |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001262039-15-000016:notes:125]
[same as prior period, unchanged from 0001262039-14-000039:notes:129]

[0001262039-15-000016:notes:126]
Operating segments are defined as components of an enterprise about which separate financial information is available that is evaluated regularly by the chief operating decision maker in deciding how to allocate resources and in assessing performance. Our chief operating decision maker is our chief executive officer. Our chief executive officer reviews financial information presented on a consolidated basis, accompanied by information about revenue by geographic region for purposes of allocating resources and evaluating financial performance. We have one business activity, and there are no segment managers who are held accountable for operations, operating results and plans for levels or components below the consolidated unit level. Accordingly, we have determined that we have one operating segment, and therefore, one reportable segment.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001262039-15-000016:notes:127]
[same as prior period, unchanged from 0001262039-14-000039:notes:130]

[0001262039-15-000016:notes:128]
[same as prior period, unchanged from 0001262039-14-000039:notes:132]

[0001262039-15-000016:notes:129]
There have been no material changes to our significant accounting policies as of and for the three months ended March 31, 2015.
