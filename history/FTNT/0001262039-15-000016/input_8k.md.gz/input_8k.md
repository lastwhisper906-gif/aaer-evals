# FTNT 8-K — 0001262039-15-000014 filed 2015-04-20

## item codes, every 8-K on or before 2015-05-01

- 2015-04-20 0001262039-15-000014 — 2.02, 9.01
- 2015-01-28 0001262039-15-000005 — 2.02, 9.01
- 2014-10-22 0001262039-14-000036 — 2.02, 9.01
- 2014-07-23 0001262039-14-000030 — 2.02, 9.01
- 2014-06-24 0001262039-14-000027 — 5.07
- 2014-04-23 0001262039-14-000021 — 2.02, 9.01
- 2014-04-21 0001262039-14-000018 — 5.03, 9.01
- 2014-01-29 0001262039-14-000004 — 2.02, 9.01
- 2013-12-20 0001262039-13-000061 — 5.02, 9.01
- 2013-11-27 0001262039-13-000057 — 5.02, 7.01, 9.01
- 2013-11-12 0001445305-13-002993 — 5.02
- 2013-10-23 0001262039-13-000051 — 2.02, 9.01
- 2013-07-30 0001262039-13-000039 — 2.02, 9.01
- 2013-06-25 0001262039-13-000030 — 5.07
- 2013-04-30 0001262039-13-000023 — 2.02, 9.01
- 2013-04-19 0001262039-13-000020 — 5.02, 9.01
- 2013-04-19 0001262039-13-000018 — 5.02 — amendment of 0001262039-13-000020
- 2013-04-10 0001262039-13-000016 — 2.02, 9.01
- 2013-03-26 0001262039-13-000013 — 5.02
- 2013-01-30 0001262039-13-000005 — 2.02, 9.01
- 2013-01-24 0001262039-13-000002 — 5.02, 9.01
- 2012-10-16 0001262039-12-000048 — 2.02, 9.01
- 2012-10-01 0001262039-12-000045 — 5.02
- 2012-09-26 0001262039-12-000043 — 5.01
- 2012-07-25 0001262039-12-000038 — 2.02, 9.01
- 2012-07-19 0001262039-12-000034 — 5.02
- 2012-06-20 0001193125-12-275869 — 5.07
- 2012-04-27 0001262039-12-000029 — 5.02
- 2012-04-24 0001262039-12-000025 — 2.02, 9.01
- 2012-01-31 0001262039-12-000006 — 2.02, 9.01
- 2012-01-25 0001262039-12-000003 — 5.03
- 2011-10-24 0001262039-11-000036 — 2.02
- 2011-07-19 0001262039-11-000014 — 2.02, 9.01
- 2011-06-27 0001193125-11-174474 — 5.02, 5.07, 9.01
- 2011-04-27 0001193125-11-111938 — 2.02, 9.01
- 2011-01-25 0001193125-11-013914 — 2.02, 9.01
- 2010-10-21 0001193125-10-233676 — 2.02, 9.01
- 2010-09-02 0001193125-10-203099 — 8.01
- 2010-07-22 0001193125-10-163844 — 2.02, 9.01
- 2010-06-24 0001193125-10-146082 — 5.07
- 2010-04-28 0001193125-10-096698 — 2.02, 9.01
- 2010-02-09 0001193125-10-024614 — 8.01
- 2010-01-27 0001193125-10-014292 — 2.02, 9.01
- 2010-01-26 0001193125-10-013031 — 5.02, 9.01

## late-filing notifications on or before 2015-05-01

- none on or before 2015-05-01

## item 2.02 — earnings release, exhibit 99.1

[0001262039-15-000014:8k_2_02:1]
EX-99.1
2
ftntq1-2015ex991.htm
PRESS RELEASE

[0001262039-15-000014:8k_2_02:2]
FTNT Q1-2015 EX 99.1

[0001262039-15-000014:8k_2_02:3]
Press Release

[0001262039-15-000014:8k_2_02:4]
| Investor Contact: |  | Media Contact: |
| Michelle Spolver |  | Andrea Cousens |
| Fortinet, Inc. |  | Fortinet, Inc. |
| 408-486-7837 |  | 310-270-8903 |
| mspolver@fortinet.com |  | acousens@fortinet.com |

[0001262039-15-000014:8k_2_02:5]
Fortinet Reports Strong First Quarter 2015 Financial Results

[0001262039-15-000014:8k_2_02:6]
Investment Strategy Continues to Pay Off: Billings growth of 36% year over year is highest in history as a public company

[0001262039-15-000014:8k_2_02:7]
•Billings of $254.3 million, up 36% year over year1

[0001262039-15-000014:8k_2_02:8]
•Revenues of $212.9 million, up 26% year over year

[0001262039-15-000014:8k_2_02:9]
•Non-GAAP diluted net income per share of $0.081

[0001262039-15-000014:8k_2_02:10]
•Cash flow from operations of $64.6 million

[0001262039-15-000014:8k_2_02:11]
•Free cash flow of $59.7 million1

[0001262039-15-000014:8k_2_02:12]
| • | Cash, cash equivalents and investments of $1.07 billion |

[0001262039-15-000014:8k_2_02:13]
| • | Deferred revenue of $600.2 million, up 33% year over year |

[0001262039-15-000014:8k_2_02:14]
SUNNYVALE, Calif. - April 20, 2015 - Fortinet® (NASDAQ: FTNT), a global leader in high performance cyber security solutions, today announced financial results for the first quarter ended March 31, 2015.

[0001262039-15-000014:8k_2_02:15]
“Fortinet had an exceptionally strong first quarter that reflects our ability to continue to execute in a strong security market and once again exceed our expectations across all key metrics,” said Ken Xie, founder, chairman and chief executive officer.  “Our first quarter billings growth was the highest since becoming a public company over five years ago and is further evidence that our investment strategy is paying off. During the first quarter, we grew the number of large deals closed against competitors and added over 8,000 customers to our base of more than 200,000, which already include most of the Fortune Global 100.  Looking forward, we feel Fortinet's scale is starting to provide more of a competitive differentiator on multiple fronts, and helps us provide the best solution to our customers. And Fortinet remains well positioned to maintain momentum and grow market share globally given our best-in-class integrated end-to-end network security platform, which provides superior protection against advanced cyber threats.”

[0001262039-15-000014:8k_2_02:16]
Financial Highlights for the First Quarter of 2015

[0001262039-15-000014:8k_2_02:17]
| • | Billings1: Total billings were $254.3 million for the first quarter of 2015, an increase of 36% compared to $187.6 million in the same quarter of 2014. |

[0001262039-15-000014:8k_2_02:18]
| • | Revenue: Total revenue was $212.9 million for the first quarter of 2015, an increase of 26% compared to $168.9 million in the same quarter of 2014. Within total revenue, product revenue was $97.5 million, an increase of 27% compared to the same quarter of 2014. Services and other revenue was $115.4 million, an increase of 25% compared to the same quarter of 2014. |

[0001262039-15-000014:8k_2_02:19]
| • | Deferred Revenue: Total deferred revenue was $600.2 million as of March 31, 2015, an increase of $41.4 million from $558.8 million as of December 31, 2014. |

[0001262039-15-000014:8k_2_02:20]
| • | Cash and Cash Flow2: As of March 31, 2015, cash, cash equivalents and investments were $1.07 billion, compared to $991.7 million as of December 31, 2014. In the first quarter of 2015, cash flow from operations was $64.6 million and free cash flow1 was $59.7 million. |

[0001262039-15-000014:8k_2_02:21]
| • | GAAP Operating Income: GAAP operating income was $0.9 million for the first quarter of 2015, representing a GAAP operating margin of 0.4%. GAAP operating income was $12.8 million for the same quarter of 2014, representing a GAAP operating margin of 8%. |

[0001262039-15-000014:8k_2_02:22]
| • | GAAP Net Income and Diluted Net Income Per Share: GAAP net income was $1.6 million for the first quarter of 2015, compared to GAAP net income of $8.4 million for the same quarter of 2014. GAAP diluted net income per share was $0.01 for the first quarter of 2015, compared to $0.05 for the same quarter of 2014. |

[0001262039-15-000014:8k_2_02:23]
| • | Non-GAAP Operating Income1: Non-GAAP operating income was $20.1 million for the first quarter of 2015, representing a non-GAAP operating margin of 9%. Non-GAAP operating income was $26.3 million for the same quarter of 2014, representing a non-GAAP operating margin of 16%. |

[0001262039-15-000014:8k_2_02:24]
| • | Non-GAAP Net Income and Diluted Net Income Per Share1: Non-GAAP net income was $13.5 million for the first quarter of 2015, compared to non-GAAP net income of $18.2 million for the same quarter of 2014. Non-GAAP diluted net income per share was $0.08 for the first quarter of 2015, compared to $0.11 for the same quarter of 2014. |

[0001262039-15-000014:8k_2_02:25]
1 A reconciliation of GAAP to non-GAAP financial measures has been provided in the financial statement tables included in this press release. An explanation of these measures is also included below under the heading “Non-GAAP Financial Measures.”

[0001262039-15-000014:8k_2_02:26]
2 During the first quarter of 2015, there were no shares repurchased under our share repurchase program.

[0001262039-15-000014:8k_2_02:27]
Conference Call Details

[0001262039-15-000014:8k_2_02:28]
Fortinet will host a conference call today, April 20, 2015, at 1:30 p.m. Pacific Time (4:30 p.m. Eastern Time) to discuss its financial results. To access this call, dial (877) 303-6913 (domestic) or (224) 357-2188 (international) with conference ID # 22278922. A live webcast of the conference call and supplemental slides will be accessible from the Investor Relations page of Fortinet's website at http://investor.fortinet.com and a replay will be archived and accessible at http://investor.fortinet.com/events.cfm.  A replay of this conference call can also be accessed through April 27, 2015, by dialing (855) 859-2056 (domestic) or (404) 537-3406 (international) with conference ID# 22278922.

[0001262039-15-000014:8k_2_02:29]
Following Fortinet's financial results conference call, the Company will host an additional question-and-answer session at 3:30 p.m. Pacific Time (6:30 p.m. Eastern Time) to provide an

[0001262039-15-000014:8k_2_02:30]
opportunity for financial analysts and investors to ask more detailed product and financial questions. To access this call, dial (877) 303-6913 (domestic) or (224) 357-2188 (international) with conference ID # 22281145. This follow-up call will be webcast live and accessible at http://investor.fortinet.com, and a replay will be archived and available after the call at http://investor.fortinet.com/events.cfm. A replay of this conference call will also be available through April 27, 2015 by dialing (855) 859-2056 (domestic) or (404) 537-3406 (international) with conference ID # 22281145.

[0001262039-15-000014:8k_2_02:31]
About Fortinet (www.fortinet.com)

[0001262039-15-000014:8k_2_02:32]
Fortinet (NASDAQ: FTNT) protects the most valuable assets of some of the largest enterprise, service provider and government organizations across the globe. The company’s fast, secure and global cyber security solutions provide broad, high-performance protection against dynamic security threats while simplifying the IT infrastructure. They are strengthened by the industry’s highest level of threat research, intelligence and analytics. Unlike pure-play network security providers, Fortinet can solve organizations’ most important security challenges, whether in networked, application or mobile environments - be it virtualized/cloud or physical. More than 200,000 customers worldwide, including some of the largest and most complex organizations, trust Fortinet to protect their brands. Learn more at www.fortinet.com, the Fortinet Blog or FortiGuard Labs.

[0001262039-15-000014:8k_2_02:33]
#          #          #

[0001262039-15-000014:8k_2_02:34]
Copyright © 2015 Fortinet, Inc. All rights reserved. The symbols ® and ™ denote respectively federally registered trademarks and unregistered trademarks of Fortinet, Inc., its subsidiaries and affiliates. Fortinet's trademarks include, but are not limited to, the following: Fortinet, FortiGate, FortiGuard, FortiManager, FortiMail, FortiClient, FortiCare, FortiAnalyzer, FortiReporter, FortiOS, FortiASIC, FortiWiFi, FortiSwitch, FortiVoIP, FortiBIOS, FortiLog, FortiResponse, FortiCarrier, FortiScan, FortiAP, FortiDB, FortiVoice and FortiWeb. Other trademarks belong to their respective owners.

[0001262039-15-000014:8k_2_02:35]
FTNT-F

[0001262039-15-000014:8k_2_02:36]
Forward-looking Statements

[0001262039-15-000014:8k_2_02:37]
This press release contains forward-looking statements that involve risks and uncertainties. These forward-looking statements include statements regarding the momentum in our business, potential growth of our business, market share gains and product performance. Although we attempt to be accurate in making forward-looking statements, it is possible that future circumstances might differ from the assumptions on which such statements are based. Important factors that could cause results to differ materially from the statements herein include the following: general economic risks; increasing competitiveness in the security market; the dynamic nature of the security market; specific economic risks in different geographies, and among different customer segments; changes in foreign currency exchange rates; uncertainty regarding increased business and renewals from existing customers; uncertainties around continued success in sales growth and market share gains; failure to convert sales pipeline into final sales; risks associated with successful implementation of multiple integrated software products and other product functionality risks; execution risks around new product development and introductions and innovation; product defects; litigation and disputes and the potential cost, distraction and damage to sales and reputation caused thereby; market acceptance of new products and services; the ability to attract and retain personnel; changes in strategy; risks associated with management of growth; lengthy sales and implementation cycles, particularly in larger organizations; technological changes that make our products and services less competitive; risks associated with the adoption of, and demand for, our model in general and by

[0001262039-15-000014:8k_2_02:38]
Non-GAAP Financial Measures

[0001262039-15-000014:8k_2_02:39]
We have provided in this release financial information that has not been prepared in accordance with Generally Accepted Accounting Principles (GAAP). These non-GAAP financial measures are not based on any standardized methodology prescribed by GAAP and are not necessarily comparable to similar measures presented by other companies. We use these non-GAAP financial measures internally in analyzing our financial results and believe they are useful to investors, as a supplement to GAAP measures, in evaluating our ongoing operational performance. We believe that the use of these non-GAAP financial measures provides an additional tool for investors to use in evaluating ongoing operating results and trends and in comparing our financial results with other companies in our industry, many of which present similar non-GAAP financial measures to investors.

[0001262039-15-000014:8k_2_02:40]
Non-GAAP financial measures should not be considered in isolation from, or as a substitute for, financial information prepared in accordance with GAAP. Investors are encouraged to review the reconciliation of these non-GAAP financial measures to their most directly comparable GAAP financial measures below. As previously mentioned, a reconciliation of our non-GAAP financial measures to their most directly comparable GAAP measures has been provided in the financial statement tables included below in this press release.

[0001262039-15-000014:8k_2_02:41]
Billings. We define billings as revenue recognized plus the change in deferred revenue from the beginning to the end of the period less any deferred revenue balances acquired from business combination(s) during the period. We consider billings to be a useful metric for management and investors because billings drive deferred revenue, which is an important indicator of the health and visibility of our business, and historically the recognition of previously deferred revenue represents a majority of the quarterly revenue that we recognize. There are a number of limitations related to the use of billings versus revenue calculated in accordance with GAAP. First, billings include amounts that have not yet been recognized as revenue. Second, we may calculate billings in a manner that is different from peer companies that report similar financial measures. Management compensates for these limitations by providing specific information regarding GAAP revenue and evaluating billings together with revenues calculated in accordance with GAAP.

[0001262039-15-000014:8k_2_02:42]
Free cash flow. We define free cash flow as net cash provided by operating activities minus capital expenditures. We consider free cash flow to be a liquidity measure that provides useful information to management and investors about the amount of cash generated by the business that, after the acquisition of property and equipment, can be used for strategic opportunities, including investing in our business, making strategic acquisitions, repurchasing outstanding common stock, and strengthening the balance sheet. Analysis of free cash flow facilitates management's comparisons of our operating results to competitors' operating results. A limitation of using free cash flow versus the GAAP measure of net cash provided by operating activities as a means for evaluating liquidity is that free cash flow does not represent the total increase or decrease in the cash, cash equivalents and investments balance for the period because free cash flow excludes cash used for capital expenditures and also excludes cash provided by or used for other investing and financing activities. Management compensates for

[0001262039-15-000014:8k_2_02:43]
this limitation by providing information about our capital expenditures and other investing and financing activities on the face of the cash flow statement and under the caption “Management's Discussion and Analysis of Financial Condition and Results of Operations - Liquidity and Capital Resources” in our most recent Quarterly Report on Form 10-Q and Annual Report on Form 10-K.

[0001262039-15-000014:8k_2_02:44]
Non-GAAP operating income and operating margin. We define non-GAAP operating income as operating income plus stock-based compensation expense, acquisition-related charges, including amortization, impairments and other purchase accounting adjustments, and, when applicable, any other significant non-recurring items in a given quarter. Non-GAAP operating margin is defined as non-GAAP operating income divided by revenue. We consider these non-GAAP financial measures to be useful metrics for management and investors because they exclude the effect of stock-based compensation expense, acquisition-related charges, including amortization, impairments and other purchase accounting adjustments, and, when applicable, any other significant non-recurring items  so that our management and investors can compare our recurring core business operating results over multiple periods. There are a number of limitations related to the use of non-GAAP operating income versus operating income calculated in accordance with GAAP. First, non-GAAP operating income excludes stock-based compensation expense and acquisition-related charges and any other significant non-recurring items. Stock-based compensation expense has been and will continue to be, for the foreseeable future, a significant recurring expense in our business. Second, stock-based compensation expense is an important part of our employees' compensation and impacts their performance. Third, the components of the costs that we exclude in our calculation of non-GAAP operating income may differ from the components that other companies exclude when they report their non-GAAP results of operations. Management compensates for these limitations by providing specific information regarding the GAAP amounts excluded from non-GAAP operating income and evaluating non-GAAP operating income together with operating income calculated in accordance with GAAP.

[0001262039-15-000014:8k_2_02:45]
Non-GAAP net income and diluted net income per share. We define non-GAAP net income as net income plus stock-based compensation expense, acquisition-related charges, including amortization, impairments and other purchase accounting adjustments, and, when applicable, any other significant non-recurring items, adjusted for the impact of the tax adjustment, if any, required to achieve the effective tax rate on a non-GAAP basis, which could differ from the GAAP effective tax rate. We define non-GAAP diluted net income per share as non-GAAP net income divided by the weighted-average diluted shares outstanding. We consider these non-GAAP financial measures to be useful metrics for management and investors for the same reasons that we use non-GAAP operating income and non-GAAP operating margin. However, in order to provide a complete picture of our recurring core business operating results, we include in non-GAAP net income and non-GAAP diluted net income per share, the tax adjustment required to achieve the effective tax rate on a non-GAAP basis, which could differ from the GAAP tax rate. We believe the effective tax rates we used are reasonable estimates of normalized tax rates for our current and prior fiscal years under our global operating structure. The same limitations described above regarding our use of non-GAAP operating income and non-GAAP operating margin apply to our use of non-GAAP net income and non-GAAP diluted net income per share. We compensate for these limitations by providing specific information regarding the GAAP amounts excluded from non-GAAP net income and non-GAAP diluted net income per share and evaluating non-GAAP net income and non-GAAP diluted net income per share together with net income and diluted net income per share calculated in accordance with GAAP.

[0001262039-15-000014:8k_2_02:46]
FORTINET, INC.

[0001262039-15-000014:8k_2_02:47]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001262039-15-000014:8k_2_02:48]
(Unaudited, in thousands)

[0001262039-15-000014:8k_2_02:49]
|  | March 31, 2015 |  | December 31, 2014 |
| ASSETS |  |  |  |
| CURRENT ASSETS: |  |  |  |
| Cash and cash equivalents | $ | 386,352 |  |  | $ | 283,254 |  |
| Short-term investments | 417,605 |  |  | 436,766 |  |
| Accounts receivable—Net | 161,854 |  |  | 184,741 |  |
| Inventory | 72,060 |  |  | 69,477 |  |
| Deferred tax assets | 41,175 |  |  | 41,484 |  |
| Prepaid expenses and other current assets | 32,757 |  |  | 31,143 |  |
| Total current assets | 1,111,803 |  |  | 1,046,865 |  |
| LONG-TERM INVESTMENTS | 268,608 |  |  | 271,724 |  |
| PROPERTY AND EQUIPMENT—Net | 63,487 |  |  | 58,919 |  |
| DEFERRED TAX ASSETS | 38,998 |  |  | 31,080 |  |
| GOODWILL | 2,824 |  |  | 2,824 |  |
| OTHER INTANGIBLE ASSETS—Net | 2,559 |  |  | 2,832 |  |
| OTHER ASSETS | 10,024 |  |  | 10,530 |  |
| TOTAL ASSETS | $ | 1,498,303 |  |  | $ | 1,424,774 |  |
| LIABILITIES AND STOCKHOLDERS' EQUITY |  |  |  |
| CURRENT LIABILITIES: |  |  |  |
| Accounts payable | $ | 40,164 |  |  | $ | 49,947 |  |
| Accrued liabilities | 25,873 |  |  | 29,016 |  |
| Accrued payroll and compensation | 42,727 |  |  | 45,875 |  |
| Income taxes payable | 3,343 |  |  | 2,689 |  |
| Deferred revenue | 406,526 |  |  | 368,929 |  |
| Total current liabilities | 518,633 |  |  | 496,456 |  |
| DEFERRED REVENUE | 193,645 |  |  | 189,828 |  |
| INCOME TAXES PAYABLE | 50,280 |  |  | 45,139 |  |
| OTHER LIABILITIES | 15,998 |  |  | 17,385 |  |
| Total liabilities | 778,556 |  |  | 748,808 |  |
| STOCKHOLDERS' EQUITY: |  |  |  |
| Common stock | 169 |  |  | 166 |  |
| Additional paid-in capital | 604,147 |  |  | 562,504 |  |
| Accumulated other comprehensive income (loss) | 226 |  |  | (349 | ) |
| Retained earnings | 115,205 |  |  | 113,645 |  |
| Total stockholders’ equity | 719,747 |  |  | 675,966 |  |
| TOTAL LIABILITIES AND STOCKHOLDERS’ EQUITY | $ | 1,498,303 |  |  | $ | 1,424,774 |  |

[0001262039-15-000014:8k_2_02:50]
FORTINET, INC.

[0001262039-15-000014:8k_2_02:51]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001262039-15-000014:8k_2_02:52]
(Unaudited, in thousands, except per share amounts)

[0001262039-15-000014:8k_2_02:53]
|  | Three Months Ended |
|  | March 31, 2015 |  | March 31, 2014 |
| REVENUE: |  |  |  |
| Product | $ | 97,509 |  |  | $ | 76,765 |  |
| Services and other | 115,377 |  |  | 92,184 |  |
| Total revenue | 212,886 |  |  | 168,949 |  |
| COST OF REVENUE: |  |  |  |
| Product 1 | 41,368 |  |  | 32,139 |  |
| Services and other 1 | 22,234 |  |  | 18,604 |  |
| Total cost of revenue | 63,602 |  |  | 50,743 |  |
| GROSS PROFIT: |  |  |  |
| Product | 56,141 |  |  | 44,626 |  |
| Services and other | 93,143 |  |  | 73,580 |  |
| Total gross profit | 149,284 |  |  | 118,206 |  |
| OPERATING EXPENSES: |  |  |  |
| Research and development 1 | 35,816 |  |  | 29,055 |  |
| Sales and marketing 1 | 100,609 |  |  | 67,326 |  |
| General and administrative 1 | 11,961 |  |  | 9,010 |  |
| Total operating expenses | 148,386 |  |  | 105,391 |  |
| OPERATING INCOME | 898 |  |  | 12,815 |  |
| INTEREST INCOME | 1,422 |  |  | 1,333 |  |
| OTHER EXPENSE—Net | (677 | ) |  | (389 | ) |
| INCOME BEFORE INCOME TAXES | 1,643 |  |  | 13,759 |  |
| PROVISION FOR INCOME TAXES | 83 |  |  | 5,366 |  |
| NET INCOME | $ | 1,560 |  |  | $ | 8,393 |  |
| Net income per share: |  |  |  |
| Basic | $ | 0.01 |  |  | $ | 0.05 |  |
| Diluted | $ | 0.01 |  |  | $ | 0.05 |  |
| Weighted-average shares outstanding: |  |  |  |
| Basic | 168,077 |  |  | 162,391 |  |
| Diluted | 173,720 |  |  | 168,114 |  |
| 1 Includes stock-based compensation expense as follows: |  |  |  |
| Cost of product revenue | $ | 140 |  |  | $ | 113 |  |
| Cost of services and other revenue | 1,632 |  |  | 1,329 |  |
| Research and development | 5,157 |  |  | 3,882 |  |
| Sales and marketing | 9,307 |  |  | 5,746 |  |
| General and administrative | 2,686 |  |  | 1,860 |  |
|  | $ | 18,922 |  |  | $ | 12,930 |  |

[0001262039-15-000014:8k_2_02:54]
FORTINET, INC.

[0001262039-15-000014:8k_2_02:55]
CONDENSED CONSOLIDATED STATEMENTS OF COMPREHENSIVE INCOME

[0001262039-15-000014:8k_2_02:56]
(Unaudited, in thousands)

[0001262039-15-000014:8k_2_02:57]
|  | Three Months Ended |
|  | March 31, 2015 |  | March 31, 2014 |
| Net income | $ | 1,560 |  |  | $ | 8,393 |  |
| Other comprehensive income (loss)—net of taxes: |  |  |  |
| Foreign currency translation losses | — |  |  | (1,017 | ) |
| Unrealized gains on investments | 885 |  |  | 2 |  |
| Tax provision related to items of other comprehensive income | (310 | ) |  | — |  |
| Other comprehensive income (loss)—net of taxes | 575 |  |  | (1,015 | ) |
| Comprehensive income | $ | 2,135 |  |  | $ | 7,378 |  |

[0001262039-15-000014:8k_2_02:58]
FORTINET, INC.

[0001262039-15-000014:8k_2_02:59]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001262039-15-000014:8k_2_02:60]
(Unaudited, in thousands)

[0001262039-15-000014:8k_2_02:61]
|  | Three Months Ended |
|  | March 31, 2015 |  | March 31, 2014 |
| CASH FLOWS FROM OPERATING ACTIVITIES: |  |  |  |
| Net income | $ | 1,560 |  |  | $ | 8,393 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |
| Depreciation and amortization | 6,353 |  |  | 4,422 |  |
| Amortization of investment premiums | 1,938 |  |  | 2,513 |  |
| Stock-based compensation | 18,880 |  |  | 12,930 |  |
| Excess tax benefit from stock-based compensation | — |  |  | (579 | ) |
| Other non-cash items—net | 159 |  |  | (67 | ) |
| Changes in operating assets and liabilities: |  |  |  |
| Accounts receivable—Net | 23,621 |  |  | 19,119 |  |
| Inventory | (6,296 | ) |  | 3,326 |  |
| Deferred tax assets | (7,918 | ) |  | 24 |  |
| Prepaid expenses and other current assets | (1,203 | ) |  | (287 | ) |
| Other assets | 507 |  |  | 45 |  |
| Accounts payable | (11,305 | ) |  | (6,042 | ) |
| Accrued liabilities | (3,450 | ) |  | (170 | ) |
| Other liabilities | (1,569 | ) |  | 16,155 |  |
| Accrued payroll and compensation | (3,149 | ) |  | 1,071 |  |
| Deferred revenue | 40,696 |  |  | 18,469 |  |
| Income taxes payable | 5,795 |  |  | (18,420 | ) |
| Net cash provided by operating activities | 64,619 |  |  | 60,902 |  |
| CASH FLOWS FROM INVESTING ACTIVITIES: |  |  |  |
| Purchases of investments | (120,991 | ) |  | (120,590 | ) |
| Sales of investments | 6,679 |  |  | 10,920 |  |
| Maturities of investments | 135,363 |  |  | 118,641 |  |
| Purchases of property and equipment | (4,927 | ) |  | (11,318 | ) |
| Payments made in connection with business acquisitions—net of cash acquired | — |  |  | (17 | ) |
| Net cash provided by (used in) investing activities | 16,124 |  |  | (2,364 | ) |
| CASH FLOWS FROM FINANCING ACTIVITIES: |  |  |  |
| Proceeds from issuance of common stock | 28,955 |  |  | 14,471 |  |
| Taxes paid related to net share settlement of equity awards | (6,600 | ) |  | (3,633 | ) |
| Excess tax benefit from stock-based compensation | — |  |  | 579 |  |
| Repurchase and retirement of common stock | — |  |  | (12,305 | ) |
| Net cash provided by (used in) financing activities | 22,355 |  |  | (888 | ) |
| EFFECT OF EXCHANGE RATES ON CASH AND CASH EQUIVALENTS | — |  |  | (555 | ) |
| NET INCREASE IN CASH AND CASH EQUIVALENTS | 103,098 |  |  | 57,095 |  |
| CASH AND CASH EQUIVALENTS—Beginning of period | 283,254 |  |  | 115,873 |  |
| CASH AND CASH EQUIVALENTS—End of period | $ | 386,352 |  |  | $ | 172,968 |  |

[0001262039-15-000014:8k_2_02:62]
Reconciliations of non-GAAP results of operations measures to the nearest comparable GAAP measures

[0001262039-15-000014:8k_2_02:63]
(Unaudited, in thousands)

[0001262039-15-000014:8k_2_02:64]
Reconciliation of GAAP revenue to billings

[0001262039-15-000014:8k_2_02:65]
|  | Three Months Ended |
|  | March 31, 2015 |  | March 31, 2014 |
| Total revenue | $ | 212,886 |  |  | $ | 168,949 |  |
| Add increase in deferred revenue | 41,414 |  |  | 18,675 |  |
| Total billings (Non-GAAP) | $ | 254,300 |  |  | $ | 187,624 |  |

[0001262039-15-000014:8k_2_02:66]
Reconciliation of net cash provided by operating activities to free cash flow

[0001262039-15-000014:8k_2_02:67]
|  | Three Months Ended |
|  | March 31, 2015 |  | March 31, 2014 |
| Net cash provided by operating activities | $ | 64,619 |  |  | $ | 60,902 |  |
| Less purchases of property and equipment | (4,927 | ) |  | (11,318 | ) |
| Free cash flow (Non-GAAP) | $ | 59,692 |  |  | $ | 49,584 |  |

[0001262039-15-000014:8k_2_02:68]
Reconciliation of non-GAAP results of operations to the nearest comparable GAAP measures

[0001262039-15-000014:8k_2_02:69]
(Unaudited, in thousands, except per share amounts)

[0001262039-15-000014:8k_2_02:70]
Reconciliation of GAAP to Non-GAAP operating income, operating margin, net income and diluted net income per share

[0001262039-15-000014:8k_2_02:71]
|  | Three Months Ended March 31, 2015 |  | Three Months Ended March 31, 2014 |
|  | GAAP Results |  | Adjustments |  | Non-GAAP Results |  | GAAP Results |  | Adjustments |  | Non-GAAP Results |
| Operating income | $ | 898 |  |  | $ | 19,166 |  | (a) | $ | 20,064 |  |  | $ | 12,815 |  |  | $ | 13,441 |  | (b) | $ | 26,256 |  |
| Operating margin | 0.4 | % |  |  |  | 9 | % |  | 8 | % |  |  |  | 16 | % |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation expense |  |  | 18,922 |  |  |  |  |  |  | 12,930 |  |  |  |
| Amortization expense of certain intangible assets |  |  | 244 |  |  |  |  |  |  | 511 |  |  |  |
| Tax adjustment |  |  | (7,200 | ) | (c) |  |  |  |  | (3,610 | ) | (c) |  |
| Net income | $ | 1,560 |  |  | $ | 11,966 |  |  | $ | 13,526 |  |  | $ | 8,393 |  |  | $ | 9,831 |  |  | $ | 18,224 |  |
| Diluted net income per share | $ | 0.01 |  |  |  |  | $ | 0.08 |  |  | $ | 0.05 |  |  |  |  | $ | 0.11 |  |
| Shares used in diluted net income per share calculations | 173,720 |  |  |  |  | 173,720 |  |  | 168,114 |  |  |  |  | 168,114 |  |

[0001262039-15-000014:8k_2_02:72]
(a) To exclude $18.9 million of stock-based compensation expense and $0.2 million of amortization expense of certain intangible assets in the three months ended March 31, 2015.

[0001262039-15-000014:8k_2_02:73]
(b) To exclude $12.9 million of stock-based compensation expense and $0.5 million of amortization expense of certain intangible assets in the three months ended March 31, 2014.

[0001262039-15-000014:8k_2_02:74]
(c)  Non-GAAP financial information is adjusted to achieve an overall 35 and 33 percent effective tax rate on a non-GAAP basis in the three months ended March 31, 2015 and 2014, respectively.
