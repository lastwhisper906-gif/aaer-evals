# FTNT note change history — 0001262039-20-000067 → 0001262039-21-000014


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2021-05-03):
[0001262039-21-000014:note_history:1]
COMMITMENTS AND CONTINGENCIES
The following table summarizes our inventory purchase commitments as of March 31, 2021 (in millions):
  (was, 2020-11-06, similarity 0.9609):
[0001262039-20-000067:note_history:1]
COMMITMENTS AND CONTINGENCIES
The following table summarizes our inventory purchase commitments as of September 30, 2020 (in millions):

- changed (2021-05-03):
[0001262039-21-000014:note_history:2]
Inventory Purchase Commitments—Our independent contract manufacturers procure components and build our products based on our forecasts. These forecasts are based on estimates of future demand for our products, which are in turn based on historical trends and an analysis from our sales and marketing organizations, adjusted for overall market conditions. In order to reduce manufacturing lead times and plan for adequate component supply, we may issue purchase orders to some of our independent contract manufacturers, which may not be cancelable. As of March 31, 2021, we had $298.8 million of open purchase orders with our independent contract manufacturers that may not be cancelable.
  (was, 2020-11-06, similarity 0.9897):
[0001262039-20-000067:note_history:2]
Inventory Purchase Commitments—Our independent contract manufacturers procure components and build our products based on our forecasts. These forecasts are based on estimates of future demand for our products, which are in turn based on historical trends and an analysis from our sales and marketing organizations, adjusted for overall market conditions. In order to reduce manufacturing lead times and plan for adequate component supply, we may issue purchase orders to some of our independent contract manufacturers, which may not be cancelable. As of September 30, 2020, we had $284.7 million of open purchase orders with our independent contract manufacturers that may not be cancelable.

- changed (2021-05-03):
[0001262039-21-000014:note_history:3]
Other Contractual Commitments and Open Purchase Orders—In addition to commitments with contract manufacturers, we have open purchase orders and contractual obligations in the ordinary course of business for which we have not received goods or services. As of March 31, 2021, we had $65.1 million in other contractual commitments having a remaining term in excess of one year that may not be cancelable.
  (was, 2020-11-06, similarity 0.9823):
[0001262039-20-000067:note_history:3]
Other Contractual Commitments and Open Purchase Orders—In addition to commitments with contract manufacturers, we have open purchase orders and contractual obligations in the ordinary course of business for which we have not received goods or services. As of September 30, 2020, we had $23.1 million in other contractual commitments having a remaining term in excess of one year that may not be cancelable.

- changed (2021-05-03):
[0001262039-21-000014:note_history:4]
Litigation—We are involved in disputes, litigation, and other legal actions. For lawsuits where we are the defendant, we are in the process of defending these litigation matters, and while there can be no assurances and the outcome of certain of these matters is currently not determinable and not predictable, we currently are unaware of any existing claims or proceedings that we believe are likely to have a material adverse effect on our financial position. There are many uncertainties associated with any litigation and these actions or other third-party claims against us may cause us to incur costly litigation fees, costs and substantial settlement charges, and possibly subject us to damages and other penalties. In addition, the resolution of any IP litigation may require us to make royalty payments, which could adversely affect our gross margins in future periods. If any of those events were to occur, our business, financial condition, results of operations, and cash flows could be adversely affected. Litigation is unpredictable and the actual liability in any such matters may be materially different from our current estimates, which could result in the need to adjust any accrued liability and record additional expenses. We accrue for contingencies when we believe that a loss is probable and that we can reasonably estimate the amount of any such loss. Litigation loss contingency accruals were not material as of March 31, 2021 and December 31, 2020.
  (was, 2020-11-06, similarity 0.969):
[0001262039-20-000067:note_history:4]
Litigation—We are involved in disputes, litigation, and other legal actions. For lawsuits where we are the defendant, we are in the process of defending these litigation matters, and while there can be no assurances and the outcome of certain of these matters is currently not determinable and not predictable, we currently are unaware of any existing claims or proceedings that we believe are likely to have a material adverse effect on our financial position. There are many uncertainties associated with any litigation and these actions or other third-party claims against us may cause us to incur costly litigation fees, costs and substantial settlement charges, and possibly subject us to damages and other penalties. In addition, the resolution of any IP litigation may require us to make royalty payments, which could adversely affect our gross margins in future periods. If any of those events were to occur, our business, financial condition, results of operations, and cash flows could be adversely affected. Litigation is unpredictable and the actual liability in any such matters may be materially different from our current estimates, which could result in the need to adjust any accrued liability and record additional expenses. We accrue for contingencies when we believe that a loss is probable and that we can reasonably estimate the amount of any such loss.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2021-05-03):
[0001262039-21-000014:note_history:5]
SUMMARY OF SIGNIFICANT ACCOUNTING POLICIES
Basis of Presentation and Preparation—The unaudited condensed consolidated financial statements of Fortinet, Inc. and its wholly owned subsidiaries (collectively, “we,” “us” or “our”) have been prepared in accordance with generally accepted accounting principles in the United States (“GAAP”) for interim financial information, as well as the instructions to Form 10-Q pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (the “SEC”). Accordingly, they do not include all of the information and footnotes required by GAAP for complete financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the year ended December 31, 2020, contained in our Annual Report on Form 10-K filed with the SEC on February 19, 2021. In the opinion of management, all adjustments, which includes normal recurring adjustments, considered necessary for a fair presentation have been included. All intercompany balances, transactions and cash flows have been eliminated. The results of operations for the three months ended March 31, 2021 are not necessarily indicative of the results for the full year or for any future periods. The condensed consolidated balance sheet as of December 31, 2020 is derived from the audited consolidated financial statements for the year ended December 31, 2020.
  (was, 2020-11-06, similarity 0.922):
[0001262039-20-000067:note_history:5]
SUMMARY OF SIGNIFICANT ACCOUNTING POLICIES
Basis of Presentation and Preparation—The unaudited condensed consolidated financial statements of Fortinet, Inc. and its wholly owned subsidiaries (collectively, “we,” “us” or “our”) have been prepared in accordance with generally accepted accounting principles in the United States (“GAAP”) for interim financial information, as well as the instructions to Form 10-Q pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (the “SEC”). Accordingly, they do not include all of the information and footnotes required by GAAP for complete financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the year ended December 31, 2019, contained in our Annual Report on Form 10-K filed with the SEC on February 26, 2020. In the opinion of management, all adjustments, which includes normal recurring adjustments, considered necessary for a fair presentation have been included. All intercompany balances, transactions and cash flows have been eliminated. The results of operations for the three and nine months ended September 30, 2020 are not necessarily indicative of the results for the full year or for any future periods. The condensed consolidated balance sheet as of December 31, 2019 is derived from the audited consolidated financial statements for the year ended December 31, 2019. For 2020, the amounts previously reported as Income taxes payable are included in Accrued liabilities. Prior periods have been reclassified to conform with current period presentation.

- changed (2021-05-03):
[0001262039-21-000014:note_history:6]
There have been no material changes to our significant accounting policies as of and for the three months ended March 31, 2021.
  (was, 2020-11-06, similarity 0.9255):
[0001262039-20-000067:note_history:6]
There have been no material changes to our significant accounting policies as of and for the three and nine months ended September 30, 2020.

- changed (2021-05-03):
[0001262039-21-000014:note_history:7]
In December 2019, the Financial Accounting Standards Board (the “FASB”) issued Accounting Standards Update (“ASU”) 2019-12—Income Taxes (“Topic 740”): Simplifying the Accounting for Income Taxes. The amendments in ASU 2019-12 simplify the accounting for income taxes by removing certain exceptions to the general principles in Topic 740. The amendments also improve consistent application and simplification of GAAP for other areas of Topic 740 by clarifying and amending existing guidance. ASU 2019-12 was effective for us beginning on January 1, 2021. The adoption of this guidance did not have any impact on our condensed consolidated financial statements and accompanying disclosures.
  (was, 2020-11-06, similarity 0.6114):
[0001262039-20-000067:note_history:7]
In December 2019, the FASB issued ASU 2019-12—Income Taxes (Topic 740): Simplifying the Accounting for Income Taxes. The amendments in ASU 2019-12 simplify the accounting for income taxes by removing certain exceptions to the general principles in Topic 740. The amendments also improve consistent application and simplification of GAAP for other areas of Topic 740 by clarifying and amending existing guidance. ASU 2019-12 is effective for us beginning on January 1, 2021. We are currently evaluating the impact of ASU 2019-12 on our condensed consolidated financial statements.

- removed (2021-05-03):
[0001262039-20-000067:note_history:8]
Financial Instruments

- removed (2021-05-03):
[0001262039-20-000067:note_history:9]
In June 2016, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) 2016-13—Financial Instruments—Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments (“Topic 326”), which provides guidance on how an entity should measure credit losses on financial instruments. The standard replaces the existing incurred loss model with an expected credit loss model for financial assets measured at amortized cost, including trade receivables, and requires that credit losses on available-for-sale debt securities be presented as an allowance rather than as a write-down. The new approach to estimating credit losses (referred to as the current expected credit losses model) generally accelerates recognition of credit losses. We adopted Topic 326 on January 1, 2020 using the modified retrospective method. The adoption of this standard did not have a material impact on our condensed consolidated financial statements.

- removed (2021-05-03):
[0001262039-20-000067:note_history:10]
Cloud Computing

- removed (2021-05-03):
[0001262039-20-000067:note_history:11]
In August 2018, the FASB issued ASU 2018-15—Intangibles—Goodwill and Other—Internal-Use Software (Subtopic 350-40): Customer’s Accounting for Implementation Costs Incurred in a Cloud Computing Arrangement That Is a Service Contract, which requires a customer in a cloud computing arrangement that is a service contract to follow the internal-use software guidance in Accounting Standards Codification (“ASC”) Topic 350, Intangibles—Goodwill and Other, to determine which implementation costs to capitalize as assets or expense as incurred. We adopted ASU 2018-15 on January 1, 2020. The adoption of this standard did not have a material impact on our condensed consolidated financial statements.

- removed (2021-05-03):
[0001262039-20-000067:note_history:12]
Fair Value Measurements

- removed (2021-05-03):
[0001262039-20-000067:note_history:13]
In August 2018, the FASB issued ASU 2018-13—Fair Value Measurement (Topic 820): Disclosure Framework—Changes to the Disclosure Requirements for Fair Value Measurement, which eliminates, adds and modifies certain disclosure requirements for fair value measurements in ASC 820, Fair Value Measurement, as part of its disclosure framework project. We adopted ASU 2018-13 on January 1, 2020. The adoption of this standard did not have a material impact on our disclosures.

- removed (2021-05-03):
[0001262039-20-000067:note_history:14]
Recent Accounting Standards Not Yet Effective


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: no_prior_note, score: 0.0

- added (2021-05-03):
[0001262039-21-000014:note_history:15]
DEBT
On March 5, 2021, we issued $1.0 billion aggregate principal amount of senior notes (collectively, the “Senior Notes”), consisting of $500.0 million aggregate principal amount of 1.0% notes due March 15, 2026 (the “2026 Senior Notes”) and $500.0 million aggregate principal amount of 2.2% notes due March 15, 2031 (the “2031 Senior Notes”), in an underwritten registered public offering. The Senior Notes are senior unsecured obligations and rank equally with each other in right of payment and with our other outstanding obligations. We may redeem the Senior Notes at any time in whole or in part for cash, at specified redemption prices that include accrued and unpaid interest, if any, and a make-whole premium. However, no make-whole premium will be paid for redemptions of the 2026 Senior Notes on or after February 15, 2026, or the 2031 Senior Notes on or after December 15, 2030. Interest on the Senior Notes is payable on March 15 and September 15 of each year, beginning on September 15, 2021. As of March 31, 2021, the Senior Notes were recorded as long-term debt, net of discount and issuance costs, which are amortized to interest expense over the respective contractual terms of these notes using the effective interest method.

- added (2021-05-03):
[0001262039-21-000014:note_history:16]
The total outstanding debt is summarized below (in millions, except percentages):

- added (2021-05-03):
[0001262039-21-000014:note_history:17]
|  | Maturity |  | Coupon Rate |  | Effective Interest Rate |  | March 31, 2021 |
| Debt |  |  |  |  |  |  |  |
| 2026 Senior Notes | March 2026 |  | 1.0 | % |  | 1.3 | % |  | $ | 500.0 |  |
| 2031 Senior Notes | March 2031 |  | 2.2 | % |  | 2.3 | % |  | 500.0 |  |
| Total debt |  |  |  |  |  |  | 1,000.0 |  |
| Less: Unamortized discount and debt issuance costs |  |  |  |  |  |  | (13.0) |  |
| Total long-term debt |  |  |  |  |  |  | $ | 987.0 |  |

- added (2021-05-03):
[0001262039-21-000014:note_history:18]
As of March 31, 2021 we accrued interest payable of $1.2 million, and there are no financial covenants with which we must comply. During the quarter ended March 31, 2021 we recorded $1.3 million of total interest expense in relation to these Senior Notes.

- added (2021-05-03):
[0001262039-21-000014:note_history:19]
The total estimated fair value of the outstanding Senior Notes was approximately $975.6 million, including accrued and unpaid interest, as of March 31, 2021. The fair value was determined based on observable market prices of identical instruments in less active markets. The estimated fair values are based on Level 2 inputs.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: no_prior_note, score: 0.0

- added (2021-05-03):
[0001262039-21-000014:note_history:20]
The total outstanding debt is summarized below (in millions, except percentages):

- added (2021-05-03):
[0001262039-21-000014:note_history:21]
|  | Maturity |  | Coupon Rate |  | Effective Interest Rate |  | March 31, 2021 |
| Debt |  |  |  |  |  |  |  |
| 2026 Senior Notes | March 2026 |  | 1.0 | % |  | 1.3 | % |  | $ | 500.0 |  |
| 2031 Senior Notes | March 2031 |  | 2.2 | % |  | 2.3 | % |  | 500.0 |  |
| Total debt |  |  |  |  |  |  | 1,000.0 |  |
| Less: Unamortized discount and debt issuance costs |  |  |  |  |  |  | (13.0) |  |
| Total long-term debt |  |  |  |  |  |  | $ | 987.0 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2021-05-03):
[0001262039-21-000014:note_history:22]
|  | Three Months Ended |  |  |
|  | March 31,2021 |  | March 31,2020 |  |  |  |  |
| Product | $ | 240.7 |  |  | $ | 192.3 |  |  |  |  |  |
| Service: |  |  |  |  |  |  |  |
| Security subscription | 255.3 |  |  | 211.4 |  |  |  |  |  |
| Technical support and other | 214.3 |  |  | 174.0 |  |  |  |  |  |
| Total service revenue | 469.6 |  |  | 385.4 |  |  |  |  |  |
| Total revenue | $ | 710.3 |  |  | $ | 577.7 |  |  |  |  |  |
  (was, 2020-11-06, similarity 0.6518):
[0001262039-20-000067:note_history:22]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30,2020 |  | September 30,2019 |  | September 30,2020 |  | September 30,2019 |
| Product | $ | 223.8 |  |  | $ | 197.1 |  |  | $ | 628.0 |  |  | $ | 549.7 |  |
| Service: |  |  |  |  |  |  |  |
| Security subscription | 235.4 |  |  | 192.8 |  |  | 669.4 |  |  | 545.5 |  |
| Technical support and other | 191.9 |  |  | 158.2 |  |  | 549.0 |  |  | 449.7 |  |
| Total service revenue | 427.3 |  |  | 351.0 |  |  | 1,218.4 |  |  | 995.2 |  |
| Total revenue | $ | 651.1 |  |  | $ | 548.1 |  |  | $ | 1,846.4 |  |  | $ | 1,544.9 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2021-05-03):
[0001262039-21-000014:note_history:23]
REVENUE RECOGNITIONWe sell cybersecurity solutions to a variety of organizations, such as enterprises, communication service providers, government organizations and small to medium-sized enterprises. Our revenue consists of product and service revenue. Product revenue is generated by our FortiGate network security products, our Fortinet Security Fabric platform products and other products. Service revenue relates to sales of our security subscription services, which mainly consists of our FortiGuard security solutions, as well as our FortiCare technical support services and other services.
Disaggregation of Revenue
  (was, 2020-11-06, similarity 0.9377):
[0001262039-20-000067:note_history:23]
REVENUE RECOGNITION
We sell cybersecurity solutions to a variety of organizations, such as enterprises, communication service providers, government organizations and small businesses. Our revenue consists of product and service revenue. Product revenue is generated by our FortiGate network security appliances, our Fortinet Security Fabric platform products and other products. Service revenue relates to sales of our security subscription services, which mainly consist of our FortiGuard security solutions, as well as our FortiCare technical support services and other services.

- changed (2021-05-03):
[0001262039-21-000014:note_history:24]
|  | Three Months Ended |  |  |
|  | March 31,2021 |  | March 31,2020 |  |  |  |  |
| Product | $ | 240.7 |  |  | $ | 192.3 |  |  |  |  |  |
| Service: |  |  |  |  |  |  |  |
| Security subscription | 255.3 |  |  | 211.4 |  |  |  |  |  |
| Technical support and other | 214.3 |  |  | 174.0 |  |  |  |  |  |
| Total service revenue | 469.6 |  |  | 385.4 |  |  |  |  |  |
| Total revenue | $ | 710.3 |  |  | $ | 577.7 |  |  |  |  |  |
  (was, 2020-11-06, similarity 0.6518):
[0001262039-20-000067:note_history:24]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30,2020 |  | September 30,2019 |  | September 30,2020 |  | September 30,2019 |
| Product | $ | 223.8 |  |  | $ | 197.1 |  |  | $ | 628.0 |  |  | $ | 549.7 |  |
| Service: |  |  |  |  |  |  |  |
| Security subscription | 235.4 |  |  | 192.8 |  |  | 669.4 |  |  | 545.5 |  |
| Technical support and other | 191.9 |  |  | 158.2 |  |  | 549.0 |  |  | 449.7 |  |
| Total service revenue | 427.3 |  |  | 351.0 |  |  | 1,218.4 |  |  | 995.2 |  |
| Total revenue | $ | 651.1 |  |  | $ | 548.1 |  |  | $ | 1,846.4 |  |  | $ | 1,544.9 |  |

- added (2021-05-03):
[0001262039-21-000014:note_history:25]
During the three months ended March 31, 2021 and March 31, 2020, we recognized $417.9 million and $343.3 million in service revenue that was included in the deferred revenue balance as of December 31, 2020 and December 31, 2019, respectively.

- changed (2021-05-03):
[0001262039-21-000014:note_history:26]
As of March 31, 2021, the aggregate amount of the transaction price allocated to remaining performance obligations was $2.75 billion, which was substantially comprised of deferred security subscription and technical support services revenue. We expect to recognize approximately $1.47 billion as revenue over the next 12 months and the remainder thereafter.
  (was, 2020-11-06, similarity 0.9798):
[0001262039-20-000067:note_history:26]
As of September 30, 2020, the aggregate amount of the transaction price allocated to remaining performance obligations was $2.39 billion, which was substantially comprised of deferred security subscription and technical support services revenue. We expect to recognize approximately $1.30 billion as revenue over the next 12 months and the remainder thereafter.

- changed (2021-05-03):
[0001262039-21-000014:note_history:27]
Trade accounts receivable are recorded at the invoiced amount. Our accounts receivable balance is reduced by an allowance for expected credit losses. We measure expected credit losses of accounts receivable on a collective (pooled) basis, aggregating accounts receivable that are either current or no more than 60 days past due, and aggregating accounts receivable that are more than 60 days past due. We apply a credit-loss percentage to each of the pools that is based on our historical credit losses. We review whether each of our significant accounts receivable that is more than 60 days past due continues to exhibit similar risk characteristics with the other accounts receivable in the pool. If we determine that it does not, we evaluate it for expected credit losses on an individual basis. Expected credit losses are recorded as general and administrative expenses on our consolidated statements of income.
  (was, 2020-11-06, similarity 0.7681):
[0001262039-20-000067:note_history:27]
Trade accounts receivable are recorded at the invoiced amount. On January 1, 2020, we adopted Topic 326, which provides guidance on how to measure credit losses on financial instruments, including accounts receivable. Prior to our adoption of Topic 326, our accounts receivable balance was reduced by an allowance for doubtful accounts that we determined based on our assessment of the collectability of customer accounts. Under Topic 326, our accounts receivable balance is reduced by an allowance for expected credit losses. We measure expected credit losses of accounts receivable on a collective (pooled) basis, aggregating accounts receivable that are either current or no more than 60 days past due, and aggregating accounts receivable that are more than 60 days past due. We apply a credit-loss percentage to each of the pools that is based on our historical credit losses. We review whether each of our significant accounts receivable that is more than 60 days past due continues to exhibit similar risk characteristics with the other accounts receivable in the pool. If we determine that it does not, we evaluate it for expected credit losses on an individual basis.

- added (2021-05-03):
[0001262039-21-000014:note_history:28]
The allowance for credit losses was $3.1 million and $2.5 million as of March 31, 2021 and December 31, 2020, respectively. Provisions, write-offs and recoveries were not material during the three months ended March 31, 2021 and 2020.

- added (2021-05-03):
[0001262039-21-000014:note_history:29]
Deferred Contract Costs
Amortization of deferred contract costs during the three months ended March 31, 2021 and 2020 were $39.7 million and $31.3 million, respectively.

- removed (2021-05-03):
[0001262039-20-000067:note_history:30]
Disaggregation of Revenue

- removed (2021-05-03):
[0001262039-20-000067:note_history:31]
During the three months ended September 30, 2020 and September 30, 2019, we recognized $263.1 million and $211.8 million in service revenue that was included in the deferred revenue balance as of December 31, 2019 and December 31, 2018, respectively. During the nine months ended September 30, 2020 and September 30, 2019, we recognized $921.7 million and $754.5 million in service revenue that was included in the deferred revenue balance as of December 31, 2019 and December 31, 2018, respectively.

- removed (2021-05-03):
[0001262039-20-000067:note_history:32]
The COVID-19 pandemic and the recent economic downturn prompted us to perform additional credit reviews of our existing customers, including obtaining recent credit reports and reviewing their latest available statements of financial position. In addition, we have seen an increase in requests for extended payment terms. After performing our additional reviews, we increased the allowance for credit losses for certain accounts receivable.

- removed (2021-05-03):
[0001262039-20-000067:note_history:33]
The allowance for credit losses was $2.2 million as of September 30, 2020, and the allowance for doubtful accounts was $1.2 million as of December 31, 2019. Provisions, write-offs and recoveries were not material during the nine months ended September 30, 2020.

- removed (2021-05-03):
[0001262039-20-000067:note_history:34]
Deferred Contract Costs

- removed (2021-05-03):
[0001262039-20-000067:note_history:35]
Sales commissions earned by our sales force are considered incremental and recoverable costs of obtaining a contract with a customer. The amortization of deferred contract costs is included in sales and marketing expense in our condensed consolidated statements of income. Amortization of deferred contract costs during the three months ended September 30, 2020 and September 30, 2019 were $35.3 million and $27.5 million, respectively. Amortization of deferred contract costs during the nine months ended September 30, 2020 and September 30, 2019 were $99.8 million and $78.5 million, respectively.
